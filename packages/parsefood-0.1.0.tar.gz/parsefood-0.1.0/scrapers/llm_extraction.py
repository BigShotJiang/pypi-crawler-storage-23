"""LLM-based nutrition extraction for scrapers."""

import logging
from typing import Optional

from pydantic import ValidationError

from food_log.config import MODEL_ID
from food_log.llm.client import create_openrouter_client
from food_log.llm.prompts import create_nutrition_extraction_prompt
from food_log.utils import parse_json_response
from .models import NutritionPer100g

logger = logging.getLogger(__name__)


class NutritionExtractionError(Exception):
    """Raised when nutrition extraction fails."""

    pass


def extract_nutrition_with_llm(raw_text: str) -> Optional[NutritionPer100g]:
    """
    Extract nutrition data from raw text using LLM.

    Args:
        raw_text: Raw text content from the nutrition table container

    Returns:
        NutritionPer100g model if extraction succeeds, None if:
        - Only per 100ml data is available (returns None, not an error)
        - Extraction fails (logs warning and returns None)

    Raises:
        NutritionExtractionError: If LLM API call fails
    """
    if not raw_text or not raw_text.strip():
        logger.warning("Empty text provided for nutrition extraction")
        return None

    client = create_openrouter_client()

    messages = [
        {"role": "system", "content": create_nutrition_extraction_prompt()},
        {"role": "user", "content": raw_text},
    ]

    try:
        response = client.chat.completions.create(
            model=MODEL_ID, messages=messages, temperature=0
        )
        response_text = response.choices[0].message.content.strip()
    except Exception as e:
        logger.error(f"LLM API call failed: {e}")
        raise NutritionExtractionError(f"LLM API call failed: {e}") from e

    data = parse_json_response(response_text, array=False)
    if data is None:
        logger.warning(f"Failed to parse JSON from LLM response: {response_text[:200]}")
        return None

    # All nulls = only per 100ml data available
    if all(v is None for v in data.values()):
        logger.info("LLM returned all nulls - likely only per 100ml data available")
        return None

    try:
        validated = {
            "calories": data.get("calories") or 0,
            "proteins": data.get("proteins") or 0.0,
            "carbs": data.get("carbs") or 0.0,
            "fats": data.get("fats") or 0.0,
            "fiber": data.get("fiber"),
            "sodium": data.get("sodium"),
        }
        return NutritionPer100g(**validated)
    except ValidationError as e:
        logger.warning(f"Validation failed for extracted data: {e}")
        return None
