"""Food scraper package for extracting nutrition data from product URLs."""

from .base import FoodScraper
from .celeiro import CeleiroScraper
from .continente import ContinenteScraper
from .pingo_doce import PingoDoceScraper
from .models import NutritionPer100g, ScrapedFoodEntry, ScrapeResult
from .registry import ScraperRegistry, registry

# Re-export from food_log.database for backward compatibility
from food_log.database import (
    create_backup,
    load_database,
    merge_entry,
    save_database,
    validate_against_existing,
)

__all__ = [
    # Protocol
    "FoodScraper",
    # Models
    "NutritionPer100g",
    "ScrapedFoodEntry",
    "ScrapeResult",
    # Registry
    "ScraperRegistry",
    "registry",
    # Scrapers
    "CeleiroScraper",
    "ContinenteScraper",
    "PingoDoceScraper",
    # Utilities (re-exported from food_log.database)
    "create_backup",
    "load_database",
    "save_database",
    "merge_entry",
    "validate_against_existing",
]
