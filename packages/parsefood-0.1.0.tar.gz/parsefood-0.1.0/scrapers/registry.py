"""Scraper registry for URL pattern matching."""

from typing import List, Optional

from .base import FoodScraper


class ScraperRegistry:
    """Registry for food scrapers with URL pattern matching.

    Scrapers are registered and then selected based on URL patterns.
    The first scraper that can handle a URL will be used.
    """

    def __init__(self) -> None:
        self._scrapers: List[FoodScraper] = []

    def register(self, scraper: FoodScraper) -> None:
        """Register a scraper.

        Args:
            scraper: The scraper instance to register.
        """
        self._scrapers.append(scraper)

    def get_scraper(self, url: str) -> Optional[FoodScraper]:
        """Find a scraper that can handle the given URL.

        Args:
            url: The URL to find a scraper for.

        Returns:
            The first scraper that can handle the URL, or None.
        """
        for scraper in self._scrapers:
            if scraper.can_handle(url):
                return scraper
        return None

    def list_scrapers(self) -> List[str]:
        """List all registered scraper names.

        Returns:
            List of scraper names.
        """
        return [s.name for s in self._scrapers]


# Global registry instance
registry = ScraperRegistry()
