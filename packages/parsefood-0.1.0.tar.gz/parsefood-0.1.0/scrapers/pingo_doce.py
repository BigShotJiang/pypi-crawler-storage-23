"""Scraper for Pingo Doce product pages."""

import logging
import re
from typing import Optional

from playwright.sync_api import Page, TimeoutError as PlaywrightTimeout, sync_playwright

from .models import NutritionPer100g, ScrapedFoodEntry, ScrapeResult

logger = logging.getLogger(__name__)


class PingoDoceScraper:
    """Scraper for Pingo Doce product pages.

    Uses Playwright for JavaScript rendering since the nutrition
    data may be loaded dynamically.
    """

    name = "Pingo Doce"
    url_pattern = r"https?://(?:www\.)?pingodoce\.pt/.+\.html"

    # Selectors for page elements
    SELECTORS = {
        "product_name": "h1.product-name, h1[class*='product'], h1",
        "nutrition_tab": "[data-tab='nutritional'], [href*='nutritional']",
        "nutrition_container": ".nutritional-info, .nutrition-table, table",
    }

    def can_handle(self, url: str) -> bool:
        """Check if this scraper can handle the given URL."""
        return bool(re.match(self.url_pattern, url))

    def scrape(self, url: str) -> ScrapeResult:
        """Scrape nutrition data using Playwright for JS rendering."""
        logger.info(f"Scraping {url}")

        try:
            with sync_playwright() as p:
                browser = p.chromium.launch(headless=True)
                context = browser.new_context(
                    user_agent=(
                        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                        "AppleWebKit/537.36 (KHTML, like Gecko) "
                        "Chrome/120.0.0.0 Safari/537.36"
                    ),
                    locale="pt-PT",
                )
                page = context.new_page()

                # Navigate to page
                logger.info("Loading page...")
                page.goto(url, wait_until="domcontentloaded", timeout=30000)

                # Wait for product name to appear
                page.wait_for_selector(self.SELECTORS["product_name"], timeout=10000)

                # Scroll down to load lazy content and wait for page to settle
                page.evaluate("window.scrollTo(0, document.body.scrollHeight / 2)")
                page.wait_for_timeout(2000)

                # Try to expand nutrition section if needed
                self._expand_nutrition_section(page)

                # Extract data
                entry = self._extract_nutrition(page, url)
                browser.close()

                if entry:
                    return ScrapeResult(success=True, entry=entry, source_url=url)
                else:
                    return ScrapeResult(
                        success=False,
                        error="Failed to extract nutrition data",
                        source_url=url,
                    )

        except PlaywrightTimeout as e:
            logger.error(f"Timeout: {e}")
            return ScrapeResult(
                success=False, error=f"Timeout waiting for page content: {e}", source_url=url
            )
        except Exception as e:
            logger.error(f"Error scraping {url}: {e}")
            return ScrapeResult(success=False, error=str(e), source_url=url)

    def _expand_nutrition_section(self, page: Page) -> None:
        """Try to expand the nutrition information section if collapsed."""
        try:
            tab_button_selectors = [
                '[data-tab="nutritional"]',
                '[href*="nutritional"]',
                'button:has-text("Nutricional")',
                'a:has-text("Nutricional")',
                '[role="tab"]:has-text("Nutricional")',
                'button:has-text("Informação Nutricional")',
                '.tab:has-text("Nutri")',
            ]

            clicked = False
            for selector in tab_button_selectors:
                try:
                    button = page.locator(selector).first
                    if button.count() > 0 and button.is_visible():
                        logger.info(f"Found nutrition tab with selector: {selector}")
                        button.scroll_into_view_if_needed()
                        page.wait_for_timeout(300)
                        button.click(force=True)
                        page.wait_for_timeout(500)
                        clicked = True
                        break
                except Exception as e:
                    logger.debug(f"Could not click {selector}: {e}")
                    continue

            if clicked:
                page.wait_for_timeout(1000)
                logger.info("Clicked nutrition tab")
            else:
                logger.debug("No nutrition tab button found (may not be needed)")

        except Exception as e:
            logger.warning(f"Could not expand nutrition section: {e}")

    def _extract_nutrition(self, page: Page, url: str) -> Optional[ScrapedFoodEntry]:
        """Extract nutrition data from the loaded page."""
        # Get product name
        name = self._extract_product_name(page)
        if not name:
            logger.error("Could not find product name")
            return None

        logger.info(f"Product name: {name}")

        # Extract nutrition values
        nutrition = self._extract_nutrition_values(page)
        if not nutrition:
            logger.error("Could not extract nutrition values")
            return None

        logger.info(f"Extracted nutrition: {nutrition}")

        # Extract unit weight from page title or URL
        grams_per_unit = {"g": 1}
        unit_weight = self._extract_unit_weight(page, url)
        if unit_weight:
            grams_per_unit["unit"] = unit_weight
            logger.info(f"Extracted unit weight: {unit_weight}g")

        return ScrapedFoodEntry(
            name=name,
            url=url,
            grams_per_unit=grams_per_unit,
            nutrition_per_100g=NutritionPer100g(**nutrition),
        )

    def _extract_product_name(self, page: Page) -> Optional[str]:
        """Extract the product name from the page."""
        try:
            name_elem = page.locator(self.SELECTORS["product_name"]).first
            if name_elem.count() > 0:
                return name_elem.inner_text().strip()
        except Exception as e:
            logger.warning(f"Error extracting product name: {e}")
        return None

    def _extract_unit_weight(self, page: Page, url: str) -> Optional[float]:
        """Extract unit/package weight from the page or URL.

        Looks for weight info in:
        1. URL (e.g., "pack-2" combined with product weight)
        2. Page title
        3. Product name
        """
        try:
            # Patterns for weight extraction
            weight_patterns = [
                r"(\d+(?:[.,]\d+)?)[-\s]*(?:gramas?|gr?)\b",  # 125 gramas, 125g
                r"(\d+(?:[.,]\d+)?)[-\s]*(?:ml)\b",  # 250 ml
                r"(\d+(?:[.,]\d+)?)\s*[xX]\s*(\d+(?:[.,]\d+)?)\s*(?:gr?|ml)",  # 2x125g
            ]

            # Try URL first
            for pattern in weight_patterns:
                match = re.search(pattern, url, re.IGNORECASE)
                if match:
                    if match.lastindex == 2:  # Pattern with multiplier (e.g., 2x125g)
                        count = float(match.group(1).replace(",", "."))
                        weight = float(match.group(2).replace(",", "."))
                        total = count * weight
                    else:
                        total = float(match.group(1).replace(",", "."))
                    if 1 <= total <= 10000:  # Sanity check
                        return total

            # Try page title
            title = page.title()
            if title:
                for pattern in weight_patterns:
                    match = re.search(pattern, title, re.IGNORECASE)
                    if match:
                        if match.lastindex == 2:
                            count = float(match.group(1).replace(",", "."))
                            weight = float(match.group(2).replace(",", "."))
                            total = count * weight
                        else:
                            total = float(match.group(1).replace(",", "."))
                        if 1 <= total <= 10000:
                            return total

            # Try product name element
            name_elem = page.locator(self.SELECTORS["product_name"]).first
            if name_elem.count() > 0:
                name_text = name_elem.inner_text()
                for pattern in weight_patterns:
                    match = re.search(pattern, name_text, re.IGNORECASE)
                    if match:
                        if match.lastindex == 2:
                            count = float(match.group(1).replace(",", "."))
                            weight = float(match.group(2).replace(",", "."))
                            total = count * weight
                        else:
                            total = float(match.group(1).replace(",", "."))
                        if 1 <= total <= 10000:
                            return total

        except Exception as e:
            logger.debug(f"Could not extract unit weight: {e}")

        return None

    def _extract_nutrition_values(self, page: Page) -> Optional[dict]:
        """Extract nutrition values from the page using LLM.

        Extracts raw text from nutrition containers and uses an LLM
        to parse the nutrition data.
        """
        try:
            # Try multiple selectors for nutrition data
            nutrition_selectors = [
                ".nutritional-info",
                ".nutrition-table",
                "table:has-text('Energia')",
                "div:has-text('Valor energético')",
                "div:has-text('Informação Nutricional')",
                ".product-info table",
                "section:has-text('Nutricional')",
            ]

            container = None
            for selector in nutrition_selectors:
                try:
                    elem = page.locator(selector).first
                    if elem.count() > 0:
                        text = elem.inner_text()
                        # Check if this looks like nutrition data
                        if any(
                            keyword in text.lower()
                            for keyword in ["energia", "proteína", "hidratos", "lípidos", "gordura"]
                        ):
                            container = elem
                            logger.info(f"Found nutrition data with selector: {selector}")
                            break
                except Exception:
                    continue

            if container is None:
                # Fallback: get all page text and search for nutrition section
                logger.warning("No dedicated nutrition container found, trying page-wide search")
                page_text = page.content()
                # Try to find nutrition table in raw HTML
                if "Valor energético" in page_text or "energia" in page_text.lower():
                    # Get body text as fallback
                    container = page.locator("body")
                else:
                    logger.error("Could not find nutrition information on page")
                    return None

            # Extract text from the container
            raw_text = container.inner_text()

            if not raw_text or len(raw_text.strip()) < 20:
                logger.warning(
                    f"Insufficient text in nutrition container: "
                    f"{raw_text[:50] if raw_text else 'empty'}"
                )
                return None

            logger.info(f"Extracted {len(raw_text)} chars from nutrition container")
            logger.debug(f"Raw text: {raw_text[:500]}...")

            # Use LLM to extract structured data
            from .llm_extraction import NutritionExtractionError, extract_nutrition_with_llm

            try:
                nutrition = extract_nutrition_with_llm(raw_text)
            except NutritionExtractionError as e:
                logger.error(f"LLM extraction failed: {e}")
                return None

            if nutrition is None:
                logger.warning("LLM extraction returned None (possibly only per 100ml data)")
                return None

            # Convert Pydantic model to dict for compatibility with existing code
            return nutrition.model_dump()

        except Exception as e:
            logger.error(f"Error extracting nutrition values: {e}")
            return None
