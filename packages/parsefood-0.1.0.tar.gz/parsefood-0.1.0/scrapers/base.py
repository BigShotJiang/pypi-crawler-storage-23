"""Abstract base protocol for food scrapers."""

from typing import Protocol

from .models import ScrapeResult


class FoodScraper(Protocol):
    """Protocol defining the interface for food scrapers.

    All scrapers must implement this protocol to be registered
    in the scraper registry.
    """

    @property
    def name(self) -> str:
        """Human-readable name of the scraper."""
        ...

    @property
    def url_pattern(self) -> str:
        """Regex pattern for URLs this scraper handles."""
        ...

    def can_handle(self, url: str) -> bool:
        """Check if this scraper can handle the given URL.

        Args:
            url: The URL to check.

        Returns:
            True if this scraper can handle the URL.
        """
        ...

    def scrape(self, url: str) -> ScrapeResult:
        """Scrape nutritional data from the given URL.

        Args:
            url: The product URL to scrape.

        Returns:
            ScrapeResult with success status and extracted data or error.
        """
        ...
