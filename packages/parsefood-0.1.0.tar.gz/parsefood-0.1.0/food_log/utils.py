"""Shared utilities for the food log parser."""

import concurrent.futures
import json
import logging
import re
from typing import Any, Callable, Dict, List, Optional, Tuple

from tqdm import tqdm

from .config import UNIT_MAP

logger = logging.getLogger(__name__)


def normalize_name(value: str) -> Optional[str]:
    """
    Normalize a food name or string field.

    Strips whitespace and converts to lowercase.

    Args:
        value: The string to normalize

    Returns:
        Normalized string or None if empty
    """
    if not value or not value.strip():
        return None
    return value.strip().lower()


def normalize_unit(unit: str) -> str:
    """
    Normalize a unit to standard form.

    Maps Portuguese and other unit variations to standard units:
    tbsp, tsp, cup, unit, g

    Args:
        unit: The unit string to normalize

    Returns:
        Standard unit string (defaults to 'unit' if not found)
    """
    if not unit:
        return 'unit'
    unit_lower = unit.lower().strip()
    return UNIT_MAP.get(unit_lower, 'unit')


def extract_json_from_response(text: str, array: bool = False) -> Optional[str]:
    """
    Extract JSON from an LLM response that may contain markdown or extra text.

    Tries multiple patterns in order:
    1. ```json ... ``` markdown blocks
    2. ``` ... ``` generic code blocks
    3. Direct JSON (array or object)

    Args:
        text: The response text to parse
        array: If True, look for JSON array; if False, look for JSON object

    Returns:
        The extracted JSON string, or None if not found
    """
    if not text:
        return None

    text = text.strip()

    if array:
        # Look for JSON array
        # Pattern 1: ```json [...] ```
        match = re.search(r'```json\s*(\[.*?\])\s*```', text, re.DOTALL)
        if match:
            return match.group(1)

        # Pattern 2: ``` [...] ```
        match = re.search(r'```\s*(\[.*?\])\s*```', text, re.DOTALL)
        if match:
            return match.group(1)

        # Pattern 3: Direct JSON array
        match = re.search(r'\[.*?\]', text, re.DOTALL)
        if match:
            return match.group()
    else:
        # Look for JSON object
        # Pattern 1: ```json {...} ```
        match = re.search(r'```json\s*(\{.*?\})\s*```', text, re.DOTALL)
        if match:
            return match.group(1)

        # Pattern 2: ``` {...} ```
        match = re.search(r'```\s*(\{.*?\})\s*```', text, re.DOTALL)
        if match:
            return match.group(1)

        # Pattern 3: Direct JSON object (greedy to handle nested objects)
        match = re.search(r'\{.*\}', text, re.DOTALL)
        if match:
            return match.group()

    return None


def parse_json_response(text: str, array: bool = False) -> Optional[Any]:
    """
    Extract and parse JSON from an LLM response.

    Args:
        text: The response text to parse
        array: If True, expect JSON array; if False, expect JSON object

    Returns:
        Parsed JSON (list or dict), or None if parsing fails
    """
    json_str = extract_json_from_response(text, array=array)
    if not json_str:
        return None

    try:
        return json.loads(json_str)
    except json.JSONDecodeError as e:
        logger.warning(f"Failed to parse JSON: {e}")
        return None


def run_tasks(
    tasks: List[Tuple[Callable, Any]],
    name: str = "Processing tasks",
    max_workers: int = 5,
    timeout: int = 30
) -> None:
    """
    Run tasks concurrently with a progress bar.

    Args:
        tasks: List of (function, *args) tuples. The function will receive
               the args followed by the task index.
        name: Description for the progress bar
        max_workers: Maximum number of concurrent workers
        timeout: Timeout in seconds for each task
    """
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [executor.submit(*tasks[index], index) for index in range(len(tasks))]
        progress_bar = tqdm(
            total=len(tasks),
            desc=name,
            bar_format='{l_bar}{bar}| {n_fmt}/{total_fmt}'
        )

        for future in concurrent.futures.as_completed(futures):
            try:
                future.result(timeout=timeout)
                progress_bar.update(1)
            except Exception:
                for f in futures:
                    f.cancel()
                logging.exception("Task execution failed")
                raise
        progress_bar.close()


def format_quantity(quantity: float) -> str:
    """
    Format a quantity for display, removing .0 from whole numbers.

    Args:
        quantity: The quantity to format

    Returns:
        Formatted string (e.g., "2" for 2.0, "2.5" for 2.5)
    """
    if quantity == int(quantity):
        return str(int(quantity))
    return str(quantity)
