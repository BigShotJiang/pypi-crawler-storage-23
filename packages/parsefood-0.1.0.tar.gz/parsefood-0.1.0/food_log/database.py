"""Database operations for the food log parser."""

import json
import logging
import shutil
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from .config import BACKUP_TIMESTAMP_FORMAT, FOOD_DATABASE_PATH

logger = logging.getLogger(__name__)


def load_json(file_path: str | Path) -> Dict[str, Any]:
    """
    Load a JSON file.

    Args:
        file_path: Path to the JSON file

    Returns:
        Parsed JSON data (dict)
    """
    return json.loads(Path(file_path).read_text(encoding='utf-8'))


def save_json(file_path: str | Path, data: Dict[str, Any], sort_keys: bool = False) -> None:
    """
    Save data to a JSON file.

    Args:
        file_path: Path to save the JSON file
        data: Data to save
        sort_keys: Whether to sort dictionary keys
    """
    if sort_keys:
        data = dict(sorted(data.items()))
    Path(file_path).write_text(
        json.dumps(data, indent=4 if not sort_keys else 2, ensure_ascii=False),
        encoding='utf-8'
    )


def load_database(file_path: Path = FOOD_DATABASE_PATH) -> Dict[str, Any]:
    """
    Load the food database from JSON.

    Args:
        file_path: Path to the database file

    Returns:
        Dictionary of food entries, empty dict if file doesn't exist
    """
    if not file_path.exists():
        logger.warning(f"Food database not found at {file_path}")
        return {}

    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
            logger.info(f"Loaded {len(data)} entries from {file_path}")
            return data
    except json.JSONDecodeError as e:
        logger.error(f"Failed to parse food database JSON: {e}")
        return {}
    except Exception as e:
        logger.error(f"Failed to load food database: {e}")
        return {}


def save_database(data: Dict[str, Any], file_path: Path = FOOD_DATABASE_PATH) -> bool:
    """
    Save the food database to JSON with sorted keys.

    Args:
        data: Dictionary of food entries
        file_path: Path to save to

    Returns:
        True if saved successfully
    """
    try:
        sorted_data = dict(sorted(data.items()))
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(sorted_data, f, indent=2, ensure_ascii=False)
        logger.info(f"Saved {len(sorted_data)} entries to {file_path}")
        return True
    except Exception as e:
        logger.error(f"Failed to save food database: {e}")
        return False


def create_backup(
    file_path: Path,
    backup_dir: Optional[Path] = None
) -> Optional[Path]:
    """
    Create a timestamped backup of a file.

    Args:
        file_path: Path to file to backup
        backup_dir: Optional directory for backups. If None, creates backup
                   in same directory with .backup_TIMESTAMP suffix

    Returns:
        Path to backup file if created, None if source doesn't exist
    """
    if not file_path.exists():
        logger.info(f"No file found at {file_path}, skipping backup")
        return None

    try:
        timestamp = datetime.now().strftime(BACKUP_TIMESTAMP_FORMAT)

        if backup_dir:
            # Create backup in specified directory
            backup_dir.mkdir(exist_ok=True)
            backup_path = backup_dir / f'{file_path.stem}_{timestamp}.json'
        else:
            # Create backup in same directory with timestamp suffix
            backup_path = file_path.with_suffix(f'.backup_{timestamp}.json')

        shutil.copy2(file_path, backup_path)
        logger.info(f"Created backup: {backup_path.name}")
        return backup_path
    except Exception as e:
        logger.error(f"Failed to create backup: {e}")
        raise


def merge_entry(
    existing: Dict[str, Any],
    new_entry: Dict[str, Any],
    overwrite: bool = False
) -> Tuple[Dict[str, Any], int, int]:
    """
    Merge a new entry into the existing database.

    When an entry already exists:
    - If overwrite=True: Replace the entire entry
    - If overwrite=False: Merge grams_per_unit, keep existing nutrition data

    Args:
        existing: Existing food database
        new_entry: New entry to merge (dict with name, url, grams_per_unit, nutrition_per_100g)
        overwrite: If True, overwrite existing entries

    Returns:
        Tuple of (merged dict, num_added, num_skipped)
    """
    merged = existing.copy()
    added = 0
    skipped = 0

    entry_name = new_entry.get("name", "")
    if not entry_name:
        logger.warning("Cannot merge entry without name")
        return merged, 0, 1

    if entry_name in merged:
        if overwrite:
            logger.warning(f"Overwriting existing entry: {entry_name}")
            merged[entry_name] = new_entry
            added = 1
        else:
            # Merge grams_per_unit instead of skipping
            existing_units = set(merged[entry_name].get("grams_per_unit", {}).keys())
            new_units = set(new_entry.get("grams_per_unit", {}).keys())
            units_to_add = new_units - existing_units

            if units_to_add:
                logger.info(f"Merging units {units_to_add} into existing entry: {entry_name}")
                for unit in units_to_add:
                    merged[entry_name]["grams_per_unit"][unit] = new_entry["grams_per_unit"][unit]
                # Update URL if provided
                if new_entry.get("url"):
                    merged[entry_name]["url"] = new_entry["url"]
                added = 1
            else:
                logger.warning(f"Skipping duplicate entry (no new units): {entry_name}")
                skipped = 1
    else:
        merged[entry_name] = new_entry
        added = 1

    return merged, added, skipped


def merge_entries(
    existing: Dict[str, Any],
    new_entries: Dict[str, Any],
    overwrite: bool = False
) -> Tuple[Dict[str, Any], int, int]:
    """
    Merge multiple new entries into existing database.

    Args:
        existing: Existing food database entries
        new_entries: Dict of new entries to merge (keyed by entry name)
        overwrite: If True, overwrite existing entries. If False, merge units.

    Returns:
        Tuple of (merged dict, num_added, num_skipped)
    """
    merged = existing.copy()
    total_added = 0
    total_skipped = 0

    for entry_name, entry_data in new_entries.items():
        # Ensure entry has name field
        if "name" not in entry_data:
            entry_data = {**entry_data, "name": entry_name}

        merged, added, skipped = merge_entry(merged, entry_data, overwrite)
        total_added += added
        total_skipped += skipped

    return merged, total_added, total_skipped


def validate_against_existing(
    scraped: Dict[str, Any],
    existing: Dict[str, Any],
    tolerance: float = 0.05
) -> Dict[str, Any]:
    """
    Validate scraped data against existing entries.

    Compares nutrition values and reports differences.

    Args:
        scraped: Scraped entry data
        existing: Existing database
        tolerance: Allowed difference as fraction (0.05 = 5%)

    Returns:
        Dict with match status, differences, and whether within tolerance
    """
    results = {"match": False, "differences": {}, "within_tolerance": True}

    entry_name = scraped.get("name", "")
    if entry_name not in existing:
        return results

    existing_entry = existing[entry_name]
    results["match"] = True

    # Compare nutrition values
    scraped_nutrition = scraped.get("nutrition_per_100g", {})
    existing_nutrition = existing_entry.get("nutrition_per_100g", {})

    for field in ["calories", "proteins", "carbs", "fats"]:
        scraped_val = scraped_nutrition.get(field, 0)
        existing_val = existing_nutrition.get(field, 0)

        if existing_val > 0:
            diff_pct = abs(scraped_val - existing_val) / existing_val
            if diff_pct > tolerance:
                results["within_tolerance"] = False
            results["differences"][field] = {
                "scraped": scraped_val,
                "existing": existing_val,
                "diff_pct": round(diff_pct * 100, 1),
            }

    return results
