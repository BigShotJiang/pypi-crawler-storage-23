"""Visualization functions for food log data."""

from typing import Any, Dict

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures

from ..config import PATHS


def plot_calories(
    date_messages_map: Dict[str, Any],
    output_path: str | None = None
) -> None:
    """
    Generate a polynomial regression plot of calorie trends.

    Args:
        date_messages_map: The date messages map with calorie data
        output_path: Path to save the plot. If None, uses PATHS['plot']
    """
    calories_map = {
        date: data["total"]
        for date, data in date_messages_map.items()
        if "total" in data
    }
    if not calories_map:
        return

    # Create DataFrame and prepare data
    data = pd.DataFrame(list(calories_map.items()), columns=['date', 'calories'])
    data['date'] = pd.to_datetime(data['date'])
    data.sort_values(by='date', inplace=True)
    x = data['date'].apply(lambda x: x.toordinal()).values.reshape(-1, 1)
    y = data['calories'].values

    # Polynomial regression
    x_poly = PolynomialFeatures(degree=2).fit_transform(x)
    y_pred = LinearRegression().fit(x_poly, y).predict(x_poly)
    r_squared = 1 - (np.sum((y - y_pred) ** 2) / np.sum((y - np.mean(y)) ** 2))

    # Plot
    plt.figure(figsize=(10, 6))
    plt.plot(data['date'], y, marker='o', linestyle='-', label='Actual Calories')
    plt.plot(data['date'], y_pred, color='red', linestyle='--', label='Regression Line')
    plt.xlabel('Date')
    plt.ylabel('Calories')
    plt.title(f'Calories Intake Over Time (R-squared = {r_squared:.2f})')
    plt.legend()
    plt.grid(True)
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(output_path or PATHS['plot'])
    plt.close()
