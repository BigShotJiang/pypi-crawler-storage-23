"""Visualization modules for food log data."""

from .plots import plot_calories

__all__ = ["plot_calories"]
