"""Profile configuration for multi-user support."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml


@dataclass
class ProfileConfig:
    """Configuration for a user profile."""

    name: str
    sender_name: str
    data_path: str

    # Optional settings with defaults
    start_date: str = "2023-08-30"
    target_calories: int = 2000
    blacklisted_ids: List[int] = field(default_factory=list)
    rewrite_id_dates: Dict[int, str] = field(default_factory=dict)

    @classmethod
    def from_file(cls, path: Path) -> "ProfileConfig":
        """Load a profile from a YAML file.

        Args:
            path: Path to the YAML profile file.

        Returns:
            ProfileConfig instance.

        Raises:
            FileNotFoundError: If the file doesn't exist.
            ValueError: If required fields are missing.
        """
        if not path.exists():
            raise FileNotFoundError(f"Profile not found: {path}")

        with open(path, "r") as f:
            data = yaml.safe_load(f)

        if not data:
            raise ValueError(f"Empty profile file: {path}")

        # Validate required fields
        required = ["name", "sender_name", "data_path"]
        missing = [f for f in required if f not in data]
        if missing:
            raise ValueError(f"Missing required fields in profile: {missing}")

        return cls(
            name=data["name"],
            sender_name=data["sender_name"],
            data_path=data["data_path"],
            start_date=data.get("start_date", "2023-08-30"),
            target_calories=data.get("target_calories", 2000),
            blacklisted_ids=data.get("blacklisted_ids", []),
            rewrite_id_dates={
                int(k): v for k, v in data.get("rewrite_id_dates", {}).items()
            },
        )

    @property
    def start_date_dt(self) -> datetime:
        """Get start_date as a datetime object."""
        return datetime.strptime(self.start_date, "%Y-%m-%d")

    @property
    def paths(self) -> Dict[str, str]:
        """Get resolved file paths for this profile.

        Returns:
            Dictionary with paths for input, messages, and plot files.
        """
        data_path = Path(self.data_path)
        # Create data directory if it doesn't exist
        data_path.mkdir(parents=True, exist_ok=True)

        return {
            "food_database": "food_database.json",  # Shared globally
            "input": str(data_path / "result.json"),
            "messages": str(data_path / "date_messages_map.json"),
            "plot": str(data_path / "plot.png"),
        }

    def to_runtime_config(self) -> Dict[str, Any]:
        """Convert profile to runtime config dictionary.

        Returns:
            Dictionary with all configuration values needed at runtime.
        """
        return {
            "name": self.name,
            "sender_name": self.sender_name,
            "data_path": self.data_path,
            "start_date": self.start_date_dt,
            "target_calories": self.target_calories,
            "blacklisted_ids": self.blacklisted_ids,
            "rewrite_id_dates": self.rewrite_id_dates,
            "paths": self.paths,
        }


def get_profiles_dir() -> Path:
    """Get the profiles directory path."""
    return Path(__file__).parent.parent / "profiles"


def list_profiles() -> List[str]:
    """List available profile names.

    Excludes files starting with '_' (templates).

    Returns:
        List of profile names (without .yaml extension).
    """
    profiles_dir = get_profiles_dir()
    if not profiles_dir.exists():
        return []

    profiles = []
    for f in profiles_dir.glob("*.yaml"):
        if not f.name.startswith("_"):
            profiles.append(f.stem)
    return sorted(profiles)


def load_profile(name: str) -> ProfileConfig:
    """Load a profile by name.

    Args:
        name: Profile name (without .yaml extension).

    Returns:
        ProfileConfig instance.

    Raises:
        FileNotFoundError: If the profile doesn't exist.
    """
    profiles_dir = get_profiles_dir()
    path = profiles_dir / f"{name}.yaml"
    return ProfileConfig.from_file(path)
