"""Self-consistency checking for food extraction accuracy."""

import json
import logging
from dataclasses import dataclass, field
from difflib import SequenceMatcher, get_close_matches
from typing import Any, Dict, List, Optional, Tuple

from ..config import STANDARD_UNITS
from ..models import ExtractionConfidence, FoodEntry
from ..processing.nutrition import NutritionCalculator
from ..utils import parse_json_response
from .extractor import FoodDataExtractor
from .prompts import create_verification_prompt

logger = logging.getLogger(__name__)


@dataclass
class ConsistencyStats:
    """Statistics from consistency checking."""

    single_pass_count: int = 0
    multi_pass_count: int = 0
    conflicts_resolved: int = 0
    total_entries: int = 0
    uncertain_remaining: int = 0
    verification_improvements: int = 0

    def __str__(self) -> str:
        return (
            f"Consistency Stats: single_pass={self.single_pass_count}, "
            f"multi_pass={self.multi_pass_count}, conflicts={self.conflicts_resolved}, "
            f"improvements={self.verification_improvements}"
        )


@dataclass
class ExtractionResult:
    """Result from consistency-checked extraction."""

    entries: List[FoodEntry] = field(default_factory=list)
    passes_used: int = 1
    conflicts_resolved: int = 0
    uncertain_count: int = 0
    success: bool = True
    error: Optional[str] = None


class ConsistencyChecker:
    """
    Selective self-consistency for uncertain extractions.

    This class implements an iterative refinement approach:
    1. First pass: Standard extraction with temp=0.0
    2. Score confidence for each entry based on database matching
    3. If all high-confidence: return immediately (1 API call)
    4. If uncertain entries: second pass with temp>0 for verification
    5. Resolve conflicts using database-anchored rules
    """

    def __init__(
        self,
        extractor: FoodDataExtractor,
        calculator: NutritionCalculator,
        confidence_threshold: float = 0.7,
        max_passes: int = 3,
        verification_temp: float = 0.3
    ):
        """
        Initialize the consistency checker.

        Args:
            extractor: FoodDataExtractor instance for LLM calls
            calculator: NutritionCalculator for database matching
            confidence_threshold: Minimum confidence to skip verification (0-1)
            max_passes: Maximum number of LLM calls per extraction
            verification_temp: Temperature for verification passes
        """
        self.extractor = extractor
        self.calculator = calculator
        self.confidence_threshold = confidence_threshold
        self.max_passes = max_passes
        self.verification_temp = verification_temp
        self.stats = ConsistencyStats()

    def reset_stats(self) -> None:
        """Reset statistics for a new processing run."""
        self.stats = ConsistencyStats()

    def extract_with_consistency(
        self,
        text: str,
        available_foods: str
    ) -> ExtractionResult:
        """
        Extract food entries with selective consistency checking.

        Args:
            text: The input text to parse (Portuguese food log)
            available_foods: Newline-separated list of available food names

        Returns:
            ExtractionResult with entries and metadata
        """
        # First pass - standard extraction with temp=0.0
        entries_v1, success = self.extractor.extract_food_data(text, available_foods)

        if not success:
            self.stats.single_pass_count += 1
            return ExtractionResult(
                entries=[],
                passes_used=1,
                success=False,
                error='extraction_failed'
            )

        if not entries_v1:
            self.stats.single_pass_count += 1
            return ExtractionResult(
                entries=[],
                passes_used=1,
                success=True
            )

        # Score confidence for each entry
        scored_entries = self._score_entries(entries_v1)
        self.stats.total_entries += len(scored_entries)

        # Check if any entries need verification
        uncertain_entries = [
            e for e in scored_entries
            if e.confidence and e.confidence.needs_verification
        ]

        if not uncertain_entries:
            # All entries are high-confidence - return as-is
            for entry in scored_entries:
                entry.verification_status = 'single_pass'
            self.stats.single_pass_count += 1
            return ExtractionResult(
                entries=scored_entries,
                passes_used=1,
                success=True
            )

        # Second pass - verify uncertain entries
        logger.info(
            f"Found {len(uncertain_entries)} uncertain entries, "
            "running verification pass"
        )

        entries_v2 = self._extract_with_verification(
            text,
            available_foods,
            entries_v1,
            uncertain_entries
        )

        if entries_v2 is None:
            # Verification failed, use first pass results
            for entry in scored_entries:
                entry.verification_status = 'single_pass'
            self.stats.multi_pass_count += 1
            return ExtractionResult(
                entries=scored_entries,
                passes_used=2,
                uncertain_count=len(uncertain_entries),
                success=True
            )

        # Resolve discrepancies
        final_entries, conflicts = self._resolve_entries(
            scored_entries, entries_v2, uncertain_entries
        )

        self.stats.multi_pass_count += 1
        self.stats.conflicts_resolved += conflicts
        self.stats.uncertain_remaining += sum(
            1 for e in final_entries
            if e.confidence and e.confidence.overall < self.confidence_threshold
        )

        return ExtractionResult(
            entries=final_entries,
            passes_used=2,
            conflicts_resolved=conflicts,
            uncertain_count=len(uncertain_entries),
            success=True
        )

    def _score_entries(self, entries: List[FoodEntry]) -> List[FoodEntry]:
        """
        Score confidence for each entry based on database matching.

        Args:
            entries: List of extracted food entries

        Returns:
            Same entries with confidence scores populated
        """
        for entry in entries:
            ingredient_score = self._score_ingredient(entry.ingredient)
            unit_score = self._score_unit(entry.unit)
            quantity_score = self._score_quantity(entry.quantity)

            entry.confidence = ExtractionConfidence(
                ingredient_score=ingredient_score,
                unit_score=unit_score,
                quantity_score=quantity_score
            )

        return entries

    def _score_ingredient(self, ingredient: str) -> float:
        """Score how well an ingredient matches the database."""
        ingredient_lower = ingredient.lower().strip()

        # Check for exact match
        if ingredient_lower in self.calculator.food_lookup:
            return 1.0

        # Check for fuzzy match
        matches = get_close_matches(
            ingredient_lower,
            list(self.calculator.food_lookup.keys()),
            n=1,
            cutoff=0.8
        )

        if matches:
            # Fuzzy match - return the similarity ratio
            ratio = SequenceMatcher(
                None, ingredient_lower, matches[0]
            ).ratio()
            return max(0.6, ratio)  # At least 0.6 for fuzzy matches

        # No match found
        return 0.3

    def _score_unit(self, unit: str) -> float:
        """Score confidence in unit interpretation."""
        unit_lower = unit.lower().strip()

        if unit_lower in STANDARD_UNITS:
            return 1.0

        # Common Portuguese variants that are clear
        clear_variants = {
            'colher de sopa', 'csopa', 'cs',
            'colher de cha', 'ccha', 'cc',
            'copo', 'tigela',
            'unidade', 'fatia', 'lata',
            'gramas', 'grama'
        }
        if unit_lower in clear_variants:
            return 0.9

        # Unknown unit
        return 0.5

    def _score_quantity(self, quantity: float) -> float:
        """Score confidence in quantity parsing."""
        # Check if it's a clean number
        if quantity == int(quantity):
            return 1.0

        # Check for common fractions
        common_fractions = {0.25, 0.5, 0.75, 1.5, 2.5}
        if quantity in common_fractions:
            return 1.0

        # Unusual decimals might indicate parsing issues
        if quantity < 0.1 or quantity > 100:
            return 0.6

        return 0.8

    def _extract_with_verification(
        self,
        original_text: str,
        available_foods: str,
        first_extraction: List[FoodEntry],
        uncertain_entries: List[FoodEntry]
    ) -> Optional[List[FoodEntry]]:
        """
        Run a verification pass for uncertain entries.

        Args:
            original_text: The original input text
            available_foods: Available food names
            first_extraction: Results from first extraction
            uncertain_entries: Entries that need verification

        Returns:
            New list of entries, or None if verification failed
        """
        # Create JSON of first extraction
        first_json = json.dumps(
            [
                {
                    'ingredient': e.ingredient,
                    'quantity': e.quantity,
                    'unit': e.unit
                }
                for e in first_extraction
            ],
            ensure_ascii=False,
            indent=2
        )

        uncertain_items = [e.ingredient for e in uncertain_entries]

        # Create verification prompt
        verification_prompt = create_verification_prompt(
            available_foods,
            first_json,
            uncertain_items
        )

        try:
            # Use higher temperature for verification
            original_temp = self.extractor.temp
            self.extractor.temp = self.verification_temp

            response = self.extractor.client.chat.completions.create(
                model=self.extractor.model,
                messages=[
                    {"role": "system", "content": verification_prompt},
                    {"role": "user", "content": original_text}
                ],
                temperature=self.verification_temp
            ).choices[0].message.content.strip()

            self.extractor.temp = original_temp

            # Parse response
            result = parse_json_response(response, array=True)
            if result is None:
                logger.warning("Verification pass returned no valid JSON")
                return None

            # Convert to FoodEntry objects
            entries = []
            for item in result:
                try:
                    item.setdefault('calories', 0)
                    item.update({
                        k: str(item.get(k, '')).strip().lower()
                        for k in ('unit', 'ingredient')
                    })
                    item['quantity'] = float(item.get('quantity', 0))
                    entries.append(FoodEntry(**item))
                except Exception as e:
                    logger.warning(f"Failed to validate verification entry {item}: {e}")

            return entries

        except Exception as e:
            logger.error(f"Verification extraction failed: {e}")
            return None

    def _resolve_entries(
        self,
        entries_v1: List[FoodEntry],
        entries_v2: List[FoodEntry],
        uncertain: List[FoodEntry]
    ) -> Tuple[List[FoodEntry], int]:
        """
        Resolve discrepancies between two extraction passes.

        Args:
            entries_v1: First pass entries (with confidence scores)
            entries_v2: Verification pass entries
            uncertain: Entries that were flagged as uncertain

        Returns:
            Tuple of (resolved entries, number of conflicts resolved)
        """
        conflicts = 0
        resolved = []
        uncertain_ingredients = {e.ingredient.lower() for e in uncertain}

        # Build lookup by ingredient for v2
        v2_map: Dict[str, FoodEntry] = {}
        for e in entries_v2:
            key = e.ingredient.lower()
            v2_map[key] = e

        for entry in entries_v1:
            key = entry.ingredient.lower()

            # If this entry wasn't uncertain, keep it as-is
            if key not in uncertain_ingredients:
                entry.verification_status = 'single_pass'
                resolved.append(entry)
                continue

            # Look for corresponding entry in v2
            v2_entry = v2_map.get(key)

            if v2_entry is None:
                # Entry disappeared in v2 - check if it was renamed
                # For now, keep the original
                entry.verification_status = 'single_pass'
                resolved.append(entry)
                continue

            # Compare entries
            if self._entries_match(entry, v2_entry):
                # Consensus - both passes agree
                entry.verification_status = 'verified'
                resolved.append(entry)
            else:
                # Conflict - need to resolve
                winner, reason = self._pick_winner(entry, v2_entry)
                winner.verification_status = 'conflict_resolved'
                resolved.append(winner)
                conflicts += 1
                self.stats.verification_improvements += 1
                logger.info(
                    f"Resolved conflict for '{key}': chose {reason} "
                    f"(v1: {entry.quantity} {entry.unit}, "
                    f"v2: {v2_entry.quantity} {v2_entry.unit})"
                )

        # Check for new entries in v2 that weren't in v1
        v1_ingredients = {e.ingredient.lower() for e in entries_v1}
        for v2_entry in entries_v2:
            key = v2_entry.ingredient.lower()
            if key not in v1_ingredients:
                # New entry found in verification - add it
                v2_entry.verification_status = 'verified'
                v2_entry.confidence = ExtractionConfidence(
                    ingredient_score=self._score_ingredient(v2_entry.ingredient),
                    unit_score=self._score_unit(v2_entry.unit),
                    quantity_score=self._score_quantity(v2_entry.quantity)
                )
                resolved.append(v2_entry)
                self.stats.verification_improvements += 1
                logger.info(f"Added new entry from verification: {v2_entry.ingredient}")

        return resolved, conflicts

    def _entries_match(self, e1: FoodEntry, e2: FoodEntry) -> bool:
        """Check if two entries are essentially the same."""
        # Same ingredient (already normalized)
        if e1.ingredient.lower() != e2.ingredient.lower():
            return False

        # Same unit
        if e1.unit.lower() != e2.unit.lower():
            return False

        # Quantity within 10%
        if e1.quantity == 0 or e2.quantity == 0:
            return e1.quantity == e2.quantity

        ratio = e1.quantity / e2.quantity
        return 0.9 <= ratio <= 1.1

    def _pick_winner(
        self,
        e1: FoodEntry,
        e2: FoodEntry
    ) -> Tuple[FoodEntry, str]:
        """
        Select the better extraction based on validation rules.

        Priority:
        1. Entry that matches database exactly
        2. Entry with valid unit mapping
        3. Default to first (temp=0.0) version

        Args:
            e1: First pass entry
            e2: Verification pass entry

        Returns:
            Tuple of (winner entry, reason string)
        """
        # Rule 1: Prefer exact database match
        match1 = self.calculator.match_ingredient(e1.ingredient)
        match2 = self.calculator.match_ingredient(e2.ingredient)

        if match1 and not match2:
            return e1, 'v1_database_match'
        if match2 and not match1:
            return e2, 'v2_database_match'

        # Rule 2: Prefer entry with valid unit in database
        if match1:
            food_data = self.calculator.database[match1]
            units = food_data.get('grams_per_unit', {})

            e1_has_unit = e1.unit.lower() in units or e1.unit.lower() == 'g'
            e2_has_unit = e2.unit.lower() in units or e2.unit.lower() == 'g'

            if e1_has_unit and not e2_has_unit:
                return e1, 'v1_valid_unit'
            if e2_has_unit and not e1_has_unit:
                return e2, 'v2_valid_unit'

        # Rule 3: Prefer standard unit
        e1_standard = e1.unit.lower() in STANDARD_UNITS
        e2_standard = e2.unit.lower() in STANDARD_UNITS

        if e1_standard and not e2_standard:
            return e1, 'v1_standard_unit'
        if e2_standard and not e1_standard:
            return e2, 'v2_standard_unit'

        # Rule 4: Default to first (temp=0.0) version
        return e1, 'default_v1'
