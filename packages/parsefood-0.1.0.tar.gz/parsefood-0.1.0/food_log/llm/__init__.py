"""LLM-related modules for food data extraction."""

from .client import create_openrouter_client
from .consistency import ConsistencyChecker, ConsistencyStats, ExtractionResult
from .extractor import FoodDataExtractor, parse_legacy_format
from .prompts import (
    create_food_extraction_prompt,
    create_verification_prompt,
    create_vision_prompt,
)

__all__ = [
    "create_openrouter_client",
    "FoodDataExtractor",
    "parse_legacy_format",
    "create_food_extraction_prompt",
    "create_verification_prompt",
    "create_vision_prompt",
    "ConsistencyChecker",
    "ConsistencyStats",
    "ExtractionResult",
]
