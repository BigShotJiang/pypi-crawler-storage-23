"""Food data extraction using LLM."""

import logging
from typing import Any, Dict, List, Optional, Tuple

from openai import OpenAI

from ..models import FoodEntry
from ..utils import parse_json_response
from .client import create_openrouter_client
from .prompts import create_food_extraction_prompt

logger = logging.getLogger(__name__)


class FoodDataExtractor:
    """Main class for extracting food data using LLM and Pydantic validation."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: Optional[str] = None,
        temp: float = 0.0
    ):
        """
        Initialize the food data extractor.

        Args:
            api_key: OpenRouter API key. If not provided, uses environment variable.
            model: Model ID to use. If not provided, uses MODEL_ID from environment.
            temp: Temperature for LLM generation.
        """
        from ..config import MODEL_ID

        self.client = create_openrouter_client(api_key)
        self.model = model or MODEL_ID
        self.temp = temp

        if not self.model:
            raise ValueError(
                "MODEL_ID not found. "
                "Please set it in your .env file or pass it explicitly."
            )

    def _extract_with_llm(
        self,
        text: str,
        available_foods: str
    ) -> Tuple[List[Dict[str, Any]], bool]:
        """
        Extract food data from text using LLM.

        Args:
            text: The input text to parse
            available_foods: Newline-separated list of available food names

        Returns:
            Tuple of (results, success_flag). success_flag is False if extraction failed.
        """
        messages = [
            {"role": "system", "content": create_food_extraction_prompt(available_foods)},
            {"role": "user", "content": text}
        ]

        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=self.temp
            ).choices[0].message.content.strip()

            # Extract JSON array from response
            result = parse_json_response(response, array=True)
            if result is not None:
                return result, True
            else:
                logger.warning(f"No JSON array found in LLM response: {response[:200]}...")
                return [], True  # No foods found, but extraction succeeded
        except Exception as e:
            logger.error(f"LLM extraction failed: {e}")
            return [], False  # Extraction failed

    def extract_food_data(
        self,
        text: str,
        available_foods: str
    ) -> Tuple[List[FoodEntry], bool]:
        """
        Extract food entries from text.

        Args:
            text: The input text to parse
            available_foods: Newline-separated list of available food names

        Returns:
            Tuple of (food_entries, success_flag). success_flag is False if LLM extraction failed.
        """
        raw_data, success = self._extract_with_llm(text, available_foods)
        food_entries = []

        for item in raw_data:
            try:
                item.setdefault('calories', 0)
                item.setdefault('unknown', False)
                item.update({
                    k: str(item.get(k, '')).strip().lower()
                    for k in ('unit', 'ingredient')
                })
                item['quantity'] = float(item.get('quantity', 0))
                food_entries.append(FoodEntry(**item))
            except Exception as e:
                logger.warning(f"Failed to validate food entry {item}: {e}")

        return food_entries, success


def parse_legacy_format(line: str) -> Optional[FoodEntry]:
    """
    Parse legacy format: ingredient;quantity;unit;calories

    Args:
        line: A semicolon-separated line in legacy format

    Returns:
        FoodEntry if parsing succeeds, None otherwise
    """
    try:
        parts = line.strip().split(';')
        if len(parts) != 4:
            return None

        ingredient, quantity, unit, calories = parts
        return FoodEntry(
            ingredient=ingredient.strip(),
            quantity=float(quantity),
            unit=unit.strip(),
            calories=int(round(float(calories)))
        )
    except Exception as e:
        logger.warning(f"Could not parse legacy format line '{line}': {e}")
        return None
