"""Prompt templates for LLM food extraction."""


def create_food_extraction_prompt(available_foods: str) -> str:
    """
    Create the prompt for extracting food data from Portuguese text.

    Args:
        available_foods: Newline-separated list of available food names

    Returns:
        System prompt string for food extraction
    """
    return f"""Extract food information from Portuguese text and return as JSON.

Your task is to:
1. Identify food items in the text
2. Match each food to one from the available foods list below
3. Extract the quantity for each food
4. Map the unit to one of the standard units

Available foods in the database:
{available_foods}

IMPORTANT: Try to match each food to one from the list above (use the closest match).
If a food is NOT in the list and cannot be reasonably matched, still include it with "unknown": true.
Never silently skip foods - always output every food item mentioned.

UNIT MAPPING - You must map any unit expression to one of these standard units:
- "tbsp" = tablespoon (colher de sopa, csopa, cs, tablespoon, etc.)
- "tsp" = teaspoon (colher de chá, colher de cha, ccha, cc, teaspoon, etc.)
- "cup" = cup (copo, tigela, cup, etc.)
- "unit" = unit/piece (unidade, fatia, lata, slice, piece, etc. - use this as default when no unit specified)
- "g" = grams (gramas, grama, g, etc.)

CRITICAL: Abbreviations "cs" and "csopa" ALWAYS mean "tbsp", and "cc" and "ccha" ALWAYS mean "tsp".

Examples of unit mapping:
- "2 colheres de sopa de arroz" → "tbsp"
- "1 cs arroz" → "tbsp"  (cs = colher de sopa = tablespoon)
- "1 cs espinafres com azeite" → espinafres: "tbsp", azeite: "tbsp"
- "1 copo de leite" → "cup"
- "3 bolachas" → "unit"
- "10 gramas de amendoa" → "g"

SPECIAL HANDLING FOR "COM" (WITH):
When a food is described as "com X" (with X), where X is a condiment or topping like olive oil, butter, etc., treat as TWO separate items:
- "1 cs espinafres com azeite" → espinafres: 1 tbsp (preserve the "cs" as "tbsp"), azeite: 0.5 tbsp
- "pao com manteiga" → bread gets its original quantity/unit, butter gets 0.5 tsp
- For oils/fats added with "com", ALWAYS use "tbsp" unit (never "unit")
- Default to 0.5 tbsp for oils and 0.5 tsp for butter/spreads unless explicitly stated otherwise

Return JSON array with this exact format:
[{{"ingredient": "food_name", "quantity": number, "unit": "standard_unit", "unknown": false}}]

Set "unknown": true only for foods that don't match any item in the available foods list.
DO NOT include calories - those will be calculated automatically.
Return ONLY the JSON array, nothing else."""


def create_vision_prompt() -> str:
    """
    Create the prompt for the vision model to extract nutrition data from labels.

    Returns:
        Prompt string for vision-based nutrition extraction
    """
    return """Analyze the nutrition label(s) in the provided image(s) and extract comprehensive nutritional information.

Your task:
1. Identify the product name
2. Extract nutritional values per 100g
3. Identify all relevant serving sizes (per unit, per package, per bag, etc.)
4. Generate a SINGLE database entry with ALL measurement units

IMPORTANT REQUIREMENTS:

1. Product name should be in Portuguese, lowercase, descriptive
2. Include ALL useful measurement units in the grams_per_unit field:
   - "unit": grams per individual item (e.g., 1 bar, 1 cookie, 1 piece)
   - "package": grams per package (if multiple units per package)
   - "tbsp": tablespoon (if applicable - for spreads, powders, etc.)
   - "tsp": teaspoon (if applicable - for spreads, powders, etc.)
   - "cup": cup (if applicable - for liquids, cereals, etc.)
   - "g": always 1 (for gram-based measurements)

3. For nutrition_per_100g, extract:
   - calories (kcal, as integer)
   - proteins (g, as float)
   - carbs (g, as float)
   - fats (g, as float)
   - sodium (g, as float, optional)

EXAMPLE OUTPUT FORMAT:

For a package of granola bars (2 bars per package, 21g each bar, 42g total package):

```json
{
  "barra de cereais nature valley de aveia e mel": {
    "name": "barra de cereais nature valley de aveia e mel",
    "grams_per_unit": {
      "unit": 21,
      "package": 42,
      "g": 1
    },
    "nutrition_per_100g": {
      "calories": 467,
      "proteins": 7.0,
      "carbs": 65.0,
      "fats": 18.0
    }
  }
}
```

For a jar of peanut butter (350g total):

```json
{
  "manteiga de amendoim": {
    "name": "manteiga de amendoim",
    "grams_per_unit": {
      "tbsp": 16,
      "tsp": 5,
      "g": 1
    },
    "nutrition_per_100g": {
      "calories": 588,
      "proteins": 25.0,
      "carbs": 20.0,
      "fats": 50.0
    }
  }
}
```

CRITICAL:
- Return ONLY valid JSON matching the exact schema above
- Use Portuguese names
- Create ONE entry per food product with ALL units in grams_per_unit
- DO NOT create separate entries for different unit types
- Include all decimal places for nutritional values
- Calculate per-100g values if only per-serving is shown
- The top-level keys should be the same as the "name" field inside each entry

Return the JSON object now:"""


def create_nutrition_extraction_prompt() -> str:
    """
    Create the prompt for extracting nutrition data from scraped web text.

    Returns:
        System prompt string for nutrition extraction from raw text
    """
    return """Extract nutritional information per 100g from the following text.

CRITICAL REQUIREMENTS:
1. Extract ONLY values per 100g (not per serving, not per portion)
2. If multiple tables exist (e.g., "per 100g" AND "per 100ml"), use ONLY the per 100g values
3. IMPORTANT: Some sites mislabel solid foods as "per 100ml" or "Mililitro". If the nutritional profile clearly indicates solid food (e.g., >200 kcal, significant carbs/protein/fat), extract the values anyway - treat it as per 100g
4. Only return null for ALL fields if it's clearly a liquid beverage (e.g., water, juice with <100 kcal)

VALUE CONVERSIONS:
- If calories are only in kJ (quilojoules): convert to kcal by dividing by 4.184
- If salt (sal) is given instead of sodium (sódio): convert to sodium by dividing by 2.5
- Handle Portuguese decimal format: comma as decimal separator (e.g., "12,5" = 12.5)

OUTPUT FORMAT (JSON object with these exact fields):
{
  "calories": <integer in kcal, or null if not found>,
  "proteins": <float in grams, or null if not found>,
  "carbs": <float in grams, or null if not found>,
  "fats": <float in grams, or null if not found>,
  "fiber": <float in grams, or null if not available>,
  "sodium": <float in grams, or null if not available>
}

FIELD MAPPINGS (Portuguese to English):
- "Energia" with "quilocaloria" or "kcal" → calories
- "Energia" with "quilojoule" or "kJ" → convert to calories (kJ / 4.184)
- "Proteína" or "Proteínas" → proteins
- "Hidratos de carbono" (main row, NOT the "açúcares" subrow) → carbs
- "Lípidos" (main row, NOT "saturados" or "dos quais saturados" subrow) → fats
- "Fibra" → fiber
- "Sal" → sodium (divide by 2.5)
- "Sódio" → sodium (use directly)

IMPORTANT:
- Return ONLY the JSON object, no explanations or markdown
- All numeric values should be numbers (not strings)
- Use null (not 0) for missing optional fields (fiber, sodium)
- Use null for ALL fields if only per 100ml data is available"""


def create_verification_prompt(
    available_foods: str,
    previous_extraction: str,
    uncertain_items: list[str]
) -> str:
    """
    Create prompt for verifying uncertain extractions.

    Args:
        available_foods: Newline-separated list of available food names
        previous_extraction: JSON string of the previous extraction
        uncertain_items: List of ingredient names that need verification

    Returns:
        System prompt string for verification
    """
    uncertain_list = "\n".join(f"- {item}" for item in uncertain_items)

    return f"""You are verifying a food log extraction. A previous extraction was done but some items need verification.

Previous extraction (may have errors):
{previous_extraction}

Items that need careful verification:
{uncertain_list}

Available foods in database:
{available_foods}

VERIFICATION TASKS:
1. Check if each ingredient name EXACTLY matches one from the available foods list
2. Verify quantities are correct (watch for ranges like "2-3" which should be averaged)
3. Verify units are correct:
   - "cs" / "csopa" / "colher de sopa" = "tbsp"
   - "cc" / "ccha" / "colher de cha" = "tsp"
   - "copo" / "tigela" = "cup"
   - "unidade" / "fatia" / "lata" = "unit"
   - "g" / "gramas" = "g"
4. Check if any foods from the original text were MISSED in the extraction
5. Check if "com" (with) patterns were correctly split into separate items

Return the CORRECTED JSON array. Only change items that are clearly wrong.
Keep items that are correct even if not in the uncertain list.

Format: [{{"ingredient": "food_name", "quantity": number, "unit": "standard_unit"}}]

Return ONLY the JSON array, nothing else."""
