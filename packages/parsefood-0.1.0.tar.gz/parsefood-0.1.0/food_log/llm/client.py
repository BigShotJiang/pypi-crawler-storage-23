"""OpenAI client factory for OpenRouter API."""

import os
from typing import Optional

from openai import OpenAI

from ..config import OPENROUTER_API_KEY, OPENROUTER_BASE_URL


def create_openrouter_client(api_key: Optional[str] = None) -> OpenAI:
    """
    Create an OpenAI client configured for OpenRouter.

    Args:
        api_key: Optional API key. If not provided, uses OPENROUTER_API_KEY from env.

    Returns:
        Configured OpenAI client

    Raises:
        ValueError: If no API key is available
    """
    key = api_key or OPENROUTER_API_KEY
    if not key:
        raise ValueError(
            "OPENROUTER_API_KEY not found. "
            "Please set it in your .env file or pass it explicitly."
        )

    return OpenAI(
        base_url=OPENROUTER_BASE_URL,
        api_key=key
    )


