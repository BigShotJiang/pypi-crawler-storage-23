"""Pydantic models for the food log parser."""

import logging
import re
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field, field_validator, model_validator

from .utils import normalize_name

logger = logging.getLogger(__name__)


class ExtractionConfidence(BaseModel):
    """Confidence metadata for a food extraction."""

    ingredient_score: float = Field(
        default=1.0, ge=0, le=1,
        description="How well ingredient matches database (1.0=exact, 0.8=fuzzy, 0.3=no match)"
    )
    unit_score: float = Field(
        default=1.0, ge=0, le=1,
        description="Confidence in unit interpretation (1.0=standard, 0.8=variant, 0.5=unknown)"
    )
    quantity_score: float = Field(
        default=1.0, ge=0, le=1,
        description="Confidence in quantity parsing (1.0=clean number, 0.6=ambiguous)"
    )
    overall: float = Field(
        default=1.0, ge=0, le=1,
        description="Weighted average confidence"
    )

    @model_validator(mode='after')
    def calculate_overall(self) -> 'ExtractionConfidence':
        """Calculate overall confidence as weighted average."""
        # Ingredient match is most important (50%), then unit (30%), then quantity (20%)
        self.overall = (
            self.ingredient_score * 0.5 +
            self.unit_score * 0.3 +
            self.quantity_score * 0.2
        )
        return self

    @property
    def needs_verification(self) -> bool:
        """Check if this extraction needs a second pass."""
        return self.overall < 0.7


class FoodEntry(BaseModel):
    """Model for a single food entry with validation."""

    ingredient: str = Field(..., description="The food ingredient name")
    quantity: float = Field(..., gt=0, description="The quantity (must be positive)")
    unit: str = Field(..., description="The unit of measurement")
    calories: int = Field(default=0, ge=0, description="The calories (must be non-negative)")
    unknown: bool = Field(default=False, description="True if food not in database")

    # Nutrition tracking fields
    matched_food_id: Optional[str] = Field(
        default=None, description="Matched food ID from database"
    )
    grams: Optional[float] = Field(default=None, description="Total grams")
    proteins: Optional[float] = Field(default=None, description="Protein in grams")
    carbs: Optional[float] = Field(default=None, description="Carbohydrates in grams")
    fats: Optional[float] = Field(default=None, description="Fats in grams")
    fiber: Optional[float] = Field(default=None, description="Fiber in grams")

    # Calculation status tracking
    calculation_status: Optional[str] = Field(
        default=None, description="Status: 'success', 'no_match', 'missing_unit'"
    )

    # Confidence tracking for self-consistency
    confidence: Optional[ExtractionConfidence] = Field(
        default=None, description="Extraction confidence scores"
    )
    verification_status: Optional[str] = Field(
        default=None,
        description="Status: 'single_pass', 'verified', 'conflict_resolved'"
    )

    @field_validator('ingredient', 'unit')
    @classmethod
    def normalize_string_fields(cls, v: str) -> Optional[str]:
        return normalize_name(v)

    @model_validator(mode='after')
    def validate_quantity_range(self) -> 'FoodEntry':
        """Warn about suspiciously large quantities that might be typos."""
        # For grams, large quantities (up to 500g) are normal
        # For other units (tbsp, cup, unit), >20 is suspicious
        if self.unit == 'g':
            if self.quantity > 500:
                logger.warning(
                    f"Unusually large gram quantity: {self.quantity}g of "
                    f"{self.ingredient} - verify this is correct"
                )
        elif self.quantity > 20:
            logger.warning(
                f"Unusually large quantity: {self.quantity} {self.unit} of "
                f"{self.ingredient} - possible typo?"
            )
        return self


class FoodLogEntry(BaseModel):
    """Model for a complete food log entry containing multiple food items."""

    date: str = Field(..., description="The date of the log entry (YYYY-MM-DD)")
    raw_text: str = Field(..., description="The original raw text")
    foods: List[FoodEntry] = Field(
        default_factory=list, description="List of extracted food entries"
    )
    total_calories: int = Field(default=0, description="Total calories for the day")

    # Total nutrition tracking
    total_proteins: Optional[float] = Field(
        default=None, description="Total proteins for the day"
    )
    total_carbs: Optional[float] = Field(
        default=None, description="Total carbs for the day"
    )
    total_fats: Optional[float] = Field(
        default=None, description="Total fats for the day"
    )
    total_fiber: Optional[float] = Field(
        default=None, description="Total fiber for the day"
    )

    @field_validator('date')
    @classmethod
    def validate_date(cls, v: str) -> str:
        if not re.match(r'\d{4}-\d{2}-\d{2}', v):
            raise ValueError("Date must be in YYYY-MM-DD format")
        return v

    @model_validator(mode='after')
    def calculate_totals(self) -> 'FoodLogEntry':
        """Auto-calculate totals from food entries."""
        self.total_calories = sum(food.calories for food in self.foods)

        # Calculate macro totals if available
        for field in ('proteins', 'carbs', 'fats', 'fiber'):
            values = [
                getattr(f, field)
                for f in self.foods
                if getattr(f, field) is not None
            ]
            setattr(
                self,
                f'total_{field}',
                round(sum(values), 1) if values else None
            )

        return self


class NutritionPer100g(BaseModel):
    """Nutrition information per 100g."""

    calories: int = Field(..., ge=0, description="Calories per 100g")
    proteins: float = Field(..., ge=0, description="Proteins per 100g in grams")
    carbs: float = Field(..., ge=0, description="Carbohydrates per 100g in grams")
    fats: float = Field(..., ge=0, description="Fats per 100g in grams")
    fiber: Optional[float] = Field(default=None, ge=0, description="Fiber per 100g in grams")
    sodium: Optional[float] = Field(default=None, ge=0, description="Sodium per 100g in grams")


class FoodDatabaseEntry(BaseModel):
    """Schema for an entry in food_database.json."""

    name: str = Field(..., description="Food name (lowercase)")
    url: Optional[str] = Field(default=None, description="Source URL for the food data")
    grams_per_unit: Dict[str, float] = Field(
        default_factory=lambda: {"g": 1},
        description="Mapping of unit names to grams per unit"
    )
    nutrition_per_100g: NutritionPer100g = Field(
        ..., description="Nutrition information per 100g"
    )

    @field_validator('name')
    @classmethod
    def normalize_food_name(cls, v: str) -> str:
        return v.strip().lower()


class NutritionResult(BaseModel):
    """Result from nutrition calculation."""

    calories: Optional[int] = Field(default=None, description="Calculated calories")
    proteins: Optional[float] = Field(default=None, description="Calculated proteins")
    carbs: Optional[float] = Field(default=None, description="Calculated carbohydrates")
    fats: Optional[float] = Field(default=None, description="Calculated fats")
    grams: Optional[float] = Field(default=None, description="Total grams")
    matched_food_id: Optional[str] = Field(
        default=None, description="Matched food ID from database"
    )
