"""Food Log Parser - A tool for parsing and analyzing food logs."""

__version__ = "0.1.0"

from .config import (
    BLACKLISTED_IDS,
    DATA_PATH,
    FOOD_DATABASE_PATH,
    MODEL_ID,
    OPENROUTER_API_KEY,
    OPENROUTER_BASE_URL,
    PATHS,
    REWRITE_ID_DATES,
    START_DATE,
    STANDARD_UNITS,
    TARGET_CALORIES,
    UNIT_MAP,
    get_runtime_config,
)
from .profile import ProfileConfig, list_profiles, load_profile
from .database import (
    create_backup,
    load_database,
    load_json,
    merge_entries,
    merge_entry,
    save_database,
    save_json,
    validate_against_existing,
)
from .models import (
    FoodDatabaseEntry,
    FoodEntry,
    FoodLogEntry,
    NutritionPer100g,
    NutritionResult,
)
from .utils import (
    extract_json_from_response,
    format_quantity,
    normalize_name,
    normalize_unit,
    parse_json_response,
    run_tasks,
)

__all__ = [
    "__version__",
    # Config
    "BLACKLISTED_IDS",
    "DATA_PATH",
    "FOOD_DATABASE_PATH",
    "MODEL_ID",
    "OPENROUTER_API_KEY",
    "OPENROUTER_BASE_URL",
    "PATHS",
    "REWRITE_ID_DATES",
    "START_DATE",
    "STANDARD_UNITS",
    "TARGET_CALORIES",
    "UNIT_MAP",
    "get_runtime_config",
    # Profile
    "ProfileConfig",
    "list_profiles",
    "load_profile",
    # Database
    "create_backup",
    "load_database",
    "load_json",
    "merge_entries",
    "merge_entry",
    "save_database",
    "save_json",
    "validate_against_existing",
    # Models
    "FoodDatabaseEntry",
    "FoodEntry",
    "FoodLogEntry",
    "NutritionPer100g",
    "NutritionResult",
    # Utils
    "extract_json_from_response",
    "format_quantity",
    "normalize_name",
    "normalize_unit",
    "parse_json_response",
    "run_tasks",
]
