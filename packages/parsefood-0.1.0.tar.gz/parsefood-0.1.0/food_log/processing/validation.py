"""Validation functions for food log data."""

import logging
from typing import Any, Dict, Optional

from ..llm.extractor import parse_legacy_format
from ..models import FoodLogEntry

logger = logging.getLogger(__name__)


def print_validation_summary(date_messages_map: Dict[str, Any]) -> None:
    """
    Validate and print a summary report of food log data using the legacy format.

    Args:
        date_messages_map: The date messages map to validate
    """
    total = len(date_messages_map)
    valid = 0
    invalid = 0
    missing_processed = 0
    errors = []
    unit_dist = {}
    cal_values = []

    for date, data in date_messages_map.items():
        if 'processed' not in data:
            missing_processed += 1
            continue

        try:
            entries = []
            for line in data['processed']:
                entry = parse_legacy_format(line)
                if entry:
                    entries.append(entry)
                    unit_dist[entry.unit] = unit_dist.get(entry.unit, 0) + 1

            total_cal = data.get('total', sum(e.calories for e in entries))
            cal_values.append(total_cal)
            valid += 1
        except Exception as e:
            invalid += 1
            errors.append({'date': date, 'error': str(e)})

    print(f"{'=' * 60}\nFOOD LOG DATA VALIDATION REPORT\n{'=' * 60}")
    print(f"Total entries: {total}")
    print(f"Valid entries: {valid}")
    print(f"Invalid entries: {invalid}")
    print(f"Missing processed data: {missing_processed}\n")

    if errors:
        print("VALIDATION ERRORS:")
        for error in errors:
            print(f"  {error['date']}: {error['error']}")
        print()

    print("UNIT DISTRIBUTION:")
    for unit, count in sorted(unit_dist.items()):
        print(f"  {unit}: {count}")

    if cal_values:
        print(f"\nCALORIE STATISTICS:\n  Min daily calories: {min(cal_values)}")
        print(f"  Max daily calories: {max(cal_values)}")
        print(f"  Average daily calories: {sum(cal_values) / len(cal_values):.1f}")
        print(f"  Total calories: {sum(cal_values)}\n")


def inspect_date_entries(date_messages_map: Dict[str, Any], date: str) -> None:
    """
    Inspect entries for a specific date.

    Args:
        date_messages_map: The date messages map
        date: The date to inspect (YYYY-MM-DD format)
    """
    if date not in date_messages_map:
        print(f"No data found for date: {date}")
        return

    data = date_messages_map[date]
    print(f"{'=' * 60}\nINSPECTION FOR DATE: {date}\n{'=' * 60}\nORIGINAL MESSAGES:")
    for i, msg in enumerate(data.get('original', []), 1):
        print(f"  {i}: {msg}")

    if 'processed' in data:
        print("\nPROCESSED MESSAGES:")
        for i, msg in enumerate(data['processed'], 1):
            print(f"  {i}: {msg}")

    if 'structured_data' in data:
        print("\nSTRUCTURED DATA:")
        try:
            entry = FoodLogEntry(**data['structured_data'])
            print(f"  Date: {entry.date}\n  Total calories: {entry.total_calories}")
            print(f"  Number of foods: {len(entry.foods)}\n  Foods:")
            for i, food in enumerate(entry.foods, 1):
                print(f"    {i}: {food.ingredient} - {food.quantity} {food.unit} - {food.calories} cal")
        except Exception as e:
            print(f"  ERROR: Invalid structured data: {e}")
    else:
        print("\nNo structured data available")
    print()


def validate_and_migrate_existing_data(
    date_messages_map: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Validate existing processed data and migrate to new format where possible.

    Note: This function validates but does not store structured_data field.

    Args:
        date_messages_map: The date messages map to validate

    Returns:
        The same date_messages_map (possibly with validation logs)
    """
    migrated_count = 0

    for date, data in date_messages_map.items():
        if 'processed' in data and 'structured_data' not in data:
            try:
                # Try to parse existing processed data
                food_entries = []
                for line in data['processed']:
                    food_entry = parse_legacy_format(line)
                    if food_entry:
                        food_entries.append(food_entry)

                if food_entries:
                    # Just log that we could parse the data, but don't store structured_data
                    migrated_count += 1
                    logger.info(f"Validated data for {date}")

            except Exception as e:
                logger.warning(f"Could not validate data for {date}: {e}")

    logger.info(f"Validated {migrated_count} existing entries")
    return date_messages_map


def run_validation(data_file: str, date_to_inspect: Optional[str] = None) -> None:
    """
    Run validation on food log data.

    Args:
        data_file: Path to the date_messages_map.json file
        date_to_inspect: Optional specific date to inspect
    """
    import json

    try:
        from ..database import load_json
        date_messages_map = load_json(data_file)

        if date_to_inspect:
            inspect_date_entries(date_messages_map, date_to_inspect)
        else:
            print_validation_summary(date_messages_map)
    except FileNotFoundError:
        print(f"Error: File {data_file} not found.")
    except json.JSONDecodeError as e:
        print(f"Error: Invalid JSON in {data_file}: {e}")
