"""
Nutrition Calculator

This module handles deterministic nutrition calculations based on the food database.
It maps ingredient names to database entries and calculates nutrition based on
quantity and unit measurements.
"""

import json
import logging
from difflib import get_close_matches
from pathlib import Path
from typing import Any, Dict, List, Optional

from ..config import FOOD_DATABASE_PATH

logger = logging.getLogger(__name__)


class NutritionCalculator:
    """
    Calculates nutrition information from food entries using a structured database.

    The calculator:
    1. Matches ingredient names to database entries (with fuzzy matching)
    2. Looks up grams per unit for the specified unit
    3. Calculates total grams: quantity * grams_per_unit
    4. Calculates nutrition: total_grams * (nutrition_per_100g / 100)
    """

    def __init__(self, database_path: Optional[str | Path] = None):
        """
        Initialize the calculator with a food database.

        Args:
            database_path: Path to the food_database.json file.
                          If not provided, uses FOOD_DATABASE_PATH from config.
        """
        db_path = Path(database_path) if database_path else FOOD_DATABASE_PATH

        with open(db_path, 'r', encoding='utf-8') as f:
            self.database = json.load(f)

        # Create a lookup by name only (no aliases)
        self.food_lookup: Dict[str, str] = {}
        for food_id, food_data in self.database.items():
            # Add main name
            self.food_lookup[food_data['name'].lower()] = food_id


    def match_ingredient(self, ingredient: str) -> Optional[str]:
        """
        Match an ingredient name to a food in the database.

        Uses exact match first, then fuzzy matching.

        Args:
            ingredient: The ingredient name to match

        Returns:
            The matched food ID, or None if no match found
        """
        ingredient_lower = ingredient.lower().strip()

        # Exact match
        if ingredient_lower in self.food_lookup:
            return self.food_lookup[ingredient_lower]

        # Fuzzy match
        matches = get_close_matches(ingredient_lower, list(self.food_lookup.keys()), n=1, cutoff=0.8)
        if matches:
            matched_name = matches[0]
            food_id = self.food_lookup[matched_name]
            logger.warning(
                f"Fuzzy matched '{ingredient}' to '{matched_name}' - verify this is correct"
            )
            return food_id

        logger.warning(f"Could not match ingredient '{ingredient}' to database")
        return None

    def _create_nutrition_result(
        self,
        calories: Optional[int] = None,
        proteins: Optional[float] = None,
        carbs: Optional[float] = None,
        fats: Optional[float] = None,
        fiber: Optional[float] = None,
        grams: Optional[float] = None,
        matched_food_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """Helper to create nutrition result dictionary."""
        return {
            'calories': calories,
            'proteins': proteins,
            'carbs': carbs,
            'fats': fats,
            'fiber': fiber,
            'grams': grams,
            'matched_food_id': matched_food_id
        }

    def calculate_nutrition(
        self,
        ingredient: str,
        quantity: float,
        unit: str
    ) -> Dict[str, Any]:
        """
        Calculate nutrition for a food entry.

        Args:
            ingredient: The ingredient name
            quantity: The quantity amount
            unit: The unit of measurement

        Returns:
            Dict with keys: calories, proteins, carbs, fats, grams, matched_food_id
            Returns None values if calculation is not possible
        """
        # Match ingredient to database
        food_id = self.match_ingredient(ingredient)

        if not food_id:
            logger.warning(f"Could not match ingredient '{ingredient}' to database")
            return self._create_nutrition_result()

        food_data = self.database[food_id]
        unit_lower = unit.lower().strip()

        # Special case: "g" means grams, so conversion factor is 1
        if unit_lower == 'g':
            grams_per_unit = 1
        else:
            # Calculate from grams_per_unit and nutrition_per_100g
            grams_per_unit = food_data.get('grams_per_unit', {}).get(unit_lower)

        nutrition_per_100g = food_data.get('nutrition_per_100g', {})

        if grams_per_unit is None:
            logger.warning(f"No grams_per_unit data for {ingredient} ({unit})")
            return self._create_nutrition_result(matched_food_id=food_id)

        if nutrition_per_100g.get('calories') is None:
            logger.warning(f"No nutrition_per_100g data for {ingredient}")
            return self._create_nutrition_result(matched_food_id=food_id)

        # Calculate total grams
        total_grams = quantity * grams_per_unit

        # Calculate nutrition from per-100g values
        calories = (total_grams / 100) * nutrition_per_100g['calories']
        proteins = (
            (total_grams / 100) * nutrition_per_100g['proteins']
            if nutrition_per_100g.get('proteins')
            else None
        )
        carbs = (
            (total_grams / 100) * nutrition_per_100g['carbs']
            if nutrition_per_100g.get('carbs')
            else None
        )
        fats = (
            (total_grams / 100) * nutrition_per_100g['fats']
            if nutrition_per_100g.get('fats')
            else None
        )
        fiber = (
            (total_grams / 100) * nutrition_per_100g['fiber']
            if nutrition_per_100g.get('fiber')
            else None
        )

        return self._create_nutrition_result(
            calories=int(round(calories)),
            proteins=round(proteins, 1) if proteins is not None else None,
            carbs=round(carbs, 1) if carbs is not None else None,
            fats=round(fats, 1) if fats is not None else None,
            fiber=round(fiber, 1) if fiber is not None else None,
            grams=round(total_grams, 1),
            matched_food_id=food_id
        )

    def get_available_foods(self) -> str:
        """
        Get a formatted list of available foods for LLM prompt.

        Returns:
            String with food names (bulleted list)
        """
        foods_list = [f"- {food_data['name']}" for food_data in self.database.values()]
        return "\n".join(sorted(foods_list))

    def get_available_food_names(self) -> List[str]:
        """
        Get a list of all available food names (for compact prompt).

        Returns:
            List of food names
        """
        return sorted([food_data['name'] for food_data in self.database.values()])
