"""Message processing functions for food log parsing."""

from __future__ import annotations

import logging
from collections import defaultdict
from datetime import datetime
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from ..config import (
    BLACKLISTED_IDS,
    DEFAULT_SENDER_NAME,
    PATHS,
    REWRITE_ID_DATES,
    START_DATE,
)
from ..database import load_json
from ..llm.extractor import FoodDataExtractor
from ..models import FoodEntry
from ..utils import format_quantity, run_tasks
from .nutrition import NutritionCalculator

if TYPE_CHECKING:
    from ..llm.consistency import ConsistencyStats

logger = logging.getLogger(__name__)


def load_messages(config: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    """
    Load messages from the Telegram export file.

    Args:
        config: Optional runtime config dict with 'paths' and 'sender_name'.
                Uses defaults if not provided.

    Returns:
        List of message dictionaries filtered to food log entries
    """
    paths = config["paths"] if config else PATHS
    sender_name = config["sender_name"] if config else DEFAULT_SENDER_NAME

    data = load_json(paths['input'])
    return [
        m for m in data.get('messages', [])
        if m.get('type') == 'message'
        and sender_name in m.get('from', '')
        and m.get('text')
    ]


def group_messages_by_date(
    messages: List[Dict[str, Any]],
    config: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Group messages by date, applying blacklists and date rewrites.

    Args:
        messages: List of message dictionaries
        config: Optional runtime config dict with 'blacklisted_ids',
                'rewrite_id_dates', and 'start_date'. Uses defaults if not provided.

    Returns:
        Dictionary mapping dates to message data
    """
    blacklisted_ids = config["blacklisted_ids"] if config else BLACKLISTED_IDS
    rewrite_id_dates = config["rewrite_id_dates"] if config else REWRITE_ID_DATES
    start_date = config["start_date"] if config else START_DATE

    date_messages_map: Dict[str, Any] = {}

    for message in messages:
        if message["id"] in blacklisted_ids:
            continue
        if message["id"] in rewrite_id_dates:
            message["date"] = rewrite_id_dates[message["id"]]

        date = message['date'].split('T')[0]
        if datetime.strptime(date, '%Y-%m-%d') < start_date:
            continue

        text = message.get('text', '')
        if isinstance(text, list):
            # Handle case where text is a list of entities
            text = ' '.join([
                e.get('text', '') if isinstance(e, dict) else str(e)
                for e in text
            ])
        date_messages_map.setdefault(date, {"original": []})["original"].append(text)

    return date_messages_map


def process_date_messages_map(
    date_messages_map: Dict[str, Any],
    process_dates: List[str],
    use_consistency: bool = True,
    confidence_threshold: float = 0.7
) -> Dict[str, Any]:
    """
    Process unprocessed dates in the date messages map.

    Uses LLM extraction followed by nutrition calculation.
    When use_consistency is True, applies self-consistency checking
    for uncertain extractions.

    Args:
        date_messages_map: The date messages map to process
        process_dates: List of dates that need processing
        use_consistency: Whether to use self-consistency checking
        confidence_threshold: Minimum confidence to skip verification (0-1)

    Returns:
        Updated date messages map with processed data
    """
    from ..config import MODEL_ID, OPENROUTER_API_KEY

    extractor = FoodDataExtractor(
        api_key=OPENROUTER_API_KEY,
        model=MODEL_ID,
        temp=0.0
    )

    # Initialize nutrition calculator with database
    calculator = NutritionCalculator(PATHS['food_database'])

    # Get simplified food list for LLM prompt
    available_foods = "\n".join(calculator.get_available_food_names())

    # Initialize consistency checker if enabled
    consistency_checker = None
    if use_consistency:
        # Import here to avoid circular import
        from ..llm.consistency import ConsistencyChecker
        consistency_checker = ConsistencyChecker(
            extractor=extractor,
            calculator=calculator,
            confidence_threshold=confidence_threshold
        )

    # Track issues across all dates for final summary
    unmatched_ingredients: Dict[str, int] = defaultdict(int)
    missing_unit_entries: Dict[tuple, int] = defaultdict(int)
    unknown_foods: Dict[str, int] = defaultdict(int)
    llm_failures: List[str] = []
    zero_calorie_entries: List[tuple] = []

    def _run(date: str, index: int) -> None:
        original_messages = date_messages_map[date]["original"]
        ingredients_text = '\n'.join(original_messages)

        try:
            # Step 1: Extract food data from LLM (without calories)
            if consistency_checker:
                # Use self-consistency extraction
                result = consistency_checker.extract_with_consistency(
                    ingredients_text, available_foods
                )
                food_entries = result.entries
                extraction_success = result.success

                if result.passes_used > 1:
                    logger.info(
                        f"Date {date}: {result.passes_used} passes, "
                        f"{result.conflicts_resolved} conflicts resolved"
                    )
            else:
                # Standard single-pass extraction
                food_entries, extraction_success = extractor.extract_food_data(
                    ingredients_text, available_foods
                )

            if not extraction_success:
                llm_failures.append(date)
                logger.error(f"LLM extraction failed for date {date}")
                return

            if not food_entries:
                logger.warning(f"No food entries extracted for date {date}")
                return

            # Step 2: Calculate nutrition for each entry
            for food in food_entries:
                # Track unknown foods flagged by LLM
                if food.unknown:
                    unknown_foods[food.ingredient] += 1

                nutrition = calculator.calculate_nutrition(
                    food.ingredient, food.quantity, food.unit
                )
                for key in ('proteins', 'carbs', 'fats', 'fiber', 'grams', 'matched_food_id'):
                    setattr(food, key, nutrition[key])

                # Set calculation status based on result
                if nutrition['matched_food_id'] is None:
                    food.calculation_status = 'no_match'
                    food.calories = 0
                    unmatched_ingredients[food.ingredient] += 1
                elif nutrition['calories'] is None:
                    food.calculation_status = 'missing_unit'
                    food.calories = 0
                    missing_unit_entries[(food.ingredient, food.unit)] += 1
                else:
                    food.calculation_status = 'success'
                    food.calories = nutrition['calories']

                # Track zero-calorie entries (potential failures)
                if food.calories == 0:
                    zero_calorie_entries.append((date, food.ingredient))

            # Convert to legacy format for backward compatibility
            processed_messages = [
                f"{f.ingredient};{format_quantity(f.quantity)};{f.unit};{f.calories}"
                for f in food_entries
            ]

            total_calories = sum(food.calories for food in food_entries)
            total_proteins = sum(food.proteins or 0 for food in food_entries)
            total_carbs = sum(food.carbs or 0 for food in food_entries)
            total_fats = sum(food.fats or 0 for food in food_entries)
            total_fiber = sum(food.fiber or 0 for food in food_entries)

        except Exception as e:
            logger.error(f"Error processing ingredients for {date}: {ingredients_text}, {e}")
            llm_failures.append(date)
            return

        date_messages_map[date] = {
            'original': original_messages,
            'processed': processed_messages,
            'total': total_calories,
            'proteins': total_proteins,
            'carbs': total_carbs,
            'fats': total_fats,
            'fiber': total_fiber
        }

    logger.info(f"Dates to process: {len(process_dates)} - {process_dates}")
    tasks = [(_run, date) for date in process_dates]
    run_tasks(tasks, max_workers=2)

    # Print summary of issues
    _print_processing_summary(
        unmatched_ingredients,
        missing_unit_entries,
        unknown_foods,
        llm_failures,
        zero_calorie_entries,
        len(process_dates),
        consistency_checker.stats if consistency_checker else None
    )

    return date_messages_map


def _print_processing_summary(
    unmatched_ingredients: Dict[str, int],
    missing_unit_entries: Dict[tuple, int],
    unknown_foods: Dict[str, int],
    llm_failures: List[str],
    zero_calorie_entries: List[tuple],
    total_dates: int,
    consistency_stats: Optional["ConsistencyStats"] = None
) -> None:
    """Print a summary of processing issues."""
    has_issues = unmatched_ingredients or missing_unit_entries or unknown_foods or llm_failures

    if not has_issues and not consistency_stats:
        logger.info(f"Processing complete: {total_dates} dates processed with no issues")
        return

    # Print consistency stats even if no other issues
    if consistency_stats and not has_issues:
        print("\n" + "=" * 60)
        print("PROCESSING SUMMARY")
        print("=" * 60)
        print(f"\n[INFO] {consistency_stats}")
        if consistency_stats.verification_improvements > 0:
            print(
                f"  Self-consistency improved {consistency_stats.verification_improvements} "
                "extraction(s)"
            )
        print("=" * 60 + "\n")
        return

    print("\n" + "=" * 60)
    print("PROCESSING SUMMARY - Issues Found")
    print("=" * 60)

    # Print consistency stats if available
    if consistency_stats:
        print(f"\n[INFO] {consistency_stats}")
        if consistency_stats.verification_improvements > 0:
            print(
                f"  Self-consistency improved {consistency_stats.verification_improvements} "
                "extraction(s)"
            )

    if llm_failures:
        print(f"\n[ERROR] LLM extraction failed for {len(llm_failures)} date(s):")
        for date in llm_failures:
            print(f"  - {date}")

    if unknown_foods:
        print(f"\n[WARNING] {len(unknown_foods)} food(s) not in database (flagged by LLM):")
        for ingredient, count in sorted(
            unknown_foods.items(), key=lambda x: -x[1]
        ):
            print(f"  - \"{ingredient}\" ({count}x)")
        print("\n  Add these to food_database.json to fix.")

    if unmatched_ingredients:
        print(f"\n[WARNING] {len(unmatched_ingredients)} food(s) not found in database:")
        for ingredient, count in sorted(
            unmatched_ingredients.items(), key=lambda x: -x[1]
        ):
            print(f"  - \"{ingredient}\" (appeared {count} time(s))")
        print("\n  Add these to food_database.json and rerun to fix.")

    if missing_unit_entries:
        print(
            f"\n[WARNING] {len(missing_unit_entries)} food/unit combination(s) "
            "missing unit conversion:"
        )
        for (ingredient, unit), count in sorted(
            missing_unit_entries.items(), key=lambda x: -x[1]
        ):
            print(f"  - \"{ingredient}\" with unit \"{unit}\" ({count} time(s))")
        print("\n  Add the missing unit to grams_per_unit in food_database.json.")

    if zero_calorie_entries:
        unique_zero_cal = set(ingredient for _, ingredient in zero_calorie_entries)
        print(
            f"\n[INFO] {len(zero_calorie_entries)} entries calculated as 0 calories "
            f"({len(unique_zero_cal)} unique foods)"
        )

    print("=" * 60 + "\n")
