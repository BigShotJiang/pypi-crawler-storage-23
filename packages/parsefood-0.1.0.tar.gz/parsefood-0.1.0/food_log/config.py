"""Centralized configuration for the food log parser."""

from __future__ import annotations

import os
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from dotenv import load_dotenv

if TYPE_CHECKING:
    from .profile import ProfileConfig

# Load environment variables
load_dotenv(override=True)

# API Configuration
MODEL_ID = os.getenv("MODEL_ID")
OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY")
OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"

# Data paths
DATA_PATH = os.getenv("DATA_PATH", "data")
FOOD_DATABASE_PATH = Path("food_database.json")

# File paths (default, used when no profile specified)
PATHS = {
    'food_database': 'food_database.json',  # Structured nutrition database
    'input': f'{DATA_PATH}/result.json',
    'messages': f'{DATA_PATH}/date_messages_map.json',
    'plot': f'{DATA_PATH}/plot.png'
}

# Default processing settings (used when no profile specified)
START_DATE = datetime(2023, 8, 30)
BLACKLISTED_IDS: List[int] = [2842, 2849, 2864, 2905, 7074, 7075]
REWRITE_ID_DATES: Dict[int, str] = {
    7071: "2024-06-23T07:22:47",
    7072: "2024-06-23T07:22:47",
    7073: "2024-06-23T07:22:47"
}

# Timestamp format for backups
BACKUP_TIMESTAMP_FORMAT = '%Y%m%d_%H%M%S'

# Unit normalization map - maps Portuguese/legacy units to standard units
UNIT_MAP: Dict[str, str] = {
    # Portuguese -> Standard
    'unidade': 'unit',
    'lata': 'unit',
    'fatia': 'unit',
    'colher de sopa': 'tbsp',
    'c.sopa': 'tbsp',
    'csopa': 'tbsp',
    'cs': 'tbsp',
    'colher de servir': 'tbsp',
    'copo': 'cup',
    'tigela': 'cup',
    'porcao': 'unit',
    'gramas': 'g',
    'grama': 'g',
    'g': 'g',
    'colher de chá': 'tsp',
    'colher de cha': 'tsp',
    'c.cha': 'tsp',
    'ccha': 'tsp',
    'cc': 'tsp',
    # Standard units (pass-through)
    'tbsp': 'tbsp',
    'tsp': 'tsp',
    'cup': 'cup',
    'unit': 'unit',
}

# Standard units that should be used in the database
STANDARD_UNITS = {'tbsp', 'tsp', 'cup', 'unit', 'g'}

# Target calories (for daily summary)
TARGET_CALORIES = int(os.getenv("TARGET_CALORIES", 2000))

# Default sender name (for backward compatibility)
DEFAULT_SENDER_NAME = "Cristina"


def get_runtime_config(profile: Optional["ProfileConfig"] = None) -> Dict[str, Any]:
    """Build runtime configuration from profile or environment defaults.

    Configuration priority:
    1. Profile YAML settings (if profile provided)
    2. Environment variables
    3. Code defaults

    Args:
        profile: Optional ProfileConfig instance. If None, uses env defaults.

    Returns:
        Dictionary with all configuration values needed at runtime.
    """
    if profile is not None:
        return profile.to_runtime_config()

    # Build from environment defaults
    return {
        "name": DEFAULT_SENDER_NAME,
        "sender_name": DEFAULT_SENDER_NAME,
        "data_path": DATA_PATH,
        "start_date": START_DATE,
        "target_calories": TARGET_CALORIES,
        "blacklisted_ids": BLACKLISTED_IDS,
        "rewrite_id_dates": REWRITE_ID_DATES,
        "paths": PATHS,
    }
