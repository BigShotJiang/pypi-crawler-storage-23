from .model import ModelTab
from .development import DevelopmentTab
from .segmentation import SegmentationTab
from .intelligence import IntelligenceTab
