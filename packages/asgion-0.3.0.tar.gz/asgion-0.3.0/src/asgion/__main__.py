from asgion.cli import main

main()
