# CLAUDE.md

## Project Overview

This is a **Python CLI/MCP tool** that provides governed database access for AI agents — a "headless data IDE" combining schema introspection, query validation, cost estimation, and performance monitoring.

**Name:** dbastion (db + bastion, also DB-AST-ion — Database Abstract Syntax Tree)
**Language:** Python (>=3.12)
**Core SQL engine:** sqlglot
**CLI aliases:** `dbastion` (full, for agents) and `dbast` (short, for humans)

## Documentation

All design context is in `docs/`:
- `VISION.md` — problem, solution, differentiators
- `ARCHITECTURE.md` — four engines, tech stack, CLI interface
- `CONCEPTS.md` — core conceptual frameworks (Headless Data IDE, Semantic Telemetry, Three Pillars, Enum Trap, Auto-Healing Pipeline)
- `FEATURES.md` — 10 IDE features adapted for agents
- `MONITORING.md` — Lab128-inspired monitoring, collector mode
- `COMPETITIVE_LANDSCAPE.md` — every competitor analyzed
- `ROADMAP.md` — v0.1 through v0.8
- `RESEARCH.md` — raw research findings
- `DIAGNOSTICS.md` — rustc-inspired error reporting, error codes, auto-healing design

**Read docs/ thoroughly before making architectural decisions.**

## Architecture (Four Engines)

1. **Introspection Engine** — Schema cache (3 levels), FK graph, value profiling, fuzzy search
2. **Policy Engine** — sqlglot AST parsing, classification, guardrails, enrichment
3. **Execution Engine** — Multi-DB adapters (Postgres, BigQuery first), dry-run, formatting
4. **Monitoring Engine** — Client-side polling, local DuckDB snapshots, semantic telemetry

## Key Dependencies

```
sqlglot>=26,<30     # SQL parsing, transpilation, lineage, optimization
click>=8.1,<9       # CLI framework
```

Optional (per adapter):
```
psycopg[binary]>=3.1           # PostgreSQL
google-cloud-bigquery>=3.20    # BigQuery
```

## Project Structure

```
src/dbastion/
  cli/            # click commands (validate, query)
  policy/         # policy engine (classify, safety, enrich)
  diagnostics/    # diagnostic types, codes, rendering
  adapters/       # database adapter protocol + implementations
```

## Code Standards

- Python 3.12+ with `from __future__ import annotations`
- Type hints on all public functions
- dataclasses for data types, Enum for enumerations
- Tests for all policy engine rules (safety-critical path)
- `uv` for project management, `ruff` for linting, `pytest` for testing

## Build & Test

```bash
uv sync --extra dev     # install deps
uv run pytest           # run tests
uv run ruff check       # lint
uv run dbastion --help  # CLI
```

## Git

- Personal account: bakhtiyar.mautov@gmail.com
- SSH host: `gh-me` (uses personal SSH key)
- Remote: `git@gh-me:USERNAME/REPO.git` (set when GitHub repo is created)

## Current Phase

v0.1 in progress. Policy engine implemented (classification, safety checks, auto-LIMIT). CLI `validate` and `query` commands working. Next: database adapters and connection management.
