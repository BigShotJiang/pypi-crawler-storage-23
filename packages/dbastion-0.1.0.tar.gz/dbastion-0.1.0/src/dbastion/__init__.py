"""dbastion: governed database access for AI agents."""

__version__ = "0.1.0"
