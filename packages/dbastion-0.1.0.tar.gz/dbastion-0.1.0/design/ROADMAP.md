# Roadmap

## v0.1 — Works (MVP)
**Goal:** Agents can query safely with schema awareness.

- [ ] Project scaffolding (Cargo workspace, clap CLI)
- [ ] Connection config (`~/.config/tool-name/connections.toml`)
- [ ] PostgreSQL adapter (connect, execute, introspect L1/L2)
- [ ] BigQuery adapter (connect, execute via REST API, introspect)
- [ ] Policy engine: query classification (READ/DML/DDL via polyglot-sql AST)
- [ ] Policy engine: write blocking (require `--allow-write` for DML/DDL)
- [ ] Policy engine: auto-LIMIT injection (default 1000)
- [ ] `tool connect` — register a database connection
- [ ] `tool query` — guarded query execution
- [ ] `tool schema tables` — list tables with row counts
- [ ] `tool schema columns <table>` — column details with types
- [ ] JSON output (default, agent-friendly) and table output (human-friendly)

## v0.2 — Smart
**Goal:** Eliminate the most common agent failures.

- [ ] Schema cache (local SQLite/DuckDB, persist across sessions)
- [ ] `tool validate` — check SQL against schema, fuzzy column correction
- [ ] `tool profile <table.column>` — value hinting (top-N distinct values)
- [ ] `tool estimate` — cost estimation via adapter dry-run
- [ ] `tool format` — pretty-print SQL via polyglot-sql
- [ ] Safety inspections: DELETE without WHERE, CROSS JOIN, constant conditions
- [ ] SELECT * expansion (replace with explicit columns from schema)
- [ ] Structured error responses with suggestions

## v0.3 — Powerful
**Goal:** Advanced SQL intelligence.

- [ ] `tool explain` — execution plan analysis with natural language hints
- [ ] `tool schema join-path <from> <to>` — FK graph BFS
- [ ] `tool schema relationships` — full FK graph
- [ ] `tool transpile` — cross-dialect conversion
- [ ] `tool lineage <column>` — column-level lineage
- [ ] MySQL adapter
- [ ] Snowflake adapter
- [ ] Schema search (keyword matching over table/column names + comments)
- [ ] L3 introspection (view definitions, procedure source, comments)
- [ ] Dependency tracking (warn on DDL that breaks views/procs)

## v0.4 — Complete
**Goal:** Full "headless IDE" feature surface.

- [ ] `tool diff <db1> <db2>` — schema comparison
- [ ] `tool export` — CSV, JSON, Parquet output
- [ ] `tool mock <table>` — test data generation respecting constraints
- [ ] MCP server mode (`tool mcp`) — expose all commands as MCP tools
- [ ] DuckDB adapter
- [ ] Result pagination (cap rows, truncate wide columns, report total vs returned)

## v0.5 — Monitor (Direct)
**Goal:** Agent-native database diagnostics, direct polling.

- [ ] `tool monitor activity` — active sessions + wait events (PostgreSQL)
- [ ] `tool monitor top-sql` — top SQL by time/reads/rows
- [ ] `tool monitor locks` — blocking chain resolution
- [ ] `tool monitor waits` — wait event breakdown
- [ ] Local snapshot store (DuckDB/Parquet)
- [ ] Delta computation for cumulative stats

## v0.6 — Monitor (Serverless)
**Goal:** Cost tracking for cloud databases.

- [ ] `tool monitor cost` — BigQuery (bytes/dollars from JOBS view)
- [ ] `tool monitor cost` — Snowflake (credits from QUERY_HISTORY)
- [ ] `tool monitor report` — historical analysis from system views
- [ ] On-demand sync for serverless DB history

## v0.7 — Collector
**Goal:** Persistent monitoring for managed databases.

- [ ] `tool collector start` — long-running polling mode with REST API
- [ ] Snapshot storage with retention policies (raw → hourly → daily rollups)
- [ ] CLI queries collector API via `--collector` flag
- [ ] Auto-detect: collector vs direct poll vs serverless
- [ ] Docker image for deployment
- [ ] Health endpoint with vitals one-liner

## v0.8 — Monitor (TUI)
**Goal:** Human-friendly live dashboard.

- [ ] `tool monitor live` — ratatui TUI with auto-refresh
- [ ] Activity panel (sessions, waits)
- [ ] Top SQL panel
- [ ] Lock tree panel
- [ ] System vitals header

## Future
- Oracle adapter
- ClickHouse adapter
- Alerting rules (collector mode)
- Query rewrite suggestions (optimization hints)
- Team sharing (collector → multiple CLI clients)
- Plugin system for custom adapters
- Context injection header in all responses (DB vitals)
