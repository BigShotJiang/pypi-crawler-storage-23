# Core Concepts

Conceptual frameworks that define the project's identity. These emerged during initial design conversations and should guide all implementation decisions.

---

## The Name: DB-AST-ion

**dbastion** = db + bastion — the fortified gateway between an AI agent and your databases.

But there's a hidden double meaning: **DB-AST-ion** — Database Abstract Syntax Tree. The entire architecture relies on parsing SQL into an AST (via polyglot-sql) to enforce guardrails. The name literally encodes the core technical mechanism.

**CLI aliases:** Ship both `dbastion` (explicit, for AI agents — reinforces guardrail context in the LLM's memory) and `dbast` (fast to type, for human developers — and literally spells "DB AST").

---

## The Headless Data IDE

**Thesis:** When a human developer opens DataGrip, they don't get a blank text box. The IDE does massive background work — introspecting schemas, mapping relationships, profiling data — so the human doesn't keep a 500-table schema in their head.

LLMs suffer the exact same memory constraints (token limits + hallucinations). This tool adapts visual IDE features into **text-based APIs optimized for LLM token windows**.

We are not building a query tool. We are building **DataGrip without the GUI, designed for AI agents**.

---

## Semantic Telemetry

**Problem:** Human DBAs use colored graphs and timelines to spot performance spikes. LLMs cannot see graphs, and they fail if you dump 5,000 rows of raw `pg_stat_activity` JSON into their context window.

**Solution:** Every monitoring response is a dense, token-optimized semantic summary:

Instead of raw data:
```json
[{"pid": 12345, "state": "active", "wait_event_type": "IO", "wait_event": "DataFileRead", ...},
 {"pid": 12346, "state": "active", "wait_event_type": "IO", "wait_event": "DataFileRead", ...},
 ... 45 more rows ...]
```

Return a diagnosis:
```
CRITICAL: 45 active connections. 80% of database time spent on IO:DataFileRead.
Primary bottleneck: PID 12345, Sequential Scan on historical_logs, running 14 minutes.
Suggestion: Add WHERE clause on partition column or terminate PID 12345.
```

The tool does the aggregation and analysis. The agent gets actionable intelligence.

---

## Three Pillars

The tool is organized around three conceptual pillars:

### 1. The Governor (Safety & Execution)
**Question it answers:** "Is this SQL safe to run, and what will it cost?"

- polyglot-sql AST parsing and classification
- Cost estimation via adapter-specific dry-runs
- Auto-LIMIT injection, write blocking, injection detection
- JSON-optimized result pagination

### 2. The Navigator (IDE Context & Introspection)
**Question it answers:** "What's in this database and how do I query it correctly?"

- Background schema introspection at 3 levels (catalog → structure → full)
- Semantic search over table/column names
- FK graph with join path discovery
- Column value profiling (the "enum trap" solver)
- Fuzzy column name correction

### 3. The Diagnostician (Performance & Monitoring)
**Question it answers:** "What's happening in this database right now, and what happened at 3 AM?"

- Client-side polling (Lab128 philosophy)
- Local snapshot store with delta computation
- Lock tree resolution
- Execution plan analysis with natural language hints
- Cost tracking for serverless databases
- Situational awareness via context injection headers

---

## The Enum Trap

The #1 reason LLM data analysis fails. An agent knows a column is named `status`. It writes:
```sql
WHERE status = 'Active'
```
But the database stores `['active', 'pending', 'cancelled_user']`. The query returns 0 rows. The agent concludes "no data exists" and hallucinates an explanation.

**Solution:** `tool profile orders.status` returns the actual distinct values before the agent writes its query. This eliminates an entire class of errors.

---

## The Auto-Healing Pipeline

When an agent submits SQL, the tool doesn't just pass/fail. It **heals**:

1. Parse SQL → AST (polyglot-sql)
2. Extract table/column references
3. Validate against schema cache
4. If column `usename` not found → calculate Levenshtein distance → suggest `username`
5. If `SELECT *` on wide table → expand to explicit columns
6. If no LIMIT → inject LIMIT 1000
7. If DELETE without WHERE → block with explanation
8. If cost > threshold → warn with estimation
9. Execute the validated, enriched query
10. Return results + metadata (cost, tables, row count)

The agent gets both the result and the correction, learning implicitly what the right column names and patterns are.

---

## Situational Awareness

Traditional tools give agents no context about database health. An agent will happily launch a massive `CREATE MATERIALIZED VIEW` during peak traffic.

**Solution:** Every tool response can include a vitals header:
```
[DB: prod-pg | Active: 198/200 | CPU: 92% | Locks: 7 | Load: CRITICAL]
```

If the agent's system prompt says "defer heavy operations under high load," it will autonomously postpone its analytical query until load drops. The tool provides the awareness; the agent makes the decision.

---

## End-to-End Query Flow

```
Agent: "What's the revenue by status for last month?"

Step 1 — Agent calls schema
  tool schema columns orders --db prod-pg
  → Returns: id, user_id, amount (DECIMAL), status (VARCHAR), created_at (TIMESTAMP)

Step 2 — Agent calls profile (avoids enum trap)
  tool profile orders.status --db prod-pg
  → Returns: active (57%), pending (20%), completed (15%), cancelled_user (5%), refunded (3%)

Step 3 — Agent writes SQL and submits
  tool query "SELECT status, SUM(amount) FROM orders
              WHERE created_at >= '2026-01-01' GROUP BY 1" --db prod-pg

Step 4 — Policy engine processes
  a. Parse → AST (SELECT, valid)
  b. Validate columns → status ✓, amount ✓, created_at ✓ (all exist)
  c. Classification → READ (allowed)
  d. Safety checks → no issues
  e. Auto-LIMIT → not needed (GROUP BY limits naturally)
  f. Cost estimate → dry-run: 0.3 GB (under threshold, auto-approve)
  g. Format → pretty-print SQL

Step 5 — Execute
  → Returns 5 rows + metadata

Step 6 — Response to agent
  {
    "rows": [
      {"status": "active", "sum": 15234567.89},
      {"status": "pending", "sum": 3421098.45},
      ...
    ],
    "metadata": {
      "cost_gb": 0.3,
      "rows_returned": 5,
      "tables": ["orders"],
      "execution_time_ms": 234
    },
    "vitals": "DB: prod-pg | Active: 12 | Load: NORMAL"
  }
```

The agent never hallucinated a column name, never used the wrong enum value, never ran an expensive unbounded query. Every step was guided by the tool's intelligence.

---

## Why Not Just Give Agents Raw psql/bq Access?

| Raw access | Through this tool |
|---|---|
| Agent guesses table names → error → retry | Agent calls `schema tables` → exact names |
| Agent guesses column names → error → retry | Agent calls `schema columns` → exact columns + types |
| Agent writes `SELECT *` → 200 columns → blows context | Tool auto-expands to relevant columns |
| Agent writes JOIN → wrong FK → wrong results | Agent calls `join-path` → correct FK chain |
| Agent writes `WHERE status = 'Active'` → 0 rows | Agent calls `profile` → knows actual values |
| Agent writes DELETE without WHERE → data gone | Tool blocks with explanation |
| Agent runs 500GB query → $2.50 bill | Tool estimates cost, asks for approval |
| Agent can't diagnose slow database | Agent calls `monitor activity` → semantic diagnosis |
