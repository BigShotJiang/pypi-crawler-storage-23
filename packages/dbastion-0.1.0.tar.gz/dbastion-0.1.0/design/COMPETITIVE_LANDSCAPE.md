# Competitive Landscape

## Direct Competitors: None

No existing tool combines sqlglot-level SQL analysis + multi-database execution + agent-friendly CLI/MCP interface. The space is fragmented across partial solutions.

---

## Validation Libraries (Parse + Guard, No Execution)

### ProxQL
- **URL:** https://github.com/Zeredbaron/proxql
- **Stars:** 4 | **License:** Apache 2.0 | **Language:** Python/TypeScript
- **Last active:** December 2025
- **What it does:** Python library built on sqlglot for validating AI-generated SQL. Table allowlists, LIMIT enforcement, write blocking, injection detection.
- **Limitations:** Library only (`from proxql import Validator`). Does not execute queries, estimate costs, or connect to any database.
- **Relevance:** Validates the demand. Someone independently reached for sqlglot to solve the exact same problem.

### Guardrails AI — exclude_sql_predicates
- **URL:** https://github.com/guardrails-ai/exclude_sql_predicates
- **Stars:** 2 | **Last active:** February 2024
- **What it does:** Guardrails AI plugin using sqlglot to reject queries with forbidden predicates (DROP, DELETE).
- **Limitations:** Plugin for Guardrails AI framework only. Predicate-level blocking, no broader analysis.

### mcp-server-sql-analyzer
- **URL:** https://github.com/j4c0bs/mcp-server-sql-analyzer
- **Stars:** 26 | **Last active:** January 2025
- **What it does:** MCP server exposing sqlglot analysis tools: lint_sql, transpile_sql, get_table_references, get_column_references.
- **Limitations:** Analysis/linting only, does not execute queries or enforce policies.

---

## Execution Servers (Execute, No Guardrails)

### Google MCP Toolbox for Databases
- **URL:** https://github.com/googleapis/genai-toolbox
- **Stars:** 13,100 | **License:** Apache 2.0 | **Language:** Go
- **Last active:** Active (Google-maintained)
- **What it does:** MCP server for 44+ databases. Connection pooling, OAuth, hot-reload YAML config. Predefined tools per database type.
- **SQL parsing:** Hand-written 350-line Go table parser (BigQuery only). No sqlglot.
- **Guardrails:** BigQuery: write-mode blocking + dataset allowlists. CockroachDB: read-only mode + row limits. All others: parameterized queries only.
- **Cost estimation:** BigQuery dry-run used internally but NOT surfaced to agents.
- **Limitations:** No SQL analysis, no transpilation, no optimization, no lineage. Heavy (Go server + YAML config) vs lightweight CLI.
- **Relationship:** Complementary — they handle connectivity, we handle SQL intelligence. Could be used as a backend adapter.

---

## Text-to-SQL Generators (Different Category)

### Vanna AI
- **URL:** https://github.com/vanna-ai/vanna
- **Stars:** 22,725 | **License:** MIT | **Language:** Python
- **Last active:** February 2026
- **What it does:** Natural language → SQL via LLM + RAG. Train with DDL/docs/example queries, ask questions in English, get SQL + results + charts.
- **SQL parsing:** `sqlparse` in legacy (trivial SELECT check). v2.0: `args.sql.strip().upper().split()[0]` — a string split. That's it.
- **sqlglot:** Not used. Community proposed it (discussion #940), 0 comments, ignored.
- **Guardrails:** None in v2.0. No cost estimation, no dry-run, no write blocking, no schema validation.
- **Security:** CVE-2024-5565 — RCE via prompt injection into `exec()` on LLM-generated Python. Still open per issues #1078, #1062.
- **Relationship:** Not competing — Vanna generates SQL, we govern and execute it. They could use our tool under the hood.

### Wren AI
- **URL:** https://github.com/Canner/WrenAI
- **What it does:** Text-to-SQL with a semantic modeling layer (relationships, metrics, calculated fields defined upfront).
- **Difference:** Semantic layer approach vs our runtime governance approach. Different philosophies.

---

## MCP Security Gateways (Protocol Layer)

### MCP Guardian (EQTY Lab)
- **URL:** https://github.com/eqtylab/mcp-guardian
- **Stars:** 192 | **License:** Apache 2.0 | **Language:** Rust
- **What it does:** MCP proxy for approval/audit of all tool calls. Logs LLM-to-MCP-server interactions.
- **Limitations:** Protocol-level gateway, not SQL-aware. Does not parse queries or estimate costs.

### TrueFoundry MCP Gateway
- **URL:** https://truefoundry.com/mcp-gateway (commercial, not open source)
- **What it does:** Enterprise MCP gateway with OAuth/OIDC, RBAC, audit logging. 3-4ms latency.
- **Limitations:** Commercial managed service. Auth/access layer, not SQL analysis.

### Invariant Guardrails (now Snyk)
- **URL:** https://github.com/invariantlabs-ai/invariant
- **Stars:** 389 | **License:** Apache 2.0
- **What it does:** Rule-based agent guardrailing. Pattern matching on agent behavior flows (e.g., "agent reads inbox then sends email externally").
- **Limitations:** General-purpose agent safety, not SQL-specific. No sqlglot.

---

## Database Monitoring (Adjacent)

### pg_activity
- **URL:** https://github.com/dalibo/pg_activity
- **What it does:** htop-like TUI for PostgreSQL. Active sessions, wait events, blocking queries.
- **Limitations:** PostgreSQL only, real-time only (no historical snapshots).

### pgcenter
- **URL:** https://github.com/lesovsky/pgcenter
- **What it does:** top-like TUI with recording capability. Can store stats to files for later analysis.
- **Limitations:** PostgreSQL only. Closest to Lab128 philosophy in the PG ecosystem.

### Lab128 (discontinued)
- **What it was:** Windows-native Oracle performance monitor. Client-side C/C++, polled V$ views every 6 seconds, stored 60 days locally. Instant drill-down to any historical moment.
- **Why it matters:** Architectural inspiration for our monitoring engine. Proved that client-side computation + local storage + high-frequency polling = unmatched diagnostic capability.
- **Status:** Abandoned since ~2017.

---

## Summary Matrix

| Tool | SQL Parsing | Cost Estimation | Write Blocking | Schema Validation | Transpilation | Monitoring | Executes SQL |
|---|---|---|---|---|---|---|---|
| **This project** | polyglot-sql (32 dialects) | Per-adapter dry-run | AST-based | Against schema cache | Yes | Yes | Yes |
| Google Toolbox | Hand-written (BQ only) | Internal only | BQ/CockroachDB only | No | No | No | Yes |
| Vanna AI | String split | No | No (v2.0) | No | No | No | Yes |
| ProxQL | sqlglot | No | Yes | No | No | No | No |
| MCP Guardian | No | No | No | No | No | No | No |
| pg_activity | No | No | No | No | No | PG only | No |
