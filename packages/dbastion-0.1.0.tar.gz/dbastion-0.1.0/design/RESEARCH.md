# Research Notes

Context gathered during project conception. This document preserves key findings for reference.

## Origin Story

This project evolved from a Claude Code hook (`.claude/hooks/bq-guardrail.py`) in the analytics-hub repository that intercepts `bq query` commands, parses SQL with sqlglot, runs dry-runs for cost estimation, and auto-approves/blocks based on thresholds. The realization: this pattern is useful for any agent talking to any database, not just Claude Code + BigQuery.

## Key Insight: The Missing Middle

The ecosystem has validation libraries (parse SQL, no execution) and execution servers (run SQL, no validation). Nobody combines parse + guard + execute in a single tool.

## polyglot-sql: sqlglot in Rust

**URL:** https://github.com/tobilg/polyglot
**Crate:** https://crates.io/crates/polyglot-sql

A Rust reimplementation of Python's sqlglot. Key facts:
- 18,629 tests (including 10,220 sqlglot fixture tests), 100% pass rate
- 32 SQL dialects
- Full feature parity: parsing, transpilation, optimization (12 passes), column lineage, type annotation, AST diff, query builder, schema module, scope analysis
- v0.1.5, created January 2026, single primary maintainer (tobilg)
- MIT license (acknowledges sqlglot origin)
- Zero Python dependencies — pure Rust

**Known issues:**
- #18: Column lineage lost inside function calls
- #19: Schema validation fails on valid queries with CTEs
- #17: PostgreSQL `::schema.type` cast syntax produces invalid output
- #21: Table extraction doesn't easily exclude CTE names

## Vanna AI Analysis

**URL:** https://github.com/vanna-ai/vanna (22K stars)

Text-to-SQL tool (natural language → SQL via LLM + RAG). Key findings:
- Does NOT use sqlglot (grep: 0 matches in entire codebase)
- Uses `sqlparse` in legacy for trivial SELECT check
- v2.0 SQL "validation": `args.sql.strip().upper().split()[0]` — a string split
- Community proposed sqlglot integration (discussion #940) — 0 comments, ignored
- CVE-2024-5565: RCE via prompt injection into `exec()` on LLM-generated Python (still open)
- RAG approach (train with DDL/docs/examples) validates our schema context concept
- Not a competitor — they generate SQL, we govern it

## Google MCP Toolbox for Databases

**URL:** https://github.com/googleapis/genai-toolbox (13K stars)

Database connectivity MCP server. Key findings:
- 44+ database sources, Go binary
- SQL parsing: hand-written 350-line Go table parser (BigQuery only)
- No sqlglot, no transpilation, no optimization, no lineage
- Guardrails: BQ write-mode + dataset allowlists, CockroachDB read-only + row limits, others: nothing
- Cost estimation: BQ dry-run used internally, NOT surfaced to agents
- Not a competitor — they handle connectivity, we handle SQL intelligence
- Could be used as a backend adapter

## DataGrip Feature Analysis

Key features adapted for agent context:

**3-Level Introspection:**
- L1: Object names only (fastest, for massive schemas)
- L2: Names + types + constraints (no source code)
- L3: Everything including procedure source
- Thresholds: L3 for ≤1000 objects, L2 for ≤3000, L1 above
- Caching: disk-persisted, survives IDE restarts
- Smart refresh: after each query, refresh only affected objects

**Code Inspections (applicable to agents):**
- Unresolved objects (table/column doesn't exist)
- Ambiguous column names
- DELETE/UPDATE without WHERE ("unsafe statements")
- Constant conditions (always TRUE/FALSE)
- Type compatibility issues
- Unused subquery columns
- Nested DML/DDL detection in function call trees

**Schema Diff:**
- Compare any two same-type objects across servers
- Auto-generate migration scripts
- DDL diff with synchronized scrolling

## DBeaver Feature Analysis

Key unique features:
- Semantic SQL validation against cached metadata (not just syntax)
- Grouping Panel: drag columns for instant GROUP BY analysis without writing SQL
- Calc Panel: live statistics (COUNT, SUM, AVG, MIN, MAX) on selected data
- Schema compare via Liquibase under the hood
- Mock data generation respecting FK/PK/UNIQUE constraints
- Row count estimation via database statistics (no COUNT(*))
- ER diagram auto-generation from FK metadata

## Lab128 Architecture

Oracle performance monitor (discontinued ~2017). Key architecture:
- Pure client-side C/C++, ~47MB RAM, starts in 1-2 seconds
- Zero footprint on database (only reads V$ views via OCI)
- Polls every 6 seconds, 60 days of data on disk
- All computation (deltas, aggregation, correlation) done client-side
- Could monitor 15-20 instances simultaneously on a laptop
- Killer feature: frequent V$SQL snapshots (6s resolution) — see SQL stats at any historical moment
- Activity Explorer: Gantt charts + timelines for any time window

**Why DBAs loved it vs OEM:**
- 1-2 second startup vs hours of OEM setup
- No agents, no server, no repository database
- 6-second resolution vs OEM's 60-minute AWR snapshots
- Native C/C++ responsiveness vs OEM's sluggish web UI

## Database System Views for Monitoring

### PostgreSQL
- `pg_stat_activity` — active sessions, wait events
- `pg_stat_statements` — SQL stats (requires extension)
- `pg_stat_user_tables` — table I/O stats
- `pg_locks` — lock contention
- `pg_stat_database` — database-level stats
- `pg_stat_io` — I/O stats (PG 16+)
- No built-in ASH equivalent (must poll pg_stat_activity yourself)

### BigQuery
- `INFORMATION_SCHEMA.JOBS` — job history (180 days)
- `INFORMATION_SCHEMA.JOBS_TIMELINE` — slot consumption (1s granularity)
- `INFORMATION_SCHEMA.TABLE_STORAGE` — table sizes

### Snowflake
- `ACCOUNT_USAGE.QUERY_HISTORY` — query history (365 days)
- `ACCOUNT_USAGE.WAREHOUSE_METERING_HISTORY` — credit usage
- `ACCOUNT_USAGE.WAREHOUSE_LOAD_HISTORY` — running/queued queries
- Note: ACCOUNT_USAGE views have 45min-3hr latency

### MySQL
- `performance_schema.events_statements_summary_by_digest` — SQL stats
- `performance_schema.threads` — active sessions
- `performance_schema.events_waits_*` — wait events
- `performance_schema.data_locks` — InnoDB locks (8.0+)
- `sys` schema — user-friendly views over performance_schema

## Existing CLI Monitoring Tools
- **pg_activity** — htop-like TUI for PostgreSQL (real-time only)
- **pgcenter** — top-like TUI with recording + report generation (closest to Lab128 for PG)
- **pgmetrics** — one-shot stats dump as text/JSON
- **pgbadger** — PostgreSQL log analyzer → HTML reports
