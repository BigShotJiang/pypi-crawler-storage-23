# Features: IDE Intelligence Adapted for Agents

This document maps database IDE features (DataGrip, DBeaver) to their agent-native equivalents.

---

## 1. Schema Introspection → Schema Context API

**IDE:** On connection, DataGrip silently queries `information_schema` to build a local metadata cache in three levels. Powers the tree view, auto-completion, and navigation.

**Agent problem:** LLMs waste turns writing `SHOW TABLES`, hallucinate column names, or get entire DDL dumps that blow out context windows.

**Our adaptation:**

```bash
# Quick orientation
tool schema tables --db prod-pg
# → orders (2.1M rows, 12 cols), users (340K rows, 8 cols), ...

# Column details for writing SQL
tool schema columns orders --db prod-pg
# → id: INT64 PK, user_id: INT64 FK→users.id, amount: DECIMAL(10,2) NOT NULL, ...

# Relationship graph
tool schema relationships --db prod-pg
# → orders.user_id → users.id (MANY-TO-ONE)
# → payments.order_id → orders.id (MANY-TO-ONE)

# Search by concept (keyword matching over table/column names + comments)
tool schema search "user subscription" --db prod-pg
# → Returns 2-3 most relevant tables with columns
```

---

## 2. ER Diagrams → Join Path Finder

**IDE:** DataGrip parses foreign keys to draw ER diagrams. Auto-completes JOIN conditions.

**Agent problem:** Agents are terrible at navigating normalized databases. They hallucinate JOIN conditions, creating cartesian products.

**Our adaptation:**

```bash
tool schema join-path users products --db prod-pg
# → users.id → orders.user_id → order_items.order_id → products.id
# → Suggested SQL:
# →   JOIN orders ON users.id = orders.user_id
# →   JOIN order_items ON orders.id = order_items.order_id
# →   JOIN products ON order_items.product_id = products.id
```

Implementation: BFS over FK graph built during introspection. No external dependencies.

---

## 3. Auto-Completion / Red Squiggles → Pre-Flight Validation

**IDE:** DataGrip underlines invalid column names in red before you run the query. Suggests corrections.

**Agent problem:** Agents hallucinate column names, get `column does not exist` errors, waste a full turn on schema discovery to fix it.

**Our adaptation:**

```bash
tool validate "SELECT usename, emial FROM users" --db prod-pg
# ❌ Column 'usename' not found in 'users'. Did you mean 'username'?
# ❌ Column 'emial' not found in 'users'. Did you mean 'email'?
# Available columns: id, username, email, created_at, status, ...
# Executed: 0 bytes (no database hit)
```

Implementation: Parse with polyglot-sql, extract column references, match against schema cache using Levenshtein distance.

---

## 4. Data Profiling / Calc Panel → Value Hinting

**IDE:** DBeaver's Calc panel shows COUNT, SUM, AVG, MIN, MAX. Grouping panel does ad-hoc GROUP BY.

**Agent problem (The Enum Trap):** Agent knows column is `status`, writes `WHERE status = 'Active'`. Database has `['active', 'pending', 'cancelled_user']`. Query returns 0 rows. Agent hallucinates "no data."

**Our adaptation:**

```bash
tool profile orders.status --db prod-pg
# Column: orders.status (VARCHAR)
# Distinct values: 5
# Null %: 0.0%
# Top values:
#   active         1,204,332  (57.3%)
#   pending          421,098  (20.0%)
#   completed        312,445  (14.9%)
#   cancelled_user   102,331  (4.9%)
#   refunded          61,234  (2.9%)

tool profile orders --db prod-pg
# Table: orders (2,101,440 rows)
# Column          Type           Nulls   Distinct   Min          Max
# id              INT64          0%      2,101,440  1            2101440
# amount          DECIMAL(10,2)  0%      48,332     0.01         9,999.99
# created_at      TIMESTAMP      0%      2,101,440  2020-01-01   2026-02-23
# status          VARCHAR        0%      5          -            -
```

Implementation: Auto-generated queries per column type. Runs lightweight aggregations, not full scans.

---

## 5. Query Inspections → Safety Checks

**IDE:** DataGrip detects DELETE without WHERE, constant conditions, type mismatches, unused subquery columns — all before execution.

**Agent problem:** Agents write structurally valid but dangerous queries. No one catches it before the database does.

**Our adaptation (built into the policy engine):**

| Inspection | Severity | Action |
|---|---|---|
| DELETE/UPDATE without WHERE | Error | Block execution |
| CROSS JOIN without condition | Warning | Warn about cartesian product |
| Constant WHERE (1=1, OR TRUE) | Warning | Possible injection |
| SELECT * on wide table (>20 cols) | Warning | Auto-expand to explicit columns |
| Multiple statements in one query | Error | Block (injection detection) |
| Implicit type cast | Warning | Performance impact |
| Missing LIMIT on SELECT | Info | Auto-inject LIMIT 1000 |
| Ambiguous column reference | Error | Require table qualifier |
| Unused subquery columns | Info | Could be optimized away |

---

## 6. Execution Plan Visualization → Plan Analysis

**IDE:** DataGrip shows EXPLAIN as tree, diagram, or flame chart with red highlights on bottlenecks.

**Agent problem:** Agents can request EXPLAIN but can't parse deeply nested JSON plan trees. Raw plans are unreadable for LLMs.

**Our adaptation:**

```bash
tool explain "SELECT * FROM events_raw WHERE user_id = 123" --db prod-pg
# Execution Plan Analysis:
# ⚠ Sequential Scan on events_raw (cost: 45,000, rows: 2.5M)
#   Filter: user_id = 123 (selectivity: 0.01%)
#
# Suggestions:
# - Table has no index on user_id. Consider: CREATE INDEX idx_events_user ON events_raw(user_id)
# - Table is partitioned by event_date. Adding WHERE event_date > ... would prune partitions

tool explain "SELECT * FROM events_raw" --db prod-bq
# Execution Plan Analysis:
# ⚠ Full table scan: 45.2 GB (~$0.23)
# Table is partitioned by event_date
# Suggestion: Add WHERE event_date >= '2026-01-01' to reduce scan to ~2.1 GB (~$0.01)
```

Implementation: Per-adapter EXPLAIN parsing. Start with high-signal patterns (full scan, missing partition filter, missing index), expand over time.

---

## 7. Schema Diff → Database Comparison

**IDE:** DataGrip compares schemas across servers, generates migration scripts.

**Our adaptation:**

```bash
tool diff prod-pg staging-pg
# Tables only in prod: audit_logs, legacy_users
# Tables only in staging: test_data
# Modified tables:
#   orders:
#     + column: shipping_method VARCHAR (staging only)
#     ~ column: amount DECIMAL(10,2) → DECIMAL(12,4) (type change)
```

Implementation: Introspect both databases, compare schema metadata, report differences. AST diff via polyglot-sql for DDL comparison.

---

## 8. DDL Generation → Schema Export

**IDE:** DataGrip generates CREATE TABLE statements for any object.

**Our adaptation:**

```bash
tool schema ddl orders --db prod-pg
# CREATE TABLE orders (
#   id BIGINT PRIMARY KEY,
#   user_id BIGINT NOT NULL REFERENCES users(id),
#   amount DECIMAL(10,2) NOT NULL,
#   status VARCHAR(20) NOT NULL DEFAULT 'pending',
#   created_at TIMESTAMP NOT NULL DEFAULT NOW()
# );
# CREATE INDEX idx_orders_user ON orders(user_id);
# CREATE INDEX idx_orders_created ON orders(created_at);
```

---

## 9. Dependency Tracking → Impact Analysis

**IDE:** DataGrip warns "This column is used in 3 views and 1 stored procedure" before DROP.

**Our adaptation:**

```bash
tool query "ALTER TABLE orders DROP COLUMN user_id" --db prod-pg --allow-write
# ⚠ IMPACT ANALYSIS:
# Column orders.user_id is referenced by:
#   - VIEW v_daily_active_users (line 3: SELECT ... FROM orders WHERE user_id ...)
#   - VIEW v_revenue_by_user (line 5: JOIN orders ON users.id = orders.user_id)
#   - FUNCTION calculate_ltv() (line 12: SELECT ... FROM orders WHERE user_id = $1)
#
# Dropping this column will break 2 views and 1 function.
# Proceed? [y/N]
```

Implementation: Parse view definitions and procedure source from L3 introspection cache. Use polyglot-sql to extract column references.

---

## 10. Mock Data Generation

**IDE:** DBeaver generates test data respecting PK, FK, UNIQUE, NOT NULL, data type constraints.

**Our adaptation:**

```bash
tool mock orders --rows 100 --db prod-pg
# Generated 100 rows respecting constraints:
#   - user_id: random from existing users.id values
#   - amount: DECIMAL(10,2) range [0.01, 9999.99]
#   - status: random from ['active', 'pending', 'completed', 'cancelled_user', 'refunded']
#   - created_at: random TIMESTAMP in [2020-01-01, now()]
#
# INSERT INTO orders (user_id, amount, status, created_at) VALUES ...
# Preview first 5 rows? [Y/n]
```
