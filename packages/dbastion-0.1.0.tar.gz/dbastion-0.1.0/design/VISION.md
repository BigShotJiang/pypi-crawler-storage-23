# Vision: Headless Data IDE for AI Agents

## One-liner

A governed database query proxy that gives AI agents the same intelligence a human gets from DataGrip — schema awareness, query validation, cost estimation, and performance monitoring — as a single CLI/MCP binary.

## The Problem

AI agents interacting with databases today face three failures:

1. **No schema awareness** — Agents hallucinate table/column names, guess JOIN conditions, write `SELECT *` on 200-column tables
2. **No safety layer** — Tools like Vanna AI execute whatever SQL the LLM generates with zero guardrails (no cost estimation, no write blocking, no injection detection)
3. **No operational intelligence** — Agents can't diagnose "why is this query slow?" or "is the database healthy?" without writing complex diagnostic SQL

## The Solution

A single binary with four engines:

```
┌──────────────────────────────────────────────┐
│           CLI / MCP / TUI Interface          │
├──────────────────────────────────────────────┤
│  1. INTROSPECTION    Schema cache, FK graph, │
│     ENGINE           value profiling, search │
├──────────────────────────────────────────────┤
│  2. POLICY           Parse, classify, guard, │
│     ENGINE           validate, enrich        │
├──────────────────────────────────────────────┤
│  3. EXECUTION        Multi-DB adapters,      │
│     ENGINE           dry-run, format, export │
├──────────────────────────────────────────────┤
│  4. MONITORING       Snapshots, deltas,      │
│     ENGINE           top-sql, history, cost  │
├──────────────────────────────────────────────┤
│  Local Store: DuckDB/Parquet                 │
│  Schema cache + monitoring snapshots         │
└──────────────────────────────────────────────┘
```

## Key Differentiators

### vs Google MCP Toolbox for Databases (13K stars)
- Toolbox is a **connectivity router** (44 databases, connection pooling, MCP server)
- It has no SQL parsing — uses a hand-written 350-line Go table parser for BigQuery only
- No cost estimation surfaced to agents, no query optimization, no transpilation
- **We are the SQL intelligence layer; Toolbox is the connectivity layer. Complementary, not competing.**

### vs Vanna AI (22K stars)
- Vanna is a **text-to-SQL generator** (natural language → SQL via LLM + RAG)
- Its SQL "validation" in v2.0 is `args.sql.strip().upper().split()[0]` — a string split
- No sqlglot (community proposed it in discussion #940, ignored by maintainers)
- Has a known RCE vulnerability (CVE-2024-5565) via `exec()` on LLM-generated Python
- **We don't generate SQL — we govern and execute SQL that agents (or Vanna) generate**

### vs ProxQL (4 stars)
- ProxQL is a **validation library** using sqlglot for table allowlists and write blocking
- It does not execute queries, estimate costs, or interact with any database
- **ProxQL validates the gap exists. We fill it end-to-end.**

### vs Database IDEs (DataGrip, DBeaver)
- IDEs provide schema introspection, validation, ER diagrams, profiling — but for human eyes
- **We provide the same intelligence as text-based APIs optimized for LLM token windows**

## The Missing Middle

```
VALIDATION ONLY (no execution)          EXECUTION ONLY (no guardrails)
┌──────────────────────┐                ┌──────────────────────┐
│ ProxQL (4 stars)     │                │ Google Toolbox (13K) │
│ guardrails-ai (2)    │                │ raw psql/bq/snowsql  │
│ mcp-sql-analyzer(26) │                │ MCP DB servers       │
└──────────────────────┘                └──────────────────────┘
            │                                      │
            └──────────── NOBODY HERE ─────────────┘
                     Parse + Guard + Execute
                     ← this project
```
