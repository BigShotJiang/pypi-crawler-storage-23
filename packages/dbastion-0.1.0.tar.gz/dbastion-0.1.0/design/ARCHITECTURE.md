# Architecture

## Technology Choice: Rust

### Why Rust
- **Single binary distribution** — `cargo install` or download binary, no runtime dependencies
- **~5ms CLI startup** — vs ~300ms for Python (import overhead)
- **Low memory collector** — predictable memory for long-running monitoring mode
- **Excellent ecosystem** — clap (CLI), axum (HTTP), ratatui (TUI), tokio (async)

### The Key Enabler: polyglot-sql

[polyglot-sql](https://github.com/tobilg/polyglot) is a **Rust reimplementation of sqlglot** — same design, same test suite (10,220 sqlglot fixture tests passing at 100%), native Rust crate.

| Feature | Python sqlglot | Rust polyglot-sql |
|---|---|---|
| Parsing (32+ dialects) | Yes | Yes |
| Transpilation | Yes | Yes |
| Query optimization (12 passes) | 14 passes | 12 passes |
| Column lineage | Yes | Yes (minor gaps in function calls) |
| Type annotation | Yes | Yes |
| AST diff | Yes | Yes |
| Query builder | Yes | Yes |
| Schema module | Yes | Yes |
| Scope analysis | Yes | Yes |
| Validation with error locations | Yes | Yes |

This eliminates the main argument for Python — we get full sqlglot-equivalent SQL analysis natively in Rust.

**Risks:** polyglot-sql is young (v0.1.5, ~5 weeks old, single maintainer). Mitigation: pin version, test our SQL patterns, contribute fixes upstream, prepared to fork if needed.

### Dependency Stack

```toml
[dependencies]
polyglot-sql = "0.1"        # SQL parsing, transpilation, lineage, optimization
clap = "4"                   # CLI framework
tokio = "1"                  # Async runtime
sqlx = "0.8"                 # Postgres, MySQL, SQLite drivers
duckdb = "1.0"               # Local snapshot store
serde = "1"                  # Serialization
serde_json = "1"             # JSON output
ratatui = "0.29"             # TUI (monitor live)
axum = "0.8"                 # HTTP server (collector mode, MCP)
```

---

## Four Engines

### Engine 1: Introspection (The Brain)

Runs on connection. Queries `information_schema` / system catalogs, caches locally.

**Three introspection levels** (inspired by DataGrip):

| Level | What's cached | Size | Use case |
|---|---|---|---|
| L1: Catalog | Database/schema names, table names, row count estimates | ~1KB | "What's in this database?" |
| L2: Structure | + columns (name, type, nullability), PKs, FKs, indexes | ~10-50KB | Writing correct SQL |
| L3: Full | + column comments/descriptions, view definitions, procedure signatures | ~50-200KB | Understanding business semantics |

**Schema services built on the cache:**
- `fuzzy_match("usename")` → "Did you mean `username`?" (Levenshtein distance)
- `search("user subscription")` → returns relevant tables (keyword matching)
- `join_path("users", "products")` → FK chain via BFS graph traversal
- `profile_column(table, col)` → `SELECT col, COUNT(*) GROUP BY 1 ORDER BY 2 DESC LIMIT 20`
- `dependencies(table)` → views and procedures that reference this table

### Engine 2: Policy (The Shield)

Uses polyglot-sql to parse every query into an AST before execution.

**Pipeline (each check returns allow/warn/block):**

1. **Schema validation** — column/table exists? Fuzzy suggest if not
2. **Classification** — READ / DML / DDL via AST type. Block writes unless `--allow-write`
3. **Safety inspections:**
   - DELETE/UPDATE without WHERE → block
   - CROSS JOIN without condition → warn
   - Constant WHERE (1=1) → warn (possible injection)
   - Multiple statements → block (injection detection)
   - Implicit type cast → warn
4. **Cost estimation** — adapter-specific dry-run, threshold gating
5. **Enrichment:**
   - Auto-LIMIT if missing (default 1000)
   - SELECT * expansion with schema
   - Pretty-format for output
6. **Dependency check** (DDL only) — warn if DROP affects views/procedures

### Engine 3: Execution (The Hands)

Database-specific adapters, each implementing a common trait:

```rust
trait DatabaseAdapter {
    async fn connect(&self, config: &ConnectionConfig) -> Result<()>;
    async fn introspect(&self, level: IntrospectionLevel) -> Result<SchemaMetadata>;
    async fn dry_run(&self, sql: &str) -> Result<CostEstimate>;
    async fn execute(&self, sql: &str) -> Result<ResultSet>;
    async fn explain(&self, sql: &str) -> Result<ExecutionPlan>;
    async fn profile_column(&self, table: &str, column: &str) -> Result<ColumnProfile>;
}
```

**Adapters (priority order):**
1. BigQuery (via REST API)
2. PostgreSQL (via sqlx)
3. MySQL (via sqlx)
4. Snowflake (via REST API)
5. DuckDB (via duckdb-rs)

**Output formats:**
- JSON (agent-friendly, default)
- Table (human-friendly)
- CSV / Parquet (export)

### Engine 4: Monitoring (The Diagnostician)

Inspired by Lab128 Oracle performance monitor. Client-side polling, local storage, delta computation.

**Two deployment modes:**

```
CLI Mode (laptop)              Collector Mode (near database)
─────────────────              ──────────────────────────────
Ad-hoc monitoring              Continuous 6-second polling
Polls directly or              Stores snapshots in DuckDB
queries collector API          Serves REST API for CLI clients
```

**What gets polled per database:**

| Database | Active Sessions | Top SQL | Wait Events | Locks | Cost |
|---|---|---|---|---|---|
| PostgreSQL | pg_stat_activity | pg_stat_statements (deltas) | wait_event | pg_locks | N/A |
| MySQL | performance_schema.threads | events_statements_summary (deltas) | events_waits_summary | data_locks | N/A |
| BigQuery | N/A (serverless) | INFORMATION_SCHEMA.JOBS | N/A | N/A | total_bytes_billed |
| Snowflake | N/A (serverless) | QUERY_HISTORY | N/A | N/A | credits_used |

**Local snapshot store:**
```
~/.config/tool-name/snapshots/
├── prod-pg/
│   ├── activity.parquet      # 6s resolution
│   ├── statements.parquet    # 30s resolution, deltas
│   └── rollups/hourly/       # aggregated, indefinite
└── prod-bq/
    └── jobs.parquet          # cached INFORMATION_SCHEMA.JOBS
```

---

## CLI Interface

```bash
# Connection management
tool connect <name> --type postgres --host ... --introspect
tool connections list

# Schema browsing
tool schema tables --db prod-pg
tool schema columns <table> --db prod-pg
tool schema relationships --db prod-pg
tool schema search "user subscription" --db prod-pg

# Query execution (guarded)
tool query "SELECT * FROM orders" --db prod-pg
tool validate "SELECT usename FROM users" --db prod-pg
tool estimate "SELECT * FROM big_table" --db prod-bq
tool explain "SELECT ..." --db prod-pg

# SQL tools
tool format "select a,b from t" --dialect bigquery
tool transpile "SELECT ..." --from postgres --to bigquery
tool lineage "amount" --sql "SELECT a*b AS amount FROM ..."

# Data profiling
tool profile orders --db prod-pg
tool profile orders.status --db prod-pg

# Schema management
tool diff prod-pg staging-pg
tool export "SELECT ..." --db prod-pg --format csv

# Monitoring
tool monitor activity --db prod-pg
tool monitor top-sql --db prod-pg --sort total_time
tool monitor locks --db prod-pg
tool monitor cost --db prod-bq --from 7d
tool monitor live --db prod-pg                    # TUI dashboard
tool monitor history --db prod-pg --at "2026-02-22 03:47"

# Collector mode (deployed near database)
tool collector start --db prod-pg --interval 6s --listen :9128
```

---

## MCP Server Mode

Any MCP-compatible agent (Claude Desktop, Cursor, Windsurf) can connect:

```json
{
  "mcpServers": {
    "db": {
      "command": "tool-name",
      "args": ["mcp"]
    }
  }
}
```

Exposes all commands as MCP tools. Schema context injected into tool responses automatically.
