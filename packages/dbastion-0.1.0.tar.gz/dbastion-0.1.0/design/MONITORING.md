# Monitoring Engine

Inspired by Lab128 Oracle Performance Monitor — lightweight, client-side, high-frequency telemetry adapted for modern cloud-native databases.

## Lab128 Philosophy

Lab128 (discontinued ~2017) was an Oracle DBA's secret weapon:
- **Pure client-side C/C++** — no agents on the database server
- **Polled V$ views every 6 seconds** — stored 60 days of data locally
- **Delta computation** — transformed cumulative counters into rates
- **Instant time-travel** — click any moment in the last 60 days, see everything

The genius: compute everything client-side, minimize database load.

## Cloud-Native Adaptation

Lab128 assumed on-premise: client and database on the same LAN. Cloud changes this:

| Scenario | Approach |
|---|---|
| **Serverless DB (BigQuery, Snowflake)** | No polling needed — history stored server-side (JOBS: 180d, QUERY_HISTORY: 365d). Query and analyze on demand |
| **Managed DB (Cloud SQL, RDS)** | Collector mode — deploy near database, poll continuously, serve API to remote CLI clients |
| **Local dev (localhost, Docker)** | Lab128 mode — CLI polls directly, stores locally |

## Two Deployment Modes, One Binary

```
CLI Mode (developer laptop)         Collector Mode (near database)
───────────────────────────         ──────────────────────────────
tool monitor activity --db x        tool collector start --db x
  │                                   --interval 6s --listen :9128
  │                                   │
  ├─ Has collector? → query API       ├─ Polls pg_stat_activity (6s)
  ├─ Is localhost?  → poll directly   ├─ Polls pg_stat_statements (30s)
  └─ Is serverless? → query system    ├─ Computes deltas locally
     views directly                   ├─ Stores in DuckDB/Parquet
                                      └─ Serves REST API
```

## What Gets Polled

### PostgreSQL
| View | Interval | Purpose |
|---|---|---|
| `pg_stat_activity` | 6s | Active sessions, wait events, query text |
| `pg_stat_statements` | 30s | SQL stats (compute deltas: calls, time, rows, blocks) |
| `pg_stat_user_tables` | 60s | Table I/O (seq scans, idx scans, tuples) |
| `pg_locks` | 6s | Lock contention, blocking chains |
| `pg_stat_database` | 60s | DB-level stats (commits, rollbacks, blocks) |
| `pg_stat_bgwriter` | 60s | Background writer, checkpoints |

### MySQL
| View | Interval | Purpose |
|---|---|---|
| `performance_schema.threads` | 6s | Active sessions |
| `events_statements_summary_by_digest` | 30s | SQL stats (deltas) |
| `events_waits_summary_global` | 30s | Wait events |
| `data_locks` + `innodb_lock_waits` | 6s | Lock contention |

### BigQuery (on-demand, no polling)
| View | Purpose |
|---|---|
| `INFORMATION_SCHEMA.JOBS` | Job history (180 days): query text, bytes processed, slot_ms, cache hit |
| `INFORMATION_SCHEMA.JOBS_TIMELINE` | Slot consumption over time (1-second granularity) |

### Snowflake (on-demand, no polling)
| View | Purpose |
|---|---|
| `ACCOUNT_USAGE.QUERY_HISTORY` | Query history (365 days): execution_time, bytes_scanned, warehouse |
| `ACCOUNT_USAGE.WAREHOUSE_METERING_HISTORY` | Credit usage per warehouse |

## CLI Commands

```bash
# Current state
tool monitor activity --db prod-pg         # Active sessions + wait events
tool monitor top-sql --db prod-pg          # Top SQL by time/reads/rows
tool monitor locks --db prod-pg            # Lock trees (who blocks whom)
tool monitor waits --db prod-pg            # Wait event breakdown

# Cost tracking (serverless)
tool monitor cost --db prod-bq --from 7d   # Bytes/dollars over time
tool monitor cost --db prod-sf --from 30d  # Credits over time

# Historical (requires collector or serverless)
tool monitor history --db prod-pg --at "2026-02-22 03:47" --window 30m
tool monitor report --db prod-pg --from 24h --sort total_time

# Live TUI dashboard
tool monitor live --db prod-pg

# Collector management
tool collector start --db prod-pg --interval 6s --listen :9128
tool collector status
```

## Output: Semantic Telemetry for Agents

LLMs can't read graphs. They need dense, token-optimized text summaries.

### Activity summary (JSON, agent-friendly)
```json
{
  "active_sessions": 12,
  "idle_in_transaction": 3,
  "waiting_on_lock": 2,
  "longest_query_sec": 847,
  "top_wait_event": "IO:DataFileRead (4 sessions, 42%)",
  "bottleneck": {
    "pid": 12345,
    "duration": "14m 07s",
    "wait": "IO:DataFileRead",
    "operation": "Sequential Scan on historical_logs",
    "query_preview": "SELECT ... FROM historical_logs WHERE ..."
  }
}
```

### Lock tree (resolved, not raw)
```json
{
  "blocking_chains": [
    {
      "root_blocker": {"pid": 8932, "state": "idle in transaction", "duration": "23m"},
      "lock_type": "ExclusiveLock",
      "table": "orders",
      "blocked_pids": [102, 103, 104],
      "suggestion": "PID 8932 has been idle in transaction for 23 minutes. Consider terminating."
    }
  ]
}
```

### Context injection (1-line vitals)
Every tool response can include a system vitals header:
```
[DB: prod-pg | Active: 12 | Locks: 2 | Longest query: 14m | Load: HIGH]
```
Agent sees this and can autonomously defer heavy queries during high load.

## Local Snapshot Store

```
~/.config/tool-name/snapshots/
├── prod-pg/
│   ├── activity/          # Parquet files, 6s resolution
│   ├── statements/        # Parquet files, 30s resolution, deltas
│   ├── tables/            # Parquet files, 60s resolution
│   ├── rollups/hourly/    # Aggregated for long-term retention
│   └── meta.json          # Config: intervals, retention, last poll
└── prod-bq/
    └── jobs/              # Cached INFORMATION_SCHEMA.JOBS
```

**Storage engine:** DuckDB (columnar, fast analytical queries, zero-server, Parquet-native).

**Retention:**
- Raw snapshots: 14 hours in memory, 7 days on disk
- Hourly rollups: 60 days
- Daily rollups: indefinite

## Collector API

```
GET /health                        → system vitals one-liner
GET /activity/current              → latest activity snapshot
GET /activity/history?from=&to=    → time-range query
GET /top-sql?sort=time&limit=10    → top SQL in time range
GET /locks/tree                    → resolved blocking chains
GET /waits/summary                 → wait event breakdown
GET /stats/{metric}?from=&to=      → any metric over time
GET /cost?from=&to=                → cost tracking (serverless DBs)
```

## Deployment

```bash
# Docker (sidecar next to Cloud SQL Proxy)
docker run -d --name tool-collector \
  -e DB_HOST=10.0.0.5 -e DB_PORT=5432 \
  -e DB_USER=monitor \
  -p 9128:9128 -v /data/snapshots:/data \
  tool-name/collector

# Kubernetes sidecar (same pod as app)
# Cloud Run job (periodic sync for serverless DBs)
# Standalone VM (monitors multiple databases)
```
