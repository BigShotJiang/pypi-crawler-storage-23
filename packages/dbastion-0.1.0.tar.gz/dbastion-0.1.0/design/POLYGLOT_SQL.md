# polyglot-sql: Rust SQL Analysis Engine

The core SQL analysis dependency. A Rust reimplementation of Python's sqlglot.

## Project Info
- **URL:** https://github.com/tobilg/polyglot
- **Crate:** https://crates.io/crates/polyglot-sql (v0.1.5)
- **License:** MIT (acknowledges sqlglot origin in licenses/SQLGLOT_LICENSE.md)
- **Stars:** 585 | **Created:** January 2026
- **Tests:** 18,629 total (10,220 sqlglot fixture tests), 100% pass rate
- **Dependencies:** Zero external (serde, thiserror, unicode-segmentation only)

## Supported Dialects (32)

### Cloud Data Warehouses
BigQuery, Snowflake, Redshift, Databricks, Fabric

### Query Engines
Presto, Trino, Athena, Spark, Spark2, Hive, Dremio

### OLTP Databases
MySQL, PostgreSQL, Oracle, TSQL (SQL Server), SQLite, SingleStore

### OLAP / Analytical
ClickHouse, DuckDB, Druid, StarRocks, Doris, Exasol, Teradata

### Streaming / Realtime
Materialize, RisingWave

### Specialized
Drill, Dune, Solr, Tableau, PRQL

## Feature Matrix

| Feature | Available | Module |
|---|---|---|
| Parse SQL → AST | Yes | `parse()`, `parse_one()` |
| Generate AST → SQL | Yes | `generate()` |
| Transpile between dialects | Yes | `transpile()` |
| Pretty-print / format | Yes | Generator with formatting options |
| Validate with error locations | Yes | `validate()` |
| AST traversal (DFS, BFS, find, transform) | Yes | `traversal` module |
| Table extraction | Yes | `get_tables()`, `get_table_names()` |
| Column extraction | Yes | `get_columns()`, `get_column_names()` |
| Column lineage | Yes | `lineage` module |
| Scope analysis | Yes | `scope` module |
| Optimizer (12 passes) | Yes | `optimizer` module |
| Type annotation | Yes | `annotate_types` |
| AST diff | Yes | `diff` module |
| Query builder (fluent API) | Yes | `builder` module |
| Schema module | Yes | `schema` module |
| Custom dialects | Yes | `CustomDialectBuilder` |

## Optimizer Passes

1. Qualify columns/tables (fully qualify all references)
2. Pushdown predicates (move WHERE into subqueries/joins)
3. Pushdown projections (select only needed columns)
4. Normalize boolean expressions
5. Simplify expressions (`NOT FALSE AND x = x` → `x = x`)
6. Optimize joins
7. Eliminate CTEs (remove unused)
8. Eliminate joins (remove no-effect joins)
9. Unnest/merge subqueries
10. Annotate types
11. Canonicalize
12. Quote identifiers

## Usage Examples (Rust)

### Basic transpilation
```rust
use polyglot_sql::{transpile, DialectType};

let result = transpile(
    "SELECT IFNULL(a, b) FROM t",
    DialectType::MySQL,
    DialectType::Postgres,
).unwrap();
// result[0] == "SELECT COALESCE(a, b) FROM t"
```

### Parse + inspect
```rust
use polyglot_sql::{parse, DialectType};
use polyglot_sql::traversal::{get_tables, get_columns};

let ast = parse(
    "SELECT a, b FROM users JOIN orders ON users.id = orders.user_id",
    DialectType::Generic,
).unwrap();

let tables = get_tables(&ast[0]);   // ["users", "orders"]
let columns = get_columns(&ast[0]); // ["a", "b", "users.id", "orders.user_id"]
```

### Optimization
```rust
use polyglot_sql::{parse_one, generate, DialectType};
use polyglot_sql::optimizer::{optimize, OptimizerConfig};

let expr = parse_one(
    "SELECT * FROM t WHERE 1 = 1 AND x > 5",
    DialectType::Generic,
).unwrap();

let optimized = optimize(expr, &OptimizerConfig::default());
let sql = generate(&optimized, DialectType::Generic).unwrap();
// Simplified: WHERE 1=1 removed, etc.
```

### Column lineage
```rust
use polyglot_sql::lineage::lineage;
use polyglot_sql::DialectType;

let node = lineage(
    "col_a",
    "SELECT col_a FROM (SELECT x AS col_a FROM t)",
    Some(DialectType::Generic),
    false,
).unwrap();

for n in node.walk() {
    println!("{}", n.name);
}
```

### Validation
```rust
use polyglot_sql::{validate, DialectType};

let result = validate("SELECT * FORM users", DialectType::Generic);
// Returns errors with line/column info
```

### Query builder
```rust
use polyglot_sql::builder::*;

let query = select(["id", "name"])
    .from("users")
    .where_(col("age").gt(lit(18)))
    .order_by(["name"])
    .limit(10)
    .build();
```

## How We Use It

| Our feature | polyglot-sql API |
|---|---|
| Query classification (READ/DML/DDL) | Parse → check AST root type |
| Table extraction (for schema validation) | `get_tables()` + scope analysis |
| Column extraction (for fuzzy matching) | `get_columns()` |
| Write blocking | AST type check for INSERT/UPDATE/DELETE/DROP/CREATE |
| Auto-LIMIT injection | Parse → check for Limit node → modify AST → regenerate |
| SELECT * expansion | Parse → find Star node → replace with column list from schema → regenerate |
| SQL formatting | `generate()` with pretty-print options |
| Transpilation | `transpile(sql, read_dialect, write_dialect)` |
| Column lineage | `lineage(column, sql, dialect)` |
| Query optimization | `optimize(ast, config)` |
| Schema diff | Parse DDL → `diff(ast1, ast2)` |
| Safety inspections | Parse → traverse AST for dangerous patterns |
| Injection detection | `parse()` returns multiple statements → block |

## Known Issues (as of v0.1.5)

- **#18:** Column lineage lost inside function calls (e.g., `COALESCE(a, b)` doesn't trace `a` and `b`)
- **#19:** Schema validation fails on valid queries containing CTEs
- **#17:** PostgreSQL `::schema.type` cast syntax produces invalid output
- **#21:** Table extraction includes CTE names (should be excluded)

## Risk Mitigation

1. **Pin version** in Cargo.toml — don't auto-upgrade
2. **Test our specific SQL patterns** — build a test suite of real queries from our target databases
3. **Contribute fixes upstream** — become an active contributor, especially for issues #17-#21
4. **Fork readiness** — if maintainer goes inactive, we can fork (MIT license)
5. **Fallback to sqlparser-rs** — for parsing-only features (classification, table extraction), sqlparser-rs (4K stars, mature) is a backup. We lose transpilation/lineage/optimization but guardrails still work.
