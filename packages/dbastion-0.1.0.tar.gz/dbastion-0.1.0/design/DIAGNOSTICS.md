# Diagnostics: Rust Compiler-Inspired SQL Error Reporting

Adapted from rustc's diagnostic system (RFC 1644, `annotate-snippets` crate) for SQL query analysis.

## Design Principle

> Errors should focus on the code you wrote.

Every diagnostic points into the user's SQL, labels what's wrong, explains why, and suggests how to fix it — with machine-applicable fixes auto-applied before execution.

## Anatomy of a Diagnostic

```
error[Q0012]: column 'usename' not found in 'users'
  --> query:1:8
   |
 1 | SELECT usename, emial FROM users WHERE status = 'Active'
   |        ^^^^^^^ help: similar column exists: `username`
   |
   = note: available columns: id, username, email, created_at, status
```

| Part | Purpose |
|---|---|
| **Level** | `error` / `warning` / `info` — colored in terminal |
| **Error code** | `[Q0012]` — stable, searchable, documentable |
| **Message** | Main description, lowercase, no period |
| **Location** | `query:1:8` — line:column into the SQL text |
| **Code window** | The user's SQL with underlines on the problem |
| **Primary label** (`^^^^`) | What is wrong |
| **Secondary label** (`----`) | Why it is wrong (context) |
| **Notes** (`= note:`) | Extra context (available columns, actual values, types) |
| **Help** (`= help:`) | How to fix it |

## Diagnostic Levels

| Level | Meaning | Blocks execution? | Color |
|---|---|---|---|
| `Error` | Cannot execute this query | Yes | Red |
| `Warning` | Suspicious but executable | No (unless `--strict`) | Yellow |
| `Info` | Enrichment applied automatically | No | Blue |

## Suggestion Applicability

Directly from rustc's `Applicability` enum — controls whether fixes are auto-applied.

| Applicability | Meaning | Auto-apply? | SQL example |
|---|---|---|---|
| `MachineApplicable` | Definitely correct fix | Yes | `LIMIT 1000` injection, `usename` → `username` (edit distance 1, unique match) |
| `MaybeIncorrect` | Plausible but uncertain | No, show suggestion | `'Active'` → `'active'` (could be intentional) |
| `HasPlaceholders` | Needs human input | No, show template | "Add WHERE clause: `WHERE <condition>`" |

### Auto-Healing Flow

```
Agent submits SQL
  → Parse (polyglot-sql)
  → Run all checks → Vec<Diagnostic>
  → Partition: MachineApplicable vs rest
  → Auto-apply MachineApplicable fixes to SQL
  → Execute the healed SQL
  → Return results + ALL diagnostics (agent learns from corrections)
```

## Error Code Registry

Codes are namespaced by engine:

| Range | Engine | Examples |
|---|---|---|
| `Q01xx` | Schema validation | Q0101 table not found, Q0102 column not found |
| `Q02xx` | Safety checks | Q0201 DELETE without WHERE, Q0202 multiple statements |
| `Q03xx` | Classification | Q0301 write blocked, Q0302 DDL blocked |
| `Q04xx` | Cost estimation | Q0401 over threshold, Q0402 full table scan |
| `Q05xx` | Data warnings | Q0501 value not in column, Q0502 type mismatch |
| `Q06xx` | Enrichment (info) | Q0601 LIMIT injected, Q0602 SELECT * expanded |

## Examples

### Column Not Found (with fuzzy suggestion)

```
error[Q0102]: column 'usename' not found in 'users'
  --> query:1:8
   |
 1 | SELECT usename, emial FROM users WHERE status = 'Active'
   |        ^^^^^^^ help: similar column exists: `username`
   |                ^^^^^ help: similar column exists: `email`
   |
   = note: available columns: id, username, email, created_at, status
```

If edit distance ≤ 2 and unique match → `MachineApplicable` (auto-fix).

### DELETE Without WHERE

```
error[Q0201]: DELETE without WHERE clause
  --> query:1:1
   |
 1 | DELETE FROM orders
   | ^^^^^^ ----------- this affects all 2,101,440 rows
   | |
   | statement blocked for safety
   |
   = help: add a WHERE clause, or pass `--allow-unsafe` to override
```

Always `HasPlaceholders` — we can't guess the WHERE clause.

### Enum Trap (value not found)

```
warning[Q0501]: value 'Active' not found in column 'orders.status'
  --> query:1:44
   |
 1 | SELECT * FROM orders WHERE status = 'Active'
   |                                      ^^^^^^^^
   |
   = note: column 'status' contains: 'active' (57%), 'pending' (20%),
           'completed' (15%), 'cancelled_user' (5%), 'refunded' (3%)
   = help: did you mean 'active'? (case-sensitive match)
```

`MaybeIncorrect` — the case difference is a strong signal but could be intentional.

### Auto-LIMIT Injection (info)

```
info[Q0601]: LIMIT 1000 added to unbounded SELECT
  --> query:1:1
   |
 1 | SELECT id, name FROM users
   | ^^^^^^ query had no LIMIT clause
   |
   = note: override with `--no-limit` or `--limit N`
```

`MachineApplicable` — always auto-applied.

### SELECT * Expansion (info)

```
info[Q0602]: expanded SELECT * to 12 explicit columns
  --> query:1:8
   |
 1 | SELECT * FROM orders
   |        ^ expanded to: id, user_id, amount, status, created_at, ...
   |
   = note: table 'orders' has 12 columns. Full list in schema cache.
```

`MachineApplicable` — always auto-applied on wide tables.

### Cost Over Threshold

```
warning[Q0401]: estimated cost exceeds threshold
  --> query:1:1
   |
 1 | SELECT * FROM events_raw WHERE user_id = 123
   | ------
   |
   = note: estimated scan: 45.2 GB (~$0.23)
   = note: threshold: 10 GB (configurable via --cost-limit)
   = help: table is partitioned by event_date — add WHERE event_date >= '...'
           to reduce scan to ~2.1 GB (~$0.01)
```

### Multiple Statements (injection detection)

```
error[Q0202]: multiple statements detected
  --> query:1:32
   |
 1 | SELECT * FROM users; DROP TABLE users
   |                     ^ second statement starts here
   |
   = note: only single statements are allowed (possible SQL injection)
   = help: split into separate `tool query` calls if intentional
```

### Multi-Span: Type Mismatch in JOIN

```
warning[Q0502]: type mismatch in JOIN condition
  --> query:1:46
   |
 1 | SELECT * FROM orders JOIN users ON orders.user_id = users.email
   |                                    -------------- ~~~~~~~~~~~~
   |                                    |              |
   |                                    INT64          VARCHAR
   |
   = note: implicit cast may cause performance degradation or unexpected results
   = help: did you mean `users.id` (INT64)?
```

## Rendering

### Terminal (human)

Use `annotate-snippets` crate (same renderer rustc is migrating to):

```toml
annotate-snippets = "0.11"
```

Provides colored output with span underlines, labels, and elision — zero custom rendering code.

### JSON (agent)

```json
{
  "diagnostics": [
    {
      "level": "error",
      "code": "Q0102",
      "message": "column 'usename' not found in 'users'",
      "spans": [
        {
          "start": 7,
          "end": 14,
          "line": 1,
          "column": 8,
          "label": "similar column exists: `username`",
          "is_primary": true
        }
      ],
      "notes": ["available columns: id, username, email, created_at, status"],
      "suggestions": [
        {
          "message": "replace with `username`",
          "start": 7,
          "end": 14,
          "replacement": "username",
          "applicability": "MachineApplicable"
        }
      ]
    }
  ],
  "original_sql": "SELECT usename FROM users",
  "healed_sql": "SELECT username FROM users",
  "applied_fixes": ["Q0102: usename → username"],
  "execution_blocked": false
}
```

The agent gets both the structured diagnostics and the healed SQL. It learns from the corrections implicitly.
