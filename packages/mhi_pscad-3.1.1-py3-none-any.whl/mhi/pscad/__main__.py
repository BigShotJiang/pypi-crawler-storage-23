"""
PSCAD Automation Library
"""

import mhi.common
import mhi.pscad
import mhi.help

from mhi.common.zipper import LibraryZipper
from mhi.pscad.buildtime import BUILD_TIME


def version():
    """Display package version info"""

    print(f"MHI PSCAD Library v{mhi.pscad.VERSION} ({BUILD_TIME})")
    print("(c) Manitoba Hydro International Ltd.")
    print()
    print(mhi.common.version_msg())


if __name__ == '__main__':
    main = mhi.help.Main(mhi.pscad, version)
    updater = LibraryZipper('PSCAD', 'mhi.pscad', 'mhi.common')
    updater.add_subparser(main._subparsers)
    main()
