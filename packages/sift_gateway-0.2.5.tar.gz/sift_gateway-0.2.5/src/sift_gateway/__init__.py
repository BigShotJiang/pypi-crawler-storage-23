"""Expose the public version string for the package.

Sift is a local, single-tenant MCP proxy that
intercepts upstream tool results and stores them as durable,
content-addressed artifact envelopes.
"""

__version__ = "0.2.5"
__all__ = ["__version__"]
