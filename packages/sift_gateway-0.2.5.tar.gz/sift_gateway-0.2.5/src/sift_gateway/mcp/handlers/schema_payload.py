"""Shared schema-payload normalization helpers for handler modules."""

from sift_gateway.core.schema_payload import build_schema_payload

__all__ = ["build_schema_payload"]
