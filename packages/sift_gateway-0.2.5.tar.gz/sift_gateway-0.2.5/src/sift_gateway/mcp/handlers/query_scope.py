"""Shared helpers for scope and cursor-position resolution in handlers."""

from __future__ import annotations

from sift_gateway.core.query_scope import resolve_cursor_offset, resolve_scope

__all__ = ["resolve_cursor_offset", "resolve_scope"]
