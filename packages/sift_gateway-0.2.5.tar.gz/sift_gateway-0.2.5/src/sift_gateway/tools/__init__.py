"""Gateway tool validation, SQL, and response-building helpers."""
