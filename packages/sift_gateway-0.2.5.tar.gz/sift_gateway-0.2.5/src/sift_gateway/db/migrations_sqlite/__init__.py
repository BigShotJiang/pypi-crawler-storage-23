"""SQLite-specific database migration scripts."""
