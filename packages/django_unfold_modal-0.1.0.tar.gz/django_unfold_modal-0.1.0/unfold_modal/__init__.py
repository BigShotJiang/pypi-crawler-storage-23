"""Unfold Modal - Modal-based related-object popups for django-unfold."""

__version__ = "0.1.0"
