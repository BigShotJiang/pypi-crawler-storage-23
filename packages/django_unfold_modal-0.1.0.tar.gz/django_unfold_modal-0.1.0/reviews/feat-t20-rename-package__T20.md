# Review: feat/t20-rename-package — T20

**Status: DONE**

## Scope
Package rename from `django_unfold_modal` → `unfold_modal`, distribution `django-unfold-modal` → `unfold-modal`. No behavioral changes.

## Codex CLI Result
No issues found.

## Test Result
97 passed, 7 warnings (pytest -q + playwright chromium)
