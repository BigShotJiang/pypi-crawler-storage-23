# Review: feat/t20a-dist-name-alignment — T20a

**Status: DONE**

## Scope
Revert distribution name to `django-unfold-modal` (pyproject.toml). Keep `unfold_modal` as import/app name. Add naming note to README.

## Codex CLI Result
No issues found.

## Test Result
97 passed, 7 warnings (pytest -q + playwright chromium)
