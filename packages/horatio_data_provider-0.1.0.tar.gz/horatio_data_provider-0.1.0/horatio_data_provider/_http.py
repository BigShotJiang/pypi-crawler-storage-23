import io

import httpx
import pandas as pd
import pyarrow.parquet as pq

from .exceptions import DataProviderHTTPError


async def fetch_parquet(session: httpx.AsyncClient, url: str, body: dict) -> pd.DataFrame:
    response = await session.post(url, json=body)
    content_type = response.headers.get("content-type", "")
    if "application/json" in content_type:
        data = response.json()
        raise DataProviderHTTPError(response.status_code, data.get("error", str(data)))
    response.raise_for_status()
    return pq.read_table(io.BytesIO(response.content)).to_pandas()
