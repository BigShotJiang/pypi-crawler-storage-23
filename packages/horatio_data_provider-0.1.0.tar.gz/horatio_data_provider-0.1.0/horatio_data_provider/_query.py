import httpx
import pandas as pd

from ._http import fetch_parquet


class BaseQuery:
    def __init__(self, session: httpx.AsyncClient, base_url: str, body: dict):
        self._session = session
        self._base_url = base_url
        self._body = body

    def network(self, n: str) -> "BaseQuery":
        self._body["network"] = n
        return self

    def time_range(self, since: str, until: str) -> "BaseQuery":
        self._body["since"] = since
        self._body["until"] = until
        return self


class CacheableQuery(BaseQuery):
    def cache(self, cache_type: str = "append") -> "CacheableQuery":
        self._body["cache"] = True
        self._body["cache_type"] = cache_type
        return self


class EventQuery(BaseQuery):
    def __init__(self, session: httpx.AsyncClient, base_url: str, path: str, body: dict):
        super().__init__(session, base_url, body)
        self._path = path

    async def fetch(self) -> pd.DataFrame:
        return await fetch_parquet(self._session, self._base_url + self._path, self._body)
