import httpx
import pandas as pd

from ._http import fetch_parquet
from ._query import BaseQuery, CacheableQuery


class RawTradesQuery(CacheableQuery):
    def __init__(self, session: httpx.AsyncClient, base_url: str, token: str):
        super().__init__(session, base_url, {"token": token})

    async def fetch(self) -> pd.DataFrame:
        return await fetch_parquet(self._session, self._base_url + "/binance/raw_trades/read", self._body)


class OHLCVQuery(BaseQuery):
    def __init__(self, session: httpx.AsyncClient, base_url: str, token: str, window: str):
        super().__init__(session, base_url, {"token": token, "window": window})

    async def fetch(self) -> pd.DataFrame:
        return await fetch_parquet(self._session, self._base_url + "/binance/ohlcv/read", self._body)


class BinanceNamespace:
    def __init__(self, session: httpx.AsyncClient, base_url: str):
        self._session = session
        self._base_url = base_url

    def raw_trades(self, token: str) -> RawTradesQuery:
        return RawTradesQuery(self._session, self._base_url, token)

    def ohlcv(self, token: str, window: str) -> OHLCVQuery:
        return OHLCVQuery(self._session, self._base_url, token, window)

    async def flush_raw_trades(self, token: str | None = None) -> None:
        body = {}
        if token is not None:
            body["token"] = token
        await self._session.post(self._base_url + "/binance/raw_trades/flush", json=body)
