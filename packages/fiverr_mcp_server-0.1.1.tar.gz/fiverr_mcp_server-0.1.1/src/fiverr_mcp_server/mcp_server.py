from mcp.server.fastmcp import FastMCP

from fiverr_mcp_server.utils.scraper import FiverrScraper

mcp = FastMCP("Fiverr")
scraper = FiverrScraper()
