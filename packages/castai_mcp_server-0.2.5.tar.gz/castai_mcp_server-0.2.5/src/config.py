#!/usr/bin/env python3
"""
Configuration module for CAST.AI External MCP Server.

Loads environment variables and validates required configuration.
"""

import os


# API configuration
API_BASE_URL = os.getenv("CASTAI_API_URL", "https://api.cast.ai")
API_KEY = os.getenv("CASTAI_API_KEY", "")
