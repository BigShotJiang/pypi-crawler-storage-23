# -*- coding: utf-8 -*-

import json
import time
from dataclasses import dataclass

from PySide6.QtCore import QEventLoop, QObject, Signal
from PySide6.QtNetwork import QNetworkReply, QNetworkRequest

from qgitc.applicationbase import ApplicationBase
from qgitc.common import logger
from qgitc.events import LoginFinished, RequestLoginGithubCopilot
from qgitc.llm import AiModelBase, AiModelFactory, AiParameters, AiRole
from qgitc.settings import Settings


def _makeHeaders(token: str, intent: bytes = b"conversation-other"):
    return {
        b"authorization": f"Bearer {token}".encode("utf-8"),
        b"copilot-integration-id": b"vscode-chat",
        b"editor-plugin-version": b"copilot-chat/0.27.2",
        b"editor-version": b"vscode/1.97.2",
        b"openai-intent": intent,
        b"user-agent": b"GithubCopilotChat/0.27.2",
        b"x-github-api-version": b"2025-05-01",
    }


@dataclass
class AiModelCapabilities:

    streaming: bool = True
    tool_calls: bool = False
    max_output_tokens: int = 4096


class ModelsFetcher(QObject):

    finished = Signal()

    def __init__(self, token: str, url_prefix: str, parent=None):
        super().__init__(parent)
        self.models = []
        self.capabilities = {}
        self.endPoints = {}
        self.defaultModel = None
        self._token = token
        self._reply: QNetworkReply = None
        self._url_prefix = url_prefix

    def start(self):
        url = f"{self._url_prefix}/models"
        headers = _makeHeaders(self._token, b"model-access")

        mgr = ApplicationBase.instance().networkManager
        request = QNetworkRequest()
        request.setUrl(url)

        for key, value in headers.items():
            request.setRawHeader(key, value)

        self._reply = mgr.get(request)
        self._reply.finished.connect(self._onFinished)
        logger.debug(f"Fetching GitHub Copilot models...")

    def _onFinished(self):
        reply = self._reply
        reply.deleteLater()
        self._reply = None
        logger.debug(
            f"GitHub Copilot models fetch finished with error code {reply.error()}")
        if reply.error() != QNetworkReply.NoError:
            return

        model_list = json.loads(reply.readAll().data())
        if not model_list or "data" not in model_list:
            return
        for model in model_list["data"]:
            id = model.get("id")
            if not id:
                continue
            if not model.get("model_picker_enabled", True):
                continue

            caps: dict = model.get("capabilities", {})
            type = caps.get("type", "chat")
            if type != "chat":
                continue

            supports: dict = caps.get("supports", {})
            limits: dict = caps.get("limits", {})

            modelCaps = AiModelCapabilities(
                supports.get("streaming", False),
                supports.get("tool_calls", False)
            )
            modelCaps.max_output_tokens = limits.get(
                "max_output_tokens", 4096)
            self.capabilities[id] = modelCaps

            name = model.get("name")
            self.models.append((id, name or id))

            if model.get("is_chat_default", False):
                self.defaultModel = id

            endpoints = model.get("supported_endpoints", [])
            self.endPoints[id] = endpoints

        self.finished.emit()

    def requestInterruption(self):
        if self._reply and self._reply.isRunning():
            self._reply.abort()

    def isRunning(self):
        return self._reply is not None and self._reply.isRunning()


@AiModelFactory.register()
class GithubCopilot(AiModelBase):

    _models = None
    _capabilities = {}
    _defaultModel = None
    _endPoints = {}

    def __init__(self, model: str = None, parent=None):
        super().__init__(None, model, parent)
        self._token = ApplicationBase.instance().settings().githubCopilotToken()
        self._updateUrlPrefix()

        self._eventLoop = None
        self._modelFetcher: ModelsFetcher = None

        self._ensureDefaultModel()
        self._updateModels()

    def _defaultModelId(self):
        modelKey = AiModelFactory.modelKey(self)
        settings = ApplicationBase.instance().settings()
        return settings.defaultLlmModelId(modelKey)

    def _updateUrlPrefix(self):
        isIndividual = GithubCopilot.isIndividualToken(self._token)
        self._url_prefix = "https://api.{}.githubcopilot.com".format(
            "individual" if isIndividual else "business"
        )
        if self._token and isIndividual and "individual.githubcopilot" not in self._token:
            logger.warning("GitHub individual url may changed, please check!")

    def queryAsync(self, params: AiParameters):
        if not self._token or not GithubCopilot.isTokenValid(self._token):
            logger.debug(
                "GitHub Copilot token is invalid or expired, updating...")
            if not self.updateToken():
                self.serviceUnavailable.emit()
                self.finished.emit()
                return

        id = params.model or self.modelId or "gpt-4.1"
        self.modelId = id
        caps: AiModelCapabilities = GithubCopilot._capabilities.get(
            id, AiModelCapabilities())

        stream = params.stream
        if stream and not caps.streaming:
            stream = False

        if params.max_tokens is None or params.max_tokens > caps.max_output_tokens:
            params.max_tokens = caps.max_output_tokens
        elif id.startswith("claude-") and "thought" in id:
            # claude-3.7-sonnet-thought seems cannot be 4096
            params.max_tokens = caps.max_output_tokens

        # Decide which endpoint to use for this model.
        self._isResponsesApiEnabled = self._shouldUseResponsesApi(id)
        if self._isResponsesApiEnabled:
            if not params.continue_only:
                prompt = params.prompt
                if params.sys_prompt:
                    self.addHistory(AiRole.System, params.sys_prompt)
                self.addHistory(AiRole.User, prompt)

            payload = {
                "model": id,
                "stream": stream,
                "store": False,
                "input": self.toResponsesInput(),
                "truncation": "disabled",
            }

            if params.reasoning:
                payload["reasoning"] = {
                    "effort": "medium",
                    "summary": "detailed"
                }
                payload["include"] = ["reasoning.encrypted_content"]

            # FIXME: `Unsupported parameter: 'temperature' is not supported with this model.`
            # Such as gpt-5.2, currently disable temperature for Responses API.

            if params.max_tokens is not None:
                payload["max_output_tokens"] = params.max_tokens

            if params.top_p is not None:
                payload["top_p"] = params.top_p

            if params.tools and caps.tool_calls:
                payload["tools"] = AiModelBase.chatToolsToResponsesTools(
                    params.tools)
                payload["tool_choice"] = params.tool_choice or "auto"

            self._doQuery(payload, stream)
            return

        payload = {
            "model": id,
            "temperature": params.temperature,
            "top_p": 1,
            "max_tokens": params.max_tokens,
            "n": 1,
            "stream": stream
        }

        if params.tools and caps.tool_calls:
            payload["tools"] = params.tools
            payload["tool_choice"] = params.tool_choice or "auto"

        if params.top_p is not None:
            payload["top_p"] = params.top_p

        if params.continue_only:
            payload["messages"] = self.toOpenAiMessages()
        else:
            prompt = params.prompt
            if params.sys_prompt:
                self.addHistory(AiRole.System, params.sys_prompt)
            self.addHistory(AiRole.User, prompt)
            payload["messages"] = self.toOpenAiMessages()

        self._doQuery(payload, stream)

    @property
    def name(self):
        return "GitHub Copilot"

    def supportsToolCalls(self, modelId: str) -> bool:
        caps: AiModelCapabilities = GithubCopilot._capabilities.get(
            modelId, AiModelCapabilities())
        return bool(caps.tool_calls)

    def _shouldUseResponsesApi(self, modelId: str) -> bool:
        """Return True when the model supports the Responses API."""
        endpoints = GithubCopilot._endPoints.get(modelId)
        if not endpoints:
            return False

        return "/responses" in endpoints

    def _doQuery(self, payload, stream=True):
        headers = _makeHeaders(self._token)
        url = f"{self._url_prefix}/responses" if self._isResponsesApiEnabled else f"{self._url_prefix}/chat/completions"
        self.post(url, headers=headers, data=payload, stream=stream)

    def updateToken(self, retry=False):
        settings = Settings(testing=ApplicationBase.instance().testing)
        accessToken = settings.githubCopilotAccessToken()
        if not accessToken:
            accessToken = self._requestAccessToken()
            if not accessToken:
                return False

        reply = AiModelBase.request(
            "https://api.github.com/copilot_internal/v2/token",
            headers={
                b"authorization": f"token {accessToken}".encode("utf-8"),
                b"editor-plugin-version": b"copilot-chat/0.24.1",
                b"editor-version": b"vscode/1.97.2",
                b"user-agent": b"GithubCopilotChat/0.24.1",
            }, post=False, timeout=1500)

        self._eventLoop = QEventLoop()
        reply.finished.connect(self._eventLoop.quit)
        self._eventLoop.exec()

        # If the event loop is interrupted, we should not process the reply
        if self._eventLoop is None:
            return False
        self._eventLoop = None

        if reply.error() == QNetworkReply.AuthenticationRequiredError and not retry:
            # clear the token and retry
            settings.setGithubCopilotAccessToken("")
            return self.updateToken(retry=True)

        if reply.error() != QNetworkReply.NoError:
            return False

        data: dict = json.loads(reply.readAll().data())
        self._token = data.get("token")
        if not self._token:
            return False
        self._updateUrlPrefix()
        settings.setGithubCopilotToken(self._token)
        self._updateModels()
        return True

    @staticmethod
    def isTokenValid(token: str):
        if token is None or 'exp' not in token:
            return False
        expTime = GithubCopilot.getTokenExpTime(token)
        return expTime > time.time()

    @staticmethod
    def getTokenExpTime(token: str):
        pairs = token.split(';')
        for pair in pairs:
            key, value = pair.split('=')
            if key.strip() == "exp":
                return int(value.strip())
        return None

    @staticmethod
    def isIndividualToken(token: str):
        if not token:
            return False

        pairs = token.split(';')
        individual = False
        for pair in pairs:
            key, value = pair.split('=')
            key = key.strip()
            if key == "sku":
                return value.strip() == "free_limited_copilot"
            if key == "proxy-ep":
                individual = "individual" in value

        return individual

    def _requestAccessToken(self):
        if self._eventLoop:
            return None

        ApplicationBase.instance().postEvent(
            ApplicationBase.instance(), RequestLoginGithubCopilot(self))

        self._eventLoop = QEventLoop()
        self._eventLoop.exec()
        self._eventLoop = None

        settings = Settings(testing=ApplicationBase.instance().testing)
        return settings.githubCopilotAccessToken()

    def event(self, evt):
        if evt.type() == LoginFinished.Type:
            if self._eventLoop:
                self._eventLoop.quit()
            return True

        return super().event(evt)

    def _updateModels(self):
        if self._modelFetcher:
            return

        if GithubCopilot._models is not None:
            return

        settings = ApplicationBase.instance().settings()
        accessToken = settings.githubCopilotAccessToken()
        # If user never logged before, don't try to fetch models
        if not accessToken:
            return

        if not GithubCopilot.isTokenValid(self._token):
            logger.debug("GitHub Copilot token is expired, updating...")
            self.updateToken()
            return

        GithubCopilot._models = []

        self._modelFetcher = ModelsFetcher(self._token, self._url_prefix, self)
        self._modelFetcher.finished.connect(self._onModelsAvailable)
        self._modelFetcher.start()

    def _onModelsAvailable(self):
        fetcher: ModelsFetcher = self.sender()
        GithubCopilot._models = fetcher.models
        GithubCopilot._capabilities = fetcher.capabilities
        GithubCopilot._defaultModel = fetcher.defaultModel
        GithubCopilot._endPoints = fetcher.endPoints

        self._ensureDefaultModel()

        self._modelFetcher = None
        self.modelsReady.emit()

    def _hasModelId(self, modelId: str) -> bool:
        if GithubCopilot._models is None:
            return False

        for id, _ in GithubCopilot._models:
            if id == modelId:
                return True

        return False

    def _ensureDefaultModel(self):
        # If caller already selected a model, keep it unless we know it's invalid.
        if self.modelId:
            if GithubCopilot._models is None or self._hasModelId(self.modelId):
                return

        modelsLoaded = GithubCopilot._models is not None

        preferred = self._defaultModelId()
        if preferred and (not modelsLoaded or self._hasModelId(preferred)):
            self.modelId = preferred
            return

        if GithubCopilot._defaultModel and (not modelsLoaded or self._hasModelId(GithubCopilot._defaultModel)):
            self.modelId = GithubCopilot._defaultModel
            return

        self.modelId = "gpt-4.1"

    def models(self):
        if GithubCopilot._models is None:
            return []

        return GithubCopilot._models

    def cleanup(self):
        if self._modelFetcher and self._modelFetcher.isRunning():
            self._modelFetcher.disconnect(self)
            self._modelFetcher.requestInterruption()
            self._modelFetcher = None

    def requestInterruption(self):
        if self._eventLoop:
            self._eventLoop.quit()
            self._eventLoop = None
        return super().requestInterruption()

    def trySwitchModel(self, modelId: str) -> bool:
        if not self._hasModelId(modelId):
            return False
        self.modelId = modelId
        return True
