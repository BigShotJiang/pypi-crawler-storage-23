{{originalPrompt}}

## IMPORTANT: Previous Attempt Failed Verification

Your previous attempt did not pass quality verification. Please address this feedback:

{{feedback}}

Make sure your output addresses all the feedback points above.
