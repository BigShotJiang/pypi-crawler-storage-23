Evaluate the candidates and select the best one. You must save your decision to the file `output/result.json`.
