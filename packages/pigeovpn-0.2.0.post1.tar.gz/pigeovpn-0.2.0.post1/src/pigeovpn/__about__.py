__all__ = [
    "__title__",
    "__summary__",
    "__version__",
    "__author__",
    "__email__",
    "__license__",
    "__url__",
]

__title__ = "pigeovpn"
__summary__ = "A terminal user interface to dynamically select, connect, and monitor OpenVPN configurations on Linux."
__version__ = "0.2.0-1"
__author__ = "Ioannis-D"
__email__ = "i.doganos@tutamail.com"
__license__ = "GPL3"
__url__ = "https://github.com/Ioannis-D/pigeovpn"
