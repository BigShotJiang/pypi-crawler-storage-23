# SPDX-FileCopyrightText: 2026-present Ioannis Doganos <i.doganos@tutamail.com>
#
# SPDX-License-Identifier: MIT
