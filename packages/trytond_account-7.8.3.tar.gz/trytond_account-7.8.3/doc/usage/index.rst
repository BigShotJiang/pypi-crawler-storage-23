*****
Usage
*****

Accounting configuration, data, and reports are found under the
[:menuselection:`Financial`] main menu item.

.. include:: create.inc.rst
.. include:: view.inc.rst
.. include:: report.inc.rst
.. include:: process.inc.rst
.. include:: close.inc.rst
.. include:: structure.inc.rst
