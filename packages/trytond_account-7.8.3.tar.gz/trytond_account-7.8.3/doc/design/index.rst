******
Design
******

The *Account Module* introduces the following concepts:

.. include:: account.inc.rst
.. include:: move.inc.rst
.. include:: fiscal-year.inc.rst
.. include:: journal.inc.rst
.. include:: tax.inc.rst
.. include:: template.inc.rst
.. include:: configuration.inc.rst
