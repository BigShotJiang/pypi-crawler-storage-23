# langchain-oneshot

LangChain tools for [OneShot](https://oneshotagent.com) — commercial actions for AI agents.

Provides 19 tools as LangChain `BaseTool` subclasses with automatic x402 payment handling via USDC on Base.

## Installation

```bash
pip install langchain-oneshot
```

## Quick Start

```python
from langchain_oneshot import OneShotToolkit
from langchain_openai import ChatOpenAI
from langgraph.prebuilt import create_react_agent

# Create toolkit (test mode uses Base Sepolia testnet)
toolkit = OneShotToolkit.from_private_key(
    private_key="0x...",
    test_mode=True,
)

# Use all 19 tools with a LangGraph agent
tools = toolkit.get_tools()
llm = ChatOpenAI(model="gpt-4o")
agent = create_react_agent(llm, tools)

result = agent.invoke({
    "messages": [("user", "Research the latest AI agent frameworks")]
})
```

## Individual Tools

```python
from langchain_oneshot import OneShotClient, ResearchTool

client = OneShotClient(private_key="0x...", test_mode=True)
research = ResearchTool(client=client)
result = research.invoke({"topic": "AI agent frameworks 2026"})
```

## Available Tools

| Tool | Description | Cost |
|------|-------------|------|
| `oneshot_email` | Send emails | ~$0.01 |
| `oneshot_voice` | Make phone calls | ~$0.25/min |
| `oneshot_sms` | Send SMS messages | ~$0.035/segment |
| `oneshot_research` | Deep web research | $0.50–$2.00 |
| `oneshot_people_search` | Search for people | ~$0.10/result |
| `oneshot_enrich_profile` | Enrich a profile | ~$0.10 |
| `oneshot_find_email` | Find email address | ~$0.10 |
| `oneshot_verify_email` | Verify email | ~$0.01 |
| `oneshot_commerce_search` | Search products | Free |
| `oneshot_commerce_buy` | Purchase product | Price + fee |
| `oneshot_build` | Build a website | ~$10 base |
| `oneshot_update_build` | Update a website | ~$10 base |
| `oneshot_inbox_list` | List inbox emails | Free |
| `oneshot_inbox_get` | Get email by ID | Free |
| `oneshot_sms_inbox_list` | List SMS inbox | Free |
| `oneshot_sms_inbox_get` | Get SMS by ID | Free |
| `oneshot_notifications` | List notifications | Free |
| `oneshot_mark_notification_read` | Mark read | Free |
| `oneshot_get_balance` | USDC balance | Free |

## How Payments Work

Paid tools use the [x402 protocol](https://x402.org). When a tool requires payment:

1. The client POSTs to the tool endpoint
2. The API returns `402 Payment Required` with a quote
3. The client signs a USDC `TransferWithAuthorization` (EIP-3009) using your private key
4. The client re-POSTs with the signed payment header
5. The API processes the request and returns the result

All payment signing happens locally — your private key never leaves your machine.

## Configuration

```python
# Test mode (Base Sepolia — no real money)
toolkit = OneShotToolkit.from_private_key("0x...", test_mode=True)

# Production (Base Mainnet — real USDC)
toolkit = OneShotToolkit.from_private_key("0x...", test_mode=False)
```

## Requirements

- Python 3.10+
- `langchain-core >= 0.3.0`
- `eth-account >= 0.13.0`
- `httpx >= 0.27.0`
- `pydantic >= 2.0`
