"""Tests for EIP-712 payment signing (x402 module).

Verifies that:
1. USDC amount parsing is correct (6 decimals)
2. EIP-712 signatures are valid and recoverable
3. Domain names match per chain (USDC for Sepolia, USD Coin for Mainnet)
"""

from eth_account import Account

from langchain_oneshot.x402 import (
    _get_usdc_domain_name,
    _parse_usdc_amount,
    sign_payment_authorization,
)

# Deterministic test key (never use with real funds)
TEST_PRIVATE_KEY = "0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80"
TEST_ADDRESS = Account.from_key(TEST_PRIVATE_KEY).address

# Base Sepolia config
SEPOLIA_CHAIN_ID = 84532
SEPOLIA_USDC = "0x036CbD53842c5426634e7929541eC2318f3dCF7e"

# Base Mainnet config
MAINNET_CHAIN_ID = 8453
MAINNET_USDC = "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913"


class TestParseUsdcAmount:
    def test_whole_number(self) -> None:
        assert _parse_usdc_amount("10") == 10_000_000

    def test_two_decimals(self) -> None:
        assert _parse_usdc_amount("1.50") == 1_500_000

    def test_six_decimals(self) -> None:
        assert _parse_usdc_amount("0.000001") == 1

    def test_three_decimals(self) -> None:
        assert _parse_usdc_amount("0.123") == 123_000

    def test_zero(self) -> None:
        assert _parse_usdc_amount("0") == 0

    def test_small_amount(self) -> None:
        assert _parse_usdc_amount("0.01") == 10_000


class TestDomainName:
    def test_sepolia_uses_usdc(self) -> None:
        assert _get_usdc_domain_name(84532) == "USDC"

    def test_mainnet_uses_usd_coin(self) -> None:
        assert _get_usdc_domain_name(8453) == "USD Coin"


class TestSignPaymentAuthorization:
    def test_returns_valid_structure(self) -> None:
        auth = sign_payment_authorization(
            private_key=TEST_PRIVATE_KEY,
            from_address=TEST_ADDRESS,
            to_address="0x70997970C51812dc3A010C7d01b50e0d17dc79C8",
            amount="1.00",
            token_address=SEPOLIA_USDC,
            chain_id=SEPOLIA_CHAIN_ID,
            network="eip155:84532",
        )

        # Check all required fields
        assert auth["from"] == TEST_ADDRESS
        assert auth["to"] == "0x70997970C51812dc3A010C7d01b50e0d17dc79C8"
        assert auth["value"] == "1000000"
        assert isinstance(auth["validAfter"], int)
        assert isinstance(auth["validBefore"], int)
        assert auth["validBefore"] > auth["validAfter"]
        assert auth["nonce"].startswith("0x") and len(auth["nonce"]) == 66
        assert auth["network"] == "eip155:84532"
        assert auth["token"] == SEPOLIA_USDC

        # Check signature
        sig = auth["signature"]
        assert sig["v"] in (27, 28)
        assert sig["r"].startswith("0x")
        assert sig["s"].startswith("0x")

    def test_mainnet_config(self) -> None:
        auth = sign_payment_authorization(
            private_key=TEST_PRIVATE_KEY,
            from_address=TEST_ADDRESS,
            to_address="0x70997970C51812dc3A010C7d01b50e0d17dc79C8",
            amount="5.00",
            token_address=MAINNET_USDC,
            chain_id=MAINNET_CHAIN_ID,
            network="eip155:8453",
        )

        assert auth["value"] == "5000000"
        assert auth["network"] == "eip155:8453"
        assert auth["token"] == MAINNET_USDC

    def test_different_calls_produce_different_nonces(self) -> None:
        auth1 = sign_payment_authorization(
            private_key=TEST_PRIVATE_KEY,
            from_address=TEST_ADDRESS,
            to_address="0x70997970C51812dc3A010C7d01b50e0d17dc79C8",
            amount="1.00",
            token_address=SEPOLIA_USDC,
            chain_id=SEPOLIA_CHAIN_ID,
            network="eip155:84532",
        )
        auth2 = sign_payment_authorization(
            private_key=TEST_PRIVATE_KEY,
            from_address=TEST_ADDRESS,
            to_address="0x70997970C51812dc3A010C7d01b50e0d17dc79C8",
            amount="1.00",
            token_address=SEPOLIA_USDC,
            chain_id=SEPOLIA_CHAIN_ID,
            network="eip155:84532",
        )

        assert auth1["nonce"] != auth2["nonce"]
