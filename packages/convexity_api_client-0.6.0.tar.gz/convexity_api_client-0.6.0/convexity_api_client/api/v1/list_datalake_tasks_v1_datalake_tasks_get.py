from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.worker_task_response import WorkerTaskResponse
from ...models.worker_task_status import WorkerTaskStatus
from ...models.worker_task_type import WorkerTaskType
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    task_type: None | Unset | WorkerTaskType = UNSET,
    status: None | Unset | WorkerTaskStatus = UNSET,
    limit: int | Unset = 50,
    project_id: str,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_task_type: None | str | Unset
    if isinstance(task_type, Unset):
        json_task_type = UNSET
    elif isinstance(task_type, WorkerTaskType):
        json_task_type = task_type.value
    else:
        json_task_type = task_type
    params["taskType"] = json_task_type

    json_status: None | str | Unset
    if isinstance(status, Unset):
        json_status = UNSET
    elif isinstance(status, WorkerTaskStatus):
        json_status = status.value
    else:
        json_status = status
    params["status"] = json_status

    params["limit"] = limit

    params["projectId"] = project_id

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/datalake-tasks",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | list[WorkerTaskResponse] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = WorkerTaskResponse.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | list[WorkerTaskResponse]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    task_type: None | Unset | WorkerTaskType = UNSET,
    status: None | Unset | WorkerTaskStatus = UNSET,
    limit: int | Unset = 50,
    project_id: str,
) -> Response[HTTPValidationError | list[WorkerTaskResponse]]:
    """List Datalake Tasks

     List datalake-related worker tasks for the current project.

    Returns tasks of types: refresh_dataset, delete_dataset,
    vacuum_ducklake, and sync_catalog_to_s3.

    Optionally filter by task type and/or status.

    Requires viewer role.

    Args:
        task_type (None | Unset | WorkerTaskType): Filter by task type
        status (None | Unset | WorkerTaskStatus): Filter by task status
        limit (int | Unset): Maximum number of tasks to return Default: 50.
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[WorkerTaskResponse]]
    """

    kwargs = _get_kwargs(
        task_type=task_type,
        status=status,
        limit=limit,
        project_id=project_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    task_type: None | Unset | WorkerTaskType = UNSET,
    status: None | Unset | WorkerTaskStatus = UNSET,
    limit: int | Unset = 50,
    project_id: str,
) -> HTTPValidationError | list[WorkerTaskResponse] | None:
    """List Datalake Tasks

     List datalake-related worker tasks for the current project.

    Returns tasks of types: refresh_dataset, delete_dataset,
    vacuum_ducklake, and sync_catalog_to_s3.

    Optionally filter by task type and/or status.

    Requires viewer role.

    Args:
        task_type (None | Unset | WorkerTaskType): Filter by task type
        status (None | Unset | WorkerTaskStatus): Filter by task status
        limit (int | Unset): Maximum number of tasks to return Default: 50.
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[WorkerTaskResponse]
    """

    return sync_detailed(
        client=client,
        task_type=task_type,
        status=status,
        limit=limit,
        project_id=project_id,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    task_type: None | Unset | WorkerTaskType = UNSET,
    status: None | Unset | WorkerTaskStatus = UNSET,
    limit: int | Unset = 50,
    project_id: str,
) -> Response[HTTPValidationError | list[WorkerTaskResponse]]:
    """List Datalake Tasks

     List datalake-related worker tasks for the current project.

    Returns tasks of types: refresh_dataset, delete_dataset,
    vacuum_ducklake, and sync_catalog_to_s3.

    Optionally filter by task type and/or status.

    Requires viewer role.

    Args:
        task_type (None | Unset | WorkerTaskType): Filter by task type
        status (None | Unset | WorkerTaskStatus): Filter by task status
        limit (int | Unset): Maximum number of tasks to return Default: 50.
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[WorkerTaskResponse]]
    """

    kwargs = _get_kwargs(
        task_type=task_type,
        status=status,
        limit=limit,
        project_id=project_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    task_type: None | Unset | WorkerTaskType = UNSET,
    status: None | Unset | WorkerTaskStatus = UNSET,
    limit: int | Unset = 50,
    project_id: str,
) -> HTTPValidationError | list[WorkerTaskResponse] | None:
    """List Datalake Tasks

     List datalake-related worker tasks for the current project.

    Returns tasks of types: refresh_dataset, delete_dataset,
    vacuum_ducklake, and sync_catalog_to_s3.

    Optionally filter by task type and/or status.

    Requires viewer role.

    Args:
        task_type (None | Unset | WorkerTaskType): Filter by task type
        status (None | Unset | WorkerTaskStatus): Filter by task status
        limit (int | Unset): Maximum number of tasks to return Default: 50.
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[WorkerTaskResponse]
    """

    return (
        await asyncio_detailed(
            client=client,
            task_type=task_type,
            status=status,
            limit=limit,
            project_id=project_id,
        )
    ).parsed
