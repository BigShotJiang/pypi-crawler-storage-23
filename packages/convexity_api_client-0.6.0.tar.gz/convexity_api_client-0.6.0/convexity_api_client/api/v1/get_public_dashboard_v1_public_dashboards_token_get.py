from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.public_dashboard_response import PublicDashboardResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    token: str,
    *,
    referer: None | str | Unset = UNSET,
    origin: None | str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(referer, Unset):
        headers["referer"] = referer

    if not isinstance(origin, Unset):
        headers["origin"] = origin

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/public/dashboards/{token}".format(
            token=quote(str(token), safe=""),
        ),
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | PublicDashboardResponse | None:
    if response.status_code == 200:
        response_200 = PublicDashboardResponse.from_dict(response.json())

        return response_200

    if response.status_code == 403:
        response_403 = cast(Any, None)
        return response_403

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | PublicDashboardResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    token: str,
    *,
    client: AuthenticatedClient | Client,
    referer: None | str | Unset = UNSET,
    origin: None | str | Unset = UNSET,
) -> Response[Any | HTTPValidationError | PublicDashboardResponse]:
    """Get Public Dashboard

     Get a shared dashboard for public viewing.

    This endpoint does not require authentication.
    It validates the share token, expiration, and domain restrictions.

    Args:
        token: The share token from the URL
        referer: The Referer header (used for domain validation when embedding)
        origin: The Origin header (fallback for domain validation)

    Args:
        token (str):
        referer (None | str | Unset):
        origin (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | PublicDashboardResponse]
    """

    kwargs = _get_kwargs(
        token=token,
        referer=referer,
        origin=origin,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    token: str,
    *,
    client: AuthenticatedClient | Client,
    referer: None | str | Unset = UNSET,
    origin: None | str | Unset = UNSET,
) -> Any | HTTPValidationError | PublicDashboardResponse | None:
    """Get Public Dashboard

     Get a shared dashboard for public viewing.

    This endpoint does not require authentication.
    It validates the share token, expiration, and domain restrictions.

    Args:
        token: The share token from the URL
        referer: The Referer header (used for domain validation when embedding)
        origin: The Origin header (fallback for domain validation)

    Args:
        token (str):
        referer (None | str | Unset):
        origin (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | PublicDashboardResponse
    """

    return sync_detailed(
        token=token,
        client=client,
        referer=referer,
        origin=origin,
    ).parsed


async def asyncio_detailed(
    token: str,
    *,
    client: AuthenticatedClient | Client,
    referer: None | str | Unset = UNSET,
    origin: None | str | Unset = UNSET,
) -> Response[Any | HTTPValidationError | PublicDashboardResponse]:
    """Get Public Dashboard

     Get a shared dashboard for public viewing.

    This endpoint does not require authentication.
    It validates the share token, expiration, and domain restrictions.

    Args:
        token: The share token from the URL
        referer: The Referer header (used for domain validation when embedding)
        origin: The Origin header (fallback for domain validation)

    Args:
        token (str):
        referer (None | str | Unset):
        origin (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | PublicDashboardResponse]
    """

    kwargs = _get_kwargs(
        token=token,
        referer=referer,
        origin=origin,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    token: str,
    *,
    client: AuthenticatedClient | Client,
    referer: None | str | Unset = UNSET,
    origin: None | str | Unset = UNSET,
) -> Any | HTTPValidationError | PublicDashboardResponse | None:
    """Get Public Dashboard

     Get a shared dashboard for public viewing.

    This endpoint does not require authentication.
    It validates the share token, expiration, and domain restrictions.

    Args:
        token: The share token from the URL
        referer: The Referer header (used for domain validation when embedding)
        origin: The Origin header (fallback for domain validation)

    Args:
        token (str):
        referer (None | str | Unset):
        origin (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | PublicDashboardResponse
    """

    return (
        await asyncio_detailed(
            token=token,
            client=client,
            referer=referer,
            origin=origin,
        )
    ).parsed
