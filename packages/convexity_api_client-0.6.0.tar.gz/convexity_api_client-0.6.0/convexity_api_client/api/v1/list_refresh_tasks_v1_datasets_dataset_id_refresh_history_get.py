from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.refresh_task_list_response import RefreshTaskListResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    dataset_id: str,
    *,
    limit: int | Unset = 20,
    offset: int | Unset = 0,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["limit"] = limit

    params["offset"] = offset

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/datasets/{dataset_id}/refresh-history".format(
            dataset_id=quote(str(dataset_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | RefreshTaskListResponse | None:
    if response.status_code == 200:
        response_200 = RefreshTaskListResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | RefreshTaskListResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    dataset_id: str,
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 20,
    offset: int | Unset = 0,
) -> Response[HTTPValidationError | RefreshTaskListResponse]:
    """List Refresh Tasks

     List refresh task history for a dataset with pagination.

    Returns the most recent refresh tasks first. Requires viewer role.

    Args:
        dataset_id (str):
        limit (int | Unset): Number of tasks per page Default: 20.
        offset (int | Unset): Number of tasks to skip Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | RefreshTaskListResponse]
    """

    kwargs = _get_kwargs(
        dataset_id=dataset_id,
        limit=limit,
        offset=offset,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    dataset_id: str,
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 20,
    offset: int | Unset = 0,
) -> HTTPValidationError | RefreshTaskListResponse | None:
    """List Refresh Tasks

     List refresh task history for a dataset with pagination.

    Returns the most recent refresh tasks first. Requires viewer role.

    Args:
        dataset_id (str):
        limit (int | Unset): Number of tasks per page Default: 20.
        offset (int | Unset): Number of tasks to skip Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | RefreshTaskListResponse
    """

    return sync_detailed(
        dataset_id=dataset_id,
        client=client,
        limit=limit,
        offset=offset,
    ).parsed


async def asyncio_detailed(
    dataset_id: str,
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 20,
    offset: int | Unset = 0,
) -> Response[HTTPValidationError | RefreshTaskListResponse]:
    """List Refresh Tasks

     List refresh task history for a dataset with pagination.

    Returns the most recent refresh tasks first. Requires viewer role.

    Args:
        dataset_id (str):
        limit (int | Unset): Number of tasks per page Default: 20.
        offset (int | Unset): Number of tasks to skip Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | RefreshTaskListResponse]
    """

    kwargs = _get_kwargs(
        dataset_id=dataset_id,
        limit=limit,
        offset=offset,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    dataset_id: str,
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 20,
    offset: int | Unset = 0,
) -> HTTPValidationError | RefreshTaskListResponse | None:
    """List Refresh Tasks

     List refresh task history for a dataset with pagination.

    Returns the most recent refresh tasks first. Requires viewer role.

    Args:
        dataset_id (str):
        limit (int | Unset): Number of tasks per page Default: 20.
        offset (int | Unset): Number of tasks to skip Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | RefreshTaskListResponse
    """

    return (
        await asyncio_detailed(
            dataset_id=dataset_id,
            client=client,
            limit=limit,
            offset=offset,
        )
    ).parsed
