from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.area_chart_config import AreaChartConfig
    from ..models.bar_chart_config import BarChartConfig
    from ..models.kpi_chart_config import KpiChartConfig
    from ..models.line_chart_config import LineChartConfig
    from ..models.pie_chart_config import PieChartConfig
    from ..models.scatter_chart_config import ScatterChartConfig


T = TypeVar("T", bound="ChartConfig")


@_attrs_define
class ChartConfig:
    """Chart configuration with type-specific options.

    Attributes:
        id (str): Unique chart configuration identifier
        dataset_id (str): Dataset identifier
        type_ (Literal['chartconfig'] | Unset):  Default: 'chartconfig'.
        title (None | str | Unset): Chart title
        config (AreaChartConfig | BarChartConfig | KpiChartConfig | LineChartConfig | None | PieChartConfig |
            ScatterChartConfig | Unset): Chart type-specific configuration
        line (LineChartConfig | None | Unset): Line chart configuration
        bar (BarChartConfig | None | Unset): Bar chart configuration
        area (AreaChartConfig | None | Unset): Area chart configuration
        scatter (None | ScatterChartConfig | Unset): Scatter chart configuration
        pie (None | PieChartConfig | Unset): Pie chart configuration
        kpi (KpiChartConfig | None | Unset): KPI chart configuration
    """

    id: str
    dataset_id: str
    type_: Literal["chartconfig"] | Unset = "chartconfig"
    title: None | str | Unset = UNSET
    config: (
        AreaChartConfig
        | BarChartConfig
        | KpiChartConfig
        | LineChartConfig
        | None
        | PieChartConfig
        | ScatterChartConfig
        | Unset
    ) = UNSET
    line: LineChartConfig | None | Unset = UNSET
    bar: BarChartConfig | None | Unset = UNSET
    area: AreaChartConfig | None | Unset = UNSET
    scatter: None | ScatterChartConfig | Unset = UNSET
    pie: None | PieChartConfig | Unset = UNSET
    kpi: KpiChartConfig | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.area_chart_config import AreaChartConfig
        from ..models.bar_chart_config import BarChartConfig
        from ..models.kpi_chart_config import KpiChartConfig
        from ..models.line_chart_config import LineChartConfig
        from ..models.pie_chart_config import PieChartConfig
        from ..models.scatter_chart_config import ScatterChartConfig

        id = self.id

        dataset_id = self.dataset_id

        type_ = self.type_

        title: None | str | Unset
        if isinstance(self.title, Unset):
            title = UNSET
        else:
            title = self.title

        config: dict[str, Any] | None | Unset
        if isinstance(self.config, Unset):
            config = UNSET
        elif isinstance(self.config, LineChartConfig):
            config = self.config.to_dict()
        elif isinstance(self.config, BarChartConfig):
            config = self.config.to_dict()
        elif isinstance(self.config, AreaChartConfig):
            config = self.config.to_dict()
        elif isinstance(self.config, ScatterChartConfig):
            config = self.config.to_dict()
        elif isinstance(self.config, PieChartConfig):
            config = self.config.to_dict()
        elif isinstance(self.config, KpiChartConfig):
            config = self.config.to_dict()
        else:
            config = self.config

        line: dict[str, Any] | None | Unset
        if isinstance(self.line, Unset):
            line = UNSET
        elif isinstance(self.line, LineChartConfig):
            line = self.line.to_dict()
        else:
            line = self.line

        bar: dict[str, Any] | None | Unset
        if isinstance(self.bar, Unset):
            bar = UNSET
        elif isinstance(self.bar, BarChartConfig):
            bar = self.bar.to_dict()
        else:
            bar = self.bar

        area: dict[str, Any] | None | Unset
        if isinstance(self.area, Unset):
            area = UNSET
        elif isinstance(self.area, AreaChartConfig):
            area = self.area.to_dict()
        else:
            area = self.area

        scatter: dict[str, Any] | None | Unset
        if isinstance(self.scatter, Unset):
            scatter = UNSET
        elif isinstance(self.scatter, ScatterChartConfig):
            scatter = self.scatter.to_dict()
        else:
            scatter = self.scatter

        pie: dict[str, Any] | None | Unset
        if isinstance(self.pie, Unset):
            pie = UNSET
        elif isinstance(self.pie, PieChartConfig):
            pie = self.pie.to_dict()
        else:
            pie = self.pie

        kpi: dict[str, Any] | None | Unset
        if isinstance(self.kpi, Unset):
            kpi = UNSET
        elif isinstance(self.kpi, KpiChartConfig):
            kpi = self.kpi.to_dict()
        else:
            kpi = self.kpi

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "datasetId": dataset_id,
            }
        )
        if type_ is not UNSET:
            field_dict["type"] = type_
        if title is not UNSET:
            field_dict["title"] = title
        if config is not UNSET:
            field_dict["config"] = config
        if line is not UNSET:
            field_dict["line"] = line
        if bar is not UNSET:
            field_dict["bar"] = bar
        if area is not UNSET:
            field_dict["area"] = area
        if scatter is not UNSET:
            field_dict["scatter"] = scatter
        if pie is not UNSET:
            field_dict["pie"] = pie
        if kpi is not UNSET:
            field_dict["kpi"] = kpi

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.area_chart_config import AreaChartConfig
        from ..models.bar_chart_config import BarChartConfig
        from ..models.kpi_chart_config import KpiChartConfig
        from ..models.line_chart_config import LineChartConfig
        from ..models.pie_chart_config import PieChartConfig
        from ..models.scatter_chart_config import ScatterChartConfig

        d = dict(src_dict)
        id = d.pop("id")

        dataset_id = d.pop("datasetId")

        type_ = cast(Literal["chartconfig"] | Unset, d.pop("type", UNSET))
        if type_ != "chartconfig" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'chartconfig', got '{type_}'")

        def _parse_title(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        title = _parse_title(d.pop("title", UNSET))

        def _parse_config(
            data: object,
        ) -> (
            AreaChartConfig
            | BarChartConfig
            | KpiChartConfig
            | LineChartConfig
            | None
            | PieChartConfig
            | ScatterChartConfig
            | Unset
        ):
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                config_type_0_type_0 = LineChartConfig.from_dict(data)

                return config_type_0_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                config_type_0_type_1 = BarChartConfig.from_dict(data)

                return config_type_0_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                config_type_0_type_2 = AreaChartConfig.from_dict(data)

                return config_type_0_type_2
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                config_type_0_type_3 = ScatterChartConfig.from_dict(data)

                return config_type_0_type_3
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                config_type_0_type_4 = PieChartConfig.from_dict(data)

                return config_type_0_type_4
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                config_type_0_type_5 = KpiChartConfig.from_dict(data)

                return config_type_0_type_5
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(
                AreaChartConfig
                | BarChartConfig
                | KpiChartConfig
                | LineChartConfig
                | None
                | PieChartConfig
                | ScatterChartConfig
                | Unset,
                data,
            )

        config = _parse_config(d.pop("config", UNSET))

        def _parse_line(data: object) -> LineChartConfig | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                line_type_0 = LineChartConfig.from_dict(data)

                return line_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(LineChartConfig | None | Unset, data)

        line = _parse_line(d.pop("line", UNSET))

        def _parse_bar(data: object) -> BarChartConfig | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                bar_type_0 = BarChartConfig.from_dict(data)

                return bar_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(BarChartConfig | None | Unset, data)

        bar = _parse_bar(d.pop("bar", UNSET))

        def _parse_area(data: object) -> AreaChartConfig | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                area_type_0 = AreaChartConfig.from_dict(data)

                return area_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(AreaChartConfig | None | Unset, data)

        area = _parse_area(d.pop("area", UNSET))

        def _parse_scatter(data: object) -> None | ScatterChartConfig | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                scatter_type_0 = ScatterChartConfig.from_dict(data)

                return scatter_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | ScatterChartConfig | Unset, data)

        scatter = _parse_scatter(d.pop("scatter", UNSET))

        def _parse_pie(data: object) -> None | PieChartConfig | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                pie_type_0 = PieChartConfig.from_dict(data)

                return pie_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | PieChartConfig | Unset, data)

        pie = _parse_pie(d.pop("pie", UNSET))

        def _parse_kpi(data: object) -> KpiChartConfig | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                kpi_type_0 = KpiChartConfig.from_dict(data)

                return kpi_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(KpiChartConfig | None | Unset, data)

        kpi = _parse_kpi(d.pop("kpi", UNSET))

        chart_config = cls(
            id=id,
            dataset_id=dataset_id,
            type_=type_,
            title=title,
            config=config,
            line=line,
            bar=bar,
            area=area,
            scatter=scatter,
            pie=pie,
            kpi=kpi,
        )

        chart_config.additional_properties = d
        return chart_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
