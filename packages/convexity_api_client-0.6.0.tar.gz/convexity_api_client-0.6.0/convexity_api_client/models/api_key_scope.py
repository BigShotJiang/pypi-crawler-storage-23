from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.api_key_permission import ApiKeyPermission
from ..models.api_key_resource_type import ApiKeyResourceType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.api_key import ApiKey


T = TypeVar("T", bound="ApiKeyScope")


@_attrs_define
class ApiKeyScope:
    """Represents a ApiKeyScope record

    Attributes:
        id (str):
        api_key_id (str):
        resource_type (ApiKeyResourceType):
        role (ApiKeyPermission):
        created_at (datetime.datetime):
        api_key (ApiKey | None | Unset):
    """

    id: str
    api_key_id: str
    resource_type: ApiKeyResourceType
    role: ApiKeyPermission
    created_at: datetime.datetime
    api_key: ApiKey | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.api_key import ApiKey

        id = self.id

        api_key_id = self.api_key_id

        resource_type = self.resource_type.value

        role = self.role.value

        created_at = self.created_at.isoformat()

        api_key: dict[str, Any] | None | Unset
        if isinstance(self.api_key, Unset):
            api_key = UNSET
        elif isinstance(self.api_key, ApiKey):
            api_key = self.api_key.to_dict()
        else:
            api_key = self.api_key

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "api_key_id": api_key_id,
                "resource_type": resource_type,
                "role": role,
                "created_at": created_at,
            }
        )
        if api_key is not UNSET:
            field_dict["api_key"] = api_key

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.api_key import ApiKey

        d = dict(src_dict)
        id = d.pop("id")

        api_key_id = d.pop("api_key_id")

        resource_type = ApiKeyResourceType(d.pop("resource_type"))

        role = ApiKeyPermission(d.pop("role"))

        created_at = isoparse(d.pop("created_at"))

        def _parse_api_key(data: object) -> ApiKey | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                api_key_type_0 = ApiKey.from_dict(data)

                return api_key_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ApiKey | None | Unset, data)

        api_key = _parse_api_key(d.pop("api_key", UNSET))

        api_key_scope = cls(
            id=id,
            api_key_id=api_key_id,
            resource_type=resource_type,
            role=role,
            created_at=created_at,
            api_key=api_key,
        )

        api_key_scope.additional_properties = d
        return api_key_scope

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
