from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="VacuumDucklakePayload")


@_attrs_define
class VacuumDucklakePayload:
    """Payload for a DuckLake vacuum task.

    Cleans up unreferenced Parquet data files left behind by overwrites
    or schema evolution. Should be scheduled periodically.

        Attributes:
            project_id (str): Project whose DuckLake to vacuum
            type_ (Literal['vacuum_ducklake'] | Unset):  Default: 'vacuum_ducklake'.
            retention_hours (int | Unset): Keep files newer than this many hours (default: 7 days) Default: 168.
    """

    project_id: str
    type_: Literal["vacuum_ducklake"] | Unset = "vacuum_ducklake"
    retention_hours: int | Unset = 168
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        project_id = self.project_id

        type_ = self.type_

        retention_hours = self.retention_hours

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "projectId": project_id,
            }
        )
        if type_ is not UNSET:
            field_dict["type"] = type_
        if retention_hours is not UNSET:
            field_dict["retentionHours"] = retention_hours

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        project_id = d.pop("projectId")

        type_ = cast(Literal["vacuum_ducklake"] | Unset, d.pop("type", UNSET))
        if type_ != "vacuum_ducklake" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'vacuum_ducklake', got '{type_}'")

        retention_hours = d.pop("retentionHours", UNSET)

        vacuum_ducklake_payload = cls(
            project_id=project_id,
            type_=type_,
            retention_hours=retention_hours,
        )

        vacuum_ducklake_payload.additional_properties = d
        return vacuum_ducklake_payload

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
