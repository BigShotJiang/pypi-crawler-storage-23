from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.task_execution_parameter_override_inputtype import TaskExecutionParameterOverrideInputtype
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.filter_option import FilterOption


T = TypeVar("T", bound="TaskExecutionParameterOverride")


@_attrs_define
class TaskExecutionParameterOverride:
    """Override for a single parameter from the task's parameter_schema.

    Attributes:
        parameter_name (str): Matches key in parameter_schema.properties
        input_type (TaskExecutionParameterOverrideInputtype): Input type for this parameter
        label (None | str | Unset): Display label override
        default_value (Any | None | Unset): Default value
        options_dataset_id (None | str | Unset): Dataset to load dynamic options from
        options_value_column (None | str | Unset): Column to use as option value
        options_label_column (None | str | Unset): Column to use as option label
        options (list[FilterOption] | None | Unset): Static options for select/multiselect
    """

    parameter_name: str
    input_type: TaskExecutionParameterOverrideInputtype
    label: None | str | Unset = UNSET
    default_value: Any | None | Unset = UNSET
    options_dataset_id: None | str | Unset = UNSET
    options_value_column: None | str | Unset = UNSET
    options_label_column: None | str | Unset = UNSET
    options: list[FilterOption] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        parameter_name = self.parameter_name

        input_type = self.input_type.value

        label: None | str | Unset
        if isinstance(self.label, Unset):
            label = UNSET
        else:
            label = self.label

        default_value: Any | None | Unset
        if isinstance(self.default_value, Unset):
            default_value = UNSET
        else:
            default_value = self.default_value

        options_dataset_id: None | str | Unset
        if isinstance(self.options_dataset_id, Unset):
            options_dataset_id = UNSET
        else:
            options_dataset_id = self.options_dataset_id

        options_value_column: None | str | Unset
        if isinstance(self.options_value_column, Unset):
            options_value_column = UNSET
        else:
            options_value_column = self.options_value_column

        options_label_column: None | str | Unset
        if isinstance(self.options_label_column, Unset):
            options_label_column = UNSET
        else:
            options_label_column = self.options_label_column

        options: list[dict[str, Any]] | None | Unset
        if isinstance(self.options, Unset):
            options = UNSET
        elif isinstance(self.options, list):
            options = []
            for options_type_0_item_data in self.options:
                options_type_0_item = options_type_0_item_data.to_dict()
                options.append(options_type_0_item)

        else:
            options = self.options

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "parameterName": parameter_name,
                "inputType": input_type,
            }
        )
        if label is not UNSET:
            field_dict["label"] = label
        if default_value is not UNSET:
            field_dict["defaultValue"] = default_value
        if options_dataset_id is not UNSET:
            field_dict["optionsDatasetId"] = options_dataset_id
        if options_value_column is not UNSET:
            field_dict["optionsValueColumn"] = options_value_column
        if options_label_column is not UNSET:
            field_dict["optionsLabelColumn"] = options_label_column
        if options is not UNSET:
            field_dict["options"] = options

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.filter_option import FilterOption

        d = dict(src_dict)
        parameter_name = d.pop("parameterName")

        input_type = TaskExecutionParameterOverrideInputtype(d.pop("inputType"))

        def _parse_label(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        label = _parse_label(d.pop("label", UNSET))

        def _parse_default_value(data: object) -> Any | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Any | None | Unset, data)

        default_value = _parse_default_value(d.pop("defaultValue", UNSET))

        def _parse_options_dataset_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        options_dataset_id = _parse_options_dataset_id(d.pop("optionsDatasetId", UNSET))

        def _parse_options_value_column(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        options_value_column = _parse_options_value_column(d.pop("optionsValueColumn", UNSET))

        def _parse_options_label_column(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        options_label_column = _parse_options_label_column(d.pop("optionsLabelColumn", UNSET))

        def _parse_options(data: object) -> list[FilterOption] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                options_type_0 = []
                _options_type_0 = data
                for options_type_0_item_data in _options_type_0:
                    options_type_0_item = FilterOption.from_dict(options_type_0_item_data)

                    options_type_0.append(options_type_0_item)

                return options_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[FilterOption] | None | Unset, data)

        options = _parse_options(d.pop("options", UNSET))

        task_execution_parameter_override = cls(
            parameter_name=parameter_name,
            input_type=input_type,
            label=label,
            default_value=default_value,
            options_dataset_id=options_dataset_id,
            options_value_column=options_value_column,
            options_label_column=options_label_column,
            options=options,
        )

        task_execution_parameter_override.additional_properties = d
        return task_execution_parameter_override

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
