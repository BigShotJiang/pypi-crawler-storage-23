from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.tooltip_series_config_format_type_0 import TooltipSeriesConfigFormatType0
from ..types import UNSET, Unset

T = TypeVar("T", bound="TooltipSeriesConfig")


@_attrs_define
class TooltipSeriesConfig:
    """Configuration for individual series in tooltip.

    Attributes:
        series_id (str): Series identifier (metric or metric:group)
        show (bool | None | Unset): Whether to show this series in tooltip Default: True.
        label (None | str | Unset): Custom label for this series in tooltip
        format_ (None | TooltipSeriesConfigFormatType0 | Unset): Number format Default:
            TooltipSeriesConfigFormatType0.NUMBER.
        decimal_places (int | None | Unset): Number of decimal places
        prefix (None | str | Unset): Value prefix (e.g., '$')
        suffix (None | str | Unset): Value suffix (e.g., '%', 'K', 'M')
    """

    series_id: str
    show: bool | None | Unset = True
    label: None | str | Unset = UNSET
    format_: None | TooltipSeriesConfigFormatType0 | Unset = TooltipSeriesConfigFormatType0.NUMBER
    decimal_places: int | None | Unset = UNSET
    prefix: None | str | Unset = UNSET
    suffix: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        series_id = self.series_id

        show: bool | None | Unset
        if isinstance(self.show, Unset):
            show = UNSET
        else:
            show = self.show

        label: None | str | Unset
        if isinstance(self.label, Unset):
            label = UNSET
        else:
            label = self.label

        format_: None | str | Unset
        if isinstance(self.format_, Unset):
            format_ = UNSET
        elif isinstance(self.format_, TooltipSeriesConfigFormatType0):
            format_ = self.format_.value
        else:
            format_ = self.format_

        decimal_places: int | None | Unset
        if isinstance(self.decimal_places, Unset):
            decimal_places = UNSET
        else:
            decimal_places = self.decimal_places

        prefix: None | str | Unset
        if isinstance(self.prefix, Unset):
            prefix = UNSET
        else:
            prefix = self.prefix

        suffix: None | str | Unset
        if isinstance(self.suffix, Unset):
            suffix = UNSET
        else:
            suffix = self.suffix

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "seriesId": series_id,
            }
        )
        if show is not UNSET:
            field_dict["show"] = show
        if label is not UNSET:
            field_dict["label"] = label
        if format_ is not UNSET:
            field_dict["format"] = format_
        if decimal_places is not UNSET:
            field_dict["decimalPlaces"] = decimal_places
        if prefix is not UNSET:
            field_dict["prefix"] = prefix
        if suffix is not UNSET:
            field_dict["suffix"] = suffix

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        series_id = d.pop("seriesId")

        def _parse_show(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show = _parse_show(d.pop("show", UNSET))

        def _parse_label(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        label = _parse_label(d.pop("label", UNSET))

        def _parse_format_(data: object) -> None | TooltipSeriesConfigFormatType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                format_type_0 = TooltipSeriesConfigFormatType0(data)

                return format_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | TooltipSeriesConfigFormatType0 | Unset, data)

        format_ = _parse_format_(d.pop("format", UNSET))

        def _parse_decimal_places(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        decimal_places = _parse_decimal_places(d.pop("decimalPlaces", UNSET))

        def _parse_prefix(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        prefix = _parse_prefix(d.pop("prefix", UNSET))

        def _parse_suffix(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        suffix = _parse_suffix(d.pop("suffix", UNSET))

        tooltip_series_config = cls(
            series_id=series_id,
            show=show,
            label=label,
            format_=format_,
            decimal_places=decimal_places,
            prefix=prefix,
            suffix=suffix,
        )

        tooltip_series_config.additional_properties = d
        return tooltip_series_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
