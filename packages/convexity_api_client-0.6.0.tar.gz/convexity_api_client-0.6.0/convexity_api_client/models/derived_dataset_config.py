from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.derived_dataset_config_transformations_item import DerivedDatasetConfigTransformationsItem


T = TypeVar("T", bound="DerivedDatasetConfig")


@_attrs_define
class DerivedDatasetConfig:
    """Configuration for derived datasets (computed from other datasets).

    Attributes:
        source_dataset_id (str): Source dataset ID
        transformations (list[DerivedDatasetConfigTransformationsItem] | Unset): Transformation operations
    """

    source_dataset_id: str
    transformations: list[DerivedDatasetConfigTransformationsItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        source_dataset_id = self.source_dataset_id

        transformations: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.transformations, Unset):
            transformations = []
            for transformations_item_data in self.transformations:
                transformations_item = transformations_item_data.to_dict()
                transformations.append(transformations_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "sourceDatasetId": source_dataset_id,
            }
        )
        if transformations is not UNSET:
            field_dict["transformations"] = transformations

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.derived_dataset_config_transformations_item import DerivedDatasetConfigTransformationsItem

        d = dict(src_dict)
        source_dataset_id = d.pop("sourceDatasetId")

        _transformations = d.pop("transformations", UNSET)
        transformations: list[DerivedDatasetConfigTransformationsItem] | Unset = UNSET
        if _transformations is not UNSET:
            transformations = []
            for transformations_item_data in _transformations:
                transformations_item = DerivedDatasetConfigTransformationsItem.from_dict(transformations_item_data)

                transformations.append(transformations_item)

        derived_dataset_config = cls(
            source_dataset_id=source_dataset_id,
            transformations=transformations,
        )

        derived_dataset_config.additional_properties = d
        return derived_dataset_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
