from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="RunStatsResponse")


@_attrs_define
class RunStatsResponse:
    """Response model for run statistics.

    Attributes:
        total_runs (int):
        completed_runs (int):
        failed_runs (int):
        cancelled_runs (int):
        running_runs (int):
        pending_runs (int):
        active_threads (int):
        average_execution_time_ms (float):
        success_rate (float):
    """

    total_runs: int
    completed_runs: int
    failed_runs: int
    cancelled_runs: int
    running_runs: int
    pending_runs: int
    active_threads: int
    average_execution_time_ms: float
    success_rate: float
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        total_runs = self.total_runs

        completed_runs = self.completed_runs

        failed_runs = self.failed_runs

        cancelled_runs = self.cancelled_runs

        running_runs = self.running_runs

        pending_runs = self.pending_runs

        active_threads = self.active_threads

        average_execution_time_ms = self.average_execution_time_ms

        success_rate = self.success_rate

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "total_runs": total_runs,
                "completed_runs": completed_runs,
                "failed_runs": failed_runs,
                "cancelled_runs": cancelled_runs,
                "running_runs": running_runs,
                "pending_runs": pending_runs,
                "active_threads": active_threads,
                "average_execution_time_ms": average_execution_time_ms,
                "success_rate": success_rate,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        total_runs = d.pop("total_runs")

        completed_runs = d.pop("completed_runs")

        failed_runs = d.pop("failed_runs")

        cancelled_runs = d.pop("cancelled_runs")

        running_runs = d.pop("running_runs")

        pending_runs = d.pop("pending_runs")

        active_threads = d.pop("active_threads")

        average_execution_time_ms = d.pop("average_execution_time_ms")

        success_rate = d.pop("success_rate")

        run_stats_response = cls(
            total_runs=total_runs,
            completed_runs=completed_runs,
            failed_runs=failed_runs,
            cancelled_runs=cancelled_runs,
            running_runs=running_runs,
            pending_runs=pending_runs,
            active_threads=active_threads,
            average_execution_time_ms=average_execution_time_ms,
            success_rate=success_rate,
        )

        run_stats_response.additional_properties = d
        return run_stats_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
