from enum import Enum


class OrganizationRole(str, Enum):
    ADMIN = "ADMIN"
    MEMBER = "MEMBER"
    OWNER = "OWNER"
    VIEWER = "VIEWER"

    def __str__(self) -> str:
        return str(self.value)
