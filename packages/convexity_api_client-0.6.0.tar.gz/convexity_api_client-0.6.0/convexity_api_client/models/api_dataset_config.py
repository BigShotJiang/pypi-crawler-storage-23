from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.api_dataset_config_method import ApiDatasetConfigMethod
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.api_dataset_config_body_type_0 import ApiDatasetConfigBodyType0
    from ..models.api_dataset_config_headers_type_0 import ApiDatasetConfigHeadersType0
    from ..models.api_dataset_config_parameters_type_0 import ApiDatasetConfigParametersType0


T = TypeVar("T", bound="ApiDatasetConfig")


@_attrs_define
class ApiDatasetConfig:
    """Configuration for API datasets.

    Attributes:
        endpoint (str): API endpoint URL
        method (ApiDatasetConfigMethod | Unset): HTTP method Default: ApiDatasetConfigMethod.GET.
        headers (ApiDatasetConfigHeadersType0 | None | Unset): Request headers
        body (ApiDatasetConfigBodyType0 | None | Unset): Request body for POST
        json_path (None | str | Unset): JSONPath to extract data
        parameters (ApiDatasetConfigParametersType0 | None | Unset): Query parameters
    """

    endpoint: str
    method: ApiDatasetConfigMethod | Unset = ApiDatasetConfigMethod.GET
    headers: ApiDatasetConfigHeadersType0 | None | Unset = UNSET
    body: ApiDatasetConfigBodyType0 | None | Unset = UNSET
    json_path: None | str | Unset = UNSET
    parameters: ApiDatasetConfigParametersType0 | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.api_dataset_config_body_type_0 import ApiDatasetConfigBodyType0
        from ..models.api_dataset_config_headers_type_0 import ApiDatasetConfigHeadersType0
        from ..models.api_dataset_config_parameters_type_0 import ApiDatasetConfigParametersType0

        endpoint = self.endpoint

        method: str | Unset = UNSET
        if not isinstance(self.method, Unset):
            method = self.method.value

        headers: dict[str, Any] | None | Unset
        if isinstance(self.headers, Unset):
            headers = UNSET
        elif isinstance(self.headers, ApiDatasetConfigHeadersType0):
            headers = self.headers.to_dict()
        else:
            headers = self.headers

        body: dict[str, Any] | None | Unset
        if isinstance(self.body, Unset):
            body = UNSET
        elif isinstance(self.body, ApiDatasetConfigBodyType0):
            body = self.body.to_dict()
        else:
            body = self.body

        json_path: None | str | Unset
        if isinstance(self.json_path, Unset):
            json_path = UNSET
        else:
            json_path = self.json_path

        parameters: dict[str, Any] | None | Unset
        if isinstance(self.parameters, Unset):
            parameters = UNSET
        elif isinstance(self.parameters, ApiDatasetConfigParametersType0):
            parameters = self.parameters.to_dict()
        else:
            parameters = self.parameters

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "endpoint": endpoint,
            }
        )
        if method is not UNSET:
            field_dict["method"] = method
        if headers is not UNSET:
            field_dict["headers"] = headers
        if body is not UNSET:
            field_dict["body"] = body
        if json_path is not UNSET:
            field_dict["jsonPath"] = json_path
        if parameters is not UNSET:
            field_dict["parameters"] = parameters

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.api_dataset_config_body_type_0 import ApiDatasetConfigBodyType0
        from ..models.api_dataset_config_headers_type_0 import ApiDatasetConfigHeadersType0
        from ..models.api_dataset_config_parameters_type_0 import ApiDatasetConfigParametersType0

        d = dict(src_dict)
        endpoint = d.pop("endpoint")

        _method = d.pop("method", UNSET)
        method: ApiDatasetConfigMethod | Unset
        if isinstance(_method, Unset):
            method = UNSET
        else:
            method = ApiDatasetConfigMethod(_method)

        def _parse_headers(data: object) -> ApiDatasetConfigHeadersType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                headers_type_0 = ApiDatasetConfigHeadersType0.from_dict(data)

                return headers_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ApiDatasetConfigHeadersType0 | None | Unset, data)

        headers = _parse_headers(d.pop("headers", UNSET))

        def _parse_body(data: object) -> ApiDatasetConfigBodyType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                body_type_0 = ApiDatasetConfigBodyType0.from_dict(data)

                return body_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ApiDatasetConfigBodyType0 | None | Unset, data)

        body = _parse_body(d.pop("body", UNSET))

        def _parse_json_path(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        json_path = _parse_json_path(d.pop("jsonPath", UNSET))

        def _parse_parameters(data: object) -> ApiDatasetConfigParametersType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                parameters_type_0 = ApiDatasetConfigParametersType0.from_dict(data)

                return parameters_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ApiDatasetConfigParametersType0 | None | Unset, data)

        parameters = _parse_parameters(d.pop("parameters", UNSET))

        api_dataset_config = cls(
            endpoint=endpoint,
            method=method,
            headers=headers,
            body=body,
            json_path=json_path,
            parameters=parameters,
        )

        api_dataset_config.additional_properties = d
        return api_dataset_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
