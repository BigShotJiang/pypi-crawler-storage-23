from enum import Enum


class PreviewType(str, Enum):
    CODE = "code"
    CSV = "csv"
    IMAGE = "image"
    MARKDOWN = "markdown"
    PDF = "pdf"
    SPREADSHEET = "spreadsheet"
    TEXT = "text"

    def __str__(self) -> str:
        return str(self.value)
