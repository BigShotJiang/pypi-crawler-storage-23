from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.connection_status import ConnectionStatus
from ..models.connection_type import ConnectionType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.dataset import Dataset
    from ..models.project import Project
    from ..models.task_connection import TaskConnection


T = TypeVar("T", bound="ConnectionDTO")


@_attrs_define
class ConnectionDTO:
    """Represents a ConnectionDTO record

    Attributes:
        id (str):
        user_id (str):
        project_id (str):
        name (str):
        type_ (ConnectionType):
        status (ConnectionStatus):
        config (str):
        created_at (datetime.datetime):
        updated_at (datetime.datetime):
        description (None | str | Unset):
        last_tested (datetime.datetime | None | Unset):
        error_message (None | str | Unset):
        project (None | Project | Unset):
        tasks (list[TaskConnection] | None | Unset):
        datasets (list[Dataset] | None | Unset):
    """

    id: str
    user_id: str
    project_id: str
    name: str
    type_: ConnectionType
    status: ConnectionStatus
    config: str
    created_at: datetime.datetime
    updated_at: datetime.datetime
    description: None | str | Unset = UNSET
    last_tested: datetime.datetime | None | Unset = UNSET
    error_message: None | str | Unset = UNSET
    project: None | Project | Unset = UNSET
    tasks: list[TaskConnection] | None | Unset = UNSET
    datasets: list[Dataset] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.project import Project

        id = self.id

        user_id = self.user_id

        project_id = self.project_id

        name = self.name

        type_ = self.type_.value

        status = self.status.value

        config = self.config

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        last_tested: None | str | Unset
        if isinstance(self.last_tested, Unset):
            last_tested = UNSET
        elif isinstance(self.last_tested, datetime.datetime):
            last_tested = self.last_tested.isoformat()
        else:
            last_tested = self.last_tested

        error_message: None | str | Unset
        if isinstance(self.error_message, Unset):
            error_message = UNSET
        else:
            error_message = self.error_message

        project: dict[str, Any] | None | Unset
        if isinstance(self.project, Unset):
            project = UNSET
        elif isinstance(self.project, Project):
            project = self.project.to_dict()
        else:
            project = self.project

        tasks: list[dict[str, Any]] | None | Unset
        if isinstance(self.tasks, Unset):
            tasks = UNSET
        elif isinstance(self.tasks, list):
            tasks = []
            for tasks_type_0_item_data in self.tasks:
                tasks_type_0_item = tasks_type_0_item_data.to_dict()
                tasks.append(tasks_type_0_item)

        else:
            tasks = self.tasks

        datasets: list[dict[str, Any]] | None | Unset
        if isinstance(self.datasets, Unset):
            datasets = UNSET
        elif isinstance(self.datasets, list):
            datasets = []
            for datasets_type_0_item_data in self.datasets:
                datasets_type_0_item = datasets_type_0_item_data.to_dict()
                datasets.append(datasets_type_0_item)

        else:
            datasets = self.datasets

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "user_id": user_id,
                "project_id": project_id,
                "name": name,
                "type": type_,
                "status": status,
                "config": config,
                "created_at": created_at,
                "updated_at": updated_at,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if last_tested is not UNSET:
            field_dict["last_tested"] = last_tested
        if error_message is not UNSET:
            field_dict["error_message"] = error_message
        if project is not UNSET:
            field_dict["project"] = project
        if tasks is not UNSET:
            field_dict["tasks"] = tasks
        if datasets is not UNSET:
            field_dict["datasets"] = datasets

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.dataset import Dataset
        from ..models.project import Project
        from ..models.task_connection import TaskConnection

        d = dict(src_dict)
        id = d.pop("id")

        user_id = d.pop("user_id")

        project_id = d.pop("project_id")

        name = d.pop("name")

        type_ = ConnectionType(d.pop("type"))

        status = ConnectionStatus(d.pop("status"))

        config = d.pop("config")

        created_at = isoparse(d.pop("created_at"))

        updated_at = isoparse(d.pop("updated_at"))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_last_tested(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_tested_type_0 = isoparse(data)

                return last_tested_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        last_tested = _parse_last_tested(d.pop("last_tested", UNSET))

        def _parse_error_message(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        error_message = _parse_error_message(d.pop("error_message", UNSET))

        def _parse_project(data: object) -> None | Project | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                project_type_0 = Project.from_dict(data)

                return project_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Project | Unset, data)

        project = _parse_project(d.pop("project", UNSET))

        def _parse_tasks(data: object) -> list[TaskConnection] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                tasks_type_0 = []
                _tasks_type_0 = data
                for tasks_type_0_item_data in _tasks_type_0:
                    tasks_type_0_item = TaskConnection.from_dict(tasks_type_0_item_data)

                    tasks_type_0.append(tasks_type_0_item)

                return tasks_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[TaskConnection] | None | Unset, data)

        tasks = _parse_tasks(d.pop("tasks", UNSET))

        def _parse_datasets(data: object) -> list[Dataset] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                datasets_type_0 = []
                _datasets_type_0 = data
                for datasets_type_0_item_data in _datasets_type_0:
                    datasets_type_0_item = Dataset.from_dict(datasets_type_0_item_data)

                    datasets_type_0.append(datasets_type_0_item)

                return datasets_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[Dataset] | None | Unset, data)

        datasets = _parse_datasets(d.pop("datasets", UNSET))

        connection_dto = cls(
            id=id,
            user_id=user_id,
            project_id=project_id,
            name=name,
            type_=type_,
            status=status,
            config=config,
            created_at=created_at,
            updated_at=updated_at,
            description=description,
            last_tested=last_tested,
            error_message=error_message,
            project=project,
            tasks=tasks,
            datasets=datasets,
        )

        connection_dto.additional_properties = d
        return connection_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
