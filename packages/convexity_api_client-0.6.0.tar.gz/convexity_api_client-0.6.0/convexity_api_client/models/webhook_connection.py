from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.connection_status import ConnectionStatus
from ..types import UNSET, Unset

T = TypeVar("T", bound="WebhookConnection")


@_attrs_define
class WebhookConnection:
    """Connection for receiving webhook data.

    Attributes:
        project_id (str): Project this connection belongs to
        name (str): Connection name
        endpoint (str): Webhook endpoint URL
        id (None | str | Unset): Connection ID
        user_id (None | str | Unset): Owner user ID
        description (None | str | Unset): Connection description
        type_ (Literal['WEBHOOK'] | Unset):  Default: 'WEBHOOK'.
        status (ConnectionStatus | Unset):
        last_tested (None | str | Unset): Last verification timestamp
        error_message (None | str | Unset): Error message if status is error
        created_at (None | str | Unset): Creation timestamp
        updated_at (None | str | Unset): Last update timestamp
        secret (None | str | Unset): Webhook secret for verification
        secret_header (None | str | Unset): Header name for secret Default: 'X-Webhook-Secret'.
    """

    project_id: str
    name: str
    endpoint: str
    id: None | str | Unset = UNSET
    user_id: None | str | Unset = UNSET
    description: None | str | Unset = UNSET
    type_: Literal["WEBHOOK"] | Unset = "WEBHOOK"
    status: ConnectionStatus | Unset = UNSET
    last_tested: None | str | Unset = UNSET
    error_message: None | str | Unset = UNSET
    created_at: None | str | Unset = UNSET
    updated_at: None | str | Unset = UNSET
    secret: None | str | Unset = UNSET
    secret_header: None | str | Unset = "X-Webhook-Secret"
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        project_id = self.project_id

        name = self.name

        endpoint = self.endpoint

        id: None | str | Unset
        if isinstance(self.id, Unset):
            id = UNSET
        else:
            id = self.id

        user_id: None | str | Unset
        if isinstance(self.user_id, Unset):
            user_id = UNSET
        else:
            user_id = self.user_id

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        type_ = self.type_

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value

        last_tested: None | str | Unset
        if isinstance(self.last_tested, Unset):
            last_tested = UNSET
        else:
            last_tested = self.last_tested

        error_message: None | str | Unset
        if isinstance(self.error_message, Unset):
            error_message = UNSET
        else:
            error_message = self.error_message

        created_at: None | str | Unset
        if isinstance(self.created_at, Unset):
            created_at = UNSET
        else:
            created_at = self.created_at

        updated_at: None | str | Unset
        if isinstance(self.updated_at, Unset):
            updated_at = UNSET
        else:
            updated_at = self.updated_at

        secret: None | str | Unset
        if isinstance(self.secret, Unset):
            secret = UNSET
        else:
            secret = self.secret

        secret_header: None | str | Unset
        if isinstance(self.secret_header, Unset):
            secret_header = UNSET
        else:
            secret_header = self.secret_header

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "projectId": project_id,
                "name": name,
                "endpoint": endpoint,
            }
        )
        if id is not UNSET:
            field_dict["id"] = id
        if user_id is not UNSET:
            field_dict["userId"] = user_id
        if description is not UNSET:
            field_dict["description"] = description
        if type_ is not UNSET:
            field_dict["type"] = type_
        if status is not UNSET:
            field_dict["status"] = status
        if last_tested is not UNSET:
            field_dict["lastTested"] = last_tested
        if error_message is not UNSET:
            field_dict["errorMessage"] = error_message
        if created_at is not UNSET:
            field_dict["createdAt"] = created_at
        if updated_at is not UNSET:
            field_dict["updatedAt"] = updated_at
        if secret is not UNSET:
            field_dict["secret"] = secret
        if secret_header is not UNSET:
            field_dict["secretHeader"] = secret_header

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        project_id = d.pop("projectId")

        name = d.pop("name")

        endpoint = d.pop("endpoint")

        def _parse_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        id = _parse_id(d.pop("id", UNSET))

        def _parse_user_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        user_id = _parse_user_id(d.pop("userId", UNSET))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        type_ = cast(Literal["WEBHOOK"] | Unset, d.pop("type", UNSET))
        if type_ != "WEBHOOK" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'WEBHOOK', got '{type_}'")

        _status = d.pop("status", UNSET)
        status: ConnectionStatus | Unset
        if isinstance(_status, Unset):
            status = UNSET
        else:
            status = ConnectionStatus(_status)

        def _parse_last_tested(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        last_tested = _parse_last_tested(d.pop("lastTested", UNSET))

        def _parse_error_message(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        error_message = _parse_error_message(d.pop("errorMessage", UNSET))

        def _parse_created_at(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        created_at = _parse_created_at(d.pop("createdAt", UNSET))

        def _parse_updated_at(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        updated_at = _parse_updated_at(d.pop("updatedAt", UNSET))

        def _parse_secret(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        secret = _parse_secret(d.pop("secret", UNSET))

        def _parse_secret_header(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        secret_header = _parse_secret_header(d.pop("secretHeader", UNSET))

        webhook_connection = cls(
            project_id=project_id,
            name=name,
            endpoint=endpoint,
            id=id,
            user_id=user_id,
            description=description,
            type_=type_,
            status=status,
            last_tested=last_tested,
            error_message=error_message,
            created_at=created_at,
            updated_at=updated_at,
            secret=secret,
            secret_header=secret_header,
        )

        webhook_connection.additional_properties = d
        return webhook_connection

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
