from enum import Enum


class RefreshMode(str, Enum):
    MANUAL = "MANUAL"
    REALTIME = "REALTIME"
    SCHEDULED = "SCHEDULED"

    def __str__(self) -> str:
        return str(self.value)
