from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.update_api_connection_request_headers_type_0 import UpdateApiConnectionRequestHeadersType0


T = TypeVar("T", bound="UpdateApiConnectionRequest")


@_attrs_define
class UpdateApiConnectionRequest:
    """
    Attributes:
        name (None | str | Unset): Connection name
        description (None | str | Unset): Connection description
        endpoint (None | str | Unset): API endpoint URL
        method (None | str | Unset): HTTP method
        auth_type (None | str | Unset): Auth type
        api_key (None | str | Unset): API key
        api_key_header (None | str | Unset): API key header
        bearer_token (None | str | Unset): Bearer token
        basic_username (None | str | Unset): Basic auth username
        basic_password (None | str | Unset): Basic auth password
        headers (None | Unset | UpdateApiConnectionRequestHeadersType0): Additional headers
    """

    name: None | str | Unset = UNSET
    description: None | str | Unset = UNSET
    endpoint: None | str | Unset = UNSET
    method: None | str | Unset = UNSET
    auth_type: None | str | Unset = UNSET
    api_key: None | str | Unset = UNSET
    api_key_header: None | str | Unset = UNSET
    bearer_token: None | str | Unset = UNSET
    basic_username: None | str | Unset = UNSET
    basic_password: None | str | Unset = UNSET
    headers: None | Unset | UpdateApiConnectionRequestHeadersType0 = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.update_api_connection_request_headers_type_0 import UpdateApiConnectionRequestHeadersType0

        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        endpoint: None | str | Unset
        if isinstance(self.endpoint, Unset):
            endpoint = UNSET
        else:
            endpoint = self.endpoint

        method: None | str | Unset
        if isinstance(self.method, Unset):
            method = UNSET
        else:
            method = self.method

        auth_type: None | str | Unset
        if isinstance(self.auth_type, Unset):
            auth_type = UNSET
        else:
            auth_type = self.auth_type

        api_key: None | str | Unset
        if isinstance(self.api_key, Unset):
            api_key = UNSET
        else:
            api_key = self.api_key

        api_key_header: None | str | Unset
        if isinstance(self.api_key_header, Unset):
            api_key_header = UNSET
        else:
            api_key_header = self.api_key_header

        bearer_token: None | str | Unset
        if isinstance(self.bearer_token, Unset):
            bearer_token = UNSET
        else:
            bearer_token = self.bearer_token

        basic_username: None | str | Unset
        if isinstance(self.basic_username, Unset):
            basic_username = UNSET
        else:
            basic_username = self.basic_username

        basic_password: None | str | Unset
        if isinstance(self.basic_password, Unset):
            basic_password = UNSET
        else:
            basic_password = self.basic_password

        headers: dict[str, Any] | None | Unset
        if isinstance(self.headers, Unset):
            headers = UNSET
        elif isinstance(self.headers, UpdateApiConnectionRequestHeadersType0):
            headers = self.headers.to_dict()
        else:
            headers = self.headers

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description
        if endpoint is not UNSET:
            field_dict["endpoint"] = endpoint
        if method is not UNSET:
            field_dict["method"] = method
        if auth_type is not UNSET:
            field_dict["authType"] = auth_type
        if api_key is not UNSET:
            field_dict["apiKey"] = api_key
        if api_key_header is not UNSET:
            field_dict["apiKeyHeader"] = api_key_header
        if bearer_token is not UNSET:
            field_dict["bearerToken"] = bearer_token
        if basic_username is not UNSET:
            field_dict["basicUsername"] = basic_username
        if basic_password is not UNSET:
            field_dict["basicPassword"] = basic_password
        if headers is not UNSET:
            field_dict["headers"] = headers

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.update_api_connection_request_headers_type_0 import UpdateApiConnectionRequestHeadersType0

        d = dict(src_dict)

        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_endpoint(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        endpoint = _parse_endpoint(d.pop("endpoint", UNSET))

        def _parse_method(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        method = _parse_method(d.pop("method", UNSET))

        def _parse_auth_type(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        auth_type = _parse_auth_type(d.pop("authType", UNSET))

        def _parse_api_key(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        api_key = _parse_api_key(d.pop("apiKey", UNSET))

        def _parse_api_key_header(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        api_key_header = _parse_api_key_header(d.pop("apiKeyHeader", UNSET))

        def _parse_bearer_token(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        bearer_token = _parse_bearer_token(d.pop("bearerToken", UNSET))

        def _parse_basic_username(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        basic_username = _parse_basic_username(d.pop("basicUsername", UNSET))

        def _parse_basic_password(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        basic_password = _parse_basic_password(d.pop("basicPassword", UNSET))

        def _parse_headers(data: object) -> None | Unset | UpdateApiConnectionRequestHeadersType0:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                headers_type_0 = UpdateApiConnectionRequestHeadersType0.from_dict(data)

                return headers_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UpdateApiConnectionRequestHeadersType0, data)

        headers = _parse_headers(d.pop("headers", UNSET))

        update_api_connection_request = cls(
            name=name,
            description=description,
            endpoint=endpoint,
            method=method,
            auth_type=auth_type,
            api_key=api_key,
            api_key_header=api_key_header,
            bearer_token=bearer_token,
            basic_username=basic_username,
            basic_password=basic_password,
            headers=headers,
        )

        update_api_connection_request.additional_properties = d
        return update_api_connection_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
