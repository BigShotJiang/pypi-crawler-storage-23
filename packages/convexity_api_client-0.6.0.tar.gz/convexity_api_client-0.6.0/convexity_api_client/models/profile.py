from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.api_key import ApiKey
    from ..models.forecasting import Forecasting
    from ..models.formulation import Formulation
    from ..models.organization_member import OrganizationMember
    from ..models.run import Run
    from ..models.token_balance import TokenBalance
    from ..models.token_package import TokenPackage
    from ..models.token_purchase import TokenPurchase
    from ..models.token_usage import TokenUsage


T = TypeVar("T", bound="Profile")


@_attrs_define
class Profile:
    """Represents a Profile record

    Attributes:
        user_id (str):
        created_at (datetime.datetime):
        updated_at (datetime.datetime):
        auto_recharge_enabled (bool):
        name (None | str | Unset):
        email (None | str | Unset):
        profile_picture (None | str | Unset):
        bio (None | str | Unset):
        auto_recharge_threshold (int | None | Unset):
        auto_recharge_package_id (None | str | Unset):
        formulations (list[Formulation] | None | Unset):
        token_packages (None | TokenPackage | Unset):
        runs (list[Run] | None | Unset):
        token_balances (None | TokenBalance | Unset):
        token_purchases (list[TokenPurchase] | None | Unset):
        token_usage (list[TokenUsage] | None | Unset):
        forecasting (list[Forecasting] | None | Unset):
        organization_memberships (list[OrganizationMember] | None | Unset):
        owned_api_keys (list[ApiKey] | None | Unset):
        created_api_keys (list[ApiKey] | None | Unset):
        revoked_api_keys (list[ApiKey] | None | Unset):
    """

    user_id: str
    created_at: datetime.datetime
    updated_at: datetime.datetime
    auto_recharge_enabled: bool
    name: None | str | Unset = UNSET
    email: None | str | Unset = UNSET
    profile_picture: None | str | Unset = UNSET
    bio: None | str | Unset = UNSET
    auto_recharge_threshold: int | None | Unset = UNSET
    auto_recharge_package_id: None | str | Unset = UNSET
    formulations: list[Formulation] | None | Unset = UNSET
    token_packages: None | TokenPackage | Unset = UNSET
    runs: list[Run] | None | Unset = UNSET
    token_balances: None | TokenBalance | Unset = UNSET
    token_purchases: list[TokenPurchase] | None | Unset = UNSET
    token_usage: list[TokenUsage] | None | Unset = UNSET
    forecasting: list[Forecasting] | None | Unset = UNSET
    organization_memberships: list[OrganizationMember] | None | Unset = UNSET
    owned_api_keys: list[ApiKey] | None | Unset = UNSET
    created_api_keys: list[ApiKey] | None | Unset = UNSET
    revoked_api_keys: list[ApiKey] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.token_balance import TokenBalance
        from ..models.token_package import TokenPackage

        user_id = self.user_id

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        auto_recharge_enabled = self.auto_recharge_enabled

        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        email: None | str | Unset
        if isinstance(self.email, Unset):
            email = UNSET
        else:
            email = self.email

        profile_picture: None | str | Unset
        if isinstance(self.profile_picture, Unset):
            profile_picture = UNSET
        else:
            profile_picture = self.profile_picture

        bio: None | str | Unset
        if isinstance(self.bio, Unset):
            bio = UNSET
        else:
            bio = self.bio

        auto_recharge_threshold: int | None | Unset
        if isinstance(self.auto_recharge_threshold, Unset):
            auto_recharge_threshold = UNSET
        else:
            auto_recharge_threshold = self.auto_recharge_threshold

        auto_recharge_package_id: None | str | Unset
        if isinstance(self.auto_recharge_package_id, Unset):
            auto_recharge_package_id = UNSET
        else:
            auto_recharge_package_id = self.auto_recharge_package_id

        formulations: list[dict[str, Any]] | None | Unset
        if isinstance(self.formulations, Unset):
            formulations = UNSET
        elif isinstance(self.formulations, list):
            formulations = []
            for formulations_type_0_item_data in self.formulations:
                formulations_type_0_item = formulations_type_0_item_data.to_dict()
                formulations.append(formulations_type_0_item)

        else:
            formulations = self.formulations

        token_packages: dict[str, Any] | None | Unset
        if isinstance(self.token_packages, Unset):
            token_packages = UNSET
        elif isinstance(self.token_packages, TokenPackage):
            token_packages = self.token_packages.to_dict()
        else:
            token_packages = self.token_packages

        runs: list[dict[str, Any]] | None | Unset
        if isinstance(self.runs, Unset):
            runs = UNSET
        elif isinstance(self.runs, list):
            runs = []
            for runs_type_0_item_data in self.runs:
                runs_type_0_item = runs_type_0_item_data.to_dict()
                runs.append(runs_type_0_item)

        else:
            runs = self.runs

        token_balances: dict[str, Any] | None | Unset
        if isinstance(self.token_balances, Unset):
            token_balances = UNSET
        elif isinstance(self.token_balances, TokenBalance):
            token_balances = self.token_balances.to_dict()
        else:
            token_balances = self.token_balances

        token_purchases: list[dict[str, Any]] | None | Unset
        if isinstance(self.token_purchases, Unset):
            token_purchases = UNSET
        elif isinstance(self.token_purchases, list):
            token_purchases = []
            for token_purchases_type_0_item_data in self.token_purchases:
                token_purchases_type_0_item = token_purchases_type_0_item_data.to_dict()
                token_purchases.append(token_purchases_type_0_item)

        else:
            token_purchases = self.token_purchases

        token_usage: list[dict[str, Any]] | None | Unset
        if isinstance(self.token_usage, Unset):
            token_usage = UNSET
        elif isinstance(self.token_usage, list):
            token_usage = []
            for token_usage_type_0_item_data in self.token_usage:
                token_usage_type_0_item = token_usage_type_0_item_data.to_dict()
                token_usage.append(token_usage_type_0_item)

        else:
            token_usage = self.token_usage

        forecasting: list[dict[str, Any]] | None | Unset
        if isinstance(self.forecasting, Unset):
            forecasting = UNSET
        elif isinstance(self.forecasting, list):
            forecasting = []
            for forecasting_type_0_item_data in self.forecasting:
                forecasting_type_0_item = forecasting_type_0_item_data.to_dict()
                forecasting.append(forecasting_type_0_item)

        else:
            forecasting = self.forecasting

        organization_memberships: list[dict[str, Any]] | None | Unset
        if isinstance(self.organization_memberships, Unset):
            organization_memberships = UNSET
        elif isinstance(self.organization_memberships, list):
            organization_memberships = []
            for organization_memberships_type_0_item_data in self.organization_memberships:
                organization_memberships_type_0_item = organization_memberships_type_0_item_data.to_dict()
                organization_memberships.append(organization_memberships_type_0_item)

        else:
            organization_memberships = self.organization_memberships

        owned_api_keys: list[dict[str, Any]] | None | Unset
        if isinstance(self.owned_api_keys, Unset):
            owned_api_keys = UNSET
        elif isinstance(self.owned_api_keys, list):
            owned_api_keys = []
            for owned_api_keys_type_0_item_data in self.owned_api_keys:
                owned_api_keys_type_0_item = owned_api_keys_type_0_item_data.to_dict()
                owned_api_keys.append(owned_api_keys_type_0_item)

        else:
            owned_api_keys = self.owned_api_keys

        created_api_keys: list[dict[str, Any]] | None | Unset
        if isinstance(self.created_api_keys, Unset):
            created_api_keys = UNSET
        elif isinstance(self.created_api_keys, list):
            created_api_keys = []
            for created_api_keys_type_0_item_data in self.created_api_keys:
                created_api_keys_type_0_item = created_api_keys_type_0_item_data.to_dict()
                created_api_keys.append(created_api_keys_type_0_item)

        else:
            created_api_keys = self.created_api_keys

        revoked_api_keys: list[dict[str, Any]] | None | Unset
        if isinstance(self.revoked_api_keys, Unset):
            revoked_api_keys = UNSET
        elif isinstance(self.revoked_api_keys, list):
            revoked_api_keys = []
            for revoked_api_keys_type_0_item_data in self.revoked_api_keys:
                revoked_api_keys_type_0_item = revoked_api_keys_type_0_item_data.to_dict()
                revoked_api_keys.append(revoked_api_keys_type_0_item)

        else:
            revoked_api_keys = self.revoked_api_keys

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "user_id": user_id,
                "created_at": created_at,
                "updated_at": updated_at,
                "auto_recharge_enabled": auto_recharge_enabled,
            }
        )
        if name is not UNSET:
            field_dict["name"] = name
        if email is not UNSET:
            field_dict["email"] = email
        if profile_picture is not UNSET:
            field_dict["profile_picture"] = profile_picture
        if bio is not UNSET:
            field_dict["bio"] = bio
        if auto_recharge_threshold is not UNSET:
            field_dict["auto_recharge_threshold"] = auto_recharge_threshold
        if auto_recharge_package_id is not UNSET:
            field_dict["auto_recharge_package_id"] = auto_recharge_package_id
        if formulations is not UNSET:
            field_dict["formulations"] = formulations
        if token_packages is not UNSET:
            field_dict["token_packages"] = token_packages
        if runs is not UNSET:
            field_dict["runs"] = runs
        if token_balances is not UNSET:
            field_dict["token_balances"] = token_balances
        if token_purchases is not UNSET:
            field_dict["token_purchases"] = token_purchases
        if token_usage is not UNSET:
            field_dict["token_usage"] = token_usage
        if forecasting is not UNSET:
            field_dict["Forecasting"] = forecasting
        if organization_memberships is not UNSET:
            field_dict["organization_memberships"] = organization_memberships
        if owned_api_keys is not UNSET:
            field_dict["owned_api_keys"] = owned_api_keys
        if created_api_keys is not UNSET:
            field_dict["created_api_keys"] = created_api_keys
        if revoked_api_keys is not UNSET:
            field_dict["revoked_api_keys"] = revoked_api_keys

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.api_key import ApiKey
        from ..models.forecasting import Forecasting
        from ..models.formulation import Formulation
        from ..models.organization_member import OrganizationMember
        from ..models.run import Run
        from ..models.token_balance import TokenBalance
        from ..models.token_package import TokenPackage
        from ..models.token_purchase import TokenPurchase
        from ..models.token_usage import TokenUsage

        d = dict(src_dict)
        user_id = d.pop("user_id")

        created_at = isoparse(d.pop("created_at"))

        updated_at = isoparse(d.pop("updated_at"))

        auto_recharge_enabled = d.pop("auto_recharge_enabled")

        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))

        def _parse_email(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        email = _parse_email(d.pop("email", UNSET))

        def _parse_profile_picture(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        profile_picture = _parse_profile_picture(d.pop("profile_picture", UNSET))

        def _parse_bio(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        bio = _parse_bio(d.pop("bio", UNSET))

        def _parse_auto_recharge_threshold(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        auto_recharge_threshold = _parse_auto_recharge_threshold(d.pop("auto_recharge_threshold", UNSET))

        def _parse_auto_recharge_package_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        auto_recharge_package_id = _parse_auto_recharge_package_id(d.pop("auto_recharge_package_id", UNSET))

        def _parse_formulations(data: object) -> list[Formulation] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                formulations_type_0 = []
                _formulations_type_0 = data
                for formulations_type_0_item_data in _formulations_type_0:
                    formulations_type_0_item = Formulation.from_dict(formulations_type_0_item_data)

                    formulations_type_0.append(formulations_type_0_item)

                return formulations_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[Formulation] | None | Unset, data)

        formulations = _parse_formulations(d.pop("formulations", UNSET))

        def _parse_token_packages(data: object) -> None | TokenPackage | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                token_packages_type_0 = TokenPackage.from_dict(data)

                return token_packages_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | TokenPackage | Unset, data)

        token_packages = _parse_token_packages(d.pop("token_packages", UNSET))

        def _parse_runs(data: object) -> list[Run] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                runs_type_0 = []
                _runs_type_0 = data
                for runs_type_0_item_data in _runs_type_0:
                    runs_type_0_item = Run.from_dict(runs_type_0_item_data)

                    runs_type_0.append(runs_type_0_item)

                return runs_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[Run] | None | Unset, data)

        runs = _parse_runs(d.pop("runs", UNSET))

        def _parse_token_balances(data: object) -> None | TokenBalance | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                token_balances_type_0 = TokenBalance.from_dict(data)

                return token_balances_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | TokenBalance | Unset, data)

        token_balances = _parse_token_balances(d.pop("token_balances", UNSET))

        def _parse_token_purchases(data: object) -> list[TokenPurchase] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                token_purchases_type_0 = []
                _token_purchases_type_0 = data
                for token_purchases_type_0_item_data in _token_purchases_type_0:
                    token_purchases_type_0_item = TokenPurchase.from_dict(token_purchases_type_0_item_data)

                    token_purchases_type_0.append(token_purchases_type_0_item)

                return token_purchases_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[TokenPurchase] | None | Unset, data)

        token_purchases = _parse_token_purchases(d.pop("token_purchases", UNSET))

        def _parse_token_usage(data: object) -> list[TokenUsage] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                token_usage_type_0 = []
                _token_usage_type_0 = data
                for token_usage_type_0_item_data in _token_usage_type_0:
                    token_usage_type_0_item = TokenUsage.from_dict(token_usage_type_0_item_data)

                    token_usage_type_0.append(token_usage_type_0_item)

                return token_usage_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[TokenUsage] | None | Unset, data)

        token_usage = _parse_token_usage(d.pop("token_usage", UNSET))

        def _parse_forecasting(data: object) -> list[Forecasting] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                forecasting_type_0 = []
                _forecasting_type_0 = data
                for forecasting_type_0_item_data in _forecasting_type_0:
                    forecasting_type_0_item = Forecasting.from_dict(forecasting_type_0_item_data)

                    forecasting_type_0.append(forecasting_type_0_item)

                return forecasting_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[Forecasting] | None | Unset, data)

        forecasting = _parse_forecasting(d.pop("Forecasting", UNSET))

        def _parse_organization_memberships(data: object) -> list[OrganizationMember] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                organization_memberships_type_0 = []
                _organization_memberships_type_0 = data
                for organization_memberships_type_0_item_data in _organization_memberships_type_0:
                    organization_memberships_type_0_item = OrganizationMember.from_dict(
                        organization_memberships_type_0_item_data
                    )

                    organization_memberships_type_0.append(organization_memberships_type_0_item)

                return organization_memberships_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[OrganizationMember] | None | Unset, data)

        organization_memberships = _parse_organization_memberships(d.pop("organization_memberships", UNSET))

        def _parse_owned_api_keys(data: object) -> list[ApiKey] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                owned_api_keys_type_0 = []
                _owned_api_keys_type_0 = data
                for owned_api_keys_type_0_item_data in _owned_api_keys_type_0:
                    owned_api_keys_type_0_item = ApiKey.from_dict(owned_api_keys_type_0_item_data)

                    owned_api_keys_type_0.append(owned_api_keys_type_0_item)

                return owned_api_keys_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[ApiKey] | None | Unset, data)

        owned_api_keys = _parse_owned_api_keys(d.pop("owned_api_keys", UNSET))

        def _parse_created_api_keys(data: object) -> list[ApiKey] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                created_api_keys_type_0 = []
                _created_api_keys_type_0 = data
                for created_api_keys_type_0_item_data in _created_api_keys_type_0:
                    created_api_keys_type_0_item = ApiKey.from_dict(created_api_keys_type_0_item_data)

                    created_api_keys_type_0.append(created_api_keys_type_0_item)

                return created_api_keys_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[ApiKey] | None | Unset, data)

        created_api_keys = _parse_created_api_keys(d.pop("created_api_keys", UNSET))

        def _parse_revoked_api_keys(data: object) -> list[ApiKey] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                revoked_api_keys_type_0 = []
                _revoked_api_keys_type_0 = data
                for revoked_api_keys_type_0_item_data in _revoked_api_keys_type_0:
                    revoked_api_keys_type_0_item = ApiKey.from_dict(revoked_api_keys_type_0_item_data)

                    revoked_api_keys_type_0.append(revoked_api_keys_type_0_item)

                return revoked_api_keys_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[ApiKey] | None | Unset, data)

        revoked_api_keys = _parse_revoked_api_keys(d.pop("revoked_api_keys", UNSET))

        profile = cls(
            user_id=user_id,
            created_at=created_at,
            updated_at=updated_at,
            auto_recharge_enabled=auto_recharge_enabled,
            name=name,
            email=email,
            profile_picture=profile_picture,
            bio=bio,
            auto_recharge_threshold=auto_recharge_threshold,
            auto_recharge_package_id=auto_recharge_package_id,
            formulations=formulations,
            token_packages=token_packages,
            runs=runs,
            token_balances=token_balances,
            token_purchases=token_purchases,
            token_usage=token_usage,
            forecasting=forecasting,
            organization_memberships=organization_memberships,
            owned_api_keys=owned_api_keys,
            created_api_keys=created_api_keys,
            revoked_api_keys=revoked_api_keys,
        )

        profile.additional_properties = d
        return profile

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
