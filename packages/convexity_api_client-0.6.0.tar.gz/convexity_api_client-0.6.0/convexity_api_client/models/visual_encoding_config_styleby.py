from enum import Enum


class VisualEncodingConfigStyleby(str, Enum):
    GROUP = "group"
    METRIC = "metric"
    NONE = "none"

    def __str__(self) -> str:
        return str(self.value)
