from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.dashboard import Dashboard


T = TypeVar("T", bound="DashboardShare")


@_attrs_define
class DashboardShare:
    """Represents a DashboardShare record

    Attributes:
        id (str):
        dashboard_id (str):
        share_token (str):
        is_active (bool):
        allowed_domains (list[str]):
        allow_filtering (bool):
        show_branding (bool):
        view_count (int):
        created_at (datetime.datetime):
        updated_at (datetime.datetime):
        created_by (str):
        expires_at (datetime.datetime | None | Unset):
        custom_title (None | str | Unset):
        last_viewed_at (datetime.datetime | None | Unset):
        dashboard (Dashboard | None | Unset):
    """

    id: str
    dashboard_id: str
    share_token: str
    is_active: bool
    allowed_domains: list[str]
    allow_filtering: bool
    show_branding: bool
    view_count: int
    created_at: datetime.datetime
    updated_at: datetime.datetime
    created_by: str
    expires_at: datetime.datetime | None | Unset = UNSET
    custom_title: None | str | Unset = UNSET
    last_viewed_at: datetime.datetime | None | Unset = UNSET
    dashboard: Dashboard | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.dashboard import Dashboard

        id = self.id

        dashboard_id = self.dashboard_id

        share_token = self.share_token

        is_active = self.is_active

        allowed_domains = self.allowed_domains

        allow_filtering = self.allow_filtering

        show_branding = self.show_branding

        view_count = self.view_count

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        created_by = self.created_by

        expires_at: None | str | Unset
        if isinstance(self.expires_at, Unset):
            expires_at = UNSET
        elif isinstance(self.expires_at, datetime.datetime):
            expires_at = self.expires_at.isoformat()
        else:
            expires_at = self.expires_at

        custom_title: None | str | Unset
        if isinstance(self.custom_title, Unset):
            custom_title = UNSET
        else:
            custom_title = self.custom_title

        last_viewed_at: None | str | Unset
        if isinstance(self.last_viewed_at, Unset):
            last_viewed_at = UNSET
        elif isinstance(self.last_viewed_at, datetime.datetime):
            last_viewed_at = self.last_viewed_at.isoformat()
        else:
            last_viewed_at = self.last_viewed_at

        dashboard: dict[str, Any] | None | Unset
        if isinstance(self.dashboard, Unset):
            dashboard = UNSET
        elif isinstance(self.dashboard, Dashboard):
            dashboard = self.dashboard.to_dict()
        else:
            dashboard = self.dashboard

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "dashboard_id": dashboard_id,
                "share_token": share_token,
                "is_active": is_active,
                "allowed_domains": allowed_domains,
                "allow_filtering": allow_filtering,
                "show_branding": show_branding,
                "view_count": view_count,
                "created_at": created_at,
                "updated_at": updated_at,
                "created_by": created_by,
            }
        )
        if expires_at is not UNSET:
            field_dict["expires_at"] = expires_at
        if custom_title is not UNSET:
            field_dict["custom_title"] = custom_title
        if last_viewed_at is not UNSET:
            field_dict["last_viewed_at"] = last_viewed_at
        if dashboard is not UNSET:
            field_dict["dashboard"] = dashboard

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.dashboard import Dashboard

        d = dict(src_dict)
        id = d.pop("id")

        dashboard_id = d.pop("dashboard_id")

        share_token = d.pop("share_token")

        is_active = d.pop("is_active")

        allowed_domains = cast(list[str], d.pop("allowed_domains"))

        allow_filtering = d.pop("allow_filtering")

        show_branding = d.pop("show_branding")

        view_count = d.pop("view_count")

        created_at = isoparse(d.pop("created_at"))

        updated_at = isoparse(d.pop("updated_at"))

        created_by = d.pop("created_by")

        def _parse_expires_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                expires_at_type_0 = isoparse(data)

                return expires_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        expires_at = _parse_expires_at(d.pop("expires_at", UNSET))

        def _parse_custom_title(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        custom_title = _parse_custom_title(d.pop("custom_title", UNSET))

        def _parse_last_viewed_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_viewed_at_type_0 = isoparse(data)

                return last_viewed_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        last_viewed_at = _parse_last_viewed_at(d.pop("last_viewed_at", UNSET))

        def _parse_dashboard(data: object) -> Dashboard | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                dashboard_type_0 = Dashboard.from_dict(data)

                return dashboard_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(Dashboard | None | Unset, data)

        dashboard = _parse_dashboard(d.pop("dashboard", UNSET))

        dashboard_share = cls(
            id=id,
            dashboard_id=dashboard_id,
            share_token=share_token,
            is_active=is_active,
            allowed_domains=allowed_domains,
            allow_filtering=allow_filtering,
            show_branding=show_branding,
            view_count=view_count,
            created_at=created_at,
            updated_at=updated_at,
            created_by=created_by,
            expires_at=expires_at,
            custom_title=custom_title,
            last_viewed_at=last_viewed_at,
            dashboard=dashboard,
        )

        dashboard_share.additional_properties = d
        return dashboard_share

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
