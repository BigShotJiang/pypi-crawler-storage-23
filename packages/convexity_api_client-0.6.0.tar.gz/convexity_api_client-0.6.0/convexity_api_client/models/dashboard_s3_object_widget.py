from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="DashboardS3ObjectWidget")


@_attrs_define
class DashboardS3ObjectWidget:
    """S3 Object widget definition.

    Attributes:
        id (str): Unique widget identifier
        title (None | str | Unset): Widget title
        description (None | str | Unset): Widget description
        show_title (bool | None | Unset): Whether to display the widget title Default: True.
        show_description (bool | None | Unset): Whether to display the widget description Default: True.
        type_ (Literal['s3object'] | Unset):  Default: 's3object'.
        connection_id (None | str | Unset): S3 connection ID
        object_key (None | str | Unset): S3 object key
    """

    id: str
    title: None | str | Unset = UNSET
    description: None | str | Unset = UNSET
    show_title: bool | None | Unset = True
    show_description: bool | None | Unset = True
    type_: Literal["s3object"] | Unset = "s3object"
    connection_id: None | str | Unset = UNSET
    object_key: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        title: None | str | Unset
        if isinstance(self.title, Unset):
            title = UNSET
        else:
            title = self.title

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        show_title: bool | None | Unset
        if isinstance(self.show_title, Unset):
            show_title = UNSET
        else:
            show_title = self.show_title

        show_description: bool | None | Unset
        if isinstance(self.show_description, Unset):
            show_description = UNSET
        else:
            show_description = self.show_description

        type_ = self.type_

        connection_id: None | str | Unset
        if isinstance(self.connection_id, Unset):
            connection_id = UNSET
        else:
            connection_id = self.connection_id

        object_key: None | str | Unset
        if isinstance(self.object_key, Unset):
            object_key = UNSET
        else:
            object_key = self.object_key

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
            }
        )
        if title is not UNSET:
            field_dict["title"] = title
        if description is not UNSET:
            field_dict["description"] = description
        if show_title is not UNSET:
            field_dict["showTitle"] = show_title
        if show_description is not UNSET:
            field_dict["showDescription"] = show_description
        if type_ is not UNSET:
            field_dict["type"] = type_
        if connection_id is not UNSET:
            field_dict["connectionId"] = connection_id
        if object_key is not UNSET:
            field_dict["objectKey"] = object_key

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        def _parse_title(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        title = _parse_title(d.pop("title", UNSET))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_show_title(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_title = _parse_show_title(d.pop("showTitle", UNSET))

        def _parse_show_description(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_description = _parse_show_description(d.pop("showDescription", UNSET))

        type_ = cast(Literal["s3object"] | Unset, d.pop("type", UNSET))
        if type_ != "s3object" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 's3object', got '{type_}'")

        def _parse_connection_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        connection_id = _parse_connection_id(d.pop("connectionId", UNSET))

        def _parse_object_key(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        object_key = _parse_object_key(d.pop("objectKey", UNSET))

        dashboard_s3_object_widget = cls(
            id=id,
            title=title,
            description=description,
            show_title=show_title,
            show_description=show_description,
            type_=type_,
            connection_id=connection_id,
            object_key=object_key,
        )

        dashboard_s3_object_widget.additional_properties = d
        return dashboard_s3_object_widget

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
