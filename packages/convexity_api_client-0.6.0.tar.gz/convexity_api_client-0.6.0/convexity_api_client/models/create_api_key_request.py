from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.api_key_permission import ApiKeyPermission
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.api_key_scope_roles import ApiKeyScopeRoles


T = TypeVar("T", bound="CreateApiKeyRequest")


@_attrs_define
class CreateApiKeyRequest:
    """Request to create a new API key.

    Attributes:
        name (str): Name for the API key
        description (None | str | Unset):
        permission (ApiKeyPermission | Unset):
        scopes (ApiKeyScopeRoles | None | Unset): Role scopes for org/project resources
        expires_at (datetime.datetime | None | Unset):
        rate_limit (int | None | Unset):
        allowed_ips (list[str] | None | Unset):
    """

    name: str
    description: None | str | Unset = UNSET
    permission: ApiKeyPermission | Unset = UNSET
    scopes: ApiKeyScopeRoles | None | Unset = UNSET
    expires_at: datetime.datetime | None | Unset = UNSET
    rate_limit: int | None | Unset = UNSET
    allowed_ips: list[str] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.api_key_scope_roles import ApiKeyScopeRoles

        name = self.name

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        permission: str | Unset = UNSET
        if not isinstance(self.permission, Unset):
            permission = self.permission.value

        scopes: dict[str, Any] | None | Unset
        if isinstance(self.scopes, Unset):
            scopes = UNSET
        elif isinstance(self.scopes, ApiKeyScopeRoles):
            scopes = self.scopes.to_dict()
        else:
            scopes = self.scopes

        expires_at: None | str | Unset
        if isinstance(self.expires_at, Unset):
            expires_at = UNSET
        elif isinstance(self.expires_at, datetime.datetime):
            expires_at = self.expires_at.isoformat()
        else:
            expires_at = self.expires_at

        rate_limit: int | None | Unset
        if isinstance(self.rate_limit, Unset):
            rate_limit = UNSET
        else:
            rate_limit = self.rate_limit

        allowed_ips: list[str] | None | Unset
        if isinstance(self.allowed_ips, Unset):
            allowed_ips = UNSET
        elif isinstance(self.allowed_ips, list):
            allowed_ips = self.allowed_ips

        else:
            allowed_ips = self.allowed_ips

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if permission is not UNSET:
            field_dict["permission"] = permission
        if scopes is not UNSET:
            field_dict["scopes"] = scopes
        if expires_at is not UNSET:
            field_dict["expiresAt"] = expires_at
        if rate_limit is not UNSET:
            field_dict["rateLimit"] = rate_limit
        if allowed_ips is not UNSET:
            field_dict["allowedIps"] = allowed_ips

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.api_key_scope_roles import ApiKeyScopeRoles

        d = dict(src_dict)
        name = d.pop("name")

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        _permission = d.pop("permission", UNSET)
        permission: ApiKeyPermission | Unset
        if isinstance(_permission, Unset):
            permission = UNSET
        else:
            permission = ApiKeyPermission(_permission)

        def _parse_scopes(data: object) -> ApiKeyScopeRoles | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                scopes_type_0 = ApiKeyScopeRoles.from_dict(data)

                return scopes_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ApiKeyScopeRoles | None | Unset, data)

        scopes = _parse_scopes(d.pop("scopes", UNSET))

        def _parse_expires_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                expires_at_type_0 = isoparse(data)

                return expires_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        expires_at = _parse_expires_at(d.pop("expiresAt", UNSET))

        def _parse_rate_limit(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        rate_limit = _parse_rate_limit(d.pop("rateLimit", UNSET))

        def _parse_allowed_ips(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                allowed_ips_type_0 = cast(list[str], data)

                return allowed_ips_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        allowed_ips = _parse_allowed_ips(d.pop("allowedIps", UNSET))

        create_api_key_request = cls(
            name=name,
            description=description,
            permission=permission,
            scopes=scopes,
            expires_at=expires_at,
            rate_limit=rate_limit,
            allowed_ips=allowed_ips,
        )

        create_api_key_request.additional_properties = d
        return create_api_key_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
