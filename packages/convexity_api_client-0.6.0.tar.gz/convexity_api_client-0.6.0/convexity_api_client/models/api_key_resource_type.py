from enum import Enum


class ApiKeyResourceType(str, Enum):
    ORG = "ORG"
    PROJECT = "PROJECT"

    def __str__(self) -> str:
        return str(self.value)
