from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.auth_type import AuthType
from ..models.connection_status import ConnectionStatus
from ..models.http_method import HttpMethod
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.api_connection_headers_type_0 import ApiConnectionHeadersType0


T = TypeVar("T", bound="ApiConnection")


@_attrs_define
class ApiConnection:
    """Connection to a REST API.

    Attributes:
        project_id (str): Project this connection belongs to
        name (str): Connection name
        endpoint (str): API endpoint URL
        id (None | str | Unset): Connection ID
        user_id (None | str | Unset): Owner user ID
        description (None | str | Unset): Connection description
        type_ (Literal['API'] | Unset):  Default: 'API'.
        status (ConnectionStatus | Unset):
        last_tested (None | str | Unset): Last verification timestamp
        error_message (None | str | Unset): Error message if status is error
        created_at (None | str | Unset): Creation timestamp
        updated_at (None | str | Unset): Last update timestamp
        method (HttpMethod | Unset): HTTP methods.
        auth_type (AuthType | Unset): Authentication types for API connections.
        api_key (None | str | Unset): API key
        api_key_header (None | str | Unset): Header name for API key Default: 'X-API-Key'.
        bearer_token (None | str | Unset): Bearer token
        basic_username (None | str | Unset): Basic auth username
        basic_password (None | str | Unset): Basic auth password
        headers (ApiConnectionHeadersType0 | None | Unset): Additional headers
    """

    project_id: str
    name: str
    endpoint: str
    id: None | str | Unset = UNSET
    user_id: None | str | Unset = UNSET
    description: None | str | Unset = UNSET
    type_: Literal["API"] | Unset = "API"
    status: ConnectionStatus | Unset = UNSET
    last_tested: None | str | Unset = UNSET
    error_message: None | str | Unset = UNSET
    created_at: None | str | Unset = UNSET
    updated_at: None | str | Unset = UNSET
    method: HttpMethod | Unset = UNSET
    auth_type: AuthType | Unset = UNSET
    api_key: None | str | Unset = UNSET
    api_key_header: None | str | Unset = "X-API-Key"
    bearer_token: None | str | Unset = UNSET
    basic_username: None | str | Unset = UNSET
    basic_password: None | str | Unset = UNSET
    headers: ApiConnectionHeadersType0 | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.api_connection_headers_type_0 import ApiConnectionHeadersType0

        project_id = self.project_id

        name = self.name

        endpoint = self.endpoint

        id: None | str | Unset
        if isinstance(self.id, Unset):
            id = UNSET
        else:
            id = self.id

        user_id: None | str | Unset
        if isinstance(self.user_id, Unset):
            user_id = UNSET
        else:
            user_id = self.user_id

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        type_ = self.type_

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value

        last_tested: None | str | Unset
        if isinstance(self.last_tested, Unset):
            last_tested = UNSET
        else:
            last_tested = self.last_tested

        error_message: None | str | Unset
        if isinstance(self.error_message, Unset):
            error_message = UNSET
        else:
            error_message = self.error_message

        created_at: None | str | Unset
        if isinstance(self.created_at, Unset):
            created_at = UNSET
        else:
            created_at = self.created_at

        updated_at: None | str | Unset
        if isinstance(self.updated_at, Unset):
            updated_at = UNSET
        else:
            updated_at = self.updated_at

        method: str | Unset = UNSET
        if not isinstance(self.method, Unset):
            method = self.method.value

        auth_type: str | Unset = UNSET
        if not isinstance(self.auth_type, Unset):
            auth_type = self.auth_type.value

        api_key: None | str | Unset
        if isinstance(self.api_key, Unset):
            api_key = UNSET
        else:
            api_key = self.api_key

        api_key_header: None | str | Unset
        if isinstance(self.api_key_header, Unset):
            api_key_header = UNSET
        else:
            api_key_header = self.api_key_header

        bearer_token: None | str | Unset
        if isinstance(self.bearer_token, Unset):
            bearer_token = UNSET
        else:
            bearer_token = self.bearer_token

        basic_username: None | str | Unset
        if isinstance(self.basic_username, Unset):
            basic_username = UNSET
        else:
            basic_username = self.basic_username

        basic_password: None | str | Unset
        if isinstance(self.basic_password, Unset):
            basic_password = UNSET
        else:
            basic_password = self.basic_password

        headers: dict[str, Any] | None | Unset
        if isinstance(self.headers, Unset):
            headers = UNSET
        elif isinstance(self.headers, ApiConnectionHeadersType0):
            headers = self.headers.to_dict()
        else:
            headers = self.headers

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "projectId": project_id,
                "name": name,
                "endpoint": endpoint,
            }
        )
        if id is not UNSET:
            field_dict["id"] = id
        if user_id is not UNSET:
            field_dict["userId"] = user_id
        if description is not UNSET:
            field_dict["description"] = description
        if type_ is not UNSET:
            field_dict["type"] = type_
        if status is not UNSET:
            field_dict["status"] = status
        if last_tested is not UNSET:
            field_dict["lastTested"] = last_tested
        if error_message is not UNSET:
            field_dict["errorMessage"] = error_message
        if created_at is not UNSET:
            field_dict["createdAt"] = created_at
        if updated_at is not UNSET:
            field_dict["updatedAt"] = updated_at
        if method is not UNSET:
            field_dict["method"] = method
        if auth_type is not UNSET:
            field_dict["authType"] = auth_type
        if api_key is not UNSET:
            field_dict["apiKey"] = api_key
        if api_key_header is not UNSET:
            field_dict["apiKeyHeader"] = api_key_header
        if bearer_token is not UNSET:
            field_dict["bearerToken"] = bearer_token
        if basic_username is not UNSET:
            field_dict["basicUsername"] = basic_username
        if basic_password is not UNSET:
            field_dict["basicPassword"] = basic_password
        if headers is not UNSET:
            field_dict["headers"] = headers

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.api_connection_headers_type_0 import ApiConnectionHeadersType0

        d = dict(src_dict)
        project_id = d.pop("projectId")

        name = d.pop("name")

        endpoint = d.pop("endpoint")

        def _parse_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        id = _parse_id(d.pop("id", UNSET))

        def _parse_user_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        user_id = _parse_user_id(d.pop("userId", UNSET))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        type_ = cast(Literal["API"] | Unset, d.pop("type", UNSET))
        if type_ != "API" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'API', got '{type_}'")

        _status = d.pop("status", UNSET)
        status: ConnectionStatus | Unset
        if isinstance(_status, Unset):
            status = UNSET
        else:
            status = ConnectionStatus(_status)

        def _parse_last_tested(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        last_tested = _parse_last_tested(d.pop("lastTested", UNSET))

        def _parse_error_message(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        error_message = _parse_error_message(d.pop("errorMessage", UNSET))

        def _parse_created_at(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        created_at = _parse_created_at(d.pop("createdAt", UNSET))

        def _parse_updated_at(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        updated_at = _parse_updated_at(d.pop("updatedAt", UNSET))

        _method = d.pop("method", UNSET)
        method: HttpMethod | Unset
        if isinstance(_method, Unset):
            method = UNSET
        else:
            method = HttpMethod(_method)

        _auth_type = d.pop("authType", UNSET)
        auth_type: AuthType | Unset
        if isinstance(_auth_type, Unset):
            auth_type = UNSET
        else:
            auth_type = AuthType(_auth_type)

        def _parse_api_key(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        api_key = _parse_api_key(d.pop("apiKey", UNSET))

        def _parse_api_key_header(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        api_key_header = _parse_api_key_header(d.pop("apiKeyHeader", UNSET))

        def _parse_bearer_token(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        bearer_token = _parse_bearer_token(d.pop("bearerToken", UNSET))

        def _parse_basic_username(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        basic_username = _parse_basic_username(d.pop("basicUsername", UNSET))

        def _parse_basic_password(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        basic_password = _parse_basic_password(d.pop("basicPassword", UNSET))

        def _parse_headers(data: object) -> ApiConnectionHeadersType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                headers_type_0 = ApiConnectionHeadersType0.from_dict(data)

                return headers_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ApiConnectionHeadersType0 | None | Unset, data)

        headers = _parse_headers(d.pop("headers", UNSET))

        api_connection = cls(
            project_id=project_id,
            name=name,
            endpoint=endpoint,
            id=id,
            user_id=user_id,
            description=description,
            type_=type_,
            status=status,
            last_tested=last_tested,
            error_message=error_message,
            created_at=created_at,
            updated_at=updated_at,
            method=method,
            auth_type=auth_type,
            api_key=api_key,
            api_key_header=api_key_header,
            bearer_token=bearer_token,
            basic_username=basic_username,
            basic_password=basic_password,
            headers=headers,
        )

        api_connection.additional_properties = d
        return api_connection

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
