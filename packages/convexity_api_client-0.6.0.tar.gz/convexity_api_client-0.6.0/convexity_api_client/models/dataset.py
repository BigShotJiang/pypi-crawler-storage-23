from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.dataset_type import DatasetType
from ..models.refresh_mode import RefreshMode
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.connection_dto import ConnectionDTO
    from ..models.dashboard_dataset import DashboardDataset
    from ..models.dataset_snapshot import DatasetSnapshot
    from ..models.project import Project
    from ..models.refresh_task import RefreshTask


T = TypeVar("T", bound="Dataset")


@_attrs_define
class Dataset:
    """Represents a Dataset record

    Attributes:
        id (str):
        user_id (str):
        project_id (str):
        name (str):
        type_ (DatasetType):
        config (str):
        refresh_mode (RefreshMode):
        tags (list[str]):
        created_at (datetime.datetime):
        updated_at (datetime.datetime):
        description (None | str | Unset):
        connection_id (None | str | Unset):
        column_schema (None | str | Unset):
        refresh_schedule (None | str | Unset):
        last_refreshed_at (datetime.datetime | None | Unset):
        cache_ttl_seconds (int | None | Unset):
        project (None | Project | Unset):
        connection (ConnectionDTO | None | Unset):
        snapshots (list[DatasetSnapshot] | None | Unset):
        dashboard_links (list[DashboardDataset] | None | Unset):
        refresh_tasks (list[RefreshTask] | None | Unset):
    """

    id: str
    user_id: str
    project_id: str
    name: str
    type_: DatasetType
    config: str
    refresh_mode: RefreshMode
    tags: list[str]
    created_at: datetime.datetime
    updated_at: datetime.datetime
    description: None | str | Unset = UNSET
    connection_id: None | str | Unset = UNSET
    column_schema: None | str | Unset = UNSET
    refresh_schedule: None | str | Unset = UNSET
    last_refreshed_at: datetime.datetime | None | Unset = UNSET
    cache_ttl_seconds: int | None | Unset = UNSET
    project: None | Project | Unset = UNSET
    connection: ConnectionDTO | None | Unset = UNSET
    snapshots: list[DatasetSnapshot] | None | Unset = UNSET
    dashboard_links: list[DashboardDataset] | None | Unset = UNSET
    refresh_tasks: list[RefreshTask] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.connection_dto import ConnectionDTO
        from ..models.project import Project

        id = self.id

        user_id = self.user_id

        project_id = self.project_id

        name = self.name

        type_ = self.type_.value

        config = self.config

        refresh_mode = self.refresh_mode.value

        tags = self.tags

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        connection_id: None | str | Unset
        if isinstance(self.connection_id, Unset):
            connection_id = UNSET
        else:
            connection_id = self.connection_id

        column_schema: None | str | Unset
        if isinstance(self.column_schema, Unset):
            column_schema = UNSET
        else:
            column_schema = self.column_schema

        refresh_schedule: None | str | Unset
        if isinstance(self.refresh_schedule, Unset):
            refresh_schedule = UNSET
        else:
            refresh_schedule = self.refresh_schedule

        last_refreshed_at: None | str | Unset
        if isinstance(self.last_refreshed_at, Unset):
            last_refreshed_at = UNSET
        elif isinstance(self.last_refreshed_at, datetime.datetime):
            last_refreshed_at = self.last_refreshed_at.isoformat()
        else:
            last_refreshed_at = self.last_refreshed_at

        cache_ttl_seconds: int | None | Unset
        if isinstance(self.cache_ttl_seconds, Unset):
            cache_ttl_seconds = UNSET
        else:
            cache_ttl_seconds = self.cache_ttl_seconds

        project: dict[str, Any] | None | Unset
        if isinstance(self.project, Unset):
            project = UNSET
        elif isinstance(self.project, Project):
            project = self.project.to_dict()
        else:
            project = self.project

        connection: dict[str, Any] | None | Unset
        if isinstance(self.connection, Unset):
            connection = UNSET
        elif isinstance(self.connection, ConnectionDTO):
            connection = self.connection.to_dict()
        else:
            connection = self.connection

        snapshots: list[dict[str, Any]] | None | Unset
        if isinstance(self.snapshots, Unset):
            snapshots = UNSET
        elif isinstance(self.snapshots, list):
            snapshots = []
            for snapshots_type_0_item_data in self.snapshots:
                snapshots_type_0_item = snapshots_type_0_item_data.to_dict()
                snapshots.append(snapshots_type_0_item)

        else:
            snapshots = self.snapshots

        dashboard_links: list[dict[str, Any]] | None | Unset
        if isinstance(self.dashboard_links, Unset):
            dashboard_links = UNSET
        elif isinstance(self.dashboard_links, list):
            dashboard_links = []
            for dashboard_links_type_0_item_data in self.dashboard_links:
                dashboard_links_type_0_item = dashboard_links_type_0_item_data.to_dict()
                dashboard_links.append(dashboard_links_type_0_item)

        else:
            dashboard_links = self.dashboard_links

        refresh_tasks: list[dict[str, Any]] | None | Unset
        if isinstance(self.refresh_tasks, Unset):
            refresh_tasks = UNSET
        elif isinstance(self.refresh_tasks, list):
            refresh_tasks = []
            for refresh_tasks_type_0_item_data in self.refresh_tasks:
                refresh_tasks_type_0_item = refresh_tasks_type_0_item_data.to_dict()
                refresh_tasks.append(refresh_tasks_type_0_item)

        else:
            refresh_tasks = self.refresh_tasks

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "user_id": user_id,
                "project_id": project_id,
                "name": name,
                "type": type_,
                "config": config,
                "refresh_mode": refresh_mode,
                "tags": tags,
                "created_at": created_at,
                "updated_at": updated_at,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if connection_id is not UNSET:
            field_dict["connection_id"] = connection_id
        if column_schema is not UNSET:
            field_dict["column_schema"] = column_schema
        if refresh_schedule is not UNSET:
            field_dict["refresh_schedule"] = refresh_schedule
        if last_refreshed_at is not UNSET:
            field_dict["last_refreshed_at"] = last_refreshed_at
        if cache_ttl_seconds is not UNSET:
            field_dict["cache_ttl_seconds"] = cache_ttl_seconds
        if project is not UNSET:
            field_dict["project"] = project
        if connection is not UNSET:
            field_dict["connection"] = connection
        if snapshots is not UNSET:
            field_dict["snapshots"] = snapshots
        if dashboard_links is not UNSET:
            field_dict["dashboardLinks"] = dashboard_links
        if refresh_tasks is not UNSET:
            field_dict["refreshTasks"] = refresh_tasks

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.connection_dto import ConnectionDTO
        from ..models.dashboard_dataset import DashboardDataset
        from ..models.dataset_snapshot import DatasetSnapshot
        from ..models.project import Project
        from ..models.refresh_task import RefreshTask

        d = dict(src_dict)
        id = d.pop("id")

        user_id = d.pop("user_id")

        project_id = d.pop("project_id")

        name = d.pop("name")

        type_ = DatasetType(d.pop("type"))

        config = d.pop("config")

        refresh_mode = RefreshMode(d.pop("refresh_mode"))

        tags = cast(list[str], d.pop("tags"))

        created_at = isoparse(d.pop("created_at"))

        updated_at = isoparse(d.pop("updated_at"))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_connection_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        connection_id = _parse_connection_id(d.pop("connection_id", UNSET))

        def _parse_column_schema(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        column_schema = _parse_column_schema(d.pop("column_schema", UNSET))

        def _parse_refresh_schedule(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        refresh_schedule = _parse_refresh_schedule(d.pop("refresh_schedule", UNSET))

        def _parse_last_refreshed_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_refreshed_at_type_0 = isoparse(data)

                return last_refreshed_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        last_refreshed_at = _parse_last_refreshed_at(d.pop("last_refreshed_at", UNSET))

        def _parse_cache_ttl_seconds(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        cache_ttl_seconds = _parse_cache_ttl_seconds(d.pop("cache_ttl_seconds", UNSET))

        def _parse_project(data: object) -> None | Project | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                project_type_0 = Project.from_dict(data)

                return project_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Project | Unset, data)

        project = _parse_project(d.pop("project", UNSET))

        def _parse_connection(data: object) -> ConnectionDTO | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                connection_type_0 = ConnectionDTO.from_dict(data)

                return connection_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ConnectionDTO | None | Unset, data)

        connection = _parse_connection(d.pop("connection", UNSET))

        def _parse_snapshots(data: object) -> list[DatasetSnapshot] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                snapshots_type_0 = []
                _snapshots_type_0 = data
                for snapshots_type_0_item_data in _snapshots_type_0:
                    snapshots_type_0_item = DatasetSnapshot.from_dict(snapshots_type_0_item_data)

                    snapshots_type_0.append(snapshots_type_0_item)

                return snapshots_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[DatasetSnapshot] | None | Unset, data)

        snapshots = _parse_snapshots(d.pop("snapshots", UNSET))

        def _parse_dashboard_links(data: object) -> list[DashboardDataset] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                dashboard_links_type_0 = []
                _dashboard_links_type_0 = data
                for dashboard_links_type_0_item_data in _dashboard_links_type_0:
                    dashboard_links_type_0_item = DashboardDataset.from_dict(dashboard_links_type_0_item_data)

                    dashboard_links_type_0.append(dashboard_links_type_0_item)

                return dashboard_links_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[DashboardDataset] | None | Unset, data)

        dashboard_links = _parse_dashboard_links(d.pop("dashboardLinks", UNSET))

        def _parse_refresh_tasks(data: object) -> list[RefreshTask] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                refresh_tasks_type_0 = []
                _refresh_tasks_type_0 = data
                for refresh_tasks_type_0_item_data in _refresh_tasks_type_0:
                    refresh_tasks_type_0_item = RefreshTask.from_dict(refresh_tasks_type_0_item_data)

                    refresh_tasks_type_0.append(refresh_tasks_type_0_item)

                return refresh_tasks_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[RefreshTask] | None | Unset, data)

        refresh_tasks = _parse_refresh_tasks(d.pop("refreshTasks", UNSET))

        dataset = cls(
            id=id,
            user_id=user_id,
            project_id=project_id,
            name=name,
            type_=type_,
            config=config,
            refresh_mode=refresh_mode,
            tags=tags,
            created_at=created_at,
            updated_at=updated_at,
            description=description,
            connection_id=connection_id,
            column_schema=column_schema,
            refresh_schedule=refresh_schedule,
            last_refreshed_at=last_refreshed_at,
            cache_ttl_seconds=cache_ttl_seconds,
            project=project,
            connection=connection,
            snapshots=snapshots,
            dashboard_links=dashboard_links,
            refresh_tasks=refresh_tasks,
        )

        dataset.additional_properties = d
        return dataset

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
