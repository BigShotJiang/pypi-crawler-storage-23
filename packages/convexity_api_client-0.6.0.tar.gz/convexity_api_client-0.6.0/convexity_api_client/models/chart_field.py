from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.chart_field_line_style_type_0 import ChartFieldLineStyleType0
from ..models.chart_field_line_type_type_0 import ChartFieldLineTypeType0
from ..models.chart_field_transform_type_0 import ChartFieldTransformType0
from ..types import UNSET, Unset

T = TypeVar("T", bound="ChartField")


@_attrs_define
class ChartField:
    """Field configuration for chart axes and values.
    Represents a data field with optional aggregation/transform and display name.
    Used for x/y axes in cartesian charts and name/value fields in pie charts.

        Attributes:
            name (str): Column/field name from the dataset
            display_name (None | str | Unset): Custom display name for the field
            transform (ChartFieldTransformType0 | None | Unset): Aggregation/transform function to apply
            percentile_value (float | None | Unset): Percentile value (0-100) when transform is 'percentile'
            color (None | str | Unset): Series color (hex or CSS color string)
            line_style (ChartFieldLineStyleType0 | None | Unset): Line style for line/area charts
            line_width (int | None | Unset): Line width in pixels
            line_type (ChartFieldLineTypeType0 | None | Unset): Line plot type for line charts
    """

    name: str
    display_name: None | str | Unset = UNSET
    transform: ChartFieldTransformType0 | None | Unset = UNSET
    percentile_value: float | None | Unset = UNSET
    color: None | str | Unset = UNSET
    line_style: ChartFieldLineStyleType0 | None | Unset = UNSET
    line_width: int | None | Unset = UNSET
    line_type: ChartFieldLineTypeType0 | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        display_name: None | str | Unset
        if isinstance(self.display_name, Unset):
            display_name = UNSET
        else:
            display_name = self.display_name

        transform: None | str | Unset
        if isinstance(self.transform, Unset):
            transform = UNSET
        elif isinstance(self.transform, ChartFieldTransformType0):
            transform = self.transform.value
        else:
            transform = self.transform

        percentile_value: float | None | Unset
        if isinstance(self.percentile_value, Unset):
            percentile_value = UNSET
        else:
            percentile_value = self.percentile_value

        color: None | str | Unset
        if isinstance(self.color, Unset):
            color = UNSET
        else:
            color = self.color

        line_style: None | str | Unset
        if isinstance(self.line_style, Unset):
            line_style = UNSET
        elif isinstance(self.line_style, ChartFieldLineStyleType0):
            line_style = self.line_style.value
        else:
            line_style = self.line_style

        line_width: int | None | Unset
        if isinstance(self.line_width, Unset):
            line_width = UNSET
        else:
            line_width = self.line_width

        line_type: None | str | Unset
        if isinstance(self.line_type, Unset):
            line_type = UNSET
        elif isinstance(self.line_type, ChartFieldLineTypeType0):
            line_type = self.line_type.value
        else:
            line_type = self.line_type

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
            }
        )
        if display_name is not UNSET:
            field_dict["displayName"] = display_name
        if transform is not UNSET:
            field_dict["transform"] = transform
        if percentile_value is not UNSET:
            field_dict["percentileValue"] = percentile_value
        if color is not UNSET:
            field_dict["color"] = color
        if line_style is not UNSET:
            field_dict["lineStyle"] = line_style
        if line_width is not UNSET:
            field_dict["lineWidth"] = line_width
        if line_type is not UNSET:
            field_dict["lineType"] = line_type

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        def _parse_display_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        display_name = _parse_display_name(d.pop("displayName", UNSET))

        def _parse_transform(data: object) -> ChartFieldTransformType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                transform_type_0 = ChartFieldTransformType0(data)

                return transform_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ChartFieldTransformType0 | None | Unset, data)

        transform = _parse_transform(d.pop("transform", UNSET))

        def _parse_percentile_value(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        percentile_value = _parse_percentile_value(d.pop("percentileValue", UNSET))

        def _parse_color(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        color = _parse_color(d.pop("color", UNSET))

        def _parse_line_style(data: object) -> ChartFieldLineStyleType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                line_style_type_0 = ChartFieldLineStyleType0(data)

                return line_style_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ChartFieldLineStyleType0 | None | Unset, data)

        line_style = _parse_line_style(d.pop("lineStyle", UNSET))

        def _parse_line_width(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        line_width = _parse_line_width(d.pop("lineWidth", UNSET))

        def _parse_line_type(data: object) -> ChartFieldLineTypeType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                line_type_type_0 = ChartFieldLineTypeType0(data)

                return line_type_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ChartFieldLineTypeType0 | None | Unset, data)

        line_type = _parse_line_type(d.pop("lineType", UNSET))

        chart_field = cls(
            name=name,
            display_name=display_name,
            transform=transform,
            percentile_value=percentile_value,
            color=color,
            line_style=line_style,
            line_width=line_width,
            line_type=line_type,
        )

        chart_field.additional_properties = d
        return chart_field

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
