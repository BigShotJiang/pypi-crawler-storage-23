from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.column_aggregation_type_0 import ColumnAggregationType0
from ..models.column_role import ColumnRole
from ..models.column_semantic_type_type_0 import ColumnSemanticTypeType0
from ..models.column_type import ColumnType
from ..types import UNSET, Unset

T = TypeVar("T", bound="Column")


@_attrs_define
class Column:
    """Column definition for chart data.

    Attributes:
        name (str): Column name
        type_ (ColumnType): Data type of the column
        role (ColumnRole): Column role
        description (None | str | Unset): Column description
        semantic_type (ColumnSemanticTypeType0 | None | Unset): Semantic type of the column
        aggregation (ColumnAggregationType0 | None | Unset): Aggregation function
        original_expression (None | str | Unset): Original expression
    """

    name: str
    type_: ColumnType
    role: ColumnRole
    description: None | str | Unset = UNSET
    semantic_type: ColumnSemanticTypeType0 | None | Unset = UNSET
    aggregation: ColumnAggregationType0 | None | Unset = UNSET
    original_expression: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        type_ = self.type_.value

        role = self.role.value

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        semantic_type: None | str | Unset
        if isinstance(self.semantic_type, Unset):
            semantic_type = UNSET
        elif isinstance(self.semantic_type, ColumnSemanticTypeType0):
            semantic_type = self.semantic_type.value
        else:
            semantic_type = self.semantic_type

        aggregation: None | str | Unset
        if isinstance(self.aggregation, Unset):
            aggregation = UNSET
        elif isinstance(self.aggregation, ColumnAggregationType0):
            aggregation = self.aggregation.value
        else:
            aggregation = self.aggregation

        original_expression: None | str | Unset
        if isinstance(self.original_expression, Unset):
            original_expression = UNSET
        else:
            original_expression = self.original_expression

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "type": type_,
                "role": role,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if semantic_type is not UNSET:
            field_dict["semanticType"] = semantic_type
        if aggregation is not UNSET:
            field_dict["aggregation"] = aggregation
        if original_expression is not UNSET:
            field_dict["originalExpression"] = original_expression

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        type_ = ColumnType(d.pop("type"))

        role = ColumnRole(d.pop("role"))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_semantic_type(data: object) -> ColumnSemanticTypeType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                semantic_type_type_0 = ColumnSemanticTypeType0(data)

                return semantic_type_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ColumnSemanticTypeType0 | None | Unset, data)

        semantic_type = _parse_semantic_type(d.pop("semanticType", UNSET))

        def _parse_aggregation(data: object) -> ColumnAggregationType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                aggregation_type_0 = ColumnAggregationType0(data)

                return aggregation_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ColumnAggregationType0 | None | Unset, data)

        aggregation = _parse_aggregation(d.pop("aggregation", UNSET))

        def _parse_original_expression(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        original_expression = _parse_original_expression(d.pop("originalExpression", UNSET))

        column = cls(
            name=name,
            type_=type_,
            role=role,
            description=description,
            semantic_type=semantic_type,
            aggregation=aggregation,
            original_expression=original_expression,
        )

        column.additional_properties = d
        return column

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
