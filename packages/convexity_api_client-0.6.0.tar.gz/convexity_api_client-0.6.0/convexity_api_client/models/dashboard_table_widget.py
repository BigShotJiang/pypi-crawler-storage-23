from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.dashboard_table_widget_default_sort_direction_type_0 import DashboardTableWidgetDefaultSortDirectionType0
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.dashboard_table_widget_column_widths_type_0 import DashboardTableWidgetColumnWidthsType0


T = TypeVar("T", bound="DashboardTableWidget")


@_attrs_define
class DashboardTableWidget:
    """Table widget definition for displaying tabular data from a Dataset.

    Attributes:
        id (str): Unique widget identifier
        title (None | str | Unset): Widget title
        description (None | str | Unset): Widget description
        show_title (bool | None | Unset): Whether to display the widget title Default: True.
        show_description (bool | None | Unset): Whether to display the widget description Default: True.
        type_ (Literal['table'] | Unset):  Default: 'table'.
        dataset_id (None | str | Unset): ID of the linked dataset to display
        page_size (int | None | Unset): Rows per page for pagination Default: 25.
        visible_columns (list[str] | None | Unset): List of column names to display (default: all)
        column_order (list[str] | None | Unset): Custom order of columns
        column_widths (DashboardTableWidgetColumnWidthsType0 | None | Unset): Custom column widths in pixels
        default_sort_column (None | str | Unset): Default column to sort by
        default_sort_direction (DashboardTableWidgetDefaultSortDirectionType0 | None | Unset): Default sort direction
            Default: DashboardTableWidgetDefaultSortDirectionType0.ASC.
        enable_filtering (bool | None | Unset): Enable column filtering Default: True.
        enable_sorting (bool | None | Unset): Enable column sorting Default: True.
        enable_pagination (bool | None | Unset): Enable pagination Default: True.
        show_row_numbers (bool | None | Unset): Show row numbers Default: True.
    """

    id: str
    title: None | str | Unset = UNSET
    description: None | str | Unset = UNSET
    show_title: bool | None | Unset = True
    show_description: bool | None | Unset = True
    type_: Literal["table"] | Unset = "table"
    dataset_id: None | str | Unset = UNSET
    page_size: int | None | Unset = 25
    visible_columns: list[str] | None | Unset = UNSET
    column_order: list[str] | None | Unset = UNSET
    column_widths: DashboardTableWidgetColumnWidthsType0 | None | Unset = UNSET
    default_sort_column: None | str | Unset = UNSET
    default_sort_direction: DashboardTableWidgetDefaultSortDirectionType0 | None | Unset = (
        DashboardTableWidgetDefaultSortDirectionType0.ASC
    )
    enable_filtering: bool | None | Unset = True
    enable_sorting: bool | None | Unset = True
    enable_pagination: bool | None | Unset = True
    show_row_numbers: bool | None | Unset = True
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.dashboard_table_widget_column_widths_type_0 import DashboardTableWidgetColumnWidthsType0

        id = self.id

        title: None | str | Unset
        if isinstance(self.title, Unset):
            title = UNSET
        else:
            title = self.title

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        show_title: bool | None | Unset
        if isinstance(self.show_title, Unset):
            show_title = UNSET
        else:
            show_title = self.show_title

        show_description: bool | None | Unset
        if isinstance(self.show_description, Unset):
            show_description = UNSET
        else:
            show_description = self.show_description

        type_ = self.type_

        dataset_id: None | str | Unset
        if isinstance(self.dataset_id, Unset):
            dataset_id = UNSET
        else:
            dataset_id = self.dataset_id

        page_size: int | None | Unset
        if isinstance(self.page_size, Unset):
            page_size = UNSET
        else:
            page_size = self.page_size

        visible_columns: list[str] | None | Unset
        if isinstance(self.visible_columns, Unset):
            visible_columns = UNSET
        elif isinstance(self.visible_columns, list):
            visible_columns = self.visible_columns

        else:
            visible_columns = self.visible_columns

        column_order: list[str] | None | Unset
        if isinstance(self.column_order, Unset):
            column_order = UNSET
        elif isinstance(self.column_order, list):
            column_order = self.column_order

        else:
            column_order = self.column_order

        column_widths: dict[str, Any] | None | Unset
        if isinstance(self.column_widths, Unset):
            column_widths = UNSET
        elif isinstance(self.column_widths, DashboardTableWidgetColumnWidthsType0):
            column_widths = self.column_widths.to_dict()
        else:
            column_widths = self.column_widths

        default_sort_column: None | str | Unset
        if isinstance(self.default_sort_column, Unset):
            default_sort_column = UNSET
        else:
            default_sort_column = self.default_sort_column

        default_sort_direction: None | str | Unset
        if isinstance(self.default_sort_direction, Unset):
            default_sort_direction = UNSET
        elif isinstance(self.default_sort_direction, DashboardTableWidgetDefaultSortDirectionType0):
            default_sort_direction = self.default_sort_direction.value
        else:
            default_sort_direction = self.default_sort_direction

        enable_filtering: bool | None | Unset
        if isinstance(self.enable_filtering, Unset):
            enable_filtering = UNSET
        else:
            enable_filtering = self.enable_filtering

        enable_sorting: bool | None | Unset
        if isinstance(self.enable_sorting, Unset):
            enable_sorting = UNSET
        else:
            enable_sorting = self.enable_sorting

        enable_pagination: bool | None | Unset
        if isinstance(self.enable_pagination, Unset):
            enable_pagination = UNSET
        else:
            enable_pagination = self.enable_pagination

        show_row_numbers: bool | None | Unset
        if isinstance(self.show_row_numbers, Unset):
            show_row_numbers = UNSET
        else:
            show_row_numbers = self.show_row_numbers

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
            }
        )
        if title is not UNSET:
            field_dict["title"] = title
        if description is not UNSET:
            field_dict["description"] = description
        if show_title is not UNSET:
            field_dict["showTitle"] = show_title
        if show_description is not UNSET:
            field_dict["showDescription"] = show_description
        if type_ is not UNSET:
            field_dict["type"] = type_
        if dataset_id is not UNSET:
            field_dict["datasetId"] = dataset_id
        if page_size is not UNSET:
            field_dict["pageSize"] = page_size
        if visible_columns is not UNSET:
            field_dict["visibleColumns"] = visible_columns
        if column_order is not UNSET:
            field_dict["columnOrder"] = column_order
        if column_widths is not UNSET:
            field_dict["columnWidths"] = column_widths
        if default_sort_column is not UNSET:
            field_dict["defaultSortColumn"] = default_sort_column
        if default_sort_direction is not UNSET:
            field_dict["defaultSortDirection"] = default_sort_direction
        if enable_filtering is not UNSET:
            field_dict["enableFiltering"] = enable_filtering
        if enable_sorting is not UNSET:
            field_dict["enableSorting"] = enable_sorting
        if enable_pagination is not UNSET:
            field_dict["enablePagination"] = enable_pagination
        if show_row_numbers is not UNSET:
            field_dict["showRowNumbers"] = show_row_numbers

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.dashboard_table_widget_column_widths_type_0 import DashboardTableWidgetColumnWidthsType0

        d = dict(src_dict)
        id = d.pop("id")

        def _parse_title(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        title = _parse_title(d.pop("title", UNSET))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_show_title(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_title = _parse_show_title(d.pop("showTitle", UNSET))

        def _parse_show_description(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_description = _parse_show_description(d.pop("showDescription", UNSET))

        type_ = cast(Literal["table"] | Unset, d.pop("type", UNSET))
        if type_ != "table" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'table', got '{type_}'")

        def _parse_dataset_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        dataset_id = _parse_dataset_id(d.pop("datasetId", UNSET))

        def _parse_page_size(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        page_size = _parse_page_size(d.pop("pageSize", UNSET))

        def _parse_visible_columns(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                visible_columns_type_0 = cast(list[str], data)

                return visible_columns_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        visible_columns = _parse_visible_columns(d.pop("visibleColumns", UNSET))

        def _parse_column_order(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                column_order_type_0 = cast(list[str], data)

                return column_order_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        column_order = _parse_column_order(d.pop("columnOrder", UNSET))

        def _parse_column_widths(data: object) -> DashboardTableWidgetColumnWidthsType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                column_widths_type_0 = DashboardTableWidgetColumnWidthsType0.from_dict(data)

                return column_widths_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(DashboardTableWidgetColumnWidthsType0 | None | Unset, data)

        column_widths = _parse_column_widths(d.pop("columnWidths", UNSET))

        def _parse_default_sort_column(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        default_sort_column = _parse_default_sort_column(d.pop("defaultSortColumn", UNSET))

        def _parse_default_sort_direction(data: object) -> DashboardTableWidgetDefaultSortDirectionType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                default_sort_direction_type_0 = DashboardTableWidgetDefaultSortDirectionType0(data)

                return default_sort_direction_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(DashboardTableWidgetDefaultSortDirectionType0 | None | Unset, data)

        default_sort_direction = _parse_default_sort_direction(d.pop("defaultSortDirection", UNSET))

        def _parse_enable_filtering(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        enable_filtering = _parse_enable_filtering(d.pop("enableFiltering", UNSET))

        def _parse_enable_sorting(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        enable_sorting = _parse_enable_sorting(d.pop("enableSorting", UNSET))

        def _parse_enable_pagination(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        enable_pagination = _parse_enable_pagination(d.pop("enablePagination", UNSET))

        def _parse_show_row_numbers(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_row_numbers = _parse_show_row_numbers(d.pop("showRowNumbers", UNSET))

        dashboard_table_widget = cls(
            id=id,
            title=title,
            description=description,
            show_title=show_title,
            show_description=show_description,
            type_=type_,
            dataset_id=dataset_id,
            page_size=page_size,
            visible_columns=visible_columns,
            column_order=column_order,
            column_widths=column_widths,
            default_sort_column=default_sort_column,
            default_sort_direction=default_sort_direction,
            enable_filtering=enable_filtering,
            enable_sorting=enable_sorting,
            enable_pagination=enable_pagination,
            show_row_numbers=show_row_numbers,
        )

        dashboard_table_widget.additional_properties = d
        return dashboard_table_widget

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
