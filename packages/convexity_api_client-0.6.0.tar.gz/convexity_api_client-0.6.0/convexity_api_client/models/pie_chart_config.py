from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.pie_chart_config_label_position_type_0 import PieChartConfigLabelPositionType0
from ..models.pie_chart_config_legend_orientation_type_0 import PieChartConfigLegendOrientationType0
from ..models.pie_chart_config_legend_position_type_0 import PieChartConfigLegendPositionType0
from ..models.pie_chart_config_rose_type_type_0 import PieChartConfigRoseTypeType0
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.chart_field import ChartField
    from ..models.chart_filter import ChartFilter
    from ..models.pie_chart_config_chart_padding_type_1 import PieChartConfigChartPaddingType1
    from ..models.tooltip_config import TooltipConfig
    from ..models.visual_encoding_config import VisualEncodingConfig


T = TypeVar("T", bound="PieChartConfig")


@_attrs_define
class PieChartConfig:
    """Configuration for pie charts.

    Attributes:
        type_ (Literal['pie'] | Unset):  Default: 'pie'.
        name_field (ChartField | None | Unset): Name/label field configuration
        value_field (ChartField | None | Unset): Value field configuration
        inner_radius (None | str | Unset): Inner radius for donut (e.g., '50%')
        outer_radius (None | str | Unset): Outer radius (e.g., '70%') Default: '70%'.
        colors (list[str] | None | Unset): Custom colors
        show_labels (bool | None | Unset): Whether to show labels Default: True.
        label_position (None | PieChartConfigLabelPositionType0 | Unset): Label position Default:
            PieChartConfigLabelPositionType0.OUTSIDE.
        rose_type (None | PieChartConfigRoseTypeType0 | Unset): Rose chart type
        show_legend (bool | None | Unset): Whether to show legend Default: True.
        legend_position (None | PieChartConfigLegendPositionType0 | Unset): Legend position
        legend_orientation (None | PieChartConfigLegendOrientationType0 | Unset): Legend orientation
        visual_encoding (None | Unset | VisualEncodingConfig): Configuration for visual encoding (color mapping for pie
            slices)
        tooltip_config (None | TooltipConfig | Unset): Tooltip configuration
        filters (list[ChartFilter] | None | Unset): Chart-specific filters (applied before dashboard filters)
        chart_padding (int | None | PieChartConfigChartPaddingType1 | Unset): Chart padding (space around the chart
            inside the widget). Can be a single number for all sides, or an object for individual sides
    """

    type_: Literal["pie"] | Unset = "pie"
    name_field: ChartField | None | Unset = UNSET
    value_field: ChartField | None | Unset = UNSET
    inner_radius: None | str | Unset = UNSET
    outer_radius: None | str | Unset = "70%"
    colors: list[str] | None | Unset = UNSET
    show_labels: bool | None | Unset = True
    label_position: None | PieChartConfigLabelPositionType0 | Unset = PieChartConfigLabelPositionType0.OUTSIDE
    rose_type: None | PieChartConfigRoseTypeType0 | Unset = UNSET
    show_legend: bool | None | Unset = True
    legend_position: None | PieChartConfigLegendPositionType0 | Unset = UNSET
    legend_orientation: None | PieChartConfigLegendOrientationType0 | Unset = UNSET
    visual_encoding: None | Unset | VisualEncodingConfig = UNSET
    tooltip_config: None | TooltipConfig | Unset = UNSET
    filters: list[ChartFilter] | None | Unset = UNSET
    chart_padding: int | None | PieChartConfigChartPaddingType1 | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.chart_field import ChartField
        from ..models.pie_chart_config_chart_padding_type_1 import PieChartConfigChartPaddingType1
        from ..models.tooltip_config import TooltipConfig
        from ..models.visual_encoding_config import VisualEncodingConfig

        type_ = self.type_

        name_field: dict[str, Any] | None | Unset
        if isinstance(self.name_field, Unset):
            name_field = UNSET
        elif isinstance(self.name_field, ChartField):
            name_field = self.name_field.to_dict()
        else:
            name_field = self.name_field

        value_field: dict[str, Any] | None | Unset
        if isinstance(self.value_field, Unset):
            value_field = UNSET
        elif isinstance(self.value_field, ChartField):
            value_field = self.value_field.to_dict()
        else:
            value_field = self.value_field

        inner_radius: None | str | Unset
        if isinstance(self.inner_radius, Unset):
            inner_radius = UNSET
        else:
            inner_radius = self.inner_radius

        outer_radius: None | str | Unset
        if isinstance(self.outer_radius, Unset):
            outer_radius = UNSET
        else:
            outer_radius = self.outer_radius

        colors: list[str] | None | Unset
        if isinstance(self.colors, Unset):
            colors = UNSET
        elif isinstance(self.colors, list):
            colors = self.colors

        else:
            colors = self.colors

        show_labels: bool | None | Unset
        if isinstance(self.show_labels, Unset):
            show_labels = UNSET
        else:
            show_labels = self.show_labels

        label_position: None | str | Unset
        if isinstance(self.label_position, Unset):
            label_position = UNSET
        elif isinstance(self.label_position, PieChartConfigLabelPositionType0):
            label_position = self.label_position.value
        else:
            label_position = self.label_position

        rose_type: None | str | Unset
        if isinstance(self.rose_type, Unset):
            rose_type = UNSET
        elif isinstance(self.rose_type, PieChartConfigRoseTypeType0):
            rose_type = self.rose_type.value
        else:
            rose_type = self.rose_type

        show_legend: bool | None | Unset
        if isinstance(self.show_legend, Unset):
            show_legend = UNSET
        else:
            show_legend = self.show_legend

        legend_position: None | str | Unset
        if isinstance(self.legend_position, Unset):
            legend_position = UNSET
        elif isinstance(self.legend_position, PieChartConfigLegendPositionType0):
            legend_position = self.legend_position.value
        else:
            legend_position = self.legend_position

        legend_orientation: None | str | Unset
        if isinstance(self.legend_orientation, Unset):
            legend_orientation = UNSET
        elif isinstance(self.legend_orientation, PieChartConfigLegendOrientationType0):
            legend_orientation = self.legend_orientation.value
        else:
            legend_orientation = self.legend_orientation

        visual_encoding: dict[str, Any] | None | Unset
        if isinstance(self.visual_encoding, Unset):
            visual_encoding = UNSET
        elif isinstance(self.visual_encoding, VisualEncodingConfig):
            visual_encoding = self.visual_encoding.to_dict()
        else:
            visual_encoding = self.visual_encoding

        tooltip_config: dict[str, Any] | None | Unset
        if isinstance(self.tooltip_config, Unset):
            tooltip_config = UNSET
        elif isinstance(self.tooltip_config, TooltipConfig):
            tooltip_config = self.tooltip_config.to_dict()
        else:
            tooltip_config = self.tooltip_config

        filters: list[dict[str, Any]] | None | Unset
        if isinstance(self.filters, Unset):
            filters = UNSET
        elif isinstance(self.filters, list):
            filters = []
            for filters_type_0_item_data in self.filters:
                filters_type_0_item = filters_type_0_item_data.to_dict()
                filters.append(filters_type_0_item)

        else:
            filters = self.filters

        chart_padding: dict[str, Any] | int | None | Unset
        if isinstance(self.chart_padding, Unset):
            chart_padding = UNSET
        elif isinstance(self.chart_padding, PieChartConfigChartPaddingType1):
            chart_padding = self.chart_padding.to_dict()
        else:
            chart_padding = self.chart_padding

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if type_ is not UNSET:
            field_dict["type"] = type_
        if name_field is not UNSET:
            field_dict["nameField"] = name_field
        if value_field is not UNSET:
            field_dict["valueField"] = value_field
        if inner_radius is not UNSET:
            field_dict["innerRadius"] = inner_radius
        if outer_radius is not UNSET:
            field_dict["outerRadius"] = outer_radius
        if colors is not UNSET:
            field_dict["colors"] = colors
        if show_labels is not UNSET:
            field_dict["showLabels"] = show_labels
        if label_position is not UNSET:
            field_dict["labelPosition"] = label_position
        if rose_type is not UNSET:
            field_dict["roseType"] = rose_type
        if show_legend is not UNSET:
            field_dict["showLegend"] = show_legend
        if legend_position is not UNSET:
            field_dict["legendPosition"] = legend_position
        if legend_orientation is not UNSET:
            field_dict["legendOrientation"] = legend_orientation
        if visual_encoding is not UNSET:
            field_dict["visualEncoding"] = visual_encoding
        if tooltip_config is not UNSET:
            field_dict["tooltipConfig"] = tooltip_config
        if filters is not UNSET:
            field_dict["filters"] = filters
        if chart_padding is not UNSET:
            field_dict["chartPadding"] = chart_padding

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.chart_field import ChartField
        from ..models.chart_filter import ChartFilter
        from ..models.pie_chart_config_chart_padding_type_1 import PieChartConfigChartPaddingType1
        from ..models.tooltip_config import TooltipConfig
        from ..models.visual_encoding_config import VisualEncodingConfig

        d = dict(src_dict)
        type_ = cast(Literal["pie"] | Unset, d.pop("type", UNSET))
        if type_ != "pie" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'pie', got '{type_}'")

        def _parse_name_field(data: object) -> ChartField | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                name_field_type_0 = ChartField.from_dict(data)

                return name_field_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ChartField | None | Unset, data)

        name_field = _parse_name_field(d.pop("nameField", UNSET))

        def _parse_value_field(data: object) -> ChartField | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                value_field_type_0 = ChartField.from_dict(data)

                return value_field_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ChartField | None | Unset, data)

        value_field = _parse_value_field(d.pop("valueField", UNSET))

        def _parse_inner_radius(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        inner_radius = _parse_inner_radius(d.pop("innerRadius", UNSET))

        def _parse_outer_radius(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        outer_radius = _parse_outer_radius(d.pop("outerRadius", UNSET))

        def _parse_colors(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                colors_type_0 = cast(list[str], data)

                return colors_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        colors = _parse_colors(d.pop("colors", UNSET))

        def _parse_show_labels(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_labels = _parse_show_labels(d.pop("showLabels", UNSET))

        def _parse_label_position(data: object) -> None | PieChartConfigLabelPositionType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                label_position_type_0 = PieChartConfigLabelPositionType0(data)

                return label_position_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | PieChartConfigLabelPositionType0 | Unset, data)

        label_position = _parse_label_position(d.pop("labelPosition", UNSET))

        def _parse_rose_type(data: object) -> None | PieChartConfigRoseTypeType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                rose_type_type_0 = PieChartConfigRoseTypeType0(data)

                return rose_type_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | PieChartConfigRoseTypeType0 | Unset, data)

        rose_type = _parse_rose_type(d.pop("roseType", UNSET))

        def _parse_show_legend(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_legend = _parse_show_legend(d.pop("showLegend", UNSET))

        def _parse_legend_position(data: object) -> None | PieChartConfigLegendPositionType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                legend_position_type_0 = PieChartConfigLegendPositionType0(data)

                return legend_position_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | PieChartConfigLegendPositionType0 | Unset, data)

        legend_position = _parse_legend_position(d.pop("legendPosition", UNSET))

        def _parse_legend_orientation(data: object) -> None | PieChartConfigLegendOrientationType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                legend_orientation_type_0 = PieChartConfigLegendOrientationType0(data)

                return legend_orientation_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | PieChartConfigLegendOrientationType0 | Unset, data)

        legend_orientation = _parse_legend_orientation(d.pop("legendOrientation", UNSET))

        def _parse_visual_encoding(data: object) -> None | Unset | VisualEncodingConfig:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                visual_encoding_type_0 = VisualEncodingConfig.from_dict(data)

                return visual_encoding_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | VisualEncodingConfig, data)

        visual_encoding = _parse_visual_encoding(d.pop("visualEncoding", UNSET))

        def _parse_tooltip_config(data: object) -> None | TooltipConfig | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                tooltip_config_type_0 = TooltipConfig.from_dict(data)

                return tooltip_config_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | TooltipConfig | Unset, data)

        tooltip_config = _parse_tooltip_config(d.pop("tooltipConfig", UNSET))

        def _parse_filters(data: object) -> list[ChartFilter] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                filters_type_0 = []
                _filters_type_0 = data
                for filters_type_0_item_data in _filters_type_0:
                    filters_type_0_item = ChartFilter.from_dict(filters_type_0_item_data)

                    filters_type_0.append(filters_type_0_item)

                return filters_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[ChartFilter] | None | Unset, data)

        filters = _parse_filters(d.pop("filters", UNSET))

        def _parse_chart_padding(data: object) -> int | None | PieChartConfigChartPaddingType1 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                chart_padding_type_1 = PieChartConfigChartPaddingType1.from_dict(data)

                return chart_padding_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(int | None | PieChartConfigChartPaddingType1 | Unset, data)

        chart_padding = _parse_chart_padding(d.pop("chartPadding", UNSET))

        pie_chart_config = cls(
            type_=type_,
            name_field=name_field,
            value_field=value_field,
            inner_radius=inner_radius,
            outer_radius=outer_radius,
            colors=colors,
            show_labels=show_labels,
            label_position=label_position,
            rose_type=rose_type,
            show_legend=show_legend,
            legend_position=legend_position,
            legend_orientation=legend_orientation,
            visual_encoding=visual_encoding,
            tooltip_config=tooltip_config,
            filters=filters,
            chart_padding=chart_padding,
        )

        pie_chart_config.additional_properties = d
        return pie_chart_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
