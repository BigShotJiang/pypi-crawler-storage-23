from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.chart_filter_config_match_mode_type_0 import ChartFilterConfigMatchModeType0
from ..models.chart_filter_config_operator_type_0 import ChartFilterConfigOperatorType0
from ..types import UNSET, Unset

T = TypeVar("T", bound="ChartFilterConfig")


@_attrs_define
class ChartFilterConfig:
    """Configuration options for chart filters.

    Attributes:
        match_mode (ChartFilterConfigMatchModeType0 | None | Unset): Text matching mode
        case_sensitive (bool | None | Unset): Whether text matching is case-sensitive
        operator (ChartFilterConfigOperatorType0 | None | Unset): Comparison operator for number filters
    """

    match_mode: ChartFilterConfigMatchModeType0 | None | Unset = UNSET
    case_sensitive: bool | None | Unset = UNSET
    operator: ChartFilterConfigOperatorType0 | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        match_mode: None | str | Unset
        if isinstance(self.match_mode, Unset):
            match_mode = UNSET
        elif isinstance(self.match_mode, ChartFilterConfigMatchModeType0):
            match_mode = self.match_mode.value
        else:
            match_mode = self.match_mode

        case_sensitive: bool | None | Unset
        if isinstance(self.case_sensitive, Unset):
            case_sensitive = UNSET
        else:
            case_sensitive = self.case_sensitive

        operator: None | str | Unset
        if isinstance(self.operator, Unset):
            operator = UNSET
        elif isinstance(self.operator, ChartFilterConfigOperatorType0):
            operator = self.operator.value
        else:
            operator = self.operator

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if match_mode is not UNSET:
            field_dict["matchMode"] = match_mode
        if case_sensitive is not UNSET:
            field_dict["caseSensitive"] = case_sensitive
        if operator is not UNSET:
            field_dict["operator"] = operator

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_match_mode(data: object) -> ChartFilterConfigMatchModeType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                match_mode_type_0 = ChartFilterConfigMatchModeType0(data)

                return match_mode_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ChartFilterConfigMatchModeType0 | None | Unset, data)

        match_mode = _parse_match_mode(d.pop("matchMode", UNSET))

        def _parse_case_sensitive(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        case_sensitive = _parse_case_sensitive(d.pop("caseSensitive", UNSET))

        def _parse_operator(data: object) -> ChartFilterConfigOperatorType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                operator_type_0 = ChartFilterConfigOperatorType0(data)

                return operator_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ChartFilterConfigOperatorType0 | None | Unset, data)

        operator = _parse_operator(d.pop("operator", UNSET))

        chart_filter_config = cls(
            match_mode=match_mode,
            case_sensitive=case_sensitive,
            operator=operator,
        )

        chart_filter_config.additional_properties = d
        return chart_filter_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
