from enum import Enum


class CellType(str, Enum):
    CODE = "code"
    MARKDOWN = "markdown"

    def __str__(self) -> str:
        return str(self.value)
