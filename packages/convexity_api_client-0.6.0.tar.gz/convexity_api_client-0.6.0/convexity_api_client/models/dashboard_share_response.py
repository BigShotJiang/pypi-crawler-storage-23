from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="DashboardShareResponse")


@_attrs_define
class DashboardShareResponse:
    """Response containing share information.

    Attributes:
        id (str): Share ID
        dashboard_id (str): Dashboard ID
        share_token (str): Public share token
        is_active (bool): Whether share is active
        allow_filtering (bool): Filtering enabled
        show_branding (bool): Branding shown
        view_count (int): Total view count
        created_at (datetime.datetime): Created timestamp
        created_by (str): User who created the share
        expires_at (datetime.datetime | None | Unset): Expiration date
        allowed_domains (list[str] | Unset): Allowed embed domains
        custom_title (None | str | Unset): Custom title
        last_viewed_at (datetime.datetime | None | Unset): Last viewed timestamp
    """

    id: str
    dashboard_id: str
    share_token: str
    is_active: bool
    allow_filtering: bool
    show_branding: bool
    view_count: int
    created_at: datetime.datetime
    created_by: str
    expires_at: datetime.datetime | None | Unset = UNSET
    allowed_domains: list[str] | Unset = UNSET
    custom_title: None | str | Unset = UNSET
    last_viewed_at: datetime.datetime | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        dashboard_id = self.dashboard_id

        share_token = self.share_token

        is_active = self.is_active

        allow_filtering = self.allow_filtering

        show_branding = self.show_branding

        view_count = self.view_count

        created_at = self.created_at.isoformat()

        created_by = self.created_by

        expires_at: None | str | Unset
        if isinstance(self.expires_at, Unset):
            expires_at = UNSET
        elif isinstance(self.expires_at, datetime.datetime):
            expires_at = self.expires_at.isoformat()
        else:
            expires_at = self.expires_at

        allowed_domains: list[str] | Unset = UNSET
        if not isinstance(self.allowed_domains, Unset):
            allowed_domains = self.allowed_domains

        custom_title: None | str | Unset
        if isinstance(self.custom_title, Unset):
            custom_title = UNSET
        else:
            custom_title = self.custom_title

        last_viewed_at: None | str | Unset
        if isinstance(self.last_viewed_at, Unset):
            last_viewed_at = UNSET
        elif isinstance(self.last_viewed_at, datetime.datetime):
            last_viewed_at = self.last_viewed_at.isoformat()
        else:
            last_viewed_at = self.last_viewed_at

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "dashboardId": dashboard_id,
                "shareToken": share_token,
                "isActive": is_active,
                "allowFiltering": allow_filtering,
                "showBranding": show_branding,
                "viewCount": view_count,
                "createdAt": created_at,
                "createdBy": created_by,
            }
        )
        if expires_at is not UNSET:
            field_dict["expiresAt"] = expires_at
        if allowed_domains is not UNSET:
            field_dict["allowedDomains"] = allowed_domains
        if custom_title is not UNSET:
            field_dict["customTitle"] = custom_title
        if last_viewed_at is not UNSET:
            field_dict["lastViewedAt"] = last_viewed_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        dashboard_id = d.pop("dashboardId")

        share_token = d.pop("shareToken")

        is_active = d.pop("isActive")

        allow_filtering = d.pop("allowFiltering")

        show_branding = d.pop("showBranding")

        view_count = d.pop("viewCount")

        created_at = isoparse(d.pop("createdAt"))

        created_by = d.pop("createdBy")

        def _parse_expires_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                expires_at_type_0 = isoparse(data)

                return expires_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        expires_at = _parse_expires_at(d.pop("expiresAt", UNSET))

        allowed_domains = cast(list[str], d.pop("allowedDomains", UNSET))

        def _parse_custom_title(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        custom_title = _parse_custom_title(d.pop("customTitle", UNSET))

        def _parse_last_viewed_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_viewed_at_type_0 = isoparse(data)

                return last_viewed_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        last_viewed_at = _parse_last_viewed_at(d.pop("lastViewedAt", UNSET))

        dashboard_share_response = cls(
            id=id,
            dashboard_id=dashboard_id,
            share_token=share_token,
            is_active=is_active,
            allow_filtering=allow_filtering,
            show_branding=show_branding,
            view_count=view_count,
            created_at=created_at,
            created_by=created_by,
            expires_at=expires_at,
            allowed_domains=allowed_domains,
            custom_title=custom_title,
            last_viewed_at=last_viewed_at,
        )

        dashboard_share_response.additional_properties = d
        return dashboard_share_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
