from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.chat_session import ChatSession
    from ..models.connection_dto import ConnectionDTO
    from ..models.dashboard import Dashboard
    from ..models.dataset import Dataset
    from ..models.organization import Organization
    from ..models.task_dto import TaskDTO


T = TypeVar("T", bound="Project")


@_attrs_define
class Project:
    """Represents a Project record

    Attributes:
        id (str):
        name (str):
        slug (str):
        organization_id (str):
        created_at (datetime.datetime):
        updated_at (datetime.datetime):
        description (None | str | Unset):
        organization (None | Organization | Unset):
        connections (list[ConnectionDTO] | None | Unset):
        tasks (list[TaskDTO] | None | Unset):
        dashboards (list[Dashboard] | None | Unset):
        chat_sessions (list[ChatSession] | None | Unset):
        datasets (list[Dataset] | None | Unset):
    """

    id: str
    name: str
    slug: str
    organization_id: str
    created_at: datetime.datetime
    updated_at: datetime.datetime
    description: None | str | Unset = UNSET
    organization: None | Organization | Unset = UNSET
    connections: list[ConnectionDTO] | None | Unset = UNSET
    tasks: list[TaskDTO] | None | Unset = UNSET
    dashboards: list[Dashboard] | None | Unset = UNSET
    chat_sessions: list[ChatSession] | None | Unset = UNSET
    datasets: list[Dataset] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.organization import Organization

        id = self.id

        name = self.name

        slug = self.slug

        organization_id = self.organization_id

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        organization: dict[str, Any] | None | Unset
        if isinstance(self.organization, Unset):
            organization = UNSET
        elif isinstance(self.organization, Organization):
            organization = self.organization.to_dict()
        else:
            organization = self.organization

        connections: list[dict[str, Any]] | None | Unset
        if isinstance(self.connections, Unset):
            connections = UNSET
        elif isinstance(self.connections, list):
            connections = []
            for connections_type_0_item_data in self.connections:
                connections_type_0_item = connections_type_0_item_data.to_dict()
                connections.append(connections_type_0_item)

        else:
            connections = self.connections

        tasks: list[dict[str, Any]] | None | Unset
        if isinstance(self.tasks, Unset):
            tasks = UNSET
        elif isinstance(self.tasks, list):
            tasks = []
            for tasks_type_0_item_data in self.tasks:
                tasks_type_0_item = tasks_type_0_item_data.to_dict()
                tasks.append(tasks_type_0_item)

        else:
            tasks = self.tasks

        dashboards: list[dict[str, Any]] | None | Unset
        if isinstance(self.dashboards, Unset):
            dashboards = UNSET
        elif isinstance(self.dashboards, list):
            dashboards = []
            for dashboards_type_0_item_data in self.dashboards:
                dashboards_type_0_item = dashboards_type_0_item_data.to_dict()
                dashboards.append(dashboards_type_0_item)

        else:
            dashboards = self.dashboards

        chat_sessions: list[dict[str, Any]] | None | Unset
        if isinstance(self.chat_sessions, Unset):
            chat_sessions = UNSET
        elif isinstance(self.chat_sessions, list):
            chat_sessions = []
            for chat_sessions_type_0_item_data in self.chat_sessions:
                chat_sessions_type_0_item = chat_sessions_type_0_item_data.to_dict()
                chat_sessions.append(chat_sessions_type_0_item)

        else:
            chat_sessions = self.chat_sessions

        datasets: list[dict[str, Any]] | None | Unset
        if isinstance(self.datasets, Unset):
            datasets = UNSET
        elif isinstance(self.datasets, list):
            datasets = []
            for datasets_type_0_item_data in self.datasets:
                datasets_type_0_item = datasets_type_0_item_data.to_dict()
                datasets.append(datasets_type_0_item)

        else:
            datasets = self.datasets

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "name": name,
                "slug": slug,
                "organization_id": organization_id,
                "created_at": created_at,
                "updated_at": updated_at,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if organization is not UNSET:
            field_dict["organization"] = organization
        if connections is not UNSET:
            field_dict["connections"] = connections
        if tasks is not UNSET:
            field_dict["tasks"] = tasks
        if dashboards is not UNSET:
            field_dict["dashboards"] = dashboards
        if chat_sessions is not UNSET:
            field_dict["chatSessions"] = chat_sessions
        if datasets is not UNSET:
            field_dict["datasets"] = datasets

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.chat_session import ChatSession
        from ..models.connection_dto import ConnectionDTO
        from ..models.dashboard import Dashboard
        from ..models.dataset import Dataset
        from ..models.organization import Organization
        from ..models.task_dto import TaskDTO

        d = dict(src_dict)
        id = d.pop("id")

        name = d.pop("name")

        slug = d.pop("slug")

        organization_id = d.pop("organization_id")

        created_at = isoparse(d.pop("created_at"))

        updated_at = isoparse(d.pop("updated_at"))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_organization(data: object) -> None | Organization | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                organization_type_0 = Organization.from_dict(data)

                return organization_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Organization | Unset, data)

        organization = _parse_organization(d.pop("organization", UNSET))

        def _parse_connections(data: object) -> list[ConnectionDTO] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                connections_type_0 = []
                _connections_type_0 = data
                for connections_type_0_item_data in _connections_type_0:
                    connections_type_0_item = ConnectionDTO.from_dict(connections_type_0_item_data)

                    connections_type_0.append(connections_type_0_item)

                return connections_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[ConnectionDTO] | None | Unset, data)

        connections = _parse_connections(d.pop("connections", UNSET))

        def _parse_tasks(data: object) -> list[TaskDTO] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                tasks_type_0 = []
                _tasks_type_0 = data
                for tasks_type_0_item_data in _tasks_type_0:
                    tasks_type_0_item = TaskDTO.from_dict(tasks_type_0_item_data)

                    tasks_type_0.append(tasks_type_0_item)

                return tasks_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[TaskDTO] | None | Unset, data)

        tasks = _parse_tasks(d.pop("tasks", UNSET))

        def _parse_dashboards(data: object) -> list[Dashboard] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                dashboards_type_0 = []
                _dashboards_type_0 = data
                for dashboards_type_0_item_data in _dashboards_type_0:
                    dashboards_type_0_item = Dashboard.from_dict(dashboards_type_0_item_data)

                    dashboards_type_0.append(dashboards_type_0_item)

                return dashboards_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[Dashboard] | None | Unset, data)

        dashboards = _parse_dashboards(d.pop("dashboards", UNSET))

        def _parse_chat_sessions(data: object) -> list[ChatSession] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                chat_sessions_type_0 = []
                _chat_sessions_type_0 = data
                for chat_sessions_type_0_item_data in _chat_sessions_type_0:
                    chat_sessions_type_0_item = ChatSession.from_dict(chat_sessions_type_0_item_data)

                    chat_sessions_type_0.append(chat_sessions_type_0_item)

                return chat_sessions_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[ChatSession] | None | Unset, data)

        chat_sessions = _parse_chat_sessions(d.pop("chatSessions", UNSET))

        def _parse_datasets(data: object) -> list[Dataset] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                datasets_type_0 = []
                _datasets_type_0 = data
                for datasets_type_0_item_data in _datasets_type_0:
                    datasets_type_0_item = Dataset.from_dict(datasets_type_0_item_data)

                    datasets_type_0.append(datasets_type_0_item)

                return datasets_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[Dataset] | None | Unset, data)

        datasets = _parse_datasets(d.pop("datasets", UNSET))

        project = cls(
            id=id,
            name=name,
            slug=slug,
            organization_id=organization_id,
            created_at=created_at,
            updated_at=updated_at,
            description=description,
            organization=organization,
            connections=connections,
            tasks=tasks,
            dashboards=dashboards,
            chat_sessions=chat_sessions,
            datasets=datasets,
        )

        project.additional_properties = d
        return project

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
