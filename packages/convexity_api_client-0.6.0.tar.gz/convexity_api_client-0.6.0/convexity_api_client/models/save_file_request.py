from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="SaveFileRequest")


@_attrs_define
class SaveFileRequest:
    """
    Attributes:
        workspace_id (str):
        file_name (str):
        content (str):
        description (str | Unset):  Default: ''.
        overwrite (bool | Unset):  Default: False.
    """

    workspace_id: str
    file_name: str
    content: str
    description: str | Unset = ""
    overwrite: bool | Unset = False
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        workspace_id = self.workspace_id

        file_name = self.file_name

        content = self.content

        description = self.description

        overwrite = self.overwrite

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "workspace_id": workspace_id,
                "file_name": file_name,
                "content": content,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if overwrite is not UNSET:
            field_dict["overwrite"] = overwrite

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        workspace_id = d.pop("workspace_id")

        file_name = d.pop("file_name")

        content = d.pop("content")

        description = d.pop("description", UNSET)

        overwrite = d.pop("overwrite", UNSET)

        save_file_request = cls(
            workspace_id=workspace_id,
            file_name=file_name,
            content=content,
            description=description,
            overwrite=overwrite,
        )

        save_file_request.additional_properties = d
        return save_file_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
