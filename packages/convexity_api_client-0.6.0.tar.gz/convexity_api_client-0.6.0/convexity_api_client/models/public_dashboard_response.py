from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.dashboard_button_widget import DashboardButtonWidget
    from ..models.dashboard_chart_widget import DashboardChartWidget
    from ..models.dashboard_date_filter_widget import DashboardDateFilterWidget
    from ..models.dashboard_date_range_filter_widget import DashboardDateRangeFilterWidget
    from ..models.dashboard_e_chart_widget import DashboardEChartWidget
    from ..models.dashboard_layout import DashboardLayout
    from ..models.dashboard_multi_select_filter_widget import DashboardMultiSelectFilterWidget
    from ..models.dashboard_number_filter_widget import DashboardNumberFilterWidget
    from ..models.dashboard_number_range_filter_widget import DashboardNumberRangeFilterWidget
    from ..models.dashboard_s3_object_widget import DashboardS3ObjectWidget
    from ..models.dashboard_select_filter_widget import DashboardSelectFilterWidget
    from ..models.dashboard_sql_chart_widget import DashboardSqlChartWidget
    from ..models.dashboard_table_widget import DashboardTableWidget
    from ..models.dashboard_task_execution_widget import DashboardTaskExecutionWidget
    from ..models.dashboard_task_widget import DashboardTaskWidget
    from ..models.dashboard_text_filter_widget import DashboardTextFilterWidget
    from ..models.dashboard_text_widget import DashboardTextWidget
    from ..models.public_dashboard_response_filters_type_0_item import PublicDashboardResponseFiltersType0Item


T = TypeVar("T", bound="PublicDashboardResponse")


@_attrs_define
class PublicDashboardResponse:
    """Response for public dashboard access (read-only view).

    Attributes:
        id (str): Dashboard ID
        project_id (str): Project ID for data access
        name (str): Dashboard name
        allow_filtering (bool): Whether filtering is enabled
        show_branding (bool): Whether to show branding
        description (None | str | Unset): Dashboard description
        custom_title (None | str | Unset): Custom title if set
        widgets (list[DashboardButtonWidget | DashboardChartWidget | DashboardDateFilterWidget |
            DashboardDateRangeFilterWidget | DashboardEChartWidget | DashboardMultiSelectFilterWidget |
            DashboardNumberFilterWidget | DashboardNumberRangeFilterWidget | DashboardS3ObjectWidget |
            DashboardSelectFilterWidget | DashboardSqlChartWidget | DashboardTableWidget | DashboardTaskExecutionWidget |
            DashboardTaskWidget | DashboardTextFilterWidget | DashboardTextWidget] | Unset): Widget definitions
        layout (DashboardLayout | None | Unset): Grid layout configuration
        filters (list[PublicDashboardResponseFiltersType0Item] | None | Unset): Filter definitions if enabled
        last_refreshed_at (datetime.datetime | None | Unset): Last refresh timestamp
    """

    id: str
    project_id: str
    name: str
    allow_filtering: bool
    show_branding: bool
    description: None | str | Unset = UNSET
    custom_title: None | str | Unset = UNSET
    widgets: (
        list[
            DashboardButtonWidget
            | DashboardChartWidget
            | DashboardDateFilterWidget
            | DashboardDateRangeFilterWidget
            | DashboardEChartWidget
            | DashboardMultiSelectFilterWidget
            | DashboardNumberFilterWidget
            | DashboardNumberRangeFilterWidget
            | DashboardS3ObjectWidget
            | DashboardSelectFilterWidget
            | DashboardSqlChartWidget
            | DashboardTableWidget
            | DashboardTaskExecutionWidget
            | DashboardTaskWidget
            | DashboardTextFilterWidget
            | DashboardTextWidget
        ]
        | Unset
    ) = UNSET
    layout: DashboardLayout | None | Unset = UNSET
    filters: list[PublicDashboardResponseFiltersType0Item] | None | Unset = UNSET
    last_refreshed_at: datetime.datetime | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.dashboard_chart_widget import DashboardChartWidget
        from ..models.dashboard_date_filter_widget import DashboardDateFilterWidget
        from ..models.dashboard_date_range_filter_widget import DashboardDateRangeFilterWidget
        from ..models.dashboard_e_chart_widget import DashboardEChartWidget
        from ..models.dashboard_layout import DashboardLayout
        from ..models.dashboard_multi_select_filter_widget import DashboardMultiSelectFilterWidget
        from ..models.dashboard_number_filter_widget import DashboardNumberFilterWidget
        from ..models.dashboard_number_range_filter_widget import DashboardNumberRangeFilterWidget
        from ..models.dashboard_s3_object_widget import DashboardS3ObjectWidget
        from ..models.dashboard_select_filter_widget import DashboardSelectFilterWidget
        from ..models.dashboard_sql_chart_widget import DashboardSqlChartWidget
        from ..models.dashboard_table_widget import DashboardTableWidget
        from ..models.dashboard_task_execution_widget import DashboardTaskExecutionWidget
        from ..models.dashboard_task_widget import DashboardTaskWidget
        from ..models.dashboard_text_filter_widget import DashboardTextFilterWidget
        from ..models.dashboard_text_widget import DashboardTextWidget

        id = self.id

        project_id = self.project_id

        name = self.name

        allow_filtering = self.allow_filtering

        show_branding = self.show_branding

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        custom_title: None | str | Unset
        if isinstance(self.custom_title, Unset):
            custom_title = UNSET
        else:
            custom_title = self.custom_title

        widgets: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.widgets, Unset):
            widgets = []
            for widgets_item_data in self.widgets:
                widgets_item: dict[str, Any]
                if isinstance(widgets_item_data, DashboardChartWidget):
                    widgets_item = widgets_item_data.to_dict()
                elif isinstance(widgets_item_data, DashboardSqlChartWidget):
                    widgets_item = widgets_item_data.to_dict()
                elif isinstance(widgets_item_data, DashboardTaskWidget):
                    widgets_item = widgets_item_data.to_dict()
                elif isinstance(widgets_item_data, DashboardS3ObjectWidget):
                    widgets_item = widgets_item_data.to_dict()
                elif isinstance(widgets_item_data, DashboardEChartWidget):
                    widgets_item = widgets_item_data.to_dict()
                elif isinstance(widgets_item_data, DashboardTableWidget):
                    widgets_item = widgets_item_data.to_dict()
                elif isinstance(widgets_item_data, DashboardTextWidget):
                    widgets_item = widgets_item_data.to_dict()
                elif isinstance(widgets_item_data, DashboardSelectFilterWidget):
                    widgets_item = widgets_item_data.to_dict()
                elif isinstance(widgets_item_data, DashboardMultiSelectFilterWidget):
                    widgets_item = widgets_item_data.to_dict()
                elif isinstance(widgets_item_data, DashboardDateFilterWidget):
                    widgets_item = widgets_item_data.to_dict()
                elif isinstance(widgets_item_data, DashboardDateRangeFilterWidget):
                    widgets_item = widgets_item_data.to_dict()
                elif isinstance(widgets_item_data, DashboardTextFilterWidget):
                    widgets_item = widgets_item_data.to_dict()
                elif isinstance(widgets_item_data, DashboardNumberFilterWidget):
                    widgets_item = widgets_item_data.to_dict()
                elif isinstance(widgets_item_data, DashboardNumberRangeFilterWidget):
                    widgets_item = widgets_item_data.to_dict()
                elif isinstance(widgets_item_data, DashboardTaskExecutionWidget):
                    widgets_item = widgets_item_data.to_dict()
                else:
                    widgets_item = widgets_item_data.to_dict()

                widgets.append(widgets_item)

        layout: dict[str, Any] | None | Unset
        if isinstance(self.layout, Unset):
            layout = UNSET
        elif isinstance(self.layout, DashboardLayout):
            layout = self.layout.to_dict()
        else:
            layout = self.layout

        filters: list[dict[str, Any]] | None | Unset
        if isinstance(self.filters, Unset):
            filters = UNSET
        elif isinstance(self.filters, list):
            filters = []
            for filters_type_0_item_data in self.filters:
                filters_type_0_item = filters_type_0_item_data.to_dict()
                filters.append(filters_type_0_item)

        else:
            filters = self.filters

        last_refreshed_at: None | str | Unset
        if isinstance(self.last_refreshed_at, Unset):
            last_refreshed_at = UNSET
        elif isinstance(self.last_refreshed_at, datetime.datetime):
            last_refreshed_at = self.last_refreshed_at.isoformat()
        else:
            last_refreshed_at = self.last_refreshed_at

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "projectId": project_id,
                "name": name,
                "allowFiltering": allow_filtering,
                "showBranding": show_branding,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if custom_title is not UNSET:
            field_dict["customTitle"] = custom_title
        if widgets is not UNSET:
            field_dict["widgets"] = widgets
        if layout is not UNSET:
            field_dict["layout"] = layout
        if filters is not UNSET:
            field_dict["filters"] = filters
        if last_refreshed_at is not UNSET:
            field_dict["lastRefreshedAt"] = last_refreshed_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.dashboard_button_widget import DashboardButtonWidget
        from ..models.dashboard_chart_widget import DashboardChartWidget
        from ..models.dashboard_date_filter_widget import DashboardDateFilterWidget
        from ..models.dashboard_date_range_filter_widget import DashboardDateRangeFilterWidget
        from ..models.dashboard_e_chart_widget import DashboardEChartWidget
        from ..models.dashboard_layout import DashboardLayout
        from ..models.dashboard_multi_select_filter_widget import DashboardMultiSelectFilterWidget
        from ..models.dashboard_number_filter_widget import DashboardNumberFilterWidget
        from ..models.dashboard_number_range_filter_widget import DashboardNumberRangeFilterWidget
        from ..models.dashboard_s3_object_widget import DashboardS3ObjectWidget
        from ..models.dashboard_select_filter_widget import DashboardSelectFilterWidget
        from ..models.dashboard_sql_chart_widget import DashboardSqlChartWidget
        from ..models.dashboard_table_widget import DashboardTableWidget
        from ..models.dashboard_task_execution_widget import DashboardTaskExecutionWidget
        from ..models.dashboard_task_widget import DashboardTaskWidget
        from ..models.dashboard_text_filter_widget import DashboardTextFilterWidget
        from ..models.dashboard_text_widget import DashboardTextWidget
        from ..models.public_dashboard_response_filters_type_0_item import PublicDashboardResponseFiltersType0Item

        d = dict(src_dict)
        id = d.pop("id")

        project_id = d.pop("projectId")

        name = d.pop("name")

        allow_filtering = d.pop("allowFiltering")

        show_branding = d.pop("showBranding")

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_custom_title(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        custom_title = _parse_custom_title(d.pop("customTitle", UNSET))

        _widgets = d.pop("widgets", UNSET)
        widgets: (
            list[
                DashboardButtonWidget
                | DashboardChartWidget
                | DashboardDateFilterWidget
                | DashboardDateRangeFilterWidget
                | DashboardEChartWidget
                | DashboardMultiSelectFilterWidget
                | DashboardNumberFilterWidget
                | DashboardNumberRangeFilterWidget
                | DashboardS3ObjectWidget
                | DashboardSelectFilterWidget
                | DashboardSqlChartWidget
                | DashboardTableWidget
                | DashboardTaskExecutionWidget
                | DashboardTaskWidget
                | DashboardTextFilterWidget
                | DashboardTextWidget
            ]
            | Unset
        ) = UNSET
        if _widgets is not UNSET:
            widgets = []
            for widgets_item_data in _widgets:

                def _parse_widgets_item(
                    data: object,
                ) -> (
                    DashboardButtonWidget
                    | DashboardChartWidget
                    | DashboardDateFilterWidget
                    | DashboardDateRangeFilterWidget
                    | DashboardEChartWidget
                    | DashboardMultiSelectFilterWidget
                    | DashboardNumberFilterWidget
                    | DashboardNumberRangeFilterWidget
                    | DashboardS3ObjectWidget
                    | DashboardSelectFilterWidget
                    | DashboardSqlChartWidget
                    | DashboardTableWidget
                    | DashboardTaskExecutionWidget
                    | DashboardTaskWidget
                    | DashboardTextFilterWidget
                    | DashboardTextWidget
                ):
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        widgets_item_type_0 = DashboardChartWidget.from_dict(data)

                        return widgets_item_type_0
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        widgets_item_type_1 = DashboardSqlChartWidget.from_dict(data)

                        return widgets_item_type_1
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        widgets_item_type_2 = DashboardTaskWidget.from_dict(data)

                        return widgets_item_type_2
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        widgets_item_type_3 = DashboardS3ObjectWidget.from_dict(data)

                        return widgets_item_type_3
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        widgets_item_type_4 = DashboardEChartWidget.from_dict(data)

                        return widgets_item_type_4
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        widgets_item_type_5 = DashboardTableWidget.from_dict(data)

                        return widgets_item_type_5
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        widgets_item_type_6 = DashboardTextWidget.from_dict(data)

                        return widgets_item_type_6
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        widgets_item_type_7 = DashboardSelectFilterWidget.from_dict(data)

                        return widgets_item_type_7
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        widgets_item_type_8 = DashboardMultiSelectFilterWidget.from_dict(data)

                        return widgets_item_type_8
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        widgets_item_type_9 = DashboardDateFilterWidget.from_dict(data)

                        return widgets_item_type_9
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        widgets_item_type_10 = DashboardDateRangeFilterWidget.from_dict(data)

                        return widgets_item_type_10
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        widgets_item_type_11 = DashboardTextFilterWidget.from_dict(data)

                        return widgets_item_type_11
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        widgets_item_type_12 = DashboardNumberFilterWidget.from_dict(data)

                        return widgets_item_type_12
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        widgets_item_type_13 = DashboardNumberRangeFilterWidget.from_dict(data)

                        return widgets_item_type_13
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        widgets_item_type_14 = DashboardTaskExecutionWidget.from_dict(data)

                        return widgets_item_type_14
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    if not isinstance(data, dict):
                        raise TypeError()
                    widgets_item_type_15 = DashboardButtonWidget.from_dict(data)

                    return widgets_item_type_15

                widgets_item = _parse_widgets_item(widgets_item_data)

                widgets.append(widgets_item)

        def _parse_layout(data: object) -> DashboardLayout | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                layout_type_0 = DashboardLayout.from_dict(data)

                return layout_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(DashboardLayout | None | Unset, data)

        layout = _parse_layout(d.pop("layout", UNSET))

        def _parse_filters(data: object) -> list[PublicDashboardResponseFiltersType0Item] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                filters_type_0 = []
                _filters_type_0 = data
                for filters_type_0_item_data in _filters_type_0:
                    filters_type_0_item = PublicDashboardResponseFiltersType0Item.from_dict(filters_type_0_item_data)

                    filters_type_0.append(filters_type_0_item)

                return filters_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[PublicDashboardResponseFiltersType0Item] | None | Unset, data)

        filters = _parse_filters(d.pop("filters", UNSET))

        def _parse_last_refreshed_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_refreshed_at_type_0 = isoparse(data)

                return last_refreshed_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        last_refreshed_at = _parse_last_refreshed_at(d.pop("lastRefreshedAt", UNSET))

        public_dashboard_response = cls(
            id=id,
            project_id=project_id,
            name=name,
            allow_filtering=allow_filtering,
            show_branding=show_branding,
            description=description,
            custom_title=custom_title,
            widgets=widgets,
            layout=layout,
            filters=filters,
            last_refreshed_at=last_refreshed_at,
        )

        public_dashboard_response.additional_properties = d
        return public_dashboard_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
