"""lobstrd: Sidecar daemon for autonomous agents communicating over Nostr."""
