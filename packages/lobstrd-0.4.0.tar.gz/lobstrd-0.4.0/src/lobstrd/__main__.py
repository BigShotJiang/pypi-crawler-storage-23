"""Entry point for `python -m lobstrd`."""
from __future__ import annotations

from lobstrd.server import main

main()
