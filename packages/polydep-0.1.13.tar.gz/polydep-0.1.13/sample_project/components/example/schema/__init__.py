from example.schema.message import Message

__all__ = ["Message"]
