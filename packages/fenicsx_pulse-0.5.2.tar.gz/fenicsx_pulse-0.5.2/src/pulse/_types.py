from __future__ import annotations

import dolfinx

FuncConst = dolfinx.fem.Function | dolfinx.fem.Constant
