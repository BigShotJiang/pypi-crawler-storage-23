class FeatureGroupNotFoundError(Exception):
    """Custom error that is raised when feature group not found in seeknal (possibly not saved yet)"""

    pass


class FeatureServingNotFoundError(Exception):
    """Custom error that is raised when feature group not found in seeknal (possibly not saved yet)"""

    pass
