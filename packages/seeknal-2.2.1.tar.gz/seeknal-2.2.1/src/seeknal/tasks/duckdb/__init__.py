from .duckdb import DuckDBTask

_all_ = ["DuckDBTask"]
