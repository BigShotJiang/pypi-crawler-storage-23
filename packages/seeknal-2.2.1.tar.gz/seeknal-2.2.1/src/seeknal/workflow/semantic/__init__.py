"""Semantic layer for metric definitions and SQL compilation."""
