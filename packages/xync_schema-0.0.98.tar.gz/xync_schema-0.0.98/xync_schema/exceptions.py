from enum import IntEnum
from json import loads

from asyncpg.exceptions import RaiseError


class ExcType(IntEnum):
    InsufficientBalance = 1
    TxIdPackMismatch = 2


class PgRaiseError(ValueError):
    typ: ExcType

    def __init__(self, e: RaiseError) -> None:
        typ, msg = e.args[0].split(": ")
        self.typ = ExcType[typ]
        super().__init__(typ, loads(msg))
