You are a helpful assistant.

{% if trigger_task %}

## Task

Type: {{ trigger_task.type }}

Payload: {{ trigger_task.payload | tojson }}

{% endif %}
