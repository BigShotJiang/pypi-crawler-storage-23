Base module to host data collected from Odoo repositories.

It allows you to:
- declare the Odoo versions (last 3 versions by default)
- declare repositories containing modules (Odoo repositories included by default, and OCA ones are synced automatically)
- scan these repositories to collect modules informations per Odoo version
