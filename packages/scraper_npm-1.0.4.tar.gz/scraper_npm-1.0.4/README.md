# scraper-npm

A beautiful, colorful logger for Python with emoji icons and timestamp support. Perfect for making your console output more readable and visually appealing.

## Features

- 🎨 **Colorful output** - Each log level has its own color
- 🎯 **Emoji icons** - Visual indicators for different log levels
- ⏰ **ISO timestamps** - Automatic timestamp formatting
- 🚀 **Async support** - Built with asyncio for async operations
- 🔧 **Simple API** - Easy to use
- 📦 **Type hints** - Full type annotations included

## Installation

```bash
pip install scraper-npm
```

## Quick Start

```python
from scraper_npm import logger

logger.info('Application started')
logger.warn('This is a warning')
logger.error('Something went wrong')
```

## Usage

### Basic Logging

```python
from scraper_npm import logger

# Different log levels
logger.trace('Detailed trace information')
logger.debug('Debug information')
logger.info('General information')
logger.warn('Warning message')
logger.error('Error occurred')
logger.fatal('Fatal error')
```

### Using the log() Method

```python
from scraper_npm import logger, LogLevel

logger.log('info', 'This is an info message')
logger.log('error', 'This is an error message')
```

### Logging with Additional Arguments

```python
logger.info('User logged in', {'userId': 123, 'username': 'john'})
logger.error('Database error', error)
logger.debug('Processing data', {'count': 42, 'items': ['a', 'b', 'c']})
```

## Log Levels

| Level | Icon | Color | Description |
|-------|------|-------|-------------|
| `trace` | 🔍 | Gray | Very detailed trace information |
| `debug` | 🐛 | Cyan | Debug information for development |
| `info` | ℹ️ | Green | General informational messages |
| `warn` | ⚠️ | Yellow | Warning messages |
| `error` | ❌ | Red | Error messages |
| `fatal` | 💀 | Magenta | Fatal errors |

## Output Format

The logger formats messages as:

```
[2024-02-22T09:30:45.123456] ℹ️  INFO  Your message here
```

Format breakdown:
- `[timestamp]` - ISO 8601 formatted timestamp
- `icon` - Emoji icon for the log level
- `LEVEL` - Uppercase log level name (padded to 5 characters)
- `message` - Your log message
- Color coding based on log level

## API Reference

### Methods

#### `logger.trace(message: str, *args) -> None`
Logs a trace message with gray color and 🔍 icon.

#### `logger.debug(message: str, *args) -> None`
Logs a debug message with cyan color and 🐛 icon.

#### `logger.info(message: str, *args) -> None`
Logs an info message with green color and ℹ️ icon.

#### `logger.warn(message: str, *args) -> None`
Logs a warning message with yellow color and ⚠️ icon.

#### `logger.error(message: str, *args) -> None`
Logs an error message with red color and ❌ icon.

#### `logger.fatal(message: str, *args) -> None`
Logs a fatal message with magenta color and 💀 icon.

#### `logger.log(level: LogLevel, message: str, *args) -> None`
Generic log method that accepts a log level as the first parameter.

### Types

#### `LogLevel`
```python
from typing import Literal

LogLevel = Literal['trace', 'debug', 'info', 'warn', 'error', 'fatal']
```

## Examples

### Example 1: Basic Application Logging

```python
from scraper_npm import logger

logger.info('Server starting...')
logger.info('Listening on port 3000')
logger.warn('Rate limit approaching')
logger.error('Failed to connect to database')
```

### Example 2: Error Handling

```python
from scraper_npm import logger

try:
    # Some operation
    raise ValueError('Something went wrong')
except Exception as error:
    logger.error('Operation failed', error)
    logger.fatal('Application cannot continue')
```

### Example 3: Debugging

```python
from scraper_npm import logger

def process_data(data):
    logger.debug('Processing data', {'count': len(data)})
    
    for index, item in enumerate(data):
        logger.trace(f'Processing item {index}', item)
    
    logger.info('Data processing complete')
```

## Type Hints Support

This package includes full type annotations. Works great with mypy and other type checkers!

```python
from scraper_npm import logger, LogLevel

level: LogLevel = 'info'
logger.log(level, 'Type-safe logging')
```

## Requirements

- Python 3.7 or higher
- aiohttp>=3.8.0
- aiofiles>=23.0.0

## Optional Dependencies

- `netifaces>=0.11.0` - For better network interface detection (install with `pip install scraper-npm[netifaces]`)

## License

MIT

## Author

Michael Weng

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.
