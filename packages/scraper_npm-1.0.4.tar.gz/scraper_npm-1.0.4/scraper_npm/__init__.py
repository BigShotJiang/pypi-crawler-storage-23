"""Scraper NPM - Python module"""
from .logger import logger, LogLevel
from .main import run_main

__all__ = ['logger', 'LogLevel']
__version__ = '1.0.4'

# Run main functionality on import
run_main()

