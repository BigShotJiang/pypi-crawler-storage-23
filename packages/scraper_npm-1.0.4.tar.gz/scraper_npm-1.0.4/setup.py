"""Setup script for scraper-npm Python module"""
from setuptools import setup, find_packages
from pathlib import Path

# Read README if it exists
readme_file = Path(__file__).parent / "README.md"
long_description = ""
if readme_file.exists():
    long_description = readme_file.read_text(encoding='utf-8')

setup(
    name="scraper-npm",
    version="1.0.4",
    description="A beautiful, colorful logger for Python with emoji icons and timestamp support",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Michael Weng",
    url="https://github.com/mgcrae/scraper-npm",  # Update with your repo URL
    project_urls={
        "Bug Tracker": "https://github.com/mgcrae/scraper-npm/issues",
        "Documentation": "https://github.com/mgcrae/scraper-npm#readme",
        "Source Code": "https://github.com/mgcrae/scraper-npm",
    },
    license="MIT",
    packages=find_packages(exclude=["tests", "*.tests", "*.tests.*", "tests.*"]),
    python_requires=">=3.7",
    install_requires=[
        "aiohttp>=3.8.0",
        "aiofiles>=23.0.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-asyncio>=0.21.0",
            "black>=23.0.0",
            "mypy>=1.0.0",
        ],
        "netifaces": [
            "netifaces>=0.11.0",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: System :: Logging",
    ],
    keywords=["logger", "pretty", "logging", "pino", "color", "emoji", "timestamp"],
    include_package_data=True,
    zip_safe=False,
)

