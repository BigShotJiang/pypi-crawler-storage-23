"""AllClear — all-sky camera cloud detection via star matching."""

__version__ = "0.2.0"
