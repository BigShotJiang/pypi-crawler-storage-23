Community Central - ServiceNow Community
We've updated the ServiceNow Community Code of Conduct, adding guidelines around AI usage, professionalism, and content violations. [Read more](https://www.servicenow.com/community/community-resources/servicenow-community-code-of-conduct-for-all-members/ta-p/2338554)
[![ServiceNow](https://www.servicenow.com/content/dam/servicenow-assets/images/naas/servicenow-header-logo.svg)![ServiceNow](https://www.servicenow.com/content/dam/servicenow-assets/images/naas/servicenow-logo-icon.svg)![ServiceNow](https://www.servicenow.com/content/dam/servicenow-assets/images/naas/servicenow-logo-icon-white.svg)![ServiceNow](https://www.servicenow.com/content/dam/servicenow-assets/images/naas/servicenow-header-logo-white.svg)](https://www.servicenow.com/)
  * ![icon](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cpath%20d%3D%22M22.5%2011.9855C22.5%2012.4081%2022.1254%2012.7367%2021.704%2012.7367H4.05184L10.607%2019.7793C10.888%2020.061%2010.888%2020.5305%2010.5602%2020.8122C10.4197%2020.9531%2010.2324%2021%2010.0452%2021C9.81104%2021%209.62375%2020.9531%209.48328%2020.7652L1.7107%2012.502C1.42977%2012.2203%201.42977%2011.7977%201.7107%2011.516L9.48328%203.2527C9.76421%202.92404%2010.2324%202.92404%2010.5602%203.20575C10.888%203.48745%2010.888%203.95696%2010.607%204.23866L4.05184%2011.2343H21.704C22.1254%2011.2343%2022.5%2011.6099%2022.5%2011.9855Z%22%20fill%3D%22%231D1D1D%22%2F%3E%0A%20%20%20%20%20%20%20%20%20%20%3C%2Fsvg%3E)MyNow
  * ![icon](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cpath%20d%3D%22M22.5%2011.9855C22.5%2012.4081%2022.1254%2012.7367%2021.704%2012.7367H4.05184L10.607%2019.7793C10.888%2020.061%2010.888%2020.5305%2010.5602%2020.8122C10.4197%2020.9531%2010.2324%2021%2010.0452%2021C9.81104%2021%209.62375%2020.9531%209.48328%2020.7652L1.7107%2012.502C1.42977%2012.2203%201.42977%2011.7977%201.7107%2011.516L9.48328%203.2527C9.76421%202.92404%2010.2324%202.92404%2010.5602%203.20575C10.888%203.48745%2010.888%203.95696%2010.607%204.23866L4.05184%2011.2343H21.704C22.1254%2011.2343%2022.5%2011.6099%2022.5%2011.9855Z%22%20fill%3D%22%231D1D1D%22%2F%3E%0A%20%20%20%20%20%20%20%20%20%20%3C%2Fsvg%3E)Products
  * ![icon](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cpath%20d%3D%22M22.5%2011.9855C22.5%2012.4081%2022.1254%2012.7367%2021.704%2012.7367H4.05184L10.607%2019.7793C10.888%2020.061%2010.888%2020.5305%2010.5602%2020.8122C10.4197%2020.9531%2010.2324%2021%2010.0452%2021C9.81104%2021%209.62375%2020.9531%209.48328%2020.7652L1.7107%2012.502C1.42977%2012.2203%201.42977%2011.7977%201.7107%2011.516L9.48328%203.2527C9.76421%202.92404%2010.2324%202.92404%2010.5602%203.20575C10.888%203.48745%2010.888%203.95696%2010.607%204.23866L4.05184%2011.2343H21.704C22.1254%2011.2343%2022.5%2011.6099%2022.5%2011.9855Z%22%20fill%3D%22%231D1D1D%22%2F%3E%0A%20%20%20%20%20%20%20%20%20%20%3C%2Fsvg%3E)Industries
  * ![icon](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cpath%20d%3D%22M22.5%2011.9855C22.5%2012.4081%2022.1254%2012.7367%2021.704%2012.7367H4.05184L10.607%2019.7793C10.888%2020.061%2010.888%2020.5305%2010.5602%2020.8122C10.4197%2020.9531%2010.2324%2021%2010.0452%2021C9.81104%2021%209.62375%2020.9531%209.48328%2020.7652L1.7107%2012.502C1.42977%2012.2203%201.42977%2011.7977%201.7107%2011.516L9.48328%203.2527C9.76421%202.92404%2010.2324%202.92404%2010.5602%203.20575C10.888%203.48745%2010.888%203.95696%2010.607%204.23866L4.05184%2011.2343H21.704C22.1254%2011.2343%2022.5%2011.6099%2022.5%2011.9855Z%22%20fill%3D%22%231D1D1D%22%2F%3E%0A%20%20%20%20%20%20%20%20%20%20%3C%2Fsvg%3E)Learning
  * ![icon](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cpath%20d%3D%22M22.5%2011.9855C22.5%2012.4081%2022.1254%2012.7367%2021.704%2012.7367H4.05184L10.607%2019.7793C10.888%2020.061%2010.888%2020.5305%2010.5602%2020.8122C10.4197%2020.9531%2010.2324%2021%2010.0452%2021C9.81104%2021%209.62375%2020.9531%209.48328%2020.7652L1.7107%2012.502C1.42977%2012.2203%201.42977%2011.7977%201.7107%2011.516L9.48328%203.2527C9.76421%202.92404%2010.2324%202.92404%2010.5602%203.20575C10.888%203.48745%2010.888%203.95696%2010.607%204.23866L4.05184%2011.2343H21.704C22.1254%2011.2343%2022.5%2011.6099%2022.5%2011.9855Z%22%20fill%3D%22%231D1D1D%22%2F%3E%0A%20%20%20%20%20%20%20%20%20%20%3C%2Fsvg%3E)Support
  * ![icon](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cpath%20d%3D%22M22.5%2011.9855C22.5%2012.4081%2022.1254%2012.7367%2021.704%2012.7367H4.05184L10.607%2019.7793C10.888%2020.061%2010.888%2020.5305%2010.5602%2020.8122C10.4197%2020.9531%2010.2324%2021%2010.0452%2021C9.81104%2021%209.62375%2020.9531%209.48328%2020.7652L1.7107%2012.502C1.42977%2012.2203%201.42977%2011.7977%201.7107%2011.516L9.48328%203.2527C9.76421%202.92404%2010.2324%202.92404%2010.5602%203.20575C10.888%203.48745%2010.888%203.95696%2010.607%204.23866L4.05184%2011.2343H21.704C22.1254%2011.2343%2022.5%2011.6099%2022.5%2011.9855Z%22%20fill%3D%22%231D1D1D%22%2F%3E%0A%20%20%20%20%20%20%20%20%20%20%3C%2Fsvg%3E)Partners
  * ![icon](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cpath%20d%3D%22M22.5%2011.9855C22.5%2012.4081%2022.1254%2012.7367%2021.704%2012.7367H4.05184L10.607%2019.7793C10.888%2020.061%2010.888%2020.5305%2010.5602%2020.8122C10.4197%2020.9531%2010.2324%2021%2010.0452%2021C9.81104%2021%209.62375%2020.9531%209.48328%2020.7652L1.7107%2012.502C1.42977%2012.2203%201.42977%2011.7977%201.7107%2011.516L9.48328%203.2527C9.76421%202.92404%2010.2324%202.92404%2010.5602%203.20575C10.888%203.48745%2010.888%203.95696%2010.607%204.23866L4.05184%2011.2343H21.704C22.1254%2011.2343%2022.5%2011.6099%2022.5%2011.9855Z%22%20fill%3D%22%231D1D1D%22%2F%3E%0A%20%20%20%20%20%20%20%20%20%20%3C%2Fsvg%3E)Company


* * *
[![Help](https://www.servicenow.com/content/dam/servicenow-assets/images/naas/question-icon.svg)](https://www.servicenow.com/community/help/faqpage)
  * ![Select your country](https://www.servicenow.com/content/dam/servicenow-assets/images/naas/language-selector-light.svg)United States - GlobalMain menu
  * [View a Demo](https://www.servicenow.com/lpdem/demonow-all.html)


[![Help](https://www.servicenow.com/content/dam/servicenow-assets/images/naas/question-icon.svg)](https://www.servicenow.com/community/help/faqpage)
![Select your country](https://www.servicenow.com/content/dam/servicenow-assets/images/naas/language-selector-light.svg)
Americas
  * [United States - Global](https://www.servicenow.com/community/community-central/ct-p/community-central?profile.language=en)
  * [Brasil - Português](https://www.servicenow.com/community/community-central/ct-p/community-central?profile.language=pt-br)


Asia, Pacific, and Japan
  * [日本 - 日本語](https://www.servicenow.com/community/community-central/ct-p/community-central?profile.language=ja)
  * [한국 - 한국어](https://www.servicenow.com/community/community-central/ct-p/community-central?profile.language=ko)


Europe, Middle East, and Africa
  * [United Kingdom - English](https://www.servicenow.com/community/community-central/ct-p/community-central?profile.language=en-gb)
  * [DACH - Deutsch](https://www.servicenow.com/community/community-central/ct-p/community-central?profile.language=de)
  * [France - Français](https://www.servicenow.com/community/community-central/ct-p/community-central?profile.language=fr)
  * [Nederland - Nederlands](https://www.servicenow.com/community/community-central/ct-p/community-central?profile.language=nl)
  * [España - Español](https://www.servicenow.com/community/community-central/ct-p/community-central?profile.language=es)
  * [Italia - Italiano](https://www.servicenow.com/community/community-central/ct-p/community-central?profile.language=it)


MyNow
Explore MyNow, your personalized experience for quick access to your workflows, to-do lists, and AI guided recommendations.
[Home](https://mynow.servicenow.com/now/mynow/my-home/home)
Products
  * Featured products
  * ServiceNow AI Platform
  * Demo Library


Solutions
  * IT
  * CRM
  * Risk and Security
  * Employee Experience
  * App Development
  * [](https://www.servicenow.com/products-by-category.html)


Featured products
Products
Unite people, processes, and systems with AI-powered products for all your workflows.
[See All Products](https://www.servicenow.com/products-by-category.html)
Featured products
  * ### [AI Agents Take action with autonomous AI agents that work for you.](https://www.servicenow.com/products/ai-agents.html)
  * ### [IT Service Management Transform service management for productivity and ROI.](https://www.servicenow.com/products/itsm.html)
  * ### [ServiceNow AI Control Tower Connect strategy, governance, management, and performance for all your AI across the enterprise.](https://www.servicenow.com/products/ai-control-tower.html)
  * ### [IT Operations Management Deliver proactive digital operations with AIOps.](https://www.servicenow.com/products/it-operations-management.html)
  * ### [Customer Service Management Empower self-service, boost agent productivity, and speed up resolution.](https://www.servicenow.com/products/customer-service-management.html)
  * ### [Strategic Portfolio Management Gain insights to move from strategy to business outcomes.](https://www.servicenow.com/products/strategic-portfolio-management.html)
  * ### [IT Asset Management Improve technology use and spend over the IT asset lifecycle.](https://www.servicenow.com/products/it-asset-management.html)
  * ### [Governance, Risk, and Compliance Enable an integrated approach that builds operational resilience and mitigates risk.](https://www.servicenow.com/products/governance-risk-and-compliance.html)
  * ### [Security Operations Defend against security threats and attacks.](https://www.servicenow.com/products/security-operations.html)
  * ### [Field Service Management Reduce field service costs and improve efficiency.](https://www.servicenow.com/products/field-service-management.html)
  * ### [HR Service Delivery Give employees instant answers, guidance, and fast issue resolution.](https://www.servicenow.com/products/hr-service-delivery.html)
  * ### [EmployeeWorks Stop chasing what other AI tools should have finished.](https://www.servicenow.com/products/employeeworks.html)


### Meet the Autonomous Workforce
The Autonomous Workforce is more than just isolated tasks. These AI specialists are assigned to roles, with business context and permissions to handle complex workflows end-to-end.
[Learn More](https://www.servicenow.com/platform/autonomous-workforce.html)
ServiceNow AI Platform
One platform, ready for anything
AI, data, and workflows—working together on one platform. Only ServiceNow makes it this simple at scale.
[Explore AI Platform](https://www.servicenow.com/now-platform.html)
  * ### [AI Put AI to work across your business with our single, intelligent platform.](https://www.servicenow.com/ai.html)
  * ### [Data Power all your workflows, AI, and analytics with real-time access to data from any source.](https://www.servicenow.com/now-platform/workflow-data-fabric.html)
  * ### [Workflows Automate workflows to lower costs and raise productivity.](https://www.servicenow.com/now-platform/workflow-automation.html)
  * ### [AI Experience Bring AI directly into the flow of work with the UI for Enterprise AI.](https://www.servicenow.com/now-platform/ai-experience.html)
  * ### [RaptorDB Unify data and analytics on the ServiceNow AI Platform for ultra-fast workflow performance at scale.](https://www.servicenow.com/products/raptordb.html)
  * ### [Infrastructure Deploy, automate, and scale with trusted and flexible cloud-based infrastructure options built to make work flow.](https://www.servicenow.com/now-platform/infrastructure.html)
  * ### [AI Agents AI Agents Take action with autonomous AI agents that work for you.](https://www.servicenow.com/products/ai-agents.html)
  * ### [ServiceNow AI Control Tower Connect strategy, governance, management, and performance for all your AI across the enterprise.](https://www.servicenow.com/products/ai-control-tower.html)
  * ### [Security Protect sensitive data and increase security, privacy, and compliance across the enterprise.](https://www.servicenow.com/products/vault.html)
  * ### [App Engine Build apps that automate manual work and modernize legacy processes.](https://www.servicenow.com/products/now-platform-app-engine.html)
  * ### [ServiceNow Store Do more with the ServiceNow AI Platform. Find hundreds of certified, ready to use applications.](https://store.servicenow.com/sn_appstore_store.do#!/store/home)
  * ### [Responsible AI Rely on ServiceNow for AI that’s human-centered, inclusive, transparent, and accountable. ](https://www.servicenow.com/now-platform/responsible-ai.html)


Demo Library
Demo Library
Watch and learn. Our product and solutions experts offer demo options for everyone, at every skill level.
[Explore Demo Library](https://www.servicenow.com/demo/demonow.html)
Featured demos
  * [![Provide better experiences](https://www.servicenow.com/content/dam/servicenow-assets/images/naas/provide-better-experiences.jpg)Provide better experiences Learn how you can use GenAI to equip customers and employees with self-service for requests. (3:17)](https://www.servicenow.com/demo/demonow-detail.html?videoid=put-ai-to-work-with-now-assist-for-customers-and-employees)
  * [![Resolve issues faster](https://www.servicenow.com/content/dam/servicenow-assets/images/naas/resolve-issues-faster.jpg)Resolve issues faster Find out how your business can reduce manual work and help agents resolve cases faster. (4:08)](https://www.servicenow.com/demo/demonow-detail.html?videoid=put-ai-to-work-with-now-assist-for-agents)
  * [![Create and automate workflows](https://www.servicenow.com/content/dam/servicenow-assets/images/naas/create-automate-workflows.jpg)Create and automate workflows See how to simplify the way workflows are built and custom code is developed. (4:30)](https://www.servicenow.com/demo/demonow-detail.html?videoid=put-ai-to-work-with-now-assist-for-developers-and-admins)


Solutions
IT
IT
Anticipate needs with efficient IT and digital operations.
[Explore Solution](https://www.servicenow.com/solutions/enterprise-it.html)
Related Products
  * ### [Enterprise Architecture Build a bridge between business processes and IT architecture.](https://www.servicenow.com/products/enterprise-architecture.html)
  * ### [Service Operations Workspace Predict, prevent, and resolve incidents proactively from a single workspace.](https://www.servicenow.com/products/service-operations-workspace.html)
  * ### [Cloud Governance Suite Automate cloud governance for better compliance, security, and costs.](https://www.servicenow.com/solutions/cloud-transformation.html)
  * ### [Operational Technology Management Protect your OT environment and improve uptime.](https://www.servicenow.com/products/operational-technology-management.html)
  * ### [IT Asset Management Control costs and minimize risks across the IT asset lifecycle.](https://www.servicenow.com/products/it-asset-management.html)
  * ### [IT Operations Management Deliver proactive digital operations with AIOps.](https://www.servicenow.com/products/it-operations-management.html)
  * ### [IT Service Management Transform service management to boost productivity and maximize ROI.](https://www.servicenow.com/products/itsm.html)
  * ### [ServiceNow Cloud Observability Gain insights to detect and respond to changes in cloud-native apps.](https://www.servicenow.com/products/observability.html)
  * ### [Strategic Portfolio Management Gain insights to move from strategy to business outcomes.](https://www.servicenow.com/products/strategic-portfolio-management.html)
  * ### [Digital End-user Experience Improve your employees' endpoint technology experience. ](https://www.servicenow.com/products/digital-user-experience.html)


CRM
CRM
Deliver a seamless, personalized end-to-end customer experience.
[Explore Solution](https://www.servicenow.com/solutions/crm.html)
Related Products
  * ### [Customer Service Management Empower self-service, boost agent productivity, and speed up resolution.](https://www.servicenow.com/products/customer-service-management.html)
  * ### [Field Service Management Optimize scheduling, empower technicians, and reduce unneeded visits.](https://www.servicenow.com/products/field-service-management.html)
  * ### [Sales and Order Management Accelerate the lead-to-cash cycle and boost revenue.](https://www.servicenow.com/products/sales-management.html)
  * ### [Configure, Price, Quote Use AI to simplify and accelerate sales across all channels.](https://www.servicenow.com/products/cpq.html)
  * ### [Financial Services Operations Provide resilient financial services operations for enhanced experiences.](https://www.servicenow.com/products/financial-services-operations.html)
  * ### [Healthcare and Life Sciences Service Management Create consumer-grade healthcare experiences and improve operational performance.](https://www.servicenow.com/products/healthcare-life-sciences.html)
  * ### [Sales and Order Management for Technology Providers Fuel XaaS revenue with AI-powered experiences across sales and order lifecycles.](https://www.servicenow.com/products/order-management-tech-providers.html)
  * ### [Sales and Order Management for Telecommunications Grow revenue with AI-powered experiences across sales, fulfillment, and services.](https://www.servicenow.com/products/telecom-order-management.html)
  * ### [Public Sector Digital Services Modernize and speed up the delivery of government services.](https://www.servicenow.com/products/public-sector-digital-services.html)
  * ### [Telecommunications Service Management Unlock growth with AI-powered experiences across customer service and network operations.](https://www.servicenow.com/products/telecommunications-service-management.html)
  * ### [Technology Provider Service Management Promote speed and growth for your XaaS business with AI-powered experiences.](https://www.servicenow.com/products/technology-provider-service-management.html)


Risk and Security
Risk and Security
Minimize the risk, impact, and cost of securing your business.
[Explore Solution](https://www.servicenow.com/solutions/security.html)
Related Products
  * ### [Security Operations Mount an effective defense against security threats and attacks.](https://www.servicenow.com/products/security-operations.html)
  * ### [Security Incident Response Respond fast to evolving threats while optimizing security operations.](https://www.servicenow.com/products/security-incident-response.html)
  * ### [Vulnerability Response Identify, prioritize, and remediate vulnerabilities across the business.](https://www.servicenow.com/products/vulnerability-response.html)
  * ### [Threat Intelligence Security Center Gain advanced threat hunting, modeling, and analysis on the ServiceNow AI Platform.](https://www.servicenow.com/products/threat-intelligence-security-center.html)
  * ### [Integrated Risk Management Make risk-informed decisions while improving efficiency and resilience.](https://www.servicenow.com/products/integrated-risk-management.html)
  * ### [Third-party Risk Management Reduce third-party risk while improving resilience and compliance.](https://www.servicenow.com/products/third-party-risk-management.html)
  * ### [Security Posture Control Manage the security of enterprise assets on premises and in the cloud.](https://www.servicenow.com/products/security-posture-control.html)
  * ### [Privacy Management Manage data privacy in real time as part of a holistic enterprise risk program.](https://www.servicenow.com/products/privacy-management.html)


Employee Experience
Employee Experience
Automate the busywork, so that you can unleash your talent on the big work.
[Explore Solution](https://www.servicenow.com/solutions/employee-experience.html)
Related Products
  * ### [HR Service Delivery Give employees instant answers, guidance, and fast issue resolution.](https://www.servicenow.com/products/hr-service-delivery.html)
  * ### [Talent Development Make AI and skills-driven talent planning and development decisions.](https://www.servicenow.com/products/talent-development.html)
  * ### [Legal Service Delivery Modernize operations to make faster decisions and grow productivity.](https://www.servicenow.com/products/legal-service-delivery.html)
  * ### [Workplace Service Delivery Automate desk bookings, manage facilities, and optimize operations.](https://www.servicenow.com/products/workplace-service-delivery.html)
  * ### [Accounts Payable Operations Automate invoice ingestion and pay suppliers accurately.](https://www.servicenow.com/products/accounts-payable.html)
  * ### [Sourcing and Procurement Operations Deploy easy-to-follow procurement processes.](https://www.servicenow.com/products/procurement-service-management.html)
  * ### [Supplier Lifecycle Operations Streamline supplier onboarding, collaboration, and performance management.](https://www.servicenow.com/products/supplier-lifecycle-management.html)
  * ### [EmployeeWorks Stop chasing what other AI tools should have finished.](https://www.servicenow.com/products/employeeworks.html)


App Development
App Development
Build custom apps fast while enhancing developer and business expert productivity.
[Explore Solution](https://www.servicenow.com/solutions/application-development.html)
Related Products
  * ### [App Engine Build apps that automate manual work and modernize legacy processes.](https://www.servicenow.com/products/now-platform-app-engine.html)
  * ### [Integration Hub Reduce cost and complexity for ServiceNow integrations.](https://www.servicenow.com/products/integration-hub.html)


[](https://www.servicenow.com/products-by-category.html)
Industries
Browse solutions to help you solve the complex business challenges unique to your industry.
[Learn More](https://www.servicenow.com/industries.html)
  * ### [Automotive Put your automotive operations in overdrive with a single AI platform.](https://www.servicenow.com/industries/automotive.html)
  * ### [Banking Future-proof your bank with one AI platform.](https://www.servicenow.com/industries/banking.html)
  * ### [Consumer Packaged Goods Power your product growth and efficiency with a single AI platform.](https://www.servicenow.com/industries/consumer-packaged-goods.html)
  * ### [Healthcare Fuel efficiency, reduce costs, and deliver quality care with a single AI platform.](https://www.servicenow.com/industries/healthcare.html)
  * ### [Insurance Be the trusted carrier of choice with one AI platform.](https://www.servicenow.com/industries/insurance.html)
  * ### [Life Sciences Accelerate innovation, in and out of the lab, with one AI-powered platform.](https://www.servicenow.com/industries/life-sciences.html)
  * ### [Manufacturing Drive manufacturing efficiency with one AI platform.](https://www.servicenow.com/industries/manufacturing.html)
  * ### [Nonprofit Learn how to do more with less while making your nonprofit organization more agile and effective.](https://www.servicenow.com/solutions/industry/non-profit.html)
  * ### [National Government Deliver secure experiences for civilian, defense, and intelligence IT workflows.](https://www.servicenow.com/industries/government.html)
  * ### [Retail Enhance retail experiences with AI-powered insights on a single AI platform.](https://www.servicenow.com/industries/retail.html)
  * ### [Technology Providers Reimagine your XaaS lifecycle with a single AI platform.](https://www.servicenow.com/industries/technology-providers.html)
  * ### [Telecom Grow revenue, automate operations, and manage infrastructure on one AI platform.](https://www.servicenow.com/industries/telecom.html)


Learning
  * ServiceNow University
  * Community
  * Developer Resources
  * Events
  * Customer Stories
  * Blog


ServiceNow University
ServiceNow University
Discover a playground for learning, designed to help develop the skills you need for an AI-driven world.
[Start Learning](https://learning.servicenow.com/now/lxp/home)
  * ### [Training & Certification Explore ServiceNow certifications, career journeys, and expert programs—all designed to build your skills and elevate your career.](https://www.servicenow.com/university/training-and-certification.html)
  * ### [Skill Your Team Upskill your teams with scalable, role-based training designed to help you reach your digital transformation goals faster.](https://www.servicenow.com/university/skill-your-team.html)
  * ### [Skilling Programs Explore skilling programs at ServiceNow University, including RiseUp and partnerships that develop ServiceNow-skilled talent to meet rising ecosystem demands.](https://www.servicenow.com/university/skilling-programs.html)


Community
Community
Learn from ServiceNow experts and engage in discussions with industry peers.
[Visit Community](https://www.servicenow.com/community)
  * ### [Product hubs Find the resources, tools, and guidance you need for any ServiceNow product.](https://www.servicenow.com/community/products/ct-p/product-discussions)
  * ### [ServiceNow user groups Join a user group in person or online to expand your network and knowledge.](https://www.servicenow.com/community/servicenow-user-groups-snugs/ct-p/servicenow-user-groups-snugs)
  * ### [Developer forum Connect with other developers to ask questions, offer solutions, and build together.](https://www.servicenow.com/community/developer/ct-p/Developer)
  * ### [Community events Find live events for the ServiceNow community online or in person near you.](https://www.servicenow.com/community/events/ct-p/TopLevel_Events)
  * ### [Community Central From updates to best practices, find all things community related.](https://www.servicenow.com/community/community-central/ct-p/community-central)
  * ### [Join the community Become a member of our vibrant ServiceNow community.](https://www.servicenow.com/community/community-central/ct-p/community-central)


Developer Resources
Developer resources
Get your team building apps fast with tools and personal developer instances.
[Explore Resources](https://developer.servicenow.com/dev.do)
  * ### [Learn Browse learning plans and courses that teach you how to build apps to tackle your company's business needs.](https://developer.servicenow.com/dev.do#!/learn)
  * ### [Reference documentation Find APIs, libraries, and supplemental materials for working with the ServiceNow AI Platform.](https://developer.servicenow.com/dev.do#!/reference)
  * ### [Guides Read technology overviews and recommendations for innovating on the ServiceNow AI Platform.](https://developer.servicenow.com/dev.do#!/guides)
  * ### [Connect Meet fellow creators and gain insights from the community.](https://developer.servicenow.com/dev.do#!/connect)
  * ### [Design Find components, patterns, and resources to help you start designing experiences on the ServiceNow AI Platform.](https://horizon.servicenow.com/)


Events
Events
Join us at an event and learn how the world works with ServiceNow.
[Find Your Event](https://www.servicenow.com/events.html)
  * ### [Knowledge 2026 Join us May 5-7 at Knowledge, where you and AI get to work. ](https://www.servicenow.com/events/knowledge.html)
  * ### [World Forum 2026 Check out 2026 dates and locations, and discover how you can put AI to work in a city near you. ](https://www.servicenow.com/events/world-forum.html)
  * ### [Webinars Broaden your knowledge by registering for live and on demand ServiceNow webinars.](https://www.servicenow.com/events/on-demand-webinars.html)
  * ### [Community events Find live events for the ServiceNow community happening near you.](https://www.servicenow.com/community/events/ct-p/TopLevel_Events)


![Two people at the Knowledge conference taking a picture.](https://www.servicenow.com/content/dam/servicenow-assets/public/en-us/images/company-events/knowledge/26/background/k26-promo-menu.lg.png)
### Registration is open for Knowledge 2026
Join us for the AI event that can change everything. Act now to save big. Come for the wow, leave with the know-how.
[Register Now](https://www.servicenow.com/events/knowledge.html?referenceSource=dotcom:k26:earlybird:nav:reg)
Customer Stories
Customer stories
Find out how businesses like yours rely on ServiceNow to make the world work.
[Read Stories](https://www.servicenow.com/customers.html)
  * ### [AI Agent Stories Learn how ServiceNow customers are putting AI to work.](https://www.servicenow.com/customers.html?page=1&products-category=servicenow%3Aproducts%2Fai-agents)
  * ### [HR Stories See how organizations are improving self-service and delivering outstanding employee experiences.](https://www.servicenow.com/customers.html?page=1&products-category=servicenow%3Aproducts%2Fhr-service-delivery)
  * ### [CRM Stories Discover how businesses enable self-service for customers and reduce resolution time.](https://www.servicenow.com/customers.html?page=1&solutions-category=servicenow%3Asolutions%2Fcustomer-service)
  * ### [Public Sector/Government Stories Explore ways to streamline operations, engage citizens, and empower employees.](https://www.servicenow.com/customers.html?page=1&Industry-category=servicenow%3AIndustry%2Fgovernment)
  * ### [Now on Now Hear how ServiceNow uses ServiceNow.](https://www.servicenow.com/company/how-servicenow-uses-servicenow.html)


![Aston Martin logo](https://www.servicenow.com/content/dam/servicenow-assets/public/en-us/digital-graphics/ds-logos/logo-aston-martin-aramco-f1-white.svg)
### Featured customer story
Aston Martin Aramco partners with ServiceNow to boost efficiency and productivity on and off the race track.
[Read story](https://www.servicenow.com/customers/f1.html)
Blog
Blog
Find unique perspectives on products, company news, and life at ServiceNow.
[Read the Latest](https://www.servicenow.com/blogs)
  * ### [Company news See the latest news and stories about ServiceNow partnerships, technology, and innovation.](https://www.servicenow.com/blogs/category/company-news)
  * ### [Trends and research Learn what the ServiceNow Research team is exploring to improve AI-powered experiences.](https://www.servicenow.com/blogs/category/servicenow-research)
  * ### [Product insights Read about the positive impact of ServiceNow products in action.](https://www.servicenow.com/blogs/category/product-news)


Support
  * Customer Support
  * Documentation
  * Best Practices
  * MyNow
  * Customer Success
  * Platform Releases


Customer Support
Customer Support
Access your instances, manage tasks and explore self-service help all in one place.
  * ### [Community Connect with other customers to share tips, exchange resources, and solve problems together.](https://www.servicenow.com/community/)
  * ### [Get support Discover answers, troubleshoot issues, and get expert help, all in our support center.](https://support.servicenow.com/)


Documentation
Documentation
Find answers to your technical questions and learn how to use ServiceNow products.
[Visit Documentation](https://www.servicenow.com/docs/)
  * ### [IT Service Management Deliver IT services to your users all through a single cloud-based platform.](https://servicenow.com/docs/csh?version=latest&topicname=r_ITServiceManagement.html)
  * ### [Customer Service Management Provide customers the ability to communicate and receive support through multiple channels.](https://servicenow.com/docs/csh?version=latest&topicname=c_CustomerServiceManagement.html)
  * ### [IT Operations Management Get visibility into infrastructure and services, prevent outages, and expand operational agility.](https://servicenow.com/docs/csh?version=latest&topicname=r_ITOMApplications.html)
  * ### [ServiceNow AI Platform Automate processes and develop, run, and manage applications.](https://servicenow.com/docs/csh?version=latest&topicname=now-platform-landing.html)


### What’s new in AI experiences
Use AI-based tools to prioritize and automate routine tasks, detect incidents, and surface insights.
[Start Reading](https://servicenow.com/docs/csh?version=latest&amp;topicname=ai-products.html)
Best Practices
Best Practices
Accelerate outcomes with expert-curated best practices for the ServiceNow AI Platform.
[Home](https://mynow.servicenow.com/now/best-practices/home)
  * ### [ServiceNow AI Platform Automate business processes, streamline app development, and manage digital infrastructure.](https://mynow.servicenow.com/now/best-practices/collections/now-platform-best-practices)
  * ### [Customer Service Management Deliver exceptional service, empower customers, and enhance their experience.](https://mynow.servicenow.com/now/best-practices/collections/customer-service-management-best-practices)
  * ### [IT Service Management Streamline IT service delivery, boost productivity, resolve issues, and enhance user satisfaction.](https://mynow.servicenow.com/now/best-practices/collections/it-service-management-best-practices)
  * ### [Employee Service Management Streamline onboarding, provide HR and IT support, and empower employees with digital workflows.](https://mynow.servicenow.com/now/best-practices/collections/employee-service-management-best-practices)
  * ### [Telecommunications Service Management Unify telecom operations and deliver proactive care with quality and availability for services.](https://mynow.servicenow.com/now/best-practices/collections/telecommunications-service-management-best-practices)
  * ### [Governance, Risk, and Compliance Build an integrated risk program, enhance decision-making, and improve performance with automation.](https://mynow.servicenow.com/now/best-practices/collections/governance-risk-and-compliance-best-practices)
  * ### [Security Operations Accelerate response and strengthen security posture with SecOps workflows.](https://mynow.servicenow.com/now/best-practices/collections/security-operations-best-practices)


MyNow
MyNow
Explore MyNow, your personalized experience for quick access to your workflows, to-do lists, and AI guided recommendations.
  * ### [Learn More Start your day with MyNow.](https://www.servicenow.com/mynow.html)


Customer Success
Customer Success
Increase your ROI and get more value from the ServiceNow platform.
  * ### [ServiceNow Impact™ success plans Receive long-term adoption guidance and support with an Impact success plan tailored to you.](https://www.servicenow.com/impact.html)
  * ### [Services Implement and optimize ServiceNow with expert help from ServiceNow and our partners.](https://www.servicenow.com/services/expert-services.html)


Platform Releases
ServiceNow Platform Zurich Release
See innovation highlights, get release notes, and start your upgrade to our latest ServiceNow AI Platform software release.
[Go to Latest Release](https://www.servicenow.com/now-platform/latest-release.html)
Past Releases
  * ### [Yokohama Put AI innovations to work today.](https://www.servicenow.com/docs/bundle/yokohama-release-notes/page/release-notes/family-release-notes.html)
  * ### [Xanadu The biggest ServiceNow AI release yet.](https://www.servicenow.com/docs/bundle/xanadu-release-notes/page/release-notes/family-release-notes.html)
  * ### [Washington D.C. Take work to the next level with smarter, faster, simpler experiences for everyone.](https://www.servicenow.com/docs/bundle/washingtondc-release-notes/page/release-notes/family-release-notes.html)


Partners
Locate the partner you need, or explore the benefits of partnering with ServiceNow.
[Learn More](https://www.servicenow.com/partners.html)
  * ### [Find a partner Connect with a ServiceNow partner to reach your business goals.](https://www.servicenow.com/partners/partner-finder.html)
  * ### [Become a partner Join our partner ecosystem. Choose the partner paths that best fit your expertise and experience.](https://www.servicenow.com/partners/become-a-partner.html)
  * ### [Partner awards Meet the global ServiceNow partners leading the way in innovation and value for our customers.](https://www.servicenow.com/partners/awards.html)
  * ### [Partner portal Find tasks, alerts, and information you need, all in one place.](https://partnerportal.service-now.com/partnerhome)
  * ### [Partner applications Explore innovative apps that extend and complement the ServiceNow AI Platform.](https://store.servicenow.com/sn_appstore_store.do#!/store/home?offeredby=partners)


Discover how the world works with ServiceNow
Bring AI Agents to every corner of your business.
[Learn More](https://www.servicenow.com/company.html)
  * ### [Careers Make your next career move with the fastest growing enterprise software company.](https://careers.servicenow.com/careers)
  * ### [Investors Explore investor news and resources.](https://www.servicenow.com/company/investor-relations.html)
  * ### [ServiceNow AI Research Learn how we keep innovation moving forward through our AI research team, labs, and partnerships.](https://www.servicenow.com/research/)
  * ### [Leadership Meet the ServiceNow leadership team.](https://www.servicenow.com/company/leadership.html)
  * ### [Locations See ServiceNow office locations around the world.](https://www.servicenow.com/company/locations.html)
  * ### [Newsroom ServiceNow is making headlines. Find announcements, media kits, and more.](https://newsroom.servicenow.com/overview/default.aspx)
  * ### [Analyst Reports Get expert insights from top industry analysts on ServiceNow.](https://www.servicenow.com/company/analyst-reports.html)
  * ### [Global impact Join us to foster a more sustainable, fair, and ethical world.](https://www.servicenow.com/company/global-impact.html)
  * ### [Trust and compliance Learn the measures ServiceNow takes to keep your data secure and compliant.](https://www.servicenow.com/company/trust.html)


![Company Collage](https://www.servicenow.com/content/dam/servicenow-assets/images/naas/company-collage.png)
[View a Demo](https://www.servicenow.com/lpdem/demonow-all.html)
[Community](https://www.servicenow.com/community)
  * ![icon](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cpath%20d%3D%22M22.5%2011.9855C22.5%2012.4081%2022.1254%2012.7367%2021.704%2012.7367H4.05184L10.607%2019.7793C10.888%2020.061%2010.888%2020.5305%2010.5602%2020.8122C10.4197%2020.9531%2010.2324%2021%2010.0452%2021C9.81104%2021%209.62375%2020.9531%209.48328%2020.7652L1.7107%2012.502C1.42977%2012.2203%201.42977%2011.7977%201.7107%2011.516L9.48328%203.2527C9.76421%202.92404%2010.2324%202.92404%2010.5602%203.20575C10.888%203.48745%2010.888%203.95696%2010.607%204.23866L4.05184%2011.2343H21.704C22.1254%2011.2343%2022.5%2011.6099%2022.5%2011.9855Z%22%20fill%3D%22%231D1D1D%22%2F%3E%0A%20%20%20%20%20%20%20%20%20%20%3C%2Fsvg%3E)Product Hubs
  * ![icon](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cpath%20d%3D%22M22.5%2011.9855C22.5%2012.4081%2022.1254%2012.7367%2021.704%2012.7367H4.05184L10.607%2019.7793C10.888%2020.061%2010.888%2020.5305%2010.5602%2020.8122C10.4197%2020.9531%2010.2324%2021%2010.0452%2021C9.81104%2021%209.62375%2020.9531%209.48328%2020.7652L1.7107%2012.502C1.42977%2012.2203%201.42977%2011.7977%201.7107%2011.516L9.48328%203.2527C9.76421%202.92404%2010.2324%202.92404%2010.5602%203.20575C10.888%203.48745%2010.888%203.95696%2010.607%204.23866L4.05184%2011.2343H21.704C22.1254%2011.2343%2022.5%2011.6099%2022.5%2011.9855Z%22%20fill%3D%22%231D1D1D%22%2F%3E%0A%20%20%20%20%20%20%20%20%20%20%3C%2Fsvg%3E)Connect
  * ![icon](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cpath%20d%3D%22M22.5%2011.9855C22.5%2012.4081%2022.1254%2012.7367%2021.704%2012.7367H4.05184L10.607%2019.7793C10.888%2020.061%2010.888%2020.5305%2010.5602%2020.8122C10.4197%2020.9531%2010.2324%2021%2010.0452%2021C9.81104%2021%209.62375%2020.9531%209.48328%2020.7652L1.7107%2012.502C1.42977%2012.2203%201.42977%2011.7977%201.7107%2011.516L9.48328%203.2527C9.76421%202.92404%2010.2324%202.92404%2010.5602%203.20575C10.888%203.48745%2010.888%203.95696%2010.607%204.23866L4.05184%2011.2343H21.704C22.1254%2011.2343%2022.5%2011.6099%2022.5%2011.9855Z%22%20fill%3D%22%231D1D1D%22%2F%3E%0A%20%20%20%20%20%20%20%20%20%20%3C%2Fsvg%3E)Blogs
  * ![icon](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3Cpath%20d%3D%22M22.5%2011.9855C22.5%2012.4081%2022.1254%2012.7367%2021.704%2012.7367H4.05184L10.607%2019.7793C10.888%2020.061%2010.888%2020.5305%2010.5602%2020.8122C10.4197%2020.9531%2010.2324%2021%2010.0452%2021C9.81104%2021%209.62375%2020.9531%209.48328%2020.7652L1.7107%2012.502C1.42977%2012.2203%201.42977%2011.7977%201.7107%2011.516L9.48328%203.2527C9.76421%202.92404%2010.2324%202.92404%2010.5602%203.20575C10.888%203.48745%2010.888%203.95696%2010.607%204.23866L4.05184%2011.2343H21.704C22.1254%2011.2343%2022.5%2011.6099%2022.5%2011.9855Z%22%20fill%3D%22%231D1D1D%22%2F%3E%0A%20%20%20%20%20%20%20%20%20%20%3C%2Fsvg%3E)Resources


  * [Join the Community](https://www.servicenow.com/community/s/plugins/common/feature/oidcss/sso_login_redirect/providerid/default?referer=https%3A%2F%2Fwww.servicenow.com%2Fcommunity%2Fcommunity-central%2Fct-p%2Fcommunity-central)


[Join the Community](https://www.servicenow.com/community/s/plugins/common/feature/oidcss/sso_login_redirect/providerid/default?referer=https%3A%2F%2Fwww.servicenow.com%2Fcommunity%2Fcommunity-central%2Fct-p%2Fcommunity-central)
Product Hubs
  * Most Active
  * Platform
  * App Development
  * Asset Management
  * Data and Analytics
  * CRM and Industry Solutions
  * [](https://www.servicenow.com/community/onboarding-hub/ct-p/new-customer-onboarding)[](https://www.servicenow.com/community/releases-and-upgrades/ct-p/releases-and-upgrades)[](https://www.servicenow.com/community/products/ct-p/product-discussions)


Most Active
Most active product hubs
See what product hubs the other Community members are talking about and jump into a conversation.
[Visit Now Assist](https://www.servicenow.com/community/now-assist/ct-p/now-assist%20)
  * ### [Agent Chat, Routing, Sidebar Get started with training or one of our guides, or explore advanced topics. ](https://www.servicenow.com/community/agent-chat-routing-and-sidebar/ct-p/agent-chat-routing-sidebar)
  * ### [App Engine Bring new enterprise apps to market in half the time and one-third the cost with low-code apps.](https://www.servicenow.com/community/app-engine/ct-p/app-engine)
  * ### [CMDB Find CMDB guidelines, product resources, expert help, or join the discussions. ](https://www.servicenow.com/community/cmdb/ct-p/CMDB)
  * ### [CSDM Learn or ask questions about the Common Service Data Model or find an event.](https://www.servicenow.com/community/csdm/ct-p/common-service-data-model-csdm%20)
  * ### [Customer Service Management Learn more about request automation and how to empower employees to address customer needs.](https://www.servicenow.com/community/csm/ct-p/customer-service-management)
  * ### [Employee Center Discover how others are succeeding with this dynamic portal for service delivery and employee engagement.](https://www.servicenow.com/community/employee-center/ct-p/employee-center%20)
  * ### [Governance, Risk, and Compliance Find out about this integrated approach to building operational resilience, mitigate risk, and manage compliance.](https://www.servicenow.com/community/grc/ct-p/governance-risk-compliance%20)
  * ### [Hardware Asset Management Manage your IT environment lifecycle management even better for more strategic decision-making.](https://www.servicenow.com/community/ham/ct-p/hardware-asset-management)
  * ### [Human Resources Service Delivery Provide a more efficient employee service with guidelines, product resources, and expert help.](https://www.servicenow.com/community/hrsd/ct-p/human-resources-service-delivery)
  * ### [Impact See how our value acceleration solutions can meet you where you are on your ServiceNow journey.](https://www.servicenow.com/community/impact/ct-p/impact)
  * ### [Intelligence and Machine Learning Data-based decision making that improves performance and provides actionable insights.](https://www.servicenow.com/community/intelligence-and-machine/ct-p/ai-intelligence%20)
  * ### [IT Operations Management Network with peers or ask, answer IT ops questions, or learn what can be integrated with ITOM.](https://www.servicenow.com/community/itom/ct-p/it-operations-management%20)
  * ### [IT Service Management See how others are transforming service management to increase productivity and ROI.](https://www.servicenow.com/community/itsm/ct-p/it-service-management%20)
  * ### [Mobile Apps & Platform Improve productivity across IT, HR, facilities, and other departments with mobile apps.](https://www.servicenow.com/community/mobile-apps-platform/ct-p/mobile-apps-platform%20)
  * ### [Next Experience Explore Next Experience, UI Builder, and Workspaces.](https://www.servicenow.com/community/next-experience/ct-p/next-experience%20)
  * ### [Now Assist & Generative AI Learn more about putting generative AI to work with Now Assist to simplify work.](https://www.servicenow.com/community/now-assist/ct-p/now-assist%20)
  * ### [Platform Analytics Start at the beginning or find advanced topics on Performance Analytics and reporting.](https://www.servicenow.com/community/platform-analytics/ct-p/platform-analytics%20)
  * ### [Security Operations Learn more about overcoming threats and vulnerabilities and improving cyber resilience and response times.](https://www.servicenow.com/community/secops/ct-p/security-operations)
  * ### [Service Management Get articles, answers, and information about upcoming events on Service Management.](https://www.servicenow.com/community/service-management/ct-p/service-management%20)
  * ### [Service Operations Workspace Learn more about core workflows or read the Getting Started guide to start your journey.](https://www.servicenow.com/community/service-operations-workspace/ct-p/service-operations-workspace%20)
  * ### [Software Asset Management See how others are controlling risk and automating the software lifecycle, all from a single platform.](https://www.servicenow.com/community/sam/ct-p/it-asset-management%20)
  * ### [Strategic Portfolio Management Discover how you can break down silos and gain visibility across the enterprise.](https://www.servicenow.com/community/spm/ct-p/strategic-portfolio-management)
  * ### [Virtual Agent & NLU Find answers to questions or learn more about integrating Virtual Agent with messaging apps.](https://www.servicenow.com/community/virtual-agent-nlu/ct-p/virtual-agent-natural-language%20)
  * ### [Workflow Automation Get more from Workflow Automation with one of our playbooks or join the forum.](https://www.servicenow.com/community/workflow-automation/ct-p/workflow-automation%20)


Platform
Platform
Learn more about using AI, data, and workflows together for your organization, no matter what industry you’re in.
[Learn More](https://www.servicenow.com/community/servicenow-ai-platform/ct-p/now-platform)
  * ### [Admin Experience Resources Get recommended solutions with streamlined setup experiences and a centralized hub for admin tasks.](https://www.servicenow.com/community/admin-experience/ct-p/admin-experience)
  * ### [Agent Chat, Routing, and Sidebar Find answers to questions on advanced agent chat with smart routing and incident management.](https://www.servicenow.com/community/agent-chat-routing-and-sidebar/ct-p/agent-chat-routing-sidebar)
  * ### [Intelligence and Machine Learning See how you can take performance improvement further with data-based decision making.](https://www.servicenow.com/community/intelligence-and-machine/ct-p/ai-intelligence%20)
  * ### [Knowledge Management Gain the contextual knowledge that will increase customers’ and employees’ use of self-service.](https://www.servicenow.com/community/knowledge-management/ct-p/knowledge-management)
  * ### [Mobile Apps and Platform Join this forum to create and configure better apps that improve productivity.](https://www.servicenow.com/community/mobile-apps-platform/ct-p/mobile-apps-platform)
  * ### [Next Experience Learn more about Next Experience, UI Builder, and Workspaces in the forum or hot topics.](https://www.servicenow.com/community/next-experience/ct-p/next-experience)
  * ### [Now Assist and Generative AI Learn more about Now Assist and how it uses GenAI to simplify work.](https://www.servicenow.com/community/now-assist/ct-p/now-assist)
  * ### [Platform Analytics Get toolkits and extended learning opportunities for Performance Analytics and Reporting.](https://www.servicenow.com/community/platform-analytics/ct-p/platform-analytics%20)
  * ### [Platform Privacy and Security Find integrations or step-by-step guidance on ServiceNow Vault or security hardening.](https://www.servicenow.com/community/platform-privacy-security/ct-p/platform-privacy-security)
  * ### [Process Mining Process Mining helps analysts and process stakeholders quickly analyze and optimize their business processes.](https://www.servicenow.com/community/process-and-task-mining/ct-p/process-optimization)
  * ### [Service Catalog Find out how others deliver products and services and empower users with self-service.](https://www.servicenow.com/community/service-catalog/ct-p/service-catalog)
  * ### [Service Portal Get learning resources on using Service Portal, including creating an engaging visual layer for your content.](https://www.servicenow.com/community/service-portal/ct-p/service-portal)
  * ### [Virtual Agent and NLU Get the most from your virtual agent with the latest forum information and questions and answers. ](https://www.servicenow.com/community/virtual-agent-nlu/ct-p/virtual-agent-natural-language)
  * ### [Workflow Automation Discover more about automating processes and creating end-to-end workflows.](https://www.servicenow.com/community/workflow-automation/ct-p/workflow-automation)


App Development
App development
Discover how you can develop business apps for your enterprise, no matter what your role is.
[Learn More](https://www.servicenow.com/community/app-dev-get-started/ct-p/app-dev-get-started)
  * ### [Getting Started with Application Development Learn to create apps that scale seamlessly with custom workflows on the ServiceNow AI Platform.](https://www.servicenow.com/community/app-dev-get-started/ct-p/app-dev-get-started)
  * ### [App Engine Discover more about creating low-code apps to market in half the time and one-third the cost.](https://www.servicenow.com/community/app-engine/ct-p/app-engine)
  * ### [Citizen Development Center Find out why you should have citizen developers and help them get started building no- and low-code apps.](https://www.servicenow.com/community/citizen-development-center/ct-p/coe-citizen-development)
  * ### [Creator Studio Find everything you need to start creating no-code apps and start turning your business expertise into workflows.](https://www.servicenow.com/community/creator-studio/ct-p/creator-studio)
  * ### [Now Assist for Creator See how you can combine GenAI with Creator Studio for faster development and better collaboration.](https://www.servicenow.com/community/now-assist-for-creator/ct-p/creator-now-assist)
  * ### [ServiceNow Studio Learn more about using this comprehensive tool for app development.](https://www.servicenow.com/community/servicenow-studio/ct-p/servicenow-studio)
  * ### [App Engine for ERP Learn more about how to update your resource planning data from a system of record, like an SAP.](https://www.servicenow.com/community/app-engine-for-erp/ct-p/app-engine-erp)
  * ### [App Governance See how others govern their development processes from end to end.](https://www.servicenow.com/community/app-governance/ct-p/app-governance)


Asset Management
Asset management
See how you can manage all your enterprise’s assets efficiently.
[Learn More](https://www.servicenow.com/community/asset-management/ct-p/asset-management)
  * ### [Cloud Cost Management Learn more about managing your cloud resources for less cost and risk.](https://www.servicenow.com/community/cloud-cost-management/ct-p/cloud-insights)
  * ### [Enterprise Asset Management Find out how you can govern the enterprise asset lifecycle from planning to disposal.](https://www.servicenow.com/community/eam/ct-p/enterprise-asset-management)
  * ### [Hardware Asset Management Learn more about automating and supporting your IT environment’s lifecycle.](https://www.servicenow.com/community/ham/ct-p/hardware-asset-management)
  * ### [Software Asset Management See what others are doing to control risk, reduce costs, and automate the software lifecycle.](https://www.servicenow.com/community/sam/ct-p/it-asset-management)


Data and Analytics
Data and Analytics
Discover more about these go-to tools for strengthening your data foundations.
[Learn More](https://www.servicenow.com/community/data-and-analytics/ct-p/data-foundations)
  * ### [API Insights Learn about managing your centralized API data using API Insights.](https://www.servicenow.com/community/api-insights/ct-p/api-insights)
  * ### [CMDB Find resources and integrations, or find peers to collaborate with on using ServiceNow CMDB. ](https://www.servicenow.com/community/cmdb/ct-p/CMDB)
  * ### [CSDM Learn or ask questions about the Common Service Data Model in the forum, or find articles.](https://www.servicenow.com/community/csdm/ct-p/common-service-data-model-csdm)
  * ### [Platform Analytics Start at the beginning or find advanced topics on Performance Analytics and reporting.](https://www.servicenow.com/community/platform-analytics/ct-p/platform-analytics)
  * ### [Service Graph Connectors Get more information on ServiceGraph Connectors](https://www.servicenow.com/community/service-graph-connectors/ct-p/service-graph-connectors)
  * ### [Workflow Data Fabric Get more information on unifying enterprise data for workflows and AI agents with real-time, secure data access.](https://www.servicenow.com/community/workflow-data-fabric/ct-p/workflow-data-fabric)


CRM and Industry Solutions
CRM and Industry solutions
See how others within your industry are using ServiceNow to simplify work and improve their processes.
[Learn More](https://www.servicenow.com/community/crm-and-industry-solutions/ct-p/industry-solutions)
  * ### [Customer Service Management Learn more about request automation and how to empower employees to address customer needs. ](https://www.servicenow.com/community/csm/ct-p/customer-service-management)
  * ### [Field Service Management Revolutionizing Field Service Management – Smarter Scheduling, Faster Resolutions, and Seamless Customer Experiences.](https://www.servicenow.com/community/fsm/ct-p/field-service-management)
  * ### [Financial Services Operations Learn more about connecting your entire financial institution on the ServiceNow AI Platform.](https://www.servicenow.com/community/fso/ct-p/financial-services-operations)
  * ### [Healthcare and Life Sciences Get involved in the forum on facilitating patient-centric care and great clinician experiences.](https://www.servicenow.com/community/healthcare-and-life-sciences/ct-p/healthcare-life-sciences)
  * ### [Manufacturing Get the answers and information you need to improve manufacturing productivity and efficiency.](https://www.servicenow.com/community/manufacturing/ct-p/manufacturing)
  * ### [Public Sector Digital Services Find our more about how you can use AI for better government service delivery.](https://www.servicenow.com/community/public-sector-digital-services/ct-p/public-sector-digital-services)
  * ### [Retail and Hospitality Learn or ask questions about Retail Service Management (RSM) and Retail Operations (RO).](https://www.servicenow.com/community/retail-hospitality/ct-p/industry-retail-hospitality)
  * ### [Technology Provider See how others are streamlining operations and fueling growth using the ServiceNow AI Platform.](https://www.servicenow.com/community/technology-provider/ct-p/technology)
  * ### [Telecommunications Improve your end-to-end service experience with these resources and tips from peers and experts.](https://www.servicenow.com/community/telecom/ct-p/telecommunication)


[](https://www.servicenow.com/community/onboarding-hub/ct-p/new-customer-onboarding)[](https://www.servicenow.com/community/releases-and-upgrades/ct-p/releases-and-upgrades)[](https://www.servicenow.com/community/products/ct-p/product-discussions)
Connect
  * Connect by Role


Connect at Events
  * Events


Connect in groups
  * Developer Meetups
  * Industry Groups
  * Interest Groups
  * ServiceNow User Groups (SNUGs)


Connect by region
  * Locations


Connect by Role
Connect by role
Get the latest updates and challenges from the ServiceNow Developer Advocates. Find release info and upcoming events.
  * ### [Architects See the latest solutions and best practices our architects have posted.](https://www.servicenow.com/community/architect/ct-p/Architect)
  * ### [Champions Community forum Ask a question and see the latest solutions offered by ServiceNow developer champions.](https://www.servicenow.com/community/champion-community/ct-p/champion-program)
  * ### [Developers Join a discussion or find resources to learn more from fellow developers](https://www.servicenow.com/community/developer/ct-p/Developer)
  * ### [Expert Services Get faster results when you implement our products with a team of ServiceNow experts.](https://www.servicenow.com/community/expert-services/ct-p/servicenow-expert-services)
  * ### [Knowledge managers Find knowledge management tips and see what problems managers are solving. ](https://www.servicenow.com/community/knowledge-managers/gh-p/knowledge-managers-)
  * ### [Onboarding hub Find the top resources for getting started with onboarding guides, events, and posts.](https://www.servicenow.com/community/new-customer-onboarding/ct-p/new-customer-onboarding)
  * ### [Platform Owner Resource Center Get the latest articles, events, and blogs to keep platform owners updated. ](https://www.servicenow.com/community/platform-owner-resource-center/ct-p/platform-owner-resource-center)
  * ### [SysAdmin forum Participate in the discussions to connect with and learn from other SysAdmins.](https://www.servicenow.com/community/system-administrator/ct-p/sysadmin)
  * ### [ServiceNow jobs Join the ServiceNow team of experts who are delivering innovation daily.](https://www.servicenow.com/community/servicenow-jobs/ct-p/servicenow-jobs)
  * ### [Training and certifications Explore the ServiceNow certification portfolio and see what you want to learn next.](https://www.servicenow.com/community/training-and-certifications/ct-p/training-and-certifications)


### Developer Community
Join in the discussions our developers are having.
[Learn More](https://www.servicenow.com/community/developer/ct-p/Developer)
Connect at Events
Events
Events
Browse our live and on-demand events to learn more so you can get the most from your ServiceNow AI Platform.
[Learn More](https://www.servicenow.com/community/events/ct-p/TopLevel_Events)
  * ### [Community events Find the webinars, meetups, and more on everything from App Engine to Workplace Service Delivery.](https://www.servicenow.com/community/events/ct-p/TopLevel_Events)
  * ### [Community Week Join us and celebrate the spirit of Community! Live sessions, AMAs, badges, and more!](https://www.servicenow.com/community/community-week/ct-p/community-week)
  * ### [ ServiceNow Exchange Gain insider tips, proven shortcuts, and practical tools from ServiceNow star practitioners and peers to simplify complexity and achieve faster, smarter business results.](https://www.servicenow.com/community/servicenow-exchange-events/ct-p/servicenow-exchange-events)
  * ### [Ask the experts Expand your skills with our expert-led sessions or ask your own question in the forum. ](https://www.servicenow.com/community/ask-the-expert-events/ct-p/events-ask-the-expert)
  * ### [CreatorCon Build something great for the ServiceNow AI Platform and connect with other builders, too.](https://www.servicenow.com/community/creatorcon/ct-p/creatorcon)
  * ### [The Devvies: App of the Year Build impactful apps so you can earn awards, recognition, and bragging rights.](https://www.servicenow.com/community/the-devvies-app-of-the-year/ct-p/the-devvies)
  * ### [DemoCenter Watch live solution demonstrations each month to do more on the platform.](https://www.servicenow.com/community/-/-/ta-p/2323183)
  * ### [Partner events Find out about training for partners or join us at one of our global events.](https://partnersuccess.servicenow.com/partner-experience-events.html)
  * ### [ServiceNow podcasts Listen to one of our many focused podcasts designed to give you more from ServiceNow.](https://www.servicenow.com/community/servicenow-podcasts/ct-p/servicenow-podcasts)
  * ### [ServiceNow events See the events happening beyond Community, across the ServiceNow ecosystem. ](https://www.servicenow.com/events.html)
  * ### [AI Pacesetter awards See who’s truly innovating and making AI work for people or join the contest.](https://www.servicenow.com/community/the-ai-pacesetter-innovation/ct-p/ai-pacesetter-awards)


### ServiceNow Exchange
Stay updated with what’s new, get implementation pro tips, and connect with the ServiceNow community​.
[Learn More](https://www.servicenow.com/community/servicenow-exchange-events/ct-p/servicenow-exchange-events)
Developer Meetups
Developer meetups
Connect with peers, share best practices, and stay up to date with the latest ServiceNow trends, no matter where you are in your ServiceNow journey.
[Learn More](https://www.servicenow.com/community/developer-meetups/ct-p/developer-meetups)
  * ### [Americas Find your peers at one of our meetups in the Americas and expand your network. ](https://www.servicenow.com/community/ams-developer-meetups/ct-p/developer-meetups-ams-united-states)
  * ### [Europe, Middle East, Africa Find your peers at one of our meetups in the Europe, Middle East, or Africa region and expand your network. ](https://www.servicenow.com/community/emea-developer-meetups/ct-p/developer-meetups-emea)
  * ### [Asia, Pacific, Japan Find your peers at one of our meetups in the Asia, Pacific, and Japan region and expand your network. ](https://www.servicenow.com/community/apj-developer-meetups/ct-p/developer-meetups-apj)


### Developer Meetups
Whether you're a seasoned developer or just starting your journey, Meetups are the perfect place to connect with peers, share best practices, and stay up-to-date with the latest ServiceNow trends.
[Learn More](https://www.servicenow.com/community/developer-meetups/ct-p/developer-meetups)
Industry Groups
Industry groups
Our special interest groups include education and leadership so you can expand the adoption and use of ServiceNow technology in your industry.
[Learn More](https://www.servicenow.com/community/groups/ct-p/Groups)
  * ### [Energy Collaborate with other customers who have similar challenges and opportunities in energy industries.](https://www.servicenow.com/community/energy-special-interest-group/gh-p/sig-energy-)
  * ### [Financial Services Innovate more in the financial services industry from the back office to your customers.](https://www.servicenow.com/community/financial-services-special/gh-p/sig-financial-services-)
  * ### [Governments and military Connect with on of several government, military, and veteran groups. ](https://www.servicenow.com/community/governments-military-sigs/ct-p/sig-gov-mil)
  * ### [Healthcare Find out what the hot topics are and meet others in one of our healthcare groups.](https://www.servicenow.com/community/healthcare-and-life-sciences/ct-p/sig-groups-healthcare)
  * ### [Higher Education See how others are automating and managing service relationships on their campuses. ](https://www.servicenow.com/community/higher-education-special/gh-p/sig-higher-education-)
  * ### [Life Sciences See what’s impacting the life sciences industry and find colleagues around the globe.](https://www.servicenow.com/community/healthcare-and-life-sciences/ct-p/sig-groups-healthcare)
  * ### [Manufacturing Network with peers around the globe on operational technology, mitigating risk, and other manufacturing topics.](https://www.servicenow.com/community/manufacturing-special-interest/gh-p/sig-manufacturing-)
  * ### [ServiceNow Creator Club Join other creators in your industry with similar roles to learn about the impact of automating your business. ](https://www.servicenow.com/community/servicenow-creator-club/gh-p/sig-creator-central-emea)
  * ### [All groups See all our available industry groups and expand your knowledge.](https://www.servicenow.com/community/groups/ct-p/Groups)


Interest Groups
Special interest groups
Join in a special interest group for education and leadership that will help you expand your adoption and use of ServiceNow technology.
[See All Groups](https://www.servicenow.com/community/special-interest-groups/ct-p/ServiceNow_Interest_Groups)
  * ### [EX Platform for the Modern Intranet Meet others who have (or are interested in) replacing their traditional intranet portals with ServiceNow.](https://www.servicenow.com/community/ex-platform-for-the-modern/gh-p/sig-modern-intranet)
  * ### [User Experience Deliver better ServiceNow user experiences when you connect with other designers, developers, and PMs.](https://www.servicenow.com/community/user-experience-sig/gh-p/sig-user-experience)
  * ### [Accessibility – A11y Get insight from partners and developers on accessibility conformance.](https://www.servicenow.com/community/accessibility-a11y/gh-p/sig-accessibility)


ServiceNow User Groups (SNUGs)
ServiceNow User Groups (SNUGs)
Collaborate around the world to learn best practices, want to talk shop with experts, or share tips and tricks.
[Learn More](https://www.servicenow.com/community/servicenow-user-groups-snugs/ct-p/servicenow-user-groups-snugs)
  * ### [Americas Meet other ServiceNow users online or in person throughout the Americas. ](https://www.servicenow.com/community/snug-ams-united-states/ct-p/snug-ams-united-states)
  * ### [Europe, Middle East, Africa Meet other ServiceNow users online or in person throughout the Europe, Middle East, and Africa region. ](https://www.servicenow.com/community/snug-emea/ct-p/snug-emea)
  * ### [Asia, Pacific, Japan Meet other ServiceNow users online or in person throughout the Asia, Pacific, and Japan region.](https://www.servicenow.com/community/snug-apj/ct-p/snug-apj)


Locations
Locations
Find local groups in Australia, New Zealand, or Japan to meet and discuss topics including government and employee experience, plus more.
[See All Locations](https://www.servicenow.com/community/servicenow-user-groups-snugs/ct-p/servicenow-user-groups-snugs)
  * ### [Australia and New Zealand Join a group in Australia or New Zealand or get involved in the online discussions.](https://www.servicenow.com/community/anz-special-interest-groups/ct-p/anz-special-interest-groups)
  * ### [Japan Join a group in Japan or get involved in the online discussions.](https://www.servicenow.com/community/japan/ct-p/Japan)


Blogs
  * Most Active
  * ServiceNow University
  * [](https://www.servicenow.com/community/blogs/ct-p/blogs)[](https://www.servicenow.com/community/developer-advocate-blog/bg-p/developer-advocate-blog)[](https://www.servicenow.com/community/developer-blog/bg-p/developer-blog)[](https://www.servicenow.com/blogs.html)


Most Active
Most active blogs
Take a look at the blogs that have Community members talking. Get videos that answer your questions, guidelines, strategy decks, and inspiration from experts.
[Read More](https://www.servicenow.com/community/blogs/ct-p/blogs)
  * ### [Developer Advocate blogs Read how these advocates help developers foster ServiceNow innovation.](https://www.servicenow.com/community/developer-advocate-blog/bg-p/developer-advocate-blog)
  * ### [Developer blogs See what ServiceNow developers are talking about, from analytics to VS code extensions.](https://www.servicenow.com/community/developer-blog/bg-p/developer-blog)
  * ### [In other news Find information on thought leadership, working with multiple versions, or explore other interests.](https://www.servicenow.com/community/in-other-news/bg-p/blog)
  * ### [ITOM blogs Find out what the hot ITOM topics are from ServiceNow employees and experts.](https://www.servicenow.com/community/itom-blog/bg-p/it-operations-management-blog)
  * ### [ITSM blogs Learn more about ITSM use cases, how to fine tune it or manage change. ](https://www.servicenow.com/community/itsm-blog/bg-p/it-service-management-blog)
  * ### [Japan Join our Japanese Community members for similar relevant topics. ](https://www.servicenow.com/community/japan/ct-p/Japan)
  * ### [ServiceNow AI Platform blogs Get recordings of training sessions, information on the latest platform features, and more.](https://www.servicenow.com/community/servicenow-ai-platform-blog/bg-p/now-platform-blog)
  * ### [Performance Analytics blogs Learn more about Performance Analytics premigration activities, GenAI, and more.](https://www.servicenow.com/community/performance-analytics-blog/bg-p/platform-analytics-blog)
  * ### [ServiceNow blogs Step away from Community to see what the general ServiceNow bloggers are saying.](https://www.servicenow.com/blogs.html)


### Developer Advocate blogs
Stay up to date with the Developer Advocates.
[Learn More](https://www.servicenow.com/community/developer-advocate-blog/bg-p/developer-advocate-blog)
ServiceNow University
ServiceNow University
Gain skills that are growing in demand and learn from others who’ve built rewarding careers with ServiceNow.
[Learn More](https://www.servicenow.com/community/servicenow-university/ct-p/sn-university)
  * ### [Tech Switchers Learn about new career paths in tech for workers from other fields.](https://www.servicenow.com/community/career-journey-stories/bg-p/sn-university-blogs/label-name/tech%20switchers)
  * ### [Business Skills Read about career changers thriving in tech with transferable skills.](https://www.servicenow.com/community/career-journey-stories/bg-p/sn-university-blogs/label-name/business%20skills)
  * ### [Early in Career See how young professionals gaining tech skills launch their careers.](https://www.servicenow.com/community/career-journey-stories/bg-p/sn-university-blogs/label-name/early%20in%20career)
  * ### [Life and Career Transition Learn how people pivot into tech, regardless of prior experience.](https://www.servicenow.com/community/career-journey-stories/bg-p/sn-university-blogs/label-name/life%20%26%20career%20transition)
  * ### [Veterans Read about how they transition into tech with the support of ServiceNow.](https://www.servicenow.com/community/career-journey-stories/bg-p/sn-university-blogs/label-name/veterans)


### Put AI to work for your career
Get skilled on the ServiceNow AI Platform through expert-led training and industry-recognized certifications.
[Start Learning](https://learning.servicenow.com/now/lxp/home)
[](https://www.servicenow.com/community/blogs/ct-p/blogs)[](https://www.servicenow.com/community/developer-advocate-blog/bg-p/developer-advocate-blog)[](https://www.servicenow.com/community/developer-blog/bg-p/developer-blog)[](https://www.servicenow.com/blogs.html)
Resources
  * Resources
  * Expert programs


Resources
Resources
Visit the ServiceNow Community hub for guidelines, to get involved, and to learn how to gain awards.
[Learn More](https://www.servicenow.com/community/community-central/ct-p/community-central)
  * ### [Community Central Start here for the latest news and updates.](https://www.servicenow.com/community/community-central/ct-p/community-central)
  * ### [Community guidelines Read the guidelines for participating in this peer-to-peer group of professionals. ](https://www.servicenow.com/community/community-resources/servicenow-community-code-of-conduct-for-all-members/ta-p/2338554)
  * ### [Recognition and Rewards Program Boost your ServiceNow resume by completing levels and earning badges that expand your skills. ](https://www.servicenow.com/community/recognition-rewards/ct-p/rewards)
  * ### [Idea Portal Have a say in upcoming ServiceNow features by voting or submitting enhancement requests.](https://support.servicenow.com/ideas?id=ideas_list&sysparm_module_id=enhancement_requests)


### Put AI to work with the Now Platform
Connect and automate workflows across the enterprise with a single AI platform for business transformation.
[Explore Platform](https://www.servicenow.com/community/servicenow-ai-platform/ct-p/now-platform)
Expert programs
Expert programs
Our Expert Programs offer the highest level of certification, recognizing you as a leader in strategy, design, architecture, and governance.
[Learn More](https://www.servicenow.com/community/community-expert-programs/ct-p/community-expert-programs)
  * ### [Become an Expert Become a top contributor and dedicate your expertise to one of our programs.](https://www.servicenow.com/community/community-expert-programs/ct-p/community-expert-programs)
  * ### [ServiceNow MVP Find out what it takes to be a most valued professional, the contribution areas, and core values.](https://www.servicenow.com/community/mvp/ct-p/mvp)
  * ### [Rising Star Program Commit to expanding your learning and become one of the ServiceNow Rising Stars.](https://www.servicenow.com/community/rising-star-program/ct-p/rising-star-program)


### Launch your future today
Master the Now Platform through guided learning and hands-on credentials.
[Discover ServiceNow University](https://www.servicenow.com/community/servicenow-university/ct-p/sn-university)
  * [ServiceNow Community](https://www.servicenow.com/community/)
  * [Community Resources](https://www.servicenow.com/community/community-resources/ct-p/community-resources)
  * Community Central


## Community Central
Welcome to the ServiceNow Community! From updates to best practices, Community Central is your hub for all things ServiceNow Community and the ServiceNow AI Platform. Click through the tabs below to familiarize yourself with what the Community has to offer!
![](https://www.servicenow.com/community/s/html/assets/CommCent-april24-marquee.jpeg)
WelcomeWhat’s NewCommunity FAQsYour ImpactLearn ServiceNow EventsDevelopers
### Welcome to the Community
Thanks for including the ServiceNow Community in your journey. Whether you’re new or a seasoned member, you’re a valued part of this vibrant ecosystem.
### Hear from our members
Our ServiceNow Community is a thriving network of vibrant, diverse, and smart problem solvers. Watch to find out what being a member is like!
Video Player is loading.
Play Video
Play
Mute
Current Time 0:00
/
Duration 1:11
Loaded: 13.84%
0:00
Stream Type LIVE
Seek to live, currently behind liveLIVE
Remaining Time -1:11
1x
Playback Rate
Chapters
  * Chapters


Descriptions
  * descriptions off, selected


Captions
  * captions settings, opens captions settings dialog
  * captions off, selected


Audio Track
  * en (Main), selected


Picture-in-PictureFullscreen
This is a modal window.
Beginning of dialog window. Escape will cancel and close the window.
Text ColorWhite Black Red Green Blue Yellow Magenta CyanTransparencyOpaque Semi-Transparent Background ColorBlack White Red Green Blue Yellow Magenta CyanTransparencyOpaque Semi-Transparent Transparent Window ColorBlack White Red Green Blue Yellow Magenta CyanTransparencyTransparent Semi-Transparent Opaque
Font Size 50% 75% 100% 125% 150% 175% 200% 300% 400% Text Edge Style None Raised Depressed Uniform Dropshadow Font Family Proportional Sans-Serif Monospace Sans-Serif Proportional Serif Monospace Serif Casual Script Small Caps
Reset restore all settings to the default valuesDone
Close Modal Dialog
End of dialog window.
Close Modal Dialog
This is a modal window. This modal can be closed by pressing the Escape key or activating the close button.
## The Community is waiting for you
![Grow your career image](https://www.servicenow.com/community/s/html/assets/CommCent-april24-welcome-waiting-grow.jpeg)
###### Grow your career
Sharpen your skills and knowledge to carve out a path to success.
![Meet new people image](https://www.servicenow.com/community/s/html/assets/CommCent-april24-welcome-waiting-meet.jpeg)
###### Meet new people
Build meaningful relationships and become a part of a collaborative network.
![Find accepted solutions image](https://www.servicenow.com/community/s/html/assets/CommCent-april24-welcome-waiting-find.jpeg)
###### Find accepted solutions
Share information in real time with members of our ServiceNow Community.
Start connectingMeet your community
## Live topics
Up-to-the-minute discussions, straight from the community and happening now.
[View All Posts](https://www.servicenow.com/community/forums/recentpostspage/post-type/message)
  * ###  [CSDM 5 Finally!!! Get the CSDM 5 White Paper HERE](https://www.servicenow.com/community/common-service-data-model/csdm-5-finally-get-the-csdm-5-white-paper-here/ta-p/3254967)
by **[scott_lemm](https://www.servicenow.com/community/user/viewprofilepage/user-id/192153) ** [ ![User avatar](https://www.servicenow.com/community/image/serverpage/avatar-name/ProfileAvatar/avatar-theme/candy/avatar-collection/ServiceNow_Avatars/avatar-display-size/profile/version/2?xdesc=1.0) ](https://www.servicenow.com/community/user/viewprofilepage/user-id/192153)
  * ###  [ServiceNow ITOM (Discovery, Event Management & Service Mapping) Solution Architecture Diagram](https://www.servicenow.com/community/itom-articles/servicenow-itom-discovery-event-management-amp-service-mapping/ta-p/3291198)
by **[SAMfluencer786](https://www.servicenow.com/community/user/viewprofilepage/user-id/920614) ** [ ![User avatar](https://www.servicenow.com/community/image/serverpage/avatar-name/ProfileAvatar/avatar-theme/candy/avatar-collection/ServiceNow_Avatars/avatar-display-size/profile/version/2?xdesc=1.0) ](https://www.servicenow.com/community/user/viewprofilepage/user-id/920614)
  * ###  [ServiceNow SAM Solution Architecture Diagram](https://www.servicenow.com/community/sam-articles/servicenow-sam-solution-architecture-diagram/ta-p/3291148)
by **[SAMfluencer786](https://www.servicenow.com/community/user/viewprofilepage/user-id/920614) ** [ ![User avatar](https://www.servicenow.com/community/image/serverpage/avatar-name/ProfileAvatar/avatar-theme/candy/avatar-collection/ServiceNow_Avatars/avatar-display-size/profile/version/2?xdesc=1.0) ](https://www.servicenow.com/community/user/viewprofilepage/user-id/920614)
  * ###  [ServiceNow HAM Solution Architecture Diagram](https://www.servicenow.com/community/ham-articles/servicenow-ham-solution-architecture-diagram/ta-p/3291128)
by **[SAMfluencer786](https://www.servicenow.com/community/user/viewprofilepage/user-id/920614) ** [ ![User avatar](https://www.servicenow.com/community/image/serverpage/avatar-name/ProfileAvatar/avatar-theme/candy/avatar-collection/ServiceNow_Avatars/avatar-display-size/profile/version/2?xdesc=1.0) ](https://www.servicenow.com/community/user/viewprofilepage/user-id/920614)
  * ###  [🚀 ServiceNow Discovery & CMDB Interview Questions and Answers (2025)](https://www.servicenow.com/community/developer-articles/servicenow-discovery-amp-cmdb-interview-questions-and-answers/ta-p/3245373)
by **[Ravi Gaurav](https://www.servicenow.com/community/user/viewprofilepage/user-id/19722) ** [ ![User avatar](https://www.servicenow.com/community/image/serverpage/image-id/379669i10C991037BC44A1E/image-dimensions/150x150/image-coordinates/0%2C1728%2C3456%2C5184?v=v2) ](https://www.servicenow.com/community/user/viewprofilepage/user-id/19722)
  * ###  [Agentic AI: The Evolution of Intelligent Automation in ServiceNow](https://www.servicenow.com/community/now-assist-articles/agentic-ai-the-evolution-of-intelligent-automation-in-servicenow/ta-p/3196959)
by **[anapessan](https://www.servicenow.com/community/user/viewprofilepage/user-id/760175) ** [ ![User avatar](https://www.servicenow.com/community/image/serverpage/avatar-name/ProfileAvatar/avatar-theme/candy/avatar-collection/ServiceNow_Avatars/avatar-display-size/profile/version/2?xdesc=1.0) ](https://www.servicenow.com/community/user/viewprofilepage/user-id/760175)
  * ###  [Congratulations 2025 ServiceNow Community Rising Stars!](https://www.servicenow.com/community/in-other-news/congratulations-2025-servicenow-community-rising-stars/ba-p/3376201)
by **[Sarah G_](https://www.servicenow.com/community/user/viewprofilepage/user-id/424839) ** [ ![User avatar](https://www.servicenow.com/community/s/legacyfs/online/avatars_servicenow/3f79d1b5db8dd010feb1a851ca9619fa.jpg) ](https://www.servicenow.com/community/user/viewprofilepage/user-id/424839)
  * ###  [Cleared CIS-DF (CMDB & CSDM): Exam Experience, Difficulty Level, and Key Learnings](https://www.servicenow.com/community/developer-blog/cleared-cis-df-cmdb-amp-csdm-exam-experience-difficulty-level/ba-p/3450574)
by **[Its_Azar](https://www.servicenow.com/community/user/viewprofilepage/user-id/683708) ** [ ![User avatar](https://www.servicenow.com/community/image/serverpage/image-id/337409i3D79B8934613B237/image-dimensions/150x150/image-coordinates/0%2C0%2C400%2C400?v=v2) ](https://www.servicenow.com/community/user/viewprofilepage/user-id/683708)
  * ###  [CSDM 5 Finally!!! Get the CSDM 5 White Paper HERE](https://www.servicenow.com/community/common-service-data-model/csdm-5-finally-get-the-csdm-5-white-paper-here/ta-p/3254967)
by **[scott_lemm](https://www.servicenow.com/community/user/viewprofilepage/user-id/192153) ** [ ![User avatar](https://www.servicenow.com/community/image/serverpage/avatar-name/ProfileAvatar/avatar-theme/candy/avatar-collection/ServiceNow_Avatars/avatar-display-size/profile/version/2?xdesc=1.0) ](https://www.servicenow.com/community/user/viewprofilepage/user-id/192153)
  * ###  [ServiceNow ITOM (Discovery, Event Management & Service Mapping) Solution Architecture Diagram](https://www.servicenow.com/community/itom-articles/servicenow-itom-discovery-event-management-amp-service-mapping/ta-p/3291198)
by **[SAMfluencer786](https://www.servicenow.com/community/user/viewprofilepage/user-id/920614) ** [ ![User avatar](https://www.servicenow.com/community/image/serverpage/avatar-name/ProfileAvatar/avatar-theme/candy/avatar-collection/ServiceNow_Avatars/avatar-display-size/profile/version/2?xdesc=1.0) ](https://www.servicenow.com/community/user/viewprofilepage/user-id/920614)
  * ###  [ServiceNow SAM Solution Architecture Diagram](https://www.servicenow.com/community/sam-articles/servicenow-sam-solution-architecture-diagram/ta-p/3291148)
by **[SAMfluencer786](https://www.servicenow.com/community/user/viewprofilepage/user-id/920614) ** [ ![User avatar](https://www.servicenow.com/community/image/serverpage/avatar-name/ProfileAvatar/avatar-theme/candy/avatar-collection/ServiceNow_Avatars/avatar-display-size/profile/version/2?xdesc=1.0) ](https://www.servicenow.com/community/user/viewprofilepage/user-id/920614)


Meet your peers
### Meet Cory “CJ” Wesley
With over a decade of experience and over two years as a certified MVP, the co-host of the "CJ and the Duke" podcast CJ Wesley truly knows his way around the ServiceNow ecosystem.
![Meet Cory CJ Wesley](https://www.servicenow.com/community/s/html/assets/CommCent-april24-welcome-meet-cory.jpg)
Meet your peers
### Meet Nia McCash
As part of the University of Toronto Mississauga team, this distinguished MVP played a pivotal role in helping her team win The Knowledge 2023 Devvies App of the Year award.
![Meet Nia McCash Devvies 2024](https://www.servicenow.com/community/s/html/assets/CommCentral-home-Nia-2.png)
Meet your peers
### Meet Chris Helming
Chris brings years of know-how as an MVP, attorney, and ServiceNow developer. They also lead our ServiceNow Pride Connected in Tech Group.
![](https://www.servicenow.com/community/s/html/assets/MicrosoftTeams-image%20\(9\)%201.png)
##  Catch up with the Community
  * [ ![](https://www.servicenow.com/community/image/serverpage/image-id/460042i4D419CF42F281A44/image-size/original?v=v2&px=-1) ](https://www.servicenow.com/community/developer-advocate-blog/zurich-content-archive/ba-p/3340460)
blog
##### [Zurich Content Archive ](https://www.servicenow.com/community/developer-advocate-blog/zurich-content-archive/ba-p/3340460)
We've Made It To the End of the Alphabet - Zurich is HERE! 🇨🇭 That means its also time for your Develo...
[ ![Post author icon](https://www.servicenow.com/community/s/legacyfs/online/avatars_servicenow/809cf35cdb050094d82ffb2439961982.jpg) laurenmcman ](https://www.servicenow.com/community/user/viewprofilepage/user-id/242587)
  * [ ![](https://www.servicenow.com/community/image/serverpage/image-id/468300iD8AB563CEF4559B2/image-size/original?v=v2&px=-1) ](https://www.servicenow.com/community/developer-advocate-blog/stirring-things-up-september-s-community-cafe/ba-p/3373924)
blog
##### [Stirring Things Up: September's Community Cafe ](https://www.servicenow.com/community/developer-advocate-blog/stirring-things-up-september-s-community-cafe/ba-p/3373924)
Welcome to the September Community Cafe! We may be a little late pouring this month...
[ ![Post author icon](https://www.servicenow.com/community/image/serverpage/image-id/482028iDB6656E9F36B872D/image-dimensions/16x16?v=v2) jordancbaron ](https://www.servicenow.com/community/user/viewprofilepage/user-id/603962)
  * [ ![](https://www.servicenow.com/community/image/serverpage/image-id/468155iCDACA58EC92B208A/image-size/original?v=v2&px=-1) ](https://www.servicenow.com/community/content-blogs/your-content-deserves-better-choosing-the-right-format-for-the/ba-p/3373534)
blog
##### [Your Content Deserves Better: Choosing the right format for the max impact ](https://www.servicenow.com/community/content-blogs/your-content-deserves-better-choosing-the-right-format-for-the/ba-p/3373534)
Hi Community! This blo...
[ ![Post author icon](https://www.servicenow.com/community/s/legacyfs/online/avatars_servicenow/79a7e39d1b42fc981e579979b04bcb34.jpg) Earl Duque ](https://www.servicenow.com/community/user/viewprofilepage/user-id/91225)
  * [ ![](https://www.servicenow.com/community/image/serverpage/image-id/341443i6681927DDA2DD63E/image-size/original?v=v2&px=-1) ](https://www.servicenow.com/community/in-other-news/moving-up-the-community-ladder/ba-p/2873641)
blog
##### [Moving up the Community Ladder! ](https://www.servicenow.com/community/in-other-news/moving-up-the-community-ladder/ba-p/2873641)
Welcome to the ServiceNow Community, your gateway to enthusiastic individuals, pass...
[ ![Post author icon](https://www.servicenow.com/community/image/serverpage/image-id/482028iDB6656E9F36B872D/image-dimensions/16x16?v=v2) jordancbaron ](https://www.servicenow.com/community/user/viewprofilepage/user-id/603962)
  * [ ![](https://www.servicenow.com/community/image/serverpage/image-id/463386iD687A80ACD98F398/image-size/original?v=v2&px=-1) ](https://www.servicenow.com/community/training-and-certifications/unlock-your-skills-with-servicenow-university-amp-professor/ba-p/3353797)
blog
##### [Unlock your Skills with ServiceNow University & Professor Idris ](https://www.servicenow.com/community/training-and-certifications/unlock-your-skills-with-servicenow-university-amp-professor/ba-p/3353797)
Meet Professor Idris -...
[ ![Post author icon](https://www.servicenow.com/community/s/legacyfs/online/avatars_servicenow/2b82e0581b0fc9109f20ece7624bcb75.jpg) ServiceNow  ](https://www.servicenow.com/community/user/viewprofilepage/user-id/294016)
  * [ ![](https://www.servicenow.com/community/image/serverpage/image-id/469586i23981A2B677B8BF5/image-size/original?v=v2&px=-1) ](https://www.servicenow.com/community/developer-advocate-blog/the-merged-update-set-july-august-2025-developer-highlights/ba-p/3378947)
blog
##### [The Merged Update Set: July + August 2025 Developer Highlights ](https://www.servicenow.com/community/developer-advocate-blog/the-merged-update-set-july-august-2025-developer-highlights/ba-p/3378947)
Missed the July Update...
[ ![Post author icon](https://www.servicenow.com/community/s/legacyfs/online/avatars_servicenow/7aa4f94f1b4064106531ea89bd4bcba0.jpg) kristymerriam ](https://www.servicenow.com/community/user/viewprofilepage/user-id/204063)
  * [ ![](https://www.servicenow.com/community/image/serverpage/image-id/469626iEE1876529EA3F4EB/image-size/original?v=v2&px=-1) ](https://www.servicenow.com/community/developer-advocate-blog/servicenow-developer-advocates-ama-3-special-guest-sarah-garey/ba-p/3379182)
blog
##### [ServiceNow Developer Advocates AMA #3: Special Guest, Sarah Garey, Community Program Manager ](https://www.servicenow.com/community/developer-advocate-blog/servicenow-developer-advocates-ama-3-special-guest-sarah-garey/ba-p/3379182)
[ ![Post author icon](https://www.servicenow.com/community/s/legacyfs/online/avatars_servicenow/79a7e39d1b42fc981e579979b04bcb34.jpg) Earl Duque ](https://www.servicenow.com/community/user/viewprofilepage/user-id/91225)


## Community FAQs
Your ServiceNow Community compass. Find the answers you need to get started.
✕
![Navigating your Community image](https://cf-images.us-east-1.prod.boltdns.net/v1/static/6062814548001/e820bf9d-edb5-485c-8d0a-4e9d49ecf4fb/0216ea94-f19b-4410-bf56-df2af308318d/1280x720/match/image.jpg)
###### Navigating your Community
Learn to effortlessly navigate our forums to find exactly what you need.
✕
![Community tips and tricks image](https://cf-images.us-east-1.prod.boltdns.net/v1/static/6062814548001/ade663e1-bdc7-412d-872b-267e50091fe6/b042778f-c4e6-4426-b05e-f969daac54f5/1280x720/match/image.jpg)
###### Community tips and tricks
Access comprehensive guides and resources for creating articles, blogs, and more.
✕
![Updating your profiles image](https://cf-images.us-east-1.prod.boltdns.net/v1/static/6062814548001/9f3eb446-71f7-4c67-ba19-175e5cd0170a/babce80a-9eb4-4332-a61a-28f744fd3daa/1280x720/match/image.jpg)
###### Updating your profiles
Learn how your Community and ServiceNow profiles differ, and how to update them.
✕
![Adjust your notifications image](https://cf-images.us-east-1.prod.boltdns.net/v1/static/6062814548001/92b5fa60-521f-40ef-b4eb-dff3a3fd44c7/554eb34a-e928-4c2b-86ef-931b32d774cd/1280x720/match/image.jpg)
###### Adjust your notifications
Stay on top of the ServiceNow Community news and developments you choose.
✕
![Posting content image](https://www.servicenow.com/community/image/serverpage/image-id/347024iE78265C2E95F7CC1/image-size/large?v=v2&px=999)
###### Posting content
Unravel the nuances between content types and learn when or where to utilize them.
✕
![Community code of conduct image](https://cf-images.us-east-1.prod.boltdns.net/v1/static/6062814548001/865fd6f7-f7e1-4679-86a6-ac9aaa79a62c/3eec06e9-1564-4e3e-a82d-50bd4ddeb032/1280x720/match/image.jpg)
###### Community code of conduct
Help us maintain a supportive and inclusive environment for all Community members.
## The ServiceNow Community is changing lives
Familiarize yourself with the diverse stories and opportunities at your fingertips.
![Empower your journey image](https://www.servicenow.com/community/s/html/assets/CommCent-april24-impact-empower.jpeg)
###### Empower your journey
Discover how members met personal goals through ServiceNow University.
[](https://www.servicenow.com/community/servicenow-university/ct-p/sn-university#arc-component-11)
![Meet the experts image](https://www.servicenow.com/community/s/html/assets/CommCent-april24-impact-meet.jpeg)
###### Meet the experts
Get to know our experts, the MVPs and Rising Stars, who can help on your journey.
[](https://www.servicenow.com/community/community-expert-programs/ct-p/community-expert-programs)
![Find perspective image](https://www.servicenow.com/community/s/html/assets/CommCent-april24-impact-find.jpeg)
###### Find perspective
Dive into real-world stories and an array of customer use cases and best practices.
[](https://www.servicenow.com/community/blogs/ct-p/blogs)
## Grow your ServiceNow knowledge
Whether you’re new to the platform or looking to expand your skills we can help.
![ServiceNow University image](https://www.servicenow.com/community/s/html/assets/CommCentral-Learn-31-SNU.png)
###### ServiceNow University
Learn the skills to change your profession, industry, or to manage technology.
[](https://www.servicenow.com/community/servicenow-university/ct-p/sn-university)
![Expand your technical skills image](https://www.servicenow.com/community/s/html/assets/CommCent-april24-learn-expand.jpeg)
###### Expand your technical skills
Discover prescriptive pathways and on-demand classes at Now Learning.
[](https://nowlearning.servicenow.com/lxp/en/pages/servicenow)
![Get ServiceNow certified image](https://www.servicenow.com/community/s/html/assets/CommCent-april24-learn-certified.jpeg)
###### Get ServiceNow certified
Broaden your technical skills and expertise with our dedicated certifications.
[](https://www.servicenow.com/community/training-and-certifications/ct-p/training-and-certifications)
![Customer Onboarding image](https://www.servicenow.com/community/s/html/assets/CommCent-april24-learn-customer.jpeg)
###### Customer Onboarding
Explore resources for a smooth and seamless onboarding process.
[](https://www.servicenow.com/community/new-customer-onboarding/ct-p/new-customer-onboarding)
![Build your reputation  image](https://www.servicenow.com/community/s/html/assets/CommCent-april24-learn-build.jpeg)
###### Build your reputation
Become recognized for your expertise by participating in our Expert programs.
[](https://www.servicenow.com/community/community-expert-programs/ct-p/community-expert-programs)
![Explore our product hubs image](https://www.servicenow.com/community/s/html/assets/CommCent-april24-learn-explore.jpeg)
###### Explore our product hubs
Check out product specific solutions and resource collections.
[](https://www.servicenow.com/community/products/ct-p/product-discussions)
## Events
Looking to learn, share, or simply belong? Our events offer something for everyone.
![ Developer Meetups image](https://www.servicenow.com/community/s/html/assets/CommCentral-Events-meetups-2.png)
######  Developer Meetups
Attend casual get-togethers to share insights with developers in your area.
[](https://www.meetup.com/pro/servicenowdevprogram/)
![ServiceNow User Groups image](https://www.servicenow.com/community/s/html/assets/CommCentral-Events-SNUGS.jpg)
###### ServiceNow User Groups
Chat and engage with others on specific topics either in your neighborhood or online.
[](https://www.servicenow.com/community/servicenow-user-groups-snugs/ct-p/servicenow-user-groups-snugs)
![Live on ServiceNow image](https://www.servicenow.com/community/s/html/assets/CommCentral-Events-LOSN.jpg)
###### Live on ServiceNow
Attend real-time and on-demand events with fellow ServiceNow enthusiasts.
[](https://www.servicenow.com/community/live-on-servicenow/ct-p/live-on-servicenow-events)
![ServiceNow World Forums image](https://www.servicenow.com/community/s/html/assets/CommCentral-Events-Tech.jpg)
###### ServiceNow World Forums
Explore the world. Master the ServiceNow AI Platform. Connect with the global Community.
[](https://www.servicenow.com/events/world-forum.html)
![CreatorCon at Knowledge image](https://www.servicenow.com/community/s/html/assets/CommCentral-Events-CreatorCon.jpg)
###### CreatorCon at Knowledge
Join experts and beginners alike at this specialized interactive conference.
[](https://www.servicenow.com/community/creatorcon/ct-p/creatorcon)
![Special interest groups image](https://www.servicenow.com/community/s/html/assets/CommCentral-Events-SIGs.jpg)
###### Special interest groups
Interact with communities tailored to your industry, role, or associations
[](https://www.servicenow.com/community/special-interest-groups/ct-p/ServiceNow_Interest_Groups)
## Developers
Discover our forum, get to know the Developer Advocates, and uncover our technical initiatives.
![Engage with developers image](https://www.servicenow.com/community/s/html/assets/CommCentral-Developer-1.jpg)
###### Engage with developers
Stay on top of the latest information with blogs, videos, and podcasts.
[](https://www.servicenow.com/community/developer/ct-p/Developer)
![Celebrate The Devvies image](https://www.servicenow.com/community/s/html/assets/CommCentral-Developer-2.jpg)
###### Celebrate The Devvies
Applaud innovation with The Devvies, ServiceNow’s App of the Year contest.
[](https://www.servicenow.com/community/the-devvies-app-of-the-year/ct-p/the-devvies)
![Meet the advocates image](https://www.servicenow.com/community/s/html/assets/CommCentral-Developer-3.jpg)
###### Meet the advocates
Stay in the loop about the latest updates and features with our developer advocates.
[](https://www.servicenow.com/community/developer-advocate-blog/bg-p/developer-advocate-blog)
[Options](https://www.servicenow.com/community/community-central/ct-p/community-central "Show option menu")
  * Subscribe


## Activity in Community Central
[Ask a Question](https://www.servicenow.com/community/s/plugins/common/feature/oidcss/sso_login_redirect/providerid/default?referer=https%3A%2F%2Fwww.servicenow.com%2Fcommunity%2Fcommunity-central%2Fct-p%2Fcommunity-central)
Question status: Content Type  Questions  Articles  Events  Blogs  Question status: Question Status Solved Unsolved Unreplied
Sorted by: Recently posted or commented Date originally posted Most viewed Most commented Most liked
###  Featured [About the Digital Services Forum](https://www.servicenow.com/community/digital-services-forum/about-the-digital-services-forum/ba-p/2437605 "About the Digital Services Forum")
The Digital Services Forum was founded in June 2018 and is run by ServiceNow's Enterprise Architecture team. We meet bi-weekly to share findings and best practices in leveraging the ServiceNow platform to support service design, service delivery, and...
  * blog


  * **16679** Views
  * **10** replies
  * **35** helpfuls


[![John Spirko](https://www.servicenow.com/community/image/serverpage/avatar-name/ProfileAvatar/avatar-theme/candy/avatar-collection/ServiceNow_Avatars/avatar-display-size/inline/version/2?xdesc=1.0)](https://www.servicenow.com/community/user/viewprofilepage/user-id/73007 "View profile") ** by  [ John Spirko ](https://www.servicenow.com/community/user/viewprofilepage/user-id/73007 "View profile") ** • _ServiceNow Employee_
01-09-2023 8:14:52 AM
###  Featured [Important Update on Legacy Reporting and Analytics with Australia Release](https://www.servicenow.com/community/performance-analytics-blog/important-update-on-legacy-reporting-and-analytics-with/ba-p/3396343 "Important Update on Legacy Reporting and Analytics with Australia Release")
Subject: Important Update on Legacy Reporting and Analytics with Australia Release Dear Valued Customers, We would like to address some concerns and provide clarity regarding the upcoming upgrade to the Australia release and its impact on your report...
  * blog
  * Australia
  * Dashboard
  * Migration
  * Performance Analytics
  * Platform Analytics
  * platform analytics migration
  * Upgrades


  * **10455** Views
  * **14** replies
  * **28** helpfuls


[![Dan_Kane](https://www.servicenow.com/community/s/legacyfs/online/avatars_servicenow/f7ca6dde1be7d050305fea89bd4bcb36.jpg)](https://www.servicenow.com/community/user/viewprofilepage/user-id/57338 "View profile") ** by  [ Dan_Kane ](https://www.servicenow.com/community/user/viewprofilepage/user-id/57338 "View profile") ** • _ServiceNow Employee_
10-02-2025 9:55:16 AM
###  Featured [The Governance Topology V.1](https://www.servicenow.com/community/in-other-news/the-governance-topology-v-1/ba-p/3245559 "The Governance Topology V.1")
The Governance Topology A Fundamental Framework for Mapping out Governance Table of Contents 1 - Introduction 2 - Disclaimer 3 - Why Introduce The Governance Topology 4 - What is The Governance Topology 4.1 - The Governance Onion 5 - The Referen...
  * blog


  * **5826** Views
  * **6** replies
  * **27** helpfuls


[![JakobAnkerN](https://www.servicenow.com/community/image/serverpage/image-id/222360iC75B4C92566AEAD3/image-dimensions/16x16?v=v2)](https://www.servicenow.com/community/user/viewprofilepage/user-id/202847 "View profile") ** by  [ JakobAnkerN ](https://www.servicenow.com/community/user/viewprofilepage/user-id/202847 "View profile") ** • _ServiceNow Employee_
04-26-2025 1:17:09 PM
###  Featured [Volunteer Opportunity: Introducing ServiceNow University Campus Leaders](https://www.servicenow.com/community/in-other-news/volunteer-opportunity-introducing-servicenow-university-campus/ba-p/3480039 "Volunteer Opportunity: Introducing ServiceNow University Campus Leaders")
Introducing ServiceNow University Campus Leaders Meet the Inaugural Class Shaping the Future of Tech Talent These students are bringing ServiceNow skills to their university campuses, and they could use your help. We're excited to introduce ...
  * blog


  * **1300** Views
  * **3** replies
  * **9** helpfuls


[![treyhem](https://www.servicenow.com/community/image/serverpage/image-id/324502iA32F7CCD977F544F/image-dimensions/16x16?v=v2)](https://www.servicenow.com/community/user/viewprofilepage/user-id/259643 "View profile") ** by  [ treyhem ](https://www.servicenow.com/community/user/viewprofilepage/user-id/259643 "View profile") ** • _ServiceNow Employee_
3 weeks ago
###  Featured [Introducing Knowledge Center with Advanced Editing, powered by Now Assist](https://www.servicenow.com/community/knowledge-management-articles/introducing-knowledge-center-with-advanced-editing-powered-by/ta-p/3447858 "Introducing Knowledge Center with Advanced Editing, powered by Now Assist")
Introducing Knowledge Center Smarter Knowledge Management with Now Assist AI and Advanced Editing Knowledge has never mattered more—especially with AI depending on accurate, fresh, well-structured content. Knowledge Center for ServiceNow's Knowledge...
  * Article
  * AI Search
  * Best Practices
  * KCS
  * Now Assist


  * **12382** Views
  * **24** replies
  * **30** helpfuls


[![rob_martoncik](https://www.servicenow.com/community/s/legacyfs/online/avatars_servicenow/addf1638db0568104aa5d9d96896194a.jpg)](https://www.servicenow.com/community/user/viewprofilepage/user-id/391928 "View profile") ** by  [ rob_martoncik ](https://www.servicenow.com/community/user/viewprofilepage/user-id/391928 "View profile") ** • _ServiceNow Employee_
12-11-2025 1:55:08 PM
###  [ServiceNow to Azure DevOps Integration Using Oauth 2.](https://www.servicenow.com/community/developer-forum/servicenow-to-azure-devops-integration-using-oauth-2/td-p/3498423 "ServiceNow to Azure DevOps Integration Using Oauth 2.")
ServiceNow to Azure DevOps Integration Using REST APIsI have tried this and yet getting 203 erorr
  * Question


  * **1** Views
[
  * **Be the first to reply** ](https://www.servicenow.com/community/developer-forum/servicenow-to-azure-devops-integration-using-oauth-2/td-p/3498423)
  * **0** helpfuls


[![Prateek1](https://www.servicenow.com/community/image/serverpage/avatar-name/ProfileAvatar/avatar-theme/candy/avatar-collection/ServiceNow_Avatars/avatar-display-size/inline/version/2?xdesc=1.0)](https://www.servicenow.com/community/user/viewprofilepage/user-id/86213 "View profile") ** by  [ Prateek1 ](https://www.servicenow.com/community/user/viewprofilepage/user-id/86213 "View profile") ** • _Tera Contributor_
4m ago
###  [Zoom Meetings for Digital Services Forum](https://www.servicenow.com/community/digital-services-forum/zoom-meetings-for-digital-services-forum/td-p/3468051 "Zoom Meetings for Digital Services Forum")
Hi Everyone,Is there a new list of Zoom meetings for the Digital Services forum to sign up for (for 2026)? It seems like the last few Zoom meetings on my calendar never had a host to start the meeting (I had one on my calendar for 1/15/2026, waited a...
  * Question


  * **418** Views
  * **3** replies
  * **2** helpfuls


[![Angel Brady](https://www.servicenow.com/community/image/serverpage/avatar-name/ProfileAvatar/avatar-theme/candy/avatar-collection/ServiceNow_Avatars/avatar-display-size/inline/version/2?xdesc=1.0)](https://www.servicenow.com/community/user/viewprofilepage/user-id/397976 "View profile") ** by  [ Angel Brady ](https://www.servicenow.com/community/user/viewprofilepage/user-id/397976 "View profile") ** • _Tera Contributor_
01-15-2026 8:43:43 AM
###  [Martin Virag MVP 2026: My Community Power](https://www.servicenow.com/community/in-other-news/martin-virag-mvp-2026-my-community-power/ba-p/3498417 "Martin Virag MVP 2026: My Community Power")
Hi everyone, I’m Martin Virag, a first‑time ServiceNow MVP. I started my ServiceNow career at the end of 2019 in Hungary, mainly focusing on ITOM and presales and implementations. Over time, my role gradually evolved toward more architectural respo...
  * blog


  * **1** Views
[
  * **Be the first to reply** ](https://www.servicenow.com/community/in-other-news/martin-virag-mvp-2026-my-community-power/ba-p/3498417)
  * **0** helpfuls


[![martinvirag](https://www.servicenow.com/community/image/serverpage/avatar-name/ProfileAvatar/avatar-theme/candy/avatar-collection/ServiceNow_Avatars/avatar-display-size/inline/version/2?xdesc=1.0)](https://www.servicenow.com/community/user/viewprofilepage/user-id/224259 "View profile") ** by  [ martinvirag ](https://www.servicenow.com/community/user/viewprofilepage/user-id/224259 "View profile") ** • _Mega Sage_
8m ago
###  [Question for CMDB](https://www.servicenow.com/community/developer-forum/question-for-cmdb/td-p/3498412 "Question for CMDB")
HelloI have these 2 questions from practice exam for CIS- Data foundation. How does a CMDB Administrator use the ServiceNow Platform to ensure the data quality associated with Cls in the CMDB?A. Data Quality Business RuleB. CMDB WorkspaceC. Data Qual...
  * Question


  * **42** Views
  * **3** replies
  * **0** helpfuls


[![SnowDevOps](https://www.servicenow.com/community/image/serverpage/avatar-name/ProfileAvatar/avatar-theme/candy/avatar-collection/ServiceNow_Avatars/avatar-display-size/inline/version/2?xdesc=1.0)](https://www.servicenow.com/community/user/viewprofilepage/user-id/697244 "View profile") ** by  [ SnowDevOps ](https://www.servicenow.com/community/user/viewprofilepage/user-id/697244 "View profile") ** • _Giga Guru_
19m ago
###  [Service now cad exam](https://www.servicenow.com/community/community-central-forum/service-now-cad-exam/td-p/3498105 "Service now cad exam")
Wanted to ask do you have to take the fundamentals course before you are able to take the service now Cad exam, and if you do , do they give you a discount voucher upon completion?
  * Question


  * **134** Views
  * **3** replies
  * **0** helpfuls


[![CECILJ](https://www.servicenow.com/community/image/serverpage/avatar-name/ProfileAvatar/avatar-theme/candy/avatar-collection/ServiceNow_Avatars/avatar-display-size/inline/version/2?xdesc=1.0)](https://www.servicenow.com/community/user/viewprofilepage/user-id/1066906 "View profile") ** by  [ CECILJ ](https://www.servicenow.com/community/user/viewprofilepage/user-id/1066906 "View profile") ** • _Kilo Explorer_
13 hours ago
###  [CWM - Why is the “Assigned to” filter unavailable in the Kanban view, unlike in VTB?](https://www.servicenow.com/community/spm-forum/cwm-why-is-the-assigned-to-filter-unavailable-in-the-kanban-view/td-p/3497970 "CWM - Why is the “Assigned to” filter unavailable in the Kanban view, unlike in VTB?")
Collaborative Work Management As we are transitioning from Agile Development 2.0 to Collaborative Work Management, I am trying to understand how we can work with the new solution on a daily basis.Unfortunately, one significant functionality appears t...
  * Question
  * Service Portfolio Management


  * **72** Views
  * **1** replies
  * **0** helpfuls


[![Joanna Węgrzyn](https://www.servicenow.com/community/image/serverpage/image-id/503787i06AE41BE51118581/image-dimensions/16x16?v=v2)](https://www.servicenow.com/community/user/viewprofilepage/user-id/11308 "View profile") ** by  [ Joanna Węgrzyn ](https://www.servicenow.com/community/user/viewprofilepage/user-id/11308 "View profile") ** • _Tera Contributor_
16 hours ago
###  [SLA](https://www.servicenow.com/community/community-central-forum/sla/td-p/3497997 "SLA")
Are there BP for SLAs?
  * Question


  * **112** Views
  * **4** replies
  * **0** helpfuls


[![JustinaG](https://www.servicenow.com/community/image/serverpage/avatar-name/ProfileAvatar/avatar-theme/candy/avatar-collection/ServiceNow_Avatars/avatar-display-size/inline/version/2?xdesc=1.0)](https://www.servicenow.com/community/user/viewprofilepage/user-id/1066625 "View profile") ** by  [ JustinaG ](https://www.servicenow.com/community/user/viewprofilepage/user-id/1066625 "View profile") ** • _Kilo Contributor_
15 hours ago
###  [Dashboard usage metrics](https://www.servicenow.com/community/developer-forum/dashboard-usage-metrics/td-p/3498040 "Dashboard usage metrics")
Is there a way to see how many people are using a dashboard under platform-analytics-workspace/dashboards?
  * Question


  * **129** Views
  * **2** replies
  * **1** helpfuls


[![Michele O_Dell](https://www.servicenow.com/community/image/serverpage/avatar-name/ProfileAvatar/avatar-theme/candy/avatar-collection/ServiceNow_Avatars/avatar-display-size/inline/version/2?xdesc=1.0)](https://www.servicenow.com/community/user/viewprofilepage/user-id/372439 "View profile") ** by  [ Michele O_Dell ](https://www.servicenow.com/community/user/viewprofilepage/user-id/372439 "View profile") ** • _Tera Contributor_
14 hours ago
###  [Is there a way to differentiate if a tag is created on VTB or form?](https://www.servicenow.com/community/platform-analytics-forum/is-there-a-way-to-differentiate-if-a-tag-is-created-on-vtb-or/td-p/3498371 "Is there a way to differentiate if a tag is created on VTB or form?")
We have an issue when a label is created on VTB it automatically shared by everyone instead of me, we raised it with servicenow and they said we have to customise for this to work and I am struggling to find options how we can do it? have someone imp...
  * Question


  * **65** Views
  * **1** replies
  * **0** helpfuls


[![Anvesh](https://www.servicenow.com/community/image/serverpage/avatar-name/ProfileAvatar/avatar-theme/candy/avatar-collection/ServiceNow_Avatars/avatar-display-size/inline/version/2?xdesc=1.0)](https://www.servicenow.com/community/user/viewprofilepage/user-id/92849 "View profile") ** by  [ Anvesh ](https://www.servicenow.com/community/user/viewprofilepage/user-id/92849 "View profile") ** • _Tera Contributor_
an hour ago
###  [How to add a new widget on serviceNow Operation Workspace landing page](https://www.servicenow.com/community/service-operations-workspace/how-to-add-a-new-widget-on-servicenow-operation-workspace/td-p/3498339 "How to add a new widget on serviceNow Operation Workspace landing page")
  * Question


  * **208** Views
  * **4** replies
  * **0** helpfuls


[![Adetunji Olayem](https://www.servicenow.com/community/image/serverpage/avatar-name/ProfileAvatar/avatar-theme/candy/avatar-collection/ServiceNow_Avatars/avatar-display-size/inline/version/2?xdesc=1.0)](https://www.servicenow.com/community/user/viewprofilepage/user-id/418284 "View profile") ** by  [ Adetunji Olayem ](https://www.servicenow.com/community/user/viewprofilepage/user-id/418284 "View profile") ** • _Tera Contributor_
2 hours ago
###  [Report: Total number of tickets moved.](https://www.servicenow.com/community/itsm-forum/report-total-number-of-tickets-moved/td-p/3498198 "Report: Total number of tickets moved.")
Customer asked the following question: "It is possible to create a report that show the count of the total number of tickets I have moved.?". My interpretation of the question is: "For example, if the 'ABC' group receives 5 new incidents and then the...
  * Question


  * **53** Views
  * **1** replies
  * **0** helpfuls


[![FabioV](https://www.servicenow.com/community/image/serverpage/avatar-name/ProfileAvatar/avatar-theme/candy/avatar-collection/ServiceNow_Avatars/avatar-display-size/inline/version/2?xdesc=1.0)](https://www.servicenow.com/community/user/viewprofilepage/user-id/885265 "View profile") ** by  [ FabioV ](https://www.servicenow.com/community/user/viewprofilepage/user-id/885265 "View profile") ** • _Kilo Contributor_
10 hours ago
###  [Variable value show based on order](https://www.servicenow.com/community/platform-analytics-forum/variable-value-show-based-on-order/td-p/3498337 "Variable value show based on order")
I have a requirement to display records from a custom table in a specific sequence (based on defined order) instead of the default alphabetical order in a type of lookup select box variable.Please help with the appropriate approach to achieve this. T...
  * Question


  * **285** Views
  * **6** replies
  * **0** helpfuls


[![Ramjee](https://www.servicenow.com/community/image/serverpage/image-id/372934iC415BD5E905D889F/image-dimensions/16x16?v=v2)](https://www.servicenow.com/community/user/viewprofilepage/user-id/62414 "View profile") ** by  [ Ramjee ](https://www.servicenow.com/community/user/viewprofilepage/user-id/62414 "View profile") ** • _Tera Expert_
3 hours ago
###  [CMDB Discovery credentials](https://www.servicenow.com/community/itom-forum/cmdb-discovery-credentials/td-p/3498208 "CMDB Discovery credentials")
Hello, i am getting below error when i am testing of credentials in discovery, i cross check the ip address
  * Question
  * Discovery


  * **202** Views
  * **2** replies
  * **0** helpfuls


[![sandhyaBatc](https://www.servicenow.com/community/image/serverpage/avatar-name/Upgradekit-cover-zurich/avatar-theme/candy/avatar-collection/ServiceNow_Avatars/avatar-display-size/inline/version/2?xdesc=1.0)](https://www.servicenow.com/community/user/viewprofilepage/user-id/1020442 "View profile") ** by  [ sandhyaBatc ](https://www.servicenow.com/community/user/viewprofilepage/user-id/1020442 "View profile") ** • _Tera Contributor_
9 hours ago
###  [Why ITIL admin role user not able to see the Incident list?](https://www.servicenow.com/community/incident-management-forum/why-itil-admin-role-user-not-able-to-see-the-incident-list/td-p/3495480 "Why ITIL admin role user not able to see the Incident list?")
Since his level is higher than ITIL, should he automatically have access, or does he also need the ITIL and ITIL admin roles?
  * Question


  * **360** Views
  * **18** replies
  * **0** helpfuls


[![KM SN](https://www.servicenow.com/community/image/serverpage/avatar-name/ProfileAvatar/avatar-theme/candy/avatar-collection/ServiceNow_Avatars/avatar-display-size/inline/version/2?xdesc=1.0)](https://www.servicenow.com/community/user/viewprofilepage/user-id/174908 "View profile") ** by  [ KM SN ](https://www.servicenow.com/community/user/viewprofilepage/user-id/174908 "View profile") ** • _Tera Expert_
Tuesday
###  [variable editor is not visible on approval form](https://www.servicenow.com/community/developer-forum/variable-editor-is-not-visible-on-approval-form/td-p/3497160 "variable editor is not visible on approval form")
Hi,I am working on a requirement where I need to display the Variable Editor on the approval form. When I open the RITM, the Variable Editor is visible and all variables are displayed correctly. However, it does not appear on the approval form.I have...
  * Question


  * **353** Views
  * **7** replies
  * **0** helpfuls


[![zee15](https://www.servicenow.com/community/image/serverpage/avatar-name/ProfileAvatar/avatar-theme/candy/avatar-collection/ServiceNow_Avatars/avatar-display-size/inline/version/2?xdesc=1.0)](https://www.servicenow.com/community/user/viewprofilepage/user-id/561946 "View profile") ** by  [ zee15 ](https://www.servicenow.com/community/user/viewprofilepage/user-id/561946 "View profile") ** • _Tera Contributor_
yesterday
[View More](javascript:;)
[Ask a Question](https://www.servicenow.com/community/s/plugins/common/feature/oidcss/sso_login_redirect/providerid/default?referer=https%3A%2F%2Fwww.servicenow.com%2Fcommunity%2Fcommunity-central%2Fct-p%2Fcommunity-central)
Contents
  * [Community Central forum](https://www.servicenow.com/community/community-central-forum/bd-p/community-central-forum)
  * [Community Central articles](https://www.servicenow.com/community/community-central-articles/tkb-p/community-central-articles)
  * [Community Central blog](https://www.servicenow.com/community/community-central-blog/bg-p/community-central-blogs)
  * [Community Central events](https://www.servicenow.com/community/community-central-events/eb-p/community-central-events)


Top Helpful Authors
User |  Count
---|---
[ ![its_SumitNow](https://www.servicenow.com/community/image/serverpage/avatar-name/ProfileAvatar/avatar-theme/candy/avatar-collection/ServiceNow_Avatars/avatar-display-size/message/version/2?xdesc=1.0) its_SumitNow ](https://www.servicenow.com/community/user/viewprofilepage/user-id/940840) |  15
[ ![Suggy](https://www.servicenow.com/community/image/serverpage/avatar-name/ProfileAvatar/avatar-theme/candy/avatar-collection/ServiceNow_Avatars/avatar-display-size/message/version/2?xdesc=1.0) Suggy ](https://www.servicenow.com/community/user/viewprofilepage/user-id/239192) |  3
[ ![Tanushree Maiti](https://www.servicenow.com/community/image/serverpage/avatar-name/ProfileAvatar/avatar-theme/candy/avatar-collection/ServiceNow_Avatars/avatar-display-size/message/version/2?xdesc=1.0) Tanushree Maiti ](https://www.servicenow.com/community/user/viewprofilepage/user-id/287542) |  3
[ ![Ivan Betev](https://www.servicenow.com/community/image/serverpage/image-id/496641i4654AA052074B1CF/image-dimensions/40x40?v=v2) Ivan Betev ![Mega Sage](https://www.servicenow.com/community/s/html/rank_icons/mvp-rank.svg) ](https://www.servicenow.com/community/user/viewprofilepage/user-id/295281) |  2
[ ![SaaniyaC](https://www.servicenow.com/community/image/serverpage/avatar-name/ProfileAvatar/avatar-theme/candy/avatar-collection/ServiceNow_Avatars/avatar-display-size/message/version/2?xdesc=1.0) SaaniyaC ![ServiceNow Employee](https://www.servicenow.com/community/s/html/rank_icons/servicenow-employee.svg) ](https://www.servicenow.com/community/user/viewprofilepage/user-id/797564) |  2
[View all](https://www.servicenow.com/community/forums/kudosleaderboardpage/category-id/community-central/timerange/one_month/page/1/tab/authors)
###  ![ServiceNow](https://www.servicenow.com/content/dam/servicenow-assets/public/en-us/images/global-nav/images/logo/1024-up.svg)The world works with ServiceNow™
[](https://twitter.com/servicenow)[](https://www.youtube.com/user/servicenowinc)[](https://www.linkedin.com/company/servicenow)[](https://www.facebook.com/servicenow)[](https://www.instagram.com/servicenow/)[](https://www.tiktok.com/@servicenow)
  * United States - Global
Americas
    * [United States - Global](https://www.servicenow.com/community/community-central/ct-p/community-central?profile.language=en)
    * [Brasil - Português](https://www.servicenow.com/community/community-central/ct-p/community-central?profile.language=pt-br)
Asia, Pacific, and Japan
    * [日本 - 日本語](https://www.servicenow.com/community/community-central/ct-p/community-central?profile.language=ja)
    * [한국 - 한국어](https://www.servicenow.com/community/community-central/ct-p/community-central?profile.language=ko)
Europe, Middle East, and Africa
    * [United Kingdom - English](https://www.servicenow.com/community/community-central/ct-p/community-central?profile.language=en-gb)
    * [DACH - Deutsch](https://www.servicenow.com/community/community-central/ct-p/community-central?profile.language=de)
    * [France - Français](https://www.servicenow.com/community/community-central/ct-p/community-central?profile.language=fr)
    * [Nederland - Nederlands](https://www.servicenow.com/community/community-central/ct-p/community-central?profile.language=nl)
    * [España - Español](https://www.servicenow.com/community/community-central/ct-p/community-central?profile.language=es)
    * [Italia - Italiano](https://www.servicenow.com/community/community-central/ct-p/community-central?profile.language=it)
  * [Site terms](https://www.servicenow.com/terms-of-use.html)
  * [GDPR](https://www.servicenow.com/company/trust/privacy/gdpr.html)
  * [Privacy statement](https://www.servicenow.com/privacy-statement.html)
  * [Your privacy choices](https://www.servicenow.com/privacy-preferences.html)
  * [Cookie policy](https://www.servicenow.com/cookie-policy.html)
  * [Cookie preferences](https://www.servicenow.com/community/community-central/ct-p/community-central)
  * [Sitemap](https://www.servicenow.com/sitemap.html)
  * [Business continuity](https://www.servicenow.com/content/dam/servicenow-assets/public/en-us/doc-type/public-document/servicenow-business-continuity-faq.pdf)
  * [Accessibility](https://www.servicenow.com/accessibility-statement.html)
  * ©️ 2026 ServiceNow. All rights reserved.


We use cookies on this site to improve your browsing experience, analyze individualized usage and website traffic, tailor content to your preferences, and make your interactions with our website more meaningful. To learn more about the cookies we use and how you can change your preferences, please read our [Cookie Policy](https://www.servicenow.com/cookie-policy.html) and visit our Cookie Preference Manager. By clicking “Accept and Proceed,” closing this banner or continuing to browse this site, you consent to the use of cookies.
Accept and Proceed
![](https://id.rlcdn.com/464526.gif)![](https://cdn.bizible.com/ipv?_biz_r=&_biz_h=800054037&_biz_u=c8cd2b62188748f19023a5c5b22cefc0&_biz_l=https%3A%2F%2Fwww.servicenow.com%2Faccessibility-statement.html&_biz_t=1772177237854&_biz_i=Accessibility%20Statement%20-%20ServiceNow&_biz_n=10&rnd=184033&cdn_o=a&_biz_z=1772177237958)![](https://cdn.bizible.com/ipv?_biz_r=&_biz_h=800054037&_biz_u=c8cd2b62188748f19023a5c5b22cefc0&_biz_l=https%3A%2F%2Fwww.servicenow.com%2Fcommunity%2Fcommunity-central%2Fct-p%2Fcommunity-central&_biz_t=1772177237957&_biz_i=%0A%09Community%20Central%20-%20ServiceNow%20Community%0A&_biz_n=11&rnd=882802&cdn_o=a&_biz_z=1772177237959)![](https://pt.ispot.tv/v2/TC-8010-2.gif?app=web&type=Visit)
