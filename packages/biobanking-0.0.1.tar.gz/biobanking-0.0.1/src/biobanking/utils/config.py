import os 


class AllofUs:
    def __init__(self, home_dir=""):
        self.bucket = os.getenv("WORKSPACE_BUCKET")
        self.cdr = os.environ["WORKSPACE_CDR"]
        self.google_project = os.getenv("GOOGLE_PROJECT")
        self.home_dir = home_dir

