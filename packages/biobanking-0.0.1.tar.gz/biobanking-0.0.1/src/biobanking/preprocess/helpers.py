import numpy as np
import pandas as pd

def remove_outliers_iqr_helper(df, column, multiplier=5):
    """
    Remove outliers from a specified column in a pandas DataFrame using the IQR method.
    """
    value = np.log1p(df[column].astype(float))
    Q1 = value.quantile(0.25)
    Q3 = value.quantile(0.75)
    IQR = Q3 - Q1
    lower_bound = Q1 - multiplier * IQR
    upper_bound = Q3 + multiplier * IQR
    return np.where(value.between(lower_bound, upper_bound), df[column], pd.NA)

def remove_outliers_iqr(df, col="median_value", multiplier=5):
    df =  df.copy()
    df = df[df[col] >= 0]
    df[col] = remove_outliers_iqr_helper(df, col, multiplier)
    return df.dropna(subset=[col])
