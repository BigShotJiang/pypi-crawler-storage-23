"""Módulo ComexStat — dados de exportação/importação (MDIC/SECEX)."""

from agrobr.comexstat.api import exportacao

__all__ = ["exportacao"]
