"""Sub-modulo CONAB Serie Historica — dados historicos de safras."""

from agrobr.conab.serie_historica.api import produtos_disponiveis, serie_historica

__all__ = ["serie_historica", "produtos_disponiveis"]
