# sage_setup: distribution = sagemath-tachyon
