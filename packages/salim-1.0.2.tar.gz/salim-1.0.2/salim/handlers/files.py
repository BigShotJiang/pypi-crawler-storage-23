"""
File system handlers — browse, read, write, transfer, archive, search.
"""

from __future__ import annotations

import io
import os
import shutil
import stat
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Optional

import aiofiles
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from salim.auth import require_auth
from salim.utils import bytes_to_human, safe_read, run_shell_async


class FileHandlers:

    # ── /ls ──────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_ls(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        List directory contents with size, perms, date.
        /ls [path] [-a] [-s] (a=show hidden, s=sort by size)
        """
        args = list(ctx.args or [])
        show_hidden = "-a" in args
        sort_size   = "-s" in args
        args = [a for a in args if not a.startswith("-")]
        path_str = " ".join(args) if args else self._cwd
        path = Path(path_str).expanduser().resolve()

        if not path.exists():
            await update.effective_message.reply_text(f"❌ Path not found: `{path}`", parse_mode="Markdown")
            return
        if not path.is_dir():
            # If it's a file, show info
            ctx.args = [str(path)]
            await self.cmd_stat(update, ctx)
            return

        try:
            entries = list(path.iterdir())
        except PermissionError:
            await update.effective_message.reply_text("❌ Permission denied.")
            return

        if not show_hidden:
            entries = [e for e in entries if not e.name.startswith(".")]

        dirs  = sorted([e for e in entries if e.is_dir()],  key=lambda x: x.name)
        files = sorted([e for e in entries if e.is_file()], key=lambda x: (-x.stat().st_size if sort_size else x.name))

        lines = []
        # Directories
        for d in dirs[:50]:
            try:
                n_items = sum(1 for _ in d.iterdir())
                lines.append(f"📁 `{d.name}/` ({n_items} items)")
            except Exception:
                lines.append(f"📁 `{d.name}/`")

        # Files
        for f in files[:50]:
            try:
                st  = f.stat()
                mod = datetime.fromtimestamp(st.st_mtime).strftime("%m-%d %H:%M")
                lines.append(f"📄 `{f.name}` {bytes_to_human(st.st_size)} {mod}")
            except Exception:
                lines.append(f"📄 `{f.name}`")

        total = len(dirs) + len(files)
        header = f"📂 *{path}*\n_{total} items{', ' + str(len(dirs)) + ' dirs' if dirs else ''}_\n\n"
        content = "\n".join(lines) or "_Empty directory_"

        # Pagination if huge
        if len(content) > 3000:
            content = content[:3000] + f"\n\n_...{total - 100} more items_"

        await update.effective_message.reply_text(header + content, parse_mode="Markdown")

    # ── /cd ──────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_cd(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            path = str(Path.home())
        else:
            path = " ".join(ctx.args)

        resolved = Path(path).expanduser().resolve()
        if not resolved.is_dir():
            await update.effective_message.reply_text(f"❌ Not a directory: `{resolved}`", parse_mode="Markdown")
            return
        self._cwd = str(resolved)
        # Quick ls
        try:
            count = sum(1 for _ in resolved.iterdir())
        except Exception:
            count = 0
        await update.effective_message.reply_text(
            f"📂 Now in: `{resolved}` ({count} items)",
            parse_mode="Markdown"
        )

    # ── /pwd ─────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_pwd(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        await update.effective_message.reply_text(f"📂 `{self._cwd}`", parse_mode="Markdown")

    # ── /cat ─────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_cat(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text("Usage: `/cat <file>`", parse_mode="Markdown")
            return
        path_str = " ".join(ctx.args)
        path = Path(path_str).expanduser() if path_str.startswith(("/", "~")) else Path(self._cwd) / path_str

        if not path.exists():
            await update.effective_message.reply_text(f"❌ File not found: `{path}`", parse_mode="Markdown")
            return

        content, is_binary = safe_read(path)
        if is_binary:
            await update.effective_message.reply_text(f"⚠️ Binary file: {content}\nUse `/download {path}` to get it.", parse_mode="Markdown")
            return

        # Detect language for syntax hint
        ext = path.suffix.lower()
        lang_map = {".py": "python", ".js": "javascript", ".ts": "typescript",
                    ".sh": "bash", ".json": "json", ".yaml": "yaml", ".yml": "yaml",
                    ".toml": "toml", ".md": "markdown", ".sql": "sql", ".html": "html",
                    ".css": "css", ".rs": "rust", ".go": "go", ".java": "java"}
        lang = lang_map.get(ext, "")

        if len(content) > 3500:
            # Send as file
            buf = io.BytesIO(content.encode())
            buf.name = path.name
            await update.effective_message.reply_document(document=buf, filename=path.name)
        else:
            text = f"📄 `{path.name}`\n\n```{lang}\n{content}\n```"
            await update.effective_message.reply_text(text, parse_mode="Markdown")

    # ── /stat ────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_stat(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text("Usage: `/stat <path>`", parse_mode="Markdown")
            return
        path_str = " ".join(ctx.args)
        path = Path(path_str).expanduser()

        if not path.exists():
            await update.effective_message.reply_text(f"❌ Not found: `{path_str}`", parse_mode="Markdown")
            return

        st   = path.stat()
        mode = oct(stat.S_IMODE(st.st_mode))
        kind = "Directory" if path.is_dir() else ("Symlink" if path.is_symlink() else "File")

        text = (
            f"📋 *{path.name}*\n\n"
            f"Type:     {kind}\n"
            f"Path:     `{path}`\n"
            f"Size:     {bytes_to_human(st.st_size)}\n"
            f"Mode:     {mode}\n"
            f"Modified: {datetime.fromtimestamp(st.st_mtime).strftime('%Y-%m-%d %H:%M:%S')}\n"
            f"Created:  {datetime.fromtimestamp(st.st_ctime).strftime('%Y-%m-%d %H:%M:%S')}\n"
            f"Owner:    UID {st.st_uid} / GID {st.st_gid}"
        )
        if path.is_dir():
            try:
                total = sum(f.stat().st_size for f in path.rglob("*") if f.is_file())
                text += f"\nDisk use: {bytes_to_human(total)}"
            except Exception:
                pass
        await update.effective_message.reply_text(text, parse_mode="Markdown")

    # ── /find ────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_find(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        Find files. /find <pattern> [in <dir>] [-type f|d] [-size +10M]
        """
        if not ctx.args:
            await update.effective_message.reply_text(
                "Usage: `/find <pattern> [in <dir>]`\nExample: `/find *.py in ~/Projects`",
                parse_mode="Markdown"
            )
            return

        args  = list(ctx.args)
        pattern = args[0]
        search_dir = self._cwd

        # Parse "in <dir>"
        if "in" in args[1:]:
            idx = args.index("in", 1)
            search_dir = " ".join(args[idx + 1:])

        await update.effective_message.reply_text(f"🔍 Searching for `{pattern}` in `{search_dir}`...", parse_mode="Markdown")

        out, rc = await run_shell_async(
            f'find {search_dir!r} -name "{pattern}" 2>/dev/null | head -50'
        )
        if not out or out == "(no output)":
            await update.effective_message.reply_text("🔍 No files found.")
        else:
            lines = out.split("\n")
            text = f"🔍 *Found {len(lines)} result(s)*\n\n```\n{out[:2000]}\n```"
            await update.effective_message.reply_text(text, parse_mode="Markdown")

    # ── /grep ────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_grep(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Search text inside files. /grep <pattern> [path]"""
        if not ctx.args:
            await update.effective_message.reply_text(
                "Usage: `/grep <pattern> [path]`\nExample: `/grep TODO ~/Projects -r`",
                parse_mode="Markdown"
            )
            return
        pattern = ctx.args[0]
        path    = ctx.args[1] if len(ctx.args) > 1 else self._cwd
        flags   = " ".join(ctx.args[2:]) if len(ctx.args) > 2 else "-rn --color=never"
        cmd     = f"grep {flags} {pattern!r} {path!r} 2>/dev/null | head -40"

        out, rc = await run_shell_async(cmd)
        if not out or out == "(no output)":
            await update.effective_message.reply_text(f"🔍 No matches for `{pattern}`", parse_mode="Markdown")
        else:
            await update.effective_message.reply_text(f"🔍 `{pattern}`\n\n```\n{out[:2500]}\n```", parse_mode="Markdown")

    # ── /mkdir ───────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_mkdir(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text("Usage: `/mkdir <dirname>`", parse_mode="Markdown")
            return
        path = Path(self._cwd) / " ".join(ctx.args)
        try:
            path.mkdir(parents=True, exist_ok=True)
            await update.effective_message.reply_text(f"✅ Created `{path}`", parse_mode="Markdown")
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {e}")

    # ── /rm ──────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_rm(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text("Usage: `/rm <path> [-r]`", parse_mode="Markdown")
            return
        recursive = "-r" in ctx.args
        args = [a for a in ctx.args if a != "-r"]
        path = Path(" ".join(args)).expanduser()

        if not path.exists():
            await update.effective_message.reply_text(f"❌ Not found: `{path}`", parse_mode="Markdown")
            return

        # Confirm with inline button
        keyboard = [[
            InlineKeyboardButton("✅ Yes, delete", callback_data=f"rm_confirm:{path}:{recursive}"),
            InlineKeyboardButton("❌ Cancel",       callback_data="rm_cancel")
        ]]
        await update.effective_message.reply_text(
            f"⚠️ Delete `{path}`?\n{'(recursive)' if recursive else ''}",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )

    async def cb_rm_confirm(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        await query.answer()
        data = query.data.replace("rm_confirm:", "").split(":")
        path_str, recursive_str = data[0], data[1]
        path = Path(path_str)
        recursive = recursive_str == "True"
        try:
            if path.is_dir() and recursive:
                shutil.rmtree(path)
            elif path.is_file():
                path.unlink()
            else:
                await query.edit_message_text("❌ Use `-r` flag to delete directories.")
                return
            await query.edit_message_text(f"✅ Deleted `{path}`", parse_mode="Markdown")
        except Exception as e:
            await query.edit_message_text(f"❌ {e}")

    # ── /mv / /cp ────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_mv(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if len(ctx.args) < 2:
            await update.effective_message.reply_text("Usage: `/mv <src> <dst>`", parse_mode="Markdown")
            return
        mid = len(ctx.args) // 2
        src = Path(" ".join(ctx.args[:mid])).expanduser()
        dst = Path(" ".join(ctx.args[mid:])).expanduser()
        try:
            shutil.move(str(src), str(dst))
            await update.effective_message.reply_text(f"✅ Moved `{src.name}` → `{dst}`", parse_mode="Markdown")
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {e}")

    @require_auth
    async def cmd_cp(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if len(ctx.args) < 2:
            await update.effective_message.reply_text("Usage: `/cp <src> <dst>`", parse_mode="Markdown")
            return
        mid = len(ctx.args) // 2
        src = Path(" ".join(ctx.args[:mid])).expanduser()
        dst = Path(" ".join(ctx.args[mid:])).expanduser()
        try:
            if src.is_dir():
                shutil.copytree(src, dst)
            else:
                shutil.copy2(src, dst)
            await update.effective_message.reply_text(f"✅ Copied `{src.name}` → `{dst}`", parse_mode="Markdown")
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {e}")

    # ── /download ────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_download(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text("Usage: `/download <filepath>`", parse_mode="Markdown")
            return
        path_str = " ".join(ctx.args)
        path = Path(path_str).expanduser() if path_str.startswith(("/", "~")) else Path(self._cwd) / path_str

        if not path.exists():
            await update.effective_message.reply_text(f"❌ Not found: `{path}`", parse_mode="Markdown")
            return

        # Auto-zip directories
        if path.is_dir():
            await update.effective_message.reply_text(f"📦 Zipping `{path.name}`...")
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
                for f in path.rglob("*"):
                    if f.is_file():
                        zf.write(f, f.relative_to(path))
            buf.seek(0)
            buf.name = path.name + ".zip"
            await update.effective_message.reply_document(document=buf, filename=path.name + ".zip",
                                                           caption=f"📦 `{path.name}/` (zipped)")
            return

        size = path.stat().st_size
        max_bytes = self.config.max_file_mb * 1024 * 1024
        if size > max_bytes:
            await update.effective_message.reply_text(
                f"❌ File too large ({bytes_to_human(size)}). Max: {self.config.max_file_mb}MB.\n"
                f"Adjust with `/config set max_file_mb <n>`"
            )
            return

        await update.effective_message.reply_text(f"📤 Sending `{path.name}`...")
        async with aiofiles.open(path, "rb") as f:
            data = await f.read()
        buf = io.BytesIO(data)
        buf.name = path.name
        await update.effective_message.reply_document(
            document=buf,
            filename=path.name,
            caption=f"📥 `{path.name}` · {bytes_to_human(size)}"
        )

    # ── /upload (receive file from Telegram) ─────────────────────────────────
    @require_auth
    async def cmd_upload_prompt(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        await update.effective_message.reply_text(
            f"📤 Send me any file now and I'll save it to:\n`{self.config.upload_dir}`\n\n"
            "Or reply with a file to a different path using `/saveto <path>`",
            parse_mode="Markdown"
        )

    async def handle_document(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Handle incoming file uploads."""
        user = update.effective_user
        if not self.auth.is_allowed(user.id):
            return

        doc  = update.effective_message.document
        dest_dir = ctx.user_data.get("upload_dir", str(self.config.upload_dir))
        dest = Path(dest_dir) / doc.file_name

        await update.effective_message.reply_text(f"📥 Saving `{doc.file_name}`...")
        file_obj = await ctx.bot.get_file(doc.file_id)

        buf = io.BytesIO()
        await file_obj.download_to_memory(buf)
        buf.seek(0)

        async with aiofiles.open(dest, "wb") as f:
            await f.write(buf.read())

        await update.effective_message.reply_text(
            f"✅ Saved to `{dest}` ({bytes_to_human(dest.stat().st_size)})",
            parse_mode="Markdown"
        )

    # ── /zip / /unzip ────────────────────────────────────────────────────────
    @require_auth
    async def cmd_zip(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text("Usage: `/zip <source_path> [output.zip]`", parse_mode="Markdown")
            return
        src_path  = Path(" ".join(ctx.args)).expanduser()
        out_path  = Path(self._cwd) / (src_path.name + ".zip")

        if not src_path.exists():
            await update.effective_message.reply_text(f"❌ Not found: `{src_path}`", parse_mode="Markdown")
            return

        await update.effective_message.reply_text(f"📦 Zipping `{src_path.name}`...")
        with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as zf:
            if src_path.is_dir():
                for f in src_path.rglob("*"):
                    if f.is_file():
                        zf.write(f, f.relative_to(src_path.parent))
            else:
                zf.write(src_path, src_path.name)

        await update.effective_message.reply_text(
            f"✅ Created `{out_path.name}` ({bytes_to_human(out_path.stat().st_size)})",
            parse_mode="Markdown"
        )

    @require_auth
    async def cmd_unzip(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text("Usage: `/unzip <file.zip> [destination]`", parse_mode="Markdown")
            return
        zip_path = Path(ctx.args[0]).expanduser()
        dest     = Path(ctx.args[1]).expanduser() if len(ctx.args) > 1 else Path(self._cwd)

        try:
            with zipfile.ZipFile(zip_path, "r") as zf:
                zf.extractall(dest)
                names = zf.namelist()
            await update.effective_message.reply_text(
                f"✅ Extracted {len(names)} files → `{dest}`",
                parse_mode="Markdown"
            )
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {e}")

    # ── /write ───────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_write(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Write text to a file. /write <filename> <content>"""
        if len(ctx.args) < 2:
            await update.effective_message.reply_text("Usage: `/write <filename> <content>`", parse_mode="Markdown")
            return
        filename = ctx.args[0]
        content  = " ".join(ctx.args[1:])
        path = Path(self._cwd) / filename
        try:
            path.write_text(content)
            await update.effective_message.reply_text(f"✅ Written to `{path}` ({len(content)} chars)", parse_mode="Markdown")
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {e}")
