"""
Screen & UI handlers — screenshot, type, click, scroll, notify, volume, brightness.
"""

from __future__ import annotations

import io
import platform

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth
from salim.utils import run_shell_async, is_mac, is_linux, is_windows

OS = platform.system()


class ScreenHandlers:

    # ── /screenshot ──────────────────────────────────────────────────────────
    @require_auth
    async def cmd_screenshot(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        Take a screenshot. Optional: /screenshot <delay_seconds>
        """
        delay = 0
        if ctx.args:
            try:
                delay = int(ctx.args[0])
            except ValueError:
                pass

        if delay:
            await update.effective_message.reply_text(f"📸 Screenshot in {delay}s...")
            await __import__("asyncio").sleep(delay)

        try:
            import pyautogui
            from PIL import Image

            shot = pyautogui.screenshot()
            # Optional: crop /screenshot 0 0 1280 720
            if len(ctx.args) >= 4:
                try:
                    x, y, w, h = [int(a) for a in ctx.args[:4]]
                    shot = shot.crop((x, y, x + w, y + h))
                except Exception:
                    pass

            # Compress
            buf = io.BytesIO()
            quality = self.config.screenshot_quality
            shot.save(buf, format="JPEG", quality=quality, optimize=True)
            buf.seek(0)

            size = buf.getbuffer().nbytes
            w, h = shot.size
            await update.effective_message.reply_photo(
                photo=buf,
                caption=f"📸 {w}×{h} · {size // 1024}KB"
            )
        except ImportError:
            await update.effective_message.reply_text(
                "❌ Missing: `pip install pyautogui Pillow`",
                parse_mode="Markdown"
            )
        except Exception as e:
            await update.effective_message.reply_text(f"❌ Screenshot failed: {e}")

    # ── /type ────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_type(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Type text on screen using keyboard automation."""
        if not ctx.args:
            await update.effective_message.reply_text("Usage: `/type <text to type>`", parse_mode="Markdown")
            return
        text = " ".join(ctx.args)
        try:
            import pyautogui
            pyautogui.write(text, interval=0.03)
            await update.effective_message.reply_text(f"⌨️ Typed: `{text[:100]}`", parse_mode="Markdown")
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {e}")

    # ── /key ─────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_key(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        Press keyboard shortcut. /key ctrl+c, /key cmd+space, /key enter
        Common: ctrl+c, ctrl+v, ctrl+z, cmd+space, alt+tab, enter, escape, tab
        """
        if not ctx.args:
            await update.effective_message.reply_text(
                "Usage: `/key <shortcut>`\nExamples:\n`/key ctrl+c`\n`/key cmd+space`\n`/key enter`\n`/key alt+tab`",
                parse_mode="Markdown"
            )
            return
        combo = ctx.args[0].lower()
        try:
            import pyautogui
            if "+" in combo:
                keys = combo.split("+")
                pyautogui.hotkey(*keys)
            else:
                pyautogui.press(combo)
            await update.effective_message.reply_text(f"⌨️ Pressed: `{combo}`", parse_mode="Markdown")
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {e}")

    # ── /click ───────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_click(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        Click at coordinates. /click <x> <y> [button] [clicks]
        button: left (default), right, middle
        """
        if len(ctx.args) < 2:
            await update.effective_message.reply_text(
                "Usage: `/click <x> <y> [left|right|middle] [1|2|3]`\n"
                "Example: `/click 500 300 right`\n`/click 200 400 left 2` (double-click)",
                parse_mode="Markdown"
            )
            return
        try:
            import pyautogui
            x       = int(ctx.args[0])
            y       = int(ctx.args[1])
            button  = ctx.args[2] if len(ctx.args) > 2 else "left"
            clicks  = int(ctx.args[3]) if len(ctx.args) > 3 else 1
            pyautogui.click(x, y, button=button, clicks=clicks, interval=0.1)
            await update.effective_message.reply_text(
                f"🖱️ Clicked `{button}×{clicks}` at ({x}, {y})",
                parse_mode="Markdown"
            )
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {e}")

    # ── /scroll ──────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_scroll(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Scroll the mouse wheel. /scroll <amount> [x y]"""
        if not ctx.args:
            await update.effective_message.reply_text("Usage: `/scroll <amount>` (negative=down)", parse_mode="Markdown")
            return
        try:
            import pyautogui
            amount = int(ctx.args[0])
            if len(ctx.args) >= 3:
                pyautogui.scroll(amount, x=int(ctx.args[1]), y=int(ctx.args[2]))
            else:
                pyautogui.scroll(amount)
            direction = "up" if amount > 0 else "down"
            await update.effective_message.reply_text(f"🖱️ Scrolled {direction} by {abs(amount)}")
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {e}")

    # ── /move ────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_move(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Move mouse to coordinates. /move <x> <y>"""
        if len(ctx.args) < 2:
            await update.effective_message.reply_text("Usage: `/move <x> <y>`", parse_mode="Markdown")
            return
        try:
            import pyautogui
            x, y = int(ctx.args[0]), int(ctx.args[1])
            pyautogui.moveTo(x, y, duration=0.3)
            await update.effective_message.reply_text(f"🖱️ Moved to ({x}, {y})")
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {e}")

    # ── /mousepos ────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_mousepos(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Get current mouse position."""
        try:
            import pyautogui
            x, y = pyautogui.position()
            w, h = pyautogui.size()
            await update.effective_message.reply_text(
                f"🖱️ Mouse: ({x}, {y})\n📐 Screen: {w}×{h}"
            )
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {e}")

    # ── /notify ──────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_notify(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Show desktop notification. /notify <title> | <message>"""
        if not ctx.args:
            await update.effective_message.reply_text("Usage: `/notify <title> | <message>`", parse_mode="Markdown")
            return
        full = " ".join(ctx.args)
        if "|" in full:
            title, msg = full.split("|", 1)
        else:
            title, msg = "Salim", full
        title = title.strip()
        msg   = msg.strip()

        if is_mac():
            out, _ = await run_shell_async(
                f"osascript -e 'display notification \"{msg}\" with title \"{title}\"'"
            )
        elif is_windows():
            out, _ = await run_shell_async(
                f'powershell -command "Add-Type -AssemblyName System.Windows.Forms; '
                f'[System.Windows.Forms.MessageBox]::Show(\'{msg}\', \'{title}\')"'
            )
        else:
            out, _ = await run_shell_async(f'notify-send "{title}" "{msg}"')

        await update.effective_message.reply_text(f"🔔 Sent notification: *{title}*\n_{msg}_", parse_mode="Markdown")

    # ── /volume ──────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_volume(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Get or set system volume. /volume [0-100|up|down|mute]"""
        if not ctx.args:
            # Get current
            if is_mac():
                out, _ = await run_shell_async("osascript -e 'output volume of (get volume settings)'")
            elif is_linux():
                out, _ = await run_shell_async("amixer get Master | grep -o '[0-9]*%' | head -1")
            else:
                out, _ = await run_shell_async("(Get-AudioDevice -Playback).Volume")
            await update.effective_message.reply_text(f"🔊 Volume: `{out}`", parse_mode="Markdown")
            return

        level = ctx.args[0].lower()
        if is_mac():
            if level == "mute":
                cmd = "osascript -e 'set volume output muted true'"
            elif level == "up":
                cmd = "osascript -e 'set volume output volume (output volume of (get volume settings) + 10)'"
            elif level == "down":
                cmd = "osascript -e 'set volume output volume (output volume of (get volume settings) - 10)'"
            else:
                cmd = f"osascript -e 'set volume output volume {level}'"
        elif is_linux():
            level_map = {"up": "+10%", "down": "-10%", "mute": "toggle"}
            amixer_level = level_map.get(level, f"{level}%")
            cmd = f"amixer set Master {amixer_level}"
        else:
            cmd = f"powershell -c \"$obj = New-Object -com wscript.shell; $obj.SendKeys([char]174)\""

        await run_shell_async(cmd)
        await update.effective_message.reply_text(f"🔊 Volume set to `{level}`", parse_mode="Markdown")

    # ── /brightness ──────────────────────────────────────────────────────────
    @require_auth
    async def cmd_brightness(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Set screen brightness. /brightness [0-100]"""
        if not ctx.args:
            await update.effective_message.reply_text("Usage: `/brightness <0-100>`", parse_mode="Markdown")
            return
        level = ctx.args[0]
        if is_mac():
            cmd = f"osascript -e 'tell application \"System Events\" to set brightness to {int(level)/100}'"
        elif is_linux():
            out, _ = await run_shell_async("ls /sys/class/backlight/")
            device = out.split("\n")[0].strip()
            if device:
                max_b, _ = await run_shell_async(f"cat /sys/class/backlight/{device}/max_brightness")
                val = int(max_b.strip()) * int(level) // 100
                cmd = f"echo {val} | sudo tee /sys/class/backlight/{device}/brightness"
            else:
                cmd = f"xrandr --output $(xrandr | grep ' connected' | head -1 | cut -d' ' -f1) --brightness {int(level)/100}"
        else:
            cmd = f"powershell -c \"(Get-WmiObject -Namespace root/wmi -Class WmiMonitorBrightnessMethods).WmiSetBrightness(1,{level})\""

        await run_shell_async(cmd)
        await update.effective_message.reply_text(f"💡 Brightness → `{level}%`", parse_mode="Markdown")

    # ── /clipboard ───────────────────────────────────────────────────────────
    @require_auth
    async def cmd_copy(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text("Usage: `/copy <text>`", parse_mode="Markdown")
            return
        text = " ".join(ctx.args)
        try:
            import pyperclip
            pyperclip.copy(text)
            await update.effective_message.reply_text(f"📋 Copied to clipboard:\n`{text[:200]}`", parse_mode="Markdown")
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {e}")

    @require_auth
    async def cmd_paste(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        try:
            import pyperclip
            content = pyperclip.paste()
            if not content:
                await update.effective_message.reply_text("📋 Clipboard is empty.")
                return
            await update.effective_message.reply_text(
                f"📋 *Clipboard*\n\n```\n{content[:2000]}\n```",
                parse_mode="Markdown"
            )
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {e}")

    # ── /open ────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_open(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Open a file, app, or URL."""
        if not ctx.args:
            await update.effective_message.reply_text("Usage: `/open <app|file|url>`", parse_mode="Markdown")
            return
        target = " ".join(ctx.args)
        if is_mac():
            cmd = f"open '{target}'"
        elif is_windows():
            cmd = f"start '' '{target}'"
        else:
            cmd = f"xdg-open '{target}' &"
        out, rc = await run_shell_async(cmd)
        icon = "🚀" if rc == 0 else "❌"
        await update.effective_message.reply_text(f"{icon} Opened: `{target}`", parse_mode="Markdown")
