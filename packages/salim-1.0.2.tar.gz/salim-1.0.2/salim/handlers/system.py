"""
System monitoring handlers: CPU, memory, disk, battery, network, processes.
"""

from __future__ import annotations

import os
import platform
import time
from datetime import datetime, timedelta

import psutil
from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth
from salim.utils import bytes_to_human, short_time, is_mac, is_linux, is_windows

OS = platform.system()


class SystemHandlers:

    # ── /info ────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_info(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        msg = update.effective_message
        await msg.reply_text("🔄 Gathering system info...")

        cpu_pct  = psutil.cpu_percent(interval=1)
        cpu_freq = psutil.cpu_freq()
        mem      = psutil.virtual_memory()
        swap     = psutil.swap_memory()
        disk     = psutil.disk_usage("/")
        boot     = psutil.boot_time()
        uptime   = timedelta(seconds=int(time.time() - boot))

        # Battery
        try:
            bat = psutil.sensors_battery()
            bat_line = (
                f"🔋 {bat.percent:.0f}% {'🔌 charging' if bat.power_plugged else '🔋 on battery'}"
                if bat else "⚡ No battery (desktop)"
            )
        except Exception:
            bat_line = "⚡ N/A"

        # Temperatures (Linux/Mac)
        temp_line = ""
        try:
            temps = psutil.sensors_temperatures()
            if temps:
                all_temps = [t.current for sensors in temps.values() for t in sensors]
                if all_temps:
                    temp_line = f"\n🌡️ *Temp:* {max(all_temps):.0f}°C (max)"
        except Exception:
            pass

        freq_str = f"{cpu_freq.current:.0f} MHz" if cpu_freq else "N/A"
        cores    = f"{psutil.cpu_count(logical=False)}P / {psutil.cpu_count(logical=True)}L"

        text = (
            f"🖥️ *System Report* — {short_time()}\n\n"
            f"*Host:* `{platform.node()}`\n"
            f"*OS:* {platform.system()} {platform.release()} ({platform.machine()})\n"
            f"*User:* `{os.getenv('USER') or os.getenv('USERNAME', '?')}`\n"
            f"*Uptime:* {uptime}\n"
            f"*Boot:* {datetime.fromtimestamp(boot).strftime('%Y-%m-%d %H:%M')}\n\n"
            f"⚙️ *CPU:* {cpu_pct}% · {cores} cores · {freq_str}{temp_line}\n"
            f"🧠 *RAM:* {bytes_to_human(mem.used)} / {bytes_to_human(mem.total)} ({mem.percent}%)\n"
            f"💾 *Swap:* {bytes_to_human(swap.used)} / {bytes_to_human(swap.total)} ({swap.percent}%)\n"
            f"💿 *Disk:* {bytes_to_human(disk.used)} / {bytes_to_human(disk.total)} ({disk.percent}%)\n"
            f"{bat_line}\n\n"
            f"🐍 Python {platform.python_version()} · Salim"
        )
        await msg.reply_text(text, parse_mode="Markdown")

    # ── /cpu ─────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_cpu(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        per_cpu = psutil.cpu_percent(interval=1, percpu=True)
        freq    = psutil.cpu_freq(percpu=False)
        lines   = []
        for i, p in enumerate(per_cpu):
            bar = "█" * int(p / 5) + "░" * (20 - int(p / 5))
            lines.append(f"Core {i:2d} [{bar}] {p:5.1f}%")
        avg = sum(per_cpu) / len(per_cpu)
        freq_str = f"{freq.current:.0f}/{freq.max:.0f} MHz" if freq else "N/A"
        text = (
            f"⚙️ *CPU Usage*\n\n```\n"
            + "\n".join(lines)
            + f"\n\nAvg: {avg:.1f}%  Freq: {freq_str}\n```"
        )
        await update.effective_message.reply_text(text, parse_mode="Markdown")

    # ── /mem ─────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_mem(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        m  = psutil.virtual_memory()
        sw = psutil.swap_memory()
        bar_filled = int(m.percent / 5)
        bar = "█" * bar_filled + "░" * (20 - bar_filled)
        text = (
            f"🧠 *Memory*\n\n"
            f"`[{bar}] {m.percent}%`\n\n"
            f"Total:     {bytes_to_human(m.total)}\n"
            f"Used:      {bytes_to_human(m.used)}\n"
            f"Available: {bytes_to_human(m.available)}\n"
            f"Cached:    {bytes_to_human(getattr(m, 'cached', 0))}\n\n"
            f"💾 *Swap*: {bytes_to_human(sw.used)} / {bytes_to_human(sw.total)} ({sw.percent}%)"
        )
        await update.effective_message.reply_text(text, parse_mode="Markdown")

    # ── /disk ────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_disk(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        lines = []
        for part in psutil.disk_partitions(all=False):
            try:
                u = psutil.disk_usage(part.mountpoint)
                bar = "█" * int(u.percent / 5) + "░" * (20 - int(u.percent / 5))
                lines.append(
                    f"`{part.mountpoint}`\n"
                    f"[{bar}] {u.percent}%\n"
                    f"{bytes_to_human(u.used)} / {bytes_to_human(u.total)} free: {bytes_to_human(u.free)}\n"
                )
            except (PermissionError, OSError):
                pass

        # Disk IO
        try:
            io1 = psutil.disk_io_counters()
            time.sleep(0.5)
            io2 = psutil.disk_io_counters()
            read_speed  = bytes_to_human((io2.read_bytes  - io1.read_bytes)  * 2) + "/s"
            write_speed = bytes_to_human((io2.write_bytes - io1.write_bytes) * 2) + "/s"
            io_line = f"\n📈 I/O: ↓{read_speed} ↑{write_speed}"
        except Exception:
            io_line = ""

        text = "💿 *Disk Usage*\n\n" + "\n".join(lines) + io_line
        await update.effective_message.reply_text(text, parse_mode="Markdown")

    # ── /battery ─────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_battery(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        try:
            bat = psutil.sensors_battery()
            if not bat:
                await update.effective_message.reply_text("⚡ No battery detected (desktop system).")
                return
            pct  = bat.percent
            bar  = "█" * int(pct / 5) + "░" * (20 - int(pct / 5))
            secs = bat.secsleft
            if secs > 0:
                time_left = f"{secs // 3600}h {(secs % 3600) // 60}m remaining"
            elif bat.power_plugged:
                time_left = "Fully charged / charging"
            else:
                time_left = "Calculating..."
            status = "🔌 Plugged In" if bat.power_plugged else "🔋 On Battery"
            text = (
                f"🔋 *Battery Status*\n\n"
                f"`[{bar}] {pct:.0f}%`\n\n"
                f"Status:    {status}\n"
                f"Time:      {time_left}"
            )
        except Exception as e:
            text = f"❌ Could not read battery: {e}"
        await update.effective_message.reply_text(text, parse_mode="Markdown")

    # ── /network ─────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_network(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        lines = []
        addrs = psutil.net_if_addrs()
        stats = psutil.net_if_stats()
        for iface, addr_list in addrs.items():
            s = stats.get(iface)
            up = "✅" if (s and s.isup) else "❌"
            speed = f"{s.speed}Mbps" if (s and s.speed) else ""
            lines.append(f"\n{up} *{iface}* {speed}")
            for addr in addr_list:
                fam = addr.family.name
                if fam in ("AF_INET", "AF_INET6"):
                    lines.append(f"  `{addr.address}`")

        # Network IO
        try:
            n1 = psutil.net_io_counters()
            time.sleep(0.5)
            n2 = psutil.net_io_counters()
            sent = bytes_to_human((n2.bytes_sent - n1.bytes_sent) * 2) + "/s"
            recv = bytes_to_human((n2.bytes_recv - n1.bytes_recv) * 2) + "/s"
            io_line = f"\n\n📡 Live: ↑{sent}  ↓{recv}"
            total   = f"\n📊 Total: ↑{bytes_to_human(n2.bytes_sent)}  ↓{bytes_to_human(n2.bytes_recv)}"
        except Exception:
            io_line = total = ""

        text = "🌐 *Network*\n" + "\n".join(lines) + io_line + total
        await update.effective_message.reply_text(text, parse_mode="Markdown")

    # ── /ps ──────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_ps(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        # Optional: filter by name
        filter_name = (ctx.args[0] if ctx.args else "").lower()

        procs = []
        for p in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent", "status", "username"]):
            try:
                info = p.info
                if filter_name and filter_name not in (info["name"] or "").lower():
                    continue
                procs.append(info)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass

        # Second pass for accurate CPU
        time.sleep(0.3)
        procs.sort(key=lambda x: x["cpu_percent"] or 0, reverse=True)

        lines = ["```", f"{'PID':>7}  {'CPU%':>6}  {'MEM%':>6}  NAME"]
        for p in procs[:25]:
            lines.append(
                f"{p['pid']:>7}  {p['cpu_percent'] or 0:>5.1f}%  "
                f"{p['memory_percent'] or 0:>5.1f}%  {(p['name'] or '?')[:30]}"
            )
        lines.append("```")

        header = f"⚙️ *Processes* (top {min(25, len(procs))} by CPU)"
        if filter_name:
            header += f" matching `{filter_name}`"
        await update.effective_message.reply_text(header + "\n" + "\n".join(lines), parse_mode="Markdown")

    # ── /kill ────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_kill(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text("Usage: `/kill <pid> [signal]`\nSignals: term (default), kill, stop, cont", parse_mode="Markdown")
            return
        try:
            pid    = int(ctx.args[0])
            sig    = (ctx.args[1] if len(ctx.args) > 1 else "term").lower()
            p      = psutil.Process(pid)
            name   = p.name()
            status = p.status()

            if sig == "kill":
                p.kill()
                action = "killed (SIGKILL)"
            elif sig == "stop":
                p.suspend()
                action = "suspended (SIGSTOP)"
            elif sig == "cont":
                p.resume()
                action = "resumed (SIGCONT)"
            else:
                p.terminate()
                action = "terminated (SIGTERM)"

            await update.effective_message.reply_text(
                f"✅ Process `{name}` (PID {pid}, was {status}) — {action}",
                parse_mode="Markdown"
            )
        except psutil.NoSuchProcess:
            await update.effective_message.reply_text(f"❌ No process with PID {ctx.args[0]}")
        except psutil.AccessDenied:
            await update.effective_message.reply_text(f"❌ Permission denied. Try running Salim with sudo.")
        except ValueError:
            await update.effective_message.reply_text("❌ PID must be a number.")
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {e}")

    # ── /uptime ──────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_uptime(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        boot   = psutil.boot_time()
        up     = timedelta(seconds=int(time.time() - boot))
        boot_t = datetime.fromtimestamp(boot).strftime("%Y-%m-%d %H:%M:%S")
        await update.effective_message.reply_text(
            f"⏱ *Uptime*: `{up}`\n📅 *Booted*: `{boot_t}`",
            parse_mode="Markdown"
        )

    # ── /top ─────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_top(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Live resource snapshot — updates every 3s for 5 iterations."""
        msg = await update.effective_message.reply_text("📊 Loading live stats...")
        for _ in range(5):
            cpu  = psutil.cpu_percent(interval=1)
            mem  = psutil.virtual_memory()
            net  = psutil.net_io_counters()
            disk = psutil.disk_io_counters()
            text = (
                f"📊 *Live Stats* — {short_time()}\n\n"
                f"CPU  [{('█' * int(cpu/5)).ljust(20, '░')}] {cpu:.1f}%\n"
                f"RAM  [{('█' * int(mem.percent/5)).ljust(20, '░')}] {mem.percent:.1f}%\n\n"
                f"Net ↑ {bytes_to_human(net.bytes_sent)}  ↓ {bytes_to_human(net.bytes_recv)}\n"
                f"Disk R {bytes_to_human(disk.read_bytes)}  W {bytes_to_human(disk.write_bytes)}"
            )
            try:
                await msg.edit_text(text, parse_mode="Markdown")
            except Exception:
                pass
            await __import__("asyncio").sleep(3)
