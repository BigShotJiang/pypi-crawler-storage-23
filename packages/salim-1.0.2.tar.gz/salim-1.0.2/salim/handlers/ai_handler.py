"""
Salim AI Handler — Telegram message handler for natural language control.

Intercepts plain-text messages (not /commands), routes through SalimAI,
executes the appropriate action, presents results with inline buttons.
Supports the full fallback chain: NVIDIA → Groq → Z.AI.
"""

from __future__ import annotations

import logging
from pathlib import Path

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes

from salim.ai import SalimAI
from salim.ai_search import SearchResult, format_results_for_telegram, search_laptop
from salim.auth import require_auth

logger = logging.getLogger("salim.ai_handler")

MAX_BUTTON_RESULTS = 8

# Commands that map to handler method names
HANDLER_MAP = {
    "screenshot": "cmd_screenshot",
    "ss":         "cmd_screenshot",
    "info":       "cmd_info",
    "cpu":        "cmd_cpu",
    "mem":        "cmd_mem",
    "disk":       "cmd_disk",
    "battery":    "cmd_battery",
    "network":    "cmd_network",
    "uptime":     "cmd_uptime",
    "top":        "cmd_top",
    "ps":         "cmd_ps",
    "ls":         "cmd_ls",
    "pwd":        "cmd_pwd",
    "paste":      "cmd_paste",
    "volume":     "cmd_volume",
    "brightness": "cmd_brightness",
    "lock":       "cmd_lock",
    "sleep":      "cmd_sleep",
    "screensaver":"cmd_screensaver",
    "notify":     "cmd_notify",
    "open":       "cmd_open",
    "type":       "cmd_type",
    "key":        "cmd_key",
    "mousepos":   "cmd_mousepos",
    "click":      "cmd_click",
    "scroll":     "cmd_scroll",
    "move":       "cmd_move",
    "run":        "cmd_run",
    "sh":         "cmd_run",
    "env":        "cmd_env",
    "which":      "cmd_which",
    "find":       "cmd_find",
    "grep":       "cmd_grep",
    "cat":        "cmd_cat",
    "stat":       "cmd_stat",
    "download":   "cmd_download",
    "copy":       "cmd_copy",
    "mkdir":      "cmd_mkdir",
    "zip":        "cmd_zip",
    "unzip":      "cmd_unzip",
    "write":      "cmd_write",
    "mv":         "cmd_mv",
    "cp":         "cmd_cp",
}

# Destructive command handlers for confirm callbacks
DESTRUCTIVE_MAP = {
    "shutdown":  "cmd_shutdown",
    "restart":   "cmd_restart",
    "sleep":     "cmd_sleep",
    "lock":      "cmd_lock",
    "hibernate": "cmd_hibernate",
    "logout":    "cmd_logout",
    "rm":        "cb_rm_confirm",
    "kill":      "cmd_kill",
}


class AIHandler:
    """
    Mixin for SalimBot — adds full natural language understanding.
    All plain-text Telegram messages go through handle_ai_message().
    """

    @property
    def _ai(self) -> SalimAI:
        """Lazy-init AI instance (cached on self)."""
        if not hasattr(self, "_ai_instance"):
            self._ai_instance = SalimAI(self.config)
        return self._ai_instance

    # ══════════════════════════════════════════════════════════════════════════
    #  MAIN ENTRY — plain text message handler
    # ══════════════════════════════════════════════════════════════════════════

    @require_auth
    async def handle_ai_message(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        Called for every plain-text Telegram message that isn't a /command.
        Routes through AI intent parser → executes the appropriate action.
        """
        msg = update.effective_message
        text = (msg.text or "").strip()
        if not text:
            return

        # Not configured — friendly nudge
        if not self._ai.is_configured():
            await msg.reply_text(
                "🤖 *AI mode is not set up yet.*\n\n"
                "Run `salim setup` on your laptop to add NVIDIA, Groq, or Z.AI API keys.\n\n"
                "You can still use all /commands directly — send /help to see them.",
                parse_mode="Markdown",
            )
            return

        # Thinking indicator
        thinking = await msg.reply_text("🤖 _Thinking..._", parse_mode="Markdown")

        try:
            intent = await self._ai.parse_intent(text)
        except Exception as e:
            await thinking.edit_text(f"⚠️ AI error: {e}")
            return

        action   = intent.get("action", "clarify")
        ai_msg   = intent.get("message", "")
        provider = intent.get("_provider", "")

        # Append provider tag to thinking message
        provider_tag = f" _[{provider}]_" if provider else ""

        if action == "search_files":
            await thinking.edit_text(
                (ai_msg or "🔍 Searching your laptop...") + provider_tag,
                parse_mode="Markdown",
            )
            await self._do_search(update, ctx, intent)

        elif action == "execute":
            await thinking.edit_text(
                (ai_msg or "⚙️ Running...") + provider_tag,
                parse_mode="Markdown",
            )
            await self._do_execute(update, ctx, intent)

        elif action == "generate_and_write":
            await thinking.edit_text(
                (ai_msg or "✍️ Generating content...") + provider_tag,
                parse_mode="Markdown",
            )
            await self._do_generate_write(update, ctx, intent)

        elif action == "confirm":
            await thinking.edit_text(
                f"{ai_msg or '⚠️ Confirm this action?'}{provider_tag}\n\n"
                "_This action may be irreversible._",
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup([
                    [
                        InlineKeyboardButton(
                            "✅ Yes, do it",
                            callback_data=(
                                f"ai_confirm:"
                                f"{intent.get('command','').lstrip('/')}:"
                                f"{intent.get('args','')}"
                            ),
                        ),
                        InlineKeyboardButton("❌ Cancel", callback_data="ai_cancel"),
                    ]
                ]),
            )

        elif action == "clarify":
            await thinking.edit_text(
                ai_msg or "🤔 Could you be more specific? Or use a /command directly.",
                parse_mode="Markdown",
            )

        else:  # error or unknown
            await thinking.edit_text(
                ai_msg or "⚠️ Something went wrong. Try using a /command directly.",
                parse_mode="Markdown",
            )

    # ══════════════════════════════════════════════════════════════════════════
    #  ACTION HANDLERS
    # ══════════════════════════════════════════════════════════════════════════

    async def _do_search(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE, intent: dict):
        """Handle search_files intent — fuzzy-search laptop, show results with buttons."""
        msg = update.effective_message
        keywords: list[str] = intent.get("keywords", [])
        file_types: list[str] = intent.get("file_types", [])

        if not keywords:
            await msg.reply_text(
                "❓ I couldn't extract search keywords. Please be more specific.\n"
                "Example: _find my project files_, _download day 3 recording_",
                parse_mode="Markdown",
            )
            return

        results = await search_laptop(
            keywords=keywords,
            file_types=file_types or None,
            max_results=MAX_BUTTON_RESULTS,
        )

        if not results:
            await msg.reply_text(
                f"🔍 No files found matching: *{', '.join(keywords)}*\n\n"
                f"Try different keywords or use `/find <pattern>` directly.",
                parse_mode="Markdown",
            )
            return

        text = format_results_for_telegram(results)
        keyboard = _build_result_buttons(results)
        keyboard.append([InlineKeyboardButton("❌ Cancel", callback_data="ai_cancel")])

        await msg.reply_text(
            text,
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup(keyboard),
        )

    async def _do_execute(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE, intent: dict):
        """Handle execute intent — dispatch to existing Salim command handler."""
        command = intent.get("command", "").lstrip("/")
        args_str = intent.get("args", "")

        # Set ctx.args from args string
        ctx.args = args_str.split() if args_str.strip() else []

        handler_name = HANDLER_MAP.get(command)
        if handler_name and hasattr(self, handler_name):
            await getattr(self, handler_name)(update, ctx)
        else:
            # Fallback: run via shell
            await update.effective_message.reply_text(
                f"⚙️ Running: `{command} {args_str}`".strip(),
                parse_mode="Markdown",
            )
            ctx.args = [f"{command} {args_str}".strip()]
            if hasattr(self, "cmd_run"):
                await self.cmd_run(update, ctx)

    async def _do_generate_write(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE, intent: dict):
        """Handle generate_and_write intent — AI writes content, saves file, offers download."""
        msg = update.effective_message
        topic        = intent.get("topic", "")
        fmt          = intent.get("format", "txt").lower()
        filename     = intent.get("filename", f"salim_output.{fmt}")
        save_path    = Path(intent.get("save_path", "~/Desktop")).expanduser()
        instructions = intent.get("content_instructions", f"Write about: {topic}")

        if not topic:
            await msg.reply_text(
                "❓ I couldn't determine what to write about. Please be more specific.\n"
                "Example: _create a txt file about the history of chess_",
                parse_mode="Markdown",
            )
            return

        gen_msg = await msg.reply_text(
            f"✍️ *AI is writing your {fmt.upper()} file about {topic}...*",
            parse_mode="Markdown",
        )

        try:
            content, provider = await self._ai.generate_content(
                topic=topic,
                format=fmt,
                instructions=instructions,
                max_tokens=2048,
            )
        except Exception as e:
            await gen_msg.edit_text(f"⚠️ Content generation failed: {e}")
            return

        # Save to disk
        try:
            save_path.mkdir(parents=True, exist_ok=True)
            full_path = save_path / filename
            full_path.write_text(content, encoding="utf-8")
        except Exception as e:
            await gen_msg.edit_text(f"⚠️ Could not save file: {e}")
            return

        # Shorten path for display
        try:
            display_path = "~/" + str(full_path.relative_to(Path.home()))
        except ValueError:
            display_path = str(full_path)

        preview = content[:280] + ("..." if len(content) > 280 else "")

        await gen_msg.edit_text(
            f"✅ *Created `{filename}`* _[{provider}]_\n"
            f"📁 `{display_path}`\n"
            f"📝 {len(content):,} characters\n\n"
            f"*Preview:*\n```\n{preview}\n```",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([
                [
                    InlineKeyboardButton(
                        "⬇️ Send to Telegram",
                        callback_data=f"ai_dl:{str(full_path)[:200]}",
                    ),
                    InlineKeyboardButton(
                        "👁️ Read file",
                        callback_data=f"ai_cat:{str(full_path)[:200]}",
                    ),
                ],
                [InlineKeyboardButton("✅ Done", callback_data="ai_cancel")],
            ]),
        )

    # ══════════════════════════════════════════════════════════════════════════
    #  CALLBACK HANDLER — inline button presses from AI messages
    # ══════════════════════════════════════════════════════════════════════════

    async def handle_ai_callback(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Handles ai_* callback_data from AI-generated inline keyboards."""
        query = update.callback_query
        await query.answer()
        data = query.data or ""

        if data == "ai_cancel":
            await query.edit_message_text("❌ Cancelled.")
            return

        if data.startswith("ai_dl:"):
            path = data[6:]
            ctx.args = [path]
            if hasattr(self, "cmd_download"):
                await self.cmd_download(update, ctx)

        elif data.startswith("ai_rm:"):
            path = data[6:]
            await query.edit_message_text(
                f"⚠️ *Delete this file?*\n`{path}`\n\n_This cannot be undone._",
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup([
                    [
                        InlineKeyboardButton(
                            "🗑️ Yes, delete",
                            callback_data=f"rm_confirm:{path}",
                        ),
                        InlineKeyboardButton("❌ Cancel", callback_data="ai_cancel"),
                    ]
                ]),
            )

        elif data.startswith("ai_cat:"):
            path = data[7:]
            ctx.args = [path]
            if hasattr(self, "cmd_cat"):
                await self.cmd_cat(update, ctx)

        elif data.startswith("ai_confirm:"):
            # Format: ai_confirm:command:args
            rest = data[11:]
            parts = rest.split(":", 1)
            command  = parts[0]
            args_str = parts[1] if len(parts) > 1 else ""

            ctx.args = args_str.split() if args_str.strip() else []
            handler_name = DESTRUCTIVE_MAP.get(command)

            if handler_name and hasattr(self, handler_name):
                await query.edit_message_text(
                    f"⚙️ Executing `/{command}`...", parse_mode="Markdown"
                )
                await getattr(self, handler_name)(update, ctx)
            else:
                await query.edit_message_text(
                    f"❓ Unknown command: `{command}`", parse_mode="Markdown"
                )


# ══════════════════════════════════════════════════════════════════════════════
#  HELPERS
# ══════════════════════════════════════════════════════════════════════════════

TEXT_EXTENSIONS = {
    ".txt", ".md", ".csv", ".log", ".json", ".py", ".js", ".ts",
    ".html", ".css", ".xml", ".yaml", ".yml", ".sh", ".bat", ".env",
    ".ini", ".cfg", ".toml",
}


def _build_result_buttons(results: list[SearchResult]) -> list[list[InlineKeyboardButton]]:
    """Build one row of action buttons per search result."""
    keyboard = []
    for i, r in enumerate(results, 1):
        path_str = str(r.path)
        row = [
            InlineKeyboardButton(
                f"{i}️⃣ ⬇️ Send",
                callback_data=f"ai_dl:{path_str[:200]}",
            ),
            InlineKeyboardButton(
                "🗑️ Delete",
                callback_data=f"ai_rm:{path_str[:200]}",
            ),
        ]
        if r.path.suffix.lower() in TEXT_EXTENSIONS:
            row.append(InlineKeyboardButton(
                "👁️ Read",
                callback_data=f"ai_cat:{path_str[:200]}",
            ))
        keyboard.append(row)
    return keyboard
