"""
Shell execution handlers — run commands, interactive sessions, cron-like scheduling.
"""

from __future__ import annotations

import asyncio
import os
import re
import shlex
from pathlib import Path

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from salim.auth import require_auth
from salim.utils import run_shell_async, truncate, bytes_to_human


class ShellHandlers:

    # ── /run or /sh ──────────────────────────────────────────────────────────
    @require_auth
    async def cmd_run(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        Execute any shell command. Streams output in real-time (updates message).
        Usage: /run <command>
        """
        if not ctx.args:
            await update.effective_message.reply_text(
                "💻 *Shell Execution*\n\nUsage: `/run <command>`\n\n"
                "Examples:\n`/run ls -la ~/Desktop`\n`/run git status`\n"
                "`/run python3 script.py`\n`/run ps aux | grep python`",
                parse_mode="Markdown"
            )
            return

        cmd = " ".join(ctx.args)
        msg = await update.effective_message.reply_text(f"🔄 Running: `{cmd}`...", parse_mode="Markdown")

        out, rc = await run_shell_async(cmd, timeout=120, cwd=self._cwd)

        status_icon = "✅" if rc == 0 else "❌"
        result = truncate(out)

        # If output is long, send as document
        if len(out) > 3500:
            import io
            file_obj = io.BytesIO(out.encode())
            file_obj.name = "output.txt"
            await msg.delete()
            await update.effective_message.reply_document(
                document=file_obj,
                filename="output.txt",
                caption=f"{status_icon} `{cmd[:100]}` → exit {rc}",
                parse_mode="Markdown"
            )
        else:
            await msg.edit_text(
                f"{status_icon} `{cmd[:100]}`\n\n```\n{result}\n```\n_Exit: {rc}_",
                parse_mode="Markdown"
            )

    # ── /runbg ───────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_runbg(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Run a command in background, notify when done."""
        if not ctx.args:
            await update.effective_message.reply_text("Usage: `/runbg <command>`", parse_mode="Markdown")
            return
        cmd = " ".join(ctx.args)
        await update.effective_message.reply_text(f"🚀 Running in background: `{cmd}`", parse_mode="Markdown")

        async def _bg():
            out, rc = await run_shell_async(cmd, timeout=3600, cwd=self._cwd)
            icon = "✅" if rc == 0 else "❌"
            short_out = truncate(out, 1000)
            await update.effective_message.reply_text(
                f"{icon} *Background task done*\n`{cmd[:80]}`\n\n```\n{short_out}\n```",
                parse_mode="Markdown"
            )

        asyncio.create_task(_bg())

    # ── /pipe ────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_pipe(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        Run a pipeline of commands separated by |||
        /pipe ls -la ||| grep py ||| wc -l
        """
        if not ctx.args:
            await update.effective_message.reply_text(
                "Usage: `/pipe cmd1 ||| cmd2 ||| cmd3`\n\nBuilds a shell pipeline between commands.",
                parse_mode="Markdown"
            )
            return
        raw = " ".join(ctx.args)
        # Replace ||| with actual |
        cmd = raw.replace("|||", "|")
        ctx.args = shlex.split(cmd)
        await self.cmd_run(update, ctx)

    # ── /env ─────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_env(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Show or set environment variables."""
        if ctx.args and ctx.args[0].startswith("set"):
            # /env set KEY=value
            kv = " ".join(ctx.args[1:])
            if "=" in kv:
                k, v = kv.split("=", 1)
                os.environ[k.strip()] = v.strip()
                await update.effective_message.reply_text(f"✅ Set `{k.strip()}` = `{v.strip()}`", parse_mode="Markdown")
                return

        env = os.environ.copy()
        # Filter out secrets
        safe_keys = [k for k in sorted(env.keys()) if not any(s in k.upper() for s in ["TOKEN", "SECRET", "PASSWORD", "KEY"])]
        lines = [f"{k}={env[k][:80]}" for k in safe_keys[:40]]
        text = "🌍 *Environment Variables* (sensitive keys hidden)\n\n```\n" + "\n".join(lines) + "\n```"
        await update.effective_message.reply_text(text, parse_mode="Markdown")

    # ── /which ───────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_which(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text("Usage: `/which <program>`", parse_mode="Markdown")
            return
        prog = ctx.args[0]
        import shutil
        path = shutil.which(prog)
        if path:
            out, _ = await run_shell_async(f"{prog} --version 2>&1 || {prog} -version 2>&1 || {prog} -V 2>&1 | head -1")
            await update.effective_message.reply_text(
                f"🔍 `{prog}` → `{path}`\n{out[:200]}",
                parse_mode="Markdown"
            )
        else:
            await update.effective_message.reply_text(f"❌ `{prog}` not found in PATH", parse_mode="Markdown")

    # ── /cron ────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_cron(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Schedule a command to run every N seconds."""
        if len(ctx.args) < 2:
            await update.effective_message.reply_text(
                "⏰ *Scheduler*\n\nUsage: `/cron <seconds> <command>`\nExample: `/cron 60 uptime`\n\nUse `/cronjobs` to list, `/cronstop <id>` to stop.",
                parse_mode="Markdown"
            )
            return
        try:
            interval = int(ctx.args[0])
            cmd = " ".join(ctx.args[1:])
        except ValueError:
            await update.effective_message.reply_text("❌ First argument must be seconds (integer)")
            return

        job_id = f"cron_{len(ctx.bot_data.get('cron_jobs', {})) + 1}"
        ctx.bot_data.setdefault("cron_jobs", {})[job_id] = {
            "cmd": cmd, "interval": interval, "count": 0
        }

        async def _tick(ctx2: ContextTypes.DEFAULT_TYPE):
            info = ctx2.bot_data.get("cron_jobs", {}).get(job_id)
            if not info:
                return
            info["count"] += 1
            out, rc = await run_shell_async(cmd, timeout=max(interval - 5, 30))
            icon = "✅" if rc == 0 else "❌"
            await update.effective_message.reply_text(
                f"⏰ *Cron `{job_id}`* run #{info['count']}\n`{cmd}`\n\n```\n{truncate(out, 800)}\n```",
                parse_mode="Markdown"
            )

        ctx.job_queue.run_repeating(_tick, interval=interval, first=interval, name=job_id, data=job_id)
        await update.effective_message.reply_text(
            f"✅ Scheduled `{job_id}`: `{cmd}` every {interval}s",
            parse_mode="Markdown"
        )

    @require_auth
    async def cmd_cronstop(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text("Usage: `/cronstop <job_id>`", parse_mode="Markdown")
            return
        job_id = ctx.args[0]
        jobs = ctx.job_queue.get_jobs_by_name(job_id)
        for j in jobs:
            j.schedule_removal()
        ctx.bot_data.get("cron_jobs", {}).pop(job_id, None)
        await update.effective_message.reply_text(f"🛑 Stopped cron job `{job_id}`", parse_mode="Markdown")

    @require_auth
    async def cmd_cronjobs(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        jobs = ctx.bot_data.get("cron_jobs", {})
        if not jobs:
            await update.effective_message.reply_text("No cron jobs running.")
            return
        lines = [f"• `{jid}`: `{info['cmd']}` every {info['interval']}s (ran {info['count']}×)"
                 for jid, info in jobs.items()]
        await update.effective_message.reply_text(
            "⏰ *Active Cron Jobs*\n\n" + "\n".join(lines),
            parse_mode="Markdown"
        )
