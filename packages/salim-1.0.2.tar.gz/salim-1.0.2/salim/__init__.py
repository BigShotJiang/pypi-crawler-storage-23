"""
Salim — Control your laptop from Telegram.
"""

__version__ = "1.0.0"
__author__ = "Salim Contributors"
__license__ = "MIT"

from salim.config import Config
from salim.bot import SalimBot

__all__ = ["Config", "SalimBot", "__version__"]
