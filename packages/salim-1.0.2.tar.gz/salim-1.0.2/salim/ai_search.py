"""
Salim AI Search — Fuzzy file search across the whole laptop.

Smartly searches by keywords, scores results, and returns ranked matches
so the user can pick which file to download/delete/read.
"""

from __future__ import annotations

import asyncio
import fnmatch
import logging
import os
import platform
import re
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Optional

logger = logging.getLogger("salim.ai_search")

# ── Directories to skip (speed + avoid noise) ────────────────────────────────
SKIP_DIRS = {
    # System
    "System32", "SysWOW64", "Windows", "WinSxS",
    "$Recycle.Bin", "ProgramData", "AppData",
    # macOS
    "Library", ".Trash",
    # Linux
    "proc", "sys", "dev", "run",
    # Dev noise
    "node_modules", ".git", "__pycache__", ".venv", "venv",
    ".tox", "dist", "build", "*.egg-info",
    # Cache
    ".cache", "Cache", "cache",
}

# ── File type groups for smarter filtering ────────────────────────────────────
FILE_TYPE_GROUPS = {
    "audio":    [".mp3", ".wav", ".flac", ".aac", ".ogg", ".m4a", ".wma"],
    "video":    [".mp4", ".mkv", ".avi", ".mov", ".wmv", ".flv", ".webm"],
    "image":    [".jpg", ".jpeg", ".png", ".gif", ".bmp", ".svg", ".webp", ".heic"],
    "document": [".pdf", ".docx", ".doc", ".pptx", ".ppt", ".xlsx", ".xls"],
    "text":     [".txt", ".md", ".csv", ".json", ".xml", ".yaml", ".yml"],
    "code":     [".py", ".js", ".ts", ".java", ".cpp", ".c", ".go", ".rs", ".html", ".css"],
    "archive":  [".zip", ".tar", ".gz", ".rar", ".7z"],
}


@dataclass
class SearchResult:
    path: Path
    score: float
    size_bytes: int = 0
    modified: Optional[datetime] = None
    file_type: str = "file"

    @property
    def size_human(self) -> str:
        b = self.size_bytes
        for unit in ["B", "KB", "MB", "GB"]:
            if b < 1024:
                return f"{b:.1f} {unit}"
            b /= 1024
        return f"{b:.1f} TB"

    @property
    def modified_human(self) -> str:
        if not self.modified:
            return "unknown"
        now = datetime.now()
        delta = now - self.modified
        if delta.days == 0:
            return "today"
        elif delta.days == 1:
            return "yesterday"
        elif delta.days < 7:
            return f"{delta.days} days ago"
        elif delta.days < 30:
            return f"{delta.days // 7} weeks ago"
        else:
            return self.modified.strftime("%b %d, %Y")

    @property
    def icon(self) -> str:
        ext = self.path.suffix.lower()
        for group, exts in FILE_TYPE_GROUPS.items():
            if ext in exts:
                icons = {
                    "audio": "🎵", "video": "🎬", "image": "🖼️",
                    "document": "📄", "text": "📝", "code": "💻",
                    "archive": "🗜️",
                }
                return icons.get(group, "📄")
        if self.path.is_dir():
            return "📁"
        return "📄"

    @property
    def short_path(self) -> str:
        """Show path relative to home, or absolute if outside home."""
        try:
            return "~/" + str(self.path.relative_to(Path.home()))
        except ValueError:
            return str(self.path)


def _score_match(filename: str, keywords: list[str]) -> float:
    """
    Score how well a filename matches the search keywords.
    Higher = better match.
    """
    name_lower = filename.lower()
    score = 0.0

    for kw in keywords:
        kw_lower = kw.lower()
        if kw_lower == name_lower:
            score += 100  # Exact match
        elif name_lower.startswith(kw_lower):
            score += 50   # Starts with keyword
        elif kw_lower in name_lower:
            score += 30   # Contains keyword
        else:
            # Fuzzy: all chars of keyword appear in order
            pos = 0
            fuzzy_score = 0
            for char in kw_lower:
                idx = name_lower.find(char, pos)
                if idx >= 0:
                    fuzzy_score += 1
                    pos = idx + 1
            if fuzzy_score == len(kw_lower):
                score += fuzzy_score * 2

    return score


def _should_skip(path: Path) -> bool:
    """Return True if this directory should be skipped during search."""
    return path.name in SKIP_DIRS or path.name.startswith(".")


def _get_search_roots() -> list[Path]:
    """Get the best roots to search from based on OS."""
    home = Path.home()
    system = platform.system()

    if system == "Windows":
        # Search user profile + common drives
        roots = [home]
        for drive in ["C:\\", "D:\\"]:
            p = Path(drive)
            if p.exists():
                roots.append(p / "Users")
    elif system == "Darwin":  # macOS
        roots = [home, Path("/Volumes")]
    else:  # Linux
        roots = [home]

    return [r for r in roots if r.exists()]


async def search_laptop(
    keywords: list[str],
    file_types: Optional[list[str]] = None,
    max_results: int = 10,
    max_depth: int = 8,
) -> list[SearchResult]:
    """
    Fuzzy-search the whole laptop for files matching keywords.

    Args:
        keywords: List of keyword strings to search for
        file_types: Optional list of extensions to filter (e.g. ['.mp3', '.mp4'])
        max_results: Maximum number of results to return
        max_depth: Maximum directory depth to traverse

    Returns:
        Ranked list of SearchResult objects
    """
    # Resolve file type filter
    allowed_exts: set[str] = set()
    if file_types:
        for ft in file_types:
            ft = ft.lower()
            if not ft.startswith("."):
                ft = "." + ft
            allowed_exts.add(ft)
            # Also expand group names
            if ft.lstrip(".") in FILE_TYPE_GROUPS:
                allowed_exts.update(FILE_TYPE_GROUPS[ft.lstrip(".")])

    results: list[SearchResult] = []

    def walk_sync():
        roots = _get_search_roots()
        for root in roots:
            _walk_dir(root, keywords, allowed_exts, results, 0, max_depth)

    # Run filesystem walk in a thread so we don't block the event loop
    loop = asyncio.get_event_loop()
    await loop.run_in_executor(None, walk_sync)

    # Sort by score descending, then by recency
    results.sort(key=lambda r: (-r.score, -(r.modified.timestamp() if r.modified else 0)))
    return results[:max_results]


def _walk_dir(
    directory: Path,
    keywords: list[str],
    allowed_exts: set[str],
    results: list[SearchResult],
    depth: int,
    max_depth: int,
):
    """Recursive directory walker with scoring."""
    if depth > max_depth:
        return

    try:
        entries = list(directory.iterdir())
    except (PermissionError, OSError):
        return

    for entry in entries:
        try:
            if entry.is_symlink():
                continue

            if entry.is_dir():
                if not _should_skip(entry):
                    _walk_dir(entry, keywords, allowed_exts, results, depth + 1, max_depth)

            elif entry.is_file():
                # Extension filter
                if allowed_exts and entry.suffix.lower() not in allowed_exts:
                    continue

                # Score the filename
                score = _score_match(entry.name, keywords)
                if score <= 0:
                    continue

                try:
                    stat = entry.stat()
                    size = stat.st_size
                    modified = datetime.fromtimestamp(stat.st_mtime)
                except OSError:
                    size = 0
                    modified = None

                results.append(SearchResult(
                    path=entry,
                    score=score,
                    size_bytes=size,
                    modified=modified,
                ))

        except (PermissionError, OSError):
            continue


def format_results_for_telegram(results: list[SearchResult]) -> str:
    """Format search results as a readable Telegram message."""
    if not results:
        return "🔍 No files found matching your search."

    lines = [f"🔍 *Found {len(results)} result{'s' if len(results) != 1 else ''}:*\n"]
    for i, r in enumerate(results, 1):
        lines.append(
            f"{i}️⃣ {r.icon} `{r.path.name}`\n"
            f"   📁 {r.short_path}\n"
            f"   💾 {r.size_human} · 🕐 {r.modified_human}"
        )
    lines.append("\n_Tap a button below to act on a file:_")
    return "\n".join(lines)
