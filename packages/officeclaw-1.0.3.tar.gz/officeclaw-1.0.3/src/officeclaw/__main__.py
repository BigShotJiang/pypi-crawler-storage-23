"""
Entry point for `python -m officeclaw`.
"""

from __future__ import annotations

from officeclaw.cli import main

if __name__ == "__main__":
    main()
