"""MCP server providing ground-truth Unreal Engine API documentation."""

__version__ = "0.1.1"
