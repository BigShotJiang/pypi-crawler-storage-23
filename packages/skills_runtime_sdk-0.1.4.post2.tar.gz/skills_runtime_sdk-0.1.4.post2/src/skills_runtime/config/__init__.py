"""配置 schema 与加载器。"""

from skills_runtime.config.defaults import load_default_config_dict

__all__ = ["load_default_config_dict"]
