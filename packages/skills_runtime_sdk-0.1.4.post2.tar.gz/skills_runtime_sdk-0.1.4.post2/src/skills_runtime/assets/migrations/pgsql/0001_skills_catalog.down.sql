BEGIN;

DROP TABLE IF EXISTS "agent"."skills_catalog";
DROP SCHEMA IF EXISTS "agent";

COMMIT;

