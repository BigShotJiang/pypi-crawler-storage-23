"""Entry point for PyInstaller binary and ``python -m octomil``."""

from octomil.cli import main

if __name__ == "__main__":
    main()
