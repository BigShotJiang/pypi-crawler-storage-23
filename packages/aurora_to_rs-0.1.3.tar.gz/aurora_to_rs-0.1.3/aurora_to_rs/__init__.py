#===============================================================================
#  aurora_to_rs - Aurora PostgreSQL -> S3 -> Redshift loader
#  Uses psycopg2 copy_expert (bypasses pandas, ~10x faster on large tables)
#  Flow: PG COPY TO STDOUT -> BytesIO -> S3 -> Redshift COPY FROM
#  Auth: IAM role only
#
#  3 strategies (1 public method each):
#    full_load        - TRUNCATE + COPY           (filter_cond = '1=1')
#    delete_and_insert - DELETE by filter + COPY   (del_table = 'Y')
#    upsert           - staging DELETE+INSERT      (everything else)
#===============================================================================

import csv
import io
import random
import string
import time
import boto3
from datetime import datetime
from botocore.config import Config

__version__ = '0.1.3'


class aurora_to_rs:
    """Aurora PostgreSQL -> S3 -> Redshift loader.

    Sample:
        loader = aurora_to_rs(
            region_name='ap-south-1', s3_bucket='my-bucket',
            redshift_c=redshift_conn,        # psycopg2 connection (autocommit=True)
            postgres_engine=pg_engine,        # SQLAlchemy engine
            iam_role_arn='arn:aws:iam::123456:role/MY_ROLE'
        )
        loader.full_load("SELECT * FROM master.items", "master.items")
        loader.delete_and_insert(src_sql, "tran.alloc_au", "dt>=current_date-1")
        loader.upsert(src_sql, "tran.orders", ['order_id'])
    """

    def __init__(self, region_name, s3_bucket, redshift_c, postgres_engine, iam_role_arn):
        self.region_name = region_name
        self.s3_bucket = s3_bucket
        self.redshift_c = redshift_c
        self.postgres_engine = postgres_engine
        self.iam_role_arn = iam_role_arn
        self.s3 = boto3.resource('s3', region_name=region_name, config=Config(
            region_name=region_name,
            retries={'max_attempts': 10, 'mode': 'adaptive'},
            max_pool_connections=100, connect_timeout=60, read_timeout=300
        ))

    #---------------------------------------------------------------------------
    # ✦✦ Internal: helpers ✦✦ #
    #---------------------------------------------------------------------------
    def _ts(self):
        return datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    def _s3_put(self, key, body):
        """Upload to S3 with exponential backoff on transient errors."""
        for attempt in range(5):
            try:
                self.s3.Object(self.s3_bucket, key).put(Body=body)
                return
            except Exception as e:
                if attempt < 4 and any(err in str(e) for err in ['SSL', 'EOF', 'Connection']):
                    print(f"[{self._ts()}] S3 retry {attempt+1}/5: {str(e)[:100]}")
                    time.sleep(2 ** attempt)
                    continue
                raise

    def _s3_delete(self, key):
        """Best-effort S3 cleanup."""
        try:
            self.s3.Object(self.s3_bucket, key).delete()
        except Exception:
            pass

    #---------------------------------------------------------------------------
    # ✦✦ Internal: Stream Aurora -> S3 ✦✦ #
    # PG COPY TO STDOUT -> strip \x00 -> parse header -> upload to S3
    # Returns (s3_key, columns_csv, row_count) or (None, None, 0) if empty
    #---------------------------------------------------------------------------
    def _stream_to_s3(self, source_sql, label=''):
        t0 = time.time()
        print(f"[{self._ts()}] [{label}] Streaming from Aurora...")

        raw_conn = self.postgres_engine.raw_connection()
        raw_cur = raw_conn.cursor()
        buf = io.BytesIO()
        raw_cur.copy_expert(f"COPY ({source_sql}) TO STDOUT WITH CSV HEADER NULL 'NULL'", buf)
        raw_cur.close()
        raw_conn.close()

        data = buf.getvalue().replace(b'\x00', b'')
        size_mb = len(data) / (1024 * 1024)
        print(f"[{self._ts()}] [{label}] {size_mb:.1f} MB in {int(time.time()-t0)}s")

        if data.strip() == b'':
            return None, None, 0

        header_end = data.index(b'\n')
        header_cols = next(csv.reader([data[:header_end].decode('utf-8').strip()]))
        columns = ','.join(c.replace('/', '_').replace('.', '_').replace('-', '_') for c in header_cols)
        row_count = data.count(b'\n') - 1

        s3_key = ''.join(random.choices(string.ascii_letters + string.digits, k=12)) + '.csv'
        self._s3_put(s3_key, data)
        print(f"[{self._ts()}] [{label}] S3 done in {int(time.time()-t0)}s | {row_count:,} rows")
        return s3_key, columns, row_count

    #---------------------------------------------------------------------------
    # ✦✦ Internal: Redshift COPY from S3 ✦✦ #
    #---------------------------------------------------------------------------
    def _redshift_copy(self, dest, s3_key, columns):
        self.redshift_c.cursor().execute(f"""
            COPY {dest} ({columns})
            FROM 's3://{self.s3_bucket}/{s3_key}'
            IAM_ROLE '{self.iam_role_arn}'
            CSV IGNOREHEADER 1 NULL AS 'NULL' REGION '{self.region_name}';
        """)

    #===========================================================================
    #  STRATEGY 1: full_load  (filter_cond = '1=1')
    #  TRUNCATE destination -> COPY all rows from Aurora
    #===========================================================================
    def full_load(self, source_sql, dest_table):
        """Full table refresh: TRUNCATE + COPY. Returns row_count.

        Sample:
            loader.full_load("SELECT * FROM master.items", "master.items")
        """
        s3_key = None
        cursor = self.redshift_c.cursor()
        try:
            s3_key, columns, row_count = self._stream_to_s3(source_sql, label=dest_table)
            cursor.execute("BEGIN;")
            cursor.execute(f"TRUNCATE TABLE {dest_table};")
            if row_count > 0:
                self._redshift_copy(dest_table, s3_key, columns)
            cursor.execute("COMMIT;")
            print(f"[{self._ts()}] [{dest_table}] full_load done | {row_count:,} rows")
            return row_count
        except Exception as e:
            cursor.execute("ROLLBACK;")
            print(f"[{self._ts()}] [{dest_table}] full_load error: {e}")
            raise
        finally:
            if s3_key:
                self._s3_delete(s3_key)

    #===========================================================================
    #  STRATEGY 2: delete_and_insert  (del_table = 'Y')
    #  DELETE rows matching filter_cond -> COPY fresh data from Aurora
    #  Optional min_timestamp overlap delete for safety
    #===========================================================================
    def delete_and_insert(self, source_sql, dest_table, filter_cond,
                          min_timestamp=None, timestamp_col=None):
        """Delete by filter, then COPY new data. Returns row_count.

        Sample:
            loader.delete_and_insert(
                "SELECT * FROM tran.shipment_au WHERE create_datetime >= current_date-3",
                "tran.shipment_au", "create_datetime >= current_date-3",
                min_timestamp='2026-02-19', timestamp_col='create_datetime'
            )
        """
        s3_key = None
        cursor = self.redshift_c.cursor()
        try:
            s3_key, columns, row_count = self._stream_to_s3(source_sql, label=dest_table)

            cursor.execute("BEGIN;")
            cursor.execute(f"DELETE FROM {dest_table} WHERE {filter_cond};")
            print(f"[{self._ts()}] [{dest_table}] Deleted by filter_cond")

            if min_timestamp is not None and timestamp_col is not None:
                cursor.execute(f"DELETE FROM {dest_table} WHERE {timestamp_col} >= '{min_timestamp}';")
                print(f"[{self._ts()}] [{dest_table}] Deleted by min_timestamp={min_timestamp}")

            if row_count > 0:
                self._redshift_copy(dest_table, s3_key, columns)

            cursor.execute("COMMIT;")
            print(f"[{self._ts()}] [{dest_table}] delete_and_insert done | {row_count:,} rows")
            return row_count
        except Exception as e:
            cursor.execute("ROLLBACK;")
            print(f"[{self._ts()}] [{dest_table}] delete_and_insert error: {e}")
            raise
        finally:
            cursor.close()
            if s3_key:
                self._s3_delete(s3_key)

    #===========================================================================
    #  STRATEGY 3: upsert  (everything else)
    #  COPY to staging table -> DELETE matching keys -> INSERT from staging
    #  NULL-safe key matching: (col=col OR (col IS NULL AND col IS NULL))
    #===========================================================================
    def upsert(self, source_sql, dest_table, upsert_columns):
        """Incremental upsert via staging table. Returns row_count.

        Sample:
            loader.upsert("SELECT * FROM tran.orders WHERE dt>=current_date-1",
                          "tran.orders", ['order_id'])
        """
        s3_key = None
        staging = dest_table + '_stgg'
        cursor = self.redshift_c.cursor()
        try:
            s3_key, columns, row_count = self._stream_to_s3(source_sql, label=dest_table)

            cursor.execute(f"DROP TABLE IF EXISTS {staging}; CREATE TABLE {staging} AS SELECT * FROM {dest_table} WHERE 1=0;")
            if row_count > 0:
                self._redshift_copy(staging, s3_key, columns)

            where_parts = []
            for col in upsert_columns:
                c = col.replace('"', '')
                where_parts.append(
                    f"({dest_table}.{c} = {staging}.{c} OR ({dest_table}.{c} IS NULL AND {staging}.{c} IS NULL))"
                )

            cursor.execute("BEGIN;")
            if row_count > 0:
                cursor.execute(f"DELETE FROM {dest_table} USING {staging} WHERE {' AND '.join(where_parts)};")
                cursor.execute(f"INSERT INTO {dest_table} SELECT * FROM {staging};")
            cursor.execute("COMMIT;")
            print(f"[{self._ts()}] [{dest_table}] upsert done | {row_count:,} rows")
            return row_count
        except Exception as e:
            cursor.execute("ROLLBACK;")
            print(f"[{self._ts()}] [{dest_table}] upsert error: {e}")
            raise
        finally:
            try:
                cursor.execute(f"DROP TABLE IF EXISTS {staging};")
            except Exception:
                pass
            if s3_key:
                self._s3_delete(s3_key)
