# -*- coding: utf-8 -*-
check_protected: bool = False
check_override: bool = False
