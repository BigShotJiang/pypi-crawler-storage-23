# USER.md - About the Human

* **Name:** User
* **Preferred name:** User
* **Timezone:** America/Chicago
* **Location:** Chicago, Illinois
* **Style:** Technical, concise, no fluff
