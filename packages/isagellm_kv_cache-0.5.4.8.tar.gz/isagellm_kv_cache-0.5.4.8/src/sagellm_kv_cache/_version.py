"""Version information for sagellm-kv-cache."""

__version__ = "0.5.4.8"
__author__ = "IntelliStream Team"
__email__ = "shuhao_zhang@hust.edu.cn"
