"""Bootstrap logic for the registry server FastAPI application."""
import json

from fastapi import FastAPI, APIRouter, HTTPException

from .storage import AgentRegistryLookup, McpRegistryLookup
from .dynamo_db import DynamoDbAgentRegistryLookup, DynamoDbMcpRegistryLookup
from .model import McpServer


def load_registry(
        agent_registry: AgentRegistryLookup = DynamoDbAgentRegistryLookup(agent_card_tabel="agent-cards"),
        mcp_registry: McpRegistryLookup = DynamoDbMcpRegistryLookup(mcp_table="mcp-servers")
) -> FastAPI:
    """Bootstraps the registry server FastAPI application.

    Args:
        agent_registry: The agent registry storage implementation.
        mcp_registry: The MCP registry storage implementation.

    Returns:
        A configured FastAPI application instance.
    """
    app = FastAPI()

    agent_lookup: AgentRegistryLookup = agent_registry
    mcp_lookup: McpRegistryLookup = mcp_registry

    agent_router = APIRouter()

    @agent_router.put("/agent-card/{name}")
    def put_agent_card(name: str, agent_card: dict, expire_at: str) -> None:
        """Endpoint to register or update an agent card."""
        agent_lookup.put_agent_card(name=name, card=json.dumps(agent_card), expire_at=expire_at)

    @agent_router.get("/agent-card/{name}")
    def get_agent_card(name: str) -> dict:
        """Endpoint to retrieve a specific agent card."""
        card_str = agent_lookup.get_agent_card(name=name)
        if card_str:
            return json.loads(card_str)
        raise HTTPException(status_code=404, detail="Agent card not found")

    @agent_router.get("/agent-cards")
    def get_agent_cards() -> list[dict]:
        """Endpoint to retrieve all agent cards."""
        return agent_lookup.get_agent_cards()

    @agent_router.patch("/agent-card/{name}/heartbeat")
    def patch_agent_heartbeat(name: str, expire_at: str) -> None:
        """Endpoint to update the heartbeat/expiration for an agent."""
        agent_lookup.update_agent_expiry(name=name, expire_at=expire_at)

    mcp_router = APIRouter()

    @mcp_router.put("/mcp/server")
    def put_mcp_tool(server: McpServer) -> None:
        """Endpoint to register or update an MCP server."""
        mcp_lookup.put_mcp_server(server=server)

    @mcp_router.get("/mcp/server/{name}")
    def get_mcp_tool(name: str) -> McpServer:
        """Endpoint to retrieve a specific MCP server."""
        tool = mcp_lookup.get_mcp_server(name=name)
        if tool:
            return tool
        raise HTTPException(status_code=404, detail="MCP Tool not found")

    @mcp_router.get("/mcp/servers")
    def get_mcp_servers() -> list[McpServer]:
        """Endpoint to retrieve all MCP servers."""
        return mcp_lookup.get_mcp_servers()

    @mcp_router.put("/mcp/{name}/agent/{agent_name}")
    def enable_mcp_server_for_agent(name: str, agent_name: str) -> None:
        """Endpoint to authorize an agent for an MCP server."""
        try:
            mcp_lookup.enable_mcp_server_for_agent(server_name=name, agent_name=agent_name)
        except Exception as e:
            raise HTTPException(status_code=404, detail=str(e))

    @mcp_router.delete("/mcp/{name}/agent/{agent_name}")
    def disable_mcp_server_for_agent(name: str, agent_name: str) -> None:
        """Endpoint to deauthorize an agent for an MCP server."""
        try:
            mcp_lookup.disable_mcp_server_for_agent(server_name=name, agent_name=agent_name)
        except Exception as e:
            raise HTTPException(status_code=404, detail=str(e))

    @mcp_router.get("/mcp/{name}/agent")
    def get_allowed_agents(name: str) -> set[str]:
        """Endpoint to retrieve all authorized agents for an MCP server."""
        return mcp_lookup.get_allowed_agents(server_name=name)

    @mcp_router.get("/mcp/agent/{agent_name}/servers")
    def get_mcp_server_for_agent(agent_name: str) -> list[McpServer]:
        """Endpoint to retrieve all MCP servers authorized for a specific agent."""
        return mcp_lookup.get_mcp_server_for_agent(agent_name=agent_name)

    app.include_router(agent_router)
    app.include_router(mcp_router)

    @app.get("/health")
    def health_check() -> dict:
        """Health check endpoint."""
        return {"status": "OK"}

    return app
