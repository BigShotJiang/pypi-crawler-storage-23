class PolyApiException(BaseException):
    """Generic error for the Poly API."""
    pass