"""Server core — accumulator, router, scheduler."""
