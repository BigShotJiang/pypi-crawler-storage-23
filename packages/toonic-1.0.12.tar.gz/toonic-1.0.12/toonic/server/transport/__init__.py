"""Transport layers — REST API + WebSocket."""
