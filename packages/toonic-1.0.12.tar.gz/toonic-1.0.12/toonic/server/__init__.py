"""
Toonic Server — bidirectional TOON streaming between data sources and LLMs.

Usage:
    python -m toonic.server            # start server
    python -m toonic.server --help     # show options
"""

__all__ = ["ServerConfig", "ToonicServer"]
