# Docs
Documentation for Stof. The "libs" directory is an auto-generated folder containing documentation for Stof libraries.

## Generate Libs
The test that generates the "libs" folder is located in "src/model/formats/stof/mod.rs", named "stof_docs". Run `cargo test` to regenerate.

## Contributing
Please improve the docs where you think needed so everyone can benefit.