from __future__ import annotations

from collections.abc import Iterable
from pathlib import Path

CONFIG_FILES: tuple[str, ...] = (
    "ruff.toml",
    "mypy.ini",
    "pyrightconfig.json",
    ".pre-commit-config.yaml",
)

DEV_DEP_SECTION_HEADER = "[tool.poetry.group.dev.dependencies]"
DEV_DEP_KEYS: tuple[str, ...] = (
    "ruff",
    "pre-commit",
    "pylint",
    "mypy",
    "pyright",
    "black",
)

__all__ = ["sync_ci_cd_configs"]


def _get_tp_common_root() -> Path:
    """
    Определить корень репозитория tp-common, откуда брать эталонные конфиги.

    Ожидается структура:
    tp-common/
      pyproject.toml
      ruff.toml
      mypy.ini
      pyrightconfig.json
      .pre-commit-config.yaml
      src/tp_common/devtools/__init__.py
    """

    # __file__ -> tp-common/src/tp_common/devtools/__init__.py
    # parents[0] = devtools
    # parents[1] = tp_common
    # parents[2] = src
    # parents[3] = tp-common (корень проекта)
    return Path(__file__).resolve().parents[3]


def _copy_config_files(source_root: Path, target_root: Path) -> None:
    """
    Скопировать конфигурационные файлы (ruff, mypy, pyright, pre-commit)
    из tp-common в целевой проект.
    """

    import shutil

    for name in CONFIG_FILES:
        src = source_root / name
        dst = target_root / name
        if not src.is_file():
            # Тихо пропускаем отсутствующие файлы — скрипт должен быть устойчивым.
            continue
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def _iter_section_lines(lines: list[str], start_index: int) -> tuple[int, int]:
    """
    Найти диапазон строк секции, начиная с заданного индекса заголовка.

    Возвращает (start, end), где end — индекс первой строки после секции.
    """

    start = start_index + 1
    end = start
    for i in range(start, len(lines)):
        stripped = lines[i].lstrip()
        if stripped.startswith("[") and not stripped.startswith("#["):
            end = i
            break
    else:
        end = len(lines)
    return start, end


def _find_section_header(lines: list[str], header: str) -> int | None:
    for index, line in enumerate(lines):
        if line.strip() == header:
            return index
    return None


def _load_source_dev_dependency_lines(source_root: Path) -> dict[str, str]:
    """
    Считать из pyproject.toml tp-common строки с dev-зависимостями
    для заданных ключей (ruff, pre-commit, pylint и т.д.).
    """

    pyproject_path = source_root / "pyproject.toml"
    content = pyproject_path.read_text(encoding="utf-8").splitlines()

    header_index = _find_section_header(content, DEV_DEP_SECTION_HEADER)
    if header_index is None:
        return {}

    start, end = _iter_section_lines(content, header_index)
    result: dict[str, str] = {}

    for line in content[start:end]:
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        for key in DEV_DEP_KEYS:
            if stripped.startswith(f"{key} ") or stripped.startswith(f"{key}="):
                result[key] = line
                break

    return result


def _sync_target_pyproject_dev_deps(
    target_pyproject: Path,
    source_dev_deps: dict[str, str],
) -> None:
    """
    Обновить/добавить секцию [tool.poetry.group.dev.dependencies] в целевом проекте,
    выровняв версии ruff/black/mypy/pyright/pre-commit/pylint с tp-common.
    """

    if not target_pyproject.is_file():
        msg = f"pyproject.toml не найден по пути: {target_pyproject}"
        raise FileNotFoundError(msg)

    lines = target_pyproject.read_text(encoding="utf-8").splitlines()

    header_index = _find_section_header(lines, DEV_DEP_SECTION_HEADER)

    if header_index is None:
        # Секции нет — добавляем её в конец файла.
        new_lines: list[str] = []
        if lines and lines[-1].strip():
            new_lines.append("")  # пустая строка перед новой секцией
        new_lines.append(DEV_DEP_SECTION_HEADER)

        for key in DEV_DEP_KEYS:
            line = source_dev_deps.get(key)
            if line:
                new_lines.append(line)

        final_lines = new_lines if not lines else lines + [""] + new_lines

        target_pyproject.write_text("\n".join(final_lines) + "\n", encoding="utf-8")
        return

    # Секция существует — аккуратно обновляем только нужные ключи.
    start, end = _iter_section_lines(lines, header_index)

    def _find_key_line_index(
        key: str,
        search_range: Iterable[int],
    ) -> int | None:
        for i in search_range:
            stripped = lines[i].strip()
            if stripped.startswith(f"{key} ") or stripped.startswith(f"{key}="):
                return i
        return None

    insert_position = end

    for key in DEV_DEP_KEYS:
        source_line = source_dev_deps.get(key)
        if not source_line:
            # В tp-common ключа нет — ничего не делаем.
            continue

        existing_index = _find_key_line_index(key, range(start, end))
        if existing_index is not None:
            # Обновляем строку на эталонную.
            lines[existing_index] = source_line
        else:
            # Добавляем новую строку перед окончанием секции.
            lines.insert(insert_position, source_line)
            insert_position += 1
            end += 1

    target_pyproject.write_text("\n".join(lines) + "\n", encoding="utf-8")


def sync_ci_cd_configs(target_project_root: str | Path | None = None) -> None:
    """
    Синхронизация CI/CD-конфигурации из tp-common в целевой проект.

    Делает две вещи:
    1. Копирует конфиги ruff/mypy/pyright/.pre-commit-config.yaml.
    2. Обновляет секцию [tool.poetry.group.dev.dependencies] в pyproject.toml
       целевого проекта, подставляя версии из tp-common.
    """

    tp_common_root = _get_tp_common_root()
    target_root = (
        Path(target_project_root).resolve()
        if target_project_root is not None
        else Path.cwd()
    )

    _copy_config_files(tp_common_root, target_root)

    source_dev_deps = _load_source_dev_dependency_lines(tp_common_root)
    if not source_dev_deps:
        # Нечего синхронизировать по dev-зависимостям.
        return

    target_pyproject = target_root / "pyproject.toml"
    _sync_target_pyproject_dev_deps(target_pyproject, source_dev_deps)
