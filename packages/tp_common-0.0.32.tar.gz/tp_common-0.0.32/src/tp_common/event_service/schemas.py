from __future__ import annotations

from enum import Enum
from typing import Any, TypeVar, get_args, get_origin

from pydantic import BaseModel, ConfigDict, Field, model_validator

PayloadT = TypeVar("PayloadT", bound=BaseModel)
EventT = TypeVar("EventT", bound=Enum)

_RESERVED = frozenset({"before", "after", "event"})


def _get_payload_class(cls: type) -> type[BaseModel] | None:
    """Извлекает PayloadT: по аннотации after или по __orig_bases__ (PEP 695)."""
    # 1) По аннотации поля after (работает, если тип разрешён)
    if hasattr(cls, "model_fields"):
        for field_name in ("after", "before"):
            if field_name not in cls.model_fields:
                continue
            annotation = cls.model_fields[field_name].annotation
            origin = get_origin(annotation)
            if origin is not None:
                args = get_args(annotation)
                for arg in args:
                    if (
                        arg is not type(None)
                        and isinstance(arg, type)
                        and issubclass(arg, BaseModel)
                    ):
                        return arg
            elif isinstance(annotation, type) and issubclass(annotation, BaseModel):
                return annotation
    # 2) Fallback: __orig_bases__ (наследник BaseEventMessage[User, UserEvent] и т.п.)
    for base in getattr(cls, "__orig_bases__", ()):
        args = get_args(base)
        if args and isinstance(args[0], type) and issubclass(args[0], BaseModel):
            return args[0]
    return None


class RawEventPayload(BaseModel):
    """
    Схема сырого payload из Kafka (bytes → JSON).
    Поля before, after, event — как приходят из Debezium/топика.
    """

    before: dict[str, Any] | None = Field(
        None, description="Данные до изменений (сырой dict)"
    )
    after: dict[str, Any] | None = Field(
        None, description="Данные после изменений (сырой dict)"
    )
    event: str = Field(
        ..., description="Тип события: c/u/d/r или create/update/delete/snapshot"
    )

    model_config = ConfigDict(extra="allow")

    @model_validator(mode="after")
    def _validate_before_or_after(self: RawEventPayload) -> RawEventPayload:
        """Хотя бы одно из before или after должно быть задано; допускаются оба поля."""
        if self.before is None and self.after is None:
            raise ValueError("Должен быть задан before или after; допускаются оба поля")
        return self


class BaseEventMessage[PayloadT: BaseModel, EventT: Enum](BaseModel):
    before: PayloadT | None = Field(None, description="Схема до изменений")
    after: PayloadT | None = Field(None, description="Схема после изменений")
    event: EventT = Field(..., description="Тип события")

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    @model_validator(mode="after")
    def _validate_before_or_after(
        self: BaseEventMessage[PayloadT, EventT],
    ) -> BaseEventMessage[PayloadT, EventT]:
        """Хотя бы одно из before или after должно быть задано; допускаются оба поля."""
        if self.before is None and self.after is None:
            raise ValueError("Должен быть задан before или after; допускаются оба поля")
        return self

    def get_payload(self) -> PayloadT:
        """
        Возвращает актуальный payload из сообщения: after, если есть, иначе before.
        Удобно для обработки события без разбора create/update/delete — всегда есть
        один объект для работы (текущее состояние для create/update, предыдущее для delete).
        """
        if self.after is not None:
            return self.after
        if self.before is not None:
            return self.before
        raise AssertionError("Недопустимо: before и after оба None (валидация)")

    # @model_validator(mode="after")
    # def _forward_after_fields(
    #     self: BaseEventMessage[PayloadT, EventT],
    # ) -> BaseEventMessage[PayloadT, EventT]:
    #     """
    #     Для полей, объявленных в наследнике и совпадающих с полями схемы payload,
    #     подставляет значения из after (в рантайме). Позволяет писать id, name и т.д.
    #     без хардкода — достаточно объявить поле в сообщении.
    #     """
    #     payload_cls = _get_payload_class(self.__class__)
    #     if payload_cls is None and self.after is not None:
    #         payload_cls = type(self.after)
    #     if payload_cls is None or not hasattr(payload_cls, "model_fields"):
    #         return self
    #     # Обращение к model_fields только у класса (не у инстанса), совместимость с Pydantic v3
    #     payload_field_names = set(payload_cls.model_fields.keys())
    #     message_field_names = self.__class__.model_fields
    #     for name in payload_field_names:
    #         if name in _RESERVED or name not in message_field_names:
    #             continue
    #         value = getattr(self.after, name, None) if self.after is not None else None
    #         object.__setattr__(self, name, value)
    #     return self
