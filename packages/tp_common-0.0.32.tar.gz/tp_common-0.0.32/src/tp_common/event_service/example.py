import random
from datetime import datetime
from enum import Enum

from pydantic import BaseModel

from tp_common.event_service.schemas import BaseEventMessage
from tp_common.event_service.service import BaseEvent
from tp_common.kafka.connector import KafkaConnector
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLogger

log_factory = TpLogger(env=EnvironmentType.LOCAL)


def get_kafka() -> KafkaConnector:
    """Коннектор без логгера; BaseEvent при создании consumer/producer вызовет connector.set_logger(self.logger)."""
    return KafkaConnector("sasl_plaintext://user:user1122@@192.168.81.61:9094")


class EventGroup(str, Enum):
    USERS = "users"


class UserEvent(str, Enum):
    CREATE = "create"
    UPDATE = "update"
    DELETE = "delete"

    CHANGE_NAME = "change_name"


class User(BaseModel):
    id: int
    name: str
    description: str | None = None
    is_active: bool
    created_at: datetime
    updated_at: datetime | None = None


class UserEventMessage(BaseEventMessage[User, UserEvent]):
    """Сообщение события пользователя."""


class UserEventService(BaseEvent[UserEventMessage, UserEvent]):
    """Дескриптор события пользователей."""

    SERVICE_NAME = "postgres"
    EVENT_GROUP = EventGroup.USERS
    MESSAGE_CLASS = UserEventMessage
    EVENT_TYPE_CLASS = UserEvent


logger = log_factory.get_logger("api_service")

# subscribe_to: только эти типы событий обрабатываются; остальные коммитятся и пропускаются
event = UserEventService(
    connector=get_kafka(),
    consumer_group="worker_format_C",
    log=logger,
)


def main() -> None:
    """
    Цикл: with subscription() — подписка/отписка; with pop() as message — чтение.
    Несовпадение схем обрабатывается внутри BaseEvent: остановка, затем каждые 10 мин Critical.
    """
    while True:
        logger.debug("Получаю сообщения")

        try:

            with event.subscription():
                while True:
                    with event.pop() as message:

                        logger.debug("Event: %s", message.event)
                        logger.debug("Before: %s", message.before)
                        logger.debug("After: %s", message.after)

                        if random.random() < 0.90:
                            logger.debug("Публикация сообщения")
                            message.event = UserEvent.CHANGE_NAME
                            event.publish(message)

                        if random.random() < 0.15:
                            raise ValueError("Ошибка логики работы программы")

        except Exception as e:
            logger.exception("Ошибка в цикле событий: %s", e)


if __name__ == "__main__":
    main()
