#!/usr/bin/env python

#####################################################
#
#   Genset Plotter
#
#   Extract timestamp info from DEFAULT section
#
#   2010-08-21  Todd Valentic
#               Initial implementation
#
#####################################################

from Transport.Components   import PlotTool
from Transport.Util         import removeFile
from Transport              import NewsTool

from dateutil import parser

import sys
import ConfigParser

class PlotGenset(PlotTool):

    def parse(self,message):

        filenames = NewsTool.saveFiles(message)

        self.data = ConfigParser.ConfigParser()
        self.data.read(filenames)

        removeFile(filenames)

        return True

    def getTimestamp(self,message):
        timestamp = self.data.get('DEFAULT','timestamp')
        timestamp = parser.parse(timestamp).replace(tzinfo=self.utc)
        return timestamp

if __name__ == '__main__':
    PlotGenset(sys.argv).run()
