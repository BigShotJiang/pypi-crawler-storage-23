#!/usr/bin/env python

#######################################################
#
#   Simulated SBC data producer
#
#   Post data records into a news group.
#
#   2010-08-21  Todd Valentic
#               Initial implementation
#
#######################################################

from Transport      import ProcessClient
from Transport      import NewsPostMixin

import sys
import random

class SBC(ProcessClient,NewsPostMixin):

    def __init__(self,argv):
        ProcessClient.__init__(self,argv)
        NewsPostMixin.__init__(self)

        self.rate = self.getRate('rate')

    def run(self):

        while self.wait(self.rate):

            try:
                self.process()
            except:
                self.log.exception('Problem processing')

    def process(self):

        data = self.createData()

        self.newsPoster.postText(data,date=self.currentTime())

        self.log.debug('Posted data')

    def createData(self):

        fanState = random.randint(0,1)

        data = '[fan] %s' % fanState

        return data

if __name__ == '__main__':
    SBC(sys.argv).run()

