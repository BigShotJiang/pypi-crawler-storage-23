#!/usr/bin/env python

##########################################################
#
#   Hello World
#
#   Print a message to the log
#
#   2010-08-16  Todd Valentic
#               Initial implementation
#
##########################################################

from Transport import ProcessClient

import sys

class HelloWorld (ProcessClient):

    def __init__(self,argv):
        ProcessClient.__init__(self,argv)

        self.rate    = self.getRate('rate','1:00')
        self.message = self.get('message')

        if self.message is None:
            self.abort('You need to specify a message')

        self.log.info('Rate: %s' % self.rate)

    def run(self):

        while self.wait(self.rate):
            self.log.info(self.message)

if __name__ == '__main__':
    HelloWorld(sys.argv).run()

