#!/usr/bin/env python

##########################################################
#
#   Example 2 - post a news message 
#
#   Post a message to the news group 
#
#   2010-08-16  Todd Valentic
#               Initial implementation
#
##########################################################

from Transport import ProcessClient
from Transport import NewsPostMixin

import sys

class PostExample(ProcessClient,NewsPostMixin):

    def __init__(self,argv):
        ProcessClient.__init__(self,argv)
        NewsPostMixin.__init__(self)

        self.rate    = self.getDeltaTime('rate','1:00')
        self.message = self.get('message')

        if self.message is None:
            self.abort('You need to specify a message')

        self.log.info('Rate: %s' % self.rate)

    def run(self):

        while self.wait(self.rate,sync=True):
            self.newsPoster.postText(self.message)
            self.log.info('Posted message')

if __name__ == '__main__':
    PostExample(sys.argv).run()

