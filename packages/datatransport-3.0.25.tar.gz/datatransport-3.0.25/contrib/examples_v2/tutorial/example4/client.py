#!/usr/bin/env python

###########################################################
#
#   XMLRPC Client Program
#
#   How to user an XMLRPC service
#
#   2010-08-19  Todd Valentic
#               Initial implementation
#
###########################################################

from Transport  import ProcessClient
from Transport  import DirectoryMixin

import sys

class Client (ProcessClient, DirectoryMixin):

    def __init__(self,argv):
        ProcessClient.__init__(self,argv)
        DirectoryMixin.__init__(self)

        self.systemstatus = self.connect('systemstatus')

    def run(self):

        while self.wait(5):
            load = self.systemstatus.load()
            uptime = self.systemstatus.uptime()

            self.log.info('Load: %s' % load)
            self.log.info('Uptime: %s' % uptime)


if __name__ == '__main__':
    Client(sys.argv).run()
