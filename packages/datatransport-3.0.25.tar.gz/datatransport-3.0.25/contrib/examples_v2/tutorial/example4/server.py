#!/usr/bin/env python

##################################################
#
#   Uptime Service
#
#   2010-08-19  Todd Valentic
#               Initial implementation
#
##################################################

from Transport  import ProcessClient
from Transport  import XMLRPCServerMixin

import sys

class Server (ProcessClient, XMLRPCServerMixin):

    def __init__(self,argv):
        ProcessClient.__init__(self,argv)
        XMLRPCServerMixin.__init__(self)

        self.register_function(self.uptime)
        self.register_function(self.load)

    def uptime(self):
        return open('/proc/uptime').read() 

    def load(self):
        return open('/proc/loadavg').read() 

if __name__ == '__main__':
    Server(sys.argv).run()


