"""Allow running as ``python -m fin_pocket``."""

from fin_pocket.cli import _cli_entry

_cli_entry()
