"""Core application primitives."""

from ppbase.core.id_generator import generate_id

__all__ = ["generate_id"]
