"""OpenSpec package."""
