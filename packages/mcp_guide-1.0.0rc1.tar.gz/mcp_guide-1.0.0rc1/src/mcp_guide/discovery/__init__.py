"""Pattern matching and file/command discovery."""
