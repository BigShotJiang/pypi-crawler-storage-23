"""
Zarr v3 store backed by async-hdf5.

Provides ``HDF5Store``, a read-only Zarr v3 store that wraps async-hdf5
objects and defers chunk index parsing until chunks are actually requested.
Dataset metadata (shape, dtype, filters, chunk_shape) is parsed eagerly at
open time since it's cheap, but the expensive B-tree / FixedArray traversal
for chunk locations only happens on first access to each variable's data.

This module also provides ``open_hdf5``, an async convenience function
that creates and returns an ``HDF5Store``.  The store can be opened as an
xarray Dataset via ``xr.open_dataset(store, engine="zarr", ...)``.

``zarr`` is a **required** dependency; ``xarray`` is **optional**.
"""

from __future__ import annotations

import re
import warnings
from collections.abc import AsyncGenerator, Iterable
from typing import TYPE_CHECKING, Any, Literal

import numpy as np
from zarr.abc.store import (
    ByteRequest,
    OffsetByteRequest,
    RangeByteRequest,
    Store,
    SuffixByteRequest,
)
from zarr.core.buffer import Buffer, BufferPrototype
from zarr.core.buffer.core import default_buffer_prototype as _default_prototype
from zarr.core.common import BytesLike
from zarr.core.group import GroupMetadata
from zarr.core.metadata.v3 import ArrayV3Metadata

from async_hdf5 import HDF5Dataset, HDF5File
from async_hdf5._utils import assign_phony_dims, hdf5_filters_to_zarr_codecs

if TYPE_CHECKING:
    import asyncio

    from async_hdf5 import ChunkIndex, ObspecInput
    from async_hdf5.store import ObjectStore

__all__ = ["HDF5Store", "open_hdf5"]

# When the total number of chunks exceeds this threshold, listing methods
# resolve the chunk index and yield only allocated chunks instead of
# enumerating the full Cartesian product of the grid shape.  This prevents
# hangs on large, sparse datasets (e.g. shape 10^9 × 10^9 with small chunks).
_MAX_DENSE_GRID_SIZE = 10_000_000


# ---------------------------------------------------------------------------
# Chunk key parsing (adapted from VirtualiZarr manifests/utils.py)
# ---------------------------------------------------------------------------

_CHUNK_KEY_RE = re.compile(r"c\.(.+)$")


def _parse_chunk_key(suffix: str, separator: str = ".") -> tuple[int, ...]:
    """Parse a chunk key suffix like ``'c.3.5'`` into index tuple ``(3, 5)``."""
    if suffix == "c":
        return ()  # scalar array
    prefix = f"c{separator}"
    if not suffix.startswith(prefix):
        raise ValueError(f"Unexpected chunk key format: {suffix!r}")
    indices_str = suffix[len(prefix) :]
    return tuple(int(x) for x in indices_str.split(separator))


# ---------------------------------------------------------------------------
# Fill value decoding
# ---------------------------------------------------------------------------


def _decode_fill_value(raw: list[int] | None, numpy_dtype: str) -> int | float | None:
    """Convert raw fill value bytes from the HDF5 parser to a numpy scalar.

    Args:
        raw: Raw fill value as a list of byte values (from Rust ``Vec<u8>``
            via PyO3), or ``None`` if no fill value is defined.
        numpy_dtype: Numpy dtype string for the dataset (e.g. ``"<f4"``).

    Returns:
        A Python scalar suitable for Zarr's ``ArrayV3Metadata(fill_value=...)``,
        or ``None`` if no fill value is defined.

    Raises:
        ValueError: If *raw* cannot be interpreted as *numpy_dtype*
            (e.g. byte count mismatch).
    """
    if raw is None:
        return None
    raw_bytes = bytes(raw)
    dt = np.dtype(numpy_dtype)
    if len(raw_bytes) != dt.itemsize:
        raise ValueError(
            f"Fill value has {len(raw_bytes)} byte(s) but dtype {numpy_dtype!r} "
            f"expects {dt.itemsize}. Raw bytes: {raw_bytes!r}"
        )
    return np.frombuffer(raw_bytes, dtype=dt).flat[0].item()


# ---------------------------------------------------------------------------
# Attribute sanitization
# ---------------------------------------------------------------------------


def _sanitize_attrs(attrs: dict[str, Any]) -> dict[str, Any]:
    """Convert HDF5 attributes to JSON-serializable Python types.

    Zarr's ``GroupMetadata`` serializes attributes to JSON.  HDF5 attributes
    can include ``bytes`` (from ``AttributeValue::Raw``), numpy arrays, and
    numpy scalars that aren't directly JSON-compatible.

    Binary attributes that can't be decoded as UTF-8 are dropped, and a
    :func:`warnings.warn` lists every dropped key so the user can investigate.
    """
    clean: dict[str, Any] = {}
    non_serializable: list[tuple[str, str, str]] = []

    for k, v in attrs.items():
        if isinstance(v, bytes):
            try:
                clean[k] = v.decode("utf-8")
            except UnicodeDecodeError:
                non_serializable.append((k, type(v).__name__, repr(v[:32])))
                continue
        elif isinstance(v, np.ndarray):
            clean[k] = v.tolist()
        elif isinstance(v, (np.integer, np.floating)):
            clean[k] = v.item()
        else:
            clean[k] = v

    if non_serializable:
        details = "; ".join(f"{k} ({t}): {r}" for k, t, r in non_serializable)
        warnings.warn(
            f"Dropped {len(non_serializable)} non-serializable attribute(s): "
            f"{details}. These contain raw bytes that cannot be represented "
            f"in Zarr metadata.",
            stacklevel=2,
        )
    return clean


# ---------------------------------------------------------------------------
# Dataset info: lightweight metadata cache (no chunk index)
# ---------------------------------------------------------------------------


class _DatasetInfo:
    """Cached metadata for one HDF5 dataset, without its chunk index."""

    __slots__ = (
        "name",
        "shape",
        "numpy_dtype",
        "element_size",
        "chunk_shape",
        "fill_value",
        "filters",
        "dimension_names",
        "hdf5_dataset",
        "_array_metadata",
        "_zarr_json_bytes",
    )

    def __init__(
        self,
        ds: HDF5Dataset,
        dimension_names: tuple[str, ...],
    ) -> None:
        self.name: str = ds.name
        self.shape: tuple[int, ...] = tuple(int(s) for s in ds.shape)
        self.numpy_dtype: str = ds.numpy_dtype
        self.element_size: int = ds.element_size
        self.chunk_shape: tuple[int, ...] = tuple(
            int(s) for s in (ds.chunk_shape or ds.shape)
        )
        self.fill_value: int | float | None = _decode_fill_value(
            ds.fill_value, ds.numpy_dtype
        )
        self.filters: list[dict[str, Any]] = ds.filters
        self.dimension_names = dimension_names
        self.hdf5_dataset: HDF5Dataset = ds
        self._array_metadata: ArrayV3Metadata | None = None
        self._zarr_json_bytes: bytes | None = None

        # --- Guards: fail loudly instead of producing silent wrong data ---

        # Skip datasets with null dataspace (no data)
        if ds.is_null_dataspace:
            raise ValueError("Dataset has null dataspace (no data)")

        # Skip datasets using external data files
        if ds.has_external_storage:
            raise ValueError(
                "Dataset uses external data files (not supported). "
                "Use drop_variables to skip this dataset."
            )

        # Validate numpy dtype is understood by numpy
        np.dtype(self.numpy_dtype)

        # Validate all HDF5 filters have a Zarr codec mapping
        hdf5_filters_to_zarr_codecs(self.filters, self.element_size)

    @property
    def array_metadata(self) -> ArrayV3Metadata:
        if self._array_metadata is None:
            self._array_metadata = _create_array_metadata(self)
        return self._array_metadata

    @property
    def zarr_json_bytes(self) -> bytes:
        if self._zarr_json_bytes is None:
            buf_dict = self.array_metadata.to_buffer_dict(
                prototype=_default_prototype()
            )
            self._zarr_json_bytes = buf_dict["zarr.json"].to_bytes()
        return self._zarr_json_bytes

    @property
    def grid_shape(self) -> tuple[int, ...]:
        return tuple(
            -(-s // c) for s, c in zip(self.shape, self.chunk_shape, strict=True)
        )


def _create_array_metadata(info: _DatasetInfo) -> ArrayV3Metadata:
    """Build Zarr v3 array metadata from cached dataset info."""
    from virtualizarr.codecs import convert_to_codec_pipeline
    from zarr.dtype import parse_data_type

    codecs_config = hdf5_filters_to_zarr_codecs(info.filters, info.element_size)
    dt = np.dtype(info.numpy_dtype)
    zdtype = parse_data_type(dt, zarr_format=3)

    return ArrayV3Metadata(
        shape=info.shape,
        data_type=zdtype,
        chunk_grid={
            "name": "regular",
            "configuration": {"chunk_shape": info.chunk_shape},
        },
        chunk_key_encoding={"name": "default"},
        fill_value=(
            zdtype.default_scalar() if info.fill_value is None else info.fill_value
        ),
        codecs=convert_to_codec_pipeline(codecs=codecs_config, dtype=dt),
        attributes={},
        dimension_names=info.dimension_names,
        storage_transformers=None,
    )


# ---------------------------------------------------------------------------
# Chunk batcher (DataLoader pattern)
# ---------------------------------------------------------------------------


class _ChunkBatcher:
    """Accumulates chunk requests within one event-loop tick and flushes them
    as a single ``HDF5Dataset.batch_fetch_ranges()`` call.

    zarr-python's codec pipeline calls ``store.get()`` individually per chunk
    via ``asyncio.gather``.  Because all those coroutines are scheduled in the
    same tick, we can collect them and issue one batched Rust-level fetch that
    uses ``object_store::get_ranges()`` under the hood.

    The chunk index (B-tree) is resolved once on first flush and cached.
    Subsequent flushes only perform the raw data fetch.
    """

    __slots__ = ("_dataset", "_chunk_index", "_pending", "_flush_scheduled")

    def __init__(self, hdf5_dataset: HDF5Dataset) -> None:
        self._dataset = hdf5_dataset
        self._chunk_index: ChunkIndex | None = None
        self._pending: list[tuple[list[int], asyncio.Future[bytes | None]]] = []
        self._flush_scheduled = False

    async def get_chunk(self, indices: list[int]) -> bytes | None:
        """Request a single chunk.  The actual I/O is deferred until flush."""
        import asyncio

        loop = asyncio.get_running_loop()
        future: asyncio.Future[bytes | None] = loop.create_future()
        self._pending.append((indices, future))
        if not self._flush_scheduled:
            self._flush_scheduled = True
            loop.call_soon(lambda: asyncio.ensure_future(self._flush()))
        return await future

    async def _flush(self) -> None:
        self._flush_scheduled = False
        batch = self._pending
        self._pending = []
        if not batch:
            return

        # Resolve chunk index once (B-tree traversal via BlockCache)
        if self._chunk_index is None:
            self._chunk_index = await self._dataset.chunk_index()

        futures = [b[1] for b in batch]
        try:
            # Look up byte ranges in Python (fast, cached index)
            ranges: list[tuple[int, int]] = []
            range_map: list[int | None] = []
            for indices, _fut in batch:
                loc = self._chunk_index.get(indices)
                if loc is not None:
                    range_map.append(len(ranges))
                    ranges.append((loc.byte_offset, loc.byte_length))
                else:
                    range_map.append(None)

            if ranges:
                # Single batched fetch via raw reader (bypasses BlockCache)
                fetched = await self._dataset.batch_fetch_ranges(ranges)
            else:
                fetched = []

            for fut, mapping in zip(futures, range_map, strict=True):
                if not fut.done():
                    fut.set_result(fetched[mapping] if mapping is not None else None)
        except Exception as exc:
            for fut in futures:
                if not fut.done():
                    fut.set_exception(exc)


# ---------------------------------------------------------------------------
# HDF5Store
# ---------------------------------------------------------------------------


class HDF5Store(Store):
    """Read-only Zarr v3 store backed by async-hdf5 with lazy chunk index resolution.

    Dataset metadata (shape, dtype, codecs, etc.) is parsed eagerly at
    construction — this is fast because the data is already in async-hdf5's
    BlockCache from the superblock / group parse.  Chunk indices (B-tree /
    FixedArray traversal) are parsed lazily on first chunk access per variable.

    Args:
        dataset_infos: Mapping from variable name to ``_DatasetInfo``
            (pre-parsed metadata).
        group_attrs: Root group attributes.
        file_url: Full URL of the HDF5 file (used for equality checks).
    """

    _dataset_infos: dict[str, _DatasetInfo]
    _group_attrs: dict[str, Any]
    _file_url: str
    _chunk_indices: dict[str, ChunkIndex]
    _batchers: dict[str, _ChunkBatcher]
    _group_metadata: GroupMetadata

    def __init__(
        self,
        *,
        dataset_infos: dict[str, _DatasetInfo],
        group_attrs: dict[str, Any],
        file_url: str,
    ) -> None:
        super().__init__(read_only=True)
        self._dataset_infos = dataset_infos
        self._group_attrs = group_attrs
        self._file_url = file_url
        self._chunk_indices = {}
        self._batchers = {}
        self._group_metadata = GroupMetadata(attributes=_sanitize_attrs(group_attrs))

    def __eq__(self, other: object) -> bool:
        return isinstance(other, HDF5Store) and self._file_url == other._file_url

    # ------------------------------------------------------------------
    # Core read
    # ------------------------------------------------------------------

    async def get(
        self,
        key: str,
        prototype: BufferPrototype,
        byte_range: ByteRequest | None = None,
    ) -> Buffer | None:
        await self._ensure_open()

        # Root group metadata
        if key == "zarr.json":
            return self._get_group_metadata(prototype)

        # Split into variable name and remainder
        if "/" not in key:
            return None
        var_name, suffix = key.split("/", 1)

        # Check for v2 metadata keys → return None (Zarr v3 only)
        if suffix.endswith((".zattrs", ".zgroup", ".zarray", ".zmetadata")):
            return None

        info = self._dataset_infos.get(var_name)
        if info is None:
            return None

        # Array metadata
        if suffix == "zarr.json":
            return prototype.buffer.from_bytes(info.zarr_json_bytes)

        # Chunk data — lazily resolve chunk index
        return await self._get_chunk_data(var_name, info, suffix, prototype, byte_range)

    def _ensure_batcher(self, var_name: str) -> _ChunkBatcher:
        """Get or create a chunk batcher for the given variable."""
        if var_name not in self._batchers:
            info = self._dataset_infos[var_name]
            self._batchers[var_name] = _ChunkBatcher(info.hdf5_dataset)
        return self._batchers[var_name]

    async def _get_chunk_data(
        self,
        var_name: str,
        info: _DatasetInfo,
        suffix: str,
        prototype: BufferPrototype,
        byte_range: ByteRequest | None,
    ) -> Buffer | None:
        """Fetch chunk data via batched Rust-level I/O."""
        separator: str = getattr(
            info.array_metadata.chunk_key_encoding, "separator", "/"
        )
        indices = _parse_chunk_key(suffix, separator)

        batcher = self._ensure_batcher(var_name)
        raw_data = await batcher.get_chunk(list(indices))
        if raw_data is None:
            return None

        # Apply byte_range slicing if the codec pipeline requests a sub-range
        if byte_range is not None:
            chunk_len = len(raw_data)
            resolved = _transform_byte_range(
                byte_range, chunk_start=0, chunk_end_exclusive=chunk_len
            )
            raw_data = raw_data[resolved.start : resolved.end]

        return prototype.buffer.from_bytes(raw_data)

    def _get_group_metadata(self, prototype: BufferPrototype) -> Buffer:
        buf_dict = self._group_metadata.to_buffer_dict(prototype=prototype)
        return buf_dict["zarr.json"]

    # ------------------------------------------------------------------
    # Batch read
    # ------------------------------------------------------------------

    async def get_partial_values(
        self,
        prototype: BufferPrototype,
        key_ranges: Iterable[tuple[str, ByteRequest | None]],
    ) -> list[Buffer | None]:
        import asyncio

        return list(
            await asyncio.gather(
                *(
                    self.get(key, prototype, byte_range)
                    for key, byte_range in key_ranges
                )
            )
        )

    # ------------------------------------------------------------------
    # Existence
    # ------------------------------------------------------------------

    async def exists(self, key: str) -> bool:
        if key == "zarr.json":
            return True
        if "/" not in key:
            return False
        var_name, suffix = key.split("/", 1)
        if var_name not in self._dataset_infos:
            return False
        if suffix == "zarr.json":
            return True
        # For chunk keys, we'd need to check the chunk index — return True
        # optimistically since zarr-python typically only requests valid keys.
        return True

    # ------------------------------------------------------------------
    # Write stubs (read-only store)
    # ------------------------------------------------------------------

    @property
    def supports_writes(self) -> bool:
        return False

    @property
    def supports_deletes(self) -> bool:
        return False

    @property
    def supports_partial_writes(self) -> Literal[False]:
        return False

    async def set(self, key: str, value: Buffer) -> None:
        raise NotImplementedError("HDF5Store is read-only")

    async def set_if_not_exists(self, key: str, value: Buffer) -> None:
        raise NotImplementedError("HDF5Store is read-only")

    async def delete(self, key: str) -> None:
        raise NotImplementedError("HDF5Store is read-only")

    async def set_partial_values(
        self, key_start_values: Iterable[tuple[str, int, BytesLike]]
    ) -> None:
        raise NotImplementedError("HDF5Store is read-only")

    # ------------------------------------------------------------------
    # Listing
    # ------------------------------------------------------------------

    @property
    def supports_listing(self) -> bool:
        return True

    async def list(self) -> AsyncGenerator[str, None]:
        yield "zarr.json"
        for name, info in self._dataset_infos.items():
            separator: str = getattr(
                info.array_metadata.chunk_key_encoding, "separator", "/"
            )
            yield f"{name}/zarr.json"
            if info.shape == ():
                yield f"{name}/c"
            else:
                async for key in self._iter_chunk_keys_for(name, info, separator):
                    yield f"{name}/c{separator}{key}"

    async def list_prefix(self, prefix: str) -> AsyncGenerator[str, None]:
        async for key in self.list():
            if key.startswith(prefix):
                yield key

    async def list_dir(self, prefix: str) -> AsyncGenerator[str, None]:
        prefix = prefix.rstrip("/")
        if prefix == "":
            # Root: group metadata + variable names
            yield "zarr.json"
            for name in self._dataset_infos:
                yield name
        else:
            # Variable directory: metadata + chunk keys
            info = self._dataset_infos.get(prefix)
            if info is not None:
                separator = getattr(
                    info.array_metadata.chunk_key_encoding, "separator", "/"
                )
                yield "zarr.json"
                if info.shape == ():
                    yield "c"
                else:
                    async for key in self._iter_chunk_keys_for(prefix, info, separator):
                        yield f"c{separator}{key}"

    async def _iter_chunk_keys_for(
        self,
        var_name: str,
        info: _DatasetInfo,
        separator: str,
    ) -> AsyncGenerator[str, None]:
        """Yield chunk keys for a variable.

        For small grids (< 10 million chunks) this yields the full Cartesian
        product.  For large grids the chunk index is resolved first and only
        keys for *allocated* chunks are yielded — this avoids hanging on sparse
        datasets with enormous grid shapes.
        """
        import math

        total = math.prod(info.grid_shape) if info.grid_shape else 1
        if total <= _MAX_DENSE_GRID_SIZE:
            for key in _iter_chunk_keys(info.grid_shape, separator):
                yield key
        else:
            # Sparse path: resolve the chunk index and yield only existing keys
            batcher = self._ensure_batcher(var_name)
            if batcher._chunk_index is None:
                batcher._chunk_index = await info.hdf5_dataset.chunk_index()
            for loc in batcher._chunk_index:
                yield separator.join(str(i) for i in loc.indices)

    @property
    def supports_consolidated_metadata(self) -> bool:
        return False


def _iter_chunk_keys(
    grid_shape: tuple[int, ...], separator: str = "/"
) -> Iterable[str]:
    """Yield chunk keys like '0/0', '0/1', ... for a given grid shape."""
    if len(grid_shape) == 0:
        return
    import itertools

    ranges = [range(s) for s in grid_shape]
    for idx in itertools.product(*ranges):
        yield separator.join(str(i) for i in idx)


# ---------------------------------------------------------------------------
# Byte range transformation (same as VirtualiZarr ManifestStore)
# ---------------------------------------------------------------------------


def _transform_byte_range(
    byte_range: ByteRequest | None,
    *,
    chunk_start: int,
    chunk_end_exclusive: int,
) -> RangeByteRequest:
    """Convert a byte_range relative to a chunk into absolute file offsets."""
    if byte_range is None:
        return RangeByteRequest(chunk_start, chunk_end_exclusive)
    elif isinstance(byte_range, RangeByteRequest):
        return RangeByteRequest(
            chunk_start + byte_range.start, chunk_start + byte_range.end
        )
    elif isinstance(byte_range, OffsetByteRequest):
        return RangeByteRequest(chunk_start + byte_range.offset, chunk_end_exclusive)
    elif isinstance(byte_range, SuffixByteRequest):
        return RangeByteRequest(
            chunk_end_exclusive - byte_range.suffix, chunk_end_exclusive
        )
    else:
        raise ValueError(f"Unexpected byte_range type: {type(byte_range)}")


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


async def open_hdf5(
    *,
    path: str,
    store: ObjectStore | ObspecInput,
    group: str | None = None,
    drop_variables: Iterable[str] | None = None,
    block_size: int = 8 * 1024 * 1024,
    pre_warm_size: int | None = None,
) -> HDF5Store:
    """Open an HDF5 file as an :class:`HDF5Store` (read-only Zarr v3 store).

    Chunk index parsing is deferred until data is actually accessed, making
    the initial open significantly faster for files with many variables.

    The returned store can be passed directly to xarray::

        store = await open_hdf5(path=key, store=s3_store)
        ds = xr.open_dataset(store, engine="zarr", consolidated=False, zarr_format=3)

    Args:
        path: Path within the store (e.g. the object key for S3).
        store: An async_hdf5 or obstore ObjectStore or obspec-compatible backend.
        group: HDF5 group to open. If ``None``, the root group is used.
        drop_variables: Variable names to exclude.
        block_size: BlockCache size in bytes (default 8 MiB).
        pre_warm_size: Maximum bytes of cache blocks to pre-fetch in
            parallel during open (default ``None`` — disabled). When set,
            the file size is queried and up to *pre_warm_size* bytes of blocks
            are fetched in a single batched call. This trades bandwidth for
            latency: useful on very fast connections or for small files, but
            counterproductive when the file is large relative to the
            connection speed.

    Returns:
        A read-only Zarr v3 store backed by async-hdf5. Variables are lazily
        loaded — chunk indices are only parsed when data is actually read.
    """
    # Phase 1: parse superblock + group structure
    f = await HDF5File.open(
        path, store=store, block_size=block_size, pre_warm_size=pre_warm_size
    )
    root = await f.root_group()
    target = (await root.navigate(group)) if group else root

    drop = set(drop_variables or ())

    # Phase 2: parse all dataset headers (fast — data in BlockCache)
    dataset_names = await target.dataset_names()
    datasets: dict[str, HDF5Dataset] = {}
    for name in dataset_names:
        if name in drop:
            continue
        datasets[name] = await target.dataset(name)

    # Compute phony dimension names from shapes
    dim_names_map = assign_phony_dims(
        [(name, tuple(int(s) for s in ds.shape)) for name, ds in datasets.items()]
    )

    # Build lightweight metadata cache (no chunk indices!)
    dataset_infos: dict[str, _DatasetInfo] = {}
    skipped: list[tuple[str, str]] = []
    for name, ds in datasets.items():
        try:
            dataset_infos[name] = _DatasetInfo(ds, dimension_names=dim_names_map[name])
        except (ValueError, TypeError) as exc:
            skipped.append((name, str(exc)))
    if skipped:
        details = "; ".join(f"{n}: {e}" for n, e in skipped)
        warnings.warn(
            f"Skipped {len(skipped)} dataset(s) with unsupported types: {details}. "
            f"Use drop_variables to suppress this warning.",
            stacklevel=2,
        )

    # Get group attributes
    group_attrs = await target.attributes()

    return HDF5Store(
        dataset_infos=dataset_infos,
        group_attrs=group_attrs,
        file_url=path,
    )
