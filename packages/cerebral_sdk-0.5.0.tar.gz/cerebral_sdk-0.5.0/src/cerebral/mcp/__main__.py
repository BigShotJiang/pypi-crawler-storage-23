from cerebral.mcp import main

main()
