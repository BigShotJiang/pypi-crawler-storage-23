# Subslice Example

This example demonstrates using strings. This example briefly demonstrates the usage of:

- `autograder.LC3UnitTestCase.writeString`, and
- `autograder.LC3UnitTestCase.assertString`.
