# Fibonacci Example

This example demonstrates autograding recursive functions. This example briefly demonstrates the usage of:

- `autograder.LC3UnitTestCase.assertSubroutineCalled`, and
- `autograder.LC3UnitTestCase.assertSubroutineCalledInOrder`.
