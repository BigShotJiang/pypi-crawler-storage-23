"""FinAgent MCP tools."""
