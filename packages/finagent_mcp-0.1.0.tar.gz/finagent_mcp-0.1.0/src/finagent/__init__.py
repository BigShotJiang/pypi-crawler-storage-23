"""FinAgent — Financial analysis MCP server."""
