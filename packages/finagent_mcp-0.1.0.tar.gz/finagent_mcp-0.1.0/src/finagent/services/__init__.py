"""FinAgent services — wrappers around financial data providers."""
