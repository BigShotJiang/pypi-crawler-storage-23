# FinAgent

## Tagline
Free stock data and market news for any MCP-compatible AI assistant.

## Description
FinAgent gives your AI assistant access to live stock quotes, financial statements, analyst estimates, insider trades, key ratios, and market news — all for free. It wraps Yahoo Finance into two clean MCP tools that work with Claude, ChatGPT, Cursor, Copilot, and any other MCP-compatible app.

## Setup Requirements
No configuration required — FinAgent works out of the box with free public data.

## Category
Finance

## Features
- Real-time stock quotes with price, P/E, market cap, 52-week range, and more
- Income statements, balance sheets, and cash flow statements (annual or quarterly)
- Analyst price targets, recommendations, and earnings/revenue estimates
- Insider trading activity and purchase summaries
- Key financial ratios: P/E, PEG, ROE, debt-to-equity, profit margins, and more
- Market news search by keyword or ticker with source attribution

## Getting Started
- "What's NVIDIA's current stock price and P/E ratio?"
- "Show me Apple's last 4 quarters of revenue"
- "Who's been buying or selling TSLA stock lately?"
- "What are analysts saying about AMZN?"
- Tool: financial_data — Stock quotes, financials, ratios, analyst estimates, insider trades
- Tool: market_news — Search financial news by keyword or ticker

## Tags
finance, stocks, market data, news, quotes, financial statements, analyst estimates, insider trades, ratios, yahoo finance

## Documentation URL
https://mcp-marketplace.io/server/finagent

## Health Check URL
N/A — runs locally via stdio
