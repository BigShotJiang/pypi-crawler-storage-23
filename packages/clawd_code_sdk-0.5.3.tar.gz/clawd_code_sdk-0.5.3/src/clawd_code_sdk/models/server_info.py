"""Pydantic models for Claude Code server info structures."""

from __future__ import annotations

from typing import Literal

from anthropic.types import Model
from pydantic import Field

from clawd_code_sdk.models.base import ClaudeCodeBaseModel, FastModeState


EffortLevel = Literal["low", "medium", "high", "max"]


class ClaudeCodeModelInfo(ClaudeCodeBaseModel):
    """Information about an available AI model from Claude Code."""

    value: str
    """Model identifier used in API calls (e.g., "default", "opus", "haiku")."""

    display_name: str
    """Human-readable display name (e.g., "Opus", "Default (recommended)")."""

    description: str
    """Full description including capabilities and pricing."""

    supports_effort: bool | None = None
    """Whether the model supports effort setting."""

    supported_effort_levels: list[EffortLevel] | None = None
    """Supported effort levels."""

    supports_adaptive_thinking: bool | None = None
    """Whether the model supports adaptive thinking."""


class ClaudeCodeCommandInfo(ClaudeCodeBaseModel):
    """Information about an available slash command from Claude Code."""

    name: str
    """Command name without the / prefix (e.g., "compact", "review")."""

    description: str
    """Full description of what the command does."""

    argument_hint: str
    """Usage hint for command arguments (may be empty string)."""


class ClaudeCodeAccountInfo(ClaudeCodeBaseModel):
    """Account information from Claude Code."""

    email: str | None = None
    """User email address."""

    subscription_type: str | None = None
    """Subscription type (e.g., "Claude API")."""

    token_source: str | None = None
    """Where tokens come from (e.g., "claude.ai")."""

    api_key_source: str | None = None
    """Where API key comes from (e.g., "ANTHROPIC_API_KEY")."""

    organization: str | None = None
    """Organization name."""


class ClaudeCodeAgentInfo(ClaudeCodeBaseModel):
    """Information about an available subagent from Claude Code server."""

    name: str
    """Agent type identifier (e.g., "Explore")."""

    description: str
    """Description of when to use this agent."""

    model: Model | str | None = None
    """Model alias this agent uses. If omitted, inherits the parent's model."""


class ClaudeCodeServerInfo(ClaudeCodeBaseModel):
    """Complete server initialization info from Claude Code.

    This is returned by the Claude Code server during initialization and contains
    all available capabilities including models, commands, output styles, and
    account information.
    """

    models: list[ClaudeCodeModelInfo] = Field(default_factory=list)
    """List of available AI models."""

    commands: list[ClaudeCodeCommandInfo] = Field(default_factory=list)
    """List of available slash commands."""

    output_style: str = Field(default="default")
    """Current output style setting."""

    available_output_styles: list[str] = Field(default_factory=list)
    """List of all available output styles."""

    account: ClaudeCodeAccountInfo | None = Field(default=None)
    """Account and authentication information."""

    agents: list[ClaudeCodeAgentInfo] = Field(default_factory=list)
    """List of available subagents."""

    fast_mode_state: FastModeState | None = None
    """Fast mode state: off, in cooldown after rate limit, or actively enabled."""

    pid: int | None = None
    """Process id."""
