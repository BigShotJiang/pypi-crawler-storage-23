# relaybus-core (Python)

Envelope decoding utilities for Relaybus.
