"""Qt-based view layer for redsun."""

from __future__ import annotations

from .mainview import QtMainView

__all__ = ["QtMainView"]
