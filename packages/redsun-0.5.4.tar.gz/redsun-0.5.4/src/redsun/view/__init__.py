"""View layer for redsun."""

from __future__ import annotations

from .qt import QtMainView

__all__ = ["QtMainView"]
