def print_dict(ldict):
    import json
    print(json.dumps(ldict, indent=4))
