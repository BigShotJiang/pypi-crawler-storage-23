"""Altimate Engine — Python sidecar for the Altimate Code CLI."""

__version__ = "0.1.0"
