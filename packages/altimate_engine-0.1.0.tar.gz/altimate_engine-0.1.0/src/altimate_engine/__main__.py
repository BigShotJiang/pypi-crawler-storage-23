"""Entry point for `python -m altimate_engine`."""

from altimate_engine.server import main

main()
