"""Local-first DuckDB testing loop — sync remote schemas and test SQL locally."""
