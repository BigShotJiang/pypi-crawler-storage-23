# Generated migration for APIEndpointMapping virtual model

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('hub_auth_client', '0003_azure_ad_config'),
    ]

    operations = [
        # APIEndpointMapping is a virtual model (managed=False)
        # No actual database operations needed
    ]
