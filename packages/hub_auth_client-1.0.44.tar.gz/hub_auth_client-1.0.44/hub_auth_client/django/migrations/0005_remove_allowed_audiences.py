"""
Migration to safely remove allowed_audiences field from AzureADConfiguration.
"""

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('hub_auth_client', '0004_rename_hub_auth_cl_url_pat_idx_hub_auth_cl_url_pat_6a85ac_idx_and_more'),
    ]

    operations = [
        migrations.SeparateDatabaseAndState(
            database_operations=[
                migrations.RunSQL(
                    sql="""
                        ALTER TABLE hub_auth_client_azureadconfiguration
                        DROP COLUMN IF EXISTS allowed_audiences CASCADE;
                    """,
                    reverse_sql="""
                        ALTER TABLE hub_auth_client_azureadconfiguration
                        ADD COLUMN allowed_audiences JSONB DEFAULT '[]';
                    """
                ),
            ],
            state_operations=[
                migrations.RemoveField(
                    model_name='azureadconfiguration',
                    name='allowed_audiences',
                ),
            ],
        ),
    ]
