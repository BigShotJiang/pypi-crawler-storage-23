from bank_statement_parser import __app_name__


def main():
    print(f"{__app_name__}")


if __name__ == "__main__":
    main()
