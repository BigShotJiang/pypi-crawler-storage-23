"""
Tests for geocodio-python
"""