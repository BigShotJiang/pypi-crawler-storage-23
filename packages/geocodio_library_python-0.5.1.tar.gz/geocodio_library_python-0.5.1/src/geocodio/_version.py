"""Version information for geocodio package."""

__version__ = "0.5.1"
