"""
Entry point for running sarathy as a module: python -m sarathy
"""

from sarathy.cli.commands import app

if __name__ == "__main__":
    app()
