from .lemmatizer import SindhiLemmatizer
from .spellchecker import SindhiSpellchecker

__version__ = "1.1.4"