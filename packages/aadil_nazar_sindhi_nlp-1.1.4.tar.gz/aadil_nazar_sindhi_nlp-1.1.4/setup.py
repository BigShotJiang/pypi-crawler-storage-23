from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="aadil_nazar_sindhi_nlp", 
    version="1.1.4",  # Increment to 1.1.1
    author="Aadil Nazar",
    author_email="adilhussainburiro14912@gmail.com",
    description="A comprehensive Sindhi NLP Suite (Lemmatizer & Spellchecker)",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/aadilnazar/sindhi_nlp",
    package_dir={"": "src"},
    # This is the most reliable way to find your modules
    packages=find_packages(where="src"),
    include_package_data=True,
    package_data={
        "aadil_nazar_sindhi_nlp": ["data/*.csv"],
    },
    python_requires=">=3.7",
    license="MIT",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)