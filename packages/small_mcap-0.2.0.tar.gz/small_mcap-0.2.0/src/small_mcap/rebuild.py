"""Rebuild MCAP summary section from data section."""

from collections import defaultdict
from collections.abc import Iterable
from dataclasses import dataclass
from typing import IO

from small_mcap.exceptions import McapError
from small_mcap.reader import (
    _RECORD_HEADER_SIZE,
    _get_chunk_data_stream,
    breakup_chunk,
    stream_reader,
)
from small_mcap.records import (
    OPCODE_AND_LEN_STRUCT,
    Attachment,
    AttachmentIndex,
    Channel,
    Chunk,
    ChunkIndex,
    Header,
    LazyChunk,
    McapRecord,
    Message,
    MessageIndex,
    Metadata,
    MetadataIndex,
    Opcode,
    Schema,
    Statistics,
    Summary,
)

# opcode + length + channel_id + sequence + log_time + publish_time
MESSAGE_RECORD_OVERHEAD = 1 + 8 + 2 + 4 + 8 + 8


def _estimate_size_from_indexes(indexes: list[MessageIndex], chunk_size: int) -> dict[int, int]:
    """Estimate message sizes from MessageIndex offsets without decompressing.

    This calculates approximate message sizes by looking at the gaps between message
    offsets within a chunk. The size is estimated as the difference between consecutive
    offsets minus the message record header size.

    Args:
        indexes: List of MessageIndex records for a chunk
        chunk_size: Uncompressed size of the chunk

    Returns:
        Dict mapping channel_id to total estimated bytes for that channel
    """

    # Fast path: single channel (common case)
    if len(indexes) == 1:
        idx = indexes[0]
        offsets = idx.offsets
        if not offsets:
            return {}
        total = sum(
            offsets[i + 1] - offsets[i] - MESSAGE_RECORD_OVERHEAD for i in range(len(offsets) - 1)
        )
        total += chunk_size - offsets[-1] - MESSAGE_RECORD_OVERHEAD  # last message
        return {idx.channel_id: total}

    # Multi-channel: collect all (offset, channel_id) pairs and sort by offset
    # Pre-calculate total size to avoid list resizing
    total_records = sum(len(idx.timestamps) for idx in indexes)
    all_msgs: list[tuple[int, int]] = [(0, 0)] * total_records

    i = 0
    for idx in indexes:
        ch = idx.channel_id
        for offset in idx.offsets:
            all_msgs[i] = (offset, ch)
            i += 1

    all_msgs.sort()  # Sort by offset (first element)

    if not all_msgs:
        return {}

    # Calculate sizes in a single pass
    sizes: dict[int, int] = {}
    for j in range(len(all_msgs) - 1):
        offset, ch = all_msgs[j]
        next_offset = all_msgs[j + 1][0]
        sizes[ch] = sizes.get(ch, 0) + (next_offset - offset - MESSAGE_RECORD_OVERHEAD)

    # Last message extends to chunk_size
    offset, ch = all_msgs[-1]
    sizes[ch] = sizes.get(ch, 0) + (chunk_size - offset - MESSAGE_RECORD_OVERHEAD)

    return sizes


@dataclass(slots=True)
class RebuildInfo:
    """Result of rebuilding MCAP summary from data section.

    Attributes:
        header: The MCAP file header
        summary: The rebuilt summary section
        channel_sizes: Optional dict mapping channel_id to total uncompressed message data bytes.
            This represents the sum of len(message.data) for all messages on each channel.
            None if calculate_channel_sizes was False.
        estimated_channel_sizes: Whether channel_sizes are estimated (True) or exact (False).
            Only meaningful when channel_sizes is not None.
        chunk_information: Optional dict mapping chunk offset to MessageIndex records.
        next_offset: Byte offset where the next read should start.
    """

    header: Header
    summary: Summary
    channel_sizes: dict[int, int] | None = None
    estimated_channel_sizes: bool = False
    chunk_information: dict[int, list[MessageIndex]] | None = None
    next_offset: int = 0


def _breakup_chunk_with_offsets(
    chunk: Chunk, validate_crc: bool = False
) -> Iterable[tuple[int, McapRecord]]:
    """Like breakup_chunk but yields (offset, record) tuples.

    The offset is the byte position of the record within the uncompressed chunk data,
    suitable for use in MessageIndex records.
    """
    data = _get_chunk_data_stream(chunk, validate_crc=validate_crc)
    view = memoryview(data)
    pos = 0

    while pos < len(view):
        record_start = pos  # Offset of this record in chunk
        opcode, length = OPCODE_AND_LEN_STRUCT.unpack_from(view, pos)
        pos += _RECORD_HEADER_SIZE
        record_data_end = pos + length

        if opcode == Opcode.MESSAGE:
            yield (record_start, Message.read(view[pos:record_data_end]))
        elif opcode == Opcode.CHANNEL:
            yield (record_start, Channel.read(view[pos:record_data_end]))
        elif opcode == Opcode.SCHEMA:
            yield (record_start, Schema.read(view[pos:record_data_end]))

        pos = record_data_end


def rebuild_summary(
    stream: IO[bytes],
    *,
    validate_crc: bool,
    calculate_channel_sizes: bool,
    exact_sizes: bool,
    initial_state: RebuildInfo | None = None,
    skip_magic: bool = False,
) -> RebuildInfo:
    """Rebuild summary section from an MCAP file's data section.

    This function reconstructs the summary section by reading through the data section
    and collecting all necessary information. It reuses the same chunk processing logic
    as message reading to efficiently handle channel definitions.

    Args:
        stream: Input stream to read from (must be non-seekable or at start of file)
        validate_crc: Whether to validate CRC checksums when processing chunks
        calculate_channel_sizes: Whether to calculate per-channel message data sizes.
        exact_sizes: When True, decompresses all chunks for exact sizes. When False, estimates
            sizes from MessageIndex offsets (faster but approximate). Only relevant when
            calculate_channel_sizes=True.
        initial_state: Optional previous RebuildInfo to resume from. When used for resuming, first
            seek to initial_state.next_offset before calling and set skip_magic=True.

    Returns:
        RebuildInfo containing header, summary, and optionally channel_sizes.
        The estimated_channel_sizes flag indicates if sizes are estimated.
        The next_offset field contains the byte position where reading stopped.

    Raises:
        McapError: If the file is invalid or header is missing
    """
    # Initialize or resume from previous state
    if initial_state is not None:
        # Resume from previous state
        header = initial_state.header
        summary = initial_state.summary
        statistics = summary.statistics
        assert statistics is not None, "Initial state's summary must have statistics"
        channel_sizes = defaultdict(int, initial_state.channel_sizes or {})
        chunk_information = dict(initial_state.chunk_information or {})
    else:
        # Start fresh
        header = None
        summary = Summary()
        statistics = Statistics(
            attachment_count=0,
            channel_count=0,
            channel_message_counts=defaultdict(int),
            chunk_count=0,
            message_count=0,
            message_end_time=0,
            message_start_time=0,
            metadata_count=0,
            schema_count=0,
        )
        channel_sizes = defaultdict(int)
        chunk_information = {}

    # These always start fresh (handle chunk boundaries)
    pending_chunk: LazyChunk | None = None
    pending_chunk_start_offset: int = 0
    pending_indexes: list[MessageIndex] = []
    pending_message_index_offsets: dict[int, int] = {}

    def update_message(record: Message) -> None:
        # Update message time statistics
        if statistics.message_start_time == 0:
            statistics.message_start_time = record.log_time
        else:
            statistics.message_start_time = min(statistics.message_start_time, record.log_time)
        if statistics.message_end_time == 0:
            statistics.message_end_time = record.log_time
        else:
            statistics.message_end_time = max(statistics.message_end_time, record.log_time)

        # Update channel message count
        statistics.message_count += 1
        statistics.channel_message_counts[record.channel_id] += 1
        # Calculate channel sizes if requested
        if calculate_channel_sizes:
            channel_sizes[record.channel_id] += len(record.data)

    def finish_chunk(*, force: bool = False, rebuild_indexes: bool = False) -> None:
        nonlocal pending_chunk, pending_indexes
        if pending_chunk is None:
            return

        if (
            force
            or exact_sizes
            or any(msg_idx.channel_id not in summary.channels for msg_idx in pending_indexes)
        ):
            if rebuild_indexes:
                # Rebuild MessageIndex records from chunk data
                rebuilt_indexes: dict[int, MessageIndex] = {}
                for offset, record in _breakup_chunk_with_offsets(
                    pending_chunk.to_chunk(stream),
                    validate_crc=validate_crc,
                ):
                    if isinstance(record, Channel):
                        summary.channels[record.id] = record
                    elif isinstance(record, Schema):
                        summary.schemas[record.id] = record
                    elif isinstance(record, Message):
                        update_message(record)
                        # Build MessageIndex entry
                        if record.channel_id not in rebuilt_indexes:
                            rebuilt_indexes[record.channel_id] = MessageIndex(
                                channel_id=record.channel_id, timestamps=[], offsets=[]
                            )
                        rebuilt_indexes[record.channel_id].timestamps.append(record.log_time)
                        rebuilt_indexes[record.channel_id].offsets.append(offset)
                # Replace pending_indexes with rebuilt ones
                pending_indexes = list(rebuilt_indexes.values())
            else:
                # Original path - no index rebuilding
                for record in breakup_chunk(
                    pending_chunk.to_chunk(stream),
                    validate_crc=validate_crc,
                ):
                    if isinstance(record, Channel):
                        summary.channels[record.id] = record
                    elif isinstance(record, Schema):
                        summary.schemas[record.id] = record
                    elif isinstance(record, Message):
                        update_message(record)
        else:
            if calculate_channel_sizes:
                estimated_sizes = _estimate_size_from_indexes(
                    pending_indexes, pending_chunk.uncompressed_size
                )
                for channel_id, size in estimated_sizes.items():
                    channel_sizes[channel_id] += size

            for idx in pending_indexes:
                statistics.message_count += len(idx.timestamps)
                statistics.channel_message_counts[idx.channel_id] += len(idx.timestamps)

        # Store MessageIndex records for this chunk
        if pending_indexes:
            chunk_information[pending_chunk_start_offset] = pending_indexes.copy()

        pending_indexes.clear()
        pending_message_index_offsets.clear()
        pending_chunk = None

    message_index_start_offset: int = 0
    prev_pos: int = 0
    last_message_index_end_offset: int = 0

    # Track position for resumable reads
    next_offset = stream.tell()

    try:
        for record in stream_reader(
            stream,
            skip_magic=skip_magic,
            emit_chunks=True,
            lazy_chunks=True,
            validate_crc=validate_crc,
        ):
            record_start_pos = prev_pos
            current_pos = stream.tell()
            next_offset = current_pos  # Track position after each successful record read
            prev_pos = current_pos

            if not isinstance(record, MessageIndex):
                # Finish previous chunk and add its ChunkIndex
                if pending_chunk is not None:
                    # Calculate message index section length
                    message_index_length = record_start_pos - message_index_start_offset

                    summary.chunk_indexes.append(
                        ChunkIndex(
                            chunk_length=message_index_start_offset - pending_chunk_start_offset,
                            chunk_start_offset=pending_chunk_start_offset,
                            compression=pending_chunk.compression,
                            compressed_size=pending_chunk.data_len,
                            message_end_time=pending_chunk.message_end_time,
                            message_index_length=message_index_length,
                            message_index_offsets=pending_message_index_offsets,
                            message_start_time=pending_chunk.message_start_time,
                            uncompressed_size=pending_chunk.uncompressed_size,
                        )
                    )
                finish_chunk()

            if isinstance(record, Header):
                header = record
            elif isinstance(record, Channel):
                summary.channels[record.id] = record
            elif isinstance(record, Schema):
                summary.schemas[record.id] = record
            elif isinstance(record, Message):
                update_message(record)
            elif isinstance(record, Chunk):
                raise RuntimeError("Unreachable")  # noqa: TRY004, TRY301
            elif isinstance(record, LazyChunk):
                pending_chunk_start_offset = record_start_pos
                message_index_start_offset = current_pos
                last_message_index_end_offset = message_index_start_offset

                statistics.chunk_count += 1

                # Update time statistics from chunk
                if statistics.message_start_time == 0:
                    statistics.message_start_time = record.message_start_time
                else:
                    statistics.message_start_time = min(
                        statistics.message_start_time, record.message_start_time
                    )
                if statistics.message_end_time == 0:
                    statistics.message_end_time = record.message_end_time
                else:
                    statistics.message_end_time = max(
                        statistics.message_end_time, record.message_end_time
                    )
                pending_chunk = record
            elif isinstance(record, MessageIndex):
                if record.timestamps:
                    pending_indexes.append(record)
                    # Track the position of this MessageIndex for this channel
                    pending_message_index_offsets.setdefault(record.channel_id, record_start_pos)
                # Track the end position of MessageIndex records
                last_message_index_end_offset = current_pos
            elif isinstance(record, Attachment):
                statistics.attachment_count += 1
            elif isinstance(record, AttachmentIndex):
                summary.attachment_indexes.append(record)
            elif isinstance(record, Metadata):
                statistics.metadata_count += 1
            elif isinstance(record, MetadataIndex):
                summary.metadata_indexes.append(record)
    except Exception:  # noqa: BLE001, S110
        pass

    if pending_chunk is not None:
        message_index_length = last_message_index_end_offset - message_index_start_offset
        summary.chunk_indexes.append(
            ChunkIndex(
                chunk_length=message_index_start_offset - pending_chunk_start_offset,
                chunk_start_offset=pending_chunk_start_offset,
                compression=pending_chunk.compression,
                compressed_size=pending_chunk.data_len,
                message_end_time=pending_chunk.message_end_time,
                message_index_length=max(0, message_index_length),
                message_index_offsets=pending_message_index_offsets,
                message_start_time=pending_chunk.message_start_time,
                uncompressed_size=pending_chunk.uncompressed_size,
            )
        )
    try:
        prior_chunks = summary.chunk_indexes[:-1]
        # Only skip index rebuilding if there are prior chunks and none have indexes
        # (i.e., the file was written without message indexes). With no prior chunks
        # or with any prior chunk having indexes, default to rebuilding.
        should_rebuild_indexes = not prior_chunks or any(
            ci.message_index_length > 0 for ci in prior_chunks
        )
        finish_chunk(force=True, rebuild_indexes=should_rebuild_indexes)
    except Exception:  # noqa: BLE001, S110
        pass

    # Finalize statistics
    statistics.schema_count = len(summary.schemas)
    statistics.channel_count = len(summary.channels)
    summary.statistics = statistics

    if header is None:
        raise McapError("No header found in MCAP file")

    return RebuildInfo(
        header=header,
        summary=summary,
        channel_sizes=channel_sizes if calculate_channel_sizes else None,
        estimated_channel_sizes=calculate_channel_sizes and not exact_sizes,
        chunk_information=chunk_information or None,
        next_offset=next_offset,
    )
