"""MCP server for the Unipile API — 96 tools for messaging, email, calendar, LinkedIn, and more."""

from .server import main

__all__ = ["main"]
