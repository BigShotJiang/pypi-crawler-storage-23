from setuptools import setup

setup(
    name='tsumugiritoki',
    version='1.0.0',
    description='This package name is reserved.'
)