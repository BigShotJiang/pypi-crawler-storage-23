import os
# import sys
import inspect
# import traceback
import numpy as np
import datetime as dt
# import uuid
import warnings, traceback

import astropy.units as u
from astropy import uncertainty as unc
# from numba.np.ufunc.workqueue import synchronize

from .utils.versioning import HeadVer
from .utils.pydocformatter import PyDocFormatter

class ValueU:
    __fullname = 'Uncertainty-bearing Value'
    __firstwritten = dt.datetime.strptime('2023-09-06', '%Y-%m-%d')
    __lastupdate = dt.datetime.strptime('2026-03-03', '%Y-%m-%d')
    __version = HeadVer(1, __lastupdate, 5)
    __developer = {'name': 'DH.Koh', 'contact': 'donghyeok.koh.code@gmail.com'}
    __collaborators = [{'name': 'JH.Kim', 'contact': None}, {'name': 'KM.Heo', 'contact': None}]
    __contributors = [{'name': None, 'role': None}]
    __callsign = 'Value(+/-)'

    __versiondependency = {}

    __array_priority__ = 11000
    _n_samples = None  # Number of samples for uncertainty distribution
    _n_samples_defaultvalue = 10000  # Default value of __n_samples

    def __init__(self, center=None, std=None, n_samples=None, dtype:np.generic=None):
        # self.__id = uuid.uuid4()  # time.perf_counter_ns()
        
        if center is None:
            center = np.nan
        
        if std is None:
            std = np.nan
        
        if n_samples is None:
            self.n_samples = ValueU._n_samples_defaultvalue  # Default number of samples for uncertainty distribution
        else:
            try:
                if n_samples == int(n_samples):
                    self.n_samples = int(n_samples)
            except:
                raise TypeError(f'{self.__callsign.ljust(10)}: Input argument \"n_samples\" must be an integer value.')
        
        if dtype is None:
            self.__dtype = np.float32
        elif issubclass(dtype, np.number):
            self.__dtype = dtype
        else:
            self.__dtype = np.float32
        
        self._comparison_criterion_by_center = True
        self._comparison_criterion_threshold = None

        ### initialize
        self.distribution = unc.Distribution([np.nan]).astype(self.__dtype)

        ### recognize value
        generated_distribution = self._generate_distribution(center=center, std=std)

        self._digit_round = 5
        self._digit_stringformat = 8

        return None
    
    def _sync_info(self):
        """
        [Protected] Synchronizes the instance's internal metadata with the current state of the distribution.
        Although primarily designed for internal consistency, it may be manually called by users if necessary.
        """
        self.n_samples = self.distribution.distribution.shape[-1]
        self.__dtype = self.distribution.dtype
        # assert self.n_samples == self.distribution.distribution.shape[-1], 'The shape of the distribution does not match the static number of samples.'

        return self

    def __set_manual(self, center, distribution: unc.Distribution):
        """
        [Private] Manually sets attributes. Assumes inputs are pre-validated.
        """
        self.center = center
        self.distribution = distribution#.astype(self.__dtype)

        return self

    def set_manual(self, center:float=None, distribution: unc.Distribution = None):
        """
        [Public] Provides a user-level interface for manually defining the center and distribution of the instance.
        If 'center' is not provided, it is automatically assigned the median value of the given distribution to ensure statistical consistency.
        """
        # if isinstance(center, unc.Distribution):
        #     raise TypeError(f'{self.__callsign.ljust(10)}: The input argument \"center\" should not be an instance of {unc.Distribution}.')
        if not isinstance(distribution, unc.Distribution):
            raise TypeError(f'{self.__callsign.ljust(10)}: The input argument \"distribution\" should be an instance of {unc.Distribution}.')
        
        if center is None:
            warnings.warn(
                message=f'{self.__callsign.ljust(10)}: Not provided center; automatically set to the median of the distribution.',
                category=UserWarning,
                stacklevel=2
            )
            # traceback.print_stack(limit=2)
            center = distribution.pdf_median()

        self.__set_manual(center=center, distribution=distribution)

        return self._sync_info()

    @property
    def enforced_positive(self):
        """
        [Public Property]
        Returns a new instance with a positive-enforced distribution.
        Replaces negative samples with NaN to maintain alignment while enforcing domain.
        """
        if self.center < 0:
            raise ValueError(
                f'{self.__callsign.ljust(10)}: Logical Contradiction, '
                f'Cannot enforce positive on a distribution with a negative center ({self.center}).'
            )
        
        """
        Replaces samples in the negative domain with NaN to preserve 
        the total sample count and alignment without distorting the valid distribution.
        """
        distribution_positive = np.where(self.distribution.distribution < 0, np.nan, self.distribution.distribution)
        
        return self.__class__().set_manual(
            center=self.center,
            # distribution=unc.Distribution(distribution_positive.astype(self.__dtype))
            distribution=unc.Distribution(distribution_positive)
        ).set_digit(
            self._digit_round,
            self._digit_stringformat
        )
    
    @property
    def enforced_negative(self):
        """
        [Public Property]
        Returns a new instance with a negative-enforced distribution.
        Replaces positive samples with NaN to maintain alignment while enforcing domain.
        """
        if self.center > 0:
            raise ValueError(
                f'{self.__callsign.ljust(10)}: Logical Contradiction, '
                f'Cannot enforce negative on a distribution with a positive center ({self.center}).'
            )
        
        """
        Replaces samples in the positive domain with NaN to preserve 
        the total sample count and alignment without distorting the valid distribution.
        """
        enforced_negative = np.where(self.distribution.distribution > 0, np.nan, self.distribution.distribution)
        
        return self.__class__().set_manual(
            center=self.center,
            # distribution=unc.Distribution(enforced_negative.astype(self.__dtype))
            distribution=unc.Distribution(enforced_negative)
        ).set_digit(
            self._digit_round,
            self._digit_stringformat
        )
    
    def __generate_distribution_symmetric(self, center, std):
        """
        [Private]
        Generates a symmetric distribution and directly updates instance variables.
        No return value. Direct user access is strictly prohibited.
        Usage (not allowed direct call this at the user level) :
        >>> self.__generate_distribution_symmetric(center=10, std=1)
        """
        self.center = center

        distribution_generated = unc.normal(center=self.center, std=std, n_samples=self.n_samples)

        self.distribution = distribution_generated.astype(self.__dtype)

    def __generate_distribution_asymmetric(self, center, stds: np.ndarray):
        """
        [Private]
        Generates an asymmetric distribution by splicing two half-normal distributions (p=0.5 each)
        using the provided numeric pair of left and right standard deviations ('stds').
        Directly modifies instance variables without returning an object.
        Usage (not allowed direct call this at the user level) :
        >>> self.__generate_distribution_asymmetric(center=10, std=np.array([1, 2]))
        """
        self.center = center

        """
        Logic: Scales the negative and positive domains of a zero-centered normal 
        distribution independently using the ratio of the two std values, 
        then shifts it to the provided center.
        """
        distribution_generated_primary = unc.normal(center=0, std=stds[1], n_samples=self.n_samples)
        distribution_generated_secondary = unc.Distribution(
            np.where(
                distribution_generated_primary.distribution < 0,
                distribution_generated_primary.distribution * (-stds[0] / stds[1]),
                distribution_generated_primary.distribution
            )
        )
        distribution_generated = (self.center + distribution_generated_secondary)

        self.distribution = distribution_generated.astype(self.__dtype)

    def _generate_distribution(self, center, std: np.ndarray):
        """
        [Protected]
        Categorizes input uncertainty information and routes it to the appropriate distribution generation logic.
        The input 'std' must be a single value or a pair for each 'center'.
        For a pair input, the first value must be negative (lower distribution) and 
        the second value must be positive (upper distribution) relative to the center.
        Note: Simultaneous processing functions for multi-valued inputs have not been implemented yet.
        Usage (not recommand direct call this at the user level) :
        >>> v = ValueU(10)
        ... print(repr(v))
        ValueU(10, (nan, nan))
        >>> v._set_error_relative([-1, 2])
        ValueU(5, (-1, +2))
        """

        if isinstance(std, np.ndarray):
            if std.shape == (2,):
                ### Case (a-1) std= array([-number, +number])
                self.__generate_distribution_asymmetric(center=center, stds=std)
            elif std.shape == (1,):
                ### Case (a-2) std= array([number])
                self.__generate_distribution_symmetric(center=center, std=std[0])
            elif np.prod(std.shape) / np.prod(center.shape) == 2.:
                ### Case (a-3) std= [[-number1, +number2, ...], [+number1, +number2, ...]]
                """[Describe] - self.center가 단일 값이 아닐 경우를 위한 부분. 현재는 사용처가 없지만 활용 가능성이 있기 때문에 존치."""
                if not std.shape == ((2,) + np.array(center).shape):
                    raise ValueError(f'{self.__callsign.ljust(10)}: Input argument \"stddev\" shape not matched with two times repeated shape of the center value')
                self.__generate_distribution_asymmetric(center=center, stds=np.array([std[0], std[1]]))
            elif np.prod(std.shape) / np.prod(center.shape) == 1.:
                ### Case (a-4) std= [-number1, +number2, ...]
                """[Describe] - self.center가 단일 값이 아닐 경우를 위한 부분. 현재는 사용처가 없지만 활용 가능성이 있기 때문에 존치."""
                if not std.shape == np.array(center).shape:
                    raise ValueError(f'{self.__callsign.ljust(10)}: Input argument \"stddev\" shape not matched with the center value')
                self.__generate_distribution_symmetric(center=center, std=std)
            else:
                raise ValueError(f'{self.__callsign.ljust(10)}: Input argument \"std\" wrong - should be a number pair (ndarray) or the same structure as the center value')
        elif isinstance(std, list) or isinstance(std, tuple):
            if len(std) == 2:
                ### Case (b-1) std= [-number, +number]
                self.__generate_distribution_asymmetric(center=center, stds=np.array(std))
            elif len(std) == 1:
                ### Case (b-2) std= [number]
                self.__generate_distribution_symmetric(center=center, std=std[0])
            elif np.prod(np.array(std).shape) / np.prod(np.array(center).shape) == 2.:
                ### Case (b-3) std= [[-number1, +number2, ...], [+number1, +number2, ...]]
                """[Describe] - self.center가 단일 값이 아닐 경우를 위한 부분. 현재는 사용처가 없지만 활용 가능성이 있기 때문에 존치."""
                if not np.array(std).shape == ((2,) + np.array(center).shape):
                    raise ValueError(f'{self.__callsign.ljust(10)}: Input argument \"stddev\" shape not matched with two times repeated shape of the center value')
                self.__generate_distribution_asymmetric(center=center, stds=np.array([np.array(std)[0], np.array(std)[1]]))
            elif np.prod(np.array(std).shape) / np.prod(np.array(center).shape) == 1.:
                ### Case (b-4) std= [-number1, +number2, ...]
                """[Describe] - self.center가 단일 값이 아닐 경우를 위한 부분. 현재는 사용처가 없지만 활용 가능성이 있기 때문에 존치."""
                if not np.array(std).shape == np.array(center).shape:
                    raise ValueError(f'{self.__callsign.ljust(10)}: Input argument \"stddev\" shape not matched with the center value')
                self.__generate_distribution_symmetric(center=center, std=std)
            else:
                raise ValueError(f'{self.__callsign.ljust(10)}: Input argument \"std\" wrong - should be a number pair (list) or the same structure as the center value')
        elif isinstance(std, int) or isinstance(std, float):
            ### Case (c) std= number
            self.__generate_distribution_symmetric(center=center, std=std)
        else:
            raise ValueError(f'{self.__callsign.ljust(10)}: Input argument \"std\" wrong - should be a number pair or the same structure as the center value')

        return self._sync_info()

    def __resample(self, n_samples=None):
        """
        [Private]
        Provides a user-level interface for resampling distribution via random shuffling.
        To avoid duplication, it performs sampling without replacement for downscaling,
        but permits sampling with replacement for upscaling if necessary.
        Usage :
        >>> instance.resample(n_samples=1000)
        """
        dummyvalue_synchronized = self._sync_info()

        self_resampled = self.__class__().set_manual(
            center=self.center,
            distribution=unc.Distribution(
                self.distribution.distribution[
                    np.random.choice(self.n_samples, size=n_samples, replace=n_samples > self.n_samples)]
            ).astype(self.__dtype)
        ).set_digit(
            digit_round=self._digit_round,
            digit_stringformat=self._digit_stringformat,
        )

        return self_resampled

    def resample(self, n_samples=None):
        """
        [Public]
        Provides a user-level interface for resampling distribution via random shuffling.
        To avoid duplication, it performs sampling without replacement for downscaling, 
        but permits sampling with replacement for upscaling if necessary.
        Usage :
        >>> v.resample(n_samples=1000)
        """
        if n_samples is None:
            n_samples = self.n_samples
        elif not isinstance(n_samples, (int, np.integer)):
            raise TypeError(f'{self.__callsign.ljust(10)}: Input argument \"n_samples\" must be an integer value.')
        
        dummyvalue_synchronized = self._sync_info()
        
        self_resampled = self.__class__().set_manual(
            center = self.center,
            distribution = unc.Distribution(
                self.distribution.distribution[np.random.choice(self.n_samples, size=n_samples, replace=n_samples > self.n_samples)]
            ).astype(self.__dtype)
        ).set_digit(
            digit_round = self._digit_round,
            digit_stringformat = self._digit_stringformat,
        )

        return self_resampled

    def _promote_nsamples(self, other):
        """
        [Protected]
        Acts as a safety measure to synchronize sample resolutions between instances during operations.
        While the system is designed to maintain a consistent 'n_samples', this method ensures 
        compatibility when discrepancies occur by upscaling 'self' to match the higher resolution.
        As this involves resampling via replacement for upscaling, it may introduce minor 
        statistical variations in the distribution results. Not intended for direct user-level calls.
        Usage (not recommand direct call this at the user level) :
        >>> v1._promote_nsamples(other) + v2._promote_nsamples(self)
        """
        from .quantityu import QuantityU
        if not isinstance(other, (self.__class__, QuantityU)):
            raise TypeError(f'{self.__callsign.ljust(10)}: Incompatible type for n_samples promotion: {type(other)}')

        n_samples_self = self._sync_info().n_samples
        n_samples_other = other._sync_info().n_samples

        if n_samples_self < n_samples_other:
            return self.copy().resample(n_samples_other)
        else:
            return self.copy()

    def copy(self):
        """
        [Public]
        Returns a new instance with the identical center, distribution, and formatting settings.
        Ensures the original instance remains unchanged during subsequent manipulations.
        Usage:
        >>> new_instance = v.copy()
        """
        self_copied = self.__class__().set_manual(
            center=self.center,
            distribution=self.distribution,
        ).set_digit(
            digit_round=self._digit_round,
            digit_stringformat=self._digit_stringformat,
        )

        return self_copied

    def astype(self, dtype):
        """
        [Public]
        Returns a new instance with the distribution cast to a specified numeric data type (dtype).
        Preserves all metadata while updating the underlying array's precision.
        Usage:
        >>> float32_instance = v.astype(np.float32)
        """
        self_copied = self.__class__().set_manual(
            center=self.center,
            distribution=self.distribution.astype(dtype),
        ).set_digit(
            digit_round=self._digit_round,
            digit_stringformat=self._digit_stringformat,
        )

        return self_copied
    
    def set_comparison_mode(self, central:bool=False, conservative:bool=False, permissive:bool=False, percentage:int=None):
        """
        [***ToDo*__] (25-01-24) - 단일문으로 작성시 어테이션 에러 발생할때 도무지 알 수 없는 이유로 스레드가 종료되지 않는 스레딩 에러 발생,
        python3.10/threading.py, line 1567, lock.acquire() \n KeyboardInterrupt:
        assert 열에서 하는 일을 바깥으로 빼내어 일단 안정적으로 작동, 임시방편인지 해결팩인지 확인 필요.
        """
        number_of_true_in_arguments: int = np.sum((central, conservative, permissive, not percentage is None))
        error_message = f'Only one of these parameters can be set: central (True), conservative (True), permissive (True), or percentage (\033[3mfloat value\033[0m) for this method ({self.__class__.__name__}.{inspect.getframeinfo(inspect.currentframe()).function})'
        # error_message = f'It is invalid to provide multiple parameters as \'True\' among {["central", "conservative", "upper", "lower"]} for the method {self.__class__.__name__}.{inspect.getframeinfo(inspect.currentframe()).function}.'
        assert number_of_true_in_arguments == 1, error_message

        result = self.copy()
        if central:
            result._comparison_criterion_by_center = True
        else:
            result._comparison_criterion_by_center = False
            if conservative:
                result._comparison_criterion_threshold = 0.9973
            elif permissive:
                result._comparison_criterion_threshold = 0.6827
            elif percentage is not None:
                result._comparison_criterion_threshold = percentage
            else:
                result._comparison_criterion_by_center = True

        return result

    def __getstate__(self):
        stateinfo_sleeping = {
            'center': self.center,
            'distribution': self.distribution.distribution.astype(self.__dtype),
            'digits': [self._digit_round, self._digit_stringformat],
            'n_samples': self.n_samples,
            f'_{self.__class__.__name__}__dtype': self.__dtype,
        }

        return stateinfo_sleeping

    def __setstate__(self, stateinfo):
        self_wakeing = self.set_manual(
            center=stateinfo['center'],
            distribution=unc.Distribution(stateinfo['distribution']).astype(stateinfo[f'_{self.__class__.__name__}__dtype']),
        ).set_digit(
            digit_round=stateinfo['digits'][0],
            digit_stringformat=stateinfo['digits'][1],
        )



    def __add__(self, other):  ## from self + other
        """
        [Describe] - 가산연산에서 other가 QuantityU의 인스턴스라면 other.__radd__를 호출하여 처리하고,
        이때 other가 Quantity의 인스턴스인 경우에는 other.unit이 astropy.units.dimensionless_unscaled이지 않으면 연산 불가능하다.
        이러한 경우를 별도로 예외처리하지 않고, 연산을 시도할 경우 기존 에러가 발생하도록 의도함.

        [__*ToDo___] (24-_-_) - QuantityU와 ValueU간의 상호작용이 있고, QuantityU에서도 ValueU 클래스를 사용하고 있다.
        따라서 순환참조가 되지 않도록 하려면 QuantityU를 이렇게 메소드 내에서 호출하여 사용하는 것이 맞는지 확인 필요.
        """
        from .quantityu import QuantityU
        if isinstance(other, QuantityU):  ### Case for ValueU + QuantityU
            result = other.__radd__(self)
        else:
            if isinstance(other, self.__class__):
                result = self.__class__().set_manual(
                    center=self.center + other.center,
                    distribution=(self.distribution + other.distribution).astype(dtype=np.result_type(self.__dtype, other.__dtype)),
                ).set_digit(
                    digit_round=max(self._digit_round, other._digit_round),
                    digit_stringformat=max(self._digit_stringformat, other._digit_stringformat),
                )
            else:
                result = self.__class__().set_manual(
                    center=self.center + other,
                    distribution=self.distribution + other,
                ).set_digit(
                    digit_round=self._digit_round,
                    digit_stringformat=self._digit_stringformat,
                )

        return result

    def __radd__(self, other):  ## other + self
        return self.__add__(other)

    def __neg__(self):  ## -self
        result = self.__class__().set_manual(center=-self.center, distribution=-self.distribution,).set_digit(self._digit_round, self._digit_stringformat,)
        return result

    def __sub__(self, other):  ## self - other
        return self.__add__(other.__neg__())

    def __rsub__(self, other):  ## other - self
        return self.__neg__().__add__(other)
    
    def __abs__(self):  ## abs(self)
        """
        [Operator: Standard Absolute]
        Applies absolute values to all samples, folding negative values into the positive domain.
        """
        return self.__class__().set_manual(
            center=abs(self.center),
            distribution=unc.Distribution(np.abs(self.distribution.distribution).astype(self.__dtype))
        ).set_digit(self._digit_round, self._digit_stringformat)
    
    def __pos__(self):  ## + self
        """
        [Operator: Unary Plus]
        Ensures the center is positive by flipping the entire distribution if center < 0.
        Preserves the relative shape of the distribution while aligning it to the positive domain.
        Used via '+instance' syntax.
        """
        if self.center < 0:
            return self.__neg__()
        else:
            return self.copy()

    def __mul__(self, other):  ## self * other
        """
        [Describe] - 승법연산에서 other가 QuantityU의 인스턴스라면 other.__rmul__를 호출하여 처리하고,
        이때 other가 Quantity의 인스턴스인 경우에는 other.unit이 astropy.units.dimensionless_unscaled이지 않으면 연산 불가능하다.
        이러한 경우를 별도로 예외처리하지 않고, 연산을 시도할 경우 기존 에러가 발생하도록 의도함.

        [__*ToDo___] (24--) - QuantityU와 ValueU간의 상호작용이 있고, QuantityU에서도 ValueU 클래스를 사용하고 있다.
        따라서 순환참조가 되지 않도록 하려면 QuantityU를 이렇게 메소드 내에서 호출하여 사용하는 것이 맞는지 확인 필요.
        """
        from .quantityu import QuantityU
        if isinstance(other, QuantityU):  ### Case(c) ValueU * QuantityU
            result = other.__rmul__(self)
        else:
            if isinstance(other, u.UnitBase):  ### Case(d) ValueU * Units
                ## [Describe] - 승법연산에서 other가 astropy.units에서 제공하는 인스턴스라면, QuantityU 객체로 반환한다.
                result = QuantityU(n_samples=self.n_samples).set_manual(
                    center=self.center * other,
                    distribution=self.distribution * other,
                ).set_digit(
                    digit_round=self._digit_round,
                    digit_stringformat=self._digit_stringformat,
                )
            else:
                if isinstance(other, self.__class__):
                    result = self.__class__().set_manual(
                        center=self.center * other.center,
                        distribution=(self.distribution * other.distribution).astype(dtype=np.result_type(self.__dtype, other.__dtype)),
                    ).set_digit(
                        digit_round=max(self._digit_round, other._digit_round),
                        digit_stringformat=max(self._digit_stringformat, other._digit_stringformat),
                    )
                else:
                    result = self.__class__().set_manual(
                        center=self.center * other,
                        distribution=self.distribution * other,
                    ).set_digit(
                        digit_round=self._digit_round,
                        digit_stringformat=self._digit_stringformat,
                    )

        return result

    def __rmul__(self, other):  ## from other * self
        return self.__mul__(other)

    def __truediv__(self, other):  ## self / other
        from .quantityu import QuantityU
        if isinstance(other, self.__class__):
            if np.issubdtype(self.distribution.distribution.dtype, np.floating):
                return self.__mul__(other.astype(np.floating).__pow__(-1))
            else:
                return self.astype(np.floating).__mul__(other.astype(np.floating).__pow__(-1))
        elif isinstance(other, QuantityU):
            return other.__rtruediv__(self)
        elif isinstance(other, np.integer):
            if np.issubdtype(self.distribution.distribution.dtype, np.floating):
                return self.__mul__(float(other).__pow__(-1))
            else:
                return self.astype(np.floating).__mul__(float(other).__pow__(-1))
        else:
            if np.issubdtype(self.distribution.distribution.dtype, np.floating):
                return self.__mul__(other.__pow__(-1))
            else:
                return self.astype(np.floating).__mul__(other.__pow__(-1))

    def __rtruediv__(self, other):  ## other / self
        from .quantityu import QuantityU
        if isinstance(other, (self.__class__)):
            if np.issubdtype(self.distribution.distribution.value.dtype, np.floating):
                return self.__pow__(-1).__mul__(other.astype(np.floating))
            else:
                return self.astype(np.floating).__pow__(-1).__mul__(other.astype(np.floating))
        elif isinstance(other, QuantityU):
            return other.__truediv__(self)
        elif isinstance(other, np.integer):
            if np.issubdtype(self.distribution.distribution.dtype, np.floating):
                return self.__pow__(-1).__mul__(float(other))
            else:
                return self.astype(np.floating).__pow__(-1).__mul__(float(other))
        else:
            if np.issubdtype(self.distribution.distribution.dtype, np.floating):
                return self.__pow__(-1).__mul__(other)
            else:
                return self.astype(np.floating).__pow__(-1).__mul__(other)

    def __pow__(self, other):  ## from self ** other
        """
        [Describe] - 지수연산에서 other는 단위가 없거나 단위가 dimensionless_unscaled 이어야 한다.
        other가 '지수연산이 불가능한 단위를 가진 객체'인 경우를 별도로 예외처리하지 않고, 연산을 시도할 경우 에러가 발생하도록 의도함.
        띠리서 other은 반드시 numeric하거나, 단위가 dimensionless_unscaled 이어야 한다.
        """
        from .quantityu import QuantityU
        if isinstance(other, QuantityU):  ### Case(c) ValueU ** QuantityU
            result = other.__rpow__(self)
        else:
            if isinstance(other, self.__class__):
                result = self.__class__().set_manual(
                    center=self.center ** other.center,
                    distribution=(self.distribution ** other.distribution).astype(dtype=np.result_type(self.__dtype, other.__dtype)),
                ).set_digit(
                    digit_round=max(self._digit_round, other._digit_round),
                    digit_stringformat=max(self._digit_stringformat, other._digit_stringformat),
                )
            else:
                result = self.__class__().set_manual(
                    center=self.center ** other,
                    distribution=self.distribution ** other,
                ).set_digit(
                    digit_round=self._digit_round,
                    digit_stringformat=self._digit_stringformat,
                )

        return result

    def __rpow__(self, other):  ## from other ** self
        from .quantityu import QuantityU
        """
        [Describe] - other가 QuantityU의 인스턴스일 경우, QuantityU ** ValueU 연산은 QuantityU.__pow__()에서 처리할 것이다.
        따라서 Value.__rpow__()에 해당 케이스를 처리하는 별도의 기능을 구현하지 않고, 부적절한 연산을 시도할 경우 에러가 발생하도록 의도.
        """
        if isinstance(other, self.__class__):
            result = self.__class__().set_manual(
                center=other.center ** self.center,
                distribution=(other.distribution ** self.distribution).astype(dtype=np.result_type(self.__dtype, other.__dtype)),
            ).set_digit(
                digit_round=max(self._digit_round, other._digit_round),
                digit_stringformat=max(self._digit_stringformat, other._digit_stringformat),
            )
        else:
            result = self.__class__().set_manual(
                center=other ** self.center,
                distribution=other ** self.distribution,
            ).set_digit(
                digit_round=self._digit_round,
                digit_stringformat=self._digit_stringformat,
            )

        return result



    def __eq__(self, other):
        if isinstance(other, self.__class__):
            issame_center = self.center == other.center
            issame_distribution = np.all(self.distribution.distribution[np.where(np.logical_not(np.isnan(self.distribution.distribution)))[0]] == other.distribution.distribution[np.where(np.logical_not(np.isnan(other.distribution.distribution)))[0]])
            return issame_center and issame_distribution
        else:
            return False

    def __lt__(self, other):
        """
        [***ToDo***] (26-01-15) - False 결과의 이중성 검토, False 는 np.nan값과 비교했을때도 발생함. 이에 대한 처리 로직 필요.
        """
        if isinstance(other, self.__class__):
            assert self._comparison_criterion_by_center == other._comparison_criterion_by_center and self._comparison_criterion_threshold == other._comparison_criterion_threshold, 'Comparison criteria of two ValueU instances are different. Please set the same comparison criteria using the method \"set_comparison_mode\" before comparison operation.'
            if self._comparison_criterion_by_center:
                comparison = self.center < other.center
            else:
                comparison = np.average(self.distribution.distribution < other.distribution.distribution) > self._comparison_criterion_threshold
        else:
            if self._comparison_criterion_by_center:
                comparison = self.center < other
            else:
                comparison = np.average(self.distribution.distribution < other) > self._comparison_criterion_threshold
            """
            [***ToDo___] (25-02-11) - 해당 예외를 일으킬만한 상황이 있는가? 삭제해도 문제가 없는지 검토중
            """
            # raise TypeError(f'Not valid type {type(other)} of {other} for operation method \"{__name__}\"')

        return comparison

    def __gt__(self, other):
        """
        [***ToDo***] (26-01-15) - False 결과의 이중성 검토, False 는 np.nan값과 비교했을때도 발생함. 이에 대한 처리 로직 필요.
        """
        if isinstance(other, self.__class__):
            assert self._comparison_criterion_by_center == other._comparison_criterion_by_center and self._comparison_criterion_threshold == other._comparison_criterion_threshold, 'Comparison criteria of two ValueU instances are different. Please set the same comparison criteria using the method \"set_comparison_mode\" before comparison operation.'
            if self._comparison_criterion_by_center:
                comparison = self.center > other.center
            else:
                comparison = np.average(self.distribution.distribution > other.distribution.distribution) > self._comparison_criterion_threshold
        else:
            if self._comparison_criterion_by_center:
                comparison = self.center > other
            else:
                comparison = np.average(self.distribution.distribution > other) > self._comparison_criterion_threshold
            """
            [***ToDo___] (25-02-11) - 해당 예외를 일으킬만한 상황이 있는가? 삭제해도 문제가 없는지 검토중
            """
            # raise TypeError(f'Not valid type {type(other)} of {other} for operation method \"{__name__}\"')

        return comparison

    def __le__(self, other):
        """
        [***ToDo***] (26-01-15) - False 결과의 이중성 검토, False 는 np.nan값과 비교했을때도 발생함. 이에 대한 처리 로직 필요.
        """
        if isinstance(other, self.__class__):
            assert self._comparison_criterion_by_center == other._comparison_criterion_by_center and self._comparison_criterion_threshold == other._comparison_criterion_threshold, 'Comparison criteria of two ValueU instances are different. Please set the same comparison criteria using the method \"set_comparison_mode\" before comparison operation.'
            if self._comparison_criterion_by_center:
                comparison = self.center <= other.center
            else:
                comparison = np.average(self.distribution.distribution <= other.distribution.distribution) > self._comparison_criterion_threshold
        else:
            if self._comparison_criterion_by_center:
                comparison = self.center <= other
            else:
                comparison = np.average(self.distribution.distribution <= other) > self._comparison_criterion_threshold
            """
            [***ToDo___] (25-02-11) - 해당 예외를 일으킬만한 상황이 있는가? 삭제해도 문제가 없는지 검토중
            """
            # raise TypeError(f'Not valid type {type(other)} of {other} for operation method \"{__name__}\"')
            # raise TypeError(f'Not valid type {type(other)} of {other} for operation method \"{__name__}\"')

        return comparison

    def __ge__(self, other):
        """
        [***ToDo***] (26-01-15) - False 결과의 이중성 검토, False 는 np.nan값과 비교했을때도 발생함. 이에 대한 처리 로직 필요.
        """
        if isinstance(other, self.__class__):
            assert self._comparison_criterion_by_center == other._comparison_criterion_by_center and self._comparison_criterion_threshold == other._comparison_criterion_threshold, 'Comparison criteria of two ValueU instances are different. Please set the same comparison criteria using the method \"set_comparison_mode\" before comparison operation.'
            if self._comparison_criterion_by_center:
                comparison = self.center >= other.center
            else:
                comparison = np.average(self.distribution.distribution >= other.distribution.distribution) > self._comparison_criterion_threshold
        else:
            if self._comparison_criterion_by_center:
                comparison = self.center >= other
            else:
                comparison = np.average(self.distribution.distribution >= other) > self._comparison_criterion_threshold
            """
            [***ToDo___] (25-02-11) - 해당 예외를 일으킬만한 상황이 있는가? 삭제해도 문제가 없는지 검토중
            """
            # raise TypeError(f'Not valid type {type(other)} of {other} for operation method \"{__name__}\"')

        return comparison



    def __int__(self):
        return self.center.astype('int')

    def __round__(self, rounddigit: int=0):
        """
        $ >>> v = ValueU(3.141592653589793, 0.5)
        $ ... print(repr(round(v, 3)))
        $ ValueU(3.142, (-0.5, +0.5))
        """
        result_rounded = self.copy().set_manual(
            center=np.round(self.center, rounddigit),
            distribution=self.distribution
        ).set_digit(
            digit_round=rounddigit,
            digit_stringformat=self._digit_stringformat
        )

        return result_rounded
    
    # def __array__(self, dtype=None, copy=None):
    #     """
    #     [Interoperability: NumPy]
    #     Provides a NumPy array representation of the instance.
    #     This enables direct use of NumPy functions (e.g., np.mean, np.nanmean)
    #     by exposing the internal distribution data.
    #     """
    #     if dtype:
    #         return self.distribution.distribution.astype(dtype)
    #     return self.distribution.distribution
    


    def set_digit(self, digit_round=5, digit_stringformat=10):
        if isinstance(digit_round, int):
            self._digit_round = digit_round
        else:
            raise TypeError(f'{self.__callsign.ljust(10)}: Input argument \'digit_round\' for \"{__name__}\" type wrong - must be instance of {int}')

        if isinstance(digit_stringformat, int):
            self._digit_stringformat = digit_stringformat
        else:
            raise TypeError(f'{self.__callsign.ljust(10)}: Input argument \'digit_stringformat\' for \"{__name__}\" type wrong - must be instance of {int}')

        return self

    def get_numnotation(self, digit_round=None):
        if digit_round == None:
            digit_round = self._digit_round

        rounded_central = np.round(self.center, digit_round)

        if np.isnan(rounded_central):
            notation_central = np.nan
        elif int(rounded_central) == float(rounded_central):
            notation_central = rounded_central.astype("int")
        else:
            notation_central = rounded_central

        deviation = (self.distribution.distribution - rounded_central)

        mask_positivedeviation = deviation > 0
        mask_negativedeviation = deviation < 0

        if mask_positivedeviation.any():
            deviation_positive = deviation[mask_positivedeviation]
            uncertainty_upper = np.sqrt(np.dot(deviation_positive, deviation_positive) / deviation_positive.shape[0])
        else:
            uncertainty_upper = np.nan

        if mask_negativedeviation.any():
            deviation_negative = deviation[mask_negativedeviation]
            uncertainty_lower = np.sqrt(np.dot(deviation_negative, deviation_negative) / deviation_negative.shape[0])
        else:
            uncertainty_lower = np.nan

        return notation_central, [uncertainty_lower, uncertainty_upper]

    def get_strnotation(self, digit_round=None):
        if digit_round == None:
            digit_round = self._digit_round

        rounded_central = np.round(self.center, digit_round)

        if np.isnan(rounded_central):
            notation_central = 'np.nan'
        elif int(rounded_central) == float(rounded_central):
            notation_central = f'{rounded_central.astype("int")}'
        else:
            notation_central = f'{rounded_central}'

        # if np.sum(~np.isnan(self.distribution.distribution)) > 0:
        deviation = (self.distribution.distribution - rounded_central)
        if np.all(np.isnan(deviation)):
            notations_error = ['-np.nan', '+np.nan']
        else:
            # deviation_positive = deviation[np.where(deviation > 0)[0]]
            # deviation_negative = deviation[np.where(deviation < 0)[0]]
            #
            # uncertainty_upper = np.sqrt(np.nanmean(deviation_positive ** 2)) if np.sum(~np.isnan(deviation_positive)) > 0 else 0 if deviation_positive.shape[0] == 0 else np.nan
            # uncertainty_lower = np.sqrt(np.nanmean(deviation_negative ** 2)) if np.sum(~np.isnan(deviation_negative)) > 0 else 0 if deviation_negative.shape[0] == 0 else np.nan

            mask_positivedeviation = deviation > 0
            mask_negativedeviation = deviation < 0

            if mask_positivedeviation.any():
                deviation_positive = deviation[mask_positivedeviation]
                uncertainty_upper = np.sqrt(
                    np.dot(deviation_positive, deviation_positive) / deviation_positive.shape[0])
            else:
                uncertainty_upper = np.nan

            if mask_negativedeviation.any():
                deviation_negative = deviation[mask_negativedeviation]
                uncertainty_lower = np.sqrt(
                    np.dot(deviation_negative, deviation_negative) / deviation_negative.shape[0])
            else:
                uncertainty_lower = np.nan

            notations_error = []
            for error_sign, error_relative in zip([-1, 1], [uncertainty_lower, uncertainty_upper]):
                if not np.isnan(error_relative):
                    rounded_error_relative = np.round(error_relative, digit_round)
                    if int(rounded_error_relative) == float(rounded_error_relative):
                        notation_value = rounded_error_relative.astype("int")
                    else:
                        notation_value = rounded_error_relative
                    if error_sign == -1:
                        sign = '-'
                    else:
                        sign = '+'
                    if isinstance(notation_value, (int, np.integer)):
                        notations_error.append(f'{sign}{np.abs(notation_value)}')
                    else:
                        notations_error.append(f'{sign}{np.abs(notation_value):.{digit_round}f}')
                else:
                    notations_error.append('np.nan')  # to-do : how to show in the error is nan
            # else:
            #     notations_error = ['nan', 'nan']

        return notation_central, notations_error

    def __format__(self, format_spec):
        """
        [***ToDo***] (26-01-16) - f-string 및 format() 지원을 위한 커스텀 포매터 구현 플랜:

        1. 배경: 현재 __format__이 정의되지 않아 f-string 포맷 명시자(:>20 등) 사용 시
           객체의 문자열 표현이 아닌 기본 object 포맷이 적용되어 정렬이 무너지는 문제 발생.

        2. 구현 목표:
           - format_spec이 비어있을 경우 기존 __str__ 결과 반환.
           - 정렬(>, <, ^) 및 너비(width) 명시자가 들어올 경우,
             내부 수치 포맷팅(digit_round 등)을 유지하면서 외부 레이아웃 정렬을 수행하도록 설계.

        3. 상세 사양:
           - f"{instance:20}" -> 전체 '중심값(±오차)' 텍스트를 20자 내에서 정렬.
           - f"{instance:.3f}" -> 내부 digit_round 설정을 오버라이드하여 소수점 3자리 강제 적용 검토.

        Note: 현재는 str(instance).rjust(width) 방식으로 임시 대응 중이나,
              가독성과 견고함을 위해 파이썬 표준 포맷팅 프로토콜 도입이 필요함.
        """
        # 임시 방편: 포맷 명시자가 있어도 무시하고 str로 변환 후 포맷 적용
        return format(str(self), format_spec)



    @classmethod
    def help(cls):
        pydoc = PyDocFormatter(120)
        print(f'\n{"#" * pydoc.width}\n')

        print(
            f'\033[1m\033[3m\033[4m\033[7m{cls.__name__}\033[0m\033[4m: \033[1m{cls.__fullname} (Class) '
            f''.ljust(pydoc.width + 4 * 7 - len(str(cls.__version))) + str(cls.__version) + '\033[0m')
        print(f'last updated at {cls.__lastupdate.strftime("%Y-%m-%d")}'.rjust(pydoc.width))

        print(f'\n\033[1m\033[4m{"Introduction:".ljust(25)}\033[0m')
        print(pydoc.f(
            f' {cls.__name__} is a Python class for handling values and their associated uncertainties.'
            f' It stores, computes with, and represents these values not through traditional error propagation, but by modeling uncertainty distribution as a large sequence of sample values.'
            f' This implementation assumes an initial normal distribution based on the provided standard deviations.'
            f' Fundamentally based on the {unc.__name__} package, {cls.__name__} extends it with several key convenience features.'
            f' These enhancements, updated in August 2025, include \033[1mpickling\033[0m, robust preservation of the central value during operations, and more intuitive string representations.'
            # f' The underlying samples of a {cls.__name__} instance are treated as dependent when used in multiple operations, which differs from the independent variable assumption in analytical error propagation.'
            f' Additionally, the sampling method can lead to significant memory consumption, especially with a high number of samples, so careful management of memory and sample size is recommended for extensive use.'
            # f' The package requires `NumPy` and `Astropy` and was developed and tested on macOS Ventura; performance may vary on other systems pending further testing.'
        ))
        print('\n        \u2013 How to declare/generate an instance:')
        print(
            f'            $ >>> from {os.path.basename(os.path.dirname(__file__))} import {cls.__name__}\n'
            f'            $ >>> my_first_uncertain_value = {cls.__name__}(center=15, std=3)\n'
        )
        print(pydoc.f(
            f' A new {cls.__name__} instance is generated from the provided parameters: `center`, `std`, and `n_samples`.'
            f' The `center` parameter takes a numeric value (int, float) as the central value of the distribution.'
            f' If omitted, it defaults to \033[1mnp.nan\033[0m.'
            f' The `std` parameter defines the standard deviation of the uncertainty.'
            f' You can provide a single number for a \033[1msymmetric\033[0m uncertainty (e.g., `std=0.1` implies ±0.1), or a two-element array-like object (e.g., `[-0.2, 0.3]`) for an \033[1masymmetric\033[0m uncertainty.'
            f' An asymmetric uncertainty is modeled by combining the left half (from center) of one normal distribution and the right half of another, each defined with a different standard deviation.'
            f' If this parameter is omitted, it defaults to \033[1m0\033[0m.'
            f' The `n_samples` parameter specifies the number of random samples used to represent the uncertainty distribution.'
            f' \033[1mImportant\033[0m: `n_samples` is a class-level setting.'
            f' All instances of {cls.__name__} must share the same number of samples to ensure that Numpy calculations between them are mathematically valid.'
            f' Attempting to create a new instance with a different `n_samples` value than existing instances will raise an error.'
        ))
        print(' The full set of parameters is:\n')
        print(f'    \u2013 \033[1mcenter\033[0m [float]: \033[4mCentral\033[0m value (or representative/\033[4mmean\033[0m value) the representing probabilistic center')
        print(f'    \u2013 \033[1mstd\033[0m [float/float-arr]: \033[4mStandard deviation\033[0m(s) representing relative uncertainty(ies) from the central value')
        print(f'    \u2013 \033[1mn_samples\033[0m [unsigned int]: \033[4mNumber of samples\033[0m of uncertain distribution (by default, {cls._n_samples_defaultvalue})')
        print('')
        print(pydoc.f(
            f'If no keywords are specified, the first parameter is regarded as the central value and the second as the standard deviation.'
            f' \033[4mWe recommend that users avoid using protected methods\033[0m.'
            f' Although we do not restrict users from accessing protected methods like \'_set_central()\' and modifying object contents, \033[4mthese methods are not designed for user access\033[0m.'
        ))

        print(f'\n\033[1m\033[4m{"Application:".ljust(25)}\033[0m')
        print(f'\033[1m\u2022\033[0mMathematical Operation\033[0m')
        print(pydoc.f(
            f' {cls.__name__} uses a sampling-based approach to support non-normal uncertainty distributions.'
            f' During mathematical operations, the sampled sequences of the objects are calculated element-wise.'
            f' Because this calculation is performed index by index, any existing correlation between the objects is inherently reflected in the result.'
            f' If the objects are strictly independent, the outcome is equivalent to standard error propagation.'
        , tab=1))
        print('\n        \u2013 Example 1 of Application : Addition Operation of Symmetric Uncertainty')
        v1, v2 = cls(72, 3), cls(83, 4)
        print(f'            $ >>> v1, v2 = {repr(v1.copy().set_digit(0))}, {repr(v2.copy().set_digit(0))}\n            $ >>> print(\'v1 + v2  = \' + str(v1 + v2) + \' = \' + repr(v1 + v2))\n            $ v1 + v2  =  {str(v1 + v2)}  =  {repr(v1 + v2)}')
        print('\n        \u2013 Example 2 of Application : Addition Operation of Asymmetric Uncertainty')
        v1, v2 = cls(72, (-3, +5)), cls(83, (-4, +12))
        print(f'            $ >>> v1, v2 = {repr(v1.copy().set_digit(0))}, {repr(v2.copy().set_digit(0))}\n            $ >>> print(\'v1 + v2  = \' + str(v1 + v2) + \' = \' + repr(v1 + v2))\n            $ v1 + v2  =  {str(v1 + v2)}  =  {repr(v1 + v2)}\n')
        print(pydoc.f(
            f' Other basic arithmetic operations (-, *, /) and exponentiation (**) are supported in the same manner.'
            f' In-place operators (+=, -=, *=, /=, **=) are currently withheld to prevent unintended data mutation.'
            f' Logical operators (and, or) are not implemented, as handling boolean data requires further design.'
            f' Future releases may support additional mathematical functions.'
        , tab=1))
        print('\n\033[1m\u2022\033[0mPromotion\033[0m')
        from .quantityu import QuantityU
        print(pydoc.f(
            f' {cls.__name__} objects are designed to be compatible with {" ".join([word[0].upper() + word[1:] for word in str(u.__name__).split(".")])}.'
            f' Multiplying a {cls.__name__} object by an \'{u.__name__}\' object will promote it to a {QuantityU.__name__} object, which provides additional features for working with units.'
            f' See the {QuantityU.__name__} documentation for a complete description of its capabilities.'
        , tab=1))
        print('\n        \u2013 Example 3 of Application : Multiply with Unit Object')
        q = v1 * u.m  # It is now promoted as QuantityU, not ValueU anymore.
        print(
            f'            $ >>> q = v1 * u.m  # It is now promoted as QuantityU, not {cls.__name__} anymore.\n            $ >>> print(\'q  = \', str(q), \' = \', repr(q))\n            $ q  =  {str(q)}  =  {repr(q)}\n'
            f'            $ >>> print(type(q))\n            $ {QuantityU}')
        print('\n\033[1m\u2022\033[0mComparison\033[0m')
        print(pydoc.f(
            f' You can compare {cls.__name__} objects using standard comparison operators (<, >, <=, >=).'
            f' However, because ValueU is designed to represent a probability distribution rather than a single scalar, it lacks a single definitive reference point.'
            f' As a result, the criteria for comparison must be specified before performing these operations.'
            f' For initial setting, the comparison criterion is set to use the central value; it evaluates the objects based solely on their center attribute and ignores uncertainty.'
            f' To customize the criterion, the \'{cls.set_comparison_mode.__name__}()\' method provides an intuitive user-level interface.'
            f' This method accepts three boolean keyword arguments - \'central\', \'conservative\', and \'permissive\'.'
            f' Setting any of these to True enables the corresponding criterion.'
            f' Alternatively, you can pass a numeric value to the percentage keyword argument to manually set a custom significance level.'
            f' The selected comparison mode will govern the subsequent comparison criterion.'
        , tab=1))
        print('    *\033[1mNote\033[0m: \033[4mThis approach is currently under review and may undergo significant changes in future releases.\033[0m')
        print('    The specific behavior for each keyword argument is as follows:\n')
        print(f'        \u2013 \033[1mCentral\033[0m [bool]: Compares only the central values of the {cls.__name__} objects. This is the default setting')
        print(f'        \u2013 \033[1mConservative\033[0m [bool]: Applies a \033[4mconservative\033[0m (or strict) comparison approach. Returns True if the comparison\n            holds for 99.73% (3\u03C3) of the distribution.')
        print(f'        \u2013 \033[1mPermissive\033[0m [bool]: Applies a \033[4mpermissive\033[0m (or relaxed) comparison threshold. Returns True if the comparison hol-\n            ds for 68.27% (1\u03C3) of the distribution.')
        print(f'        \u2013 \033[1mPercentage\033[0m [bool]: Compares using a custom lower bound for the uncertainty ranges of each {cls.__name__} objects')
        print('')
        print(pydoc.f(
            f' Currently, both objects must share the exact same comparison mode.'
            f' Comparing objects with different modes is not implemented.'
            f' Once set, this mode is saved within the object and dictates all future comparisons.'
            f' Therefore, it is recommended to verify the current mode before performing any comparison.'
        , tab=1))
        print('\n            \u2013 Example 4 of Application : Comparison in Various Approaches')
        v3, v4 = cls(90, 50), cls(100, 10)
        print(
            f'            $ >>> v3, v4 = {repr(v3.set_digit(-1))}, {repr(v4.set_digit(-1))}\n\n'
            f'            $ >>> # Compare by central value\n'
            f'            $ ... if v3.{v3.set_comparison_mode.__name__}(central=True) < v4.{v4.set_comparison_mode.__name__}(central=True):\n            $ ...     print(\'v3 < v4 by central value\')\n'
            f'            $ ... elif v3.{v3.set_comparison_mode.__name__}(central=True) > v4.{v4.set_comparison_mode.__name__}(central=True):\n            $ ...     print(\'v3 > v4 by central value\')\n'
            f'            $ ... else:\n            $ ...     print(\'unable to compare by central value\')'
            f'            $ {"v3 < v4 by central value" if v3.set_comparison_mode(central=True) < v4.set_comparison_mode(central=True) else "v3 > v4 by central value" if v3.set_comparison_mode(central=True) > v4.set_comparison_mode(central=True) else "unable to compare by central value"}\n')
        print(
            f'            $ >>> # Compare as conservative approach (uncertainty range of v3 it too large, not judgeable)\n'
            f'            $ ... if v3.{v3.set_comparison_mode.__name__}(conservative=True) < v4.{v4.set_comparison_mode.__name__}(conservative=True):\n            $ ...     print(\'v3 < v4 in conservative approach\')\n'
            f'            $ ... elif v3.{v3.set_comparison_mode.__name__}(conservative=True) > v4.{v4.set_comparison_mode.__name__}(conservative=True):\n            $ ...     print(\'v3 > v4 in conservative approach\')\n'
            f'            $ ... else:\n            $ ...     print(\'unable to compare in conservative approach\')\n'
            f'            $ {"v3 < v4 in conservative approach" if v3.set_comparison_mode(conservative=True) < v4.set_comparison_mode(conservative=True) else "v3 > v4 in conservative approach" if v3.set_comparison_mode(conservative=True) > v4.set_comparison_mode(conservative=True) else "unable to compare in conservative approach"}\n')
        print(pydoc.f(
            f' In contrast to the previously described comparison methods, \033[4mthe == operator performs a strict equality check.\033[0m'
            f' It returns True only when both the center and the exact sequence of uncertainty values are completely identical.'
            f' An operation to evaluate the overall similarity between distributions is not yet implemented, as a suitable operator for this behavior has not been decided'
        , tab=1))
        print('\n\033[1m\u2022\033[0mAdditional Functions\033[0m')
        print(pydoc.f(
            f' The \'{cls.set_manual.__name__}(center, distribution: {unc.__name__}.{unc.Distribution.__name__})\' allows manual assignment of the central value and the uncertainty distribution.'
            f' If center is not provided, it automatically defaults to the median of the given distribution to ensure statistical consistency.'
        , tab=1))
        print('\n        \u2013 Example 5 of Application : Manual Set Instance')
        v5 = cls().set_manual(center=0, distribution=unc.Distribution([-3, -1, 2, 4]))
        print(f'            $ >>> from astropy import uncertainty as unc\n'
              f'            $ ... v5 = {cls.__name__}().{cls.set_manual.__name__}(center={v5.center}, distribution=unc.Distribution({str(list(v5.distribution.distribution))}))\n'
              f'            $ >>> print(\'v5 includes: \' + repr(v5.distribution.distribution))\n'
              f'            $ v5 includes: {repr(v5.distribution.distribution)}\n'
              f'            $ >>> print(repr(({cls.__name__}().{cls.set_manual.__name__}(center=0, distribution=v5.distribution + 2) - v5).distribution))\n'
              f'            $ {repr((cls().set_manual(center=0, distribution=v5.distribution + 2) - v5).distribution)}\n')
        print(pydoc.f(
            f' The {cls.copy.__name__}() method returns an independent duplicate of the {cls.__name__} object.'
            f' The copied instance retains the identical central value and sampled uncertainty sequence.'
            f' It ensures that modifications to the copy do not affect the original object.'
        , tab=1))
        print('\n        \u2013 Example 6 of Application : Copy Object')
        v6 = cls(1897, (-1, 10))
        print(f'            $ >>> v6 = {repr(v6.set_digit(0))}\n'
              f'            $ >>> # The copy holds the same sequence but is a distinct object in memory\n'
              f'            $ ... print((v6 == v6.{v6.copy.__name__}(), v6 is v6.{v6.copy.__name__}()))\n            $ {repr((v6 == v6.copy(), v6 is v6.copy()))}\n')
        print(pydoc.f(
            f' The \'enforced_positive\' / \'enforced_negative\' returns a new instance with the distribution restricted to the positive or negative domain.'
            f' Out-of-bounds samples are replaced with np.NaN to maintain sequence alignment and sample count without distorting the valid distribution.'
            f' A ValueError is raised if the central value contradicts the enforced domain.'
        , tab=1))
        # print(pydoc.f(
        #     f'\033[1m\033[4m\033[7mWarning!:\033[0m\033[1m Replacing out-of-bounds values with NaN automatically upcasts integer arrays to {np.float64.__name__}, as NumPy\'s NaN is strictly a floating-point representation.'
        #     f' \033[4m\033[7mDo not attempt\033[0m\033[1m to force-cast the resulting array back to integers using \'{cls.astype.__name__}(int)\'.'
        #     f' Because integer types cannot represent NaN, doing so will cause an integer overflow, converting NaN values into arbitrarily large negative integers (e.g., -9223372036854775808).'
        #     f' This will lead to \033[4m\033[7munexpected data distortion and silent bugs\033[0m\033[1m.'
        #     f' The current implementation is not designed to process NumPy masked arrays (numpy.ma) as a workaround.'
        #     f' Fully resolving this integer upcasting limitation will require additional development time in future updates.\033[0m'
        # , tab=1))
        print('\n        \u2013 Example 7 of Application : Sign-Enforced derivative')
        v7 = cls(100, 500)
        print(f'            $ >>> v7 = {repr(v7.set_digit(-2))}\n'
              f'            $ >>> print(repr(v7.enforced_positive))\n            $ {repr(v7.enforced_positive)}\n')
        print(pydoc.f(
            f' The \'{cls.resample.__name__}(n_samples)\' returns a new instance with the distribution resampled to the specified number of samples.'
            f' To prevent unnecessary duplication, it performs sampling without replacement for downscaling. '
            f' For upscaling, it performs sampling with replacement.'
        , tab=1))
        print('\n        \u2013 Example 8 of Application : Resampling')
        v8 = v7.resample(n_samples=5)
        print(f'            $ >>> v8 = v7.{v7.resample.__name__}(n_samples=100)\n'
              f'            $ >>> print(repr(v8) + \' has: \' + str(len(v8.distribution.distribution)) + \' samples\')\n'
              f'            $ {repr(v8) + " has: " + str(len(v8.distribution.distribution)) + " samples"}\n')
        print(pydoc.f(
            f' The \'{cls.astype.__name__}(dtype)\' returns a new instance with the underlying distribution array cast to the specified numeric data type (e.g., {np.__name__}.{np.float32.__name__}).'
            f' This preserves all metadata while updating the array\'s precision.'
            f' \033[1mCaution is required \033[4mif the distribution array contains NaN values\033[0m\033[1m (e.g., after using \'enforced_positive\' or \'enforced_negative\') and is cast to an integer.'
            # f' Replacing out-of-bounds values with NaN automatically upcasts integer arrays to float64, as NumPy\'s NaN is strictly a floating-point representation.'
            f' According to the IEEE 754 standard, {np.__name__}.nan is represented by specific bit patterns in the exponent and fraction fields of floating-point numbers.'
            f' Since integer types cannot accommodate this representation, casting NaN to an integer falls back to the minimum representable value of int64 (e.g., -9223372036854775808).'
            f' Although intended as an integer fallback representation for NaN, it arithmetically functions as an actual, extremely large negative number.'
            f' This is highly misleading and will lead to unexpected data distortion and silent bugs.'
            f' Therefore, \033[4m\033[7mit is strongly recommended not to cast an instance to an integer data type\033[0m\033[1m if you are aware of or suspect that the underlying distribution contains {np.__name__}.nan.'
        , tab=1))
        print('\n        \u2013 Example 9 of Application : Type Casting')
        remainders = (v6 - v6.astype(int)).distribution.distribution
        print(
            f'            $ >>> remainders = (v6 - v6.{v6.astype.__name__}(int)).distribution.distribution\n'
            f'            $ >>> print(str(remainders))\n'
            f'            $ ... print((min(remainders), max(remainders)))\n'
            f'            $ {str(remainders)}\n'
            f'            $ {str((min(remainders), max(remainders)))}\n'
        )







        print('\n\033[1m\u2022\033[0mFormatting\033[0m')
        print(pydoc.f(
            f' The \'{cls.set_digit.__name__}\' method allows you to customize how the object is displayed.'
            f' A first parameter, \'digit_round\', controls the number of decimal places for rounding (default: 5 digit), and \'digit_stringformat\' sets the total output width (default: 8 spaces).'
            f' For example, \".{cls.set_digit.__name__}(digit_round=3, digit_stringformat=10)\" would round to 3 decimal places and use a width of 10 characters.'
            f' Users can access the formatted representation via \'{cls.get_strnotation.__name__}\'.'
            f' However, the \'{cls.__str__.__name__}()\' and \'{cls.__repr__.__name__}()\' functions already use these settings.'
            f' Therefore, users rarely need to call \'get_notation()\' directly.'
        , tab=1))
        print('\n            \u2013 Example 11 of Application : Output Formatting')
        print(f'                $ >>> import numpy as np\n                $ >>> v11 = {cls.__name__}(np.pi, (-np.pi * 0.011, np.pi * 0.013))')
        v11 = cls(np.pi, (-np.pi * 0.011, np.pi * 0.013))
        print(f'                $ >>> print(\'formatted v11   : \', v11.{cls.set_digit.__name__}(7, 13))\n                $ ... print(\'ex-formatted v11: \', v11.{cls.set_digit.__name__}(10, 13))\n                $ formatted v11   : {str(v11.set_digit(7, 13))}\n                $ ex-formatted v11: {str(v11.set_digit(10, 13))}')

        print(f'\n\033[1m\033[4m{"Warning:".ljust(25)}\033[0m')
        print(pydoc.f(
            ' The operations in this package are designed to propagate errors based on normal distribution theory, treating errors in each variable independently.'
            ' However, due to the complexities of error propagation, some operations may not be mathematically or logically sound.'
            ' We are actively working to identify and address these potential issues through ongoing testing and review.\n\n'
            ' While some NumPy methods, such as \'sum()\', \'diff()\', \'prod()\', and interactions with `numpy.ndarray`, \033[4mappear to function, they have \033[1mnot been fully validated\033[0m.'
            ' \033[1m\033[4mExercise extreme caution\033[0m when using these methods, and do not rely on their output without careful verification.'
            ' Full support for \'numpy.ndarray\' is planned for future development.\n\n'
            ' We are dedicated to improving the accuracy and reliability of this package.'
            ' If you encounter results that differ from other packages, or if you suspect an incorrect or inappropriate operation, please submit a detailed bug report to the primary developer.'
            ' Your feedback is crucial for identifying and resolving any remaining issues.'
            ' We appreciate your collaboration in making this package more robust.'
        ))

        print(f'\n\033[1m\033[4m{"Credit:".ljust(25)}\033[0m')
        print('\033[1m\u2022\033[0mDevelopers\033[0m')
        developers = [f'    {"Main Developer ".ljust(50, "-")}: {cls.__developer["name"]} ({cls.__developer["contact"]})']
        for collaborator in cls.__collaborators:
            if collaborator["contact"] is None:
                developers.append(f'    {"Collaborate Developer ".ljust(50, "-")}: {collaborator["name"]}')
            else:
                developers.append(f'    {"Collaborate Developer ".ljust(50, "-")}: {collaborator["name"]} ({collaborator["contact"]})')
        for contributor in cls.__contributors:
            developers.append(f'    {"Contributor ".ljust(50, "-")}: {contributor["name"]} ({contributor["role"]})')
        print('\n'.join(developers) + '\n')
        print('\033[1m\u2022\033[0mHistory\033[0m')
        histories = [
            {'contents': 'First Development of Varu', 'period': '2349'},
            {'contents': 'First Separated Design of ValueU / QuantityU', 'period': '2406'},
            {'contents': 'Test for Operator Magic Method', 'period': '2412'},
            {'contents': 'Code Commenting', 'period': '2412'},
            {'contents': 'Operator Magic Method Restructuring', 'period': '2507'},
            {'contents': 'Help Message Implements', 'period': '2508'},
            {'contents': 'Minor hotfix (__rtruediv__ error)', 'period': '2509'},
            {'contents': 'Minor hotfix (__rper__ error)', 'period': '2509'},
            {'contents': 'Minor hotfix (system path error in help message)', 'period': '2509'},
            {'contents': 'Minor hotfix (__array_priority__)', 'period': '2510'},
            {'contents': 'Minor hotfix (absolute/relative selection in __init__)', 'period': '2510'},
            {'contents': 'Minor hotfix (inherit digit parameter)', 'period': '2510'},
            {'contents': 'Major upgrade (engine transition from theoretical model to approximate sampling)', 'period': '2535'},
            {'contents': 'Minor upgrade (added sign constraints for distributions)', 'period': '2601'},
            {'contents': 'Minor upgrade (implemented auxiliary methods for sampled distribution computation)', 'period': '2603'},
            {'contents': 'Minor upgrade (general validation completed, help() explanation)', 'period': '2609'},
            {'contents': 'Error hotfix (output formatting and operation)', 'period': '2610'},
        ]
        historys_period_len = max([len(history["period"]) for history in histories])
        for history_part in histories:
            print(f'    {(history_part["contents"] + " ").ljust(120 - historys_period_len - 6, "-")}: {history_part["period"].rjust(historys_period_len)}')
        # for history_part in histories:
        #     print(f'    {(history_part["contents"] + " ").ljust(50, "-")}: {history_part["period"]}')

        print(f'\n{"#" * pydoc.width}\n{f"Now, you can start {cls.__name__}".rjust(pydoc.width)}')

        return True

    def __str__(self, connection=''):
        notation_central, notations_error = self.get_strnotation()

        if notations_error[0][1:] == notations_error[-1][1:]:
            if notations_error[0] == 'np.nan' and notations_error[1] == 'np.nan':
                notation_error = f'  {notations_error[-1].ljust(self._digit_stringformat * 2 + 1)}'
            else:
                notation_error = f' ±{notations_error[0][1:].ljust(self._digit_stringformat * 2 + 1)}'
        else:
            notation_error = f' {notations_error[0].ljust(self._digit_stringformat)}, {notations_error[-1].ljust(self._digit_stringformat)}'

        notation_final = (
            f'{notation_central.ljust(self._digit_stringformat)}'
            f' '
            f'({notation_error})'
        )

        return notation_final

    def __repr__(self):
        notation_central, notations_error = self.get_strnotation()

        if notations_error[0][1:] == notations_error[-1][1:]:
            if notations_error[0] == 'np.nan' and notations_error[1] == 'np.nan':
                notation_error = 'np.nan'
            else:
                notation_error = f'{notations_error[0][1:]}'
        else:
            notation_error = f'({notations_error[0]}, {notations_error[-1]})'

        notation_final = (
            f'{self.__class__.__name__}({notation_central},'
            f' '
            f'{notation_error})')

        return notation_final



if __name__ == '__main__':
    ValueU().help()
