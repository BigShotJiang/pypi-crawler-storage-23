import datetime as dt
import re
from .versioning import SemVer


class PyDocFormatter:
    """
    A class to format strings into well-wrapped paragraphs for terminal display,
    correctly handling ANSI escape codes for styling.
    """
    # --- Metadata ---
    __fullname = 'String Formatter for Python Document'
    __firstwritten = dt.datetime.strptime('2024-03-06', '%Y-%m-%d')
    __lastupdate = dt.datetime.strptime('2026-02-23', '%Y-%m-%d')
    __version = SemVer(0, 4, 0)
    __developer = {'name': 'DH.Koh'}
    __callsign = 'PyDoc'

    # --- Constants ---
    # Regex to find all ANSI escape codes.
    ANSI_ESCAPE_PATTERN = re.compile(r'\x1b\[.*?m')

    def __init__(self, width: int = 120):
        """Initializes the formatter with a target line width."""
        self.width = width

    def _get_visible_length(self, s: str) -> int:
        """Calculates the visible length of a string, excluding ANSI codes."""
        return len(self.ANSI_ESCAPE_PATTERN.sub('', s))

    def _find_break_point(self, line: str, max_width: int) -> tuple[int, bool]:
        """
        Finds the best position to break a line, returning the index and
        whether a hyphen should be added.
        """
        visible_count = 0
        actual_idx = 0

        # 1. 보이는 글자 수가 max_width에 도달할 때까지 실제 인덱스를 전진
        while actual_idx < len(line) and visible_count < max_width:
            match = self.ANSI_ESCAPE_PATTERN.match(line, actual_idx)
            if match:
                actual_idx = match.end()  # ANSI 코드는 통째로 점프 (카운트 X)
            else:
                visible_count += 1
                actual_idx += 1

        # 만약 전체 문장이 max_width보다 짧다면 그대로 반환
        if self._get_visible_length(line) <= max_width:
            return len(line), False

        # 2. 단어 중간이 잘리지 않도록 마지막 공백 위치를 찾음
        line_to_check = line[:actual_idx]
        space_index = line_to_check.rfind(' ')

        if space_index != -1:
            return space_index, False  # 공백에서 자름
        else:
            return actual_idx, True  # 공백 없으면 하이픈 추가하며 자름

    def f(self, string: str, tab: int = 0) -> str:
        """
        Formats the given string into wrapped paragraphs.

        Args:
            string: The input string to format.
            tab: The number of tab stops (4 spaces each) to indent.

        Returns:
            A formatted string with lines wrapped to the specified width.
        """
        # Preserve user-intended paragraph breaks (2 or more newlines)
        # by replacing them with a unique placeholder.
        placeholder = "||PARAGRAPH_BREAK||"
        processed_string = re.sub(r'\n\s*\n', placeholder, string)
        # # Replace single newlines with spaces to join lines within a paragraph.
        # processed_string = processed_string.replace('\n', ' ')

        paragraphs = processed_string.split(placeholder)

        final_output = []
        indent = ' ' * (tab * 4)
        processed_width = self.width - len(indent)

        for paragraph in paragraphs:
            # paragraph = paragraph.strip()
            if not paragraph: continue

            wrapped_lines = []
            rest_part = paragraph

            while self._get_visible_length(rest_part) > 0:
                # Find the best point to break the line.
                break_point, add_hyphen = self._find_break_point(rest_part, processed_width)

                line = rest_part[:break_point]
                if add_hyphen:
                    line += '-'

                wrapped_lines.append(indent + line)
                # 자른 뒷부분을 다시 rest_part로 설정
                rest_part = rest_part[break_point:].lstrip()

            final_output.append('\n'.join(wrapped_lines))

        return '\n\n'.join(final_output)

    def test(self):
        print(self.f(
            """
             In the realm of Eldoria, nestled amidst rolling hills and ancient forests, lived Princess Elara, a maiden of unparalleled beauty and spirit.
            Her laughter was like the tinkling of a silver bell, and her eyes sparkled like the stars in the night sky.
            But her life was not without its shadows, for a fearsome dragon named \033[1m\033[4m\033[7mIgnis\033[0m dwelled in the nearby mountains, terrorizing the countryside and threatening the kingdom's peace.
            Ignis was a creature of immense power, its scales as hard as steel, its claws as sharp as razors, and its breath a torrent of fire that could incinerate anything in its path.
            The dragon had long been a scourge upon Eldoria, its fiery reign casting a pall over the land and instilling fear in the hearts of its people.
            The king, Elara's father, had tried countless times to slay the beast, but all his knights and armies had failed, their weapons no match for the dragon's impenetrable hide and devastating flames.
            And so, the kingdom lived in constant dread, wondering when the next fiery attack would come, when the dragon would once again descend from its mountain lair to wreak havoc upon their homes and lives.
            Princess Elara, despite her gentle nature, possessed a fierce spirit and a deep love for her people.
            She refused to cower in fear, refused to accept the dragon's tyranny as an inescapable fate.
            She yearned for a hero, a champion who could vanquish the beast and bring peace back to Eldoria.
    
             One day, a noble knight named Sir Gideon arrived in Eldoria, his heart burning with courage and his sword gleaming with honor.
            He had heard tales of the dragon's wrath and vowed to protect the princess and her kingdom from its fiery reign.
            Sir Gideon was a man of unwavering loyalty and unwavering chivalry, his spirit as bright as his polished armor.
            He was renowned throughout the land for his bravery and skill in battle, his name whispered with awe and respect by commoners and nobles alike.
            He was a knight of the highest caliber, a true embodiment of the chivalric code, his every action guided by honor, courage, and a deep sense of justice.
            When he arrived in Eldoria, his reputation preceded him, and the people greeted him with hope in their eyes, believing that he was the hero they had been waiting for, the one who could finally rid them of the dragon's menace.
            Princess Elara, upon meeting Sir Gideon, was immediately struck by his noble bearing and the intensity of his gaze.
            She saw in him a kindred spirit, a soul as pure and radiant as her own.
            As they spent time together, their bond deepened, and a spark of love ignited in their hearts.
            They shared long walks through the royal gardens, discussing matters of state and personal dreams, their conversations filled with laughter and shared silences that spoke volumes.
            Elara found herself drawn to Gideon's strength and his unwavering belief in the good, while Gideon was captivated by Elara's compassion and her unwavering determination to protect her people.
    
             But their budding romance was threatened by the looming presence of Ignis.
            The dragon's attacks grew bolder, its fiery breath scorching the land and casting a pall over the kingdom.
            Sir Gideon knew he had to act, to face the beast and protect the woman he had come to cherish.
            He could no longer stand by and watch the kingdom suffer, watch Elara live in fear.
            He had to act, even if it meant facing the dragon alone.
            He went to the king and offered his services, vowing to slay the dragon or die trying.
            The king, though hesitant to send his bravest knight to what seemed like certain death, could not deny Gideon's plea.
            He knew that the kingdom's hope rested on Gideon's shoulders, that if anyone could defeat the dragon, it was him.
            And so, with a heavy heart but with a glimmer of hope, the king gave his blessing.
            Before embarking on his perilous quest, Gideon sought out Elara, knowing that he could not leave without her blessing.
            He found her in the royal chapel, praying for the kingdom's safety.
            He knelt beside her, and they prayed together, their hearts intertwined, their love a silent plea for courage and protection.
            When they rose, Gideon took Elara's hand, his touch gentle yet firm.
            He told her of his plan, of his determination to face the dragon, not just for the kingdom but for her, for the love that had blossomed between them.
            Elara, though fearful for his life, did not try to dissuade him.
            She knew that this was his destiny, that he was the hero she and her people had been waiting for.
            Instead, she offered him her blessing, her love a shield of protection around his heart.
            She gave him a token of her affection, a small silver locket containing a strand of her hair, a reminder of the love that awaited him upon his return.
    
             With the princess's blessing and the kingdom's hopes resting on his shoulders, Sir Gideon ventured into the dragon's lair, a dark and treacherous cave hidden deep within the mountains.
            He battled his way through hordes of monstrous creatures, his sword flashing like lightning, his spirit unyielding.
            The cave was a labyrinth of winding tunnels and treacherous pitfalls, home to all manner of grotesque creatures that served as the dragon's minions.
            Gideon fought his way through them, his sword a whirlwind of steel, his shield deflecting their claws and fangs.
            He faced giant spiders, their webs sticky and strong, their venomous fangs dripping with poison.
            He battled packs of goblins, their eyes beady and malicious, their gnarled fingers wielding rusty daggers.
            He overcame each challenge, his resolve strengthened by the thought of Elara, by the love that burned within him.
            Finally, he stood before Ignis, the dragon's eyes burning with malevolent fire.
            The battle was fierce and unrelenting, the knight's courage matched only by the dragon's raw power.
            Ignis was a terrifying sight, its massive form filling the cave, its scales shimmering like a thousand emeralds, its eyes burning with ancient malice.
            It unleashed its fiery breath, a torrent of flames that engulfed the cave, forcing Gideon to dodge and weave, his shield raised in defense.
            Gideon fought with the strength of his love for Princess Elara, his heart filled with the fire of his devotion.
            He remembered her gentle smile, her kind words, her unwavering belief in him. He thought of the kingdom, of the people who lived in fear, of their hopes pinned on his success.
            He channeled all his love, all his hopes, all his fears into his sword, each strike aimed with precision, each parrydeflecting the dragon's attacks.
    
             In the end, it was not brute force that prevailed, but the knight's unwavering spirit and the purity of his heart.
            With a final, desperate strike, he pierced the dragon's heart, its roar echoing through the mountains as it fell lifeless to the ground.
            The dragon's death was a moment of profound triumph, a victory not just for Gideon but for the entire kingdom.
            The fiery reign of terror was finally over, the shadow that had loomed over Eldoria for so long was lifted.
            Sir Gideon, exhausted but victorious, emerged from the dragon's lair, the dragon's heart clutched in his gauntleted hand.
            He made his way back to Eldoria, his steps heavy but his heart light.
            He was greeted as a hero, the people cheering his name, their faces filled with joy and relief.
            The king embraced him, tears of gratitude streaming down his face.
            But it was Elara's embrace that Gideon craved the most.
            He found her in the throne room, surrounded by her court, her face radiant with happiness.
            He knelt before her, offering her the dragon's heart as a symbol of his love and his victory.
            She took it, her fingers brushing against his, her eyes filled with love and admiration.
            She knew that he was not just a hero, but the man she was destined to be with.
            They ruled Eldoria together, their reign marked by peace, prosperity, and the enduring spirit of chivalry.
            Their love story became a legend, a tale told and retold through the ages, a testament to the power of love, courage, and sacrifice.
            And so, the kingdom of Eldoria prospered, its people forever grateful to the noble knight who had slain the dragon and won the heart of their princess.
            # The end."""
        ))
