"""Version information for sagellm-gateway."""

__version__ = "0.5.4.0"
