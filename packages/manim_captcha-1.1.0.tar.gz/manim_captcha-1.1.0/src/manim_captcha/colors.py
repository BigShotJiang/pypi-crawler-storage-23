#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script:
    manim_captcha_generator.py
Description:
    Manim captcha colors (wrapper to isolate and abstract Manim colors).
Author:
    Jose Miguel Rios Rubio
Creation date:
    14/02/2026
Last modified date:
    14/02/2026
Version:
    1.0.0
"""

###############################################################################
# Libraries
###############################################################################

import manim


###############################################################################
# Captcha Colors
###############################################################################

class CaptchaColorCustom(manim.ManimColor):
    """Captcha custom color (alias from ManimColor)."""


class CaptchaColor:
    """Captcha colors."""
    WHITE = manim.WHITE
    GREY_A = manim.GREY_A
    GREY_B = manim.GREY_B
    GREY_C = manim.GREY_C
    GREY_D = manim.GREY_D
    GREY_E = manim.GREY_E
    BLACK = manim.BLACK
    LIGHTER_GREY = manim.LIGHTER_GREY
    LIGHT_GREY = manim.LIGHT_GREY
    GREY = manim.GREY
    DARK_GREY = manim.DARK_GREY
    DARKER_GREY = manim.DARKER_GREY
    BLUE_A = manim.BLUE_A
    BLUE_B = manim.BLUE_B
    BLUE_C = manim.BLUE_C
    BLUE_D = manim.BLUE_D
    BLUE_E = manim.BLUE_E
    PURE_BLUE = manim.PURE_BLUE
    BLUE = manim.BLUE
    DARK_BLUE = manim.DARK_BLUE
    TEAL_A = manim.TEAL_A
    TEAL_B = manim.TEAL_B
    TEAL_C = manim.TEAL_C
    TEAL_D = manim.TEAL_D
    TEAL_E = manim.TEAL_E
    TEAL = manim.TEAL
    GREEN_A = manim.GREEN_A
    GREEN_B = manim.GREEN_B
    GREEN_C = manim.GREEN_C
    GREEN_D = manim.GREEN_D
    GREEN_E = manim.GREEN_E
    PURE_GREEN = manim.PURE_GREEN
    GREEN = manim.GREEN
    YELLOW_A = manim.YELLOW_A
    YELLOW_B = manim.YELLOW_B
    YELLOW_C = manim.YELLOW_C
    YELLOW_D = manim.YELLOW_D
    YELLOW_E = manim.YELLOW_E
    YELLOW = manim.YELLOW
    GOLD_A = manim.GOLD_A
    GOLD_B = manim.GOLD_B
    GOLD_C = manim.GOLD_C
    GOLD_D = manim.GOLD_D
    GOLD_E = manim.GOLD_E
    GOLD = manim.GOLD
    RED_A = manim.RED_A
    RED_B = manim.RED_B
    RED_C = manim.RED_C
    RED_D = manim.RED_D
    RED_E = manim.RED_E
    PURE_RED = manim.PURE_RED
    RED = manim.RED
    MAROON_A = manim.MAROON_A
    MAROON_B = manim.MAROON_B
    MAROON_C = manim.MAROON_C
    MAROON_D = manim.MAROON_D
    MAROON_E = manim.MAROON_E
    MAROON = manim.MAROON
    PURPLE_A = manim.PURPLE_A
    PURPLE_B = manim.PURPLE_B
    PURPLE_C = manim.PURPLE_C
    PURPLE_D = manim.PURPLE_D
    PURPLE_E = manim.PURPLE_E
    PURPLE = manim.PURPLE
    PINK = manim.PINK
    LIGHT_PINK = manim.LIGHT_PINK
    ORANGE = manim.ORANGE
    LIGHT_BROWN = manim.LIGHT_BROWN
    DARK_BROWN = manim.DARK_BROWN
    GREY_BROWN = manim.GREY_BROWN

###############################################################################
