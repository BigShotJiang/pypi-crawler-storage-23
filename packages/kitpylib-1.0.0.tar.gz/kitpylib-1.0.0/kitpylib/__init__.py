'''
KitPyLib
========

A Python Library of basic tools.

How to use
----------
We recommend you to import `kitpy` as ``kp``:\n
  >>> import kitpy as kp
  >>> kp.fplot2d(lambda x: x**3, 0, 2)
  
Use the built-in ``help`` function to view a function's docstring:\n
  >>> help(kp.fplot2d)
  ... # doctest: +SKIP
  
Available subpackages
---------------------
PyFile
    KitPy's subpackage to solve txt file problems
PyWidget
    KitPy's subpackage about qt widgets
   
Utilities
---------
__version__
    KitPy version string
__copr__
    KitPy copyright string
__lic__
    KitPy license string
'''

from .init import *
__version__ = '1.0.0'
__copr__ = myinfo['copyright']
__lic__ = __copr__ + mit_license