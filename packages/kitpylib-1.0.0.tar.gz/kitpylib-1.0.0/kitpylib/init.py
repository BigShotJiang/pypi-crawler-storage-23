'''A module to set up KitPy.'''
from . import PyFile
from .PyMath import *
from .PyModule import *
from .PyPlot import *
