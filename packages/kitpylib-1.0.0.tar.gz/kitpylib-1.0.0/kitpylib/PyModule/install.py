from setuptools import setup, find_packages
import kitpylib as kpl

def confirm_info(all_modules):
    '''Confirm name, version of a module.'''
    name = all_modules.__name__
    version = all_modules.__version__
    return name, version

def mod_setup(module, **attrs):
    '''modules' setup. Need version string(__version__).\n
       **attrs: except `name`, `version` and `py_modules`.'''
    _name, _version = confirm_info(module)
    setup(name=_name, version=_version, py_modules=[_name], **attrs)
    
def pkg_setup(package, **attrs):
    '''packages' setup. Need version string(__version__).\n
       **attrs: except `name`, `version` and `packages`.'''
    _name, _version= confirm_info(package)
    setup(name=_name, packages=find_packages(), version=_version, **attrs)
    
def my_setup(pkg, **attrs):
    '''S_My setup tools.'''
    pkg_setup(pkg, 
              classifiers = ['Operating System :: Microsoft :: Windows :: Windows 11',
                             'Operating System :: Microsoft :: Windows :: Windows 7',
                             'Programming Language :: Python :: 3',
                             'Programming Language :: Python :: 3.9',
                             'License :: OSI Approved :: MIT License'],
              long_description = pkg.__doc__,
              long_description_content_type='text/x-rst',
              license=f'MIT License({kpl.__copr__})',
              author=kpl.myinfo['author'],
              author_email=kpl.myinfo['email'],
              **attrs)
