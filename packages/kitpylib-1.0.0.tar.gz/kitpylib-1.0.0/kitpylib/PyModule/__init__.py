from .docstr import generate_doc
from .install import mod_setup, pkg_setup, my_setup
from .license import myinfo, mit_license