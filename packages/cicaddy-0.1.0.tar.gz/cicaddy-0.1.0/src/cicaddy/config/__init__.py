"""Configuration modules for Cicaddy."""
