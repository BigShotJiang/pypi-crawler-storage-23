"""CLI module for Cicaddy."""

from cicaddy.cli.main import main

__all__ = ["main"]
