"""leashd — Remote AI-assisted development with safety constraints."""

__version__ = "0.4.0"
