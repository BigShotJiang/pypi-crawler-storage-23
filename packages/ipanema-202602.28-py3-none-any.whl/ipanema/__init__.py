from ipanema.models import database_connection, Language, LanguageFamily, Label


def query_language(spec: str) -> Language | None:
    """
    Query language by spec

    Args:
        spec: Spec for language
    Returns:
        the language
    """
    with database_connection():
        return Language.query(spec)


def query_family(spec: str) -> LanguageFamily | None:
    """
    Query family by spec

    Args:
        spec: a language spec
    Returns:
         the family
    """
    with database_connection():
        return LanguageFamily.query(spec)


def query_label(spec: str) -> Label | None:
    """
    Query label by spec

    Args:
        spec: a label spec (``en:American``)
    Returns:
         the label
    """
    lang_code, label = spec.split(":", 2)
    with database_connection():
        return Label.query(lang_code, label or lang_code)
