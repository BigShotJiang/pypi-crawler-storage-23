from . import base, Language
from peewee import TextField, ForeignKeyField, CompositeKey


class Script(base.Model):
    """
    A script used by one or more languages, , see
    `Module:scripts <https://en.wiktionary.org/wiki/Module:scripts>`_.
    """
    code = TextField(primary_key=True, null=False)
    """The script code, e.g. ``Latn``"""
    canonical_name = TextField(null=False)
    systems = TextField(null=True)
    """``alphabet``, ``abugida``, etc."""
    direction = TextField(null=True)
    """``rtl``, ``vertical-ltr``, etc."""
    parent_script = ForeignKeyField('self', to_field='code',
                                    db_column='parent_script', null=True)
    """the parent script, e.g. ``Latf`` => ``Latn``"""

    class Meta:
        table_name = 'scripts'

    def __str__(self):
        return self.canonical_name


class LanguageScripts(base.Model):
    language = ForeignKeyField(Language, db_column="lang_code", backref='scripts')
    script = ForeignKeyField(Script, db_column="script_code")

    class Meta:
        table_name = 'language_scripts'
        primary_key = CompositeKey('language', 'script')
