from __future__ import print_function
from ipanema import query_language, query_family, query_label
import sys


if len(sys.argv) > 1:
    input = sys.argv[1]
    print(repr(query_language(input) or
               query_family(input) or
               query_label(input)))
else:
    print(f"{sys.argv[0]} <query>")
