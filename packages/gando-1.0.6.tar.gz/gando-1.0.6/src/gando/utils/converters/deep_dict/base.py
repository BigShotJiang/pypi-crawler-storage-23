def any2dict(obj):
    if obj is None:
        return obj

    if isinstance(obj, [str, int, float]):
        return obj

    if isinstance(obj, dict):
        return {k: any2dict(v) for k, v in obj.items()}

    if isinstance(obj, list):
        return [any2dict(v) for v in obj]

    if isinstance(obj, tuple):
        return tuple(any2dict(v) for v in obj)

    if isinstance(obj, set):
        return set(any2dict(v) for v in obj)

    if hasattr(obj, '__dict__'):
        return {k: any2dict(v) for k, v in obj.__dict__.items()}

    return str(obj)
