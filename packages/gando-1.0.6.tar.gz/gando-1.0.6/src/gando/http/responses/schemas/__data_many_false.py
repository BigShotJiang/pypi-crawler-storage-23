from pydantic import BaseModel


class DataManyFalseSchema(BaseModel):
    result: dict
