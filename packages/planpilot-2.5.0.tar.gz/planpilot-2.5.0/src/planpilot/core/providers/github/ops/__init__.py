"""Internal operation helpers for GitHub provider."""
