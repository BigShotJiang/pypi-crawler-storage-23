"""Core GitHub provider implementation."""

from planpilot.core.providers.github.provider import GitHubProvider

__all__ = ["GitHubProvider"]
