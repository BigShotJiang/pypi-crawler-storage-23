"""Core target parsing utilities."""

from planpilot.core.targets.github_project import parse_project_url

__all__ = ["parse_project_url"]
