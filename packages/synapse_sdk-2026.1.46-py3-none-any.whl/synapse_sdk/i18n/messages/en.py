"""English translations for Synapse SDK log messages."""

from __future__ import annotations

MESSAGES: dict[str, str] = {
    # ==========================================================================
    # Common (synapse_sdk/plugins/log_messages.py)
    # ==========================================================================
    'PLUGIN_RUN_COMPLETE': 'Plugin run is complete.',
    # ==========================================================================
    # Upload (synapse_sdk/plugins/actions/upload/log_messages.py)
    # ==========================================================================
    'UPLOAD_INITIALIZED': 'Storage and paths initialized',
    'UPLOAD_METADATA_LOADED': 'Loaded metadata for {count} files',
    'UPLOAD_METADATA_INVALID_HEADER': (
        'Invalid metadata file: First column must be "filename" or "file_name", got "{header}"'
    ),
    'UPLOAD_COLLECTION_ANALYZED': 'Data collection analyzed: {count} file specifications',
    'UPLOAD_FILES_ORGANIZED': 'Organized {count} file groups',
    'UPLOAD_NO_FILES_FOUND': 'No files found to organize',
    'UPLOAD_VALIDATION_PASSED': 'Validation passed: {count} file groups',
    'UPLOAD_FILES_UPLOADING': 'Uploading {count} files',
    'UPLOAD_FILES_COMPLETED': 'Upload complete: {success} files uploaded',
    'UPLOAD_FILES_COMPLETED_WITH_FAILURES': 'Upload complete: {success} succeeded, {failed} failed',
    'UPLOAD_DATA_UNITS_CREATING': 'Creating {count} data units',
    'UPLOAD_DATA_UNITS_COMPLETED': '{count} data units created',
    'UPLOAD_DATA_UNITS_COMPLETED_WITH_FAILURES': 'Data units created: {success} succeeded, {failed} failed',
    'UPLOAD_COMPLETED': 'Upload complete: {files} files, {data_units} data units',
    # ==========================================================================
    # Train (synapse_sdk/plugins/actions/train/log_messages.py)
    # ==========================================================================
    'TRAIN_STARTING': 'Starting training for {epochs} epochs',
    'TRAIN_EPOCH_PROGRESS': 'Training epoch {epoch}/{total_epochs}',
    'TRAIN_VALIDATION_METRICS': 'Validation mAP50: {map50:.3f}, mAP50-95: {map50_95:.3f}',
    'TRAIN_COMPLETED': 'Training complete, uploading model...',
    'TRAIN_MODEL_SAVED': 'Model weights saved',
    'TRAIN_MODEL_UPLOADED': 'Model upload complete',
    # ==========================================================================
    # Export (synapse_sdk/plugins/actions/export/log_messages.py)
    # ==========================================================================
    'EXPORT_INITIALIZED': 'Export storage and paths initialized',
    'EXPORT_NO_RESULTS': 'No results found for export',
    'EXPORT_RESULTS_FETCHED': 'Retrieved {count} results for export',
    'EXPORT_CONVERTING': 'Converting {count} items',
    'EXPORT_CONVERTED': 'Converted {count} items',
    'EXPORT_SAVING_FILES': 'Saving {count} files',
    'EXPORT_FILES_SAVED': 'Saved {count} files',
    'EXPORT_FILES_SAVED_WITH_FAILURES': 'Saved {success} files, {failed} failed',
    'EXPORT_COMPLETED': 'Export complete: {count} items exported',
    'EXPORT_COMPLETED_WITH_FAILURES': 'Export complete: {exported} exported, {failed} failed',
    'EXPORT_SAVING_ORIGINAL': 'Saving original file.',
    'EXPORT_SAVING_JSON': 'Saving json file.',
    'EXPORT_STARTING': 'Starting export process.',
    'EXPORT_CONVERTING_DATASET': 'Converting dataset.',
    # ==========================================================================
    # ToTask (synapse_sdk/plugins/actions/to_task/log_messages.py)
    # ==========================================================================
    # Initialization
    'TASK_INITIALIZING': 'Initializing to_task workflow',
    'TASK_DATA_COLLECTION_LOADED': 'Data collection loaded successfully',
    # Preparation
    'TASK_PREPARING_FILE_METHOD': 'Preparing file-based annotation',
    'TASK_PREPARING_INFERENCE_METHOD': 'Preparing inference-based annotation',
    'TASK_SPECIFICATION_VALIDATED': 'Target specification validated',
    'TASK_INFERENCE_PARAMS_VALIDATING': 'Validating inference parameters',
    'TASK_INFERENCE_PARAMS_VALIDATED': 'Parameters validated: {pre_processor}, {model}',
    'TASK_PREPROCESSOR_RELEASE_FETCHING': 'Fetching pre-processor: {pre_processor}',
    'TASK_PREPROCESSOR_RELEASE_FETCHED': 'Release fetched: {plugin_code} v{version}',
    'TASK_PREPROCESSOR_CHECKING': 'Checking pre-processor status',
    'TASK_PREPROCESSOR_ALREADY_RUNNING': 'Pre-processor already running',
    'TASK_DATA_PREPROCESSOR_DEPLOYING': 'Starting pre-processor deployment',
    'TASK_PREPROCESSOR_WAITING': 'Waiting for pre-processor to be ready',
    'TASK_PREPROCESSOR_WAITING_PROGRESS': 'Still waiting... ({elapsed_seconds}s elapsed)',
    'TASK_PREPROCESSOR_READY': 'Pre-processor is ready',
    'TASK_INFERENCE_CONTEXT_READY': 'Inference context prepared successfully',
    # Fetching
    'TASK_FETCHING_TASKS': 'Fetching task list',
    'TASK_TASKS_FETCHED': 'Fetched {count} tasks for annotation',
    # Processing
    'TASK_DATA_ANNOTATING': 'Annotating {count} tasks ({method} method)',
    'TASK_DATA_COMPLETED': 'Annotation complete: {count} tasks annotated',
    'TASK_DATA_COMPLETED_WITH_FAILURES': 'Annotation complete: {success} succeeded, {failed} failed',
    # Finalization
    'TASK_FINALIZING': 'Finalizing annotation results',
    # ==========================================================================
    # Dataset (synapse_sdk/plugins/actions/dataset/log_messages.py)
    # ==========================================================================
    'DATASET_DOWNLOAD_STARTING': 'Starting dataset download (ID: {dataset_id})',
    'DATASET_SPLIT_DOWNLOADED': 'Downloaded {split_name} split: {count} items',
    'DATASET_DOWNLOAD_COMPLETED': 'Dataset download complete: {count} items',
    'DATASET_GT_EVENTS_FOUND': 'Found {count} ground truth events',
    'DATASET_DOWNLOAD_PARTIAL': 'Downloaded {downloaded} items ({missing} missing images)',
    'DATASET_CONVERTING': 'Converting dataset: {source} → {target}',
    'DATASET_CONVERSION_COMPLETED': 'Dataset conversion complete',
}

__all__ = ['MESSAGES']
