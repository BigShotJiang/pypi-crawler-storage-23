from __future__ import annotations

import logging
import os
import time
import warnings
from abc import ABC, abstractmethod
from collections.abc import Mapping
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Any, NotRequired, Protocol, TypedDict

if TYPE_CHECKING:
    from synapse_sdk.plugins.models.logger import LogLevel

# Module-level logger for SDK output
_logger = logging.getLogger('synapse_sdk.loggers')

# LogLevel string value → Python logging level mapping
_LOG_LEVEL_MAP: dict[str, int] = {
    'debug': logging.DEBUG,
    'info': logging.INFO,
    'success': logging.INFO,
    'warning': logging.WARNING,
    'danger': logging.ERROR,
    'error': logging.ERROR,
    'critical': logging.CRITICAL,
}


def _resolve_level_with_deprecation(
    level: 'LogLevel | None',
    context: 'str | LogLevel | None',
    default: 'LogLevel | None' = None,
    stacklevel: int = 3,
) -> 'LogLevel':
    """Resolve level, handling deprecated context parameter.

    Args:
        level: The new preferred level parameter.
        context: The deprecated context parameter.
        default: Default LogLevel if neither is provided. If None, uses LogLevel.INFO.
        stacklevel: Stack level for the deprecation warning.

    Returns:
        Resolved LogLevel.
    """
    from synapse_sdk.plugins.models.logger import LogLevel

    if context is not None:
        warnings.warn(
            "The 'context' parameter is deprecated. Use 'level' instead.",
            DeprecationWarning,
            stacklevel=stacklevel,
        )
        if level is None:
            return context if isinstance(context, LogLevel) else LogLevel(context)

    if default is None:
        default = LogLevel.INFO

    return level if level is not None else default


class LoggerBackend(Protocol):
    """Protocol for logger backends that handle data synchronization."""

    def publish_progress(self, job_id: str, progress: 'ProgressData') -> None: ...
    def publish_metrics(self, job_id: str, metrics: dict[str, Any]) -> None: ...
    def publish_log(self, job_id: str, log_entry: 'LogEntry') -> None: ...


@dataclass
class ProgressData:
    """Immutable progress data snapshot."""

    percent: float
    time_remaining: float | None = None
    elapsed_time: float | None = None
    status: str = 'running'


class MessageLogData(TypedDict):
    """event='message' 또는 event='debug' log entry의 data 구조.

    level 정보는 log_entry['level']에 기록되므로 data에 포함하지 않음.

    Attributes:
        content: 사용자에게 표시될 메시지 본문.
        key: LogMessageCode 사용 시 원본 코드 값 (e.g., 'UPLOAD_FILES_UPLOADING'). 선택적.
    """

    content: str
    key: NotRequired[str]


@dataclass
class LogEntry:
    """Single log entry."""

    event: str
    data: dict[str, Any]
    timestamp: float = field(default_factory=time.time)
    file: str | None = None
    step: str | None = None  # 로그가 발생한 step
    level: Any = None  # 로그 레벨 (LogLevel enum, 순환 import 방지를 위해 Any)
    language: str | None = None  # i18n 언어 코드 (ISO 639-1)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API serialization."""
        result: dict[str, Any] = {
            'event': self.event,
            'data': self.data,
            'timestamp': self.timestamp,
            'file': self.file,
            'step': self.step,
            'level': self.level.value if self.level else None,
        }
        if self.language is not None:
            result['language'] = self.language
        return result


class BaseLogger(ABC):
    """Base class for logging progress, metrics, and events.

    All state is instance-level to prevent cross-instance contamination.
    Uses composition over inheritance for backend communication.
    """

    _start_time: float
    _progress: dict[str, ProgressData]
    _metrics: dict[str, dict[str, Any]]
    _step_start_times: dict[str, float]
    _current_step: str | None
    _is_finished: bool

    def __init__(self) -> None:
        self._start_time = time.monotonic()
        self._progress = {}
        self._metrics = {}
        self._step_start_times = {}
        self._current_step = None
        self._current_step_order: int | None = None
        self._is_finished = False

    def set_step(self, step: str | None, order: int | None = None) -> None:
        """Set the current step for logging context.

        Args:
            step: The step name, or None to clear.
            order: Optional 0-based step order from registry registration.
                When step is None, order is also cleared.
        """
        self._current_step = step
        self._current_step_order = order if step is not None else None

    def get_step(self) -> str | None:
        """Get the current step.

        Returns:
            The current step name, or None if not set.
        """
        return self._current_step

    def get_step_order(self) -> int | None:
        """Get the current step order.

        Returns:
            The current step order (0-based index), or None if not set.
        """
        return self._current_step_order

    def _raise_if_finished(self) -> None:
        if self._is_finished:
            raise RuntimeError('Cannot log to a finished logger')

    def log(
        self,
        level: LogLevel,
        event: str,
        data: dict[str, Any],
        file: str | None = None,
        step: str | None = None,
    ) -> None:
        """Log an event with data.

        Args:
            level: Log level (LogLevel enum).
            event: Event name/type.
            data: Dictionary of event data.
            file: Optional file path associated with the event.
            step: Optional step name. Uses current step if not specified.

        Raises:
            TypeError: If level is not a LogLevel enum or data is not a dictionary.
            RuntimeError: If logger is already finished.
        """
        self._raise_if_finished()

        # Validate level is a LogLevel enum (duck typing check to avoid circular import)
        if not (isinstance(level, Enum) and hasattr(level, 'value') and level.value in _LOG_LEVEL_MAP):
            raise TypeError(f'level must be a LogLevel enum, got {type(level).__name__}')

        if not isinstance(data, Mapping):
            raise TypeError(f'data must be a dict, got {type(data).__name__}')

        data = dict(data)  # Copy to avoid mutating input
        # Use explicit step or fall back to current step
        effective_step = step if step is not None else self._current_step
        self._log_impl(event, data, file, effective_step, level)

    def info(self, message: str) -> None:
        """Log an info message."""
        from synapse_sdk.plugins.models.logger import LogLevel

        self.log(LogLevel.INFO, 'message', self._build_message_data(message))

    def debug(self, message: str) -> None:
        """Log a debug message.

        Unlike other log methods that use 'message' event (delivered to Synapse users),
        debug logs use 'debug' event to avoid delivering internal debug output to users.
        """
        from synapse_sdk.plugins.models.logger import LogLevel

        self.log(LogLevel.DEBUG, 'debug', self._build_message_data(message))

    def warning(self, message: str) -> None:
        """Log a warning message."""
        from synapse_sdk.plugins.models.logger import LogLevel

        self.log(LogLevel.WARNING, 'message', self._build_message_data(message))

    def error(self, message: str) -> None:
        """Log an error message."""
        from synapse_sdk.plugins.models.logger import LogLevel

        self.log(LogLevel.ERROR, 'message', self._build_message_data(message))

    def critical(self, message: str) -> None:
        """Log a critical message."""
        from synapse_sdk.plugins.models.logger import LogLevel

        self.log(LogLevel.CRITICAL, 'message', self._build_message_data(message))

    @staticmethod
    def _build_message_data(
        content: str,
        key: str | None = None,
    ) -> MessageLogData:
        """message/debug 이벤트용 data dict 생성."""
        data: MessageLogData = {'content': content}
        if key is not None:
            data['key'] = key
        return data

    def set_progress(
        self,
        current: int,
        total: int,
        step: str | None = None,
    ) -> None:
        """Set progress for the current operation.

        Args:
            current: Current progress value (0 to total).
            total: Total progress value.
            step: Optional step name. Uses current step if not specified.

        Raises:
            ValueError: If current/total values are invalid.
            RuntimeError: If logger is already finished.
        """
        self._raise_if_finished()

        if total <= 0:
            raise ValueError(f'total must be > 0, got {total}')
        if not 0 <= current <= total:
            raise ValueError(f'current must be between 0 and {total}, got {current}')

        effective_step = step if step is not None else self._current_step
        key = effective_step or '__default__'
        now = time.monotonic()

        # Initialize start time on first call for this step
        if key not in self._step_start_times or current == 0:
            self._step_start_times[key] = now

        elapsed = now - self._step_start_times[key]
        percent = round((current / total) * 100, 2)

        # Calculate time remaining
        time_remaining = None
        if current > 0:
            rate = elapsed / current
            time_remaining = round(rate * (total - current), 2)

        progress = ProgressData(
            percent=percent,
            time_remaining=time_remaining,
            elapsed_time=round(elapsed, 2),
        )

        self._progress[key] = progress
        self._on_progress(progress, effective_step)

    def set_progress_failed(self, step: str | None = None) -> None:
        """Mark progress as failed.

        Args:
            step: Optional step name.

        Raises:
            RuntimeError: If logger is already finished.
        """
        self._raise_if_finished()

        key = step or '__default__'
        elapsed = None

        if key in self._step_start_times:
            elapsed = round(time.monotonic() - self._step_start_times[key], 2)

        progress = ProgressData(
            percent=0.0,
            time_remaining=None,
            elapsed_time=elapsed,
            status='failed',
        )

        self._progress[key] = progress
        self._on_progress(progress, step)

    def set_metrics(
        self,
        value: dict[str, Any],
        step: str | None = None,
    ) -> None:
        """Set metrics for a step.

        Args:
            value: Dictionary of metric values.
            step: Optional step name. Uses current step if not specified.

        Raises:
            ValueError: If no step is available.
            TypeError: If value is not a dictionary.
            RuntimeError: If logger is already finished.
        """
        self._raise_if_finished()

        if not isinstance(value, Mapping):
            raise TypeError(f'value must be a dict, got {type(value).__name__}')

        effective_step = step if step is not None else self._current_step

        if not effective_step:
            raise ValueError('step must be specified or set via set_step()')

        data = dict(value)  # Copy

        if effective_step not in self._metrics:
            self._metrics[effective_step] = {}
        self._metrics[effective_step].update(data)

        self._on_metrics(effective_step, self._metrics[effective_step])

    def get_progress(self, step: str | None = None) -> ProgressData | None:
        """Get progress for a step."""
        key = step or '__default__'
        return self._progress.get(key)

    def get_metrics(self, step: str | None = None) -> dict[str, Any]:
        """Get metrics, optionally filtered by step."""
        if step:
            return dict(self._metrics.get(step, {}))
        return {k: dict(v) for k, v in self._metrics.items()}

    def finish(self) -> None:
        """Mark the logger as finished. No further logging is allowed."""
        self._is_finished = True
        self._on_finish()

    @abstractmethod
    def _log_impl(
        self,
        event: str,
        data: dict[str, Any],
        file: str | None,
        step: str | None,
        level: LogLevel | None = None,
    ) -> None:
        """Implementation-specific log handling."""
        ...

    def _on_progress(self, progress: ProgressData, step: str | None) -> None:
        """Hook called when progress is updated. Override in subclasses."""
        pass

    def _on_metrics(self, step: str, metrics: dict[str, Any]) -> None:
        """Hook called when metrics are updated. Override in subclasses."""
        pass

    def _on_finish(self) -> None:
        """Hook called when logger is finished. Override in subclasses."""
        pass


class ConsoleLogger(BaseLogger):
    """Logger that prints to console with colored output based on log level.

    Uses tqdm progress bars for visual progress tracking when available.
    Falls back to simple console output if tqdm is not installed.
    """

    # ANSI color codes
    _COLORS = {
        'debug': '\033[90m',  # Gray/Dim
        'info': '\033[94m',  # Light Blue
        'success': '\033[92m',  # Bright Green
        'warning': '\033[93m',  # Bright Yellow
        'danger': '\033[91m',  # Bright Red
        'error': '\033[91m',  # Bright Red
        'critical': '\033[1;91m',  # Bold Bright Red
        'reset': '\033[0m',  # Reset
    }

    def __init__(self) -> None:
        super().__init__()
        self._progress_bars: dict[str, Any] = {}  # step -> tqdm bar
        self._bar_totals: dict[str, float] = {}  # Track total for each bar
        self._tqdm_available: bool | None = None  # Cache tqdm availability

    def _print(self, message: str) -> None:
        """Print message, using tqdm.write() if tqdm is active to avoid progress bar corruption."""
        # Use tqdm.write() if we have active progress bars
        if self._progress_bars:
            try:
                from tqdm import tqdm

                tqdm.write(message)
                return
            except (ImportError, AttributeError):
                pass
        # Fallback to regular print
        print(message, flush=True)

    def _colorize(self, text: str, level: str | None, bold: bool = False) -> str:
        """Apply color to text based on log level.

        Args:
            text: Text to colorize.
            level: Log level string (lowercase).
            bold: Whether to apply bold formatting.

        Returns:
            Colorized text with ANSI codes.
        """
        if level and level.lower() in self._COLORS:
            color = self._COLORS[level.lower()]
            reset = self._COLORS['reset']
            bold_code = '\033[1m' if bold else ''
            return f'{bold_code}{color}{text}{reset}'
        return text

    def _log_impl(
        self,
        event: str,
        data: dict[str, Any],
        file: str | None,
        step: str | None,
        level: LogLevel | None = None,
    ) -> None:
        level_str = level.value.upper() if level else 'INFO'
        level_value = level.value if level else 'info'

        # Build message parts consistently: [STEP: step] [LEVEL: level] event data
        # If event equals step, omit event to avoid duplication
        event_part = '' if (step and event == step) else f'{event} '
        data_str = str(data) if data else ''

        # Highlight both step name and log level with bold
        if step:
            colored_step = self._colorize(f'[STEP: {step}]', level_value, bold=True)
            colored_level = self._colorize(f' [LEVEL: {level_str}]', level_value, bold=True)
            prefix = colored_step + colored_level
        else:
            colored_level = self._colorize(f'[LEVEL: {level_str}]', level_value, bold=True)
            prefix = colored_level

        # Regular color for the message body
        message_body = f' {event_part}{data_str}'
        colored_body = self._colorize(message_body, level_value)

        colored_message = prefix + colored_body

        # Use _print() which handles tqdm compatibility
        self._print(colored_message)

    def _on_progress(self, progress: ProgressData, step: str | None) -> None:
        """Update or create tqdm progress bar, fallback to console if unavailable."""
        # Check tqdm availability once
        if self._tqdm_available is None:
            try:
                import tqdm  # noqa: F401

                self._tqdm_available = True
            except ImportError:
                self._tqdm_available = False

        # Use tqdm if available
        if self._tqdm_available:
            self._on_progress_tqdm(progress, step)
        else:
            # Fallback to console output: [STEP: step] [LEVEL: level] message
            if step:
                colored_step = self._colorize(f'[STEP: {step}]', 'info', bold=True)
                colored_level = self._colorize(' [LEVEL: INFO]', 'info', bold=True)
                prefix = colored_step + colored_level
            else:
                colored_level = self._colorize('[LEVEL: INFO]', 'info', bold=True)
                prefix = colored_level

            message_body = f' Progress: {progress.percent}% | ETA: {progress.time_remaining}s'
            colored_body = self._colorize(message_body, 'info')
            self._print(prefix + colored_body)

    def _on_progress_tqdm(self, progress: ProgressData, step: str | None) -> None:
        """Use tqdm progress bar for visual progress tracking."""
        from tqdm import tqdm

        key = step or '__default__'

        # Create new progress bar if needed
        if key not in self._progress_bars:
            # Use dim/gray color for less bright appearance with [STEP:] prefix
            desc = f'\033[90m[STEP: {step}]\033[0m' if step else '\033[90mProgress\033[0m'
            self._progress_bars[key] = tqdm(
                total=100,
                desc=desc,
                unit='%',
                bar_format='{desc}: {percentage:3.0f}%|{bar}| [{elapsed}<{remaining}]',
                leave=True,
                position=len(self._progress_bars),  # Stack bars vertically
                colour='white',  # Use white instead of bright colors
            )
            self._bar_totals[key] = 0

        bar = self._progress_bars[key]
        current_total = self._bar_totals[key]

        # Update progress bar (increment by the difference)
        increment = progress.percent - current_total
        if increment > 0:
            bar.update(increment)
            self._bar_totals[key] = progress.percent

        # Close bar if complete
        if progress.percent >= 100 or progress.status == 'failed':
            bar.close()
            del self._progress_bars[key]
            del self._bar_totals[key]

    def _on_finish(self) -> None:
        """Close all remaining progress bars."""
        for bar in self._progress_bars.values():
            bar.close()
        self._progress_bars.clear()
        self._bar_totals.clear()

    def __del__(self) -> None:
        """Ensure all progress bars are closed on cleanup."""
        for bar in self._progress_bars.values():
            try:
                bar.close()
            except Exception:
                pass

    def _on_metrics(self, step: str, metrics: dict[str, Any]) -> None:
        # Format: [STEP: step] [LEVEL: level] message
        colored_step = self._colorize(f'[STEP: {step}]', 'info', bold=True)
        colored_level = self._colorize(' [LEVEL: INFO]', 'info', bold=True)
        message_body = f' Metrics: {metrics}'
        colored_body = self._colorize(message_body, 'info')
        self._print(colored_step + colored_level + colored_body)

    def log_event(self, event: str, data: dict[str, Any], file: str | None = None) -> None:
        """Log an event (console-only)."""
        file_info = f' (file: {file})' if file else ''
        colored_level = self._colorize('[LEVEL: INFO]', 'info', bold=True)
        message_body = f' [{event}] {data}{file_info}'
        colored_body = self._colorize(message_body, 'info')
        self._print(colored_level + colored_body)

    def log_metric(
        self,
        category: str,
        key: str,
        value: float | int,
        **metrics: Any,
    ) -> None:
        """Log a training metric (console-only)."""
        colored_level = self._colorize('[LEVEL: INFO]', 'info', bold=True)
        message_body = f' [metric] category={category}, {key}={value}, {metrics}'
        colored_body = self._colorize(message_body, 'info')
        self._print(colored_level + colored_body)

    def log_visualization(
        self,
        category: str,
        group: str,
        index: int,
        image: str,
        **meta: Any,
    ) -> None:
        """Log a visualization (console-only)."""
        colored_level = self._colorize('[LEVEL: INFO]', 'info', bold=True)
        message_body = f' [visualization] category={category}, group={group}, index={index}, image={image}'
        colored_body = self._colorize(message_body, 'info')
        self._print(colored_level + colored_body)

    def log_trials(
        self,
        data: dict[str, Any] | None = None,
        *,
        trials: dict[str, Any] | None = None,
        base: list[str] | None = None,
        hyperparameters: list[str] | None = None,
        metrics: list[str] | None = None,
        best_trial: str = '',
    ) -> None:
        """Log Ray Tune trial progress (console-only)."""
        if data is None:
            data = {'trials': trials or {}, 'best_trial': best_trial}
        colored_level = self._colorize('[LEVEL: INFO]', 'info', bold=True)
        message_body = f' [trials] {data}'
        colored_body = self._colorize(message_body, 'info')
        self._print(colored_level + colored_body)

    def log_message(
        self,
        message: str,
        level: 'LogLevel | None' = None,
        *,
        context: 'str | LogLevel | None' = None,
    ) -> None:
        """Log a message (console-only).

        Args:
            message: The message content.
            level: Log level (LogLevel enum). Preferred parameter.
            context: DEPRECATED. Use 'level' instead.
        """
        level = _resolve_level_with_deprecation(level, context)
        level_str = level.value.upper()
        colored_level = self._colorize(f'[LEVEL: {level_str}]', level.value, bold=True)
        colored_body = self._colorize(f' {message}', level.value)
        self._print(colored_level + colored_body)


class BackendLogger(BaseLogger):
    """Logger that syncs with a remote backend.

    Uses a backend interface for decoupled communication.
    """

    _backend: LoggerBackend | None
    _job_id: str
    _log_queue: list[LogEntry]

    def __init__(self, backend: LoggerBackend | None, job_id: str) -> None:
        super().__init__()
        self._backend = backend
        self._job_id = job_id
        self._log_queue = []

    def _log_impl(
        self,
        event: str,
        data: dict[str, Any],
        file: str | None,
        step: str | None,
        level: LogLevel | None = None,
    ) -> None:
        entry = LogEntry(event=event, data=data, file=file, step=step, level=level)
        self._log_queue.append(entry)
        self._flush_logs()

    def _on_progress(self, progress: ProgressData, step: str | None) -> None:
        if self._backend is None:
            return

        try:
            self._backend.publish_progress(self._job_id, progress)
        except Exception as e:
            _logger.error(f'Failed to publish progress: {e}')

    def _on_metrics(self, step: str, metrics: dict[str, Any]) -> None:
        if self._backend is None:
            return

        try:
            self._backend.publish_metrics(self._job_id, {step: metrics})
        except Exception as e:
            _logger.error(f'Failed to publish metrics: {e}')

    def _flush_logs(self) -> None:
        if self._backend is None or not self._log_queue:
            return

        try:
            for entry in self._log_queue:
                self._backend.publish_log(self._job_id, entry)
            self._log_queue.clear()
        except Exception as e:
            _logger.error(f'Failed to flush logs: {e}')

    def _on_finish(self) -> None:
        self._flush_logs()


class JobLogger(BaseLogger):
    """Logger that prints to console AND reports progress/metrics to the Synapse backend.

    Sends progress_record and metrics_record via BackendClient.update_job(),
    and log entries via BackendClient.create_logs().

    - progress_record: {'record': {steps...}, 'current_progress': {overall, step, percent, time_remaining}}
    - metrics_record: {'record': {'steps': {step: {metrics}}}}

    Backend errors are silently caught to avoid crashing training.
    """

    def __init__(
        self,
        client: Any,
        job_id: str,
        step_proportions: dict[str, int] | None = None,
    ) -> None:
        """Initialize JobLogger.

        Args:
            client: BackendClient instance for API calls.
            job_id: Synapse job ID (UUID, passed as RAY_JOB_ID in the worker).
            step_proportions: Optional mapping of step name to proportion weight.
                If not provided, weights are dynamically assigned based on usage order.
                This is typically auto-configured by Orchestrator from step definitions.
        """
        super().__init__()
        self._client = client
        self._job_id = job_id
        self._step_proportions: dict[str, int] = dict(step_proportions) if step_proportions else {}
        self._progress_record: dict[str, Any] = {
            'steps': {step: {'proportion': prop} for step, prop in self._step_proportions.items()},
        }
        self._current_progress_step: str | None = None
        self._metrics_record: dict[str, Any] = {}
        self._logs_queue: list[dict[str, Any]] = []
        self._step_order: list[str] = []  # Track order of step usage
        self._locked_weights: dict[str, float] = {}  # Cache weights once assigned
        self._data_prep_used: float = 0.0  # Track weight used by dynamic steps
        self._max_overall: float = 0.0  # Ensure progress never decreases

    def set_step_proportions(
        self,
        proportions: dict[str, int],
        orders: dict[str, int] | None = None,
    ) -> None:
        """Set step proportions after initialization.

        Call this before any progress updates to configure expected steps
        and their weights. This is typically called automatically by Orchestrator
        based on registered step definitions.

        Args:
            proportions: Mapping of step name to proportion weight.
                Example: {'initialize': 5, 'upload': 30, 'cleanup': 5}
            orders: Optional mapping of step name to 0-based order index.
                Example: {'initialize': 0, 'upload': 1, 'cleanup': 2}

        Raises:
            RuntimeError: If progress has already been recorded.
        """
        if self._step_order:
            raise RuntimeError(
                'Cannot set step proportions after progress has started. '
                'Call set_step_proportions() before any set_progress() calls.'
            )
        self._step_proportions = dict(proportions)
        self._progress_record = {
            'steps': {
                step: {
                    'proportion': prop,
                    **({'order': orders[step]} if orders and step in orders else {}),
                }
                for step, prop in proportions.items()
            },
        }

    def _get_current_progress(self) -> dict[str, Any]:
        """Calculate current progress format.

        Weight allocation strategy:
        - Predefined steps use their configured proportions from _step_proportions
        - Dynamic steps (not in _step_proportions) share weight from unused
          predefined proportion (e.g., if 'dataset' is not used, its weight is available)
        - Weights are locked once assigned to prevent recalculation
        - No normalization: if configured proportions sum to 100, final progress = 100%

        Progress is sequential: previous phases=100%, current=actual%, future=0%
        """
        steps = self._progress_record.get('steps', {})
        if not steps or not self._current_progress_step:
            return {'overall': 0}

        ordered = self._step_order.copy()
        if not ordered:
            return {'overall': 0}

        # Assign weights to any new steps (lock them)
        for step in ordered:
            if step in self._locked_weights:
                continue

            if step in self._step_proportions:
                # Predefined step - use its configured proportion
                self._locked_weights[step] = float(self._step_proportions[step])
            else:
                # Dynamic step - shares weight from unused predefined steps
                # Core phases (train, model_upload) are excluded from the pool
                core_phases = {'train', 'model_upload'}
                data_prep_pool = sum(
                    v
                    for k, v in self._step_proportions.items()
                    if k not in core_phases and k not in self._locked_weights
                )
                available_pool = data_prep_pool - self._data_prep_used

                if available_pool >= 5:
                    # Give this step half of remaining pool, minimum 5%
                    weight = max(5.0, available_pool / 2)
                else:
                    # Pool nearly exhausted, give remaining or minimal
                    weight = max(2.0, available_pool) if available_pool > 0 else 2.0

                self._locked_weights[step] = weight
                self._data_prep_used += weight

        # Find current step index
        try:
            current_idx = ordered.index(self._current_progress_step)
        except ValueError:
            current_idx = len(ordered) - 1

        # Calculate overall progress using locked weights
        overall = 0.0
        for i, step in enumerate(ordered):
            weight = self._locked_weights.get(step, 0)
            step_data = steps.get(step, {})

            if i < current_idx:
                # Previous steps: full weight
                overall += weight
            elif i == current_idx:
                # Current step: proportional
                percent = step_data.get('percent', 0)
                overall += weight * percent / 100

        # Ensure progress never decreases (monotonically increasing)
        self._max_overall = max(self._max_overall, overall)
        overall = self._max_overall

        step_record = steps.get(self._current_progress_step, {})

        result: dict[str, Any] = {
            'overall': round(min(overall, 100), 2),
            'step': self._current_progress_step,
            'percent': step_record.get('percent', 0),
            'time_remaining': step_record.get('time_remaining'),
        }
        if self._current_step_order is not None:
            result['order'] = self._current_step_order
        return result

    def _log_impl(
        self,
        event: str,
        data: dict[str, Any],
        file: str | None,
        step: str | None,
        level: LogLevel | None = None,
    ) -> None:
        # Always print to console for Ray log visibility
        level_str = level.value.upper() if level else 'INFO'
        if step:
            prefix = f'[STEP: {step}] [LEVEL: {level_str}]'
        else:
            prefix = f'[LEVEL: {level_str}]'
        print(f'{prefix} {event} {data}', flush=True)

        # Queue and send to backend
        import datetime as dt

        log_entry: dict[str, Any] = {
            'event': event,
            'data': data,
            'datetime': dt.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f'),
            'job': self._job_id,
        }
        if file:
            log_entry['file'] = file
        if step:
            log_entry['step'] = step
        if level:
            log_entry['level'] = level.value

        self._logs_queue.append(log_entry)

        try:
            self._client.create_logs(self._logs_queue)
            self._logs_queue.clear()
        except Exception as e:
            from synapse_sdk.plugins.models.logger import LogLevel

            _logger.debug(f'JobLogger: failed to send log to backend: {e}')
            print(f'[LEVEL: {LogLevel.WARNING.value.upper()}] JobLogger failed to send log to backend: {e}', flush=True)

    def _on_progress(self, progress: ProgressData, step: str | None) -> None:
        from synapse_sdk.plugins.models.logger import LogLevel

        # Print to console
        info_level = LogLevel.INFO.value.upper()
        if step:
            prefix = f'[STEP: {step}] [LEVEL: {info_level}]'
        else:
            prefix = f'[LEVEL: {info_level}]'
        print(f'{prefix} Progress: {progress.percent}% | ETA: {progress.time_remaining}s', flush=True)

        # Update step in progress_record
        if step:
            # Track step order (first time we see each step)
            if step not in self._step_order:
                self._step_order.append(step)

            self._current_progress_step = step
            steps = self._progress_record.setdefault('steps', {})
            step_update: dict[str, Any] = {
                'percent': progress.percent,
                'time_remaining': progress.time_remaining,
            }
            if self._current_step_order is not None:
                step_update['order'] = self._current_step_order
            steps.setdefault(step, {}).update(step_update)
        else:
            self._progress_record.update({
                'percent': progress.percent,
                'time_remaining': progress.time_remaining,
            })

        try:
            payload = {
                'record': self._progress_record,
                'current_progress': self._get_current_progress(),
            }
            self._client.update_job(self._job_id, {'progress_record': payload})
        except Exception as e:
            _logger.debug(f'JobLogger: failed to update progress: {e}')
            print(f'[LEVEL: {LogLevel.WARNING.value.upper()}] JobLogger failed to update progress: {e}', flush=True)

    def _on_metrics(self, step: str, metrics: dict[str, Any]) -> None:
        from synapse_sdk.plugins.models.logger import LogLevel

        # Print to console
        info_level = LogLevel.INFO.value.upper()
        print(f'[STEP: {step}] [LEVEL: {info_level}] Metrics: {metrics}', flush=True)

        if 'steps' not in self._metrics_record:
            self._metrics_record['steps'] = {}
        self._metrics_record['steps'].setdefault(step, {}).update(metrics)

        try:
            self._client.update_job(self._job_id, {'metrics_record': {'record': self._metrics_record}})
        except Exception as e:
            _logger.debug(f'JobLogger: failed to update metrics: {e}')
            print(f'[LEVEL: {LogLevel.WARNING.value.upper()}] JobLogger failed to update metrics: {e}', flush=True)

    # -------------------------------------------------------------------------
    # Legacy-compatible logging methods for metrics/visualization
    # These send logs with specific 'event' types that the backend API expects
    # -------------------------------------------------------------------------

    def log_event(self, event: str, data: dict[str, Any], file: str | None = None) -> None:
        """Log an event with specific event type (legacy-compatible).

        This method sends logs with a specific 'event' field that matches
        the backend API format expected by /logs/?event=<type>.

        Args:
            event: Event type (e.g., 'metric', 'visualization', 'message', 'trials').
            data: Event data dictionary.
            file: Optional file path to attach (will be converted to base64).
        """
        import datetime as dt

        from synapse_sdk.plugins.models.logger import LogLevel

        step = self._current_step
        info_level = LogLevel.INFO.value.upper()
        if step:
            prefix = f'[STEP: {step}] [LEVEL: {info_level}]'
        else:
            prefix = f'[LEVEL: {info_level}]'
        print(f'{prefix} {event} {data}', flush=True)

        log_entry: dict[str, Any] = {
            'event': event,
            'data': data,
            'datetime': dt.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f'),
            'job': self._job_id,
        }
        if file:
            log_entry['file'] = file
        if step:
            log_entry['step'] = step

        try:
            self._client.create_logs([log_entry])
        except Exception as e:
            _logger.debug(f'JobLogger: failed to send {event} log to backend: {e}')
            print(
                f'[LEVEL: {LogLevel.WARNING.value.upper()}] JobLogger failed to send {event} log to backend: {e}',
                flush=True,
            )

    def log_metric(
        self,
        category: str,
        key: str,
        value: float | int,
        **metrics: Any,
    ) -> None:
        """Log a training metric (legacy-compatible).

        Sends a log entry with event='metric' to the backend.
        When IS_TUNE=true, automatically adds trial_id from Ray context.

        Args:
            category: Metric category (e.g., 'train', 'val').
            key: Metric key (e.g., 'loss', 'accuracy').
            value: Metric value.
            **metrics: Additional metrics as keyword arguments.

        Example:
            >>> ctx.logger.log_metric('train', 'loss', 0.5, accuracy=0.95)
        """
        data: dict[str, Any] = {
            'category': category,
            'key': key,
            'value': value,
            'metrics': metrics,
        }

        # Automatically add trial_id when in tune mode
        # Priority: SYNAPSE_TRIAL_ID env var > ray.train.get_context()
        if os.environ.get('IS_TUNE') == 'true':
            trial_id = os.environ.get('SYNAPSE_TRIAL_ID')
            if not trial_id:
                try:
                    from ray import train

                    context = train.get_context()
                    trial_id = context.get_trial_id()
                except Exception:
                    pass
            if trial_id:
                data['trial_id'] = trial_id

        self.log_event('metric', data)

    def log_visualization(
        self,
        category: str,
        group: str,
        index: int,
        image: str,
        **meta: Any,
    ) -> None:
        """Log a visualization image (legacy-compatible).

        Sends a log entry with event='visualization' to the backend.
        The image file is automatically converted to base64.
        When IS_TUNE=true, automatically adds trial_id from Ray context.

        Args:
            category: Visualization category (e.g., 'train', 'val').
            group: Group name for organizing visualizations.
            index: Index within the group.
            image: Path to the image file.
            **meta: Additional metadata as keyword arguments.

        Example:
            >>> ctx.logger.log_visualization('train', 'predictions', 0, '/tmp/pred.png')
        """
        data: dict[str, Any] = {
            'category': category,
            'group': group,
            'index': index,
            **meta,
        }

        # Automatically add trial_id when in tune mode
        # Priority: SYNAPSE_TRIAL_ID env var > ray.train.get_context()
        if os.environ.get('IS_TUNE') == 'true':
            trial_id = os.environ.get('SYNAPSE_TRIAL_ID')
            if not trial_id:
                try:
                    from ray import train

                    context = train.get_context()
                    trial_id = context.get_trial_id()
                except Exception:
                    pass
            if trial_id:
                data['trial_id'] = trial_id

        self.log_event('visualization', data, file=image)

    def log_trials(
        self,
        data: dict[str, Any] | None = None,
        *,
        trials: dict[str, Any] | None = None,
        base: list[str] | None = None,
        hyperparameters: list[str] | None = None,
        metrics: list[str] | None = None,
        best_trial: str = '',
    ) -> None:
        """Log Ray Tune trial progress (legacy-compatible).

        Sends a log entry with event='trials' to the backend.

        TODO: This interface is only for specific(train) action and Should be moved.

        Args:
            data: Pre-built payload containing 'trials' key.
            trials: Mapping of trial_id to trial data.
            base: Column names for the base section.
            hyperparameters: Column names for hyperparameters.
            metrics: Column names for metrics.
            best_trial: Trial ID of the best trial.

        Example:
            >>> ctx.logger.log_trials(
            ...     trials={'trial_1': {'loss': 0.1}},
            ...     metrics=['loss'],
            ...     best_trial='trial_1'
            ... )
        """
        if data is None:
            data = {
                'base': base or [],
                'trials': trials or {},
                'hyperparameters': hyperparameters or [],
                'metrics': metrics or [],
                'best_trial': best_trial,
            }
        elif not isinstance(data, dict):
            raise ValueError('log_trials expects a dictionary payload')

        if 'trials' not in data:
            raise ValueError('log_trials payload must include "trials" key')

        self.log_event('trials', data)

    def log_message(
        self,
        message: str,
        level: 'LogLevel | None' = None,
        *,
        context: 'str | LogLevel | None' = None,
    ) -> None:
        """Log a message (legacy-compatible).

        Sends a log entry with event='message' to the backend.

        Args:
            message: The message content.
            level: Log level (LogLevel enum). Preferred parameter.
            context: DEPRECATED. Use 'level' instead.

        Example:
            >>> ctx.logger.log_message('Training started', LogLevel.INFO)
        """
        _resolve_level_with_deprecation(level, context)  # Only for deprecation warning
        data: MessageLogData = {'content': message}
        self.log_event('message', data)


class TqdmLogger(ConsoleLogger):
    """Logger that uses tqdm progress bars for visual progress tracking.

    Creates and manages separate tqdm progress bars for each step.
    Falls back to console output for log messages.
    """

    def __init__(self) -> None:
        super().__init__()
        self._progress_bars: dict[str, Any] = {}  # step -> tqdm bar
        self._bar_totals: dict[str, float] = {}  # Track total for each bar

    def _on_progress(self, progress: ProgressData, step: str | None) -> None:
        """Update or create tqdm progress bar for the step."""
        try:
            from tqdm import tqdm
        except ImportError:
            # Fallback to console output if tqdm not available
            super()._on_progress(progress, step)
            return

        key = step or '__default__'

        # Create new progress bar if needed
        if key not in self._progress_bars:
            desc = f'[{step}]' if step else 'Progress'
            self._progress_bars[key] = tqdm(
                total=100,
                desc=desc,
                unit='%',
                bar_format='{desc}: {percentage:3.0f}%|{bar}| [{elapsed}<{remaining}]',
                leave=True,
                position=len(self._progress_bars),  # Stack bars vertically
            )
            self._bar_totals[key] = 0

        bar = self._progress_bars[key]
        current_total = self._bar_totals[key]

        # Update progress bar (increment by the difference)
        increment = progress.percent - current_total
        if increment > 0:
            bar.update(increment)
            self._bar_totals[key] = progress.percent

        # Close bar if complete
        if progress.percent >= 100 or progress.status == 'failed':
            bar.close()
            del self._progress_bars[key]
            del self._bar_totals[key]

    def _on_finish(self) -> None:
        """Close all remaining progress bars."""
        for bar in self._progress_bars.values():
            bar.close()
        self._progress_bars.clear()
        self._bar_totals.clear()

    def __del__(self) -> None:
        """Ensure all progress bars are closed on cleanup."""
        for bar in self._progress_bars.values():
            try:
                bar.close()
            except Exception:
                pass


class NoOpLogger(BaseLogger):
    """Logger that does nothing. Useful for testing or disabled logging."""

    def _log_impl(
        self,
        event: str,
        data: dict[str, Any],
        file: str | None,
        step: str | None,
        level: LogLevel | None = None,
    ) -> None:
        pass

    # Legacy-compatible methods (no-op)
    def log_event(self, event: str, data: dict[str, Any], file: str | None = None) -> None:
        pass

    def log_metric(self, category: str, key: str, value: float | int, **metrics: Any) -> None:
        pass

    def log_visualization(self, category: str, group: str, index: int, image: str, **meta: Any) -> None:
        pass

    def log_trials(self, data: dict[str, Any] | None = None, **kwargs: Any) -> None:
        pass

    def log_message(
        self,
        message: str,
        level: 'LogLevel | None' = None,
        *,
        context: 'str | LogLevel | None' = None,
    ) -> None:
        """No-op log_message.

        Args:
            message: The message content.
            level: Log level (LogLevel enum). Preferred parameter.
            context: DEPRECATED. Use 'level' instead.
        """
        _resolve_level_with_deprecation(level, context)  # Only for deprecation warning


__all__ = [
    'BaseLogger',
    'BackendLogger',
    'ConsoleLogger',
    'JobLogger',
    'LogEntry',
    'LoggerBackend',
    'MessageLogData',
    'NoOpLogger',
    'ProgressData',
    'TqdmLogger',
]
