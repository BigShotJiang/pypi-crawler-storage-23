"""MCP Prompts for Synapse SDK.

Prompts provide workflow templates for common tasks.
"""
