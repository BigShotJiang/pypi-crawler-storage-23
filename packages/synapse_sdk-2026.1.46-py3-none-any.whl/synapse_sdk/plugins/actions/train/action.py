"""Train action base class with optional step support."""

from __future__ import annotations

import logging
import os
import tempfile
from pathlib import Path
from typing import TYPE_CHECKING, Any, TypeVar

from pydantic import BaseModel, Field, model_validator

from synapse_sdk.plugins.action import BaseAction
from synapse_sdk.plugins.actions.train.context import TrainContext
from synapse_sdk.plugins.enums import MetricsCategory, PluginCategory
from synapse_sdk.plugins.steps import BaseStep, Orchestrator, StepRegistry, StepResult

P = TypeVar('P', bound=BaseModel)

logger = logging.getLogger(__name__)

# Progress proportions for tune mode (dataset: 20%, trials: 75%, model_upload: 5%)
TUNE_STEP_PROPORTIONS = {
    'dataset': 20,
    'trials': 75,
    'model_upload': 5,
}


class _TuneTrialLoggerWrapper:
    """Logger wrapper that ignores progress updates in tune trials.

    In tune mode, individual trials should not report their training progress
    to the backend. Only the main process reports trial completion progress.
    This wrapper forwards all logger methods except set_progress.
    """

    def __init__(self, logger: Any) -> None:
        self._logger = logger

    def set_progress(self, current: int, total: int, step: str | None = None) -> None:
        """Ignore progress updates from tune trials."""
        # In tune mode, ignore progress from individual trials
        # The main process reports trial completion via _TuneTrialCallback
        pass

    def __getattr__(self, name: str) -> Any:
        """Forward all other method calls to the underlying logger."""
        return getattr(self._logger, name)


# Lazy base class for tune callback — avoids hard dependency on ray
try:
    from ray.tune import Callback as _TuneCallbackBase
except ImportError:
    _TuneCallbackBase = object  # type: ignore[misc,assignment]

if TYPE_CHECKING:
    from synapse_sdk.clients.backend import BackendClient
    from synapse_sdk.plugins.actions.train.log_messages import TrainLogMessageCode


class BaseTrainParams(BaseModel):
    """Base parameters for training actions.

    Provides common fields used across training workflows.
    Extend this class to add plugin-specific training parameters.

    Attributes:
        dataset: Ground truth dataset ID to download from Synapse.
        splits: Optional split definitions for train/valid/test.
        checkpoint: Optional model ID to use as starting checkpoint.
        is_tune: Whether this is a hyperparameter tuning run (backend field).
        hyperparameters: Optional list of hyperparameter dicts from backend.
            When provided, hyperparameters[0] is flattened to top-level fields.

    Example:
        >>> class MyTrainParams(BaseTrainParams):
        ...     epochs: int = 100
        ...     batch_size: int = 32
    """

    dataset: int = Field(description='Synapse ground truth dataset ID')
    splits: dict[str, Any] | None = Field(
        default=None,
        description='Split definitions: {"train": {...filters}, "valid": {...}}',
    )
    checkpoint: int | None = Field(default=None, description='Checkpoint model ID to resume from')
    is_tune: bool = Field(default=False, description='Hyperparameter tuning mode (requires tune_config)')
    hyperparameters: list[dict[str, Any]] | None = Field(
        default=None,
        description='Hyperparameters list from backend (hyperparameters[0] is flattened to top-level)',
    )

    model_config = {'extra': 'allow'}

    @model_validator(mode='before')
    @classmethod
    def flatten_hyperparameters(cls, data: Any) -> Any:
        """Flatten hyperparameters[0] fields to top level for backend compatibility.

        For normal training, the backend sends resolved values:
            {"dataset": 176, "hyperparameters": [{"epochs": 10, "batch_size": 8}]}
        This validator flattens hyperparameters[0] to top level:
            {"dataset": 176, "epochs": 10, "batch_size": 8, "hyperparameters": [...]}

        For tune mode (is_tune=True), hyperparameters contain search space definitions:
            [{"name": "epochs", "type": "randint", "min": 5, "max": 10}, ...]
        In this case, flattening is skipped — the search space is consumed by
        _run_tune() to build Ray Tune param_space instead.
        """
        if not isinstance(data, dict):
            return data

        # Skip flattening for tune mode — hyperparameters are search space definitions
        if data.get('is_tune'):
            return data

        hyperparams = data.get('hyperparameters')
        if hyperparams and isinstance(hyperparams, list) and len(hyperparams) > 0:
            first_hp = hyperparams[0]
            if isinstance(first_hp, dict):
                for key, value in first_hp.items():
                    # Only set if not already present at top level
                    if key not in data:
                        data[key] = value

        return data


class BaseTrainAction(BaseAction[P]):
    """Base class for training actions.

    Provides a simplified API for training workflows. Plugin developers
    only need to:
    1. Set `target_format` class attribute (e.g., 'yolo')
    2. Override `execute(data_path, checkpoint)` with training logic

    The SDK automatically handles:
    - Dataset export from Synapse (if `dataset` in params)
    - Dataset conversion to target format
    - Step orchestration and progress tracking

    Attributes:
        category: Plugin category (defaults to NEURAL_NET).
        target_format: Dataset format for conversion (e.g., 'yolo', 'coco').
            Set this to enable automatic dataset conversion.

    Example (minimal - recommended):
        >>> class TrainAction(BaseTrainAction[TrainParams]):
        ...     target_format = 'yolo'  # Auto-converts dataset to YOLO format
        ...     result_model = TrainResult
        ...
        ...     def execute(self, data_path: Path, checkpoint: dict) -> TrainResult:
        ...         model = YOLO(checkpoint['path'])
        ...         model.train(data=str(data_path), epochs=self.params.epochs)
        ...         return TrainResult(weights_path='./weights')

    Example (custom steps - advanced):
        >>> class TrainAction(BaseTrainAction[TrainParams]):
        ...     def setup_steps(self, registry: StepRegistry[TrainContext]) -> None:
        ...         # Full control over step pipeline
        ...         registry.register(MyCustomExportStep())
        ...         registry.register(MyCustomTrainStep())

    Dataset Format Configuration:
        Set `target_format` to automatically convert downloaded datasets:
        - 'yolo': YOLO format with dataset.yaml
        - 'coco': COCO JSON format
        - None: No conversion (use raw Datamaker format)

    Overriding Steps:
        Override `setup_steps()` for full control over the pipeline.
        When overridden, auto-wiring is disabled and you manage all steps.
    """

    category = PluginCategory.NEURAL_NET

    # Dataset format for automatic conversion (e.g., 'yolo', 'coco')
    # Set to None to disable automatic conversion
    target_format: str | None = None

    @classmethod
    def get_log_message_code_class(cls) -> type[TrainLogMessageCode]:
        from synapse_sdk.plugins.actions.train.log_messages import TrainLogMessageCode

        return TrainLogMessageCode

    def autolog(self, framework: str) -> None:
        """Enable automatic logging for an ML framework.

        Call this before creating model objects. The SDK will automatically
        attach callbacks to log progress, metrics, and artifacts.

        Supported frameworks:
            - 'ultralytics': YOLO object detection models

        Args:
            framework: Framework name (e.g., 'ultralytics').

        Raises:
            ValueError: If framework is not recognized.
            ImportError: If framework package is not installed.

        Example:
            >>> def execute(self, data_path, checkpoint):
            ...     self.autolog('ultralytics')
            ...     model = YOLO(checkpoint['path'])
            ...     model.train(epochs=100)
        """
        from synapse_sdk.integrations import autolog as _autolog

        _autolog(framework, self)

    def report_metrics(
        self,
        metrics: dict[str, Any],
        *,
        epoch: int | None = None,
        category: MetricsCategory | str = MetricsCategory.TRAIN,
    ) -> None:
        """Report training metrics to backend and Ray Tune.

        Use this method in your training loop to log metrics. It automatically:
        - Logs metrics to the Synapse backend
        - Reports metrics to Ray Tune when in tune mode (IS_TUNE=true)

        This is the recommended way to report metrics for plugins without autolog.

        Args:
            metrics: Dict of metric name to value (e.g., {'loss': 0.5, 'accuracy': 0.95}).
            epoch: Current epoch number (optional but recommended).
            category: Metric category (default: MetricsCategory.TRAIN).

        Example:
            >>> def execute(self, data_path, checkpoint):
            ...     for epoch in range(epochs):
            ...         loss, acc = train_epoch()
            ...         self.report_metrics({'loss': loss, 'accuracy': acc}, epoch=epoch)
        """
        # Log to backend
        step_key = 'epoch'
        step_value = epoch if epoch is not None else 0
        self.ctx.log_metric(category, step_key, step_value, **metrics)

        # Report to Ray Tune if in tune mode
        # Only report validation metrics to tune because:
        # 1. Tune's optimization metric (e.g., f1_score) is typically a validation metric
        # 2. Search algorithms like OptunaSearch expect the metric in every tune.report()
        # 3. Train metrics don't include validation metrics, causing KeyError

        # FIXME 'true' string to boolean or enum conversion should be handled centrally
        if os.environ.get('IS_TUNE') != 'true':
            return

        if category != MetricsCategory.VALIDATION:
            return

        try:
            from ray import tune

            # Include epoch in metrics for Ray Tune
            tune_metrics = dict(metrics)
            if epoch is not None:
                tune_metrics['epoch'] = epoch
            tune.report(tune_metrics)
        except ImportError:
            pass

    @property
    def client(self) -> BackendClient:
        """Backend client from context.

        Returns:
            BackendClient instance.

        Raises:
            RuntimeError: If no client in context.
        """
        if self.ctx.client is None:
            raise RuntimeError(
                'No client in context. Either provide a client via RuntimeContext '
                'or override the helper methods (get_dataset, create_model, get_model).'
            )
        return self.ctx.client

    def _has_custom_setup_steps(self) -> bool:
        """Check if setup_steps was overridden by subclass."""
        return type(self).setup_steps is not BaseTrainAction.setup_steps

    def setup_steps(self, registry: StepRegistry[TrainContext]) -> None:
        """Register workflow steps for step-based execution.

        Override this method for full control over the step pipeline.
        When overridden, automatic step wiring is disabled.

        By default (when not overridden), the SDK auto-wires steps based on:
        - `dataset` in params → adds ExportDatasetStep
        - `target_format` class attribute → adds ConvertDatasetStep
        - Always adds internal step that calls your `execute()` method

        Args:
            registry: StepRegistry to register steps with.

        Example:
            >>> def setup_steps(self, registry: StepRegistry[TrainContext]) -> None:
            ...     from synapse_sdk.plugins.steps import ExportDatasetStep
            ...     registry.register(ExportDatasetStep())
            ...     registry.register(MyCustomPreprocessStep())
            ...     registry.register(MyTrainStep())
        """
        pass  # Default: no custom steps, run() will auto-wire

    def create_context(self) -> TrainContext:
        """Create training context for step-based workflow.

        Override to customize context creation or add additional state.

        Returns:
            TrainContext instance with params and runtime context.
        """
        params_dict = self.params.model_dump() if hasattr(self.params, 'model_dump') else dict(self.params)
        return TrainContext(
            runtime_ctx=self.ctx,
            params=params_dict,
        )

    def run(self) -> Any:
        """Run the action with automatic step orchestration.

        This method is called by executors. It:
        1. Checks if is_tune mode → delegates to _run_tune()
        2. Checks if setup_steps() was overridden
        3. If overridden: uses custom steps
        4. If not overridden: auto-wires export/convert/train steps

        Step proportions are automatically configured by Orchestrator
        based on each step's progress_proportion property.

        Returns:
            Action result (dict or result_model instance).
        """
        # --- Tune mode ---
        # TODO(tune-extraction): When tune becomes a separate action type
        # (BaseTuneAction), this branch will be removed. The is_tune flag
        # routing will be handled by the executor or a dedicated TuneAction.
        if getattr(self.params, 'is_tune', False):
            return self._run_tune()

        from synapse_sdk.plugins.steps import ConvertDatasetStep, ExportDatasetStep

        registry: StepRegistry[TrainContext] = StepRegistry()

        if self._has_custom_setup_steps():
            # User has custom steps - use them
            self.setup_steps(registry)
        else:
            # Auto-wire steps based on params and target_format
            dataset = getattr(self.params, 'dataset', None)

            if dataset is not None:
                registry.register(ExportDatasetStep())
                if self.target_format:
                    registry.register(ConvertDatasetStep(target_format=self.target_format))

            # Add internal step that calls execute()
            registry.register(_TrainExecuteStep(self))

            # Add model upload step (works for all plugins)
            registry.register(_ModelUploadStep(self))

        if not registry:
            raise RuntimeError(
                'No steps registered. Either set target_format class attribute '
                'or override setup_steps() to register custom steps.'
            )

        # Step-based execution
        context = self.create_context()
        orchestrator: Orchestrator[TrainContext] = Orchestrator(
            registry=registry,
            context=context,
            progress_callback=lambda curr, total: self.set_progress(curr, total),
        )
        result = orchestrator.execute()

        # Add context data to result
        # Return model ID (not full object) to match v1 SDK behavior
        if context.model:
            result['model_id'] = context.model.get('id') if isinstance(context.model, dict) else context.model

        return result

    def execute(self, data_path: Path, checkpoint: dict[str, Any] | None) -> Any:
        """Execute training logic.

        Override this method with your training implementation.
        The SDK automatically resolves data_path and checkpoint for you.

        Args:
            data_path: Path to dataset config file (e.g., dataset.yaml for YOLO).
                Resolved from export/convert steps.
            checkpoint: Checkpoint dict with 'path' and 'category' keys, or None.
                Resolved from params.checkpoint or ctx.checkpoint.

        Returns:
            Training result. Can be a dict or result_model instance.

        Example:
            >>> def execute(self, data_path: Path, checkpoint: dict) -> TrainResult:
            ...     self.autolog('ultralytics')
            ...     model = YOLO(checkpoint['path'])
            ...     results = model.train(
            ...         data=str(data_path),
            ...         epochs=self.params.epochs,
            ...     )
            ...     return TrainResult(weights_path='./weights')
        """
        raise NotImplementedError(
            f'{type(self).__name__} must implement execute(data_path, checkpoint). '
            'See BaseTrainAction docstring for examples.'
        )

    def get_dataset(self) -> dict[str, Any]:
        """Fetch training dataset info from backend.

        Default implementation uses params.dataset. Override for custom behavior.

        Returns:
            Dataset metadata dictionary.

        Raises:
            ValueError: If params.dataset is not set.
            RuntimeError: If no client in context.
        """
        dataset = getattr(self.params, 'dataset', None)
        if dataset is None:
            raise ValueError(
                'params.dataset is required for default get_dataset(). '
                'Either set dataset in your params model or override get_dataset().'
            )
        # Return basic info - full data is fetched via ground_truth_events
        return {'id': dataset}

    def create_model(self, path: str, **kwargs: Any) -> dict[str, Any]:
        """Upload trained model to backend.

        Default implementation uploads via client.create_model().
        Override for custom behavior (e.g., MLflow, S3).

        Args:
            path: Local path to model artifacts.
            **kwargs: Additional fields for model creation (name, configuration, etc.).

        Returns:
            Created model metadata dictionary.

        Raises:
            RuntimeError: If no client in context.
        """
        # Pass file as keyword argument for chunked upload
        return self.client.create_model(kwargs, file=path)

    def get_model(self, model_id: int) -> dict[str, Any]:
        """Retrieve existing model by ID.

        Args:
            model_id: Model identifier.

        Returns:
            Model metadata dictionary.

        Raises:
            RuntimeError: If no client in context.
        """
        return self.client.get_model(model_id)

    def get_checkpoint(self) -> dict[str, Any] | None:
        """Get checkpoint for training.

        Resolves checkpoint in the following order:
        1. If ctx.checkpoint is set (remote mode), returns it directly
        2. If params.checkpoint is set (model ID), fetches and extracts

        Returns:
            Checkpoint dict with 'category', 'path', 'id', 'name', or None.

        Example:
            >>> checkpoint = self.get_checkpoint()
            >>> if checkpoint:
            ...     model_path = checkpoint['path']
        """
        from synapse_sdk.utils.file import extract_archive, get_temp_path

        # If checkpoint is already in context (remote mode), return it
        if self.ctx.checkpoint is not None:
            return self.ctx.checkpoint

        # Check if params has a checkpoint field (model ID)
        checkpoint_id = getattr(self.params, 'checkpoint', None)
        if checkpoint_id is None:
            return None

        # Fetch model from backend
        model = self.get_model(checkpoint_id)

        # The model['file'] is downloaded by the client's url_conversion
        model_file = Path(model['file'])

        # Extract to temp path
        output_path = get_temp_path(f'models/{model_file.stem}')
        if not output_path.exists():
            output_path.mkdir(parents=True, exist_ok=True)
            extract_archive(model_file, output_path)

        # Determine category - base models vs fine-tuned
        category = model.get('category') or 'base'

        return {
            'category': category,
            'path': output_path,
            'id': model.get('id'),
            'name': model.get('name'),
        }

    # ------------------------------------------------------------------ #
    # Tune support methods                                                #
    # TODO(tune-extraction): All methods below prefixed with _run_tune,  #
    # _prepare_tune_, _convert_tune_ are candidates for extraction into  #
    # a dedicated BaseTuneAction class. The _TuneTrialCallback class at  #
    # the bottom of this file should also move there.                    #
    # ------------------------------------------------------------------ #

    def _run_tune(self) -> Any:
        """Orchestrate hyperparameter tuning via Ray Tune.

        Runs dataset preparation once, then launches Ray Tune to explore
        the hyperparameter search space defined in params.hyperparameters.
        Each trial calls the plugin's execute() with resolved param values.

        Returns:
            Dict with 'best_result' containing the best trial config.
        """
        import ray
        from ray import tune

        if not ray.is_initialized():
            # Check if we're running inside a Ray Job (backend execution)
            # In this case, the Job already has a runtime_env configured by the backend.
            # We should connect to the existing cluster without specifying a new runtime_env
            # to avoid merge conflicts.
            is_inside_ray_job = bool(os.environ.get('RAY_JOB_CONFIG_JSON_ENV_VAR'))

            if is_inside_ray_job:
                # Connect to existing Ray cluster without custom runtime_env
                ray.init(address='auto')
                logger.info('Connected to existing Ray cluster (inside Ray Job).')
            else:
                # Local development: initialize with custom runtime_env
                runtime_env = self._build_tune_runtime_env()
                ray.init(runtime_env=runtime_env)
                logger.info('Initialized Ray with custom runtime_env (local mode).')

        logger.info('Starting hyperparameter tuning mode.')

        # Set up step proportions for tune mode (dataset: 20%, trials: 75%, model_upload: 5%)
        if hasattr(self.ctx.logger, 'set_step_proportions'):
            self.ctx.logger.set_step_proportions(TUNE_STEP_PROPORTIONS)

        # 1. Prepare dataset (run export/convert steps once)
        data_path = self._prepare_tune_dataset()

        # 2. Get checkpoint
        checkpoint = self.get_checkpoint()

        # 3. Parse tune_config from params (extra field from backend)
        params_dict = self.params.model_dump() if hasattr(self.params, 'model_dump') else dict(self.params)
        tune_config = params_dict.get('tune_config') or {}
        hyperparameters = self.params.hyperparameters or []

        # 4. Convert search space definitions to Ray Tune param_space
        param_space = self._convert_tune_params(hyperparameters)

        # 5. Setup search algorithm and scheduler
        search_alg = self._convert_tune_search_alg(tune_config)
        scheduler = self._convert_tune_scheduler(tune_config)

        # 6. Build TuneConfig kwargs
        # Disable strict metric checking to allow metric keys with special characters
        # e.g., 'metrics/mAP50-95(B)' from ultralytics
        os.environ['TUNE_DISABLE_STRICT_METRIC_CHECKING'] = '1'

        tune_config_kwargs: dict[str, Any] = {
            'num_samples': tune_config.get('num_samples', 1),
        }
        if tune_config.get('mode'):
            tune_config_kwargs['mode'] = tune_config['mode']
        if tune_config.get('metric'):
            # Use metric name as-is from backend (e.g., 'metrics/mAP50-95(B)')
            # Ray Tune supports special characters in metric keys
            tune_config_kwargs['metric'] = tune_config['metric']
        if tune_config.get('max_concurrent_trials'):
            tune_config_kwargs['max_concurrent_trials'] = tune_config['max_concurrent_trials']
        if search_alg is not None:
            tune_config_kwargs['search_alg'] = search_alg
        if scheduler is not None:
            tune_config_kwargs['scheduler'] = scheduler

        # 7. Create trainable function
        # Each trial receives resolved param values from Ray Tune,
        # creates a fresh action instance (to avoid tqdm serialization issues),
        # and calls execute().
        #
        # NOTE: We pass action_cls and base_params instead of the action instance
        # because the action contains a logger with tqdm objects that can't be
        # serialized by Ray (causes RecursionError).
        action_cls = type(self)
        base_params = params_dict.copy()

        # Get job_id to pass to trial workers
        job_id = self.ctx.job_id

        def _trial_entrypoint(
            config: dict[str, Any],
            action_cls: type,
            base_params: dict[str, Any],
            data_path: Any,
            checkpoint: Any,
            tune_job_id: str | None,
        ) -> dict[str, Any]:
            """Single tune trial entrypoint.

            Wraps tune.report() to cache metrics and returns them at the end.
            This is necessary because search algorithms like OptunaSearch access
            metrics directly from result[metric_key], not from the nested structure
            that tune.report() creates in Ray 2.x.

            The wrapper pattern is borrowed from the old SDK's _wrap_tune_entrypoint.

            TODO(tune-extraction): Move to BaseTuneAction._trial_entrypoint.
            """
            from synapse_sdk.plugins.context import PluginEnvironment, RuntimeContext

            os.environ['IS_TUNE'] = 'true'

            # Extract trial_id using multiple methods and store in environment variable
            # This ensures log_metric/log_visualization can reliably access trial_id
            trial_id = None
            try:
                # Method 1: ray.train.get_context() - works in Ray Train/Tune context
                from ray import train

                context = train.get_context()
                trial_id = context.get_trial_id()
            except Exception:
                pass

            if not trial_id:
                try:
                    # Method 2: ray.tune.get_trial_id() - alternative method
                    from ray import tune as ray_tune

                    trial_id = ray_tune.get_trial_id()
                except Exception:
                    pass

            if trial_id:
                os.environ['SYNAPSE_TRIAL_ID'] = trial_id

            # Merge base params with trial config (trial config overrides)
            trial_params = {**base_params, **config}

            # Create logger based on job_id availability
            # If job_id is available (backend mode), use JobLogger to send logs to backend
            # Otherwise, use ConsoleLogger for local development
            # NOTE: In tune mode, we wrap the logger to ignore progress updates from
            # individual trials (only the main process should report trial completion progress)
            if tune_job_id:
                try:
                    from synapse_sdk.loggers import JobLogger
                    from synapse_sdk.utils.auth import create_backend_client

                    client = create_backend_client()
                    if client:
                        base_logger = JobLogger(client=client, job_id=tune_job_id)
                        # Wrap to ignore progress updates in tune trials
                        trial_logger = _TuneTrialLoggerWrapper(base_logger)
                    else:
                        from synapse_sdk.loggers import ConsoleLogger

                        trial_logger = ConsoleLogger()
                except Exception:
                    from synapse_sdk.loggers import ConsoleLogger

                    trial_logger = ConsoleLogger()
            else:
                from synapse_sdk.loggers import ConsoleLogger

                trial_logger = ConsoleLogger()

            # Create fresh action instance with trial-specific params
            # This avoids serialization issues with tqdm in the logger
            ctx = RuntimeContext(
                logger=trial_logger,
                env=PluginEnvironment.from_environ(),
                job_id=tune_job_id,
            )
            action = action_cls(action_cls.params_model(**trial_params), ctx)

            # Set up tune.report wrapper to cache metrics (like old SDK's _wrap_tune_entrypoint)
            # This is necessary because OptunaSearch expects result[metric] directly,
            # but tune.report() in Ray 2.x stores metrics in a nested structure.
            # We cache original keys to match what search algorithms expect.
            last_metrics: dict[str, Any] = {}

            try:
                from ray import tune as ray_tune

                original_report = ray_tune.report

                def caching_report(metrics: dict[str, Any] = None, *args: Any, **kwargs: Any) -> Any:
                    nonlocal last_metrics

                    # Extract checkpoint kwarg if present
                    checkpoint = kwargs.pop('checkpoint', None)

                    # Build metrics dict from positional arg or kwargs
                    if metrics is not None:
                        if isinstance(metrics, dict):
                            # Called as tune.report(dict)
                            report_metrics = metrics
                        elif hasattr(metrics, 'items'):
                            # Called with dict-like object (e.g., Ultralytics DetMetrics)
                            report_metrics = dict(metrics)
                        else:
                            report_metrics = {}
                    elif kwargs:
                        # Called as tune.report(**dict) - reconstruct dict
                        report_metrics = dict(kwargs)
                        kwargs = {}  # Clear kwargs since we've consumed them
                    else:
                        report_metrics = {}

                    # Cache with original keys (no sanitization needed)
                    for k, v in report_metrics.items():
                        last_metrics[k] = v

                    # Call original with dict as positional arg
                    if checkpoint is not None:
                        return original_report(report_metrics, checkpoint=checkpoint)
                    else:
                        return original_report(report_metrics)

                ray_tune.report = caching_report
            except ImportError:
                original_report = None
                ray_tune = None

            execute_result = None
            try:
                # Run plugin's execute() method
                execute_result = action.execute(data_path, checkpoint)
            finally:
                # Restore original tune.report
                if ray_tune and original_report:
                    ray_tune.report = original_report

            # Add checkpoint_output from multiple sources (in priority order):
            # 1. execute() result's weights_path (for plugins without autolog)
            # 2. autolog context's model_path (for plugins with autolog like ultralytics)
            # This is used by on_trial_complete to upload each trial's model

            # Try execute() result first (ResNet, EfficientNet, etc.)
            if execute_result is not None:
                # Handle Pydantic model or dict
                if hasattr(execute_result, 'weights_path'):
                    weights_path = execute_result.weights_path
                elif isinstance(execute_result, dict):
                    weights_path = execute_result.get('weights_path')
                else:
                    weights_path = None

                if weights_path:
                    last_metrics['checkpoint_output'] = str(weights_path)

            # Fall back to autolog context (Ultralytics, etc.)
            if 'checkpoint_output' not in last_metrics:
                try:
                    from synapse_sdk.integrations._context import get_autolog_context

                    autolog_ctx = get_autolog_context()
                    if autolog_ctx and 'model_path' in autolog_ctx.extra:
                        last_metrics['checkpoint_output'] = autolog_ctx.extra['model_path']
                except ImportError:
                    pass

            # Return cached metrics so search algorithms can access result[metric] directly
            return last_metrics

        train_fn = tune.with_parameters(
            _trial_entrypoint,
            action_cls=action_cls,
            base_params=base_params,
            data_path=data_path,
            checkpoint=checkpoint,
            tune_job_id=job_id,
        )

        # 8. Apply resource constraints
        # TODO(tune-extraction): Make resource config customizable via
        # tune_config or class attribute (e.g., tune_resources).
        trainable = tune.with_resources(train_fn, {'cpu': 1, 'gpu': 0.5})

        storage_dir = tempfile.mkdtemp(prefix='synapse_tune_')
        num_samples = tune_config.get('num_samples', 1)

        # Initialize trials progress (step='trials' starts at 0%)
        try:
            self.ctx.set_progress(0, num_samples, step='trials')
        except Exception:
            pass

        # Trial progress callback
        trial_callback = _TuneTrialCallback(action=self, num_samples=num_samples)
        callbacks = [trial_callback]

        tuner = tune.Tuner(
            trainable,
            tune_config=tune.TuneConfig(**tune_config_kwargs),
            run_config=tune.RunConfig(
                name='synapse_tune_hpo',
                log_to_file=('stdout.log', 'stderr.log'),
                storage_path=storage_dir,
                callbacks=callbacks,
            ),
            param_space=param_space,
        )

        logger.info('Launching Ray Tune with %d samples.', num_samples)
        result_grid = tuner.fit()

        # 9. Extract best result and emit final log_trials with best_trial
        best_result = result_grid.get_best_result()
        best_config = best_result.config if best_result else {}
        best_trial_id = ''

        if best_result and trial_callback._trial_rows:
            # Find best_trial_id by matching the metric value from best_result
            # This is more reliable than parsing the path with regex
            best_metrics = getattr(best_result, 'metrics', {}) or {}
            metric_key = tune_config.get('metric')

            if metric_key and metric_key in best_metrics:
                target_value = best_metrics[metric_key]
                # Find the trial with matching metric value
                for trial_id, row in trial_callback._trial_rows.items():
                    if metric_key in row:
                        try:
                            if abs(float(row[metric_key]) - float(target_value)) < 1e-6:
                                best_trial_id = trial_id
                                break
                        except (TypeError, ValueError):
                            pass

            # Fallback: if no metric match, use the first completed trial
            if not best_trial_id:
                for trial_id, row in trial_callback._trial_rows.items():
                    if row.get('status') == 'TERMINATED':
                        best_trial_id = trial_id
                        break

        # Override best_trial via backend API and emit final log_trials snapshot
        if best_trial_id:
            self._override_best_trial(best_trial_id, best_config, trial_callback)

        # Note: Model upload is now handled by on_trial_complete() for each trial
        # No need to upload best model separately here (would be duplicate)
        self.ctx.set_progress(1, 1, step='model_upload')

        logger.info('Tune completed. Best config: %s', best_config)

        return {
            'best_result': best_config,
            'trial_models': trial_callback._trial_models,
        }

    def _prepare_tune_dataset(self) -> Path | None:
        """Run export/convert steps to prepare dataset for tuning.

        Executes only the dataset steps (no training step), returning
        the resolved data path for use across all tune trials.

        TODO(tune-extraction): Move to BaseTuneAction.

        Returns:
            Path to dataset config file, or None if no dataset in params.
        """
        from synapse_sdk.plugins.steps import ConvertDatasetStep, ExportDatasetStep

        registry: StepRegistry[TrainContext] = StepRegistry()
        dataset = getattr(self.params, 'dataset', None)

        if dataset is not None:
            registry.register(ExportDatasetStep())
            if self.target_format:
                registry.register(ConvertDatasetStep(target_format=self.target_format))

        if not registry:
            return None

        context = self.create_context()

        # During dataset preparation, suppress all internal progress updates
        # (e.g., 'init', 'fetch', 'download' from DatasetAction) to prevent
        # them from affecting the tune progress calculation.
        # We'll set the correct dataset progress (100%) after completion.
        original_logger = context.runtime_ctx.logger
        context.runtime_ctx.logger = _TuneTrialLoggerWrapper(original_logger)

        try:
            orchestrator: Orchestrator[TrainContext] = Orchestrator(
                registry=registry,
                context=context,
                progress_callback=lambda curr, total: None,  # Ignore step progress
            )
            orchestrator.execute()
        finally:
            # Restore original logger
            context.runtime_ctx.logger = original_logger

        # Set dataset step to 100% after completion (this contributes 20% to overall)
        self.ctx.set_progress(100, 100, step='dataset')

        # Resolve data path from context (same logic as _TrainExecuteStep)
        if context.dataset is None:
            return None
        config_path = context.dataset.get('config_path')
        if config_path is not None:
            return Path(config_path)
        path = context.dataset.get('path')
        if path is not None:
            path = Path(path)
            return path / 'dataset.yaml' if path.is_dir() else path
        return None

    def _build_tune_runtime_env(self) -> dict[str, Any]:
        """Build Ray runtime_env for tune trials.

        Mirrors the logic in BaseRayExecutor._build_runtime_env() to ensure
        tune trial workers have access to:
        - Plugin code (working_dir)
        - Python dependencies (requirements.txt)
        - SDK source (py_modules)
        - Environment variables (Synapse credentials)

        TODO(tune-extraction): Move to BaseTuneAction. Consider sharing
        the runtime_env building logic with BaseRayExecutor.

        Returns:
            Dict suitable for ray.init(runtime_env=...).
        """
        from synapse_sdk.plugins.executors.ray.base import read_requirements

        runtime_env: dict[str, Any] = {}

        # 1. Working directory — ship plugin code to workers
        working_dir = Path.cwd()
        runtime_env['working_dir'] = str(working_dir)

        # 2. Python dependencies from requirements.txt
        req_path = working_dir / 'requirements.txt'
        requirements = read_requirements(req_path)
        if requirements:
            packages = [r for r in requirements if not r.strip().startswith('-')]
            pip_args = [r for r in requirements if r.strip().startswith('-')]

            if packages:
                runtime_env['pip'] = {'packages': packages}

            if pip_args:
                import shlex

                split_args = []
                for arg in pip_args:
                    split_args.extend(shlex.split(arg))
                runtime_env.setdefault('pip', {})
                runtime_env['pip']['pip_install_options'] = split_args

        # 3. Include SDK source so workers can import synapse_sdk
        import synapse_sdk

        sdk_path = str(Path(synapse_sdk.__file__).parent)
        runtime_env['py_modules'] = [sdk_path]

        # 4. Environment variables — Synapse credentials for backend client
        env_vars: dict[str, str] = {}

        from synapse_sdk.utils.auth import ENV_SYNAPSE_ACCESS_TOKEN, ENV_SYNAPSE_HOST, load_credentials

        creds = load_credentials()
        if creds.host:
            env_vars[ENV_SYNAPSE_HOST] = creds.host
        if creds.token:
            env_vars[ENV_SYNAPSE_ACCESS_TOKEN] = creds.token

        # Include plugin environment variables
        if hasattr(self.ctx, 'env') and self.ctx.env:
            env_vars.update(self.ctx.env.to_dict())

        # Include job_id for trial logging
        if self.ctx.job_id:
            env_vars['SYNAPSE_TUNE_JOB_ID'] = self.ctx.job_id

        if env_vars:
            runtime_env['env_vars'] = env_vars

        logger.info(
            'Built tune runtime_env: working_dir=%s, pip=%s, py_modules=%s',
            working_dir,
            bool(requirements),
            bool(sdk_path),
        )

        return runtime_env

    def _get_tune_artifact_path(self, result: Any) -> str | None:
        """Get the checkpoint/artifact path from a Ray Tune result.

        Priority:
        1. checkpoint_output from metrics (plugin-reported)
        2. Ray checkpoint path (result.checkpoint.path or result.best_checkpoints)

        Args:
            result: Ray Tune Result object.

        Returns:
            Path string or None if no checkpoint found.
        """
        # Check metrics for checkpoint_output (set by plugin)
        metrics = getattr(result, 'metrics', None)
        if isinstance(metrics, dict):
            for key in ('checkpoint_output', 'checkpoint', 'result'):
                path = metrics.get(key)
                if path:
                    return str(path)

        # Check Ray's checkpoint path
        checkpoint = getattr(result, 'checkpoint', None)
        if checkpoint:
            # Ray 2.x: checkpoint.path or checkpoint.to_directory()
            if hasattr(checkpoint, 'path') and checkpoint.path:
                return str(checkpoint.path)
            try:
                return str(checkpoint.to_directory())
            except Exception:
                pass

        # Try best_checkpoints (list of checkpoints)
        best_checkpoints = getattr(result, 'best_checkpoints', None)
        if best_checkpoints and len(best_checkpoints) > 0:
            ckpt = best_checkpoints[0]
            if hasattr(ckpt, 'path'):
                return str(ckpt.path)

        return None

    def _create_tune_model(self, result: Any, artifact_path: str, trial_id: str = '') -> dict[str, Any] | None:
        """Create and upload model from tune result.

        Archives the checkpoint and uploads to backend.

        Args:
            result: Ray Tune Result object.
            artifact_path: Path to model checkpoint.
            trial_id: Trial identifier for naming.

        Returns:
            Created model metadata or None on failure.
        """
        import shutil

        from synapse_sdk.utils.file.archive import create_archive

        if not self.client:
            logger.warning('No client available for model upload.')
            return None

        # Build configuration
        params_dict = self.params.model_dump() if hasattr(self.params, 'model_dump') else dict(self.params)
        configuration = {
            'hyperparameters': params_dict.get('hyperparameters'),
            'tune_config': params_dict.get('tune_config'),
            'tune_trial': {
                'config': getattr(result, 'config', None),
                'metrics': getattr(result, 'metrics', None),
                'logdir': artifact_path,
            },
        }

        # Build model name
        base_name = params_dict.get('name') or f'tune_{self.ctx.job_id}'
        model_name = f'{base_name}_{trial_id}' if trial_id else base_name

        # Get plugin code from job's plugin_release
        # Backend expects plugin CODE (string), not plugin ID (int)
        plugin_code = None
        version = None
        job_id = self.ctx.job_id
        if job_id and self.client:
            try:
                job_info = self.client.get_job(job_id)
                plugin_release = job_info.get('plugin_release')

                if isinstance(plugin_release, int):
                    # plugin_release is the ID, fetch full details with plugin expanded
                    release_info = self.client.get_plugin_release(plugin_release, params={'expand': 'plugin'})
                    plugin = release_info.get('plugin')
                    if isinstance(plugin, dict):
                        plugin_code = plugin.get('code')
                    version = release_info.get('version')
                elif isinstance(plugin_release, dict):
                    # plugin_release is already a dict with details
                    plugin = plugin_release.get('plugin')
                    if isinstance(plugin, dict):
                        plugin_code = plugin.get('code')
                    version = plugin_release.get('version')
            except Exception as e:
                logger.warning('Failed to get plugin info from job: %s', e)

        # Archive and upload
        temp_dir = tempfile.mkdtemp()
        try:
            archive_path = Path(temp_dir) / 'model.zip'
            create_archive(Path(artifact_path), archive_path)

            # Build model data
            model_data: dict[str, Any] = {
                'name': model_name,
                'description': params_dict.get('description', ''),
                'configuration': configuration,
            }
            if plugin_code:
                model_data['plugin'] = plugin_code
            if version:
                model_data['version'] = version
            # Set checkpoint (parent model) for fine-tuned category
            # Check ctx.checkpoint first (has 'id' from get_checkpoint())
            # Fall back to params.checkpoint (raw model ID)
            checkpoint_id = None
            if self.ctx.checkpoint:
                checkpoint_id = self.ctx.checkpoint.get('id')
            if not checkpoint_id:
                checkpoint_id = params_dict.get('checkpoint')
            if checkpoint_id:
                model_data['checkpoint'] = checkpoint_id

            logger.info(
                'Creating model with data: plugin=%s, version=%s, name=%s, checkpoint=%s',
                plugin_code,
                version,
                model_name,
                checkpoint_id,
            )

            # Pass file as keyword argument for chunked upload
            model = self.client.create_model(model_data, file=archive_path)
            return model
        except Exception as e:
            logger.error('Failed to create model: %s', e)
            return None
        finally:
            shutil.rmtree(temp_dir, ignore_errors=True)

    def _upload_trial_model(
        self,
        trial_id: str,
        config: dict[str, Any],
        metrics: dict[str, Any],
        artifact_path: str,
    ) -> dict[str, Any] | None:
        """Upload model for a completed trial.

        Called by _TuneTrialCallback.on_trial_complete() to upload each trial's model
        to the backend as soon as the trial completes.

        Args:
            trial_id: Trial identifier.
            config: Trial hyperparameter configuration.
            metrics: Trial result metrics (including checkpoint_output).
            artifact_path: Path to model checkpoint.

        Returns:
            Created model metadata or None on failure.
        """
        import shutil

        from synapse_sdk.utils.file.archive import create_archive

        if not self.client:
            logger.warning('No client available for model upload.')
            return None

        if not artifact_path or not Path(artifact_path).exists():
            logger.warning('Trial %s: No valid artifact path for model upload.', trial_id)
            return None

        # Build configuration
        params_dict = self.params.model_dump() if hasattr(self.params, 'model_dump') else dict(self.params)
        configuration = {
            'hyperparameters': params_dict.get('hyperparameters'),
            'tune_config': params_dict.get('tune_config'),
            'tune_trial': {
                'trial_id': trial_id,
                'config': config,
                'metrics': metrics,
                'logdir': artifact_path,
            },
        }

        # Build model name with trial_id
        base_name = params_dict.get('name') or f'tune_{self.ctx.job_id}'
        model_name = f'{base_name}_{trial_id}'

        # Get plugin code from job's plugin_release
        plugin_code = None
        version = None
        job_id = self.ctx.job_id
        if job_id and self.client:
            try:
                job_info = self.client.get_job(job_id)
                plugin_release = job_info.get('plugin_release')

                if isinstance(plugin_release, int):
                    release_info = self.client.get_plugin_release(plugin_release, params={'expand': 'plugin'})
                    plugin = release_info.get('plugin')
                    if isinstance(plugin, dict):
                        plugin_code = plugin.get('code')
                    version = release_info.get('version')
                elif isinstance(plugin_release, dict):
                    plugin = plugin_release.get('plugin')
                    if isinstance(plugin, dict):
                        plugin_code = plugin.get('code')
                    version = plugin_release.get('version')
            except Exception as e:
                logger.warning('Failed to get plugin info from job: %s', e)

        # Archive and upload
        temp_dir = tempfile.mkdtemp()
        try:
            archive_path = Path(temp_dir) / 'model.zip'
            create_archive(Path(artifact_path), archive_path)

            # Build model data
            model_data: dict[str, Any] = {
                'name': model_name,
                'description': f'Trial {trial_id} model',
                'configuration': configuration,
            }
            if plugin_code:
                model_data['plugin'] = plugin_code
            if version:
                model_data['version'] = version

            # Set checkpoint (parent model) for fine-tuned category
            checkpoint_id = None
            if self.ctx.checkpoint:
                checkpoint_id = self.ctx.checkpoint.get('id')
            if not checkpoint_id:
                checkpoint_id = params_dict.get('checkpoint')
            if checkpoint_id:
                model_data['checkpoint'] = checkpoint_id

            logger.info(
                'Uploading trial %s model: plugin=%s, version=%s, name=%s',
                trial_id,
                plugin_code,
                version,
                model_name,
            )

            model = self.client.create_model(model_data, file=archive_path)
            logger.info('Trial %s model uploaded successfully: %s', trial_id, model.get('id') if model else None)
            return model
        except Exception as e:
            logger.error('Failed to upload trial %s model: %s', trial_id, e)
            return None
        finally:
            shutil.rmtree(temp_dir, ignore_errors=True)

    def _override_best_trial(
        self,
        trial_id: str,
        best_config: dict[str, Any],
        trial_callback: Any,
    ) -> None:
        """Override best trial via backend API and emit final log_trials snapshot.

        This mirrors the behavior of the old SDK's _override_best_trial method:
        1. PUT trains/{job_id}/override_best_trial/ with trial_id and config
        2. Emit final log_trials snapshot with best_trial set

        Args:
            trial_id: The best trial's ID.
            best_config: The best trial's config dictionary.
            trial_callback: The trial callback containing trial rows.
        """
        job_id = self.ctx.job_id
        if not job_id:
            logger.warning('Skipping override_best_trial: job_id not available.')
            if trial_callback._trial_rows:
                trial_callback._emit_final_snapshot(trial_id)
            return

        # Build payload
        payload = {'trial_id': trial_id, **best_config}
        url = f'trains/{job_id}/override_best_trial/'

        logger.info('Calling override_best_trial: %s payload=%s', url, payload)

        try:
            # Call backend API
            self.client._put(url, data=payload)
            logger.info('Successfully called override_best_trial API.')
        except Exception as e:
            logger.warning('Failed to override best trial via API: %s', e)

        # Emit final log_trials snapshot with best_trial
        if trial_callback._trial_rows:
            trial_callback._emit_final_snapshot(trial_id)

    @staticmethod
    def _convert_tune_params(param_list: list[dict[str, Any]]) -> dict[str, Any]:
        """Convert backend hyperparameter definitions to Ray Tune search space.

        Backend sends search space definitions like:
            [{"name": "epochs", "type": "randint", "min": 5, "max": 10},
             {"name": "batch_size", "type": "choice", "options": [2, 4, 8]}]

        This converts them to Ray Tune functions:
            {"epochs": tune.randint(5, 10), "batch_size": tune.choice([2, 4, 8])}

        TODO(tune-extraction): Move to BaseTuneAction._convert_tune_params.

        Args:
            param_list: List of hyperparameter search space definitions.

        Returns:
            Dict mapping param names to Ray Tune search space objects.
        """
        from ray import tune

        param_handlers = {
            'uniform': lambda p: tune.uniform(p['min'], p['max']),
            'quniform': lambda p: tune.quniform(p['min'], p['max']),
            'loguniform': lambda p: tune.loguniform(p['min'], p['max'], p['base']),
            'qloguniform': lambda p: tune.qloguniform(p['min'], p['max'], p['base']),
            'randn': lambda p: tune.randn(p['mean'], p['sd']),
            'qrandn': lambda p: tune.qrandn(p['mean'], p['sd']),
            'randint': lambda p: tune.randint(p['min'], p['max']),
            'qrandint': lambda p: tune.qrandint(p['min'], p['max']),
            'lograndint': lambda p: tune.lograndint(p['min'], p['max'], p['base']),
            'qlograndint': lambda p: tune.qlograndint(p['min'], p['max'], p['base']),
            'choice': lambda p: tune.choice(p['options']),
            'grid_search': lambda p: tune.grid_search(p['options']),
        }

        param_space: dict[str, Any] = {}

        for param in param_list:
            name = param['name']
            param_type = param['type']

            if param_type in param_handlers:
                param_space[name] = param_handlers[param_type](param)
            else:
                raise ValueError(
                    f"Unknown tune parameter type: '{param_type}' for '{name}'. "
                    f'Supported types: {", ".join(param_handlers.keys())}'
                )

        return param_space

    @staticmethod
    def _convert_tune_search_alg(tune_config: dict[str, Any]) -> Any:
        """Convert tune_config to a Ray Tune search algorithm instance.

        Supports both string and dict formats for search_alg:
            - String: "basicvariantgenerator"
            - Dict: {"name": "basicvariantgenerator", "options": {...}}

        TODO(tune-extraction): Move to BaseTuneAction._convert_tune_search_alg.

        Args:
            tune_config: Tune configuration from backend.

        Returns:
            Ray Tune search algorithm instance, or None.
        """
        search_alg_raw = tune_config.get('search_alg')
        if search_alg_raw is None:
            return None

        # Handle both string and dict formats
        if isinstance(search_alg_raw, str):
            search_alg_name = search_alg_raw.lower()
        elif isinstance(search_alg_raw, dict):
            search_alg_name = search_alg_raw.get('name', '').lower()
        else:
            return None

        # Use metric name as-is from backend (e.g., 'metrics/mAP50-95(B)')
        # Ray Tune supports special characters in metric keys
        metric = tune_config.get('metric')
        mode = tune_config.get('mode')

        if search_alg_name == 'bayesoptsearch':
            from ray.tune.search.bayesopt import BayesOptSearch

            return BayesOptSearch(metric=metric, mode=mode)
        elif search_alg_name == 'hyperoptsearch':
            from ray.tune.search.hyperopt import HyperOptSearch

            return HyperOptSearch(metric=metric, mode=mode)
        elif search_alg_name == 'optunasearch':
            from ray.tune.search.optuna import OptunaSearch

            return OptunaSearch(metric=metric, mode=mode)
        elif search_alg_name == 'basicvariantgenerator':
            from ray.tune.search.basic_variant import BasicVariantGenerator

            max_concurrent = tune_config.get('max_concurrent_trials')
            return BasicVariantGenerator(max_concurrent=max_concurrent)
        elif search_alg_name == 'axsearch':
            from ray.tune.search.ax import AxSearch

            return AxSearch(metric=metric, mode=mode)
        else:
            raise ValueError(
                f"Unsupported search algorithm: '{search_alg_name}'. "
                f'Supported: basicvariantgenerator, hyperoptsearch, optunasearch, '
                f'bayesoptsearch, axsearch'
            )

    @staticmethod
    def _convert_tune_scheduler(tune_config: dict[str, Any]) -> Any:
        """Convert tune_config to a Ray Tune scheduler instance.

        Supports both string and dict formats for scheduler:
            - String: "hyperband"
            - Dict: {"name": "hyperband", "options": {...}}

        TODO(tune-extraction): Move to BaseTuneAction._convert_tune_scheduler.

        Args:
            tune_config: Tune configuration from backend.

        Returns:
            Ray Tune scheduler instance, or None.
        """
        from ray.tune.schedulers import (
            ASHAScheduler,
            FIFOScheduler,
            HyperBandScheduler,
            MedianStoppingRule,
            PopulationBasedTraining,
        )

        scheduler_raw = tune_config.get('scheduler')
        if scheduler_raw is None:
            return None

        # Handle both string and dict formats
        if isinstance(scheduler_raw, str):
            scheduler_name = scheduler_raw.lower()
            options: dict[str, Any] = {}
        elif isinstance(scheduler_raw, dict):
            scheduler_name = scheduler_raw.get('name', 'fifo').lower()
            options = scheduler_raw.get('options') or {}
        else:
            return None

        scheduler_map = {
            'fifo': FIFOScheduler,
            'asha': ASHAScheduler,
            'hyperband': HyperBandScheduler,
            'pbt': PopulationBasedTraining,
            'median': MedianStoppingRule,
        }

        scheduler_class = scheduler_map.get(scheduler_name)
        if scheduler_class is None:
            raise ValueError(f"Unsupported scheduler: '{scheduler_name}'. Supported: {', '.join(scheduler_map.keys())}")

        return scheduler_class(**options) if options else scheduler_class()


class _TuneTrialCallback(_TuneCallbackBase):
    """Ray Tune callback for tracking trial progress and logging trial tables.

    Captures Ray Tune trial snapshots and forwards them to action.ctx.log_trials().
    Also reports trial completion progress via the action's set_progress().
    """

    BASE_COLUMNS = ('trial_id', 'status')
    METRIC_COLUMN_LIMIT = 4
    RESERVED_RESULT_KEYS = {
        'config',
        'date',
        'done',
        'experiment_id',
        'experiment_state',
        'experiment_tag',
        'hostname',
        'iterations_since_restore',
        'logdir',
        'node_ip',
        'pid',
        'restored_from_trial_id',
        'time_since_restore',
        'time_this_iter_s',
        'time_total',
        'time_total_s',
        'timestamp',
        'timesteps_since_restore',
        'timesteps_total',
        'training_iteration',
        'trial_id',
    }

    def __init__(self, action: BaseTrainAction[Any], num_samples: int = 1) -> None:
        self._action = action
        self._num_samples = num_samples
        self._completed = 0
        self._trial_rows: dict[str, dict[str, Any]] = {}
        self._config_keys: list[str] = []
        self._metric_keys: list[str] = []
        self._last_snapshot: tuple[Any, ...] | None = None
        self._trial_models: list[dict[str, Any]] = []  # Collected trial model info

    def on_trial_result(
        self, iteration: int, trials: list[Any], trial: Any, result: dict[str, Any], **info: Any
    ) -> None:
        """Called when a trial reports intermediate results."""
        self._record_trial(trial, result, status_override='RUNNING')
        self._emit_snapshot()

    def on_trial_complete(self, iteration: int, trials: list[Any], trial: Any, **info: Any) -> None:
        """Called when a trial completes successfully.

        Uploads the trial's model to the backend immediately after completion.
        """
        last_result = getattr(trial, 'last_result', None) or {}
        self._record_trial(trial, last_result, status_override='TERMINATED')
        self._emit_snapshot()
        self._completed += 1
        self._update_progress()

        # Upload trial model to backend
        trial_id = getattr(trial, 'trial_id', None)
        if trial_id and isinstance(last_result, dict):
            # Get artifact path from checkpoint_output (set by plugin)
            artifact_path = last_result.get('checkpoint_output')
            if artifact_path:
                try:
                    config = getattr(trial, 'config', {}) or {}
                    model = self._action._upload_trial_model(
                        trial_id=trial_id,
                        config=config,
                        metrics=last_result,
                        artifact_path=artifact_path,
                    )
                    # Collect trial model info for return value (v1 SDK compatibility)
                    # Use same field names as v1: trial_logdir, model_id, config, metrics
                    if model:
                        self._trial_models.append({
                            'trial_logdir': artifact_path,
                            'model_id': model.get('id'),
                            'config': config,
                            'metrics': last_result,
                        })
                except Exception as e:
                    logger.warning('Failed to upload trial %s model: %s', trial_id, e)

    def on_trial_error(self, iteration: int, trials: list[Any], trial: Any, **info: Any) -> None:
        """Called when a trial errors out."""
        self._record_trial(trial, getattr(trial, 'last_result', None), status_override='ERROR')
        self._emit_snapshot()
        self._completed += 1
        logger.warning('Tune trial %s ended with error.', getattr(trial, 'trial_id', '?'))
        self._update_progress()

    def on_step_end(self, iteration: int, trials: list[Any], **info: Any) -> None:
        """Called at the end of each tuning step to detect status changes."""
        updated = False
        for trial in trials or []:
            trial_id = getattr(trial, 'trial_id', None)
            if not trial_id:
                continue
            status = getattr(trial, 'status', None)
            existing = self._trial_rows.get(trial_id)
            existing_status = existing.get('status') if existing else None
            if existing is None or (status and status != existing_status):
                self._record_trial(
                    trial,
                    getattr(trial, 'last_result', None),
                    status_override=status,
                )
                updated = True
        if updated:
            self._emit_snapshot()

    def _record_trial(self, trial: Any, result: dict[str, Any] | None, status_override: str | None = None) -> None:
        """Record trial data (config, metrics, status) into trial_rows."""
        trial_id = getattr(trial, 'trial_id', None)
        if not trial_id:
            return

        row = self._trial_rows.setdefault(trial_id, {})
        result = result if isinstance(result, dict) else {}

        row['trial_id'] = trial_id
        row['status'] = status_override or getattr(trial, 'status', 'PENDING')

        config_data = self._extract_config(getattr(trial, 'config', None) or {})
        metric_data = self._extract_metrics(result)

        row.update(config_data)
        row.update(metric_data)

        self._track_columns(config_data.keys(), metric_data.keys())

    def _extract_config(self, config: dict[str, Any]) -> dict[str, Any]:
        """Extract and flatten config values."""
        flat: dict[str, Any] = {}
        if not isinstance(config, dict):
            return flat
        for key, value in self._flatten_items(config):
            flat[key] = self._serialize_config_value(value)
        return flat

    def _extract_metrics(self, result: dict[str, Any]) -> dict[str, Any]:
        """Extract metrics from trial result."""
        metrics: dict[str, Any] = {}
        if not isinstance(result, dict):
            return metrics

        # Handle nested 'metrics' dict
        nested = result.get('metrics')
        if isinstance(nested, dict):
            for key, value in self._flatten_items(nested, prefix='metrics'):
                serialized = self._serialize_metric_value(value)
                if serialized is not None:
                    metrics[key] = serialized

        # Handle top-level metric keys
        for key, value in result.items():
            if key in self.RESERVED_RESULT_KEYS or key == 'metrics':
                continue
            if isinstance(value, dict):
                continue
            serialized = self._serialize_metric_value(value)
            if serialized is not None:
                metrics[key] = serialized

        return metrics

    def _track_columns(self, config_keys: Any, metric_keys: Any) -> None:
        """Track discovered config and metric column names."""
        for key in config_keys:
            if key not in self._config_keys:
                self._config_keys.append(key)
        for key in metric_keys:
            if key not in self._metric_keys and len(self._metric_keys) < self.METRIC_COLUMN_LIMIT:
                self._metric_keys.append(key)

    def _emit_snapshot(self) -> None:
        """Emit trial table snapshot via log_trials() if changed."""
        if not self._trial_rows:
            return

        base_keys = list(self.BASE_COLUMNS)
        config_keys = list(self._config_keys)
        metric_keys = list(self._metric_keys)

        ordered_trials: dict[str, dict[str, Any]] = {}
        flat_rows: list[tuple[str, tuple[Any, ...]]] = []

        for trial_id in sorted(self._trial_rows.keys()):
            row = self._trial_rows[trial_id]
            base_values = [row.get(col) for col in base_keys]
            hyper_values = [row.get(col) for col in config_keys]
            metric_values = [row.get(col) for col in metric_keys]

            ordered_trials[trial_id] = {
                'base': base_values,
                'hyperparameters': hyper_values,
                'metrics': metric_values,
            }
            flat_rows.append((trial_id, tuple(base_values + hyper_values + metric_values)))

        # Check if snapshot changed to avoid duplicate logs
        snapshot = (tuple(base_keys + config_keys + metric_keys), tuple(flat_rows))
        if snapshot == self._last_snapshot:
            return
        self._last_snapshot = snapshot

        # Call log_trials via action's context
        try:
            self._action.ctx.log_trials(
                base=base_keys,
                trials=ordered_trials,
                hyperparameters=config_keys,
                metrics=metric_keys,
                best_trial='',
            )
        except Exception as e:
            logger.debug('Failed to log trials snapshot: %s', e)

    def _flatten_items(self, data: dict[str, Any], prefix: str | None = None) -> Any:
        """Flatten nested dict into (key, value) pairs."""
        if not isinstance(data, dict):
            return
        for key, value in data.items():
            key_str = str(key)
            current = f'{prefix}/{key_str}' if prefix else key_str
            if isinstance(value, dict):
                yield from self._flatten_items(value, current)
            else:
                yield current, value

    def _serialize_config_value(self, value: Any) -> Any:
        """Serialize config value for JSON compatibility."""
        from numbers import Number

        if isinstance(value, (str, bool)) or value is None:
            return value
        if isinstance(value, Number) and not isinstance(value, bool):
            return float(value)
        return str(value)

    def _serialize_metric_value(self, value: Any) -> float | None:
        """Serialize metric value (only numeric values)."""
        from numbers import Number

        if isinstance(value, Number) and not isinstance(value, bool):
            return float(value)
        return None

    def _update_progress(self) -> None:
        """Update trial completion progress using step='trials'."""
        completed = min(self._completed, self._num_samples)
        try:
            # Use step='trials' to integrate with TUNE_STEP_PROPORTIONS (20% dataset, 75% trials, 5% model_upload)
            self._action.ctx.set_progress(completed, self._num_samples, step='trials')
        except Exception:
            pass

    def _emit_final_snapshot(self, best_trial_id: str) -> None:
        """Emit final trial table snapshot with best_trial set.

        Called after all trials complete to set the best_trial field.
        """
        if not self._trial_rows:
            return

        base_keys = list(self.BASE_COLUMNS)
        config_keys = list(self._config_keys)
        metric_keys = list(self._metric_keys)

        ordered_trials: dict[str, dict[str, Any]] = {}

        for trial_id in sorted(self._trial_rows.keys()):
            row = self._trial_rows[trial_id]
            base_values = [row.get(col) for col in base_keys]
            hyper_values = [row.get(col) for col in config_keys]
            metric_values = [row.get(col) for col in metric_keys]

            ordered_trials[trial_id] = {
                'base': base_values,
                'hyperparameters': hyper_values,
                'metrics': metric_values,
            }

        # Emit final snapshot with best_trial
        try:
            self._action.ctx.log_trials(
                base=base_keys,
                trials=ordered_trials,
                hyperparameters=config_keys,
                metrics=metric_keys,
                best_trial=best_trial_id,
            )
            logger.info('Emitted final trials snapshot with best_trial=%s', best_trial_id)
        except Exception as e:
            logger.debug('Failed to log final trials snapshot: %s', e)


class _TrainExecuteStep(BaseStep[TrainContext]):
    """Internal step that wraps action's execute() method.

    This step is auto-registered when setup_steps() is not overridden.
    It resolves data_path and checkpoint, then calls action.execute().
    """

    def __init__(self, action: BaseTrainAction[Any]) -> None:
        self._action = action

    @property
    def name(self) -> str:
        return 'train'

    @property
    def progress_weight(self) -> float:
        return 0.5

    @property
    def progress_proportion(self) -> int:
        """Proportion for overall job progress (75% - training)."""
        return 75

    def execute(self, context: TrainContext) -> StepResult:
        # Resolve data path from context (set by export/convert steps)
        data_path = self._resolve_data_path(context)
        if data_path is None:
            return StepResult(
                success=False,
                error='No data path available. Ensure ExportDatasetStep and ConvertDatasetStep ran successfully.',
            )

        # Resolve checkpoint
        checkpoint = self._action.get_checkpoint()

        # Call action's execute method
        try:
            result = self._action.execute(data_path, checkpoint)
        except Exception as e:
            return StepResult(success=False, error=str(e))

        # Extract result data
        if hasattr(result, 'model_dump'):
            result_data = result.model_dump()
        elif isinstance(result, dict):
            result_data = result
        else:
            result_data = {'result': result}

        # Store model_path in context if available (from execute() result)
        weights_path = result_data.get('weights_path')
        if weights_path:
            context.model_path = weights_path

        # Also check autolog context for model_path (set by on_train_end callback)
        if not context.model_path:
            try:
                from synapse_sdk.integrations._context import get_autolog_context

                autolog_ctx = get_autolog_context()
                if autolog_ctx and autolog_ctx.extra.get('model_path'):
                    context.model_path = autolog_ctx.extra['model_path']
            except ImportError:
                pass

        return StepResult(success=True, data=result_data)

    def _resolve_data_path(self, context: TrainContext) -> Path | None:
        """Resolve data path from context (set by ConvertDatasetStep)."""
        if context.dataset is None:
            return None

        config_path = context.dataset.get('config_path')
        if config_path is not None:
            return Path(config_path)

        path = context.dataset.get('path')
        if path is not None:
            path = Path(path)
            if path.is_dir():
                return path / 'dataset.yaml'
            return path

        return None


class _ModelUploadStep(BaseStep[TrainContext]):
    """Step for uploading trained model to backend.

    This step handles model upload universally for all plugins.
    It reads model_path from context (set by _TrainExecuteStep from
    either execute() result or autolog callback) and uploads to backend.

    The step includes:
    - Plugin code and version from job's plugin_release
    - Checkpoint ID for fine-tuned model categorization
    """

    def __init__(self, action: BaseTrainAction[Any]) -> None:
        self._action = action

    @property
    def name(self) -> str:
        return 'model_upload'

    @property
    def progress_weight(self) -> float:
        return 0.1

    @property
    def progress_proportion(self) -> int:
        """Proportion for overall job progress (5% - model upload)."""
        return 5

    def execute(self, context: TrainContext) -> StepResult:
        import shutil
        import tempfile

        from synapse_sdk.plugins.actions.train.log_messages import TrainLogMessageCode
        from synapse_sdk.utils.file.archive import create_archive

        # Check if model_path is available
        model_path = context.model_path
        if not model_path:
            logger.info('No model_path in context. Skipping model upload.')
            return StepResult(success=True, data={'skipped': True})

        model_path = Path(model_path)
        if not model_path.exists():
            logger.warning('Model path does not exist: %s', model_path)
            return StepResult(success=True, data={'skipped': True, 'reason': 'path_not_found'})

        # Get client
        try:
            client = self._action.client
        except (RuntimeError, AttributeError):
            logger.warning('No client available for model upload.')
            return StepResult(success=True, data={'skipped': True, 'reason': 'no_client'})

        # Log upload start
        self._action.log_message(TrainLogMessageCode.TRAIN_MODEL_SAVED)

        temp_dir = tempfile.mkdtemp()
        try:
            archive_path = Path(temp_dir) / 'model.zip'
            create_archive(model_path, archive_path)

            # Build model name
            params_dict = self._action.params.model_dump() if hasattr(self._action.params, 'model_dump') else {}
            model_name = params_dict.get('name') or f'train_{self._action.ctx.job_id}'

            # Build configuration
            configuration = {
                'hyperparameter': params_dict.get('hyperparameter')
                or (params_dict.get('hyperparameters', [{}])[0] if params_dict.get('hyperparameters') else {}),
            }

            # Build model data
            model_data: dict[str, Any] = {
                'name': model_name,
                'description': params_dict.get('description', ''),
                'configuration': configuration,
            }

            # Get plugin code and version from job's plugin_release
            job_id = self._action.ctx.job_id
            if job_id:
                try:
                    job_info = client.get_job(job_id)
                    plugin_release = job_info.get('plugin_release')

                    if isinstance(plugin_release, int):
                        release_info = client.get_plugin_release(plugin_release, params={'expand': 'plugin'})
                        plugin = release_info.get('plugin')
                        if isinstance(plugin, dict):
                            model_data['plugin'] = plugin.get('code')
                        model_data['version'] = release_info.get('version')
                    elif isinstance(plugin_release, dict):
                        plugin = plugin_release.get('plugin')
                        if isinstance(plugin, dict):
                            model_data['plugin'] = plugin.get('code')
                        model_data['version'] = plugin_release.get('version')
                except Exception as e:
                    logger.debug('Failed to get plugin info from job: %s', e)

            # Set checkpoint (parent model) for fine-tuned category
            checkpoint_id = None
            if context.runtime_ctx.checkpoint:
                checkpoint_id = context.runtime_ctx.checkpoint.get('id')
            if not checkpoint_id:
                checkpoint_id = params_dict.get('checkpoint')
            if checkpoint_id:
                model_data['checkpoint'] = checkpoint_id

            # Register model
            model = client.create_model(model_data, file=archive_path)
            self._action.log_message(f'Model registered: {model.get("id")}')

            # Store model info in context
            context.model = model

            # Log upload complete
            self._action.log_message(TrainLogMessageCode.TRAIN_MODEL_UPLOADED)

            return StepResult(success=True, data={'model_id': model})

        except Exception as e:
            logger.error('Model upload failed: %s', e)
            self._action.log_message(f'Model registration failed: {e}')
            return StepResult(success=False, error=str(e))
        finally:
            shutil.rmtree(temp_dir, ignore_errors=True)
