"""Train log message codes for user-facing UI messages."""

from __future__ import annotations

from synapse_sdk.plugins.log_messages import LogMessageCode, register_log_messages
from synapse_sdk.plugins.models.logger import LogLevel


class TrainLogMessageCode(LogMessageCode):
    """Log message codes for training workflows."""

    TRAIN_STARTING = ('TRAIN_STARTING', LogLevel.INFO)
    TRAIN_EPOCH_PROGRESS = ('TRAIN_EPOCH_PROGRESS', LogLevel.INFO)
    TRAIN_VALIDATION_METRICS = ('TRAIN_VALIDATION_METRICS', LogLevel.INFO)
    TRAIN_COMPLETED = ('TRAIN_COMPLETED', LogLevel.SUCCESS)
    TRAIN_MODEL_SAVED = ('TRAIN_MODEL_SAVED', LogLevel.INFO)
    TRAIN_MODEL_UPLOADED = ('TRAIN_MODEL_UPLOADED', LogLevel.SUCCESS)


register_log_messages({
    TrainLogMessageCode.TRAIN_STARTING: {
        'en': 'Starting training for {epochs} epochs',
        'ko': '{epochs} 에포크 학습을 시작합니다',
    },
    TrainLogMessageCode.TRAIN_EPOCH_PROGRESS: {
        'en': 'Training epoch {epoch}/{total_epochs}',
        'ko': '학습 에포크 {epoch}/{total_epochs}',
    },
    TrainLogMessageCode.TRAIN_VALIDATION_METRICS: {
        'en': 'Validation mAP50: {map50:.3f}, mAP50-95: {map50_95:.3f}',
        'ko': '검증 mAP50: {map50:.3f}, mAP50-95: {map50_95:.3f}',
    },
    TrainLogMessageCode.TRAIN_COMPLETED: {
        'en': 'Training complete, uploading model...',
        'ko': '학습 완료, 모델 업로드 중...',
    },
    TrainLogMessageCode.TRAIN_MODEL_SAVED: {
        'en': 'Model weights saved',
        'ko': '모델 가중치가 저장되었습니다',
    },
    TrainLogMessageCode.TRAIN_MODEL_UPLOADED: {
        'en': 'Model upload complete',
        'ko': '모델 업로드가 완료되었습니다',
    },
})


__all__ = ['TrainLogMessageCode']
