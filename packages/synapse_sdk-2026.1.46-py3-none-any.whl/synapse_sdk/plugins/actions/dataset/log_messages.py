"""Dataset log message codes for user-facing UI messages."""

from __future__ import annotations

from synapse_sdk.plugins.log_messages import LogMessageCode, register_log_messages
from synapse_sdk.plugins.models.logger import LogLevel


class DatasetLogMessageCode(LogMessageCode):
    """Log message codes for dataset download and conversion workflows."""

    DATASET_DOWNLOAD_STARTING = ('DATASET_DOWNLOAD_STARTING', LogLevel.INFO)
    DATASET_SPLIT_DOWNLOADED = ('DATASET_SPLIT_DOWNLOADED', LogLevel.INFO)
    DATASET_DOWNLOAD_COMPLETED = ('DATASET_DOWNLOAD_COMPLETED', LogLevel.SUCCESS)
    DATASET_GT_EVENTS_FOUND = ('DATASET_GT_EVENTS_FOUND', LogLevel.INFO)
    DATASET_DOWNLOAD_PARTIAL = ('DATASET_DOWNLOAD_PARTIAL', LogLevel.WARNING)
    DATASET_CONVERTING = ('DATASET_CONVERTING', LogLevel.INFO)
    DATASET_CONVERSION_COMPLETED = ('DATASET_CONVERSION_COMPLETED', LogLevel.SUCCESS)


register_log_messages({
    DatasetLogMessageCode.DATASET_DOWNLOAD_STARTING: {
        'en': 'Starting dataset download (ID: {dataset_id})',
        'ko': '데이터셋 다운로드 시작 (ID: {dataset_id})',
    },
    DatasetLogMessageCode.DATASET_SPLIT_DOWNLOADED: {
        'en': 'Downloaded {split_name} split: {count} items',
        'ko': '{split_name} 분할 다운로드 완료: {count}개 항목',
    },
    DatasetLogMessageCode.DATASET_DOWNLOAD_COMPLETED: {
        'en': 'Dataset download complete: {count} items',
        'ko': '데이터셋 다운로드 완료: {count}개 항목',
    },
    DatasetLogMessageCode.DATASET_GT_EVENTS_FOUND: {
        'en': 'Found {count} ground truth events',
        'ko': '{count}개 정답 이벤트 발견',
    },
    DatasetLogMessageCode.DATASET_DOWNLOAD_PARTIAL: {
        'en': 'Downloaded {downloaded} items ({missing} missing images)',
        'ko': '{downloaded}개 항목 다운로드됨 ({missing}개 이미지 누락)',
    },
    DatasetLogMessageCode.DATASET_CONVERTING: {
        'en': 'Converting dataset: {source} → {target}',
        'ko': '데이터셋 변환 중: {source} → {target}',
    },
    DatasetLogMessageCode.DATASET_CONVERSION_COMPLETED: {
        'en': 'Dataset conversion complete',
        'ko': '데이터셋 변환 완료',
    },
})


__all__ = ['DatasetLogMessageCode']
