"""To task action for pre-annotation workflows."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from enum import StrEnum
from typing import TYPE_CHECKING, Any

from pydantic import BaseModel, Field

from synapse_sdk.clients.backend.models import JobStatus
from synapse_sdk.plugins.action import BaseAction
from synapse_sdk.plugins.actions.to_task.context import ToTaskContext
from synapse_sdk.plugins.actions.to_task.log_messages import ToTaskLogMessageCode
from synapse_sdk.plugins.enums import PluginCategory
from synapse_sdk.plugins.steps import Orchestrator, StepRegistry

if TYPE_CHECKING:
    from synapse_sdk.clients.backend import BackendClient


class ToTaskMethod(StrEnum):
    """Supported methods for to_task."""

    FILE = 'file'
    INFERENCE = 'inference'


class TaskProcessStatus(StrEnum):
    """Status values for individual task processing results.

    Used for logging task processing outcomes with type safety.
    """

    SUCCESS = 'success'
    FAILED = 'failed'


@dataclass
class TaskInfo:
    """Nested task information for event logging.

    Contains metadata about the task being processed.
    """

    task_id: int


@dataclass
class AnnotateTaskEvent:
    """Event log data structure for task annotation events.

    This dataclass provides type-safe structure for logging task processing events.
    Use to_dict() to convert to dictionary for logging.
    """

    task_info: TaskInfo
    status: str  # TaskProcessStatus value
    method: str  # ToTaskMethod value
    index: int
    total: int
    created: str  # ISO format timestamp
    error: str | None = None  # Only present for failed tasks

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for logging.

        Returns:
            Dictionary representation suitable for context.log()
        """
        return asdict(self)


class ToTaskParams(BaseModel):
    """Parameters for ToTaskAction."""

    name: str = Field(min_length=1)
    description: str | None = None
    project: int
    agent: int
    task_filters: dict[str, Any] = Field(default_factory=dict)
    method: ToTaskMethod = ToTaskMethod.FILE
    target_specification_name: str | None = None
    model: int | None = None
    pre_processor: int | None = None
    pre_processor_params: dict[str, Any] = Field(default_factory=dict)


class ToTaskResult(BaseModel):
    """Result payload for ToTaskAction."""

    status: JobStatus
    message: str
    total_tasks: int
    success_count: int
    failed_count: int
    failures: list[dict[str, Any]] = Field(default_factory=list)


class ToTaskAction(BaseAction[ToTaskParams]):
    """To task action for file-based and inference-based pre-annotation.

    This action uses a 5-step workflow:
    1. InitializeStep - Load data collection (10%)
    2. PrepareStep - Method-specific preparation (FILE: 5%, INFERENCE: 20%)
    3. FetchTasksStep - Retrieve task IDs (10%)
    4. AnnotateTaskDataStep - Annotate tasks (FILE: 70%, INFERENCE: 60%)
    5. FinalizeStep - Finalize results (5%)

    Progress weights differ based on ToTaskMethod:
    - FILE method: Quick preparation (5%), longer processing (70%)
    - INFERENCE method: Longer preparation with deployment (20%), shorter processing (60%)

    This action annotates tasks by either reading task data from file
    specifications or invoking a pre-processor for inference. Subclasses
    must implement the conversion hooks to map raw data into task payloads.
    """

    action_name = 'to_task'
    category = PluginCategory.PRE_ANNOTATION
    result_model = ToTaskResult
    context: ToTaskContext | None = None

    @classmethod
    def get_log_message_code_class(cls) -> type[ToTaskLogMessageCode]:
        from synapse_sdk.plugins.actions.to_task.log_messages import ToTaskLogMessageCode

        return ToTaskLogMessageCode

    @property
    def client(self) -> BackendClient:
        """Backend client from context.

        Returns:
            BackendClient: Backend client instance from runtime context.

        Raises:
            RuntimeError: If no backend client is attached to the context.
        """
        if self.ctx.client is None:
            raise RuntimeError('No backend client in context. Provide one via RuntimeContext.')
        return self.ctx.client

    def create_context(self) -> ToTaskContext:
        """Create execution context.

        Returns:
            ToTaskContext: Fresh context seeded with params and runtime ctx.
        """
        params_dict = self.params.model_dump()
        return ToTaskContext(runtime_ctx=self.ctx, params=params_dict)

    def setup_steps(self, registry: StepRegistry[ToTaskContext]) -> None:
        """Register workflow steps for to_task.

        Steps are registered based on ToTaskMethod:
        - InitializeStep: Load data collection (10%)
        - PrepareStep: Method-specific preparation (FILE: 5%, INFERENCE: 20%)
        - FetchTasksStep: Retrieve task IDs (10%)
        - AnnotateTaskDataStep: Annotate tasks (FILE: 70%, INFERENCE: 60%)
        - FinalizeStep: Finalize results (5%)

        Args:
            registry: Step registry to populate.
        """
        from synapse_sdk.plugins.actions.to_task.steps import (
            AnnotateTaskDataStep,
            FetchTasksStep,
            FinalizeStep,
            InitializeStep,
            PrepareStep,
        )

        registry.register(InitializeStep())
        registry.register(PrepareStep(method=self.params.method))
        registry.register(FetchTasksStep())
        registry.register(AnnotateTaskDataStep(action=self, method=self.params.method))
        registry.register(FinalizeStep())

    def run(self) -> ToTaskResult:
        """Run the action, using step orchestration when steps are registered.

        Returns:
            ToTaskResult: Summary of annotation outcome.
        """
        registry: StepRegistry[ToTaskContext] = StepRegistry()
        self.setup_steps(registry)

        if registry:
            context = self.create_context()
            self.context = context
            orchestrator: Orchestrator[ToTaskContext] = Orchestrator(
                registry=registry,
                context=context,
                progress_callback=lambda curr, total: self.set_progress(curr, total),
            )
            try:
                orchestrator.execute()
            except RuntimeError as e:
                # Convert orchestrator RuntimeError to ValueError for backward compatibility
                raise ValueError(str(e)) from e

            return ToTaskResult(
                status=JobStatus.SUCCEEDED,
                message=f'to_task completed. success={context.success_count}, failed={context.failed_count}',
                total_tasks=context.total_tasks,
                success_count=context.success_count,
                failed_count=context.failed_count,
                failures=context.failures,
            )

        # Fallback to execute if registry is somehow empty (backward compatibility)
        return self.execute()

    def execute(self) -> ToTaskResult:
        """Execute to_task workflow.

        This method provides backward compatibility. It simply delegates to run()
        which uses the step-based workflow.

        Returns:
            ToTaskResult: Summary of success/failure counts and failures.
        """
        return self.run()

    def convert_data_from_file(
        self,
        primary_file_url: str,
        primary_file_name: str | None,
        data_file_url: str,
        data_file_name: str | None,
        task_data: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Convert file-based data into task data payload.

        This method is called for each task during the annotation process.
        Implement this in your subclass to define how annotation data from
        files should be converted into task data.

        Important: If you need to access the action's context attribute,
        use self.context. Do not try to access attributes on function objects.

        Args:
            primary_file_url: URL of the primary file.
            primary_file_name: Original name of the primary file.
            data_file_url: URL of the annotation data file.
            data_file_name: Original name of the annotation data file.
            task_data: Optional task payload for additional context.

        Returns:
            dict[str, Any]: Task data payload ready for submission.

        Example:
            >>> def convert_data_from_file(self, primary_file_url, primary_file_name,
            ...                           data_file_url, data_file_name, task_data=None):
            ...     # Access action context if needed
            ...     params = self.context.params if self.context else {}
            ...     # Fetch and process the annotation file
            ...     annotations = load_annotations_from_url(data_file_url)
            ...     return {'annotations': annotations}
        """
        raise NotImplementedError('Override convert_data_from_file() in a subclass.')

    def convert_data_from_inference(
        self,
        inference_data: Any,
        task_data: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Convert inference output into task data payload.

        This method is called for each task during the annotation process
        when using inference method. Implement this in your subclass to
        define how inference results should be converted into task data.

        Important: If you need to access the action's context attribute,
        use self.context. Do not try to access attributes on function objects.

        Args:
            inference_data: Raw output returned by the pre-processor.
            task_data: Optional task payload for additional context.

        Returns:
            dict[str, Any]: Task data payload ready for submission.

        Example:
            >>> def convert_data_from_inference(self, inference_data, task_data=None):
            ...     # Access action context if needed
            ...     params = self.context.params if self.context else {}
            ...     # Process inference results
            ...     annotations = process_inference_output(inference_data)
            ...     return {'annotations': annotations}
        """
        raise NotImplementedError('Override convert_data_from_inference() in a subclass.')
