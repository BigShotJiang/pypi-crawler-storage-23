"""To-task workflow steps.

Provides the 5-step workflow for to_task action:
    1. InitializeStep: Load data collection (10%)
    2. PrepareStep: Method-specific preparation (FILE: 5%, INFERENCE: 20%)
    3. FetchTasksStep: Retrieve task IDs (10%)
    4. AnnotateTaskDataStep: Annotate tasks (FILE: 70%, INFERENCE: 60%)
    5. FinalizeStep: Cleanup and results (5%)
"""

from synapse_sdk.plugins.actions.to_task.steps.annotate_task_data import AnnotateTaskDataStep
from synapse_sdk.plugins.actions.to_task.steps.fetch_tasks import FetchTasksStep
from synapse_sdk.plugins.actions.to_task.steps.finalize import FinalizeStep
from synapse_sdk.plugins.actions.to_task.steps.initialize import InitializeStep
from synapse_sdk.plugins.actions.to_task.steps.prepare import PrepareStep

__all__ = [
    'AnnotateTaskDataStep',
    'FetchTasksStep',
    'FinalizeStep',
    'InitializeStep',
    'PrepareStep',
]
