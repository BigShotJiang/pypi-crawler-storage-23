"""Initialize step for to_task workflow."""

from __future__ import annotations

from typing import TYPE_CHECKING

from synapse_sdk.plugins.actions.to_task.context import ToTaskContext
from synapse_sdk.plugins.actions.to_task.log_messages import ToTaskLogMessageCode
from synapse_sdk.plugins.steps import BaseStep, StepResult

if TYPE_CHECKING:
    from synapse_sdk.clients.backend import BackendClient


class InitializeStep(BaseStep[ToTaskContext]):
    """Initialize to_task workflow by loading data collection.

    This step:
    1. Loads project from backend
    2. Loads data collection from project
    3. Stores data collection in context

    Progress weight: 0.10 (10%) for both methods
    """

    @property
    def name(self) -> str:
        """Step identifier."""
        return 'initialize'

    @property
    def progress_weight(self) -> float:
        """Relative progress weight."""
        return 0.10

    @property
    def progress_proportion(self) -> int:
        """Proportion for overall job progress (10%)."""
        return 10

    def execute(self, context: ToTaskContext) -> StepResult:
        """Execute initialization step.

        Args:
            context: To-task context with params and client.

        Returns:
            StepResult with data collection info.
        """
        try:
            # Set initial progress
            context.set_progress(0, 100)

            # Get client
            client: BackendClient | None = context.runtime_ctx.client
            if client is None:
                return StepResult(
                    success=False,
                    error='No backend client in context',
                )

            # Get project
            project_id = context.params.get('project')
            if project_id is None:
                return StepResult(
                    success=False,
                    error='Project parameter is required',
                )

            project = client.get_project(project_id)
            if not isinstance(project, dict):
                return StepResult(
                    success=False,
                    error='Invalid project response',
                )

            context.set_progress(50, 100)

            # Get data collection
            data_collection_id = project.get('data_collection')
            if not data_collection_id:
                return StepResult(
                    success=False,
                    error='Project does not have a data collection',
                )

            data_collection = client.get_data_collection(data_collection_id)
            if not isinstance(data_collection, dict):
                return StepResult(
                    success=False,
                    error='Invalid data collection response',
                )

            # Store in context
            context.data_collection = data_collection

            # Log success
            context.log_message(ToTaskLogMessageCode.TASK_DATA_COLLECTION_LOADED)

            # Set completion progress
            context.set_progress(100, 100)

            return StepResult(
                success=True,
                data={'data_collection_id': data_collection_id},
                rollback_data={'data_collection_id': data_collection_id},
            )

        except Exception as e:
            return StepResult(
                success=False,
                error=f'Failed to initialize: {e}',
            )

    def can_skip(self, context: ToTaskContext) -> bool:
        """Can skip if data collection already loaded.

        Args:
            context: To-task context.

        Returns:
            True if data collection already in context.
        """
        return context.data_collection is not None

    def rollback(self, context: ToTaskContext, result: StepResult) -> None:
        """Rollback by clearing data collection.

        Args:
            context: To-task context.
            result: Step result with rollback data.
        """
        context.data_collection = None
        context.runtime_ctx.logger.info('Rolled back: cleared data collection')
