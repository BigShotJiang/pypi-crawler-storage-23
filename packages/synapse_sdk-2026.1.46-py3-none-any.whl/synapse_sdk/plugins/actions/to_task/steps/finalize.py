"""Finalize step for to_task workflow."""

from __future__ import annotations

from synapse_sdk.plugins.actions.to_task.context import ToTaskContext
from synapse_sdk.plugins.actions.to_task.log_messages import ToTaskLogMessageCode
from synapse_sdk.plugins.steps import BaseStep, StepResult


class FinalizeStep(BaseStep[ToTaskContext]):
    """Finalize to_task workflow.

    This step:
    1. Logs final statistics
    2. Logs warnings if failures occurred
    3. Builds result message

    Progress weight: 0.05 (5%) for both methods
    """

    @property
    def name(self) -> str:
        """Step identifier."""
        return 'finalize'

    @property
    def progress_weight(self) -> float:
        """Relative progress weight."""
        return 0.05

    @property
    def progress_proportion(self) -> int:
        """Proportion for overall job progress (5%)."""
        return 5

    def execute(self, context: ToTaskContext) -> StepResult:
        """Execute finalization.

        Args:
            context: To-task context with processing results.

        Returns:
            StepResult with completion message.
        """
        try:
            # Set initial progress
            context.set_progress(0, 100)

            # Log completion based on results
            if context.failed_count > 0:
                context.log_message(
                    ToTaskLogMessageCode.TASK_DATA_COMPLETED_WITH_FAILURES,
                    success=context.success_count,
                    failed=context.failed_count,
                )
            else:
                context.log_message(
                    ToTaskLogMessageCode.TASK_DATA_COMPLETED,
                    count=context.success_count,
                )

            message = f'to_task completed. success={context.success_count}, failed={context.failed_count}'

            # Set completion progress
            context.set_progress(100, 100)

            return StepResult(
                success=True,
                data={'message': message},
            )

        except Exception as e:
            return StepResult(
                success=False,
                error=f'Failed to finalize: {e}',
            )

    def can_skip(self, context: ToTaskContext) -> bool:
        """Always finalize.

        Args:
            context: To-task context.

        Returns:
            False (never skip).
        """
        return False

    def rollback(self, context: ToTaskContext, result: StepResult) -> None:
        """No rollback needed for finalization.

        Args:
            context: To-task context.
            result: Step result with rollback data.
        """
        pass  # Finalize is read-only, no rollback needed
