"""Prepare step for to_task workflow."""

from __future__ import annotations

import time
from typing import TYPE_CHECKING, Any

from synapse_sdk.plugins.actions.to_task.action import ToTaskMethod
from synapse_sdk.plugins.actions.to_task.context import ToTaskContext
from synapse_sdk.plugins.actions.to_task.log_messages import ToTaskLogMessageCode
from synapse_sdk.plugins.steps import BaseStep, StepResult

if TYPE_CHECKING:
    from synapse_sdk.clients.backend import BackendClient


class PrepareStep(BaseStep[ToTaskContext]):
    """Prepare to_task workflow based on method.

    FILE method:
    - Validates target specification exists
    - Progress weight: 0.05 (5%)

    INFERENCE method:
    - Validates required parameters
    - Deploys pre-processor if needed
    - Waits for pre-processor to be ready
    - Progress weight: 0.20 (20%)
    """

    def __init__(self, method: ToTaskMethod) -> None:
        """Initialize prepare step.

        Args:
            method: ToTaskMethod (FILE or INFERENCE).
        """
        self._method = method

    @property
    def name(self) -> str:
        """Step identifier."""
        return 'prepare'

    @property
    def progress_weight(self) -> float:
        """Relative progress weight based on method."""
        return 0.05 if self._method == ToTaskMethod.FILE else 0.20

    @property
    def progress_proportion(self) -> int:
        """Proportion for overall job progress."""
        return 5 if self._method == ToTaskMethod.FILE else 20

    def execute(self, context: ToTaskContext) -> StepResult:
        """Execute preparation based on method.

        Args:
            context: To-task context with params and client.

        Returns:
            StepResult with preparation info.
        """
        if self._method == ToTaskMethod.FILE:
            return self._prepare_file_method(context)
        else:
            return self._prepare_inference_method(context)

    def _prepare_file_method(self, context: ToTaskContext) -> StepResult:
        """Validate target specification for FILE method.

        Args:
            context: To-task context.

        Returns:
            StepResult with validation info.
        """
        try:
            # Set initial progress
            context.set_progress(0, 100)

            target_spec = context.params.get('target_specification_name')
            if not target_spec:
                return StepResult(
                    success=False,
                    error='target_specification_name is required for file method',
                )

            # Validate specification exists in data collection
            if context.data_collection is None:
                return StepResult(
                    success=False,
                    error='Data collection not loaded',
                )

            file_specs = context.data_collection.get('file_specifications', [])
            if not any(spec.get('name') == target_spec for spec in file_specs if isinstance(spec, dict)):
                return StepResult(
                    success=False,
                    error=f"Target specification '{target_spec}' not found in file specifications",
                )

            context.log_message(ToTaskLogMessageCode.TASK_SPECIFICATION_VALIDATED)

            # Set completion progress
            context.set_progress(100, 100)

            return StepResult(
                success=True,
                data={'target_spec': target_spec},
            )

        except Exception as e:
            return StepResult(
                success=False,
                error=f'Failed to validate target specification: {e}',
            )

    def _prepare_inference_method(self, context: ToTaskContext) -> StepResult:
        """Prepare inference context for INFERENCE method.

        Args:
            context: To-task context.

        Returns:
            StepResult with inference context info.
        """
        try:
            # Set initial progress
            context.set_progress(0, 100)

            # Validate required parameters
            context.log_message(ToTaskLogMessageCode.TASK_INFERENCE_PARAMS_VALIDATING)

            pre_processor = context.params.get('pre_processor')
            model = context.params.get('model')
            agent = context.params.get('agent')

            if not pre_processor:
                return StepResult(
                    success=False,
                    error='pre_processor is required for inference method',
                )
            if not model:
                return StepResult(
                    success=False,
                    error='model is required for inference method',
                )
            if not agent:
                return StepResult(
                    success=False,
                    error='agent is required for inference method',
                )

            context.log_message(
                ToTaskLogMessageCode.TASK_INFERENCE_PARAMS_VALIDATED,
                pre_processor=pre_processor,
                model=model,
            )
            context.set_progress(20, 100)

            # Get client
            client: BackendClient | None = context.runtime_ctx.client
            if client is None:
                return StepResult(
                    success=False,
                    error='No backend client in context',
                )

            # Get pre-processor release
            context.log_message(
                ToTaskLogMessageCode.TASK_PREPROCESSOR_RELEASE_FETCHING,
                pre_processor=pre_processor,
            )
            release = client.get_plugin_release(pre_processor)
            if not isinstance(release, dict):
                return StepResult(
                    success=False,
                    error='Invalid pre-processor response',
                )

            config = release.get('config', {})
            code = config.get('code')
            version = release.get('version')
            if not code or not version:
                return StepResult(
                    success=False,
                    error='Invalid pre-processor configuration',
                )

            context.log_message(
                ToTaskLogMessageCode.TASK_PREPROCESSOR_RELEASE_FETCHED,
                plugin_code=code,
                version=version,
            )
            context.set_progress(40, 100)

            # Ensure pre-processor is running
            context.log_message(ToTaskLogMessageCode.TASK_PREPROCESSOR_CHECKING)
            required_resources = config.get('actions', {}).get('inference', {}).get('required_resources', {})
            self._ensure_pre_processor_running(context, client, code, agent, required_resources)

            context.set_progress(90, 100)

            # Store inference context
            context.inference = {
                'code': code,
                'version': version,
            }

            context.log_message(ToTaskLogMessageCode.TASK_INFERENCE_CONTEXT_READY)
            # Set completion progress
            context.set_progress(100, 100)

            return StepResult(
                success=True,
                data={'code': code, 'version': version},
                rollback_data={'code': code},
            )

        except Exception as e:
            return StepResult(
                success=False,
                error=f'Failed to prepare inference: {e}',
            )

    def _ensure_pre_processor_running(
        self,
        context: ToTaskContext,
        client: BackendClient,
        code: str,
        agent: int,
        required_resources: dict[str, Any],
    ) -> None:
        """Ensure pre-processor serve app is running.

        Args:
            context: To-task context.
            client: Backend client.
            code: Pre-processor plugin code.
            agent: Agent ID.
            required_resources: Resource requirements.

        Raises:
            RuntimeError: If pre-processor fails to become ready.
        """
        if self._has_running_serve_app(client, code, agent):
            context.log_message(ToTaskLogMessageCode.TASK_PREPROCESSOR_ALREADY_RUNNING)
            return

        # Deploy pre-processor
        num_cpus = required_resources.get('required_cpu_count', required_resources.get('num_cpus', 1))
        num_gpus = required_resources.get('required_gpu_count', required_resources.get('num_gpus', 0.1))

        context.log_message(ToTaskLogMessageCode.TASK_DATA_PREPROCESSOR_DEPLOYING)
        client.run_plugin(
            code,
            {
                'agent': agent,
                'action': 'deployment',
                'params': {
                    'num_cpus': num_cpus,
                    'num_gpus': num_gpus,
                },
            },
        )

        # Wait for deployment
        context.log_message(ToTaskLogMessageCode.TASK_PREPROCESSOR_WAITING)
        self._wait_for_pre_processor(context, client, code, agent)

    def _wait_for_pre_processor(
        self,
        context: ToTaskContext,
        client: BackendClient,
        code: str,
        agent: int,
        timeout_seconds: int = 180,
        poll_seconds: int = 10,
    ) -> None:
        """Wait until pre-processor serve app is running.

        Args:
            context: To-task context.
            client: Backend client.
            code: Pre-processor plugin code.
            agent: Agent ID.
            timeout_seconds: Maximum wait time in seconds.
            poll_seconds: Polling interval in seconds.

        Raises:
            RuntimeError: If serve app doesn't reach RUNNING status within timeout.
        """
        start_time = time.monotonic()
        deadline = start_time + timeout_seconds
        while time.monotonic() < deadline:
            if self._has_running_serve_app(client, code, agent):
                context.log_message(ToTaskLogMessageCode.TASK_PREPROCESSOR_READY)
                return

            # Update progress during waiting (40% to 90% range)
            elapsed = time.monotonic() - start_time
            wait_progress = min(int(40 + (elapsed / timeout_seconds) * 50), 90)
            context.set_progress(wait_progress, 100)

            context.log_message(
                ToTaskLogMessageCode.TASK_PREPROCESSOR_WAITING_PROGRESS,
                elapsed_seconds=int(elapsed),
            )

            time.sleep(poll_seconds)

        raise RuntimeError('Pre-processor did not become ready within timeout')

    def _has_running_serve_app(self, client: BackendClient, code: str, agent: int) -> bool:
        """Check if serve application is running.

        Args:
            client: Backend client.
            code: Pre-processor plugin code.
            agent: Agent ID.

        Returns:
            True if a RUNNING serve app exists.
        """
        response = client.list_serve_applications(
            params={'plugin_code': code, 'job__agent': agent},
        )
        results = response.get('results', []) if isinstance(response, dict) else response
        if isinstance(results, list):
            return any(isinstance(app, dict) and app.get('status') == 'RUNNING' for app in results)
        return False

    def can_skip(self, context: ToTaskContext) -> bool:
        """Can skip if already prepared.

        Args:
            context: To-task context.

        Returns:
            True if preparation can be skipped.
        """
        if self._method == ToTaskMethod.FILE:
            return False  # Always validate
        else:
            return context.inference is not None

    def rollback(self, context: ToTaskContext, result: StepResult) -> None:
        """Rollback preparation.

        Args:
            context: To-task context.
            result: Step result with rollback data.
        """
        if self._method == ToTaskMethod.INFERENCE:
            context.inference = None
            context.runtime_ctx.logger.info('Rolled back: cleared inference context')
            # Note: We don't stop the serve app to allow retries
