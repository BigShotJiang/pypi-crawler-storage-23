"""Export log message codes for user-facing UI messages."""

from __future__ import annotations

from synapse_sdk.plugins.log_messages import LogMessageCode, register_log_messages
from synapse_sdk.plugins.models.logger import LogLevel


class ExportLogMessageCode(LogMessageCode):
    """Log message codes for export workflows."""

    EXPORT_INITIALIZED = ('EXPORT_INITIALIZED', LogLevel.INFO)
    EXPORT_NO_RESULTS = ('EXPORT_NO_RESULTS', LogLevel.WARNING)
    EXPORT_RESULTS_FETCHED = ('EXPORT_RESULTS_FETCHED', LogLevel.INFO)
    EXPORT_CONVERTING = ('EXPORT_CONVERTING', LogLevel.INFO)
    EXPORT_CONVERTED = ('EXPORT_CONVERTED', LogLevel.INFO)
    EXPORT_SAVING_FILES = ('EXPORT_SAVING_FILES', LogLevel.INFO)
    EXPORT_FILES_SAVED = ('EXPORT_FILES_SAVED', LogLevel.INFO)
    EXPORT_FILES_SAVED_WITH_FAILURES = ('EXPORT_FILES_SAVED_WITH_FAILURES', LogLevel.WARNING)
    EXPORT_COMPLETED = ('EXPORT_COMPLETED', LogLevel.SUCCESS)
    EXPORT_COMPLETED_WITH_FAILURES = ('EXPORT_COMPLETED_WITH_FAILURES', LogLevel.WARNING)
    EXPORT_SAVING_ORIGINAL = ('EXPORT_SAVING_ORIGINAL', LogLevel.INFO)
    EXPORT_SAVING_JSON = ('EXPORT_SAVING_JSON', LogLevel.INFO)
    EXPORT_STARTING = ('EXPORT_STARTING', LogLevel.INFO)
    EXPORT_CONVERTING_DATASET = ('EXPORT_CONVERTING_DATASET', LogLevel.INFO)


register_log_messages({
    ExportLogMessageCode.EXPORT_INITIALIZED: {
        'en': 'Export storage and paths initialized',
        'ko': '내보내기 스토리지 및 경로가 초기화되었습니다',
    },
    ExportLogMessageCode.EXPORT_NO_RESULTS: {
        'en': 'No results found for export',
        'ko': '내보낼 결과를 찾지 못했습니다',
    },
    ExportLogMessageCode.EXPORT_RESULTS_FETCHED: {
        'en': 'Retrieved {count} results for export',
        'ko': '내보내기 대상 {count}개 결과를 가져왔습니다',
    },
    ExportLogMessageCode.EXPORT_CONVERTING: {
        'en': 'Converting {count} items',
        'ko': '{count}개 항목 변환 중',
    },
    ExportLogMessageCode.EXPORT_CONVERTED: {
        'en': 'Converted {count} items',
        'ko': '{count}개 항목 변환 완료',
    },
    ExportLogMessageCode.EXPORT_SAVING_FILES: {
        'en': 'Saving {count} files',
        'ko': '{count}개 파일 저장 중',
    },
    ExportLogMessageCode.EXPORT_FILES_SAVED: {
        'en': 'Saved {count} files',
        'ko': '{count}개 파일 저장 완료',
    },
    ExportLogMessageCode.EXPORT_FILES_SAVED_WITH_FAILURES: {
        'en': 'Saved {success} files, {failed} failed',
        'ko': '{success}개 파일 저장 완료, {failed}개 실패',
    },
    ExportLogMessageCode.EXPORT_COMPLETED: {
        'en': 'Export complete: {count} items exported',
        'ko': '내보내기 완료: {count}개 항목',
    },
    ExportLogMessageCode.EXPORT_COMPLETED_WITH_FAILURES: {
        'en': 'Export complete: {exported} exported, {failed} failed',
        'ko': '내보내기 완료: {exported}개 완료, {failed}개 실패',
    },
    ExportLogMessageCode.EXPORT_SAVING_ORIGINAL: {
        'en': 'Saving original file.',
        'ko': '원본 파일 저장 중.',
    },
    ExportLogMessageCode.EXPORT_SAVING_JSON: {
        'en': 'Saving json file.',
        'ko': 'JSON 파일 저장 중.',
    },
    ExportLogMessageCode.EXPORT_STARTING: {
        'en': 'Starting export process.',
        'ko': '내보내기 프로세스 시작.',
    },
    ExportLogMessageCode.EXPORT_CONVERTING_DATASET: {
        'en': 'Converting dataset.',
        'ko': '데이터셋 변환 중.',
    },
})


__all__ = ['ExportLogMessageCode']
