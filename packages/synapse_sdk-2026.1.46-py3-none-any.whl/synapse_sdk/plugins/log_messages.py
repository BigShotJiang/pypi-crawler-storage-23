"""Base log message codes for user-facing UI messages.

Provides:
    - LogMessageCode: Base StrEnum with embedded log level for all log message codes
    - CommonLogMessageCode: General/shared message codes
    - register_log_messages: Register plugin-specific templates (with i18n support)
    - resolve_log_message: Resolve code + kwargs into (message, level)

Each plugin defines its own LogMessageCode subclass (e.g., UploadLogMessageCode)
in its own log_messages.py module. Each member carries its log level
via ``LogLevel`` enum. Templates are registered at import time
via register_log_messages().

i18n Support:
    Templates can be registered as:
    - str: Single language template (treated as 'en')
    - dict[str, str]: Multi-language templates {lang: template}

    Example:
        register_log_messages({
            MyCode.MSG_1: 'English only',
            MyCode.MSG_2: {'en': 'English', 'ko': '한국어'},
        })
"""

from __future__ import annotations

from enum import StrEnum
from typing import Any

from synapse_sdk.plugins.models.logger import LogLevel


class LogMessageCode(StrEnum):
    """Base class for all log message codes.

    Each member is defined as ``NAME = ('VALUE', LogLevel.XXX)`` where the
    second element is a :class:`LogLevel` enum value.
    The level is accessible via the ``level`` property.

    Python StrEnum allows subclassing only when the parent has no members.

    Example:
        >>> class UploadLogMessageCode(LogMessageCode):
        ...     UPLOAD_INITIALIZED = ('UPLOAD_INITIALIZED', LogLevel.INFO)
        ...     UPLOAD_COMPLETED = ('UPLOAD_COMPLETED', LogLevel.SUCCESS)
        >>> UploadLogMessageCode.UPLOAD_INITIALIZED.level
        'info'
    """

    def __new__(cls, value: str, level: str | LogLevel = LogLevel.INFO) -> LogMessageCode:
        obj = str.__new__(cls, value)
        obj._value_ = value
        obj._level = level if isinstance(level, LogLevel) else LogLevel(level)
        return obj

    @property
    def level(self) -> LogLevel:
        """UI context level for this log message code."""
        return self._level


class CommonLogMessageCode(LogMessageCode):
    """General/shared log message codes used across all plugins."""

    PLUGIN_RUN_COMPLETE = ('PLUGIN_RUN_COMPLETE', LogLevel.INFO)


# Global template registry: maps LogMessageCode members to template strings.
# Each plugin's log_messages module calls register_log_messages() at import time.
# This registry is kept for backward compatibility; the i18n translator is the primary source.
_TEMPLATE_REGISTRY: dict[LogMessageCode, str] = {}


def register_log_messages(templates: dict[LogMessageCode, str | dict[str, str]]) -> None:
    """Register log message templates into the global registry with i18n support.

    Called at import time by each plugin's log_messages module.

    Args:
        templates: Mapping of code to template(s).
            - str: Single language template (treated as 'en')
            - dict[str, str]: Multi-language templates {lang: template}

    Example:
        >>> # Legacy format (still supported)
        >>> register_log_messages({
        ...     UploadLogMessageCode.UPLOAD_INITIALIZED: 'Storage initialized',
        ... })

        >>> # i18n format
        >>> register_log_messages({
        ...     UploadLogMessageCode.UPLOAD_INITIALIZED: {
        ...         'en': 'Storage initialized',
        ...         'ko': '스토리지가 초기화되었습니다',
        ...     },
        ... })

    Note:
        Invalid template values are skipped with a warning log to prevent job failures.
    """
    import logging

    from synapse_sdk.i18n import get_translator

    translator = get_translator()

    for code, template in templates.items():
        if isinstance(template, str):
            # Legacy format: single string = English only
            translator.register('en', {code.value: template})
            _TEMPLATE_REGISTRY[code] = template
        elif isinstance(template, dict):
            # i18n format: dict of translations
            valid_templates: dict[str, str] = {}
            for lang, tmpl in template.items():
                if not isinstance(tmpl, str):
                    logging.warning(
                        f'Skipping invalid translation for {code.value}[{lang}]: '
                        f'expected str, got {type(tmpl).__name__}: {tmpl!r}'
                    )
                    continue
                translator.register(lang, {code.value: tmpl})
                valid_templates[lang] = tmpl
            # Store English in legacy registry for backward compat
            if valid_templates:
                _TEMPLATE_REGISTRY[code] = valid_templates.get('en', next(iter(valid_templates.values())))
        else:
            logging.warning(
                f'Skipping invalid template for {code.value}: '
                f'expected str or dict[str, str], got {type(template).__name__}: {template!r}'
            )


def resolve_log_message(
    code: LogMessageCode,
    language: str | None = None,
    **kwargs: Any,
) -> tuple[str, LogLevel]:
    """Resolve a log message code into a formatted message and level.

    The level is read from ``code.level`` (embedded in the enum member).
    Uses the i18n translator to resolve the message in the target language.

    Args:
        code: The log message code to resolve.
        language: Target language (ISO 639-1). None = use translator's current language.
        **kwargs: Format parameters for the message template.

    Returns:
        Tuple of (formatted_message, level).

    Example:
        >>> resolve_log_message(UploadLogMessageCode.UPLOAD_FILES_UPLOADING, count=10)
        ('Uploading 10 files', LogLevel.INFO)

        >>> resolve_log_message(UploadLogMessageCode.UPLOAD_FILES_UPLOADING, language='ko', count=10)
        ('10개 파일 업로드 중', LogLevel.INFO)
    """
    from synapse_sdk.i18n import get_translator

    translator = get_translator()
    message = translator.translate(code.value, language=language, **kwargs)
    return message, code.level


# Register common templates (will be overwritten by i18n/messages/en.py if loaded)
register_log_messages({
    CommonLogMessageCode.PLUGIN_RUN_COMPLETE: 'Plugin run is complete.',
})


__all__ = [
    'LogMessageCode',
    'CommonLogMessageCode',
    'register_log_messages',
    'resolve_log_message',
]
