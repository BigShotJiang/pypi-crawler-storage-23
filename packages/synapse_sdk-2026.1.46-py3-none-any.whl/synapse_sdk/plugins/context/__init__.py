from __future__ import annotations

import warnings
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from synapse_sdk.plugins.context.env import PluginEnvironment
from synapse_sdk.plugins.log_messages import CommonLogMessageCode, LogMessageCode
from synapse_sdk.plugins.models.logger import LogLevel

if TYPE_CHECKING:
    from synapse_sdk.clients.agent import AgentClient
    from synapse_sdk.clients.backend import BackendClient
    from synapse_sdk.i18n import LocalizedMessage
    from synapse_sdk.loggers import BaseLogger


@dataclass
class RuntimeContext:
    """Runtime context injected into actions.

    Provides access to logging, environment, and client dependencies.
    All action dependencies are accessed through this context object.

    Attributes:
        logger: Logger instance for progress, metrics, and event logging.
        env: Environment variables and configuration as PluginEnvironment.
        job_id: Optional job identifier for tracking.
        client: Optional backend client for API access.
        agent_client: Optional agent client for Ray operations.
        checkpoint: Optional checkpoint info for pretrained models.
            Contains 'category' ('base' or fine-tuned) and 'path' to model.
        language: Optional language code (ISO 639-1) for log messages.
            If not set, uses SYNAPSE_LANGUAGE env var or defaults to 'en'.

    Example:
        >>> ctx = RuntimeContext(
        ...     logger=ConsoleLogger(),
        ...     env=PluginEnvironment.from_environ(),
        ...     job_id='job-123',
        ...     language='ko',
        ...     checkpoint={'category': 'base', 'path': '/models/yolov8n.pt'},
        ... )
        >>> ctx.set_progress(50, 100)
        >>> ctx.log('checkpoint', {'epoch': 5})
    """

    logger: BaseLogger
    env: PluginEnvironment
    job_id: str | None = None
    client: BackendClient | None = None
    agent_client: AgentClient | None = None
    checkpoint: dict[str, Any] | None = None
    language: str | None = field(default=None)

    def _get_effective_language(self, override: str | None = None) -> str:
        """Get effective language with priority resolution.

        Priority order:
        1. Override parameter (explicit language for this call)
        2. Context language (set at context creation)
        3. SYNAPSE_LANGUAGE environment variable
        4. Default 'en'

        Args:
            override: Explicit language override for this call.

        Returns:
            Language code (ISO 639-1).
        """
        if override is not None:
            return override
        if self.language is not None:
            return self.language
        return self.env.get_str('SYNAPSE_LANGUAGE', 'en') or 'en'

    def log(self, event: str, data: dict[str, Any], file: str | None = None) -> None:
        """Log an event with data.

        Args:
            event: Event name/type.
            data: Dictionary of event data.
            file: Optional file path associated with the event.
        """
        self.logger.log(LogLevel.INFO, event, data, file)

    def set_progress(self, current: int, total: int, step: str | None = None) -> None:
        """Set progress for the current operation.

        Args:
            current: Current progress value (0 to total).
            total: Total progress value.
            step: Optional step name for multi-phase progress.
        """
        self.logger.set_progress(current, total, step)

    def set_metrics(self, value: dict[str, Any], step: str) -> None:
        """Set metrics for a step.

        Args:
            value: Dictionary of metric values.
            step: Non-empty step name.
        """
        self.logger.set_metrics(value, step)

    def log_message(
        self,
        message: str | dict[str, str] | LocalizedMessage | LogMessageCode,
        level: LogLevel = LogLevel.INFO,
        *,
        context: str | LogLevel | None = None,
        language: str | None = None,
        step: str | None = None,
        **kwargs: Any,
    ) -> None:
        """Log a user-facing message with i18n support.

        Sends a log entry with event='message' to the backend.

        Accepts multiple message formats:
        - Plain string (no i18n, used as-is)
        - dict[str, str] mapping language codes to templates
        - LocalizedMessage instance
        - LogMessageCode enum (resolved from registry with i18n)

        Args:
            message: Message content in one of the supported formats.
            level: Log level (LogLevel enum). Ignored when message is a LogMessageCode
                (level comes from template). Preferred parameter.
            context: DEPRECATED. Use 'level' instead.
            language: Override language for this message only (ISO 639-1).
            step: Optional step name to include in the log entry.
            **kwargs: Format parameters for message templates.

        Example:
            >>> # Plain string (no i18n)
            >>> ctx.log_message('Custom message', LogLevel.INFO)

            >>> # LogMessageCode with i18n
            >>> ctx.log_message(UploadLogMessageCode.UPLOAD_FILES_UPLOADING, count=10)

            >>> # Dict-based i18n
            >>> ctx.log_message({
            ...     'en': 'Processing {count} items',
            ...     'ko': '{count}개 항목 처리 중',
            ... }, count=10)

            >>> # LocalizedMessage
            >>> from synapse_sdk.i18n import LocalizedMessage
            >>> msg = LocalizedMessage(en='Hello', ko='안녕하세요')
            >>> ctx.log_message(msg)
        """
        from synapse_sdk.i18n import LocalizedMessage as LM

        # Handle deprecated context parameter
        if context is not None:
            warnings.warn(
                "The 'context' parameter is deprecated. Use 'level' instead.",
                DeprecationWarning,
                stacklevel=2,
            )
            level = context if isinstance(context, LogLevel) else LogLevel(context)

        # Get effective language
        effective_lang = self._get_effective_language(language)

        key: str | None = None
        resolved_message: str

        if isinstance(message, LogMessageCode):
            # LogMessageCode: resolve from registry with i18n
            from synapse_sdk.plugins.log_messages import resolve_log_message

            key = message.value
            resolved_message, level = resolve_log_message(message, language=effective_lang, **kwargs)
            level = level if isinstance(level, LogLevel) else LogLevel(level)

        elif isinstance(message, dict):
            # Dict-based i18n: {lang: template}
            template = message.get(effective_lang) or message.get('en', '')
            resolved_message = template.format(**kwargs) if kwargs else template

        elif isinstance(message, LM):
            # LocalizedMessage instance
            resolved_message = message.format(effective_lang, 'en', **kwargs)

        else:
            # Plain string: use as-is (no i18n)
            resolved_message = message.format(**kwargs) if kwargs else message

        data = self.logger._build_message_data(resolved_message, key=key)
        self.logger.log(level, 'message', data, step=step)

    def log_metric(
        self,
        category: str,
        key: str,
        value: float | int,
        **metrics: Any,
    ) -> None:
        """Log a training metric.

        Sends a log entry with event='metric' to the backend.

        Args:
            category: Metric category (e.g., 'train', 'val').
            key: Metric key (e.g., 'loss', 'accuracy').
            value: Metric value.
            **metrics: Additional metrics as keyword arguments.

        Example:
            >>> ctx.log_metric('train', 'loss', 0.5, accuracy=0.95)
        """
        if hasattr(self.logger, 'log_metric'):
            self.logger.log_metric(category, key, value, **metrics)
        else:
            data = {'category': category, 'key': key, 'value': value, 'metrics': metrics}
            self.logger.log(LogLevel.INFO, 'metric', data)

    def log_visualization(
        self,
        category: str,
        group: str,
        index: int,
        image: str,
        **meta: Any,
    ) -> None:
        """Log a visualization image.

        Sends a log entry with event='visualization' to the backend.
        The image file is automatically converted to base64.

        Args:
            category: Visualization category (e.g., 'train', 'val').
            group: Group name for organizing visualizations.
            index: Index within the group.
            image: Path to the image file.
            **meta: Additional metadata as keyword arguments.

        Example:
            >>> ctx.log_visualization('train', 'predictions', 0, '/tmp/pred.png')
        """
        if hasattr(self.logger, 'log_visualization'):
            self.logger.log_visualization(category, group, index, image, **meta)
        else:
            data = {'category': category, 'group': group, 'index': index, **meta}
            self.logger.log(LogLevel.INFO, 'visualization', data, image)

    def log_trials(
        self,
        data: dict[str, Any] | None = None,
        *,
        trials: dict[str, Any] | None = None,
        base: list[str] | None = None,
        hyperparameters: list[str] | None = None,
        metrics: list[str] | None = None,
        best_trial: str = '',
    ) -> None:
        """Log Ray Tune trial progress.

        Sends a log entry with event='trials' to the backend.

        Args:
            data: Pre-built payload containing 'trials' key.
            trials: Mapping of trial_id to trial data.
            base: Column names for the base section.
            hyperparameters: Column names for hyperparameters.
            metrics: Column names for metrics.
            best_trial: Trial ID of the best trial.

        Example:
            >>> ctx.log_trials(
            ...     trials={'trial_1': {'loss': 0.1}},
            ...     metrics=['loss'],
            ...     best_trial='trial_1'
            ... )
        """
        if hasattr(self.logger, 'log_trials'):
            self.logger.log_trials(
                data, trials=trials, base=base, hyperparameters=hyperparameters, metrics=metrics, best_trial=best_trial
            )
        else:
            if data is None:
                data = {
                    'base': base or [],
                    'trials': trials or {},
                    'hyperparameters': hyperparameters or [],
                    'metrics': metrics or [],
                    'best_trial': best_trial,
                }
            self.logger.log(LogLevel.INFO, 'trials', data)

    def log_dev_event(self, message: str, data: dict[str, Any] | None = None) -> None:
        """Log a development/debug event.

        For plugin developers to log custom events during execution.
        Not shown to end users by default.

        Args:
            message: Event message.
            data: Optional additional data.
        """
        self.logger.log(LogLevel.DEBUG, 'dev_event', {'message': message, 'data': data})

    def end_log(self) -> None:
        """Signal that plugin execution is complete."""
        self.log_message(CommonLogMessageCode.PLUGIN_RUN_COMPLETE)


__all__ = ['PluginEnvironment', 'RuntimeContext']
