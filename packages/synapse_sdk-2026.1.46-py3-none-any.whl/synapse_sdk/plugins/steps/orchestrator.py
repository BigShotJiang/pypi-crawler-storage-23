"""Orchestrator for executing workflow steps with rollback support."""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING, Any

from synapse_sdk.plugins.steps.base import BaseStep, StepResult

if TYPE_CHECKING:
    from synapse_sdk.plugins.steps.context import BaseStepContext
    from synapse_sdk.plugins.steps.registry import StepRegistry


class Orchestrator[C: BaseStepContext]:
    """Executes workflow steps with progress tracking and rollback.

    Type parameter C is the context type shared between steps.
    Runs steps in order, tracking progress based on step weights.
    On failure, automatically rolls back executed steps in reverse order.

    IMPORTANT: progress_callback is required for proper job status management.
    Without progress_callback, the backend will not receive progress updates
    and the job status will NOT transition to 'success' upon completion.

    Attributes:
        registry: StepRegistry containing ordered steps.
        context: Shared context for step communication.
        progress_callback: Callback for progress updates (required).

    Example:
        >>> registry = StepRegistry[MyContext]()
        >>> registry.register(InitStep())
        >>> registry.register(ProcessStep())
        >>> context = MyContext(runtime_ctx=runtime_ctx)
        >>> orchestrator = Orchestrator(
        ...     registry=registry,
        ...     context=context,
        ...     progress_callback=lambda curr, total: action.set_progress(curr, total),
        ... )
        >>> result = orchestrator.execute()
    """

    def __init__(
        self,
        registry: StepRegistry[C],
        context: C,
        progress_callback: Callable[[int, int], None],
    ) -> None:
        """Initialize orchestrator.

        Args:
            registry: StepRegistry with steps to execute.
            context: Shared context for steps.
            progress_callback: Callback(current, total) for progress updates.
                This is required for proper job status management. Without it,
                job status will not transition to 'success' upon completion.
                Typically: lambda curr, total: self.set_progress(curr, total)
        """
        self._registry = registry
        self._context = context
        self._progress_callback = progress_callback
        self._executed_steps: list[tuple[BaseStep[C], StepResult]] = []

    def execute(self) -> dict[str, Any]:
        """Execute all steps in order with rollback on failure.

        Returns:
            Dict with success status and step count.

        Raises:
            RuntimeError: If any step fails (after rollback).
        """
        steps = self._registry.get_steps()
        logger = getattr(self._context.runtime_ctx, 'logger', None)

        # Auto-configure step proportions from registry if using JobLogger
        self._configure_step_proportions()

        try:
            for i, step in enumerate(steps):
                # Set current step name and order for auto-category support
                self._context._set_current_step(step.name, order=i)
                if logger is not None:
                    logger.set_step(step.name, order=i)

                # Check skip condition
                if step.can_skip(self._context):
                    result = StepResult(success=True, skipped=True)
                    self._context.step_results.append(result)
                    # Report skipped step as 100% complete
                    self._progress_callback(100, 100)
                    continue

                # Execute step
                try:
                    result = step.execute(self._context)
                except Exception as e:
                    result = StepResult(success=False, error=str(e))

                self._context.step_results.append(result)
                self._executed_steps.append((step, result))

                if not result.success:
                    self._rollback()
                    raise RuntimeError(f"Step '{step.name}' failed: {result.error}")

                # Report step as 100% complete
                # The JobLogger calculates overall progress based on step proportions
                self._progress_callback(100, 100)

            return {
                'success': True,
                'steps_executed': len(self._executed_steps),
                'steps_total': len(steps),
            }
        finally:
            # Clear current step after execution completes or fails
            self._context._set_current_step(None)
            if logger is not None:
                logger.set_step(None)

    def _configure_step_proportions(self) -> None:
        """Configure step proportions in JobLogger from registry.

        Automatically extracts progress_proportion values from registered
        steps and sets them in JobLogger via set_step_proportions().
        This allows steps to define their own progress proportions.

        IMPORTANT: If step proportions are already configured (e.g., by
        _run_tune() setting TUNE_STEP_PROPORTIONS), this method skips
        auto-configuration to avoid overwriting the parent's proportions.
        """
        # Get step proportions from registry
        proportions = self._registry.get_step_proportions()
        if not proportions:
            return

        # Get logger from context
        logger = getattr(self._context.runtime_ctx, 'logger', None)
        if logger is None:
            return

        # Check if it's a JobLogger and set proportions
        # Import here to avoid circular imports
        from synapse_sdk.loggers import JobLogger

        if isinstance(logger, JobLogger):
            # Skip if proportions are already configured (e.g., by parent tune run)
            # This prevents nested Orchestrators from overwriting parent's proportions
            if logger._step_proportions:
                return

            try:
                orders = self._registry.get_step_orders()
                logger.set_step_proportions(proportions, orders=orders)
            except RuntimeError:
                # Progress already started, skip
                pass

    def _rollback(self) -> None:
        """Rollback executed steps in reverse order.

        Best-effort rollback - errors during rollback are logged but
        do not prevent other steps from rolling back.
        """
        for step, result in reversed(self._executed_steps):
            try:
                step.rollback(self._context, result)
            except Exception:
                # Best effort rollback - log but continue
                self._context.errors.append(f"Rollback failed for step '{step.name}'")
