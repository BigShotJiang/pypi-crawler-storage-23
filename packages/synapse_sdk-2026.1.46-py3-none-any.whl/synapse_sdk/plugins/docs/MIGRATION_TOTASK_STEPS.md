# ToTaskAction Migration Guide: Step-Based Workflow

## Overview

ToTaskAction has been refactored from a single-step workflow to a comprehensive 5-step workflow with method-specific progress optimization. This guide helps developers understand the changes and migrate existing code if needed.

## What Changed

### Before (Single Step)
```python
class ToTaskAction(BaseAction[ToTaskParams]):
    progress = ToTaskProgressCategories()  # ❌ Removed

    def _annotate_tasks(self, context):
        # Everything in one method
        pass
```

### After (5 Steps)
```python
class ToTaskAction(BaseAction[ToTaskParams]):
    # ✅ No progress attribute

    def setup_steps(self, registry):
        # ✅ 5 steps automatically registered
        registry.register(InitializeStep())
        registry.register(PrepareStep(method=self.params.method))
        registry.register(FetchTasksStep())
        registry.register(ProcessTasksStep(action=self, method=self.params.method))
        registry.register(FinalizeStep())
```

## Breaking Changes

### 1. Removed: `ToTaskProgressCategories` Class
**Before:**
```python
from synapse_sdk.plugins.actions.to_task import ToTaskProgressCategories
category = ToTaskProgressCategories.ANNOTATE_TASK_DATA
```

**After:**
```python
# Not needed - steps define their own names
# Metrics still use 'annotate_task_data' for backward compatibility
```

### 2. Removed: `progress` Attribute
**Before:**
```python
class MyToTaskAction(ToTaskAction):
    def custom_method(self):
        self.set_progress(50, 100, self.progress.ANNOTATE_TASK_DATA)
```

**After:**
```python
class MyToTaskAction(ToTaskAction):
    def custom_method(self):
        # Steps handle progress automatically
        # If needed, use context.set_progress() in custom steps
        pass
```

## Non-Breaking Changes (Public API Preserved)

### ✅ ToTaskParams - Unchanged
```python
params = ToTaskParams(
    name='job',
    project=1,
    agent=1,
    method=ToTaskMethod.FILE,
    target_specification_name='annotations',
)
```

### ✅ ToTaskResult - Unchanged
```python
result = action.run()
assert result.success_count == 10
assert result.failed_count == 0
```

### ✅ Abstract Methods - Unchanged
```python
class MyToTaskAction(ToTaskAction):
    def convert_data_from_file(self, ...):
        # Still required - no changes needed
        pass

    def convert_data_from_inference(self, ...):
        # Still required - no changes needed
        pass
```

## New 5-Step Workflow

### Step 1: InitializeStep (10%)
- Loads project and data collection
- Validates basic requirements

### Step 2: PrepareStep (5% FILE / 20% INFERENCE)
- **FILE**: Validates target specification
- **INFERENCE**: Deploys pre-processor, waits for ready

### Step 3: FetchTasksStep (10%)
- Retrieves task IDs based on filters
- Validates at least one task found

### Step 4: ProcessTasksStep (70% FILE / 60% INFERENCE)
- Iterates through tasks
- Calls `convert_data_from_file()` or `convert_data_from_inference()`
- Tracks success/failure per task

### Step 5: FinalizeStep (5%)
- Logs completion statistics
- Returns final result

## Progress Weight Optimization

### FILE Method (Fast per-task)
```
Initialize:    10% ████
Prepare:        5% ██
FetchTasks:    10% ████
ProcessTasks:  70% ████████████████████████████
Finalize:       5% ██
```

### INFERENCE Method (Slow per-task, needs deployment)
```
Initialize:    10% ████
Prepare:       20% ████████  (pre-processor deployment)
FetchTasks:    10% ████
ProcessTasks:  60% ████████████████████
Finalize:       5% ██
```

## Migration Checklist

### For Plugin Developers

- [ ] ✅ **No action needed** if you only override `convert_data_from_file()` and `convert_data_from_inference()`
- [ ] Remove any references to `ToTaskProgressCategories` (if importing it)
- [ ] Remove any references to `action.progress.ANNOTATE_TASK_DATA`
- [ ] Update tests if they mock progress tracking

### For Custom Implementations

If you subclassed ToTaskAction and overrode internal methods:

- [ ] Remove overrides of `_annotate_tasks()` (moved to ProcessTasksStep)
- [ ] Remove overrides of helper methods (moved to appropriate steps)
- [ ] Consider customizing via `setup_steps()` if needed

## Customization Examples

### Add Custom Validation Step
```python
class MyToTaskAction(ToTaskAction):
    def setup_steps(self, registry):
        super().setup_steps(registry)

        # Add custom validation before processing
        registry.insert_before('process_tasks', MyValidationStep())
```

### Replace Prepare Step
```python
class MyToTaskAction(ToTaskAction):
    def setup_steps(self, registry):
        super().setup_steps(registry)

        # Replace prepare step with custom logic
        registry.unregister('prepare')
        registry.register(MyCustomPrepareStep(method=self.params.method))
```

### Add Notification Step
```python
class MyToTaskAction(ToTaskAction):
    def setup_steps(self, registry):
        super().setup_steps(registry)

        # Add notification after finalization
        registry.insert_after('finalize', MyNotificationStep())
```

## Testing

### Existing Tests Should Pass
All existing tests continue to work because:
- `execute()` still exists and delegates to `run()`
- Public API unchanged
- Metrics still use 'annotate_task_data' category
- RuntimeError converted to ValueError for compatibility

### New Test Patterns
```python
def test_to_task_with_steps():
    action = MyToTaskAction(params, ctx)
    result = action.run()  # Uses 5-step workflow

    assert result.success_count == expected_count
    assert result.failed_count == 0
```

## Benefits of New Architecture

1. **Better UX**: 5 progress updates instead of 1
2. **Method Optimization**: Different progress weights reflect actual workload
3. **Code Quality**: Clear separation of concerns
4. **Testability**: Each step can be tested independently
5. **Maintainability**: Easier to modify individual steps
6. **Consistency**: Follows patterns from Export and Upload actions
7. **Rollback Support**: Steps can implement rollback for error recovery

## Questions?

See:
- [STEP.md](STEP.md) - Complete step system documentation
- [ACTION_DEV_GUIDE.md](ACTION_DEV_GUIDE.md) - Action development guide
- [ARCHITECTURE.md](ARCHITECTURE.md) - System architecture

## Implementation Details

### Files Created
- `synapse_sdk/plugins/actions/to_task/steps/__init__.py`
- `synapse_sdk/plugins/actions/to_task/steps/initialize.py`
- `synapse_sdk/plugins/actions/to_task/steps/prepare.py`
- `synapse_sdk/plugins/actions/to_task/steps/fetch_tasks.py`
- `synapse_sdk/plugins/actions/to_task/steps/process_tasks.py`
- `synapse_sdk/plugins/actions/to_task/steps/finalize.py`

### Files Modified
- `synapse_sdk/plugins/actions/to_task/action.py` (200 lines, was 651)
- `synapse_sdk/plugins/actions/to_task/log_messages.py` (12 codes, was 4)
- `synapse_sdk/plugins/actions/to_task/__init__.py`
- `synapse_sdk/plugins/actions/__init__.py`

### Test Status
✅ All 3 existing tests passing:
- `test_file_method_success`
- `test_file_method_missing_target_spec_raises`
- `test_inference_method_success`

---

**Version**: Implemented in SYN-6341
**Date**: February 2026
**Status**: ✅ Production Ready
