"""
Relation Tool Processor

Created: 2025-12-12

Conversion Rules (see data-model.md 9.9):
V1 → V2:
  - annotationId, targetAnnotationId → data [from_id, to_id]
  - classification.class → classification
  - classification.{other} → attrs[{name, value}]

V2 → V1:
  - data [from_id, to_id] → annotationId, targetAnnotationId
  - classification → classification.class
  - attrs[{name, value}] → classification.{name: value}
"""

from typing import Any


class RelationProcessor:
    """Relation Tool Processor

    V1 annotationData: {annotationId, targetAnnotationId}
    V2 data: [from_id, to_id]

    Represents relationship between two annotations.
    """

    tool_name = 'relation'

    _META_FIELDS = {'isLocked', 'isVisible', 'isValid', 'isDrawCompleted', 'label', 'id', 'tool'}
    _INTERNAL_ATTR_PREFIX = '_'

    def to_v2(self, v1_annotation: dict[str, Any], v1_data: dict[str, Any]) -> dict[str, Any]:
        """Convert V1 relation to V2"""
        classification_obj = v1_annotation.get('classification') or {}

        # V2 data: [from_id, to_id]
        data = [
            v1_data.get('annotationId', ''),
            v1_data.get('targetAnnotationId', ''),
        ]

        # Build V2 attrs
        attrs: list[dict[str, Any]] = []
        for key, value in classification_obj.items():
            if key != 'class':
                attrs.append({'name': key, 'value': value})

        return {
            'id': v1_annotation.get('id', ''),
            'classification': classification_obj.get('class', ''),
            'attrs': attrs,
            'data': data,
        }

    def to_v1(self, v2_annotation: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
        """Convert V2 relation to V1"""
        annotation_id = v2_annotation.get('id', '')
        classification_str = v2_annotation.get('classification', '')
        attrs = v2_annotation.get('attrs', [])
        data = v2_annotation.get('data', [])

        # Build V1 classification
        classification: dict[str, Any] = {'class': classification_str}
        for attr in attrs:
            name = attr.get('name', '')
            value = attr.get('value')
            if not name.startswith(self._INTERNAL_ATTR_PREFIX):
                classification[name] = value

        v1_annotation: dict[str, Any] = {
            'id': annotation_id,
            'tool': self.tool_name,
            'classification': classification,
        }

        # V1 annotationData
        v1_data: dict[str, Any] = {
            'id': annotation_id,
            'annotationId': data[0] if len(data) > 0 else '',
            'targetAnnotationId': data[1] if len(data) > 1 else '',
        }

        return v1_annotation, v1_data
