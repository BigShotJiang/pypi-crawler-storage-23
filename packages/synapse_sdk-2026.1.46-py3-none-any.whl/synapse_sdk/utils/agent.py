"""Agent client utilities for SDK."""

from __future__ import annotations

import os
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from synapse_sdk.clients.agent import AgentClient


def create_agent_client() -> AgentClient | None:
    """Create an AgentClient for the local agent from environment variables.

    Reads SYNAPSE_AGENT_URL and SYNAPSE_AGENT_TOKEN (set by the agent
    service).  Also forwards SYNAPSE_PLUGIN_RUN_USER_TOKEN and
    SYNAPSE_PLUGIN_RUN_TENANT so the agent can authenticate downstream
    requests on behalf of the user.

    Returns:
        AgentClient if agent URL and token are available, None otherwise.
    """
    agent_url = os.environ.get('SYNAPSE_AGENT_URL')
    agent_token = os.environ.get('SYNAPSE_AGENT_TOKEN')

    if not agent_url or not agent_token:
        return None

    from synapse_sdk.clients.agent import AgentClient

    return AgentClient(
        base_url=agent_url,
        agent_token=agent_token,
        user_token=os.environ.get('SYNAPSE_PLUGIN_RUN_USER_TOKEN'),
        tenant=os.environ.get('SYNAPSE_PLUGIN_RUN_TENANT'),
    )


__all__ = ['create_agent_client']
