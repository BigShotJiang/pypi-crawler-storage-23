"""Ultralytics YOLO callback implementations for autolog."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from synapse_sdk.integrations._context import get_autolog_context
from synapse_sdk.plugins.actions.train.log_messages import TrainLogMessageCode
from synapse_sdk.plugins.enums import MetricsCategory


def on_train_epoch_end(trainer: Any) -> None:
    """Log training metrics at end of each epoch.

    Logs:
        - Progress: epoch/total_epochs
        - Metrics: box_loss, cls_loss, dfl_loss (category=MetricsCategory.TRAIN)

    Args:
        trainer: Ultralytics trainer instance.
    """
    ctx = get_autolog_context()
    if ctx is None:
        return

    action = ctx.action
    epoch = trainer.epoch + 1
    total_epochs = ctx.total_epochs or getattr(trainer, 'epochs', 100)

    # Update progress
    action.set_progress(epoch, total_epochs, 'train')

    # Log epoch message (every 10 epochs or first/last)
    if epoch == 1 or epoch == total_epochs or epoch % 10 == 0:
        action.log_message(TrainLogMessageCode.TRAIN_EPOCH_PROGRESS, epoch=epoch, total_epochs=total_epochs)

    # Log loss metrics with event='metric'
    if hasattr(trainer, 'loss_items') and trainer.loss_items is not None:
        loss_items = trainer.loss_items
        if hasattr(loss_items, 'cpu'):
            loss_items = loss_items.cpu().numpy()

        action.log_metric(
            MetricsCategory.TRAIN,
            'epoch',
            epoch,
            box_loss=float(loss_items[0]),
            cls_loss=float(loss_items[1]),
            dfl_loss=float(loss_items[2]),
        )


def on_fit_epoch_end(trainer: Any) -> None:
    """Log validation metrics after validation pass.

    Logs:
        - Metrics: mAP50, mAP50_95 (category=MetricsCategory.VALIDATION)
        - Files: validation batch prediction images

    Args:
        trainer: Ultralytics trainer instance.
    """
    ctx = get_autolog_context()
    if ctx is None:
        return

    action = ctx.action
    epoch = trainer.epoch + 1
    total_epochs = ctx.total_epochs or getattr(trainer, 'epochs', 100)
    metrics = trainer.metrics

    # Track logged metric epochs to prevent duplicates on final epoch only
    # (Ultralytics may call on_fit_epoch_end twice on the final epoch)
    logged_metric_epochs = ctx.extra.setdefault('logged_metric_epochs', set())
    if epoch == total_epochs and epoch in logged_metric_epochs:
        return
    logged_metric_epochs.add(epoch)

    if metrics:
        mAP50 = metrics.get('metrics/mAP50(B)', 0)
        mAP50_95 = metrics.get('metrics/mAP50-95(B)', 0)

        # Log validation metrics with event='metric'
        action.log_metric(
            MetricsCategory.VALIDATION,
            'epoch',
            epoch,
            mAP50=mAP50,
            mAP50_95=mAP50_95,
        )

        # Log validation message (every 10 epochs or first)
        if epoch == 1 or epoch == total_epochs or epoch % 10 == 0:
            action.log_message(TrainLogMessageCode.TRAIN_VALIDATION_METRICS, map50=mAP50, map50_95=mAP50_95)

        # Log validation sample images with event='visualization'
        # Use ctx.extra to track logged epochs and prevent duplicates
        logged_vis_epochs = ctx.extra.setdefault('logged_visualization_epochs', set())
        if epoch not in logged_vis_epochs:
            logged_vis_epochs.add(epoch)
            save_dir = Path(trainer.save_dir)
            for i in range(3):
                img_path = save_dir / f'val_batch{i}_pred.jpg'
                if img_path.exists():
                    action.log_visualization(
                        MetricsCategory.VALIDATION,
                        str(epoch),
                        i,
                        str(img_path),
                    )

    # Ray Tune integration - report metrics to Ray Tune
    env = action.ctx.env
    if hasattr(env, 'get_bool'):
        is_tune = env.get_bool('IS_TUNE', default=False)
    else:
        # Handle case where env is a dict (e.g., remote execution)
        is_tune = str(env.get('IS_TUNE', 'false')).lower() in ('true', '1', 'yes')
    if is_tune and metrics:
        try:
            from ray import tune

            # Report metrics with original Ultralytics keys (e.g., 'metrics/mAP50-95(B)')
            # Ray Tune and search algorithms (OptunaSearch, etc.) support special characters
            # in metric keys. The backend should send the exact key that matches the
            # reported metrics (as defined in the plugin's config.yaml).
            # Ray 2.x tune.report() requires a dict as the first positional argument.
            tune.report(metrics)
        except ImportError:
            pass


def on_val_start(validator: Any) -> None:
    """Force validation plots on every epoch.

    Ultralytics validator disables plots on non-final epochs via
    ``self.args.plots &= stopper.possible_stop or (epoch == epochs - 1)``.
    This callback runs after that line, resetting plots to True so
    val_batch prediction images are generated every epoch.

    Args:
        validator: Ultralytics validator instance.
    """
    validator.args.plots = True


def on_train_end(trainer: Any) -> None:
    """Log training completion and store model path for upload step.

    This callback only stores the model path in autolog context.
    The actual model upload is handled by _ModelUploadStep to ensure
    it works universally for all plugins, not just ultralytics autolog.

    Logs:
        - Message: Training completed, model saved

    For tune mode:
        - Reports checkpoint_output via ray.tune.report()

    Args:
        trainer: Ultralytics trainer instance.
    """
    ctx = get_autolog_context()
    if ctx is None:
        return

    action = ctx.action
    save_dir = Path(trainer.save_dir)
    weights_dir = save_dir / 'weights'

    action.log_message(TrainLogMessageCode.TRAIN_COMPLETED)

    if (weights_dir / 'best.pt').exists():
        action.log_message(TrainLogMessageCode.TRAIN_MODEL_SAVED)

    # Store model path in autolog context for _ModelUploadStep
    if weights_dir.exists():
        ctx.extra['model_path'] = str(weights_dir)

    # Note: In tune mode, checkpoint_output is passed via _trial_entrypoint return value
    # instead of tune.report() to avoid KeyError in search algorithms like OptunaSearch
    # that expect every reported result to contain the optimization metric.


__all__ = ['on_train_epoch_end', 'on_fit_epoch_end', 'on_val_start', 'on_train_end']
