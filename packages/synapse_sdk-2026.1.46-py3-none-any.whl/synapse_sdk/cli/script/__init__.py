"""Script execution CLI commands."""

from synapse_sdk.cli.script.submit import ScriptSubmitResult, submit_script

__all__ = ['ScriptSubmitResult', 'submit_script']
