"""Script submission to Ray cluster."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse

from rich.console import Console


@dataclass
class ScriptSubmitResult:
    """Result of script submission."""

    script: str
    job_id: str


def submit_script(
    script: Path,
    console: Console,
    *,
    ray_address: str,
    requirements: Path | None = None,
    env_vars: dict[str, str] | None = None,
    num_gpus: int | None = None,
    num_cpus: int | None = None,
    include_sdk: bool = False,
) -> ScriptSubmitResult:
    """Submit a Python script to a Ray cluster for execution.

    Args:
        script: Path to the .py script file.
        console: Rich console for output.
        ray_address: Ray cluster address (e.g., ray://host:10001).
        requirements: Optional path to requirements.txt.
        env_vars: Additional environment variables.
        num_gpus: Number of GPUs to request.
        num_cpus: Number of CPUs to request.
        include_sdk: If True, bundle local SDK with upload.

    Returns:
        ScriptSubmitResult with job ID.
    """
    from synapse_sdk.plugins.executors.ray.jobs_api import RayJobsApiExecutor

    # Derive dashboard address from ray_address
    if ray_address.startswith('ray://'):
        parsed = urlparse(ray_address)
        dashboard_addr = f'http://{parsed.hostname}:8265'
    else:
        dashboard_addr = 'http://localhost:8265'

    console.print(f'[dim]Script:[/dim] {script}')
    console.print(f'[dim]Dashboard:[/dim] {dashboard_addr}')
    if num_gpus is not None:
        console.print(f'[dim]GPUs:[/dim] {num_gpus}')
    if num_cpus is not None:
        console.print(f'[dim]CPUs:[/dim] {num_cpus}')

    executor = RayJobsApiExecutor(
        dashboard_address=dashboard_addr,
        working_dir=script.parent,
        requirements_file=requirements,
        num_gpus=num_gpus,
        num_cpus=num_cpus,
        include_sdk=include_sdk,
    )

    job_id = executor.submit_script(script, env_vars=env_vars)

    console.print(f'[dim]Job submitted:[/dim] {job_id}')

    return ScriptSubmitResult(script=str(script), job_id=job_id)


__all__ = ['ScriptSubmitResult', 'submit_script']
