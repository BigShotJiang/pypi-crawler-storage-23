"""
kepler-atlas: A simplified SQLAlchemy ORM with pandas integration.

Features:
- Lazy table reflection for improved performance
- Case-insensitive table and column access
- Multi-database support with dialect-specific optimizations
- Seamless pandas DataFrame integration

Example:
    from kepler.atlas import DataBase

    db = DataBase('sqlite:///example.db')
    users = db.users  # Lazy loaded table
    df = db.query(users).filter(users.age > 18).to_df()
"""

from .core.database import DataBase
from .core.exceptions import (
    AtlasError,
    ConnectionError,
    InsertError,
    TableError,
    ValidationError,
)

__all__ = [
    'DataBase',
    'AtlasError',
    'TableError',
    'ConnectionError',
    'InsertError',
    'ValidationError',
]

__version__ = '0.2.0'
