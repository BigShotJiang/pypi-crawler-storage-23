"""Enhanced SQLAlchemy Session with DataFrame support."""
from sqlalchemy.orm import Session as SQLAlchemySession

from .query import Query


class Session(SQLAlchemySession):
    """
    Enhanced SQLAlchemy Session with DataFrame support.

    This session class uses the enhanced Query by default, which provides
    the to_df() method for converting query results to pandas DataFrames.
    """

    def __init__(self, bind=None, **kwargs):
        """
        Initialize the session with sensible defaults.

        Args:
            bind: SQLAlchemy engine or connection
            **kwargs: Additional session arguments
        """
        kwargs.setdefault('query_cls', Query)
        kwargs.setdefault('future', True)
        kwargs.setdefault('expire_on_commit', True)

        super().__init__(bind=bind, **kwargs)
