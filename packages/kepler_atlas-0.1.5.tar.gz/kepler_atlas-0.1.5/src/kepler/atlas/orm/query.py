"""Enhanced SQLAlchemy Query with DataFrame support."""
import pandas as pd
from sqlalchemy.orm import Query as SQLAlchemyQuery


class Query(SQLAlchemyQuery):
    """
    Enhanced SQLAlchemy Query with pandas DataFrame conversion.

    Example:
        df = db.query(db.users).filter(db.users.age > 18).to_df()
    """

    def to_df(self, **kwargs) -> pd.DataFrame:
        """
        Convert query result to a pandas DataFrame.

        Args:
            **kwargs: Additional arguments passed to pd.read_sql

        Returns:
            pandas.DataFrame containing the query results
        """
        return pd.read_sql(sql=self.statement, con=self.session.bind, **kwargs)
