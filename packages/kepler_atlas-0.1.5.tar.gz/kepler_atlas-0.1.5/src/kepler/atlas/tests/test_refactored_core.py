"""Tests for kepler-atlas core functionality."""
import pytest
import pandas as pd
from sqlalchemy import create_engine, MetaData, Table, Column, Integer, String

from kepler.atlas import DataBase, AtlasError, TableError, ValidationError
from kepler.atlas.core.dialects import DialectFactory, MySQLInsertStrategy


class TestDialectFactory:
    """Test the dialect factory and insert strategies."""

    def test_get_mysql_strategy(self):
        strategy = DialectFactory.get_strategy('mysql')
        assert isinstance(strategy, MySQLInsertStrategy)
        assert strategy.get_ignore_clause(True) == 'IGNORE'
        assert strategy.get_ignore_clause(False) == ''

    def test_get_sqlite_strategy(self):
        strategy = DialectFactory.get_strategy('sqlite')
        assert strategy.get_ignore_clause(True) == 'OR REPLACE'
        assert strategy.get_ignore_clause(False) == ''

    def test_get_unknown_strategy(self):
        strategy = DialectFactory.get_strategy('unknown_db')
        with pytest.raises(Exception):
            strategy.validate_bulk_insert(True)

    def test_case_insensitive_dialect_names(self):
        mysql1 = DialectFactory.get_strategy('mysql')
        mysql2 = DialectFactory.get_strategy('MySQL')
        assert type(mysql1) == type(mysql2)


class TestDataBase:
    """Test the DataBase class."""

    def test_unbound_initialization(self):
        """Test initialization without bind."""
        db = DataBase(None)
        assert db._bind is None
        assert db._session is None
        assert db._table_registry is None

    def test_no_inject_method(self):
        """Test that inject method no longer exists."""
        db = DataBase(None)
        assert not hasattr(db, 'inject')

    def test_runtime_errors_when_not_connected(self):
        """Test that operations raise RuntimeError when not connected."""
        db = DataBase(None)

        with pytest.raises(RuntimeError, match="Database not connected"):
            db.query()

        with pytest.raises(RuntimeError, match="Database not connected"):
            db.update(None)

        with pytest.raises(RuntimeError, match="Database not connected"):
            db.insert(None, [])

        with pytest.raises(RuntimeError, match="Database not connected"):
            db.delete(None)

        with pytest.raises(RuntimeError, match="Database not connected"):
            db.commit()

    def test_repr(self):
        """Test __repr__ method."""
        db = DataBase(None)
        assert '<DataBase (unbound)>' in repr(db)


class TestDatabaseIntegration:
    """Integration tests for database operations."""

    @pytest.fixture
    def db(self):
        """Create an in-memory SQLite database for testing."""
        engine = create_engine('sqlite:///:memory:')
        metadata = MetaData()
        Table(
            'users', metadata,
            Column('id', Integer, primary_key=True),
            Column('name', String(50)),
            Column('email', String(100))
        )
        metadata.create_all(engine)
        return DataBase(engine)

    def test_tables_property(self, db):
        """Test tables property."""
        assert 'users' in db.tables

    def test_table_access(self, db):
        """Test table access."""
        users_class = db.users
        assert users_class is not None

    def test_case_insensitive_table_access(self, db):
        """Test case-insensitive table access."""
        users_class = db.users
        assert db.USERS == users_class
        assert db.Users == users_class

    def test_query_method(self, db):
        """Test query method."""
        users_class = db.users
        query = db.query(users_class)
        assert query is not None

    def test_insert_with_list(self, db):
        """Test insert with list of dicts."""
        users_class = db.users
        test_data = [
            {'name': 'Alice', 'email': 'alice@test.com'},
            {'name': 'Bob', 'email': 'bob@test.com'}
        ]

        result = db.insert(users_class, test_data)
        assert result is not None
        db.commit()

        inserted_users = db.query(users_class).all()
        assert len(inserted_users) == 2

    def test_insert_with_dataframe(self, db):
        """Test insert with DataFrame."""
        users_class = db.users
        df = pd.DataFrame({
            'name': ['Charlie', 'Diana'],
            'email': ['charlie@test.com', 'diana@test.com']
        })

        db.insert(users_class, df)
        db.commit()

        inserted_users = db.query(users_class).all()
        assert len(inserted_users) == 2
        assert set(user.name for user in inserted_users) == {'Charlie', 'Diana'}

    def test_insert_empty_dataframe_raises_error(self, db):
        """Test that empty DataFrame raises ValidationError."""
        users_class = db.users
        df = pd.DataFrame()

        with pytest.raises(ValidationError, match="DataFrame is empty"):
            db.insert(users_class, df)

    def test_insert_invalid_type_raises_error(self, db):
        """Test that invalid type raises ValidationError."""
        users_class = db.users

        with pytest.raises(ValidationError, match="must be DataFrame or list of dicts"):
            db.insert(users_class, "invalid")

    def test_query_to_df(self, db):
        """Test query to_df method."""
        users_class = db.users
        db.insert(users_class, [
            {'name': 'Alice', 'email': 'alice@test.com'},
            {'name': 'Bob', 'email': 'bob@test.com'}
        ])
        db.commit()

        df = db.query(users_class).to_df()
        assert len(df) == 2
        assert 'name' in df.columns
        assert 'email' in df.columns

    def test_update_and_delete(self, db):
        """Test update and delete operations."""
        users_class = db.users

        # Insert
        db.insert(users_class, [{'name': 'Alice', 'email': 'alice@test.com'}])
        db.commit()

        # Query
        user = db.query(users_class).first()
        assert user.name == 'Alice'

        # Update
        user.name = 'Alice Updated'
        db.merge(user)
        db.commit()

        updated = db.query(users_class).first()
        assert updated.name == 'Alice Updated'

        # Delete
        db.delete(updated)
        db.commit()

        remaining = db.query(users_class).all()
        assert len(remaining) == 0

    def test_transaction_rollback(self, db):
        """Test transaction rollback."""
        users_class = db.users

        db.insert(users_class, [{'name': 'Alice', 'email': 'alice@test.com'}])
        db.flush()

        db.rollback()

        remaining = db.query(users_class).all()
        assert len(remaining) == 0

    def test_context_manager(self):
        """Test context manager usage."""
        engine = create_engine('sqlite:///:memory:')
        metadata = MetaData()
        Table('users', metadata, Column('id', Integer, primary_key=True))
        metadata.create_all(engine)

        with DataBase(engine) as db:
            assert 'users' in db.tables

    def test_base_property(self, db):
        """Test Base property for model definitions."""
        assert db.Base is not None

    def test_metadata_property(self, db):
        """Test metadata property."""
        assert db.metadata is not None

    def test_properties(self, db):
        """Test various properties."""
        assert db.bind is not None
        assert db.schema is None


class TestExceptions:
    """Test exception hierarchy."""

    def test_atlas_error_is_base(self):
        """Test AtlasError is base exception."""
        assert issubclass(TableError, AtlasError)
        assert issubclass(ValidationError, AtlasError)

    def test_table_error_message(self):
        """Test TableError can be raised with message."""
        with pytest.raises(TableError):
            raise TableError("Table not found")


if __name__ == '__main__':
    pytest.main([__file__])
