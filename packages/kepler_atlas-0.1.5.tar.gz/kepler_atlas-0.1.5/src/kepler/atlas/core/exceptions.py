"""Custom exceptions for kepler-atlas library."""


class AtlasError(Exception):
    """Base exception class for all kepler-atlas errors."""
    pass


class TableError(AtlasError):
    """Raised when table operations fail (reflection, not found, no PK)."""
    pass


class ConnectionError(AtlasError):
    """Raised when database connection fails."""
    pass


class InsertError(AtlasError):
    """Raised when insert strategy fails."""
    pass


class ValidationError(AtlasError):
    """Raised when input validation fails."""
    pass
