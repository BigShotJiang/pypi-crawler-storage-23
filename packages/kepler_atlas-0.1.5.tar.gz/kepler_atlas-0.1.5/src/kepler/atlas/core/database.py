"""DataBase class for simplified ORM operations."""
import reprlib
from collections.abc import Iterable
from typing import Any, List, Optional, Union

import pandas as pd
from sqlalchemy import create_engine
from sqlalchemy.engine import Engine

from kepler.atlas.orm import Session

from .dialects import DialectFactory
from .exceptions import ValidationError
from .table_registry import TableRegistry


class DataBase:
    """
    Simplified DataBase class for ORM operations.

    Features:
    - Lazy table reflection for improved performance
    - Case-insensitive table and column access
    - Multi-database support with dialect-specific optimizations
    - pandas DataFrame integration

    Args:
        bind: SQLAlchemy engine or connection string
        schema: Optional database schema name

    Example:
        db = DataBase('sqlite:///example.db')
        users = db.users  # Lazy loaded table
        df = db.query(users).filter(users.age > 18).to_df()
    """

    def __init__(self, bind: Union[str, Engine, None] = None, schema: Optional[str] = None):
        if bind is None:
            self._bind = None
            self._schema = None
            self._session = None
            self._table_registry = None
            self._insert_strategy = None
            return

        if schema == 'None':
            schema = None

        if isinstance(bind, str):
            try:
                bind = create_engine(bind)
            except Exception as e:
                raise ValidationError(f"Failed to create engine from '{bind}': {e}") from e

        self._bind = bind
        self._schema = schema
        self._session = Session(self._bind)
        self._table_registry = TableRegistry(self._bind, schema)

        dialect_name = self._bind.dialect.name
        self._insert_strategy = DialectFactory.get_strategy(dialect_name)

    def __getattr__(self, name: str) -> Any:
        """Handle dynamic table access with lazy loading."""
        if self._table_registry is not None:
            try:
                table_class = self._table_registry.get_table(name)
                # Cache on instance for faster future access
                object.__setattr__(self, name, table_class)
                return table_class
            except Exception:
                pass

        available = self._table_registry.available_tables if self._table_registry else []
        raise AttributeError(
            f"'{name}' is not a valid table or attribute. "
            f"Available tables: {reprlib.repr(available)}"
        )

    def __repr__(self) -> str:
        if self._bind is None:
            return f"<{type(self).__name__} (unbound)>"
        return str(self._bind).replace(type(self._bind).__name__, type(self).__name__)

    def __dir__(self):
        """Return list of attributes for IPython tab completion."""
        # Get default attributes
        attrs = list(super().__dir__())

        # Add table names with case variants for tab completion
        if self._table_registry is not None:
            for table_name in self._table_registry.available_tables:
                attrs.append(table_name)

        return attrs

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    # -------------------------------------------------------------------------
    # Properties
    # -------------------------------------------------------------------------

    @property
    def bind(self) -> Optional[Engine]:
        """Get the underlying SQLAlchemy engine."""
        return self._bind

    @property
    def schema(self) -> Optional[str]:
        """Get the database schema name."""
        return self._schema

    @property
    def tables(self) -> List[str]:
        """Get a list of all available table names."""
        if self._table_registry is None:
            return []
        return self._table_registry.available_tables

    @property
    def Base(self):
        """Get the automap base class for defining custom models."""
        if self._table_registry is None:
            return None
        return self._table_registry.base

    @property
    def metadata(self):
        """Access to the underlying SQLAlchemy metadata."""
        if self._table_registry:
            return self._table_registry._metadata
        return None

    # -------------------------------------------------------------------------
    # Connection Management
    # -------------------------------------------------------------------------

    def close(self) -> None:
        """Close the database session."""
        if self._session is not None:
            self._session.close()

    def refresh(self) -> None:
        """Refresh the database connection and table metadata."""
        if self._bind is not None:
            if self._session:
                self._session.close()
            self.__init__(self._bind, self._schema)

    # -------------------------------------------------------------------------
    # Query Operations
    # -------------------------------------------------------------------------

    def query(self, *columns) -> Any:
        """
        Create a SQLAlchemy query object.

        Args:
            *columns: Optional columns to query

        Returns:
            Query object with to_df() support
        """
        if self._session is None:
            raise RuntimeError("Database not connected.")
        return self._session.query(*columns)

    def reflect(self) -> None:
        """Reflect all tables in the database."""
        if self._table_registry is None:
            return
        self._table_registry.reflect_all_tables()

    # -------------------------------------------------------------------------
    # CRUD Operations
    # -------------------------------------------------------------------------

    def insert(self, table, insert_obj, ignore: bool = True, index: Optional[str] = None):
        """
        Insert bulk data into the database.

        Args:
            table: SQLAlchemy table class (e.g., db.users)
            insert_obj: DataFrame or list of dictionaries to insert
            ignore: Whether to ignore duplicate key errors (default: True)
            index: Index name for Oracle ignore functionality
        """
        if self._session is None:
            raise RuntimeError("Database not connected.")

        if isinstance(insert_obj, pd.DataFrame):
            if insert_obj.empty:
                raise ValidationError('The input DataFrame is empty.')
            insert_obj = insert_obj.to_dict('records')
        elif not isinstance(insert_obj, list):
            raise ValidationError(
                f"insert_obj must be DataFrame or list of dicts, got {type(insert_obj)}"
            )

        if self._insert_strategy:
            self._insert_strategy.validate_bulk_insert(ignore=ignore, table=table, index=index)

        ignore_str = ""
        if self._insert_strategy:
            ignore_str = self._insert_strategy.get_ignore_clause(
                ignore=ignore, table=table, index=index
            )

        insert_statement = table.__table__.insert()
        if ignore_str:
            insert_statement = insert_statement.prefix_with(ignore_str)

        return self._session.execute(insert_statement.values(insert_obj))

    def update(self, t_obj) -> None:
        """Update or insert objects into the database."""
        if self._session is None:
            raise RuntimeError("Database not connected.")

        if isinstance(t_obj, Iterable):
            self._session.add_all(t_obj)
        else:
            self._session.add(t_obj)

    def delete(self, t_obj) -> Any:
        """Delete an object from the database."""
        if self._session is None:
            raise RuntimeError("Database not connected.")
        return self._session.delete(t_obj)

    def merge(self, t_obj):
        """Merge an object into the current session."""
        if self._session is None:
            raise RuntimeError("Database not connected.")

        if isinstance(t_obj, Iterable):
            for obj in t_obj:
                self._session.merge(obj)
            return
        return self._session.merge(t_obj)

    # -------------------------------------------------------------------------
    # Transaction Management
    # -------------------------------------------------------------------------

    def commit(self) -> None:
        """Commit the current transaction."""
        if self._session is None:
            raise RuntimeError("Database not connected.")
        self._session.commit()

    def flush(self, objects=None) -> None:
        """Flush pending changes to the database."""
        if self._session is None:
            raise RuntimeError("Database not connected.")
        self._session.flush(objects=objects)

    def rollback(self) -> None:
        """Roll back the current transaction."""
        if self._session is None:
            raise RuntimeError("Database not connected.")
        self._session.rollback()

    # -------------------------------------------------------------------------
    # Schema Operations
    # -------------------------------------------------------------------------

    def create_all(self, tables=None, checkfirst: bool = True) -> None:
        """Create all tables defined in the metadata."""
        if self._bind is None:
            raise RuntimeError("Database not connected.")

        if self._table_registry:
            self._table_registry._metadata.create_all(
                bind=self._bind,
                tables=tables,
                checkfirst=checkfirst
            )
            self.refresh()
        else:
            raise RuntimeError("Table registry not initialized.")
