"""Table registry for managing lazy table reflection."""
import reprlib
from typing import Any, Dict, List, Optional, Set

from sqlalchemy import MetaData, inspect
from sqlalchemy.engine import Engine
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm.attributes import InstrumentedAttribute

from .exceptions import TableError


class TableRegistry:
    """
    Manages lazy table reflection with optimized metadata caching.

    Features:
    - Incremental reflection (no full metadata clear)
    - Case-insensitive table and column access
    - Cached automap base for repeated access
    """

    def __init__(self, bind: Engine, schema: Optional[str] = None):
        self._bind = bind
        self._schema = schema
        self._metadata = MetaData(schema=schema)
        self._base = None
        self._tables: Set[str] = set()
        self._reflected_tables: Dict[str, Any] = {}
        self._load_table_names()

    def _load_table_names(self) -> None:
        """Load all table names from the database."""
        insp = inspect(self._bind)
        self._tables = set(insp.get_table_names(schema=self._schema))

    @property
    def available_tables(self) -> List[str]:
        """Get a list of all available table names."""
        return list(self._tables)

    @property
    def base(self):
        """Get the automap base, creating it if necessary."""
        if self._base is None:
            self._base = automap_base(metadata=self._metadata)
            self._base.prepare()
        return self._base

    def table_exists(self, table_name: str) -> bool:
        """Check if a table exists in the database."""
        return table_name in self._tables

    def _resolve_table_name(self, name: str) -> Optional[str]:
        """
        Resolve a table name to its actual name in the database.

        Uses case-insensitive matching.
        """
        # Direct match
        if name in self._tables:
            return name

        # Case-insensitive match
        name_lower = name.lower()
        for table_name in self._tables:
            if table_name.lower() == name_lower:
                return table_name

        return None

    def _reflect_table(self, table_name: str) -> Any:
        """
        Reflect a specific table and return the mapped class.

        Args:
            table_name: Name of the table to reflect

        Returns:
            Mapped SQLAlchemy table class

        Raises:
            TableError: If the table doesn't exist or has no primary key
        """
        actual_name = self._resolve_table_name(table_name)
        if actual_name is None:
            raise TableError(
                f"Table '{table_name}' not found. "
                f"Available tables: {reprlib.repr(self.available_tables)}"
            )

        try:
            # Only reflect the specific table (incremental)
            self._metadata.reflect(
                bind=self._bind,
                only=[actual_name],
                extend_existing=True
            )

            # Rebuild automap base with new table
            self._base = automap_base(metadata=self._metadata)
            self._base.prepare()

            # Get the mapped class
            table_class = self._base.classes[actual_name]

            # Add case-insensitive column access
            self._add_column_variants(table_class)

            return table_class

        except KeyError as e:
            raise TableError(
                f"Table '{actual_name}' must have a primary key for ORM mapping."
            ) from e
        except Exception as e:
            raise TableError(
                f"Failed to reflect table '{actual_name}': {e}"
            ) from e

    def _add_column_variants(self, table_class) -> None:
        """Add case-insensitive access to table columns."""
        for key in list(table_class.__dict__.keys()):
            if key.startswith('_'):
                continue

            column = getattr(table_class, key)
            if isinstance(column, InstrumentedAttribute):
                # Add lowercase and uppercase variants
                if key.lower() != key:
                    setattr(table_class, key.lower(), column)
                if key.upper() != key:
                    setattr(table_class, key.upper(), column)

    def get_table(self, table_name: str) -> Any:
        """
        Get a table, reflecting it lazily if necessary.

        Args:
            table_name: Name of the table to get (case-insensitive)

        Returns:
            Mapped SQLAlchemy table class

        Raises:
            TableError: If the table doesn't exist or has no primary key
        """
        # Resolve actual table name first
        actual_name = self._resolve_table_name(table_name)
        if actual_name is None:
            raise TableError(
                f"Table '{table_name}' not found. "
                f"Available tables: {reprlib.repr(self.available_tables)}"
            )

        # Check cache
        if actual_name in self._reflected_tables:
            return self._reflected_tables[actual_name]

        # Reflect and cache
        table_class = self._reflect_table(table_name)
        self._reflected_tables[actual_name] = table_class

        return table_class

    def reflect_all_tables(self) -> Dict[str, Any]:
        """
        Reflect all tables in the database.

        Returns:
            Dictionary mapping table names to mapped classes
        """
        self._metadata.reflect(bind=self._bind)
        self._base = automap_base(metadata=self._metadata)
        self._base.prepare()

        reflected = {}
        for table_name, table_class in self._base.classes.items():
            self._add_column_variants(table_class)
            reflected[table_name] = table_class
            self._reflected_tables[table_name] = table_class

        return reflected

    def refresh(self) -> None:
        """Refresh the table registry by reloading table names."""
        self._reflected_tables.clear()
        self._metadata.clear()
        self._base = None
        self._load_table_names()
