# know_the_time

Get the time in different formats. Quickly available time stamps, dates, etc. are available useing functions. - makes `datetime` more available.
## Content
- Installation
- Usage

## Installation
- `pip install know-the-time`

## Usage

## Links
[GitHub](https://github.com/ICreedenI/know_the_time) | [PyPI](https://pypi.org/project/know-the-time/)