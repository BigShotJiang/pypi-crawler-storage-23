"""GooseFS gRPC generated files."""
