from .definitions import (
    Fore,
    Back,
    Style,
    TermAct,
    colored_print,
    demo_print,
    foreground_demo,
    background_demo,
    style_demo,
    rgb_demo,
    rainbow_demo,
    reprint_last_line,
    PauseFlag,
)

__version__ = "0.1.7"
