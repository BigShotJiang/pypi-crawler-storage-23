"""Bundled default enhancement workflow presets."""
