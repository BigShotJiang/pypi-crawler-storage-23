from bex_hooks.exec.cli import main

__all__ = ["main"]
