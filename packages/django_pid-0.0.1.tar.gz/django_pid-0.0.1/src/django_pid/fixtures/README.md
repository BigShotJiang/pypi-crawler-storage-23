# Fixtures

This folder can be used to add default table entries ("fixtures") into the LARA database tables.