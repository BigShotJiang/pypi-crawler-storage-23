"""_____________________________________________________________________

:PROJECT: opensourcelab

*django_pid celery tasks*

:details: django_pid celery tasks.
         - 
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - 
________________________________________________________________________
"""

# from config import celery_app

# @celery_app.task()

from celery import shared_task, current_task
from celery.utils.log import get_task_logger

logger = get_task_logger(__name__)

@shared_task
def create_pid():
    logger.info(f"create_pid")
    return "create_pid"