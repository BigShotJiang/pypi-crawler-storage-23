"""_____________________________________________________________________

:PROJECT: LARAsuite

*django_pid gRPC serializer*

:details: django_pid gRPC serializer.
         - 
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - 
________________________________________________________________________
"""

