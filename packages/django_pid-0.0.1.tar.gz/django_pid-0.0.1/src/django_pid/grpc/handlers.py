"""_____________________________________________________________________

:PROJECT: LARAsuite

*django_pid gRPC handlers*

:details: django_pid gRPC handlers.
         - 
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - 
________________________________________________________________________
"""

