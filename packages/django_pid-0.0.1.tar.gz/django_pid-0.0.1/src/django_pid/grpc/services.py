"""_____________________________________________________________________

:PROJECT: LARAsuite

*django_pid gRPC services*

:details: django_pid gRPC services.
         - 
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - 
________________________________________________________________________
"""

