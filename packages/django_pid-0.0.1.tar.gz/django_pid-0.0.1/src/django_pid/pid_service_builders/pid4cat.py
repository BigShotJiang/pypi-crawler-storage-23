import httpx
import json
import logging

# get django settings

from django.conf import settings


logger = logging.getLogger(__name__)


class PID4CatServiceBuilder:
    def __init__(
        self,
        resource_type: str,
    ):
        self.resource_type = resource_type

    def __call__(self):
        return PID4CatService(resource_type=self.resource_type)


class PID4CatService:  # (PIDServiceBase)
    def __init__(self, resource_type: str):

        self.resource_type = resource_type
        self.pid_server_api = settings.PID_SERVER_APIS["pid4cat"]
        self.pid = None

        self.api_base_url = self.pid_server_api

        # self.pid_client = httpx.Client(auth=(self.pid_server_api['user'], self.pid_server_api['password']))

    def create_pid(self, metadata: dict):
        """Create a PID for a resource."""
        # create the PID

        handle_scheme = self.pid_type["name"]

        handle_create_url = f"{self.api_base_url}/{handle_scheme}/"

        target_url = "https://lara.org/pid_target_url"  # extract from metadata

        params = {"data": target_url}

        logger.info(f"Create PID {handle_create_url} {params}")
        # res = self.pid_client.get(handle_create_url, params=params)
        # logger.info(f"Create PID {res}")

    def change_visibility(self, pid, visible: bool):
        """Change the visibility of a PID."""
        logger.info(f"Change PID visibility {pid} to {visible}")

    def delete_pid(self, pid):
        """Delete a PID."""
        logger.info(f"Delete PID {pid}")


PIDServiceBuilder = PID4CatServiceBuilder
