"""_____________________________________________________________________

:PROJECT: LARAsuite

*django_pid app *

:details: django_pid app configuration. 
         This provides a generic django app configuration mechanism.
         For more details see:
         https://docs.djangoproject.com/en/4.0/ref/applications/
         - 
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - 
________________________________________________________________________
"""


from django.apps import AppConfig
from object_factory import object_factory

from django_pid.pid_service_builders.pid4cat import PID4CatServiceBuilder

class PIDService(object_factory.ObjectFactory):
    """PIDService is a factory for PIDBuilderInterface"""

    def get(self, service_id, **kwargs):
        return self.create(service_id.strip().lower(), **kwargs)
    

class djangoPIDConfig(AppConfig):
    name = 'django_pid'
    # enter a verbose name for your app: django_pid here - this will be used in the admin interface
    verbose_name = 'django-pid'
    # lara_app_icon = 'django_pid_icon.svg'  # this will be used to display an icon, e.g. in the main LARA menu.

    pid_service = PIDService()

    pid_service.register_builder('pid4cat', PID4CatServiceBuilder)



