Invoking Sage
=============

To run Sage, you basically just need to type ``sage`` from the
command-line prompt to start the Sage interpreter.  See the Sage
Installation Guide for information about making sure your
:envvar:`$PATH` is set correctly, etc.

Command-line options for Sage
-----------------------------

.. literalinclude:: options.txt
