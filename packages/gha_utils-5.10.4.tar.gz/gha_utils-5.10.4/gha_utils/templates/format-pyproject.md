---
title: Format `pyproject.toml`
---

### Description

Auto-formats `pyproject.toml` with [pyproject-fmt](https://github.com/tox-dev/pyproject-fmt). See the [`format-pyproject` job documentation](https://github.com/kdeldycke/workflows?tab=readme-ov-file#githubworkflowsautofixyaml-jobs) for details.
