"""video-thumbnail-creator: Extract and select thumbnail images from video files."""

from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("video-thumbnail-creator")
except PackageNotFoundError:
    __version__ = "0.0.0"

from .extractor import extract_frames, extract_single_frame_highres
from .mosaic import create_mosaic
from .poster_composer import compose_poster, compose_landscape_with_text
from .ai_selector import select_frame_with_ai
from .embedded_image import detect_embedded_image, extract_embedded_image
from .sidecar_image import detect_sidecar_image
from .utils import get_video_properties, check_dependencies
from .badges import detect_badges
from .fanart_composer import compose_fanart, FANART_SUFFIX
from .session import ThumbnailSession, ThumbnailResult
from .api import create_thumbnail

__all__ = [
    "__version__",
    "extract_frames",
    "extract_single_frame_highres",
    "create_mosaic",
    "compose_poster",
    "compose_landscape_with_text",
    "select_frame_with_ai",
    "detect_embedded_image",
    "extract_embedded_image",
    "detect_sidecar_image",
    "get_video_properties",
    "check_dependencies",
    "detect_badges",
    "compose_fanart",
    "FANART_SUFFIX",
    "ThumbnailSession",
    "ThumbnailResult",
    "create_thumbnail",
]
