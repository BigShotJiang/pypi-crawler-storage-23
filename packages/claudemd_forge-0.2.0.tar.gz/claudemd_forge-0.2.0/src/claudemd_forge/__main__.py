"""Allow running as `python -m claudemd_forge`."""

from claudemd_forge.cli import app

if __name__ == "__main__":
    app()
