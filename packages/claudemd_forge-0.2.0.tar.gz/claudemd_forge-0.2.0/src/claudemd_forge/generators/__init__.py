"""CLAUDE.md generators for ClaudeMD Forge."""
