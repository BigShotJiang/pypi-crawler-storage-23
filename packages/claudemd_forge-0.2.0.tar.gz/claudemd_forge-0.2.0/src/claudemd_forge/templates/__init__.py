"""Template system for ClaudeMD Forge."""
