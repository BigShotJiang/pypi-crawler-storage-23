"""ClaudeMD Forge — Generate and audit CLAUDE.md files for AI coding agents."""

__version__ = "0.2.0"

__all__ = [
    "__version__",
]
