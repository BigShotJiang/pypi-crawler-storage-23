"""Lakebench - CLI tool for deploying and benchmarking lakehouse architectures on Kubernetes."""

__version__ = "1.0.7"
