__init__ = ['rcParams']

rcParams = {
    'satellite.cmr_to_level3.method': 'download',
}
