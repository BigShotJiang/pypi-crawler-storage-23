if __name__ == '__main__':
    from .drivers import parse_args
    # args will be gathered from the command line
    parse_args(args=None, noexit=False)
