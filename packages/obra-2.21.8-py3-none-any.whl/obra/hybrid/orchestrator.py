"""Hybrid Orchestrator for EPIC-HYBRID-001.

This module provides the client-side orchestration logic for the Unified Hybrid Architecture.
It connects to the server, dispatches actions to appropriate handlers, and manages the
orchestration loop.

Design Principle (from PRD):
    - Server owns the brain (decisions, orchestration logic)
    - Client owns the hands (execution, code access)

The HybridOrchestrator:
    1. Starts a session with the server
    2. Receives action instructions from the server
    3. Dispatches to appropriate handlers (derive, examine, revise, execute, review, fix)
    4. Reports results back to the server
    5. Repeats until completion or escalation

Related:
    - docs/design/prds/UNIFIED_HYBRID_ARCHITECTURE_PRD.md Section 3
    - obra/api/protocol.py
    - obra/hybrid/handlers/*.py
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import subprocess
import sys
import time
import uuid
from collections import deque
from collections.abc import Callable
from datetime import UTC, datetime, timedelta
from http import HTTPStatus
from pathlib import Path
from typing import Any, cast
from urllib.parse import urlencode

from pydantic import BaseModel

from obra.api import APIClient
from obra.api.protocol import (
    ActionType,
    AgentType,
    CompletionNotice,
    DEFAULT_REVIEW_AGENTS,
    DEFAULT_REPORT_REVIEW_AGENT_TYPES,
    DerivedPlan,
    DeriveRequest,
    EscalationDecision,
    EscalationNotice,
    EscalationReason,
    ExaminationReport,
    ExamineRequest,
    ExecutionRequest,
    ExecutionResult,
    ExecutionStatus,
    FixRequest,
    FixReport,
    IntentRequest,
    PipelineStageRequest,
    ResumeContext,
    ReviewRequest,
    RevisedPlan,
    RevisionRequest,
    ServerAction,
    SessionPhase,
    SessionStart,
    StoryPreflightRequest,
    UserDecision,
    UserDecisionChoice,
)
from obra.config import (
    get_max_iterations,
    get_watchdog_enabled,
    get_watchdog_max_silent_seconds,
    get_watchdog_stall_timeout,
)
from obra.config.llm import resolve_action_llm_config, resolve_role_llm_config
from obra.constants import (
    HYBRID_POLLING_BACKOFF_MULTIPLIER,
    HYBRID_POLLING_BASE_DELAY_S,
    HYBRID_POLLING_MAX_DELAY_S,
)
from obra.constants import (
    MAX_POLLING_RETRIES as DEFAULT_MAX_POLLING_RETRIES,
)
from obra.core.interrupts import (
    GracefulInterrupt,
    interrupt_reason,
    interrupt_requested,
)

# FEAT-PROCESS-LIFECYCLE-001: Process lifecycle management for subprocess cleanup
from obra.core.process_registry import (
    ProcessRegistry,
    create_process_registry_from_config,
)
from obra.display import console, print_info, print_warning
from obra.display.observability import ObservabilityConfig, ProgressEmitter
from obra.exceptions import (
    APIError,
    AuthenticationError,
    ConfigurationError,
    ConnectionError,
    ErrorContext,
    OrchestratorError,
    SessionCompletedInfo,
)
from obra.execution.skip_record import SkipReason, SkipSource, create_skip_record

# ISSUE-SAAS-042: Use HybridEventLogger for observability
# This is the SaaS-spec logger - always available in published package
from obra.hybrid.event_logger import HybridEventLogger

# FEAT-SESSION-GUARD-001: Session runtime guard (zombie prevention)
from obra.hybrid.session_guard import SessionGuard
from obra.messages import get_message
from obra.model_registry import resolve_quality_tier

# Production logger for detailed derivation metrics and quality observability
from obra.observability.production_logger import ProductionLogger, get_production_logger
from obra.review.config import ReviewConfig
from obra.schemas.userplan_schema import DerivedPlanItem
from obra.utils.cli_cache_monitor import CLICacheMonitor
from obra.utils.obra_home import get_runtime_dir

logger = logging.getLogger(__name__)

DEFAULT_MAX_USERPLAN_STEPS_LOGGED = 200
DEFAULT_MAX_DERIVED_ITEMS_LOGGED = 200
DEFAULT_MAX_PLAN_TITLE_LEN = 300
PLAN_SNAPSHOT_DIRNAME = "plan_snapshots"

# ISSUE-CLI-012: Maximum polling retry attempts before circuit breaker triggers
# Set to 5 per industry best practices (AWS, Google Cloud, Stripe all use 3-5)
# Observed behavior showed 7 attempts before manual termination
MAX_POLLING_RETRIES = DEFAULT_MAX_POLLING_RETRIES

# Bypass mode severity classification.
# Safety overrides relax quality gates or validation — these warrant a prominent Warning.
# All other modes (workflow modifiers, continuation optimizations) are informational.
_SAFETY_OVERRIDE_MODES: frozenset[str] = frozenset({
    "planning_permissive",
    "permissive_planning",
    "permissive",
    "skip_quality_check",
    "skip_tier_check",
    "skip_complexity_check",
})

# ADR-069: Action-to-role mapping for role-based LLM configuration
# This maps each ActionType to a handler role name used for LLM config resolution.
# Planning actions (derive, examine, revise) use "orchestrator" profile by default.
# Execution actions (execute, fix) use "implementation" profile by default.
# See: docs/decisions/ADR-069-role-based-llm-configuration.md
ACTION_TO_ROLE: dict[ActionType, str] = {
    ActionType.DERIVE: "derive",
    ActionType.INTENT: "derive",
    ActionType.STORY0: "derive",
    ActionType.STORY_PREFLIGHT: "validator",
    ActionType.EXAMINE: "examine",
    ActionType.REVISE: "revise",
    ActionType.EXECUTE: "execute",
    ActionType.FIX: "fix",
    ActionType.REVIEW: "review",
    ActionType.VALIDATOR: "validator",
}


class HybridOrchestrator:
    """Client-side orchestrator for Obra hybrid architecture.

    ## Architecture

    This orchestrator implements the **client-side** of the Obra SaaS hybrid
    architecture (ADR-035):

    - **Server**: Provides orchestration decisions, action instructions, and validation
    - **Client**: Builds prompts locally, executes LLM/agents, reports results

    ## Handler Responsibilities

    Each handler (`DeriveHandler`, `ExamineHandler`, etc.) implements client-side logic:
    1. Receives action request from server (objective, plan items, issues, etc.)
    2. Builds prompts entirely client-side
    3. Gathers tactical context locally (files, git, errors)
    4. Invokes LLM or agent locally
    5. Reports results back to server for validation

    Note: The marker-based prompt enrichment described in ADR-035 is an aspirational
    design. The current implementation builds prompts entirely client-side.

    ## Privacy Model

    Tactical context (file contents, git messages, errors) stays client-side.
    Server never receives file contents or local project details.

    See: docs/decisions/ADR-035-unified-hybrid-architecture.md
    """

    def __init__(
        self,
        client: APIClient,
        working_dir: Path | None = None,
        on_progress: Callable[[str, dict[str, Any]], None] | None = None,
        on_escalation: Callable[[EscalationNotice], EscalationDecision] | None = None,
        on_stream: Callable[[str, str], None] | None = None,
        review_config: ReviewConfig | None = None,
        defaults_json: bool = False,
        observability_config: ObservabilityConfig | None = None,
        progress_emitter: ProgressEmitter | None = None,
    ) -> None:
        """Initialize HybridOrchestrator.

        Args:
            client: APIClient for server communication
            working_dir: Working directory for file operations
            on_progress: Optional callback for progress updates (action, payload)
            on_escalation: Optional callback for handling escalations
            on_stream: Optional callback for LLM streaming chunks (event_type, content)
            review_config: Review configuration (selection/modifiers/output)
            defaults_json: Whether to output JSON defaults
            observability_config: Optional observability configuration for progress visibility
            progress_emitter: Optional progress emitter for heartbeat and file events
        """
        self._client = client
        # GIT-HARD-001 S2.T3: Track if working_dir was explicitly provided (for Inbox exemption)
        self._working_dir_explicit = working_dir is not None
        self._working_dir = working_dir or Path.cwd()
        self._session_id: str | None = None
        self._trace_id: str | None = None
        self._project_id: str | None = None
        self._project_name: str | None = None
        self._pipeline_start_time: float | None = None
        self._pipeline_span_id: str | None = None
        self._phase_span_id: str | None = None
        self._subphase_span_id: str | None = None
        self._component = "hybrid_client"
        self._on_progress = on_progress
        self._on_escalation = on_escalation
        self._on_stream = on_stream
        self._bypass_modes: list[str] = []
        self._bypass_modes_validated: bool = False  # Track if we've validated modes
        self._bypass_notice_keys: set[str] = set()  # Dedupe bypass warnings per phase/session
        self._session_start_contract_warnings: list[str] = []
        self._skip_completed_items: list[str] = []  # For --continue-from recovery
        self._skipped_item_ids: set[str] = (
            set()
        )  # Items skipped (container/prev completed) - skip review
        self._defaults_json = defaults_json
        self._observability_config = observability_config
        self._progress_emitter = progress_emitter
        self._progress_cursor: str | None = None
        # ISSUE-HYBRID-023: Skip historical progress events on resume
        # Set to ISO timestamp when resume() starts; events before this are skipped
        self._resume_start_timestamp: str | None = None
        # Event deduplication: LRU set of processed event_ids to prevent duplicate emissions
        # (server echoes back events that were already emitted locally)
        self._processed_event_ids: set[str] = set()
        self._processed_event_ids_queue: deque[str] = deque()
        self._processed_event_ids_max: int = 1000  # LRU capacity
        # Track locally-completed items to prevent duplicate item_completed emissions
        # (server echoes back item_completed events that were already emitted locally)
        self._locally_completed_items: set[str] = set()
        # Issue #6: Track started items by execution context to prevent spurious emissions
        # Key format: "{item_id}:{iteration}:{attempt}"
        self._locally_started_items: set[str] = set()
        # Track locally-completed phases to prevent duplicate phase_completed emissions
        # (server stores phase_completed events that duplicate local emissions)
        self._locally_completed_phases: set[str] = set()
        # Track locally-started phases to prevent duplicate phase_started emissions
        self._locally_started_phases: set[str] = set()
        self._config: dict[str, Any] | None = None
        self._objective: str | None = None

        # Handler registry - lazily initialized
        self._handlers: dict[ActionType | tuple[ActionType, str], Any] = {}

        # LLM config - set by from_config() or defaults to None
        self._llm_config: dict[str, Any] | None = None

        # FEAT-COMPLEXITY-ROUTING-001: Planning mode - set by from_config() or defaults to None
        self._planning_mode: str | None = None

        # Phase tracking for observability (S3.T3)
        self._current_phase: SessionPhase | None = None
        self._phase_start_time: float | None = None

        # Polling failure tracking for diagnostics
        self._polling_failure_count: int = 0
        self._last_item_id: str | None = None

        # UserPlan tracking for DerivedPlan reporting
        self._last_userplan_id: str | None = None
        self._last_userplan_version: int | None = None

        # Preserved plan items for --from-step re-derivation merge
        self._preserved_plan_items: list[dict[str, Any]] = []
        self._derive_from_step: int | None = None

        # Last derivation result for phase_completed event (FIX-TRACKER-001)
        self._last_derivation_plan_items: list[dict[str, Any]] = []

        # FIX-ESCALATION-COMPLETION-001: Track if session was escalated
        # Used to prevent "Mission Complete!" celebration on force-completed escalations
        self._was_escalated: bool = False

        # Session-level fix result accumulator for escalation summary context.
        # Populated by _report_fix_result; included in escalation_decision events.
        self._fix_result_history: list[dict[str, Any]] = []

        # FEAT-SESSION-CLOSEOUT-001: Invocation tracking for cumulative runtime
        # Track if session was interrupted (Ctrl+C / GracefulInterrupt)
        self._was_interrupted: bool = False
        # Items completed within the current invocation (for closeout display)
        self._items_completed_this_invocation: int = 0
        # Invocation timing (set at start of start_session/resume)
        self._invocation_id: str | None = None
        self._invocation_start_time: float | None = None

        # Refinement cycle tracking for terminal summary
        self._refinement_cycle_count: int = 0
        self._refinement_start_time: float | None = None
        self._refinement_last_blocking_count: int = 0

        # S0.T7: Track verification tools for mid-session Story 0 injection
        # If FIX needs verification tools and none are available, re-run Story 0
        self._verification_tools: dict[str, Any] | None = None
        self._verification_preflight_attempted: bool = False

        # ISSUE-SAAS-042: Initialize HybridEventLogger for observability
        # This is the SaaS-spec logger - always available in published package
        self._event_logger = HybridEventLogger()
        self._event_logger.set_component(self._component)

        # Production logger for detailed derivation/quality metrics
        # Writes to resolved runtime logs/production.jsonl with structured events
        self._production_logger: ProductionLogger | None = None

        # FEAT-REFINEMENT-PARALLEL-001 S3.T4: C9 dependency validation cache.
        # Stores SHA256 of the dependency graph to skip redundant validation.
        self._c9_graph_hash: str | None = None

        # Review configuration for handler creation
        # Use from_cli_and_config to respect feature gates (quality_automation.agents.*)
        self._review_config = review_config or ReviewConfig.from_cli_and_config(
            project_path=Path(self._working_dir) if self._working_dir else None
        )
        self._server_review_agent_types: set[str] = set(
            DEFAULT_REPORT_REVIEW_AGENT_TYPES
        )

        # FEAT-PROCESS-LIFECYCLE-001: Process registry for subprocess cleanup
        # Set by from_config() based on orchestration.process_cleanup config
        self._process_registry: ProcessRegistry | None = None

        # ISSUE-HYBRID-003: Session watchdog for stall detection
        # Tracks time since last event to detect stuck sessions
        self._watchdog_enabled = get_watchdog_enabled()
        self._watchdog_stall_timeout = get_watchdog_stall_timeout()

        # FEAT-RESILIENCE-P2-001: Graceful degradation tracking
        self._degraded_mode = False
        # ISSUE-HYBRID-008: max_silent_seconds applies even during handler execution
        self._watchdog_max_silent_seconds = get_watchdog_max_silent_seconds()
        self._last_event_time: float = time.time()
        self._handler_active: bool = False
        self._last_action_payload: dict[str, Any] = {}

        # FEAT-SESSION-GUARD-001: Session runtime guard (zombie prevention)
        self._session_guard: SessionGuard | None = None

        logger.debug(f"HybridOrchestrator initialized for {self._working_dir}")

    def _build_error_context(
        self, phase: str | None = None, action: str | None = None
    ) -> ErrorContext:
        """Build ErrorContext for error enrichment.

        Creates an ErrorContext with current session state for inclusion
        in OrchestratorError instances. Enables better debugging by
        including session ID, project ID, current phase, and log path.

        Args:
            phase: Override phase (defaults to _current_phase if set)
            action: Specific action that failed (e.g., 'poll_session', 'derive')

        Returns:
            ErrorContext populated with available session metadata
        """
        # Use explicit phase or current tracking phase
        effective_phase = phase
        if effective_phase is None and self._current_phase is not None:
            effective_phase = self._current_phase.value

        return ErrorContext(
            session_id=self._session_id,
            project_id=self._project_id,
            phase=effective_phase,
            action=action,
            log_path=str(get_runtime_dir() / "logs" / "hybrid.jsonl"),
        )

    def get_crash_snapshot(self) -> dict[str, Any]:
        """Build a snapshot of orchestrator state for crash/bug reports.

        Returns non-sensitive orchestration metadata useful for diagnosing
        crashes without exposing prompts, user content, or credentials.

        Returns:
            Dictionary with session state, phase, and last action metadata.
        """
        snapshot: dict[str, Any] = {
            "session_id": self._session_id,
            "phase": self._current_phase.value if self._current_phase else None,
            "last_item_id": self._last_item_id,
            "items_completed": self._items_completed_this_invocation,
            "refinement_cycles": self._refinement_cycle_count,
            "polling_failures": self._polling_failure_count,
            "degraded_mode": self._degraded_mode,
            "was_escalated": self._was_escalated,
        }
        # Runtime duration
        if self._invocation_start_time:
            snapshot["runtime_s"] = round(time.time() - self._invocation_start_time, 1)
        # Last action metadata (type + structural keys only, no prompt content)
        if self._last_action_payload:
            snapshot["last_action_keys"] = sorted(self._last_action_payload.keys())
            # Include execution_index if present (helps locate crash point in plan)
            if "execution_index" in self._last_action_payload:
                snapshot["execution_index"] = self._last_action_payload["execution_index"]
            if "plan_items" in self._last_action_payload:
                snapshot["plan_item_count"] = len(self._last_action_payload["plan_items"])
        return snapshot

    def get_last_server_action_redacted(self) -> dict[str, Any]:
        """Return the last server action payload with sensitive fields redacted.

        Redacts prompt content, base_prompt, and any field containing
        user-authored content. Preserves structural metadata needed
        for crash diagnosis (action type, field names, item IDs, counts).

        Returns:
            Redacted copy of the last server action payload.
        """
        if not self._last_action_payload:
            return {}

        # Fields that may contain user/LLM content — redact values
        redact_keys = {
            "base_prompt", "prompt", "system_prompt", "user_prompt",
            "objective", "description", "acceptance_criteria",
            "context", "rationale", "instructions",
        }

        def _redact(obj: Any, depth: int = 0) -> Any:
            if depth > 4:
                return "<truncated>"
            if isinstance(obj, dict):
                result = {}
                for k, v in obj.items():
                    if k in redact_keys:
                        result[k] = f"<redacted, {len(str(v))} chars>"
                    elif isinstance(v, (dict, list)):
                        result[k] = _redact(v, depth + 1)
                    elif isinstance(v, str) and len(v) > 500:
                        result[k] = f"<string, {len(v)} chars>"
                    else:
                        result[k] = v
                return result
            if isinstance(obj, list):
                if len(obj) > 10:
                    return [_redact(obj[0], depth + 1), f"... ({len(obj)} items)"]
                return [_redact(item, depth + 1) for item in obj]
            return obj

        return _redact(self._last_action_payload)

    def _get_termination_type(self) -> str:
        """Get the termination type for the current invocation.

        FEAT-SESSION-CLOSEOUT-001: Used for invocation history tracking.

        Returns:
            One of: 'completed', 'escalated', 'interrupted', 'error'
        """
        if self._was_interrupted or interrupt_requested():
            return "interrupted"
        if self._was_escalated:
            return "escalated"
        # Check for error state (could be indicated by various conditions)
        # Currently we don't have a dedicated error flag, so default to completed
        # if neither interrupted nor escalated
        return "completed"

    def _record_invocation(
        self,
        invocation_id: str,
        started_at: float,
        duration_seconds: float,
        termination: str,
        phase_reached: str,
        items_completed: int,
    ) -> None:
        """Record an invocation to session metadata.

        FEAT-SESSION-CLOSEOUT-001: Tracks invocation history for cumulative runtime.

        Args:
            invocation_id: Unique identifier for this invocation
            started_at: Unix timestamp when invocation started
            duration_seconds: Duration of this invocation in seconds
            termination: Termination type (completed, escalated, interrupted, error)
            phase_reached: Phase reached when invocation ended
            items_completed: Number of items completed in this invocation
        """
        if not self._session_id:
            logger.debug("Cannot record invocation: no session_id")
            return

        try:
            # Build invocation record
            invocation_record = {
                "invocation_id": invocation_id,
                "started_at": datetime.fromtimestamp(started_at, tz=UTC).isoformat(),
                "ended_at": datetime.now(UTC).isoformat(),
                "duration_seconds": duration_seconds,
                "termination": termination,
                "phase_reached": phase_reached,
                "items_completed": items_completed,
            }

            # Update session metadata via API
            # Note: The server-side coordinator will handle the metadata update
            # We emit this as an event for the server to process
            self._emit_progress(
                "invocation_recorded",
                {
                    "invocation": invocation_record,
                    "duration_seconds": duration_seconds,
                },
            )
            logger.debug(
                f"Recorded invocation {invocation_id}: {termination}, "
                f"{duration_seconds:.1f}s, {items_completed} items"
            )
        except Exception as e:
            # Don't fail the session if recording fails
            logger.warning(f"Failed to record invocation: {e}")

    def _get_created_files(self) -> list[str]:
        """Get list of files created during this session.

        FEAT-SESSION-CLOSEOUT-001 S4.T1: Extract created files for closeout display.

        Returns:
            List of file paths that were created, or empty list if unavailable.
        """
        from obra.hybrid.handlers.execute import ExecuteHandler

        execute_handler = self._handlers.get(ActionType.EXECUTE)
        if isinstance(execute_handler, ExecuteHandler):
            changes = execute_handler.get_session_file_changes()
            return sorted(changes.added)
        return []

    def _get_modified_files(self) -> list[str]:
        """Get list of files modified during this session.

        FEAT-SESSION-CLOSEOUT-001 S4.T1: Extract modified files for closeout display.

        Returns:
            List of file paths that were modified, or empty list if unavailable.
        """
        from obra.hybrid.handlers.execute import ExecuteHandler

        execute_handler = self._handlers.get(ActionType.EXECUTE)
        if isinstance(execute_handler, ExecuteHandler):
            changes = execute_handler.get_session_file_changes()
            return sorted(changes.modified)
        return []

    def _get_git_branch(self) -> str:
        """Get current git branch name.

        FEAT-SESSION-CLOSEOUT-001 S4.T2: Extract git branch for closeout display.

        Returns:
            Current branch name, or empty string if not in a git repo or on error.
        """
        try:
            result = subprocess.run(
                ["git", "rev-parse", "--abbrev-ref", "HEAD"],
                check=False,
                capture_output=True,
                text=True,
                cwd=self._working_dir,
                timeout=5,
            )
            if result.returncode == 0:
                return result.stdout.strip()
        except (
            subprocess.CalledProcessError,
            FileNotFoundError,
            subprocess.TimeoutExpired,
        ):
            pass
        return ""

    def _get_git_commit(self) -> str:
        """Get current git commit hash.

        FEAT-SESSION-CLOSEOUT-001 S4.T2: Extract git commit for closeout display.

        Returns:
            Current commit hash (short form), or empty string if not in a git repo or on error.
        """
        try:
            result = subprocess.run(
                ["git", "rev-parse", "--short", "HEAD"],
                check=False,
                capture_output=True,
                text=True,
                cwd=self._working_dir,
                timeout=5,
            )
            if result.returncode == 0:
                return result.stdout.strip()
        except (
            subprocess.CalledProcessError,
            FileNotFoundError,
            subprocess.TimeoutExpired,
        ):
            pass
        return ""

    def _extract_work_summary(self) -> list[str]:
        """Extract 2-3 bullet summary of completed work.

        FEAT-SESSION-CLOSEOUT-001 S4.T3: Generate human-readable work summary.

        Returns:
            List of 2-3 strings summarizing completed work, or empty list.
        """
        summary: list[str] = []

        # Extract from last derivation plan items that were completed
        if self._last_derivation_plan_items and self._locally_completed_items:
            for item in self._last_derivation_plan_items:
                item_id = item.get("item_id") or item.get("id", "")
                if item_id in self._locally_completed_items:
                    # Use title or description
                    title = item.get("title") or item.get("description", "")
                    if title and len(summary) < 3:
                        # Truncate long titles
                        if len(title) > 80:
                            title = title[:77] + "..."
                        summary.append(title)

        # If no items from plan, use items_completed count
        if not summary and self._items_completed_this_invocation > 0:
            summary.append(f"Completed {self._items_completed_this_invocation} item(s)")

        return summary

    def create_monitoring_context(
        self,
        task_id: str | None = None,
        liveness_interval: int = 180,
    ) -> dict[str, Any] | None:
        """Create monitoring context dict for subprocess operations.

        ADR-043 Phase 3: Helper factory to simplify monitoring context construction.
        Returns dict compatible with MonitoringThread initialization.

        Args:
            task_id: Optional task ID for monitoring context (agent operations)
            liveness_interval: Liveness check interval in seconds (default: 180s)

        Returns:
            Monitoring context dict with keys: config, workspace_path, event_logger, session_id
            Returns None if session_id not available

        Usage:
            context = orchestrator.create_monitoring_context(task_id="T-001")
            handler = DeriveHandler(..., monitoring_context=context)
        """
        if not self._session_id:
            return None

        return {
            "config": {
                "orchestration": {
                    "monitoring": {"enabled": True},
                    "timeouts": {"liveness": {"check_interval_s": liveness_interval}},
                }
            },
            "workspace_path": str(self._working_dir),
            "event_logger": self._event_logger,
            "session_id": self._session_id,
            "task_id": task_id,
        }

    def _log_session_event(self, event_type: str, **kwargs) -> None:
        """Log hybrid session event for observability (ISSUE-SAAS-042).

        Uses HybridEventLogger - the SaaS-spec logger always available in published package.

        Args:
            event_type: Event type (session_started, derivation_started, etc.)
            **kwargs: Event-specific data
        """
        session_id = self._session_id or ""
        if self._trace_id and "trace_id" not in kwargs:
            kwargs["trace_id"] = self._trace_id
        if "component" not in kwargs:
            kwargs["component"] = self._component
        if "project_id" not in kwargs and self._project_id:
            kwargs["project_id"] = self._project_id
        if "project_name" not in kwargs and self._project_name:
            kwargs["project_name"] = self._project_name

        # ISSUE-015: Pop session_id from kwargs to avoid collision
        # Some handlers (like IntentHandler) pass session_id=None in kwargs,
        # which would cause TypeError: multiple values for keyword argument 'session_id'
        kwargs.pop("session_id", None)

        try:
            self._event_logger.log_event(event_type, session_id=session_id, **kwargs)
            # ISSUE-HYBRID-003: Update last event time for watchdog
            self._last_event_time = time.time()
        except Exception as e:
            logger.warning(f"Failed to log hybrid event '{event_type}': {e}")

    def _log_pipeline_completed(self) -> None:
        """Log pipeline completion with total duration if available."""
        if self._pipeline_start_time is None:
            return
        duration_ms = int((time.time() - self._pipeline_start_time) * 1000)
        self._log_session_event(
            "pipeline_completed",
            duration_ms=duration_ms,
            span_id=self._pipeline_span_id,
        )
        self._log_resource_snapshot("pipeline_end")

        # Stop session console logging for feedback system
        try:
            from obra.feedback import stop_session_logging

            stop_session_logging()
            logger.debug("Session console logging stopped")
        except Exception as e:
            logger.warning(f"Failed to stop session console logging: {e}")

    def _cleanup_story0_containers(self) -> None:
        """Cleanup Story 0 Docker containers on session completion."""
        if not self._session_id:
            return
        try:
            from obra.config.loaders import load_layered_config
            from obra.hybrid.handlers.story0 import cleanup_containers

            config = self._config
            if config is None:
                config, _, _ = load_layered_config(include_defaults=True)
                self._config = config
            if not config.get("story0", {}).get("docker", {}).get("cleanup_on_complete", True):
                return
            cleanup_containers(self._session_id)
        except Exception as exc:
            logger.debug("Story 0 cleanup failed: %s", exc)

    def _log_resource_snapshot(self, snapshot_type: str) -> None:
        """Log a resource snapshot via event logger."""
        self._log_session_event("resource_snapshot", snapshot_type=snapshot_type)

    def _check_stall(self) -> None:
        """Check for session stall and raise if detected (ISSUE-HYBRID-003, ISSUE-HYBRID-008).

        Two-tier stall detection:
        1. Normal stall: No handler active + time > stall_timeout_s (ISSUE-HYBRID-003)
        2. Max silent stall: Time > max_silent_seconds, REGARDLESS of handler state (ISSUE-HYBRID-008)

        The max_silent_seconds timeout catches HTTP hangs and other silent failures
        that occur during handler execution when the normal watchdog is suppressed.

        Raises:
            OrchestratorError: If stall detected
        """
        if not self._watchdog_enabled:
            return

        elapsed = time.time() - self._last_event_time

        # ISSUE-HYBRID-008: Check max_silent_seconds FIRST (applies regardless of handler state)
        # This catches HTTP hangs and other silent failures during handler execution
        if elapsed > self._watchdog_max_silent_seconds:
            # Log stall event with handler context before raising
            self._log_session_event(
                "stall_detected",
                elapsed_seconds=elapsed,
                max_silent_seconds=self._watchdog_max_silent_seconds,
                handler_active=self._handler_active,
                during_handler=self._handler_active,
            )
            short_id = self._session_id.split("-")[0] if self._session_id else ""
            msg = (
                f"Session stalled during handler execution: no events for {int(elapsed)}s "
                f"(max_silent_seconds: {self._watchdog_max_silent_seconds}s). "
                "This may indicate HTTP connection hang or subprocess failure. "
                "Check hybrid.jsonl for last event."
                f"\n\nSession may be stuck. Try: {get_message('recovery.session.force_complete', short_id=short_id)}"
            )
            logger.error(msg)
            raise OrchestratorError(
                msg,
                session_id=self._session_id or "",
            )

        # ISSUE-HYBRID-003: Original stall check (only when handler NOT active)
        if self._handler_active:
            # Handler is running and within max_silent_seconds - don't check normal timeout
            # The handler's LLM calls have their own monitoring (MonitoringThread)
            return

        if elapsed > self._watchdog_stall_timeout:
            # Log stall event before raising
            self._log_session_event(
                "stall_detected",
                elapsed_seconds=elapsed,
                stall_timeout_s=self._watchdog_stall_timeout,
                handler_active=False,
            )
            short_id = self._session_id.split("-")[0] if self._session_id else ""
            msg = (
                f"Session stalled: no progress for {int(elapsed)}s "
                f"(threshold: {self._watchdog_stall_timeout}s). "
                "Check hybrid.jsonl for last event."
                f"\n\nSession may be stuck. Try: {get_message('recovery.session.force_complete', short_id=short_id)}"
            )
            logger.error(msg)
            raise OrchestratorError(
                msg,
                session_id=self._session_id or "",
            )

    def _check_cli_cache_health(self, check_type: str = "pre_session") -> None:
        """Check CLI tool cache directories and log warnings.

        CLI-CACHE-MONITOR-001: Monitor cache sizes to detect potential resource
        exhaustion during long coding sessions.

        Args:
            check_type: Type of check (pre_session, mid_session).
        """
        try:
            monitor = CLICacheMonitor(
                warn_threshold_mb=500,
                critical_threshold_mb=1000,
            )
            warnings = monitor.check_and_warn()

            for warning in warnings:
                # Log to production log for crash analysis
                self._log_session_event(
                    "cli_cache_warning",
                    check_type=check_type,
                    tool=warning.tool,
                    cache_path=warning.path,
                    size_mb=warning.size_mb,
                    threshold_mb=warning.threshold_mb,
                    severity=warning.severity,
                    message=warning.message,
                )

                # Also print to console for immediate visibility
                if warning.severity == "critical":
                    print_warning(
                        f"CRITICAL: {warning.tool.capitalize()} cache is {warning.size_mb:.0f}MB. "
                        f"Risk of resource exhaustion!"
                    )
                else:
                    print_warning(
                        f"{warning.tool.capitalize()} cache is large ({warning.size_mb:.0f}MB). "
                        f"Consider cleanup if session becomes unstable."
                    )
        except Exception as e:
            # Never let cache monitoring interrupt the main workflow
            logger.debug("CLI cache health check failed: %s", e)

    def _with_graceful_degradation(
        self,
        operation_name: str,
        operation: Callable[[], Any],
        default_result: Any,
    ) -> Any:
        """Execute operation with graceful degradation on failure.

        FEAT-RESILIENCE-P2-001: Graceful degradation wrapper for non-critical operations.
        Use this for operations like metrics emission and optional logging where failures
        should not abort the session.

        Args:
            operation_name: Name of the operation for logging
            operation: Callable that performs the operation
            default_result: Value to return if operation fails

        Returns:
            Result of operation if successful, otherwise default_result

        Example:
            >>> result = self._with_graceful_degradation(
            ...     "emit_metrics",
            ...     lambda: self._emit_quality_metrics(scores),
            ...     default_result=None
            ... )
        """
        try:
            return operation()
        except Exception as e:
            logger.warning("Operation %s failed in degraded mode: %s", operation_name, str(e))
            self._degraded_mode = True
            return default_result

    def _start_subphase(self, subphase: str) -> float:
        """Start a subphase span and return its start time."""
        self._subphase_span_id = uuid.uuid4().hex
        self._log_session_event(
            "subphase_started",
            subphase=subphase,
            span_id=self._subphase_span_id,
            parent_span_id=self._phase_span_id,
        )
        return time.time()

    def _complete_subphase(
        self,
        subphase: str,
        start_time: float,
        status: str = "success",
        error_message: str | None = None,
    ) -> None:
        """Complete subphase span with duration and status."""
        duration_ms = int((time.time() - start_time) * 1000)
        self._log_session_event(
            "subphase_completed",
            subphase=subphase,
            duration_ms=duration_ms,
            status=status,
            error_message=error_message,
            span_id=self._subphase_span_id,
            parent_span_id=self._phase_span_id,
        )
        self._subphase_span_id = None

    def _request_with_observability(
        self,
        method: str,
        endpoint: str,
        json: dict[str, Any] | None = None,
        response_schema: type[BaseModel] | None = None,
    ) -> dict[str, Any]:
        """Make API request with observability timing events."""
        request_id = uuid.uuid4().hex
        start_time = time.time()
        start_monotonic = time.perf_counter()
        start_dt = datetime.now(UTC)
        start_iso = start_dt.isoformat()
        parent_span_id = self._subphase_span_id or self._phase_span_id or self._pipeline_span_id
        self._log_session_event(
            "client_request_started",
            request_id=request_id,
            endpoint=endpoint,
            method=method,
            client_request_start_ts=start_iso,
            span_id=self._pipeline_span_id,
            parent_span_id=parent_span_id,
        )
        try:
            response = self._client._request(
                method,
                endpoint,
                json=json,
                response_schema=response_schema,
                request_id=request_id,
                client_request_start_ts=start_time,
            )
            status = "success"
            return cast(dict[str, Any], response)
        except Exception as e:
            status = "error"
            error_message = str(e)
            # Compute response_ts from start_dt + monotonic duration to avoid
            # wall-clock sensitivity (NTP adjustments can invert timestamps).
            duration_s = time.perf_counter() - start_monotonic
            response_ts = (start_dt + timedelta(seconds=duration_s)).isoformat()
            self._log_session_event(
                "client_request_completed",
                request_id=request_id,
                endpoint=endpoint,
                method=method,
                client_request_start_ts=start_iso,
                client_response_ts=response_ts,
                duration_ms=max(0, int(duration_s * 1000)),
                status=status,
                error_class=type(e).__name__,
                error_message=error_message,
                span_id=self._pipeline_span_id,
                parent_span_id=parent_span_id,
            )
            # Attach error context to ObraError instances for debugging
            from obra.exceptions import ObraError

            if isinstance(e, ObraError) and not getattr(e, "error_context", None):
                e.error_context = self._build_error_context(action=endpoint)
            raise
        finally:
            if status == "success":
                # Compute response_ts from start_dt + monotonic duration to
                # guarantee response_ts >= start_ts regardless of clock skew.
                duration_s = time.perf_counter() - start_monotonic
                response_ts = (start_dt + timedelta(seconds=duration_s)).isoformat()
                self._log_session_event(
                    "client_request_completed",
                    request_id=request_id,
                    endpoint=endpoint,
                    method=method,
                    client_request_start_ts=start_iso,
                    client_response_ts=response_ts,
                    duration_ms=max(0, int(duration_s * 1000)),
                    status=status,
                    span_id=self._pipeline_span_id,
                    parent_span_id=parent_span_id,
                )

    @classmethod
    def from_config(
        cls,
        working_dir: Path | None = None,
        on_progress: Callable[[str, dict[str, Any]], None] | None = None,
        on_escalation: Callable[[EscalationNotice], EscalationDecision] | None = None,
        on_stream: Callable[[str, str], None] | None = None,
        impl_provider: str | None = None,
        impl_model: str | None = None,
        thinking_level: str | None = None,
        review_config: ReviewConfig | None = None,
        bypass_modes: list[str] | None = None,
        defaults_json: bool = False,
        observability_config: ObservabilityConfig | None = None,
        progress_emitter: ProgressEmitter | None = None,
        skip_git_check: bool | None = None,
        auto_init_git: bool | None = None,
        planning_mode: str | None = None,
    ) -> HybridOrchestrator:
        """Create HybridOrchestrator from configuration.

        Loads APIClient from ~/.obra/config-layers/01-user.yaml.

        Args:
            working_dir: Working directory for file operations
            on_progress: Optional progress callback
            on_escalation: Optional escalation callback
            on_stream: Optional streaming callback for LLM output
            impl_provider: Optional implementation provider override (S5.T1)
            impl_model: Optional implementation model override (S5.T1)
            thinking_level: Optional thinking level override (S5.T1)
            review_config: Optional review configuration to pass to handlers
            bypass_modes: Optional list of validation modes to bypass
            defaults_json: Whether to output JSON defaults
            observability_config: Optional observability configuration for progress visibility
            progress_emitter: Optional progress emitter for heartbeat and file events
            skip_git_check: Optional CLI flag to skip git validation (overrides config)
            auto_init_git: Optional CLI flag to auto-init git (overrides config)
            planning_mode: Optional planning mode override (auto, quick, standard, thorough)

        Returns:
            Configured HybridOrchestrator

        Raises:
            ConfigurationError: If configuration is invalid or missing
        """
        try:
            client = APIClient.from_config()
        except ConfigurationError:
            raise
        except Exception as e:
            msg = f"Failed to create API client: {e}"
            raise ConfigurationError(msg) from e

        # S5.T2: Resolve LLM config with overrides
        from obra.config import resolve_llm_config

        llm_config = resolve_llm_config(
            role="implementation",
            override_provider=impl_provider,
            override_model=impl_model,
            override_thinking_level=thinking_level,
            override_skip_git_check=skip_git_check,
            override_auto_init_git=auto_init_git,
        )

        orchestrator = cls(
            client=client,
            working_dir=working_dir,
            on_progress=on_progress,
            on_escalation=on_escalation,
            on_stream=on_stream,
            review_config=review_config,
            defaults_json=defaults_json,
            observability_config=observability_config,
            progress_emitter=progress_emitter,
        )

        # S5.T2: Store resolved config for handler creation
        orchestrator._llm_config = llm_config
        orchestrator._bypass_modes = bypass_modes or []
        # FEAT-COMPLEXITY-ROUTING-001: Store planning mode for DeriveHandler
        orchestrator._planning_mode = planning_mode

        # FEAT-PROCESS-LIFECYCLE-001: Initialize process registry for subprocess cleanup
        # Uses factory function to respect orchestration.process_cleanup config
        from obra.config.loaders import load_layered_config

        config, _, _ = load_layered_config(include_defaults=True)
        orchestrator._config = config
        story0_config = config.get("story0", {})
        if story0_config.get("docker", {}).get("orphan_check_on_start", True):
            try:
                from obra.hybrid.handlers.story0 import check_orphaned_containers

                check_orphaned_containers(is_tty=sys.stdin.isatty())
            except Exception as exc:
                logger.debug("Story 0 orphan check failed: %s", exc)

        orchestrator._process_registry = create_process_registry_from_config(config)
        if orchestrator._process_registry:
            orchestrator._process_registry.install_signal_handlers()
            orchestrator._process_registry.register_atexit()
            logger.debug("ProcessRegistry initialized for subprocess lifecycle management")

        return orchestrator

    @property
    def client(self) -> APIClient:
        """Get the API client."""
        return self._client

    @property
    def working_dir(self) -> Path:
        """Get the working directory."""
        return self._working_dir

    @property
    def session_id(self) -> str | None:
        """Get the current session ID."""
        return self._session_id

    @property
    def degraded_mode(self) -> bool:
        """Check if orchestrator is running in degraded mode.

        Returns:
            True if non-critical operations have failed and degraded mode is active.
        """
        return self._degraded_mode

    def is_online(self) -> bool:
        """Check if the server is reachable.

        Returns:
            True if server is reachable, False otherwise.
        """
        try:
            self._client.health_check()
            return True
        except ConnectionError as e:
            logger.warning("Health check failed: Network connectivity issue - %s", e)
            return False
        except AuthenticationError as e:
            logger.warning("Health check failed: Authentication error - %s", e)
            return False
        except ConfigurationError as e:
            logger.warning("Health check failed: Configuration error - %s", e)
            return False
        except APIError as e:
            if e.status_code == HTTPStatus.UNAUTHORIZED.value:
                logger.warning("Health check failed: Authentication invalid (401) - %s", e)
            elif e.status_code == HTTPStatus.FORBIDDEN.value:
                logger.warning("Health check failed: Access forbidden (403) - %s", e)
            else:
                logger.warning(
                    "Health check failed: API error (status %s) - %s",
                    e.status_code or "unknown",
                    e,
                )
            return False
        except Exception as e:
            logger.warning(
                "Health check failed: Unexpected error (%s) - %s",
                type(e).__name__,
                e,
            )
            return False

    def _refresh_server_review_capabilities(self, version_info: Any) -> None:
        """Refresh server-supported review agent types from version metadata."""
        fallback = set(DEFAULT_REPORT_REVIEW_AGENT_TYPES)
        if not isinstance(version_info, dict):
            self._server_review_agent_types = fallback
            return

        raw_agent_types: Any = None
        capabilities = version_info.get("capabilities", {})
        if isinstance(capabilities, dict):
            report_review = capabilities.get("report_review", {})
            if isinstance(report_review, dict):
                raw_agent_types = report_review.get("agent_types")

        if not isinstance(raw_agent_types, list):
            self._server_review_agent_types = fallback
            return

        valid_types = {agent.value for agent in AgentType if agent != AgentType.CODE_VERIFY}
        normalized = {
            str(agent).strip()
            for agent in raw_agent_types
            if isinstance(agent, str) and str(agent).strip() in valid_types
        }
        self._server_review_agent_types = normalized or fallback

    def _ordered_supported_review_agents(self) -> list[str]:
        """Return server-supported review agents in stable protocol order."""
        ordered = [
            agent
            for agent in DEFAULT_REVIEW_AGENTS
            if agent in self._server_review_agent_types
        ]
        if ordered:
            return ordered
        return list(DEFAULT_REPORT_REVIEW_AGENT_TYPES)

    def _sanitize_review_agents_for_server(
        self, candidate_agents: list[str] | None
    ) -> tuple[list[str], list[str]]:
        """Filter review agents to those accepted by the current server."""
        supported = set(self._ordered_supported_review_agents())
        if not candidate_agents:
            return self._ordered_supported_review_agents(), []

        sanitized: list[str] = []
        dropped: list[str] = []
        seen: set[str] = set()

        for agent in candidate_agents:
            normalized = str(agent).strip()
            if not normalized or normalized in seen:
                continue
            seen.add(normalized)
            if normalized in supported:
                sanitized.append(normalized)
            else:
                dropped.append(normalized)

        if sanitized:
            return sanitized, dropped
        return self._ordered_supported_review_agents(), dropped

    def _ensure_online(self) -> None:
        """Ensure server is reachable.

        Raises:
            ConnectionError: If server is not reachable
            APIError: If client version is unsupported by server policy
        """
        if not self.is_online():
            raise ConnectionError()
        # Fail fast on incompatible client versions before session bootstrap.
        version_info = self._client.assert_client_version_supported()
        self._refresh_server_review_capabilities(version_info)

    def _hash_working_dir(self) -> str:
        """Create SHA256 hash of working directory path.

        Returns:
            SHA256 hex digest of working directory path
        """
        return hashlib.sha256(str(self._working_dir).encode()).hexdigest()

    def _resolve_quality_policy_mode(self) -> str | None:
        """Resolve quality policy mode from config for SessionStart payload.

        Returns None when mode is 'auto' (default) to keep payload minimal
        for backward compatibility with older servers.

        Returns:
            Policy mode string if not auto, None otherwise
        """
        from obra.config.loaders import get_quality_policy_mode

        mode = get_quality_policy_mode()
        return mode if mode != "auto" else None

    def _build_effective_llm_map(self) -> dict[str, dict[str, str]]:
        """Build the effective LLM map from role-based config resolution.

        For each pipeline stage, resolves provider/model/tier/thinking_level
        using the role-based config system (ADR-069). Agent overrides are
        included only when they differ from their parent review stage.

        Returns:
            Dict keyed by stage/agent name with provider, model, tier, thinking_level.
        """
        effective_map: dict[str, dict[str, str]] = {}

        # Resolve per-stage config
        stages = ["derive", "examine", "revise", "execute", "fix", "review"]
        for stage in stages:
            config = resolve_role_llm_config(stage)
            provider = config.get("provider", "anthropic")
            model = config.get("model", "")
            tier = resolve_quality_tier(provider, model)
            thinking = config.get("thinking_level", "medium")
            effective_map[stage] = {
                "provider": provider,
                "model": model,
                "tier": tier,
                "thinking_level": thinking,
            }

        # Check agent overrides for review agents
        review_entry = effective_map.get("review", {})
        agent_names = ["sense_check", "code_quality", "test_execution"]
        for agent in agent_names:
            try:
                agent_config = resolve_action_llm_config(agent)
                agent_provider = agent_config.get("provider", "anthropic")
                agent_model = agent_config.get("model", "")
                # Only include if different from parent review stage
                if (
                    agent_provider != review_entry.get("provider")
                    or agent_model != review_entry.get("model")
                ):
                    agent_tier = resolve_quality_tier(agent_provider, agent_model)
                    agent_thinking = agent_config.get("thinking_level", "medium")
                    effective_map[agent] = {
                        "provider": agent_provider,
                        "model": agent_model,
                        "tier": agent_tier,
                        "thinking_level": agent_thinking,
                    }
            except Exception:
                # Agent config resolution failure is non-fatal
                logger.debug("Skipping agent override for %s", agent)

        return effective_map

    def _run_provider_preflight(
        self, effective_map: dict[str, dict[str, str]]
    ) -> dict[str, dict[str, str | None]]:
        """Run preflight checks for unique providers and provider+model pairs.

        Args:
            effective_map: The effective LLM map.

        Returns:
            Dict keyed by provider name with status and error info.

        Raises:
            OrchestratorError: If any provider fails preflight checks.
        """
        from obra.config.providers import (
            validate_provider_model_ready,
            validate_provider_ready,
        )
        from obra.exceptions import ConfigurationError

        providers = {entry["provider"] for entry in effective_map.values()}
        provider_model_pairs = {
            (entry["provider"], entry.get("model", ""))
            for entry in effective_map.values()
        }
        results: dict[str, dict[str, str | None]] = {}
        failures: list[str] = []
        auth_method = "oauth"
        run_model_probe = isinstance(self._llm_config, dict)
        if run_model_probe and isinstance(self._llm_config, dict):
            auth_method = str(self._llm_config.get("auth_method", "oauth"))

        for provider in sorted(providers):
            try:
                validate_provider_ready(provider)
                results[provider] = {"status": "ok", "error": None}
            except (ConfigurationError, Exception) as e:
                results[provider] = {"status": "failed", "error": str(e)}
                failures.append(f"{provider} ({e})")

        if run_model_probe:
            for provider, model in sorted(provider_model_pairs):
                try:
                    validate_provider_model_ready(
                        provider,
                        model,
                        auth_method=auth_method,
                        cwd=self._working_dir,
                    )
                except (ConfigurationError, Exception) as e:
                    results[provider] = {"status": "failed", "error": str(e)}
                    failures.append(f"{provider}:{model} ({e})")

        if failures:
            raise OrchestratorError(
                f"Provider preflight failed: {', '.join(failures)}",
                error_context=self._build_error_context(action="provider_preflight"),
            )

        return results

    @property
    def effective_llm_map(self) -> dict[str, dict[str, str]]:
        """The effective LLM map built during session initialization."""
        return getattr(self, "_effective_llm_map", {})

    @property
    def preflight_results(self) -> dict[str, dict[str, str | None]]:
        """Provider preflight check results."""
        return getattr(self, "_preflight_results", {})

    def _emit_runtime_banner(self) -> None:
        """Emit a one-line banner showing backend target and log file paths.

        Helps operators verify whether the session is hitting the emulator
        or production, and where to find telemetry files.
        """
        import os

        runtime_dir = get_runtime_dir()
        hybrid_log = runtime_dir / "logs" / "hybrid.jsonl"
        production_log = runtime_dir / "logs" / "production.jsonl"
        api_url = os.environ.get("OBRA_API_BASE_URL", "")
        backend = api_url if api_url else "production"

        console.print(f"Backend: [cyan]{backend}[/cyan]")
        console.print(
            f"Logs: [dim]{hybrid_log}[/dim]  |  [dim]{production_log}[/dim]"
        )

    def _emit_llm_pipeline_banner(
        self,
        effective_map: dict[str, dict[str, str]],
        server_validation: dict[str, dict[str, Any]],
    ) -> None:
        """Emit the full LLM Pipeline Models banner post-session.

        Called after server validation completes so all indicators have real data.
        Uses preflight results from CLI (stored as _cli_preflight_results) and
        the server validation from the session start response.
        """
        import os

        from obra.cli import _format_llm_banner, _format_quality_policy_lines
        from obra.config.loaders import get_quality_policy_mode

        preflight_results = getattr(self, "_cli_preflight_results", self._preflight_results)
        verbose = getattr(self, "_cli_verbose", 0)

        console.print()
        console.print("LLM Pipeline Models")
        banner_lines = _format_llm_banner(
            effective_map, preflight_results, server_validation, verbose
        )
        for line in banner_lines:
            console.print(line)

        # Quality policy: show model tier and effective policy tier

        impl_tier = effective_map.get("execute", {}).get("tier", "medium")
        try:
            policy_mode = get_quality_policy_mode()
        except Exception:
            policy_mode = "auto"

        effective_tier = impl_tier if policy_mode == "auto" else policy_mode

        for line in _format_quality_policy_lines(impl_tier, policy_mode):
            console.print(f"[dim]{line}[/dim]")

        # Tier behavior note
        suppress_tier_info = os.environ.get(
            "OBRA_SUPPRESS_TIER_INFO", ""
        ).lower() in ("1", "true")
        if effective_tier == "fast" and not suppress_tier_info:
            console.print(
                "[dim]Note: Fast quality policy - relaxed quality gates "
                "(1 iteration, auto-permissive)[/dim]"
            )
            if verbose > 0:
                console.print(
                    "[dim]  Compared to medium tier: 3 iterations, P1 issues block[/dim]"
                )
                console.print(
                    "[dim]  Compared to high tier: 5 iterations, strict quality gates[/dim]"
                )

    def _get_role_llm_config(self, action: ActionType) -> dict[str, Any]:
        """Get LLM config for a handler action using role-based resolution.

        This method implements ADR-069 role-based LLM configuration, allowing
        different handlers to use different LLM settings based on configuration.

        Resolution order:
        1. llm.roles.<role> - explicit role configuration
        2. llm.profiles.<profile> - if role references a profile
        3. Default mapping (derive->orchestrator, execute->implementation)
        4. Fallback to stored _llm_config (backward compatibility)

        Args:
            action: The ActionType for which to resolve config

        Returns:
            Resolved LLM config dict with provider, model, thinking_level, etc.

        See:
            docs/decisions/ADR-069-role-based-llm-configuration.md
        """
        role = ACTION_TO_ROLE.get(action)
        if role is None:
            logger.warning(
                "No role mapping for action %s, using stored llm_config",
                action.value,
            )
            return self._llm_config or {}

        # Resolve config using role-based resolution
        # This checks llm.roles.<role> and llm.profiles.<profile>.
        resolved = resolve_role_llm_config(role)

        # Merge with any session-level overrides from _llm_config
        # (e.g., CLI flags like --provider, --model)
        if self._llm_config:
            # Git and codex configs are session-level, not role-level
            for key in ("git", "codex"):
                if key in self._llm_config and key not in resolved:
                    resolved[key] = self._llm_config[key]

        logger.debug(
            "Resolved LLM config for action %s (role=%s): provider=%s, model=%s",
            action.value,
            role,
            resolved.get("provider"),
            resolved.get("model"),
        )

        return resolved

    def _get_review_config(self) -> dict[str, Any] | None:
        """Get LLM config for review agents.

        Uses config-wired model_tier (handlers.review.model_tier, default: high)
        with implementation role tier resolution.

        Returns:
            LLM config dict if available, None otherwise.
        """
        from obra.config.loaders import get_review_model_tier

        tier = get_review_model_tier()
        tier_config = resolve_action_llm_config("review", model_tier=tier)

        # Merge with session-level overrides (git, codex)
        resolved = {
            "provider": tier_config.get("provider", "anthropic"),
            "model": tier_config.get("model"),
            "auth_method": tier_config.get("auth_method", "oauth"),
            "thinking_level": tier_config.get("thinking_level", "medium"),
        }
        if self._llm_config:
            for key in ("git", "codex"):
                if key in self._llm_config and key not in resolved:
                    resolved[key] = self._llm_config[key]

        logger.debug(
            "Resolved review config: tier=%s, provider=%s, model=%s",
            tier,
            resolved.get("provider"),
            resolved.get("model"),
        )

        return resolved

    def _get_project_context(self) -> dict[str, Any]:
        """Gather minimal project context (no code content).

        Returns:
            Dictionary with project context (languages, frameworks, etc.)
        """
        context: dict[str, Any] = {
            "languages": [],
            "frameworks": [],
            "has_tests": False,
            "file_count": 0,
        }

        # Prefer discovery cache when available (language-agnostic)
        tooling_context: dict[str, Any] = {}
        try:
            from obra.config.loaders import (
                get_verification_discovery_enabled,
                get_verification_force_refresh,
            )
            from obra.hybrid.tooling_discovery import ToolingDiscovery

            if get_verification_discovery_enabled():
                discovery = ToolingDiscovery(self._working_dir, self._llm_config or {})
                tooling_context = discovery.discover(force_refresh=get_verification_force_refresh())
        except Exception:
            tooling_context = {}

        if tooling_context:
            languages = tooling_context.get("languages", {})
            if isinstance(languages, dict):
                primary = languages.get("primary")
                secondary = languages.get("secondary", [])
                detected = []
                if primary:
                    detected.append(primary)
                if isinstance(secondary, list):
                    detected.extend(secondary)
                context["languages"] = list({lang for lang in detected if lang})

            verification = tooling_context.get("verification", {})
            if isinstance(verification, dict):
                test_cfg = verification.get("test", {})
                if isinstance(test_cfg, dict) and test_cfg.get("command"):
                    context["has_tests"] = True

        # Detect languages by file extensions
        extensions = set()
        file_count = 0
        try:
            for path in self._working_dir.rglob("*"):
                if path.is_file() and not any(part.startswith(".") for part in path.parts):
                    file_count += 1
                    if path.suffix:
                        extensions.add(path.suffix.lower())
        except Exception:
            pass  # Permission errors, etc.

        context["file_count"] = file_count

        # Map extensions to languages
        ext_to_lang = {
            ".py": "python",
            ".js": "javascript",
            ".ts": "typescript",
            ".tsx": "typescript",
            ".jsx": "javascript",
            ".go": "go",
            ".rs": "rust",
            ".java": "java",
            ".rb": "ruby",
            ".php": "php",
            ".cs": "csharp",
            ".cpp": "cpp",
            ".c": "c",
        }
        if not context["languages"]:
            context["languages"] = list(
                {ext_to_lang.get(ext) for ext in extensions if ext in ext_to_lang}
            )

        # Detect common test directories
        test_dirs = ["tests", "test", "__tests__", "spec"]
        if not context["has_tests"]:
            context["has_tests"] = any((self._working_dir / d).is_dir() for d in test_dirs)

        # Detect frameworks by config files
        framework_files = {
            "package.json": ["node"],
            "requirements.txt": ["python"],
            "pyproject.toml": ["python"],
            "Cargo.toml": ["rust"],
            "go.mod": ["go"],
            "pom.xml": ["java", "maven"],
            "build.gradle": ["java", "gradle"],
            "Gemfile": ["ruby"],
            "composer.json": ["php"],
        }
        for filename, frameworks in framework_files.items():
            if (self._working_dir / filename).exists():
                context["frameworks"].extend(frameworks)

        context["frameworks"] = list(set(context["frameworks"]))

        # Include SenseCheck pipeline config for server-side validation
        # FEAT-SENSECHECK-PIPELINE-001: Pass client config to server
        try:
            from obra.config.loaders import load_layered_config

            config, _, _ = load_layered_config()
            sense_check_pipeline = (
                config.get("review", {}).get("sense_check", {}).get("pipeline", {})
            )
            if sense_check_pipeline:
                context["config"] = {
                    "review": {
                        "sense_check": {
                            "pipeline": sense_check_pipeline,
                        }
                    }
                }
        except Exception:
            pass  # Config loading failure is non-fatal

        return context

    def _emit_progress(self, action: str, payload: dict[str, Any]) -> None:
        """Emit progress update.

        Args:
            action: Action being performed
            payload: Action payload
        """
        if self._on_progress:
            try:
                self._on_progress(action, payload)
            except Exception as e:
                logger.warning(
                    f"Progress callback failed for action '{action}': {e}",
                    exc_info=True,
                )

    def _handle_session_timeout_warning(self, runtime_hours: float, warning_count: int) -> bool:
        """Handle session timeout warning prompt.

        FEAT-SESSION-GUARD-001: Called when session exceeds warning threshold.
        User input resets the timer for another warning period.

        Args:
            runtime_hours: Current runtime in hours
            warning_count: Number of times user has been warned

        Returns:
            True to continue session, False to terminate
        """
        import sys

        # Log the warning event
        self._log_session_event(
            "session_runtime_warning",
            runtime_hours=runtime_hours,
            warning_count=warning_count,
            items_completed=self._items_completed_this_invocation,
            phase=self._current_phase.value if self._current_phase else "unknown",
        )

        # Non-interactive mode: auto-continue with warning
        if not sys.stdin.isatty():
            logger.warning(
                f"Session {self._session_id} running for {runtime_hours:.1f}h "
                f"in non-interactive mode, auto-continuing"
            )
            return True

        # Interactive prompt
        print()
        console.print(f"[yellow]Session has been running for {runtime_hours:.1f} hours.[/yellow]")
        console.print(f"Items completed: {self._items_completed_this_invocation}")
        if self._current_phase:
            console.print(f"Current phase: {self._current_phase.value}")
        print()

        try:
            from obra.display.prompting import prompt_input

            response = prompt_input("Continue session? [Y/n]: ").strip().lower()
            if response in ("", "y", "yes"):
                console.print("[green]Continuing session...[/green]")
                # Record user activity to reset warning timer
                if self._session_guard:
                    self._session_guard.record_user_activity()
                return True
            else:
                console.print("[dim]Stopping session...[/dim]")
                return False
        except (EOFError, KeyboardInterrupt):
            console.print("\n[dim]Stopping session...[/dim]")
            return False

    def _update_session_guard(self) -> None:
        """Update session guard with current progress.

        FEAT-SESSION-GUARD-001: Called after each action to track progress.
        """
        if self._session_guard:
            self._session_guard.update(
                items_completed=self._items_completed_this_invocation,
                phase=self._current_phase.value if self._current_phase else "unknown",
            )

    def _display_bypass_notices(self, server_action: ServerAction) -> None:
        """Render bypass-related warnings for the current action.

        Modes are classified by severity:
        - Safety overrides (in _SAFETY_OVERRIDE_MODES) → Warning, deduped per phase
        - Informational modes (everything else) → Info, deduped globally (once per session)
        """
        active_bypass_modes = list(server_action.bypass_modes_active or [])
        if active_bypass_modes:
            phase_label = self._current_phase.value if self._current_phase else "unknown"

            # Classify by severity
            safety_overrides = [m for m in active_bypass_modes if m in _SAFETY_OVERRIDE_MODES]
            info_modes = [m for m in active_bypass_modes if m not in _SAFETY_OVERRIDE_MODES]

            # Safety overrides → Warning (per-phase dedup, prominent)
            if safety_overrides:
                notice_key = f"{phase_label}|safety|{','.join(sorted(safety_overrides))}"
                if notice_key not in self._bypass_notice_keys:
                    self._bypass_notice_keys.add(notice_key)
                    print_warning(f"Bypass modes active: {', '.join(safety_overrides)}")
                    permissive_modes = {"planning_permissive", "permissive_planning", "permissive"}
                    if any(mode in permissive_modes for mode in safety_overrides):
                        console.print(
                            "  Permissive mode may relax P1 blocking, strict quality thresholds, and escalation safeguards."
                        )
                    else:
                        console.print("  Results may not reflect production behavior.")

            # Informational modes → Info (session-global dedup, quiet)
            if info_modes:
                notice_key = f"info|{','.join(sorted(info_modes))}"
                if notice_key not in self._bypass_notice_keys:
                    self._bypass_notice_keys.add(notice_key)
                    print_info(f"Session modes: {', '.join(info_modes)}")

        bypassed_p1 = None
        if isinstance(server_action.metadata, dict):
            bypassed_p1 = server_action.metadata.get("bypassed_p1_count")
            bypassed_p1_issues = server_action.metadata.get("bypassed_p1_issues")
        else:
            bypassed_p1_issues = None

        if isinstance(bypassed_p1, int) and bypassed_p1 > 0:
            console.print(f"[yellow]Bypassing {bypassed_p1} P1 issues in permissive mode[/yellow]")
            if self._is_skip_tracking_enabled("permissive_mode") and bypassed_p1_issues:
                for idx, issue in enumerate(bypassed_p1_issues):
                    issue_id = issue.get("id") or f"p1-issue-{idx + 1}"
                    create_skip_record(
                        session_id=self._session_id or "",
                        task_id=str(issue_id),
                        source=SkipSource.PERMISSIVE_MODE,
                        reason=SkipReason.QUALITY_THRESHOLD,
                        description=f"P1 issue bypassed in permissive mode: {issue.get('description', '')}",
                        source_context={"issue": issue},
                    )
                logger.info("Run 'obra skips list' to review skipped items")

        # Validate that requested modes were actually applied (once per session)
        self._validate_bypass_modes_applied(server_action)

    def _validate_bypass_modes_applied(self, server_action: ServerAction) -> list[str]:
        """Check if requested bypass modes were acknowledged by server.

        Warns user if any requested modes were not activated. This helps detect
        bugs where CLI flags are parsed but not transmitted to the server.

        Args:
            server_action: Server response containing bypass_modes_active

        Returns:
            List of modes that were requested but not activated
        """
        # Only validate once per session
        if getattr(self, "_bypass_modes_validated", False):
            return []
        self._bypass_modes_validated = True

        if not self._bypass_modes:
            return []

        active = set(server_action.bypass_modes_active or [])
        requested = set(self._bypass_modes)
        unapplied = requested - active

        if unapplied:
            # Map internal mode names to user-facing flag names
            flag_names = {
                "planning_permissive": "--permissive",
                "no_closeout": "--no-closeout",
                "skip_intent": "--skip-intent",
                "review_intent": "--review-intent",
                "scaffolded": "--scaffolded",
                "no_scaffolded": "--no-scaffolded",
                "skip_quality_check": "--skip-quality-check",
                "skip_complexity_check": "--skip-complexity-check",
                "parallel": "--parallel",
                "skip_explore": "--skip-explore",
                "force_explore": "--force-explore",
            }
            flags = [flag_names.get(m, f"--{m}") for m in sorted(unapplied)]
            print_warning(f"Flags requested but not applied by server: {', '.join(flags)}")
            logger.warning(
                "Bypass mode mismatch: requested=%s, active=%s, unapplied=%s",
                list(requested),
                list(active),
                list(unapplied),
            )

        return list(unapplied)

    def _extract_session_start_contract_warnings(self, metadata: Any) -> list[str]:
        """Extract server-reported SessionStart contract warnings from metadata."""
        if not isinstance(metadata, dict):
            return []
        raw_fields = metadata.get("session_start_unknown_fields")
        if not isinstance(raw_fields, list):
            return []

        fields: list[str] = []
        for value in raw_fields:
            text = str(value).strip()
            if text:
                fields.append(text)
        if not fields:
            return []

        return [
            (
                "Server ignored unknown session-start fields from this client: "
                f"{', '.join(fields)}. "
                "This indicates client/server contract drift; align versions."
            )
        ]

    def _emit_session_start_contract_warnings(self, warnings: list[str]) -> None:
        """Display prominent SessionStart contract warnings."""
        for warning in warnings:
            print_warning(f"API contract warning: {warning}")
            logger.warning("API contract warning: %s", warning)

    def _append_session_start_contract_warnings(
        self, notice: CompletionNotice
    ) -> CompletionNotice:
        """Attach and re-emit SessionStart contract warnings at session end."""
        if not self._session_start_contract_warnings:
            return notice

        existing = set(notice.warnings or [])
        for warning in self._session_start_contract_warnings:
            tagged = f"API contract warning: {warning}"
            if tagged not in existing:
                notice.warnings.append(tagged)
                existing.add(tagged)
            print_warning(f"{tagged} (session end)")
        return notice

    def _is_skip_tracking_enabled(self, source_key: str) -> bool:
        config = self._config or {}
        skip_config = config.get("orchestration", {}).get("skip_tracking", {})
        return bool(skip_config.get("enabled", True)) and bool(
            skip_config.get("sources", {}).get(source_key, True)
        )

    def _should_prompt_for_defaults(self) -> bool:
        """Determine if we should prompt the user for defaults confirmation."""
        if self._defaults_json:
            return False

        return (
            sys.stdin.isatty()
            and os.environ.get("CI") != "true"
            and os.environ.get("OBRA_HEADLESS") != "1"
        )

    def _inject_defaults_into_prompt(
        self,
        base_prompt: str | None,
        defaults: list[dict[str, Any]],
    ) -> str:
        """Append confirmed defaults to the revision prompt."""
        defaults_block = json.dumps(defaults, indent=2)
        prefix = base_prompt or ""
        return (
            f"{prefix}\n\n"
            "# User-confirmed defaults (apply unless overridden)\n"
            "The following defaults were confirmed to unblock refinement. "
            "Incorporate them into the revised plan explicitly:\n"
            f"{defaults_block}\n"
        )

    def _process_proposed_defaults(
        self,
        proposed_defaults: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Render and optionally collect confirmation for proposed defaults.

        Displays each proposed default with a clear, visually distinct prompt
        following standard CLI prompt patterns (FIX-DEFAULTS-PROMPT-UX-001).
        """
        if not proposed_defaults:
            return []

        console.print()
        console.print("[bold]Proposed defaults detected[/bold]")

        if self._defaults_json:
            console.print(json.dumps({"proposed_defaults": proposed_defaults}, indent=2))
            msg = "Defaults exported via --defaults-json; rerun interactively to confirm."
            raise OrchestratorError(
                msg,
                session_id=self._session_id or "",
            )

        should_prompt = self._should_prompt_for_defaults()
        if not should_prompt:
            print_warning("Non-interactive environment detected; auto-accepting proposed defaults.")

        confirmed: list[dict[str, Any]] = []
        for default in proposed_defaults:
            value = default.get("proposed_value", "")
            issue_id = default.get("issue_id", "unknown")
            description = default.get("description", "")
            confidence = default.get("confidence", 0.0)

            # Visually distinct block per default — issue on its own line,
            # proposed value clearly labeled, blank line separator.
            console.print()
            console.print(f"  [bold]Issue {issue_id}[/bold]: {description or value}")
            if description and value != description:
                console.print(f"  [cyan]Proposed[/cyan]: {value}")
            console.print(f"  [dim]Confidence: {confidence:.0%}[/dim]")

            if should_prompt:
                try:
                    from obra.display.prompting import prompt_input

                    user_input = prompt_input(
                        "[bold yellow]?[/bold yellow] Accept, override, or 'skip': ",
                    ).strip()
                except (EOFError, KeyboardInterrupt):
                    user_input = ""

                if user_input.lower() == "skip":
                    continue
                if user_input:
                    default = {
                        **default,
                        "proposed_value": user_input,
                        "rationale": f"User override: {default.get('rationale', 'custom default')}",
                    }

            confirmed.append(default)

        return confirmed

    def _poll_with_backoff(
        self,
        poll_count: int,
        base_delay: float = HYBRID_POLLING_BASE_DELAY_S,
        max_delay: float = HYBRID_POLLING_MAX_DELAY_S,
        multiplier: float = HYBRID_POLLING_BACKOFF_MULTIPLIER,
    ) -> float:
        """Calculate and execute exponential backoff delay for polling.

        Implements exponential backoff: delay = base_delay * (multiplier ^ poll_count)
        capped at max_delay.

        Args:
            poll_count: Current poll iteration (0-indexed)
            base_delay: Initial delay in seconds (default: 1.0)
            max_delay: Maximum delay in seconds (default: 30.0)
            multiplier: Exponential multiplier (default: 2.0)

        Returns:
            The actual delay used in seconds
        """
        import time

        # Calculate delay with exponential backoff: 1, 2, 4, 8, 16, 30, 30...
        delay = min(base_delay * (multiplier**poll_count), max_delay)
        time.sleep(delay)

        logger.debug(f"Polling wait: {delay:.1f}s (poll #{poll_count + 1})")
        return delay

    def _action_to_phase(self, action: ActionType) -> SessionPhase | None:
        """Map action type to session phase.

        Args:
            action: Action type from server

        Returns:
            Corresponding session phase, or None for non-phase actions
        """
        phase_mapping = {
            ActionType.DERIVE: SessionPhase.DERIVATION,
            ActionType.INTENT: SessionPhase.DERIVATION,
            ActionType.STORY0: SessionPhase.STORY0,
            ActionType.STORY_PREFLIGHT: SessionPhase.EXECUTION,
            ActionType.EXAMINE: SessionPhase.REFINEMENT,
            ActionType.REVISE: SessionPhase.REFINEMENT,
            ActionType.EXECUTE: SessionPhase.EXECUTION,
            ActionType.REVIEW: SessionPhase.REVIEW,
        }
        return phase_mapping.get(action)

    def _progress_snapshot(self, action: ActionType | None) -> dict[str, Any]:
        """Capture minimal progress state for stall detection."""
        return {
            "items_completed": self._items_completed_this_invocation,
            "last_item_id": self._last_item_id,
            "phase": self._current_phase.value if self._current_phase else "unknown",
            "action": action.value if action else None,
        }

    def _detect_progress(
        self,
        before: dict[str, Any],
        next_action: ActionType | None,
        result: dict[str, Any],
    ) -> bool:
        """Detect meaningful progress to reset stall iteration counter."""
        if result.get("completed"):
            return True
        if self._items_completed_this_invocation > before["items_completed"]:
            return True
        if self._last_item_id and self._last_item_id != before["last_item_id"]:
            return True
        current_phase = self._current_phase.value if self._current_phase else "unknown"
        if current_phase != before["phase"]:
            return True
        if next_action and before.get("action") and next_action.value != before.get("action"):
            return True
        return False

    def _emit_phase_event(self, action: ActionType) -> None:
        """Emit phase transition events based on action.

        Tracks phase changes and emits phase_started/phase_completed events
        via the on_progress callback.

        Args:
            action: Current action type
        """
        import time

        new_phase = self._action_to_phase(action)
        if new_phase is None:
            return  # Skip non-phase actions (COMPLETE, ESCALATE, etc.)

        # Check if phase changed
        if new_phase != self._current_phase:
            # Emit phase_completed for previous phase
            if self._current_phase is not None and self._phase_start_time is not None:
                duration_ms = int((time.time() - self._phase_start_time) * 1000)
                # FIX-TRACKER-001: Include plan items in DERIVATION phase_completed
                # This enables the CLI tracker to populate all items upfront
                phase_result: dict[str, Any] = {}
                if self._current_phase == SessionPhase.DERIVATION:
                    phase_result = {
                        "item_count": len(self._last_derivation_plan_items),
                        "items": self._last_derivation_plan_items,
                    }
                # Emit refinement summary when refinement phase ends
                if (
                    self._current_phase == SessionPhase.REFINEMENT
                    and self._refinement_cycle_count > 0
                ):
                    refinement_duration_s = 0.0
                    if self._refinement_start_time:
                        refinement_duration_s = time.time() - self._refinement_start_time
                    phase_result["refinement_cycles"] = self._refinement_cycle_count
                    phase_result["refinement_duration_s"] = refinement_duration_s

                self._emit_progress(
                    "phase_completed",
                    {
                        "phase": self._current_phase.value,
                        "duration_ms": duration_ms,
                        "result": phase_result if phase_result else None,
                    },
                )
                # Track locally completed phases to prevent duplicate server-echoed emissions
                self._locally_completed_phases.add(self._current_phase.value)
                # ISSUE-OBS-002: Log phase_completed to production logger
                self._log_session_event(
                    "phase_completed",
                    phase=self._current_phase.value,
                    duration_ms=duration_ms,
                    span_id=self._phase_span_id,
                    parent_span_id=self._pipeline_span_id,
                )
                self._log_resource_snapshot(f"phase_{self._current_phase.value}_end")

            # Emit phase_started for new phase
            self._current_phase = new_phase
            self._phase_start_time = time.time()
            self._phase_span_id = uuid.uuid4().hex
            self._emit_progress(
                "phase_started",
                {
                    "phase": new_phase.value,
                },
            )
            self._locally_started_phases.add(new_phase.value)
            # ISSUE-OBS-002: Log phase_started to production logger
            self._log_session_event(
                "phase_started",
                phase=new_phase.value,
                span_id=self._phase_span_id,
                parent_span_id=self._pipeline_span_id,
            )
            self._log_resource_snapshot(f"phase_{new_phase.value}_start")

    def _git_preflight(self) -> None:
        """Run git repository validation before orchestration begins.

        GIT-HARD-001 Story 2: Git preflight check for hybrid orchestration.

        Validates that the working directory is a git repository before starting
        orchestration. Behavior controlled by llm.git config section.

        Config options:
            llm.git.skip_check (bool): Skip git validation entirely (default: True).
                ISSUE-REVIEW-AGENTS-002: Changed default from False to True since
                Obra now uses FileStateTracker for change detection instead of git.
                Note: auto_init=True overrides skip_check - validation must run to
                detect missing repos before auto-initializing.
            llm.git.auto_init (bool): Auto-initialize git if missing (default: False)

        Exemptions:
            - Inbox projects (working_dir is None) are exempted from validation

        Raises:
            GitValidationError: If not in git repo and auto_init is False

        Task breakdown:
            S2.T0: Method exists and reads config
            S2.T1: Called before first handler dispatch
            S2.T2: Validates working_dir not cwd
            S2.T3: Exempts Inbox projects
            S2.T4: Logs auto-init actions
        """
        # S2.T3: Exempt Inbox projects (no explicit working_dir provided)
        # When working_dir is not explicitly provided (None in constructor),
        # it defaults to cwd but should be treated as an Inbox project
        if not self._working_dir_explicit:
            logger.debug("Git preflight: Skipping (Inbox project - no explicit working_dir)")
            return

        # Get git config settings (with safe defaults)
        git_config = {}
        if self._llm_config:
            git_config = self._llm_config.get("git", {})

        skip_check = git_config.get("skip_check", True)  # ISSUE-REVIEW-AGENTS-002: Default True
        auto_init = git_config.get("auto_init", False)

        # Honor skip_check flag (but auto_init overrides - if user wants auto-init,
        # we must run the check to detect missing repos)
        if skip_check and not auto_init:
            logger.info("Git preflight: Skipping (llm.git.skip_check enabled)")
            return

        # S2.T2: Validate working_dir not cwd
        # Use self._working_dir which is the project working directory
        logger.debug(f"Git preflight: Validating {self._working_dir}")

        # Import git_utils locally to avoid circular imports
        from obra.utils.git_utils import ensure_git_repository

        try:
            # S2.T4: Log auto-init actions (handled by ensure_git_repository)
            # Note: ensure_git_repository logs auto-init at INFO level
            # Pass full config for auto-init safety checks
            ensure_git_repository(self._working_dir, auto_init=auto_init, config=self._llm_config)
            logger.info(f"Git preflight: Passed for {self._working_dir}")
        except Exception:
            logger.exception(f"Git preflight: Failed for {self._working_dir}")
            raise

    def _merge_plan_items_for_rederivation(
        self,
        preserved_items: list[dict[str, Any]],
        newly_derived_items: list[dict[str, Any]],
        from_step: int | None,
    ) -> list[dict[str, Any]]:
        """Merge preserved plan items with newly derived items for --from-step re-derivation.

        When using --from-step N, this method combines:
        - Preserved items for steps 1 to N-1 (unchanged from previous derivation)
        - Newly derived items for steps N onwards (re-derived in current run)

        The preserved items retain their original IDs and content, while newly derived
        items are appended after them to form a complete plan.

        For hierarchical plans, preserved items are filtered to drop only the
        affected subtrees (items derived from source steps >= from_step). Completed
        leaves outside the affected subtree remain intact, along with their parent
        linkage.

        Args:
            preserved_items: Plan items to preserve from previous derivation
                (steps 1 to from_step-1). These items should have userplan_step_index
                in their context to indicate which step they belong to.
            newly_derived_items: Plan items newly derived in this run
                (steps from_step onwards).
            from_step: Step number to re-derive from (1-indexed). If None,
                all items are considered newly derived (no merge needed).

        Returns:
            Merged list of plan items:
            - If from_step is None or 1: returns newly_derived_items unchanged
            - If from_step > 1: returns preserved_items + newly_derived_items
              sorted by userplan_step_index to maintain correct ordering

        Example:
            # Re-derive from step 3:
            # preserved_items = [items for steps 1, 2]
            # newly_derived_items = [items for steps 3, 4, 5]
            # result = [step1_items, step2_items, step3_items, step4_items, step5_items]
        """
        # No merge needed if from_step is None or 1 (full derivation)
        if from_step is None or from_step <= 1:
            return newly_derived_items

        # No preserved items means this is effectively a full derivation
        if not preserved_items:
            logger.info(
                f"No preserved items for --from-step {from_step}, "
                f"returning {len(newly_derived_items)} newly derived items"
            )
            return newly_derived_items

        preserved_items = self._mark_rederived_parents_stale(
            preserved_items,
            from_step=from_step,
        )
        preserved_items = self._filter_preserved_items_for_rederivation(
            preserved_items,
            from_step=from_step,
        )

        # Merge preserved items with newly derived items (preserved first)
        merged_items = list(preserved_items) + list(newly_derived_items)
        merged_items = self._recompute_parent_statuses(merged_items)

        logger.info(
            f"Merged plan items for --from-step {from_step}: "
            f"{len(preserved_items)} preserved + {len(newly_derived_items)} newly derived = "
            f"{len(merged_items)} total items"
        )

        return merged_items

    @staticmethod
    def _compute_dependency_graph_hash(plan_items: list[dict[str, Any]]) -> str:
        """Compute SHA256 of the dependency graph for C9 validation caching.

        Extracts (item_id, sorted(dependencies)) for all items, sorts by
        item_id, JSON-serializes, and returns hex digest.
        """
        import hashlib
        import json as _json

        edges: list[tuple[str, list[str]]] = []
        for item in plan_items:
            item_id = item.get("id", "")
            deps = item.get("dependencies") or item.get("depends_on") or []
            if isinstance(deps, str):
                deps = [deps]
            edges.append((item_id, sorted(deps)))
        edges.sort(key=lambda e: e[0])
        return hashlib.sha256(_json.dumps(edges).encode()).hexdigest()

    def _merge_revision_batch(
        self,
        base_items: list[dict[str, Any]],
        revised_items: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Merge revised batch items into a full plan snapshot by ID."""
        if not base_items:
            return list(revised_items)

        revised_map = {
            item.get("id"): item
            for item in revised_items
            if isinstance(item, dict) and item.get("id")
        }
        base_ids = {
            item.get("id")
            for item in base_items
            if isinstance(item, dict) and item.get("id")
        }

        merged: list[dict[str, Any]] = []
        for item in base_items:
            if not isinstance(item, dict):
                continue
            item_id = item.get("id")
            if item_id in revised_map:
                merged.append(revised_map[item_id])
            else:
                merged.append(item)

        for item in revised_items:
            if not isinstance(item, dict):
                continue
            item_id = item.get("id")
            if item_id and item_id not in base_ids:
                merged.append(item)

        return merged

    # ------------------------------------------------------------------
    # FEAT-REFINEMENT-PARALLEL-001: Parallel batch fan-out
    # ------------------------------------------------------------------

    def _handle_parallel_examine_batches(
        self,
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        """Fan out examination batches to parallel ExamineHandler workers.

        Builds per-batch ExamineRequest objects by merging top-level shared
        fields into each batch dict, then submits to a ThreadPoolExecutor.
        Results are merged and deduplicated before returning.

        Args:
            payload: Full EXAMINE action payload containing ``batches`` and
                shared fields (``base_prompt``, ``plan_version_id``, etc.).

        Returns:
            Consolidated result dict with merged ``issues``, summed
            ``thinking_budget_used``, concatenated ``raw_response``,
            ``iteration``, and ``thinking_fallback``.
        """
        import time
        from concurrent.futures import ThreadPoolExecutor, as_completed

        from obra.api.protocol import ExamineRequest
        from obra.config.loaders import (
            get_parallel_worker_delay_s,
            get_refinement_parallel_max_workers,
        )
        from obra.hybrid.handlers.examine import ExamineHandler

        batches = payload.get("batches", [])

        # Guard: empty batches list — return empty result without spawning executor.
        if not batches:
            return {
                "issues": [],
                "thinking_budget_used": 0,
                "raw_response": "",
                "iteration": payload.get("iteration", 0),
                "thinking_fallback": False,
            }

        # Shared fields that must be injected into each per-batch request.
        shared_fields = {
            "base_prompt": payload.get("base_prompt"),
            "plan_version_id": payload.get("plan_version_id"),
            "thinking_required": payload.get("thinking_required"),
            "thinking_level": payload.get("thinking_level"),
            "iteration": payload.get("iteration"),
            "max_iterations": payload.get("max_iterations"),
        }

        max_workers = get_refinement_parallel_max_workers()
        effective_workers = min(max_workers, len(batches))
        provider = (self._llm_config or {}).get("provider")
        worker_delay_s = get_parallel_worker_delay_s(provider)
        llm_config = self._get_role_llm_config(ActionType.EXAMINE)

        total_items = sum(
            len(b.get("plan_items", [])) for b in batches
        )

        if self._progress_emitter:
            self._progress_emitter.parallel_batch_started(
                "examine", workers=effective_workers, batches=len(batches), items=total_items,
            )

        batch_results: list[dict[str, Any]] = []
        batch_errors: list[tuple[int, Exception]] = []
        per_batch_ms: list[float] = []
        total_start = time.monotonic()

        def _run_batch(batch_idx: int, batch_dict: dict[str, Any]) -> dict[str, Any]:
            """Execute a single examination batch."""
            merged = {**shared_fields, **batch_dict}
            examine_req = ExamineRequest.from_payload(merged)
            handler = ExamineHandler(
                working_dir=self._working_dir,
                llm_config=llm_config,
                log_event=self._log_session_event,
                trace_id=self._trace_id,
            )
            return handler.handle(examine_req)

        with ThreadPoolExecutor(max_workers=effective_workers) as executor:
            futures: dict[Any, int] = {}
            for idx, batch_dict in enumerate(batches):
                if idx > 0 and worker_delay_s > 0:
                    time.sleep(worker_delay_s)
                batch_start = time.monotonic()
                future = executor.submit(_run_batch, idx, batch_dict)
                futures[future] = idx

            batches_done = 0
            batches_failed_count = 0
            for future in as_completed(futures):
                batch_idx = futures[future]
                elapsed_ms = (time.monotonic() - total_start) * 1000
                try:
                    result = future.result()
                    batch_results.append(result)
                    per_batch_ms.append(elapsed_ms)
                    batches_done += 1
                    batch_status = "success"
                except Exception as exc:
                    logger.warning(
                        "Examine batch %d/%d failed: %s",
                        batch_idx + 1,
                        len(batches),
                        exc,
                    )
                    batch_errors.append((batch_idx, exc))
                    per_batch_ms.append(elapsed_ms)
                    batches_failed_count += 1
                    batch_status = "error"
                self._log_session_event(
                    "refinement_batch_completed",
                    phase="examine",
                    batch_index=batch_idx,
                    batch_size=len(batches[batch_idx].get("plan_items", [])),
                    batches_total=len(batches),
                    batches_done=batches_done,
                    batches_failed=batches_failed_count,
                    elapsed_ms=round(elapsed_ms, 1),
                    status=batch_status,
                )

        # If ALL batches failed, propagate the last error.
        if len(batch_errors) == len(batches):
            raise batch_errors[-1][1]

        # Merge and deduplicate results.
        merged_result = self._merge_examine_batch_results(
            batch_results, payload, batch_errors
        )

        # Telemetry (Rule 10: ProgressEmitter counters MUST increment).
        wall_clock_ms = (time.monotonic() - total_start) * 1000
        sum_per_batch = sum(per_batch_ms) if per_batch_ms else wall_clock_ms
        speedup_ratio = sum_per_batch / wall_clock_ms if wall_clock_ms > 0 else 1.0
        imbalance_ratio = (
            round(max(per_batch_ms) / min(per_batch_ms), 2)
            if len(per_batch_ms) >= 2 and min(per_batch_ms) > 0
            else 1.0
        )
        self._log_session_event(
            "refinement_parallel_examine",
            wall_clock_ms=round(wall_clock_ms, 1),
            per_batch_ms=[round(ms, 1) for ms in per_batch_ms],
            worker_count=effective_workers,
            speedup_ratio=round(speedup_ratio, 2),
            imbalance_ratio=imbalance_ratio,
            batches_total=len(batches),
            batches_failed=len(batch_errors),
        )
        if self._progress_emitter:
            self._progress_emitter.increment("refinement_parallel_examine")
            self._progress_emitter.parallel_batch_completed(
                "examine",
                wall_clock_ms=wall_clock_ms,
                speedup_ratio=round(speedup_ratio, 2),
                batches_failed=len(batch_errors),
                batches_total=len(batches),
            )

        return merged_result

    def _merge_examine_batch_results(
        self,
        batch_results: list[dict[str, Any]],
        payload: dict[str, Any],
        batch_errors: list[tuple[int, Exception]] | None = None,
    ) -> dict[str, Any]:
        """Merge and deduplicate issues from parallel examine batches.

        Args:
            batch_results: List of result dicts from successful batches.
            payload: Original EXAMINE payload (for iteration, etc.).
            batch_errors: List of (batch_idx, exception) for failed batches.

        Returns:
            Single consolidated result dict.
        """
        all_issues: list[dict[str, Any]] = []
        total_thinking_budget = 0
        raw_responses: list[str] = []

        for result in batch_results:
            all_issues.extend(result.get("issues", []))
            total_thinking_budget += result.get("thinking_budget_used", 0)
            raw = result.get("raw_response", "")
            if raw:
                raw_responses.append(raw)

        # Deduplicate using composite key matching server's _issue_dedupe_key().
        seen: dict[str, dict[str, Any]] = {}
        for issue in all_issues:
            dedupe_key = self._issue_dedupe_key(issue)
            if dedupe_key and dedupe_key not in seen:
                seen[dedupe_key] = issue
            elif not dedupe_key:
                seen[f"_anon_{len(seen)}"] = issue
        deduped_issues = list(seen.values())

        failed_indices = [idx for idx, _ in (batch_errors or [])]
        consolidated: dict[str, Any] = {
            "issues": deduped_issues,
            "thinking_budget_used": total_thinking_budget,
            "raw_response": "\n---\n".join(raw_responses),
            "iteration": payload.get("iteration", 0),
            "thinking_fallback": any(
                r.get("thinking_fallback", False) for r in batch_results
            ),
        }
        if batch_errors:
            consolidated["failed_batch_indices"] = failed_indices
            consolidated["failed_batch_count"] = len(batch_errors)
        return consolidated

    @staticmethod
    def _issue_dedupe_key(issue: dict[str, Any]) -> str | None:
        """Build a stable composite key for issue deduplication.

        Replicates the server's ``_issue_dedupe_key()`` in
        ``functions/src/orchestration/coordinator.py`` to ensure consistent
        dedup behavior across client and server.
        """
        issue_id = str(issue.get("id", "")).strip()
        if not issue_id:
            return None

        category = str(issue.get("category", "")).strip().lower()
        issue_type = str(
            issue.get("type") or issue.get("issue_type") or ""
        ).strip().lower()

        # Extract priority: prefer explicit priority field, fall back to severity mapping.
        priority_raw = str(issue.get("priority", "")).upper()
        _valid = {"P0", "P1", "P2", "P3"}
        if priority_raw not in _valid:
            _sev_map = {
                "critical": "P0",
                "high": "P1",
                "medium": "P2",
                "low": "P3",
                "p0": "P0",
                "p1": "P1",
                "p2": "P2",
                "p3": "P3",
            }
            severity = str(issue.get("severity", "")).lower()
            priority_raw = _sev_map.get(severity, "P2")
        priority = priority_raw

        description = " ".join(
            str(issue.get("description", "")).strip().lower().split()
        )

        affected_items = issue.get("affected_items", [])
        if not isinstance(affected_items, list):
            affected_items = [affected_items] if affected_items else []
        affected_key = "|".join(
            sorted(str(item).strip() for item in affected_items if str(item).strip())
        )

        return (
            f"id:{issue_id}|priority:{priority}|category:{category}|type:{issue_type}|"
            f"affected:{affected_key}|description:{description}"
        )

    # ------------------------------------------------------------------
    # FEAT-REFINEMENT-PARALLEL-001: Parallel revision batch fan-out
    # ------------------------------------------------------------------

    def _handle_parallel_revise_batches(
        self,
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        """Fan out revision batches to parallel ReviseHandler workers.

        Builds per-batch RevisionRequest objects by merging top-level shared
        fields into each batch dict, then submits to a ThreadPoolExecutor.
        Results are merged against ``full_plan_items`` (the complete plan
        used as merge base) and returned as a single consolidated result.

        Args:
            payload: Full REVISE action payload containing ``batches``,
                ``full_plan_items``, and shared fields (``proposed_defaults``,
                ``userplan_id``, ``quality_score``, etc.).

        Returns:
            Consolidated result dict with merged ``plan_items``,
            concatenated ``changes_summary`` and ``raw_response``,
            unioned ``addressed_issues``, and concatenated
            ``deferred_issues``.
        """
        import time
        from concurrent.futures import ThreadPoolExecutor, as_completed

        from obra.api.protocol import RevisionRequest
        from obra.config.loaders import (
            get_parallel_worker_delay_s,
            get_refinement_parallel_max_workers,
        )
        from obra.hybrid.handlers.revise import ReviseHandler

        batches = payload.get("batches", [])
        full_plan_items = payload.get("full_plan_items", [])

        # Invalidate C9 cache — graph may change after revision (S3.T4).
        self._c9_graph_hash = None

        # Guard: empty batches list — return full plan unchanged.
        if not batches:
            return {
                "plan_items": list(full_plan_items),
                "addressed_issues": [],
                "deferred_issues": [],
                "changes_summary": "",
                "raw_response": "",
            }

        # Shared fields that must be injected into each per-batch request.
        shared_fields = {
            "proposed_defaults": payload.get("proposed_defaults"),
            "current_plan_version_id": payload.get("current_plan_version_id"),
            "userplan_id": payload.get("userplan_id"),
        }

        max_workers = get_refinement_parallel_max_workers()
        effective_workers = min(max_workers, len(batches))
        provider = (self._llm_config or {}).get("provider")
        worker_delay_s = get_parallel_worker_delay_s(provider)
        llm_config = self._get_role_llm_config(ActionType.REVISE)

        total_items = sum(
            len(b.get("plan_items", [])) for b in batches
        )

        if self._progress_emitter:
            self._progress_emitter.parallel_batch_started(
                "revise", workers=effective_workers, batches=len(batches), items=total_items,
            )

        batch_results: list[dict[str, Any]] = []
        batch_errors: list[tuple[int, Exception]] = []
        per_batch_ms: list[float] = []
        total_start = time.monotonic()

        def _run_batch(batch_idx: int, batch_dict: dict[str, Any]) -> dict[str, Any]:
            """Execute a single revision batch."""
            merged = {**shared_fields, **batch_dict}
            revise_req = RevisionRequest.from_payload(merged)
            handler = ReviseHandler(
                working_dir=self._working_dir,
                llm_config=llm_config,
                log_event=self._log_session_event,
                trace_id=self._trace_id,
            )
            return handler.handle(revise_req)

        with ThreadPoolExecutor(max_workers=effective_workers) as executor:
            futures: dict[Any, int] = {}
            for idx, batch_dict in enumerate(batches):
                if idx > 0 and worker_delay_s > 0:
                    time.sleep(worker_delay_s)
                future = executor.submit(_run_batch, idx, batch_dict)
                futures[future] = idx

            batches_done = 0
            batches_failed_count = 0
            for future in as_completed(futures):
                batch_idx = futures[future]
                elapsed_ms = (time.monotonic() - total_start) * 1000
                try:
                    result = future.result()
                    batch_results.append(result)
                    per_batch_ms.append(elapsed_ms)
                    batches_done += 1
                    batch_status = "success"
                except Exception as exc:
                    logger.warning(
                        "Revise batch %d/%d failed: %s",
                        batch_idx + 1,
                        len(batches),
                        exc,
                    )
                    batch_errors.append((batch_idx, exc))
                    per_batch_ms.append(elapsed_ms)
                    batches_failed_count += 1
                    batch_status = "error"
                self._log_session_event(
                    "refinement_batch_completed",
                    phase="revise",
                    batch_index=batch_idx,
                    batch_size=len(batches[batch_idx].get("plan_items", [])),
                    batches_total=len(batches),
                    batches_done=batches_done,
                    batches_failed=batches_failed_count,
                    elapsed_ms=round(elapsed_ms, 1),
                    status=batch_status,
                )

        # If ALL batches failed, propagate the last error.
        if len(batch_errors) == len(batches):
            raise batch_errors[-1][1]

        # Merge results: start with full_plan_items as merge base, overlay
        # each batch's revised items by ID.  Union-find guarantees batch
        # disjointness, so overlay order doesn't matter.
        merged_plan = list(full_plan_items)
        all_addressed: list[str] = []
        all_deferred: list[dict[str, Any]] = []
        summaries: list[str] = []
        raw_responses: list[str] = []

        for result in batch_results:
            batch_items = result.get("plan_items", [])
            if batch_items:
                merged_plan = self._merge_revision_batch(merged_plan, batch_items)
            all_addressed.extend(result.get("addressed_issues", []))
            all_deferred.extend(result.get("deferred_issues", []))
            summary = result.get("changes_summary", "")
            if summary:
                summaries.append(summary)
            raw = result.get("raw_response", "")
            if raw:
                raw_responses.append(raw)

        # Post-merge C9 dependency validation with caching (S3.T4).
        graph_hash = self._compute_dependency_graph_hash(merged_plan)
        if graph_hash == self._c9_graph_hash:
            logger.debug("C9 cache hit -- skipping validation (graph unchanged)")
        else:
            from obra.agents.dependency_graph import DependencyGraphValidator

            findings = DependencyGraphValidator().validate(merged_plan)
            if findings:
                logger.warning(
                    "Post-merge C9 validation found %d findings: %s",
                    len(findings),
                    findings,
                )
            self._c9_graph_hash = graph_hash

        # Build consolidated result.
        consolidated: dict[str, Any] = {
            "plan_items": merged_plan,
            "addressed_issues": all_addressed,
            "deferred_issues": all_deferred,
            "changes_summary": "\n---\n".join(summaries),
            "raw_response": "\n---\n".join(raw_responses),
        }

        # Error metadata for partial failures.
        failed_indices = [idx for idx, _ in batch_errors]
        if batch_errors:
            consolidated["failed_batch_indices"] = failed_indices
            consolidated["failed_batch_count"] = len(batch_errors)
            consolidated["all_batches_failed"] = False

        # Telemetry (Rule 10: ProgressEmitter counters MUST increment).
        wall_clock_ms = (time.monotonic() - total_start) * 1000
        sum_per_batch = sum(per_batch_ms) if per_batch_ms else wall_clock_ms
        speedup_ratio = sum_per_batch / wall_clock_ms if wall_clock_ms > 0 else 1.0
        imbalance_ratio = (
            round(max(per_batch_ms) / min(per_batch_ms), 2)
            if len(per_batch_ms) >= 2 and min(per_batch_ms) > 0
            else 1.0
        )
        self._log_session_event(
            "refinement_parallel_revise",
            wall_clock_ms=round(wall_clock_ms, 1),
            per_batch_ms=[round(ms, 1) for ms in per_batch_ms],
            worker_count=effective_workers,
            speedup_ratio=round(speedup_ratio, 2),
            imbalance_ratio=imbalance_ratio,
            batches_total=len(batches),
            batches_failed=len(batch_errors),
        )
        if self._progress_emitter:
            self._progress_emitter.increment("refinement_parallel_revise")
            self._progress_emitter.parallel_batch_completed(
                "revise",
                wall_clock_ms=wall_clock_ms,
                speedup_ratio=round(speedup_ratio, 2),
                batches_failed=len(batch_errors),
                batches_total=len(batches),
            )

        return consolidated

    def _extract_step_index(self, item: dict[str, Any]) -> int | None:
        """Extract UserPlan step index from item context or source_step_id."""
        context = item.get("context")
        if isinstance(context, dict):
            step_index = context.get("userplan_step_index")
            if isinstance(step_index, int):
                return step_index
            if isinstance(step_index, str) and step_index.strip().isdigit():
                return int(step_index.strip())
        source_step_id = item.get("source_step_id")
        if isinstance(source_step_id, str) and ":S" in source_step_id:
            try:
                return int(source_step_id.split(":S")[-1])
            except ValueError:
                return None
        return None

    def _filter_preserved_items_for_rederivation(
        self,
        preserved_items: list[dict[str, Any]],
        *,
        from_step: int,
    ) -> list[dict[str, Any]]:
        """Drop affected subtrees for items derived from steps >= from_step."""
        item_map = {item.get("id"): item for item in preserved_items if item.get("id")}
        children_by_parent: dict[str, list[str]] = {}
        for item in preserved_items:
            parent_id = item.get("parent_id")
            item_id = item.get("id")
            if parent_id and item_id:
                children_by_parent.setdefault(parent_id, []).append(item_id)

        affected_ids: set[str] = set()
        for item_id, item in item_map.items():
            step_index = self._extract_step_index(item)
            if step_index is not None and step_index >= from_step and item_id is not None:
                affected_ids.add(item_id)

        stack = list(affected_ids)
        while stack:
            current_id = stack.pop()
            for child_id in children_by_parent.get(current_id, []):
                if child_id not in affected_ids:
                    affected_ids.add(child_id)
                    stack.append(child_id)

        return [item for item in preserved_items if item.get("id") not in affected_ids]

    def _mark_rederived_parents_stale(
        self,
        preserved_items: list[dict[str, Any]],
        *,
        from_step: int,
    ) -> list[dict[str, Any]]:
        """Mark parents as stale when any descendant is re-derived."""
        item_map = {item.get("id"): item for item in preserved_items if item.get("id")}
        affected_ids = {
            item_id
            for item_id, item in item_map.items()
            if (step_index := self._extract_step_index(item)) is not None
            and step_index >= from_step
        }
        if not affected_ids:
            return preserved_items

        ancestors_to_mark: set[str] = set()
        for item_id in affected_ids:
            current = item_map.get(item_id)
            while current and current.get("parent_id"):
                parent_id = current.get("parent_id")
                if not parent_id:
                    break
                if parent_id not in affected_ids:
                    ancestors_to_mark.add(parent_id)
                current = item_map.get(parent_id)

        for item in preserved_items:
            if item.get("id") in ancestors_to_mark:
                item["is_stale"] = True
                item["stale_reason"] = "Child items re-derived"

        return preserved_items

    def _recompute_parent_statuses(
        self,
        items: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Recompute parent statuses from descendant completion."""
        item_map = {item.get("id"): item for item in items if item.get("id")}
        children_by_parent: dict[str, list[dict[str, Any]]] = {}
        for item in items:
            parent_id = item.get("parent_id")
            if parent_id and parent_id in item_map:
                children_by_parent.setdefault(parent_id, []).append(item)

        def rollup_status(child_items: list[dict[str, Any]]) -> str:
            if not child_items:
                return "pending"
            statuses = [child.get("status", "pending") for child in child_items]
            if any(status == "blocked" for status in statuses):
                return "blocked"
            if any(status == "in_progress" for status in statuses):
                return "in_progress"
            if all(status == "completed" for status in statuses):
                return "completed"
            return "pending"

        # Update parents bottom-up by depth (deepest first if available)
        items_sorted = sorted(
            items,
            key=lambda item: (int(item.get("depth", 0)) if item.get("depth") is not None else 0),
            reverse=True,
        )
        for item in items_sorted:
            item_id = item.get("id")
            if not item_id:
                continue
            children = children_by_parent.get(item_id)
            if not children:
                continue
            new_status = rollup_status(children)
            item["status"] = new_status

        return items

    def _get_log_viewer_int(self, env_var: str, default: int) -> int:
        """Read an int from env for log viewer payload caps."""
        try:
            return max(0, int(os.environ.get(env_var, default)))
        except (TypeError, ValueError):
            return default

    def _plan_snapshot_dir(self) -> Path:
        """Return the directory for plan snapshot reference files."""
        return Path.home() / ".obra" / "logs" / PLAN_SNAPSHOT_DIRNAME

    def _write_plan_snapshot(
        self,
        *,
        session_id: str,
        userplan_id: str | None = None,
        userplan_version: int | None = None,
        userplan_steps: list[dict[str, Any]] | None = None,
        derived_plan_items: list[dict[str, Any]] | None = None,
    ) -> str | None:
        """Write a full plan snapshot reference file for the viewer."""
        if not session_id:
            return None

        snapshot_dir = self._plan_snapshot_dir()
        snapshot_dir.mkdir(parents=True, exist_ok=True)
        filename = f"{session_id}.json"
        path = snapshot_dir / filename

        payload: dict[str, Any] = {
            "session_id": session_id,
            "updated_at": datetime.now(UTC).isoformat(),
        }
        if userplan_id:
            payload["userplan_id"] = userplan_id
        if userplan_version is not None:
            payload["userplan_version"] = userplan_version
        if userplan_steps is not None:
            payload["userplan_steps"] = userplan_steps
            payload["userplan_steps_count"] = len(userplan_steps)
        if derived_plan_items is not None:
            payload["derived_plan_items"] = derived_plan_items
            payload["derived_plan_count"] = len(derived_plan_items)

        path.write_text(json.dumps(payload, ensure_ascii=False, default=str), encoding="utf-8")
        return filename

    def _get_derived_plan_api_keys(self) -> set[str]:
        """Return allowed DerivedPlan item keys based on schema."""
        cached = getattr(self, "_derived_plan_api_keys_cache", None)
        if cached is not None:
            return cached
        keys = set(DerivedPlanItem.model_fields.keys())
        self._derived_plan_api_keys_cache = keys
        return keys

    def _normalize_plan_items_for_api(
        self,
        items: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Drop unsupported keys before sending DerivedPlan payload to server."""
        if not items:
            return items

        normalized: list[dict[str, Any]] = []
        dropped_keys_by_id: dict[str, list[str]] = {}
        dropped_key_counts: dict[str, int] = {}
        allowed_keys = self._get_derived_plan_api_keys()

        for idx, item in enumerate(items, start=1):
            if not isinstance(item, dict):
                logger.warning("DerivedPlan item %s is not a dict; passing through unchanged", idx)
                normalized.append(item)
                continue
            extra_keys = set(item.keys()) - allowed_keys
            if extra_keys:
                item_id = item.get("id") or f"item-{idx}"
                dropped_keys_by_id[item_id] = sorted(extra_keys)
                for key in extra_keys:
                    dropped_key_counts[key] = dropped_key_counts.get(key, 0) + 1
            normalized.append({key: item[key] for key in item if key in allowed_keys})

        if dropped_keys_by_id:
            logger.warning(
                "Dropped unsupported DerivedPlan item keys before report_derivation: %s",
                dropped_keys_by_id,
            )
            log_event = getattr(self, "_log_event", None)
            if log_event:
                try:
                    log_event(
                        "derived_plan_item_keys_dropped",
                        session_id=self._session_id,
                        trace_id=self._trace_id,
                        parent_span_id=self._phase_span_id,
                        items_with_dropped_keys=len(dropped_keys_by_id),
                        dropped_key_counts=dropped_key_counts,
                    )
                except Exception as exc:
                    logger.debug("Failed to log derived plan key drops: %s", exc)
            if self._production_logger:
                self._production_logger.log_event(
                    "derived_plan_item_keys_dropped",
                    work_unit_id="derivation",
                    items_with_dropped_keys=len(dropped_keys_by_id),
                    dropped_key_counts=dropped_key_counts,
                )

        return normalized

    def _read_plan_snapshot(self, session_id: str) -> dict[str, Any]:
        """Read an existing plan snapshot file if present."""
        if not session_id:
            return {}
        path = self._plan_snapshot_dir() / f"{session_id}.json"
        if not path.exists():
            return {}
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return {}

    def _resolve_project_name(self, project_id: str | None) -> str | None:
        """Resolve project name for logging if available."""
        if not project_id:
            return None
        try:
            project = self._client.get_project(project_id)
            if isinstance(project, dict):
                name = project.get("name") or project.get("project_name")
                if isinstance(name, str) and name.strip():
                    return name.strip()
        except Exception:
            logger.debug("Failed to resolve project name for %s", project_id, exc_info=True)
        return None

    def _summarize_userplan_steps(
        self, steps: list[dict[str, Any]]
    ) -> tuple[list[dict[str, Any]], bool]:
        """Return a capped summary of userplan steps for logging."""
        max_steps = self._get_log_viewer_int(
            "OBRA_LOG_VIEWER_MAX_USERPLAN_STEPS",
            DEFAULT_MAX_USERPLAN_STEPS_LOGGED,
        )
        max_title_len = self._get_log_viewer_int(
            "OBRA_LOG_VIEWER_MAX_TITLE_LEN",
            DEFAULT_MAX_PLAN_TITLE_LEN,
        )
        summarized: list[dict[str, Any]] = []
        for step in steps[:max_steps]:
            if not isinstance(step, dict):
                continue
            title = str(step.get("title", "")).strip()
            if len(title) > max_title_len:
                title = f"{title[:max_title_len]}..."
            summarized.append(
                {
                    "id": step.get("id"),
                    "index": step.get("index"),
                    "title": title,
                }
            )
        truncated = len(steps) > max_steps
        return summarized, truncated

    def _summarize_plan_items(
        self, items: list[dict[str, Any]]
    ) -> tuple[list[dict[str, Any]], bool]:
        """Return a capped summary of derived plan items for logging."""
        max_items = self._get_log_viewer_int(
            "OBRA_LOG_VIEWER_MAX_DERIVED_ITEMS",
            DEFAULT_MAX_DERIVED_ITEMS_LOGGED,
        )
        max_title_len = self._get_log_viewer_int(
            "OBRA_LOG_VIEWER_MAX_TITLE_LEN",
            DEFAULT_MAX_PLAN_TITLE_LEN,
        )
        summarized: list[dict[str, Any]] = []
        for item in items[:max_items]:
            if not isinstance(item, dict):
                continue
            title = str(item.get("title", "")).strip()
            if len(title) > max_title_len:
                title = f"{title[:max_title_len]}..."
            context = item.get("context") if isinstance(item.get("context"), dict) else {}
            summarized.append(
                {
                    "id": item.get("id"),
                    "title": title,
                    "source_step_id": item.get("source_step_id"),
                    "userplan_step_index": (
                        context.get("userplan_step_index") if context else None
                    ),
                    "level": item.get("level"),
                    "parent_id": item.get("parent_id"),
                    "depth": item.get("depth"),
                    "path": item.get("path") or item.get("ancestry"),
                    "order": item.get("order") or item.get("index"),
                }
            )
        truncated = len(items) > max_items
        return summarized, truncated

    @staticmethod
    def _is_leaf_item(current_item: dict[str, Any], plan_items: list[dict[str, Any]]) -> bool:
        """Check whether the current item has no children in the plan."""
        item_id = current_item.get("id")
        if not item_id:
            return True
        return all(item.get("parent_id") != item_id for item in plan_items)

    def _get_handler(
        self,
        action: ActionType,
        payload: dict[str, Any] | None = None,
    ) -> Any:
        """Get handler for action type.

        Lazily imports and instantiates handlers.

        Args:
            action: Action type

        Returns:
            Handler instance

        Raises:
            OrchestratorError: If handler not found
            ConfigurationError: If llm_config is invalid or missing required keys
        """
        validator_stage = None
        if action == ActionType.VALIDATOR and isinstance(payload, dict):
            stage = payload.get("stage")
            if isinstance(stage, str):
                validator_stage = stage.strip().lower()

        handler_key: ActionType | tuple[ActionType, str]
        if action == ActionType.VALIDATOR and validator_stage:
            handler_key = (action, validator_stage)
        else:
            handler_key = action

        if handler_key not in self._handlers:
            # Validate llm_config for handlers that require it (C11)
            # DERIVE, EXAMINE, REVISE, EXECUTE, FIX, and VALIDATOR all need llm_config
            # ADR-069: Use role-based resolution for validation
            if action in (
                ActionType.DERIVE,
                ActionType.INTENT,
                ActionType.EXAMINE,
                ActionType.REVISE,
                ActionType.EXECUTE,
                ActionType.FIX,
                ActionType.STORY_PREFLIGHT,
                ActionType.VALIDATOR,  # FEAT-SENSECHECK-PIPELINE-001
            ):
                # Get role-based config (has fallbacks, should rarely fail)
                role_config = self._get_role_llm_config(action)

                # Validate required keys
                required_keys = {"provider"}
                missing_keys = required_keys - set(role_config.keys())
                if missing_keys:
                    msg = (
                        f"Cannot create {action.value} handler: resolved llm_config missing required keys: {missing_keys}. "
                        f"Current config: {role_config}"
                    )
                    raise ConfigurationError(
                        msg,
                        recovery="Run 'obra config' to set up LLM configuration or use 'obra derive' with --model and --provider flags.",
                    )
            # ISSUE-CLI-016/CLI-017 FIX: Build monitoring context for liveness checks
            # ADR-043 Phase 3: Use helper factory for consistent context construction
            monitoring_context = self.create_monitoring_context()

            # Import handlers lazily to avoid circular imports
            if action == ActionType.DERIVE:
                from obra.hybrid.handlers.derive import DeriveHandler

                # S3.T6: Pass on_stream callback to handler
                # S4.T2: Pass llm_config to handler
                # ISSUE-CLI-016/017: Pass monitoring context
                # Quality gate: Pass API client for UserPlan quality assessment
                # Production logger: Pass for detailed derivation/quality metrics
                # FEAT-COMPLEXITY-ROUTING-001: Pass planning mode for complexity routing
                # ADR-069: Use role-based LLM config resolution
                self._handlers[action] = DeriveHandler(
                    self._working_dir,
                    on_stream=self._on_stream,
                    on_progress=self._on_progress,
                    llm_config=self._get_role_llm_config(action),
                    log_event=self._log_session_event,
                    trace_id=self._trace_id,
                    parent_span_id=self._phase_span_id,
                    monitoring_context=monitoring_context,
                    observability_config=self._observability_config,
                    bypass_modes=self._bypass_modes,
                    api_client=self._client,
                    work_type_override=getattr(self, "_work_type_override", None),
                    production_logger=self._production_logger,
                    planning_mode=self._planning_mode,
                )
            elif action == ActionType.INTENT:
                from obra.hybrid.handlers.intent_stage import IntentStageHandler

                self._handlers[action] = IntentStageHandler(
                    self._working_dir,
                    on_stream=self._on_stream,
                    on_progress=self._on_progress,
                    llm_config=self._get_role_llm_config(ActionType.DERIVE),
                    log_event=self._log_session_event,
                    trace_id=self._trace_id,
                    parent_span_id=self._phase_span_id,
                    monitoring_context=monitoring_context,
                    production_logger=self._production_logger,
                )
            elif action == ActionType.STORY0:
                from obra.config.loaders import load_layered_config
                from obra.hybrid.handlers.story0 import Story0Handler

                config = self._config
                if config is None:
                    config, _, _ = load_layered_config(include_defaults=True)
                    self._config = config

                self._handlers[action] = Story0Handler(
                    self._working_dir,
                    config,
                    on_progress=self._on_progress,
                    session_id=self._session_id or "",
                    objective=self._objective or "",
                    is_tty=sys.stdin.isatty(),
                    llm_config=self._get_role_llm_config(ActionType.DERIVE),
                )
            elif action == ActionType.STORY_PREFLIGHT:
                from obra.agents.tier_config import resolve_agent_tier_config
                from obra.config.loaders import load_layered_config
                from obra.hybrid.handlers.story_preflight import StoryPreflightHandler

                config = self._config
                if config is None:
                    config, _, _ = load_layered_config(include_defaults=True)
                    self._config = config

                validator_llm_config = resolve_agent_tier_config("code_verify")
                if self._llm_config:
                    for key in ("git", "codex", "auth_method"):
                        if key in self._llm_config and key not in validator_llm_config:
                            validator_llm_config[key] = self._llm_config[key]

                self._handlers[action] = StoryPreflightHandler(
                    self._working_dir,
                    config=config,
                    llm_config=validator_llm_config,
                    log_event=self._log_session_event,
                    session_id=self._session_id or "",
                    trace_id=self._trace_id,
                    progress_emitter=self._progress_emitter,
                )
            elif action == ActionType.EXAMINE:
                from obra.hybrid.handlers.examine import ExamineHandler

                # S3.T6: Pass on_stream callback to handler
                # S4.T3: Pass llm_config to handler
                # ISSUE-CLI-016/017: Pass monitoring context
                # ADR-069: Use role-based LLM config resolution
                self._handlers[action] = ExamineHandler(
                    self._working_dir,
                    on_stream=self._on_stream,
                    llm_config=self._get_role_llm_config(action),
                    log_event=self._log_session_event,
                    trace_id=self._trace_id,
                    parent_span_id=self._phase_span_id,
                    monitoring_context=monitoring_context,
                )
            elif action == ActionType.REVISE:
                from obra.hybrid.handlers.revise import ReviseHandler

                # S3.T6: Pass on_stream callback to handler
                # S4.T4: Pass llm_config to handler
                # ISSUE-CLI-016/017: Pass monitoring context
                # ADR-069: Use role-based LLM config resolution
                self._handlers[action] = ReviseHandler(
                    self._working_dir,
                    on_stream=self._on_stream,
                    llm_config=self._get_role_llm_config(action),
                    log_event=self._log_session_event,
                    trace_id=self._trace_id,
                    parent_span_id=self._phase_span_id,
                    monitoring_context=monitoring_context,
                )
            elif action == ActionType.EXECUTE:
                from obra.hybrid.handlers.execute import ExecuteHandler

                # S5.T3: Pass llm_config to ExecuteHandler
                # ISSUE-OBS-003: Pass observability context for cross-process propagation
                # S2.T4: Pass observability_config and progress_emitter for heartbeat
                # ADR-069: Use role-based LLM config resolution
                log_file = get_runtime_dir() / "logs" / "hybrid.jsonl"
                self._handlers[action] = ExecuteHandler(
                    self._working_dir,
                    llm_config=self._get_role_llm_config(action),
                    session_id=self._session_id,
                    log_file=log_file,
                    trace_id=self._trace_id,
                    log_event=self._log_session_event,
                    parent_span_id=self._phase_span_id,
                    observability_config=self._observability_config,
                    progress_emitter=self._progress_emitter,
                    on_stream=self._on_stream,
                    process_registry=self._process_registry,  # FEAT-PROCESS-LIFECYCLE-001
                    monitoring_context=monitoring_context,
                )
            elif action == ActionType.REVIEW:
                from obra.hybrid.handlers.review import ReviewHandler

                self._handlers[action] = ReviewHandler(
                    self._working_dir,
                    llm_config=self._get_review_config(),
                    review_config=self._review_config,
                    log_event=self._log_session_event,
                    trace_id=self._trace_id,
                    parent_span_id=self._phase_span_id,
                    progress_emitter=self._progress_emitter,
                )
            elif action == ActionType.PIPELINE_STAGE:
                from obra.hybrid.handlers.stage import StageHandler

                self._handlers[action] = StageHandler(
                    self._working_dir,
                    llm_config=self._get_review_config(),  # Use review config for stage agents
                    log_event=self._log_session_event,
                )
            elif action == ActionType.FIX:
                from obra.hybrid.handlers.fix import FixHandler

                # ISSUE-OBS-003: Pass observability context for cross-process propagation
                # S3.T2: Pass observability_config and progress_emitter for heartbeat
                # ADR-069: Use role-based LLM config resolution
                log_file = get_runtime_dir() / "logs" / "hybrid.jsonl"
                self._handlers[action] = FixHandler(
                    self._working_dir,
                    llm_config=self._get_role_llm_config(action),
                    session_id=self._session_id,
                    log_file=log_file,
                    trace_id=self._trace_id,
                    log_event=self._log_session_event,
                    parent_span_id=self._phase_span_id,
                    observability_config=self._observability_config,
                    progress_emitter=self._progress_emitter,
                    on_stream=self._on_stream,
                    process_registry=self._process_registry,  # FEAT-PROCESS-LIFECYCLE-001
                )
            elif action == ActionType.VALIDATOR and validator_stage == "code_verify":
                from obra.agents.tier_config import resolve_agent_tier_config
                from obra.hybrid.handlers.code_verify import CodeVerifyHandler

                validator_llm_config = resolve_agent_tier_config("code_verify")
                if self._llm_config:
                    for key in ("git", "codex", "auth_method"):
                        if key in self._llm_config and key not in validator_llm_config:
                            validator_llm_config[key] = self._llm_config[key]
                validator_llm_config["allowed_tools"] = ["Read", "Grep", "Glob"]
                self._handlers[handler_key] = CodeVerifyHandler(
                    self._working_dir,
                    llm_config=validator_llm_config,
                    log_event=self._log_session_event,
                    trace_id=self._trace_id,
                    parent_span_id=self._phase_span_id,
                )
            elif action == ActionType.VALIDATOR:
                from obra.agents.tier_config import resolve_agent_tier_config
                from obra.hybrid.handlers.validator_executor import ValidatorExecutor

                # FEAT-SENSECHECK-PIPELINE-001: SenseCheck pipeline validator execution
                # Validators use SenseCheck agent config (Menu 5 > Specialized Agents)
                # which inherits from Review LLM config (Menu 3)
                validator_llm_config = resolve_agent_tier_config("sense_check")
                # Merge session-level settings (git, codex) from runtime config
                if self._llm_config:
                    for key in ("git", "codex", "auth_method"):
                        if key in self._llm_config and key not in validator_llm_config:
                            validator_llm_config[key] = self._llm_config[key]
                self._handlers[handler_key] = ValidatorExecutor(
                    self._working_dir,
                    llm_config=validator_llm_config,
                    log_event=self._log_session_event,
                    trace_id=self._trace_id,
                    parent_span_id=self._phase_span_id,
                    progress_emitter=self._progress_emitter,
                )
            else:
                msg = f"No handler for action: {action.value}"
                raise OrchestratorError(
                    msg,
                    session_id=self._session_id or "",
                )

        return self._handlers[handler_key]

    def _handle_action(self, server_action: ServerAction) -> dict[str, Any]:
        """Handle a server action by dispatching to appropriate handler.

        Args:
            server_action: Server action to handle

        Returns:
            Result to report back to server

        Raises:
            OrchestratorError: If action handling fails
        """
        action = server_action.action
        payload = server_action.payload
        self._last_action_payload = payload  # Store for _report_result access

        logger.info(f"Handling action: {action.value} (iteration {server_action.iteration})")

        # S3.T3: Emit phase transition events
        self._emit_phase_event(action)

        self._emit_progress(action.value, payload)

        # Handle special actions
        if action == ActionType.COMPLETE:
            completion_notice = CompletionNotice.from_payload(payload)
            return {"completed": True, "notice": completion_notice}

        if action == ActionType.ESCALATE:
            escalation_notice = EscalationNotice.from_payload(payload)
            return self._handle_escalation(escalation_notice)

        if action == ActionType.ERROR:
            error_msg = server_action.error_message or "Unknown server error"
            error_code = server_action.error_code or "UNKNOWN"
            msg = f"Server error [{error_code}]: {error_msg}"
            # Add recovery hint for server errors (often 500 errors from Cloud Functions)
            if self._session_id:
                short_id = self._session_id.split("-")[0]
                msg += f"\n\nTry: {get_message('recovery.session.repair', short_id=short_id)}"
            raise OrchestratorError(
                msg,
                session_id=self._session_id or "",
                error_context=self._build_error_context(action="poll_session"),
            )

        if action == ActionType.WAIT:
            # Server is processing async, wait and poll
            return {"waiting": True}

        # Get handler for action
        handler = self._get_handler(action, payload)

        # ISSUE-HYBRID-003: Mark handler as active for watchdog
        # This prevents stall detection during handler execution
        self._handler_active = True
        try:
            return self._dispatch_handler(handler, action, payload, server_action)
        finally:
            self._handler_active = False

    def _dispatch_handler(
        self,
        handler: Any,
        action: ActionType,
        payload: dict[str, Any],
        server_action: ServerAction | None = None,
    ) -> dict[str, Any]:
        """Dispatch request to the appropriate handler (ISSUE-HYBRID-003 refactor).

        Extracted from _handle_action to enable try/finally for handler tracking.

        Args:
            handler: Handler instance for the action
            action: Action type
            payload: Server action payload
            server_action: Original server action envelope (optional, for metadata access)

        Returns:
            Handler result dict
        """
        # ISSUE-HYBRID-033: Update heartbeat on every handler dispatch so the
        # session-*.json stays fresh during long refinement cycles, not just
        # at iteration boundaries.
        if self._session_guard:
            self._session_guard.update(
                items_completed=self._items_completed_this_invocation,
                phase=self._current_phase.value if self._current_phase else "unknown",
            )

        # Create typed request from payload and dispatch to handler
        if action == ActionType.INTENT:
            intent_req = IntentRequest.from_payload(payload)
            self._last_userplan_id = intent_req.userplan_id
            self._last_userplan_version = intent_req.userplan_version
            self._derive_from_step = intent_req.from_step
            subphase_start = self._start_subphase("intent")
            if hasattr(handler, "_parent_span_id"):
                handler._parent_span_id = self._subphase_span_id
            try:
                result = cast(dict[str, Any], handler.handle(intent_req))
            except Exception as e:
                self._complete_subphase(
                    "intent", subphase_start, status="error", error_message=str(e)
                )
                if self._current_phase:
                    self._log_session_event(
                        "phase_failed",
                        phase=self._current_phase.value,
                        failure_stage="intent",
                        error_code="HANDLER_ERROR",
                        error_class=type(e).__name__,
                        error_message=str(e),
                        span_id=self._phase_span_id,
                        parent_span_id=self._pipeline_span_id,
                    )
                raise
            self._complete_subphase("intent", subphase_start)
            return result
        if action == ActionType.DERIVE:
            derive_req = DeriveRequest.from_payload(payload)
            # Store userplan info for DerivedPlan reporting
            self._last_userplan_id = derive_req.userplan_id
            self._last_userplan_version = derive_req.userplan_version
            # Store preserved plan items for --from-step re-derivation merge
            self._preserved_plan_items = derive_req.plan_items_reference
            self._derive_from_step = derive_req.from_step
            subphase_start = self._start_subphase("derive")
            if hasattr(handler, "_parent_span_id"):
                handler._parent_span_id = self._subphase_span_id
            summarized_steps, steps_truncated = self._summarize_userplan_steps(
                derive_req.userplan_steps
            )
            snapshot_ref = self._write_plan_snapshot(
                session_id=self._session_id or "",
                userplan_id=derive_req.userplan_id,
                userplan_version=derive_req.userplan_version,
                userplan_steps=derive_req.userplan_steps,
            )
            self._log_session_event(
                "userplan_snapshot",
                userplan_id=derive_req.userplan_id,
                userplan_version=derive_req.userplan_version,
                userplan_steps_count=len(derive_req.userplan_steps),
                userplan_steps=summarized_steps,
                truncated=steps_truncated,
                plan_snapshot_ref=snapshot_ref,
                span_id=self._subphase_span_id,
                parent_span_id=self._phase_span_id,
            )
            # ISSUE-OBS-002: Log derivation_started event
            self._log_session_event(
                "derivation_started",
                objective=derive_req.objective,
                plan_id=getattr(derive_req, "plan_id", None),
                span_id=self._subphase_span_id,
                parent_span_id=self._phase_span_id,
            )
            try:
                result = cast(dict[str, Any], handler.handle(derive_req))
            except Exception as e:
                self._complete_subphase(
                    "derive", subphase_start, status="error", error_message=str(e)
                )
                if self._current_phase:
                    self._log_session_event(
                        "phase_failed",
                        phase=self._current_phase.value,
                        failure_stage="derive",
                        error_code="HANDLER_ERROR",
                        error_class=type(e).__name__,
                        error_message=str(e),
                        span_id=self._phase_span_id,
                        parent_span_id=self._pipeline_span_id,
                    )
                raise
            # ISSUE-OBS-002: Log derivation_complete event
            self._log_session_event(
                "derivation_complete",
                plan_items_count=len(result.get("plan_items", [])),
                span_id=self._subphase_span_id,
                parent_span_id=self._phase_span_id,
            )
            # FIX-TRACKER-001: Store plan items for phase_completed event
            # This enables the CLI tracker to show "Next:" items correctly
            self._last_derivation_plan_items = result.get("plan_items", [])
            self._complete_subphase("derive", subphase_start)
            return result
        if action == ActionType.STORY0:
            story0_prerequisites = payload.get("story0_prerequisites", [])
            objective = payload.get("objective") or self._objective or ""
            if hasattr(handler, "_objective") and objective:
                handler._objective = objective  # type: ignore[attr-defined]
            result = handler.handle(
                story0_prerequisites,
                resume_reason=payload.get("story0_resume_reason"),
                missing_tools=payload.get("missing_tools"),
            )
            # S0.T7: Store verification tools for mid-session FIX checks
            if result.verification_tools:
                self._verification_tools = result.verification_tools
                logger.info(
                    "Story 0 returned verification_tools: %s",
                    result.verification_tools,
                )
            if payload.get("story0_resume_reason") == "verification_tools_missing":
                self._verification_preflight_attempted = True
                logger.info("Verification preflight attempted flag set to True")
            return {
                "status": result.status,
                "completed_prereqs": result.completed,
                "failed_prereqs": result.failed,
                "blocking_failures": result.blocking_failures,
                "non_blocking_failures": result.non_blocking_failures,
                "verification_tools": result.verification_tools,
                "mocked_credentials": result.mocked_credentials,
            }
        if action == ActionType.STORY_PREFLIGHT:
            preflight_req = StoryPreflightRequest.from_payload(payload)
            preflight = handler.handle(
                story_item=preflight_req.story_item,
                plan_items=preflight_req.plan_items,
                exploration_context=preflight_req.exploration_context,
            )
            if hasattr(preflight, "to_dict"):
                result_dict = cast(dict[str, Any], preflight.to_dict())
            elif isinstance(preflight, dict):
                result_dict = dict(preflight)
            else:
                raise OrchestratorError(
                    "Story preflight handler returned invalid payload",
                    session_id=self._session_id or "",
                )
            result_dict["story_id"] = str(preflight_req.story_item.get("id", "")).strip()
            return result_dict
        if action == ActionType.EXAMINE:
            # Track refinement cycles (examine action count, NOT logical iteration)
            self._refinement_cycle_count += 1
            if self._refinement_start_time is None:
                self._refinement_start_time = time.time()
            # Inject refinement cycle info from server action envelope
            if server_action is not None:
                payload.setdefault("iteration", server_action.iteration)
                payload.setdefault(
                    "max_iterations",
                    server_action.metadata.get("max_refinement_iterations"),
                )

            # ISSUE-HYBRID-055: Client-side iteration guard.
            # The server should enforce max_iterations, but as defense-in-depth
            # the client rejects EXAMINE actions that exceed the limit.
            # Prefer effective_max (dynamic) over base max_refinement_iterations.
            iteration = payload.get("iteration")
            effective_max = (
                server_action.metadata.get("effective_max_refinement_iterations")
                if server_action is not None
                else None
            )
            guard_max = effective_max or payload.get("max_iterations")
            if (
                iteration is not None
                and guard_max is not None
                and iteration >= guard_max
            ):
                logger.warning(
                    "ISSUE-HYBRID-055: Client-side iteration guard triggered — "
                    "iteration %d >= max %d, skipping examine and returning "
                    "empty result to break refinement loop",
                    iteration,
                    guard_max,
                )
                if self._production_logger:
                    self._production_logger.log_event(
                        "refinement_guard_triggered",
                        session_id=self._session_id,
                        examine_action_count=self._refinement_cycle_count,
                        iteration=iteration,
                        effective_max=guard_max,
                    )
                return {"issues": [], "iteration_limit_exceeded": True}

            # FEAT-REFINEMENT-PARALLEL-001: All EXAMINE actions route through
            # parallel batch fan-out. Single-batch payloads produce a batches
            # list with 1 entry and execute with 1 worker (no overhead).
            subphase_start = self._start_subphase("examine")
            batch_count = len(payload.get("batches", []))
            # ISSUE-HYBRID-034: Structured telemetry for examine start
            if self._production_logger:
                self._production_logger.log_event(
                    "examine_start",
                    session_id=self._session_id,
                    examine_action_count=self._refinement_cycle_count,
                    plan_items=sum(
                        len(b.get("plan_items", []))
                        for b in payload.get("batches", [])
                    ),
                    iteration=payload.get("iteration"),
                    max_iterations=payload.get("max_iterations"),
                    batch_count=batch_count,
                )
            try:
                result = self._handle_parallel_examine_batches(payload)
            except Exception as e:
                self._complete_subphase(
                    "examine", subphase_start, status="error", error_message=str(e)
                )
                if self._progress_emitter:
                    self._progress_emitter.parallel_batch_fallback(
                        "examine", error=str(e),
                    )
                if self._production_logger:
                    self._production_logger.log_event(
                        "examine_failed",
                        session_id=self._session_id,
                        examine_action_count=self._refinement_cycle_count,
                        batch_count=batch_count,
                        error_class=type(e).__name__,
                        error_message=str(e),
                    )
                if self._current_phase:
                    self._log_session_event(
                        "phase_failed",
                        phase=self._current_phase.value,
                        failure_stage="examine",
                        error_code="HANDLER_ERROR",
                        error_class=type(e).__name__,
                        error_message=str(e),
                        span_id=self._phase_span_id,
                        parent_span_id=self._pipeline_span_id,
                    )
                raise
            self._complete_subphase("examine", subphase_start)
            # ISSUE-HYBRID-034: Structured telemetry for examine complete
            issues = result.get("issues", []) if isinstance(result, dict) else []
            blocking = [i for i in issues if isinstance(i, dict) and str(i.get("severity", i.get("priority", ""))).upper() in ("P0", "P1")]
            if self._production_logger:
                self._production_logger.log_event(
                    "examine_complete",
                    session_id=self._session_id,
                    examine_action_count=self._refinement_cycle_count,
                    issue_count=len(issues),
                    blocking_count=len(blocking),
                    batch_count=batch_count,
                )
            # Refinement scope summary for CLI visibility
            scope_items = sum(
                len(b.get("plan_items", []))
                for b in payload.get("batches", [])
            )
            total_items = len(payload.get("full_plan_items", payload.get("plan_items", [])))
            if self._progress_emitter:
                self._progress_emitter.refinement_scope_summary(
                    cycle=self._refinement_cycle_count,
                    scope_items=scope_items or total_items,
                    total_items=total_items or scope_items,
                    scope_mode=payload.get("scope_mode", "full"),
                    blocking_count=len(blocking),
                    prev_blocking_count=self._refinement_last_blocking_count if self._refinement_cycle_count > 1 else None,
                )
            self._refinement_last_blocking_count = len(blocking)
            return result
        if action == ActionType.REVISE:
            # ISSUE-HYBRID-055: Client-side iteration guard for REVISE.
            if server_action is not None:
                iteration = server_action.iteration
                effective_max = (
                    server_action.metadata.get("effective_max_refinement_iterations")
                )
                guard_max = effective_max or server_action.metadata.get(
                    "max_refinement_iterations"
                )
                if (
                    iteration is not None
                    and guard_max is not None
                    and iteration >= guard_max
                ):
                    logger.warning(
                        "ISSUE-HYBRID-055: Client-side iteration guard triggered "
                        "for REVISE — iteration %d >= max %d, returning unchanged "
                        "plan items",
                        iteration,
                        guard_max,
                    )
                    if self._production_logger:
                        self._production_logger.log_event(
                            "refinement_guard_triggered",
                            session_id=self._session_id,
                            action="revise",
                            examine_action_count=self._refinement_cycle_count,
                            iteration=iteration,
                            effective_max=guard_max,
                        )
                    return {"plan_items": payload.get("full_plan_items", []),
                            "iteration_limit_exceeded": True}

            # FEAT-REFINEMENT-PARALLEL-001: All REVISE actions route through
            # parallel batch fan-out.  Single-batch payloads execute with
            # 1 worker (no overhead).
            subphase_start = self._start_subphase("revise")
            batch_count = len(payload.get("batches", []))
            # ISSUE-HYBRID-034: Structured telemetry for revise start
            if self._production_logger:
                self._production_logger.log_event(
                    "revise_start",
                    session_id=self._session_id,
                    examine_action_count=self._refinement_cycle_count,
                    batch_count=batch_count,
                    issue_count=sum(
                        len(b.get("issues", []))
                        for b in payload.get("batches", [])
                    ),
                )

            # Process proposed defaults once and inject into each batch's
            # base_prompt before parallel fan-out.
            proposed_defaults = payload.get("proposed_defaults") or []
            try:
                if proposed_defaults:
                    confirmed_defaults = self._process_proposed_defaults(proposed_defaults)
                    for batch_dict in payload.get("batches", []):
                        batch_dict["base_prompt"] = self._inject_defaults_into_prompt(
                            batch_dict.get("base_prompt", ""),
                            confirmed_defaults,
                        )
                        batch_dict["proposed_defaults"] = confirmed_defaults
            except OrchestratorError:
                self._complete_subphase(
                    "revise",
                    subphase_start,
                    status="error",
                    error_message="defaults confirmation aborted",
                )
                raise

            try:
                result = self._handle_parallel_revise_batches(payload)
            except Exception as e:
                self._complete_subphase(
                    "revise", subphase_start, status="error", error_message=str(e)
                )
                if self._progress_emitter:
                    self._progress_emitter.parallel_batch_fallback(
                        "revise", error=str(e),
                    )
                if self._production_logger:
                    self._production_logger.log_event(
                        "revise_failed",
                        session_id=self._session_id,
                        examine_action_count=self._refinement_cycle_count,
                        batch_count=batch_count,
                        error_class=type(e).__name__,
                        error_message=str(e),
                    )
                if self._current_phase:
                    self._log_session_event(
                        "phase_failed",
                        phase=self._current_phase.value,
                        failure_stage="revise",
                        error_code="HANDLER_ERROR",
                        error_class=type(e).__name__,
                        error_message=str(e),
                        span_id=self._phase_span_id,
                        parent_span_id=self._pipeline_span_id,
                    )
                raise

            # Skip tracking on consolidated result.
            if self._is_skip_tracking_enabled("revision"):
                deferred = result.get("deferred_issues")
                created = 0
                # Build issue map from all batches for lookup.
                all_issues: dict[str, dict[str, Any]] = {}
                for batch_dict in payload.get("batches", []):
                    for issue in batch_dict.get("issues", []):
                        issue_id = str(issue.get("id", "")).strip()
                        if issue_id:
                            all_issues[issue_id] = issue

                if isinstance(deferred, list):
                    for item in deferred:
                        if not isinstance(item, dict):
                            continue
                        issue_id = str(item.get("id", "")).strip()
                        if not issue_id:
                            continue
                        reason_text = str(item.get("reason", "")).strip() or "Deferred by revision"
                        source_issue = all_issues.get(issue_id, {})
                        priority = str(source_issue.get("priority", "")).upper()
                        create_skip_record(
                            session_id=self._session_id or "",
                            task_id=issue_id,
                            source=SkipSource.REVISION,
                            reason=SkipReason.DEFERRED_CONCERN,
                            description=f"Deferred concern: {reason_text}",
                            source_context={
                                "priority": priority,
                                "issue": source_issue,
                                "deferred_reason": reason_text,
                            },
                        )
                        created += 1
                if created > 0:
                    logger.info("Run 'obra skips list' to review skipped items")

            self._complete_subphase("revise", subphase_start)
            # ISSUE-HYBRID-034: Structured telemetry for revise complete
            if self._production_logger:
                items_updated = len(result.get("plan_items", [])) if isinstance(result, dict) else 0
                self._production_logger.log_event(
                    "revise_complete",
                    session_id=self._session_id,
                    examine_action_count=self._refinement_cycle_count,
                    batch_count=batch_count,
                    items_updated=items_updated,
                )
            return result
        if action == ActionType.EXECUTE:
            execute_req = ExecutionRequest.from_payload(payload)
            subphase_start = self._start_subphase("execute")
            if hasattr(handler, "_parent_span_id"):
                handler._parent_span_id = self._subphase_span_id
            if execute_req.current_item and execute_req.current_item.get("id"):
                self._last_item_id = execute_req.current_item.get("id")

            # --continue-from: Skip items that were completed in the source session
            if self._skip_completed_items and execute_req.current_item:
                item_title = execute_req.current_item.get("title", "")
                if item_title in self._skip_completed_items:
                    logger.info(f"Skipping completed item: {item_title}")
                    self._emit_progress(
                        "item_skipped",
                        {
                            "item": execute_req.current_item,
                            "reason": "completed_in_previous_session",
                        },
                    )
                    self._log_session_event(
                        "item_skipped",
                        item=execute_req.current_item,
                        reason="completed_in_previous_session",
                        span_id=self._subphase_span_id,
                        parent_span_id=self._phase_span_id,
                    )
                    self._complete_subphase("execute", subphase_start, status="skipped")
                    item_id = execute_req.current_item.get("id", "")
                    if item_id:
                        self._skipped_item_ids.add(item_id)  # Track for review skip
                        if self._is_skip_tracking_enabled("orchestrator"):
                            create_skip_record(
                                session_id=self._session_id or "",
                                task_id=item_id,
                                source=SkipSource.ORCHESTRATOR,
                                reason=SkipReason.RESUME_RECOVERY,
                                description=f"Item {item_id} skipped (completed in previous session)",
                                source_context={
                                    "skip_type": "resume_recovery",
                                    "item_title": execute_req.current_item.get("title", ""),
                                },
                            )
                            logger.info("Run 'obra skips list' to review skipped items")
                    return {
                        "item_id": item_id,
                        "status": "success",  # ExecutionStatus.SUCCESS for previously completed items
                        "summary": f"Skipped (completed in previous session): {item_title}",
                        "files_changed": 0,
                        "tests_passed": True,
                    }

            # Skip non-leaf items (containers) in hierarchical plans
            if execute_req.current_item and execute_req.plan_items:
                if not self._is_leaf_item(execute_req.current_item, execute_req.plan_items):
                    item_title = execute_req.current_item.get("title", "")
                    logger.info("Skipping container item (non-leaf): %s", item_title)
                    self._emit_progress(
                        "item_skipped",
                        {
                            "item": execute_req.current_item,
                            "reason": "non_leaf_container",
                        },
                    )
                    self._log_session_event(
                        "item_skipped",
                        item=execute_req.current_item,
                        reason="non_leaf_container",
                        span_id=self._subphase_span_id,
                        parent_span_id=self._phase_span_id,
                    )
                    self._complete_subphase("execute", subphase_start, status="skipped")
                    item_id = execute_req.current_item.get("id", "")
                    if item_id:
                        self._skipped_item_ids.add(item_id)  # Track for review skip
                        if self._is_skip_tracking_enabled("orchestrator"):
                            create_skip_record(
                                session_id=self._session_id or "",
                                task_id=item_id,
                                source=SkipSource.ORCHESTRATOR,
                                reason=SkipReason.CONTAINER_EXECUTION,
                                description=f"Item {item_id} skipped (non-leaf container)",
                                source_context={
                                    "skip_type": "container",
                                    "item_title": execute_req.current_item.get("title", ""),
                                },
                            )
                            logger.info("Run 'obra skips list' to review skipped items")
                    return {
                        "item_id": item_id,
                        "status": "success",  # ExecutionStatus.SUCCESS for container items
                        "summary": f"Skipped container item: {item_title}",
                        "files_changed": 0,
                        "tests_passed": True,
                    }

            # Compatibility: some server versions return ActionType.EXECUTE with fix payload
            # (item_id + issues_to_fix) instead of ActionType.FIX. Route to FixHandler but report as FIX.
            if execute_req.current_item is None and payload.get("issues_to_fix"):
                fix_handler = self._get_handler(ActionType.FIX)
                if hasattr(fix_handler, "_parent_span_id"):
                    fix_handler._parent_span_id = self._subphase_span_id

                # Pass orchestrator's verification_tools to FixHandler to prevent redundant re-install
                if self._verification_tools and hasattr(fix_handler, "_verification_tools"):
                    available_tools = self._verification_tools.get("available", [])
                    if available_tools:
                        default_tool_configs: dict[str, dict[str, Any]] = {
                            "tests": {
                                "name": "tests",
                                "category": "tests",
                                "command": "pytest {files}",
                                "parser": "llm",
                                "patterns": ["test_*.py", "*_test.py"],
                            },
                            "lint": {
                                "name": "lint",
                                "category": "lint",
                                "command": "ruff check {files}",
                                "parser": "llm",
                                "patterns": ["*.py"],
                            },
                            "typecheck": {
                                "name": "typecheck",
                                "category": "typecheck",
                                "command": "mypy {files}",
                                "parser": "llm",
                                "patterns": ["*.py"],
                            },
                        }
                        tool_configs = [
                            default_tool_configs[cat]
                            for cat in available_tools
                            if cat in default_tool_configs
                        ]
                        if tool_configs:
                            fix_handler._verification_tools = tool_configs
                            logger.info(
                                "Passed %d verification tools to FixHandler (compat path): %s",
                                len(tool_configs),
                                [t["name"] for t in tool_configs],
                            )

                fix_req = FixRequest.from_payload(payload)
                try:
                    fix_result = cast(dict[str, Any], fix_handler.handle(fix_req))
                except Exception as e:
                    self._complete_subphase(
                        "execute",
                        subphase_start,
                        status="error",
                        error_message=str(e),
                    )
                    if self._current_phase:
                        self._log_session_event(
                            "phase_failed",
                            phase=self._current_phase.value,
                            failure_stage="execute",
                            error_code="HANDLER_ERROR",
                            error_class=type(e).__name__,
                            error_message=str(e),
                            span_id=self._phase_span_id,
                            parent_span_id=self._pipeline_span_id,
                        )
                    raise
                fix_result["_report_as"] = ActionType.FIX.value
                self._complete_subphase("execute", subphase_start)
                return fix_result

            # S3.T5: Emit item_started event
            # Issue #6: Use server-supplied execution_context for deduplication
            if execute_req.current_item:
                exec_ctx = execute_req.execution_context
                should_emit = True

                # Dedupe using execution_context if available
                if exec_ctx:
                    ctx_key = f"{exec_ctx.get('item_id')}:{exec_ctx.get('iteration')}:{exec_ctx.get('attempt')}"
                    if ctx_key in self._locally_started_items:
                        should_emit = False
                        logger.debug("Skipping local item_started (already emitted): %s", ctx_key)
                    else:
                        self._locally_started_items.add(ctx_key)

                if should_emit:
                    self._emit_progress(
                        "item_started",
                        {
                            "item": execute_req.current_item,
                            "execution_context": exec_ctx,
                        },
                    )
                    # ISSUE-OBS-002: Log item_started to production logger
                    self._log_session_event(
                        "item_started",
                        item=execute_req.current_item,
                        span_id=self._subphase_span_id,
                        parent_span_id=self._phase_span_id,
                    )

            try:
                result = cast(dict[str, Any], handler.handle(execute_req))
            except Exception as e:
                self._complete_subphase(
                    "execute", subphase_start, status="error", error_message=str(e)
                )
                if self._current_phase:
                    self._log_session_event(
                        "phase_failed",
                        phase=self._current_phase.value,
                        failure_stage="execute",
                        error_code="HANDLER_ERROR",
                        error_class=type(e).__name__,
                        error_message=str(e),
                        span_id=self._phase_span_id,
                        parent_span_id=self._pipeline_span_id,
                    )
                raise

            # S3.T5: Emit item_completed event
            if execute_req.current_item:
                # Track locally-completed items to prevent duplicate server-echo emissions
                item_id = execute_req.current_item.get("id")
                if item_id:
                    self._locally_completed_items.add(str(item_id))
                # FEAT-SESSION-CLOSEOUT-001: Increment items completed in this invocation
                self._items_completed_this_invocation += 1
                self._emit_progress(
                    "item_completed",
                    {"item": execute_req.current_item, "result": result},
                )
                # ISSUE-OBS-002: Log item_completed to production logger
                self._log_session_event(
                    "item_completed",
                    item=execute_req.current_item,
                    status=result.get("status", "unknown"),
                    files_changed=result.get("files_changed", 0),
                    span_id=self._subphase_span_id,
                    parent_span_id=self._phase_span_id,
                )

            self._complete_subphase("execute", subphase_start)
            return result
        if action == ActionType.REVIEW:
            review_payload = dict(payload)
            if not review_payload.get("item_id") and self._last_item_id:
                review_payload["item_id"] = self._last_item_id

            candidate_agents = review_payload.get("agents_to_run")
            if not candidate_agents:
                legacy_agents = review_payload.get("review_agents")
                if isinstance(legacy_agents, list):
                    candidate_agents = legacy_agents
            if isinstance(candidate_agents, list):
                sanitized_agents, dropped_agents = self._sanitize_review_agents_for_server(
                    candidate_agents
                )
            else:
                sanitized_agents, dropped_agents = self._sanitize_review_agents_for_server(None)

            if dropped_agents:
                logger.warning(
                    "Dropped unsupported review agents for current server contract: %s",
                    sorted(set(dropped_agents)),
                )
            review_payload["agents_to_run"] = sanitized_agents

            review_req = ReviewRequest.from_payload(review_payload)
            if review_req.item_id:
                self._last_item_id = review_req.item_id

            # Skip review for items that were skipped (containers or previously completed)
            # No code was executed, so no review is needed
            if review_req.item_id and review_req.item_id in self._skipped_item_ids:
                logger.info("Skipping review for skipped item: %s", review_req.item_id)
                subphase_start = self._start_subphase("review")
                self._complete_subphase("review", subphase_start, status="skipped")
                return {
                    "item_id": review_req.item_id,
                    "agent_reports": [
                        {
                            "agent_type": "code_quality",
                            "status": "pass",
                            "scores": {"code_quality": 1.0},
                            "issues": [],
                        }
                    ],
                    "iteration": 0,
                }

            subphase_start = self._start_subphase("review")
            if hasattr(handler, "_parent_span_id"):
                handler._parent_span_id = self._subphase_span_id
            try:
                result = cast(dict[str, Any], handler.handle(review_req))
            except Exception as e:
                self._complete_subphase(
                    "review", subphase_start, status="error", error_message=str(e)
                )
                if self._current_phase:
                    self._log_session_event(
                        "phase_failed",
                        phase=self._current_phase.value,
                        failure_stage="review",
                        error_code="HANDLER_ERROR",
                        error_class=type(e).__name__,
                        error_message=str(e),
                        span_id=self._phase_span_id,
                        parent_span_id=self._pipeline_span_id,
                    )
                raise
            self._complete_subphase("review", subphase_start)
            return result
        if action == ActionType.PIPELINE_STAGE:
            # Parse pipeline stage request from payload
            stage_req = PipelineStageRequest.from_payload(payload)

            logger.info(
                f"Executing pipeline stage '{stage_req.stage_name}' "
                f"at trigger '{stage_req.trigger}' "
                f"(iteration {stage_req.iteration}/{stage_req.max_iterations})"
            )

            subphase_start = self._start_subphase(f"stage_{stage_req.stage_name}")
            if hasattr(handler, "_parent_span_id"):
                handler._parent_span_id = self._subphase_span_id

            try:
                result = handler.handle(stage_req)
                # Convert PipelineStageResult to dict for server response
                result_dict = result.to_dict()
                self._complete_subphase(f"stage_{stage_req.stage_name}", subphase_start)
                return result_dict
            except Exception as e:
                self._complete_subphase(
                    f"stage_{stage_req.stage_name}",
                    subphase_start,
                    status="error",
                    error_message=str(e),
                )
                if self._current_phase:
                    self._log_session_event(
                        "phase_failed",
                        phase=self._current_phase.value,
                        failure_stage=f"stage_{stage_req.stage_name}",
                        error_code="STAGE_ERROR",
                        error_class=type(e).__name__,
                        error_message=str(e),
                        span_id=self._phase_span_id,
                        parent_span_id=self._pipeline_span_id,
                    )
                raise
        if action == ActionType.FIX:
            fix_payload = payload
            if not payload.get("item_id") and self._last_item_id:
                fix_payload = dict(payload)
                fix_payload["item_id"] = self._last_item_id
            fix_req = FixRequest.from_payload(fix_payload)
            if fix_req.item_id:
                self._last_item_id = fix_req.item_id

            # S0.T7: Check verification tools before FIX
            # If tools are missing and preflight not attempted, inject Story 0
            available_tools = (self._verification_tools or {}).get("available", [])
            missing_tools = (self._verification_tools or {}).get("missing", [])
            if not available_tools and not self._verification_preflight_attempted:
                logger.info("Verification tools missing before FIX - injecting Story 0 preflight")
                self._emit_progress(
                    "verification_preflight_triggered",
                    {
                        "message": (
                            "Verification tools missing. "
                            "Running Story 0 preflight to install required tooling."
                        ),
                        "missing_tools": missing_tools,
                    },
                )
                # Run Story 0 with verification_tools_missing reason
                story0_handler = self._get_handler(ActionType.STORY0)
                story0_result = self._dispatch_handler(
                    story0_handler,
                    ActionType.STORY0,
                    {
                        "story0_prerequisites": [],
                        "objective": self._objective or "",
                        "story0_resume_reason": "verification_tools_missing",
                        "missing_tools": missing_tools,
                    },
                )
                # Update verification tools from Story 0 result
                if story0_result and story0_result.get("verification_tools"):
                    self._verification_tools = story0_result["verification_tools"]
                    available_tools = self._verification_tools.get("available", [])
                    # Report to server so session.verification_tools is updated
                    try:
                        self._request_with_observability(
                            "POST",
                            "report_story0",
                            json={
                                "session_id": self._session_id,
                                "status": story0_result.get("status", "complete"),
                                "completed_prereqs": [],
                                "failed_prereqs": [],
                                "blocking_failures": [],
                                "non_blocking_failures": [],
                                "verification_tools": self._verification_tools,
                                "mocked_credentials": [],
                            },
                        )
                        logger.info(
                            "Reported injected Story 0 verification_tools to server: %s",
                            self._verification_tools,
                        )
                    except Exception as e:
                        logger.warning("Failed to report Story 0 to server: %s", e)
                if not available_tools:
                    logger.warning(
                        "Verification tools still missing after preflight - proceeding without"
                    )
                    self._emit_progress(
                        "verification_preflight_incomplete",
                        {
                            "message": (
                                "Verification tools still missing after preflight. "
                                "Proceeding with FIX but verification may be limited."
                            ),
                        },
                    )

            subphase_start = self._start_subphase("fix")
            if hasattr(handler, "_parent_span_id"):
                handler._parent_span_id = self._subphase_span_id

            # Pass orchestrator's verification_tools to FixHandler to prevent redundant re-install
            # Story 0 returns format: {"available": ["tests", "lint", "typecheck"], ...}
            # FixHandler expects: [{"name": "tests", "category": "tests", "command": "..."}, ...]
            if self._verification_tools and hasattr(handler, "_verification_tools"):
                available_tools = self._verification_tools.get("available", [])
                if available_tools:
                    # Convert category names to tool configs using FixHandler's defaults
                    # Map category to default tool config
                    fix_tool_configs: dict[str, dict[str, Any]] = {
                        "tests": {
                            "name": "tests",
                            "category": "tests",
                            "command": "pytest {files}",
                            "parser": "llm",
                            "patterns": ["test_*.py", "*_test.py"],
                        },
                        "lint": {
                            "name": "lint",
                            "category": "lint",
                            "command": "ruff check {files}",
                            "parser": "llm",
                            "patterns": ["*.py"],
                        },
                        "typecheck": {
                            "name": "typecheck",
                            "category": "typecheck",
                            "command": "mypy {files}",
                            "parser": "llm",
                            "patterns": ["*.py"],
                        },
                    }
                    tool_configs = [
                        fix_tool_configs[cat] for cat in available_tools if cat in fix_tool_configs
                    ]
                    if tool_configs:
                        handler._verification_tools = tool_configs
                        logger.info(
                            "Passed %d verification tools to FixHandler from Story 0: %s",
                            len(tool_configs),
                            [t["name"] for t in tool_configs],
                        )

            try:
                result = cast(dict[str, Any], handler.handle(fix_req))
            except Exception as e:
                self._complete_subphase("fix", subphase_start, status="error", error_message=str(e))
                if self._current_phase:
                    self._log_session_event(
                        "phase_failed",
                        phase=self._current_phase.value,
                        failure_stage="fix",
                        error_code="HANDLER_ERROR",
                        error_class=type(e).__name__,
                        error_message=str(e),
                        span_id=self._phase_span_id,
                        parent_span_id=self._pipeline_span_id,
                    )
                raise
            self._complete_subphase("fix", subphase_start)
            # CLI fix progress summary
            if self._progress_emitter and isinstance(result, dict):
                applied = sum(
                    1 for d in self._fix_result_history if d.get("status") == "applied"
                )
                failed = sum(
                    1 for d in self._fix_result_history if d.get("status") == "failed"
                )
                self._progress_emitter.review_fix_progress(
                    item_id=fix_req.item_id or self._last_item_id or "",
                    fixes_applied=applied,
                    fixes_failed=failed,
                )
            return result
        if action == ActionType.VALIDATOR:
            # FEAT-SENSECHECK-PIPELINE-001: Handle validator requests from server
            from obra.api.protocol import ValidatorRequest

            validator_req = ValidatorRequest.from_payload(payload)
            subphase_start = self._start_subphase(f"validator_{validator_req.stage}")
            if hasattr(handler, "_parent_span_id"):
                handler._parent_span_id = self._subphase_span_id

            try:
                result = handler.handle(validator_req)
                # Convert ValidatorResult to dict for server response
                result_dict = result.to_dict()
                self._complete_subphase(f"validator_{validator_req.stage}", subphase_start)
                return result_dict
            except Exception as e:
                self._complete_subphase(
                    f"validator_{validator_req.stage}",
                    subphase_start,
                    status="error",
                    error_message=str(e),
                )
                if self._current_phase:
                    self._log_session_event(
                        "phase_failed",
                        phase=self._current_phase.value,
                        failure_stage=f"validator_{validator_req.stage}",
                        error_code="VALIDATOR_ERROR",
                        error_class=type(e).__name__,
                        error_message=str(e),
                        span_id=self._phase_span_id,
                        parent_span_id=self._pipeline_span_id,
                    )
                raise
        msg = f"Unhandled action: {action.value}"
        raise OrchestratorError(
            msg,
            session_id=self._session_id or "",
        )

    def _handle_escalation(self, notice: EscalationNotice) -> dict[str, Any]:
        """Handle escalation by prompting user.

        Args:
            notice: Escalation notice from server

        Returns:
            User decision result
        """
        # FIX-ESCALATION-COMPLETION-001: Mark session as escalated
        # This prevents "Mission Complete!" celebration on force-completed escalations
        self._was_escalated = True

        # If callback provided, use it
        if self._on_escalation:
            result = self._on_escalation(notice)
            # FIX-HYBRID-052: Derive blocking count from convergence_diagnostic
            # when blocking_issues list is empty (common for convergence_stalled).
            blocking_count = len(notice.blocking_issues or [])
            if blocking_count == 0 and isinstance(notice.convergence_diagnostic, dict):
                sizes = notice.convergence_diagnostic.get(
                    "per_cycle_blocking_sizes", {}
                )
                if isinstance(sizes, dict) and sizes:
                    blocking_count = max(
                        (int(v) for v in sizes.values()), default=0
                    )
            esc_id = notice.escalation_id or f"esc-{uuid.uuid4().hex[:12]}"
            # ISSUE-HYBRID-046: Emit escalation decision event
            # Include fix failure context so production.jsonl captures why we escalated.
            failed_fixes = [
                fr for fr in self._fix_result_history if fr.get("status") == "failed"
            ]
            self._log_session_event(
                "escalation_decision",
                escalation_id=esc_id,
                decision=result.choice.value,
                reason=notice.reason.value,
                was_timeout=result.was_timeout,
                blocking_issues_count=blocking_count,
                fix_failure_summary={
                    "total_attempts": len(self._fix_result_history),
                    "failed": len(failed_fixes),
                    "recent_failures": failed_fixes[-5:],
                } if self._fix_result_history else None,
            )
            if self._progress_emitter:
                self._progress_emitter.escalation_summary(
                    reason=notice.reason.value,
                    fix_attempts=len(self._fix_result_history),
                    fix_results=failed_fixes[-5:] if failed_fixes else None,
                )
            return {
                "escalation_id": esc_id,
                "decision": result.choice.value,
                "reason": "",
            }

        # Default: display and force complete
        print_warning(f"Escalation: {notice.reason.value}")

        # Defensive check for blocking_issues structure
        blocking_issues = notice.blocking_issues
        if not isinstance(blocking_issues, list):
            logger.warning(
                f"Invalid blocking_issues type: expected list, got {type(blocking_issues).__name__}. "
                f"Converting to empty list."
            )
            blocking_issues = []
        else:
            # Ensure all items are dicts
            validated_issues = []
            for idx, issue in enumerate(blocking_issues):
                if not isinstance(issue, dict):
                    logger.warning(
                        f"Invalid blocking_issue at index {idx}: expected dict, got {type(issue).__name__}. "
                        f"Skipping item."
                    )
                else:
                    validated_issues.append(issue)
            blocking_issues = validated_issues

        console.print(f"  Blocking issues: {len(blocking_issues)}")
        for issue in blocking_issues[:5]:  # Show first 5
            priority = issue.get("priority", "P3")
            description = issue.get("description", "Unknown")
            console.print(f"    - \\[{priority}] {description}")

        # Show validated item count if available in iteration_history
        if notice.iteration_history:
            last_iteration = notice.iteration_history[-1] if notice.iteration_history else {}
            validated = last_iteration.get("validated_count")
            total = last_iteration.get("total_items")
            if validated is not None and total is not None:
                console.print(f"\n  Plan items validated: {validated} of {total}")

        convergence_diagnostic = (
            notice.convergence_diagnostic
            if isinstance(notice.convergence_diagnostic, dict)
            else {}
        )
        if convergence_diagnostic:
            console.print("\n  Convergence diagnostic:")

            raw_sizes = convergence_diagnostic.get("per_cycle_blocking_sizes", {})
            if isinstance(raw_sizes, dict) and raw_sizes:
                sorted_sizes = sorted(
                    (
                        (str(iteration), int(size))
                        for iteration, size in raw_sizes.items()
                    ),
                    key=lambda item: (
                        int(item[0]) if item[0].isdigit() else 10_000_000,
                        item[0],
                    ),
                )
                size_summary = ", ".join(
                    f"{iteration}:{size}" for iteration, size in sorted_sizes
                )
                console.print(f"    - Blocking sizes by cycle: {size_summary}")

            raw_persisted = convergence_diagnostic.get("persisted_issues", [])
            persisted_issues = (
                [str(issue_id) for issue_id in raw_persisted if str(issue_id).strip()]
                if isinstance(raw_persisted, list)
                else []
            )
            if persisted_issues:
                console.print(
                    "    - Persisted issues: "
                    + ", ".join(persisted_issues[:5])
                    + (" ..." if len(persisted_issues) > 5 else "")
                )

            raw_appeared = convergence_diagnostic.get("appeared_issues", [])
            appeared_issues = (
                [str(issue_id) for issue_id in raw_appeared if str(issue_id).strip()]
                if isinstance(raw_appeared, list)
                else []
            )
            if appeared_issues:
                console.print(
                    "    - Appeared during stale window: "
                    + ", ".join(appeared_issues[:5])
                    + (" ..." if len(appeared_issues) > 5 else "")
                )

        # Show --permissive tip for refinement-related escalations
        refinement_reasons = {
            EscalationReason.MAX_ITERATIONS,
            EscalationReason.MAX_REFINEMENT_ITERATIONS,
            EscalationReason.BLOCKED,
            EscalationReason.QUALITY_THRESHOLD_NOT_MET,
        }
        if notice.reason in refinement_reasons and blocking_issues:
            console.print("\n  [bold]Tip:[/bold] Use --permissive to bypass P1 issues and proceed.")
            console.print("       Or clarify your objective and retry, e.g.:")
            console.print('       "Add feature X (use library Y, handle errors with Z)"')

        # FIX-HYBRID-052: Derive blocking count from convergence_diagnostic
        # when blocking_issues list is empty (common for convergence_stalled).
        blocking_count = len(blocking_issues)
        if blocking_count == 0 and convergence_diagnostic:
            sizes = convergence_diagnostic.get("per_cycle_blocking_sizes", {})
            if isinstance(sizes, dict) and sizes:
                blocking_count = max(
                    (int(v) for v in sizes.values()), default=0
                )
        esc_id = notice.escalation_id or f"esc-{uuid.uuid4().hex[:12]}"

        # ISSUE-HYBRID-046: Emit escalation decision event
        # Include fix failure context so production.jsonl captures why we escalated.
        failed_fixes = [
            fr for fr in self._fix_result_history if fr.get("status") == "failed"
        ]
        self._log_session_event(
            "escalation_decision",
            escalation_id=esc_id,
            decision=UserDecisionChoice.FORCE_COMPLETE.value,
            reason=notice.reason.value,
            was_timeout=True,
            blocking_issues_count=blocking_count,
            fix_failure_summary={
                "total_attempts": len(self._fix_result_history),
                "failed": len(failed_fixes),
                "recent_failures": failed_fixes[-5:],
            } if self._fix_result_history else None,
        )
        if self._progress_emitter:
            self._progress_emitter.escalation_summary(
                reason=notice.reason.value,
                fix_attempts=len(self._fix_result_history),
                fix_results=failed_fixes[-5:] if failed_fixes else None,
            )

        return {
            "escalation_id": esc_id,
            "decision": UserDecisionChoice.FORCE_COMPLETE.value,
            "reason": "Auto-completed (no interactive handler)",
        }

    def _report_result(
        self,
        action: ActionType,
        result: dict[str, Any],
    ) -> ServerAction:
        """Report action result to server.

        Args:
            action: Action that was handled
            result: Result from handler

        Returns:
            Next server action
        """
        if not self._session_id:
            msg = "No active session"
            raise OrchestratorError(
                msg,
                error_context=self._build_error_context(action="report_result"),
            )

        # Validate supported action types before entering try block (TRY301)
        supported_actions = {
            ActionType.DERIVE,
            ActionType.INTENT,
            ActionType.STORY0,
            ActionType.STORY_PREFLIGHT,
            ActionType.EXAMINE,
            ActionType.REVISE,
            ActionType.EXECUTE,
            ActionType.REVIEW,
            ActionType.FIX,
            ActionType.ESCALATE,
            ActionType.VALIDATOR,  # FEAT-SENSECHECK-PIPELINE-001
        }
        if action not in supported_actions:
            msg = f"Cannot report result for action: {action.value}"
            raise OrchestratorError(
                msg,
                session_id=self._session_id,
                error_context=self._build_error_context(action="report_result"),
            )

        try:
            if action == ActionType.DERIVE:
                # Validate userplan info is available for DerivedPlan
                if not self._last_userplan_id or self._last_userplan_version is None:
                    msg = "Cannot report derivation: userplan_id and userplan_version required"
                    raise OrchestratorError(
                        msg,
                        session_id=self._session_id,
                        error_context=self._build_error_context(action="report_result"),
                    )

                # Merge preserved plan items with newly derived items for --from-step
                newly_derived_items = result.get("plan_items", [])
                final_plan_items = self._merge_plan_items_for_rederivation(
                    preserved_items=self._preserved_plan_items,
                    newly_derived_items=newly_derived_items,
                    from_step=self._derive_from_step,
                )
                final_plan_items_for_api = self._normalize_plan_items_for_api(final_plan_items)
                summarized_items, items_truncated = self._summarize_plan_items(final_plan_items)
                snapshot_ref = self._write_plan_snapshot(
                    session_id=self._session_id,
                    userplan_id=self._last_userplan_id,
                    userplan_version=self._last_userplan_version,
                    userplan_steps=self._read_plan_snapshot(self._session_id).get("userplan_steps"),
                    derived_plan_items=final_plan_items,
                )
                self._log_session_event(
                    "derived_plan_snapshot",
                    source="derive",
                    userplan_id=self._last_userplan_id,
                    userplan_version=self._last_userplan_version,
                    plan_items_count=len(final_plan_items),
                    plan_items=summarized_items,
                    truncated=items_truncated,
                    plan_snapshot_ref=snapshot_ref,
                )
                self._emit_progress(
                    "plan_snapshot",
                    {
                        "session_id": self._session_id,
                        "source": "derive",
                        "plan_items": final_plan_items,
                        "plan_items_count": len(final_plan_items),
                        "plan_snapshot_ref": snapshot_ref,
                    },
                )

                response = self._request_with_observability(
                    "POST",
                    "report_derivation",
                    json=DerivedPlan(
                        session_id=self._session_id,
                        userplan_id=self._last_userplan_id,
                        userplan_version=self._last_userplan_version,
                        plan_items=final_plan_items_for_api,
                        raw_response=result.get("raw_response", ""),
                        work_type=result.get("work_type"),
                        verification_tools=result.get("verification_tools"),
                        story0_prerequisites=result.get("story0_prerequisites"),
                    ).to_dict(),
                )

                # Update step statuses to DERIVED after successful derivation
                # This handles --from-step re-derivation status transitions
                if self._derive_from_step is not None:
                    try:
                        # Calculate which steps were re-derived (from_step onwards)
                        # The newly derived items are for steps from_step to N
                        total_steps = len(final_plan_items)
                        if total_steps > 0 and self._derive_from_step <= total_steps:
                            step_indices = list(range(self._derive_from_step, total_steps + 1))
                            self._client.update_userplan_steps_status_batch(
                                userplan_id=self._last_userplan_id,
                                step_indices=step_indices,
                                derivation_status="derived",
                            )
                            logger.info(
                                f"Marked steps {step_indices} as DERIVED for UserPlan {self._last_userplan_id}"
                            )
                    except Exception as status_err:
                        # Non-fatal: log warning but don't fail derivation
                        logger.warning(
                            f"Failed to update step statuses to DERIVED: {status_err}",
                            exc_info=True,
                        )
            elif action == ActionType.INTENT:
                intent_payload = {
                    "session_id": self._session_id,
                    "intent": result.get("intent", {}),
                    "intent_enrichment": result.get("intent_enrichment"),
                }
                if self._derive_from_step is not None:
                    intent_payload["from_step"] = self._derive_from_step
                response = self._request_with_observability(
                    "POST",
                    "report_intent",
                    json=intent_payload,
                )
            elif action == ActionType.STORY0:
                vtools = result.get("verification_tools")
                logger.info(
                    "Reporting Story 0 to server with verification_tools: %s",
                    vtools,
                )
                response = self._request_with_observability(
                    "POST",
                    "report_story0",
                    json={
                        "session_id": self._session_id,
                        "status": result.get("status", "complete"),
                        "completed_prereqs": result.get("completed_prereqs", []),
                        "failed_prereqs": result.get("failed_prereqs", []),
                        "blocking_failures": result.get("blocking_failures", []),
                        "non_blocking_failures": result.get("non_blocking_failures", []),
                        "verification_tools": vtools,
                        "mocked_credentials": result.get("mocked_credentials", []),
                    },
                )
            elif action == ActionType.STORY_PREFLIGHT:
                response = self._request_with_observability(
                    "POST",
                    "report_validator",
                    json={
                        "session_id": self._session_id,
                        "stage": "story_preflight",
                        **result,
                    },
                )
            elif action == ActionType.EXAMINE:
                response = self._request_with_observability(
                    "POST",
                    "report_examination",
                    json=ExaminationReport(
                        session_id=self._session_id,
                        iteration=result.get("iteration", 0),
                        issues=result.get("issues", []),
                        thinking_budget_used=result.get("thinking_budget_used", 0),
                        thinking_fallback=result.get("thinking_fallback", False),
                        raw_response=result.get("raw_response", ""),
                    ).to_dict(),
                )
            elif action == ActionType.REVISE:
                revised_items = result.get("plan_items", [])
                revised_items_for_api = self._normalize_plan_items_for_api(revised_items)

                # Determine batch position for progress semantics.
                # NOTE: single-batch revisions can still be scoped subsets, so we
                # merge against cached full plan snapshot for display consistency.
                batch_index_raw = self._last_action_payload.get("batch_index", 0)
                total_batches_raw = self._last_action_payload.get("total_batches", 0)
                try:
                    batch_index = int(batch_index_raw)
                except (TypeError, ValueError):
                    batch_index = 0
                try:
                    total_batches = int(total_batches_raw)
                except (TypeError, ValueError):
                    total_batches = 0
                if batch_index < 0:
                    batch_index = 0
                if total_batches < 1:
                    total_batches = 1
                is_final_or_single = total_batches <= 1 or batch_index >= total_batches - 1

                cache_session_id = getattr(self, "_revision_plan_cache_session_id", None)
                cache_items = getattr(self, "_revision_plan_cache", None)
                if (
                    cache_session_id != self._session_id
                    or batch_index == 0
                    or cache_items is None
                ):
                    snapshot = self._read_plan_snapshot(self._session_id)
                    cache_items = snapshot.get("derived_plan_items") or []
                    if not isinstance(cache_items, list):
                        cache_items = []
                    self._revision_plan_cache = cache_items
                    self._revision_plan_cache_session_id = self._session_id

                if self._revision_plan_cache:
                    merged_plan_items = self._merge_revision_batch(
                        self._revision_plan_cache,
                        revised_items,
                    )
                else:
                    merged_plan_items = list(revised_items)

                self._revision_plan_cache = merged_plan_items
                full_plan_items = merged_plan_items
                authoritative_snapshot_payload: dict[str, Any] | None = None

                if is_final_or_single:
                    self._revision_plan_cache = None
                    self._revision_plan_cache_session_id = None
                    snapshot_ref = self._write_plan_snapshot(
                        session_id=self._session_id,
                        userplan_steps=self._read_plan_snapshot(self._session_id).get(
                            "userplan_steps"
                        ),
                        derived_plan_items=full_plan_items,
                    )
                    summarized_items, items_truncated = self._summarize_plan_items(
                        full_plan_items
                    )
                    self._log_session_event(
                        "derived_plan_snapshot",
                        source="revise",
                        plan_items_count=len(full_plan_items),
                        plan_items=summarized_items,
                        truncated=items_truncated,
                        plan_snapshot_ref=snapshot_ref,
                    )
                    authoritative_snapshot_payload = {
                        "session_id": self._session_id,
                        "source": "revise",
                        "plan_items": full_plan_items,
                        "plan_items_count": len(full_plan_items),
                        "plan_snapshot_ref": snapshot_ref,
                        "mode": "authoritative",
                    }
                else:
                    summarized_items, items_truncated = self._summarize_plan_items(
                        revised_items
                    )
                    self._log_session_event(
                        "derived_plan_snapshot",
                        source="revise",
                        plan_items_count=len(revised_items),
                        plan_items=summarized_items,
                        truncated=items_truncated,
                    )
                    # Lighter progress event for intermediate batch
                    self._emit_progress(
                        "revision_batch_progress",
                        {
                            "batch_index": batch_index + 1,
                            "total_batches": total_batches,
                            "items_revised": len(revised_items),
                        },
                    )
                response = self._request_with_observability(
                    "POST",
                    "report_revision",
                    json=RevisedPlan(
                        session_id=self._session_id,
                        plan_items=revised_items_for_api,
                        addressed_issues=result.get("addressed_issues", []),
                        deferred_issues=result.get("deferred_issues", []),
                        changes_summary=result.get("changes_summary", ""),
                        raw_response=result.get("raw_response", ""),
                    ).to_dict(),
                )
                if authoritative_snapshot_payload is not None:
                    self._emit_progress("plan_snapshot", authoritative_snapshot_payload)
            elif action == ActionType.EXECUTE:
                item_id = result.get("item_id") or self._last_item_id or ""
                if not item_id:
                    logger.warning(
                        "Missing item_id for report_execution; using 'unknown' to satisfy schema."
                    )
                    item_id = "unknown"
                response = self._request_with_observability(
                    "POST",
                    "report_execution",
                    json=ExecutionResult(
                        session_id=self._session_id,
                        item_id=item_id,
                        status=ExecutionStatus(result.get("status", "failure")),
                        summary=result.get("summary", ""),
                        files_changed=result.get("files_changed", 0),
                        changed_file_paths=result.get("changed_file_paths", []),
                        tests_passed=result.get("tests_passed", False),
                        test_count=result.get("test_count", 0),
                        coverage_delta=result.get("coverage_delta", 0.0),
                        verification_tools=result.get("verification_tools"),
                        decomposition_suggested=result.get(
                            "decomposition_suggested",
                            False,
                        ),
                        decomposition_reason=result.get("decomposition_reason"),
                        partial_work_summary=result.get("partial_work_summary"),
                    ).to_dict(),
                )
            elif action == ActionType.REVIEW:
                agent_reports = result.get("agent_reports", [])
                item_id = result.get("item_id") or self._last_item_id or ""
                if not item_id:
                    logger.warning(
                        "Missing item_id for report_review; using 'unknown' to satisfy schema."
                    )
                    item_id = "unknown"
                # ISSUE-SAAS-015: Map client status values to server API contract
                # Client uses: complete, timeout, error, skipped (execution state)
                # Server expects: pass, fail, warning (quality assessment)
                status_mapping = {
                    "complete": "pass",  # Completed successfully = pass
                    "timeout": "warning",  # Timed out = warning (couldn't complete)
                    "error": "fail",  # Error = fail
                    "skipped": "pass",  # BUG-fad06fe5: Skipped (no files) = pass with 0 issues
                }
                mapped_reports = []
                for report in agent_reports:
                    mapped_report = dict(report)  # Shallow copy
                    client_status = mapped_report.get("status", "complete")
                    mapped_report["status"] = status_mapping.get(client_status, client_status)
                    mapped_reports.append(mapped_report)

                supported_agents = set(self._ordered_supported_review_agents())
                filtered_reports: list[dict[str, Any]] = []
                dropped_agent_types: list[str] = []
                for report in mapped_reports:
                    agent_type = str(report.get("agent_type", "")).strip()
                    if agent_type and agent_type in supported_agents:
                        filtered_reports.append(report)
                    else:
                        dropped_agent_types.append(agent_type or "<missing>")
                if dropped_agent_types:
                    logger.warning(
                        "Dropping unsupported report_review agent types: %s",
                        sorted(set(dropped_agent_types)),
                    )
                mapped_reports = filtered_reports

                # ISSUE-SAAS-052: Handle skip_review mode or empty agent_reports
                # Server schema requires min 1 agent report. When review is skipped
                # (--skip-review flag or no agents resolved), inject a synthetic
                # "code_quality" report with "pass" status to satisfy the contract.
                # ISSUE-HYBRID-005: Must include valid scores (non-empty) to produce
                # non-zero compiled_score on server, otherwise server returns WAIT.
                if not mapped_reports:
                    synthetic_agent = (
                        "code_quality"
                        if "code_quality" in supported_agents
                        else next(iter(supported_agents), "code_quality")
                    )
                    logger.info(
                        "Review skipped: injecting synthetic pass report for session %s",
                        self._session_id,
                    )
                    mapped_reports = [
                        {
                            "agent_type": synthetic_agent,
                            "status": "pass",
                            "scores": {synthetic_agent: 1.0},
                            "issues": [],
                        }
                    ]

                review_payload: dict[str, Any] = {
                    "session_id": self._session_id,
                    "item_id": item_id,
                    "agent_reports": mapped_reports,
                    "iteration": result.get("iteration", 0),
                }
                if self._progress_cursor:
                    review_payload["progress_cursor"] = self._progress_cursor
                response = self._request_with_observability(
                    "POST",
                    "report_review",
                    json=review_payload,
                )
            elif action == ActionType.FIX:
                fix_results = result.get("fix_results", [])
                item_id = result.get("item_id") or self._last_item_id or ""
                filtered_details = []
                dropped = 0

                # FIX-LOOP-RESILIENCE-001: Include failure context for retry feedback
                from obra.config.loaders import get_failure_context_max_chars

                max_ctx_chars = get_failure_context_max_chars()

                for fix_result in fix_results:
                    canonical_id = str(
                        fix_result.get("canonical_id") or fix_result.get("issue_id") or ""
                    ).strip()
                    issue_id = str(fix_result.get("issue_id") or canonical_id).strip()
                    if not canonical_id:
                        dropped += 1
                        continue
                    detail: dict[str, Any] = {
                        "issue_id": issue_id,
                        "canonical_id": canonical_id,
                        "status": fix_result.get("status", ""),
                        "reason": fix_result.get("reason", ""),
                        "summary": fix_result.get("summary", ""),
                    }
                    verification = (
                        fix_result.get("verification")
                        if isinstance(fix_result.get("verification"), dict)
                        else {}
                    )
                    for field in (
                        "verification_outcome",
                        "verification_scope",
                        "attribution_confidence",
                    ):
                        field_value = fix_result.get(field)
                        if not field_value and verification:
                            field_value = verification.get(field)
                        if field_value:
                            detail[field] = str(field_value)
                    # FIX-LOOP-RESILIENCE-001: Attach verification failure context
                    # so the server can include it in fix_history for retries.
                    if (
                        isinstance(verification, dict)
                        and detail["status"] == "failed"
                    ):
                        last_error = verification.get("last_tool_error", {})
                        failure_reason = verification.get("failure_reason", "")
                        if last_error or failure_reason:
                            error_output = str(
                                last_error.get("output", "")
                            )[:max_ctx_chars]
                            detail["failure_context"] = {
                                "tool": last_error.get("tool", ""),
                                "output": error_output,
                                "failure_reason": failure_reason,
                            }
                    filtered_details.append(detail)
                if dropped:
                    logger.warning(
                        "Dropped %d fix_details without canonical_id before report_fix.",
                        dropped,
                    )

                fixes_applied = sum(
                    1 for detail in filtered_details if detail.get("status") == "applied"
                )
                fixes_failed = sum(
                    1 for detail in filtered_details if detail.get("status") == "failed"
                )
                # Accumulate fix results for escalation summary context.
                for detail in filtered_details:
                    self._fix_result_history.append({
                        "issue_id": detail.get("canonical_id", detail.get("id", "")),
                        "status": detail.get("status", "unknown"),
                        "reason": detail.get("reason", ""),
                        "verification_scope": detail.get("verification_scope", ""),
                        "verification_command": (
                            detail.get("failure_context", {}).get("tool", "")
                            if isinstance(detail.get("failure_context"), dict) else ""
                        ),
                    })
                fix_payload = FixReport(
                    session_id=self._session_id,
                    item_id=item_id,  # ISSUE-SAAS-021: Include for fix-review loop
                    fixes_applied=fixes_applied,
                    fixes_failed=fixes_failed,
                    fix_details=filtered_details,
                    progress_cursor=self._progress_cursor,
                ).to_dict()
                response = self._request_with_observability(
                    "POST",
                    "report_fix",
                    json=fix_payload,
                )
            elif action == ActionType.VALIDATOR:
                # FEAT-SENSECHECK-PIPELINE-001: Report validator result to server
                validator_payload: dict[str, Any] = {
                    "session_id": self._session_id,
                    **result,  # Pass full ValidatorResult fields
                }
                if self._progress_cursor:
                    validator_payload["progress_cursor"] = self._progress_cursor
                response = self._request_with_observability(
                    "POST",
                    "report_validator",
                    json=validator_payload,
                )
            else:  # action == ActionType.ESCALATE (validated above)
                response = self._request_with_observability(
                    "POST",
                    "user_decision",
                    json=UserDecision(
                        session_id=self._session_id,
                        escalation_id=result.get("escalation_id", ""),
                        decision=UserDecisionChoice(result.get("decision", "force_complete")),
                        reason=result.get("reason", ""),
                    ).to_dict(),
                )

            if isinstance(response, dict):
                self._handle_progress_events_from_response(response)
                response = self._sanitize_server_action_response(response)

            server_action = ServerAction.from_dict(response)
            self._display_bypass_notices(server_action)
            return server_action

        except APIError:
            raise
        except Exception as e:
            msg = f"Failed to report result: {e}"
            raise OrchestratorError(
                msg,
                session_id=self._session_id,
                error_context=self._build_error_context(action="report_result"),
            ) from e

    def _sanitize_server_action_response(self, response: dict[str, Any]) -> dict[str, Any]:
        """Drop non-ServerAction fields from API responses."""
        allowed_keys = {
            "action",
            "session_id",
            "iteration",
            "payload",
            "metadata",
            "bypass_modes_active",
            "error_code",
            "error_message",
            "timestamp",
            "rationale",
        }
        return {key: value for key, value in response.items() if key in allowed_keys}

    def _parse_polling_action_response(
        self,
        response: dict[str, Any],
        iteration: int,
    ) -> ServerAction:
        """Parse polling responses from get_session_action into ServerAction.

        Supports both full ServerAction payloads and the polling shape:
        {action, reason, confidence, status}.
        """
        if "session_id" in response:
            sanitized = self._sanitize_server_action_response(response)
            return ServerAction.from_dict(sanitized)

        if "action" in response and "status" in response:
            logger.info(
                "Polling response missing session_id; adapting to ServerAction "
                "(action=%s, status=%s).",
                response.get("action"),
                response.get("status"),
            )
            action_value = str(response.get("action", ActionType.WAIT.value)).strip().lower()
            adapted_payload: dict[str, Any] = {"polling": response}
            if action_value == ActionType.ESCALATE.value:
                raw_details = response.get("escalation_details", {})
                escalation_details = raw_details if isinstance(raw_details, dict) else {}
                adapted_payload = {
                    "polling": response,
                    "reason": response.get("reason", "blocked"),
                    "reason_code": response.get("reason_code", ""),
                    "reason_text": response.get("reason_text", response.get("reason", "")),
                    "blocking_issues": response.get("blocking_issues", []),
                    "invariant_errors": response.get("invariant_errors", []),
                    "repair_attempt_history": response.get("repair_attempt_history", []),
                    "iteration_history": response.get("iteration_history", []),
                    "options": response.get("options", []),
                    "convergence_diagnostic": response.get("convergence_diagnostic", {}),
                    "escalation_id": response.get("escalation_id", ""),
                    "escalation_details": escalation_details,
                }
            adapted = {
                "action": response.get("action", ActionType.WAIT.value),
                "session_id": self._session_id or "",
                "iteration": iteration,
                "payload": adapted_payload,
                "metadata": {"polling_adapted": True},
            }
            return ServerAction.from_dict(adapted)

        msg = f"Unexpected polling response shape: {response}"
        raise OrchestratorError(
            msg,
            session_id=self._session_id or "unknown",
        )

    def _handle_progress_events_from_response(self, response: dict[str, Any]) -> None:
        """Extract and route progress events from server response to progress callback.

        This method enables progress dashboard features in SaaS mode by:
        1. Extracting progress_events array from get_session_action response
        2. Routing each event to the on_progress callback
        3. Gracefully handling malformed events (skip and log)

        Related:
            - ISSUE-CLI-023: Progress dashboard features not visible in SaaS mode
            - docs/quality/investigations/ISSUE-CLI-023_RCA.md
            - tests/hybrid/test_saas_progress_events.py

        Args:
            response: Server response dict (from get_session_action)
        """
        progress_cursor = response.get("progress_cursor")
        if isinstance(progress_cursor, str) and progress_cursor:
            self._progress_cursor = progress_cursor

        if not self._on_progress:
            # No progress callback registered, nothing to do
            return

        progress_events = response.get("progress_events", [])
        if not progress_events:
            # No events in response (backward compatibility)
            return

        # ISSUE-HYBRID-023: Skip historical events on resume
        # On first poll after resume, skip events from before resume started
        skip_before_timestamp = self._resume_start_timestamp
        skipped_count = 0
        if skip_before_timestamp:
            # Clear after first use - subsequent polls should show all new events
            self._resume_start_timestamp = None

        dedupe_skipped = 0
        for event_data in progress_events:
            # ISSUE-HYBRID-023: Skip events older than resume start
            if skip_before_timestamp:
                event_timestamp = event_data.get("timestamp")
                if event_timestamp and event_timestamp < skip_before_timestamp:
                    skipped_count += 1
                    continue

            try:
                # Validate event has required fields
                if "event_type" not in event_data:
                    logger.warning(
                        "Skipping progress event with missing event_type: %s",
                        event_data,
                    )
                    continue

                event_type = event_data["event_type"]
                payload = event_data.get("payload", {})

                # Deduplicate item_completed events that were already emitted locally
                # (server echoes back item_completed for items we just completed)
                if event_type == "item_completed":
                    item = payload.get("item", {})
                    item_id = item.get("id") if isinstance(item, dict) else None
                    if item_id and str(item_id) in self._locally_completed_items:
                        dedupe_skipped += 1
                        continue

                # Issue #6: Deduplicate item_started events using execution_context
                # Prevents spurious "Executing X" messages during fix-review loops
                if event_type == "item_started":
                    exec_ctx = payload.get("execution_context")
                    if exec_ctx:
                        # Server-supplied context - dedupe by composite key
                        ctx_key = f"{exec_ctx.get('item_id')}:{exec_ctx.get('iteration')}:{exec_ctx.get('attempt')}"
                        if ctx_key in self._locally_started_items:
                            dedupe_skipped += 1
                            logger.debug("Skipping duplicate item_started: %s", ctx_key)
                            continue
                        self._locally_started_items.add(ctx_key)
                    # Legacy events without context fall through to event_id dedup

                # Deduplicate phase_completed events that were already emitted locally
                # Server stores phase_completed with duration_ms=0, duplicating local emission
                if event_type == "phase_completed":
                    phase_raw = payload.get("phase")
                    phase = str(phase_raw).strip().lower() if phase_raw else ""
                    duration_ms_raw = payload.get("duration_ms")
                    try:
                        duration_ms = int(duration_ms_raw) if duration_ms_raw is not None else 0
                    except (TypeError, ValueError):
                        duration_ms = 0

                    # Skip server echoes for phases already completed locally.
                    if phase and phase in self._locally_completed_phases:
                        dedupe_skipped += 1
                        logger.debug("Skipping duplicate phase_completed: %s", phase)
                        continue
                    # Skip non-authoritative zero-duration phase completion while the
                    # client is still in that phase; local transition emits authoritative
                    # duration at the phase boundary.
                    if (
                        phase
                        and self._current_phase is not None
                        and phase == self._current_phase.value
                        and duration_ms <= 0
                    ):
                        dedupe_skipped += 1
                        logger.debug(
                            "Skipping non-authoritative phase_completed echo: %s (duration_ms=%s)",
                            phase,
                            duration_ms_raw,
                        )
                        continue

                # Deduplicate phase_started events already emitted locally
                if event_type == "phase_started":
                    phase_raw = payload.get("phase")
                    phase = str(phase_raw).strip().lower() if phase_raw else ""
                    if phase and phase in self._locally_started_phases:
                        dedupe_skipped += 1
                        logger.debug("Skipping duplicate phase_started: %s", phase)
                        continue
                    if phase:
                        self._locally_started_phases.add(phase)

                # Deduplicate by event_id to prevent double-emission of same server event
                event_id = event_data.get("event_id")
                if event_id:
                    if event_id in self._processed_event_ids:
                        dedupe_skipped += 1
                        continue
                    # Add to processed set (with LRU eviction if needed)
                    self._processed_event_ids.add(event_id)
                    self._processed_event_ids_queue.append(event_id)
                    if len(self._processed_event_ids_queue) > self._processed_event_ids_max:
                        evicted = self._processed_event_ids_queue.popleft()
                        self._processed_event_ids.discard(evicted)

                # Route to progress callback
                # The callback will route to ProgressEmitter methods (item_started, heartbeat, etc.)
                self._on_progress(event_type, payload)

            except Exception as e:
                # Log and skip malformed events, don't break polling loop
                logger.warning(
                    "Failed to process progress event: %s (error: %s)",
                    event_data,
                    e,
                    exc_info=True,
                )

        # ISSUE-HYBRID-023: Log skipped events count
        if skipped_count > 0:
            logger.debug(
                "Skipped %d historical progress events from before resume",
                skipped_count,
            )

    def _get_session_action_endpoint(self) -> str:
        """Build get_session_action endpoint with optional progress cursor."""
        if not self._session_id:
            return "get_session_action"

        params: dict[str, str] = {"session_id": self._session_id}
        if self._progress_cursor:
            params["progress_cursor"] = self._progress_cursor
        return f"get_session_action?{urlencode(params)}"

    def derive(
        self,
        objective: str,
        working_dir: Path | None = None,
        project_id: str | None = None,
        max_iterations: int | None = None,
        plan_id: str | None = None,
        plan_only: bool = False,
        bypass_modes: list[str] | None = None,
        skip_completed_items: list[str] | None = None,
        userplan_id: str | None = None,
        from_step: int | None = None,
        work_type: str | None = None,
    ) -> CompletionNotice:
        """Start a new derivation session.

        This is the main entry point for the hybrid orchestration loop.
        It creates a new session, derives a plan, refines it, executes
        the plan items, runs quality review, and completes the session.

        Args:
            objective: Task objective to plan and execute
            working_dir: Working directory (overrides instance default)
            project_id: Optional project ID override
            llm_provider: LLM provider to use
            max_iterations: Maximum orchestration loop iterations (None = use config)
            plan_id: Optional reference to uploaded plan (for plan import workflow)
            plan_only: If True, stop before execution once plan is ready (default: False)
            skip_completed_items: List of task titles to skip (for --continue-from recovery)
            userplan_id: Optional UserPlan ID (for plan file import - S2.T3)
            from_step: Re-derive from step N onwards (1-indexed), preserving earlier steps
            work_type: Manual work type override (bypasses auto-detection when provided)

        Returns:
            CompletionNotice with session summary

        Raises:
            ConnectionError: If server is not reachable
            OrchestratorError: If orchestration fails
        """
        if bypass_modes is not None:
            self._bypass_modes = bypass_modes

        self._objective = objective

        # Store skip_completed_items for --continue-from recovery
        self._skip_completed_items = skip_completed_items or []

        # Store from_step for incremental re-derivation
        self._from_step = from_step

        # Store work_type override for DeriveHandler
        self._work_type_override = work_type

        # FIX-PROJID-002: CLI must provide validated project_id - no auto-detection
        # If project_id is None here, CLI validation was bypassed (direct API call)
        if project_id is None:
            msg = (
                "project_id is required. CLI must validate project_id against server "
                "before calling orchestrator. Use 'obra projects select' to set a default."
            )
            raise OrchestratorError(
                msg, recovery="Run 'obra projects list' to see available projects"
            )

        self._project_id = project_id
        self._project_name = self._resolve_project_name(project_id)

        # Resolve max_iterations from config if not provided
        if max_iterations is None:
            max_iterations = get_max_iterations()

        # Update working dir if provided
        if working_dir:
            self._working_dir = working_dir

        # S2.T1: Run git preflight check before starting session
        # GIT-HARD-001: Validate git repository before orchestration begins
        self._git_preflight()

        # Ensure we can reach the server
        self._ensure_online()

        # Gather project context
        project_context = self._get_project_context()
        project_hash = self._hash_working_dir()

        # Get client version
        try:
            from obra import __version__ as client_version
        except ImportError:
            client_version = "0.0.0-dev"

        # Initialize trace context for end-to-end observability
        if not self._trace_id:
            self._trace_id = uuid.uuid4().hex
        self._pipeline_span_id = uuid.uuid4().hex
        self._pipeline_start_time = time.time()
        try:
            self._client.set_trace_context(self._trace_id, span_id=self._pipeline_span_id)
        except Exception:
            logger.debug("Failed to set trace context on API client", exc_info=True)
        self._event_logger.set_trace_context(self._trace_id, span_id=self._pipeline_span_id)

        # Set project context for all subsequent log events
        if project_id:
            self._event_logger.set_project(project_id, self._project_name)

        # Log pipeline start for end-to-end timing
        self._log_session_event(
            "pipeline_started",
            objective=objective[:200] if len(objective) > 200 else objective,
            working_dir=str(self._working_dir),
            project_id=project_id,
            project_name=self._project_name,
            client_version=client_version,
            span_id=self._pipeline_span_id,
        )
        self._log_resource_snapshot("pipeline_start")

        # CLI-CACHE-MONITOR-001: Check CLI cache health before session
        self._check_cli_cache_health("pre_session")

        # Start session
        print_info("Starting session...")
        logger.info(f"Starting session: {objective}")

        # Build effective LLM map from role-based config resolution
        effective_map = self._build_effective_llm_map()
        self._effective_llm_map = effective_map

        # Run provider preflight checks
        self._preflight_results = self._run_provider_preflight(effective_map)

        try:
            response = self._request_with_observability(
                "POST",
                "hybrid_orchestrate",
                json=SessionStart(
                    objective=objective,
                    project_hash=project_hash,
                    working_dir=str(self._working_dir),
                    project_id=project_id,
                    project_context=project_context,
                    client_version=client_version,
                    effective_llm_map=effective_map,
                    plan_id=plan_id,
                    userplan_id=userplan_id,
                    bypass_modes=bypass_modes or self._bypass_modes,
                    from_step=from_step,
                    quality_policy_mode=self._resolve_quality_policy_mode(),
                ).to_dict(),
            )
        except APIError as e:
            msg = f"Failed to start session: {e}"
            raise OrchestratorError(
                msg,
                recovery="Check your authentication with 'obra whoami'",
                error_context=self._build_error_context(action="start_session"),
            ) from e

        # Parse server response
        server_action = ServerAction.from_dict(response)
        self._session_id = server_action.session_id
        if self._progress_emitter:
            self._progress_emitter.set_session_id(self._session_id)

        # ISSUE-OBS-004: Set work_unit_id for event correlation
        # This enables work_unit_id to appear in all subsequent events in hybrid.jsonl
        self._event_logger.set_work_unit(self._session_id)

        # Initialize production logger with session_id for detailed metrics
        # Writes derivation/quality metrics to resolved runtime logs/production.jsonl
        self._production_logger = get_production_logger(session_id=self._session_id)
        # FIX-HYBRID-053: Wire production logger into event logger for forwarding
        if self._production_logger:
            self._event_logger._production_logger = self._production_logger

        # FEAT-SESSION-CLOSEOUT-001: Initialize invocation tracking
        self._invocation_id = str(uuid.uuid4())
        self._invocation_start_time = time.time()
        self._items_completed_this_invocation = 0
        self._was_interrupted = False

        # Start session console logging for feedback system
        try:
            from obra.feedback import start_session_logging

            start_session_logging(self._session_id)
            logger.debug(f"Session console logging started: {self._session_id}")
        except Exception as e:
            # Don't fail orchestration if session logging fails
            logger.warning(f"Failed to start session console logging: {e}")

        self._display_bypass_notices(server_action)

        # Extract and store server-side LLM validation results
        server_validation = server_action.metadata.get("llm_validation", {})
        self._server_validation = server_validation

        # Fail-fast on tier mismatch unless --skip-tier-check is active
        skip_tier_check = "skip_tier_check" in (
            bypass_modes or self._bypass_modes or []
        )
        mismatches: list[str] = []
        for stage, result in server_validation.items():
            if result.get("status") == "tier_mismatch":
                client_tier = effective_map.get(stage, {}).get("tier", "unknown")
                server_tier = result.get("server_tier", "unknown")
                mismatches.append(
                    f"  {stage}: client={client_tier}, server={server_tier}"
                )
                logger.warning(
                    "Server tier mismatch for %s: client=%s, server=%s",
                    stage,
                    client_tier,
                    server_tier,
                )

        if mismatches and not skip_tier_check:
            mismatch_detail = "\n".join(mismatches)
            raise OrchestratorError(
                f"Server tier mismatch detected:\n{mismatch_detail}\n\n"
                "Quality policy would use incorrect tiers. "
                "Fix: Update your config or model registry. "
                "Run 'obra config show llm' to inspect.\n"
                "Bypass: Use --skip-tier-check to proceed anyway.",
                session_id=self._session_id,
                error_context=self._build_error_context(action="tier_validation"),
            )

        project_notice = server_action.metadata.get("project_notice")
        if project_notice:
            print_info(project_notice)
        project_warning = server_action.metadata.get("project_warning")
        if project_warning:
            print_warning(project_warning)

        self._session_start_contract_warnings = self._extract_session_start_contract_warnings(
            server_action.metadata
        )
        self._emit_session_start_contract_warnings(self._session_start_contract_warnings)

        if server_action.is_error():
            raise OrchestratorError(
                server_action.error_message or "Failed to start session",
                session_id=self._session_id,
                error_context=self._build_error_context(action="start_session"),
            )

        logger.info(f"Session started: {self._session_id}")
        console.print(f"Session: [cyan]{self._session_id}[/cyan]")
        print_info("Pipeline: starting")

        # ISSUE-OBS-002: Log session_started event for observability
        quality_tier = effective_map.get("execute", {}).get("tier", "medium")
        self._log_session_event(
            "session_started",
            objective=objective,
            working_dir=str(self._working_dir),
            plan_id=plan_id,
            project_id=project_id,
            project_name=self._project_name,
            client_version=client_version,
            quality_tier=quality_tier,
        )

        # Emit runtime environment banner (log paths + backend target)
        self._emit_runtime_banner()

        # Emit full LLM Pipeline Models banner (post-session, with server validation)
        self._emit_llm_pipeline_banner(effective_map, server_validation)

        # FEAT-SESSION-GUARD-001: Start session guard for zombie prevention
        self._session_guard = SessionGuard(
            session_id=self._session_id or "unknown",
            working_dir=self._working_dir,
            on_warning=self._handle_session_timeout_warning,
        )
        self._session_guard.start()

        # Main orchestration loop
        iteration = 0
        poll_count = 0  # Track consecutive WAIT responses for backoff
        stall_iterations = 0  # Consecutive non-progress iterations (excludes WAIT)
        loop_error: OrchestratorError | None = None  # TRY301: Track errors to raise outside try
        try:
            while True:
                iteration += 1
                logger.debug(f"Orchestration loop iteration {iteration}")

                # FEAT-SESSION-GUARD-001: Check session timeout (may prompt user)
                if self._session_guard and self._session_guard.check_timeout():
                    loop_error = OrchestratorError(
                        f"Session terminated: runtime exceeded {self._session_guard.max_hours}h limit",
                        session_id=self._session_id or "",
                        recovery="Use OBRA_SESSION_MAX_HOURS to increase limit if needed",
                    )
                    break

                # CLI-CACHE-MONITOR-001: Mid-session cache check every 10 iterations
                if iteration % 10 == 0:
                    self._check_cli_cache_health("mid_session")

                # Handle current action
                progress_before = self._progress_snapshot(server_action.action)
                result = self._handle_action(server_action)

                # FEAT-SESSION-GUARD-001: Update session guard with progress
                if self._session_guard:
                    try:
                        heartbeat_iteration = int(server_action.iteration)
                    except (TypeError, ValueError):
                        heartbeat_iteration = iteration
                    self._session_guard.update(
                        iteration=heartbeat_iteration,
                        items_completed=self._items_completed_this_invocation,
                        phase=(self._current_phase.value if self._current_phase else "unknown"),
                    )

                # Check for completion
                if result.get("completed"):
                    notice = result.get("notice")
                    if isinstance(notice, CompletionNotice):
                        if not notice.terminal_phase:
                            notice.terminal_phase = (
                                self._current_phase.value if self._current_phase else "unknown"
                            )
                        if self._was_escalated and not notice.was_escalated:
                            notice.was_escalated = True
                        logger.info(f"Session completed: {self._session_id}")
                        # ISSUE-OBS-002: Log session_completed event
                        self._log_session_event(
                            "session_completed",
                            items_completed=notice.items_completed,
                            total_iterations=notice.total_iterations,
                            quality_score=notice.quality_score,
                        )
                        # FIX-COMPLETION-001: Emit progress event for celebration message
                        # FIX-ESCALATION-COMPLETION-001: Include was_escalated to skip celebration
                        self._emit_progress(
                            "session_completed",
                            {
                                "items_completed": notice.items_completed,
                                "total_iterations": notice.total_iterations,
                                "quality_score": notice.quality_score,
                                "session_summary": notice.session_summary,
                                "was_escalated": self._was_escalated,
                            },
                        )
                        self._log_pipeline_completed()
                        self._cleanup_story0_containers()
                        return self._append_session_start_contract_warnings(notice)
                    # Create notice from result if not already
                    # FEAT-SESSION-CLOSEOUT-001 S4.T4: Populate enhanced closeout fields
                    duration_s = (
                        time.time() - self._invocation_start_time
                        if self._invocation_start_time
                        else 0.0
                    )
                    notice = CompletionNotice(
                        session_summary=result.get("session_summary", ""),
                        items_completed=result.get("items_completed", 0),
                        total_iterations=result.get("total_iterations", iteration),
                        quality_score=result.get("quality_score", 0.0),
                        was_escalated=self._was_escalated,
                        terminal_phase=(
                            self._current_phase.value if self._current_phase else "unknown"
                        ),
                        # Enhanced closeout fields
                        objective=self._objective or "",
                        work_summary=self._extract_work_summary(),
                        duration_seconds=duration_s,
                        total_duration_seconds=result.get("total_duration_seconds", duration_s),
                        invocation_count=result.get("invocation_count", 1),
                        files_created=self._get_created_files(),
                        files_modified=self._get_modified_files(),
                        git_branch=self._get_git_branch(),
                        git_commit_hash=self._get_git_commit(),
                        termination_reason=result.get("termination_reason", ""),
                        warnings=result.get("warnings", []),
                    )
                    # ISSUE-OBS-002: Log session_completed event for alternate completion path
                    self._log_session_event(
                        "session_completed",
                        items_completed=notice.items_completed,
                        total_iterations=notice.total_iterations,
                        quality_score=notice.quality_score,
                    )
                    # FIX-COMPLETION-001: Emit progress event for celebration message
                    # FIX-ESCALATION-COMPLETION-001: Include was_escalated to skip celebration
                    self._emit_progress(
                        "session_completed",
                        {
                            "items_completed": notice.items_completed,
                            "total_iterations": notice.total_iterations,
                            "quality_score": notice.quality_score,
                            "session_summary": notice.session_summary,
                            "was_escalated": self._was_escalated,
                        },
                    )
                    self._log_pipeline_completed()
                    self._cleanup_story0_containers()
                    return self._append_session_start_contract_warnings(notice)

                # Check for waiting (async processing)
                if result.get("waiting"):
                    self._poll_with_backoff(poll_count)
                    poll_count += 1
                    # ISSUE-HYBRID-003: Check for stalls during polling
                    self._check_stall()
                    # Poll server for updated action
                    # ISSUE-009 Bug #3: Use query param format (not path param)
                    # Cloud Functions routing: get_session_action?session_id={id}
                    try:
                        response = self._request_with_observability(
                            "GET",
                            self._get_session_action_endpoint(),
                        )
                        # ISSUE-CLI-023: Extract and route progress events to client
                        self._handle_progress_events_from_response(response)

                        server_action = self._parse_polling_action_response(
                            response,
                            iteration,
                        )
                        self._display_bypass_notices(server_action)
                        # Reset failure count on successful poll
                        self._polling_failure_count = 0
                    except APIError as e:
                        # Increment failure counter
                        self._polling_failure_count += 1

                        # ISSUE-CLI-012: Fast-fail on non-retryable errors (404, 401, 403)
                        # These errors indicate endpoint doesn't exist or auth failure
                        if hasattr(e, "status_code") and e.status_code in (
                            404,
                            401,
                            403,
                        ):
                            logger.exception(
                                f"Polling endpoint returned non-retryable error {e.status_code}. "
                                f"Session: {self._session_id}, "
                                f"Endpoint likely does not exist or auth failed. "
                                f"Error: {e}"
                            )
                            msg = (
                                f"Polling endpoint failed with non-retryable error (HTTP {e.status_code}). "
                                f"The get_session_action?session_id={self._session_id} endpoint may not exist or requires authentication. "
                                f"Original error: {e}"
                            )
                            short_id = self._session_id.split("-")[0] if self._session_id else ""
                            raise OrchestratorError(
                                msg,
                                session_id=self._session_id,
                                recovery=f"Check server logs for endpoint availability. Resume with: {get_message('recovery.session.resume', short_id=short_id)}",
                                error_context=self._build_error_context(action="derive"),
                            ) from e

                        # Log warning on each failure
                        logger.warning(
                            f"Polling backoff exception (attempt {self._polling_failure_count}): {e}"
                        )

                        # After 5 consecutive failures, log error with diagnostics
                        if self._polling_failure_count >= 5:
                            logger.exception(
                                f"Polling endpoint failed {self._polling_failure_count} consecutive times. "
                                f"Session: {self._session_id}, "
                                f"Poll count: {poll_count}, "
                                f"Iteration: {iteration}, "
                                f"Last error: {e}"
                            )

                        # ISSUE-CLI-012: Circuit breaker - exit after max retries
                        if self._polling_failure_count >= MAX_POLLING_RETRIES:
                            logger.exception(
                                f"Polling circuit breaker triggered after {MAX_POLLING_RETRIES} consecutive failures. "
                                f"Session: {self._session_id}, "
                                f"Last error: {e}"
                            )
                            short_id = self._session_id.split("-")[0] if self._session_id else ""
                            msg = (
                                f"Polling endpoint failed after {MAX_POLLING_RETRIES} consecutive attempts. "
                                f"Session: {self._session_id}. "
                                f"This may indicate the endpoint does not exist or the server is not responding. "
                                f"Last error: {e}"
                                f"\n\nTry: {get_message('recovery.session.repair', short_id=short_id)}"
                            )
                            raise OrchestratorError(
                                msg,
                                session_id=self._session_id,
                                recovery=f"Check server logs for endpoint availability. Resume with: {get_message('recovery.session.resume', short_id=short_id)}",
                                error_context=self._build_error_context(action="derive"),
                            ) from e

                        # Continue with current action if polling endpoint not available
                    continue
                # Reset poll count when not waiting
                poll_count = 0

                # Report result and get next action
                report_as = result.pop("_report_as", None)
                action_to_report = (
                    ActionType(report_as)
                    if isinstance(report_as, str) and report_as
                    else server_action.action
                )
                server_action = self._report_result(action_to_report, result)
                if interrupt_requested():
                    self._log_session_event(
                        "session_interrupted",
                        reason=interrupt_reason() or "sigint",
                        session_id=self._session_id,
                    )
                    msg = "post_action_report"
                    raise GracefulInterrupt(msg)

                # Plan-only mode: stop before execution once plan is ready.
                if plan_only and server_action.action in (
                    ActionType.EXECUTE,
                    ActionType.REVIEW,
                    ActionType.FIX,
                ):
                    if action_to_report == ActionType.REVISE:
                        plan_summary = result.get("changes_summary", "Plan revised")
                        items_count = len(result.get("plan_items", []))
                    elif action_to_report == ActionType.EXAMINE:
                        issues_count = len(result.get("issues", []))
                        plan_summary = f"Plan examined with {issues_count} issue(s)"
                        items_count = 0
                    else:
                        plan_summary = "Plan-only mode: stopping before execution"
                        items_count = len(result.get("plan_items", []))

                    # FEAT-SESSION-CLOSEOUT-001 S4.T4: Populate enhanced closeout fields
                    plan_duration_s = (
                        time.time() - self._invocation_start_time
                        if self._invocation_start_time
                        else 0.0
                    )
                    notice = CompletionNotice(
                        session_summary=f"Plan-only mode: {plan_summary}",
                        items_completed=0,
                        total_iterations=iteration,
                        quality_score=0.0,
                        was_escalated=self._was_escalated,
                        terminal_phase=(
                            self._current_phase.value if self._current_phase else "unknown"
                        ),
                        # Enhanced closeout fields
                        objective=self._objective or "",
                        work_summary=[f"Plan derived with {items_count} item(s)"],
                        duration_seconds=plan_duration_s,
                        total_duration_seconds=plan_duration_s,
                        invocation_count=1,
                        files_created=[],
                        files_modified=[],
                        git_branch=self._get_git_branch(),
                        git_commit_hash="",  # No commit in plan-only mode
                        termination_reason="",
                        warnings=[],
                    )

                    logger.info(f"Plan-only session completed: {self._session_id}")
                    self._log_session_event(
                        "session_completed",
                        plan_only=True,
                        plan_items_count=items_count,
                        total_iterations=iteration,
                    )
                    self._log_pipeline_completed()
                    self._cleanup_story0_containers()
                    return self._append_session_start_contract_warnings(notice)

                # Check for error response
                if server_action.is_error():
                    loop_error = OrchestratorError(
                        server_action.error_message or "Server returned error",
                        session_id=self._session_id,
                    )
                    break

                if self._detect_progress(progress_before, server_action.action, result):
                    stall_iterations = 0
                else:
                    stall_iterations += 1
                    if stall_iterations >= max_iterations:
                        error_message = (
                            "Orchestration loop exceeded "
                            f"{max_iterations} consecutive non-progress iterations"
                        )
                        # Emit session_failed before raising so log viewer can display termination reason
                        self._log_session_event(
                            "session_failed",
                            error_code="MAX_ITERATIONS",
                            error_class="OrchestratorError",
                            error_message=error_message,
                            phase=(self._current_phase.value if self._current_phase else "unknown"),
                        )
                        if self._is_skip_tracking_enabled("orchestrator"):
                            current_item_id = getattr(self, "_last_item_id", "") or "unknown"
                            create_skip_record(
                                session_id=self._session_id or "",
                                task_id=current_item_id,
                                source=SkipSource.ORCHESTRATOR,
                                reason=SkipReason.MAX_ITERATIONS,
                                description=(
                                    "Execution terminated at max non-progress iterations "
                                    "with work remaining"
                                ),
                                source_context={
                                    "iteration": iteration,
                                    "stall_iterations": stall_iterations,
                                    "max_iterations": max_iterations,
                                },
                            )
                            logger.info("Run 'obra skips list' to review skipped items")
                        short_id = self._session_id.split("-")[0] if self._session_id else ""
                        loop_error = OrchestratorError(
                            error_message,
                            session_id=self._session_id,
                            recovery=(
                                "This may indicate a bug. Resume with: "
                                f"{get_message('recovery.session.resume', short_id=short_id)}"
                            ),
                        )
                        break

            # Unexpected loop exit - set error to raise outside try block (TRY301)
            if loop_error is None:
                error_message = "Orchestration loop exited unexpectedly"
                # Emit session_failed before raising so log viewer can display termination reason
                self._log_session_event(
                    "session_failed",
                    error_code="ORCHESTRATOR_ERROR",
                    error_class="OrchestratorError",
                    error_message=error_message,
                    phase=(self._current_phase.value if self._current_phase else "unknown"),
                )
                short_id = self._session_id.split("-")[0] if self._session_id else ""
                loop_error = OrchestratorError(
                    error_message,
                    session_id=self._session_id,
                    recovery=f"This may indicate a bug. Resume with: {get_message('recovery.session.resume', short_id=short_id)}",
                )
        except Exception as e:
            error_message = str(e)
            error_class = type(e).__name__
            self._log_session_event(
                "pipeline_failed",
                failure_stage=(self._current_phase.value if self._current_phase else "unknown"),
                error_code="ORCHESTRATOR_ERROR",
                error_class=error_class,
                error_message=error_message,
                span_id=self._pipeline_span_id,
            )
            if self._current_phase:
                self._log_session_event(
                    "phase_failed",
                    phase=self._current_phase.value,
                    failure_stage="orchestration_loop",
                    error_code="ORCHESTRATOR_ERROR",
                    error_class=error_class,
                    error_message=error_message,
                    span_id=self._phase_span_id,
                    parent_span_id=self._pipeline_span_id,
                )
            # ISSUE-OBS-003: Emit session_failed to properly close session lifecycle
            self._log_session_event(
                "session_failed",
                error_code="ORCHESTRATOR_ERROR",
                error_class=error_class,
                error_message=error_message,
                phase=self._current_phase.value if self._current_phase else "unknown",
            )
            self._cleanup_story0_containers()
            raise
        finally:
            # FEAT-SESSION-GUARD-001: Stop session guard
            if self._session_guard:
                self._session_guard.stop()
                self._session_guard = None

            # ISSUE-HYBRID-035: Close HTTP session to release CLOSE_WAIT sockets
            if hasattr(self._client, "close"):
                try:
                    self._client.close()
                except Exception:
                    logger.debug("HTTP client close failed", exc_info=True)

            # FEAT-SESSION-CLOSEOUT-001: Record invocation for cumulative runtime tracking
            if self._invocation_id and self._invocation_start_time:
                duration = time.time() - self._invocation_start_time
                phase_reached = self._current_phase.value if self._current_phase else "unknown"
                self._record_invocation(
                    invocation_id=self._invocation_id,
                    started_at=self._invocation_start_time,
                    duration_seconds=duration,
                    termination=self._get_termination_type(),
                    phase_reached=phase_reached,
                    items_completed=self._items_completed_this_invocation,
                )

        # TRY301: Raise loop error outside try block
        if loop_error is not None:
            self._cleanup_story0_containers()
            raise loop_error
        return None

    def resume(self, session_id: str) -> CompletionNotice:
        """Resume an interrupted session.

        Args:
            session_id: Session ID to resume

        Returns:
            CompletionNotice with session summary

        Raises:
            ConnectionError: If server is not reachable
            OrchestratorError: If session cannot be resumed
        """
        self._ensure_online()

        # ISSUE-HYBRID-023: Mark resume start time to skip historical progress events
        from datetime import datetime

        self._resume_start_timestamp = datetime.now(UTC).isoformat()

        # Initialize trace context for resumed run
        if not self._trace_id:
            self._trace_id = uuid.uuid4().hex
        self._pipeline_span_id = uuid.uuid4().hex
        self._pipeline_start_time = time.time()
        try:
            self._client.set_trace_context(self._trace_id, span_id=self._pipeline_span_id)
        except Exception:
            logger.debug("Failed to set trace context on API client", exc_info=True)
        self._event_logger.set_trace_context(self._trace_id, span_id=self._pipeline_span_id)

        self._log_session_event(
            "pipeline_started",
            objective="resume_session",
            working_dir=str(self._working_dir),
            resumed_session_id=session_id,
            span_id=self._pipeline_span_id,
        )
        self._log_resource_snapshot("pipeline_start")

        # CLI-CACHE-MONITOR-001: Check CLI cache health before session
        self._check_cli_cache_health("pre_session")

        # Get session state (supports short IDs - ISSUE-SAAS-044 fix)
        try:
            response = self._client.get_session(session_id)
            resume_payload: dict[str, Any] = {}
            if isinstance(response, dict):
                resume_payload.update(response)
                nested_context = response.get("resume_context")
                if isinstance(nested_context, dict):
                    resume_payload.update(nested_context)
            resume_context = ResumeContext.from_dict(resume_payload)
            self._objective = response.get("objective") if isinstance(response, dict) else None
        except APIError as e:
            if e.status_code == HTTPStatus.NOT_FOUND.value:
                msg = f"Session not found: {session_id}"
                raise OrchestratorError(
                    msg,
                    recovery="The session may have expired. Start a new session with 'obra derive'",
                    error_context=self._build_error_context(action="resume"),
                ) from e
            raise

        if not resume_context.can_resume:
            # Build detailed message with status, reason, and recovery guidance
            status = response.get("status", resume_context.status.value)
            escalation_reason = response.get("escalation_reason")

            def _is_unknown(value: str) -> bool:
                normalized = value.strip().lower()
                return normalized in {
                    "unknown",
                    "unknown state",
                    "unknown action",
                    "unknown status",
                }

            # Get progress info from plan if available
            progress_info = ""
            try:
                plan_data = self._client.get_session_plan(session_id)
                completed = plan_data.get("completed_count", 0)
                total = plan_data.get("total_count", 0)
                if total > 0:
                    progress_info = f"Progress: {completed}/{total} tasks completed"
            except Exception:
                pass  # Progress info is optional

            # Build message parts
            if status == "completed":
                error_parts = ["Session is completed and cannot be resumed."]
            else:
                error_parts = [f"Session cannot be resumed (status: {status})"]

            if escalation_reason:
                error_parts.append(f"Reason: {escalation_reason}")
            if resume_context.last_successful_step and not _is_unknown(
                resume_context.last_successful_step
            ):
                error_parts.append(f"Last step: {resume_context.last_successful_step}")
            if resume_context.pending_action and not _is_unknown(resume_context.pending_action):
                error_parts.append(f"Pending action: {resume_context.pending_action}")
            if resume_context.awaiting_message and not _is_unknown(resume_context.awaiting_message):
                error_parts.append(f"Awaiting: {resume_context.awaiting_message}")
            if progress_info:
                error_parts.append(progress_info)

            error_message = "\n".join(error_parts)

            # Build recovery suggestion
            short_id = session_id[:8] if len(session_id) > 8 else session_id
            recovery_lines = []
            if resume_context.resume_instructions:
                recovery_lines.append(resume_context.resume_instructions)
            if status in ("escalated", "completed"):
                recovery_lines.append(
                    "To continue from the last checkpoint (reuses prior outputs):"
                )
                recovery_lines.append(f"  obra run --continue-from {short_id}")
            else:
                recovery_lines.append("Check session status:")
                recovery_lines.append(f"  obra status --session-id {short_id}")
            recovery_lines.append("To start fresh:")
            recovery_lines.append('  obra run "<objective>"')
            if status == "completed":
                recovery_lines.append(
                    "If this was unexpected, check session status or contact support with the session ID."
                )
            recovery = "\n".join(recovery_lines)

            error_cls = SessionCompletedInfo if status == "completed" else OrchestratorError
            raise error_cls(
                error_message,
                session_id=session_id,
                recovery=recovery,
                error_context=self._build_error_context(action="resume"),
            )

        # Use full session ID from response (in case short ID was provided)
        full_session_id = response.get("session_id", session_id)
        self._session_id = full_session_id
        if self._progress_emitter:
            self._progress_emitter.set_session_id(self._session_id)

        # ISSUE-OBS-004: Set work_unit_id for event correlation in resume flow
        self._event_logger.set_work_unit(self._session_id)

        # Set project context for log events (from session or auto-detect from working_dir)
        project_id = response.get("project_id")
        if not project_id and self._working_dir:
            try:
                from obra.intent.storage import IntentStorage

                storage = IntentStorage()
                project_id = storage.get_project_id(self._working_dir)
                logger.debug("Auto-detected project_id from working_dir: %s", project_id)
            except Exception as e:
                logger.debug("Could not auto-detect project_id: %s", e)

        if project_id:
            project_name = response.get("project_name") or self._resolve_project_name(project_id)
            self._project_id = project_id
            self._project_name = project_name
            self._event_logger.set_project(project_id, project_name)

        # Initialize production logger with session_id for detailed metrics (resume flow)
        self._production_logger = get_production_logger(session_id=self._session_id)
        # FIX-HYBRID-053: Wire production logger into event logger for forwarding
        if self._production_logger:
            self._event_logger._production_logger = self._production_logger

        # FEAT-SESSION-CLOSEOUT-001: Initialize invocation tracking
        self._invocation_id = str(uuid.uuid4())
        self._invocation_start_time = time.time()
        self._items_completed_this_invocation = 0
        self._was_interrupted = False

        console.print(f"Resuming session: [cyan]{full_session_id}[/cyan]")
        print_info(f"  Last step: {resume_context.last_successful_step}")

        self._log_session_event(
            "session_resumed",
            resumed_from=resume_context.last_successful_step,
            resumed_from_phase=(
                resume_context.current_phase.value if resume_context.current_phase else None
            ),
        )

        # Request resume from server
        try:
            resume_request: dict[str, Any] = {"session_id": full_session_id}
            if self._bypass_modes:
                resume_request["bypass_modes"] = self._bypass_modes
            response = self._request_with_observability(
                "POST",
                "resume",
                json=resume_request,
            )
        except APIError as e:
            response_preview = ""
            if e.response_body:
                response_preview = str(e.response_body).strip()
                if len(response_preview) > 300:
                    response_preview = f"{response_preview[:300]}..."
            recovery_lines = [e.recovery]
            if response_preview:
                recovery_lines.append(f"Server response: {response_preview}")
            if self._trace_id:
                recovery_lines.append(f"Trace ID: {self._trace_id}")
            recovery = "\n".join(recovery_lines)
            msg = f"Failed to resume session: {e}"
            raise OrchestratorError(
                msg,
                session_id=session_id,
                recovery=recovery,
                error_context=self._build_error_context(action="resume"),
            ) from e

        if not isinstance(response, dict):
            msg = "Resume response invalid (expected object)."
            raise OrchestratorError(
                msg,
                session_id=session_id,
                recovery=f"Check session status:\n  obra status --session-id {session_id[:8]}",
                error_context=self._build_error_context(action="resume"),
            )

        allowed_keys = {
            "action",
            "session_id",
            "iteration",
            "payload",
            "metadata",
            "bypass_modes_active",
            "error_code",
            "error_message",
            "timestamp",
            "rationale",
        }
        if "action" not in response:
            try:
                poll_response = self._request_with_observability(
                    "GET",
                    self._get_session_action_endpoint(),
                )
            except Exception as e:
                poll_response = None
                poll_error: Exception | None = e
            else:
                poll_error = None

            if isinstance(poll_response, dict):
                self._handle_progress_events_from_response(poll_response)
                if "action" in poll_response and "session_id" in poll_response:
                    sanitized_response = {
                        key: value for key, value in poll_response.items() if key in allowed_keys
                    }
                    try:
                        server_action = ServerAction.from_dict(sanitized_response)
                        self._display_bypass_notices(server_action)
                    except ValueError as e:
                        poll_error = e
                else:
                    try:
                        server_action = self._parse_polling_action_response(
                            poll_response,
                            iteration=0,
                        )
                        self._display_bypass_notices(server_action)
                    except Exception as e:
                        poll_error = e
            else:
                poll_error = poll_error or OrchestratorError(
                    "Resume polling response invalid (expected object).",
                    session_id=session_id,
                )

            if poll_error is not None:
                recovered_action: ServerAction | None = None
                if resume_context.current_phase == SessionPhase.REVIEW:
                    try:
                        events_payload = self._client.get_session_events(
                            session_id=full_session_id,
                            limit=50,
                        )
                        events = events_payload.get("events", [])
                    except Exception:
                        events = []
                    item_id = None
                    if isinstance(events, list):
                        for event in reversed(events):
                            if not isinstance(event, dict):
                                continue
                            event_type = event.get("event_type") or event.get("type")
                            if event_type not in ("item_completed", "item_started"):
                                continue
                            item = event.get("item")
                            if isinstance(item, dict):
                                item_id = item.get("id") or item.get("item_id")
                            if not item_id:
                                item_id = event.get("item_id")
                            if item_id:
                                break
                    if item_id:
                        recovered_action = ServerAction.from_dict(
                            {
                                "action": ActionType.REVIEW.value,
                                "session_id": full_session_id,
                                "iteration": response.get("iteration", 0),
                                "payload": {"item_id": item_id},
                            }
                        )

                if recovered_action is not None:
                    server_action = recovered_action
                else:
                    status_value = response.get("status", resume_context.status.value)
                    if not isinstance(status_value, str):
                        status_value = str(status_value)
                    short_id = session_id[:8] if len(session_id) > 8 else session_id
                    recovery_lines = []
                    if resume_context.resume_instructions:
                        recovery_lines.append(resume_context.resume_instructions)
                    if status_value in ("escalated", "completed"):
                        recovery_lines.append("To continue from the last checkpoint:")
                        recovery_lines.append(f"  obra run --continue-from {short_id}")
                    else:
                        recovery_lines.append("Check session status:")
                        recovery_lines.append(f"  obra status --session-id {short_id}")
                    recovery_lines.append("To start fresh:")
                    recovery_lines.append('  obra run "<objective>"')
                    msg = f"Resume response missing required action (status: {status_value})."
                    raise OrchestratorError(
                        msg,
                        session_id=session_id,
                        recovery="\n".join(recovery_lines),
                    ) from poll_error
        else:
            sanitized_response = {
                key: value for key, value in response.items() if key in allowed_keys
            }
            try:
                server_action = ServerAction.from_dict(sanitized_response)
                self._display_bypass_notices(server_action)
            except ValueError as e:
                short_id = session_id[:8] if len(session_id) > 8 else session_id
                msg = f"Resume response invalid: {e}"
                raise OrchestratorError(
                    msg,
                    session_id=session_id,
                    recovery=f"Check session status:\n  obra status --session-id {short_id}",
                ) from e

        # Restore _last_item_id for REVIEW action if not in payload
        # This enables the fallback at line ~1982 when server doesn't include item_id
        if server_action.action == ActionType.REVIEW and not server_action.payload.get("item_id"):
            item_id = None
            # Try 1: Get from session events
            try:
                events_payload = self._client.get_session_events(
                    session_id=full_session_id,
                    limit=50,
                )
                events = events_payload.get("events", [])
            except Exception:
                events = []
            if isinstance(events, list):
                for event in reversed(events):
                    if not isinstance(event, dict):
                        continue
                    event_type = event.get("event_type") or event.get("type")
                    if event_type not in ("item_completed", "item_started"):
                        continue
                    item = event.get("item")
                    if isinstance(item, dict):
                        item_id = item.get("id") or item.get("item_id")
                    if not item_id:
                        item_id = event.get("item_id")
                    if item_id:
                        break

            # Try 2: Get from session plan (last completed or in_progress item)
            if not item_id:
                try:
                    plan_data = self._client.get_session_plan(full_session_id)
                    plan_items = plan_data.get("plan_items", [])
                    # Find the last completed or in_progress item
                    for plan_item in reversed(plan_items):
                        if isinstance(plan_item, dict):
                            status = plan_item.get("status", "")
                            if status in ("completed", "in_progress"):
                                item_id = plan_item.get("id") or plan_item.get("item_id")
                                if item_id:
                                    logger.debug(
                                        "Restored item_id from session plan: %s",
                                        item_id,
                                    )
                                    break
                except Exception:
                    pass

            if item_id:
                self._last_item_id = item_id
                logger.debug("Restored _last_item_id from recovery: %s", item_id)

        # Continue orchestration loop from resume point
        iteration = 0
        poll_count = 0  # Track consecutive WAIT responses for backoff
        stall_iterations = 0  # Consecutive non-progress iterations (excludes WAIT)
        max_iterations = get_max_iterations()
        resume_loop_error: OrchestratorError | None = (
            None  # TRY301: Track errors to raise outside try
        )
        try:
            while True:
                iteration += 1

                # CLI-CACHE-MONITOR-001: Mid-session cache check every 10 iterations
                if iteration % 10 == 0:
                    self._check_cli_cache_health("mid_session")

                progress_before = self._progress_snapshot(server_action.action)
                result = self._handle_action(server_action)

                # Keep local heartbeat aligned with server-side refinement iteration.
                if self._session_guard:
                    try:
                        heartbeat_iteration = int(server_action.iteration)
                    except (TypeError, ValueError):
                        heartbeat_iteration = iteration
                    self._session_guard.update(
                        iteration=heartbeat_iteration,
                        items_completed=self._items_completed_this_invocation,
                        phase=(self._current_phase.value if self._current_phase else "unknown"),
                    )

                if result.get("completed"):
                    notice = result.get("notice")
                    if isinstance(notice, CompletionNotice):
                        if not notice.terminal_phase:
                            notice.terminal_phase = (
                                self._current_phase.value if self._current_phase else "unknown"
                            )
                        if self._was_escalated and not notice.was_escalated:
                            notice.was_escalated = True
                        self._log_session_event(
                            "session_completed",
                            items_completed=notice.items_completed,
                            total_iterations=notice.total_iterations,
                            quality_score=notice.quality_score,
                        )
                        self._emit_progress(
                            "session_completed",
                            {
                                "items_completed": notice.items_completed,
                                "total_iterations": notice.total_iterations,
                                "quality_score": notice.quality_score,
                                "session_summary": notice.session_summary,
                                "was_escalated": self._was_escalated,
                            },
                        )
                        self._log_pipeline_completed()
                        self._cleanup_story0_containers()
                        return self._append_session_start_contract_warnings(notice)
                    self._log_session_event(
                        "session_completed",
                        items_completed=result.get("items_completed", 0),
                        total_iterations=result.get("total_iterations", iteration),
                        quality_score=result.get("quality_score", 0.0),
                    )
                    self._emit_progress(
                        "session_completed",
                        {
                            "items_completed": result.get("items_completed", 0),
                            "total_iterations": result.get("total_iterations", iteration),
                            "quality_score": result.get("quality_score", 0.0),
                            "session_summary": result.get("session_summary", ""),
                            "was_escalated": self._was_escalated,
                        },
                    )
                    self._log_pipeline_completed()
                    self._cleanup_story0_containers()
                    # FEAT-SESSION-CLOSEOUT-001 S4.T4: Populate enhanced closeout fields
                    resume_duration_s = (
                        time.time() - self._invocation_start_time
                        if self._invocation_start_time
                        else 0.0
                    )
                    return self._append_session_start_contract_warnings(
                        CompletionNotice(
                        session_summary=result.get("session_summary", ""),
                        items_completed=result.get("items_completed", 0),
                        total_iterations=result.get("total_iterations", iteration),
                        quality_score=result.get("quality_score", 0.0),
                        was_escalated=self._was_escalated,
                        terminal_phase=(
                            self._current_phase.value if self._current_phase else "unknown"
                        ),
                        # Enhanced closeout fields
                        objective=self._objective or "",
                        work_summary=self._extract_work_summary(),
                        duration_seconds=resume_duration_s,
                        total_duration_seconds=result.get(
                            "total_duration_seconds", resume_duration_s
                        ),
                        invocation_count=result.get("invocation_count", 1),
                        files_created=self._get_created_files(),
                        files_modified=self._get_modified_files(),
                        git_branch=self._get_git_branch(),
                        git_commit_hash=self._get_git_commit(),
                        termination_reason=result.get("termination_reason", ""),
                        warnings=result.get("warnings", []),
                        )
                    )

                if result.get("waiting"):
                    self._poll_with_backoff(poll_count)
                    poll_count += 1
                    # ISSUE-HYBRID-003: Check for stalls during polling
                    self._check_stall()
                    # Poll server for updated action
                    # ISSUE-009 Bug #3: Use query param format (not path param)
                    # Cloud Functions routing: get_session_action?session_id={id}
                    try:
                        response = self._request_with_observability(
                            "GET",
                            self._get_session_action_endpoint(),
                        )
                        self._handle_progress_events_from_response(response)
                        server_action = self._parse_polling_action_response(
                            response,
                            iteration=iteration,
                        )
                        # Reset failure count on successful poll
                        self._polling_failure_count = 0
                    except APIError as e:
                        # Increment failure counter
                        self._polling_failure_count += 1

                        # ISSUE-CLI-012: Fast-fail on non-retryable errors (404, 401, 403)
                        if hasattr(e, "status_code") and e.status_code in (
                            404,
                            401,
                            403,
                        ):
                            logger.exception(
                                f"Resume polling endpoint returned non-retryable error {e.status_code}. "
                                f"Session: {self._session_id}, Error: {e}"
                            )
                            msg = (
                                f"Resume polling endpoint failed with non-retryable error (HTTP {e.status_code}). "
                                f"Original error: {e}"
                            )
                            short_id = self._session_id.split("-")[0] if self._session_id else ""
                            raise OrchestratorError(
                                msg,
                                session_id=self._session_id,
                                recovery=f"Check server logs. Resume with: {get_message('recovery.session.resume', short_id=short_id)}",
                            ) from e

                        # ISSUE-CLI-012: Circuit breaker - exit after max retries
                        if self._polling_failure_count >= MAX_POLLING_RETRIES:
                            logger.exception(
                                f"Resume polling circuit breaker triggered after {MAX_POLLING_RETRIES} failures. "
                                f"Session: {self._session_id}, Last error: {e}"
                            )
                            short_id = self._session_id.split("-")[0] if self._session_id else ""
                            msg = (
                                f"Resume polling failed after {MAX_POLLING_RETRIES} attempts. "
                                f"Last error: {e}"
                            )
                            raise OrchestratorError(
                                msg,
                                session_id=self._session_id,
                                recovery=f"Check server status. Resume with: {get_message('recovery.session.resume', short_id=short_id)}",
                            ) from e

                        # If polling endpoint not available, continue with current action
                        logger.warning(
                            f"Resume polling attempt {self._polling_failure_count} failed: {e}"
                        )
                    continue
                # Reset poll count when not waiting
                poll_count = 0

                server_action = self._report_result(server_action.action, result)
                if interrupt_requested():
                    self._log_session_event(
                        "session_interrupted",
                        reason=interrupt_reason() or "sigint",
                        session_id=self._session_id,
                    )
                    msg = "post_action_report"
                    raise GracefulInterrupt(msg)

                if server_action.is_error():
                    resume_loop_error = OrchestratorError(
                        server_action.error_message or "Server returned error",
                        session_id=self._session_id,
                    )
                    break

                if self._detect_progress(progress_before, server_action.action, result):
                    stall_iterations = 0
                else:
                    stall_iterations += 1
                    if stall_iterations >= max_iterations:
                        error_message = (
                            "Orchestration loop exceeded "
                            f"{max_iterations} consecutive non-progress iterations"
                        )
                        # Emit session_failed before raising so log viewer can display termination reason
                        self._log_session_event(
                            "session_failed",
                            error_code="MAX_ITERATIONS",
                            error_class="OrchestratorError",
                            error_message=error_message,
                            phase=(self._current_phase.value if self._current_phase else "unknown"),
                        )
                        resume_loop_error = OrchestratorError(
                            error_message,
                            session_id=self._session_id,
                        )
                        break

            # Unexpected loop exit - set error to raise outside try block (TRY301)
            if resume_loop_error is None:
                error_message = "Orchestration loop exited unexpectedly"
                # Emit session_failed before raising so log viewer can display termination reason
                self._log_session_event(
                    "session_failed",
                    error_code="ORCHESTRATOR_ERROR",
                    error_class="OrchestratorError",
                    error_message=error_message,
                    phase=(self._current_phase.value if self._current_phase else "unknown"),
                )
                resume_loop_error = OrchestratorError(
                    error_message,
                    session_id=self._session_id,
                )
        except Exception as e:
            error_message = str(e)
            error_class = type(e).__name__
            self._log_session_event(
                "pipeline_failed",
                failure_stage=(self._current_phase.value if self._current_phase else "unknown"),
                error_code="ORCHESTRATOR_ERROR",
                error_class=error_class,
                error_message=error_message,
                span_id=self._pipeline_span_id,
            )
            if self._current_phase:
                self._log_session_event(
                    "phase_failed",
                    phase=self._current_phase.value,
                    failure_stage="resume_loop",
                    error_code="ORCHESTRATOR_ERROR",
                    error_class=error_class,
                    error_message=error_message,
                    span_id=self._phase_span_id,
                    parent_span_id=self._pipeline_span_id,
                )
            # ISSUE-OBS-003: Emit session_failed to properly close session lifecycle
            self._log_session_event(
                "session_failed",
                error_code="ORCHESTRATOR_ERROR",
                error_class=error_class,
                error_message=error_message,
                phase=self._current_phase.value if self._current_phase else "unknown",
            )
            self._cleanup_story0_containers()
            raise
        finally:
            # FEAT-SESSION-CLOSEOUT-001: Record invocation for cumulative runtime tracking
            if self._invocation_id and self._invocation_start_time:
                duration = time.time() - self._invocation_start_time
                phase_reached = self._current_phase.value if self._current_phase else "unknown"
                self._record_invocation(
                    invocation_id=self._invocation_id,
                    started_at=self._invocation_start_time,
                    duration_seconds=duration,
                    termination=self._get_termination_type(),
                    phase_reached=phase_reached,
                    items_completed=self._items_completed_this_invocation,
                )

        # TRY301: Raise loop error outside try block
        if resume_loop_error is not None:
            self._cleanup_story0_containers()
            raise resume_loop_error
        return None

    def get_status(self, session_id: str | None = None) -> ResumeContext:
        """Get session status.

        Args:
            session_id: Session ID to check (defaults to current session)

        Returns:
            ResumeContext with session status

        Raises:
            OrchestratorError: If no session ID provided and no active session
        """
        sid = session_id or self._session_id
        if not sid:
            msg = "No session ID provided"
            raise OrchestratorError(
                msg,
                recovery="Provide a session ID or start a new session with 'obra derive'",
            )

        try:
            response = self._request_with_observability("GET", f"session/{sid}")
            return ResumeContext.from_dict(response)
        except APIError as e:
            if e.status_code == HTTPStatus.NOT_FOUND.value:
                msg = f"Session not found: {sid}"
                raise OrchestratorError(
                    msg,
                    recovery="The session may have expired.",
                ) from e
            raise


__all__ = [
    "ConnectionError",
    "HybridOrchestrator",
    "OrchestratorError",
]
