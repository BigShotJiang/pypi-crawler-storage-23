"""Prompt helpers that suspend the active spinner for clean input UX."""

from __future__ import annotations

from typing import Callable

from rich.console import Console

from obra.display.spinner import suspend_active_spinner


def prompt_input(
    prompt: str = "",
    *,
    default: str | None = None,
    console: Console | None = None,
    markup: bool = False,
    input_func: Callable[[str], str] | None = None,
) -> str:
    """Read interactive input while suspending any active spinner.

    Args:
        prompt: Prompt string to display.
        default: Default value if user enters empty input (only for std input).
        console: Optional Rich Console for input.
        markup: Whether console input should interpret markup.
        input_func: Optional input function override (for tests).

    Returns:
        User input (or default if provided and empty).
    """
    with suspend_active_spinner():
        if console is not None:
            return console.input(prompt, markup=markup)
        reader = input_func or input
        value = reader(prompt)
        if default is not None and value == "":
            return default
        return value
