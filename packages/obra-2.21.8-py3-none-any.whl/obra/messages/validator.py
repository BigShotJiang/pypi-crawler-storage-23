"""
Validator domain message templates.

Templates for validator pipeline stages: intent, plan, review_filter, and code_verify.
These messages are emitted during validator execution to inform users
about validation progress and results.
"""

from __future__ import annotations

from typing import Any

from obra.messages.registry import (
    MessageDomain,
    MessageTemplate,
    ValidatorCategory,
)

__all__ = [
    "TEMPLATES",
    "build_validator_message",
    "get_validator",
]

# =============================================================================
# Validator Templates
# =============================================================================

TEMPLATES: dict[str, MessageTemplate] = {
    # -------------------------------------------------------------------------
    # Intent Category (pre-derivation validation)
    # -------------------------------------------------------------------------
    "validator.intent.running": MessageTemplate(
        domain=MessageDomain.VALIDATOR,
        category=ValidatorCategory.INTENT,
        template="Validating objective scope...",
        verbose_template="Running SenseCheck intent validation...",
    ),
    "validator.intent.sound": MessageTemplate(
        domain=MessageDomain.VALIDATOR,
        category=ValidatorCategory.INTENT,
        template="Objective validated",
        verbose_template="SenseCheck: Objective is well-scoped, no constraints needed",
    ),
    "validator.intent.constraints": MessageTemplate(
        domain=MessageDomain.VALIDATOR,
        category=ValidatorCategory.INTENT,
        template="Applied {count} scope constraints",
        verbose_template="SenseCheck: Applied {count} constraints to prevent scope creep",
        placeholders=("count",),
    ),
    "validator.intent.skipped": MessageTemplate(
        domain=MessageDomain.VALIDATOR,
        category=ValidatorCategory.INTENT,
        template="Intent validation skipped",
        verbose_template="SenseCheck intent validation disabled in config",
    ),
    # -------------------------------------------------------------------------
    # Plan Category (post-derivation validation)
    # -------------------------------------------------------------------------
    "validator.plan.running": MessageTemplate(
        domain=MessageDomain.VALIDATOR,
        category=ValidatorCategory.PLAN,
        template="Reviewing plan...",
        verbose_template="Running SenseCheck plan validation...",
    ),
    "validator.plan.sound": MessageTemplate(
        domain=MessageDomain.VALIDATOR,
        category=ValidatorCategory.PLAN,
        template="Plan validated",
        verbose_template="SenseCheck: Plan is well-structured, no revision needed",
    ),
    "validator.plan.issues": MessageTemplate(
        domain=MessageDomain.VALIDATOR,
        category=ValidatorCategory.PLAN,
        template="Found {count} issues, triggering revision",
        verbose_template="SenseCheck: Found {count} plan issues, auto-revision triggered",
        placeholders=("count",),
    ),
    "validator.plan.issues_no_revise": MessageTemplate(
        domain=MessageDomain.VALIDATOR,
        category=ValidatorCategory.PLAN,
        template="Found {count} issues (below revision threshold)",
        verbose_template="SenseCheck: Found {count} issues but below auto-revision threshold",
        placeholders=("count",),
    ),
    "validator.plan.skipped": MessageTemplate(
        domain=MessageDomain.VALIDATOR,
        category=ValidatorCategory.PLAN,
        template="Plan validation skipped",
        verbose_template="SenseCheck plan validation disabled in config",
    ),
    # -------------------------------------------------------------------------
    # Review Filter Category (post-review validation)
    # -------------------------------------------------------------------------
    "validator.review_filter.running": MessageTemplate(
        domain=MessageDomain.VALIDATOR,
        category=ValidatorCategory.REVIEW_FILTER,
        template="Filtering review findings...",
        verbose_template="Running SenseCheck review filter...",
    ),
    "validator.review_filter.sound": MessageTemplate(
        domain=MessageDomain.VALIDATOR,
        category=ValidatorCategory.REVIEW_FILTER,
        template="No false positives detected",
        verbose_template="SenseCheck: All review findings are valid, no filtering needed",
    ),
    "validator.review_filter.filtered": MessageTemplate(
        domain=MessageDomain.VALIDATOR,
        category=ValidatorCategory.REVIEW_FILTER,
        template="Filtered {count} false positives",
        verbose_template="SenseCheck: Removed {count} false positive findings from review",
        placeholders=("count",),
    ),
    "validator.review_filter.skipped": MessageTemplate(
        domain=MessageDomain.VALIDATOR,
        category=ValidatorCategory.REVIEW_FILTER,
        template="Review filter skipped",
        verbose_template="SenseCheck review filter disabled in config",
    ),
    # -------------------------------------------------------------------------
    # Code Verify Category (plan/code grounding validation)
    # -------------------------------------------------------------------------
    "validator.code_verify.running": MessageTemplate(
        domain=MessageDomain.VALIDATOR,
        category=ValidatorCategory.CODE_VERIFY,
        template="-> Verifying plan against codebase...",
        verbose_template="-> Verifying {check_count} checks against {file_count} files...",
        placeholders=("check_count", "file_count"),
    ),
    "validator.code_verify.clean": MessageTemplate(
        domain=MessageDomain.VALIDATOR,
        category=ValidatorCategory.CODE_VERIFY,
        template="OK Plan verified (0 issues)",
        verbose_template="OK Plan verified -- {files_read} files read, {callers_checked} callers checked",
        placeholders=("files_read", "callers_checked"),
    ),
    "validator.code_verify.findings": MessageTemplate(
        domain=MessageDomain.VALIDATOR,
        category=ValidatorCategory.CODE_VERIFY,
        template="-> Found {count} issues ({blocking} blocking)",
        verbose_template="-> Found {count} issues ({v0} V0, {v1} V1, {v2} V2)",
        placeholders=("count", "blocking", "v0", "v1", "v2"),
    ),
    "validator.code_verify.skip": MessageTemplate(
        domain=MessageDomain.VALIDATOR,
        category=ValidatorCategory.CODE_VERIFY,
        template="-> Plan verification skipped ({reason})",
        placeholders=("reason",),
    ),
    "validator.code_verify.preflight.start": MessageTemplate(
        domain=MessageDomain.VALIDATOR,
        category=ValidatorCategory.CODE_VERIFY,
        template="-> Story {story_id}: Pre-flight verification...",
        placeholders=("story_id",),
    ),
    "validator.code_verify.preflight.sense_check": MessageTemplate(
        domain=MessageDomain.VALIDATOR,
        category=ValidatorCategory.CODE_VERIFY,
        template="  -> SenseCheck: {task_count} tasks validated, {changes} structural changes",
        placeholders=("task_count", "changes"),
    ),
    "validator.code_verify.preflight.pass_start": MessageTemplate(
        domain=MessageDomain.VALIDATOR,
        category=ValidatorCategory.CODE_VERIFY,
        template="  -> CodeVerify pass {pass_num}: checking {task_count} tasks against codebase...",
        placeholders=("pass_num", "task_count"),
    ),
    "validator.code_verify.preflight.finding": MessageTemplate(
        domain=MessageDomain.VALIDATOR,
        category=ValidatorCategory.CODE_VERIFY,
        template="    -> {severity}: {description}",
        placeholders=("severity", "description"),
    ),
    "validator.code_verify.preflight.adjusted": MessageTemplate(
        domain=MessageDomain.VALIDATOR,
        category=ValidatorCategory.CODE_VERIFY,
        template="    -> Adjusted {task_id}: {reason}",
        placeholders=("task_id", "reason"),
    ),
    "validator.code_verify.preflight.complete": MessageTemplate(
        domain=MessageDomain.VALIDATOR,
        category=ValidatorCategory.CODE_VERIFY,
        template="OK Story {story_id}: Pre-flight complete ({passes} passes, {adjustments} adjustments, {blockers} blockers)",
        placeholders=("story_id", "passes", "adjustments", "blockers"),
    ),
    "validator.code_verify.preflight.escalate": MessageTemplate(
        domain=MessageDomain.VALIDATOR,
        category=ValidatorCategory.CODE_VERIFY,
        template="!! Story {story_id}: Pre-flight escalating -- V0 persists after {passes} passes: {description}",
        placeholders=("story_id", "passes", "description"),
    ),
    # -------------------------------------------------------------------------
    # Generic Stage Messages
    # -------------------------------------------------------------------------
    "validator.stage.timeout": MessageTemplate(
        domain=MessageDomain.VALIDATOR,
        category=ValidatorCategory.INTENT,
        template="Validation timed out ({stage})",
        verbose_template="SenseCheck {stage} validation timed out after {duration}s",
        placeholders=("stage",),
    ),
    "validator.stage.error": MessageTemplate(
        domain=MessageDomain.VALIDATOR,
        category=ValidatorCategory.INTENT,
        template="Validation failed ({stage})",
        verbose_template="SenseCheck {stage} validation encountered an error: {message}",
        placeholders=("stage",),
    ),
}


# =============================================================================
# Builder Functions
# =============================================================================


def get_validator(key: str, **kwargs: Any) -> str:
    """
    Get a validator message with automatic domain prefix.

    Args:
        key: Key without 'validator.' prefix (e.g., 'intent.running')
        **kwargs: Placeholder values

    Returns:
        Formatted message string
    """
    from obra.messages.registry import get_message

    return get_message(f"validator.{key}", **kwargs)


def build_validator_message(
    stage: str,
    event: str,
    *,
    count: int | None = None,
    duration: float | None = None,
    message: str | None = None,
    verbose: bool = False,
    **kwargs: Any,
) -> str:
    """
    Build a validator message for a specific stage and event.

    Args:
        stage: Validation stage ('intent', 'plan', 'review_filter')
        event: Event type ('running', 'sound', 'constraints', 'issues', 'filtered', 'skipped', 'timeout', 'error')
        count: Number of constraints/issues/filtered items (for applicable events)
        duration: Duration in seconds (for timeout events)
        message: Error message (for error events)
        verbose: Use verbose message variant

    Returns:
        Formatted validator message
    """
    from obra.messages.registry import get_message

    # Map stage to appropriate key
    stage_normalized = stage.lower().replace("-", "_")

    # Handle generic stage messages
    if event in ("timeout", "error"):
        key = f"validator.stage.{event}"
        kwargs: dict[str, Any] = {"stage": stage_normalized}
        if duration is not None:
            kwargs["duration"] = duration
        if message is not None:
            kwargs["message"] = message
        return get_message(key, verbose=verbose, **kwargs)

    # Handle stage-specific messages
    key = f"validator.{stage_normalized}.{event}"
    message_kwargs: dict[str, Any] = dict(kwargs)
    if count is not None:
        message_kwargs["count"] = count

    return get_message(key, verbose=verbose, **message_kwargs)
