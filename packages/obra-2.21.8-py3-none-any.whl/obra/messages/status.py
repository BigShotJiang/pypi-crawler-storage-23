"""
Status domain message templates.

Templates for session states, phase announcements, and celebration banners.
"""

from __future__ import annotations

from typing import Any

from obra.messages.registry import (
    MessageDomain,
    MessageTemplate,
    StatusCategory,
)

__all__ = [
    "TEMPLATES",
    "build_celebration_banner",
    "build_phase_announcement",
    "build_session_banner",
    "get_status",
]

# =============================================================================
# Status Templates
# =============================================================================

TEMPLATES: dict[str, MessageTemplate] = {
    # -------------------------------------------------------------------------
    # Session Category
    # -------------------------------------------------------------------------
    "status.session.complete": MessageTemplate(
        domain=MessageDomain.STATUS,
        category=StatusCategory.SESSION,
        template="Session Complete",
    ),
    "status.session.escalated": MessageTemplate(
        domain=MessageDomain.STATUS,
        category=StatusCategory.SESSION,
        template="Session Escalated",
    ),
    "status.session.paused": MessageTemplate(
        domain=MessageDomain.STATUS,
        category=StatusCategory.SESSION,
        template="Session Paused",
    ),
    "status.session.failed": MessageTemplate(
        domain=MessageDomain.STATUS,
        category=StatusCategory.SESSION,
        template="Session Failed",
    ),
    "status.session.expired": MessageTemplate(
        domain=MessageDomain.STATUS,
        category=StatusCategory.SESSION,
        template="Session Expired",
    ),
    "status.session.abandoned": MessageTemplate(
        domain=MessageDomain.STATUS,
        category=StatusCategory.SESSION,
        template="Session Abandoned",
    ),
    # -------------------------------------------------------------------------
    # Phase Category
    # -------------------------------------------------------------------------
    "status.phase.derivation": MessageTemplate(
        domain=MessageDomain.STATUS,
        category=StatusCategory.PHASE,
        template="Deriving execution plan",
    ),
    "status.phase.execution": MessageTemplate(
        domain=MessageDomain.STATUS,
        category=StatusCategory.PHASE,
        template="Executing plan",
    ),
    "status.phase.refinement": MessageTemplate(
        domain=MessageDomain.STATUS,
        category=StatusCategory.PHASE,
        template="Refining results",
    ),
    "status.phase.userplan": MessageTemplate(
        domain=MessageDomain.STATUS,
        category=StatusCategory.PHASE,
        template="Processing user plan",
    ),
    # -------------------------------------------------------------------------
    # Celebration Category
    # -------------------------------------------------------------------------
    "status.celebration.mission_complete": MessageTemplate(
        domain=MessageDomain.STATUS,
        category=StatusCategory.CELEBRATION,
        template="MISSION COMPLETE",
    ),
}


# =============================================================================
# Builder Functions (FR-3)
# =============================================================================


def get_status(key: str, **kwargs: Any) -> str:
    """
    Get a status message with automatic domain prefix.

    Args:
        key: Key without 'status.' prefix (e.g., 'session.complete')
        **kwargs: Placeholder values

    Returns:
        Formatted message string
    """
    from obra.messages.registry import get_message

    return get_message(f"status.{key}", **kwargs)


def build_session_banner(state: str, session_id: str | None = None) -> str:
    """
    Build session state banner text.

    Args:
        state: Session state (complete, escalated, paused, failed, expired, abandoned)
        session_id: Optional session ID to include

    Returns:
        Formatted banner text (e.g., 'Session Complete' or 'Session Complete: abc123')
    """
    from obra.messages.registry import get_message

    state_lower = state.lower()
    key = f"status.session.{state_lower}"

    try:
        banner = get_message(key)
    except KeyError:
        # Fallback for unknown states
        banner = f"Session {state.title()}"

    if session_id:
        short_id = session_id.split("-")[0] if "-" in session_id else session_id
        return f"{banner}: {short_id}"
    return banner


def build_phase_announcement(phase: str) -> str:
    """
    Build phase announcement text.

    Args:
        phase: Phase name (derivation, execution, refinement, userplan)

    Returns:
        Phase announcement text
    """
    from obra.messages.registry import get_message

    phase_lower = phase.lower()
    key = f"status.phase.{phase_lower}"

    try:
        return get_message(key)
    except KeyError:
        # Fallback for unknown phases
        return phase.replace("_", " ").title()


def build_celebration_banner() -> str:
    """
    Build celebration banner text for mission completion.

    Returns:
        'MISSION COMPLETE' text
    """
    from obra.messages.registry import get_message

    return get_message("status.celebration.mission_complete")
