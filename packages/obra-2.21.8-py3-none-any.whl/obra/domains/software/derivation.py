"""Derivation keywords and guidance for software development domain.

These definitions are used for work type detection and task sizing guidance
in software development workflows.

Related:
    - obra/execution/derivation.py (original source)
    - obra/domains/interface.py (DomainModule protocol)
"""

from obra.domains.software.prompts.sizing import (
    SIZING_GUIDANCE as DOMAIN_SIZING_GUIDANCE,
)

# Keywords for detecting work types from objective text
WORK_TYPE_KEYWORDS: dict[str, list[str]] = {
    "feature_implementation": [
        "implement",
        "create",
        "build",
        "add feature",
        "new feature",
    ],
    "bug_fix": ["fix", "bug", "issue", "error", "broken", "failing"],
    "refactoring": ["refactor", "restructure", "reorganize", "clean up", "simplify"],
    "documentation": ["docs", "doc", "documentation", "readme", "guide"],
    "integration": ["integrate", "connect", "api", "external", "third-party"],
    "database": ["database", "schema", "migration", "table", "column", "index"],
    "testing": ["test", "tests", "coverage", "unit test", "integration test"],
    "performance": ["optimize", "performance", "speed", "cache", "slow"],
    "security": ["security", "auth", "authentication", "authorization", "encrypt"],
    "infrastructure": ["deploy", "ci", "cd", "pipeline", "docker", "kubernetes"],
}

SIZING_GUIDANCE = DOMAIN_SIZING_GUIDANCE

# Valid development phases for software workflows
VALID_PHASES = ["explore", "plan", "implement", "commit"]

# Work types that typically benefit from exploration before implementation
WORK_TYPES_NEEDING_EXPLORATION = [
    "feature_implementation",
    "refactoring",
    "integration",
]

# Mapping of phases to agent types (None means no specific agent)
PHASE_TO_AGENT: dict[str, str | None] = {
    "explore": "Explore",
    "plan": None,
    "implement": None,
    "commit": None,
}
