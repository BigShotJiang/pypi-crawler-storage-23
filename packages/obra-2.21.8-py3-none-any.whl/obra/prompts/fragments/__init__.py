"""Shared prompt fragments for context enrichment.

This package contains reusable prompt building blocks:
- context: Working directory constraints
- recovery: Interactive retry banners
- template_edit: File editing instructions
- response_protocol: Response status protocol
"""

from __future__ import annotations

# Define lazy-loaded exports
_SUBMODULE_EXPORTS = {
    # context.py exports
    "build_working_directory_constraint": ".context",
    "WORKING_DIRECTORY_CONSTRAINT": ".context",
    # recovery.py exports
    "build_interactive_recovery_banner": ".recovery",
    # template_edit.py exports
    "build_template_edit_prompt": ".template_edit",
    # response_protocol.py exports
    "get_response_protocol_instructions": ".response_protocol",
    "RESPONSE_PROTOCOL_INSTRUCTIONS": ".response_protocol",
}

__all__ = list(_SUBMODULE_EXPORTS.keys())


def __getattr__(name: str):
    """PEP 562 lazy loading for submodule exports."""
    if name in _SUBMODULE_EXPORTS:
        from importlib import import_module

        module_name = _SUBMODULE_EXPORTS[name]
        module = import_module(module_name, package=__name__)
        return getattr(module, name)
    msg = f"module {__name__!r} has no attribute {name!r}"
    raise AttributeError(msg)


def __dir__():
    """List available exports."""
    return __all__
