"""Shared prompt fragments for hybrid context enrichment."""

from __future__ import annotations

__all__ = ["WORKING_DIRECTORY_CONSTRAINT", "build_working_directory_constraint"]

WORKING_DIRECTORY_CONSTRAINT = (
    "IMPORTANT: This is the target directory for ALL file operations. "
    "Create new files within this path. Do NOT write to parent directories."
)


def build_working_directory_constraint() -> str:
    """Return the working directory constraint for prompt context."""
    return WORKING_DIRECTORY_CONSTRAINT
