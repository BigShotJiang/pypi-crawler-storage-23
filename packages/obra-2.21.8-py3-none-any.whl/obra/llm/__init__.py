"""Unified LLM invocation layer for Obra client.

This package provides:
- LLMInvoker: Unified interface for LLM invocation across providers
- ThinkingModeAdapter: Provider-agnostic extended thinking support
- OutputParser: Structured output parsing with schema validation
- Provider implementations: Anthropic, OpenAI, Google, Ollama

The LLM layer abstracts provider differences and provides consistent
interfaces for derivation, revision, and examination operations.

Example:
    from obra.llm import LLMInvoker, ThinkingLevel

    invoker = LLMInvoker()
    result = invoker.invoke(
        prompt="Analyze this code",
        provider="anthropic",
        thinking_level=ThinkingLevel.HIGH,
    )
    print(result.content)

Related:
    - docs/design/prds/UNIFIED_HYBRID_ARCHITECTURE_PRD.md
    - obra/execution/ (derivation/revision engines)
    - obra/hybrid/orchestrator.py
"""

from typing import TYPE_CHECKING

from obra.llm.invoker import InvocationResult, LLMInvoker
from obra.llm.output_parser import OutputParser, ParsedOutput

if TYPE_CHECKING:
    from obra.llm.subprocess_runner import (
        LLMErrorDetails,
        LLMSubprocessConfig,
        LLMSubprocessResult,
        run_llm_subprocess,
    )
from obra.llm.thinking_mode import (
    THINKING_LEVEL_TOKENS,
    ThinkingConfig,
    ThinkingLevel,
    ThinkingMode,
    ThinkingModeAdapter,
)

__all__ = [
    "THINKING_LEVEL_TOKENS",
    "InvocationResult",
    # Core invoker
    "LLMInvoker",
    "LLMErrorDetails",
    "LLMSubprocessConfig",
    "LLMSubprocessResult",
    # Output parser
    "OutputParser",
    "ParsedOutput",
    "ThinkingConfig",
    "ThinkingLevel",
    "ThinkingMode",
    # Thinking mode
    "ThinkingModeAdapter",
    # Subprocess runner (ADR-047)
    "run_llm_subprocess",
]


def __getattr__(name: str):
    if name in {
        "LLMErrorDetails",
        "LLMSubprocessConfig",
        "LLMSubprocessResult",
        "run_llm_subprocess",
    }:
        from obra.llm.subprocess_runner import (
            LLMErrorDetails,
            LLMSubprocessConfig,
            LLMSubprocessResult,
            run_llm_subprocess,
        )

        return {
            "LLMErrorDetails": LLMErrorDetails,
            "LLMSubprocessConfig": LLMSubprocessConfig,
            "LLMSubprocessResult": LLMSubprocessResult,
            "run_llm_subprocess": run_llm_subprocess,
        }[name]
    raise AttributeError(f"module 'obra.llm' has no attribute {name!r}")
