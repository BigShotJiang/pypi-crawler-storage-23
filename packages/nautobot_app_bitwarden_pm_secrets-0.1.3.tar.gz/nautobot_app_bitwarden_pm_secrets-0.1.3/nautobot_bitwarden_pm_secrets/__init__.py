# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

"""Nautobot app providing a secrets provider for Bitwarden Password Manager."""

from importlib import metadata

from nautobot.apps import NautobotAppConfig

__version__ = metadata.version("nautobot-app-bitwarden-pm-secrets")


class NautobotBitwardenPmSecretsConfig(NautobotAppConfig):
    """App configuration for nautobot_bitwarden_pm_secrets."""

    name = "nautobot_bitwarden_pm_secrets"
    verbose_name = "Bitwarden Password Manager Secrets Provider"
    version = __version__
    author = "Gary T. Giesen"
    author_email = "ggiesen@giesen.me"
    description = "Nautobot app providing a secrets provider for Bitwarden Password Manager via the bw serve REST API."
    base_url = "bitwarden-pm-secrets"
    required_settings = []
    default_settings = {
        "base_url": "http://localhost:8087",
    }
    min_version = "2.4.0"
    max_version = "2.99"


config = NautobotBitwardenPmSecretsConfig
