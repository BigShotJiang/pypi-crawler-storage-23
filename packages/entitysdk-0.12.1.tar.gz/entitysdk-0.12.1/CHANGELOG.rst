# Changelog

## Version 0.0.1

- Initial preliminary version.
