"""Ion channel modeling execution model."""

from entitysdk.models.execution import Execution


class IonChannelModelingExecution(Execution):
    """Ion channel modeling execution model."""
