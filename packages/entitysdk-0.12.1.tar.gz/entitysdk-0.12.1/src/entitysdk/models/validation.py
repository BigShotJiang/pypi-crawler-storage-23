"""Validation activity model."""

from entitysdk.models.activity import Activity


class Validation(Activity):
    """Validation activity class."""
