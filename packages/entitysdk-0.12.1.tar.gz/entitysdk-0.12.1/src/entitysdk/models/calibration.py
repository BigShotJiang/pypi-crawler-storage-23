"""Calibration activity model."""

from entitysdk.models.activity import Activity


class Calibration(Activity):
    """Calibration activity class."""
