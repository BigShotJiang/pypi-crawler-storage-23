"""Skeletonization execution model."""

from entitysdk.models.execution import Execution


class SkeletonizationExecution(Execution):
    """Skeletonization execution model."""
