"""Simulation execution model."""

from entitysdk.models.execution import Execution


class SimulationExecution(Execution):
    """Simulation execution model."""
