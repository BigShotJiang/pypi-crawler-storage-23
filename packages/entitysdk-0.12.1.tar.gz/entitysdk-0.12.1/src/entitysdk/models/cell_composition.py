"""Cell Composition."""

from entitysdk.models.entity import Entity


class CellComposition(Entity):
    """Cell Composition."""
