"""Local to entitysdk schemas."""
