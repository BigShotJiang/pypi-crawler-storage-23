# metaflow_extensions.prefect — Prefect integration for Metaflow.
# This package is discovered by Metaflow's extension system at import time.
