"""A2A trust extension types.

Re-exports from reputation for convenience.
"""

from .reputation import A2ATrustExtension

__all__ = ["A2ATrustExtension"]
