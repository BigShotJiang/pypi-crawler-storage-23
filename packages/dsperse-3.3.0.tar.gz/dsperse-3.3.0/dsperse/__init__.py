# This file is intentionally left empty
# The main function is imported directly from main.py via the entry point in setup.py
