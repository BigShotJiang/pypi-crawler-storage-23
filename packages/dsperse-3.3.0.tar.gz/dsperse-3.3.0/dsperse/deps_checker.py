import logging
from dsperse.install import install_deps, check_ezkl

logger = logging.getLogger(__name__)


def ensure_dependencies():
    """Check and install dependencies"""
    ezkl_path, ezkl_version = check_ezkl()

    if ezkl_path:
        return True

    logger.info("EZKL not found. Installing dependencies...")

    if install_deps(interactive=False):
        logger.info("Dependencies installed successfully!")
        return True

    logger.error("Automatic dependency installation failed.")
    return False
