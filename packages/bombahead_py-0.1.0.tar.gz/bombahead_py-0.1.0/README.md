# bombahead-py

Python SDK for building Bomberman bots that connect to a Bombahead game server over WebSocket.

## Installation

```bash
pip install bombahead-py
```

## Quick Start

```python
from bombahead import Bot, Action, run


class MyBot(Bot):
    def get_next_move(self, state, helpers):
        return Action.DO_NOTHING


run(MyBot())
```
