from bombahead import Bomb, CellType, Field, GameState, Player, Position, render_field


def test_render_field_nil_state() -> None:
    assert render_field(None) == "<nil game state>\n"


def test_render_field_empty_field() -> None:
    state = GameState(field=Field(width=0, height=0, cells=[]))
    assert render_field(state) == "<empty field>\n"


def test_render_field_board_and_overlays() -> None:
    state = GameState(
        me=Player(id="me", pos=Position(2, 1), health=3, score=10),
        opponents=[Player(id="op-z", pos=Position(3, 0), health=2, score=4)],
        players=[
            Player(id="me", pos=Position(2, 1), health=3, score=10),
            Player(id="op-z", pos=Position(3, 0), health=2, score=4),
        ],
        field=Field(
            width=4,
            height=3,
            cells=[
                CellType.AIR,
                CellType.WALL,
                CellType.BOX,
                CellType.AIR,
                CellType.AIR,
                CellType.AIR,
                CellType.AIR,
                CellType.AIR,
                CellType.WALL,
                CellType.AIR,
                CellType.AIR,
                CellType.BOX,
            ],
        ),
        bombs=[Bomb(pos=Position(1, 1), fuse=2)],
        explosions=[Position(0, 1)],
    )

    got = render_field(state)
    want_parts = [
        "╔════════╗\n",
        "║  🧱📦👾║\n",
        "║💥💣🤖  ║\n",
        "║🧱    📦║\n",
        "╚════════╝\n",
        "--- PLAYERS ---\n",
        "🤖 Player me | Health: 3, Score: 10 | Pos: (2,1)\n",
        "👾 Player op-z | Health: 2, Score: 4 | Pos: (3,0)\n",
        "--- BOMBS ---\n",
        "💣 at (1,1) | Fuse: 2\n",
        "Legend: [space] AIR",
    ]

    for part in want_parts:
        assert part in got


def test_render_field_short_player_id_no_panic_and_shortening() -> None:
    state = GameState(
        players=[Player(id="xy", pos=Position(0, 0), health=1, score=1)],
        field=Field(width=1, height=1, cells=[CellType.AIR]),
    )

    got = render_field(state)
    assert "Player xy" in got
