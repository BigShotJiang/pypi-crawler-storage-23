from bombahead import CellType, Field, Position


def test_position_distance_to() -> None:
    p = Position(1, 2)
    other = Position(-2, 6)
    assert p.distance_to(other) == 7


def test_field_cell_at() -> None:
    field = Field(
        width=2,
        height=2,
        cells=[
            CellType.AIR,
            CellType.BOX,
            CellType.WALL,
            CellType.AIR,
        ],
    )

    assert field.cell_at(Position(1, 0)) == CellType.BOX
    assert field.cell_at(Position(-1, 0)) == CellType.WALL

    short_field = Field(width=3, height=1, cells=[CellType.AIR])
    assert short_field.cell_at(Position(2, 0)) == CellType.WALL
