from __future__ import annotations

from typing import Protocol

from .enums import Action
from .helpers import GameHelpers
from .models import GameState


class Bot(Protocol):
    def get_next_move(self, state: GameState, helpers: GameHelpers) -> Action:
        ...
