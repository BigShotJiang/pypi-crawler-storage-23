from enum import Enum


class Action(str, Enum):
    MOVE_UP = "move_up"
    MOVE_DOWN = "move_down"
    MOVE_LEFT = "move_left"
    MOVE_RIGHT = "move_right"
    PLACE_BOMB = "place_bomb"
    DO_NOTHING = "nothing"


class CellType(str, Enum):
    AIR = "AIR"
    WALL = "WALL"
    BOX = "BOX"
