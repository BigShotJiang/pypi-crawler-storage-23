// Source: https://github.com/jupyterlab/jupyterlab/blob/v4.3.2/docs/source/extension/extension_dev.rst#custom-webpack-config
module.exports = {
  module: {
    rules: [
      {
        test: /\.ogg$/,
        type: "asset/inline",
      },
    ],
  },
};
