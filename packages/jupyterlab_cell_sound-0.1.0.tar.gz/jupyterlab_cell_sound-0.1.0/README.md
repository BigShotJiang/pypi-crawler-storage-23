# jupyterlab-cell-sound

[![uv](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/uv/main/assets/badge/v0.json)](https://github.com/astral-sh/uv)
[![Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)

Play a sound when a cell is executed.

The sound effects are from the [Interface Sounds](https://kenney.nl/assets/interface-sounds) asset pack by [Kenney](https://kenney.nl/).

## Development

Install [uv](https://docs.astral.sh/uv/getting-started/installation/) and [fnm](https://github.com/Schniz/fnm?tab=readme-ov-file#installation) (if necessary):

```bash
curl -LsSf https://astral.sh/uv/0.8.12/install.sh | sh
```

```bash
uv python install
```

```bash
fnm install && fnm use && node --version && npm --version
```

```bash
uv run python -c "from jupyterlab_cell_sound import __version__; print(__version__)"
```

```bash
source .venv/bin/activate
```

```bash
npm run check:exts
```

```bash
npm run watch
```

In a separate terminal window:

```bash
source .venv/bin/activate
```

```bash
jupyter lab
```

```bash
ruff check --fix
```

```bash
ruff format
```

```bash
deactivate
```

## Deployment

```bash
npm version patch
```

```bash
npm version minor
```

```bash
npm version major
```

```bash
uv build
```

```bash
echo "$(npm pkg get version | tr -d \")" | pbcopy
```

- Commit and push changes.
- Create a tag on [GitHub Desktop](https://github.blog/2020-05-12-create-and-push-tags-in-the-latest-github-desktop-2-5-release/).
- Check [GitLab](https://gitlab.com/joaommpalmeiro/jupyterlab-cell-sound/-/tags).

```bash
uv publish
```

- Check [PyPI](https://pypi.org/project/jupyterlab-cell-sound/).
