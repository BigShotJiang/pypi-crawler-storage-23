import { JupyterFrontEndPlugin } from "@jupyterlab/application";
import { NotebookActions } from "@jupyterlab/notebook";
import { debounce } from "es-toolkit/function";

import success from "../style/sounds/confirmation_001.ogg";
import error from "../style/sounds/error_008.ogg";
import { PLUGIN_DESC, PLUGIN_ID } from "./constants";

function playSound(dataUrl: string): void {
  const audio = new Audio(dataUrl);
  audio.play();
}
const debouncedPlaySound = debounce(playSound, 300);

const plugin: JupyterFrontEndPlugin<void> = {
  id: PLUGIN_ID,
  description: PLUGIN_DESC,
  autoStart: true,
  activate: () => {
    console.log("JupyterLab extension jupyterlab-cell-sound is activated!");

    NotebookActions.executed.connect((_, args) => {
      if (args.cell.model.type === "code") {
        if (args.success) {
          debouncedPlaySound(success);
        } else {
          debouncedPlaySound(error);
        }
      }
    });
  },
};

export default plugin;
