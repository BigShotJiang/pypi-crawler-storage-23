export const NS = "jupyterlab-cell-sound";

export const PLUGIN_ID = `${NS}:plugin`;
export const PLUGIN_DESC = "Play a sound when a cell is executed.";
