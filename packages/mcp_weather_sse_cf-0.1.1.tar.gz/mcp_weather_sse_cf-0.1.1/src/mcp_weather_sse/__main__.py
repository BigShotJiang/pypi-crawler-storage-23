from mcp_weather_sse import main
main()