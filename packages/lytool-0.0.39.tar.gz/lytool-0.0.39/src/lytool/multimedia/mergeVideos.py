from moviepy import VideoFileClip, concatenate_videoclips

def mergeMp4Files(file_list, output_path):
    # 加载所有视频文件
    clips = [VideoFileClip(file_path) for file_path in file_list]
    # 合并视频
    final_clip = concatenate_videoclips(clips)
    # 输出合并后的视频
    final_clip.write_videofile(output_path, codec='libx264')
    # 关闭所有剪辑以释放内存
    for clip in clips:
        clip.close()
    final_clip.close()