import svgwrite
from xml.dom import minidom

def compressSvgSimple(input_file, output_file):
    """简单压缩SVG文件"""
    # 读取SVG文件
    with open(input_file, 'r', encoding='utf-8') as f:
        svg_content = f.read()

    # 使用minidom解析并重新输出（去除多余空格）
    parsed = minidom.parseString(svg_content)
    compressed_svg = parsed.toxml()

    # 写入压缩后的文件
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(compressed_svg)

def batchCompressSvgSimple():
    pass


if __name__ == '__main__':
    # 使用示例
    compressSvgSimple('gameIcon1.svg', 'gameIcon1.svg')