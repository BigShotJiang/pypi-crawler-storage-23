def toForwardSlash(path):
    return path.replace('\\', '/')