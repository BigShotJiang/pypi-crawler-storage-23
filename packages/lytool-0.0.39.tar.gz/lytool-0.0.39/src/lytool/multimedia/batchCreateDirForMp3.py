import os
import shutil
from lytool.multimedia.toLinuxPath import toForwardSlash


def bcdfm(topFolderPath):
    '''
    batch create directory for mp3
    '''
    for i in os.listdir(topFolderPath):
        folderName = i.split('.')[0]
        folderPath = os.path.join(topFolderPath, folderName)
        oldMp3Path = os.path.join(topFolderPath, i)
        newMp3Path = os.path.join(topFolderPath, folderName) + '.mp3'
        newMp3Path = toForwardSlash(newMp3Path)
        if not os.path.exists(folderPath):
            os.makedirs(folderPath)
            shutil.move(oldMp3Path, folderPath)


if __name__ == '__main__':
    topFolderPath = 'E:/project/program/AIGC/output/videoLibrary/phoneticSymbols1'
    bcdfm(topFolderPath)