from pathlib import Path

def deleteAllMp4(topDir):
    folder = Path(topDir)
    mp4_files = list(folder.rglob("*.mp4")) + list(folder.rglob("*.MP4"))
    for i in mp4_files:
        try:
            i.unlink()  # 删除文件
        except FileNotFoundError as e:
            print(e)

if __name__ == '__main__':
    workPath = 'E:/project/program/AIGC/output/videoLibrary/aesopFables'
    deleteAllMp4(workPath)