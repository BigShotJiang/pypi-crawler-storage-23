import os
import shutil

def keepOnly(path):
    if os.path.exists(path):
        if os.path.isfile(path):
            print(f"{path} 是一个文件")
            os.remove(path)
        elif os.path.isdir(path):
            print(f"{path} 是一个目录")
            shutil.rmtree(path)
    else:
        print(f"{path} 不存在")