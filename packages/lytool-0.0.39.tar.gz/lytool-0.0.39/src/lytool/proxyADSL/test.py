import random
dic = {'a':'b','c':'d'}
lis = ['a','c']
name = random.choice(lis)
proxy = dic[name]
