"""Chuk MCP Chart: Interactive data visualisation MCP server."""

__version__ = "1.0.0"
