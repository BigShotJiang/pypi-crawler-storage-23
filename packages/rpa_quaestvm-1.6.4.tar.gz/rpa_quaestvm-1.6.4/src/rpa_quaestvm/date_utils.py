from datetime import datetime, timezone
import calendar


def now_utc() -> datetime:
    """Return tz-aware datetime in UTC."""
    return datetime.now(timezone.utc)


def data_br_para_sql(data_br: str):
    return datetime.strptime(data_br, "%d/%m/%Y").strftime("%Y-%m-%d")


def get_ultimo_dia_do_mes(mes: int, ano: int) -> int:
    """Retorna o último dia do mês da competência escolhida.

    Example: `get_ultimo_dia_do_mes(2, 2024) == 29`.
    """
    if not 1 <= mes <= 12:
        raise ValueError("mes deve ser entre 1 e 12")

    return calendar.monthrange(ano, mes)[1]
