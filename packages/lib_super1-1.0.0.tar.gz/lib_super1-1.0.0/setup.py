from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="lib-super1", 
    version="1.0.0",
    author="Walter Soca",
    author_email="superlib.system@gmail.com", # Tu nuevo correo empresarial
    description="La librería Python todo-en-uno: PDFs con Tailwind, correos estilo SaaS y utilidades pro.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/noldee/super-lib", # El enlace a tu repo de GitHub
    packages=find_packages(),
    include_package_data=True,
    python_requires=">=3.7",
    
    
    # --- Dependencias Obligatorias ---
    install_requires=[
        "qrcode",
        "reportlab",
        "python-dotenv",
        "xhtml2pdf",
        "requests",
    ],
    
    # --- Clasificadores para PyPI ---
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ], 
    project_urls={
        "Bug Tracker": "https://github.com/noldee/super-lib/issues",
        "Documentation": "https://github.com/noldee/super-lib#readme",
        "Source Code": "https://github.com/noldee/super-lib",
    },
)