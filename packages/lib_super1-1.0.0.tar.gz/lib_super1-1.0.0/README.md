# 🚀 superlib

> **La librería Python todo-en-uno para humanos.**
> Matematicas avanzadas · Consola con colores · Graficas ASCII · QR · PDF · Correo HTML

---

## 📦 Instalacion

```bash
pip install lib-super
```

> Instala automaticamente: `qrcode`, `reportlab`, `xhtml2pdf`, `python-dotenv`

---

## ⚡ Inicio rapido

```python
from libsuper import *
```

---

## 📚 Modulos

---

### 🎨 `console` — Mensajes, tablas, progreso

#### Mensajes con color

```python
from libsuper import Print

Print.success("Usuario registrado correctamente")
Print.error("No se pudo conectar a la base de datos")
Print.warning("La contrasena expira en 3 dias")
Print.info("Hay 5 actualizaciones disponibles")
Print.danger("3 intentos de acceso fallidos detectados")
Print.bold("Texto importante", color="cyan")
Print.dim("Texto secundario / atenuado")
```

Salida en consola:

```
✔ SUCCESS  Usuario registrado correctamente
✘ ERROR    No se pudo conectar a la base de datos
⚠ WARNING  La contrasena expira en 3 dias
ℹ INFO     Hay 5 actualizaciones disponibles
☠ DANGER   3 intentos de acceso fallidos detectados
```

---

#### Banner ASCII

```python
from libsuper import banner

banner("MI PROYECTO", "version 1.0", color="cyan")
banner("SUPERLIB",    "La libreria todo-en-uno", color="green")
```

```
╔════════════════════════════════════════════════════════════╗
║                        MI PROYECTO                         ║
║                        version 1.0                         ║
╚════════════════════════════════════════════════════════════╝
```

Colores: `cyan` · `blue` · `green` · `yellow` · `magenta` · `red`

---

#### Tabla bonita

```python
from libsuper import tabla

# Con lista de dicts (headers automaticos):
tabla([
    {"nombre": "Ana",  "nota": 9.5, "aprobado": "Si"},
    {"nombre": "Luis", "nota": 7.2, "aprobado": "Si"},
    {"nombre": "Maria","nota": 4.8, "aprobado": "No"},
])

# Con lista de listas y headers manuales:
tabla([[1, "Ana", 9.5], [2, "Luis", 8.0]],
      headers=["#", "Nombre", "Nota"],
      titulo="Calificaciones",
      color="green")
```

```
   Calificaciones
┌────┬────────┬──────┐
│ #  │ Nombre │ Nota │
├────┼────────┼──────┤
│ 1  │ Ana    │ 9.5  │
├────┼────────┼──────┤
│ 2  │ Luis   │ 8.0  │
└────┴────────┴──────┘
```

---

#### Barra de progreso

```python
from libsuper import progreso
import time

# Modo iterador:
for item in progreso(range(100), desc="Procesando", color="cyan"):
    time.sleep(0.02)

# Modo manual:
bar = progreso(total=100, desc="Cargando")
bar.update(50)
bar.close()
```

```
Procesando: [████████████████████░░░░░░░░░░░░░░░░░░░░]  50% (50/100)
```

---

#### Smart Print — Big Data

```python
from libsuper import smart_print

# Muestra inicio + fin, omite el medio:
smart_print(list(range(1000)), titulo="Mi lista")
smart_print(lista_de_dicts,    max_rows=6)
```

```
  Mi lista
  Total de elementos: 1000
  [0]  0
  [1]  1
  [2]  2
  ... 994 elementos omitidos ...
  [997] 997
  [998] 998
  [999] 999
  Mostrando 6 de 1000 elementos
```

---

### ➗ `matematica` — Fracciones, Estadistica, Trig, Geo

#### Fracciones

```python
from libsuper import Fraccion

f = Fraccion(3, 6)            # -> 1/2 (simplificada automaticamente)
print(f)                      # "1/2"
print(f.decimal())            # 0.5
print(f.info())               # {"fraccion": "1/2", "decimal": 0.5, "porcentaje": "50.00%", ...}

# Operaciones:
Fraccion(1, 3) + Fraccion(1, 6)   # -> 1/2
Fraccion(3, 4) * Fraccion(2, 3)   # -> 1/2
Fraccion(1, 2) / Fraccion(1, 4)   # -> 2
Fraccion(1, 3) + 1                # -> 4/3
```

---

#### Ecuaciones cuadraticas

```python
from libsuper import cuadratica

res = cuadratica(1, -5, 6)   # x² - 5x + 6 = 0
print(res["raices"])          # (3.0, 2.0)
print(res["discriminante"])   # 1
print(res["vertice"])         # (2.5, -0.25)
print(res["tipo"])            # "2 raices reales distintas"
print(res["abre"])            # "arriba ↑"

# Raices complejas:
res2 = cuadratica(1, 0, 1)
print(res2["raices"])         # ("0.0 + 1.0i", "0.0 - 1.0i")
```

---

#### Estadistica

```python
from libsuper import Estadistica

e = Estadistica([12, 7, 3, 14, 6, 11, 5, 4, 9, 8])
print(e.media())          # 7.9
print(e.mediana())        # 7.5
print(e.moda())           # [todos (sin moda)]
print(e.desviacion_std()) # 3.2...
print(e.percentil(75))    # Q3
print(e.resumen())        # dict completo con n, media, mediana, Q1, Q2, Q3...
```

---

#### Conversion de bases

```python
from libsuper import Base

Base.decimal_a_binario(42)       # "101010"
Base.decimal_a_hex(255)          # "FF"
Base.decimal_a_octal(8)          # "10"
Base.binario_a_decimal("101010") # 42
Base.hex_a_decimal("FF")         # 255
Base.convertir(255, 10, 2)       # base 10 -> base 2: "11111111"
Base.convertir(255, 10, 36)      # base 10 -> base 36: "73"
Base.tabla_completa(255)         # {"decimal": 255, "binario": "11111111", "hex": "FF", ...}
```

---

#### Trigonometria

```python
from libsuper import Trig

Trig.sen(30)                   # 0.5
Trig.cos(60)                   # 0.5
Trig.tan(45)                   # 1.0
Trig.csc(30)                   # 2.0
Trig.arcsen(0.5)               # 30.0
Trig.todos(45)                 # {"sen": 0.707, "cos": 0.707, "tan": 1.0, ...}

# En radianes:
import math
Trig.sen(math.pi / 6, grados=False)   # 0.5

# Ley de senos (deja el faltante como None):
Trig.ley_senos(a=5, A=30, b=None, B=45)   # encuentra b
Trig.ley_senos(a=5, A=30, b=7, B=None)    # encuentra B
```

---

#### Geometria

```python
from libsuper import Geo

# 2D:
Geo.circulo(5)           # {"area": 78.539, "perimetro": 31.415, "diametro": 10}
Geo.rectangulo(4, 6)     # {"area": 24, "perimetro": 20, "diagonal": 7.211}
Geo.triangulo(3, 4, 5)   # {"area": 6.0, "tipo_lados": "Escaleno", "tipo_angulos": "Rectangulo", "angulo_C": 90.0}
Geo.cuadrado(4)          # {"area": 16, "perimetro": 16, "diagonal": 5.656}
Geo.trapecio(6, 4, 3)    # {"area": 15.0}

# 3D:
Geo.esfera(3)            # {"volumen": 113.097, "area_sup": 113.097}
Geo.cilindro(2, 5)       # {"volumen": 62.831, "area_lateral": 62.831, "area_total": 87.964}
Geo.cono(2, 5)           # {"volumen": 20.943, "generatriz": 5.385, ...}
Geo.cubo(4)              # {"volumen": 64, "area_total": 96, "diagonal": 6.928}
Geo.piramide(4, 6)       # {"volumen": 32.0, "area_base": 16.0, ...}
Geo.piramide(4, 6, tipo="triangular")
```

---

### 📊 `visual` — Graficas ASCII, QR, PDF, Correo

#### Graficas en terminal

```python
from libsuper import grafica_barras, grafica_linea, grafica_pastel, simular_funcion
import math

# Barras:
grafica_barras({"Python": 45, "JS": 30, "C++": 15, "Java": 10})
grafica_barras(datos, color="green", ancho=50)

# Linea:
grafica_linea([3, 7, 2, 8, 4, 9, 1, 6], titulo="Ventas semanales")
grafica_linea([(0,0),(1,1),(2,4),(3,9)], titulo="y = x²")

# Pastel:
grafica_pastel({"Python": 45, "JavaScript": 30, "C++": 15, "Otro": 10})

# Simular funciones:
simular_funcion(lambda x: x**2,         titulo="y = x²",    inicio=-5, fin=5)
simular_funcion(lambda x: math.sin(x),  titulo="y = sin(x)", inicio=0, fin=6.28)
simular_funcion(lambda x: math.e**x,    titulo="y = eˣ",    inicio=-3, fin=3)
```

---

#### QR Code

```python
from libsuper import qr

qr("https://google.com")
qr("Hola, este es mi QR")
```

```
  QR para: https://google.com

  ██████████████  ██  ██████████████
  ██          ██      ██          ██
  ██  ██████  ██  ██  ██  ██████  ██
  ...
```

---

#### Crear PDF

```python
from libsuper import crear_pdf

# Basico:
crear_pdf("reporte.pdf", "Contenido del documento.", titulo="Mi Reporte")

# Nivel experto (con Tailwind CSS):
crear_pdf("reporte.pdf", "Contenido.", titulo="Reporte", nivel="expert", autor="Juan")

# Multi-idioma:
crear_pdf("doc.pdf", {"es": "Hola mundo", "en": "Hello world"}, titulo="Doc")

# Template propio:
mi_template = "<html><body><h1>{{titulo}}</h1><p>{{contenido}}</p></body></html>"
crear_pdf("doc.pdf", "Mi contenido", template_personalizado=mi_template)
```

---

#### Enviar PDF por correo

```python
from libsuper import enviar_pdf_correo, email_html

# Simple (texto plano):
enviar_pdf_correo("LUFFY.pdf", "socamezareswalter@gmail.com")

# Con asunto y mensaje:
enviar_pdf_correo(
    "LUFFY.pdf",
    "libsuper@gmail.com",
    asunto="📄 Documento LUFFY",
    cuerpo="Estimado Soca, adjunto el documento solicitado."
)

# Con HTML bonito (recomendado):
html = email_html(
    titulo="Estimado Mendez,",
    mensaje="Espero que te encuentres bien. Adjunto el documento LUFFY solicitado.",
    nombre_archivo="LUFFY.pdf",
    color_principal="#0066cc",
    firma="Tu Nombre"
)
enviar_pdf_correo(
    "LUFFY.pdf",
    "libsuper@gmail.com",
    asunto="📄 Documento LUFFY adjunto",
    html=html
)

# Multi-idioma:
enviar_pdf_correo("doc.pdf", "amigo@gmail.com",
                  cuerpo={"es": "Adjunto el doc.", "en": "Please find attached."},
                  lenguaje="en")
```

---

## 🔐 Configuracion del correo (`.env`)

Crea un archivo `.env` en la raiz de tu proyecto:

```env
SUPERLIB_EMAIL=superlibpy@gmail.com
SUPERLIB_PASSWORD=abcd efgh ijkl mnop
```

> **¿Cómo generar la contraseña?**
>
> 1. Ve a [myaccount.google.com/apppasswords](https://myaccount.google.com/apppasswords)
> 2. Crea una nueva con el nombre `superlib`
> 3. Google te da una clave de 16 letras — esa es tu `SUPERLIB_PASSWORD`

> **Recomendacion:** Crea un Gmail nuevo exclusivo como `superlibpy@gmail.com` para no exponer tu correo personal.

---

## 📁 Estructura del proyecto

```
lib-super/
├── .env                    ← Tus credenciales (nunca a GitHub)
├── .env.example            ← Plantilla para otros devs
├── .gitignore
├── setup.py
├── README.md
└── libsuper/
    ├── __init__.py
    └── modules/
        ├── console.py      ← Print, banner, tabla, progreso, smart_print
        ├── matematica.py   ← Fraccion, cuadratica, Estadistica, Base, Trig, Geo
        └── visual.py       ← graficas, qr, crear_pdf, email_html, enviar_pdf_correo
```

---

## 🔧 Dependencias

Todas se instalan automaticamente con `pip install superlib`:

| Dependencia     | Para que sirve         |
| --------------- | ---------------------- |
| `qrcode`        | Generar QR en terminal |
| `xhtml2pdf`     | Crear archivos PDF     |
| `python-dotenv` | Leer el archivo `.env` |

---

## 📄 Licencia

MIT — Libre para uso personal y comercial.

---

<p align="center">
  Hecho con ❤️ · powered by <strong>lib super open source</strong> 🚀
</p>
