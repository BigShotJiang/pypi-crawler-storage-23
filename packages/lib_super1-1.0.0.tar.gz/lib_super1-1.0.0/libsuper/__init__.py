"""
╠══════════════════════════════════════════════════════╣
║                L I B S U P E R   v1.0.0              ║
║    La libreria Python todo-en-uno para humanos 🚀     ║
╠══════════════════════════════════════════════════════╣

Uso rapido:
    from libsuper import Print, banner, tabla, progreso
    from libsuper import Fraccion, cuadratica, Estadistica
    from libsuper import Base, Trig, Geo
    from libsuper import grafica_barras, grafica_linea, simular_funcion
    from libsuper import qr, crear_pdf, enviar_pdf_correo, smart_print
"""

__version__ = "1.0.5"
__author__  = "Walter Soca"

# ── Consola ──────────────────────────────────────────
try:
    from libsuper.modules.console import (
        Print,
        banner,
        tabla,
        progreso,
        smart_print,
    )
except ImportError as e:
    print(f"\033[91mError importando Consola desde libsuper: {e}\033[0m")

# ── Matematica ───────────────────────────────────────
try:
    from libsuper.modules.matematica import (
        Fraccion,
        cuadratica,
        Estadistica,
        Base,
        Trig,
        Geo,
    )
except ImportError as e:
    print(f"\033[91mError importando Matematica desde libsuper: {e}\033[0m")

# ── Visual / Graficas ────────────────────────────────
try:
    from libsuper.modules.visual import (
        grafica_barras,
        grafica_linea,
        grafica_pastel,
        simular_funcion,
        qr,
        crear_pdf,        # La versión con niveles (Basic, Intermediate, Expert)
        enviar_pdf_correo, # La función de correo
    )
except ImportError as e:
    print(f"\033[91mError importando Visual desde libsuper: {e}\033[0m")

# ── Exportación Global ───────────────────────────────
__all__ = [
    # Consola
    "Print", "banner", "tabla", "progreso", "smart_print",
    # Matematica
    "Fraccion", "cuadratica", "Estadistica", "Base", "Trig", "Geo",
    # Visual
    "grafica_barras", "grafica_linea", "grafica_pastel",
    "simular_funcion", "qr", "crear_pdf", "enviar_pdf_correo",
]