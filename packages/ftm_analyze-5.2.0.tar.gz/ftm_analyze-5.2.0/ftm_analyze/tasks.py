from followthemoney import registry
from followthemoney.proxy import EntityProxy
from openaleph_procrastinate import defer
from openaleph_procrastinate.app import make_app
from openaleph_procrastinate.model import DatasetJob
from openaleph_procrastinate.tasks import task
from openaleph_procrastinate.util import make_stub_entity

from ftm_analyze.logic import analyze_entity

app = make_app(__loader__.name)
ORIGIN = "analyze"


def should_geocode(e: EntityProxy) -> bool:
    if e.schema.is_a("Address") or e.schema.is_a("RealEstate"):
        return True
    return bool(e.get_type_values(registry.address))


def should_translate(e: EntityProxy, e_origin_ingest: EntityProxy) -> bool:
    if e.schema.is_a("Document") and e.has("detectedLanguage"):
        return e_origin_ingest.has("indexText") or e_origin_ingest.has("bodyText")
    return False


@task(app=app, retry=defer.tasks.analyze.retries)
def analyze(job: DatasetJob) -> None:
    to_translate: list[EntityProxy] = []
    to_geocode: list[EntityProxy] = []
    to_index: list[EntityProxy] = []
    with job.get_writer() as bulk:
        for entity in job.load_entities():
            for result in analyze_entity(entity):
                bulk.put(result, origin=ORIGIN, fragment=entity.id)
                to_index.append(make_stub_entity(result))
                if should_geocode(result):
                    to_geocode.append(make_stub_entity(result))
                if should_translate(result, entity):
                    to_translate.append(make_stub_entity(result))
    if to_index:
        defer.index(app, job.dataset, to_index, batch=job.batch, **job.context)
    if to_geocode:
        defer.geocode(app, job.dataset, to_geocode, batch=job.batch, **job.context)
    if to_translate:
        defer.translate(app, job.dataset, to_translate, batch=job.batch, **job.context)
