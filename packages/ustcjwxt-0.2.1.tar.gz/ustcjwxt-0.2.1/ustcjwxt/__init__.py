version_info = (0, 2, '1')

__version__ = ".".join([str(x) for x in version_info])