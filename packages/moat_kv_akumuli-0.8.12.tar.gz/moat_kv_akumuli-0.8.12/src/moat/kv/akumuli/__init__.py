# noqa:D104
from __future__ import annotations

from moat.lib.config import register as _register

__all__ = []

_register(__name__)
