# Akumuli time series storage

% start synopsis
% start main

This is a simple link between Akumuli and MoaT-KV.

It will update an Akumuli series whenever a MoaT-KV value changes.

% end synopsis

## Deprecation Warning

This package is deprecated.  Use ``moat-link-akumuli`` instead.

Akumuli itself is also deprecated; see moat-7wl for a future
VictoriaMetrics replacement.

% end main
