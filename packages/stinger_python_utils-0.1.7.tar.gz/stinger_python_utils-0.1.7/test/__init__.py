"""Test package configuration"""
