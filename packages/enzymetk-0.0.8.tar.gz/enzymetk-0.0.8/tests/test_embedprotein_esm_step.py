"""Unit tests for enzymetk/embedprotein_esm_step.py"""

import os
import tempfile
import unittest
from unittest.mock import patch, MagicMock
import numpy as np
import pandas as pd
import torch

from enzymetk.embedprotein_esm_step import (
    EmbedESM,
    extract_mean_embedding,
    extract_active_site_embedding,
)


class TestExtractMeanEmbedding(unittest.TestCase):
    """Tests for the extract_mean_embedding function."""

    def setUp(self):
        """Set up test fixtures."""
        self.tmp_dir = tempfile.mkdtemp()
        # Create mock embedding files
        self.embedding_dim = 1280
        self.seq_len = 10
        self.rep_num = 33

        # Create sample tensor data
        self.sample_tensor = torch.randn(self.seq_len, self.embedding_dim)
        
        # Save mock .pt files
        for entry_id in ['protein1', 'protein2']:
            embedding_data = {
                'representations': {
                    self.rep_num: self.sample_tensor
                }
            }
            torch.save(embedding_data, os.path.join(self.tmp_dir, f'{entry_id}.pt'))

    def tearDown(self):
        """Clean up test fixtures."""
        import shutil
        shutil.rmtree(self.tmp_dir)

    def test_extract_mean_embedding_basic(self):
        """Test basic mean embedding extraction."""
        df = pd.DataFrame({
            'id': ['protein1', 'protein2'],
            'sequence': ['ACDEFGHIK', 'LMNPQRSTV']
        })
        
        result = extract_mean_embedding(df, 'id', self.tmp_dir, rep_num=self.rep_num)
        
        self.assertIn('embedding', result.columns)
        self.assertEqual(len(result), 2)
        # Check embedding shape
        self.assertEqual(result['embedding'].iloc[0].shape, (self.embedding_dim,))
        self.assertEqual(result['embedding'].iloc[1].shape, (self.embedding_dim,))

    def test_extract_mean_embedding_missing_file(self):
        """Test handling of missing embedding files."""
        df = pd.DataFrame({
            'id': ['protein1', 'missing_protein'],
            'sequence': ['ACDEFGHIK', 'LMNPQRSTV']
        })
        
        result = extract_mean_embedding(df, 'id', self.tmp_dir, rep_num=self.rep_num)
        
        self.assertIn('embedding', result.columns)
        self.assertIsNotNone(result['embedding'].iloc[0])
        self.assertIsNone(result['embedding'].iloc[1])


class TestExtractActiveSiteEmbedding(unittest.TestCase):
    """Tests for the extract_active_site_embedding function."""

    def setUp(self):
        """Set up test fixtures."""
        self.tmp_dir = tempfile.mkdtemp()
        self.embedding_dim = 1280
        self.seq_len = 20
        self.rep_num = 33

        # Create sample tensor data
        self.sample_tensor = torch.randn(self.seq_len, self.embedding_dim)
        
        # Save mock .pt files
        for entry_id in ['protein1', 'protein2']:
            embedding_data = {
                'representations': {
                    self.rep_num: self.sample_tensor
                }
            }
            torch.save(embedding_data, os.path.join(self.tmp_dir, f'{entry_id}.pt'))

    def tearDown(self):
        """Clean up test fixtures."""
        import shutil
        shutil.rmtree(self.tmp_dir)

    def test_extract_active_site_embedding_basic(self):
        """Test basic active site embedding extraction."""
        df = pd.DataFrame({
            'id': ['protein1', 'protein2'],
            'active_site': ['1|5|10', '2|8'],
            'sequence': ['ACDEFGHIKLMNPQRSTV', 'ACDEFGHIKLMNPQRSTV']
        })
        
        result = extract_active_site_embedding(
            df, 'id', 'active_site', self.tmp_dir, rep_num=self.rep_num
        )
        
        self.assertIn('active_embedding', result.columns)
        self.assertIn('esm_embedding', result.columns)
        self.assertEqual(len(result), 2)
        
        # Check that active site embeddings are lists of tensors
        self.assertEqual(len(result['active_embedding'].iloc[0]), 3)  # 3 residues
        self.assertEqual(len(result['active_embedding'].iloc[1]), 2)  # 2 residues

    def test_extract_active_site_embedding_none_residues(self):
        """Test handling of None residues."""
        df = pd.DataFrame({
            'id': ['protein1', 'protein2'],
            'active_site': [None, 'None'],
            'sequence': ['ACDEFGHIKLMNPQRSTV', 'ACDEFGHIKLMNPQRSTV']
        })
        
        result = extract_active_site_embedding(
            df, 'id', 'active_site', self.tmp_dir, rep_num=self.rep_num
        )
        
        self.assertIn('active_embedding', result.columns)
        self.assertIn('esm_embedding', result.columns)
        # Empty list when no residues specified
        self.assertEqual(result['active_embedding'].iloc[0], [])
        self.assertEqual(result['active_embedding'].iloc[1], [])

    def test_extract_active_site_embedding_missing_file(self):
        """Test handling of missing embedding files."""
        df = pd.DataFrame({
            'id': ['protein1', 'missing_protein'],
            'active_site': ['1|5', '2|8'],
            'sequence': ['ACDEFGHIKLMNPQRSTV', 'ACDEFGHIKLMNPQRSTV']
        })
        
        result = extract_active_site_embedding(
            df, 'id', 'active_site', self.tmp_dir, rep_num=self.rep_num
        )
        
        self.assertIsNotNone(result['active_embedding'].iloc[0])
        self.assertIsNone(result['active_embedding'].iloc[1])


class TestEmbedESM(unittest.TestCase):
    """Tests for the EmbedESM class."""

    def test_init_default_params(self):
        """Test EmbedESM initialization with default parameters."""
        embed = EmbedESM(id_col='id', seq_col='sequence')
        
        self.assertEqual(embed.id_col, 'id')
        self.assertEqual(embed.seq_col, 'sequence')
        self.assertEqual(embed.model, 'esm2_t36_3B_UR50D')
        self.assertEqual(embed.extraction_method, 'mean')
        self.assertIsNone(embed.active_site_col)
        self.assertEqual(embed.num_threads, 1)
        self.assertIsNone(embed.tmp_dir)
        self.assertEqual(embed.rep_num, 36)

    def test_init_custom_params(self):
        """Test EmbedESM initialization with custom parameters."""
        embed = EmbedESM(
            id_col='protein_id',
            seq_col='protein_seq',
            model='esm2_t33_650M_UR50D',
            extraction_method='active_site',
            active_site_col='active_sites',
            num_threads=4,
            tmp_dir='/tmp/test',
            rep_num=33
        )
        
        self.assertEqual(embed.id_col, 'protein_id')
        self.assertEqual(embed.seq_col, 'protein_seq')
        self.assertEqual(embed.model, 'esm2_t33_650M_UR50D')
        self.assertEqual(embed.extraction_method, 'active_site')
        self.assertEqual(embed.active_site_col, 'active_sites')
        self.assertEqual(embed.num_threads, 4)
        self.assertEqual(embed.tmp_dir, '/tmp/test')
        self.assertEqual(embed.rep_num, 33)

    def test_active_site_without_column_raises_error(self):
        """Test that active_site extraction without column raises ValueError."""
        embed = EmbedESM(
            id_col='id',
            seq_col='sequence',
            extraction_method='active_site',
            active_site_col=None
        )
        
        # Create a mock tmp_dir with embedding files
        with tempfile.TemporaryDirectory() as tmp_dir:
            embed.tmp_dir = tmp_dir
            
            # Create mock embedding file
            embedding_data = {
                'representations': {36: torch.randn(10, 1280)}
            }
            torch.save(embedding_data, os.path.join(tmp_dir, 'protein1.pt'))
            
            df = pd.DataFrame({
                'id': ['protein1'],
                'sequence': ['ACDEFGHIK']
            })
            
            # Mock the run method to avoid actually running esm-extract
            with patch.object(embed, 'run'):
                with self.assertRaises(ValueError) as context:
                    embed.execute(df)
                
                self.assertIn('active_site_col must be provided', str(context.exception))

    @patch.object(EmbedESM, 'run')
    def test_execute_creates_fasta_file(self, mock_run):
        """Test that execute creates a FASTA file with correct content."""
        with tempfile.TemporaryDirectory() as tmp_dir:
            embed = EmbedESM(
                id_col='id',
                seq_col='sequence',
                tmp_dir=tmp_dir
            )
            
            # Create mock embedding files
            for entry_id in ['protein1', 'protein2']:
                embedding_data = {
                    'representations': {36: torch.randn(10, 1280)}
                }
                torch.save(embedding_data, os.path.join(tmp_dir, f'{entry_id}.pt'))
            
            df = pd.DataFrame({
                'id': ['protein1', 'protein2'],
                'sequence': ['ACDEFGHIK', 'LMNPQRSTV']
            })
            
            result = embed.execute(df)
            
            # Check that run was called
            mock_run.assert_called_once()
            
            # Check that embedding column was added
            self.assertIn('embedding', result.columns)

    @patch.object(EmbedESM, 'run')
    def test_execute_skips_existing_embeddings(self, mock_run):
        """Test that execute skips entries that already have embeddings."""
        with tempfile.TemporaryDirectory() as tmp_dir:
            embed = EmbedESM(
                id_col='id',
                seq_col='sequence',
                tmp_dir=tmp_dir
            )
            
            # Create mock embedding file for only one protein
            embedding_data = {
                'representations': {36: torch.randn(10, 1280)}
            }
            torch.save(embedding_data, os.path.join(tmp_dir, 'protein1.pt'))
            torch.save(embedding_data, os.path.join(tmp_dir, 'protein2.pt'))
            
            df = pd.DataFrame({
                'id': ['protein1', 'protein2'],
                'sequence': ['ACDEFGHIK', 'LMNPQRSTV']
            })
            
            result = embed.execute(df)
            
            # Check the FASTA file content - should not include protein1
            fasta_path = os.path.join(tmp_dir, 'input.fasta')
            if os.path.exists(fasta_path):
                with open(fasta_path, 'r') as f:
                    content = f.read()
                # protein1 should be skipped since its .pt file exists
                self.assertNotIn('>protein1', content)


class TestEmbedESMIntegration(unittest.TestCase):
    """Integration tests for EmbedESM (mocked external calls)."""

    @patch.object(EmbedESM, 'run')
    def test_mean_extraction_workflow(self, mock_run):
        """Test complete mean extraction workflow."""
        with tempfile.TemporaryDirectory() as tmp_dir:
            embed = EmbedESM(
                id_col='id',
                seq_col='sequence',
                extraction_method='mean',
                tmp_dir=tmp_dir,
                rep_num=36
            )
            
            # Create mock embedding files
            embedding_dim = 1280
            for entry_id in ['prot1', 'prot2', 'prot3']:
                embedding_data = {
                    'representations': {36: torch.randn(15, embedding_dim)}
                }
                torch.save(embedding_data, os.path.join(tmp_dir, f'{entry_id}.pt'))
            
            df = pd.DataFrame({
                'id': ['prot1', 'prot2', 'prot3'],
                'sequence': ['ACDEFGHIKLMNPQR', 'STVWYFGHIKLMNPQ', 'ACDEFGHIKLMNPQR']
            })
            
            result = embed.execute(df)
            
            self.assertEqual(len(result), 3)
            self.assertIn('embedding', result.columns)
            for emb in result['embedding']:
                self.assertEqual(emb.shape, (embedding_dim,))

    @patch.object(EmbedESM, 'run')
    def test_active_site_extraction_workflow(self, mock_run):
        """Test complete active site extraction workflow."""
        with tempfile.TemporaryDirectory() as tmp_dir:
            embed = EmbedESM(
                id_col='id',
                seq_col='sequence',
                extraction_method='active_site',
                active_site_col='active_sites',
                tmp_dir=tmp_dir,
                rep_num=36
            )
            
            # Create mock embedding files
            embedding_dim = 1280
            seq_len = 20
            for entry_id in ['prot1', 'prot2']:
                embedding_data = {
                    'representations': {36: torch.randn(seq_len, embedding_dim)}
                }
                torch.save(embedding_data, os.path.join(tmp_dir, f'{entry_id}.pt'))
            
            df = pd.DataFrame({
                'id': ['prot1', 'prot2'],
                'sequence': ['ACDEFGHIKLMNPQRSTUVW', 'STVWYFGHIKLMNPQRSTUV'],
                'active_sites': ['1|5|10', '3|7']
            })
            
            result = embed.execute(df)
            
            self.assertEqual(len(result), 2)
            self.assertIn('active_embedding', result.columns)
            self.assertIn('esm_embedding', result.columns)
            
            # Check active site embeddings
            self.assertEqual(len(result['active_embedding'].iloc[0]), 3)
            self.assertEqual(len(result['active_embedding'].iloc[1]), 2)


if __name__ == '__main__':
    unittest.main()
