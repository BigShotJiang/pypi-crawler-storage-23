"""
Gitea Plugin

Complete Gitea management through REST API.
"""

from .plugin import GiteaPlugin

__all__ = ["GiteaPlugin"]
