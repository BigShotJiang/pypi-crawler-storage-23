"""WordPress plugin package"""

from plugins.wordpress.plugin import WordPressPlugin

__all__ = ["WordPressPlugin"]
