"""Utility functions for DTW, feature engineering, and synthetic data generation."""

from ad_inventory_forecast.utils.dtw import (
    align_sequences,
    dtw_distance,
    warp_sequence,
    scale_and_warp,
    find_similar_events,
    EventPatternLibrary,
)
from ad_inventory_forecast.utils.synthetic import (
    generate_dummy_data,
    generate_multi_series_data,
    create_test_dataset,
)

__all__ = [
    # DTW utilities
    "align_sequences",
    "dtw_distance",
    "warp_sequence",
    "scale_and_warp",
    "find_similar_events",
    "EventPatternLibrary",
    # Synthetic data generation
    "generate_dummy_data",
    "generate_multi_series_data",
    "create_test_dataset",
]
