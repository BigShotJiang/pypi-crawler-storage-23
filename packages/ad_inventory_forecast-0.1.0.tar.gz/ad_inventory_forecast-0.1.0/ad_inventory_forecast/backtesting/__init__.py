"""Backtesting and model evaluation module."""

from ad_inventory_forecast.backtesting.metrics import (
    calculate_mase,
    calculate_smape,
    calculate_mape,
    calculate_rmse,
    calculate_mae,
    calculate_wmape,
    calculate_bias,
    calculate_all_metrics,
    coverage_probability,
    interval_width,
)
from ad_inventory_forecast.backtesting.validator import (
    WalkForwardValidator,
    BacktestResult,
    FoldResult,
    cross_validate,
    time_series_split,
)

__all__ = [
    # Metrics
    "calculate_mase",
    "calculate_smape",
    "calculate_mape",
    "calculate_rmse",
    "calculate_mae",
    "calculate_wmape",
    "calculate_bias",
    "calculate_all_metrics",
    "coverage_probability",
    "interval_width",
    # Validation
    "WalkForwardValidator",
    "BacktestResult",
    "FoldResult",
    "cross_validate",
    "time_series_split",
]
