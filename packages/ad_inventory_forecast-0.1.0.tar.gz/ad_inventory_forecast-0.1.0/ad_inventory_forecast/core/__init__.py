"""Core module containing base classes, validation, and preprocessing utilities."""

from ad_inventory_forecast.core.base import BaseForecaster
from ad_inventory_forecast.core.validation import DataValidator, ValidationResult
from ad_inventory_forecast.core.preprocessing import (
    fill_missing_dates,
    detect_outliers,
    log_transform,
    inverse_log_transform,
)
from ad_inventory_forecast.core.advisor import (
    ModelAdvisor,
    ModelAdvice,
    ModelRecommendation,
    DataAnalysis,
)
from ad_inventory_forecast.core.diagnostics import (
    StructuralBreakWarning,
    VolatilityAnalysis,
    detect_structural_break,
    analyze_volatility,
    get_volatility_multiplier,
    detect_recent_trend_change,
)

__all__ = [
    "BaseForecaster",
    "DataValidator",
    "ValidationResult",
    "fill_missing_dates",
    "detect_outliers",
    "log_transform",
    "inverse_log_transform",
    "ModelAdvisor",
    "ModelAdvice",
    "ModelRecommendation",
    "DataAnalysis",
    # Diagnostics
    "StructuralBreakWarning",
    "VolatilityAnalysis",
    "detect_structural_break",
    "analyze_volatility",
    "get_volatility_multiplier",
    "detect_recent_trend_change",
]
