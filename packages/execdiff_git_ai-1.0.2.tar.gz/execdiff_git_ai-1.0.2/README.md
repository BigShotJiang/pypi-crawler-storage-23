# ExecDiff Git AI

AI Impact Assessment for git changes - understand what your AI copilot changed before you commit it.

## Overview

ExecDiff Git AI is a Python CLI tool that helps developers understand the scope and implications of code changes made by AI coding assistants (like GitHub Copilot, Cursor, or Replit AI) by analyzing git diffs and extracting modified symbols (functions, classes, variables). It can optionally use a local LLM (Ollama) to assess the business impact of each change.

## Privacy

ExecDiff Git AI runs **entirely locally**.

- ✅ No code is uploaded
- ✅ No cloud calls required
- ✅ No telemetry
- ✅ Works offline with optional local LLM (Ollama)
- ✅ All analysis happens on your machine

## Features

- **Local-first**: Runs entirely on your machine with no cloud calls or telemetry
- **Impact Assessment**: Detects specific changes to functions, classes, and variables and provides human-readable summaries
- **Two modes**: Fast analysis (non-AI) or deep AI-powered analysis (optional)
- **CLI-first**: `execdiff-git scan` and `execdiff-git scan-ai`
- **Works offline**, no telemetry

## Installation

### Prerequisites (Required)

- Python 3.8+
- Git

### Initial Setup

Install from PyPI:

```bash
pip install execdiff-git-ai
```

That's it! You can now use the non-AI mode immediately.

## How to Use

### Quick Start (No AI Required)

1. **Make your code change** (or let your AI copilot make changes)

2. **Stage your changes with git**

   ```bash
   git add .
   # For new files, you may need:
   git add -N .
   ```

3. **Run the assessment**

   ```bash
   execdiff-git scan
   ```

**Note**: For newly created files, you must run `git add -N .` (intent-to-add) so that `execdiff-git scan` can detect them. This is a git limitation for diff tools.

---

## AI-Powered Assessment (Optional)

**AI mode is completely optional.** The non-AI mode works great for most use cases.

### Requirements for AI Mode

| Component | Size | Description |
|-----------|------|-------------|
| **Ollama** | ~50MB | Local AI runtime (one-time install) |
| **tinyllama model** | ~637MB | Smallest AI model (one-time download) |

**Total: ~700MB one-time download**

- ✅ 100% local - no data sent to cloud
- ✅ Works offline after initial setup
- ✅ User permission required before any downloads

### How AI Mode Works

When you run `execdiff-git scan-ai`:

1. **Ollama check** - Checks if Ollama is installed
2. **Model check** - Checks if AI model is available
3. **User permission** - Asks before downloading anything
4. **Auto-start** - Starts Ollama server automatically
5. **Analysis** - Runs local AI analysis on your changes
6. **Auto-stop** - Stops Ollama server when done

### Install Ollama (One-Time)

**macOS:**
```bash
brew install ollama
```

**macOS/Linux:**
```bash
curl -fsSL https://ollama.ai/install.sh | sh
```

**Or download from:** https://ollama.ai/

### Use AI Mode

Simply run:

```bash
execdiff-git scan-ai
```

If the AI model is not installed, you'll be asked:

```
⚠️  Model 'tinyllama' (~637MB) is not installed locally.
✅ Everything stays local - no data is sent to the cloud.

Download 'tinyllama' now? (yes/no): 
```

**Say "yes" to download, or "no" to skip AI analysis.**

---

## Usage

### Basic Commands

**Non-AI mode (fast, always available, no setup):**
```bash
execdiff-git scan
```

**AI mode (optional, requires Ollama ~700MB total):**
```bash
execdiff-git scan-ai
```

### Example Output

**Non-AI Mode:**

```
==============================
📊 File Change Assessment
==============================
File                            +Lines  -Lines
------------------------------------------------
test_feature.py                     14       0

================================================================================
📋 Impact Summary
================================================================================
Symbol                    Change Type          Impact  
--------------------------------------------------------
authenticate_user         function added       LOW     
create_session            function added       LOW     
validate_token            function added       LOW     

✅ Assessment complete!
```

**AI Mode (with Ollama):**

```
==============================
📊 File Change Assessment
==============================
File                            +Lines  -Lines
------------------------------------------------
test_feature.py                     14       0

================================================================================
📋 Impact Summary
================================================================================
Symbol                    Change Type          Impact  
--------------------------------------------------------
authenticate_user         function added       LOW     
create_session            function added       LOW     
validate_token            function added       LOW     

================================================================================
🤖 AI Impact Assessment
================================================================================

🚀 Starting Ollama server...
⏳ Waiting for Ollama server to start...
✅ Ollama server is ready!
🧠 Analyzing with AI (tinyllama, 100% local)...

Symbol: authenticate_user
Impact: MEDIUM
Summary: Added user authentication logic. This affects user access and security.

Symbol: create_session
Impact: LOW
Summary: Added session creation. Improves user experience and session management.

Symbol: validate_token
Impact: LOW
Summary: Added token validation. Enhances security by validating session tokens.

🛑 Ollama server stopped

✅ Assessment complete!
```

---

## Comparison: Non-AI vs AI Mode

| Feature | Non-AI Mode | AI Mode |
|---------|-------------|---------|
| **Setup** | None | Ollama + model (~700MB) |
| **Speed** | Instant | 5-30 seconds |
| **Analysis** | Symbol detection | Business-facing summaries |
| **Privacy** | 100% local | 100% local |
| **Offline** | Yes | Yes (after setup) |

---

## How It Works

1. **Reads git diff** - Gets all staged changes (`git diff --cached`)
2. **Extracts symbols** - Finds functions, classes, and variables
3. **Detects change type** - Identifies what kind of change was made
4. **Assesses impact** - Uses local AI (Ollama) if available, or quick heuristics
5. **Generates business summary** - Specific, non-technical impact summary (AI mode only)
6. **Advisory warnings** - Critical impact changes trigger warnings (AI mode only)

---

## Development

Install in editable mode:

```bash
git clone https://github.com/anupmoncy/execdiff-git-ai.git
cd execdiff-git-ai
pip install -e .
```

Run the CLI:

```bash
execdiff-git scan
```

## Programmatic Usage

You can also use ExecDiff Git AI as a library:

```python
from execdiff_git_ai.agent import run_agent, run_agent_with_ai

# Non-AI mode (default)
run_agent()

# AI-powered mode (optional, automatically manages Ollama)
run_agent_with_ai()
```

## License

Apache-2.0

## Author

Anup Moncy (n93181165@gmail.com)

## Contributing

Contributions welcome! Please open an issue or submit a pull request.

---

**Note**: This is an early-stage project. The API and behavior are subject to change.
