"""Huey task queue — SQLite-backed, no Redis required."""

import asyncio
import logging
import uuid
from collections import defaultdict
from datetime import datetime
from pathlib import Path

from huey import SqliteHuey, crontab

from actflare.config import get_config, DEFAULT_CONFIG_DIR
from actflare.memory import MemoryStore, build_augmented_prompt

logger = logging.getLogger(__name__)

cfg = get_config()
huey_queue = SqliteHuey(filename=cfg.paths.huey_db)
memory_store = MemoryStore(cfg.paths.memory_db)

# Maximum WeChat text message length
MAX_MSG_LEN = 2000

# Agent execution timeout (seconds)
AGENT_TIMEOUT = 120


async def _run_agent_with_timeout(prompt: str, timeout: int = AGENT_TIMEOUT):
    """Run Claude agent with asyncio timeout protection."""
    from actflare.agent import run_claude_agent

    return await asyncio.wait_for(run_claude_agent(prompt), timeout=timeout)


@huey_queue.task(retries=3, retry_delay=10)
def process_message(
    user_id: str,
    content: str,
    sender_type: str = "app",
    response_url: str = "",
    account_id: str = "",
) -> None:
    """Process a user message: run Claude agent and push the reply via ChannelSender."""
    from actflare.sender import build_sender

    trace_id = uuid.uuid4().hex[:8]
    logger.info("[%s] Processing message from %s: %s", trace_id, user_id, content[:80])

    # 1. Search for relevant historical cases
    keywords = MemoryStore.extract_keywords(content)
    cases = memory_store.search_cases(keywords) if keywords else []
    if cases:
        logger.info("[%s] Found %d historical cases for query", trace_id, len(cases))

    # 2. Build augmented prompt with historical context
    augmented_prompt = build_augmented_prompt(content, cases)

    # 3. Run agent with timeout protection
    turns_used = 1
    try:
        result, turns_used = asyncio.run(_run_agent_with_timeout(augmented_prompt))
    except asyncio.TimeoutError:
        logger.error("[%s] Agent timeout after %ds for user %s", trace_id, AGENT_TIMEOUT, user_id)
        result = "抱歉，处理超时，请稍后重试或简化您的问题。"
    except Exception:
        logger.exception("[%s] Agent failed for user %s", trace_id, user_id)
        result = "抱歉，处理您的请求时出现了错误，请稍后再试。"

    # 4. Save case if: multi-turn OR substantial answer (>200 chars), and not error
    should_save = (turns_used > 1 or len(result) > 200) and result and not result.startswith("抱歉")
    if should_save:
        try:
            memory_store.save_case(
                user_id=user_id,
                query=content,
                answer=result,
                turns_used=turns_used,
                trace_id=trace_id,
            )
        except Exception:
            logger.exception("[%s] Failed to save case to memory", trace_id)

    # Append trace_id and feedback hint for user reference
    if result and not result.startswith("抱歉"):
        result = result.rstrip() + f"\n\n[任务编号: {trace_id}]\n收到结果后，回复「评价 {trace_id} 好」或「评价 {trace_id} 不好」帮助我改进"

    # Truncate if the reply exceeds WeChat's limit
    if len(result) > MAX_MSG_LEN:
        result = result[: MAX_MSG_LEN - 3] + "..."

    sender = build_sender(sender_type, response_url=response_url, account_id=account_id)
    try:
        sender.send_text(user_id, result)
    except Exception:
        logger.exception("[%s] Failed to send reply to %s", trace_id, user_id)


# ---------------------------------------------------------------------------
# Periodic tasks — run automatically by Huey worker
# ---------------------------------------------------------------------------


@huey_queue.periodic_task(crontab(minute="0", hour="*/6"))
def periodic_memory_stats():
    """Log memory system statistics every 6 hours."""
    stats = memory_store.get_stats()
    logger.info(
        "Memory stats: total=%d, avg_feedback=%.3f, error_isolated=%d",
        stats["total_cases"],
        stats["avg_feedback"],
        stats["error_isolated"],
    )


@huey_queue.periodic_task(crontab(minute="0", hour="3", day_of_week="0"))
def periodic_distill():
    """Distill high-quality cases into skill drafts every Sunday 3:00 AM."""
    cases = memory_store.top_cases(min_feedback=0.5, limit=50)
    if not cases:
        logger.info("Distill: no high-quality cases to process")
        return

    # Group by first 3 keywords
    clusters: defaultdict[str, list[dict]] = defaultdict(list)
    for case in cases:
        kws = case["keywords"].split()[:3]
        cluster_key = " ".join(sorted(kws)) if kws else "其他"
        clusters[cluster_key].append(case)

    drafts_dir = DEFAULT_CONFIG_DIR / "skills" / "drafts"
    drafts_dir.mkdir(parents=True, exist_ok=True)

    date_str = datetime.now().strftime("%Y%m%d")
    draft_count = 0
    for cluster_key, cluster_cases in clusters.items():
        if len(cluster_cases) < 2:
            continue

        draft_name = f"draft_{date_str}_{cluster_key.replace(' ', '_')[:30]}.md"
        draft_path = drafts_dir / draft_name
        if draft_path.exists():
            continue  # Don't overwrite existing drafts

        lines = [
            f"# 知识草稿: {cluster_key}",
            "",
            f"> 自动提炼自 {len(cluster_cases)} 条高质量案例 ({date_str})",
            f"> 审核后请移动到 ~/.config/actflare/skills/ 正式目录",
            "",
            "## 案例汇总",
            "",
        ]
        for i, c in enumerate(cluster_cases, 1):
            lines.append(f"### 案例 {i} (评分: {c['feedback_score']}, 轮次: {c['turns_used']})")
            lines.append(f"**问题**: {c['query']}")
            lines.append(f"**解决方案**: {c['answer'][:500]}")
            lines.append("")

        lines.append("## 待提炼的通用规律")
        lines.append("")
        lines.append("<!-- 请根据上述案例总结通用规律，然后删除案例部分 -->")
        lines.append("")

        draft_path.write_text("\n".join(lines), encoding="utf-8")
        draft_count += 1

    if draft_count:
        logger.info("Distill: generated %d skill drafts in %s", draft_count, drafts_dir)
