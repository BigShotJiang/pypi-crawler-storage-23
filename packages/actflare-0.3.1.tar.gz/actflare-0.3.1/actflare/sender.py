"""Channel sender implementations for message delivery."""

import logging
import time
from typing import Optional, Protocol

import httpx

logger = logging.getLogger(__name__)

BASE_URL = "https://qyapi.weixin.qq.com/cgi-bin"


def _send_with_retry(url: str, payload: dict, max_retries: int = 3, timeout: int = 15) -> dict:
    """Send HTTP POST with exponential backoff retry."""
    last_exc = None
    for attempt in range(max_retries):
        try:
            with httpx.Client(timeout=timeout) as client:
                resp = client.post(url, json=payload)
                resp.raise_for_status()
                return resp.json()
        except (httpx.TimeoutException, httpx.HTTPStatusError) as e:
            last_exc = e
            if attempt < max_retries - 1:
                wait = 2**attempt  # 1s, 2s, 4s
                logger.warning("Send retry %d/%d after %ds: %s", attempt + 1, max_retries, wait, e)
                time.sleep(wait)
    raise last_exc


class ChannelSender(Protocol):
    """Protocol for channel message senders."""

    def send_text(self, user_id: str, text: str) -> None: ...


class WecomAppSender:
    """Send messages via WeChat Work App API (access_token + /message/send)."""

    def __init__(self, corpid: str, corpsecret: str, agent_id: int):
        self.corpid = corpid
        self.corpsecret = corpsecret
        self.agent_id = agent_id
        self._access_token: Optional[str] = None
        self._token_expires_at: float = 0.0

    def _get_access_token(self) -> str:
        if self._access_token and time.time() < self._token_expires_at:
            return self._access_token
        with httpx.Client(timeout=10) as client:
            resp = client.get(
                f"{BASE_URL}/gettoken",
                params={"corpid": self.corpid, "corpsecret": self.corpsecret},
            )
            resp.raise_for_status()
            data = resp.json()
        if data.get("errcode", 0) != 0:
            raise RuntimeError(f"Failed to get access_token: {data}")
        self._access_token = data["access_token"]
        self._token_expires_at = time.time() + data.get("expires_in", 7200) - 300
        logger.info("Refreshed WeChat access_token")
        return self._access_token

    def send_text(self, user_id: str, text: str) -> None:
        token = self._get_access_token()
        url = f"{BASE_URL}/message/send?access_token={token}"
        payload = {
            "touser": user_id,
            "msgtype": "text",
            "agentid": self.agent_id,
            "text": {"content": text},
        }
        data = _send_with_retry(url, payload)
        errcode = data.get("errcode", 0)
        # Token expired or invalid: refresh and retry once
        if errcode in (40014, 42001):
            logger.warning("Access token expired (errcode=%d), refreshing...", errcode)
            self._access_token = None
            self._token_expires_at = 0.0
            token = self._get_access_token()
            url = f"{BASE_URL}/message/send?access_token={token}"
            data = _send_with_retry(url, payload)
            errcode = data.get("errcode", 0)
        if errcode != 0:
            logger.error("WecomAppSender failed: %s", data)
        else:
            logger.info("App message sent to %s", user_id)


class WecomBotSender:
    """Send messages via Bot response_url (no access_token needed)."""

    def __init__(self, response_url: str):
        self.response_url = response_url

    def send_text(self, user_id: str, text: str) -> None:
        if not self.response_url:
            logger.error("No response_url for bot reply to %s", user_id)
            return
        payload = {"msgtype": "text", "text": {"content": text}}
        _send_with_retry(self.response_url, payload)
        logger.info("Bot message sent to %s via response_url", user_id)


def build_sender(
    sender_type: str,
    response_url: str = "",
    account_id: str = "",
) -> ChannelSender:
    """Factory: construct the appropriate sender from Huey task params."""
    if sender_type == "bot":
        return WecomBotSender(response_url)

    from actflare.config import get_config

    cfg = get_config()
    for ch_cfg in cfg.channels.values():
        if account_id in ch_cfg.accounts:
            acc = ch_cfg.accounts[account_id]
            return WecomAppSender(acc.corpid, acc.corpsecret, acc.agent_id)

    raise ValueError(f"Unknown account_id: {account_id}")
