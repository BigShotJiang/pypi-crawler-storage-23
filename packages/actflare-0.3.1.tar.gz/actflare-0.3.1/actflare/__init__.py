"""
ActFlare: WeChat Work callback service powered by Claude Agent SDK.

Receives messages from WeChat Work, processes them asynchronously via
Claude Agent SDK, and pushes replies back to WeChat Work.
"""

__version__ = "0.3.1"
__author__ = "Zan Yuan"
__email__ = "yfinddream@gmail.com"

from actflare.config import load_config, get_config

__all__ = ["load_config", "get_config"]
