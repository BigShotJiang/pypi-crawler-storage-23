"""FastAPI application — WeChat Work callback endpoint with channel routing."""

import json
import logging
import re
import xml.etree.ElementTree as ET
from typing import Optional

from fastapi import FastAPI, Query, Request
from fastapi.responses import PlainTextResponse

from actflare.config import get_config, AccountConfig
from actflare.crypto import WXBizMsgCrypt

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)

app = FastAPI(title="ActFlare", description="WeChat Work callback service with Claude Agent SDK")

MAX_INPUT_LEN = 5000

# Feedback pattern: "评价 <trace_id> 好/不好/有用/没用" etc.
_FEEDBACK_RE = re.compile(
    r"^评价\s+([a-f0-9]{8})\s+(好|不好|有用|没用|满意|不满意|👍|👎)$",
    re.IGNORECASE,
)
_POSITIVE_WORDS = frozenset({"好", "有用", "满意", "👍"})


def _try_process_feedback(content: str, user_id: str) -> Optional[str]:
    """If content matches feedback pattern, process and return reply. Otherwise None."""
    m = _FEEDBACK_RE.match(content.strip())
    if not m:
        return None

    trace_id = m.group(1)
    sentiment = m.group(2)
    score = 1.0 if sentiment in _POSITIVE_WORDS else -1.0

    from actflare.tasks import memory_store

    found = memory_store.update_feedback_by_trace(trace_id, score)
    if found:
        label = "好评 👍" if score > 0 else "差评"
        logger.info("Feedback recorded: trace=%s score=%s user=%s", trace_id, score, user_id)
        return f"已记录您对任务 {trace_id} 的{label}，感谢反馈！"
    else:
        logger.warning("Feedback trace_id not found: %s from user %s", trace_id, user_id)
        return f"未找到任务编号 {trace_id}，请确认编号是否正确。"


def _make_crypt(account: AccountConfig) -> WXBizMsgCrypt:
    receive_id = account.receive_id if account.mode == "bot" else account.corpid
    return WXBizMsgCrypt(
        token=account.token,
        encoding_aes_key=account.encoding_aes_key,
        receive_id=receive_id,
    )


def register_channel_routes(application: FastAPI) -> None:
    """Dynamically register webhook routes for each channel account."""
    cfg = get_config()
    for channel_name, channel_cfg in cfg.channels.items():
        if not channel_cfg.enabled:
            continue
        for account_id, account_cfg in channel_cfg.accounts.items():
            if account_cfg.mode == "bot":
                _register_bot_routes(application, account_id, account_cfg)
            elif account_cfg.mode == "app":
                _register_app_routes(application, account_id, account_cfg)
            else:
                logger.warning("Unknown mode %s for account %s", account_cfg.mode, account_id)


def _register_bot_routes(application: FastAPI, account_id: str, account: AccountConfig) -> None:
    path = account.webhook_path

    @application.get(path, name=f"verify_{account_id}")
    async def bot_verify(
        msg_signature: str = Query(...),
        timestamp: str = Query(...),
        nonce: str = Query(...),
        echostr: str = Query(...),
        _account: AccountConfig = account,
    ):
        try:
            crypt = _make_crypt(_account)
            echo = crypt.verify_url(msg_signature, timestamp, nonce, echostr)
            return PlainTextResponse(echo)
        except Exception:
            logger.exception("Bot URL verification failed for %s", account_id)
            return PlainTextResponse("error", status_code=403)

    @application.post(path, name=f"receive_{account_id}")
    async def bot_receive(
        request: Request,
        msg_signature: str = Query(...),
        timestamp: str = Query(...),
        nonce: str = Query(...),
        _account: AccountConfig = account,
        _account_id: str = account_id,
    ):
        from actflare.tasks import process_message

        try:
            body = await request.json()
        except Exception:
            logger.exception("Bot invalid JSON body")
            return PlainTextResponse("error", status_code=400)

        encrypt = body.get("encrypt", "") or body.get("Encrypt", "")
        if not encrypt:
            return PlainTextResponse("missing encrypt", status_code=400)

        try:
            crypt = _make_crypt(_account)
            plain = crypt.decrypt_msg_raw(encrypt, msg_signature, timestamp, nonce)
        except Exception:
            logger.exception("Bot message decryption failed")
            return PlainTextResponse("error", status_code=403)

        try:
            msg = json.loads(plain)
        except json.JSONDecodeError:
            logger.error("Bot decrypted content is not valid JSON: %s", plain[:200])
            return PlainTextResponse("error", status_code=400)

        user_id = ""
        from_info = msg.get("from", {})
        if isinstance(from_info, dict):
            user_id = from_info.get("userid", "")
        user_id = user_id or msg.get("FromUserName", "")

        msg_type = msg.get("msgtype", msg.get("MsgType", ""))
        content = ""
        if msg_type == "text":
            text_obj = msg.get("text", {})
            if isinstance(text_obj, dict):
                content = text_obj.get("content", "")
            elif isinstance(text_obj, str):
                content = text_obj

        if content and len(content) > MAX_INPUT_LEN:
            logger.warning("Message too long (%d chars) from %s, truncating", len(content), user_id)
            content = content[:MAX_INPUT_LEN]

        response_url = msg.get("response_url", "")

        logger.info("Bot received %s from %s: %s", msg_type, user_id, (content or "")[:80])

        if msg_type == "text" and user_id and content:
            # Intercept feedback messages — process directly without Claude
            feedback_reply = _try_process_feedback(content, user_id)
            if feedback_reply is not None:
                from actflare.sender import build_sender

                sender = build_sender("bot", response_url=response_url)
                sender.send_text(user_id, feedback_reply)
            else:
                process_message(user_id, content, sender_type="bot", response_url=response_url)
        else:
            logger.info("Bot ignoring non-text or empty message (type=%s)", msg_type)

        return PlainTextResponse("")


def _register_app_routes(application: FastAPI, account_id: str, account: AccountConfig) -> None:
    path = account.webhook_path

    @application.get(path, name=f"verify_{account_id}")
    async def app_verify(
        msg_signature: str = Query(...),
        timestamp: str = Query(...),
        nonce: str = Query(...),
        echostr: str = Query(...),
        _account: AccountConfig = account,
    ):
        try:
            crypt = _make_crypt(_account)
            echo = crypt.verify_url(msg_signature, timestamp, nonce, echostr)
            return PlainTextResponse(echo)
        except Exception:
            logger.exception("App URL verification failed for %s", account_id)
            return PlainTextResponse("error", status_code=403)

    @application.post(path, name=f"receive_{account_id}")
    async def app_receive(
        request: Request,
        msg_signature: str = Query(...),
        timestamp: str = Query(...),
        nonce: str = Query(...),
        _account: AccountConfig = account,
        _account_id: str = account_id,
    ):
        from actflare.tasks import process_message

        body = await request.body()
        post_data = body.decode("utf-8")

        try:
            crypt = _make_crypt(_account)
            xml_str = crypt.decrypt_msg(post_data, msg_signature, timestamp, nonce)
        except Exception:
            logger.exception("App message decryption failed")
            return PlainTextResponse("error", status_code=403)

        root = ET.fromstring(xml_str)
        msg_type = root.findtext("MsgType", "")
        from_user = root.findtext("FromUserName", "")
        content = root.findtext("Content", "")

        if content and len(content) > MAX_INPUT_LEN:
            logger.warning("Message too long (%d chars) from %s, truncating", len(content), from_user)
            content = content[:MAX_INPUT_LEN]

        logger.info("App received %s from %s: %s", msg_type, from_user, (content or "")[:80])

        if msg_type == "text" and from_user and content:
            # Intercept feedback messages — process directly without Claude
            feedback_reply = _try_process_feedback(content, from_user)
            if feedback_reply is not None:
                from actflare.sender import build_sender

                sender = build_sender("app", account_id=_account_id)
                sender.send_text(from_user, feedback_reply)
            else:
                process_message(from_user, content, sender_type="app", account_id=_account_id)
        else:
            logger.info("App ignoring non-text or empty message (type=%s)", msg_type)

        return PlainTextResponse("")


register_channel_routes(app)
