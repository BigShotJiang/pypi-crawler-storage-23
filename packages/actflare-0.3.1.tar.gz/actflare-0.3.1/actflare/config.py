import logging
import os
import stat
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import yaml

logger = logging.getLogger(__name__)


@dataclass
class PathsConfig:
    claude_cli: str
    huey_db: str
    workspace: str
    memory_db: str = "./data/memory.db"
    workdir: str = "./workdir"      # task root directory
    task_db: str = "./data/task.db"  # task tracking database


@dataclass
class AccountConfig:
    mode: str  # "bot" | "app"
    webhook_path: str
    token: str
    encoding_aes_key: str
    # Bot mode
    receive_id: str = ""
    # App mode
    corpid: str = ""
    corpsecret: str = ""
    agent_id: int = 0


@dataclass
class ChannelConfig:
    enabled: bool = True
    default_account: str = ""
    accounts: dict[str, AccountConfig] = field(default_factory=dict)


@dataclass
class ServerConfig:
    host: str = "0.0.0.0"
    port: int = 8001


@dataclass
class WorkerConfig:
    concurrency: int = 2
    worker_type: str = "process"


_DEFAULT_ALLOWED_TOOLS = ["Read", "Glob", "Grep", "Edit", "Write"]
_DEFAULT_SYSTEM_PROMPT = "你是企业内部开发助手，通过企业微信回答问题。输出简洁。"


@dataclass
class AgentConfig:
    max_turns: int = 10
    allowed_tools: list[str] = field(default_factory=lambda: list(_DEFAULT_ALLOWED_TOOLS))
    system_prompt: str = _DEFAULT_SYSTEM_PROMPT
    permission_mode: str = "default"
    model: Optional[str] = None
    env: dict[str, str] = field(default_factory=dict)
    cli_args: list[str] = field(default_factory=list)


@dataclass
class Config:
    paths: PathsConfig
    channels: dict[str, ChannelConfig]
    server: ServerConfig
    worker: WorkerConfig
    agent: AgentConfig


_config: Optional[Config] = None

DEFAULT_CONFIG_DIR = Path.home() / ".config" / "actflare"
DEFAULT_CONFIG_PATH = DEFAULT_CONFIG_DIR / "config.yml"


def _check_config_permissions(path: str) -> None:
    """检查配置文件权限，如果 group/other 可读则发出警告。"""
    try:
        file_stat = os.stat(path)
    except OSError:
        return
    # 仅在 Unix 系统上检查（Windows 无 st_mode 权限位语义）
    if not hasattr(file_stat, "st_mode"):
        return
    mode = file_stat.st_mode
    if mode & (stat.S_IRGRP | stat.S_IROTH):
        logger.warning(
            "配置文件 %s 权限过于宽松 (mode=%o)，建议设置为 600: chmod 600 %s",
            path,
            stat.S_IMODE(mode),
            path,
        )


def _resolve_config_path(path: Optional[str] = None) -> str:
    """Resolve config file path by priority.

    1. Explicit ``path`` argument
    2. ``ACTFLARE_CONFIG`` environment variable
    3. ``~/.config/actflare/config.yml``
    """
    if path is not None:
        return path
    env_path = os.environ.get("ACTFLARE_CONFIG")
    if env_path:
        return env_path
    return str(DEFAULT_CONFIG_PATH)


def load_config(path: Optional[str] = None) -> Config:
    """Load configuration from a YAML file.

    Resolution order for config path:
    1. Explicit ``path`` argument
    2. ``ACTFLARE_CONFIG`` environment variable
    3. ``~/.config/actflare/config.yml``
    """
    global _config

    path = _resolve_config_path(path)
    _check_config_permissions(path)

    with open(path, "r", encoding="utf-8") as f:
        raw = yaml.safe_load(f)

    channels: dict[str, ChannelConfig] = {}
    for ch_name, ch_raw in raw.get("channels", {}).items():
        accounts = {}
        for acc_name, acc_raw in ch_raw.get("accounts", {}).items():
            accounts[acc_name] = AccountConfig(**acc_raw)
        channels[ch_name] = ChannelConfig(
            enabled=ch_raw.get("enabled", True),
            default_account=ch_raw.get("default_account", ""),
            accounts=accounts,
        )

    _config = Config(
        paths=PathsConfig(**raw["paths"]),
        channels=channels,
        server=ServerConfig(**raw.get("server", {})),
        worker=WorkerConfig(**raw.get("worker", {})),
        agent=AgentConfig(
            max_turns=raw["agent"].get("max_turns", 10),
            allowed_tools=raw["agent"].get("allowed_tools", list(_DEFAULT_ALLOWED_TOOLS)),
            system_prompt=raw["agent"].get("system_prompt", _DEFAULT_SYSTEM_PROMPT),
            permission_mode=raw["agent"].get("permission_mode", "default"),
            model=raw["agent"].get("model"),
            env=raw["agent"].get("env", {}),
            cli_args=raw["agent"].get("cli_args", []),
        ),
    )

    # 环境变量覆盖敏感字段
    for ch_cfg in _config.channels.values():
        for acc_name, acc in ch_cfg.accounts.items():
            env_prefix = f"ACTFLARE_{acc_name.upper()}_"
            if v := os.environ.get(env_prefix + "CORPID"):
                acc.corpid = v
            if v := os.environ.get(env_prefix + "CORPSECRET"):
                acc.corpsecret = v
            if v := os.environ.get(env_prefix + "TOKEN"):
                acc.token = v

    # Resolve relative paths against the config file's directory
    config_dir = Path(path).resolve().parent
    _config.paths.huey_db = str((config_dir / _config.paths.huey_db).resolve())
    _config.paths.workspace = str((config_dir / _config.paths.workspace).resolve())
    _config.paths.memory_db = str((config_dir / _config.paths.memory_db).resolve())
    _config.paths.workdir = str((config_dir / _config.paths.workdir).resolve())
    _config.paths.task_db = str((config_dir / _config.paths.task_db).resolve())

    # Ensure workspace directory exists
    Path(_config.paths.workspace).mkdir(parents=True, exist_ok=True)
    # Ensure huey db directory exists
    Path(_config.paths.huey_db).parent.mkdir(parents=True, exist_ok=True)
    # Ensure memory db directory exists
    Path(_config.paths.memory_db).parent.mkdir(parents=True, exist_ok=True)
    # Ensure workdir exists
    Path(_config.paths.workdir).mkdir(parents=True, exist_ok=True)
    # Ensure task db directory exists
    Path(_config.paths.task_db).parent.mkdir(parents=True, exist_ok=True)

    return _config


def get_config() -> Config:
    """Return the cached Config singleton, loading it if necessary."""
    global _config
    if _config is None:
        return load_config()
    return _config
