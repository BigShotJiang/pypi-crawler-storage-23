# 任务跟踪指南

## Task ID 格式

所有通过 annoeva 或 annotask 投递的任务使用统一的 ID 格式：

```
{tool_name}_{YYYYMMDD}_{6位hex}
```

示例：`scrna_pipeline_20260225_a1b2c3`

## 任务记录

每次投递任务后，应通过 `actflare status` 命令或代码中 TaskDB 记录任务信息：

- task_id: 唯一任务标识
- tool_name: 使用的工具名称
- backend: 投递后端（annoeva / annotask）
- workdir: 工作目录
- status: 任务状态（created → running → completed / failed）

## 状态查询

### CLI 查询

```bash
actflare status <task_id>
```

输出任务的数据库记录信息（工具名、后端、工作目录、状态、创建时间）。

### 后端实时查询

- annoeva 项目：`annoeva stat -p <task_id>`
- annotask 任务：`annotask stat -p <task_id>`

## 最佳实践

1. 投递前生成 task_id 并记录
2. 投递后立即告知用户 task_id，方便后续查询
3. annotask/annoeva 自带通知系统，长时间运行的任务无需轮询
4. 用户再次询问时，可通过 task_id 查询最新状态
