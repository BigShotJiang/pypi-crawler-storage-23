# annoeva 投递模式指南

## 概述

annoeva 是项目级流水线管理工具，用于启动完整的生物信息分析流水线。每次调用创建一个独立项目。

## 命令格式

```bash
annoeva addproject -p <task_id> -t <type> -d <workdir>
```

### 参数说明

| 参数 | 说明 |
|------|------|
| `-p` | 项目 ID（即 task_id，格式：`{tool_name}_{YYYYMMDD}_{6hex}`） |
| `-t` | 项目类型（见下表） |
| `-d` | 工作目录路径 |

### 项目类型（-t）

| 类型 | 说明 |
|------|------|
| `scrna` | 单细胞 RNA-seq 分析 |
| `atac` | ATAC-seq 分析 |
| （其他类型由具体工具 skill 定义） | |

## 工作目录结构

annoeva 项目工作目录必须包含以下结构：

```
<workdir>/<task_id>/
├── Analysis/     # 分析结果输出
├── info/
│   └── info.xls  # 项目元数据（样本信息等）
└── Filter/
    └── GO.sign   # 过滤数据就绪标记
```

**重要**：在调用 annoeva addproject 之前，需确保 info/info.xls 已填写正确的样本元数据，Filter/ 目录已放置好过滤数据或链接。

## 准备流程

1. 使用数据库查询 skill 获取项目元数据（合同号、样本列表等）
2. 使用 query_path 或 cloud-download skill 定位过滤数据目录
3. 创建工作目录并准备 info/info.xls 和 Filter/ 内容
4. 调用 `annoeva addproject` 启动流水线

## 状态查询

```bash
annoeva stat -p <task_id>
```

查看项目运行状态和目录结构。
