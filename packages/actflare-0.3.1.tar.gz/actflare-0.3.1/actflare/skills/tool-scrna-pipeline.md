# 单细胞 RNA-seq 全流程分析（scrna_pipeline）

## 工具信息

- **工具名**: scrna_pipeline
- **投递模式**: annoeva
- **项目类型 (-t)**: scrna

## 功能说明

单细胞 RNA-seq（包括 10X Genomics、Smart-seq 等平台）的标准分析流水线。包含数据质控、细胞过滤、降维聚类、差异表达分析等步骤。

## 使用方法

### 1. 准备元数据

通过数据库查询或用户提供获取：
- 合同号、项目分期号
- 样本列表及对应的过滤数据路径
- 分析参数（如有特殊要求）

### 2. 准备工作目录

```bash
# 工作目录结构
<workdir>/annoeva/<task_id>/
├── Analysis/
├── info/
│   └── info.xls    # 填写样本信息
└── Filter/
    └── GO.sign     # 过滤数据就绪标记
```

### 3. 投递命令

```bash
annoeva addproject -p <task_id> -t scrna -d <workdir>
```

### 4. 状态查询

```bash
annoeva stat -p <task_id>
```

## 数据准备参考

- 过滤数据路径：参考 data_io skill 中的查找方法
- info.xls 模板：包含样本名、数据路径、分组信息等字段
