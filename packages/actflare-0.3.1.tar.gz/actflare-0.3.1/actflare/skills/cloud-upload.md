# 云存储上传

## 概述

将本地分析结果上传到云端对象存储（如阿里云 OSS），用于数据交付或备份。

## 前置条件

需要配置 ossutil 工具路径和认证信息（含公司内部地址，不提交到版本控制）。

## 命令模板

```bash
# TODO: 由用户配置实际路径和认证
# ossutil_path=<ossutil 路径>
# config_file=<ossutil 配置文件路径>

# 上传文件/目录
# $ossutil_path --config-file=$config_file cp <local_path> <oss_path> -r

# 验证上传
# $ossutil_path --config-file=$config_file ls <oss_path>
```

## 常用场景

### 上传分析结果
```bash
# 目标路径格式: oss://sci-scv/standard/Commercial/<产品子目录>/<合同号>/<项目分期号>/<分析员>/
# TODO: 填写实际 ossutil 路径和配置
```

### 上传交付数据
```bash
# TODO: 填写实际的交付 bucket 和路径格式
```

## 配置说明

请在首次使用时填写实际的 ossutil 路径和配置文件位置。此文件包含公司内部信息，已被 gitignore。
