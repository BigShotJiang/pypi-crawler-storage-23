"""Skills system — loads domain knowledge files and injects them into the agent prompt.

Skills are markdown files (.md) stored in two locations (both loaded, merged):
1. ~/.config/actflare/skills/   (default, higher priority)
2. {workspace}/skills/          (project-level, supplementary)

The agent can edit skill files to self-improve based on successful practice.
"""

import logging
import shutil
from datetime import datetime
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


def _default_skills_dir() -> Path:
    from actflare.config import DEFAULT_CONFIG_DIR
    return DEFAULT_CONFIG_DIR / "skills"


def _find_skills_example_dir() -> Path:
    """Locate the skills/ example directory shipped with the package."""
    pkg_dir = Path(__file__).resolve().parent
    candidate = pkg_dir / "skills"
    if candidate.is_dir():
        return candidate
    return pkg_dir


def ensure_skills_dir(skills_dir: Optional[Path] = None) -> Path:
    """Ensure the default skills directory exists with initial files."""
    target = skills_dir or _default_skills_dir()
    target.mkdir(parents=True, exist_ok=True)

    # Copy example skill files if the directory is empty
    if not any(target.glob("*.md")):
        example_dir = _find_skills_example_dir()
        for md_file in example_dir.glob("*.md"):
            dest = target / md_file.name
            if not dest.exists():
                shutil.copy2(md_file, dest)
                logger.info("Installed skill: %s", dest)

    return target


def load_skills(
    global_dir: Optional[str] = None,
    project_dir: Optional[str] = None,
) -> dict[str, str]:
    """Load all skill files from both directories.

    Args:
        global_dir: Override for global skills directory.
        project_dir: Override for project-level skills directory.

    Returns:
        Dict of {filename: content}, global files take precedence on conflict.
    """
    skills: dict[str, str] = {}

    # 1. Project-level skills (lower priority, loaded first)
    if project_dir:
        p = Path(project_dir)
        if p.is_dir():
            for md_file in sorted(p.glob("*.md")):
                try:
                    skills[md_file.name] = md_file.read_text(encoding="utf-8")
                except Exception as e:
                    logger.warning("Failed to read skill %s: %s", md_file, e)

    # 2. Global skills (higher priority, overwrites on conflict)
    g = Path(global_dir) if global_dir else _default_skills_dir()
    if g.is_dir():
        for md_file in sorted(g.glob("*.md")):
            try:
                skills[md_file.name] = md_file.read_text(encoding="utf-8")
            except Exception as e:
                logger.warning("Failed to read skill %s: %s", md_file, e)

    return skills


def list_skills(
    global_dir: Optional[str] = None,
    project_dir: Optional[str] = None,
) -> list[dict[str, str]]:
    """Return a summary of loaded skills for CLI display."""
    result: list[dict[str, str]] = []

    dirs_to_scan: list[tuple[str, Path]] = []

    g = Path(global_dir) if global_dir else _default_skills_dir()
    if g.is_dir():
        dirs_to_scan.append(("global", g))

    if project_dir:
        p = Path(project_dir)
        if p.is_dir():
            dirs_to_scan.append(("project", p))

    seen: set[str] = set()
    for source, d in dirs_to_scan:
        for md_file in sorted(d.glob("*.md")):
            name = md_file.name
            if name in seen:
                continue
            seen.add(name)
            # Extract first non-empty line as title
            try:
                text = md_file.read_text(encoding="utf-8")
                title = ""
                for line in text.splitlines():
                    stripped = line.strip().lstrip("#").strip()
                    if stripped:
                        title = stripped[:60]
                        break
            except Exception:
                title = "(读取失败)"
            result.append({
                "name": name,
                "source": source,
                "path": str(md_file),
                "title": title,
            })

    return result


def get_skill_metadata(skill_path: str) -> dict:
    """Return metadata for a skill file."""
    p = Path(skill_path)
    if not p.exists():
        return {}
    stat = p.stat()
    return {
        "name": p.name,
        "size_bytes": stat.st_size,
        "modified_at": datetime.fromtimestamp(stat.st_mtime).isoformat(),
    }


def build_skills_prompt_section(
    global_dir: Optional[str] = None,
    project_dir: Optional[str] = None,
) -> str:
    """Build the skills section for injection into the agent's system prompt."""
    skills = load_skills(global_dir, project_dir)
    if not skills:
        return ""

    # Build filename -> file path mapping for version tracking
    file_paths: dict[str, Path] = {}
    if project_dir:
        p = Path(project_dir)
        if p.is_dir():
            for md_file in p.glob("*.md"):
                file_paths[md_file.name] = md_file
    g = Path(global_dir) if global_dir else _default_skills_dir()
    if g.is_dir():
        for md_file in g.glob("*.md"):
            file_paths[md_file.name] = md_file  # Global overrides project

    lines = [
        "",
        "## 领域知识（Skills）",
        "",
    ]

    for filename, content in sorted(skills.items()):
        lines.append(content.rstrip())
        # Add metadata comment with modification time
        fp = file_paths.get(filename)
        if fp and fp.exists():
            mtime = datetime.fromtimestamp(fp.stat().st_mtime).isoformat()
        else:
            mtime = "unknown"
        lines.append(f"\n<!-- skill: {filename}, updated: {mtime} -->")
        lines.append("")

    # Self-improvement instruction
    lines.append("---")
    lines.append("")
    lines.append(
        "**自改进指令**: 如果你在实践中发现上述知识有误、过时，或发现了更准确的"
        "数据查找规律和路径模式，请使用 Edit 工具直接修改对应的 skill 文件"
        "（位于 ~/.config/actflare/skills/ 目录下）以改进后续交互的准确性。"
    )
    lines.append("")

    return "\n".join(lines)
