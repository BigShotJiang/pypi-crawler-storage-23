"""Claude Agent SDK wrapper.

Spawns a Claude CLI subprocess via the Agent SDK, passing custom environment
variables and CLI arguments from config.yml.
"""

import logging
import os
from pathlib import Path

from claude_agent_sdk import ClaudeAgentOptions, query

from actflare.config import get_config

logger = logging.getLogger(__name__)


async def run_claude_agent(prompt: str) -> tuple[str, int]:
    """Run Claude Agent SDK with the given prompt.

    Returns:
        A tuple of (result_text, turns_used).
    """
    cfg = get_config()

    # 构建本地 env 字典，通过 ClaudeAgentOptions.env 传递，避免修改全局 os.environ
    agent_env: dict[str, str] = {}
    for key, value in cfg.agent.env.items():
        agent_env[key] = str(value)

    # Build system prompt with tool descriptions and skills
    from actflare.skills import build_skills_prompt_section, ensure_skills_dir

    system_prompt = cfg.agent.system_prompt

    # Inject skills: global (~/.config/actflare/skills/) + project ({workspace}/skills/)
    ensure_skills_dir()
    project_skills_dir = str(Path(cfg.paths.workspace) / "skills")
    skills_section = build_skills_prompt_section(project_dir=project_skills_dir)
    if skills_section:
        system_prompt = system_prompt.rstrip() + "\n" + skills_section

    options = ClaudeAgentOptions(
        cwd=cfg.paths.workspace,
        allowed_tools=cfg.agent.allowed_tools,
        system_prompt=system_prompt,
        max_turns=cfg.agent.max_turns,
        permission_mode=cfg.agent.permission_mode,
        env=agent_env,
    )

    # Set optional fields only when configured
    if cfg.paths.claude_cli:
        options.cli_path = cfg.paths.claude_cli
    if cfg.agent.model:
        options.model = cfg.agent.model

    try:
        result_parts: list[str] = []
        turns_used = 1

        async for message in query(prompt=prompt, options=options):
            if hasattr(message, "result") and message.result:
                result_parts.append(message.result)
            elif message.type == "result":
                result_parts.append(getattr(message, "result", ""))

            # Capture num_turns from ResultMessage
            if hasattr(message, "num_turns"):
                turns_used = message.num_turns

        return "\n".join(part for part in result_parts if part), turns_used

    except Exception:
        logger.exception("Claude agent error")
        raise
