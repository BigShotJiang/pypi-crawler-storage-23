# ascii-tool

A simple image to ascii converter