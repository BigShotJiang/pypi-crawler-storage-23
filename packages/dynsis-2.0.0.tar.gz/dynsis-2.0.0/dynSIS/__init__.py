from .core import run_simulation
from .types import SimulationArgs

__version__ = "2.0.0"

__all__ = ["run_simulation", "SimulationArgs"]

# Print a text banner when the package is imported
banner = r"""
Please cite the following paper if you use dynSIS in your research:

    Wesley Cota, Silvio C. Ferreira.
    Optimized Gillespie algorithms for the simulation of Markovian epidemic processes on large and heterogeneous networks.
    arXiv:1704.01557, 2017. DOI:10.1016/j.cpc.2017.06.007. https://doi.org/10.1016/j.cpc.2017.06.007
"""

print(banner)
