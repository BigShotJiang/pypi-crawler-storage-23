from setuptools import setup, find_packages
from setuptools.command.build_ext import build_ext as build_ext_orig
from setuptools.command.build_py import build_py as build_py_orig
import subprocess
import sys
import os
from pathlib import Path

def build_fortran():
    """Lógica de compilação ajustada para setup.py dentro da pasta /python."""
    compiler = os.environ.get("FC", "gfortran")
    fflags = os.environ.get("FFLAGS", "-O3 -ffree-line-length-512")

    # O setup.py está em /python, então a raiz do projeto (onde está o fpm.toml) é ../
    project_root = Path(__file__).parent.parent.absolute()
    # O destino do binário deve ser dentro da pasta dynSIS que está no mesmo nível deste setup.py
    prefix_path = Path(__file__).parent / "dynSIS"

    print(f"\n🚀 Iniciando compilação Fortran em: {project_root}")

    try:
        # Rodamos o fpm a partir da raiz do projeto
        subprocess.run(["fpm", "clean", "--all"], cwd=project_root, check=True)
        subprocess.run([
            "fpm", "install",
            "--profile", "release",
            "--compiler", compiler,
            "--flag", fflags,
            "--prefix", str(prefix_path)
        ], cwd=project_root, check=True)
        print("✅ Compilação concluída com sucesso!\n")
    except subprocess.CalledProcessError:
        print("\n❌ ERRO FATAL: Falha na compilação do Fortran.")
        sys.exit(1)

class BuildExtWithFPM(build_ext_orig):
    def run(self):
        build_fortran()

class BuildPyWithFPM(build_py_orig):
    def run(self):
        build_fortran()
        super().run()

setup(
    name="dynSIS",
    version="0.1.0",
    # find_packages() agora encontra a pasta dynSIS aqui mesmo
    packages=find_packages(),
    python_requires=">=3.10",
    cmdclass={
        "build_py": BuildPyWithFPM,
        "build_ext": BuildExtWithFPM,
    },
    include_package_data=True,
    # O binário vai estar em dynSIS/bin/...
    package_data={"dynSIS": ["bin/*"]},
    entry_points={
        "console_scripts": [
            "dynSIS_sampling=dynSIS.bin.dynSIS_sampling:main_stub",
        ],
    },
)