# dependencies
import drs4


def test_namespace() -> None:
    drs4.ctrl
    drs4.daq
    drs4.qlook
    drs4.specs
    drs4.utils
