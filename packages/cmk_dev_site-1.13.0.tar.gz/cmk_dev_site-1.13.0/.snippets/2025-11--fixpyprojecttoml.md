## fix pyproject toml file
<!--
type: bugfix
scope: internal
affected: all
-->

fix pyproject toml file. this made the last release fail.

also fix typing problem which was caused by a not rebased merge
