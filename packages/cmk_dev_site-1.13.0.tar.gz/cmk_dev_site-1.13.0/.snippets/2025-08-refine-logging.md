## Refine logging
<!--
type: feature
scope: all
affected: all
-->
The logging decorator now includes an optional flag to print the output of functions.
Additionally, the `url_exist` message has been removed to prevent unnecessary information from being displayed.
