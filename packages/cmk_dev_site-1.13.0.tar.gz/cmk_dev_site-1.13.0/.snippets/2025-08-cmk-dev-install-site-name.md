## Add name argument to cmk-dev install-site
<!--
type: feature
scope: all
affected: all
-->

Now `--name` is available to specify the name of the site created with
`cmk-dev site-install`.
