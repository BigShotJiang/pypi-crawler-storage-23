## Refine log output
<!--
type: feature
scope: all
affected: all
-->

The log output is more concise and now includes the site link.
