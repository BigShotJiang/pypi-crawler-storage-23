## implementing https redirect for cmk-dev-site. Right now it only supports http traffic
<!--
type: feature
scope: all
affected: all
-->

TBD
