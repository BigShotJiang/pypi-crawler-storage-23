## Enable install of 2.4.0
<!--
type: bugfix
scope: all
affected: all
-->

Creating a site with `cmk-dev-install-site 2.4.0` failed with an error:

```
ERROR: Checkmk 2.4.0p0 is not installed.
```
