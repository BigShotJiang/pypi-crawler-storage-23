"""Tests for comprehension cleanup recipes."""

from rewrite.test import RecipeSpec, python
from openrewrite_static_analysis.cleanup.comprehension_cleanup import (
    CollectionBuiltinToComprehension,
    ComprehensionToGenerator,
    ConvertAnyToIn,
    IdentityComprehension,
    InvertAnyAll,
    InvertAnyAllBody,
    SimplifyConstantSum,
    SimplifyGenerator,
)


class TestCollectionBuiltinToComprehension:
    """Tests for the CollectionBuiltinToComprehension recipe."""

    def test_list_generator_to_comprehension(self):
        """Test that list(x for x in items) is replaced with [x for x in items]."""
        spec = RecipeSpec(recipe=CollectionBuiltinToComprehension())
        spec.rewrite_run(
            python(
                """
                result = list(x for x in items)
                """,
                """
                result = [x for x in items]
                """,
            )
        )

    def test_set_generator_to_comprehension(self):
        """Test that set(x for x in items) is replaced with {x for x in items}."""
        spec = RecipeSpec(recipe=CollectionBuiltinToComprehension())
        spec.rewrite_run(
            python(
                """
                result = set(x for x in items)
                """,
                """
                result = {x for x in items}
                """,
            )
        )

    def test_list_generator_with_expression(self):
        """Test that list(x * 2 for x in items) is replaced with [x * 2 for x in items]."""
        spec = RecipeSpec(recipe=CollectionBuiltinToComprehension())
        spec.rewrite_run(
            python(
                """
                result = list(x * 2 for x in items)
                """,
                """
                result = [x * 2 for x in items]
                """,
            )
        )

    def test_list_generator_with_condition(self):
        """Test that list(x for x in items if x > 0) is replaced with [x for x in items if x > 0]."""
        spec = RecipeSpec(recipe=CollectionBuiltinToComprehension())
        spec.rewrite_run(
            python(
                """
                result = list(x for x in items if x > 0)
                """,
                """
                result = [x for x in items if x > 0]
                """,
            )
        )

    def test_no_change_list_with_iterable(self):
        """Test that list(items) is not changed -- it's not a generator expression."""
        spec = RecipeSpec(recipe=CollectionBuiltinToComprehension())
        spec.rewrite_run(
            python(
                """
                result = list(items)
                """
            )
        )

    def test_no_change_empty_list(self):
        """Test that list() is not changed."""
        spec = RecipeSpec(recipe=CollectionBuiltinToComprehension())
        spec.rewrite_run(
            python(
                """
                result = list()
                """
            )
        )

    def test_no_change_method_call_on_object(self):
        """Test that obj.list(x for x in items) is not changed."""
        spec = RecipeSpec(recipe=CollectionBuiltinToComprehension())
        spec.rewrite_run(
            python(
                """
                result = obj.list(x for x in items)
                """
            )
        )


class TestSimplifyGenerator:
    """Tests for the SimplifyGenerator recipe."""

    def test_any_identity(self):
        """Test that any(x for x in items) is simplified to any(items)."""
        spec = RecipeSpec(recipe=SimplifyGenerator())
        spec.rewrite_run(
            python(
                """
                result = any(x for x in items)
                """,
                """
                result = any(items)
                """,
            )
        )

    def test_all_identity(self):
        """Test that all(x for x in items) is simplified to all(items)."""
        spec = RecipeSpec(recipe=SimplifyGenerator())
        spec.rewrite_run(
            python(
                """
                result = all(x for x in items)
                """,
                """
                result = all(items)
                """,
            )
        )

    def test_no_change_with_filter(self):
        """Test that any(x for x in items if x > 0) is not changed."""
        spec = RecipeSpec(recipe=SimplifyGenerator())
        spec.rewrite_run(
            python(
                """
                result = any(x for x in items if x > 0)
                """
            )
        )

    def test_no_change_with_transformation(self):
        """Test that any(x + 1 for x in items) is not changed -- not identity."""
        spec = RecipeSpec(recipe=SimplifyGenerator())
        spec.rewrite_run(
            python(
                """
                result = any(x + 1 for x in items)
                """
            )
        )

    def test_no_change_non_builtin(self):
        """Test that custom_func(x for x in items) is not changed."""
        spec = RecipeSpec(recipe=SimplifyGenerator())
        spec.rewrite_run(
            python(
                """
                result = custom_func(x for x in items)
                """
            )
        )

    def test_no_change_method_on_object(self):
        """Test that obj.any(x for x in items) is not changed."""
        spec = RecipeSpec(recipe=SimplifyGenerator())
        spec.rewrite_run(
            python(
                """
                result = obj.any(x for x in items)
                """
            )
        )


class TestComprehensionToGenerator:
    """Tests for the ComprehensionToGenerator recipe."""

    def test_any_list_comprehension_to_generator(self):
        """Test that any([x for x in items]) becomes any(x for x in items)."""
        spec = RecipeSpec(recipe=ComprehensionToGenerator())
        spec.rewrite_run(
            python(
                """
                result = any([x for x in items])
                """,
                """
                result = any(x for x in items)
                """,
            )
        )

    def test_all_list_comprehension_to_generator(self):
        """Test that all([x for x in items]) becomes all(x for x in items)."""
        spec = RecipeSpec(recipe=ComprehensionToGenerator())
        spec.rewrite_run(
            python(
                """
                result = all([x for x in items])
                """,
                """
                result = all(x for x in items)
                """,
            )
        )

    def test_sum_list_comprehension_to_generator(self):
        """Test that sum([x for x in items]) becomes sum(x for x in items)."""
        spec = RecipeSpec(recipe=ComprehensionToGenerator())
        spec.rewrite_run(
            python(
                """
                result = sum([x for x in items])
                """,
                """
                result = sum(x for x in items)
                """,
            )
        )

    def test_min_list_comprehension_to_generator(self):
        """Test that min([x for x in items]) becomes min(x for x in items)."""
        spec = RecipeSpec(recipe=ComprehensionToGenerator())
        spec.rewrite_run(
            python(
                """
                result = min([x for x in items])
                """,
                """
                result = min(x for x in items)
                """,
            )
        )

    def test_max_list_comprehension_to_generator(self):
        """Test that max([x for x in items]) becomes max(x for x in items)."""
        spec = RecipeSpec(recipe=ComprehensionToGenerator())
        spec.rewrite_run(
            python(
                """
                result = max([x for x in items])
                """,
                """
                result = max(x for x in items)
                """,
            )
        )

    def test_sorted_list_comprehension_to_generator(self):
        """Test that sorted([x for x in items]) becomes sorted(x for x in items)."""
        spec = RecipeSpec(recipe=ComprehensionToGenerator())
        spec.rewrite_run(
            python(
                """
                result = sorted([x for x in items])
                """,
                """
                result = sorted(x for x in items)
                """,
            )
        )

    def test_any_with_expression_and_filter(self):
        """Test that any([is_hat(item) for item in wardrobe]) works."""
        spec = RecipeSpec(recipe=ComprehensionToGenerator())
        spec.rewrite_run(
            python(
                """
                hat_found = any([is_hat(item) for item in wardrobe])
                """,
                """
                hat_found = any(is_hat(item) for item in wardrobe)
                """,
            )
        )

    def test_no_change_generator_already(self):
        """Test that any(x for x in items) is not changed -- already a generator."""
        spec = RecipeSpec(recipe=ComprehensionToGenerator())
        spec.rewrite_run(
            python(
                """
                result = any(x for x in items)
                """
            )
        )

    def test_no_change_non_matching_function(self):
        """Test that foo([x for x in items]) is not changed."""
        spec = RecipeSpec(recipe=ComprehensionToGenerator())
        spec.rewrite_run(
            python(
                """
                result = foo([x for x in items])
                """
            )
        )

    def test_no_change_set_comprehension(self):
        """Test that any({x for x in items}) is not changed -- set comprehension."""
        spec = RecipeSpec(recipe=ComprehensionToGenerator())
        spec.rewrite_run(
            python(
                """
                result = any({x for x in items})
                """
            )
        )

    def test_no_change_method_on_object(self):
        """Test that obj.any([x for x in items]) is not changed."""
        spec = RecipeSpec(recipe=ComprehensionToGenerator())
        spec.rewrite_run(
            python(
                """
                result = obj.any([x for x in items])
                """
            )
        )


class TestIdentityComprehension:
    """Tests for the IdentityComprehension recipe."""

    def test_list_identity_to_list(self):
        """Test that [item for item in coll] becomes list(coll)."""
        spec = RecipeSpec(recipe=IdentityComprehension())
        spec.rewrite_run(
            python(
                """
                result = [item for item in coll]
                """,
                """
                result = list(coll)
                """,
            )
        )

    def test_set_identity_to_set_constructor(self):
        """Test that {item for item in coll} becomes set(coll)."""
        spec = RecipeSpec(recipe=IdentityComprehension())
        spec.rewrite_run(
            python(
                """
                result = {item for item in coll}
                """,
                """
                result = set(coll)
                """,
            )
        )

    def test_no_change_with_transformation(self):
        """Test that [x + 1 for x in items] is not changed -- not identity."""
        spec = RecipeSpec(recipe=IdentityComprehension())
        spec.rewrite_run(
            python(
                """
                result = [x + 1 for x in items]
                """
            )
        )

    def test_no_change_with_filter(self):
        """Test that [x for x in items if x > 0] is not changed -- has filter."""
        spec = RecipeSpec(recipe=IdentityComprehension())
        spec.rewrite_run(
            python(
                """
                result = [x for x in items if x > 0]
                """
            )
        )

    def test_no_change_generator(self):
        """Test that a generator expression (x for x in items) is not changed."""
        spec = RecipeSpec(recipe=IdentityComprehension())
        spec.rewrite_run(
            python(
                """
                result = any(x for x in items)
                """
            )
        )

    def test_no_change_async_comprehension(self):
        """Test that [x async for x in aiter] is NOT changed -- async iteration."""
        spec = RecipeSpec(recipe=IdentityComprehension())
        spec.rewrite_run(
            python(
                """
                async def f():
                    result = [x async for x in aiter]
                """
            )
        )


class TestInvertAnyAll:
    """Tests for the InvertAnyAll recipe."""

    def test_not_all_to_any_negated(self):
        """Test that not all(a > b for a in things) becomes any(a <= b for a in things)."""
        spec = RecipeSpec(recipe=InvertAnyAll())
        spec.rewrite_run(
            python(
                """
                b = not all(a > b for a in things)
                """,
                """
                b = any(a <= b for a in things)
                """,
            )
        )

    def test_not_any_to_all_negated(self):
        """Test that not any(a > b for a in things) becomes all(a <= b for a in things)."""
        spec = RecipeSpec(recipe=InvertAnyAll())
        spec.rewrite_run(
            python(
                """
                b = not any(a > b for a in things)
                """,
                """
                b = all(a <= b for a in things)
                """,
            )
        )

    def test_not_all_equal_to_any_not_equal(self):
        """Test that not all(x == y for x in items) becomes any(x != y for x in items)."""
        spec = RecipeSpec(recipe=InvertAnyAll())
        spec.rewrite_run(
            python(
                """
                result = not all(x == y for x in items)
                """,
                """
                result = any(x != y for x in items)
                """,
            )
        )

    def test_no_change_without_not(self):
        """Test that all(a > b for a in things) is not changed -- no negation."""
        spec = RecipeSpec(recipe=InvertAnyAll())
        spec.rewrite_run(
            python(
                """
                b = all(a > b for a in things)
                """
            )
        )

    def test_no_change_not_other_func(self):
        """Test that not sum(x for x in items) is not changed -- not any/all."""
        spec = RecipeSpec(recipe=InvertAnyAll())
        spec.rewrite_run(
            python(
                """
                b = not sum(x for x in items)
                """
            )
        )


class TestInvertAnyAllBody:
    """Tests for the InvertAnyAllBody recipe."""

    def test_any_not_to_not_all(self):
        """Test that any(not a for a in things) becomes not all(things)."""
        spec = RecipeSpec(recipe=InvertAnyAllBody())
        spec.rewrite_run(
            python(
                """
                b = any(not a for a in things)
                """,
                """
                b = not all(things)
                """,
            )
        )

    def test_all_not_to_not_any(self):
        """Test that all(not a for a in things) becomes not any(things)."""
        spec = RecipeSpec(recipe=InvertAnyAllBody())
        spec.rewrite_run(
            python(
                """
                b = all(not a for a in things)
                """,
                """
                b = not any(things)
                """,
            )
        )

    def test_no_change_without_negation(self):
        """Test that any(a for a in things) is not changed -- no negation in body."""
        spec = RecipeSpec(recipe=InvertAnyAllBody())
        spec.rewrite_run(
            python(
                """
                b = any(a for a in things)
                """
            )
        )

    def test_no_change_non_identity_negation(self):
        """Test that any(not f(a) for a in things) is not changed -- negation of non-identity."""
        spec = RecipeSpec(recipe=InvertAnyAllBody())
        spec.rewrite_run(
            python(
                """
                b = any(not f(a) for a in things)
                """
            )
        )


class TestConvertAnyToIn:
    """Tests for the ConvertAnyToIn recipe."""

    def test_any_equality_to_in(self):
        """Test that any(hat == 'bowler' for hat in hats) becomes 'bowler' in hats."""
        spec = RecipeSpec(recipe=ConvertAnyToIn())
        spec.rewrite_run(
            python(
                """
                if any(hat == "bowler" for hat in hats):
                    shout("I have a bowler hat!")
                """,
                """
                if "bowler" in hats:
                    shout("I have a bowler hat!")
                """,
            )
        )

    def test_any_equality_literal_on_left(self):
        """Test that any('bowler' == hat for hat in hats) becomes 'bowler' in hats."""
        spec = RecipeSpec(recipe=ConvertAnyToIn())
        spec.rewrite_run(
            python(
                """
                result = any("bowler" == hat for hat in hats)
                """,
                """
                result = "bowler" in hats
                """,
            )
        )

    def test_no_change_non_equality(self):
        """Test that any(hat > 'bowler' for hat in hats) is not changed."""
        spec = RecipeSpec(recipe=ConvertAnyToIn())
        spec.rewrite_run(
            python(
                """
                result = any(hat > "bowler" for hat in hats)
                """
            )
        )

    def test_no_change_no_literal(self):
        """Test that any(hat == other for hat in hats) is not changed -- no literal."""
        spec = RecipeSpec(recipe=ConvertAnyToIn())
        spec.rewrite_run(
            python(
                """
                result = any(hat == other for hat in hats)
                """
            )
        )

    def test_no_change_with_filter(self):
        """Test that any(hat == 'bowler' for hat in hats if hat) is not changed -- has filter."""
        spec = RecipeSpec(recipe=ConvertAnyToIn())
        spec.rewrite_run(
            python(
                """
                result = any(hat == "bowler" for hat in hats if hat)
                """
            )
        )


class TestSimplifyConstantSum:
    """Tests for the SimplifyConstantSum recipe."""

    def test_sum_1_with_filter(self):
        """Test sum(1 for book in books if cond) becomes sum(bool(cond) for book in books)."""
        spec = RecipeSpec(recipe=SimplifyConstantSum())
        spec.rewrite_run(
            python(
                """
                count = sum(1 for book in books if book.author == "Terry Pratchett")
                """,
                """
                count = sum(bool(book.author == "Terry Pratchett") for book in books)
                """,
            )
        )

    def test_no_change_non_constant(self):
        """Test that sum(x for x in items if cond) is not changed -- non-constant expression."""
        spec = RecipeSpec(recipe=SimplifyConstantSum())
        spec.rewrite_run(
            python(
                """
                total = sum(x for x in items if x > 0)
                """
            )
        )

    def test_no_change_no_filter(self):
        """Test that sum(1 for x in items) is not changed -- no filter."""
        spec = RecipeSpec(recipe=SimplifyConstantSum())
        spec.rewrite_run(
            python(
                """
                count = sum(1 for x in items)
                """
            )
        )

    def test_simplify_constant_sum_removes_filter(self):
        """sum(1 for x in items if cond) should drop the `if` clause in output."""
        spec = RecipeSpec(recipe=SimplifyConstantSum())
        spec.rewrite_run(
            python(
                "total = sum(1 for x in items if x > 0)",
                "total = sum(bool(x > 0) for x in items)",
            )
        )

    def test_simplify_constant_sum_removes_isinstance_filter(self):
        """sum(1 for obj in items if isinstance(obj, r.Rule)) should drop the filter."""
        spec = RecipeSpec(recipe=SimplifyConstantSum())
        spec.rewrite_run(
            python(
                "count = sum(1 for obj in objects if isinstance(obj, r.Rule))",
                "count = sum(bool(isinstance(obj, r.Rule)) for obj in objects)",
            )
        )
