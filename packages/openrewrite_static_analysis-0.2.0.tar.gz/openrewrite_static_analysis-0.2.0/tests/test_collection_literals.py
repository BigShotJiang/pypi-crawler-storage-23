"""Tests for collection literal cleanup recipes."""

from rewrite.test import RecipeSpec, python
from openrewrite_static_analysis.cleanup.collection_literals import (
    DictLiteral,
    ListLiteral,
    TupleLiteral,
    CollectionIntoSet,
    UnwrapIterableConstruction,
)


class TestDictLiteral:
    """Tests for the DictLiteral recipe."""

    def test_replaces_empty_dict_call(self):
        """Test that dict() is replaced with {}."""
        spec = RecipeSpec(recipe=DictLiteral())
        spec.rewrite_run(
            python(
                """
                x = dict()
                """,
                """
                x = {}
                """,
            )
        )

    def test_no_change_with_keyword_args(self):
        """Test that dict(a=1) is not changed."""
        spec = RecipeSpec(recipe=DictLiteral())
        spec.rewrite_run(
            python(
                """
                x = dict(a=1, b=2)
                """
            )
        )

    def test_no_change_with_positional_args(self):
        """Test that dict(iterable) is not changed."""
        spec = RecipeSpec(recipe=DictLiteral())
        spec.rewrite_run(
            python(
                """
                x = dict([("a", 1)])
                """
            )
        )


class TestListLiteral:
    """Tests for the ListLiteral recipe."""

    def test_replaces_empty_list_call(self):
        """Test that list() is replaced with []."""
        spec = RecipeSpec(recipe=ListLiteral())
        spec.rewrite_run(
            python(
                """
                x = list()
                """,
                """
                x = []
                """,
            )
        )

    def test_no_change_with_args(self):
        """Test that list(iterable) is not changed."""
        spec = RecipeSpec(recipe=ListLiteral())
        spec.rewrite_run(
            python(
                """
                x = list(range(10))
                """
            )
        )

    def test_no_change_with_string_arg(self):
        """Test that list("abc") is not changed."""
        spec = RecipeSpec(recipe=ListLiteral())
        spec.rewrite_run(
            python(
                """
                x = list("abc")
                """
            )
        )


class TestTupleLiteral:
    """Tests for the TupleLiteral recipe."""

    def test_replaces_empty_tuple_call(self):
        """Test that tuple() is replaced with ()."""
        spec = RecipeSpec(recipe=TupleLiteral())
        spec.rewrite_run(
            python(
                """
                x = tuple()
                """,
                """
                x = ()
                """,
            )
        )

    def test_no_change_with_args(self):
        """Test that tuple(iterable) is not changed."""
        spec = RecipeSpec(recipe=TupleLiteral())
        spec.rewrite_run(
            python(
                """
                x = tuple([1, 2, 3])
                """
            )
        )

    def test_no_change_with_generator(self):
        """Test that tuple(gen) is not changed."""
        spec = RecipeSpec(recipe=TupleLiteral())
        spec.rewrite_run(
            python(
                """
                x = tuple(i for i in range(5))
                """
            )
        )


class TestCollectionIntoSet:
    """Tests for CollectionIntoSet: use set for membership checking of literals."""

    def test_list_to_set_in_if(self):
        """Test currency in ['EUR', 'USD'] -> currency in {'EUR', 'USD'}."""
        spec = RecipeSpec(recipe=CollectionIntoSet())
        spec.rewrite_run(
            python(
                'x = currency in ["EUR", "USD"]',
                'x = currency in {"EUR", "USD"}',
            )
        )

    def test_tuple_to_set(self):
        """Test x in (1, 2, 3) -> x in {1, 2, 3}."""
        spec = RecipeSpec(recipe=CollectionIntoSet())
        spec.rewrite_run(
            python(
                "x = val in (1, 2, 3)",
                "x = val in {1, 2, 3}",
            )
        )

    def test_no_change_already_set(self):
        """Test that set literals are not changed."""
        spec = RecipeSpec(recipe=CollectionIntoSet())
        spec.rewrite_run(
            python(
                'x = currency in {"EUR", "USD"}',
            )
        )

    def test_no_change_non_literal_elements(self):
        """Test that lists with non-literal elements are not changed."""
        spec = RecipeSpec(recipe=CollectionIntoSet())
        spec.rewrite_run(
            python(
                "x = val in [a, b, c]",
            )
        )


class TestUnwrapIterableConstruction:
    """Tests for UnwrapIterableConstruction: unwrap constructor into literal."""

    def test_tuple_of_list(self):
        """Test tuple([a, b, c]) -> (a, b, c)."""
        spec = RecipeSpec(recipe=UnwrapIterableConstruction())
        spec.rewrite_run(
            python(
                "x = tuple([a, b, c])",
                "x = (a, b, c)",
            )
        )

    def test_list_of_tuple(self):
        """Test list((a, b, c)) -> [a, b, c]."""
        spec = RecipeSpec(recipe=UnwrapIterableConstruction())
        spec.rewrite_run(
            python(
                "x = list((a, b, c))",
                "x = [a, b, c]",
            )
        )

    def test_set_of_list(self):
        """Test set([a, b, c]) -> {a, b, c}."""
        spec = RecipeSpec(recipe=UnwrapIterableConstruction())
        spec.rewrite_run(
            python(
                "x = set([a, b, c])",
                "x = {a, b, c}",
            )
        )

    def test_no_change_empty_constructor(self):
        """Test that empty constructors are not changed (handled by other recipes)."""
        spec = RecipeSpec(recipe=UnwrapIterableConstruction())
        spec.rewrite_run(
            python(
                "x = list()",
            )
        )

    def test_no_change_non_literal_arg(self):
        """Test that constructors with non-literal args are not changed."""
        spec = RecipeSpec(recipe=UnwrapIterableConstruction())
        spec.rewrite_run(
            python(
                "x = list(range(10))",
            )
        )

    def test_tuple_single_element_gets_trailing_comma(self):
        """tuple([x]) -> (x,) — trailing comma preserves tuple semantics."""
        spec = RecipeSpec(recipe=UnwrapIterableConstruction())
        spec.rewrite_run(
            python(
                "x = tuple([single])",
                "x = (single,)",
            )
        )
