"""Tests for the PythonBestPractices composite recipe."""

from rewrite.test import RecipeSpec, python
from openrewrite_static_analysis.cleanup.python_best_practices import PythonBestPractices


class TestPythonBestPractices:
    """Tests for the PythonBestPractices composite recipe."""

    def test_recipe_list_not_empty(self):
        """Test that the composite recipe has recipes."""
        recipe = PythonBestPractices()
        recipes = recipe.recipe_list()
        assert len(recipes) > 0

    def test_recipe_metadata(self):
        """Test composite recipe metadata."""
        recipe = PythonBestPractices()
        assert recipe.name == "org.openrewrite.python.cleanup.PythonBestPractices"
        assert "cleanup" in recipe.display_name.lower()

    def test_applies_dict_literal(self):
        """Test that the composite recipe applies DictLiteral."""
        spec = RecipeSpec(recipe=PythonBestPractices())
        spec.rewrite_run(
            python(
                """
                x = dict()
                """,
                """
                x = {}
                """,
            )
        )

    def test_applies_none_compare(self):
        """Test that the composite recipe applies NoneCompare."""
        spec = RecipeSpec(recipe=PythonBestPractices())
        spec.rewrite_run(
            python(
                """
                if x == None:
                    print("found")
                """,
                """
                if x is None:
                    print("found")
                """,
            )
        )

    def test_applies_remove_redundant_pass(self):
        """Test that the composite recipe applies RemoveRedundantPass."""
        spec = RecipeSpec(recipe=PythonBestPractices())
        spec.rewrite_run(
            python(
                """
                class Foo:
                    x = 1
                    pass
                """,
                """
                class Foo:
                    x = 1
                """,
            )
        )

    def test_applies_multiple_recipes(self):
        """Test that multiple cleanup rules fire in one pass."""
        spec = RecipeSpec(recipe=PythonBestPractices())
        spec.rewrite_run(
            python(
                """
                x = dict()
                y = list()
                if z == None:
                    print("found")
                """,
                """
                x = {}
                y = []
                if z is None:
                    print("found")
                """,
            )
        )

    def test_no_change_when_clean(self):
        """Test that clean code is not modified."""
        spec = RecipeSpec(recipe=PythonBestPractices())
        spec.rewrite_run(
            python(
                """
                x = {}
                y = []
                if z is None:
                    print("found")
                """
            )
        )
