"""Tests for dict cleanup recipes."""

import pytest
from rewrite.test import RecipeSpec, python
from openrewrite_static_analysis.cleanup.dict_cleanup import (
    RemoveDictKeys,
    SimplifyDictionaryUpdate,
    UseDictionaryUnion,
    RemoveRedundantConstructorInDictUnion,
    RemoveDuplicateDictKey,
    RemoveDuplicateSetKey,
)


class TestRemoveDictKeys:
    """Tests for the RemoveDictKeys recipe."""

    def test_removes_keys_in_for(self):
        """Test that d.keys() is simplified to d in a for loop."""
        spec = RecipeSpec(recipe=RemoveDictKeys())
        spec.rewrite_run(
            python(
                """
                for k in d.keys():
                    print(k)
                """,
                """
                for k in d:
                    print(k)
                """,
            )
        )

    def test_removes_keys_in_membership(self):
        """Test that d.keys() is simplified to d in a membership test."""
        spec = RecipeSpec(recipe=RemoveDictKeys())
        spec.rewrite_run(
            python(
                """
                if k in d.keys():
                    pass
                """,
                """
                if k in d:
                    pass
                """,
            )
        )

    def test_no_change_in_assignment(self):
        """Test that d.keys() is NOT simplified in an assignment context.

        `.keys()` returns a `dict_keys` view, not the dict itself, so
        removing it in assignment context changes semantics.
        """
        spec = RecipeSpec(recipe=RemoveDictKeys())
        spec.rewrite_run(
            python(
                """
                x = d.keys()
                """
            )
        )

    def test_no_change_values(self):
        """Test that d.values() is not changed."""
        spec = RecipeSpec(recipe=RemoveDictKeys())
        spec.rewrite_run(
            python(
                """
                x = d.values()
                """
            )
        )

    def test_no_change_items(self):
        """Test that d.items() is not changed."""
        spec = RecipeSpec(recipe=RemoveDictKeys())
        spec.rewrite_run(
            python(
                """
                x = d.items()
                """
            )
        )


class TestSimplifyDictionaryUpdate:
    """Tests for the SimplifyDictionaryUpdate recipe."""

    def test_single_string_key_update(self):
        """Test that d.update({"k": v}) is simplified to d["k"] = v."""
        spec = RecipeSpec(recipe=SimplifyDictionaryUpdate())
        spec.rewrite_run(
            python(
                """
                d.update({"request": HttpRequest()})
                """,
                """
                d["request"] = HttpRequest()
                """,
            )
        )

    def test_single_key_simple_value(self):
        """Test with a simple string value."""
        spec = RecipeSpec(recipe=SimplifyDictionaryUpdate())
        spec.rewrite_run(
            python(
                """
                config.update({"key": "value"})
                """,
                """
                config["key"] = "value"
                """,
            )
        )

    def test_no_change_multiple_keys(self):
        """Test that multi-key dict updates are not changed."""
        spec = RecipeSpec(recipe=SimplifyDictionaryUpdate())
        spec.rewrite_run(
            python(
                """
                d.update({"a": 1, "b": 2})
                """
            )
        )

    def test_no_change_keyword_args(self):
        """Test that keyword-style updates are not changed."""
        spec = RecipeSpec(recipe=SimplifyDictionaryUpdate())
        spec.rewrite_run(
            python(
                """
                d.update(key="value")
                """
            )
        )

    def test_no_change_inside_exception_test(self):
        """update() and bracket assignment raise different exception types on read-only mappings.

        `mapping.update({k: v})` raises AttributeError (no `update` method),
        while `mapping[k] = v` raises TypeError (unhashable or read-only).
        Converting one to the other inside `pytest.raises(AttributeError)`
        would break the test.
        """
        spec = RecipeSpec(recipe=SimplifyDictionaryUpdate())
        spec.rewrite_run(
            python(
                """
                with pytest.raises(AttributeError):
                    a.metadata.update({"key": "value"})
                """
            )
        )

    def test_no_change_variable_arg(self):
        """Test that variable argument updates are not changed."""
        spec = RecipeSpec(recipe=SimplifyDictionaryUpdate())
        spec.rewrite_run(
            python(
                """
                d.update(other_dict)
                """
            )
        )

    def test_no_change_inside_lambda(self):
        """dict.update inside lambda must not be transformed.

        Assignment statements are not valid inside a lambda body, so
        converting ``lambda v: d.update({"k": v})`` into
        ``lambda v: d["k"] = v`` produces a SyntaxError.
        """
        spec = RecipeSpec(recipe=SimplifyDictionaryUpdate())
        spec.rewrite_run(
            python('f = lambda v: d.update({"k": v})')
        )

    def test_update_inside_function_body(self):
        """dict.update inside function body should preserve indentation."""
        spec = RecipeSpec(recipe=SimplifyDictionaryUpdate())
        spec.rewrite_run(
            python(
                'def f():\n    d.update({"k": v})',
                'def f():\n    d["k"] = v',
            )
        )


class TestUseDictionaryUnion:
    """Tests for the UseDictionaryUnion recipe."""

    def test_two_dict_unpacking(self):
        """Test that {**a, **b} is simplified to a | b."""
        spec = RecipeSpec(recipe=UseDictionaryUnion())
        spec.rewrite_run(
            python(
                """
                all_stops = {**tube_stops, **bus_stops}
                """,
                """
                all_stops = tube_stops | bus_stops
                """,
            )
        )

    def test_three_dict_unpacking(self):
        """Test that {**a, **b, **c} is simplified to a | b | c."""
        spec = RecipeSpec(recipe=UseDictionaryUnion())
        spec.rewrite_run(
            python(
                """
                merged = {**a, **b, **c}
                """,
                """
                merged = a | b | c
                """,
            )
        )

    def test_no_change_mixed_entries(self):
        """Test that dicts with mixed unpacking and regular keys are not changed."""
        spec = RecipeSpec(recipe=UseDictionaryUnion())
        spec.rewrite_run(
            python(
                """
                d = {**a, "key": 1}
                """
            )
        )

    def test_no_change_single_unpacking(self):
        """Test that a single unpacking is not changed."""
        spec = RecipeSpec(recipe=UseDictionaryUnion())
        spec.rewrite_run(
            python(
                """
                d = {**a}
                """
            )
        )

    def test_no_change_regular_dict(self):
        """Test that regular dicts are not changed."""
        spec = RecipeSpec(recipe=UseDictionaryUnion())
        spec.rewrite_run(
            python(
                """
                d = {"a": 1, "b": 2}
                """
            )
        )


class TestRemoveRedundantConstructorInDictUnion:
    """Tests for the RemoveRedundantConstructorInDictUnion recipe."""

    def test_dict_constructor_on_left(self):
        """Test that dict(y) | z is simplified to y | z."""
        spec = RecipeSpec(recipe=RemoveRedundantConstructorInDictUnion())
        spec.rewrite_run(
            python(
                """
                x = dict(y) | z
                """,
                """
                x = y | z
                """,
            )
        )

    def test_dict_constructor_on_right(self):
        """Test that y | dict(z) is simplified to y | z."""
        spec = RecipeSpec(recipe=RemoveRedundantConstructorInDictUnion())
        spec.rewrite_run(
            python(
                """
                x = y | dict(z)
                """,
                """
                x = y | z
                """,
            )
        )

    def test_no_change_without_dict(self):
        """Test that a | b without dict() is not changed."""
        spec = RecipeSpec(recipe=RemoveRedundantConstructorInDictUnion())
        spec.rewrite_run(
            python(
                """
                x = a | b
                """
            )
        )

    def test_no_change_dict_no_args(self):
        """Test that dict() with no args in a union is not changed."""
        spec = RecipeSpec(recipe=RemoveRedundantConstructorInDictUnion())
        spec.rewrite_run(
            python(
                """
                x = dict() | z
                """
            )
        )


class TestRemoveDuplicateDictKey:
    """Tests for the RemoveDuplicateDictKey recipe."""

    def test_duplicate_identifier_keys(self):
        """Test that duplicate identifier keys are deduplicated, keeping last."""
        spec = RecipeSpec(recipe=RemoveDuplicateDictKey())
        spec.rewrite_run(
            python(
                """
                my_dict = {a: 1, b: 2, a: 3}
                """,
                """
                my_dict = {b: 2, a: 3}
                """,
            )
        )

    def test_duplicate_string_keys(self):
        """Test that duplicate string keys are deduplicated."""
        spec = RecipeSpec(recipe=RemoveDuplicateDictKey())
        spec.rewrite_run(
            python(
                """
                d = {"x": 1, "y": 2, "x": 3}
                """,
                """
                d = {"y": 2, "x": 3}
                """,
            )
        )

    def test_duplicate_star_unpacking(self):
        """Test that duplicate star unpacking is deduplicated."""
        spec = RecipeSpec(recipe=RemoveDuplicateDictKey())
        spec.rewrite_run(
            python(
                """
                my_dict = {**d1, **d2, **d1}
                """,
                """
                my_dict = {**d2, **d1}
                """,
            )
        )

    def test_mixed_duplicate_keys_and_stars(self):
        """Test deduplication with both regular keys and star unpacking."""
        spec = RecipeSpec(recipe=RemoveDuplicateDictKey())
        spec.rewrite_run(
            python(
                """
                my_dict = {a: 1, b: 2, a: 3, **d1, **d2, **d1}
                """,
                """
                my_dict = {b: 2, a: 3, **d2, **d1}
                """,
            )
        )

    def test_no_change_unique_keys(self):
        """Test that dicts with unique keys are not changed."""
        spec = RecipeSpec(recipe=RemoveDuplicateDictKey())
        spec.rewrite_run(
            python(
                """
                d = {a: 1, b: 2, c: 3}
                """
            )
        )


class TestRemoveDuplicateSetKey:
    """Tests for the RemoveDuplicateSetKey recipe."""

    def test_duplicate_string_elements(self):
        """Test that duplicate string set elements are deduplicated."""
        spec = RecipeSpec(recipe=RemoveDuplicateSetKey())
        spec.rewrite_run(
            python(
                """
                addresses = {"here", "there", "here"}
                """,
                """
                addresses = {"there", "here"}
                """,
            )
        )

    def test_duplicate_identifier_elements(self):
        """Test that duplicate identifier set elements are deduplicated."""
        spec = RecipeSpec(recipe=RemoveDuplicateSetKey())
        spec.rewrite_run(
            python(
                """
                s = {a, b, c, a}
                """,
                """
                s = {b, c, a}
                """,
            )
        )

    def test_no_change_unique_elements(self):
        """Test that sets with unique elements are not changed."""
        spec = RecipeSpec(recipe=RemoveDuplicateSetKey())
        spec.rewrite_run(
            python(
                """
                s = {"a", "b", "c"}
                """
            )
        )

    def test_multiple_duplicates(self):
        """Test deduplication with multiple repeated elements."""
        spec = RecipeSpec(recipe=RemoveDuplicateSetKey())
        spec.rewrite_run(
            python(
                """
                s = {1, 2, 1, 3, 2}
                """,
                """
                s = {1, 3, 2}
                """,
            )
        )
