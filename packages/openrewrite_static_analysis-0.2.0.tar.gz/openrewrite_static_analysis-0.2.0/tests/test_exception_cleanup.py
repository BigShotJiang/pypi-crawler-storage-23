"""Tests for exception cleanup recipes."""

import pytest
from rewrite.test import RecipeSpec, python
from openrewrite_static_analysis.cleanup.exception_cleanup import (
    DoNotUseBareExcept,
    SimplifySingleExceptionTuple,
    RaiseFromPreviousError,
    UseContextlibSuppress,
)


class TestDoNotUseBareExcept:
    """Tests for the DoNotUseBareExcept recipe."""

    def test_replaces_bare_except(self):
        """Test that bare `except:` is replaced with `except Exception:`."""
        spec = RecipeSpec(recipe=DoNotUseBareExcept())
        spec.rewrite_run(
            python(
                "try:\n    x = 1\nexcept:\n    pass",
                "try:\n    x = 1\nexcept Exception:\n    pass",
            )
        )

    def test_no_change_with_exception_type(self):
        """Test that `except ValueError:` is not modified."""
        spec = RecipeSpec(recipe=DoNotUseBareExcept())
        spec.rewrite_run(
            python(
                "try:\n    x = 1\nexcept ValueError:\n    pass"
            )
        )

    def test_no_change_already_exception(self):
        """Test that `except Exception:` is not modified."""
        spec = RecipeSpec(recipe=DoNotUseBareExcept())
        spec.rewrite_run(
            python(
                "try:\n    x = 1\nexcept Exception:\n    pass"
            )
        )

    def test_bare_except_with_variable(self):
        """Test that bare `except` with `as e` binding is replaced."""
        spec = RecipeSpec(recipe=DoNotUseBareExcept())
        spec.rewrite_run(
            python(
                "try:\n    x = 1\nexcept:\n    print('error')",
                "try:\n    x = 1\nexcept Exception:\n    print('error')",
            )
        )

    def test_multiple_except_clauses(self):
        """Test that only bare except is replaced when multiple clauses exist."""
        spec = RecipeSpec(recipe=DoNotUseBareExcept())
        spec.rewrite_run(
            python(
                "try:\n    x = 1\nexcept ValueError:\n    pass\nexcept:\n    pass",
                "try:\n    x = 1\nexcept ValueError:\n    pass\nexcept Exception:\n    pass",
            )
        )


class TestSimplifySingleExceptionTuple:
    """Tests for the SimplifySingleExceptionTuple recipe."""

    def test_unwraps_single_exception_tuple(self):
        """Test that except (FileNotFoundError,) becomes except FileNotFoundError."""
        spec = RecipeSpec(recipe=SimplifySingleExceptionTuple())
        spec.rewrite_run(
            python(
                "try:\n    read_file()\nexcept (FileNotFoundError,) as e:\n    log_error(e)",
                "try:\n    read_file()\nexcept FileNotFoundError as e:\n    log_error(e)",
            )
        )

    def test_unwraps_single_exception_tuple_without_as(self):
        """Test that except (ValueError,) becomes except ValueError (no as clause)."""
        spec = RecipeSpec(recipe=SimplifySingleExceptionTuple())
        spec.rewrite_run(
            python(
                "try:\n    x = 1\nexcept (ValueError,):\n    pass",
                "try:\n    x = 1\nexcept ValueError:\n    pass",
            )
        )

    def test_no_change_for_multiple_exceptions(self):
        """Test that except (ValueError, TypeError) is not changed."""
        spec = RecipeSpec(recipe=SimplifySingleExceptionTuple())
        spec.rewrite_run(
            python(
                "try:\n    x = 1\nexcept (ValueError, TypeError):\n    pass"
            )
        )

    def test_no_change_for_single_exception(self):
        """Test that except ValueError is not changed (already unwrapped)."""
        spec = RecipeSpec(recipe=SimplifySingleExceptionTuple())
        spec.rewrite_run(
            python(
                "try:\n    x = 1\nexcept ValueError:\n    pass"
            )
        )


class TestRaiseFromPreviousError:
    """Tests for the RaiseFromPreviousError recipe."""

    def test_adds_from_to_raise_with_existing_as(self):
        """Test that raise inside except with as variable gets from added."""
        spec = RecipeSpec(recipe=RaiseFromPreviousError())
        spec.rewrite_run(
            python(
                "try:\n    print(1 / x)\nexcept ZeroDivisionError as e:\n    raise ValueError(\"Can't divide by zero\")",
                "try:\n    print(1 / x)\nexcept ZeroDivisionError as e:\n    raise ValueError(\"Can't divide by zero\") from e",
            )
        )

    def test_adds_as_and_from_when_no_variable(self):
        """Test that except without as gets both as e and from e added."""
        spec = RecipeSpec(recipe=RaiseFromPreviousError())
        spec.rewrite_run(
            python(
                "try:\n    print(1 / x)\nexcept ZeroDivisionError:\n    raise ValueError(\"Can't divide by zero\")",
                "try:\n    print(1 / x)\nexcept ZeroDivisionError as e:\n    raise ValueError(\"Can't divide by zero\") from e",
            )
        )

    def test_no_change_when_already_has_from(self):
        """Test that raise with existing from clause is not modified."""
        spec = RecipeSpec(recipe=RaiseFromPreviousError())
        spec.rewrite_run(
            python(
                "try:\n    x = 1\nexcept ValueError as e:\n    raise RuntimeError('fail') from e"
            )
        )

    def test_no_change_for_bare_raise(self):
        """Test that bare raise (re-raise) is not modified."""
        spec = RecipeSpec(recipe=RaiseFromPreviousError())
        spec.rewrite_run(
            python(
                "try:\n    x = 1\nexcept ValueError as e:\n    raise"
            )
        )


class TestUseContextlibSuppress:
    """Tests for the UseContextlibSuppress recipe."""

    def test_replaces_try_except_pass(self):
        """Test that try/except pass is replaced with contextlib.suppress."""
        spec = RecipeSpec(recipe=UseContextlibSuppress())
        spec.rewrite_run(
            python(
                "try:\n    travel_world(days=80)\nexcept DistractionError:\n    pass",
                "import contextlib\nwith contextlib.suppress(DistractionError):\n    travel_world(days=80)",
            )
        )

    def test_no_change_when_except_has_body(self):
        """Test that try/except with non-pass body is not changed."""
        spec = RecipeSpec(recipe=UseContextlibSuppress())
        spec.rewrite_run(
            python(
                "try:\n    x = 1\nexcept ValueError:\n    print('error')"
            )
        )

    def test_no_change_with_finally(self):
        """Test that try/except/finally is not changed even if except is pass."""
        spec = RecipeSpec(recipe=UseContextlibSuppress())
        spec.rewrite_run(
            python(
                "try:\n    x = 1\nexcept ValueError:\n    pass\nfinally:\n    cleanup()"
            )
        )

    def test_no_change_with_multiple_except(self):
        """Test that try with multiple except clauses is not changed."""
        spec = RecipeSpec(recipe=UseContextlibSuppress())
        spec.rewrite_run(
            python(
                "try:\n    x = 1\nexcept ValueError:\n    pass\nexcept TypeError:\n    pass"
            )
        )

    def test_no_change_with_multi_statement_try_body(self):
        """Test that try with multiple statements in body is not transformed."""
        spec = RecipeSpec(recipe=UseContextlibSuppress())
        spec.rewrite_run(
            python(
                "try:\n    x = 1\n    y = 2\nexcept ValueError:\n    pass"
            )
        )

    def test_no_change_with_else_clause(self):
        """Test that try/except: pass with else clause is NOT transformed."""
        spec = RecipeSpec(recipe=UseContextlibSuppress())
        spec.rewrite_run(
            python(
                "try:\n    x = 1\nexcept ValueError:\n    pass\nelse:\n    y = 2"
            )
        )

    def test_no_change_except_star(self):
        """Test that except* (ExceptionGroup) is NOT transformed to contextlib.suppress."""
        spec = RecipeSpec(recipe=UseContextlibSuppress())
        spec.rewrite_run(
            python(
                "try:\n    some_call()\nexcept* Error:\n    pass"
            )
        )

    def test_no_change_tuple_exception_type(self):
        """except (ValueError, TypeError): pass should not be transformed.

        contextlib.suppress takes *args, not a tuple.  Passing the tuple
        expression verbatim produces contextlib.suppress((ValueError, TypeError))
        which raises TypeError at runtime.
        """
        spec = RecipeSpec(recipe=UseContextlibSuppress())
        spec.rewrite_run(
            python(
                "try:\n    x = 1\nexcept (ValueError, TypeError):\n    pass"
            )
        )

    def test_return_in_try_body(self):
        """return inside try body should be transformed."""
        spec = RecipeSpec(recipe=UseContextlibSuppress())
        spec.rewrite_run(
            python(
                "def f():\n    try:\n        return lookup(key)\n    except KeyError:\n        pass",
                "import contextlib\ndef f():\n    with contextlib.suppress(KeyError):\n        return lookup(key)",
            )
        )

    def test_if_in_try_body(self):
        """if inside try body should be transformed."""
        spec = RecipeSpec(recipe=UseContextlibSuppress())
        spec.rewrite_run(
            python(
                "try:\n    if cond:\n        do_it()\nexcept OSError:\n    pass",
                "import contextlib\nwith contextlib.suppress(OSError):\n    if cond:\n        do_it()",
            )
        )

    def test_while_loop_in_try_body(self):
        """while loop inside try body should be transformed without ClassCastException."""
        spec = RecipeSpec(recipe=UseContextlibSuppress())
        spec.rewrite_run(
            python(
                "try:\n    while True:\n        sock.send(b'x' * 65536)\nexcept BlockingIOError:\n    pass",
                "import contextlib\nwith contextlib.suppress(BlockingIOError):\n    while True:\n        sock.send(b'x' * 65536)",
            )
        )

    def test_no_change_conditional_pass_in_except(self):
        """except body with conditional pass must NOT be transformed.

        Real-world example from tox: `except OSError: if self._interrupted: pass`
        was incorrectly simplified to `contextlib.suppress(OSError)`, removing
        the condition check. The pass is only taken when `self._interrupted` is
        true — the exception is NOT unconditionally suppressed.
        """
        spec = RecipeSpec(recipe=UseContextlibSuppress())
        spec.rewrite_run(
            python(
                "try:\n    os.kill(pid, sig)\nexcept OSError:\n    if self._interrupted:\n        pass"
            )
        )


class TestRaiseFromSelfRaise:
    """Tests for RaiseFromPreviousError not adding 'from e' when re-raising same exception."""

    def test_no_change_when_reraising_same_exception(self):
        """Test that `raise e` in `except X as e:` does NOT get `from e` added."""
        spec = RecipeSpec(recipe=RaiseFromPreviousError())
        spec.rewrite_run(
            python(
                "try:\n    x = 1\nexcept ValueError as e:\n    raise e"
            )
        )

    def test_no_change_bare_raise_in_except(self):
        """Test that bare `raise` in except is not modified (already tested, but verify)."""
        spec = RecipeSpec(recipe=RaiseFromPreviousError())
        spec.rewrite_run(
            python(
                "try:\n    x = 1\nexcept ValueError as e:\n    raise"
            )
        )


class TestDoNotUseBareExceptWithBareRaise:
    """Tests for DoNotUseBareExcept skipping catch-and-reraise patterns."""

    def test_no_change_bare_except_with_bare_raise(self):
        """bare except: with bare raise is a catch-and-reraise pattern.

        Narrowing to except Exception: would silently swallow BaseException
        subclasses (KeyboardInterrupt, SystemExit) that the original code
        correctly re-raises.
        """
        spec = RecipeSpec(recipe=DoNotUseBareExcept())
        spec.rewrite_run(
            python(
                "try:\n    x = 1\nexcept:\n    log()\n    raise"
            )
        )

    def test_no_change_bare_except_with_only_raise(self):
        """except: raise — pure re-raise, must not be narrowed."""
        spec = RecipeSpec(recipe=DoNotUseBareExcept())
        spec.rewrite_run(
            python(
                "try:\n    x = 1\nexcept:\n    raise"
            )
        )

    def test_still_narrows_when_no_bare_raise(self):
        """except: without bare raise should still be narrowed to except Exception:."""
        spec = RecipeSpec(recipe=DoNotUseBareExcept())
        spec.rewrite_run(
            python(
                "try:\n    x = 1\nexcept:\n    log_error()",
                "try:\n    x = 1\nexcept Exception:\n    log_error()",
            )
        )
