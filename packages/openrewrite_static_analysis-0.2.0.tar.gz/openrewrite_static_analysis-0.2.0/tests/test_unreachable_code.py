"""Tests for unreachable code cleanup recipes."""

from rewrite.test import RecipeSpec, python
from openrewrite_static_analysis.cleanup.unreachable_code import (
    RemoveAssertTrue,
    RemoveUnreachableCode,
    RemoveEmptyNestedBlock,
)


class TestRemoveAssertTrue:
    """Tests for the RemoveAssertTrue recipe."""

    def test_removes_assert_true(self):
        """Test that `assert True` is removed from between other statements."""
        spec = RecipeSpec(recipe=RemoveAssertTrue())
        spec.rewrite_run(
            python(
                """
                x = 1
                assert True
                y = 2
                """,
                """
                x = 1
                y = 2
                """,
            )
        )

    def test_no_change_assert_false(self):
        """Test that `assert False` is not removed."""
        spec = RecipeSpec(recipe=RemoveAssertTrue())
        spec.rewrite_run(
            python(
                """
                assert False
                """
            )
        )

    def test_no_change_assert_expression(self):
        """Test that `assert x > 0` is not modified."""
        spec = RecipeSpec(recipe=RemoveAssertTrue())
        spec.rewrite_run(
            python(
                """
                assert x > 0
                """
            )
        )

    def test_removes_assert_true_only(self):
        """Test that only `assert True` is removed, other asserts are kept."""
        spec = RecipeSpec(recipe=RemoveAssertTrue())
        spec.rewrite_run(
            python(
                """
                assert x > 0
                assert True
                assert y < 10
                """,
                """
                assert x > 0
                assert y < 10
                """,
            )
        )

    def test_no_change_assert_with_message(self):
        """Test that `assert True, 'msg'` is not modified (it has a message)."""
        spec = RecipeSpec(recipe=RemoveAssertTrue())
        spec.rewrite_run(
            python(
                """
                assert True, "this should not be removed"
                """
            )
        )

    def test_no_change_assert_variable(self):
        """Test that `assert some_var` is not modified."""
        spec = RecipeSpec(recipe=RemoveAssertTrue())
        spec.rewrite_run(
            python(
                """
                assert some_var
                """
            )
        )


class TestRemoveUnreachableCode:
    """Tests for the RemoveUnreachableCode recipe."""

    def test_removes_statements_after_return(self):
        """Test that statements after return are removed."""
        spec = RecipeSpec(recipe=RemoveUnreachableCode())
        spec.rewrite_run(
            python(
                """
                def foo():
                    x = 1
                    return x
                    y = 2
                    z = 3
                """,
                """
                def foo():
                    x = 1
                    return x
                """,
            )
        )

    def test_removes_statements_after_raise(self):
        """Test that statements after raise are removed."""
        spec = RecipeSpec(recipe=RemoveUnreachableCode())
        spec.rewrite_run(
            python(
                """
                def foo():
                    raise ValueError("bad")
                    x = 1
                """,
                """
                def foo():
                    raise ValueError("bad")
                """,
            )
        )

    def test_removes_statements_after_continue(self):
        """Test that statements after continue in a loop are removed."""
        spec = RecipeSpec(recipe=RemoveUnreachableCode())
        spec.rewrite_run(
            python(
                """
                for a in b:
                    do_a()
                    continue
                    do_x()
                    do_y()
                """,
                """
                for a in b:
                    do_a()
                    continue
                """,
            )
        )

    def test_removes_statements_after_break(self):
        """Test that statements after break in a loop are removed."""
        spec = RecipeSpec(recipe=RemoveUnreachableCode())
        spec.rewrite_run(
            python(
                """
                for i in range(10):
                    if i > 5:
                        break
                        print("unreachable")
                """,
                """
                for i in range(10):
                    if i > 5:
                        break
                """,
            )
        )

    def test_no_change_when_no_unreachable_code(self):
        """Test that code without unreachable statements is unchanged."""
        spec = RecipeSpec(recipe=RemoveUnreachableCode())
        spec.rewrite_run(
            python(
                """
                def foo():
                    x = 1
                    return x
                """
            )
        )

    def test_no_change_return_as_last_statement(self):
        """Test that return as the last statement is not modified."""
        spec = RecipeSpec(recipe=RemoveUnreachableCode())
        spec.rewrite_run(
            python(
                """
                def bar():
                    print("hello")
                    return 42
                """
            )
        )

    def test_no_change_yield_after_raise_in_generator(self):
        """Yield after raise must NOT be removed: it makes the function a generator.

        Removing the yield would change the function from a generator to a
        regular function, altering its return type and call-site semantics.
        """
        spec = RecipeSpec(recipe=RemoveUnreachableCode())
        spec.rewrite_run(
            python(
                """
                def gen():
                    raise StopIteration
                    yield
                """
            )
        )

    def test_no_change_yield_value_after_raise(self):
        """yield with a value after raise must also be preserved."""
        spec = RecipeSpec(recipe=RemoveUnreachableCode())
        spec.rewrite_run(
            python(
                '''
                def read_chunks():
                    raise RuntimeError("init failed")
                    yield b""
                '''
            )
        )

    def test_no_change_yield_from_after_raise(self):
        """yield from after raise should not be removed (changes generator semantics)."""
        spec = RecipeSpec(recipe=RemoveUnreachableCode())
        spec.rewrite_run(python(
            "def f():\n    raise StopIteration\n    yield from count(1)"
        ))

    def test_no_change_yield_in_nested_block_after_terminal(self):
        """yield inside nested if after terminal must be preserved."""
        spec = RecipeSpec(recipe=RemoveUnreachableCode())
        spec.rewrite_run(python(
            "def f():\n    raise StopIteration\n    if True:\n        yield 1"
        ))


class TestRemoveEmptyNestedBlock:
    """Tests for the RemoveEmptyNestedBlock recipe."""

    def test_no_change_for_with_only_pass(self):
        """Test that for loop with only pass is NOT removed (iterable may have side effects)."""
        spec = RecipeSpec(recipe=RemoveEmptyNestedBlock())
        spec.rewrite_run(
            python(
                """
                x = 1
                for i in range(3):
                    pass
                y = 2
                """
            )
        )

    def test_removes_if_with_only_pass(self):
        """Test that if with only pass (and no else) is removed."""
        spec = RecipeSpec(recipe=RemoveEmptyNestedBlock())
        spec.rewrite_run(
            python(
                """
                x = 1
                if condition:
                    pass
                y = 2
                """,
                """
                x = 1
                y = 2
                """,
            )
        )

    def test_no_change_if_with_else(self):
        """Test that if with pass body but an else branch is NOT removed."""
        spec = RecipeSpec(recipe=RemoveEmptyNestedBlock())
        spec.rewrite_run(
            python(
                """
                if x:
                    pass
                else:
                    y = 1
                """
            )
        )

    def test_no_change_for_with_real_body(self):
        """Test that for loop with actual statements is not removed."""
        spec = RecipeSpec(recipe=RemoveEmptyNestedBlock())
        spec.rewrite_run(
            python(
                """
                for i in range(3):
                    print(i)
                """
            )
        )

    def test_no_change_if_with_real_body(self):
        """Test that if with actual statements is not removed."""
        spec = RecipeSpec(recipe=RemoveEmptyNestedBlock())
        spec.rewrite_run(
            python(
                """
                if condition:
                    do_something()
                """
            )
        )

    def test_no_change_for_with_pass_side_effects(self):
        """Test that for loop with only pass is NOT removed (iterable may have side effects)."""
        spec = RecipeSpec(recipe=RemoveEmptyNestedBlock())
        spec.rewrite_run(
            python(
                """
                for _ in progress:
                    pass
                """
            )
        )
