"""Tests for expression simplification cleanup recipes."""

import pytest
from rewrite.test import RecipeSpec, python
from openrewrite_static_analysis.cleanup.expression_simplification import (
    OrIfExpIdentity,
    SwapIfExpression,
    SimplifyDivision,
    RemoveRedundantSliceIndex,
    SimplifyNegativeIndex,
    AugAssign,
)


class TestOrIfExpIdentity:
    """Tests for the OrIfExpIdentity recipe: x if x else y -> x or y."""

    def test_simplifies(self):
        """Test that x if x else y is simplified to x or y."""
        spec = RecipeSpec(recipe=OrIfExpIdentity())
        spec.rewrite_run(
            python(
                "result = x if x else y",
                "result = x or y",
            )
        )

    def test_no_change_different_condition(self):
        """Test that x if z else y is not modified (condition differs from true branch)."""
        spec = RecipeSpec(recipe=OrIfExpIdentity())
        spec.rewrite_run(python("result = x if z else y"))


class TestSwapIfExpression:
    """Tests for the SwapIfExpression recipe: a if not c else b -> b if c else a."""

    def test_swaps_negated_condition(self):
        """Test that a if not c else b is swapped to b if c else a."""
        spec = RecipeSpec(recipe=SwapIfExpression())
        spec.rewrite_run(
            python(
                "result = a if not c else b",
                "result = b if c else a",
            )
        )

    def test_no_change_positive_condition(self):
        """Test that a if c else b is not modified (no negation)."""
        spec = RecipeSpec(recipe=SwapIfExpression())
        spec.rewrite_run(python("result = a if c else b"))


class TestSimplifyDivision:
    """Tests for the SimplifyDivision recipe: int(x / y) -> x // y."""

    def test_no_change_int_div(self):
        """int(x / y) is NOT simplified because int() truncates toward zero
        while // floors toward negative infinity, giving different results for
        negative operands."""
        spec = RecipeSpec(recipe=SimplifyDivision())
        spec.rewrite_run(python("result = int(x / y)"))

    def test_no_change_regular_int(self):
        """Test that int(x) without division is not modified."""
        spec = RecipeSpec(recipe=SimplifyDivision())
        spec.rewrite_run(python("result = int(x)"))


class TestRemoveRedundantSliceIndex:
    """Tests for the RemoveRedundantSliceIndex recipe: numbers[0:len(numbers)] -> numbers[:]."""

    def test_removes_redundant_slice(self):
        """Test that numbers[0:len(numbers)] is simplified to numbers[:]."""
        spec = RecipeSpec(recipe=RemoveRedundantSliceIndex())
        spec.rewrite_run(
            python(
                "result = numbers[0:len(numbers)]",
                "result = numbers[:]",
            )
        )

    def test_no_change_non_zero_start(self):
        """Test that numbers[1:len(numbers)] is not modified (start is not 0)."""
        spec = RecipeSpec(recipe=RemoveRedundantSliceIndex())
        spec.rewrite_run(python("result = numbers[1:len(numbers)]"))

    def test_no_change_different_end(self):
        """Test that numbers[0:5] is not modified (end is not len(same_var))."""
        spec = RecipeSpec(recipe=RemoveRedundantSliceIndex())
        spec.rewrite_run(python("result = numbers[0:5]"))


class TestSimplifyNegativeIndex:
    """Tests for the SimplifyNegativeIndex recipe: a[len(a) - 1] -> a[-1]."""

    def test_simplifies_len_minus_one(self):
        """Test that a[len(a) - 1] is simplified to a[-1]."""
        spec = RecipeSpec(recipe=SimplifyNegativeIndex())
        spec.rewrite_run(
            python(
                "result = a[len(a) - 1]",
                "result = a[-1]",
            )
        )

    def test_no_change_different_variable(self):
        """Test that a[len(b) - 1] is not modified (different variable in len())."""
        spec = RecipeSpec(recipe=SimplifyNegativeIndex())
        spec.rewrite_run(python("result = a[len(b) - 1]"))


class TestAugAssign:
    """Tests for the AugAssign recipe: count = count + other -> count += other."""

    def test_addition_augassign(self):
        """Test that count = count + other is simplified to count += other."""
        spec = RecipeSpec(recipe=AugAssign())
        spec.rewrite_run(
            python(
                "count = count + other_value",
                "count += other_value",
            )
        )

    def test_subtraction_augassign(self):
        """Test that x = x - 1 is simplified to x -= 1."""
        spec = RecipeSpec(recipe=AugAssign())
        spec.rewrite_run(
            python(
                "x = x - 1",
                "x -= 1",
            )
        )

    def test_multiplication_augassign(self):
        """Test that x = x * 2 is simplified to x *= 2."""
        spec = RecipeSpec(recipe=AugAssign())
        spec.rewrite_run(
            python(
                "x = x * 2",
                "x *= 2",
            )
        )

    def test_no_change_different_variable(self):
        """Test that x = y + 1 is not modified (different variable on right side)."""
        spec = RecipeSpec(recipe=AugAssign())
        spec.rewrite_run(python("x = y + 1"))

    def test_no_change_non_binary_rhs(self):
        """Test that x = foo() is not modified (right side is not binary)."""
        spec = RecipeSpec(recipe=AugAssign())
        spec.rewrite_run(python("x = foo()"))

    def test_no_change_list_concat_addition(self):
        """x = x + [item] must NOT become x += [item].

        += on lists mutates in-place, while + creates a new list.
        This changes semantics when other references exist to the same list.
        """
        spec = RecipeSpec(recipe=AugAssign())
        spec.rewrite_run(python("x = x + [item]"))

    def test_no_change_list_literal_addition(self):
        """x = x + [1, 2, 3] must NOT become x += [1, 2, 3]."""
        spec = RecipeSpec(recipe=AugAssign())
        spec.rewrite_run(python("x = x + [1, 2, 3]"))
