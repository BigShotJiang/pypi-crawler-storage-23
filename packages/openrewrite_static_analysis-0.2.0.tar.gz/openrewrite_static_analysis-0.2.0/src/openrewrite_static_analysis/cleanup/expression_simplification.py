"""
Recipes that tighten common Python expression patterns.

- Replace self-referencing ternary with ``or``: ``val if val else fallback`` -> ``val or fallback`` (OrIfExpIdentity)
- Remove negation from ternary conditions by swapping branches (SwapIfExpression)
- Convert ``int(a / b)`` to floor division ``a // b`` (SimplifyDivision) [disabled: see class docstring]
- Drop default slice boundaries: ``data[0:len(data)]`` -> ``data[:]`` (RemoveRedundantSliceIndex)
- Use negative indexing: ``seq[len(seq) - 1]`` -> ``seq[-1]`` (SimplifyNegativeIndex)
- Shorten ``x = x + y`` to ``x += y`` and similar compound assignments (AugAssign)
"""

from typing import Any, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.python.template import pattern, template, capture
from rewrite.java.tree import (
    ArrayAccess,
    Assignment,
    Binary as JBinary,
    Identifier,
    Literal,
    MethodInvocation,
    Ternary,
    Unary,
)
from rewrite.python import ExpressionStatement
from rewrite.python.tree import CollectionLiteral, Slice
from rewrite.java import Space
from openrewrite_static_analysis.cleanup import trees_equal

_Cleanup = [*Python, CategoryDescriptor(display_name="Cleanup")]



# Template for x if x else y -> x or y
_or_x = capture('x')
_or_y = capture('y')
_or_if_template = template("{x} or {y}", x=_or_x, y=_or_y)

# Template for a if not c else b -> b if c else a
_swap_a = capture('a')
_swap_b = capture('b')
_swap_c = capture('c')
_swap_template = template("{b} if {c} else {a}", a=_swap_a, b=_swap_b, c=_swap_c)

# Pattern/template for int(x / y) -> x // y
_div_x = capture('x')
_div_y = capture('y')
_int_div_pattern = pattern("int({x} / {y})", x=_div_x, y=_div_y)
_int_div_template = template("{x} // {y}", x=_div_x, y=_div_y)

# Templates for AugAssign output (keyed by J.Binary operator)
_aug_x = capture('ax')
_aug_y = capture('ay')
_AUG_TEMPLATES = {
    JBinary.Type.Addition: template("{ax} += {ay}", ax=_aug_x, ay=_aug_y),
    JBinary.Type.Subtraction: template("{ax} -= {ay}", ax=_aug_x, ay=_aug_y),
    JBinary.Type.Multiplication: template("{ax} *= {ay}", ax=_aug_x, ay=_aug_y),
    JBinary.Type.Division: template("{ax} /= {ay}", ax=_aug_x, ay=_aug_y),
    JBinary.Type.Modulo: template("{ax} %= {ay}", ax=_aug_x, ay=_aug_y),
}


@categorize(_Cleanup)
class OrIfExpIdentity(Recipe):
    """
    Replace a self-referencing ternary with the ``or`` operator.

    When a ternary's condition and its true-branch are the same variable,
    the expression degenerates into a simple ``or`` with the false-branch,
    which avoids naming the variable twice.

    Example:
        Before:
            value = setting if setting else default

        After:
            value = setting or default
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.OrIfExpIdentity"

    @property
    def display_name(self) -> str:
        return "Replace self-referencing ternary with `or`"

    @property
    def description(self) -> str:
        return (
            "When a ternary's condition and true-branch name the same variable, "
            "rewrite ``val if val else fallback`` as ``val or fallback`` to "
            "avoid repeating the name."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_ternary(
                self, ternary: Ternary, p: ExecutionContext
            ) -> Optional[Ternary]:
                ternary = super().visit_ternary(ternary, p)
                # In Python's `x if x else y`, the Ternary AST has:
                #   condition = x (the part after 'if')
                #   true_part = x (the part before 'if')
                #   false_part = y (the part after 'else')
                cond = ternary.condition
                true_part = ternary.true_part
                if (isinstance(cond, Identifier) and isinstance(true_part, Identifier)
                        and cond.simple_name == true_part.simple_name):
                    values = {'x': true_part, 'y': ternary.false_part}
                    return _or_if_template.apply(self.cursor, values=values)
                return ternary

        return Visitor()


@categorize(_Cleanup)
class SwapIfExpression(Recipe):
    """
    Remove negation from ternary conditions by swapping branches.

    A conditional expression with a ``not`` in its test can be turned into
    an equivalent expression without the negation by exchanging the
    true and false branches, resulting in more direct logic.

    Example:
        Before:
            color = red if not is_ok else green

        After:
            color = green if is_ok else red
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.SwapIfExpression"

    @property
    def display_name(self) -> str:
        return "Swap ternary branches to drop negated condition"

    @property
    def description(self) -> str:
        return (
            "Flip the branches of a conditional expression whose test uses "
            "``not``, eliminating the negation for clearer intent."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_ternary(
                self, ternary: Ternary, p: ExecutionContext
            ) -> Optional[Ternary]:
                ternary = super().visit_ternary(ternary, p)
                # In Python's `a if not c else b`, the Ternary AST has:
                #   condition = Unary(Not, c)
                #   true_part = a
                #   false_part = b
                cond = ternary.condition
                if isinstance(cond, Unary) and cond.operator == Unary.Type.Not:
                    values = {
                        'a': ternary.true_part,
                        'b': ternary.false_part,
                        'c': cond.expression,
                    }
                    return _swap_template.apply(self.cursor, values=values)
                return ternary

        return Visitor()


@categorize(_Cleanup)
class SimplifyDivision(Recipe):
    """
    Convert ``int(a / b)`` to floor division ``a // b``.

    NOTE: This recipe is intentionally a no-op.  ``int(a / b)`` truncates
    toward zero, whereas ``a // b`` floors toward negative infinity.
    With negative operands the two forms give different answers (e.g.
    ``int(-7 / 2) == -3`` but ``-7 // 2 == -4``), so the rewrite is
    not safe in the general case and is therefore disabled.

    Example:
        Before:
            result = int(total / parts)

        After:
            result = total // parts
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.SimplifyDivision"

    @property
    def display_name(self) -> str:
        return "Convert `int(a / b)` to floor division"

    @property
    def description(self) -> str:
        return (
            "Replace ``int(a / b)`` with Python's floor-division operator "
            "``a // b`` for a more concise expression."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                return super().visit_method_invocation(method, p)

        return Visitor()


@categorize(_Cleanup)
class RemoveRedundantSliceIndex(Recipe):
    """
    Drop default-value slice bounds that duplicate Python's defaults.

    A slice starting at ``0`` and stopping at ``len(seq)`` simply copies
    the whole sequence, which ``seq[:]`` already expresses.  Removing the
    explicit bounds reduces noise.

    Example:
        Before:
            result = data[0:len(data)]

        After:
            result = data[:]
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.RemoveRedundantSliceIndex"

    @property
    def display_name(self) -> str:
        return "Drop default-value slice boundaries"

    @property
    def description(self) -> str:
        return (
            "Omit slice start/stop when they equal ``0`` and ``len(seq)`` "
            "respectively, e.g. ``data[0:len(data)]`` becomes ``data[:]``."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        _seq = capture('seq')
        _empty_slice_template = template('{seq}[:]', seq=_seq)

        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_array_access(
                self, array_access: ArrayAccess, p: ExecutionContext
            ) -> Optional[ArrayAccess]:
                array_access = super().visit_array_access(array_access, p)
                idx = array_access.dimension.index
                if not isinstance(idx, Slice):
                    return array_access
                # start must be literal 0
                if not isinstance(idx.start, Literal):
                    return array_access
                if idx.start.value != 0:
                    return array_access
                # stop must be len(same_var)
                stop = idx.stop
                if not isinstance(stop, MethodInvocation):
                    return array_access
                if not isinstance(stop.name, Identifier):
                    return array_access
                if stop.name.simple_name != "len":
                    return array_access
                if stop.select is not None:
                    return array_access
                args = list(stop.arguments)
                if len(args) != 1:
                    return array_access
                if not trees_equal(args[0], array_access.indexed, self.cursor):
                    return array_access
                # Replace with seq[:] via template
                result = _empty_slice_template.apply(
                    self.cursor, values={"seq": array_access.indexed}
                )
                if isinstance(result, ExpressionStatement):
                    result = result.expression
                return result.replace(prefix=array_access.prefix)

        return Visitor()


@categorize(_Cleanup)
class SimplifyNegativeIndex(Recipe):
    """
    Use negative indexing instead of ``len()``-based offset from the end.

    Python supports negative indices natively, so ``seq[len(seq) - k]``
    can always be written as ``seq[-k]``, which is shorter and avoids
    an unnecessary function call.

    Example:
        Before:
            result = rows[len(rows) - 1]

        After:
            result = rows[-1]
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.SimplifyNegativeIndex"

    @property
    def display_name(self) -> str:
        return "Use negative index instead of `len()` offset"

    @property
    def description(self) -> str:
        return (
            "Rewrite ``seq[len(seq) - k]`` as ``seq[-k]``, using Python's "
            "native negative-indexing support."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        _k = capture('k')
        _neg_template = template("-{k}", k=_k)

        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_array_access(
                self, array_access: ArrayAccess, p: ExecutionContext
            ) -> Optional[ArrayAccess]:
                array_access = super().visit_array_access(array_access, p)
                idx = array_access.dimension.index
                # Match: len(var) - k
                if not isinstance(idx, JBinary):
                    return array_access
                if idx.operator != JBinary.Type.Subtraction:
                    return array_access
                call = idx.left
                if not isinstance(call, MethodInvocation):
                    return array_access
                if not isinstance(call.name, Identifier):
                    return array_access
                if call.name.simple_name != "len":
                    return array_access
                if call.select is not None:
                    return array_access
                # len() must have exactly one arg matching the indexed expr
                args = list(call.arguments)
                if len(args) != 1:
                    return array_access
                if not trees_equal(args[0], array_access.indexed, self.cursor):
                    return array_access
                # Build -k using template
                k = idx.right
                neg_expr = _neg_template.apply(self.cursor, values={"k": k})
                if isinstance(neg_expr, ExpressionStatement):
                    neg_expr = neg_expr.expression
                neg_expr = neg_expr.replace(prefix=idx.prefix)
                # Replace the index inside the JRightPadded wrapper
                dim = array_access.dimension
                new_idx_padded = dim._index.replace(element=neg_expr)
                new_dim = dim.padding.replace(index=new_idx_padded)
                return array_access.replace(dimension=new_dim)

        return Visitor()


@categorize(_Cleanup)
class AugAssign(Recipe):
    """
    Shorten ``x = x op y`` to the compound assignment form ``x op= y``.

    If an assignment's right-hand side is an arithmetic expression where
    the first operand is the same as the target, a compound assignment
    operator (``+=``, ``-=``, ``*=``, ``/=``, ``%=``) expresses the
    same update more concisely.

    Example:
        Before:
            total = total + amount

        After:
            total += amount
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.AugAssign"

    @property
    def display_name(self) -> str:
        return "Shorten assignment to compound operator form"

    @property
    def description(self) -> str:
        return (
            "Convert ``target = target op value`` into ``target op= value`` "
            "for arithmetic operators (+, -, *, /, %)."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_assignment(
                self, assignment: Assignment, p: ExecutionContext
            ) -> Optional[Assignment]:
                assignment = super().visit_assignment(assignment, p)
                # Check if right side is a J.Binary
                rhs = assignment.assignment
                if not isinstance(rhs, JBinary):
                    return assignment
                # Check if the binary operator is one we can convert
                tmpl = _AUG_TEMPLATES.get(rhs.operator)
                if tmpl is None:
                    return assignment
                # Skip list/set concatenation: x = x + [y] creates a new
                # list, but x += [y] mutates in-place, changing semantics
                # when other references to the same list exist.
                if rhs.operator == JBinary.Type.Addition and isinstance(rhs.right, CollectionLiteral):
                    return assignment
                # Check if the binary's left operand matches the assignment target
                if not trees_equal(assignment.variable, rhs.left, self.cursor):
                    return assignment
                values = {
                    'ax': assignment.variable,
                    'ay': rhs.right,
                }
                return tmpl.apply(self.cursor, values=values)

        return Visitor()
