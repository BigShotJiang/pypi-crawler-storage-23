"""
Recipes that simplify and tighten conditional logic.

- Eliminate pointless ternary where true/false paths yield the same value (RemoveRedundantCondition)
- Consolidate repeated `isinstance` calls linked by `or` into one tuple check (MergeIsinstance)
- Flatten an inner `if` into its parent using `and` when neither has an else (MergeNestedIfs)
- Convert `else` containing a lone `if` into `elif` (MergeElseIfIntoElif)
- Flip an empty if-body (`pass`) by inverting the condition and dropping the else (SwapIfElseBranches)
- Invert the condition to remove a `pass`-only if-body that precedes an else (RemovePassBody)
- Invert an elif whose body is `pass` when followed by an else clause (RemovePassElif)
- Collapse a redundant `elif not <same_cond>` into a plain `else` (RemoveRedundantIf)
- Strip an unnecessary `else` when the if-body always exits early (RemoveUnnecessaryElse)
- Condense matching if/else assignments into a single ternary expression (AssignIfExp)
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers
from rewrite.utils import random_id
from rewrite.python.visitor import PythonVisitor
from rewrite.python.template import template, capture
from rewrite.python.format import auto_format
from rewrite.python import ExpressionStatement
from rewrite.python import tree as py_tree
from rewrite.python.tree import Binary as PyBinary, CollectionLiteral
from openrewrite_static_analysis.cleanup import trees_equal
from rewrite.java.tree import (
    Assignment,
    Binary as JBinary,
    Block,
    Identifier,
    If as JIf,
    JRightPadded,
    Lambda,
    MethodInvocation,
    Return,
    Space,
    Ternary as JTernary,
    Throw,
    Unary,
)

# Define category path: Python > Cleanup
_Cleanup = [*Python, CategoryDescriptor(display_name="Cleanup")]

# Template for y if z else y -> y
_y = capture('y')
_redundant_template = template("{y}", y=_y)

# Template for isinstance(x, A) or isinstance(x, B) -> isinstance(x, (A, B))
_x = capture('x')
_a = capture('a')
_b = capture('b')
_isinstance_merged_template = template("isinstance({x}, ({a}, {b}))", x=_x, a=_a, b=_b)



@categorize(_Cleanup)
class RemoveRedundantCondition(Recipe):
    """
    Remove redundant ternary expressions where both branches are identical.

    When both branches of a ternary expression return the same value, the
    condition is irrelevant and the expression simplifies to just the value.

    Example:
        Before:
            result = y if z else y

        After:
            result = y
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.RemoveRedundantCondition"

    @property
    def display_name(self) -> str:
        return "Remove redundant ternary condition"

    @property
    def description(self) -> str:
        return (
            "When both branches of a ternary expression are identical, "
            "simplify `y if z else y` to `y`."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_ternary(
                self, ternary: JTernary, p: ExecutionContext
            ) -> Optional[JTernary]:
                ternary = super().visit_ternary(ternary, p)
                if not trees_equal(ternary.true_part, ternary.false_part, self.cursor):
                    return ternary
                return _redundant_template.apply(
                    self.cursor, values={"y": ternary.true_part}
                )

        return Visitor()


def _is_pass_only(block) -> bool:
    """Check if a block contains only a single `pass` statement."""
    if not isinstance(block, Block):
        return False
    stmts = block.statements
    return len(stmts) == 1 and isinstance(stmts[0], py_tree.Pass)


def _negate_condition(cond, cursor):
    """Negate a condition expression. Removes double negation and flips is/is not."""
    if isinstance(cond, Unary) and cond.operator == Unary.Type.Not:
        # Double negation: not(not x) -> x
        inner = cond.expression
        return inner.replace(prefix=cond.prefix)
    # Flip is/is not operators directly
    if isinstance(cond, PyBinary) and cond.operator == PyBinary.Type.IsNot:
        return cond.replace(
            _operator=cond._operator.replace(element=PyBinary.Type.Is),
            prefix=cond.prefix,
        )
    if isinstance(cond, PyBinary) and cond.operator == PyBinary.Type.Is:
        return cond.replace(
            _operator=cond._operator.replace(element=PyBinary.Type.IsNot),
            prefix=cond.prefix,
        )
    # Apply not
    _c = capture('c')
    _not_tmpl = template("not {c}", c=_c)
    new_cond = _not_tmpl.apply(cursor, values={"c": cond})
    if isinstance(new_cond, ExpressionStatement):
        new_cond = new_cond.expression
    return new_cond.replace(prefix=cond.prefix)


def _set_condition(if_stmt: JIf, new_cond) -> JIf:
    """Replace the condition expression inside an If's ControlParentheses."""
    new_ctrl = if_stmt.if_condition.padding.replace(
        tree=if_stmt.if_condition._tree.replace(element=new_cond)
    )
    return if_stmt.replace(if_condition=new_ctrl)


def _if_body_always_exits(if_stmt: JIf) -> bool:
    """Check if the if-body always exits (ends with return, raise, continue, or break)."""
    then_part = if_stmt.then_part
    if not isinstance(then_part, Block):
        return False
    stmts = then_part.statements
    if not stmts:
        return False
    last_stmt = stmts[-1]
    from rewrite.java.tree import Continue, Break
    return isinstance(last_stmt, (Return, Throw, Continue, Break))


@categorize(_Cleanup)
class MergeIsinstance(Recipe):
    """
    Merge multiple `isinstance()` calls joined by `or` into a single call with a tuple.

    When two `isinstance()` calls check the same variable against different types
    and are combined with `or`, they can be merged into a single call.

    Example:
        Before:
            if isinstance(x, int) or isinstance(x, str):
                pass

        After:
            if isinstance(x, (int, str)):
                pass
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.MergeIsinstance"

    @property
    def display_name(self) -> str:
        return "Merge `isinstance()` calls"

    @property
    def description(self) -> str:
        return (
            "Merge `isinstance(x, A) or isinstance(x, B)` into "
            "`isinstance(x, (A, B))` for cleaner type checking."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_binary(
                self, binary: JBinary, p: ExecutionContext
            ) -> Optional[JBinary]:
                binary = super().visit_binary(binary, p)

                # Must be an 'or' binary expression
                if binary.operator != JBinary.Type.Or:
                    return binary

                left = binary.left
                right = binary.right

                # Both sides must be isinstance() calls
                if not isinstance(left, MethodInvocation) or not isinstance(right, MethodInvocation):
                    return binary
                if not isinstance(left.name, Identifier) or left.name.simple_name != "isinstance":
                    return binary
                if not isinstance(right.name, Identifier) or right.name.simple_name != "isinstance":
                    return binary

                # Both must have exactly 2 arguments
                if len(left.arguments) != 2 or len(right.arguments) != 2:
                    return binary

                # Guard: don't merge if either type arg is already a tuple
                if isinstance(left.arguments[1], CollectionLiteral) or isinstance(right.arguments[1], CollectionLiteral):
                    return binary

                # First arguments must be the same variable
                if not trees_equal(left.arguments[0], right.arguments[0], self.cursor):
                    return binary

                return _isinstance_merged_template.apply(
                    self.cursor,
                    values={
                        "x": left.arguments[0],
                        "a": left.arguments[1],
                        "b": right.arguments[1],
                    },
                )

        return Visitor()


@categorize(_Cleanup)
class MergeNestedIfs(Recipe):
    """
    Flatten consecutive nested ``if`` blocks into a single condition joined by ``and``.

    When the only statement inside an ``if`` body is another ``if`` and neither
    branch carries an ``else``, the two guards can be collapsed into one check.
    This reduces indentation depth and makes the combined requirement explicit.

    Example:
        Before:
            if is_valid:
                if is_active:
                    process(record)

        After:
            if is_valid and is_active:
                process(record)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.MergeNestedIfs"

    @property
    def display_name(self) -> str:
        return "Collapse nested ``if`` into a single ``and`` condition"

    @property
    def description(self) -> str:
        return (
            "When two ``if`` statements are nested with no ``else`` on either, "
            "join their conditions with ``and`` and flatten the body."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        _cond_a = capture('a')
        _cond_b = capture('b')
        _and_tmpl = template("{a} and {b}", a=_cond_a, b=_cond_b)

        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_if(
                self, if_stmt: JIf, p: ExecutionContext
            ) -> Optional[JIf]:
                if_stmt = super().visit_if(if_stmt, p)

                # Outer if must have no else
                if if_stmt.else_part is not None:
                    return if_stmt

                # Body must be a block with exactly one statement
                if not isinstance(if_stmt.then_part, Block):
                    return if_stmt
                blk = if_stmt.then_part
                if len(blk.statements) != 1:
                    return if_stmt

                # That statement must be an if with no else
                inner = blk.statements[0]
                if not isinstance(inner, JIf) or inner.else_part is not None:
                    return if_stmt

                outer_cond = if_stmt.if_condition.tree
                inner_cond = inner.if_condition.tree

                # Create combined "a and b" condition
                new_cond = _and_tmpl.apply(
                    self.cursor,
                    values={"a": outer_cond, "b": inner_cond},
                )
                if isinstance(new_cond, ExpressionStatement):
                    new_cond = new_cond.expression
                new_cond = new_cond.replace(prefix=Space.SINGLE_SPACE)

                # Update the condition
                result = _set_condition(if_stmt, new_cond)

                # Use inner's then_part directly; auto_format fixes indentation
                result = result.padding.replace(
                    then_part=result._then_part.replace(element=inner.then_part)
                )
                return auto_format(result, p, cursor=self.cursor.parent)

        return Visitor()


@categorize(_Cleanup)
class MergeElseIfIntoElif(Recipe):
    """
    Replace an ``else`` block that wraps a single ``if`` with an ``elif``.

    An ``else`` clause whose sole content is another ``if`` introduces an
    unnecessary nesting level. Rewriting it as ``elif`` keeps the same
    semantics while reducing indentation.

    Example:
        Before:
            if status == "ok":
                handle_success()
            else:
                if status == "retry":
                    retry_request()
                else:
                    abort()

        After:
            if status == "ok":
                handle_success()
            elif status == "retry":
                retry_request()
            else:
                abort()
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.MergeElseIfIntoElif"

    @property
    def display_name(self) -> str:
        return "Convert ``else: if`` to ``elif``"

    @property
    def description(self) -> str:
        return (
            "When an ``else`` clause contains nothing but an ``if``, "
            "rewrite it as ``elif`` to eliminate extra nesting."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_if(
                self, if_stmt: JIf, p: ExecutionContext
            ) -> Optional[JIf]:
                if_stmt = super().visit_if(if_stmt, p)

                if if_stmt.else_part is None:
                    return if_stmt

                else_body = if_stmt.else_part.body

                # The else body must be a Block containing exactly one If
                if not isinstance(else_body, Block):
                    return if_stmt
                stmts = else_body.statements
                if len(stmts) != 1 or not isinstance(stmts[0], JIf):
                    return if_stmt

                inner_if = stmts[0]

                # Promote: set inner_if as the else_part body directly
                # with empty prefix (which makes it print as elif instead of else: if)
                inner_if = inner_if.replace(prefix=Space.EMPTY)

                new_else_part = if_stmt.else_part.with_body(inner_if)
                result = if_stmt.replace(else_part=new_else_part)
                return auto_format(result, p, cursor=self.cursor.parent)

        return Visitor()


@categorize(_Cleanup)
class SwapIfElseBranches(Recipe):
    """
    Invert an ``if``/``else`` whose true branch is empty.

    If the ``if`` body consists only of ``pass`` while the ``else`` holds
    meaningful logic, the condition can be negated so the real work moves
    into the primary branch and the ``else`` is dropped entirely.

    Example:
        Before:
            if is_weekend:
                pass
            else:
                send_report()

        After:
            if not is_weekend:
                send_report()
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.SwapIfElseBranches"

    @property
    def display_name(self) -> str:
        return "Flip empty ``if``-body by negating the condition"

    @property
    def description(self) -> str:
        return (
            "When the ``if`` branch is just ``pass`` and an ``else`` exists, "
            "invert the test and promote the else body to the if body."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_if(
                self, if_stmt: JIf, p: ExecutionContext
            ) -> Optional[JIf]:
                if_stmt = super().visit_if(if_stmt, p)

                # Must have else
                if if_stmt.else_part is None:
                    return if_stmt

                # If body must be only pass
                if not _is_pass_only(if_stmt.then_part):
                    return if_stmt

                # Negate condition
                cond = if_stmt.if_condition.tree
                new_cond = _negate_condition(cond, self.cursor)

                result = _set_condition(if_stmt, new_cond)

                # Use else body as new then_part
                else_body = if_stmt.else_part.body

                # When else body is an elif (If with empty prefix),
                # wrap it in a Block so it becomes a nested if.
                if isinstance(else_body, JIf):
                    rp = JRightPadded(else_body, Space.EMPTY, Markers.EMPTY)
                    static_rp = JRightPadded(False, Space.EMPTY, Markers.EMPTY)
                    else_body = Block(random_id(), Space.EMPTY, Markers.EMPTY,
                                     static_rp, [rp], Space.EMPTY)

                result = result.padding.replace(
                    then_part=result._then_part.replace(element=else_body)
                )
                # Remove else
                result = result.replace(else_part=None)
                return auto_format(result, p, cursor=self.cursor.parent)

        return Visitor()


@categorize(_Cleanup)
class RemovePassBody(Recipe):
    """
    Eliminate a ``pass``-only ``if`` body by inverting the condition.

    This recipe targets conditionals where the primary branch does nothing
    and the ``else`` branch contains the actual logic. Flipping the guard
    removes the no-op ``pass`` and makes the intent clearer.

    Example:
        Before:
            if not ready:
                pass
            else:
                return result

        After:
            if ready:
                return result
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.RemovePassBody"

    @property
    def display_name(self) -> str:
        return "Drop ``pass``-only ``if`` body by inverting the guard"

    @property
    def description(self) -> str:
        return (
            "When an ``if`` body contains only ``pass`` and is followed by "
            "an ``else``, flip the condition and use the else body directly."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        return SwapIfElseBranches().editor()


@categorize(_Cleanup)
class RemovePassElif(Recipe):
    """
    Eliminate a ``pass``-only ``elif`` branch by inverting its condition.

    When an ``elif`` does nothing (body is just ``pass``) and an ``else``
    follows, the ``elif`` condition can be negated so the ``else`` body
    replaces the empty branch directly.

    Example:
        Before:
            if enabled:
                run()
            elif locked:
                pass
            else:
                return fallback

        After:
            if enabled:
                run()
            elif not locked:
                return fallback
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.RemovePassElif"

    @property
    def display_name(self) -> str:
        return "Drop ``pass``-only ``elif`` by negating its condition"

    @property
    def description(self) -> str:
        return (
            "When an ``elif`` body is only ``pass`` and an ``else`` follows, "
            "invert the ``elif`` condition and absorb the else body."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_if(
                self, if_stmt: JIf, p: ExecutionContext
            ) -> Optional[JIf]:
                if_stmt = super().visit_if(if_stmt, p)

                # Look for elif chains: else_part.body is an If (elif)
                if if_stmt.else_part is None:
                    return if_stmt

                elif_if = if_stmt.else_part.body
                if not isinstance(elif_if, JIf):
                    return if_stmt

                # The elif must have pass body and an else
                if not _is_pass_only(elif_if.then_part):
                    return if_stmt
                if elif_if.else_part is None:
                    return if_stmt

                # Skip when the else body is another elif (If node).
                # Transforming would nest the elif chain, producing worse code.
                if isinstance(elif_if.else_part.body, JIf):
                    return if_stmt

                # Negate the elif condition
                elif_cond = elif_if.if_condition.tree
                new_cond = _negate_condition(elif_cond, self.cursor)
                new_elif = _set_condition(elif_if, new_cond)

                # Use else body as new elif body
                else_body = elif_if.else_part.body
                new_elif = new_elif.padding.replace(
                    then_part=new_elif._then_part.replace(element=else_body)
                )
                # Remove elif's else
                new_elif = new_elif.replace(else_part=None)

                # Put the updated elif back as the else_part body
                new_else_part = if_stmt.else_part.with_body(new_elif)
                return if_stmt.replace(else_part=new_else_part)

        return Visitor()


@categorize(_Cleanup)
class RemoveRedundantIf(Recipe):
    """
    Simplify an ``elif`` that tests the inverse of the ``if`` condition into ``else``.

    If the ``elif`` guard is simply ``not <if_condition>``, the test is
    always the complement of the original ``if`` and can be replaced with a
    plain ``else``.

    Example:
        Before:
            if path.endswith(".csv"):
                load_csv(path)
            elif not path.endswith(".csv"):
                load_json(path)

        After:
            if path.endswith(".csv"):
                load_csv(path)
            else:
                load_json(path)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.RemoveRedundantIf"

    @property
    def display_name(self) -> str:
        return "Simplify negated ``elif`` to ``else``"

    @property
    def description(self) -> str:
        return (
            "When an ``elif`` condition is the exact negation of the preceding "
            "``if``, replace it with ``else`` since the test is redundant."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_if(
                self, if_stmt: JIf, p: ExecutionContext
            ) -> Optional[JIf]:
                if_stmt = super().visit_if(if_stmt, p)

                if if_stmt.else_part is None:
                    return if_stmt

                # else_part.body must be an If (elif)
                elif_if = if_stmt.else_part.body
                if not isinstance(elif_if, JIf):
                    return if_stmt

                # Check if elif condition is the negation of if condition
                elif_cond = elif_if.if_condition.tree

                # The elif condition must be `not <if_cond>`
                if not isinstance(elif_cond, Unary) or elif_cond.operator != Unary.Type.Not:
                    return if_stmt

                if not trees_equal(elif_cond.expression, if_stmt.if_condition.tree, self.cursor):
                    return if_stmt

                # Replace elif with else: take elif's then_part as else body
                new_else = JIf.Else(
                    _id=if_stmt.else_part.id,
                    _prefix=if_stmt.else_part.prefix,
                    _markers=if_stmt.else_part.markers,
                    _body=elif_if._then_part,
                )
                # Preserve elif's else if any
                if elif_if.else_part is not None:
                    # This is a more complex case; skip for now
                    return if_stmt

                return if_stmt.replace(else_part=new_else)

        return Visitor()


@categorize(_Cleanup)
class RemoveUnnecessaryElse(Recipe):
    """
    Drop a superfluous ``else`` following an early-exit ``if`` branch.

    When the ``if`` body is guaranteed to leave the current scope (via
    ``return``, ``raise``, ``continue``, or ``break``), the ``else``
    wrapper is unnecessary. The else body can be moved to the same
    indentation level as the ``if``.

    Example:
        Before:
            if count <= 0:
                raise ValueError("empty")
            else:
                total = sum(items)
                return total

        After:
            if count <= 0:
                raise ValueError("empty")
            total = sum(items)
            return total
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.RemoveUnnecessaryElse"

    @property
    def display_name(self) -> str:
        return "Drop ``else`` after early-exit ``if`` branch"

    @property
    def description(self) -> str:
        return (
            "When the ``if`` body always exits via return, raise, continue, "
            "or break, remove the ``else`` and dedent its contents."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def _process_statements(
                self, padded_stmts: List[JRightPadded]
            ) -> List[JRightPadded]:
                """Process a list of padded statements, expanding ifs with unnecessary else."""
                new_padded = []
                changed = False
                for rp in padded_stmts:
                    stmt = rp.element
                    if not isinstance(stmt, JIf):
                        new_padded.append(rp)
                        continue
                    if stmt.else_part is None:
                        new_padded.append(rp)
                        continue
                    if not _if_body_always_exits(stmt):
                        new_padded.append(rp)
                        continue
                    else_body = stmt.else_part.body
                    if not isinstance(else_body, Block):
                        new_padded.append(rp)
                        continue

                    # Remove else from the if
                    new_if = stmt.replace(else_part=None)
                    new_padded.append(rp.replace(element=new_if))

                    # Splice else body statements after the if (auto_format fixes indentation).
                    # Strip comments from the first statement's prefix — they
                    # belonged to the `else:` line which is being removed.
                    extra_stmts = list(else_body.padding.statements)
                    if extra_stmts and extra_stmts[0].element.prefix.comments:
                        first = extra_stmts[0].element
                        last_comment = first.prefix.comments[-1]
                        clean_prefix = Space([], last_comment.suffix)
                        extra_stmts[0] = extra_stmts[0].replace(
                            element=first.replace(prefix=clean_prefix)
                        )
                    new_padded.extend(extra_stmts)
                    changed = True

                return new_padded if changed else padded_stmts

            def visit_compilation_unit(self, cu, p):
                cu = super().visit_compilation_unit(cu, p)
                new_stmts = self._process_statements(cu.padding.statements)
                if new_stmts is not cu.padding.statements:
                    cu = cu.padding.replace(statements=new_stmts)
                    cu = auto_format(cu, p, cursor=self.cursor.parent)
                return cu

            def visit_block(
                self, block: Block, p: ExecutionContext
            ) -> Optional[Block]:
                block = super().visit_block(block, p)
                new_stmts = self._process_statements(block.padding.statements)
                if new_stmts is not block.padding.statements:
                    block = block.padding.replace(statements=new_stmts)
                    block = auto_format(block, p, cursor=self.cursor.parent)
                return block

        return Visitor()


@categorize(_Cleanup)
class AssignIfExp(Recipe):
    """
    Condense an ``if``/``else`` that assigns to the same variable into a ternary.

    When both the ``if`` and ``else`` blocks each contain a single assignment
    to the same target, the two statements can be expressed more concisely as
    an inline conditional expression.

    Example:
        Before:
            if threshold_met:
                label = "high"
            else:
                label = "low"

        After:
            label = "high" if threshold_met else "low"
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.AssignIfExp"

    @property
    def display_name(self) -> str:
        return "Use inline conditional for simple ``if``/``else`` assignment"

    @property
    def description(self) -> str:
        return (
            "When an ``if``/``else`` pair each assign a single value to the "
            "same variable, rewrite as a ternary expression."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        _val = capture('val')
        _cond = capture('cond')
        _other = capture('other')
        _ternary_tmpl = template(
            "{val} if {cond} else {other}",
            val=_val, cond=_cond, other=_other,
        )

        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_if(
                self, if_stmt: JIf, p: ExecutionContext
            ) -> Optional[JIf]:
                if_stmt = super().visit_if(if_stmt, p)

                # Must have else
                if if_stmt.else_part is None:
                    return if_stmt

                # Both branches must be blocks with exactly one assignment
                then_part = if_stmt.then_part
                else_body = if_stmt.else_part.body
                if not isinstance(then_part, Block) or not isinstance(else_body, Block):
                    return if_stmt
                if len(then_part.statements) != 1 or len(else_body.statements) != 1:
                    return if_stmt

                then_stmt = then_part.statements[0]
                else_stmt = else_body.statements[0]

                if not isinstance(then_stmt, Assignment) or not isinstance(else_stmt, Assignment):
                    return if_stmt

                # Same variable
                if not trees_equal(then_stmt.variable, else_stmt.variable, self.cursor):
                    return if_stmt

                # Skip tuple unpacking — `a, b = X if cond else Y, Z`
                # has ambiguous comma parsing
                if isinstance(then_stmt.variable, CollectionLiteral):
                    return if_stmt

                # Skip if either value is already a ternary — avoids
                # producing chained ternaries with wrong precedence
                if isinstance(then_stmt.assignment, JTernary) or isinstance(else_stmt.assignment, JTernary):
                    return if_stmt

                # Skip lambda values — the lambda body absorbs the ternary,
                # e.g. `lambda x: expr if cond else lambda x: expr2` parses
                # as `lambda x: (expr if cond else (lambda x: expr2))`
                if isinstance(then_stmt.assignment, Lambda) or isinstance(else_stmt.assignment, Lambda):
                    return if_stmt

                # Build ternary: val if cond else other
                cond = if_stmt.if_condition.tree
                true_val = then_stmt.assignment
                false_val = else_stmt.assignment

                ternary = _ternary_tmpl.apply(
                    self.cursor,
                    values={
                        "val": true_val,
                        "cond": cond,
                        "other": false_val,
                    },
                )
                if isinstance(ternary, ExpressionStatement):
                    ternary = ternary.expression

                # When the if is an elif (body of an Else node), its prefix
                # is empty — the indentation lives on the parent Else.
                # The resulting assignment would lack proper indentation,
                # producing `else:x = ...` on one line.  Skip this case.
                parent = self.cursor.parent
                if parent is not None and isinstance(parent.value, JIf.Else):
                    return if_stmt

                # Create assignment: x = <ternary>
                # The assignment field is JLeftPadded; update via padding helper
                new_assignment = then_stmt.padding.replace(
                    assignment=then_stmt._assignment.replace(
                        element=ternary.replace(prefix=Space.SINGLE_SPACE)
                    )
                )
                # Preserve the if statement's prefix
                new_assignment = new_assignment.replace(prefix=if_stmt.prefix)
                return new_assignment

        return Visitor()
