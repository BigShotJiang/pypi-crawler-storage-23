"""
Recipes that standardize the first parameter name on Python methods.

PEP 8 prescribes specific names for the leading parameter of different
method types:

- Class methods (``@classmethod``) should use ``cls``
- Regular instance methods should use ``self``

When a parameter is renamed, all usages of the old name inside the
method body are updated accordingly.

See: https://peps.python.org/pep-0008/#function-and-method-arguments
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import ClassDeclaration, Identifier, MethodDeclaration, VariableDeclarations

# Define category path: Python > Cleanup
_Cleanup = [*Python, CategoryDescriptor(display_name="Cleanup")]


def _has_decorator(method: MethodDeclaration, name: str) -> bool:
    """Check if a method has a decorator with the given name."""
    return any(
        isinstance(ann.annotation_type, Identifier)
        and ann.annotation_type.simple_name == name
        for ann in method.leading_annotations
    )


def _is_inside_class(cursor) -> bool:
    """Check if the current cursor position is inside a class declaration."""
    c = cursor.parent
    while c is not None:
        if isinstance(c.value, ClassDeclaration):
            return True
        c = c.parent
    return False


def _get_first_param_name(method: MethodDeclaration) -> Optional[str]:
    """Get the simple name of the first parameter, or None if no params."""
    params = method.parameters
    if not params:
        return None
    first_param = params[0]
    if not isinstance(first_param, VariableDeclarations) or not first_param.variables:
        return None
    return first_param.variables[0].name.simple_name


def _make_renaming_visitor(
    should_rename, target_name: str
):
    """Create a visitor that renames the first parameter of matching methods.

    Args:
        should_rename: A callable (method, cursor) -> bool that determines
            whether a method's first parameter should be renamed.
        target_name: The new name for the first parameter (e.g. 'cls' or 'self').
    """

    class Visitor(PythonVisitor[ExecutionContext]):
        def __init__(self):
            super().__init__()
            self._rename_from = None
            self._rename_to = None
            self._depth = 0

        def visit_method_declaration(
            self, method: MethodDeclaration, p: ExecutionContext
        ) -> Optional[MethodDeclaration]:
            if self._depth > 0:
                # Don't rename inside nested functions
                return method

            if not should_rename(method, self.cursor):
                return super().visit_method_declaration(method, p)

            old_name = _get_first_param_name(method)
            if old_name is None or old_name == target_name:
                return super().visit_method_declaration(method, p)

            self._rename_from = old_name
            self._rename_to = target_name
            self._depth += 1
            method = super().visit_method_declaration(method, p)
            self._depth -= 1
            self._rename_from = None
            self._rename_to = None
            return method

        def visit_identifier(
            self, identifier: Identifier, p: ExecutionContext
        ) -> Optional[Identifier]:
            identifier = super().visit_identifier(identifier, p)
            if (
                self._rename_from
                and self._rename_to
                and identifier.simple_name == self._rename_from
            ):
                return identifier.replace(_simple_name=self._rename_to)
            return identifier

    return Visitor()


@categorize(_Cleanup)
class ClassMethodFirstArgName(Recipe):
    """
    Standardize the leading parameter of ``@classmethod`` methods to ``cls``.

    PEP 8 specifies that class methods must name their first argument
    ``cls``. When a different name is found (e.g. ``kls``, ``clazz``),
    this recipe renames it and updates every reference inside the method
    body.

    Example:
        Before:
            class Parser:
                @classmethod
                def from_string(clazz, raw):
                    return clazz(raw)

        After:
            class Parser:
                @classmethod
                def from_string(cls, raw):
                    return cls(raw)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.ClassMethodFirstArgName"

    @property
    def display_name(self) -> str:
        return "Standardize `@classmethod` first parameter to `cls`"

    @property
    def description(self) -> str:
        return (
            "Ensure that `@classmethod` methods use `cls` as their first "
            "parameter, as required by PEP 8, and update all body references."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "cleanup", "naming", "pep8"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        def should_rename(method: MethodDeclaration, cursor) -> bool:
            return _has_decorator(method, "classmethod")

        return _make_renaming_visitor(should_rename, "cls")


@categorize(_Cleanup)
class InstanceMethodFirstArgName(Recipe):
    """
    Standardize the leading parameter of instance methods to ``self``.

    PEP 8 dictates that the first argument of every regular instance
    method must be ``self``. This recipe corrects any deviation and
    propagates the rename throughout the method body.

    Methods annotated with ``@staticmethod`` or ``@classmethod`` are
    skipped. Only methods nested inside a class body are considered.

    Example:
        Before:
            class Account:
                def get_balance(me):
                    return me.balance

        After:
            class Account:
                def get_balance(self):
                    return self.balance
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.InstanceMethodFirstArgName"

    @property
    def display_name(self) -> str:
        return "Standardize instance method first parameter to `self`"

    @property
    def description(self) -> str:
        return (
            "Ensure instance methods use `self` as their first parameter "
            "per PEP 8 and rename all body references. Methods decorated "
            "with `@staticmethod` or `@classmethod` are not affected."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "cleanup", "naming", "pep8"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        def should_rename(method: MethodDeclaration, cursor) -> bool:
            if not _is_inside_class(cursor):
                return False
            if _has_decorator(method, "staticmethod"):
                return False
            if _has_decorator(method, "classmethod"):
                return False
            return True

        return _make_renaming_visitor(should_rename, "self")
