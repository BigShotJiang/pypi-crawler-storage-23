"""
Recipes that reduce verbosity in boolean logic.

Each recipe targets a specific pattern where boolean expressions contain
unnecessary operators, literals, or indirection:

- Explicit ``True``/``False`` comparisons: ``flag == True`` -> ``flag``, ``flag != True`` -> ``not flag``
- Ternary wrappers around booleans: ``True if active else False`` -> ``active``
- Superfluous literals in ``and``/``or``: ``True and val`` -> ``val``, ``False or val`` -> ``val``
- Double negation and De Morgan expansion: ``not not done`` -> ``done``, ``not (m and n)`` -> ``not m or not n``
- Equality against empty containers: ``name == ""`` -> ``not name``, ``items != []`` -> ``items``
- Length-based emptiness checks: ``len(records) > 0`` -> ``records``, ``len(records) == 0`` -> ``not records``
- String-length-to-empty-string: ``len(msg) == 0`` -> ``msg == ""``, ``len(msg) != 0`` -> ``msg != ""``
- Constant collections in conditions: ``if ("a", "b"):`` -> ``if True:``, ``if []:`` -> ``if False:``

See: https://peps.python.org/pep-0008/#programming-recommendations
"""

from typing import Any, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.visitor import Cursor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.python.template import pattern, template, capture
from rewrite.java.tree import (
    Binary as JBinary, ControlParentheses, If as JIf, Literal,
    Ternary as JTernary, Unary, WhileLoop as JWhileLoop,
)
from rewrite.java.support_types import JLeftPadded, Space
from rewrite.python.tree import (
    Binary as PyBinary, CollectionLiteral, DictLiteral,
)

_BOOLEAN_SOURCES = frozenset({"True", "False"})


def _has_boolean_rhs(binary) -> bool:
    """Check that the right operand is a True or False literal (not 1/0)."""
    right = binary.right
    return isinstance(right, Literal) and right.value_source in _BOOLEAN_SOURCES


# Define category path: Python > Cleanup
_Cleanup = [*Python, CategoryDescriptor(display_name="Cleanup")]

# --- SimplifyBooleanComparison patterns/templates ---
_x = capture('x')

# x == True -> x
_eq_true_pattern = pattern("{x} == True", x=_x)
# x == False -> not x
_eq_false_pattern = pattern("{x} == False", x=_x)
# x != True -> not x
_neq_true_pattern = pattern("{x} != True", x=_x)
# x != False -> x
_neq_false_pattern = pattern("{x} != False", x=_x)
# x is True -> x
_is_true_pattern = pattern("{x} is True", x=_x)
# x is False -> not x
_is_false_pattern = pattern("{x} is False", x=_x)
# x is not True -> not x
_is_not_true_pattern = pattern("{x} is not True", x=_x)
# x is not False -> x
_is_not_false_pattern = pattern("{x} is not False", x=_x)

# Templates for results
_x_template = template("{x}", x=_x)
_not_x_template = template("not {x}", x=_x)

# --- RemoveRedundantBoolean patterns/templates ---
_rb_x = capture('rb_x')
_true_and_x_pattern = pattern("True and {rb_x}", rb_x=_rb_x)
_x_and_true_pattern = pattern("{rb_x} and True", rb_x=_rb_x)
_false_and_x_pattern = pattern("False and {rb_x}", rb_x=_rb_x)
_x_and_false_pattern = pattern("{rb_x} and False", rb_x=_rb_x)
_x_or_false_pattern = pattern("{rb_x} or False", rb_x=_rb_x)
_false_or_x_pattern = pattern("False or {rb_x}", rb_x=_rb_x)
_true_or_x_pattern = pattern("True or {rb_x}", rb_x=_rb_x)
_x_or_true_pattern = pattern("{rb_x} or True", rb_x=_rb_x)
_rb_x_template = template("{rb_x}", rb_x=_rb_x)
_rb_true_template = template("True")
_rb_false_template = template("False")

# --- SimplifyEmptyCollectionComparison patterns/templates ---
_ec_x = capture('ec_x')
_eq_empty_str_pattern = pattern('{ec_x} == ""', ec_x=_ec_x)
_neq_empty_str_pattern = pattern('{ec_x} != ""', ec_x=_ec_x)
_eq_empty_list_pattern = pattern("{ec_x} == []", ec_x=_ec_x)
_neq_empty_list_pattern = pattern("{ec_x} != []", ec_x=_ec_x)
_eq_empty_dict_pattern = pattern("{ec_x} == {}", ec_x=_ec_x)
_neq_empty_dict_pattern = pattern("{ec_x} != {}", ec_x=_ec_x)
_eq_empty_tuple_pattern = pattern("{ec_x} == ()", ec_x=_ec_x)
_neq_empty_tuple_pattern = pattern("{ec_x} != ()", ec_x=_ec_x)
_ec_not_x_template = template("not {ec_x}", ec_x=_ec_x)
_ec_x_template = template("{ec_x}", ec_x=_ec_x)

# --- SimplifyLenComparison patterns/templates ---
_lc_x = capture('lc_x')
_len_gt_0_pattern = pattern("len({lc_x}) > 0", lc_x=_lc_x)
_len_neq_0_pattern = pattern("len({lc_x}) != 0", lc_x=_lc_x)
_len_eq_0_pattern = pattern("len({lc_x}) == 0", lc_x=_lc_x)
_len_gte_1_pattern = pattern("len({lc_x}) >= 1", lc_x=_lc_x)
_lc_x_template = template("{lc_x}", lc_x=_lc_x)
_lc_not_x_template = template("not {lc_x}", lc_x=_lc_x)

# --- SimplifyStrLenComparison patterns/templates ---
_sl_s = capture('sl_s')
_slen_eq_0_pattern = pattern("len({sl_s}) == 0", sl_s=_sl_s)
_slen_gt_0_pattern = pattern("len({sl_s}) > 0", sl_s=_sl_s)
_slen_neq_0_pattern = pattern("len({sl_s}) != 0", sl_s=_sl_s)
_sl_eq_empty_template = template('{sl_s} == ""', sl_s=_sl_s)
_sl_neq_empty_template = template('{sl_s} != ""', sl_s=_sl_s)

# --- DeMorgan patterns/templates ---
_dm_x = capture('dm_x')
_dm_y = capture('dm_y')
_not_not_pattern = pattern("not not {dm_x}", dm_x=_dm_x)
_dm_x_template = template("{dm_x}", dm_x=_dm_x)
_not_and_pattern = pattern("not ({dm_x} and {dm_y})", dm_x=_dm_x, dm_y=_dm_y)
_not_or_pattern = pattern("not ({dm_x} or {dm_y})", dm_x=_dm_x, dm_y=_dm_y)
_not_x_or_not_y_template = template("not {dm_x} or not {dm_y}", dm_x=_dm_x, dm_y=_dm_y)
_not_x_and_not_y_template = template("not {dm_x} and not {dm_y}", dm_x=_dm_x, dm_y=_dm_y)
# Partial-negation templates: one operand already negated by operator flip (in→not in)
_not_x_or_y_template = template("not {dm_x} or {dm_y}", dm_x=_dm_x, dm_y=_dm_y)
_x_or_not_y_template = template("{dm_x} or not {dm_y}", dm_x=_dm_x, dm_y=_dm_y)
_not_x_and_y_template = template("not {dm_x} and {dm_y}", dm_x=_dm_x, dm_y=_dm_y)
_x_and_not_y_template = template("{dm_x} and not {dm_y}", dm_x=_dm_x, dm_y=_dm_y)
# Fused DeMorgan + double-negation: not (not x and not y) -> x or y
_not_notx_and_noty_pattern = pattern("not (not {dm_x} and not {dm_y})", dm_x=_dm_x, dm_y=_dm_y)
_x_or_y_template = template("{dm_x} or {dm_y}", dm_x=_dm_x, dm_y=_dm_y)
_not_notx_or_noty_pattern = pattern("not (not {dm_x} or not {dm_y})", dm_x=_dm_x, dm_y=_dm_y)
_x_and_y_template = template("{dm_x} and {dm_y}", dm_x=_dm_x, dm_y=_dm_y)

# DeMorgan with comparison operators: not (p == q and r == s) -> p != q or r != s
_dm_p = capture('dm_p')
_dm_q = capture('dm_q')
_dm_r = capture('dm_r')
_dm_s = capture('dm_s')
_not_eq_and_eq_pattern = pattern("not ({dm_p} == {dm_q} and {dm_r} == {dm_s})", dm_p=_dm_p, dm_q=_dm_q, dm_r=_dm_r, dm_s=_dm_s)
_neq_or_neq_template = template("{dm_p} != {dm_q} or {dm_r} != {dm_s}", dm_p=_dm_p, dm_q=_dm_q, dm_r=_dm_r, dm_s=_dm_s)

# Operator flipping for idiomatic negation of in/is comparisons
_FLIP_OPS = {
    PyBinary.Type.In: PyBinary.Type.NotIn,
    PyBinary.Type.NotIn: PyBinary.Type.In,
    PyBinary.Type.Is: PyBinary.Type.IsNot,
    PyBinary.Type.IsNot: PyBinary.Type.Is,
}


def _flip_py_binary(expr) -> Optional[PyBinary]:
    """Flip a membership/identity operator: ``in`` ↔ ``not in``, ``is`` ↔ ``is not``.

    Returns the flipped :class:`PyBinary`, or ``None`` if the expression is
    not a :class:`PyBinary` with a flippable operator.
    """
    if not isinstance(expr, PyBinary):
        return None
    new_type = _FLIP_OPS.get(expr.operator)
    if new_type is None:
        return None
    new_op = JLeftPadded(
        _before=expr._operator._before,
        _element=new_type,
        _markers=expr._operator._markers,
    )
    # NotIn / IsNot carry a `not` keyword that needs whitespace
    new_negation = (
        Space.SINGLE_SPACE
        if new_type in (PyBinary.Type.NotIn, PyBinary.Type.IsNot)
        else None
    )
    return expr.replace(_operator=new_op, _negation=new_negation)


def _is_bool_literal(node, expected_source: str) -> bool:
    """Check if a node is a specific boolean literal (by value_source)."""
    return isinstance(node, Literal) and node.value_source == expected_source


@categorize(_Cleanup)
class SimplifyBooleanComparison(Recipe):
    """
    Eliminate explicit comparisons to ``True`` and ``False`` literals.

    Testing a value with ``==`` or ``!=`` against a boolean literal adds
    no information -- the bare expression (or its negation) already
    conveys the intent and is shorter.

    Example:
        Before:
            if is_valid == True:
                pass

        After:
            if is_valid:
                pass
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.SimplifyBooleanComparison"

    @property
    def display_name(self) -> str:
        return "Remove explicit True/False comparisons"

    @property
    def description(self) -> str:
        return (
            "Drop unnecessary ``== True``, ``!= False``, and similar tests "
            "against boolean literals, leaving just the expression or ``not expr``."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_binary(
                self, binary: JBinary, p: ExecutionContext
            ) -> Optional[JBinary]:
                binary = super().visit_binary(binary, p)

                # Guard: RHS must be an actual True/False literal (not 1/0)
                if not _has_boolean_rhs(binary):
                    return binary

                # == True, != False -> x
                for pat in (_eq_true_pattern, _neq_false_pattern):
                    match = pat.match(binary, self.cursor)
                    if match:
                        return _x_template.apply(self.cursor, values=match)

                # == False, != True -> not x
                for pat in (_eq_false_pattern, _neq_true_pattern):
                    match = pat.match(binary, self.cursor)
                    if match:
                        return _not_x_template.apply(self.cursor, values=match)

                return binary

        return Visitor()


@categorize(_Cleanup)
class BooleanIfExpIdentity(Recipe):
    """
    Collapse ternary expressions that merely wrap a condition in ``True``/``False``.

    A conditional expression whose branches are the boolean literals ``True``
    and ``False`` adds nothing beyond the condition itself, so the ternary
    can be replaced with the condition (or ``not condition``).

    Example:
        Before:
            enabled = True if check_flag else False

        After:
            enabled = check_flag
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.BooleanIfExpIdentity"

    @property
    def display_name(self) -> str:
        return "Collapse boolean ternary to bare condition"

    @property
    def description(self) -> str:
        return (
            "Replace ``True if expr else False`` with ``expr`` and "
            "``False if expr else True`` with ``not expr``, removing the "
            "redundant ternary wrapper."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        _cond = capture('cond')
        _bool_cond_template = template("bool({cond})", cond=_cond)
        _not_cond_template = template("not {cond}", cond=_cond)

        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_ternary(
                self, ternary: JTernary, p: ExecutionContext
            ) -> Optional[JTernary]:
                ternary = super().visit_ternary(ternary, p)

                true_part = ternary.true_part
                false_part = ternary.false_part

                # True if cond else False -> bool(cond)
                # Using bool() preserves the guaranteed bool return type;
                # bare `cond` could return any truthy/falsy value.
                if _is_bool_literal(true_part, "True") and _is_bool_literal(false_part, "False"):
                    from rewrite.python.template.pattern import MatchResult
                    match = MatchResult({'cond': ternary.condition})
                    return _bool_cond_template.apply(self.cursor, values=match)

                # False if cond else True -> not cond
                if _is_bool_literal(true_part, "False") and _is_bool_literal(false_part, "True"):
                    from rewrite.python.template.pattern import MatchResult
                    match = MatchResult({'cond': ternary.condition})
                    return _not_cond_template.apply(self.cursor, values=match)

                return ternary

        return Visitor()


def _is_true_literal(node) -> bool:
    """Check if a node is a True literal (not 1)."""
    return isinstance(node, Literal) and node.value_source == "True"


def _is_false_literal(node) -> bool:
    """Check if a node is a False literal (not 0)."""
    return isinstance(node, Literal) and node.value_source == "False"


@categorize(_Cleanup)
class RemoveRedundantBoolean(Recipe):
    """
    Strip unnecessary ``True``/``False`` operands from logical connectives.

    When ``True`` or ``False`` appears as one side of an ``and`` or ``or``
    expression, the outcome is determined by the other operand (or by the
    literal alone), making the boolean literal superfluous.

    Example:
        Before:
            result = True and calculate()

        After:
            result = calculate()
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.RemoveRedundantBoolean"

    @property
    def display_name(self) -> str:
        return "Eliminate boolean literal from `and`/`or`"

    @property
    def description(self) -> str:
        return (
            "Strip ``True`` or ``False`` from ``and``/``or`` expressions where "
            "the literal has no effect on the result, e.g. ``True and val`` "
            "reduces to ``val`` and ``False and val`` reduces to ``False``."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def _has_any_bool_literal(self, binary: JBinary) -> bool:
                """Check if either side of binary is a True/False literal (not 1/0)."""
                left = binary.left
                right = binary.right
                return (
                    (isinstance(left, Literal) and left.value_source in _BOOLEAN_SOURCES)
                    or (isinstance(right, Literal) and right.value_source in _BOOLEAN_SOURCES)
                )

            def visit_binary(
                self, binary: JBinary, p: ExecutionContext
            ) -> Optional[JBinary]:
                binary = super().visit_binary(binary, p)

                # Guard: at least one side must be an actual True/False literal (not 1/0)
                if not self._has_any_bool_literal(binary):
                    return binary

                # True and x -> x, x and True -> x
                for pat in (_true_and_x_pattern, _x_and_true_pattern):
                    match = pat.match(binary, self.cursor)
                    if match:
                        return _rb_x_template.apply(self.cursor, values=match)

                # False and x -> False, x and False -> False
                for pat in (_false_and_x_pattern, _x_and_false_pattern):
                    match = pat.match(binary, self.cursor)
                    if match:
                        return _rb_false_template.apply(self.cursor, values=match)

                # x or False -> x, False or x -> x
                for pat in (_x_or_false_pattern, _false_or_x_pattern):
                    match = pat.match(binary, self.cursor)
                    if match:
                        return _rb_x_template.apply(self.cursor, values=match)

                # True or x -> True, x or True -> True
                for pat in (_true_or_x_pattern, _x_or_true_pattern):
                    match = pat.match(binary, self.cursor)
                    if match:
                        return _rb_true_template.apply(self.cursor, values=match)

                return binary

        return Visitor()


def _apply_demorgan(cursor, match, both_not, left_not, right_not, neither_not):
    """Apply a DeMorgan template, flipping ``in``/``is`` operators instead of
    prepending ``not`` where possible.

    For example, ``not (A and X in Y)`` becomes ``not A or X not in Y``
    rather than ``not A or not X in Y``.  The latter is semantically correct
    but unidiomatic; Python's ``not in`` / ``is not`` operators are the
    canonical way to negate membership and identity tests.
    """
    from rewrite.python.template.pattern import MatchResult

    dm_x_val = match['dm_x']
    dm_y_val = match['dm_y']
    x_flipped = _flip_py_binary(dm_x_val)
    y_flipped = _flip_py_binary(dm_y_val)

    if x_flipped and y_flipped:
        values = MatchResult({'dm_x': x_flipped, 'dm_y': y_flipped})
        return neither_not.apply(cursor, values=values)
    if x_flipped:
        values = MatchResult({'dm_x': x_flipped, 'dm_y': dm_y_val})
        return right_not.apply(cursor, values=values)
    if y_flipped:
        values = MatchResult({'dm_x': dm_x_val, 'dm_y': y_flipped})
        return left_not.apply(cursor, values=values)
    return both_not.apply(cursor, values=match)


@categorize(_Cleanup)
class DeMorgan(Recipe):
    """
    Flatten negated compound logic using De Morgan's identities.

    Double negation and negated conjunctions/disjunctions can be rewritten
    into equivalent forms that are shorter and easier to reason about.

    Example:
        Before:
            result = not not finished

        After:
            result = finished
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.DeMorgan"

    @property
    def display_name(self) -> str:
        return "Flatten negated logic via De Morgan's identities"

    @property
    def description(self) -> str:
        return (
            "Use De Morgan's identities to remove double negation and to "
            "distribute ``not`` into compound conditions, e.g. "
            "``not not finished`` becomes ``finished`` and "
            "``not (m and n)`` becomes ``not m or not n``."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_unary(
                self, unary: Unary, p: ExecutionContext
            ) -> Optional[Unary]:
                unary = super().visit_unary(unary, p)
                cursor = Cursor(self.cursor.parent, unary)

                # not not x -> x
                match = _not_not_pattern.match(unary, cursor)
                if match:
                    return _dm_x_template.apply(cursor, values=match)

                # not (p == q and r == s) -> p != q or r != s
                match = _not_eq_and_eq_pattern.match(unary, cursor)
                if match:
                    return _neq_or_neq_template.apply(cursor, values=match)

                # Fused: not (not x and not y) -> x or y
                match = _not_notx_and_noty_pattern.match(unary, cursor)
                if match:
                    return _x_or_y_template.apply(cursor, values=match)

                # Fused: not (not x or not y) -> x and y
                match = _not_notx_or_noty_pattern.match(unary, cursor)
                if match:
                    return _x_and_y_template.apply(cursor, values=match)

                # not (x and y) -> not x or not y
                # Skip multi-way chains: not (a and b and c) where dm_x
                # captures (a and b) — partial expansion is messy.
                match = _not_and_pattern.match(unary, cursor)
                if match:
                    dm_x_val = match['dm_x']
                    if not (isinstance(dm_x_val, JBinary) and dm_x_val.operator == JBinary.Type.And):
                        return _apply_demorgan(
                            cursor, match, _not_x_or_not_y_template,
                            _not_x_or_y_template, _x_or_not_y_template,
                            _x_or_y_template,
                        )

                # not (x or y) -> not x and not y
                match = _not_or_pattern.match(unary, cursor)
                if match:
                    dm_x_val = match['dm_x']
                    if not (isinstance(dm_x_val, JBinary) and dm_x_val.operator == JBinary.Type.Or):
                        return _apply_demorgan(
                            cursor, match, _not_x_and_not_y_template,
                            _not_x_and_y_template, _x_and_not_y_template,
                            _x_and_y_template,
                        )

                return unary

        return Visitor()


@categorize(_Cleanup)
class SimplifyEmptyCollectionComparison(Recipe):
    """
    Convert equality tests against empty containers to truthiness checks.

    Testing whether a variable equals ``""``, ``[]``, ``{}``, or ``()``
    is equivalent to checking its boolean value, which is both shorter
    and consistent with PEP 8 guidance on empty-sequence testing.

    Example:
        Before:
            if username == "":
                pass

        After:
            if not username:
                pass
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.SimplifyEmptyCollectionComparison"

    @property
    def display_name(self) -> str:
        return "Use truthiness instead of empty-container equality"

    @property
    def description(self) -> str:
        return (
            "Convert ``== \"\"``/``== []``/``== {}``/``== ()`` into "
            "``not var`` and the corresponding ``!=`` forms into ``var``, "
            "relying on Python's truthiness semantics for empty collections."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_binary(
                self, binary: JBinary, p: ExecutionContext
            ) -> Optional[JBinary]:
                binary = super().visit_binary(binary, p)

                # == empty collection -> not x
                for pat in (
                    _eq_empty_str_pattern,
                    _eq_empty_list_pattern,
                    _eq_empty_dict_pattern,
                    _eq_empty_tuple_pattern,
                ):
                    match = pat.match(binary, self.cursor)
                    if match:
                        return _ec_not_x_template.apply(self.cursor, values=match)

                # != empty collection -> x
                for pat in (
                    _neq_empty_str_pattern,
                    _neq_empty_list_pattern,
                    _neq_empty_dict_pattern,
                    _neq_empty_tuple_pattern,
                ):
                    match = pat.match(binary, self.cursor)
                    if match:
                        return _ec_x_template.apply(self.cursor, values=match)

                return binary

        return Visitor()


@categorize(_Cleanup)
class SimplifyLenComparison(Recipe):
    """
    Replace ``len()``-based emptiness checks with direct truthiness tests.

    Comparing ``len(seq)`` against zero is a verbose way to test whether a
    collection is empty or non-empty.  Python's truthiness protocol already
    handles this, so the ``len()`` call can be dropped entirely.

    Example:
        Before:
            if len(items) > 0:
                pass

        After:
            if items:
                pass
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.SimplifyLenComparison"

    @property
    def display_name(self) -> str:
        return "Replace `len()` emptiness check with truthiness"

    @property
    def description(self) -> str:
        return (
            "Rewrite ``len(seq) > 0`` / ``len(seq) != 0`` to ``seq`` and "
            "``len(seq) == 0`` to ``not seq``, leveraging Python's built-in "
            "truthiness for collections."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_binary(
                self, binary: JBinary, p: ExecutionContext
            ) -> Optional[JBinary]:
                binary = super().visit_binary(binary, p)

                # len(x) > 0, len(x) != 0, len(x) >= 1 -> x
                for pat in (_len_gt_0_pattern, _len_neq_0_pattern, _len_gte_1_pattern):
                    match = pat.match(binary, self.cursor)
                    if match:
                        return _lc_x_template.apply(self.cursor, values=match)

                # len(x) == 0 -> not x
                match = _len_eq_0_pattern.match(binary, self.cursor)
                if match:
                    return _lc_not_x_template.apply(self.cursor, values=match)

                return binary

        return Visitor()


@categorize(_Cleanup)
class SimplifyStrLenComparison(Recipe):
    """
    Rewrite ``len()``-based string emptiness tests as comparisons to ``""``.

    Rather than measuring a string's length and comparing the result to zero,
    compare the string directly to the empty string literal for clarity.

    Example:
        Before:
            if len(line) == 0:
                pass

        After:
            if line == "":
                pass
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.SimplifyStrLenComparison"

    @property
    def display_name(self) -> str:
        return "Compare string to `\"\"` instead of checking `len()`"

    @property
    def description(self) -> str:
        return (
            "Replace ``len(text) == 0`` with ``text == \"\"`` and "
            "``len(text) > 0`` / ``len(text) != 0`` with ``text != \"\"``, "
            "comparing the string directly rather than measuring its length."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_binary(
                self, binary: JBinary, p: ExecutionContext
            ) -> Optional[JBinary]:
                binary = super().visit_binary(binary, p)

                # len(s) == 0 -> s == ""
                match = _slen_eq_0_pattern.match(binary, self.cursor)
                if match:
                    return _sl_eq_empty_template.apply(self.cursor, values=match)

                # len(s) > 0, len(s) != 0 -> s != ""
                for pat in (_slen_gt_0_pattern, _slen_neq_0_pattern):
                    match = pat.match(binary, self.cursor)
                    if match:
                        return _sl_neq_empty_template.apply(self.cursor, values=match)

                return binary

        return Visitor()


def _is_collection_literal(node) -> Optional[bool]:
    """
    Check if a node is a collection literal and return whether it's non-empty.

    Returns True if non-empty, False if empty, None if not a collection literal.

    Note: In the OpenRewrite AST, empty collections like `[]` still have one
    element which is an `Empty` sentinel node. A truly empty collection has
    exactly one `Empty` element, while non-empty collections have real elements.
    """
    from rewrite.java.tree import Empty
    if isinstance(node, (CollectionLiteral, DictLiteral)):
        elements = node.elements
        # Empty collection: single Empty sentinel element
        if len(elements) == 1 and isinstance(elements[0], Empty):
            return False
        return True
    return None


@categorize(_Cleanup)
class CollectionToBool(Recipe):
    """
    Substitute literal collections in ``if``/``while`` conditions with their boolean value.

    When a collection literal (list, tuple, dict, or set) appears as a
    condition, its truth value is fixed at write time: non-empty means
    ``True``, empty means ``False``.  Using the boolean directly makes
    the intent explicit.

    Example:
        Before:
            if ("alpha", "beta"):
                pass

        After:
            if True:
                pass
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.CollectionToBool"

    @property
    def display_name(self) -> str:
        return "Substitute constant collection condition with boolean"

    @property
    def description(self) -> str:
        return (
            "When a list, tuple, dict, or set literal is used as an ``if`` or "
            "``while`` condition, replace it with ``True`` (non-empty) or "
            "``False`` (empty) to state the intent directly."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def _make_bool_literal(self, is_true: bool, prefix) -> Literal:
                """Create a True or False literal with the given prefix."""
                import uuid
                from rewrite.markers import Markers
                return Literal(
                    _id=uuid.uuid4(),
                    _prefix=prefix,
                    _markers=Markers.EMPTY,
                    _value=is_true,
                    _value_source="True" if is_true else "False",
                    _unicode_escapes=None,
                    _type=None,
                )

            def visit_if(
                self, if_stmt: JIf, p: ExecutionContext
            ) -> Optional[JIf]:
                if_stmt = super().visit_if(if_stmt, p)
                cond = if_stmt.if_condition
                # The condition is wrapped in ControlParentheses
                if isinstance(cond, ControlParentheses):
                    inner = cond.tree
                else:
                    inner = cond
                is_non_empty = _is_collection_literal(inner)
                if is_non_empty is None:
                    return if_stmt
                new_lit = self._make_bool_literal(is_non_empty, inner.prefix)
                if isinstance(cond, ControlParentheses):
                    rp = cond.padding.tree
                    new_rp = rp.replace(_element=new_lit)
                    new_cp = cond.replace(_tree=new_rp)
                    return if_stmt.replace(_if_condition=new_cp)
                return if_stmt.replace(_if_condition=new_lit)

            def visit_while_loop(
                self, while_loop: JWhileLoop, p: ExecutionContext
            ) -> Optional[JWhileLoop]:
                while_loop = super().visit_while_loop(while_loop, p)
                cond = while_loop.condition
                if isinstance(cond, ControlParentheses):
                    inner = cond.tree
                else:
                    inner = cond
                is_non_empty = _is_collection_literal(inner)
                if is_non_empty is None:
                    return while_loop
                new_lit = self._make_bool_literal(is_non_empty, inner.prefix)
                if isinstance(cond, ControlParentheses):
                    rp = cond.padding.tree
                    new_rp = rp.replace(_element=new_lit)
                    new_cp = cond.replace(_tree=new_rp)
                    return while_loop.replace(_condition=new_cp)
                return while_loop.replace(_condition=new_lit)

        return Visitor()
