"""OpenRewrite recipes for Python code quality and cleanup."""

from typing import TYPE_CHECKING

from rewrite.java import J
from rewrite.python.template.comparator import PatternMatchingComparator

if TYPE_CHECKING:
    from rewrite.visitor import Cursor


def trees_equal(a: J, b: J, cursor: "Cursor") -> bool:
    """Check if two AST subtrees are structurally equal, ignoring whitespace."""
    return PatternMatchingComparator(captures={}).match(a, b, cursor) is not None
