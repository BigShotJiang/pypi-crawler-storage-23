"""
Recipes that improve the readability of comparison expressions.

- FlipComparison: reorder constants to the right (``42 == n`` -> ``n == 42``)
- SimplifySubstringSearch: use ``in``/``not in`` instead of ``.find()`` return checks
- MergeComparisons: combine repeated ``==`` tests via ``in`` (``v == 1 or v == 2`` -> ``v in [1, 2]``)
- ChainCompares: merge adjacent relational tests into chained form (``0 < k and k < 10`` -> ``0 < k < 10``)
"""

from typing import Any, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.python.template import pattern, template, capture
from rewrite.java.tree import Binary as JBinary, JRightPadded, Literal, Space
from rewrite.markers import Markers
from rewrite.python import tree as py
from openrewrite_static_analysis.cleanup import trees_equal

_Cleanup = [*Python, CategoryDescriptor(display_name="Cleanup")]


# Operator flipping map for relational operators
_FLIPPED_OPS = {
    JBinary.Type.Equal: JBinary.Type.Equal,
    JBinary.Type.NotEqual: JBinary.Type.NotEqual,
    JBinary.Type.LessThan: JBinary.Type.GreaterThan,
    JBinary.Type.GreaterThan: JBinary.Type.LessThan,
    JBinary.Type.LessThanOrEqual: JBinary.Type.GreaterThanOrEqual,
    JBinary.Type.GreaterThanOrEqual: JBinary.Type.LessThanOrEqual,
}

# Pattern/template pairs for SimplifySubstringSearch
_x = capture('x')
_y = capture('y')
_find_eq_neg1_pattern = pattern("{x}.find({y}) == -1", x=_x, y=_y)
_not_in_template = template("{y} not in {x}", x=_x, y=_y)
_find_neq_neg1_pattern = pattern("{x}.find({y}) != -1", x=_x, y=_y)
_in_template = template("{y} in {x}", x=_x, y=_y)

# Template for MergeComparisons output
_mx = capture('mx')
_my = capture('my')
_mz = capture('mz')
_merge_template = template("{mx} in [{my}, {mz}]", mx=_mx, my=_my, mz=_mz)


@categorize(_Cleanup)
class FlipComparison(Recipe):
    """
    Move literal operands to the right side of comparisons.

    Placing a constant on the left of a comparison (sometimes called
    "Yoda style") is harder to read than the natural ``variable op literal``
    order.  This recipe swaps the operands and mirrors the relational
    operator so the semantics are preserved.

    Example:
        Before:
            if 42 == count:
                pass

        After:
            if count == 42:
                pass
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.FlipComparison"

    @property
    def display_name(self) -> str:
        return "Reorder comparisons to put literals on the right"

    @property
    def description(self) -> str:
        return (
            "Swap operands when a constant appears on the left of a "
            "comparison, e.g. ``42 == count`` becomes ``count == 42``, "
            "mirroring the relational operator as needed."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_binary(
                self, binary: JBinary, p: ExecutionContext
            ) -> Optional[JBinary]:
                binary = super().visit_binary(binary, p)
                op = binary.operator
                if op not in _FLIPPED_OPS:
                    return binary

                # Don't flip if this binary is part of a chained comparison.
                # The framework represents `a <= x < b` as nested Binary nodes;
                # flipping the inner one breaks chained-comparison semantics.
                parent = self.cursor.parent
                if parent is not None and isinstance(parent.value, JBinary):
                    parent_op = parent.value.operator
                    if parent_op in _FLIPPED_OPS:
                        return binary

                # Also don't flip if this binary *contains* a comparison child
                # (i.e., this is the outer node of a chained comparison).
                if isinstance(binary.left, JBinary) and binary.left.operator in _FLIPPED_OPS:
                    return binary
                if isinstance(binary.right, JBinary) and binary.right.operator in _FLIPPED_OPS:
                    return binary

                left = binary.left
                right = binary.right
                # Only flip when left is a literal and right is not
                if isinstance(left, Literal) and not isinstance(right, Literal):
                    flipped_op = _FLIPPED_OPS[op]
                    # Swap left and right, preserving their respective prefixes
                    new_left = right.replace(_prefix=left.prefix)
                    new_right = left.replace(_prefix=right.prefix)
                    new_operator = binary._operator.replace(_element=flipped_op)
                    return binary.replace(
                        _left=new_left,
                        _right=new_right,
                        _operator=new_operator,
                    )
                return binary

        return Visitor()


@categorize(_Cleanup)
class SimplifySubstringSearch(Recipe):
    """
    Use ``in``/``not in`` instead of inspecting the ``.find()`` return value.

    Checking whether ``.find()`` returns ``-1`` is a C-style idiom.  Python's
    membership operators express substring presence more clearly and concisely.

    Example:
        Before:
            if text.find("needle") == -1:
                pass

        After:
            if "needle" not in text:
                pass
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.SimplifySubstringSearch"

    @property
    def display_name(self) -> str:
        return "Replace `.find()` check with `in` / `not in`"

    @property
    def description(self) -> str:
        return (
            "Rewrite ``.find()`` return-value checks as membership tests: "
            "``text.find(sub) == -1`` becomes ``sub not in text`` and "
            "``text.find(sub) != -1`` becomes ``sub in text``."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_binary(
                self, binary: JBinary, p: ExecutionContext
            ) -> Optional[JBinary]:
                binary = super().visit_binary(binary, p)
                match = _find_eq_neg1_pattern.match(binary, self.cursor)
                if match:
                    return _not_in_template.apply(self.cursor, values=match)
                match = _find_neq_neg1_pattern.match(binary, self.cursor)
                if match:
                    return _in_template.apply(self.cursor, values=match)
                return binary

        return Visitor()


@categorize(_Cleanup)
class MergeComparisons(Recipe):
    """
    Combine duplicate equality tests joined by ``or`` into a single ``in`` check.

    When the same expression is compared for equality against two values
    separated by ``or``, a membership test with a list is more compact
    and easier to extend later.

    Example:
        Before:
            if status == "active" or status == "pending":
                process()

        After:
            if status in ["active", "pending"]:
                process()
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.MergeComparisons"

    @property
    def display_name(self) -> str:
        return "Consolidate repeated `==` with `or` into `in`"

    @property
    def description(self) -> str:
        return (
            "Fold ``var == a or var == b`` into ``var in [a, b]``, "
            "reducing duplication and improving readability."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_binary(
                self, binary: JBinary, p: ExecutionContext
            ) -> Optional[JBinary]:
                binary = super().visit_binary(binary, p)
                # Match: ... or x == c (J.Binary with Or operator)
                if binary.operator != JBinary.Type.Or:
                    return binary
                left = binary.left
                right = binary.right

                # Right side must be x == c
                if not isinstance(right, JBinary) or right.operator != JBinary.Type.Equal:
                    return binary

                # Case 1: x in [a, b] or x == c  ->  x in [a, b, c]
                if (isinstance(left, py.Binary)
                        and left.operator == py.Binary.Type.In
                        and isinstance(left.right, py.CollectionLiteral)
                        and left.right.kind == py.CollectionLiteral.Kind.LIST
                        and trees_equal(left.left, right.left, self.cursor)):
                    collection = left.right
                    old_padded = list(collection._elements._elements)
                    # Append the new value with leading space
                    new_elem = right.right.replace(_prefix=Space([], ' '))
                    old_padded.append(JRightPadded(new_elem, Space.EMPTY, Markers.EMPTY))
                    new_container = collection._elements.replace(_elements=old_padded)
                    new_collection = collection.replace(_elements=new_container)
                    return left.replace(_right=new_collection, _prefix=binary.prefix)

                # Case 2: x == a or x == b  ->  x in [a, b]
                if not isinstance(left, JBinary) or left.operator != JBinary.Type.Equal:
                    return binary
                if not trees_equal(left.left, right.left, self.cursor):
                    return binary
                values = {
                    'mx': left.left,
                    'my': left.right,
                    'mz': right.right,
                }
                return _merge_template.apply(self.cursor, values=values)

        return Visitor()


@categorize(_Cleanup)
class ChainCompares(Recipe):
    """
    Merge adjacent relational tests into Python's chained comparison syntax.

    When two comparisons sharing a common inner operand are linked by ``and``,
    Python's chained-comparison form expresses the same constraint more
    concisely.

    Example:
        Before:
            if 0 < idx and idx < size:
                print("idx is within bounds")

        After:
            if 0 < idx < size:
                print("idx is within bounds")
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.ChainCompares"

    @property
    def display_name(self) -> str:
        return "Use chained comparison syntax"

    @property
    def description(self) -> str:
        return (
            "Merge two relational tests that share a middle operand into "
            "a single chained comparison, e.g. ``0 < idx and idx < size`` "
            "becomes ``0 < idx < size``."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        _RELATIONAL_OPS = frozenset({
            JBinary.Type.LessThan,
            JBinary.Type.LessThanOrEqual,
            JBinary.Type.GreaterThan,
            JBinary.Type.GreaterThanOrEqual,
        })

        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_binary(
                self, binary: JBinary, p: ExecutionContext
            ) -> Optional[JBinary]:
                binary = super().visit_binary(binary, p)
                # Match: left_cmp and right_cmp
                if binary.operator != JBinary.Type.And:
                    return binary
                left = binary.left
                right = binary.right
                if not isinstance(left, JBinary) or not isinstance(right, JBinary):
                    return binary
                if left.operator not in _RELATIONAL_OPS:
                    return binary
                if right.operator not in _RELATIONAL_OPS:
                    return binary
                # The middle operand must match: left.right == right.left
                if not trees_equal(left.right, right.left, self.cursor):
                    return binary
                # Build chained: Binary(left_cmp, right_op, right.right)
                # This produces Binary(Binary(a, <, b), <, c) which prints as a < b < c
                return binary.replace(
                    _left=left,
                    _operator=binary._operator.replace(element=right.operator),
                    _right=right.right.replace(prefix=right.right.prefix),
                )

        return Visitor()
