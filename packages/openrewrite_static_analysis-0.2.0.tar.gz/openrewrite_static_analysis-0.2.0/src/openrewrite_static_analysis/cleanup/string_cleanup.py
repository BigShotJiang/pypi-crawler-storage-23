"""
Recipes that clean up unnecessary string and formatting constructs.

- Unwrap ``str()`` inside ``print()`` since ``print`` handles conversion automatically
- Strip the explicit ``None`` default from ``dict.get()`` since it is already the default
- Remove the ``f`` prefix from f-strings that contain no interpolated expressions
- Remove ``str()`` wrapping inside f-string placeholders where conversion is implicit
- Rewrite ``text[:N] == "literal"`` as ``text.startswith("literal")`` for clarity
- Rewrite ``text[-N:] == "literal"`` as ``text.endswith("literal")`` for clarity
- Use bracket notation (``match[n]``) instead of ``.group(n)`` for regex match access
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers
from rewrite.python.visitor import PythonVisitor
from rewrite.python.template import pattern, template, capture
from rewrite.python.tree import FormattedString, Slice
from rewrite.java.tree import (
    ArrayAccess,
    Assignment,
    Binary,
    Block,
    Empty,
    Expression,
    If,
    Identifier,
    Literal,
    MethodInvocation,
    Statement,
    Unary,
)
from rewrite.java.support_types import JContainer, JLeftPadded, JRightPadded, Space
from rewrite.utils import random_id

_Cleanup = [*Python, CategoryDescriptor(display_name="Cleanup")]

# Pattern/template for print(str(x)) -> print(x)
_x = capture('x')
_str_print_pattern = pattern("print(str({x}))", x=_x)
_str_print_template = template("print({x})", x=_x)

# Pattern/template for d.get(k, None) -> d.get(k)
_d = capture('d')
_k = capture('k')
_get_none_pattern = pattern("{d}.get({k}, None)", d=_d, k=_k)
_get_none_template = template("{d}.get({k})", d=_d, k=_k)

# Pattern/template for m.group(n) -> m[n]
_m = capture('m')
_n = capture('n')
_group_pattern = pattern("{m}.group({n})", m=_m, n=_n)
_group_template = template("{m}[{n}]", m=_m, n=_n)


def _is_string_literal(expr: Any) -> bool:
    """Check if an expression is a string literal."""
    if isinstance(expr, Literal):
        value_source = expr.value_source
        if value_source and len(value_source) > 0:
            first_char = value_source[0]
            if first_char in ('"', "'"):
                return True
            if len(value_source) > 1 and first_char.lower() in ('r', 'b', 'u') and value_source[1] in ('"', "'"):
                return True
    return False


def _get_literal_string_len(expr: Any) -> Optional[int]:
    """If expr is a string Literal, return the length of its string value."""
    if not _is_string_literal(expr):
        return None
    val = expr.value
    if isinstance(val, str):
        return len(val)
    return None


def _get_int_value(expr: Any) -> Optional[int]:
    """Get integer value from a Literal or Unary(Negative, Literal)."""
    if isinstance(expr, Literal) and isinstance(expr.value, int):
        return expr.value
    if isinstance(expr, Unary) and expr.operator == Unary.Type.Negative:
        inner = expr.expression
        if isinstance(inner, Literal) and isinstance(inner.value, int):
            return -inner.value
    return None


def _make_method_call(
    prefix: Space,
    target: Expression,
    method_name: str,
    arg: Expression,
) -> MethodInvocation:
    """Build a MethodInvocation like ``target.method_name(arg)``."""
    name_id = Identifier(
        _id=random_id(),
        _prefix=Space.EMPTY,
        _markers=Markers.EMPTY,
        _annotations=[],
        _simple_name=method_name,
        _type=None,
        _field_type=None,
    )
    args = JContainer(
        _before=Space.EMPTY,
        _elements=[JRightPadded(
            _element=arg.replace(_prefix=Space.EMPTY),
            _after=Space.EMPTY,
            _markers=Markers.EMPTY,
        )],
        _markers=Markers.EMPTY,
    )
    return MethodInvocation(
        _id=random_id(),
        _prefix=prefix,
        _markers=Markers.EMPTY,
        _select=JRightPadded(
            _element=target.replace(_prefix=Space.EMPTY),
            _after=Space.EMPTY,
            _markers=Markers.EMPTY,
        ),
        _type_parameters=None,
        _name=name_id,
        _arguments=args,
        _method_type=None,
    )


@categorize(_Cleanup)
class RemoveStrFromPrint(Recipe):
    """
    Unwrap a needless ``str()`` call from inside ``print()``.

    ``print()`` performs string conversion on every argument automatically,
    so passing ``str(value)`` instead of ``value`` adds a redundant step.

    Example:
        Before:
            print(str(total))

        After:
            print(total)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.RemoveStrFromPrint"

    @property
    def display_name(self) -> str:
        return "Unwrap ``str()`` from ``print()`` arguments"

    @property
    def description(self) -> str:
        return (
            "``print()`` automatically converts its arguments to strings, "
            "so an explicit ``str()`` wrapper is unnecessary and can be removed."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)
                match = _str_print_pattern.match(method, self.cursor)
                if match:
                    return _str_print_template.apply(self.cursor, values=match)
                return method

        return Visitor()


@categorize(_Cleanup)
class RemoveNoneFromDefaultGet(Recipe):
    """
    Remove redundant `None` default from `dict.get()`.

    The `dict.get()` method already returns `None` when the key is not found,
    so passing `None` as the default value is unnecessary.

    Example:
        Before:
            x = d.get('key', None)

        After:
            x = d.get('key')
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.RemoveNoneFromDefaultGet"

    @property
    def display_name(self) -> str:
        return "Remove redundant `None` default from `dict.get()`"

    @property
    def description(self) -> str:
        return (
            "Remove redundant `None` default argument from `dict.get()` calls "
            "since `None` is already the default return value."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)
                match = _get_none_pattern.match(method, self.cursor)
                if match:
                    return _get_none_template.apply(self.cursor, values=match)
                return method

        return Visitor()


@categorize(_Cleanup)
class RemoveRedundantFstring(Recipe):
    """
    Convert an f-string with no interpolations to a plain string literal.

    An ``f``-prefixed string that contains zero ``{...}`` placeholders
    behaves identically to a regular string. Dropping the prefix makes
    it obvious that no dynamic substitution is happening.

    Example:
        Before:
            greeting = f"hello world"

        After:
            greeting = "hello world"
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.RemoveRedundantFstring"

    @property
    def display_name(self) -> str:
        return "Drop ``f`` prefix from strings without placeholders"

    @property
    def description(self) -> str:
        return (
            "When an f-string has no ``{...}`` expressions, strip the ``f`` "
            "prefix and convert it to an ordinary string literal."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_formatted_string(
                self, fs: FormattedString, p: ExecutionContext
            ) -> Optional[Expression]:
                fs = super().visit_formatted_string(fs, p)
                if not isinstance(fs, FormattedString):
                    return fs

                # If any part is a Value (interpolation), keep the f-string
                has_values = any(
                    isinstance(part, FormattedString.Value) for part in fs.parts
                )
                if has_values:
                    return fs

                # Build the string content from Literal parts
                content = ''
                for part in fs.parts:
                    if isinstance(part, Literal):
                        content += part.value_source if part.value_source else ''

                # Build the string value from Literal parts
                value = ''
                for part in fs.parts:
                    if isinstance(part, Literal):
                        value += part.value if part.value else ''

                # Determine quote style from the f-string delimiter.
                # Strip prefix characters (f, r, b, etc.) to find the
                # quote chars, then re-add any non-f prefixes (e.g. rf" → r").
                delim = fs.delimiter
                quote_start = 0
                for i, ch in enumerate(delim):
                    if ch in ('"', "'"):
                        quote_start = i
                        break
                non_f_prefix = ""
                for i in range(quote_start):
                    if delim[i].lower() != 'f':
                        non_f_prefix += delim[i]
                quote_chars = delim[quote_start:]  # e.g. " or ' or """ or '''

                return Literal(
                    _id=random_id(),
                    _prefix=fs.prefix,
                    _markers=Markers.EMPTY,
                    _value=value,
                    _value_source=non_f_prefix + quote_chars + content + quote_chars,
                    _unicode_escapes=None,
                    _type=None,
                )

        return Visitor()


@categorize(_Cleanup)
class RemoveStrFromFstring(Recipe):
    """
    Strip ``str()`` wrappers from f-string placeholders.

    F-string interpolation already invokes ``__str__`` on each embedded
    expression, making an explicit ``str()`` call inside ``{...}`` redundant.

    Example:
        Before:
            msg = f"User: {str(username)}, Score: {str(points)}"

        After:
            msg = f"User: {username}, Score: {points}"
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.RemoveStrFromFstring"

    @property
    def display_name(self) -> str:
        return "Strip ``str()`` from f-string placeholders"

    @property
    def description(self) -> str:
        return (
            "F-string placeholders convert values to strings automatically, "
            "so wrapping expressions in ``str()`` inside ``{...}`` is redundant."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_formatted_string_value(
                self, value: FormattedString.Value, p: ExecutionContext
            ) -> Optional[FormattedString.Value]:
                value = super().visit_formatted_string_value(value, p)
                if not isinstance(value, FormattedString.Value):
                    return value

                expr = value.expression
                if not isinstance(expr, MethodInvocation):
                    return value

                # Check for bare str() call (no select/receiver)
                if expr.select is not None:
                    return value

                # Check the method name is "str"
                if not isinstance(expr.name, Identifier):
                    return value
                if expr.name.simple_name != 'str':
                    return value

                # Must have exactly one real argument (not Empty)
                args = list(expr.arguments)
                if len(args) != 1 or isinstance(args[0], Empty):
                    return value

                # Replace with just the argument
                return value.with_expression(args[0])

        return Visitor()


@categorize(_Cleanup)
class StrPrefixSuffix(Recipe):
    """
    Use ``startswith``/``endswith`` instead of slicing to check string boundaries.

    Comparing a fixed-length slice of a string to a literal works, but it is
    less idiomatic than calling the purpose-built ``str.startswith()`` or
    ``str.endswith()`` methods.

    Example:
        Before:
            filename[:4] == ".env"
            filename[-5:] == ".yaml"

        After:
            filename.startswith(".env")
            filename.endswith(".yaml")
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.StrPrefixSuffix"

    @property
    def display_name(self) -> str:
        return "Prefer ``startswith``/``endswith`` over slice comparison"

    @property
    def description(self) -> str:
        return (
            "Rewrite ``s[:N] == \"lit\"`` as ``s.startswith(\"lit\")`` and "
            "``s[-N:] == \"lit\"`` as ``s.endswith(\"lit\")`` when the slice "
            "length equals the literal length."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_binary(
                self, binary: Binary, p: ExecutionContext
            ) -> Optional[Expression]:
                binary = super().visit_binary(binary, p)
                if not isinstance(binary, Binary):
                    return binary

                if binary.operator != Binary.Type.Equal:
                    return binary

                left = binary.left
                right = binary.right

                # Determine which side is the slice and which is the string
                slice_side: Optional[ArrayAccess] = None
                string_side: Optional[Expression] = None
                if isinstance(left, ArrayAccess) and isinstance(left.dimension.index, Slice):
                    slice_side = left
                    string_side = right
                elif isinstance(right, ArrayAccess) and isinstance(right.dimension.index, Slice):
                    slice_side = right
                    string_side = left

                if slice_side is None or string_side is None:
                    return binary

                str_len = _get_literal_string_len(string_side)
                if str_len is None:
                    return binary

                slc: Slice = slice_side.dimension.index
                indexed = slice_side.indexed

                # Case: name[:N] == "string" where N == len("string") -> startswith
                if slc.start is None and slc.stop is not None:
                    stop_val = _get_int_value(slc.stop)
                    if stop_val == str_len:
                        return _make_method_call(
                            binary.prefix, indexed, 'startswith', string_side
                        )

                # Case: name[-N:] == "string" where N == len("string") -> endswith
                if slc.start is not None and isinstance(slc.stop, Empty):
                    start_val = _get_int_value(slc.start)
                    if start_val is not None and start_val == -str_len:
                        return _make_method_call(
                            binary.prefix, indexed, 'endswith', string_side
                        )

                return binary

        return Visitor()


@categorize(_Cleanup)
class UseGetitemForReMatchGroups(Recipe):
    """
    Access regex match groups via bracket notation instead of ``.group()``.

    Since Python 3.6, ``re.Match`` objects support ``__getitem__``, so
    ``result[n]`` is equivalent to ``result.group(n)`` but shorter.

    Example:
        Before:
            hit.group(0)
            hit.group(2)

        After:
            hit[0]
            hit[2]
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.UseGetitemForReMatchGroups"

    @property
    def display_name(self) -> str:
        return "Use bracket access for ``re.Match`` groups"

    @property
    def description(self) -> str:
        return (
            "Replace ``match.group(n)`` with ``match[n]`` to use the "
            "shorter subscript syntax available since Python 3.6."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[Expression]:
                method = super().visit_method_invocation(method, p)
                if not isinstance(method, MethodInvocation):
                    return method

                # Pre-check: must be .group() with exactly one real argument
                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != 'group':
                    return method
                args = list(method.arguments)
                if len(args) != 1 or isinstance(args[0], Empty):
                    return method

                match = _group_pattern.match(method, self.cursor)
                if match:
                    return _group_template.apply(self.cursor, values=match)
                return method

        return Visitor()


def _can_inline_literal(value: FormattedString.Value) -> bool:
    """Check if a FormattedString.Value wraps a constant that can be inlined as text."""
    if value.conversion is not None or value.format is not None:
        return False
    expr = value.expression
    if not isinstance(expr, Literal):
        return False
    # Only inline numeric types (int, float) and strings
    if isinstance(expr.value, (int, float)):
        return True
    if isinstance(expr.value, str):
        return True
    return False


def _inline_literal_text(value: FormattedString.Value) -> str:
    """Get the text representation of an inlineable literal."""
    expr = value.expression
    if isinstance(expr.value, str):
        return expr.value
    return expr.value_source if expr.value_source else str(expr.value)


def _is_unwrappable_nested_fstring(value: FormattedString.Value) -> bool:
    """Check if a Value wraps a nested f-string that can be flattened."""
    if value.conversion is not None or value.format is not None:
        return False
    expr = value.expression
    return isinstance(expr, FormattedString)


@categorize(_Cleanup)
class SimplifyFstringFormatting(Recipe):
    """
    Reduce f-string clutter by folding constants and unwrapping nested f-strings.

    When a placeholder holds a compile-time constant (integer, float, or
    string literal), it can be written directly as text. Similarly, an
    f-string nested inside another f-string's placeholder can be flattened
    into the outer string.

    Example:
        Before:
            f"{10} items left"
            f"{f'{name.title()}'}"

        After:
            f"10 items left"
            f"{name.title()}"
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.SimplifyFstringFormatting"

    @property
    def display_name(self) -> str:
        return "Fold constants and flatten nested f-strings"

    @property
    def description(self) -> str:
        return (
            "Inline constant values directly into f-string text and "
            "unwrap nested f-strings into their enclosing string."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_formatted_string(
                self, fs: FormattedString, p: ExecutionContext
            ) -> Optional[Expression]:
                fs = super().visit_formatted_string(fs, p)
                if not isinstance(fs, FormattedString):
                    return fs

                # Check if any simplification is possible
                needs_simplification = False
                for part in fs.parts:
                    if isinstance(part, FormattedString.Value):
                        if _can_inline_literal(part):
                            needs_simplification = True
                            break
                        if _is_unwrappable_nested_fstring(part):
                            needs_simplification = True
                            break

                if not needs_simplification:
                    return fs

                # Build new parts list with simplifications applied
                new_parts: List[Expression] = []
                for part in fs.parts:
                    if isinstance(part, FormattedString.Value):
                        if _can_inline_literal(part):
                            # Inline the constant as a text Literal
                            text = _inline_literal_text(part)
                            lit = Literal(
                                _id=random_id(),
                                _prefix=Space.EMPTY,
                                _markers=Markers.EMPTY,
                                _value=text,
                                _value_source=text,
                                _unicode_escapes=None,
                                _type=None,
                            )
                            # Merge with previous Literal if possible
                            if new_parts and isinstance(new_parts[-1], Literal):
                                prev = new_parts[-1]
                                merged_value = (prev.value or '') + text
                                merged_source = (prev.value_source or '') + text
                                new_parts[-1] = Literal(
                                    _id=prev.id,
                                    _prefix=prev.prefix,
                                    _markers=prev.markers,
                                    _value=merged_value,
                                    _value_source=merged_source,
                                    _unicode_escapes=None,
                                    _type=None,
                                )
                            else:
                                new_parts.append(lit)
                        elif _is_unwrappable_nested_fstring(part):
                            # Flatten: replace outer Value with inner f-string's parts
                            inner_fs: FormattedString = part.expression
                            new_parts.extend(inner_fs.parts)
                        else:
                            new_parts.append(part)
                    else:
                        # Literal text part -- merge with previous if possible
                        if (new_parts and isinstance(new_parts[-1], Literal)
                                and isinstance(part, Literal)):
                            prev = new_parts[-1]
                            merged_value = (prev.value or '') + (part.value or '')
                            merged_source = (prev.value_source or '') + (part.value_source or '')
                            new_parts[-1] = Literal(
                                _id=prev.id,
                                _prefix=prev.prefix,
                                _markers=prev.markers,
                                _value=merged_value,
                                _value_source=merged_source,
                                _unicode_escapes=None,
                                _type=None,
                            )
                        else:
                            new_parts.append(part)

                return fs.replace(_parts=new_parts)

        return Visitor()


@categorize(_Cleanup)
class UseStringRemoveAffix(Recipe):
    """
    Replace string slicing after ``startswith``/``endswith`` with
    ``removeprefix``/``removesuffix`` (Python 3.9+).

    When an ``if`` block checks for a prefix or suffix and then slices
    the string to remove it, the code can be simplified to use the
    ``str.removeprefix()`` or ``str.removesuffix()`` methods.

    Example:
        Before:
            if text.startswith("Hello, "):
                text = text[7:]
            if text.endswith(" World!"):
                text = text[:-7]

        After:
            text = text.removeprefix("Hello, ")
            text = text.removesuffix(" World!")
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.UseStringRemoveAffix"

    @property
    def display_name(self) -> str:
        return "Replace string slicing with `removeprefix`/`removesuffix`"

    @property
    def description(self) -> str:
        return (
            "Replace `if text.startswith(s): text = text[N:]` with "
            "`text = text.removeprefix(s)` and the equivalent `endswith` "
            "pattern with `removesuffix` (Python 3.9+)."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_if(
                self, if_stmt: If, p: ExecutionContext
            ) -> Optional[Statement]:
                if_stmt = super().visit_if(if_stmt, p)
                if not isinstance(if_stmt, If):
                    return if_stmt

                # Must have no else branch
                if if_stmt.else_part is not None:
                    return if_stmt

                # Condition must be text.startswith("...") or text.endswith("...")
                cond = if_stmt.if_condition.tree
                if not isinstance(cond, MethodInvocation):
                    return if_stmt

                method_name = cond.name.simple_name
                if method_name not in ('startswith', 'endswith'):
                    return if_stmt

                select = cond.select
                if not isinstance(select, Identifier):
                    return if_stmt
                var_name = select.simple_name

                cond_args = list(cond.arguments)
                if len(cond_args) != 1 or isinstance(cond_args[0], Empty):
                    return if_stmt
                affix_lit = cond_args[0]

                # Get the string length of the affix
                affix_len = _get_literal_string_len(affix_lit)
                if affix_len is None:
                    return if_stmt

                # Body must be a Block with exactly one statement
                body = if_stmt.then_part
                if not isinstance(body, Block):
                    return if_stmt
                stmts = body.statements
                if len(stmts) != 1:
                    return if_stmt

                stmt = stmts[0]
                if not isinstance(stmt, Assignment):
                    return if_stmt

                # LHS must be the same variable
                if not isinstance(stmt.variable, Identifier):
                    return if_stmt
                if stmt.variable.simple_name != var_name:
                    return if_stmt

                # RHS must be var_name[slice]
                rhs = stmt.assignment
                if not isinstance(rhs, ArrayAccess):
                    return if_stmt
                if not isinstance(rhs.indexed, Identifier):
                    return if_stmt
                if rhs.indexed.simple_name != var_name:
                    return if_stmt

                slc_idx = rhs.dimension.index
                if not isinstance(slc_idx, Slice):
                    return if_stmt

                # Validate the slice matches the affix operation
                if method_name == 'startswith':
                    # text = text[N:] where N == len(affix)
                    if slc_idx.start is None:
                        return if_stmt
                    start_val = _get_int_value(slc_idx.start)
                    if start_val != affix_len:
                        return if_stmt
                    # stop must be absent (Empty) or None
                    if slc_idx.stop is not None and not isinstance(slc_idx.stop, Empty):
                        return if_stmt
                    remove_method = 'removeprefix'
                elif method_name == 'endswith':
                    # text = text[:-N] where N == len(affix)
                    if slc_idx.start is not None:
                        return if_stmt
                    if slc_idx.stop is None:
                        return if_stmt
                    stop_val = _get_int_value(slc_idx.stop)
                    if stop_val is None or stop_val != -affix_len:
                        return if_stmt
                    remove_method = 'removesuffix'
                else:
                    return if_stmt

                # Build: var_name = var_name.remove{prefix,suffix}(affix_lit)
                return _make_remove_affix_assignment(
                    if_stmt.prefix, var_name, remove_method, affix_lit,
                )

        return Visitor()


def _make_remove_affix_assignment(
    prefix: Space,
    var_name: str,
    method_name: str,
    affix_lit: Expression,
) -> Assignment:
    """Build ``var = var.removeprefix/removesuffix(affix)``."""
    lhs = Identifier(
        _id=random_id(),
        _prefix=Space.EMPTY,
        _markers=Markers.EMPTY,
        _annotations=[],
        _simple_name=var_name,
        _type=None,
        _field_type=None,
    )
    target = Identifier(
        _id=random_id(),
        _prefix=Space.EMPTY,
        _markers=Markers.EMPTY,
        _annotations=[],
        _simple_name=var_name,
        _type=None,
        _field_type=None,
    )
    name_id = Identifier(
        _id=random_id(),
        _prefix=Space.EMPTY,
        _markers=Markers.EMPTY,
        _annotations=[],
        _simple_name=method_name,
        _type=None,
        _field_type=None,
    )
    call = MethodInvocation(
        _id=random_id(),
        _prefix=Space.SINGLE_SPACE,
        _markers=Markers.EMPTY,
        _select=JRightPadded(
            _element=target,
            _after=Space.EMPTY,
            _markers=Markers.EMPTY,
        ),
        _type_parameters=None,
        _name=name_id,
        _arguments=JContainer(
            _before=Space.EMPTY,
            _elements=[JRightPadded(
                _element=affix_lit.replace(_prefix=Space.EMPTY),
                _after=Space.EMPTY,
                _markers=Markers.EMPTY,
            )],
            _markers=Markers.EMPTY,
        ),
        _method_type=None,
    )
    return Assignment(
        _id=random_id(),
        _prefix=prefix,
        _markers=Markers.EMPTY,
        _variable=lhs,
        _assignment=JLeftPadded(
            _before=Space.SINGLE_SPACE,
            _element=call,
            _markers=Markers.EMPTY,
        ),
        _type=None,
    )
