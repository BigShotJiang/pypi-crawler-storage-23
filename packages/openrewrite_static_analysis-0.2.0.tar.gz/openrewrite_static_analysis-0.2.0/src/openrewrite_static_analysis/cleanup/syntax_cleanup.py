"""
Recipes for removing syntactically invalid or misplaced statements.

- BreakOrContinueOutsideLoop: Remove break/continue that are not inside any loop.
- ReturnOrYieldOutsideFunction: Remove return/yield that are not inside any function.
"""

from typing import Any, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import (
    Break, Continue, ForEachLoop, MethodDeclaration, Return, WhileLoop, Yield,
)

# Define category path: Python > Cleanup
_Cleanup = [*Python, CategoryDescriptor(display_name="Cleanup")]


def _has_enclosing_loop(cursor) -> bool:
    """Check if the cursor has an enclosing for or while loop."""
    loop = cursor.first_enclosing(ForEachLoop)
    if loop is not None:
        return True
    loop = cursor.first_enclosing(WhileLoop)
    return loop is not None


def _has_enclosing_function(cursor) -> bool:
    """Check if the cursor has an enclosing function/method declaration."""
    func = cursor.first_enclosing(MethodDeclaration)
    return func is not None


@categorize(_Cleanup)
class BreakOrContinueOutsideLoop(Recipe):
    """
    Remove break and continue statements that are not inside any loop.

    A `break` or `continue` statement outside of a for or while loop is
    a syntax error in Python. This recipe removes such misplaced statements.

    Example:
        Before:
            def handle(numbers):
                for number in numbers:
                    if is_valid(number):
                        continue
                break
                handle(number)

        After:
            def handle(numbers):
                for number in numbers:
                    if is_valid(number):
                        continue
                handle(number)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.BreakOrContinueOutsideLoop"

    @property
    def display_name(self) -> str:
        return "Remove `break`/`continue` outside loop"

    @property
    def description(self) -> str:
        return (
            "Remove `break` and `continue` statements that are not inside "
            "any for or while loop."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_break(
                self, break_: Break, p: ExecutionContext
            ) -> Optional[Break]:
                break_ = super().visit_break(break_, p)
                if break_ is None:
                    return None
                if not _has_enclosing_loop(self.cursor):
                    return None
                return break_

            def visit_continue(
                self, continue_: Continue, p: ExecutionContext
            ) -> Optional[Continue]:
                continue_ = super().visit_continue(continue_, p)
                if continue_ is None:
                    return None
                if not _has_enclosing_loop(self.cursor):
                    return None
                return continue_

        return Visitor()


@categorize(_Cleanup)
class ReturnOrYieldOutsideFunction(Recipe):
    """
    Remove return and yield statements that are not inside any function or method.

    A `return` or `yield` statement outside of a function/method definition is
    a syntax error in Python. This recipe removes such misplaced statements.

    Example:
        Before:
            for i in range(10):
                print(i)
                return i

        After:
            for i in range(10):
                print(i)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.ReturnOrYieldOutsideFunction"

    @property
    def display_name(self) -> str:
        return "Remove `return`/`yield` outside function"

    @property
    def description(self) -> str:
        return (
            "Remove `return` and `yield` statements that are not inside "
            "any function or method definition."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_return(
                self, return_: Return, p: ExecutionContext
            ) -> Optional[Return]:
                return_ = super().visit_return(return_, p)
                if return_ is None:
                    return None
                if not _has_enclosing_function(self.cursor):
                    return None
                return return_

            def visit_yield(
                self, yield_: Yield, p: ExecutionContext
            ) -> Optional[Yield]:
                yield_ = super().visit_yield(yield_, p)
                if yield_ is None:
                    return None
                if not _has_enclosing_function(self.cursor):
                    return None
                return yield_

        return Visitor()
