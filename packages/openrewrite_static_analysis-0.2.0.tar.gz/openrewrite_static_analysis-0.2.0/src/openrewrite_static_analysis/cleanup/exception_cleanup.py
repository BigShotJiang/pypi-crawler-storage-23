"""
Recipes that improve exception handling hygiene.

- Narrow bare ``except:`` to ``except Exception:`` so system-exiting exceptions
  are not accidentally swallowed.
- Unwrap one-element exception tuples like ``except (KeyError,):`` into the plain
  form ``except KeyError:``.
- Chain re-raised exceptions with ``from`` to preserve the original traceback.
- Replace ``try/except: pass`` with ``contextlib.suppress()`` for explicit intent.
"""

from typing import Any, List, Optional
from uuid import uuid4

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.python.tree import (
    CollectionLiteral,
    ErrorFrom,
    ExceptionType,
    ExpressionTypeTree,
    Pass,
    TrailingElseWrapper,
)
from rewrite.python import maybe_add_import, AddImportOptions
from rewrite.python.template import template, capture
from rewrite.java.tree import (
    Empty,
    Identifier,
    JLeftPadded,
    JRightPadded,
    Markers,
    Space,
    Throw,
    Try,
)

# Define category path: Python > Cleanup
_Cleanup = [*Python, CategoryDescriptor(display_name="Cleanup")]


@categorize(_Cleanup)
class DoNotUseBareExcept(Recipe):
    """
    Narrow bare ``except:`` to ``except Exception:`` for safer error handling.

    An unqualified ``except:`` intercepts every exception class, including
    ``SystemExit`` and ``KeyboardInterrupt``. This is rarely desirable.
    Specifying ``Exception`` limits the handler to ordinary runtime errors
    while letting control-flow exceptions propagate normally.

    Example:
        Before:
            try:
                perform_update()
            except:
                rollback()

        After:
            try:
                perform_update()
            except Exception:
                rollback()
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.DoNotUseBareExcept"

    @property
    def display_name(self) -> str:
        return "Narrow bare `except:` to `except Exception:`"

    @property
    def description(self) -> str:
        return (
            "An unqualified `except:` intercepts every exception, including "
            "`SystemExit` and `KeyboardInterrupt`. Specifying `Exception` "
            "restricts the handler to ordinary runtime errors."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_catch(
                self, catch: Try.Catch, p: ExecutionContext
            ) -> Optional[Try.Catch]:
                catch = super().visit_catch(catch, p)

                vd = catch.parameter.tree
                te = vd.type_expression
                if not isinstance(te, ExceptionType):
                    return catch
                if not isinstance(te.expression, Empty):
                    return catch

                # Skip if the body contains a bare raise — this is a
                # catch-and-reraise pattern.  Narrowing to except Exception:
                # would silently swallow BaseException subclasses
                # (KeyboardInterrupt, SystemExit) that the code re-raises.
                for stmt_padded in catch.body._statements:
                    stmt = stmt_padded.element
                    if isinstance(stmt, Throw) and isinstance(stmt.exception, Empty):
                        return catch

                # Build an Identifier for "Exception"
                exception_ident = Identifier(
                    _id=uuid4(),
                    _prefix=Space([], ''),
                    _markers=Markers.EMPTY,
                    _annotations=[],
                    _simple_name='Exception',
                    _type=None,
                    _field_type=None,
                )

                # Replace the Empty expression with the Exception identifier
                new_te = te.replace(_expression=exception_ident)

                # Add a space before the type expression so the output is
                # "except Exception:" rather than "exceptException:"
                new_vd = vd.replace(
                    _type_expression=new_te,
                    _prefix=Space([], ' '),
                )

                # Update the catch parameter
                new_param = catch.parameter.padding.replace(
                    _tree=catch.parameter.padding.tree.replace(
                        _element=new_vd,
                    ),
                )

                return catch.replace(_parameter=new_param)

        return Visitor()


@categorize(_Cleanup)
class SimplifySingleExceptionTuple(Recipe):
    """
    Unwrap single-element exception tuples into the plain exception type.

    Wrapping a single exception class in a tuple adds visual noise without
    changing behavior. Removing the parentheses produces cleaner code.

    Example:
        Before:
            try:
                connect(host)
            except (ConnectionError,) as err:
                retry(err)

        After:
            try:
                connect(host)
            except ConnectionError as err:
                retry(err)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.SimplifySingleExceptionTuple"

    @property
    def display_name(self) -> str:
        return "Unwrap one-element exception tuple in `except`"

    @property
    def description(self) -> str:
        return (
            "A tuple containing only one exception type is needlessly verbose. "
            "This unwraps it to the plain `except ExcType:` form."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_catch(
                self, catch: Try.Catch, p: ExecutionContext
            ) -> Optional[Try.Catch]:
                catch = super().visit_catch(catch, p)

                vd = catch.parameter.tree
                te = vd.type_expression
                if not isinstance(te, ExceptionType):
                    return catch

                expr = te.expression
                if not isinstance(expr, ExpressionTypeTree):
                    return catch

                ref = expr.reference
                if not isinstance(ref, CollectionLiteral):
                    return catch
                if ref.kind != CollectionLiteral.Kind.TUPLE:
                    return catch
                if len(ref.elements) != 1:
                    return catch

                # Unwrap the single element from the tuple
                single_element = ref.elements[0]

                # Replace the ExpressionTypeTree wrapping the tuple
                # with just the single element identifier
                new_te = te.replace(_expression=single_element)

                new_vd = vd.replace(_type_expression=new_te)

                new_param = catch.parameter.padding.replace(
                    _tree=catch.parameter.padding.tree.replace(
                        _element=new_vd,
                    ),
                )

                return catch.replace(_parameter=new_param)

        return Visitor()


@categorize(_Cleanup)
class RaiseFromPreviousError(Recipe):
    """
    Chain re-raised exceptions with ``from`` to keep the original traceback.

    When a new exception is raised inside an ``except`` block, attaching
    ``from <caught>`` creates an explicit exception chain. This makes
    debugging easier by preserving the causal relationship between errors.

    Example:
        Before:
            try:
                parse(raw_data)
            except json.JSONDecodeError:
                raise ConfigError("invalid config file")

        After:
            try:
                parse(raw_data)
            except json.JSONDecodeError as e:
                raise ConfigError("invalid config file") from e
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.RaiseFromPreviousError"

    @property
    def display_name(self) -> str:
        return "Chain exceptions with `raise ... from` in except blocks"

    @property
    def description(self) -> str:
        return (
            "Raise statements inside except blocks should use `from` to chain "
            "the new exception to the caught one, preserving the full traceback."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        _CATCH_VAR_NAME = "RAISE_FROM_CATCH_VAR_NAME"

        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_catch(
                self, catch: Try.Catch, p: ExecutionContext
            ) -> Optional[Try.Catch]:
                vd = catch.parameter.tree
                te = vd.type_expression

                # Skip bare except (no type expression)
                if isinstance(te, ExceptionType) and isinstance(te.expression, Empty):
                    return super().visit_catch(catch, p)

                # Determine if we have an 'as' variable
                var = vd.variables[0] if vd.variables else None
                var_name = var.name.simple_name if var else ''

                # Check if there are raise statements that need from
                has_raise_needing_from = False
                for stmt_padded in catch.body._statements:
                    stmt = stmt_padded.element
                    if isinstance(stmt, Throw):
                        # Skip bare raise and raise ... from ...
                        if isinstance(stmt.exception, Empty):
                            continue
                        if isinstance(stmt.exception, ErrorFrom):
                            continue
                        has_raise_needing_from = True
                        break

                if not has_raise_needing_from:
                    return super().visit_catch(catch, p)

                # If no 'as' variable, add one
                if not var_name:
                    var_name = 'e'
                    new_name_ident = Identifier(
                        _id=uuid4(),
                        _prefix=Space([], ' '),
                        _markers=Markers.EMPTY,
                        _annotations=[],
                        _simple_name='e',
                        _type=None,
                        _field_type=None,
                    )
                    from rewrite.java.tree import VariableDeclarations
                    new_var = VariableDeclarations.NamedVariable(
                        _id=uuid4(),
                        _prefix=Space([], ''),
                        _markers=Markers.EMPTY,
                        _name=new_name_ident,
                        _dimensions_after_name=[],
                        _initializer=None,
                        _variable_type=None,
                    )
                    new_vd = vd.replace(
                        _variables=[JRightPadded(new_var, Space([], ' '), Markers.EMPTY)],
                    )
                    new_param = catch.parameter.padding.replace(
                        _tree=catch.parameter.padding.tree.replace(
                            _element=new_vd,
                        ),
                    )
                    catch = catch.replace(_parameter=new_param)

                # Store the var name on the cursor for visit_throw to use
                self.cursor.put_message(_CATCH_VAR_NAME, var_name)

                # Now visit the catch body to add 'from e' to raises
                catch = super().visit_catch(catch, p)
                return catch

            def visit_throw(
                self, throw: Throw, p: ExecutionContext
            ) -> Optional[Throw]:
                throw = super().visit_throw(throw, p)

                # Skip bare raise
                if isinstance(throw.exception, Empty):
                    return throw

                # Skip if already has 'from'
                if isinstance(throw.exception, ErrorFrom):
                    return throw

                # Get variable name from the catch cursor message
                var_name = self.cursor.get_nearest_message(_CATCH_VAR_NAME)
                if not var_name:
                    return throw

                # Skip if re-raising the same exception variable (e.g., `raise e`)
                exc = throw.exception
                if isinstance(exc, Identifier) and exc.simple_name == var_name:
                    return throw

                # Create ErrorFrom wrapping the raise expression
                from_ident = Identifier(
                    _id=uuid4(),
                    _prefix=Space([], ' '),
                    _markers=Markers.EMPTY,
                    _annotations=[],
                    _simple_name=var_name,
                    _type=None,
                    _field_type=None,
                )

                error_from = ErrorFrom(
                    _id=uuid4(),
                    _prefix=throw.exception.prefix,
                    _markers=Markers.EMPTY,
                    _error=throw.exception.replace(_prefix=Space([], '')),
                    _from=JLeftPadded(
                        Space([], ' '),
                        from_ident,
                        Markers.EMPTY,
                    ),
                    _type=None,
                )

                return throw.replace(_exception=error_from)

        return Visitor()


# Template for contextlib.suppress
_suppress_exc = capture('exc')
_suppress_body = capture('body')
_suppress_template = template(
    'with contextlib.suppress({exc}):\n    {body}',
    exc=_suppress_exc,
    body=_suppress_body,
)


@categorize(_Cleanup)
class UseContextlibSuppress(Recipe):
    """
    Use ``contextlib.suppress()`` instead of ``try/except: pass``.

    An except handler that only contains ``pass`` is silently swallowing
    the exception. Replacing it with ``contextlib.suppress()`` makes the
    suppression explicit and reduces nesting.

    Example:
        Before:
            try:
                remove_temp_file(path)
            except OSError:
                pass

        After:
            import contextlib
            with contextlib.suppress(OSError):
                remove_temp_file(path)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.UseContextlibSuppress"

    @property
    def display_name(self) -> str:
        return "Replace `try/except: pass` with `contextlib.suppress()`"

    @property
    def description(self) -> str:
        return (
            "When an except handler only contains `pass`, the intent is to "
            "suppress the error. `contextlib.suppress()` states this explicitly "
            "and eliminates the try/except boilerplate."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_try(
                self, try_stmt: Try, p: ExecutionContext
            ) -> Optional[Try]:
                try_stmt = super().visit_try(try_stmt, p)

                # Only handle single except clause
                if len(try_stmt.catches) != 1:
                    return try_stmt

                # Skip if there's a finally block
                if try_stmt.finally_ is not None:
                    return try_stmt

                # Skip if try has an else clause (wrapped in TrailingElseWrapper)
                parent = self.cursor.parent
                if parent is not None and isinstance(parent.value, TrailingElseWrapper):
                    return try_stmt

                catch = try_stmt.catches[0]

                # Only handle if except body is just 'pass'
                if len(catch.body.statements) != 1:
                    return try_stmt
                if not isinstance(catch.body.statements[0], Pass):
                    return try_stmt

                # Get exception type
                vd = catch.parameter.tree
                te = vd.type_expression
                if te is None:
                    return try_stmt
                if isinstance(te, ExceptionType):
                    if isinstance(te.expression, Empty):
                        # Bare except -- don't transform
                        return try_stmt
                    if te.exception_group:
                        # except* (ExceptionGroup) -- contextlib.suppress doesn't handle these
                        return try_stmt
                    exc_expr = te.expression
                    # Tuple exception types like (ValueError, TypeError) can't
                    # be passed directly — contextlib.suppress takes *args.
                    if isinstance(exc_expr, ExpressionTypeTree):
                        return try_stmt
                else:
                    exc_expr = te

                # Only handle single-statement try bodies
                body_stmts = try_stmt.body.statements
                if len(body_stmts) != 1:
                    return try_stmt

                body_stmt = body_stmts[0]

                values = {
                    'exc': exc_expr,
                    'body': body_stmt,
                }

                maybe_add_import(
                    self,
                    AddImportOptions(module='contextlib', only_if_referenced=False),
                )
                return _suppress_template.apply(self.cursor, values=values)

        return Visitor()
