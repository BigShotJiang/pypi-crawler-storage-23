"""
Recipes that strip unnecessary arguments from ``range()`` calls.

- range(0, n) can be shortened to range(n) because 0 is already the implicit start
- range(a, b, 1) can be shortened to range(a, b) because 1 is already the implicit step
"""

from typing import Any, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.python.template import pattern, template, capture
from rewrite.java.tree import MethodInvocation

_Cleanup = [*Python, CategoryDescriptor(display_name="Cleanup")]

# Pattern/template for range(0, x) -> range(x)
_x = capture('x')
_range_zero_pattern = pattern("range(0, {x})", x=_x)
_range_zero_template = template("range({x})", x=_x)

# Pattern/template for range(x, y, 1) -> range(x, y)
_rx = capture('rx')
_ry = capture('ry')
_range_step_pattern = pattern("range({rx}, {ry}, 1)", rx=_rx, ry=_ry)
_range_step_template = template("range({rx}, {ry})", rx=_rx, ry=_ry)


@categorize(_Cleanup)
class RemoveZeroFromRange(Recipe):
    """
    Drop the explicit zero start argument from ``range(0, n)``.

    Because ``range()`` already starts at 0 when only one positional argument
    is given, writing ``range(0, n)`` is needlessly verbose. This recipe
    shortens it to ``range(n)``.

    Example:
        Before:
            indices = range(0, 50)

        After:
            indices = range(50)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.RemoveZeroFromRange"

    @property
    def display_name(self) -> str:
        return "Drop unnecessary `0` start argument from `range()`"

    @property
    def description(self) -> str:
        return (
            "Shorten `range(0, n)` to `range(n)` because `range` already defaults to starting at zero."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)
                match = _range_zero_pattern.match(method, self.cursor)
                if match:
                    return _range_zero_template.apply(self.cursor, values=match)
                return method

        return Visitor()


@categorize(_Cleanup)
class RemoveUnitStepFromRange(Recipe):
    """
    Drop the explicit step-of-one argument from ``range(a, b, 1)``.

    The ``range()`` built-in increments by 1 when no step is specified,
    so passing ``1`` as the third argument adds no information. This recipe
    removes it, leaving ``range(a, b)``.

    Example:
        Before:
            values = range(5, 25, 1)

        After:
            values = range(5, 25)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.RemoveUnitStepFromRange"

    @property
    def display_name(self) -> str:
        return "Drop unnecessary step `1` argument from `range()`"

    @property
    def description(self) -> str:
        return (
            "Shorten `range(a, b, 1)` to `range(a, b)` because `range` already defaults to a step of one."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)
                match = _range_step_pattern.match(method, self.cursor)
                if match:
                    return _range_step_template.apply(self.cursor, values=match)
                return method

        return Visitor()
