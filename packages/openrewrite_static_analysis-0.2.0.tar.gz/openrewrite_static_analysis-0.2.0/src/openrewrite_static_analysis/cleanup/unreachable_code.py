"""
Recipes that eliminate dead code and no-op statements.

- Bare ``assert True`` is always a no-op and can be deleted.
- Code that follows a ``return``, ``raise``, ``continue``, or ``break`` never executes and should be trimmed.
- ``for`` loops and ``if`` blocks whose body is nothing but ``pass`` have no side effects and can be deleted.

See: https://docs.python.org/3/reference/simple_stmts.html#the-assert-statement
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.python import tree as py_tree
from rewrite.java.tree import Assert, Block, Break, Continue, If, Literal, Return, Throw, Yield
from rewrite.python.tree import StatementExpression, YieldFrom

# Define category path: Python > Cleanup
_Cleanup = [*Python, CategoryDescriptor(display_name="Cleanup")]


@categorize(_Cleanup)
class RemoveAssertTrue(Recipe):
    """
    Delete ``assert True`` statements that have no runtime effect.

    Because the condition is always satisfied, a bare ``assert True`` is
    dead weight. Removing it reduces noise and makes the surrounding code
    easier to follow.

    Assertions that include a message string (e.g., ``assert True, "note"``)
    are kept, as the message may serve a documentation purpose.

    Example:
        Before:
            count = 0
            assert True
            count += 1

        After:
            count = 0
            count += 1
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.RemoveAssertTrue"

    @property
    def display_name(self) -> str:
        return "Delete no-op `assert True` statements"

    @property
    def description(self) -> str:
        return (
            "Delete bare `assert True` statements, which are always satisfied and have "
            "no effect. Assertions that carry a message string are preserved."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_assert(
                self, assert_: Assert, p: ExecutionContext
            ) -> Optional[Assert]:
                assert_ = super().visit_assert(assert_, p)

                # Only remove bare `assert True` (no message)
                if assert_.detail is not None:
                    return assert_

                condition = assert_.condition
                if not isinstance(condition, Literal):
                    return assert_

                if condition.value is not True:
                    return assert_

                # Remove the statement by returning None
                return None

        return Visitor()


def _is_terminal(stmt) -> bool:
    """Check if a statement is a terminal statement (return, raise, continue, break)."""
    return isinstance(stmt, (Return, Throw, Continue, Break))


def _contains_yield(node) -> bool:
    """Recursively check if a tree node contains any Yield or YieldFrom."""
    if isinstance(node, Yield):
        return True
    if isinstance(node, YieldFrom):
        return True
    if isinstance(node, StatementExpression):
        return _contains_yield(node.statement)
    if isinstance(node, Block):
        return any(_contains_yield(s) for s in node.statements)
    if isinstance(node, If):
        if _contains_yield(node.then_part):
            return True
        if node.else_part is not None and _contains_yield(node.else_part.body):
            return True
    return False


@categorize(_Cleanup)
class RemoveUnreachableCode(Recipe):
    """
    Trim statements that follow a ``return``, ``raise``, ``continue``, or ``break``.

    Once a terminal statement executes, control leaves the current block, so
    any subsequent statements in that same block can never run. This recipe
    strips those dead statements.

    Example:
        Before:
            for item in collection:
                process(item)
                break
                cleanup(item)
                log(item)

        After:
            for item in collection:
                process(item)
                break
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.RemoveUnreachableCode"

    @property
    def display_name(self) -> str:
        return "Strip dead code after terminal statements"

    @property
    def description(self) -> str:
        return (
            "Delete statements that follow a `return`, `raise`, `continue`, or `break` "
            "in the same block, since they can never execute."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_block(
                self, block: Block, p: ExecutionContext
            ) -> Block:
                block = super().visit_block(block, p)

                stmts = block.statements
                if not stmts:
                    return block

                # Find the first terminal statement
                terminal_idx = None
                for i, stmt in enumerate(stmts):
                    if _is_terminal(stmt):
                        terminal_idx = i
                        break

                # If no terminal found, or terminal is last, nothing to do
                if terminal_idx is None or terminal_idx == len(stmts) - 1:
                    return block

                # Don't remove unreachable code if any of it contains a
                # yield/yield-from — yield makes the enclosing function a
                # generator even when unreachable, so removing it changes the
                # function's return type.  Check recursively since yield may
                # be inside nested blocks (if, for, etc.).
                for stmt in stmts[terminal_idx + 1:]:
                    if _contains_yield(stmt):
                        return block

                # Get the raw padded statements and slice them too
                padded_stmts = block._statements[:terminal_idx + 1]
                return block.replace(_statements=padded_stmts)

        return Visitor()


@categorize(_Cleanup)
class RemoveEmptyNestedBlock(Recipe):
    """
    Delete ``if`` statements that contain only ``pass`` (with no ``else``).

    When the entire body of an ``if`` block is a single ``pass`` statement
    and there is no ``else`` branch, the block does nothing and is safe to
    remove.

    ``for`` and ``while`` loops with ``pass``-only bodies are **not**
    removed because iterating over the iterable may have side effects
    (e.g., consuming a progress bar or generator).

    Example:
        Before:
            if stale:
                pass

        After:
            # (entire block deleted)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.RemoveEmptyNestedBlock"

    @property
    def display_name(self) -> str:
        return "Delete `if` blocks whose body is only `pass`"

    @property
    def description(self) -> str:
        return (
            "Delete `if` statements that contain nothing but `pass` and have no "
            "`else` branch. `for`/`while` loops are left alone because iterating "
            "may have side effects."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def _body_is_only_pass(self, body) -> bool:
                """Check if a body block contains only a single pass statement."""
                if not isinstance(body, Block):
                    return isinstance(body, py_tree.Pass)
                stmts = body.statements
                return len(stmts) == 1 and isinstance(stmts[0], py_tree.Pass)

            def visit_if(
                self, if_: If, p: ExecutionContext
            ) -> Optional[If]:
                if_ = super().visit_if(if_, p)
                if if_ is None:
                    return None

                # Don't remove if it has an else branch
                if if_.else_part is not None:
                    return if_

                # Check if body is only pass
                if self._body_is_only_pass(if_.then_part):
                    return None

                return if_

        return Visitor()
