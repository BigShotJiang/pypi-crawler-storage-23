"""
Recipes that simplify comprehension and generator expression patterns.

- ``CollectionBuiltinToComprehension``: Turn ``list(expr for ...)`` into ``[expr for ...]``
  and ``set(expr for ...)`` into ``{expr for ...}``.
- ``SimplifyGenerator``: Reduce ``any(v for v in seq)`` / ``all(v for v in seq)``
  to ``any(seq)`` / ``all(seq)``.
- ``ComprehensionToGenerator``: Drop unneeded list brackets inside calls like
  ``any([...])``, ``sum([...])``, etc.
- ``IdentityComprehension``: Replace ``[v for v in seq]`` with ``list(seq)``
  and ``{v for v in seq}`` with ``set(seq)``.
- ``InvertAnyAll``: Swap ``not all(cond ...)`` to ``any(negated_cond ...)`` and vice versa.
- ``InvertAnyAllBody``: Apply De Morgan's law to simplify ``any(not v for v in seq)``
  into ``not all(seq)`` and the mirror case.
- ``ConvertAnyToIn``: Rewrite ``any(v == lit for v in seq)`` as ``lit in seq``.
- ``SimplifyConstantSum``: Transform ``sum(1 for v in seq if cond)`` into
  ``sum(bool(cond) for v in seq)``.

Comprehension syntax is preferred over wrapping generators in ``list()``/``set()``,
and identity generators passed to aggregation functions like ``any()``/``all()``
can typically be replaced by passing the iterable directly.
"""

from typing import Any, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.python.tree import ComprehensionExpression
from rewrite.python.template import template, capture
from rewrite.python.template.pattern import MatchResult
from rewrite.java.markers import OmitParentheses
from rewrite.java.tree import (
    Binary as JBinary, Identifier, JContainer, Literal,
    MethodInvocation, Unary,
)

_Cleanup = [*Python, CategoryDescriptor(display_name="Cleanup")]

# Mapping from builtin function names to comprehension kinds
_BUILTIN_TO_KIND = {
    'list': ComprehensionExpression.Kind.LIST,
    'set': ComprehensionExpression.Kind.SET,
}

# Builtin functions where identity generators can be simplified
_IDENTITY_FUNCS = {'any', 'all'}

# Functions that accept a generator where a list comprehension is unnecessary
_GENERATOR_ACCEPTING_FUNCS = {'any', 'all', 'sum', 'min', 'max', 'sorted', 'tuple', 'frozenset'}

# Operator negation map for InvertAnyAll
_NEGATE_OP = {
    JBinary.Type.Equal: JBinary.Type.NotEqual,
    JBinary.Type.NotEqual: JBinary.Type.Equal,
    JBinary.Type.LessThan: JBinary.Type.GreaterThanOrEqual,
    JBinary.Type.GreaterThan: JBinary.Type.LessThanOrEqual,
    JBinary.Type.LessThanOrEqual: JBinary.Type.GreaterThan,
    JBinary.Type.GreaterThanOrEqual: JBinary.Type.LessThan,
}

# Templates for IdentityComprehension
_coll_capture = capture('coll')
_list_template = template('list({coll})', coll=_coll_capture)
_set_template = template('set({coll})', coll=_coll_capture)

# Templates for ConvertAnyToIn
_lit_capture = capture('lit')
_coll_capture2 = capture('coll')
_in_template = template('{lit} in {coll}', lit=_lit_capture, coll=_coll_capture2)

# Templates for InvertAnyAllBody
_not_inner_capture = capture('inner')
_not_template = template('not {inner}', inner=_not_inner_capture)

# Templates for SimplifyConstantSum
_x_capture = capture('x')
_bool_template = template('bool({x})', x=_x_capture)


@categorize(_Cleanup)
class CollectionBuiltinToComprehension(Recipe):
    """
    Convert ``list()``/``set()`` wrapping a generator into native comprehension syntax.

    Writing ``[expr for ...]`` or ``{expr for ...}`` is the idiomatic way to
    build a list or set from a generator expression in Python, and it avoids
    the overhead of a function call around the generator.

    Example:
        Before:
            doubled = list(n * 2 for n in values)

        After:
            doubled = [n * 2 for n in values]
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.CollectionBuiltinToComprehension"

    @property
    def display_name(self) -> str:
        return "Use comprehension syntax instead of `list()`/`set()` around generators"

    @property
    def description(self) -> str:
        return (
            "Wrapping a generator in `list()` or `set()` is less idiomatic "
            "than the equivalent bracket/brace comprehension syntax."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                # Only match bare builtin calls (no select/receiver)
                if method.select is not None:
                    return method

                if not isinstance(method.name, Identifier):
                    return method

                func_name = method.name.simple_name
                if func_name not in _BUILTIN_TO_KIND:
                    return method

                args = method.arguments
                if len(args) != 1 or not isinstance(args[0], ComprehensionExpression):
                    return method

                gen = args[0]
                if gen.kind != ComprehensionExpression.Kind.GENERATOR:
                    return method

                # Transform generator expression into the corresponding comprehension
                return gen.replace(
                    _kind=_BUILTIN_TO_KIND[func_name],
                    _prefix=method.prefix,
                )

        return Visitor()


@categorize(_Cleanup)
class SimplifyGenerator(Recipe):
    """
    Remove pass-through generators in ``any()`` and ``all()`` calls.

    A generator that yields each element unchanged (e.g. ``any(v for v in seq)``)
    adds no transformation, so the iterable can be passed directly to the
    aggregation function.

    Example:
        Before:
            found = any(elem for elem in candidates)

        After:
            found = any(candidates)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.SimplifyGenerator"

    @property
    def display_name(self) -> str:
        return "Pass iterable directly to `any()`/`all()` instead of identity generator"

    @property
    def description(self) -> str:
        return (
            "An identity generator that yields every element unchanged is "
            "redundant inside `any()` or `all()` -- pass the collection directly."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                # Only match bare builtin calls (no select/receiver)
                if method.select is not None:
                    return method

                if not isinstance(method.name, Identifier):
                    return method

                func_name = method.name.simple_name
                if func_name not in _IDENTITY_FUNCS:
                    return method

                args = method.arguments
                if len(args) != 1 or not isinstance(args[0], ComprehensionExpression):
                    return method

                gen = args[0]
                if gen.kind != ComprehensionExpression.Kind.GENERATOR:
                    return method

                # Must have exactly one clause with no conditions
                if len(gen.clauses) != 1:
                    return method
                clause = gen.clauses[0]
                if clause.conditions:
                    return method

                # Check identity: result must be the same identifier as
                # the iterator variable
                result = gen.result
                iter_var = clause.iterator_variable
                if not isinstance(result, Identifier) or not isinstance(iter_var, Identifier):
                    return method
                if result.simple_name != iter_var.simple_name:
                    return method

                # Replace arguments with just the iterated collection
                coll = clause.iterated_list
                new_args = JContainer.build_nullable(
                    method.padding.arguments,
                    [coll.replace(_prefix=gen.prefix)],
                )
                return method.replace(_arguments=new_args)

        return Visitor()


def _is_bare_builtin(method: MethodInvocation, names: set) -> bool:
    """Check if method is a bare builtin call (no receiver) with a name in `names`."""
    if method.select is not None:
        return False
    if not isinstance(method.name, Identifier):
        return False
    return method.name.simple_name in names


def _get_single_generator(method: MethodInvocation) -> Optional[ComprehensionExpression]:
    """Return the single generator argument if there is exactly one, else None."""
    args = method.arguments
    if len(args) != 1 or not isinstance(args[0], ComprehensionExpression):
        return None
    gen = args[0]
    if gen.kind != ComprehensionExpression.Kind.GENERATOR:
        return None
    return gen


def _get_single_list_comp(method: MethodInvocation) -> Optional[ComprehensionExpression]:
    """Return the single list-comprehension argument if there is exactly one, else None."""
    args = method.arguments
    if len(args) != 1 or not isinstance(args[0], ComprehensionExpression):
        return None
    comp = args[0]
    if comp.kind != ComprehensionExpression.Kind.LIST:
        return None
    return comp


@categorize(_Cleanup)
class ComprehensionToGenerator(Recipe):
    """
    Drop unnecessary list brackets inside functions that accept iterables.

    Functions like ``any``, ``all``, ``sum``, ``min``, ``max``, and ``sorted``
    consume their argument lazily. Passing a list comprehension forces the
    entire list into memory first. A generator expression avoids this overhead.

    Example:
        Before:
            has_error = any([is_critical(ev) for ev in events])

        After:
            has_error = any(is_critical(ev) for ev in events)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.ComprehensionToGenerator"

    @property
    def display_name(self) -> str:
        return "Use generator expression instead of list comprehension in iterable-accepting calls"

    @property
    def description(self) -> str:
        return (
            "Functions that consume iterables lazily (e.g. `any`, `sum`, `sorted`) "
            "do not need a list comprehension -- a generator expression suffices."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not _is_bare_builtin(method, _GENERATOR_ACCEPTING_FUNCS):
                    return method

                comp = _get_single_list_comp(method)
                if comp is None:
                    return method

                # Change the comprehension kind from LIST to GENERATOR.
                # Add the OmitParentheses marker so the printer doesn't add
                # extra parentheses around the generator expression (the
                # function call's parens serve as the generator's delimiters).
                from uuid import uuid4
                omit_marker = OmitParentheses(uuid4())
                new_markers = comp.markers.replace(
                    _markers=[*comp.markers.markers, omit_marker],
                )
                new_comp = comp.replace(
                    _kind=ComprehensionExpression.Kind.GENERATOR,
                    _markers=new_markers,
                )
                new_args = JContainer.build_nullable(
                    method.padding.arguments,
                    [new_comp],
                )
                return method.replace(_arguments=new_args)

        return Visitor()


@categorize(_Cleanup)
class IdentityComprehension(Recipe):
    """
    Simplify identity comprehensions to ``list()``/``set()`` constructor calls.

    A comprehension that yields every element unchanged -- ``[v for v in seq]``
    or ``{v for v in seq}`` -- is just copying the iterable. The constructor
    call ``list(seq)`` or ``set(seq)`` expresses the same operation more clearly.

    Example:
        Before:
            output = [entry for entry in records]

        After:
            output = list(records)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.IdentityComprehension"

    @property
    def display_name(self) -> str:
        return "Simplify identity comprehension to `list()`/`set()` call"

    @property
    def description(self) -> str:
        return (
            "A comprehension that simply passes through each element unchanged "
            "is equivalent to calling `list()` or `set()` on the iterable."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_comprehension_expression(
                self, comp: ComprehensionExpression, p: ExecutionContext
            ) -> Optional[ComprehensionExpression]:
                comp = super().visit_comprehension_expression(comp, p)

                kind = comp.kind
                # Only handle list, set (not generator or dict for now)
                if kind not in (ComprehensionExpression.Kind.LIST,
                                ComprehensionExpression.Kind.SET):
                    return comp

                # Must have exactly one clause with no conditions
                if len(comp.clauses) != 1:
                    return comp
                clause = comp.clauses[0]
                if clause.conditions:
                    return comp
                # Skip async comprehensions — list() does synchronous iteration
                if clause.async_:
                    return comp

                # Check identity: result must be the same identifier as
                # the iterator variable
                result = comp.result
                iter_var = clause.iterator_variable
                if not isinstance(result, Identifier) or not isinstance(iter_var, Identifier):
                    return comp
                if result.simple_name != iter_var.simple_name:
                    return comp

                coll = clause.iterated_list
                match = MatchResult({'coll': coll})

                if kind == ComprehensionExpression.Kind.LIST:
                    return _list_template.apply(self.cursor, values=match)
                elif kind == ComprehensionExpression.Kind.SET:
                    return _set_template.apply(self.cursor, values=match)

                return comp

        return Visitor()


@categorize(_Cleanup)
class InvertAnyAll(Recipe):
    """
    Swap ``not all(...)`` / ``not any(...)`` by negating the inner comparison.

    By De Morgan's laws, ``not all(cond for ...)`` equals ``any(negated_cond for ...)``,
    and ``not any(cond for ...)`` equals ``all(negated_cond for ...)``. This recipe
    performs the swap when the generator body is a comparison operator that has
    a clean inverse (e.g. ``>`` becomes ``<=``).

    Example:
        Before:
            result = not all(score >= passing for score in grades)

        After:
            result = any(score < passing for score in grades)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.InvertAnyAll"

    @property
    def display_name(self) -> str:
        return "Swap `not all()`/`not any()` by negating the comparison"

    @property
    def description(self) -> str:
        return (
            "Apply De Morgan's law to replace `not all(cond ...)` with "
            "`any(negated_cond ...)` or `not any(cond ...)` with "
            "`all(negated_cond ...)`."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_unary(
                self, unary: Unary, p: ExecutionContext
            ) -> Optional[Unary]:
                unary = super().visit_unary(unary, p)

                if unary.operator != Unary.Type.Not:
                    return unary

                expr = unary.expression
                if not isinstance(expr, MethodInvocation):
                    return unary

                if not _is_bare_builtin(expr, {'any', 'all'}):
                    return unary

                gen = _get_single_generator(expr)
                if gen is None:
                    return unary

                # Must have exactly one clause
                if len(gen.clauses) != 1:
                    return unary

                # The generator body must be a binary comparison we can negate
                body = gen.result
                if not isinstance(body, JBinary):
                    return unary

                if body.operator not in _NEGATE_OP:
                    return unary

                # Negate the operator
                negated_op = _NEGATE_OP[body.operator]
                new_body = body.replace(
                    _operator=body._operator.replace(_element=negated_op),
                )

                # Swap function name: any <-> all
                func_name = expr.name.simple_name
                new_name = 'any' if func_name == 'all' else 'all'

                # Build the new generator with negated body
                new_gen = gen.replace(_result=new_body)
                new_args = JContainer.build_nullable(
                    expr.padding.arguments,
                    [new_gen],
                )
                new_method = expr.replace(
                    _name=expr.name.replace(_simple_name=new_name),
                    _arguments=new_args,
                    _prefix=unary.prefix,
                )
                return new_method

        return Visitor()


@categorize(_Cleanup)
class InvertAnyAllBody(Recipe):
    """
    Apply De Morgan's law to ``any(not v for v in seq)`` and ``all(not v for v in seq)``.

    When a generator simply negates the loop variable, the expression can be
    rewritten without the generator at all: ``any(not v for v in seq)`` becomes
    ``not all(seq)``, and ``all(not v for v in seq)`` becomes ``not any(seq)``.

    Example:
        Before:
            flag = any(not ok for ok in checks)

        After:
            flag = not all(checks)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.InvertAnyAllBody"

    @property
    def display_name(self) -> str:
        return "Apply De Morgan's law to `any(not ...)`/`all(not ...)`"

    @property
    def description(self) -> str:
        return (
            "When the generator body just negates the loop variable, De Morgan's "
            "law lets us eliminate the generator entirely: `any(not v for v in seq)` "
            "becomes `not all(seq)`, and the reverse."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not _is_bare_builtin(method, {'any', 'all'}):
                    return method

                gen = _get_single_generator(method)
                if gen is None:
                    return method

                # Must have exactly one clause with no conditions
                if len(gen.clauses) != 1:
                    return method
                clause = gen.clauses[0]
                if clause.conditions:
                    return method

                # Body must be `not x` where x matches the loop variable
                body = gen.result
                if not isinstance(body, Unary) or body.operator != Unary.Type.Not:
                    return method

                negated_expr = body.expression
                iter_var = clause.iterator_variable
                if not isinstance(negated_expr, Identifier) or not isinstance(iter_var, Identifier):
                    return method
                if negated_expr.simple_name != iter_var.simple_name:
                    return method

                # Swap function name: any <-> all
                func_name = method.name.simple_name
                new_name = 'any' if func_name == 'all' else 'all'

                # Replace arguments with the collection directly
                coll = clause.iterated_list
                new_args = JContainer.build_nullable(
                    method.padding.arguments,
                    [coll.replace(_prefix=gen.prefix)],
                )
                new_method = method.replace(
                    _name=method.name.replace(_simple_name=new_name),
                    _arguments=new_args,
                )

                # Wrap in `not ...` to preserve correct semantics
                match = MatchResult({'inner': new_method})
                return _not_template.apply(self.cursor, values=match)

        return Visitor()


@categorize(_Cleanup)
class ConvertAnyToIn(Recipe):
    """
    Rewrite ``any(v == literal for v in seq)`` as a membership test with ``in``.

    An ``any()`` call that checks whether any element equals a specific literal
    is equivalent to the built-in ``in`` operator, which is more readable and
    often faster.

    Example:
        Before:
            if any(fruit == "mango" for fruit in basket):
                celebrate()

        After:
            if "mango" in basket:
                celebrate()
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.ConvertAnyToIn"

    @property
    def display_name(self) -> str:
        return "Rewrite `any(v == literal ...)` as `literal in collection`"

    @property
    def description(self) -> str:
        return (
            "An `any()` generator that tests equality against a literal value "
            "is equivalent to the `in` membership operator, which is clearer."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not _is_bare_builtin(method, {'any'}):
                    return method

                gen = _get_single_generator(method)
                if gen is None:
                    return method

                # Must have exactly one clause with no conditions (no if-filter)
                if len(gen.clauses) != 1:
                    return method
                clause = gen.clauses[0]
                if clause.conditions:
                    return method

                # Body must be `var == literal` or `literal == var`
                body = gen.result
                if not isinstance(body, JBinary) or body.operator != JBinary.Type.Equal:
                    return method

                iter_var = clause.iterator_variable
                if not isinstance(iter_var, Identifier):
                    return method

                left = body.left
                right = body.right

                # Determine which side is the literal and which is the loop variable
                literal_node = None
                if (isinstance(left, Identifier) and left.simple_name == iter_var.simple_name
                        and isinstance(right, Literal)):
                    literal_node = right
                elif (isinstance(right, Identifier) and right.simple_name == iter_var.simple_name
                        and isinstance(left, Literal)):
                    literal_node = left
                else:
                    return method

                # Build `literal in coll`
                coll = clause.iterated_list
                match = MatchResult({
                    'lit': literal_node,
                    'coll': coll,
                })
                return _in_template.apply(self.cursor, values=match)

        return Visitor()


@categorize(_Cleanup)
class SimplifyConstantSum(Recipe):
    """
    Simplify ``sum(1 for x in items if cond)`` to
    ``sum(bool(cond) for x in items)``.

    When ``sum()`` is used with a generator that yields a constant ``1``
    filtered by a condition, the pattern can be simplified by moving the
    condition into a ``bool()`` wrapper.

    Example:
        Before:
            sum(1 for book in books if book.author == "Terry Pratchett")

        After:
            sum(bool(book.author == "Terry Pratchett") for book in books)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.cleanup.SimplifyConstantSum"

    @property
    def display_name(self) -> str:
        return "Simplify `sum(1 for x in items if cond)` to `sum(bool(cond) for x in items)`"

    @property
    def description(self) -> str:
        return (
            "Replace `sum(1 for x in items if cond)` with "
            "`sum(bool(cond) for x in items)` by moving the filter "
            "condition into a `bool()` wrapper."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not _is_bare_builtin(method, {'sum'}):
                    return method

                gen = _get_single_generator(method)
                if gen is None:
                    return method

                # Must have exactly one clause with exactly one condition
                if len(gen.clauses) != 1:
                    return method
                clause = gen.clauses[0]
                if not clause.conditions or len(clause.conditions) != 1:
                    return method

                # The result must be the literal 1
                result = gen.result
                if not isinstance(result, Literal):
                    return method
                if result.value != 1:
                    return method

                # Get the condition expression
                condition = clause.conditions[0]
                cond_expr = condition.expression

                # Build bool(cond) as the new result using template.
                # template.apply() returns an ExpressionStatement wrapper,
                # so extract the inner expression.
                match = MatchResult({'x': cond_expr})
                bool_stmt = _bool_template.apply(self.cursor, values=match)
                bool_call = bool_stmt.expression

                # Build new generator: bool(cond) for x in items (no filter)
                new_clause = clause.replace(_conditions=[])
                new_gen = gen.replace(
                    _result=bool_call.replace(_prefix=result.prefix),
                    _clauses=[new_clause],
                )
                new_args = JContainer.build_nullable(
                    method.padding.arguments,
                    [new_gen],
                )
                return method.replace(_arguments=new_args)

        return Visitor()
