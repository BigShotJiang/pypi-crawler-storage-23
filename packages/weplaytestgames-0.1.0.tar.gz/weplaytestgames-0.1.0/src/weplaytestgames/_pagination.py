"""Pagination helpers for sync and async iteration."""

from __future__ import annotations

from typing import Any, Callable, Dict, Generic, Iterator, List, Optional, TypeVar

T = TypeVar("T")


class Page(Generic[T]):
    """A single page of results."""

    def __init__(self, data: List[T], meta: Dict[str, Any]):
        self.data = data
        self.meta = meta

    @property
    def has_more(self) -> bool:
        return self.meta.get("has_more", False)

    @property
    def cursor(self) -> Optional[str]:
        return self.meta.get("cursor")

    def __repr__(self) -> str:
        return f"Page(data=[...{len(self.data)} items], has_more={self.has_more})"


class SyncPaginator(Generic[T]):
    """Synchronous paginator. Iterable for auto-pagination, or call get_page() for a single page."""

    def __init__(
        self,
        fetch_fn: Callable[[Dict[str, Any]], Page[T]],
        initial_params: Dict[str, Any],
    ):
        self._fetch = fetch_fn
        self._params = dict(initial_params)

    def get_page(self) -> Page[T]:
        return self._fetch(self._params)

    def __iter__(self) -> Iterator[T]:
        params = dict(self._params)
        while True:
            page = self._fetch(params)
            yield from page.data
            if not page.has_more or not page.cursor:
                break
            params["cursor"] = page.cursor


class AsyncPaginator(Generic[T]):
    """Async paginator. Async iterable for auto-pagination, or call get_page() for a single page."""

    def __init__(
        self,
        fetch_fn: Any,  # Callable[[Dict], Awaitable[Page[T]]]
        initial_params: Dict[str, Any],
    ):
        self._fetch = fetch_fn
        self._params = dict(initial_params)

    async def get_page(self) -> Page[T]:
        return await self._fetch(self._params)

    async def __aiter__(self):  # type: ignore[override]
        params = dict(self._params)
        while True:
            page = await self._fetch(params)
            for item in page.data:
                yield item
            if not page.has_more or not page.cursor:
                break
            params["cursor"] = page.cursor
