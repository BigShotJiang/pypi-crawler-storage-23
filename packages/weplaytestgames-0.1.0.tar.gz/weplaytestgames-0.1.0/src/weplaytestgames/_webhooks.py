"""Webhook signature verification utility."""

from __future__ import annotations

import hashlib
import hmac
import time


def verify_webhook_signature(
    *,
    payload: str,
    signature: str,
    timestamp: str,
    secret: str,
    tolerance_seconds: int = 300,
) -> bool:
    """Verify a webhook signature from We Playtest Games.

    The backend signs as ``HMAC-SHA256(secret, "{timestamp}.{payload}")`` and
    sends the hex digest in the ``X-WPG-Signature`` header and the unix
    timestamp in ``X-WPG-Timestamp``.

    Args:
        payload: The raw request body string.
        signature: Value of the ``X-WPG-Signature`` header.
        timestamp: Value of the ``X-WPG-Timestamp`` header (unix seconds).
        secret: Your webhook secret.
        tolerance_seconds: Max age in seconds before rejecting as replay
            (default 300, 0 to disable).

    Returns:
        ``True`` if the signature is valid and within the tolerance window.
    """
    # Replay protection
    if tolerance_seconds > 0:
        try:
            ts = int(timestamp)
        except (ValueError, TypeError):
            return False
        diff = abs(int(time.time()) - ts)
        if diff > tolerance_seconds:
            return False

    expected = hmac.new(
        secret.encode(), f"{timestamp}.{payload}".encode(), hashlib.sha256
    ).hexdigest()

    return hmac.compare_digest(signature, expected)
