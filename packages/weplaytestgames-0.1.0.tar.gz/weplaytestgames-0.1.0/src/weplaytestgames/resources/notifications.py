from __future__ import annotations

from typing import Any, Dict, Optional

from .._http import AsyncHttpClient, SyncHttpClient
from .._pagination import AsyncPaginator, Page, SyncPaginator
from .._types import Notification


class SyncNotificationsResource:
    def __init__(self, http: SyncHttpClient):
        self._http = http

    def list(
        self, *, limit: int = 20, cursor: Optional[str] = None, unread: bool = False
    ) -> SyncPaginator[Notification]:
        """List notifications (paginated)."""

        def fetch(params: Dict[str, Any]) -> Page[Notification]:
            if unread:
                params["unread"] = "true"
            resp = self._http.request("GET", "/notifications", params=params)
            return Page(data=resp["data"]["notifications"], meta=resp["meta"])

        return SyncPaginator(fetch, {"limit": limit, "cursor": cursor})

    def mark_all_read(self) -> Dict[str, Any]:
        """Mark all notifications as read."""
        return self._http.request("POST", "/notifications/mark-all-read")["data"]


class AsyncNotificationsResource:
    def __init__(self, http: AsyncHttpClient):
        self._http = http

    def list(
        self, *, limit: int = 20, cursor: Optional[str] = None, unread: bool = False
    ) -> AsyncPaginator[Notification]:
        async def fetch(params: Dict[str, Any]) -> Page[Notification]:
            if unread:
                params["unread"] = "true"
            resp = await self._http.request("GET", "/notifications", params=params)
            return Page(data=resp["data"]["notifications"], meta=resp["meta"])

        return AsyncPaginator(fetch, {"limit": limit, "cursor": cursor})

    async def mark_all_read(self) -> Dict[str, Any]:
        resp = await self._http.request("POST", "/notifications/mark-all-read")
        return resp["data"]
