from __future__ import annotations

from typing import Any, Dict, List, Optional

from .._http import AsyncHttpClient, SyncHttpClient
from .._pagination import AsyncPaginator, Page, SyncPaginator
from .._types import PlaytestCreateResponse, PlaytestDetail, PlaytestRequest, PlaytestSlot


class SyncPlaytestsResource:
    def __init__(self, http: SyncHttpClient):
        self._http = http

    def list(self, game_id: str, *, limit: int = 20, cursor: Optional[str] = None) -> SyncPaginator[PlaytestRequest]:
        """List playtest requests for a game (paginated)."""

        def fetch(params: Dict[str, Any]) -> Page[PlaytestRequest]:
            resp = self._http.request("GET", f"/games/{game_id}/playtests", params=params)
            return Page(data=resp["data"]["playtests"], meta=resp["meta"])

        return SyncPaginator(fetch, {"limit": limit, "cursor": cursor})

    def create(
        self,
        game_id: str,
        *,
        visibility: str = "private",
        quantity: int = 1,
        duration_minutes: int = 60,
        notes_for_testers: Optional[str] = None,
        keys_for_testers: Optional[List[str]] = None,
        is_free_public_trial: bool = False,
        targeting_type: Optional[str] = None,
        past_playtester_scope: Optional[str] = None,
        targeted_playtester_id: Optional[str] = None,
    ) -> PlaytestCreateResponse:
        """Create a playtest request for a game."""
        body: Dict[str, Any] = {
            "visibility": visibility,
            "quantity": quantity,
            "duration_minutes": duration_minutes,
            "is_free_public_trial": is_free_public_trial,
        }
        if notes_for_testers is not None:
            body["notes_for_testers"] = notes_for_testers
        if keys_for_testers is not None:
            body["keys_for_testers"] = keys_for_testers
        if targeting_type is not None:
            body["targeting_type"] = targeting_type
        if past_playtester_scope is not None:
            body["past_playtester_scope"] = past_playtester_scope
        if targeted_playtester_id is not None:
            body["targeted_playtester_id"] = targeted_playtester_id
        return self._http.request("POST", f"/games/{game_id}/playtests", json=body)["data"]

    def get(self, playtest_id: str) -> PlaytestDetail:
        """Get playtest request details."""
        return self._http.request("GET", f"/playtests/{playtest_id}")["data"]["playtest"]

    def update(self, playtest_id: str, *, notes_for_testers: Optional[str] = None) -> PlaytestRequest:
        """Update a playtest request."""
        body: Dict[str, Any] = {}
        if notes_for_testers is not None:
            body["notes_for_testers"] = notes_for_testers
        return self._http.request("PATCH", f"/playtests/{playtest_id}", json=body)["data"]["playtest"]

    def slots(self, playtest_id: str, *, limit: int = 20, cursor: Optional[str] = None) -> SyncPaginator[PlaytestSlot]:
        """List slots for a playtest (paginated)."""

        def fetch(params: Dict[str, Any]) -> Page[PlaytestSlot]:
            resp = self._http.request("GET", f"/playtests/{playtest_id}/slots", params=params)
            return Page(data=resp["data"]["slots"], meta=resp["meta"])

        return SyncPaginator(fetch, {"limit": limit, "cursor": cursor})


class AsyncPlaytestsResource:
    def __init__(self, http: AsyncHttpClient):
        self._http = http

    def list(self, game_id: str, *, limit: int = 20, cursor: Optional[str] = None) -> AsyncPaginator[PlaytestRequest]:
        async def fetch(params: Dict[str, Any]) -> Page[PlaytestRequest]:
            resp = await self._http.request("GET", f"/games/{game_id}/playtests", params=params)
            return Page(data=resp["data"]["playtests"], meta=resp["meta"])

        return AsyncPaginator(fetch, {"limit": limit, "cursor": cursor})

    async def create(
        self,
        game_id: str,
        *,
        visibility: str = "private",
        quantity: int = 1,
        duration_minutes: int = 60,
        notes_for_testers: Optional[str] = None,
        keys_for_testers: Optional[List[str]] = None,
        is_free_public_trial: bool = False,
        targeting_type: Optional[str] = None,
        past_playtester_scope: Optional[str] = None,
        targeted_playtester_id: Optional[str] = None,
    ) -> PlaytestCreateResponse:
        body: Dict[str, Any] = {
            "visibility": visibility,
            "quantity": quantity,
            "duration_minutes": duration_minutes,
            "is_free_public_trial": is_free_public_trial,
        }
        if notes_for_testers is not None:
            body["notes_for_testers"] = notes_for_testers
        if keys_for_testers is not None:
            body["keys_for_testers"] = keys_for_testers
        if targeting_type is not None:
            body["targeting_type"] = targeting_type
        if past_playtester_scope is not None:
            body["past_playtester_scope"] = past_playtester_scope
        if targeted_playtester_id is not None:
            body["targeted_playtester_id"] = targeted_playtester_id
        resp = await self._http.request("POST", f"/games/{game_id}/playtests", json=body)
        return resp["data"]

    async def get(self, playtest_id: str) -> PlaytestDetail:
        resp = await self._http.request("GET", f"/playtests/{playtest_id}")
        return resp["data"]["playtest"]

    async def update(self, playtest_id: str, *, notes_for_testers: Optional[str] = None) -> PlaytestRequest:
        body: Dict[str, Any] = {}
        if notes_for_testers is not None:
            body["notes_for_testers"] = notes_for_testers
        resp = await self._http.request("PATCH", f"/playtests/{playtest_id}", json=body)
        return resp["data"]["playtest"]

    def slots(self, playtest_id: str, *, limit: int = 20, cursor: Optional[str] = None) -> AsyncPaginator[PlaytestSlot]:
        async def fetch(params: Dict[str, Any]) -> Page[PlaytestSlot]:
            resp = await self._http.request("GET", f"/playtests/{playtest_id}/slots", params=params)
            return Page(data=resp["data"]["slots"], meta=resp["meta"])

        return AsyncPaginator(fetch, {"limit": limit, "cursor": cursor})
