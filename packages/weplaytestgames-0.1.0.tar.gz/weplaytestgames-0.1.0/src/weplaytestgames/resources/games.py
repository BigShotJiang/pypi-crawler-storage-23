from __future__ import annotations

from typing import Any, Dict, List, Optional

from .._http import AsyncHttpClient, SyncHttpClient
from .._pagination import AsyncPaginator, Page, SyncPaginator
from .._types import Build, Game


class SyncGamesResource:
    def __init__(self, http: SyncHttpClient):
        self._http = http

    def list(self, *, limit: int = 20, cursor: Optional[str] = None) -> SyncPaginator[Game]:
        """List your games (paginated)."""

        def fetch(params: Dict[str, Any]) -> Page[Game]:
            resp = self._http.request("GET", "/games", params=params)
            return Page(data=resp["data"]["games"], meta=resp["meta"])

        return SyncPaginator(fetch, {"limit": limit, "cursor": cursor})

    def create(
        self,
        *,
        name: str,
        build_url: str,
        description: Optional[str] = None,
        instructions: Optional[str] = None,
        cover_image_url: Optional[str] = None,
        external_url: Optional[str] = None,
        devices: Optional[List[str]] = None,
        platforms: Optional[List[str]] = None,
        tags: Optional[List[str]] = None,
    ) -> Game:
        """Create a new game."""
        body: Dict[str, Any] = {"name": name, "build_url": build_url}
        if description is not None:
            body["description"] = description
        if instructions is not None:
            body["instructions"] = instructions
        if cover_image_url is not None:
            body["cover_image_url"] = cover_image_url
        if external_url is not None:
            body["external_url"] = external_url
        if devices is not None:
            body["devices"] = devices
        if platforms is not None:
            body["platforms"] = platforms
        if tags is not None:
            body["tags"] = tags
        return self._http.request("POST", "/games", json=body)["data"]["game"]

    def get(self, game_id: str) -> Game:
        """Get a game by ID."""
        return self._http.request("GET", f"/games/{game_id}")["data"]["game"]

    def update(self, game_id: str, **kwargs: Any) -> Game:
        """Update a game."""
        return self._http.request("PATCH", f"/games/{game_id}", json=kwargs)["data"]["game"]

    def builds(self, game_id: str, *, limit: int = 20, cursor: Optional[str] = None) -> SyncPaginator[Build]:
        """List builds for a game (paginated)."""

        def fetch(params: Dict[str, Any]) -> Page[Build]:
            resp = self._http.request("GET", f"/games/{game_id}/builds", params=params)
            return Page(data=resp["data"]["builds"], meta=resp["meta"])

        return SyncPaginator(fetch, {"limit": limit, "cursor": cursor})


class AsyncGamesResource:
    def __init__(self, http: AsyncHttpClient):
        self._http = http

    def list(self, *, limit: int = 20, cursor: Optional[str] = None) -> AsyncPaginator[Game]:
        async def fetch(params: Dict[str, Any]) -> Page[Game]:
            resp = await self._http.request("GET", "/games", params=params)
            return Page(data=resp["data"]["games"], meta=resp["meta"])

        return AsyncPaginator(fetch, {"limit": limit, "cursor": cursor})

    async def create(
        self,
        *,
        name: str,
        build_url: str,
        description: Optional[str] = None,
        instructions: Optional[str] = None,
        cover_image_url: Optional[str] = None,
        external_url: Optional[str] = None,
        devices: Optional[List[str]] = None,
        platforms: Optional[List[str]] = None,
        tags: Optional[List[str]] = None,
    ) -> Game:
        body: Dict[str, Any] = {"name": name, "build_url": build_url}
        if description is not None:
            body["description"] = description
        if instructions is not None:
            body["instructions"] = instructions
        if cover_image_url is not None:
            body["cover_image_url"] = cover_image_url
        if external_url is not None:
            body["external_url"] = external_url
        if devices is not None:
            body["devices"] = devices
        if platforms is not None:
            body["platforms"] = platforms
        if tags is not None:
            body["tags"] = tags
        resp = await self._http.request("POST", "/games", json=body)
        return resp["data"]["game"]

    async def get(self, game_id: str) -> Game:
        resp = await self._http.request("GET", f"/games/{game_id}")
        return resp["data"]["game"]

    async def update(self, game_id: str, **kwargs: Any) -> Game:
        resp = await self._http.request("PATCH", f"/games/{game_id}", json=kwargs)
        return resp["data"]["game"]

    def builds(self, game_id: str, *, limit: int = 20, cursor: Optional[str] = None) -> AsyncPaginator[Build]:
        async def fetch(params: Dict[str, Any]) -> Page[Build]:
            resp = await self._http.request("GET", f"/games/{game_id}/builds", params=params)
            return Page(data=resp["data"]["builds"], meta=resp["meta"])

        return AsyncPaginator(fetch, {"limit": limit, "cursor": cursor})
