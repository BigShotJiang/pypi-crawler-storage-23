from __future__ import annotations

from typing import Any, Dict, Optional

from .._http import AsyncHttpClient, SyncHttpClient
from .._pagination import AsyncPaginator, Page, SyncPaginator
from .._types import Submission


class SyncSubmissionsResource:
    def __init__(self, http: SyncHttpClient):
        self._http = http

    def list(
        self, *, limit: int = 20, cursor: Optional[str] = None, status: Optional[str] = None
    ) -> SyncPaginator[Submission]:
        """List submissions across all your games (paginated)."""

        def fetch(params: Dict[str, Any]) -> Page[Submission]:
            if status is not None:
                params["status"] = status
            resp = self._http.request("GET", "/playtests/submissions", params=params)
            return Page(data=resp["data"]["submissions"], meta=resp["meta"])

        return SyncPaginator(fetch, {"limit": limit, "cursor": cursor})


class AsyncSubmissionsResource:
    def __init__(self, http: AsyncHttpClient):
        self._http = http

    def list(
        self, *, limit: int = 20, cursor: Optional[str] = None, status: Optional[str] = None
    ) -> AsyncPaginator[Submission]:
        async def fetch(params: Dict[str, Any]) -> Page[Submission]:
            if status is not None:
                params["status"] = status
            resp = await self._http.request("GET", "/playtests/submissions", params=params)
            return Page(data=resp["data"]["submissions"], meta=resp["meta"])

        return AsyncPaginator(fetch, {"limit": limit, "cursor": cursor})
