from __future__ import annotations

from .._http import AsyncHttpClient, SyncHttpClient
from .._types import DashboardStats


class SyncDashboardResource:
    def __init__(self, http: SyncHttpClient):
        self._http = http

    def stats(self) -> DashboardStats:
        """Get dashboard statistics."""
        return self._http.request("GET", "/playtests/dashboard/stats")["data"]


class AsyncDashboardResource:
    def __init__(self, http: AsyncHttpClient):
        self._http = http

    async def stats(self) -> DashboardStats:
        resp = await self._http.request("GET", "/playtests/dashboard/stats")
        return resp["data"]
