from __future__ import annotations

from typing import Any, Dict, List, Optional

from .._http import AsyncHttpClient, SyncHttpClient
from .._pagination import AsyncPaginator, Page, SyncPaginator
from .._types import ChatContact, ChatMessage


class SyncChatResource:
    def __init__(self, http: SyncHttpClient):
        self._http = http

    def contacts(self) -> List[ChatContact]:
        """List chat contacts."""
        return self._http.request("GET", "/chat/contacts")["data"]["contacts"]

    def conversation(
        self, conversation_id: str, *, limit: int = 20, cursor: Optional[str] = None
    ) -> SyncPaginator[ChatMessage]:
        """Get conversation messages (paginated)."""

        def fetch(params: Dict[str, Any]) -> Page[ChatMessage]:
            resp = self._http.request("GET", f"/chat/conversations/{conversation_id}", params=params)
            return Page(data=resp["data"]["messages"], meta=resp["meta"])

        return SyncPaginator(fetch, {"limit": limit, "cursor": cursor})

    def send_message(self, conversation_id: str, *, content: str) -> ChatMessage:
        """Send a message in a conversation."""
        resp = self._http.request(
            "POST", f"/chat/conversations/{conversation_id}/messages", json={"content": content}
        )
        return resp["data"]["message"]

    def unread_count(self) -> int:
        """Get total unread message count."""
        return int(self._http.request("GET", "/chat/unread-count")["data"]["unread_count"])


class AsyncChatResource:
    def __init__(self, http: AsyncHttpClient):
        self._http = http

    async def contacts(self) -> List[ChatContact]:
        resp = await self._http.request("GET", "/chat/contacts")
        return resp["data"]["contacts"]

    def conversation(
        self, conversation_id: str, *, limit: int = 20, cursor: Optional[str] = None
    ) -> AsyncPaginator[ChatMessage]:
        async def fetch(params: Dict[str, Any]) -> Page[ChatMessage]:
            resp = await self._http.request("GET", f"/chat/conversations/{conversation_id}", params=params)
            return Page(data=resp["data"]["messages"], meta=resp["meta"])

        return AsyncPaginator(fetch, {"limit": limit, "cursor": cursor})

    async def send_message(self, conversation_id: str, *, content: str) -> ChatMessage:
        resp = await self._http.request(
            "POST", f"/chat/conversations/{conversation_id}/messages", json={"content": content}
        )
        return resp["data"]["message"]

    async def unread_count(self) -> int:
        resp = await self._http.request("GET", "/chat/unread-count")
        return int(resp["data"]["unread_count"])
