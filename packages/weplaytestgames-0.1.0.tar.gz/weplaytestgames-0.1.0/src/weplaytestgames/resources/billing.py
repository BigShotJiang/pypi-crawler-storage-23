from __future__ import annotations

from typing import Any, Dict, Optional

from .._http import AsyncHttpClient, SyncHttpClient
from .._pagination import AsyncPaginator, Page, SyncPaginator
from .._types import Balance, Payment, PurchaseCreditResponse


class SyncBillingResource:
    def __init__(self, http: SyncHttpClient):
        self._http = http

    def get_balance(self) -> Balance:
        """Get current credit balance."""
        return self._http.request("GET", "/billing/balance")["data"]

    def payments(self, *, limit: int = 20, cursor: Optional[str] = None) -> SyncPaginator[Payment]:
        """List payment history (paginated)."""

        def fetch(params: Dict[str, Any]) -> Page[Payment]:
            resp = self._http.request("GET", "/billing/payments", params=params)
            return Page(data=resp["data"]["payments"], meta=resp["meta"])

        return SyncPaginator(fetch, {"limit": limit, "cursor": cursor})

    def get_payment(self, payment_id: str) -> Payment:
        """Get a single payment by ID."""
        return self._http.request("GET", f"/billing/payments/{payment_id}")["data"]["payment"]

    def purchase_credit(self, *, amount_cents: int, return_url: Optional[str] = None) -> PurchaseCreditResponse:
        """Purchase credit via Stripe Checkout."""
        body: Dict[str, Any] = {"amount_cents": amount_cents}
        if return_url is not None:
            body["return_url"] = return_url
        return self._http.request("POST", "/billing/credit", json=body)["data"]


class AsyncBillingResource:
    def __init__(self, http: AsyncHttpClient):
        self._http = http

    async def get_balance(self) -> Balance:
        resp = await self._http.request("GET", "/billing/balance")
        return resp["data"]

    def payments(self, *, limit: int = 20, cursor: Optional[str] = None) -> AsyncPaginator[Payment]:
        async def fetch(params: Dict[str, Any]) -> Page[Payment]:
            resp = await self._http.request("GET", "/billing/payments", params=params)
            return Page(data=resp["data"]["payments"], meta=resp["meta"])

        return AsyncPaginator(fetch, {"limit": limit, "cursor": cursor})

    async def get_payment(self, payment_id: str) -> Payment:
        resp = await self._http.request("GET", f"/billing/payments/{payment_id}")
        return resp["data"]["payment"]

    async def purchase_credit(self, *, amount_cents: int, return_url: Optional[str] = None) -> PurchaseCreditResponse:
        body: Dict[str, Any] = {"amount_cents": amount_cents}
        if return_url is not None:
            body["return_url"] = return_url
        resp = await self._http.request("POST", "/billing/credit", json=body)
        return resp["data"]
