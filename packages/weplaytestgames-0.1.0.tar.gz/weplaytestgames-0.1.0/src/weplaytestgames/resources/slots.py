from __future__ import annotations

from typing import Any, Dict, Optional

from .._http import AsyncHttpClient, SyncHttpClient
from .._types import DownloadUrlResponse, SlotDetail, TranscriptResponse


class SyncSlotsResource:
    def __init__(self, http: SyncHttpClient):
        self._http = http

    def get(self, slot_id: str) -> SlotDetail:
        """Get slot details."""
        return self._http.request("GET", f"/playtests/slots/{slot_id}")["data"]["slot"]

    def accept(self, slot_id: str, *, rating: Optional[int] = None) -> Dict[str, Any]:
        """Accept a submission."""
        body: Dict[str, Any] = {}
        if rating is not None:
            body["rating"] = rating
        return self._http.request("POST", f"/playtests/slots/{slot_id}/accept", json=body or None)["data"]

    def reject(
        self, slot_id: str, *, reason: Optional[str] = None, allow_retry: bool = False
    ) -> Dict[str, Any]:
        """Reject a submission."""
        body: Dict[str, Any] = {"allow_retry": allow_retry}
        if reason is not None:
            body["reason"] = reason
        return self._http.request("POST", f"/playtests/slots/{slot_id}/reject", json=body)["data"]

    def download_url(self, slot_id: str) -> DownloadUrlResponse:
        """Get a pre-signed download URL for the submission video."""
        return self._http.request("GET", f"/playtests/slots/{slot_id}/download-url")["data"]

    def transcript(self, slot_id: str) -> TranscriptResponse:
        """Get the submission transcript."""
        return self._http.request("GET", f"/playtests/slots/{slot_id}/transcript")["data"]


class AsyncSlotsResource:
    def __init__(self, http: AsyncHttpClient):
        self._http = http

    async def get(self, slot_id: str) -> SlotDetail:
        resp = await self._http.request("GET", f"/playtests/slots/{slot_id}")
        return resp["data"]["slot"]

    async def accept(self, slot_id: str, *, rating: Optional[int] = None) -> Dict[str, Any]:
        body: Dict[str, Any] = {}
        if rating is not None:
            body["rating"] = rating
        resp = await self._http.request("POST", f"/playtests/slots/{slot_id}/accept", json=body or None)
        return resp["data"]

    async def reject(
        self, slot_id: str, *, reason: Optional[str] = None, allow_retry: bool = False
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {"allow_retry": allow_retry}
        if reason is not None:
            body["reason"] = reason
        resp = await self._http.request("POST", f"/playtests/slots/{slot_id}/reject", json=body)
        return resp["data"]

    async def download_url(self, slot_id: str) -> DownloadUrlResponse:
        resp = await self._http.request("GET", f"/playtests/slots/{slot_id}/download-url")
        return resp["data"]

    async def transcript(self, slot_id: str) -> TranscriptResponse:
        resp = await self._http.request("GET", f"/playtests/slots/{slot_id}/transcript")
        return resp["data"]
