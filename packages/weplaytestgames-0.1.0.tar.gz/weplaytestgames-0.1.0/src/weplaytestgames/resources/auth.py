from __future__ import annotations

from typing import Any, Dict, List, Optional

from .._http import AsyncHttpClient, SyncHttpClient
from .._types import (
    Category,
    Device,
    Platform,
    RegisterResponse,
    RegisterWithApiKeyResponse,
    User,
)


class SyncAuthResource:
    def __init__(self, http: SyncHttpClient):
        self._http = http

    def register(
        self,
        *,
        email: str,
        password: str,
        role: str = "game_owner",
        company_name: Optional[str] = None,
    ) -> RegisterResponse:
        """Register a new user."""
        body: Dict[str, Any] = {"email": email, "password": password, "role": role}
        if company_name is not None:
            body["company_name"] = company_name
        resp = self._http.request("POST", "/auth/register", json=body)
        return resp["data"]

    def register_with_api_key(
        self,
        *,
        email: str,
        password: str,
        role: str = "game_owner",
        company_name: Optional[str] = None,
        key_name: Optional[str] = None,
        scopes: Optional[List[str]] = None,
    ) -> RegisterWithApiKeyResponse:
        """Register a new user and return an API key."""
        body: Dict[str, Any] = {"email": email, "password": password, "role": role}
        if company_name is not None:
            body["company_name"] = company_name
        if key_name is not None:
            body["key_name"] = key_name
        if scopes is not None:
            body["scopes"] = scopes
        resp = self._http.request("POST", "/auth/register/api-key", json=body)
        return resp["data"]

    def me(self) -> User:
        """Get current user profile."""
        return self._http.request("GET", "/auth/me")["data"]

    def update_profile(
        self,
        *,
        display_name: Optional[str] = None,
        company_name: Optional[str] = None,
        website_url: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Update profile."""
        body: Dict[str, Any] = {}
        if display_name is not None:
            body["display_name"] = display_name
        if company_name is not None:
            body["company_name"] = company_name
        if website_url is not None:
            body["website_url"] = website_url
        return self._http.request("PATCH", "/auth/profile", json=body)["data"]

    def change_password(self, *, current_password: str, new_password: str) -> Dict[str, Any]:
        """Change password."""
        return self._http.request(
            "POST",
            "/auth/change-password",
            json={"current_password": current_password, "new_password": new_password},
        )["data"]

    def categories(self) -> List[Category]:
        """List all game categories/tags."""
        return self._http.request("GET", "/auth/categories")["data"]["categories"]

    def devices(self) -> List[Device]:
        """List all device types."""
        return self._http.request("GET", "/auth/devices")["data"]["devices"]

    def platforms(self) -> List[Platform]:
        """List all platforms."""
        return self._http.request("GET", "/auth/platforms")["data"]["platforms"]


class AsyncAuthResource:
    def __init__(self, http: AsyncHttpClient):
        self._http = http

    async def register(
        self,
        *,
        email: str,
        password: str,
        role: str = "game_owner",
        company_name: Optional[str] = None,
    ) -> RegisterResponse:
        body: Dict[str, Any] = {"email": email, "password": password, "role": role}
        if company_name is not None:
            body["company_name"] = company_name
        resp = await self._http.request("POST", "/auth/register", json=body)
        return resp["data"]

    async def register_with_api_key(
        self,
        *,
        email: str,
        password: str,
        role: str = "game_owner",
        company_name: Optional[str] = None,
        key_name: Optional[str] = None,
        scopes: Optional[List[str]] = None,
    ) -> RegisterWithApiKeyResponse:
        body: Dict[str, Any] = {"email": email, "password": password, "role": role}
        if company_name is not None:
            body["company_name"] = company_name
        if key_name is not None:
            body["key_name"] = key_name
        if scopes is not None:
            body["scopes"] = scopes
        resp = await self._http.request("POST", "/auth/register/api-key", json=body)
        return resp["data"]

    async def me(self) -> User:
        resp = await self._http.request("GET", "/auth/me")
        return resp["data"]

    async def update_profile(
        self,
        *,
        display_name: Optional[str] = None,
        company_name: Optional[str] = None,
        website_url: Optional[str] = None,
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {}
        if display_name is not None:
            body["display_name"] = display_name
        if company_name is not None:
            body["company_name"] = company_name
        if website_url is not None:
            body["website_url"] = website_url
        resp = await self._http.request("PATCH", "/auth/profile", json=body)
        return resp["data"]

    async def change_password(self, *, current_password: str, new_password: str) -> Dict[str, Any]:
        resp = await self._http.request(
            "POST",
            "/auth/change-password",
            json={"current_password": current_password, "new_password": new_password},
        )
        return resp["data"]

    async def categories(self) -> List[Category]:
        resp = await self._http.request("GET", "/auth/categories")
        return resp["data"]["categories"]

    async def devices(self) -> List[Device]:
        resp = await self._http.request("GET", "/auth/devices")
        return resp["data"]["devices"]

    async def platforms(self) -> List[Platform]:
        resp = await self._http.request("GET", "/auth/platforms")
        return resp["data"]["platforms"]
