from __future__ import annotations

from typing import Any, Dict, List, Optional

from .._http import AsyncHttpClient, SyncHttpClient
from .._pagination import AsyncPaginator, Page, SyncPaginator
from .._types import Webhook, WebhookCreateResponse, WebhookDelivery, WebhookTestResponse


class SyncWebhooksResource:
    def __init__(self, http: SyncHttpClient):
        self._http = http

    def list(self) -> List[Webhook]:
        """List all webhooks."""
        return self._http.request("GET", "/webhooks")["data"]["webhooks"]

    def create(self, *, url: str, events: List[str]) -> WebhookCreateResponse:
        """Create a webhook (returns webhook + secret)."""
        return self._http.request("POST", "/webhooks", json={"url": url, "events": events})["data"]

    def update(self, webhook_id: str, *, url: Optional[str] = None, events: Optional[List[str]] = None) -> Webhook:
        """Update a webhook."""
        body: Dict[str, Any] = {}
        if url is not None:
            body["url"] = url
        if events is not None:
            body["events"] = events
        return self._http.request("PATCH", f"/webhooks/{webhook_id}", json=body)["data"]["webhook"]

    def delete(self, webhook_id: str) -> Dict[str, Any]:
        """Delete a webhook."""
        return self._http.request("DELETE", f"/webhooks/{webhook_id}")["data"]

    def deliveries(
        self, webhook_id: str, *, limit: int = 20, cursor: Optional[str] = None
    ) -> SyncPaginator[WebhookDelivery]:
        """List delivery attempts for a webhook (paginated)."""

        def fetch(params: Dict[str, Any]) -> Page[WebhookDelivery]:
            resp = self._http.request("GET", f"/webhooks/{webhook_id}/deliveries", params=params)
            return Page(data=resp["data"]["deliveries"], meta=resp["meta"])

        return SyncPaginator(fetch, {"limit": limit, "cursor": cursor})

    def test(self, webhook_id: str) -> WebhookTestResponse:
        """Send a test event to a webhook."""
        return self._http.request("POST", f"/webhooks/{webhook_id}/test")["data"]

    def enable(self, webhook_id: str) -> Dict[str, Any]:
        """Re-enable a disabled webhook."""
        return self._http.request("POST", f"/webhooks/{webhook_id}/enable")["data"]

    def rotate_secret(self, webhook_id: str) -> Dict[str, Any]:
        """Rotate webhook secret (returns new secret once)."""
        return self._http.request("POST", f"/webhooks/{webhook_id}/rotate-secret")["data"]


class AsyncWebhooksResource:
    def __init__(self, http: AsyncHttpClient):
        self._http = http

    async def list(self) -> List[Webhook]:
        resp = await self._http.request("GET", "/webhooks")
        return resp["data"]["webhooks"]

    async def create(self, *, url: str, events: List[str]) -> WebhookCreateResponse:
        resp = await self._http.request("POST", "/webhooks", json={"url": url, "events": events})
        return resp["data"]

    async def update(self, webhook_id: str, *, url: Optional[str] = None, events: Optional[List[str]] = None) -> Webhook:
        body: Dict[str, Any] = {}
        if url is not None:
            body["url"] = url
        if events is not None:
            body["events"] = events
        resp = await self._http.request("PATCH", f"/webhooks/{webhook_id}", json=body)
        return resp["data"]["webhook"]

    async def delete(self, webhook_id: str) -> Dict[str, Any]:
        resp = await self._http.request("DELETE", f"/webhooks/{webhook_id}")
        return resp["data"]

    def deliveries(
        self, webhook_id: str, *, limit: int = 20, cursor: Optional[str] = None
    ) -> AsyncPaginator[WebhookDelivery]:
        async def fetch(params: Dict[str, Any]) -> Page[WebhookDelivery]:
            resp = await self._http.request("GET", f"/webhooks/{webhook_id}/deliveries", params=params)
            return Page(data=resp["data"]["deliveries"], meta=resp["meta"])

        return AsyncPaginator(fetch, {"limit": limit, "cursor": cursor})

    async def test(self, webhook_id: str) -> WebhookTestResponse:
        resp = await self._http.request("POST", f"/webhooks/{webhook_id}/test")
        return resp["data"]

    async def enable(self, webhook_id: str) -> Dict[str, Any]:
        resp = await self._http.request("POST", f"/webhooks/{webhook_id}/enable")
        return resp["data"]

    async def rotate_secret(self, webhook_id: str) -> Dict[str, Any]:
        resp = await self._http.request("POST", f"/webhooks/{webhook_id}/rotate-secret")
        return resp["data"]
