"""Official Python SDK for the We Playtest Games API."""

from ._client import AsyncWPGClient, WPGClient
from ._error import ErrorDetail, WPGError
from ._pagination import AsyncPaginator, Page, SyncPaginator
from ._webhooks import verify_webhook_signature
from ._types import (
    Balance,
    Build,
    Category,
    ChatContact,
    ChatMessage,
    DashboardStats,
    Device,
    DownloadUrlResponse,
    Game,
    GameOwnerProfile,
    Notification,
    Payment,
    PurchaseCreditResponse,
    Platform,
    PlaytestCreateResponse,
    PlaytestDetail,
    PlaytestRequest,
    PlaytestSlot,
    RegisteredUser,
    RegisterResponse,
    RegisterWithApiKeyResponse,
    SlotDetail,
    SlotDetailTranscription,
    SlotGame,
    SlotPlaytest,
    SlotPlaytester,
    SlotRating,
    SlotRejection,
    SlotStats,
    Submission,
    SubmissionBlockedReport,
    SubmissionDetail,
    SubmissionPlaytest,
    SubmissionSlot,
    SubmissionSummary,
    TranscriptResponse,
    TranscriptionSummary,
    User,
    Webhook,
    WebhookCreateResponse,
    WebhookDelivery,
    WebhookTestDelivery,
    WebhookTestResponse,
)

__all__ = [
    # Clients
    "WPGClient",
    "AsyncWPGClient",
    # Errors
    "WPGError",
    "ErrorDetail",
    # Pagination
    "Page",
    "SyncPaginator",
    "AsyncPaginator",
    # Auth types
    "RegisterResponse",
    "RegisteredUser",
    "RegisterWithApiKeyResponse",
    "GameOwnerProfile",
    "User",
    "Category",
    "Device",
    "Platform",
    # Game types
    "Game",
    "Build",
    # Playtest types
    "SlotStats",
    "PlaytestRequest",
    "PlaytestDetail",
    "PlaytestCreateResponse",
    # Slot & submission types
    "SlotPlaytester",
    "SlotRating",
    "SlotRejection",
    "SubmissionSummary",
    "TranscriptionSummary",
    "PlaytestSlot",
    "SlotGame",
    "SlotPlaytest",
    "SlotDetailTranscription",
    "SlotDetail",
    "DownloadUrlResponse",
    "TranscriptResponse",
    "SubmissionSlot",
    "SubmissionDetail",
    "SubmissionPlaytest",
    "SubmissionBlockedReport",
    "Submission",
    # Billing types
    "Balance",
    "Payment",
    "PurchaseCreditResponse",
    # Chat types
    "ChatContact",
    "ChatMessage",
    # Notification types
    "Notification",
    # Webhook types
    "Webhook",
    "WebhookCreateResponse",
    "WebhookDelivery",
    "WebhookTestDelivery",
    "WebhookTestResponse",
    # Dashboard types
    "DashboardStats",
    # Webhook verification
    "verify_webhook_signature",
]

__version__ = "0.1.0"
