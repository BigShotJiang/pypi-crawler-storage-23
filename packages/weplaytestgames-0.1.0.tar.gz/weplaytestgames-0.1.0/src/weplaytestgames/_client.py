"""WPGClient and AsyncWPGClient - main entry points for the SDK."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from ._http import AsyncHttpClient, SyncHttpClient
from ._types import RegisterResponse, RegisterWithApiKeyResponse
from .resources.auth import AsyncAuthResource, SyncAuthResource
from .resources.billing import AsyncBillingResource, SyncBillingResource
from .resources.chat import AsyncChatResource, SyncChatResource
from .resources.dashboard import AsyncDashboardResource, SyncDashboardResource
from .resources.games import AsyncGamesResource, SyncGamesResource
from .resources.notifications import AsyncNotificationsResource, SyncNotificationsResource
from .resources.playtests import AsyncPlaytestsResource, SyncPlaytestsResource
from .resources.slots import AsyncSlotsResource, SyncSlotsResource
from .resources.submissions import AsyncSubmissionsResource, SyncSubmissionsResource
from .resources.webhooks import AsyncWebhooksResource, SyncWebhooksResource

DEFAULT_BASE_URL = "https://app.weplaytestgames.com/api/v1"


class WPGClient:
    """Synchronous client for the We Playtest Games API."""

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
        max_retries: int = 2,
    ):
        self._http = SyncHttpClient(api_key, base_url, timeout, max_retries=max_retries)
        self.auth = SyncAuthResource(self._http)
        self.games = SyncGamesResource(self._http)
        self.playtests = SyncPlaytestsResource(self._http)
        self.slots = SyncSlotsResource(self._http)
        self.submissions = SyncSubmissionsResource(self._http)
        self.billing = SyncBillingResource(self._http)
        self.chat = SyncChatResource(self._http)
        self.notifications = SyncNotificationsResource(self._http)
        self.webhooks = SyncWebhooksResource(self._http)
        self.dashboard = SyncDashboardResource(self._http)

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> "WPGClient":
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    @staticmethod
    def register(
        *,
        email: str,
        password: str,
        role: str = "game_owner",
        company_name: Optional[str] = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
    ) -> RegisterResponse:
        """Register a new user (no API key required)."""
        http = SyncHttpClient(api_key=None, base_url=base_url, timeout=timeout)
        try:
            return SyncAuthResource(http).register(
                email=email, password=password, role=role, company_name=company_name,
            )
        finally:
            http.close()

    @staticmethod
    def register_with_api_key(
        *,
        email: str,
        password: str,
        role: str = "game_owner",
        company_name: Optional[str] = None,
        key_name: Optional[str] = None,
        scopes: Optional[List[str]] = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
    ) -> RegisterWithApiKeyResponse:
        """Register a new user and return an API key (no API key required)."""
        http = SyncHttpClient(api_key=None, base_url=base_url, timeout=timeout)
        try:
            return SyncAuthResource(http).register_with_api_key(
                email=email, password=password, role=role,
                company_name=company_name, key_name=key_name, scopes=scopes,
            )
        finally:
            http.close()


class AsyncWPGClient:
    """Async client for the We Playtest Games API."""

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
        max_retries: int = 2,
    ):
        self._http = AsyncHttpClient(api_key, base_url, timeout, max_retries=max_retries)
        self.auth = AsyncAuthResource(self._http)
        self.games = AsyncGamesResource(self._http)
        self.playtests = AsyncPlaytestsResource(self._http)
        self.slots = AsyncSlotsResource(self._http)
        self.submissions = AsyncSubmissionsResource(self._http)
        self.billing = AsyncBillingResource(self._http)
        self.chat = AsyncChatResource(self._http)
        self.notifications = AsyncNotificationsResource(self._http)
        self.webhooks = AsyncWebhooksResource(self._http)
        self.dashboard = AsyncDashboardResource(self._http)

    async def close(self) -> None:
        await self._http.close()

    async def __aenter__(self) -> "AsyncWPGClient":
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()

    @staticmethod
    async def register(
        *,
        email: str,
        password: str,
        role: str = "game_owner",
        company_name: Optional[str] = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
    ) -> RegisterResponse:
        """Register a new user (no API key required)."""
        http = AsyncHttpClient(api_key=None, base_url=base_url, timeout=timeout)
        try:
            return await AsyncAuthResource(http).register(
                email=email, password=password, role=role, company_name=company_name,
            )
        finally:
            await http.close()

    @staticmethod
    async def register_with_api_key(
        *,
        email: str,
        password: str,
        role: str = "game_owner",
        company_name: Optional[str] = None,
        key_name: Optional[str] = None,
        scopes: Optional[List[str]] = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
    ) -> RegisterWithApiKeyResponse:
        """Register a new user and return an API key (no API key required)."""
        http = AsyncHttpClient(api_key=None, base_url=base_url, timeout=timeout)
        try:
            return await AsyncAuthResource(http).register_with_api_key(
                email=email, password=password, role=role,
                company_name=company_name, key_name=key_name, scopes=scopes,
            )
        finally:
            await http.close()
