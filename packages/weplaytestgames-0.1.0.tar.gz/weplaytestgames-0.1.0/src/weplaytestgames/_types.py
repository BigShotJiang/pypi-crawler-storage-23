"""Type definitions for API responses.

All types are TypedDict classes with snake_case keys (converted from the API's camelCase).
Uses typing_extensions for Python 3.9 compatibility.
"""

from __future__ import annotations

from typing import List, Optional

from typing_extensions import NotRequired, TypedDict

# ========== Auth ==========


class RegisterResponse(TypedDict):
    message: str
    user_id: str


class RegisteredUser(TypedDict):
    id: str
    email: str
    role: str
    email_verified: bool


class RegisterWithApiKeyResponse(TypedDict):
    api_key: str
    user: RegisteredUser
    message: str


class GameOwnerProfile(TypedDict):
    id: str
    user_id: str
    company_name: str
    display_name: str
    website_url: Optional[str]
    created_at: str


class User(TypedDict):
    id: str
    email: str
    role: str
    email_verified: bool
    created_at: str
    profile: Optional[GameOwnerProfile]


class Category(TypedDict):
    id: str
    name: str
    slug: str


class Device(TypedDict):
    id: str
    name: str


class Platform(TypedDict):
    id: str
    name: str


# ========== Games ==========


class Game(TypedDict):
    id: str
    name: str
    description: Optional[str]
    instructions: Optional[str]
    build_url: Optional[str]
    cover_image_url: Optional[str]
    external_url: Optional[str]
    status: str
    created_at: str
    updated_at: Optional[str]
    categories: List[Category]
    devices: List[str]
    platforms: List[str]


class Build(TypedDict):
    id: str
    game_id: str
    created_at: str


# ========== Playtests ==========


class SlotStats(TypedDict):
    open: int
    reserved: int
    submitted: int
    accepted: int
    rejected: int
    expired: int


class PlaytestRequest(TypedDict):
    id: str
    game_id: str
    visibility: str
    quantity: int
    duration_minutes: int
    notes_for_testers: Optional[str]
    status: str
    is_free_public_trial: bool
    targeting_type: Optional[str]
    created_at: str
    slots: SlotStats


class PlaytestDetail(PlaytestRequest):
    game_name: str


# ========== Slots & Submissions (nested types) ==========


class SlotPlaytester(TypedDict):
    id: str
    display_name: str


class SlotRating(TypedDict):
    score: int
    comment: Optional[str]


class SlotRejection(TypedDict):
    reason: Optional[str]
    created_at: str


class SubmissionSummary(TypedDict):
    id: str
    video_file_size: Optional[int]
    notes: Optional[str]
    created_at: str


class TranscriptionSummary(TypedDict):
    id: str
    status: str
    selected_version: Optional[str]


class PlaytestSlot(TypedDict):
    id: str
    request_id: str
    status: str
    deadline_at: Optional[str]
    created_at: str
    playtester: Optional[SlotPlaytester]
    submission: Optional[SubmissionSummary]
    rating: Optional[SlotRating]
    rejection: Optional[SlotRejection]
    transcription: Optional[TranscriptionSummary]


class PlaytestCreateResponse(TypedDict):
    playtest: PlaytestRequest
    requires_payment: NotRequired[bool]
    price_per_playtest_cents: NotRequired[int]
    total_cents: NotRequired[int]
    slots: NotRequired[List[PlaytestSlot]]
    needs_admin_approval: NotRequired[bool]


class SlotGame(TypedDict):
    id: str
    name: str


class SlotPlaytest(TypedDict):
    id: str
    visibility: str
    duration_minutes: int


class SlotDetailTranscription(TypedDict):
    id: str
    status: str
    selected_version: Optional[str]
    key_takeaways: Optional[List[str]]


class SlotDetail(TypedDict):
    id: str
    request_id: str
    status: str
    deadline_at: Optional[str]
    created_at: str
    game: SlotGame
    playtest: SlotPlaytest
    playtester: Optional[SlotPlaytester]
    submission: Optional[SubmissionSummary]
    rating: Optional[SlotRating]
    rejection: Optional[SlotRejection]
    transcription: Optional[SlotDetailTranscription]


class DownloadUrlResponse(TypedDict):
    download_url: str
    expires_at: str


class TranscriptResponse(TypedDict):
    download_url: str
    filename: str
    version: str
    key_takeaways: List[str]


# ========== Submissions ==========


class SubmissionSlot(TypedDict):
    id: str
    request_id: str
    status: str
    reserved_by: Optional[str]
    deadline_at: Optional[str]
    created_at: str


class SubmissionDetail(TypedDict):
    id: str
    video_storage_key: str
    video_file_size: Optional[int]
    notes: Optional[str]
    created_at: str


class SubmissionPlaytest(TypedDict):
    id: str
    visibility: str
    duration_minutes: int
    is_free_public_trial: bool


class SubmissionBlockedReport(TypedDict):
    reason_code: str
    notes: Optional[str]
    reported_at: str


class Submission(TypedDict):
    slot: SubmissionSlot
    submission: Optional[SubmissionDetail]
    game: SlotGame
    playtest: SubmissionPlaytest
    playtester: Optional[SlotPlaytester]
    awaiting_admin_approval: bool
    blocked_report: Optional[SubmissionBlockedReport]
    transcription: Optional[TranscriptionSummary]


# ========== Billing ==========


class Balance(TypedDict):
    balance_cents: int
    currency: str


class Payment(TypedDict):
    id: str
    amount_cents: int
    status: str
    provider: Optional[str]
    external_id: Optional[str]
    created_at: str


class PurchaseCreditResponse(TypedDict):
    checkout_url: str
    payment_id: str
    amount_cents: int


# ========== Chat ==========


class ChatContact(TypedDict):
    id: str
    display_name: str
    company_name: NotRequired[str]
    chat_mode: NotRequired[str]
    is_unlocked: bool
    unread_count: int
    last_message_at: Optional[str]
    last_message_preview: Optional[str]
    conversation_id: Optional[str]


class ChatMessage(TypedDict):
    id: str
    conversation_id: NotRequired[str]
    sender_type: str
    sender_id: str
    content: str
    read_at: Optional[str]
    created_at: str


# ========== Notifications ==========


class Notification(TypedDict):
    id: str
    type: str
    title: str
    body: str
    read_at: Optional[str]
    created_at: str


# ========== Webhooks ==========


class Webhook(TypedDict):
    id: str
    url: str
    events: List[str]
    is_active: bool
    failure_count: int
    last_failure_at: NotRequired[Optional[str]]
    created_at: str


class WebhookCreateResponse(TypedDict):
    webhook: Webhook
    secret: str


class WebhookDelivery(TypedDict):
    id: str
    event: str
    status_code: Optional[int]
    attempt_count: int
    delivered_at: Optional[str]
    next_retry_at: Optional[str]
    created_at: str


class WebhookTestDelivery(TypedDict):
    id: str
    status_code: Optional[int]
    response_body: Optional[str]
    delivered_at: Optional[str]


class WebhookTestResponse(TypedDict):
    success: bool
    delivery: WebhookTestDelivery


# ========== Dashboard ==========


class DashboardStats(TypedDict):
    total_games: int
    active_playtests: int
    pending_reviews: int
