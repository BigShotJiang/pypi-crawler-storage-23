from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class ErrorDetail:
    field: str
    message: str


class WPGError(Exception):
    """Error returned by the We Playtest Games API."""

    def __init__(
        self,
        code: str,
        message: str,
        status: int,
        details: Optional[List[ErrorDetail]] = None,
        request_id: Optional[str] = None,
    ):
        super().__init__(message)
        self.code = code
        self.message = message
        self.status = status
        self.details = details or []
        self.request_id = request_id

    def __repr__(self) -> str:
        return f"WPGError(code={self.code!r}, status={self.status}, message={self.message!r})"
