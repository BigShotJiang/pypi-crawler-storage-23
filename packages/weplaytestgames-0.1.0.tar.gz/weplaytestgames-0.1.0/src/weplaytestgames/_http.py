"""HTTP client wrappers for sync and async usage."""

from __future__ import annotations

import asyncio
import math
import random
import re
import time
from typing import Any, Dict, Optional, Set

import httpx

from ._error import ErrorDetail, WPGError


_CAMEL_RE = re.compile(r"([a-z0-9])([A-Z])")
_SNAKE_RE = re.compile(r"_([a-z])")

_RETRYABLE_STATUS_CODES: Set[int] = {408, 429, 500, 502, 503, 504}


def _to_snake_case(s: str) -> str:
    return _CAMEL_RE.sub(r"\1_\2", s).lower()


def _to_camel_case(s: str) -> str:
    return _SNAKE_RE.sub(lambda m: m.group(1).upper(), s)


def _convert_keys(obj: Any, converter: Any) -> Any:
    if isinstance(obj, dict):
        return {converter(k): _convert_keys(v, converter) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_convert_keys(item, converter) for item in obj]
    return obj


def to_snake(obj: Any) -> Any:
    return _convert_keys(obj, _to_snake_case)


def to_camel(obj: Any) -> Any:
    return _convert_keys(obj, _to_camel_case)


def _raise_for_error(response: httpx.Response, data: Dict[str, Any]) -> None:
    error = data.get("error", {})
    meta = data.get("meta", {})
    details_raw = error.get("details", [])
    details = [ErrorDetail(field=d.get("field", ""), message=d.get("message", "")) for d in details_raw]
    raise WPGError(
        code=error.get("code", "INTERNAL_ERROR"),
        message=error.get("message", response.reason_phrase or "Unknown error"),
        status=response.status_code,
        details=details or None,
        request_id=meta.get("requestId"),
    )


def _retry_delay(attempt: int, retry_after: Optional[float] = None) -> float:
    if retry_after is not None and retry_after > 0:
        return min(retry_after, 8.0)
    base = 0.5 * math.pow(2, attempt)
    jitter = random.random() * 0.25
    return min(base + jitter, 8.0)


def _is_retryable_network_error(exc: Exception) -> bool:
    return isinstance(exc, (httpx.ConnectError, httpx.ReadTimeout, httpx.ConnectTimeout))


class SyncHttpClient:
    def __init__(
        self,
        api_key: Optional[str],
        base_url: str,
        timeout: float = 30.0,
        max_retries: int = 2,
    ):
        headers: Dict[str, str] = {
            "Content-Type": "application/json",
            "User-Agent": "weplaytestgames-python/0.1.0",
        }
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        self._client = httpx.Client(
            base_url=base_url,
            headers=headers,
            timeout=timeout,
        )
        self._max_retries = max_retries

    def request(
        self,
        method: str,
        path: str,
        *,
        json: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        headers: Dict[str, str] = {}
        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key

        # Filter None values from params
        clean_params = {k: v for k, v in (params or {}).items() if v is not None} or None

        # Convert request body keys to camelCase
        body = to_camel(json) if json else None

        last_error: Optional[Exception] = None

        for attempt in range(self._max_retries + 1):
            try:
                response = self._client.request(
                    method, path, json=body, params=clean_params, headers=headers
                )

                data = response.json()

                if not response.is_success:
                    if attempt < self._max_retries and response.status_code in _RETRYABLE_STATUS_CODES:
                        retry_after_header = response.headers.get("Retry-After")
                        retry_after = float(retry_after_header) if retry_after_header else None
                        time.sleep(_retry_delay(attempt, retry_after))
                        continue
                    _raise_for_error(response, data)

                # Convert response keys to snake_case
                return to_snake(data)
            except WPGError:
                raise
            except Exception as exc:
                last_error = exc
                if attempt < self._max_retries and _is_retryable_network_error(exc):
                    time.sleep(_retry_delay(attempt))
                    continue
                raise

        raise last_error  # type: ignore[misc]

    def close(self) -> None:
        self._client.close()


class AsyncHttpClient:
    def __init__(
        self,
        api_key: Optional[str],
        base_url: str,
        timeout: float = 30.0,
        max_retries: int = 2,
    ):
        headers: Dict[str, str] = {
            "Content-Type": "application/json",
            "User-Agent": "weplaytestgames-python/0.1.0",
        }
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        self._client = httpx.AsyncClient(
            base_url=base_url,
            headers=headers,
            timeout=timeout,
        )
        self._max_retries = max_retries

    async def request(
        self,
        method: str,
        path: str,
        *,
        json: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        headers: Dict[str, str] = {}
        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key

        clean_params = {k: v for k, v in (params or {}).items() if v is not None} or None
        body = to_camel(json) if json else None

        last_error: Optional[Exception] = None

        for attempt in range(self._max_retries + 1):
            try:
                response = await self._client.request(
                    method, path, json=body, params=clean_params, headers=headers
                )

                data = response.json()

                if not response.is_success:
                    if attempt < self._max_retries and response.status_code in _RETRYABLE_STATUS_CODES:
                        retry_after_header = response.headers.get("Retry-After")
                        retry_after = float(retry_after_header) if retry_after_header else None
                        await asyncio.sleep(_retry_delay(attempt, retry_after))
                        continue
                    _raise_for_error(response, data)

                return to_snake(data)
            except WPGError:
                raise
            except Exception as exc:
                last_error = exc
                if attempt < self._max_retries and _is_retryable_network_error(exc):
                    await asyncio.sleep(_retry_delay(attempt))
                    continue
                raise

        raise last_error  # type: ignore[misc]

    async def close(self) -> None:
        await self._client.aclose()
