"""
End-to-end playtest workflow example.

This script shows how a game studio would:
  1. Create a game and order playtests
  2. Set up a webhook to get notified when playtests complete
  3. Listen for webhook events via a tiny HTTP server
  4. Download the video and transcript for each completed playtest

Usage:
  python examples/playtest_workflow.py

Environment variables:
  WPG_API_KEY   - Your API key (wpg_sk_...)
  WEBHOOK_URL   - Public HTTPS URL that points to this server (e.g. via ngrok)
  DOWNLOAD_DIR  - Local folder for downloads (default: ./downloads)
"""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import sys
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path

import httpx

from weplaytestgames import WPGClient, WPGError

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

API_KEY = os.environ.get("WPG_API_KEY")
WEBHOOK_URL = os.environ.get("WEBHOOK_URL")  # e.g. https://abc123.ngrok.app/webhook
DOWNLOAD_DIR = os.environ.get("DOWNLOAD_DIR", "./downloads")
WEBHOOK_PORT = 4000

if not API_KEY:
    print("Set WPG_API_KEY to your API key", file=sys.stderr)
    sys.exit(1)
if not WEBHOOK_URL:
    print("Set WEBHOOK_URL to a public HTTPS URL (e.g. from ngrok)", file=sys.stderr)
    sys.exit(1)

client = WPGClient(api_key=API_KEY)

webhook_secret: str = ""


# ---------------------------------------------------------------------------
# Step 1 — Create a game (or pick an existing one)
# ---------------------------------------------------------------------------

def get_or_create_game() -> str:
    # Check if we already have a game
    page = client.games.list(limit=1).get_page()
    if page.data:
        game = page.data[0]
        print(f'Using existing game: "{game["name"]}" ({game["id"]})')
        return game["id"]

    # Otherwise create one
    game = client.games.create(
        name="My Awesome Game",
        build_url="https://store.steampowered.com/app/123456",
        description="An indie adventure game with puzzle mechanics.",
        tags=[],  # add category UUIDs from client.auth.categories()
    )
    print(f'Created game: "{game["name"]}" ({game["id"]})')
    return game["id"]


# ---------------------------------------------------------------------------
# Step 2 — Register a webhook for slot events
# ---------------------------------------------------------------------------

def setup_webhook() -> str:
    global webhook_secret

    # Clean up any existing webhooks pointing to our URL
    existing = client.webhooks.list()
    for wh in existing:
        if wh["url"] == WEBHOOK_URL:
            client.webhooks.delete(wh["id"])
            print(f"Deleted old webhook {wh['id']}")

    result = client.webhooks.create(
        url=WEBHOOK_URL,
        events=["slot.submitted", "slot.accepted", "slot.rejected", "slot.expired"],
    )

    webhook_secret = result["secret"]
    webhook = result["webhook"]
    print(f"Webhook created: {webhook['id']}")
    print(f"  URL:    {webhook['url']}")
    print(f"  Events: {', '.join(webhook['events'])}")
    print(f"  Secret: {webhook_secret[:8]}...")
    return webhook["id"]


# ---------------------------------------------------------------------------
# Step 3 — Order playtests
# ---------------------------------------------------------------------------

def order_playtests(game_id: str) -> str:
    result = client.playtests.create(
        game_id=game_id,
        visibility="public",
        quantity=2,
        duration_minutes=30,
        notes_for_testers="Please focus on the first 3 levels and let me know if any puzzles feel unfair.",
    )

    playtest = result["playtest"]
    print(f"\nPlaytest created: {playtest['id']}")
    print(f"  Status: {playtest['status']}")
    if result.get("requires_payment"):
        total = result.get("total_cents", 0)
        print(f"  Payment required: ${total / 100:.2f}")
        print("  (Complete payment in the dashboard to activate the playtest)")

    return playtest["id"]


# ---------------------------------------------------------------------------
# Step 4 — Download video + transcript for a completed slot
# ---------------------------------------------------------------------------

def download_slot_artifacts(slot_id: str) -> None:
    Path(DOWNLOAD_DIR).mkdir(parents=True, exist_ok=True)

    slot = client.slots.get(slot_id)
    playtester_name = slot.get("playtester", {}).get("display_name", "unknown") if slot.get("playtester") else "unknown"
    print(f"\nDownloading artifacts for slot {slot_id}...")
    print(f"  Playtester: {playtester_name}")
    print(f"  Status:     {slot['status']}")

    # Download video
    try:
        download_info = client.slots.download_url(slot_id)
        download_url = download_info["download_url"]
        expires_at = download_info["expires_at"]
        print(f"  Video URL expires: {expires_at}")

        video_path = Path(DOWNLOAD_DIR) / f"{slot_id}-video.mp4"
        with httpx.stream("GET", download_url) as response:
            response.raise_for_status()
            with open(video_path, "wb") as f:
                for chunk in response.iter_bytes():
                    f.write(chunk)
        print(f"  Video saved to {video_path}")
    except WPGError as err:
        if err.code == "NOT_FOUND":
            print("  No video available yet")
        else:
            print(f"  Video download failed: {err}")
    except Exception as err:
        print(f"  Video download failed: {err}")

    # Download transcript
    try:
        transcript = client.slots.transcript(slot_id)
        print(f"  Transcript version: {transcript['version']}")
        if transcript.get("key_takeaways"):
            print("  Key takeaways:")
            for t in transcript["key_takeaways"]:
                print(f"    - {t}")

        transcript_path = Path(DOWNLOAD_DIR) / f"{slot_id}-{transcript['filename']}"
        with httpx.stream("GET", transcript["download_url"]) as response:
            response.raise_for_status()
            with open(transcript_path, "wb") as f:
                for chunk in response.iter_bytes():
                    f.write(chunk)
        print(f"  Transcript saved to {transcript_path}")
    except WPGError as err:
        if err.code == "NOT_FOUND":
            print("  Transcript not available yet (still processing)")
        else:
            print(f"  Transcript download failed: {err}")
    except Exception as err:
        print(f"  Transcript download failed: {err}")


# ---------------------------------------------------------------------------
# Step 5 — Webhook listener
# ---------------------------------------------------------------------------

def verify_signature(payload: bytes, signature: str) -> bool:
    expected = hmac.new(
        webhook_secret.encode(), payload, hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(signature, expected)


class WebhookHandler(BaseHTTPRequestHandler):
    def do_POST(self) -> None:
        if self.path != "/webhook":
            self.send_response(404)
            self.end_headers()
            return

        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length)

        # Verify signature
        signature = self.headers.get("X-WPG-Signature", "")
        if signature and not verify_signature(body, signature):
            print("Webhook signature mismatch — ignoring")
            self.send_response(401)
            self.end_headers()
            return

        # Acknowledge immediately
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps({"ok": True}).encode())

        # Process event
        event = json.loads(body)
        event_type = event.get("event", "")
        print(f"\n--- Webhook event: {event_type} ---")

        if event_type == "slot.submitted":
            slot_id = event.get("data", {}).get("slotId", "")
            print(f"Slot {slot_id} has a new submission — reviewing...")
            # Auto-accept for this demo (in production you'd review the video first)
            try:
                client.slots.accept(slot_id)
                print("Submission accepted!")
            except Exception as err:
                print(f"Failed to accept: {err}")

        if event_type == "slot.accepted":
            slot_id = event.get("data", {}).get("slotId", "")
            print(f"Slot {slot_id} accepted — downloading artifacts...")
            download_slot_artifacts(slot_id)

    def log_message(self, format: str, *args: object) -> None:
        # Suppress default request logging
        pass


def start_webhook_server() -> None:
    server = HTTPServer(("", WEBHOOK_PORT), WebhookHandler)
    print(f"\nWebhook server listening on http://localhost:{WEBHOOK_PORT}/webhook")
    print("Waiting for playtest events...\n")
    server.serve_forever()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    print("=== We Playtest Games — SDK Example ===\n")

    # Show who we are
    user = client.auth.me()
    print(f"Logged in as {user['email']} ({user['role']})")

    balance = client.billing.get_balance()
    print(f"Credit balance: ${balance['balance_cents'] / 100:.2f}\n")

    # Set up game + webhook + playtests
    game_id = get_or_create_game()
    setup_webhook()
    order_playtests(game_id)

    # Start listening for webhook events
    start_webhook_server()


if __name__ == "__main__":
    main()
