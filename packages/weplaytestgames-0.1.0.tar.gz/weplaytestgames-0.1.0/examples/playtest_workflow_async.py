"""
Async end-to-end playtest workflow example.

This is the async version of playtest_workflow.py, using AsyncWPGClient.
It shows how a game studio would:
  1. Create a game and order playtests
  2. Set up a webhook to get notified when playtests complete
  3. Listen for webhook events via a tiny HTTP server (sync, in a thread)
  4. Download the video and transcript for each completed playtest

Usage:
  python examples/playtest_workflow_async.py

Environment variables:
  WPG_API_KEY   - Your API key (wpg_sk_...)
  WEBHOOK_URL   - Public HTTPS URL that points to this server (e.g. via ngrok)
  DOWNLOAD_DIR  - Local folder for downloads (default: ./downloads)
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

import httpx

from weplaytestgames import AsyncWPGClient, WPGError, verify_webhook_signature

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

API_KEY = os.environ.get("WPG_API_KEY")
WEBHOOK_URL = os.environ.get("WEBHOOK_URL")  # e.g. https://abc123.ngrok.app/webhook
DOWNLOAD_DIR = os.environ.get("DOWNLOAD_DIR", "./downloads")
WEBHOOK_PORT = 4000

if not API_KEY:
    print("Set WPG_API_KEY to your API key", file=sys.stderr)
    sys.exit(1)
if not WEBHOOK_URL:
    print("Set WEBHOOK_URL to a public HTTPS URL (e.g. from ngrok)", file=sys.stderr)
    sys.exit(1)

webhook_secret: str = ""


# ---------------------------------------------------------------------------
# Step 1 — Create a game (or pick an existing one)
# ---------------------------------------------------------------------------

async def get_or_create_game(client: AsyncWPGClient) -> str:
    page = await client.games.list(limit=1).get_page()
    if page.data:
        game = page.data[0]
        print(f'Using existing game: "{game["name"]}" ({game["id"]})')
        return game["id"]

    game = await client.games.create(
        name="My Awesome Game",
        build_url="https://store.steampowered.com/app/123456",
        description="An indie adventure game with puzzle mechanics.",
        tags=[],
    )
    print(f'Created game: "{game["name"]}" ({game["id"]})')
    return game["id"]


# ---------------------------------------------------------------------------
# Step 2 — Register a webhook for slot events
# ---------------------------------------------------------------------------

async def setup_webhook(client: AsyncWPGClient) -> str:
    global webhook_secret

    existing = await client.webhooks.list()
    for wh in existing:
        if wh["url"] == WEBHOOK_URL:
            await client.webhooks.delete(wh["id"])
            print(f"Deleted old webhook {wh['id']}")

    result = await client.webhooks.create(
        url=WEBHOOK_URL,
        events=["slot.submitted", "slot.accepted", "slot.rejected", "slot.expired"],
    )

    webhook_secret = result["secret"]
    webhook = result["webhook"]
    print(f"Webhook created: {webhook['id']}")
    print(f"  URL:    {webhook['url']}")
    print(f"  Events: {', '.join(webhook['events'])}")
    print(f"  Secret: {webhook_secret[:8]}...")
    return webhook["id"]


# ---------------------------------------------------------------------------
# Step 3 — Order playtests
# ---------------------------------------------------------------------------

async def order_playtests(client: AsyncWPGClient, game_id: str) -> str:
    result = await client.playtests.create(
        game_id=game_id,
        visibility="public",
        quantity=2,
        duration_minutes=30,
        notes_for_testers="Please focus on the first 3 levels and let me know if any puzzles feel unfair.",
    )

    playtest = result["playtest"]
    print(f"\nPlaytest created: {playtest['id']}")
    print(f"  Status: {playtest['status']}")
    if result.get("requires_payment"):
        total = result.get("total_cents", 0)
        print(f"  Payment required: ${total / 100:.2f}")
        print("  (Complete payment in the dashboard to activate the playtest)")

    return playtest["id"]


# ---------------------------------------------------------------------------
# Step 4 — Download video + transcript for a completed slot
# ---------------------------------------------------------------------------

async def download_slot_artifacts(client: AsyncWPGClient, slot_id: str) -> None:
    Path(DOWNLOAD_DIR).mkdir(parents=True, exist_ok=True)

    slot = await client.slots.get(slot_id)
    playtester_name = (
        slot.get("playtester", {}).get("display_name", "unknown")
        if slot.get("playtester")
        else "unknown"
    )
    print(f"\nDownloading artifacts for slot {slot_id}...")
    print(f"  Playtester: {playtester_name}")
    print(f"  Status:     {slot['status']}")

    # Download video
    try:
        download_info = await client.slots.download_url(slot_id)
        download_url = download_info["download_url"]
        expires_at = download_info["expires_at"]
        print(f"  Video URL expires: {expires_at}")

        video_path = Path(DOWNLOAD_DIR) / f"{slot_id}-video.mp4"
        async with httpx.AsyncClient() as http:
            async with http.stream("GET", download_url) as response:
                response.raise_for_status()
                with open(video_path, "wb") as f:
                    async for chunk in response.aiter_bytes():
                        f.write(chunk)
        print(f"  Video saved to {video_path}")
    except WPGError as err:
        if err.code == "NOT_FOUND":
            print("  No video available yet")
        else:
            print(f"  Video download failed: {err}")
    except Exception as err:
        print(f"  Video download failed: {err}")

    # Download transcript
    try:
        transcript = await client.slots.transcript(slot_id)
        print(f"  Transcript version: {transcript['version']}")
        if transcript.get("key_takeaways"):
            print("  Key takeaways:")
            for t in transcript["key_takeaways"]:
                print(f"    - {t}")

        transcript_path = Path(DOWNLOAD_DIR) / f"{slot_id}-{transcript['filename']}"
        async with httpx.AsyncClient() as http:
            async with http.stream("GET", transcript["download_url"]) as response:
                response.raise_for_status()
                with open(transcript_path, "wb") as f:
                    async for chunk in response.aiter_bytes():
                        f.write(chunk)
        print(f"  Transcript saved to {transcript_path}")
    except WPGError as err:
        if err.code == "NOT_FOUND":
            print("  Transcript not available yet (still processing)")
        else:
            print(f"  Transcript download failed: {err}")
    except Exception as err:
        print(f"  Transcript download failed: {err}")


# ---------------------------------------------------------------------------
# Step 5 — Webhook listener (sync HTTP server run in a thread)
# ---------------------------------------------------------------------------

# Shared queue for passing events from the sync server thread to the async loop
_event_queue: asyncio.Queue[dict] = asyncio.Queue()


class WebhookHandler(BaseHTTPRequestHandler):
    def do_POST(self) -> None:
        if self.path != "/webhook":
            self.send_response(404)
            self.end_headers()
            return

        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length)

        # Verify signature using the SDK utility
        signature = self.headers.get("X-WPG-Signature", "")
        timestamp = self.headers.get("X-WPG-Timestamp", "")
        if signature and not verify_webhook_signature(
            payload=body.decode(),
            signature=signature,
            timestamp=timestamp,
            secret=webhook_secret,
        ):
            print("Webhook signature mismatch -- ignoring")
            self.send_response(401)
            self.end_headers()
            return

        # Acknowledge immediately
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps({"ok": True}).encode())

        # Push event to the async queue
        event = json.loads(body)
        _event_queue.put_nowait(event)

    def log_message(self, format: str, *args: object) -> None:
        pass


def _run_sync_server() -> None:
    server = HTTPServer(("", WEBHOOK_PORT), WebhookHandler)
    server.serve_forever()


async def process_events(client: AsyncWPGClient) -> None:
    """Process webhook events from the queue."""
    while True:
        event = await _event_queue.get()
        event_type = event.get("event", "")
        print(f"\n--- Webhook event: {event_type} ---")

        if event_type == "slot.submitted":
            slot_id = event.get("data", {}).get("slotId", "")
            print(f"Slot {slot_id} has a new submission -- reviewing...")
            try:
                await client.slots.accept(slot_id)
                print("Submission accepted!")
            except Exception as err:
                print(f"Failed to accept: {err}")

        if event_type == "slot.accepted":
            slot_id = event.get("data", {}).get("slotId", "")
            print(f"Slot {slot_id} accepted -- downloading artifacts...")
            await download_slot_artifacts(client, slot_id)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

async def main() -> None:
    print("=== We Playtest Games -- Async SDK Example ===\n")

    async with AsyncWPGClient(api_key=API_KEY) as client:
        # Show who we are
        user = await client.auth.me()
        print(f"Logged in as {user['email']} ({user['role']})")

        balance = await client.billing.get_balance()
        print(f"Credit balance: ${balance['balance_cents'] / 100:.2f}\n")

        # Set up game + webhook + playtests
        game_id = await get_or_create_game(client)
        await setup_webhook(client)
        await order_playtests(client, game_id)

        # Start the sync webhook server in a background thread
        print(f"\nWebhook server listening on http://localhost:{WEBHOOK_PORT}/webhook")
        print("Waiting for playtest events...\n")
        asyncio.get_event_loop().run_in_executor(None, _run_sync_server)

        # Process events as they arrive
        await process_events(client)


if __name__ == "__main__":
    asyncio.run(main())
