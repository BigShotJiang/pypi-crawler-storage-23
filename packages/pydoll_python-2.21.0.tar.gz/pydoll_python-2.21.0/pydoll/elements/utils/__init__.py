from pydoll.elements.utils.selector_parser import SelectorParser

__all__ = ['SelectorParser']
