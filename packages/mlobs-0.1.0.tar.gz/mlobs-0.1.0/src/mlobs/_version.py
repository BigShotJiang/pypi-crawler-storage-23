# This file is read by hatchling at build time via [tool.hatch.version].
# Do not import anything here.
__version__ = "0.1.0"
