# Transactions

Record and query financial transactions.

## Create a Transaction

```python
from decimal import Decimal
from datetime import date
from finwise import FinWise

client = FinWise(api_key="your-api-key")

transaction = client.transactions.create(
    account_id="acc_123",
    amount=Decimal("-50.00"),  # Negative for expenses
    transaction_date=date.today(),
    description="Grocery shopping",
    category_id="cat_groceries",
    type="expense",
)
```

### Transaction Types

| Type | Description |
|------|-------------|
| `income` | Money coming in |
| `expense` | Money going out |
| `transfer` | Transfer between accounts |

!!! tip "Amount Sign Convention"
    Use negative amounts for expenses and positive amounts for income. This makes calculations straightforward.

## List Transactions

```python
# Basic listing
transactions = client.transactions.list()

# With date filters
transactions = client.transactions.list(
    start_date=date(2024, 1, 1),
    end_date=date(2024, 1, 31),
    type="expense",
)

for txn in transactions:
    print(f"{txn.transaction_date}: {txn.description} ({txn.amount.format()})")
```

!!! note "Filtering"
    The API supports filtering by `category_id`, `start_date`, `end_date`, and `type`. Filtering by account ID is not supported.

## Archive a Transaction

```python
client.transactions.archive("txn_123")
```
