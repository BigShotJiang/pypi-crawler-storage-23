# Sample Optimization Configurations

This directory contains sample configuration files for various optimization problems that can be solved using `pyoptima`.

## Configuration Files

### Portfolio Optimization

- **`portfolio_basic.json`** - Basic portfolio optimization with 4 assets, maximizing returns with budget and diversification constraints
- **`portfolio_large.json`** - Larger portfolio with 8 assets and sector constraints, using GUROBI solver
- **`portfolio_min_risk.json`** - Risk-minimizing portfolio with minimum return constraint

### Scheduling Problems

- **`nurse_scheduling.json`** - Nurse shift scheduling problem with coverage requirements and shift limits
- **`assignment.json`** - Assignment problem: assigning workers to tasks to minimize total cost

### Production & Logistics

- **`production_planning.json`** - Production planning with multiple products, machines, and resource constraints
- **`transportation.json`** - Transportation problem: minimizing shipping costs from warehouses to stores
- **`cutting_stock.json`** - Cutting stock problem: minimizing waste when cutting materials into required sizes

### Classic Problems

- **`knapsack.json`** - 0/1 Knapsack problem: maximizing value while respecting weight constraint

## Usage

Run any configuration file using the CLI:

```bash
pyoptima optimize data/portfolio_basic.json
```

Or with output file:

```bash
pyoptima optimize data/portfolio_basic.json --output results.json --pretty
```

## Configuration Format

All configuration files follow the same JSON structure:

```json
{
  "meta": {
    "job_id": "unique-job-id",
    "solver": "CBC",  // "CBC", "GUROBI", or "GLPK"
    "time_limit_seconds": 30  // Optional
  },
  "variables": [
    {
      "id": "variable_name",
      "type": "Continuous",  // "Continuous", "Binary", or "Integer"
      "lb": 0,  // Optional lower bound
      "ub": 1.0  // Optional upper bound
    }
  ],
  "objective": {
    "direction": "Maximize",  // or "Minimize"
    "terms": [
      { "var": "variable_name", "coef": 1.0 }
    ]
  },
  "constraints": [
    {
      "id": "constraint_name",
      "lower_bound": null,  // Optional
      "upper_bound": 1.0,  // Optional
      "terms": [
        { "var": "variable_name", "coef": 1.0 }
      ]
    }
  ]
}
```

## Solver Selection

- **CBC** - Coin-or Branch and Cut, open-source, good for most problems
- **GUROBI** - Commercial solver, fastest for large problems (requires license)
- **GLPK** - GNU Linear Programming Kit, open-source alternative

## Notes

- Binary variables don't need bounds (they're automatically 0 or 1)
- Integer variables should have appropriate bounds
- Continuous variables can have bounds or be unbounded
- Constraints can have both lower and upper bounds, or just one
- Time limits are optional but recommended for large problems
