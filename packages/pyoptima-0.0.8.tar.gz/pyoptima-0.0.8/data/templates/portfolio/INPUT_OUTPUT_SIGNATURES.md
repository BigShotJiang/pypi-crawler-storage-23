# Portfolio Optimization Input/Output Signatures

## Summary

**All portfolio optimization methods share the same output signature**, but have different input requirements based on the optimization objective.

## Input Signature

### Base Structure (All Methods)
```json
{
  "template": "portfolio",
  "data": {
    "expected_returns": [0.12, 0.10, 0.08, ...],
    "covariance_matrix": [[0.04, 0.01, ...], ...],
    "symbols": ["AAPL", "GOOGL", ...],
    "objective": "min_volatility"
  }
}
```

### Required Fields by Method Category

#### 1. Efficient Frontier Methods
**Methods:** `min_volatility`, `max_sharpe`, `max_return`, `efficient_return`, `efficient_risk`, `max_utility`

**Required:**
- `expected_returns`
- `covariance_matrix`
- `objective`

**Optional:**
- `symbols`
- `weight_bounds` or `min_weight`/`max_weight`
- `risk_free_rate` (for `max_sharpe`)
- `target_return` (for `efficient_return`)
- `target_volatility` (for `efficient_risk`)
- `risk_aversion` (for `max_utility`)

#### 2. Black-Litterman Methods
**Methods:** `black_litterman_max_sharpe`, `black_litterman_min_volatility`, `black_litterman_quadratic_utility`

**Required:**
- `expected_returns`
- `covariance_matrix`
- `objective`
- `market_caps` OR (`views` + `view_cov`)

**Optional:**
- `symbols`
- `weight_bounds`
- `risk_free_rate`
- `risk_aversion`
- `tau` (scaling factor, default: 1.0)

#### 3. CVaR Methods
**Methods:** `min_cvar`, `efficient_cvar_risk`, `efficient_cvar_return`

**Required:**
- `expected_returns`
- `covariance_matrix`
- `returns` (historical returns matrix)
- `objective`

**Optional:**
- `symbols`
- `weight_bounds`
- `confidence_level` (default: 0.05)
- `target_cvar` (for `efficient_cvar_risk`)
- `target_return` (for `efficient_cvar_return`)

#### 4. CDaR Methods
**Methods:** `min_cdar`, `efficient_cdar_risk`, `efficient_cdar_return`

**Required:**
- `expected_returns`
- `covariance_matrix`
- `returns` (historical returns matrix)
- `objective`

**Optional:**
- `symbols`
- `weight_bounds`
- `confidence_level` (default: 0.05)
- `target_cdar` (for `efficient_cdar_risk`)
- `target_return` (for `efficient_cdar_return`)

#### 5. Semivariance Methods
**Methods:** `min_semivariance`, `efficient_semivariance_risk`, `efficient_semivariance_return`

**Required:**
- `expected_returns`
- `covariance_matrix`
- `returns` (historical returns matrix)
- `objective`

**Optional:**
- `symbols`
- `weight_bounds`
- `benchmark` (default: 0.0)
- `target_semivariance` (for `efficient_semivariance_risk`)
- `target_return` (for `efficient_semivariance_return`)

#### 6. CLA Methods
**Methods:** `cla_min_volatility`, `cla_max_sharpe`

**Required:**
- `expected_returns`
- `covariance_matrix`
- `objective`

**Optional:**
- `symbols`
- `weight_bounds`
- `risk_free_rate` (for `cla_max_sharpe`)

#### 7. Hierarchical Methods
**Methods:** `hierarchical_min_volatility`, `hierarchical_max_sharpe`

**Required:**
- `expected_returns`
- `covariance_matrix`
- `objective`

**Optional:**
- `symbols`
- `weight_bounds`
- `risk_free_rate` (for `hierarchical_max_sharpe`)

#### 8. Maximum Diversification
**Methods:** `max_diversification`, `max_diversification_index`

**Required:**
- `expected_returns`
- `covariance_matrix`
- `objective`

**Optional:**
- `symbols`
- `weight_bounds`

#### 9. Risk Parity
**Methods:** `risk_parity`, `equal_risk_contribution`

**Required:**
- `expected_returns`
- `covariance_matrix`
- `objective`

**Optional:**
- `symbols`
- `weight_bounds`

#### 10. Transaction Cost-Aware
**Methods:** `max_sharpe_with_costs`, `min_volatility_with_costs`

**Required:**
- `expected_returns`
- `covariance_matrix`
- `objective`
- `transaction_costs`

**Optional:**
- `symbols`
- `weight_bounds`
- `risk_free_rate` (for `max_sharpe_with_costs`)
- `current_weights` (for accurate cost calculation)
- `min_net_return` (for `min_volatility_with_costs`)

#### 11. Momentum-Filtered
**Methods:** `momentum_filtered_max_sharpe`, `momentum_filtered_min_volatility`

**Required:**
- `expected_returns`
- `covariance_matrix`
- `returns` (historical returns matrix)
- `objective`

**Optional:**
- `symbols`
- `weight_bounds`
- `risk_free_rate` (for `momentum_filtered_max_sharpe`)
- `momentum_period` (default: 20)
- `momentum_top_pct` (default: 0.2)

#### 12. Factor-Based
**Methods:** `factor_based_selection`

**Required:**
- `expected_returns`
- `covariance_matrix`
- `objective`
- `factor_data`

**Optional:**
- `symbols`
- `weight_bounds`
- `factor_weights`
- `max_volatility`

### Common Constraints (All Methods)
All methods support these optional constraints:

- **Weight Bounds:**
  ```json
  "weight_bounds": [0, 1]
  // OR
  "min_weight": 0.0,
  "max_weight": 1.0
  ```

- **Cardinality (Max Assets):**
  ```json
  "max_assets": 10,
  "min_position_size": 0.05
  ```

- **Turnover:**
  ```json
  "current_weights": {"AAPL": 0.25, ...},
  "max_turnover": 0.20
  ```

## Output Signature

**All methods return the same structure:**

```json
{
  "status": "optimal",
  "weights": {
    "AAPL": 0.25,
    "GOOGL": 0.35,
    "MSFT": 0.20,
    "AMZN": 0.15,
    "TSLA": 0.05
  },
  "portfolio_return": 0.12,
  "portfolio_volatility": 0.15,
  "portfolio_variance": 0.0225,
  "sharpe_ratio": 0.67,
  "objective_value": 0.0225
}
```

### Output Fields

- **`status`**: Optimization status (`"optimal"`, `"feasible"`, `"infeasible"`, `"error"`)
- **`weights`**: Dictionary mapping asset symbols to optimal weights
- **`portfolio_return`**: Expected portfolio return
- **`portfolio_volatility`**: Portfolio volatility (standard deviation)
- **`portfolio_variance`**: Portfolio variance
- **`sharpe_ratio`**: Sharpe ratio (if `risk_free_rate` provided)
- **`objective_value`**: Value of the objective function

### Method-Specific Output Fields

Some methods include additional metrics:

- **CVaR methods:** `cvar` - Conditional Value at Risk
- **CDaR methods:** `cdar` - Conditional Drawdown at Risk
- **Semivariance methods:** 
  - `semivariance` - Semivariance value
  - `sortino_ratio` - Sortino ratio (downside Sharpe)

## Data Format Notes

### Arrays/Matrices
All numeric arrays can be provided as:
- Python lists: `[0.12, 0.10, 0.08]`
- NumPy arrays: `np.array([0.12, 0.10, 0.08])`
- Pandas Series/DataFrames: `pd.Series([0.12, 0.10, 0.08], index=["AAPL", "GOOGL", "MSFT"])`

### Historical Returns Matrix
For methods requiring `returns`:
- **Format:** 2D array where rows = time periods, columns = assets
- **Example:**
  ```json
  "returns": [
    [0.01, 0.008, 0.006],  // Day 1 returns for assets 1, 2, 3
    [-0.005, -0.003, -0.002],  // Day 2 returns
    [0.015, 0.012, 0.010]  // Day 3 returns
  ]
  ```

### Market Capitalizations
For Black-Litterman methods:
- **Format:** Array of market cap values (in same order as assets)
- **Example:** `[2500000000000, 1800000000000, ...]` (in dollars)

### Views (Black-Litterman)
- **`views`**: Array of expected returns from investor views
- **`view_cov`**: Covariance matrix of view uncertainty

## Quick Reference Table

| Method Category | Requires `returns`? | Requires `market_caps`? | Requires `views`? | Requires `target_*`? |
|----------------|---------------------|------------------------|-------------------|---------------------|
| Efficient Frontier | ❌ | ❌ | ❌ | ⚠️ (some methods) |
| Black-Litterman | ❌ | ✅ OR `views` | ⚠️ (optional) | ❌ |
| CVaR | ✅ | ❌ | ❌ | ⚠️ (some methods) |
| CDaR | ✅ | ❌ | ❌ | ⚠️ (some methods) |
| Semivariance | ✅ | ❌ | ❌ | ⚠️ (some methods) |
| CLA | ❌ | ❌ | ❌ | ❌ |
| Hierarchical | ❌ | ❌ | ❌ | ❌ |
| Max Diversification | ❌ | ❌ | ❌ | ❌ |
| Risk Parity | ❌ | ❌ | ❌ | ❌ |
| Transaction Costs | ❌ | ❌ | ❌ | ❌ |
| Momentum-Filtered | ✅ | ❌ | ❌ | ❌ |
| Factor-Based | ❌ | ❌ | ❌ | ❌ |

Legend:
- ✅ = Required
- ⚠️ = Required for some methods in category
- ❌ = Not required
