# Portfolio Optimization Configuration Templates

This directory contains configuration file templates for all portfolio optimization methods in PyOptima.

## Input/Output Signatures

### Input Signature
**All methods share a common base structure**, but have method-specific requirements:

**Common Required Fields:**
- `expected_returns`: List/array of expected returns for each asset
- `covariance_matrix`: 2D matrix of asset return covariances
- `objective`: String specifying the optimization objective

**Common Optional Fields:**
- `symbols`: List of asset names/identifiers
- `weight_bounds`: [min, max] weight bounds (default: [0, 1])
- `risk_free_rate`: Risk-free rate (default: 0.0)

**Method-Specific Requirements:**
- **CVaR/CDaR/Semivariance methods**: Require `returns` (historical returns matrix)
- **Black-Litterman methods**: Require `market_caps` or `views` + `view_cov`
- **Efficient return/risk methods**: Require `target_return` or `target_volatility`
- **Transaction cost methods**: Require `transaction_costs` and optionally `current_weights`
- **Momentum methods**: Require `returns` (historical)
- **Factor-based**: Require `factor_data`

### Output Signature
**All methods return the same structure:**
```json
{
  "status": "optimal",
  "weights": {"AAPL": 0.25, "GOOGL": 0.35, ...},
  "portfolio_return": 0.12,
  "portfolio_volatility": 0.15,
  "portfolio_variance": 0.0225,
  "sharpe_ratio": 0.67,
  "objective_value": 0.0225
}
```

Additional fields may be present for specific methods:
- `cvar`: For CVaR methods
- `cdar`: For CDaR methods
- `semivariance`: For semivariance methods
- `sortino_ratio`: For semivariance methods

## Template Categories

### 1. Efficient Frontier Methods
Basic mean-variance optimization:
- `min_volatility.json` - Minimize portfolio variance
- `max_sharpe.json` - Maximize Sharpe ratio
- `max_return.json` - Maximize expected return
- `efficient_return.json` - Minimize volatility for target return
- `efficient_risk.json` - Maximize return for target volatility
- `max_utility.json` - Maximize quadratic utility

### 2. Black-Litterman Methods
Market equilibrium + investor views:
- `black_litterman_max_sharpe.json` - BL with max Sharpe
- `black_litterman_min_volatility.json` - BL with min volatility
- `black_litterman_quadratic_utility.json` - BL with utility function

### 3. CVaR Methods (Conditional Value at Risk)
Tail risk optimization:
- `min_cvar.json` - Minimize CVaR
- `efficient_cvar_risk.json` - Maximize return for target CVaR
- `efficient_cvar_return.json` - Minimize CVaR for target return

### 4. CDaR Methods (Conditional Drawdown at Risk)
Drawdown-based risk:
- `min_cdar.json` - Minimize CDaR
- `efficient_cdar_risk.json` - Maximize return for target CDaR
- `efficient_cdar_return.json` - Minimize CDaR for target return

### 5. Semivariance Methods
Downside risk optimization:
- `min_semivariance.json` - Minimize semivariance
- `efficient_semivariance_risk.json` - Maximize return for target semivariance
- `efficient_semivariance_return.json` - Minimize semivariance for target return

### 6. CLA Methods (Critical Line Algorithm)
- `cla_min_volatility.json` - CLA for minimum volatility
- `cla_max_sharpe.json` - CLA for maximum Sharpe

### 7. Hierarchical Methods
- `hierarchical_min_volatility.json` - HRP for minimum volatility
- `hierarchical_max_sharpe.json` - HRP for maximum Sharpe

### 8. Advanced Methods
- `max_diversification.json` - Maximum diversification ratio
- `risk_parity.json` - Equal risk contribution
- `max_sharpe_with_costs.json` - Sharpe with transaction costs
- `momentum_filtered_max_sharpe.json` - Momentum-filtered Sharpe
- `factor_based_selection.json` - Factor-based asset selection

## Usage

### From Python:
```python
from pyoptima import solve, load_config_file

# Load and solve
config = load_config_file("data/templates/portfolio/min_volatility.json")
result = solve(config.template, config.data)
```

### From CLI:
```bash
pyoptima solve --config data/templates/portfolio/min_volatility.json
```

### Direct API:
```python
from pyoptima import solve

result = solve("portfolio", {
    "expected_returns": [0.12, 0.10, 0.08],
    "covariance_matrix": [[0.04, 0.01, 0.02], ...],
    "objective": "min_volatility"
})
```

## Notes

1. **Data Formats**: All numeric arrays can be provided as:
   - Python lists: `[0.12, 0.10, 0.08]`
   - NumPy arrays: `np.array([0.12, 0.10, 0.08])`
   - Pandas Series/DataFrames: `pd.Series([0.12, 0.10, 0.08], index=["AAPL", "GOOGL", "MSFT"])`

2. **Historical Returns**: For CVaR/CDaR/Semivariance methods, `returns` should be a 2D array where:
   - Rows = time periods (e.g., days)
   - Columns = assets
   - Values = returns for that period

3. **Solver Options**: All methods support solver configuration:
   ```json
   {
     "solver": {
       "name": "ipopt",
       "options": {
         "max_iter": 5000,
         "tol": 1e-6
       }
     }
   }
   ```

4. **Constraints**: All methods support:
   - Weight bounds: `weight_bounds: [0, 1]` or `min_weight: 0.0, max_weight: 1.0`
   - Cardinality: `max_assets: 10` (limits number of assets)
   - Turnover: `max_turnover: 0.2` (requires `current_weights`)
