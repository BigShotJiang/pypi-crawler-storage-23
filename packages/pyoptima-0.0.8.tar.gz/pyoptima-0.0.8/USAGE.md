# PyOptima Usage Guide

Config schema: **template**, **data**, **solver**. For portfolio, `data` includes `objective`, `expected_returns`, `covariance_matrix`.

## Installation

```bash
pip install pyoptima
pip install pyoptima[api]   # optional: API server
```

## Quick Start

### 1. Config-driven (recommended)

```python
from pyoptima import run_from_config, PortfolioOptimizer, load_config_file

# One-shot (any template: portfolio, knapsack, lp, ...)
result = run_from_config("portfolio.json")

# Portfolio: build optimizer from config, then solve (uses config data)
opt = PortfolioOptimizer.from_config("min_volatility.json")
result = opt.solve()

# Solve with different data
result2 = opt.solve(expected_returns=er2, covariance_matrix=cov2, symbols=symbols)
```

### 2. Code-only (sklearn-style)

```python
from pyoptima import PortfolioOptimizer

opt = PortfolioOptimizer(objective="min_volatility", max_weight=0.4)
result = opt.solve(
    expected_returns=[0.10, 0.12, 0.15],
    covariance_matrix=[[0.04, 0.01, 0.02], [0.01, 0.05, 0.01], [0.02, 0.01, 0.06]],
    symbols=["AAPL", "MSFT", "GOOGL"],
)
```

### 3. Config from dict

```python
from pyoptima import run_from_config, load_config

config_dict = {
    "template": "portfolio",
    "data": {
        "objective": "min_volatility",
        "expected_returns": [0.10, 0.12, 0.15],
        "covariance_matrix": [[0.04, 0.01, 0.02], [0.01, 0.05, 0.01], [0.02, 0.01, 0.06]],
    },
    "solver": {"name": "ipopt"},
}
result = run_from_config(config_dict)
```

## Configuration File Format

Schema: `template`, `data`, `solver`. Portfolio `data` must include `objective`, `expected_returns`, `covariance_matrix`.

### Example: Min Volatility Portfolio

```json
{
  "template": "portfolio",
  "data": {
    "objective": "min_volatility",
    "expected_returns": [0.10, 0.12, 0.15, 0.08],
    "covariance_matrix": [
      [0.04, 0.01, 0.02, 0.01],
      [0.01, 0.05, 0.01, 0.01],
      [0.02, 0.01, 0.06, 0.01],
      [0.01, 0.01, 0.01, 0.03]
    ],
    "symbols": ["AAPL", "MSFT", "GOOGL", "AMZN"],
    "weight_bounds": [0, 1]
  },
  "solver": { "name": "ipopt", "time_limit": 60 }
}
```

### Example: Max Sharpe

```json
{
  "template": "portfolio",
  "data": {
    "objective": "max_sharpe",
    "risk_free_rate": 0.02,
    "expected_returns": [0.10, 0.12, 0.15, 0.08],
    "covariance_matrix": [[0.04, 0.01, 0.02, 0.01], [0.01, 0.05, 0.01, 0.01], [0.02, 0.01, 0.06, 0.01], [0.01, 0.01, 0.01, 0.03]],
    "weight_bounds": [0, 0.5]
  },
  "solver": { "name": "ipopt" }
}
```

### Example: Efficient Risk (target volatility)

```json
{
  "template": "portfolio",
  "data": {
    "objective": "efficient_risk",
    "target_volatility": 0.15,
    "expected_returns": [0.10, 0.12, 0.15, 0.08],
    "covariance_matrix": [[0.04, 0.01, 0.02, 0.01], [0.01, 0.05, 0.01, 0.01], [0.02, 0.01, 0.06, 0.01], [0.01, 0.01, 0.01, 0.03]]
  },
  "solver": { "name": "ipopt" }
}
```

### Example: CVaR

```json
{
  "template": "portfolio",
  "data": {
    "objective": "min_cvar",
    "confidence_level": 0.05,
    "returns": [[0.01, 0.02, -0.01], [0.015, -0.01, 0.02], [-0.01, 0.02, 0.015]],
    "expected_returns": [0.10, 0.12, 0.15],
    "covariance_matrix": [[0.04, 0.01, 0.02], [0.01, 0.05, 0.01], [0.02, 0.01, 0.06]]
  },
  "solver": { "name": "ipopt" }
}
```

### Example: Black-Litterman

```json
{
  "template": "portfolio",
  "data": {
    "objective": "black_litterman_max_sharpe",
    "expected_returns": [0.10, 0.12, 0.15, 0.08],
    "covariance_matrix": [[0.04, 0.01, 0.02, 0.01], [0.01, 0.05, 0.01, 0.01], [0.02, 0.01, 0.06, 0.01], [0.01, 0.01, 0.01, 0.03]],
    "views": [[1, -1, 0, 0]],
    "view_cov": [[0.01]],
    "risk_aversion": 1.0
  },
  "solver": { "name": "ipopt" }
}
```

## Available Methods

### Portfolio objectives

```python
from pyoptima import PortfolioOptimizer

objectives = PortfolioOptimizer.list_objectives()
# e.g. min_volatility, max_sharpe, efficient_return, min_cvar, ...
```

### Templates (all problem types)

```python
from pyoptima import list_templates, get_template, solve

names = list_templates()  # e.g. knapsack, lp, portfolio, tsp
result = solve("knapsack", {"items": [...], "capacity": 50})
```

### Method Categories

- **Efficient Frontier**: `min_volatility`, `max_sharpe`, `max_quadratic_utility`, `efficient_risk`, `efficient_return`
- **Black-Litterman**: `black_litterman_max_sharpe`, `black_litterman_min_volatility`, `black_litterman_quadratic_utility`
- **CVaR**: `min_cvar`, `efficient_cvar_risk`, `efficient_cvar_return`
- **CDaR**: `min_cdar`, `efficient_cdar_risk`, `efficient_cdar_return`
- **Semivariance**: `min_semivariance`, `efficient_semivariance_risk`, `efficient_semivariance_return`
- **Hierarchical**: `hierarchical_min_volatility`, `hierarchical_max_sharpe`
- **CLA**: `cla_min_volatility`, `cla_max_sharpe`

## Working with Real Data

### Using Pandas DataFrames

```python
import pandas as pd
from pyoptima import PortfolioOptimizer

returns_df = pd.read_csv("data/stock_returns.csv", index_col=0, parse_dates=True)
expected_returns = returns_df.mean() * 252
cov_matrix = returns_df.cov() * 252

opt = PortfolioOptimizer.from_config("config.json")
result = opt.solve(
    expected_returns=expected_returns,
    covariance_matrix=cov_matrix,
    symbols=list(returns_df.columns),
)
weights = result.weights
```

### Using NumPy Arrays

```python
import numpy as np
from pyoptima import PortfolioOptimizer

expected_returns = np.array([0.10, 0.12, 0.15, 0.08])
cov_matrix = np.array([
    [0.04, 0.01, 0.02, 0.01],
    [0.01, 0.05, 0.01, 0.01],
    [0.02, 0.01, 0.06, 0.01],
    [0.01, 0.01, 0.01, 0.03],
])

opt = PortfolioOptimizer(objective="min_volatility")
result = opt.solve(expected_returns=expected_returns, covariance_matrix=cov_matrix)
```

### Methods Requiring Historical Returns (CVaR, CDaR, Semivariance)

```python
import pandas as pd
from pyoptima import PortfolioOptimizer

returns_df = pd.read_csv("data/returns.csv", index_col=0)
opt = PortfolioOptimizer.from_config("config_cvar.json")
result = opt.solve(
    returns=returns_df.values,
    expected_returns=returns_df.mean(),
    covariance_matrix=returns_df.cov(),
    symbols=list(returns_df.columns),
)
```

## CLI Usage

### Basic Optimization

```bash
# Run optimization from config file
pyoptima optimize config.json

# Save results to file
pyoptima optimize config.json --output results.json

# Pretty print results
pyoptima optimize config.json --pretty
```

### List Available Methods

```bash
# List all methods (when implemented)
pyoptima list-methods

# List methods by category
pyoptima list-methods --category portfolio

# Get method information
pyoptima method-info min_volatility
```

## Advanced Usage

### Reusing Optimizer with Different Data

```python
from pyoptima import PortfolioOptimizer
import pandas as pd

opt = PortfolioOptimizer.from_config("config.json")

for period in ["2023-Q1", "2023-Q2", "2023-Q3", "2023-Q4"]:
    returns = pd.read_csv(f"data/returns_{period}.csv", index_col=0)
    result = opt.solve(
        expected_returns=returns.mean() * 252,
        covariance_matrix=returns.cov() * 252,
        symbols=list(returns.columns),
    )
    print(f"{period}: Sharpe = {getattr(result, 'sharpe_ratio', 'N/A'):.4f}")
```

### Custom Parameters

```python
from pyoptima import PortfolioOptimizer

opt = PortfolioOptimizer.from_config("config.json")
opt.set_params(max_weight=0.3, solver="ipopt")
result = opt.solve(expected_returns=..., covariance_matrix=..., symbols=...)
```

## Result Format

All optimization methods return a standardized dictionary:

```python
{
    "weights": {
        "Asset_0": 0.25,
        "Asset_1": 0.30,
        "Asset_2": 0.20,
        "Asset_3": 0.25
    },
    "objective_value": 0.045,  # Objective function value
    "status": "optimal",  # or "feasible", "infeasible", etc.
    "message": "Optimization successful",
    "portfolio_return": 0.115,  # Portfolio expected return
    "portfolio_volatility": 0.15,  # Portfolio volatility
    # Method-specific metrics:
    "sharpe_ratio": 0.77,  # For max_sharpe
    "cvar": 0.05,  # For CVaR methods
    "semivariance": 0.02,  # For semivariance methods
    # etc.
}
```

## Error Handling

```python
from pyoptima import run_from_config, PortfolioOptimizer

try:
    result = run_from_config("config.json")
    if result.get("status") == "optimal":
        print("✓ Optimization successful")
        print(f"Weights: {result['weights']}")
    else:
        print(f"⚠ Status: {result.get('status')}")
        print(f"Message: {result.get('message')}")
except ValueError as e:
    print(f"❌ Validation error: {e}")
except RuntimeError as e:
    print(f"❌ Solver error: {e}")
except Exception as e:
    print(f"❌ Unexpected error: {e}")
```

## Examples by Method Type

### Efficient Frontier Methods

```python
# Min Volatility
result = optimizer.optimize(
    expected_returns=er,
    covariance_matrix=cov,
    weight_bounds=(0, 1)
)

# Max Sharpe
result = optimizer.optimize(
    expected_returns=er,
    covariance_matrix=cov,
    risk_free_rate=0.02,
    weight_bounds=(0, 1)
)

# Efficient Risk (target volatility)
result = optimizer.optimize(
    expected_returns=er,
    covariance_matrix=cov,
    target_volatility=0.15,
    weight_bounds=(0, 1)
)
```

### Risk-Based Methods (CVaR, CDaR, Semivariance)

```python
# Min CVaR
result = optimizer.optimize(
    returns=returns_df,  # Historical returns required
    confidence_level=0.05,
    weight_bounds=(0, 1)
)

# Min CDaR
result = optimizer.optimize(
    returns=returns_df,
    confidence_level=0.05,
    weight_bounds=(0, 1)
)

# Min Semivariance
result = optimizer.optimize(
    returns=returns_df,
    benchmark=0.0,
    weight_bounds=(0, 1)
)
```

### Black-Litterman

```python
import numpy as np

# Define views: Asset 1 will outperform Asset 2 by 2%
views = np.array([[1, -1, 0, 0]])  # View matrix
view_cov = np.array([[0.01]])  # View uncertainty

result = optimizer.optimize(
    expected_returns=prior_returns,  # Prior expected returns
    covariance_matrix=cov_matrix,  # Prior covariance
    views=views,
    view_cov=view_cov,
    risk_aversion=1.0,
    weight_bounds=(0, 1)
)
```

## Tips

1. **Reuse Optimizers**: Create once, optimize many times for better performance
2. **Data Format**: Methods accept pandas Series/DataFrames or numpy arrays
3. **Solver Selection**: Use `ipopt` for nonlinear (default), `cbc`/`glpk` for linear, `gurobi` for commercial
4. **Weight Bounds**: Use `[0, 0.4]` to limit individual asset weights to 40%
5. **Time Limits**: Set `time_limit_seconds` in config meta for long-running optimizations
