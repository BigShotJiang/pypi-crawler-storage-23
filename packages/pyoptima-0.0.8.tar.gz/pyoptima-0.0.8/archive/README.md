# Archive

This directory holds obsolete or no-longer-needed files from the repository.

- **pyoptima-root-remnant/** – Leftover directory from the migration to the src layout (Jan 2025). Package code now lives under `src/pyoptima/`. Contains only `__pycache__` and empty `compat/`. Kept for reference only; safe to delete after verification.

Do not use archived code in active development. Remove items from this directory only when they are no longer needed for history or reference.
