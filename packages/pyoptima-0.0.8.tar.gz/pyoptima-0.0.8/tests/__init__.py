"""
Tests for PyOptima.
"""
