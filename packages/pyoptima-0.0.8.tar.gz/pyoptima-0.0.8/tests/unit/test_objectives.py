"""
Tests for objective classes.

Verifies that every objective builds real mathematical expressions on
AbstractModel (no more dict-flag-only stubs).
"""

import numpy as np
import pytest

from pyoptima.model.core import AbstractModel, OptimizationSense
from pyoptima.objectives import (  # Efficient frontier; CVaR; CDaR; Semivariance; Black-Litterman; CLA / Hierarchical; Diversification; Risk parity; Transaction cost; Momentum; Factor; Trading
    OBJECTIVE_REGISTRY,
    BaseObjective,
    BlackLittermanMaxSharpe,
    BlackLittermanMinVolatility,
    BlackLittermanQuadraticUtility,
    CLAMaxSharpe,
    CLAMinVolatility,
    EfficientCDaRReturn,
    EfficientCDaRRisk,
    EfficientCVaRReturn,
    EfficientCVaRRisk,
    EfficientReturn,
    EfficientRisk,
    EfficientSemivarianceReturn,
    EfficientSemivarianceRisk,
    EqualRiskContribution,
    FactorBasedSelection,
    HierarchicalMaxSharpe,
    HierarchicalMinVolatility,
    LiquidityAdjustedMinVol,
    MaxDiversification,
    MaxDiversificationIndex,
    MaxReturn,
    MaxSharpe,
    MaxSharpeWithCosts,
    MaxUtility,
    MinCDaR,
    MinCVaR,
    MinImplementationShortfall,
    MinMarketImpact,
    MinSemivariance,
    MinTrackingError,
    MinVolatility,
    MinVolatilityWithCosts,
    MomentumFilteredMaxSharpe,
    MomentumFilteredMinVolatility,
    RiskParity,
    get_objective,
    list_objectives,
)

# =============================================================================
# Fixtures
# =============================================================================


def _make_model(n=3):
    """Create an AbstractModel with n weight variables."""
    model = AbstractModel("test")
    for i in range(n):
        model.add_continuous(f"w_{i}", lb=0.0, ub=1.0)
    return model


def _base_data(n=3):
    """Standard data dict with covariance, returns, symbols."""
    np.random.seed(42)
    cov = np.eye(n) * 0.04
    cov[0, 1] = cov[1, 0] = 0.01
    er = np.array([0.12, 0.10, 0.08])[:n]
    returns = np.random.normal(0, 0.02, (50, n))
    return {
        "symbols": [f"S{i}" for i in range(n)],
        "n_assets": n,
        "covariance_matrix": cov.tolist(),
        "expected_returns": er.tolist(),
        "returns": returns.tolist(),
    }


# =============================================================================
# Registry tests
# =============================================================================


class TestRegistry:
    def test_list_objectives(self):
        names = list_objectives()
        assert "min_volatility" in names
        assert "max_sharpe" in names
        assert "min_market_impact" in names
        assert len(names) == len(OBJECTIVE_REGISTRY)

    def test_get_objective_simple(self):
        obj = get_objective("min_volatility")
        assert isinstance(obj, MinVolatility)
        assert obj.name == "min_volatility"

    def test_get_objective_with_params(self):
        obj = get_objective("max_sharpe", risk_free_rate=0.02)
        assert isinstance(obj, MaxSharpe)
        assert obj.risk_free_rate == 0.02

    def test_get_objective_unknown_raises(self):
        with pytest.raises(KeyError, match="Unknown objective"):
            get_objective("nonexistent_objective")

    def test_all_registry_entries_are_base_objective(self):
        for name, cls in OBJECTIVE_REGISTRY.items():
            assert issubclass(cls, BaseObjective), f"{name}: {cls} not BaseObjective"


# =============================================================================
# Efficient Frontier objectives
# =============================================================================


class TestMinVolatility:
    def test_builds_quadratic_objective(self):
        model = _make_model()
        data = _base_data()
        obj = MinVolatility()
        obj.build(model, data)

        assert model.objective is not None
        assert model.objective.sense == OptimizationSense.MINIMIZE
        assert model.objective.expression.is_quadratic

    def test_missing_cov_raises(self):
        model = _make_model()
        with pytest.raises(ValueError, match="covariance_matrix"):
            MinVolatility().build(model, {"symbols": ["A"], "n_assets": 1})

    def test_repr(self):
        assert repr(MinVolatility()) == "MinVolatility()"


class TestMaxSharpe:
    def test_builds_sharpe_linearization(self):
        model = _make_model()
        data = _base_data()
        obj = MaxSharpe(risk_free_rate=0.02)
        obj.build(model, data)

        # Should minimize variance with normalization constraint
        assert model.objective is not None
        assert model.objective.sense == OptimizationSense.MINIMIZE
        assert "sharpe_normalization" in model.constraints

    def test_from_config(self):
        obj = MaxSharpe.from_config({"risk_free_rate": 0.03})
        assert obj.risk_free_rate == 0.03

    def test_to_config(self):
        obj = MaxSharpe(risk_free_rate=0.02)
        cfg = obj.to_config()
        assert cfg["name"] == "max_sharpe"
        assert cfg["risk_free_rate"] == 0.02


class TestMaxReturn:
    def test_builds_linear_objective(self):
        model = _make_model()
        data = _base_data()
        MaxReturn().build(model, data)

        assert model.objective is not None
        assert model.objective.sense == OptimizationSense.MAXIMIZE
        assert model.objective.expression.is_linear


class TestEfficientReturn:
    def test_builds_variance_with_return_constraint(self):
        model = _make_model()
        data = _base_data()
        EfficientReturn(target_return=0.10).build(model, data)

        assert model.objective is not None
        assert model.objective.sense == OptimizationSense.MINIMIZE
        assert model.objective.expression.is_quadratic
        assert "target_return" in model.constraints


class TestEfficientRisk:
    def test_builds_return_with_variance_constraint(self):
        model = _make_model()
        data = _base_data()
        EfficientRisk(target_volatility=0.15).build(model, data)

        assert model.objective is not None
        assert model.objective.sense == OptimizationSense.MAXIMIZE
        assert model.objective.expression.is_linear
        assert "target_volatility" in model.constraints


class TestMaxUtility:
    def test_builds_quadratic_utility(self):
        model = _make_model()
        data = _base_data()
        MaxUtility(risk_aversion=2.0).build(model, data)

        assert model.objective is not None
        assert model.objective.sense == OptimizationSense.MINIMIZE
        # Should be quadratic (lambda/2 * w'Sw - mu'w)
        assert model.objective.expression.is_quadratic


# =============================================================================
# CVaR objectives
# =============================================================================


class TestMinCVaR:
    def test_builds_cvar_formulation(self):
        model = _make_model()
        data = _base_data()
        MinCVaR(confidence=0.95).build(model, data)

        assert model.objective is not None
        assert model.objective.sense == OptimizationSense.MINIMIZE
        # Should have VaR variable and auxiliaries
        assert model.get_variable("cvar_zeta") is not None
        assert model.get_variable("cvar_u_0") is not None

    def test_missing_returns_raises(self):
        model = _make_model()
        data = {"symbols": ["A"], "n_assets": 1}
        with pytest.raises(ValueError, match="returns"):
            MinCVaR().build(model, data)


class TestEfficientCVaRRisk:
    def test_builds_return_max_with_cvar_constraint(self):
        model = _make_model()
        data = _base_data()
        EfficientCVaRRisk(target_cvar=0.05, confidence=0.95).build(model, data)

        assert model.objective.sense == OptimizationSense.MAXIMIZE
        assert "target_cvar" in model.constraints


class TestEfficientCVaRReturn:
    def test_builds_cvar_min_with_return_constraint(self):
        model = _make_model()
        data = _base_data()
        EfficientCVaRReturn(target_return=0.05, confidence=0.95).build(model, data)

        assert model.objective.sense == OptimizationSense.MINIMIZE
        assert "target_return" in model.constraints


# =============================================================================
# CDaR objectives
# =============================================================================


class TestMinCDaR:
    def test_builds_cdar_formulation(self):
        model = _make_model()
        data = _base_data()
        MinCDaR(confidence=0.95).build(model, data)

        assert model.objective is not None
        assert model.objective.sense == OptimizationSense.MINIMIZE
        assert model.get_variable("cdar_zeta") is not None
        assert model.get_variable("cdar_u_0") is not None


class TestEfficientCDaRRisk:
    def test_builds_with_cdar_constraint(self):
        model = _make_model()
        data = _base_data()
        EfficientCDaRRisk(target_cdar=0.05).build(model, data)

        assert model.objective.sense == OptimizationSense.MAXIMIZE
        assert "target_cdar" in model.constraints


class TestEfficientCDaRReturn:
    def test_builds_with_return_constraint(self):
        model = _make_model()
        data = _base_data()
        EfficientCDaRReturn(target_return=0.05).build(model, data)

        assert model.objective.sense == OptimizationSense.MINIMIZE
        assert "target_return" in model.constraints


# =============================================================================
# Semivariance objectives
# =============================================================================


class TestMinSemivariance:
    def test_builds_semivariance_formulation(self):
        model = _make_model()
        data = _base_data()
        MinSemivariance(benchmark=0.0).build(model, data)

        assert model.objective is not None
        assert model.objective.sense == OptimizationSense.MINIMIZE
        # Quadratic: d_t^2 terms
        assert model.objective.expression.is_quadratic
        assert model.get_variable("sv_d_0") is not None


class TestEfficientSemivarianceRisk:
    def test_builds_with_sv_constraint(self):
        model = _make_model()
        data = _base_data()
        EfficientSemivarianceRisk(target_semivariance=0.01).build(model, data)

        assert model.objective.sense == OptimizationSense.MAXIMIZE
        assert "target_semivariance" in model.constraints


class TestEfficientSemivarianceReturn:
    def test_builds_with_return_constraint(self):
        model = _make_model()
        data = _base_data()
        EfficientSemivarianceReturn(target_return=0.05).build(model, data)

        assert model.objective.sense == OptimizationSense.MINIMIZE
        assert "target_return" in model.constraints


# =============================================================================
# Black-Litterman objectives
# =============================================================================


class TestBlackLitterman:
    def _bl_data(self):
        data = _base_data()
        data["market_caps"] = [1e12, 5e11, 3e11]
        data["views"] = {
            "P": [[1, 0, 0]],
            "Q": [0.15],
        }
        data["view_confidences"] = [0.001]
        return data

    def test_bl_max_sharpe(self):
        model = _make_model()
        data = self._bl_data()
        BlackLittermanMaxSharpe(risk_free_rate=0.02).build(model, data)

        assert model.objective is not None
        assert "sharpe_normalization" in model.constraints

    def test_bl_min_volatility(self):
        model = _make_model()
        data = self._bl_data()
        BlackLittermanMinVolatility().build(model, data)

        assert model.objective is not None
        assert model.objective.sense == OptimizationSense.MINIMIZE

    def test_bl_quadratic_utility(self):
        model = _make_model()
        data = self._bl_data()
        BlackLittermanQuadraticUtility(risk_aversion=2.0).build(model, data)

        assert model.objective is not None
        assert model.objective.expression.is_quadratic


# =============================================================================
# CLA / Hierarchical (algorithmic — store metadata)
# =============================================================================


class TestAlgorithmicObjectives:
    def test_cla_min_vol_stores_metadata(self):
        model = _make_model()
        data = _base_data()
        CLAMinVolatility().build(model, data)

        assert model.get_parameter("_objective_type") == "cla_min_volatility"
        assert model.objective is not None

    def test_cla_max_sharpe_stores_metadata(self):
        model = _make_model()
        data = _base_data()
        CLAMaxSharpe(risk_free_rate=0.02).build(model, data)

        assert model.get_parameter("_objective_type") == "cla_max_sharpe"
        assert model.get_parameter("_sharpe_rf") == 0.02

    def test_hierarchical_min_vol(self):
        model = _make_model()
        data = _base_data()
        HierarchicalMinVolatility().build(model, data)

        assert model.get_parameter("_objective_type") == "hierarchical_min_volatility"

    def test_hierarchical_max_sharpe(self):
        model = _make_model()
        data = _base_data()
        HierarchicalMaxSharpe(risk_free_rate=0.01).build(model, data)

        assert model.get_parameter("_objective_type") == "hierarchical_max_sharpe"


# =============================================================================
# Diversification / Risk parity
# =============================================================================


class TestDiversification:
    def test_max_diversification_builds_normalization(self):
        model = _make_model()
        data = _base_data()
        MaxDiversification().build(model, data)

        assert model.objective is not None
        assert model.objective.sense == OptimizationSense.MINIMIZE
        assert "diversification_normalization" in model.constraints

    def test_max_diversification_index(self):
        model = _make_model()
        data = _base_data()
        MaxDiversificationIndex().build(model, data)

        assert model.objective is not None
        assert "diversification_normalization" in model.constraints


class TestRiskParity:
    def test_risk_parity_stores_metadata(self):
        model = _make_model()
        data = _base_data()
        RiskParity().build(model, data)

        assert model.get_parameter("_objective_type") == "risk_parity"
        assert model.objective is not None

    def test_equal_risk_contribution(self):
        model = _make_model()
        data = _base_data()
        EqualRiskContribution().build(model, data)

        assert model.get_parameter("_objective_type") == "equal_risk_contribution"


# =============================================================================
# Transaction cost-aware
# =============================================================================


class TestTransactionCostObjectives:
    def test_max_sharpe_with_costs(self):
        model = _make_model()
        data = _base_data()
        data["transaction_costs"] = 0.001
        data["current_weights"] = {"S0": 0.3, "S1": 0.4, "S2": 0.3}
        MaxSharpeWithCosts(risk_free_rate=0.02).build(model, data)

        assert model.objective is not None
        assert "sharpe_normalization" in model.constraints
        assert model.get_parameter("_objective_type") == "max_sharpe_with_costs"

    def test_min_volatility_with_costs(self):
        model = _make_model()
        data = _base_data()
        data["transaction_costs"] = 0.001
        MinVolatilityWithCosts().build(model, data)

        assert model.objective is not None
        assert model.objective.sense == OptimizationSense.MINIMIZE


# =============================================================================
# Momentum-filtered
# =============================================================================


class TestMomentumFiltered:
    def test_momentum_filtered_max_sharpe(self):
        model = _make_model()
        data = _base_data()
        # Make one asset have negative momentum
        returns = np.array(data["returns"])
        returns[:, 2] = -0.05  # S2 negative
        data["returns"] = returns.tolist()
        MomentumFilteredMaxSharpe(risk_free_rate=0.01).build(model, data)

        assert model.objective is not None
        # S2 should be excluded (bounds set to 0)
        var = model.get_variable("w_2")
        assert var.upper_bound == 0.0

    def test_momentum_filtered_min_vol(self):
        model = _make_model()
        data = _base_data()
        returns = np.array(data["returns"])
        returns[:, 2] = -0.05
        data["returns"] = returns.tolist()
        MomentumFilteredMinVolatility().build(model, data)

        assert model.objective is not None
        assert model.objective.sense == OptimizationSense.MINIMIZE
        var = model.get_variable("w_2")
        assert var.upper_bound == 0.0


# =============================================================================
# Factor-based
# =============================================================================


class TestFactorBased:
    def test_factor_based_selection(self):
        model = _make_model()
        data = _base_data()
        data["factor_data"] = {
            "value": {"S0": 1.0, "S1": -0.5, "S2": 0.3},
            "momentum": {"S0": 0.5, "S1": 0.8, "S2": -0.2},
        }
        data["factor_weights"] = {"value": 0.6, "momentum": 0.4}
        FactorBasedSelection().build(model, data)

        assert model.objective is not None
        assert model.objective.sense == OptimizationSense.MAXIMIZE
        assert model.objective.expression.is_linear

    def test_missing_factor_data_raises(self):
        model = _make_model()
        data = _base_data()
        with pytest.raises(ValueError, match="factor_data"):
            FactorBasedSelection().build(model, data)


# =============================================================================
# Trading objectives
# =============================================================================


class TestTradingObjectives:
    def test_min_market_impact(self):
        model = _make_model()
        data = _base_data()
        data["adv"] = {"S0": 1e6, "S1": 5e5, "S2": 2e5}
        data["current_weights"] = {"S0": 0.3, "S1": 0.4, "S2": 0.3}

        obj = MinMarketImpact(adv=data["adv"])
        obj.build(model, data)

        assert model.objective is not None
        assert model.objective.sense == OptimizationSense.MINIMIZE
        # Should have buy/sell variables
        assert model.get_variable("buy_0") is not None
        assert model.get_variable("sell_0") is not None

    def test_min_implementation_shortfall(self):
        model = _make_model()
        data = _base_data()
        data["adv"] = {"S0": 1e6, "S1": 5e5, "S2": 2e5}
        data["volatilities"] = {"S0": 0.02, "S1": 0.03, "S2": 0.015}
        data["current_weights"] = {"S0": 0.3, "S1": 0.4, "S2": 0.3}

        obj = MinImplementationShortfall(
            adv=data["adv"], volatilities=data["volatilities"]
        )
        obj.build(model, data)

        assert model.objective is not None
        assert model.objective.expression.is_quadratic

    def test_min_tracking_error(self):
        model = _make_model()
        data = _base_data()
        bw = {"S0": 0.15, "S1": 0.10, "S2": 0.08}

        obj = MinTrackingError(benchmark_weights=bw)
        obj.build(model, data)

        assert model.objective is not None
        assert model.objective.sense == OptimizationSense.MINIMIZE
        assert model.objective.expression.is_quadratic

    def test_liquidity_adjusted_min_vol(self):
        model = _make_model()
        data = _base_data()
        data["adv"] = {"S0": 1e6, "S1": 5e5, "S2": 2e5}

        obj = LiquidityAdjustedMinVol(adv=data["adv"], liquidity_penalty=0.01)
        obj.build(model, data)

        assert model.objective is not None
        assert model.objective.sense == OptimizationSense.MINIMIZE
        assert model.objective.expression.is_quadratic


# =============================================================================
# Config round-trip tests
# =============================================================================


class TestConfigRoundTrip:
    def test_from_config_dict(self):
        obj = MaxSharpe.from_config({"risk_free_rate": 0.03})
        assert obj.risk_free_rate == 0.03

    def test_to_config(self):
        obj = EfficientReturn(target_return=0.10)
        cfg = obj.to_config()
        assert cfg["name"] == "efficient_return"
        assert cfg["target_return"] == 0.10

    def test_round_trip(self):
        original = MaxUtility(risk_aversion=3.5)
        cfg = original.to_config()
        restored = MaxUtility.from_config(cfg)
        assert restored.risk_aversion == 3.5

    def test_no_params_objective(self):
        obj = MinVolatility()
        cfg = obj.to_config()
        assert cfg["name"] == "min_volatility"
        restored = MinVolatility.from_config(cfg)
        assert restored.name == "min_volatility"
