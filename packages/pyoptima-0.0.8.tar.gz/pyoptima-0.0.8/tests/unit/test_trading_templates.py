"""
Unit tests for trading templates and estimators.

Tests template configs, validation, and estimator interfaces for:
- Execution (TWAP, VWAP, IS, POV)
- Signal Sizing (mean_risk, equal_risk, kelly, fixed_risk)
- Rebalance (min_deviation, min_cost, min_impact)
- Risk Budget (check, reduce, allocate)
- Trading Schedule (fixed, priority, adaptive)
- Multi-Account (joint)
"""

import numpy as np
import pytest

# Estimators
from pyoptima.estimators.execution import ExecutionOptimizer
from pyoptima.estimators.multi_account import MultiAccountOptimizer
from pyoptima.estimators.rebalance import RebalanceOptimizer
from pyoptima.estimators.risk_budget import RiskBudgetOptimizer
from pyoptima.estimators.signal_sizing import SignalSizingOptimizer

# Template registry
from pyoptima.templates import get_template, list_templates

# Templates
from pyoptima.templates.execution import ExecutionTemplate

# Template configs
from pyoptima.templates.execution_config import ExecutionConfig, ExecutionStrategy
from pyoptima.templates.multi_account import MultiAccountTemplate
from pyoptima.templates.multi_account_config import (
    MultiAccountConfig,
    MultiAccountStrategy,
)
from pyoptima.templates.rebalance import RebalanceTemplate
from pyoptima.templates.rebalance_config import RebalanceConfig, RebalanceStrategy
from pyoptima.templates.risk_budget import RiskBudgetTemplate
from pyoptima.templates.risk_budget_config import RiskBudgetConfig, RiskStrategy
from pyoptima.templates.signal_sizing import SignalSizingTemplate
from pyoptima.templates.signal_sizing_config import SignalSizingConfig, SizingStrategy
from pyoptima.templates.trading_schedule import TradingScheduleTemplate
from pyoptima.templates.trading_schedule_config import (
    ScheduleStrategy,
    TradingScheduleConfig,
)

# =============================================================================
# Config roundtrip tests
# =============================================================================


class TestExecutionConfig:
    def test_from_dict_vwap(self):
        d = {
            "strategy": "vwap",
            "symbol": "AAPL",
            "total_quantity": 50000,
            "side": "buy",
            "horizon_minutes": 120,
            "interval_minutes": 5,
            "adv": 75_000_000,
            "volume_profile": [0.1] * 24,
        }
        cfg = ExecutionConfig.from_dict(d)
        assert cfg.strategy == ExecutionStrategy.VWAP
        assert cfg.symbol == "AAPL"
        assert cfg.n_intervals == 24

    def test_roundtrip(self):
        cfg = ExecutionConfig(
            strategy=ExecutionStrategy.IS,
            symbol="MSFT",
            total_quantity=100_000,
            side="sell",
        )
        d = cfg.to_dict()
        cfg2 = ExecutionConfig.from_dict(d)
        assert cfg2.strategy == cfg.strategy
        assert cfg2.total_quantity == cfg.total_quantity

    def test_interval_labels(self):
        cfg = ExecutionConfig(horizon_minutes=30, interval_minutes=10)
        labels = cfg.interval_labels("09:30")
        assert labels == ["09:30", "09:40", "09:50"]


class TestSignalSizingConfig:
    def test_from_dict(self):
        d = {
            "strategy": "mean_risk",
            "signals": {"AAPL": 0.02, "MSFT": -0.01},
            "symbols": ["AAPL", "MSFT"],
            "covariance_matrix": [[0.04, 0.01], [0.01, 0.09]],
            "risk_aversion": 2.0,
        }
        cfg = SignalSizingConfig.from_dict(d)
        assert cfg.strategy == SizingStrategy.MEAN_RISK
        assert cfg.risk_aversion == 2.0


class TestRebalanceConfig:
    def test_from_dict(self):
        d = {
            "strategy": "min_cost",
            "current_weights": {"AAPL": 0.30, "MSFT": 0.70},
            "target_weights": {"AAPL": 0.50, "MSFT": 0.50},
            "symbols": ["AAPL", "MSFT"],
            "transaction_costs": 0.001,
        }
        cfg = RebalanceConfig.from_dict(d)
        assert cfg.strategy == RebalanceStrategy.MIN_COST


class TestRiskBudgetConfig:
    def test_from_dict(self):
        d = {
            "strategy": "reduce",
            "current_weights": {"AAPL": 0.40, "MSFT": 0.60},
            "symbols": ["AAPL", "MSFT"],
            "max_volatility": 0.15,
            "covariance_matrix": [[0.04, 0.01], [0.01, 0.09]],
        }
        cfg = RiskBudgetConfig.from_dict(d)
        assert cfg.strategy == RiskStrategy.REDUCE
        assert cfg.max_volatility == 0.15


class TestTradingScheduleConfig:
    def test_from_dict(self):
        d = {
            "strategy": "priority",
            "tasks": [
                {"name": "rebalance", "duration_minutes": 30, "priority": 2},
                {"name": "execution", "duration_minutes": 60, "priority": 1},
            ],
            "session_start": "09:30",
            "session_end": "16:00",
        }
        cfg = TradingScheduleConfig.from_dict(d)
        assert cfg.strategy == ScheduleStrategy.PRIORITY
        assert len(cfg.tasks) == 2
        assert cfg.n_slots > 0

    def test_slot_labels(self):
        cfg = TradingScheduleConfig(
            session_start="09:30",
            session_end="10:00",
            interval_minutes=10,
        )
        labels = cfg.slot_labels()
        assert labels == ["09:30", "09:40", "09:50"]


class TestMultiAccountConfig:
    def test_from_dict(self):
        d = {
            "strategy": "joint",
            "accounts": [
                {"name": "aggressive", "max_weight": 0.40},
                {"name": "conservative", "max_weight": 0.15},
            ],
            "symbols": ["AAPL", "MSFT"],
            "covariance_matrix": [[0.04, 0.01], [0.01, 0.09]],
        }
        cfg = MultiAccountConfig.from_dict(d)
        assert cfg.strategy == MultiAccountStrategy.JOINT
        assert len(cfg.accounts) == 2


# =============================================================================
# Template validation tests
# =============================================================================


class TestExecutionTemplateValidation:
    def test_missing_total_quantity_raises(self):
        template = ExecutionTemplate()
        with pytest.raises(ValueError, match="total_quantity"):
            template.validate_data({"side": "buy"})

    def test_invalid_side_raises(self):
        template = ExecutionTemplate()
        with pytest.raises(ValueError, match="side must be"):
            template.validate_data({"total_quantity": 1000, "side": "invalid"})

    def test_vwap_needs_profile(self):
        template = ExecutionTemplate()
        with pytest.raises(ValueError, match="volume_profile"):
            template.validate_data(
                {
                    "strategy": "vwap",
                    "total_quantity": 1000,
                    "side": "buy",
                }
            )


class TestSignalSizingTemplateValidation:
    def test_missing_signals_raises(self):
        template = SignalSizingTemplate()
        with pytest.raises(ValueError, match="signals"):
            template.validate_data({"symbols": ["AAPL"]})

    def test_mean_risk_needs_cov(self):
        template = SignalSizingTemplate()
        with pytest.raises(ValueError, match="covariance_matrix"):
            template.validate_data(
                {
                    "strategy": "mean_risk",
                    "signals": {"AAPL": 0.02},
                    "symbols": ["AAPL"],
                }
            )


class TestRebalanceTemplateValidation:
    def test_missing_current_weights_raises(self):
        template = RebalanceTemplate()
        with pytest.raises(ValueError):
            template.validate_data(
                {
                    "target_weights": {"AAPL": 0.50},
                    "symbols": ["AAPL"],
                }
            )


class TestRiskBudgetTemplateValidation:
    def test_missing_symbols_raises(self):
        template = RiskBudgetTemplate()
        with pytest.raises(ValueError):
            template.validate_data({"current_weights": {"AAPL": 1.0}})


# =============================================================================
# Estimator interface tests
# =============================================================================


class TestEstimatorInterfaces:
    """Verify all estimators follow the sklearn pattern."""

    def test_execution_optimizer_params(self):
        opt = ExecutionOptimizer(strategy="twap", horizon_minutes=120)
        params = opt.get_params()
        assert params["strategy"] == "twap"
        assert params["horizon_minutes"] == 120

        opt.set_params(horizon_minutes=60)
        assert opt.horizon_minutes == 60

    def test_signal_sizing_optimizer_params(self):
        opt = SignalSizingOptimizer(strategy="mean_risk", risk_aversion=2.0)
        params = opt.get_params()
        assert params["strategy"] == "mean_risk"
        assert params["risk_aversion"] == 2.0

    def test_rebalance_optimizer_params(self):
        opt = RebalanceOptimizer(strategy="min_cost", max_turnover=0.15)
        params = opt.get_params()
        assert params["strategy"] == "min_cost"
        assert params["max_turnover"] == 0.15

    def test_risk_budget_optimizer_params(self):
        opt = RiskBudgetOptimizer(strategy="reduce", max_volatility=0.15)
        params = opt.get_params()
        assert params["strategy"] == "reduce"
        assert params["max_volatility"] == 0.15

    def test_multi_account_optimizer_params(self):
        opt = MultiAccountOptimizer(strategy="joint", objective="min_volatility")
        params = opt.get_params()
        assert params["strategy"] == "joint"
        assert params["objective"] == "min_volatility"

    def test_execution_list_strategies(self):
        strategies = ExecutionOptimizer.list_strategies()
        assert "twap" in strategies
        assert "vwap" in strategies
        assert "implementation_shortfall" in strategies
        assert "pov" in strategies

    def test_signal_sizing_list_strategies(self):
        strategies = SignalSizingOptimizer.list_strategies()
        assert "mean_risk" in strategies
        assert "equal_risk" in strategies

    def test_rebalance_list_strategies(self):
        strategies = RebalanceOptimizer.list_strategies()
        assert "min_deviation" in strategies
        assert "min_cost" in strategies

    def test_risk_budget_list_strategies(self):
        strategies = RiskBudgetOptimizer.list_strategies()
        assert "check" in strategies
        assert "reduce" in strategies

    def test_multi_account_list_strategies(self):
        strategies = MultiAccountOptimizer.list_strategies()
        assert "joint" in strategies

    def test_execution_validate_data(self):
        opt = ExecutionOptimizer()
        with pytest.raises(ValueError, match="total_quantity"):
            opt.solve(side="buy")

    def test_signal_sizing_validate_data(self):
        opt = SignalSizingOptimizer()
        with pytest.raises(ValueError, match="signals"):
            opt.solve(symbols=["AAPL"])

    def test_rebalance_validate_data(self):
        opt = RebalanceOptimizer()
        with pytest.raises(ValueError, match="current_weights"):
            opt.solve(symbols=["AAPL"])


# =============================================================================
# Template registry tests
# =============================================================================


class TestTemplateRegistry:
    def test_all_trading_templates_registered(self):
        templates = list_templates()
        for name in [
            "execution",
            "signal_sizing",
            "rebalance",
            "risk_budget",
            "trading_schedule",
            "multi_account",
        ]:
            assert name in templates, f"Template '{name}' not registered"

    def test_get_execution_template(self):
        template = get_template("execution")
        assert isinstance(template, ExecutionTemplate)
        assert template.info.name == "execution"

    def test_get_signal_sizing_template(self):
        template = get_template("signal_sizing")
        assert isinstance(template, SignalSizingTemplate)

    def test_get_rebalance_template(self):
        template = get_template("rebalance")
        assert isinstance(template, RebalanceTemplate)

    def test_get_risk_budget_template(self):
        template = get_template("risk_budget")
        assert isinstance(template, RiskBudgetTemplate)

    def test_get_trading_schedule_template(self):
        template = get_template("trading_schedule")
        assert isinstance(template, TradingScheduleTemplate)

    def test_get_multi_account_template(self):
        template = get_template("multi_account")
        assert isinstance(template, MultiAccountTemplate)


# =============================================================================
# Liquidity constraints tests
# =============================================================================


class TestLiquidityConstraints:
    def test_liquidity_limit(self):
        from pyoptima.constraints.liquidity import LiquidityLimit
        from pyoptima.model.core import AbstractModel

        c = LiquidityLimit(
            adv={"AAPL": 50_000},
            max_days_to_liquidate=1.0,
            participation_rate=0.10,
            prices={"AAPL": 185.0},
            portfolio_value=10_000_000,
        )
        assert c.name == "liquidity_limit"

        model = AbstractModel("test")
        model.add_continuous("w_0", lb=0.0, ub=1.0)
        data = {"n_assets": 1, "symbols": ["AAPL"]}
        c.apply(model, data)
        # max_w = 50_000 * 185.0 * 1.0 * 0.10 / 10_000_000 = 0.0925
        var = model.get_variable("w_0")
        assert var.upper_bound < 1.0
        assert abs(var.upper_bound - 0.0925) < 1e-6

    def test_max_participation(self):
        from pyoptima.constraints.liquidity import MaxParticipation

        c = MaxParticipation(
            adv={"AAPL": 75_000_000},
            max_participation=0.10,
        )
        assert c.name == "max_participation"

    def test_max_spread_cost(self):
        from pyoptima.constraints.liquidity import MaxSpreadCost

        c = MaxSpreadCost(
            spreads={"AAPL": 1.0, "ILLIQ": 50.0},
            max_cost_bps=5.0,
        )
        assert c.name == "max_spread_cost"


# =============================================================================
# Trading objectives tests
# =============================================================================


class TestTradingObjectives:
    def test_min_market_impact(self):
        from pyoptima.objectives.trading import MinMarketImpact

        obj = MinMarketImpact(adv={"AAPL": 75_000_000})
        assert obj.name == "min_market_impact"

    def test_min_implementation_shortfall(self):
        from pyoptima.objectives.trading import MinImplementationShortfall

        obj = MinImplementationShortfall(adv={"AAPL": 75_000_000})
        assert obj.name == "min_implementation_shortfall"

    def test_min_tracking_error(self):
        from pyoptima.objectives.trading import MinTrackingError

        obj = MinTrackingError(benchmark_weights={"AAPL": 0.15, "MSFT": 0.10})
        assert obj.name == "min_tracking_error"

    def test_liquidity_adjusted_min_vol(self):
        from pyoptima.objectives.trading import LiquidityAdjustedMinVol

        obj = LiquidityAdjustedMinVol(adv={"AAPL": 75_000_000})
        assert obj.name == "liquidity_adjusted_min_vol"


# =============================================================================
# PortfolioData.from_intraday test
# =============================================================================


class TestPortfolioDataIntraday:
    def test_from_intraday(self):
        from pyoptima.io.data import PortfolioData

        # Simulate 100 intraday bars for 3 assets
        np.random.seed(42)
        bars = np.random.normal(0, 0.001, (100, 3))
        data = PortfolioData.from_intraday(bars, frequency=78)
        assert data.n_assets == 3
        assert data.metadata["frequency"] == 78 * 252
