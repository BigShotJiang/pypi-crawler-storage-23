"""
Tests for BaseOptimizer class.
"""

import pytest

from pyoptima.core.result import OptimizationResult, SolverStatus
from pyoptima.estimators.base import BaseOptimizer, clone


class MockOptimizer(BaseOptimizer):
    """Mock optimizer for testing."""

    def __init__(self, alpha: float = 1.0, max_iter: int = 100, name: str = "mock"):
        self.alpha = alpha
        self.max_iter = max_iter
        self.name = name

    def _solve(self, **data) -> OptimizationResult:
        return OptimizationResult(
            status=SolverStatus.OPTIMAL,
            objective_value=self.alpha * 10,
            solution={"x": self.alpha},
            solver_name="mock",
        )


class TestBaseOptimizer:
    """Tests for BaseOptimizer."""

    def test_get_params(self):
        """Test get_params returns all init parameters."""
        opt = MockOptimizer(alpha=0.5, max_iter=200, name="test")
        params = opt.get_params()

        assert params == {"alpha": 0.5, "max_iter": 200, "name": "test"}

    def test_get_params_deep(self):
        """Test get_params with deep=True."""
        opt = MockOptimizer()
        params = opt.get_params(deep=True)

        assert "alpha" in params
        assert "max_iter" in params

    def test_set_params(self):
        """Test set_params updates parameters."""
        opt = MockOptimizer()
        opt.set_params(alpha=0.25, max_iter=500)

        assert opt.alpha == 0.25
        assert opt.max_iter == 500

    def test_set_params_returns_self(self):
        """Test set_params returns self for chaining."""
        opt = MockOptimizer()
        result = opt.set_params(alpha=0.5)

        assert result is opt

    def test_set_params_invalid(self):
        """Test set_params raises on invalid parameter."""
        opt = MockOptimizer()

        with pytest.raises(ValueError, match="Invalid parameter"):
            opt.set_params(invalid_param=123)

    def test_solve(self):
        """Test solve returns result."""
        opt = MockOptimizer(alpha=2.0)
        result = opt.solve(x=[1, 2, 3])

        assert result.status == SolverStatus.OPTIMAL
        assert result.objective_value == 20.0
        assert result.solution == {"x": 2.0}

    def test_repr(self):
        """Test repr is sklearn-style."""
        opt = MockOptimizer(alpha=0.5, max_iter=200, name="test")
        repr_str = repr(opt)

        assert "MockOptimizer" in repr_str
        assert "alpha=0.5" in repr_str
        assert "max_iter=200" in repr_str

    def test_clone(self):
        """Test clone creates copy with same params."""
        opt = MockOptimizer(alpha=0.5, max_iter=200)
        opt2 = clone(opt)

        assert opt2.alpha == 0.5
        assert opt2.max_iter == 200
        assert opt2 is not opt

    def test_clone_with_overrides(self):
        """Test clone with parameter overrides."""
        opt = MockOptimizer(alpha=0.5, max_iter=200)
        opt2 = clone(opt, alpha=0.9)

        assert opt2.alpha == 0.9
        assert opt2.max_iter == 200

    def test_equality(self):
        """Test optimizer equality based on params."""
        opt1 = MockOptimizer(alpha=0.5)
        opt2 = MockOptimizer(alpha=0.5)
        opt3 = MockOptimizer(alpha=0.6)

        assert opt1 == opt2
        assert opt1 != opt3


class TestFitScorePipeline:
    """Tests for fit/score/Pipeline compatibility."""

    def test_fit_stores_data(self):
        opt = MockOptimizer()
        result = opt.fit(x=[1, 2, 3])
        assert result is opt
        assert opt._fit_data == {"x": [1, 2, 3]}

    def test_solve_uses_fit_data(self):
        opt = MockOptimizer(alpha=3.0)
        opt.fit(x=[1, 2])
        result = opt.solve()
        assert result.status == SolverStatus.OPTIMAL
        assert result.objective_value == 30.0

    def test_solve_kwargs_override_fit(self):
        opt = MockOptimizer()
        opt.fit(x=[1])
        result = opt.solve(x=[2, 3])
        assert result.status == SolverStatus.OPTIMAL

    def test_score_returns_objective(self):
        opt = MockOptimizer(alpha=2.0)
        score = opt.score(x=[1])
        assert score == 20.0

    def test_score_uses_fit_data(self):
        opt = MockOptimizer(alpha=5.0)
        opt.fit(x=[1])
        score = opt.score()
        assert score == 50.0


class TestConfigRoundTrip:
    """Tests for from_config/to_config."""

    def test_to_config(self):
        opt = MockOptimizer(alpha=0.5, max_iter=200, name="test")
        cfg = opt.to_config()
        assert cfg == {"alpha": 0.5, "max_iter": 200, "name": "test"}

    def test_from_config_dict(self):
        opt = MockOptimizer.from_config({"alpha": 0.7, "max_iter": 300})
        assert opt.alpha == 0.7
        assert opt.max_iter == 300

    def test_config_round_trip(self):
        original = MockOptimizer(alpha=0.3, max_iter=500, name="rt")
        cfg = original.to_config()
        restored = MockOptimizer.from_config(cfg)
        assert original == restored

    def test_from_config_ignores_unknown_keys(self):
        opt = MockOptimizer.from_config({"alpha": 0.5, "unknown_key": "ignored"})
        assert opt.alpha == 0.5
        assert not hasattr(opt, "unknown_key") or opt.name == "mock"


class TestEstimatorFromConfig:
    """Test from_config on all domain estimators."""

    def test_execution_from_config(self):
        from pyoptima.estimators.execution import ExecutionOptimizer

        opt = ExecutionOptimizer.from_config(
            {
                "strategy": "vwap",
                "horizon_minutes": 90,
                "data": {
                    "symbol": "AAPL",
                    "total_quantity": 10000,
                    "side": "buy",
                },
            }
        )
        assert opt.strategy == "vwap"
        assert opt.horizon_minutes == 90
        assert opt._fit_data["symbol"] == "AAPL"

    def test_rebalance_from_config(self):
        from pyoptima.estimators.rebalance import RebalanceOptimizer

        opt = RebalanceOptimizer.from_config(
            {
                "strategy": "min_cost",
                "max_turnover": 0.15,
            }
        )
        assert opt.strategy == "min_cost"
        assert opt.max_turnover == 0.15

    def test_signal_sizing_from_config(self):
        from pyoptima.estimators.signal_sizing import SignalSizingOptimizer

        opt = SignalSizingOptimizer.from_config(
            {
                "strategy": "kelly",
                "risk_aversion": 3.0,
            }
        )
        assert opt.strategy == "kelly"
        assert opt.risk_aversion == 3.0

    def test_risk_budget_from_config(self):
        from pyoptima.estimators.risk_budget import RiskBudgetOptimizer

        opt = RiskBudgetOptimizer.from_config(
            {
                "strategy": "reduce",
                "max_volatility": 0.20,
            }
        )
        assert opt.strategy == "reduce"
        assert opt.max_volatility == 0.20

    def test_multi_account_from_config(self):
        from pyoptima.estimators.multi_account import MultiAccountOptimizer

        opt = MultiAccountOptimizer.from_config(
            {
                "strategy": "joint",
                "objective": "max_sharpe",
            }
        )
        assert opt.strategy == "joint"
        assert opt.objective == "max_sharpe"
