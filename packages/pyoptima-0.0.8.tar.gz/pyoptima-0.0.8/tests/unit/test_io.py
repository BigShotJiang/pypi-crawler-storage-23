"""
Tests for IO layer.
"""

import json
import tempfile
from pathlib import Path

import pytest

from pyoptima.io import PortfolioData, read_portfolio_json


class TestPortfolioData:
    """Tests for PortfolioData class."""

    def test_basic_creation(self):
        """Test basic creation with lists."""
        data = PortfolioData(
            expected_returns=[0.1, 0.12, 0.08],
            covariance_matrix=[
                [0.04, 0.01, 0.02],
                [0.01, 0.05, 0.01],
                [0.02, 0.01, 0.03],
            ],
            symbols=["AAPL", "GOOGL", "MSFT"],
        )

        assert data.n_assets == 3
        assert data.symbols == ["AAPL", "GOOGL", "MSFT"]

    def test_dimension_validation(self):
        """Test dimension validation."""
        with pytest.raises(ValueError, match="Dimension mismatch"):
            PortfolioData(
                expected_returns=[0.1, 0.12],
                covariance_matrix=[
                    [0.04, 0.01, 0.02],
                    [0.01, 0.05, 0.01],
                    [0.02, 0.01, 0.03],
                ],
            )

    def test_symbol_validation(self):
        """Test symbol dimension validation."""
        with pytest.raises(ValueError, match="Dimension mismatch"):
            PortfolioData(
                expected_returns=[0.1, 0.12, 0.08],
                covariance_matrix=[
                    [0.04, 0.01, 0.02],
                    [0.01, 0.05, 0.01],
                    [0.02, 0.01, 0.03],
                ],
                symbols=["AAPL", "GOOGL"],  # Wrong length
            )

    def test_to_dict(self):
        """Test to_dict method."""
        data = PortfolioData(
            expected_returns=[0.1, 0.12],
            covariance_matrix=[[0.04, 0.01], [0.01, 0.05]],
            symbols=["A", "B"],
        )

        d = data.to_dict()
        assert "expected_returns" in d
        assert "covariance_matrix" in d
        assert "symbols" in d


class TestPortfolioDataNumpy:
    """Tests for PortfolioData with numpy."""

    def test_numpy_conversion(self):
        """Test numpy array conversion."""
        np = pytest.importorskip("numpy")

        data = PortfolioData(
            expected_returns=[0.1, 0.12, 0.08],
            covariance_matrix=[
                [0.04, 0.01, 0.02],
                [0.01, 0.05, 0.01],
                [0.02, 0.01, 0.03],
            ],
        )

        assert isinstance(data.expected_returns, np.ndarray)
        assert isinstance(data.covariance_matrix, np.ndarray)

    def test_from_returns(self):
        """Test from_returns class method."""
        np = pytest.importorskip("numpy")
        pd = pytest.importorskip("pandas")

        # Create sample returns DataFrame
        returns = pd.DataFrame(
            {
                "AAPL": np.random.randn(100) * 0.02,
                "GOOGL": np.random.randn(100) * 0.025,
                "MSFT": np.random.randn(100) * 0.02,
            }
        )

        data = PortfolioData.from_returns(returns, frequency=252)

        assert data.n_assets == 3
        assert data.symbols == ["AAPL", "GOOGL", "MSFT"]
        assert data.expected_returns is not None
        assert data.covariance_matrix is not None


class TestReadPortfolioJson:
    """Tests for read_portfolio_json function."""

    def test_read_from_dict(self):
        """Test reading from dictionary."""
        input_dict = {
            "expected_returns": [0.1, 0.12],
            "covariance_matrix": [[0.04, 0.01], [0.01, 0.05]],
            "symbols": ["A", "B"],
        }

        data = read_portfolio_json(input_dict)

        assert data.n_assets == 2
        assert data.symbols == ["A", "B"]

    def test_read_from_file(self):
        """Test reading from file."""
        input_dict = {
            "expected_returns": [0.1, 0.12, 0.08],
            "covariance_matrix": [
                [0.04, 0.01, 0.02],
                [0.01, 0.05, 0.01],
                [0.02, 0.01, 0.03],
            ],
            "symbols": ["AAPL", "GOOGL", "MSFT"],
        }

        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump(input_dict, f)
            temp_path = f.name

        try:
            data = read_portfolio_json(temp_path)

            assert data.n_assets == 3
            assert data.symbols == ["AAPL", "GOOGL", "MSFT"]
        finally:
            Path(temp_path).unlink()

    def test_missing_required_field(self):
        """Test error on missing required field."""
        input_dict = {
            "expected_returns": [0.1, 0.12],
            # Missing covariance_matrix
        }

        with pytest.raises(ValueError, match="Missing required field"):
            read_portfolio_json(input_dict)

    def test_nested_data_format(self):
        """Test reading nested data format."""
        input_dict = {
            "data": {
                "expected_returns": [0.1, 0.12],
                "covariance_matrix": [[0.04, 0.01], [0.01, 0.05]],
            }
        }

        data = read_portfolio_json(input_dict)

        assert data.n_assets == 2
