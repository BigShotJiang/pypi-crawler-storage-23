"""
Tests for composable constraints.

All constraints build real mathematical constraints on AbstractModel.
"""

import numpy as np

from pyoptima.constraints import (
    ConstraintSet,
    ExclusionList,
    InclusionList,
    LinearInequality,
    LongOnly,
    MaxAssets,
    MaxConcentration,
    MaxCVaR,
    MaxReturn,
    MaxTurnover,
    MaxVolatility,
    MinPositionSize,
    MinReturn,
    PerAssetBounds,
    SectorCaps,
    SectorConstraints,
    SectorMins,
    SumToOne,
    TrackingErrorLimit,
    TransactionCosts,
    WeightBounds,
)
from pyoptima.model.core import AbstractModel


def _make_model(n: int = 3, lb: float = 0.0, ub: float = 1.0) -> AbstractModel:
    """Create a minimal portfolio model with n weight variables."""
    model = AbstractModel("test")
    for i in range(n):
        model.add_continuous(f"w_{i}", lb=lb, ub=ub)
    return model


def _base_data(n: int = 3) -> dict:
    """Standard data dict for a 3-asset portfolio."""
    return {
        "n_assets": n,
        "symbols": [f"A{i}" for i in range(n)],
        "expected_returns": [0.10, 0.12, 0.08][:n],
        "covariance_matrix": np.eye(n).tolist(),
    }


# ============================================================== #
# Bounds
# ============================================================== #


class TestWeightBounds:
    def test_default_bounds(self):
        c = WeightBounds()
        assert c.min_weight == 0.0
        assert c.max_weight == 1.0

    def test_custom_bounds(self):
        c = WeightBounds(min_weight=0.05, max_weight=0.4)
        assert c.min_weight == 0.05
        assert c.max_weight == 0.4

    def test_repr(self):
        c = WeightBounds(min_weight=0.0, max_weight=0.4)
        assert "WeightBounds" in repr(c)
        assert "0.4" in repr(c)

    def test_apply_sets_variable_bounds(self):
        model = _make_model(3)
        data = _base_data(3)
        WeightBounds(0.05, 0.4).apply(model, data)

        for i in range(3):
            v = model.get_variable(f"w_{i}")
            assert v.lower_bound == 0.05
            assert v.upper_bound == 0.4


class TestPerAssetBounds:
    def test_bounds_dict(self):
        bounds = {"A0": (0.0, 0.3), "A1": (0.05, 0.25)}
        c = PerAssetBounds(bounds=bounds)
        assert c.bounds["A0"] == (0.0, 0.3)

    def test_apply(self):
        model = _make_model(3)
        data = _base_data(3)
        PerAssetBounds({"A1": (0.1, 0.5)}).apply(model, data)
        assert model.get_variable("w_1").lower_bound == 0.1
        assert model.get_variable("w_1").upper_bound == 0.5
        # Other variables unchanged
        assert model.get_variable("w_0").lower_bound == 0.0


class TestLongOnly:
    def test_creation(self):
        c = LongOnly()
        assert c.name == "long_only"

    def test_repr(self):
        assert "LongOnly" in repr(LongOnly())

    def test_apply_forces_nonnegative(self):
        model = _make_model(3, lb=-1.0)
        data = _base_data(3)
        LongOnly().apply(model, data)
        for i in range(3):
            assert model.get_variable(f"w_{i}").lower_bound == 0.0


# ============================================================== #
# Cardinality
# ============================================================== #


class TestMaxAssets:
    def test_max_assets_stored(self):
        c = MaxAssets(10)
        assert c.max_assets == 10

    def test_apply_adds_constraints(self):
        model = _make_model(4)
        data = _base_data(4)
        MaxAssets(2).apply(model, data)

        # Should have binary variables z_0..z_3
        for i in range(4):
            z = model.get_variable(f"z_{i}")
            assert z is not None

        # Should have cardinality constraint
        assert "max_assets" in model.constraints

        # Should have link constraints
        for i in range(4):
            assert f"card_link_{i}" in model.constraints


class TestMinPositionSize:
    def test_apply_creates_lower_bounds(self):
        model = _make_model(3)
        data = _base_data(3)
        MinPositionSize(0.05).apply(model, data)

        for i in range(3):
            assert f"min_pos_{i}" in model.constraints


# ============================================================== #
# Sector
# ============================================================== #


class TestSectorConstraints:
    def test_sector_caps(self):
        c = SectorCaps(
            caps={"Tech": 0.4, "Finance": 0.3},
            asset_sectors={"A0": "Tech", "A1": "Finance"},
        )
        assert c.caps["Tech"] == 0.4

    def test_apply_adds_constraint(self):
        model = _make_model(3)
        data = _base_data(3)
        SectorCaps(
            caps={"Tech": 0.4},
            asset_sectors={"A0": "Tech", "A1": "Tech"},
        ).apply(model, data)
        assert "sector_cap_Tech" in model.constraints

    def test_sector_mins(self):
        c = SectorMins(mins={"Healthcare": 0.1})
        assert c.mins["Healthcare"] == 0.1

    def test_combined_sector_constraints(self):
        model = _make_model(3)
        data = _base_data(3)
        SectorConstraints(
            caps={"Tech": 0.5},
            mins={"Fin": 0.1},
            asset_sectors={"A0": "Tech", "A1": "Fin"},
        ).apply(model, data)
        assert "sector_cap_Tech" in model.constraints
        assert "sector_min_Fin" in model.constraints


# ============================================================== #
# Risk
# ============================================================== #


class TestRiskConstraints:
    def test_max_volatility_stored(self):
        c = MaxVolatility(0.2)
        assert c.max_volatility == 0.2

    def test_max_volatility_adds_quadratic(self):
        model = _make_model(3)
        data = _base_data(3)
        MaxVolatility(0.2).apply(model, data)
        assert "max_volatility" in model.constraints
        # Should be quadratic
        c = model.constraints["max_volatility"]
        assert c.lhs.is_quadratic

    def test_max_cvar(self):
        c = MaxCVaR(max_cvar=0.05, confidence=0.95)
        assert c.max_cvar == 0.05
        assert c.confidence == 0.95

    def test_max_cvar_adds_constraints(self):
        model = _make_model(3)
        data = _base_data(3)
        data["returns"] = np.random.randn(10, 3).tolist()
        MaxCVaR(0.05).apply(model, data)
        assert "max_cvar" in model.constraints
        assert model.get_variable("cvar_zeta") is not None

    def test_tracking_error_adds_quadratic(self):
        model = _make_model(3)
        data = _base_data(3)
        data["benchmark_weights"] = {"A0": 0.5, "A1": 0.3, "A2": 0.2}
        TrackingErrorLimit(0.05).apply(model, data)
        assert "max_tracking_error" in model.constraints

    def test_max_concentration_top1(self):
        model = _make_model(3)
        data = _base_data(3)
        MaxConcentration(0.4, top_k=1).apply(model, data)
        # Should tighten upper bounds
        for i in range(3):
            assert model.get_variable(f"w_{i}").upper_bound == 0.4


# ============================================================== #
# Portfolio
# ============================================================== #


class TestPortfolioConstraints:
    def test_sum_to_one(self):
        model = _make_model(3)
        data = _base_data(3)
        SumToOne().apply(model, data)
        assert "sum_to_one" in model.constraints

    def test_min_return(self):
        model = _make_model(3)
        data = _base_data(3)
        MinReturn(0.10).apply(model, data)
        assert "min_return" in model.constraints

    def test_max_return(self):
        model = _make_model(3)
        data = _base_data(3)
        MaxReturn(0.20).apply(model, data)
        assert "max_return" in model.constraints

    def test_exclusion_list(self):
        model = _make_model(3)
        data = _base_data(3)
        ExclusionList(["A1"]).apply(model, data)
        assert model.get_variable("w_1").upper_bound == 0.0

    def test_inclusion_list(self):
        model = _make_model(3)
        data = _base_data(3)
        InclusionList(["A0"]).apply(model, data)
        assert model.get_variable("w_0").upper_bound == 1.0  # kept
        assert model.get_variable("w_1").upper_bound == 0.0  # excluded
        assert model.get_variable("w_2").upper_bound == 0.0  # excluded


# ============================================================== #
# Turnover
# ============================================================== #


class TestTurnoverConstraints:
    def test_max_turnover(self):
        model = _make_model(3)
        data = _base_data(3)
        MaxTurnover(
            max_turnover=0.2,
            current_weights={"A0": 0.3, "A1": 0.4, "A2": 0.3},
        ).apply(model, data)
        assert "max_turnover" in model.constraints
        # Should have buy/sell variables
        for i in range(3):
            assert model.get_variable(f"buy_{i}") is not None
            assert model.get_variable(f"sell_{i}") is not None

    def test_transaction_costs_with_max(self):
        model = _make_model(3)
        data = _base_data(3)
        TransactionCosts(
            costs=0.001,
            current_weights={"A0": 0.3, "A1": 0.3, "A2": 0.4},
            max_cost=0.005,
        ).apply(model, data)
        assert "max_transaction_cost" in model.constraints


# ============================================================== #
# Linear
# ============================================================== #


class TestLinearInequality:
    def test_apply_leq(self):
        model = _make_model(3)
        data = _base_data(3)
        LinearInequality(A=[[1, 1, 0]], b=[0.5], sense="<=").apply(model, data)
        assert "linear_0" in model.constraints

    def test_apply_geq(self):
        model = _make_model(3)
        data = _base_data(3)
        LinearInequality(A=[[1, 0, 1]], b=[0.3], sense=">=").apply(model, data)
        c = model.constraints["linear_0"]
        from pyoptima.model.core import ConstraintSense

        assert c.sense == ConstraintSense.GEQ


# ============================================================== #
# Composition
# ============================================================== #


class TestConstraintCombination:
    def test_add_two_constraints(self):
        c1 = WeightBounds(0, 0.4)
        c2 = MaxAssets(10)
        combined = c1 + c2
        assert isinstance(combined, ConstraintSet)
        assert len(combined) == 2

    def test_add_constraint_to_set(self):
        c1 = WeightBounds(0, 0.4)
        c2 = MaxAssets(10)
        c3 = LongOnly()
        combined = c1 + c2 + c3
        assert len(combined) == 3

    def test_constraint_set_iteration(self):
        combined = WeightBounds(0, 0.4) + MaxAssets(10)
        assert len(list(combined)) == 2

    def test_constraint_set_repr(self):
        combined = WeightBounds(0, 0.4) + MaxAssets(10)
        r = repr(combined)
        assert "ConstraintSet" in r
        assert "weight_bounds" in r
        assert "max_assets" in r

    def test_apply_all(self):
        model = _make_model(3)
        data = _base_data(3)
        constraints = WeightBounds(0.05, 0.4) + SumToOne()
        constraints.apply_all(model, data)

        # Bounds applied
        assert (
            model.get_variable("w_0").min_weight
            if hasattr(model.get_variable("w_0"), "min_weight")
            else model.get_variable("w_0").lower_bound == 0.05
        )
        # Sum to one constraint added
        assert "sum_to_one" in model.constraints


# ============================================================== #
# Config round-trip
# ============================================================== #


class TestFromConfig:
    def test_weight_bounds_from_config(self):
        class _FakeConfig:
            min = 0.05
            max = 0.4

        c = WeightBounds.from_config(_FakeConfig())
        assert c.min_weight == 0.05
        assert c.max_weight == 0.4

    def test_to_config(self):
        c = WeightBounds(0.05, 0.4)
        cfg = c.to_config()
        assert cfg["min_weight"] == 0.05
        assert cfg["max_weight"] == 0.4

    def test_max_assets_from_config(self):
        class _FakeConfig:
            max_assets = 10

        c = MaxAssets.from_config(_FakeConfig())
        assert c.max_assets == 10
