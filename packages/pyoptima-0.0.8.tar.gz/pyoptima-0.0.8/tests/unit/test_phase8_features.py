"""
Tests for Phase 8 features: warm start, LP export, model summary,
diagnostics (IIS, sensitivity, diagnose), config utilities (validate,
generate, diff).
"""

import json

import pytest

from pyoptima.core.result import OptimizationResult, SolverStatus
from pyoptima.model.core import AbstractModel, Expression
from pyoptima.solvers.base import SolverOptions

# ===================================================================
# Warm start
# ===================================================================


class TestWarmStart:
    """Tests for AbstractModel warm start support."""

    def test_set_initial(self):
        model = AbstractModel("test")
        model.add_continuous("x", lb=0.0, ub=1.0)
        model.add_continuous("y", lb=0.0, ub=1.0)

        model.set_initial({"x": 0.5, "y": 0.3})

        assert model.get_variable("x").value == 0.5
        assert model.get_variable("y").value == 0.3

    def test_set_initial_missing_variable(self):
        """set_initial should silently ignore unknown variable names."""
        model = AbstractModel("test")
        model.add_continuous("x", lb=0.0, ub=1.0)

        model.set_initial({"x": 0.5, "z_missing": 0.9})
        assert model.get_variable("x").value == 0.5
        assert model.get_variable("z_missing") is None

    def test_set_initial_from_result(self):
        model = AbstractModel("test")
        model.add_continuous("a", lb=0.0, ub=1.0)
        model.add_continuous("b", lb=0.0, ub=1.0)

        result = OptimizationResult(
            status=SolverStatus.OPTIMAL,
            solution={"a": 0.7, "b": 0.3},
        )
        model.set_initial_from_result(result)

        assert model.get_variable("a").value == 0.7
        assert model.get_variable("b").value == 0.3

    def test_set_initial_from_result_no_solution(self):
        model = AbstractModel("test")
        model.add_continuous("x", lb=0.0)
        result = OptimizationResult(status=SolverStatus.INFEASIBLE)
        # Should not raise
        model.set_initial_from_result(result)
        assert model.get_variable("x").value is None

    def test_solver_options_warm_start_field(self):
        opts = SolverOptions()
        assert opts.warm_start is False

        opts = SolverOptions(warm_start=True)
        assert opts.warm_start is True


# ===================================================================
# LP export
# ===================================================================


class TestLPExport:
    """Tests for AbstractModel.to_lp()."""

    def _build_small_model(self) -> AbstractModel:
        model = AbstractModel("small_lp")
        model.add_continuous("x", lb=0.0, ub=10.0)
        model.add_continuous("y", lb=0.0, ub=10.0)

        obj = Expression()
        obj.add_term(1.0, "x")
        obj.add_term(2.0, "y")
        model.minimize(obj)

        lhs = Expression()
        lhs.add_term(1.0, "x")
        lhs.add_term(1.0, "y")
        model.add_leq_constraint("budget", lhs, 5.0)

        return model

    def test_to_lp_string(self):
        model = self._build_small_model()
        lp = model.to_lp()

        assert "Minimize" in lp
        assert "Subject To" in lp
        assert "Bounds" in lp
        assert "End" in lp
        assert "budget" in lp

    def test_to_lp_objective_direction(self):
        model = AbstractModel("max_test")
        model.add_continuous("x", lb=0.0, ub=1.0)
        expr = Expression()
        expr.add_term(3.0, "x")
        model.maximize(expr)
        lp = model.to_lp()
        assert "Maximize" in lp

    def test_to_lp_binary_variables(self):
        model = AbstractModel("mip")
        model.add_binary("z")
        model.minimize(Expression())
        lp = model.to_lp()
        assert "Binary" in lp
        assert "z" in lp

    def test_to_lp_integer_variables(self):
        model = AbstractModel("ip")
        model.add_integer("n", lb=0, ub=100)
        model.minimize(Expression())
        lp = model.to_lp()
        assert "General" in lp
        assert "n" in lp

    def test_to_lp_file_export(self, tmp_path):
        model = self._build_small_model()
        path = str(tmp_path / "test.lp")
        lp = model.to_lp(path=path)

        with open(path) as f:
            content = f.read()
        assert content == lp

    def test_to_lp_quadratic(self):
        model = AbstractModel("qp")
        model.add_continuous("x", lb=0.0, ub=1.0)
        model.add_continuous("y", lb=0.0, ub=1.0)

        expr = Expression()
        expr.add_term(1.0, "x", "x")
        expr.add_term(0.5, "x", "y")
        model.minimize(expr)
        lp = model.to_lp()
        assert "*" in lp  # quadratic term marker
        assert "QP" in lp or "Type" in lp


# ===================================================================
# Model summary
# ===================================================================


class TestModelSummary:
    """Tests for AbstractModel.summary()."""

    def test_summary_basic(self):
        model = AbstractModel("test_summary")
        model.add_continuous("x", lb=0.0, ub=1.0)
        model.add_continuous("y", lb=0.0, ub=1.0)
        model.add_binary("z")

        expr = Expression()
        expr.add_term(1.0, "x")
        model.minimize(expr)

        lhs = Expression()
        lhs.add_term(1.0, "x")
        lhs.add_term(1.0, "y")
        model.add_leq_constraint("c1", lhs, 1.0)

        summary = model.summary()
        assert "test_summary" in summary
        assert "Variables" in summary
        assert "3" in summary  # 3 variables
        assert "Constraints" in summary
        assert "1" in summary  # 1 constraint
        assert "continuous" in summary
        assert "binary" in summary

    def test_summary_no_objective(self):
        model = AbstractModel("empty")
        model.add_continuous("x")
        summary = model.summary()
        assert "Objective" not in summary


# ===================================================================
# Diagnostics
# ===================================================================


class TestDiagnostics:
    """Tests for the diagnostics module."""

    def test_diagnose_optimal(self):
        from pyoptima.diagnostics import diagnose

        result = OptimizationResult(
            status=SolverStatus.OPTIMAL,
            objective_value=1.5,
            solve_time=0.01,
        )
        report = diagnose(result)
        assert "optimal" in report.lower() or "optimal" in report
        assert "No issues detected" in report

    def test_diagnose_infeasible(self):
        from pyoptima.diagnostics import diagnose

        result = OptimizationResult(
            status=SolverStatus.INFEASIBLE,
            solver_message="infeasible model",
        )
        report = diagnose(result)
        assert "INFEASIBLE" in report
        assert "Suggestions" in report

    def test_diagnose_unbounded(self):
        from pyoptima.diagnostics import diagnose

        result = OptimizationResult(status=SolverStatus.UNBOUNDED)
        report = diagnose(result)
        assert "UNBOUNDED" in report

    def test_diagnose_time_limit(self):
        from pyoptima.diagnostics import diagnose

        result = OptimizationResult(status=SolverStatus.TIME_LIMIT)
        report = diagnose(result)
        assert "TIME LIMIT" in report
        assert "warm_start" in report

    def test_diagnose_error(self):
        from pyoptima.diagnostics import diagnose

        result = OptimizationResult(
            status=SolverStatus.ERROR,
            solver_message="Solver crashed",
        )
        report = diagnose(result)
        assert "ERROR" in report

    def test_diagnose_feasible_with_gap(self):
        from pyoptima.diagnostics import diagnose

        result = OptimizationResult(
            status=SolverStatus.FEASIBLE,
            objective_value=10.0,
            gap=0.05,
        )
        report = diagnose(result)
        assert "NOT proven optimal" in report
        assert "5.00" in report  # 5.0000% format

    def test_iis_result_repr(self):
        from pyoptima.diagnostics import IISResult

        iis = IISResult(
            infeasible_constraints=["c1", "c2"],
            infeasible_bounds=["x"],
        )
        r = repr(iis)
        assert "constraints=2" in r
        assert "bounds=1" in r

    def test_iis_result_summary_empty(self):
        from pyoptima.diagnostics import IISResult

        iis = IISResult()
        assert iis.is_empty
        assert "feasible" in iis.summary().lower()

    def test_iis_result_summary_nonempty(self):
        from pyoptima.diagnostics import IISResult

        iis = IISResult(infeasible_constraints=["c1", "c2"])
        assert not iis.is_empty
        summary = iis.summary()
        assert "c1" in summary
        assert "c2" in summary
        assert "relax" in summary.lower()


class TestSensitivityReport:
    """Tests for sensitivity report."""

    def test_sensitivity_report_basic(self):
        from pyoptima.diagnostics import sensitivity_report

        model = AbstractModel("sens_test")
        model.add_continuous("x", lb=0.0, ub=1.0)
        model.add_continuous("y", lb=0.0, ub=1.0)

        obj = Expression()
        obj.add_term(1.0, "x")
        obj.add_term(2.0, "y")
        model.minimize(obj)

        lhs = Expression()
        lhs.add_term(1.0, "x")
        lhs.add_term(1.0, "y")
        model.add_eq_constraint("sum_one", lhs, 1.0)

        result = OptimizationResult(
            status=SolverStatus.OPTIMAL,
            objective_value=1.0,
            solution={"x": 1.0, "y": 0.0},
        )

        report = sensitivity_report(model, result)
        assert "sum_one" in report.binding_constraints
        assert "sum_one" in report.shadow_prices
        assert isinstance(report.summary(), str)

    def test_sensitivity_report_infeasible(self):
        from pyoptima.diagnostics import sensitivity_report

        model = AbstractModel("infeasible")
        result = OptimizationResult(status=SolverStatus.INFEASIBLE)
        report = sensitivity_report(model, result)
        assert len(report.binding_constraints) == 0

    def test_sensitivity_report_repr(self):
        from pyoptima.diagnostics import SensitivityReport

        report = SensitivityReport(
            binding_constraints=["c1"],
            shadow_prices={"c1": 0.5},
        )
        r = repr(report)
        assert "binding=1" in r


class TestEvaluateExpression:
    """Tests for expression evaluation in diagnostics."""

    def test_evaluate_linear(self):
        from pyoptima.diagnostics import _evaluate_expression

        expr = Expression()
        expr.add_term(2.0, "x")
        expr.add_term(3.0, "y")
        expr.add_constant(1.0)

        val = _evaluate_expression(expr, {"x": 1.0, "y": 2.0})
        assert abs(val - 9.0) < 1e-10  # 2*1 + 3*2 + 1

    def test_evaluate_quadratic(self):
        from pyoptima.diagnostics import _evaluate_expression

        expr = Expression()
        expr.add_term(1.0, "x", "x")
        expr.add_term(2.0, "x", "y")

        val = _evaluate_expression(expr, {"x": 3.0, "y": 2.0})
        assert abs(val - 21.0) < 1e-10  # 1*3*3 + 2*3*2 = 9 + 12


# ===================================================================
# Config utilities
# ===================================================================


class TestConfigValidate:
    """Tests for config_utils.validate()."""

    def test_validate_valid_config(self):
        from pyoptima.config_utils import validate

        config = {
            "template": "portfolio",
            "objective": {"name": "min_volatility"},
            "data": {
                "symbols": ["A", "B"],
                "expected_returns": [0.1, 0.12],
                "covariance_matrix": [[0.04, 0.01], [0.01, 0.03]],
            },
        }
        errors = validate(config)
        assert errors == []

    def test_validate_missing_template(self):
        from pyoptima.config_utils import validate

        errors = validate({"objective": {"name": "min_volatility"}})
        assert len(errors) > 0
        assert any("template" in e for e in errors)

    def test_validate_invalid_data(self):
        from pyoptima.config_utils import validate

        config = {
            "template": "portfolio",
            "objective": {"name": "min_volatility"},
            # Missing required 'data' field
        }
        errors = validate(config)
        assert len(errors) > 0

    def test_validate_invalid_objective(self):
        from pyoptima.config_utils import validate

        config = {
            "template": "portfolio",
            "objective": {"name": "nonexistent_objective"},
            "data": {
                "symbols": ["A"],
                "expected_returns": [0.1],
                "covariance_matrix": [[0.04]],
            },
        }
        errors = validate(config)
        assert len(errors) > 0

    def test_validate_file_not_found(self):
        from pyoptima.config_utils import validate

        errors = validate("/nonexistent/config.yaml")
        assert len(errors) > 0
        assert any("not found" in e.lower() for e in errors)


class TestConfigGenerate:
    """Tests for config_utils.generate()."""

    def test_generate_portfolio_json(self):
        from pyoptima.config_utils import generate

        config_str = generate("portfolio", format="json")
        data = json.loads(config_str)
        assert data["template"] == "portfolio"
        assert "objective" in data
        assert "data" in data
        assert "solver" in data

    def test_generate_execution(self):
        from pyoptima.config_utils import generate

        config_str = generate("execution", format="json")
        data = json.loads(config_str)
        assert data["template"] == "execution"
        assert data["strategy"] == "twap"

    def test_generate_all_templates(self):
        from pyoptima.config_utils import generate

        templates = [
            "portfolio",
            "execution",
            "rebalance",
            "signal_sizing",
            "risk_budget",
            "trading_schedule",
            "multi_account",
        ]
        for t in templates:
            config_str = generate(t, format="json")
            data = json.loads(config_str)
            assert data["template"] == t

    def test_generate_unknown_template(self):
        from pyoptima.config_utils import generate

        with pytest.raises(ValueError, match="Unknown template"):
            generate("nonexistent")

    def test_generate_validates(self):
        """Generated configs should pass validation."""
        from pyoptima.config_utils import generate, validate

        for template in [
            "portfolio",
            "execution",
            "rebalance",
            "signal_sizing",
            "risk_budget",
            "trading_schedule",
            "multi_account",
        ]:
            config_str = generate(template, format="json")
            config = json.loads(config_str)
            errors = validate(config)
            assert errors == [], (
                f"Template '{template}' generated invalid config: {errors}"
            )


class TestConfigDiff:
    """Tests for config_utils.diff()."""

    def test_diff_identical(self):
        from pyoptima.config_utils import diff

        config = {"template": "portfolio", "solver": {"name": "highs"}}
        diffs = diff(config, config)
        assert diffs == []

    def test_diff_value_changed(self):
        from pyoptima.config_utils import diff

        c1 = {"template": "portfolio", "solver": {"name": "highs"}}
        c2 = {"template": "portfolio", "solver": {"name": "ipopt"}}
        diffs = diff(c1, c2)
        assert len(diffs) == 1
        assert "solver.name" in diffs[0]
        assert "highs" in diffs[0]
        assert "ipopt" in diffs[0]

    def test_diff_key_added(self):
        from pyoptima.config_utils import diff

        c1 = {"template": "portfolio"}
        c2 = {"template": "portfolio", "solver": {"name": "highs"}}
        diffs = diff(c1, c2)
        assert any("added" in d for d in diffs)

    def test_diff_key_removed(self):
        from pyoptima.config_utils import diff

        c1 = {"template": "portfolio", "solver": {"name": "highs"}}
        c2 = {"template": "portfolio"}
        diffs = diff(c1, c2)
        assert any("removed" in d for d in diffs)

    def test_diff_nested(self):
        from pyoptima.config_utils import diff

        c1 = {"objective": {"name": "min_vol", "risk_free_rate": 0.02}}
        c2 = {"objective": {"name": "max_sharpe", "risk_free_rate": 0.02}}
        diffs = diff(c1, c2)
        assert len(diffs) == 1
        assert "objective.name" in diffs[0]

    def test_diff_list_length_change(self):
        from pyoptima.config_utils import diff

        c1 = {"data": {"symbols": ["A", "B"]}}
        c2 = {"data": {"symbols": ["A", "B", "C"]}}
        diffs = diff(c1, c2)
        assert any("length" in d for d in diffs)

    def test_diff_list_value_change(self):
        from pyoptima.config_utils import diff

        c1 = {"data": {"returns": [0.1, 0.2]}}
        c2 = {"data": {"returns": [0.1, 0.3]}}
        diffs = diff(c1, c2)
        assert len(diffs) == 1
        assert "returns[1]" in diffs[0]


# ===================================================================
# Top-level imports
# ===================================================================


class TestTopLevelImports:
    """Verify Phase 8 features are importable from pyoptima."""

    def test_import_diagnose(self):
        from pyoptima import diagnose

        assert callable(diagnose)

    def test_import_find_iis(self):
        from pyoptima import find_iis

        assert callable(find_iis)

    def test_import_validate_config(self):
        from pyoptima import validate_config

        assert callable(validate_config)

    def test_import_generate_config(self):
        from pyoptima import generate_config

        assert callable(generate_config)

    def test_import_diff_config(self):
        from pyoptima import diff_config

        assert callable(diff_config)

    def test_all_exports(self):
        import pyoptima

        all_exports = pyoptima.__all__
        for name in [
            "diagnose",
            "find_iis",
            "validate_config",
            "generate_config",
            "diff_config",
        ]:
            assert name in all_exports, f"{name} not in __all__"
