"""
Unit tests for the shared trading infrastructure.

Tests:
- Cost models (Linear, SquareRoot, AlmgrenChriss, factory)
- Risk models (Covariance, Factor)
- Market data containers (VolumeProfile, MarketData)
"""

import math

import numpy as np
import pytest

from pyoptima.trading.costs import (
    AlmgrenChrissCostModel,
    LinearCostModel,
    SquareRootCostModel,
    get_cost_model,
)
from pyoptima.trading.market_data import MarketData, VolumeProfile
from pyoptima.trading.risk import CovarianceRiskModel, FactorRiskModel

# =============================================================================
# Cost Models
# =============================================================================


class TestLinearCostModel:
    def test_basic_estimate(self):
        model = LinearCostModel(eta=10.0)
        bps = model.estimate(quantity=1_000_000, adv=10_000_000, spread=1.0)
        # spread/2 + eta * (1M/10M) = 0.5 + 10 * 0.1 = 1.5
        assert abs(bps - 1.5) < 1e-10

    def test_zero_quantity(self):
        model = LinearCostModel(eta=10.0)
        bps = model.estimate(quantity=0, adv=10_000_000, spread=1.0)
        assert abs(bps - 0.5) < 1e-10  # Just spread/2

    def test_negative_quantity_uses_abs(self):
        model = LinearCostModel(eta=10.0)
        bps_pos = model.estimate(quantity=1_000_000, adv=10_000_000)
        bps_neg = model.estimate(quantity=-1_000_000, adv=10_000_000)
        assert abs(bps_pos - bps_neg) < 1e-10

    def test_invalid_adv_raises(self):
        model = LinearCostModel()
        with pytest.raises(ValueError, match="adv must be positive"):
            model.estimate(quantity=1000, adv=0)

    def test_name(self):
        assert LinearCostModel().name == "linear"

    def test_to_dict(self):
        model = LinearCostModel(eta=5.0)
        d = model.to_dict()
        assert d["name"] == "linear"
        assert d["eta"] == 5.0

    def test_total_cost(self):
        model = LinearCostModel(eta=10.0)
        cost = model.total_cost(quantity=1000, adv=10_000_000, price=100.0, spread=1.0)
        bps = model.estimate(quantity=1000, adv=10_000_000, price=100.0, spread=1.0)
        expected = 100.0 * 1000 * bps / 10_000
        assert abs(cost - expected) < 1e-6


class TestSquareRootCostModel:
    def test_basic_estimate(self):
        model = SquareRootCostModel(eta=0.5, sigma=0.02)
        bps = model.estimate(quantity=50_000, adv=10_000_000, spread=1.0)
        # spread/2 + eta * sigma * sqrt(50K/10M) * 10000
        participation = 50_000 / 10_000_000
        expected = 0.5 + 0.5 * 0.02 * math.sqrt(participation) * 10_000
        assert abs(bps - expected) < 1e-6

    def test_name(self):
        assert SquareRootCostModel().name == "sqrt"


class TestAlmgrenChrissCostModel:
    def test_basic_estimate(self):
        model = AlmgrenChrissCostModel(eta=0.1, gamma=0.05, sigma=0.02)
        bps = model.estimate(quantity=100_000, adv=10_000_000, spread=1.0)
        assert bps > 0.5  # At least half spread

    def test_name(self):
        assert AlmgrenChrissCostModel().name == "almgren_chriss"

    def test_to_dict(self):
        model = AlmgrenChrissCostModel(
            eta=0.1, gamma=0.05, sigma=0.02, horizon_days=2.0
        )
        d = model.to_dict()
        assert d["name"] == "almgren_chriss"
        assert d["horizon_days"] == 2.0


class TestCostModelFactory:
    def test_linear(self):
        model = get_cost_model("linear", eta=5.0)
        assert isinstance(model, LinearCostModel)
        assert model.eta == 5.0

    def test_sqrt(self):
        model = get_cost_model("sqrt")
        assert isinstance(model, SquareRootCostModel)

    def test_square_root_alias(self):
        model = get_cost_model("square_root")
        assert isinstance(model, SquareRootCostModel)

    def test_almgren_chriss(self):
        model = get_cost_model("almgren_chriss")
        assert isinstance(model, AlmgrenChrissCostModel)

    def test_ac_alias(self):
        model = get_cost_model("ac")
        assert isinstance(model, AlmgrenChrissCostModel)

    def test_unknown_raises(self):
        with pytest.raises(ValueError, match="Unknown cost model"):
            get_cost_model("nonexistent")


# =============================================================================
# Risk Models
# =============================================================================


class TestCovarianceRiskModel:
    def test_basic_variance(self):
        cov = np.array([[0.04, 0.01], [0.01, 0.09]])
        model = CovarianceRiskModel(covariance_matrix=cov)
        w = np.array([0.6, 0.4])
        var = model.portfolio_variance(w)
        expected = float(w @ cov @ w)
        assert abs(var - expected) < 1e-10

    def test_portfolio_risk(self):
        cov = np.array([[0.04, 0.01], [0.01, 0.09]])
        model = CovarianceRiskModel(covariance_matrix=cov)
        w = np.array([0.6, 0.4])
        risk = model.portfolio_risk(w)
        assert risk == pytest.approx(math.sqrt(float(w @ cov @ w)), abs=1e-10)

    def test_marginal_risk(self):
        cov = np.array([[0.04, 0.01], [0.01, 0.09]])
        model = CovarianceRiskModel(covariance_matrix=cov)
        w = np.array([0.6, 0.4])
        mr = model.marginal_risk(w)
        assert len(mr) == 2

    def test_risk_contributions_sum_to_one(self):
        cov = np.array([[0.04, 0.01], [0.01, 0.09]])
        model = CovarianceRiskModel(covariance_matrix=cov)
        w = np.array([0.6, 0.4])
        rc = model.risk_contributions(w)
        assert abs(sum(rc) - 1.0) < 1e-6

    def test_dimension_mismatch_raises(self):
        cov = np.array([[0.04, 0.01], [0.01, 0.09]])
        model = CovarianceRiskModel(covariance_matrix=cov)
        with pytest.raises(ValueError, match="weights length"):
            model.portfolio_variance(np.array([0.5, 0.3, 0.2]))

    def test_name(self):
        model = CovarianceRiskModel(covariance_matrix=np.eye(2))
        assert model.name == "covariance"

    def test_to_dict(self):
        cov = np.array([[0.04, 0.01], [0.01, 0.09]])
        model = CovarianceRiskModel(covariance_matrix=cov)
        d = model.to_dict()
        assert d["name"] == "covariance"
        assert len(d["covariance_matrix"]) == 2


class TestFactorRiskModel:
    def test_basic_variance(self):
        B = np.array([[1.1, 0.2], [0.9, -0.1], [0.8, 0.5]])
        Sf = np.array([[0.04, 0.005], [0.005, 0.01]])
        D = np.array([0.001, 0.002, 0.0015])
        model = FactorRiskModel(B, Sf, D)
        w = np.array([0.4, 0.3, 0.3])
        var = model.portfolio_variance(w)
        assert var > 0

    def test_factor_exposures(self):
        B = np.array([[1.1, 0.2], [0.9, -0.1]])
        Sf = np.array([[0.04, 0.005], [0.005, 0.01]])
        D = np.array([0.001, 0.002])
        model = FactorRiskModel(B, Sf, D, factor_names=["Market", "Size"])
        w = np.array([0.6, 0.4])
        exp = model.factor_exposures(w)
        assert "Market" in exp
        assert "Size" in exp

    def test_name(self):
        B = np.array([[1.0]])
        Sf = np.array([[0.04]])
        D = np.array([0.001])
        model = FactorRiskModel(B, Sf, D)
        assert model.name == "factor"


# =============================================================================
# Market Data Containers
# =============================================================================


class TestVolumeProfile:
    def test_basic_creation(self):
        vp = VolumeProfile(
            intervals=["09:30", "09:35", "09:40"],
            volumes=[0.08, 0.06, 0.05],
            symbol="AAPL",
        )
        assert vp.n_intervals == 3
        assert vp.symbol == "AAPL"

    def test_length_mismatch_raises(self):
        with pytest.raises(ValueError, match="same length"):
            VolumeProfile(intervals=["09:30", "09:35"], volumes=[0.08])

    def test_normalized(self):
        vp = VolumeProfile(intervals=["a", "b", "c"], volumes=[2.0, 3.0, 5.0])
        norm = vp.normalized()
        assert abs(sum(norm) - 1.0) < 1e-10
        assert abs(norm[0] - 0.2) < 1e-10

    def test_normalized_zero_total(self):
        vp = VolumeProfile(intervals=["a", "b"], volumes=[0.0, 0.0])
        norm = vp.normalized()
        assert abs(sum(norm) - 1.0) < 1e-10

    def test_uniform(self):
        vp = VolumeProfile.uniform(24, interval_minutes=5, start="09:30")
        assert vp.n_intervals == 24
        assert abs(sum(vp.volumes) - 1.0) < 1e-10
        assert vp.intervals[0] == "09:30"
        assert vp.intervals[1] == "09:35"

    def test_roundtrip_dict(self):
        vp = VolumeProfile(
            intervals=["09:30", "09:35"],
            volumes=[0.6, 0.4],
            symbol="AAPL",
        )
        d = vp.to_dict()
        vp2 = VolumeProfile.from_dict(d)
        assert vp2.intervals == vp.intervals
        assert vp2.volumes == vp.volumes
        assert vp2.symbol == vp.symbol


class TestMarketData:
    def test_basic_creation(self):
        md = MarketData(
            symbols=["AAPL", "MSFT"],
            adv={"AAPL": 75_000_000, "MSFT": 25_000_000},
        )
        assert md.get_adv("AAPL") == 75_000_000

    def test_missing_adv_raises(self):
        with pytest.raises(ValueError, match="adv missing"):
            MarketData(
                symbols=["AAPL", "MSFT"],
                adv={"AAPL": 75_000_000},  # MSFT missing
            )

    def test_get_spread_default(self):
        md = MarketData(
            symbols=["AAPL"],
            adv={"AAPL": 75_000_000},
        )
        assert md.get_spread("AAPL") == 1.0  # default

    def test_get_price_default(self):
        md = MarketData(symbols=["AAPL"], adv={"AAPL": 1})
        assert md.get_price("AAPL") == 100.0

    def test_roundtrip_dict(self):
        md = MarketData(
            symbols=["AAPL", "MSFT"],
            adv={"AAPL": 75_000_000, "MSFT": 25_000_000},
            price={"AAPL": 185.50, "MSFT": 420.00},
            bid_ask_spread={"AAPL": 1.0, "MSFT": 1.5},
        )
        d = md.to_dict()
        md2 = MarketData.from_dict(d)
        assert md2.symbols == md.symbols
        assert md2.adv == md.adv
        assert md2.price == md.price
