"""
Tests for OptimizationResult class.
"""

import json

import pytest

from pyoptima.core.result import (
    ExecutionResult,
    OptimizationResult,
    PortfolioResult,
    RebalanceResult,
    RiskBudgetResult,
    SignalSizingResult,
    SolverStatus,
)


class TestSolverStatus:
    """Tests for SolverStatus enum."""

    def test_status_values(self):
        """Test status enum values."""
        assert SolverStatus.OPTIMAL.value == "optimal"
        assert SolverStatus.FEASIBLE.value == "feasible"
        assert SolverStatus.INFEASIBLE.value == "infeasible"
        assert SolverStatus.ERROR.value == "error"


class TestOptimizationResult:
    """Tests for OptimizationResult."""

    @pytest.fixture
    def sample_result(self):
        """Create a sample result."""
        return OptimizationResult(
            status=SolverStatus.OPTIMAL,
            objective_value=0.025,
            solution={"AAPL": 0.3, "GOOGL": 0.4, "MSFT": 0.3},
            solve_time=0.5,
            solver_name="ipopt",
            weights={"AAPL": 0.3, "GOOGL": 0.4, "MSFT": 0.3},
            portfolio_return=0.12,
            portfolio_volatility=0.15,
            sharpe_ratio=0.8,
        )

    def test_is_optimal(self, sample_result):
        """Test is_optimal property."""
        assert sample_result.is_optimal is True

        infeasible = OptimizationResult(status=SolverStatus.INFEASIBLE)
        assert infeasible.is_optimal is False

    def test_is_feasible(self, sample_result):
        """Test is_feasible property."""
        assert sample_result.is_feasible is True

        feasible = OptimizationResult(status=SolverStatus.FEASIBLE)
        assert feasible.is_feasible is True

        infeasible = OptimizationResult(status=SolverStatus.INFEASIBLE)
        assert infeasible.is_feasible is False

    def test_to_dict(self, sample_result):
        """Test to_dict method."""
        d = sample_result.to_dict()

        assert d["status"] == "optimal"
        assert d["objective_value"] == 0.025
        assert d["weights"]["AAPL"] == 0.3
        assert d["portfolio_return"] == 0.12
        assert d["sharpe_ratio"] == 0.8

    def test_to_json(self, sample_result):
        """Test to_json method."""
        json_str = sample_result.to_json()

        # Should be valid JSON
        data = json.loads(json_str)
        assert data["status"] == "optimal"
        assert data["objective_value"] == 0.025

    def test_repr(self, sample_result):
        """Test repr."""
        repr_str = repr(sample_result)

        assert "OptimizationResult" in repr_str
        assert "optimal" in repr_str
        assert "0.025" in repr_str


class TestOptimizationResultPandas:
    """Tests for OptimizationResult pandas integration."""

    @pytest.fixture
    def sample_result(self):
        """Create a sample result."""
        return OptimizationResult(
            status=SolverStatus.OPTIMAL,
            objective_value=0.025,
            weights={"AAPL": 0.3, "GOOGL": 0.4, "MSFT": 0.3},
            portfolio_return=0.12,
            portfolio_volatility=0.15,
        )

    def test_to_dataframe(self, sample_result):
        """Test to_dataframe method."""
        pytest.importorskip("pandas")

        df = sample_result.to_dataframe()

        assert "status" in df.index or "status" in df.columns

    def test_weights_to_dataframe(self, sample_result):
        """Test weights_to_dataframe method."""
        pytest.importorskip("pandas")

        df = sample_result.weights_to_dataframe()

        assert "symbol" in df.columns
        assert "weight" in df.columns
        assert len(df) == 3

    def test_weights_to_dataframe_no_weights(self):
        """Test weights_to_dataframe raises without weights."""
        pytest.importorskip("pandas")

        result = OptimizationResult(status=SolverStatus.OPTIMAL)

        with pytest.raises(ValueError, match="No weights"):
            result.weights_to_dataframe()


class TestPortfolioResult:
    """Tests for PortfolioResult subclass."""

    def test_portfolio_result_fields(self):
        result = PortfolioResult(
            status=SolverStatus.OPTIMAL,
            objective_value=0.025,
            weights={"AAPL": 0.5, "MSFT": 0.5},
            portfolio_return=0.10,
            portfolio_volatility=0.15,
            sharpe_ratio=0.67,
            risk_contributions={"AAPL": 0.012, "MSFT": 0.013},
        )
        assert result.is_optimal
        assert result.weights["AAPL"] == 0.5
        assert result.risk_contributions["AAPL"] == 0.012

    def test_portfolio_result_from_solution_dict(self):
        d = {
            "status": "optimal",
            "weights": {"A": 0.6, "B": 0.4},
            "portfolio_return": 0.12,
            "portfolio_volatility": 0.18,
            "sharpe_ratio": 0.67,
            "risk_contributions": {"A": 0.01, "B": 0.008},
        }
        result = PortfolioResult.from_solution_dict(d)
        assert isinstance(result, PortfolioResult)
        assert result.weights["A"] == 0.6
        assert result.risk_contributions is not None

    def test_portfolio_result_repr(self):
        result = PortfolioResult(
            status=SolverStatus.OPTIMAL,
            objective_value=0.025,
            portfolio_volatility=0.15,
            sharpe_ratio=0.67,
            weights={"A": 0.5, "B": 0.5},
        )
        r = repr(result)
        assert "PortfolioResult" in r
        assert "vol=" in r
        assert "sharpe=" in r

    def test_is_subclass_of_optimization_result(self):
        result = PortfolioResult(status=SolverStatus.OPTIMAL)
        assert isinstance(result, OptimizationResult)


class TestExecutionResult:
    """Tests for ExecutionResult subclass."""

    def test_execution_result_fields(self):
        result = ExecutionResult(
            status=SolverStatus.OPTIMAL,
            schedule=[
                {"time": "09:30", "quantity": 1000},
                {"time": "09:35", "quantity": 1500},
            ],
            expected_cost_bps=2.5,
        )
        assert result.is_optimal
        assert len(result.schedule) == 2
        assert result.expected_cost_bps == 2.5

    def test_execution_result_repr(self):
        result = ExecutionResult(
            status=SolverStatus.OPTIMAL,
            expected_cost_bps=3.0,
            schedule=[{"t": 1}],
        )
        r = repr(result)
        assert "ExecutionResult" in r
        assert "cost=" in r


class TestRebalanceResult:
    """Tests for RebalanceResult subclass."""

    def test_rebalance_result_fields(self):
        result = RebalanceResult(
            status=SolverStatus.OPTIMAL,
            trades={"AAPL": {"from": 0.3, "to": 0.5, "delta": 0.2}},
            total_turnover=0.10,
            total_cost_bps=1.5,
        )
        assert result.trades["AAPL"]["delta"] == 0.2
        assert result.total_turnover == 0.10


class TestSignalSizingResult:
    """Tests for SignalSizingResult subclass."""

    def test_signal_sizing_result_fields(self):
        result = SignalSizingResult(
            status=SolverStatus.OPTIMAL,
            positions={"AAPL": 0.3, "MSFT": -0.2},
            gross_exposure=0.5,
            net_exposure=0.1,
        )
        assert result.positions["AAPL"] == 0.3
        assert result.gross_exposure == 0.5


class TestRiskBudgetResult:
    """Tests for RiskBudgetResult subclass."""

    def test_risk_budget_result_fields(self):
        result = RiskBudgetResult(
            status=SolverStatus.OPTIMAL,
            adjusted_weights={"AAPL": 0.35, "MSFT": 0.65},
            all_limits_satisfied=True,
            violations=[],
        )
        assert result.all_limits_satisfied is True
        assert result.adjusted_weights["AAPL"] == 0.35

    def test_risk_budget_result_repr(self):
        result = RiskBudgetResult(
            status=SolverStatus.OPTIMAL,
            all_limits_satisfied=False,
            portfolio_volatility=0.22,
        )
        r = repr(result)
        assert "RiskBudgetResult" in r
        assert "limits_ok=False" in r
