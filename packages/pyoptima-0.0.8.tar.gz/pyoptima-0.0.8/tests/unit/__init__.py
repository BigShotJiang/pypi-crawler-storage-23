"""Unit tests for PyOptima."""
