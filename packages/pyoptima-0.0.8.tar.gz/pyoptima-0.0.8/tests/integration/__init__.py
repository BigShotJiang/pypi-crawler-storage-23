"""Integration tests for PyOptima."""
