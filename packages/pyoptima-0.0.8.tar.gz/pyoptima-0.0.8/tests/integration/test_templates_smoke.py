"""Smoke tests for non-portfolio templates (knapsack, lp)."""

from pyoptima import solve
from pyoptima.core.result import OptimizationResult


def test_solve_knapsack_returns_optimization_result():
    """solve('knapsack', data) returns OptimizationResult."""
    data = {
        "items": [
            {"name": "a", "value": 60, "weight": 10},
            {"name": "b", "value": 100, "weight": 20},
            {"name": "c", "value": 120, "weight": 30},
        ],
        "capacity": 50,
    }
    result = solve("knapsack", data, solver="highs")
    assert isinstance(result, OptimizationResult)
    assert result.status.value in ("optimal", "feasible")
    d = result.to_dict()
    assert "status" in d
    assert (
        result.objective_value is not None
        or "objective_value" in d
        or "selected_items" in d
        or "solution" in d
    )


def test_solve_lp_returns_optimization_result():
    """solve('lp', data) returns OptimizationResult."""
    data = {
        "c": [1.0, 1.0],
        "A": [[1.0, 1.0]],
        "b": [1.0],
        "sense": "maximize",
    }
    result = solve("lp", data, solver="highs")
    assert isinstance(result, OptimizationResult)
    assert result.status.value in ("optimal", "feasible")
    assert result.objective_value is not None
    d = result.to_dict()
    assert "status" in d
    assert "solution" in d or "objective_value" in d
