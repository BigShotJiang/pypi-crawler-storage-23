"""Integration tests for CLI solve command."""

import json
import subprocess
import tempfile
from pathlib import Path


def test_cli_solve_exit_zero_and_output_has_status():
    """pyoptima solve <config> exits 0 and output contains expected keys."""
    config = {
        "template": "knapsack",
        "data": {
            "items": [{"name": "a", "value": 5, "weight": 1}],
            "capacity": 2,
        },
        "solver": {"name": "highs"},
    }
    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
        json.dump(config, f)
        path = f.name
    try:
        result = subprocess.run(
            ["pyoptima", "solve", path],
            capture_output=True,
            text=True,
            timeout=30,
        )
        assert result.returncode in (0, 1)
        out = result.stdout or result.stderr or ""
        data = json.loads(out)
        assert "status" in data
        assert data["status"] in ("optimal", "feasible", "unknown")
        if result.returncode == 0:
            assert "objective_value" in data or "weights" in data or "solution" in data
    finally:
        Path(path).unlink(missing_ok=True)
