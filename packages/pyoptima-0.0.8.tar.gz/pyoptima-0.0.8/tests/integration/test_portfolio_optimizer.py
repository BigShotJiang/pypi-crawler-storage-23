"""
Integration tests for PortfolioOptimizer.
"""

import pytest

from pyoptima.constraints import SumToOne, WeightBounds
from pyoptima.core.result import SolverStatus
from pyoptima.estimators.portfolio import PortfolioOptimizer

# Skip if pyomo/ipopt not available
pytest.importorskip("pyomo")


@pytest.fixture
def sample_data():
    """Sample portfolio data for testing."""
    np = pytest.importorskip("numpy")

    # 5 assets with realistic data
    expected_returns = np.array([0.10, 0.12, 0.08, 0.15, 0.11])

    # Generate positive definite covariance matrix
    np.random.seed(42)
    A = np.random.randn(5, 5)
    covariance_matrix = A @ A.T * 0.01 + np.eye(5) * 0.01

    return {
        "expected_returns": expected_returns,
        "covariance_matrix": covariance_matrix,
        "symbols": ["AAPL", "GOOGL", "MSFT", "AMZN", "META"],
    }


@pytest.fixture
def sample_data_with_returns():
    """Sample data with historical returns."""
    np = pytest.importorskip("numpy")

    np.random.seed(42)
    n_assets = 5
    n_periods = 100

    # Generate correlated returns
    expected_returns = np.array([0.10, 0.12, 0.08, 0.15, 0.11])
    A = np.random.randn(n_assets, n_assets)
    covariance_matrix = A @ A.T * 0.01 + np.eye(n_assets) * 0.01

    # Generate historical returns
    mean = expected_returns / 252
    cov = covariance_matrix / 252
    L = np.linalg.cholesky(cov)
    returns = np.random.randn(n_periods, n_assets) @ L.T + mean

    return {
        "expected_returns": expected_returns,
        "covariance_matrix": covariance_matrix,
        "returns": returns,
        "symbols": ["AAPL", "GOOGL", "MSFT", "AMZN", "META"],
    }


class TestPortfolioOptimizerBasic:
    """Basic tests for PortfolioOptimizer."""

    def test_creation(self):
        """Test optimizer creation."""
        opt = PortfolioOptimizer(objective="min_volatility")
        assert opt.objective == "min_volatility"

    def test_invalid_objective(self):
        """Test invalid objective raises."""
        with pytest.raises(ValueError, match="Unknown objective"):
            PortfolioOptimizer(objective="invalid_objective")

    def test_list_objectives(self):
        """Test list_objectives returns all objectives."""
        objectives = PortfolioOptimizer.list_objectives()
        assert "min_volatility" in objectives
        assert "max_sharpe" in objectives
        assert len(objectives) > 20


class TestPortfolioOptimizerSklearn:
    """Tests for sklearn-style API."""

    def test_get_params(self):
        """Test get_params."""
        opt = PortfolioOptimizer(
            objective="min_volatility",
            min_weight=0.0,
            max_weight=0.4,
        )

        params = opt.get_params()

        assert params["objective"] == "min_volatility"
        assert params["min_weight"] == 0.0
        assert params["max_weight"] == 0.4

    def test_set_params(self):
        """Test set_params."""
        opt = PortfolioOptimizer()
        opt.set_params(objective="max_sharpe", max_weight=0.3)

        assert opt.objective == "max_sharpe"
        assert opt.max_weight == 0.3

    def test_add_constraint(self):
        """Test add_constraint method chaining."""
        opt = (
            PortfolioOptimizer(objective="min_volatility")
            .add_constraint(WeightBounds(0, 0.4))
            .add_constraint(SumToOne())
        )

        assert len(opt.constraints) == 2


class TestPortfolioOptimizerSolve:
    """Tests for solve method."""

    @pytest.mark.slow
    def test_min_volatility(self, sample_data):
        """Test min_volatility optimization."""
        opt = PortfolioOptimizer(objective="min_volatility")
        result = opt.solve(**sample_data)

        if result.is_feasible:
            assert result.weights is not None
            assert len(result.weights) == 5

            # Weights should sum to 1
            np = pytest.importorskip("numpy")
            weight_sum = sum(result.weights.values())
            assert np.isclose(weight_sum, 1.0, atol=1e-4)

    @pytest.mark.slow
    def test_max_sharpe(self, sample_data):
        """Test max_sharpe optimization."""
        opt = PortfolioOptimizer(
            objective="max_sharpe",
            risk_free_rate=0.02,
        )
        result = opt.solve(**sample_data)

        if result.is_feasible:
            assert result.sharpe_ratio is not None

    @pytest.mark.slow
    def test_efficient_return(self, sample_data):
        """Test efficient_return optimization."""
        opt = PortfolioOptimizer(
            objective="efficient_return",
            target_return=0.10,
        )
        result = opt.solve(**sample_data)

        if result.is_feasible:
            assert result.portfolio_return is not None
            # Return should be at least target
            assert result.portfolio_return >= 0.10 - 0.001

    @pytest.mark.slow
    def test_with_weight_bounds(self, sample_data):
        """Test with explicit weight bounds."""
        opt = PortfolioOptimizer(
            objective="min_volatility",
            min_weight=0.05,
            max_weight=0.4,
        )
        result = opt.solve(**sample_data)

        if result.is_feasible:
            for weight in result.weights.values():
                # Weights should be within bounds (with tolerance)
                assert weight >= 0.05 - 0.001 or weight < 0.001
                assert weight <= 0.4 + 0.001

    @pytest.mark.slow
    def test_with_constraints(self, sample_data):
        """Test with constraint objects."""
        opt = PortfolioOptimizer(
            objective="min_volatility",
            constraints=[WeightBounds(0.05, 0.35)],
        )
        result = opt.solve(**sample_data)

        assert result.status in [
            SolverStatus.OPTIMAL,
            SolverStatus.FEASIBLE,
            SolverStatus.INFEASIBLE,
        ]


class TestPortfolioOptimizerCVaR:
    """Tests for CVaR objectives."""

    @pytest.mark.slow
    def test_min_cvar(self, sample_data_with_returns):
        """Test min_cvar optimization."""
        opt = PortfolioOptimizer(
            objective="min_cvar",
            confidence_level=0.05,
        )
        result = opt.solve(**sample_data_with_returns)

        # CVaR methods may fail without proper solver setup
        # Just check it doesn't crash
        assert result.status in list(SolverStatus)


class TestPortfolioOptimizerResult:
    """Tests for result object."""

    @pytest.mark.slow
    def test_result_attributes(self, sample_data):
        """Test result has expected attributes."""
        opt = PortfolioOptimizer(objective="min_volatility")
        result = opt.solve(**sample_data)

        # Basic attributes should always be present
        assert hasattr(result, "status")
        assert hasattr(result, "objective_value")
        assert hasattr(result, "weights")

    @pytest.mark.slow
    def test_result_to_dict(self, sample_data):
        """Test result to_dict method."""
        opt = PortfolioOptimizer(objective="min_volatility")
        result = opt.solve(**sample_data)

        d = result.to_dict()
        assert "status" in d
        assert "objective_value" in d

    @pytest.mark.slow
    def test_result_to_dataframe(self, sample_data):
        """Test result weights_to_dataframe."""
        pd = pytest.importorskip("pandas")

        opt = PortfolioOptimizer(objective="min_volatility")
        result = opt.solve(**sample_data)

        if result.is_feasible and result.weights:
            df = result.weights_to_dataframe()
            assert "symbol" in df.columns
            assert "weight" in df.columns
