"""Integration tests for API optimize endpoints.

Paths use API_PREFIX /api/v1 (same as PyCharter/PyStator). All v1 routes are
mounted under create_application() with prefix="/api/v1".
"""

import pytest

try:
    from fastapi.testclient import TestClient

    from pyoptima.api.main import create_application

    _HAS_API = True
except ImportError:
    _HAS_API = False


@pytest.fixture
def client():
    if not _HAS_API:
        pytest.skip("pyoptima[api] required for API tests")
    return TestClient(create_application())


@pytest.mark.skipif(not _HAS_API, reason="pyoptima[api] required")
def test_post_optimize_success(client):
    """POST /api/v1/optimize with valid knapsack data returns 200 and result shape."""
    payload = {
        "template": "knapsack",
        "data": {
            "items": [{"name": "x", "value": 10, "weight": 1}],
            "capacity": 5,
        },
    }
    resp = client.post("/api/v1/optimize", json=payload)
    assert resp.status_code == 200
    body = resp.json()
    assert "job_id" in body
    assert "status" in body
    assert "result" in body
    assert body["status"] in ("optimal", "feasible")
    assert "objective_value" in body["result"] or "status" in body["result"]


@pytest.mark.skipif(not _HAS_API, reason="pyoptima[api] required")
def test_post_optimize_invalid_data_returns_400(client):
    """POST /api/v1/optimize with invalid data returns 400 and error code."""
    payload = {
        "template": "knapsack",
        "data": {"capacity": 50},  # missing required "items"
    }
    resp = client.post("/api/v1/optimize", json=payload)
    assert resp.status_code == 400
    body = resp.json()
    assert "detail" in body
    detail = body["detail"]
    if isinstance(detail, dict):
        assert detail.get("code") == "VALIDATION_ERROR" or "error" in detail
    else:
        assert "detail" in body
