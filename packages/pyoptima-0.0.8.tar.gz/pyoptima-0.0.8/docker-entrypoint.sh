#!/bin/bash
set -euo pipefail

# ---------------------------------------------------------------------------
# PyOptima Docker Entrypoint
#
# Dispatches to the correct CLI command based on SERVICE env var or first arg.
# Optionally runs DB migrations before starting the service.
# Uses exec for proper PID 1 signal forwarding (graceful shutdown).
# ---------------------------------------------------------------------------

# --- Run DB migrations if requested ----------------------------------------
if [ "${RUN_MIGRATIONS:-false}" = "true" ]; then
    echo "[entrypoint] Running database migrations..."
    pyoptima db upgrade || echo "[entrypoint] WARNING: Migration failed (may already be current)"
fi

# --- Dispatch based on first argument or SERVICE env var -------------------
SERVICE_CMD="${1:-${SERVICE:-api}}"

case "$SERVICE_CMD" in
    api)
        echo "[entrypoint] Starting PyOptima API server..."
        exec pyoptima api \
            --host "${API_HOST:-0.0.0.0}" \
            --port "${API_PORT:-8003}" \
            --no-reload
        ;;
    worker)
        echo "[entrypoint] Starting PyOptima worker..."
        exec pyoptima worker \
            --concurrency "${WORKER_CONCURRENCY:-5}" \
            --poll-interval "${WORKER_POLL_INTERVAL:-500}"
        ;;
    ui)
        echo "[entrypoint] Starting PyOptima UI server..."
        exec pyoptima ui serve \
            --host "${UI_HOST:-0.0.0.0}" \
            --port "${UI_PORT:-3003}"
        ;;
    *)
        # Pass through any other command (e.g., bash, sh, pyoptima db upgrade)
        exec "$@"
        ;;
esac
