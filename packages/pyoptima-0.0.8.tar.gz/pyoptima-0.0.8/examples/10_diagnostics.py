"""
Diagnostics: understand solver results and debug infeasibility.

Shows how to use diagnose() for any result, sensitivity_report()
for optimal solutions, and find_iis() for infeasible models.
"""

from pyoptima import PortfolioOptimizer, diagnose
from pyoptima.diagnostics import sensitivity_report
from pyoptima.model.core import AbstractModel, Expression

# ---- 1. Diagnose an optimal result ---------------------------------------

print("=== Diagnose optimal result ===")
opt = PortfolioOptimizer(objective="min_volatility")
result = opt.solve(
    expected_returns=[0.10, 0.12, 0.08],
    covariance_matrix=[
        [0.04, 0.01, 0.02],
        [0.01, 0.05, 0.015],
        [0.02, 0.015, 0.025],
    ],
    symbols=["AAPL", "GOOGL", "MSFT"],
)
print(diagnose(result))

# ---- 2. Sensitivity report -----------------------------------------------

print("\n=== Sensitivity report ===")
# Build a small model to analyze
model = AbstractModel("sensitivity_demo")
model.add_continuous("x", lb=0.0, ub=1.0)
model.add_continuous("y", lb=0.0, ub=1.0)

obj = Expression()
obj.add_term(1.0, "x")
obj.add_term(2.0, "y")
model.minimize(obj)

lhs = Expression()
lhs.add_term(1.0, "x")
lhs.add_term(1.0, "y")
model.add_eq_constraint("budget", lhs, 1.0)

from pyoptima.core.result import OptimizationResult, SolverStatus

mock_result = OptimizationResult(
    status=SolverStatus.OPTIMAL,
    objective_value=1.0,
    solution={"x": 1.0, "y": 0.0},
)
report = sensitivity_report(model, mock_result)
print(report.summary())

# ---- 3. Model export (LP format) -----------------------------------------

print("\n=== LP export ===")
lp = model.to_lp()
print(lp)

# ---- 4. Model summary ----------------------------------------------------

print("\n=== Model summary ===")
print(model.summary())
