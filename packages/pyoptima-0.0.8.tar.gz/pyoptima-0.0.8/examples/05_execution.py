"""
Execution optimization: split a large order into time buckets.

Three strategies: TWAP (equal splits), VWAP (follow volume curve),
Implementation Shortfall (minimize market impact + timing risk).
"""

from pyoptima import ExecutionOptimizer

# Common inputs
data = dict(
    symbol="AAPL",
    total_quantity=50_000,
    side="buy",
    adv=75_000_000,
    price=175.50,
    volatility=0.02,
    horizon_minutes=120,
    interval_minutes=5,
    max_participation=0.10,
)

# 1. TWAP: equal slices
opt_twap = ExecutionOptimizer(strategy="twap")
r_twap = opt_twap.solve(**data)
print("TWAP:", r_twap.status.value, "cost=", r_twap.expected_cost_bps, "bps")

# 2. VWAP: follow historical volume profile
volume_profile = [
    0.08, 0.06, 0.05, 0.04, 0.04, 0.04, 0.05, 0.06,
    0.07, 0.08, 0.09, 0.10, 0.08, 0.06, 0.05, 0.04,
    0.04, 0.04, 0.05, 0.06, 0.07, 0.08, 0.09, 0.13,
]
opt_vwap = ExecutionOptimizer(strategy="vwap")
r_vwap = opt_vwap.solve(**data, volume_profile=volume_profile)
print("VWAP:", r_vwap.status.value, "cost=", r_vwap.expected_cost_bps, "bps")

# 3. Implementation Shortfall: balance urgency vs impact
opt_is = ExecutionOptimizer(strategy="implementation_shortfall")
r_is = opt_is.solve(**data, risk_aversion=1e-6, temporary_impact=0.1, permanent_impact=0.1)
print("IS:", r_is.status.value, "cost=", r_is.expected_cost_bps, "bps")

# Inspect the schedule
if r_twap.schedule:
    print(f"\nTWAP schedule ({len(r_twap.schedule)} buckets):")
    for bucket in r_twap.schedule[:5]:
        print(f"  {bucket}")
