# PyOptima Examples

Comprehensive examples covering all optimization templates and features.

## Python Examples

| File | Description |
|------|-------------|
| **01_quickstart.py** | Minimal portfolio optimization: `PortfolioOptimizer` + `solve()` |
| **02_from_config.py** | Load a YAML config with `PortfolioOptimizer.from_config(path)` |
| **03_objectives.py** | Portfolio objectives: min_volatility, max_sharpe, efficient_return, max_utility |
| **04_constraints.py** | Constraints: WeightBounds, SumToOne, SectorCaps, ExclusionList, InclusionList |
| **05_execution.py** | Order execution: TWAP, VWAP, Implementation Shortfall |
| **06_rebalance.py** | Portfolio rebalancing: min_deviation, min_cost strategies |
| **07_signal_sizing.py** | Alpha signal sizing: convert signals to risk-controlled positions |
| **08_risk_budget.py** | Risk budget: check/adjust portfolio against risk limits |
| **09_config_driven.py** | Config utilities: run, load, validate, generate, diff, schema |
| **10_diagnostics.py** | Diagnostics: diagnose results, sensitivity report, LP export |
| **11_warm_start.py** | Warm start: reuse previous solution for faster re-optimization |
| **12_custom_constraint.py** | Write a custom constraint class with BaseConstraint |

## Config Files

| File | Template | Description |
|------|----------|-------------|
| **portfolio_min_vol.yaml** | portfolio | Minimum volatility with weight bounds |
| **portfolio_max_sharpe.yaml** | portfolio | Maximum Sharpe ratio with risk-free rate |
| **portfolio_black_litterman.yaml** | portfolio | Black-Litterman with investor views |
| **execution_vwap.yaml** | execution | VWAP order execution with volume profile |
| **rebalance_min_cost.yaml** | rebalance | Cost-minimizing portfolio rebalance |
| **signal_sizing_mean_risk.yaml** | signal_sizing | Mean-risk signal sizing with exposure limits |
| **risk_budget_reduce.yaml** | risk_budget | Risk reduction with volatility/concentration limits |
| **multi_account_joint.yaml** | multi_account | Joint optimization across aggressive/conservative accounts |

## Two-Tier API

### Tier 1: Config-driven (primary)

```python
import pyoptima

result = pyoptima.run("configs/portfolio_min_vol.yaml")
print(result.weights)
```

### Tier 2: Python API (wraps config)

```python
from pyoptima import PortfolioOptimizer

opt = PortfolioOptimizer(objective="min_volatility")
result = opt.solve(
    expected_returns=[0.10, 0.12, 0.08],
    covariance_matrix=cov,
    symbols=["AAPL", "GOOGL", "MSFT"],
)
```

## Run

```bash
# From repo root
python examples/01_quickstart.py
python examples/09_config_driven.py

# Config-driven (CLI)
pyoptima solve examples/configs/portfolio_min_vol.yaml
```
