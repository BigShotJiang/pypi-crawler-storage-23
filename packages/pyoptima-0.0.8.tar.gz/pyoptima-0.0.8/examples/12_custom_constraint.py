"""
Custom constraint: write your own constraint class.

All constraints extend BaseConstraint and implement apply(model, data).
The apply method adds mathematical constraints to the AbstractModel.
"""

from pyoptima import PortfolioOptimizer
from pyoptima.constraints.base import BaseConstraint
from pyoptima.model.core import AbstractModel, Expression


class MinDiversification(BaseConstraint):
    """Constraint: ensure no asset is more than `max_ratio` of the largest position.

    Ensures the portfolio is diversified by limiting how much any single
    position can dominate relative to others.

    Example:
        If max_ratio=3.0, then no asset can have more than 3x the weight
        of the smallest non-zero position.
    """

    name = "min_diversification"

    def __init__(self, max_ratio: float = 3.0, min_position: float = 0.05):
        self.max_ratio = max_ratio
        self.min_position = min_position

    def apply(self, model: AbstractModel, data: dict) -> None:
        """Add diversification constraints to the model.

        For each pair of assets (i, j), add: w_i <= max_ratio * w_j
        (only if both are allowed to have non-zero positions).
        """
        symbols = data.get("symbols", [])
        n = len(symbols)

        for i in range(n):
            for j in range(n):
                if i == j:
                    continue
                # w_i <= max_ratio * w_j
                expr = Expression()
                expr.add_term(1.0, f"w_{i}")
                expr.add_term(-self.max_ratio, f"w_{j}")
                model.add_leq_constraint(
                    f"diversify_{i}_{j}", expr, 0.0
                )


# Use the custom constraint
opt = PortfolioOptimizer(
    objective="min_volatility",
    constraints=[MinDiversification(max_ratio=2.0)],
)

result = opt.solve(
    expected_returns=[0.10, 0.12, 0.08],
    covariance_matrix=[
        [0.04, 0.01, 0.02],
        [0.01, 0.05, 0.015],
        [0.02, 0.015, 0.025],
    ],
    symbols=["AAPL", "GOOGL", "MSFT"],
)

print(f"Status: {result.status.value}")
print(f"Weights: {result.weights}")
print(f"Max/min ratio: {max(result.weights.values()) / max(min(result.weights.values()), 1e-10):.2f}")
