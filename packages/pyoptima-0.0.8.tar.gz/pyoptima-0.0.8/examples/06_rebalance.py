"""
Portfolio rebalancing: move from current to target weights.

Two strategies: min_deviation (least trades) and min_cost (cheapest path).
"""

from pyoptima import RebalanceOptimizer

symbols = ["AAPL", "GOOGL", "MSFT", "AMZN"]

data = dict(
    symbols=symbols,
    current_weights={"AAPL": 0.30, "GOOGL": 0.25, "MSFT": 0.20, "AMZN": 0.25},
    target_weights={"AAPL": 0.25, "GOOGL": 0.30, "MSFT": 0.25, "AMZN": 0.20},
    transaction_costs=0.001,
    max_turnover=0.15,
)

# 1. Minimum deviation: get as close to target as possible
opt_dev = RebalanceOptimizer(strategy="min_deviation")
r_dev = opt_dev.solve(**data)
print("min_deviation:", r_dev.status.value)
if r_dev.trades:
    for sym, trade in r_dev.trades.items():
        print(f"  {sym}: {trade}")
if r_dev.total_turnover is not None:
    print(f"  Total turnover: {r_dev.total_turnover:.4f}")

# 2. Minimum cost: minimize transaction costs
opt_cost = RebalanceOptimizer(strategy="min_cost")
r_cost = opt_cost.solve(**data)
print("\nmin_cost:", r_cost.status.value)
if r_cost.total_cost_bps is not None:
    print(f"  Total cost: {r_cost.total_cost_bps:.2f} bps")
