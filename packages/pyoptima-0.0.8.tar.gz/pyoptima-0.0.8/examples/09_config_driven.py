"""
Config-driven optimization: the primary PyOptima interface.

Load a YAML config, validate, solve, and inspect results. Also
demonstrates config validation, generation, and diff utilities.
"""

from pathlib import Path

import pyoptima

examples_dir = Path(__file__).resolve().parent

# ---- 1. Solve from config ------------------------------------------------

print("=== Solve from config ===")
result = pyoptima.run(examples_dir / "configs" / "portfolio_min_vol.yaml")
print(f"Status: {result.status.value}")
print(f"Weights: {result.weights}")

# ---- 2. Load and inspect config ------------------------------------------

print("\n=== Load and inspect ===")
config = pyoptima.load(examples_dir / "configs" / "portfolio_max_sharpe.yaml")
print(f"Template: {config.template}")
print(f"Objective: {config.objective.name}")
print(f"Risk-free rate: {config.objective.risk_free_rate}")
print(f"Solver: {config.solver.name}")

# ---- 3. Validate a config ------------------------------------------------

print("\n=== Validate ===")
errors = pyoptima.validate_config(examples_dir / "configs" / "portfolio_min_vol.yaml")
if errors:
    print("Validation errors:", errors)
else:
    print("Config is valid!")

# ---- 4. Generate an example config ---------------------------------------

print("\n=== Generate example ===")
example = pyoptima.generate_config("execution", format="json")
print(example[:200], "...")

# ---- 5. Diff two configs -------------------------------------------------

print("\n=== Diff configs ===")
diffs = pyoptima.diff_config(
    examples_dir / "configs" / "portfolio_min_vol.yaml",
    examples_dir / "configs" / "portfolio_max_sharpe.yaml",
)
for d in diffs:
    print(f"  {d}")

# ---- 6. JSON Schema export -----------------------------------------------

print("\n=== JSON Schema (first 5 keys) ===")
json_schema = pyoptima.schema("portfolio")
for key in list(json_schema.keys())[:5]:
    print(f"  {key}: {json_schema[key]}")
