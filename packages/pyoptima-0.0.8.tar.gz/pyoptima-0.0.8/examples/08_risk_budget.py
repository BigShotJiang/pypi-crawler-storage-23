"""
Risk budget: check and adjust portfolio against risk limits.

Given current weights and a risk model, verify that risk limits
(volatility, concentration, CVaR) are satisfied. If violated,
adjust weights minimally to comply.
"""

from pyoptima import RiskBudgetOptimizer

symbols = ["AAPL", "GOOGL", "MSFT", "AMZN", "TSLA"]

data = dict(
    symbols=symbols,
    current_weights={
        "AAPL": 0.25, "GOOGL": 0.20, "MSFT": 0.20, "AMZN": 0.20, "TSLA": 0.15,
    },
    covariance_matrix=[
        [0.0400, 0.0120, 0.0100, 0.0150, 0.0200],
        [0.0120, 0.0350, 0.0080, 0.0110, 0.0160],
        [0.0100, 0.0080, 0.0250, 0.0090, 0.0120],
        [0.0150, 0.0110, 0.0090, 0.0500, 0.0250],
        [0.0200, 0.0160, 0.0120, 0.0250, 0.0600],
    ],
    max_volatility=0.18,
    max_concentration=0.30,
)

opt = RiskBudgetOptimizer(strategy="reduce")
result = opt.solve(**data)

print(f"Status: {result.status.value}")
if result.all_limits_satisfied is not None:
    print(f"All limits satisfied: {result.all_limits_satisfied}")
if result.violations:
    print("Violations:")
    for v in result.violations:
        print(f"  - {v}")
if result.adjusted_weights:
    print("Adjusted weights:")
    for sym, w in result.adjusted_weights.items():
        print(f"  {sym}: {w:.4f}")
if result.portfolio_volatility is not None:
    print(f"Portfolio volatility: {result.portfolio_volatility:.4f}")
