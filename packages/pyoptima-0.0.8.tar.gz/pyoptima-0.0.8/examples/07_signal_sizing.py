"""
Signal sizing: convert alpha signals to position weights.

Takes raw signal values (positive = bullish, negative = bearish),
risk model (covariance), and exposure constraints. Outputs signed
position weights with controlled risk.
"""

from pyoptima import SignalSizingOptimizer

symbols = ["AAPL", "GOOGL", "MSFT", "AMZN", "TSLA"]

data = dict(
    symbols=symbols,
    signals={"AAPL": 0.8, "GOOGL": -0.3, "MSFT": 0.5, "AMZN": 0.2, "TSLA": -0.6},
    covariance_matrix=[
        [0.0400, 0.0120, 0.0100, 0.0150, 0.0200],
        [0.0120, 0.0350, 0.0080, 0.0110, 0.0160],
        [0.0100, 0.0080, 0.0250, 0.0090, 0.0120],
        [0.0150, 0.0110, 0.0090, 0.0500, 0.0250],
        [0.0200, 0.0160, 0.0120, 0.0250, 0.0600],
    ],
)

opt = SignalSizingOptimizer(
    strategy="mean_risk",
    risk_aversion=1.0,
    max_position=0.30,
    max_gross_exposure=1.5,
    max_net_exposure=0.20,
)
result = opt.solve(**data)

print(f"Status: {result.status.value}")
if result.positions:
    print("Positions:")
    for sym, w in result.positions.items():
        direction = "LONG" if w > 0 else "SHORT" if w < 0 else "FLAT"
        print(f"  {sym}: {w:+.4f} ({direction})")
if result.gross_exposure is not None:
    print(f"Gross exposure: {result.gross_exposure:.4f}")
if result.net_exposure is not None:
    print(f"Net exposure:   {result.net_exposure:.4f}")
