"""
Warm start: reuse a previous solution to speed up re-optimization.

Common use case: solve a portfolio, then re-solve with tighter constraints.
The warm start provides a good initial point for the solver.
"""

from pyoptima import PortfolioOptimizer
from pyoptima.model.core import AbstractModel

# ---- Step 1: Solve initial problem ----------------------------------------

opt = PortfolioOptimizer(objective="min_volatility")
result1 = opt.solve(
    expected_returns=[0.10, 0.12, 0.08, 0.09, 0.11],
    covariance_matrix=[
        [0.04, 0.01, 0.02, 0.01, 0.015],
        [0.01, 0.05, 0.015, 0.01, 0.02],
        [0.02, 0.015, 0.025, 0.02, 0.01],
        [0.01, 0.01, 0.02, 0.03, 0.015],
        [0.015, 0.02, 0.01, 0.015, 0.035],
    ],
    symbols=["A", "B", "C", "D", "E"],
)
print("Initial solve:", result1.status.value)
print("Weights:", result1.weights)

# ---- Step 2: Warm start from previous result -----------------------------

# AbstractModel supports warm start via set_initial / set_initial_from_result
model = AbstractModel("warm_start_demo")
for i in range(5):
    model.add_continuous(f"w_{i}", lb=0.0, ub=1.0)

# Set initial values from the previous solution
model.set_initial_from_result(result1)

# Verify values are set
for i in range(5):
    var = model.get_variable(f"w_{i}")
    print(f"  w_{i} initial = {var.value}")

# ---- Step 3: Re-solve with warm start ------------------------------------

# The solver will use these initial values when warm_start=True
# in SolverOptions. This is handled automatically by the solver layer.
print("\nWarm start available for next solve with SolverOptions(warm_start=True)")
