"""Risk budget optimization config.

Example YAML::

    template: risk_budget

    strategy: reduce

    data:
      current_weights: {AAPL: 0.40, GOOGL: 0.35, MSFT: 0.25}
      symbols: [AAPL, GOOGL, MSFT]
      covariance_matrix: [[0.04, 0.01, 0.02], ...]

    constraints:
      max_volatility: 0.15
      max_concentration: 0.35

    solver:
      name: ipopt
"""

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from pyoptima.configs.solver import SolverConfig

RISK_STRATEGIES = ["check", "reduce", "allocate"]


class RiskBudgetDataConfig(BaseModel):
    """Risk budget input data."""

    model_config = ConfigDict(extra="forbid")

    current_weights: dict[str, float] = Field(
        ..., description="Current portfolio weights"
    )
    symbols: list[str] = Field(..., description="Asset symbols")
    covariance_matrix: list[list[float]] = Field(..., description="Covariance matrix")
    returns: list[list[float]] | None = Field(
        None, description="Historical returns for CVaR"
    )
    factor_loadings: list[list[float]] | None = Field(
        None, description="Factor loadings (n_assets x n_factors)"
    )
    factor_names: list[str] | None = Field(None, description="Factor names")


class RiskBudgetConstraintsConfig(BaseModel):
    """Risk budget constraints — the limits to check/enforce."""

    model_config = ConfigDict(extra="forbid")

    max_volatility: float | None = Field(
        None, description="Maximum portfolio volatility"
    )
    max_cvar: float | None = Field(None, description="Maximum CVaR")
    max_concentration: float | None = Field(
        None, description="Maximum single-asset weight"
    )
    max_sector_weight: dict[str, float] | None = Field(
        None, description="Maximum weight per sector"
    )
    asset_sectors: dict[str, str] | None = Field(
        None, description="Asset to sector mapping"
    )
    max_factor_exposure: dict[str, float] | None = Field(
        None, description="Maximum factor exposure"
    )
    confidence_level: float = Field(
        default=0.05, description="Confidence level for CVaR"
    )


class RiskBudgetConfig(BaseModel):
    """Complete risk budget configuration."""

    model_config = ConfigDict(extra="forbid")

    template: Literal["risk_budget"] = "risk_budget"
    strategy: str = Field(
        default="check", description="Strategy: check, reduce, allocate"
    )
    data: RiskBudgetDataConfig = Field(..., description="Portfolio data")
    constraints: RiskBudgetConstraintsConfig = Field(
        default_factory=RiskBudgetConstraintsConfig,
        description="Risk limits to check/enforce",
    )
    solver: SolverConfig = Field(
        default_factory=SolverConfig, description="Solver configuration"
    )
    job_id: str | None = Field(None, description="Optional job identifier")

    @model_validator(mode="after")
    def _validate_strategy(self) -> "RiskBudgetConfig":
        if self.strategy not in RISK_STRATEGIES:
            raise ValueError(
                f"Unknown strategy '{self.strategy}'. "
                f"Supported: {', '.join(RISK_STRATEGIES)}"
            )
        return self
