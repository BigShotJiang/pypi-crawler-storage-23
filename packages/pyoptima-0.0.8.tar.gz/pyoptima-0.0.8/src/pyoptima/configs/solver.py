"""Solver configuration."""

from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class SolverConfig(BaseModel):
    """Solver configuration.

    Controls which solver backend is used and its runtime options.

    Example YAML::

        solver:
          name: ipopt
          time_limit: 60
          verbose: false
          options:
            max_iter: 1000
    """

    model_config = ConfigDict(extra="forbid")

    name: str = Field(
        default="highs",
        description="Solver backend: highs, ipopt, cbc, glpk, gurobi, cplex",
    )
    time_limit: float | None = Field(None, description="Maximum solve time in seconds")
    verbose: bool = Field(default=False, description="Print solver output")
    options: dict[str, Any] = Field(
        default_factory=dict, description="Solver-specific options"
    )
