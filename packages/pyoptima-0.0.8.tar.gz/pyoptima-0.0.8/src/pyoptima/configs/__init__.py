"""Structured configuration models for PyOptima.

Every optimization in PyOptima is fully expressible as a YAML/JSON config file.
These Pydantic models define the schema, validate inputs, and export JSON Schema.

Usage::

    from pyoptima.configs import load, run, schema

    # Load and validate a config file
    config = load("portfolio_config.yaml")

    # Load, validate, and solve in one step
    result = run("portfolio_config.yaml")

    # Export JSON Schema for editor autocomplete
    json_schema = schema("portfolio")

Template-specific configs::

    from pyoptima.configs import (
        PortfolioConfig,
        ExecutionConfig,
        RebalanceConfig,
        SignalSizingConfig,
        RiskBudgetConfig,
        TradingScheduleConfig,
        MultiAccountConfig,
    )
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import TYPE_CHECKING, Any

from pydantic import TypeAdapter

if TYPE_CHECKING:
    from pyoptima.core.result import OptimizationResult

# Constraint config models (for programmatic config building)
from pyoptima.configs.constraints import (
    CardinalityConfig,
    FactorExposureConfig,
    LiquidityConfig,
    SectorConfig,
    SpreadCostConfig,
    TrackingErrorConfig,
    TransactionCostConfig,
    TurnoverConfig,
    WeightBoundsConfig,
)
from pyoptima.configs.execution import ExecutionConfig
from pyoptima.configs.multi_account import MultiAccountConfig
from pyoptima.configs.portfolio import PortfolioConfig
from pyoptima.configs.rebalance import RebalanceConfig
from pyoptima.configs.risk_budget import RiskBudgetConfig
from pyoptima.configs.signal_sizing import SignalSizingConfig
from pyoptima.configs.solver import SolverConfig
from pyoptima.configs.trading_schedule import TradingScheduleConfig

# Discriminated union — template field selects the config type.
# Pydantic validates the correct sub-model based on the ``template`` value.
OptimizationConfig = (
    PortfolioConfig
    | ExecutionConfig
    | RebalanceConfig
    | SignalSizingConfig
    | RiskBudgetConfig
    | TradingScheduleConfig
    | MultiAccountConfig
)

_config_adapter = TypeAdapter(OptimizationConfig)

# Map template name -> config class for schema export
_CONFIG_REGISTRY: dict[str, type] = {
    "portfolio": PortfolioConfig,
    "execution": ExecutionConfig,
    "rebalance": RebalanceConfig,
    "signal_sizing": SignalSizingConfig,
    "risk_budget": RiskBudgetConfig,
    "trading_schedule": TradingScheduleConfig,
    "multi_account": MultiAccountConfig,
}


def load(config: str | Path | dict[str, Any]) -> OptimizationConfig:
    """Load and validate a config from a file path or dictionary.

    Supports JSON and YAML files. The ``template`` field determines which
    config model is used for validation.

    Args:
        config: Path to .json/.yaml/.yml file, or a dict.

    Returns:
        Validated config model (PortfolioConfig, ExecutionConfig, etc.).

    Raises:
        ValidationError: If the config is invalid.
        FileNotFoundError: If the file does not exist.

    Example::

        config = load("portfolio_config.yaml")
        print(config.objective.name)  # "max_sharpe"
    """
    if isinstance(config, (str, Path)):
        data = _read_file(config)
    else:
        data = config
    return _config_adapter.validate_python(data)


def run(config: str | Path | dict[str, Any]) -> OptimizationResult:
    """Load config, validate, and solve in one step.

    This is the primary entry point for config-driven optimization.

    Args:
        config: Path to config file, or a dict.

    Returns:
        OptimizationResult with solution.

    Example::

        result = run("portfolio_config.yaml")
        print(result.status, result.objective_value)
    """
    from pyoptima.core.result import OptimizationResult
    from pyoptima.templates import solve as template_solve
    from pyoptima.utils.logging import log_run

    cfg = load(config)
    template_name = cfg.template

    # Build the data dict and solver options for the template
    solver_opts = cfg.solver.options.copy()
    if cfg.solver.time_limit is not None:
        solver_opts["time_limit"] = cfg.solver.time_limit
    solver_opts["verbose"] = cfg.solver.verbose

    # Convert structured config to the flat dict that templates expect.
    # This bridge exists during migration; eventually templates will
    # accept the structured config directly.
    template_data = _config_to_template_data(cfg)

    start = time.perf_counter()
    result = template_solve(
        template_name,
        template_data,
        solver=cfg.solver.name,
        **solver_opts,
    )
    duration = time.perf_counter() - start

    job_id = getattr(cfg, "job_id", None)
    if job_id and isinstance(result, OptimizationResult):
        result.metadata["job_id"] = job_id
    log_run(job_id, template_name, result.status.value, duration)
    return result


def schema(template: str) -> dict[str, Any]:
    """Export JSON Schema for a template's config.

    Useful for editor autocomplete and config file validation.

    Args:
        template: Template name (e.g. "portfolio", "execution").

    Returns:
        JSON Schema dictionary.

    Example::

        import json
        print(json.dumps(schema("portfolio"), indent=2))
    """
    if template not in _CONFIG_REGISTRY:
        available = ", ".join(sorted(_CONFIG_REGISTRY))
        raise ValueError(f"Unknown template '{template}'. Available: {available}")
    return _CONFIG_REGISTRY[template].model_json_schema()


def list_config_templates() -> list[str]:
    """List all templates with structured config support."""
    return sorted(_CONFIG_REGISTRY.keys())


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _read_file(path: str | Path) -> dict[str, Any]:
    """Read a JSON or YAML file."""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Config file not found: {p}")

    suffix = p.suffix.lower()
    text = p.read_text()

    if suffix == ".json":
        return json.loads(text)
    elif suffix in (".yaml", ".yml"):
        try:
            import yaml
        except ImportError as e:
            raise ImportError(
                "PyYAML required for YAML configs: pip install pyyaml"
            ) from e
        return yaml.safe_load(text)
    else:
        raise ValueError(
            f"Unsupported config format: {suffix}. Use .json, .yaml, or .yml"
        )


def _config_to_template_data(cfg: OptimizationConfig) -> dict[str, Any]:
    """Convert a structured config into the flat dict that templates expect.

    This is a bridge layer. Once templates are updated to accept structured
    configs directly (Phase 7), this function can be simplified.
    """
    if isinstance(cfg, PortfolioConfig):
        return _portfolio_config_to_data(cfg)
    elif isinstance(cfg, ExecutionConfig):
        return _execution_config_to_data(cfg)
    elif isinstance(cfg, RebalanceConfig):
        return _rebalance_config_to_data(cfg)
    elif isinstance(cfg, SignalSizingConfig):
        return _signal_sizing_config_to_data(cfg)
    elif isinstance(cfg, RiskBudgetConfig):
        return _risk_budget_config_to_data(cfg)
    elif isinstance(cfg, TradingScheduleConfig):
        return _trading_schedule_config_to_data(cfg)
    elif isinstance(cfg, MultiAccountConfig):
        return _multi_account_config_to_data(cfg)
    else:
        raise ValueError(f"Unknown config type: {type(cfg)}")


def _portfolio_config_to_data(cfg: PortfolioConfig) -> dict[str, Any]:
    """Flatten PortfolioConfig into the dict PortfolioTemplate expects."""
    obj = cfg.objective
    data: dict[str, Any] = {
        "objective": obj.name,
        "expected_returns": cfg.data.expected_returns,
        "covariance_matrix": cfg.data.covariance_matrix,
        "risk_free_rate": obj.risk_free_rate,
        "risk_aversion": obj.risk_aversion,
        "confidence_level": obj.confidence_level,
        "benchmark": obj.benchmark,
    }
    if cfg.data.symbols:
        data["symbols"] = cfg.data.symbols
    if cfg.data.returns:
        data["returns"] = cfg.data.returns

    # Objective-specific targets
    for field in (
        "target_return",
        "target_volatility",
        "target_cvar",
        "target_cdar",
        "target_semivariance",
    ):
        val = getattr(obj, field)
        if val is not None:
            data[field] = val

    # Black-Litterman
    for field in ("market_caps", "views", "view_cov", "tau"):
        val = getattr(cfg.data, field)
        if val is not None:
            data[field] = val

    # Momentum / Factor
    for field in (
        "momentum_period",
        "momentum_top_pct",
        "factor_data",
        "factor_weights",
    ):
        val = getattr(cfg.data, field)
        if val is not None:
            data[field] = val

    # Constraints
    c = cfg.constraints
    if c.weight_bounds:
        data["min_weight"] = c.weight_bounds.min
        data["max_weight"] = c.weight_bounds.max
        if c.weight_bounds.per_asset:
            data["per_asset_bounds"] = {
                k: tuple(v) for k, v in c.weight_bounds.per_asset.items()
            }
    else:
        data["min_weight"] = 0.0
        data["max_weight"] = 1.0

    if c.cardinality:
        data["max_assets"] = c.cardinality.max_assets
        data["min_position_size"] = c.cardinality.min_position
    if c.turnover:
        data["max_turnover"] = c.turnover.max
        data["current_weights"] = c.turnover.current_weights
    if c.sectors:
        data["asset_sectors"] = c.sectors.asset_map
        if c.sectors.caps:
            data["sector_caps"] = c.sectors.caps
        if c.sectors.floors:
            data["sector_mins"] = c.sectors.floors
    if c.tracking_error:
        data["max_tracking_error"] = c.tracking_error.max
        data["benchmark_weights"] = c.tracking_error.benchmark_weights
    if c.liquidity:
        data["adv"] = c.liquidity.adv
        data["max_participation"] = c.liquidity.max_participation
    if c.transaction_costs:
        data["transaction_costs"] = c.transaction_costs.rate
        if c.transaction_costs.current_weights:
            data["current_weights"] = c.transaction_costs.current_weights
    if c.max_volatility is not None:
        data["max_volatility"] = c.max_volatility
    if c.max_concentration is not None:
        data["max_concentration"] = c.max_concentration
    if c.exclusions:
        # Build per_asset_bounds with (0, 0) for excluded
        pab = data.get("per_asset_bounds", {})
        for sym in c.exclusions:
            pab[sym] = (0.0, 0.0)
        data["per_asset_bounds"] = pab
    if c.inclusions and cfg.data.symbols:
        allowed = set(c.inclusions)
        pab = data.get("per_asset_bounds", {})
        for sym in cfg.data.symbols:
            if sym not in allowed:
                pab[sym] = (0.0, 0.0)
        data["per_asset_bounds"] = pab

    return data


def _execution_config_to_data(cfg: ExecutionConfig) -> dict[str, Any]:
    data: dict[str, Any] = {
        "strategy": cfg.strategy,
        "symbol": cfg.data.symbol,
        "total_quantity": cfg.data.total_quantity,
        "side": cfg.data.side,
        "adv": cfg.data.adv,
        "horizon_minutes": cfg.params.horizon_minutes,
        "interval_minutes": cfg.params.interval_minutes,
        "max_participation": cfg.constraints.max_participation,
        "risk_aversion": cfg.params.risk_aversion,
        "temporary_impact": cfg.params.temporary_impact,
        "permanent_impact": cfg.params.permanent_impact,
        "target_participation": cfg.params.target_participation,
    }
    if cfg.data.price is not None:
        data["price"] = cfg.data.price
    if cfg.data.volatility is not None:
        data["volatility"] = cfg.data.volatility
    if cfg.data.bid_ask_spread is not None:
        data["bid_ask_spread"] = cfg.data.bid_ask_spread
    if cfg.data.volume_profile is not None:
        data["volume_profile"] = cfg.data.volume_profile
    return data


def _rebalance_config_to_data(cfg: RebalanceConfig) -> dict[str, Any]:
    data: dict[str, Any] = {
        "strategy": cfg.strategy,
        "current_weights": cfg.data.current_weights,
        "target_weights": cfg.data.target_weights,
        "symbols": cfg.data.symbols,
    }
    if cfg.data.transaction_costs is not None:
        data["transaction_costs"] = cfg.data.transaction_costs
    if cfg.data.adv is not None:
        data["adv"] = cfg.data.adv
    if cfg.data.covariance_matrix is not None:
        data["covariance_matrix"] = cfg.data.covariance_matrix
    if cfg.data.prices is not None:
        data["prices"] = cfg.data.prices
    if cfg.data.portfolio_value is not None:
        data["portfolio_value"] = cfg.data.portfolio_value
    if cfg.constraints.max_turnover is not None:
        data["max_turnover"] = cfg.constraints.max_turnover
    if cfg.constraints.max_tracking_error is not None:
        data["max_tracking_error"] = cfg.constraints.max_tracking_error
    if cfg.constraints.max_participation is not None:
        data["max_participation"] = cfg.constraints.max_participation
    return data


def _signal_sizing_config_to_data(cfg: SignalSizingConfig) -> dict[str, Any]:
    data: dict[str, Any] = {
        "strategy": cfg.strategy,
        "signals": cfg.data.signals,
        "symbols": cfg.data.symbols,
        "risk_aversion": cfg.objective.risk_aversion,
    }
    if cfg.data.covariance_matrix is not None:
        data["covariance_matrix"] = cfg.data.covariance_matrix
    if cfg.data.prices is not None:
        data["prices"] = cfg.data.prices
    if cfg.objective.target_volatility is not None:
        data["target_volatility"] = cfg.objective.target_volatility
    if cfg.constraints.max_position is not None:
        data["max_position"] = cfg.constraints.max_position
    if cfg.constraints.max_gross_exposure is not None:
        data["max_gross_exposure"] = cfg.constraints.max_gross_exposure
    if cfg.constraints.max_net_exposure is not None:
        data["max_net_exposure"] = cfg.constraints.max_net_exposure
    if cfg.constraints.max_notional is not None:
        data["max_notional"] = cfg.constraints.max_notional
    return data


def _risk_budget_config_to_data(cfg: RiskBudgetConfig) -> dict[str, Any]:
    data: dict[str, Any] = {
        "strategy": cfg.strategy,
        "current_weights": cfg.data.current_weights,
        "symbols": cfg.data.symbols,
        "covariance_matrix": cfg.data.covariance_matrix,
    }
    if cfg.data.returns is not None:
        data["returns"] = cfg.data.returns
    if cfg.data.factor_loadings is not None:
        data["factor_loadings"] = cfg.data.factor_loadings
    if cfg.data.factor_names is not None:
        data["factor_names"] = cfg.data.factor_names
    c = cfg.constraints
    if c.max_volatility is not None:
        data["max_volatility"] = c.max_volatility
    if c.max_cvar is not None:
        data["max_cvar"] = c.max_cvar
    if c.max_concentration is not None:
        data["max_concentration"] = c.max_concentration
    if c.max_sector_weight is not None:
        data["max_sector_weight"] = c.max_sector_weight
    if c.asset_sectors is not None:
        data["asset_sectors"] = c.asset_sectors
    if c.max_factor_exposure is not None:
        data["max_factor_exposure"] = c.max_factor_exposure
    data["confidence_level"] = c.confidence_level
    return data


def _trading_schedule_config_to_data(cfg: TradingScheduleConfig) -> dict[str, Any]:
    tasks = []
    for t in cfg.data.tasks:
        task = {
            "name": t.name,
            "duration_minutes": t.duration_minutes,
            "priority": t.priority,
        }
        if t.earliest is not None:
            task["earliest"] = t.earliest
        if t.latest is not None:
            task["latest"] = t.latest
        if t.depends_on:
            task["depends_on"] = t.depends_on
        tasks.append(task)
    data: dict[str, Any] = {
        "strategy": cfg.strategy,
        "tasks": tasks,
        "session_start": cfg.data.session_start,
        "session_end": cfg.data.session_end,
        "slot_minutes": cfg.data.slot_minutes,
    }
    if cfg.data.volume_profile is not None:
        data["volume_profile"] = cfg.data.volume_profile
    if cfg.data.volatility_profile is not None:
        data["volatility_profile"] = cfg.data.volatility_profile
    return data


def _multi_account_config_to_data(cfg: MultiAccountConfig) -> dict[str, Any]:
    accounts = []
    for a in cfg.data.accounts:
        acct: dict[str, Any] = {
            "name": a.name,
            "min_weight": a.min_weight,
            "max_weight": a.max_weight,
        }
        if a.max_turnover is not None:
            acct["max_turnover"] = a.max_turnover
        if a.max_volatility is not None:
            acct["max_volatility"] = a.max_volatility
        if a.excluded_symbols:
            acct["excluded_symbols"] = a.excluded_symbols
        accounts.append(acct)
    data: dict[str, Any] = {
        "strategy": cfg.strategy,
        "objective": cfg.objective,
        "symbols": cfg.data.symbols,
        "expected_returns": cfg.data.expected_returns,
        "covariance_matrix": cfg.data.covariance_matrix,
        "accounts": accounts,
    }
    if cfg.data.account_values is not None:
        data["account_values"] = cfg.data.account_values
    if cfg.data.current_weights is not None:
        data["current_weights"] = cfg.data.current_weights
    if cfg.data.target_weights is not None:
        data["target_weights"] = cfg.data.target_weights
    return data


__all__ = [
    # Top-level functions
    "load",
    "run",
    "schema",
    "list_config_templates",
    # Union type
    "OptimizationConfig",
    # Template configs
    "PortfolioConfig",
    "ExecutionConfig",
    "RebalanceConfig",
    "SignalSizingConfig",
    "RiskBudgetConfig",
    "TradingScheduleConfig",
    "MultiAccountConfig",
    # Solver
    "SolverConfig",
    # Constraint configs
    "WeightBoundsConfig",
    "CardinalityConfig",
    "TurnoverConfig",
    "SectorConfig",
    "FactorExposureConfig",
    "TrackingErrorConfig",
    "LiquidityConfig",
    "TransactionCostConfig",
    "SpreadCostConfig",
]
