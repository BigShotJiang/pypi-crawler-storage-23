"""Portfolio optimization config.

Defines the complete, validated YAML/JSON schema for portfolio optimization.

Example YAML::

    template: portfolio

    objective:
      name: max_sharpe
      risk_free_rate: 0.02

    data:
      symbols: [AAPL, GOOGL, MSFT]
      expected_returns: [0.12, 0.10, 0.08]
      covariance_matrix: [[0.04, 0.01, 0.02], [0.01, 0.03, 0.015], [0.02, 0.015, 0.025]]

    constraints:
      weight_bounds:
        min: 0.0
        max: 0.4

    solver:
      name: ipopt
"""

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from pyoptima.configs.constraints import (
    CardinalityConfig,
    FactorExposureConfig,
    LiquidityConfig,
    SectorConfig,
    SpreadCostConfig,
    TrackingErrorConfig,
    TransactionCostConfig,
    TurnoverConfig,
    WeightBoundsConfig,
)
from pyoptima.configs.solver import SolverConfig

# All supported portfolio objectives
PORTFOLIO_OBJECTIVES = [
    # Efficient Frontier
    "min_volatility",
    "max_sharpe",
    "max_return",
    "efficient_return",
    "efficient_risk",
    "max_utility",
    # Black-Litterman
    "black_litterman_max_sharpe",
    "black_litterman_min_volatility",
    "black_litterman_quadratic_utility",
    # CVaR
    "min_cvar",
    "efficient_cvar_risk",
    "efficient_cvar_return",
    # CDaR
    "min_cdar",
    "efficient_cdar_risk",
    "efficient_cdar_return",
    # Semivariance
    "min_semivariance",
    "efficient_semivariance_risk",
    "efficient_semivariance_return",
    # CLA
    "cla_min_volatility",
    "cla_max_sharpe",
    # Hierarchical
    "hierarchical_min_volatility",
    "hierarchical_max_sharpe",
    # Maximum Diversification
    "max_diversification",
    "max_diversification_index",
    # Risk Parity
    "risk_parity",
    "equal_risk_contribution",
    # Transaction Cost-Aware
    "max_sharpe_with_costs",
    "min_volatility_with_costs",
    # Momentum-Filtered
    "momentum_filtered_max_sharpe",
    "momentum_filtered_min_volatility",
    # Factor-Based
    "factor_based_selection",
]


class PortfolioObjectiveConfig(BaseModel):
    """Portfolio objective configuration.

    Separates the optimization objective and its parameters from raw data.
    """

    model_config = ConfigDict(extra="forbid")

    name: str = Field(default="min_volatility", description="Objective function name")
    risk_free_rate: float = Field(
        default=0.0, description="Risk-free rate for Sharpe calculations"
    )
    target_return: float | None = Field(
        None, description="Target return for efficient_return"
    )
    target_volatility: float | None = Field(
        None, description="Target volatility for efficient_risk"
    )
    target_cvar: float | None = Field(
        None, description="Target CVaR for efficient_cvar_risk"
    )
    target_cdar: float | None = Field(
        None, description="Target CDaR for efficient_cdar_risk"
    )
    target_semivariance: float | None = Field(None, description="Target semivariance")
    risk_aversion: float = Field(
        default=1.0, description="Risk aversion coefficient for utility objectives"
    )
    confidence_level: float = Field(
        default=0.05, description="Confidence level for CVaR/CDaR (0.05 = 95%)"
    )
    benchmark: float = Field(
        default=0.0, description="Benchmark return for semivariance"
    )

    @model_validator(mode="after")
    def _validate_objective(self) -> "PortfolioObjectiveConfig":
        if self.name not in PORTFOLIO_OBJECTIVES:
            raise ValueError(
                f"Unknown objective '{self.name}'. "
                f"Supported: {', '.join(PORTFOLIO_OBJECTIVES)}"
            )
        if self.name in (
            "efficient_return",
            "efficient_cvar_return",
            "efficient_cdar_return",
            "efficient_semivariance_return",
        ):
            if self.target_return is None:
                raise ValueError(f"target_return required for {self.name}")
        if self.name == "efficient_risk" and self.target_volatility is None:
            raise ValueError("target_volatility required for efficient_risk")
        if self.name == "efficient_cvar_risk" and self.target_cvar is None:
            raise ValueError("target_cvar required for efficient_cvar_risk")
        if self.name == "efficient_cdar_risk" and self.target_cdar is None:
            raise ValueError("target_cdar required for efficient_cdar_risk")
        if (
            self.name == "efficient_semivariance_risk"
            and self.target_semivariance is None
        ):
            raise ValueError(
                "target_semivariance required for efficient_semivariance_risk"
            )
        return self


class PortfolioDataConfig(BaseModel):
    """Portfolio input data — pure data, no configuration knobs."""

    model_config = ConfigDict(extra="forbid")

    symbols: list[str] | None = Field(None, description="Asset ticker symbols")
    expected_returns: list[float] | dict[str, float] = Field(
        ..., description="Expected returns per asset"
    )
    covariance_matrix: list[list[float]] = Field(
        ..., description="Covariance matrix (n x n)"
    )
    returns: list[list[float]] | None = Field(
        None,
        description="Historical returns (n_periods x n_assets) for CVaR/CDaR/semivariance",
    )
    # Black-Litterman inputs
    market_caps: list[float] | None = Field(None, description="Market capitalizations")
    views: list[float] | None = Field(
        None, description="Investor views (Black-Litterman)"
    )
    view_cov: list[list[float]] | None = Field(
        None, description="View covariance (Black-Litterman)"
    )
    tau: float | None = Field(None, description="Uncertainty scaling (Black-Litterman)")
    # Momentum inputs
    momentum_period: int | None = Field(
        None, description="Lookback period for momentum"
    )
    momentum_top_pct: float | None = Field(
        None, description="Top percentile for momentum filter"
    )
    # Factor inputs
    factor_data: dict[str, Any] | None = Field(
        None, description="Factor data for factor-based selection"
    )
    factor_weights: dict[str, float] | None = Field(None, description="Factor weights")


class PortfolioConstraintsConfig(BaseModel):
    """All portfolio constraints in a single structured section."""

    model_config = ConfigDict(extra="forbid")

    weight_bounds: WeightBoundsConfig | None = Field(
        None, description="Per-asset weight limits"
    )
    cardinality: CardinalityConfig | None = Field(
        None, description="Max/min number of assets"
    )
    turnover: TurnoverConfig | None = Field(
        None, description="Turnover limit vs current portfolio"
    )
    sectors: SectorConfig | None = Field(None, description="Sector exposure limits")
    factors: FactorExposureConfig | None = Field(
        None, description="Factor exposure limits"
    )
    tracking_error: TrackingErrorConfig | None = Field(
        None, description="Tracking error vs benchmark"
    )
    liquidity: LiquidityConfig | None = Field(
        None, description="Liquidity-based weight limits"
    )
    transaction_costs: TransactionCostConfig | None = Field(
        None, description="Transaction cost parameters"
    )
    spread_cost: SpreadCostConfig | None = Field(
        None, description="Maximum spread cost"
    )
    max_volatility: float | None = Field(
        None, description="Maximum portfolio volatility"
    )
    max_cvar: float | None = Field(None, description="Maximum CVaR")
    max_drawdown: float | None = Field(None, description="Maximum drawdown")
    max_concentration: float | None = Field(
        None, description="Maximum single-asset weight (concentration)"
    )
    exclusions: list[str] | None = Field(
        None, description="Symbols to exclude (weight=0)"
    )
    inclusions: list[str] | None = Field(
        None, description="Symbols to include (all others excluded)"
    )


class PortfolioConfig(BaseModel):
    """Complete portfolio optimization configuration.

    This is the top-level config for ``template: portfolio``.
    """

    model_config = ConfigDict(extra="forbid")

    template: Literal["portfolio"] = "portfolio"
    objective: PortfolioObjectiveConfig = Field(
        default_factory=PortfolioObjectiveConfig,
        description="Objective function and its parameters",
    )
    data: PortfolioDataConfig = Field(
        ..., description="Input data (returns, covariance, symbols)"
    )
    constraints: PortfolioConstraintsConfig = Field(
        default_factory=PortfolioConstraintsConfig,
        description="Optimization constraints",
    )
    solver: SolverConfig = Field(
        default_factory=SolverConfig, description="Solver backend configuration"
    )
    job_id: str | None = Field(
        None, description="Optional job identifier for logging/tracking"
    )
