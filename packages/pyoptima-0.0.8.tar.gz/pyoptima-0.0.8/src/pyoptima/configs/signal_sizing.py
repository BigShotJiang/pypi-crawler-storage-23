"""Signal sizing optimization config.

Example YAML::

    template: signal_sizing

    strategy: mean_risk

    objective:
      risk_aversion: 2.0

    data:
      signals: {AAPL: 0.02, GOOGL: -0.01, MSFT: 0.015}
      symbols: [AAPL, GOOGL, MSFT]
      covariance_matrix: [[0.04, 0.01, 0.02], ...]

    constraints:
      max_position: 0.30
      max_gross_exposure: 1.0

    solver:
      name: ipopt
"""

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from pyoptima.configs.solver import SolverConfig

SIZING_STRATEGIES = ["mean_risk", "equal_risk", "kelly", "fixed_risk"]


class SignalSizingDataConfig(BaseModel):
    """Signal sizing input data."""

    model_config = ConfigDict(extra="forbid")

    signals: dict[str, float] = Field(..., description="Alpha signals per asset")
    symbols: list[str] = Field(..., description="Asset symbols")
    covariance_matrix: list[list[float]] | None = Field(
        None,
        description="Covariance matrix (required for mean_risk, kelly, fixed_risk)",
    )
    prices: dict[str, float] | None = Field(
        None, description="Asset prices for notional conversion"
    )


class SignalSizingObjectiveConfig(BaseModel):
    """Signal sizing objective parameters."""

    model_config = ConfigDict(extra="forbid")

    risk_aversion: float = Field(default=1.0, description="Risk aversion for mean-risk")
    target_volatility: float | None = Field(
        None, description="Target volatility for fixed_risk"
    )


class SignalSizingConstraintsConfig(BaseModel):
    """Signal sizing constraints."""

    model_config = ConfigDict(extra="forbid")

    max_position: float | None = Field(
        None, description="Maximum absolute weight per asset"
    )
    max_gross_exposure: float | None = Field(
        None, description="Maximum sum of |weights|"
    )
    max_net_exposure: float | None = Field(None, description="Maximum |sum of weights|")
    max_notional: float | None = Field(None, description="Maximum total notional value")


class SignalSizingConfig(BaseModel):
    """Complete signal sizing configuration."""

    model_config = ConfigDict(extra="forbid")

    template: Literal["signal_sizing"] = "signal_sizing"
    strategy: str = Field(
        default="mean_risk",
        description="Strategy: mean_risk, equal_risk, kelly, fixed_risk",
    )
    objective: SignalSizingObjectiveConfig = Field(
        default_factory=SignalSizingObjectiveConfig,
        description="Objective parameters",
    )
    data: SignalSizingDataConfig = Field(..., description="Signal data")
    constraints: SignalSizingConstraintsConfig = Field(
        default_factory=SignalSizingConstraintsConfig,
        description="Position constraints",
    )
    solver: SolverConfig = Field(
        default_factory=SolverConfig, description="Solver configuration"
    )
    job_id: str | None = Field(None, description="Optional job identifier")

    @model_validator(mode="after")
    def _validate_strategy(self) -> "SignalSizingConfig":
        if self.strategy not in SIZING_STRATEGIES:
            raise ValueError(
                f"Unknown strategy '{self.strategy}'. "
                f"Supported: {', '.join(SIZING_STRATEGIES)}"
            )
        if self.strategy in ("mean_risk", "kelly", "fixed_risk"):
            if self.data.covariance_matrix is None:
                raise ValueError(f"covariance_matrix required for {self.strategy}")
        if self.strategy == "fixed_risk" and self.objective.target_volatility is None:
            raise ValueError("target_volatility required for fixed_risk strategy")
        return self
