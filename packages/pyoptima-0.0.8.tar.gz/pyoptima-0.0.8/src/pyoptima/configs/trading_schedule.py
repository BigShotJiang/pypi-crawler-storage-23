"""Trading schedule optimization config.

Example YAML::

    template: trading_schedule

    strategy: adaptive

    data:
      tasks:
        - name: rebalance_equities
          duration_minutes: 30
          priority: 1
          earliest: "09:30"
          latest: "15:00"
        - name: hedge_fx
          duration_minutes: 15
          priority: 2
      session_start: "09:30"
      session_end: "16:00"
      volume_profile: [0.08, 0.06, 0.05, ...]

    solver:
      name: highs
"""

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from pyoptima.configs.solver import SolverConfig

SCHEDULE_STRATEGIES = ["fixed", "adaptive", "priority"]


class TradingTaskConfig(BaseModel):
    """A single trading task to schedule."""

    model_config = ConfigDict(extra="forbid")

    name: str = Field(..., description="Task name")
    duration_minutes: int = Field(..., description="Duration in minutes")
    priority: int = Field(default=1, description="Priority (lower = higher priority)")
    earliest: str | None = Field(None, description="Earliest start time (HH:MM)")
    latest: str | None = Field(None, description="Latest end time (HH:MM)")
    depends_on: list[str] | None = Field(
        None, description="Tasks that must complete first"
    )


class TradingScheduleDataConfig(BaseModel):
    """Trading schedule input data."""

    model_config = ConfigDict(extra="forbid")

    tasks: list[TradingTaskConfig] = Field(..., description="Tasks to schedule")
    session_start: str = Field(
        default="09:30", description="Session start time (HH:MM)"
    )
    session_end: str = Field(default="16:00", description="Session end time (HH:MM)")
    slot_minutes: int = Field(default=5, description="Time slot granularity in minutes")
    volume_profile: list[float] | None = Field(
        None, description="Intraday volume profile"
    )
    volatility_profile: list[float] | None = Field(
        None, description="Intraday volatility profile"
    )


class TradingScheduleConfig(BaseModel):
    """Complete trading schedule configuration."""

    model_config = ConfigDict(extra="forbid")

    template: Literal["trading_schedule"] = "trading_schedule"
    strategy: str = Field(
        default="fixed", description="Strategy: fixed, adaptive, priority"
    )
    data: TradingScheduleDataConfig = Field(..., description="Tasks and session data")
    solver: SolverConfig = Field(
        default_factory=SolverConfig, description="Solver configuration"
    )
    job_id: str | None = Field(None, description="Optional job identifier")

    @model_validator(mode="after")
    def _validate_strategy(self) -> "TradingScheduleConfig":
        if self.strategy not in SCHEDULE_STRATEGIES:
            raise ValueError(
                f"Unknown strategy '{self.strategy}'. "
                f"Supported: {', '.join(SCHEDULE_STRATEGIES)}"
            )
        if self.strategy == "adaptive" and self.data.volume_profile is None:
            raise ValueError("volume_profile required for adaptive strategy")
        return self
