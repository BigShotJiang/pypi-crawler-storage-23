"""Execution optimization config.

Example YAML::

    template: execution

    strategy: vwap

    data:
      symbol: AAPL
      total_quantity: 50000
      side: buy
      adv: 75000000
      price: 185.50
      volume_profile: [0.08, 0.06, 0.05, ...]

    constraints:
      max_participation: 0.25

    solver:
      name: highs
"""

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from pyoptima.configs.solver import SolverConfig

EXECUTION_STRATEGIES = ["twap", "vwap", "implementation_shortfall", "pov"]


class ExecutionDataConfig(BaseModel):
    """Execution input data."""

    model_config = ConfigDict(extra="forbid")

    symbol: str = Field(..., description="Symbol to trade")
    total_quantity: float = Field(..., description="Total shares to trade")
    side: Literal["buy", "sell"] = Field(..., description="Trade direction")
    adv: float = Field(..., description="Average daily volume")
    price: float | None = Field(None, description="Current price")
    volatility: float | None = Field(None, description="Daily return volatility")
    bid_ask_spread: float | None = Field(None, description="Bid-ask spread in bps")
    volume_profile: list[float] | None = Field(
        None, description="Intraday volume profile (per interval)"
    )


class ExecutionConstraintsConfig(BaseModel):
    """Execution constraints."""

    model_config = ConfigDict(extra="forbid")

    max_participation: float = Field(
        default=0.25, description="Maximum participation rate per interval"
    )


class ExecutionStrategyConfig(BaseModel):
    """Strategy-specific parameters."""

    model_config = ConfigDict(extra="forbid")

    horizon_minutes: int = Field(default=60, description="Execution horizon in minutes")
    interval_minutes: int = Field(default=5, description="Slice interval in minutes")
    # Almgren-Chriss parameters (IS strategy)
    risk_aversion: float = Field(
        default=1e-6, description="Risk aversion for IS strategy"
    )
    temporary_impact: float = Field(
        default=0.1, description="Temporary impact coefficient"
    )
    permanent_impact: float = Field(
        default=0.01, description="Permanent impact coefficient"
    )
    # POV parameters
    target_participation: float = Field(
        default=0.10, description="Target participation rate (POV)"
    )


class ExecutionConfig(BaseModel):
    """Complete execution optimization configuration."""

    model_config = ConfigDict(extra="forbid")

    template: Literal["execution"] = "execution"
    strategy: str = Field(
        default="vwap",
        description="Execution strategy: twap, vwap, implementation_shortfall, pov",
    )
    data: ExecutionDataConfig = Field(..., description="Market data for the order")
    params: ExecutionStrategyConfig = Field(
        default_factory=ExecutionStrategyConfig,
        description="Strategy-specific parameters",
    )
    constraints: ExecutionConstraintsConfig = Field(
        default_factory=ExecutionConstraintsConfig,
        description="Execution constraints",
    )
    solver: SolverConfig = Field(
        default_factory=SolverConfig, description="Solver configuration"
    )
    job_id: str | None = Field(None, description="Optional job identifier")

    @model_validator(mode="after")
    def _validate_strategy(self) -> "ExecutionConfig":
        if self.strategy not in EXECUTION_STRATEGIES:
            raise ValueError(
                f"Unknown strategy '{self.strategy}'. "
                f"Supported: {', '.join(EXECUTION_STRATEGIES)}"
            )
        if self.strategy == "vwap" and self.data.volume_profile is None:
            raise ValueError("volume_profile required for vwap strategy")
        return self
