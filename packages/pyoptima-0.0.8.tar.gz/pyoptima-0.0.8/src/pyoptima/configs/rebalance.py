"""Rebalance optimization config.

Example YAML::

    template: rebalance

    strategy: min_cost

    data:
      current_weights: {AAPL: 0.30, GOOGL: 0.25, MSFT: 0.20, AMZN: 0.25}
      target_weights: {AAPL: 0.25, GOOGL: 0.30, MSFT: 0.25, AMZN: 0.20}
      symbols: [AAPL, GOOGL, MSFT, AMZN]
      transaction_costs: 0.001

    constraints:
      max_turnover: 0.15
      max_participation: 0.10

    solver:
      name: highs
"""

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from pyoptima.configs.solver import SolverConfig

REBALANCE_STRATEGIES = ["min_deviation", "min_cost", "min_impact"]


class RebalanceDataConfig(BaseModel):
    """Rebalance input data."""

    model_config = ConfigDict(extra="forbid")

    current_weights: dict[str, float] = Field(
        ..., description="Current portfolio weights"
    )
    target_weights: dict[str, float] = Field(
        ..., description="Target portfolio weights"
    )
    symbols: list[str] = Field(..., description="Asset symbols")
    transaction_costs: float | None = Field(
        None, description="Transaction cost rate (bps)"
    )
    adv: dict[str, float] | None = Field(
        None, description="Average daily volume per asset"
    )
    covariance_matrix: list[list[float]] | None = Field(
        None, description="Covariance matrix"
    )
    prices: dict[str, float] | None = Field(None, description="Asset prices")
    portfolio_value: float | None = Field(None, description="Total portfolio value")


class RebalanceConstraintsConfig(BaseModel):
    """Rebalance constraints."""

    model_config = ConfigDict(extra="forbid")

    max_turnover: float | None = Field(None, description="Maximum one-way turnover")
    max_tracking_error: float | None = Field(
        None, description="Maximum tracking error vs target"
    )
    max_participation: float | None = Field(
        None, description="Maximum ADV participation per trade"
    )


class RebalanceConfig(BaseModel):
    """Complete rebalance optimization configuration."""

    model_config = ConfigDict(extra="forbid")

    template: Literal["rebalance"] = "rebalance"
    strategy: str = Field(
        default="min_deviation",
        description="Strategy: min_deviation, min_cost, min_impact",
    )
    data: RebalanceDataConfig = Field(..., description="Portfolio data for rebalancing")
    constraints: RebalanceConstraintsConfig = Field(
        default_factory=RebalanceConstraintsConfig,
        description="Rebalance constraints",
    )
    solver: SolverConfig = Field(
        default_factory=SolverConfig, description="Solver configuration"
    )
    job_id: str | None = Field(None, description="Optional job identifier")

    @model_validator(mode="after")
    def _validate_strategy(self) -> "RebalanceConfig":
        if self.strategy not in REBALANCE_STRATEGIES:
            raise ValueError(
                f"Unknown strategy '{self.strategy}'. "
                f"Supported: {', '.join(REBALANCE_STRATEGIES)}"
            )
        if self.strategy == "min_cost" and self.data.transaction_costs is None:
            raise ValueError("transaction_costs required for min_cost strategy")
        if self.strategy == "min_impact" and self.data.adv is None:
            raise ValueError("adv required for min_impact strategy")
        return self
