"""Multi-account optimization config.

Example YAML::

    template: multi_account

    strategy: joint
    objective: min_volatility

    data:
      symbols: [AAPL, GOOGL, MSFT]
      expected_returns: [0.12, 0.10, 0.08]
      covariance_matrix: [[0.04, 0.01, 0.02], ...]
      accounts:
        - name: aggressive
          max_weight: 0.40
        - name: conservative
          max_weight: 0.15
          max_volatility: 0.10
      account_values: {aggressive: 1000000, conservative: 500000}

    solver:
      name: ipopt
"""

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from pyoptima.configs.solver import SolverConfig

MULTI_ACCOUNT_STRATEGIES = ["independent", "joint", "cascade"]


class AccountConfig(BaseModel):
    """Per-account constraints."""

    model_config = ConfigDict(extra="forbid")

    name: str = Field(..., description="Account name")
    min_weight: float = Field(
        default=0.0, description="Minimum weight per asset in this account"
    )
    max_weight: float = Field(
        default=1.0, description="Maximum weight per asset in this account"
    )
    max_turnover: float | None = Field(
        None, description="Maximum turnover for this account"
    )
    max_volatility: float | None = Field(
        None, description="Maximum volatility for this account"
    )
    excluded_symbols: list[str] | None = Field(
        None, description="Symbols excluded from this account"
    )


class MultiAccountDataConfig(BaseModel):
    """Multi-account input data."""

    model_config = ConfigDict(extra="forbid")

    symbols: list[str] = Field(..., description="Asset symbols")
    expected_returns: list[float] = Field(..., description="Expected returns")
    covariance_matrix: list[list[float]] = Field(..., description="Covariance matrix")
    accounts: list[AccountConfig] = Field(
        ..., description="Account definitions and per-account constraints"
    )
    account_values: dict[str, float] | None = Field(
        None, description="Account values: {name: value}"
    )
    current_weights: dict[str, dict[str, float]] | None = Field(
        None, description="Current weights per account: {account: {symbol: weight}}"
    )
    target_weights: dict[str, dict[str, float]] | None = Field(
        None, description="Target weights per account"
    )


class MultiAccountConfig(BaseModel):
    """Complete multi-account configuration."""

    model_config = ConfigDict(extra="forbid")

    template: Literal["multi_account"] = "multi_account"
    strategy: str = Field(
        default="independent", description="Strategy: independent, joint, cascade"
    )
    objective: str = Field(
        default="min_volatility",
        description="Objective: min_volatility, max_return, max_utility",
    )
    data: MultiAccountDataConfig = Field(
        ..., description="Shared data and per-account settings"
    )
    solver: SolverConfig = Field(
        default_factory=SolverConfig, description="Solver configuration"
    )
    job_id: str | None = Field(None, description="Optional job identifier")

    @model_validator(mode="after")
    def _validate_strategy(self) -> "MultiAccountConfig":
        if self.strategy not in MULTI_ACCOUNT_STRATEGIES:
            raise ValueError(
                f"Unknown strategy '{self.strategy}'. "
                f"Supported: {', '.join(MULTI_ACCOUNT_STRATEGIES)}"
            )
        return self
