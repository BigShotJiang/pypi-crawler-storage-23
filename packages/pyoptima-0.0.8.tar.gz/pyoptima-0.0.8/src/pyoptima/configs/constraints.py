"""Shared constraint config models.

Each constraint type has a Pydantic model defining its knobs.
These are composed into template-specific constraint containers.
"""

from pydantic import BaseModel, ConfigDict, Field


class WeightBoundsConfig(BaseModel):
    """Per-asset weight bounds."""

    model_config = ConfigDict(extra="forbid")

    min: float = Field(default=0.0, description="Minimum weight per asset")
    max: float = Field(default=1.0, description="Maximum weight per asset")
    per_asset: dict[str, list[float]] | None = Field(
        None, description="Per-asset overrides: {symbol: [min, max]}"
    )


class CardinalityConfig(BaseModel):
    """Cardinality constraint — limit number of held assets."""

    model_config = ConfigDict(extra="forbid")

    max_assets: int = Field(..., description="Maximum number of assets to hold")
    min_position: float = Field(
        default=0.0, description="Minimum weight if asset is held"
    )


class TurnoverConfig(BaseModel):
    """Turnover constraint — limit trading from current portfolio."""

    model_config = ConfigDict(extra="forbid")

    max: float = Field(..., description="Maximum one-way turnover (0-1)")
    current_weights: dict[str, float] = Field(
        ..., description="Current portfolio weights"
    )


class SectorConfig(BaseModel):
    """Sector exposure constraints."""

    model_config = ConfigDict(extra="forbid")

    asset_map: dict[str, str] = Field(
        ..., description="Asset to sector mapping: {AAPL: Tech}"
    )
    caps: dict[str, float] | None = Field(
        None, description="Maximum sector weight: {Tech: 0.6}"
    )
    floors: dict[str, float] | None = Field(
        None, description="Minimum sector weight: {Tech: 0.1}"
    )


class FactorExposureConfig(BaseModel):
    """Factor exposure constraints."""

    model_config = ConfigDict(extra="forbid")

    loadings: list[list[float]] = Field(
        ..., description="Factor loadings matrix (n_assets x n_factors)"
    )
    factor_names: list[str] = Field(..., description="Factor names")
    max_exposure: dict[str, float] | None = Field(
        None, description="Max exposure per factor"
    )
    min_exposure: dict[str, float] | None = Field(
        None, description="Min exposure per factor"
    )


class TrackingErrorConfig(BaseModel):
    """Tracking error constraint vs benchmark."""

    model_config = ConfigDict(extra="forbid")

    max: float = Field(..., description="Maximum tracking error")
    benchmark_weights: dict[str, float] = Field(
        ..., description="Benchmark portfolio weights"
    )


class LiquidityConfig(BaseModel):
    """Liquidity constraints — limit positions based on ADV."""

    model_config = ConfigDict(extra="forbid")

    adv: dict[str, float] = Field(
        ..., description="Average daily volume per asset (shares or dollars)"
    )
    max_participation: float = Field(
        default=0.10, description="Maximum fraction of daily volume"
    )
    max_days_to_liquidate: float = Field(
        default=1.0, description="Maximum days to fully liquidate"
    )
    prices: dict[str, float] | None = Field(
        None, description="Asset prices (for dollar-based ADV)"
    )
    portfolio_value: float | None = Field(None, description="Total portfolio value")


class TransactionCostConfig(BaseModel):
    """Transaction cost constraint/objective parameter."""

    model_config = ConfigDict(extra="forbid")

    rate: float = Field(default=0.001, description="Cost rate in bps per trade")
    current_weights: dict[str, float] | None = Field(
        None, description="Current weights for cost calculation"
    )
    per_asset: dict[str, float] | None = Field(None, description="Per-asset cost rates")


class SpreadCostConfig(BaseModel):
    """Maximum spread cost constraint."""

    model_config = ConfigDict(extra="forbid")

    spreads: dict[str, float] = Field(..., description="Bid-ask spread per asset (bps)")
    max_cost_bps: float = Field(..., description="Maximum total spread cost (bps)")
