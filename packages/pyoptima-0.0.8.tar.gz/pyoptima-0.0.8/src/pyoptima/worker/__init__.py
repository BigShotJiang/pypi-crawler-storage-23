"""
PyOptima Worker — durable job queue and worker process.

DB-only, broker-free. Run `pyoptima worker` to process optimization jobs
from the optimization_jobs table. Multiple workers can run; each job is
claimed by exactly one worker (atomic claim).

Quick start::

    from pyoptima.worker import Worker

    worker = Worker()
    await worker.start()
    await worker.run()

Submitting jobs (from API or any process with DB access)::

    from pyoptima.worker import submit_job

    job_id = await submit_job(
        template="portfolio",
        data={"objective": "min_volatility", ...},
        solver_options={"name": "ipopt"},
        job_id="opt-001",
    )
"""

from __future__ import annotations

import asyncio
from typing import Any

from pyoptima.worker.config import WorkerConfig
from pyoptima.worker.models import ClaimedJob, JobStatus, OptimizationJob
from pyoptima.worker.runner import Worker

__all__ = [
    "Worker",
    "WorkerConfig",
    "OptimizationJob",
    "ClaimedJob",
    "JobStatus",
    "submit_job",
    "submit_job_sync",
    "get_job",
]


async def submit_job(
    template: str,
    data: dict[str, Any],
    *,
    solver_options: dict[str, Any] | None = None,
    job_id: str | None = None,
    fires_at: Any | None = None,
    idempotency_key: str | None = None,
    max_attempts: int = 5,
    db_url: str | None = None,
) -> str:
    """Submit an optimization job to the queue.

    Args:
        template: Template name (e.g. portfolio, knapsack).
        data: Problem data dict.
        solver_options: Optional solver config (name, time_limit, etc.).
        job_id: Optional custom job id.
        fires_at: When the job becomes eligible (None = now).
        idempotency_key: Optional dedup key; duplicate submits return existing id.
        max_attempts: Max processing attempts.
        db_url: Database URL (default: PYOPTIMA_DATABASE_URL env).

    Returns:
        Job id (existing id if idempotency_key duplicate).
    """
    from pyoptima.worker.job_sources.database import DatabaseJobSource

    resolved = db_url
    if resolved is None:
        import os

        resolved = os.environ.get("PYOPTIMA_DATABASE_URL")
    if not resolved:
        raise ValueError("No database URL. Set PYOPTIMA_DATABASE_URL or pass db_url.")

    source = DatabaseJobSource(resolved, config=None)
    try:
        job = OptimizationJob(
            template=template,
            data=data,
            solver_options=solver_options,
            job_id=job_id,
            fires_at=fires_at,
            idempotency_key=idempotency_key,
            max_attempts=max_attempts,
        )
        return await source.submit(job)
    finally:
        await source.close()


def submit_job_sync(
    template: str,
    data: dict[str, Any],
    *,
    solver_options: dict[str, Any] | None = None,
    job_id: str | None = None,
    idempotency_key: str | None = None,
    max_attempts: int = 5,
    db_url: str | None = None,
) -> str:
    """Synchronous submit_job for use from non-async code."""
    return asyncio.run(
        submit_job(
            template=template,
            data=data,
            solver_options=solver_options,
            job_id=job_id,
            idempotency_key=idempotency_key,
            max_attempts=max_attempts,
            db_url=db_url,
        )
    )


async def get_job(job_id: str, db_url: str | None = None) -> dict[str, Any] | None:
    """Get job status and result by id. Returns None if not found."""
    import os

    from pyoptima.worker.job_sources.database import DatabaseJobSource

    resolved = db_url or os.environ.get("PYOPTIMA_DATABASE_URL")
    if not resolved:
        return None
    source = DatabaseJobSource(resolved, config=None)
    try:
        return await source.get_job(job_id)
    finally:
        await source.close()
