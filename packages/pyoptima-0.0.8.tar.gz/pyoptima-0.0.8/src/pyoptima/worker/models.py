"""Data models for the PyOptima worker service."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import Any


class JobStatus(str, Enum):
    """Lifecycle status of an optimization job."""

    PENDING = "pending"
    CLAIMED = "claimed"
    COMPLETED = "completed"
    FAILED = "failed"
    DEAD_LETTER = "dead_letter"
    CANCELLED = "cancelled"


@dataclass
class OptimizationJob:
    """Envelope for submitting an optimization job."""

    template: str
    data: dict[str, Any]
    solver_options: dict[str, Any] | None = None
    job_id: str | None = None
    fires_at: datetime | None = None
    idempotency_key: str | None = None
    max_attempts: int = 5


@dataclass
class ClaimedJob:
    """A job that has been atomically claimed by a worker."""

    event_id: str
    template: str
    data: dict[str, Any]
    solver_options: dict[str, Any]
    attempt: int
    max_attempts: int
    fires_at: datetime
    claimed_at: datetime
