"""Job processor: run optimization for a claimed job."""

from __future__ import annotations

import logging

from pyoptima import solve
from pyoptima.core.result import OptimizationResult
from pyoptima.worker.job_sources.base import JobSource
from pyoptima.worker.models import ClaimedJob

logger = logging.getLogger(__name__)


class JobProcessor:
    """Processes a single claimed job: solve then complete/fail."""

    def __init__(self, job_source: JobSource) -> None:
        self._job_source = job_source

    async def process_one(self, claimed: ClaimedJob) -> None:
        """Run optimization for the claimed job; complete or fail in the source."""
        logger.info(
            "Processing job %s: template=%s (attempt %d/%d)",
            claimed.event_id,
            claimed.template,
            claimed.attempt,
            claimed.max_attempts,
        )
        solver_name = (claimed.solver_options or {}).get("name")
        solver_options = {
            k: v
            for k, v in (claimed.solver_options or {}).items()
            if k != "name" and v is not None
        }
        try:
            result: OptimizationResult = solve(
                template_name=claimed.template,
                data=claimed.data,
                solver=solver_name,
                **solver_options,
            )
            await self._job_source.complete(claimed.event_id, result=result.to_dict())
            logger.info("Job %s completed", claimed.event_id)
        except Exception as e:
            logger.exception("Job %s failed: %s", claimed.event_id, e)
            retry = claimed.attempt < claimed.max_attempts
            await self._job_source.fail(claimed.event_id, str(e), retry=retry)
