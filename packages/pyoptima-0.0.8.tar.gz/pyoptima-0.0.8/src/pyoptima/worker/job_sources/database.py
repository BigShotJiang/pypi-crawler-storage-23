"""Database-backed job source (optimization_jobs table)."""

from __future__ import annotations

import asyncio
import logging
import uuid
from datetime import UTC, datetime, timedelta
from functools import partial
from typing import Any

from sqlalchemy import func, text, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from pyoptima.db.base import Base, get_engine, get_schema_prefix
from pyoptima.db.models.optimization_job import OptimizationJobModel
from pyoptima.worker.config import WorkerConfig
from pyoptima.worker.job_sources.base import JobSource
from pyoptima.worker.models import ClaimedJob, JobStatus, OptimizationJob

logger = logging.getLogger(__name__)

_DEFAULT_CLAIM_LEASE_TIMEOUT_S = 300
_DEFAULT_RETRY_BACKOFF_BASE_MS = 1000
_DEFAULT_RETRY_BACKOFF_MAX_MS = 300000


def _utc_now() -> datetime:
    return datetime.now(UTC)


def _status_to_api(s: str) -> str:
    """Map DB status to API JobStatus (queued, running, completed, failed, cancelled)."""
    if s == "pending":
        return "queued"
    if s == "claimed":
        return "running"
    if s in ("failed", "dead_letter"):
        return "failed"
    return s


class DatabaseJobSource(JobSource):
    """Job source backed by the optimization_jobs table."""

    def __init__(self, db_url: str, config: WorkerConfig | None = None) -> None:
        self._db_url = db_url
        self._config = config
        self._engine = get_engine(db_url)
        self._is_postgres = not db_url.startswith("sqlite://")
        self._prefix = get_schema_prefix(db_url)
        self._table = f"{self._prefix}optimization_jobs"
        self._SessionFactory = __import__(
            "sqlalchemy.orm", fromlist=["sessionmaker"]
        ).sessionmaker(bind=self._engine)

        self._claim_lease_timeout_s = (
            config.claim_lease_timeout_s if config else _DEFAULT_CLAIM_LEASE_TIMEOUT_S
        )
        self._retry_backoff_base_ms = (
            config.retry_backoff_base_ms if config else _DEFAULT_RETRY_BACKOFF_BASE_MS
        )
        self._retry_backoff_max_ms = (
            config.retry_backoff_max_ms if config else _DEFAULT_RETRY_BACKOFF_MAX_MS
        )
        # Ensure table exists (e.g. first run or no alembic)
        Base.metadata.create_all(self._engine, tables=[OptimizationJobModel.__table__])

    def _session(self) -> Session:
        return self._SessionFactory()

    async def _run_sync(self, fn: Any, *args: Any, **kwargs: Any) -> Any:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, partial(fn, *args, **kwargs))

    async def submit(self, job: OptimizationJob) -> str:
        return await self._run_sync(self._submit_sync, job)

    async def claim_next(self, worker_id: str) -> ClaimedJob | None:
        return await self._run_sync(self._claim_next_sync, worker_id)

    async def complete(
        self, event_id: str, result: dict[str, Any] | None = None
    ) -> None:
        await self._run_sync(self._complete_sync, event_id, result)

    async def fail(self, event_id: str, error: str, *, retry: bool = True) -> None:
        await self._run_sync(self._fail_sync, event_id, error, retry)

    async def health_check(self) -> bool:
        try:
            return await self._run_sync(self._health_check_sync)
        except Exception:
            return False

    async def get_job(self, job_id: str) -> dict[str, Any] | None:
        return await self._run_sync(self._get_job_sync, job_id)

    async def list_jobs(
        self,
        status: str | None = None,
        limit: int | None = None,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        return await self._run_sync(self._list_jobs_sync, status, limit, offset)

    async def cancel_job(self, job_id: str) -> bool:
        return await self._run_sync(self._cancel_job_sync, job_id)

    async def delete_job(self, job_id: str) -> bool:
        return await self._run_sync(self._delete_job_sync, job_id)

    async def get_stats(self) -> dict[str, int]:
        return await self._run_sync(self._get_stats_sync)

    async def pending_count(self) -> int:
        try:
            return await self._run_sync(self._pending_count_sync)
        except Exception:
            return -1

    async def close(self) -> None:
        if self._engine is not None:
            self._engine.dispose()

    # ------------------------------------------------------------------
    # Sync implementations
    # ------------------------------------------------------------------

    def _submit_sync(self, job: OptimizationJob) -> str:
        session = self._session()
        try:
            event_id = job.job_id or str(uuid.uuid4())
            now = _utc_now()
            fires_at = job.fires_at or now

            if job.idempotency_key and self._is_postgres:
                result = session.execute(
                    text(f"""
                        INSERT INTO {self._table}
                        (id, template, data_json, solver_json, status, fires_at,
                         attempt, max_attempts, idempotency_key, created_at)
                        VALUES
                        (:id, :template, :data_json, :solver_json, 'pending', :fires_at,
                         0, :max_attempts, :idempotency_key, :created_at)
                        ON CONFLICT (idempotency_key) DO UPDATE SET id = {self._table}.id
                        RETURNING id
                    """),
                    {
                        "id": event_id,
                        "template": job.template,
                        "data_json": job.data,
                        "solver_json": job.solver_options,
                        "fires_at": fires_at,
                        "max_attempts": job.max_attempts,
                        "idempotency_key": job.idempotency_key,
                        "created_at": now,
                    },
                )
                row = result.mappings().first()
                session.commit()
                return str(row["id"])

            if job.idempotency_key and not self._is_postgres:
                try:
                    row = OptimizationJobModel(
                        id=event_id,
                        template=job.template,
                        data_json=job.data,
                        solver_json=job.solver_options,
                        status=JobStatus.PENDING.value,
                        fires_at=fires_at,
                        attempt=0,
                        max_attempts=job.max_attempts,
                        idempotency_key=job.idempotency_key,
                        created_at=now,
                    )
                    session.add(row)
                    session.commit()
                    return event_id
                except IntegrityError:
                    session.rollback()
                    existing = (
                        session.query(OptimizationJobModel.id)
                        .filter(
                            OptimizationJobModel.idempotency_key == job.idempotency_key
                        )
                        .first()
                    )
                    if existing:
                        return str(existing[0])
                    raise

            row = OptimizationJobModel(
                id=event_id,
                template=job.template,
                data_json=job.data,
                solver_json=job.solver_options,
                status=JobStatus.PENDING.value,
                fires_at=fires_at,
                attempt=0,
                max_attempts=job.max_attempts,
                idempotency_key=job.idempotency_key,
                created_at=now,
            )
            session.add(row)
            session.commit()
            return event_id
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def _release_stale_claims_sync(self) -> None:
        session = self._session()
        try:
            session.execute(
                text(f"""
                    UPDATE {self._table}
                    SET status = 'pending', claimed_by = NULL, claimed_at = NULL
                    WHERE status = 'claimed'
                      AND claimed_at < :cutoff
                """),
                {"cutoff": _utc_now() - timedelta(seconds=self._claim_lease_timeout_s)},
            )
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def _claim_next_sync(self, worker_id: str) -> ClaimedJob | None:
        self._release_stale_claims_sync()
        if self._is_postgres:
            return self._claim_next_postgres(worker_id)
        return self._claim_next_sqlite(worker_id)

    def _claim_next_postgres(self, worker_id: str) -> ClaimedJob | None:
        session = self._session()
        now = _utc_now()
        table = self._table
        try:
            result = session.execute(
                text(f"""
                    WITH claimable AS (
                        SELECT id FROM {table}
                        WHERE status = 'pending' AND fires_at <= :now
                        ORDER BY fires_at ASC
                        LIMIT 1
                        FOR UPDATE SKIP LOCKED
                    )
                    UPDATE {table}
                    SET status = 'claimed', claimed_by = :worker_id, claimed_at = :now,
                        attempt = attempt + 1
                    FROM claimable
                    WHERE {table}.id = claimable.id
                    RETURNING *
                """),
                {"now": now, "worker_id": worker_id},
            )
            row = result.mappings().first()
            session.commit()
            if row is None:
                return None
            return self._row_to_claimed(row, now)
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def _claim_next_sqlite(self, worker_id: str) -> ClaimedJob | None:
        session = self._session()
        now = _utc_now()
        table = self._table
        try:
            result = session.execute(
                text(f"""
                    SELECT id, template, data_json, solver_json, attempt, max_attempts, fires_at
                    FROM {table}
                    WHERE status = 'pending' AND fires_at <= :now
                    ORDER BY fires_at ASC
                    LIMIT 1
                """),
                {"now": now},
            )
            candidate = result.mappings().first()
            if candidate is None:
                return None
            event_id = str(candidate["id"])
            new_attempt = (candidate["attempt"] or 0) + 1
            session.execute(
                text(f"""
                    UPDATE {table}
                    SET status = 'claimed', claimed_by = :worker_id, claimed_at = :now,
                        attempt = :attempt
                    WHERE id = :event_id
                """),
                {
                    "worker_id": worker_id,
                    "now": now,
                    "attempt": new_attempt,
                    "event_id": event_id,
                },
            )
            session.commit()
            return self._row_to_claimed(
                {
                    "id": event_id,
                    "template": candidate["template"],
                    "data_json": candidate["data_json"],
                    "solver_json": candidate["solver_json"],
                    "attempt": new_attempt,
                    "max_attempts": candidate["max_attempts"],
                    "fires_at": candidate["fires_at"],
                },
                now,
            )
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def _row_to_claimed(self, row: Any, claimed_at: datetime) -> ClaimedJob:
        data = (
            row["data_json"]
            if isinstance(row.get("data_json"), dict)
            else (row["data_json"] or {})
        )
        solver = row.get("solver_json") or {}
        return ClaimedJob(
            event_id=str(row["id"]),
            template=row["template"],
            data=data,
            solver_options=solver,
            attempt=row["attempt"],
            max_attempts=row["max_attempts"],
            fires_at=row["fires_at"],
            claimed_at=claimed_at,
        )

    def _complete_sync(
        self, event_id: str, result: dict[str, Any] | None = None
    ) -> None:
        session = self._session()
        try:
            session.execute(
                update(OptimizationJobModel)
                .where(OptimizationJobModel.id == event_id)
                .values(
                    status=JobStatus.COMPLETED.value,
                    completed_at=_utc_now(),
                    result_json=result,
                )
            )
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def _fail_sync(self, event_id: str, error: str, retry: bool) -> None:
        session = self._session()
        try:
            row = (
                session.query(OptimizationJobModel)
                .filter(OptimizationJobModel.id == event_id)
                .first()
            )
            if row is None:
                return
            can_retry = retry and row.attempt < row.max_attempts
            if can_retry:
                backoff_ms = min(
                    self._retry_backoff_max_ms,
                    self._retry_backoff_base_ms * (2**row.attempt),
                )
                row.status = JobStatus.PENDING.value
                row.claimed_by = None
                row.claimed_at = None
                row.error_message = error
                row.fires_at = _utc_now() + timedelta(milliseconds=backoff_ms)
            else:
                row.status = JobStatus.DEAD_LETTER.value
                row.error_message = error
                row.completed_at = _utc_now()
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def _health_check_sync(self) -> bool:
        session = self._session()
        try:
            session.execute(text("SELECT 1"))
            return True
        finally:
            session.close()

    def _get_job_sync(self, job_id: str) -> dict[str, Any] | None:
        session = self._session()
        try:
            row = (
                session.query(OptimizationJobModel)
                .filter(OptimizationJobModel.id == job_id)
                .first()
            )
            if row is None:
                return None
            return self._model_to_job_response(row)
        finally:
            session.close()

    def _model_to_job_response(self, row: OptimizationJobModel) -> dict[str, Any]:
        duration_ms = None
        if row.completed_at and row.claimed_at:
            duration_ms = (row.completed_at - row.claimed_at).total_seconds() * 1000
        elif row.completed_at and row.created_at:
            duration_ms = (row.completed_at - row.created_at).total_seconds() * 1000
        return {
            "job_id": str(row.id),
            "status": _status_to_api(row.status),
            "template": row.template,
            "result": row.result_json,
            "error": row.error_message,
            "created_at": row.created_at,
            "started_at": row.claimed_at,
            "completed_at": row.completed_at,
            "duration_ms": duration_ms,
        }

    def _list_jobs_sync(
        self,
        status: str | None = None,
        limit: int | None = None,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        session = self._session()
        try:
            q = session.query(OptimizationJobModel).order_by(
                OptimizationJobModel.created_at.desc()
            )
            if status is not None:
                api_to_db = {"queued": "pending", "running": "claimed"}
                db_status = api_to_db.get(status, status)
                q = q.filter(OptimizationJobModel.status == db_status)
            if offset > 0:
                q = q.offset(offset)
            if limit is not None:
                q = q.limit(limit)
            rows = q.all()
            return [self._model_to_job_response(r) for r in rows]
        finally:
            session.close()

    def _cancel_job_sync(self, job_id: str) -> bool:
        session = self._session()
        try:
            row = (
                session.query(OptimizationJobModel)
                .filter(OptimizationJobModel.id == job_id)
                .first()
            )
            if row is None or row.status not in (
                JobStatus.PENDING.value,
                JobStatus.CLAIMED.value,
            ):
                return False
            row.status = JobStatus.CANCELLED.value
            row.completed_at = _utc_now()
            session.commit()
            return True
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def _delete_job_sync(self, job_id: str) -> bool:
        session = self._session()
        try:
            deleted = (
                session.query(OptimizationJobModel)
                .filter(OptimizationJobModel.id == job_id)
                .delete()
            )
            session.commit()
            return deleted > 0
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def _get_stats_sync(self) -> dict[str, int]:
        session = self._session()
        try:
            total = session.query(OptimizationJobModel).count()
            by_status = {}
            for s in JobStatus:
                by_status[s.value] = (
                    session.query(OptimizationJobModel)
                    .filter(OptimizationJobModel.status == s.value)
                    .count()
                )
            by_status["total"] = total
            api_keys = {"queued": "pending", "running": "claimed"}
            out = {
                "queued": 0,
                "running": 0,
                "completed": 0,
                "failed": 0,
                "cancelled": 0,
            }
            for api, db in api_keys.items():
                out[api] = by_status.get(db, 0)
            out["completed"] = by_status.get("completed", 0)
            out["failed"] = by_status.get("failed", 0) + by_status.get("dead_letter", 0)
            out["cancelled"] = by_status.get("cancelled", 0)
            out["total"] = total
            return out
        finally:
            session.close()

    def _pending_count_sync(self) -> int:
        session = self._session()
        try:
            return (
                session.query(func.count(OptimizationJobModel.id))
                .filter(OptimizationJobModel.status == JobStatus.PENDING.value)
                .scalar()
                or 0
            )
        finally:
            session.close()
