import { useEffect, useRef } from 'react';
import { usePathname, useRouter } from 'next/navigation';
import { useAuthStore } from '@/stores/auth';
import {
  AUTH_SESSION_EXPIRED_EVENT,
  LOGIN_REASON_SESSION_EXPIRED,
  ROUTES,
} from '@/lib/constants';

/**
 * Runs the initial auth check on mount and listens for session-expired events.
 * This is the only place Next.js router is used for auth-related navigation.
 */
export function useAuthInit() {
  const router = useRouter();
  const pathname = usePathname();
  const checkAuth = useAuthStore((s) => s.checkAuth);
  const clearUser = useAuthStore((s) => s.clearUser);
  const didLoad = useRef(false);

  useEffect(() => {
    if (didLoad.current) return;
    didLoad.current = true;
    checkAuth();
  }, [checkAuth]);

  useEffect(() => {
    const handler = () => {
      clearUser();
      if (typeof window !== 'undefined') {
        sessionStorage.setItem('pyoptima_return_url', pathname || ROUTES.HOME);
      }
      router.replace(`${ROUTES.LOGIN}?reason=${LOGIN_REASON_SESSION_EXPIRED}`);
    };
    window.addEventListener(AUTH_SESSION_EXPIRED_EVENT, handler);
    return () => window.removeEventListener(AUTH_SESSION_EXPIRED_EVENT, handler);
  }, [clearUser, pathname, router]);
}
