/**
 * Client-side parsing of portfolio data from JSON or CSV.
 * Populates expected_returns, covariance_matrix, and symbols for the optimization form.
 */

export interface ParsedPortfolioJson {
  expected_returns: number[];
  covariance_matrix: number[][];
  symbols?: string[];
}

export interface ParsedPortfolioCsv {
  expected_returns: number[];
  symbols: string[];
}

function toNumberArray(x: unknown): number[] {
  if (Array.isArray(x)) return x.map((v) => (typeof v === 'number' && !Number.isNaN(v) ? v : Number(v) || 0));
  if (x && typeof x === 'object' && !Array.isArray(x)) return Object.values(x).map((v) => Number(v) || 0);
  throw new Error('expected_returns must be an array or object of numbers');
}

function toSymbols(x: unknown): string[] | undefined {
  if (Array.isArray(x)) return x.map(String).filter(Boolean);
  if (x && typeof x === 'object') return Object.keys(x as Record<string, unknown>);
  return undefined;
}

function toMatrix(x: unknown): number[][] {
  if (Array.isArray(x) && x.length > 0) {
    const rows = x.map((row) => {
      if (Array.isArray(row)) return row.map((v) => Number(v) || 0);
      if (row && typeof row === 'object') return Object.values(row).map((v) => Number(v) || 0);
      return [];
    });
    if (rows.every((r) => r.length === rows.length)) return rows;
  }
  if (x && typeof x === 'object' && !Array.isArray(x)) {
    const obj = x as Record<string, Record<string, number>>;
    const syms = Object.keys(obj).sort();
    if (syms.length === 0) throw new Error('covariance_matrix must be a 2D array or symbol-keyed object');
    const matrix = syms.map((r) => syms.map((c) => Number(obj[r]?.[c]) || 0));
    return matrix;
  }
  throw new Error('covariance_matrix must be a 2D array or object');
}

/**
 * Parse JSON string into expected_returns, covariance_matrix, and optional symbols.
 * Accepts: { expected_returns: number[]|object, covariance_matrix: number[][]|object, symbols?: string[] }
 */
export function parsePortfolioJson(text: string): ParsedPortfolioJson {
  let raw: unknown;
  try {
    raw = JSON.parse(text);
  } catch {
    throw new Error('Invalid JSON');
  }
  if (!raw || typeof raw !== 'object') throw new Error('JSON must be an object');
  const data = raw as Record<string, unknown>;

  const expectedReturnsRaw = data.expected_returns ?? data.expectedReturns;
  const covRaw = data.covariance_matrix ?? data.covarianceMatrix ?? data.covariance_matrix;
  const symbolsRaw = data.symbols ?? toSymbols(expectedReturnsRaw);

  if (expectedReturnsRaw == null) throw new Error('Missing expected_returns');
  if (covRaw == null) throw new Error('Missing covariance_matrix');

  const expected_returns = toNumberArray(expectedReturnsRaw);
  const covariance_matrix = toMatrix(covRaw);
  const symbols = toSymbols(symbolsRaw) ?? expected_returns.map((_, i) => `Asset${i + 1}`);

  if (expected_returns.length !== covariance_matrix.length) {
    throw new Error('expected_returns length must match covariance_matrix size');
  }
  if (symbols.length !== expected_returns.length) {
    throw new Error('symbols length must match expected_returns length');
  }

  return { expected_returns, covariance_matrix, symbols };
}

/**
 * Parse CSV string: header "symbol,return" and one row per asset.
 * Sets expected_returns and symbols only; covariance must be entered separately or via JSON.
 */
export function parsePortfolioCsv(text: string): ParsedPortfolioCsv {
  const lines = text.trim().split(/\r?\n/).filter(Boolean);
  if (lines.length < 2) throw new Error('CSV must have a header and at least one row');
  const header = lines[0].toLowerCase();
  const sep = header.includes('\t') ? '\t' : ',';
  const cols = lines[0].split(sep).map((c) => c.trim().toLowerCase());
  const symbolIdx = cols.findIndex((c) => c === 'symbol' || c === 'symbols' || c === 'asset');
  const returnIdx = cols.findIndex((c) => c === 'return' || c === 'expected_return' || c === 'er' || c === 'mu');
  const symCol = symbolIdx >= 0 ? symbolIdx : 0;
  const retCol = returnIdx >= 0 ? returnIdx : 1;
  const symbols: string[] = [];
  const expected_returns: number[] = [];
  for (let i = 1; i < lines.length; i++) {
    const parts = lines[i].split(sep).map((p) => p.trim());
    const sym = parts[symCol];
    const val = parseFloat(parts[retCol] ?? '');
    if (sym != null && sym !== '' && !Number.isNaN(val)) {
      symbols.push(sym);
      expected_returns.push(val);
    }
  }
  if (symbols.length === 0) throw new Error('No valid symbol,return rows found');
  return { expected_returns, symbols };
}
