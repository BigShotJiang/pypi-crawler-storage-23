/** Default app/website name shown in the UI (overridable via app-config). */
export const APP_NAME = 'PyOptima';

/** localStorage key for theme so an inline script can apply it before React (avoids flash). */
export const THEME_STORAGE_KEY = 'pyoptima-theme';

/** Theme IDs that use a dedicated palette (data-theme). light/dark/system use :root + .dark only. */
export const NAMED_THEME_IDS = [
  'ocean',
  'forest',
  'sunset',
  'high-contrast',
  'sepia',
  'violet',
  'cathay',
] as const;
export type NamedThemeId = (typeof NAMED_THEME_IDS)[number];

/** User-facing message when the API server is unreachable. */
export const API_CONNECTION_ERROR_MESSAGE =
  'API server not connected. Start it with: pyoptima api';

/** Timeout for the initial auth check (GET /auth/me) on app load (ms). */
export const AUTH_CHECK_TIMEOUT_MS = 4000;
/** Timeout for login POST request (ms). */
export const LOGIN_REQUEST_TIMEOUT_MS = 10000;

/** Custom event dispatched when API returns 401 (e.g. token expired). */
export const AUTH_SESSION_EXPIRED_EVENT = 'auth:sessionExpired';
/** Login page query param value for session-expired redirect. */
export const LOGIN_REASON_SESSION_EXPIRED = 'session_expired';

/** Official documentation site URL. Override with NEXT_PUBLIC_DOCS_URL. */
export const DOCS_URL = process.env.NEXT_PUBLIC_DOCS_URL ?? 'https://optophi.github.io/pyoptima/';

export const ROUTES = {
  HOME: '/',
  LOGIN: '/login',
  OPTIMIZATION: '/optimization',
  JOBS: '/jobs',
  METHODS: '/methods',
  DOCUMENTATION: '/documentation',
  SETTINGS: '/settings',
} as const;

export const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8003';

export const DEFAULT_TEMPLATE = 'knapsack';

export const PROBLEM_TYPES = ['LP', 'MIP', 'QP', 'NLP'] as const;

export const SOLVERS = {
  highs: { name: 'HiGHS', types: ['LP', 'MIP'], available: true },
  ipopt: { name: 'IPOPT', types: ['LP', 'QP', 'NLP'], available: true },
  cbc: { name: 'CBC', types: ['LP', 'MIP'], available: false },
  glpk: { name: 'GLPK', types: ['LP', 'MIP'], available: false },
  gurobi: { name: 'Gurobi', types: ['LP', 'MIP', 'QP'], available: false },
  cplex: { name: 'CPLEX', types: ['LP', 'MIP', 'QP'], available: false },
  scip: { name: 'SCIP', types: ['LP', 'MIP', 'MINLP'], available: false },
} as const;
