/**
 * Centralized type exports for PyOptima UI
 * 
 * Types are organized by domain for better maintainability
 */

// Optimization types
export interface OptimizeRequest {
  template: string;
  data: Record<string, any>;
  solver?: {
    name: string;
    time_limit?: number;
    gap_tolerance?: number;
    verbose?: boolean;
    options?: Record<string, any>;
  };
  job_id?: string;
}

export interface OptimizeResponse {
  job_id: string;
  status: string;
  result: Record<string, any>;
  template: string;
  solver: string;
  duration_ms: number;
}

// Job types
export type JobStatus = 'queued' | 'running' | 'completed' | 'failed' | 'cancelled';

export interface JobResponse {
  job_id: string;
  status: JobStatus;
  template?: string;
  result?: Record<string, any>;
  error?: string;
  created_at: string;
  started_at?: string;
  completed_at?: string;
  duration_ms?: number;
}

export interface AsyncJobResponse {
  job_id: string;
  status: JobStatus;
  message: string;
}

// Template types
export type TemplateCategory = 'mathematical' | 'combinatorial' | 'network' | 'scheduling' | 'finance';

export interface TemplateInfo {
  name: string;
  description: string;
  problem_type: string;
  required_data: string[];
  optional_data: string[];
  default_solver: string;
}

export interface TemplatesListResponse {
  templates: string[];
  total: number;
}

// Solver types
export interface SolverInfo {
  name: string;
  available: boolean;
  supports: string[];
}

export interface SolversListResponse {
  solvers: SolverInfo[];
  total: number;
}

// Validation types
export interface ValidationResponse {
  valid: boolean;
  template: string;
  errors: string[];
  warnings: string[];
}

// Batch optimization types
export interface BatchOptimizeResponse {
  total: number;
  completed: number;
  failed: number;
  results: OptimizeResponse[];
  duration_ms: number;
}

// Health types
export interface HealthResponse {
  status: string;
  version: string;
  solvers_available: number;
  templates_available: number;
}

// Error types
export interface ErrorResponse {
  error: string;
  message: string;
  details?: Record<string, any>;
}

// Form field configuration
export interface FieldConfig {
  name: string;
  label: string;
  type: 'text' | 'number' | 'boolean' | 'array' | 'object' | 'select' | 'matrix' | 'items' | 'json' | 'map';
  required: boolean;
  description?: string;
  default?: any;
  min?: number;
  max?: number;
  step?: number;
  options?: Array<{ value: string; label: string }>;
  items?: FieldConfig; // For array types
  properties?: Record<string, FieldConfig>; // For object types
}

// Template configuration
export interface TemplateConfig {
  id: string;
  name: string;
  description: string;
  category: TemplateCategory;
  icon: string;
  defaultSolver: string;
  problemType: string;
  fields: FieldConfig[];
  examples: Record<string, any>;
}
