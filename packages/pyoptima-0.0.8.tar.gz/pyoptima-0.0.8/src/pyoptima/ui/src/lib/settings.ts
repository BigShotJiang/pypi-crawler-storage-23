/**
 * Settings storage utility
 * 
 * Manages client-side settings using localStorage.
 */

export interface AppSettings {
  apiServer: {
    url: string;
  };
}

const SETTINGS_KEY = 'pyoptima_settings';
const DEFAULT_SETTINGS: AppSettings = {
  apiServer: {
    url: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8003',
  },
};

/**
 * Get current settings from localStorage
 */
export function getSettings(): AppSettings {
  if (typeof window === 'undefined') {
    return DEFAULT_SETTINGS;
  }

  try {
    const stored = localStorage.getItem(SETTINGS_KEY);
    if (stored) {
      const parsed = JSON.parse(stored);
      // Merge with defaults to ensure all fields exist
      return {
        ...DEFAULT_SETTINGS,
        ...parsed,
        apiServer: {
          ...DEFAULT_SETTINGS.apiServer,
          ...parsed.apiServer,
        },
      };
    }
  } catch (error) {
    console.error('Failed to load settings:', error);
  }

  return DEFAULT_SETTINGS;
}

/**
 * Save settings to localStorage
 */
export function saveSettings(settings: AppSettings): void {
  if (typeof window === 'undefined') {
    return;
  }

  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch (error) {
    console.error('Failed to save settings:', error);
    throw error;
  }
}

/**
 * Get API base URL from settings
 */
export function getApiBaseUrl(): string {
  const settings = getSettings();
  return settings.apiServer.url || DEFAULT_SETTINGS.apiServer.url;
}
