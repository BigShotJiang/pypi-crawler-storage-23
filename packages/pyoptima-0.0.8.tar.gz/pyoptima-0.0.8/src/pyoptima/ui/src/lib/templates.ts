/**
 * Template configurations for PyOptima UI
 * Defines the data schema, UI fields, and examples for each optimization template
 */

import type { TemplateConfig, TemplateCategory } from './types';

// =============================================================================
// Template Definitions
// =============================================================================

export const TEMPLATES: Record<string, TemplateConfig> = {
  // ---------------------------------------------------------------------------
  // Mathematical Programming
  // ---------------------------------------------------------------------------
  lp: {
    id: 'lp',
    name: 'Linear Programming',
    description: 'Optimize a linear objective subject to linear constraints',
    category: 'mathematical',
    icon: 'TrendingUp',
    defaultSolver: 'highs',
    problemType: 'LP',
    fields: [
      { name: 'c', label: 'Objective Coefficients (c)', type: 'array', required: true, description: 'Coefficients for the objective function' },
      { name: 'A', label: 'Constraint Matrix (A)', type: 'matrix', required: false, description: 'Inequality constraint matrix (Ax ≤ b)' },
      { name: 'b', label: 'Constraint Bounds (b)', type: 'array', required: false, description: 'Right-hand side for inequalities' },
      { name: 'A_eq', label: 'Equality Matrix (A_eq)', type: 'matrix', required: false, description: 'Equality constraint matrix' },
      { name: 'b_eq', label: 'Equality Bounds (b_eq)', type: 'array', required: false, description: 'Right-hand side for equalities' },
      { name: 'bounds', label: 'Variable Bounds', type: 'array', required: false, description: 'Bounds for each variable [[lb, ub], ...]' },
      { name: 'sense', label: 'Optimization Sense', type: 'select', required: false, default: 'minimize', options: [
        { value: 'minimize', label: 'Minimize' },
        { value: 'maximize', label: 'Maximize' },
      ]},
    ],
    examples: {
      c: [3, 2],
      A: [[1, 1], [2, 1]],
      b: [4, 5],
      sense: 'maximize',
    },
  },

  mip: {
    id: 'mip',
    name: 'Mixed-Integer Programming',
    description: 'Linear programming with integer variables',
    category: 'mathematical',
    icon: 'Grid',
    defaultSolver: 'highs',
    problemType: 'MIP',
    fields: [
      { name: 'c', label: 'Objective Coefficients', type: 'array', required: true },
      { name: 'A', label: 'Constraint Matrix', type: 'matrix', required: false },
      { name: 'b', label: 'Constraint Bounds', type: 'array', required: false },
      { name: 'integer_vars', label: 'Integer Variable Indices', type: 'array', required: false, description: 'Indices of integer variables' },
      { name: 'binary_vars', label: 'Binary Variable Indices', type: 'array', required: false, description: 'Indices of binary (0-1) variables' },
      { name: 'sense', label: 'Optimization Sense', type: 'select', required: false, default: 'minimize', options: [
        { value: 'minimize', label: 'Minimize' },
        { value: 'maximize', label: 'Maximize' },
      ]},
    ],
    examples: {
      c: [5, 8],
      A: [[1, 1], [5, 9]],
      b: [6, 45],
      integer_vars: [0, 1],
      sense: 'maximize',
    },
  },

  qp: {
    id: 'qp',
    name: 'Quadratic Programming',
    description: 'Quadratic objective with linear constraints',
    category: 'mathematical',
    icon: 'Activity',
    defaultSolver: 'ipopt',
    problemType: 'QP',
    fields: [
      { name: 'Q', label: 'Quadratic Matrix (Q)', type: 'matrix', required: true, description: 'Quadratic term (½ x\'Qx)' },
      { name: 'c', label: 'Linear Coefficients (c)', type: 'array', required: false, description: 'Linear term coefficients' },
      { name: 'A', label: 'Constraint Matrix', type: 'matrix', required: false },
      { name: 'b', label: 'Constraint Bounds', type: 'array', required: false },
      { name: 'sense', label: 'Optimization Sense', type: 'select', required: false, default: 'minimize', options: [
        { value: 'minimize', label: 'Minimize' },
        { value: 'maximize', label: 'Maximize' },
      ]},
    ],
    examples: {
      Q: [[2, 0], [0, 2]],
      c: [-2, -5],
      A: [[1, 1]],
      b: [2],
      sense: 'minimize',
    },
  },

  // ---------------------------------------------------------------------------
  // Combinatorial Optimization
  // ---------------------------------------------------------------------------
  knapsack: {
    id: 'knapsack',
    name: 'Knapsack Problem',
    description: 'Select items to maximize value within capacity',
    category: 'combinatorial',
    icon: 'Package',
    defaultSolver: 'highs',
    problemType: 'MIP',
    fields: [
      { name: 'items', label: 'Items', type: 'items', required: true, description: 'List of items with name, value, and weight' },
      { name: 'capacity', label: 'Capacity', type: 'number', required: true, description: 'Maximum total weight', min: 1 },
      { name: 'variant', label: 'Variant', type: 'select', required: false, default: '0-1', options: [
        { value: '0-1', label: '0-1 Knapsack (each item once)' },
        { value: 'unbounded', label: 'Unbounded (items can repeat)' },
        { value: 'bounded', label: 'Bounded (limited quantities)' },
      ]},
    ],
    examples: {
      items: [
        { name: 'Gold Bar', value: 100, weight: 5 },
        { name: 'Silver Coins', value: 50, weight: 3 },
        { name: 'Bronze Medal', value: 30, weight: 2 },
        { name: 'Copper Wire', value: 20, weight: 4 },
      ],
      capacity: 10,
    },
  },

  assignment: {
    id: 'assignment',
    name: 'Assignment Problem',
    description: 'Optimally assign workers to tasks',
    category: 'combinatorial',
    icon: 'Users',
    defaultSolver: 'highs',
    problemType: 'MIP',
    fields: [
      { name: 'costs', label: 'Cost Matrix', type: 'matrix', required: true, description: 'Cost[i][j] = cost to assign worker i to task j' },
      { name: 'workers', label: 'Worker Names', type: 'array', required: false },
      { name: 'tasks', label: 'Task Names', type: 'array', required: false },
      { name: 'sense', label: 'Optimization Sense', type: 'select', required: false, default: 'minimize', options: [
        { value: 'minimize', label: 'Minimize Cost' },
        { value: 'maximize', label: 'Maximize Value' },
      ]},
    ],
    examples: {
      costs: [
        [9, 2, 7, 8],
        [6, 4, 3, 7],
        [5, 8, 1, 8],
        [7, 6, 9, 4],
      ],
      workers: ['Alice', 'Bob', 'Charlie', 'Diana'],
      tasks: ['Task A', 'Task B', 'Task C', 'Task D'],
    },
  },

  tsp: {
    id: 'tsp',
    name: 'Traveling Salesman',
    description: 'Find shortest route visiting all cities',
    category: 'combinatorial',
    icon: 'MapPin',
    defaultSolver: 'highs',
    problemType: 'MIP',
    fields: [
      { name: 'distances', label: 'Distance Matrix', type: 'matrix', required: true, description: 'Distance[i][j] = distance from city i to j' },
      { name: 'cities', label: 'City Names', type: 'array', required: false },
    ],
    examples: {
      distances: [
        [0, 29, 20, 21],
        [29, 0, 15, 17],
        [20, 15, 0, 28],
        [21, 17, 28, 0],
      ],
      cities: ['New York', 'Los Angeles', 'Chicago', 'Houston'],
    },
  },

  vrp: {
    id: 'vrp',
    name: 'Vehicle Routing',
    description: 'Optimize routes for multiple vehicles',
    category: 'combinatorial',
    icon: 'Truck',
    defaultSolver: 'highs',
    problemType: 'MIP',
    fields: [
      { name: 'distances', label: 'Distance Matrix', type: 'matrix', required: true },
      { name: 'demands', label: 'Customer Demands', type: 'array', required: true },
      { name: 'vehicle_capacity', label: 'Vehicle Capacity', type: 'number', required: true },
      { name: 'num_vehicles', label: 'Number of Vehicles', type: 'number', required: false, min: 1 },
      { name: 'depot', label: 'Depot Index', type: 'number', required: false, default: 0 },
    ],
    examples: {
      distances: [
        [0, 10, 15, 20, 25],
        [10, 0, 12, 18, 22],
        [15, 12, 0, 8, 16],
        [20, 18, 8, 0, 14],
        [25, 22, 16, 14, 0],
      ],
      demands: [0, 3, 4, 2, 5],
      vehicle_capacity: 8,
      num_vehicles: 2,
    },
  },

  binpacking: {
    id: 'binpacking',
    name: 'Bin Packing',
    description: 'Pack items into minimum number of bins',
    category: 'combinatorial',
    icon: 'Box',
    defaultSolver: 'highs',
    problemType: 'MIP',
    fields: [
      { name: 'items', label: 'Item Sizes', type: 'array', required: true },
      { name: 'bin_capacity', label: 'Bin Capacity', type: 'number', required: true, min: 1 },
      { name: 'item_names', label: 'Item Names', type: 'array', required: false },
    ],
    examples: {
      items: [4, 8, 1, 4, 2, 1, 5, 6, 3],
      bin_capacity: 10,
      item_names: ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I'],
    },
  },

  // ---------------------------------------------------------------------------
  // Network Flow
  // ---------------------------------------------------------------------------
  transportation: {
    id: 'transportation',
    name: 'Transportation Problem',
    description: 'Optimize shipping from sources to destinations',
    category: 'network',
    icon: 'Truck',
    defaultSolver: 'highs',
    problemType: 'LP',
    fields: [
      { name: 'costs', label: 'Cost Matrix', type: 'matrix', required: true, description: 'Shipping cost from source i to destination j' },
      { name: 'supply', label: 'Supply at Sources', type: 'array', required: true },
      { name: 'demand', label: 'Demand at Destinations', type: 'array', required: true },
      { name: 'sources', label: 'Source Names', type: 'array', required: false },
      { name: 'destinations', label: 'Destination Names', type: 'array', required: false },
    ],
    examples: {
      costs: [
        [8, 6, 10, 9],
        [9, 12, 13, 7],
        [14, 9, 16, 5],
      ],
      supply: [35, 50, 40],
      demand: [45, 20, 30, 30],
      sources: ['Factory A', 'Factory B', 'Factory C'],
      destinations: ['Store 1', 'Store 2', 'Store 3', 'Store 4'],
    },
  },

  mincostflow: {
    id: 'mincostflow',
    name: 'Min Cost Flow',
    description: 'Find minimum cost flow through a network',
    category: 'network',
    icon: 'GitBranch',
    defaultSolver: 'highs',
    problemType: 'LP',
    fields: [
      { name: 'nodes', label: 'Node Names', type: 'array', required: true },
      { name: 'arcs', label: 'Arcs (from, to, capacity, cost)', type: 'json', required: true },
      { name: 'supplies', label: 'Node Supplies', type: 'json', required: true, description: 'Positive = supply, negative = demand' },
    ],
    examples: {
      nodes: ['S', 'A', 'B', 'T'],
      arcs: [
        { from: 'S', to: 'A', capacity: 10, cost: 2 },
        { from: 'S', to: 'B', capacity: 10, cost: 4 },
        { from: 'A', to: 'B', capacity: 5, cost: 1 },
        { from: 'A', to: 'T', capacity: 10, cost: 3 },
        { from: 'B', to: 'T', capacity: 10, cost: 2 },
      ],
      supplies: { S: 15, T: -15 },
    },
  },

  maxflow: {
    id: 'maxflow',
    name: 'Maximum Flow',
    description: 'Find maximum flow through a network',
    category: 'network',
    icon: 'Zap',
    defaultSolver: 'highs',
    problemType: 'LP',
    fields: [
      { name: 'nodes', label: 'Node Names', type: 'array', required: true },
      { name: 'arcs', label: 'Arcs (from, to, capacity)', type: 'json', required: true },
      { name: 'source', label: 'Source Node', type: 'text', required: true },
      { name: 'sink', label: 'Sink Node', type: 'text', required: true },
    ],
    examples: {
      nodes: ['S', 'A', 'B', 'C', 'T'],
      arcs: [
        { from: 'S', to: 'A', capacity: 10 },
        { from: 'S', to: 'B', capacity: 10 },
        { from: 'A', to: 'C', capacity: 8 },
        { from: 'B', to: 'A', capacity: 5 },
        { from: 'B', to: 'C', capacity: 10 },
        { from: 'C', to: 'T', capacity: 15 },
      ],
      source: 'S',
      sink: 'T',
    },
  },

  // ---------------------------------------------------------------------------
  // Scheduling
  // ---------------------------------------------------------------------------
  jobshop: {
    id: 'jobshop',
    name: 'Job Shop Scheduling',
    description: 'Schedule jobs on machines to minimize makespan',
    category: 'scheduling',
    icon: 'Calendar',
    defaultSolver: 'highs',
    problemType: 'MIP',
    fields: [
      { name: 'jobs', label: 'Jobs', type: 'json', required: true, description: 'List of jobs with operations' },
      { name: 'machines', label: 'Machine Names', type: 'array', required: false },
    ],
    examples: {
      jobs: [
        { name: 'Job1', operations: [{ machine: 'M1', duration: 3 }, { machine: 'M2', duration: 2 }] },
        { name: 'Job2', operations: [{ machine: 'M2', duration: 2 }, { machine: 'M1', duration: 4 }] },
        { name: 'Job3', operations: [{ machine: 'M1', duration: 1 }, { machine: 'M2', duration: 3 }] },
      ],
      machines: ['M1', 'M2'],
    },
  },

  // ---------------------------------------------------------------------------
  // Facility Location
  // ---------------------------------------------------------------------------
  facility: {
    id: 'facility',
    name: 'Facility Location',
    description: 'Decide which facilities to open and customer assignments',
    category: 'combinatorial',
    icon: 'Building',
    defaultSolver: 'highs',
    problemType: 'MIP',
    fields: [
      { name: 'fixed_costs', label: 'Fixed Costs', type: 'array', required: true, description: 'Cost to open each facility' },
      { name: 'transport_costs', label: 'Transport Cost Matrix', type: 'matrix', required: true, description: 'Cost to serve customer j from facility i' },
      { name: 'capacities', label: 'Facility Capacities', type: 'array', required: false },
      { name: 'demands', label: 'Customer Demands', type: 'array', required: false },
      { name: 'facilities', label: 'Facility Names', type: 'array', required: false },
      { name: 'customers', label: 'Customer Names', type: 'array', required: false },
    ],
    examples: {
      fixed_costs: [100, 120, 90],
      transport_costs: [
        [10, 20, 15, 25],
        [15, 10, 20, 18],
        [20, 15, 10, 22],
      ],
      capacities: [50, 60, 40],
      demands: [20, 25, 15, 30],
      facilities: ['Warehouse A', 'Warehouse B', 'Warehouse C'],
      customers: ['Store 1', 'Store 2', 'Store 3', 'Store 4'],
    },
  },

  // ---------------------------------------------------------------------------
  // Finance
  // ---------------------------------------------------------------------------
  portfolio: {
    id: 'portfolio',
    name: 'Portfolio Optimization',
    description: 'Optimize asset allocation for risk/return',
    category: 'finance',
    icon: 'TrendingUp',
    defaultSolver: 'ipopt',
    problemType: 'QP',
    fields: [
      { name: 'expected_returns', label: 'Expected Returns', type: 'array', required: true, description: 'Annualized expected return for each asset' },
      { name: 'covariance_matrix', label: 'Covariance Matrix', type: 'matrix', required: true, description: 'Annualized covariance matrix' },
      { name: 'symbols', label: 'Asset Symbols', type: 'array', required: false },
      { name: 'objective', label: 'Objective', type: 'select', required: false, default: 'min_volatility', options: [
        { value: 'min_volatility', label: 'Minimize Volatility' },
        { value: 'max_sharpe', label: 'Maximize Sharpe Ratio' },
        { value: 'max_return', label: 'Maximize Return' },
        { value: 'efficient_return', label: 'Target Return (Min Risk)' },
        { value: 'efficient_risk', label: 'Target Risk (Max Return)' },
        { value: 'max_utility', label: 'Maximize Utility' },
        { value: 'black_litterman_max_sharpe', label: 'Black-Litterman Max Sharpe' },
        { value: 'black_litterman_min_volatility', label: 'Black-Litterman Min Volatility' },
        { value: 'black_litterman_quadratic_utility', label: 'Black-Litterman Utility' },
        { value: 'min_cvar', label: 'Minimize CVaR' },
        { value: 'efficient_cvar_risk', label: 'Efficient CVaR Risk' },
        { value: 'efficient_cvar_return', label: 'Efficient CVaR Return' },
        { value: 'min_cdar', label: 'Minimize CDaR' },
        { value: 'efficient_cdar_risk', label: 'Efficient CDaR Risk' },
        { value: 'efficient_cdar_return', label: 'Efficient CDaR Return' },
        { value: 'min_semivariance', label: 'Minimize Semivariance' },
        { value: 'efficient_semivariance_risk', label: 'Efficient Semivariance Risk' },
        { value: 'efficient_semivariance_return', label: 'Efficient Semivariance Return' },
        { value: 'cla_min_volatility', label: 'CLA Min Volatility' },
        { value: 'cla_max_sharpe', label: 'CLA Max Sharpe' },
        { value: 'hierarchical_min_volatility', label: 'Hierarchical Min Volatility' },
        { value: 'hierarchical_max_sharpe', label: 'Hierarchical Max Sharpe' },
        { value: 'risk_parity', label: 'Risk Parity' },
        { value: 'equal_risk_contribution', label: 'Equal Risk Contribution' },
        { value: 'max_diversification', label: 'Max Diversification' },
        { value: 'max_diversification_index', label: 'Max Diversification Index' },
        { value: 'max_sharpe_with_costs', label: 'Max Sharpe (Cost-Aware)' },
        { value: 'min_volatility_with_costs', label: 'Min Volatility (Cost-Aware)' },
        { value: 'momentum_filtered_max_sharpe', label: 'Momentum-Filtered Max Sharpe' },
        { value: 'momentum_filtered_min_volatility', label: 'Momentum-Filtered Min Volatility' },
        { value: 'factor_based_selection', label: 'Factor-Based Selection' },
      ]},
      { name: 'risk_free_rate', label: 'Risk-Free Rate', type: 'number', required: false, default: 0.02, step: 0.001 },
      { name: 'target_return', label: 'Target Return', type: 'number', required: false, step: 0.01 },
      { name: 'target_volatility', label: 'Target Volatility', type: 'number', required: false, step: 0.01 },
      { name: 'risk_aversion', label: 'Risk Aversion', type: 'number', required: false, default: 1.0, step: 0.1 },
      { name: 'confidence_level', label: 'Confidence Level', type: 'number', required: false, default: 0.05, min: 0.01, max: 0.5, step: 0.01, description: 'For CVaR/CDaR (e.g., 0.05 = 5%)' },
      { name: 'benchmark', label: 'Benchmark Return', type: 'number', required: false, default: 0.0, step: 0.01, description: 'For semivariance calculation' },
      { name: 'target_cvar', label: 'Target CVaR', type: 'number', required: false, step: 0.01 },
      { name: 'target_cdar', label: 'Target CDaR', type: 'number', required: false, step: 0.01 },
      { name: 'target_semivariance', label: 'Target Semivariance', type: 'number', required: false, step: 0.01 },
      { name: 'returns', label: 'Historical Returns', type: 'matrix', required: false, description: 'Historical returns matrix (required for CVaR/CDaR/Semivariance)' },
      { name: 'market_caps', label: 'Market Capitalizations', type: 'array', required: false, description: 'For Black-Litterman' },
      { name: 'views', label: 'Investor Views', type: 'array', required: false, description: 'For Black-Litterman' },
      { name: 'view_cov', label: 'View Covariance', type: 'matrix', required: false, description: 'For Black-Litterman' },
      { name: 'tau', label: 'Tau (BL scaling)', type: 'number', required: false, default: 1.0, step: 0.1, description: 'For Black-Litterman' },
      { name: 'min_weight', label: 'Min Weight', type: 'number', required: false, default: 0, min: -1, max: 1, step: 0.01, description: 'Global minimum weight per asset' },
      { name: 'max_weight', label: 'Max Weight', type: 'number', required: false, default: 1, min: 0, max: 1, step: 0.01, description: 'Global maximum weight per asset' },
      { name: 'max_assets', label: 'Max Assets', type: 'number', required: false, min: 1, description: 'Maximum number of assets to hold (cardinality constraint)' },
      { name: 'min_position_size', label: 'Min Position Size', type: 'number', required: false, default: 0, min: 0, max: 1, step: 0.01, description: 'Minimum weight if asset is held (for cardinality)' },
      { name: 'current_weights', label: 'Current Weights', type: 'map', required: false, description: 'Current portfolio weights (dict: asset -> weight) for turnover constraint' },
      { name: 'max_turnover', label: 'Max Turnover', type: 'number', required: false, min: 0, max: 1, step: 0.01, description: 'Maximum portfolio turnover (0.0 to 1.0)' },
      { name: 'transaction_costs', label: 'Transaction Costs', type: 'map', required: false, description: 'Transaction costs per asset (dict: asset -> cost) or array/list' },
      { name: 'per_asset_bounds', label: 'Per-Asset Bounds', type: 'map', required: false, description: 'Per-asset weight bounds (dict: asset -> [min, max])' },
      { name: 'sector_caps', label: 'Sector Caps', type: 'map', required: false, description: 'Maximum exposure per sector (dict: sector -> max_weight)' },
      { name: 'sector_mins', label: 'Sector Minimums', type: 'map', required: false, description: 'Minimum exposure per sector (dict: sector -> min_weight)' },
      { name: 'asset_sectors', label: 'Asset Sectors', type: 'map', required: false, description: 'Asset to sector mapping (dict: asset -> sector)' },
      // Momentum (for momentum-filtered objectives)
      { name: 'momentum_period', label: 'Momentum Period', type: 'number', required: false, default: 20, min: 1, step: 1, description: 'Lookback period for momentum (e.g. 20 days)' },
      { name: 'momentum_top_pct', label: 'Momentum Top %', type: 'number', required: false, default: 0.2, min: 0.01, max: 1, step: 0.05, description: 'Fraction of assets to keep (e.g. 0.2 = top 20%)' },
      // Factor-based
      { name: 'factor_data', label: 'Factor Data', type: 'map', required: false, description: 'Factor name -> array of scores per asset (for factor_based_selection)' },
      { name: 'factor_weights', label: 'Factor Weights', type: 'map', required: false, description: 'Factor name -> weight for combining scores' },
      // Extra objective/constraint params
      { name: 'min_net_return', label: 'Min Net Return', type: 'number', required: false, step: 0.01, description: 'Minimum return after costs' },
      { name: 'max_volatility', label: 'Max Volatility', type: 'number', required: false, step: 0.01, description: 'Portfolio volatility cap (e.g. 0.20 = 20%)' },
      // Liquidity constraints
      { name: 'adv', label: 'Average Daily Volume', type: 'map', required: false, description: 'Symbol -> ADV (shares) for liquidity limits' },
      { name: 'max_days_to_liquidate', label: 'Max Days to Liquidate', type: 'number', required: false, default: 1, min: 0.1, step: 0.5, description: 'Days to fully exit a position' },
      { name: 'participation_rate', label: 'Participation Rate', type: 'number', required: false, default: 0.1, min: 0.01, max: 1, step: 0.01, description: 'Fraction of ADV traded per day' },
      { name: 'portfolio_value', label: 'Portfolio Value', type: 'number', required: false, default: 1000000, min: 1, description: 'Total AUM for liquidity calculations' },
      { name: 'max_participation', label: 'Max Participation', type: 'number', required: false, default: 0.25, min: 0, max: 1, step: 0.01, description: 'Max fraction of ADV per trade' },
      { name: 'spreads', label: 'Bid-Ask Spreads (bps)', type: 'map', required: false, description: 'Symbol -> spread in basis points' },
      { name: 'max_cost_bps', label: 'Max Spread Cost (bps)', type: 'number', required: false, default: 10, min: 0, step: 1, description: 'Max total spread cost in basis points' },
      // Risk limits
      { name: 'max_concentration', label: 'Max Concentration', type: 'number', required: false, min: 0, max: 1, step: 0.01, description: 'Max combined weight in top K assets (e.g. 0.6)' },
      { name: 'concentration_top_k', label: 'Concentration Top K', type: 'number', required: false, default: 1, min: 1, step: 1, description: 'Number of largest positions to limit' },
      { name: 'max_tracking_error', label: 'Max Tracking Error', type: 'number', required: false, step: 0.01, description: 'Max tracking error vs benchmark (e.g. 0.02 = 2%)' },
      { name: 'benchmark_weights', label: 'Benchmark Weights', type: 'map', required: false, description: 'Benchmark weights for tracking error (symbol -> weight)' },
    ],
    examples: {
      expected_returns: [0.12, 0.10, 0.08, 0.06],
      covariance_matrix: [
        [0.04, 0.01, 0.02, 0.005],
        [0.01, 0.03, 0.015, 0.008],
        [0.02, 0.015, 0.025, 0.01],
        [0.005, 0.008, 0.01, 0.015],
      ],
      symbols: ['AAPL', 'GOOGL', 'MSFT', 'AMZN'],
      objective: 'min_volatility',
      max_weight: 0.4,
    },
  },

  // ---------------------------------------------------------------------------
  // Finance – Execution, Signal Sizing, Rebalance, Risk Budget, Multi-Account
  // ---------------------------------------------------------------------------
  execution: {
    id: 'execution',
    name: 'Order Execution',
    description: 'Split parent orders into optimal child slices (TWAP, VWAP, IS, POV)',
    category: 'finance',
    icon: 'Zap',
    defaultSolver: 'highs',
    problemType: 'LP',
    fields: [
      { name: 'strategy', label: 'Strategy', type: 'select', required: true, default: 'vwap', options: [
        { value: 'twap', label: 'TWAP' },
        { value: 'vwap', label: 'VWAP' },
        { value: 'implementation_shortfall', label: 'Implementation Shortfall' },
        { value: 'pov', label: 'POV' },
      ]},
      { name: 'symbol', label: 'Symbol', type: 'text', required: true, description: 'Ticker symbol' },
      { name: 'total_quantity', label: 'Total Quantity', type: 'number', required: true, min: 1, description: 'Shares to execute' },
      { name: 'side', label: 'Side', type: 'select', required: false, default: 'buy', options: [{ value: 'buy', label: 'Buy' }, { value: 'sell', label: 'Sell' }]},
      { name: 'horizon_minutes', label: 'Horizon (minutes)', type: 'number', required: false, default: 60, min: 1 },
      { name: 'interval_minutes', label: 'Interval (minutes)', type: 'number', required: false, default: 5, min: 1 },
      { name: 'adv', label: 'ADV', type: 'number', required: false, description: 'Average daily volume (shares)' },
      { name: 'price', label: 'Price', type: 'number', required: false, description: 'Current mid price' },
      { name: 'volatility', label: 'Volatility', type: 'number', required: false, step: 0.001, description: 'Daily volatility (decimal)' },
      { name: 'bid_ask_spread', label: 'Bid-Ask Spread (bps)', type: 'number', required: false },
      { name: 'volume_profile', label: 'Volume Profile', type: 'array', required: false, description: 'Per-interval volume fractions' },
      { name: 'risk_aversion', label: 'Risk Aversion', type: 'number', required: false, default: 1e-6, description: 'Almgren-Chriss λ (IS only)' },
      { name: 'temporary_impact', label: 'Temporary Impact', type: 'number', required: false, default: 0.1 },
      { name: 'permanent_impact', label: 'Permanent Impact', type: 'number', required: false, default: 0.01 },
      { name: 'target_participation', label: 'Target Participation', type: 'number', required: false, default: 0.1, min: 0, max: 1, step: 0.01 },
      { name: 'max_participation', label: 'Max Participation', type: 'number', required: false, default: 0.25, min: 0, max: 1, step: 0.01 },
    ],
    examples: {
      strategy: 'vwap',
      symbol: 'AAPL',
      total_quantity: 50000,
      side: 'buy',
      horizon_minutes: 120,
      interval_minutes: 5,
      adv: 75000000,
    },
  },

  signal_sizing: {
    id: 'signal_sizing',
    name: 'Signal Sizing',
    description: 'Convert alpha signals into optimal position sizes',
    category: 'finance',
    icon: 'Activity',
    defaultSolver: 'ipopt',
    problemType: 'QP',
    fields: [
      { name: 'strategy', label: 'Strategy', type: 'select', required: true, default: 'mean_risk', options: [
        { value: 'mean_risk', label: 'Mean-Risk' },
        { value: 'equal_risk', label: 'Equal Risk' },
        { value: 'kelly', label: 'Kelly' },
        { value: 'fixed_risk', label: 'Fixed Risk' },
      ]},
      { name: 'signals', label: 'Signals', type: 'map', required: true, description: 'Symbol → alpha/score' },
      { name: 'symbols', label: 'Symbols', type: 'array', required: false, description: 'Ordered asset list' },
      { name: 'covariance_matrix', label: 'Covariance Matrix', type: 'matrix', required: false },
      { name: 'max_notional', label: 'Max Notional', type: 'number', required: false },
      { name: 'max_position', label: 'Max Position', type: 'number', required: false, min: 0, max: 1, step: 0.01 },
      { name: 'max_gross_exposure', label: 'Max Gross Exposure', type: 'number', required: false, min: 0, step: 0.01 },
      { name: 'max_net_exposure', label: 'Max Net Exposure', type: 'number', required: false, min: 0, step: 0.01 },
      { name: 'risk_aversion', label: 'Risk Aversion', type: 'number', required: false, default: 1.0, step: 0.1 },
      { name: 'target_volatility', label: 'Target Volatility', type: 'number', required: false, step: 0.01, description: 'For fixed_risk' },
      { name: 'prices', label: 'Prices', type: 'map', required: false, description: 'Symbol → price' },
    ],
    examples: {
      strategy: 'mean_risk',
      signals: { AAPL: 0.02, GOOGL: -0.01, MSFT: 0.015 },
      symbols: ['AAPL', 'GOOGL', 'MSFT'],
      risk_aversion: 2.0,
      max_gross_exposure: 1.0,
      max_position: 0.3,
    },
  },

  rebalance: {
    id: 'rebalance',
    name: 'Rebalance',
    description: 'Optimal trade list from current to target weights',
    category: 'finance',
    icon: 'GitBranch',
    defaultSolver: 'highs',
    problemType: 'QP',
    fields: [
      { name: 'strategy', label: 'Strategy', type: 'select', required: true, default: 'min_deviation', options: [
        { value: 'min_deviation', label: 'Min Deviation' },
        { value: 'min_cost', label: 'Min Cost' },
        { value: 'min_impact', label: 'Min Impact' },
      ]},
      { name: 'current_weights', label: 'Current Weights', type: 'map', required: true, description: 'Symbol → weight' },
      { name: 'target_weights', label: 'Target Weights', type: 'map', required: true, description: 'Symbol → weight' },
      { name: 'symbols', label: 'Symbols', type: 'array', required: false },
      { name: 'max_turnover', label: 'Max Turnover', type: 'number', required: false, min: 0, max: 1, step: 0.01 },
      { name: 'max_tracking_error', label: 'Max Tracking Error', type: 'number', required: false, step: 0.01 },
      { name: 'transaction_costs', label: 'Transaction Costs', type: 'map', required: false, description: 'Per-asset cost or scalar (bps)' },
      { name: 'adv', label: 'ADV', type: 'map', required: false, description: 'Symbol → average daily volume' },
      { name: 'max_participation', label: 'Max Participation', type: 'number', required: false, min: 0, max: 1, step: 0.01 },
      { name: 'covariance_matrix', label: 'Covariance Matrix', type: 'matrix', required: false },
      { name: 'lot_size', label: 'Lot Size', type: 'number', required: false, min: 1 },
      { name: 'prices', label: 'Prices', type: 'map', required: false },
      { name: 'portfolio_value', label: 'Portfolio Value', type: 'number', required: false, min: 0 },
    ],
    examples: {
      strategy: 'min_deviation',
      current_weights: { AAPL: 0.30, MSFT: 0.20, GOOGL: 0.50 },
      target_weights: { AAPL: 0.25, MSFT: 0.25, GOOGL: 0.50 },
      symbols: ['AAPL', 'MSFT', 'GOOGL'],
      max_turnover: 0.15,
    },
  },

  risk_budget: {
    id: 'risk_budget',
    name: 'Risk Budget',
    description: 'Check, reduce, or allocate risk across assets and factors',
    category: 'finance',
    icon: 'Shield',
    defaultSolver: 'ipopt',
    problemType: 'QP',
    fields: [
      { name: 'strategy', label: 'Strategy', type: 'select', required: true, default: 'reduce', options: [
        { value: 'check', label: 'Check' },
        { value: 'reduce', label: 'Reduce' },
        { value: 'allocate', label: 'Allocate' },
      ]},
      { name: 'current_weights', label: 'Current Weights', type: 'map', required: true },
      { name: 'covariance_matrix', label: 'Covariance Matrix', type: 'matrix', required: false },
      { name: 'symbols', label: 'Symbols', type: 'array', required: false },
      { name: 'max_volatility', label: 'Max Volatility', type: 'number', required: false, step: 0.01 },
      { name: 'max_cvar', label: 'Max CVaR', type: 'number', required: false, step: 0.01 },
      { name: 'max_drawdown', label: 'Max Drawdown', type: 'number', required: false, step: 0.01 },
      { name: 'max_sector_weight', label: 'Max Sector Weight', type: 'map', required: false },
      { name: 'max_concentration', label: 'Max Concentration', type: 'number', required: false, min: 0, max: 1, step: 0.01 },
      { name: 'asset_sectors', label: 'Asset Sectors', type: 'map', required: false },
      { name: 'factor_loadings', label: 'Factor Loadings', type: 'matrix', required: false },
      { name: 'factor_names', label: 'Factor Names', type: 'array', required: false },
      { name: 'max_factor_exposure', label: 'Max Factor Exposure', type: 'map', required: false },
      { name: 'min_change', label: 'Minimize Change', type: 'select', required: false, default: 'true', options: [{ value: 'true', label: 'Yes' }, { value: 'false', label: 'No' }]},
      { name: 'returns', label: 'Historical Returns', type: 'matrix', required: false, description: 'For CVaR' },
      { name: 'confidence_level', label: 'Confidence Level', type: 'number', required: false, default: 0.05, min: 0.01, max: 0.5, step: 0.01 },
    ],
    examples: {
      strategy: 'reduce',
      current_weights: { AAPL: 0.40, GOOGL: 0.35, MSFT: 0.25 },
      symbols: ['AAPL', 'GOOGL', 'MSFT'],
      max_volatility: 0.15,
      max_concentration: 0.35,
    },
  },

  multi_account: {
    id: 'multi_account',
    name: 'Multi-Account',
    description: 'Allocate across accounts with per-account constraints',
    category: 'finance',
    icon: 'Users',
    defaultSolver: 'ipopt',
    problemType: 'QP',
    fields: [
      { name: 'strategy', label: 'Strategy', type: 'select', required: true, default: 'joint', options: [
        { value: 'independent', label: 'Independent' },
        { value: 'joint', label: 'Joint' },
        { value: 'cascade', label: 'Cascade' },
      ]},
      { name: 'accounts', label: 'Accounts', type: 'json', required: true, description: 'Array of { name, min_weight, max_weight, max_turnover, excluded_symbols, max_volatility, target_weights }' },
      { name: 'expected_returns', label: 'Expected Returns', type: 'array', required: false },
      { name: 'covariance_matrix', label: 'Covariance Matrix', type: 'matrix', required: false },
      { name: 'symbols', label: 'Symbols', type: 'array', required: false },
      { name: 'objective', label: 'Objective', type: 'text', required: false, default: 'min_volatility', description: 'e.g. min_volatility, max_sharpe' },
      { name: 'account_values', label: 'Account Values', type: 'map', required: false, description: 'Account → AUM' },
      { name: 'current_weights', label: 'Current Weights', type: 'json', required: false, description: 'Account → { symbol: weight }' },
    ],
    examples: {
      strategy: 'joint',
      accounts: [
        { name: 'aggressive', max_weight: 0.40 },
        { name: 'conservative', max_weight: 0.15 },
      ],
      symbols: ['AAPL', 'MSFT', 'GOOGL'],
      objective: 'min_volatility',
    },
  },
};

// =============================================================================
// Category Definitions
// =============================================================================

export const CATEGORIES: Record<TemplateCategory, { name: string; description: string; icon: string }> = {
  mathematical: {
    name: 'Mathematical Programming',
    description: 'LP, MIP, and QP problems',
    icon: 'Calculator',
  },
  combinatorial: {
    name: 'Combinatorial Optimization',
    description: 'Discrete decision problems',
    icon: 'Layers',
  },
  network: {
    name: 'Network Flow',
    description: 'Flow and routing problems',
    icon: 'GitBranch',
  },
  scheduling: {
    name: 'Scheduling',
    description: 'Job and resource scheduling',
    icon: 'Calendar',
  },
  finance: {
    name: 'Finance',
    description: 'Portfolio and risk optimization',
    icon: 'TrendingUp',
  },
};

// =============================================================================
// Helper Functions
// =============================================================================

export function getTemplatesByCategory(category: TemplateCategory): TemplateConfig[] {
  return Object.values(TEMPLATES).filter(t => t.category === category);
}

export function getTemplate(id: string): TemplateConfig | undefined {
  return TEMPLATES[id];
}

export function getAllTemplates(): TemplateConfig[] {
  return Object.values(TEMPLATES);
}
