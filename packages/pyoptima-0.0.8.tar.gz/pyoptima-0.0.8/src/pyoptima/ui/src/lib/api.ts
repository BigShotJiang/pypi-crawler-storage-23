/**
 * API client for PyOptima API
 * 
 * Provides typed functions for interacting with the PyOptima API.
 * Handles errors, loading states, and response parsing.
 */

import type {
  OptimizeRequest,
  OptimizeResponse,
  AsyncJobResponse,
  JobResponse,
  JobStatus,
  TemplateInfo,
  TemplatesListResponse,
  SolverInfo,
  SolversListResponse,
  ValidationResponse,
  BatchOptimizeResponse,
  HealthResponse,
} from './types';
import { getApiBaseUrl } from './settings';

export class ApiError extends Error {
  constructor(
    message: string,
    public status: number,
    public response?: any
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

/**
 * Base fetch wrapper with error handling
 */
async function fetchApi<T>(
  endpoint: string,
  options?: RequestInit
): Promise<T> {
  const url = `${getApiBaseUrl()}${endpoint}`;
  
  try {
    const response = await fetch(url, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...options?.headers,
      },
    });

    if (!response.ok) {
      let errorData;
      try {
        errorData = await response.json();
      } catch {
        errorData = { detail: response.statusText };
      }
      
      // Handle validation errors (422) with detailed messages
      let errorMessage = errorData.detail || errorData.message || `API request failed: ${response.statusText}`;
      if (response.status === 422 && errorData.details && Array.isArray(errorData.details)) {
        // Format validation errors into a readable message
        const validationErrors = errorData.details.map((err: any) => {
          const field = err.loc?.join('.') || err.field || 'field';
          const msg = err.msg || err.message || 'validation error';
          return `${field}: ${msg}`;
        }).join('; ');
        errorMessage = validationErrors || errorMessage;
      }
      
      throw new ApiError(
        errorMessage,
        response.status,
        errorData
      );
    }

    // Handle empty responses
    const contentType = response.headers.get('content-type');
    if (contentType && contentType.includes('application/json')) {
      return response.json();
    }
    
    return response.text() as unknown as T;
  } catch (error) {
    // Handle network errors (API server not reachable, CORS, etc.)
    if (error instanceof TypeError && (error.message === 'Failed to fetch' || error.message.includes('fetch'))) {
      const apiUrl = getApiBaseUrl();
      const port = apiUrl.match(/:(\d+)/)?.[1] || '8003';
      throw new ApiError(
        `Unable to connect to API server at ${apiUrl}. Please ensure the API server is running and the URL is correct.`,
        0,
        { 
          originalError: 'NetworkError',
          apiUrl,
          endpoint,
          suggestions: [
            `Start the API server: pyoptima api --port ${port}`,
            'Or update the API URL in Settings if your server is on a different port',
            `Check if API is running: curl ${apiUrl}/health`,
          ]
        }
      );
    }
    // Re-throw other errors (including ApiError)
    throw error;
  }
}

/**
 * GET request
 */
export async function get<T>(endpoint: string): Promise<T> {
  return fetchApi<T>(endpoint, { method: 'GET' });
}

/**
 * POST request
 */
export async function post<T>(endpoint: string, data?: any): Promise<T> {
  return fetchApi<T>(endpoint, {
    method: 'POST',
    body: data ? JSON.stringify(data) : undefined,
  });
}

/**
 * DELETE request
 */
export async function del<T>(endpoint: string): Promise<T> {
  return fetchApi<T>(endpoint, { method: 'DELETE' });
}

// API endpoint helpers
export const api = {
  // Optimization
  optimize: (request: OptimizeRequest): Promise<OptimizeResponse> =>
    post<OptimizeResponse>('/api/v1/optimize', request),
  
  optimizeAsync: (request: OptimizeRequest): Promise<AsyncJobResponse> =>
    post<AsyncJobResponse>('/api/v1/optimize/async', request),
  
  validate: (request: { template: string; data: Record<string, any> }): Promise<ValidationResponse> =>
    post<ValidationResponse>('/api/v1/optimize/validate', request),
  
  batchOptimize: (requests: OptimizeRequest[]): Promise<BatchOptimizeResponse> =>
    post<BatchOptimizeResponse>('/api/v1/optimize/batch', { requests }),

  // Jobs
  listJobs: (status?: JobStatus, limit?: number, offset?: number): Promise<JobResponse[]> => {
    const params = new URLSearchParams();
    if (status) params.append('status', status);
    if (limit) params.append('limit', limit.toString());
    if (offset) params.append('offset', offset.toString());
    const query = params.toString();
    return get<JobResponse[]>(`/api/v1/jobs${query ? `?${query}` : ''}`);
  },
  
  getJob: (jobId: string): Promise<JobResponse> =>
    get<JobResponse>(`/api/v1/jobs/${jobId}`),
  
  deleteJob: (jobId: string): Promise<void> =>
    del<void>(`/api/v1/jobs/${jobId}`),
  
  cancelJob: (jobId: string): Promise<void> =>
    post<void>(`/api/v1/jobs/${jobId}/cancel`),
  
  getJobStats: (): Promise<Record<string, number>> =>
    get<Record<string, number>>('/api/v1/jobs/stats'),

  // Templates
  listTemplates: (): Promise<TemplatesListResponse> =>
    get<TemplatesListResponse>('/api/v1/templates'),
  
  getTemplate: (templateName: string): Promise<TemplateInfo> =>
    get<TemplateInfo>(`/api/v1/templates/${templateName}`),

  // Solvers
  listSolvers: (): Promise<SolversListResponse> =>
    get<SolversListResponse>('/api/v1/solvers'),
  
  getSolver: (solverName: string): Promise<SolverInfo> =>
    get<SolverInfo>(`/api/v1/solvers/${solverName}`),

  // Health
  health: (): Promise<HealthResponse> =>
    get<HealthResponse>('/health'),
};
