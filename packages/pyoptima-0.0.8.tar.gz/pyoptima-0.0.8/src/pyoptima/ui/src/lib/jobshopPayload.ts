/**
 * Builds the API payload for the jobshop template.
 * Converts UI data (machine names, custom_constraints) to backend format
 * (machine indices, num_machines, horizon, custom_constraints).
 */

export function buildJobShopPayload(data: Record<string, unknown>): Record<string, unknown> {
  const machines = Array.isArray(data.machines) ? (data.machines as string[]).map(String).filter(Boolean) : [];
  const num_machines = machines.length || 1;
  const machineToIndex: Record<string, number> = {};
  machines.forEach((m, i) => {
    machineToIndex[m] = i;
  });

  const rawJobs = data.jobs;
  if (!Array.isArray(rawJobs) || rawJobs.length === 0) {
    return { jobs: [], num_machines, ...(data.horizon != null && data.horizon !== '' ? { horizon: Number(data.horizon) } : {}), custom_constraints: data.custom_constraints ?? [] };
  }

  const jobs = rawJobs.map((j: unknown) => {
    if (!j || typeof j !== 'object' || !('operations' in j)) return { name: 'Job', operations: [] };
    const job = j as { name?: unknown; operations?: unknown[] };
    const operations = Array.isArray(job.operations)
      ? job.operations.map((o: unknown) => {
          if (!o || typeof o !== 'object' || !('machine' in o) || !('duration' in o))
            return { machine: 0, duration: 1 };
          const op = o as { machine: unknown; duration: unknown };
          const machineVal = op.machine;
          const machineIndex =
            typeof machineVal === 'number'
              ? machineVal
              : machineToIndex[String(machineVal)] ?? 0;
          return {
            machine: machineIndex,
            duration: Number(op.duration) || 1,
          };
        })
      : [];
    return { name: job.name ?? 'Job', operations };
  });

  const horizon =
    data.horizon != null && data.horizon !== '' && Number(data.horizon) > 0
      ? Number(data.horizon)
      : undefined;

  const custom_constraints = Array.isArray(data.custom_constraints) ? data.custom_constraints : [];

  return {
    jobs,
    num_machines,
    ...(horizon != null ? { horizon } : {}),
    ...(custom_constraints.length > 0 ? { custom_constraints } : {}),
  };
}
