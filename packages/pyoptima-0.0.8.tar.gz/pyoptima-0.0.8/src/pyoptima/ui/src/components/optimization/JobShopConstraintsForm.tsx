'use client';

import { useCallback } from 'react';
import { Plus, Trash2, Calendar, Clock, Layers, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

export type JobShopConstraintType =
  | 'deadline'
  | 'release_time'
  | 'time_window'
  | 'job_priority'
  | 'sequence';

export interface JobShopConstraintBase {
  type: JobShopConstraintType;
}

export interface DeadlineConstraint extends JobShopConstraintBase {
  type: 'deadline';
  job: number;
  operation: number;
  deadline: number;
}

export interface ReleaseTimeConstraint extends JobShopConstraintBase {
  type: 'release_time';
  job: number;
  operation: number;
  release_time: number;
}

export interface TimeWindowConstraint extends JobShopConstraintBase {
  type: 'time_window';
  job: number;
  operation: number;
  earliest: number;
  latest: number;
}

export interface JobPriorityConstraint extends JobShopConstraintBase {
  type: 'job_priority';
  job: number;
  must_finish_before: number;
}

export interface SequenceConstraint extends JobShopConstraintBase {
  type: 'sequence';
  job: number;
  operations: number[];
  max_gap?: number;
}

export type JobShopConstraint =
  | DeadlineConstraint
  | ReleaseTimeConstraint
  | TimeWindowConstraint
  | JobPriorityConstraint
  | SequenceConstraint;

function ensureJobs(data: Record<string, unknown>): { name: string; operations: unknown[] }[] {
  const raw = data.jobs;
  if (Array.isArray(raw) && raw.length > 0) {
    return raw.map((j: unknown) => {
      if (j && typeof j === 'object' && 'name' in j && 'operations' in j) {
        const ops = Array.isArray((j as { operations: unknown }).operations)
          ? (j as { operations: unknown[] }).operations
          : [];
        return { name: String((j as { name: unknown }).name), operations: ops };
      }
      return { name: 'Job', operations: [] };
    });
  }
  return [];
}

function ensureCustomConstraints(data: Record<string, unknown>): JobShopConstraint[] {
  const raw = data.custom_constraints;
  if (!Array.isArray(raw)) return [];
  return raw.filter((c): c is JobShopConstraint => c != null && typeof c === 'object' && 'type' in c) as JobShopConstraint[];
}

interface JobShopConstraintsFormProps {
  data: Record<string, unknown>;
  onChange: (data: Record<string, unknown>) => void;
}

const CONSTRAINT_TYPES: { value: JobShopConstraintType; label: string; icon: typeof Clock }[] = [
  { value: 'deadline', label: 'Deadline (finish by time)', icon: Calendar },
  { value: 'release_time', label: 'Release time (start after time)', icon: Clock },
  { value: 'time_window', label: 'Time window (start between earliest–latest)', icon: Clock },
  { value: 'job_priority', label: 'Job priority (Job A must finish before Job B)', icon: ArrowRight },
  { value: 'sequence', label: 'Sequence (max gap between operations)', icon: Layers },
];

function defaultConstraint(type: JobShopConstraintType, jobCount: number): JobShopConstraint {
  switch (type) {
    case 'deadline':
      return { type: 'deadline', job: 0, operation: 0, deadline: 100 };
    case 'release_time':
      return { type: 'release_time', job: 0, operation: 0, release_time: 0 };
    case 'time_window':
      return { type: 'time_window', job: 0, operation: 0, earliest: 0, latest: 200 };
    case 'job_priority':
      return { type: 'job_priority', job: 0, must_finish_before: Math.min(1, jobCount - 1) };
    case 'sequence':
      return { type: 'sequence', job: 0, operations: [0, 1], max_gap: 10 };
    default:
      return { type: 'deadline', job: 0, operation: 0, deadline: 100 };
  }
}

export function JobShopConstraintsForm({ data, onChange }: JobShopConstraintsFormProps) {
  const jobs = ensureJobs(data);
  const constraints = ensureCustomConstraints(data);

  const updateConstraints = useCallback(
    (next: JobShopConstraint[]) => {
      onChange({ ...data, custom_constraints: next });
    },
    [data, onChange]
  );

  const addConstraint = useCallback(
    (type: JobShopConstraintType) => {
      const c = defaultConstraint(type, jobs.length);
      updateConstraints([...constraints, c]);
    },
    [constraints, jobs.length, updateConstraints]
  );

  const removeConstraint = useCallback(
    (index: number) => {
      updateConstraints(constraints.filter((_, i) => i !== index));
    },
    [constraints, updateConstraints]
  );

  const setConstraint = useCallback(
    (index: number, c: JobShopConstraint) => {
      const next = [...constraints];
      next[index] = c;
      updateConstraints(next);
    },
    [constraints, updateConstraints]
  );

  if (jobs.length === 0) {
    return (
      <Card className="bg-slate-50 border-slate-200">
        <div className="p-4">
          <p className="text-sm text-slate-600">
            Define jobs and operations in the <strong>Assets & Data</strong> tab first. Then you can add constraints here.
          </p>
        </div>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-sm font-semibold text-slate-800 mb-1">Add constraint</h3>
        <p className="text-xs text-slate-500 mb-3">
          Precedence is already enforced by the order of operations in each job. Add optional deadlines, release times, time windows, job priorities, or sequence gaps.
        </p>
        <div className="flex flex-wrap gap-2">
          {CONSTRAINT_TYPES.map(({ value, label, icon: Icon }) => (
            <Button
              key={value}
              type="button"
              variant="outline"
              size="sm"
              onClick={() => addConstraint(value)}
            >
              <Icon className="w-3.5 h-3.5 mr-1.5" />
              {label}
            </Button>
          ))}
        </div>
      </div>

      {constraints.length === 0 ? (
        <Card className="bg-slate-50 border-slate-200">
          <div className="p-4">
            <p className="text-sm text-slate-600">No constraints added yet. Use the buttons above to add one.</p>
          </div>
        </Card>
      ) : (
        <div className="space-y-3">
          <h3 className="text-sm font-semibold text-slate-800">Active constraints</h3>
          {constraints.map((c, index) => (
            <Card key={index} className="p-4 border-slate-200">
              <div className="flex flex-wrap items-start gap-3">
                <ConstraintEditor
                  constraint={c}
                  jobs={jobs}
                  onChange={(updated) => setConstraint(index, updated)}
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => removeConstraint(index)}
                  className="text-slate-500 hover:text-red-600 shrink-0"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

function ConstraintEditor({
  constraint,
  jobs,
  onChange,
}: {
  constraint: JobShopConstraint;
  jobs: { name: string; operations: unknown[] }[];
  onChange: (c: JobShopConstraint) => void;
}) {
  const numOps = jobs[constraint.job]?.operations?.length ?? 0;
  const jobOptions = jobs.map((j, i) => ({ value: i, label: j.name || `Job ${i}` }));

  if (constraint.type === 'deadline') {
    return (
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-xs font-medium text-slate-600">Deadline:</span>
        <select
          value={constraint.job}
          onChange={(e) => onChange({ ...constraint, job: parseInt(e.target.value, 10) })}
          className="p-2 bg-white border border-slate-300 rounded text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
        >
          {jobOptions.map((o) => (
            <option key={o.value} value={o.value}>{o.label}</option>
          ))}
        </select>
        <select
          value={constraint.operation}
          onChange={(e) => onChange({ ...constraint, operation: parseInt(e.target.value, 10) })}
          className="p-2 bg-white border border-slate-300 rounded text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
        >
          {Array.from({ length: numOps }, (_, i) => (
            <option key={i} value={i}>Op {i + 1}</option>
          ))}
        </select>
        <span className="text-slate-500 text-sm">finish by</span>
        <input
          type="number"
          value={constraint.deadline}
          onChange={(e) => onChange({ ...constraint, deadline: Number(e.target.value) || 0 })}
          min={0}
          className="w-24 p-2 bg-white border border-slate-300 rounded text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
        />
      </div>
    );
  }

  if (constraint.type === 'release_time') {
    return (
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-xs font-medium text-slate-600">Release:</span>
        <select
          value={constraint.job}
          onChange={(e) => onChange({ ...constraint, job: parseInt(e.target.value, 10) })}
          className="p-2 bg-white border border-slate-300 rounded text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
        >
          {jobOptions.map((o) => (
            <option key={o.value} value={o.value}>{o.label}</option>
          ))}
        </select>
        <select
          value={constraint.operation}
          onChange={(e) => onChange({ ...constraint, operation: parseInt(e.target.value, 10) })}
          className="p-2 bg-white border border-slate-300 rounded text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
        >
          {Array.from({ length: numOps }, (_, i) => (
            <option key={i} value={i}>Op {i + 1}</option>
          ))}
        </select>
        <span className="text-slate-500 text-sm">start after</span>
        <input
          type="number"
          value={constraint.release_time}
          onChange={(e) => onChange({ ...constraint, release_time: Number(e.target.value) || 0 })}
          min={0}
          className="w-24 p-2 bg-white border border-slate-300 rounded text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
        />
      </div>
    );
  }

  if (constraint.type === 'time_window') {
    return (
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-xs font-medium text-slate-600">Window:</span>
        <select
          value={constraint.job}
          onChange={(e) => onChange({ ...constraint, job: parseInt(e.target.value, 10) })}
          className="p-2 bg-white border border-slate-300 rounded text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
        >
          {jobOptions.map((o) => (
            <option key={o.value} value={o.value}>{o.label}</option>
          ))}
        </select>
        <select
          value={constraint.operation}
          onChange={(e) => onChange({ ...constraint, operation: parseInt(e.target.value, 10) })}
          className="p-2 bg-white border border-slate-300 rounded text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
        >
          {Array.from({ length: numOps }, (_, i) => (
            <option key={i} value={i}>Op {i + 1}</option>
          ))}
        </select>
        <input
          type="number"
          value={constraint.earliest}
          onChange={(e) => onChange({ ...constraint, earliest: Number(e.target.value) || 0 })}
          min={0}
          placeholder="Earliest"
          className="w-24 p-2 bg-white border border-slate-300 rounded text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
        />
        <span className="text-slate-500 text-sm">–</span>
        <input
          type="number"
          value={constraint.latest}
          onChange={(e) => onChange({ ...constraint, latest: Number(e.target.value) || 0 })}
          min={0}
          placeholder="Latest"
          className="w-24 p-2 bg-white border border-slate-300 rounded text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
        />
      </div>
    );
  }

  if (constraint.type === 'job_priority') {
    const otherJobs = jobOptions.filter((o) => o.value !== constraint.job);
    return (
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-xs font-medium text-slate-600">Priority:</span>
        <select
          value={constraint.job}
          onChange={(e) => onChange({ ...constraint, job: parseInt(e.target.value, 10) })}
          className="p-2 bg-white border border-slate-300 rounded text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
        >
          {jobOptions.map((o) => (
            <option key={o.value} value={o.value}>{o.label}</option>
          ))}
        </select>
        <span className="text-slate-500 text-sm">must finish before</span>
        {otherJobs.length > 0 ? (
          <select
            value={constraint.must_finish_before}
            onChange={(e) => onChange({ ...constraint, must_finish_before: parseInt(e.target.value, 10) })}
            className="p-2 bg-white border border-slate-300 rounded text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
          >
            {otherJobs.map((o) => (
              <option key={o.value} value={o.value}>{o.label}</option>
            ))}
          </select>
        ) : (
          <span className="text-xs text-amber-600">Add at least 2 jobs</span>
        )}
      </div>
    );
  }

  if (constraint.type === 'sequence') {
    const opIndices = constraint.operations.length ? constraint.operations : [0];
    return (
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-xs font-medium text-slate-600">Sequence:</span>
        <select
          value={constraint.job}
          onChange={(e) => onChange({ ...constraint, job: parseInt(e.target.value, 10) })}
          className="p-2 bg-white border border-slate-300 rounded text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
        >
          {jobOptions.map((o) => (
            <option key={o.value} value={o.value}>{o.label}</option>
          ))}
        </select>
        <span className="text-slate-500 text-sm">ops</span>
        <input
          type="text"
          value={opIndices.join(', ')}
          onChange={(e) => {
            const vals = e.target.value.split(',').map((s) => parseInt(s.trim(), 10)).filter((n) => !Number.isNaN(n));
            onChange({ ...constraint, operations: vals.length ? vals : [0] });
          }}
          placeholder="0, 1, 2"
          className="w-28 p-2 bg-white border border-slate-300 rounded text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
        />
        <span className="text-slate-500 text-sm">max gap</span>
        <input
          type="number"
          value={constraint.max_gap ?? ''}
          onChange={(e) => onChange({ ...constraint, max_gap: e.target.value === '' ? undefined : Number(e.target.value) })}
          min={0}
          placeholder="optional"
          className="w-24 p-2 bg-white border border-slate-300 rounded text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
        />
      </div>
    );
  }

  return null;
}
