'use client';

import { AlertCircle, Settings, ExternalLink } from 'lucide-react';
import Link from 'next/link';
import { ApiError } from '@/lib/api';
import { getApiBaseUrl } from '@/lib/settings';
import { cn } from '@/lib/utils';

interface ErrorDisplayProps {
  error: Error | ApiError | null;
  title?: string;
  className?: string;
  showApiHelp?: boolean;
}

export default function ErrorDisplay({ error, title = 'Error', className, showApiHelp }: ErrorDisplayProps) {
  if (!error) return null;

  const isApiError = error instanceof ApiError;
  const message = isApiError
    ? error.message
    : error.message || 'An unexpected error occurred';
  
  const isConnectionError = message.includes('Unable to connect to API server') || 
                           message.includes('Failed to fetch') ||
                           (isApiError && error.status === 0);
  
  const apiUrl = isConnectionError ? getApiBaseUrl() : null;

  return (
    <div
      className={cn(
        'rounded-lg border border-destructive/50 bg-destructive/10 p-4',
        className
      )}
    >
      <div className="flex">
        <AlertCircle className="h-5 w-5 text-destructive flex-shrink-0 mt-0.5" />
        <div className="ml-3 flex-1">
          <h3 className="text-sm font-medium text-destructive">{title}</h3>
          <div className="mt-2 text-sm text-destructive/90">
            <p>{message}</p>
            {isApiError && error.status && error.status > 0 && (
              <p className="mt-1 text-xs opacity-75">Status: {error.status}</p>
            )}
            
            {/* Connection Error Help */}
            {isConnectionError && (
              <div className="mt-4 p-3 bg-white/50 rounded border border-destructive/20">
                <p className="text-xs font-medium text-slate-700 mb-2">To fix this:</p>
                <ol className="text-xs text-slate-600 space-y-1.5 list-decimal list-inside">
                  <li>
                    <strong>Start the API server:</strong>
                    <code className="ml-1 px-1.5 py-0.5 bg-slate-100 rounded text-xs font-mono">
                      pyoptima api --port {apiUrl?.match(/:(\d+)/)?.[1] || '8003'}
                    </code>
                  </li>
                  <li>
                    <strong>Or update the API URL</strong> if your server is running on a different port
                  </li>
                  <li>
                    <strong>Check the API is running:</strong>
                    <code className="ml-1 px-1.5 py-0.5 bg-slate-100 rounded text-xs font-mono">
                      curl {apiUrl}/health
                    </code>
                  </li>
                </ol>
                <div className="mt-3 pt-3 border-t border-destructive/20">
                  <Link 
                    href="/settings"
                    className="inline-flex items-center gap-1.5 text-xs text-indigo-600 hover:text-indigo-700 font-medium"
                  >
                    <Settings className="w-3.5 h-3.5" />
                    Go to Settings to change API URL
                    <ExternalLink className="w-3 h-3" />
                  </Link>
                </div>
                {apiUrl && (
                  <p className="mt-2 text-xs text-slate-500">
                    Current API URL: <code className="px-1 py-0.5 bg-slate-100 rounded">{apiUrl}</code>
                  </p>
                )}
              </div>
            )}
            
            {/* Show suggestions from ApiError if available */}
            {isApiError && error.response?.suggestions && (
              <div className="mt-3 p-3 bg-white/50 rounded border border-destructive/20">
                <p className="text-xs font-medium text-slate-700 mb-2">Suggestions:</p>
                <ul className="text-xs text-slate-600 space-y-1 list-disc list-inside">
                  {error.response.suggestions.map((suggestion: string, i: number) => (
                    <li key={i}>{suggestion}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
