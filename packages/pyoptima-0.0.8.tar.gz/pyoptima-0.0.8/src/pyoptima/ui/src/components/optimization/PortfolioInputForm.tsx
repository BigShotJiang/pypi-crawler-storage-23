'use client';

import { useState, useMemo, useCallback, useRef, useEffect } from 'react';
import { HelpCircle, Info, TrendingUp, Shield, Settings, BarChart3, Upload, FileSpreadsheet, PieChart, Plus, Trash2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import { parsePortfolioJson, parsePortfolioCsv } from '@/lib/portfolioParser';
import type { FieldConfig } from '@/lib/types';
import type { OptimizationTab } from './OptimizationTabBar';

interface PortfolioInputFormProps {
  fields: FieldConfig[];
  data: Record<string, unknown>;
  onChange: (data: Record<string, unknown>) => void;
  /** When set, only the section for this tab is shown (Assets & Data / Objective / Constraint). */
  activeTab?: OptimizationTab;
}

// Group fields by category
const FIELD_GROUPS = {
  basic: ['expected_returns', 'covariance_matrix', 'symbols'],
  objective: ['objective'],
  parameters: ['risk_free_rate', 'target_return', 'target_volatility', 'risk_aversion',
               'confidence_level', 'benchmark', 'target_cvar', 'target_cdar', 'target_semivariance', 'min_net_return'],
  blackLitterman: ['market_caps', 'views', 'view_cov', 'tau'],
  historical: ['returns'],
  constraints: ['min_weight', 'max_weight', 'weight_bounds', 'max_assets', 'min_position_size', 'current_weights', 'max_turnover', 'per_asset_bounds', 'sector_caps', 'sector_mins', 'asset_sectors'],
  costs: ['transaction_costs'],
  momentum: ['momentum_period', 'momentum_top_pct'],
  factors: ['factor_data', 'factor_weights'],
  liquidity: ['adv', 'max_days_to_liquidate', 'participation_rate', 'portfolio_value', 'max_participation', 'spreads', 'max_cost_bps'],
  riskLimits: ['max_volatility', 'max_concentration', 'concentration_top_k', 'max_tracking_error', 'benchmark_weights'],
};

// Objectives that require historical returns
const REQUIRES_RETURNS = ['min_cvar', 'efficient_cvar_risk', 'efficient_cvar_return', 
                          'min_cdar', 'efficient_cdar_risk', 'efficient_cdar_return',
                          'min_semivariance', 'efficient_semivariance_risk', 'efficient_semivariance_return',
                          'momentum_filtered_max_sharpe', 'momentum_filtered_min_volatility'];

// Objectives that require Black-Litterman data
const REQUIRES_BL = ['black_litterman_max_sharpe', 'black_litterman_min_volatility', 'black_litterman_quadratic_utility'];

// Objectives that require target return
const REQUIRES_TARGET_RETURN = ['efficient_return', 'efficient_cvar_return', 'efficient_cdar_return', 'efficient_semivariance_return'];

// Objectives that require target risk
const REQUIRES_TARGET_RISK = ['efficient_risk', 'efficient_cvar_risk', 'efficient_cdar_risk', 'efficient_semivariance_risk'];

// Objectives that require transaction costs
const REQUIRES_COSTS = ['max_sharpe_with_costs', 'min_volatility_with_costs'];

// Objectives that have limited constraint support (only basic weight bounds)
const LIMITED_CONSTRAINTS = ['cla_min_volatility', 'cla_max_sharpe'];

// Objectives that support NO constraints (hierarchical methods ignore all constraints)
const NO_CONSTRAINTS = ['hierarchical_min_volatility', 'hierarchical_max_sharpe'];

// Objective dropdown groups (for optgroup labels)
const OBJECTIVE_GROUPS: { label: string; values: string[] }[] = [
  { label: 'Mean–variance', values: ['min_volatility', 'max_sharpe', 'max_return', 'efficient_return', 'efficient_risk', 'max_utility'] },
  { label: 'Black–Litterman', values: ['black_litterman_max_sharpe', 'black_litterman_min_volatility', 'black_litterman_quadratic_utility'] },
  { label: 'CVaR / CDaR', values: ['min_cvar', 'efficient_cvar_risk', 'efficient_cvar_return', 'min_cdar', 'efficient_cdar_risk', 'efficient_cdar_return'] },
  { label: 'Semivariance', values: ['min_semivariance', 'efficient_semivariance_risk', 'efficient_semivariance_return'] },
  { label: 'CLA / Hierarchical', values: ['cla_min_volatility', 'cla_max_sharpe', 'hierarchical_min_volatility', 'hierarchical_max_sharpe'] },
  { label: 'Risk Parity', values: ['risk_parity', 'equal_risk_contribution'] },
  { label: 'Diversification', values: ['max_diversification', 'max_diversification_index'] },
  { label: 'Cost-Aware', values: ['max_sharpe_with_costs', 'min_volatility_with_costs'] },
  { label: 'Momentum-Filtered', values: ['momentum_filtered_max_sharpe', 'momentum_filtered_min_volatility'] },
  { label: 'Factor-Based', values: ['factor_based_selection'] },
];

// One-line hints for objective parameters
const PARAMETER_HINTS: Record<string, string> = {
  target_return: 'Target annual return, e.g. 0.08 for 8%.',
  target_volatility: 'Target annual volatility, e.g. 0.15 for 15%.',
  risk_free_rate: 'Risk-free rate for Sharpe (e.g. 0.02 for 2%).',
  confidence_level: 'Tail probability for CVaR/CDaR (e.g. 0.05 = 5%).',
  momentum_period: 'Lookback period for momentum (e.g. 20 days).',
  momentum_top_pct: 'Fraction of assets to keep by momentum (e.g. 0.2 = top 20%).',
  max_concentration: 'Max combined weight in top K assets (e.g. 0.6 = 60%).',
  concentration_top_k: 'Number of largest positions to limit.',
  max_tracking_error: 'Max tracking error vs benchmark (e.g. 0.02 = 2%).',
  max_volatility: 'Portfolio volatility cap (e.g. 0.20 = 20%).',
};

// Above this size, in-browser matrix grid edit is disabled; use upload instead.
const MAX_MATRIX_EDIT_IN_BROWSER = 20;
const LARGE_ASSET_COUNT = 15; // above this, show scroll hint and cap table height

export function PortfolioInputForm({ fields, data, onChange, activeTab }: PortfolioInputFormProps) {
  const [showHelp, setShowHelp] = useState<Record<string, boolean>>({});
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    basic: true,
    objective: true,
    parameters: true,
    advanced: false,
  });
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const [showCovarianceEditor, setShowCovarianceEditor] = useState(false);
  const [showFullCovarianceMatrix, setShowFullCovarianceMatrix] = useState(false);
  const [covarianceUploadError, setCovarianceUploadError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const covarianceFileInputRef = useRef<HTMLInputElement>(null);

  const objective = (data.objective as string) || 'min_volatility';

  const hasBasicData = useMemo(() => {
    const er = data.expected_returns;
    const cov = data.covariance_matrix;
    const sym = data.symbols;
    const nEr = Array.isArray(er) ? er.length : 0;
    const nCov = Array.isArray(cov) && cov[0] && Array.isArray(cov[0]) ? cov.length : 0;
    const nSym = Array.isArray(sym) ? sym.length : 0;
    return nEr > 0 || nCov > 0 || nSym > 0;
  }, [data.expected_returns, data.covariance_matrix, data.symbols]);

  const processFile = useCallback(
    (file: File) => {
      setUploadError(null);
      const reader = new FileReader();
      reader.onload = () => {
        const text = String(reader.result ?? '');
        const name = file.name.toLowerCase();
        try {
          if (name.endsWith('.json') || text.trimStart().startsWith('{')) {
            const parsed = parsePortfolioJson(text);
            onChange({
              ...data,
              expected_returns: parsed.expected_returns,
              covariance_matrix: parsed.covariance_matrix,
              symbols: parsed.symbols,
            });
          } else {
            const parsed = parsePortfolioCsv(text);
            onChange({
              ...data,
              expected_returns: parsed.expected_returns,
              symbols: parsed.symbols,
            });
          }
        } catch (err) {
          setUploadError(err instanceof Error ? err.message : 'Invalid format');
        }
      };
      reader.readAsText(file);
    },
    [data, onChange]
  );

  const handleFileUpload = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      e.target.value = '';
      if (file) processFile(file);
    },
    [processFile]
  );

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setDragOver(false);
      const file = e.dataTransfer?.files?.[0];
      if (file && (file.name.toLowerCase().endsWith('.json') || file.name.toLowerCase().endsWith('.csv'))) {
        processFile(file);
      } else if (file) {
        setUploadError('Please drop a JSON or CSV file.');
      }
    },
    [processFile]
  );
  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragOver(true);
  }, []);
  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragOver(false);
  }, []);

  const handleCovarianceOnlyUpload = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      e.target.value = '';
      if (!file) return;
      setCovarianceUploadError(null);
      const reader = new FileReader();
      reader.onload = () => {
        const text = String(reader.result ?? '').trim();
        const name = file.name.toLowerCase();
        try {
          if (name.endsWith('.csv') || (name.endsWith('.txt') && !text.startsWith('{'))) {
            const lines = text.split(/\r?\n/).filter(Boolean);
            const rows: number[][] = [];
            let skipFirst = false;
            for (let i = 0; i < lines.length; i++) {
              const cells = lines[i].split(',').map((c) => c.trim());
              const nums = cells.map((c) => parseFloat(c));
              const allNumeric = nums.every((n) => !Number.isNaN(n));
              if (i === 0 && !allNumeric) skipFirst = true;
              if (i === 0 && skipFirst) continue;
              if (allNumeric && nums.length > 0) rows.push(nums);
            }
            if (rows.length === 0 || rows[0].length === 0) {
              setCovarianceUploadError('CSV must contain numeric rows (comma-separated numbers).');
              return;
            }
            onChange({ ...data, covariance_matrix: rows });
          } else {
            const parsed = JSON.parse(text);
            const cov = parsed.covariance_matrix ?? parsed.covarianceMatrix;
            if (!Array.isArray(cov) || !cov[0] || !Array.isArray(cov[0])) {
              setCovarianceUploadError('JSON must contain covariance_matrix (2D array of numbers).');
              return;
            }
            onChange({ ...data, covariance_matrix: cov });
          }
        } catch {
          setCovarianceUploadError(name.endsWith('.csv') ? 'Invalid CSV.' : 'Invalid JSON.');
        }
      };
      reader.readAsText(file);
    },
    [data, onChange]
  );

  const formatPercent = (x: number) => `${(x * 100).toFixed(2)}%`;

  const symbolsArr = (Array.isArray(data.symbols) ? data.symbols : []) as string[];
  const expectedReturnsArr = (Array.isArray(data.expected_returns) ? data.expected_returns : []) as number[];
  const covMatrix = (Array.isArray(data.covariance_matrix) ? data.covariance_matrix : []) as number[][];
  const assetCount = Math.max(symbolsArr.length, expectedReturnsArr.length, covMatrix.length);

  const addAsset = useCallback(() => {
    const n = assetCount;
    const newSymbol = `A${n + 1}`;
    const newMu = 0.10;
    const newSymbols = [...symbolsArr];
    const newMuArr = [...expectedReturnsArr];
    const newCov = covMatrix.map(row => [...row]);
    while (newSymbols.length < n) newSymbols.push(`Asset${newSymbols.length + 1}`);
    while (newMuArr.length < n) newMuArr.push(0.10);
    while (newCov.length < n || (newCov[0] && newCov[0].length < n)) {
      if (newCov.length < n) newCov.push(new Array(n).fill(0));
      newCov.forEach((row) => { while (row.length < n) row.push(0); });
    }
    newSymbols.push(newSymbol);
    newMuArr.push(newMu);
    newCov.forEach((row) => row.push(0));
    newCov.push(new Array(n + 1).fill(0));
    newCov[n][n] = 0.04;
    onChange({ ...data, symbols: newSymbols, expected_returns: newMuArr, covariance_matrix: newCov });
  }, [data, assetCount, symbolsArr, expectedReturnsArr, covMatrix, onChange]);

  const removeAsset = useCallback((index: number) => {
    const newSymbols = symbolsArr.filter((_, i) => i !== index);
    const newMuArr = expectedReturnsArr.filter((_, i) => i !== index);
    const newCov = covMatrix.filter((_, i) => i !== index).map(row => row.filter((_, j) => j !== index));
    onChange({ ...data, symbols: newSymbols, expected_returns: newMuArr, covariance_matrix: newCov });
  }, [data, symbolsArr, expectedReturnsArr, covMatrix, onChange]);

  const updateSymbolAtIndex = useCallback((index: number, value: string) => {
    const next = [...symbolsArr];
    while (next.length <= index) next.push(`Asset${next.length + 1}`);
    next[index] = value;
    onChange({ ...data, symbols: next });
  }, [data, symbolsArr, onChange]);

  const updateExpectedReturnAtIndex = useCallback((index: number, value: number) => {
    const next = [...expectedReturnsArr];
    while (next.length <= index) next.push(0.10);
    next[index] = value;
    onChange({ ...data, expected_returns: next });
  }, [data, expectedReturnsArr, onChange]);

  // Group fields
  const groupedFields = useMemo(() => {
    const groups: Record<string, FieldConfig[]> = {
      basic: [],
      objective: [],
      parameters: [],
      blackLitterman: [],
      historical: [],
      constraints: [],
      costs: [],
      momentum: [],
      factors: [],
      liquidity: [],
      riskLimits: [],
    };

    fields.forEach(field => {
      for (const [group, fieldNames] of Object.entries(FIELD_GROUPS)) {
        if (fieldNames.includes(field.name)) {
          groups[group].push(field);
          return;
        }
      }
      // Default to parameters if not found
      groups.parameters.push(field);
    });

    return groups;
  }, [fields]);

  // Determine which sections should be visible
  const visibleSections = useMemo(() => {
    return {
      basic: true,
      objective: true,
      parameters: true,
      blackLitterman: REQUIRES_BL.includes(objective),
      historical: REQUIRES_RETURNS.includes(objective),
      constraints: true,
      costs: REQUIRES_COSTS.includes(objective) || !!data.transaction_costs,
      momentum: objective.startsWith('momentum_filtered'),
      factors: objective === 'factor_based_selection',
      liquidity: true,
      riskLimits: true,
    };
  }, [objective, data.transaction_costs]);

  const updateField = useCallback((name: string, value: unknown) => {
    onChange({ ...data, [name]: value });
  }, [data, onChange]);

  const toggleSection = (section: string) => {
    setExpandedSections(prev => ({ ...prev, [section]: !prev[section] }));
  };

  const toggleHelp = (fieldName: string) => {
    setShowHelp(prev => ({ ...prev, [fieldName]: !prev[fieldName] }));
  };

  const isFieldVisible = useCallback((fieldName: string) => {
    // Show/hide based on objective
    if (fieldName === 'target_return' && !REQUIRES_TARGET_RETURN.includes(objective)) return false;
    if (fieldName === 'target_volatility' && !REQUIRES_TARGET_RISK.includes(objective)) return false;
    if (fieldName === 'target_cvar' && !objective.includes('cvar')) return false;
    if (fieldName === 'target_cdar' && !objective.includes('cdar')) return false;
    if (fieldName === 'target_semivariance' && !objective.includes('semivariance')) return false;
    
    // Constraint visibility based on objective support
    const advancedConstraints = ['max_assets', 'min_position_size', 'current_weights', 'max_turnover', 
                                 'transaction_costs', 'per_asset_bounds', 'sector_caps', 'sector_mins', 'asset_sectors'];
    
    if (NO_CONSTRAINTS.includes(objective)) {
      // Hierarchical methods support NO constraints (they're ignored)
      if (advancedConstraints.includes(fieldName)) return false;
    } else if (LIMITED_CONSTRAINTS.includes(objective)) {
      // CLA methods only support basic weight bounds
      if (advancedConstraints.includes(fieldName)) return false;
    }
    
    return true;
  }, [objective]);

  const renderField = useCallback((field: FieldConfig) => {
    const value = data[field.name];
    if (!isFieldVisible(field.name) && field.name.startsWith('target_')) return null;

    return (
      <FieldRenderer
        key={field.name}
        field={field}
        value={value}
        onChange={(v) => updateField(field.name, v)}
        showHelp={showHelp[field.name] || false}
        onToggleHelp={() => toggleHelp(field.name)}
        compact={true}
      />
    );
  }, [data, showHelp, updateField, toggleHelp, isFieldVisible]);

  const showAssetsData = activeTab === undefined || activeTab === 'assetsData';
  const showObjective = activeTab === undefined || activeTab === 'objective';
  const showConstraint = activeTab === undefined || activeTab === 'constraint';

  return (
    <div className="space-y-8">
      {/* ========== ASSETS & DATA PAGE (reference layout) ========== */}
      {showAssetsData && (
        <section className="space-y-6">
          <div>
            <h2 className="text-xl font-semibold text-slate-900 tracking-tight">Assets & Data</h2>
            <p className="text-sm text-slate-500 mt-1">
              Configure assets, expected returns, and covariance. Upload CSV/JSON or add assets manually.
            </p>
          </div>

          {/* Upload drop zone when no assets */}
          {assetCount === 0 && (
            <>
              <div
                role="button"
                tabIndex={0}
                onKeyDown={(e) => e.key === 'Enter' && fileInputRef.current?.click()}
                onClick={() => fileInputRef.current?.click()}
                onDrop={handleDrop}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                className={`
                  flex min-h-[160px] flex-col items-center justify-center gap-3 rounded-xl border-2 border-dashed p-6 text-center transition-colors
                  ${dragOver ? 'border-indigo-500 bg-indigo-50/50' : 'border-slate-300 bg-slate-50/80 hover:border-slate-400'}
                `}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".json,.csv,application/json,text/csv"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <Upload className="size-8 text-slate-500" />
                <p className="text-sm text-slate-600">Drop CSV or JSON here, or click to browse</p>
                <p className="text-xs text-slate-500">JSON: expected_returns, covariance_matrix, symbols. CSV: symbol, return per row.</p>
              </div>
              {uploadError && (
                <div className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                  {uploadError}
                </div>
              )}
            </>
          )}

          {/* Card: Assets (N) — same layout as reference */}
          <Card>
            <CardHeader className="pb-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <CardTitle className="text-base flex items-center gap-2">
                    <PieChart className="h-4 w-4 text-indigo-600" />
                    Assets ({assetCount})
                  </CardTitle>
                  <CardDescription>Configure expected returns; volatility is derived from the covariance matrix.</CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  {assetCount > 0 && (
                    <>
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept=".json,.csv,application/json,text/csv"
                        onChange={handleFileUpload}
                        className="hidden"
                      />
                      <Button type="button" variant="outline" size="sm" onClick={() => fileInputRef.current?.click()}>
                        <Upload className="h-3 w-3 mr-1" />
                        Import
                      </Button>
                    </>
                  )}
                  <Button type="button" size="sm" variant="outline" onClick={addAsset} className="gap-1">
                    <Plus className="h-3 w-3" />
                    Add Asset
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {assetCount === 0 ? (
                <p className="text-sm text-slate-500 text-center py-8">No assets yet. Choose an example (if available), import CSV/JSON above, or click Add Asset.</p>
              ) : (
                <>
                  {assetCount > LARGE_ASSET_COUNT && (
                    <p className="text-xs text-slate-500 mb-2">
                      {assetCount} assets — scroll the table to see all. For 50+ assets, prefer uploading CSV/JSON in the header.
                    </p>
                  )}
                  <div className={`overflow-x-auto overflow-y-auto border border-slate-200 rounded-lg ${assetCount > LARGE_ASSET_COUNT ? 'max-h-[min(400px,50vh)]' : ''}`}>
                    <table className="w-full text-sm border-collapse">
                      <thead className="sticky top-0 z-10 bg-slate-50 border-b border-slate-200">
                        <tr>
                          <th className="text-left font-medium text-slate-600 py-2 pr-4 w-32">Symbol</th>
                          <th className="text-left font-medium text-slate-600 py-2 pr-4 w-36">Expected Return</th>
                          <th className="text-left font-medium text-slate-600 py-2 pr-4 w-28">Volatility</th>
                          <th className="w-10" />
                        </tr>
                      </thead>
                      <tbody>
                        {Array.from({ length: assetCount }, (_, idx) => {
                        const sym = symbolsArr[idx] ?? `Asset${idx + 1}`;
                        const muVal = typeof expectedReturnsArr[idx] === 'number' ? expectedReturnsArr[idx] : 0.10;
                        const vol = covMatrix[idx]?.[idx] != null ? Math.sqrt(covMatrix[idx][idx]) : 0;
                        return (
                          <tr key={idx} className="border-b border-slate-100 hover:bg-slate-50/50">
                            <td className="py-1.5 pr-4">
                              <Input
                                value={sym}
                                onChange={(e) => updateSymbolAtIndex(idx, e.target.value)}
                                className="h-8 text-sm font-mono bg-white"
                                aria-label={`Asset ${idx + 1} symbol`}
                              />
                            </td>
                            <td className="py-1.5 pr-4">
                              <div className="flex items-center gap-2">
                                <Input
                                  type="number"
                                  step={0.01}
                                  min={-1}
                                  max={2}
                                  value={muVal}
                                  onChange={(e) => updateExpectedReturnAtIndex(idx, parseFloat(e.target.value) || 0)}
                                  className="h-8 w-24 text-sm font-mono bg-white"
                                  aria-label={`Expected return ${idx + 1}`}
                                />
                                <span className="text-xs text-slate-500 font-mono">{formatPercent(muVal)}</span>
                              </div>
                            </td>
                            <td className="py-1.5 text-slate-500 font-mono text-xs">
                              {formatPercent(vol)}
                            </td>
                            <td className="py-1.5">
                              <Button
                                type="button"
                                variant="ghost"
                                size="sm"
                                className="h-7 w-7 p-0 text-slate-400 hover:text-red-600"
                                onClick={() => removeAsset(idx)}
                                aria-label={`Remove ${sym}`}
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </Button>
                            </td>
                          </tr>
                        );
                      })}
                      </tbody>
                    </table>
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          {/* Covariance Matrix — view, edit (small n), or upload (large n) */}
          {covMatrix.length > 0 && (
            <Card>
              <CardHeader className="pb-3">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div>
                    <CardTitle className="text-base">Covariance Matrix</CardTitle>
                    <CardDescription>
                      {assetCount <= MAX_MATRIX_EDIT_IN_BROWSER
                        ? 'Annualized covariance. View below or click Edit to change values and add rows/columns.'
                        : `Large matrix (${covMatrix.length}×${covMatrix[0]?.length ?? 0}). Replace via upload — in-browser edit is disabled for 20+ assets.`}
                    </CardDescription>
                  </div>
                  <div className="flex items-center gap-2">
                    {assetCount <= MAX_MATRIX_EDIT_IN_BROWSER ? (
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => setShowCovarianceEditor((v) => !v)}
                      >
                        {showCovarianceEditor ? 'Done (view only)' : 'Edit matrix'}
                      </Button>
                    ) : (
                      <>
                        <input
                          ref={covarianceFileInputRef}
                          type="file"
                          accept=".json,.csv,application/json,text/csv,text/plain"
                          onChange={handleCovarianceOnlyUpload}
                          className="hidden"
                        />
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => covarianceFileInputRef.current?.click()}
                        >
                          <Upload className="h-3 w-3 mr-1" />
                          Upload JSON/CSV (matrix only)
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {covarianceUploadError && (
                  <div className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-600">
                    {covarianceUploadError}
                  </div>
                )}
                {showCovarianceEditor && assetCount <= MAX_MATRIX_EDIT_IN_BROWSER ? (
                  <div className="max-h-[min(420px,55vh)] overflow-auto rounded-lg border border-slate-200 bg-white p-3">
                    <MatrixInput
                      value={covMatrix}
                      onChange={(v) => updateField('covariance_matrix', v)}
                      compact={false}
                      className="max-h-[380px]"
                    />
                  </div>
                ) : (
                  <>
                    <div className="flex items-center gap-2 mb-2">
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => setShowFullCovarianceMatrix((v) => !v)}
                      >
                        {showFullCovarianceMatrix ? 'Show preview (12×12)' : 'Show full matrix'}
                      </Button>
                      {showFullCovarianceMatrix && (
                        <span className="text-xs text-slate-500">
                          Scroll to see all {covMatrix.length}×{covMatrix[0]?.length ?? 0} entries.
                        </span>
                      )}
                    </div>
                    <div
                      className={cn(
                        'overflow-x-auto overflow-y-auto rounded-lg border border-slate-200 bg-white',
                        showFullCovarianceMatrix ? 'max-h-[70vh] min-h-[200px]' : 'max-h-[320px]'
                      )}
                    >
                      <table className="w-full text-sm border-collapse">
                        <thead className="sticky top-0 z-10 bg-slate-50 border-b border-slate-200">
                          <tr>
                            <th className="w-16 min-w-[4rem] text-left font-medium text-slate-600 py-2 pr-2 sticky left-0 z-20 bg-slate-50 border-r border-slate-200" />
                            {(showFullCovarianceMatrix ? symbolsArr : symbolsArr.slice(0, 12)).map((s, j) => (
                              <th key={j} className="text-center font-mono text-xs text-slate-600 py-2 px-1 min-w-[3.5rem]">
                                {s}
                              </th>
                            ))}
                            {!showFullCovarianceMatrix && symbolsArr.length > 12 && (
                              <th className="text-center text-xs text-slate-400 py-2">+{symbolsArr.length - 12}</th>
                            )}
                          </tr>
                        </thead>
                        <tbody>
                          {(showFullCovarianceMatrix ? covMatrix : covMatrix.slice(0, 12)).map((row, i) => (
                            <tr key={i} className="border-b border-slate-100">
                              <td className="font-mono text-xs font-medium text-slate-700 py-1 pr-2 sticky left-0 z-10 bg-white border-r border-slate-100 min-w-[4rem]">
                                {symbolsArr[i] ?? `A${i + 1}`}
                              </td>
                              {(showFullCovarianceMatrix ? row : row.slice(0, 12)).map((cell, j) => (
                                <td key={j} className={`text-center font-mono text-xs py-1 px-1 min-w-[3.5rem] ${i === j ? 'text-indigo-600 font-medium' : 'text-slate-500'}`}>
                                  {cell?.toFixed(4) ?? '—'}
                                </td>
                              ))}
                              {!showFullCovarianceMatrix && row.length > 12 && (
                                <td className="text-center text-xs text-slate-400">…</td>
                              )}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                    {!showFullCovarianceMatrix && covMatrix.length > 12 && (
                      <p className="text-xs text-slate-500 mt-2">Showing first 12×12. Click “Show full matrix” to expand and scroll.</p>
                    )}
                  </>
                )}
              </CardContent>
            </Card>
          )}

          {/* Black–Litterman & Historical (unchanged) */}
          {(activeTab === undefined || activeTab === 'assetsData') && (visibleSections.blackLitterman || visibleSections.historical) && (
            <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
              {visibleSections.blackLitterman && (
                <Card className="overflow-hidden">
                  <div className="border-b border-purple-100 bg-purple-50 px-4 py-2.5 flex items-center gap-2">
                    <Shield className="size-4 text-purple-600" />
                    <h3 className="text-sm font-semibold text-slate-800">Black–Litterman</h3>
                  </div>
                  <CardContent className="p-4 space-y-3">
                    {groupedFields.blackLitterman.map(renderField)}
                  </CardContent>
                </Card>
              )}
              {visibleSections.historical && (
                <Card className="overflow-hidden">
                  <div className="border-b border-cyan-100 bg-cyan-50 px-4 py-2.5 flex items-center gap-2">
                    <BarChart3 className="size-4 text-cyan-600" />
                    <h3 className="text-sm font-semibold text-slate-800">Historical Returns</h3>
                  </div>
                  <CardContent className="p-4">
                    {groupedFields.historical.map(renderField)}
                  </CardContent>
                </Card>
              )}
            </div>
          )}

          {activeTab === undefined && (visibleSections.momentum || visibleSections.factors) && (
            <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
              {visibleSections.momentum && (
                <Card className="overflow-hidden">
                  <div className="border-b border-violet-100 bg-violet-50 px-4 py-2.5 flex items-center gap-2">
                    <TrendingUp className="size-4 text-violet-600" />
                    <h3 className="text-sm font-semibold text-slate-800">Momentum Filter</h3>
                  </div>
                  <CardContent className="p-4 space-y-3">
                    {groupedFields.momentum.map(renderField)}
                  </CardContent>
                </Card>
              )}
              {visibleSections.factors && (
                <Card className="overflow-hidden">
                  <div className="border-b border-rose-100 bg-rose-50 px-4 py-2.5 flex items-center gap-2">
                    <BarChart3 className="size-4 text-rose-600" />
                    <h3 className="text-sm font-semibold text-slate-800">Factor Data</h3>
                  </div>
                  <CardContent className="p-4 space-y-3">
                    {groupedFields.factors.map(renderField)}
                  </CardContent>
                </Card>
              )}
            </div>
          )}
        </section>
      )}

      {/* ========== OBJECTIVE PAGE ========== */}
      {showObjective && (
        <section className="space-y-5">
          <div>
            <h2 className="text-lg font-semibold text-slate-800">Objective</h2>
            <p className="text-sm text-slate-500 mt-0.5">
              Choose what to optimize (e.g. minimize volatility, maximize Sharpe) and set any required parameters.
            </p>
          </div>

          <Card className="overflow-hidden">
            <CardContent className="p-5">
              <label className="block text-sm font-medium text-slate-700 mb-2">Optimization objective</label>
              <select
                value={objective}
                onChange={(e) => updateField('objective', e.target.value)}
                className="w-full max-w-md p-2.5 bg-white border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
              >
                {OBJECTIVE_GROUPS.map((grp) => {
                  const options = (groupedFields.objective[0]?.options || []).filter((opt) => grp.values.includes(opt.value));
                  if (options.length === 0) return null;
                  return (
                    <optgroup key={grp.label} label={grp.label}>
                      {options.map((opt) => (
                        <option key={opt.value} value={opt.value}>{opt.label}</option>
                      ))}
                    </optgroup>
                  );
                })}
                {(groupedFields.objective[0]?.options || [])
                  .filter((opt) => !OBJECTIVE_GROUPS.some((g) => g.values.includes(opt.value)))
                  .map((opt) => (
                    <option key={opt.value} value={opt.value}>{opt.label}</option>
                  ))}
              </select>
            </CardContent>
          </Card>

          {(REQUIRES_TARGET_RETURN.includes(objective) || REQUIRES_TARGET_RISK.includes(objective) ||
            objective.includes('cvar') || objective.includes('cdar') || objective.includes('semivariance') ||
            ['max_sharpe', 'max_utility', 'max_sharpe_with_costs', 'momentum_filtered_max_sharpe', ...REQUIRES_BL].includes(objective)) && (
            <Card className="overflow-hidden">
              <div className="bg-amber-50 px-4 py-2.5 border-b border-amber-100">
                <h3 className="font-semibold text-slate-800 text-sm">Parameters for this objective</h3>
              </div>
              <CardContent className="p-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {groupedFields.parameters
                    .filter(f => {
                      if (f.name === 'target_return') return REQUIRES_TARGET_RETURN.includes(objective);
                      if (f.name === 'target_volatility') return REQUIRES_TARGET_RISK.includes(objective);
                      if (f.name === 'target_cvar') return objective.includes('cvar');
                      if (f.name === 'target_cdar') return objective.includes('cdar');
                      if (f.name === 'target_semivariance') return objective.includes('semivariance');
                      if (f.name === 'risk_free_rate') return ['max_sharpe', 'cla_max_sharpe', 'hierarchical_max_sharpe', 'max_sharpe_with_costs', 'momentum_filtered_max_sharpe', ...REQUIRES_BL].includes(objective);
                      if (f.name === 'risk_aversion') return ['max_utility', ...REQUIRES_BL].includes(objective);
                      if (f.name === 'confidence_level') return objective.includes('cvar') || objective.includes('cdar');
                      if (f.name === 'benchmark') return objective.includes('semivariance');
                      if (f.name === 'min_net_return') return REQUIRES_COSTS.includes(objective);
                      return false;
                    })
                    .map((f) => (
                      <div key={f.name}>
                        {renderField(f)}
                        {PARAMETER_HINTS[f.name] && (
                          <p className="text-xs text-slate-500 mt-0.5">{PARAMETER_HINTS[f.name]}</p>
                        )}
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>
          )}

          {activeTab === 'objective' && (visibleSections.momentum || visibleSections.factors) && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
              {visibleSections.momentum && (
                <Card className="overflow-hidden">
                  <div className="bg-violet-50 px-4 py-2.5 border-b border-violet-100 flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-violet-600" />
                    <h3 className="font-semibold text-slate-800 text-sm">Momentum Filter</h3>
                  </div>
                  <CardContent className="p-4 space-y-3">
                    {groupedFields.momentum.map(renderField)}
                  </CardContent>
                </Card>
              )}
              {visibleSections.factors && (
                <Card className="overflow-hidden">
                  <div className="bg-rose-50 px-4 py-2.5 border-b border-rose-100 flex items-center gap-2">
                    <BarChart3 className="w-4 h-4 text-rose-600" />
                    <h3 className="font-semibold text-slate-800 text-sm">Factor Data</h3>
                  </div>
                  <CardContent className="p-4 space-y-3">
                    {groupedFields.factors.map(renderField)}
                  </CardContent>
                </Card>
              )}
            </div>
          )}

          <Card className="bg-blue-50 border-blue-200">
            <CardContent className="p-4 flex items-start gap-3">
              <Info className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
              <div className="text-sm text-blue-800">
                <p className="font-medium mb-1.5">{objective.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</p>
                {REQUIRES_RETURNS.includes(objective) && <p className="text-blue-700">• Fill Historical Returns in Assets & Data.</p>}
                {REQUIRES_BL.includes(objective) && <p className="text-blue-700">• Fill Black–Litterman data in Assets & Data.</p>}
                {REQUIRES_TARGET_RETURN.includes(objective) && <p className="text-blue-700">• Set target return above.</p>}
                {REQUIRES_TARGET_RISK.includes(objective) && <p className="text-blue-700">• Set target volatility above.</p>}
                {REQUIRES_COSTS.includes(objective) && <p className="text-blue-700">• Provide transaction_costs and current_weights in Constraints.</p>}
                {objective.startsWith('momentum_filtered') && <p className="text-blue-700">• Provide Historical Returns in Assets & Data for momentum filter.</p>}
                {objective === 'factor_based_selection' && <p className="text-blue-700">• Fill Factor Data (and optional Factor Weights) in Assets & Data.</p>}
                {['risk_parity', 'equal_risk_contribution'].includes(objective) && <p className="text-blue-700">• Risk parity: equal risk contribution across assets.</p>}
                {['max_diversification', 'max_diversification_index'].includes(objective) && <p className="text-blue-700">• Maximize diversification ratio.</p>}
                {NO_CONSTRAINTS.includes(objective) && <p className="text-amber-700 font-medium">• Hierarchical methods ignore constraints.</p>}
                {LIMITED_CONSTRAINTS.includes(objective) && <p className="text-amber-700 font-medium">• CLA supports only basic weight bounds.</p>}
              </div>
            </CardContent>
          </Card>
        </section>
      )}

      {/* ========== CONSTRAINTS PAGE ========== */}
      {showConstraint && (
        <section className="space-y-5">
          <div>
            <h2 className="text-lg font-semibold text-slate-800">Constraints</h2>
            <p className="text-sm text-slate-500 mt-0.5">
              Limit weights, turnover, sector exposure, and optional transaction costs. Some objectives support only basic bounds.
            </p>
          </div>

          {(NO_CONSTRAINTS.includes(objective) || LIMITED_CONSTRAINTS.includes(objective)) && (
            <Card className="bg-amber-50 border-amber-200">
              <CardContent className="p-4">
                {NO_CONSTRAINTS.includes(objective) && (
                  <p className="text-sm text-amber-800">
                    <strong>Note:</strong> Hierarchical methods ignore all constraints. Weight bounds may be applied but are not guaranteed.
                  </p>
                )}
                {LIMITED_CONSTRAINTS.includes(objective) && (
                  <p className="text-sm text-amber-800">
                    <strong>Note:</strong> CLA methods support only basic weight bounds (min/max weight). Cardinality, turnover, and sector constraints are not available.
                  </p>
                )}
              </CardContent>
            </Card>
          )}

          <Card className="overflow-hidden">
            <div className="bg-slate-50 px-4 py-2.5 border-b border-slate-200 flex items-center justify-between flex-wrap gap-2">
              <h3 className="font-semibold text-slate-800 text-sm">Weight and cardinality</h3>
              {NO_CONSTRAINTS.includes(objective) && <span className="text-xs text-amber-600 bg-amber-50 px-2 py-0.5 rounded font-medium">No constraints supported</span>}
              {LIMITED_CONSTRAINTS.includes(objective) && <span className="text-xs text-amber-600 bg-amber-50 px-2 py-0.5 rounded font-medium">Only weight bounds</span>}
            </div>
            <CardContent className="p-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {groupedFields.constraints
                  .filter(f => ['min_weight', 'max_weight', 'max_assets', 'min_position_size'].includes(f.name))
                  .filter(f => isFieldVisible(f.name))
                  .map(renderField)}
              </div>
            </CardContent>
          </Card>

          {groupedFields.constraints.some(f => ['current_weights', 'max_turnover'].includes(f.name) && isFieldVisible(f.name)) && (
            <Card className="overflow-hidden">
              <div className="bg-slate-50 px-4 py-2.5 border-b border-slate-200">
                <h3 className="font-semibold text-slate-800 text-sm">Turnover</h3>
                <p className="text-xs text-slate-500 mt-0.5">Current weights and maximum turnover (0–1).</p>
              </div>
              <CardContent className="p-5">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  {groupedFields.constraints
                    .filter(f => ['current_weights', 'max_turnover'].includes(f.name))
                    .filter(f => isFieldVisible(f.name))
                    .map(renderField)}
                </div>
              </CardContent>
            </Card>
          )}

          {groupedFields.constraints.some(f => ['per_asset_bounds', 'sector_caps', 'sector_mins', 'asset_sectors'].includes(f.name) && isFieldVisible(f.name)) && (
            <Card className="overflow-hidden">
              <div className="bg-slate-50 px-4 py-2.5 border-b border-slate-200">
                <h3 className="font-semibold text-slate-800 text-sm">Sector and per-asset bounds</h3>
                <p className="text-xs text-slate-500 mt-0.5">Asset → sector mapping, sector caps/mins, and per-asset min/max.</p>
              </div>
              <CardContent className="p-5">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  {groupedFields.constraints
                    .filter(f => ['per_asset_bounds', 'sector_caps', 'sector_mins', 'asset_sectors'].includes(f.name))
                    .filter(f => isFieldVisible(f.name))
                    .map(renderField)}
                </div>
              </CardContent>
            </Card>
          )}

          {visibleSections.liquidity && groupedFields.liquidity.length > 0 && (
            <Card className="overflow-hidden">
              <div className="bg-slate-50 px-4 py-2.5 border-b border-slate-200">
                <h3 className="font-semibold text-slate-800 text-sm">Liquidity</h3>
                <p className="text-xs text-slate-500 mt-0.5">ADV, participation limits, and spread cost caps.</p>
              </div>
              <CardContent className="p-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {groupedFields.liquidity.filter(f => isFieldVisible(f.name)).map(renderField)}
                </div>
              </CardContent>
            </Card>
          )}

          {visibleSections.riskLimits && groupedFields.riskLimits.length > 0 && (
            <Card className="overflow-hidden">
              <div className="bg-slate-50 px-4 py-2.5 border-b border-slate-200">
                <h3 className="font-semibold text-slate-800 text-sm">Risk limits</h3>
                <p className="text-xs text-slate-500 mt-0.5">Volatility cap, concentration, and tracking error.</p>
              </div>
              <CardContent className="p-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {groupedFields.riskLimits.filter(f => isFieldVisible(f.name)).map(renderField)}
                </div>
              </CardContent>
            </Card>
          )}

          {visibleSections.costs && groupedFields.costs.length > 0 && (
            <Card className="overflow-hidden">
              <div className="bg-orange-50 px-4 py-2.5 border-b border-orange-100 flex items-center justify-between">
                <h3 className="font-semibold text-slate-800 text-sm">Transaction costs</h3>
                {REQUIRES_COSTS.includes(objective) && (
                  <span className="text-xs text-orange-600 bg-white px-2 py-0.5 rounded border border-orange-200">Required for cost-aware objectives</span>
                )}
              </div>
              <CardContent className="p-5">
                {groupedFields.costs.map(renderField)}
                {REQUIRES_COSTS.includes(objective) && (
                  <p className="mt-3 text-xs text-orange-700 bg-orange-50 p-2 rounded-lg">
                    Provide costs as a dictionary (asset → cost) or array/list.
                  </p>
                )}
              </CardContent>
            </Card>
          )}
        </section>
      )}
    </div>
  );
}

// Compact Field Renderer
interface FieldRendererProps {
  field: FieldConfig;
  value: unknown;
  onChange: (value: unknown) => void;
  showHelp: boolean;
  onToggleHelp: () => void;
  compact?: boolean;
}

function FieldRenderer({ field, value, onChange, showHelp, onToggleHelp, compact = false }: FieldRendererProps) {
  const renderInput = () => {
    switch (field.type) {
      case 'number':
        return (
          <input
            type="number"
            value={value as number ?? field.default ?? ''}
            onChange={(e) => onChange(e.target.value === '' ? undefined : parseFloat(e.target.value))}
            min={field.min}
            max={field.max}
            step={field.step ?? (field.name.includes('rate') || field.name.includes('return') ? 0.001 : 1)}
            placeholder={field.default ? String(field.default) : ''}
            className="w-full p-2 bg-white border border-slate-300 rounded text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
          />
        );

      case 'text':
        return (
          <input
            type="text"
            value={value as string ?? ''}
            onChange={(e) => onChange(e.target.value || undefined)}
            className="w-full p-2 bg-white border border-slate-300 rounded text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
          />
        );

      case 'select':
        return (
          <select
            value={value as string ?? field.default ?? ''}
            onChange={(e) => onChange(e.target.value)}
            className="w-full p-2 bg-white border border-slate-300 rounded text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
          >
            {field.options?.map((opt) => (
              <option key={opt.value} value={opt.value}>
                {opt.label}
              </option>
            ))}
          </select>
        );

      case 'array':
        if (field.name === 'symbols') {
          return <StringArrayInput value={(value as string[]) ?? []} onChange={onChange} placeholder="AAPL, GOOGL, MSFT" />;
        }
        return <ArrayInput value={(value as number[]) ?? []} onChange={onChange} compact={compact} />;

      case 'matrix':
        return <MatrixInput value={(value as number[][]) ?? []} onChange={onChange} compact={compact} />;

      case 'map':
      case 'json':
        return (
          <textarea
            value={typeof value === 'object' && value !== null ? JSON.stringify(value, null, 2) : (value as string) ?? ''}
            onChange={(e) => {
              const raw = e.target.value.trim();
              if (!raw) {
                onChange(undefined);
                return;
              }
              try {
                onChange(JSON.parse(raw));
              } catch {
                onChange(raw);
              }
            }}
            rows={3}
            className="w-full p-2 bg-white border border-slate-300 rounded text-sm font-mono focus:ring-2 focus:ring-indigo-500 outline-none"
            placeholder="{}"
          />
        );

      default:
        return (
          <input
            type="text"
            value={String(value ?? '')}
            onChange={(e) => onChange(e.target.value)}
            className="w-full p-2 bg-white border border-slate-300 rounded text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
          />
        );
    }
  };

  return (
    <div className="space-y-1">
      <div className="flex items-center gap-1.5">
        <label className="text-xs font-medium text-slate-700 flex-1">
          {field.label}
          {field.required && <span className="text-red-500 ml-0.5">*</span>}
        </label>
        {field.description && (
          <button
            type="button"
            onClick={onToggleHelp}
            className="text-slate-400 hover:text-slate-600"
            title={field.description}
          >
            <HelpCircle className="w-3.5 h-3.5" />
          </button>
        )}
      </div>
      {showHelp && field.description && (
        <p className="text-xs text-slate-500 bg-slate-50 p-1.5 rounded mb-1">{field.description}</p>
      )}
      {renderInput()}
    </div>
  );
}

// Compact Array Input (numbers)
function ArrayInput({ value, onChange, compact }: { value: number[]; onChange: (v: number[]) => void; compact?: boolean }) {
  const [inputText, setInputText] = useState(() => (Array.isArray(value) ? value.join(', ') : ''));

  // Sync from parent when value changes (e.g. after file upload or template load)
  useEffect(() => {
    setInputText(Array.isArray(value) ? value.join(', ') : '');
  }, [value]);

  const handleBlur = () => {
    try {
      const parsed = inputText.split(',').map(s => parseFloat(s.trim())).filter(n => !isNaN(n));
      onChange(parsed);
    } catch {
      // Keep existing value on parse error
    }
  };

  return (
    <input
      type="text"
      value={inputText}
      onChange={(e) => setInputText(e.target.value)}
      onBlur={handleBlur}
      placeholder="0.12, 0.10, 0.08"
      className="w-full p-2 bg-white border border-slate-300 rounded text-xs font-mono focus:ring-2 focus:ring-indigo-500 outline-none"
    />
  );
}

// String array input (e.g. asset symbols) — comma-separated, no number parsing
function StringArrayInput({
  value,
  onChange,
  placeholder = 'Symbol1, Symbol2, Symbol3',
}: {
  value: string[];
  onChange: (v: unknown) => void;
  placeholder?: string;
}) {
  const arr = Array.isArray(value) ? value : [];
  const [inputText, setInputText] = useState(() => arr.join(', '));

  useEffect(() => {
    setInputText(arr.join(', '));
  }, [value]);

  const handleBlur = () => {
    const parsed = inputText
      .split(',')
      .map(s => s.trim())
      .filter(Boolean);
    onChange(parsed);
  };

  return (
    <input
      type="text"
      value={inputText}
      onChange={(e) => setInputText(e.target.value)}
      onBlur={handleBlur}
      placeholder={placeholder}
      className="w-full p-2 bg-white border border-slate-300 rounded text-xs font-mono focus:ring-2 focus:ring-indigo-500 outline-none"
    />
  );
}

// Compact Matrix Input (simplified for portfolio - shows size info)
function MatrixInput({ value, onChange, compact, className }: { value: number[][]; onChange: (v: number[][]) => void; compact?: boolean; className?: string }) {
  const [expanded, setExpanded] = useState(false);
  const [rows, setRows] = useState(value.length || 3);
  const [cols, setCols] = useState(value[0]?.length || 3);
  const [matrix, setMatrix] = useState<number[][]>(() => {
    if (Array.isArray(value) && value.length > 0) return value.map(r => [...r]);
    return Array(rows).fill(null).map(() => Array(cols).fill(0));
  });

  // Sync from parent when value changes (e.g. after file upload or template load)
  useEffect(() => {
    if (Array.isArray(value) && value.length > 0) {
      setMatrix(value.map(r => [...r]));
      setRows(value.length);
      setCols(value[0]?.length ?? 0);
    }
  }, [value]);

  const updateCell = (i: number, j: number, val: number) => {
    const newMatrix = matrix.map((row, ri) => 
      row.map((cell, ci) => (ri === i && ci === j) ? val : cell)
    );
    setMatrix(newMatrix);
    onChange(newMatrix);
  };

  if (compact && !expanded) {
    return (
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-xs text-slate-500">
            {matrix.length > 0 ? `${matrix.length}×${matrix[0].length} matrix` : 'Empty matrix'}
          </span>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => setExpanded(true)}
            className="text-xs h-7"
          >
            Edit Matrix
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {expanded && (
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs text-slate-500">{matrix.length}×{matrix[0]?.length || 0} matrix</span>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => setExpanded(false)}
            className="text-xs h-7"
          >
            Collapse
          </Button>
        </div>
      )}
      <div className={cn('overflow-x-auto overflow-y-auto border border-slate-200 rounded p-2 bg-white', className ?? 'max-h-64')}>
        <table className="text-xs">
          <tbody>
            {matrix.map((row, i) => (
              <tr key={i}>
                {row.map((cell, j) => (
                  <td key={j} className="p-0.5">
                    <input
                      type="number"
                      value={cell}
                      onChange={(e) => updateCell(i, j, parseFloat(e.target.value) || 0)}
                      className="w-16 p-1.5 border border-slate-200 rounded text-center font-mono focus:ring-1 focus:ring-indigo-500 outline-none text-xs"
                      step="0.001"
                    />
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {expanded && (
        <div className="flex gap-2">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => {
              const newMatrix = [...matrix, Array(matrix[0]?.length || cols).fill(0)];
              setMatrix(newMatrix);
              onChange(newMatrix);
            }}
            className="text-xs h-7"
          >
            + Row
          </Button>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => {
              const newMatrix = matrix.map(row => [...row, 0]);
              setMatrix(newMatrix);
              onChange(newMatrix);
            }}
            className="text-xs h-7"
          >
            + Col
          </Button>
        </div>
      )}
    </div>
  );
}
