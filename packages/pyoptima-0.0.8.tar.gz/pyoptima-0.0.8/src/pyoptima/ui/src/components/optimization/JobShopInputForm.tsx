'use client';

import { useCallback } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

export interface JobShopOperation {
  machine: string;
  duration: number;
}

export interface JobShopJob {
  name: string;
  operations: JobShopOperation[];
}

interface JobShopInputFormProps {
  data: Record<string, unknown>;
  onChange: (data: Record<string, unknown>) => void;
}

function ensureJobs(data: Record<string, unknown>): JobShopJob[] {
  const raw = data.jobs;
  if (Array.isArray(raw) && raw.length > 0) {
    return raw.map((j: unknown) => {
      if (j && typeof j === 'object' && 'name' in j && 'operations' in j) {
        const ops = Array.isArray((j as { operations: unknown }).operations)
          ? (j as { operations: unknown[] }).operations.map((o: unknown) => {
              if (o && typeof o === 'object' && 'machine' in o && 'duration' in o) {
                return {
                  machine: String((o as { machine: unknown }).machine),
                  duration: Number((o as { duration: unknown }).duration) || 0,
                };
              }
              return { machine: '', duration: 0 };
            })
          : [];
        return { name: String((j as { name: unknown }).name), operations: ops };
      }
      return { name: 'Job', operations: [{ machine: '', duration: 0 }] };
    });
  }
  return [
    { name: 'Job1', operations: [{ machine: 'M1', duration: 3 }, { machine: 'M2', duration: 2 }] },
    { name: 'Job2', operations: [{ machine: 'M2', duration: 2 }, { machine: 'M1', duration: 4 }] },
  ];
}

function ensureMachines(data: Record<string, unknown>): string[] {
  const raw = data.machines;
  if (Array.isArray(raw)) return raw.map(String).filter(Boolean);
  return [];
}

function ensureHorizon(data: Record<string, unknown>): number | undefined {
  const v = data.horizon;
  if (typeof v === 'number' && v > 0) return v;
  if (typeof v === 'string' && v.trim() !== '') {
    const n = Number(v);
    if (!Number.isNaN(n) && n > 0) return n;
  }
  return undefined;
}

export function JobShopInputForm({ data, onChange }: JobShopInputFormProps) {
  const jobs = ensureJobs(data);
  const machines = ensureMachines(data);
  const horizon = ensureHorizon(data);

  const updateJobs = useCallback(
    (newJobs: JobShopJob[]) => {
      onChange({ ...data, jobs: newJobs });
    },
    [data, onChange]
  );

  const updateMachines = useCallback(
    (newMachines: string[]) => {
      onChange({ ...data, machines: newMachines });
    },
    [data, onChange]
  );

  const setJob = useCallback(
    (index: number, job: JobShopJob) => {
      const next = [...jobs];
      next[index] = job;
      updateJobs(next);
    },
    [jobs, updateJobs]
  );

  const addJob = useCallback(() => {
    const name = `Job${jobs.length + 1}`;
    updateJobs([...jobs, { name, operations: [{ machine: machines[0] || '', duration: 1 }] }]);
  }, [jobs, machines, updateJobs]);

  const removeJob = useCallback(
    (index: number) => {
      if (jobs.length <= 1) return;
      updateJobs(jobs.filter((_, i) => i !== index));
    },
    [jobs, updateJobs]
  );

  const addOperation = useCallback(
    (jobIndex: number) => {
      const job = jobs[jobIndex];
      if (!job) return;
      setJob(jobIndex, {
        ...job,
        operations: [...job.operations, { machine: machines[0] || '', duration: 1 }],
      });
    },
    [jobs, machines, setJob]
  );

  const removeOperation = useCallback(
    (jobIndex: number, opIndex: number) => {
      const job = jobs[jobIndex];
      if (!job || job.operations.length <= 1) return;
      setJob(jobIndex, {
        ...job,
        operations: job.operations.filter((_, i) => i !== opIndex),
      });
    },
    [jobs, setJob]
  );

  const setOperation = useCallback(
    (jobIndex: number, opIndex: number, field: 'machine' | 'duration', value: string | number) => {
      const job = jobs[jobIndex];
      if (!job) return;
      const ops = [...job.operations];
      const op = ops[opIndex];
      if (!op) return;
      if (field === 'machine') ops[opIndex] = { ...op, machine: String(value) };
      else ops[opIndex] = { ...op, duration: Number(value) || 0 };
      setJob(jobIndex, { ...job, operations: ops });
    },
    [jobs, setJob]
  );

  const setHorizon = useCallback(
    (value: number | undefined) => {
      onChange({ ...data, horizon: value === undefined || value <= 0 ? undefined : value });
    },
    [data, onChange]
  );

  return (
    <div className="space-y-6">
      {/* Time horizon (optional) */}
      <div>
        <label className="block text-sm font-medium text-slate-700 mb-2">
          Time horizon (optional)
        </label>
        <p className="text-xs text-slate-500 mb-2">
          Maximum time span for the schedule. Leave empty to auto-compute from total operation durations.
        </p>
        <input
          type="number"
          value={horizon ?? ''}
          onChange={(e) => setHorizon(e.target.value === '' ? undefined : parseInt(e.target.value, 10))}
          min={1}
          placeholder="Auto"
          className="w-40 p-2.5 bg-white border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
        />
      </div>

      {/* Machine names (optional) */}
      <div>
        <label className="block text-sm font-medium text-slate-700 mb-2">
          Machine names (optional)
        </label>
        <p className="text-xs text-slate-500 mb-2">
          Comma-separated. Used as dropdown options for each operation.
        </p>
        <input
          type="text"
          value={machines.join(', ')}
          onChange={(e) => {
            const list = e.target.value.split(',').map((s) => s.trim()).filter(Boolean);
            updateMachines(list);
          }}
          placeholder="M1, M2, M3"
          className="w-full p-2.5 bg-white border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
        />
      </div>

      {/* Jobs */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <label className="text-sm font-medium text-slate-700">Jobs and operations</label>
          <Button type="button" variant="outline" size="sm" onClick={addJob}>
            <Plus className="w-4 h-4 mr-1" />
            Add job
          </Button>
        </div>
        <p className="text-xs text-slate-500 mb-3">
          Each job has an ordered list of operations (machine + duration). Operations run in order.
        </p>
        <div className="space-y-4">
          {jobs.map((job, jobIndex) => (
            <Card key={jobIndex} className="p-4 border-slate-200">
              <div className="flex items-start justify-between gap-2 mb-3">
                <input
                  type="text"
                  value={job.name}
                  onChange={(e) => setJob(jobIndex, { ...job, name: e.target.value })}
                  placeholder="Job name"
                  className="flex-1 max-w-[200px] p-2 bg-white border border-slate-300 rounded text-sm font-medium focus:ring-2 focus:ring-indigo-500 outline-none"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => removeJob(jobIndex)}
                  disabled={jobs.length <= 1}
                  className="text-slate-500 hover:text-red-600"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
              <div className="space-y-2">
                {job.operations.map((op, opIndex) => (
                  <div key={opIndex} className="flex items-center gap-2 flex-wrap">
                    {machines.length > 0 ? (
                      <select
                        value={op.machine}
                        onChange={(e) => setOperation(jobIndex, opIndex, 'machine', e.target.value)}
                        className="p-2 bg-white border border-slate-300 rounded text-sm focus:ring-2 focus:ring-indigo-500 outline-none min-w-[80px]"
                      >
                        <option value="">Select machine</option>
                        {machines.map((m) => (
                          <option key={m} value={m}>
                            {m}
                          </option>
                        ))}
                      </select>
                    ) : (
                      <input
                        type="text"
                        value={op.machine}
                        onChange={(e) => setOperation(jobIndex, opIndex, 'machine', e.target.value)}
                        placeholder="Machine"
                        className="p-2 w-24 bg-white border border-slate-300 rounded text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                      />
                    )}
                    <input
                      type="number"
                      value={op.duration}
                      onChange={(e) =>
                        setOperation(jobIndex, opIndex, 'duration', e.target.value ? parseInt(e.target.value, 10) : 0)
                      }
                      min={1}
                      className="p-2 w-20 bg-white border border-slate-300 rounded text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                      placeholder="Dur"
                    />
                    <span className="text-xs text-slate-500">time units</span>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => removeOperation(jobIndex, opIndex)}
                      disabled={job.operations.length <= 1}
                      className="text-slate-500 hover:text-red-600 p-1"
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                ))}
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => addOperation(jobIndex)}
                  className="mt-1"
                >
                  <Plus className="w-3 h-3 mr-1" />
                  Add operation
                </Button>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
