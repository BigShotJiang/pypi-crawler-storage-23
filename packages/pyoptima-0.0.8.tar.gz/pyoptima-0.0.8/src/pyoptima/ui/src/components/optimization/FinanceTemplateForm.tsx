'use client';

import { useMemo } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { DataInputForm } from './DataInputForm';
import type { FieldConfig } from '@/lib/types';

export const FINANCE_TEMPLATE_IDS = ['execution', 'signal_sizing', 'rebalance', 'risk_budget', 'multi_account'] as const;
export type FinanceTemplateId = typeof FINANCE_TEMPLATE_IDS[number];

interface SectionSpec {
  title: string;
  description?: string;
  fieldNames: string[];
}

const SECTIONS: Record<FinanceTemplateId, SectionSpec[]> = {
  execution: [
    { title: 'Strategy', description: 'Execution algorithm and order details', fieldNames: ['strategy', 'symbol', 'total_quantity', 'side'] },
    { title: 'Horizon', description: 'Time horizon and intervals', fieldNames: ['horizon_minutes', 'interval_minutes'] },
    { title: 'Market data', description: 'ADV, price, volatility, volume profile', fieldNames: ['adv', 'price', 'volatility', 'bid_ask_spread', 'volume_profile'] },
    { title: 'Impact & POV', description: 'Almgren-Chriss and participation', fieldNames: ['risk_aversion', 'temporary_impact', 'permanent_impact', 'target_participation', 'max_participation'] },
  ],
  signal_sizing: [
    { title: 'Strategy', fieldNames: ['strategy'] },
    { title: 'Signals & data', description: 'Alpha signals and covariance', fieldNames: ['signals', 'symbols', 'covariance_matrix'] },
    { title: 'Limits', description: 'Exposure and position limits', fieldNames: ['max_notional', 'max_position', 'max_gross_exposure', 'max_net_exposure'] },
    { title: 'Parameters', fieldNames: ['risk_aversion', 'target_volatility'] },
    { title: 'Prices', fieldNames: ['prices'] },
  ],
  rebalance: [
    { title: 'Strategy', fieldNames: ['strategy'] },
    { title: 'Weights', description: 'Current and target weights', fieldNames: ['current_weights', 'target_weights', 'symbols'] },
    { title: 'Constraints', fieldNames: ['max_turnover', 'max_tracking_error'] },
    { title: 'Costs & liquidity', fieldNames: ['transaction_costs', 'adv', 'max_participation'] },
    { title: 'Optional', description: 'Covariance, lots, prices', fieldNames: ['covariance_matrix', 'lot_size', 'prices', 'portfolio_value'] },
  ],
  risk_budget: [
    { title: 'Strategy', fieldNames: ['strategy'] },
    { title: 'Weights & covariance', fieldNames: ['current_weights', 'covariance_matrix', 'symbols'] },
    { title: 'Risk limits', fieldNames: ['max_volatility', 'max_cvar', 'max_drawdown', 'max_sector_weight', 'max_concentration', 'asset_sectors'] },
    { title: 'Factors', fieldNames: ['factor_loadings', 'factor_names', 'max_factor_exposure'] },
    { title: 'Options', fieldNames: ['min_change', 'returns', 'confidence_level'] },
  ],
  multi_account: [
    { title: 'Strategy', fieldNames: ['strategy'] },
    { title: 'Accounts', description: 'Per-account constraints (array of objects: name, min_weight, max_weight, max_turnover, excluded_symbols, max_volatility, target_weights)', fieldNames: ['accounts'] },
    { title: 'Market data', fieldNames: ['expected_returns', 'covariance_matrix', 'symbols'] },
    { title: 'Objective', fieldNames: ['objective'] },
    { title: 'Optional', fieldNames: ['account_values', 'current_weights'] },
  ],
};

interface FinanceTemplateFormProps {
  templateId: FinanceTemplateId;
  fields: FieldConfig[];
  data: Record<string, unknown>;
  onChange: (data: Record<string, unknown>) => void;
}

export function FinanceTemplateForm({ templateId, fields, data, onChange }: FinanceTemplateFormProps) {
  const sections = SECTIONS[templateId];
  const fieldByName = useMemo(() => {
    const m: Record<string, FieldConfig> = {};
    fields.forEach(f => { m[f.name] = f; });
    return m;
  }, [fields]);

  const sectionedFields = useMemo(() => {
    const used = new Set<string>();
    const result: { section: SectionSpec; sectionFields: FieldConfig[] }[] = [];
    for (const section of sections) {
      const sectionFields: FieldConfig[] = [];
      for (const name of section.fieldNames) {
        const f = fieldByName[name];
        if (f) {
          sectionFields.push(f);
          used.add(name);
        }
      }
      if (sectionFields.length > 0) {
        result.push({ section, sectionFields });
      }
    }
    const rest = fields.filter(f => !used.has(f.name));
    if (rest.length > 0) {
      result.push({
        section: { title: 'Other', fieldNames: rest.map(f => f.name) },
        sectionFields: rest,
      });
    }
    return result;
  }, [sections, fields, fieldByName]);

  return (
    <div className="space-y-6">
      {sectionedFields.map(({ section, sectionFields }) => (
        <Card key={section.title} className="overflow-hidden">
          <div className="bg-slate-50 px-4 py-2.5 border-b border-slate-200">
            <h3 className="font-semibold text-slate-800 text-sm">{section.title}</h3>
            {section.description && (
              <p className="text-xs text-slate-500 mt-0.5">{section.description}</p>
            )}
          </div>
          <CardContent className="p-5">
            <DataInputForm
              fields={sectionFields}
              data={data}
              onChange={onChange}
            />
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
