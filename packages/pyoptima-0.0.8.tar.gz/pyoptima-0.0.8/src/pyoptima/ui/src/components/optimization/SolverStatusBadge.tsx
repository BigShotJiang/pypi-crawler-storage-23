'use client';

import { Circle, Loader2, CheckCircle, XCircle, Clock } from 'lucide-react';
import { cn, formatDuration, statusColor, statusBgColor, type SolverStatus } from '@/lib/utils';

interface SolverStatusBadgeProps {
  status: SolverStatus;
  solveTimeMs?: number;
  message?: string;
  className?: string;
}

const statusLabels: Record<SolverStatus, string> = {
  idle: 'Ready',
  solving: 'Solving…',
  optimal: 'Optimal',
  infeasible: 'Infeasible',
  error: 'Error',
  'time-limit': 'Time limit',
};

const statusIcons: Record<SolverStatus, React.ElementType> = {
  idle: Circle,
  solving: Loader2,
  optimal: CheckCircle,
  infeasible: XCircle,
  error: XCircle,
  'time-limit': Clock,
};

export function SolverStatusBadge({ status, solveTimeMs, message, className }: SolverStatusBadgeProps) {
  const Icon = statusIcons[status];
  return (
    <div
      className={cn(
        'inline-flex items-center gap-2 rounded-md border px-3 py-1.5 text-sm',
        statusBgColor(status),
        className
      )}
    >
      <Icon className={cn('h-4 w-4 shrink-0', statusColor(status), status === 'solving' && 'animate-spin')} />
      <span className={statusColor(status)}>{statusLabels[status]}</span>
      {solveTimeMs != null && status !== 'idle' && status !== 'solving' && (
        <span className="text-xs text-slate-500">({formatDuration(solveTimeMs)})</span>
      )}
      {message && (status === 'error' || status === 'infeasible') && (
        <span className="max-w-32 truncate text-xs text-slate-500" title={message}>
          {message}
        </span>
      )}
    </div>
  );
}
