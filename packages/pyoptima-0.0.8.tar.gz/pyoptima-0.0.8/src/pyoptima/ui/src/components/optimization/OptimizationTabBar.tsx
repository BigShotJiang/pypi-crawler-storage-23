'use client';

import { cn } from '@/lib/utils';
import { BarChart3, Settings, Settings2, Shield, Target } from 'lucide-react';

export type OptimizationTab = 'assetsData' | 'objective' | 'constraint' | 'solver' | 'results';

const TABS: { id: OptimizationTab; label: string; Icon: typeof BarChart3; portfolioTitle?: string }[] = [
  { id: 'assetsData', label: 'Assets & Data', Icon: Settings2, portfolioTitle: 'Returns, covariance matrix, and asset symbols' },
  { id: 'objective', label: 'Objective', Icon: Target, portfolioTitle: 'What to optimize (e.g. min volatility, max Sharpe)' },
  { id: 'constraint', label: 'Constraint', Icon: Shield, portfolioTitle: 'Weight and sector limits' },
  { id: 'solver', label: 'Solver', Icon: Settings, portfolioTitle: 'Solver choice and time limit' },
  { id: 'results', label: 'Results', Icon: BarChart3, portfolioTitle: 'Optimization output and charts' },
];

interface OptimizationTabBarProps {
  activeTab: OptimizationTab;
  onTabChange: (tab: OptimizationTab) => void;
  /** When "portfolio", use indigo active state; when "jobshop", use slate/amber. */
  template?: string;
}

export function OptimizationTabBar({ activeTab, onTabChange, template }: OptimizationTabBarProps) {
  const isPortfolio = template === 'portfolio';

  return (
    <div className="border-b border-slate-200 bg-white px-6">
      <nav className="flex gap-0" aria-label="Problem structure">
        {TABS.map((tab) => {
          const isActive = activeTab === tab.id;
          const Icon = tab.Icon;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => onTabChange(tab.id)}
              title={isPortfolio && tab.portfolioTitle ? tab.portfolioTitle : undefined}
              data-active={isActive ? true : undefined}
              className={cn(
                'flex items-center gap-2 rounded-none border-b-2 border-transparent px-4 py-3 text-sm font-medium transition-colors -mb-px',
                isActive
                  ? isPortfolio
                    ? 'border-indigo-500 text-indigo-600 bg-transparent'
                    : 'border-primary text-primary bg-transparent'
                  : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
              )}
            >
              <Icon className="h-4 w-4 shrink-0" />
              {tab.label}
            </button>
          );
        })}
      </nav>
    </div>
  );
}
