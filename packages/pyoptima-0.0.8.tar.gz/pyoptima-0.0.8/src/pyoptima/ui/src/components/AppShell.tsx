'use client';

import { useAuthInit } from '@/hooks/use-auth-init';
import AuthGuard from '@/components/AuthGuard';
import Navigation from '@/components/Navigation';
import ApiUnavailableBanner from '@/components/ApiUnavailableBanner';

export default function AppShell({ children }: { children: React.ReactNode }) {
  useAuthInit();

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      <ApiUnavailableBanner />
      <main
        className="flex-1"
        style={{ minHeight: 0, overflow: 'hidden', position: 'relative' }}
      >
        <AuthGuard>{children}</AuthGuard>
      </main>
    </div>
  );
}
