'use client';

import { useState, useCallback } from 'react';
import { Plus, Trash2, HelpCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import type { FieldConfig } from '@/lib/types';

interface DataInputFormProps {
  fields: FieldConfig[];
  data: Record<string, unknown>;
  onChange: (data: Record<string, unknown>) => void;
}

export function DataInputForm({ fields, data, onChange }: DataInputFormProps) {
  const updateField = useCallback((name: string, value: unknown) => {
    onChange({ ...data, [name]: value });
  }, [data, onChange]);

  return (
    <div className="space-y-4">
      {fields.map((field) => (
        <FieldRenderer
          key={field.name}
          field={field}
          value={data[field.name]}
          onChange={(value) => updateField(field.name, value)}
        />
      ))}
    </div>
  );
}

interface FieldRendererProps {
  field: FieldConfig;
  value: unknown;
  onChange: (value: unknown) => void;
}

function FieldRenderer({ field, value, onChange }: FieldRendererProps) {
  const [showHelp, setShowHelp] = useState(false);

  const renderInput = () => {
    switch (field.type) {
      case 'number':
        return (
          <input
            type="number"
            value={value as number ?? field.default ?? ''}
            onChange={(e) => onChange(e.target.value === '' ? undefined : parseFloat(e.target.value))}
            min={field.min}
            max={field.max}
            step={field.step ?? 1}
            className="w-full p-2.5 bg-white border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
          />
        );

      case 'text':
        return (
          <input
            type="text"
            value={value as string ?? ''}
            onChange={(e) => onChange(e.target.value || undefined)}
            className="w-full p-2.5 bg-white border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
          />
        );

      case 'select':
        return (
          <select
            value={value as string ?? field.default ?? ''}
            onChange={(e) => onChange(e.target.value)}
            className="w-full p-2.5 bg-white border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
          >
            {field.options?.map((opt) => (
              <option key={opt.value} value={opt.value}>
                {opt.label}
              </option>
            ))}
          </select>
        );

      case 'boolean':
        return (
          <button
            type="button"
            onClick={() => onChange(!value)}
            className={`w-10 h-5 rounded-full relative transition-colors ${
              value ? 'bg-indigo-600' : 'bg-slate-200'
            }`}
          >
            <div className={`w-3 h-3 bg-white rounded-full absolute top-1 transition-transform ${
              value ? 'right-1' : 'left-1'
            }`} />
          </button>
        );

      case 'array':
        return <ArrayInput value={value as number[] ?? []} onChange={onChange} />;

      case 'matrix':
        return <MatrixInput value={value as number[][] ?? []} onChange={onChange} />;

      case 'items':
        return <ItemsInput value={value as Array<{name: string; value: number; weight: number}> ?? []} onChange={onChange} />;

      case 'json':
      case 'map':
        return <JsonInput value={value} onChange={onChange} />;

      default:
        return (
          <input
            type="text"
            value={String(value ?? '')}
            onChange={(e) => onChange(e.target.value)}
            className="w-full p-2.5 bg-white border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
          />
        );
    }
  };

  return (
    <div className="space-y-1.5">
      <div className="flex items-center gap-2">
        <label className="text-sm font-medium text-slate-700">
          {field.label}
          {field.required && <span className="text-red-500 ml-1">*</span>}
        </label>
        {field.description && (
          <button
            type="button"
            onClick={() => setShowHelp(!showHelp)}
            className="text-slate-400 hover:text-slate-600"
          >
            <HelpCircle className="w-4 h-4" />
          </button>
        )}
      </div>
      {showHelp && field.description && (
        <p className="text-xs text-slate-500 bg-slate-50 p-2 rounded">{field.description}</p>
      )}
      {renderInput()}
    </div>
  );
}

// Array Input Component
function ArrayInput({ value, onChange }: { value: number[]; onChange: (v: number[]) => void }) {
  const [inputText, setInputText] = useState(value.join(', '));

  const handleBlur = () => {
    try {
      const parsed = inputText.split(',').map(s => parseFloat(s.trim())).filter(n => !isNaN(n));
      onChange(parsed);
    } catch {
      // Keep existing value on parse error
    }
  };

  return (
    <input
      type="text"
      value={inputText}
      onChange={(e) => setInputText(e.target.value)}
      onBlur={handleBlur}
      placeholder="1, 2, 3, 4"
      className="w-full p-2.5 bg-white border border-slate-300 rounded-lg text-sm font-mono focus:ring-2 focus:ring-indigo-500 outline-none"
    />
  );
}

// Matrix Input Component
function MatrixInput({ value, onChange }: { value: number[][]; onChange: (v: number[][]) => void }) {
  const [rows, setRows] = useState(value.length || 2);
  const [cols, setCols] = useState(value[0]?.length || 2);
  const [matrix, setMatrix] = useState<number[][]>(() => {
    if (value.length > 0) return value;
    return Array(rows).fill(null).map(() => Array(cols).fill(0));
  });

  const updateCell = (i: number, j: number, val: number) => {
    const newMatrix = matrix.map((row, ri) => 
      row.map((cell, ci) => (ri === i && ci === j) ? val : cell)
    );
    setMatrix(newMatrix);
    onChange(newMatrix);
  };

  const addRow = () => {
    const newMatrix = [...matrix, Array(cols).fill(0)];
    setRows(rows + 1);
    setMatrix(newMatrix);
    onChange(newMatrix);
  };

  const addCol = () => {
    const newMatrix = matrix.map(row => [...row, 0]);
    setCols(cols + 1);
    setMatrix(newMatrix);
    onChange(newMatrix);
  };

  const removeRow = (idx: number) => {
    if (matrix.length <= 1) return;
    const newMatrix = matrix.filter((_, i) => i !== idx);
    setRows(rows - 1);
    setMatrix(newMatrix);
    onChange(newMatrix);
  };

  const removeCol = (idx: number) => {
    if (matrix[0].length <= 1) return;
    const newMatrix = matrix.map(row => row.filter((_, i) => i !== idx));
    setCols(cols - 1);
    setMatrix(newMatrix);
    onChange(newMatrix);
  };

  return (
    <div className="space-y-2">
      <div className="overflow-x-auto">
        <table className="text-sm">
          <tbody>
            {matrix.map((row, i) => (
              <tr key={i}>
                {row.map((cell, j) => (
                  <td key={j} className="p-0.5">
                    <input
                      type="number"
                      value={cell}
                      onChange={(e) => updateCell(i, j, parseFloat(e.target.value) || 0)}
                      className="w-16 p-1.5 border border-slate-200 rounded text-center text-xs font-mono focus:ring-2 focus:ring-indigo-500 outline-none"
                    />
                  </td>
                ))}
                <td className="p-0.5">
                  <button
                    type="button"
                    onClick={() => removeRow(i)}
                    className="p-1 text-slate-300 hover:text-red-500"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="flex gap-2">
        <Button type="button" variant="outline" size="sm" onClick={addRow}>
          <Plus className="w-3 h-3 mr-1" /> Row
        </Button>
        <Button type="button" variant="outline" size="sm" onClick={addCol}>
          <Plus className="w-3 h-3 mr-1" /> Column
        </Button>
      </div>
    </div>
  );
}

// Items Input Component (for Knapsack)
function ItemsInput({ 
  value, 
  onChange 
}: { 
  value: Array<{name: string; value: number; weight: number}>; 
  onChange: (v: Array<{name: string; value: number; weight: number}>) => void 
}) {
  const addItem = () => {
    onChange([...value, { name: `Item ${value.length + 1}`, value: 10, weight: 5 }]);
  };

  const updateItem = (idx: number, field: string, val: string | number) => {
    const newItems = value.map((item, i) => 
      i === idx ? { ...item, [field]: val } : item
    );
    onChange(newItems);
  };

  const removeItem = (idx: number) => {
    onChange(value.filter((_, i) => i !== idx));
  };

  return (
    <div className="space-y-2">
      <Card className="overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-slate-500 font-medium">
            <tr>
              <th className="px-3 py-2 text-left">Name</th>
              <th className="px-3 py-2 text-right">Value</th>
              <th className="px-3 py-2 text-right">Weight</th>
              <th className="px-3 py-2 w-8"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {value.map((item, i) => (
              <tr key={i} className="hover:bg-slate-50">
                <td className="px-3 py-1.5">
                  <input
                    type="text"
                    value={item.name}
                    onChange={(e) => updateItem(i, 'name', e.target.value)}
                    className="w-full bg-transparent border-none p-1 focus:ring-2 focus:ring-indigo-500 rounded"
                  />
                </td>
                <td className="px-3 py-1.5">
                  <input
                    type="number"
                    value={item.value}
                    onChange={(e) => updateItem(i, 'value', parseFloat(e.target.value) || 0)}
                    className="w-20 text-right bg-transparent border-none p-1 font-mono text-emerald-600 focus:ring-2 focus:ring-indigo-500 rounded"
                  />
                </td>
                <td className="px-3 py-1.5">
                  <input
                    type="number"
                    value={item.weight}
                    onChange={(e) => updateItem(i, 'weight', parseFloat(e.target.value) || 0)}
                    className="w-20 text-right bg-transparent border-none p-1 font-mono focus:ring-2 focus:ring-indigo-500 rounded"
                  />
                </td>
                <td className="px-3 py-1.5">
                  <button
                    type="button"
                    onClick={() => removeItem(i)}
                    className="text-slate-300 hover:text-red-500"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
      <Button type="button" variant="outline" size="sm" onClick={addItem}>
        <Plus className="w-3 h-3 mr-1" /> Add Item
      </Button>
    </div>
  );
}

// JSON Input Component (for complex nested data)
function JsonInput({ value, onChange }: { value: unknown; onChange: (v: unknown) => void }) {
  const [text, setText] = useState(JSON.stringify(value, null, 2) || '');
  const [error, setError] = useState<string | null>(null);

  const handleBlur = () => {
    try {
      const parsed = JSON.parse(text);
      onChange(parsed);
      setError(null);
    } catch (e) {
      setError('Invalid JSON');
    }
  };

  return (
    <div className="space-y-1">
      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        onBlur={handleBlur}
        rows={6}
        className={`w-full p-2.5 bg-white border rounded-lg text-sm font-mono focus:ring-2 focus:ring-indigo-500 outline-none ${
          error ? 'border-red-300' : 'border-slate-300'
        }`}
      />
      {error && <p className="text-xs text-red-500">{error}</p>}
    </div>
  );
}

export default DataInputForm;
