'use client';

import { CheckCircle, XCircle, Clock, TrendingUp, Target, Package, Users, MapPin, Truck, Calendar, Building, Download } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend
} from 'recharts';
import type { OptimizeResponse } from '@/lib/types';
import { formatDuration } from '@/lib/utils';

interface ResultsDisplayProps {
  response: OptimizeResponse;
  template: string;
}

const COLORS = ['#4f46e5', '#06b6d4', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#14b8a6'];

export function ResultsDisplay({ response, template }: ResultsDisplayProps) {
  const { status, result, duration_ms, solver } = response;
  const isOptimal = status === 'optimal';
  const solveTime = result?.solve_time != null ? Number(result.solve_time) : null;
  const gap = result?.gap != null ? Number(result.gap) : null;
  const solverMessage = result?.solver_message ?? result?.message;
  const msg = typeof solverMessage === 'string' ? solverMessage : null;

  return (
    <div className="space-y-6">
      {/* Status Header */}
      <Card className={`border-l-4 ${isOptimal ? 'border-l-emerald-500' : 'border-l-amber-500'}`}>
        <CardContent className="py-4">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div className="flex items-center gap-3">
              {isOptimal ? (
                <CheckCircle className="w-8 h-8 text-emerald-500" />
              ) : (
                <XCircle className="w-8 h-8 text-amber-500" />
              )}
              <div>
                <h3 className="font-bold text-lg text-slate-800">
                  {isOptimal ? 'Optimal Solution Found' : `Status: ${status}`}
                </h3>
                <p className="text-sm text-slate-500">
                  Solved in {solveTime != null ? `${(solveTime * 1000).toFixed(1)}ms` : `${duration_ms.toFixed(1)}ms`} using {solver}
                </p>
                {(gap != null || msg) && (
                  <div className="mt-1.5 flex flex-wrap gap-3 text-xs text-slate-500">
                    {gap != null && <span>MIP gap: {gap.toExponential(2)}</span>}
                    {msg && <span title={msg}>Solver: {msg.length > 60 ? `${msg.slice(0, 60)}…` : msg}</span>}
                  </div>
                )}
              </div>
            </div>
            <div className="flex items-center gap-2 text-sm text-slate-500">
              <Clock className="w-4 h-4" />
              {new Date().toLocaleTimeString()}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Template-specific results */}
      {renderTemplateResults(template, result, { duration_ms })}
    </div>
  );
}

function renderTemplateResults(
  template: string,
  result: Record<string, unknown>,
  meta?: { duration_ms?: number }
) {
  switch (template) {
    case 'knapsack':
      return <KnapsackResults result={result} />;
    case 'lp':
    case 'mip':
    case 'qp':
      return <LPResults result={result} />;
    case 'portfolio':
      return <PortfolioResults result={result} durationMs={meta?.duration_ms} />;
    case 'assignment':
      return <AssignmentResults result={result} />;
    case 'tsp':
      return <TSPResults result={result} />;
    case 'transportation':
      return <TransportationResults result={result} />;
    case 'jobshop':
      return <JobShopResults result={result} />;
    default:
      return <GenericResults result={result} />;
  }
}

// Knapsack Results
function KnapsackResults({ result }: { result: Record<string, unknown> }) {
  const totalValue = result.total_value as number;
  const totalWeight = result.total_weight as number;
  const selectedItems = result.selected_items as Array<{name: string; value: number; weight: number; quantity: number}> || [];

  const chartData = selectedItems.map(item => ({
    name: item.name,
    value: item.value * (item.quantity || 1),
    weight: item.weight * (item.quantity || 1),
  }));

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
      {/* Summary Cards */}
      <Card className="bg-gradient-to-br from-indigo-600 to-violet-700 text-white border-none">
        <CardContent className="py-4">
          <div className="flex items-center gap-3">
            <Package className="w-8 h-8 opacity-80" />
            <div>
              <p className="text-indigo-100 text-xs font-medium uppercase">Total Value</p>
              <p className="text-3xl font-bold">{totalValue.toLocaleString()}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="py-4">
          <div className="flex items-center gap-3">
            <Target className="w-8 h-8 text-slate-400" />
            <div>
              <p className="text-slate-500 text-xs font-medium uppercase">Total Weight</p>
              <p className="text-3xl font-bold text-slate-800">{totalWeight.toLocaleString()}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="py-4">
          <div className="flex items-center gap-3">
            <TrendingUp className="w-8 h-8 text-emerald-500" />
            <div>
              <p className="text-slate-500 text-xs font-medium uppercase">Items Selected</p>
              <p className="text-3xl font-bold text-slate-800">{selectedItems.length}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Chart */}
      <Card className="lg:col-span-2">
        <CardHeader>
          <CardTitle className="text-base">Value by Item</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip />
                <Bar dataKey="value" fill="#4f46e5" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Selected Items List */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Selected Items</CardTitle>
        </CardHeader>
        <CardContent className="max-h-64 overflow-y-auto">
          <div className="space-y-2">
            {selectedItems.map((item, i) => (
              <div key={i} className="flex items-center justify-between p-2 bg-slate-50 rounded">
                <span className="font-medium text-sm">{item.name}</span>
                <div className="text-xs text-slate-500">
                  <span className="text-emerald-600 font-medium">${item.value}</span>
                  {' · '}
                  <span>{item.weight}kg</span>
                  {item.quantity > 1 && <span className="ml-1">×{item.quantity}</span>}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// LP/MIP/QP Results
function LPResults({ result }: { result: Record<string, unknown> }) {
  const objectiveValue = result.objective_value as number;
  const solution = result.solution as Record<string, number> || {};

  const chartData = Object.entries(solution).map(([name, value]) => ({
    name,
    value: Math.abs(value),
  }));

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
      <Card className="bg-gradient-to-br from-indigo-600 to-violet-700 text-white border-none">
        <CardContent className="py-6">
          <p className="text-indigo-100 text-xs font-medium uppercase mb-1">Objective Value</p>
          <p className="text-4xl font-bold">{objectiveValue.toFixed(4)}</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Variable Values</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 max-h-48 overflow-y-auto">
            {Object.entries(solution).map(([name, value]) => (
              <div key={name} className="flex justify-between items-center">
                <span className="font-mono text-sm text-slate-600">{name}</span>
                <span className="font-mono font-bold text-slate-800">{value.toFixed(4)}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {chartData.length > 0 && (
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">Solution Visualization</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                  <XAxis type="number" tick={{ fontSize: 12 }} />
                  <YAxis dataKey="name" type="category" tick={{ fontSize: 12 }} width={60} />
                  <Tooltip />
                  <Bar dataKey="value" fill="#4f46e5" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

// Portfolio Results
function PortfolioResults({
  result,
  durationMs,
}: {
  result: Record<string, unknown>;
  durationMs?: number;
}) {
  const weights = (result?.weights as Record<string, number>) || {};
  const portfolioReturn = typeof result?.portfolio_return === 'number' ? result.portfolio_return : 0;
  const portfolioVolatility = typeof result?.portfolio_volatility === 'number' ? result.portfolio_volatility : 0;
  const sharpeRatio = typeof result?.sharpe_ratio === 'number' ? result.sharpe_ratio : 0;
  const objectiveValue = result?.objective_value != null ? Number(result.objective_value) : null;
  const riskContributions = (result?.risk_contributions as Record<string, number>) || undefined;
  const sortinoRatio = result?.sortino_ratio != null ? Number(result.sortino_ratio) : null;
  const netReturn = result?.net_return != null ? Number(result.net_return) : null;

  const pieData = Object.entries(weights)
    .filter(([_, v]) => v > 0.001)
    .map(([name, value]) => ({
      name,
      value: Math.round(value * 10000) / 100,
    }));

  const riskChartData = riskContributions
    ? Object.entries(riskContributions).map(([name, value]) => ({ name, value: Number(value) || 0 }))
    : [];

  const weightEntries = Object.entries(weights)
    .filter(([, v]) => v > 0.001)
    .sort((a, b) => b[1] - a[1]);

  const downloadJson = () => {
    const blob = new Blob([JSON.stringify(result, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'portfolio-result.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  const downloadCsv = () => {
    const rows = weightEntries.map(([symbol, weight]) => {
      const rc = riskContributions?.[symbol];
      return rc != null ? `${symbol},${(weight * 100).toFixed(4)},${(Number(rc) * 100).toFixed(4)}` : `${symbol},${(weight * 100).toFixed(4)}`;
    });
    const header = riskContributions ? 'symbol,weight_pct,risk_contribution_pct' : 'symbol,weight_pct';
    const csv = [header, ...rows].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'portfolio-weights.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  const summaryParts: string[] = [];
  if (typeof portfolioReturn === 'number' && !Number.isNaN(portfolioReturn)) {
    summaryParts.push(`expected return ${(portfolioReturn * 100).toFixed(2)}%`);
  }
  if (typeof portfolioVolatility === 'number' && !Number.isNaN(portfolioVolatility)) {
    summaryParts.push(`volatility ${(portfolioVolatility * 100).toFixed(2)}%`);
  }
  if (typeof sharpeRatio === 'number' && !Number.isNaN(sharpeRatio)) {
    summaryParts.push(`Sharpe ratio ${sharpeRatio.toFixed(2)}`);
  }
  const summarySentence = summaryParts.length > 0
    ? `Portfolio with ${summaryParts.join(', ')}. ${pieData.length} position${pieData.length !== 1 ? 's' : ''}.`
    : null;

  return (
    <div className="space-y-5">
      {/* One-line summary */}
      {summarySentence && (
        <p className="text-slate-600 text-sm leading-relaxed">
          {summarySentence}
        </p>
      )}

      {/* KPI cards — reference style: label text-xs text-muted, value text-2xl font-bold font-mono */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-4">
            <p className="text-xs text-slate-500 mb-1">Expected Return</p>
            <p className="text-2xl font-bold font-mono text-indigo-600">{(portfolioReturn * 100).toFixed(2)}%</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-xs text-slate-500 mb-1">Volatility</p>
            <p className="text-2xl font-bold font-mono text-slate-800">{(portfolioVolatility * 100).toFixed(2)}%</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-xs text-slate-500 mb-1">Sharpe Ratio</p>
            <p className="text-2xl font-bold font-mono text-slate-800">{sharpeRatio.toFixed(2)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-xs text-slate-500 mb-1">Positions</p>
            <p className="text-2xl font-bold font-mono text-slate-800">{pieData.length}</p>
          </CardContent>
        </Card>
        {durationMs != null && (
          <Card>
            <CardContent className="p-4">
              <p className="text-xs text-slate-500 mb-1">Solve Time</p>
              <p className="text-2xl font-bold font-mono text-slate-800">{formatDuration(durationMs)}</p>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Objective value + optional metrics */}
      {(objectiveValue != null || sortinoRatio != null || netReturn != null) && (
        <div className="flex flex-wrap items-center gap-4 text-sm">
          {objectiveValue != null && !Number.isNaN(objectiveValue) && (
            <span className="text-slate-600">
              <span className="font-medium text-slate-700">Objective value:</span>{' '}
              <span className="font-mono">{objectiveValue.toFixed(6)}</span>
            </span>
          )}
          {sortinoRatio != null && !Number.isNaN(sortinoRatio) && (
            <span className="text-slate-600">
              <span className="font-medium text-slate-700">Sortino ratio:</span>{' '}
              <span className="font-mono">{sortinoRatio.toFixed(2)}</span>
            </span>
          )}
          {netReturn != null && !Number.isNaN(netReturn) && (
            <span className="text-slate-600">
              <span className="font-medium text-slate-700">Net return:</span>{' '}
              <span className="font-mono">{(netReturn * 100).toFixed(2)}%</span>
            </span>
          )}
        </div>
      )}

      {/* Export */}
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-xs font-medium text-slate-500 uppercase tracking-wide">Export</span>
        <button
          type="button"
          onClick={downloadJson}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
        >
          <Download className="w-4 h-4" />
          JSON
        </button>
        <button
          type="button"
          onClick={downloadCsv}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
        >
          <Download className="w-4 h-4" />
          CSV
        </button>
      </div>

      {/* Pie Chart + Weights table */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Allocation</CardTitle>
            <p className="text-xs text-slate-500 font-normal">Portfolio weights by asset.</p>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    outerRadius={80}
                    label={({ name, value }) => `${name}: ${value}%`}
                    labelLine={false}
                  >
                    {pieData.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value: number) => `${value}%`} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Weights</CardTitle>
            <p className="text-xs text-slate-500 font-normal">Sorted by weight; optional risk contribution.</p>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto max-h-64 overflow-y-auto">
              <table className="w-full text-sm border-collapse">
                <thead>
                  <tr className="border-b border-slate-200">
                    <th className="text-left py-2 pr-3 font-medium text-slate-600">Symbol</th>
                    <th className="text-right py-2 px-2 font-medium text-slate-600">Weight</th>
                    {riskContributions && Object.keys(riskContributions).length > 0 && (
                      <th className="text-right py-2 pl-2 font-medium text-slate-600">Risk contrib.</th>
                    )}
                  </tr>
                </thead>
                <tbody>
                  {weightEntries.map(([name, value]) => (
                    <tr key={name} className="border-b border-slate-100">
                      <td className="py-2 pr-3 font-medium text-slate-800">{name}</td>
                      <td className="text-right py-2 px-2 font-mono text-slate-700">
                        {(value * 100).toFixed(2)}%
                      </td>
                      {riskContributions && riskContributions[name] != null && (
                        <td className="text-right py-2 pl-2 font-mono text-slate-600">
                          {(Number(riskContributions[name]) * 100).toFixed(2)}%
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Risk contribution chart (when present) */}
      {riskChartData.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Risk contribution</CardTitle>
            <p className="text-xs text-slate-500 font-normal">Per-asset contribution to portfolio variance (risk parity aims for equal bars).</p>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={riskChartData} layout="vertical" margin={{ left: 60 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                  <XAxis type="number" tickFormatter={(v) => `${(v * 100).toFixed(1)}%`} tick={{ fontSize: 12 }} />
                  <YAxis dataKey="name" type="category" tick={{ fontSize: 12 }} width={60} />
                  <Tooltip formatter={(v: number) => `${(v * 100).toFixed(2)}%`} />
                  <Bar dataKey="value" fill="#06b6d4" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

// Assignment Results
function AssignmentResults({ result }: { result: Record<string, unknown> }) {
  const assignments = result.assignments as Record<string, string> || {};
  const totalCost = result.total_cost as number;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
      <Card className="bg-gradient-to-br from-indigo-600 to-violet-700 text-white border-none">
        <CardContent className="py-4">
          <div className="flex items-center gap-3">
            <Users className="w-8 h-8 opacity-80" />
            <div>
              <p className="text-indigo-100 text-xs font-medium uppercase">Total Cost</p>
              <p className="text-3xl font-bold">{totalCost.toLocaleString()}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="lg:col-span-2">
        <CardHeader>
          <CardTitle className="text-base">Assignments</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-2">
            {Object.entries(assignments).map(([worker, task]) => (
              <div key={worker} className="flex items-center justify-between p-2 bg-slate-50 rounded">
                <span className="font-medium text-sm">{worker}</span>
                <span className="text-indigo-600 font-medium text-sm">→ {task}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// TSP Results
function TSPResults({ result }: { result: Record<string, unknown> }) {
  const tour = result.tour as string[] || [];
  const totalDistance = result.total_distance as number;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
      <Card className="bg-gradient-to-br from-indigo-600 to-violet-700 text-white border-none">
        <CardContent className="py-4">
          <div className="flex items-center gap-3">
            <MapPin className="w-8 h-8 opacity-80" />
            <div>
              <p className="text-indigo-100 text-xs font-medium uppercase">Total Distance</p>
              <p className="text-3xl font-bold">{totalDistance.toLocaleString()}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="lg:col-span-2">
        <CardHeader>
          <CardTitle className="text-base">Optimal Tour</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap items-center gap-2">
            {tour.map((city, i) => (
              <div key={i} className="flex items-center">
                <span className="px-3 py-1.5 bg-indigo-100 text-indigo-700 rounded-full text-sm font-medium">
                  {city}
                </span>
                {i < tour.length - 1 && <span className="mx-2 text-slate-400">→</span>}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Transportation Results
function TransportationResults({ result }: { result: Record<string, unknown> }) {
  const shipments = result.shipments as Array<{from: string; to: string; quantity: number}> || [];
  const totalCost = result.total_cost as number;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
      <Card className="bg-gradient-to-br from-indigo-600 to-violet-700 text-white border-none">
        <CardContent className="py-4">
          <div className="flex items-center gap-3">
            <Truck className="w-8 h-8 opacity-80" />
            <div>
              <p className="text-indigo-100 text-xs font-medium uppercase">Total Cost</p>
              <p className="text-3xl font-bold">{totalCost.toLocaleString()}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="lg:col-span-2">
        <CardHeader>
          <CardTitle className="text-base">Shipments</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {shipments.filter(s => s.quantity > 0).map((ship, i) => (
              <div key={i} className="flex items-center justify-between p-2 bg-slate-50 rounded">
                <span className="text-sm">
                  <span className="font-medium">{ship.from}</span>
                  <span className="mx-2 text-slate-400">→</span>
                  <span className="font-medium">{ship.to}</span>
                </span>
                <span className="font-mono text-indigo-600">{ship.quantity} units</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Job Shop: slot is [job_name, o_idx, start, end] (API serializes tuples as arrays)
type MachineSlot = [string, number, number, number];

function buildMachineSchedules(result: Record<string, unknown>): Record<string, MachineSlot[]> {
  const raw = result.machine_schedules as Record<string, unknown[]> | undefined;
  if (raw && typeof raw === 'object') {
    const out: Record<string, MachineSlot[]> = {};
    for (const [machine, arr] of Object.entries(raw)) {
      if (Array.isArray(arr)) {
        out[machine] = arr.map((item) => {
          if (Array.isArray(item) && item.length >= 4) {
            return [String(item[0]), Number(item[1]), Number(item[2]), Number(item[3])] as MachineSlot;
          }
          return ['', 0, 0, 0] as MachineSlot;
        }).filter(([j]) => j);
      }
    }
    return out;
  }
  // Fallback: build from schedule (by job: array of { machine, start, end })
  const schedule = result.schedule as Record<string, Array<{ machine: string; start: number; end: number }>> | undefined;
  if (!schedule || typeof schedule !== 'object') return {};
  const byMachine: Record<string, MachineSlot[]> = {};
  for (const [jobName, ops] of Object.entries(schedule)) {
    if (!Array.isArray(ops)) continue;
    ops.forEach((op, oIdx) => {
      if (op && typeof op === 'object' && 'machine' in op) {
        const m = String(op.machine);
        if (!byMachine[m]) byMachine[m] = [];
        byMachine[m].push([jobName, oIdx, Number(op.start), Number(op.end)]);
      }
    });
  }
  for (const arr of Object.values(byMachine)) {
    arr.sort((a, b) => a[2] - b[2]);
  }
  return byMachine;
}

// Job Shop Results with Gantt
function JobShopResults({ result }: { result: Record<string, unknown> }) {
  const makespan = Number(result.makespan) || 0;
  const machineSchedules = buildMachineSchedules(result);
  const machines = Object.keys(machineSchedules).sort();

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="bg-gradient-to-br from-indigo-600 to-violet-700 text-white border-none">
          <CardContent className="py-4">
            <div className="flex items-center gap-3">
              <Calendar className="w-8 h-8 opacity-80" />
              <div>
                <p className="text-indigo-100 text-xs font-medium uppercase">Makespan</p>
                <p className="text-3xl font-bold">{makespan}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Gantt view (by machine)</CardTitle>
          <p className="text-xs text-slate-500 font-normal">Timeline 0 to makespan; each block is one operation.</p>
        </CardHeader>
        <CardContent>
          {machines.length === 0 ? (
            <pre className="text-xs font-mono bg-slate-50 p-4 rounded overflow-auto max-h-48">
              {JSON.stringify(result, null, 2)}
            </pre>
          ) : (
            <div className="space-y-4">
              {machines.map((machine) => {
                const slots = machineSchedules[machine] || [];
                return (
                  <div key={machine} className="space-y-1.5">
                    <p className="text-sm font-medium text-slate-700">{machine}</p>
                    <div
                      className="relative h-10 bg-slate-100 rounded overflow-hidden"
                      style={{ minWidth: 400 }}
                    >
                      {slots.map(([jobName, oIdx, start, end], i) => {
                        const left = makespan > 0 ? (start / makespan) * 100 : 0;
                        const width = makespan > 0 ? Math.max(((end - start) / makespan) * 100, 2) : 0;
                        return (
                          <div
                            key={`${jobName}-${oIdx}-${i}`}
                            className="absolute top-1 bottom-1 rounded flex items-center justify-center text-xs font-medium text-white overflow-hidden"
                            style={{
                              left: `${left}%`,
                              width: `${width}%`,
                              backgroundColor: COLORS[i % COLORS.length],
                              minWidth: width < 5 ? '28px' : undefined,
                            }}
                            title={`${jobName} Op${oIdx + 1}: ${start}–${end}`}
                          >
                            {width >= 8 ? `${jobName} (${start}–${end})` : `${jobName}`}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
              {makespan > 0 && (
                <div className="flex justify-between text-xs text-slate-500 px-1">
                  <span>0</span>
                  <span>{makespan}</span>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

// Generic Results (fallback)
function GenericResults({ result }: { result: Record<string, unknown> }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">Results</CardTitle>
      </CardHeader>
      <CardContent>
        <pre className="text-xs font-mono bg-slate-50 p-4 rounded-lg overflow-auto max-h-96">
          {JSON.stringify(result, null, 2)}
        </pre>
      </CardContent>
    </Card>
  );
}

export default ResultsDisplay;
