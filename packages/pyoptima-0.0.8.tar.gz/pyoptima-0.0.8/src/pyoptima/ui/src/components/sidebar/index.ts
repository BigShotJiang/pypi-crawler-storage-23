export { CollapsibleSidebar } from './CollapsibleSidebar';
export type { SidebarSection, SidebarItem } from './CollapsibleSidebar';
