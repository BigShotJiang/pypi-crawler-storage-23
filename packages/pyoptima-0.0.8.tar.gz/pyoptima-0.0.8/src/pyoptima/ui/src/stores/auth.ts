import { create } from 'zustand';
import { devtools } from 'zustand/middleware';
import { getApiBaseUrl } from '@/lib/settings';
import { clearAccessToken, getAccessToken, setAccessToken } from '@/lib/auth-storage';
import { AUTH_CHECK_TIMEOUT_MS, LOGIN_REQUEST_TIMEOUT_MS, ROUTES } from '@/lib/constants';

export interface AuthMeResponse {
  username: string;
  auth_disabled?: boolean;
}

function isConnectionError(err: unknown): boolean {
  if (err instanceof Error) {
    return (
      (err as { status?: number }).status === 0 ||
      err.message.includes('Unable to connect') ||
      err.message.includes('timed out') ||
      err.message.includes('Failed to fetch')
    );
  }
  return false;
}

async function fetchWithTimeout(
  url: string,
  options: RequestInit,
  timeoutMs: number,
): Promise<Response> {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { ...options, signal: controller.signal });
    return res;
  } finally {
    clearTimeout(id);
  }
}

export interface AuthState {
  user: AuthMeResponse | null;
  loading: boolean;
  apiUnavailable: boolean;
  checkAuth: () => Promise<void>;
  login: (username: string, password: string) => Promise<string>;
  logout: () => void;
  clearUser: () => void;
}

export const useAuthStore = create<AuthState>()(
  devtools(
    (set, get) => ({
      user: null,
      loading: true,
      apiUnavailable: false,

      checkAuth: async () => {
        const base = getApiBaseUrl().replace(/\/$/, '');
        const url = `${base}/api/v1/auth/me`;
        const token = getAccessToken();
        try {
          const res = await fetchWithTimeout(
            url,
            {
              method: 'GET',
              headers: token ? { Authorization: `Bearer ${token}` } : {},
            },
            AUTH_CHECK_TIMEOUT_MS,
          );
          if (res.ok) {
            const me = await res.json();
            set({ user: me, apiUnavailable: false });
          } else if (res.status === 401) {
            set({ user: null, apiUnavailable: false });
          } else {
            set({ user: null, apiUnavailable: false });
          }
        } catch (err) {
          if (isConnectionError(err)) {
            set({ user: null, apiUnavailable: true });
          } else {
            set({ user: null, apiUnavailable: false });
          }
        } finally {
          set({ loading: false });
        }
      },

      login: async (username, password) => {
        const base = getApiBaseUrl().replace(/\/$/, '');
        const res = await fetchWithTimeout(
          `${base}/api/v1/auth/login`,
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password }),
          },
          LOGIN_REQUEST_TIMEOUT_MS,
        );
        if (!res.ok) {
          const data = await res.json().catch(() => ({}));
          throw new Error(data.detail || `Login failed: ${res.status}`);
        }
        const data = await res.json();
        setAccessToken(data.access_token);
        set({ user: { username, auth_disabled: false }, apiUnavailable: false });
        const returnUrl =
          typeof window !== 'undefined'
            ? sessionStorage.getItem('pyoptima_return_url')
            : null;
        if (typeof window !== 'undefined') sessionStorage.removeItem('pyoptima_return_url');
        return returnUrl || ROUTES.HOME;
      },

      logout: () => {
        clearAccessToken();
        set({ user: null, apiUnavailable: false });
      },

      clearUser: () => set({ user: null }),
    }),
    { name: 'auth' },
  ),
);

export const selectUser = (s: AuthState) => s.user;
export const selectLoading = (s: AuthState) => s.loading;
export const selectApiUnavailable = (s: AuthState) => s.apiUnavailable;
export const selectIsAuthenticated = (s: AuthState) => !!s.user;
export const selectAuthDisabled = (s: AuthState) => s.user?.auth_disabled === true;
export const selectLogin = (s: AuthState) => s.login;
export const selectLogout = (s: AuthState) => s.logout;
export const selectCheckAuth = (s: AuthState) => s.checkAuth;
