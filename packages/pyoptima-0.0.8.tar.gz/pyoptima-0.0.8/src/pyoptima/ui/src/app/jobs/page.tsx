'use client';

import { useState, useEffect } from 'react';
import { PageHeader } from '@/components/common';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { PageLoading, TableSkeleton } from '@/components/LoadingSpinner';
import ErrorDisplay from '@/components/ErrorDisplay';
import { api } from '@/lib/api';
import type { JobResponse } from '@/lib/types';
import { RefreshCw, Trash2, Clock, CheckCircle, XCircle, AlertCircle, Loader2, ChevronDown, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

const STATUS_CONFIG: Record<string, { icon: typeof CheckCircle; color: string; bg: string; animate?: boolean }> = {
  completed: { icon: CheckCircle, color: 'text-emerald-600', bg: 'bg-emerald-100' },
  running: { icon: Loader2, color: 'text-blue-600', bg: 'bg-blue-100', animate: true },
  queued: { icon: Clock, color: 'text-amber-600', bg: 'bg-amber-100' },
  failed: { icon: XCircle, color: 'text-red-600', bg: 'bg-red-100' },
  cancelled: { icon: AlertCircle, color: 'text-slate-600', bg: 'bg-slate-100' },
};

export default function JobsPage() {
  const [jobs, setJobs] = useState<JobResponse[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [expandedJob, setExpandedJob] = useState<string | null>(null);
  const [stats, setStats] = useState<Record<string, number>>({});

  const fetchJobs = async () => {
    try {
      setLoading(true);
      setError(null);
      const [jobsResult, statsResult] = await Promise.all([
        api.listJobs(undefined, 50),
        api.getJobStats().catch(() => ({})),
      ]);
      setJobs(jobsResult);
      setStats(statsResult);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to load jobs';
      setError(message);
      console.error('Error loading jobs:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (jobId: string) => {
    try {
      await api.deleteJob(jobId);
      setJobs(jobs.filter(j => j.job_id !== jobId));
    } catch (err) {
      console.error('Error deleting job:', err);
    }
  };

  const handleCancel = async (jobId: string) => {
    try {
      await api.cancelJob(jobId);
      fetchJobs();
    } catch (err) {
      console.error('Error cancelling job:', err);
    }
  };

  useEffect(() => {
    fetchJobs();
    
    // Poll for updates on running jobs
    const interval = setInterval(() => {
      if (jobs.some(j => j.status === 'running' || j.status === 'queued')) {
        fetchJobs();
      }
    }, 3000);
    
    return () => clearInterval(interval);
  }, []);

  if (loading && jobs.length === 0) {
    return <PageLoading message="Loading jobs..." />;
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <PageHeader
          title="Optimization Jobs"
          description="Track and manage your optimization runs"
          actions={
            <Button onClick={fetchJobs} variant="outline" disabled={loading}>
              <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          }
        />

        {/* Stats Summary */}
        {Object.keys(stats).length > 0 && (
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mt-6 mb-6">
            {Object.entries(STATUS_CONFIG).map(([status, config]) => {
              const Icon = config.icon;
              const count = stats[status] || 0;
              
              return (
                <Card key={status} className="p-4">
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-full ${config.bg} flex items-center justify-center`}>
                      <Icon className={`w-4 h-4 ${config.color} ${config.animate ? 'animate-spin' : ''}`} />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-slate-800">{count}</p>
                      <p className="text-xs text-slate-500 capitalize">{status}</p>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        )}

        {error && (
          <div className="mb-6">
            <ErrorDisplay error={new Error(error)} title="Failed to load jobs" />
            <Button onClick={fetchJobs} variant="outline" className="mt-4">
              Retry
            </Button>
          </div>
        )}

        {!error && jobs.length === 0 && (
          <Card className="mt-6">
            <CardContent className="py-12 text-center">
              <Clock className="w-12 h-12 text-slate-300 mx-auto mb-4" />
              <p className="text-muted-foreground">No jobs found. Run an optimization to see jobs here.</p>
            </CardContent>
          </Card>
        )}

        {!error && jobs.length > 0 && (
          <div className="space-y-3 mt-6">
            {jobs.map((job) => {
              const statusConfig = STATUS_CONFIG[job.status] || STATUS_CONFIG.cancelled;
              const StatusIcon = statusConfig.icon;
              const isExpanded = expandedJob === job.job_id;
              
              return (
                <Card key={job.job_id} className="overflow-hidden">
                  <div 
                    className="p-4 cursor-pointer hover:bg-slate-50 transition-colors"
                    onClick={() => setExpandedJob(isExpanded ? null : job.job_id)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        {isExpanded ? (
                          <ChevronDown className="w-4 h-4 text-slate-400" />
                        ) : (
                          <ChevronRight className="w-4 h-4 text-slate-400" />
                        )}
                        
                        <div className={`w-8 h-8 rounded-full ${statusConfig.bg} flex items-center justify-center`}>
                          <StatusIcon className={`w-4 h-4 ${statusConfig.color} ${statusConfig.animate ? 'animate-spin' : ''}`} />
                        </div>
                        
                        <div>
                          <p className="font-medium text-slate-800">{job.job_id}</p>
                          <p className="text-xs text-slate-500">
                            {job.template && <span className="mr-2">{job.template}</span>}
                            {new Date(job.created_at).toLocaleString()}
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-4">
                        {job.duration_ms && (
                          <span className="text-xs text-slate-500">
                            {job.duration_ms.toFixed(1)}ms
                          </span>
                        )}
                        
                        <span className={`px-2 py-1 rounded text-xs font-medium capitalize ${statusConfig.bg} ${statusConfig.color}`}>
                          {job.status}
                        </span>
                        
                        <div className="flex gap-1">
                          {(job.status === 'queued' || job.status === 'running') && (
                            <Button 
                              variant="ghost" 
                              size="sm"
                              onClick={(e) => { e.stopPropagation(); handleCancel(job.job_id); }}
                            >
                              Cancel
                            </Button>
                          )}
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={(e) => { e.stopPropagation(); handleDelete(job.job_id); }}
                          >
                            <Trash2 className="w-4 h-4 text-slate-400 hover:text-red-500" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {isExpanded && (
                    <div className="border-t bg-slate-50 p-4">
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm mb-4">
                        <div>
                          <p className="text-slate-500 text-xs mb-1">Created</p>
                          <p className="font-medium">{new Date(job.created_at).toLocaleString()}</p>
                        </div>
                        {job.started_at && (
                          <div>
                            <p className="text-slate-500 text-xs mb-1">Started</p>
                            <p className="font-medium">{new Date(job.started_at).toLocaleString()}</p>
                          </div>
                        )}
                        {job.completed_at && (
                          <div>
                            <p className="text-slate-500 text-xs mb-1">Completed</p>
                            <p className="font-medium">{new Date(job.completed_at).toLocaleString()}</p>
                          </div>
                        )}
                        {job.duration_ms && (
                          <div>
                            <p className="text-slate-500 text-xs mb-1">Duration</p>
                            <p className="font-medium">{job.duration_ms.toFixed(2)}ms</p>
                          </div>
                        )}
                      </div>
                      
                      {job.error && (
                        <div className="p-3 bg-red-50 border border-red-200 rounded text-sm text-red-700 mb-4">
                          <p className="font-medium mb-1">Error</p>
                          <p>{job.error}</p>
                        </div>
                      )}
                      
                      {job.result && (
                        <div>
                          <p className="text-slate-500 text-xs mb-2">Result</p>
                          <pre className="text-xs font-mono bg-white p-3 rounded border overflow-auto max-h-64">
                            {JSON.stringify(job.result, null, 2)}
                          </pre>
                        </div>
                      )}
                    </div>
                  )}
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
