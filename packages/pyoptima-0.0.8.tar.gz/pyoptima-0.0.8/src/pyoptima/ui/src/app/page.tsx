'use client';

import Link from 'next/link';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ROUTES } from '@/lib/constants';
import { useAppConfigStore, selectAppName, selectVersion } from '@/stores/app-config';
import { TrendingUp, Activity, Layers, ArrowRight } from 'lucide-react';

export default function Home() {
  const appName = useAppConfigStore(selectAppName);
  const version = useAppConfigStore(selectVersion);
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <div className="border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h1 className="text-4xl font-bold tracking-tight text-foreground sm:text-5xl md:text-6xl">
              {appName}
            </h1>
            <p className="mt-6 text-lg leading-8 text-muted-foreground max-w-2xl mx-auto">
              Solve optimization problems with ease. From knapsack to portfolio optimization—all through a unified, intuitive interface.
              {version ? (
                <span className="block mt-2 text-sm font-medium text-muted-foreground/90">
                  Release {version}
                </span>
              ) : null}
            </p>
            <div className="mt-10 flex items-center justify-center gap-x-6">
              <Link href={ROUTES.OPTIMIZATION}>
                <Button size="lg" className="gap-2">
                  Get Started
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </Link>
              <Link href={ROUTES.METHODS}>
                <Button variant="outline" size="lg">
                  Browse Templates
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <TrendingUp className="h-8 w-8 text-primary mb-2" />
              <CardTitle>Optimization</CardTitle>
              <CardDescription>
                Run portfolio, knapsack, LP, MIP, and more. Choose a template, enter data, and get results.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href={ROUTES.OPTIMIZATION}>
                <Button variant="outline" className="w-full">
                  Start Optimizing
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <Activity className="h-8 w-8 text-primary mb-2" />
              <CardTitle>Jobs</CardTitle>
              <CardDescription>
                Track async optimization jobs. View status, results, and history from the jobs dashboard.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href={ROUTES.JOBS}>
                <Button variant="outline" className="w-full">
                  View Jobs
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <Layers className="h-8 w-8 text-primary mb-2" />
              <CardTitle>Templates</CardTitle>
              <CardDescription>
                Browse 14+ problem types: portfolio, knapsack, LP, MIP, job shop, and more.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href={ROUTES.METHODS}>
                <Button variant="outline" className="w-full">
                  Browse Templates
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
