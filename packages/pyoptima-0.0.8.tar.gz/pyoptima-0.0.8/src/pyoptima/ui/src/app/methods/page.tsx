'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { PageHeader } from '@/components/common';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { PageLoading } from '@/components/LoadingSpinner';
import ErrorDisplay from '@/components/ErrorDisplay';
import { api } from '@/lib/api';
import { TEMPLATES, CATEGORIES, getTemplatesByCategory } from '@/lib/templates';
import { ROUTES } from '@/lib/constants';
import type { TemplateInfo, TemplateCategory } from '@/lib/types';
import { 
  Package, 
  Calculator, 
  TrendingUp, 
  Users, 
  MapPin, 
  Truck, 
  Box, 
  Building,
  GitBranch,
  Calendar,
  Layers,
  Grid,
  Activity,
  Zap,
  ArrowRight,
  ExternalLink,
} from 'lucide-react';

const ICONS: Record<string, typeof Package> = {
  Package, Calculator, TrendingUp, Users, MapPin, Truck, Box, Building,
  GitBranch, Calendar, Layers, Grid, Activity, Zap,
};

const CATEGORY_COLORS: Record<TemplateCategory, string> = {
  mathematical: 'border-l-emerald-500 bg-emerald-50',
  combinatorial: 'border-l-indigo-500 bg-indigo-50',
  network: 'border-l-cyan-500 bg-cyan-50',
  scheduling: 'border-l-amber-500 bg-amber-50',
  finance: 'border-l-rose-500 bg-rose-50',
};

export default function MethodsPage() {
  const [loading, setLoading] = useState(true);
  const [serverTemplates, setServerTemplates] = useState<string[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<string | null>(null);
  const [templateInfo, setTemplateInfo] = useState<TemplateInfo | null>(null);
  const [loadingInfo, setLoadingInfo] = useState(false);

  useEffect(() => {
    const fetchTemplates = async () => {
      try {
        const result = await api.listTemplates();
        setServerTemplates(result.templates);
      } catch (err) {
        console.error('Error loading templates from server:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchTemplates();
  }, []);

  const loadTemplateInfo = async (templateId: string) => {
    setSelectedTemplate(templateId);
    setLoadingInfo(true);
    try {
      const info = await api.getTemplate(templateId);
      setTemplateInfo(info);
    } catch (err) {
      console.error('Error loading template info:', err);
      setTemplateInfo(null);
    } finally {
      setLoadingInfo(false);
    }
  };

  if (loading) {
    return <PageLoading message="Loading templates..." />;
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <PageHeader
          title="Optimization Templates"
          description="Browse available templates for common optimization problems"
          actions={
            <Link href={ROUTES.OPTIMIZATION}>
              <Button>
                Open Optimizer
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          }
        />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
          {/* Template Categories */}
          <div className="lg:col-span-2 space-y-6">
            {(Object.entries(CATEGORIES) as [TemplateCategory, typeof CATEGORIES.mathematical][]).map(([categoryId, category]) => {
              const templates = getTemplatesByCategory(categoryId);
              
              return (
                <div key={categoryId}>
                  <h2 className="font-semibold text-lg text-slate-800 mb-3 flex items-center gap-2">
                    {categoryId === 'mathematical' && <Calculator className="w-5 h-5 text-emerald-600" />}
                    {categoryId === 'combinatorial' && <Layers className="w-5 h-5 text-indigo-600" />}
                    {categoryId === 'network' && <GitBranch className="w-5 h-5 text-cyan-600" />}
                    {categoryId === 'scheduling' && <Calendar className="w-5 h-5 text-amber-600" />}
                    {categoryId === 'finance' && <TrendingUp className="w-5 h-5 text-rose-600" />}
                    {category.name}
                  </h2>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {templates.map((tmpl) => {
                      const Icon = ICONS[tmpl.icon] || Package;
                      const isAvailable = serverTemplates.includes(tmpl.id);
                      const isSelected = selectedTemplate === tmpl.id;
                      
                      return (
                        <Card 
                          key={tmpl.id}
                          className={`cursor-pointer transition-all border-l-4 ${CATEGORY_COLORS[categoryId]} ${
                            isSelected ? 'ring-2 ring-indigo-500' : 'hover:shadow-md'
                          } ${!isAvailable ? 'opacity-50' : ''}`}
                          onClick={() => isAvailable && loadTemplateInfo(tmpl.id)}
                        >
                          <CardHeader className="pb-2">
                            <div className="flex items-start justify-between">
                              <div className="flex items-center gap-3">
                                <Icon className="w-5 h-5 text-slate-600" />
                                <CardTitle className="text-base">{tmpl.name}</CardTitle>
                              </div>
                              <span className="text-xs bg-white border px-2 py-0.5 rounded">
                                {tmpl.problemType}
                              </span>
                            </div>
                          </CardHeader>
                          <CardContent>
                            <CardDescription className="text-xs">
                              {tmpl.description}
                            </CardDescription>
                            {!isAvailable && (
                              <p className="text-xs text-amber-600 mt-2">Not available on server</p>
                            )}
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Template Details Panel */}
          <div className="lg:col-span-1">
            <div className="sticky top-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Template Details</CardTitle>
                </CardHeader>
                <CardContent>
                  {!selectedTemplate && (
                    <p className="text-sm text-muted-foreground">
                      Select a template to view details
                    </p>
                  )}
                  
                  {loadingInfo && (
                    <div className="animate-pulse space-y-3">
                      <div className="h-4 bg-slate-200 rounded w-3/4"></div>
                      <div className="h-4 bg-slate-200 rounded w-1/2"></div>
                    </div>
                  )}
                  
                  {templateInfo && !loadingInfo && (
                    <div className="space-y-4">
                      <div>
                        <h3 className="font-semibold text-slate-800">{templateInfo.name}</h3>
                        <p className="text-sm text-muted-foreground mt-1">
                          {templateInfo.description}
                        </p>
                      </div>
                      
                      <div>
                        <h4 className="text-xs font-semibold text-slate-500 uppercase mb-2">
                          Problem Type
                        </h4>
                        <span className="text-sm bg-slate-100 px-2 py-1 rounded">
                          {templateInfo.problem_type}
                        </span>
                      </div>
                      
                      <div>
                        <h4 className="text-xs font-semibold text-slate-500 uppercase mb-2">
                          Default Solver
                        </h4>
                        <span className="text-sm bg-slate-100 px-2 py-1 rounded">
                          {templateInfo.default_solver}
                        </span>
                      </div>
                      
                      <div>
                        <h4 className="text-xs font-semibold text-slate-500 uppercase mb-2">
                          Required Data
                        </h4>
                        <div className="flex flex-wrap gap-1">
                          {templateInfo.required_data.map((field) => (
                            <span 
                              key={field}
                              className="text-xs bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded"
                            >
                              {field}
                            </span>
                          ))}
                        </div>
                      </div>
                      
                      {templateInfo.optional_data.length > 0 && (
                        <div>
                          <h4 className="text-xs font-semibold text-slate-500 uppercase mb-2">
                            Optional Data
                          </h4>
                          <div className="flex flex-wrap gap-1">
                            {templateInfo.optional_data.map((field) => (
                              <span 
                                key={field}
                                className="text-xs bg-slate-100 text-slate-600 px-2 py-0.5 rounded"
                              >
                                {field}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                      
                      <Link href={ROUTES.OPTIMIZATION}>
                        <Button className="w-full mt-4">
                          Use This Template
                          <ExternalLink className="w-4 h-4 ml-2" />
                        </Button>
                      </Link>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
