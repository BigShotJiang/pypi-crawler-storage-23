/**
 * Documentation page - PyOptima methods, functions, and API reference
 *
 * Displays REST API endpoints and Python API (solve, templates, model, config, solvers, expressions)
 * with left sidebar navigation and optional API testing for HTTP endpoints.
 */

'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { ApiError } from '@/lib/api';
import LoadingSpinner from '@/components/LoadingSpinner';
import { Play, Copy, Check, FileText, Zap, Briefcase, Cpu, Code, Box, Settings, Braces } from 'lucide-react';
import { CollapsibleSidebar, SidebarSection } from '@/components/sidebar';
import { getApiBaseUrl } from '@/lib/settings';

interface ApiTestResult {
  success: boolean;
  data?: unknown;
  error?: string;
}

interface Argument {
  name: string;
  type: string;
  description: string;
  required?: boolean;
  default?: string;
}

interface ReturnValue {
  type: string;
  description: string;
}

interface MethodDoc {
  id: string;
  title: string;
  description: string;
  method: string;
  apiEndpoint: string | null;
  apiMethod: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'N/A';
  exampleRequest?: unknown;
  exampleCode: string;
  arguments?: Argument[];
  returns?: ReturnValue;
}

const methods: MethodDoc[] = [
  // --- Optimization ---
  {
    id: 'optimize_sync',
    title: 'Optimize (synchronous)',
    description: 'Submit an optimization request and wait for the result. Best for problems that complete quickly (< 30 seconds).',
    method: 'POST /api/v1/optimize',
    apiEndpoint: '/api/v1/optimize',
    apiMethod: 'POST',
    exampleRequest: {
      template: 'knapsack',
      data: {
        items: [{ name: 'A', value: 60, weight: 10 }, { name: 'B', value: 100, weight: 20 }],
        capacity: 50,
      },
    },
    exampleCode: `# cURL (replace BASE with your API URL, e.g. http://localhost:8003)
curl -X POST BASE/api/v1/optimize \\
  -H "Content-Type: application/json" \\
  -d '{"template":"knapsack","data":{"items":[...],"capacity":50}}'`,
    arguments: [
      { name: 'template', type: 'string', description: 'Template name (e.g. knapsack, lp)', required: true },
      { name: 'data', type: 'object', description: 'Problem data per template schema', required: true },
      { name: 'solver', type: 'object', description: 'Optional solver override { name: "highs" }', required: false },
      { name: 'job_id', type: 'string', description: 'Optional job ID for tracking', required: false },
    ],
    returns: {
      type: 'OptimizeResponse',
      description: 'job_id, status, result (solution), template, solver, duration_ms',
    },
  },
  {
    id: 'optimize_async',
    title: 'Optimize (asynchronous)',
    description: 'Submit an optimization request and receive a job ID. Poll GET /jobs/{job_id} for results. Best for long-running problems.',
    method: 'POST /api/v1/optimize/async',
    apiEndpoint: '/api/v1/optimize/async',
    apiMethod: 'POST',
    exampleRequest: {
      template: 'knapsack',
      data: { items: [{ name: 'A', value: 60, weight: 10 }], capacity: 50 },
    },
    exampleCode: `# Submit job (replace BASE with your API URL)
curl -X POST BASE/api/v1/optimize/async \\
  -H "Content-Type: application/json" \\
  -d '{"template":"knapsack","data":{...}}'
# Response: { "job_id": "...", "status": "queued" }

# Poll for result
curl BASE/api/v1/jobs/{job_id}`,
    arguments: [
      { name: 'template', type: 'string', description: 'Template name', required: true },
      { name: 'data', type: 'object', description: 'Problem data', required: true },
      { name: 'solver', type: 'object', description: 'Optional solver override', required: false },
      { name: 'job_id', type: 'string', description: 'Optional job ID', required: false },
    ],
    returns: {
      type: 'AsyncJobResponse',
      description: 'job_id, status (queued), message',
    },
  },
  {
    id: 'optimize_validate',
    title: 'Validate data',
    description: 'Validate problem data against a template without running optimization.',
    method: 'POST /api/v1/optimize/validate',
    apiEndpoint: '/api/v1/optimize/validate',
    apiMethod: 'POST',
    exampleRequest: { template: 'knapsack', data: { items: [], capacity: 50 } },
    exampleCode: `curl -X POST BASE/api/v1/optimize/validate \\
  -H "Content-Type: application/json" \\
  -d '{"template":"knapsack","data":{...}}'`,
    arguments: [
      { name: 'template', type: 'string', description: 'Template name', required: true },
      { name: 'data', type: 'object', description: 'Problem data to validate', required: true },
    ],
    returns: {
      type: 'ValidationResponse',
      description: 'valid, template, errors, warnings',
    },
  },
  {
    id: 'optimize_batch',
    title: 'Batch optimization',
    description: 'Submit multiple optimization requests at once. Processed sequentially.',
    method: 'POST /api/v1/optimize/batch',
    apiEndpoint: '/api/v1/optimize/batch',
    apiMethod: 'POST',
    exampleRequest: {
      requests: [
        { template: 'knapsack', data: { items: [{ name: 'A', value: 60, weight: 10 }], capacity: 50 } },
      ],
    },
    exampleCode: `curl -X POST BASE/api/v1/optimize/batch \\
  -H "Content-Type: application/json" \\
  -d '{"requests":[{"template":"knapsack","data":{...}}]}'`,
    arguments: [
      { name: 'requests', type: 'OptimizeRequest[]', description: 'Array of optimization requests', required: true },
    ],
    returns: {
      type: 'BatchOptimizeResponse',
      description: 'total, completed, failed, results[], duration_ms',
    },
  },
  // --- Jobs ---
  {
    id: 'list_jobs',
    title: 'List jobs',
    description: 'List optimization jobs with optional filtering by status and pagination.',
    method: 'GET /api/v1/jobs',
    apiEndpoint: '/api/v1/jobs',
    apiMethod: 'GET',
    exampleRequest: null,
    exampleCode: `# All jobs
curl BASE/api/v1/jobs

# Filter by status
curl "BASE/api/v1/jobs?status=completed&limit=10&offset=0"`,
    arguments: [
      { name: 'status', type: 'string', description: 'Filter: queued | running | completed | failed | cancelled', required: false },
      { name: 'limit', type: 'number', description: 'Max jobs to return (default 100)', required: false, default: '100' },
      { name: 'offset', type: 'number', description: 'Skip N jobs (pagination)', required: false, default: '0' },
    ],
    returns: {
      type: 'JobResponse[]',
      description: 'List of jobs (job_id, status, result, error, created_at)',
    },
  },
  {
    id: 'get_job',
    title: 'Get job',
    description: 'Get the status and results of an optimization job.',
    method: 'GET /api/v1/jobs/{job_id}',
    apiEndpoint: '/api/v1/jobs/{job_id}',
    apiMethod: 'GET',
    exampleRequest: null,
    exampleCode: `curl BASE/api/v1/jobs/YOUR_JOB_ID`,
    arguments: [
      { name: 'job_id', type: 'string', description: 'Job ID from async submit or response', required: true },
    ],
    returns: {
      type: 'JobResponse',
      description: 'job_id, status, result (if completed), error (if failed), created_at',
    },
  },
  {
    id: 'get_job_stats',
    title: 'Get job statistics',
    description: 'Get counts of jobs by status (queued, running, completed, failed, cancelled).',
    method: 'GET /api/v1/jobs/stats',
    apiEndpoint: '/api/v1/jobs/stats',
    apiMethod: 'GET',
    exampleRequest: null,
    exampleCode: `curl BASE/api/v1/jobs/stats`,
    arguments: [],
    returns: {
      type: 'Record<string, number>',
      description: 'Counts per status',
    },
  },
  {
    id: 'cancel_job',
    title: 'Cancel job',
    description: 'Cancel a queued or running optimization job.',
    method: 'POST /api/v1/jobs/{job_id}/cancel',
    apiEndpoint: '/api/v1/jobs/{job_id}/cancel',
    apiMethod: 'POST',
    exampleRequest: null,
    exampleCode: `curl -X POST BASE/api/v1/jobs/YOUR_JOB_ID/cancel`,
    arguments: [
      { name: 'job_id', type: 'string', description: 'Job ID to cancel', required: true },
    ],
    returns: {
      type: 'object',
      description: 'message, job_id, status (cancelled)',
    },
  },
  {
    id: 'delete_job',
    title: 'Delete job',
    description: 'Permanently remove a job from storage.',
    method: 'DELETE /api/v1/jobs/{job_id}',
    apiEndpoint: '/api/v1/jobs/{job_id}',
    apiMethod: 'DELETE',
    exampleRequest: null,
    exampleCode: `curl -X DELETE BASE/api/v1/jobs/YOUR_JOB_ID`,
    arguments: [
      { name: 'job_id', type: 'string', description: 'Job ID to delete', required: true },
    ],
    returns: { type: 'void', description: '204 No Content' },
  },
  // --- Templates ---
  {
    id: 'list_templates',
    title: 'List templates',
    description: 'List all available optimization templates (knapsack, lp, portfolio, etc.).',
    method: 'GET /api/v1/templates',
    apiEndpoint: '/api/v1/templates',
    apiMethod: 'GET',
    exampleRequest: null,
    exampleCode: `curl BASE/api/v1/templates`,
    arguments: [],
    returns: {
      type: 'TemplatesListResponse',
      description: 'templates (string[]), total',
    },
  },
  {
    id: 'get_template_info',
    title: 'Get template info',
    description: 'Get detailed information about a template: description, required/optional data, problem type, default solver.',
    method: 'GET /api/v1/templates/{template_name}',
    apiEndpoint: '/api/v1/templates/{template_name}',
    apiMethod: 'GET',
    exampleRequest: null,
    exampleCode: `curl BASE/api/v1/templates/knapsack`,
    arguments: [
      { name: 'template_name', type: 'string', description: 'Template name (e.g. knapsack, lp)', required: true },
    ],
    returns: {
      type: 'TemplateInfo',
      description: 'name, description, problem_type, required_data, optional_data, default_solver',
    },
  },
  // --- Solvers ---
  {
    id: 'list_solvers',
    title: 'List solvers',
    description: 'List all optimization solvers and their capabilities (LP, MIP, QP, NLP).',
    method: 'GET /api/v1/solvers',
    apiEndpoint: '/api/v1/solvers',
    apiMethod: 'GET',
    exampleRequest: null,
    exampleCode: `curl BASE/api/v1/solvers`,
    arguments: [],
    returns: {
      type: 'SolversListResponse',
      description: 'solvers (name, available, supports[]), total',
    },
  },
  {
    id: 'get_solver_info',
    title: 'Get solver info',
    description: 'Get availability and supported problem types for a specific solver.',
    method: 'GET /api/v1/solvers/{solver_name}',
    apiEndpoint: '/api/v1/solvers/{solver_name}',
    apiMethod: 'GET',
    exampleRequest: null,
    exampleCode: `curl BASE/api/v1/solvers/highs`,
    arguments: [
      { name: 'solver_name', type: 'string', description: 'Solver name (e.g. highs, ipopt)', required: true },
    ],
    returns: {
      type: 'SolverInfo',
      description: 'name, available, supports',
    },
  },
  // --- Python: Solve & Templates ---
  {
    id: 'solve',
    title: 'solve()',
    description: 'Solve an optimization problem by template name and data. One-line entry point.',
    method: 'solve(template_name, data, solver=None)',
    apiEndpoint: null,
    apiMethod: 'N/A',
    exampleCode: `from pyoptima import solve

# Knapsack
result = solve("knapsack", {
    "items": [{"name": "A", "value": 60, "weight": 10}, {"name": "B", "value": 100, "weight": 20}],
    "capacity": 50
})

# Linear programming
result = solve("lp", {
    "c": [1, 2, 3],
    "A": [[1, 1, 1]],
    "b": [10],
    "sense": "maximize"
})`,
    arguments: [
      { name: 'template_name', type: 'str', description: 'Template id (knapsack, lp, portfolio, etc.)', required: true },
      { name: 'data', type: 'dict', description: 'Problem data per template schema', required: true },
      { name: 'solver', type: 'Optional[str]', description: 'Solver name override', required: false },
    ],
    returns: {
      type: 'dict',
      description: 'Solution with status, objective, variables, and template-specific result keys',
    },
  },
  {
    id: 'get_template',
    title: 'get_template()',
    description: 'Get a template instance by name for programmatic use (e.g. template.solve(data)).',
    method: 'get_template(name: str) -> ProblemTemplate',
    apiEndpoint: null,
    apiMethod: 'N/A',
    exampleCode: `from pyoptima import get_template

template = get_template("knapsack")
result = template.solve({"items": [...], "capacity": 50})

# Template metadata
info = template.info  # name, description, problem_type, default_solver`,
    arguments: [
      { name: 'name', type: 'str', description: 'Template name', required: true },
    ],
    returns: {
      type: 'ProblemTemplate',
      description: 'Template instance with .solve(data), .info',
    },
  },
  {
    id: 'list_templates_py',
    title: 'list_templates()',
    description: 'Return list of registered template names.',
    method: 'list_templates() -> List[str]',
    apiEndpoint: null,
    apiMethod: 'N/A',
    exampleCode: `from pyoptima import list_templates

names = list_templates()  # e.g. ["knapsack", "lp", "qp", "portfolio", ...]`,
    arguments: [],
    returns: { type: 'List[str]', description: 'Template names' },
  },
  // --- Python: Model ---
  {
    id: 'AbstractModel',
    title: 'AbstractModel',
    description: 'Build optimization models programmatically: add variables, objectives, constraints, then solve.',
    method: 'AbstractModel(name)',
    apiEndpoint: null,
    apiMethod: 'N/A',
    exampleCode: `from pyoptima import AbstractModel, Expression, get_solver

model = AbstractModel("MyProblem")
model.add_continuous("x", lb=0)
model.add_continuous("y", lb=0)
model.add_objective(Expression("x + 2*y"), sense="maximize")
model.add_constraint(Expression("x + y <= 10"), name="c1")
result = model.solve(solver=get_solver("highs"))`,
    arguments: [
      { name: 'name', type: 'str', description: 'Model name', required: true },
    ],
    returns: { type: 'AbstractModel', description: 'Model with add_* and solve()' },
  },
  {
    id: 'Variable',
    title: 'Variable / VariableType',
    description: 'Variable types: continuous, integer, binary. Used with model.add_continuous, add_integer, add_binary.',
    method: 'Variable, VariableType',
    apiEndpoint: null,
    apiMethod: 'N/A',
    exampleCode: `from pyoptima import AbstractModel

model = AbstractModel("LP")
model.add_continuous("x", lb=0, ub=10)
model.add_integer("n", lb=0)
model.add_binary("z")`,
    arguments: [],
    returns: { type: 'N/A', description: 'Used when building models' },
  },
  {
    id: 'Expression_Constraint_Objective',
    title: 'Expression, Constraint, Objective',
    description: 'Expression for objectives and constraints; Constraint and Objective represent model components.',
    method: 'Expression(expr), Constraint, Objective',
    apiEndpoint: null,
    apiMethod: 'N/A',
    exampleCode: `from pyoptima import AbstractModel, Expression

model = AbstractModel("LP")
model.add_objective(Expression("2*x + 3*y"), sense="maximize")
model.add_constraint(Expression("x + y <= 5"), name="c1")`,
    arguments: [],
    returns: { type: 'N/A', description: 'Model building blocks' },
  },
  {
    id: 'OptimizationResult',
    title: 'OptimizationResult, SolverStatus',
    description: 'Result object with status, objective value, variable values; SolverStatus enum (ok, error, etc.).',
    method: 'OptimizationResult, SolverStatus',
    apiEndpoint: null,
    apiMethod: 'N/A',
    exampleCode: `from pyoptima import solve

result = solve("knapsack", data)
# result["status"], result["objective"], result["variables"], ...`,
    arguments: [],
    returns: { type: 'dict | OptimizationResult', description: 'status, objective, variables, ...' },
  },
  // --- Python: Config ---
  {
    id: 'OptimizationConfig',
    title: 'OptimizationConfig, load_config, run_from_config',
    description: 'Run optimizations from config (dict or file): template, data, solver, and optional job settings.',
    method: 'load_config(config_dict), load_config_file(path), run_from_config(config)',
    apiEndpoint: null,
    apiMethod: 'N/A',
    exampleCode: `from pyoptima import load_config_file, run_from_config

config = load_config_file("config.yaml")
result = run_from_config(config)

# Or from dict
from pyoptima import load_config, OptimizationConfig
cfg = load_config({"template": "knapsack", "data": {...}})
run_from_config(cfg)`,
    arguments: [
      { name: 'config_dict', type: 'dict', description: 'Template, data, solver, etc.', required: true },
      { name: 'path', type: 'str', description: 'Path to YAML/JSON config file', required: false },
    ],
    returns: { type: 'dict', description: 'Optimization result' },
  },
  // --- Python: Solvers & Expressions ---
  {
    id: 'get_solver',
    title: 'get_solver()',
    description: 'Get a solver instance by name for use with AbstractModel.solve(solver=...).',
    method: 'get_solver(name: str) -> SolverInterface',
    apiEndpoint: null,
    apiMethod: 'N/A',
    exampleCode: `from pyoptima import get_solver, AbstractModel

solver = get_solver("highs")
model = AbstractModel("LP")
# ... add variables, objective, constraints
result = model.solve(solver=solver)`,
    arguments: [
      { name: 'name', type: 'str', description: 'Solver name (highs, ipopt, etc.)', required: true },
    ],
    returns: { type: 'SolverInterface', description: 'Solver instance' },
  },
  {
    id: 'list_available_solvers',
    title: 'list_available_solvers()',
    description: 'Return list of solver names that are currently available (installed and usable).',
    method: 'list_available_solvers() -> List[str]',
    apiEndpoint: null,
    apiMethod: 'N/A',
    exampleCode: `from pyoptima import list_available_solvers

solvers = list_available_solvers()  # e.g. ["highs", "ipopt"]`,
    arguments: [],
    returns: { type: 'List[str]', description: 'Available solver names' },
  },
  {
    id: 'parse_expression',
    title: 'parse_expression()',
    description: 'Parse a string expression into an internal form for objectives/constraints.',
    method: 'parse_expression(expr: str)',
    apiEndpoint: null,
    apiMethod: 'N/A',
    exampleCode: `from pyoptima import parse_expression, Expression

# Expression("x + 2*y") uses parsing internally
parsed = parse_expression("x + 2*y")`,
    arguments: [
      { name: 'expr', type: 'str', description: 'Expression string (e.g. "x + 2*y")', required: true },
    ],
    returns: { type: 'Parsed expression', description: 'Internal representation' },
  },
  {
    id: 'evaluate_expression',
    title: 'evaluate_expression()',
    description: 'Evaluate a parsed expression given variable values.',
    method: 'evaluate_expression(parsed, values: dict)',
    apiEndpoint: null,
    apiMethod: 'N/A',
    exampleCode: `from pyoptima import evaluate_expression, parse_expression

parsed = parse_expression("x + 2*y")
value = evaluate_expression(parsed, {"x": 1, "y": 2})  # 5`,
    arguments: [
      { name: 'parsed', type: 'parsed', description: 'Output of parse_expression', required: true },
      { name: 'values', type: 'dict', description: 'Variable name -> value', required: true },
    ],
    returns: { type: 'float', description: 'Evaluated value' },
  },
];

function ApiTester({ method }: { method: MethodDoc }) {
  const [requestBody, setRequestBody] = useState<string>(
    method.exampleRequest ? JSON.stringify(method.exampleRequest, null, 2) : ''
  );
  const [result, setResult] = useState<ApiTestResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  if (!method.apiEndpoint) {
    return (
      <div className="border rounded-lg p-4 bg-muted/30">
        <h5 className="text-sm font-semibold mb-2">Python only</h5>
        <p className="text-xs text-muted-foreground">This item is part of the Python API; use the REST endpoints in the Optimization, Jobs, Templates, or Solvers sections to call the server.</p>
      </div>
    );
  }

  const resolvedEndpoint = method.apiEndpoint
    .replace('{job_id}', 'example-job-id')
    .replace('{template_name}', 'knapsack')
    .replace('{solver_name}', 'highs');

  const handleTest = async () => {
    setLoading(true);
    setResult(null);
    try {
      const base = getApiBaseUrl();
      const url = `${base}${resolvedEndpoint}`;
      const opts: RequestInit =
        method.apiMethod === 'GET'
          ? { method: 'GET' }
          : {
              method: method.apiMethod,
              headers: { 'Content-Type': 'application/json' },
              body: requestBody ?? undefined,
            };
      const response = await fetch(url, opts);
      const contentType = response.headers.get('content-type');
      let data: unknown;
      if (contentType?.includes('application/json')) {
        data = await response.json();
      } else {
        const text = await response.text();
        data = response.ok ? { message: text } : { error: text };
      }
      if (!response.ok) {
        setResult({
          success: false,
          error: (data as { detail?: string })?.detail || (data as { error?: string })?.error || response.statusText,
        });
      } else {
        setResult({ success: true, data });
      }
    } catch (err) {
      const message = err instanceof ApiError ? err.message : err instanceof Error ? err.message : 'Request failed';
      setResult({ success: false, error: message });
    } finally {
      setLoading(false);
    }
  };

  const copyEndpoint = () => {
    navigator.clipboard.writeText(getApiBaseUrl() + resolvedEndpoint);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="border rounded-lg p-4 bg-muted/30">
      <div className="flex items-center justify-between mb-3">
        <h5 className="text-sm font-semibold">Test API</h5>
        <div className="flex gap-2">
          <Button size="sm" variant="outline" onClick={copyEndpoint} className="h-7">
            {copied ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
          </Button>
          <Button
            size="sm"
            onClick={handleTest}
            disabled={loading || (method.apiMethod !== 'GET' && !requestBody)}
            className="h-7"
          >
            {loading ? (
              <>
                <LoadingSpinner size="sm" className="mr-1" />
                Testing...
              </>
            ) : (
              <>
                <Play className="h-3 w-3 mr-1" />
                Test
              </>
            )}
          </Button>
        </div>
      </div>
      {method.apiMethod !== 'GET' && (
        <div className="mb-3">
          <label className="block text-xs font-medium mb-1">Request body (JSON)</label>
          <textarea
            value={requestBody}
            onChange={(e) => setRequestBody(e.target.value)}
            rows={6}
            className="w-full px-2 py-1 border rounded text-xs font-mono bg-background"
            placeholder="{}"
          />
        </div>
      )}
      <div className="text-xs text-muted-foreground mb-2">
        <span className="font-mono font-semibold">{method.apiMethod}</span> {resolvedEndpoint}
      </div>
      {result && (
        <div className="mt-3">
          {result.success ? (
            <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded p-2">
              <div className="text-xs font-semibold text-green-800 dark:text-green-200 mb-1">Success</div>
              <pre className="text-xs overflow-x-auto text-green-700 dark:text-green-300">
                {JSON.stringify(result.data, null, 2)}
              </pre>
            </div>
          ) : (
            <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded p-2">
              <div className="text-xs font-semibold text-red-800 dark:text-red-200 mb-1">Error</div>
              <div className="text-xs text-red-700 dark:text-red-300">{result.error}</div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default function DocumentationPage() {
  const [selectedSection, setSelectedSection] = useState<string>('optimization');

  const sectionMethodMap: Record<string, string[]> = {
    optimization: ['optimize_sync', 'optimize_async', 'optimize_validate', 'optimize_batch'],
    jobs: ['list_jobs', 'get_job', 'get_job_stats', 'cancel_job', 'delete_job'],
    templates: ['list_templates', 'get_template_info'],
    solvers: ['list_solvers', 'get_solver_info'],
    'python-solve': ['solve', 'get_template', 'list_templates_py'],
    'python-model': ['AbstractModel', 'Variable', 'Expression_Constraint_Objective', 'OptimizationResult'],
    'python-config': ['OptimizationConfig'],
    'python-solvers-expressions': ['get_solver', 'list_available_solvers', 'parse_expression', 'evaluate_expression'],
  };

  const scrollToMethod = (methodId: string) => {
    const sectionId = Object.keys(sectionMethodMap).find((s) => sectionMethodMap[s].includes(methodId));
    if (sectionId) {
      setSelectedSection(sectionId);
      setTimeout(() => {
        const el = document.getElementById(`method-${methodId}`);
        if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 150);
    } else {
      const el = document.getElementById(`method-${methodId}`);
      if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const handleSectionClick = (sectionId: string) => {
    setSelectedSection(sectionId);
    setTimeout(() => {
      const el = document.getElementById(`section-${sectionId}`);
      if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);
  };

  const sectionDescriptions: Record<string, string> = {
    optimization: 'Run optimizations synchronously, asynchronously, in batch, or validate data only.',
    jobs: 'List, get, cancel, and delete optimization jobs.',
    templates: 'Discover templates and their required data and default solvers.',
    solvers: 'List solvers and check availability and supported problem types.',
    'python-solve': 'Solve by template name and data; get template instances and list template names.',
    'python-model': 'Build models with variables, objectives, and constraints; work with results.',
    'python-config': 'Run optimizations from configuration dict or file.',
    'python-solvers-expressions': 'Get solver instances, list available solvers, parse and evaluate expressions.',
  };

  const sidebarSections: SidebarSection[] = [
    {
      id: 'optimization',
      title: 'Optimization',
      icon: Zap,
      items: [
        { id: 'optimize_sync', label: 'Optimize (sync)', onClick: () => scrollToMethod('optimize_sync') },
        { id: 'optimize_async', label: 'Optimize (async)', onClick: () => scrollToMethod('optimize_async') },
        { id: 'optimize_validate', label: 'Validate data', onClick: () => scrollToMethod('optimize_validate') },
        { id: 'optimize_batch', label: 'Batch optimize', onClick: () => scrollToMethod('optimize_batch') },
      ],
    },
    {
      id: 'jobs',
      title: 'Jobs',
      icon: Briefcase,
      items: [
        { id: 'list_jobs', label: 'List jobs', onClick: () => scrollToMethod('list_jobs') },
        { id: 'get_job', label: 'Get job', onClick: () => scrollToMethod('get_job') },
        { id: 'get_job_stats', label: 'Job stats', onClick: () => scrollToMethod('get_job_stats') },
        { id: 'cancel_job', label: 'Cancel job', onClick: () => scrollToMethod('cancel_job') },
        { id: 'delete_job', label: 'Delete job', onClick: () => scrollToMethod('delete_job') },
      ],
    },
    {
      id: 'templates',
      title: 'Templates',
      icon: FileText,
      items: [
        { id: 'list_templates', label: 'List templates', onClick: () => scrollToMethod('list_templates') },
        { id: 'get_template_info', label: 'Get template info', onClick: () => scrollToMethod('get_template_info') },
      ],
    },
    {
      id: 'solvers',
      title: 'Solvers',
      icon: Cpu,
      items: [
        { id: 'list_solvers', label: 'List solvers', onClick: () => scrollToMethod('list_solvers') },
        { id: 'get_solver_info', label: 'Get solver info', onClick: () => scrollToMethod('get_solver_info') },
      ],
    },
    {
      id: 'python-solve',
      title: 'Python – Solve & Templates',
      icon: Code,
      items: [
        { id: 'solve', label: 'solve()', onClick: () => scrollToMethod('solve') },
        { id: 'get_template', label: 'get_template()', onClick: () => scrollToMethod('get_template') },
        { id: 'list_templates_py', label: 'list_templates()', onClick: () => scrollToMethod('list_templates_py') },
      ],
    },
    {
      id: 'python-model',
      title: 'Python – Model',
      icon: Box,
      items: [
        { id: 'AbstractModel', label: 'AbstractModel', onClick: () => scrollToMethod('AbstractModel') },
        { id: 'Variable', label: 'Variable / VariableType', onClick: () => scrollToMethod('Variable') },
        { id: 'Expression_Constraint_Objective', label: 'Expression, Constraint, Objective', onClick: () => scrollToMethod('Expression_Constraint_Objective') },
        { id: 'OptimizationResult', label: 'OptimizationResult', onClick: () => scrollToMethod('OptimizationResult') },
      ],
    },
    {
      id: 'python-config',
      title: 'Python – Config',
      icon: Settings,
      items: [
        { id: 'OptimizationConfig', label: 'Config & run_from_config', onClick: () => scrollToMethod('OptimizationConfig') },
      ],
    },
    {
      id: 'python-solvers-expressions',
      title: 'Python – Solvers & Expressions',
      icon: Braces,
      items: [
        { id: 'get_solver', label: 'get_solver()', onClick: () => scrollToMethod('get_solver') },
        { id: 'list_available_solvers', label: 'list_available_solvers()', onClick: () => scrollToMethod('list_available_solvers') },
        { id: 'parse_expression', label: 'parse_expression()', onClick: () => scrollToMethod('parse_expression') },
        { id: 'evaluate_expression', label: 'evaluate_expression()', onClick: () => scrollToMethod('evaluate_expression') },
      ],
    },
  ];

  const displayedMethods = sectionMethodMap[selectedSection]
    ? methods.filter((m) => sectionMethodMap[selectedSection].includes(m.id))
    : methods;

  return (
    <div className="flex h-full bg-background" style={{ height: 'calc(100vh - 4rem)', overflow: 'hidden' }}>
      <div className="flex-shrink-0" style={{ height: '100%', overflow: 'hidden' }}>
        <CollapsibleSidebar
          sections={sidebarSections}
          defaultCollapsed={false}
          headerTitle="Documentation"
          selectedSection={selectedSection}
          onSectionClick={handleSectionClick}
        />
      </div>
      <div
        className="flex-1 min-w-0"
        style={{ height: '100%', overflowY: 'auto', overflowX: 'hidden' }}
        data-content-area
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="space-y-8">
            <div id={`section-${selectedSection}`} className="scroll-mt-4 mb-4">
              <h2 className="text-2xl font-bold text-foreground mb-1">
                {sidebarSections.find((s) => s.id === selectedSection)?.title || 'Documentation'}
              </h2>
              <p className="text-sm text-muted-foreground">
                {sectionDescriptions[selectedSection] ?? 'Methods and API reference for PyOptima.'}
              </p>
            </div>
            <div className="space-y-6">
              {displayedMethods.map((method) => (
                <div
                  key={method.id}
                  id={`method-${method.id}`}
                  className="border rounded-lg overflow-hidden scroll-mt-4"
                >
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 p-4">
                    <div>
                      <h4 className="font-semibold mb-2">{method.title}</h4>
                      <p className="text-sm text-muted-foreground mb-3">{method.description}</p>
                      {method.arguments && method.arguments.length > 0 && (
                        <div className="mb-4">
                          <h5 className="text-sm font-semibold mb-2">Arguments</h5>
                          <div className="space-y-2">
                            {method.arguments.map((arg, idx) => (
                              <div key={idx} className="text-xs border-l-2 border-primary/20 pl-2">
                                <div className="font-mono font-semibold text-foreground">
                                  {arg.name}
                                  {!arg.required && <span className="text-muted-foreground ml-1">(optional)</span>}
                                </div>
                                <div className="text-muted-foreground mt-0.5">
                                  <span className="font-mono">{arg.type}</span>
                                  {arg.default != null && <span className="ml-1">default: {arg.default}</span>}
                                </div>
                                <div className="text-muted-foreground mt-1">{arg.description}</div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                      {method.returns && (
                        <div className="mb-4">
                          <h5 className="text-sm font-semibold mb-2">Returns</h5>
                          <div className="text-xs border-l-2 border-green-500/20 pl-2">
                            <div className="font-mono font-semibold text-foreground mb-0.5">{method.returns.type}</div>
                            <div className="text-muted-foreground">{method.returns.description}</div>
                          </div>
                        </div>
                      )}
                      <div className="bg-muted p-3 rounded font-mono text-xs overflow-x-auto mb-3">
                        <pre className="whitespace-pre-wrap">{method.exampleCode}</pre>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        <span className="font-semibold">Method:</span> {method.method}
                      </div>
                    </div>
                    <div>
                      <ApiTester method={method} />
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div className="border rounded-lg p-4 bg-primary/5">
              <h4 className="font-semibold mb-2">Additional resources</h4>
              <ul className="text-sm space-y-1 text-muted-foreground">
                <li>• API docs: /docs and /redoc when the API server is running</li>
                <li>• PyOptima README and examples in the repository</li>
                <li>• Health: GET /health for API status and solver/template counts</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
