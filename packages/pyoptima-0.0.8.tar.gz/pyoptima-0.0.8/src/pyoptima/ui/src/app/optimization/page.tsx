'use client';

import { useState, useMemo, useCallback } from 'react';
import { 
  Play, 
  Settings, 
  ChevronRight,
  ChevronDown,
  RefreshCw, 
  RotateCcw,
  Sparkles,
  Calculator,
  Layers,
  GitBranch,
  Calendar,
  TrendingUp,
  Package,
  Users,
  MapPin,
  Truck,
  Box,
  Building,
  Grid,
  Activity,
  Zap,
  Shield,
  CheckCircle,
  FileText,
  Upload,
  Code,
} from 'lucide-react';
import { api, ApiError } from '@/lib/api';
import { TEMPLATES, CATEGORIES, getTemplatesByCategory, getTemplate } from '@/lib/templates';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { DataInputForm } from '@/components/optimization/DataInputForm';
import { FinanceTemplateForm, FINANCE_TEMPLATE_IDS, type FinanceTemplateId } from '@/components/optimization/FinanceTemplateForm';
import { JobShopInputForm } from '@/components/optimization/JobShopInputForm';
import { JobShopConstraintsForm } from '@/components/optimization/JobShopConstraintsForm';
import { PortfolioInputForm } from '@/components/optimization/PortfolioInputForm';
import { ResultsDisplay } from '@/components/optimization/ResultsDisplay';
import { OptimizationTabBar, type OptimizationTab } from '@/components/optimization/OptimizationTabBar';
import { SolverStatusBadge } from '@/components/optimization/SolverStatusBadge';
import type { SolverStatus } from '@/lib/utils';
import { CollapsibleSidebar, type SidebarSection } from '@/components/sidebar';
import ErrorDisplay from '@/components/ErrorDisplay';
import type { OptimizeResponse, TemplateCategory } from '@/lib/types';
import { buildJobShopPayload } from '@/lib/jobshopPayload';

// Icon mapping
const ICONS: Record<string, typeof Package> = {
  Package, Users, MapPin, Truck, Box, Building, Grid, Activity, Zap, Shield,
  TrendingUp, Calculator, Layers, GitBranch, Calendar,
};

const CATEGORY_ICONS: Record<TemplateCategory, typeof Calculator> = {
  mathematical: Calculator,
  combinatorial: Layers,
  network: GitBranch,
  scheduling: Calendar,
  finance: TrendingUp,
};

export default function OptimizationPage() {
  // Template selection
  const [selectedTemplate, setSelectedTemplate] = useState('knapsack');
  const [selectedCategory, setSelectedCategory] = useState<string>('combinatorial');
  
  // Input mode: 'form' or 'config'
  const [inputMode, setInputMode] = useState<'form' | 'config'>('form');
  
  // Tab for portfolio/jobshop layout (Assets & Data | Objective | Constraint)
  const [optimizationTab, setOptimizationTab] = useState<OptimizationTab>('assetsData');
  
  // Data and configuration
  const [data, setData] = useState<Record<string, unknown>>({});
  const [solver, setSolver] = useState('');
  const [timeLimit, setTimeLimit] = useState<number | undefined>(undefined);
  const [showAdvanced, setShowAdvanced] = useState(false);
  
  // Config file mode
  const [configContent, setConfigContent] = useState('');
  const [configError, setConfigError] = useState<string | null>(null);
  
  // Execution state
  const [isRunning, setIsRunning] = useState(false);
  const [result, setResult] = useState<OptimizeResponse | null>(null);
  const [error, setError] = useState<string | ApiError | null>(null);
  const [validationResult, setValidationResult] = useState<{ valid: boolean; errors: string[] } | null>(null);
  const [isValidating, setIsValidating] = useState(false);

  // Get current template config
  const template = useMemo(() => getTemplate(selectedTemplate), [selectedTemplate]);

  // Derived solver status and solve time (for portfolio/jobshop header)
  const solverStatus: SolverStatus = useMemo(() => {
    if (isRunning) return 'solving';
    if (error) return 'error';
    if (result) {
      const s = (result as { status?: string }).status;
      if (s === 'optimal') return 'optimal';
      if (s === 'infeasible') return 'infeasible';
      if (s === 'time_limit' || s === 'time-limit') return 'time-limit';
      return 'error';
    }
    return 'idle';
  }, [isRunning, error, result]);

  const solveTimeMs = useMemo(() => {
    if (!result) return undefined;
    const r = result as { duration_ms?: number; result?: { solve_time?: number } };
    if (typeof r.duration_ms === 'number') return r.duration_ms;
    const st = r.result?.solve_time;
    if (typeof st === 'number') return st * 1000;
    return undefined;
  }, [result]);

  const portfolioAssetCount = useMemo(() => {
    if (selectedTemplate !== 'portfolio' || !data) return 0;
    const sym = data.symbols;
    const er = data.expected_returns;
    if (Array.isArray(sym)) return sym.length;
    if (Array.isArray(er)) return er.length;
    return 0;
  }, [selectedTemplate, data?.symbols, data?.expected_returns]);
  
  // Handle template selection
  const handleSelectTemplate = useCallback((templateId: string) => {
    setSelectedTemplate(templateId);
    setOptimizationTab('assetsData');
    const tmpl = getTemplate(templateId);
    if (tmpl) {
      setData(JSON.parse(JSON.stringify(tmpl.examples)));
      setSolver(tmpl.defaultSolver);
    }
    setResult(null);
    setError(null);
    setValidationResult(null);
  }, []);

  // Build sidebar sections from categories
  const sidebarSections: SidebarSection[] = useMemo(() => {
    return (Object.entries(CATEGORIES) as [TemplateCategory, typeof CATEGORIES.mathematical][]).map(([categoryId, category]) => {
      const templates = getTemplatesByCategory(categoryId);
      const CategoryIcon = CATEGORY_ICONS[categoryId];
      
      return {
        id: categoryId,
        title: category.name,
        icon: CategoryIcon,
        items: templates.map((tmpl) => ({
          id: tmpl.id,
          label: tmpl.name,
          onClick: () => handleSelectTemplate(tmpl.id),
        })),
      };
    });
  }, [handleSelectTemplate]);

  // Handle section click
  const handleSectionClick = (sectionId: string) => {
    setSelectedCategory(sectionId);
  };

  // Load example data
  const loadExample = () => {
    if (template) {
      setData(JSON.parse(JSON.stringify(template.examples)));
    }
  };

  // Reset (clear results + reload example) for portfolio/jobshop
  const handleReset = () => {
    setResult(null);
    setError(null);
    setValidationResult(null);
    setOptimizationTab(selectedTemplate === 'portfolio' ? 'assetsData' : selectedTemplate === 'jobshop' ? 'assetsData' : optimizationTab);
    loadExample();
  };

  // Load example config
  const loadExampleConfig = () => {
    if (template) {
      const exampleConfig = {
        template: selectedTemplate,
        data: template.examples,
        solver: {
          name: template.defaultSolver,
        },
      };
      setConfigContent(formatConfig(exampleConfig));
      setConfigError(null);
    }
  };

  // Format config as YAML-like string
  const formatConfig = (config: Record<string, unknown>): string => {
    try {
      return JSON.stringify(config, null, 2);
    } catch {
      return '';
    }
  };

  // Parse and load config file
  const handleLoadConfig = () => {
    setConfigError(null);
    
    if (!configContent.trim()) {
      setConfigError('Config content is empty');
      return;
    }
    
    try {
      // Try to parse as JSON
      const parsed = JSON.parse(configContent);
      
      // Validate structure
      if (!parsed.template) {
        setConfigError('Config must include "template" field');
        return;
      }
      
      if (!parsed.data) {
        setConfigError('Config must include "data" field');
        return;
      }
      
      // Update template and data
      setSelectedTemplate(parsed.template);
      setData(parsed.data);
      
      // Update solver settings
      if (parsed.solver) {
        setSolver(parsed.solver.name || '');
        setTimeLimit(parsed.solver.time_limit);
      } else {
        const tmpl = getTemplate(parsed.template);
        setSolver(tmpl?.defaultSolver || '');
        setTimeLimit(undefined);
      }
      
      // Switch to form mode to show the loaded data
      setInputMode('form');
      setResult(null);
      setError(null);
    } catch (err) {
      setConfigError(`Invalid JSON: ${err instanceof Error ? err.message : 'Unknown error'}`);
    }
  };

  // Handle file upload
  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      setConfigContent(content);
      setConfigError(null);
    };
    reader.onerror = () => {
      setConfigError('Failed to read file');
    };
    reader.readAsText(file);
  };

  // Validate problem data
  const handleValidate = async () => {
    setValidationResult(null);
    setIsValidating(true);
    try {
      let templateId = selectedTemplate;
      let payload: Record<string, unknown> = data;
      if (inputMode === 'config' && configContent.trim()) {
        try {
          const parsed = JSON.parse(configContent) as Record<string, unknown>;
          if (!parsed || typeof parsed !== 'object' || !parsed.template || !parsed.data) {
            setValidationResult({ valid: false, errors: ['Config must include template and data'] });
            return;
          }
          templateId = String(parsed.template);
          payload = parsed.data as Record<string, unknown>;
        } catch {
          setValidationResult({ valid: false, errors: ['Invalid JSON in config'] });
          return;
        }
      } else if (!template) {
        setValidationResult({ valid: false, errors: ['Select a template first'] });
        return;
      }
      const validatePayload = templateId === 'jobshop' ? buildJobShopPayload(payload as Record<string, unknown>) : payload;
      const res = await api.validate({ template: templateId, data: validatePayload });
      setValidationResult({ valid: res.valid, errors: res.errors || [] });
    } catch (err) {
      setValidationResult({
        valid: false,
        errors: [err instanceof ApiError ? err.message : err instanceof Error ? err.message : 'Validation request failed'],
      });
    } finally {
      setIsValidating(false);
    }
  };

  // Client-side validation for portfolio required fields (surfaces clear message before API call)
  const portfolioValidationError = useMemo(() => {
    if (selectedTemplate !== 'portfolio' || !data || typeof data.objective !== 'string') return null;
    const objective = data.objective as string;
    const get = (k: string) => data[k];
    if (['efficient_return', 'efficient_cvar_return', 'efficient_cdar_return', 'efficient_semivariance_return'].includes(objective)) {
      if (get('target_return') == null || get('target_return') === '') return 'Target return is required for this objective. Set it in the Objective tab.';
    }
    if (objective === 'efficient_risk') {
      if (get('target_volatility') == null || get('target_volatility') === '') return 'Target volatility is required for Efficient Risk. Set it in the Objective tab.';
    }
    if (objective === 'efficient_cvar_risk') {
      if (get('target_cvar') == null || get('target_cvar') === '') return 'Target CVaR is required. Set it in the Objective tab.';
    }
    if (objective === 'efficient_cdar_risk') {
      if (get('target_cdar') == null || get('target_cdar') === '') return 'Target CDaR is required. Set it in the Objective tab.';
    }
    if (objective === 'efficient_semivariance_risk') {
      if (get('target_semivariance') == null || get('target_semivariance') === '') return 'Target semivariance is required. Set it in the Objective tab.';
    }
    return null;
  }, [selectedTemplate, data]);

  // Run optimization
  const handleRun = async () => {
    setValidationResult(null);
    if (portfolioValidationError) {
      setError(portfolioValidationError);
      return;
    }
    if (inputMode === 'config') {
      // Parse config and run directly
      if (!configContent.trim()) {
        setError('Config content is empty');
        return;
      }
      
      try {
        const parsed = JSON.parse(configContent);
        
        if (!parsed.template || !parsed.data) {
          setError('Config must include "template" and "data" fields');
          return;
        }
        
        setIsRunning(true);
        setError(null);
        
        const response = await api.optimize({
          template: parsed.template,
          data: parsed.data,
          solver: parsed.solver ? {
            name: parsed.solver.name,
            time_limit: parsed.solver.time_limit,
          } : undefined,
        });
        
        setResult(response);
        } catch (err) {
          if (err instanceof ApiError) {
            setError(err);
          } else if (err instanceof SyntaxError) {
            setError(`Invalid JSON: ${err.message}`);
          } else if (err instanceof Error) {
            setError(err.message);
          } else {
            setError('Optimization failed. Please check your config and try again.');
          }
          console.error('Optimization error:', err);
        } finally {
          setIsRunning(false);
        }
        return;
    }
    
    // Form mode - run normally
    if (!template) return;
    
    setIsRunning(true);
    setError(null);
    
    try {
      const payload = selectedTemplate === 'jobshop' ? buildJobShopPayload(data) : data;
      const response = await api.optimize({
        template: selectedTemplate,
        data: payload,
        solver: solver ? {
          name: solver,
          time_limit: timeLimit,
        } : undefined,
      });
      
      setResult(response);
      if (selectedTemplate === 'portfolio' || selectedTemplate === 'jobshop') {
        setOptimizationTab('results');
      }
    } catch (err) {
      if (err instanceof ApiError) {
        setError(err);
      } else if (err instanceof Error) {
        setError(err.message);
      } else {
        setError('Optimization failed. Please check your data and try again.');
      }
      console.error('Optimization error:', err);
    } finally {
      setIsRunning(false);
    }
  };

  return (
    <div className="flex h-[calc(100vh-4rem)]">
      {/* Collapsible Sidebar - Template Selection */}
      <div className="flex-shrink-0" style={{ height: '100%', overflow: 'hidden' }}>
        <CollapsibleSidebar
          sections={sidebarSections}
          defaultCollapsed={false}
          headerTitle="Templates"
          selectedSection={selectedCategory}
          onSectionClick={handleSectionClick}
        />
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Bar */}
        <div className="h-14 bg-white border-b border-slate-200 flex items-center justify-between px-6 shrink-0">
          <div className="flex items-center gap-3">
            {template && (
              <>
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                  template.category === 'finance' ? 'bg-emerald-100 text-emerald-600' :
                  template.category === 'network' ? 'bg-cyan-100 text-cyan-600' :
                  template.category === 'scheduling' ? 'bg-amber-100 text-amber-600' :
                  'bg-indigo-100 text-indigo-600'
                }`}>
                  {(() => {
                    const Icon = ICONS[template.icon] || Package;
                    return <Icon className="w-4 h-4" />;
                  })()}
                </div>
                <div>
                  <h1 className="font-bold text-slate-800">{template.name}</h1>
                  <p className="text-xs text-slate-500">{template.description}</p>
                </div>
                {selectedTemplate === 'portfolio' && portfolioAssetCount > 0 && (
                  <span className="inline-flex items-center rounded-md border border-indigo-200 bg-indigo-50 px-2.5 py-0.5 text-xs font-medium text-indigo-700">
                    {portfolioAssetCount} Asset{portfolioAssetCount !== 1 ? 's' : ''}
                  </span>
                )}
              </>
            )}
          </div>
          
          <div className="flex items-center gap-3">
            {inputMode === 'form' && (selectedTemplate === 'portfolio' || selectedTemplate === 'jobshop') && (
              <>
                <SolverStatusBadge
                  status={solverStatus}
                  solveTimeMs={solveTimeMs}
                  message={error instanceof Error ? error.message : typeof error === 'string' ? error : undefined}
                />
                <Button variant="outline" size="sm" onClick={handleReset} className="gap-1">
                  <RotateCcw className="w-4 h-4" />
                  Reset
                </Button>
              </>
            )}
            {inputMode === 'form' && (
              <Button variant="outline" size="sm" onClick={loadExample}>
                <Sparkles className="w-4 h-4 mr-1" />
                Load Example
              </Button>
            )}
            
            {inputMode === 'config' && (
              <>
                <Button variant="outline" size="sm" onClick={loadExampleConfig}>
                  <Sparkles className="w-4 h-4 mr-1" />
                  Example Config
                </Button>
                <Button 
                  onClick={handleLoadConfig}
                  disabled={!configContent.trim()}
                  variant="outline"
                  size="sm"
                >
                  <Upload className="w-4 h-4 mr-1" />
                  Load Config
                </Button>
              </>
            )}
            
            {/* Input Mode Toggle - immediately before Run button */}
            <div className="flex items-center gap-1 bg-slate-100 rounded-lg p-1">
              <button
                onClick={() => setInputMode('form')}
                className={`px-3 py-1.5 text-sm font-medium rounded transition-colors ${
                  inputMode === 'form'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Code className="w-4 h-4 inline mr-1" />
                Form
              </button>
              <button
                onClick={() => setInputMode('config')}
                className={`px-3 py-1.5 text-sm font-medium rounded transition-colors ${
                  inputMode === 'config'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <FileText className="w-4 h-4 inline mr-1" />
                Config
              </button>
            </div>
            
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={handleValidate}
              disabled={isValidating || (inputMode === 'config' && !configContent.trim())}
            >
              {isValidating ? (
                <RefreshCw className="w-4 h-4 mr-1 animate-spin" />
              ) : (
                <CheckCircle className="w-4 h-4 mr-1" />
              )}
              {isValidating ? 'Validating...' : 'Validate'}
            </Button>
            <Button 
              onClick={handleRun}
              disabled={isRunning || (inputMode === 'config' && !configContent.trim())}
              size="sm"
              className={selectedTemplate === 'portfolio' ? 'bg-indigo-600 hover:bg-indigo-700' : undefined}
            >
              {isRunning ? (
                <RefreshCw className="w-4 h-4 mr-1 animate-spin" />
              ) : (
                <Play className="w-4 h-4 mr-1" />
              )}
              {isRunning
                ? 'Solving…'
                : selectedTemplate === 'portfolio'
                  ? 'Optimize'
                  : selectedTemplate === 'jobshop'
                    ? 'Solve'
                    : 'Run Optimization'}
            </Button>
          </div>
        </div>

        {/* Tabs: directly below header for portfolio/jobshop form mode */}
        {inputMode === 'form' && (selectedTemplate === 'portfolio' || selectedTemplate === 'jobshop') && (
          <div className="shrink-0 border-b border-slate-200 bg-white px-6">
            <OptimizationTabBar
              activeTab={optimizationTab}
              onTabChange={setOptimizationTab}
              template={selectedTemplate}
            />
          </div>
        )}

        {/* Content */}
        <div className="flex-1 overflow-y-auto">
          <div className={`mx-auto p-6 space-y-4 ${selectedTemplate === 'portfolio' ? 'max-w-7xl' : 'max-w-5xl'}`}>
            {/* Error Display */}
            {error && (
              <ErrorDisplay 
                error={error instanceof ApiError ? error : (typeof error === 'string' ? new Error(error) : error)} 
                showApiHelp={
                  (typeof error === 'string' && (error.includes('Unable to connect to API') || error.includes('Failed to fetch'))) ||
                  (error instanceof ApiError && error.status === 0)
                }
              />
            )}

            {/* Portfolio required-field validation (inline, before Run) */}
            {portfolioValidationError && (
              <div className="rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800">
                <p className="font-medium">Missing required parameter</p>
                <p className="mt-0.5">{portfolioValidationError}</p>
              </div>
            )}

            {/* Validation result */}
            {validationResult && (
              <div
                className={`rounded-lg border px-4 py-3 text-sm ${
                  validationResult.valid
                    ? 'border-emerald-200 bg-emerald-50 text-emerald-800'
                    : 'border-red-200 bg-red-50 text-red-800'
                }`}
              >
                {validationResult.valid ? (
                  <p className="font-medium">Validation passed. You can run optimization.</p>
                ) : (
                  <div>
                    <p className="font-medium mb-1">Validation failed:</p>
                    <ul className="list-disc list-inside space-y-0.5">
                      {validationResult.errors.map((e, i) => (
                        <li key={i}>{e}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            )}
            
            {/* For portfolio/jobshop: Results tab shows results; other tabs show form */}
            {inputMode === 'form' && (selectedTemplate === 'portfolio' || selectedTemplate === 'jobshop') ? (
              optimizationTab === 'results' ? (
                <div className="p-6">
                  {result ? (
                    <>
                      <ResultsDisplay response={result} template={selectedTemplate} />
                      <p className="text-sm text-slate-500 mt-4">
                        Modify the data in the other tabs and click Run again to re-optimize.
                      </p>
                    </>
                  ) : (
                    <div className="flex flex-col items-center justify-center py-16 text-slate-500">
                      <TrendingUp className="h-12 w-12 mb-4 opacity-30" />
                      <p className="text-sm font-medium text-slate-600">No results yet</p>
                      <p className="text-sm mt-1">Configure your portfolio in the tabs above and click Optimize.</p>
                    </div>
                  )}
                </div>
              ) : optimizationTab === 'solver' ? (
                <div className="p-6">
                  <div className="max-w-xl space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Solver</label>
                      <select
                        value={solver}
                        onChange={(e) => setSolver(e.target.value)}
                        className="w-full p-2.5 bg-white border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                      >
                        <option value="">Default ({template?.defaultSolver})</option>
                        <optgroup label="Available">
                          <option value="highs">HiGHS (LP/MIP)</option>
                          <option value="ipopt">IPOPT (QP/NLP)</option>
                        </optgroup>
                        <optgroup label="Commercial">
                          <option value="gurobi">Gurobi</option>
                          <option value="cplex">CPLEX</option>
                        </optgroup>
                        <optgroup label="Open Source">
                          <option value="cbc">CBC</option>
                          <option value="glpk">GLPK</option>
                          <option value="scip">SCIP</option>
                        </optgroup>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Time Limit (seconds)</label>
                      <input
                        type="number"
                        value={timeLimit ?? ''}
                        onChange={(e) => setTimeLimit(e.target.value ? parseInt(e.target.value) : undefined)}
                        placeholder="No limit"
                        min={1}
                        className="w-full p-2.5 bg-white border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                      />
                    </div>
                    <div className="text-xs text-slate-500 bg-slate-50 p-3 rounded-lg">
                      {selectedTemplate === 'portfolio' ? (
                        <p><strong>IPOPT:</strong> Recommended for portfolio optimization (QP).</p>
                      ) : (
                        <>
                          <p><strong>HiGHS:</strong> Fast, open-source solver for LP and MIP problems.</p>
                          <p><strong>IPOPT:</strong> Interior point optimizer for nonlinear and quadratic problems.</p>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="p-6">
                  {selectedTemplate === 'portfolio' && template && (
                    <PortfolioInputForm
                      fields={template.fields}
                      data={data}
                      onChange={setData}
                      activeTab={optimizationTab}
                    />
                  )}
                  {selectedTemplate === 'jobshop' && (
                    optimizationTab === 'assetsData' ? (
                      <JobShopInputForm data={data} onChange={setData} />
                    ) : optimizationTab === 'objective' ? (
                      <Card className="bg-slate-50 border-slate-200">
                        <div className="p-4">
                          <p className="text-sm text-slate-700">
                            <strong>Objective:</strong> Minimize makespan (complete all jobs in the minimum total time).
                          </p>
                        </div>
                      </Card>
                    ) : (
                      <JobShopConstraintsForm data={data} onChange={setData} />
                    )
                  )}
                </div>
              )
            ) : inputMode === 'form' && template && selectedTemplate !== 'portfolio' && selectedTemplate !== 'jobshop' ? (
              /* Non-portfolio/jobshop: results at top, then form */
              <>
                {result && (
                  <>
                    <ResultsDisplay response={result} template={selectedTemplate} />
                    <p className="text-sm text-slate-500">Modify the data below and click Run again to re-optimize.</p>
                  </>
                )}
                {!result && !error && (
                  <div className="rounded-lg border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-600">
                    Fill in the problem data below and click Run to see results here.
                  </div>
                )}
                <div className="p-6">
                  {FINANCE_TEMPLATE_IDS.includes(selectedTemplate as FinanceTemplateId) ? (
                    <FinanceTemplateForm
                      templateId={selectedTemplate as FinanceTemplateId}
                      fields={template.fields}
                      data={data}
                      onChange={setData}
                    />
                  ) : (
                    <DataInputForm fields={template.fields} data={data} onChange={setData} />
                  )}
                </div>
              </>
            ) : null}

            {/* Config File Input Section */}
            {inputMode === 'config' && (
              <Card className="overflow-hidden">
                <div className="bg-slate-50 px-6 py-3 border-b border-slate-200 flex items-center justify-between">
                  <h2 className="font-semibold text-slate-700">Configuration File</h2>
                  <div className="flex items-center gap-2">
                    <label className="cursor-pointer">
                      <input
                        type="file"
                        accept=".json,.yaml,.yml"
                        onChange={handleFileUpload}
                        className="hidden"
                      />
                      <Button variant="outline" size="sm" type="button">
                        <Upload className="w-4 h-4 mr-1" />
                        Upload File
                      </Button>
                    </label>
                  </div>
                </div>
                <div className="p-6 space-y-4">
                  {configError && (
                    <div className="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-lg text-sm">
                      {configError}
                    </div>
                  )}
                  
                  <div className="space-y-2">
                    <label className="block text-sm font-medium text-slate-700">
                      Config Content (JSON or YAML)
                    </label>
                    <textarea
                      value={configContent}
                      onChange={(e) => {
                        setConfigContent(e.target.value);
                        setConfigError(null);
                      }}
                      placeholder={`{\n  "template": "${selectedTemplate}",\n  "data": {\n    // Your problem data here\n  },\n  "solver": {\n    "name": "highs",\n    "time_limit": 60\n  }\n}`}
                      className="w-full h-96 font-mono text-sm p-4 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none resize-none"
                      spellCheck={false}
                    />
                    <p className="text-xs text-slate-500">
                      Enter a JSON configuration file (YAML support coming soon). The config should include <code className="bg-slate-100 px-1 rounded">template</code>, <code className="bg-slate-100 px-1 rounded">data</code>, and optionally <code className="bg-slate-100 px-1 rounded">solver</code> fields. Click "Load Config" to parse and populate the form, then switch to Form mode to run optimization.
                    </p>
                  </div>
                  
                  <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                    <h4 className="text-sm font-semibold text-slate-700 mb-2">Config Format:</h4>
                    <pre className="text-xs text-slate-600 overflow-x-auto">
{`{
  "template": "knapsack",
  "data": {
    "items": [
      {"name": "Gold", "value": 500, "weight": 5},
      {"name": "Silver", "value": 300, "weight": 3}
    ],
    "capacity": 10
  },
  "solver": {
    "name": "highs",
    "time_limit": 60
  }
}`}
                    </pre>
                  </div>
                </div>
              </Card>
            )}

            {/* Solver Configuration - only when not using tabbed layout (portfolio/jobshop have Solver tab) */}
            {!(inputMode === 'form' && (selectedTemplate === 'portfolio' || selectedTemplate === 'jobshop')) && (
              selectedTemplate === 'portfolio' ? (
                <Card className="overflow-hidden">
                  <div className="bg-slate-50 px-4 py-2.5 border-b border-slate-200 flex items-center gap-2">
                    <Settings className="w-4 h-4 text-slate-600" />
                    <h3 className="font-semibold text-slate-700 text-sm">Solver Configuration</h3>
                  </div>
                  <div className="p-4">
                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <label className="block text-xs font-medium text-slate-700 mb-1">Solver</label>
                        <select
                          value={solver}
                          onChange={(e) => setSolver(e.target.value)}
                          className="w-full p-2 bg-white border border-slate-300 rounded text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                        >
                          <option value="">Default ({template?.defaultSolver})</option>
                          <option value="ipopt">IPOPT (QP/NLP)</option>
                          <option value="highs">HiGHS (LP/MIP)</option>
                          <option value="gurobi">Gurobi</option>
                          <option value="cplex">CPLEX</option>
                          <option value="cbc">CBC</option>
                          <option value="glpk">GLPK</option>
                          <option value="scip">SCIP</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-slate-700 mb-1">Time Limit (s)</label>
                        <input
                          type="number"
                          value={timeLimit ?? ''}
                          onChange={(e) => setTimeLimit(e.target.value ? parseInt(e.target.value) : undefined)}
                          placeholder="No limit"
                          min={1}
                          className="w-full p-2 bg-white border border-slate-300 rounded text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                        />
                      </div>
                      <div className="flex items-end">
                        <div className="text-xs text-slate-500 bg-slate-50 p-2 rounded w-full">
                          <p><strong>IPOPT:</strong> Recommended for portfolio optimization (QP)</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </Card>
              ) : (
                <Card>
                  <button
                    onClick={() => setShowAdvanced(!showAdvanced)}
                    className="w-full px-6 py-3 flex items-center justify-between text-left hover:bg-slate-50 transition-colors"
                  >
                    <div className="flex items-center gap-2">
                      <Settings className="w-4 h-4 text-slate-400" />
                      <span className="font-semibold text-slate-700">Solver Configuration</span>
                    </div>
                    {showAdvanced ? (
                      <ChevronDown className="w-4 h-4 text-slate-400" />
                    ) : (
                      <ChevronRight className="w-4 h-4 text-slate-400" />
                    )}
                  </button>
                  {showAdvanced && (
                    <div className="px-6 pb-6 pt-2 border-t border-slate-100 space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-slate-700 mb-1">Solver</label>
                          <select
                            value={solver}
                            onChange={(e) => setSolver(e.target.value)}
                            className="w-full p-2.5 bg-white border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                          >
                            <option value="">Default ({template?.defaultSolver})</option>
                            <optgroup label="Available">
                              <option value="highs">HiGHS (LP/MIP)</option>
                              <option value="ipopt">IPOPT (QP/NLP)</option>
                            </optgroup>
                            <optgroup label="Commercial">
                              <option value="gurobi">Gurobi</option>
                              <option value="cplex">CPLEX</option>
                            </optgroup>
                            <optgroup label="Open Source">
                              <option value="cbc">CBC</option>
                              <option value="glpk">GLPK</option>
                              <option value="scip">SCIP</option>
                            </optgroup>
                          </select>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-slate-700 mb-1">Time Limit (seconds)</label>
                          <input
                            type="number"
                            value={timeLimit ?? ''}
                            onChange={(e) => setTimeLimit(e.target.value ? parseInt(e.target.value) : undefined)}
                            placeholder="No limit"
                            min={1}
                            className="w-full p-2.5 bg-white border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                          />
                        </div>
                      </div>
                      <div className="text-xs text-slate-500 bg-slate-50 p-3 rounded-lg">
                        <p><strong>HiGHS:</strong> Fast, open-source solver for LP and MIP problems.</p>
                        <p><strong>IPOPT:</strong> Interior point optimizer for nonlinear and quadratic problems.</p>
                      </div>
                    </div>
                  )}
                </Card>
              )
            )}

          </div>
        </div>
      </div>
    </div>
  );
}
