/**
 * Settings page
 *
 * Configure API server URL
 */

'use client';

import { useState, useEffect } from 'react';
import { PageHeader } from '@/components/common';
import { getSettings, saveSettings, type AppSettings } from '@/lib/settings';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2 } from 'lucide-react';
import { useAppConfigStore, selectVersion } from '@/stores/app-config';

export default function SettingsPage() {
  const version = useAppConfigStore(selectVersion);
  const [settings, setSettings] = useState<AppSettings>(getSettings());
  const [saving, setSaving] = useState(false);
  const [saveMessage, setSaveMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const handleSave = async () => {
    setSaving(true);
    setSaveMessage(null);

    try {
      saveSettings(settings);
      setSaveMessage({ type: 'success', text: 'Settings saved successfully!' });

      // Reload page to apply API URL changes
      setTimeout(() => {
        window.location.reload();
      }, 1000);
    } catch (error) {
      setSaveMessage({ type: 'error', text: `Failed to save settings: ${error instanceof Error ? error.message : 'Unknown error'}` });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <PageHeader
          title="Settings"
          description={version ? `Configure PyOptima UI settings and API server connection (${version})` : 'Configure PyOptima UI settings and API server connection'}
        />

        {saveMessage && (
          <Alert className={`mt-4 ${saveMessage.type === 'success' ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}`}>
            <AlertDescription className={saveMessage.type === 'success' ? 'text-green-800' : 'text-red-800'}>
              {saveMessage.text}
            </AlertDescription>
          </Alert>
        )}

        <div className="mt-8 space-y-6">
          {/* API Server Configuration */}
          <Card>
            <CardHeader>
              <CardTitle>API Server</CardTitle>
              <CardDescription>
                Configure the PyOptima API server URL that this UI will connect to
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="api-url">API Server URL</Label>
                <Input
                  id="api-url"
                  type="text"
                  value={settings.apiServer.url}
                  onChange={(e) =>
                    setSettings({
                      ...settings,
                      apiServer: { ...settings.apiServer, url: e.target.value },
                    })
                  }
                  placeholder="http://localhost:8003"
                />
                <p className="text-sm text-muted-foreground">
                  Enter the full URL of your PyOptima API server (e.g., http://localhost:8003)
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Save Button */}
          <div className="flex justify-end">
            <Button onClick={handleSave} disabled={saving} size="lg">
              {saving ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : (
                'Save Settings'
              )}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
