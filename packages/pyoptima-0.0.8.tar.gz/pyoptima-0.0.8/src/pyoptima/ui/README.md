# PyOptima UI

Standalone Next.js + React UI for PyOptima built with Tailwind CSS and Recharts.

## Features

- ✅ **Next.js 16 App Router** - Latest Next.js features
- ✅ **TypeScript** - Full type safety
- ✅ **Tailwind CSS** - Utility-first styling
- ✅ **Recharts** - Beautiful charts for visualization
- ✅ **Portfolio Optimization Interface** - Interactive optimization workspace
- ✅ **Real-time API Integration** - Connects to PyOptima API

## Installation

The UI is an optional component. Install it with:

```bash
pip install pyoptima[ui]
```

Then install npm dependencies:

```bash
cd ui
npm install
```

## Development

### Prerequisites

- Node.js 18+ and npm
- PyOptima API server running (optional, but required for full functionality)

### Setup

1. Install dependencies:
   ```bash
   cd ui
   npm install
   ```

2. Create `.env.local`:
   ```bash
   NEXT_PUBLIC_API_URL=http://localhost:8000
   ```

3. Run development server:
   ```bash
   pyoptima ui dev
   # or
   npm run dev
   ```

   The UI will be available at `http://localhost:3000`

### Building for Production

1. Build the UI:
   ```bash
   pyoptima ui build
   # or
   npm run build
   ```

2. Serve the built UI:
   ```bash
   pyoptima ui serve
   ```

## Project Structure

```
ui/
├── src/
│   ├── app/              # Next.js App Router pages
│   │   ├── layout.tsx    # Root layout
│   │   ├── page.tsx      # Portfolio optimization page
│   │   └── globals.css   # Global styles
│   └── lib/
│       └── api.ts         # API client
├── server.py              # FastAPI server for serving static files
├── dev.py                 # Development server wrapper
├── build.py               # Build script
└── package.json           # npm dependencies
```

## Usage

### Portfolio Optimization Interface

The UI provides an interactive interface for portfolio optimization:

1. **Asset Universe Tab**: Define assets, expected returns, volatility, and weight bounds
2. **Constraints Tab**: Add advanced constraints (sector caps, cardinality, etc.)
3. **Results Tab**: View optimization results, efficient frontier, and allocations

### Features

- **Multiple Optimization Methods**: Min Volatility, Max Sharpe, Black-Litterman, CVaR, etc.
- **Solver Selection**: IPOPT, CBC, GLPK, Gurobi
- **Real-time Optimization**: Submit jobs and view results
- **Visualizations**: Efficient frontier charts, allocation breakdowns
- **Constraint Management**: Add/remove constraints dynamically

## Configuration

- `next.config.js` - Next.js configuration
- `tailwind.config.js` - Tailwind CSS configuration
- `tsconfig.json` - TypeScript configuration
- `.env.local` - Environment variables (API URL)

## API Integration

The UI integrates with the PyOptima API:
- In development: Next.js rewrites handle proxying
- In production: FastAPI server handles proxying

Make sure the PyOptima API server is running for the UI to function properly.

## Running the UI

### Development Mode

```bash
pyoptima ui dev
```

### Production Mode

```bash
# Build first
pyoptima ui build

# Then serve
pyoptima ui serve
```

## Notes

- The UI follows the same pattern as PyCharter UI
- Static files are built and can be included in the package
- API proxying is handled automatically
- The UI is a single-page application (SPA) with client-side routing
