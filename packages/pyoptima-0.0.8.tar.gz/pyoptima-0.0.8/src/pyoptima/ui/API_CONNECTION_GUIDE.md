# API Connection Guide

## Why This Error Occurs

The error "Unable to connect to API server at http://localhost:8001" means the UI cannot reach the PyOptima API server. This happens when:

1. **The API server is not running** - Most common cause
2. **The API URL is incorrect** - The UI is configured to connect to the wrong port/URL
3. **The API server is on a different port** - Your API might be running on port 8000 but UI is configured for 8001

## Quick Fix

### Option 1: Start the API Server (Recommended)

The API server needs to be running for the UI to work. Start it with:

```bash
# Default port (8000)
pyoptima api

# Or specify a port
pyoptima api --port 8001
```

### Option 2: Update the API URL in Settings

If your API is already running on a different port:

1. Go to **Settings** page in the UI (click Settings in the navigation)
2. Update the "API Server URL" field to match your API server
3. Click "Save Settings"
4. The page will reload and connect to the new URL

### Option 3: Use Environment Variable

Set the API URL when starting the UI:

```bash
# For dev server
PYOPTIMA_API_URL=http://localhost:8001 pyoptima ui dev

# Or for production server
PYOPTIMA_API_URL=http://localhost:8001 pyoptima ui serve
```

## Default Ports

- **API Server**: `http://localhost:8000` (default)
- **UI Dev Server**: `http://localhost:3000` (default)
- **UI Production Server**: `http://localhost:3000` (default)

## Verify API is Running

Check if the API server is responding:

```bash
# Health check
curl http://localhost:8000/health

# Should return:
# {"status":"healthy","version":"...","solvers_available":...,"templates_available":...}
```

## Common Scenarios

### Scenario 1: First Time Setup
1. Start the API: `pyoptima api`
2. In another terminal, start the UI: `pyoptima ui dev`
3. Open `http://localhost:3000` in your browser

### Scenario 2: API on Different Port
If your API is running on port 8001:
1. Go to Settings in the UI
2. Change API URL to `http://localhost:8001`
3. Save and reload

### Scenario 3: API Running Remotely
If your API is on a remote server:
1. Go to Settings in the UI
2. Change API URL to `http://your-server:8000`
3. Save and reload
4. Make sure CORS is configured on the API server

## Troubleshooting

### Check API Server Status
```bash
# Check if port is in use
lsof -i :8000  # Linux/Mac
netstat -ano | findstr :8000  # Windows
```

### Check UI Settings
The UI stores API URL in browser localStorage. To reset:
1. Open browser DevTools (F12)
2. Go to Application/Storage → Local Storage
3. Find `pyoptima_settings`
4. Delete or update the `apiServer.url` value

### Check Network Tab
In browser DevTools → Network tab, check:
- Is the request being made to the correct URL?
- What's the response status code?
- Any CORS errors?

## Error Message Details

The improved error message now shows:
- Current API URL being used
- Command to start the API server
- Link to Settings page
- Suggestions for fixing the issue
