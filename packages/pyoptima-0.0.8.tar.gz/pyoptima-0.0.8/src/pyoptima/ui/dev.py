"""
Development server wrapper for PyOptima UI.

Runs Next.js dev server with API proxying configured.
"""

import os
import subprocess
import sys
from pathlib import Path


def get_ui_root() -> Path:
    """Get the root directory of the UI module."""
    return Path(__file__).parent


def run_dev_server(
    api_url: str | None = None,
    port: int = 3003,
) -> None:
    """
        Run Next.js development server.

        Args:
    api_url: URL of the PyOptima API (defaults to http://localhost:8003)
        port: Port to run dev server on (default: 3003)
    """
    ui_root = get_ui_root()

    # Check if package.json exists
    package_json = ui_root / "package.json"
    if not package_json.exists():
        print(f"Error: package.json not found at {package_json}", file=sys.stderr)
        print("Please initialize the Next.js project first.", file=sys.stderr)
        sys.exit(1)

    # Get API URL from environment or argument
    if api_url is None:
        api_url = os.getenv("PYOPTIMA_API_URL", "http://localhost:8003")

    # Set environment variables for Next.js
    env = os.environ.copy()
    env["NEXT_PUBLIC_API_URL"] = api_url
    env["PORT"] = str(port)

    # Check if node_modules exists, if not, suggest running npm install
    node_modules = ui_root / "node_modules"
    if not node_modules.exists():
        print(
            "Warning: node_modules not found. Running 'npm install' first...",
            file=sys.stderr,
        )
        try:
            subprocess.run(
                ["npm", "install"],
                cwd=str(ui_root),
                check=True,
                env=env,
            )
        except subprocess.CalledProcessError as e:
            print(f"Error: npm install failed: {e}", file=sys.stderr)
            sys.exit(1)
        except FileNotFoundError:
            print(
                "Error: npm not found. Please install Node.js and npm.", file=sys.stderr
            )
            sys.exit(1)

    print("PyOptima UI development server starting...")
    print(f"  UI: http://localhost:{port}")
    print(f"  API: {api_url}")
    print(f"  API proxied via: /api/* -> {api_url}/api/*")
    print()

    # Run Next.js dev server
    try:
        subprocess.run(
            ["npm", "run", "dev"],
            cwd=str(ui_root),
            env=env,
        )
    except KeyboardInterrupt:
        print("\nShutting down dev server...", file=sys.stderr)
        sys.exit(0)
    except FileNotFoundError:
        print("Error: npm not found. Please install Node.js and npm.", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="PyOptima UI Development Server")
    parser.add_argument(
        "--api-url",
        type=str,
        default=None,
        help="URL of the PyOptima API (default: http://localhost:8003 or PYOPTIMA_API_URL env var)",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=3003,
        help="Port to run dev server on (default: 3003)",
    )

    args = parser.parse_args()
    run_dev_server(api_url=args.api_url, port=args.port)
