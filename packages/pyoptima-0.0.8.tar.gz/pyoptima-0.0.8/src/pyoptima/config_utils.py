"""
Config utility functions for validation, generation, and comparison.

- :func:`validate` --- Validate a config without solving.
- :func:`generate` --- Generate an example config for a template.
- :func:`diff` --- Compare two configs and show differences.

Example::

    from pyoptima.config_utils import validate, generate, diff

    # Validate a config file
    errors = validate("portfolio_config.yaml")
    if errors:
        print("Validation errors:", errors)

    # Generate example config
    example = generate("portfolio")
    print(example)

    # Compare two configs
    differences = diff("config1.yaml", "config2.yaml")
    for d in differences:
        print(d)
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# Validate
# ---------------------------------------------------------------------------


def validate(config: str | Path | dict[str, Any]) -> list[str]:
    """Validate a config without solving.

    Returns an empty list if the config is valid, otherwise a list of
    human-readable error messages.

    Args:
        config: Path to a YAML/JSON file, or a dict.

    Returns:
        List of validation error strings.

    Example::

        errors = validate("portfolio_config.yaml")
        if not errors:
            print("Config is valid!")
    """
    errors: list[str] = []

    # Load file
    if isinstance(config, (str, Path)):
        try:
            from pyoptima.configs import _read_file

            data = _read_file(config)
        except FileNotFoundError as e:
            return [str(e)]
        except Exception as e:
            return [f"Failed to read config file: {e}"]
    else:
        data = config

    # Check template field exists
    if "template" not in data:
        errors.append("Missing required field: 'template'")
        return errors

    # Validate against the structured config model
    try:
        from pyoptima.configs import load

        load(data)
    except Exception as e:
        # Parse Pydantic validation errors into human-readable messages
        error_str = str(e)
        if hasattr(e, "errors"):
            for err in e.errors():
                loc = " -> ".join(str(part) for part in err.get("loc", []))
                msg = err.get("msg", "unknown error")
                errors.append(f"{loc}: {msg}")
        else:
            errors.append(error_str)
        return errors

    return errors


# ---------------------------------------------------------------------------
# Generate
# ---------------------------------------------------------------------------

# Example configs for each template
_EXAMPLES: dict[str, dict[str, Any]] = {
    "portfolio": {
        "template": "portfolio",
        "objective": {
            "name": "min_volatility",
            "risk_free_rate": 0.02,
        },
        "data": {
            "symbols": ["AAPL", "GOOGL", "MSFT", "AMZN", "TSLA"],
            "expected_returns": [0.12, 0.10, 0.08, 0.15, 0.11],
            "covariance_matrix": [
                [0.0400, 0.0120, 0.0100, 0.0150, 0.0200],
                [0.0120, 0.0350, 0.0080, 0.0110, 0.0160],
                [0.0100, 0.0080, 0.0250, 0.0090, 0.0120],
                [0.0150, 0.0110, 0.0090, 0.0500, 0.0250],
                [0.0200, 0.0160, 0.0120, 0.0250, 0.0600],
            ],
        },
        "constraints": {
            "weight_bounds": {"min": 0.0, "max": 0.4},
        },
        "solver": {
            "name": "highs",
            "verbose": False,
        },
    },
    "execution": {
        "template": "execution",
        "strategy": "twap",
        "data": {
            "symbol": "AAPL",
            "total_quantity": 10000,
            "side": "buy",
            "adv": 75000000,
        },
        "params": {
            "horizon_minutes": 120,
            "interval_minutes": 5,
        },
        "constraints": {
            "max_participation": 0.10,
        },
        "solver": {
            "name": "highs",
            "verbose": False,
        },
    },
    "rebalance": {
        "template": "rebalance",
        "strategy": "min_cost",
        "data": {
            "symbols": ["AAPL", "GOOGL", "MSFT"],
            "current_weights": {"AAPL": 0.40, "GOOGL": 0.35, "MSFT": 0.25},
            "target_weights": {"AAPL": 0.33, "GOOGL": 0.34, "MSFT": 0.33},
            "transaction_costs": 0.001,
        },
        "constraints": {
            "max_turnover": 0.20,
        },
        "solver": {
            "name": "highs",
            "verbose": False,
        },
    },
    "signal_sizing": {
        "template": "signal_sizing",
        "strategy": "mean_risk",
        "objective": {
            "risk_aversion": 1.0,
        },
        "data": {
            "symbols": ["AAPL", "GOOGL", "MSFT"],
            "signals": {"AAPL": 0.8, "GOOGL": -0.3, "MSFT": 0.5},
            "covariance_matrix": [
                [0.04, 0.01, 0.02],
                [0.01, 0.03, 0.015],
                [0.02, 0.015, 0.025],
            ],
        },
        "constraints": {
            "max_position": 0.30,
            "max_gross_exposure": 1.0,
        },
        "solver": {
            "name": "highs",
            "verbose": False,
        },
    },
    "risk_budget": {
        "template": "risk_budget",
        "strategy": "reduce",
        "data": {
            "symbols": ["AAPL", "GOOGL", "MSFT"],
            "current_weights": {"AAPL": 0.40, "GOOGL": 0.35, "MSFT": 0.25},
            "covariance_matrix": [
                [0.04, 0.01, 0.02],
                [0.01, 0.03, 0.015],
                [0.02, 0.015, 0.025],
            ],
        },
        "constraints": {
            "max_volatility": 0.20,
            "confidence_level": 0.05,
        },
        "solver": {
            "name": "highs",
            "verbose": False,
        },
    },
    "trading_schedule": {
        "template": "trading_schedule",
        "strategy": "priority",
        "data": {
            "tasks": [
                {"name": "order_AAPL", "duration_minutes": 30, "priority": 1},
                {"name": "order_GOOGL", "duration_minutes": 45, "priority": 2},
                {"name": "order_MSFT", "duration_minutes": 20, "priority": 3},
            ],
            "session_start": "09:30",
            "session_end": "16:00",
            "slot_minutes": 5,
        },
        "solver": {
            "name": "highs",
            "verbose": False,
        },
    },
    "multi_account": {
        "template": "multi_account",
        "strategy": "joint",
        "objective": "min_volatility",
        "data": {
            "symbols": ["AAPL", "GOOGL", "MSFT"],
            "expected_returns": [0.12, 0.10, 0.08],
            "covariance_matrix": [
                [0.04, 0.01, 0.02],
                [0.01, 0.03, 0.015],
                [0.02, 0.015, 0.025],
            ],
            "accounts": [
                {"name": "aggressive", "min_weight": 0.0, "max_weight": 0.6},
                {"name": "conservative", "min_weight": 0.05, "max_weight": 0.4},
            ],
        },
        "solver": {
            "name": "highs",
            "verbose": False,
        },
    },
}


def generate(
    template: str,
    format: str = "yaml",
) -> str:
    """Generate an example config for a template.

    Args:
        template: Template name (e.g. ``"portfolio"``, ``"execution"``).
        format: Output format — ``"yaml"`` or ``"json"``.

    Returns:
        Config string in the requested format.

    Example::

        print(generate("portfolio"))
        print(generate("execution", format="json"))
    """
    if template not in _EXAMPLES:
        available = ", ".join(sorted(_EXAMPLES))
        raise ValueError(f"Unknown template '{template}'. Available: {available}")

    example = _EXAMPLES[template]

    if format == "json":
        return json.dumps(example, indent=2)
    elif format == "yaml":
        try:
            import yaml

            return yaml.dump(example, default_flow_style=False, sort_keys=False)
        except ImportError:
            # Fall back to JSON if PyYAML not available
            return json.dumps(example, indent=2)
    else:
        raise ValueError(f"Unsupported format '{format}'. Use 'yaml' or 'json'.")


# ---------------------------------------------------------------------------
# Diff
# ---------------------------------------------------------------------------


def diff(
    config1: str | Path | dict[str, Any],
    config2: str | Path | dict[str, Any],
) -> list[str]:
    """Compare two configs and return a list of differences.

    Args:
        config1: First config (path or dict).
        config2: Second config (path or dict).

    Returns:
        List of human-readable difference strings.

    Example::

        diffs = diff("config_v1.yaml", "config_v2.yaml")
        for d in diffs:
            print(d)
    """
    if isinstance(config1, (str, Path)):
        from pyoptima.configs import _read_file

        data1 = _read_file(config1)
    else:
        data1 = config1

    if isinstance(config2, (str, Path)):
        from pyoptima.configs import _read_file

        data2 = _read_file(config2)
    else:
        data2 = config2

    differences: list[str] = []
    _diff_dicts(data1, data2, "", differences)
    return differences


def _diff_dicts(
    d1: Any,
    d2: Any,
    path: str,
    differences: list[str],
) -> None:
    """Recursively compare two dicts/values and record differences."""
    if isinstance(d1, dict) and isinstance(d2, dict):
        all_keys = set(d1) | set(d2)
        for key in sorted(all_keys):
            new_path = f"{path}.{key}" if path else key
            if key not in d1:
                differences.append(f"+ {new_path}: {_format_val(d2[key])} (added)")
            elif key not in d2:
                differences.append(f"- {new_path}: {_format_val(d1[key])} (removed)")
            else:
                _diff_dicts(d1[key], d2[key], new_path, differences)
    elif isinstance(d1, list) and isinstance(d2, list):
        if d1 != d2:
            if len(d1) != len(d2):
                differences.append(f"~ {path}: length {len(d1)} -> {len(d2)}")
            else:
                for i, (a, b) in enumerate(zip(d1, d2)):
                    _diff_dicts(a, b, f"{path}[{i}]", differences)
    else:
        if d1 != d2:
            differences.append(f"~ {path}: {_format_val(d1)} -> {_format_val(d2)}")


def _format_val(val: Any) -> str:
    """Format a value for diff output."""
    if isinstance(val, str):
        return repr(val)
    if isinstance(val, dict):
        return f"{{...}} ({len(val)} keys)"
    if isinstance(val, list):
        return f"[...] ({len(val)} items)"
    return str(val)
