"""
Base SQLAlchemy configuration for PyOptima worker queue.

Supports SQLite and PostgreSQL. No schema prefix (table names only)
so SQLite works without stripping.
"""

from __future__ import annotations

from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker

Base = declarative_base()


def get_engine(connection_string: str):
    """
    Create SQLAlchemy engine from connection string.

    For SQLite, enables foreign keys and check_same_thread=False for async use.
    """
    if connection_string.startswith("sqlite://"):
        engine = create_engine(
            connection_string,
            echo=False,
            connect_args=(
                {"check_same_thread": False}
                if connection_string != "sqlite:///:memory:"
                else {}
            ),
        )
        from sqlalchemy import event

        @event.listens_for(engine, "connect")
        def set_sqlite_pragma(dbapi_conn, connection_record):
            cursor = dbapi_conn.cursor()
            cursor.execute("PRAGMA foreign_keys=ON")
            cursor.close()

        return engine
    return create_engine(connection_string, echo=False)


def get_schema_prefix(connection_string: str) -> str:
    """Return schema prefix for raw SQL: empty for both (no schema in use)."""
    return ""


def get_session(connection_string: str):
    """Create SQLAlchemy session from connection string."""
    engine = get_engine(connection_string)
    Session = sessionmaker(bind=engine)
    return Session()
