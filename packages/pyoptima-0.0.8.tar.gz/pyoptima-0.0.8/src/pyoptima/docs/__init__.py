"""Documentation CLI for MkDocs: pyoptima docs serve / pyoptima docs build."""
