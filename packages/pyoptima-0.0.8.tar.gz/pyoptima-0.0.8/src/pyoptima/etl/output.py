"""
ETL Output Formatter.

Formats pyoptima optimization results into ETL-ready output records.
"""

from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any, Union

if TYPE_CHECKING:
    from pyoptima.core.result import OptimizationResult


def _result_to_dict(
    result: Union["OptimizationResult", dict[str, Any]],
) -> dict[str, Any]:
    """Normalize result to dict for formatting."""
    if hasattr(result, "to_dict"):
        return result.to_dict()
    return dict(result) if result else {}


class ETLOutputFormatter:
    """
    Formatter for converting pyoptima results to ETL-compatible output.

    Output format matches standard ETL load table schema:
    - job_id: Unique identifier
    - optimization_type: Objective name
    - symbols: List of asset symbols
    - weights: Dict of symbol -> weight
    - expected_return: Portfolio expected return
    - volatility: Portfolio volatility
    - sharpe_ratio: Sharpe ratio
    - status: Optimization status
    - parameters: Additional metadata
    """

    @classmethod
    def format_result(
        cls,
        result: Union["OptimizationResult", dict[str, Any]],
        job_id: str,
        objective: str,
        symbols: list[str] | None = None,
        solver: str = "ipopt",
        extra_params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        Format a single optimization result for ETL loading.

        Args:
            result: OptimizationResult from solve/optimize_single.
            job_id: Unique job identifier.
            objective: Optimization objective name.
            symbols: List of asset symbols.
            solver: Solver used.
            extra_params: Additional parameters to include.

        Returns:
            ETL-ready output record.
        """
        run_at = datetime.now(UTC).isoformat()
        result = _result_to_dict(result)

        # Normalize error message key
        if "error" not in result:
            if "message" in result:
                result["error"] = result.pop("message")
            elif "solver_message" in result and result.get("solver_message"):
                result["error"] = result.pop("solver_message")

        # Extract weights
        weights = result.get("weights") or {}

        # Determine symbols from various sources
        if symbols is None:
            if isinstance(weights, dict):
                symbols = list(weights.keys())
            else:
                symbols = []

        # Extract portfolio metrics
        portfolio_return = (
            result.get("portfolio_return")
            or result.get("expected_return")
            or result.get("return")
        )
        portfolio_volatility = (
            result.get("portfolio_volatility")
            or result.get("volatility")
            or result.get("risk")
        )
        sharpe_ratio = result.get("sharpe_ratio")
        status = str(result.get("status", "unknown"))

        # Build parameters dict with metadata
        parameters: dict[str, Any] = {
            "solver": solver,
            "run_at": run_at,
        }

        # Include method-specific metrics
        for key in [
            "objective_value",
            "cvar",
            "cdar",
            "semivariance",
            "diversification_ratio",
        ]:
            if key in result and result[key] is not None:
                parameters[key] = result[key]

        # Include any error message
        if "error" in result:
            parameters["error"] = result["error"]

        # Merge extra parameters
        if extra_params:
            parameters.update(extra_params)

        return {
            "job_id": job_id,
            "optimization_type": objective,
            "symbols": symbols,
            "weights": weights,
            "expected_return": (
                float(portfolio_return) if portfolio_return is not None else None
            ),
            "volatility": (
                float(portfolio_volatility)
                if portfolio_volatility is not None
                else None
            ),
            "sharpe_ratio": float(sharpe_ratio) if sharpe_ratio is not None else None,
            "status": status,
            "parameters": parameters,
        }

    @classmethod
    def format_error(
        cls,
        error: Exception,
        job_id: str,
        objective: str,
        symbols: list[str] | None = None,
        solver: str = "ipopt",
    ) -> dict[str, Any]:
        """
        Format an error result for ETL loading.

        Args:
            error: The exception that occurred.
            job_id: Unique job identifier.
            objective: Optimization objective name.
            symbols: List of asset symbols.
            solver: Solver used.

        Returns:
            ETL-ready error record.
        """
        run_at = datetime.now(UTC).isoformat()

        parameters: dict[str, Any] = {
            "solver": solver,
            "run_at": run_at,
            "error": str(error),
        }
        if hasattr(error, "error_code") and error.error_code is not None:
            parameters["error_code"] = error.error_code.value
        return {
            "job_id": job_id,
            "optimization_type": objective,
            "symbols": symbols or [],
            "weights": {},
            "expected_return": None,
            "volatility": None,
            "sharpe_ratio": None,
            "status": "error",
            "parameters": parameters,
        }

    @classmethod
    def format_batch(
        cls,
        results: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """
        Ensure batch results have consistent structure.

        Args:
            results: List of formatted results.

        Returns:
            List with consistent structure (all keys present).
        """
        required_keys = [
            "job_id",
            "optimization_type",
            "symbols",
            "weights",
            "expected_return",
            "volatility",
            "sharpe_ratio",
            "status",
            "parameters",
        ]

        normalized = []
        for result in results:
            record = {}
            for key in required_keys:
                if key in result:
                    record[key] = result[key]
                elif key in ("symbols",):
                    record[key] = []
                elif key in ("weights", "parameters"):
                    record[key] = {}
                else:
                    record[key] = None
            normalized.append(record)

        return normalized
