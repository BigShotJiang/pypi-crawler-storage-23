"""
Risk models for trading and portfolio optimizations.

Provides pluggable risk models that compute portfolio-level risk from weights
and market data. Used by execution, rebalance, risk-budget, and portfolio
templates.

Models
------
- **CovarianceRiskModel** — Standard ``w' Σ w`` (full covariance).
- **FactorRiskModel** — Factor-based ``w' B Σ_f B' w + w' D w``.
"""

from __future__ import annotations

import math
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

import numpy as np


class RiskModel(ABC):
    """
    Base class for portfolio risk models.

    All risk models implement :meth:`portfolio_variance` (annualised variance)
    and the convenience property :meth:`portfolio_risk` which returns the
    standard deviation (volatility).
    """

    @abstractmethod
    def portfolio_variance(self, weights: np.ndarray) -> float:
        """
        Compute annualised portfolio variance.

        Args:
            weights: 1-D array of portfolio weights (length *n*).

        Returns:
            Scalar variance (w' Σ w or equivalent).
        """
        ...

    def portfolio_risk(self, weights: np.ndarray) -> float:
        """
        Compute annualised portfolio volatility (standard deviation).

        Args:
            weights: 1-D array of portfolio weights.

        Returns:
            Portfolio volatility (√variance).
        """
        var = self.portfolio_variance(weights)
        return math.sqrt(max(var, 0.0))

    def marginal_risk(self, weights: np.ndarray) -> np.ndarray:
        """
        Compute marginal contribution to risk for each asset.

        Returns ∂σ/∂w_i for each asset, computed as (Σ w) / σ.
        Default implementation uses numerical differentiation; subclasses
        may override for closed-form.

        Args:
            weights: 1-D array of portfolio weights.

        Returns:
            1-D array of marginal risk contributions.
        """
        w = np.asarray(weights, dtype=float)
        n = len(w)
        sigma = self.portfolio_risk(w)
        if sigma == 0.0:
            return np.zeros(n)

        eps = 1e-8
        grad = np.zeros(n)
        for i in range(n):
            w_up = w.copy()
            w_up[i] += eps
            grad[i] = (self.portfolio_risk(w_up) - sigma) / eps
        return grad

    def risk_contributions(self, weights: np.ndarray) -> np.ndarray:
        """
        Percentage risk contribution of each asset.

        Returns w_i × (∂σ/∂w_i) / σ for each asset. Sums to ~1.

        Args:
            weights: 1-D array of portfolio weights.

        Returns:
            1-D array of percentage risk contributions.
        """
        w = np.asarray(weights, dtype=float)
        sigma = self.portfolio_risk(w)
        if sigma == 0.0:
            return np.zeros(len(w))
        mc = self.marginal_risk(w)
        return (w * mc) / sigma

    @property
    @abstractmethod
    def name(self) -> str:
        """Short identifier for this risk model."""
        ...

    def to_dict(self) -> dict[str, Any]:
        """Serialise the model."""
        return {"name": self.name}

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}()"


@dataclass
class CovarianceRiskModel(RiskModel):
    """
    Standard full-covariance risk model.

    .. math::

        \\sigma^2_p = w^T \\Sigma w

    Args:
        covariance_matrix: *n × n* annualised covariance matrix.

    Example::

        cov = np.array([[0.04, 0.01], [0.01, 0.09]])
        model = CovarianceRiskModel(covariance_matrix=cov)
        vol = model.portfolio_risk(np.array([0.6, 0.4]))
    """

    covariance_matrix: np.ndarray = field(default_factory=lambda: np.empty(0))

    def __post_init__(self) -> None:
        self.covariance_matrix = np.asarray(self.covariance_matrix, dtype=float)
        if self.covariance_matrix.size > 0 and self.covariance_matrix.ndim != 2:
            raise ValueError("covariance_matrix must be 2-D")

    @property
    def name(self) -> str:
        return "covariance"

    @property
    def n_assets(self) -> int:
        if self.covariance_matrix.size == 0:
            return 0
        return self.covariance_matrix.shape[0]

    def portfolio_variance(self, weights: np.ndarray) -> float:
        w = np.asarray(weights, dtype=float)
        if w.shape[0] != self.n_assets:
            raise ValueError(
                f"weights length ({w.shape[0]}) != covariance dimension ({self.n_assets})"
            )
        return float(w @ self.covariance_matrix @ w)

    def marginal_risk(self, weights: np.ndarray) -> np.ndarray:
        """Closed-form: (Σ w) / σ."""
        w = np.asarray(weights, dtype=float)
        sigma = self.portfolio_risk(w)
        if sigma == 0.0:
            return np.zeros(len(w))
        return (self.covariance_matrix @ w) / sigma

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "covariance_matrix": self.covariance_matrix.tolist(),
        }

    def __repr__(self) -> str:
        return f"CovarianceRiskModel(n_assets={self.n_assets})"


@dataclass
class FactorRiskModel(RiskModel):
    """
    Factor-based risk model.

    .. math::

        \\sigma^2_p = w^T B \\Sigma_f B^T w + w^T D w

    where *B* is the *n × k* factor loading matrix, *Σ_f* is the
    *k × k* factor covariance matrix, and *D* is the *n × n* diagonal
    matrix of idiosyncratic (specific) variances.

    Args:
        factor_loadings: *n × k* matrix of asset exposures to factors.
        factor_covariance: *k × k* factor covariance matrix.
        specific_variance: Length-*n* array of idiosyncratic variances.
        factor_names: Optional labels for the *k* factors.

    Example::

        B = np.array([[1.1, 0.2], [0.9, -0.1], [0.8, 0.5]])
        Sigma_f = np.array([[0.04, 0.005], [0.005, 0.01]])
        D = np.array([0.001, 0.002, 0.0015])
        model = FactorRiskModel(B, Sigma_f, D, factor_names=["Market", "Size"])
        vol = model.portfolio_risk(np.array([0.4, 0.3, 0.3]))
    """

    factor_loadings: np.ndarray = field(default_factory=lambda: np.empty(0))
    factor_covariance: np.ndarray = field(default_factory=lambda: np.empty(0))
    specific_variance: np.ndarray = field(default_factory=lambda: np.empty(0))
    factor_names: list[str] | None = None

    def __post_init__(self) -> None:
        self.factor_loadings = np.asarray(self.factor_loadings, dtype=float)
        self.factor_covariance = np.asarray(self.factor_covariance, dtype=float)
        self.specific_variance = np.asarray(self.specific_variance, dtype=float)
        if self.factor_loadings.size > 0:
            if self.factor_loadings.ndim != 2:
                raise ValueError("factor_loadings must be 2-D (n_assets × n_factors)")
            n, k = self.factor_loadings.shape
            if self.factor_covariance.shape != (k, k):
                raise ValueError(
                    f"factor_covariance must be {k}×{k}, "
                    f"got {self.factor_covariance.shape}"
                )
            if self.specific_variance.shape != (n,):
                raise ValueError(
                    f"specific_variance must have length {n}, "
                    f"got {self.specific_variance.shape}"
                )

    @property
    def name(self) -> str:
        return "factor"

    @property
    def n_assets(self) -> int:
        if self.factor_loadings.size == 0:
            return 0
        return self.factor_loadings.shape[0]

    @property
    def n_factors(self) -> int:
        if self.factor_loadings.size == 0:
            return 0
        return self.factor_loadings.shape[1]

    def portfolio_variance(self, weights: np.ndarray) -> float:
        w = np.asarray(weights, dtype=float)
        if w.shape[0] != self.n_assets:
            raise ValueError(
                f"weights length ({w.shape[0]}) != n_assets ({self.n_assets})"
            )
        B = self.factor_loadings
        Sf = self.factor_covariance
        D = np.diag(self.specific_variance)

        # Factor risk: w' B Σ_f B' w
        Bw = B.T @ w
        factor_var = float(Bw @ Sf @ Bw)

        # Specific risk: w' D w
        specific_var = float(w @ D @ w)

        return factor_var + specific_var

    def marginal_risk(self, weights: np.ndarray) -> np.ndarray:
        """Closed-form: (B Σ_f B' w + D w) / σ."""
        w = np.asarray(weights, dtype=float)
        sigma = self.portfolio_risk(w)
        if sigma == 0.0:
            return np.zeros(len(w))
        B = self.factor_loadings
        Sf = self.factor_covariance
        D = np.diag(self.specific_variance)
        cov_w = B @ Sf @ B.T @ w + D @ w
        return cov_w / sigma

    def factor_exposures(self, weights: np.ndarray) -> dict[str, float]:
        """
        Compute portfolio factor exposures (B' w).

        Args:
            weights: Portfolio weights.

        Returns:
            Dict mapping factor name → exposure.
        """
        w = np.asarray(weights, dtype=float)
        exposures = self.factor_loadings.T @ w
        names = self.factor_names or [f"factor_{i}" for i in range(self.n_factors)]
        return {name: float(exp) for name, exp in zip(names, exposures)}

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "name": self.name,
            "factor_loadings": self.factor_loadings.tolist(),
            "factor_covariance": self.factor_covariance.tolist(),
            "specific_variance": self.specific_variance.tolist(),
        }
        if self.factor_names:
            d["factor_names"] = self.factor_names
        return d

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> FactorRiskModel:
        return cls(
            factor_loadings=np.array(d["factor_loadings"]),
            factor_covariance=np.array(d["factor_covariance"]),
            specific_variance=np.array(d["specific_variance"]),
            factor_names=d.get("factor_names"),
        )

    def __repr__(self) -> str:
        return f"FactorRiskModel(n_assets={self.n_assets}, n_factors={self.n_factors})"
