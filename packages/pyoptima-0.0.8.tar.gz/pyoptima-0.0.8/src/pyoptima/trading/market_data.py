"""
Market data containers for trading optimizations.

Provides standardized data structures for volume profiles, per-asset market
data, and order book snapshots used across execution, rebalance, and
liquidity-aware templates.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass
class VolumeProfile:
    """
    Intraday volume distribution across time intervals.

    Represents the expected fraction (or absolute volume) of daily volume
    traded in each interval. Commonly U-shaped for US equities.

    Args:
        intervals: Time labels for each bucket (e.g. ``["09:30", "09:35", ...]``).
        volumes: Volume per bucket — fractions summing to ~1 or absolute shares.
        symbol: Optional ticker symbol this profile belongs to.

    Example::

        profile = VolumeProfile(
            intervals=["09:30", "09:35", "09:40"],
            volumes=[0.08, 0.06, 0.05],
            symbol="AAPL",
        )
    """

    intervals: list[str]
    volumes: list[float]
    symbol: str | None = None

    def __post_init__(self) -> None:
        if len(self.intervals) != len(self.volumes):
            raise ValueError(
                f"intervals ({len(self.intervals)}) and volumes ({len(self.volumes)}) "
                "must have the same length"
            )

    @property
    def n_intervals(self) -> int:
        return len(self.intervals)

    def normalized(self) -> list[float]:
        """Return volumes normalized to sum to 1."""
        total = sum(self.volumes)
        if total == 0:
            return [1.0 / len(self.volumes)] * len(self.volumes)
        return [v / total for v in self.volumes]

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "intervals": self.intervals,
            "volumes": self.volumes,
        }
        if self.symbol is not None:
            d["symbol"] = self.symbol
        return d

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> VolumeProfile:
        return cls(
            intervals=d["intervals"],
            volumes=d["volumes"],
            symbol=d.get("symbol"),
        )

    @classmethod
    def uniform(
        cls, n_intervals: int, interval_minutes: int = 5, start: str = "09:30"
    ) -> VolumeProfile:
        """Create a uniform (flat) volume profile."""
        h, m = map(int, start.split(":"))
        intervals = []
        for i in range(n_intervals):
            total_min = h * 60 + m + i * interval_minutes
            intervals.append(f"{total_min // 60:02d}:{total_min % 60:02d}")
        volumes = [1.0 / n_intervals] * n_intervals
        return cls(intervals=intervals, volumes=volumes)


@dataclass
class MarketData:
    """
    Per-asset market data for trading optimizations.

    Collects average daily volume, spreads, prices, and optional intraday
    volume profiles in a single container passed to execution, rebalance,
    and liquidity-aware templates.

    Args:
        symbols: Asset ticker symbols.
        adv: Average daily volume (shares) per symbol.
        bid_ask_spread: Bid–ask spread in basis points per symbol.
        price: Current price per symbol.
        volume_profiles: Intraday volume profile per symbol.
        market_cap: Market capitalisation per symbol.

    Example::

        md = MarketData(
            symbols=["AAPL", "MSFT"],
            adv={"AAPL": 75_000_000, "MSFT": 25_000_000},
            price={"AAPL": 185.50, "MSFT": 420.00},
            bid_ask_spread={"AAPL": 1.0, "MSFT": 1.5},
        )
    """

    symbols: list[str]
    adv: dict[str, float]
    bid_ask_spread: dict[str, float] | None = None
    price: dict[str, float] | None = None
    volume_profiles: dict[str, VolumeProfile] | None = None
    market_cap: dict[str, float] | None = None

    def __post_init__(self) -> None:
        missing = set(self.symbols) - set(self.adv)
        if missing:
            raise ValueError(f"adv missing for symbols: {missing}")

    def get_adv(self, symbol: str) -> float:
        return self.adv[symbol]

    def get_spread(self, symbol: str, default: float = 1.0) -> float:
        if self.bid_ask_spread is None:
            return default
        return self.bid_ask_spread.get(symbol, default)

    def get_price(self, symbol: str, default: float = 100.0) -> float:
        if self.price is None:
            return default
        return self.price.get(symbol, default)

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "symbols": self.symbols,
            "adv": self.adv,
        }
        if self.bid_ask_spread is not None:
            d["bid_ask_spread"] = self.bid_ask_spread
        if self.price is not None:
            d["price"] = self.price
        if self.volume_profiles is not None:
            d["volume_profiles"] = {
                s: vp.to_dict() for s, vp in self.volume_profiles.items()
            }
        if self.market_cap is not None:
            d["market_cap"] = self.market_cap
        return d

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> MarketData:
        vp = None
        if "volume_profiles" in d and d["volume_profiles"] is not None:
            vp = {
                s: VolumeProfile.from_dict(v) for s, v in d["volume_profiles"].items()
            }
        return cls(
            symbols=d["symbols"],
            adv=d["adv"],
            bid_ask_spread=d.get("bid_ask_spread"),
            price=d.get("price"),
            volume_profiles=vp,
            market_cap=d.get("market_cap"),
        )
