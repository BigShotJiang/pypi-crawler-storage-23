"""
Market impact and transaction cost models for trading optimizations.

Provides pluggable cost models used by execution, rebalance, and
liquidity-aware templates to estimate the cost of trading a given quantity.

Models
------
- **LinearCostModel** — spread/2 + η × (quantity/ADV)
- **SquareRootCostModel** — spread/2 + η × σ × √(quantity/ADV)  (Almgren-Chriss simplified)
- **AlmgrenChrissCostModel** — temporary + permanent impact (full model)

Factory
-------
Use :func:`get_cost_model` to instantiate by name::

    model = get_cost_model("sqrt", eta=0.1, sigma=0.02)
    cost_bps = model.estimate(quantity=5000, adv=1_000_000, price=185.0, spread=1.0)
"""

from __future__ import annotations

import math
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any


class CostModel(ABC):
    """
    Base class for market impact / transaction cost models.

    All cost models implement :meth:`estimate`, which returns the **estimated
    cost in basis points** for executing *quantity* shares of a security.

    Subclasses may store model-specific calibration parameters.
    """

    @abstractmethod
    def estimate(
        self,
        quantity: float,
        adv: float,
        price: float = 100.0,
        spread: float = 1.0,
    ) -> float:
        """
        Estimate the one-way execution cost in **basis points**.

        Args:
            quantity: Number of shares to trade (absolute).
            adv: Average daily volume in shares.
            price: Current price per share (used by some models).
            spread: Bid–ask spread in basis points.

        Returns:
            Estimated cost in basis points (≥ 0).
        """
        ...

    def total_cost(
        self,
        quantity: float,
        adv: float,
        price: float = 100.0,
        spread: float = 1.0,
    ) -> float:
        """
        Estimated cost in **currency** (price × quantity × bps / 10 000).

        Convenience wrapper around :meth:`estimate`.
        """
        bps = self.estimate(quantity, adv, price, spread)
        return price * abs(quantity) * bps / 10_000

    def to_dict(self) -> dict[str, Any]:
        """Serialise the model to a plain dict (name + params)."""
        return {"name": self.name, **self._params()}

    @property
    @abstractmethod
    def name(self) -> str:
        """Short identifier used by :func:`get_cost_model`."""
        ...

    def _params(self) -> dict[str, Any]:
        """Return model-specific parameters for serialisation."""
        return {}

    def __repr__(self) -> str:
        params = ", ".join(f"{k}={v}" for k, v in self._params().items())
        return (
            f"{self.__class__.__name__}({params})"
            if params
            else f"{self.__class__.__name__}()"
        )


@dataclass
class LinearCostModel(CostModel):
    """
    Linear market impact model.

    .. math::

        \\text{cost}_{\\text{bps}} = \\frac{\\text{spread}}{2}
            + \\eta \\times \\frac{\\text{quantity}}{\\text{ADV}}

    Args:
        eta: Slope of the linear impact (basis points per unit participation).
             Default 10 means trading 10 % of ADV costs 1 bp of linear impact.

    Example::

        model = LinearCostModel(eta=10.0)
        bps = model.estimate(quantity=50_000, adv=10_000_000, spread=1.0)
    """

    eta: float = 10.0

    @property
    def name(self) -> str:
        return "linear"

    def estimate(
        self,
        quantity: float,
        adv: float,
        price: float = 100.0,
        spread: float = 1.0,
    ) -> float:
        if adv <= 0:
            raise ValueError("adv must be positive")
        participation = abs(quantity) / adv
        return spread / 2.0 + self.eta * participation

    def _params(self) -> dict[str, Any]:
        return {"eta": self.eta}


@dataclass
class SquareRootCostModel(CostModel):
    """
    Square-root market impact model (simplified Almgren-Chriss).

    .. math::

        \\text{cost}_{\\text{bps}} = \\frac{\\text{spread}}{2}
            + \\eta \\times \\sigma \\times \\sqrt{\\frac{\\text{quantity}}{\\text{ADV}}}

    where σ is the daily volatility (as a decimal, e.g. 0.02 = 2 %).

    This is the most commonly used model in practice and captures the
    concavity of empirical impact curves.

    Args:
        eta: Impact coefficient (dimensionless multiplier).
        sigma: Daily volatility (decimal). Defaults to 0.02 (2 %).

    Example::

        model = SquareRootCostModel(eta=0.5, sigma=0.02)
        bps = model.estimate(quantity=50_000, adv=10_000_000, spread=1.0)
    """

    eta: float = 0.5
    sigma: float = 0.02

    @property
    def name(self) -> str:
        return "sqrt"

    def estimate(
        self,
        quantity: float,
        adv: float,
        price: float = 100.0,
        spread: float = 1.0,
    ) -> float:
        if adv <= 0:
            raise ValueError("adv must be positive")
        participation = abs(quantity) / adv
        # Convert sigma to basis points (* 10_000) for the impact term
        impact = self.eta * self.sigma * math.sqrt(participation) * 10_000
        return spread / 2.0 + impact

    def _params(self) -> dict[str, Any]:
        return {"eta": self.eta, "sigma": self.sigma}


@dataclass
class AlmgrenChrissCostModel(CostModel):
    """
    Full Almgren-Chriss market impact model with temporary and permanent impact.

    .. math::

        \\text{temporary}_{\\text{bps}} = \\eta \\times \\sigma
            \\times \\left(\\frac{\\text{quantity}}{\\text{ADV} \\times T}\\right)^{0.6}

        \\text{permanent}_{\\text{bps}} = \\gamma \\times \\sigma
            \\times \\left(\\frac{\\text{quantity}}{\\text{ADV}}\\right)^{0.5}

        \\text{total}_{\\text{bps}} = \\frac{\\text{spread}}{2}
            + \\text{temporary} + \\text{permanent}

    The 0.6 exponent on temporary impact and 0.5 on permanent impact are
    standard in the literature. ``T`` is the horizon in trading days.

    Args:
        eta: Temporary impact coefficient.
        gamma: Permanent impact coefficient.
        sigma: Daily volatility (decimal).
        horizon_days: Number of trading days to complete the order.

    Example::

        model = AlmgrenChrissCostModel(eta=0.1, gamma=0.05, sigma=0.02)
        bps = model.estimate(quantity=100_000, adv=10_000_000, spread=1.0)
    """

    eta: float = 0.1
    gamma: float = 0.05
    sigma: float = 0.02
    horizon_days: float = 1.0

    @property
    def name(self) -> str:
        return "almgren_chriss"

    def estimate(
        self,
        quantity: float,
        adv: float,
        price: float = 100.0,
        spread: float = 1.0,
    ) -> float:
        if adv <= 0:
            raise ValueError("adv must be positive")
        if self.horizon_days <= 0:
            raise ValueError("horizon_days must be positive")

        q = abs(quantity)
        participation = q / adv

        # Temporary impact: faster trading rate → higher cost
        rate = q / (adv * self.horizon_days) if self.horizon_days > 0 else participation
        temporary = self.eta * self.sigma * (rate**0.6) * 10_000

        # Permanent impact: total order size → price level shift
        permanent = self.gamma * self.sigma * (participation**0.5) * 10_000

        return spread / 2.0 + temporary + permanent

    def _params(self) -> dict[str, Any]:
        return {
            "eta": self.eta,
            "gamma": self.gamma,
            "sigma": self.sigma,
            "horizon_days": self.horizon_days,
        }


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------

_COST_MODELS: dict[str, type] = {
    "linear": LinearCostModel,
    "sqrt": SquareRootCostModel,
    "square_root": SquareRootCostModel,
    "almgren_chriss": AlmgrenChrissCostModel,
    "ac": AlmgrenChrissCostModel,
}


def get_cost_model(name: str, **params: Any) -> CostModel:
    """
    Instantiate a cost model by name.

    Args:
        name: One of ``"linear"``, ``"sqrt"`` (or ``"square_root"``),
              ``"almgren_chriss"`` (or ``"ac"``).
        **params: Keyword arguments forwarded to the model constructor.

    Returns:
        A :class:`CostModel` instance.

    Raises:
        ValueError: If *name* is not recognised.

    Example::

        model = get_cost_model("sqrt", eta=0.5, sigma=0.02)
    """
    key = name.lower().strip()
    if key not in _COST_MODELS:
        available = sorted(set(_COST_MODELS.values()), key=lambda c: c.__name__)
        names = [c.__name__ for c in available]
        raise ValueError(
            f"Unknown cost model '{name}'. "
            f"Available: {', '.join(sorted(_COST_MODELS.keys()))} "
            f"(classes: {', '.join(names)})"
        )
    return _COST_MODELS[key](**params)
