"""
Rebalance Optimizer — sklearn-style API for portfolio rebalancing.

Example::

    from pyoptima.estimators.rebalance import RebalanceOptimizer

    opt = RebalanceOptimizer(strategy="min_cost", max_turnover=0.15)
    result = opt.solve(
        current_weights={"AAPL": 0.30, "MSFT": 0.20, "GOOGL": 0.50},
        target_weights={"AAPL": 0.25, "MSFT": 0.25, "GOOGL": 0.50},
        symbols=["AAPL", "MSFT", "GOOGL"],
        transaction_costs=0.001,
    )
    print(result.solution["trades"])
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from pyoptima.core.result import OptimizationResult, SolverStatus
from pyoptima.estimators.base import BaseOptimizer


class RebalanceOptimizer(BaseOptimizer):
    """
    sklearn-style optimizer for portfolio rebalancing.

    Args:
        strategy: ``"min_deviation"``, ``"min_cost"``, or ``"min_impact"``.
        max_turnover: Total one-way turnover cap.
        max_tracking_error: TE cap vs target.
        max_participation: Max fraction of ADV per trade.
        solver: Solver name.
        solver_options: Extra solver options.
    """

    def __init__(
        self,
        strategy: str = "min_deviation",
        max_turnover: float | None = None,
        max_tracking_error: float | None = None,
        max_participation: float | None = None,
        solver: str = "highs",
        solver_options: dict[str, Any] | None = None,
    ):
        self.strategy = strategy
        self.max_turnover = max_turnover
        self.max_tracking_error = max_tracking_error
        self.max_participation = max_participation
        self.solver = solver
        self.solver_options = solver_options or {}

    def _validate_data(self, data: dict[str, Any]) -> None:
        if "current_weights" not in data:
            raise ValueError("current_weights required")
        if "target_weights" not in data:
            raise ValueError("target_weights required")
        if "symbols" not in data:
            raise ValueError("symbols required")

    def _solve(self, **data: Any) -> OptimizationResult:
        from pyoptima.templates.rebalance import RebalanceTemplate

        config_dict = self._build_config_dict(data)
        template = RebalanceTemplate()

        try:
            result = template.solve(
                config_dict,
                solver=self.solver,
                options=self.solver_options,
            )
        except Exception as e:
            return OptimizationResult(
                status=SolverStatus.ERROR,
                solver_message=str(e),
            )
        return result

    def _build_config_dict(self, data: dict[str, Any]) -> dict[str, Any]:
        config: dict[str, Any] = {
            "strategy": self.strategy,
        }
        if self.max_turnover is not None:
            config["max_turnover"] = self.max_turnover
        if self.max_tracking_error is not None:
            config["max_tracking_error"] = self.max_tracking_error
        if self.max_participation is not None:
            config["max_participation"] = self.max_participation

        for key in (
            "current_weights",
            "target_weights",
            "symbols",
            "transaction_costs",
            "adv",
            "covariance_matrix",
            "lot_size",
            "prices",
            "portfolio_value",
        ):
            if key in data:
                config[key] = data[key]
        return config

    @classmethod
    def from_config(
        cls,
        config: dict[str, Any] | str | Path | Any,
    ) -> RebalanceOptimizer:
        """Build from a config file, dict, or Pydantic model."""
        if isinstance(config, (str, Path)):
            from pyoptima.configs import load

            config = load(config)

        if isinstance(config, dict):
            cfg = config
        elif hasattr(config, "model_dump"):
            cfg = config.model_dump()
        else:
            cfg = {}

        solver_cfg = cfg.get("solver", {})
        opt = cls(
            strategy=cfg.get("strategy", "min_deviation"),
            max_turnover=cfg.get("max_turnover"),
            max_tracking_error=cfg.get("max_tracking_error"),
            max_participation=cfg.get("max_participation"),
            solver=(
                solver_cfg.get("name", "highs")
                if isinstance(solver_cfg, dict)
                else "highs"
            ),
            solver_options=(
                solver_cfg.get("options", {}) if isinstance(solver_cfg, dict) else {}
            ),
        )
        data_cfg = cfg.get("data", cfg)
        opt._fit_data = {
            k: v
            for k, v in data_cfg.items()
            if k
            in (
                "current_weights",
                "target_weights",
                "symbols",
                "transaction_costs",
                "adv",
                "covariance_matrix",
                "lot_size",
                "prices",
                "portfolio_value",
            )
        }
        return opt

    @staticmethod
    def list_strategies() -> list[str]:
        """List all supported rebalance strategies."""
        return ["min_deviation", "min_cost", "min_impact"]
