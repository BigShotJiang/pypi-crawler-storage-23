"""
Risk Budget Optimizer — sklearn-style API for risk budget management.

Example::

    from pyoptima.estimators.risk_budget import RiskBudgetOptimizer

    opt = RiskBudgetOptimizer(strategy="reduce", max_volatility=0.15)
    result = opt.solve(
        current_weights={"AAPL": 0.40, "GOOGL": 0.35, "MSFT": 0.25},
        covariance_matrix=[[...], ...],
        symbols=["AAPL", "GOOGL", "MSFT"],
        max_concentration=0.35,
    )
    print(result.solution["all_limits_satisfied"])
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from pyoptima.core.result import OptimizationResult, SolverStatus
from pyoptima.estimators.base import BaseOptimizer


class RiskBudgetOptimizer(BaseOptimizer):
    """
    sklearn-style optimizer for risk budget management.

    Args:
        strategy: ``"check"``, ``"reduce"``, or ``"allocate"``.
        max_volatility: Portfolio volatility cap.
        max_concentration: Max single-asset weight.
        max_cvar: CVaR cap.
        confidence_level: CVaR confidence level.
        solver: Solver name.
        solver_options: Extra solver options.
    """

    def __init__(
        self,
        strategy: str = "reduce",
        max_volatility: float | None = None,
        max_concentration: float | None = None,
        max_cvar: float | None = None,
        confidence_level: float = 0.05,
        solver: str = "ipopt",
        solver_options: dict[str, Any] | None = None,
    ):
        self.strategy = strategy
        self.max_volatility = max_volatility
        self.max_concentration = max_concentration
        self.max_cvar = max_cvar
        self.confidence_level = confidence_level
        self.solver = solver
        self.solver_options = solver_options or {}

    def _validate_data(self, data: dict[str, Any]) -> None:
        if "current_weights" not in data:
            raise ValueError("current_weights required")
        if "symbols" not in data:
            raise ValueError("symbols required")

    def _solve(self, **data: Any) -> OptimizationResult:
        from pyoptima.templates.risk_budget import RiskBudgetTemplate

        config_dict = self._build_config_dict(data)
        template = RiskBudgetTemplate()

        try:
            result = template.solve(
                config_dict,
                solver=self.solver,
                options=self.solver_options,
            )
        except Exception as e:
            return OptimizationResult(
                status=SolverStatus.ERROR,
                solver_message=str(e),
            )
        return result

    def _build_config_dict(self, data: dict[str, Any]) -> dict[str, Any]:
        config: dict[str, Any] = {
            "strategy": self.strategy,
            "confidence_level": self.confidence_level,
        }
        if self.max_volatility is not None:
            config["max_volatility"] = self.max_volatility
        if self.max_concentration is not None:
            config["max_concentration"] = self.max_concentration
        if self.max_cvar is not None:
            config["max_cvar"] = self.max_cvar

        for key in (
            "current_weights",
            "symbols",
            "covariance_matrix",
            "max_sector_weight",
            "asset_sectors",
            "factor_loadings",
            "factor_names",
            "max_factor_exposure",
            "returns",
        ):
            if key in data:
                config[key] = data[key]
        return config

    @classmethod
    def from_config(
        cls,
        config: dict[str, Any] | str | Path | Any,
    ) -> RiskBudgetOptimizer:
        """Build from a config file, dict, or Pydantic model."""
        if isinstance(config, (str, Path)):
            from pyoptima.configs import load

            config = load(config)

        if isinstance(config, dict):
            cfg = config
        elif hasattr(config, "model_dump"):
            cfg = config.model_dump()
        else:
            cfg = {}

        solver_cfg = cfg.get("solver", {})
        opt = cls(
            strategy=cfg.get("strategy", "reduce"),
            max_volatility=cfg.get("max_volatility"),
            max_concentration=cfg.get("max_concentration"),
            max_cvar=cfg.get("max_cvar"),
            confidence_level=cfg.get("confidence_level", 0.05),
            solver=(
                solver_cfg.get("name", "ipopt")
                if isinstance(solver_cfg, dict)
                else "ipopt"
            ),
            solver_options=(
                solver_cfg.get("options", {}) if isinstance(solver_cfg, dict) else {}
            ),
        )
        data_cfg = cfg.get("data", cfg)
        opt._fit_data = {
            k: v
            for k, v in data_cfg.items()
            if k
            in (
                "current_weights",
                "symbols",
                "covariance_matrix",
                "max_sector_weight",
                "asset_sectors",
                "factor_loadings",
                "factor_names",
                "max_factor_exposure",
                "returns",
            )
        }
        return opt

    @staticmethod
    def list_strategies() -> list[str]:
        """List all supported risk budget strategies."""
        return ["check", "reduce", "allocate"]
