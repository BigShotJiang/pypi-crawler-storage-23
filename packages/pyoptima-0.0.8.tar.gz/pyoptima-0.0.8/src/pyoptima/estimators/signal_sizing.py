"""
Signal Sizing Optimizer — sklearn-style API for signal-to-position sizing.

Example::

    from pyoptima.estimators.signal_sizing import SignalSizingOptimizer

    opt = SignalSizingOptimizer(strategy="mean_risk", risk_aversion=2.0)
    result = opt.solve(
        signals={"AAPL": 0.02, "GOOGL": -0.01, "MSFT": 0.015},
        symbols=["AAPL", "GOOGL", "MSFT"],
        covariance_matrix=[[0.04, 0.01, 0.02], ...],
        max_gross_exposure=1.0,
        max_position=0.30,
    )
    print(result.solution["positions"])
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from pyoptima.core.result import OptimizationResult, SolverStatus
from pyoptima.estimators.base import BaseOptimizer


class SignalSizingOptimizer(BaseOptimizer):
    """
    sklearn-style optimizer for signal sizing.

    Args:
        strategy: ``"mean_risk"``, ``"equal_risk"``, ``"kelly"``, or ``"fixed_risk"``.
        risk_aversion: λ for mean_risk / kelly strategies.
        max_position: Maximum absolute weight per asset.
        max_gross_exposure: Σ |w_i| cap.
        max_net_exposure: |Σ w_i| cap.
        max_notional: Maximum total portfolio notional.
        target_volatility: Target portfolio vol for fixed_risk.
        solver: Solver name.
        solver_options: Extra solver options.
    """

    def __init__(
        self,
        strategy: str = "mean_risk",
        risk_aversion: float = 1.0,
        max_position: float | None = None,
        max_gross_exposure: float | None = None,
        max_net_exposure: float | None = None,
        max_notional: float | None = None,
        target_volatility: float | None = None,
        solver: str = "ipopt",
        solver_options: dict[str, Any] | None = None,
    ):
        self.strategy = strategy
        self.risk_aversion = risk_aversion
        self.max_position = max_position
        self.max_gross_exposure = max_gross_exposure
        self.max_net_exposure = max_net_exposure
        self.max_notional = max_notional
        self.target_volatility = target_volatility
        self.solver = solver
        self.solver_options = solver_options or {}

    def _validate_data(self, data: dict[str, Any]) -> None:
        if "signals" not in data:
            raise ValueError("signals required (dict of symbol → alpha)")
        if "symbols" not in data:
            raise ValueError("symbols required (ordered list of asset symbols)")

    def _solve(self, **data: Any) -> OptimizationResult:
        from pyoptima.templates.signal_sizing import SignalSizingTemplate

        config_dict = self._build_config_dict(data)
        template = SignalSizingTemplate()

        try:
            result = template.solve(
                config_dict,
                solver=self.solver,
                options=self.solver_options,
            )
        except Exception as e:
            return OptimizationResult(
                status=SolverStatus.ERROR,
                solver_message=str(e),
            )
        return result

    def _build_config_dict(self, data: dict[str, Any]) -> dict[str, Any]:
        config: dict[str, Any] = {
            "strategy": self.strategy,
            "risk_aversion": self.risk_aversion,
        }
        if self.max_position is not None:
            config["max_position"] = self.max_position
        if self.max_gross_exposure is not None:
            config["max_gross_exposure"] = self.max_gross_exposure
        if self.max_net_exposure is not None:
            config["max_net_exposure"] = self.max_net_exposure
        if self.max_notional is not None:
            config["max_notional"] = self.max_notional
        if self.target_volatility is not None:
            config["target_volatility"] = self.target_volatility

        for key in ("signals", "symbols", "covariance_matrix", "prices"):
            if key in data:
                config[key] = data[key]
        return config

    @classmethod
    def from_config(
        cls,
        config: dict[str, Any] | str | Path | Any,
    ) -> SignalSizingOptimizer:
        """Build from a config file, dict, or Pydantic model."""
        if isinstance(config, (str, Path)):
            from pyoptima.configs import load

            config = load(config)

        if isinstance(config, dict):
            cfg = config
        elif hasattr(config, "model_dump"):
            cfg = config.model_dump()
        else:
            cfg = {}

        solver_cfg = cfg.get("solver", {})
        opt = cls(
            strategy=cfg.get("strategy", "mean_risk"),
            risk_aversion=cfg.get("risk_aversion", 1.0),
            max_position=cfg.get("max_position"),
            max_gross_exposure=cfg.get("max_gross_exposure"),
            max_net_exposure=cfg.get("max_net_exposure"),
            max_notional=cfg.get("max_notional"),
            target_volatility=cfg.get("target_volatility"),
            solver=(
                solver_cfg.get("name", "ipopt")
                if isinstance(solver_cfg, dict)
                else "ipopt"
            ),
            solver_options=(
                solver_cfg.get("options", {}) if isinstance(solver_cfg, dict) else {}
            ),
        )
        data_cfg = cfg.get("data", cfg)
        opt._fit_data = {
            k: v
            for k, v in data_cfg.items()
            if k in ("signals", "symbols", "covariance_matrix", "prices")
        }
        return opt

    @staticmethod
    def list_strategies() -> list[str]:
        """List all supported sizing strategies."""
        return ["mean_risk", "equal_risk", "kelly", "fixed_risk"]
