"""
Execution Optimizer — sklearn-style API for order execution.

Provides a clean interface for splitting parent orders into child slices
using TWAP, VWAP, Implementation Shortfall, or POV strategies.

Example::

    from pyoptima.estimators.execution import ExecutionOptimizer

    opt = ExecutionOptimizer(strategy="vwap", horizon_minutes=120)
    result = opt.solve(
        symbol="AAPL",
        total_quantity=50_000,
        side="buy",
        adv=75_000_000,
        volume_profile=[0.08, 0.06, 0.05, ...],
    )
    print(result.solution["schedule"])
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from pyoptima.core.result import OptimizationResult, SolverStatus
from pyoptima.estimators.base import BaseOptimizer


class ExecutionOptimizer(BaseOptimizer):
    """
    sklearn-style optimizer for order execution.

    Wraps :class:`~pyoptima.templates.execution.ExecutionTemplate` with a
    convenient parameter interface.

    Args:
        strategy: Execution algorithm — ``"twap"``, ``"vwap"``,
            ``"implementation_shortfall"``, or ``"pov"``.
        horizon_minutes: Total time horizon.
        interval_minutes: Length of each time bucket.
        risk_aversion: Almgren-Chriss λ (IS only).
        temporary_impact: η coefficient (IS only).
        permanent_impact: γ coefficient (IS only).
        target_participation: Target POV rate (POV only).
        max_participation: Hard participation cap per interval.
        solver: Solver name.
        solver_options: Extra solver keyword arguments.

    Example::

        opt = ExecutionOptimizer(strategy="is", horizon_minutes=60)
        result = opt.solve(
            symbol="AAPL",
            total_quantity=100_000,
            side="buy",
            adv=75_000_000,
            volatility=0.02,
        )
    """

    def __init__(
        self,
        strategy: str = "vwap",
        horizon_minutes: int = 60,
        interval_minutes: int = 5,
        risk_aversion: float = 1e-6,
        temporary_impact: float = 0.1,
        permanent_impact: float = 0.01,
        target_participation: float = 0.10,
        max_participation: float = 0.25,
        solver: str = "highs",
        solver_options: dict[str, Any] | None = None,
    ):
        self.strategy = strategy
        self.horizon_minutes = horizon_minutes
        self.interval_minutes = interval_minutes
        self.risk_aversion = risk_aversion
        self.temporary_impact = temporary_impact
        self.permanent_impact = permanent_impact
        self.target_participation = target_participation
        self.max_participation = max_participation
        self.solver = solver
        self.solver_options = solver_options or {}

    def _validate_data(self, data: dict[str, Any]) -> None:
        if "total_quantity" not in data:
            raise ValueError("total_quantity required")
        if "side" not in data:
            raise ValueError("side required ('buy' or 'sell')")
        if data.get("side") not in ("buy", "sell"):
            raise ValueError(f"side must be 'buy' or 'sell', got '{data.get('side')}'")
        if float(data["total_quantity"]) <= 0:
            raise ValueError("total_quantity must be positive")

    def _solve(self, **data: Any) -> OptimizationResult:
        from pyoptima.templates.execution import ExecutionTemplate

        config_dict = self._build_config_dict(data)
        template = ExecutionTemplate()

        try:
            result = template.solve(
                config_dict,
                solver=self.solver,
                options=self.solver_options,
            )
        except Exception as e:
            return OptimizationResult(
                status=SolverStatus.ERROR,
                solver_message=str(e),
            )
        return result

    def _build_config_dict(self, data: dict[str, Any]) -> dict[str, Any]:
        """Merge optimizer params with call-time data."""
        config: dict[str, Any] = {
            "strategy": self.strategy,
            "horizon_minutes": self.horizon_minutes,
            "interval_minutes": self.interval_minutes,
            "risk_aversion": self.risk_aversion,
            "temporary_impact": self.temporary_impact,
            "permanent_impact": self.permanent_impact,
            "target_participation": self.target_participation,
            "max_participation": self.max_participation,
        }
        # Data fields override / supplement
        for key in (
            "symbol",
            "total_quantity",
            "side",
            "adv",
            "price",
            "volatility",
            "bid_ask_spread",
            "volume_profile",
        ):
            if key in data:
                config[key] = data[key]
        return config

    @classmethod
    def from_config(
        cls,
        config: dict[str, Any] | str | Path | Any,
    ) -> ExecutionOptimizer:
        """
        Build from a config file, dict, or Pydantic model.

        Example::

            opt = ExecutionOptimizer.from_config("execution_vwap.yaml")
            result = opt.solve()
        """
        if isinstance(config, (str, Path)):
            from pyoptima.configs import load

            config = load(config)

        if isinstance(config, dict):
            cfg = config
        elif hasattr(config, "model_dump"):
            cfg = config.model_dump()
        else:
            cfg = {}

        solver_cfg = cfg.get("solver", {})
        opt = cls(
            strategy=cfg.get("strategy", "vwap"),
            horizon_minutes=cfg.get("horizon_minutes", 60),
            interval_minutes=cfg.get("interval_minutes", 5),
            risk_aversion=cfg.get("risk_aversion", 1e-6),
            temporary_impact=cfg.get("temporary_impact", 0.1),
            permanent_impact=cfg.get("permanent_impact", 0.01),
            target_participation=cfg.get("target_participation", 0.10),
            max_participation=cfg.get("max_participation", 0.25),
            solver=(
                solver_cfg.get("name", "highs")
                if isinstance(solver_cfg, dict)
                else "highs"
            ),
            solver_options=(
                solver_cfg.get("options", {}) if isinstance(solver_cfg, dict) else {}
            ),
        )
        # Store config data for solve-with-no-args
        data_cfg = cfg.get("data", cfg)
        opt._fit_data = {
            k: v
            for k, v in data_cfg.items()
            if k
            in (
                "symbol",
                "total_quantity",
                "side",
                "adv",
                "price",
                "volatility",
                "bid_ask_spread",
                "volume_profile",
            )
        }
        return opt

    @staticmethod
    def list_strategies() -> list[str]:
        """List all supported execution strategies."""
        return ["twap", "vwap", "implementation_shortfall", "pov"]
