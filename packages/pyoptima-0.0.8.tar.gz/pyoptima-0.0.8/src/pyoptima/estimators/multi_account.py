"""
Multi-Account Optimizer — sklearn-style API for multi-account allocation.

Example::

    from pyoptima.estimators.multi_account import MultiAccountOptimizer

    opt = MultiAccountOptimizer(objective="min_volatility")
    result = opt.solve(
        accounts=[
            {"name": "aggressive", "max_weight": 0.40},
            {"name": "conservative", "max_weight": 0.15, "max_volatility": 0.10},
        ],
        expected_returns=[0.10, 0.12, 0.08],
        covariance_matrix=[[...], ...],
        symbols=["AAPL", "MSFT", "GOOGL"],
    )
    for name, acct in result.solution["accounts"].items():
        print(f"{name}: {acct['weights']}")
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from pyoptima.core.result import OptimizationResult, SolverStatus
from pyoptima.estimators.base import BaseOptimizer


class MultiAccountOptimizer(BaseOptimizer):
    """
    sklearn-style optimizer for multi-account/mandate allocation.

    Args:
        strategy: ``"independent"``, ``"joint"``, or ``"cascade"``.
        objective: Portfolio objective per account.
        solver: Solver name.
        solver_options: Extra solver options.
    """

    def __init__(
        self,
        strategy: str = "joint",
        objective: str = "min_volatility",
        solver: str = "ipopt",
        solver_options: dict[str, Any] | None = None,
    ):
        self.strategy = strategy
        self.objective = objective
        self.solver = solver
        self.solver_options = solver_options or {}

    def _validate_data(self, data: dict[str, Any]) -> None:
        if "accounts" not in data:
            raise ValueError("accounts required")
        if "symbols" not in data:
            raise ValueError("symbols required")

    def _solve(self, **data: Any) -> OptimizationResult:
        from pyoptima.templates.multi_account import MultiAccountTemplate

        config_dict = self._build_config_dict(data)
        template = MultiAccountTemplate()

        try:
            result = template.solve(
                config_dict,
                solver=self.solver,
                options=self.solver_options,
            )
        except Exception as e:
            return OptimizationResult(
                status=SolverStatus.ERROR,
                solver_message=str(e),
            )
        return result

    def _build_config_dict(self, data: dict[str, Any]) -> dict[str, Any]:
        config: dict[str, Any] = {
            "strategy": self.strategy,
            "objective": self.objective,
        }
        for key in (
            "accounts",
            "symbols",
            "expected_returns",
            "covariance_matrix",
            "account_values",
            "current_weights",
        ):
            if key in data:
                config[key] = data[key]
        return config

    @classmethod
    def from_config(
        cls,
        config: dict[str, Any] | str | Path | Any,
    ) -> MultiAccountOptimizer:
        """Build from a config file, dict, or Pydantic model."""
        if isinstance(config, (str, Path)):
            from pyoptima.configs import load

            config = load(config)

        if isinstance(config, dict):
            cfg = config
        elif hasattr(config, "model_dump"):
            cfg = config.model_dump()
        else:
            cfg = {}

        solver_cfg = cfg.get("solver", {})
        opt = cls(
            strategy=cfg.get("strategy", "joint"),
            objective=cfg.get("objective", "min_volatility"),
            solver=(
                solver_cfg.get("name", "ipopt")
                if isinstance(solver_cfg, dict)
                else "ipopt"
            ),
            solver_options=(
                solver_cfg.get("options", {}) if isinstance(solver_cfg, dict) else {}
            ),
        )
        data_cfg = cfg.get("data", cfg)
        opt._fit_data = {
            k: v
            for k, v in data_cfg.items()
            if k
            in (
                "accounts",
                "symbols",
                "expected_returns",
                "covariance_matrix",
                "account_values",
                "current_weights",
            )
        }
        return opt

    @staticmethod
    def list_strategies() -> list[str]:
        """List all supported multi-account strategies."""
        return ["independent", "joint", "cascade"]
