"""
Application configuration for PyOptima API (auth, etc.).

Reads from environment variables and pyoptima.cfg. Keeps optimization
config (config.py) separate.
"""

from __future__ import annotations

import os
from configparser import ConfigParser
from pathlib import Path


def _find_config_file(filename: str) -> Path | None:
    """
    Find config file in common locations.

    Search order:
    1. Current working directory
    2. User home directory (~/.pyoptima/)
    3. Walk up to 5 parent directories from cwd
    """
    # 1. Current working directory
    cwd_path = Path.cwd() / filename
    if cwd_path.exists():
        return cwd_path

    # 2. User home directory
    home_path = Path.home() / ".pyoptima" / filename
    if home_path.exists():
        return home_path

    # 3. Walk up parent directories
    current = Path.cwd()
    for _ in range(5):
        candidate = current / filename
        if candidate.exists():
            return candidate
        current = current.parent

    return None


def _get_config_variable(var_name: str, section: str) -> str | None:
    """Read a single variable from pyoptima.cfg [section]."""
    config_file = _find_config_file("pyoptima.cfg")
    if not config_file:
        return None
    try:
        cfg = ConfigParser()
        cfg.read(config_file)
        if cfg.has_section(section):
            return cfg.get(section, var_name, fallback=None)
    except Exception:
        pass
    return None


# ---------------------------------------------------------------------------
# Auth configuration (env overrides cfg)
# ---------------------------------------------------------------------------


def get_auth_initial_credentials() -> tuple[str, str] | None:
    """
    Get initial login credentials for dev/setup (env or pyoptima.cfg [auth]).
    Returns (username, password) or None if not configured.
    """
    username = os.getenv("PYOPTIMA_AUTH_INITIAL_USERNAME")
    password = os.getenv("PYOPTIMA_AUTH_INITIAL_PASSWORD")
    if username and password:
        return (username, password)
    config_file = _find_config_file("pyoptima.cfg")
    if config_file:
        try:
            cfg = ConfigParser()
            cfg.read(config_file)
            if cfg.has_section("auth"):
                u = cfg.get("auth", "initial_username", fallback=None)
                p = cfg.get("auth", "initial_password", fallback=None)
                if u and p:
                    return (u.strip(), p.strip())
        except Exception:
            pass
    return None


def get_auth_jwt_secret() -> str | None:
    """JWT signing/verification secret (env or pyoptima.cfg [auth])."""
    secret = os.getenv("PYOPTIMA_AUTH_JWT_SECRET")
    if secret:
        return secret
    return _get_config_variable("jwt_secret", "auth")


def get_auth_service_url() -> str | None:
    """Auth microservice base URL (env or pyoptima.cfg [auth])."""
    url = os.getenv("PYOPTIMA_AUTH_SERVICE_URL")
    if url:
        return url.rstrip("/")
    v = _get_config_variable("auth_service_url", "auth")
    return v.strip() if v else None


def get_auth_service_introspect_path() -> str | None:
    """Auth service introspect path, e.g. /oauth/introspect (env or cfg)."""
    path = os.getenv("PYOPTIMA_AUTH_SERVICE_INTROSPECT_PATH")
    if path:
        return path
    return _get_config_variable("auth_service_introspect_path", "auth")


def _is_auth_configured() -> bool:
    """True if there is a way to log in or verify tokens (initial creds + JWT secret, or auth service)."""
    if get_auth_service_url():
        return True
    if get_auth_initial_credentials() and get_auth_jwt_secret():
        return True
    return False


def is_auth_disabled() -> bool:
    """True when auth is explicitly disabled or not configured.

    When disabled, /auth/me returns 200 with an anonymous user so the UI does not block.
    """
    if os.getenv("PYOPTIMA_AUTH_DISABLED", "").strip().lower() in ("1", "true", "yes"):
        return True
    return not _is_auth_configured()
