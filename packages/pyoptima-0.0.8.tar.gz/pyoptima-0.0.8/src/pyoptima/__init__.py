# ruff: noqa: E402
"""
PyOptima — Config-driven optimization with sklearn-style Python API.

Two tiers of usage:

**Tier 1: Config-driven** (primary interface)::

    import pyoptima

    result = pyoptima.run("portfolio_config.yaml")
    config = pyoptima.load("portfolio_config.yaml")
    json_schema = pyoptima.schema("portfolio")

**Tier 2: Python API** (wraps config)::

    from pyoptima import PortfolioOptimizer

    opt = PortfolioOptimizer(
        objective="min_volatility",
        constraints=[WeightBounds(0, 0.4), SumToOne()],
    )
    result = opt.solve(
        expected_returns=[0.1, 0.12, 0.08],
        covariance_matrix=cov,
        symbols=["AAPL", "GOOGL", "MSFT"],
    )

Module-based imports for detailed access::

    from pyoptima.constraints import WeightBounds, SumToOne, MaxVolatility
    from pyoptima.objectives import MinVolatility, get_objective
    from pyoptima.configs import PortfolioConfig, ExecutionConfig
    from pyoptima.model import AbstractModel, Expression
    from pyoptima.solvers import get_solver, list_available_solvers
    from pyoptima.core import OptimizationResult, PortfolioResult, SolverStatus
"""

try:
    from importlib.metadata import version

    __version__ = version("pyoptima")
except Exception:
    __version__ = "0.0.0.dev0"

# ── Backward-compat aliases (old config.py API) ──────────────────────────
# These are used by cli.py and estimators/portfolio.py. They delegate to
# the new configs module. Keep them available but not in __all__.
from pyoptima.config import OptimizationConfig as _OldOptimizationConfig
from pyoptima.config import load_config as _load_config
from pyoptima.config import load_config_file as _load_config_file
from pyoptima.config import run_from_config as _run_from_config

# ── Config utilities ─────────────────────────────────────────────────────
from pyoptima.config_utils import diff as diff_config
from pyoptima.config_utils import generate as generate_config
from pyoptima.config_utils import validate as validate_config

# ── Primary config-driven API ─────────────────────────────────────────────
from pyoptima.configs import list_config_templates, load, run, schema

# ── Results ───────────────────────────────────────────────────────────────
from pyoptima.core.result import OptimizationResult, PortfolioResult, SolverStatus

# ── Diagnostics ──────────────────────────────────────────────────────────
from pyoptima.diagnostics import diagnose, find_iis

# ── Estimators (sklearn-style) ────────────────────────────────────────────
from pyoptima.estimators import (
    ExecutionOptimizer,
    MultiAccountOptimizer,
    PortfolioOptimizer,
    RebalanceOptimizer,
    RiskBudgetOptimizer,
    SignalSizingOptimizer,
)

# ── Exceptions ────────────────────────────────────────────────────────────
from pyoptima.exceptions import OptimizationError, SolverError, ValidationError

# ── Solver discovery ──────────────────────────────────────────────────────
from pyoptima.solvers import list_available_solvers

# ── Template discovery ────────────────────────────────────────────────────
from pyoptima.templates import get_template, list_templates, solve

# Re-export under the old names so existing imports don't break.
OptimizationConfig = _OldOptimizationConfig
load_config = _load_config
load_config_file = _load_config_file
run_from_config = _run_from_config


__all__ = [
    # Config-driven API
    "run",
    "load",
    "schema",
    "list_config_templates",
    # Templates & solvers
    "solve",
    "list_templates",
    "get_template",
    "list_available_solvers",
    # Estimators
    "PortfolioOptimizer",
    "ExecutionOptimizer",
    "RebalanceOptimizer",
    "SignalSizingOptimizer",
    "RiskBudgetOptimizer",
    "MultiAccountOptimizer",
    # Results
    "OptimizationResult",
    "PortfolioResult",
    "SolverStatus",
    # Diagnostics
    "diagnose",
    "find_iis",
    # Config utilities
    "validate_config",
    "generate_config",
    "diff_config",
    # Exceptions
    "OptimizationError",
    "SolverError",
    "ValidationError",
]
