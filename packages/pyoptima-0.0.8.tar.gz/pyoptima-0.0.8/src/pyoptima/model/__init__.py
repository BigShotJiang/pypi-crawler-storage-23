"""
Solver-agnostic model representation.

This module provides a universal model representation that can be translated
to various solver backends (Pyomo, OR-Tools, CVXPY, etc.).
"""

from pyoptima.core.result import OptimizationResult, SolverStatus
from pyoptima.model.core import (
    AbstractModel,
    Constraint,
    ConstraintSense,
    Expression,
    Objective,
    OptimizationSense,
    Term,
    Variable,
    VariableType,
)
from pyoptima.model.sets import IndexedSet, IndexSet

__all__ = [
    "Variable",
    "VariableType",
    "Expression",
    "Term",
    "Constraint",
    "ConstraintSense",
    "Objective",
    "OptimizationSense",
    "AbstractModel",
    "OptimizationResult",
    "SolverStatus",
    "IndexSet",
    "IndexedSet",
]
