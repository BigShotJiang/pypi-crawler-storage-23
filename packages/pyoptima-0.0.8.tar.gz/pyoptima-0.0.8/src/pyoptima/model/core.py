"""
Core model classes for solver-agnostic optimization model representation.

These classes represent optimization problems in a way that can be translated
to various solver backends.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pyoptima.core.result import OptimizationResult


class VariableType(Enum):
    """Variable type enumeration."""

    CONTINUOUS = "continuous"
    BINARY = "binary"
    INTEGER = "integer"


class ConstraintSense(Enum):
    """Constraint sense enumeration."""

    LEQ = "<="  # Less than or equal
    GEQ = ">="  # Greater than or equal
    EQ = "=="  # Equal


class OptimizationSense(Enum):
    """Optimization direction."""

    MINIMIZE = "minimize"
    MAXIMIZE = "maximize"


@dataclass
class Variable:
    """
    Optimization variable representation.

    Attributes:
        name: Variable name/identifier
        var_type: Variable type (continuous, binary, integer)
        lower_bound: Lower bound (None for unbounded)
        upper_bound: Upper bound (None for unbounded)
        indices: For indexed variables, the index tuple
        value: Solution value (set after solving)
    """

    name: str
    var_type: VariableType = VariableType.CONTINUOUS
    lower_bound: float | None = None
    upper_bound: float | None = None
    indices: tuple | None = None
    value: float | None = None

    def __hash__(self):
        return hash((self.name, self.indices))

    def __eq__(self, other):
        if not isinstance(other, Variable):
            return False
        return self.name == other.name and self.indices == other.indices

    @property
    def full_name(self) -> str:
        """Return full name including indices."""
        if self.indices:
            idx_str = ",".join(str(i) for i in self.indices)
            return f"{self.name}[{idx_str}]"
        return self.name


@dataclass
class Term:
    """
    A term in a linear/quadratic expression.

    Represents: coefficient * variable (linear)
            or: coefficient * var1 * var2 (quadratic)
    """

    coefficient: float
    variable: Variable | str
    variable2: Variable | str | None = None  # For quadratic terms

    @property
    def is_quadratic(self) -> bool:
        return self.variable2 is not None


@dataclass
class Expression:
    """
    Mathematical expression (linear or quadratic).

    Represents: constant + sum(terms)
    """

    terms: list[Term] = field(default_factory=list)
    constant: float = 0.0

    def add_term(
        self,
        coefficient: float,
        variable: Variable | str,
        variable2: Variable | str | None = None,
    ) -> Expression:
        """Add a term to the expression."""
        self.terms.append(Term(coefficient, variable, variable2))
        return self

    def add_constant(self, value: float) -> Expression:
        """Add a constant to the expression."""
        self.constant += value
        return self

    @property
    def is_linear(self) -> bool:
        """Check if expression is linear."""
        return all(not t.is_quadratic for t in self.terms)

    @property
    def is_quadratic(self) -> bool:
        """Check if expression has quadratic terms."""
        return any(t.is_quadratic for t in self.terms)

    @classmethod
    def from_dict(
        cls, var_coeffs: dict[str, float], constant: float = 0.0
    ) -> Expression:
        """Create linear expression from variable-coefficient dictionary."""
        expr = cls(constant=constant)
        for var_name, coef in var_coeffs.items():
            expr.add_term(coef, var_name)
        return expr


@dataclass
class Constraint:
    """
    Optimization constraint representation.

    Represents: lhs sense rhs
    e.g., sum(x[i]) <= 100
    """

    name: str
    lhs: Expression
    sense: ConstraintSense
    rhs: float
    indices: tuple | None = None  # For indexed constraints

    @property
    def full_name(self) -> str:
        """Return full name including indices."""
        if self.indices:
            idx_str = ",".join(str(i) for i in self.indices)
            return f"{self.name}[{idx_str}]"
        return self.name

    @classmethod
    def leq(
        cls, name: str, lhs: Expression, rhs: float, indices: tuple | None = None
    ) -> Constraint:
        """Create a <= constraint."""
        return cls(name, lhs, ConstraintSense.LEQ, rhs, indices)

    @classmethod
    def geq(
        cls, name: str, lhs: Expression, rhs: float, indices: tuple | None = None
    ) -> Constraint:
        """Create a >= constraint."""
        return cls(name, lhs, ConstraintSense.GEQ, rhs, indices)

    @classmethod
    def eq(
        cls, name: str, lhs: Expression, rhs: float, indices: tuple | None = None
    ) -> Constraint:
        """Create an == constraint."""
        return cls(name, lhs, ConstraintSense.EQ, rhs, indices)


@dataclass
class Objective:
    """
    Objective function representation.
    """

    expression: Expression
    sense: OptimizationSense

    @classmethod
    def minimize(cls, expression: Expression) -> Objective:
        """Create minimization objective."""
        return cls(expression, OptimizationSense.MINIMIZE)

    @classmethod
    def maximize(cls, expression: Expression) -> Objective:
        """Create maximization objective."""
        return cls(expression, OptimizationSense.MAXIMIZE)


class AbstractModel:
    """
    Solver-agnostic optimization model.

    This class represents an optimization problem that can be translated
    to various solver backends (Pyomo, OR-Tools, CVXPY).
    """

    def __init__(self, name: str = "model"):
        """
        Initialize abstract model.

        Args:
            name: Model name/identifier
        """
        self.name = name
        self._variables: dict[str, Variable] = {}
        self._constraints: dict[str, Constraint] = {}
        self._objective: Objective | None = None
        self._sets: dict[str, list] = {}
        self._parameters: dict[str, Any] = {}

    # Variable management
    def add_variable(
        self,
        name: str,
        var_type: VariableType = VariableType.CONTINUOUS,
        lower_bound: float | None = None,
        upper_bound: float | None = None,
        indices: tuple | None = None,
    ) -> Variable:
        """Add a variable to the model."""
        var = Variable(name, var_type, lower_bound, upper_bound, indices)
        key = var.full_name
        self._variables[key] = var
        return var

    def add_continuous(
        self,
        name: str,
        lb: float | None = None,
        ub: float | None = None,
        indices: tuple | None = None,
    ) -> Variable:
        """Add a continuous variable."""
        return self.add_variable(name, VariableType.CONTINUOUS, lb, ub, indices)

    def add_binary(self, name: str, indices: tuple | None = None) -> Variable:
        """Add a binary variable."""
        return self.add_variable(name, VariableType.BINARY, 0, 1, indices)

    def add_integer(
        self,
        name: str,
        lb: float | None = None,
        ub: float | None = None,
        indices: tuple | None = None,
    ) -> Variable:
        """Add an integer variable."""
        return self.add_variable(name, VariableType.INTEGER, lb, ub, indices)

    def get_variable(self, name: str) -> Variable | None:
        """Get variable by name."""
        return self._variables.get(name)

    @property
    def variables(self) -> dict[str, Variable]:
        """Get all variables."""
        return self._variables

    # Constraint management
    def add_constraint(self, constraint: Constraint) -> Constraint:
        """Add a constraint to the model."""
        self._constraints[constraint.full_name] = constraint
        return constraint

    def add_leq_constraint(
        self, name: str, lhs: Expression, rhs: float, indices: tuple | None = None
    ) -> Constraint:
        """Add a <= constraint."""
        return self.add_constraint(Constraint.leq(name, lhs, rhs, indices))

    def add_geq_constraint(
        self, name: str, lhs: Expression, rhs: float, indices: tuple | None = None
    ) -> Constraint:
        """Add a >= constraint."""
        return self.add_constraint(Constraint.geq(name, lhs, rhs, indices))

    def add_eq_constraint(
        self, name: str, lhs: Expression, rhs: float, indices: tuple | None = None
    ) -> Constraint:
        """Add an == constraint."""
        return self.add_constraint(Constraint.eq(name, lhs, rhs, indices))

    @property
    def constraints(self) -> dict[str, Constraint]:
        """Get all constraints."""
        return self._constraints

    # Objective management
    def set_objective(
        self, expression: Expression, sense: OptimizationSense
    ) -> Objective:
        """Set the objective function."""
        self._objective = Objective(expression, sense)
        return self._objective

    def minimize(self, expression: Expression) -> Objective:
        """Set minimization objective."""
        return self.set_objective(expression, OptimizationSense.MINIMIZE)

    def maximize(self, expression: Expression) -> Objective:
        """Set maximization objective."""
        return self.set_objective(expression, OptimizationSense.MAXIMIZE)

    @property
    def objective(self) -> Objective | None:
        """Get objective function."""
        return self._objective

    # Set and parameter management
    def add_set(self, name: str, elements: list) -> None:
        """Add an index set."""
        self._sets[name] = list(elements)

    def get_set(self, name: str) -> list | None:
        """Get set by name."""
        return self._sets.get(name)

    def add_parameter(self, name: str, value: Any) -> None:
        """Add a parameter."""
        self._parameters[name] = value

    def get_parameter(self, name: str) -> Any:
        """Get parameter by name."""
        return self._parameters.get(name)

    @property
    def sets(self) -> dict[str, list]:
        """Get all sets."""
        return self._sets

    @property
    def parameters(self) -> dict[str, Any]:
        """Get all parameters."""
        return self._parameters

    # Model properties
    @property
    def num_variables(self) -> int:
        """Get number of variables."""
        return len(self._variables)

    @property
    def num_constraints(self) -> int:
        """Get number of constraints."""
        return len(self._constraints)

    @property
    def is_linear(self) -> bool:
        """Check if model is linear."""
        if self._objective is None:
            return True
        if not self._objective.expression.is_linear:
            return False
        return all(c.lhs.is_linear for c in self._constraints.values())

    @property
    def has_integer_variables(self) -> bool:
        """Check if model has integer/binary variables."""
        return any(
            v.var_type in (VariableType.BINARY, VariableType.INTEGER)
            for v in self._variables.values()
        )

    @property
    def problem_type(self) -> str:
        """Determine problem type (LP, MILP, QP, MIQP)."""
        is_linear = self.is_linear
        has_integers = self.has_integer_variables

        if is_linear and not has_integers:
            return "LP"
        elif is_linear and has_integers:
            return "MILP"
        elif not is_linear and not has_integers:
            return "QP"
        else:
            return "MIQP"

    # ------------------------------------------------------------------
    # Warm start
    # ------------------------------------------------------------------

    def set_initial(self, values: dict[str, float]) -> None:
        """Set initial values for warm starting.

        Args:
            values: Mapping of variable name → initial value.

        Example::

            model.set_initial({"w_0": 0.3, "w_1": 0.4, "w_2": 0.3})
        """
        for var_name, val in values.items():
            var = self.get_variable(var_name)
            if var is not None:
                var.value = val

    def set_initial_from_result(self, result: OptimizationResult) -> None:
        """Set initial values from a previous :class:`OptimizationResult`.

        Args:
            result: A solved result whose ``solution`` dict provides values.
        """
        if hasattr(result, "solution") and result.solution:
            self.set_initial(result.solution)

    # ------------------------------------------------------------------
    # Model export
    # ------------------------------------------------------------------

    def to_lp(self, path: str | None = None) -> str:
        """Export the model in LP format (linear/quadratic).

        Args:
            path: If provided, write to this file path.

        Returns:
            LP-format string.
        """
        lines: list[str] = []
        lines.append(f"\\ Problem: {self.name}")
        lines.append(f"\\ Variables: {self.num_variables}")
        lines.append(f"\\ Constraints: {self.num_constraints}")
        lines.append(f"\\ Type: {self.problem_type}")
        lines.append("")

        # Objective
        if self._objective is not None:
            sense = (
                "Minimize"
                if self._objective.sense == OptimizationSense.MINIMIZE
                else "Maximize"
            )
            lines.append(f"{sense}")
            lines.append(f" obj: {self._expr_to_lp(self._objective.expression)}")
        lines.append("")

        # Constraints
        if self._constraints:
            lines.append("Subject To")
            for cname, con in self._constraints.items():
                sense_str = {"<=": "<=", ">=": ">=", "==": "="}[con.sense.value]
                lp_lhs = self._expr_to_lp(con.lhs)
                lines.append(f" {cname}: {lp_lhs} {sense_str} {con.rhs}")
        lines.append("")

        # Bounds
        lines.append("Bounds")
        for vname, var in self._variables.items():
            lb = var.lower_bound if var.lower_bound is not None else "-inf"
            ub = var.upper_bound if var.upper_bound is not None else "+inf"
            if var.var_type == VariableType.BINARY:
                lines.append(f" 0 <= {vname} <= 1")
            else:
                lines.append(f" {lb} <= {vname} <= {ub}")
        lines.append("")

        # Integer / binary declarations
        integers = [
            v for v in self._variables.values() if v.var_type == VariableType.INTEGER
        ]
        binaries = [
            v for v in self._variables.values() if v.var_type == VariableType.BINARY
        ]
        if integers:
            lines.append("General")
            for var in integers:
                lines.append(f" {var.full_name}")
        if binaries:
            lines.append("Binary")
            for var in binaries:
                lines.append(f" {var.full_name}")

        lines.append("End")
        text = "\n".join(lines)

        if path is not None:
            from pathlib import Path as _Path

            _Path(path).write_text(text)

        return text

    @staticmethod
    def _expr_to_lp(expr: Expression) -> str:
        """Convert an Expression to LP-format string."""
        parts: list[str] = []
        for t in expr.terms:
            var1 = t.variable if isinstance(t.variable, str) else t.variable.full_name
            coeff = t.coefficient
            sign = "+" if coeff >= 0 else "-"
            abs_coeff = abs(coeff)
            coeff_str = f"{abs_coeff} " if abs_coeff != 1.0 else ""
            if t.is_quadratic:
                var2 = (
                    t.variable2
                    if isinstance(t.variable2, str)
                    else t.variable2.full_name
                )
                parts.append(f"{sign} {coeff_str}{var1} * {var2}")
            else:
                parts.append(f"{sign} {coeff_str}{var1}")
        if expr.constant != 0.0:
            sign = "+" if expr.constant >= 0 else "-"
            parts.append(f"{sign} {abs(expr.constant)}")
        return " ".join(parts) if parts else "0"

    # ------------------------------------------------------------------
    # Summary
    # ------------------------------------------------------------------

    def summary(self) -> str:
        """Return a human-readable summary of the model.

        Example::

            print(model.summary())
        """
        lines = [
            f"Model: {self.name}",
            f"Type:  {self.problem_type}",
            f"Variables:   {self.num_variables}",
        ]
        by_type: dict[str, int] = {}
        for v in self._variables.values():
            by_type[v.var_type.value] = by_type.get(v.var_type.value, 0) + 1
        for vt, cnt in sorted(by_type.items()):
            lines.append(f"  {vt}: {cnt}")
        lines.append(f"Constraints: {self.num_constraints}")
        if self._objective:
            lines.append(f"Objective:   {self._objective.sense.value}")
        return "\n".join(lines)

    def __repr__(self) -> str:
        return (
            f"AbstractModel(name={self.name}, vars={self.num_variables}, "
            f"constraints={self.num_constraints}, type={self.problem_type})"
        )
