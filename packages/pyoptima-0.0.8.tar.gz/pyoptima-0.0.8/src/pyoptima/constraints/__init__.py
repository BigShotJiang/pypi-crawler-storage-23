"""
PyOptima Constraints Module.

Composable, chainable constraints that can be combined with + operator.
"""

from pyoptima.constraints.base import BaseConstraint

# Import all constraint types for convenience
from pyoptima.constraints.bounds import (
    GrossExposure,
    LongOnly,
    LongShort,
    PerAssetBounds,
    WeightBounds,
)
from pyoptima.constraints.cardinality import MaxAssets, MinAssets, MinPositionSize
from pyoptima.constraints.linear import LinearInequality
from pyoptima.constraints.liquidity import (
    LiquidityLimit,
    MaxParticipation,
    MaxSpreadCost,
)
from pyoptima.constraints.portfolio import (
    ExclusionList,
    InclusionList,
    MaxReturn,
    MinReturn,
    SumToOne,
)
from pyoptima.constraints.risk import (
    MaxConcentration,
    MaxCVaR,
    MaxDrawdown,
    MaxVolatility,
    TrackingErrorLimit,
)
from pyoptima.constraints.sector import (
    FactorExposureLimits,
    SectorCaps,
    SectorConstraints,
    SectorMins,
)
from pyoptima.constraints.turnover import MaxTurnover, TransactionCosts
from pyoptima.core.protocols import ConstraintSet

__all__ = [
    # Base
    "BaseConstraint",
    "ConstraintSet",
    # Bounds
    "WeightBounds",
    "PerAssetBounds",
    "LongOnly",
    "LongShort",
    "GrossExposure",
    # Cardinality
    "MaxAssets",
    "MinAssets",
    "MinPositionSize",
    # Sector
    "SectorCaps",
    "SectorMins",
    "SectorConstraints",
    "FactorExposureLimits",
    # Turnover
    "MaxTurnover",
    "TransactionCosts",
    # Risk
    "MaxVolatility",
    "MaxCVaR",
    "MaxDrawdown",
    "MaxConcentration",
    "TrackingErrorLimit",
    # Portfolio
    "SumToOne",
    "MinReturn",
    "MaxReturn",
    "ExclusionList",
    "InclusionList",
    "LinearInequality",
    # Liquidity
    "LiquidityLimit",
    "MaxParticipation",
    "MaxSpreadCost",
]
