"""
Base constraint class.

All constraints build real mathematical constraints on AbstractModel.
Composable with ``+`` operator. Serializable to/from config.
"""

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

from pyoptima.core.protocols import ConstraintSet

if TYPE_CHECKING:
    from pyoptima.model.core import AbstractModel


class BaseConstraint(ABC):
    """
    Base class for all optimization constraints.

    Constraints build real mathematical constraints on the optimization model.
    They can be combined with the ``+`` operator and serialized to/from config.

    Subclasses must implement ``_apply()`` which receives the model and data
    dict.  The constraint should call ``model.add_leq_constraint()``, etc.

    Example::

        class MyConstraint(BaseConstraint):
            name = "my_constraint"

            def __init__(self, limit: float):
                self.limit = limit

            def _apply(self, model, data):
                from pyoptima.model.core import Expression
                expr = Expression()
                for i in range(data["n_assets"]):
                    expr.add_term(1.0, f"w_{i}")
                model.add_leq_constraint("my_limit", expr, self.limit)

        # Combine with +
        constraints = MyConstraint(10) + AnotherConstraint()
    """

    name: str = "base_constraint"

    def apply(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        """Apply the constraint to the model.

        Args:
            model: The optimization model to add constraints to.
            data: Problem data dictionary.
        """
        self._apply(model, data)

    @abstractmethod
    def _apply(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        """Implementation — build math on the model.

        Args:
            model: The optimization model (AbstractModel).
            data: Problem data dict (``n_assets``, ``symbols``, etc.).
        """
        ...

    @classmethod
    def from_config(cls, config) -> "BaseConstraint":
        """Build constraint from a Pydantic config model."""
        raise NotImplementedError(f"{cls.__name__}.from_config()")

    def to_config(self) -> dict[str, Any]:
        """Serialize to config dict for YAML/JSON embedding."""
        import inspect

        result: dict[str, Any] = {}
        try:
            sig = inspect.signature(self.__init__)
            for pname in sig.parameters:
                if pname == "self":
                    continue
                if hasattr(self, pname):
                    result[pname] = getattr(self, pname)
        except (ValueError, TypeError):
            pass
        return result

    # ------------------------------------------------------------------ #
    # Composition
    # ------------------------------------------------------------------ #

    def __add__(self, other: "BaseConstraint | ConstraintSet") -> ConstraintSet:
        if isinstance(other, ConstraintSet):
            return ConstraintSet([self] + list(other))
        return ConstraintSet([self, other])

    def __radd__(self, other: "BaseConstraint | ConstraintSet") -> ConstraintSet:
        if isinstance(other, ConstraintSet):
            return other + self
        return ConstraintSet([other, self])

    def __repr__(self) -> str:
        import inspect

        try:
            init_sig = inspect.signature(self.__init__)
            params = []
            for pname, _param in init_sig.parameters.items():
                if pname == "self":
                    continue
                if hasattr(self, pname):
                    value = getattr(self, pname)
                    if isinstance(value, str):
                        params.append(f"{pname}={value!r}")
                    elif isinstance(value, float):
                        params.append(f"{pname}={value:.4g}")
                    elif value is not None:
                        params.append(f"{pname}={value!r}")
            return f"{self.__class__.__name__}({', '.join(params)})"
        except (ValueError, TypeError):
            return f"{self.__class__.__name__}()"
