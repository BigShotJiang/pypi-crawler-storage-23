"""
Risk constraints.

Constraints for limiting portfolio risk measures: volatility, CVaR,
drawdown, concentration, tracking error.
"""

from typing import TYPE_CHECKING, Any

import numpy as np

from pyoptima.constraints.base import BaseConstraint

if TYPE_CHECKING:
    from pyoptima.model.core import AbstractModel


class MaxVolatility(BaseConstraint):
    """Maximum portfolio volatility (standard deviation).

    Adds the quadratic constraint ``w' Σ w <= max_vol²``.

    Example::

        constraint = MaxVolatility(0.20)  # 20% annualized
    """

    name = "max_volatility"

    def __init__(self, max_volatility: float):
        self.max_volatility = max_volatility

    def _apply(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        from pyoptima.model.core import Expression

        cov = data.get("covariance_matrix")
        if cov is None:
            return
        cov = np.array(cov)
        n = cov.shape[0]

        expr = Expression()
        for i in range(n):
            for j in range(n):
                expr.add_term(float(cov[i, j]), f"w_{i}", f"w_{j}")
        model.add_leq_constraint("max_volatility", expr, self.max_volatility**2)


class MaxCVaR(BaseConstraint):
    """Maximum Conditional Value at Risk (CVaR) constraint.

    Requires historical returns in ``data["returns"]``.
    Adds auxiliary variables for the CVaR linearization.

    Example::

        constraint = MaxCVaR(max_cvar=0.05, confidence=0.95)
    """

    name = "max_cvar"

    def __init__(self, max_cvar: float, confidence: float = 0.95):
        self.max_cvar = max_cvar
        self.confidence = confidence

    def _apply(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        from pyoptima.model.core import Expression

        returns = data.get("returns")
        if returns is None:
            return
        returns = np.array(returns)

        T, n = returns.shape
        alpha = 1.0 - self.confidence

        # VaR variable
        model.add_continuous("cvar_zeta", lb=None, ub=None)

        # Auxiliary: u_t >= -(r_t' w) - zeta
        for t in range(T):
            model.add_continuous(f"cvar_u_{t}", lb=0.0)
            expr = Expression()
            for j in range(n):
                expr.add_term(-float(returns[t, j]), f"w_{j}")
            expr.add_term(-1.0, "cvar_zeta")
            expr.add_term(-1.0, f"cvar_u_{t}")
            model.add_leq_constraint(f"cvar_aux_{t}", expr, 0.0)

        # CVaR = zeta + (1/(T*alpha)) * sum(u_t) <= max_cvar
        cvar_expr = Expression()
        cvar_expr.add_term(1.0, "cvar_zeta")
        scale = 1.0 / (T * alpha)
        for t in range(T):
            cvar_expr.add_term(scale, f"cvar_u_{t}")
        model.add_leq_constraint("max_cvar", cvar_expr, self.max_cvar)


class MaxDrawdown(BaseConstraint):
    """Maximum drawdown constraint.

    Stores the limit; the template that supports drawdown constraints
    handles the time-series formulation.

    Example::

        constraint = MaxDrawdown(0.15)
    """

    name = "max_drawdown"

    def __init__(self, max_drawdown: float):
        self.max_drawdown = max_drawdown

    def _apply(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        # Drawdown requires a multi-period formulation.
        # Store the limit for template-level handling.
        data["_max_drawdown"] = self.max_drawdown


class MaxConcentration(BaseConstraint):
    """Maximum weight in top K assets (concentration limit).

    For ``top_k == 1`` this is simply an upper bound on each weight.
    For ``top_k > 1`` it requires sorting logic (handled via auxiliary
    constraints by the template).

    Example::

        constraint = MaxConcentration(max_weight=0.60, top_k=3)
    """

    name = "max_concentration"

    def __init__(self, max_weight: float, top_k: int = 1):
        self.max_weight = max_weight
        self.top_k = top_k

    def _apply(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        if self.top_k == 1:
            # Simple per-asset cap
            n = data.get("n_assets", 0)
            for i in range(n):
                var = model.get_variable(f"w_{i}")
                if var is not None and (
                    var.upper_bound is None or var.upper_bound > self.max_weight
                ):
                    var.upper_bound = self.max_weight
        else:
            # Top-K concentration requires sorting auxiliary formulation
            data["_max_concentration"] = (self.max_weight, self.top_k)


class TrackingErrorLimit(BaseConstraint):
    """Maximum tracking error versus a benchmark.

    Adds ``(w - b)' Σ (w - b) <= TE²`` where *b* is the benchmark
    weight vector.

    Requires ``data["benchmark_weights"]`` (dict or array) and
    ``data["covariance_matrix"]``.

    Example::

        constraint = TrackingErrorLimit(max_tracking_error=0.02)
    """

    name = "tracking_error_limit"

    def __init__(self, max_tracking_error: float):
        self.max_tracking_error = max_tracking_error

    def _apply(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        from pyoptima.model.core import Expression

        cov = data.get("covariance_matrix")
        bw = data.get("benchmark_weights")
        if cov is None or bw is None:
            return

        symbols = data.get("symbols", [])
        cov = np.array(cov)
        n = cov.shape[0]

        # Build benchmark array
        if isinstance(bw, dict):
            b = np.array([bw.get(s, 0.0) for s in symbols])
        else:
            b = np.array(bw)

        # (w - b)' Σ (w - b) = w' Σ w - 2 b' Σ w + b' Σ b
        te_expr = Expression()
        # Quadratic: w' Σ w
        for i in range(n):
            for j in range(n):
                te_expr.add_term(float(cov[i, j]), f"w_{i}", f"w_{j}")
        # Linear: -2 (Σ b)' w
        sigma_b = cov @ b
        for i in range(n):
            te_expr.add_term(-2.0 * float(sigma_b[i]), f"w_{i}")

        # Constant: b' Σ b
        const = float(b @ cov @ b)
        rhs = self.max_tracking_error**2 - const

        model.add_leq_constraint("max_tracking_error", te_expr, rhs)

    @classmethod
    def from_config(cls, config) -> "TrackingErrorLimit":
        return cls(max_tracking_error=config.max)
