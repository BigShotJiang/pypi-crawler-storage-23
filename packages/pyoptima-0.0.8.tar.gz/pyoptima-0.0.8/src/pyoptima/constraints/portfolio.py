"""
Portfolio-specific constraints.

Common constraints for portfolio optimization: sum-to-one, return bounds,
exclusion/inclusion lists.
"""

from typing import TYPE_CHECKING, Any

from pyoptima.constraints.base import BaseConstraint

if TYPE_CHECKING:
    from pyoptima.model.core import AbstractModel


class SumToOne(BaseConstraint):
    """Weights must sum to one (fully invested).

    Adds ``sum(w_i) == 1``.

    Example::

        constraint = SumToOne()
    """

    name = "sum_to_one"

    def __init__(self):
        pass

    def _apply(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        from pyoptima.model.core import Expression

        n = data.get("n_assets", 0)
        expr = Expression()
        for i in range(n):
            expr.add_term(1.0, f"w_{i}")
        model.add_eq_constraint("sum_to_one", expr, 1.0)


class MinReturn(BaseConstraint):
    """Minimum expected return constraint.

    Adds ``sum(w_i * mu_i) >= min_return``.

    Example::

        constraint = MinReturn(0.10)
    """

    name = "min_return"

    def __init__(self, min_return: float):
        self.min_return = min_return

    def _apply(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        from pyoptima.model.core import Expression

        er = data.get("expected_returns", [])
        n = len(er) if hasattr(er, "__len__") else data.get("n_assets", 0)
        expr = Expression()
        for i in range(n):
            mu_i = float(er[i]) if i < len(er) else 0.0
            expr.add_term(mu_i, f"w_{i}")
        model.add_geq_constraint("min_return", expr, self.min_return)


class MaxReturn(BaseConstraint):
    """Maximum expected return constraint.

    Adds ``sum(w_i * mu_i) <= max_return``.

    Example::

        constraint = MaxReturn(0.20)
    """

    name = "max_return"

    def __init__(self, max_return: float):
        self.max_return = max_return

    def _apply(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        from pyoptima.model.core import Expression

        er = data.get("expected_returns", [])
        n = len(er) if hasattr(er, "__len__") else data.get("n_assets", 0)
        expr = Expression()
        for i in range(n):
            mu_i = float(er[i]) if i < len(er) else 0.0
            expr.add_term(mu_i, f"w_{i}")
        model.add_leq_constraint("max_return", expr, self.max_return)


class ExclusionList(BaseConstraint):
    """Exclude specific assets (weight = 0).

    Fixes ``w_i = 0`` for each excluded symbol.

    Example::

        constraint = ExclusionList(["AAPL", "TSLA"])
    """

    name = "exclusion_list"

    def __init__(self, symbols: list[str] | set[str] | tuple):
        self.symbols = list(symbols)

    def _apply(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        all_symbols = data.get("symbols", [])
        excluded = set(self.symbols)
        for i, sym in enumerate(all_symbols):
            if sym in excluded:
                var = model.get_variable(f"w_{i}")
                if var is not None:
                    var.lower_bound = 0.0
                    var.upper_bound = 0.0


class InclusionList(BaseConstraint):
    """Restrict portfolio to only listed assets.

    Sets ``w_i = 0`` for every asset NOT in the inclusion list.

    Example::

        constraint = InclusionList(["AAPL", "MSFT", "GOOGL"])
    """

    name = "inclusion_list"

    def __init__(self, symbols: list[str] | set[str] | tuple):
        self.symbols = list(symbols)

    def _apply(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        all_symbols = data.get("symbols", [])
        allowed = set(self.symbols)
        for i, sym in enumerate(all_symbols):
            if sym not in allowed:
                var = model.get_variable(f"w_{i}")
                if var is not None:
                    var.lower_bound = 0.0
                    var.upper_bound = 0.0
