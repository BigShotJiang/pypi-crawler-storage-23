"""
Liquidity constraints for portfolio optimization.

- **LiquidityLimit** — Cap weight so positions can be liquidated within *N* days.
- **MaxParticipation** — Cap daily trade as a percentage of ADV.
- **MaxSpreadCost** — Constrain total spread cost of the portfolio.
"""

from typing import TYPE_CHECKING, Any

from pyoptima.constraints.base import BaseConstraint

if TYPE_CHECKING:
    from pyoptima.model.core import AbstractModel


class LiquidityLimit(BaseConstraint):
    """Cap each asset's weight based on average daily volume.

    Ensures every position can be liquidated within
    *max_days_to_liquidate* trading days at the given participation rate.

    .. math::

        w_i \\leq \\frac{\\text{ADV}_i \\times \\text{price}_i
            \\times \\text{max\\_days} \\times \\text{participation}}{\\text{portfolio\\_value}}

    Example::

        constraint = LiquidityLimit(
            adv={"AAPL": 75_000_000, "MSFT": 25_000_000},
            max_days_to_liquidate=1.0,
            prices={"AAPL": 185.0, "MSFT": 420.0},
            portfolio_value=10_000_000,
        )
    """

    name = "liquidity_limit"

    def __init__(
        self,
        adv: dict[str, float],
        max_days_to_liquidate: float = 1.0,
        participation_rate: float = 0.10,
        prices: dict[str, float] | None = None,
        portfolio_value: float = 1_000_000.0,
    ):
        self.adv = adv
        self.max_days_to_liquidate = max_days_to_liquidate
        self.participation_rate = participation_rate
        self.prices = prices or {}
        self.portfolio_value = portfolio_value

    def _apply(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        symbols = data.get("symbols", [])

        for i, sym in enumerate(symbols):
            if sym in self.adv:
                vol = self.adv[sym]
                price = self.prices.get(sym, 1.0)
                max_w = (
                    vol
                    * price
                    * self.max_days_to_liquidate
                    * self.participation_rate
                    / self.portfolio_value
                )
                var = model.get_variable(f"w_{i}")
                if var is not None:
                    if var.upper_bound is None or var.upper_bound > max_w:
                        var.upper_bound = max_w


class MaxParticipation(BaseConstraint):
    """Cap daily trade as a fraction of average daily volume.

    Similar to ``LiquidityLimit`` but focused on trade-day participation.

    Example::

        constraint = MaxParticipation(
            adv={"AAPL": 75_000_000},
            max_participation=0.10,
        )
    """

    name = "max_participation"

    def __init__(
        self,
        adv: dict[str, float],
        max_participation: float = 0.10,
        prices: dict[str, float] | None = None,
        portfolio_value: float = 1_000_000.0,
    ):
        self.adv = adv
        self.max_participation = max_participation
        self.prices = prices or {}
        self.portfolio_value = portfolio_value

    def _apply(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        symbols = data.get("symbols", [])

        for i, sym in enumerate(symbols):
            if sym in self.adv:
                vol = self.adv[sym]
                price = self.prices.get(sym, 1.0)
                max_trade = vol * price * self.max_participation
                max_w = max_trade / self.portfolio_value
                var = model.get_variable(f"w_{i}")
                if var is not None:
                    if var.upper_bound is None or var.upper_bound > max_w:
                        var.upper_bound = max_w


class MaxSpreadCost(BaseConstraint):
    """Constrain total portfolio spread cost.

    Total spread cost = ``sum |w_i| * spread_i / 2``.
    Linearized via positive/negative decomposition when shorts are allowed.

    For long-only portfolios: ``sum w_i * spread_i / 2 <= max_cost_bps``.

    Example::

        constraint = MaxSpreadCost(
            spreads={"AAPL": 1.0, "MSFT": 1.5, "ILLIQ": 50.0},
            max_cost_bps=5.0,
        )
    """

    name = "max_spread_cost"

    def __init__(
        self,
        spreads: dict[str, float],
        max_cost_bps: float = 10.0,
    ):
        self.spreads = spreads
        self.max_cost_bps = max_cost_bps

    def _apply(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        from pyoptima.model.core import Expression

        symbols = data.get("symbols", [])
        n = len(symbols)

        # For long-only: sum w_i * (spread_i / 2) <= max_cost_bps
        # (More complex linearization for long-short is deferred to template)
        expr = Expression()
        for i, sym in enumerate(symbols):
            spread = self.spreads.get(sym, 0.0) / 2.0
            if spread > 0:
                expr.add_term(spread, f"w_{i}")

        if expr.terms:
            model.add_leq_constraint("max_spread_cost", expr, self.max_cost_bps)
