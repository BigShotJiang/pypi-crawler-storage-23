"""
Cardinality constraints.

Limit the number of assets held in a portfolio using binary indicator
variables and big-M formulation.
"""

from typing import TYPE_CHECKING, Any

from pyoptima.constraints.base import BaseConstraint

if TYPE_CHECKING:
    from pyoptima.model.core import AbstractModel


class MaxAssets(BaseConstraint):
    """Maximum number of assets constraint.

    Introduces binary indicator variables ``z_i`` such that:

    - ``w_i <= M * z_i`` (if ``z_i = 0``, then ``w_i = 0``)
    - ``sum(z_i) <= max_assets``

    where *M* is the variable upper bound.

    Example::

        constraint = MaxAssets(10)
    """

    name = "max_assets"

    def __init__(self, max_assets: int):
        self.max_assets = max_assets

    def _apply(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        from pyoptima.model.core import Expression

        n = data.get("n_assets", 0)

        # Binary indicators
        for i in range(n):
            model.add_binary(f"z_{i}")

        # Link: w_i <= M * z_i
        for i in range(n):
            var = model.get_variable(f"w_{i}")
            M = var.upper_bound if (var and var.upper_bound) else 1.0
            link = Expression()
            link.add_term(1.0, f"w_{i}")
            link.add_term(-M, f"z_{i}")
            model.add_leq_constraint(f"card_link_{i}", link, 0.0)

        # Cardinality: sum(z_i) <= K
        card = Expression()
        for i in range(n):
            card.add_term(1.0, f"z_{i}")
        model.add_leq_constraint("max_assets", card, float(self.max_assets))

    @classmethod
    def from_config(cls, config) -> "MaxAssets":
        return cls(max_assets=config.max_assets)


class MinAssets(BaseConstraint):
    """Minimum number of assets constraint.

    Ensures at least ``min_assets`` assets have non-zero weight.

    Example::

        constraint = MinAssets(5)
    """

    name = "min_assets"

    def __init__(self, min_assets: int):
        self.min_assets = min_assets

    def _apply(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        from pyoptima.model.core import Expression

        n = data.get("n_assets", 0)

        # Add binaries if not already present
        for i in range(n):
            if model.get_variable(f"z_{i}") is None:
                model.add_binary(f"z_{i}")
                # Link: w_i <= M * z_i
                var = model.get_variable(f"w_{i}")
                M = var.upper_bound if (var and var.upper_bound) else 1.0
                link = Expression()
                link.add_term(1.0, f"w_{i}")
                link.add_term(-M, f"z_{i}")
                model.add_leq_constraint(f"card_link_{i}", link, 0.0)

        card = Expression()
        for i in range(n):
            card.add_term(1.0, f"z_{i}")
        model.add_geq_constraint("min_assets", card, float(self.min_assets))


class MinPositionSize(BaseConstraint):
    """Minimum position size if held.

    If an asset is held (``z_i = 1``), its weight must be at least
    ``min_size``:  ``w_i >= min_size * z_i``.

    Requires binary indicators (added automatically if not present).

    Example::

        constraint = MinPositionSize(0.02)
    """

    name = "min_position_size"

    def __init__(self, min_size: float):
        self.min_size = min_size

    def _apply(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        from pyoptima.model.core import Expression

        n = data.get("n_assets", 0)

        for i in range(n):
            # Ensure binary indicator exists
            if model.get_variable(f"z_{i}") is None:
                model.add_binary(f"z_{i}")
                var = model.get_variable(f"w_{i}")
                M = var.upper_bound if (var and var.upper_bound) else 1.0
                link = Expression()
                link.add_term(1.0, f"w_{i}")
                link.add_term(-M, f"z_{i}")
                model.add_leq_constraint(f"card_link_{i}", link, 0.0)

            # w_i >= min_size * z_i  →  w_i - min_size * z_i >= 0
            lower = Expression()
            lower.add_term(1.0, f"w_{i}")
            lower.add_term(-self.min_size, f"z_{i}")
            model.add_geq_constraint(f"min_pos_{i}", lower, 0.0)

    @classmethod
    def from_config(cls, config) -> "MinPositionSize":
        return cls(min_size=config.min_position)
