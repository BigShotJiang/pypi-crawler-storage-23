"""
Sector and factor exposure constraints.

Constraints for limiting sector allocation and factor loadings.
"""

from typing import TYPE_CHECKING, Any

import numpy as np

from pyoptima.constraints.base import BaseConstraint

if TYPE_CHECKING:
    from pyoptima.model.core import AbstractModel


class SectorCaps(BaseConstraint):
    """Maximum sector exposure constraints.

    For each sector, adds ``sum_{i in sector} w_i <= cap``.

    Example::

        constraint = SectorCaps(
            caps={"Technology": 0.4, "Finance": 0.3},
            asset_sectors={"AAPL": "Technology", "JPM": "Finance"},
        )
    """

    name = "sector_caps"

    def __init__(
        self,
        caps: dict[str, float],
        asset_sectors: dict[str, str] | None = None,
    ):
        self.caps = caps
        self.asset_sectors = asset_sectors

    def _apply(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        from pyoptima.model.core import Expression

        symbols = data.get("symbols", [])
        asset_sectors = self.asset_sectors or data.get("asset_sectors", {})

        for sector, cap in self.caps.items():
            expr = Expression()
            for i, sym in enumerate(symbols):
                if asset_sectors.get(sym) == sector:
                    expr.add_term(1.0, f"w_{i}")
            if expr.terms:
                model.add_leq_constraint(f"sector_cap_{sector}", expr, cap)

    @classmethod
    def from_config(cls, config) -> "SectorCaps":
        return cls(caps=config.caps or {}, asset_sectors=config.asset_map)


class SectorMins(BaseConstraint):
    """Minimum sector exposure constraints.

    For each sector, adds ``sum_{i in sector} w_i >= floor``.

    Example::

        constraint = SectorMins(
            mins={"Technology": 0.1, "Healthcare": 0.05},
            asset_sectors={"AAPL": "Technology", "JNJ": "Healthcare"},
        )
    """

    name = "sector_mins"

    def __init__(
        self,
        mins: dict[str, float],
        asset_sectors: dict[str, str] | None = None,
    ):
        self.mins = mins
        self.asset_sectors = asset_sectors

    def _apply(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        from pyoptima.model.core import Expression

        symbols = data.get("symbols", [])
        asset_sectors = self.asset_sectors or data.get("asset_sectors", {})

        for sector, floor in self.mins.items():
            expr = Expression()
            for i, sym in enumerate(symbols):
                if asset_sectors.get(sym) == sector:
                    expr.add_term(1.0, f"w_{i}")
            if expr.terms:
                model.add_geq_constraint(f"sector_min_{sector}", expr, floor)


class SectorConstraints(BaseConstraint):
    """Combined sector constraints (caps and mins in one object).

    Example::

        constraint = SectorConstraints(
            caps={"Technology": 0.4},
            mins={"Healthcare": 0.1},
            asset_sectors={"AAPL": "Technology", "JNJ": "Healthcare"},
        )
    """

    name = "sector_constraints"

    def __init__(
        self,
        caps: dict[str, float] | None = None,
        mins: dict[str, float] | None = None,
        asset_sectors: dict[str, str] | None = None,
    ):
        self.caps = caps or {}
        self.mins = mins or {}
        self.asset_sectors = asset_sectors

    def _apply(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        if self.caps:
            SectorCaps(self.caps, self.asset_sectors)._apply(model, data)
        if self.mins:
            SectorMins(self.mins, self.asset_sectors)._apply(model, data)

    @classmethod
    def from_config(cls, config) -> "SectorConstraints":
        return cls(
            caps=config.caps,
            mins=config.floors,
            asset_sectors=config.asset_map,
        )


class FactorExposureLimits(BaseConstraint):
    """Factor exposure constraints.

    For factor *k* with loadings ``B[:, k]``, adds:

    - ``B[:, k]' w <= upper_limit``
    - ``B[:, k]' w >= lower_limit``  (if tuple provided)

    Example::

        constraint = FactorExposureLimits(
            limits={"beta": (0.8, 1.2), "momentum": 0.5},
        )
    """

    name = "factor_exposure_limits"

    def __init__(
        self,
        limits: dict[str, float | tuple[float, float]],
        asset_factors: dict[str, dict[str, float]] | None = None,
    ):
        self.limits = limits
        self.asset_factors = asset_factors

    def _apply(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        from pyoptima.model.core import Expression

        symbols = data.get("symbols", [])
        n = len(symbols)

        # Build factor loadings from asset_factors dict or from data
        af = self.asset_factors or data.get("asset_factors", {})
        factor_loadings = data.get("factor_loadings")

        for factor_name, limit in self.limits.items():
            if isinstance(limit, (tuple, list)):
                lo, hi = limit
            else:
                lo, hi = -limit, limit

            # Build expression: B_factor' w
            expr_upper = Expression()
            expr_lower = Expression()

            if factor_loadings is not None:
                # factor_loadings is a matrix, need factor index
                factor_names = data.get("factor_names", [])
                if factor_name in factor_names:
                    k = factor_names.index(factor_name)
                    B = np.array(factor_loadings)
                    for i in range(n):
                        expr_upper.add_term(float(B[i, k]), f"w_{i}")
                        expr_lower.add_term(float(B[i, k]), f"w_{i}")
            elif af:
                for i, sym in enumerate(symbols):
                    loading = af.get(sym, {}).get(factor_name, 0.0)
                    if loading != 0.0:
                        expr_upper.add_term(loading, f"w_{i}")
                        expr_lower.add_term(loading, f"w_{i}")

            if expr_upper.terms:
                model.add_leq_constraint(f"factor_upper_{factor_name}", expr_upper, hi)
                model.add_geq_constraint(f"factor_lower_{factor_name}", expr_lower, lo)

    @classmethod
    def from_config(cls, config) -> "FactorExposureLimits":
        limits = {}
        if config.max_exposure:
            for f, v in config.max_exposure.items():
                lo = config.min_exposure.get(f, -v) if config.min_exposure else -v
                limits[f] = (lo, v)
        return cls(limits=limits)
