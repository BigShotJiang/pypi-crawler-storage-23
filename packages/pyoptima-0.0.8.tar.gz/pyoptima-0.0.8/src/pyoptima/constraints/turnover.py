"""
Turnover and transaction cost constraints.

Constraints for limiting portfolio changes and modeling trading costs.
"""

from typing import TYPE_CHECKING, Any

from pyoptima.constraints.base import BaseConstraint

if TYPE_CHECKING:
    from pyoptima.model.core import AbstractModel


class MaxTurnover(BaseConstraint):
    """Maximum turnover constraint.

    Limits total weight change: ``sum |w_new_i - w_old_i| <= max_turnover``.

    Linearized via buy/sell decomposition:

    - ``w_i = w_old_i + buy_i - sell_i``
    - ``buy_i, sell_i >= 0``
    - ``sum(buy_i + sell_i) <= max_turnover``

    Example::

        constraint = MaxTurnover(
            max_turnover=0.2,
            current_weights={"AAPL": 0.3, "GOOGL": 0.4, "MSFT": 0.3},
        )
    """

    name = "max_turnover"

    def __init__(
        self,
        max_turnover: float,
        current_weights: dict[str, float] | None = None,
    ):
        self.max_turnover = max_turnover
        self.current_weights = current_weights

    def _apply(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        from pyoptima.model.core import Expression

        symbols = data.get("symbols", [])
        n = len(symbols)
        cw = self.current_weights or data.get("current_weights", {})

        for i, sym in enumerate(symbols):
            old_w = (
                cw.get(sym, 0.0)
                if isinstance(cw, dict)
                else (cw[i] if i < len(cw) else 0.0)
            )
            var = model.get_variable(f"w_{i}")
            ub = var.upper_bound if (var and var.upper_bound) else 1.0

            model.add_continuous(f"buy_{i}", lb=0.0, ub=ub)
            model.add_continuous(f"sell_{i}", lb=0.0, ub=max(old_w, ub))

            # w_i = old_w + buy_i - sell_i
            balance = Expression()
            balance.add_term(1.0, f"w_{i}")
            balance.add_term(-1.0, f"buy_{i}")
            balance.add_term(1.0, f"sell_{i}")
            model.add_eq_constraint(f"turnover_balance_{i}", balance, old_w)

        # sum(buy + sell) <= max_turnover
        total = Expression()
        for i in range(n):
            total.add_term(1.0, f"buy_{i}")
            total.add_term(1.0, f"sell_{i}")
        model.add_leq_constraint("max_turnover", total, self.max_turnover)

    @classmethod
    def from_config(cls, config) -> "MaxTurnover":
        return cls(
            max_turnover=config.max,
            current_weights=config.current_weights,
        )


class TransactionCosts(BaseConstraint):
    """Transaction cost constraint.

    Models cost as ``tc * sum |w_i - w_old_i|`` and optionally constrains
    total cost to ``max_cost``.

    Reuses buy/sell decomposition from ``MaxTurnover`` if already present.

    Example::

        constraint = TransactionCosts(
            costs=0.001,
            current_weights={"AAPL": 0.3, "GOOGL": 0.4},
            max_cost=0.005,
        )
    """

    name = "transaction_costs"

    def __init__(
        self,
        costs: float | dict[str, float],
        current_weights: dict[str, float] | None = None,
        max_cost: float | None = None,
    ):
        self.costs = costs
        self.current_weights = current_weights
        self.max_cost = max_cost

    def _apply(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        from pyoptima.model.core import Expression

        if self.max_cost is None:
            # No constraint to add; costs are objective parameters
            return

        symbols = data.get("symbols", [])
        n = len(symbols)
        cw = self.current_weights or data.get("current_weights", {})

        # Ensure buy/sell variables exist
        for i, sym in enumerate(symbols):
            if model.get_variable(f"buy_{i}") is None:
                old_w = (
                    cw.get(sym, 0.0)
                    if isinstance(cw, dict)
                    else (cw[i] if i < len(cw) else 0.0)
                )
                var = model.get_variable(f"w_{i}")
                ub = var.upper_bound if (var and var.upper_bound) else 1.0

                model.add_continuous(f"buy_{i}", lb=0.0, ub=ub)
                model.add_continuous(f"sell_{i}", lb=0.0, ub=max(old_w, ub))

                balance = Expression()
                balance.add_term(1.0, f"w_{i}")
                balance.add_term(-1.0, f"buy_{i}")
                balance.add_term(1.0, f"sell_{i}")
                model.add_eq_constraint(f"tc_balance_{i}", balance, old_w)

        # Total cost: sum cost_i * (buy_i + sell_i) <= max_cost
        cost_expr = Expression()
        for i, sym in enumerate(symbols):
            c = (
                self.costs
                if isinstance(self.costs, (int, float))
                else self.costs.get(sym, 0.0)
            )
            cost_expr.add_term(c, f"buy_{i}")
            cost_expr.add_term(c, f"sell_{i}")
        model.add_leq_constraint("max_transaction_cost", cost_expr, self.max_cost)
