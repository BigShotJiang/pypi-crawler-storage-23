"""
Weight bound constraints.

Constraints that set variable bounds on portfolio weights.
"""

from typing import TYPE_CHECKING, Any

from pyoptima.constraints.base import BaseConstraint

if TYPE_CHECKING:
    from pyoptima.model.core import AbstractModel


class WeightBounds(BaseConstraint):
    """Global weight bounds for all assets.

    Sets ``lb <= w_i <= ub`` for every weight variable.

    Example::

        constraint = WeightBounds(min_weight=0.0, max_weight=0.4)
    """

    name = "weight_bounds"

    def __init__(self, min_weight: float = 0.0, max_weight: float = 1.0):
        self.min_weight = min_weight
        self.max_weight = max_weight

    def _apply(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        n = data.get("n_assets", 0)
        for i in range(n):
            var = model.get_variable(f"w_{i}")
            if var is not None:
                var.lower_bound = self.min_weight
                var.upper_bound = self.max_weight

    @classmethod
    def from_config(cls, config) -> "WeightBounds":
        return cls(min_weight=config.min, max_weight=config.max)


class PerAssetBounds(BaseConstraint):
    """Per-asset weight bounds.

    Override bounds for specific assets by symbol.

    Example::

        constraint = PerAssetBounds({
            "AAPL": (0.0, 0.3),
            "GOOGL": (0.05, 0.25),
        })
    """

    name = "per_asset_bounds"

    def __init__(self, bounds: dict[str, tuple[float, float]]):
        self.bounds = bounds

    def _apply(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        symbols = data.get("symbols", [])
        for i, sym in enumerate(symbols):
            if sym in self.bounds:
                lo, hi = self.bounds[sym]
                var = model.get_variable(f"w_{i}")
                if var is not None:
                    var.lower_bound = lo
                    var.upper_bound = hi


class LongOnly(BaseConstraint):
    """Long-only constraint (no short selling).

    Equivalent to ``WeightBounds(0, 1)``.

    Example::

        constraint = LongOnly()
    """

    name = "long_only"

    def __init__(self):
        pass

    def _apply(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        n = data.get("n_assets", 0)
        for i in range(n):
            var = model.get_variable(f"w_{i}")
            if var is not None:
                var.lower_bound = 0.0


class LongShort(BaseConstraint):
    """Long-short constraint allowing negative weights.

    Optionally caps gross exposure (``sum |w_i|``) and/or net exposure.

    Example::

        constraint = LongShort(min_weight=-0.5, max_weight=1.0, gross_exposure=1.5)
    """

    name = "long_short"

    def __init__(
        self,
        min_weight: float = -1.0,
        max_weight: float = 1.0,
        gross_exposure: float | None = None,
        net_exposure: tuple[float, float] | None = None,
    ):
        self.min_weight = min_weight
        self.max_weight = max_weight
        self.gross_exposure = gross_exposure
        self.net_exposure = net_exposure

    def _apply(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        from pyoptima.model.core import Expression

        n = data.get("n_assets", 0)

        # Set variable bounds
        for i in range(n):
            var = model.get_variable(f"w_{i}")
            if var is not None:
                var.lower_bound = self.min_weight
                var.upper_bound = self.max_weight

        # Gross exposure: sum |w_i| <= G
        # Linearized via w_i = w_plus_i - w_minus_i, |w_i| = w_plus_i + w_minus_i
        if self.gross_exposure is not None:
            for i in range(n):
                model.add_continuous(f"w_plus_{i}", lb=0.0, ub=self.max_weight)
                model.add_continuous(f"w_minus_{i}", lb=0.0, ub=abs(self.min_weight))
                # w_i = w_plus_i - w_minus_i
                split = Expression()
                split.add_term(1.0, f"w_{i}")
                split.add_term(-1.0, f"w_plus_{i}")
                split.add_term(1.0, f"w_minus_{i}")
                model.add_eq_constraint(f"ls_split_{i}", split, 0.0)

            gross = Expression()
            for i in range(n):
                gross.add_term(1.0, f"w_plus_{i}")
                gross.add_term(1.0, f"w_minus_{i}")
            model.add_leq_constraint("max_gross_exposure", gross, self.gross_exposure)

        # Net exposure: net_min <= sum w_i <= net_max
        if self.net_exposure is not None:
            net_min, net_max = self.net_exposure
            net_expr_lo = Expression()
            net_expr_hi = Expression()
            for i in range(n):
                net_expr_lo.add_term(1.0, f"w_{i}")
                net_expr_hi.add_term(1.0, f"w_{i}")
            model.add_geq_constraint("min_net_exposure", net_expr_lo, net_min)
            model.add_leq_constraint("max_net_exposure", net_expr_hi, net_max)


class GrossExposure(BaseConstraint):
    """Maximum gross exposure (sum of absolute weights).

    Example::

        constraint = GrossExposure(1.5)  # 130/30
    """

    name = "gross_exposure"

    def __init__(self, max_gross: float):
        self.max_gross = max_gross

    def _apply(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        from pyoptima.model.core import Expression

        n = data.get("n_assets", 0)

        # Linearize |w_i| via positive/negative decomposition
        for i in range(n):
            var = model.get_variable(f"w_{i}")
            ub = var.upper_bound if var and var.upper_bound else 1.0
            lb = var.lower_bound if var and var.lower_bound else -1.0
            model.add_continuous(f"w_abs_plus_{i}", lb=0.0, ub=max(ub, 0.0))
            model.add_continuous(f"w_abs_minus_{i}", lb=0.0, ub=max(abs(lb), 0.0))

            split = Expression()
            split.add_term(1.0, f"w_{i}")
            split.add_term(-1.0, f"w_abs_plus_{i}")
            split.add_term(1.0, f"w_abs_minus_{i}")
            model.add_eq_constraint(f"gross_split_{i}", split, 0.0)

        gross = Expression()
        for i in range(n):
            gross.add_term(1.0, f"w_abs_plus_{i}")
            gross.add_term(1.0, f"w_abs_minus_{i}")
        model.add_leq_constraint("max_gross_exposure", gross, self.max_gross)
