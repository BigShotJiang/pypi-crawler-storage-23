"""
Generic linear constraints.

Constraints of the form ``A @ x <= b``, ``A @ x >= b``, or ``A @ x == b``.
"""

from typing import TYPE_CHECKING, Any, Literal

import numpy as np

from pyoptima.constraints.base import BaseConstraint

if TYPE_CHECKING:
    from pyoptima.model.core import AbstractModel

Sense = Literal["<=", ">=", "=="]


class LinearInequality(BaseConstraint):
    """Generic linear constraint: ``A @ x ≤/≥/= b``.

    Each row of *A* defines a separate constraint against the weight
    variables ``w_0, w_1, …``.

    Example::

        # Single constraint: 2*w0 + 3*w1 <= 0.5
        constraint = LinearInequality(A=[[2, 3]], b=[0.5], sense="<=")

        # Multiple constraints
        constraint = LinearInequality(
            A=[[1, 1, 0], [0, 1, 1]],
            b=[0.4, 0.6],
            sense="<=",
        )
    """

    name = "linear_inequality"

    def __init__(
        self,
        A: list[list[float]] | Any,
        b: list[float] | Any,
        sense: Sense = "<=",
    ):
        self.A = A
        self.b = b
        self.sense = sense

    def _apply(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        from pyoptima.model.core import Expression

        A = np.atleast_2d(np.array(self.A, dtype=float))
        b = np.atleast_1d(np.array(self.b, dtype=float))
        m, n = A.shape

        for row in range(m):
            expr = Expression()
            for j in range(n):
                if A[row, j] != 0.0:
                    expr.add_term(float(A[row, j]), f"w_{j}")

            rhs = float(b[row])
            cname = f"linear_{row}"

            if self.sense == "<=":
                model.add_leq_constraint(cname, expr, rhs)
            elif self.sense == ">=":
                model.add_geq_constraint(cname, expr, rhs)
            else:
                model.add_eq_constraint(cname, expr, rhs)
