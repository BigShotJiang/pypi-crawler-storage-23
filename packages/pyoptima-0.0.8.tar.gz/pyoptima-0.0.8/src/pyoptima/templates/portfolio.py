"""
Comprehensive Portfolio Optimization Template.

Uses :class:`AbstractModel` for solver-agnostic model building. All objectives
and constraints are expressed as :class:`Expression` objects on the abstract
model, which the solver layer translates to Pyomo/OR-Tools/CVXPY as needed.

Supported objectives (31 portfolio + 4 trading):
    See ``SUPPORTED_OBJECTIVES`` for the full list.

Usage::

    from pyoptima.templates.portfolio import PortfolioTemplate

    template = PortfolioTemplate()
    result = template.solve({
        "expected_returns": [0.1, 0.12, 0.08],
        "covariance_matrix": [[0.04, 0.01, 0.02], ...],
        "symbols": ["AAPL", "GOOGL", "MSFT"],
        "objective": "min_volatility",
    })
"""

from typing import Any

import numpy as np
import pandas as pd

from pyoptima.core.result import OptimizationResult
from pyoptima.model.core import AbstractModel, Expression
from pyoptima.templates.base import ProblemTemplate, TemplateInfo, TemplateRegistry
from pyoptima.templates.portfolio_config import (
    Objective,
    PortfolioConfig,
)


def _to_numpy(
    data: pd.Series | pd.DataFrame | np.ndarray | list,
) -> tuple[np.ndarray, list[str] | None]:
    """Convert data to numpy array and extract labels if available."""
    if isinstance(data, pd.Series):
        return data.values, list(data.index)
    elif isinstance(data, pd.DataFrame):
        return data.values, list(data.columns)
    elif isinstance(data, list):
        return np.array(data), None
    else:
        return np.array(data), None


# =============================================================================
# Black-Litterman Helper Functions
# =============================================================================


def _market_implied_prior_returns(
    market_caps: np.ndarray,
    risk_aversion: float,
    cov_matrix: np.ndarray,
    risk_free_rate: float = 0.0,
) -> np.ndarray:
    """Compute market-implied prior returns."""
    mkt_weights = market_caps / market_caps.sum()
    return risk_aversion * np.dot(cov_matrix, mkt_weights) + risk_free_rate


def _black_litterman_returns(
    prior_returns: np.ndarray,
    cov_matrix: np.ndarray,
    views: np.ndarray,
    view_cov: np.ndarray,
    tau: float = 1.0,
) -> tuple[np.ndarray, np.ndarray]:
    """Calculate Black-Litterman posterior returns and covariance."""
    if len(views.shape) == 1:
        views = views.reshape(1, -1)

    tau_sigma = tau * cov_matrix
    tau_sigma_inv = np.linalg.inv(tau_sigma)
    view_cov_inv = np.linalg.inv(view_cov)

    posterior_cov = np.linalg.inv(
        tau_sigma_inv + np.dot(views.T, np.dot(view_cov_inv, views))
    )
    prior_term = np.dot(tau_sigma_inv, prior_returns)
    view_term = np.dot(views.T, np.dot(view_cov_inv, views))
    posterior_returns = np.dot(
        posterior_cov, prior_term + np.dot(view_term, prior_returns)
    )

    return posterior_returns, posterior_cov


# =============================================================================
# CVaR / CDaR / Semivariance Helper Functions (for solution formatting)
# =============================================================================


def _calculate_cvar(
    returns: np.ndarray,
    weights: np.ndarray,
    confidence_level: float = 0.05,
) -> float:
    portfolio_returns = np.dot(returns, weights)
    var = np.percentile(portfolio_returns, confidence_level * 100)
    cvar = np.mean(portfolio_returns[portfolio_returns <= var])
    return -cvar


def _calculate_drawdowns(returns: np.ndarray) -> np.ndarray:
    cumulative = np.cumprod(1 + returns, axis=0)
    running_max = np.maximum.accumulate(cumulative, axis=0)
    return (cumulative - running_max) / running_max


def _calculate_cdar(
    returns: np.ndarray,
    weights: np.ndarray,
    confidence_level: float = 0.05,
) -> float:
    portfolio_returns = np.dot(returns, weights)
    drawdowns = _calculate_drawdowns(portfolio_returns.reshape(-1, 1)).flatten()
    var = np.percentile(drawdowns, confidence_level * 100)
    cdar = np.mean(drawdowns[drawdowns <= var])
    return -cdar


def _calculate_semivariance(
    returns: np.ndarray,
    weights: np.ndarray,
    benchmark: float = 0.0,
) -> float:
    portfolio_returns = np.dot(returns, weights)
    downside = portfolio_returns[portfolio_returns < benchmark]
    if len(downside) == 0:
        return 0.0
    return float(np.mean((downside - benchmark) ** 2))


# =============================================================================
# CLA / HRP Helper Functions (non-solver algorithms)
# =============================================================================


def _cla_optimize(
    expected_returns: np.ndarray,
    cov_matrix: np.ndarray,
    weight_bounds: tuple[float, float] = (0, 1),
    objective: str = "min_volatility",
    risk_free_rate: float = 0.0,
) -> np.ndarray:
    """Simplified Critical Line Algorithm."""
    n = len(expected_returns)
    lower, upper = weight_bounds
    weights = np.ones(n) / n
    max_iter, tolerance, lr = 1000, 1e-6, 0.01

    for _ in range(max_iter):
        port_var = weights @ cov_matrix @ weights
        if objective == "max_sharpe":
            excess = weights @ expected_returns - risk_free_rate
            if excess > 0:
                gradient = (
                    -excess / port_var**1.5 * (cov_matrix @ weights)
                    + (1 / port_var**0.5) * expected_returns
                )
            else:
                gradient = 2 * cov_matrix @ weights
        else:
            gradient = 2 * cov_matrix @ weights

        new_w = np.clip(weights - lr * gradient, lower, upper)
        new_w /= new_w.sum()
        if np.max(np.abs(new_w - weights)) < tolerance:
            break
        weights = new_w
    return weights


def _hrp_optimize(cov_matrix: np.ndarray) -> np.ndarray:
    """Simplified Hierarchical Risk Parity."""
    inv_var = 1.0 / np.diag(cov_matrix)
    return inv_var / inv_var.sum()


# =============================================================================
# Diversification / Risk Parity helpers (for solution formatting)
# =============================================================================


def _calculate_diversification_ratio(
    weights: np.ndarray, cov_matrix: np.ndarray
) -> float:
    port_vol = np.sqrt(weights @ cov_matrix @ weights)
    wavg_vol = np.sum(weights * np.sqrt(np.diag(cov_matrix)))
    return wavg_vol / port_vol if port_vol > 0 else 0.0


def _calculate_diversification_index(
    weights: np.ndarray, cov_matrix: np.ndarray
) -> float:
    return _calculate_diversification_ratio(weights, cov_matrix)


def _calculate_risk_contribution(
    weights: np.ndarray, cov_matrix: np.ndarray
) -> np.ndarray:
    port_vol = np.sqrt(weights @ cov_matrix @ weights)
    if port_vol == 0:
        return np.zeros(len(weights))
    marginal = cov_matrix @ weights / port_vol
    return weights * marginal


# =============================================================================
# Momentum / Factor helpers
# =============================================================================


def _filter_by_momentum(
    returns: np.ndarray,
    symbols: list[str],
    momentum_period: int = 20,
    top_pct: float = 0.2,
) -> tuple[np.ndarray, list[str], np.ndarray]:
    if returns.ndim == 1:
        returns = returns.reshape(1, -1)
    period = min(momentum_period, returns.shape[0])
    momentum_scores = np.mean(returns[-period:], axis=0)
    n_select = max(1, int(len(symbols) * top_pct))
    top_indices = np.argsort(momentum_scores)[-n_select:]
    mask = np.zeros(len(symbols), dtype=bool)
    mask[top_indices] = True
    filtered_symbols = [symbols[i] for i in top_indices]
    return returns[:, mask], filtered_symbols, mask


def _calculate_factor_scores(
    factor_data: dict[str, np.ndarray],
    factor_weights: dict[str, float] | None = None,
) -> np.ndarray:
    if not factor_data:
        raise ValueError("factor_data cannot be empty")
    n_assets = len(next(iter(factor_data.values())))
    if factor_weights is None:
        factor_weights = {k: 1.0 / len(factor_data) for k in factor_data}
    composite = np.zeros(n_assets)
    for name, values in factor_data.items():
        fmin, fmax = values.min(), values.max()
        norm = (values - fmin) / (fmax - fmin) if fmax > fmin else np.ones_like(values)
        composite += factor_weights.get(name, 0.0) * norm
    return composite


# =============================================================================
# PortfolioTemplate
# =============================================================================


@TemplateRegistry.register("portfolio")
class PortfolioTemplate(ProblemTemplate):
    """
    Comprehensive Portfolio Optimization Template.

    Builds an :class:`AbstractModel` which is then solved by any registered
    solver backend (Pyomo→HiGHS/Ipopt, etc.).

    Special objectives (CLA, HRP) that do not use a solver are handled via
    internal algorithms in :meth:`solve`.
    """

    SUPPORTED_OBJECTIVES = [
        # Efficient Frontier
        "min_volatility",
        "max_sharpe",
        "max_return",
        "efficient_return",
        "efficient_risk",
        "max_utility",
        # Black-Litterman
        "black_litterman_max_sharpe",
        "black_litterman_min_volatility",
        "black_litterman_quadratic_utility",
        # CVaR
        "min_cvar",
        "efficient_cvar_risk",
        "efficient_cvar_return",
        # CDaR
        "min_cdar",
        "efficient_cdar_risk",
        "efficient_cdar_return",
        # Semivariance
        "min_semivariance",
        "efficient_semivariance_risk",
        "efficient_semivariance_return",
        # CLA / HRP
        "cla_min_volatility",
        "cla_max_sharpe",
        "hierarchical_min_volatility",
        "hierarchical_max_sharpe",
        # Diversification / Risk Parity
        "max_diversification",
        "max_diversification_index",
        "risk_parity",
        "equal_risk_contribution",
        # Transaction Cost-Aware
        "max_sharpe_with_costs",
        "min_volatility_with_costs",
        # Momentum / Factor
        "momentum_filtered_max_sharpe",
        "momentum_filtered_min_volatility",
        "factor_based_selection",
    ]

    @property
    def info(self) -> TemplateInfo:
        return TemplateInfo(
            name="portfolio",
            description="Comprehensive Portfolio Optimization",
            problem_type="QP",
            required_data=["expected_returns", "covariance_matrix"],
            optional_data=[
                "symbols",
                "objective",
                "weight_bounds",
                "min_weight",
                "max_weight",
                "risk_free_rate",
                "target_return",
                "target_volatility",
                "target_cvar",
                "target_cdar",
                "target_semivariance",
                "risk_aversion",
                "confidence_level",
                "benchmark",
                "returns",
                "market_caps",
                "views",
                "view_cov",
                "tau",
                "max_assets",
                "current_weights",
                "max_turnover",
                "transaction_costs",
                "momentum_period",
                "momentum_top_pct",
                "factor_data",
                "factor_weights",
                "min_position_size",
            ],
            default_solver="ipopt",
        )

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def validate_data(self, data: dict[str, Any] | PortfolioConfig) -> None:
        """Validate portfolio optimization data."""
        if isinstance(data, dict):
            config = PortfolioConfig.from_dict(data)
        else:
            config = data

        er, _ = _to_numpy(config.data.expected_returns)
        cov, _ = _to_numpy(config.data.covariance_matrix)
        n = len(er)
        if cov.shape != (n, n):
            raise ValueError(f"Covariance matrix must be {n}x{n}")

        objective = config.objective

        if objective in [
            Objective.EFFICIENT_RETURN,
            Objective.EFFICIENT_CVAR_RETURN,
            Objective.EFFICIENT_CDAR_RETURN,
            Objective.EFFICIENT_SEMIVARIANCE_RETURN,
        ]:
            if config.target_return is None:
                raise ValueError(f"target_return required for {objective.value}")

        if objective == Objective.EFFICIENT_RISK and config.target_volatility is None:
            raise ValueError("target_volatility required for efficient_risk")
        if objective == Objective.EFFICIENT_CVAR_RISK and config.target_cvar is None:
            raise ValueError("target_cvar required for efficient_cvar_risk")
        if objective == Objective.EFFICIENT_CDAR_RISK and config.target_cdar is None:
            raise ValueError("target_cdar required for efficient_cdar_risk")
        if (
            objective == Objective.EFFICIENT_SEMIVARIANCE_RISK
            and config.target_semivariance is None
        ):
            raise ValueError(
                "target_semivariance required for efficient_semivariance_risk"
            )

        if objective in [
            Objective.MIN_CVAR,
            Objective.EFFICIENT_CVAR_RISK,
            Objective.EFFICIENT_CVAR_RETURN,
            Objective.MIN_CDAR,
            Objective.EFFICIENT_CDAR_RISK,
            Objective.EFFICIENT_CDAR_RETURN,
            Objective.MIN_SEMIVARIANCE,
            Objective.EFFICIENT_SEMIVARIANCE_RISK,
            Objective.EFFICIENT_SEMIVARIANCE_RETURN,
        ]:
            if config.data.returns is None:
                raise ValueError(f"returns required for {objective.value}")

        if objective in [
            Objective.BL_MAX_SHARPE,
            Objective.BL_MIN_VOLATILITY,
            Objective.BL_QUADRATIC_UTILITY,
        ]:
            if config.black_litterman is None:
                raise ValueError("black_litterman config required for BL objectives")

        if config.turnover is not None and config.turnover.current_weights is None:
            raise ValueError("current_weights required with turnover constraint")

        if objective in [
            Objective.MOMENTUM_FILTERED_MAX_SHARPE,
            Objective.MOMENTUM_FILTERED_MIN_VOLATILITY,
        ]:
            if config.momentum is None:
                raise ValueError(
                    "momentum config required for momentum_filtered objectives"
                )

        if objective == Objective.FACTOR_BASED_SELECTION and config.factors is None:
            raise ValueError("factors config required for factor_based_selection")

    # ------------------------------------------------------------------
    # Model building (AbstractModel — solver-agnostic)
    # ------------------------------------------------------------------

    def build_model(self, config: dict[str, Any] | PortfolioConfig) -> AbstractModel:
        """Build an AbstractModel for portfolio optimization."""
        if isinstance(config, dict):
            config = PortfolioConfig.from_dict(config)

        er, symbols = _to_numpy(config.data.expected_returns)
        cov, _ = _to_numpy(config.data.covariance_matrix)
        if symbols is None:
            symbols = config.data.symbols or [f"Asset{i}" for i in range(len(er))]
        n = len(er)
        objective_str = (
            config.objective.value
            if isinstance(config.objective, Objective)
            else config.objective
        )

        min_weight = config.weight_bounds.min
        max_weight = config.weight_bounds.max

        # --- Create model ---
        model = AbstractModel(name="portfolio")
        model.add_set("assets", list(range(n)))
        model.add_parameter("symbols", symbols)
        model.add_parameter("expected_returns", er)
        model.add_parameter("covariance", cov)
        model.add_parameter("n_assets", n)
        model.add_parameter("objective_name", objective_str)
        model.add_parameter("config", config)

        # --- Weight variables ---
        for i in range(n):
            model.add_continuous(f"w_{i}", lb=min_weight, ub=max_weight)

        # --- Sum-to-one constraint ---
        sum_expr = Expression()
        for i in range(n):
            sum_expr.add_term(1.0, f"w_{i}")
        model.add_eq_constraint("sum_weights", sum_expr, 1.0)

        # --- Apply constraints ---
        self._add_cardinality_constraint(model, config, n, max_weight)
        self._add_turnover_constraint(model, config, n, symbols, objective_str)
        self._add_per_asset_bounds(model, config, n, symbols)
        self._add_sector_constraints(model, config, n, symbols)

        # --- Build objective ---
        self._build_objective(model, config, er, cov, n, symbols)

        return model

    # ------------------------------------------------------------------
    # Constraint helpers (build on AbstractModel)
    # ------------------------------------------------------------------

    def _add_cardinality_constraint(
        self, model: AbstractModel, config: PortfolioConfig, n: int, max_weight: float
    ) -> None:
        if config.cardinality is None or config.cardinality.max_assets >= n:
            model.add_parameter("has_cardinality", False)
            return

        card = config.cardinality
        for i in range(n):
            model.add_binary(f"z_{i}")

            # w_i >= min_position * z_i  →  w_i - min_position * z_i >= 0
            lower_expr = Expression()
            lower_expr.add_term(1.0, f"w_{i}")
            lower_expr.add_term(-card.min_position_size, f"z_{i}")
            model.add_geq_constraint(f"card_lower_{i}", lower_expr, 0.0)

            # w_i <= max_weight * z_i  →  w_i - max_weight * z_i <= 0
            upper_expr = Expression()
            upper_expr.add_term(1.0, f"w_{i}")
            upper_expr.add_term(-max_weight, f"z_{i}")
            model.add_leq_constraint(f"card_upper_{i}", upper_expr, 0.0)

        # sum(z_i) <= max_assets
        card_sum = Expression()
        for i in range(n):
            card_sum.add_term(1.0, f"z_{i}")
        model.add_leq_constraint("cardinality", card_sum, float(card.max_assets))
        model.add_parameter("has_cardinality", True)

    def _add_turnover_constraint(
        self,
        model: AbstractModel,
        config: PortfolioConfig,
        n: int,
        symbols: list[str],
        objective: str,
    ) -> None:
        has_tc = config.transaction_costs is not None and objective in (
            "max_sharpe_with_costs",
            "min_volatility_with_costs",
        )
        needs_turnover = config.turnover is not None or (
            has_tc and config.transaction_costs.current_weights is not None
        )
        if not needs_turnover:
            model.add_parameter("has_turnover", False)
            model.add_parameter("current_weights_array", None)
            return

        current_weights = (
            config.turnover.current_weights
            if config.turnover
            else config.transaction_costs.current_weights
        )
        if isinstance(current_weights, dict):
            cw_arr = np.array([current_weights.get(symbols[i], 0.0) for i in range(n)])
        else:
            cw_arr, _ = _to_numpy(current_weights)
            if len(cw_arr) != n:
                raise ValueError(f"current_weights length ({len(cw_arr)}) != n ({n})")

        for i in range(n):
            model.add_continuous(f"buy_{i}", lb=0.0)
            model.add_continuous(f"sell_{i}", lb=0.0)
            # w_i = cw_i + buy_i - sell_i
            bal = Expression()
            bal.add_term(1.0, f"w_{i}")
            bal.add_term(-1.0, f"buy_{i}")
            bal.add_term(1.0, f"sell_{i}")
            model.add_eq_constraint(f"turnover_balance_{i}", bal, float(cw_arr[i]))

        if config.turnover is not None:
            turnover_sum = Expression()
            for i in range(n):
                turnover_sum.add_term(1.0, f"buy_{i}")
                turnover_sum.add_term(1.0, f"sell_{i}")
            model.add_leq_constraint(
                "max_turnover", turnover_sum, config.turnover.max_turnover
            )
            model.add_parameter("has_turnover", True)
        else:
            model.add_parameter("has_turnover", False)

        model.add_parameter("current_weights_array", cw_arr)

    def _add_per_asset_bounds(
        self, model: AbstractModel, config: PortfolioConfig, n: int, symbols: list[str]
    ) -> None:
        if config.per_asset_bounds is None or not config.per_asset_bounds.bounds:
            return
        for i in range(n):
            sym = symbols[i]
            if sym in config.per_asset_bounds.bounds:
                lo, hi = config.per_asset_bounds.bounds[sym]
                var = model.get_variable(f"w_{i}")
                if var is not None:
                    var.lower_bound = lo
                    var.upper_bound = hi

    def _add_sector_constraints(
        self, model: AbstractModel, config: PortfolioConfig, n: int, symbols: list[str]
    ) -> None:
        if config.sector_constraints is None:
            return
        sc = config.sector_constraints
        if not sc.asset_sectors:
            return

        sector_assets: dict[str, list[int]] = {}
        for i, sym in enumerate(symbols):
            if sym in sc.asset_sectors:
                sector = sc.asset_sectors[sym]
                sector_assets.setdefault(sector, []).append(i)

        if sc.sector_caps:
            for sector, cap in sc.sector_caps.items():
                if sector in sector_assets:
                    expr = Expression()
                    for i in sector_assets[sector]:
                        expr.add_term(1.0, f"w_{i}")
                    model.add_leq_constraint(f"sector_cap_{sector}", expr, cap)

        if sc.sector_mins:
            for sector, floor in sc.sector_mins.items():
                if sector in sector_assets:
                    expr = Expression()
                    for i in sector_assets[sector]:
                        expr.add_term(1.0, f"w_{i}")
                    model.add_geq_constraint(f"sector_min_{sector}", expr, floor)

    # ------------------------------------------------------------------
    # Objective building (on AbstractModel)
    # ------------------------------------------------------------------

    def _build_objective(
        self,
        model: AbstractModel,
        config: PortfolioConfig,
        er: np.ndarray,
        cov: np.ndarray,
        n: int,
        symbols: list[str],
    ) -> None:
        """Route to the appropriate objective builder."""
        objective = config.objective

        if objective in (
            Objective.MIN_VOLATILITY,
            Objective.MAX_RETURN,
            Objective.EFFICIENT_RETURN,
            Objective.EFFICIENT_RISK,
            Objective.MAX_UTILITY,
            Objective.MAX_SHARPE,
        ):
            self._build_efficient_frontier(model, objective, config, er, cov, n)
        elif objective in (
            Objective.BL_MAX_SHARPE,
            Objective.BL_MIN_VOLATILITY,
            Objective.BL_QUADRATIC_UTILITY,
        ):
            self._build_black_litterman(model, objective, config, er, cov, n)
        elif objective in (
            Objective.MIN_CVAR,
            Objective.EFFICIENT_CVAR_RISK,
            Objective.EFFICIENT_CVAR_RETURN,
        ):
            self._build_cvar(model, objective, config, er, n)
        elif objective in (
            Objective.MIN_CDAR,
            Objective.EFFICIENT_CDAR_RISK,
            Objective.EFFICIENT_CDAR_RETURN,
        ):
            self._build_cdar(model, objective, config, er, n)
        elif objective in (
            Objective.MIN_SEMIVARIANCE,
            Objective.EFFICIENT_SEMIVARIANCE_RISK,
            Objective.EFFICIENT_SEMIVARIANCE_RETURN,
        ):
            self._build_semivariance(model, objective, config, er, n)
        elif objective in (
            Objective.MAX_DIVERSIFICATION,
            Objective.MAX_DIVERSIFICATION_INDEX,
        ):
            self._build_diversification(model, objective, cov, n)
        elif objective in (Objective.RISK_PARITY, Objective.EQUAL_RISK_CONTRIBUTION):
            self._build_risk_parity(model, cov, n)
        elif objective in (
            Objective.MAX_SHARPE_WITH_COSTS,
            Objective.MIN_VOLATILITY_WITH_COSTS,
        ):
            self._build_transaction_cost(model, objective, config, er, cov, n, symbols)
        elif objective in (
            Objective.MOMENTUM_FILTERED_MAX_SHARPE,
            Objective.MOMENTUM_FILTERED_MIN_VOLATILITY,
        ):
            self._build_momentum_filtered(model, objective, config, er, cov, n, symbols)
        elif objective == Objective.FACTOR_BASED_SELECTION:
            self._build_factor(model, config, cov, n)

    # --- helpers -------------------------------------------------------

    @staticmethod
    def _variance_expr(cov: np.ndarray, n: int) -> Expression:
        """Build w'Σw quadratic expression."""
        expr = Expression()
        for i in range(n):
            for j in range(n):
                c = float(cov[i, j])
                if c != 0.0:
                    expr.add_term(c, f"w_{i}", f"w_{j}")
        return expr

    @staticmethod
    def _return_expr(er: np.ndarray, n: int) -> Expression:
        """Build μ'w linear expression."""
        expr = Expression()
        for i in range(n):
            if er[i] != 0.0:
                expr.add_term(float(er[i]), f"w_{i}")
        return expr

    # --- Efficient Frontier -------------------------------------------

    def _build_efficient_frontier(
        self,
        model: AbstractModel,
        objective: Objective,
        config: PortfolioConfig,
        er: np.ndarray,
        cov: np.ndarray,
        n: int,
    ) -> None:
        var_expr = self._variance_expr(cov, n)
        ret_expr = self._return_expr(er, n)

        if objective == Objective.MIN_VOLATILITY:
            model.minimize(var_expr)
        elif objective == Objective.MAX_RETURN:
            model.maximize(ret_expr)
        elif objective == Objective.MAX_SHARPE:
            self._build_sharpe(model, er, cov, config.risk_free_rate, n)
        elif objective == Objective.EFFICIENT_RETURN:
            model.add_geq_constraint("min_return", ret_expr, config.target_return)
            model.minimize(var_expr)
        elif objective == Objective.EFFICIENT_RISK:
            target_var = config.target_volatility**2
            model.add_leq_constraint("max_variance", var_expr, target_var)
            model.maximize(ret_expr)
        elif objective == Objective.MAX_UTILITY:
            # maximize μ'w - λ w'Σw  →  minimize λ w'Σw - μ'w
            utility = Expression()
            lam = config.risk_aversion
            for i in range(n):
                for j in range(n):
                    c = float(cov[i, j])
                    if c != 0.0:
                        utility.add_term(lam * c, f"w_{i}", f"w_{j}")
            for i in range(n):
                if er[i] != 0.0:
                    utility.add_term(-float(er[i]), f"w_{i}")
            model.minimize(utility)

    def _build_sharpe(
        self,
        model: AbstractModel,
        er: np.ndarray,
        cov: np.ndarray,
        rf: float,
        n: int,
        prefix: str = "",
    ) -> None:
        """Build Sharpe maximization via variance minimization with normalisation.

        Uses the standard Cornuéjols-Tütüncü trick: introduce scaled variables
        y_i = scale * w_i, constrain (μ-rf)'w * scale = 1, then min y'Σy.
        """
        model.add_continuous(f"scale{prefix}", lb=0.0)
        for i in range(n):
            model.add_continuous(f"y{prefix}_{i}", lb=0.0)
            # y_i = scale * w_i  →  y_i - scale * w_i = 0 (bilinear, linearized)
            # Actually, since this is bilinear we use the standard LP trick:
            # minimize y'Σy subject to (μ-rf)'w = 1  (fix normalisation)

        # For the classic Sharpe linearization we directly constrain
        # (μ - rf)' w == 1  (normalisation) and minimize w'Σw.
        norm_expr = Expression()
        for i in range(n):
            norm_expr.add_term(float(er[i] - rf), f"w_{i}")
        model.add_eq_constraint(f"sharpe_normalize{prefix}", norm_expr, 1.0)

        # Remove sum-to-one constraint (incompatible with Sharpe normalisation)
        # and set the objective to minimise variance
        if "sum_weights" in model.constraints:
            del model._constraints["sum_weights"]

        # Minimize w'Σw (the inverse of Sharpe² in the normalised space)
        var_expr = self._variance_expr(cov, n)
        model.minimize(var_expr)

    # --- Black-Litterman ---------------------------------------------

    def _build_black_litterman(
        self,
        model: AbstractModel,
        objective: Objective,
        config: PortfolioConfig,
        er: np.ndarray,
        cov: np.ndarray,
        n: int,
    ) -> None:
        bl_er, bl_cov = self._compute_bl_returns(config, er, cov)
        model.add_parameter("bl_expected_returns", bl_er)
        model.add_parameter("bl_covariance", bl_cov)

        if objective == Objective.BL_MAX_SHARPE:
            self._build_sharpe(
                model, bl_er, bl_cov, config.risk_free_rate, n, prefix="_bl"
            )
        elif objective == Objective.BL_MIN_VOLATILITY:
            model.minimize(self._variance_expr(bl_cov, n))
        elif objective == Objective.BL_QUADRATIC_UTILITY:
            # minimize λ w'Σw_bl - μ_bl'w
            utility = Expression()
            lam = config.risk_aversion
            for i in range(n):
                for j in range(n):
                    c = float(bl_cov[i, j])
                    if c != 0.0:
                        utility.add_term(lam * c, f"w_{i}", f"w_{j}")
            for i in range(n):
                if bl_er[i] != 0.0:
                    utility.add_term(-float(bl_er[i]), f"w_{i}")
            model.minimize(utility)

    @staticmethod
    def _compute_bl_returns(
        config: PortfolioConfig, er: np.ndarray, cov: np.ndarray
    ) -> tuple[np.ndarray, np.ndarray]:
        bl = config.black_litterman
        if bl.market_caps is not None:
            mc, _ = _to_numpy(bl.market_caps)
            prior = _market_implied_prior_returns(
                mc, config.risk_aversion, cov, config.risk_free_rate
            )
        else:
            prior = er
        if bl.views is not None and bl.view_cov is not None:
            views, _ = _to_numpy(bl.views)
            view_cov, _ = _to_numpy(bl.view_cov)
            return _black_litterman_returns(prior, cov, views, view_cov, bl.tau)
        return prior, cov

    # --- CVaR ---------------------------------------------------------

    def _build_cvar(
        self,
        model: AbstractModel,
        objective: Objective,
        config: PortfolioConfig,
        er: np.ndarray,
        n: int,
    ) -> None:
        returns_arr = self._get_returns_array(config.data.returns)
        T = returns_arr.shape[0]
        alpha = config.confidence_level
        model.add_parameter("returns_array", returns_arr)
        model.add_parameter("confidence_level", alpha)

        model.add_continuous("cvar_zeta")  # VaR variable (unbounded)
        for t in range(T):
            model.add_continuous(f"cvar_u_{t}", lb=0.0)
            # u_t >= zeta - r_t' w
            lhs = Expression()
            lhs.add_term(1.0, f"cvar_u_{t}")
            lhs.add_term(-1.0, "cvar_zeta")
            for i in range(n):
                lhs.add_term(float(returns_arr[t, i]), f"w_{i}")
            model.add_geq_constraint(f"cvar_c_{t}", lhs, 0.0)

        # CVaR = zeta + (1/(alpha*T)) * sum(u_t)
        cvar_expr = Expression()
        cvar_expr.add_term(1.0, "cvar_zeta")
        coeff = 1.0 / (alpha * T)
        for t in range(T):
            cvar_expr.add_term(coeff, f"cvar_u_{t}")

        ret_expr = self._return_expr(er, n)

        if objective == Objective.MIN_CVAR:
            model.minimize(cvar_expr)
        elif objective == Objective.EFFICIENT_CVAR_RISK:
            model.add_leq_constraint("max_cvar", cvar_expr, config.target_cvar)
            model.maximize(ret_expr)
        elif objective == Objective.EFFICIENT_CVAR_RETURN:
            model.add_geq_constraint("min_return", ret_expr, config.target_return)
            model.minimize(cvar_expr)

    # --- CDaR ---------------------------------------------------------

    def _build_cdar(
        self,
        model: AbstractModel,
        objective: Objective,
        config: PortfolioConfig,
        er: np.ndarray,
        n: int,
    ) -> None:
        returns_arr = self._get_returns_array(config.data.returns)
        T = returns_arr.shape[0]
        alpha = config.confidence_level
        model.add_parameter("returns_array", returns_arr)
        model.add_parameter("confidence_level", alpha)

        model.add_continuous("cdar_zeta")
        for t in range(T):
            model.add_continuous(f"cdar_u_{t}", lb=0.0)
            lhs = Expression()
            lhs.add_term(1.0, f"cdar_u_{t}")
            lhs.add_term(-1.0, "cdar_zeta")
            for i in range(n):
                lhs.add_term(float(returns_arr[t, i]), f"w_{i}")
            model.add_geq_constraint(f"cdar_c_{t}", lhs, 0.0)

        cdar_expr = Expression()
        cdar_expr.add_term(1.0, "cdar_zeta")
        coeff = 1.0 / (alpha * T)
        for t in range(T):
            cdar_expr.add_term(coeff, f"cdar_u_{t}")

        ret_expr = self._return_expr(er, n)

        if objective == Objective.MIN_CDAR:
            model.minimize(cdar_expr)
        elif objective == Objective.EFFICIENT_CDAR_RISK:
            model.add_leq_constraint("max_cdar", cdar_expr, config.target_cdar)
            model.maximize(ret_expr)
        elif objective == Objective.EFFICIENT_CDAR_RETURN:
            model.add_geq_constraint("min_return", ret_expr, config.target_return)
            model.minimize(cdar_expr)

    # --- Semivariance -------------------------------------------------

    def _build_semivariance(
        self,
        model: AbstractModel,
        objective: Objective,
        config: PortfolioConfig,
        er: np.ndarray,
        n: int,
    ) -> None:
        returns_arr = self._get_returns_array(config.data.returns)
        T = returns_arr.shape[0]
        benchmark = config.benchmark
        model.add_parameter("returns_array", returns_arr)
        model.add_parameter("benchmark", benchmark)

        for t in range(T):
            model.add_continuous(f"d_{t}", lb=0.0)
            # d_t >= benchmark - r_t'w
            lhs = Expression()
            lhs.add_term(1.0, f"d_{t}")
            for i in range(n):
                lhs.add_term(float(returns_arr[t, i]), f"w_{i}")
            model.add_geq_constraint(f"semi_c_{t}", lhs, benchmark)

        # semivariance = (1/T) * sum(d_t^2)
        semi_expr = Expression()
        inv_T = 1.0 / T
        for t in range(T):
            semi_expr.add_term(inv_T, f"d_{t}", f"d_{t}")

        ret_expr = self._return_expr(er, n)

        if objective == Objective.MIN_SEMIVARIANCE:
            model.minimize(semi_expr)
        elif objective == Objective.EFFICIENT_SEMIVARIANCE_RISK:
            model.add_leq_constraint("max_semi", semi_expr, config.target_semivariance)
            model.maximize(ret_expr)
        elif objective == Objective.EFFICIENT_SEMIVARIANCE_RETURN:
            model.add_geq_constraint("min_return", ret_expr, config.target_return)
            model.minimize(semi_expr)

    # --- Diversification / Risk Parity --------------------------------

    def _build_diversification(
        self,
        model: AbstractModel,
        objective: Objective,
        cov: np.ndarray,
        n: int,
    ) -> None:
        """Max diversification via normalisation trick: min w'Σw s.t. sum(w_i σ_i)=1."""
        sigmas = np.sqrt(np.diag(cov))

        # Replace sum-to-one with weighted-vol-sum = 1
        if "sum_weights" in model.constraints:
            del model._constraints["sum_weights"]

        norm_expr = Expression()
        for i in range(n):
            norm_expr.add_term(float(sigmas[i]), f"w_{i}")
        model.add_eq_constraint("div_normalize", norm_expr, 1.0)

        model.minimize(self._variance_expr(cov, n))

    def _build_risk_parity(self, model: AbstractModel, cov: np.ndarray, n: int) -> None:
        """Risk parity is non-convex. Use variance proxy and store metadata."""
        # Approximate: minimize variance (a reasonable convex proxy).
        # True risk parity needs nonlinear solver or iterative method;
        # the scipy path handles this correctly.
        model.minimize(self._variance_expr(cov, n))
        model.add_parameter("is_risk_parity", True)

    # --- Transaction costs --------------------------------------------

    def _build_transaction_cost(
        self,
        model: AbstractModel,
        objective: Objective,
        config: PortfolioConfig,
        er: np.ndarray,
        cov: np.ndarray,
        n: int,
        symbols: list[str],
    ) -> None:
        if config.transaction_costs is None:
            raise ValueError("transaction_costs required")

        tc = config.transaction_costs
        if isinstance(tc.costs, dict):
            cost_arr = np.array([tc.costs.get(symbols[i], 0.0) for i in range(n)])
        else:
            cost_arr, _ = _to_numpy(tc.costs)
            if len(cost_arr) != n:
                cost_arr = np.full(
                    n, float(tc.costs) if isinstance(tc.costs, (int, float)) else 0.0
                )

        # Build total-cost expression using buy/sell variables if available
        has_buy_sell = model.get_variable("buy_0") is not None
        if has_buy_sell:
            cost_expr = Expression()
            for i in range(n):
                cost_expr.add_term(float(cost_arr[i]), f"buy_{i}")
                cost_expr.add_term(float(cost_arr[i]), f"sell_{i}")
        elif tc.current_weights is not None:
            if isinstance(tc.current_weights, dict):
                cw_arr = np.array(
                    [tc.current_weights.get(symbols[i], 0.0) for i in range(n)]
                )
            else:
                cw_arr, _ = _to_numpy(tc.current_weights)

            for i in range(n):
                if model.get_variable(f"buy_{i}") is None:
                    model.add_continuous(f"buy_{i}", lb=0.0)
                    model.add_continuous(f"sell_{i}", lb=0.0)
                    bal = Expression()
                    bal.add_term(1.0, f"w_{i}")
                    bal.add_term(-1.0, f"buy_{i}")
                    bal.add_term(1.0, f"sell_{i}")
                    model.add_eq_constraint(f"tc_balance_{i}", bal, float(cw_arr[i]))

            cost_expr = Expression()
            for i in range(n):
                cost_expr.add_term(float(cost_arr[i]), f"buy_{i}")
                cost_expr.add_term(float(cost_arr[i]), f"sell_{i}")
        else:
            cost_expr = Expression()
            for i in range(n):
                cost_expr.add_term(float(cost_arr[i]), f"w_{i}")

        if objective == Objective.MAX_SHARPE_WITH_COSTS:
            # Use Sharpe linearization with net return
            # (μ - tc)' w - rf normalised, then min variance
            self._build_sharpe(
                model, er - cost_arr, cov, config.risk_free_rate, n, prefix="_tc"
            )
        else:  # MIN_VOLATILITY_WITH_COSTS
            # min variance s.t. μ'w - cost >= min_net_return
            net_ret = Expression()
            for i in range(n):
                net_ret.add_term(float(er[i]), f"w_{i}")
            # Subtract cost_expr terms
            if has_buy_sell or (tc.current_weights is not None):
                for i in range(n):
                    net_ret.add_term(-float(cost_arr[i]), f"buy_{i}")
                    net_ret.add_term(-float(cost_arr[i]), f"sell_{i}")
            else:
                for i in range(n):
                    net_ret.add_term(-float(cost_arr[i]), f"w_{i}")
            model.add_geq_constraint("min_net_return", net_ret, config.min_net_return)
            model.minimize(self._variance_expr(cov, n))

    # --- Momentum-filtered --------------------------------------------

    def _build_momentum_filtered(
        self,
        model: AbstractModel,
        objective: Objective,
        config: PortfolioConfig,
        er: np.ndarray,
        cov: np.ndarray,
        n: int,
        symbols: list[str],
    ) -> None:
        returns_arr = self._get_returns_array(config.data.returns)
        momentum_period = config.momentum.period if config.momentum else 20
        momentum_top_pct = config.momentum.top_pct if config.momentum else 0.2

        _, _, mask = _filter_by_momentum(
            returns_arr, symbols, momentum_period, momentum_top_pct
        )
        model.add_parameter("momentum_mask", mask)

        # Zero out excluded assets
        for i in range(n):
            if not mask[i]:
                var = model.get_variable(f"w_{i}")
                if var:
                    var.lower_bound = 0.0
                    var.upper_bound = 0.0

        if objective == Objective.MOMENTUM_FILTERED_MAX_SHARPE:
            self._build_sharpe(model, er, cov, config.risk_free_rate, n, prefix="_mom")
        else:
            model.minimize(self._variance_expr(cov, n))

    # --- Factor-based -------------------------------------------------

    def _build_factor(
        self,
        model: AbstractModel,
        config: PortfolioConfig,
        cov: np.ndarray,
        n: int,
    ) -> None:
        factors = config.factors
        scores = _calculate_factor_scores(factors.factor_data, factors.factor_weights)
        fmin, fmax = scores.min(), scores.max()
        if fmax > fmin:
            scores = (scores - fmin) / (fmax - fmin)
        else:
            scores = np.ones_like(scores)
        model.add_parameter("factor_scores", scores)

        if config.max_volatility is not None:
            model.add_leq_constraint(
                "max_variance",
                self._variance_expr(cov, n),
                config.max_volatility**2,
            )

        # Maximize factor score → minimize negative factor score
        obj = Expression()
        for i in range(n):
            obj.add_term(-float(scores[i]), f"w_{i}")
        model.minimize(obj)

    # ------------------------------------------------------------------
    # Solving (override base to handle scipy / CLA / HRP fast paths)
    # ------------------------------------------------------------------

    def solve(
        self,
        data: dict[str, Any] | PortfolioConfig,
        solver: str | None = None,
        options: dict[str, Any] | None = None,
    ) -> OptimizationResult:
        """Solve portfolio optimization.

        For most objectives, delegates to the base-class solve() which uses
        ``build_model()`` → ``solver.solve()`` → ``format_solution()``.

        Special algorithms (CLA, HRP) bypass the model layer entirely.
        Scipy SLSQP is tried first for simple quadratic objectives.
        """
        self.validate_data(data)

        if isinstance(data, dict):
            config = PortfolioConfig.from_dict(data)
        else:
            config = data

        objective = config.objective
        solver_name = solver or self.info.default_solver
        options = options or {}

        # --- Non-solver algorithms ---
        if objective in (Objective.CLA_MIN_VOLATILITY, Objective.CLA_MAX_SHARPE):
            return OptimizationResult.from_solution_dict(self._solve_cla(config))
        if objective in (
            Objective.HIERARCHICAL_MIN_VOLATILITY,
            Objective.HIERARCHICAL_MAX_SHARPE,
        ):
            return OptimizationResult.from_solution_dict(
                self._solve_hierarchical(config)
            )

        # --- Scipy fast path ---
        if solver_name in ("scipy", "auto", "ipopt"):
            scipy_result = self._solve_scipy(config, options)
            if scipy_result is not None:
                return scipy_result

        # --- Standard path: AbstractModel → Solver (via base class) ---
        model = self.build_model(config)

        from pyoptima.solvers import SolverOptions, get_solver

        solver_instance = get_solver(solver_name)
        solver_options = SolverOptions(**options)
        result = solver_instance.solve(model, solver_options)

        solution_dict = self.format_solution(model, result, config)
        return OptimizationResult.from_solution_dict(solution_dict)

    # ------------------------------------------------------------------
    # Scipy fast path
    # ------------------------------------------------------------------

    def _solve_scipy(
        self, config: PortfolioConfig, options: dict[str, Any]
    ) -> OptimizationResult | None:
        """Solve via scipy.optimize.minimize for supported objectives.

        Returns None for objectives that need the full model (CVaR, CDaR,
        semivariance, BL, momentum, factor).
        """
        from scipy.optimize import minimize as scipy_minimize

        objective = config.objective
        er, symbols = _to_numpy(config.data.expected_returns)
        cov, _ = _to_numpy(config.data.covariance_matrix)
        n = len(er)
        if symbols is None:
            symbols = config.data.symbols or [f"Asset{i}" for i in range(n)]

        min_w, max_w = config.weight_bounds.min, config.weight_bounds.max
        bounds = [(min_w, max_w)] * n
        if config.per_asset_bounds is not None:
            for sym, (lo, hi) in config.per_asset_bounds.bounds.items():
                if sym in symbols:
                    bounds[symbols.index(sym)] = (lo, hi)

        constraints = [{"type": "eq", "fun": lambda w: np.sum(w) - 1.0}]

        if config.turnover is not None:
            cw = config.turnover.current_weights
            current = (
                np.array([cw.get(s, 0.0) for s in symbols])
                if isinstance(cw, dict)
                else np.array(cw)
            )
            mt = config.turnover.max_turnover
            constraints.append(
                {
                    "type": "ineq",
                    "fun": lambda w, c=current, m=mt: m - np.sum(np.abs(w - c)),
                }
            )

        if config.sector_constraints is not None:
            sc = config.sector_constraints
            for sector, cap in (sc.sector_caps or {}).items():
                mask = np.array(
                    [1.0 if sc.asset_sectors.get(s) == sector else 0.0 for s in symbols]
                )
                constraints.append(
                    {"type": "ineq", "fun": lambda w, m=mask, c=cap: c - m @ w}
                )
            for sector, floor in (sc.sector_mins or {}).items():
                mask = np.array(
                    [1.0 if sc.asset_sectors.get(s) == sector else 0.0 for s in symbols]
                )
                constraints.append(
                    {"type": "ineq", "fun": lambda w, m=mask, f=floor: m @ w - f}
                )

        if config.max_volatility is not None:
            mv = config.max_volatility
            constraints.append(
                {"type": "ineq", "fun": lambda w, c=cov, v=mv: v**2 - w @ c @ w}
            )

        rf = config.risk_free_rate

        # Scipy objective functions
        def _var(w):
            return w @ cov @ w

        def _neg_ret(w):
            return -(er @ w)

        def _neg_sharpe(w):
            vol = np.sqrt(max(w @ cov @ w, 1e-16))
            return -(er @ w - rf) / vol

        def _neg_utility(w):
            return -(er @ w - 0.5 * config.risk_aversion * w @ cov @ w)

        def _neg_div(w):
            vol = np.sqrt(max(w @ cov @ w, 1e-16))
            return -(w @ np.sqrt(np.diag(cov)) / vol)

        _map = {
            Objective.MIN_VOLATILITY: _var,
            Objective.MAX_SHARPE: _neg_sharpe,
            Objective.MAX_RETURN: _neg_ret,
            Objective.MAX_UTILITY: _neg_utility,
            Objective.MAX_DIVERSIFICATION: _neg_div,
            Objective.MAX_DIVERSIFICATION_INDEX: _neg_div,
        }

        if objective == Objective.EFFICIENT_RETURN:
            constraints.append(
                {"type": "eq", "fun": lambda w, t=config.target_return: er @ w - t}
            )
            obj_func = _var
        elif objective == Objective.EFFICIENT_RISK:
            constraints.append(
                {
                    "type": "eq",
                    "fun": lambda w, tv=config.target_volatility: w @ cov @ w - tv**2,
                }
            )
            obj_func = _neg_ret
        elif objective in (Objective.RISK_PARITY, Objective.EQUAL_RISK_CONTRIBUTION):

            def _rp(w):
                pv = w @ cov @ w
                if pv < 1e-16:
                    return 1e10
                rc = w * (cov @ w) / pv
                return np.sum((rc - 1.0 / n) ** 2)

            obj_func = _rp
        elif objective in (
            Objective.MAX_SHARPE_WITH_COSTS,
            Objective.MIN_VOLATILITY_WITH_COSTS,
        ):
            tc_rate = 0.001
            if config.transaction_costs:
                tc = config.transaction_costs.costs
                tc_rate = tc if isinstance(tc, (int, float)) else 0.001
            current = np.zeros(n)
            if config.turnover and config.turnover.current_weights:
                cw = config.turnover.current_weights
                current = (
                    np.array([cw.get(s, 0.0) for s in symbols])
                    if isinstance(cw, dict)
                    else np.array(cw)
                )
            elif config.transaction_costs and config.transaction_costs.current_weights:
                cw = config.transaction_costs.current_weights
                current = (
                    np.array([cw.get(s, 0.0) for s in symbols])
                    if isinstance(cw, dict)
                    else np.array(cw)
                )
            if objective == Objective.MAX_SHARPE_WITH_COSTS:

                def _obj(w):
                    costs = tc_rate * np.sum(np.abs(w - current))
                    vol = np.sqrt(max(w @ cov @ w, 1e-16))
                    return -(er @ w - costs - rf) / vol

                obj_func = _obj
            else:

                def _obj2(w):
                    return w @ cov @ w + tc_rate * np.sum(np.abs(w - current))

                obj_func = _obj2
        elif objective in _map:
            obj_func = _map[objective]
        else:
            return None  # needs full model (CVaR, CDaR, semi, BL, momentum, factor)

        w0 = np.full(n, 1.0 / n)
        try:
            result = scipy_minimize(
                obj_func,
                w0,
                method="SLSQP",
                bounds=bounds,
                constraints=constraints,
                options={
                    "maxiter": options.get("max_iter", 1000),
                    "ftol": options.get("tol", 1e-10),
                    "disp": options.get("verbose", False),
                },
            )
            if not result.success:
                return OptimizationResult.from_solution_dict(
                    {"status": "error", "message": f"scipy SLSQP: {result.message}"}
                )

            w = result.x.copy()
            w[np.abs(w) < 1e-10] = 0.0
            if np.sum(w) > 0:
                w /= np.sum(w)

            port_ret = float(er @ w)
            port_var = float(w @ cov @ w)
            port_vol = float(np.sqrt(max(port_var, 0)))
            sharpe = float((port_ret - rf) / port_vol) if port_vol > 0 else 0.0

            return OptimizationResult.from_solution_dict(
                {
                    "status": "optimal",
                    "objective_value": float(result.fun),
                    "weights": {symbols[i]: float(w[i]) for i in range(n)},
                    "portfolio_return": port_ret,
                    "portfolio_volatility": port_vol,
                    "portfolio_variance": port_var,
                    "sharpe_ratio": sharpe,
                }
            )
        except Exception as e:
            return OptimizationResult.from_solution_dict(
                {"status": "error", "message": f"scipy solver: {e}"}
            )

    # ------------------------------------------------------------------
    # Non-solver algorithms
    # ------------------------------------------------------------------

    def _solve_cla(self, config: PortfolioConfig) -> dict[str, Any]:
        er, symbols = _to_numpy(config.data.expected_returns)
        cov, _ = _to_numpy(config.data.covariance_matrix)
        if symbols is None:
            symbols = config.data.symbols or [f"Asset{i}" for i in range(len(er))]
        wb = (config.weight_bounds.min, config.weight_bounds.max)
        obj = config.objective

        if obj == Objective.CLA_MAX_SHARPE:
            w = _cla_optimize(er, cov, wb, "max_sharpe", config.risk_free_rate)
        else:
            w = _cla_optimize(er, cov, wb, "min_volatility")

        ret = float(w @ er)
        var = float(w @ cov @ w)
        vol = float(np.sqrt(var))
        sharpe = (ret - config.risk_free_rate) / vol if vol > 0 else 0.0
        return {
            "status": "optimal",
            "weights": {symbols[i]: float(w[i]) for i in range(len(symbols))},
            "portfolio_return": ret,
            "portfolio_volatility": vol,
            "portfolio_variance": var,
            "sharpe_ratio": sharpe,
            "objective_value": var if obj == Objective.CLA_MIN_VOLATILITY else -sharpe,
        }

    def _solve_hierarchical(self, config: PortfolioConfig) -> dict[str, Any]:
        er, symbols = _to_numpy(config.data.expected_returns)
        cov, _ = _to_numpy(config.data.covariance_matrix)
        if symbols is None:
            symbols = config.data.symbols or [f"Asset{i}" for i in range(len(er))]
        w = _hrp_optimize(cov)
        ret = float(w @ er)
        var = float(w @ cov @ w)
        vol = float(np.sqrt(var))
        sharpe = (ret - config.risk_free_rate) / vol if vol > 0 else 0.0
        return {
            "status": "optimal",
            "weights": {symbols[i]: float(w[i]) for i in range(len(symbols))},
            "portfolio_return": ret,
            "portfolio_volatility": vol,
            "portfolio_variance": var,
            "sharpe_ratio": sharpe,
            "objective_value": var,
        }

    # ------------------------------------------------------------------
    # Solution formatting (reads from AbstractModel)
    # ------------------------------------------------------------------

    def format_solution(
        self,
        model: AbstractModel,
        result: OptimizationResult,
        config: dict[str, Any] | PortfolioConfig,
    ) -> dict[str, Any]:
        """Format portfolio solution from AbstractModel."""
        if isinstance(config, dict):
            config = PortfolioConfig.from_dict(config)

        symbols = model.get_parameter("symbols")
        n = model.get_parameter("n_assets")
        objective_str = model.get_parameter("objective_name")

        # Extract weights from AbstractModel
        weights = {}
        weight_array = np.zeros(n)
        for i in range(n):
            var = model.get_variable(f"w_{i}")
            w = var.value if var and var.value is not None else 0.0
            weights[symbols[i]] = w
            weight_array[i] = w

        objective = (
            Objective(objective_str)
            if objective_str in [o.value for o in Objective]
            else None
        )

        # Select returns/cov for metric calculation
        if objective in (
            Objective.BL_MAX_SHARPE,
            Objective.BL_MIN_VOLATILITY,
            Objective.BL_QUADRATIC_UTILITY,
        ):
            er = model.get_parameter("bl_expected_returns")
            cov = model.get_parameter("bl_covariance")
        else:
            er = model.get_parameter("expected_returns")
            cov = model.get_parameter("covariance")

        # For scenario-based methods, use mean historical returns
        scenario_objectives = (
            Objective.MIN_CVAR,
            Objective.EFFICIENT_CVAR_RISK,
            Objective.EFFICIENT_CVAR_RETURN,
            Objective.MIN_CDAR,
            Objective.EFFICIENT_CDAR_RISK,
            Objective.EFFICIENT_CDAR_RETURN,
            Objective.MIN_SEMIVARIANCE,
            Objective.EFFICIENT_SEMIVARIANCE_RISK,
            Objective.EFFICIENT_SEMIVARIANCE_RETURN,
        )
        if objective in scenario_objectives:
            returns_arr = model.get_parameter("returns_array")
            if returns_arr is not None:
                port_ret = float(weight_array @ np.mean(returns_arr, axis=0))
            else:
                port_ret = float(weight_array @ er)
        else:
            port_ret = float(weight_array @ er)

        port_var = float(weight_array @ cov @ weight_array)
        port_vol = float(np.sqrt(max(port_var, 0)))
        sharpe = (port_ret - config.risk_free_rate) / port_vol if port_vol > 0 else 0.0

        obj_value = (
            result.objective_value
            if result and result.objective_value is not None
            else port_var
        )

        result_dict = {
            "status": result.status.value if result else "optimal",
            "weights": weights,
            "portfolio_return": port_ret,
            "portfolio_volatility": port_vol,
            "portfolio_variance": port_var,
            "sharpe_ratio": sharpe,
            "objective_value": obj_value,
        }

        # --- Method-specific metrics ---

        if objective in (
            Objective.MIN_CVAR,
            Objective.EFFICIENT_CVAR_RISK,
            Objective.EFFICIENT_CVAR_RETURN,
        ):
            ra = model.get_parameter("returns_array")
            alpha = model.get_parameter("confidence_level")
            cvar_val = _calculate_cvar(ra, weight_array, alpha)
            result_dict["cvar"] = -cvar_val

        if objective in (
            Objective.MIN_CDAR,
            Objective.EFFICIENT_CDAR_RISK,
            Objective.EFFICIENT_CDAR_RETURN,
        ):
            ra = model.get_parameter("returns_array")
            alpha = model.get_parameter("confidence_level")
            cdar_val = _calculate_cdar(ra, weight_array, alpha)
            result_dict["cdar"] = -cdar_val

        if objective in (
            Objective.MIN_SEMIVARIANCE,
            Objective.EFFICIENT_SEMIVARIANCE_RISK,
            Objective.EFFICIENT_SEMIVARIANCE_RETURN,
        ):
            ra = model.get_parameter("returns_array")
            bm = model.get_parameter("benchmark")
            semi = _calculate_semivariance(ra, weight_array, bm)
            result_dict["semivariance"] = semi
            result_dict["sortino_ratio"] = (
                (port_ret - config.risk_free_rate) / np.sqrt(semi) if semi > 0 else 0.0
            )

        if objective in (
            Objective.MAX_DIVERSIFICATION,
            Objective.MAX_DIVERSIFICATION_INDEX,
        ):
            result_dict["diversification_ratio"] = _calculate_diversification_ratio(
                weight_array, cov
            )
            result_dict["diversification_index"] = _calculate_diversification_index(
                weight_array, cov
            )

        if objective in (Objective.RISK_PARITY, Objective.EQUAL_RISK_CONTRIBUTION):
            rc = _calculate_risk_contribution(weight_array, cov)
            result_dict["risk_contributions"] = {
                symbols[i]: float(rc[i]) for i in range(n)
            }
            result_dict["risk_contribution_std"] = float(np.std(rc))

        if objective in (
            Objective.MAX_SHARPE_WITH_COSTS,
            Objective.MIN_VOLATILITY_WITH_COSTS,
        ):
            tc = config.transaction_costs
            if tc is None:
                tc_costs = {}
            else:
                tc_costs = tc.costs
            if isinstance(tc_costs, dict):
                cost_arr = np.array([tc_costs.get(symbols[i], 0.0) for i in range(n)])
            else:
                cost_arr, _ = _to_numpy(tc_costs)
                if len(cost_arr) != n:
                    cost_arr = np.full(
                        n,
                        float(tc_costs) if isinstance(tc_costs, (int, float)) else 0.0,
                    )

            has_turnover = model.get_parameter("has_turnover")
            cw_arr = model.get_parameter("current_weights_array")
            if has_turnover and cw_arr is not None:
                buy_w = np.array(
                    [(model.get_variable(f"buy_{i}").value or 0.0) for i in range(n)]
                )
                sell_w = np.array(
                    [(model.get_variable(f"sell_{i}").value or 0.0) for i in range(n)]
                )
                total_costs = float(np.sum((buy_w + sell_w) * cost_arr))
            elif cw_arr is not None:
                total_costs = float(np.sum(np.abs(weight_array - cw_arr) * cost_arr))
            else:
                total_costs = float(np.sum(weight_array * cost_arr))

            result_dict["transaction_costs"] = total_costs
            result_dict["net_return"] = port_ret - total_costs
            result_dict["net_sharpe_ratio"] = (
                (result_dict["net_return"] - config.risk_free_rate) / port_vol
                if port_vol > 0
                else 0.0
            )

        has_card = model.get_parameter("has_cardinality")
        if has_card:
            selected = sum(1 for i in range(n) if weight_array[i] > 1e-6)
            result_dict["num_assets"] = selected
            result_dict["cardinality"] = selected

        has_turnover = model.get_parameter("has_turnover")
        if has_turnover:
            buy_w = np.array(
                [(model.get_variable(f"buy_{i}").value or 0.0) for i in range(n)]
            )
            sell_w = np.array(
                [(model.get_variable(f"sell_{i}").value or 0.0) for i in range(n)]
            )
            result_dict["turnover"] = float(np.sum(buy_w + sell_w))

        factor_scores = model.get_parameter("factor_scores")
        if objective == Objective.FACTOR_BASED_SELECTION and factor_scores is not None:
            result_dict["weighted_factor_score"] = float(
                np.sum(weight_array * factor_scores)
            )
            result_dict["factor_scores"] = {
                symbols[i]: float(factor_scores[i]) for i in range(n)
            }

        return result_dict

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _get_returns_array(returns) -> np.ndarray:
        arr, _ = _to_numpy(returns)
        if arr.ndim == 1:
            arr = arr.reshape(1, -1)
        return arr
