"""
Rebalance configuration.

Defines :class:`RebalanceStrategy` and :class:`RebalanceConfig` for the
:class:`~pyoptima.templates.rebalance.RebalanceTemplate` that computes
optimal trade lists from current to target weights.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class RebalanceStrategy(Enum):
    """Rebalance algorithm selection."""

    MIN_DEVIATION = "min_deviation"
    """Minimise |w_new − w_target| subject to turnover / cost limits."""

    MIN_COST = "min_cost"
    """Minimise transaction costs subject to tracking error limit."""

    MIN_IMPACT = "min_impact"
    """Minimise market impact (uses cost model / ADV data)."""


@dataclass
class RebalanceConfig:
    """
    Configuration for portfolio rebalance optimisation.

    Args:
        strategy: Rebalance algorithm.
        current_weights: Symbol → current weight.
        target_weights: Symbol → target weight.
        symbols: Ordered asset list.
        max_turnover: Total one-way turnover cap (sum of |Δw_i|).
        max_tracking_error: Maximum TE vs target.
        transaction_costs: Per-asset cost in bps (or a scalar applied uniformly).
        adv: Average daily volume per symbol.
        max_participation: Max fraction of ADV per trade.
        covariance_matrix: For TE calculations.
        lot_size: Round-lot size (shares).
        prices: Per-symbol prices.
        portfolio_value: Total AUM for share conversion.

    Example::

        cfg = RebalanceConfig(
            strategy=RebalanceStrategy.MIN_COST,
            current_weights={"AAPL": 0.30, "MSFT": 0.20, "GOOGL": 0.50},
            target_weights={"AAPL": 0.25, "MSFT": 0.25, "GOOGL": 0.50},
            symbols=["AAPL", "MSFT", "GOOGL"],
            max_turnover=0.15,
            transaction_costs=0.001,
        )
    """

    strategy: RebalanceStrategy = RebalanceStrategy.MIN_DEVIATION
    current_weights: dict[str, float] = field(default_factory=dict)
    target_weights: dict[str, float] = field(default_factory=dict)
    symbols: list[str] = field(default_factory=list)

    # Constraints
    max_turnover: float | None = None
    max_tracking_error: float | None = None

    # Costs
    transaction_costs: dict[str, float] | float | None = None

    # Liquidity
    adv: dict[str, float] | None = None
    max_participation: float | None = None

    # Risk
    covariance_matrix: list[list[float]] | None = None

    # Round lots
    lot_size: int | None = None
    prices: dict[str, float] | None = None
    portfolio_value: float | None = None

    # Serialisation -------------------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "strategy": self.strategy.value,
            "current_weights": self.current_weights,
            "target_weights": self.target_weights,
            "symbols": self.symbols,
        }
        if self.max_turnover is not None:
            d["max_turnover"] = self.max_turnover
        if self.max_tracking_error is not None:
            d["max_tracking_error"] = self.max_tracking_error
        if self.transaction_costs is not None:
            d["transaction_costs"] = self.transaction_costs
        if self.adv is not None:
            d["adv"] = self.adv
        if self.max_participation is not None:
            d["max_participation"] = self.max_participation
        if self.covariance_matrix is not None:
            d["covariance_matrix"] = self.covariance_matrix
        if self.lot_size is not None:
            d["lot_size"] = self.lot_size
        if self.prices is not None:
            d["prices"] = self.prices
        if self.portfolio_value is not None:
            d["portfolio_value"] = self.portfolio_value
        return d

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> RebalanceConfig:
        strategy_raw = d.get("strategy", "min_deviation")
        try:
            strategy = RebalanceStrategy(strategy_raw)
        except ValueError:
            strategy = RebalanceStrategy.MIN_DEVIATION

        return cls(
            strategy=strategy,
            current_weights=d.get("current_weights", {}),
            target_weights=d.get("target_weights", {}),
            symbols=d.get("symbols", []),
            max_turnover=d.get("max_turnover"),
            max_tracking_error=d.get("max_tracking_error"),
            transaction_costs=d.get("transaction_costs"),
            adv=d.get("adv"),
            max_participation=d.get("max_participation"),
            covariance_matrix=d.get("covariance_matrix"),
            lot_size=d.get("lot_size"),
            prices=d.get("prices"),
            portfolio_value=d.get("portfolio_value"),
        )
