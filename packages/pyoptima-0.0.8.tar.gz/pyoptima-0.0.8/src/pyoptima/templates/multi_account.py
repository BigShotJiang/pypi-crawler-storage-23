"""
Multi-account template — allocate across accounts with per-account constraints.

Strategies
----------
- **independent** — Optimise each account separately.
- **joint** — Single optimisation with per-account constraints.
- **cascade** — Optimise aggregate first, then distribute.

Usage
-----
::

    result = template.solve({
        "strategy": "joint",
        "accounts": [
            {"name": "aggressive", "max_weight": 0.40},
            {"name": "conservative", "max_weight": 0.15, "max_volatility": 0.10},
        ],
        "expected_returns": [0.10, 0.12, 0.08],
        "covariance_matrix": [[...], ...],
        "symbols": ["AAPL", "MSFT", "GOOGL"],
        "objective": "min_volatility",
    })
"""

from __future__ import annotations

import math
from typing import Any

import numpy as np

from pyoptima.core.result import OptimizationResult
from pyoptima.model.core import (
    AbstractModel,
    Expression,
)
from pyoptima.templates.base import ProblemTemplate, TemplateInfo, TemplateRegistry
from pyoptima.templates.multi_account_config import (
    MultiAccountConfig,
)


@TemplateRegistry.register("multi_account")
class MultiAccountTemplate(ProblemTemplate):
    """
    Multi-account template.

    Registered as ``"multi_account"`` — available via ``run_from_config``
    and the REST API.
    """

    @property
    def info(self) -> TemplateInfo:
        return TemplateInfo(
            name="multi_account",
            description="Multi-account/mandate portfolio allocation",
            problem_type="QP",
            required_data=["accounts", "symbols"],
            optional_data=[
                "strategy",
                "expected_returns",
                "covariance_matrix",
                "objective",
                "account_values",
                "current_weights",
            ],
            default_solver="ipopt",
        )

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def validate_data(self, data: dict[str, Any]) -> None:
        self._require_keys(data, ["accounts", "symbols"])
        cfg = MultiAccountConfig.from_dict(data)

        if not cfg.accounts:
            raise ValueError("accounts must be non-empty")
        if not cfg.symbols:
            raise ValueError("symbols must be non-empty")

        names = [a.name for a in cfg.accounts]
        if len(set(names)) != len(names):
            raise ValueError("account names must be unique")

        if cfg.objective in ("min_volatility", "max_sharpe", "max_utility"):
            if cfg.covariance_matrix is None:
                raise ValueError(
                    f"covariance_matrix required for objective '{cfg.objective}'"
                )

    # ------------------------------------------------------------------
    # Model building
    # ------------------------------------------------------------------

    def build_model(self, data: dict[str, Any]) -> AbstractModel:
        cfg = MultiAccountConfig.from_dict(data)
        n_assets = len(cfg.symbols)
        n_accounts = len(cfg.accounts)

        model = AbstractModel(name="multi_account")
        model.add_set("assets", list(range(n_assets)))
        model.add_set("accounts", list(range(n_accounts)))
        model.add_parameter("config", cfg)

        # Decision variables: w[a][i] = weight of asset i in account a
        for a in range(n_accounts):
            acc = cfg.accounts[a]
            for i in range(n_assets):
                sym = cfg.symbols[i]
                # Excluded symbols get 0 bounds
                if acc.excluded_symbols and sym in acc.excluded_symbols:
                    model.add_continuous(f"w_{a}_{i}", lb=0.0, ub=0.0)
                else:
                    model.add_continuous(
                        f"w_{a}_{i}",
                        lb=acc.min_weight,
                        ub=acc.max_weight,
                    )

        # Each account's weights sum to 1
        for a in range(n_accounts):
            sum_expr = Expression()
            for i in range(n_assets):
                sum_expr.add_term(1.0, f"w_{a}_{i}")
            model.add_eq_constraint(f"sum_to_one_{a}", sum_expr, 1.0)

        # Per-account volatility constraints
        if cfg.covariance_matrix is not None:
            cov = np.array(cfg.covariance_matrix)
            for a in range(n_accounts):
                acc = cfg.accounts[a]
                if acc.max_volatility is not None:
                    vol_expr = Expression()
                    for i in range(n_assets):
                        for j in range(n_assets):
                            vol_expr.add_term(cov[i, j], f"w_{a}_{i}", f"w_{a}_{j}")
                    model.add_leq_constraint(
                        f"max_vol_{a}", vol_expr, acc.max_volatility**2
                    )

        # Per-account turnover constraints
        if cfg.current_weights is not None:
            for a in range(n_accounts):
                acc = cfg.accounts[a]
                if acc.max_turnover is not None and acc.name in cfg.current_weights:
                    curr = cfg.current_weights[acc.name]
                    # Auxiliary variables for |Δw|
                    for i in range(n_assets):
                        sym = cfg.symbols[i]
                        c_w = curr.get(sym, 0.0)
                        model.add_continuous(f"tp_{a}_{i}", lb=0.0, ub=1.0)
                        model.add_continuous(f"tm_{a}_{i}", lb=0.0, ub=1.0)

                        split_expr = Expression()
                        split_expr.add_term(1.0, f"w_{a}_{i}")
                        split_expr.add_term(-1.0, f"tp_{a}_{i}")
                        split_expr.add_term(1.0, f"tm_{a}_{i}")
                        model.add_eq_constraint(f"turn_split_{a}_{i}", split_expr, c_w)

                    turn_expr = Expression()
                    for i in range(n_assets):
                        turn_expr.add_term(1.0, f"tp_{a}_{i}")
                        turn_expr.add_term(1.0, f"tm_{a}_{i}")
                    model.add_leq_constraint(
                        f"max_turnover_{a}", turn_expr, acc.max_turnover
                    )

        # Build objective (aggregate across accounts)
        self._build_objective(model, cfg, n_assets, n_accounts)

        return model

    # ------------------------------------------------------------------
    # Objective
    # ------------------------------------------------------------------

    def _build_objective(
        self,
        model: AbstractModel,
        cfg: MultiAccountConfig,
        n_assets: int,
        n_accounts: int,
    ) -> None:
        """Build aggregate objective across all accounts."""
        obj = Expression()

        if cfg.objective == "min_volatility" and cfg.covariance_matrix is not None:
            cov = np.array(cfg.covariance_matrix)
            # Sum of per-account portfolio variance
            for a in range(n_accounts):
                weight = 1.0 / n_accounts
                for i in range(n_assets):
                    for j in range(n_assets):
                        obj.add_term(weight * cov[i, j], f"w_{a}_{i}", f"w_{a}_{j}")
            model.minimize(obj)

        elif cfg.objective == "max_return" and cfg.expected_returns is not None:
            er = cfg.expected_returns
            for a in range(n_accounts):
                weight = 1.0 / n_accounts
                for i in range(n_assets):
                    obj.add_term(-weight * er[i], f"w_{a}_{i}")
            model.minimize(obj)

        elif (
            cfg.objective == "max_utility"
            and cfg.expected_returns is not None
            and cfg.covariance_matrix is not None
        ):
            er = cfg.expected_returns
            cov = np.array(cfg.covariance_matrix)
            for a in range(n_accounts):
                weight = 1.0 / n_accounts
                for i in range(n_assets):
                    obj.add_term(-weight * er[i], f"w_{a}_{i}")
                for i in range(n_assets):
                    for j in range(n_assets):
                        obj.add_term(
                            weight * 0.5 * cov[i, j], f"w_{a}_{i}", f"w_{a}_{j}"
                        )
            model.minimize(obj)

        else:
            # Default: minimise deviation from target weights (if given)
            for a in range(n_accounts):
                acc = cfg.accounts[a]
                targets = acc.target_weights or {}
                for i in range(n_assets):
                    sym = cfg.symbols[i]
                    t = targets.get(sym, 1.0 / n_assets)
                    obj.add_term(1.0, f"w_{a}_{i}", f"w_{a}_{i}")
                    obj.add_term(-2.0 * t, f"w_{a}_{i}")
            model.minimize(obj)

    # ------------------------------------------------------------------
    # Solution formatting
    # ------------------------------------------------------------------

    def format_solution(
        self,
        model: AbstractModel,
        result: OptimizationResult,
        data: dict[str, Any],
    ) -> dict[str, Any]:
        cfg: MultiAccountConfig = model.get_parameter("config")
        n_assets = len(cfg.symbols)
        n_accounts = len(cfg.accounts)

        account_results: dict[str, dict[str, Any]] = {}

        for a in range(n_accounts):
            acc = cfg.accounts[a]
            weights: dict[str, float] = {}
            for i, sym in enumerate(cfg.symbols):
                var = model.get_variable(f"w_{a}_{i}")
                w = var.value if var and var.value is not None else 0.0
                weights[sym] = round(max(w, 0.0), 8)

            w_arr = np.array([weights[s] for s in cfg.symbols])

            acct_info: dict[str, Any] = {
                "weights": weights,
            }

            # Portfolio metrics
            if cfg.expected_returns is not None:
                er = np.array(cfg.expected_returns)
                acct_info["expected_return"] = round(float(er @ w_arr), 8)

            if cfg.covariance_matrix is not None:
                cov = np.array(cfg.covariance_matrix)
                var_val = float(w_arr @ cov @ w_arr)
                acct_info["volatility"] = round(math.sqrt(max(var_val, 0.0)), 8)

            account_results[acc.name] = acct_info

        return {
            "status": result.status.value if hasattr(result, "status") else "optimal",
            "objective_value": (
                result.objective_value if hasattr(result, "objective_value") else None
            ),
            "solution": {
                "accounts": account_results,
                "n_accounts": n_accounts,
                "n_assets": n_assets,
                "strategy": cfg.strategy.value,
                "objective": cfg.objective,
            },
            "problem_type": "QP",
            "num_variables": model.num_variables,
            "num_constraints": model.num_constraints,
        }
