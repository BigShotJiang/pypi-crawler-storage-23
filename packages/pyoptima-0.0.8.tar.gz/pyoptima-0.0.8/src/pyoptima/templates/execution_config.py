"""
Execution optimization configuration.

Defines :class:`ExecutionStrategy` and :class:`ExecutionConfig` used by the
:class:`~pyoptima.templates.execution.ExecutionTemplate` to split parent
orders into optimised child slices.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any


class ExecutionStrategy(Enum):
    """Execution algorithm selection."""

    TWAP = "twap"
    """Time-Weighted Average Price — uniform slices across the horizon."""

    VWAP = "vwap"
    """Volume-Weighted Average Price — slices proportional to volume profile."""

    IS = "implementation_shortfall"
    """Implementation Shortfall (Almgren-Chriss) — minimise expected cost + risk."""

    POV = "pov"
    """Percentage of Volume — constant participation rate each interval."""


@dataclass
class ExecutionConfig:
    """
    Configuration for a single-asset execution optimisation.

    Pass this to :meth:`ExecutionTemplate.solve` (via ``data`` dict) or
    create via :meth:`from_dict` from a YAML / JSON payload.

    Args:
        strategy: Execution algorithm.
        symbol: Ticker symbol being traded.
        total_quantity: Shares to execute (absolute, always > 0).
        side: ``"buy"`` or ``"sell"``.
        horizon_minutes: Time horizon to complete the order.
        interval_minutes: Length of each time bucket.
        adv: Average daily volume (shares).
        price: Current mid price.
        volatility: Daily volatility (decimal, e.g. 0.02 = 2 %).
        bid_ask_spread: Spread in basis points.
        volume_profile: Per-interval volume fractions (length = n_intervals).
        risk_aversion: Almgren-Chriss risk-aversion λ (IS only).
        temporary_impact: η — temporary impact coefficient.
        permanent_impact: γ — permanent impact coefficient.
        target_participation: POV target rate (fraction of interval volume).
        max_participation: Hard cap on participation per interval.

    Example::

        cfg = ExecutionConfig(
            strategy=ExecutionStrategy.VWAP,
            symbol="AAPL",
            total_quantity=50_000,
            side="buy",
            horizon_minutes=120,
            adv=75_000_000,
            price=185.50,
            volume_profile=[0.08, 0.06, 0.05, ...],
        )
    """

    strategy: ExecutionStrategy = ExecutionStrategy.VWAP
    symbol: str = ""
    total_quantity: float = 0.0
    side: str = "buy"
    horizon_minutes: int = 60
    interval_minutes: int = 5

    # Market data
    adv: float | None = None
    price: float | None = None
    volatility: float | None = None
    bid_ask_spread: float | None = None
    volume_profile: list[float] | None = None

    # Almgren-Chriss parameters (IS strategy)
    risk_aversion: float = 1e-6
    temporary_impact: float = 0.1
    permanent_impact: float = 0.01

    # POV parameters
    target_participation: float = 0.10
    max_participation: float = 0.25

    # Derived -------------------------------------------------------------------

    @property
    def n_intervals(self) -> int:
        """Number of time intervals in the schedule."""
        return max(1, self.horizon_minutes // self.interval_minutes)

    def interval_labels(self, start: str = "09:30") -> list[str]:
        """Generate time labels for each interval starting at *start*."""
        h, m = map(int, start.split(":"))
        labels: list[str] = []
        for i in range(self.n_intervals):
            total_min = h * 60 + m + i * self.interval_minutes
            labels.append(f"{total_min // 60:02d}:{total_min % 60:02d}")
        return labels

    # Serialisation -------------------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "strategy": self.strategy.value,
            "symbol": self.symbol,
            "total_quantity": self.total_quantity,
            "side": self.side,
            "horizon_minutes": self.horizon_minutes,
            "interval_minutes": self.interval_minutes,
        }
        if self.adv is not None:
            d["adv"] = self.adv
        if self.price is not None:
            d["price"] = self.price
        if self.volatility is not None:
            d["volatility"] = self.volatility
        if self.bid_ask_spread is not None:
            d["bid_ask_spread"] = self.bid_ask_spread
        if self.volume_profile is not None:
            d["volume_profile"] = self.volume_profile
        d["risk_aversion"] = self.risk_aversion
        d["temporary_impact"] = self.temporary_impact
        d["permanent_impact"] = self.permanent_impact
        d["target_participation"] = self.target_participation
        d["max_participation"] = self.max_participation
        return d

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> ExecutionConfig:
        strategy_raw = d.get("strategy", "vwap")
        try:
            strategy = ExecutionStrategy(strategy_raw)
        except ValueError:
            strategy = ExecutionStrategy.VWAP

        return cls(
            strategy=strategy,
            symbol=d.get("symbol", ""),
            total_quantity=float(d.get("total_quantity", 0)),
            side=d.get("side", "buy"),
            horizon_minutes=int(d.get("horizon_minutes", 60)),
            interval_minutes=int(d.get("interval_minutes", 5)),
            adv=d.get("adv"),
            price=d.get("price"),
            volatility=d.get("volatility"),
            bid_ask_spread=d.get("bid_ask_spread"),
            volume_profile=d.get("volume_profile"),
            risk_aversion=float(d.get("risk_aversion", 1e-6)),
            temporary_impact=float(d.get("temporary_impact", 0.1)),
            permanent_impact=float(d.get("permanent_impact", 0.01)),
            target_participation=float(d.get("target_participation", 0.10)),
            max_participation=float(d.get("max_participation", 0.25)),
        )
