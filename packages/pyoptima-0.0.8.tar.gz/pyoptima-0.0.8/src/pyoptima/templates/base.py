"""
Base class for problem templates.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any

from pyoptima.core.result import OptimizationResult
from pyoptima.model.core import AbstractModel
from pyoptima.solvers import SolverOptions, get_solver

_plugins_discovered = False


def _discover_plugin_templates() -> None:
    """Load templates from pyoptima.templates entry points (run once)."""
    global _plugins_discovered
    if _plugins_discovered:
        return
    _plugins_discovered = True
    try:
        from importlib.metadata import entry_points

        eps = entry_points(group="pyoptima.templates")
        for ep in eps:
            try:
                fn = ep.load()
                if callable(fn):
                    fn()
            except Exception:
                pass
    except Exception:
        pass


@dataclass
class TemplateInfo:
    """Information about a problem template."""

    name: str
    description: str
    problem_type: str
    required_data: list[str]
    optional_data: list[str]
    default_solver: str


class ProblemTemplate(ABC):
    """
    Base class for problem templates.

    Templates provide a simple interface for solving common optimization problems.
    Subclasses implement:
    - validate_data(): Validate input data
    - build_model(): Create AbstractModel from data
    - format_solution(): Format results
    """

    @property
    @abstractmethod
    def info(self) -> TemplateInfo:
        """Return template information."""
        pass

    @abstractmethod
    def validate_data(self, data: dict[str, Any]) -> None:
        """Validate input data. Raises ValueError if invalid."""
        pass

    @abstractmethod
    def build_model(self, data: dict[str, Any]) -> AbstractModel:
        """Build optimization model from data."""
        pass

    @abstractmethod
    def format_solution(
        self, model: AbstractModel, result: OptimizationResult, data: dict[str, Any]
    ) -> dict[str, Any]:
        """Format solution into problem-specific output."""
        pass

    def solve(
        self,
        data: dict[str, Any],
        solver: str | None = None,
        options: dict[str, Any] | None = None,
    ) -> OptimizationResult:
        """
        Solve the problem.

        Args:
            data: Problem data dictionary
            solver: Solver name (uses default if not specified)
            options: Solver options (time_limit, verbose, etc.)

        Returns:
            OptimizationResult
        """
        self.validate_data(data)
        model = self.build_model(data)

        solver_name = solver or self.info.default_solver
        solver_instance = get_solver(solver_name)
        solver_options = SolverOptions(**(options or {}))

        result = solver_instance.solve(model, solver_options)
        solution_dict = self.format_solution(model, result, data)
        return OptimizationResult.from_solution_dict(solution_dict)

    def _require_keys(self, data: dict[str, Any], keys: list[str]) -> None:
        """Validate that required keys are present."""
        missing = [k for k in keys if k not in data]
        if missing:
            available = list(data.keys())
            suggestions = []
            for key in missing:
                # Try to find similar keys
                similar = [
                    k
                    for k in available
                    if key.lower() in k.lower() or k.lower() in key.lower()
                ]
                if similar:
                    suggestions.append(f"  '{key}' - did you mean: {similar}")

            msg = f"Missing required data fields: {missing}"
            if suggestions:
                msg += "\n\nSuggestions:\n" + "\n".join(suggestions)
            msg += f"\n\nAvailable fields: {available if available else '(none)'}"
            msg += f"\nRequired fields: {keys}"
            raise ValueError(msg)


# Template registry
class TemplateRegistry:
    """Registry for problem templates."""

    _templates: dict[str, type[ProblemTemplate]] = {}

    @classmethod
    def register(cls, name: str):
        """Decorator to register a template."""

        def decorator(template_cls: type[ProblemTemplate]):
            cls._templates[name.lower()] = template_cls
            return template_cls

        return decorator

    @classmethod
    def get(cls, name: str) -> ProblemTemplate:
        """Get a template instance by name."""
        _discover_plugin_templates()
        name_lower = name.lower()
        if name_lower not in cls._templates:
            available = sorted(cls._templates.keys())

            # Find similar template names
            suggestions = []
            for template_name in available:
                if name_lower in template_name or template_name in name_lower:
                    suggestions.append(template_name)
                elif len(name_lower) >= 3 and any(
                    name_lower[:i] in template_name
                    for i in range(3, len(name_lower) + 1)
                ):
                    suggestions.append(template_name)

            msg = f"Template '{name}' not found."
            if suggestions:
                msg += "\n\nDid you mean one of these?\n  " + "\n  ".join(
                    suggestions[:5]
                )
            msg += f"\n\nAvailable templates: {', '.join(available)}"
            msg += "\n\nUse list_templates() to see all available templates."
            raise ValueError(msg)
        return cls._templates[name_lower]()

    @classmethod
    def list_templates(cls) -> list[str]:
        """List all registered templates."""
        _discover_plugin_templates()
        return sorted(cls._templates.keys())


def get_template(name: str) -> ProblemTemplate:
    """
    Get a problem template by name.

    Args:
        name: Template name (case-insensitive)

    Returns:
        ProblemTemplate instance

    Examples:
        >>> knapsack = get_template("knapsack")
        >>> lp = get_template("lp")
    """
    return TemplateRegistry.get(name)
