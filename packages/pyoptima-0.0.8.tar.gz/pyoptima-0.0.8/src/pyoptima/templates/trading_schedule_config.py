"""
Trading schedule configuration.

Defines :class:`TradingTask` and :class:`TradingScheduleConfig` for the
:class:`~pyoptima.templates.trading_schedule.TradingScheduleTemplate` that
schedules trading tasks across time windows.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class ScheduleStrategy(Enum):
    """Trading schedule algorithm selection."""

    FIXED = "fixed"
    """Run tasks at fixed, predetermined times."""

    ADAPTIVE = "adaptive"
    """Optimise timing based on volume / volatility windows."""

    PRIORITY = "priority"
    """Schedule by priority within time constraints."""


@dataclass
class TradingTask:
    """
    A single trading task to be scheduled.

    Args:
        name: Unique task identifier.
        duration_minutes: How long the task takes.
        priority: Higher = more urgent (used by priority strategy).
        earliest: Earliest start time (HH:MM).
        latest: Latest end time (HH:MM).
        depends_on: Tasks that must complete first.
        prefer_high_volume: Whether this task prefers high-volume windows.

    Example::

        task = TradingTask(
            name="rebalance_equity",
            duration_minutes=30,
            priority=2,
            earliest="09:30",
            latest="15:30",
        )
    """

    name: str = ""
    duration_minutes: int = 10
    priority: int = 1
    earliest: str | None = None
    latest: str | None = None
    depends_on: list[str] | None = None
    prefer_high_volume: bool = True

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "name": self.name,
            "duration_minutes": self.duration_minutes,
            "priority": self.priority,
            "prefer_high_volume": self.prefer_high_volume,
        }
        if self.earliest is not None:
            d["earliest"] = self.earliest
        if self.latest is not None:
            d["latest"] = self.latest
        if self.depends_on is not None:
            d["depends_on"] = self.depends_on
        return d

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> TradingTask:
        return cls(
            name=d.get("name", ""),
            duration_minutes=int(d.get("duration_minutes", 10)),
            priority=int(d.get("priority", 1)),
            earliest=d.get("earliest"),
            latest=d.get("latest"),
            depends_on=d.get("depends_on"),
            prefer_high_volume=d.get("prefer_high_volume", True),
        )


@dataclass
class TradingScheduleConfig:
    """
    Configuration for trading schedule optimisation.

    Args:
        strategy: Scheduling algorithm.
        tasks: Tasks to schedule.
        session_start: Trading session start (HH:MM).
        session_end: Trading session end (HH:MM).
        volume_profile: Per-interval volume fractions (for adaptive).
        volatility_profile: Per-interval volatility (for adaptive).
        interval_minutes: Length of scheduling time slots.

    Example::

        cfg = TradingScheduleConfig(
            strategy=ScheduleStrategy.PRIORITY,
            tasks=[
                TradingTask(name="rebalance", duration_minutes=30, priority=2),
                TradingTask(name="execution", duration_minutes=60, priority=1),
            ],
            session_start="09:30",
            session_end="16:00",
        )
    """

    strategy: ScheduleStrategy = ScheduleStrategy.PRIORITY
    tasks: list[TradingTask] = field(default_factory=list)
    session_start: str = "09:30"
    session_end: str = "16:00"
    volume_profile: list[float] | None = None
    volatility_profile: list[float] | None = None
    interval_minutes: int = 5

    @property
    def n_slots(self) -> int:
        """Number of time slots in the session."""
        sh, sm = map(int, self.session_start.split(":"))
        eh, em = map(int, self.session_end.split(":"))
        total_minutes = (eh * 60 + em) - (sh * 60 + sm)
        return max(1, total_minutes // self.interval_minutes)

    def slot_labels(self) -> list[str]:
        """Time labels for each slot."""
        sh, sm = map(int, self.session_start.split(":"))
        labels: list[str] = []
        for s in range(self.n_slots):
            total_min = sh * 60 + sm + s * self.interval_minutes
            labels.append(f"{total_min // 60:02d}:{total_min % 60:02d}")
        return labels

    def to_dict(self) -> dict[str, Any]:
        return {
            "strategy": self.strategy.value,
            "tasks": [t.to_dict() for t in self.tasks],
            "session_start": self.session_start,
            "session_end": self.session_end,
            "volume_profile": self.volume_profile,
            "volatility_profile": self.volatility_profile,
            "interval_minutes": self.interval_minutes,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> TradingScheduleConfig:
        strategy_raw = d.get("strategy", "priority")
        try:
            strategy = ScheduleStrategy(strategy_raw)
        except ValueError:
            strategy = ScheduleStrategy.PRIORITY

        tasks = [
            TradingTask.from_dict(t) if isinstance(t, dict) else t
            for t in d.get("tasks", [])
        ]

        return cls(
            strategy=strategy,
            tasks=tasks,
            session_start=d.get("session_start", "09:30"),
            session_end=d.get("session_end", "16:00"),
            volume_profile=d.get("volume_profile"),
            volatility_profile=d.get("volatility_profile"),
            interval_minutes=int(d.get("interval_minutes", 5)),
        )
