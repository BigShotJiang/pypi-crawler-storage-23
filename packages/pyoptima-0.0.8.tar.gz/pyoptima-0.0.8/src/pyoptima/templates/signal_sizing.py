"""
Signal sizing template — alpha signals to optimal position sizes.

Given a set of alpha scores and a risk model, compute optimal portfolio
weights that maximise expected return for a given risk budget.

Strategies
----------
- **mean_risk** — Max α'w − λ/2 × w'Σw (Markowitz-style).
- **equal_risk** — Inverse-volatility weighting.
- **kelly** — Kelly criterion (full or fractional).
- **fixed_risk** — Scale to a target portfolio volatility.

Usage
-----
::

    result = template.solve({
        "strategy": "mean_risk",
        "signals": {"AAPL": 0.02, "GOOGL": -0.01, "MSFT": 0.015},
        "symbols": ["AAPL", "GOOGL", "MSFT"],
        "covariance_matrix": [[0.04, 0.01, 0.02], ...],
        "risk_aversion": 2.0,
        "max_gross_exposure": 1.0,
    })
"""

from __future__ import annotations

import math
from typing import Any

import numpy as np

from pyoptima.core.result import OptimizationResult
from pyoptima.model.core import (
    AbstractModel,
    Expression,
)
from pyoptima.templates.base import ProblemTemplate, TemplateInfo, TemplateRegistry
from pyoptima.templates.signal_sizing_config import SignalSizingConfig, SizingStrategy


@TemplateRegistry.register("signal_sizing")
class SignalSizingTemplate(ProblemTemplate):
    """
    Signal sizing template.

    Registered as ``"signal_sizing"`` — available via ``run_from_config``
    and the REST API.
    """

    @property
    def info(self) -> TemplateInfo:
        return TemplateInfo(
            name="signal_sizing",
            description="Convert alpha signals to optimal position sizes",
            problem_type="QP",
            required_data=["signals", "symbols"],
            optional_data=[
                "strategy",
                "covariance_matrix",
                "risk_aversion",
                "max_position",
                "max_gross_exposure",
                "max_net_exposure",
                "max_notional",
                "target_volatility",
                "prices",
            ],
            default_solver="ipopt",
        )

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def validate_data(self, data: dict[str, Any]) -> None:
        self._require_keys(data, ["signals", "symbols"])
        cfg = SignalSizingConfig.from_dict(data)

        if not cfg.signals:
            raise ValueError("signals must be non-empty")
        if not cfg.symbols:
            raise ValueError("symbols must be non-empty")

        # Risk-based strategies need covariance
        if cfg.strategy in (
            SizingStrategy.MEAN_RISK,
            SizingStrategy.KELLY,
            SizingStrategy.FIXED_RISK,
        ):
            if cfg.covariance_matrix is None:
                raise ValueError(
                    f"covariance_matrix required for {cfg.strategy.value} strategy"
                )

        if cfg.strategy == SizingStrategy.FIXED_RISK:
            if cfg.target_volatility is None:
                raise ValueError("target_volatility required for fixed_risk strategy")

    # ------------------------------------------------------------------
    # Model building
    # ------------------------------------------------------------------

    def build_model(self, data: dict[str, Any]) -> AbstractModel:
        cfg = SignalSizingConfig.from_dict(data)
        n = len(cfg.symbols)

        model = AbstractModel(name="signal_sizing")
        model.add_set("assets", list(range(n)))
        model.add_parameter("config", cfg)

        # Decision variables: weights (can be negative for short positions)
        max_pos = cfg.max_position or 1.0
        for i in range(n):
            model.add_continuous(f"w_{i}", lb=-max_pos, ub=max_pos)

        # Gross exposure constraint: Σ |w_i| ≤ max_gross_exposure
        # Linearise with auxiliary variables: w_i = w_plus_i - w_minus_i
        if cfg.max_gross_exposure is not None:
            for i in range(n):
                model.add_continuous(f"w_plus_{i}", lb=0.0, ub=max_pos)
                model.add_continuous(f"w_minus_{i}", lb=0.0, ub=max_pos)

                # w_i = w_plus_i - w_minus_i
                split_expr = Expression()
                split_expr.add_term(1.0, f"w_{i}")
                split_expr.add_term(-1.0, f"w_plus_{i}")
                split_expr.add_term(1.0, f"w_minus_{i}")
                model.add_eq_constraint(f"split_{i}", split_expr, 0.0)

            # Gross: Σ (w_plus_i + w_minus_i) ≤ max_gross
            gross_expr = Expression()
            for i in range(n):
                gross_expr.add_term(1.0, f"w_plus_{i}")
                gross_expr.add_term(1.0, f"w_minus_{i}")
            model.add_leq_constraint(
                "max_gross_exposure", gross_expr, cfg.max_gross_exposure
            )

        # Net exposure constraint: |Σ w_i| ≤ max_net
        if cfg.max_net_exposure is not None:
            net_expr_upper = Expression()
            net_expr_lower = Expression()
            for i in range(n):
                net_expr_upper.add_term(1.0, f"w_{i}")
                net_expr_lower.add_term(-1.0, f"w_{i}")
            model.add_leq_constraint(
                "max_net_upper", net_expr_upper, cfg.max_net_exposure
            )
            model.add_leq_constraint(
                "max_net_lower", net_expr_lower, cfg.max_net_exposure
            )

        # Build objective
        if cfg.strategy == SizingStrategy.MEAN_RISK:
            self._build_mean_risk_objective(model, cfg, n)
        elif cfg.strategy == SizingStrategy.EQUAL_RISK:
            self._build_equal_risk_objective(model, cfg, n)
        elif cfg.strategy == SizingStrategy.KELLY:
            self._build_kelly_objective(model, cfg, n)
        elif cfg.strategy == SizingStrategy.FIXED_RISK:
            self._build_fixed_risk_objective(model, cfg, n)

        return model

    # ------------------------------------------------------------------
    # Strategy-specific objectives
    # ------------------------------------------------------------------

    def _build_mean_risk_objective(
        self, model: AbstractModel, cfg: SignalSizingConfig, n: int
    ) -> None:
        """Max α'w − λ/2 × w'Σw → Min −α'w + λ/2 × w'Σw."""
        alphas = [cfg.signals.get(s, 0.0) for s in cfg.symbols]
        cov = np.array(cfg.covariance_matrix)
        lam = cfg.risk_aversion

        obj = Expression()
        # Linear: −α_i × w_i
        for i in range(n):
            obj.add_term(-alphas[i], f"w_{i}")
        # Quadratic: λ/2 × Σ_ij × w_i × w_j
        for i in range(n):
            for j in range(n):
                obj.add_term(lam / 2.0 * cov[i, j], f"w_{i}", f"w_{j}")
        model.minimize(obj)

    def _build_equal_risk_objective(
        self, model: AbstractModel, cfg: SignalSizingConfig, n: int
    ) -> None:
        """Minimise deviation from inverse-vol weighted targets.

        target_i = sign(signal_i) × (1/σ_i) / Σ(1/σ_j)
        Then minimise Σ (w_i - target_i)².
        """
        if cfg.covariance_matrix is not None:
            cov = np.array(cfg.covariance_matrix)
            vols = np.sqrt(np.diag(cov))
        else:
            vols = np.ones(n)

        inv_vols = np.where(vols > 0, 1.0 / vols, 0.0)
        total_inv_vol = inv_vols.sum() or 1.0

        targets = []
        for i, sym in enumerate(cfg.symbols):
            signal = cfg.signals.get(sym, 0.0)
            sign = 1.0 if signal >= 0 else -1.0
            targets.append(sign * inv_vols[i] / total_inv_vol)

        obj = Expression()
        for i in range(n):
            obj.add_term(1.0, f"w_{i}", f"w_{i}")
            obj.add_term(-2.0 * targets[i], f"w_{i}")
        model.minimize(obj)

    def _build_kelly_objective(
        self, model: AbstractModel, cfg: SignalSizingConfig, n: int
    ) -> None:
        """Kelly criterion ≈ mean_risk with λ = 1 (full Kelly).

        Often fractional Kelly (λ = 2) is used in practice.
        """
        # Full Kelly is equivalent to mean-risk with λ=1
        cfg_copy = SignalSizingConfig(
            strategy=SizingStrategy.MEAN_RISK,
            signals=cfg.signals,
            symbols=cfg.symbols,
            covariance_matrix=cfg.covariance_matrix,
            risk_aversion=1.0,  # full Kelly
        )
        alphas = [cfg_copy.signals.get(s, 0.0) for s in cfg_copy.symbols]
        cov = np.array(cfg_copy.covariance_matrix)

        obj = Expression()
        for i in range(n):
            obj.add_term(-alphas[i], f"w_{i}")
        for i in range(n):
            for j in range(n):
                obj.add_term(0.5 * cov[i, j], f"w_{i}", f"w_{j}")
        model.minimize(obj)

    def _build_fixed_risk_objective(
        self, model: AbstractModel, cfg: SignalSizingConfig, n: int
    ) -> None:
        """Maximise expected return subject to σ_p ≤ target_volatility.

        Min −α'w  s.t. w'Σw ≤ σ²_target.
        """
        alphas = [cfg.signals.get(s, 0.0) for s in cfg.symbols]
        cov = np.array(cfg.covariance_matrix)
        target_var = cfg.target_volatility**2 if cfg.target_volatility else 1.0

        # Objective: maximise alpha → minimise −α'w
        obj = Expression()
        for i in range(n):
            obj.add_term(-alphas[i], f"w_{i}")
        model.minimize(obj)

        # Quadratic risk constraint: w'Σw ≤ target_var
        # Linearise as: approximate with penalty or add as quadratic constraint
        # For solvers supporting QP constraints, add directly
        risk_expr = Expression()
        for i in range(n):
            for j in range(n):
                risk_expr.add_term(cov[i, j], f"w_{i}", f"w_{j}")
        model.add_leq_constraint("risk_budget", risk_expr, target_var)

    # ------------------------------------------------------------------
    # Solution formatting
    # ------------------------------------------------------------------

    def format_solution(
        self,
        model: AbstractModel,
        result: OptimizationResult,
        data: dict[str, Any],
    ) -> dict[str, Any]:
        cfg: SignalSizingConfig = model.get_parameter("config")
        n = len(cfg.symbols)

        # Extract weights
        positions: dict[str, float] = {}
        for i, sym in enumerate(cfg.symbols):
            var = model.get_variable(f"w_{i}")
            w = var.value if var and var.value is not None else 0.0
            positions[sym] = round(w, 8)

        # Compute portfolio metrics
        weights_arr = np.array([positions[s] for s in cfg.symbols])
        gross_exposure = float(np.sum(np.abs(weights_arr)))
        net_exposure = float(np.sum(weights_arr))

        # Expected return
        alphas = np.array([cfg.signals.get(s, 0.0) for s in cfg.symbols])
        expected_return = float(alphas @ weights_arr)

        # Expected risk
        expected_risk = 0.0
        if cfg.covariance_matrix is not None:
            cov = np.array(cfg.covariance_matrix)
            var = float(weights_arr @ cov @ weights_arr)
            expected_risk = math.sqrt(max(var, 0.0))

        # Notional and shares
        notional: dict[str, float] = {}
        shares: dict[str, int] = {}
        if cfg.prices:
            portfolio_value = cfg.max_notional or 1_000_000
            for sym in cfg.symbols:
                price = cfg.prices.get(sym, 100.0)
                ntl = positions[sym] * portfolio_value
                notional[sym] = round(ntl, 2)
                shares[sym] = int(ntl / price) if price > 0 else 0

        solution: dict[str, Any] = {
            "positions": positions,
            "gross_exposure": round(gross_exposure, 8),
            "net_exposure": round(net_exposure, 8),
            "expected_return": round(expected_return, 8),
            "expected_risk": round(expected_risk, 8),
            "strategy": cfg.strategy.value,
        }
        if notional:
            solution["notional"] = notional
        if shares:
            solution["shares"] = shares

        return {
            "status": result.status.value if hasattr(result, "status") else "optimal",
            "objective_value": (
                result.objective_value if hasattr(result, "objective_value") else None
            ),
            "solution": solution,
            "problem_type": "QP",
            "num_variables": model.num_variables,
            "num_constraints": model.num_constraints,
        }
