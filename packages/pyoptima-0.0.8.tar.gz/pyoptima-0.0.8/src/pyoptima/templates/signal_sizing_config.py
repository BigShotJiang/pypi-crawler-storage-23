"""
Signal sizing configuration.

Defines :class:`SizingStrategy` and :class:`SignalSizingConfig` used by the
:class:`~pyoptima.templates.signal_sizing.SignalSizingTemplate` to convert
alpha signals into optimal position sizes.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class SizingStrategy(Enum):
    """Position sizing algorithm selection."""

    MEAN_RISK = "mean_risk"
    """Max α'w − λ/2 × w'Σw subject to exposure limits."""

    EQUAL_RISK = "equal_risk"
    """Size inversely proportional to volatility (risk parity-like)."""

    KELLY = "kelly"
    """Kelly criterion — maximise expected log growth."""

    FIXED_RISK = "fixed_risk"
    """Scale positions to hit a target portfolio volatility."""


@dataclass
class SignalSizingConfig:
    """
    Configuration for signal-to-position sizing.

    Args:
        strategy: Sizing algorithm.
        signals: Symbol → alpha / score mapping.
        symbols: Ordered asset list (determines matrix row order).
        covariance_matrix: n × n annualised covariance (list of lists).
        max_notional: Maximum total portfolio notional.
        max_position: Maximum weight per asset (absolute).
        max_gross_exposure: Sum of |w_i| upper bound.
        max_net_exposure: |Σ w_i| upper bound.
        risk_aversion: λ for mean_risk strategy.
        target_volatility: σ_target for fixed_risk strategy.
        prices: Symbol → price (for share conversion in results).

    Example::

        cfg = SignalSizingConfig(
            strategy=SizingStrategy.MEAN_RISK,
            signals={"AAPL": 0.02, "GOOGL": -0.01, "MSFT": 0.015},
            symbols=["AAPL", "GOOGL", "MSFT"],
            covariance_matrix=[[0.04, 0.01, 0.02], ...],
            risk_aversion=2.0,
            max_gross_exposure=1.0,
            max_position=0.30,
        )
    """

    strategy: SizingStrategy = SizingStrategy.MEAN_RISK
    signals: dict[str, float] = field(default_factory=dict)
    symbols: list[str] = field(default_factory=list)
    covariance_matrix: list[list[float]] | None = None

    # Limits
    max_notional: float | None = None
    max_position: float | None = None
    max_gross_exposure: float | None = None
    max_net_exposure: float | None = None
    risk_aversion: float = 1.0
    target_volatility: float | None = None

    # Prices (for share/notional conversion)
    prices: dict[str, float] | None = None

    # Serialisation -------------------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "strategy": self.strategy.value,
            "signals": self.signals,
            "symbols": self.symbols,
        }
        if self.covariance_matrix is not None:
            d["covariance_matrix"] = self.covariance_matrix
        if self.max_notional is not None:
            d["max_notional"] = self.max_notional
        if self.max_position is not None:
            d["max_position"] = self.max_position
        if self.max_gross_exposure is not None:
            d["max_gross_exposure"] = self.max_gross_exposure
        if self.max_net_exposure is not None:
            d["max_net_exposure"] = self.max_net_exposure
        d["risk_aversion"] = self.risk_aversion
        if self.target_volatility is not None:
            d["target_volatility"] = self.target_volatility
        if self.prices is not None:
            d["prices"] = self.prices
        return d

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> SignalSizingConfig:
        strategy_raw = d.get("strategy", "mean_risk")
        try:
            strategy = SizingStrategy(strategy_raw)
        except ValueError:
            strategy = SizingStrategy.MEAN_RISK

        return cls(
            strategy=strategy,
            signals=d.get("signals", {}),
            symbols=d.get("symbols", []),
            covariance_matrix=d.get("covariance_matrix"),
            max_notional=d.get("max_notional"),
            max_position=d.get("max_position"),
            max_gross_exposure=d.get("max_gross_exposure"),
            max_net_exposure=d.get("max_net_exposure"),
            risk_aversion=float(d.get("risk_aversion", 1.0)),
            target_volatility=d.get("target_volatility"),
            prices=d.get("prices"),
        )
