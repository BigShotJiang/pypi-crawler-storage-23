"""
Risk budget template — risk limit checking and optimal risk allocation.

Strategies
----------
- **check** — Verify current portfolio satisfies all limits (no optimisation).
- **reduce** — Minimise trades to bring portfolio within limits.
- **allocate** — Optimally allocate risk budget across assets.

Usage
-----
::

    result = template.solve({
        "strategy": "reduce",
        "current_weights": {"AAPL": 0.40, "GOOGL": 0.35, "MSFT": 0.25},
        "covariance_matrix": [[...], ...],
        "symbols": ["AAPL", "GOOGL", "MSFT"],
        "max_volatility": 0.15,
        "max_concentration": 0.35,
    })
"""

from __future__ import annotations

import math
from typing import Any

import numpy as np

from pyoptima.core.result import OptimizationResult
from pyoptima.model.core import (
    AbstractModel,
    Expression,
)
from pyoptima.templates.base import ProblemTemplate, TemplateInfo, TemplateRegistry
from pyoptima.templates.risk_budget_config import RiskBudgetConfig, RiskStrategy


@TemplateRegistry.register("risk_budget")
class RiskBudgetTemplate(ProblemTemplate):
    """
    Risk budget template.

    Registered as ``"risk_budget"`` — available via ``run_from_config``
    and the REST API.
    """

    @property
    def info(self) -> TemplateInfo:
        return TemplateInfo(
            name="risk_budget",
            description="Check / reduce / allocate portfolio risk budgets",
            problem_type="QP",
            required_data=["current_weights", "symbols"],
            optional_data=[
                "strategy",
                "covariance_matrix",
                "max_volatility",
                "max_cvar",
                "max_drawdown",
                "max_sector_weight",
                "max_concentration",
                "asset_sectors",
                "factor_loadings",
                "factor_names",
                "max_factor_exposure",
                "returns",
                "confidence_level",
            ],
            default_solver="ipopt",
        )

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def validate_data(self, data: dict[str, Any]) -> None:
        self._require_keys(data, ["current_weights", "symbols"])
        cfg = RiskBudgetConfig.from_dict(data)

        if not cfg.symbols:
            raise ValueError("symbols must be non-empty")
        if not cfg.current_weights:
            raise ValueError("current_weights must be non-empty")

        if cfg.strategy in (RiskStrategy.REDUCE, RiskStrategy.ALLOCATE):
            if cfg.covariance_matrix is None and cfg.max_volatility is not None:
                raise ValueError(
                    "covariance_matrix required when max_volatility is specified"
                )

    # ------------------------------------------------------------------
    # Model building
    # ------------------------------------------------------------------

    def build_model(self, data: dict[str, Any]) -> AbstractModel:
        cfg = RiskBudgetConfig.from_dict(data)
        n = len(cfg.symbols)

        model = AbstractModel(name="risk_budget")
        model.add_set("assets", list(range(n)))
        model.add_parameter("config", cfg)

        # For "check" strategy, we still build a trivial model
        # The actual check logic is in format_solution
        if cfg.strategy == RiskStrategy.CHECK:
            # No decision variables needed — build trivial model
            for i in range(n):
                sym = cfg.symbols[i]
                w = cfg.current_weights.get(sym, 0.0)
                model.add_continuous(f"w_{i}", lb=w, ub=w)
            obj = Expression()
            obj.add_constant(0.0)
            model.minimize(obj)
            return model

        # Decision variables: new weights
        for i in range(n):
            model.add_continuous(f"w_{i}", lb=0.0, ub=1.0)

        # Weights sum to 1
        sum_expr = Expression()
        for i in range(n):
            sum_expr.add_term(1.0, f"w_{i}")
        model.add_eq_constraint("sum_to_one", sum_expr, 1.0)

        # Concentration constraint
        if cfg.max_concentration is not None:
            for i in range(n):
                conc_expr = Expression()
                conc_expr.add_term(1.0, f"w_{i}")
                model.add_leq_constraint(
                    f"max_concentration_{i}", conc_expr, cfg.max_concentration
                )

        # Volatility constraint
        if cfg.max_volatility is not None and cfg.covariance_matrix is not None:
            cov = np.array(cfg.covariance_matrix)
            vol_expr = Expression()
            for i in range(n):
                for j in range(n):
                    vol_expr.add_term(cov[i, j], f"w_{i}", f"w_{j}")
            model.add_leq_constraint("max_volatility", vol_expr, cfg.max_volatility**2)

        # Sector weight constraints
        if cfg.max_sector_weight is not None and cfg.asset_sectors is not None:
            sectors: dict[str, list[int]] = {}
            for i, sym in enumerate(cfg.symbols):
                sector = cfg.asset_sectors.get(sym, "unknown")
                sectors.setdefault(sector, []).append(i)

            for sector, indices in sectors.items():
                if sector in cfg.max_sector_weight:
                    sec_expr = Expression()
                    for i in indices:
                        sec_expr.add_term(1.0, f"w_{i}")
                    model.add_leq_constraint(
                        f"sector_{sector}", sec_expr, cfg.max_sector_weight[sector]
                    )

        # Factor exposure constraints
        if (
            cfg.factor_loadings is not None
            and cfg.max_factor_exposure is not None
            and cfg.factor_names is not None
        ):
            B = np.array(cfg.factor_loadings)
            for k_idx, f_name in enumerate(cfg.factor_names):
                if f_name in cfg.max_factor_exposure:
                    limit = cfg.max_factor_exposure[f_name]
                    # B'w ≤ limit (upper)
                    upper_expr = Expression()
                    for i in range(n):
                        upper_expr.add_term(B[i, k_idx], f"w_{i}")
                    model.add_leq_constraint(
                        f"factor_upper_{f_name}", upper_expr, limit
                    )
                    # -B'w ≤ limit (lower → B'w ≥ -limit)
                    lower_expr = Expression()
                    for i in range(n):
                        lower_expr.add_term(-B[i, k_idx], f"w_{i}")
                    model.add_leq_constraint(
                        f"factor_lower_{f_name}", lower_expr, limit
                    )

        # Build objective
        if cfg.strategy == RiskStrategy.REDUCE:
            self._build_reduce_objective(model, cfg, n)
        elif cfg.strategy == RiskStrategy.ALLOCATE:
            self._build_allocate_objective(model, cfg, n)

        return model

    # ------------------------------------------------------------------
    # Strategy-specific objectives
    # ------------------------------------------------------------------

    def _build_reduce_objective(
        self, model: AbstractModel, cfg: RiskBudgetConfig, n: int
    ) -> None:
        """Minimise total weight change from current portfolio."""
        obj = Expression()
        for i in range(n):
            sym = cfg.symbols[i]
            curr = cfg.current_weights.get(sym, 0.0)
            # (w_i - curr)² = w_i² - 2·curr·w_i + curr² (constant ignored)
            obj.add_term(1.0, f"w_{i}", f"w_{i}")
            obj.add_term(-2.0 * curr, f"w_{i}")
        model.minimize(obj)

    def _build_allocate_objective(
        self, model: AbstractModel, cfg: RiskBudgetConfig, n: int
    ) -> None:
        """Risk parity-style allocation: equalise risk contributions.

        Approximate: min Σ_i (w_i × σ_i - σ_target/n)².
        """
        if cfg.covariance_matrix is not None:
            cov = np.array(cfg.covariance_matrix)
            vols = np.sqrt(np.diag(cov))
        else:
            vols = np.ones(n)

        target_risk = 1.0 / n
        obj = Expression()
        for i in range(n):
            # Penalise: (vol_i × w_i - target_risk)²
            # = vol_i² × w_i² - 2·vol_i·target_risk·w_i + constant
            obj.add_term(vols[i] ** 2, f"w_{i}", f"w_{i}")
            obj.add_term(-2.0 * vols[i] * target_risk, f"w_{i}")
        model.minimize(obj)

    # ------------------------------------------------------------------
    # Solution formatting
    # ------------------------------------------------------------------

    def format_solution(
        self,
        model: AbstractModel,
        result: OptimizationResult,
        data: dict[str, Any],
    ) -> dict[str, Any]:
        cfg: RiskBudgetConfig = model.get_parameter("config")
        n = len(cfg.symbols)

        # Extract weights
        new_weights: dict[str, float] = {}
        for i, sym in enumerate(cfg.symbols):
            var = model.get_variable(f"w_{i}")
            w = (
                var.value
                if var and var.value is not None
                else cfg.current_weights.get(sym, 0.0)
            )
            new_weights[sym] = round(max(w, 0.0), 8)

        w_arr = np.array([new_weights[s] for s in cfg.symbols])

        # Compute risk metrics
        violations: list[dict[str, Any]] = []
        metrics: dict[str, Any] = {}

        # Volatility
        if cfg.covariance_matrix is not None:
            cov = np.array(cfg.covariance_matrix)
            port_var = float(w_arr @ cov @ w_arr)
            port_vol = math.sqrt(max(port_var, 0.0))
            metrics["portfolio_volatility"] = round(port_vol, 8)
            if cfg.max_volatility is not None and port_vol > cfg.max_volatility:
                violations.append(
                    {
                        "limit": "max_volatility",
                        "value": round(port_vol, 8),
                        "cap": cfg.max_volatility,
                    }
                )

        # Concentration
        max_w = float(np.max(w_arr)) if len(w_arr) > 0 else 0
        metrics["max_weight"] = round(max_w, 8)
        if cfg.max_concentration is not None and max_w > cfg.max_concentration:
            violations.append(
                {
                    "limit": "max_concentration",
                    "value": round(max_w, 8),
                    "cap": cfg.max_concentration,
                }
            )

        # Sector weights
        if cfg.asset_sectors and cfg.max_sector_weight:
            sector_weights: dict[str, float] = {}
            for i, sym in enumerate(cfg.symbols):
                sector = cfg.asset_sectors.get(sym, "unknown")
                sector_weights[sector] = sector_weights.get(sector, 0.0) + w_arr[i]
            metrics["sector_weights"] = {
                s: round(v, 8) for s, v in sector_weights.items()
            }
            for sector, weight in sector_weights.items():
                cap = cfg.max_sector_weight.get(sector)
                if cap is not None and weight > cap:
                    violations.append(
                        {
                            "limit": f"max_sector_weight_{sector}",
                            "value": round(weight, 8),
                            "cap": cap,
                        }
                    )

        # Factor exposures
        if cfg.factor_loadings is not None and cfg.factor_names:
            B = np.array(cfg.factor_loadings)
            exposures = B.T @ w_arr
            factor_exp = {
                f: round(float(exposures[k]), 8) for k, f in enumerate(cfg.factor_names)
            }
            metrics["factor_exposures"] = factor_exp
            if cfg.max_factor_exposure:
                for f_name, exp_val in factor_exp.items():
                    cap = cfg.max_factor_exposure.get(f_name)
                    if cap is not None and abs(exp_val) > cap:
                        violations.append(
                            {
                                "limit": f"max_factor_exposure_{f_name}",
                                "value": round(abs(exp_val), 8),
                                "cap": cap,
                            }
                        )

        # Compute total change from current
        curr_arr = np.array([cfg.current_weights.get(s, 0.0) for s in cfg.symbols])
        total_change = float(np.sum(np.abs(w_arr - curr_arr)))

        all_satisfied = len(violations) == 0

        solution: dict[str, Any] = {
            "new_weights": new_weights,
            "all_limits_satisfied": all_satisfied,
            "violations": violations,
            "metrics": metrics,
            "total_weight_change": round(total_change, 8),
            "strategy": cfg.strategy.value,
        }

        return {
            "status": result.status.value if hasattr(result, "status") else "optimal",
            "objective_value": (
                result.objective_value if hasattr(result, "objective_value") else None
            ),
            "solution": solution,
            "problem_type": "QP",
            "num_variables": model.num_variables,
            "num_constraints": model.num_constraints,
        }
