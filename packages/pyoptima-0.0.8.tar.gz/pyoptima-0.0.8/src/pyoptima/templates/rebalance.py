"""
Rebalance template — optimal trade list from current to target weights.

Given current and target portfolio weights, computes the optimal set of
trades that brings the portfolio toward target, respecting turnover,
cost, liquidity, and tracking-error constraints.

Strategies
----------
- **min_deviation** — Minimise Σ |w_new − w_target| subject to limits.
- **min_cost** — Minimise total transaction cost subject to TE limit.
- **min_impact** — Minimise market impact (ADV-aware).

Usage
-----
::

    result = template.solve({
        "strategy": "min_cost",
        "current_weights": {"AAPL": 0.30, "MSFT": 0.20},
        "target_weights":  {"AAPL": 0.25, "MSFT": 0.25},
        "symbols": ["AAPL", "MSFT"],
        "max_turnover": 0.15,
        "transaction_costs": 0.001,
    })
"""

from __future__ import annotations

import math
from typing import Any

import numpy as np

from pyoptima.core.result import OptimizationResult
from pyoptima.model.core import (
    AbstractModel,
    Expression,
)
from pyoptima.templates.base import ProblemTemplate, TemplateInfo, TemplateRegistry
from pyoptima.templates.rebalance_config import RebalanceConfig, RebalanceStrategy


@TemplateRegistry.register("rebalance")
class RebalanceTemplate(ProblemTemplate):
    """
    Rebalance template.

    Registered as ``"rebalance"`` — available via ``run_from_config``
    and the REST API.
    """

    @property
    def info(self) -> TemplateInfo:
        return TemplateInfo(
            name="rebalance",
            description="Compute optimal trade list from current to target weights",
            problem_type="QP",
            required_data=["current_weights", "target_weights", "symbols"],
            optional_data=[
                "strategy",
                "max_turnover",
                "max_tracking_error",
                "transaction_costs",
                "adv",
                "max_participation",
                "covariance_matrix",
                "lot_size",
                "prices",
                "portfolio_value",
            ],
            default_solver="highs",
        )

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def validate_data(self, data: dict[str, Any]) -> None:
        self._require_keys(data, ["current_weights", "target_weights", "symbols"])
        cfg = RebalanceConfig.from_dict(data)

        if not cfg.symbols:
            raise ValueError("symbols must be non-empty")
        if not cfg.current_weights:
            raise ValueError("current_weights must be non-empty")
        if not cfg.target_weights:
            raise ValueError("target_weights must be non-empty")

        missing_current = set(cfg.symbols) - set(cfg.current_weights)
        if missing_current:
            raise ValueError(f"current_weights missing for: {missing_current}")

        if cfg.strategy == RebalanceStrategy.MIN_COST:
            if cfg.transaction_costs is None:
                raise ValueError("transaction_costs required for min_cost strategy")

        if cfg.strategy == RebalanceStrategy.MIN_IMPACT:
            if cfg.adv is None:
                raise ValueError("adv required for min_impact strategy")

    # ------------------------------------------------------------------
    # Model building
    # ------------------------------------------------------------------

    def build_model(self, data: dict[str, Any]) -> AbstractModel:
        cfg = RebalanceConfig.from_dict(data)
        n = len(cfg.symbols)

        model = AbstractModel(name="rebalance")
        model.add_set("assets", list(range(n)))
        model.add_parameter("config", cfg)

        # Decision variables: new weights
        for i in range(n):
            model.add_continuous(f"w_{i}", lb=0.0, ub=1.0)

        # Weights sum to 1
        sum_expr = Expression()
        for i in range(n):
            sum_expr.add_term(1.0, f"w_{i}")
        model.add_eq_constraint("sum_to_one", sum_expr, 1.0)

        # Auxiliary: trade_plus_i, trade_minus_i for |Δw_i|
        for i in range(n):
            sym = cfg.symbols[i]
            curr = cfg.current_weights.get(sym, 0.0)
            model.add_continuous(f"trade_plus_{i}", lb=0.0, ub=1.0)
            model.add_continuous(f"trade_minus_{i}", lb=0.0, ub=1.0)

            # w_i - curr = trade_plus_i - trade_minus_i
            split_expr = Expression()
            split_expr.add_term(1.0, f"w_{i}")
            split_expr.add_term(-1.0, f"trade_plus_{i}")
            split_expr.add_term(1.0, f"trade_minus_{i}")
            model.add_eq_constraint(f"trade_split_{i}", split_expr, curr)

        # Turnover constraint: Σ (trade_plus_i + trade_minus_i) ≤ max_turnover
        if cfg.max_turnover is not None:
            turnover_expr = Expression()
            for i in range(n):
                turnover_expr.add_term(1.0, f"trade_plus_{i}")
                turnover_expr.add_term(1.0, f"trade_minus_{i}")
            model.add_leq_constraint("max_turnover", turnover_expr, cfg.max_turnover)

        # Tracking error constraint vs target
        if cfg.max_tracking_error is not None and cfg.covariance_matrix is not None:
            cov = np.array(cfg.covariance_matrix)
            targets = [cfg.target_weights.get(s, 0.0) for s in cfg.symbols]
            # (w - target)' Σ (w - target) ≤ te²
            # Expand: w'Σw - 2·target'Σw + target'Σ·target ≤ te²
            te_expr = Expression()
            for i in range(n):
                for j in range(n):
                    te_expr.add_term(cov[i, j], f"w_{i}", f"w_{j}")
                    te_expr.add_term(-2.0 * targets[j] * cov[i, j], f"w_{i}")
            target_arr = np.array(targets)
            constant = float(target_arr @ cov @ target_arr)
            te_limit = cfg.max_tracking_error**2 - constant
            model.add_leq_constraint("max_tracking_error", te_expr, te_limit)

        # Max participation (liquidity)
        if cfg.adv is not None and cfg.max_participation is not None:
            pv = cfg.portfolio_value or 1.0
            for i in range(n):
                sym = cfg.symbols[i]
                asset_adv = cfg.adv.get(sym, float("inf"))
                price = (cfg.prices or {}).get(sym, 100.0)
                # Max trade in weight terms: max_part * adv * price / portfolio_value
                max_trade_weight = cfg.max_participation * asset_adv * price / pv
                if max_trade_weight < 1.0:
                    tp_expr = Expression()
                    tp_expr.add_term(1.0, f"trade_plus_{i}")
                    model.add_leq_constraint(
                        f"max_part_buy_{i}", tp_expr, max_trade_weight
                    )

                    tm_expr = Expression()
                    tm_expr.add_term(1.0, f"trade_minus_{i}")
                    model.add_leq_constraint(
                        f"max_part_sell_{i}", tm_expr, max_trade_weight
                    )

        # Build objective
        if cfg.strategy == RebalanceStrategy.MIN_DEVIATION:
            self._build_min_deviation_objective(model, cfg, n)
        elif cfg.strategy == RebalanceStrategy.MIN_COST:
            self._build_min_cost_objective(model, cfg, n)
        elif cfg.strategy == RebalanceStrategy.MIN_IMPACT:
            self._build_min_impact_objective(model, cfg, n)

        return model

    # ------------------------------------------------------------------
    # Strategy-specific objectives
    # ------------------------------------------------------------------

    def _build_min_deviation_objective(
        self, model: AbstractModel, cfg: RebalanceConfig, n: int
    ) -> None:
        """Min Σ (w_i - target_i)²."""
        targets = [cfg.target_weights.get(s, 0.0) for s in cfg.symbols]
        obj = Expression()
        for i in range(n):
            obj.add_term(1.0, f"w_{i}", f"w_{i}")
            obj.add_term(-2.0 * targets[i], f"w_{i}")
        model.minimize(obj)

    def _build_min_cost_objective(
        self, model: AbstractModel, cfg: RebalanceConfig, n: int
    ) -> None:
        """Min Σ cost_i × |Δw_i| = Σ cost_i × (trade_plus_i + trade_minus_i)."""
        obj = Expression()
        for i in range(n):
            sym = cfg.symbols[i]
            if isinstance(cfg.transaction_costs, dict):
                cost = cfg.transaction_costs.get(sym, 0.0)
            elif isinstance(cfg.transaction_costs, (int, float)):
                cost = float(cfg.transaction_costs)
            else:
                cost = 0.0
            obj.add_term(cost, f"trade_plus_{i}")
            obj.add_term(cost, f"trade_minus_{i}")
        model.minimize(obj)

    def _build_min_impact_objective(
        self, model: AbstractModel, cfg: RebalanceConfig, n: int
    ) -> None:
        """Min Σ impact(Δw_i) ≈ Σ (trade_plus_i + trade_minus_i)² / adv_i.

        ADV-weighted quadratic impact: cheaper to trade liquid names.
        """
        obj = Expression()
        pv = cfg.portfolio_value or 1.0
        for i in range(n):
            sym = cfg.symbols[i]
            asset_adv = (cfg.adv or {}).get(sym, 1.0)
            price = (cfg.prices or {}).get(sym, 100.0)
            # Weight: inverse of ADV-in-weight-terms
            adv_weight = asset_adv * price / pv if pv > 0 else 1.0
            impact_coeff = 1.0 / (adv_weight + 1e-12)

            # Quadratic on trade_plus and trade_minus
            obj.add_term(impact_coeff, f"trade_plus_{i}", f"trade_plus_{i}")
            obj.add_term(impact_coeff, f"trade_minus_{i}", f"trade_minus_{i}")
        model.minimize(obj)

    # ------------------------------------------------------------------
    # Solution formatting
    # ------------------------------------------------------------------

    def format_solution(
        self,
        model: AbstractModel,
        result: OptimizationResult,
        data: dict[str, Any],
    ) -> dict[str, Any]:
        cfg: RebalanceConfig = model.get_parameter("config")
        n = len(cfg.symbols)

        new_weights: dict[str, float] = {}
        trades: dict[str, dict[str, Any]] = {}
        total_turnover = 0.0
        total_cost_bps = 0.0

        for i, sym in enumerate(cfg.symbols):
            var = model.get_variable(f"w_{i}")
            w_new = var.value if var and var.value is not None else 0.0
            w_new = max(w_new, 0.0)
            w_curr = cfg.current_weights.get(sym, 0.0)
            w_target = cfg.target_weights.get(sym, 0.0)
            delta = w_new - w_curr

            new_weights[sym] = round(w_new, 8)

            direction = (
                "buy" if delta > 1e-10 else ("sell" if delta < -1e-10 else "hold")
            )
            trade_info: dict[str, Any] = {
                "direction": direction,
                "weight_delta": round(delta, 8),
            }

            # Share / notional conversion
            if cfg.prices and cfg.portfolio_value:
                price = cfg.prices.get(sym, 100.0)
                notional = delta * cfg.portfolio_value
                shares = int(notional / price) if price > 0 else 0
                trade_info["notional"] = round(notional, 2)
                trade_info["shares"] = shares

            trades[sym] = trade_info
            total_turnover += abs(delta)

            # Cost
            if cfg.transaction_costs is not None:
                if isinstance(cfg.transaction_costs, dict):
                    c = cfg.transaction_costs.get(sym, 0.0)
                else:
                    c = float(cfg.transaction_costs)
                total_cost_bps += c * abs(delta) * 10_000

        # Tracking error vs target
        te_vs_target = 0.0
        if cfg.covariance_matrix is not None:
            cov = np.array(cfg.covariance_matrix)
            w_arr = np.array([new_weights[s] for s in cfg.symbols])
            t_arr = np.array([cfg.target_weights.get(s, 0.0) for s in cfg.symbols])
            diff = w_arr - t_arr
            te_var = float(diff @ cov @ diff)
            te_vs_target = math.sqrt(max(te_var, 0.0))

        return {
            "status": result.status.value if hasattr(result, "status") else "optimal",
            "objective_value": (
                result.objective_value if hasattr(result, "objective_value") else None
            ),
            "solution": {
                "trades": trades,
                "new_weights": new_weights,
                "total_turnover": round(total_turnover, 8),
                "total_cost_bps": round(total_cost_bps, 4),
                "tracking_error_vs_target": round(te_vs_target, 8),
                "strategy": cfg.strategy.value,
            },
            "problem_type": "QP",
            "num_variables": model.num_variables,
            "num_constraints": model.num_constraints,
        }
