"""
Risk budget configuration.

Defines :class:`RiskStrategy` and :class:`RiskBudgetConfig` for the
:class:`~pyoptima.templates.risk_budget.RiskBudgetTemplate` that checks,
reduces, or allocates risk budgets across assets and factors.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class RiskStrategy(Enum):
    """Risk budget algorithm selection."""

    CHECK = "check"
    """Check if current portfolio satisfies all limits (no optimisation)."""

    REDUCE = "reduce"
    """Minimise trades needed to bring portfolio within limits."""

    ALLOCATE = "allocate"
    """Allocate risk budget optimally across assets/factors."""


@dataclass
class RiskBudgetConfig:
    """
    Configuration for risk budget optimisation.

    Args:
        strategy: Risk-budget algorithm.
        current_weights: Symbol → current weight.
        covariance_matrix: n × n annualised covariance.
        symbols: Ordered asset list.
        max_volatility: Portfolio volatility cap.
        max_cvar: CVaR cap (requires *returns*).
        max_drawdown: Max drawdown cap.
        max_sector_weight: Sector → max aggregate weight.
        max_concentration: Max single-asset weight.
        asset_sectors: Symbol → sector mapping.
        factor_loadings: n × k factor loading matrix.
        factor_names: Labels for the k factors.
        max_factor_exposure: Factor → max exposure cap.
        min_change: If True (default), minimise total trades.
        returns: Historical returns for CVaR.
        confidence_level: CVaR / VaR confidence level.

    Example::

        cfg = RiskBudgetConfig(
            strategy=RiskStrategy.REDUCE,
            current_weights={"AAPL": 0.40, "GOOGL": 0.35, "MSFT": 0.25},
            covariance_matrix=[[0.04, 0.01, 0.02], ...],
            symbols=["AAPL", "GOOGL", "MSFT"],
            max_volatility=0.15,
            max_concentration=0.35,
        )
    """

    strategy: RiskStrategy = RiskStrategy.REDUCE
    current_weights: dict[str, float] = field(default_factory=dict)
    covariance_matrix: list[list[float]] | None = None
    symbols: list[str] = field(default_factory=list)

    # Risk limits
    max_volatility: float | None = None
    max_cvar: float | None = None
    max_drawdown: float | None = None
    max_sector_weight: dict[str, float] | None = None
    max_concentration: float | None = None
    asset_sectors: dict[str, str] | None = None

    # Factor limits
    factor_loadings: list[list[float]] | None = None
    factor_names: list[str] | None = None
    max_factor_exposure: dict[str, float] | None = None

    # For reduce strategy
    min_change: bool = True
    returns: list[list[float]] | None = None
    confidence_level: float = 0.05

    # Serialisation -------------------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "strategy": self.strategy.value,
            "current_weights": self.current_weights,
            "symbols": self.symbols,
        }
        if self.covariance_matrix is not None:
            d["covariance_matrix"] = self.covariance_matrix
        if self.max_volatility is not None:
            d["max_volatility"] = self.max_volatility
        if self.max_cvar is not None:
            d["max_cvar"] = self.max_cvar
        if self.max_drawdown is not None:
            d["max_drawdown"] = self.max_drawdown
        if self.max_sector_weight is not None:
            d["max_sector_weight"] = self.max_sector_weight
        if self.max_concentration is not None:
            d["max_concentration"] = self.max_concentration
        if self.asset_sectors is not None:
            d["asset_sectors"] = self.asset_sectors
        if self.factor_loadings is not None:
            d["factor_loadings"] = self.factor_loadings
        if self.factor_names is not None:
            d["factor_names"] = self.factor_names
        if self.max_factor_exposure is not None:
            d["max_factor_exposure"] = self.max_factor_exposure
        d["min_change"] = self.min_change
        if self.returns is not None:
            d["returns"] = self.returns
        d["confidence_level"] = self.confidence_level
        return d

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> RiskBudgetConfig:
        strategy_raw = d.get("strategy", "reduce")
        try:
            strategy = RiskStrategy(strategy_raw)
        except ValueError:
            strategy = RiskStrategy.REDUCE

        return cls(
            strategy=strategy,
            current_weights=d.get("current_weights", {}),
            covariance_matrix=d.get("covariance_matrix"),
            symbols=d.get("symbols", []),
            max_volatility=d.get("max_volatility"),
            max_cvar=d.get("max_cvar"),
            max_drawdown=d.get("max_drawdown"),
            max_sector_weight=d.get("max_sector_weight"),
            max_concentration=d.get("max_concentration"),
            asset_sectors=d.get("asset_sectors"),
            factor_loadings=d.get("factor_loadings"),
            factor_names=d.get("factor_names"),
            max_factor_exposure=d.get("max_factor_exposure"),
            min_change=d.get("min_change", True),
            returns=d.get("returns"),
            confidence_level=float(d.get("confidence_level", 0.05)),
        )
