"""
Execution template — optimal order splitting.

Splits a parent order into child slices across time intervals to minimise
execution cost, market impact, or timing risk.

Strategies
----------
- **TWAP** — uniform time slices.
- **VWAP** — volume-weighted slices following an intraday profile.
- **IS** (Implementation Shortfall) — Almgren-Chriss optimal trajectory
  minimising expected cost + λ × risk.
- **POV** — constant percentage-of-volume participation.

Usage
-----
::

    from pyoptima.templates.execution import ExecutionTemplate

    template = ExecutionTemplate()
    result = template.solve({
        "strategy": "vwap",
        "symbol": "AAPL",
        "total_quantity": 50000,
        "side": "buy",
        "horizon_minutes": 120,
        "adv": 75_000_000,
        "volume_profile": [0.08, 0.06, 0.05, ...],
    })
    print(result.solution["schedule"])

Or via config::

    result = run_from_config("execution_vwap.yaml")
"""

from __future__ import annotations

import math
from typing import Any

import numpy as np

from pyoptima.core.result import OptimizationResult
from pyoptima.model.core import (
    AbstractModel,
    Expression,
)
from pyoptima.templates.base import ProblemTemplate, TemplateInfo, TemplateRegistry
from pyoptima.templates.execution_config import ExecutionConfig, ExecutionStrategy


@TemplateRegistry.register("execution")
class ExecutionTemplate(ProblemTemplate):
    """
    Execution optimisation template.

    Registered as ``"execution"`` in the template registry, so it is
    automatically available via ``run_from_config`` and the REST API.
    """

    @property
    def info(self) -> TemplateInfo:
        return TemplateInfo(
            name="execution",
            description="Optimal order splitting (TWAP, VWAP, IS, POV)",
            problem_type="QP",
            required_data=["strategy", "total_quantity", "side"],
            optional_data=[
                "symbol",
                "horizon_minutes",
                "interval_minutes",
                "adv",
                "price",
                "volatility",
                "bid_ask_spread",
                "volume_profile",
                "risk_aversion",
                "temporary_impact",
                "permanent_impact",
                "target_participation",
                "max_participation",
            ],
            default_solver="highs",
        )

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def validate_data(self, data: dict[str, Any]) -> None:
        self._require_keys(data, ["total_quantity", "side"])
        cfg = ExecutionConfig.from_dict(data)

        if cfg.total_quantity <= 0:
            raise ValueError("total_quantity must be positive")
        if cfg.side not in ("buy", "sell"):
            raise ValueError(f"side must be 'buy' or 'sell', got '{cfg.side}'")
        if cfg.horizon_minutes <= 0:
            raise ValueError("horizon_minutes must be positive")
        if cfg.interval_minutes <= 0:
            raise ValueError("interval_minutes must be positive")

        # Strategy-specific checks
        if cfg.strategy == ExecutionStrategy.VWAP and cfg.volume_profile is None:
            raise ValueError("volume_profile required for VWAP strategy")
        if cfg.strategy == ExecutionStrategy.IS:
            if cfg.adv is None:
                raise ValueError("adv required for IS strategy")
            if cfg.volatility is None:
                raise ValueError("volatility required for IS strategy")

    # ------------------------------------------------------------------
    # Model building
    # ------------------------------------------------------------------

    def build_model(self, data: dict[str, Any]) -> AbstractModel:
        cfg = ExecutionConfig.from_dict(data)
        n = cfg.n_intervals

        model = AbstractModel(name="execution")
        model.add_set("intervals", list(range(n)))
        model.add_parameter("config", cfg)

        # Decision variables: quantity in each interval
        for i in range(n):
            model.add_continuous(f"q_{i}", lb=0.0, ub=cfg.total_quantity)

        # Constraint: quantities sum to total
        sum_expr = Expression()
        for i in range(n):
            sum_expr.add_term(1.0, f"q_{i}")
        model.add_eq_constraint("total_quantity", sum_expr, cfg.total_quantity)

        # Max participation constraints (if ADV and profile available)
        if cfg.adv is not None and cfg.adv > 0:
            profile = self._get_normalized_profile(cfg)
            for i in range(n):
                interval_volume = cfg.adv * profile[i]
                max_qty = interval_volume * cfg.max_participation
                if max_qty > 0:
                    expr = Expression()
                    expr.add_term(1.0, f"q_{i}")
                    model.add_leq_constraint(f"max_participation_{i}", expr, max_qty)

        # Build objective based on strategy
        if cfg.strategy == ExecutionStrategy.TWAP:
            self._build_twap_objective(model, cfg, n)
        elif cfg.strategy == ExecutionStrategy.VWAP:
            self._build_vwap_objective(model, cfg, n)
        elif cfg.strategy == ExecutionStrategy.IS:
            self._build_is_objective(model, cfg, n)
        elif cfg.strategy == ExecutionStrategy.POV:
            self._build_pov_objective(model, cfg, n)

        return model

    # ------------------------------------------------------------------
    # Strategy-specific objectives
    # ------------------------------------------------------------------

    def _build_twap_objective(
        self, model: AbstractModel, cfg: ExecutionConfig, n: int
    ) -> None:
        """Minimise deviation from uniform schedule."""
        target = cfg.total_quantity / n
        # Minimise Σ (q_i - target)² = Σ q_i² - 2·target·Σ q_i + n·target²
        # Since Σ q_i is fixed, minimise Σ q_i²
        obj = Expression()
        for i in range(n):
            obj.add_term(1.0, f"q_{i}", f"q_{i}")
        model.minimize(obj)

    def _build_vwap_objective(
        self, model: AbstractModel, cfg: ExecutionConfig, n: int
    ) -> None:
        """Minimise deviation from volume-weighted schedule."""
        profile = self._get_normalized_profile(cfg)
        # Target: q_i = total_quantity × profile_i
        # Minimise Σ (q_i - total × profile_i)²
        # = Σ q_i² - 2·total·Σ profile_i·q_i + constant
        obj = Expression()
        for i in range(n):
            # Quadratic: +1 × q_i²
            obj.add_term(1.0, f"q_{i}", f"q_{i}")
            # Linear: -2 × total × profile_i × q_i
            obj.add_term(-2.0 * cfg.total_quantity * profile[i], f"q_{i}")
        model.minimize(obj)

    def _build_is_objective(
        self, model: AbstractModel, cfg: ExecutionConfig, n: int
    ) -> None:
        """Almgren-Chriss: minimise expected cost + λ × variance."""
        adv = cfg.adv or 1.0
        sigma = cfg.volatility or 0.02
        eta = cfg.temporary_impact
        gamma = cfg.permanent_impact
        lam = cfg.risk_aversion
        T = cfg.horizon_minutes / (6.5 * 60)  # fraction of trading day

        obj = Expression()
        for i in range(n):
            # Temporary impact cost (quadratic): η × σ × q_i² / (ADV × T/n)
            interval_days = T / n if n > 0 else T
            temp_coeff = eta * sigma / (adv * interval_days) if interval_days > 0 else 0
            obj.add_term(temp_coeff, f"q_{i}", f"q_{i}")

            # Permanent impact (linear): γ × σ × q_i / √ADV
            perm_coeff = gamma * sigma / math.sqrt(adv) if adv > 0 else 0
            obj.add_term(perm_coeff, f"q_{i}")

            # Risk penalty (quadratic on remaining inventory)
            # Simplified: λ × σ² × q_i² (per-interval risk)
            risk_coeff = lam * sigma * sigma
            obj.add_term(risk_coeff, f"q_{i}", f"q_{i}")

        model.minimize(obj)

    def _build_pov_objective(
        self, model: AbstractModel, cfg: ExecutionConfig, n: int
    ) -> None:
        """Minimise deviation from target participation rate."""
        if cfg.adv is None or cfg.adv <= 0:
            # Fall back to TWAP if no ADV
            self._build_twap_objective(model, cfg, n)
            return

        profile = self._get_normalized_profile(cfg)
        target_pov = cfg.target_participation

        # Target: q_i = target_pov × adv × profile_i
        obj = Expression()
        for i in range(n):
            interval_volume = cfg.adv * profile[i]
            target_qty = target_pov * interval_volume
            obj.add_term(1.0, f"q_{i}", f"q_{i}")
            obj.add_term(-2.0 * target_qty, f"q_{i}")
        model.minimize(obj)

    # ------------------------------------------------------------------
    # Solution formatting
    # ------------------------------------------------------------------

    def format_solution(
        self,
        model: AbstractModel,
        result: OptimizationResult,
        data: dict[str, Any],
    ) -> dict[str, Any]:
        cfg: ExecutionConfig = model.get_parameter("config")
        n = cfg.n_intervals
        labels = cfg.interval_labels()
        profile = self._get_normalized_profile(cfg)
        adv = cfg.adv or 0.0

        schedule: list[dict[str, Any]] = []
        total_qty = 0.0

        for i in range(n):
            var = model.get_variable(f"q_{i}")
            qty = var.value if var and var.value is not None else 0.0
            qty = max(qty, 0.0)

            interval_volume = adv * profile[i] if adv > 0 else 0
            participation = qty / interval_volume if interval_volume > 0 else 0

            schedule.append(
                {
                    "interval": i,
                    "time": labels[i] if i < len(labels) else f"t_{i}",
                    "quantity": round(qty),
                    "participation": round(participation, 6),
                }
            )
            total_qty += qty

        # Estimate total cost using trading/costs
        expected_cost_bps = 0.0
        if cfg.adv and cfg.adv > 0:
            from pyoptima.trading.costs import SquareRootCostModel

            cost_model = SquareRootCostModel(
                eta=cfg.temporary_impact,
                sigma=cfg.volatility or 0.02,
            )
            price = cfg.price or 100.0
            spread = cfg.bid_ask_spread or 1.0
            expected_cost_bps = cost_model.estimate(
                cfg.total_quantity, cfg.adv, price, spread
            )

        avg_participation = (
            np.mean([s["participation"] for s in schedule]) if schedule else 0
        )

        return {
            "status": result.status.value if hasattr(result, "status") else "optimal",
            "objective_value": (
                result.objective_value if hasattr(result, "objective_value") else None
            ),
            "solution": {
                "schedule": schedule,
                "expected_cost_bps": round(expected_cost_bps, 4),
                "total_intervals": n,
                "total_quantity_scheduled": round(total_qty),
                "avg_participation": round(float(avg_participation), 6),
                "strategy": cfg.strategy.value,
                "symbol": cfg.symbol,
                "side": cfg.side,
            },
            "problem_type": "QP",
            "num_variables": model.num_variables,
            "num_constraints": model.num_constraints,
        }

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _get_normalized_profile(cfg: ExecutionConfig) -> list[float]:
        """Return a normalised volume profile with length == n_intervals."""
        n = cfg.n_intervals
        if cfg.volume_profile is not None:
            raw = list(cfg.volume_profile)
            # Trim or pad to n intervals
            if len(raw) > n:
                raw = raw[:n]
            elif len(raw) < n:
                raw.extend([raw[-1] if raw else 1.0 / n] * (n - len(raw)))
            total = sum(raw) or 1.0
            return [v / total for v in raw]
        # Uniform fallback
        return [1.0 / n] * n
