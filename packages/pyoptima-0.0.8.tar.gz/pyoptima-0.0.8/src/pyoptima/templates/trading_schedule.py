"""
Trading schedule template — optimal timing of trading tasks.

Schedules a set of trading tasks across the trading session, respecting
dependencies, time windows, and volume/volatility preferences.

Strategies
----------
- **fixed** — Assign fixed start times.
- **adaptive** — Optimise timing for volume/volatility windows.
- **priority** — Schedule highest-priority tasks first.

Usage
-----
::

    result = template.solve({
        "strategy": "priority",
        "tasks": [
            {"name": "rebalance", "duration_minutes": 30, "priority": 2},
            {"name": "execution", "duration_minutes": 60, "priority": 1},
        ],
        "session_start": "09:30",
        "session_end": "16:00",
    })
"""

from __future__ import annotations

from typing import Any

from pyoptima.core.result import OptimizationResult
from pyoptima.model.core import (
    AbstractModel,
    Expression,
)
from pyoptima.templates.base import ProblemTemplate, TemplateInfo, TemplateRegistry
from pyoptima.templates.trading_schedule_config import (
    ScheduleStrategy,
    TradingScheduleConfig,
)


@TemplateRegistry.register("trading_schedule")
class TradingScheduleTemplate(ProblemTemplate):
    """
    Trading schedule template.

    Registered as ``"trading_schedule"`` — available via ``run_from_config``
    and the REST API.
    """

    @property
    def info(self) -> TemplateInfo:
        return TemplateInfo(
            name="trading_schedule",
            description="Optimise timing of trading tasks across the session",
            problem_type="MILP",
            required_data=["tasks"],
            optional_data=[
                "strategy",
                "session_start",
                "session_end",
                "volume_profile",
                "volatility_profile",
                "interval_minutes",
            ],
            default_solver="highs",
        )

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def validate_data(self, data: dict[str, Any]) -> None:
        self._require_keys(data, ["tasks"])
        cfg = TradingScheduleConfig.from_dict(data)

        if not cfg.tasks:
            raise ValueError("tasks must be non-empty")
        names = [t.name for t in cfg.tasks]
        if len(set(names)) != len(names):
            raise ValueError("task names must be unique")

        # Check dependencies reference valid tasks
        for task in cfg.tasks:
            if task.depends_on:
                for dep in task.depends_on:
                    if dep not in names:
                        raise ValueError(
                            f"Task '{task.name}' depends on unknown task '{dep}'"
                        )

    # ------------------------------------------------------------------
    # Model building
    # ------------------------------------------------------------------

    def build_model(self, data: dict[str, Any]) -> AbstractModel:
        cfg = TradingScheduleConfig.from_dict(data)
        n_tasks = len(cfg.tasks)
        n_slots = cfg.n_slots

        model = AbstractModel(name="trading_schedule")
        model.add_set("tasks", list(range(n_tasks)))
        model.add_set("slots", list(range(n_slots)))
        model.add_parameter("config", cfg)

        sh, sm = map(int, cfg.session_start.split(":"))
        start_min = sh * 60 + sm

        # Decision variables: x[t,s] = 1 if task t starts at slot s
        for t in range(n_tasks):
            task = cfg.tasks[t]
            slots_needed = max(1, task.duration_minutes // cfg.interval_minutes)

            # Determine valid start slots for this task
            for s in range(n_slots):
                # Task would end at slot s + slots_needed - 1
                if s + slots_needed <= n_slots:
                    model.add_binary(f"x_{t}_{s}")

        # Each task starts exactly once
        for t in range(n_tasks):
            task = cfg.tasks[t]
            slots_needed = max(1, task.duration_minutes // cfg.interval_minutes)
            assign_expr = Expression()
            for s in range(n_slots):
                if s + slots_needed <= n_slots:
                    assign_expr.add_term(1.0, f"x_{t}_{s}")
            model.add_eq_constraint(f"assign_{t}", assign_expr, 1.0)

        # Non-overlap: at most one task active in each slot
        for s in range(n_slots):
            slot_expr = Expression()
            for t in range(n_tasks):
                task = cfg.tasks[t]
                slots_needed = max(1, task.duration_minutes // cfg.interval_minutes)
                # Task t occupies slot s if started at any slot s' where s' ≤ s < s' + slots_needed
                for s_start in range(max(0, s - slots_needed + 1), s + 1):
                    if s_start + slots_needed <= n_slots:
                        var_name = f"x_{t}_{s_start}"
                        if model.get_variable(var_name) is not None:
                            slot_expr.add_term(1.0, var_name)
            model.add_leq_constraint(f"no_overlap_{s}", slot_expr, 1.0)

        # Time window constraints
        for t in range(n_tasks):
            task = cfg.tasks[t]
            slots_needed = max(1, task.duration_minutes // cfg.interval_minutes)

            if task.earliest is not None:
                eh, em = map(int, task.earliest.split(":"))
                earliest_slot = max(
                    0, (eh * 60 + em - start_min) // cfg.interval_minutes
                )
                # Force x[t,s] = 0 for s < earliest_slot
                for s in range(min(earliest_slot, n_slots)):
                    if s + slots_needed <= n_slots:
                        var_name = f"x_{t}_{s}"
                        if model.get_variable(var_name) is not None:
                            zero_expr = Expression()
                            zero_expr.add_term(1.0, var_name)
                            model.add_leq_constraint(
                                f"earliest_{t}_{s}", zero_expr, 0.0
                            )

            if task.latest is not None:
                lh, lm = map(int, task.latest.split(":"))
                latest_slot = (lh * 60 + lm - start_min) // cfg.interval_minutes
                # Task must end by latest_slot: s + slots_needed ≤ latest_slot
                for s in range(n_slots):
                    if s + slots_needed > latest_slot and s + slots_needed <= n_slots:
                        var_name = f"x_{t}_{s}"
                        if model.get_variable(var_name) is not None:
                            zero_expr = Expression()
                            zero_expr.add_term(1.0, var_name)
                            model.add_leq_constraint(f"latest_{t}_{s}", zero_expr, 0.0)

        # Dependency constraints
        for t in range(n_tasks):
            task = cfg.tasks[t]
            if task.depends_on:
                for dep_name in task.depends_on:
                    dep_idx = next(
                        i for i, tk in enumerate(cfg.tasks) if tk.name == dep_name
                    )
                    dep_task = cfg.tasks[dep_idx]
                    dep_slots = max(
                        1, dep_task.duration_minutes // cfg.interval_minutes
                    )
                    # start(t) ≥ start(dep) + dep_slots
                    # Linearise: Σ_s s·x[t,s] ≥ Σ_s (s+dep_slots)·x[dep,s]
                    dep_expr = Expression()
                    for s in range(n_slots):
                        t_slots_needed = max(
                            1, task.duration_minutes // cfg.interval_minutes
                        )
                        if s + t_slots_needed <= n_slots:
                            dep_expr.add_term(float(s), f"x_{t}_{s}")
                        if s + dep_slots <= n_slots:
                            dep_expr.add_term(-float(s + dep_slots), f"x_{dep_idx}_{s}")
                    model.add_geq_constraint(f"dep_{t}_{dep_idx}", dep_expr, 0.0)

        # Build objective
        if cfg.strategy == ScheduleStrategy.FIXED:
            self._build_fixed_objective(model, cfg, n_tasks, n_slots)
        elif cfg.strategy == ScheduleStrategy.ADAPTIVE:
            self._build_adaptive_objective(model, cfg, n_tasks, n_slots)
        elif cfg.strategy == ScheduleStrategy.PRIORITY:
            self._build_priority_objective(model, cfg, n_tasks, n_slots)

        return model

    # ------------------------------------------------------------------
    # Strategy-specific objectives
    # ------------------------------------------------------------------

    def _build_fixed_objective(
        self,
        model: AbstractModel,
        cfg: TradingScheduleConfig,
        n_tasks: int,
        n_slots: int,
    ) -> None:
        """Minimise total start time (pack tasks early)."""
        obj = Expression()
        for t in range(n_tasks):
            task = cfg.tasks[t]
            slots_needed = max(1, task.duration_minutes // cfg.interval_minutes)
            for s in range(n_slots):
                if s + slots_needed <= n_slots:
                    obj.add_term(float(s), f"x_{t}_{s}")
        model.minimize(obj)

    def _build_adaptive_objective(
        self,
        model: AbstractModel,
        cfg: TradingScheduleConfig,
        n_tasks: int,
        n_slots: int,
    ) -> None:
        """Align tasks with preferred volume/volatility windows."""
        # Normalise volume profile
        profile = cfg.volume_profile or [1.0 / n_slots] * n_slots
        if len(profile) < n_slots:
            profile.extend(
                [profile[-1] if profile else 1.0 / n_slots] * (n_slots - len(profile))
            )
        total = sum(profile) or 1.0
        profile = [v / total for v in profile]

        obj = Expression()
        for t in range(n_tasks):
            task = cfg.tasks[t]
            slots_needed = max(1, task.duration_minutes // cfg.interval_minutes)
            prefers_volume = task.prefer_high_volume

            for s in range(n_slots):
                if s + slots_needed <= n_slots:
                    # Average volume over the task's slots
                    avg_volume = (
                        sum(profile[s + k] for k in range(slots_needed)) / slots_needed
                    )

                    # High volume = good for volume-preferring tasks
                    # → Minimise negative volume = maximise volume
                    if prefers_volume:
                        cost = -avg_volume * task.priority
                    else:
                        cost = avg_volume * task.priority
                    obj.add_term(cost, f"x_{t}_{s}")
        model.minimize(obj)

    def _build_priority_objective(
        self,
        model: AbstractModel,
        cfg: TradingScheduleConfig,
        n_tasks: int,
        n_slots: int,
    ) -> None:
        """Schedule high-priority tasks earlier."""
        max_priority = max((t.priority for t in cfg.tasks), default=1)
        obj = Expression()
        for t in range(n_tasks):
            task = cfg.tasks[t]
            slots_needed = max(1, task.duration_minutes // cfg.interval_minutes)
            # Higher priority → larger penalty for late start
            priority_weight = max_priority + 1 - task.priority
            for s in range(n_slots):
                if s + slots_needed <= n_slots:
                    obj.add_term(float(s) * priority_weight, f"x_{t}_{s}")
        model.minimize(obj)

    # ------------------------------------------------------------------
    # Solution formatting
    # ------------------------------------------------------------------

    def format_solution(
        self,
        model: AbstractModel,
        result: OptimizationResult,
        data: dict[str, Any],
    ) -> dict[str, Any]:
        cfg: TradingScheduleConfig = model.get_parameter("config")
        n_tasks = len(cfg.tasks)
        n_slots = cfg.n_slots
        labels = cfg.slot_labels()

        schedule: list[dict[str, Any]] = []
        for t in range(n_tasks):
            task = cfg.tasks[t]
            slots_needed = max(1, task.duration_minutes // cfg.interval_minutes)
            start_slot = 0

            for s in range(n_slots):
                if s + slots_needed <= n_slots:
                    var = model.get_variable(f"x_{t}_{s}")
                    if var and var.value is not None and var.value > 0.5:
                        start_slot = s
                        break

            end_slot = start_slot + slots_needed
            schedule.append(
                {
                    "task": task.name,
                    "start_slot": start_slot,
                    "end_slot": end_slot,
                    "start_time": (
                        labels[start_slot] if start_slot < len(labels) else "?"
                    ),
                    "end_time": (
                        labels[min(end_slot, len(labels) - 1)]
                        if end_slot <= len(labels)
                        else "?"
                    ),
                    "duration_minutes": task.duration_minutes,
                    "priority": task.priority,
                }
            )

        # Sort by start slot
        schedule.sort(key=lambda x: x["start_slot"])

        return {
            "status": result.status.value if hasattr(result, "status") else "optimal",
            "objective_value": (
                result.objective_value if hasattr(result, "objective_value") else None
            ),
            "solution": {
                "schedule": schedule,
                "total_tasks": n_tasks,
                "session_start": cfg.session_start,
                "session_end": cfg.session_end,
                "strategy": cfg.strategy.value,
            },
            "problem_type": "MILP",
            "num_variables": model.num_variables,
            "num_constraints": model.num_constraints,
        }
