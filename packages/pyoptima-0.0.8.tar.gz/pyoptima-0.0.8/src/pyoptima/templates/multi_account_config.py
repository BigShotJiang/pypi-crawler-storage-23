"""
Multi-account configuration.

Defines :class:`AccountConstraints` and :class:`MultiAccountConfig` for the
:class:`~pyoptima.templates.multi_account.MultiAccountTemplate` that allocates
across accounts/mandates with per-account constraints.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class MultiAccountStrategy(Enum):
    """Multi-account allocation algorithm selection."""

    INDEPENDENT = "independent"
    """Optimise each account separately, then reconcile."""

    JOINT = "joint"
    """Single optimisation with per-account constraints."""

    CASCADE = "cascade"
    """Optimise top-level aggregate, then distribute to accounts."""


@dataclass
class AccountConstraints:
    """
    Per-account constraints.

    Args:
        name: Account identifier.
        min_weight: Minimum weight per asset for this account.
        max_weight: Maximum weight per asset.
        max_turnover: Turnover cap for this account.
        excluded_symbols: Assets excluded from this account.
        max_volatility: Volatility cap for this account.
        target_weights: Optional target weights for this account.

    Example::

        acc = AccountConstraints(
            name="pension_fund",
            max_weight=0.10,
            max_volatility=0.12,
            excluded_symbols=["CRYPTO"],
        )
    """

    name: str = ""
    min_weight: float = 0.0
    max_weight: float = 1.0
    max_turnover: float | None = None
    excluded_symbols: list[str] | None = None
    max_volatility: float | None = None
    target_weights: dict[str, float] | None = None

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "name": self.name,
            "min_weight": self.min_weight,
            "max_weight": self.max_weight,
        }
        if self.max_turnover is not None:
            d["max_turnover"] = self.max_turnover
        if self.excluded_symbols is not None:
            d["excluded_symbols"] = self.excluded_symbols
        if self.max_volatility is not None:
            d["max_volatility"] = self.max_volatility
        if self.target_weights is not None:
            d["target_weights"] = self.target_weights
        return d

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> AccountConstraints:
        return cls(
            name=d.get("name", ""),
            min_weight=float(d.get("min_weight", 0.0)),
            max_weight=float(d.get("max_weight", 1.0)),
            max_turnover=d.get("max_turnover"),
            excluded_symbols=d.get("excluded_symbols"),
            max_volatility=d.get("max_volatility"),
            target_weights=d.get("target_weights"),
        )


@dataclass
class MultiAccountConfig:
    """
    Configuration for multi-account optimisation.

    Args:
        strategy: Multi-account algorithm.
        accounts: Per-account constraints.
        expected_returns: n-length vector of expected returns.
        covariance_matrix: n × n covariance matrix.
        symbols: Ordered asset list.
        objective: Objective for each account (e.g. ``"min_volatility"``).
        account_values: Account → AUM.
        current_weights: Account → {symbol: weight} current allocations.

    Example::

        cfg = MultiAccountConfig(
            strategy=MultiAccountStrategy.JOINT,
            accounts=[
                AccountConstraints(name="aggressive", max_weight=0.40),
                AccountConstraints(name="conservative", max_weight=0.15),
            ],
            expected_returns=[0.10, 0.12, 0.08],
            covariance_matrix=[[...], ...],
            symbols=["AAPL", "MSFT", "GOOGL"],
        )
    """

    strategy: MultiAccountStrategy = MultiAccountStrategy.JOINT
    accounts: list[AccountConstraints] = field(default_factory=list)
    expected_returns: list[float] | None = None
    covariance_matrix: list[list[float]] | None = None
    symbols: list[str] = field(default_factory=list)
    objective: str = "min_volatility"
    account_values: dict[str, float] | None = None
    current_weights: dict[str, dict[str, float]] | None = None

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "strategy": self.strategy.value,
            "accounts": [a.to_dict() for a in self.accounts],
            "symbols": self.symbols,
            "objective": self.objective,
        }
        if self.expected_returns is not None:
            d["expected_returns"] = self.expected_returns
        if self.covariance_matrix is not None:
            d["covariance_matrix"] = self.covariance_matrix
        if self.account_values is not None:
            d["account_values"] = self.account_values
        if self.current_weights is not None:
            d["current_weights"] = self.current_weights
        return d

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> MultiAccountConfig:
        strategy_raw = d.get("strategy", "joint")
        try:
            strategy = MultiAccountStrategy(strategy_raw)
        except ValueError:
            strategy = MultiAccountStrategy.JOINT

        accounts = [
            AccountConstraints.from_dict(a) if isinstance(a, dict) else a
            for a in d.get("accounts", [])
        ]

        return cls(
            strategy=strategy,
            accounts=accounts,
            expected_returns=d.get("expected_returns"),
            covariance_matrix=d.get("covariance_matrix"),
            symbols=d.get("symbols", []),
            objective=d.get("objective", "min_volatility"),
            account_values=d.get("account_values"),
            current_weights=d.get("current_weights"),
        )
