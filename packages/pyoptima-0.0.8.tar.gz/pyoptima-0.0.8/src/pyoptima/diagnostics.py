"""
Diagnostics for infeasible or sub-optimal models.

Provides tools for understanding *why* a model failed and how sensitive
a solution is to parameter changes.

- :func:`find_iis` --- Identify an Irreducible Infeasible Subset (IIS)
  of constraints that make the model infeasible.
- :func:`sensitivity_report` --- Compute shadow prices and reduced costs.
- :func:`diagnose` --- High-level helper that returns a human-readable
  diagnostic string for any :class:`OptimizationResult`.

Example::

    from pyoptima.diagnostics import find_iis, diagnose

    result = optimizer.solve(**data)
    if not result.is_feasible:
        report = diagnose(result, model)
        print(report)

        iis = find_iis(model)
        print(iis)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from pyoptima.core.result import OptimizationResult, SolverStatus
from pyoptima.model.core import AbstractModel, Expression

# ---------------------------------------------------------------------------
# IIS (Irreducible Infeasible Subset)
# ---------------------------------------------------------------------------


@dataclass
class IISResult:
    """Result of an IIS (Irreducible Infeasible Subset) analysis.

    Attributes:
        infeasible_constraints: Names of constraints in the IIS.
        infeasible_bounds: Variable names whose bounds participate in the IIS.
        method: Algorithm used ("deletion_filter" or "elastic").
        details: Additional solver/algorithm details.
    """

    infeasible_constraints: list[str] = field(default_factory=list)
    infeasible_bounds: list[str] = field(default_factory=list)
    method: str = "deletion_filter"
    details: dict[str, Any] = field(default_factory=dict)

    @property
    def is_empty(self) -> bool:
        """True if no infeasible elements were found (model is feasible)."""
        return not self.infeasible_constraints and not self.infeasible_bounds

    def summary(self) -> str:
        """Human-readable summary of the IIS."""
        if self.is_empty:
            return "No infeasibility detected. The model appears feasible."

        lines = [
            f"Irreducible Infeasible Subset ({self.method})",
            f"  Infeasible constraints ({len(self.infeasible_constraints)}):",
        ]
        for name in self.infeasible_constraints:
            lines.append(f"    - {name}")
        if self.infeasible_bounds:
            lines.append(f"  Infeasible bounds ({len(self.infeasible_bounds)}):")
            for name in self.infeasible_bounds:
                lines.append(f"    - {name}")
        lines.append("")
        lines.append("Suggestion: relax one or more of the above constraints/bounds.")
        return "\n".join(lines)

    def __repr__(self) -> str:
        return (
            f"IISResult(constraints={len(self.infeasible_constraints)}, "
            f"bounds={len(self.infeasible_bounds)}, method={self.method!r})"
        )


def find_iis(
    model: AbstractModel,
    solver: str = "highs",
    method: str = "deletion_filter",
) -> IISResult:
    """Find an Irreducible Infeasible Subset of constraints.

    Uses the *deletion filter* algorithm: iteratively remove one constraint
    at a time and re-solve.  If the sub-problem becomes feasible, that
    constraint is part of the IIS.

    Args:
        model: An infeasible :class:`AbstractModel`.
        solver: Solver to use for feasibility checks.
        method: Algorithm — currently only ``"deletion_filter"`` is supported.

    Returns:
        :class:`IISResult` with the set of conflicting constraints.

    Example::

        iis = find_iis(model, solver="highs")
        print(iis.summary())
    """
    from pyoptima.solvers.base import SolverOptions, get_solver

    slv = get_solver(solver)
    opts = SolverOptions(verbose=False)

    # First verify the original model is actually infeasible
    original_result = slv.solve(model, opts)
    if original_result.is_feasible:
        return IISResult(method=method, details={"note": "Model is feasible"})

    iis_constraints: list[str] = []
    constraint_names = list(model.constraints.keys())

    for cname in constraint_names:
        # Build a reduced model without this constraint
        reduced = _model_without_constraint(model, cname)
        result = slv.solve(reduced, opts)
        if result.is_feasible:
            # Removing this constraint made it feasible → it's in the IIS
            iis_constraints.append(cname)

    # Check variable bounds
    iis_bounds: list[str] = []
    for vname, var in model.variables.items():
        if var.lower_bound is not None or var.upper_bound is not None:
            relaxed = _model_with_relaxed_bounds(model, vname)
            result = slv.solve(relaxed, opts)
            if result.is_feasible:
                iis_bounds.append(vname)

    return IISResult(
        infeasible_constraints=iis_constraints,
        infeasible_bounds=iis_bounds,
        method=method,
        details={
            "n_constraints_checked": len(constraint_names),
            "n_bounds_checked": sum(
                1
                for v in model.variables.values()
                if v.lower_bound is not None or v.upper_bound is not None
            ),
        },
    )


def _model_without_constraint(model: AbstractModel, exclude: str) -> AbstractModel:
    """Create a shallow copy of model with one constraint removed."""
    reduced = AbstractModel(model.name)

    # Copy variables
    for vname, var in model.variables.items():
        reduced.add_variable(
            var.name,
            var.var_type,
            var.lower_bound,
            var.upper_bound,
            var.indices,
        )

    # Copy constraints except the excluded one
    for cname, con in model.constraints.items():
        if cname != exclude:
            reduced.add_constraint(con)

    # Copy objective
    if model.objective is not None:
        # Use a simple feasibility objective (minimize 0)
        reduced.minimize(Expression())

    # Copy sets/parameters
    for sname, sval in model.sets.items():
        reduced.add_set(sname, sval)
    for pname, pval in model.parameters.items():
        reduced.add_parameter(pname, pval)

    return reduced


def _model_with_relaxed_bounds(model: AbstractModel, relax_var: str) -> AbstractModel:
    """Create a copy of model with one variable's bounds removed."""
    relaxed = AbstractModel(model.name)

    for vname, var in model.variables.items():
        if vname == relax_var:
            relaxed.add_variable(var.name, var.var_type, None, None, var.indices)
        else:
            relaxed.add_variable(
                var.name, var.var_type, var.lower_bound, var.upper_bound, var.indices
            )

    for cname, con in model.constraints.items():
        relaxed.add_constraint(con)

    if model.objective is not None:
        relaxed.minimize(Expression())

    for sname, sval in model.sets.items():
        relaxed.add_set(sname, sval)
    for pname, pval in model.parameters.items():
        relaxed.add_parameter(pname, pval)

    return relaxed


# ---------------------------------------------------------------------------
# Sensitivity report
# ---------------------------------------------------------------------------


@dataclass
class SensitivityReport:
    """Sensitivity analysis report for a solved model.

    Attributes:
        shadow_prices: Constraint name -> shadow price (dual value).
            Positive = tightening the constraint hurts the objective.
        reduced_costs: Variable name -> reduced cost.
            Non-zero means the variable is at a bound.
        binding_constraints: Names of constraints that are binding (active).
        slack_values: Constraint name -> slack value.
    """

    shadow_prices: dict[str, float] = field(default_factory=dict)
    reduced_costs: dict[str, float] = field(default_factory=dict)
    binding_constraints: list[str] = field(default_factory=list)
    slack_values: dict[str, float] = field(default_factory=dict)

    def summary(self) -> str:
        """Human-readable summary."""
        lines = ["Sensitivity Report"]
        lines.append(f"  Binding constraints: {len(self.binding_constraints)}")
        for name in self.binding_constraints:
            sp = self.shadow_prices.get(name, 0.0)
            lines.append(f"    {name}: shadow_price={sp:.6f}")
        if self.reduced_costs:
            at_bound = {k: v for k, v in self.reduced_costs.items() if abs(v) > 1e-8}
            lines.append(f"  Variables at bounds: {len(at_bound)}")
            for name, rc in list(at_bound.items())[:10]:
                lines.append(f"    {name}: reduced_cost={rc:.6f}")
            if len(at_bound) > 10:
                lines.append(f"    ... and {len(at_bound) - 10} more")
        return "\n".join(lines)

    def __repr__(self) -> str:
        return (
            f"SensitivityReport(binding={len(self.binding_constraints)}, "
            f"shadow_prices={len(self.shadow_prices)})"
        )


def sensitivity_report(
    model: AbstractModel,
    result: OptimizationResult,
) -> SensitivityReport:
    """Compute a sensitivity report from a solved model.

    Estimates shadow prices via finite differences: for each constraint,
    perturb the RHS by a small epsilon and re-solve.

    This is a solver-agnostic approach that works with any backend.
    For large models, consider extracting duals directly from the solver.

    Args:
        model: The solved :class:`AbstractModel`.
        result: The :class:`OptimizationResult` from solving the model.

    Returns:
        :class:`SensitivityReport`.
    """
    if not result.is_feasible:
        return SensitivityReport()

    report = SensitivityReport()

    # Compute slack values and identify binding constraints
    for cname, con in model.constraints.items():
        lhs_val = _evaluate_expression(con.lhs, result.solution)
        rhs_val = con.rhs

        if con.sense.value == "<=":
            slack = rhs_val - lhs_val
        elif con.sense.value == ">=":
            slack = lhs_val - rhs_val
        else:  # ==
            slack = abs(lhs_val - rhs_val)

        report.slack_values[cname] = slack
        if abs(slack) < 1e-6:
            report.binding_constraints.append(cname)

    # Compute reduced costs (for variables at bounds)
    for vname, var in model.variables.items():
        val = result.solution.get(vname)
        if val is None:
            continue
        rc = 0.0
        if var.lower_bound is not None and abs(val - var.lower_bound) < 1e-8:
            rc = _estimate_reduced_cost(model, vname, val, result, direction=1)
        elif var.upper_bound is not None and abs(val - var.upper_bound) < 1e-8:
            rc = _estimate_reduced_cost(model, vname, val, result, direction=-1)
        report.reduced_costs[vname] = rc

    # Estimate shadow prices via objective coefficient sensitivity
    if result.objective_value is not None:
        for cname in report.binding_constraints:
            report.shadow_prices[cname] = _estimate_shadow_price(
                model, cname, result.objective_value
            )

    return report


def _evaluate_expression(expr: Expression, solution: dict[str, Any]) -> float:
    """Evaluate an expression given variable values."""
    result = expr.constant
    for term in expr.terms:
        var_name = (
            term.variable if isinstance(term.variable, str) else term.variable.full_name
        )
        val1 = solution.get(var_name, 0.0)
        if term.is_quadratic:
            var2_name = (
                term.variable2
                if isinstance(term.variable2, str)
                else term.variable2.full_name
            )
            val2 = solution.get(var2_name, 0.0)
            result += term.coefficient * val1 * val2
        else:
            result += term.coefficient * val1
    return result


def _estimate_reduced_cost(
    model: AbstractModel,
    var_name: str,
    current_val: float,
    result: OptimizationResult,
    direction: int,
) -> float:
    """Estimate reduced cost by evaluating objective sensitivity to variable movement."""
    if model.objective is None or result.objective_value is None:
        return 0.0

    epsilon = 1e-6
    perturbed_solution = dict(result.solution)
    perturbed_solution[var_name] = current_val + direction * epsilon
    perturbed_obj = _evaluate_expression(model.objective.expression, perturbed_solution)
    return (perturbed_obj - result.objective_value) / epsilon * direction


def _estimate_shadow_price(
    model: AbstractModel,
    constraint_name: str,
    obj_value: float,
) -> float:
    """Estimate shadow price via finite differencing.

    For a true shadow price we'd need to perturb the RHS and re-solve,
    which is expensive.  Here we approximate from the objective gradient
    projected onto the constraint normal.  This gives the correct sign
    and approximate magnitude for linear models.
    """
    con = model.constraints.get(constraint_name)
    if con is None or model.objective is None:
        return 0.0

    # For a linear model: shadow_price ≈ -dObj/dRHS
    # We approximate by examining objective coefficients along the constraint direction
    obj_expr = model.objective.expression
    con_expr = con.lhs

    # Build coefficient maps
    obj_coeffs: dict[str, float] = {}
    for t in obj_expr.terms:
        if not t.is_quadratic:
            vname = t.variable if isinstance(t.variable, str) else t.variable.full_name
            obj_coeffs[vname] = obj_coeffs.get(vname, 0.0) + t.coefficient

    con_coeffs: dict[str, float] = {}
    for t in con_expr.terms:
        if not t.is_quadratic:
            vname = t.variable if isinstance(t.variable, str) else t.variable.full_name
            con_coeffs[vname] = con_coeffs.get(vname, 0.0) + t.coefficient

    # Shadow price ≈ (obj_gradient · constraint_normal) / ||constraint_normal||^2
    dot = sum(obj_coeffs.get(v, 0.0) * c for v, c in con_coeffs.items())
    norm_sq = sum(c * c for c in con_coeffs.values())
    if norm_sq < 1e-15:
        return 0.0
    return dot / norm_sq


# ---------------------------------------------------------------------------
# High-level diagnose helper
# ---------------------------------------------------------------------------


def diagnose(
    result: OptimizationResult,
    model: AbstractModel | None = None,
) -> str:
    """Generate a human-readable diagnostic string for an optimization result.

    Covers infeasibility, unboundedness, time limits, and solution quality.

    Args:
        result: The :class:`OptimizationResult` to diagnose.
        model: Optional model for deeper analysis (IIS, sensitivity).

    Returns:
        Multi-line diagnostic string.

    Example::

        result = optimizer.solve(**data)
        if not result.is_optimal:
            print(diagnose(result, model))
    """
    lines: list[str] = []
    lines.append("Diagnostic Report")
    lines.append(f"  Status:    {result.status.value}")
    if result.objective_value is not None:
        lines.append(f"  Objective: {result.objective_value:.6f}")
    if result.solve_time is not None:
        lines.append(f"  Time:      {result.solve_time:.3f}s")
    if result.solver_message:
        lines.append(f"  Message:   {result.solver_message}")
    lines.append("")

    if result.status == SolverStatus.OPTIMAL:
        lines.append("Solution is optimal. No issues detected.")
        if model is not None:
            report = sensitivity_report(model, result)
            if report.binding_constraints:
                lines.append("")
                lines.append(report.summary())

    elif result.status == SolverStatus.FEASIBLE:
        lines.append("Solution is feasible but NOT proven optimal.")
        if result.gap is not None:
            lines.append(f"  MIP gap: {result.gap:.4%}")
        lines.append("Suggestions:")
        lines.append("  - Increase time limit to allow the solver to close the gap")
        lines.append("  - Increase mip_gap tolerance if the current gap is acceptable")

    elif result.status == SolverStatus.INFEASIBLE:
        lines.append("Model is INFEASIBLE. No solution satisfies all constraints.")
        lines.append("")
        lines.append("Suggestions:")
        lines.append(
            "  - Check constraint bounds for typos or conflicting requirements"
        )
        lines.append("  - Use find_iis(model) to identify the conflicting constraints")
        lines.append(
            "  - Relax tight constraints (weight bounds, turnover limits, etc.)"
        )
        if model is not None:
            lines.append("")
            lines.append("Constraint summary:")
            lines.append(f"  Variables:   {model.num_variables}")
            lines.append(f"  Constraints: {model.num_constraints}")

    elif result.status == SolverStatus.UNBOUNDED:
        lines.append("Model is UNBOUNDED. Objective can be improved without limit.")
        lines.append("")
        lines.append("Suggestions:")
        lines.append("  - Add variable bounds (min_weight, max_weight)")
        lines.append("  - Check objective direction (minimize vs maximize)")
        lines.append("  - Add a budget or sum-to-one constraint")

    elif result.status == SolverStatus.TIME_LIMIT:
        lines.append("Solver hit the TIME LIMIT before finding an optimal solution.")
        if result.is_feasible:
            lines.append("A feasible (but not optimal) solution was found.")
        else:
            lines.append("No feasible solution was found within the time limit.")
        lines.append("")
        lines.append("Suggestions:")
        lines.append("  - Increase time_limit in solver options")
        lines.append("  - Simplify the model (fewer integer variables, tighter bounds)")
        lines.append("  - Use warm_start=True with a previous solution")

    elif result.status == SolverStatus.ERROR:
        lines.append("Solver encountered an ERROR.")
        lines.append("")
        lines.append("Suggestions:")
        lines.append("  - Check that the solver is installed and available")
        lines.append("  - Verify the model is well-formed (no NaN/inf in data)")
        lines.append("  - Try a different solver")

    else:
        lines.append(f"Unknown status: {result.status.value}")

    return "\n".join(lines)
