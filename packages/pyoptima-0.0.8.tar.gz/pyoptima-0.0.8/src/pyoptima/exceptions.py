"""
Custom exceptions for PyOptima.
"""

from enum import Enum


class ErrorCode(str, Enum):
    """Machine-readable error codes for API/ETL."""

    VALIDATION_ERROR = "VALIDATION_ERROR"
    SOLVER_ERROR = "SOLVER_ERROR"
    TEMPLATE_NOT_FOUND = "TEMPLATE_NOT_FOUND"
    OPTIMIZATION_ERROR = "OPTIMIZATION_ERROR"
    CONSTRAINT_ERROR = "CONSTRAINT_ERROR"
    DATA_FORMAT_ERROR = "DATA_FORMAT_ERROR"
    METHOD_NOT_FOUND = "METHOD_NOT_FOUND"


class OptimizationError(Exception):
    """Base exception for optimization errors."""

    def __init__(self, message: str, error_code: ErrorCode | None = None):
        super().__init__(message)
        self.error_code = error_code or ErrorCode.OPTIMIZATION_ERROR


class ConstraintError(OptimizationError):
    """Exception raised for constraint-related errors."""

    def __init__(self, message: str, error_code: ErrorCode | None = None):
        super().__init__(message, error_code or ErrorCode.CONSTRAINT_ERROR)


class DataFormatError(OptimizationError):
    """Exception raised for data format issues."""

    def __init__(self, message: str, error_code: ErrorCode | None = None):
        super().__init__(message, error_code or ErrorCode.DATA_FORMAT_ERROR)


class SolverError(OptimizationError):
    """Exception raised for solver failures."""

    def __init__(self, message: str, error_code: ErrorCode | None = None):
        super().__init__(message, error_code or ErrorCode.SOLVER_ERROR)


class MethodNotFoundError(OptimizationError):
    """Exception raised when optimization method is not found."""

    def __init__(self, message: str, error_code: ErrorCode | None = None):
        super().__init__(message, error_code or ErrorCode.METHOD_NOT_FOUND)


class ValidationError(OptimizationError):
    """Exception raised for input validation errors."""

    def __init__(self, message: str, error_code: ErrorCode | None = None):
        super().__init__(message, error_code or ErrorCode.VALIDATION_ERROR)
