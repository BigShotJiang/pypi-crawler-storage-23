"""Utilities."""

from pyoptima.utils.logging import log_run

__all__ = ["log_run"]
