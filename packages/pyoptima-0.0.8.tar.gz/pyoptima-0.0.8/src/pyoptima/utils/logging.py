"""Structured logging for optimization runs."""

import logging

logger = logging.getLogger(__name__)


def log_run(
    job_id: str | None,
    template: str,
    status: str,
    duration_sec: float | None = None,
) -> None:
    """Log one line per optimization run for correlation and monitoring."""
    parts = [f"job_id={job_id or '-'}", f"template={template}", f"status={status}"]
    if duration_sec is not None:
        parts.append(f"duration_sec={duration_sec:.3f}")
    logger.info(" ".join(parts))
