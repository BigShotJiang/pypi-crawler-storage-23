"""
Optimization result classes with IO methods.

Provides a standardized result format with pandas-style export methods
and domain-specific subclasses.

Hierarchy:
- ``OptimizationResult`` --- domain-agnostic base (status, objective, solution)
- ``PortfolioResult`` --- portfolio weights, return, volatility, Sharpe
- ``ExecutionResult`` --- schedule, expected cost
- ``RebalanceResult`` --- trades, turnover, cost
- ``SignalSizingResult`` --- positions, notional
- ``RiskBudgetResult`` --- adjusted weights, risk metrics
"""

from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import Any

try:
    import pandas as pd

    HAS_PANDAS = True
except ImportError:
    HAS_PANDAS = False

try:
    import numpy as np  # noqa: F401

    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False


class SolverStatus(Enum):
    """Solver termination status."""

    OPTIMAL = "optimal"
    FEASIBLE = "feasible"
    INFEASIBLE = "infeasible"
    UNBOUNDED = "unbounded"
    TIME_LIMIT = "time_limit"
    ERROR = "error"
    UNKNOWN = "unknown"


@dataclass
class OptimizationResult:
    """
    Domain-agnostic optimization result.

    Provides pandas-style methods for exporting results:
    - to_dict(): Export as dictionary
    - to_dataframe(): Export as pandas DataFrame
    - to_json(): Export as JSON string
    - to_sql(): Write to SQL database

    Domain-specific fields (weights, portfolio_return, etc.) are kept
    on the base class for backward compatibility.  New code should
    prefer the typed subclasses (:class:`PortfolioResult`, etc.).

    Example::

        result = optimizer.solve(data)
        print(result.status)          # SolverStatus.OPTIMAL
        df = result.to_dataframe()
        result.to_json("result.json")
    """

    # Core result fields
    status: SolverStatus
    objective_value: float | None = None
    solution: dict[str, Any] = field(default_factory=dict)

    # Timing
    solve_time: float | None = None
    timestamp: datetime = field(default_factory=lambda: datetime.now(UTC))

    # Solver info
    solver_name: str | None = None
    solver_message: str | None = None
    gap: float | None = None  # MIP gap

    # Problem info
    problem_type: str | None = None
    num_variables: int | None = None
    num_constraints: int | None = None

    # Domain-specific results (backward compat — prefer subclasses)
    weights: dict[str, float] | None = None
    portfolio_return: float | None = None
    portfolio_volatility: float | None = None
    sharpe_ratio: float | None = None
    selected_items: dict[str, Any] | None = None
    assignments: dict[str, Any] | None = None
    flows: dict[str, float] | None = None

    # Extra metadata
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_solution_dict(
        cls, d: dict[str, Any], **kwargs: Any
    ) -> "OptimizationResult":
        """Build OptimizationResult from a solution dictionary (e.g. from template format_solution)."""
        status_val = d.get("status", "unknown")
        if isinstance(status_val, SolverStatus):
            status = status_val
        else:
            try:
                status = SolverStatus(status_val)
            except ValueError:
                status = SolverStatus.UNKNOWN
        msg = d.get("solver_message") or d.get("message") or ""
        return cls(
            status=status,
            objective_value=d.get("objective_value"),
            solution=d.get("solution") or {},
            solve_time=d.get("solve_time"),
            solver_message=msg or None,
            gap=d.get("gap"),
            problem_type=d.get("problem_type"),
            num_variables=d.get("num_variables"),
            num_constraints=d.get("num_constraints"),
            weights=d.get("weights"),
            portfolio_return=d.get("portfolio_return"),
            portfolio_volatility=d.get("portfolio_volatility"),
            sharpe_ratio=d.get("sharpe_ratio"),
            selected_items=d.get("selected_items"),
            assignments=d.get("assignments"),
            flows=d.get("flows"),
            metadata={
                k: v
                for k, v in d.items()
                if k
                not in (
                    "status",
                    "objective_value",
                    "solution",
                    "solve_time",
                    "solver_message",
                    "message",
                    "gap",
                    "problem_type",
                    "num_variables",
                    "num_constraints",
                    "weights",
                    "portfolio_return",
                    "portfolio_volatility",
                    "sharpe_ratio",
                    "selected_items",
                    "assignments",
                    "flows",
                )
                and v is not None
            },
            **kwargs,
        )

    @property
    def is_optimal(self) -> bool:
        """Check if solution is optimal."""
        return self.status == SolverStatus.OPTIMAL

    @property
    def is_feasible(self) -> bool:
        """Check if solution is feasible (optimal or feasible)."""
        return self.status in (SolverStatus.OPTIMAL, SolverStatus.FEASIBLE)

    def to_dict(self, include_metadata: bool = True) -> dict[str, Any]:
        """
        Export result as dictionary.

        Args:
            include_metadata: Whether to include metadata field

        Returns:
            Dictionary representation of the result
        """
        result: dict[str, Any] = {
            "status": self.status.value,
            "objective_value": self.objective_value,
            "solution": self.solution,
            "solve_time": self.solve_time,
            "timestamp": self.timestamp.isoformat() if self.timestamp else None,
            "solver_name": self.solver_name,
            "solver_message": self.solver_message,
        }

        # Add optional fields if present
        if self.gap is not None:
            result["gap"] = self.gap
        if self.problem_type:
            result["problem_type"] = self.problem_type
        if self.num_variables is not None:
            result["num_variables"] = self.num_variables
        if self.num_constraints is not None:
            result["num_constraints"] = self.num_constraints

        # Add domain-specific fields
        if self.weights is not None:
            result["weights"] = self.weights
        if self.portfolio_return is not None:
            result["portfolio_return"] = self.portfolio_return
        if self.portfolio_volatility is not None:
            result["portfolio_volatility"] = self.portfolio_volatility
        if self.sharpe_ratio is not None:
            result["sharpe_ratio"] = self.sharpe_ratio
        if self.selected_items is not None:
            result["selected_items"] = self.selected_items
        if self.assignments is not None:
            result["assignments"] = self.assignments
        if self.flows is not None:
            result["flows"] = self.flows

        if include_metadata and self.metadata:
            result["metadata"] = self.metadata

        return result

    def to_dataframe(self, orient: str = "index") -> "pd.DataFrame":
        """
        Export result as pandas DataFrame.

        Args:
            orient: DataFrame orientation ("index" or "columns")

        Returns:
            pandas DataFrame

        Raises:
            ImportError: If pandas is not installed
        """
        if not HAS_PANDAS:
            raise ImportError(
                "pandas is required for to_dataframe(). Install with: pip install pandas"
            )

        data = self.to_dict(include_metadata=False)

        if orient == "index":
            return pd.DataFrame.from_dict(data, orient="index", columns=["value"])
        else:
            return pd.DataFrame([data])

    def weights_to_dataframe(self) -> "pd.DataFrame":
        """
        Export portfolio weights as DataFrame.

        Returns:
            DataFrame with columns [symbol, weight]

        Raises:
            ImportError: If pandas is not installed
            ValueError: If no weights available
        """
        if not HAS_PANDAS:
            raise ImportError(
                "pandas is required for weights_to_dataframe(). Install with: pip install pandas"
            )

        if self.weights is None:
            raise ValueError("No weights available in result")

        return (
            pd.DataFrame([{"symbol": k, "weight": v} for k, v in self.weights.items()])
            .sort_values("weight", ascending=False)
            .reset_index(drop=True)
        )

    def to_json(self, path: str | None = None, indent: int = 2) -> str:
        """
        Export result as JSON.

        Args:
            path: Optional file path to write to
            indent: JSON indentation level

        Returns:
            JSON string
        """
        import json

        data = self.to_dict()
        json_str = json.dumps(data, indent=indent, default=str)

        if path:
            with open(path, "w") as f:
                f.write(json_str)

        return json_str

    def to_sql(
        self,
        table: str,
        connection: Any,
        schema: str | None = None,
        if_exists: str = "append",
    ) -> None:
        """
        Write result to SQL database.

        Args:
            table: Table name
            connection: SQLAlchemy connection or engine
            schema: Database schema
            if_exists: How to handle existing table ("append", "replace", "fail")

        Raises:
            ImportError: If pandas is not installed
        """
        if not HAS_PANDAS:
            raise ImportError(
                "pandas is required for to_sql(). Install with: pip install pandas"
            )

        df = self.to_dataframe(orient="columns")
        df.to_sql(table, connection, schema=schema, if_exists=if_exists, index=False)

    def __repr__(self) -> str:
        parts = [f"OptimizationResult(status={self.status.value}"]
        if self.objective_value is not None:
            parts.append(f", objective={self.objective_value:.6f}")
        if self.solve_time is not None:
            parts.append(f", time={self.solve_time:.3f}s")
        parts.append(")")
        return "".join(parts)


# =============================================================================
# Domain-specific result subclasses
# =============================================================================


@dataclass
class PortfolioResult(OptimizationResult):
    """
    Portfolio optimization result with domain-specific fields.

    Inherits all base fields and adds:
    - ``weights`` --- symbol -> weight mapping
    - ``portfolio_return`` --- expected portfolio return
    - ``portfolio_volatility`` --- portfolio standard deviation
    - ``sharpe_ratio`` --- Sharpe ratio
    - ``risk_contributions`` --- per-asset risk contribution

    Example::

        result: PortfolioResult = optimizer.solve(...)
        print(result.weights)
        print(result.sharpe_ratio)
        df = result.weights_to_dataframe()
    """

    risk_contributions: dict[str, float] | None = None

    @classmethod
    def from_solution_dict(cls, d: dict[str, Any], **kwargs: Any) -> "PortfolioResult":
        """Build PortfolioResult from a solution dictionary."""
        base = super().from_solution_dict(d, **kwargs)
        return cls(
            status=base.status,
            objective_value=base.objective_value,
            solution=base.solution,
            solve_time=base.solve_time,
            timestamp=base.timestamp,
            solver_name=base.solver_name,
            solver_message=base.solver_message,
            gap=base.gap,
            problem_type=base.problem_type or "QP",
            num_variables=base.num_variables,
            num_constraints=base.num_constraints,
            weights=base.weights,
            portfolio_return=base.portfolio_return,
            portfolio_volatility=base.portfolio_volatility,
            sharpe_ratio=base.sharpe_ratio,
            selected_items=base.selected_items,
            assignments=base.assignments,
            flows=base.flows,
            metadata=base.metadata,
            risk_contributions=d.get("risk_contributions"),
        )

    def __repr__(self) -> str:
        parts = [f"PortfolioResult(status={self.status.value}"]
        if self.objective_value is not None:
            parts.append(f", objective={self.objective_value:.6f}")
        if self.portfolio_volatility is not None:
            parts.append(f", vol={self.portfolio_volatility:.4f}")
        if self.sharpe_ratio is not None:
            parts.append(f", sharpe={self.sharpe_ratio:.4f}")
        if self.weights:
            parts.append(f", n_assets={len(self.weights)}")
        parts.append(")")
        return "".join(parts)


@dataclass
class ExecutionResult(OptimizationResult):
    """
    Execution optimization result.

    Adds:
    - ``schedule`` --- list of time-bucket dicts with quantity/participation
    - ``expected_cost_bps`` --- expected execution cost in basis points
    - ``expected_impact_bps`` --- expected market impact in basis points
    """

    schedule: list[dict[str, Any]] | None = None
    expected_cost_bps: float | None = None
    expected_impact_bps: float | None = None

    @classmethod
    def from_solution_dict(cls, d: dict[str, Any], **kwargs: Any) -> "ExecutionResult":
        base = super().from_solution_dict(d, **kwargs)
        return cls(
            status=base.status,
            objective_value=base.objective_value,
            solution=base.solution,
            solve_time=base.solve_time,
            timestamp=base.timestamp,
            solver_name=base.solver_name,
            solver_message=base.solver_message,
            metadata=base.metadata,
            schedule=d.get("schedule"),
            expected_cost_bps=d.get("expected_cost_bps"),
            expected_impact_bps=d.get("expected_impact_bps"),
        )

    def schedule_to_dataframe(self) -> "pd.DataFrame":
        """Export execution schedule as DataFrame."""
        if not HAS_PANDAS:
            raise ImportError("pandas required")
        if not self.schedule:
            raise ValueError("No schedule available")
        return pd.DataFrame(self.schedule)

    def __repr__(self) -> str:
        parts = [f"ExecutionResult(status={self.status.value}"]
        if self.expected_cost_bps is not None:
            parts.append(f", cost={self.expected_cost_bps:.2f}bps")
        if self.schedule:
            parts.append(f", n_buckets={len(self.schedule)}")
        parts.append(")")
        return "".join(parts)


@dataclass
class RebalanceResult(OptimizationResult):
    """
    Rebalance optimization result.

    Adds:
    - ``trades`` --- symbol -> trade dict (from, to, delta)
    - ``total_turnover`` --- one-way turnover
    - ``total_cost_bps`` --- total transaction cost in bps
    """

    trades: dict[str, dict[str, float]] | None = None
    total_turnover: float | None = None
    total_cost_bps: float | None = None

    @classmethod
    def from_solution_dict(cls, d: dict[str, Any], **kwargs: Any) -> "RebalanceResult":
        base = super().from_solution_dict(d, **kwargs)
        return cls(
            status=base.status,
            objective_value=base.objective_value,
            solution=base.solution,
            solve_time=base.solve_time,
            timestamp=base.timestamp,
            solver_name=base.solver_name,
            solver_message=base.solver_message,
            metadata=base.metadata,
            trades=d.get("trades"),
            total_turnover=d.get("total_turnover"),
            total_cost_bps=d.get("total_cost_bps"),
        )

    def trades_to_dataframe(self) -> "pd.DataFrame":
        """Export trades as DataFrame."""
        if not HAS_PANDAS:
            raise ImportError("pandas required")
        if not self.trades:
            raise ValueError("No trades available")
        rows = []
        for sym, trade in self.trades.items():
            rows.append({"symbol": sym, **trade})
        return pd.DataFrame(rows)

    def __repr__(self) -> str:
        parts = [f"RebalanceResult(status={self.status.value}"]
        if self.total_turnover is not None:
            parts.append(f", turnover={self.total_turnover:.4f}")
        if self.total_cost_bps is not None:
            parts.append(f", cost={self.total_cost_bps:.2f}bps")
        parts.append(")")
        return "".join(parts)


@dataclass
class SignalSizingResult(OptimizationResult):
    """
    Signal sizing result.

    Adds:
    - ``positions`` --- symbol -> position weight
    - ``gross_exposure`` --- sum |w_i|
    - ``net_exposure`` --- sum w_i
    """

    positions: dict[str, float] | None = None
    gross_exposure: float | None = None
    net_exposure: float | None = None

    @classmethod
    def from_solution_dict(
        cls, d: dict[str, Any], **kwargs: Any
    ) -> "SignalSizingResult":
        base = super().from_solution_dict(d, **kwargs)
        return cls(
            status=base.status,
            objective_value=base.objective_value,
            solution=base.solution,
            solve_time=base.solve_time,
            timestamp=base.timestamp,
            solver_name=base.solver_name,
            solver_message=base.solver_message,
            metadata=base.metadata,
            positions=d.get("positions"),
            gross_exposure=d.get("gross_exposure"),
            net_exposure=d.get("net_exposure"),
        )

    def __repr__(self) -> str:
        parts = [f"SignalSizingResult(status={self.status.value}"]
        if self.gross_exposure is not None:
            parts.append(f", gross={self.gross_exposure:.4f}")
        if self.positions:
            parts.append(f", n_positions={len(self.positions)}")
        parts.append(")")
        return "".join(parts)


@dataclass
class RiskBudgetResult(OptimizationResult):
    """
    Risk budget result.

    Adds:
    - ``adjusted_weights`` --- symbol -> adjusted weight
    - ``portfolio_volatility`` --- portfolio volatility after adjustment
    - ``all_limits_satisfied`` --- whether all risk limits pass
    - ``violations`` --- list of limit violations
    """

    adjusted_weights: dict[str, float] | None = None
    all_limits_satisfied: bool | None = None
    violations: list[str] | None = None

    @classmethod
    def from_solution_dict(cls, d: dict[str, Any], **kwargs: Any) -> "RiskBudgetResult":
        base = super().from_solution_dict(d, **kwargs)
        return cls(
            status=base.status,
            objective_value=base.objective_value,
            solution=base.solution,
            solve_time=base.solve_time,
            timestamp=base.timestamp,
            solver_name=base.solver_name,
            solver_message=base.solver_message,
            portfolio_volatility=base.portfolio_volatility,
            metadata=base.metadata,
            adjusted_weights=d.get("adjusted_weights"),
            all_limits_satisfied=d.get("all_limits_satisfied"),
            violations=d.get("violations"),
        )

    def __repr__(self) -> str:
        parts = [f"RiskBudgetResult(status={self.status.value}"]
        if self.all_limits_satisfied is not None:
            parts.append(f", limits_ok={self.all_limits_satisfied}")
        if self.portfolio_volatility is not None:
            parts.append(f", vol={self.portfolio_volatility:.4f}")
        parts.append(")")
        return "".join(parts)
