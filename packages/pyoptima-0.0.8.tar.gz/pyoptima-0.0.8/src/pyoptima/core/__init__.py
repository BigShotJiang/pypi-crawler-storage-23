"""
PyOptima Core Module.

Contains core abstractions: protocols, problem definitions, and results.
"""

from pyoptima.core.problem import Maximize, Minimize, Problem
from pyoptima.core.protocols import Constraint, Objective, Solver
from pyoptima.core.result import (
    ExecutionResult,
    OptimizationResult,
    PortfolioResult,
    RebalanceResult,
    RiskBudgetResult,
    SignalSizingResult,
    SolverStatus,
)

__all__ = [
    # Protocols
    "Objective",
    "Constraint",
    "Solver",
    # Results
    "OptimizationResult",
    "PortfolioResult",
    "ExecutionResult",
    "RebalanceResult",
    "SignalSizingResult",
    "RiskBudgetResult",
    "SolverStatus",
    # Problem definition
    "Problem",
    "Minimize",
    "Maximize",
]
