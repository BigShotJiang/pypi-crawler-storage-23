"""
Portfolio optimization objectives.

Each objective builds real mathematical expressions on :class:`AbstractModel`.
All 31 portfolio objectives are supported.

Groups:
- Efficient Frontier: MinVolatility, MaxSharpe, MaxReturn, EfficientReturn,
  EfficientRisk, MaxUtility
- CVaR / CDaR / Semivariance: MinCVaR, MinCDaR, MinSemivariance, and their
  efficient-frontier variants
- Black-Litterman: BlackLittermanMaxSharpe, BlackLittermanMinVolatility,
  BlackLittermanQuadraticUtility
- CLA / Hierarchical: CLAMinVolatility, CLAMaxSharpe,
  HierarchicalMinVolatility, HierarchicalMaxSharpe
- Diversification / Risk Parity: MaxDiversification, MaxDiversificationIndex,
  RiskParity, EqualRiskContribution
- Transaction-Cost-Aware: MaxSharpeWithCosts, MinVolatilityWithCosts
- Momentum-Filtered: MomentumFilteredMaxSharpe, MomentumFilteredMinVolatility
- Factor-Based: FactorBasedSelection
"""

from typing import TYPE_CHECKING, Any

import numpy as np

from pyoptima.objectives.base import BaseObjective

if TYPE_CHECKING:
    from pyoptima.model.core import AbstractModel


# =============================================================================
# Helpers
# =============================================================================


def _variance_expression(cov: np.ndarray, n: int):
    """Build w' * Sigma * w quadratic expression."""
    from pyoptima.model.core import Expression

    expr = Expression()
    for i in range(n):
        for j in range(n):
            c = float(cov[i, j])
            if c != 0.0:
                expr.add_term(c, f"w_{i}", f"w_{j}")
    return expr


def _return_expression(expected_returns: np.ndarray, n: int):
    """Build mu' * w linear expression."""
    from pyoptima.model.core import Expression

    expr = Expression()
    for i in range(n):
        expr.add_term(float(expected_returns[i]), f"w_{i}")
    return expr


def _get_n_and_arrays(data: dict[str, Any]):
    """Extract n_assets, covariance, expected_returns from data dict."""
    symbols = data.get("symbols", [])
    n = len(symbols) if symbols else data.get("n_assets", 0)
    cov = data.get("covariance_matrix")
    er = data.get("expected_returns")
    if cov is not None:
        cov = np.array(cov)
        if n == 0:
            n = cov.shape[0]
    if er is not None:
        er = np.array(er)
        if n == 0:
            n = len(er)
    return n, cov, er


# =============================================================================
# Efficient Frontier objectives (6)
# =============================================================================


class MinVolatility(BaseObjective):
    """
    Minimize portfolio volatility (variance).

    .. math:: \\min_w \\; w^T \\Sigma w

    Example::

        objective = MinVolatility()
    """

    name = "min_volatility"
    sense = "minimize"

    def __init__(self):
        pass

    def _build(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        n, cov, _ = _get_n_and_arrays(data)
        if cov is None:
            raise ValueError("MinVolatility requires 'covariance_matrix' in data")
        model.minimize(_variance_expression(cov, n))


class MaxSharpe(BaseObjective):
    """
    Maximize Sharpe ratio.

    Uses the standard linearization trick: introduce scaled weights
    ``y_i = w_i / k`` and variable ``k = 1 / (mu - rf)' w``, then
    minimize variance of ``y`` subject to ``(mu - rf)' y = 1``.

    For the AbstractModel representation we store the objective and
    the extra constraint; the solver layer handles translation.

    Example::

        objective = MaxSharpe(risk_free_rate=0.02)
    """

    name = "max_sharpe"
    sense = "maximize"

    def __init__(self, risk_free_rate: float = 0.0):
        self.risk_free_rate = risk_free_rate

    def _build(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        from pyoptima.model.core import Expression

        n, cov, er = _get_n_and_arrays(data)
        if cov is None or er is None:
            raise ValueError(
                "MaxSharpe requires 'covariance_matrix' and 'expected_returns' in data"
            )

        excess = er - self.risk_free_rate

        # Simple approach: maximize (mu'w) / sqrt(w'Sigma w)
        # Linearization: min w'Sigma w  s.t. (mu-rf)'w = 1, w >= 0
        # Then rescale. Store metadata for solver to handle.
        # For AbstractModel: minimize variance, add return normalization.
        model.minimize(_variance_expression(cov, n))

        # Add excess return normalization: excess' w = 1
        norm_expr = Expression()
        for i in range(n):
            norm_expr.add_term(float(excess[i]), f"w_{i}")
        model.add_eq_constraint("sharpe_normalization", norm_expr, 1.0)

        # Store metadata for result rescaling
        model.add_parameter("_sharpe_rf", self.risk_free_rate)
        model.add_parameter("_sharpe_excess", excess.tolist())
        model.add_parameter("_objective_type", "max_sharpe")


class MaxReturn(BaseObjective):
    """
    Maximize expected return.

    .. math:: \\max_w \\; \\mu^T w

    Example::

        objective = MaxReturn()
    """

    name = "max_return"
    sense = "maximize"

    def __init__(self):
        pass

    def _build(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        n, _, er = _get_n_and_arrays(data)
        if er is None:
            raise ValueError("MaxReturn requires 'expected_returns' in data")
        model.maximize(_return_expression(er, n))


class EfficientReturn(BaseObjective):
    """
    Minimize volatility for a target return.

    .. math::

        \\min_w \\; w^T \\Sigma w
        \\quad \\text{s.t.} \\quad \\mu^T w \\geq r_{\\text{target}}

    Example::

        objective = EfficientReturn(target_return=0.10)
    """

    name = "efficient_return"
    sense = "minimize"

    def __init__(self, target_return: float):
        self.target_return = target_return

    def _build(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        n, cov, er = _get_n_and_arrays(data)
        if cov is None:
            raise ValueError("EfficientReturn requires 'covariance_matrix' in data")
        if er is None:
            raise ValueError("EfficientReturn requires 'expected_returns' in data")

        model.minimize(_variance_expression(cov, n))
        model.add_geq_constraint(
            "target_return", _return_expression(er, n), self.target_return
        )


class EfficientRisk(BaseObjective):
    """
    Maximize return for a target volatility.

    .. math::

        \\max_w \\; \\mu^T w
        \\quad \\text{s.t.} \\quad w^T \\Sigma w \\leq \\sigma^2_{\\text{target}}

    Example::

        objective = EfficientRisk(target_volatility=0.15)
    """

    name = "efficient_risk"
    sense = "maximize"

    def __init__(self, target_volatility: float):
        self.target_volatility = target_volatility

    def _build(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        n, cov, er = _get_n_and_arrays(data)
        if cov is None or er is None:
            raise ValueError(
                "EfficientRisk requires 'covariance_matrix' and "
                "'expected_returns' in data"
            )

        model.maximize(_return_expression(er, n))
        model.add_leq_constraint(
            "target_volatility",
            _variance_expression(cov, n),
            self.target_volatility**2,
        )


class MaxUtility(BaseObjective):
    """
    Maximize quadratic utility: return - 0.5 * risk_aversion * variance.

    .. math:: \\max_w \\; \\mu^T w - \\frac{\\lambda}{2} w^T \\Sigma w

    Equivalent to minimizing ``(lambda/2) w'Sw - mu'w``.

    Example::

        objective = MaxUtility(risk_aversion=1.0)
    """

    name = "max_utility"
    sense = "maximize"

    def __init__(self, risk_aversion: float = 1.0):
        self.risk_aversion = risk_aversion

    def _build(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        from pyoptima.model.core import Expression

        n, cov, er = _get_n_and_arrays(data)
        if cov is None or er is None:
            raise ValueError(
                "MaxUtility requires 'covariance_matrix' and 'expected_returns' in data"
            )

        # minimize (lambda/2) w'Sw - mu'w  (negated maximize)
        expr = Expression()
        lam_half = self.risk_aversion / 2.0
        for i in range(n):
            for j in range(n):
                c = float(cov[i, j]) * lam_half
                if c != 0.0:
                    expr.add_term(c, f"w_{i}", f"w_{j}")
        for i in range(n):
            expr.add_term(-float(er[i]), f"w_{i}")
        model.minimize(expr)


# =============================================================================
# CVaR objectives (3)
# =============================================================================


class MinCVaR(BaseObjective):
    """
    Minimize Conditional Value at Risk.

    Requires historical returns in ``data["returns"]`` (T x n matrix).
    Uses Rockafellar-Uryasev linearization.

    Example::

        objective = MinCVaR(confidence=0.95)
    """

    name = "min_cvar"
    sense = "minimize"

    def __init__(self, confidence: float = 0.95):
        self.confidence = confidence

    def _build(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        from pyoptima.model.core import Expression

        returns = data.get("returns")
        if returns is None:
            raise ValueError("MinCVaR requires 'returns' in data")
        returns = np.array(returns)
        T, n = returns.shape
        alpha = 1.0 - self.confidence

        # VaR variable (zeta)
        model.add_continuous("cvar_zeta", lb=None, ub=None)

        # Auxiliary: u_t >= -(r_t' w) - zeta, u_t >= 0
        for t in range(T):
            model.add_continuous(f"cvar_u_{t}", lb=0.0)
            expr = Expression()
            for j in range(n):
                expr.add_term(-float(returns[t, j]), f"w_{j}")
            expr.add_term(-1.0, "cvar_zeta")
            expr.add_term(-1.0, f"cvar_u_{t}")
            model.add_leq_constraint(f"cvar_aux_{t}", expr, 0.0)

        # CVaR = zeta + (1/(T*alpha)) * sum(u_t)
        cvar_expr = Expression()
        cvar_expr.add_term(1.0, "cvar_zeta")
        scale = 1.0 / (T * alpha)
        for t in range(T):
            cvar_expr.add_term(scale, f"cvar_u_{t}")
        model.minimize(cvar_expr)


class EfficientCVaRRisk(BaseObjective):
    """
    Maximize return for a target CVaR.

    Example::

        objective = EfficientCVaRRisk(target_cvar=0.05, confidence=0.95)
    """

    name = "efficient_cvar_risk"
    sense = "maximize"

    def __init__(self, target_cvar: float, confidence: float = 0.95):
        self.target_cvar = target_cvar
        self.confidence = confidence

    def _build(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        from pyoptima.model.core import Expression

        returns = data.get("returns")
        if returns is None:
            raise ValueError("EfficientCVaRRisk requires 'returns' in data")
        returns = np.array(returns)
        T, n = returns.shape
        alpha = 1.0 - self.confidence

        n_a, _, er = _get_n_and_arrays(data)
        if er is None:
            raise ValueError("EfficientCVaRRisk requires 'expected_returns' in data")

        # Maximize expected return
        model.maximize(_return_expression(er, n))

        # CVaR <= target_cvar
        model.add_continuous("cvar_zeta", lb=None, ub=None)
        for t in range(T):
            model.add_continuous(f"cvar_u_{t}", lb=0.0)
            expr = Expression()
            for j in range(n):
                expr.add_term(-float(returns[t, j]), f"w_{j}")
            expr.add_term(-1.0, "cvar_zeta")
            expr.add_term(-1.0, f"cvar_u_{t}")
            model.add_leq_constraint(f"cvar_aux_{t}", expr, 0.0)

        cvar_expr = Expression()
        cvar_expr.add_term(1.0, "cvar_zeta")
        scale = 1.0 / (T * alpha)
        for t in range(T):
            cvar_expr.add_term(scale, f"cvar_u_{t}")
        model.add_leq_constraint("target_cvar", cvar_expr, self.target_cvar)


class EfficientCVaRReturn(BaseObjective):
    """
    Minimize CVaR for a target return.

    Example::

        objective = EfficientCVaRReturn(target_return=0.10, confidence=0.95)
    """

    name = "efficient_cvar_return"
    sense = "minimize"

    def __init__(self, target_return: float, confidence: float = 0.95):
        self.target_return = target_return
        self.confidence = confidence

    def _build(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        from pyoptima.model.core import Expression

        returns = data.get("returns")
        if returns is None:
            raise ValueError("EfficientCVaRReturn requires 'returns' in data")
        returns = np.array(returns)
        T, n = returns.shape
        alpha = 1.0 - self.confidence

        n_a, _, er = _get_n_and_arrays(data)
        if er is None:
            raise ValueError("EfficientCVaRReturn requires 'expected_returns' in data")

        # Return constraint
        model.add_geq_constraint(
            "target_return", _return_expression(er, n), self.target_return
        )

        # Minimize CVaR
        model.add_continuous("cvar_zeta", lb=None, ub=None)
        for t in range(T):
            model.add_continuous(f"cvar_u_{t}", lb=0.0)
            expr = Expression()
            for j in range(n):
                expr.add_term(-float(returns[t, j]), f"w_{j}")
            expr.add_term(-1.0, "cvar_zeta")
            expr.add_term(-1.0, f"cvar_u_{t}")
            model.add_leq_constraint(f"cvar_aux_{t}", expr, 0.0)

        cvar_expr = Expression()
        cvar_expr.add_term(1.0, "cvar_zeta")
        scale = 1.0 / (T * alpha)
        for t in range(T):
            cvar_expr.add_term(scale, f"cvar_u_{t}")
        model.minimize(cvar_expr)


# =============================================================================
# CDaR objectives (3)
# =============================================================================


class MinCDaR(BaseObjective):
    """
    Minimize Conditional Drawdown at Risk.

    Requires ``data["returns"]`` (T x n historical returns matrix).

    Example::

        objective = MinCDaR(confidence=0.95)
    """

    name = "min_cdar"
    sense = "minimize"

    def __init__(self, confidence: float = 0.95):
        self.confidence = confidence

    def _build(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        from pyoptima.model.core import Expression

        returns = data.get("returns")
        if returns is None:
            raise ValueError("MinCDaR requires 'returns' in data")
        returns = np.array(returns)
        T, n = returns.shape
        alpha = 1.0 - self.confidence

        # Peak variable and drawdown auxiliaries
        model.add_continuous("cdar_zeta", lb=None, ub=None)  # VaR for drawdown

        for t in range(T):
            # Cumulative return up to t: sum_{s<=t} r_s' w
            model.add_continuous(f"cdar_cumret_{t}", lb=None, ub=None)
            model.add_continuous(f"cdar_peak_{t}", lb=0.0)
            model.add_continuous(f"cdar_dd_{t}", lb=0.0)
            model.add_continuous(f"cdar_u_{t}", lb=0.0)

            # cumret_t = sum_{s=0..t} r_s' w
            cr_expr = Expression()
            for s in range(t + 1):
                for j in range(n):
                    cr_expr.add_term(float(returns[s, j]), f"w_{j}")
            cr_expr.add_term(-1.0, f"cdar_cumret_{t}")
            model.add_eq_constraint(f"cdar_cumret_def_{t}", cr_expr, 0.0)

            # peak_t >= cumret_s for all s <= t  (simplified: peak_t >= cumret_t)
            if t == 0:
                pk_expr = Expression()
                pk_expr.add_term(1.0, f"cdar_peak_{t}")
                pk_expr.add_term(-1.0, f"cdar_cumret_{t}")
                model.add_geq_constraint(f"cdar_peak_ge_cr_{t}", pk_expr, 0.0)
            else:
                # peak_t >= peak_{t-1}
                pk_prev = Expression()
                pk_prev.add_term(1.0, f"cdar_peak_{t}")
                pk_prev.add_term(-1.0, f"cdar_peak_{t - 1}")
                model.add_geq_constraint(f"cdar_peak_ge_prev_{t}", pk_prev, 0.0)
                # peak_t >= cumret_t
                pk_cr = Expression()
                pk_cr.add_term(1.0, f"cdar_peak_{t}")
                pk_cr.add_term(-1.0, f"cdar_cumret_{t}")
                model.add_geq_constraint(f"cdar_peak_ge_cr_{t}", pk_cr, 0.0)

            # dd_t >= peak_t - cumret_t
            dd_expr = Expression()
            dd_expr.add_term(1.0, f"cdar_dd_{t}")
            dd_expr.add_term(-1.0, f"cdar_peak_{t}")
            dd_expr.add_term(1.0, f"cdar_cumret_{t}")
            model.add_geq_constraint(f"cdar_dd_def_{t}", dd_expr, 0.0)

            # u_t >= dd_t - zeta
            u_expr = Expression()
            u_expr.add_term(1.0, f"cdar_u_{t}")
            u_expr.add_term(-1.0, f"cdar_dd_{t}")
            u_expr.add_term(1.0, "cdar_zeta")
            model.add_geq_constraint(f"cdar_u_def_{t}", u_expr, 0.0)

        # CDaR = zeta + (1/(T*alpha)) * sum(u_t)
        cdar_expr = Expression()
        cdar_expr.add_term(1.0, "cdar_zeta")
        scale = 1.0 / (T * alpha)
        for t in range(T):
            cdar_expr.add_term(scale, f"cdar_u_{t}")
        model.minimize(cdar_expr)


class EfficientCDaRRisk(BaseObjective):
    """
    Maximize return for a target CDaR.

    Example::

        objective = EfficientCDaRRisk(target_cdar=0.05, confidence=0.95)
    """

    name = "efficient_cdar_risk"
    sense = "maximize"

    def __init__(self, target_cdar: float, confidence: float = 0.95):
        self.target_cdar = target_cdar
        self.confidence = confidence

    def _build(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        n, _, er = _get_n_and_arrays(data)
        if er is None:
            raise ValueError("EfficientCDaRRisk requires 'expected_returns'")

        # Build CDaR formulation as constraint
        _build_cdar_constraint(model, data, self.confidence, self.target_cdar)
        model.maximize(_return_expression(er, n))


class EfficientCDaRReturn(BaseObjective):
    """
    Minimize CDaR for a target return.

    Example::

        objective = EfficientCDaRReturn(target_return=0.10, confidence=0.95)
    """

    name = "efficient_cdar_return"
    sense = "minimize"

    def __init__(self, target_return: float, confidence: float = 0.95):
        self.target_return = target_return
        self.confidence = confidence

    def _build(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        n, _, er = _get_n_and_arrays(data)
        if er is None:
            raise ValueError("EfficientCDaRReturn requires 'expected_returns'")

        # Return constraint
        model.add_geq_constraint(
            "target_return", _return_expression(er, n), self.target_return
        )

        # Minimize CDaR (build full formulation as objective)
        obj = MinCDaR(confidence=self.confidence)
        obj._build(model, data)


def _build_cdar_constraint(model, data, confidence, target_cdar):
    """Build CDaR <= target as a constraint (used by efficient variants)."""
    from pyoptima.model.core import Expression

    returns = data.get("returns")
    if returns is None:
        raise ValueError("CDaR objectives require 'returns' in data")
    returns = np.array(returns)
    T, n = returns.shape
    alpha = 1.0 - confidence

    model.add_continuous("cdar_zeta", lb=None, ub=None)
    for t in range(T):
        model.add_continuous(f"cdar_cumret_{t}", lb=None, ub=None)
        model.add_continuous(f"cdar_peak_{t}", lb=0.0)
        model.add_continuous(f"cdar_dd_{t}", lb=0.0)
        model.add_continuous(f"cdar_u_{t}", lb=0.0)

        cr_expr = Expression()
        for s in range(t + 1):
            for j in range(n):
                cr_expr.add_term(float(returns[s, j]), f"w_{j}")
        cr_expr.add_term(-1.0, f"cdar_cumret_{t}")
        model.add_eq_constraint(f"cdar_cumret_def_{t}", cr_expr, 0.0)

        if t == 0:
            pk_expr = Expression()
            pk_expr.add_term(1.0, f"cdar_peak_{t}")
            pk_expr.add_term(-1.0, f"cdar_cumret_{t}")
            model.add_geq_constraint(f"cdar_peak_ge_cr_{t}", pk_expr, 0.0)
        else:
            pk_prev = Expression()
            pk_prev.add_term(1.0, f"cdar_peak_{t}")
            pk_prev.add_term(-1.0, f"cdar_peak_{t - 1}")
            model.add_geq_constraint(f"cdar_peak_ge_prev_{t}", pk_prev, 0.0)
            pk_cr = Expression()
            pk_cr.add_term(1.0, f"cdar_peak_{t}")
            pk_cr.add_term(-1.0, f"cdar_cumret_{t}")
            model.add_geq_constraint(f"cdar_peak_ge_cr_{t}", pk_cr, 0.0)

        dd_expr = Expression()
        dd_expr.add_term(1.0, f"cdar_dd_{t}")
        dd_expr.add_term(-1.0, f"cdar_peak_{t}")
        dd_expr.add_term(1.0, f"cdar_cumret_{t}")
        model.add_geq_constraint(f"cdar_dd_def_{t}", dd_expr, 0.0)

        u_expr = Expression()
        u_expr.add_term(1.0, f"cdar_u_{t}")
        u_expr.add_term(-1.0, f"cdar_dd_{t}")
        u_expr.add_term(1.0, "cdar_zeta")
        model.add_geq_constraint(f"cdar_u_def_{t}", u_expr, 0.0)

    cdar_expr = Expression()
    cdar_expr.add_term(1.0, "cdar_zeta")
    scale = 1.0 / (T * alpha)
    for t in range(T):
        cdar_expr.add_term(scale, f"cdar_u_{t}")
    model.add_leq_constraint("target_cdar", cdar_expr, target_cdar)


# =============================================================================
# Semivariance objectives (3)
# =============================================================================


class MinSemivariance(BaseObjective):
    """
    Minimize semivariance (downside risk).

    Requires ``data["returns"]`` (T x n matrix).

    Example::

        objective = MinSemivariance(benchmark=0.0)
    """

    name = "min_semivariance"
    sense = "minimize"

    def __init__(self, benchmark: float = 0.0):
        self.benchmark = benchmark

    def _build(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        from pyoptima.model.core import Expression

        returns = data.get("returns")
        if returns is None:
            raise ValueError("MinSemivariance requires 'returns' in data")
        returns = np.array(returns)
        T, n = returns.shape

        # d_t >= benchmark - r_t' w, d_t >= 0
        for t in range(T):
            model.add_continuous(f"sv_d_{t}", lb=0.0)
            expr = Expression()
            for j in range(n):
                expr.add_term(-float(returns[t, j]), f"w_{j}")
            expr.add_term(-1.0, f"sv_d_{t}")
            model.add_leq_constraint(f"sv_aux_{t}", expr, -self.benchmark)

        # Semivariance = (1/T) * sum(d_t^2) — quadratic objective
        sv_expr = Expression()
        scale = 1.0 / T
        for t in range(T):
            sv_expr.add_term(scale, f"sv_d_{t}", f"sv_d_{t}")
        model.minimize(sv_expr)


class EfficientSemivarianceRisk(BaseObjective):
    """
    Maximize return for a target semivariance.

    Example::

        objective = EfficientSemivarianceRisk(target_semivariance=0.01, benchmark=0.0)
    """

    name = "efficient_semivariance_risk"
    sense = "maximize"

    def __init__(self, target_semivariance: float, benchmark: float = 0.0):
        self.target_semivariance = target_semivariance
        self.benchmark = benchmark

    def _build(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        from pyoptima.model.core import Expression

        returns = data.get("returns")
        if returns is None:
            raise ValueError("EfficientSemivarianceRisk requires 'returns'")
        returns = np.array(returns)
        T, n = returns.shape
        n_a, _, er = _get_n_and_arrays(data)
        if er is None:
            raise ValueError("EfficientSemivarianceRisk requires 'expected_returns'")

        model.maximize(_return_expression(er, n))

        # Semivariance constraint
        for t in range(T):
            model.add_continuous(f"sv_d_{t}", lb=0.0)
            expr = Expression()
            for j in range(n):
                expr.add_term(-float(returns[t, j]), f"w_{j}")
            expr.add_term(-1.0, f"sv_d_{t}")
            model.add_leq_constraint(f"sv_aux_{t}", expr, -self.benchmark)

        sv_expr = Expression()
        scale = 1.0 / T
        for t in range(T):
            sv_expr.add_term(scale, f"sv_d_{t}", f"sv_d_{t}")
        model.add_leq_constraint(
            "target_semivariance", sv_expr, self.target_semivariance
        )


class EfficientSemivarianceReturn(BaseObjective):
    """
    Minimize semivariance for a target return.

    Example::

        objective = EfficientSemivarianceReturn(target_return=0.10, benchmark=0.0)
    """

    name = "efficient_semivariance_return"
    sense = "minimize"

    def __init__(self, target_return: float, benchmark: float = 0.0):
        self.target_return = target_return
        self.benchmark = benchmark

    def _build(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        n_a, _, er = _get_n_and_arrays(data)
        if er is None:
            raise ValueError("EfficientSemivarianceReturn requires 'expected_returns'")

        model.add_geq_constraint(
            "target_return", _return_expression(er, n_a), self.target_return
        )
        obj = MinSemivariance(benchmark=self.benchmark)
        obj._build(model, data)


# =============================================================================
# Black-Litterman objectives (3)
# =============================================================================


def _compute_bl_returns(data: dict[str, Any]):
    """Compute Black-Litterman posterior returns from data."""
    cov = np.array(data["covariance_matrix"])
    market_caps = data.get("market_caps")
    views = data.get("views")
    view_confidences = data.get("view_confidences")
    risk_aversion = data.get("risk_aversion", 2.5)
    tau = data.get("tau", 0.05)

    n = cov.shape[0]

    # Equilibrium returns: pi = delta * Sigma * w_mkt
    if market_caps is not None:
        mc = np.array(market_caps, dtype=float)
        w_mkt = mc / mc.sum()
    else:
        w_mkt = np.ones(n) / n
    pi = risk_aversion * cov @ w_mkt

    if views is None:
        return pi, cov

    # P (pick matrix), Q (view returns)
    P = np.array(views.get("P", np.eye(n)))
    Q = np.array(views.get("Q", pi))

    if view_confidences is not None:
        omega = np.diag(np.array(view_confidences, dtype=float))
    else:
        omega = np.diag(np.diag(tau * P @ cov @ P.T))

    # Posterior: mu_bl = [(tau*Sigma)^-1 + P'*Omega^-1*P]^-1 *
    #                    [(tau*Sigma)^-1 * pi + P'*Omega^-1 * Q]
    tau_cov_inv = np.linalg.inv(tau * cov)
    omega_inv = np.linalg.inv(omega)
    M = np.linalg.inv(tau_cov_inv + P.T @ omega_inv @ P)
    mu_bl = M @ (tau_cov_inv @ pi + P.T @ omega_inv @ Q)
    cov_bl = cov + M

    return mu_bl, cov_bl


class BlackLittermanMaxSharpe(BaseObjective):
    """
    Black-Litterman optimization for max Sharpe.

    Requires ``data["market_caps"]`` and optionally ``data["views"]``.

    Example::

        objective = BlackLittermanMaxSharpe(risk_free_rate=0.02)
    """

    name = "black_litterman_max_sharpe"
    sense = "maximize"

    def __init__(self, risk_free_rate: float = 0.0):
        self.risk_free_rate = risk_free_rate

    def _build(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        mu_bl, cov_bl = _compute_bl_returns(data)
        bl_data = {
            **data,
            "expected_returns": mu_bl.tolist(),
            "covariance_matrix": cov_bl.tolist(),
        }
        obj = MaxSharpe(risk_free_rate=self.risk_free_rate)
        obj._build(model, bl_data)


class BlackLittermanMinVolatility(BaseObjective):
    """
    Black-Litterman optimization for min volatility.

    Uses BL posterior covariance.
    """

    name = "black_litterman_min_volatility"
    sense = "minimize"

    def __init__(self):
        pass

    def _build(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        _, cov_bl = _compute_bl_returns(data)
        bl_data = {**data, "covariance_matrix": cov_bl.tolist()}
        obj = MinVolatility()
        obj._build(model, bl_data)


class BlackLittermanQuadraticUtility(BaseObjective):
    """
    Black-Litterman with quadratic utility.

    Example::

        objective = BlackLittermanQuadraticUtility(risk_aversion=1.0)
    """

    name = "black_litterman_quadratic_utility"
    sense = "maximize"

    def __init__(self, risk_aversion: float = 1.0):
        self.risk_aversion = risk_aversion

    def _build(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        mu_bl, cov_bl = _compute_bl_returns(data)
        bl_data = {
            **data,
            "expected_returns": mu_bl.tolist(),
            "covariance_matrix": cov_bl.tolist(),
        }
        obj = MaxUtility(risk_aversion=self.risk_aversion)
        obj._build(model, bl_data)


# =============================================================================
# CLA objectives (2) — algorithmic, not optimization-model-based
# =============================================================================


class CLAMinVolatility(BaseObjective):
    """
    Critical Line Algorithm for minimum volatility.

    CLA is an algorithmic solver, not model-based. The ``_build()``
    method stores metadata; the template/solver handles the algorithm.

    Example::

        objective = CLAMinVolatility()
    """

    name = "cla_min_volatility"
    sense = "minimize"

    def __init__(self):
        pass

    def _build(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        model.add_parameter("_objective_type", "cla_min_volatility")
        n, cov, _ = _get_n_and_arrays(data)
        if cov is not None:
            model.minimize(_variance_expression(cov, n))


class CLAMaxSharpe(BaseObjective):
    """
    Critical Line Algorithm for maximum Sharpe.

    Example::

        objective = CLAMaxSharpe(risk_free_rate=0.02)
    """

    name = "cla_max_sharpe"
    sense = "maximize"

    def __init__(self, risk_free_rate: float = 0.0):
        self.risk_free_rate = risk_free_rate

    def _build(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        model.add_parameter("_objective_type", "cla_max_sharpe")
        model.add_parameter("_sharpe_rf", self.risk_free_rate)
        n, cov, er = _get_n_and_arrays(data)
        if cov is not None and er is not None:
            # Store for the solver but build a Sharpe-like proxy
            model.minimize(_variance_expression(cov, n))


# =============================================================================
# Hierarchical Risk Parity objectives (2) — algorithmic
# =============================================================================


class HierarchicalMinVolatility(BaseObjective):
    """
    Hierarchical Risk Parity for minimum volatility.

    HRP is an algorithmic solver. ``_build()`` stores metadata.
    """

    name = "hierarchical_min_volatility"
    sense = "minimize"

    def __init__(self):
        pass

    def _build(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        model.add_parameter("_objective_type", "hierarchical_min_volatility")
        n, cov, _ = _get_n_and_arrays(data)
        if cov is not None:
            model.minimize(_variance_expression(cov, n))


class HierarchicalMaxSharpe(BaseObjective):
    """
    Hierarchical Risk Parity for maximum Sharpe.

    Example::

        objective = HierarchicalMaxSharpe(risk_free_rate=0.02)
    """

    name = "hierarchical_max_sharpe"
    sense = "maximize"

    def __init__(self, risk_free_rate: float = 0.0):
        self.risk_free_rate = risk_free_rate

    def _build(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        model.add_parameter("_objective_type", "hierarchical_max_sharpe")
        model.add_parameter("_sharpe_rf", self.risk_free_rate)
        n, cov, _ = _get_n_and_arrays(data)
        if cov is not None:
            model.minimize(_variance_expression(cov, n))


# =============================================================================
# Diversification objectives (2)
# =============================================================================


class MaxDiversification(BaseObjective):
    """
    Maximize diversification ratio.

    .. math::

        \\text{DR} = \\frac{\\sum_i w_i \\sigma_i}{\\sqrt{w^T \\Sigma w}}

    Linearized as: minimize ``w' Sigma w`` subject to
    ``sum_i w_i * sigma_i = 1`` (then rescale).

    Example::

        objective = MaxDiversification()
    """

    name = "max_diversification"
    sense = "maximize"

    def __init__(self):
        pass

    def _build(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        from pyoptima.model.core import Expression

        n, cov, _ = _get_n_and_arrays(data)
        if cov is None:
            raise ValueError("MaxDiversification requires 'covariance_matrix'")

        vols = np.sqrt(np.diag(cov))

        # Minimize w'Sigma w s.t. sum(w_i * sigma_i) = 1
        model.minimize(_variance_expression(cov, n))

        norm_expr = Expression()
        for i in range(n):
            norm_expr.add_term(float(vols[i]), f"w_{i}")
        model.add_eq_constraint("diversification_normalization", norm_expr, 1.0)
        model.add_parameter("_objective_type", "max_diversification")


class MaxDiversificationIndex(BaseObjective):
    """
    Maximize diversification index.

    Alias for MaxDiversification with different naming.
    """

    name = "max_diversification_index"
    sense = "maximize"

    def __init__(self):
        pass

    def _build(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        obj = MaxDiversification()
        obj._build(model, data)
        model.add_parameter("_objective_type", "max_diversification_index")


# =============================================================================
# Risk Parity objectives (2)
# =============================================================================


class RiskParity(BaseObjective):
    """
    Risk parity: equal risk contribution from all assets.

    Minimizes sum of squared differences in risk contributions:

    .. math::

        \\min_w \\sum_{i,j} (w_i (\\Sigma w)_i - w_j (\\Sigma w)_j)^2

    This is a non-convex objective; ``_build()`` stores metadata
    and a variance proxy for the solver to handle via sequential QP
    or scipy.

    Example::

        objective = RiskParity()
    """

    name = "risk_parity"
    sense = "minimize"

    def __init__(self):
        pass

    def _build(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        n, cov, _ = _get_n_and_arrays(data)
        if cov is None:
            raise ValueError("RiskParity requires 'covariance_matrix'")

        # Risk parity is non-convex; store metadata for solver dispatch
        model.add_parameter("_objective_type", "risk_parity")
        model.add_parameter("_covariance_matrix", cov.tolist())
        # Set a variance proxy objective for model completeness
        model.minimize(_variance_expression(cov, n))


class EqualRiskContribution(BaseObjective):
    """
    Equal risk contribution (alias for risk parity).

    Example::

        objective = EqualRiskContribution()
    """

    name = "equal_risk_contribution"
    sense = "minimize"

    def __init__(self):
        pass

    def _build(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        obj = RiskParity()
        obj._build(model, data)
        model.add_parameter("_objective_type", "equal_risk_contribution")


# =============================================================================
# Transaction cost-aware objectives (2)
# =============================================================================


class MaxSharpeWithCosts(BaseObjective):
    """
    Maximize Sharpe ratio accounting for transaction costs.

    Net return = expected return - transaction costs.
    Requires ``data["transaction_costs"]`` and ``data["current_weights"]``.

    Example::

        objective = MaxSharpeWithCosts(risk_free_rate=0.02)
    """

    name = "max_sharpe_with_costs"
    sense = "maximize"

    def __init__(self, risk_free_rate: float = 0.0):
        self.risk_free_rate = risk_free_rate

    def _build(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        from pyoptima.model.core import Expression

        n, cov, er = _get_n_and_arrays(data)
        if cov is None or er is None:
            raise ValueError(
                "MaxSharpeWithCosts requires 'covariance_matrix' and 'expected_returns'"
            )

        tc = data.get("transaction_costs", 0.0)
        cw = data.get("current_weights", {})
        symbols = data.get("symbols", [])

        if isinstance(tc, (int, float)):
            tc_arr = np.full(n, tc)
        else:
            tc_arr = np.array([tc.get(s, 0.0) for s in symbols])
        if isinstance(cw, dict):
            cw_arr = np.array([cw.get(s, 0.0) for s in symbols])
        else:
            cw_arr = np.array(cw) if cw else np.zeros(n)

        # Store metadata for the solver
        model.add_parameter("_objective_type", "max_sharpe_with_costs")
        model.add_parameter("_sharpe_rf", self.risk_free_rate)
        model.add_parameter("_transaction_costs", tc_arr.tolist())
        model.add_parameter("_current_weights", cw_arr.tolist())

        # Build variance objective (Sharpe linearization)
        model.minimize(_variance_expression(cov, n))

        # Net excess return normalization: (mu - tc*|dw|) - rf  ≈  (mu - rf)'w = 1
        # Approximate: ignore |dw| in normalization, store costs for solver
        excess = er - self.risk_free_rate
        norm_expr = Expression()
        for i in range(n):
            norm_expr.add_term(float(excess[i]), f"w_{i}")
        model.add_eq_constraint("sharpe_normalization", norm_expr, 1.0)


class MinVolatilityWithCosts(BaseObjective):
    """
    Minimize volatility accounting for transaction costs.

    Adds a transaction cost penalty to the variance objective.

    Example::

        objective = MinVolatilityWithCosts()
    """

    name = "min_volatility_with_costs"
    sense = "minimize"

    def __init__(self):
        pass

    def _build(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        n, cov, _ = _get_n_and_arrays(data)
        if cov is None:
            raise ValueError("MinVolatilityWithCosts requires 'covariance_matrix'")

        tc = data.get("transaction_costs", 0.0)
        symbols = data.get("symbols", [])

        if isinstance(tc, (int, float)):
            tc_arr = np.full(n, tc)
        else:
            tc_arr = np.array([tc.get(s, 0.0) for s in symbols])

        model.add_parameter("_objective_type", "min_volatility_with_costs")
        model.add_parameter("_transaction_costs", tc_arr.tolist())

        # Minimize variance (costs handled as metadata for solver)
        model.minimize(_variance_expression(cov, n))


# =============================================================================
# Momentum-filtered objectives (2)
# =============================================================================


class MomentumFilteredMaxSharpe(BaseObjective):
    """
    Filter by momentum, then maximize Sharpe.

    Requires ``data["returns"]`` for momentum calculation.
    Assets with negative momentum are excluded (weight forced to 0).

    Example::

        objective = MomentumFilteredMaxSharpe(risk_free_rate=0.02)
    """

    name = "momentum_filtered_max_sharpe"
    sense = "maximize"

    def __init__(self, risk_free_rate: float = 0.0):
        self.risk_free_rate = risk_free_rate

    def _build(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        n, cov, er = _get_n_and_arrays(data)
        returns = data.get("returns")
        if returns is None or er is None or cov is None:
            raise ValueError(
                "MomentumFilteredMaxSharpe requires 'returns', "
                "'expected_returns', and 'covariance_matrix'"
            )
        returns = np.array(returns)

        # Compute momentum (cumulative return over lookback)
        lookback = data.get("momentum_lookback", returns.shape[0])
        momentum = returns[-lookback:].sum(axis=0)

        # Exclude negative-momentum assets
        for i in range(n):
            if momentum[i] < 0:
                var = model.get_variable(f"w_{i}")
                if var is not None:
                    var.lower_bound = 0.0
                    var.upper_bound = 0.0

        model.add_parameter("_objective_type", "momentum_filtered_max_sharpe")

        # Build Sharpe objective on filtered universe
        obj = MaxSharpe(risk_free_rate=self.risk_free_rate)
        obj._build(model, data)


class MomentumFilteredMinVolatility(BaseObjective):
    """
    Filter by momentum, then minimize volatility.

    Assets with negative momentum are excluded.
    """

    name = "momentum_filtered_min_volatility"
    sense = "minimize"

    def __init__(self):
        pass

    def _build(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        n, cov, _ = _get_n_and_arrays(data)
        returns = data.get("returns")
        if returns is None or cov is None:
            raise ValueError(
                "MomentumFilteredMinVolatility requires 'returns' and "
                "'covariance_matrix'"
            )
        returns = np.array(returns)

        lookback = data.get("momentum_lookback", returns.shape[0])
        momentum = returns[-lookback:].sum(axis=0)

        for i in range(n):
            if momentum[i] < 0:
                var = model.get_variable(f"w_{i}")
                if var is not None:
                    var.lower_bound = 0.0
                    var.upper_bound = 0.0

        model.add_parameter("_objective_type", "momentum_filtered_min_volatility")
        model.minimize(_variance_expression(cov, n))


# =============================================================================
# Factor-based objective (1)
# =============================================================================


class FactorBasedSelection(BaseObjective):
    """
    Select assets based on factor scores.

    Requires ``data["factor_data"]`` — dict mapping factor names to
    dicts of symbol → score.

    Maximizes weighted sum of normalized factor scores.

    Example::

        objective = FactorBasedSelection()
    """

    name = "factor_based_selection"
    sense = "maximize"

    def __init__(self):
        pass

    def _build(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        from pyoptima.model.core import Expression

        n, _, _ = _get_n_and_arrays(data)
        symbols = data.get("symbols", [])
        factor_data = data.get("factor_data", {})
        factor_weights = data.get("factor_weights", {})

        if not factor_data:
            raise ValueError("FactorBasedSelection requires 'factor_data'")

        # Compute composite score per asset
        composite = np.zeros(n)
        for factor_name, scores in factor_data.items():
            weight = factor_weights.get(factor_name, 1.0)
            raw = np.array([scores.get(s, 0.0) for s in symbols])
            std = raw.std()
            if std > 0:
                normalized = (raw - raw.mean()) / std
            else:
                normalized = raw
            composite += weight * normalized

        # Maximize sum(w_i * composite_i)
        expr = Expression()
        for i in range(n):
            if composite[i] != 0.0:
                expr.add_term(float(composite[i]), f"w_{i}")
        model.maximize(expr)
        model.add_parameter("_objective_type", "factor_based_selection")
