"""
PyOptima Objectives Module.

Composable optimization objectives that build real mathematical
expressions on :class:`AbstractModel`.

All 31 portfolio objectives and 4 trading objectives are supported.

Usage::

    from pyoptima.objectives import MinVolatility, get_objective

    # By class
    obj = MinVolatility()
    obj.build(model, data)

    # By name (string registry)
    obj = get_objective("max_sharpe", risk_free_rate=0.02)
    obj.build(model, data)

    # List available
    names = list_objectives()
"""

from pyoptima.objectives.base import BaseObjective
from pyoptima.objectives.portfolio import (  # Efficient frontier; CVaR / CDaR / Semivariance; Black-Litterman; CLA / Hierarchical; Diversification / Risk parity; Transaction cost / Momentum / Factor
    BlackLittermanMaxSharpe,
    BlackLittermanMinVolatility,
    BlackLittermanQuadraticUtility,
    CLAMaxSharpe,
    CLAMinVolatility,
    EfficientCDaRReturn,
    EfficientCDaRRisk,
    EfficientCVaRReturn,
    EfficientCVaRRisk,
    EfficientReturn,
    EfficientRisk,
    EfficientSemivarianceReturn,
    EfficientSemivarianceRisk,
    EqualRiskContribution,
    FactorBasedSelection,
    HierarchicalMaxSharpe,
    HierarchicalMinVolatility,
    MaxDiversification,
    MaxDiversificationIndex,
    MaxReturn,
    MaxSharpe,
    MaxSharpeWithCosts,
    MaxUtility,
    MinCDaR,
    MinCVaR,
    MinSemivariance,
    MinVolatility,
    MinVolatilityWithCosts,
    MomentumFilteredMaxSharpe,
    MomentumFilteredMinVolatility,
    RiskParity,
)
from pyoptima.objectives.trading import (
    LiquidityAdjustedMinVol,
    MinImplementationShortfall,
    MinMarketImpact,
    MinTrackingError,
)

# =============================================================================
# Objective registry: name -> class
# =============================================================================

OBJECTIVE_REGISTRY: dict[str, type[BaseObjective]] = {
    # Efficient frontier (6)
    "min_volatility": MinVolatility,
    "max_sharpe": MaxSharpe,
    "max_return": MaxReturn,
    "efficient_return": EfficientReturn,
    "efficient_risk": EfficientRisk,
    "max_utility": MaxUtility,
    # CVaR (3)
    "min_cvar": MinCVaR,
    "efficient_cvar_risk": EfficientCVaRRisk,
    "efficient_cvar_return": EfficientCVaRReturn,
    # CDaR (3)
    "min_cdar": MinCDaR,
    "efficient_cdar_risk": EfficientCDaRRisk,
    "efficient_cdar_return": EfficientCDaRReturn,
    # Semivariance (3)
    "min_semivariance": MinSemivariance,
    "efficient_semivariance_risk": EfficientSemivarianceRisk,
    "efficient_semivariance_return": EfficientSemivarianceReturn,
    # Black-Litterman (3)
    "black_litterman_max_sharpe": BlackLittermanMaxSharpe,
    "black_litterman_min_volatility": BlackLittermanMinVolatility,
    "black_litterman_quadratic_utility": BlackLittermanQuadraticUtility,
    # CLA (2)
    "cla_min_volatility": CLAMinVolatility,
    "cla_max_sharpe": CLAMaxSharpe,
    # Hierarchical (2)
    "hierarchical_min_volatility": HierarchicalMinVolatility,
    "hierarchical_max_sharpe": HierarchicalMaxSharpe,
    # Diversification (2)
    "max_diversification": MaxDiversification,
    "max_diversification_index": MaxDiversificationIndex,
    # Risk parity (2)
    "risk_parity": RiskParity,
    "equal_risk_contribution": EqualRiskContribution,
    # Transaction cost-aware (2)
    "max_sharpe_with_costs": MaxSharpeWithCosts,
    "min_volatility_with_costs": MinVolatilityWithCosts,
    # Momentum-filtered (2)
    "momentum_filtered_max_sharpe": MomentumFilteredMaxSharpe,
    "momentum_filtered_min_volatility": MomentumFilteredMinVolatility,
    # Factor-based (1)
    "factor_based_selection": FactorBasedSelection,
    # Trading objectives (4)
    "min_market_impact": MinMarketImpact,
    "min_implementation_shortfall": MinImplementationShortfall,
    "min_tracking_error": MinTrackingError,
    "liquidity_adjusted_min_vol": LiquidityAdjustedMinVol,
}


def get_objective(name: str, **params) -> BaseObjective:
    """
    Get an objective by name (string registry).

    Args:
        name: Objective name (e.g. ``"max_sharpe"``).
        **params: Constructor arguments for the objective.

    Returns:
        Instantiated objective.

    Raises:
        KeyError: If name is not in the registry.

    Example::

        obj = get_objective("max_sharpe", risk_free_rate=0.02)
    """
    if name not in OBJECTIVE_REGISTRY:
        raise KeyError(
            f"Unknown objective '{name}'. "
            f"Available: {sorted(OBJECTIVE_REGISTRY.keys())}"
        )
    return OBJECTIVE_REGISTRY[name](**params)


def list_objectives() -> list[str]:
    """Return sorted list of registered objective names."""
    return sorted(OBJECTIVE_REGISTRY.keys())


__all__ = [
    "BaseObjective",
    "get_objective",
    "list_objectives",
    "OBJECTIVE_REGISTRY",
    # Efficient frontier
    "MinVolatility",
    "MaxSharpe",
    "MaxReturn",
    "EfficientReturn",
    "EfficientRisk",
    "MaxUtility",
    # CVaR / CDaR / Semivariance
    "MinCVaR",
    "MinCDaR",
    "MinSemivariance",
    "EfficientCVaRRisk",
    "EfficientCVaRReturn",
    "EfficientCDaRRisk",
    "EfficientCDaRReturn",
    "EfficientSemivarianceRisk",
    "EfficientSemivarianceReturn",
    # Black-Litterman
    "BlackLittermanMaxSharpe",
    "BlackLittermanMinVolatility",
    "BlackLittermanQuadraticUtility",
    # CLA / Hierarchical
    "CLAMinVolatility",
    "CLAMaxSharpe",
    "HierarchicalMinVolatility",
    "HierarchicalMaxSharpe",
    # Diversification / Risk parity
    "MaxDiversification",
    "MaxDiversificationIndex",
    "RiskParity",
    "EqualRiskContribution",
    # Transaction cost / Momentum / Factor
    "MaxSharpeWithCosts",
    "MinVolatilityWithCosts",
    "MomentumFilteredMaxSharpe",
    "MomentumFilteredMinVolatility",
    "FactorBasedSelection",
    # Trading objectives
    "MinMarketImpact",
    "MinImplementationShortfall",
    "MinTrackingError",
    "LiquidityAdjustedMinVol",
]
