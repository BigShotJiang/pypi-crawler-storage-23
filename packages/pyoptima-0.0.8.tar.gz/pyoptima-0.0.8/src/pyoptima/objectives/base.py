"""
Base objective class and registry.

Provides the foundation for optimization objectives that build
real mathematical expressions on AbstractModel.
"""

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pyoptima.model.core import AbstractModel


class BaseObjective(ABC):
    """
    Base class for optimization objectives.

    Subclasses must implement ``_build()`` to construct the objective
    expression on the given model.  The public ``build()`` method
    delegates to ``_build()`` after any pre-processing.

    Example::

        class MinVolatility(BaseObjective):
            name = "min_volatility"
            sense = "minimize"

            def _build(self, model, data):
                from pyoptima.model.core import Expression
                import numpy as np

                cov = np.array(data["covariance_matrix"])
                n = cov.shape[0]
                expr = Expression()
                for i in range(n):
                    for j in range(n):
                        expr.add_term(float(cov[i, j]), f"w_{i}", f"w_{j}")
                model.minimize(expr)
    """

    name: str = "base_objective"
    sense: str = "minimize"  # "minimize" or "maximize"

    def build(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        """
        Build the objective on the model.

        Args:
            model: The solver-agnostic optimization model.
            data: Problem data dictionary (returns, covariance, etc.).
        """
        self._build(model, data)

    @abstractmethod
    def _build(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        """
        Implementation of objective building.

        Subclasses must call ``model.minimize(expr)`` or
        ``model.maximize(expr)`` to set the objective.

        Args:
            model: The optimization model.
            data: Problem data dictionary.
        """
        ...

    # ----- config round-trip ------------------------------------------------

    @classmethod
    def from_config(cls, config) -> "BaseObjective":
        """Build objective from a Pydantic config or dict.

        Subclasses may override for custom deserialization.
        Default: inspect ``__init__`` params and pull from *config*.
        """
        import inspect

        init_sig = inspect.signature(cls.__init__)
        kwargs: dict[str, Any] = {}
        for pname, param in init_sig.parameters.items():
            if pname == "self":
                continue
            if isinstance(config, dict):
                if pname in config:
                    kwargs[pname] = config[pname]
            elif hasattr(config, pname):
                kwargs[pname] = getattr(config, pname)
        return cls(**kwargs)

    def to_config(self) -> dict[str, Any]:
        """Serialize objective to a config dict."""
        import inspect

        result: dict[str, Any] = {"name": self.name}
        try:
            init_sig = inspect.signature(self.__init__)
            for pname in init_sig.parameters:
                if pname == "self":
                    continue
                if hasattr(self, pname):
                    result[pname] = getattr(self, pname)
        except (ValueError, TypeError):
            pass
        return result

    def __repr__(self) -> str:
        """sklearn-style repr."""
        import inspect

        try:
            init_sig = inspect.signature(self.__init__)
            params = []
            for pname, param in init_sig.parameters.items():
                if pname == "self":
                    continue
                if hasattr(self, pname):
                    value = getattr(self, pname)
                    if isinstance(value, str):
                        params.append(f"{pname}={value!r}")
                    elif isinstance(value, float):
                        params.append(f"{pname}={value:.4g}")
                    elif value is not None:
                        params.append(f"{pname}={value!r}")
            return f"{self.__class__.__name__}({', '.join(params)})"
        except (ValueError, TypeError):
            return f"{self.__class__.__name__}()"
