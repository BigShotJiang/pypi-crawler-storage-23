"""
Trading objectives for market-impact-aware optimisation.

All trading objectives extend :class:`BaseObjective` and build real
mathematical expressions on :class:`AbstractModel`.

- **MinMarketImpact** --- Minimise estimated market impact of the trade list.
- **MinImplementationShortfall** --- Minimise expected shortfall from decision price.
- **MinTrackingError** --- Minimise tracking error vs benchmark weights.
- **LiquidityAdjustedMinVol** --- Minimise volatility with a liquidity penalty.
"""

from typing import TYPE_CHECKING, Any

import numpy as np

from pyoptima.objectives.base import BaseObjective

if TYPE_CHECKING:
    from pyoptima.model.core import AbstractModel


class MinMarketImpact(BaseObjective):
    """
    Objective: minimise estimated market impact.

    Linearized approximation of square-root impact model:

    .. math::

        \\min_w \\; \\sum_i \\eta \\frac{|\\Delta w_i|}{\\text{ADV}_i}

    Uses buy/sell decomposition for linearization.

    Args:
        adv: Symbol -> average daily volume.
        prices: Symbol -> current price.
        current_weights: Symbol -> current weight (for computing dw).
        impact_coefficient: eta scaling factor.

    Example::

        obj = MinMarketImpact(
            adv={"AAPL": 75_000_000},
            current_weights={"AAPL": 0.30},
        )
    """

    name = "min_market_impact"
    sense = "minimize"

    def __init__(
        self,
        adv: dict[str, float] | None = None,
        prices: dict[str, float] | None = None,
        current_weights: dict[str, float] | None = None,
        impact_coefficient: float = 0.5,
    ):
        self.adv = adv or {}
        self.prices = prices or {}
        self.current_weights = current_weights or {}
        self.impact_coefficient = impact_coefficient

    def _build(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        from pyoptima.model.core import Expression

        symbols = data.get("symbols", [])
        n = len(symbols)
        adv = self.adv or data.get("adv", {})
        cw = self.current_weights or data.get("current_weights", {})

        # Create buy/sell decomposition for |dw_i|
        for i, sym in enumerate(symbols):
            old_w = cw.get(sym, 0.0) if isinstance(cw, dict) else 0.0
            var = model.get_variable(f"w_{i}")
            ub = var.upper_bound if (var and var.upper_bound) else 1.0

            if model.get_variable(f"buy_{i}") is None:
                model.add_continuous(f"buy_{i}", lb=0.0, ub=ub)
                model.add_continuous(f"sell_{i}", lb=0.0, ub=max(old_w, ub))

                # w_i = old_w + buy_i - sell_i
                balance = Expression()
                balance.add_term(1.0, f"w_{i}")
                balance.add_term(-1.0, f"buy_{i}")
                balance.add_term(1.0, f"sell_{i}")
                model.add_eq_constraint(f"impact_balance_{i}", balance, old_w)

        # Minimize impact: sum eta * (buy_i + sell_i) / adv_i
        impact_expr = Expression()
        for i, sym in enumerate(symbols):
            vol = adv.get(sym, 1.0)
            coeff = self.impact_coefficient / max(vol, 1e-10)
            impact_expr.add_term(coeff, f"buy_{i}")
            impact_expr.add_term(coeff, f"sell_{i}")

        model.minimize(impact_expr)


class MinImplementationShortfall(BaseObjective):
    """
    Objective: minimise implementation shortfall.

    Combines market impact with timing risk:

    .. math::

        \\min_w \\; \\sum_i [\\eta \\cdot \\sigma_i \\cdot |\\Delta w_i| / \\text{ADV}_i
                    + \\lambda \\cdot \\sigma_i^2 \\cdot \\Delta w_i^2]

    Linearized via buy/sell decomposition.

    Example::

        obj = MinImplementationShortfall(
            adv={"AAPL": 75_000_000},
            volatilities={"AAPL": 0.02},
        )
    """

    name = "min_implementation_shortfall"
    sense = "minimize"

    def __init__(
        self,
        adv: dict[str, float] | None = None,
        volatilities: dict[str, float] | None = None,
        risk_aversion: float = 1e-6,
        impact_coefficient: float = 0.5,
    ):
        self.adv = adv or {}
        self.volatilities = volatilities or {}
        self.risk_aversion = risk_aversion
        self.impact_coefficient = impact_coefficient

    def _build(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        from pyoptima.model.core import Expression

        symbols = data.get("symbols", [])
        n = len(symbols)
        adv = self.adv or data.get("adv", {})
        vols = self.volatilities or data.get("volatilities", {})
        cw = data.get("current_weights", {})

        # Create buy/sell decomposition
        for i, sym in enumerate(symbols):
            old_w = cw.get(sym, 0.0) if isinstance(cw, dict) else 0.0
            var = model.get_variable(f"w_{i}")
            ub = var.upper_bound if (var and var.upper_bound) else 1.0

            if model.get_variable(f"buy_{i}") is None:
                model.add_continuous(f"buy_{i}", lb=0.0, ub=ub)
                model.add_continuous(f"sell_{i}", lb=0.0, ub=max(old_w, ub))

                balance = Expression()
                balance.add_term(1.0, f"w_{i}")
                balance.add_term(-1.0, f"buy_{i}")
                balance.add_term(1.0, f"sell_{i}")
                model.add_eq_constraint(f"is_balance_{i}", balance, old_w)

        # IS = sum [eta * sigma_i * (buy + sell) / adv + lambda * sigma^2 * (buy + sell)^2]
        is_expr = Expression()
        for i, sym in enumerate(symbols):
            vol_i = vols.get(sym, 0.01)
            adv_i = adv.get(sym, 1.0)

            # Linear impact term
            linear_coeff = self.impact_coefficient * vol_i / max(adv_i, 1e-10)
            is_expr.add_term(linear_coeff, f"buy_{i}")
            is_expr.add_term(linear_coeff, f"sell_{i}")

            # Quadratic timing risk (buy_i^2 + sell_i^2)
            quad_coeff = self.risk_aversion * vol_i**2
            is_expr.add_term(quad_coeff, f"buy_{i}", f"buy_{i}")
            is_expr.add_term(quad_coeff, f"sell_{i}", f"sell_{i}")

        model.minimize(is_expr)


class MinTrackingError(BaseObjective):
    """
    Objective: minimise tracking error versus benchmark weights.

    .. math::

        \\min_w \\; (w - b)^T \\Sigma (w - b)

    Args:
        benchmark_weights: Symbol -> benchmark weight.
        max_tracking_error: Optional cap on tracking error.

    Example::

        obj = MinTrackingError(
            benchmark_weights={"AAPL": 0.15, "MSFT": 0.10},
        )
    """

    name = "min_tracking_error"
    sense = "minimize"

    def __init__(
        self,
        benchmark_weights: dict[str, float] | None = None,
        max_tracking_error: float | None = None,
    ):
        self.benchmark_weights = benchmark_weights or {}
        self.max_tracking_error = max_tracking_error

    def _build(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        from pyoptima.model.core import Expression

        symbols = data.get("symbols", [])
        n = len(symbols)
        cov = data.get("covariance_matrix")
        if cov is None:
            raise ValueError("MinTrackingError requires 'covariance_matrix'")
        cov = np.array(cov)

        bw = self.benchmark_weights or data.get("benchmark_weights", {})
        if isinstance(bw, dict):
            b = np.array([bw.get(s, 0.0) for s in symbols])
        else:
            b = np.array(bw)

        # (w-b)' Sigma (w-b) = w'Sw - 2(Sb)'w + b'Sb
        te_expr = Expression()
        for i in range(n):
            for j in range(n):
                c = float(cov[i, j])
                if c != 0.0:
                    te_expr.add_term(c, f"w_{i}", f"w_{j}")

        sigma_b = cov @ b
        for i in range(n):
            te_expr.add_term(-2.0 * float(sigma_b[i]), f"w_{i}")

        const = float(b @ cov @ b)
        te_expr.add_constant(const)

        model.minimize(te_expr)


class LiquidityAdjustedMinVol(BaseObjective):
    """
    Objective: liquidity-adjusted minimum volatility.

    .. math::

        \\min_w \\; w^T \\Sigma w + \\lambda_{\\text{liq}} \\sum_i \\frac{w_i^2}{\\text{ADV}_i}

    Example::

        obj = LiquidityAdjustedMinVol(
            adv={"AAPL": 75_000_000, "ILLIQ": 100_000},
            liquidity_penalty=0.01,
        )
    """

    name = "liquidity_adjusted_min_vol"
    sense = "minimize"

    def __init__(
        self,
        adv: dict[str, float] | None = None,
        liquidity_penalty: float = 0.01,
    ):
        self.adv = adv or {}
        self.liquidity_penalty = liquidity_penalty

    def _build(self, model: "AbstractModel", data: dict[str, Any]) -> None:
        from pyoptima.model.core import Expression

        symbols = data.get("symbols", [])
        n = len(symbols)
        cov = data.get("covariance_matrix")
        if cov is None:
            raise ValueError("LiquidityAdjustedMinVol requires 'covariance_matrix'")
        cov = np.array(cov)
        adv = self.adv or data.get("adv", {})

        # w'Sigma w + lambda * sum(w_i^2 / adv_i)
        expr = Expression()
        for i in range(n):
            for j in range(n):
                c = float(cov[i, j])
                if c != 0.0:
                    expr.add_term(c, f"w_{i}", f"w_{j}")

        for i, sym in enumerate(symbols):
            vol = adv.get(sym, 1.0)
            penalty = self.liquidity_penalty / max(vol, 1e-10)
            expr.add_term(penalty, f"w_{i}", f"w_{i}")

        model.minimize(expr)
