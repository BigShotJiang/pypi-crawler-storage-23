"""
Route handlers for settings (app-config for UI theme/app name/version).

Mirrors PyCharter/PyStator api/routes/v1/settings.py app-config endpoint.
"""

from __future__ import annotations

from fastapi import APIRouter, status

from pyoptima import __version__ as pyoptima_version
from pyoptima.app_config import get_ui_app_name, get_ui_theme

# Public router: no auth (so UI can load theme before login)
public_router = APIRouter()


@public_router.get(
    "/settings/app-config",
    status_code=status.HTTP_200_OK,
    summary="Get app config (theme, app name, version) for UI",
    description="Returns UI theme (light, dark, system), app name, and release version. No auth required.",
)
async def get_app_config() -> dict[str, str]:
    return {
        "theme": get_ui_theme(),
        "app_name": get_ui_app_name(),
        "version": pyoptima_version or "",
    }
