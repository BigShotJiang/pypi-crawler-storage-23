"""
API v1 routes package.
"""

from pyoptima.api.routes.v1 import auth, jobs, optimize, settings, solvers, templates

__all__ = ["auth", "jobs", "optimize", "settings", "solvers", "templates"]
