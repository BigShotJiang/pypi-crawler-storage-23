"""
Dependency injection for PyOptima API.

Provides singleton services and dependency injection for FastAPI routes.
When PYOPTIMA_DATABASE_URL is set, uses DatabaseJobManager (worker queue);
otherwise uses in-memory JobManager.
"""

import os
from collections.abc import Generator
from functools import lru_cache
from typing import Any

from pyoptima.api.services.job_manager import JobManager
from pyoptima.api.services.optimization_service import OptimizationService


def _create_job_manager() -> Any:
    db_url = os.environ.get("PYOPTIMA_DATABASE_URL", "").strip()
    if db_url:
        try:
            from pyoptima.api.services.database_job_manager import DatabaseJobManager

            return DatabaseJobManager(db_url)
        except ImportError:
            pass
    return JobManager()


@lru_cache
def get_job_manager() -> Any:
    """
    Get JobManager singleton (in-memory or database-backed when PYOPTIMA_DATABASE_URL is set).
    """
    return _create_job_manager()


def get_optimization_service() -> Generator[OptimizationService, None, None]:
    """
    Get OptimizationService instance (dependency).
    """
    job_manager = get_job_manager()
    yield OptimizationService(job_manager)


def use_database_backend() -> bool:
    """Return True if the API is using the database job backend (worker queue)."""
    return bool(os.environ.get("PYOPTIMA_DATABASE_URL", "").strip())
