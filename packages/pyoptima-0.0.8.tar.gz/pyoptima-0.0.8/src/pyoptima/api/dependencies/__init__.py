"""
Dependency injection for PyOptima API.
"""

from pyoptima.api.dependencies.core import (
    get_job_manager,
    get_optimization_service,
    use_database_backend,
)

__all__ = [
    "get_job_manager",
    "get_optimization_service",
    "use_database_backend",
]
