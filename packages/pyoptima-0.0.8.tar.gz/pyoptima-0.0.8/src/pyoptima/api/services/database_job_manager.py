"""
Database-backed job manager for the API.

When PYOPTIMA_DATABASE_URL is set, the API uses this manager so jobs
are stored in the optimization_jobs table and processed by worker processes.
"""

from __future__ import annotations

from typing import Any

from pyoptima.api.models.jobs import JobResponse, JobStatus
from pyoptima.worker.job_sources.database import DatabaseJobSource


class DatabaseJobManager:
    """Job manager that delegates to DatabaseJobSource (same interface as JobManager)."""

    def __init__(self, db_url: str) -> None:
        self._db_url = db_url
        self._source: DatabaseJobSource | None = None

    def _get_source(self) -> DatabaseJobSource:
        if self._source is None:
            self._source = DatabaseJobSource(self._db_url, config=None)
        return self._source

    def _dict_to_response(self, d: dict[str, Any]) -> JobResponse:
        return JobResponse(
            job_id=d["job_id"],
            status=JobStatus(d["status"]),
            template=d.get("template"),
            result=d.get("result"),
            error=d.get("error"),
            created_at=d["created_at"],
            started_at=d.get("started_at"),
            completed_at=d.get("completed_at"),
            duration_ms=d.get("duration_ms"),
        )

    async def get_job_async(self, job_id: str) -> JobResponse | None:
        source = self._get_source()
        d = await source.get_job(job_id)
        if d is None:
            return None
        return self._dict_to_response(d)

    async def list_jobs_async(
        self,
        status: JobStatus | None = None,
        limit: int | None = None,
        offset: int = 0,
    ) -> list[JobResponse]:
        source = self._get_source()
        status_str = status.value if status else None
        rows = await source.list_jobs(status=status_str, limit=limit, offset=offset)
        return [self._dict_to_response(r) for r in rows]

    async def get_stats_async(self) -> dict[str, int]:
        source = self._get_source()
        return await source.get_stats()

    async def cancel_job_async(self, job_id: str) -> bool:
        source = self._get_source()
        return await source.cancel_job(job_id)

    async def delete_job_async(self, job_id: str) -> bool:
        source = self._get_source()
        return await source.delete_job(job_id)

    async def submit_job_async(
        self,
        template: str,
        data: dict[str, Any],
        job_id: str | None = None,
        solver_options: dict[str, Any] | None = None,
    ) -> str:
        from pyoptima.worker.models import OptimizationJob

        source = self._get_source()
        job = OptimizationJob(
            template=template,
            data=data,
            solver_options=solver_options,
            job_id=job_id,
            idempotency_key=job_id,
            max_attempts=5,
        )
        return await source.submit(job)
