"""
Optimization execution service.

Handles the execution of optimization jobs using the PyOptima solve API.
"""

import asyncio
from typing import Any

from pyoptima import get_template, list_templates, solve
from pyoptima.api.models.jobs import JobStatus
from pyoptima.api.models.optimization import OptimizeRequest
from pyoptima.api.services.job_manager import JobManager
from pyoptima.core.result import OptimizationResult


class OptimizationService:
    """
    Service for executing optimization jobs.

    Provides both synchronous and asynchronous optimization execution
    using the PyOptima solve API.
    """

    def __init__(self, job_manager: JobManager):
        """
        Initialize optimization service.

        Args:
            job_manager: JobManager instance for managing job state
        """
        self.job_manager = job_manager

    def optimize_sync(self, request: OptimizeRequest) -> OptimizationResult:
        """
        Execute optimization synchronously.

        Args:
            request: Optimization request

        Returns:
            OptimizationResult

        Raises:
            ValueError: If template or data is invalid
            RuntimeError: If optimization fails
        """
        solver_name = None
        solver_options: dict[str, Any] = {}

        if request.solver:
            solver_name = request.solver.name
            if request.solver.time_limit:
                solver_options["time_limit"] = request.solver.time_limit
            if request.solver.gap_tolerance:
                solver_options["mip_gap"] = request.solver.gap_tolerance
            if request.solver.verbose:
                solver_options["verbose"] = request.solver.verbose
            solver_options.update(request.solver.options)

        result = solve(
            template_name=request.template,
            data=request.data,
            solver=solver_name,
            **solver_options,
        )
        return result

    async def optimize_async(
        self,
        job_id: str,
        request: OptimizeRequest,
    ) -> None:
        """
        Execute optimization asynchronously.

        Updates job status in job_manager as optimization progresses.

        Args:
            job_id: Job identifier
            request: Optimization request
        """
        # Update status to running
        self.job_manager.update_job_status(job_id, JobStatus.RUNNING)

        try:
            # Run optimization in thread to avoid blocking event loop
            result = await asyncio.to_thread(self.optimize_sync, request)

            # Update status to completed
            self.job_manager.update_job_status(
                job_id, JobStatus.COMPLETED, result=result.to_dict()
            )

        except Exception as e:
            # Update status to failed
            self.job_manager.update_job_status(job_id, JobStatus.FAILED, error=str(e))

    def optimize_batch_sync(
        self,
        requests: list[OptimizeRequest],
    ) -> list[OptimizationResult]:
        """
        Execute multiple optimizations sequentially.

        Args:
            requests: List of optimization requests

        Returns:
            List of OptimizationResult (errors as result with status=error)
        """
        results: list[OptimizationResult] = []
        for req in requests:
            try:
                results.append(self.optimize_sync(req))
            except Exception as e:
                results.append(
                    OptimizationResult.from_solution_dict(
                        {"status": "error", "solver_message": str(e)}
                    )
                )
        return results

    @staticmethod
    def validate_data(template: str, data: dict[str, Any]) -> list[str]:
        """
        Validate optimization data without solving.

        Args:
            template: Template name
            data: Problem data

        Returns:
            List of validation errors (empty if valid)
        """
        errors = []

        try:
            template_obj = get_template(template)
            template_obj.validate_data(data)
        except KeyError:
            errors.append(f"Unknown template: {template}")
        except ValueError as e:
            errors.append(str(e))
        except Exception as e:
            errors.append(f"Validation error: {str(e)}")

        return errors

    @staticmethod
    def get_template_info(template: str) -> dict[str, Any]:
        """
        Get information about a template.

        Args:
            template: Template name

        Returns:
            Template information dictionary

        Raises:
            KeyError: If template not found
        """
        template_obj = get_template(template)
        info = template_obj.info

        return {
            "name": info.name,
            "description": info.description,
            "problem_type": info.problem_type,
            "required_data": info.required_data,
            "optional_data": info.optional_data,
            "default_solver": info.default_solver,
        }

    @staticmethod
    def list_templates() -> list[str]:
        """
        List all available templates.

        Returns:
            List of template names
        """
        return list_templates()
