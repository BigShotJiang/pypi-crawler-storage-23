# PyOptima API

REST API wrapper for PyOptima optimization services using FastAPI.

## Overview

The PyOptima API is located at the root level of the repository (`api/`) and provides HTTP endpoints for optimization operations:
- **Synchronous Optimization**: Submit optimization request and wait for result
- **Asynchronous Optimization**: Submit optimization request, get job ID, poll for results
- **Job Management**: Query job status, list jobs, cancel jobs
- **Method Information**: List available optimization methods and get method details

## Installation

Install PyOptima with API dependencies:

```bash
pip install pyoptima[api]
```

## Running the API Server

### Using the CLI command:

```bash
pyoptima api
```

### With custom host/port:

```bash
pyoptima api --host 127.0.0.1 --port 8080
```

### Disable auto-reload (production):

```bash
pyoptima api --no-reload
```

### Using uvicorn directly:

```bash
uvicorn api.main:app --reload
```

### Using Python:

```python
from api.main import main
main()
```

## API Endpoints

### Optimization

#### Synchronous Optimization
- **POST** `/api/v1/optimize` - Submit optimization request and wait for result

**Request:**
```json
{
  "config": {
    "meta": {
      "job_id": "opt-001",
      "solver": "ipopt",
      "time_limit_seconds": 60
    },
    "method": "min_volatility",
    "parameters": {
      "weight_bounds": [0, 1]
    },
    "data": {
      "expected_returns": [0.10, 0.12, 0.15],
      "covariance_matrix": [
        [0.04, 0.01, 0.02],
        [0.01, 0.05, 0.01],
        [0.02, 0.01, 0.06]
      ]
    }
  },
  "data": null
}
```

**Response:**
```json
{
  "job_id": "opt-001",
  "status": "optimal",
  "result": {
    "weights": {"Asset_0": 0.25, "Asset_1": 0.30, "Asset_2": 0.45},
    "portfolio_return": 0.115,
    "portfolio_volatility": 0.15,
    "status": "optimal"
  },
  "message": "Optimization successful",
  "created_at": "2025-01-15T10:30:00Z",
  "completed_at": "2025-01-15T10:30:05Z",
  "duration_seconds": 5.2
}
```

#### Asynchronous Optimization
- **POST** `/api/v1/optimize/async` - Submit optimization request, get job ID

**Request:** Same as synchronous

**Response:**
```json
{
  "job_id": "opt-002",
  "status": "queued",
  "message": "Job submitted successfully"
}
```

### Job Management

#### Get Job Status
- **GET** `/api/v1/jobs/{job_id}` - Get job status and results

**Response:**
```json
{
  "job_id": "opt-002",
  "status": "completed",
  "config": {...},
  "result": {
    "weights": {...},
    "portfolio_return": 0.115,
    "portfolio_volatility": 0.15
  },
  "error": null,
  "created_at": "2025-01-15T10:30:00Z",
  "started_at": "2025-01-15T10:30:01Z",
  "completed_at": "2025-01-15T10:30:05Z",
  "duration_seconds": 4.0
}
```

#### List Jobs
- **GET** `/api/v1/jobs` - List all jobs
- **GET** `/api/v1/jobs?status=completed` - Filter by status
- **GET** `/api/v1/jobs?limit=10` - Limit number of results

**Query Parameters:**
- `status` (optional): Filter by status (`queued`, `running`, `completed`, `failed`, `cancelled`)
- `limit` (optional): Maximum number of jobs to return (1-1000)

#### Cancel Job
- **DELETE** `/api/v1/jobs/{job_id}` - Cancel a running or queued job

### Method Information

#### List Methods
- **GET** `/api/v1/methods` - List all available optimization methods
- **GET** `/api/v1/methods?category=portfolio` - Filter by category

**Response:**
```json
{
  "methods": ["min_volatility", "max_sharpe", "min_cvar", ...],
  "total": 21,
  "category": null
}
```

#### Get Method Info
- **GET** `/api/v1/methods/{method_name}` - Get detailed information about a method

**Response:**
```json
{
  "name": "min_volatility",
  "category": "portfolio",
  "description": "Minimize portfolio volatility (risk)",
  "parameter_schema": {
    "weight_bounds": {
      "type": "tuple",
      "default": [0, 1],
      "description": "Weight bounds"
    },
    "solver": {
      "type": "str",
      "default": "ipopt",
      "description": "Solver name"
    }
  }
}
```

### Health & Status

#### Health Check
- **GET** `/health` - Check API health status

**Response:**
```json
{
  "status": "healthy",
  "version": "0.0.1"
}
```

#### API Information
- **GET** `/` - Get API information and version

**Response:**
```json
{
  "name": "PyOptima API",
  "version": "0.0.1",
  "api_version": "v1",
  "docs": "/docs",
  "redoc": "/redoc"
}
```

## API Documentation

Interactive API documentation is available at:
- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc

## Example Usage

### Python Client Example

```python
import requests

# Synchronous optimization
response = requests.post(
    "http://localhost:8000/api/v1/optimize",
    json={
        "config": {
            "meta": {
                "job_id": "my-opt",
                "solver": "ipopt"
            },
            "method": "min_volatility",
            "parameters": {"weight_bounds": [0, 1]},
            "data": {
                "expected_returns": [0.10, 0.12, 0.15],
                "covariance_matrix": [[0.04, 0.01, 0.02], [0.01, 0.05, 0.01], [0.02, 0.01, 0.06]]
            }
        }
    }
)
result = response.json()
print(f"Optimal weights: {result['result']['weights']}")

# Asynchronous optimization
response = requests.post(
    "http://localhost:8000/api/v1/optimize/async",
    json={...}
)
job_id = response.json()["job_id"]

# Poll for results
import time
while True:
    response = requests.get(f"http://localhost:8000/api/v1/jobs/{job_id}")
    job = response.json()
    if job["status"] in ["completed", "failed"]:
        break
    time.sleep(1)

print(f"Result: {job['result']}")
```

### cURL Example

```bash
# Synchronous optimization
curl -X POST "http://localhost:8000/api/v1/optimize" \
  -H "Content-Type: application/json" \
  -d '{
    "config": {
      "meta": {"job_id": "test", "solver": "ipopt"},
      "method": "min_volatility",
      "parameters": {"weight_bounds": [0, 1]},
      "data": {
        "expected_returns": [0.10, 0.12, 0.15],
        "covariance_matrix": [[0.04, 0.01, 0.02], [0.01, 0.05, 0.01], [0.02, 0.01, 0.06]]
      }
    }
  }'

# List methods
curl "http://localhost:8000/api/v1/methods"

# Get job status
curl "http://localhost:8000/api/v1/jobs/opt-001"
```

## Job Status Values

- `queued`: Job is queued and waiting to start
- `running`: Job is currently executing
- `completed`: Job completed successfully
- `failed`: Job failed with an error
- `cancelled`: Job was cancelled

## Error Handling

The API returns standard HTTP status codes:

- `200 OK`: Request successful
- `202 Accepted`: Job submitted (async)
- `400 Bad Request`: Invalid request (e.g., cannot cancel completed job)
- `404 Not Found`: Job or method not found
- `422 Unprocessable Entity`: Validation error
- `500 Internal Server Error`: Server error

Error responses include a `detail` field with error information:

```json
{
  "detail": "Job 'invalid-id' not found"
}
```

## Configuration

The API uses the same `OptimizationConfig` format as the core PyOptima package. See the main [USAGE.md](../USAGE.md) for configuration details.

## Notes

- Jobs are stored in-memory by default (lost on server restart)
- For production deployments, consider implementing Redis or database-backed job storage
- The API supports CORS from all origins by default (configure appropriately for production)
- Auto-reload is enabled by default in development mode
