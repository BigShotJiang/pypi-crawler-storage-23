"""Shared path-resolution helpers for PyOptima configuration files."""

from __future__ import annotations

from pathlib import Path

_CONFIG_FILENAME = "pyoptima.cfg"
_MAX_PARENT_WALK = 5


def find_config_file(filename: str = _CONFIG_FILENAME) -> Path | None:
    """Locate a config file by searching standard locations.

    Search order (mirrors pycharter/pystator):
        1. Current working directory
        2. ``~/.pyoptima/``
        3. Package/project directory (directory containing the pyoptima package)
    """
    # 1. Current working directory
    cwd_path = Path.cwd() / filename
    if cwd_path.exists():
        return cwd_path

    # 2. User home directory
    home_path = Path.home() / ".pyoptima" / filename
    if home_path.exists():
        return home_path

    # 3. Package/project directory (so config is found when run from monorepo root or any CWD)
    try:
        import pyoptima

        start = Path(pyoptima.__file__).resolve().parent
        for _ in range(10):
            cand = start / filename
            if cand.exists():
                return cand
            parent = start.parent
            if parent == start:
                break
            start = parent
    except (ImportError, AttributeError):
        pass

    return None
