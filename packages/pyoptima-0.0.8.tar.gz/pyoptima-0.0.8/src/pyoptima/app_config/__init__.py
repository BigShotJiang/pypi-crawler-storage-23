"""Configuration helpers for PyOptima (paths, UI theme, app name)."""

from __future__ import annotations

from pyoptima.app_config.paths import find_config_file
from pyoptima.app_config.ui import get_ui_app_name, get_ui_theme

__all__ = ["find_config_file", "get_ui_theme", "get_ui_app_name"]
