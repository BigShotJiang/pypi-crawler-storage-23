"""UI config (theme, etc.). Env or pyoptima.cfg [ui]; keys = env names (e.g. PYOPTIMA_UI_THEME)."""

from __future__ import annotations

import os
from configparser import ConfigParser

from pyoptima.app_config.paths import find_config_file

# Named palettes use data-theme="<id>"; light/dark/system use :root + .dark only.
_VALID_THEMES = (
    "light",
    "dark",
    "system",
    "ocean",
    "forest",
    "sunset",
    "high-contrast",
    "sepia",
    "violet",
    "cathay",
)


def _cfg(section: str, key: str) -> str | None:
    cfg_path = find_config_file("pyoptima.cfg")
    if not cfg_path:
        return None
    try:
        cfg = ConfigParser()
        cfg.read(cfg_path)
        if cfg.has_section(section):
            return cfg.get(section, key, fallback=None)
    except Exception:
        pass
    return None


def get_ui_theme() -> str:
    """Return UI theme: light, dark, or system. Env overrides .cfg. Default light."""
    raw = os.getenv("PYOPTIMA_UI_THEME") or _cfg("ui", "PYOPTIMA_UI_THEME") or ""
    value = raw.strip().lower()
    return value if value in _VALID_THEMES else "light"


_DEFAULT_UI_APP_NAME = "PyOptima"


def get_ui_app_name() -> str:
    """Return UI app/website name. Env overrides .cfg. Default PyOptima."""
    raw = os.getenv("PYOPTIMA_UI_APP_NAME") or _cfg("ui", "PYOPTIMA_UI_APP_NAME") or ""
    return raw.strip() or _DEFAULT_UI_APP_NAME
