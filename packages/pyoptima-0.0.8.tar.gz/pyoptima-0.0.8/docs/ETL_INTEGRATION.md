# ETL Integration Guide

This guide explains how to use PyOptima with pycharter ETL pipelines.

## Overview

PyOptima provides a first-class `pyoptima.etl` module designed for seamless integration with pycharter's `custom_function` transform capability. No bridge code required.

**Before** (custom bridge code required):
```
pycharter ETL → user's bridge code → pyoptima.PortfolioTemplate
```

**Now** (direct integration):
```
pycharter ETL → pyoptima.etl.optimize_batch
```

## Quick Start

### pycharter Transform Configuration

Simply point your `transform.yaml` to pyoptima's ETL module:

```yaml
# transform.yaml
title: portfolio_optimization
description: Optimize portfolio using PyOptima
version: "1.0.0"

custom_function:
  module: pyoptima.etl
  function: optimize_batch
  mode: batch
  kwargs:
    objective: min_volatility
    solver: ipopt
```

That's it! No Python code needed in your project.

### Supported Objectives

All 31 portfolio optimization objectives are supported:

**Efficient Frontier:**
- `min_volatility` - Minimize portfolio volatility
- `max_sharpe` - Maximize Sharpe ratio
- `max_return` - Maximize expected return
- `efficient_return` - Target return with minimum risk
- `efficient_risk` - Target risk with maximum return
- `max_utility` - Maximize utility (return - risk_aversion * variance)

**Black-Litterman:**
- `black_litterman_max_sharpe` - BL with max Sharpe
- `black_litterman_min_volatility` - BL with min volatility
- `black_litterman_quadratic_utility` - BL with quadratic utility

**CVaR (Conditional Value at Risk):**
- `min_cvar` - Minimize CVaR
- `efficient_cvar_risk` - Target CVaR with max return
- `efficient_cvar_return` - Target return with min CVaR

**CDaR (Conditional Drawdown at Risk):**
- `min_cdar` - Minimize CDaR
- `efficient_cdar_risk` - Target CDaR with max return
- `efficient_cdar_return` - Target return with min CDaR

**Semivariance:**
- `min_semivariance` - Minimize semivariance
- `efficient_semivariance_risk` - Target semivariance with max return
- `efficient_semivariance_return` - Target return with min semivariance

**CLA (Critical Line Algorithm):**
- `cla_min_volatility` - CLA minimum volatility
- `cla_max_sharpe` - CLA maximum Sharpe

**Hierarchical:**
- `hierarchical_min_volatility` - HRP minimum volatility
- `hierarchical_max_sharpe` - HRP maximum Sharpe

**Diversification:**
- `max_diversification` - Maximum diversification
- `max_diversification_index` - Maximum diversification index
- `risk_parity` - Risk parity
- `equal_risk_contribution` - Equal risk contribution

**Transaction Cost-Aware:**
- `max_sharpe_with_costs` - Max Sharpe with transaction costs
- `min_volatility_with_costs` - Min volatility with transaction costs

**Momentum-Filtered:**
- `momentum_filtered_max_sharpe` - Momentum-filtered max Sharpe
- `momentum_filtered_min_volatility` - Momentum-filtered min volatility

**Factor-Based:**
- `factor_based_selection` - Factor-based asset selection

## Input Format

### Required Fields

Each input record must contain:

```json
{
  "expected_returns": {"AAPL": 0.12, "GOOGL": 0.10, "MSFT": 0.08},
  "covariance_matrix": {
    "matrix": [[0.04, 0.01, 0.02], [0.01, 0.03, 0.015], [0.02, 0.015, 0.025]],
    "symbols": ["AAPL", "GOOGL", "MSFT"]
  }
}
```

### Optional Fields

```json
{
  "job_id": "unique-id",
  "symbols": ["AAPL", "GOOGL", "MSFT"],
  "returns": [[0.01, 0.008, 0.006], ...],  // For CVaR/CDaR/Semivariance
  
  // Target parameters
  "target_return": 0.10,
  "target_volatility": 0.15,
  "target_cvar": 0.02,
  
  // Risk parameters
  "risk_free_rate": 0.02,
  "risk_aversion": 1.0,
  
  // Constraints
  "max_weight": 0.40,
  "min_weight": 0.01,
  "max_assets": 10,
  "sector_caps": {"Technology": 0.40},
  "asset_sectors": {"AAPL": "Technology", "GOOGL": "Technology"}
}
```

### Supported Input Formats

PyOptima automatically normalizes various formats:

**Covariance Matrix:**
```python
# Nested dict (ETL format)
{"matrix": [[...]], "symbols": [...]}

# Dict-of-dicts
{"AAPL": {"AAPL": 0.04, "MSFT": 0.01}, "MSFT": {...}}

# List-of-lists
[[0.04, 0.01], [0.01, 0.05]]

# NumPy array
np.array([[0.04, 0.01], [0.01, 0.05]])

# Pandas DataFrame
pd.DataFrame([[0.04, 0.01], [0.01, 0.05]], index=["AAPL", "MSFT"])
```

**Expected Returns:**
```python
# Dict
{"AAPL": 0.12, "MSFT": 0.11}

# List
[0.12, 0.11]

# Pandas Series
pd.Series([0.12, 0.11], index=["AAPL", "MSFT"])
```

## Output Format

PyOptima returns ETL-ready records:

```json
{
  "job_id": "unique-id",
  "optimization_type": "min_volatility",
  "symbols": ["AAPL", "GOOGL", "MSFT"],
  "weights": {"AAPL": 0.25, "GOOGL": 0.40, "MSFT": 0.35},
  "expected_return": 0.10,
  "volatility": 0.12,
  "sharpe_ratio": 0.67,
  "status": "optimal",
  "parameters": {
    "solver": "ipopt",
    "run_at": "2025-01-28T12:00:00Z"
  }
}
```

## Configuration Examples

### Basic Min Volatility

```yaml
custom_function:
  module: pyoptima.etl
  function: optimize_batch
  kwargs:
    objective: min_volatility
```

### Max Sharpe with Risk-Free Rate

```yaml
custom_function:
  module: pyoptima.etl
  function: optimize_batch
  kwargs:
    objective: max_sharpe
    risk_free_rate: 0.02
```

### Efficient Return (Target Return)

```yaml
custom_function:
  module: pyoptima.etl
  function: optimize_batch
  kwargs:
    objective: efficient_return
    target_return: 0.15
```

### With Constraints

```yaml
custom_function:
  module: pyoptima.etl
  function: optimize_batch
  kwargs:
    objective: min_volatility
    max_weight: 0.40
    min_weight: 0.01
    max_assets: 10
```

### CVaR Optimization

```yaml
custom_function:
  module: pyoptima.etl
  function: optimize_batch
  kwargs:
    objective: min_cvar
    confidence_level: 0.05  # 95% CVaR
```

### Black-Litterman

Input record must include `market_caps`:

```yaml
custom_function:
  module: pyoptima.etl
  function: optimize_batch
  kwargs:
    objective: black_litterman_max_sharpe
    tau: 1.0
    risk_free_rate: 0.02
```

### With Transaction Costs

Input record must include `current_weights` and `transaction_costs`:

```yaml
custom_function:
  module: pyoptima.etl
  function: optimize_batch
  kwargs:
    objective: max_sharpe_with_costs
    risk_free_rate: 0.02
```

## Python Usage

For direct Python usage without pycharter:

```python
from pyoptima.etl import optimize_batch, validate_inputs

# Prepare data
data = [{
    "job_id": "job-001",
    "symbols": ["AAPL", "GOOGL", "MSFT"],
    "expected_returns": {"AAPL": 0.12, "GOOGL": 0.10, "MSFT": 0.08},
    "covariance_matrix": {
        "matrix": [[0.04, 0.01, 0.02], [0.01, 0.03, 0.015], [0.02, 0.015, 0.025]],
        "symbols": ["AAPL", "GOOGL", "MSFT"]
    }
}]

# Validate first (optional)
issues = validate_inputs(data)
if issues:
    print(f"Validation issues: {issues}")

# Optimize
results = optimize_batch(
    data,
    objective="min_volatility",
    solver="ipopt",
    max_weight=0.40
)

for result in results:
    print(f"Job: {result['job_id']}")
    print(f"Status: {result['status']}")
    print(f"Weights: {result['weights']}")
    print(f"Volatility: {result['volatility']:.4f}")
```

## Error Handling

Optimization errors are captured gracefully:

```json
{
  "job_id": "job-001",
  "optimization_type": "min_volatility",
  "symbols": ["AAPL", "GOOGL"],
  "weights": {},
  "expected_return": null,
  "volatility": null,
  "sharpe_ratio": null,
  "status": "error",
  "parameters": {
    "solver": "ipopt",
    "run_at": "2025-01-28T12:00:00Z",
    "error": "Solver failed to find optimal solution"
  }
}
```

## Complete Pipeline Example

### Directory Structure

```
pipelines/min_volatility/
├── extract.yaml
├── transform.yaml
├── load.yaml
└── mock_inputs.json
```

### extract.yaml

```yaml
title: portfolio_extraction
version: "1.0.0"

source_type: file
file_path: ${CONTRACT_DIR}/mock_inputs.json
format: json
```

### transform.yaml

```yaml
title: portfolio_min_volatility
version: "1.0.0"

custom_function:
  module: pyoptima.etl
  function: optimize_batch
  mode: batch
  kwargs:
    objective: min_volatility
    solver: ${SOLVER:-ipopt}
    max_weight: 0.40
```

### load.yaml

```yaml
title: portfolio_loading
version: "1.0.0"

target_table: optimization_results
schema_name: opt
write_method: upsert
primary_key:
  - job_id
  - optimization_type

database:
  url: ${DATABASE_URL}
```

### mock_inputs.json

```json
[
  {
    "job_id": "test-001",
    "symbols": ["AAPL", "GOOGL", "MSFT"],
    "expected_returns": {"AAPL": 0.12, "GOOGL": 0.10, "MSFT": 0.08},
    "covariance_matrix": {
      "matrix": [[0.04, 0.01, 0.02], [0.01, 0.03, 0.015], [0.02, 0.015, 0.025]],
      "symbols": ["AAPL", "GOOGL", "MSFT"]
    }
  }
]
```

## Migration from Custom Bridge Code

If you have existing bridge code like `src/etl/transforms/pyoptima_transform.py`, you can migrate to the built-in module:

**Before:**
```yaml
custom_function:
  module: src.etl.transforms.pyoptima_transform
  function: optimize_batch
  kwargs:
    objective: min_volatility
```

**After:**
```yaml
custom_function:
  module: pyoptima.etl
  function: optimize_batch
  kwargs:
    objective: min_volatility
```

The input/output format is compatible, so no changes to extract or load configs are needed.

## API Reference

### optimize_batch()

```python
def optimize_batch(
    data: List[Dict[str, Any]],
    objective: str,
    solver: str = "ipopt",
    **kwargs: Any,
) -> List[Dict[str, Any]]:
    """
    Run portfolio optimization on a batch of records.
    
    Args:
        data: List of input records
        objective: Optimization objective name
        solver: Solver to use (default: "ipopt")
        **kwargs: Additional config parameters
        
    Returns:
        List of ETL-ready output records
    """
```

### validate_inputs()

```python
def validate_inputs(
    data: List[Dict[str, Any]]
) -> Dict[str, List[str]]:
    """
    Validate input records without running optimization.
    
    Args:
        data: List of input records
        
    Returns:
        Dict mapping job_id to list of validation issues
    """
```

### ETLInputAdapter

```python
class ETLInputAdapter:
    """Normalizes various input formats to pyoptima format."""
    
    @classmethod
    def normalize(cls, record: Dict) -> Dict:
        """Normalize an input record."""
    
    @classmethod
    def validate(cls, record: Dict) -> List[str]:
        """Validate a normalized record, return list of issues."""
```

### ETLOutputFormatter

```python
class ETLOutputFormatter:
    """Formats optimization results for ETL loading."""
    
    @classmethod
    def format_result(cls, result, job_id, objective, ...) -> Dict:
        """Format a successful result."""
    
    @classmethod
    def format_error(cls, error, job_id, objective, ...) -> Dict:
        """Format an error result."""
```
