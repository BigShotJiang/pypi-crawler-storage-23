# PyOptima Migration Guide

This guide helps you migrate from the legacy template API to the new sklearn-style API.

## Why Migrate?

The new API provides:

- **sklearn-style interface** with `get_params()`, `set_params()`, `clone()`
- **Composable constraints** using `+` operator
- **pandas-style IO** with `read_portfolio_csv()`, `read_portfolio_json()`
- **Better result objects** with `to_dataframe()`, `weights_to_dataframe()`
- **Type hints** throughout for better IDE support

## Quick Comparison

### Legacy API

```python
from pyoptima import solve

result = solve("portfolio", {
    "expected_returns": [0.1, 0.12, 0.08],
    "covariance_matrix": [[0.04, 0.01, 0.02], ...],
    "objective": "min_volatility",
    "weight_bounds": [0, 0.4],
})

print(result["status"])
print(result["weights"])
```

### New API

```python
from pyoptima import PortfolioOptimizer, WeightBounds

opt = PortfolioOptimizer(
    objective="min_volatility",
    constraints=[WeightBounds(0, 0.4)]
)

result = opt.solve(
    expected_returns=[0.1, 0.12, 0.08],
    covariance_matrix=[[0.04, 0.01, 0.02], ...],
)

print(result.status)          # Enum, not string
print(result.weights)         # Dict
print(result.sharpe_ratio)    # Direct attribute
df = result.weights_to_dataframe()  # pandas DataFrame
```

## Migration Steps

### 1. Replace `solve()` with `PortfolioOptimizer`

**Before:**
```python
result = solve("portfolio", data)
```

**After:**
```python
opt = PortfolioOptimizer(objective=data["objective"])
result = opt.solve(**data)
```

### 2. Use Constraint Objects

**Before:**
```python
data = {
    "weight_bounds": [0, 0.4],
    "max_assets": 10,
    "sector_caps": {"Tech": 0.3},
}
```

**After:**
```python
from pyoptima import WeightBounds, MaxAssets, SectorCaps

constraints = (
    WeightBounds(0, 0.4) +
    MaxAssets(10) +
    SectorCaps({"Tech": 0.3})
)

opt = PortfolioOptimizer(
    objective="min_volatility",
    constraints=list(constraints)
)
```

### 3. Use IO Functions

**Before:**
```python
import json
with open("data.json") as f:
    data = json.load(f)
```

**After:**
```python
from pyoptima import read_portfolio_json

data = read_portfolio_json("data.json")
result = opt.solve(**data.to_dict())
```

### 4. Access Result Properties

**Before:**
```python
status = result["status"]
weights = result["weights"]
sharpe = result.get("sharpe_ratio")
```

**After:**
```python
status = result.status        # SolverStatus enum
is_ok = result.is_optimal     # Boolean property
weights = result.weights      # Direct access
sharpe = result.sharpe_ratio  # Direct access

# Export
df = result.weights_to_dataframe()
json_str = result.to_json()
result.to_sql("results", connection)
```

## Backward Compatibility

The legacy API is **fully preserved**. You can:

- Continue using `solve("portfolio", data)`
- Mix old and new APIs in the same codebase
- Migrate gradually

## Constraint Mapping

| Legacy Parameter | New Constraint Class |
|-----------------|---------------------|
| `weight_bounds: [min, max]` | `WeightBounds(min, max)` |
| `min_weight`, `max_weight` | `WeightBounds(min, max)` |
| `max_assets` | `MaxAssets(n)` |
| `min_position_size` | `MinPositionSize(size)` |
| `sector_caps` | `SectorCaps(caps)` |
| `sector_mins` | `SectorMins(mins)` |
| `max_turnover` | `MaxTurnover(max, current)` |
| `transaction_costs` | `TransactionCosts(costs)` |

## Objective Mapping

Objectives use the same string names:

```python
# All these work the same:
PortfolioOptimizer(objective="min_volatility")
PortfolioOptimizer(objective="max_sharpe")
PortfolioOptimizer(objective="efficient_return", target_return=0.10)
# ... all 31 objectives supported
```

## Advanced: Clone and Parameter Updates

```python
# Clone with different objective
opt2 = clone(opt, objective="max_sharpe")

# Update parameters
opt.set_params(risk_free_rate=0.02, max_weight=0.3)

# Get all parameters
params = opt.get_params()
```

## Questions?

If you have questions about migration, please open an issue on GitHub.
