# PyOptima Documentation

Welcome to PyOptima documentation! This directory contains comprehensive guides for using and extending PyOptima.

## Documentation Index

### Getting Started
- **Quick Start**: See `examples/01_quickstart.py` for basic usage
- **Examples**: Check the `examples/` directory for working code

### Core Documentation

1. **[Architecture Documentation](ARCHITECTURE.md)**
   - System architecture and design
   - Component overview
   - Data flow diagrams
   - Extension points

2. **[Template Development Guide](TEMPLATE_DEVELOPMENT.md)**
   - How to create new problem templates
   - Step-by-step instructions
   - Best practices
   - Common patterns

3. **[Expression Language Reference](EXPRESSION_LANGUAGE.md)**
   - Complete syntax reference
   - Supported operators and functions
   - Usage examples
   - Advanced features

## Quick Links

### For Users
- **Solving Problems**: `from pyoptima import solve`
- **Available Templates**: `from pyoptima import list_templates`
- **Configuration Files**: See `examples/configs/` for YAML examples

### For Developers
- **Creating Templates**: See [Template Development Guide](TEMPLATE_DEVELOPMENT.md)
- **Understanding Architecture**: See [Architecture Documentation](ARCHITECTURE.md)
- **Expression Language**: See [Expression Language Reference](EXPRESSION_LANGUAGE.md)

## Common Tasks

### List Available Templates
```python
from pyoptima import list_templates
print(list_templates())
```

### Solve a Problem
```python
from pyoptima import solve

result = solve("knapsack", {
    "items": [{"name": "A", "value": 60, "weight": 10}],
    "capacity": 50
})
```

### Use Configuration File
```python
from pyoptima import run_from_config

result = run_from_config("config.yaml")
```

### Build Custom Model
```python
from pyoptima import AbstractModel, Expression, get_solver

model = AbstractModel("MyProblem")
model.add_continuous("x", lb=0)
# ... add constraints and objective ...
solver = get_solver("highs")
result = solver.solve(model)
```

## Getting Help

- **Error Messages**: PyOptima provides helpful error messages with suggestions
- **Examples**: Check `examples/` directory
- **Documentation**: See files in this directory
- **Issues**: Open an issue on GitHub

## Next Steps

1. Try the [Quick Start example](../examples/01_quickstart.py)
2. Explore [all templates example](../examples/02_all_templates.py)
3. Read the [Architecture Documentation](ARCHITECTURE.md) to understand the system
4. Create your own template using the [Template Development Guide](TEMPLATE_DEVELOPMENT.md)
