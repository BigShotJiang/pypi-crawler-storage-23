# Adding Constraints to Optimization Problems

PyOptima provides multiple ways to add constraints to optimization problems, depending on the approach you're using.

## Overview of Constraint Methods

### 1. **Template-Based Constraints** (Easiest)
For problem templates (TSP, Knapsack, Scheduling, etc.), use the `custom_constraints` parameter.

### 2. **Declarative Config Constraints** (Most Flexible)
Use the expression language in declarative configuration files.

### 3. **Direct Model Manipulation** (Programmatic)
Manually add constraints to `AbstractModel` objects.

### 4. **Portfolio-Specific Constraints** (Portfolio Only)
Use `ConstraintsConfig` for portfolio optimization methods.

---

## 1. Template-Based Constraints

Most templates support a `custom_constraints` parameter that allows you to add constraints without writing model code.

### Scheduling Template

```python
from pyoptima.templates import JobShopTemplate

template = JobShopTemplate()
data = {
    "jobs": [...],
    "num_machines": 2,
    "custom_constraints": [
        {"type": "deadline", "job": 0, "operation": 1, "deadline": 10},
        {"type": "release_time", "job": 1, "operation": 0, "release_time": 3}
    ]
}
result = template.solve(data)
```

### Adding Custom Constraints to Other Templates

You can extend any template to support custom constraints by:

1. **Modifying the template's `build_model` method** to accept `custom_constraints`
2. **Using the expression language** to parse constraint expressions
3. **Manually adding constraints** after building the model

Example: Adding constraints to Knapsack template

```python
from pyoptima.templates import KnapsackTemplate
from pyoptima.model import Expression

class ExtendedKnapsack(KnapsackTemplate):
    def build_model(self, data):
        model = super().build_model(data)
        
        # Add custom constraints
        custom_constraints = data.get("custom_constraints", [])
        for constraint in custom_constraints:
            if constraint["type"] == "min_items":
                # At least N items must be selected
                expr = Expression()
                for i in range(len(data["items"])):
                    expr.add_term(1.0, f"x[{i}]")
                model.add_geq_constraint("min_items", expr, constraint["min_count"])
        
        return model
```

---

## 2. Declarative Config Constraints (Expression Language)

The most flexible approach uses the declarative configuration system with expression language.

### YAML Configuration

```yaml
meta:
  job_id: custom-opt-001
  solver: highs

sets:
  - name: I
    elements: [0, 1, 2, 3, 4]

parameters:
  cost: [10, 20, 15, 25, 30]
  budget: 100

variables:
  - name: x
    type: binary
    indices: ["i in I"]

objective:
  sense: maximize
  expr: "sum(i in I: value[i] * x[i])"

constraints:
  # Budget constraint
  - name: budget
    expr: "sum(i in I: cost[i] * x[i]) <= budget"
  
  # At least 2 items
  - name: min_items
    expr: "sum(i in I: x[i]) >= 2"
  
  # Conditional: if item 0 selected, item 1 must be selected
  - name: conditional
    expr: "x[0] <= x[1]"
  
  # Indexed constraint
  - name: capacity
    expr: "sum(i in I: weight[i] * x[i]) <= capacity"
    for: "j in J"  # If you have multiple capacities
```

### Python Code

```python
from pyoptima.config_parser import parse_config_file
from pyoptima.models.config import DeclarativeConfig

config = parse_config_file("problem.yaml")
# Solve using the declarative config...
```

### Expression Language Syntax

Supported expressions:
- **Arithmetic**: `x + y`, `x * y`, `x / y`, `x^2`
- **Summation**: `sum(i in I: cost[i] * x[i])`
- **Comparisons**: `x <= 10`, `y >= 5`, `z == 3`
- **Functions**: `sqrt(x)`, `abs(x)`, `max(x, y)`, `min(x, y)`
- **Indexed variables**: `x[i]`, `cost[i,j]`
- **Conditional**: `x[i] <= x[j]` (logical constraints)

---

## 3. Direct Model Manipulation

For programmatic constraint addition, work directly with `AbstractModel`:

```python
from pyoptima.model import AbstractModel, Expression
from pyoptima.solvers import get_solver, SolverOptions

# Build model
model = AbstractModel("MyProblem")

# Add variables
for i in range(5):
    model.add_binary(f"x", indices=(i,))

# Add objective
obj_expr = Expression()
for i in range(5):
    obj_expr.add_term(values[i], f"x[{i}]")
model.maximize(obj_expr)

# Add constraints directly
# Constraint 1: Budget limit
budget_expr = Expression()
for i in range(5):
    budget_expr.add_term(costs[i], f"x[{i}]")
model.add_leq_constraint("budget", budget_expr, 100)

# Constraint 2: At least 2 items
min_items_expr = Expression()
for i in range(5):
    min_items_expr.add_term(1.0, f"x[{i}]")
model.add_geq_constraint("min_items", min_items_expr, 2)

# Constraint 3: If item 0 selected, item 1 must be selected
conditional_expr = Expression()
conditional_expr.add_term(1.0, "x[0]")
conditional_expr.add_term(-1.0, "x[1]")
model.add_leq_constraint("conditional", conditional_expr, 0)

# Solve
solver = get_solver("highs")
result = solver.solve(model, SolverOptions())
```

### Expression Building

```python
from pyoptima.model import Expression

# Create expression
expr = Expression()

# Add terms
expr.add_term(10.0, "x[0]")      # 10 * x[0]
expr.add_term(20.0, "x[1]")      # 20 * x[1]
expr.add_constant(5.0)           # + 5

# Result: 10*x[0] + 20*x[1] + 5

# Add constraint
model.add_leq_constraint("my_constraint", expr, 100)
```

---

## 4. Portfolio-Specific Constraints

For portfolio optimization, use `ConstraintsConfig`:

```python
from pyoptima.models.config import OptimizationConfig, ConstraintsConfig, Meta

config = OptimizationConfig(
    meta=Meta(job_id="portfolio-001", solver="ipopt"),
    method="min_volatility",
    constraints=ConstraintsConfig(
        weight_bounds=(0, 1),
        sector_caps={"Technology": 0.40},
        max_positions=10,
        min_position_size=0.05
    )
)
```

See `docs/CONSTRAINTS.md` for full portfolio constraint documentation.

---

## Common Constraint Patterns

### Linear Constraints

```python
# Sum constraint: sum(x[i]) <= limit
expr = Expression()
for i in range(n):
    expr.add_term(1.0, f"x[{i}]")
model.add_leq_constraint("sum_limit", expr, limit)

# Weighted sum: sum(w[i] * x[i]) <= budget
expr = Expression()
for i in range(n):
    expr.add_term(weights[i], f"x[{i}]")
model.add_leq_constraint("budget", expr, budget)
```

### Binary Constraints

```python
# At least K items: sum(x[i]) >= K
expr = Expression()
for i in range(n):
    expr.add_term(1.0, f"x[{i}]")
model.add_geq_constraint("min_items", expr, K)

# At most K items: sum(x[i]) <= K
model.add_leq_constraint("max_items", expr, K)

# Exactly K items: sum(x[i]) == K
model.add_eq_constraint("exact_items", expr, K)
```

### Conditional Constraints

```python
# If x[0] = 1, then x[1] = 1 (x[0] <= x[1])
expr = Expression()
expr.add_term(1.0, "x[0]")
expr.add_term(-1.0, "x[1]")
model.add_leq_constraint("if_then", expr, 0)

# Either x[0] = 1 or x[1] = 1 (x[0] + x[1] >= 1)
expr = Expression()
expr.add_term(1.0, "x[0]")
expr.add_term(1.0, "x[1]")
model.add_geq_constraint("either_or", expr, 1)

# At most one of x[0], x[1] (x[0] + x[1] <= 1)
expr = Expression()
expr.add_term(1.0, "x[0]")
expr.add_term(1.0, "x[1]")
model.add_leq_constraint("at_most_one", expr, 1)
```

### Indexed Constraints

```python
# For each j in J: sum(i in I: x[i,j]) <= capacity[j]
for j in range(m):
    expr = Expression()
    for i in range(n):
        expr.add_term(1.0, f"x[{i},{j}]")
    model.add_leq_constraint(f"capacity_{j}", expr, capacity[j])
```

### Range Constraints

```python
# Lower bound: x >= lb
expr = Expression()
expr.add_term(1.0, "x")
model.add_geq_constraint("lb", expr, lb)

# Upper bound: x <= ub
model.add_leq_constraint("ub", expr, ub)

# Range: lb <= x <= ub (add both constraints)
```

---

## Extending Templates with Custom Constraints

To add custom constraint support to any template:

```python
from pyoptima.templates.base import ProblemTemplate
from pyoptima.model import AbstractModel, Expression
from pyoptima.expression import parse_expression, evaluate_expression

class MyTemplate(ProblemTemplate):
    def build_model(self, data):
        model = super().build_model(data)  # Build base model
        
        # Add custom constraints
        custom_constraints = data.get("custom_constraints", [])
        for constraint in custom_constraints:
            self._add_custom_constraint(model, constraint, data)
        
        return model
    
    def _add_custom_constraint(self, model, constraint, data):
        constraint_type = constraint.get("type")
        
        if constraint_type == "expression":
            # Use expression language
            expr_str = constraint["expr"]
            # Parse and add constraint...
        elif constraint_type == "linear":
            # Add linear constraint
            expr = Expression()
            for var, coef in constraint["terms"]:
                expr.add_term(coef, var)
            model.add_leq_constraint(
                constraint["name"],
                expr,
                constraint["rhs"]
            )
```

---

## Best Practices

1. **Use templates** for common problems with standard constraints
2. **Use declarative config** for reusable problem definitions
3. **Use direct model manipulation** for one-off custom problems
4. **Use expression language** for complex constraints
5. **Validate constraints** before solving (check bounds, feasibility)

---

## Examples

See the following example files:

- `examples/23_scheduling_custom_constraints.py` - Custom constraints in scheduling
- `examples/24_scheduling_declarative.py` - Declarative config for scheduling
- `examples/21_expression_language_demo.py` - Expression language usage
- `examples/20_templates_demo.py` - Template usage

---

## Summary

| Approach | Best For | Flexibility | Ease of Use |
|----------|----------|-------------|-------------|
| Template `custom_constraints` | Common constraints | Medium | ⭐⭐⭐⭐⭐ |
| Declarative Config | Reusable problems | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ |
| Direct Model Manipulation | Custom problems | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ |
| Portfolio Constraints | Portfolio only | Medium | ⭐⭐⭐⭐⭐ |

Choose based on your needs:
- **Quick setup**: Use templates with `custom_constraints`
- **Reusability**: Use declarative config files
- **Maximum control**: Use direct model manipulation
- **Portfolio problems**: Use `ConstraintsConfig`
