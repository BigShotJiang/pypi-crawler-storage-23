# Solver Installation Guide

PyOptima supports multiple solvers for different types of optimization problems.

## Setup

The `setup.sh` script handles everything: virtual environment, Python packages, and IPOPT solver binary.

```bash
./setup.sh
```

This installs:
- **IPOPT** binary via `idaes-pse` extensions (downloaded into `venv/bin/`)
- **HiGHS** via `highspy` (pip package, no system deps)
- **CBC** and **GLPK** system binaries (if already installed)

### How IPOPT is Installed

PyOptima uses the IDAES project's pre-built IPOPT binaries:
1. `idaes-pse` is a pip dependency of PyOptima
2. `setup.sh` runs `idaes get-extensions --to venv/bin/` to download the IPOPT binary
3. Pyomo's `ipopt_v2` interface uses this binary directly

No system packages (`coinor-libipopt-dev`, etc.) or C compilation required.

### Verification

```python
from pyomo.environ import SolverFactory

solvers = {
    'ipopt_v2': 'IPOPT (via IDAES binary)',
    'appsi_highs': 'HiGHS (via highspy)',
}

for name, desc in solvers.items():
    solver = SolverFactory(name)
    status = "Available" if solver.available() else "Not Available"
    print(f"{name:15s} - {desc:25s} {status}")
```

## Solver Selection Guide

### When to Use IPOPT

- Quadratic optimization problems (portfolio variance)
- Nonlinear objectives
- Problems with quadratic constraints
- Most portfolio optimization methods:
  - `min_volatility` (minimizes variance - quadratic)
  - `max_sharpe` (ratio optimization - nonlinear)
  - `max_quadratic_utility` (quadratic utility)
  - `efficient_risk` / `efficient_return` (quadratic)

```python
config = {
    "template": "portfolio",
    "data": { "objective": "min_volatility", ... },
    "solver": { "name": "ipopt" }
}
```

### When to Use HiGHS

- Linear programming problems
- Mixed-integer programming (MIP)
- Problems with linear constraints and objectives
- Cardinality constraints (uses binary variables)
- Turnover constraints (linearized)

```python
config = {
    "template": "portfolio",
    "data": { "objective": "min_volatility", ... },
    "solver": { "name": "highs" }
}
```

### Solver Compatibility

| Problem Type | Recommended Solver | Alternative |
|-------------|-------------------|-------------|
| Linear Programming | HiGHS | CBC, GLPK |
| Mixed-Integer Programming | HiGHS | CBC, Gurobi |
| Quadratic Programming | IPOPT (ipopt_v2) | Gurobi |
| Nonlinear Programming | IPOPT (ipopt_v2) | Gurobi |

## Additional Solvers

These require separate installation:

- **CBC** - `sudo apt-get install coinor-cbc` (Ubuntu/Debian)
- **GLPK** - `sudo apt-get install glpk-utils` (Ubuntu/Debian)
- **Gurobi** - Commercial solver (requires license)
- **CPLEX** - Commercial solver (requires license)

## Troubleshooting

### IPOPT Not Available

If `ipopt_v2` is not detected after running `setup.sh`:

1. **Check the binary exists:**
   ```bash
   which ipopt   # Should point to venv/bin/ipopt
   ```

2. **Re-download the binary:**
   ```bash
   idaes get-extensions --to venv/bin/ --verbose
   ```

### HiGHS Not Available

```bash
pip uninstall highspy && pip install highspy
```
