# Scheduling Optimization with Custom Constraints

PyOptima supports scheduling optimization with custom constraints through two approaches:

## 1. Enhanced JobShopTemplate (Recommended)

The `JobShopTemplate` now supports built-in custom constraint types that cover most common scheduling scenarios.

### Supported Custom Constraints

#### Deadline Constraints
Operations must finish by a specific time:

```python
{
    "type": "deadline",
    "job": 0,
    "operation": 1,  # Last operation
    "deadline": 10
}
```

#### Release Time Constraints
Operations cannot start before a specific time:

```python
{
    "type": "release_time",
    "job": 0,
    "operation": 0,  # First operation
    "release_time": 5
}
```

#### Time Window Constraints
Operations must start within a time range:

```python
{
    "type": "time_window",
    "job": 0,
    "operation": 0,
    "earliest": 2,
    "latest": 8
}
```

#### Job Priority Constraints
One job must finish before another starts:

```python
{
    "type": "job_priority",
    "job": 0,  # High priority job
    "must_finish_before": 1  # Must finish before job 1 starts
}
```

#### Sequence Constraints
Operations must be scheduled in sequence with a maximum gap:

```python
{
    "type": "sequence",
    "job": 0,
    "operations": [0, 1, 2],  # Operations in sequence
    "max_gap": 3  # Max gap between consecutive operations
}
```

### Example Usage

```python
from pyoptima.templates import JobShopTemplate

template = JobShopTemplate()

data = {
    "jobs": [
        {
            "name": "Urgent Job",
            "operations": [
                {"machine": 0, "duration": 5},
                {"machine": 1, "duration": 3},
            ]
        },
        {
            "name": "Normal Job",
            "operations": [
                {"machine": 0, "duration": 4},
                {"machine": 1, "duration": 2},
            ]
        },
    ],
    "num_machines": 2,
    "custom_constraints": [
        {
            "type": "deadline",
            "job": 0,
            "operation": 1,
            "deadline": 10
        },
        {
            "type": "release_time",
            "job": 1,
            "operation": 0,
            "release_time": 3
        }
    ]
}

result = template.solve(data)
```

## 2. Declarative Config System (Full Flexibility)

For maximum flexibility, use the declarative configuration system with the expression language. This allows you to define any constraints using algebraic expressions.

### Example: Custom Scheduling with Expression Language

```yaml
meta:
  job_id: custom-schedule-001
  solver: highs

# Define sets
sets:
  - name: J
    elements: [0, 1, 2]  # Jobs
  - name: O
    elements: [0, 1]     # Operations
  - name: M
    elements: [0, 1]   # Machines

# Define parameters
parameters:
  duration:
    0: {0: 5, 1: 3}
    1: {0: 4, 1: 2}
    2: {0: 3, 1: 2}
  machine:
    0: {0: 0, 1: 1}
    1: {0: 0, 1: 1}
    2: {0: 1, 1: 0}
  deadline:
    0: 10
    1: 12
    2: 15

# Define variables
variables:
  - name: start
    type: continuous
    bounds: [0, null]
    indices: ["j in J", "o in O"]
  - name: tardiness
    type: continuous
    bounds: [0, null]
    indices: ["j in J"]

# Objective: minimize total tardiness
objective:
  sense: minimize
  expr: "sum(j in J: tardiness[j])"

# Constraints
constraints:
  # Precedence within jobs
  - name: precedence
    expr: "start[j,o+1] >= start[j,o] + duration[j,o]"
    for: "j in J, o in O where o < |O|-1"
  
  # Deadline constraints
  - name: deadline
    expr: "tardiness[j] >= start[j,last_op] + duration[j,last_op] - deadline[j]"
    for: "j in J"
  
  # Machine capacity (one operation at a time)
  - name: machine_capacity
    expr: "sum(j in J, o in O where machine[j,o] == m: active[j,o,t]) <= 1"
    for: "m in M, t in T"
```

### Expression Language Features for Scheduling

The expression language supports:

- **Summation**: `sum(j in J: tardiness[j])`
- **Indexed variables**: `start[j,o]`, `duration[j,o]`
- **Comparisons**: `start[j,o+1] >= start[j,o] + duration[j,o]`
- **Conditional expressions**: `where machine[j,o] == m`
- **Functions**: `max(...)`, `min(...)`, `abs(...)`

### Common Scheduling Constraint Patterns

#### Precedence
```
start[j,o+1] >= start[j,o] + duration[j,o]
```

#### Deadlines
```
start[j,last_op] + duration[j,last_op] <= deadline[j]
```

#### Release Times
```
start[j,o] >= release_time[j]
```

#### Time Windows
```
earliest[j,o] <= start[j,o] <= latest[j,o]
```

#### Machine Capacity
```
sum(j in J, o in O where machine[j,o] == m: active[j,o,t]) <= capacity[m]
```

#### Resource Limits
```
sum(j in J: resource_usage[j] * active[j,t]) <= max_resource
```

#### Setup Times
```
start[j2,o2] >= start[j1,o1] + duration[j1,o1] + setup_time[j1,j2]
```

## When to Use Each Approach

### Use JobShopTemplate when:
- ✅ You need common scheduling constraints (deadlines, release times, etc.)
- ✅ You want quick setup and production-ready code
- ✅ Your constraints fit the built-in types
- ✅ You prefer simple, declarative data structures

### Use Declarative Config when:
- ✅ You need constraints not supported by templates
- ✅ You want to experiment with different objective functions
- ✅ You have complex resource or timing constraints
- ✅ You want to reuse problem definitions via config files
- ✅ You need research-level flexibility

## Examples

See the following example files:

- `examples/23_scheduling_custom_constraints.py` - Using JobShopTemplate with custom constraints
- `examples/24_scheduling_declarative.py` - Using declarative config for custom scheduling
- `examples/21_expression_language_demo.py` - Expression language syntax and usage

## Extending Custom Constraints

To add new constraint types to JobShopTemplate, extend the `_add_custom_constraints` method in `pyoptima/templates/scheduling.py`.

For fully custom constraints, use the declarative config system with the expression language parser.
