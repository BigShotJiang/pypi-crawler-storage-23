# PyOptima

Portfolio optimization with a sklearn-style API and config-driven workflows. Multiple objectives, constraints, and solvers.

## Features

- **Unified API**: Solve knapsack, LP, MIP, QP, portfolio, job shop, and more through a single interface.
- **Templates**: 14+ built-in problem types; plug in your data and get results.
- **Solvers**: HiGHS, IPOPT, and optional CBC, GLPK, Gurobi, CPLEX.
- **REST API & UI**: Run optimizations via API or the web UI.

## Quick links

- [Architecture](ARCHITECTURE.md) – Package layout and design
- [Template development](TEMPLATE_DEVELOPMENT.md) – Creating custom templates
- [API quick reference](API_QUICK_REFERENCE.md) – REST and Python API
- [Configuration schemas](CONFIG_SCHEMAS.md) – Config file format
