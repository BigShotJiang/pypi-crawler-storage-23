# API Quick Reference

Use this guide to choose the right entry point for your use case.

| Entry point | Use when | Returns |
|-------------|----------|---------|
| `run_from_config(path \| dict)` | DAG/FSM, reproducibility, config-only runs | `OptimizationResult` |
| `PortfolioOptimizer(...).solve(**data)` | Interactive, pipelines, constraints as objects | `OptimizationResult` |
| `solve(template_name, data)` / `get_template(name).solve(data)` | Non-portfolio (lp, knapsack, tsp, etc.) | `OptimizationResult` |
| `optimize_batch(records, objective=..., **kwargs)` | pycharter custom_function, many records | List of ETL records (dicts) |
| POST /v1/optimize, /optimize/async, /optimize/batch | Remote service, Airflow HTTP | JSON (result in body) |
| `pyoptima solve config.json` | Scripts, Airflow BashOperator | Exit code; JSON to stdout or --output |

All in-process APIs return `OptimizationResult`; use `result.to_dict()` for JSON or serialization.

## Choosing an API

- **Config-only run:** `run_from_config("config.json")` — best for DAGs, FSMs, and reproducible runs without code.
- **Code (sklearn-style):** `PortfolioOptimizer(objective="min_volatility").solve(**data)` — best for interactive use and pipelines with composable constraints.
- **Generic template:** `solve("knapsack", data)` or `get_template("lp").solve(data)` — for non-portfolio problems (LP, knapsack, TSP, etc.).
- **Batch/ETL:** `optimize_batch(records, objective="min_volatility", ...)` — for pycharter custom_function or processing many records.
- **API/CLI:** Use the REST API or `pyoptima solve` when running as a remote service or from shell/scripts.
