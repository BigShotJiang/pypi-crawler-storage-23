# Template Development Guide

This guide explains how to create new problem templates for PyOptima.

## Overview

Templates provide a simple, high-level interface for solving specific types of optimization problems. They handle:
- Data validation
- Model construction
- Solution formatting

## Template Structure

Every template must inherit from `ProblemTemplate` and implement four methods:

```python
from pyoptima.templates.base import ProblemTemplate, TemplateInfo, TemplateRegistry

@TemplateRegistry.register("my_problem")
class MyProblemTemplate(ProblemTemplate):
    
    @property
    def info(self) -> TemplateInfo:
        """Return template metadata."""
        pass
    
    def validate_data(self, data: Dict[str, Any]) -> None:
        """Validate input data."""
        pass
    
    def build_model(self, data: Dict[str, Any]) -> AbstractModel:
        """Build optimization model from data."""
        pass
    
    def format_solution(
        self,
        model: AbstractModel,
        result: OptimizationResult,
        data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Format solution for user."""
        pass
```

## Step-by-Step Guide

### Step 1: Define Template Info

The `info` property describes your template:

```python
@property
def info(self) -> TemplateInfo:
    return TemplateInfo(
        name="my_problem",
        description="My Optimization Problem",
        problem_type="LP",  # or "MILP", "QP", "MIQP", etc.
        required_data=["param1", "param2"],  # Required keys
        optional_data=["param3"],            # Optional keys
        default_solver="highs"                # Default solver
    )
```

**Problem Types**:
- `"LP"`: Linear Programming
- `"MILP"`: Mixed Integer Linear Programming
- `"QP"`: Quadratic Programming
- `"MIQP"`: Mixed Integer Quadratic Programming
- `"NLP"`: Nonlinear Programming

### Step 2: Implement Data Validation

Validate that the input data is correct:

```python
def validate_data(self, data: Dict[str, Any]) -> None:
    # Check required fields
    self._require_keys(data, ["param1", "param2"])
    
    # Validate data types and values
    if data["param1"] <= 0:
        raise ValueError("param1 must be positive")
    
    if len(data["param2"]) != data["param1"]:
        raise ValueError("param2 length must match param1")
```

**Helper Method**:
- `self._require_keys(data, keys)`: Validates required keys are present

### Step 3: Build the Model

Convert data into an `AbstractModel`:

```python
def build_model(self, data: Dict[str, Any]) -> AbstractModel:
    model = AbstractModel("MyProblem")
    
    # Add variables
    n = data["param1"]
    for i in range(n):
        model.add_continuous(f"x{i}", lb=0)
    
    # Build objective
    obj = Expression()
    for i in range(n):
        obj.add_term(data["param2"][i], f"x{i}")
    model.maximize(obj)  # or model.minimize(obj)
    
    # Add constraints
    constraint = Expression()
    for i in range(n):
        constraint.add_term(1.0, f"x{i}")
    model.add_leq_constraint("sum_limit", constraint, 100)
    
    return model
```

**Key Methods**:
- `model.add_continuous(name, lb, ub)`: Add continuous variable
- `model.add_binary(name)`: Add binary variable
- `model.add_integer(name, lb, ub)`: Add integer variable
- `model.minimize(expression)`: Set minimization objective
- `model.maximize(expression)`: Set maximization objective
- `model.add_leq_constraint(name, expr, rhs)`: Add <= constraint
- `model.add_geq_constraint(name, expr, rhs)`: Add >= constraint
- `model.add_eq_constraint(name, expr, rhs)`: Add == constraint

### Step 4: Format the Solution

Convert `OptimizationResult` into user-friendly format:

```python
def format_solution(
    self,
    model: AbstractModel,
    result: OptimizationResult,
    data: Dict[str, Any]
) -> Dict[str, Any]:
    if not result.is_feasible:
        return {
            "status": result.status.value,
            "message": result.message
        }
    
    # Extract solution values
    solution = {}
    for i in range(data["param1"]):
        var_name = f"x{i}"
        solution[var_name] = result.solution.get(var_name, 0)
    
    return {
        "status": result.status.value,
        "objective_value": result.objective_value,
        "solution": solution,
        "solve_time": result.solve_time
    }
```

## Complete Example

Here's a complete template for a simple resource allocation problem:

```python
from typing import Any, Dict
from pyoptima.model.core import AbstractModel, Expression, OptimizationResult
from pyoptima.templates.base import ProblemTemplate, TemplateInfo, TemplateRegistry

@TemplateRegistry.register("resource_allocation")
class ResourceAllocationTemplate(ProblemTemplate):
    """
    Allocate resources to maximize value.
    
    Data format:
        {
            "resources": ["R1", "R2", "R3"],
            "values": [10, 20, 15],
            "costs": [5, 8, 6],
            "budget": 20
        }
    """
    
    @property
    def info(self) -> TemplateInfo:
        return TemplateInfo(
            name="resource_allocation",
            description="Resource Allocation Problem",
            problem_type="MILP",
            required_data=["resources", "values", "costs", "budget"],
            optional_data=[],
            default_solver="highs"
        )
    
    def validate_data(self, data: Dict[str, Any]) -> None:
        self._require_keys(data, ["resources", "values", "costs", "budget"])
        
        n = len(data["resources"])
        if len(data["values"]) != n:
            raise ValueError("values length must match resources")
        if len(data["costs"]) != n:
            raise ValueError("costs length must match resources")
        if data["budget"] <= 0:
            raise ValueError("budget must be positive")
    
    def build_model(self, data: Dict[str, Any]) -> AbstractModel:
        resources = data["resources"]
        values = data["values"]
        costs = data["costs"]
        budget = data["budget"]
        n = len(resources)
        
        model = AbstractModel("ResourceAllocation")
        
        # Binary variables: 1 if resource is selected, 0 otherwise
        for i, resource in enumerate(resources):
            model.add_binary(f"x_{resource}")
        
        # Objective: maximize total value
        obj = Expression()
        for i, resource in enumerate(resources):
            obj.add_term(values[i], f"x_{resource}")
        model.maximize(obj)
        
        # Constraint: total cost <= budget
        cost_constraint = Expression()
        for i, resource in enumerate(resources):
            cost_constraint.add_term(costs[i], f"x_{resource}")
        model.add_leq_constraint("budget", cost_constraint, budget)
        
        return model
    
    def format_solution(
        self,
        model: AbstractModel,
        result: OptimizationResult,
        data: Dict[str, Any]
    ) -> Dict[str, Any]:
        if not result.is_feasible:
            return {
                "status": result.status.value,
                "message": result.message
            }
        
        # Extract selected resources
        selected = []
        for resource in data["resources"]:
            var_name = f"x_{resource}"
            if result.solution.get(var_name, 0) > 0.5:  # Binary threshold
                selected.append(resource)
        
        return {
            "status": result.status.value,
            "objective_value": result.objective_value,
            "selected_resources": selected,
            "total_cost": sum(
                data["costs"][i] 
                for i, r in enumerate(data["resources"]) 
                if r in selected
            ),
            "solve_time": result.solve_time
        }
```

## Testing Your Template

Test your template:

```python
from pyoptima import solve

# Test with solve() function
result = solve("resource_allocation", {
    "resources": ["R1", "R2", "R3"],
    "values": [10, 20, 15],
    "costs": [5, 8, 6],
    "budget": 20
})

print(result)
# Expected: {'status': 'optimal', 'selected_resources': ['R2', 'R3'], ...}
```

## Best Practices

### 1. Clear Data Format

Document your data format in the docstring:
```python
"""
Resource allocation template.

Data format:
    {
        "resources": [...],
        "values": [...],
        ...
    }
"""
```

### 2. Helpful Error Messages

Provide specific error messages:
```python
if len(values) != len(resources):
    raise ValueError(
        f"values length ({len(values)}) must match resources length ({len(resources)})"
    )
```

### 3. Sensible Defaults

Use reasonable defaults for optional parameters:
```python
solver = data.get("solver", self.info.default_solver)
time_limit = data.get("time_limit", 60)
```

### 4. Consistent Solution Format

Follow existing templates' solution format:
- Always include `status`
- Include `objective_value` when feasible
- Include problem-specific fields
- Include `solve_time` if available

### 5. Indexed Variables

For problems with indices, use indexed variables:
```python
# For 2D indexing
for i in range(n):
    for j in range(m):
        model.add_continuous("x", indices=(i, j))
```

## Registering Your Template

1. **Add the decorator**:
```python
@TemplateRegistry.register("my_problem")
class MyProblemTemplate(ProblemTemplate):
    ...
```

2. **Import in templates/__init__.py**:
```python
from pyoptima.templates.my_module import MyProblemTemplate
```

3. **Test registration**:
```python
from pyoptima import get_template
template = get_template("my_problem")  # Should work!
```

## Advanced Topics

### Custom Constraints

Add custom constraints via template parameters:
```python
def build_model(self, data: Dict[str, Any]) -> AbstractModel:
    model = AbstractModel("MyProblem")
    # ... build base model ...
    
    # Add custom constraints if provided
    if "custom_constraints" in data:
        for constraint_spec in data["custom_constraints"]:
            # Parse and add constraint
            ...
    
    return model
```

### Using Expression Language

Parse expressions from config:
```python
from pyoptima.expression import parse_expression, evaluate_expression

expr_str = data.get("objective_expr", "sum(i in I: cost[i] * x[i])")
expr_node = parse_expression(expr_str)
# Evaluate with context
```

### Solver-Specific Options

Allow solver-specific options:
```python
def solve(self, data, solver=None, options=None):
    solver_options = options or {}
    if "mip_gap" in data:
        solver_options["mip_gap"] = data["mip_gap"]
    return super().solve(data, solver, solver_options)
```

## Common Patterns

### Pattern 1: Selection Problem (Binary Variables)

```python
# Binary variables for selection
for item in items:
    model.add_binary(f"select_{item}")

# Constraint: select at most k items
expr = Expression()
for item in items:
    expr.add_term(1.0, f"select_{item}")
model.add_leq_constraint("max_selection", expr, k)
```

### Pattern 2: Assignment Problem (Binary Variables)

```python
# Binary variables: x[i,j] = 1 if i assigned to j
for i in range(n):
    for j in range(m):
        model.add_binary("x", indices=(i, j))

# Constraint: each i assigned to exactly one j
for i in range(n):
    expr = Expression()
    for j in range(m):
        expr.add_term(1.0, "x", indices=(i, j))
    model.add_eq_constraint(f"assign_{i}", expr, 1)
```

### Pattern 3: Flow Problem (Continuous Variables)

```python
# Continuous variables for flow
for arc in arcs:
    model.add_continuous(f"flow_{arc}", lb=0, ub=capacity)

# Flow conservation at nodes
for node in nodes:
    expr = Expression()
    # Outgoing flow
    for arc in outgoing_arcs:
        expr.add_term(1.0, f"flow_{arc}")
    # Incoming flow
    for arc in incoming_arcs:
        expr.add_term(-1.0, f"flow_{arc}")
    model.add_eq_constraint(f"balance_{node}", expr, net_supply)
```

## Troubleshooting

### Template Not Found

**Problem**: `ValueError: Template 'my_problem' not found`

**Solution**: 
- Check `@TemplateRegistry.register("my_problem")` is present
- Ensure template is imported in `templates/__init__.py`
- Verify template name matches exactly (case-insensitive)

### Model Building Errors

**Problem**: `ValueError: Variable 'x' not found in model`

**Solution**:
- Ensure variable names match exactly
- Check variable is added before use in expressions
- Use `var.full_name` for indexed variables

### Solver Errors

**Problem**: Solver fails or returns infeasible

**Solution**:
- Check model is valid: `model.num_variables > 0`
- Verify constraints are consistent
- Try different solver: `solve(..., solver="highs")`
- Check solver supports problem type

## Shipping a plugin

To register templates from a separate package without editing PyOptima, use the `pyoptima.templates` entry point. PyOptima discovers and calls each registered callable on first use of `get_template()` or `list_templates()`.

**Example:** In your package `mypkg`, define a function that registers templates:

```python
# mypkg/templates.py
from pyoptima.templates.base import TemplateRegistry
from mypkg.my_templates import MyProblemTemplate  # your template class

def register_templates():
    TemplateRegistry._templates["my_problem"] = MyProblemTemplate
```

In `pyproject.toml` of your package:

```toml
[project.entry-points."pyoptima.templates"]
mycompany = "mypkg.templates:register_templates"
```

After `pip install mypkg`, `get_template("my_problem")` and `list_templates()` will include your template.

## Next Steps

1. Review existing templates in `pyoptima/templates/`
2. Start with a simple template (like the resource allocation example)
3. Test thoroughly with various inputs
4. Document your template's data format
5. Consider adding to examples or shipping as a plugin

For questions or issues, check the main documentation or open an issue.
