# PyOptima with pystator

Call PyOptima from pystator (FSM) actions for config-driven or batch optimization.

## Patterns

### 1. Run from config (single job)

Use when the FSM has a config path or config dict (e.g. from context or config store).

```python
from pyoptima import run_from_config

# In a pystator action
def run_optimization(context):
    config_path = context.get("config_path")  # or from store
    result = run_from_config(config_path)
    # result is OptimizationResult
    context["weights"] = result.weights
    context["status"] = result.status.value
    return result.to_dict()  # or push to state store
```

Pass a job id for correlation:

```python
from pyoptima import run_from_config, load_config

config = load_config({"template": "portfolio", "data": {...}, "solver": {"name": "ipopt"}, "job_id": context["job_id"]})
result = run_from_config(config)
# result.metadata["job_id"] is set when config.job_id was provided
```

### 2. Batch optimization (list of inputs)

Use when the FSM has a list of records (e.g. from a previous step).

```python
from pyoptima.etl import optimize_batch

def run_batch_optimization(context):
    records = context["input_records"]  # list of dicts with expected_returns, covariance_matrix, etc.
    results = optimize_batch(records, objective="min_volatility", solver="ipopt")
    # results is a list of ETL-ready dicts (job_id, weights, status, ...)
    context["optimization_results"] = results
    return results
```

Each record can include `job_id` for tracking; errors are per-record with `status: "error"`.

## What to do with the result

- **Write to state store:** `context["weights"] = result.weights` or store `result.to_dict()`.
- **Trigger next transition:** Use result status or weights in a guard or pass to the next action.
- **Return to caller:** Return `result.to_dict()` or the ETL list from the action.

## Minimal example (action)

```python
from pyoptima import run_from_config

async def on_optimize(state, context):
    path = context.get("config_path", "config/portfolio.json")
    result = run_from_config(path)
    context["optimization_result"] = result.to_dict()
    context["status"] = result.status.value
    return state
```
