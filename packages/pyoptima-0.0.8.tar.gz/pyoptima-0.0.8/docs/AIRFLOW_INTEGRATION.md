# PyOptima with Airflow

Run PyOptima from Airflow DAGs via PythonOperator, BashOperator, or HTTP.

## 1. PythonOperator (in-process)

Load config (file or XCom), run optimization, push result to XCom.

```python
from airflow.decorators import dag, task

@dag(schedule=None, start_date=...)
def pyoptima_dag():
    @task
    def optimize(config_path: str):
        from pyoptima import run_from_config
        result = run_from_config(config_path)
        return result.to_dict()

    result = optimize("path/to/config.json")
```

With config from XCom:

```python
    @task
    def optimize(config: dict):
        from pyoptima import run_from_config
        result = run_from_config(config)
        return result.to_dict()

    result = optimize(upstream_config_output)
```

Idempotency: use a stable `task_id` and, if needed, include a config hash in the config or `job_id` so reruns are identifiable.

## 2. BashOperator (CLI)

```python
from airflow.operators.bash import BashOperator

optimize = BashOperator(
    task_id="optimize",
    bash_command='pyoptima solve /path/to/config.json --output /tmp/result.json --pretty',
)
```

## 3. HTTP (sync API)

Call the PyOptima API from an HTTP operator or custom sensor.

```python
# Sync: POST /v1/optimize with body { "template": "portfolio", "data": {...}, "solver": {"name": "ipopt"} }
# Response: { "job_id": "...", "status": "optimal", "result": {...}, "duration_ms": ... }
```

For long-running jobs, use POST /v1/optimize/async and poll GET /v1/jobs/{job_id} until completed.

## Retries and errors

- PyOptima raises `ValidationError`, `SolverError`, `OptimizationError` on failure. Map these to task failure so Airflow can retry or alert.
- Check `result.status` (e.g. `optimal`, `feasible`, `error`) and fail the task if not acceptable.

## Minimal example DAG

```python
from airflow.decorators import dag, task
from datetime import datetime

@dag(schedule=None, start_date=datetime(2025, 1, 1), catchup=False)
def pyoptima_example():
    @task
    def run_optimization():
        from pyoptima import run_from_config
        result = run_from_config("dags/configs/portfolio.json")
        if result.status.value != "optimal" and result.status.value != "feasible":
            raise RuntimeError(f"Optimization failed: {result.status.value}")
        return result.to_dict()

    run_optimization()

pyoptima_example()
```
