# Portfolio Optimization Constraints

PyOptima supports advanced constraints for portfolio optimization beyond basic weight bounds.

## Constraint Types

### 1. Per-Asset Bounds

Set individual min/max bounds for each asset.

```python
from pyoptima.models.config import ConstraintsConfig

constraints = ConstraintsConfig(
    per_asset_bounds={
        "AAPL": (0.05, 0.30),  # Min 5%, Max 30%
        "MSFT": (0.10, 0.40),  # Min 10%, Max 40%
        "GOOGL": (0.0, 0.25)   # No minimum, Max 25%
    }
)
```

**Use case**: Different risk profiles per asset, regulatory limits.

### 2. Sector Exposure Caps

Limit total exposure to specific sectors.

```python
constraints = ConstraintsConfig(
    sector_caps={
        "Technology": 0.40,    # Max 40% in Technology
        "Financials": 0.30,    # Max 30% in Financials
        "Healthcare": 0.25      # Max 25% in Healthcare
    },
    asset_sectors={
        "AAPL": "Technology",
        "MSFT": "Technology",
        "GOOGL": "Technology",
        "JPM": "Financials",
        "JNJ": "Healthcare"
    }
)
```

**Use case**: Diversification requirements, sector concentration limits.

### 3. Sector Minimums

Enforce minimum exposure to sectors.

```python
constraints = ConstraintsConfig(
    sector_mins={
        "Technology": 0.20,    # At least 20% in Technology
        "Healthcare": 0.10      # At least 10% in Healthcare
    },
    asset_sectors={...}
)
```

**Use case**: Strategic allocation requirements.

### 4. Cardinality (Max Positions)

Limit the number of non-zero positions.

```python
constraints = ConstraintsConfig(
    max_positions=10,           # Hold at most 10 assets
    min_position_size=0.01      # If held, must be at least 1%
)
```

**Use case**: Reduce transaction costs, simplify portfolio management.

### 5. Turnover Limits

Limit trading from current portfolio.

```python
constraints = ConstraintsConfig(
    max_turnover=0.50,          # Max 50% turnover
    current_weights={
        "AAPL": 0.20,
        "MSFT": 0.30,
        "GOOGL": 0.50
    }
)
```

**Use case**: Rebalancing with transaction cost control.

### 6. Minimum Position Size

If an asset is held, it must meet a minimum size.

```python
constraints = ConstraintsConfig(
    min_position_size=0.05       # If held, must be at least 5%
)
```

**Use case**: Avoid tiny positions, reduce management overhead.

## Constraint Combinations

You can combine multiple constraints:

```python
constraints = ConstraintsConfig(
    # Sector constraints
    sector_caps={"Technology": 0.40},
    asset_sectors={...},
    
    # Position limits
    max_positions=15,
    min_position_size=0.02,
    
    # Turnover control
    max_turnover=0.30,
    current_weights={...},
    
    # Per-asset bounds
    per_asset_bounds={"AAPL": (0.05, 0.30)}
)
```

## Constraint Interactions

Some constraints interact:

- **Cardinality + Min Position Size**: If `max_positions=10` and `min_position_size=0.05`, each held position must be at least 5%, so maximum total is 50% if all 10 are held. This may conflict with the weight sum constraint (100%).

- **Sector Caps + Per-Asset Bounds**: Per-asset bounds are applied first, then sector caps are checked.

- **Turnover + Current Weights**: Turnover requires current weights. If current weights don't match symbols, constraint will fail.

## Examples

### Example 1: Diversified Technology Portfolio

```python
constraints = ConstraintsConfig(
    sector_caps={"Technology": 0.50},
    asset_sectors={
        "AAPL": "Technology",
        "MSFT": "Technology",
        "GOOGL": "Technology"
    },
    max_positions=20,
    min_position_size=0.02
)
```

### Example 2: Low-Turnover Rebalancing

```python
constraints = ConstraintsConfig(
    max_turnover=0.20,  # Only 20% turnover allowed
    current_weights={
        "AAPL": 0.25,
        "MSFT": 0.35,
        "GOOGL": 0.40
    },
    per_asset_bounds={
        "AAPL": (0.20, 0.30),  # Stay close to current
        "MSFT": (0.30, 0.40),
        "GOOGL": (0.35, 0.45)
    }
)
```

### Example 3: Concentrated High-Conviction

```python
constraints = ConstraintsConfig(
    max_positions=5,        # Only 5 positions
    min_position_size=0.10,  # Each at least 10%
    per_asset_bounds={
        "AAPL": (0.15, 0.30),  # Large positions
        "MSFT": (0.15, 0.30),
        "GOOGL": (0.15, 0.30),
        "JPM": (0.10, 0.25),
        "JNJ": (0.10, 0.25)
    }
)
```

## Configuration Format

In JSON config files:

```json
{
  "meta": {
    "job_id": "portfolio-001",
    "solver": "ipopt"
  },
  "method": "min_volatility",
  "constraints": {
    "sector_caps": {"Technology": 0.40},
    "asset_sectors": {
      "AAPL": "Technology",
      "MSFT": "Technology"
    },
    "max_positions": 10,
    "min_position_size": 0.05,
    "max_turnover": 0.30,
    "current_weights": {
      "AAPL": 0.20,
      "MSFT": 0.30
    },
    "per_asset_bounds": {
      "AAPL": [0.05, 0.30],
      "MSFT": [0.10, 0.40]
    }
  },
  "parameters": {
    "weight_bounds": [0, 1]
  }
}
```

## Best Practices

1. **Start simple**: Add constraints incrementally
2. **Check feasibility**: Too many constraints can make problems infeasible
3. **Use cardinality carefully**: Can significantly change portfolio structure
4. **Validate sector mappings**: Ensure all assets have sector assignments
5. **Test constraint combinations**: Some combinations may conflict

## Troubleshooting

### Infeasible Problems

If optimization fails with "infeasible", try:
- Relaxing constraints
- Removing some constraints
- Checking constraint values are reasonable

### Constraint Not Applied

- Verify constraint is in `ConstraintsConfig`
- Check `asset_sectors` is provided for sector constraints
- Ensure `current_weights` matches symbols for turnover

### Performance Issues

- Cardinality constraints use binary variables (slower)
- Many constraints increase solve time
- Consider solver choice (CBC for linear, IPOPT for nonlinear)
