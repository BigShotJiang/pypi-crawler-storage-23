# Config schemas

Per-template schema for the `data` payload is available in code. No generated schema files are shipped.

## Portfolio

The portfolio template expects `data` with at least:

- `objective` (string): e.g. `min_volatility`, `max_sharpe`
- `expected_returns`: list of floats or dict by symbol
- `covariance_matrix`: list of lists or nested dict with `matrix` and `symbols`

Optional fields include `symbols`, `weight_bounds`, `target_return`, `target_volatility`, `sector_caps`, `asset_sectors`, `max_assets`, `max_turnover`, `current_weights`, etc.

### Getting the JSON schema

From Python:

```python
from pyoptima.templates.portfolio_config import portfolio_data_schema

schema = portfolio_data_schema()  # dict suitable for JSON Schema validators
```

When running from config, portfolio `data` is validated in `run_from_config` before solving; invalid data raises `ValidationError`.

## Other templates

Other templates (lp, knapsack, tsp, etc.) document their `data` shape in the template docstring and in [TEMPLATE_DEVELOPMENT](TEMPLATE_DEVELOPMENT.md). Schema export for other templates can be added later following the same pattern (function returning a dict).
