# New Portfolio Optimization Methods

This document describes the newly added portfolio optimization methods in PyOptima, designed for weekly rebalancing and day trading watchlist selection.

## Overview

PyOptima now supports **31 portfolio optimization objectives** (up from 21), including new methods for:
- Maximum diversification
- Risk parity / equal risk contribution
- Transaction cost-aware optimization
- Momentum-filtered selection
- Factor-based selection
- Cardinality constraints (watchlist selection)
- Turnover constraints (rebalancing)

## New Methods

### 1. Maximum Diversification

**Objectives:**
- `max_diversification`: Maximize diversification ratio
- `max_diversification_index`: Maximize diversification index

**Use Case:** Better diversification than minimum volatility, often produces superior risk-adjusted returns.

**Example:**
```python
from pyoptima import solve

result = solve("portfolio", {
    "expected_returns": expected_returns,
    "covariance_matrix": cov_matrix,
    "symbols": symbols,
    "objective": "max_diversification",
    "max_weight": 0.15
})

print(f"Diversification Ratio: {result['diversification_ratio']:.3f}")
```

**Returns:**
- `diversification_ratio`: Ratio of weighted average volatility to portfolio volatility
- `diversification_index`: Alternative diversification measure

### 2. Risk Parity / Equal Risk Contribution

**Objectives:**
- `risk_parity`: Equal risk contribution (risk parity)
- `equal_risk_contribution`: Alias for risk_parity

**Use Case:** Each asset contributes equally to portfolio risk. Excellent for stable, diversified portfolios.

**Example:**
```python
result = solve("portfolio", {
    "expected_returns": expected_returns,
    "covariance_matrix": cov_matrix,
    "symbols": symbols,
    "objective": "risk_parity",
    "max_weight": 0.20
})

print(f"Risk Contributions: {result['risk_contributions']}")
print(f"Risk Contribution Std: {result['risk_contribution_std']:.4f}")
```

**Returns:**
- `risk_contributions`: Risk contribution of each asset
- `risk_contribution_std`: Standard deviation of risk contributions (lower = more equal)

**Note:** This method uses a non-linear optimization. For large problems, consider using IPOPT or a specialized solver.

### 3. Transaction Cost-Aware Optimization

**Objectives:**
- `max_sharpe_with_costs`: Maximize Sharpe ratio accounting for transaction costs
- `min_volatility_with_costs`: Minimize volatility accounting for transaction costs

**Use Case:** Critical for weekly rebalancing where transaction costs can significantly impact returns.

**Example:**
```python
result = solve("portfolio", {
    "expected_returns": expected_returns,
    "covariance_matrix": cov_matrix,
    "symbols": symbols,
    "objective": "max_sharpe_with_costs",
    "risk_free_rate": 0.02,
    "current_weights": {
        "AAPL": 0.25,
        "MSFT": 0.35,
        "GOOGL": 0.40
    },
    "transaction_costs": {
        "AAPL": 0.001,  # 0.1% per trade
        "MSFT": 0.001,
        "GOOGL": 0.001
    },
    "max_turnover": 0.30  # Optional: limit turnover
})

print(f"Net Return: {result['net_return']:.2%}")
print(f"Transaction Costs: {result['transaction_costs']:.4f}")
print(f"Net Sharpe Ratio: {result['net_sharpe_ratio']:.3f}")
```

**Parameters:**
- `transaction_costs`: Dict of per-asset costs, or array, or single value
- `current_weights`: Current portfolio weights (required)
- `min_net_return`: Minimum net return (for min_volatility_with_costs)

**Returns:**
- `transaction_costs`: Total transaction costs
- `net_return`: Return after transaction costs
- `net_sharpe_ratio`: Sharpe ratio after costs

### 4. Momentum-Filtered Optimization

**Objectives:**
- `momentum_filtered_max_sharpe`: Filter by momentum, then maximize Sharpe
- `momentum_filtered_min_volatility`: Filter by momentum, then minimize volatility

**Use Case:** Day trading watchlists - select assets with recent positive momentum, then optimize.

**Example:**
```python
result = solve("portfolio", {
    "expected_returns": expected_returns,
    "covariance_matrix": cov_matrix,
    "returns": historical_returns,  # Required for momentum calculation
    "symbols": symbols,
    "objective": "momentum_filtered_max_sharpe",
    "momentum_period": 20,  # Use last 20 periods
    "momentum_top_pct": 0.2,  # Select top 20% by momentum
    "risk_free_rate": 0.02,
    "max_assets": 10  # Optional: limit to 10 assets
})
```

**Parameters:**
- `returns`: Historical returns matrix (required)
- `momentum_period`: Number of periods for momentum calculation (default: 20)
- `momentum_top_pct`: Top percentage to select (default: 0.2 = 20%)

**How it works:**
1. Calculates momentum (average return over last N periods)
2. Selects top X% of assets by momentum
3. Optimizes portfolio from filtered set

### 5. Factor-Based Selection

**Objective:**
- `factor_based_selection`: Select assets based on composite factor scores

**Use Case:** Use technical indicators, fundamental factors, or custom scores for watchlist selection.

**Example:**
```python
result = solve("portfolio", {
    "expected_returns": expected_returns,
    "covariance_matrix": cov_matrix,
    "symbols": symbols,
    "objective": "factor_based_selection",
    "factor_data": {
        "momentum": [0.8, 0.6, 0.9, 0.7, ...],  # Momentum scores
        "value": [0.5, 0.7, 0.4, 0.6, ...],      # Value scores
        "quality": [0.9, 0.8, 0.7, 0.9, ...]    # Quality scores
    },
    "factor_weights": {  # Optional: weight each factor
        "momentum": 0.4,
        "value": 0.3,
        "quality": 0.3
    },
    "max_volatility": 0.20,  # Optional: risk constraint
    "max_assets": 15  # Optional: limit number of assets
})

print(f"Weighted Factor Score: {result['weighted_factor_score']:.3f}")
print(f"Factor Scores: {result['factor_scores']}")
```

**Parameters:**
- `factor_data`: Dict of factor_name -> factor_values array
- `factor_weights`: Optional weights for each factor (default: equal weights)
- `max_volatility`: Optional maximum portfolio volatility

**Returns:**
- `weighted_factor_score`: Portfolio's weighted factor score
- `factor_scores`: Factor scores for each asset

## Advanced Constraints

### Cardinality Constraint (Watchlist Selection)

Limit the number of assets in the portfolio.

**Example:**
```python
result = solve("portfolio", {
    "expected_returns": expected_returns,
    "covariance_matrix": cov_matrix,
    "symbols": symbols,
    "objective": "max_sharpe",
    "max_assets": 10,  # Hold at most 10 assets
    "min_position_size": 0.05  # If held, must be at least 5%
})
```

**Parameters:**
- `max_assets`: Maximum number of non-zero positions
- `min_position_size`: Minimum weight if asset is held

**Returns:**
- `num_assets`: Number of assets selected
- `cardinality`: Same as num_assets

**Note:** Cardinality constraints use binary variables, which makes the problem mixed-integer. Use a MIP solver (e.g., CBC, Gurobi, CPLEX) for best results.

### Turnover Constraint (Rebalancing)

Limit trading from current portfolio.

**Example:**
```python
result = solve("portfolio", {
    "expected_returns": expected_returns,
    "covariance_matrix": cov_matrix,
    "symbols": symbols,
    "objective": "min_volatility",
    "current_weights": {
        "AAPL": 0.25,
        "MSFT": 0.35,
        "GOOGL": 0.40
    },
    "max_turnover": 0.30  # Max 30% turnover
})
```

**Parameters:**
- `current_weights`: Current portfolio weights (dict or array)
- `max_turnover`: Maximum turnover (0.0 to 1.0)

**Returns:**
- `turnover`: Actual turnover amount

**Note:** Turnover is calculated as sum of buy + sell. A 30% turnover means you can trade up to 30% of portfolio value.

## Use Cases

### Weekly Rebalancing

```python
# Optimize for weekly rebalancing with transaction costs
result = solve("portfolio", {
    "expected_returns": weekly_expected_returns,
    "covariance_matrix": weekly_cov_matrix,
    "symbols": symbols,
    "objective": "max_sharpe_with_costs",
    "risk_free_rate": 0.02,
    "current_weights": current_portfolio_weights,
    "transaction_costs": {s: 0.001 for s in symbols},  # 0.1% per trade
    "max_turnover": 0.25,  # Limit to 25% turnover
    "max_weight": 0.15
})
```

### Day Trading Watchlist

```python
# Create watchlist using momentum filtering + cardinality
result = solve("portfolio", {
    "expected_returns": daily_expected_returns,
    "covariance_matrix": daily_cov_matrix,
    "returns": recent_daily_returns,  # Last 60 days
    "symbols": all_symbols,
    "objective": "momentum_filtered_max_sharpe",
    "momentum_period": 20,  # Last 20 days
    "momentum_top_pct": 0.15,  # Top 15% by momentum
    "max_assets": 20,  # Watchlist of 20 stocks
    "min_position_size": 0.03,  # Each at least 3%
    "risk_free_rate": 0.0  # No risk-free rate for day trading
})

# Extract watchlist
watchlist = [s for s, w in result['weights'].items() if w > 0.001]
print(f"Watchlist: {watchlist}")
```

### Factor-Based Watchlist

```python
# Use multiple factors to create watchlist
result = solve("portfolio", {
    "expected_returns": expected_returns,
    "covariance_matrix": cov_matrix,
    "symbols": symbols,
    "objective": "factor_based_selection",
    "factor_data": {
        "rsi": rsi_scores,  # Technical: RSI
        "volume": volume_scores,  # Technical: Volume
        "earnings": earnings_scores  # Fundamental: Earnings growth
    },
    "factor_weights": {
        "rsi": 0.3,
        "volume": 0.2,
        "earnings": 0.5
    },
    "max_assets": 15,
    "max_volatility": 0.25
})
```

## Method Comparison

| Method | Best For | Key Feature |
|--------|----------|-------------|
| `max_diversification` | Long-term portfolios | Better diversification than min_volatility |
| `risk_parity` | Stable portfolios | Equal risk contribution |
| `max_sharpe_with_costs` | Weekly rebalancing | Accounts for transaction costs |
| `momentum_filtered_max_sharpe` | Day trading watchlists | Momentum pre-filtering |
| `factor_based_selection` | Custom strategies | Multi-factor selection |

## Solver Recommendations

- **Linear/Quadratic problems**: `highs`, `ipopt`
- **Cardinality constraints**: `cbc`, `gurobi`, `cplex` (MIP solvers)
- **Risk parity**: `ipopt` (handles non-linear well)
- **Transaction costs**: Any solver (linear constraints)

## Performance Notes

1. **Cardinality constraints** make problems mixed-integer (slower)
2. **Risk parity** uses non-linear optimization (may be slower)
3. **Momentum filtering** reduces problem size (faster)
4. **Turnover constraints** add linear constraints (minimal overhead)

## Examples

See `examples/06_weekly_portfolio_optimization.py` for a complete example of weekly rebalancing with all new features.
