# PyOptima Architecture

## Overview

PyOptima is a universal optimization framework that provides a simple, unified interface for solving a wide range of optimization problems. The architecture is designed around three core principles:

1. **Template-Based**: Common problems are solved via pre-built templates
2. **Solver-Agnostic**: Models are represented independently of solvers
3. **Configuration-Driven**: Problems can be specified via JSON/YAML configs

## Architecture Layers

```
┌─────────────────────────────────────────────────────────┐
│                    User Interface                       │
│  solve(), get_template(), run_from_config()           │
└─────────────────────┬───────────────────────────────────┘
                      │
┌─────────────────────▼───────────────────────────────────┐
│                  Template Layer                          │
│  ProblemTemplate → validate_data() → build_model()      │
│  Templates: LP, QP, MIP, Knapsack, TSP, Portfolio, ... │
└─────────────────────┬───────────────────────────────────┘
                      │
┌─────────────────────▼───────────────────────────────────┐
│                  Model Layer                             │
│  AbstractModel (solver-agnostic representation)         │
│  Variables, Expressions, Constraints, Objectives        │
└─────────────────────┬───────────────────────────────────┘
                      │
┌─────────────────────▼───────────────────────────────────┐
│                  Solver Layer                            │
│  SolverInterface → translate to solver backend          │
│  PyomoSolver, (future: ORToolsSolver, CVXPYSolver)     │
└─────────────────────┬───────────────────────────────────┘
                      │
┌─────────────────────▼───────────────────────────────────┐
│                  Solver Backends                         │
│  HiGHS, IPOPT, CBC, GLPK, Gurobi, CPLEX                 │
└─────────────────────────────────────────────────────────┘
```

## Core Components

### 1. Template Layer (`pyoptima/templates/`)

**Purpose**: Provide high-level, problem-specific interfaces

**Key Classes**:
- `ProblemTemplate`: Abstract base class for all templates
- `TemplateRegistry`: Manages template registration and lookup

**How it works**:
1. User provides problem data in template-specific format
2. Template validates data (`validate_data()`)
3. Template builds solver-agnostic model (`build_model()`)
4. Template formats solution for user (`format_solution()`)

**Example Flow**:
```python
template = get_template("knapsack")
result = template.solve({
    "items": [...],
    "capacity": 50
})
```

**Portfolio as first-class special case:** The portfolio template uses Pyomo directly and does not go through the AbstractModel layer. Other templates (LP, knapsack, TSP, etc.) use `ProblemTemplate` → `build_model()` → `AbstractModel` → `SolverInterface`. Portfolio is a special case by design for performance and richness of objectives (mean-variance, CVaR, Black-Litterman, etc.). New problem types should use the template + AbstractModel path; portfolio remains the exception.

### 2. Model Layer (`pyoptima/model/`)

**Purpose**: Represent optimization problems independently of solvers

**Key Classes**:
- `AbstractModel`: Container for variables, constraints, objectives
- `Variable`: Represents decision variables (continuous, integer, binary)
- `Expression`: Mathematical expressions (linear/quadratic)
- `Constraint`: Constraints (<=, >=, ==)
- `Objective`: Objective function (minimize/maximize)

**Key Design**:
- Solver-agnostic: Can be translated to any solver backend
- Immutable structure: Variables and constraints are added, not modified
- Type-safe: Uses enums for variable types, constraint senses, etc.

**Example**:
```python
model = AbstractModel("MyProblem")
model.add_continuous("x", lb=0, ub=10)
expr = Expression()
expr.add_term(3.0, "x")
model.maximize(expr)
```

### 3. Solver Layer (`pyoptima/solvers/`)

**Purpose**: Translate models to solver backends and execute

**Key Classes**:
- `SolverInterface`: Abstract interface for all solvers
- `PyomoSolver`: Pyomo-based implementation
- `SolverOptions`: Common solver options (time_limit, mip_gap, etc.)

**How it works**:
1. `AbstractModel` is translated to solver-specific format
2. Solver executes optimization
3. Results are extracted and converted back to `OptimizationResult`

**Solver Abstraction**:
```python
solver = get_solver("highs")
result = solver.solve(model, SolverOptions(time_limit=60))
```

### 4. Expression Language (`pyoptima/expression/`)

**Purpose**: Parse and evaluate algebraic expressions from configs

**Components**:
- `ExpressionParser`: Parses strings like `"sum(i in I: cost[i] * x[i])"`
- `ExpressionEvaluator`: Evaluates parsed expressions with context
- AST Nodes: `SumNode`, `BinaryOpNode`, `FunctionNode`, etc.

**Usage**:
```python
expr = parse_expression("sum(i in I: cost[i] * x[i])")
result = evaluate_expression(expr, context={...})
```

## Data Flow

### Template-Based Solving

```
User Data → Template.validate_data()
         → Template.build_model() → AbstractModel
         → Solver.solve() → OptimizationResult
         → Template.format_solution() → User-Friendly Result
```

### Programmatic Model Building

```
AbstractModel → add_variable(), add_constraint(), set_objective()
             → Solver.solve() → OptimizationResult
```

## Design Patterns

### 1. Template Pattern
- `ProblemTemplate` defines interface
- Each problem type implements its own template
- Consistent API across all problem types

### 2. Registry Pattern
- `TemplateRegistry` manages template lookup
- Decorator-based registration: `@TemplateRegistry.register("name")`
- Solver registry for solver discovery

### 3. Strategy Pattern
- `SolverInterface` defines solving strategy
- Different solvers implement different strategies
- Can swap solvers without changing model code

### 4. Builder Pattern
- `AbstractModel` builds up problem incrementally
- `Expression` builds up mathematical expressions
- Fluent interface for model construction

## Extension Points

### Adding a New Template

1. Create class inheriting from `ProblemTemplate`
2. Implement `info`, `validate_data`, `build_model`, `format_solution`
3. Register with `@TemplateRegistry.register("name")`
4. Import in `templates/__init__.py`

### Adding a New Solver

1. Create class inheriting from `SolverInterface`
2. Implement `solve()`, `is_available()`, `capabilities`
3. Register with `@register_solver("name")`
4. Handle model translation in `solve()`

### Adding Expression Language Features

1. Add AST node class in `expression/ast.py`
2. Update parser in `expression/parser.py`
3. Update evaluator in `expression/evaluator.py`
4. Add tests and documentation

## File Organization

```
pyoptima/
├── __init__.py              # Public API exports
├── cli.py                   # Command-line interface
├── config.py                # Configuration models
├── exceptions.py            # Custom exceptions
│
├── model/                   # Solver-agnostic model
│   ├── core.py             # AbstractModel, Variable, Expression
│   └── sets.py             # Index sets
│
├── solvers/                 # Solver abstraction
│   ├── base.py             # SolverInterface, SolverOptions
│   └── pyomo_solver.py     # Pyomo implementation
│
├── templates/               # Problem templates
│   ├── base.py             # ProblemTemplate base class
│   ├── classic.py          # Knapsack, Assignment, Transportation
│   ├── mathematical.py     # LP, QP, MIP
│   ├── routing.py          # TSP, VRP
│   ├── scheduling.py       # Job Shop
│   ├── network.py          # Max Flow, Min Cost Flow
│   ├── packing.py          # Bin Packing
│   ├── facility.py         # Facility Location
│   └── portfolio.py       # Portfolio Optimization
│
└── expression/              # Expression language
    ├── ast.py              # AST node classes
    ├── parser.py           # Expression parser
    └── evaluator.py       # Expression evaluator
```

## Key Design Decisions

### Why Solver-Agnostic Models?

- **Flexibility**: Can swap solvers without rewriting models
- **Testing**: Can test models independently of solvers
- **Extensibility**: Easy to add new solver backends
- **Portability**: Models can be serialized and solved elsewhere

### Why Templates?

- **Usability**: Simple, problem-specific interfaces
- **Consistency**: Same API across all problem types
- **Validation**: Built-in data validation
- **Documentation**: Self-documenting via `info` property

### Why Expression Language?

- **Declarative**: Specify constraints naturally
- **Readable**: `sum(i in I: cost[i] * x[i])` vs nested loops
- **Configurable**: Can be specified in YAML/JSON configs
- **Extensible**: Easy to add new functions/operators

## Performance Considerations

1. **Model Building**: Templates build models efficiently
2. **Solver Selection**: Default solvers chosen for problem types
3. **Caching**: Future: cache compiled models
4. **Parallel Solving**: Future: parallel solver execution

## Future Enhancements

- **OR-Tools Integration**: For TSP/VRP with specialized algorithms
- **CVXPY Backend**: For convex optimization
- **Multi-objective**: Pareto frontier generation
- **Warm Starts**: Reuse solutions for similar problems
- **Model Caching**: Cache compiled models for repeated solves
