# Expression Language Reference

PyOptima includes an expression language for declaratively specifying objectives and constraints. This allows you to write natural mathematical expressions instead of manually building coefficient matrices.

## Quick Start

```python
from pyoptima.expression import parse_expression, evaluate_expression

# Parse an expression
expr = parse_expression("sum(i in I: cost[i] * x[i])")

# Evaluate with context
result = evaluate_expression(expr, context={
    "I": [0, 1, 2],
    "cost": [10, 20, 30],
    "x": {0: 1.0, 1: 2.0, 2: 0.5}
})
```

## Basic Syntax

### Numbers

```python
42          # Integer
3.14        # Float
-10         # Negative
1e-5        # Scientific notation
```

### Variables

```python
x           # Simple variable
x[i]        # Indexed variable (1D)
x[i, j]     # Indexed variable (2D)
cost[i][j]  # Nested indexing
```

### Arithmetic Operations

```python
x + y       # Addition
x - y       # Subtraction
x * y       # Multiplication
x / y       # Division
x ^ 2       # Power (or x ** 2)
-x          # Negation
```

**Operator Precedence** (highest to lowest):
1. `^`, `**` (power)
2. `*`, `/` (multiplication, division)
3. `+`, `-` (addition, subtraction)

Use parentheses to override: `(x + y) * z`

### Comparisons

```python
x <= 10     # Less than or equal
x >= 0      # Greater than or equal
x == 5      # Equal
x < 10      # Less than
x > 0       # Greater than
x != 5      # Not equal
```

## Summations

Sum over index sets:

```python
# Basic summation
sum(i in I: cost[i] * x[i])

# Multiple indices
sum(i in I, j in J: flow[i, j])

# With condition
sum(i in I where i < 5: x[i])

# Nested summations
sum(i in I: sum(j in J: cost[i, j] * x[i, j]))
```

**Syntax**: `sum(index_specs : expression)`

**Index Specifications**:
- `i in I`: Index `i` ranges over set `I`
- `i in I, j in J`: Multiple indices
- `i in I where condition`: Filtered indices

## Products

```python
# Product over index set
prod(i in I: x[i])

# With condition
prod(i in I where x[i] > 0: x[i])
```

## Min/Max

```python
# Minimum value
min(x[i] for i in I)
min(i in I: x[i])

# Maximum value
max(x[i] for i in I)
max(i in I: x[i])

# With condition
min(i in I where x[i] > 0: x[i])
```

## Functions

### Mathematical Functions

```python
sqrt(x)         # Square root
abs(x)          # Absolute value
log(x)          # Natural logarithm
log10(x)        # Base-10 logarithm
exp(x)          # Exponential (e^x)
pow(x, 2)       # Power function
```

### Statistical Functions

```python
min(x[i] for i in I)   # Minimum
max(x[i] for i in I)   # Maximum
sum(i in I: x[i])      # Sum
```

### Norms

```python
norm1(x)               # L1 norm: |x|
norm2([x, y, z])       # L2 norm: sqrt(x^2 + y^2 + z^2)
norm_inf(x)            # Infinity norm: max(|x|)
```

## Piecewise Functions

```python
# Piecewise linear function
piecewise(x, breakpoints=[0, 10, 20], slopes=[1, 2, 3])

# Piecewise with values
piecewise(x, breakpoints=[0, 5, 10], values=[0, 5, 15])
```

## Parameter References

Access data from context:

```python
# Simple parameter
${budget}

# Nested parameter
data.prices[t]

# Indexed parameter
cost[i, j]

# With index variable
data.prices[i]
```

## Logical Operations

### Implication

```python
x[i] => y[j]    # If x[i] then y[j] (big-M conversion)
```

### Equivalence

```python
x[i] <=> y[j]   # x[i] if and only if y[j]
```

## Examples

### Example 1: Linear Objective

```python
# Maximize: 3x + 2y
"3 * x + 2 * y"

# Or with variables
"sum(i in I: c[i] * x[i])"
```

### Example 2: Quadratic Objective

```python
# Minimize: x^2 + y^2
"x^2 + y^2"

# Or with matrix
"sum(i in I, j in J: Q[i, j] * x[i] * x[j])"
```

### Example 3: Constraint

```python
# Sum constraint: sum(x[i]) <= 10
"sum(i in I: x[i]) <= 10"

# Resource constraint
"sum(i in I: resource[i] * x[i]) <= ${budget}"
```

### Example 4: Complex Constraint

```python
# Flow conservation
"sum(j in J: flow[i, j]) - sum(j in J: flow[j, i]) == supply[i]"

# Capacity constraint with condition
"sum(i in I where type[i] == 'A': x[i]) <= capacity_A"
```

### Example 5: Portfolio Optimization

```python
# Portfolio variance
"sum(i in I, j in I: Q[i, j] * w[i] * w[j])"

# Portfolio return
"sum(i in I: r[i] * w[i])"
```

## Using in Templates

### In Configuration Files

```yaml
objective:
  minimize: "sum(i in I: cost[i] * x[i])"

constraints:
  - name: "budget"
    expr: "sum(i in I: price[i] * x[i]) <= ${budget}"
  
  - name: "capacity"
    expr: "sum(i in I where type[i] == 'A': x[i]) <= 100"
```

### In Code

```python
from pyoptima.expression import parse_expression, evaluate_expression
from pyoptima.model.core import Expression

# Parse expression string
expr_node = parse_expression("sum(i in I: cost[i] * x[i])")

# Evaluate to get Pyomo expression or value
context = {
    "I": [0, 1, 2],
    "cost": [10, 20, 30],
    "x": {0: var0, 1: var1, 2: var2}  # Pyomo variables
}
pyomo_expr = evaluate_expression(expr_node, context)
```

## Context Variables

When evaluating expressions, provide context:

```python
context = {
    # Index sets
    "I": [0, 1, 2, 3],
    "J": ["A", "B", "C"],
    
    # Parameters (1D)
    "cost": [10, 20, 30, 40],
    "demand": {"A": 100, "B": 200, "C": 150},
    
    # Parameters (2D)
    "distance": {
        (0, 1): 10,
        (0, 2): 20,
        (1, 2): 15
    },
    
    # Variables (Pyomo variables or values)
    "x": {0: var0, 1: var1, 2: var2},
    
    # Nested data
    "data": {
        "prices": [1.5, 2.0, 1.8],
        "quantities": [100, 200, 150]
    },
    
    # Scalar parameters
    "budget": 1000,
    "capacity": 500
}
```

## Index Sets

Index sets can be:
- **Lists**: `[0, 1, 2, 3]`
- **Tuples**: `(0, 1, 2)`
- **Strings**: `["A", "B", "C"]`
- **Ranges**: `range(10)` (converted to list)

## Error Handling

### Parse Errors

```python
try:
    expr = parse_expression("x +")
except ParseError as e:
    print(f"Parse error: {e}")
    print(f"Position: {e.position}")
```

### Evaluation Errors

```python
try:
    result = evaluate_expression(expr, context)
except KeyError as e:
    print(f"Missing variable: {e}")
except ValueError as e:
    print(f"Evaluation error: {e}")
```

## Limitations

1. **No loops**: Use `sum()` instead of explicit loops
2. **No conditionals**: Use `where` clauses in summations
3. **No recursion**: Expressions must be acyclic
4. **Limited functions**: Only built-in functions supported

## Best Practices

1. **Use descriptive names**: `cost[i]` not `c[i]`
2. **Group related indices**: `sum(i in I, j in J: ...)` not nested sums
3. **Use parentheses**: `(x + y) * z` for clarity
4. **Document complex expressions**: Add comments in configs
5. **Validate context**: Ensure all variables/parameters are provided

## Advanced Usage

### Custom Functions

To add custom functions, extend the evaluator:

```python
from pyoptima.expression.evaluator import ExpressionEvaluator

class CustomEvaluator(ExpressionEvaluator):
    def evaluate_function(self, node, context):
        if node.name == "my_function":
            # Custom logic
            return ...
        return super().evaluate_function(node, context)
```

### Expression Transformation

Transform expressions before evaluation:

```python
def simplify_expression(expr_node):
    # Custom transformation logic
    ...
    return transformed_node
```

## Reference

### Supported Operators

| Operator | Description | Example |
|----------|-------------|---------|
| `+` | Addition | `x + y` |
| `-` | Subtraction | `x - y` |
| `*` | Multiplication | `x * y` |
| `/` | Division | `x / y` |
| `^`, `**` | Power | `x^2`, `x**2` |
| `<=` | Less than or equal | `x <= 10` |
| `>=` | Greater than or equal | `x >= 0` |
| `==` | Equal | `x == 5` |
| `<` | Less than | `x < 10` |
| `>` | Greater than | `x > 0` |
| `!=` | Not equal | `x != 5` |
| `=>` | Implication | `x => y` |
| `<=>` | Equivalence | `x <=> y` |

### Supported Functions

| Function | Description | Example |
|----------|-------------|---------|
| `sqrt(x)` | Square root | `sqrt(16)` → 4 |
| `abs(x)` | Absolute value | `abs(-5)` → 5 |
| `log(x)` | Natural log | `log(e)` → 1 |
| `log10(x)` | Base-10 log | `log10(100)` → 2 |
| `exp(x)` | Exponential | `exp(1)` → e |
| `pow(x, n)` | Power | `pow(2, 3)` → 8 |
| `min(...)` | Minimum | `min(x[i] for i in I)` |
| `max(...)` | Maximum | `max(x[i] for i in I)` |
| `norm1(x)` | L1 norm | `norm1([1, -2, 3])` → 6 |
| `norm2(x)` | L2 norm | `norm2([3, 4])` → 5 |
| `norm_inf(x)` | Infinity norm | `norm_inf([1, -5, 3])` → 5 |
| `piecewise(...)` | Piecewise linear | See above |

### Keywords

- `sum`: Summation
- `prod`, `product`: Product
- `min`: Minimum
- `max`: Maximum
- `in`: Index set membership
- `for`: Alternative syntax for min/max
- `where`: Filter condition

## See Also

- [Template Development Guide](TEMPLATE_DEVELOPMENT.md) - Using expressions in templates
- [Architecture Documentation](ARCHITECTURE.md) - Expression language integration
- Examples in `examples/` directory
