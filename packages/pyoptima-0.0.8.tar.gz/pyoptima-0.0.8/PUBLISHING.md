# Publishing PyOptima to PyPI

Complete guide for building and publishing PyOptima to PyPI.

## Prerequisites

1. **Python 3.13+** installed
2. **PyPI account** with API token
3. **Build tools** installed:
   ```bash
   pip install build twine
   ```

## Pre-Publishing Checklist

Before publishing, ensure:

- [ ] Version number updated in `pyproject.toml`
- [ ] `CHANGELOG.md` updated (if you maintain one)
- [ ] All tests pass: `make test` (or `pytest`)
- [ ] Code formatted: `make format` (or `black . && isort .`)
- [ ] Linting passes: `make lint`
- [ ] Type checking passes: `make type-check` (or `mypy pyoptima`)
- [ ] README.md is up to date
- [ ] LICENSE file is present

## Optional Dependencies

The package uses **optional extras** so that core installs stay minimal:

- **Core only:** `pip install pyoptima` (no API, UI, or rich CLI)
- **With API:** `pip install pyoptima[api]`
- **With UI:** `pip install pyoptima[ui]`
- **With CLI (rich):** `pip install pyoptima[cli]`
- **Combined:** `pip install pyoptima[api,ui,cli]` or `pip install pyoptima[dev]` for development

All optional dependencies are listed under `[project.optional-dependencies]` in `pyproject.toml`. The published wheel includes the `pyoptima.api` and `pyoptima.ui` subpackages; only the **dependencies** for those extras are optional at install time.

## Building the Package

### Option 1: Using Makefile (Recommended)

```bash
# Build Python package
make build
```

This will:
1. Build Python package (sdist and wheel)
2. Output files in `dist/`

### Option 2: Manual Build

```bash
# Build Python package
python -m build
```

## Verifying the Package

Before publishing, verify the package contents:

```bash
# Check what's included in the wheel
python -m zipfile -l dist/pyoptima-*.whl | grep pyoptima

# List all files
python -m zipfile -l dist/pyoptima-*.whl
```

You should see:
- `pyoptima/` - Core package
- All submodules (models, solvers, config_parser, etc.)

## Testing on TestPyPI

**Always test on TestPyPI first!**

### 1. Create TestPyPI Account

1. Go to https://test.pypi.org/
2. Create an account
3. Generate an API token

### 2. Configure Credentials

Create `~/.pypirc`:

```ini
[distutils]
index-servers =
    pypi
    testpypi

[testpypi]
repository = https://test.pypi.org/legacy/
username = __token__
password = pypi-xxxxxxxxxxxxx  # Your TestPyPI API token

[pypi]
repository = https://upload.pypi.org/legacy/
username = __token__
password = pypi-xxxxxxxxxxxxx  # Your PyPI API token
```

Or use environment variables:
```bash
export TWINE_USERNAME=__token__
export TWINE_PASSWORD=pypi-your-token-here
```

### 3. Upload to TestPyPI

```bash
# Using Makefile
make publish-test

# Or manually
twine upload --repository testpypi dist/*
```

### 4. Test Installation from TestPyPI

```bash
# Create a clean virtual environment
python -m venv test_env
source test_env/bin/activate  # On Windows: test_env\Scripts\activate

# Install from TestPyPI
pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ pyoptima[cbc]

# Test the installation
pyoptima --help
pyoptima optimize examples/portfolio_optimization.json
```

## Publishing to PyPI

### 1. Final Checks

```bash
# Run all checks
make check

# Verify package
python -m zipfile -l dist/pyoptima-*.whl | head -20
```

### 2. Publish

```bash
# Using Makefile (includes confirmation prompt)
make publish

# Or manually
twine upload dist/*
```

### 3. Verify Publication

1. Check PyPI: https://pypi.org/project/pyoptima/
2. Test installation:
   ```bash
   pip install pyoptima[cbc]
   pyoptima --help
   ```

## Version Management

### Updating Version

Edit `pyproject.toml`:

```toml
[project]
version = "0.0.2"  # Update version number
```

Follow [Semantic Versioning](https://semver.org/):
- **MAJOR**: Breaking changes
- **MINOR**: New features (backward compatible)
- **PATCH**: Bug fixes

### Version Tags

After publishing, tag the release:

```bash
git tag -a v0.0.2 -m "Release version 0.0.2"
git push origin v0.0.2
```

## CI/CD Integration

### GitHub Actions Example

```yaml
name: Build and Publish

on:
  release:
    types: [created]

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Set up Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.13'
      
      - name: Install Python dependencies
        run: |
          pip install build twine
      
      - name: Build package
        run: python -m build
      
      - name: Publish to PyPI
        env:
          TWINE_USERNAME: __token__
          TWINE_PASSWORD: ${{ secrets.PYPI_API_TOKEN }}
        run: twine upload dist/*
```

## Troubleshooting

### "Package already exists on PyPI"

**Cause**: Version already published.

**Solution**: Increment version in `pyproject.toml`.

### "Authentication failed"

**Cause**: Invalid API token or credentials.

**Solution**: 
1. Check `~/.pypirc` or environment variables
2. Regenerate API token on PyPI
3. Use `__token__` as username with token as password

### "Module not found" errors

**Cause**: Missing dependencies in package.

**Solution**: 
1. Check `pyproject.toml` dependencies
2. Ensure all required packages are listed
3. Test installation in clean environment

## Quick Reference

```bash
# Full build and publish workflow
make build         # Build Python package
make publish-test  # Test on TestPyPI
make publish       # Publish to PyPI

# Manual workflow
python -m build
twine upload --repository testpypi dist/*  # Test
twine upload dist/*  # Production
```

## Post-Publishing

After successful publication:

1. ✅ Verify on PyPI: https://pypi.org/project/pyoptima/
2. ✅ Test installation: `pip install pyoptima[cbc]`
3. ✅ Create GitHub release with changelog
4. ✅ Update documentation if needed
5. ✅ Announce release (if applicable)

