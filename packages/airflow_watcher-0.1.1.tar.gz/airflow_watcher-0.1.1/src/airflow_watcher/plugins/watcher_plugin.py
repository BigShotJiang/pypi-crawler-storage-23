"""Watcher Plugin Registration."""

from airflow_watcher.plugins import AirflowWatcherPlugin

__all__ = ["AirflowWatcherPlugin"]
