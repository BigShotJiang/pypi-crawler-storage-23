"""Airflow Watcher - DAG Failure and SLA Monitoring Plugin."""

__version__ = "0.1.0"
