#!/usr/bin/env python
"""Setup script for backwards compatibility with pip install."""

from setuptools import setup

if __name__ == "__main__":
    setup()
