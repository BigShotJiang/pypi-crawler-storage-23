## About

**Monitorat** is a federated dashboard and documentation system.

Its varphilosophy is to make system monitoring and documentation continuous, much like the way tables and figures are integrated in journal articles or [Wikipedia](https://wikipedia.org/).

### Quickstart
```bash
uv tool install monitorat
monitorat demo
```
Open your browser at 
[http://localhost:6100](http://localhost:6100).  Or checkout the
[advanced](http://monitorat.brege.org/advanced),
[layout](http://monitorat.brege.org/layout), and
[federation](http://monitorat.brege.org/federation) demos.

This dashboard is a read-only instance of [**monitorat**](https://github.com/brege/monitorat). It's similar to the one you could be using on your machine, just with synthetic data. monitorat aims to be a dashboard that's a knowledge base and not a knowledge sink.

### Demos

There are several demos.

| Demo | Command | Port | Online Demo |
|:--- |:--- | --- |:--- |
| **Simple** | `monitorat demo --mode simple` | :6100  | [monitorat.brege.org/](http://monitorat.brege.org) |
| **Advanced** | `monitorat demo --mode advanced` | :6200 | [monitorat.brege.org/advanced](http://monitorat.brege.org/advanced) |
| **Federation** | `monitorat demo --mode federation` | :6300 | [monitorat.brege.org/federation](http://monitorat.brege.org/federation) |
| **Editor** | `monitorat demo --mode editor` | :6400 | not available online |
| **Layout** | `monitorat demo --mode layout` | :6500 | [monitorat.brege.org/layout](http://monitorat.brege.org/layout) |

- The [simple](http://monitorat.brege.org/) demo goes over the widget basics.
- The [advanced](http://monitorat.brege.org/advanced) demo breaks down how different features of each widget can be toggled, configured, and adjusted for different display modes.
- A more compact, columnated layout is exemplified in the [layout](http://monitorat.brege.org/layout) demo.
- [Federation](http://monitorat.brege.org/federation) is a multi-node demo that demonstrates how widgets can be shared and used from a central command. *Simple is a prerequisite for Advanced. Advanced is a prerequisite for Federation.* This demo launches 3 servers on ports `6300` (head), `6301` & `6302` (nodes).

### Widgets

| Widget                          | Features |
|:------------------------------- |:-------- |
| [Wiki](#overview)               | GitHub-flavored Markdown, Live Editor, Math, Tables, Shortcodes/Includes |
| [Metrics](#metrics-widget)      | Performance Snapshots, Logging, Charts, Tables, Notifications |
| [Network](#network-widget)      | Built-in or ddclient Logs, Outages, IP Changes, Stats, Logging, Notifications |
| [Services](#services-widget)    | Docker and Systemd Services, Timers, Local and External URLs, Web Editor |
| [Speedtest](#speedtest-widget)  | Speedtest Tracking, Tables, Charts |
| [Reminders](#reminders-widget)  | Web Editor, Calendar, Apprise Notifications |

For this (simple) demo, each widget is chased by a corresponding ["Wiki" widget](/#wiki) that provides the documentation for that widget.

On headless machines (Raspberry Pi, a NAS, NUC, or Beelink), monitorat becomes both a central dashboard and a system's bible.

### Purpose

- help me navigate to my services and check their statuses
- centralize my documentation and notes so I remember how I deployed them
- periodically check on system health, performance, and network quality

Monitorat's text editor for Markdown files is in beta. If you make edits with an editor like [Neovim](https://neovim.io/) or [Obsidian](https://obsidian.md/), simply save and refresh.

### Math Rendering

[KaTeX](https://katex.org/) math rendering is supported. Here's an example of inline math:
[Euler's formula](https://en.wikipedia.org/wiki/Euler%27s_formula) is $e^{i\varphi} = \cos\varphi + i\sin\varphi$.

Richard Feynman called [Euler's identity](https://en.wikipedia.org/wiki/Euler%27s_identity) (when $\varphi = \pi$) the
**jewel of mathematics**:

$$
e^{i\pi} + 1 = 0
$$

The *quadratic formula* can be obtained from **completing the square**:

$$
x = \frac{-b \pm \sqrt{b^2 - 4ac}}{2a}
$$

See the full project [README](https://github.com/brege/monitorat/#readme) for more information.

### Admonitions

> [!NOTE]
> Highlights information with colors and icons. See [antfu/markdown-it-github-alerts](https://github.com/antfu/markdown-it-github-alerts) on GitHub for examples.

> [!TIP]
> Use `[!NOTE]`, `[!TIP]`, `[!IMPORTANT]`, `[!WARNING]`, AND `[!CAUTION]` for different types of admonitions.
> ```markdown
> [!TIP]
> This is a tip.
> ```


### Config Snippets

Wikis can include YAML files with <code>{{ include&#58;code path="config.yaml" lang="yaml" }}</code> snippets.

<details>
<summary><b>Show config</b></summary>

> **Note:** You will see in each widget's note block the config snippet for that widget. This is the *head* config that loads each of the snippets through `includes`/snippet files.

{{ include:code path="config.yaml" lang="yaml" }}
</details>
