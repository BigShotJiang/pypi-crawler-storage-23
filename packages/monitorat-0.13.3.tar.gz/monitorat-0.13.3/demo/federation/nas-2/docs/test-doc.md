# NAS-2 Test Document

This is a test wiki document for the NAS-2 federation test node.

## Status

- Federation testing: Active
- Node ID: nas-2
