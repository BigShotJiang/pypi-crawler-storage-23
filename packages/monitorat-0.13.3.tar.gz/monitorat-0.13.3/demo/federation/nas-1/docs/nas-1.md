# Lorem Ipsum Overview

This is a document served from `nas-1`, accessed by the head node's backend via federation through `nas-1`'s API.

For more information about certain topics, see these Wikipedia articles:
- [LaTeX](https://en.wikipedia.org/wiki/LaTeX)
- [JavaScript](https://en.wikipedia.org/wiki/JavaScript)
- [Python](https://en.wikipedia.org/wiki/Python_(programming_language))

## Example Code Block

Here is a simple dummy code snippet to illustrate formatting:

<details>
<summary>Show more</summary>

```python
def lorem_ipsum():
    text = "Lorem ipsum dolor sit amet"
    for word in text.split():
        print(word)

if __name__ == "__main__":
    lorem_ipsum()
```

Suspendisse potenti. Sed blandit convallis consequat. Etiam facilisis massa in dolor tincidunt, non finibus metus elementum. Ut viverra justo vitae lectus scelerisque, ac tincidunt neque vehicula.

</details>
