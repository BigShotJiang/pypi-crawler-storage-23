"""
Intentionally empty so Hatch can treat `monitorat` as a package when building wheels.
"""
