/* global TimeSeriesHandler, ChartTableWidgetMethods */
class SpeedtestWidget {
  constructor(widgetConfig = {}) {
    this.container = null;
    this.widgetConfig = widgetConfig;
    this.attributeName = 'data-speedtest';
    this.defaults = {
      name: 'Speedtest',
      default: 'chart',
      periods: [],
      table: { min: 5, max: 200 },
      chart: {
        height: '400px',
        days: 30,
        default_period: 'all',
        default_metric: 'all',
      },
    };
    this.config = this.buildConfig();
    this.entries = [];
    this.metricFields = [];
    this.chartManager = null;
    this.tableManager = null;
    this.currentView = null;
    this.selectedPeriod = 'all';
    this.selectedMetric = 'all';
    this.selectedNode = 'all';
    this.schema = null;
    this.chartEntries = [];
    this.features = {
      controls: null,
      chart: null,
      table: null,
    };
  }

  initializeFeatureHeaders() {
    const features = this.config.features || {};
    for (const [featureId, featureConfig] of Object.entries(features)) {
      const headerEl = this.container.querySelector(
        `[data-speedtest-section-header="${featureId}"]`,
      );
      if (headerEl && featureConfig.header) {
        headerEl.textContent = featureConfig.header;
      }
    }
  }

  getApiBase() {
    return this.config._apiPrefix
      ? `api/${this.config._apiPrefix}`
      : 'api/speedtest';
  }

  getCsvUrl() {
    return `${this.getApiBase()}/csv?${Date.now()}`;
  }

  getCsvUrlForSource(source) {
    const widgetName = this.getFederatedWidgetName();
    return `api/${widgetName}-${source}/csv?${Date.now()}`;
  }

  getCsvFilename() {
    return 'speedtest.csv';
  }

  getCsvFilenameForSource(source) {
    const widgetName = this.getFederatedWidgetName();
    return `${widgetName}-${source}.csv`;
  }

  async loadSchema() {
    if (this.schema) return;
    const response = await fetch(`${this.getApiBase()}/schema`);
    this.schema = await response.json();
    this.applyMetadataConfig();
    this.metricFields = this.resolveMetricFields();
  }

  buildConfig(overrides = {}) {
    return TimeSeriesHandler.buildConfig(
      this.defaults,
      this.widgetConfig,
      overrides,
    );
  }

  resolveMetricFields() {
    const enabled = this.config?.enabled;
    if (Array.isArray(enabled) && enabled.length > 0) {
      return (this.schema.metrics || []).filter((metric) =>
        enabled.includes(metric.field),
      );
    }
    return this.schema.metrics || [];
  }

  applyMetadataConfig() {
    const metadataConfig = this.config?.metadata || {};
    if (!this.schema.metadata) {
      this.schema.metadata = {};
    }
    if (metadataConfig.field) {
      this.schema.metadata.field = metadataConfig.field;
    }
    if (metadataConfig.label) {
      this.schema.metadata.label = metadataConfig.label;
    }
    const enabledSet = new Set(this.config?.enabled || []);
    const metadataFields = Array.isArray(this.schema.metadata.fields)
      ? this.schema.metadata.fields
      : [];
    const filteredMetadata = metadataFields.filter((field) => {
      if (typeof field === 'string') return enabledSet.has(field);
      if (field && typeof field.field === 'string')
        return enabledSet.has(field.field);
      return false;
    });
    this.schema.metadata.fields = filteredMetadata;
    if (
      filteredMetadata.length === 0 ||
      (filteredMetadata.length === 1 &&
        !enabledSet.has(this.schema.metadata.field))
    ) {
      this.schema.metadata.field = null;
    }
  }

  async init(container, config = {}) {
    this.container = container;
    this.config = this.buildConfig(config);
    this.selectedPeriod =
      this.config.chart.default_period || this.defaults.chart.default_period;
    await this.loadSchema();
    this.metricFields = this.resolveMetricFields();
    const metricFields = this.metricFields.map((metric) => metric.field);
    const preferredMetric =
      this.config.chart.default_metric || this.defaults.chart.default_metric;
    this.selectedMetric =
      preferredMetric === 'all'
        ? 'all'
        : metricFields.includes(preferredMetric)
          ? preferredMetric
          : metricFields[0] || 'all';

    const response = await fetch('widgets/speedtest/index.html');
    const html = await response.text();
    await window.monitorShared.renderWidgetTemplate(container, html);

    this.applyVisibilityConfig();
    this.initializeFeatureHeaders();
    await this.loadFeatureScripts();
    this.initializeFeatures();

    const showControls = this.config.show?.controls !== false;
    const showHistory = this.config.show?.history !== false;

    if (showControls || showHistory) {
      this.features.controls.setupEventListeners();
    }

    if (showHistory) {
      this.features.table.rebuildHeaders();
      this.setupNodeSelect();
      this.setupDownloadControl();
      this.setupLegendToggle();
      this.initManagers();
      this.setView(this.config.default);
      await this.features.table.loadHistory();
    }
  }

  applyVisibilityConfig() {
    const FeatureVisibility = window.monitorShared.FeatureVisibility;

    FeatureVisibility.apply(this.container, this.config.show, {
      controls: '.speedtest-controls',
      history: '.speedtest-history',
    });
  }

  initManagers() {
    this.features.chart.initializeManager();
    this.features.table.initializeManager();
  }

  updateChart() {
    this.features.chart.update();
  }

  updateChartView() {
    this.features.chart.updateView();
  }

  async loadFeatureScripts() {
    const featureScripts = [
      {
        globalName: 'SpeedtestControls',
        source: 'widgets/speedtest/features/controls.js',
      },
      {
        globalName: 'SpeedtestChart',
        source: 'widgets/speedtest/features/history/chart.js',
      },
      {
        globalName: 'SpeedtestTable',
        source: 'widgets/speedtest/features/history/table.js',
      },
    ];

    await window.monitorShared.loadFeatureScripts(featureScripts);
  }

  initializeFeatures() {
    const ControlsFeature = window.SpeedtestControls;
    const ChartFeature = window.SpeedtestChart;
    const TableFeature = window.SpeedtestTable;

    if (!ControlsFeature || !ChartFeature || !TableFeature) {
      throw new Error('Speedtest feature scripts not loaded');
    }

    this.features.controls = new ControlsFeature(this);
    this.features.chart = new ChartFeature(this);
    this.features.table = new TableFeature(this);
  }

  updateViewToggle(hasEntries) {
    return ChartTableWidgetMethods.updateViewToggle.call(this, hasEntries);
  }

  applyNodeFilter() {
    const filtered =
      this.selectedNode === 'all'
        ? this.entries
        : this.entries.filter((entry) => entry._source === this.selectedNode);

    const limit = this.config.table.max;
    this.tableManager.setEntries(filtered.slice(0, limit));
    this.features.chart.update();
  }
}

Object.assign(
  SpeedtestWidget.prototype,
  window.monitorShared.ChartTableWidgetMethods || ChartTableWidgetMethods,
);

SpeedtestWidget.prototype.getViewControls = () => [];

SpeedtestWidget.prototype.openTableForSource = function (source) {
  if (!source) {
    return;
  }
  this.selectedNode = source;
  const nodeSelect = this.getElement('node-select');
  if (nodeSelect) {
    nodeSelect.value = source;
  }
  this.applyNodeFilter();
  this.setView('table');
};

window.widgets = window.widgets || {};
window.widgets.speedtest = SpeedtestWidget;
