"""solidlsp 호환을 위한 최소 serena 네임스페이스다."""
