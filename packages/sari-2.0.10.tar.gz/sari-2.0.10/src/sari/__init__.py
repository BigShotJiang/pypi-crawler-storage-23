"""sari-v2 패키지 진입점이다."""

__all__ = ["__version__"]
__version__ = "2.0.10"
