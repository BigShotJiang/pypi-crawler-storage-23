"""python -m sari 실행 진입점이다."""

from sari.cli.main import main


if __name__ == "__main__":
    main()
