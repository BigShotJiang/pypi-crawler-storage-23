"""
Configuration loader for ``settings/test_config.yaml``.

Handles environment-variable expansion (``${VAR}`` syntax) and provides
typed accessors for connection settings.

The YAML layout follows the ``snowflake-data-validation`` framework's
config structure so that a single file can drive both the framework and
the test runner::

    source_platform: sqlserver
    target_platform: snowflake
    output_directory_path: ./reports

    source_connection:
      mode: credentials
      host: ...
    target_connection:
      mode: name
      name: default

    validation_configuration:
      schema_validation: true
      metrics_validation: true
      row_validation: false
      max_failed_rows_number: 100

    # test-runner extension
    selectors:
      schemas: [DBO]

Connection details are kept as raw dicts so that each dialect's
:class:`DatabaseExecutorFactory` can parse them into its own typed config
(e.g. ``SqlServerCredentialsConnection``, ``SnowflakeNamedConnection``).
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

import yaml

from .connection_reader import resolve_named_connection
from .database_dialect import DatabaseDialect, parse_dialect


# ---------------------------------------------------------------------------
# Public data classes
# ---------------------------------------------------------------------------

@dataclass
class SelectorsConfig:
    """Optional selectors to filter which test files are processed."""

    schemas: list[str] = field(default_factory=list)
    exclude: list[str] = field(default_factory=list)


@dataclass
class ValidationConfiguration:
    """Controls which validation levels are executed and their limits.

    Mirrors the ``validation_configuration`` section from the
    ``snowflake-data-validation`` config format.
    """

    schema_validation: bool = True
    """Run schema-level validation (column names and type mapping)."""

    metrics_validation: bool = True
    """Run metrics-level validation (per-column aggregate metrics)."""

    row_validation: bool = True
    """Run row-level validation (row-by-row MD5 comparison)."""

    max_failed_rows_number: int = 100
    """Maximum number of failed rows to report before stopping."""


@dataclass
class TestRunnerConfig:
    """Top-level configuration for capture / validate runs.

    Connection details are raw dicts -- each dialect's factory parses them.
    """

    source_dialect: DatabaseDialect = DatabaseDialect.SQL_SERVER
    """Source database dialect (read from ``source_platform``)."""

    target_platform: str = "snowflake"
    """Target platform identifier (read from ``target_platform``)."""

    source_connection_raw: dict[str, Any] = field(default_factory=dict)
    """Raw ``source_connection`` dict from YAML."""

    target_connection_raw: dict[str, Any] = field(default_factory=dict)
    """Raw ``target_connection`` dict from YAML."""

    output_directory_path: Optional[str] = None
    """Directory for validation reports (``output_directory_path``)."""

    validation_configuration: Optional[ValidationConfiguration] = None
    """Validation level toggles and limits."""

    selectors: Optional[SelectorsConfig] = None
    """Test-runner extension: filter which test files are processed."""

    validation_database: str = ""
    """Snowflake database for validation objects.

    Defaults to the project folder name (uppercased).  Set explicitly
    via ``validation_database`` in the YAML or derived from ``project_root``.
    """

    raw: dict[str, Any] = field(default_factory=dict)
    """The full raw parsed YAML dict."""


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_ENV_VAR_PATTERN = re.compile(r"\$\{(\w+)\}")


def _expand_env_vars(value: Any) -> Any:
    """Recursively expand ``${VAR}`` references in strings, dicts and lists."""
    if isinstance(value, str):
        return _ENV_VAR_PATTERN.sub(
            lambda m: os.environ.get(m.group(1), m.group(0)), value
        )
    if isinstance(value, dict):
        return {k: _expand_env_vars(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_expand_env_vars(v) for v in value]
    return value


def _build_selectors(raw: dict[str, Any] | None) -> Optional[SelectorsConfig]:
    if not raw:
        return None
    return SelectorsConfig(
        schemas=[s.upper() for s in raw.get("schemas", [])],
        exclude=raw.get("exclude", []),
    )


def _build_validation_configuration(
    raw: dict[str, Any] | None,
) -> Optional[ValidationConfiguration]:
    if not raw:
        return None
    return ValidationConfiguration(
        schema_validation=bool(raw.get("schema_validation", True)),
        metrics_validation=bool(raw.get("metrics_validation", True)),
        row_validation=bool(raw.get("row_validation", True)),
        max_failed_rows_number=int(raw.get("max_failed_rows_number", 100)),
    )


_DIALECT_TOML_FILES: dict[DatabaseDialect, str] = {
    DatabaseDialect.SQL_SERVER: "sqlserver.toml",
    DatabaseDialect.ORACLE: "oracle.toml",
    DatabaseDialect.TERADATA: "teradata.toml",
    DatabaseDialect.POSTGRESQL: "postgresql.toml",
}


def _resolve_named_connection(
    raw: dict[str, Any],
    source_dialect: DatabaseDialect,
    project_root: str | Path,
) -> dict[str, Any]:
    """If *raw* uses ``mode: name``, resolve from ``.snowflake/snowct/<dialect>.toml``.

    TOML values are used as defaults; any explicit keys in *raw* (besides
    ``mode`` and ``name``) take precedence so users can override individual
    fields in the YAML.
    """
    if not raw or raw.get("mode") != "name":
        return raw
    name = raw.get("name")
    if not name:
        return raw
    dialect_file = _DIALECT_TOML_FILES.get(source_dialect, f"{source_dialect.value}.toml")
    resolved = resolve_named_connection(name, dialect_file, project_root)
    resolved.update({k: v for k, v in raw.items() if k not in ("mode", "name")})
    return resolved


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def load_config(
    project_root: str | Path,
    *,
    source_connection: str | None = None,
) -> TestRunnerConfig:
    """Load and validate ``settings/test_config.yaml`` from *project_root*.

    Args:
        project_root: Path to the SCAI project root directory.
        source_connection: Optional named connection to use as the source.
            When provided this overrides the ``source_connection`` section
            in the YAML with a ``mode: name`` lookup against
            ``.snowflake/connections.toml``.

    Neither ``source_connection`` nor ``target_connection`` is required at
    load time -- each command validates the fields it needs.

    Raises ``FileNotFoundError`` if the config file does not exist.
    """
    config_path = Path(project_root) / "settings" / "test_config.yaml"
    if not config_path.exists():
        raise FileNotFoundError(
            f"Config file not found: {config_path}\n"
            "Create settings/test_config.yaml with connection settings."
        )

    with open(config_path, "r", encoding="utf-8") as fh:
        raw: dict[str, Any] = yaml.safe_load(fh) or {}

    # -- platforms -----------------------------------------------------------
    source_platform_str = raw.get("source_platform", "sqlserver")
    source_dialect = parse_dialect(source_platform_str)
    target_platform = raw.get("target_platform", "snowflake")

    # -- source connection ---------------------------------------------------
    source_raw = dict(raw.get("source_connection") or {})
    if source_connection:
        source_raw = {"mode": "name", "name": source_connection}
    source_raw = _expand_env_vars(source_raw) if source_raw else {}
    source_raw = _resolve_named_connection(source_raw, source_dialect, project_root)

    # -- target connection ---------------------------------------------------
    target_raw = dict(raw.get("target_connection") or {})
    target_raw = _expand_env_vars(target_raw) if target_raw else {}

    # -- validation database (defaults to project folder name) ----------------
    validation_database = raw.get("validation_database", "")
    if not validation_database:
        validation_database = Path(project_root).resolve().name.upper()

    # -- build config --------------------------------------------------------
    return TestRunnerConfig(
        source_dialect=source_dialect,
        target_platform=target_platform,
        source_connection_raw=source_raw,
        target_connection_raw=target_raw,
        output_directory_path=raw.get("output_directory_path"),
        validation_configuration=_build_validation_configuration(
            raw.get("validation_configuration"),
        ),
        selectors=_build_selectors(raw.get("selectors")),
        validation_database=validation_database,
        raw=raw,
    )
