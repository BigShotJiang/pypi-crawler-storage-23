"""Data models for the test runner pipeline.

All models are re-exported here so that existing imports like
``from test_runner.common.models import BaselineData`` continue to work.
"""

from .validation_steps import ValidationSteps
from .test_file import TestFile
from .capture_result import TestCaseResult
from .baseline_data import BaselineData
from .stats import TestCaseStats, ValidationStats

CaptureResult = TestCaseResult
CaptureStats = TestCaseStats
ValidateStats = ValidationStats

__all__ = [
    "ValidationSteps",
    "TestFile",
    "TestCaseResult",
    "CaptureResult",
    "BaselineData",
    "TestCaseStats",
    "CaptureStats",
    "ValidationStats",
    "ValidateStats",
]
