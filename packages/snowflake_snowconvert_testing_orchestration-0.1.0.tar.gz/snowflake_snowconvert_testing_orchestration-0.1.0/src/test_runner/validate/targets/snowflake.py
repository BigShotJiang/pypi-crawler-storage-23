"""
Snowflake executor factory.

Wraps the ``ConnectorSnowflake`` from ``snowflake-data-validation`` to provide
connection management, SQL literal formatting, and stored-procedure execution.

Column types are captured from ``cursor.description`` using the Snowflake
connector's built-in ``FIELD_ID_TO_NAME`` mapping.
"""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Any, Optional, Sequence

from snowflake.connector.constants import FIELD_ID_TO_NAME
from snowflake.snowflake_data_validation.connector.connector_base import ConnectorBase
from snowflake.snowflake_data_validation.snowflake.connector.connector_snowflake import (
    ConnectorSnowflake,
)
from snowflake.snowflake_data_validation.snowflake.connector.connector_factory_snowflake import (
    SnowflakeConnectorFactory,
)
from snowflake.snowflake_data_validation.snowflake.model.snowflake_named_connection import (
    SnowflakeNamedConnection,
)

from test_runner.common.database_dialect import DatabaseDialect
from test_runner.common.database_executor import (
    DatabaseExecutor,
    DatabaseExecutorFactory,
    LiteralFormatter,
)
from test_runner.common.models import TestCaseResult


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _describe_to_column_types(
    cursor_description: Sequence[Any],
) -> dict[str, str]:
    """Map Snowflake ``cursor.description`` to ``{COLUMN_NAME: type_name}``.

    Uses the connector's built-in ``FIELD_ID_TO_NAME`` mapping which
    translates integer type codes to Snowflake type names.
    """
    return {
        desc[0].upper(): FIELD_ID_TO_NAME.get(desc[1], "VARCHAR")
        for desc in cursor_description
    }


# ---------------------------------------------------------------------------
# Literal formatter (SRP: separated from factory)
# ---------------------------------------------------------------------------

class SnowflakeLiteralFormatter(LiteralFormatter):
    """Snowflake SQL literal formatting: TRUE/FALSE for bools."""

    def format_literal(self, value: Any) -> str:
        if value is None:
            return "NULL"
        if isinstance(value, bool):
            return "TRUE" if value else "FALSE"
        if isinstance(value, (int, float, Decimal)):
            return str(value)
        if isinstance(value, datetime):
            return f"'{value.isoformat()}'"
        escaped = str(value).replace("'", "''")
        return f"'{escaped}'"


# ---------------------------------------------------------------------------
# Executor
# ---------------------------------------------------------------------------

class SnowflakeExecutor(DatabaseExecutor):
    """Executes SQL on Snowflake via the data-validation ``ConnectorSnowflake``.

    Captures column types from ``cursor.description`` using the Snowflake
    connector's integer type codes mapped to type names.
    """

    def __init__(self, connector: ConnectorBase) -> None:
        self._connector = connector

    @property
    def connector(self) -> ConnectorBase:
        return self._connector

    def close(self) -> None:
        self._connector.close()

    def execute(self, sql: str) -> TestCaseResult:
        result = TestCaseResult()
        try:
            import snowflake.connector as sf_connector

            cursor = self._connector.connection.cursor(sf_connector.DictCursor)
            try:
                cursor.execute(sql)
                description = cursor.description
                rows = cursor.fetchall()
            finally:
                cursor.close()

            result.result_sets = [rows]
            result.row_counts = [len(rows)]
            if description:
                result.column_types = [_describe_to_column_types(description)]
        except Exception as exc:
            result.success = False
            result.error = str(exc)
        return result

    def execute_statement(self, sql: str) -> None:
        self._connector.execute_statement(sql)


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------

class SnowflakeExecutorFactory(DatabaseExecutorFactory):
    """Factory for Snowflake executors backed by data-validation connectors."""

    @property
    def dialect(self) -> DatabaseDialect:
        return DatabaseDialect.SNOWFLAKE

    def build_config(self, raw: dict[str, Any]) -> SnowflakeNamedConnection:
        mode = raw.get("mode", "name")
        return SnowflakeNamedConnection(
            mode=mode,
            name=raw.get("name", ""),
        )

    def create_literal_formatter(self) -> SnowflakeLiteralFormatter:
        return SnowflakeLiteralFormatter()

    def create_executor(self, config: Any) -> SnowflakeExecutor:
        connector = SnowflakeConnectorFactory.create_connector(config)
        return SnowflakeExecutor(connector)
