"""
Transient table management for Snowflake-native validation.

Creates and cleans up transient tables for both baseline and actual
result sets so the data-validation framework's ``MetadataExtractorSnowflake``
can query them via SQL.

Baseline tables are built directly from the staged JSON files using
``LATERAL FLATTEN``, avoiding any intermediate table.
"""

from __future__ import annotations

import json
import logging

from snowflake.snowflake_data_validation.connector.connector_base import ConnectorBase

LOGGER = logging.getLogger(__name__)

_SCHEMA = "VALIDATION"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_table_name(database: str, procedure: str, params_hash: str, side: str) -> str:
    """Generate a unique transient table name."""
    safe = procedure.replace(".", "_").replace(" ", "_")[:50].upper()
    return f"{database}.{_SCHEMA}.TEMP_{side}_{safe}_{params_hash}".upper()


def _safe_cast_type(typ: str) -> str:
    """Widen bare ``NUMBER`` to ``NUMBER(38,18)`` for VARIANT casts.

    Snowflake defaults bare ``NUMBER`` to ``NUMBER(38,0)`` which
    truncates decimals when casting from VARIANT/JSON.
    """
    if typ.upper() == "NUMBER":
        return "NUMBER(38,18)"
    return typ


# ---------------------------------------------------------------------------
# Materialize baseline directly from stage JSON
# ---------------------------------------------------------------------------

def materialize_baseline_transient_table(
    connector: ConnectorBase,
    database: str,
    procedure: str,
    params_hash: str,
) -> str:
    """Create a transient table from baseline JSON files on the stage.

    Reads the staged baseline as raw text so ``json.loads`` preserves
    the original column order, then uses ``LATERAL FLATTEN`` with
    ``GET_IGNORE_CASE`` to materialize the transient table.

    Args:
        connector: Snowflake connector.
        database: Database name for the validation schema.
        procedure: Procedure name to filter by.
        params_hash: Parameter hash to filter by.

    Returns:
        The fully qualified transient table name.
    """
    table_name = _make_table_name(database, procedure, params_hash, "SOURCE")
    fq = f"{database}.{_SCHEMA}"
    stage = f"@{fq}.BASELINES"
    fmt = f"{fq}.JSON_FORMAT"
    file_filter = f"s.$1:params_hash::VARCHAR = '{params_hash}'"

    raw_fmt = f"{fq}.RAW_TEXT_FORMAT"
    cursor = connector.connection.cursor()
    try:
        # Read the raw JSON text to preserve original key order
        # (Snowflake VARIANT alphabetizes object keys)
        cursor.execute(
            f"CREATE FILE FORMAT IF NOT EXISTS {raw_fmt} "
            f"TYPE = CSV FIELD_DELIMITER = NONE RECORD_DELIMITER = NONE"
        )
        cursor.execute(f"""\
SELECT $1 AS raw_text
FROM {stage} (FILE_FORMAT => '{raw_fmt}')
WHERE PARSE_JSON($1):params_hash::VARCHAR = '{params_hash}'
LIMIT 1""")
        row = cursor.fetchone()
        if row is None:
            LOGGER.warning("No baseline on stage for %s (hash=%s)", procedure, params_hash)
            cursor.execute(
                f"CREATE OR REPLACE TRANSIENT TABLE {table_name} (DUMMY VARCHAR)"
            )
            return table_name

        baseline: dict = json.loads(row[0])
        col_types: dict[str, str] = baseline.get("column_types", [{}])[0]

        select_cols = ", ".join(
            f"GET_IGNORE_CASE(f.value, '{col}')"
            f"::{_safe_cast_type(typ)} "
            f'AS "{col}"'
            for col, typ in col_types.items()
        )

        cursor.execute(f"""\
CREATE OR REPLACE TRANSIENT TABLE {table_name} AS
SELECT {select_cols}
FROM {stage} (FILE_FORMAT => '{fmt}') s,
LATERAL FLATTEN(input => s.$1:result_sets[0]) f
WHERE {file_filter}""")

    finally:
        cursor.close()

    return table_name


# ---------------------------------------------------------------------------
# Materialize actual results via CALL + RESULT_SCAN
# ---------------------------------------------------------------------------

def materialize_actual_transient_table(
    connector: ConnectorBase,
    database: str,
    sql: str,
    procedure: str,
    params_hash: str,
) -> str:
    """Execute a procedure and capture its results into a transient table.

    Uses ``cursor.sfqid`` to capture the specific query ID, then
    ``RESULT_SCAN`` to materialize the results via CTAS.

    Args:
        connector: Snowflake connector.
        database: Database name for the validation schema.
        sql: The SQL to execute (CALL statement).
        procedure: Procedure name (for table naming).
        params_hash: Parameter hash (for table naming).

    Returns:
        The fully qualified transient table name.
    """
    table_name = _make_table_name(database, procedure, params_hash, "TARGET")

    cursor = connector.connection.cursor()
    try:
        cursor.execute(sql)
        query_id = cursor.sfqid
        cursor.execute(
            f"CREATE OR REPLACE TRANSIENT TABLE {table_name} "
            f"AS SELECT * FROM TABLE(RESULT_SCAN('{query_id}'))"
        )
    finally:
        cursor.close()

    return table_name


# ---------------------------------------------------------------------------
# Cleanup
# ---------------------------------------------------------------------------

def drop_transient_tables(connector: ConnectorBase, *table_names: str) -> None:
    """Drop transient tables, ignoring errors."""
    for name in table_names:
        try:
            connector.execute_statement(f"DROP TABLE IF EXISTS {name}")
        except Exception:
            pass
