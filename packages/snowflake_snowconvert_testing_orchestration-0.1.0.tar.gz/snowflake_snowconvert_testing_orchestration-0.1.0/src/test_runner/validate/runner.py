"""
Validate runner -- orchestrates the full validation pipeline.

1. Resolve Snowflake executor from the injected registry
2. Discover test YAML files and filter to those with ``target`` steps
3. Load baselines from ``VALIDATION.BASELINE_ROWS`` table (stage-first)
4. For each YAML test case: materialize baseline + actual into temp tables,
   compare via the data-validation framework's Snowflake-native validators
5. Write results to ``VALIDATION.RESULTS``
"""

from __future__ import annotations

import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Optional

from test_runner.common.baseline import compute_params_hash
from test_runner.common.config import TestRunnerConfig
from test_runner.common.database_dialect import DatabaseDialect
from test_runner.common.database_executor import DatabaseExecutor, DatabaseExecutorFactory
from test_runner.common.discovery import discover_test_files
from test_runner.common.models import BaselineData, TestFile, ValidationStats
from test_runner.common.template import build_parameters, render_full_sql

from .baseline_loader import create_baseline_loader
from .comparator import compare_results, errors_match
from .deploy import deploy_snowpark_validator
from .results_writer import write_results_batch


# ---------------------------------------------------------------------------
# Console output
# ---------------------------------------------------------------------------

_SEP = "\u2550" * 60


def _print_header(source: str) -> None:
    print(f"\n{_SEP}")
    print("  VALIDATING SNOWFLAKE AGAINST BASELINES")
    print(f"  Baseline source: {source}")
    print(f"{_SEP}\n")


def _print_case(procedure: str, status: str, match_type: str, error: str) -> None:
    icon = "\u2705" if status == "PASS" else "\u274c"
    detail = match_type if status != "ERROR" else error[:80]
    print(f"{icon} {status} {procedure} -- {detail}")


def _print_summary(stats: ValidationStats) -> None:
    print(f"\n{_SEP}")
    print(f"  SUMMARY: {stats.total} test cases")
    print(f"  Passed: {stats.passed}  Failed: {stats.failed}  Errors: {stats.errors}")
    if stats.no_baseline:
        print(f"  No baseline: {stats.no_baseline}")
    print(f"{_SEP}\n")


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def run_validate(
    config: TestRunnerConfig,
    factory_registry: dict[DatabaseDialect, DatabaseExecutorFactory],
    project_root: str | Path,
    snowflake_connection: Optional[str] = None,
    baseline_dir: Optional[str | Path] = None,
    baseline_stage: Optional[str] = None,
    pattern: str = ".*",
    create_schema: bool = False,
    connection_override: Any = None,
) -> ValidationStats:
    """Execute the full validation pipeline.

    Requires a Snowflake connection.  Baselines are loaded from the
    ``BASELINE_ROWS`` table first; if empty, the implicit internal
    stage ``@{database}.VALIDATION.BASELINES`` is tried automatically.

    Args:
        config: Loaded test runner configuration (injected).
        factory_registry: Dialect -> factory mapping (injected).
        project_root: Path to the SCAI project root.
        snowflake_connection: Snowflake connection name (overrides config).
        baseline_dir: Local directory with baseline JSON files (fallback).
        baseline_stage: Snowflake stage containing baselines. If not provided, uses the implicit stage ``@{database}.VALIDATION.BASELINES``.
        pattern: Regex to filter test files by procedure name.
        create_schema: Create ``VALIDATION`` schema/table/views first.
        connection_override: Pre-built executor (for testing).

    Returns:
        :class:`ValidationStats` summary.
    """
    project_root = Path(project_root)
    regex = re.compile(pattern)

    sf_factory = factory_registry.get(DatabaseDialect.SNOWFLAKE)
    if sf_factory is None:
        raise ValueError("No executor factory registered for Snowflake.")

    executor: Optional[DatabaseExecutor] = None
    owns_executor = connection_override is None
    if connection_override is not None:
        executor = connection_override
    else:
        target_raw = dict(config.target_connection_raw)
        if snowflake_connection:
            target_raw["name"] = snowflake_connection
        if not target_raw.get("name"):
            raise ValueError(
                "Validate requires a Snowflake connection. Provide --connection "
                "or set target_connection.name in settings/test_config.yaml."
            )
        target_raw.setdefault("mode", "name")
        sf_config = sf_factory.build_config(target_raw)
        executor = sf_factory.create_executor(sf_config)

    connector = executor.connector
    if connector is None:
        raise ValueError(
            "Validate requires a Snowflake connector. "
            "The executor must provide a connector property."
        )

    try:
        if create_schema:
            deploy_snowpark_validator(connector, config.validation_database)

        test_files = discover_test_files(project_root, config.selectors)
        test_files = [
            tf for tf in test_files
            if tf.target is not None
            and (regex.search(tf.procedure_name) or regex.search(tf.file_path))
        ]

        if not test_files:
            print("No test YAML files with target steps found.")
            return ValidationStats()

        loader = create_baseline_loader(
            connector=connector,
            database=config.validation_database,
            baseline_dir=Path(baseline_dir) if baseline_dir else None,
            baseline_stage=baseline_stage,
            project_root=project_root,
        )
        baselines = loader.load()
        baseline_index: dict[tuple[str, str], BaselineData] = {
            (bl.procedure, bl.params_hash): bl for bl in baselines
        }

        _print_header(loader.source_label)

        stats = ValidationStats()
        all_results: list[dict[str, Any]] = []
        format_literal = sf_factory.create_literal_formatter().format_literal

        for test_file in test_files:
            for case_idx, test_case in enumerate(test_file.test_cases):
                result = _validate_case(
                    test_file=test_file,
                    test_case=test_case,
                    baseline_index=baseline_index,
                    connector=connector,
                    executor=executor,
                    format_literal=format_literal,
                    config=config,
                )
                all_results.append(result)

                stats.total += 1
                status = result["status"]
                if status == "PASS":
                    stats.passed += 1
                elif status == "NO_BASELINE":
                    stats.no_baseline += 1
                elif status == "ERROR":
                    stats.errors += 1
                else:
                    stats.failed += 1

                _print_case(
                    result["procedure"], result["status"],
                    result.get("match_type", ""), result.get("error", ""),
                )

        if all_results:
            try:
                write_results_batch(connector, all_results, config.validation_database)
            except Exception as exc:
                print(f"Warning: failed to write results to VALIDATION.RESULTS: {exc}")

        _print_summary(stats)
        return stats

    finally:
        if owns_executor and executor is not None:
            executor.close()


# ---------------------------------------------------------------------------
# Internal: validate a single test case
# ---------------------------------------------------------------------------

def _validate_case(
    test_file: TestFile,
    test_case: list[Any],
    baseline_index: dict[tuple[str, str], BaselineData],
    connector: Any,
    executor: DatabaseExecutor,
    format_literal: Callable[[Any], str],
    config: TestRunnerConfig,
) -> dict[str, Any]:
    """Validate one test case from a YAML file against its baseline."""
    parameters = build_parameters(test_file.parameter_names, test_case)
    params_hash = compute_params_hash(parameters)
    procedure = test_file.procedure_name

    result_dict: dict[str, Any] = {
        "procedure": procedure,
        "params_hash": params_hash,
        "params": parameters,
        "status": "",
        "match_type": "",
        "error": "",
        "differences": [],
        "executed_at": datetime.now(timezone.utc).isoformat(),
    }

    baseline = baseline_index.get((procedure, params_hash))
    if baseline is None:
        result_dict["status"] = "NO_BASELINE"
        result_dict["error"] = (
            f"No baseline found for {procedure} (params_hash={params_hash})"
        )
        return result_dict

    assert test_file.target is not None
    target_sql = render_full_sql(test_file.target, test_case, format_literal)

    # Handle error baselines
    if not baseline.success:
        capture_result = executor.execute(target_sql)
        if not capture_result.success:
            if errors_match(baseline.error or "", capture_result.error or ""):
                result_dict["status"] = "PASS"
                result_dict["match_type"] = "error_match"
            else:
                result_dict["status"] = "FAIL"
                result_dict["match_type"] = "error_mismatch"
                result_dict["error"] = (
                    f"Baseline: {(baseline.error or '')[:200]}, "
                    f"Actual: {(capture_result.error or '')[:200]}"
                )
        else:
            result_dict["status"] = "FAIL"
            result_dict["error"] = f"Baseline errored: {(baseline.error or '')[:200]}"
        return result_dict

    comparison = compare_results(
        config=config,
        connector=connector,
        rendered_sql=target_sql,
        params_hash=params_hash,
        procedure_name=procedure,
    )

    result_dict["status"] = "PASS" if comparison["match"] else "FAIL"
    result_dict["match_type"] = comparison["match_type"]
    result_dict["match_level"] = comparison.get("match_level", "")
    result_dict["differences"] = comparison["differences"][:5]

    if not comparison["match"] and comparison["differences"]:
        first = comparison["differences"][0]
        detail = first.get("detail", "") if isinstance(first, dict) else str(first)
        result_dict["error"] = detail

    return result_dict
