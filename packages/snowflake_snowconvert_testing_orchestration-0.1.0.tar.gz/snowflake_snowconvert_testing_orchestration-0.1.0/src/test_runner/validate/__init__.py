"""Validate command -- execute procedures on Snowflake and compare against baselines."""
