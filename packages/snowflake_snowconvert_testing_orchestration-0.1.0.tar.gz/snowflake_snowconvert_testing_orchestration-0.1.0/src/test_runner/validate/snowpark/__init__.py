"""Snowpark validator package -- deployed to Snowflake as a zip.

This package is self-contained: it bundles the comparator and executor logic
so that ``VALIDATION.VALIDATE_BATCH`` / ``VALIDATION.VALIDATE_SINGLE``
can run entirely inside Snowflake's Python runtime.
"""
