"""Test Runner -- capture and validate database objects' baselines."""

__version__ = "0.1.0"

import sys
import warnings

warnings.filterwarnings(
    "ignore",
    message=r".*Core Pydantic V1.*",
    category=UserWarning,
)

_original_unraisablehook = sys.unraisablehook


def _filtered_unraisablehook(unraisable):
    exc = unraisable.exc_value
    if exc is not None and "BaseSettings" in str(exc):
        return
    _original_unraisablehook(unraisable)


sys.unraisablehook = _filtered_unraisablehook

from test_runner.capture.runner import run_capture  # noqa: E402
from test_runner.validate.runner import run_validate  # noqa: E402
from test_runner.common.container import create_container  # noqa: E402

__all__ = ["run_capture", "run_validate", "create_container"]
