"""Tests for test_runner.validate.comparator."""

from __future__ import annotations

import pytest

from test_runner.validate.comparator import errors_match


# ---------------------------------------------------------------------------
# errors_match
# ---------------------------------------------------------------------------

class TestErrorsMatch:
    def test_same_prefix(self):
        assert errors_match("SQL Error: foo", "SQL ERROR: bar") is True

    def test_different_prefix(self):
        assert errors_match("SQL Error: foo", "Runtime: bar") is False

    def test_both_empty(self):
        assert errors_match("", "") is True

    def test_one_empty(self):
        assert errors_match("SQL Error", "") is False

    def test_both_none_like(self):
        assert errors_match("", "") is True

    def test_exact_match(self):
        assert errors_match("ERROR: timeout", "ERROR: connection lost") is True
