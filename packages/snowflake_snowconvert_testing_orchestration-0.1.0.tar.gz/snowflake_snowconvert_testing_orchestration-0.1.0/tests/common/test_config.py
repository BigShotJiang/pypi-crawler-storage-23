"""Tests for named connection resolution in test_runner.common.config."""

from __future__ import annotations

import textwrap
from pathlib import Path

import pytest

from test_runner.common.config import load_config
from test_runner.common.database_dialect import DatabaseDialect


SQLSERVER_TOML = """\
[connections.default]
host = "toml-host"
port = 1433
database = "toml_db"
username = "toml_user"
password = "toml_pw"
trust_server_certificate = "yes"
encrypt = "no"

[connections.staging]
host = "staging-host"
port = 2433
database = "staging_db"
username = "stg_user"
password = "stg_pw"
"""


def _write_config(project: Path, yaml_text: str) -> None:
    settings = project / "settings"
    settings.mkdir(parents=True, exist_ok=True)
    (settings / "test_config.yaml").write_text(textwrap.dedent(yaml_text))


def _write_toml(project: Path, content: str = SQLSERVER_TOML) -> None:
    toml_dir = project / ".snowflake" / "snowct"
    toml_dir.mkdir(parents=True, exist_ok=True)
    (toml_dir / "sqlserver.toml").write_text(content)


# ---------------------------------------------------------------------------
# YAML mode: name  ->  resolves from .snowflake/snowct/sqlserver.toml
# ---------------------------------------------------------------------------

class TestNamedSourceConnection:
    def test_mode_name_resolves_from_toml(self, tmp_path: Path):
        _write_config(tmp_path, """\
            source_platform: sqlserver
            source_connection:
              mode: name
              name: default
        """)
        _write_toml(tmp_path)

        cfg = load_config(tmp_path)
        assert cfg.source_connection_raw["host"] == "toml-host"
        assert cfg.source_connection_raw["database"] == "toml_db"
        assert cfg.source_connection_raw["username"] == "toml_user"

    def test_mode_name_selects_correct_connection(self, tmp_path: Path):
        _write_config(tmp_path, """\
            source_platform: sqlserver
            source_connection:
              mode: name
              name: staging
        """)
        _write_toml(tmp_path)

        cfg = load_config(tmp_path)
        assert cfg.source_connection_raw["host"] == "staging-host"
        assert cfg.source_connection_raw["port"] == 2433

    def test_yaml_overrides_take_precedence(self, tmp_path: Path):
        _write_config(tmp_path, """\
            source_platform: sqlserver
            source_connection:
              mode: name
              name: default
              database: override_db
        """)
        _write_toml(tmp_path)

        cfg = load_config(tmp_path)
        assert cfg.source_connection_raw["host"] == "toml-host"
        assert cfg.source_connection_raw["database"] == "override_db"

    def test_missing_connection_raises(self, tmp_path: Path):
        _write_config(tmp_path, """\
            source_platform: sqlserver
            source_connection:
              mode: name
              name: nonexistent
        """)
        _write_toml(tmp_path)

        with pytest.raises(KeyError, match="nonexistent"):
            load_config(tmp_path)

    def test_credentials_mode_unchanged(self, tmp_path: Path):
        _write_config(tmp_path, """\
            source_platform: sqlserver
            source_connection:
              mode: credentials
              host: direct-host
              database: direct_db
              username: direct_user
              password: direct_pw
        """)

        cfg = load_config(tmp_path)
        assert cfg.source_connection_raw["host"] == "direct-host"
        assert cfg.source_connection_raw["mode"] == "credentials"


# ---------------------------------------------------------------------------
# CLI --source-connection override
# ---------------------------------------------------------------------------

class TestSourceConnectionOverride:
    def test_cli_override_resolves_named_connection(self, tmp_path: Path):
        _write_config(tmp_path, """\
            source_platform: sqlserver
            source_connection:
              mode: credentials
              host: yaml-host
        """)
        _write_toml(tmp_path)

        cfg = load_config(tmp_path, source_connection="default")
        assert cfg.source_connection_raw["host"] == "toml-host"
        assert cfg.source_connection_raw["database"] == "toml_db"

    def test_cli_override_replaces_yaml_connection(self, tmp_path: Path):
        _write_config(tmp_path, """\
            source_platform: sqlserver
            source_connection:
              mode: credentials
              host: yaml-host
              database: yaml_db
        """)
        _write_toml(tmp_path)

        cfg = load_config(tmp_path, source_connection="staging")
        assert cfg.source_connection_raw["host"] == "staging-host"
        assert cfg.source_connection_raw["database"] == "staging_db"
