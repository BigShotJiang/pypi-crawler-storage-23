"""Tests for test_runner.template."""

from __future__ import annotations

import pytest

from test_runner.common.models import ValidationSteps
from test_runner.common.template import format_sql_literal, render_full_sql, render_template


# ---------------------------------------------------------------------------
# format_sql_literal
# ---------------------------------------------------------------------------


class TestFormatSqlLiteral:
    def test_none(self):
        assert format_sql_literal(None) == "NULL"

    def test_int(self):
        assert format_sql_literal(42) == "42"

    def test_float(self):
        assert format_sql_literal(3.14) == "3.14"

    def test_string(self):
        assert format_sql_literal("hello") == "'hello'"

    def test_string_with_quotes(self):
        assert format_sql_literal("it's") == "'it''s'"

    def test_bool_true(self):
        assert format_sql_literal(True) == "1"

    def test_bool_false(self):
        assert format_sql_literal(False) == "0"

    def test_date_string(self):
        assert format_sql_literal("2025-12-09") == "'2025-12-09'"


# ---------------------------------------------------------------------------
# render_template
# ---------------------------------------------------------------------------


class TestRenderTemplate:
    def test_basic_substitution(self):
        template = "EXEC dbo.P @a = {0}, @b = {1}"
        result = render_template(template, [42, "hello"])
        assert result == "EXEC dbo.P @a = 42, @b = 'hello'"

    def test_null_value(self):
        template = "EXEC dbo.P @a = {0}"
        result = render_template(template, [None])
        assert result == "EXEC dbo.P @a = NULL"

    def test_index_out_of_range(self):
        template = "EXEC dbo.P @a = {0}, @b = {1}"
        with pytest.raises(IndexError, match="index 1"):
            render_template(template, [42])

    def test_no_placeholders(self):
        template = "EXECUTE master.dbo.GetProducts"
        result = render_template(template, [])
        assert result == "EXECUTE master.dbo.GetProducts"

    def test_string_escaping(self):
        template = "EXEC dbo.P @name = {0}"
        result = render_template(template, ["O'Brien"])
        assert result == "EXEC dbo.P @name = 'O''Brien'"


# ---------------------------------------------------------------------------
# render_full_sql
# ---------------------------------------------------------------------------


class TestRenderFullSql:
    def test_run_only(self):
        steps = ValidationSteps(run="EXEC dbo.P @a = {0}")
        result = render_full_sql(steps, [1])
        assert result == "EXEC dbo.P @a = 1"

    def test_with_pre_execute(self):
        steps = ValidationSteps(
            run="EXEC dbo.P @a = {0}",
            pre_execute="DECLARE @Out INT;",
        )
        result = render_full_sql(steps, [1])
        assert "DECLARE @Out INT;" in result
        assert "EXEC dbo.P @a = 1" in result
        lines = result.split("\n")
        assert lines[0] == "DECLARE @Out INT;"
        assert lines[1] == "EXEC dbo.P @a = 1"

    def test_empty_pre_execute_ignored(self):
        steps = ValidationSteps(run="EXEC dbo.P @a = {0}", pre_execute="")
        result = render_full_sql(steps, [1])
        assert result == "EXEC dbo.P @a = 1"
