"""Tests for test_runner.discovery."""

from __future__ import annotations

import shutil
from pathlib import Path

import pytest

from test_runner.common.config import SelectorsConfig
from test_runner.common.discovery import (
    discover_test_files,
    extract_parameter_names,
    extract_procedure_name,
)

FIXTURES_DIR = Path(__file__).parent / "fixtures"


# ---------------------------------------------------------------------------
# extract_procedure_name
# ---------------------------------------------------------------------------


class TestExtractProcedureName:
    def test_execute_with_db_schema_proc(self):
        assert extract_procedure_name("EXECUTE master.dbo.GetProducts") == "master.dbo.GetProducts"

    def test_exec_with_schema_proc(self):
        assert extract_procedure_name("EXEC RPT.GetProducts @lspId = {0}") == "RPT.GetProducts"

    def test_call_syntax(self):
        assert extract_procedure_name("CALL RPT.GetProducts({0}, {1})") == "RPT.GetProducts"

    def test_no_match(self):
        assert extract_procedure_name("SELECT * FROM dbo.Products") == ""

    def test_case_insensitive(self):
        assert extract_procedure_name("exec dbo.GetProducts") == "dbo.GetProducts"


# ---------------------------------------------------------------------------
# extract_parameter_names
# ---------------------------------------------------------------------------


class TestExtractParameterNames:
    def test_basic_params(self):
        template = "EXEC dbo.P @a = {0}, @b = {1}"
        assert extract_parameter_names(template) == ["a", "b"]

    def test_no_params(self):
        assert extract_parameter_names("EXECUTE dbo.GetProducts") == []

    def test_mixed_spacing(self):
        template = "EXEC dbo.P @x={0}, @y ={1}, @z = {2}"
        assert extract_parameter_names(template) == ["x", "y", "z"]


# ---------------------------------------------------------------------------
# discover_test_files
# ---------------------------------------------------------------------------


class TestDiscoverTestFiles:
    def test_discovers_files(self, tmp_project: Path):
        files = discover_test_files(tmp_project)
        assert len(files) == 2
        names = {f.procedure_name for f in files}
        assert "master.dbo.GetProducts" in names
        assert "master.dbo.GetCustomerOrders" in names

    def test_extracts_test_cases(self, tmp_project: Path):
        files = discover_test_files(tmp_project)
        orders = next(f for f in files if "GetCustomerOrders" in f.procedure_name)
        assert len(orders.test_cases) == 3
        assert orders.test_cases[0] == [1001, "active"]

    def test_extracts_parameter_names(self, tmp_project: Path):
        files = discover_test_files(tmp_project)
        orders = next(f for f in files if "GetCustomerOrders" in f.procedure_name)
        assert orders.parameter_names == ["customerId", "status"]

    def test_no_artifacts_dir(self, tmp_path: Path):
        files = discover_test_files(tmp_path)
        assert files == []

    def test_selector_schema_filter(self, tmp_project_with_rpt: Path):
        """Only RPT files when schemas filter is ['RPT']."""
        selectors = SelectorsConfig(schemas=["RPT"])
        files = discover_test_files(tmp_project_with_rpt, selectors)
        assert len(files) == 1
        assert "RPT" in files[0].file_path.upper()

    def test_selector_exclude(self, tmp_project: Path):
        selectors = SelectorsConfig(exclude=["getproducts.a1b2c3d4"])
        files = discover_test_files(tmp_project, selectors)
        assert len(files) == 1
        assert "GetCustomerOrders" in files[0].procedure_name

    def test_rpt_schema_procedure(self, tmp_project_with_rpt: Path):
        files = discover_test_files(tmp_project_with_rpt)
        rpt_file = next(f for f in files if f.parameter_names and "lspId" in f.parameter_names)
        assert rpt_file.parameter_names == ["lspId", "locId", "fromDate"]
        assert len(rpt_file.test_cases) == 2
