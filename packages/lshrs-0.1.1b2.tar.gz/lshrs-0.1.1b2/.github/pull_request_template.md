## Summary

<!-- Brief description of the changes -->

## Changes

-

## Test plan

- [ ] Existing tests pass (`uv run pytest`)
- [ ] Linting passes (`uv run ruff check .`)
- [ ] New tests added (if applicable)

## Related issues

<!-- Link any related issues: Closes #123, Fixes #456 -->
