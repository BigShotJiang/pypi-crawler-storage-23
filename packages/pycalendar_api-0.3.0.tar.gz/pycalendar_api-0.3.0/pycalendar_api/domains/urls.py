ENDPOINTS = {
    'bdays:between' : '/bdays/between',
    'bdays:count' : '/bdays/count',
    'bdays:month' : '/bdays/{year}/{month}',
    'bdays:next' : '/bdays/next',
    'bdays:previous' : '/bdays/previous',
    'bdays:year' : '/bdays/{year}',
    'bdays:span:month' : '/bdays/span/month',
    'bdays:span:quarter' : '/bdays/span/quarter',
    'bdays:span:semester' : '/bdays/span/semester',
    'bdays:span:year' : '/bdays/span/year',
    # ================================================
    'health:api': '/health',
    # ================================================
    'holidays:is-holiday' : '/holidays/is-holiday',
    'holidays:year' : '/holidays/{year}',
    'holidays:years' : '/holidays/years',
}
