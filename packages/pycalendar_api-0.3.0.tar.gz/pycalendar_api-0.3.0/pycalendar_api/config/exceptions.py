class ConfigurationError(Exception):
    """Exception générique du domaine config"""
