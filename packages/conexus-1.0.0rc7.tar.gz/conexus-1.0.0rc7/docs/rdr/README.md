# RDR Index

Active and closed RDRs for the Nexus project. Updated by `/rdr-list` and `/rdr-close`.

| ID | Title | Type | Status | Created |
| -- | ----- | ---- | ------ | ------- |
| [RDR-001](rdr-001-rdr-process-validation.md) | RDR Process Validation | Architecture | Accepted | 2026-02-27 |
| [RDR-002](rdr-002-t2-status-synchronization.md) | T2 Status Synchronization | Technical Debt | Accepted | 2026-02-27 |
| [RDR-004](rdr-004-four-store-architecture.md) | Four-Store T3 Architecture | Architecture | Closed | 2026-02-28 |
| [RDR-005](rdr-005-chromadb-cloud-quota-enforcement.md) | ChromaDB Cloud Quota Enforcement | Architecture | Closed | 2026-02-28 |
| [RDR-006](rdr-006-chunk-size-configuration.md) | File-Size Scoring Penalty for Code Search | Feature | Closed | 2026-02-28 |
| [RDR-007](rdr-007-claude-adoption-session-context-and-search-guidance.md) | Claude Adoption: Session Context Gaps and Search Tool Guidance | Feature | Closed | 2026-02-28 |

## RDR Process Documentation

- [Overview](../rdr-overview.md) — What RDRs are, evidence classification, the iterative pattern
- [Workflow](../rdr-workflow.md) — Create, research, gate, accept, close — slash commands
- [Nexus Integration](../rdr-nexus-integration.md) — How Nexus storage tiers and agents amplify RDRs
- [Templates](../rdr-templates.md) — Document and post-mortem template reference
