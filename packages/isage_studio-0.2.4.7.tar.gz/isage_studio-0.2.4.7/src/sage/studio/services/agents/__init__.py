"""Agent implementations for SAGE Studio.

Provides specialized agents for the Swarm Architecture.
"""

from .base import BaseAgent
from .researcher import ResearcherAgent

__all__ = ["BaseAgent", "ResearcherAgent"]
