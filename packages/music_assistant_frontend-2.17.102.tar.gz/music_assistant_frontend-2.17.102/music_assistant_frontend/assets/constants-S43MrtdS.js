const s=["discover","search","artists","albums","tracks","playlists","audiobooks","podcasts","radios","genres","browse","settings"];export{s as D};
