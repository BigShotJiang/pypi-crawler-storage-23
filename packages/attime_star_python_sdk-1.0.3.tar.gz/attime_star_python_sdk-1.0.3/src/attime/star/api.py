import os, jsonpickle
from http import HTTPMethod
from fmconsult.http.api import ApiBase
from fmconsult.utils.url import UrlUtil

class ATTimeStarApi(ApiBase):

  def __init__(self):
    try:
      self.api_environment = os.environ['attime.star.api.environment']
      self.api_company_name = os.environ['attime.star.api.company.name']
      self.api_enrollment = os.environ['attime.star.api.enrollment']
      self.api_password = os.environ['attime.star.api.password']

      api_sandbox_base_url = 'https://starbackhom.attime.inf.br'
      api_live_base_url = 'https://starback.attime.com.br'

      get_base_url = lambda env: api_live_base_url if env == 'live' else api_sandbox_base_url

      self.base_url = get_base_url(self.api_environment)
      self.headers = {
        'Empresa': self.api_company_name
      }

      self.__login()
    except:
      raise
  def __login(self):
    try:
      res = self.call_request(
        http_method = HTTPMethod.POST, 
        request_url = UrlUtil().make_url(self.base_url, ['rss','ARSA0000','Login']), 
        payload = {
          'matricula': self.api_enrollment, 
          'senha': self.api_password
        }
      )
      res = jsonpickle.decode(res)
      if not('codigo' in res):
        self.access_token = res['dados']['token']
        self.headers['Authorization'] = f'Bearer {self.access_token}'
      else:
        raise Exception(res['mensagem'])
    except:
      raise