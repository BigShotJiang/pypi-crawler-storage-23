import logging, jsonpickle
from http import HTTPMethod
from fmconsult.utils.url import UrlUtil
from attime.star.api import ATTimeStarApi
from attime.star.dtos.infocar import Veiculo

class InfoCarApi(ATTimeStarApi):

  def get_vehicle_data(self, PlacaChassi: str, FuncionarioCnpjCpf: str):
    logging.info(f'getting vehicle data by plate in InfoCar API...')
    try:
      url = UrlUtil().make_url(self.base_url, ['btc', 'ABTC0003', 'ApiInfoCar', 'Placa'])
      res = self.call_request(
        http_method = HTTPMethod.GET, 
        request_url = url,
        params = {
          'PlacaChassi': PlacaChassi,
          'FuncionarioCnpjCpf': FuncionarioCnpjCpf
        }
      )
      res = jsonpickle.decode(res)
      
      if 'dados' not in res:
        raise Exception(res.get('mensagem', 'Erro desconhecido'))

      items = [Veiculo(**item) for item in res['dados']]

      return items
    except:
      raise