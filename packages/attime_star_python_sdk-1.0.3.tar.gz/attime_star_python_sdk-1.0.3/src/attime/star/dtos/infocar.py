from dataclasses import dataclass, asdict
from typing import Optional

@dataclass
class Veiculo:
    placa: str
    codigoFipe: str
    apiExternaCodigo: str
    fonteCodigoSequencial: int
    vrmFonte: str
    vrmTipo: str
    chassi: str
    modelo: str
    marca: str
    anoFabricacao: int
    anoModelo: int
    valor: float
    cor: str
    combustivel: str
    uf: str
    municipio: str
    tipoVeiculo: str
    motor: str
    numeroCaixaCambio: Optional[str] = None
    numeroEixoTraseiroDiferencial: Optional[str] = None
    procedencia: Optional[str] = None
    situacaoChassi: Optional[str] = None
    capacidadeDeCarga: Optional[str] = None
    potencia: Optional[str] = None
    numeroCilindradas: Optional[int] = None
    capacidadeDePassageiros: Optional[int] = None
    tipoMontagem: Optional[str] = None
    quantidadeDeEixos: Optional[int] = None
    cmt: Optional[str] = None
    pbt: Optional[str] = None
    carroceria: Optional[str] = None
    numeroCarroceria: Optional[str] = None
    descricao: Optional[str] = None
    manutencaoUsuarioCpf: Optional[str] = None
    manutencaoUsuarioDataHora: Optional[str] = None

    def to_dict(self):
      return asdict(self)