# Computer utils module
