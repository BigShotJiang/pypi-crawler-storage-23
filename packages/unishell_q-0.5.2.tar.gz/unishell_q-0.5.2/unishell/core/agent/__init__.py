"""Desktop Agent module for secure gateway integration."""
from .agent import DesktopAgent
from .config import AgentConfig
from .gateway_client import GatewayClient
from .config_manager import ConfigManager

__all__ = ["DesktopAgent", "AgentConfig", "GatewayClient", "ConfigManager"]
