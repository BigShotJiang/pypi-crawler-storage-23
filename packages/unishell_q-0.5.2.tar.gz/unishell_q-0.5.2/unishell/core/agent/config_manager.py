"""Configuration manager for gateway settings."""
import json
import os
from pathlib import Path
from typing import Optional

class ConfigManager:
    def __init__(self):
        self.config_dir = Path.home() / ".unishell"
        self.config_file = self.config_dir / "gateway_config.json"
        self.config_dir.mkdir(exist_ok=True)
        
    def save_config(self, gateway_url: str, device_token: str):
        """Save gateway configuration."""
        config = {
            "gateway_enabled": True,
            "gateway_url": gateway_url,
            "device_token": device_token
        }
        
        with open(self.config_file, 'w') as f:
            json.dump(config, f, indent=2)
    
    def load_config(self) -> Optional[dict]:
        """Load gateway configuration."""
        if not self.config_file.exists():
            return None
        
        try:
            with open(self.config_file, 'r') as f:
                return json.load(f)
        except:
            return None
    
    def is_gateway_enabled(self) -> bool:
        """Check if gateway mode is enabled."""
        config = self.load_config()
        return config and config.get("gateway_enabled", False)
    
    def disable_gateway(self):
        """Disable gateway mode."""
        config = self.load_config()
        if config:
            config["gateway_enabled"] = False
            with open(self.config_file, 'w') as f:
                json.dump(config, f, indent=2)
