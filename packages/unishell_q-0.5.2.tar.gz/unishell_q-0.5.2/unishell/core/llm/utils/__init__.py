# LLM utils module
