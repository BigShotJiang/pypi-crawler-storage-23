"""Safe OS execution adapter with deterministic methods."""

import os
import shutil
import platform
import subprocess
import psutil
from pathlib import Path
from typing import Optional
from ..models.execution_result import ExecutionResult


class SafeOSExecutionAdapter:
    """Safe OS abstraction layer with path validation and dry-run support."""

    def __init__(self, allowed_paths: Optional[list[str]] = None):
        """Initialize adapter.
        
        Args:
            allowed_paths: List of allowed path prefixes (None = all paths allowed)
        """
        self.allowed_paths = [Path(p).resolve() for p in allowed_paths] if allowed_paths else None

    def _validate_path(self, path: str) -> tuple[bool, str, Path]:
        """Validate path is safe and within allowed directories.
        
        Args:
            path: Path to validate
            
        Returns:
            Tuple of (is_valid, error_message, resolved_path)
        """
        try:
            resolved = Path(path).resolve()
            
            # Check if path contains dangerous patterns
            path_str = str(resolved)
            if '..' in path or path_str.startswith('//'):
                return False, "Path contains dangerous patterns", resolved
            
            # Check against allowed paths if configured
            if self.allowed_paths:
                if not any(str(resolved).startswith(str(allowed)) for allowed in self.allowed_paths):
                    return False, f"Path not in allowed directories", resolved
            
            return True, "", resolved
            
        except Exception as e:
            return False, f"Invalid path: {str(e)}", Path()

    def rename_file(self, path: str, new_name: str, dry_run: bool = False) -> ExecutionResult:
        """Rename a file or directory.
        
        Args:
            path: Current file path
            new_name: New name for the file (just the name, not full path)
            dry_run: If True, only validate without executing
            
        Returns:
            ExecutionResult
        """
        # Validate source path
        valid, error, src_path = self._validate_path(path)
        if not valid:
            return ExecutionResult(
                success=False,
                message=f"Invalid path: {error}",
                dry_run=dry_run
            )
        
        # Check source exists
        if not src_path.exists():
            return ExecutionResult(
                success=False,
                message=f"File does not exist: {src_path}",
                dry_run=dry_run
            )
        
        # Create destination path (same directory, new name)
        dst_path = src_path.parent / new_name
        
        # Validate destination path
        valid, error, dst_path = self._validate_path(str(dst_path))
        if not valid:
            return ExecutionResult(
                success=False,
                message=f"Invalid destination: {error}",
                dry_run=dry_run
            )
        
        # Check destination doesn't already exist
        if dst_path.exists():
            return ExecutionResult(
                success=False,
                message=f"Destination already exists: {dst_path}",
                dry_run=dry_run
            )
        
        # Dry run - return success without executing
        if dry_run:
            return ExecutionResult(
                success=True,
                message=f"[DRY RUN] Would rename {src_path} to {dst_path}",
                data={"source": str(src_path), "destination": str(dst_path)},
                dry_run=True
            )
        
        # Execute rename
        try:
            src_path.rename(dst_path)
            return ExecutionResult(
                success=True,
                message=f"Renamed {src_path.name} to {new_name}",
                data={"source": str(src_path), "destination": str(dst_path)},
                dry_run=False
            )
        except Exception as e:
            return ExecutionResult(
                success=False,
                message=f"Rename failed: {str(e)}",
                dry_run=False
            )

    def move_file(self, source: str, destination: str, dry_run: bool = True) -> ExecutionResult:
        """Move file from source to destination.
        
        Args:
            source: Source file path
            destination: Destination file path
            dry_run: If True, only validate without executing
            
        Returns:
            ExecutionResult
        """
        # Validate source
        valid, error, src_path = self._validate_path(source)
        if not valid:
            return ExecutionResult(
                success=False,
                message=f"Invalid source: {error}",
                dry_run=dry_run
            )
        
        # Validate destination
        valid, error, dst_path = self._validate_path(destination)
        if not valid:
            return ExecutionResult(
                success=False,
                message=f"Invalid destination: {error}",
                dry_run=dry_run
            )
        
        # Check source exists
        if not src_path.exists():
            return ExecutionResult(
                success=False,
                message=f"Source does not exist: {src_path}",
                dry_run=dry_run
            )
        
        # Check source is a file
        if not src_path.is_file():
            return ExecutionResult(
                success=False,
                message=f"Source is not a file: {src_path}",
                dry_run=dry_run
            )
        
        # Dry run - return success without executing
        if dry_run:
            return ExecutionResult(
                success=True,
                message=f"[DRY RUN] Would move {src_path} to {dst_path}",
                data={"source": str(src_path), "destination": str(dst_path)},
                dry_run=True
            )
        
        # Execute move
        try:
            src_path.rename(dst_path)
            return ExecutionResult(
                success=True,
                message=f"Moved {src_path.name} to {dst_path}",
                data={"source": str(src_path), "destination": str(dst_path)},
                dry_run=False
            )
        except Exception as e:
            return ExecutionResult(
                success=False,
                message=f"Move failed: {str(e)}",
                dry_run=False
            )

    def delete_file(self, path: str, dry_run: bool = True) -> ExecutionResult:
        """Delete file at path.
        
        Args:
            path: File path to delete
            dry_run: If True, only validate without executing
            
        Returns:
            ExecutionResult
        """
        # Validate path
        valid, error, file_path = self._validate_path(path)
        if not valid:
            return ExecutionResult(
                success=False,
                message=f"Invalid path: {error}",
                dry_run=dry_run
            )
        
        # Check file exists
        if not file_path.exists():
            return ExecutionResult(
                success=False,
                message=f"File does not exist: {file_path}",
                dry_run=dry_run
            )
        
        # Check is a file
        if not file_path.is_file():
            return ExecutionResult(
                success=False,
                message=f"Path is not a file: {file_path}",
                dry_run=dry_run
            )
        
        # Dry run - return success without executing
        if dry_run:
            return ExecutionResult(
                success=True,
                message=f"[DRY RUN] Would delete {file_path}",
                data={"path": str(file_path), "size": file_path.stat().st_size},
                dry_run=True
            )
        
        # Execute delete
        try:
            file_path.unlink()
            return ExecutionResult(
                success=True,
                message=f"Deleted {file_path}",
                data={"path": str(file_path)},
                dry_run=False
            )
        except Exception as e:
            return ExecutionResult(
                success=False,
                message=f"Delete failed: {str(e)}",
                dry_run=False
            )

    def restart_system(self, delay: int = 0, dry_run: bool = True) -> ExecutionResult:
        """Restart the system.
        
        Args:
            delay: Delay in seconds before restart
            dry_run: If True, only validate without executing (default: True)
            
        Returns:
            ExecutionResult
        """
        system = platform.system()
        
        # Dry run - return success without executing
        if dry_run:
            return ExecutionResult(
                success=True,
                message=f"[DRY RUN] Would restart {system} system with {delay}s delay",
                data={"system": system, "delay": delay},
                dry_run=True
            )
        
        # Build command based on OS (but don't execute - too dangerous)
        # In production, this would require additional safety checks
        return ExecutionResult(
            success=False,
            message="System restart requires explicit confirmation and elevated privileges",
            data={"system": system, "delay": delay},
            dry_run=False,
            metadata={"requires_confirmation": True, "requires_elevation": True}
        )

    def get_file_info(self, path: str) -> ExecutionResult:
        """Get file information (safe read-only operation).
        
        Args:
            path: File path
            
        Returns:
            ExecutionResult with file info
        """
        valid, error, file_path = self._validate_path(path)
        if not valid:
            return ExecutionResult(
                success=False,
                message=f"Invalid path: {error}",
                dry_run=False
            )
        
        if not file_path.exists():
            return ExecutionResult(
                success=False,
                message=f"Path does not exist: {file_path}",
                dry_run=False
            )
        
        try:
            stat = file_path.stat()
            return ExecutionResult(
                success=True,
                message=f"File info for {file_path}",
                data={
                    "path": str(file_path),
                    "size": stat.st_size,
                    "is_file": file_path.is_file(),
                    "is_dir": file_path.is_dir(),
                    "exists": True
                },
                dry_run=False
            )
        except Exception as e:
            return ExecutionResult(
                success=False,
                message=f"Failed to get file info: {str(e)}",
                dry_run=False
            )

    def create_folder(self, name: str, path: str, parents: bool = True, dry_run: bool = True) -> ExecutionResult:
        """Create a new folder.
        
        Args:
            name: Folder name
            path: Parent directory path
            parents: Create parent directories if needed
            dry_run: If True, only validate without executing
            
        Returns:
            ExecutionResult
        """
        # Validate parent path
        valid, error, parent_path = self._validate_path(path)
        if not valid:
            return ExecutionResult(
                success=False,
                message=f"Invalid parent path: {error}",
                dry_run=dry_run
            )
        
        # Create full folder path
        folder_path = parent_path / name
        
        # Check if already exists
        if folder_path.exists():
            return ExecutionResult(
                success=False,
                message=f"Folder already exists: {folder_path}",
                dry_run=dry_run
            )
        
        # Dry run
        if dry_run:
            return ExecutionResult(
                success=True,
                message=f"[DRY RUN] Would create folder {folder_path}",
                data={"path": str(folder_path), "parents": parents},
                dry_run=True
            )
        
        # Execute
        try:
            folder_path.mkdir(parents=parents, exist_ok=False)
            return ExecutionResult(
                success=True,
                message=f"Created folder {folder_path}",
                data={"path": str(folder_path)},
                dry_run=False
            )
        except Exception as e:
            return ExecutionResult(
                success=False,
                message=f"Failed to create folder: {str(e)}",
                dry_run=False
            )

    def create_excel(self, path: str, sheet_name: Optional[str] = None, dry_run: bool = True) -> ExecutionResult:
        """Create a new Excel file.
        
        Args:
            path: Path to the Excel file
            sheet_name: Initial sheet name
            dry_run: If True, only validate without executing
            
        Returns:
            ExecutionResult
        """
        # Validate path
        valid, error, file_path = self._validate_path(path)
        if not valid:
            return ExecutionResult(
                success=False,
                message=f"Invalid path: {error}",
                dry_run=dry_run
            )
        
        # Check if already exists
        if file_path.exists():
            return ExecutionResult(
                success=False,
                message=f"File already exists: {file_path}",
                dry_run=dry_run
            )
        
        # Dry run
        if dry_run:
            return ExecutionResult(
                success=True,
                message=f"[DRY RUN] Would create Excel file at {file_path}",
                data={"path": str(file_path), "sheet_name": sheet_name},
                dry_run=True
            )
        
        # Execute
        try:
            import openpyxl
            wb = openpyxl.Workbook()
            if sheet_name:
                ws = wb.active
                ws.title = sheet_name
            
            # Ensure directory exists
            file_path.parent.mkdir(parents=True, exist_ok=True)
            
            wb.save(str(file_path))
            return ExecutionResult(
                success=True,
                message=f"Created Excel file at {file_path}",
                data={"path": str(file_path)},
                dry_run=False
            )
        except Exception as e:
            return ExecutionResult(
                success=False,
                message=f"Failed to create Excel file: {str(e)}",
                dry_run=False
            )

    def open_excel(self, path: str, dry_run: bool = True) -> ExecutionResult:
        """Open an existing Excel file with the default associated application.
        
        Args:
            path: Path to the Excel file
            dry_run: If True, only validate without executing
            
        Returns:
            ExecutionResult
        """
        # Validate path
        valid, error, file_path = self._validate_path(path)
        if not valid:
            return ExecutionResult(
                success=False,
                message=f"Invalid path: {error}",
                dry_run=dry_run
            )
        
        # Check file exists
        if not file_path.exists():
            return ExecutionResult(
                success=False,
                message=f"File does not exist: {file_path}",
                dry_run=dry_run
            )
        
        # Check is a file
        if not file_path.is_file():
            return ExecutionResult(
                success=False,
                message=f"Path is not a file: {file_path}",
                dry_run=dry_run
            )
        
        # Optional: basic extension check (still allow if missing .xlsx)
        if file_path.suffix.lower() not in [".xlsx", ".xls", ".xlsm", ".csv"]:
            # Not fatal, just a warning in message
            warning = " (warning: file extension is not a typical Excel format)"
        else:
            warning = ""
        
        # Dry run - don't actually open the file
        if dry_run:
            return ExecutionResult(
                success=True,
                message=f"[DRY RUN] Would open Excel file at {file_path}{warning}",
                data={"path": str(file_path)},
                dry_run=True
            )
        
        # Execute: open with OS default handler
        try:
            system = platform.system().lower()
            if "windows" in system:
                os.startfile(str(file_path))  # type: ignore[attr-defined]
            elif "darwin" in system:
                subprocess.Popen(["open", str(file_path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            else:
                subprocess.Popen(["xdg-open", str(file_path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            
            return ExecutionResult(
                success=True,
                message=f"Opened Excel file at {file_path}{warning}",
                data={"path": str(file_path)},
                dry_run=False
            )
        except Exception as e:
            return ExecutionResult(
                success=False,
                message=f"Failed to open Excel file: {str(e)}",
                dry_run=False
            )

    def save_excel(self, path: str, dry_run: bool = True) -> ExecutionResult:
        """Best-effort "save" for an Excel file.
        
        Note: In general, saving is handled by the application (Excel). This method
        attempts to re-save the workbook on disk to ensure it's persisted.
        
        Args:
            path: Path to the Excel file
            dry_run: If True, only validate without executing
            
        Returns:
            ExecutionResult
        """
        valid, error, file_path = self._validate_path(path)
        if not valid:
            return ExecutionResult(success=False, message=f"Invalid path: {error}", dry_run=dry_run)
        
        if not file_path.exists():
            return ExecutionResult(success=False, message=f"File does not exist: {file_path}", dry_run=dry_run)
        
        if not file_path.is_file():
            return ExecutionResult(success=False, message=f"Path is not a file: {file_path}", dry_run=dry_run)
        
        if dry_run:
            return ExecutionResult(
                success=True,
                message=f"[DRY RUN] Would save Excel file at {file_path}",
                data={"path": str(file_path)},
                dry_run=True
            )
        
        suffix = file_path.suffix.lower()
        if suffix in [".xlsx", ".xlsm", ".xltx", ".xltm"]:
            # Try a real read+write cycle via openpyxl (may fail if file is locked by Excel)
            try:
                import openpyxl
                wb = openpyxl.load_workbook(str(file_path))
                wb.save(str(file_path))
                return ExecutionResult(
                    success=True,
                    message=f"Saved Excel file at {file_path}",
                    data={"path": str(file_path)},
                    dry_run=False
                )
            except PermissionError:
                return ExecutionResult(
                    success=False,
                    message=f"Cannot save {file_path}: file is in use (likely open in Excel). Please switch to Excel and press Ctrl+S, then try again.",
                    dry_run=False,
                    metadata={"reason": "file_locked"}
                )
            except Exception as e:
                return ExecutionResult(
                    success=False,
                    message=f"Failed to save Excel file: {str(e)}",
                    dry_run=False
                )
        else:
            # For formats we don't rewrite safely here (e.g. .xls, .csv), just touch the file timestamp.
            try:
                os.utime(str(file_path), None)
                return ExecutionResult(
                    success=True,
                    message=f"Updated file timestamp for {file_path} (format {suffix} is not re-saved by UniShell)",
                    data={"path": str(file_path), "format": suffix},
                    dry_run=False
                )
            except Exception as e:
                return ExecutionResult(
                    success=False,
                    message=f"Failed to update timestamp for {file_path}: {str(e)}",
                    dry_run=False
                )

    def update_cell(self, path: str, cell: str, value: str, sheet_name: str = None, dry_run: bool = True) -> ExecutionResult:
        """Update a cell value in an Excel file.
        
        Args:
            path: Path to the Excel file
            cell: Cell reference (e.g., 'A1', 'B5')
            value: Value to set in the cell
            sheet_name: Sheet name (optional, uses active sheet if not specified)
            dry_run: If True, only validate without executing
            
        Returns:
            ExecutionResult
        """
        valid, error, file_path = self._validate_path(path)
        if not valid:
            return ExecutionResult(success=False, message=f"Invalid path: {error}", dry_run=dry_run)
        
        if not file_path.exists():
            return ExecutionResult(success=False, message=f"File does not exist: {file_path}", dry_run=dry_run)
        
        if not file_path.is_file():
            return ExecutionResult(success=False, message=f"Path is not a file: {file_path}", dry_run=dry_run)
        
        if dry_run:
            return ExecutionResult(
                success=True,
                message=f"[DRY RUN] Would update cell {cell} to '{value}' in {file_path}",
                data={"path": str(file_path), "cell": cell, "value": value, "sheet": sheet_name},
                dry_run=True
            )
        
        try:
            import openpyxl
            wb = openpyxl.load_workbook(str(file_path))
            
            if sheet_name:
                if sheet_name not in wb.sheetnames:
                    return ExecutionResult(
                        success=False,
                        message=f"Sheet '{sheet_name}' not found. Available sheets: {', '.join(wb.sheetnames)}",
                        dry_run=False
                    )
                ws = wb[sheet_name]
            else:
                ws = wb.active
            
            ws[cell] = value
            wb.save(str(file_path))
            
            return ExecutionResult(
                success=True,
                message=f"Updated cell {cell} to '{value}' in {file_path}",
                data={"path": str(file_path), "cell": cell, "value": value, "sheet": sheet_name or ws.title},
                dry_run=False
            )
        except PermissionError:
            return ExecutionResult(
                success=False,
                message=f"Cannot update {file_path}: file is in use (likely open in Excel). Please close the file and try again.",
                dry_run=False,
                metadata={"reason": "file_locked"}
            )
        except Exception as e:
            return ExecutionResult(
                success=False,
                message=f"Failed to update cell: {str(e)}",
                dry_run=False
            )

    def read_file(self, path: str, encoding: str = "utf-8") -> ExecutionResult:
        """Read file contents.
        
        Args:
            path: File path
            encoding: File encoding
            
        Returns:
            ExecutionResult with file contents
        """
        valid, error, file_path = self._validate_path(path)
        if not valid:
            return ExecutionResult(
                success=False,
                message=f"Invalid path: {error}",
                dry_run=False
            )
        
        if not file_path.exists():
            return ExecutionResult(
                success=False,
                message=f"File does not exist: {file_path}",
                dry_run=False
            )
        
        if not file_path.is_file():
            return ExecutionResult(
                success=False,
                message=f"Path is not a file: {file_path}",
                dry_run=False
            )
        
        try:
            content = file_path.read_text(encoding=encoding)
            return ExecutionResult(
                success=True,
                message=f"Read {len(content)} characters from {file_path}",
                data={"path": str(file_path), "content": content, "size": len(content)},
                dry_run=False
            )
        except Exception as e:
            return ExecutionResult(
                success=False,
                message=f"Failed to read file: {str(e)}",
                dry_run=False
            )

    def create_file(self, path: str, content: str = "", dry_run: bool = True) -> ExecutionResult:
        """Create a new file."""
        valid, error, file_path = self._validate_path(path)
        if not valid:
            return ExecutionResult(success=False, message=f"Invalid path: {error}", dry_run=dry_run)
        
        if file_path.exists():
            return ExecutionResult(success=False, message=f"File already exists: {file_path}", dry_run=dry_run)
        
        if dry_run:
            return ExecutionResult(success=True, message=f"[DRY RUN] Would create file {file_path}", dry_run=True)
        
        try:
            file_path.parent.mkdir(parents=True, exist_ok=True)
            file_path.write_text(content, encoding="utf-8")
            return ExecutionResult(success=True, message=f"Created file {file_path}", data={"path": str(file_path)}, dry_run=False)
        except Exception as e:
            return ExecutionResult(success=False, message=f"Failed: {str(e)}", dry_run=False)
        """Write content to file.
        
        Args:
            path: File path
            content: Content to write
            mode: Write mode ('w' or 'a')
            encoding: File encoding
            dry_run: If True, only validate without executing
            
        Returns:
            ExecutionResult
        """
        valid, error, file_path = self._validate_path(path)
        if not valid:
            return ExecutionResult(
                success=False,
                message=f"Invalid path: {error}",
                dry_run=dry_run
            )
        
        # Dry run
        if dry_run:
            return ExecutionResult(
                success=True,
                message=f"[DRY RUN] Would write {len(content)} characters to {file_path}",
                data={"path": str(file_path), "size": len(content), "mode": mode},
                dry_run=True
            )
        
        # Execute
        try:
            file_path.write_text(content, encoding=encoding)
            return ExecutionResult(
                success=True,
                message=f"Wrote {len(content)} characters to {file_path}",
                data={"path": str(file_path), "size": len(content)},
                dry_run=False
            )
        except Exception as e:
            return ExecutionResult(
                success=False,
                message=f"Failed to write file: {str(e)}",
                dry_run=False
            )

    def copy_file(self, source: str, destination: str, overwrite: bool = False, dry_run: bool = True) -> ExecutionResult:
        """Copy file from source to destination.
        
        Args:
            source: Source file path
            destination: Destination file path
            overwrite: Allow overwriting existing file
            dry_run: If True, only validate without executing
            
        Returns:
            ExecutionResult
        """
        # Validate source
        valid, error, src_path = self._validate_path(source)
        if not valid:
            return ExecutionResult(
                success=False,
                message=f"Invalid source: {error}",
                dry_run=dry_run
            )
        
        # Validate destination
        valid, error, dst_path = self._validate_path(destination)
        if not valid:
            return ExecutionResult(
                success=False,
                message=f"Invalid destination: {error}",
                dry_run=dry_run
            )
        
        # Check source exists
        if not src_path.exists():
            return ExecutionResult(
                success=False,
                message=f"Source does not exist: {src_path}",
                dry_run=dry_run
            )
        
        # Check source is file
        if not src_path.is_file():
            return ExecutionResult(
                success=False,
                message=f"Source is not a file: {src_path}",
                dry_run=dry_run
            )
        
        # Check destination doesn't exist (unless overwrite)
        if dst_path.exists() and not overwrite:
            return ExecutionResult(
                success=False,
                message=f"Destination already exists: {dst_path}",
                dry_run=dry_run
            )
        
        # Dry run
        if dry_run:
            return ExecutionResult(
                success=True,
                message=f"[DRY RUN] Would copy {src_path} to {dst_path}",
                data={"source": str(src_path), "destination": str(dst_path)},
                dry_run=True
            )
        
        # Execute
        try:
            shutil.copy2(str(src_path), str(dst_path))
            return ExecutionResult(
                success=True,
                message=f"Copied {src_path} to {dst_path}",
                data={"source": str(src_path), "destination": str(dst_path)},
                dry_run=False
            )
        except Exception as e:
            return ExecutionResult(
                success=False,
                message=f"Copy failed: {str(e)}",
                dry_run=False
            )

    def shutdown_system(self, delay: int = 0, force: bool = False, dry_run: bool = True) -> ExecutionResult:
        """Shutdown the system."""
        system = platform.system()
        if dry_run:
            return ExecutionResult(success=True, message=f"[DRY RUN] Would shutdown {system} with {delay}s delay", data={"system": system, "delay": delay}, dry_run=True)
        try:
            if 'windows' in system.lower():
                cmd = f'shutdown /s /t {delay}'
                if force:
                    cmd += ' /f'
            elif 'darwin' in system.lower():
                cmd = f'sudo shutdown -h +{delay//60}'
            else:
                cmd = f'sudo shutdown -h +{delay//60}'
            subprocess.run(cmd, shell=True, check=True)
            return ExecutionResult(success=True, message=f"System shutting down in {delay}s", dry_run=False)
        except Exception as e:
            return ExecutionResult(success=False, message=f"Shutdown failed: {str(e)}", dry_run=False)

    def sleep_system(self, dry_run: bool = True) -> ExecutionResult:
        """Put system to sleep."""
        if dry_run:
            return ExecutionResult(success=True, message="[DRY RUN] Would put system to sleep", dry_run=True)
        try:
            system = platform.system().lower()
            if 'windows' in system:
                subprocess.run('rundll32.exe powrprof.dll,SetSuspendState 0,1,0', shell=True)
            elif 'darwin' in system:
                subprocess.run('pmset sleepnow', shell=True)
            else:
                subprocess.run('systemctl suspend', shell=True)
            return ExecutionResult(success=True, message="System going to sleep", dry_run=False)
        except Exception as e:
            return ExecutionResult(success=False, message=f"Sleep failed: {str(e)}", dry_run=False)

    def hibernate_system(self, dry_run: bool = True) -> ExecutionResult:
        """Hibernate the system."""
        if dry_run:
            return ExecutionResult(success=True, message="[DRY RUN] Would hibernate system", dry_run=True)
        try:
            system = platform.system().lower()
            if 'windows' in system:
                subprocess.run('shutdown /h', shell=True)
            elif 'darwin' in system:
                subprocess.run('pmset hibernatemode 25 && pmset sleepnow', shell=True)
            else:
                subprocess.run('systemctl hibernate', shell=True)
            return ExecutionResult(success=True, message="System hibernating", dry_run=False)
        except Exception as e:
            return ExecutionResult(success=False, message=f"Hibernate failed: {str(e)}", dry_run=False)

    def lock_screen(self, dry_run: bool = True) -> ExecutionResult:
        """Lock the screen."""
        if dry_run:
            return ExecutionResult(success=True, message="[DRY RUN] Would lock screen", dry_run=True)
        try:
            system = platform.system().lower()
            if 'windows' in system:
                subprocess.run('rundll32.exe user32.dll,LockWorkStation', shell=True)
            elif 'darwin' in system:
                subprocess.run('/System/Library/CoreServices/Menu\\ Extras/User.menu/Contents/Resources/CGSession -suspend', shell=True)
            else:
                subprocess.run('loginctl lock-session', shell=True)
            return ExecutionResult(success=True, message="Screen locked", dry_run=False)
        except Exception as e:
            return ExecutionResult(success=False, message=f"Lock failed: {str(e)}", dry_run=False)

    def get_system_resources(self) -> ExecutionResult:
        """Get CPU and RAM usage."""
        try:
            cpu_percent = psutil.cpu_percent(interval=1)
            mem = psutil.virtual_memory()
            data = {
                'cpu_percent': cpu_percent,
                'cpu_count': psutil.cpu_count(),
                'memory_percent': mem.percent,
                'memory_total': mem.total,
                'memory_available': mem.available,
                'memory_used': mem.used,
                'memory_total_gb': round(mem.total / (1024**3), 2),
                'memory_used_gb': round(mem.used / (1024**3), 2),
                'memory_available_gb': round(mem.available / (1024**3), 2)
            }
            message = f"CPU Usage: {cpu_percent}% | RAM: {mem.percent}% ({data['memory_used_gb']}GB / {data['memory_total_gb']}GB used)"
            return ExecutionResult(success=True, message=message, data=data, dry_run=False)
        except Exception as e:
            return ExecutionResult(success=False, message=f"Failed to get resources: {str(e)}", dry_run=False)

    def get_system_info(self) -> ExecutionResult:
        """Get system information."""
        try:
            data = {
                'system': platform.system(),
                'release': platform.release(),
                'version': platform.version(),
                'machine': platform.machine(),
                'processor': platform.processor(),
                'hostname': platform.node()
            }
            return ExecutionResult(success=True, message="System info retrieved", data=data, dry_run=False)
        except Exception as e:
            return ExecutionResult(success=False, message=f"Failed to get info: {str(e)}", dry_run=False)

    def kill_process(self, pid: int, force: bool = False, dry_run: bool = True) -> ExecutionResult:
        """Kill a process by PID."""
        if dry_run:
            return ExecutionResult(success=True, message=f"[DRY RUN] Would kill process {pid}", data={"pid": pid}, dry_run=True)
        try:
            proc = psutil.Process(pid)
            proc.kill() if force else proc.terminate()
            return ExecutionResult(success=True, message=f"Process {pid} terminated", data={"pid": pid}, dry_run=False)
        except psutil.NoSuchProcess:
            return ExecutionResult(success=False, message=f"Process {pid} not found", dry_run=False)
        except Exception as e:
            return ExecutionResult(success=False, message=f"Kill failed: {str(e)}", dry_run=False)

    def start_service(self, name: str, dry_run: bool = True) -> ExecutionResult:
        """Start a service."""
        if dry_run:
            return ExecutionResult(success=True, message=f"[DRY RUN] Would start service {name}", data={"name": name}, dry_run=True)
        return ExecutionResult(success=False, message="Service control requires explicit confirmation", dry_run=False, metadata={"requires_confirmation": True})

    def stop_service(self, name: str, dry_run: bool = True) -> ExecutionResult:
        """Stop a service."""
        if dry_run:
            return ExecutionResult(success=True, message=f"[DRY RUN] Would stop service {name}", data={"name": name}, dry_run=True)
        return ExecutionResult(success=False, message="Service control requires explicit confirmation", dry_run=False, metadata={"requires_confirmation": True})

    def enable_service(self, name: str, dry_run: bool = True) -> ExecutionResult:
        """Enable a service."""
        if dry_run:
            return ExecutionResult(success=True, message=f"[DRY RUN] Would enable service {name}", data={"name": name}, dry_run=True)
        return ExecutionResult(success=False, message="Service control requires explicit confirmation", dry_run=False, metadata={"requires_confirmation": True})

    def disable_service(self, name: str, dry_run: bool = True) -> ExecutionResult:
        """Disable a service."""
        if dry_run:
            return ExecutionResult(success=True, message=f"[DRY RUN] Would disable service {name}", data={"name": name}, dry_run=True)
        return ExecutionResult(success=False, message="Service control requires explicit confirmation", dry_run=False, metadata={"requires_confirmation": True})

    def change_system_setting(self, setting: str, value: str, dry_run: bool = True) -> ExecutionResult:
        """Change system settings."""
        if dry_run:
            return ExecutionResult(success=True, message=f"[DRY RUN] Would change {setting} to {value}", data={"setting": setting, "value": value}, dry_run=True)
        
        system = platform.system().lower()
        setting_lower = setting.lower()
        
        # Volume control
        if 'volume' in setting_lower or 'sound' in setting_lower or 'audio' in setting_lower:
            try:
                # Use PowerShell for simple mute toggle
                subprocess.run('powershell -Command "(New-Object -ComObject WScript.Shell).SendKeys([char]173)"', shell=True, check=True)
                return ExecutionResult(success=True, message="Volume toggled (mute/unmute)", dry_run=False)
            except Exception as e:
                return ExecutionResult(success=False, message=f"Volume control failed: {str(e)}", dry_run=False)
        
        # Network control - user mode alternative
        if 'network' in setting_lower or 'internet' in setting_lower or 'wifi' in setting_lower:
            return ExecutionResult(
                success=False, 
                message="Network control requires administrator privileges. Please run as admin or use Windows Settings > Network & Internet to disable manually.",
                dry_run=False,
                metadata={"requires_admin": True, "manual_steps": "Windows Settings > Network & Internet > Change adapter options > Right-click adapter > Disable"}
            )
        
        return ExecutionResult(success=False, message=f"Setting '{setting}' not supported in user mode", dry_run=False)

    def control_volume(self, action: str, level: int = None, dry_run: bool = False) -> ExecutionResult:
        """Control system volume.
        
        Args:
            action: 'mute', 'unmute', or 'set'
            level: Volume level 0-100 (for 'set' action)
            dry_run: If True, only validate without executing
        """
        if dry_run:
            return ExecutionResult(success=True, message=f"[DRY RUN] Would {action} volume", dry_run=True)
        
        try:
            subprocess.run('powershell -Command "(New-Object -ComObject WScript.Shell).SendKeys([char]173)"', shell=True, check=True)
            return ExecutionResult(success=True, message=f"Volume {action}d", dry_run=False)
        except Exception as e:
            return ExecutionResult(success=False, message=f"Volume control failed: {str(e)}", dry_run=False)

    def update_os(self, auto_install: bool = False, dry_run: bool = True) -> ExecutionResult:
        """Update the operating system."""
        if dry_run:
            return ExecutionResult(success=True, message=f"[DRY RUN] Would update OS (auto_install={auto_install})", data={"auto_install": auto_install}, dry_run=True)
        return ExecutionResult(success=False, message="OS update requires explicit confirmation", dry_run=False, metadata={"requires_confirmation": True})

    def open_browser(self, url: str, query: str = None, dry_run: bool = True) -> ExecutionResult:
        """Open URL in browser."""
        if dry_run:
            return ExecutionResult(success=True, message=f"[DRY RUN] Would open {url}", dry_run=True)
        try:
            import webbrowser
            if query:
                url = f"{url}/search?q={query.replace(' ', '+')}"
            webbrowser.open(url)
            return ExecutionResult(success=True, message=f"Opened {url}", dry_run=False)
        except Exception as e:
            return ExecutionResult(success=False, message=f"Failed: {str(e)}", dry_run=False)

    def install_app(self, app_name: str, source: str = None, version: str = None, dry_run: bool = True) -> ExecutionResult:
        """Install an application."""
        if dry_run:
            return ExecutionResult(success=True, message=f"[DRY RUN] Would install {app_name}", data={"app_name": app_name, "version": version}, dry_run=True)
        try:
            system = platform.system().lower()
            if 'windows' in system:
                cmd = f'winget install {app_name} --silent --accept-source-agreements --accept-package-agreements'
                if version:
                    cmd += f' --version {version}'
                result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=180)
                if result.returncode == 0:
                    return ExecutionResult(success=True, message=f"Installed {app_name}", data={"output": result.stdout}, dry_run=False)
                else:
                    return ExecutionResult(success=False, message=f"Install failed: {result.stderr}", dry_run=False)
            elif 'darwin' in system:
                cmd = f'brew install {app_name}'
            else:
                cmd = f'sudo apt install -y {app_name}'
            subprocess.run(cmd, shell=True, check=True, timeout=180)
            return ExecutionResult(success=True, message=f"Installed {app_name}", dry_run=False)
        except subprocess.TimeoutExpired:
            return ExecutionResult(success=False, message=f"Install timed out after 3 minutes", dry_run=False)
        except Exception as e:
            return ExecutionResult(success=False, message=f"Install failed: {str(e)}", dry_run=False)

    def uninstall_app(self, app_name: str, force: bool = False, dry_run: bool = True) -> ExecutionResult:
        """Uninstall an application."""
        if dry_run:
            return ExecutionResult(success=True, message=f"[DRY RUN] Would uninstall {app_name}", data={"app_name": app_name}, dry_run=True)
        try:
            system = platform.system().lower()
            if 'windows' in system:
                subprocess.run(f'winget uninstall {app_name}', shell=True, check=True)
            elif 'darwin' in system:
                subprocess.run(f'brew uninstall {app_name}', shell=True, check=True)
            else:
                subprocess.run(f'sudo apt remove -y {app_name}', shell=True, check=True)
            return ExecutionResult(success=True, message=f"Uninstalled {app_name}", dry_run=False)
        except Exception as e:
            return ExecutionResult(success=False, message=f"Uninstall failed: {str(e)}", dry_run=False)

    def update_app(self, app_name: str, version: str = None, dry_run: bool = True) -> ExecutionResult:
        """Update an application."""
        if dry_run:
            return ExecutionResult(success=True, message=f"[DRY RUN] Would update {app_name}", data={"app_name": app_name}, dry_run=True)
        try:
            system = platform.system().lower()
            if 'windows' in system:
                subprocess.run(f'winget upgrade {app_name}', shell=True, check=True)
            elif 'darwin' in system:
                subprocess.run(f'brew upgrade {app_name}', shell=True, check=True)
            else:
                subprocess.run(f'sudo apt install --only-upgrade {app_name}', shell=True, check=True)
            return ExecutionResult(success=True, message=f"Updated {app_name}", dry_run=False)
        except Exception as e:
            return ExecutionResult(success=False, message=f"Update failed: {str(e)}", dry_run=False)

    def list_apps(self, filter: str = None) -> ExecutionResult:
        """List installed applications."""
        try:
            system = platform.system().lower()
            if 'windows' in system:
                result = subprocess.run('winget list', shell=True, capture_output=True, text=True)
            elif 'darwin' in system:
                result = subprocess.run('brew list', shell=True, capture_output=True, text=True)
            else:
                result = subprocess.run('apt list --installed', shell=True, capture_output=True, text=True)
            return ExecutionResult(success=True, message="Listed installed apps", data={"output": result.stdout}, dry_run=False)
        except Exception as e:
            return ExecutionResult(success=False, message=f"List failed: {str(e)}", dry_run=False)

    def open_app(self, app_name: str, args: str = None, dry_run: bool = True) -> ExecutionResult:
        """Open an application."""
        if dry_run:
            return ExecutionResult(success=True, message=f"[DRY RUN] Would open {app_name}", data={"app_name": app_name}, dry_run=True)
        try:
            system = platform.system().lower()
            if 'windows' in system:
                import os
                
                app_lower = app_name.lower().replace(' ', '')
                
                # Check if app is already running
                for proc in psutil.process_iter(['name']):
                    try:
                        proc_name = proc.info['name'].lower().replace('.exe', '').replace(' ', '')
                        if app_lower in proc_name or proc_name in app_lower:
                            return ExecutionResult(success=True, message=f"{app_name} is already open", data={"app_name": app_name, "status": "already_running"}, dry_run=False)
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        continue
                
                # Known app paths (fast lookup)
                known_apps = {
                    'teams': r'%LocalAppData%\Microsoft\Teams\current\Teams.exe',
                    'postman': r'%LocalAppData%\Postman\Postman.exe',
                    'slack': r'%LocalAppData%\slack\slack.exe',
                    'discord': r'%LocalAppData%\Discord\app-*\Discord.exe',
                    'vscode': r'%LocalAppData%\Programs\Microsoft VS Code\Code.exe',
                    'chrome': r'%ProgramFiles%\Google\Chrome\Application\chrome.exe'
                }
                
                # Try known path first
                if app_lower in known_apps:
                    known_path = os.path.expandvars(known_apps[app_lower])
                    if '*' in known_path:
                        # Handle wildcard paths
                        import glob
                        matches = glob.glob(known_path)
                        if matches:
                            subprocess.Popen([matches[0]], shell=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                            return ExecutionResult(success=True, message=f"Opened {app_name}", dry_run=False)
                    elif os.path.exists(known_path):
                        subprocess.Popen([known_path], shell=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                        return ExecutionResult(success=True, message=f"Opened {app_name}", dry_run=False)
                
                # Search Start Menu shortcuts
                start_menu_paths = [
                    os.path.expandvars(r'%AppData%\Microsoft\Windows\Start Menu\Programs'),
                    os.path.expandvars(r'%ProgramData%\Microsoft\Windows\Start Menu\Programs')
                ]
                
                for start_path in start_menu_paths:
                    if os.path.exists(start_path):
                        for root, dirs, files in os.walk(start_path):
                            for file in files:
                                file_lower = file.lower().replace(' ', '')
                                if app_lower in file_lower and file.endswith('.lnk'):
                                    lnk_path = os.path.join(root, file)
                                    os.startfile(lnk_path)
                                    return ExecutionResult(success=True, message=f"Opened {app_name}", dry_run=False)
                
                # Search executables
                search_paths = [
                    os.path.expandvars(r'%LocalAppData%\Programs'),
                    os.path.expandvars(r'%LocalAppData%\Microsoft'),
                    os.path.expandvars(r'%AppData%\Local'),
                    os.path.expandvars(r'%ProgramFiles%'),
                    os.path.expandvars(r'%ProgramFiles(x86)%'),
                    os.path.expandvars(r'C:\Program Files\PostgreSQL')
                ]
                
                for base_path in search_paths:
                    if not os.path.exists(base_path):
                        continue
                    try:
                        for root, dirs, files in os.walk(base_path):
                            dirs[:] = [d for d in dirs if d not in ['Windows', 'WindowsApps', 'System32', 'Common Files', 'WinSxS']]
                            if root.count(os.sep) - base_path.count(os.sep) > 4:
                                del dirs[:]
                            
                            for file in files:
                                file_lower = file.lower().replace(' ', '')
                                if app_lower in file_lower and file.endswith('.exe'):
                                    exe_path = os.path.join(root, file)
                                    subprocess.Popen([exe_path], shell=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                                    return ExecutionResult(success=True, message=f"Opened {app_name}", dry_run=False)
                    except (PermissionError, OSError):
                        continue
                
                return ExecutionResult(success=False, message=f"Could not find {app_name}. Try the full app name.", dry_run=False)
            elif 'darwin' in system:
                subprocess.Popen(['open', '-a', app_name], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            else:
                subprocess.Popen([app_name], shell=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return ExecutionResult(success=True, message=f"Opened {app_name}", dry_run=False)
        except Exception as e:
            return ExecutionResult(success=False, message=f"Open failed: {str(e)}", dry_run=False)

    def force_close_app(self, app_name: str, dry_run: bool = True) -> ExecutionResult:
        """Force close an application."""
        if dry_run:
            return ExecutionResult(success=True, message=f"[DRY RUN] Would force close {app_name}", data={"app_name": app_name}, dry_run=True)
        try:
            system = platform.system().lower()
            if 'windows' in system:
                subprocess.run(f'taskkill /F /IM {app_name}.exe', shell=True, check=True)
            else:
                subprocess.run(f'pkill -9 {app_name}', shell=True, check=True)
            return ExecutionResult(success=True, message=f"Force closed {app_name}", dry_run=False)
        except Exception as e:
            return ExecutionResult(success=False, message=f"Force close failed: {str(e)}", dry_run=False)

    def set_default_app(self, app_name: str, file_type: str, dry_run: bool = True) -> ExecutionResult:
        """Set default application for file type."""
        if dry_run:
            return ExecutionResult(success=True, message=f"[DRY RUN] Would set {app_name} as default for {file_type}", data={"app_name": app_name, "file_type": file_type}, dry_run=True)
        try:
            system = platform.system().lower()
            if 'windows' in system:
                subprocess.run(f'assoc {file_type}={app_name}', shell=True, check=True)
            return ExecutionResult(success=True, message=f"Set {app_name} as default for {file_type}", dry_run=False)
        except Exception as e:
            return ExecutionResult(success=False, message=f"Set default failed: {str(e)}", dry_run=False)

    def schedule_app_autostart(self, app_name: str, schedule: str, args: str = None, dry_run: bool = True) -> ExecutionResult:
        """Schedule app auto-start."""
        if dry_run:
            return ExecutionResult(success=True, message=f"[DRY RUN] Would schedule {app_name} to autostart at {schedule}", data={"app_name": app_name, "schedule": schedule}, dry_run=True)
        try:
            system = platform.system().lower()
            if 'windows' in system:
                cmd = f'schtasks /create /tn "{app_name}" /tr "{app_name}" /sc {schedule}'
                subprocess.run(cmd, shell=True, check=True)
            return ExecutionResult(success=True, message=f"Scheduled {app_name} autostart", dry_run=False)
        except Exception as e:
            return ExecutionResult(success=False, message=f"Schedule failed: {str(e)}", dry_run=False)

    def toggle_app_startup(self, app_name: str, enabled: bool, dry_run: bool = True) -> ExecutionResult:
        """Enable/disable startup programs."""
        if dry_run:
            return ExecutionResult(success=True, message=f"[DRY RUN] Would {'enable' if enabled else 'disable'} {app_name} at startup", data={"app_name": app_name, "enabled": enabled}, dry_run=True)
        try:
            system = platform.system().lower()
            if 'windows' in system:
                import winreg
                key_path = r'Software\Microsoft\Windows\CurrentVersion\Run'
                key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_ALL_ACCESS)
                if enabled:
                    winreg.SetValueEx(key, app_name, 0, winreg.REG_SZ, app_name)
                else:
                    winreg.DeleteValue(key, app_name)
                winreg.CloseKey(key)
            return ExecutionResult(success=True, message=f"{'Enabled' if enabled else 'Disabled'} {app_name} at startup", dry_run=False)
        except Exception as e:
            return ExecutionResult(success=False, message=f"Toggle startup failed: {str(e)}", dry_run=False)

    def get_app_version(self, app_name: str) -> ExecutionResult:
        """Get app version."""
        try:
            system = platform.system().lower()
            if 'windows' in system:
                # Try exact match first with specific package ID
                app_id_map = {
                    "postman": "Postman.Postman",
                    "chrome": "Google.Chrome",
                    "firefox": "Mozilla.Firefox",
                    "vscode": "Microsoft.VisualStudioCode",
                    "discord": "Discord.Discord",
                    "spotify": "Spotify.Spotify",
                    "zoom": "Zoom.Zoom",
                    "teams": "Microsoft.Teams",
                    "slack": "SlackTechnologies.Slack",
                    "notepad++": "Notepad++.Notepad++",
                    "vlc": "VideoLAN.VLC",
                    "7zip": "7zip.7zip",
                    "git": "Git.Git",
                    "python": "Python.Python.3.11",
                    "node": "OpenJS.NodeJS",
                    "docker": "Docker.DockerDesktop"
                }
                
                # Use specific package ID if available
                package_id = app_id_map.get(app_name.lower(), app_name)
                
                # Try with package ID first
                result = subprocess.run(f'winget show --id "{package_id}"', shell=True, capture_output=True, text=True, timeout=10)
                
                # If that fails, try exact match with name
                if result.returncode != 0 or "No package found" in result.stdout:
                    result = subprocess.run(f'winget show --exact "{app_name}"', shell=True, capture_output=True, text=True, timeout=10)
                
                # If still fails, try regular search
                if result.returncode != 0 or "No package found" in result.stdout:
                    result = subprocess.run(f'winget show "{app_name}"', shell=True, capture_output=True, text=True, timeout=10)
                
                # Check if multiple packages found
                if "Multiple packages found" in result.stdout:
                    # Extract package list and suggest the first one
                    lines = result.stdout.split('\n')
                    packages = []
                    for line in lines:
                        if line.strip() and not line.startswith('Name') and not line.startswith('----') and '.' in line:
                            parts = line.split()
                            if len(parts) >= 2:
                                packages.append(parts[1])  # Package ID
                    
                    if packages:
                        # Try the first package ID
                        first_package = packages[0]
                        result = subprocess.run(f'winget show --id "{first_package}"', shell=True, capture_output=True, text=True, timeout=10)
                
                # Extract version from output
                version = "Unknown"
                for line in result.stdout.split('\n'):
                    if 'Version:' in line:
                        version = line.split('Version:')[1].strip()
                        break
                
                if version != "Unknown":
                    return ExecutionResult(success=True, message=f"{app_name} version: {version}", data={"app_name": app_name, "version": version}, dry_run=False)
                else:
                    # If still showing multiple packages, return a cleaner message
                    if "Multiple packages found" in result.stdout:
                        return ExecutionResult(success=False, message=f"Multiple {app_name} packages found. Please be more specific (e.g., 'Postman.Postman').", data={"output": result.stdout}, dry_run=False)
                    else:
                        return ExecutionResult(success=True, message=f"Version info for {app_name}\n{result.stdout}", data={"output": result.stdout}, dry_run=False)
            elif 'darwin' in system:
                result = subprocess.run(f'brew info {app_name}', shell=True, capture_output=True, text=True)
                return ExecutionResult(success=True, message=f"Version info for {app_name}", data={"output": result.stdout}, dry_run=False)
            else:
                result = subprocess.run(f'apt show {app_name}', shell=True, capture_output=True, text=True)
                return ExecutionResult(success=True, message=f"Version info for {app_name}", data={"output": result.stdout}, dry_run=False)
        except Exception as e:
            return ExecutionResult(success=False, message=f"Get version failed: {str(e)}", dry_run=False)

    def monitor_cpu_threshold(self, threshold: float, duration: int = 60) -> ExecutionResult:
        """Monitor CPU threshold."""
        try:
            cpu = psutil.cpu_percent(interval=1)
            exceeded = cpu > threshold
            return ExecutionResult(success=True, message=f"CPU: {cpu}% (threshold: {threshold}%)", data={"cpu_percent": cpu, "threshold": threshold, "exceeded": exceeded}, dry_run=False)
        except Exception as e:
            return ExecutionResult(success=False, message=f"Monitor failed: {str(e)}", dry_run=False)

    def monitor_ram_spike(self, spike_threshold: float) -> ExecutionResult:
        """Detect RAM spikes."""
        try:
            mem = psutil.virtual_memory()
            spike = mem.percent > spike_threshold
            return ExecutionResult(success=True, message=f"RAM: {mem.percent}% (spike threshold: {spike_threshold}%)", data={"ram_percent": mem.percent, "spike_threshold": spike_threshold, "spike_detected": spike}, dry_run=False)
        except Exception as e:
            return ExecutionResult(success=False, message=f"Monitor failed: {str(e)}", dry_run=False)

    def monitor_crash_loop(self, service_name: str, restart_threshold: int = 3) -> ExecutionResult:
        """Detect crash loops."""
        try:
            for proc in psutil.process_iter(['name', 'create_time']):
                if service_name.lower() in proc.info['name'].lower():
                    return ExecutionResult(success=True, message=f"Service {service_name} running", data={"service": service_name, "status": "running"}, dry_run=False)
            return ExecutionResult(success=True, message=f"Service {service_name} not running", data={"service": service_name, "status": "stopped"}, dry_run=False)
        except Exception as e:
            return ExecutionResult(success=False, message=f"Monitor failed: {str(e)}", dry_run=False)

    def monitor_error_logs(self, log_path: str) -> ExecutionResult:
        """Analyze error logs."""
        try:
            with open(log_path, 'r') as f:
                lines = f.readlines()[-100:]
                errors = [l for l in lines if 'error' in l.lower() or 'exception' in l.lower()]
            return ExecutionResult(success=True, message=f"Found {len(errors)} errors", data={"error_count": len(errors), "errors": errors[:10]}, dry_run=False)
        except Exception as e:
            return ExecutionResult(success=False, message=f"Analysis failed: {str(e)}", dry_run=False)

    def monitor_root_cause(self, incident_id: str) -> ExecutionResult:
        """Identify root cause."""
        return ExecutionResult(success=True, message=f"Root cause analysis for {incident_id}", data={"incident_id": incident_id, "analysis": "Requires AI analysis"}, dry_run=False)

    def monitor_disk_full(self, threshold_percent: float, path: str = None) -> ExecutionResult:
        """Detect disk nearing full."""
        try:
            disk = psutil.disk_usage(path or '/')
            critical = disk.percent > threshold_percent
            return ExecutionResult(success=True, message=f"Disk: {disk.percent}% (threshold: {threshold_percent}%)", data={"disk_percent": disk.percent, "threshold": threshold_percent, "critical": critical}, dry_run=False)
        except Exception as e:
            return ExecutionResult(success=False, message=f"Monitor failed: {str(e)}", dry_run=False)

    def monitor_predict_failure(self, service_name: str) -> ExecutionResult:
        """Predict service failure."""
        return ExecutionResult(success=True, message=f"Failure prediction for {service_name}", data={"service": service_name, "prediction": "Requires ML model"}, dry_run=False)

    def autofix_config_mismatch(self, config_path: str, expected_config: dict, dry_run: bool = True) -> ExecutionResult:
        """Auto-fix config mismatch."""
        if dry_run:
            return ExecutionResult(success=True, message=f"[DRY RUN] Would fix config at {config_path}", dry_run=True)
        try:
            import json
            with open(config_path, 'w') as f:
                json.dump(expected_config, f, indent=2)
            return ExecutionResult(success=True, message=f"Fixed config at {config_path}", dry_run=False)
        except Exception as e:
            return ExecutionResult(success=False, message=f"Fix failed: {str(e)}", dry_run=False)

    def autofix_rollback_update(self, service_name: str, dry_run: bool = True) -> ExecutionResult:
        """Auto-rollback failed update."""
        if dry_run:
            return ExecutionResult(success=True, message=f"[DRY RUN] Would rollback {service_name}", dry_run=True)
        return ExecutionResult(success=False, message="Rollback requires checkpoint ID", dry_run=False, metadata={"requires_confirmation": True})

    def wifi_disconnect(self, interface: str = None, dry_run: bool = True) -> ExecutionResult:
        """Disconnect from WiFi."""
        if dry_run:
            return ExecutionResult(success=True, message="[DRY RUN] Would disconnect WiFi", dry_run=True)
        try:
            system = platform.system().lower()
            if 'windows' in system:
                subprocess.run('netsh wlan disconnect', shell=True, check=True)
            elif 'darwin' in system:
                subprocess.run('networksetup -setairportpower en0 off', shell=True, check=True)
            else:
                subprocess.run('nmcli radio wifi off', shell=True, check=True)
            return ExecutionResult(success=True, message="WiFi disconnected", dry_run=False)
        except Exception as e:
            return ExecutionResult(success=False, message=f"Disconnect failed: {str(e)}", dry_run=False)

    def wifi_connect(self, ssid: str, password: str = None, dry_run: bool = True) -> ExecutionResult:
        """Connect to WiFi."""
        if dry_run:
            return ExecutionResult(success=True, message=f"[DRY RUN] Would connect to {ssid}", dry_run=True)
        try:
            system = platform.system().lower()
            if 'windows' in system:
                # Disconnect first to ensure network is visible
                subprocess.run('netsh wlan disconnect', shell=True, capture_output=True, timeout=3)
                import time
                time.sleep(0.5)
                
                if password:
                    # XML escape special characters
                    import xml.sax.saxutils as saxutils
                    ssid_escaped = saxutils.escape(ssid)
                    password_escaped = saxutils.escape(password)
                    
                    # Create profile XML for WPA2-Personal
                    import tempfile
                    profile_xml = f'''<?xml version="1.0"?>
<WLANProfile xmlns="http://www.microsoft.com/networking/WLAN/profile/v1">
    <name>{ssid_escaped}</name>
    <SSIDConfig>
        <SSID>
            <name>{ssid_escaped}</name>
        </SSID>
    </SSIDConfig>
    <connectionType>ESS</connectionType>
    <connectionMode>auto</connectionMode>
    <MSM>
        <security>
            <authEncryption>
                <authentication>WPA2PSK</authentication>
                <encryption>AES</encryption>
                <useOneX>false</useOneX>
            </authEncryption>
            <sharedKey>
                <keyType>passPhrase</keyType>
                <protected>false</protected>
                <keyMaterial>{password_escaped}</keyMaterial>
            </sharedKey>
        </security>
    </MSM>
</WLANProfile>'''
                    with tempfile.NamedTemporaryFile(mode='w', suffix='.xml', delete=False, encoding='utf-8') as f:
                        f.write(profile_xml)
                        profile_path = f.name
                    try:
                        result = subprocess.run(f'netsh wlan add profile filename="{profile_path}"', shell=True, capture_output=True, text=True)
                        if result.returncode != 0:
                            return ExecutionResult(success=False, message=f"Failed to create profile: {result.stderr or result.stdout}", dry_run=False)
                    finally:
                        import os
                        os.unlink(profile_path)
                result = subprocess.run(f'netsh wlan connect name="{ssid}"', shell=True, capture_output=True, text=True)
                if result.returncode != 0:
                    error_msg = result.stderr or result.stdout
                    if "not available" in error_msg:
                        return ExecutionResult(success=False, message=f"Network '{ssid}' is not in range or not broadcasting", dry_run=False)
                    return ExecutionResult(success=False, message=f"Connect failed: {error_msg.strip()}", dry_run=False)
            elif 'darwin' in system:
                subprocess.run(f'networksetup -setairportnetwork en0 "{ssid}" {password or ""}', shell=True, check=True)
            else:
                subprocess.run(f'nmcli device wifi connect "{ssid}" password "{password or ""}"', shell=True, check=True)
            return ExecutionResult(success=True, message=f"Connected to {ssid}", dry_run=False)
        except Exception as e:
            return ExecutionResult(success=False, message=f"Connect failed: {str(e)}", dry_run=False)

    def network_check_ip(self, interface: str = None) -> ExecutionResult:
        """Check IP address."""
        try:
            result = subprocess.run('ipconfig', shell=True, capture_output=True, text=True, timeout=10)
            # Parse IPv4 addresses from output
            import re
            ipv4_pattern = r'IPv4 Address[.\s]*: ([0-9.]+)'
            ips = re.findall(ipv4_pattern, result.stdout)
            if ips:
                ip_list = "\n".join([f"  • {ip}" for ip in ips])
                message = f"IP Address(es) found:\n{ip_list}"
            else:
                message = "No IP addresses found"
            return ExecutionResult(success=True, message=message, data={"output": result.stdout, "ips": ips}, dry_run=False)
        except Exception as e:
            return ExecutionResult(success=False, message=f"Failed: {str(e)}", dry_run=False)

    def network_ping(self, host: str, count: int = 4, dry_run: bool = False) -> ExecutionResult:
        """Ping a host."""
        if dry_run:
            return ExecutionResult(success=True, message=f"[DRY RUN] Would ping {host}", dry_run=True)
        try:
            result = subprocess.run(f'ping -n {count} {host}', shell=True, capture_output=True, text=True, timeout=30)
            return ExecutionResult(success=result.returncode == 0, message=f"Pinged {host}", data={"output": result.stdout}, dry_run=False)
        except Exception as e:
            return ExecutionResult(success=False, message=f"Ping failed: {str(e)}", dry_run=False)

    def network_flush_dns(self, dry_run: bool = False) -> ExecutionResult:
        """Flush DNS cache."""
        if dry_run:
            return ExecutionResult(success=True, message="[DRY RUN] Would flush DNS", dry_run=True)
        try:
            result = subprocess.run('ipconfig /flushdns', shell=True, capture_output=True, text=True, timeout=10)
            return ExecutionResult(success=result.returncode == 0, message="DNS cache flushed", data={"output": result.stdout}, dry_run=False)
        except Exception as e:
            return ExecutionResult(success=False, message=f"Failed: {str(e)}", dry_run=False)

    def setup_java(self, version: str, install_path: str = None, dry_run: bool = False) -> ExecutionResult:
        """Setup Java environment (JAVA_HOME and PATH)."""
        if dry_run:
            return ExecutionResult(success=True, message=f"[DRY RUN] Would setup Java {version} at {install_path}", dry_run=True)
        try:
            if not install_path:
                return ExecutionResult(success=False, message="install_path is required", dry_run=False)
            
            java_path = Path(install_path)
            if not java_path.exists():
                return ExecutionResult(success=False, message=f"Java installation not found at {install_path}", dry_run=False)
            
            # Set JAVA_HOME
            subprocess.run(f'setx JAVA_HOME "{install_path}"', shell=True, check=True)
            
            # Add to PATH
            bin_path = str(java_path / "bin")
            subprocess.run(f'setx PATH "%PATH%;{bin_path}"', shell=True, check=True)
            
            return ExecutionResult(success=True, message=f"Java {version} configured: JAVA_HOME={install_path}", data={"version": version, "java_home": install_path}, dry_run=False)
        except Exception as e:
            return ExecutionResult(success=False, message=f"Setup failed: {str(e)}", dry_run=False)


    def wifi_list(self, dry_run: bool = False) -> ExecutionResult:
        """List available WiFi networks."""
        if dry_run:
            return ExecutionResult(success=True, message="[DRY RUN] Would list WiFi networks", dry_run=True)
        try:
            system = platform.system().lower()
            if 'windows' in system:
                result = subprocess.run('netsh wlan show networks mode=bssid', shell=True, capture_output=True, text=True, timeout=10)
                if result.returncode == 0:
                    networks = []
                    current_network = {}
                    
                    for line in result.stdout.split('\n'):
                        line = line.strip()
                        if 'SSID' in line and 'BSSID' not in line:
                            if current_network and current_network.get('ssid'):
                                networks.append(current_network)
                            ssid = line.split(':', 1)[1].strip() if ':' in line else ''
                            current_network = {'ssid': ssid, 'signal': '', 'auth': ''}
                        elif 'Signal' in line and current_network:
                            signal = line.split(':', 1)[1].strip() if ':' in line else ''
                            current_network['signal'] = signal
                        elif 'Authentication' in line and current_network:
                            auth = line.split(':', 1)[1].strip() if ':' in line else ''
                            current_network['auth'] = auth
                    
                    if current_network and current_network.get('ssid'):
                        networks.append(current_network)
                    
                    if networks:
                        network_list = []
                        for i, net in enumerate(networks, 1):
                            ssid = net['ssid']
                            signal = net.get('signal', 'N/A')
                            auth = net.get('auth', 'N/A')
                            network_list.append(f"  {i}. {ssid:<30} Signal: {signal:<10} Auth: {auth}")
                        
                        output = "Available WiFi Networks:\n" + "\n".join(network_list)
                        return ExecutionResult(success=True, message=output, data={"networks": networks, "count": len(networks)}, dry_run=False)
                    else:
                        return ExecutionResult(success=True, message="No WiFi networks found", data={"networks": [], "count": 0}, dry_run=False)
                else:
                    return ExecutionResult(success=False, message="WiFi adapter disabled or unavailable", dry_run=False)
            elif 'darwin' in system:
                result = subprocess.run('/System/Library/PrivateFrameworks/Apple80211.framework/Versions/Current/Resources/airport -s', shell=True, capture_output=True, text=True, timeout=10)
                if result.returncode == 0:
                    return ExecutionResult(success=True, message=f"Available WiFi Networks:\n{result.stdout}", data={"output": result.stdout}, dry_run=False)
            else:
                result = subprocess.run('nmcli device wifi list', shell=True, capture_output=True, text=True, timeout=10)
                if result.returncode == 0:
                    return ExecutionResult(success=True, message=f"Available WiFi Networks:\n{result.stdout}", data={"output": result.stdout}, dry_run=False)
            
            return ExecutionResult(success=False, message="Failed to list WiFi networks", dry_run=False)
        except Exception as e:
            return ExecutionResult(success=False, message=f"WiFi not available: {str(e)}", dry_run=False)


    def get_disk_usage(self, path: str = None) -> ExecutionResult:
        """Get disk usage information.
        
        Args:
            path: Optional path to check specific disk/partition
            
        Returns:
            ExecutionResult with disk usage data
        """
        try:
            if path:
                usage = psutil.disk_usage(path)
                data = {
                    "path": path,
                    "total": usage.total,
                    "used": usage.used,
                    "free": usage.free,
                    "percent": usage.percent,
                    "total_gb": round(usage.total / (1024**3), 2),
                    "used_gb": round(usage.used / (1024**3), 2),
                    "free_gb": round(usage.free / (1024**3), 2)
                }
                return ExecutionResult(
                    success=True,
                    message=f"Disk usage for {path}: {usage.percent}% used ({data['used_gb']}GB / {data['total_gb']}GB)",
                    data=data,
                    dry_run=False
                )
            else:
                partitions = psutil.disk_partitions()
                disk_info = []
                
                for partition in partitions:
                    try:
                        usage = psutil.disk_usage(partition.mountpoint)
                        disk_info.append({
                            "device": partition.device,
                            "mountpoint": partition.mountpoint,
                            "fstype": partition.fstype,
                            "total": usage.total,
                            "used": usage.used,
                            "free": usage.free,
                            "percent": usage.percent,
                            "total_gb": round(usage.total / (1024**3), 2),
                            "used_gb": round(usage.used / (1024**3), 2),
                            "free_gb": round(usage.free / (1024**3), 2)
                        })
                    except (PermissionError, OSError):
                        continue
                
                message_lines = ["Disk Usage:"]
                for disk in disk_info:
                    message_lines.append(
                        f"  {disk['device']} ({disk['mountpoint']}): "
                        f"{disk['percent']}% used - "
                        f"{disk['used_gb']}GB / {disk['total_gb']}GB "
                        f"({disk['free_gb']}GB free)"
                    )
                
                return ExecutionResult(
                    success=True,
                    message="\n".join(message_lines),
                    data={"disks": disk_info},
                    dry_run=False
                )
        except Exception as e:
            return ExecutionResult(
                success=False,
                message=f"Failed to get disk usage: {str(e)}",
                dry_run=False
            )

    def open_pdf(self, path: str, dry_run: bool = True) -> ExecutionResult:
        """Open a PDF file with default application.
        
        Args:
            path: Path to the PDF file
            dry_run: If True, only validate without executing
            
        Returns:
            ExecutionResult
        """
        valid, error, file_path = self._validate_path(path)
        if not valid:
            return ExecutionResult(success=False, message=f"Invalid path: {error}", dry_run=dry_run)
        
        if not file_path.exists():
            return ExecutionResult(success=False, message=f"File does not exist: {file_path}", dry_run=dry_run)
        
        if not file_path.is_file():
            return ExecutionResult(success=False, message=f"Path is not a file: {file_path}", dry_run=dry_run)
        
        if dry_run:
            return ExecutionResult(success=True, message=f"[DRY RUN] Would open PDF file at {file_path}", dry_run=True)
        
        try:
            system = platform.system().lower()
            if "windows" in system:
                os.startfile(str(file_path))
            elif "darwin" in system:
                subprocess.Popen(["open", str(file_path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            else:
                subprocess.Popen(["xdg-open", str(file_path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            
            return ExecutionResult(success=True, message=f"Opened PDF file at {file_path}", dry_run=False)
        except Exception as e:
            return ExecutionResult(success=False, message=f"Failed to open PDF: {str(e)}", dry_run=False)

    def close_pdf(self, path: str, dry_run: bool = True) -> ExecutionResult:
        """Close an open PDF file.
        
        Args:
            path: Path to the PDF file
            dry_run: If True, only validate without executing
            
        Returns:
            ExecutionResult
        """
        valid, error, file_path = self._validate_path(path)
        if not valid:
            return ExecutionResult(success=False, message=f"Invalid path: {error}", dry_run=dry_run)
        
        if dry_run:
            return ExecutionResult(success=True, message=f"[DRY RUN] Would close PDF file {file_path.name}", dry_run=True)
        
        try:
            filename = file_path.name
            closed = False
            
            for proc in psutil.process_iter(['name', 'exe']):
                try:
                    if proc.info['name'] and 'acrobat' in proc.info['name'].lower():
                        proc.terminate()
                        closed = True
                    elif proc.info['name'] and any(reader in proc.info['name'].lower() for reader in ['foxitreader', 'sumatra', 'edge', 'chrome']):
                        proc.terminate()
                        closed = True
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            
            if closed:
                return ExecutionResult(success=True, message=f"Closed PDF viewer", dry_run=False)
            else:
                return ExecutionResult(success=False, message="No PDF viewer found running", dry_run=False)
        except Exception as e:
            return ExecutionResult(success=False, message=f"Failed to close PDF: {str(e)}", dry_run=False)

    def open_document(self, path: str, dry_run: bool = True) -> ExecutionResult:
        """Open a document file with default application.
        
        Args:
            path: Path to the document file
            dry_run: If True, only validate without executing
            
        Returns:
            ExecutionResult
        """
        valid, error, file_path = self._validate_path(path)
        if not valid:
            return ExecutionResult(success=False, message=f"Invalid path: {error}", dry_run=dry_run)
        
        if not file_path.exists():
            return ExecutionResult(success=False, message=f"File does not exist: {file_path}", dry_run=dry_run)
        
        if not file_path.is_file():
            return ExecutionResult(success=False, message=f"Path is not a file: {file_path}", dry_run=dry_run)
        
        if dry_run:
            return ExecutionResult(success=True, message=f"[DRY RUN] Would open document at {file_path}", dry_run=True)
        
        try:
            system = platform.system().lower()
            if "windows" in system:
                os.startfile(str(file_path))
            elif "darwin" in system:
                subprocess.Popen(["open", str(file_path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            else:
                subprocess.Popen(["xdg-open", str(file_path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            
            return ExecutionResult(success=True, message=f"Opened document at {file_path}", dry_run=False)
        except Exception as e:
            return ExecutionResult(success=False, message=f"Failed to open document: {str(e)}", dry_run=False)

    def close_document(self, path: str, dry_run: bool = True) -> ExecutionResult:
        """Close an open document file.
        
        Args:
            path: Path to the document file
            dry_run: If True, only validate without executing
            
        Returns:
            ExecutionResult
        """
        valid, error, file_path = self._validate_path(path)
        if not valid:
            return ExecutionResult(success=False, message=f"Invalid path: {error}", dry_run=dry_run)
        
        if dry_run:
            return ExecutionResult(success=True, message=f"[DRY RUN] Would close document {file_path.name}", dry_run=True)
        
        try:
            closed = False
            
            for proc in psutil.process_iter(['name']):
                try:
                    if proc.info['name'] and any(app in proc.info['name'].lower() for app in ['winword', 'word', 'notepad', 'wordpad']):
                        proc.terminate()
                        closed = True
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            
            if closed:
                return ExecutionResult(success=True, message=f"Closed document viewer", dry_run=False)
            else:
                return ExecutionResult(success=False, message="No document viewer found running", dry_run=False)
        except Exception as e:
            return ExecutionResult(success=False, message=f"Failed to close document: {str(e)}", dry_run=False)

    def control_file(self, path: str, action: str, dry_run: bool = True) -> ExecutionResult:
        """Unified file control - open or close files (PDF, documents, Excel, etc.).
        
        Args:
            path: Path to the file
            action: 'open' or 'close'
            dry_run: If True, only validate without executing
            
        Returns:
            ExecutionResult
        """
        action = action.lower()
        if action not in ['open', 'close']:
            return ExecutionResult(success=False, message=f"Invalid action: {action}. Use 'open' or 'close'", dry_run=dry_run)
        
        valid, error, file_path = self._validate_path(path)
        if not valid:
            return ExecutionResult(success=False, message=f"Invalid path: {error}", dry_run=dry_run)
        
        if action == 'open':
            if not file_path.exists():
                return ExecutionResult(success=False, message=f"File does not exist: {file_path}", dry_run=dry_run)
            if not file_path.is_file():
                return ExecutionResult(success=False, message=f"Path is not a file: {file_path}", dry_run=dry_run)
        
        suffix = file_path.suffix.lower()
        
        if action == 'open':
            if dry_run:
                return ExecutionResult(success=True, message=f"[DRY RUN] Would open {file_path}", dry_run=True)
            
            try:
                system = platform.system().lower()
                if "windows" in system:
                    os.startfile(str(file_path))
                elif "darwin" in system:
                    subprocess.Popen(["open", str(file_path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                else:
                    subprocess.Popen(["xdg-open", str(file_path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                
                return ExecutionResult(success=True, message=f"Opened {file_path.name}", dry_run=False)
            except Exception as e:
                return ExecutionResult(success=False, message=f"Failed to open file: {str(e)}", dry_run=False)
        
        else:  # close
            if dry_run:
                return ExecutionResult(success=True, message=f"[DRY RUN] Would close {file_path.name}", dry_run=True)
            
            try:
                closed = False
                app_names = []
                
                # Determine which apps to close based on file type
                if suffix == '.pdf':
                    app_names = ['acrobat', 'foxitreader', 'sumatra', 'edge', 'chrome']
                elif suffix in ['.doc', '.docx', '.rtf']:
                    app_names = ['winword', 'word']
                elif suffix in ['.txt', '.log']:
                    app_names = ['notepad', 'notepad++']
                elif suffix in ['.xlsx', '.xls', '.xlsm']:
                    app_names = ['excel']
                else:
                    app_names = ['acrobat', 'word', 'excel', 'notepad', 'edge', 'chrome']
                
                for proc in psutil.process_iter(['name']):
                    try:
                        if proc.info['name']:
                            proc_name = proc.info['name'].lower()
                            if any(app in proc_name for app in app_names):
                                proc.terminate()
                                closed = True
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        continue
                
                if closed:
                    return ExecutionResult(success=True, message=f"Closed application viewing {file_path.name}", dry_run=False)
                else:
                    return ExecutionResult(success=False, message=f"No application found viewing {file_path.name}", dry_run=False)
            except Exception as e:
                return ExecutionResult(success=False, message=f"Failed to close: {str(e)}", dry_run=False)


    def install_fresher_packages(self, package_list: str = None, skip_confirmation: bool = False, dry_run: bool = True) -> ExecutionResult:
        """Install standard development tools for freshers."""
        default_packages = ["Git.Git", "Microsoft.VisualStudioCode", "Google.Chrome", "Postman.Postman", "Python.Python.3.11", "OpenJS.NodeJS"]
        packages = package_list.split(',') if package_list else default_packages
        
        if dry_run:
            return ExecutionResult(success=True, message=f"[DRY RUN] Would install {len(packages)} packages: {', '.join(packages)}", data={"packages": packages}, dry_run=True)
        
        try:
            # Check what's already installed
            already_installed = []
            need_to_install = []
            failed = []
            
            for pkg in packages:
                try:
                    # First check with winget
                    check_cmd = f'winget list --exact --id {pkg.strip()}'
                    check_result = subprocess.run(check_cmd, shell=True, capture_output=True, text=True, timeout=30)
                    
                    found = False
                    if check_result.returncode == 0:
                        lines = check_result.stdout.split('\n')
                        for line in lines:
                            if pkg.strip() in line and 'Available' not in line:
                                found = True
                                break
                    
                    # If not found via winget, check if app is actually installed on system
                    if not found:
                        found = self._check_app_installed(pkg.strip())
                    
                    if found:
                        already_installed.append(pkg.strip())
                    else:
                        need_to_install.append(pkg.strip())
                except Exception:
                    need_to_install.append(pkg.strip())
            
            # Install only what's needed
            installed = []
            for pkg in need_to_install:
                try:
                    cmd = f'winget install --id {pkg} --silent --accept-source-agreements --accept-package-agreements'
                    result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=300)
                    if result.returncode == 0:
                        installed.append(pkg)
                    else:
                        failed.append(pkg)
                except Exception:
                    failed.append(pkg)
            
            # Build detailed message in requested format
            result_data = {
                "INSTALL_SUCCESS": [],
                "INSTALL_FAILED": [],
                "INSTALL_SKIPPED_ALREADY_INSTALLED": []
            }
            
            if already_installed:
                result_data["INSTALL_SKIPPED_ALREADY_INSTALLED"] = [self._get_app_name(pkg) for pkg in already_installed]
            
            if installed:
                result_data["INSTALL_SUCCESS"] = [self._get_app_name(pkg) for pkg in installed]
            
            if failed:
                result_data["INSTALL_FAILED"] = [self._get_app_name(pkg) for pkg in failed]
            
            # Create JSON formatted message
            import json
            message = json.dumps(result_data, indent=2)
            
            return ExecutionResult(
                success=len(installed) > 0 or len(already_installed) > 0,
                message=message,
                data=result_data,
                dry_run=False
            )
        except Exception as e:
            return ExecutionResult(success=False, message=f"Installation failed: {str(e)}", dry_run=False)
    
    def _check_app_installed(self, package_id: str) -> bool:
        """Check if app is installed on system (fallback for non-winget installs)."""
        try:
            if package_id == "Google.Chrome":
                # Check for Chrome executable
                chrome_paths = [
                    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
                    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
                ]
                return any(os.path.exists(path) for path in chrome_paths)
            
            elif package_id == "Microsoft.VisualStudioCode":
                # Check for VS Code executable
                vscode_paths = [
                    r"C:\Program Files\Microsoft VS Code\Code.exe",
                    r"C:\Users\{}\AppData\Local\Programs\Microsoft VS Code\Code.exe".format(os.getenv('USERNAME', ''))
                ]
                return any(os.path.exists(path) for path in vscode_paths)
            
            elif package_id == "Python.Python.3.11":
                # Check for Python in PATH
                result = subprocess.run('python --version', shell=True, capture_output=True, text=True, timeout=10)
                return result.returncode == 0 and 'Python' in result.stdout
            
            elif package_id == "OpenJS.NodeJS":
                # Check for Node.js in PATH
                result = subprocess.run('node --version', shell=True, capture_output=True, text=True, timeout=10)
                return result.returncode == 0 and 'v' in result.stdout
            
            elif package_id == "Git.Git":
                # Check for Git in PATH
                result = subprocess.run('git --version', shell=True, capture_output=True, text=True, timeout=10)
                return result.returncode == 0 and 'git version' in result.stdout
            
            elif package_id == "Postman.Postman":
                # Check for Postman executable
                postman_paths = [
                    r"C:\Users\{}\AppData\Local\Postman\Postman.exe".format(os.getenv('USERNAME', '')),
                    r"C:\Program Files\Postman\Postman.exe"
                ]
                return any(os.path.exists(path) for path in postman_paths)
            
            return False
        except Exception:
            return False
    
    def _get_app_name(self, package_id: str) -> str:
        """Convert package ID to friendly app name."""
        name_map = {
            "Git.Git": "Git",
            "Microsoft.VisualStudioCode": "VS Code",
            "Google.Chrome": "Chrome",
            "Postman.Postman": "Postman",
            "Python.Python.3.11": "Python 3.11",
            "OpenJS.NodeJS": "Node.js"
        }
        return name_map.get(package_id, package_id)