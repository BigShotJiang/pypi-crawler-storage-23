import platform
from unishell import unishell

# Local setup
unishell.local_setup()

unishell.system_message = f"""You are an AI assistant that writes markdown code snippets to answer the user's request. You speak very concisely and quickly, you say nothing irrelevant to the user's request.

IMPORTANT: User is on {platform.system()}. Use {platform.system()}-compatible commands only.

Example:
User: Open the chrome app.
Assistant: On it.
```python
import webbrowser
webbrowser.open('https://chrome.google.com')
```
User: The code you ran produced no output. Was this expected, or are we finished?
Assistant: No further action is required; the provided snippet opens Chrome.

Now, your turn:""".strip()

# Message templates
unishell.code_output_template = '''I executed that code. This was the output: """{content}"""\n\nWhat does this output mean (I can't understand it, please help) / what code needs to be run next (if anything, or are we done)? I can't replace any placeholders.'''
unishell.empty_code_output_template = "The code above was executed on my machine. It produced no text output. What's next (if anything, or are we done?)"
unishell.code_output_sender = "user"

# Computer settings
unishell.computer.import_computer_api = False

# Misc settings
unishell.auto_run = False
unishell.offline = True
