# pillfyi

Pill identification and FDA drug database API client — [pillfyi.com](https://pillfyi.com)

## Install

```bash
pip install pillfyi
```

## Quick Start

```python
from pillfyi.api import PillFYI

with PillFYI() as api:
    results = api.search("aspirin")
    print(results)
```

## License

MIT
