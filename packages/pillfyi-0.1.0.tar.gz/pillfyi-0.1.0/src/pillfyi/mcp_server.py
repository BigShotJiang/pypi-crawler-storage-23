"""MCP server for pillfyi."""

from __future__ import annotations

from typing import Any

from mcp.server.fastmcp import FastMCP

from pillfyi.api import PillFYI

mcp = FastMCP("pillfyi")


@mcp.tool()
def search_pillfyi(query: str) -> dict[str, Any]:
    """Search pillfyi.com for content matching the query."""
    with PillFYI() as api:
        return api.search(query)
