"""Command-line interface for pillfyi."""

from __future__ import annotations

import json

import typer

from pillfyi.api import PillFYI

app = typer.Typer(help="PillFYI — Pill identification and FDA drug database API client.")


@app.command()
def search(query: str) -> None:
    """Search pillfyi.com."""
    with PillFYI() as api:
        result = api.search(query)
        typer.echo(json.dumps(result, indent=2))
