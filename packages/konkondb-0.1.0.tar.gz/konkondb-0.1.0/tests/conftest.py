"""Shared test fixtures for konkon db."""
