# CHANGELOG

<!-- version list -->

## v0.1.0 (2026-02-27)

- Initial Release
