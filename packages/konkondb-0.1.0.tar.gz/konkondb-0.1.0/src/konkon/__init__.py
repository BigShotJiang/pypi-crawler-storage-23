"""konkon db — AI-oriented context DB middleware."""
