from .tal import TAL
from .tal import read_tal


__all__ = ["TAL", "read_tal"]