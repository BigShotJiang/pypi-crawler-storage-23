from .fractal import Fractal


__all__ = ['Fractal']