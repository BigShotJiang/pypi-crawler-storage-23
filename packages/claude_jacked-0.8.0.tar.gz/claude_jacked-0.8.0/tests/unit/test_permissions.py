"""Tests for jacked.api.routes.permissions module."""

import json
from pathlib import Path
from unittest.mock import MagicMock

from jacked.api.routes.permissions import (
    _read_project_settings,
    _validate_repo_path,
    _write_project_settings,
)


class TestValidateRepoPath:
    def test_rejects_none(self):
        assert _validate_repo_path(None) is None

    def test_rejects_empty(self):
        assert _validate_repo_path("") is None

    def test_rejects_root(self):
        assert _validate_repo_path("/") is None

    def test_rejects_home(self):
        assert _validate_repo_path(str(Path.home())) is None

    def test_rejects_non_dir(self, tmp_path):
        f = tmp_path / "file.txt"
        f.write_text("x")
        assert _validate_repo_path(str(f)) is None

    def test_rejects_non_git_dir(self, tmp_path):
        assert _validate_repo_path(str(tmp_path)) is None

    def test_accepts_git_dir_no_db(self, tmp_path):
        (tmp_path / ".git").mkdir()
        assert _validate_repo_path(str(tmp_path)) == tmp_path

    def test_rejects_unknown_project_with_db(self, tmp_path):
        """DB check rejects git dirs not known to jacked."""
        (tmp_path / ".git").mkdir()
        mock_db = MagicMock()
        mock_db.get_project_activity_summary.return_value = []
        assert _validate_repo_path(str(tmp_path), db=mock_db) is None

    def test_accepts_known_project_with_db(self, tmp_path):
        """DB check passes for projects with jacked activity."""
        (tmp_path / ".git").mkdir()
        mock_db = MagicMock()
        mock_db.get_project_activity_summary.return_value = [
            {"repo_path": str(tmp_path)}
        ]
        assert _validate_repo_path(str(tmp_path), db=mock_db) == tmp_path

    def test_fails_closed_on_db_error(self, tmp_path):
        """DB errors reject (fail closed)."""
        (tmp_path / ".git").mkdir()
        mock_db = MagicMock()
        mock_db.get_project_activity_summary.side_effect = Exception("DB down")
        assert _validate_repo_path(str(tmp_path), db=mock_db) is None


class TestProjectSettings:
    def test_read_missing_file(self, tmp_path):
        result = _read_project_settings(str(tmp_path))
        assert result == {}

    def test_write_and_read_back(self, tmp_path):
        _write_project_settings(
            str(tmp_path), {"permissions": {"allow": ["Bash(curl:*)"]}}
        )
        result = _read_project_settings(str(tmp_path))
        assert result["permissions"]["allow"] == ["Bash(curl:*)"]

    def test_corrupt_json_returns_empty(self, tmp_path):
        claude_dir = tmp_path / ".claude"
        claude_dir.mkdir()
        (claude_dir / "settings.local.json").write_text("not json")
        assert _read_project_settings(str(tmp_path)) == {}

    def test_write_creates_claude_dir(self, tmp_path):
        _write_project_settings(str(tmp_path), {"test": True})
        assert (tmp_path / ".claude" / "settings.local.json").exists()

    def test_atomic_write(self, tmp_path):
        """No .json.tmp left behind after write."""
        _write_project_settings(str(tmp_path), {"test": True})
        assert not (tmp_path / ".claude" / "settings.local.json.tmp").exists()
