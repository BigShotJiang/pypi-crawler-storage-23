from jinns.plot._plot import (
    plot2d,
    plot1d_slice,
    plot1d_image,
)

__all__ = ["plot2d", "plot1d_slice", "plot1d_image"]
