"""
Pydantic models for FABRIC MCP Server.
"""
