"""FABRIC MCP Server — exposes FABRIC API operations as LLM-accessible tools."""

__version__ = "0.0.1"
