"""Coil: A Python-to-executable compiler that just works."""

__version__ = "0.1.0"
