"""Allow running Coil with python -m coil."""

from coil.cli import main

main()
