"""Tests for platform_audit_notify.pnotify — Discord webhook client."""

import io
import json
import unittest
from copy import deepcopy
from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

from src.platform_audit_notify.pnotify import (
    DISCORD_API_BASE,
    DiscordEmbed,
    DiscordWebhook,
    notify_audit_result,
    notify_with_embed,
    notify_with_file,
)


def _ok_response(body=None, status=200):
    """Return a mock utils.Response that looks successful."""
    r = MagicMock()
    r.status_code = status
    r.ok = 200 <= status < 300
    r.json.return_value = body or {}
    r.text = json.dumps(body or {})
    return r


# ---------------------------------------------------------------------------
# DiscordEmbed
# ---------------------------------------------------------------------------
class TestDiscordEmbed(unittest.TestCase):
    # -- construction -------------------------------------------------------
    def test_empty_embed(self):
        e = DiscordEmbed()
        d = e.to_dict()
        self.assertEqual(d, {})  # no fields key when empty

    def test_full_constructor(self):
        ts = datetime(2025, 1, 1, tzinfo=timezone.utc)
        e = DiscordEmbed(
            title="T", description="D", url="https://x.com",
            color="#ff0000", timestamp=ts,
        )
        d = e.to_dict()
        self.assertEqual(d["title"], "T")
        self.assertEqual(d["description"], "D")
        self.assertEqual(d["url"], "https://x.com")
        self.assertEqual(d["color"], 0xFF0000)
        self.assertEqual(d["timestamp"], ts.isoformat())

    # -- _parse_color -------------------------------------------------------
    def test_parse_color_hex_string(self):
        self.assertEqual(DiscordEmbed._parse_color("#03b2f8"), 0x03B2F8)

    def test_parse_color_hex_no_hash(self):
        self.assertEqual(DiscordEmbed._parse_color("ff0000"), 0xFF0000)

    def test_parse_color_int(self):
        self.assertEqual(DiscordEmbed._parse_color(255), 255)

    # -- _fmt_timestamp -----------------------------------------------------
    def test_fmt_timestamp_string_passthrough(self):
        self.assertEqual(DiscordEmbed._fmt_timestamp("2025-01-01T00:00:00"), "2025-01-01T00:00:00")

    def test_fmt_timestamp_datetime(self):
        dt = datetime(2025, 6, 15, 12, 0, tzinfo=timezone.utc)
        self.assertEqual(DiscordEmbed._fmt_timestamp(dt), dt.isoformat())

    def test_fmt_timestamp_other(self):
        self.assertEqual(DiscordEmbed._fmt_timestamp(12345), "12345")

    # -- setters (all return self for chaining) -----------------------------
    def test_set_title(self):
        e = DiscordEmbed()
        ret = e.set_title("Hello")
        self.assertIs(ret, e)
        self.assertEqual(e.to_dict()["title"], "Hello")

    def test_set_description(self):
        e = DiscordEmbed().set_description("desc")
        self.assertEqual(e.to_dict()["description"], "desc")

    def test_set_url(self):
        e = DiscordEmbed().set_url("https://x.com")
        self.assertEqual(e.to_dict()["url"], "https://x.com")

    def test_set_color(self):
        e = DiscordEmbed().set_color("#00ff00")
        self.assertEqual(e.to_dict()["color"], 0x00FF00)

    def test_set_colour_alias(self):
        e = DiscordEmbed().set_colour(123)
        self.assertEqual(e.to_dict()["color"], 123)

    def test_set_timestamp_default_utc(self):
        e = DiscordEmbed().set_timestamp()
        ts_str = e.to_dict()["timestamp"]
        # Should be a valid ISO timestamp
        parsed = datetime.fromisoformat(ts_str)
        self.assertIsNotNone(parsed)

    def test_set_timestamp_explicit(self):
        dt = datetime(2025, 3, 1, tzinfo=timezone.utc)
        e = DiscordEmbed().set_timestamp(dt)
        self.assertEqual(e.to_dict()["timestamp"], dt.isoformat())

    def test_set_author_minimal(self):
        e = DiscordEmbed().set_author("Bob")
        self.assertEqual(e.to_dict()["author"], {"name": "Bob"})

    def test_set_author_full(self):
        e = DiscordEmbed().set_author("Bob", url="https://bob.dev", icon_url="https://bob.dev/avatar.png")
        author = e.to_dict()["author"]
        self.assertEqual(author["name"], "Bob")
        self.assertEqual(author["url"], "https://bob.dev")
        self.assertEqual(author["icon_url"], "https://bob.dev/avatar.png")

    def test_set_thumbnail(self):
        e = DiscordEmbed().set_thumbnail("https://img.png")
        self.assertEqual(e.to_dict()["thumbnail"], {"url": "https://img.png"})

    def test_set_image(self):
        e = DiscordEmbed().set_image("https://img.png")
        self.assertEqual(e.to_dict()["image"], {"url": "https://img.png"})

    def test_set_footer_text_only(self):
        e = DiscordEmbed().set_footer("foot")
        self.assertEqual(e.to_dict()["footer"], {"text": "foot"})

    def test_set_footer_with_icon(self):
        e = DiscordEmbed().set_footer("foot", icon_url="https://ico.png")
        self.assertEqual(e.to_dict()["footer"]["icon_url"], "https://ico.png")

    # -- fields -------------------------------------------------------------
    def test_add_field(self):
        e = DiscordEmbed().add_field("k", "v", inline=True)
        d = e.to_dict()
        self.assertEqual(len(d["fields"]), 1)
        self.assertEqual(d["fields"][0], {"name": "k", "value": "v", "inline": True})

    def test_add_multiple_fields(self):
        e = DiscordEmbed().add_field("a", "1").add_field("b", "2")
        self.assertEqual(len(e.to_dict()["fields"]), 2)

    def test_del_field(self):
        e = DiscordEmbed().add_field("a", "1").add_field("b", "2")
        e.del_field(0)
        d = e.to_dict()
        self.assertEqual(len(d["fields"]), 1)
        self.assertEqual(d["fields"][0]["name"], "b")

    def test_del_field_returns_self(self):
        e = DiscordEmbed().add_field("a", "1")
        self.assertIs(e.del_field(0), e)

    # -- to_dict ------------------------------------------------------------
    def test_to_dict_is_deep_copy(self):
        e = DiscordEmbed(title="T").add_field("k", "v")
        d1 = e.to_dict()
        d1["title"] = "CHANGED"
        d1["fields"][0]["name"] = "CHANGED"
        d2 = e.to_dict()
        self.assertEqual(d2["title"], "T")
        self.assertEqual(d2["fields"][0]["name"], "k")

    def test_to_dict_omits_empty_fields(self):
        e = DiscordEmbed(title="T")
        self.assertNotIn("fields", e.to_dict())

    # -- chaining -----------------------------------------------------------
    def test_full_chaining(self):
        e = (
            DiscordEmbed()
            .set_title("T")
            .set_description("D")
            .set_url("https://x.com")
            .set_color("#ffffff")
            .set_timestamp()
            .set_author("A")
            .set_thumbnail("https://t.png")
            .set_image("https://i.png")
            .set_footer("F")
            .add_field("k", "v")
        )
        d = e.to_dict()
        self.assertEqual(d["title"], "T")
        self.assertEqual(len(d["fields"]), 1)


# ---------------------------------------------------------------------------
# DiscordWebhook
# ---------------------------------------------------------------------------
class TestDiscordWebhook(unittest.TestCase):
    URL = "https://discord.com/api/webhooks/123/abc"

    # -- construction -------------------------------------------------------
    def test_defaults(self):
        wh = DiscordWebhook(url=self.URL)
        self.assertEqual(wh.url, self.URL)
        self.assertIsNone(wh.content)
        self.assertIsNone(wh.username)
        self.assertFalse(wh.tts)
        self.assertEqual(wh.embeds, [])
        self.assertEqual(wh.files, {})
        self.assertTrue(wh.rate_limit_retry)
        self.assertEqual(wh.timeout, 10)
        self.assertIsNone(wh.message_id)

    # -- _build_payload -----------------------------------------------------
    def test_payload_content_only(self):
        wh = DiscordWebhook(url=self.URL, content="hi")
        p = wh._build_payload()
        self.assertEqual(p, {"content": "hi"})

    def test_payload_all_fields(self):
        embed = DiscordEmbed(title="T")
        wh = DiscordWebhook(
            url=self.URL, content="hi", username="bot",
            avatar_url="https://av.png", tts=True,
            embeds=[embed], allowed_mentions={"parse": []},
            thread_name="thread",
        )
        p = wh._build_payload()
        self.assertEqual(p["content"], "hi")
        self.assertEqual(p["username"], "bot")
        self.assertEqual(p["avatar_url"], "https://av.png")
        self.assertTrue(p["tts"])
        self.assertEqual(len(p["embeds"]), 1)
        self.assertEqual(p["allowed_mentions"], {"parse": []})
        self.assertEqual(p["thread_name"], "thread")

    def test_payload_embed_as_dict(self):
        wh = DiscordWebhook(url=self.URL, embeds=[{"title": "raw"}])
        p = wh._build_payload()
        self.assertEqual(p["embeds"][0], {"title": "raw"})

    # -- _build_params ------------------------------------------------------
    def test_params_default(self):
        wh = DiscordWebhook(url=self.URL)
        self.assertEqual(wh._build_params(), {"wait": "true"})

    def test_params_no_wait(self):
        wh = DiscordWebhook(url=self.URL)
        self.assertIsNone(wh._build_params(wait=False))

    def test_params_with_thread_id(self):
        wh = DiscordWebhook(url=self.URL, thread_id="999")
        p = wh._build_params()
        self.assertEqual(p["thread_id"], "999")

    # -- _handle_rate_limit -------------------------------------------------
    @patch("src.platform_audit_notify.pnotify.time.sleep")
    def test_rate_limit_retries(self, mock_sleep):
        wh = DiscordWebhook(url=self.URL)
        resp = MagicMock()
        resp.status_code = 429
        resp.json.return_value = {"retry_after": 2.5}

        result = wh._handle_rate_limit(resp)
        self.assertTrue(result)
        mock_sleep.assert_called_once_with(2.5)

    def test_rate_limit_disabled(self):
        wh = DiscordWebhook(url=self.URL, rate_limit_retry=False)
        resp = MagicMock()
        resp.status_code = 429
        self.assertFalse(wh._handle_rate_limit(resp))

    def test_rate_limit_non_429(self):
        wh = DiscordWebhook(url=self.URL)
        resp = MagicMock()
        resp.status_code = 200
        self.assertFalse(wh._handle_rate_limit(resp))

    # -- add_embed / remove_embed -------------------------------------------
    def test_add_embed(self):
        wh = DiscordWebhook(url=self.URL)
        embed = DiscordEmbed(title="T")
        ret = wh.add_embed(embed)
        self.assertIs(ret, wh)
        self.assertEqual(len(wh.embeds), 1)

    def test_remove_embed(self):
        wh = DiscordWebhook(url=self.URL)
        wh.add_embed(DiscordEmbed(title="A"))
        wh.add_embed(DiscordEmbed(title="B"))
        ret = wh.remove_embed(0)
        self.assertIs(ret, wh)
        self.assertEqual(len(wh.embeds), 1)

    # -- add_file / remove_file ---------------------------------------------
    def test_add_file_bytes(self):
        wh = DiscordWebhook(url=self.URL)
        ret = wh.add_file(b"data", "f.bin")
        self.assertIs(ret, wh)
        self.assertIn("f.bin", wh.files)
        self.assertEqual(wh.files["f.bin"][1], b"data")

    def test_add_file_str(self):
        wh = DiscordWebhook(url=self.URL)
        wh.add_file("text content", "f.txt")
        self.assertEqual(wh.files["f.txt"][1], b"text content")

    def test_add_file_filelike(self):
        wh = DiscordWebhook(url=self.URL)
        wh.add_file(io.BytesIO(b"stream"), "f.dat")
        self.assertEqual(wh.files["f.dat"][1], b"stream")

    def test_remove_file(self):
        wh = DiscordWebhook(url=self.URL)
        wh.add_file(b"x", "f.bin")
        ret = wh.remove_file("f.bin")
        self.assertIs(ret, wh)
        self.assertNotIn("f.bin", wh.files)

    def test_remove_file_nonexistent(self):
        wh = DiscordWebhook(url=self.URL)
        wh.remove_file("nope")  # should not raise

    # -- execute ------------------------------------------------------------
    @patch("src.platform_audit_utils.utils.urlopen")
    def test_execute_json(self, mock_urlopen):
        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.headers = {}
        mock_resp.read.return_value = json.dumps({"id": "111"}).encode()
        mock_resp.url = self.URL
        mock_resp.reason = "OK"
        mock_urlopen.return_value = mock_resp

        wh = DiscordWebhook(url=self.URL, content="hello")
        r = wh.execute()
        self.assertTrue(r.ok)
        self.assertEqual(wh.message_id, "111")

    @patch("src.platform_audit_utils.utils.urlopen")
    def test_execute_with_files(self, mock_urlopen):
        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.headers = {}
        mock_resp.read.return_value = json.dumps({"id": "222"}).encode()
        mock_resp.url = self.URL
        mock_resp.reason = "OK"
        mock_urlopen.return_value = mock_resp

        wh = DiscordWebhook(url=self.URL, content="file msg")
        wh.add_file(b"binary", "doc.pdf")
        r = wh.execute()
        self.assertTrue(r.ok)
        # Verify multipart was sent (payload_json in body)
        req_obj = mock_urlopen.call_args[0][0]
        self.assertIn(b"payload_json", req_obj.data)

    @patch("src.platform_audit_utils.utils.urlopen")
    @patch("src.platform_audit_notify.pnotify.time.sleep")
    def test_execute_rate_limit_then_success(self, mock_sleep, mock_urlopen):
        rate_limited = MagicMock()
        rate_limited.status = 429
        rate_limited.headers = {}
        rate_limited.read.return_value = json.dumps({"retry_after": 1}).encode()
        rate_limited.url = self.URL
        rate_limited.reason = "Too Many Requests"

        success = MagicMock()
        success.status = 200
        success.headers = {}
        success.read.return_value = json.dumps({"id": "333"}).encode()
        success.url = self.URL
        success.reason = "OK"

        # Raise HTTPError first to simulate 429, then succeed
        from urllib.error import HTTPError as ULE_HTTPError
        mock_urlopen.side_effect = [
            ULE_HTTPError(self.URL, 429, "Too Many Requests", {},
                          io.BytesIO(json.dumps({"retry_after": 1}).encode())),
            success,
        ]

        wh = DiscordWebhook(url=self.URL, content="retry me")
        r = wh.execute()
        self.assertTrue(r.ok)
        mock_sleep.assert_called_once_with(1)

    @patch("src.platform_audit_utils.utils.urlopen")
    def test_execute_error_no_message_id(self, mock_urlopen):
        from urllib.error import HTTPError as ULE_HTTPError
        mock_urlopen.side_effect = ULE_HTTPError(
            self.URL, 400, "Bad Request", {},
            io.BytesIO(b'{"message":"invalid"}'),
        )

        wh = DiscordWebhook(url=self.URL, content="bad")
        r = wh.execute()
        self.assertFalse(r.ok)
        self.assertIsNone(wh.message_id)

    # -- edit ---------------------------------------------------------------
    @patch("src.platform_audit_utils.utils.urlopen")
    def test_edit(self, mock_urlopen):
        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.headers = {}
        mock_resp.read.return_value = b"{}"
        mock_resp.url = self.URL
        mock_resp.reason = "OK"
        mock_urlopen.return_value = mock_resp

        wh = DiscordWebhook(url=self.URL)
        wh.message_id = "444"
        r = wh.edit(content="updated")
        self.assertTrue(r.ok)
        req_obj = mock_urlopen.call_args[0][0]
        self.assertEqual(req_obj.method, "PATCH")
        self.assertIn(b"updated", req_obj.data)

    def test_edit_no_message_id_raises(self):
        wh = DiscordWebhook(url=self.URL)
        with self.assertRaises(ValueError, msg="No message to edit"):
            wh.edit(content="x")

    @patch("src.platform_audit_utils.utils.urlopen")
    def test_edit_with_embeds(self, mock_urlopen):
        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.headers = {}
        mock_resp.read.return_value = b"{}"
        mock_resp.url = self.URL
        mock_resp.reason = "OK"
        mock_urlopen.return_value = mock_resp

        wh = DiscordWebhook(url=self.URL)
        wh.message_id = "555"
        embed = DiscordEmbed(title="New")
        wh.edit(embeds=[embed])
        req_obj = mock_urlopen.call_args[0][0]
        payload = json.loads(req_obj.data)
        self.assertEqual(payload["embeds"][0]["title"], "New")

    # -- delete -------------------------------------------------------------
    @patch("src.platform_audit_utils.utils.urlopen")
    def test_delete(self, mock_urlopen):
        mock_resp = MagicMock()
        mock_resp.status = 204
        mock_resp.headers = {}
        mock_resp.read.return_value = b""
        mock_resp.url = self.URL
        mock_resp.reason = "No Content"
        mock_urlopen.return_value = mock_resp

        wh = DiscordWebhook(url=self.URL)
        wh.message_id = "666"
        r = wh.delete()
        req_obj = mock_urlopen.call_args[0][0]
        self.assertEqual(req_obj.method, "DELETE")
        self.assertIn("/messages/666", req_obj.full_url)

    def test_delete_no_message_id_raises(self):
        wh = DiscordWebhook(url=self.URL)
        with self.assertRaises(ValueError, msg="No message to delete"):
            wh.delete()


# ---------------------------------------------------------------------------
# Convenience functions
# ---------------------------------------------------------------------------
class TestNotifyAuditResult(unittest.TestCase):
    @patch("src.platform_audit_utils.utils.urlopen")
    def test_pass(self, mock_urlopen):
        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.headers = {}
        mock_resp.read.return_value = json.dumps({"id": "1"}).encode()
        mock_resp.url = "u"
        mock_resp.reason = "OK"
        mock_urlopen.return_value = mock_resp

        r = notify_audit_result(True, "WH_ID", "TOKEN", message="all good")
        self.assertTrue(r.ok)
        req_obj = mock_urlopen.call_args[0][0]
        payload = json.loads(req_obj.data)
        self.assertTrue(payload["content"].startswith("[PASS]"))
        self.assertIn("all good", payload["content"])
        self.assertIn("/webhooks/WH_ID/TOKEN", req_obj.full_url)

    @patch("src.platform_audit_utils.utils.urlopen")
    def test_fail(self, mock_urlopen):
        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.headers = {}
        mock_resp.read.return_value = json.dumps({"id": "2"}).encode()
        mock_resp.url = "u"
        mock_resp.reason = "OK"
        mock_urlopen.return_value = mock_resp

        r = notify_audit_result(False, "WH_ID", "TOKEN")
        req_obj = mock_urlopen.call_args[0][0]
        payload = json.loads(req_obj.data)
        self.assertTrue(payload["content"].startswith("[FAIL]"))

    @patch("src.platform_audit_utils.utils.urlopen")
    def test_default_message(self, mock_urlopen):
        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.headers = {}
        mock_resp.read.return_value = json.dumps({"id": "3"}).encode()
        mock_resp.url = "u"
        mock_resp.reason = "OK"
        mock_urlopen.return_value = mock_resp

        notify_audit_result(True, "WH", "TK")
        req_obj = mock_urlopen.call_args[0][0]
        payload = json.loads(req_obj.data)
        self.assertIn("Success", payload["content"])


class TestNotifyWithEmbed(unittest.TestCase):
    @patch("src.platform_audit_utils.utils.urlopen")
    def test_basic_embed(self, mock_urlopen):
        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.headers = {}
        mock_resp.read.return_value = json.dumps({"id": "10"}).encode()
        mock_resp.url = "u"
        mock_resp.reason = "OK"
        mock_urlopen.return_value = mock_resp

        r = notify_with_embed("WH", "TK", "Title", "Desc", color="#ff0000")
        self.assertTrue(r.ok)
        req_obj = mock_urlopen.call_args[0][0]
        payload = json.loads(req_obj.data)
        embed = payload["embeds"][0]
        self.assertEqual(embed["title"], "Title")
        self.assertEqual(embed["description"], "Desc")
        self.assertEqual(embed["color"], 0xFF0000)

    @patch("src.platform_audit_utils.utils.urlopen")
    def test_embed_with_fields_and_footer(self, mock_urlopen):
        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.headers = {}
        mock_resp.read.return_value = json.dumps({"id": "11"}).encode()
        mock_resp.url = "u"
        mock_resp.reason = "OK"
        mock_urlopen.return_value = mock_resp

        fields = [
            {"name": "F1", "value": "V1", "inline": True},
            {"name": "F2", "value": "V2"},
        ]
        notify_with_embed("WH", "TK", "T", "D", fields=fields, footer="foot")
        req_obj = mock_urlopen.call_args[0][0]
        payload = json.loads(req_obj.data)
        embed = payload["embeds"][0]
        self.assertEqual(len(embed["fields"]), 2)
        self.assertTrue(embed["fields"][0]["inline"])
        self.assertFalse(embed["fields"][1]["inline"])
        self.assertEqual(embed["footer"]["text"], "foot")

    @patch("src.platform_audit_utils.utils.urlopen")
    def test_embed_with_timestamp_true(self, mock_urlopen):
        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.headers = {}
        mock_resp.read.return_value = json.dumps({"id": "12"}).encode()
        mock_resp.url = "u"
        mock_resp.reason = "OK"
        mock_urlopen.return_value = mock_resp

        notify_with_embed("WH", "TK", "T", "D", timestamp=True)
        req_obj = mock_urlopen.call_args[0][0]
        payload = json.loads(req_obj.data)
        self.assertIn("timestamp", payload["embeds"][0])

    @patch("src.platform_audit_utils.utils.urlopen")
    def test_embed_with_timestamp_datetime(self, mock_urlopen):
        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.headers = {}
        mock_resp.read.return_value = json.dumps({"id": "13"}).encode()
        mock_resp.url = "u"
        mock_resp.reason = "OK"
        mock_urlopen.return_value = mock_resp

        dt = datetime(2025, 6, 1, tzinfo=timezone.utc)
        notify_with_embed("WH", "TK", "T", "D", timestamp=dt)
        req_obj = mock_urlopen.call_args[0][0]
        payload = json.loads(req_obj.data)
        self.assertEqual(payload["embeds"][0]["timestamp"], dt.isoformat())


class TestNotifyWithFile(unittest.TestCase):
    @patch("src.platform_audit_utils.utils.urlopen")
    def test_file_bytes(self, mock_urlopen):
        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.headers = {}
        mock_resp.read.return_value = json.dumps({"id": "20"}).encode()
        mock_resp.url = "u"
        mock_resp.reason = "OK"
        mock_urlopen.return_value = mock_resp

        r = notify_with_file("WH", "TK", b"pdf-bytes", "report.pdf", content="See attached")
        self.assertTrue(r.ok)
        req_obj = mock_urlopen.call_args[0][0]
        # Should be multipart (has files)
        self.assertIn(b"report.pdf", req_obj.data)
        self.assertIn(b"See attached", req_obj.data)

    @patch("src.platform_audit_utils.utils.urlopen")
    def test_file_no_content(self, mock_urlopen):
        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.headers = {}
        mock_resp.read.return_value = json.dumps({"id": "21"}).encode()
        mock_resp.url = "u"
        mock_resp.reason = "OK"
        mock_urlopen.return_value = mock_resp

        r = notify_with_file("WH", "TK", b"data", "f.txt")
        self.assertTrue(r.ok)


if __name__ == "__main__":
    unittest.main()
