"""Tests for platform_audit_utils.utils — lightweight HTTP client."""

import io
import json
import unittest
from unittest.mock import MagicMock, patch
from urllib.error import HTTPError, URLError

from src.platform_audit_utils.utils import (
    Response,
    Session,
    _build_url,
    _encode_body,
    delete,
    get,
    head,
    options,
    patch as http_patch,
    post,
    put,
    request,
)


# ---------------------------------------------------------------------------
# Response
# ---------------------------------------------------------------------------
class TestResponse(unittest.TestCase):
    def _make_http_response(self, status=200, headers=None, body=b"",
                            url="https://example.com", reason="OK"):
        resp = MagicMock()
        resp.status = status
        resp.headers = headers or {"Content-Type": "application/json; charset=utf-8"}
        resp.read.return_value = body
        resp.url = url
        resp.reason = reason
        return resp

    def test_success_response(self):
        raw = self._make_http_response(
            body=json.dumps({"ok": True}).encode()
        )
        r = Response(http_response=raw)
        self.assertEqual(r.status_code, 200)
        self.assertTrue(r.ok)
        self.assertEqual(r.url, "https://example.com")
        self.assertEqual(r.reason, "OK")
        self.assertEqual(r.json(), {"ok": True})
        self.assertIsInstance(r.content, bytes)
        self.assertIsInstance(r.text, str)
        self.assertEqual(r.encoding, "utf-8")

    def test_error_response(self):
        err = HTTPError(
            "https://example.com/fail", 404, "Not Found",
            {"Content-Type": "text/plain"}, io.BytesIO(b"gone"),
        )
        r = Response(error=err)
        self.assertEqual(r.status_code, 404)
        self.assertFalse(r.ok)
        self.assertEqual(r.text, "gone")

    def test_raise_for_status_ok(self):
        raw = self._make_http_response()
        r = Response(http_response=raw)
        r.raise_for_status()  # should not raise

    def test_raise_for_status_error(self):
        err = HTTPError("u", 500, "ISE", {}, io.BytesIO(b""))
        r = Response(error=err)
        with self.assertRaises(HTTPError):
            r.raise_for_status()

    def test_repr(self):
        raw = self._make_http_response(status=201)
        r = Response(http_response=raw)
        self.assertEqual(repr(r), "<Response [201]>")

    def test_guess_encoding_default(self):
        raw = self._make_http_response(headers={"Content-Type": "text/html"})
        r = Response(http_response=raw)
        self.assertEqual(r.encoding, "utf-8")

    def test_guess_encoding_explicit(self):
        raw = self._make_http_response(
            headers={"Content-Type": "text/html; charset=iso-8859-1"}
        )
        r = Response(http_response=raw)
        self.assertEqual(r.encoding, "iso-8859-1")

    def test_error_without_standard_attrs(self):
        """URLError-like objects that lack .code, .headers, etc."""
        class BareError:
            reason = "connection refused"
        err = BareError()
        r = Response(error=err)
        self.assertIsNone(r.status_code)
        self.assertFalse(r.ok)


# ---------------------------------------------------------------------------
# _build_url
# ---------------------------------------------------------------------------
class TestBuildUrl(unittest.TestCase):
    def test_no_params(self):
        self.assertEqual(_build_url("https://a.com/p"), "https://a.com/p")

    def test_dict_params(self):
        url = _build_url("https://a.com/p", {"foo": "1", "bar": "2"})
        self.assertIn("foo=1", url)
        self.assertIn("bar=2", url)

    def test_merge_existing_query(self):
        url = _build_url("https://a.com/p?x=0", {"y": "1"})
        self.assertIn("x=0", url)
        self.assertIn("y=1", url)

    def test_list_params(self):
        url = _build_url("https://a.com", [("k", "v1"), ("k", "v2")])
        self.assertIn("k=v1", url)
        self.assertIn("k=v2", url)


# ---------------------------------------------------------------------------
# _encode_body
# ---------------------------------------------------------------------------
class TestEncodeBody(unittest.TestCase):
    def test_json_body(self):
        body, ct = _encode_body(json_body={"a": 1})
        self.assertEqual(ct, "application/json")
        self.assertEqual(json.loads(body), {"a": 1})

    def test_files(self):
        files = {"file1": ("name.txt", b"hello", "text/plain")}
        body, ct = _encode_body(files=files)
        self.assertIn("multipart/form-data", ct)
        self.assertIn(b"hello", body)
        self.assertIn(b"name.txt", body)

    def test_files_with_form_data(self):
        body, ct = _encode_body(
            data={"key": "val"},
            files={"f": ("f.bin", b"\x00", "application/octet-stream")},
        )
        self.assertIn(b"key", body)
        self.assertIn(b"val", body)

    def test_files_two_element_tuple(self):
        body, ct = _encode_body(files={"f": ("f.txt", b"data")})
        self.assertIn(b"data", body)

    def test_files_file_like_object(self):
        fobj = io.BytesIO(b"content")
        fobj.name = "stream.bin"
        body, ct = _encode_body(files={"f": fobj})
        self.assertIn(b"content", body)

    def test_data_dict(self):
        body, ct = _encode_body(data={"a": "b"})
        self.assertEqual(ct, "application/x-www-form-urlencoded")
        self.assertIn(b"a=b", body)

    def test_data_bytes(self):
        body, ct = _encode_body(data=b"raw")
        self.assertIsNone(ct)
        self.assertEqual(body, b"raw")

    def test_data_str(self):
        body, ct = _encode_body(data="raw")
        self.assertIsNone(ct)
        self.assertEqual(body, b"raw")

    def test_none(self):
        body, ct = _encode_body()
        self.assertIsNone(body)
        self.assertIsNone(ct)


# ---------------------------------------------------------------------------
# request() and convenience functions
# ---------------------------------------------------------------------------
class TestRequest(unittest.TestCase):
    @patch("src.platform_audit_utils.utils.urlopen")
    def test_get_request(self, mock_urlopen):
        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.headers = {}
        mock_resp.read.return_value = b'{"ok":true}'
        mock_resp.url = "https://example.com"
        mock_resp.reason = "OK"
        mock_urlopen.return_value = mock_resp

        r = get("https://example.com")
        self.assertTrue(r.ok)
        self.assertEqual(r.status_code, 200)

    @patch("src.platform_audit_utils.utils.urlopen")
    def test_post_json(self, mock_urlopen):
        mock_resp = MagicMock()
        mock_resp.status = 201
        mock_resp.headers = {}
        mock_resp.read.return_value = b""
        mock_resp.url = "https://example.com"
        mock_resp.reason = "Created"
        mock_urlopen.return_value = mock_resp

        r = post("https://example.com", json={"x": 1})
        self.assertEqual(r.status_code, 201)
        # Verify JSON content-type was set
        call_args = mock_urlopen.call_args
        req_obj = call_args[0][0]
        self.assertEqual(req_obj.get_header("Content-type"), "application/json")

    @patch("src.platform_audit_utils.utils.urlopen")
    def test_put(self, mock_urlopen):
        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.headers = {}
        mock_resp.read.return_value = b""
        mock_resp.url = "u"
        mock_resp.reason = "OK"
        mock_urlopen.return_value = mock_resp

        r = put("https://example.com", json={"a": 1})
        req_obj = mock_urlopen.call_args[0][0]
        self.assertEqual(req_obj.method, "PUT")

    @patch("src.platform_audit_utils.utils.urlopen")
    def test_patch(self, mock_urlopen):
        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.headers = {}
        mock_resp.read.return_value = b""
        mock_resp.url = "u"
        mock_resp.reason = "OK"
        mock_urlopen.return_value = mock_resp

        r = http_patch("https://example.com", json={"a": 1})
        req_obj = mock_urlopen.call_args[0][0]
        self.assertEqual(req_obj.method, "PATCH")

    @patch("src.platform_audit_utils.utils.urlopen")
    def test_delete(self, mock_urlopen):
        mock_resp = MagicMock()
        mock_resp.status = 204
        mock_resp.headers = {}
        mock_resp.read.return_value = b""
        mock_resp.url = "u"
        mock_resp.reason = "No Content"
        mock_urlopen.return_value = mock_resp

        r = delete("https://example.com")
        req_obj = mock_urlopen.call_args[0][0]
        self.assertEqual(req_obj.method, "DELETE")

    @patch("src.platform_audit_utils.utils.urlopen")
    def test_head(self, mock_urlopen):
        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.headers = {}
        mock_resp.read.return_value = b""
        mock_resp.url = "u"
        mock_resp.reason = "OK"
        mock_urlopen.return_value = mock_resp

        r = head("https://example.com")
        req_obj = mock_urlopen.call_args[0][0]
        self.assertEqual(req_obj.method, "HEAD")

    @patch("src.platform_audit_utils.utils.urlopen")
    def test_options(self, mock_urlopen):
        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.headers = {}
        mock_resp.read.return_value = b""
        mock_resp.url = "u"
        mock_resp.reason = "OK"
        mock_urlopen.return_value = mock_resp

        r = options("https://example.com")
        req_obj = mock_urlopen.call_args[0][0]
        self.assertEqual(req_obj.method, "OPTIONS")

    @patch("src.platform_audit_utils.utils.urlopen")
    def test_http_error_returns_response(self, mock_urlopen):
        mock_urlopen.side_effect = HTTPError(
            "https://example.com", 400, "Bad Request",
            {"Content-Type": "text/plain"}, io.BytesIO(b"bad"),
        )
        r = get("https://example.com")
        self.assertFalse(r.ok)
        self.assertEqual(r.status_code, 400)

    @patch("src.platform_audit_utils.utils.urlopen")
    def test_url_error_raises(self, mock_urlopen):
        mock_urlopen.side_effect = URLError("no host")
        with self.assertRaises(ConnectionError):
            get("https://nonexistent.invalid")

    @patch("src.platform_audit_utils.utils.urlopen")
    def test_basic_auth_header(self, mock_urlopen):
        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.headers = {}
        mock_resp.read.return_value = b""
        mock_resp.url = "u"
        mock_resp.reason = "OK"
        mock_urlopen.return_value = mock_resp

        get("https://example.com", auth=("user", "pass"))
        req_obj = mock_urlopen.call_args[0][0]
        self.assertIn("Basic", req_obj.get_header("Authorization"))

    @patch("src.platform_audit_utils.utils.urlopen")
    def test_cookies_header(self, mock_urlopen):
        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.headers = {}
        mock_resp.read.return_value = b""
        mock_resp.url = "u"
        mock_resp.reason = "OK"
        mock_urlopen.return_value = mock_resp

        get("https://example.com", cookies={"sid": "abc"})
        req_obj = mock_urlopen.call_args[0][0]
        self.assertIn("sid=abc", req_obj.get_header("Cookie"))

    @patch("src.platform_audit_utils.utils.urlopen")
    def test_ssl_verify_false(self, mock_urlopen):
        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.headers = {}
        mock_resp.read.return_value = b""
        mock_resp.url = "u"
        mock_resp.reason = "OK"
        mock_urlopen.return_value = mock_resp

        get("https://example.com", verify=False)
        call_kwargs = mock_urlopen.call_args[1]
        self.assertIsNotNone(call_kwargs.get("context"))


# ---------------------------------------------------------------------------
# Session
# ---------------------------------------------------------------------------
class TestSession(unittest.TestCase):
    @patch("src.platform_audit_utils.utils.urlopen")
    def test_session_persists_headers(self, mock_urlopen):
        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.headers = {}
        mock_resp.read.return_value = b""
        mock_resp.url = "u"
        mock_resp.reason = "OK"
        mock_urlopen.return_value = mock_resp

        with Session() as s:
            s.headers["X-Custom"] = "val"
            s.get("https://example.com")

        req_obj = mock_urlopen.call_args[0][0]
        self.assertEqual(req_obj.get_header("X-custom"), "val")

    @patch("src.platform_audit_utils.utils.urlopen")
    def test_session_persists_cookies(self, mock_urlopen):
        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.headers = {"Set-Cookie": "token=xyz; Path=/"}
        mock_resp.read.return_value = b""
        mock_resp.url = "u"
        mock_resp.reason = "OK"
        mock_urlopen.return_value = mock_resp

        s = Session()
        s.get("https://example.com")
        self.assertEqual(s.cookies.get("token"), "xyz")

    @patch("src.platform_audit_utils.utils.urlopen")
    def test_session_merges_params(self, mock_urlopen):
        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.headers = {}
        mock_resp.read.return_value = b""
        mock_resp.url = "u"
        mock_resp.reason = "OK"
        mock_urlopen.return_value = mock_resp

        s = Session()
        s.params = {"global": "1"}
        s.get("https://example.com", params={"local": "2"})

        req_url = mock_urlopen.call_args[0][0].full_url
        self.assertIn("global=1", req_url)
        self.assertIn("local=2", req_url)

    @patch("src.platform_audit_utils.utils.urlopen")
    def test_session_all_methods(self, mock_urlopen):
        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.headers = {}
        mock_resp.read.return_value = b""
        mock_resp.url = "u"
        mock_resp.reason = "OK"
        mock_urlopen.return_value = mock_resp

        s = Session()
        for method in ("get", "post", "put", "patch", "delete", "head", "options"):
            getattr(s, method)("https://example.com")

    def test_context_manager(self):
        with Session() as s:
            self.assertIsInstance(s, Session)


if __name__ == "__main__":
    unittest.main()
