from __future__ import annotations

from radiate.radiate import PyEcosystem
from radiate._bridge.wrapper import RsObject

from .species import Species
from .population import Population


class Ecosystem[T](RsObject):
    def __init__(self, inner: PyEcosystem):
        super().__init__()

        if isinstance(inner, PyEcosystem):
            self._pyobj = inner
        else:
            raise TypeError(f"Expected PyEcosystem, got {type(inner)}")

    def __repr__(self):
        return self.__backend__().__repr__()

    def population(self) -> Population[T]:
        return self.try_get_cache(
            "population_cache",
            lambda: Population.from_rust(self.__backend__().population),
        )

    def species(self) -> list[Species[T]]:
        return self.try_get_cache(
            "species_cache",
            lambda: [Species.from_rust(s) for s in self.__backend__().species],
        )
