pub use radiate_error::*;

pub type RadiateResult<T> = Result<T>;
