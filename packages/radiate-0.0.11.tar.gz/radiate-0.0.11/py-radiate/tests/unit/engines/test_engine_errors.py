import radiate as rd
import pytest


@pytest.mark.unit
def test_engine_empty_population():
    """Test engine handles empty population gracefully."""

    def fitness_func(x: list[int]) -> float:
        return sum(x)

    with pytest.raises(ValueError):
        engine = rd.Engine(
            codec=rd.IntCodec.vector(length=3, init_range=(0, 10)),
            fitness_func=fitness_func,
            objective=rd.MIN,
            population_size=0,  # Invalid
        )
        engine.run(rd.GenerationsLimit(10))


@pytest.mark.unit
def test_engine_invalid_limits():
    """Test engine handles invalid limits gracefully."""

    def fitness_func(x: list[int]) -> float:
        return sum(x)

    engine = rd.Engine(
        codec=rd.IntCodec.vector(length=3, init_range=(0, 10)),
        fitness_func=fitness_func,
        objective=rd.MIN,
    )

    with pytest.raises(ValueError):
        engine.run(rd.GenerationsLimit(-1))  # Invalid limit
