import argparse
import ipaddress
import logging
from collections import defaultdict
import zenoh
import time


def get_parser():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description="Zenoh scout to find all hero peers broadcasting hello messages.")
    parser.add_argument(
        "--duration", type=int, default=10, help="Duration in seconds to scout for hellos (default: 10)"
    )
    parser.add_argument(
        "--subnet",
        type=str,
        nargs="+",
        default=["192.168.0.0/16"],
        help="Subnet(s) to group hellos by (default: 192.168.0.0/16)",
    )
    parser.add_argument("--log", action="store_true", help="Enable logging of received hellos at DEBUG level")
    return parser


def get_locators(hello):
    """Extract locators from a hello object."""
    locators = []
    if hasattr(hello, "locators"):
        for locator in hello.locators:
            locators.append(str(locator))
    return locators


def remove_duplicate_hellos(hellos):
    """Remove duplicate hellos based on their locators."""
    unique_hellos = []
    seen_locators = set()

    for hello in hellos:
        locators = get_locators(hello)
        locators_tuple = tuple(sorted(locators))

        if locators_tuple not in seen_locators:
            seen_locators.add(locators_tuple)
            unique_hellos.append(hello)

    return unique_hellos


def group_by_subnet(hellos, subnet_str):
    """Group hellos by subnet."""
    try:
        subnet = ipaddress.ip_network(subnet_str, strict=False)
    except ValueError as e:
        print(f"Invalid subnet: {e}")
        return [], []

    groups = defaultdict(list)
    others = []

    for hello in hellos:
        locators = get_locators(hello)
        in_subnet = False

        for locator in locators:
            try:
                # Extract IP address from locator (format: tcp/172.16.50.2:4534)
                if "/" in locator:
                    ip_str = locator.split("/")[1].split(":")[0]
                    ip = ipaddress.ip_address(ip_str)
                    if ip in subnet:
                        groups[ip].append(hello)
                        in_subnet = True
                        break
            except (ValueError, IndexError):
                continue

        if not in_subnet and locators:
            others.append(hello)

    return groups, others


def pretty_print_groups(groups, subnet_str, others):
    """Pretty print the grouped hellos."""
    print(f"\n=== Zenoh peers in subnet: {subnet_str} ===\n")

    # Print groups
    for ip, hello_list in sorted(groups.items()):
        print(f"IP: {ip}")
        print(f"  Count: {len(hello_list)}")
        print()

    # Print others
    if others:
        print("=== Zenoh peers NOT in subnet(s) ===")
        for hello in others:
            print(f"  {get_locators(hello)}")
        print()


def main():
    args = get_parser().parse_args()

    # Setup logging if enabled
    if args.log:
        logging.basicConfig(level=logging.DEBUG, format="%(asctime)s - %(levelname)s - %(message)s")

    scout = zenoh.scout()
    hellos = []
    last_print_second = -1

    # Run for specified duration
    start_time = time.time()
    while time.time() - start_time < args.duration:
        if int(time.time() - start_time) > last_print_second:
            last_print_second += 1
            print(f"Scouting for hellos for {last_print_second}/{args.duration} seconds...", end="\r")
        try:
            hello = scout.try_recv()
            if hello:
                hellos.append(hello)
                if args.log:
                    logging.debug(f"Received hello: {get_locators(hello)}")
        except zenoh.ZError:
            continue

    # Remove duplicates
    unique_hellos = remove_duplicate_hellos(hellos)
    print()
    print(f"Received {len(unique_hellos)} unique hellos")

    remaining = None
    # Group by each subnet
    for i, subnet in enumerate(args.subnet):
        groups, others = group_by_subnet(unique_hellos, subnet)
        if remaining is None:
            remaining = set(others)
        else:
            remaining = remaining.intersection(others)

        # Pretty print results
        if i == len(args.subnet) - 1:
            pretty_print_groups(groups, subnet, remaining)
        else:
            pretty_print_groups(groups, subnet, [])


if __name__ == "__main__":
    main()
