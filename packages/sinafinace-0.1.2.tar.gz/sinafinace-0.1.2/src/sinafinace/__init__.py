import requests

def fetch_stock_latest_price(code,trade_date='20260213'):
    headers = {
        'Referer': 'http://finance.sina.com.cn',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    }
    url=f'http://hq.sinajs.cn/list={code}'
    res=requests.get(url,headers=headers)
    fields=res.text.replace('"','').split('=')[1].split(',')
    info={

        'trade_date':trade_date,
        're_open':float(fields[1]),
        're_close':float(fields[3]),
        're_high':float(fields[4]),
        're_low':float(fields[5]),
        'vol':float(fields[8]),
        'amount':float(fields[9])
    }
    return info