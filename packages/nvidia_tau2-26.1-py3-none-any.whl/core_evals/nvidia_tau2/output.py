# SPDX-FileCopyrightText: Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import json
import pathlib

from nemo_evaluator.api.api_dataclasses import EvaluationResult


def parse_output(output_dir: str) -> EvaluationResult:
    # Find tau2-bench metrics files (created by tau2 with _results.json suffix)
    metrics_files = list(pathlib.Path(output_dir).rglob("**/*_results.json"))
    if not metrics_files:
        raise FileNotFoundError(
            "Failed to find a tau2-bench results file (*_results.json). "
            "Make sure tau2 benchmark has completed successfully."
        )
    if len(metrics_files) > 1:
        raise ValueError(
            "More than 1 results file found. `output_dir` must contain a single evaluation"
        )
    
    # Load pre-computed metrics from the summary file
    with open(metrics_files[0], "r") as f:
        metrics_data = json.load(f)
    
    # Extract metrics
    domain = metrics_data["domain"]
    pass_at_k = metrics_data["metrics"]["pass_at_k"]
    avg_reward = metrics_data["metrics"]["avg_reward"]
    avg_agent_cost = metrics_data["metrics"]["avg_agent_cost"]
    pass_at_1_stats = metrics_data["metrics"]["pass_at_1_stats"]
    
    # Primary metric: pass@1
    pass_at_1 = float(pass_at_k.get("1", 0.0))
    stddev = pass_at_1_stats.get("stddev")
    stderr = pass_at_1_stats.get("stderr")
    
    # Build stats dict, filtering out None values
    stats = {}
    if stddev is not None:
        stats["stddev"] = stddev
    if stderr is not None:
        stats["stderr"] = stderr
    
    # Build metrics dict with pass@1 as primary
    task_name = f"tau2_bench_{domain}"
    
    task_metrics = {
        task_name: dict(
            metrics={
                "pass@1": dict(
                    scores={
                        "pass@1": dict(
                            value=pass_at_1,
                            stats=stats,
                        ),
                    }
                )
            }
        )
    }
    
    # Additional metrics in groups dict
    group_metrics = {
        task_name: {
            "metrics": {
                "pass@1": {
                    "scores": {
                        "pass@1": {
                            "value": pass_at_1,
                            "stats": stats,
                        },
                    }
                },
                "avg_reward": {
                    "scores": {
                        "avg_reward": {
                            "value": avg_reward,
                            "stats": {},
                        },
                    }
                },
                "avg_cost": {
                    "scores": {
                        "avg_agent_cost": {
                            "value": avg_agent_cost,
                            "stats": {},
                        },
                    }
                },
            }
        }
    }
    # Add all pass@k metrics to groups
    for k, pass_k_value in pass_at_k.items():
        k_int = int(k)
        if k_int != 1:  # pass@1 already added
            group_metrics[task_name]["metrics"][f"pass@{k}"] = {
                "scores": {
                    f"pass@{k}": {
                        "value": float(pass_k_value),
                        "stats": {},
                    },
                }
            }
    
    return EvaluationResult(tasks=task_metrics, groups=group_metrics)