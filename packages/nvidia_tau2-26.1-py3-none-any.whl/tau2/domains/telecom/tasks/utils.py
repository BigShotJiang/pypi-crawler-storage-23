# SPDX-FileCopyrightText: Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
#

# This file is based on code originally licensed under the MIT License.
# Original Copyright (c) 2025 Sierra Research
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import re
from itertools import product
from typing import Callable, Optional

from pydantic import BaseModel, Field

from tau2.data_model.message import ToolCall
from tau2.data_model.tasks import EnvAssertion, EnvFunctionCall
from tau2.environment.environment import Environment

InitFuncType = Callable[[Environment], list[EnvFunctionCall | EnvAssertion]]
FixFuncType = Callable[[Environment], list[ToolCall]] | None
EnvAssertionType = Callable[[Environment], list[EnvAssertion]]


class BaseTask(BaseModel):
    name: str
    description: str
    init_funcs: list[InitFuncType]
    fix_funcs: list[FixFuncType]
    extra_env_assertions: list[EnvAssertionType] = Field(default_factory=list)


class SelectionSet(BaseModel):
    tasks: list[BaseTask]


class ComposedTask(BaseModel):
    name: str
    description: str
    composed_from: list[BaseTask]
    init_funcs: list[InitFuncType]
    fix_funcs: list[FixFuncType]
    extra_env_assertions: list[EnvAssertionType] = Field(default_factory=list)

    def __str__(self):
        lines = []
        lines.append("-" * len(self.name))
        lines.append(self.name)
        lines.append("-" * len(self.name))
        lines.append(f"Description: {self.description}")
        lines.append("Base Tasks:")
        for task in self.composed_from:
            lines.append(f"  - {task.name}: {task.description}")
        lines.append("Init Funcs:")
        for func in self.init_funcs:
            lines.append(f"  - {func.__name__}")
        lines.append("Fix Funcs:")
        for func in self.fix_funcs:
            lines.append(f"  - {func.__name__}")
        lines.append("Extra Env Assertions:")
        for func in self.extra_env_assertions:
            lines.append(f"  - {func.__name__}")

        return "\n".join(lines)

    def __repr__(self):
        return self.__str__()


def compose_tasks(
    selection_sets: list[SelectionSet],
    task_validator: Optional[Callable[[list[Optional[BaseTask]]], bool]] = None,
) -> list[ComposedTask]:
    """
    Return all the combinations of selecting 0 or more tasks from the selection sets
    """

    product_tasks = list(
        product(*[selection_set.tasks + [None] for selection_set in selection_sets])
    )
    composed_tasks = []
    for tasks in product_tasks:
        if task_validator is not None:
            if not task_validator(tasks):
                continue
        tasks = sorted([t for t in tasks if t is not None], key=lambda x: x.name)
        if task_validator is None and len(tasks) == 0:
            continue
        init_funcs = [f for t in tasks for f in t.init_funcs]
        fix_funcs = [f for t in tasks for f in t.fix_funcs]
        extra_env_assertions = [f for t in tasks for f in t.extra_env_assertions]
        composed_task = ComposedTask(
            name="|".join([t.name for t in tasks]),
            description=", ".join([t.description for t in tasks]),
            composed_from=tasks,
            init_funcs=init_funcs,
            fix_funcs=fix_funcs,
            extra_env_assertions=extra_env_assertions,
        )
        composed_tasks.append(composed_task)
    return composed_tasks


def get_intent_from_task_id(task_id: str) -> str:
    """
    Extract the intent from the task_id.
    task_id is of the form: [intent]action1|action2|...|actionk[PERSONA:persona]
    """
    pat = r"^\[([a-zA-Z_]+)\]"
    match = re.search(pat, task_id)
    if match:
        return match.group(1)
    else:
        raise ValueError(f"Could not extract intent from task_id: {task_id}")


def get_persona_from_task_id(task_id: str) -> str:
    """
    Extract the persona from the task_id.
    task_id is of the form: [intent]action1|action2|...|actionk[PERSONA:persona]
    """
    pat = r"\[PERSONA:([a-zA-Z_]+)\]"
    match = re.search(pat, task_id)
    if match:
        return match.group(1)
    else:
        raise ValueError(f"Could not extract intent from task_id: {task_id}")


def get_num_issues_from_task_id(task_id: str) -> int:
    """
    Extract the number of issues from the task_id.
    task_id is of the form: [intent]action1|action2|...|actionk[PERSONA:persona]
    """
    return len(task_id.split("|"))
