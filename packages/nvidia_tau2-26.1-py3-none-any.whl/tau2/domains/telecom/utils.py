# SPDX-FileCopyrightText: Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
#

# This file is based on code originally licensed under the MIT License.
# Original Copyright (c) 2025 Sierra Research
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from datetime import date, datetime

from tau2.utils.utils import DATA_DIR

TELECOM_DATA_DIR = DATA_DIR / "tau2" / "domains" / "telecom"
TELECOM_DB_PATH = TELECOM_DATA_DIR / "db.toml"
TELECOM_USER_DB_PATH = TELECOM_DATA_DIR / "user_db.toml"
TELECOM_MAIN_POLICY_PATH = TELECOM_DATA_DIR / "main_policy.md"
TELECOM_TECH_SUPPORT_POLICY_MANUAL_PATH = TELECOM_DATA_DIR / "tech_support_manual.md"
TELECOM_TECH_SUPPORT_POLICY_WORKFLOW_PATH = (
    TELECOM_DATA_DIR / "tech_support_workflow.md"
)
TELECOM_MAIN_POLICY_SOLO_PATH = TELECOM_DATA_DIR / "main_policy_solo.md"
TELECOM_TECH_SUPPORT_POLICY_MANUAL_SOLO_PATH = (
    TELECOM_DATA_DIR / "tech_support_manual.md"
)
TELECOM_TECH_SUPPORT_POLICY_WORKFLOW_SOLO_PATH = (
    TELECOM_DATA_DIR / "tech_support_workflow_solo.md"
)
# TELECOM_TASK_SET_PATH_FULL = TELECOM_DATA_DIR / "tasks_full.json" # Not used anymore. Use full task split instead
# TELECOM_TASK_SET_PATH_SMALL = TELECOM_DATA_DIR / "tasks_small.json" # Not used anymore. Use small task split instead
TELECOM_TASK_SET_PATH = TELECOM_DATA_DIR / "tasks.json"


def get_now() -> datetime:
    # assume now is 2025-02-25 12:08:00
    return datetime(2025, 2, 25, 12, 8, 0)


def get_today() -> date:
    # assume today is 2025-02-25
    return date(2025, 2, 25)
