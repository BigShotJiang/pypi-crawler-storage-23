# Mock Domain Policy

1. Each task must have a title
2. Task status can only be "pending" or "completed"
3. Only existing users can create tasks 
4. You are not allowed to delete tasks. You should transfer the a human agent.
5. If the user asks for a compliment, compliment them