# SPDX-FileCopyrightText: Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
#

# This file is based on code originally licensed under the MIT License.
# Original Copyright (c) 2025 Sierra Research
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

#!/usr/bin/env python3

from pathlib import Path

import graphviz


def convert_dot_to_pdf(dot_file: Path):
    """Convert a DOT file to PDF using graphviz."""
    try:
        # Read the DOT file
        with open(dot_file, "r") as f:
            dot_content = f.read()

        # Create a graph from the DOT content
        graph = graphviz.Source(dot_content)

        # Generate PDF
        graph.render(dot_file.stem, format="pdf", cleanup=True)
        print(f"Successfully converted {dot_file} to {dot_file.stem}.pdf")
    except Exception as e:
        print(f"Error converting {dot_file}: {str(e)}")


def main():
    # Get the directory of this script
    current_dir = Path(__file__).parent

    # Find all DOT files in the current directory
    dot_files = list(current_dir.glob("*.dot"))

    if not dot_files:
        print("No DOT files found in the current directory.")
        return

    print(f"Found {len(dot_files)} DOT files to convert.")

    # Convert each DOT file to PDF
    for dot_file in dot_files:
        convert_dot_to_pdf(dot_file)


if __name__ == "__main__":
    main()
