from django.conf import settings
from django.db import models
from .manager import UserManager
from django.utils import timezone
from django.utils.translation import gettext_lazy as _
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin

AUTH_PROVIDERS = {
    'email': 'email',
    'google': 'google',
    'github': 'github',
    'facebook': 'facebook'
}


class AbstractAutheaseUser(AbstractBaseUser, PermissionsMixin):
    """
    Abstract base user model for authease. Extend this class to add custom
    fields while retaining authease's authentication functionality.
    """
    # Abstractbaseuser has password, last_login, is_active by default

    email = models.EmailField(unique=True, max_length=255, verbose_name= _("Email Address"))
    first_name = models.CharField(max_length=150, verbose_name=_("First name"))
    last_name = models.CharField(max_length=150, verbose_name=_("Last name"))

    is_staff = models.BooleanField(
        default=False
    )  # must needed, otherwise you won't be able to loginto django-admin.
    is_active = models.BooleanField(
        default=True
    )  # must needed, otherwise you won't be able to loginto django-admin.
    is_superuser = models.BooleanField(
        default=False
    )  # this field inherit from PermissionsMixin.
    is_verified = models.BooleanField(
        default=False
    )
    date_joined = models.DateTimeField(
        auto_now_add=True
    )
    auth_provider = models.CharField(max_length=50, default=AUTH_PROVIDERS.get("email"))

    USERNAME_FIELD = "email"

    REQUIRED_FIELDS = ["first_name", "last_name"]

    objects = UserManager()

    def __str__(self):
        return self.email

    @property
    def get_full_name(self):
        return f"{self.first_name} {self.last_name}"

    def tokens(self):
        refresh = RefreshToken.for_user(self)

        return {
            'refresh': str(refresh),
            'access': str(refresh.access_token)
        }

    class Meta:
        abstract = True


class User(AbstractAutheaseUser):
    """
    Default concrete user model. If you need custom fields, extend
    AbstractAutheaseUser in your own app and set AUTH_USER_MODEL accordingly.
    """
    class Meta:
        verbose_name = "User"
        verbose_name_plural = "Users"
        swappable = 'AUTH_USER_MODEL'


class OneTimePassword(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    code = models.CharField(max_length=10, unique=True, db_index=True)
    created_at = models.DateTimeField(auto_now_add=True)  # Automatically set timestamp when created

    def is_expired(self):
        """Check if the code has expired based on configurable expiration time."""
        expiration_minutes = getattr(settings, 'AUTHEASE_OTP_EXPIRY_MINUTES', 15)
        expiration_time = self.created_at + timezone.timedelta(minutes=expiration_minutes)
        return timezone.now() > expiration_time

    def __str__(self):
        return f"{self.user.first_name} passcode"


class PasswordResetToken(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="password_reset_token")
    token = models.CharField(max_length=100, unique=True, db_index=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.first_name} password reset token"
