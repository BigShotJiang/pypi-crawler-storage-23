from importlib.metadata import version

__version__: str = version("anndata-fcs")
