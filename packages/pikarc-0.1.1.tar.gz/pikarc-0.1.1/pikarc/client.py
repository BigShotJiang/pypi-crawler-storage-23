from __future__ import annotations

import os
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any

import httpx

from pikarc._run import GuardedRun
from pikarc.exceptions import PikarcBlockedError
from pikarc.types import RunResponse

_BASE_URL = "https://pikarc-api-production.up.railway.app"


class AsyncPikarc:
    """Async client for the Pikarc control plane."""

    def __init__(self, api_key: str | None = None) -> None:
        api_key = api_key or os.environ.get("PIKARC_API_KEY")
        if not api_key:
            raise ValueError(
                "api_key must be provided or set via PIKARC_API_KEY env var"
            )
        self._http = httpx.AsyncClient(
            base_url=_BASE_URL,
            headers={"Authorization": f"Bearer {api_key}"},
        )

    @asynccontextmanager
    async def run(
        self,
        user_id: str,
        metadata: dict[str, Any] | None = None,
    ) -> AsyncIterator[GuardedRun]:
        """Start a guarded run. Auto-ends on exit (COMPLETED or FAILED)."""
        body: dict[str, Any] = {"user_id": user_id}
        if metadata is not None:
            body["metadata"] = metadata

        resp = await self._http.post("/v1/runs/", json=body)
        resp.raise_for_status()
        run_resp = RunResponse.model_validate(resp.json())

        if run_resp.decision.outcome == "DENY":
            raise PikarcBlockedError(
                reason=run_resp.decision.reason or "Blocked",
                deny_reason=run_resp.decision.reason or "DENIED",
            )

        guarded = GuardedRun(run_id=run_resp.id, client=self._http)
        failed = False
        try:
            yield guarded
        except Exception:
            failed = True
            raise
        finally:
            status = "FAILED" if failed else "COMPLETED"
            await self._http.post(
                f"/v1/runs/{guarded.run_id}/end",
                json={"status": status},
            )

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._http.aclose()
