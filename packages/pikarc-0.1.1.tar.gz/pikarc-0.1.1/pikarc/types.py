from __future__ import annotations

from pydantic import BaseModel


class Decision(BaseModel):
    outcome: str  # "ALLOW" | "DENY"
    reason: str | None = None


class RunResponse(BaseModel):
    id: str
    status: str
    decision: Decision


class StepResponse(BaseModel):
    id: str
    status: str
    decision: Decision
