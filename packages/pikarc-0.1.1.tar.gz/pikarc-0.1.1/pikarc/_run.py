from __future__ import annotations

import inspect
import time
from collections.abc import Awaitable, Callable
from typing import Any, TypeVar

import httpx

from pikarc.exceptions import PikarcBlockedError
from pikarc.types import StepResponse

T = TypeVar("T")


class GuardedRun:
    """Tracks a single run and provides model_call / tool_call wrappers."""

    def __init__(self, run_id: str, client: httpx.AsyncClient) -> None:
        self.run_id = run_id
        self._client = client
        self._step_seq = 0

    async def model_call(
        self,
        fn: Callable[[], T | Awaitable[T]],
        model: str,
        input_data: dict[str, Any] | None = None,
        token_extractor: Callable[[T], tuple[int, int]] | None = None,
    ) -> T:
        """Wrap a model call: check -> execute -> extract tokens -> report."""
        self._step_seq += 1
        step = await self._create_step(
            step_type="MODEL_CALL",
            model=model,
            input_data=input_data,
        )

        return await self._execute_step(
            step=step,
            fn=fn,
            token_extractor=token_extractor,
        )

    async def tool_call(
        self,
        fn: Callable[[], T | Awaitable[T]],
        tool_name: str,
        input_data: dict[str, Any] | None = None,
    ) -> T:
        """Wrap a tool call: check -> execute -> report."""
        self._step_seq += 1
        step = await self._create_step(
            step_type="TOOL_CALL",
            tool_name=tool_name,
            input_data=input_data,
        )

        return await self._execute_step(step=step, fn=fn)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _create_step(
        self,
        step_type: str,
        model: str | None = None,
        tool_name: str | None = None,
        input_data: dict[str, Any] | None = None,
    ) -> StepResponse:
        body: dict[str, Any] = {
            "type": step_type,
            "sequence": self._step_seq,
        }
        if model is not None:
            body["model"] = model
        if tool_name is not None:
            body["tool_name"] = tool_name
        if input_data is not None:
            body["input_data"] = input_data

        resp = await self._client.post(
            f"/v1/runs/{self.run_id}/steps",
            json=body,
        )
        resp.raise_for_status()
        step = StepResponse.model_validate(resp.json())

        if step.decision.outcome == "DENY":
            raise PikarcBlockedError(
                reason=step.decision.reason or "Blocked",
                deny_reason=step.decision.reason or "DENIED",
            )
        return step

    async def _execute_step(
        self,
        step: StepResponse,
        fn: Callable[[], T | Awaitable[T]],
        token_extractor: Callable[[T], tuple[int, int]] | None = None,
    ) -> T:
        start = time.perf_counter()
        try:
            result = fn()
            if inspect.isawaitable(result):
                result = await result
        except Exception:
            duration_ms = int((time.perf_counter() - start) * 1000)
            await self._update_step(step.id, status="FAILED", duration_ms=duration_ms)
            raise

        duration_ms = int((time.perf_counter() - start) * 1000)
        patch: dict[str, Any] = {"status": "COMPLETED", "duration_ms": duration_ms}

        if token_extractor is not None:
            prompt_tokens, completion_tokens = token_extractor(result)  # type: ignore[arg-type]
            patch["prompt_tokens"] = prompt_tokens
            patch["completion_tokens"] = completion_tokens

        await self._update_step(step.id, **patch)
        return result  # type: ignore[return-value]

    async def _update_step(self, step_id: str, **fields: Any) -> None:
        resp = await self._client.patch(
            f"/v1/runs/{self.run_id}/steps/{step_id}",
            json=fields,
        )
        resp.raise_for_status()
