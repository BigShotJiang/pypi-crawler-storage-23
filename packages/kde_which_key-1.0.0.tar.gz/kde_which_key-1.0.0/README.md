# kde-which-key
Query kde shortcuts. Inspired by `which-key in emacs`. 

AI-generated and unreviewed.

## Installation
`pipx install kde-which-key`

## Usage
`kde-which` shows a popup for filtering keys. You can use `?` to fuzzy search for keybindings.

## Related tools
You may also like my tool kde-shortcuts which can add and remove shortcuts.

## About
I am @readwithai. I make tools for reading and agency with and without AI and Obsidian. I also produce a stream of small tools like this as part of my work. If this tool sounds interesting you might like to [follow me on github](https://github.com/talwrii).


