========
carbatpy
========

.. image:: https://img.shields.io/pypi/v/carbatpy.svg
   :target: https://pypi.python.org/pypi/carbatpy

.. image:: https://readthedocs.org/projects/carbatpy-010/badge/?version=latest
   :target: https://carbatpy-010.readthedocs.io/en/latest/
   :alt: Documentation Status

carbatpy is a Python package for modelling Carnot batteries (thermal energy storage)
based on heat pumps for charging, organic Rankine cycles (ORC) for discharging,
and different storage concepts.

Currently, the main focus is on **steady-state** thermodynamic cycle simulation and
evaluation (efficiency, costs, and optimisation). Time-dependent models are planned.

Documentation
-------------
* https://carbatpy-010.readthedocs.io/en/latest/

Requirements (mandatory)
------------------------
REFPROP is strongly recommended for meaningful use of the package.

* **REFPROP (NIST)**: a valid license is required.
* Python: >= 3.10, <3.14

In addition, typical scientific Python packages are used (NumPy, SciPy, pandas, ...);
see ``pyproject.toml`` for the full list.

Optional components
-------------------
carbatpy can optionally interface with additional tools. These are *not* required
to install or import carbatpy. When available, they can be selected explicitly
in various functions (they are **not enabled automatically**).

TREND
^^^^^
If **TREND** is installed and you want to use it for thermodynamic properties,
enable it in ``carbatpy.cb_config.py`` by setting the dictionary ``TREND``
accordingly (example):

* ``{"USE_TREND": True, "TREND_DLL": "...", "TREND_PATH": "..."}``

In addition, the relevant TREND paths typically need to be available as system
environment variables (see documentation for details). TREND was developed and is 
authored by Prof. Roland Span and his co-workers (Chair of Thermodynamics, Ruhr University Bochum).

Note: currently, TREND support is limited to **thermodynamic properties** (no
transport properties).

License note: TREND is licensed under GPLv3+. TREND is not distributed with carbatpy;
it must be installed separately. Users are responsible for complying with the TREND license.

Machine models (SPP 2403)
^^^^^^^^^^^^^^^^^^^^^^^^^
carbatpy can optionally interface with detailed machine-model packages that are
developed and maintained in separate repositories and may have their own license
and citation requirements. carbatpy itself remains usable without them.

Available add-ons (examples)
""""""""""""""""""""""""""""
* ``spp_machines`` (turbomachinery/compressor design tools)
  Authors: Steffen Folkers, Matthias Heselmann, Dieter Brillert, Andreas Brümmer,
  Sebastian Schuster.
  Availability: internal/private repository (on request)
  License: see repository

* ``incept-processmaps`` (inverse design process maps for compressors)
  Authors: Matthias Heselmann, Steffen Folkers, ...
  DOI: https://doi.org/10.17877/TUDODATA-2025-MFV1200A
  License: MIT with attribution requirement (see repository / CITATION)

* ``expander-liege`` (semi-empirical scroll expander model, Liège)
  Authors: Elise Neven (University of Liège), Basile Chaudoir (University of Liège),
  Vincent Lemort.
  Adaptation/packaging for carbatpy: Philipp Dreis (University of Duisburg-Essen)
  Upstream: LaboThapPy community (https://github.com/PyLaboThap/LaboThapPy/tree/main)
  License: Apache-2.0 (upstream); see the add-on repository for details

Installation (internal users)
"""""""""""""""""""""""""""""
If you have access to the private repositories, you can install the add-ons via Poetry groups:

* all machine add-ons:
  ``poetry install --with machines``
* only selected add-ons:
  ``poetry install --with processmaps`` (etc.)

If Git access is not available, internal wheels can be provided as an alternative.

External users
""""""""""""""
External users can install base carbatpy normally and request the machine-model
add-ons from the respective authors/maintainers.

Package structure
-----------------
The main functionality is implemented in the subpackages under ``carbatpy.models``:

* ``cb_fluids``:
  Fluid mixture properties (REFPROP; optional: TREND for thermodynamic data)
* ``components``:
  Models of individual devices such as compressors, turbines, heat exchangers,
  throttles, etc.
* ``coupled``:
  Coupled component models forming thermodynamic cycles and Carnot batteries

Features
--------
* Steady-state calculation of heat pumps, ORCs, and Carnot batteries
* Optimization of pressure levels and working fluid mixture composition for improved second-law efficiency
* Cost estimation based on correlations from the literature
* Reading cycle configurations and parameters from YAML input files
* Quasi steady-state evaluation of efficiencies and costs

Roadmap / TODO
--------------
* Time-dependent (dynamic) cycle simulation
* Further validation and extended component models

Credits
-------
* This package was created with Cookiecutter_ and the
  `audreyr/cookiecutter-pypackage`_ project template.

Contact
-------
Burak Atakan, University of Duisburg-Essen, Germany

* atakan.thermodynamik.duisburg [at] gmail.com

License
-------
* MIT License

Third-party notices
-------------------
carbatpy can interface with optional third-party add-ons which may have their own
license and citation requirements. See ``THIRD_PARTY_NOTICES.rst``.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage