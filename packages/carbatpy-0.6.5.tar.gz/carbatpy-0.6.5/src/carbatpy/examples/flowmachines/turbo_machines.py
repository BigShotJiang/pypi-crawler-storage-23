"""
Example for usage of the Turbo Design Tool
"""

import carbatpy as cb
import datetime

from carbatpy.optional.spp_machines import Compressor, Turbine, require_spp_machines

require_spp_machines()

# %%
# Compressor
# Initiate Compressor
print(datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S"))

# %%
Results = Compressor()
# Create inputs for the Tool
InletTemperature = 291.15  # [K]
InletPressure = 1e5  # [Pa]
OutletPressure = 20e5  # [Pa]
InletVolumeFlow = 1.5  # [m^3/s]
WorkingFluid = "pentane * butane * propane * ethane"  # Working fluid
WorkingFluidComposition = [0.2, 0.2, 0.4, 0.2]  # mole fractions

# Calling the design method
OutletState, MachineData = Results.designCompressor(
    WorkingFluid,
    WorkingFluidComposition,
    InletPressure,
    InletTemperature,
    OutletPressure,
    InletVolumeFlow,
    GearedCompressor=False,
    Plot=False,
    EfficiencyConvergence=5e-2,
)

# %%
print("Outlet:", OutletState.state)

# Efficiency in MachineData at the last stage:
print("eta_is:", Results.IsentropicEfficiency[-1])
print("m_dot:", Results.MassFlow)
print("MachineData keys:", MachineData.keys())
print("n_stages:", Results.BasicParameters.StageNumber)
print(datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S"))


# %%
# Turbine
# Create inputs for the Tool
InletTemperature = 100 + 273.10  # [K]
InletPressure = 15e5  # [Pa]
OutletPressure = 3e5  # [Pa]
MassFlow = 0.1  # [kg/s]
WorkingFluid = "pentane * butane * propane * ethane"  # Working fluid
WorkingFluidComposition = [0.2, 0.2, 0.4, 0.2]  # mole fractions

TS = cb.CB_DEFAULTS["Fluid_Defaults"]["TRANS_STRING"]

myfluid = cb.init_fluid(WorkingFluid, WorkingFluidComposition)
InletState = myfluid.set_state(
    [InletTemperature, InletPressure], "TP", wanted=TS, output="FluidState"
)

# Class initialisation
Results_turbine = Turbine()

# Calling the design method
OutletState_turbine, MachineData_turbine = Results_turbine.designTurbine(
    WorkingFluid,
    WorkingFluidComposition,
    InletState,
    OutletPressure,
    MassFlow,
    Plot=False,
)

# %%
# Outletstate
print(OutletState_turbine.state)

# Efficiency in MachineData at the last stage:
print(Results_turbine.IsentropicEfficiency[-1])
print(Results_turbine.PolytropicEfficiency)
print("n_stages:", Results_turbine.BasicParameters.StageNumber)
