"""
Example for usage of the scroll expander modell form Liège
"""

import carbatpy as cb
from carbatpy.optional.expander_liege import ExpanderSE

# -------------------------------------------------------------------------------------------#
"Third case: N_rot and m_dot known + P_ex unknown"
# -------------------------------------------------------------------------------------------#
# Create an instance of the expander component
expander = ExpanderSE()

# Create inputs for the Tool
InletTemperature = 100 + 273.15  # [K]
InletPressure = 15e5  # [Pa]
OutletPressure = 3e5  # [Pa]
MassFlow = 0.1  # [kg/s]
WorkingFluid = "pentane * butane * propane * ethane"  # Working fluid
WorkingFluidComposition = [0.2, 0.2, 0.4, 0.2]  # mole fractions

myfluid = cb.init_fluid(WorkingFluid, WorkingFluidComposition)
state = myfluid.set_state([InletTemperature, InletPressure], "TP", output="FluidState")
InletEnthalpy = state.enthalpy

# Define Inputs
inputs = {
    "P_su": InletPressure,
    "h_su": InletEnthalpy,
    "P_ex": OutletPressure,
    "m_dot": MassFlow,
    "T_amb": 288.15,
    "fluid": WorkingFluid,
    "comp": WorkingFluidComposition,
}

# Default parameters as implemented in the model
default_values = {
    "AU_amb": 0,  #  Heat transfer to the ambient neglected
    "AU_su_n": 0,  # Heat transfer to the suction side neglected
    "AU_ex_n": 0,  # Heat transfer to the exhaust side neglected
    "d_su1": 0,  # Pressure drop at the suction side neglected
    "m_dot_n": 1,  # Nominal mass flow rate
    "A_leak": 1e-12,  # Very small leakage area to neglect the leakage effect
    "W_dot_loss_0": 0,  # Idle losses neglected
    "alpha": 0,  # Proportionality rate for mechanical losses neglected
    "C_loss": 0,  # Torque losses neglected
    "rv_in": 2.5,  # Default volume ratio
    "V_s": 0.001,  # Default swept volume
    "mode": "P_M",  # Default mode
}

params_example_labothappy = {
    "AU_amb": 8.33758799e00,
    "AU_su_n": 6.67152053e-01,
    "AU_ex_n": 3.21181352e01,
    "d_su1": 6.31789061e-03,
    "m_dot_n": 0.1,
    "A_leak": 1.00000000e-10,
    "W_dot_loss_0": 8.19123951e-01,
    "alpha": 7.79756524e-02,
    "C_loss": 4.68294054e-01,
    "rv_in": 1.7,
    "V_s": 0.0000712,
    "mode": "P_M",
}

expander.set_inputs(**inputs)
expander.set_parameters(**default_values)


# Check the setup
expander.print_setup()

# Solve the expander component
expander.solve()
# Print the results
expander.print_results()

print(expander.h_ex)
print(expander.epsilon_is)
