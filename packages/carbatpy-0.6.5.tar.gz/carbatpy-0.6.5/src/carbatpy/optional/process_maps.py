# -*- coding: utf-8 -*-
"""
Inverse Design: Process map - internal isentropic efficiencies for centrifugal
and screw compressors

DOI:  https://doi.org/10.17877/TUDODATA-2025-MFV1200A

"""

from __future__ import annotations

from importlib.util import find_spec

HAS_INCEPT = find_spec("incept") is not None

if HAS_INCEPT:
    from incept import InverseDesign
else:
    InverseDesign = None


def require_process_maps() -> None:
    """Raise a helpful error if incept is not installed."""
    if not HAS_INCEPT:
        raise ImportError(
            "Optional dependency 'incept' is not installed. "
            "Install it in the same environment as carbatpy, e.g. "
            "'pip install incept' or (Poetry) 'poetry install --with process_maps'."
        )