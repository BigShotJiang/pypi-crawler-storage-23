from __future__ import annotations
from importlib.util import find_spec

HAS_EXPANDER_LIEGE = find_spec("expander_liege") is not None

if HAS_EXPANDER_LIEGE:
    from expander_liege import ExpanderSE  # noqa: F401
else:
    ExpanderSE = None  # type: ignore[assignment]


def require_expander_liege() -> None:
    if not HAS_EXPANDER_LIEGE:
        raise ImportError(
            "Optional dependency 'expander-liege' is not installed. "
            "Install it e.g. with 'pip install expander-liege'"
        )