"""Shared client factories for Google Cloud services."""

from __future__ import annotations

import json
import logging
import os
import threading
import time
from typing import Dict, Optional, Tuple

import requests
from google.api_core import exceptions as gcloud_exceptions
from google.auth import default as get_default_credentials
from google.auth.transport.requests import Request
from google.cloud import firestore
from google.cloud import secretmanager
from google.cloud import storage
from google.oauth2 import service_account
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build

from config import Config


LOGGER = logging.getLogger(__name__)

SCOPES = [
    "https://www.googleapis.com/auth/gmail.modify",
]

TOKEN_URI = "https://oauth2.googleapis.com/token"
REFRESH_WINDOW_SECONDS = 300
MAX_JWT_LIFETIME_SECONDS = 3600
_KEYLESS_CACHE_LOCK = threading.Lock()
# Key: (signing_sa_email, mailbox_user, scopes_tuple). Value: (token, expiry). Ensures wrong token is not reused if config differs.
_KEYLESS_CACHE: Dict[tuple, tuple] = {}

_SECRET_MANAGER_CLIENT: Optional[secretmanager.SecretManagerServiceClient] = None
_SECRET_CACHE: Dict[str, str] = {}

# Deterministic, low-noise runtime proof lines.
# These are intentionally ASCII-only and printed once per process so operators can confirm behavior
# even when log levels/filters differ across environments.
_PROOF_PRINT_LOCK = threading.Lock()
_PROOF_PRINTED: set = set()


def _proof_once(line: str) -> None:
    msg = (line or "").strip()
    if not msg:
        return
    with _PROOF_PRINT_LOCK:
        if msg in _PROOF_PRINTED:
            return
        _PROOF_PRINTED.add(msg)
    try:
        print(msg, flush=True)
    except Exception:
        pass


def _secret_manager_client() -> secretmanager.SecretManagerServiceClient:
    global _SECRET_MANAGER_CLIENT
    if _SECRET_MANAGER_CLIENT is None:
        _SECRET_MANAGER_CLIENT = secretmanager.SecretManagerServiceClient()
    return _SECRET_MANAGER_CLIENT


def _resolve_secret_name(project_id: str, identifier: Optional[str]) -> Optional[str]:
    if not identifier:
        return None
    if identifier.startswith("projects/"):
        return identifier if "/versions/" in identifier else f"{identifier}/versions/latest"
    return f"projects/{project_id}/secrets/{identifier}/versions/latest"


def _get_secret_value(project_id: str, identifier: Optional[str]) -> Optional[str]:
    name = _resolve_secret_name(project_id, identifier)
    if not name:
        return None
    if name in _SECRET_CACHE:
        return _SECRET_CACHE[name]
    client = _secret_manager_client()
    try:
        response = client.access_secret_version(request={"name": name})
    except gcloud_exceptions.NotFound as exc:  # pragma: no cover - runtime configuration issue
        raise RuntimeError(
            "Secret not found: {}. Ensure it exists and that the Cloud Run service account has access.".format(
                name
            )
        ) from exc
    value = response.payload.data.decode("utf-8")
    _SECRET_CACHE[name] = value
    return value


def _get_signing_sa_email(config: Config) -> str:
    """
    Resolve the signing SA email for keyless DWD.
    Signing SA = Cloud Run service account (runtime identity), or SIGNING_SERVICE_ACCOUNT_EMAIL / SERVICE_ACCOUNT_EMAIL.
    """
    email = os.environ.get("SIGNING_SERVICE_ACCOUNT_EMAIL") or os.environ.get("SERVICE_ACCOUNT_EMAIL")
    if email:
        return email.strip()
    try:
        resp = requests.get(
            "http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/email",
            headers={"Metadata-Flavor": "Google"},
            timeout=2,
        )
        if resp.status_code == 200 and resp.text:
            return resp.text.strip()
    except Exception:
        pass
    raise RuntimeError(
        "Could not resolve signing SA email for keyless DWD. "
        "Set SERVICE_ACCOUNT_EMAIL (or SIGNING_SERVICE_ACCOUNT_EMAIL) on Cloud Run, or ensure metadata server is available."
    )


class _KeylessDWDCredentials(Credentials):
    """
    Credentials for domain-wide delegation using IAM Credentials signJwt (no exported key).
    Compatible with google.auth.credentials.Credentials; caches access token with lock and refresh window.
    """

    def __init__(self, config: Config, signing_sa_email: str):
        super().__init__(token=None)
        self._config = config
        self._signing_sa_email = signing_sa_email
        self._cache_key: Tuple[str, str, Tuple[str, ...]] = (
            signing_sa_email,
            config.mailbox_user,
            tuple(SCOPES),
        )
        self._cached_token: Optional[str] = None
        self._cached_expiry: float = 0

    @property
    def expired(self) -> bool:
        return not self._cached_token or (time.time() >= self._cached_expiry - REFRESH_WINDOW_SECONDS)

    def refresh(self, request: Request) -> None:
        now = time.time()
        with _KEYLESS_CACHE_LOCK:
            entry = _KEYLESS_CACHE.get(self._cache_key)
            if entry:
                tok, exp = entry
                if exp - now >= REFRESH_WINDOW_SECONDS:
                    self._cached_token = tok
                    self._cached_expiry = exp
                    self.token = tok
                    return
        # Cache miss or expired; sign and exchange below, then store under self._cache_key
        try:
            from google.cloud.iam_credentials_v1.services.iam_credentials import IAMCredentialsClient
            from google.cloud.iam_credentials_v1.types import SignJwtRequest
        except ImportError as exc:
            raise RuntimeError(
                "Keyless DWD requires google-cloud-iam (provides google.cloud.iam_credentials_v1). "
                "Add it to requirements.txt and ensure the container build uses Python 3.11."
            ) from exc
        now = time.time()
        payload = {
            "iss": self._signing_sa_email,
            "sub": self._config.mailbox_user,
            "aud": TOKEN_URI,
            "scope": " ".join(SCOPES),
            "iat": int(now),
            "exp": int(now) + min(3600, MAX_JWT_LIFETIME_SECONDS),
        }
        name = "projects/-/serviceAccounts/{}".format(self._signing_sa_email)
        try:
            client = IAMCredentialsClient()
            response = client.sign_jwt(request=SignJwtRequest(name=name, payload=json.dumps(payload)))
        except gcloud_exceptions.PermissionDenied as exc:
            LOGGER.error("Keyless DWD: signJwt PERMISSION_DENIED - missing iam.serviceAccounts.signJwt on signing SA")
            raise RuntimeError(
                "Keyless DWD failed: IAM Credentials signJwt returned PERMISSION_DENIED. "
                "Grant roles/iam.serviceAccountTokenCreator on the orchestrator service account to itself (call GCP admin)."
            ) from exc
        signed_jwt = response.signed_jwt
        token_resp = requests.post(
            TOKEN_URI,
            data={
                "grant_type": "urn:ietf:params:oauth:grant-type:jwt-bearer",
                "assertion": signed_jwt,
            },
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            timeout=30,
        )
        if token_resp.status_code != 200:
            body = token_resp.text
            err = ""
            if "application/json" in (token_resp.headers.get("content-type") or ""):
                try:
                    err = (token_resp.json() or {}).get("error", "")
                except Exception:
                    pass
            if err in ("unauthorized_client", "invalid_grant"):
                LOGGER.error("Keyless DWD: token exchange %s - Workspace DWD allowlist or scope issue", err)
                raise RuntimeError(
                    "Keyless DWD failed: OAuth token exchange returned {} ({}). "
                    "Workspace Admin must allowlist the service account client ID for Gmail scopes (call Workspace admin).".format(
                        err, body[:200] if body else token_resp.status_code
                    )
                )
            raise RuntimeError(
                "Keyless DWD failed: token exchange returned HTTP {}: {}".format(
                    token_resp.status_code, body[:500] if body else "no body"
                )
            )
        try:
            data = token_resp.json()
        except Exception as parse_exc:
            raise RuntimeError(
                "Keyless DWD failed: token response is not valid JSON: {}".format(parse_exc)
            ) from parse_exc
        access_token = data.get("access_token") if isinstance(data, dict) else None
        expires_in = int(data.get("expires_in", 3600)) if isinstance(data, dict) else 3600
        if not access_token:
            raise RuntimeError("Keyless DWD failed: token response missing access_token")
        expiry = now + expires_in
        with _KEYLESS_CACHE_LOCK:
            _KEYLESS_CACHE[self._cache_key] = (access_token, expiry)
            self._cached_token = access_token
            self._cached_expiry = expiry
        self.token = access_token


def _get_dwd_credentials_keyless(config: Config):
    """Return DWD credentials using IAM Credentials signJwt (no exported SA key)."""
    signing_sa_email = _get_signing_sa_email(config)
    creds = _KeylessDWDCredentials(config, signing_sa_email)
    creds.refresh(Request())
    return creds


def _get_base_service_account_credentials(config: Config):
    """Return base service account credentials (no delegation). Used for DWD with subject."""
    if config.service_account_info:
        return service_account.Credentials.from_service_account_info(
            config.service_account_info, scopes=SCOPES
        )
    credentials_path = os.environ.get("GOOGLE_APPLICATION_CREDENTIALS")
    if credentials_path:
        return service_account.Credentials.from_service_account_file(
            credentials_path, scopes=SCOPES
        )
    credentials, _ = get_default_credentials(scopes=SCOPES)
    return credentials


def _has_key_based_dwd_config(config: Config) -> bool:
    """True if SA key is configured (SERVICE_ACCOUNT_JSON or GOOGLE_APPLICATION_CREDENTIALS)."""
    return bool(config.service_account_info or os.environ.get("GOOGLE_APPLICATION_CREDENTIALS"))


def _get_dwd_credentials(config: Config):
    """
    Return credentials for Domain-Wide Delegation: SA acting as config.mailbox_user.
    Tries keyless (IAM Credentials signJwt) first when no SA key is configured, then key-based (with_subject).
    """
    if not _has_key_based_dwd_config(config):
        try:
            creds = _get_dwd_credentials_keyless(config)
            LOGGER.info("Gmail auth mode: dwd (keyless)")
            _proof_once("Gmail auth mode: dwd (keyless)")
            return creds
        except Exception as exc:
            LOGGER.warning("Keyless DWD failed: %s", exc)
            # Print once so operators can grep even if WARNING/INFO logs are filtered differently.
            _proof_once("Keyless DWD failed: {}".format(exc))
            raise
    base = _get_base_service_account_credentials(config)
    if not hasattr(base, "with_subject"):
        raise RuntimeError(
            "Default credentials do not support domain-wide delegation (with_subject). "
            "Set SERVICE_ACCOUNT_JSON or GOOGLE_APPLICATION_CREDENTIALS to a service account key for DWD."
        )
    delegated = base.with_subject(config.mailbox_user)
    LOGGER.info("Gmail auth mode: dwd (key-based)")
    _proof_once("Gmail auth mode: dwd (key-based)")
    return delegated


def _get_user_oauth_credentials(config: Config):
    """Return user OAuth credentials using a refresh token stored in Secret Manager."""
    client_id = config.gmail_oauth_client_id or _get_secret_value(
        config.project_id, config.gmail_oauth_client_id_secret
    )
    client_secret = config.gmail_oauth_client_secret or _get_secret_value(
        config.project_id, config.gmail_oauth_client_secret_secret
    )
    refresh_token = config.gmail_oauth_refresh_token or _get_secret_value(
        config.project_id, config.gmail_oauth_refresh_token_secret
    )

    missing = [
        name
        for name, value in (
            ("client_id", client_id),
            ("client_secret", client_secret),
            ("refresh_token", refresh_token),
        )
        if not value
    ]
    if missing:
        raise RuntimeError(
            "Missing Gmail OAuth configuration: {}. Ensure the secrets exist or set the corresponding environment variables.".format(
                ", ".join(missing)
            )
        )

    credentials = Credentials(
        token=None,
        refresh_token=refresh_token,
        client_id=client_id,
        client_secret=client_secret,
        token_uri=TOKEN_URI,
        scopes=SCOPES,
    )

    try:
        credentials.refresh(Request())
    except Exception as exc:  # pragma: no cover - network/credential failure
        raise RuntimeError(
            "Failed to refresh Gmail OAuth credentials. Verify the refresh token and that the OAuth client remains active."
        ) from exc

    return credentials


def _get_credentials(config: Config):
    auth_mode = getattr(config, "auth_mode", "dwd_preferred")
    if auth_mode == "user_oauth_only":
        LOGGER.info("Gmail auth mode: user_oauth_only (user OAuth fallback only)")
        _proof_once("Gmail auth mode: user_oauth_only (user OAuth fallback only)")
        return _get_user_oauth_credentials(config)
    if auth_mode == "dwd_required":
        try:
            creds = _get_dwd_credentials(config)
            return creds
        except Exception as exc:
            LOGGER.error("DWD required but failed: %s", exc)
            _proof_once("DWD required but failed: {}".format(exc))
            if not _has_key_based_dwd_config(config):
                raise RuntimeError(
                    "Keyless DWD failed: {}. "
                    "Check: (1) IAM Credentials API enabled, "
                    "(2) roles/iam.serviceAccountTokenCreator on signing SA to self, "
                    "(3) Workspace Admin DWD allowlist for Gmail scopes.".format(exc)
                ) from exc
            raise RuntimeError(
                "AUTH_MODE=dwd_required but domain-wide delegation failed. "
                "Ensure Workspace Admin has allowlisted the service account client ID for Gmail scopes, "
                "and that SERVICE_ACCOUNT_JSON or GOOGLE_APPLICATION_CREDENTIALS is set for the SA key."
            ) from exc
    # dwd_preferred: try DWD first, then user OAuth fallback
    try:
        creds = _get_dwd_credentials(config)
        return creds
    except Exception as dwd_exc:
        LOGGER.info("DWD failed, trying user OAuth fallback: %s", dwd_exc)
        try:
            LOGGER.info("Gmail auth mode: user_oauth_fallback")
            _proof_once("Gmail auth mode: user_oauth_fallback")
            return _get_user_oauth_credentials(config)
        except Exception as fallback_exc:
            raise RuntimeError(
                "DWD failed ({}); user OAuth fallback also failed ({}). "
                "Fix DWD (keyless or SA key + Workspace allowlist) or ensure OAuth secrets are set.".format(
                    dwd_exc, fallback_exc
                )
            ) from dwd_exc


def gmail_client(config: Config):
    credentials = _get_credentials(config)
    return build("gmail", "v1", credentials=credentials, cache_discovery=False)


def drive_client(config: Config):
    credentials = _get_credentials(config)
    return build("drive", "v3", credentials=credentials, cache_discovery=False)


def firestore_client(config: Config) -> firestore.Client:
    return firestore.Client(project=config.project_id)


def storage_client(config: Config) -> storage.Client:
    return storage.Client(project=config.project_id)
