"""Configuration helper for the MediLink Gmail cloud orchestrator."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import Any, Dict, List, Optional


def _get_env(name: str, default: Optional[str] = None, *, required: bool = False) -> str:
    value = os.getenv(name, default)
    if required and not value:
        raise RuntimeError("Missing required environment variable: {}".format(name))
    return value  # type: ignore[return-value]


def _load_json_env(name: str) -> Optional[Dict[str, Any]]:
    raw = os.getenv(name)
    if not raw:
        return None
    try:
        return json.loads(raw)
    except Exception as exc:  # pragma: no cover - defensive
        raise RuntimeError("Environment variable {} does not contain valid JSON".format(name)) from exc


@dataclass(frozen=True)
class Config:
    """Runtime configuration derived from environment variables."""

    project_id: str
    mailbox_user: str
    gcs_bucket: str
    firestore_queue_collection: str
    firestore_state_collection: str
    signed_url_ttl_seconds: int
    jwt_issuer: str
    jwt_audience: str
    client_machine_claim: str
    jwks_url: Optional[str]
    xp_public_key_pem: Optional[str]
    xp_jwt_algorithm: str
    service_account_info: Optional[Dict[str, Any]]

    gmail_auth_method: str
    auth_mode: str  # dwd_preferred | dwd_required | user_oauth_only
    gmail_oauth_client_id: Optional[str]
    gmail_oauth_client_secret: Optional[str]
    gmail_oauth_refresh_token: Optional[str]
    gmail_oauth_client_id_secret: Optional[str]
    gmail_oauth_client_secret_secret: Optional[str]
    gmail_oauth_refresh_token_secret: Optional[str]

    enable_cleanup_on_ack: bool
    default_machine_id: Optional[str]
    gmail_processed_label: Optional[str]
    gmail_remove_labels: List[str]
    cleanup_gcs_files: bool
    ready_batch_size: int
    admin_shared_secret: Optional[str]
    
    # Filter configuration for GAS parity
    gmail_label_ids: List[str]
    gmail_pubsub_topic: str
    allowed_attachment_extensions: List[str]
    allowed_sender_domains: Optional[List[str]]

    # Preprocessor
    preprocessor_mode: str  # shadow | enforce; default shadow
    firestore_ingest_errors_collection: str

    @property
    def queue_collection_path(self) -> str:
        return self.firestore_queue_collection

    @property
    def state_collection_path(self) -> str:
        return self.firestore_state_collection

    @property
    def ingest_errors_collection_path(self) -> str:
        return self.firestore_ingest_errors_collection


def load_config() -> Config:
    project_id = _get_env("PROJECT_ID", required=True)
    mailbox_user = _get_env("MAILBOX_USER", required=True)
    gcs_bucket = _get_env("GCS_BUCKET", required=True)

    queue_collection = _get_env("FIRESTORE_QUEUE_COLLECTION", "queues")
    state_collection = _get_env("FIRESTORE_STATE_COLLECTION", "sync_state")

    signed_url_ttl = int(_get_env("SIGNED_URL_TTL_SECONDS", "3600"))

    jwt_issuer = _get_env("JWT_ISSUER", "medilink-orchestrator")
    jwt_audience = _get_env("JWT_AUDIENCE", "medilink-xp-agent")
    client_machine_claim = _get_env("JWT_MACHINE_ID_CLAIM", "machine_id")

    jwks_url = _get_env("XP_JWKS_URL")
    xp_public_key_pem = _get_env("XP_AGENT_PUBLIC_KEY_PEM")
    xp_jwt_algorithm = _get_env("XP_AGENT_JWT_ALGORITHM", "RS256")

    service_account_info = _load_json_env("SERVICE_ACCOUNT_JSON")

    gmail_auth_method = _get_env("GMAIL_AUTH_METHOD", "service_account").lower()
    auth_mode_raw = _get_env("AUTH_MODE", "").lower()
    if auth_mode_raw in ("dwd_preferred", "dwd_required", "user_oauth_only"):
        auth_mode = auth_mode_raw
    elif gmail_auth_method == "user_oauth":
        auth_mode = "user_oauth_only"
    else:
        auth_mode = "dwd_preferred"
    gmail_oauth_client_id = _get_env("GMAIL_OAUTH_CLIENT_ID")
    gmail_oauth_client_secret = _get_env("GMAIL_OAUTH_CLIENT_SECRET")
    gmail_oauth_refresh_token = _get_env("GMAIL_OAUTH_REFRESH_TOKEN")
    gmail_oauth_client_id_secret = _get_env("GMAIL_OAUTH_CLIENT_ID_SECRET", "gmail_oauth_client_id")
    gmail_oauth_client_secret_secret = _get_env("GMAIL_OAUTH_CLIENT_SECRET_SECRET", "gmail_oauth_client_secret")
    gmail_oauth_refresh_token_secret = _get_env("GMAIL_OAUTH_REFRESH_TOKEN_SECRET", "gmail_oauth_refresh_token")

    enable_cleanup = _get_env("ENABLE_CLEANUP_ON_ACK", "true").lower() in ("1", "true", "yes")
    default_machine_id = _get_env("DEFAULT_MACHINE_ID")

    processed_label = _get_env("GMAIL_PROCESSED_LABEL")
    remove_labels_raw = _get_env("GMAIL_REMOVE_LABEL_IDS", "")
    remove_labels = [label.strip() for label in remove_labels_raw.split(",") if label.strip()]
    cleanup_gcs_files = _get_env("CLEANUP_GCS_FILES", "true").lower() in ("1", "true", "yes")
    ready_batch_size = int(_get_env("READY_BATCH_SIZE", "10"))
    admin_shared_secret = _get_env("ADMIN_SHARED_SECRET")
    
    # Filter configuration for GAS parity
    gmail_label_ids_raw = _get_env("GMAIL_LABEL_IDS", "")
    gmail_label_ids = [label.strip() for label in gmail_label_ids_raw.split(",") if label.strip()]
    gmail_pubsub_topic = _get_env("GMAIL_PUBSUB_TOPIC", "gmail-new-emails")
    
    # Default to docx,csv to match GAS behavior
    allowed_exts_raw = _get_env("ALLOWED_ATTACHMENT_EXTENSIONS", "docx,csv")
    allowed_exts = [ext.strip().lower().lstrip(".") for ext in allowed_exts_raw.split(",") if ext.strip()]
    
    # Optional sender filtering
    sender_domains_raw = _get_env("ALLOWED_SENDER_DOMAINS", "")
    sender_domains = [domain.strip().lower() for domain in sender_domains_raw.split(",") if domain.strip()] if sender_domains_raw else None

    # Preprocessor: shadow (default) or enforce
    preprocessor_mode_raw = _get_env("PREPROCESSOR_MODE", "shadow").lower()
    preprocessor_mode = preprocessor_mode_raw if preprocessor_mode_raw in ("shadow", "enforce") else "shadow"
    firestore_ingest_errors_collection = _get_env("FIRESTORE_INGEST_ERRORS_COLLECTION", "ingest_errors")

    return Config(
        project_id=project_id,
        mailbox_user=mailbox_user,
        gcs_bucket=gcs_bucket,
        firestore_queue_collection=queue_collection,
        firestore_state_collection=state_collection,
        signed_url_ttl_seconds=signed_url_ttl,
        jwt_issuer=jwt_issuer,
        jwt_audience=jwt_audience,
        client_machine_claim=client_machine_claim,
        jwks_url=jwks_url,
        xp_public_key_pem=xp_public_key_pem,
        xp_jwt_algorithm=xp_jwt_algorithm,
        service_account_info=service_account_info,
        gmail_auth_method=gmail_auth_method,
        auth_mode=auth_mode,
        gmail_oauth_client_id=gmail_oauth_client_id,
        gmail_oauth_client_secret=gmail_oauth_client_secret,
        gmail_oauth_refresh_token=gmail_oauth_refresh_token,
        gmail_oauth_client_id_secret=gmail_oauth_client_id_secret,
        gmail_oauth_client_secret_secret=gmail_oauth_client_secret_secret,
        gmail_oauth_refresh_token_secret=gmail_oauth_refresh_token_secret,
        enable_cleanup_on_ack=enable_cleanup,
        default_machine_id=default_machine_id,
        gmail_processed_label=processed_label,
        gmail_remove_labels=remove_labels,
        cleanup_gcs_files=cleanup_gcs_files,
        ready_batch_size=ready_batch_size,
        admin_shared_secret=admin_shared_secret,
        gmail_label_ids=gmail_label_ids,
        gmail_pubsub_topic=gmail_pubsub_topic,
        allowed_attachment_extensions=allowed_exts,
        allowed_sender_domains=sender_domains,
        preprocessor_mode=preprocessor_mode,
        firestore_ingest_errors_collection=firestore_ingest_errors_collection,
    )

