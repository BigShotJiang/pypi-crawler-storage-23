"""FastAPI application exposing sync endpoints and Pub/Sub handler."""

from __future__ import annotations

import base64
import datetime as dt
import binascii
import json
import logging
import os
from typing import Any, Dict, List, Optional

from fastapi import Body, Depends, FastAPI, Header, HTTPException, Request, status
from fastapi.responses import JSONResponse, StreamingResponse
from google.cloud import firestore
from googleapiclient.errors import HttpError
from starlette.background import BackgroundTask

try:
    from google.api_core import exceptions as gax_exceptions
except Exception:  # pragma: no cover - optional dependency guard
    gax_exceptions = None


def _serialize_timestamp(value: Any) -> Any:
    try:
        if value is None:
            return value
        iso = value.isoformat()  # type: ignore[attr-defined]
        return iso
    except Exception:
        return value


def _format_received_at(value: Any) -> Any:
    if not value:
        return value
    try:
        millis = int(value)
        iso = dt.datetime.utcfromtimestamp(millis / 1000.0).isoformat() + "Z"
        return iso
    except Exception:
        return value

from auth import AuthError, validate_machine_id, verify_agent_jwt
from cleanup import perform_cleanup
from config import Config, load_config
import processor
import services
from watch import normalize_label_ids, register_gmail_watch


LOGGER = logging.getLogger("medilink.orchestrator.api")

# Load config lazily to avoid startup failures when env vars aren't set yet
_CONFIG = None

# Log once per process per endpoint when admin endpoint is called but ADMIN_SHARED_SECRET is not set (avoids log spam)
_ADMIN_SECRET_UNSET_LOGGED: Dict[str, bool] = {}


class PermanentPubSubPayloadError(ValueError):
    """Raised when Pub/Sub payload is malformed and should be acknowledged."""


def _validate_admin_payload(
    payload: Dict[str, Any],
    config: Config,
    endpoint_name: str,
    caller: Optional[str] = None,
) -> None:
    """
    Validate admin secret for admin endpoints.
    Raises 500 if ADMIN_SHARED_SECRET not configured; 403 if secret missing or wrong.
    """
    if not config.admin_shared_secret:
        if not _ADMIN_SECRET_UNSET_LOGGED.get(endpoint_name):
            _ADMIN_SECRET_UNSET_LOGGED[endpoint_name] = True
            LOGGER.error("ADMIN_SHARED_SECRET not set but %s was called", endpoint_name)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Internal Server Error")
    secret = payload.get("secret")
    if not secret or secret != config.admin_shared_secret:
        if caller:
            LOGGER.info("%s outcome=failure reason=forbidden caller=%s", endpoint_name, caller)
        else:
            LOGGER.info("%s outcome=failure reason=forbidden", endpoint_name)
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Forbidden")

def validate_startup_environment():
    """Validate that critical environment variables are set."""
    required_vars = ['PROJECT_ID', 'MAILBOX_USER', 'GCS_BUCKET']
    missing = []

    for var in required_vars:
        if not os.environ.get(var):
            missing.append(var)

    if missing:
        LOGGER.warning(f"Missing required environment variables: {missing}")
        LOGGER.warning("Using placeholder config - some features may not work")

    return len(missing) == 0

def get_config():
    global _CONFIG
    if _CONFIG is None:
        try:
            # Validate environment first
            env_valid = validate_startup_environment()

            _CONFIG = load_config()
            LOGGER.info("Configuration loaded successfully")
        except Exception as e:
            LOGGER.error(f"Failed to load config: {e}")
            # Return a minimal config for health checks during startup
            from config import Config
            _CONFIG = Config(
                project_id="placeholder",
                mailbox_user="placeholder@domain.com",
                gcs_bucket="placeholder-bucket",
                firestore_queue_collection="queues",
                firestore_state_collection="sync_state",
                signed_url_ttl_seconds=3600,
                jwt_issuer="medilink-orchestrator",
                jwt_audience="medilink-xp-agent",
                client_machine_claim="machine_id",
                jwks_url=None,
                xp_public_key_pem=None,
                xp_jwt_algorithm="RS256",
                service_account_info=None,
                gmail_auth_method="service_account",
                auth_mode="dwd_preferred",
                gmail_oauth_client_id=None,
                gmail_oauth_client_secret=None,
                gmail_oauth_refresh_token=None,
                gmail_oauth_client_id_secret="gmail_oauth_client_id",
                gmail_oauth_client_secret_secret="gmail_oauth_client_secret",
                gmail_oauth_refresh_token_secret="gmail_oauth_refresh_token",
                enable_cleanup_on_ack=True,
                default_machine_id=None,
                gmail_processed_label=None,
                gmail_remove_labels=[],
                cleanup_gcs_files=True,
                ready_batch_size=10,
                admin_shared_secret=None,
                gmail_label_ids=[],
                gmail_pubsub_topic="gmail-new-emails",
                allowed_attachment_extensions=["docx", "csv"],
                allowed_sender_domains=None,
                preprocessor_mode="shadow",
                firestore_ingest_errors_collection="ingest_errors",
            )
    return _CONFIG

APP = FastAPI(title="MediLink Gmail Orchestrator", version="1.0.0")


@APP.get("/")
async def root() -> Dict[str, Any]:
    """Root path for Cloud Run / load balancer probes; avoids 404 on GET /."""
    return {"status": "ok", "service": "medilink-gmail-orchestrator"}


def _extract_bearer_token(authorization: str) -> str:
    if not authorization:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Missing Authorization header")
    scheme, _, token = authorization.partition(" ")
    if scheme.lower() != "bearer" or not token:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid Authorization header")
    return token


def authenticate(authorization: str = Header(default="")) -> Dict[str, Any]:
    try:
        token = _extract_bearer_token(authorization)
        return verify_agent_jwt(token, get_config())
    except AuthError as exc:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=str(exc)) from exc


@APP.get("/health")
async def healthcheck() -> Dict[str, Any]:
    # Health check should work even if config isn't fully loaded yet
    response = {
        "status": "ok",
        "service": "medilink-gmail-orchestrator",
        "version": "1.0.0"
    }

    try:
        config = get_config()
        # Try to access a required config field to test if it's loaded
        response["config_loaded"] = "true"
        response["project_id"] = config.project_id[:10] + "..." if len(config.project_id) > 10 else config.project_id
        response["mailbox_user"] = config.mailbox_user
    except Exception as e:
        # If config isn't loaded yet, still return OK for health check
        response["config_loaded"] = "false"
        response["config_error"] = str(e)

    # Add system info
    import platform
    response["python_version"] = platform.python_version()

    return response

def _extract_caller_from_request(request: Request) -> str:
    """Extract caller identity from OIDC token when available (no secrets)."""
    auth = request.headers.get("Authorization") or ""
    if not auth.startswith("Bearer "):
        return "unknown"
    token = auth[7:].strip()
    if not token:
        return "unknown"
    try:
        parts = token.split(".")
        if len(parts) != 3:
            return "unknown"
        import base64
        payload_b64 = parts[1]
        padding = 4 - len(payload_b64) % 4
        if padding != 4:
            payload_b64 += "=" * padding
        payload = json.loads(base64.urlsafe_b64decode(payload_b64))
        email = payload.get("email") or payload.get("sub")
        return email or "unknown"
    except Exception:
        return "unknown"


def _parse_pubsub_push_payload(envelope: Any) -> Dict[str, Any]:
    """Parse Pub/Sub envelope and return normalized payload + message_id."""
    if not isinstance(envelope, dict):
        raise PermanentPubSubPayloadError("envelope_not_object")
    message = envelope.get("message")
    if not isinstance(message, dict):
        raise PermanentPubSubPayloadError("message_missing_or_not_object")
    message_id = str(message.get("messageId") or "unknown")
    data = message.get("data")
    if not data:
        raise PermanentPubSubPayloadError("missing_data")
    if not isinstance(data, str):
        raise PermanentPubSubPayloadError("data_not_string")

    try:
        decoded_bytes = base64.b64decode(data, validate=True)
    except (binascii.Error, ValueError):
        raise PermanentPubSubPayloadError("invalid_base64")
    try:
        decoded_text = decoded_bytes.decode("utf-8")
    except UnicodeDecodeError:
        raise PermanentPubSubPayloadError("invalid_utf8")
    try:
        decoded = json.loads(decoded_text)
    except json.JSONDecodeError:
        raise PermanentPubSubPayloadError("invalid_json")
    if not isinstance(decoded, dict):
        raise PermanentPubSubPayloadError("decoded_payload_not_object")

    out = dict(decoded)
    out["_pubsub_message_id"] = message_id
    return out


def _classify_processing_exception(exc: Exception) -> Dict[str, Any]:
    """Classify processing exceptions into retryable/non-retryable buckets."""
    if isinstance(exc, HttpError):
        status_code = getattr(getattr(exc, "resp", None), "status", None)
        return {
            "error_class": "downstream_http_error",
            # Reliability-safe default: processing/downstream failures should retry and eventually DLQ.
            "retryable": True,
            "status_code": status_code,
        }

    if gax_exceptions is not None:
        retryable_names = (
            "ServiceUnavailable",
            "TooManyRequests",
            "DeadlineExceeded",
            "InternalServerError",
            "GoogleAPICallError",
        )
        retryable_types = tuple(
            getattr(gax_exceptions, name)
            for name in retryable_names
            if hasattr(gax_exceptions, name)
        )
        if retryable_types and isinstance(exc, retryable_types):
            return {"error_class": "google_api_error", "retryable": True}

    if isinstance(exc, (TimeoutError, ConnectionError, OSError)):
        return {"error_class": "network_or_os_error", "retryable": True}

    # Safe-by-default for reliability: unknown processor/downstream failures retry.
    return {"error_class": "processing_exception_retryable", "retryable": True}


@APP.post("/setup-gmail-watch")
async def setup_gmail_watch(request: Request, payload: Optional[Dict[str, Any]] = Body(default=None)) -> Dict[str, Any]:
    """
    Admin endpoint to register Gmail watch.
    Requires IAM invoker (Cloud Run enforces when --no-allow-unauthenticated) and
    ADMIN_SHARED_SECRET in payload. Uses canonical register_gmail_watch(config).
    """
    payload = payload or {}

    config = get_config()
    caller = _extract_caller_from_request(request)
    _validate_admin_payload(payload, config, "setup-gmail-watch", caller=caller)

    try:
        detail, history_id, watch_response = register_gmail_watch(config)
        LOGGER.info("setup-gmail-watch outcome=success caller=%s", caller)
        return {"status": "success", "message": detail, "watch_details": watch_response}
    except HTTPException:
        raise
    except Exception as e:
        LOGGER.error(
            "setup-gmail-watch outcome=failure caller=%s: %s",
            caller,
            e,
            exc_info=True,
        )
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Internal Server Error")


@APP.post("/pubsub/push")
async def pubsub_push(request: Request) -> JSONResponse:
    """Handle Pub/Sub push with retry-safe semantics."""
    try:
        envelope = await request.json()
    except Exception:
        LOGGER.warning(
            "PUBSUB_PUSH outcome=acked_permanent_error message_id=unknown "
            "error_class=invalid_envelope_json retryable=False"
        )
        return JSONResponse(
            {
                "status": "acked_permanent_error",
                "message_id": "unknown",
                "error_class": "invalid_envelope_json",
                "retryable": False,
            },
            status_code=200,
        )

    message_id = "unknown"
    try:
        decoded = _parse_pubsub_push_payload(envelope)
        message_id = str(decoded.get("_pubsub_message_id") or "unknown")
        decoded.pop("_pubsub_message_id", None)
    except PermanentPubSubPayloadError as exc:
        maybe_message = envelope.get("message") if isinstance(envelope, dict) else None
        if isinstance(maybe_message, dict):
            message_id = str(maybe_message.get("messageId") or "unknown")
        error_class = str(exc)
        LOGGER.warning(
            "PUBSUB_PUSH outcome=acked_permanent_error message_id=%s "
            "error_class=%s retryable=False",
            message_id,
            error_class,
        )
        return JSONResponse(
            {
                "status": "acked_permanent_error",
                "message_id": message_id,
                "error_class": error_class,
                "retryable": False,
            },
            status_code=200,
        )

    try:
        result = processor.process_history_event(decoded, get_config())
        LOGGER.info(
            "PUBSUB_PUSH outcome=processed message_id=%s error_class=none retryable=False",
            message_id,
        )
        return JSONResponse({"status": "ok", "result": result, "message_id": message_id}, status_code=200)
    except Exception as process_error:
        classification = _classify_processing_exception(process_error)
        error_class = classification.get("error_class", "processing_exception_retryable")
        retryable = bool(classification.get("retryable", True))
        if retryable:
            LOGGER.error(
                "PUBSUB_PUSH outcome=retryable_error message_id=%s "
                "error_class=%s retryable=True",
                message_id,
                error_class,
                exc_info=True,
            )
            return JSONResponse(
                {
                    "status": "retryable_error",
                    "message_id": message_id,
                    "error_class": error_class,
                    "retryable": True,
                },
                status_code=503,
            )

        LOGGER.warning(
            "PUBSUB_PUSH outcome=acked_non_retryable_error message_id=%s "
            "error_class=%s retryable=False",
            message_id,
            error_class,
            exc_info=True,
        )
        return JSONResponse(
            {
                "status": "acked_non_retryable_error",
                "message_id": message_id,
                "error_class": error_class,
                "retryable": False,
            },
            status_code=200,
        )


def _build_ready_payload(
    machine_id: str,
    snapshot: firestore.DocumentSnapshot,
    fs_client: firestore.Client,
) -> Dict[str, Any]:
    data = snapshot.to_dict() or {}
    data_machine = data.get("machine_id")
    if machine_id != data_machine:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Machine not authorised for this item")

    files = []
    for item in data.get("files", []):
        download_token = item.get("download_token")
        if not download_token:
            continue
        files.append(
            {
                "filename": item.get("filename"),
                "checksum": item.get("checksum"),
                "size": item.get("size"),
                "mime_type": item.get("mime_type"),
                "download_path": "/files/{}/{}".format(snapshot.id, download_token),
            }
        )

    doc_ref = fs_client.collection(get_config().queue_collection_path).document(snapshot.id)
    doc_ref.update({"last_ready_at": firestore.SERVER_TIMESTAMP, "updated_at": firestore.SERVER_TIMESTAMP})

    return {
        "id": snapshot.id,
        "otp_required": data.get("otp_required", False),
        "otp_token": data.get("otp_token"),
        "files": files,
        "message_id": data.get("message_id"),
        "thread_id": data.get("thread_id"),
        "created_at": _serialize_timestamp(data.get("created_at")),
        "subject": data.get("subject"),
        "received_at": _format_received_at(data.get("received_at")),
    }


@APP.get("/ready/{machine_id}")
async def ready(machine_id: str, claims: Dict[str, Any] = Depends(authenticate)) -> Dict[str, Any]:
    validate_machine_id(claims, machine_id, get_config())
    fs_client = services.firestore_client(get_config())
    query = (
        fs_client.collection(get_config().queue_collection_path)
        .where("machine_id", "==", machine_id)
        .where("acked", "==", False)
        .order_by("created_at")
        .limit(get_config().ready_batch_size)
    )
    snapshots = list(query.stream())
    items = [_build_ready_payload(machine_id, snapshot, fs_client) for snapshot in snapshots]
    return {"ready": items, "poll_after_seconds": 10}


@APP.get("/files/{item_id}/{download_token}")
async def download_file(item_id: str, download_token: str, claims: Dict[str, Any] = Depends(authenticate)) -> StreamingResponse:
    fs_client = services.firestore_client(get_config())
    doc_ref = fs_client.collection(get_config().queue_collection_path).document(item_id)
    snapshot = doc_ref.get()
    if not snapshot.exists:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Queue item not found")

    data = snapshot.to_dict() or {}
    machine_id = data.get("machine_id")
    validate_machine_id(claims, machine_id, get_config())

    file_entry = None
    for candidate in data.get("files", []):
        if candidate.get("download_token") == download_token:
            file_entry = candidate
            break

    if not file_entry:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="File not found")

    gcs_path = file_entry.get("gcs_path")
    if not gcs_path:
        raise HTTPException(status_code=status.HTTP_410_GONE, detail="File no longer available")

    storage_client = services.storage_client(get_config())
    bucket = storage_client.bucket(get_config().gcs_bucket)
    blob = bucket.blob(gcs_path)
    if not blob.exists():
        raise HTTPException(status_code=status.HTTP_410_GONE, detail="File no longer available")
    stream = blob.open("rb")

    def _close_stream():  # pragma: no cover - network resource cleanup
        try:
            stream.close()
        except Exception:
            pass

    headers = {
        "Content-Disposition": 'attachment; filename="{}"'.format(file_entry.get("filename", "attachment")),
    }
    return StreamingResponse(
        stream,
        media_type=file_entry.get("mime_type") or "application/octet-stream",
        headers=headers,
        background=BackgroundTask(_close_stream),
    )


def _update_ack_document(
    doc_ref: firestore.DocumentReference,
    doc_data: Dict[str, Any],
    files: List[Dict[str, Any]],
    otp_token: Optional[str],
):
    updates = {
        "acked": True,
        "ack_payload": files,
        "acknowledged_at": firestore.SERVER_TIMESTAMP,
        "updated_at": firestore.SERVER_TIMESTAMP,
    }
    if otp_token:
        updates["otp_completed_token"] = otp_token
    doc_ref.update(updates)


@APP.post("/ack")
async def acknowledge(payload: Dict[str, Any], claims: Dict[str, Any] = Depends(authenticate)) -> Dict[str, str]:
    item_id = payload.get("item_id")
    machine_id = payload.get("machine_id")
    if not item_id or not machine_id:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="item_id and machine_id required")

    validate_machine_id(claims, machine_id, get_config())

    fs_client = services.firestore_client(get_config())
    doc_ref = fs_client.collection(get_config().queue_collection_path).document(item_id)
    snapshot = doc_ref.get()
    if not snapshot.exists:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Queue item not found")

    doc_data = snapshot.to_dict() or {}
    if doc_data.get("machine_id") != machine_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Machine not authorised for item")
    if doc_data.get("acked"):
        return {"status": "already_acknowledged"}

    otp_required = doc_data.get("otp_required", False)
    otp_token = payload.get("otp_token")
    if otp_required:
        expected = doc_data.get("otp_token")
        if not otp_token or otp_token != expected:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="OTP token mismatch")

    files = payload.get("files", []) or []
    _update_ack_document(doc_ref, doc_data, files, otp_token)

    if get_config().enable_cleanup_on_ack:
        perform_cleanup(doc_data, get_config())

    return {"status": "acknowledged"}


@APP.post("/admin/resume-history")
async def resume_history(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Admin endpoint for Gmail watch refresh (scheduler). Disabled unless ADMIN_SHARED_SECRET is set.
    """
    # Stable log line for verification (no secrets)
    LOGGER.info("resume-history invoked")
    # Also print the proof line. In some Cloud Run logging configurations, INFO logs can be filtered or
    # mapped to DEFAULT severity; printing makes the proof visible in `gcloud run services logs read`.
    try:
        print("resume-history invoked", flush=True)
    except Exception:
        pass

    config = get_config()
    _validate_admin_payload(payload, config, "resume-history")

    # Accept either history_id (our admin payload) or historyId (Pub/Sub/Gmail style).
    # If absent or invalid, derive a safe starting point from the mailbox profile.
    history_id = payload.get("history_id") or payload.get("historyId")
    if not history_id or not str(history_id).isdigit():
        try:
            gmail = services.gmail_client(config)
            profile = gmail.users().getProfile(userId="me").execute()
            derived = profile.get("historyId")
            if derived and str(derived).isdigit():
                history_id = derived
                LOGGER.info("Derived historyId from Gmail profile for admin resume-history: %s", history_id)
            else:
                raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Internal Server Error")
        except HTTPException:
            raise
        except Exception as exc:
            LOGGER.error("Failed to derive historyId for admin resume-history: %s", exc, exc_info=True)
            raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Internal Server Error")

    # Wrap process_history_event with exception handler (single outer handler)
    try:
        result = processor.process_history_event({"historyId": str(history_id)}, config)
        return {"status": "ok", "result": result}
    except Exception as exc:
        # Log full traceback with context; keep response body generic
        LOGGER.error(
            "Failed to process history event in /admin/resume-history (historyId=%s): %s",
            history_id,
            exc,
            exc_info=True
        )
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Internal Server Error")


def _validate_label_ids_for_backfill(label_ids: Optional[List[Any]]) -> Optional[List[str]]:
    """
    Validate label_ids for backfill: length <= 20, each non-empty string.
    Returns None if invalid (caller returns 400), else list of strings.
    """
    if label_ids is None:
        return None
    if not isinstance(label_ids, list):
        return None
    if len(label_ids) > 20:
        return None
    seen = []
    for item in label_ids:
        if not isinstance(item, str) or not (item or "").strip():
            return None
        seen.append(str(item).strip())
    return seen


@APP.post("/admin/backfill-backlog")
async def backfill_backlog(
    request: Request,
    payload: Optional[Dict[str, Any]] = Body(default=None),
) -> Dict[str, Any]:
    """
    Admin endpoint for Gmail backlog backfill. Requires ADMIN_SHARED_SECRET.
    Body: { "secret": "...", "label_ids": [...], "batch_size": 20, "preview_only": false }.
    preview_only=true: returns has_backlog check. Otherwise runs backfill.
    """
    payload = payload or {}
    config = get_config()
    caller = _extract_caller_from_request(request)
    _validate_admin_payload(payload, config, "backfill-backlog", caller=caller)

    raw_labels = payload.get("label_ids")
    if raw_labels is not None:
        label_ids = _validate_label_ids_for_backfill(raw_labels)
        if label_ids is None:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="label_ids must be a list of up to 20 non-empty strings",
            )
        if len(label_ids) == 0:
            label_ids = normalize_label_ids(from_list=config.gmail_label_ids or [])
    else:
        label_ids = normalize_label_ids(from_list=config.gmail_label_ids or [])

    batch_size = payload.get("batch_size", 20)
    try:
        batch_size = int(batch_size) if batch_size is not None else 20
    except (TypeError, ValueError):
        batch_size = 20
    batch_size = min(max(1, batch_size), 100)

    preview_only = payload.get("preview_only") is True

    try:
        if preview_only:
            has_backlog = processor.has_backlog(config, label_ids)
            return {"mode": "preview", "has_backlog": has_backlog}
        result = processor.run_backfill(config, label_ids=label_ids, batch_size=batch_size)
        status_val = "partial_failure" if result["failed_count"] > 0 else "ok"
        return {
            "mode": "run",
            "status": status_val,
            "scanned_count": result["scanned_count"],
            "processed_count": result["processed_count"],
            "skipped_count": result["skipped_count"],
            "failed_count": result["failed_count"],
        }
    except HTTPException:
        raise
    except Exception as exc:
        LOGGER.error(
            "backfill-backlog outcome=failure caller=%s: %s",
            caller,
            exc,
            exc_info=True,
        )
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Internal Server Error")

