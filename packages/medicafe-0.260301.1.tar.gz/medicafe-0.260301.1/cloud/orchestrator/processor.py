"""Pub/Sub event processing for Gmail notifications."""

from __future__ import annotations

import base64
import datetime as dt
import hashlib
import logging
import uuid
from typing import Any, Dict, Iterable, List, Optional, Tuple

from google.cloud import firestore
from google.cloud import storage
from googleapiclient.errors import HttpError

import itertools

from config import Config
import preprocessor
import services

try:
    from . import watch
except ImportError:
    import watch


LOGGER = logging.getLogger("medilink.orchestrator.processor")


class MachineIdResolutionError(RuntimeError):
    """Raised when machine_id cannot be determined from message/routing."""



HISTORY_TYPES = ["messageAdded"]


def _utcnow() -> dt.datetime:
    return dt.datetime.utcnow().replace(tzinfo=dt.timezone.utc)


def _ensure_state_document(config: Config, fs_client: firestore.Client) -> firestore.DocumentReference:
    doc_ref = fs_client.collection(config.state_collection_path).document("gmail")
    if not doc_ref.get().exists:
        doc_ref.set({"last_history_id": None, "created_at": _utcnow()})
    return doc_ref


def _find_existing_queue_doc(
    fs_client: firestore.Client, config: Config, message_id: str
) -> Optional[firestore.DocumentSnapshot]:
    query = (
        fs_client.collection(config.queue_collection_path)
        .where("message_id", "==", message_id)
        .limit(1)
    )
    docs = list(query.stream())
    return docs[0] if docs else None


def _get_header(message: Dict[str, Any], header_name: str) -> Optional[str]:
    payload = message.get("payload", {})
    headers = payload.get("headers", [])
    for header in headers:
        if header.get("name", "").lower() == header_name.lower():
            return header.get("value")
    return None


def _detect_secure_message(message: Dict[str, Any]) -> bool:
    subject = (_get_header(message, "Subject") or "").lower()
    snippet = (message.get("snippet") or "").lower()
    if "protected message" in subject or "secure message" in subject:
        return True
    if "secure message" in snippet:
        return True
    return False


def _is_sender_allowed(message: Dict[str, Any], config: Config) -> bool:
    """Check if the sender is in the allowed list (if configured)."""
    if not config.allowed_sender_domains:
        return True  # No filter configured, allow all
    
    from_header = (_get_header(message, "From") or "").lower()
    for domain in config.allowed_sender_domains:
        if domain in from_header:
            return True
    
    return False


def _extract_machine_id(message: Dict[str, Any], config: Config, fs_client: firestore.Client) -> str:
    # Owner decision: when DEFAULT_MACHINE_ID is set, it is authoritative; ignore header.
    # Rationale: single-site, removes header spoof risk, deterministic during stabilization.
    if config.default_machine_id and config.default_machine_id.strip():
        return config.default_machine_id.strip()

    # When default not set: header can override, then Firestore routing
    explicit_header = _get_header(message, "X-MediLink-Clinic")
    if explicit_header:
        return explicit_header.strip().lower()

    # Multi-machine routing: check Firestore routing document
    to_header = _get_header(message, "Delivered-To") or _get_header(message, "To") or ""
    to_header = to_header.lower()
    routing_doc = fs_client.collection(config.state_collection_path).document("routing").get()
    if routing_doc.exists:
        data = routing_doc.to_dict() or {}
        mapping = data.get("email_to_machine", {})
        if isinstance(mapping, dict):
            for pattern, machine in mapping.items():
                if pattern and pattern.lower() in to_header:
                    return str(machine)

    raise MachineIdResolutionError("Unable to determine machine id for message {}".format(message.get("id")))


def _upload_attachment(storage_client: storage.Client, bucket_name: str, path: str, data: bytes, content_type: str) -> Tuple[str, str]:
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(path)
    blob.upload_from_string(data, content_type=content_type)
    sha256 = hashlib.sha256(data).hexdigest()
    blob.metadata = blob.metadata or {}
    blob.metadata.update({"sha256": sha256})
    blob.patch()
    return path, sha256


def _iter_attachment_parts(payload: Dict[str, Any]) -> Iterable[Dict[str, Any]]:
    stack = [payload]
    while stack:
        part = stack.pop()
        if part.get("parts"):
            stack.extend(part.get("parts") or [])
        filename = part.get("filename")
        body = part.get("body", {})
        if filename and body.get("attachmentId"):
            yield part


def _collect_attachments(message: Dict[str, Any], gmail_client, storage_client: storage.Client, config: Config, machine_id: str) -> List[Dict[str, Any]]:
    attachments: List[Dict[str, Any]] = []
    payload = message.get("payload", {})
    for part in _iter_attachment_parts(payload):
        safe_filename = part.get("filename") or "attachment-{}.bin".format(uuid.uuid4().hex)
        
        # Filter by allowed extensions (GAS parity)
        if config.allowed_attachment_extensions:
            filename_lower = safe_filename.lower()
            allowed = False
            for ext in config.allowed_attachment_extensions:
                if filename_lower.endswith("." + ext):
                    allowed = True
                    break
            if not allowed:
                LOGGER.debug("Skipping attachment %s (not in allowed extensions)", safe_filename)
                continue
        
        attachment_id = part.get("body", {}).get("attachmentId")
        raw = gmail_client.users().messages().attachments().get(
            userId="me", messageId=message["id"], id=attachment_id
        ).execute()
        data = base64.urlsafe_b64decode(raw.get("data", ""))
        blob_path = "{}/{}/{}".format(machine_id, uuid.uuid4().hex, safe_filename)
        gcs_path, checksum = _upload_attachment(
            storage_client,
            config.gcs_bucket,
            blob_path,
            data,
            part.get("mimeType", "application/octet-stream"),
        )
        attachments.append(
            {
                "filename": safe_filename,
                "mime_type": part.get("mimeType"),
                "size": len(data),
                "gcs_path": gcs_path,
                "checksum": checksum,
                "download_token": uuid.uuid4().hex,
            }
        )
    return attachments


def _persist_queue_entry(
    fs_client: firestore.Client,
    config: Config,
    machine_id: str,
    message: Dict[str, Any],
    attachments: List[Dict[str, Any]],
    otp_required: bool,
    otp_token: Optional[str],
    validated_payload: Optional[Dict[str, Any]] = None,
    attempt_id: Optional[str] = None,
    preprocessor_reject_code: Optional[str] = None,
    preprocessor_reject_reason: Optional[str] = None,
) -> str:
    queues = fs_client.collection(config.queue_collection_path)
    message_id = message["id"]
    existing_snapshot = _find_existing_queue_doc(fs_client, config, message_id)

    if existing_snapshot:
        existing_data = existing_snapshot.to_dict() or {}
        doc_ref = queues.document(existing_snapshot.id)
        if existing_data.get("acked"):
            LOGGER.info("Message %s already processed; skipping re-queue", message.get("id"))
            return existing_snapshot.id

        if validated_payload:
            merged_files = (
                validated_payload["files"]
                if "files" in validated_payload
                else existing_data.get("files", [])
            )
            update_payload = {
                "files": merged_files,
                "otp_required": validated_payload["otp_required"] if "otp_required" in validated_payload else otp_required,
                "otp_token": validated_payload["otp_token"] if "otp_token" in validated_payload else existing_data.get("otp_token"),
                "machine_id": validated_payload["machine_id"] if "machine_id" in validated_payload else machine_id,
                "thread_id": (
                    validated_payload.get("thread_id")
                    if validated_payload.get("thread_id") is not None
                    else message.get("threadId")
                ),
                "history_id": (
                    validated_payload.get("history_id")
                    if validated_payload.get("history_id") is not None
                    else message.get("historyId")
                ),
                "subject": (
                    validated_payload.get("subject")
                    if validated_payload.get("subject") is not None
                    else _get_header(message, "Subject")
                ),
                "received_at": (
                    validated_payload.get("received_at")
                    if validated_payload.get("received_at") is not None
                    else message.get("internalDate")
                ),
                "updated_at": firestore.SERVER_TIMESTAMP,
                "schema_version": validated_payload.get("schema_version"),
                "preprocessor_version": validated_payload.get("preprocessor_version"),
                "attempt_id": attempt_id or validated_payload.get("attempt_id"),
                # Explicitly clear reject markers when candidate is accepted.
                "preprocessor_reject_code": None,
                "preprocessor_reject_reason": None,
            }
        else:
            merged_files = attachments or existing_data.get("files", [])
            update_payload = {
                "files": merged_files,
                "otp_required": otp_required,
                "otp_token": otp_token or existing_data.get("otp_token"),
                "machine_id": machine_id,
                "thread_id": message.get("threadId"),
                "history_id": message.get("historyId"),
                "subject": _get_header(message, "Subject"),
                "received_at": message.get("internalDate"),
                "updated_at": firestore.SERVER_TIMESTAMP,
            }
            if attempt_id:
                update_payload["attempt_id"] = attempt_id
            if preprocessor_reject_code:
                update_payload["preprocessor_reject_code"] = preprocessor_reject_code
                update_payload["preprocessor_reject_reason"] = (preprocessor_reject_reason or "")[:500]
        doc_ref.update(update_payload)
        return existing_snapshot.id

    doc_id = uuid.uuid4().hex
    if validated_payload:
        payload = dict(validated_payload)
        payload["created_at"] = firestore.SERVER_TIMESTAMP
        payload["updated_at"] = firestore.SERVER_TIMESTAMP
        payload["preprocessor_reject_code"] = None
        payload["preprocessor_reject_reason"] = None
    else:
        payload = {
            "machine_id": machine_id,
            "message_id": message_id,
            "thread_id": message.get("threadId"),
            "history_id": message.get("historyId"),
            "otp_required": otp_required,
            "otp_token": otp_token,
            "files": attachments,
            "acked": False,
            "created_at": firestore.SERVER_TIMESTAMP,
            "updated_at": firestore.SERVER_TIMESTAMP,
            "subject": _get_header(message, "Subject"),
            "received_at": message.get("internalDate"),
            "schema_version": "1",
            "preprocessor_version": "1.0",
        }
        if attempt_id:
            payload["attempt_id"] = attempt_id
        if preprocessor_reject_code:
            payload["preprocessor_reject_code"] = preprocessor_reject_code
            payload["preprocessor_reject_reason"] = (preprocessor_reject_reason or "")[:500]
    queues.document(doc_id).set(payload)
    return doc_id


def _record_state(fs_client: firestore.Client, config: Config, history_id: str) -> None:
    doc_ref = _ensure_state_document(config, fs_client)
    doc_ref.update({"last_history_id": history_id, "updated_at": firestore.SERVER_TIMESTAMP})


def _ensure_preprocessor_state(config: Config, fs_client: firestore.Client) -> None:
    """Ensure sync_state/preprocessor exists with shadow_started_at for cohort boundary."""
    doc_ref = fs_client.collection(config.state_collection_path).document("preprocessor")
    if not doc_ref.get().exists:
        doc_ref.set({
            "shadow_started_at": firestore.SERVER_TIMESTAMP,
            "created_at": _utcnow(),
        })


def _write_ingest_error(
    fs_client: firestore.Client,
    config: Config,
    message_id: str,
    machine_id: str,
    reject_code: str,
    reason: str,
    attempt_id: str,
    cleanup_partial_failure: bool = False,
    stage: str = "preprocessor",
) -> None:
    """Write durable ingest_errors record. No raw payload dumps; minimal redacted fields."""
    coll = fs_client.collection(config.ingest_errors_collection_path)
    doc_ref = coll.document()
    payload = {
        "error_id": doc_ref.id,
        "message_id": message_id,
        "machine_id": machine_id or "",
        "reject_code": reject_code,
        "reason": reason[:500] if reason else "",
        "schema_version": preprocessor.SCHEMA_VERSION,
        "preprocessor_version": preprocessor.PREPROCESSOR_VERSION,
        "attempt_id": attempt_id,
        "created_at": firestore.SERVER_TIMESTAMP,
        "updated_at": firestore.SERVER_TIMESTAMP,
        "status": "open",
        "cleanup_partial_failure": cleanup_partial_failure,
    }
    if stage:
        payload["stage"] = stage
    doc_ref.set(payload)


def _cleanup_gcs_attachments(
    storage_client: storage.Client,
    bucket_name: str,
    attachments: List[Dict[str, Any]],
) -> bool:
    """Best-effort delete GCS objects from attachments. Returns True if any delete failed."""
    partial_failure = False
    for item in attachments:
        gcs_path = item.get("gcs_path")
        if not gcs_path:
            continue
        try:
            bucket = storage_client.bucket(bucket_name)
            blob = bucket.blob(gcs_path)
            blob.delete()
        except Exception as exc:
            LOGGER.warning("GCS cleanup failed for %s: %s", gcs_path, exc)
            partial_failure = True
    return partial_failure


def _list_history(gmail_client, start_history_id: str) -> Iterable[Dict[str, Any]]:
    request = gmail_client.users().history().list(
        userId="me", startHistoryId=start_history_id, historyTypes=HISTORY_TYPES
    )
    while request is not None:
        response = request.execute()
        for history_record in response.get("history", []):
            yield history_record
        request = gmail_client.users().history().list_next(request, response)


def _bootstrap_messages(
    gmail_client, config: Config, label_ids_override: Optional[List[str]] = None
) -> Iterable[str]:
    """List message IDs by label (has:attachment). label_ids_override overrides config.gmail_label_ids."""
    query = _build_attachment_query(config, label_ids_override)

    request = gmail_client.users().messages().list(userId="me", q=query)
    while request is not None:
        response = request.execute()
        for message_meta in response.get("messages", []):
            yield message_meta["id"]
        request = gmail_client.users().messages().list_next(request, response)


def _fetch_message(gmail_client, message_id: str) -> Optional[Dict[str, Any]]:
    """
    Fetch a full Gmail message.

    Gmail history can reference message IDs that are no longer retrievable (deleted/expunged/race),
    in which case the Gmail API returns 404 notFound. Treat that as non-fatal and skip the message
    so we can still advance the history checkpoint and avoid endless scheduler 500 retries.
    """
    try:
        return gmail_client.users().messages().get(userId="me", id=message_id, format="full").execute()
    except HttpError as exc:
        status = getattr(getattr(exc, "resp", None), "status", None)
        if status == 404:
            LOGGER.warning("Message not found (404) for message_id=%s; skipping.", message_id)
            return None
        raise


def has_backlog(config: Config, label_ids: Optional[List[str]] = None) -> bool:
    """
    Cheap check: any labeled messages with attachments exist?
    Uses messages.list with label filter + has:attachment, maxResults=1.
    """
    gmail_client = services.gmail_client(config)
    query = _build_attachment_query(config, label_ids)
    response = gmail_client.users().messages().list(
        userId="me", q=query, maxResults=1
    ).execute()
    messages = response.get("messages") or []
    return len(messages) > 0


def run_backfill(
    config: Config,
    label_ids: Optional[List[str]] = None,
    batch_size: int = 20,
) -> Dict[str, Any]:
    """
    Process up to batch_size messages from label-based list. Idempotent by message_id
    path in _persist_queue_entry; already-queued messages are skipped before fetch to
    avoid duplicate GCS downloads.

    Returns: scanned_count, processed_count, skipped_count, failed_count.
    """
    batch_size = min(max(1, batch_size), 100)  # cap 100, min 1
    gmail_client = services.gmail_client(config)
    fs_client = services.firestore_client(config)
    storage_client = services.storage_client(config)

    scanned_count = 0
    processed_count = 0
    skipped_count = 0
    failed_count = 0

    for message_id in itertools.islice(
        _bootstrap_messages(gmail_client, config, label_ids), batch_size
    ):
        scanned_count += 1

        # Early pre-check: if already queued (acked or not), skip before fetch to avoid
        # duplicate downloads/uploads and keep backfill idempotent by message_id.
        existing = _find_existing_queue_doc(fs_client, config, message_id)
        if existing:
            skipped_count += 1
            continue

        message = _fetch_message(gmail_client, message_id)
        if not message:
            skipped_count += 1
            continue

        try:
            _handle_message(message, gmail_client, storage_client, fs_client, config)
            processed_count += 1
        except Exception as exc:
            LOGGER.warning(
                "BACKFILL failed message_id=%s: %s",
                message_id,
                exc,
                exc_info=True,
            )
            failed_count += 1

    LOGGER.info(
        "BACKFILL scanned=%s processed=%s skipped=%s failed=%s",
        scanned_count,
        processed_count,
        skipped_count,
        failed_count,
    )
    return {
        "scanned_count": scanned_count,
        "processed_count": processed_count,
        "skipped_count": skipped_count,
        "failed_count": failed_count,
    }


def _build_attachment_query(
    config: Config,
    label_ids_override: Optional[List[str]] = None,
) -> str:
    """
    Build the Gmail search query used by backlog listing/preview.
    Keeps label normalization and query format in one place.
    """
    ids = (
        label_ids_override
        if label_ids_override is not None
        else (config.gmail_label_ids or [])
    )
    normalized = watch.normalize_label_ids(from_list=ids if ids else None)
    label_query = " ".join("label:{}".format(lid) for lid in normalized)
    return "has:attachment {}".format(label_query).strip()


def process_history_event(notification: Dict[str, Any], config: Config) -> Dict[str, Any]:
    history_id = notification.get("historyId")
    if not history_id:
        LOGGER.warning("Notification missing historyId: %s", notification)
        return {"processed": 0}

    fs_client = services.firestore_client(config)
    storage_client = services.storage_client(config)
    gmail_client = services.gmail_client(config)

    state_ref = _ensure_state_document(config, fs_client)
    state_snapshot = state_ref.get()
    state_data = state_snapshot.to_dict() if state_snapshot.exists else {}
    last_history_id = state_data.get("last_history_id")
    # Defensive: avoid poisoning the state with non-numeric placeholders (seen during scheduler bootstrap).
    # If last_history_id is invalid, treat as missing so we re-bootstrap and reset state safely.
    if last_history_id and not str(last_history_id).isdigit():
        LOGGER.warning("Invalid last_history_id in state (%s); resetting via bootstrap.", last_history_id)
        last_history_id = None

    processed_count = 0

    try:
        if not last_history_id:
            for message_id in _bootstrap_messages(gmail_client, config):
                message = _fetch_message(gmail_client, message_id)
                if not message:
                    continue
                _handle_message(message, gmail_client, storage_client, fs_client, config)
                processed_count += 1
            _record_state(fs_client, config, history_id)
            return {"processed": processed_count, "bootstrap": True}

        for record in _list_history(gmail_client, last_history_id):
            for message_added in record.get("messagesAdded", []):
                message_id = message_added.get("message", {}).get("id")
                if not message_id:
                    continue
                message = _fetch_message(gmail_client, message_id)
                if not message:
                    continue
                _handle_message(message, gmail_client, storage_client, fs_client, config)
                processed_count += 1
        _record_state(fs_client, config, history_id)
        return {"processed": processed_count, "bootstrap": False}
    except HttpError as exc:
        if exc.resp.status == 404 and exc.uri and "historyId" in exc.uri:
            # History ID too old; reset by performing bootstrap
            LOGGER.warning("HistoryId gap detected, performing bootstrap: %s", exc)
            for message_id in _bootstrap_messages(gmail_client, config):
                message = _fetch_message(gmail_client, message_id)
                if not message:
                    continue
                _handle_message(message, gmail_client, storage_client, fs_client, config)
                processed_count += 1
            _record_state(fs_client, config, history_id)
            return {"processed": processed_count, "bootstrap": True, "reset": True}
        raise


def _handle_message(
    message: Dict[str, Any],
    gmail_client,
    storage_client: storage.Client,
    fs_client: firestore.Client,
    config: Config,
) -> None:
    # attempt_id generated at start of _handle_message; reused for queue doc + ingest_errors
    attempt_id = uuid.uuid4().hex

    # Filter by sender if configured
    if not _is_sender_allowed(message, config):
        LOGGER.debug("Skipping message %s (sender not in allowed list)", message.get("id"))
        return

    machine_id = ""
    try:
        otp_required = _detect_secure_message(message)
        try:
            machine_id = _extract_machine_id(message, config, fs_client)
        except MachineIdResolutionError as exc:
            LOGGER.warning("PROCESSOR_REJECT code=machine_id_resolution_failure message_id=%s", message.get("id"))
            _ensure_preprocessor_state(config, fs_client)
            _write_ingest_error(
                fs_client,
                config,
                message_id=str(message.get("id", "")),
                machine_id="",
                reject_code="machine_id_resolution_failure",
                reason=str(exc)[:500] if str(exc) else "machine_id_resolution_failure",
                attempt_id=attempt_id,
                stage="processor",
            )
            return

        attachments: List[Dict[str, Any]] = []
        otp_token: Optional[str] = None

        if not otp_required:
            attachments = _collect_attachments(message, gmail_client, storage_client, config, machine_id)
            # Do not return early; route through preprocessor so we write ingest_errors on reject
        else:
            otp_token = uuid.uuid4().hex

        # Build raw candidate for preprocessor
        raw_candidate = {
            "machine_id": machine_id,
            "message_id": message["id"],
            "thread_id": message.get("threadId"),
            "historyId": message.get("historyId"),
            "history_id": message.get("historyId"),
            "internalDate": message.get("internalDate"),
            "subject": _get_header(message, "Subject"),
            "received_at": message.get("internalDate"),
            "otp_required": otp_required,
            "otp_token": otp_token,
            "files": attachments,
        }

        result = preprocessor.preprocess_queue_candidate(raw_candidate, config, attempt_id)

        if result.ok:
            _ensure_preprocessor_state(config, fs_client)
            doc_id = _persist_queue_entry(
                fs_client, config, machine_id, message, attachments, otp_required, otp_token,
                validated_payload=result.payload,
                attempt_id=attempt_id,
            )
            LOGGER.info(
                "Queued message %s for machine %s (otp=%s, files=%s) as %s",
                message.get("id"),
                machine_id,
                otp_required,
                len(attachments),
                doc_id,
            )
            return

        # Rejected
        LOGGER.warning(
            "PREPROCESSOR_REJECT code=%s message_id=%s",
            result.code,
            message.get("id"),
        )

        cleanup_failed = False
        preprocessor_mode = getattr(config, "preprocessor_mode", "shadow")
        if preprocessor_mode == "enforce":
            # Skip queue write; best-effort GCS cleanup
            cleanup_failed = _cleanup_gcs_attachments(storage_client, config.gcs_bucket, attachments)

        _write_ingest_error(
            fs_client,
            config,
            message_id=str(message.get("id", "")),
            machine_id=machine_id,
            reject_code=result.code,
            reason=result.message,
            attempt_id=attempt_id,
            cleanup_partial_failure=cleanup_failed,
        )

        if preprocessor_mode == "enforce":
            return

        # shadow mode: still write queue
        _ensure_preprocessor_state(config, fs_client)
        doc_id = _persist_queue_entry(
            fs_client, config, machine_id, message, attachments, otp_required, otp_token,
            attempt_id=attempt_id,
            preprocessor_reject_code=result.code,
            preprocessor_reject_reason=result.message,
        )
        LOGGER.info(
            "Queued message %s for machine %s (shadow reject, otp=%s, files=%s) as %s",
            message.get("id"),
            machine_id,
            otp_required,
            len(attachments),
            doc_id,
        )
    except Exception as exc:
        # Catch-all to prevent silent telemetry gaps when failures happen around preprocessing.
        LOGGER.exception(
            "PROCESSOR_REJECT code=processor_unhandled_exception message_id=%s",
            message.get("id"),
        )
        try:
            _ensure_preprocessor_state(config, fs_client)
            _write_ingest_error(
                fs_client,
                config,
                message_id=str(message.get("id", "")),
                machine_id=machine_id,
                reject_code="processor_unhandled_exception",
                reason=str(exc)[:500] if str(exc) else "processor_unhandled_exception",
                attempt_id=attempt_id,
                stage="processor",
            )
        except Exception as write_exc:
            LOGGER.error(
                "Failed to write ingest_errors for processor_unhandled_exception message_id=%s: %s",
                message.get("id"),
                write_exc,
                exc_info=True,
            )
        raise
