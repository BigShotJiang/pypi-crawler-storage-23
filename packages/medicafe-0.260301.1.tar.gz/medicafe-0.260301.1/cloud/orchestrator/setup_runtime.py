from __future__ import annotations

import argparse
import base64
import json
import time
import tempfile
import os
from dataclasses import dataclass
from typing import List, Optional

if __package__:
    from .setup_common import (
        _call_cloud_run_admin_resume_history,
        _command_error,
        _confirm,
        _run,
        _tag_fail,
        _tag_info,
        _tag_ok,
    )
else:
    from setup_common import (
        _call_cloud_run_admin_resume_history,
        _command_error,
        _confirm,
        _run,
        _tag_fail,
        _tag_info,
        _tag_ok,
    )

@dataclass
class RuntimeVerifyResult:
    # Best-effort signals only. Missing values usually mean "could not be determined from logs".
    effective_http_status: Optional[int]
    handler_invoked: bool
    any_auth_mode: bool
    keyless_proof: bool
    saw_dwd_required_failed: bool
    startup_proof: bool


def _verify_runtime(args: argparse.Namespace, ctx: "Context") -> RuntimeVerifyResult:
    """Best-effort operational verification (intentionally non-fatal)."""
    project_id = args.project_id
    region = args.region
    service_name = args.service_name
    job_name = args.scheduler_job
    service_url = ctx.service_url or ""
    admin_secret = ctx.admin_secret or ""
    validate_only = bool(args.validate_only)
    interactive = bool(args.interactive)
    auto_fix_enabled = bool(interactive) and (not validate_only) and (not bool(getattr(args, "no_auto_verify_fixes", False)))

    def _get_cloud_run_env_map() -> dict:
        try:
            proc = _run([
                "gcloud", "run", "services", "describe", service_name,
                "--project", project_id, "--region", region, "--format", "json",
            ])
            if proc.returncode != 0 or not proc.stdout:
                return {}
            payload = json.loads(proc.stdout)
            containers = (((payload.get("spec") or {}).get("template") or {}).get("spec") or {}).get("containers") or []
            if not containers:
                return {}
            out = {}
            for item in (containers[0].get("env") or []):
                name = item.get("name")
                value = item.get("value")
                if name:
                    out[str(name)] = "" if value is None else str(value)
            return out
        except Exception:
            return {}

    def _update_cloud_run_env_map(env_map: dict) -> bool:
        # Update via env-vars-file to avoid escaping problems on Windows (commas, quotes, etc.).
        path = ""
        try:
            with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False, encoding="utf-8") as f:
                for key in sorted(env_map):
                    f.write("{}: {}\n".format(key, json.dumps(str(env_map[key]))))
                path = f.name
            proc = _run([
                "gcloud", "run", "services", "update", service_name,
                "--project", project_id, "--region", region,
                "--env-vars-file", path,
                "--quiet",
            ])
            return proc.returncode == 0
        finally:
            if path:
                try:
                    os.unlink(path)
                except Exception:
                    pass

    def _ensure_cloud_run_env_vars(updates: dict) -> bool:
        current = _get_cloud_run_env_map()
        if not current:
            return False
        changed = False
        merged = dict(current)
        for k, v in updates.items():
            if merged.get(k) != str(v):
                merged[k] = str(v)
                changed = True
        if not changed:
            return True
        return _update_cloud_run_env_map(merged)

    def _ensure_scheduler_invoker_binding(oidc_sa_email: str) -> bool:
        if not oidc_sa_email:
            return False
        member = "serviceAccount:{}".format(oidc_sa_email)
        proc = _run([
            "gcloud", "run", "services", "add-iam-policy-binding", service_name,
            "--project", project_id, "--region", region,
            "--member", member,
            "--role", "roles/run.invoker",
            "--quiet",
        ])
        return proc.returncode == 0

    try:
        print("\n{} Triggering scheduler job '{}'...".format(_tag_info(), job_name))
        _run([
            "gcloud", "scheduler", "jobs", "run", job_name,
            "--project", project_id, "--location", region,
        ])
    except Exception as exc:
        print("{} Scheduler run request failed: {}".format(_tag_fail(), exc))

    # Scheduler logs (JSON)
    last_http_status = None
    try:
        flt = 'resource.type="cloud_scheduler_job" AND resource.labels.job_id="{}"'.format(job_name)
        # Logging can lag by ~10-60 seconds after a scheduler run. Retry a few times.
        for attempt in range(1, 5):
            proc = _run([
                "gcloud", "logging", "read", flt,
                "--project", project_id,
                "--freshness", "30m",
                "--limit", "10",
                "--format", "json",
            ])
            if proc.returncode == 0 and proc.stdout:
                try:
                    entries = json.loads(proc.stdout)
                    for e in entries:
                        jp = e.get("jsonPayload") or {}
                        if "AttemptFinished" in (jp.get("@type") or ""):
                            status = jp.get("status")
                            debug = jp.get("debugInfo")
                            http_status = (e.get("httpRequest") or {}).get("status")
                            last_http_status = http_status
                            print("{} Scheduler last AttemptFinished: status={}, httpStatus={}, debugInfo={}".format(
                                _tag_info(), status, http_status, debug
                            ))
                            break
                    if last_http_status is not None:
                        break
                except Exception:
                    print("{} Scheduler logs available (unparsed).".format(_tag_info()))
                    break
            if attempt < 4:
                time.sleep(8)
        if last_http_status is None:
            print("{} Scheduler status could not be determined from logs (log propagation delay or insufficient permissions).".format(_tag_info()))
    except Exception as exc:
        print("{} Scheduler log read failed: {}".format(_tag_fail(), exc))

    # Runbook proof point: handler ran (stable log line) and auth mode lines exist.
    # Use Cloud Logging queries (more reliable than tailing the last N service logs).
    def _extract_log_snippet(entry: dict) -> str:
        jp = entry.get("jsonPayload") or {}
        if isinstance(jp, dict):
            msg = jp.get("message") or jp.get("msg")
            if msg:
                return str(msg).strip()
        tp = entry.get("textPayload")
        if tp:
            return str(tp).strip()
        return ""

    handler_invoked = False
    keyless_proof = False
    any_auth_mode = False
    saw_dwd_required_failed = False
    last_admin_request_status: Optional[int] = None
    # Keep the latest raw Cloud Run log lines for pattern detection and auto-fix heuristics.
    last_cloud_run_lines: List[str] = []
    did_apply_fix = False
    applied_fix_notes: List[str] = []

    try:
        flt_handler = (
            'resource.type="cloud_run_revision" '
            'AND resource.labels.service_name="{}" '
            'AND "resume-history invoked"'
        ).format(service_name)
        proc_h = _run([
            "gcloud", "logging", "read", flt_handler,
            "--project", project_id,
            "--freshness", "30m",
            "--limit", "10",
            "--format", "json",
        ])
        if proc_h.returncode == 0 and proc_h.stdout:
            try:
                entries = json.loads(proc_h.stdout) or []
                snippets = []
                for e in entries:
                    sn = _extract_log_snippet(e).replace("\n", " ")
                    if "resume-history invoked" in sn:
                        handler_invoked = True
                        ts = e.get("timestamp") or ""
                        sev = e.get("severity") or ""
                        snippets.append("{} {} {}".format(ts, sev, sn[:200]))
                if handler_invoked:
                    print("\n{} Handler proof: found 'resume-history invoked' in Cloud Run logs (last 30m).".format(_tag_ok()))
                    for ln in snippets[:3]:
                        print("  {}".format(ln))
                else:
                    print("\n{} Handler proof: 'resume-history invoked' not found in last 30m.".format(_tag_info()))
            except Exception:
                print("\n{} Handler proof: logs available (unparsed).".format(_tag_info()))
        else:
            print("\n{} Handler proof: no matching logs found (or insufficient permissions).".format(_tag_info()))
    except Exception as exc:
        print("\n{} Handler proof check failed: {}".format(_tag_fail(), exc))

    try:
        flt_auth = (
            'resource.type="cloud_run_revision" '
            'AND resource.labels.service_name="{}" '
            'AND ("Gmail auth mode:" OR "Keyless DWD failed:" OR "DWD required but failed:")'
        ).format(service_name)
        proc_a = _run([
            "gcloud", "logging", "read", flt_auth,
            "--project", project_id,
            "--freshness", "24h",
            "--limit", "50",
            "--format", "json",
        ])
        if proc_a.returncode == 0 and proc_a.stdout:
            try:
                entries = json.loads(proc_a.stdout) or []
                mode_lines = []
                fail_lines = []
                for e in entries:
                    sn = _extract_log_snippet(e).replace("\n", " ")
                    if not sn:
                        continue
                    if "Gmail auth mode:" in sn:
                        any_auth_mode = True
                        ts = e.get("timestamp") or ""
                        mode_lines.append("{} {}".format(ts, sn[:240]))
                        if "Gmail auth mode: dwd (keyless)" in sn:
                            keyless_proof = True
                    if "Keyless DWD failed:" in sn or "DWD required but failed:" in sn:
                        ts = e.get("timestamp") or ""
                        fail_lines.append("{} {}".format(ts, sn[:240]))
                        if "DWD required but failed:" in sn:
                            saw_dwd_required_failed = True
                if any_auth_mode:
                    print("\n{} Auth proof: observed 'Gmail auth mode:' lines (last 24h, newest first).".format(_tag_info()))
                    for ln in mode_lines[:6]:
                        print("  {}".format(ln))
                    if keyless_proof:
                        print("{} Verified keyless DWD log line found.".format(_tag_ok()))
                    else:
                        print("{} Keyless DWD line not found yet (may be using fallback).".format(_tag_info()))
                else:
                    print("\n{} Auth proof: no 'Gmail auth mode:' lines found in last 24h.".format(_tag_info()))
                if fail_lines:
                    print("\n{} Recent auth-related failures (last 24h):".format(_tag_info()))
                    for ln in fail_lines[:6]:
                        print("  {}".format(ln))
            except Exception:
                print("\n{} Auth proof: logs available (unparsed).".format(_tag_info()))
        else:
            print("\n{} Auth proof: no matching logs found (or insufficient permissions).".format(_tag_info()))
    except Exception as exc:
        print("\n{} Auth proof check failed: {}".format(_tag_fail(), exc))

    # Always try to infer whether Cloud Run received /admin/resume-history recently, even if scheduler status is unknown.
    try:
        flt_req = (
            'resource.type="cloud_run_revision" '
            'AND resource.labels.service_name="{}" '
            'AND httpRequest.requestUrl:"/admin/resume-history"'
        ).format(service_name)
        proc_req = _run([
            "gcloud", "logging", "read", flt_req,
            "--project", project_id,
            "--freshness", "30m",
            "--limit", "10",
            "--format", "json",
        ])
        if proc_req.returncode == 0 and proc_req.stdout:
            try:
                entries = json.loads(proc_req.stdout) or []
                if entries:
                    first = entries[0]
                    last_admin_request_status = (first.get("httpRequest") or {}).get("status")
                    print("\n{} Recent Cloud Run request logs for /admin/resume-history (last 30m):".format(_tag_info()))
                    for e in entries[:6]:
                        ts = e.get("timestamp") or ""
                        sev = e.get("severity") or ""
                        hr = e.get("httpRequest") or {}
                        st = hr.get("status")
                        url = hr.get("requestUrl") or ""
                        snippet = _extract_log_snippet(e).replace("\n", " ").strip()
                        if len(snippet) > 160:
                            snippet = snippet[:160] + "..."
                        print("  {} {} status={} url={} {}".format(ts, sev, st, url, snippet))
                else:
                    print("\n{} No /admin/resume-history requests found in Cloud Run logs (last 30m).".format(_tag_info()))
            except Exception:
                print("\n{} Cloud Run request logs available (unparsed).".format(_tag_info()))
        else:
            print("\n{} Could not read Cloud Run request logs (or none found).".format(_tag_info()))
    except Exception as exc:
        print("\n{} Cloud Run request log check failed: {}".format(_tag_fail(), exc))

    effective_http = last_admin_request_status if isinstance(last_admin_request_status, int) else last_http_status

    # Safe auto-fixes based on observed runtime behavior.
    # These are only applied in interactive mode, never in validate-only, and can be disabled via --no-auto-verify-fixes.
    #
    # Philosophy: only apply remediations that are low-risk, idempotent, and have clear rollback:
    # - Set DEFAULT_MACHINE_ID when the app is throwing "Unable to determine machine id"
    # - Set SERVICE_ACCOUNT_EMAIL when keyless DWD cannot resolve signing SA email
    # - Grant roles/run.invoker to the scheduler OIDC SA when we see auth-related failures
    def _maybe_apply_safe_fixes() -> None:
        nonlocal did_apply_fix, applied_fix_notes
        if not auto_fix_enabled:
            return

        # Pull a short Cloud Run log tail for pattern matching (best-effort).
        if not last_cloud_run_lines:
            try:
                proc_tail = _run([
                    "gcloud", "run", "services", "logs", "read", service_name,
                    "--project", project_id, "--region", region,
                    "--limit", "400",
                ])
                if proc_tail.returncode == 0 and proc_tail.stdout:
                    last_cloud_run_lines.extend((proc_tail.stdout or "").splitlines())
            except Exception:
                pass

        joined = "\n".join(last_cloud_run_lines[-200:]) if last_cloud_run_lines else ""

        # Fix 1: DEFAULT_MACHINE_ID missing -> known 500.
        if "Unable to determine machine id" in joined:
            desired = (getattr(args, "default_machine_id", "") or "").strip() or "clinic-default"
            ok = _ensure_cloud_run_env_vars({"DEFAULT_MACHINE_ID": desired})
            if ok:
                did_apply_fix = True
                applied_fix_notes.append("Set DEFAULT_MACHINE_ID={}".format(desired))

        # Fix 2: keyless signing SA email resolution failures.
        if "Could not resolve signing SA email for keyless DWD" in joined:
            # Use the service account email from context (Cloud Run service account) if available.
            desired_email = (getattr(ctx, "service_account_email", "") or "").strip()
            if desired_email:
                ok = _ensure_cloud_run_env_vars({"SERVICE_ACCOUNT_EMAIL": desired_email})
                if ok:
                    did_apply_fix = True
                    applied_fix_notes.append("Set SERVICE_ACCOUNT_EMAIL={}".format(desired_email))

        # Fix 3: scheduler auth failures -> ensure invoker binding for its OIDC service account.
        if isinstance(effective_http, int) and effective_http in (401, 403):
            try:
                desc = _run([
                    "gcloud", "scheduler", "jobs", "describe", job_name,
                    "--project", project_id, "--location", region, "--format", "json",
                ])
                if desc.returncode == 0 and desc.stdout:
                    data = json.loads(desc.stdout)
                    oidc_sa = ((data.get("httpTarget") or {}).get("oidcToken") or {}).get("serviceAccountEmail") or ""
                    oidc_sa = str(oidc_sa).strip()
                    if oidc_sa:
                        ok = _ensure_scheduler_invoker_binding(oidc_sa)
                        if ok:
                            did_apply_fix = True
                            applied_fix_notes.append("Granted roles/run.invoker to scheduler OIDC SA {}".format(oidc_sa))
            except Exception:
                pass

    _maybe_apply_safe_fixes()

    if did_apply_fix:
        print("\n{} Applied safe runtime auto-fixes:".format(_tag_ok()))
        for note in applied_fix_notes:
            print("  - {}".format(note))
        print("{} Re-running scheduler once to verify...".format(_tag_info()))
        try:
            _run([
                "gcloud", "scheduler", "jobs", "run", job_name,
                "--project", project_id, "--location", region,
            ])
            # Give logs a moment to propagate.
            time.sleep(8)
        except Exception:
            pass

    # If scheduler is returning 4xx/5xx, show the scheduler target + decoded message body (redacted).
    try:
        if isinstance(effective_http, int) and effective_http >= 400:
            desc = _run([
                "gcloud", "scheduler", "jobs", "describe", job_name,
                "--project", project_id, "--location", region,
                "--format", "json",
            ])
            if desc.returncode == 0 and desc.stdout:
                try:
                    data = json.loads(desc.stdout)
                    target = (data.get("httpTarget") or {})
                    oidc = (target.get("oidcToken") or {})
                    uri = target.get("uri") or ""
                    aud = oidc.get("audience") or ""
                    sa = oidc.get("serviceAccountEmail") or ""
                    body_b64 = target.get("body") or ""
                    decoded = ""
                    if body_b64:
                        decoded = base64.b64decode(str(body_b64).encode("utf-8")).decode("utf-8", errors="replace").strip()
                    redacted = decoded
                    try:
                        obj = json.loads(decoded) if decoded else {}
                        if isinstance(obj, dict) and "secret" in obj:
                            obj = dict(obj)
                            obj["secret"] = "<redacted>"
                            redacted = json.dumps(obj)
                    except Exception:
                        # If not JSON, just avoid printing anything that looks like the secret.
                        redacted = "<unparsed>"
                    print("\n{} Scheduler job target (redacted):".format(_tag_info()))
                    print("  uri={}".format(uri))
                    print("  oidc_audience={}".format(aud))
                    print("  oidc_service_account={}".format(sa))
                    if decoded:
                        print("  body={}".format(redacted))
                except Exception:
                    pass
    except Exception:
        pass

    # If we have a 4xx/5xx on /admin/resume-history, surface the actual exception.
    # Note: application stdout/stderr logs often do NOT include httpRequest fields, so do not filter on requestUrl here.
    try:
        # Only do this if we have a clear 4xx/5xx signal; otherwise it can be noisy.
        if isinstance(effective_http, int) and effective_http >= 400:
            print("\n{} Recent Cloud Run exception hints (service-wide, last 30m):".format(_tag_info()))
            # Avoid filtering on severity. Python logs can land as DEFAULT severity even for "ERROR",
            # depending on runtime/logging config. Use stable substrings instead.
            base = (
                'resource.type="cloud_run_revision" '
                'AND resource.labels.service_name="{}" '
                'AND ("Failed to process history event in /admin/resume-history" '
                'OR "ADMIN_SHARED_SECRET not set" '
                'OR "resume-history invoked" '
                'OR "Traceback" '
                'OR "Unable to determine machine id" '
                'OR "Message not found (404)" '
                'OR "Keyless DWD failed:" '
                'OR "DWD required but failed:")'
            ).format(service_name)
            proc_err = _run([
                "gcloud", "logging", "read", base,
                "--project", project_id,
                "--freshness", "30m",
                "--limit", "50",
                "--format", "json",
            ])
            if proc_err.returncode == 0 and proc_err.stdout:
                try:
                    entries = json.loads(proc_err.stdout) or []
                    if not entries:
                        print("  (no matching exception/proof logs found)")
                    for e in entries[:12]:
                        ts = e.get("timestamp") or ""
                        sev = e.get("severity") or ""
                        sn = _extract_log_snippet(e).replace("\n", " ").strip()
                        if len(sn) > 240:
                            sn = sn[:240] + "..."
                        if sn:
                            print("  {} {} {}".format(ts, sev, sn))
                except Exception:
                    out = (proc_err.stdout or "").strip()
                    if out:
                        for line in out.splitlines()[:120]:
                            print("  {}".format(line))
                    else:
                        print("  (no matching logs found or insufficient permissions)")
            else:
                print("  (no matching logs found or insufficient permissions)")
    except Exception:
        pass

    # Optionally call the admin endpoint directly (forces a Gmail call) then re-scan.
    # This usually requires a service-account identity token; for user accounts it commonly fails.
    # If Scheduler already hit the endpoint (last_http_status is known), skip this by default to
    # avoid interactive impersonation prompts.
    called_admin = False
    # Default: do not prompt for direct calls. Direct calls frequently require SA impersonation and can stall runs.
    # Only attempt direct call when explicitly requested via flag.
    should_attempt_direct_admin = bool(getattr(args, "attempt_direct_admin_call", False))
    if should_attempt_direct_admin and (not (service_url and admin_secret)):
        should_attempt_direct_admin = False
    if should_attempt_direct_admin and (not interactive or validate_only):
        should_attempt_direct_admin = False
    if should_attempt_direct_admin:
        ok, detail = _call_cloud_run_admin_resume_history(
            project_id,
            region,
            service_name,
            service_url,
            admin_secret,
            validate_only=validate_only,
            interactive=interactive,
        )
        if ok:
            called_admin = True
            print("{} Admin endpoint call succeeded (resume-history).".format(_tag_ok()))
        else:
            print("{} Admin endpoint call skipped/failed: {}".format(_tag_info(), detail))

    # Cloud Run logs scan (retry a few times to allow log propagation)
    try:
        found_any = False
        printed_hints = False
        printed_traceback_context = False
        saw_gmail_message_404 = False

        def _print_traceback_context(lines: List[str]) -> None:
            nonlocal printed_traceback_context
            if printed_traceback_context:
                return
            # Try to find the MOST RECENT traceback block and print enough lines to include the exception.
            # gcloud run logs are chronological; if multiple runs happened, earlier tracebacks can be stale.
            idxs = [i for i, ln in enumerate(lines) if "Traceback (most recent call last)" in ln]
            if not idxs:
                return
            idx = idxs[-1]
            printed_traceback_context = True
            print("\n{} Traceback context (best effort, most recent):".format(_tag_info()))
            window = lines[idx: idx + 80]
            for w in window:
                if w.strip():
                    print("  {}".format(w))
            # Also try to surface the last explicit exception line(s) if present.
            # This is useful when the traceback is longer than our window.
            ex_lines = [ln for ln in window if ("Error:" in ln or "Exception:" in ln or "RuntimeError:" in ln)]
            if ex_lines:
                print("\n{} Exception lines (from the traceback window):".format(_tag_info()))
                for ln in ex_lines[-6:]:
                    print("  {}".format(ln))

        for attempt in range(1, 4):
            proc = _run([
                "gcloud", "run", "services", "logs", "read", service_name,
                "--project", project_id, "--region", region,
                "--limit", "300",
            ])
            if proc.returncode != 0:
                print("{} Cloud Run logs read failed: {}".format(_tag_fail(), _command_error(proc)))
                return
            lines = (proc.stdout or "").splitlines()
            last_cloud_run_lines = lines
            if any("HttpError 404" in ln and "/gmail/v1/users/me/messages/" in ln for ln in lines):
                saw_gmail_message_404 = True
            mode_lines = [ln for ln in lines if "Gmail auth mode:" in ln][-10:]
            # When the admin endpoint is failing (4xx/5xx), show targeted hints even if auth-mode lines are absent.
            if not printed_hints and isinstance(effective_http, int) and effective_http >= 400:
                hint_terms = (
                    "resume-history invoked",
                    "ADMIN_SHARED_SECRET not set",
                    "Failed to process history event in /admin/resume-history",
                    "Traceback",
                    "Unable to determine machine id",
                    "Keyless DWD failed:",
                    "DWD required but failed:",
                )
                hint_lines = [ln for ln in lines if any(t in ln for t in hint_terms)][-30:]
                if hint_lines:
                    printed_hints = True
                    print("\n{} Recent Cloud Run log hints (latest):".format(_tag_info()))
                    for ln in hint_lines[-12:]:
                        print("  {}".format(ln))
                    # If we saw a traceback header, print a bit more context.
                    _print_traceback_context(lines)
                else:
                    # Fallback: show a short tail so operators can spot the real exception even if it
                    # does not match our hint substrings (e.g. framework-level errors).
                    tail = [ln for ln in lines if ln.strip()][-40:]
                    if tail:
                        printed_hints = True
                        print("\n{} Recent Cloud Run log tail (latest):".format(_tag_info()))
                        for ln in tail[-12:]:
                            print("  {}".format(ln))
                        _print_traceback_context(tail)
            if mode_lines:
                found_any = True
                print("{} Observed Gmail auth mode lines (latest):".format(_tag_info()))
                for ln in mode_lines:
                    print("  {}".format(ln))
                if any("Gmail auth mode: dwd (keyless)" in ln for ln in mode_lines):
                    print("{} Verified keyless DWD log line found.".format(_tag_ok()))
                else:
                    print("{} Keyless DWD line not found yet (may be using fallback).".format(_tag_info()))
                break
            if attempt < 3:
                time.sleep(8)
        if not found_any:
            if called_admin:
                print("{} No 'Gmail auth mode:' lines found even after direct admin call. Likely the deployed image does not contain the new DWD logging code, or the admin call is not reaching Gmail logic.".format(_tag_info()))
            else:
                print("{} No 'Gmail auth mode:' lines found in recent Cloud Run logs.".format(_tag_info()))

        # Actionable classification: this is a known Gmail edge case and should not keep Scheduler failing.
        if isinstance(effective_http, int) and effective_http >= 500 and saw_gmail_message_404:
            print(
                "\n{} Detected Gmail API 404 for a message id during /admin/resume-history. "
                "This usually means Gmail history referenced a message that is no longer retrievable (deleted/expunged/race). "
                "The orchestrator should skip 404 messages and continue. "
                "If Scheduler keeps returning 500, deploy the latest code (processor 404-skip fix) and re-run verification.".format(
                    _tag_info()
                )
            )
    except Exception as exc:
        print("{} Cloud Run log scan failed: {}".format(_tag_fail(), exc))

    # Deterministic "are we on the new image?" proof: look for startup env dump line(s) that include AUTH_MODE.
    # This is more reliable than guessing from image tags.
    startup_proof = False
    try:
        flt_startup = (
            'resource.type="cloud_run_revision" '
            'AND resource.labels.service_name="{}" '
            'AND ("STARTUP ENVIRONMENT CHECK" OR "AUTH_MODE:")'
        ).format(service_name)
        proc_startup = _run([
            "gcloud", "logging", "read", flt_startup,
            "--project", project_id,
            "--freshness", "7d",
            "--limit", "10",
            "--format", "json",
        ])
        if proc_startup.returncode == 0 and proc_startup.stdout:
            try:
                entries = json.loads(proc_startup.stdout)
                # Show the most recent few relevant lines.
                lines_out: List[str] = []
                for e in entries[:10]:
                    ts = e.get("timestamp") or ""
                    sev = e.get("severity") or ""
                    msg = ""
                    jp = e.get("jsonPayload") or {}
                    if isinstance(jp, dict):
                        msg = str(jp.get("message") or jp.get("msg") or "")
                    tp = str(e.get("textPayload") or "")
                    snippet = (msg or tp).strip().replace("\n", " ")
                    if not snippet:
                        continue
                    if "STARTUP ENVIRONMENT CHECK" in snippet or "AUTH_MODE:" in snippet:
                        if len(snippet) > 240:
                            snippet = snippet[:240] + "..."
                        lines_out.append("{} {} {}".format(ts, sev, snippet))
                if lines_out:
                    print("\n{} Startup proof (logs include AUTH_MODE):".format(_tag_info()))
                    for ln in lines_out[:6]:
                        print("  {}".format(ln))
                    print("{} This indicates the deployed revision includes the startup env dump and AUTH_MODE is visible in Cloud Run logs.".format(_tag_ok()))
                    startup_proof = True
                else:
                    print("\n{} Startup proof not found in last 7d (logs may have rotated or revision has not restarted).".format(_tag_info()))
                    startup_proof = False
            except Exception:
                print("\n{} Startup proof logs available (unparsed).".format(_tag_info()))
                startup_proof = False
        else:
            print("\n{} Startup proof not found (or insufficient permissions to read logs).".format(_tag_info()))
            startup_proof = False
    except Exception as exc:
        print("\n{} Startup proof check failed: {}".format(_tag_fail(), exc))
        startup_proof = False

    # End-state guidance (runbook alignment)
    effective_http = last_admin_request_status if isinstance(last_admin_request_status, int) else last_http_status
    if isinstance(effective_http, int) and 200 <= effective_http < 300 and (not any_auth_mode):
        print(
            "\n{} Next action: Scheduler is 2xx and handler ran, but there are no 'Gmail auth mode:' lines. "
            "This usually means the deployed image does not include the DWD logging code yet, or the path is not reaching Gmail auth. "
            "If startup proof is also missing, redeploy the latest image then re-run --verify-runtime.".format(_tag_info())
        )
    if isinstance(effective_http, int) and 200 <= effective_http < 300 and any_auth_mode and (not keyless_proof):
        print(
            "\n{} Next action: Auth mode lines exist but keyless proof is missing. "
            "Check for 'Keyless DWD failed:' lines above; fix IAM (Token Creator on self) or Workspace allowlist/scopes, then re-run.".format(_tag_info())
        )

    return RuntimeVerifyResult(
        effective_http_status=effective_http if isinstance(effective_http, int) else None,
        handler_invoked=handler_invoked,
        any_auth_mode=any_auth_mode,
        keyless_proof=keyless_proof,
        saw_dwd_required_failed=saw_dwd_required_failed,
        startup_proof=bool(startup_proof),
    )

