#!/usr/bin/env python
"""
Cloud Readiness launcher menu/actions extracted from launcher.py.

Keeps top-level launcher flow small while preserving exact operator-facing
menu wording and behavior.
"""
from __future__ import print_function

import json
import os
import re


class LauncherCloudReadinessMixin(object):
    """Mixin providing Cloud Readiness menus and action handlers."""

    def _cloud_readiness_service(self):
        resolver = getattr(self, '_cloud_readiness_resolver', None)
        if callable(resolver):
            try:
                return resolver()
            except Exception:
                return None
        return None

    def _env_flag_value(self, name, default=False):
        env_flag_fn = getattr(self, '_env_flag_fn', None)
        if callable(env_flag_fn):
            try:
                return env_flag_fn(name, default)
            except Exception:
                return default
        return default

    def _print_phase_f_status(self):
        """Print interpreted pipeline health snapshot before Cloud Readiness choices."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        lab_root = cr.resolve_lab_root(self.repo_root)
        for line in cr.get_health_lines(lab_root, self._env_flag_value):
            print(line)

    def _print_manual_pipeline_runbook(self, action_code):
        """Print what-to-expect runbook after manual pipeline trigger."""
        code = str(action_code or '').upper().strip()
        print('')
        print('Manual pipeline runbook:')
        print(' - heartbeat_timeout_sec=120')
        if code == 'A':
            print(' - expected_progression=B->C->D->E->F')
            print(' - expected_artifacts=artifact_discovery_summary_, ingest_write_summary_, qa_canonical_summary_, projection_parity_summary_, shadow_run_report_')
            print(' - if_no_new_artifacts_within_timeout=Open latest Artifact Triage Pack; if still stalled, retrigger A and inspect delivery diagnostics.')
        elif code == 'B':
            print(' - expected_artifact=artifact_discovery_summary_<run_id>.json/.txt')
            print(' - if_missing_after_timeout=Verify source folders, then retrigger B or run A for coherent pipeline execution.')
        elif code == 'C':
            print(' - expected_artifact=ingest_write_summary_<run_id>.json/.txt')
            print(' - if_missing_after_timeout=Confirm manifest exists; review ingest anomalies and rerun C or full A.')
        elif code == 'D':
            print(' - expected_artifact=qa_canonical_summary_<run_id>.json/.txt')
            print(' - if_missing_after_timeout=Check QA prerequisites and rerun D; inspect reject samples when produced.')
        elif code == 'E':
            print(' - expected_artifact=projection_parity_summary_<run_id>.json/.txt')
            print(' - if_missing_after_timeout=Validate parity inputs and rerun E; inspect deviation samples if coverage/parity issues appear.')
        print(' - verify_with=Cloud Phase Artifact Tools -> A/B')

    def _run_system_health_triage(self):
        """Run migration audit + refresh unified system-health pack, then print quick hints."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        migration_stage = str(os.environ.get('MEDICAFE_MIGRATION_STAGE', 'xp_validation') or 'xp_validation').strip().lower()
        if migration_stage not in ('xp_validation', 'dual_run_pre_cutover', 'cutover'):
            migration_stage = 'xp_validation'
        ok, msg, data = cr.run_system_health_triage(
            self.repo_root,
            self.python_exe,
            self.environment,
            self._env_flag_value,
            scope='both',
            cloud_required=False,
            migration_stage=migration_stage,
        )
        if msg:
            print(msg)
        hints = []
        artifacts = []
        if isinstance(data, dict):
            hints = data.get('hints', []) if isinstance(data.get('hints', []), list) else []
            artifacts = data.get('artifacts', []) if isinstance(data.get('artifacts', []), list) else []
            runbook_lines = data.get('runbook_lines', []) if isinstance(data.get('runbook_lines', []), list) else []
        else:
            runbook_lines = []
        if hints:
            print('')
            print('Manual validation quick hints:')
            for line in hints:
                print(' - {0}'.format(line))
        if runbook_lines:
            print('')
            print('Decision runbook:')
            for line in runbook_lines:
                print(' - {0}'.format(line))
        if artifacts:
            print('')
            print('Generated artifacts:')
            for path in artifacts:
                print(' - {0}'.format(path))
        if not ok:
            print('Triage finished with issues. Review artifacts for details.')

    def _open_latest_system_health_pack(self):
        """Open latest combined system-health pack snapshot."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        ok, msg, path = cr.open_latest_system_health_pack(self.repo_root, self._env_flag_value)
        if ok and path:
            print('Opening: {0}'.format(path))
            self._launch_viewer(path)
        elif msg:
            print(msg)

    def _open_data_plane_audit_report(self, report_type='overview', limit=40):
        """Generate and open DB data audit report (counts + patient chain sample)."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        ok, msg, path = cr.open_data_plane_audit_report(
            self.repo_root, report_type=report_type, limit=limit)
        if msg:
            print(msg)
        if ok and path:
            print('Opening: {0}'.format(path))
            self._launch_viewer(path)

    def _open_latest_data_plane_audit_report(self, report_type='overview'):
        """Open latest generated DB data audit report for report_type."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        ok, msg, path = cr.open_latest_data_plane_audit_report(
            self.repo_root, report_type=report_type)
        if ok and path:
            print('Opening: {0}'.format(path))
            self._launch_viewer(path)
        elif msg:
            print(msg)

    def _open_patient_flow_runbook_by_reference(self):
        """Prompt for patient reference and open patient flow runbook."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        patient_ref = (self._prompt(
            'Enter patient reference (patient_id / external_patient_id / patient_key): ') or '').strip()
        if not patient_ref:
            print('Cancelled.')
            return
        ok, msg, path = cr.open_patient_flow_runbook(self.repo_root, patient_ref)
        if msg:
            print(msg)
        if ok and path:
            print('Opening: {0}'.format(path))
            self._launch_viewer(path)

    def _cloud_db_inspection_menu(self):
        """DB content inspection tools for manual data-quality audits."""
        while True:
            self._clear_console()
            self._print_legacy_banner('Cloud DB Inspection', width=40)
            self._print_troubleshooting_group('Inventory & Quality', [
                '1)  Generate DB overview report (counts + quality)',
                '2)  Open latest DB overview report',
                '3)  Generate recent patient sample report',
                '4)  Generate high-risk patient sample report',
            ])
            self._print_troubleshooting_group('Patient Drilldown', [
                '5)  Open patient flow runbook by patient reference',
                '6)  Open Patient Flow Runbook (auto-populated list)',
                '7)  Guided Patient Completeness Runbook',
            ])
            print('Navigation')
            print(' 0)  Back to Cloud Readiness menu')
            print('')
            choice = (self._prompt('Enter your choice: ') or '').strip()
            if choice == '0':
                return
            elif choice == '1':
                print('Generating DB overview report...')
                self._open_data_plane_audit_report(report_type='overview', limit=60)
            elif choice == '2':
                print('Opening latest DB overview report...')
                self._open_latest_data_plane_audit_report(report_type='overview')
            elif choice == '3':
                print('Generating recent patient sample report...')
                self._open_data_plane_audit_report(report_type='recent', limit=60)
            elif choice == '4':
                print('Generating high-risk patient sample report...')
                self._open_data_plane_audit_report(report_type='high_risk', limit=60)
            elif choice == '5':
                print('Opening patient flow runbook by manual reference...')
                self._open_patient_flow_runbook_by_reference()
            elif choice == '6':
                print('Opening patient flow runbook by auto-populated reference...')
                self._open_patient_flow_runbook_for_id()
            elif choice == '7':
                print('Starting guided patient completeness runbook...')
                self._guided_patient_completeness_runbook()
            else:
                print('Invalid choice.')
            try:
                self._prompt('Press Enter to return to menu...')
            except Exception:
                pass

    def _open_report_delivery_status(self):
        """Open compact report delivery/send diagnostics snapshot."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        ok, msg, path = cr.open_report_delivery_status(self.repo_root)
        if ok and path:
            print('Opening: {0}'.format(path))
            self._launch_viewer(path)
        elif msg:
            print(msg)

    def _open_phase_f_shadow_report(self):
        """View latest Shadow Health report (Phase F) - txt or json."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        ok, msg, path = cr.open_phase_f_shadow_report(self.repo_root)
        if ok and path:
            print('Opening: {0}'.format(path))
            self._launch_viewer(path)
        elif msg:
            print(msg)

    def _send_latest_system_health_pack(self):
        """Send latest unified system-health pack with related artifacts."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        ok, msg, data = cr.send_latest_system_health_pack(self.repo_root, self._env_flag_value)
        if msg:
            print(msg)
        runbook_lines = data.get('pre_send_runbook_lines', []) if isinstance(data, dict) else []
        if runbook_lines:
            print('')
            print('Pre-send runbook:')
            for line in runbook_lines:
                print(' - {0}'.format(line))
        if not ok:
            print('')
            print('Opening report delivery diagnostics to help triage send failure...')
            self._open_report_delivery_status()

    def _print_runbook_block(self, heading, runbook_lines):
        """Print runbook lines while preserving headings and numbered actions."""
        if not runbook_lines:
            return
        print('')
        print(heading)
        for line in runbook_lines:
            line_text = str(line or '')
            stripped = line_text.strip()
            if not stripped:
                continue
            if line_text.startswith(' - ') or line_text.startswith('- '):
                print(line_text)
                continue
            is_numbered = False
            for idx in range(1, 10):
                if stripped.startswith('{0})'.format(idx)):
                    is_numbered = True
                    break
            if stripped.endswith(':'):
                print(stripped)
            elif is_numbered:
                print(' {0}'.format(stripped))
            else:
                print(' - {0}'.format(stripped))

    def _guided_patient_completeness_runbook(self):
        """Run guided letter-based patient completeness inspection with embedded runbook output."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        ok, msg, data = cr.get_guided_patient_completeness_options(self.repo_root)
        if msg:
            print(msg)
        runbook_lines = data.get('runbook_lines', []) if isinstance(data, dict) else []
        actions = data.get('actions', []) if isinstance(data, dict) else []
        if not ok:
            self._print_runbook_block('Guided runbook context:', runbook_lines)
            has_action_section = any(
                str(line or '').strip().lower() == 'what to do now:'
                for line in runbook_lines
            )
            if actions and not has_action_section:
                print('')
                print('What To Do Now:')
                step = 1
                for item in actions:
                    print(' {0}) {1}'.format(step, item))
                    step += 1
            return

        options = data.get('options', []) if isinstance(data, dict) else []
        self._print_runbook_block('Guided runbook context:', runbook_lines)
        if not options:
            print('No guided patient options available.')
            return

        print('')
        print('Guided patient completeness selections:')
        for item in options:
            code = str(item.get('code', '') or '').upper()
            title = item.get('title', '')
            display_id = item.get('display_id', '-')
            risk = item.get('risk_label', 'UNKNOWN')
            reason = item.get('reason', '')
            run_id = item.get('context_run_id', '') or '-'
            print(' {0}) {1}'.format(code, title))
            print('    patient={0} risk={1} run_id={2}'.format(display_id, risk, run_id))
            print('    why={0}'.format(reason))
        print(' 0) Cancel')

        choice = (self._prompt('Select guided option: ') or '').strip().upper()
        if not choice or choice == '0':
            print('Cancelled.')
            return

        print('Generating patient completeness runbook...')
        ok_open, msg_open, path = cr.open_guided_patient_completeness_runbook(
            self.repo_root, choice)
        if msg_open:
            print(msg_open)
        if ok_open and path:
            print('Opening: {0}'.format(path))
            self._launch_viewer(path)



    def _open_patient_flow_runbook_for_id(self):
        """Open patient flow runbook from auto-populated patient references."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        ok_opts, msg_opts, data_opts = cr.get_patient_flow_reference_options(self.repo_root, limit=12)
        if msg_opts:
            print(msg_opts)
        if not ok_opts or not isinstance(data_opts, dict):
            runbook_lines = data_opts.get('runbook_lines', []) if isinstance(data_opts, dict) else []
            self._print_runbook_block('Patient flow context:', runbook_lines)
            return

        options = data_opts.get('options', []) if isinstance(data_opts.get('options', []), list) else []
        if not options:
            print('No patient flow options available.')
            return

        print('')
        print('Patient flow references (auto-populated):')
        for item in options:
            idx = item.get('index', '?')
            display_id = item.get('display_id', '-')
            ref = item.get('patient_ref', '-')
            risk = item.get('risk_label', 'UNKNOWN')
            score = item.get('risk_score', 0)
            print(' {0}) patient={1} ref={2} risk={3} score={4}'.format(idx, display_id, ref, risk, score))
        print(' 0) Cancel')

        choice = (self._prompt('Select patient flow option: ') or '').strip()
        if not choice or choice == '0':
            print('Cancelled.')
            return

        selected = None
        for item in options:
            if str(item.get('index', '')) == choice:
                selected = item
                break
        if not isinstance(selected, dict):
            print('Invalid selection.')
            return

        patient_ref = str(selected.get('patient_ref', '') or '').strip()
        print('Generating patient flow runbook for {0}...'.format(patient_ref))
        ok, msg, path = cr.open_patient_flow_runbook(self.repo_root, patient_ref)
        if msg:
            print(msg)
        if ok and path:
            print('Opening: {0}'.format(path))
            self._launch_viewer(path)

    def _open_latest_artifact_triage_pack(self):
        """Open latest run-scoped artifact triage pack."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        ok, msg, path = cr.open_latest_artifact_triage_pack(self.repo_root)
        if ok and path:
            print('Opening: {0}'.format(path))
            self._launch_viewer(path)
        elif msg:
            print(msg)

    def _open_latest_run_artifact_index(self):
        """Open latest run-scoped artifact index."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        ok, msg, path = cr.open_latest_run_artifact_index(self.repo_root)
        if ok and path:
            print('Opening: {0}'.format(path))
            self._launch_viewer(path)
        elif msg:
            print(msg)

    def _open_run_artifact_index_for_run_id(self, run_id):
        """Open run-scoped artifact index for explicit run ID."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        ok, msg, path = cr.open_run_artifact_index_for_run_id(self.repo_root, run_id)
        if ok and path:
            print('Opening: {0}'.format(path))
            self._launch_viewer(path)
        elif msg:
            print(msg)

    def _send_latest_run_evidence_bundle(self):
        """Send latest coherent run evidence bundle across phases B..F."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        ok, msg, data = cr.send_latest_run_evidence_bundle(self.repo_root)
        if msg:
            print(msg)
        runbook_lines = data.get('runbook_lines', []) if isinstance(data, dict) else []
        if runbook_lines:
            print('')
            print('Bundle runbook:')
            for line in runbook_lines:
                print(' - {0}'.format(line))
        if not ok:
            print('')
            print('Opening report delivery diagnostics to help triage send failure...')
            self._open_report_delivery_status()

    def _cloud_readiness_advanced_menu(self):
        """Cloud Readiness & Advanced submenu with consolidated health-first actions."""
        cr = self._cloud_readiness_service()
        if cr is None:
            print('Cloud Readiness unavailable this session.')
            return
        bootstrap_ok, bootstrap_msg, _ = cr.ensure_lab_ready(
            self.repo_root, self.python_exe, self.environment, self._env_flag_value)
        first_loop = True
        while True:
            self._clear_console()
            self._print_legacy_banner('Cloud Readiness & Advanced Tools', width=40)
            if first_loop and bootstrap_msg:
                level = 'WARNING' if not bootstrap_ok else 'INFO'
                print('[{0}] {1}'.format(level, bootstrap_msg))
            first_loop = False
            self._print_phase_f_status()
            print('')
            self._print_troubleshooting_group('Health & Reporting', [
                '1)  Run System Health Triage now (recommended)',
                '2)  Open latest System Health Pack',
                '3)  Send latest System Health Pack',
                '4)  Guided Patient Completeness Runbook',
                '5)  Open Patient Flow Runbook (auto-populated patient list)',
                '6)  DB Inspection & Data Audit tools...',
            ])
            self._print_troubleshooting_group('Manual Pipeline Control', [
                'A) Trigger full shadow pipeline (A->F, background)',
                'B) Trigger Phase B discovery (background)',
                'C) Trigger Phase C ingest (background)',
                'D) Trigger Phase D QA (background)',
                'E) Trigger Phase E projection/parity (background)',
            ])
            self._print_troubleshooting_group('Expert / Raw Artifacts', [
                '9)  Open phase artifact tools...',
            ])
            print('Navigation')
            print(' 0)  Back to Troubleshooting menu')
            print('')
            choice = (self._prompt('Enter your choice: ') or '').strip()
            choice_u = choice.upper()
            if choice == '0':
                return
            elif choice == '1':
                print('Running system health triage (audit + pack refresh)...')
                self._run_system_health_triage()
            elif choice == '2':
                print('Opening latest System Health Pack...')
                self._open_latest_system_health_pack()
            elif choice == '3':
                _, warn_msg = cr.check_pipeline_running_for_action(
                    self.repo_root, 'Send System Health Pack')
                if warn_msg:
                    print(warn_msg)
                print('Sending latest System Health Pack...')
                self._send_latest_system_health_pack()
            elif choice == '4':
                print('Starting guided patient completeness runbook...')
                self._guided_patient_completeness_runbook()
            elif choice == '5':
                print('Opening patient flow runbook by patient reference...')
                self._open_patient_flow_runbook_for_id()
            elif choice == '6':
                self._cloud_db_inspection_menu()
            elif choice_u == 'A':
                print('Triggering full shadow pipeline (non-blocking)...')
                if self._run_shadow_pipeline():
                    self._print_manual_pipeline_runbook('A')
            elif choice_u == 'B':
                print('Triggering manual discovery run (non-blocking)...')
                if self._run_phase_b_discovery_manual():
                    self._print_manual_pipeline_runbook('B')
            elif choice_u == 'C':
                print('Triggering manual Phase C ingest pass (non-blocking)...')
                if self._run_phase_c_ingest_manual():
                    self._print_manual_pipeline_runbook('C')
            elif choice_u == 'D':
                print('Triggering manual Phase D run (non-blocking)...')
                if self._run_phase_d_manual():
                    self._print_manual_pipeline_runbook('D')
            elif choice_u == 'E':
                print('Triggering manual Phase E run (non-blocking)...')
                if self._run_phase_e_manual():
                    self._print_manual_pipeline_runbook('E')
            elif choice == '9':
                self._cloud_phase_artifacts_menu()
            else:
                print('Invalid choice.')
            try:
                self._prompt('Press Enter to return to menu...')
            except Exception:
                pass

    def _cloud_phase_artifacts_menu(self):
        """Run-centric artifact tools for latest coherent pipeline evidence."""
        while True:
            self._clear_console()
            self._print_legacy_banner('Cloud Phase Artifact Tools', width=40)
            self._print_troubleshooting_group('Run-Centric Artifact Workflow', [
                'A) Open latest Artifact Triage Pack',
                'B) Open latest run artifact index',
                'C) Send latest run evidence bundle',
                'D) Enter run ID and inspect artifact index',
            ])
            self._print_troubleshooting_group('Advanced', [
                'E) Phase-specific deep dive tools...',
                'F) Open report delivery diagnostics',
            ])
            print('Navigation')
            print(' 0)  Back to Cloud Readiness menu')
            print('')
            choice = (self._prompt('Enter your choice: ') or '').strip()
            choice_u = choice.upper()
            if choice == '0':
                return
            elif choice_u == 'A':
                print('Opening latest artifact triage pack...')
                self._open_latest_artifact_triage_pack()
            elif choice_u == 'B':
                print('Opening latest run artifact index...')
                self._open_latest_run_artifact_index()
            elif choice_u == 'C':
                self._maybe_warn_pipeline_running('Send latest run evidence bundle')
                print('Sending latest run evidence bundle...')
                self._send_latest_run_evidence_bundle()
            elif choice_u == 'D':
                run_id = (self._prompt('Enter run ID to inspect: ') or '').strip()
                if not run_id:
                    print('Cancelled.')
                else:
                    print('Opening artifact index for run {0}...'.format(run_id))
                    self._open_run_artifact_index_for_run_id(run_id)
            elif choice_u == 'E':
                self._cloud_phase_deep_dive_menu()
            elif choice_u == 'F':
                print('Opening report delivery diagnostics...')
                self._open_report_delivery_status()
            else:
                print('Invalid choice.')
            try:
                self._prompt('Press Enter to return to menu...')
            except Exception:
                pass

    def _print_deep_dive_action_runbook(self, action_key):
        """Print short runbook note for deep-dive phase action."""
        key = str(action_key or '').strip()
        print('')
        if key == '1':
            print('Runbook: Use discovery summary to confirm artifact classes/total before downstream phases.')
        elif key == '2':
            print('Runbook: Use manifest location when diagnosing ingest source selection/path drift.')
        elif key == '3':
            print('Runbook: Send B evidence when discovery outputs appear inconsistent or empty.')
        elif key == '4':
            print('Runbook: Use ingest summary to verify inserted/failed/anomaly counters.')
        elif key == '5':
            print('Runbook: Send C evidence when ingest counters or anomalies need external triage.')
        elif key == '6':
            print('Runbook: Use QA summary for pass/reject ratios and cutover quality checks.')
        elif key == '7':
            print('Runbook: Reject samples are for root-causing QA failures, not routine healthy runs.')
        elif key == '8':
            print('Runbook: Send D evidence when reject patterns need support analysis.')
        elif key == '9':
            print('Runbook: Projection summary confirms coverage and parity status.')
        elif key == '10':
            print('Runbook: Deviation samples explain projection/parity drifts in detail.')
        elif key == '11':
            print('Runbook: Send E evidence for parity/coverage escalation cases.')
        elif key == '12':
            print('Runbook: Phase F advanced is for packaging/index rebuild and strict run-id recovery.')

    def _cloud_phase_deep_dive_menu(self):
        """Deep-dive submenu for per-phase summary/sample/evidence files."""
        while True:
            self._clear_console()
            self._print_legacy_banner('Cloud Phase Deep Dive', width=40)
            self._print_troubleshooting_group('Phase B Discovery', [
                '1)  Open latest artifact discovery summary',
                '2)  Open latest manifest location',
                '3)  Send latest discovery evidence bundle',
            ])
            self._print_troubleshooting_group('Phase C Ingest', [
                '4)  Open latest Phase C summary',
                '5)  Send latest Phase C evidence bundle',
            ])
            self._print_troubleshooting_group('Phase D QA', [
                '6)  Open latest Phase D summary',
                '7)  Open latest Phase D reject sample file',
                '8)  Send Phase D evidence bundle',
            ])
            self._print_troubleshooting_group('Phase E Projection', [
                '9)  Open latest Phase E summary',
                '10) Open latest Phase E deviation sample file',
                '11) Send Phase E evidence bundle',
            ])
            self._print_troubleshooting_group('Phase F', [
                '12) Phase F advanced tools...',
            ])
            print('Navigation')
            print(' 0)  Back to Artifact Tools')
            print('')
            choice = (self._prompt('Enter your choice: ') or '').strip()
            if choice == '0':
                return
            elif choice == '1':
                self._print_deep_dive_action_runbook(choice)
                print('Opening latest artifact discovery summary...')
                self._open_phase_b_summary()
            elif choice == '2':
                self._print_deep_dive_action_runbook(choice)
                print('Opening latest manifest location...')
                self._open_phase_b_manifest_location()
            elif choice == '3':
                self._print_deep_dive_action_runbook(choice)
                self._maybe_warn_pipeline_running('Send Phase B evidence')
                print('Sending latest discovery evidence via support bundle...')
                self._send_phase_b_evidence()
            elif choice == '4':
                self._print_deep_dive_action_runbook(choice)
                print('Opening latest Phase C summary...')
                self._open_phase_c_summary()
            elif choice == '5':
                self._print_deep_dive_action_runbook(choice)
                self._maybe_warn_pipeline_running('Send Phase C evidence')
                print('Sending latest Phase C evidence via support bundle...')
                self._send_phase_c_evidence()
            elif choice == '6':
                self._print_deep_dive_action_runbook(choice)
                print('Opening latest Phase D summary...')
                self._open_phase_d_summary()
            elif choice == '7':
                self._print_deep_dive_action_runbook(choice)
                print('Opening reject sample file...')
                self._open_phase_d_reject_sample()
            elif choice == '8':
                self._print_deep_dive_action_runbook(choice)
                self._maybe_warn_pipeline_running('Send Phase D evidence')
                print('Sending Phase D evidence via support bundle...')
                self._send_phase_d_evidence()
            elif choice == '9':
                self._print_deep_dive_action_runbook(choice)
                print('Opening latest Phase E summary...')
                self._open_phase_e_summary()
            elif choice == '10':
                self._print_deep_dive_action_runbook(choice)
                print('Opening deviation sample file...')
                self._open_phase_e_deviation_samples()
            elif choice == '11':
                self._print_deep_dive_action_runbook(choice)
                self._maybe_warn_pipeline_running('Send Phase E evidence')
                print('Sending Phase E evidence via support bundle...')
                self._send_phase_e_evidence()
            elif choice == '12':
                self._print_deep_dive_action_runbook(choice)
                self._phase_f_advanced_menu()
            else:
                print('Invalid choice.')
            try:
                self._prompt('Press Enter to return to menu...')
            except Exception:
                pass

    def _phase_f_advanced_menu(self):
        """Phase F advanced submenu."""
        _RUN_ID_RE = re.compile(r'^\d{8}-\d{6}-[a-f0-9]{8}$')
        while True:
            print('')
            print('Phase F Advanced')
            print(' 1) Rebuild Shadow Health report (latest)')
            print(' 2) Rebuild Shadow Health report for run ID (strict)')
            suggested = self._get_last_shadow_pipeline_run_id()
            if suggested:
                print('     (suggested: {0})'.format(suggested))
            print(' 3) Open Phase F Evidence Index')
            print(' 0) Back')
            print('')
            choice = (self._prompt('Enter your choice: ') or '').strip()
            if choice == '0':
                return
            elif choice == '1':
                self._maybe_warn_pipeline_running('Rebuild Phase F')
                print('Triggering manual Phase F packaging pass...')
                self._run_phase_f_manual()
                try:
                    self._prompt('Press Enter to return to menu...')
                except Exception:
                    pass
            elif choice == '2':
                self._maybe_warn_pipeline_running('Rebuild Phase F (strict)')
                prompt_text = 'Enter run ID [YYYYMMDD-HHMMSS-<8hex>]'
                if suggested:
                    prompt_text += ' (suggested: {0})'.format(suggested)
                prompt_text += ': '
                rid = (self._prompt(prompt_text) or '').strip()
                if not rid:
                    print('Cancelled.')
                    try:
                        self._prompt('Press Enter to return to menu...')
                    except Exception:
                        pass
                    continue
                if not _RUN_ID_RE.match(rid):
                    confirm = (self._prompt(
                        'Format may be non-standard; proceed anyway? [y/N]: ') or '').strip().lower()
                    if confirm not in ('y', 'yes'):
                        print('Cancelled.')
                        try:
                            self._prompt('Press Enter to return to menu...')
                        except Exception:
                            pass
                        continue
                print('Triggering Phase F packaging for run {0}...'.format(rid))
                cr = self._cloud_readiness_service()
                if cr is not None:
                    ok, msg, _ = cr.run_phase_f_manual_for_run_id(
                        self.repo_root, self.python_exe, self.environment, rid)
                    if ok:
                        print('Phase F packaging started in background.')
                    elif msg:
                        print(msg)
                try:
                    self._prompt('Press Enter to return to menu...')
                except Exception:
                    pass
            elif choice == '3':
                print('Opening latest Phase F evidence index...')
                self._open_phase_f_evidence_index()
                try:
                    self._prompt('Press Enter to return to menu...')
                except Exception:
                    pass
            else:
                print('Invalid choice.')

    def _get_last_shadow_pipeline_run_id(self):
        """Return last_shadow_pipeline_run_id from diagnostics_state.json or empty string."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return ''
        lab_root = cr.resolve_lab_root(self.repo_root)
        state_path = os.path.join(lab_root, 'diagnostics_state.json')
        if not os.path.exists(state_path):
            return ''
        try:
            with open(state_path, 'r', encoding='utf-8') as f:
                state = json.load(f)
            return state.get('last_shadow_pipeline_run_id', '') or ''
        except (IOError, OSError, ValueError):
            return ''

    def _maybe_warn_pipeline_running(self, action_name):
        """Print warning if pipeline is running."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        running, warn_msg = cr.check_pipeline_running_for_action(
            self.repo_root, action_name)
        if warn_msg:
            print(warn_msg)

    def _run_phase_f_manual(self):
        """Trigger manual Phase F packaging pass (non-blocking)."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        ok, msg, _ = cr.run_phase_f_manual(
            self.repo_root, self.python_exe, self.environment)
        if ok:
            print('Phase F packaging started in background.')
        elif msg:
            print(msg)

    def _open_phase_f_evidence_index(self):
        """View latest Phase F evidence index."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        ok, msg, path = cr.open_phase_f_evidence_index(self.repo_root)
        if ok and path:
            print('Opening: {0}'.format(path))
            self._launch_viewer(path)
        elif msg:
            print(msg)
