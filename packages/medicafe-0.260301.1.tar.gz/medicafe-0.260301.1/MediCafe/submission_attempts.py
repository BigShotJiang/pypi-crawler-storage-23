"""
submission_attempts.py - Lightweight submission attempt ledger and retry helpers.

Purpose:
- Track submission attempts with custody-aware status for safer retries.
- Provide a minimal JSONL ledger without requiring database dependencies.
"""
from __future__ import print_function
import os
import json
import time

ATTEMPTS_FILENAME = "submission_attempts.jsonl"

# Status -> custody mapping (safe default: out_of_custody)
_STATUS_CUSTODY = {
    "conversion_failed": "in_custody",
    "upload_failed": "in_custody",
    "api_error": "in_custody",
    "submitted": "out_of_custody",
    "pending_ack": "out_of_custody",
    "ack_query_failed": "out_of_custody",
    "rejected_277": "returned_to_custody",
    "rejected_999": "returned_to_custody",
}


def _extract_medilink_config(config):
    if isinstance(config, dict) and isinstance(config.get("MediLink_Config"), dict):
        return config.get("MediLink_Config")
    return config if isinstance(config, dict) else {}


def get_attempts_root(config):
    cfg = _extract_medilink_config(config)
    root = cfg.get("local_claims_path") or cfg.get("local_storage_path") or "."
    return root


def get_attempts_path(config):
    return os.path.join(get_attempts_root(config), ATTEMPTS_FILENAME)


def append_attempt(config, record):
    try:
        path = get_attempts_path(config)
        with open(path, "a") as f:
            f.write(json.dumps(record))
            f.write("\n")
    except Exception:
        pass


def load_attempts(config, max_records=5000):
    attempts = []
    try:
        path = get_attempts_path(config)
        if not os.path.exists(path):
            return attempts
        with open(path, "r") as f:
            for line in f:
                if not line.strip():
                    continue
                try:
                    rec = json.loads(line)
                    if isinstance(rec, dict):
                        attempts.append(rec)
                except Exception:
                    continue
        if max_records and len(attempts) > max_records:
            return attempts[-max_records:]
    except Exception:
        return attempts
    return attempts


def status_to_custody(status):
    return _STATUS_CUSTODY.get(status, "out_of_custody")


def latest_attempts_by_claim_key(attempts):
    latest = {}
    for rec in attempts:
        try:
            key = rec.get("claim_key", "")
            if not key:
                continue
            ts = rec.get("attempt_at", 0) or 0
            if key not in latest or ts >= (latest[key].get("attempt_at", 0) or 0):
                latest[key] = rec
        except Exception:
            continue
    return latest


def summarize_attempts_for_claims(claim_keys, attempts):
    summary = {
        "attempted": 0,
        "no_attempt": 0,
        "in_custody": 0,
        "returned_to_custody": 0,
        "out_of_custody": 0,
        "unknown": 0,
    }
    latest = latest_attempts_by_claim_key(attempts)
    for key in claim_keys:
        rec = latest.get(key)
        if not rec:
            summary["no_attempt"] += 1
            continue
        summary["attempted"] += 1
        status = rec.get("status", "")
        custody = rec.get("custody", status_to_custody(status))
        if custody in summary:
            summary[custody] += 1
        else:
            summary["unknown"] += 1
    return summary, latest


def filter_candidates(patient_data_list, latest_attempts, include_rejected=False):
    """
    Return a filtered list of patient data entries based on custody-aware retry rules.
    - Always include entries with no prior attempt.
    - Include in-custody failures.
    - Include returned-to-custody (rejected) only if include_rejected is True.
    """
    filtered = []
    for data in patient_data_list:
        try:
            claim_key = data.get("claim_key", "")
            rec = latest_attempts.get(claim_key) if claim_key else None
            if not rec:
                filtered.append(data)
                continue
            status = rec.get("status", "")
            custody = rec.get("custody", status_to_custody(status))
            if custody == "in_custody":
                filtered.append(data)
            elif include_rejected and custody == "returned_to_custody":
                filtered.append(data)
        except Exception:
            filtered.append(data)
    return filtered


def build_attempt_record(
    claim_key,
    endpoint,
    status,
    file_path="",
    submission_method="",
    submission_type="",
    run_id="",
    transaction_id="",
    note="",
):
    attempt_at = int(time.time())
    custody = status_to_custody(status)
    return {
        "attempt_at": attempt_at,
        "run_id": run_id,
        "claim_key": claim_key or "",
        "endpoint": endpoint or "",
        "status": status or "",
        "custody": custody,
        "file_path": file_path or "",
        "submission_method": submission_method or "",
        "submission_type": submission_type or "",
        "transaction_id": transaction_id or "",
        "note": note or "",
    }
