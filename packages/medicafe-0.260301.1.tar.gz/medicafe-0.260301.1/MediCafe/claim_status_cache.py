"""
claim_status_cache.py - Persistent cache for post-submission claim status lookups.

Purpose:
- Store last status result per submission (keyed by transaction_id+payer_id or payer_id+member_id+dos)
- Avoid repeated API calls when status is final or recently checked (recency + finality)
- Support detail view by storing full last_result for display_submission_context_results (DRY)

Design:
- Backed by a single JSON file in receipts_root (same as submission index)
- Hardcoded refresh threshold (e.g. 3 hours) and final status list
- Lock file for process-safe read/modify/write (pattern from submission_index)
"""
import os
import json
import time

# Hardcoded defaults (no config keys per plan)
REFRESH_THRESHOLD_HOURS = 3
CLAIM_STATUS_FINAL_STATUSES = ["Finalized", "Rejected", "Paid", "Denied"]

CACHE_FILENAME = 'claim_status_cache.json'
LOCK_FILENAME = 'claim_status_cache.lock'


def _cache_path(root_dir):
    return os.path.join(root_dir, CACHE_FILENAME)


def _lock_path(root_dir):
    return os.path.join(root_dir, LOCK_FILENAME)


def _ensure_cache_exists(root_dir):
    """Create empty cache file if missing."""
    if not root_dir or not os.path.isdir(root_dir):
        return
    path = _cache_path(root_dir)
    if not os.path.exists(path):
        try:
            with open(path, 'w') as f:
                f.write("{}")
        except Exception:
            pass


def _try_acquire_lock(root_dir):
    """Acquire exclusive lock (same pattern as submission_index)."""
    lock = _lock_path(root_dir)
    try:
        fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.close(fd)
        return True
    except Exception:
        return False


def _release_lock(root_dir):
    """Release lock."""
    try:
        os.remove(_lock_path(root_dir))
    except Exception:
        pass


def _normalize_dos_for_key(record):
    """Get DOS from record and normalize to a string for cache key. Returns empty string if missing."""
    if not record or not isinstance(record, dict):
        return ''
    dos = (record.get('dos') or record.get('date_of_service') or record.get('service_start_date') or '').strip()
    if not dos:
        return ''
    # Normalize to YYYY-MM-DD if possible for consistent keys
    try:
        from MediCafe.deductible_utils import validate_and_format_date
        normalized = validate_and_format_date(dos)
        if normalized:
            return normalized
    except Exception:
        pass
    for fmt in ["%m/%d/%Y", "%m-%d-%Y", "%Y-%m-%d", "%m/%d/%y"]:
        try:
            from datetime import datetime
            dt = datetime.strptime(dos, fmt)
            return dt.strftime("%Y-%m-%d")
        except Exception:
            continue
    return dos


def get_cache_key(submission_record):
    """
    Produce a stable cache key from a submission record.
    Prefer transaction_id|payer_id when both exist; else payer_id|member_id|dos.
    Returns None if we cannot form a usable key.
    """
    if not submission_record or not isinstance(submission_record, dict):
        return None
    payer_id = (submission_record.get('payer_id') or submission_record.get('payerId') or '').strip()
    transaction_id = (submission_record.get('transactionId') or submission_record.get('transaction_id') or '').strip()
    if transaction_id and payer_id:
        return "{}|{}".format(transaction_id, payer_id)
    member_id = (submission_record.get('member_id') or submission_record.get('memberId') or submission_record.get('patient_id') or '').strip()
    dos = _normalize_dos_for_key(submission_record)
    if payer_id and member_id and dos:
        return "{}|{}|{}".format(payer_id, member_id, dos)
    if payer_id and dos:
        return "{}||{}".format(payer_id, dos)
    return None


def get_cached_status(receipts_root, key):
    """
    Get cached status entry for key, or None if missing/expired not applicable.
    Entry: dict with last_checked_at, final, summary, statuscode, lookup_type, last_result.
    """
    if not receipts_root or not key:
        return None
    path = _cache_path(receipts_root)
    if not os.path.exists(path):
        return None
    try:
        with open(path, 'r') as f:
            data = f.read()
        cache = json.loads(data) if data.strip() else {}
        if not isinstance(cache, dict):
            return None
        return cache.get(key)
    except Exception:
        return None


def set_cached_status(receipts_root, key, final, summary, statuscode=None, lookup_type=None, last_result=None):
    """Write or update cache entry for key. Uses lock for process safety."""
    if not receipts_root or not key:
        return
    _ensure_cache_exists(receipts_root)
    if not _try_acquire_lock(receipts_root):
        return
    try:
        path = _cache_path(receipts_root)
        cache = {}
        if os.path.exists(path):
            try:
                with open(path, 'r') as f:
                    data = f.read()
                cache = json.loads(data) if data.strip() else {}
            except Exception:
                pass
        if not isinstance(cache, dict):
            cache = {}
        entry = {
            'last_checked_at': time.time(),
            'final': bool(final),
            'summary': summary if isinstance(summary, dict) else {},
        }
        if statuscode is not None:
            entry['statuscode'] = statuscode
        if lookup_type is not None:
            entry['lookup_type'] = lookup_type
        if last_result is not None:
            entry['last_result'] = last_result
        cache[key] = entry
        with open(path, 'w') as f:
            f.write(json.dumps(cache))
    finally:
        _release_lock(receipts_root)


def is_within_refresh_window(last_checked_at, threshold_hours=REFRESH_THRESHOLD_HOURS):
    """Return True if last_checked_at is within the last threshold_hours."""
    if last_checked_at is None:
        return False
    try:
        t = float(last_checked_at)
        return (time.time() - t) < (threshold_hours * 3600)
    except (TypeError, ValueError):
        return False


def is_final_result(result):
    """
    Determine if the get_claim_status_by_submission_context result is final
    (we should stop re-checking). Uses hardcoded final status list and no-data/error rules.
    """
    if not result or not isinstance(result, dict):
        return False
    # Permanent no-data / known unrecoverable errors -> final
    statuscode = result.get('statuscode', '')
    message = (result.get('message') or '').lower()
    if statuscode in ('404', '400'):
        if 'lclm_ps_201' in message or 'lclm_ps_203' in message or 'no data' in message:
            return True
    # 277CA: if we have a definitive response (accepted/rejected), could be final
    ack = result.get('ack_277ca')
    if isinstance(ack, dict) and ack.get('statuscode') == '000':
        # 277CA success often means claim accepted; treat as final for "no more telemetry" simplicity
        # If we want to keep re-checking for 277CA-accepted claims, set this to False
        pass
    # Member-data claim status: any claim with final status -> final
    claim_status = result.get('claim_status')
    if isinstance(claim_status, dict):
        claims = claim_status.get('claims') or []
        for c in claims:
            if not isinstance(c, dict):
                continue
            status = (c.get('claimStatus') or '').strip()
            if status and status in CLAIM_STATUS_FINAL_STATUSES:
                return True
    return False


def parse_result_to_summary(result):
    """
    Build a summary dict (status_display, claim_number, paid_amount, patient_name) and final flag
    from get_claim_status_by_submission_context result. Used for table display and cache.
    """
    summary = {'status_display': '', 'claim_number': '', 'paid_amount': '', 'patient_name': ''}
    if not result or not isinstance(result, dict):
        summary['status_display'] = 'Error: no response'
        return summary, False
    statuscode = result.get('statuscode', '')
    message = (result.get('message') or '').strip()
    claim_status = result.get('claim_status')
    ack_277ca = result.get('ack_277ca')
    # Prefer claim status from member-data lookup
    if isinstance(claim_status, dict):
        claims = claim_status.get('claims') or []
        if claims:
            c = claims[0]
            summary['status_display'] = (c.get('claimStatus') or '').strip() or 'Unknown'
            claim_summary = c.get('claimSummary') or {}
            summary['claim_number'] = (c.get('claimNumber') or '').strip()
            summary['paid_amount'] = (claim_summary.get('totalPaidAmt') or claim_summary.get('totalPaidAmount') or '0.00')
            mi = c.get('memberInfo') or {}
            fn = (mi.get('ptntFn') or mi.get('firstName') or '').strip()
            ln = (mi.get('ptntLn') or mi.get('lastName') or '').strip()
            summary['patient_name'] = "{} {}".format(fn, ln).strip()
        else:
            summary['status_display'] = message or 'No claims found'
    elif isinstance(ack_277ca, dict):
        summary['status_display'] = message or ack_277ca.get('message') or '277CA: {}'.format(ack_277ca.get('statuscode', ''))
    else:
        summary['status_display'] = message or 'No data'
    final = is_final_result(result)
    return summary, final
