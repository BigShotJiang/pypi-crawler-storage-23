"""
reconciliation.py - Read-only reconciliation gate comparing submission vs remittance.

Purpose:
- Compare submission attempts/index against remittance records
- Classify mismatches: missing_remittance, duplicate_remittance, amount_status_mismatch, orphan_remittance
- Emit human-readable summary and machine-readable artifacts (JSON, CSV)
- Built-in severity model: PASS/WARN/FAIL

Full operator guide: docs/reconciliation_reference.md
"""
from __future__ import print_function
import os
import json
import re
import csv
from datetime import datetime

# Severity constants
SEVERITY_PASS = 'PASS'
SEVERITY_WARN = 'WARN'
SEVERITY_FAIL = 'FAIL'

# Thresholds (document in docs/reconciliation_reference.md)
FAIL_MISSING_ABSOLUTE = 5
FAIL_MISSING_RATIO = 0.5
FAIL_ORPHAN_ABSOLUTE = 10
FAIL_ORPHAN_RATIO = 0.6
FAIL_DUPLICATE_ABSOLUTE = 3

# Next actions by category
NEXT_ACTIONS = {
    'missing_remittance': 'Check ERA download or payer processing status',
    'duplicate_remittance': 'Review ERA sources; merge or deduplicate records',
    'amount_status_mismatch': 'Verify submission status vs remittance; reconcile amounts',
    'orphan_remittance': 'Confirm claim was submitted via MediCafe or is legacy',
}


def normalize_patient_id(value):
    """Strip whitespace; coerce to str; return '' for None/empty."""
    if value is None:
        return ''
    return str(value).strip()


def normalize_payer_id(value):
    """Same as patient_id. Prefer payer_id over primary_insurance when both exist."""
    if value is None:
        return ''
    return str(value).strip()


def normalize_dos(value):
    """
    Convert to YYYYMMDD. Supported inputs:
    - '20250101' -> '20250101'
    - '2025-01-01' -> '20250101'
    - '01/15/2025' -> '20250115'
    - int/float (Unix timestamp) -> YYYYMMDD via datetime
    - '' or invalid -> ''
    """
    if value is None:
        return ''
    s = str(value).strip()
    if not s:
        return ''
    # YYYYMMDD (8 digits)
    if re.match(r'^\d{8}$', s):
        return s
    # YYYY-MM-DD
    m = re.match(r'^(\d{4})-(\d{2})-(\d{2})', s)
    if m:
        return m.group(1) + m.group(2) + m.group(3)
    # MM/DD/YYYY
    m = re.match(r'^(\d{1,2})/(\d{1,2})/(\d{4})', s)
    if m:
        try:
            mm, dd, yyyy = int(m.group(1)), int(m.group(2)), int(m.group(3))
            return '{:04d}{:02d}{:02d}'.format(yyyy, mm, dd)
        except (ValueError, TypeError):
            return ''
    # Unix timestamp
    try:
        ts = float(s)
        dt = datetime.utcfromtimestamp(ts)
        return dt.strftime('%Y%m%d')
    except (ValueError, TypeError, OSError):
        pass
    return ''


def _parse_claim_key_patient(claim_key):
    """claim_key = patient_id|payer_or_primary|dos|service_hash (4 parts, submission_index.compute_claim_key)"""
    if not claim_key:
        return ''
    parts = str(claim_key).split('|')
    return normalize_patient_id(parts[0] if parts else '')


def adapter_submission_index(raw):
    """
    Extract (patient_id, dos, payer_id). Prefer patient_id from record; else parse first segment of claim_key.
    Returns (key, enriched_record) or None if key incomplete (missing patient_id or dos).
    """
    pid = normalize_patient_id(raw.get('patient_id') or _parse_claim_key_patient(raw.get('claim_key')))
    dos = normalize_dos(raw.get('dos', ''))
    payer = normalize_payer_id(raw.get('payer_id') or raw.get('primary_insurance', ''))
    if not pid or not dos:
        return None
    key = (pid, dos, payer or '')
    enriched = {'_raw': raw, 'claim_key': raw.get('claim_key'), 'source': 'submission_index'}
    return (key, enriched)


def adapter_submission_attempt(claim_key, raw, index_lookup):
    """
    claim_key format (from submission_index.compute_claim_key): 4 parts
      patient_id | payer_id_or_primary | date_of_service | service_hash
    Parse: parts[0]=patient_id, parts[1]=payer, parts[2]=dos, parts[3]=service_hash.
    Fallback: lookup from index_lookup[claim_key] if key incomplete.
    """
    parts = (claim_key or '').split('|')
    pid = normalize_patient_id(parts[0] if len(parts) > 0 else '')
    payer = normalize_payer_id(parts[1] if len(parts) > 1 else '')
    dos = normalize_dos(parts[2] if len(parts) > 2 else '')
    if not pid or not dos:
        idx = index_lookup.get(claim_key) if claim_key else None
        if idx:
            return adapter_submission_index(idx)
        return None
    key = (pid, dos, payer or '')
    enriched = {'_raw': raw, 'claim_key': claim_key, 'source': 'submission_attempt'}
    return (key, enriched)


def adapter_remittance(raw):
    """
    Use patid, dos, payer_id. Return None if patid or dos missing.
    Rows without patid are skipped (cannot build canonical key).
    """
    pid = normalize_patient_id(raw.get('patid', ''))
    dos = normalize_dos(raw.get('dos', ''))
    payer = normalize_payer_id(raw.get('payer_id', ''))
    if not pid or not dos:
        return None
    key = (pid, dos, payer or '')
    enriched = {'_raw': raw, 'claim_number': raw.get('claim_number'), 'source': 'remittance_parsed'}
    return (key, enriched)


def load_submission_index(receipts_root):
    """Load submission_index.jsonl, skip ack events. Returns list of dicts."""
    from MediCafe.submission_index import _index_path
    path = _index_path(receipts_root)
    records = []
    if not os.path.exists(path):
        return records
    try:
        with open(path, 'r') as f:
            for line in f:
                if not line.strip():
                    continue
                try:
                    entry = json.loads(line.strip())
                    if not isinstance(entry, dict):
                        continue
                    if entry.get('notes') == 'ack event':
                        continue
                    records.append(entry)
                except (ValueError, TypeError):
                    continue
    except (IOError, OSError):
        pass
    return records


def load_remittance_parsed(storage_path):
    """Load remittance_parsed.jsonl. Returns list of dicts."""
    path = os.path.join(storage_path, 'remittance_parsed.jsonl')
    records = []
    if not os.path.exists(path):
        return records
    try:
        with open(path, 'r') as f:
            for line in f:
                if not line.strip():
                    continue
                try:
                    entry = json.loads(line.strip())
                    if isinstance(entry, dict):
                        records.append(entry)
                except (ValueError, TypeError):
                    continue
    except (IOError, OSError):
        pass
    return records


def _status_mismatch(sub_rec, rem_rec):
    """Submission says submitted/pending_ack but remittance says Reject/Denied, or vice versa."""
    sub_status = str(sub_rec.get('_raw', {}).get('status', '')).lower()
    rem_status = str(rem_rec.get('_raw', {}).get('status', '')).lower()
    sub_submitted = sub_status in ('submitted', 'pending_ack')
    rem_reject = 'reject' in rem_status or 'denied' in rem_status
    if sub_submitted and rem_reject:
        return True
    if sub_status in ('rejected_277', 'rejected_999') and ('accept' in rem_status or 'approved' in rem_status):
        return True
    return False


def _amount_mismatch(sub_rec, rem_rec):
    """Optional: both have paid and values differ by > 0.01."""
    try:
        rem_paid = rem_rec.get('_raw', {}).get('paid', '')
        if not rem_paid:
            return False
        rem_val = float(str(rem_paid).replace(',', ''))
        sub_raw = sub_rec.get('_raw', {})
        if 'paid' not in sub_raw:
            return False
        sub_val = float(str(sub_raw.get('paid', '')).replace(',', ''))
        return abs(rem_val - sub_val) > 0.01
    except (ValueError, TypeError):
        return False


def _build_finding(category, key, sub_recs, rem_recs, detail):
    """Build a finding record."""
    pid, dos, payer = key
    claim_key = None
    claim_number = None
    if sub_recs:
        claim_key = sub_recs[0].get('claim_key')
    if rem_recs:
        claim_number = rem_recs[0].get('claim_number')
    refs = []
    if sub_recs:
        refs.append(sub_recs[0].get('source', 'submission_index'))
    if rem_recs:
        refs.append('remittance_parsed')
    if not refs:
        refs = ['submission_index', 'remittance_parsed']
    return {
        'category': category,
        'patient_id': pid,
        'dos': dos,
        'payer_id': payer,
        'claim_key': claim_key,
        'claim_number': claim_number,
        'detail': detail,
        'next_action': NEXT_ACTIONS.get(category, 'Review manually'),
        'source_refs': refs,
    }


def run_reconciliation(config, receipts_root, storage_path):
    """
    Run full reconciliation. Returns dict with severity, totals, counts, findings.
    """
    sub_by_key = {}
    rem_by_key = {}
    index_records = {}

    # Load submission index
    index_rows = load_submission_index(receipts_root)
    for raw in index_rows:
        result = adapter_submission_index(raw)
        if result:
            key, enriched = result
            sub_by_key.setdefault(key, []).append(enriched)
            if enriched.get('claim_key'):
                index_records[enriched['claim_key']] = raw

    # Load submission attempts and merge
    try:
        from MediCafe import submission_attempts
        attempts = submission_attempts.load_attempts(config, max_records=5000)
        latest = submission_attempts.latest_attempts_by_claim_key(attempts)
        for ck, rec in latest.items():
            status = rec.get('status', '')
            custody = rec.get('custody', submission_attempts.status_to_custody(status))
            if status in ('submitted', 'pending_ack') or custody == 'out_of_custody':
                result = adapter_submission_attempt(ck, rec, index_records)
                if result:
                    key, enriched = result
                    sub_by_key.setdefault(key, []).append(enriched)
    except (ImportError, AttributeError):
        pass

    # Load remittance parsed
    rem_rows = load_remittance_parsed(storage_path)
    for raw in rem_rows:
        result = adapter_remittance(raw)
        if result:
            key, enriched = result
            rem_by_key.setdefault(key, []).append(enriched)

    submission_keys = set(sub_by_key.keys())
    remittance_keys = set(rem_by_key.keys())

    findings = {
        'missing_remittance': [],
        'duplicate_remittance': [],
        'amount_status_mismatch': [],
        'orphan_remittance': [],
    }

    for k in submission_keys:
        if k not in remittance_keys:
            findings['missing_remittance'].append(_build_finding(
                'missing_remittance', k, sub_by_key[k], None,
                'No remittance for submitted claim'
            ))

    for k, recs in rem_by_key.items():
        if len(recs) > 1:
            findings['duplicate_remittance'].append(_build_finding(
                'duplicate_remittance', k, None, recs,
                'Multiple remittance records for same claim'
            ))

    for k in submission_keys & remittance_keys:
        sub_recs, rem_recs = sub_by_key[k], rem_by_key[k]
        if _status_mismatch(sub_recs[0], rem_recs[0]) or _amount_mismatch(sub_recs[0], rem_recs[0]):
            findings['amount_status_mismatch'].append(_build_finding(
                'amount_status_mismatch', k, sub_recs, rem_recs,
                'Status or amount mismatch between submission and remittance'
            ))

    for k in remittance_keys:
        if k not in submission_keys:
            findings['orphan_remittance'].append(_build_finding(
                'orphan_remittance', k, None, rem_by_key[k],
                'Remittance with no matching submission'
            ))

    totals = {'submissions': len(submission_keys), 'remittances': len(remittance_keys)}
    counts = {cat: len(findings[cat]) for cat in findings}
    severity = evaluate_gate_severity(findings, totals)

    return {
        'run_at': datetime.now().strftime('%Y-%m-%dT%H:%M:%S'),
        'severity': severity,
        'totals': totals,
        'counts': counts,
        'findings': findings,
    }


def evaluate_gate_severity(findings, totals):
    """
    totals = {'submissions': int, 'remittances': int}
    Returns SEVERITY_PASS | SEVERITY_WARN | SEVERITY_FAIL
    """
    m = len(findings['missing_remittance'])
    o = len(findings['orphan_remittance'])
    d = len(findings['duplicate_remittance'])
    a = len(findings['amount_status_mismatch'])
    sub = totals.get('submissions', 0)
    rem = totals.get('remittances', 0)

    if m >= FAIL_MISSING_ABSOLUTE or (sub and m / float(sub) >= FAIL_MISSING_RATIO):
        return SEVERITY_FAIL
    if o >= FAIL_ORPHAN_ABSOLUTE or (rem and o / float(rem) >= FAIL_ORPHAN_RATIO):
        return SEVERITY_FAIL
    if d >= FAIL_DUPLICATE_ABSOLUTE:
        return SEVERITY_FAIL

    if m or o or d or a:
        return SEVERITY_WARN
    return SEVERITY_PASS


def print_reconciliation_summary(result, storage_path):
    """Print human-readable console summary."""
    totals = result.get('totals', {})
    counts = result.get('counts', {})
    severity = result.get('severity', 'PASS')
    findings = result.get('findings', {})

    print("")
    print("Reconciliation Report")
    print("=" * 40)
    print("Submissions: {}  |  Remittances: {}".format(
        totals.get('submissions', 0), totals.get('remittances', 0)))
    print("Severity: {}".format(severity))
    print("")
    print("Counts:")
    for cat in ('missing_remittance', 'duplicate_remittance', 'amount_status_mismatch', 'orphan_remittance'):
        print("  {}: {}".format(cat, counts.get(cat, 0)))
    print("")

    for cat in ('missing_remittance', 'duplicate_remittance', 'amount_status_mismatch', 'orphan_remittance'):
        items = findings.get(cat, [])
        if items:
            print("Examples ({}):".format(cat))
            for f in items[:3]:
                print("  {} | {} | {}  - {}".format(
                    f.get('patient_id', ''),
                    f.get('dos', ''),
                    f.get('payer_id', ''),
                    f.get('detail', '')))
                print("  Next action: {}".format(f.get('next_action', '')))
            if len(items) > 3:
                print("  ... and {} more".format(len(items) - 3))
            print("")

    json_path = os.path.join(storage_path, 'reconciliation_report.json')
    csv_path = os.path.join(storage_path, 'reconciliation_report.csv')
    print("Artifacts: {}, {}".format(json_path, csv_path))
    print("")


def write_reconciliation_artifacts(result, storage_path):
    """Write JSON and CSV artifacts. Ensures directory exists."""
    if not os.path.isdir(storage_path):
        try:
            os.makedirs(storage_path)
        except OSError:
            pass

    json_path = os.path.join(storage_path, 'reconciliation_report.json')
    csv_path = os.path.join(storage_path, 'reconciliation_report.csv')

    # Flatten findings for JSON
    all_findings = []
    for cat in ('missing_remittance', 'duplicate_remittance', 'amount_status_mismatch', 'orphan_remittance'):
        for f in result.get('findings', {}).get(cat, []):
            all_findings.append(f)

    report = {
        'run_at': result.get('run_at', ''),
        'severity': result.get('severity', ''),
        'totals': result.get('totals', {}),
        'counts': result.get('counts', {}),
        'findings': all_findings,
    }

    try:
        with open(json_path, 'w') as f:
            json.dump(report, f, indent=2)
    except (IOError, OSError):
        pass

    try:
        with open(csv_path, 'w') as f:
            writer = csv.DictWriter(f, fieldnames=[
                'category', 'patient_id', 'dos', 'payer_id', 'claim_key', 'claim_number',
                'detail', 'next_action'
            ], lineterminator='\n')
            writer.writeheader()
            for row in sorted(all_findings, key=lambda x: (x.get('category', ''), x.get('patient_id', ''), x.get('dos', ''))):
                writer.writerow({
                    'category': row.get('category', ''),
                    'patient_id': row.get('patient_id', ''),
                    'dos': row.get('dos', ''),
                    'payer_id': row.get('payer_id', ''),
                    'claim_key': row.get('claim_key', '') or '',
                    'claim_number': row.get('claim_number', '') or '',
                    'detail': row.get('detail', ''),
                    'next_action': row.get('next_action', ''),
                })
    except (IOError, OSError):
        pass
