# Obtain an OAuth refresh token for daniel@strategicimplementation.us and store it in Secret Manager.
# Requires:
#   - gcloud CLI authenticated (gcloud auth login)
#   - Secrets already created: gmail_oauth_client_id, gmail_oauth_client_secret, gmail_oauth_refresh_token
# Usage:
#   .\get_gmail_oauth_token.ps1 -ProjectId genial-analyzer-476721-f8
#   .\get_gmail_oauth_token.ps1 -ProjectId genial-analyzer-476721-f8 -ClientJsonPath cloud/orchestrator/json/client_secret_*.json

param(
    [string]$ProjectId = "genial-analyzer-476721-f8",
    [string]$Mailbox = "daniel@strategicimplementation.us",
    [string]$ClientIdSecret = "gmail_oauth_client_id",
    [string]$ClientSecretSecret = "gmail_oauth_client_secret",
    [string]$RefreshTokenSecret = "gmail_oauth_refresh_token",
    [string[]]$Scopes = @("https://www.googleapis.com/auth/gmail.modify"),
    [string]$ClientJsonPath = "",
    [switch]$NoBrowser
)

function Find-Gcloud {
    $gcloudPath = "$env:USERPROFILE\AppData\Local\Google\Cloud SDK\google-cloud-sdk\bin\gcloud.cmd"
    if (Test-Path $gcloudPath) {
        return $gcloudPath
    }
    Write-Host "❌ gcloud CLI not found. Install https://cloud.google.com/sdk/docs/install" -ForegroundColor Red
    throw "gcloud CLI not found"
}

function Fail([string]$Message, [string]$Hint = "") {
    Write-Host "❌ $Message" -ForegroundColor Red
    if ($Hint) {
        Write-Host $Hint -ForegroundColor Yellow
    }
    throw $Message
}

function Get-ScriptDirectory {
    if ($PSScriptRoot -and -not [string]::IsNullOrWhiteSpace($PSScriptRoot)) {
        return $PSScriptRoot
    }
    if ($MyInvocation.MyCommand.Path) {
        return (Split-Path -Parent $MyInvocation.MyCommand.Path)
    }
    return (Get-Location).Path
}

function Add-SecretVersionFromValue(
    [string]$GcloudExe,
    [string]$Project,
    [string]$SecretName,
    [string]$Value
) {
    $tempPath = Join-Path $env:TEMP ("secret_value_{0}.txt" -f [System.Guid]::NewGuid().ToString("N"))
    try {
        $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllText($tempPath, $Value, $utf8NoBom)
        $result = & $GcloudExe secrets versions add $SecretName --data-file=$tempPath --project $Project 2>&1
        if ($LASTEXITCODE -ne 0) {
            Write-Host $result -ForegroundColor Yellow
            Fail "Failed to update secret '$SecretName'"
        }
    } finally {
        Remove-Item $tempPath -ErrorAction SilentlyContinue
    }
}

function Normalize-SecretValue([string]$Value) {
    if ($null -eq $Value) {
        return ""
    }
    return $Value.Trim().TrimStart([char]0xFEFF)
}

$gcloudExe = Find-Gcloud
$scriptDir = Get-ScriptDirectory

Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "GMAIL OAUTH TOKEN SETUP" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "Project: $ProjectId" -ForegroundColor White
Write-Host "Mailbox: $Mailbox" -ForegroundColor White
Write-Host "ClientIdSecret: $ClientIdSecret" -ForegroundColor Gray
Write-Host "ClientSecretSecret: $ClientSecretSecret" -ForegroundColor Gray
Write-Host "RefreshTokenSecret: $RefreshTokenSecret" -ForegroundColor Gray
Write-Host "Scopes: $($Scopes -join ', ')" -ForegroundColor Gray
if ($ClientJsonPath) {
    Write-Host "ClientJsonPath: $ClientJsonPath" -ForegroundColor Gray
}
Write-Host ""

# Verify gcloud auth
$authUser = & $gcloudExe config get-value account 2>$null
if ($LASTEXITCODE -ne 0 -or -not $authUser) {
    Fail "gcloud not authenticated" "Run: gcloud auth login"
}
Write-Host "✅ gcloud authenticated as: $authUser" -ForegroundColor Green

# Ensure project is set
$configProject = & $gcloudExe config get-value project 2>$null
if ($configProject -ne $ProjectId) {
    Fail "gcloud project mismatch (current: $configProject)" "Run: gcloud config set project $ProjectId"
}
Write-Host "✅ gcloud project matches" -ForegroundColor Green

# Ensure Python available
try {
    $pythonVersion = & "C:\Python311\python.exe" --version 2>$null
    if ($LASTEXITCODE -ne 0) { throw "Python not found" }
    Write-Host "✅ Python available: $pythonVersion" -ForegroundColor Green
} catch {
    Fail "Python 3.11 not found at C:\Python311\python.exe"
}

# Ensure dependencies installed
$requirementsCandidates = @(
    (Join-Path $scriptDir "requirements.txt"),
    (Join-Path $scriptDir "tools\requirements.txt"),
    (Join-Path (Get-Location).Path "tools\requirements.txt")
) | Select-Object -Unique

$requirementsPath = $requirementsCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1

if ($requirementsPath) {
    $installResult = & "C:\Python311\python.exe" -m pip install -r $requirementsPath 2>&1
} else {
    Write-Host "⚠️  requirements.txt not found; installing required packages directly." -ForegroundColor Yellow
    $installResult = & "C:\Python311\python.exe" -m pip install google-api-python-client google-auth google-auth-httplib2 google-auth-oauthlib google-cloud-secret-manager 2>&1
}
if ($LASTEXITCODE -ne 0) {
    Write-Host $installResult -ForegroundColor Yellow
    Fail "Failed to install dependencies"
}
Write-Host "✅ Dependencies installed" -ForegroundColor Green

# Optionally refresh OAuth client id/secret from a local OAuth JSON before requesting token.
$jsonClientId = ""
$jsonClientSecret = ""
if ($ClientJsonPath) {
    try {
        $resolvedClientJsonPath = (Resolve-Path -LiteralPath $ClientJsonPath).Path
    } catch {
        Fail "OAuth client JSON path not found: $ClientJsonPath"
    }
    try {
        $oauthJson = Get-Content -LiteralPath $resolvedClientJsonPath -Raw | ConvertFrom-Json
    } catch {
        Fail "Failed to parse OAuth client JSON: $resolvedClientJsonPath"
    }

    $oauthBlock = $null
    if ($oauthJson.installed) {
        $oauthBlock = $oauthJson.installed
    } elseif ($oauthJson.web) {
        $oauthBlock = $oauthJson.web
    } else {
        Fail "OAuth client JSON must contain 'installed' or 'web' block."
    }

    $jsonClientId = [string]$oauthBlock.client_id
    $jsonClientSecret = [string]$oauthBlock.client_secret
    if ([string]::IsNullOrWhiteSpace($jsonClientId) -or [string]::IsNullOrWhiteSpace($jsonClientSecret)) {
        Fail "OAuth client JSON is missing client_id or client_secret."
    }

    Add-SecretVersionFromValue -GcloudExe $gcloudExe -Project $ProjectId -SecretName $ClientIdSecret -Value $jsonClientId
    Add-SecretVersionFromValue -GcloudExe $gcloudExe -Project $ProjectId -SecretName $ClientSecretSecret -Value $jsonClientSecret
    Write-Host "✅ Updated OAuth client secrets from JSON" -ForegroundColor Green
}

# Read OAuth client values from Secret Manager via gcloud (avoids Python ADC dependency).
$clientIdValue = ""
$clientSecretValue = ""
$idRead = & $gcloudExe secrets versions access latest --secret=$ClientIdSecret --project $ProjectId 2>&1
$idReadExit = $LASTEXITCODE
$secretReadFailed = $false
if ($idReadExit -eq 0) {
    $clientIdValue = Normalize-SecretValue (($idRead -join "`n"))
    if ([string]::IsNullOrWhiteSpace($clientIdValue)) {
        $secretReadFailed = $true
    }
} else {
    $secretReadFailed = $true
}

$secretReadError = ""
if ($secretReadFailed) {
    $secretReadError = (($idRead -join "`n")).Trim()
}

$secretReadFailed2 = $false
$secretRead2 = & $gcloudExe secrets versions access latest --secret=$ClientSecretSecret --project $ProjectId 2>&1
$secretRead2Exit = $LASTEXITCODE
if ($secretRead2Exit -eq 0) {
    $clientSecretValue = Normalize-SecretValue (($secretRead2 -join "`n"))
    if ([string]::IsNullOrWhiteSpace($clientSecretValue)) {
        $secretReadFailed2 = $true
    }
} else {
    $secretReadFailed2 = $true
}
if ($secretReadFailed2) {
    $detail2 = (($secretRead2 -join "`n")).Trim()
    if ($detail2) {
        if ($secretReadError) {
            $secretReadError = $secretReadError + "`n" + $detail2
        } else {
            $secretReadError = $detail2
        }
    }
}

if ($secretReadFailed -or $secretReadFailed2) {
    if (-not [string]::IsNullOrWhiteSpace($jsonClientId) -and -not [string]::IsNullOrWhiteSpace($jsonClientSecret)) {
        Write-Host "⚠️  Could not read OAuth client secrets back from Secret Manager; using values from -ClientJsonPath for this run." -ForegroundColor Yellow
        if ($secretReadError) {
            Write-Host $secretReadError -ForegroundColor DarkYellow
        }
        $clientIdValue = $jsonClientId
        $clientSecretValue = $jsonClientSecret
    } else {
        $hint = "Ensure the secret exists and has at least one version."
        if ($secretReadError) {
            $hint = $hint + "`n" + $secretReadError
        }
        Fail "Failed to read secret '$ClientIdSecret' or '$ClientSecretSecret' value." $hint
    }
}

if ([string]::IsNullOrWhiteSpace($clientIdValue) -or [string]::IsNullOrWhiteSpace($clientSecretValue)) {
    Fail "OAuth client_id/client_secret are empty after resolving values."
}
& $gcloudExe secrets describe $RefreshTokenSecret --project $ProjectId --format="value(name)" 2>$null | Out-Null
if ($LASTEXITCODE -ne 0) {
    Fail "Secret '$RefreshTokenSecret' does not exist." "Create it first: gcloud secrets create $RefreshTokenSecret --replication-policy=automatic --project $ProjectId"
}
Write-Host "✅ OAuth secrets resolved from Secret Manager" -ForegroundColor Green

# Build JSON for scopes passed to Python as environment variable
$scopeList = $Scopes -join "|"

$env:CLIENT_ID_VALUE = $clientIdValue
$env:CLIENT_SECRET_VALUE = $clientSecretValue
$env:SCOPE_LIST = $scopeList
$env:NO_BROWSER = $(if ($NoBrowser) { "1" } else { "0" })
$env:PYTHONUNBUFFERED = "1"

$pythonScript = @'
import os
import sys

from google_auth_oauthlib.flow import InstalledAppFlow

CLIENT_ID = os.environ["CLIENT_ID_VALUE"]
CLIENT_SECRET = os.environ["CLIENT_SECRET_VALUE"]
SCOPES = [scope for scope in os.environ.get("SCOPE_LIST", "").split("|") if scope]
NO_BROWSER = os.environ.get("NO_BROWSER", "0") == "1"
TOKEN_OUT = os.environ["REFRESH_TOKEN_OUT"]

if not SCOPES:
    SCOPES = ["https://www.googleapis.com/auth/gmail.modify"]

config = {
    "installed": {
        "client_id": CLIENT_ID,
        "client_secret": CLIENT_SECRET,
        "auth_uri": "https://accounts.google.com/o/oauth2/auth",
        "token_uri": "https://oauth2.googleapis.com/token",
        "redirect_uris": ["http://localhost"]
    }
}

flow = InstalledAppFlow.from_client_config(config, scopes=SCOPES)
print("Starting OAuth consent flow...", flush=True)
creds = flow.run_local_server(port=0, prompt="consent", open_browser=(not NO_BROWSER))

refresh_token = creds.refresh_token
if not refresh_token:
    raise RuntimeError("Refresh token was not returned. Ensure offline access is granted.")

with open(TOKEN_OUT, "w", encoding="utf-8") as fh:
    fh.write(refresh_token)

print("Refresh token captured.", flush=True)
'@

$tempScript = Join-Path $env:TEMP ("temp_get_token_{0}.py" -f [System.Guid]::NewGuid().ToString("N"))
$tempTokenFile = Join-Path $env:TEMP ("refresh_token_{0}.txt" -f [System.Guid]::NewGuid().ToString("N"))
$env:REFRESH_TOKEN_OUT = $tempTokenFile
$pythonScript | Out-File -FilePath $tempScript -Encoding UTF8

try {
    if ($NoBrowser) {
        Write-Host "Open the OAuth URL shown below in a browser, complete consent, then return here." -ForegroundColor Yellow
    }
    & "C:\Python311\python.exe" $tempScript
    if ($LASTEXITCODE -ne 0) {
        Fail "Failed to obtain and store refresh token" "If you see 'invalid_client', re-run with -ClientJsonPath <path-to-client_secret_*.json> so client_id/client_secret are re-synced before token generation."
    }
    if (-not (Test-Path $tempTokenFile)) {
        Fail "OAuth flow completed but refresh token file was not produced."
    }
    $refreshToken = Get-Content -Path $tempTokenFile -Raw
    if ($null -ne $refreshToken) {
        $refreshToken = Normalize-SecretValue $refreshToken
    }
    if (-not $refreshToken) {
        Fail "Captured refresh token is empty."
    }
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($tempTokenFile, $refreshToken, $utf8NoBom)
    $saveResult = & $gcloudExe secrets versions add $RefreshTokenSecret --data-file=$tempTokenFile --project $ProjectId 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Host $saveResult -ForegroundColor Yellow
        Fail "Failed to save refresh token to Secret Manager"
    }
} finally {
    Remove-Item $tempScript -ErrorAction SilentlyContinue
    Remove-Item $tempTokenFile -ErrorAction SilentlyContinue
}

Write-Host "✅ Refresh token saved to Secret Manager" -ForegroundColor Green
Write-Host "Use 'gcloud secrets versions access $RefreshTokenSecret --project=$ProjectId' to verify." -ForegroundColor White
