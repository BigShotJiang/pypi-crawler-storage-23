﻿import json
import os
adc_path = os.environ.get('GOOGLE_APPLICATION_CREDENTIALS')
if adc_path and os.path.exists(adc_path):
    print('ADC file exists at:', adc_path)
    with open(adc_path, 'r') as f:
        data = json.load(f)
    print('ADC type:', data.get('type'))
    print('Has client_id:', 'client_id' in data)
    print('Has private_key:', 'private_key' in data)
    print('Has service_account_impersonation_url:', 'service_account_impersonation_url' in data)
else:
    print('ADC file not found or GOOGLE_APPLICATION_CREDENTIALS not set')
    print('GOOGLE_APPLICATION_CREDENTIALS:', adc_path)
