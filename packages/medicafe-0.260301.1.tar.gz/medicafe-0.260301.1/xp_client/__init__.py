"""Legacy XP sync agent for MediLink Gmail orchestrator."""

