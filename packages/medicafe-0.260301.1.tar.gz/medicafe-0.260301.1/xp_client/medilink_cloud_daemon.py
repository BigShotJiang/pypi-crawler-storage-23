from __future__ import print_function

"""Thin XP-friendly sync agent for the MediLink Gmail orchestrator.

This daemon polls the cloud orchestrator for ready items, downloads files to
the local machine, and sends acknowledgments. It supports both regular file
attachments and OTP/secure message flows.

OTP/Secure Messages:
    OTP items are recorded locally and require manual portal completion.
    See OTP_README.md for the complete workflow and usage instructions.
    Use --ack-otp <token> after manually downloading from the secure portal.

Configuration:
    See medilink_cloud_daemon.ini for all available options including:
    - download_dir: Optional separate folder for downloaded files
    - verbose: Enable debug logging for troubleshooting
    - Various TLS and authentication options

Usage:
    python medilink_cloud_daemon.py [--config path/to/config.ini]
    python medilink_cloud_daemon.py --ack-otp <token>
"""

import argparse
import datetime
import io
import json
import os
import sys
import time
import uuid

try:
    import ConfigParser as configparser  # Python 2 fallback
except ImportError:  # pragma: no cover - Python 3
    import configparser

import jwt  # pyjwt<=1.7 for Python 3.4 compatibility
import requests


DEFAULT_CONFIG_PATH = os.path.join(os.path.dirname(__file__), "medilink_cloud_daemon.ini")


def _read_file(path, default):
    if not os.path.exists(path):
        return default
    handle = io.open(path, "r", encoding="utf-8")
    try:
        content = handle.read()
    finally:
        handle.close()
    try:
        return json.loads(content)
    except Exception:
        return default


class MediLinkCloudDaemon(object):
    def __init__(self, config_path):
        self.config = self._load_config(config_path)
        self.base_url = self.config.get("base_url")
        self.machine_id = self.config.get("machine_id")
        self.cache_dir = self.config.get("cache_dir")
        
        # Optional download_dir (defaults to cache_dir for backward compatibility)
        self.download_dir = self.config.get("download_dir") or self.cache_dir
        
        self.otp_dir = self.config.get("otp_watch_dir")
        self.poll_interval = int(self.config.get("poll_interval", 15))
        self.retry_interval = int(self.config.get("retry_interval", 60))
        self.service_account_path = self.config.get("service_account_key")
        self.jwt_audience = self.config.get("audience")
        self.jwt_issuer = self.config.get("issuer")
        self.ca_bundle = self.config.get("ca_bundle")
        self.disable_tls_verify = self.config.get("disable_tls_verify", "false").lower() in ("1", "true", "yes")
        
        # Verbose logging control
        self.verbose = self.config.get("verbose", "false").lower() in ("1", "true", "yes")

        # Validate required configuration
        if not self.base_url:
            raise RuntimeError("base_url must be configured in [daemon] section")
        if not self.machine_id:
            raise RuntimeError("machine_id must be configured in [daemon] section")
        if not self.cache_dir:
            raise RuntimeError("cache_dir must be configured in [daemon] section")

        if not os.path.isdir(self.cache_dir):
            os.makedirs(self.cache_dir)
        
        # Create download_dir if different from cache_dir
        if self.download_dir != self.cache_dir and not os.path.isdir(self.download_dir):
            os.makedirs(self.download_dir)
        
        if self.otp_dir and not os.path.isdir(self.otp_dir):
            try:
                os.makedirs(self.otp_dir)
            except Exception:
                pass

        self.log_path = os.path.join(self.cache_dir, "cloud_daemon.log")
        self.pending_path = os.path.join(self.cache_dir, "pending_ack.json")
        self.pending_otps_path = os.path.join(self.cache_dir, "pending_otps.json")
        self.downloaded_log = os.path.join(self.cache_dir, "downloaded_emails.txt")

        self.pending_acks = _read_file(self.pending_path, [])
        self.pending_otps = _read_file(self.pending_otps_path, {})

        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "MediLinkCloudDaemon/1.0"})
        if self.disable_tls_verify:
            try:
                requests.packages.urllib3.disable_warnings()  # type: ignore[attr-defined]
            except Exception:
                pass

        self._log("Daemon initialised for machine %s" % self.machine_id)

    def _load_config(self, path):
        parser = configparser.ConfigParser()
        if not parser.read(path):
            raise RuntimeError("Unable to read configuration at %s" % path)
        section = "daemon"
        if not parser.has_section(section):
            raise RuntimeError("Config missing [daemon] section")
        options = {}
        for key, value in parser.items(section):
            options[key] = value
        return options

    def _log(self, message, level="INFO"):
        """Log a message with the given level (INFO, DEBUG, ERROR, etc.)."""
        timestamp = datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
        line = "%s [%s] %s" % (timestamp, level, message)
        try:
            with io.open(self.log_path, "a", encoding="utf-8") as handle:
                handle.write(line + "\n")
        except Exception:
            pass
        print(line)
    
    def _log_verbose(self, message):
        """Log a debug message only if verbose mode is enabled."""
        if self.verbose:
            self._log(message, level="DEBUG")

    def _load_service_account(self):
        """Load service account info if using key-based auth (fallback)."""
        if not self.service_account_path or not os.path.exists(self.service_account_path):
            return None  # Allow Workload Identity instead
        with io.open(self.service_account_path, "r", encoding="utf-8") as handle:
            return json.load(handle)

    def _build_jwt(self):
        """Build JWT using Workload Identity Federation or service account key."""
        now = int(time.time())

        # Try Workload Identity Federation first
        try:
            from google.auth import default as get_default_credentials
            from google.auth.transport.requests import Request

            # Get credentials using Application Default Credentials
            credentials, project = get_default_credentials(
                scopes=["https://www.googleapis.com/auth/cloud-platform"]
            )

            # Create a JWT payload
            payload = {
                "iss": self.jwt_issuer or credentials.service_account_email,
                "sub": credentials.service_account_email,
                "aud": self.jwt_audience,
                "iat": now,
                "nbf": now - 30,
                "exp": now + 300,
                "machine_id": self.machine_id,
            }

            # Sign the JWT using the credentials
            import google.auth.jwt as jwt_auth
            token = jwt_auth.encode(credentials, payload)
            if isinstance(token, bytes):
                token = token.decode("ascii")
            return token

        except ImportError:
            # google-auth not available, fall back to service account key
            pass
        except Exception as e:
            print("Workload Identity failed, trying service account key: %s" % e)
            pass

        # Fallback to service account key method
        sa_info = self._load_service_account()
        if not sa_info:
            raise RuntimeError("Neither Workload Identity nor service account key available")

        payload = {
            "iss": self.jwt_issuer or sa_info.get("client_email"),
            "sub": sa_info.get("client_email"),
            "aud": self.jwt_audience,
            "iat": now,
            "nbf": now - 30,
            "exp": now + 300,
            "machine_id": self.machine_id,
        }
        headers = {}
        if sa_info.get("private_key_id"):
            headers["kid"] = sa_info.get("private_key_id")
        token = jwt.encode(payload, sa_info.get("private_key"), algorithm="RS256", headers=headers)
        if isinstance(token, bytes):
            token = token.decode("ascii")
        return token

    def _auth_headers(self):
        token = self._build_jwt()
        return {"Authorization": "Bearer %s" % token}

    def _request(self, method, path, **kwargs):
        url = "%s%s" % (self.base_url.rstrip("/"), path)
        headers = kwargs.pop("headers", {})
        headers.update(self._auth_headers())
        kwargs["headers"] = headers
        if self.disable_tls_verify:
            kwargs["verify"] = False
        elif self.ca_bundle:
            kwargs["verify"] = self.ca_bundle
        resp = self.session.request(method, url, timeout=45, **kwargs)
        if resp.status_code == 401:
            raise RuntimeError("Authentication failed (401)")
        return resp

    def _persist_json(self, path, payload):
        tmp_path = path + ".tmp"
        with io.open(tmp_path, "w", encoding="utf-8") as handle:
            handle.write(json.dumps(payload, indent=2, sort_keys=True))
        try:
            os.replace(tmp_path, path)
        except AttributeError:
            if os.path.exists(path):
                try:
                    os.remove(path)
                except Exception:
                    pass
            os.rename(tmp_path, path)

    def _append_download_log(self, filenames):
        if not filenames:
            return
        with io.open(self.downloaded_log, "a", encoding="utf-8") as handle:
            for name in filenames:
                handle.write(name + "\n")

    def _queue_ack(self, ack_payload):
        self.pending_acks.append(ack_payload)
        self._persist_json(self.pending_path, self.pending_acks)

    def _store_pending_otp(self, otp_token, item_payload):
        self.pending_otps[otp_token] = item_payload
        self._persist_json(self.pending_otps_path, self.pending_otps)
        instructions_path = os.path.join(self.cache_dir, "OTP_%s.txt" % otp_token)
        content = []
        content.append("OTP token: %s" % otp_token)
        content.append("Queue item: %s" % item_payload.get("id"))
        content.append("")
        content.append("1. Launch the secure message portal from the MediLink menu.")
        content.append("2. Complete the OTP challenge.")
        content.append("3. Once the file is saved locally, run: python medilink_cloud_daemon.py --ack-otp %s" % otp_token)
        with io.open(instructions_path, "w", encoding="utf-8") as handle:
            handle.write("\n".join(content))
        self._log("Pending OTP recorded for token %s" % otp_token)

    def drain_pending_acks(self):
        if not self.pending_acks:
            return
        remaining = []
        for ack_payload in list(self.pending_acks):
            try:
                self._send_ack(ack_payload)
            except Exception as exc:
                self._log("Ack retry failed: %s" % exc)
                remaining.append(ack_payload)
        self.pending_acks = remaining
        self._persist_json(self.pending_path, self.pending_acks)

    def _send_ack(self, payload):
        resp = self._request("POST", "/ack", json=payload)
        if resp.status_code not in (200, 201):
            raise RuntimeError("Ack failed (%s): %s" % (resp.status_code, resp.text))
        self._log("Acked item %s" % payload.get("item_id"))

    def fetch_ready(self):
        resp = self._request("GET", "/ready/%s" % self.machine_id)
        if resp.status_code != 200:
            raise RuntimeError("Ready poll failed (%s)" % resp.status_code)
        data = resp.json()
        return data.get("ready", []), data.get("poll_after_seconds", self.poll_interval)

    def _download_file(self, url, filename):
        local_path = os.path.join(self.download_dir, filename)
        if os.path.exists(local_path):
            root, ext = os.path.splitext(filename)
            unique_name = "%s_%s%s" % (root, uuid.uuid4().hex[:6], ext)
            local_path = os.path.join(self.download_dir, unique_name)
        verify_flag = True
        if self.disable_tls_verify:
            verify_flag = False
        elif self.ca_bundle:
            verify_flag = self.ca_bundle
        headers = self._auth_headers()
        resp = self.session.get(url, timeout=120, stream=True, verify=verify_flag, headers=headers)
        if resp.status_code != 200:
            raise RuntimeError("Download failed for %s (%s)" % (filename, resp.status_code))
        with io.open(local_path, "wb") as handle:
            for chunk in resp.iter_content(65536):
                if chunk:
                    handle.write(chunk)
        return local_path

    def handle_file_item(self, item):
        files = item.get("files") or []
        saved = []
        for file_entry in files:
            filename = file_entry.get("filename") or ("attachment_%s" % uuid.uuid4().hex)
            download_path = file_entry.get("download_path")
            url = file_entry.get("download_url") or file_entry.get("url")
            if download_path:
                url = self.base_url.rstrip("/") + download_path
            elif url and url.startswith("/"):
                url = self.base_url.rstrip("/") + url
            if not url:
                raise RuntimeError("File payload missing download URL for %s" % filename)
            local_path = self._download_file(url, filename)
            saved.append((filename, local_path, file_entry.get("checksum")))
            self._log("Saved %s to %s" % (filename, local_path))
        self._append_download_log([entry[0] for entry in saved])
        ack_payload = {
            "item_id": item.get("id"),
            "machine_id": self.machine_id,
            "files": [
                {"filename": entry[0], "checksum": entry[2]} for entry in saved
            ],
        }
        try:
            self._send_ack(ack_payload)
        except Exception as exc:
            self._log("Ack failed, queuing retry: %s" % exc)
            self._queue_ack(ack_payload)

    def handle_otp_item(self, item):
        token = item.get("otp_token")
        if not token:
            self._log("OTP item missing token: %s" % item.get("id"))
            return
        self._store_pending_otp(token, item)

    def sync_once(self):
        self.drain_pending_acks()
        try:
            items, poll_after = self.fetch_ready()
        except Exception as exc:
            self._log("Poll failed: %s" % exc, level="ERROR")
            time.sleep(self.retry_interval)
            return
        if not items:
            self._log_verbose("No items ready, polling again in %s seconds" % (poll_after or self.poll_interval))
            time.sleep(poll_after or self.poll_interval)
            return
        
        self._log("Received %s item(s) from orchestrator" % len(items))
        for item in items:
            if item.get("otp_required"):
                self.handle_otp_item(item)
            else:
                self.handle_file_item(item)

    def run(self):
        self._log("Starting poll loop (interval=%ss)" % self.poll_interval)
        while True:
            self.sync_once()

    def ack_otp(self, token):
        token = token.strip()
        if token not in self.pending_otps:
            raise RuntimeError("Token %s not found in pending OTP list" % token)
        item = self.pending_otps[token]
        ack_payload = {
            "item_id": item.get("id"),
            "machine_id": self.machine_id,
            "otp_token": token,
            "files": [],
        }
        self._send_ack(ack_payload)
        del self.pending_otps[token]
        self._persist_json(self.pending_otps_path, self.pending_otps)
        instructions_path = os.path.join(self.cache_dir, "OTP_%s.txt" % token)
        if os.path.exists(instructions_path):
            try:
                os.remove(instructions_path)
            except Exception:
                pass
        self._log("OTP token %s acknowledged" % token)


def parse_args(argv):
    parser = argparse.ArgumentParser(description="MediLink Cloud daemon")
    parser.add_argument("--config", dest="config", default=DEFAULT_CONFIG_PATH, help="Path to daemon ini file")
    parser.add_argument("--ack-otp", dest="ack_otp", help="Ack a pending OTP token and exit")
    return parser.parse_args(argv)


def main(argv=None):
    args = parse_args(argv or sys.argv[1:])
    daemon = MediLinkCloudDaemon(args.config)
    if args.ack_otp:
        daemon.ack_otp(args.ack_otp)
        return 0
    daemon.run()
    return 0


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())

