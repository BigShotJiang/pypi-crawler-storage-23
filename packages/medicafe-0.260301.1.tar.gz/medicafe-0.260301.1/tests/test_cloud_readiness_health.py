import os
import json
import sqlite3
import tempfile
import unittest

from MediCafe.cloud_readiness_health import build_cloud_health_lines


class TestCloudReadinessHealthPhaseF(unittest.TestCase):
    def test_phase_f_detail_includes_lock_diag_suffix(self):
        lab_root = tempfile.mkdtemp()
        try:
            state_path = os.path.join(lab_root, "diagnostics_state.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "pipeline_state": "failed",
                        "last_shadow_pipeline_run_id": "run-1",
                        "last_shadow_pipeline_failed_phase": "F",
                        "last_shadow_pipeline_error_code": "PHASE_F_LOCK_FAIL",
                        "last_phase_f_lock_diag_path": os.path.join(lab_root, "reports", "phase_f_lock_diag_run-1_20260101T000000Z.json"),
                    },
                    f,
                    indent=2,
                )
            lines = build_cloud_health_lines(lab_root, auto_pipeline=True, auto_health=True)
            joined = "\n".join(lines)
            self.assertIn("err=PHASE_F_LOCK_FAIL", joined)
            self.assertIn("lock_diag=phase_f_lock_diag_run-1_20260101T000000Z.json", joined)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_phase_rows_use_v2_phase_run_id_map(self):
        lab_root = tempfile.mkdtemp()
        try:
            state_path = os.path.join(lab_root, "diagnostics_state.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_shadow_pipeline_phase_run_ids": {
                            "B": "rid-b",
                            "C": "rid-c",
                            "D": "rid-d",
                            "E": "rid-e",
                        },
                        "last_shadow_pipeline_ok": False,
                        "last_shadow_pipeline_failed_phase": "E",
                        "last_shadow_pipeline_error_code": "PHASE_E_DB_WRITE_ERROR",
                    },
                    f,
                    indent=2,
                )
            lines = build_cloud_health_lines(lab_root, auto_pipeline=True, auto_health=True)
            joined = "\n".join(lines)
            self.assertIn("B:?", joined)
            self.assertIn("run_id=rid-b", joined)
            self.assertIn("C:?", joined)
            self.assertIn("run_id=rid-c", joined)
            self.assertIn("D:?", joined)
            self.assertIn("run_id=rid-d", joined)
            self.assertIn("E:?", joined)
            self.assertIn("run_id=rid-e", joined)
            self.assertNotIn("state=not_run", joined)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_pending_phase_rows_render_as_running_during_active_pipeline(self):
        lab_root = tempfile.mkdtemp()
        try:
            state_path = os.path.join(lab_root, "diagnostics_state.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "pipeline_state": "running",
                        "active_phase": "C",
                        "active_run_id": "rid-active",
                        "last_shadow_pipeline_run_id": "rid-active",
                        "last_shadow_pipeline_phase_run_ids": {"B": "rid-b"},
                    },
                    f,
                    indent=2,
                )
            lines = build_cloud_health_lines(lab_root, auto_pipeline=True, auto_health=True)
            joined = "\n".join(lines)
            self.assertIn("state=awaiting_phase_write", joined)
            self.assertNotIn("PHASE_D_NOT_RUN", joined)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_health_snapshot_includes_data_plane_counts(self):
        lab_root = tempfile.mkdtemp()
        try:
            state_path = os.path.join(lab_root, "diagnostics_state.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_discovery_ok": True,
                        "last_phase_c_ok": True,
                        "last_phase_d_ok": True,
                        "last_phase_e_ok": True,
                        "last_shadow_pipeline_ok": True,
                        "last_contract_parity_status": "pass",
                        "last_baseline_parity_status": "pass",
                        "last_discovery_counts_by_class": {"csv": 2},
                    },
                    f,
                    indent=2,
                )

            db_path = os.path.join(lab_root, "unified_model_xp.db")
            conn = sqlite3.connect(db_path)
            conn.execute("CREATE TABLE patient (patient_id INTEGER PRIMARY KEY)")
            conn.execute("CREATE TABLE coverage (coverage_id INTEGER PRIMARY KEY)")
            conn.execute("CREATE TABLE encounter (encounter_id INTEGER PRIMARY KEY)")
            conn.execute("CREATE TABLE claim (claim_id INTEGER PRIMARY KEY, encounter_id INTEGER)")
            conn.execute("CREATE TABLE claim_line (claim_line_id INTEGER PRIMARY KEY, claim_id INTEGER)")
            conn.execute("CREATE TABLE ingest_artifact (artifact_id INTEGER PRIMARY KEY)")
            conn.execute("CREATE TABLE qa_result (qa_result_id INTEGER PRIMARY KEY, status TEXT)")
            conn.execute("CREATE TABLE replay_queue (replay_id INTEGER PRIMARY KEY, status TEXT)")
            conn.execute("CREATE TABLE extracted_canonical_record (canonical_record_id INTEGER PRIMARY KEY)")
            conn.execute(
                "CREATE TABLE projection_result (projection_id INTEGER PRIMARY KEY, projection_type TEXT, projection_status TEXT)"
            )
            conn.execute("INSERT INTO patient (patient_id) VALUES (1)")
            conn.execute("INSERT INTO qa_result (qa_result_id, status) VALUES (1, 'reject')")
            conn.execute("INSERT INTO replay_queue (replay_id, status) VALUES (1, 'pending')")
            conn.execute("INSERT INTO projection_result (projection_id, projection_type, projection_status) VALUES (1, 'patient_v1', 'success')")
            conn.commit()
            conn.close()

            lines = build_cloud_health_lines(lab_root, auto_pipeline=True, auto_health=True)
            joined = "\n".join(lines)
            self.assertIn("Data Plane: status=", joined)
            self.assertIn("patient=1", joined)
            self.assertIn("replay_rows=1", joined)
            self.assertIn("qa_reject=1", joined)
            self.assertIn("replay_pending=1", joined)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_health_snapshot_prefers_version_scoped_quality_counts(self):
        lab_root = tempfile.mkdtemp()
        try:
            state_path = os.path.join(lab_root, "diagnostics_state.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_qa_policy_version": "qa_v2",
                        "last_projection_version": "proj_v2",
                    },
                    f,
                    indent=2,
                )

            db_path = os.path.join(lab_root, "unified_model_xp.db")
            conn = sqlite3.connect(db_path)
            conn.execute(
                "CREATE TABLE patient ("
                "patient_id INTEGER PRIMARY KEY, "
                "patient_key TEXT, "
                "external_patient_id TEXT)"
            )
            conn.execute("CREATE TABLE coverage (coverage_id INTEGER PRIMARY KEY)")
            conn.execute("CREATE TABLE encounter (encounter_id INTEGER PRIMARY KEY)")
            conn.execute("CREATE TABLE claim (claim_id INTEGER PRIMARY KEY, encounter_id INTEGER)")
            conn.execute("CREATE TABLE claim_line (claim_line_id INTEGER PRIMARY KEY, claim_id INTEGER)")
            conn.execute("CREATE TABLE ingest_artifact (artifact_id INTEGER PRIMARY KEY)")
            conn.execute(
                "CREATE TABLE qa_result ("
                "qa_result_id INTEGER PRIMARY KEY, "
                "status TEXT, "
                "qa_version TEXT)"
            )
            conn.execute("CREATE TABLE replay_queue (replay_id INTEGER PRIMARY KEY, status TEXT)")
            conn.execute("CREATE TABLE extracted_canonical_record (canonical_record_id INTEGER PRIMARY KEY)")
            conn.execute(
                "CREATE TABLE projection_result ("
                "projection_id INTEGER PRIMARY KEY, "
                "projection_type TEXT, "
                "projection_status TEXT, "
                "projection_version TEXT)"
            )
            conn.execute("INSERT INTO patient (patient_id, patient_key, external_patient_id) VALUES (1, 'p1', '11111')")
            conn.execute("INSERT INTO qa_result (qa_result_id, status, qa_version) VALUES (1, 'reject', 'qa_v1')")
            conn.execute("INSERT INTO qa_result (qa_result_id, status, qa_version) VALUES (2, 'reject', 'qa_v2')")
            conn.execute(
                "INSERT INTO projection_result "
                "(projection_id, projection_type, projection_status, projection_version) "
                "VALUES (1, 'patient_v1', 'success', 'proj_v1')"
            )
            conn.execute(
                "INSERT INTO projection_result "
                "(projection_id, projection_type, projection_status, projection_version) "
                "VALUES (2, 'patient_v1', 'rejected', 'proj_v2')"
            )
            conn.commit()
            conn.close()

            lines = build_cloud_health_lines(lab_root, auto_pipeline=True, auto_health=True)
            joined = "\n".join(lines)
            self.assertIn("Quality: qa_reject=1, replay_pending=0, proj_success=0, proj_reject=1", joined)
            self.assertIn("Quality Scope: qa_version=qa_v2, projection_version=proj_v2", joined)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)


if __name__ == "__main__":
    unittest.main()
