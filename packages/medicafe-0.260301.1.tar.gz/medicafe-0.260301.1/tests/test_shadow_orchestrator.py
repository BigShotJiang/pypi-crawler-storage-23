import os
import subprocess
import tempfile
import unittest
from unittest.mock import patch

from MediCafe import shadow_orchestrator as so


def _env_flag(name, default):
    raw = os.environ.get(name)
    if raw is None:
        return default
    return str(raw).strip().lower() in ("1", "true", "yes", "on", "y")


def _ops_for_repo(repo_root):
    from MediCafe import cloud_readiness as cr
    return {
        "resolve_lab_root": cr.resolve_lab_root,
        "lab_has_core_artifacts": cr._lab_has_core_artifacts,
        "write_bootstrap_diag": cr._write_bootstrap_diag,
        "bootstrap_fail_message": cr._bootstrap_fail_message,
        "devnull": subprocess.DEVNULL,
    }


class TestPolicySelector(unittest.TestCase):
    def test_health_action_maps_attach_only(self):
        intent = so.PolicySelector.select_intent(
            so.ACTION_HEALTH_VIEW, so.ENTRYPOINT_HEALTH_VIEW, {}, {}, {}
        )
        self.assertEqual(intent, so.INTENT_ATTACH_ONLY)

    def test_startup_auto_maps_start_or_attach(self):
        env = {"MEDICAFE_SHADOW_AUTO_PIPELINE": "1"}
        intent = so.PolicySelector.select_intent(
            so.ACTION_STARTUP, so.ENTRYPOINT_STARTUP, env, {}, {}
        )
        self.assertEqual(intent, so.INTENT_START_OR_ATTACH_PIPELINE)

    def test_menu_default_maps_ensure_baseline(self):
        intent = so.PolicySelector.select_intent(
            so.ACTION_ENSURE_PHASE_A_ONLY, so.ENTRYPOINT_MENU, {}, {}, {}
        )
        self.assertEqual(intent, so.INTENT_ENSURE_BASELINE)


class TestStartOrAttachBehavior(unittest.TestCase):
    def test_ensure_baseline_ready_noop_when_lab_healthy(self):
        repo = tempfile.mkdtemp()
        try:
            lab = os.path.join(repo, "lab")
            os.makedirs(lab, exist_ok=True)
            with open(os.path.join(lab, "unified_model_xp.db"), "wb") as f:
                f.write(b"")
            with open(os.path.join(lab, "run_cursor.json"), "w", encoding="utf-8") as f:
                f.write("{}")
            result = so.start_or_attach_shadow_pipeline(
                action_id=so.ACTION_ENSURE_PHASE_A_ONLY,
                entrypoint=so.ENTRYPOINT_MENU,
                repo_root=repo,
                python_exe="/py",
                env={},
                env_flag_fn=_env_flag,
                ops=_ops_for_repo(repo),
            )
            self.assertEqual(result["status"], so.STATUS_READY_NOOP)
            self.assertEqual(result["error_code"], so.ERROR_READY_NOOP)
        finally:
            import shutil
            shutil.rmtree(repo, ignore_errors=True)

    def test_disabled_phase_a_policy_returns_typed_failure(self):
        repo = tempfile.mkdtemp()
        try:
            lab = os.path.join(repo, "lab")
            os.makedirs(lab, exist_ok=True)

            def _disabled(name, default):
                if name == "MEDICAFE_PHASE_A_AUTO_VALIDATE":
                    return False
                return default

            result = so.start_or_attach_shadow_pipeline(
                action_id=so.ACTION_ENSURE_PHASE_A_ONLY,
                entrypoint=so.ENTRYPOINT_MENU,
                repo_root=repo,
                python_exe="/py",
                env={},
                env_flag_fn=_disabled,
                ops=_ops_for_repo(repo),
            )
            self.assertEqual(result["status"], so.STATUS_FAILED)
            self.assertEqual(result["error_code"], so.ERROR_POLICY_PHASE_A_DISABLED)
        finally:
            import shutil
            shutil.rmtree(repo, ignore_errors=True)

    def test_keyboard_interrupt_maps_unknown_source_interruption(self):
        repo = tempfile.mkdtemp()
        try:
            lab = os.path.join(repo, "lab")
            os.makedirs(lab, exist_ok=True)
            bootstrap = os.path.join(repo, "scripts", "unified_model")
            os.makedirs(bootstrap, exist_ok=True)
            with open(os.path.join(bootstrap, "bootstrap_lab.py"), "w", encoding="utf-8") as f:
                f.write("# stub\n")
            with patch("MediCafe.shadow_orchestrator.subprocess.call", side_effect=KeyboardInterrupt):
                result = so.start_or_attach_shadow_pipeline(
                    action_id=so.ACTION_ENSURE_PHASE_A_ONLY,
                    entrypoint=so.ENTRYPOINT_MENU,
                    repo_root=repo,
                    python_exe="/py",
                    env={},
                    env_flag_fn=_env_flag,
                    ops=_ops_for_repo(repo),
                )
            self.assertEqual(result["status"], so.STATUS_FAILED)
            self.assertEqual(result["error_code"], so.ERROR_INTERRUPTED_UNKNOWN)
        finally:
            import shutil
            shutil.rmtree(repo, ignore_errors=True)



    def test_pipeline_start_uses_parent_repo_scripts_when_nested_repo_root(self):
        repo = tempfile.mkdtemp()
        try:
            nested_repo = os.path.join(repo, "MediCafe")
            os.makedirs(os.path.join(nested_repo, "lab"), exist_ok=True)
            script_dir = os.path.join(repo, "scripts", "unified_model")
            os.makedirs(script_dir, exist_ok=True)
            pipeline_script = os.path.join(script_dir, "run_shadow_pipeline.py")
            with open(pipeline_script, "w", encoding="utf-8") as f:
                f.write("# stub\n")

            with patch("MediCafe.shadow_orchestrator.subprocess.Popen") as mock_popen:
                result = so.start_or_attach_shadow_pipeline(
                    action_id=so.ACTION_MANUAL_FULL_PIPELINE,
                    entrypoint=so.ENTRYPOINT_MENU,
                    repo_root=nested_repo,
                    python_exe="/py",
                    env={},
                    env_flag_fn=_env_flag,
                    ops=_ops_for_repo(nested_repo),
                )

            self.assertEqual(result["status"], so.STATUS_STARTED_NEW)
            mock_popen.assert_called_once()
            _, kwargs = mock_popen.call_args
            self.assertEqual(kwargs.get("cwd"), repo)

        finally:
            import shutil
            shutil.rmtree(repo, ignore_errors=True)

    def test_baseline_uses_parent_repo_scripts_when_nested_repo_root(self):
        repo = tempfile.mkdtemp()
        try:
            nested_repo = os.path.join(repo, "MediCafe")
            os.makedirs(os.path.join(nested_repo, "lab"), exist_ok=True)
            script_dir = os.path.join(repo, "scripts", "unified_model")
            os.makedirs(script_dir, exist_ok=True)
            bootstrap_script = os.path.join(script_dir, "bootstrap_lab.py")
            with open(bootstrap_script, "w", encoding="utf-8") as f:
                f.write("# stub\n")

            with patch("MediCafe.shadow_orchestrator.subprocess.call", return_value=0) as mock_call:
                result = so.start_or_attach_shadow_pipeline(
                    action_id=so.ACTION_ENSURE_PHASE_A_ONLY,
                    entrypoint=so.ENTRYPOINT_MENU,
                    repo_root=nested_repo,
                    python_exe="/py",
                    env={},
                    env_flag_fn=_env_flag,
                    ops=_ops_for_repo(nested_repo),
                )

            self.assertEqual(result["status"], so.STATUS_STARTED_NEW)
            _, kwargs = mock_call.call_args
            self.assertEqual(kwargs.get("cwd"), repo)

        finally:
            import shutil
            shutil.rmtree(repo, ignore_errors=True)

    def test_pipeline_uses_prefix_root_for_script_resolution(self):
        repo = tempfile.mkdtemp()
        prefix_root = tempfile.mkdtemp()
        try:
            os.makedirs(os.path.join(repo, "lab"), exist_ok=True)
            script_dir = os.path.join(prefix_root, "scripts", "unified_model")
            os.makedirs(script_dir, exist_ok=True)
            pipeline_script = os.path.join(script_dir, "run_shadow_pipeline.py")
            with open(pipeline_script, "w", encoding="utf-8") as f:
                f.write("# stub\n")

            with patch.object(so.sys, "prefix", prefix_root):
                with patch.object(so.sys, "executable", os.path.join(prefix_root, "python.exe")):
                    with patch("MediCafe.shadow_orchestrator.subprocess.Popen") as mock_popen:
                        result = so.start_or_attach_shadow_pipeline(
                            action_id=so.ACTION_MANUAL_FULL_PIPELINE,
                            entrypoint=so.ENTRYPOINT_MENU,
                            repo_root=repo,
                            python_exe="/py",
                            env={},
                            env_flag_fn=_env_flag,
                            ops=_ops_for_repo(repo),
                        )

            self.assertEqual(result["status"], so.STATUS_STARTED_NEW)
            mock_popen.assert_called_once()
            _, kwargs = mock_popen.call_args
            self.assertEqual(kwargs.get("cwd"), prefix_root)

        finally:
            import shutil
            shutil.rmtree(repo, ignore_errors=True)
            shutil.rmtree(prefix_root, ignore_errors=True)


    def test_pipeline_prefers_requested_python_executable_root_for_script_resolution(self):
        repo = tempfile.mkdtemp()
        requested_prefix = tempfile.mkdtemp()
        runtime_prefix = tempfile.mkdtemp()
        try:
            os.makedirs(os.path.join(repo, "lab"), exist_ok=True)
            requested_script_dir = os.path.join(requested_prefix, "scripts", "unified_model")
            runtime_script_dir = os.path.join(runtime_prefix, "scripts", "unified_model")
            os.makedirs(requested_script_dir, exist_ok=True)
            os.makedirs(runtime_script_dir, exist_ok=True)
            with open(os.path.join(requested_script_dir, "run_shadow_pipeline.py"), "w", encoding="utf-8") as f:
                f.write("# requested stub\n")
            with open(os.path.join(runtime_script_dir, "run_shadow_pipeline.py"), "w", encoding="utf-8") as f:
                f.write("# runtime stub\n")

            requested_python = os.path.join(requested_prefix, "bin", "python")
            with patch.object(so.sys, "prefix", runtime_prefix):
                with patch.object(so.sys, "executable", os.path.join(runtime_prefix, "python.exe")):
                    with patch("MediCafe.shadow_orchestrator.subprocess.Popen") as mock_popen:
                        result = so.start_or_attach_shadow_pipeline(
                            action_id=so.ACTION_MANUAL_FULL_PIPELINE,
                            entrypoint=so.ENTRYPOINT_MENU,
                            repo_root=repo,
                            python_exe=requested_python,
                            env={},
                            env_flag_fn=_env_flag,
                            ops=_ops_for_repo(repo),
                        )

            self.assertEqual(result["status"], so.STATUS_STARTED_NEW)
            mock_popen.assert_called_once()
            _, kwargs = mock_popen.call_args
            self.assertEqual(kwargs.get("cwd"), requested_prefix)

        finally:
            import shutil
            shutil.rmtree(repo, ignore_errors=True)
            shutil.rmtree(requested_prefix, ignore_errors=True)
            shutil.rmtree(runtime_prefix, ignore_errors=True)

    def test_pipeline_script_missing_includes_resolution_diagnostics(self):
        repo = tempfile.mkdtemp()
        try:
            os.makedirs(os.path.join(repo, "lab"), exist_ok=True)
            result = so.start_or_attach_shadow_pipeline(
                action_id=so.ACTION_MANUAL_FULL_PIPELINE,
                entrypoint=so.ENTRYPOINT_MENU,
                repo_root=repo,
                python_exe="/py",
                env={},
                env_flag_fn=_env_flag,
                ops=_ops_for_repo(repo),
            )
            self.assertEqual(result["status"], so.STATUS_FAILED)
            self.assertEqual(result["error_code"], "PIPELINE_SCRIPT_MISSING")
            self.assertTrue(result.get("diagnostic_path"))
            self.assertTrue(os.path.exists(result.get("diagnostic_path")))
            self.assertIn("checked:", result.get("message", ""))
            payload = result.get("payload", {})
            self.assertEqual(payload.get("script_name"), "run_shadow_pipeline.py")
            checks = payload.get("script_resolution_checks", [])
            self.assertTrue(isinstance(checks, list))
            self.assertTrue(len(checks) >= 1)
        finally:
            import shutil
            shutil.rmtree(repo, ignore_errors=True)


class TestCloudReadinessCoordinatorWiring(unittest.TestCase):
    def test_ensure_lab_ready_does_not_direct_call_subprocess_call(self):
        from MediCafe import cloud_readiness as cr

        with patch("MediCafe.cloud_readiness.resolve_lab_root", return_value="/repo/lab"):
            with patch("MediCafe.cloud_readiness._probe_lab_root", return_value={"is_dir": True, "has_core_artifacts": False, "pipeline_running": False}):
                with patch("MediCafe.cloud_readiness.shadow_orchestrator.start_or_attach_shadow_pipeline") as mock_start:
                    mock_start.return_value = {
                        "status": so.STATUS_READY_NOOP,
                        "error_code": so.ERROR_READY_NOOP,
                        "message": "",
                    }
                    with patch("MediCafe.cloud_readiness.subprocess.call") as mock_call:
                        ok, msg, _ = cr.ensure_lab_ready("/repo", "/py", {}, _env_flag)
        self.assertTrue(ok)
        self.assertEqual(msg, "")
        self.assertGreaterEqual(mock_start.call_count, 1)
        mock_call.assert_not_called()

    def test_run_pipeline_returns_typed_interrupt_message(self):
        from MediCafe import cloud_readiness as cr

        with patch("MediCafe.cloud_readiness.shadow_orchestrator.start_or_attach_shadow_pipeline") as mock_start:
            mock_start.return_value = {
                "status": so.STATUS_FAILED,
                "error_code": so.ERROR_INTERRUPTED_UNKNOWN,
                "message": "PIPELINE_INTERRUPTED_SOURCE_UNKNOWN: interrupted",
            }
            ok, msg, _ = cr.run_pipeline("/repo", "/py", {}, _env_flag)
        self.assertFalse(ok)
        self.assertIn("PIPELINE_INTERRUPTED_SOURCE_UNKNOWN", msg)

    def test_cloud_readiness_has_no_direct_bootstrap_subprocess_call(self):
        repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
        target = os.path.join(repo_root, "MediCafe", "cloud_readiness.py")
        with open(target, "r", encoding="utf-8") as f:
            text = f.read()
        self.assertNotIn("subprocess.call([python_exe, bootstrap_script]", text)


if __name__ == "__main__":
    unittest.main()
