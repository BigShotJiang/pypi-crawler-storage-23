#!/usr/bin/env python
from __future__ import print_function

import os
import unittest


class TestLabRootResolutionDryness(unittest.TestCase):

    def test_unified_model_entrypoints_use_shared_resolver(self):
        repo_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        targets = [
            'scripts/unified_model/bootstrap_lab.py',
            'scripts/unified_model/discover_artifacts.py',
            'scripts/unified_model/ingest_from_manifest.py',
            'scripts/unified_model/run_qa_canonical.py',
            'scripts/unified_model/run_projection_parity.py',
            'scripts/unified_model/run_shadow_pipeline.py',
            'scripts/unified_model/package_shadow_run_report.py',
            'scripts/unified_model/diagnostics_runner.py',
        ]
        for rel in targets:
            path = os.path.join(repo_root, rel)
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('from lab_path_utils import resolve_lab_root', text, rel)
            self.assertNotIn('os.environ.get("MEDICAFE_LAB_DIR"', text, rel)


if __name__ == '__main__':
    unittest.main()
