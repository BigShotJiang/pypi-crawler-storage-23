import os
import tempfile
import unittest
from unittest.mock import patch

from MediLink import insurance_type_cache


class TestInsuranceTypeCacheSave(unittest.TestCase):
    def test_save_cache_uses_os_replace_when_available(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch('MediLink.insurance_type_cache.os.replace') as mock_replace:
                insurance_type_cache.save_cache(tmpdir, {'version': 2, 'by_patient_id': {}})
                self.assertTrue(mock_replace.called)

    def test_save_cache_falls_back_without_replace(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            target = insurance_type_cache.get_cache_path(tmpdir)
            with open(target, 'w') as f:
                f.write('{}')

            real_remove = os.remove
            real_rename = os.rename

            with patch('MediLink.insurance_type_cache.os.replace', None), \
                 patch('MediLink.insurance_type_cache.os.remove') as mock_remove, \
                 patch('MediLink.insurance_type_cache.os.rename') as mock_rename:
                def _rename(src, dst):
                    real_rename(src, dst)

                def _remove(path):
                    real_remove(path)

                mock_rename.side_effect = _rename
                mock_remove.side_effect = _remove

                insurance_type_cache.save_cache(tmpdir, {'version': 2, 'by_patient_id': {}})

                self.assertTrue(mock_remove.called)
                self.assertTrue(mock_rename.called)


if __name__ == '__main__':
    unittest.main()
