#!/usr/bin/env python
"""
Phase E projection and parity: unit tests.
Tests determinism, idempotency, no-op, lock-fail, projection logic.
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import json
import os
import sqlite3
import sys
import tempfile
import unittest

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.abspath(os.path.join(_SCRIPT_DIR, "..", ".."))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from phase_e_common import (
    PHASE_E_LOCK_FAIL,
    PHASE_E_STATE_WRITE_ERROR,
    PROJECTION_TYPE,
    PROJECTION_VERSION,
    QA_POLICY_VERSION,
    serialize_projection_json,
)

try:
    from unittest.mock import patch, MagicMock
except ImportError:
    from mock import patch, MagicMock

SQL_PATH = os.path.join(_ROOT, "sql", "unified_relational_model_v1.sql")


def _make_lab_with_db():
    """Create temp lab dir with unified_model_xp.db and schema."""
    lab_root = tempfile.mkdtemp()
    db_path = os.path.join(lab_root, "unified_model_xp.db")
    reports_dir = os.path.join(lab_root, "reports")
    os.makedirs(reports_dir, exist_ok=True)
    if os.path.exists(SQL_PATH):
        with open(SQL_PATH, "r", encoding="utf-8") as f:
            conn = sqlite3.connect(db_path)
            conn.executescript(f.read())
            conn.close()
    return lab_root, db_path, reports_dir


class TestProjectionSerialization(unittest.TestCase):
    """Deterministic projection JSON serialization."""

    def test_serialize_determinism(self):
        obj = {"b": 2, "a": 1, "c": 3}
        s1 = serialize_projection_json(obj)
        s2 = serialize_projection_json(obj)
        self.assertEqual(s1, s2)
        parsed = json.loads(s1)
        self.assertEqual(parsed["a"], 1)
        self.assertEqual(parsed["b"], 2)
        self.assertEqual(parsed["c"], 3)

    def test_sort_keys(self):
        obj = {"z": 1, "a": 2}
        s = serialize_projection_json(obj)
        self.assertTrue(s.index('"a"') < s.index('"z"'))


class TestRunProjectionParity(unittest.TestCase):
    """run_projection_parity: no-op, lock-fail, DB-fail."""

    def test_no_eligible_rows_ok(self):
        from run_projection_parity import run_projection_parity
        lab_root, db_path, reports_dir = _make_lab_with_db()
        try:
            with patch("run_projection_parity.acquire_lock"):
                with patch("run_projection_parity.release_lock"):
                    ok, rid, summary, err = run_projection_parity(lab_root)
            self.assertTrue(ok)
            self.assertEqual(summary.get("eligible_count"), 0)
            self.assertIsNone(err)
        finally:
            try:
                if os.path.exists(db_path):
                    os.remove(db_path)
                if os.path.exists(reports_dir):
                    for f in os.listdir(reports_dir):
                        os.remove(os.path.join(reports_dir, f))
                    os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_lock_fail_returns_error(self):
        from run_projection_parity import run_projection_parity
        lab_root, db_path, reports_dir = _make_lab_with_db()
        try:
            with patch("run_projection_parity.acquire_lock", side_effect=SystemExit(1)):
                ok, rid, summary, err = run_projection_parity(lab_root)
            self.assertFalse(ok)
            self.assertEqual(err, PHASE_E_LOCK_FAIL)
        finally:
            try:
                if os.path.exists(db_path):
                    os.remove(db_path)
                if os.path.exists(reports_dir):
                    for f in os.listdir(reports_dir):
                        os.remove(os.path.join(reports_dir, f))
                    os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestRunProjectionParityIntegration(unittest.TestCase):
    """End-to-end: canonical -> projection_result; determinism; idempotency."""

    def test_integration_projects_canonical(self):
        from run_projection_parity import run_projection_parity
        lab_root, db_path, reports_dir = _make_lab_with_db()
        try:
            conn = sqlite3.connect(db_path)
            conn.execute(
                "INSERT INTO ingest_artifact (ingest_key, source_system, source_type, source_ref, message_id, "
                "attachment_name, attachment_sha256, payload_json, ingest_status) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                ("ingest_k1", "xp_local", "file_csv", "src|path", None, "", "",
                 json.dumps({"artifact_class": "csv", "locator": "x.csv"}), "ingested"),
            )
            conn.execute(
                "INSERT INTO qa_result (artifact_id, qa_stage, qa_version, status, reject_code, reject_reason, deterministic_key) "
                "VALUES (1, 'phase_d', ?, 'pass', NULL, NULL, 'dk1')",
                (QA_POLICY_VERSION,),
            )
            conn.execute(
                "INSERT INTO extracted_canonical_record (artifact_id, canonical_type, canonical_key, extractor_version, canonical_json, provenance_json) "
                "VALUES (1, 'patient_csv_row', 'pk1', 'canon_v1', "
                "'{\"Patient ID\":\"12345\",\"Birth Date\":\"1990-01-01\"}', '{\"artifact_id\":1}')",
            )
            conn.commit()
            conn.close()
            with patch("run_projection_parity.acquire_lock"):
                with patch("run_projection_parity.release_lock"):
                    ok, rid, summary, err = run_projection_parity(lab_root)
            self.assertTrue(ok)
            self.assertEqual(summary.get("eligible_count"), 1)
            self.assertEqual(summary.get("projected_success_this_run"), 1)
            self.assertEqual(summary.get("projected_reject_this_run"), 0)
            conn = sqlite3.connect(db_path)
            proj_count = conn.execute(
                "SELECT COUNT(*) FROM projection_result WHERE projection_type=? AND projection_version=?",
                (PROJECTION_TYPE, PROJECTION_VERSION),
            ).fetchone()[0]
            self.assertEqual(proj_count, 1)
            conn.close()
        finally:
            try:
                if os.path.exists(db_path):
                    os.remove(db_path)
                if os.path.exists(reports_dir):
                    for f in os.listdir(reports_dir):
                        os.remove(os.path.join(reports_dir, f))
                    os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_idempotency_rerun_no_new_rows(self):
        from run_projection_parity import run_projection_parity
        lab_root, db_path, reports_dir = _make_lab_with_db()
        try:
            conn = sqlite3.connect(db_path)
            conn.execute(
                "INSERT INTO ingest_artifact (ingest_key, source_system, source_type, source_ref, message_id, "
                "attachment_name, attachment_sha256, payload_json, ingest_status) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                ("ingest_k1", "xp_local", "file_csv", "src|path", None, "", "",
                 json.dumps({"artifact_class": "csv"}), "ingested"),
            )
            conn.execute(
                "INSERT INTO qa_result (artifact_id, qa_stage, qa_version, status, reject_code, reject_reason, deterministic_key) "
                "VALUES (1, 'phase_d', ?, 'pass', NULL, NULL, 'dk1')",
                (QA_POLICY_VERSION,),
            )
            conn.execute(
                "INSERT INTO extracted_canonical_record (artifact_id, canonical_type, canonical_key, extractor_version, canonical_json, provenance_json) "
                "VALUES (1, 'patient_csv_row', 'pk1', 'canon_v1', '{\"Patient ID\":\"12345\"}', '{}')",
            )
            conn.commit()
            conn.close()
            with patch("run_projection_parity.acquire_lock"):
                with patch("run_projection_parity.release_lock"):
                    ok1, _, _, _ = run_projection_parity(lab_root)
                    ok2, _, summary2, _ = run_projection_parity(lab_root)
            self.assertTrue(ok1)
            self.assertTrue(ok2)
            self.assertEqual(summary2.get("eligible_count"), 0)
            self.assertEqual(summary2.get("projected_success_this_run"), 0)
        finally:
            try:
                if os.path.exists(db_path):
                    os.remove(db_path)
                if os.path.exists(reports_dir):
                    for f in os.listdir(reports_dir):
                        os.remove(os.path.join(reports_dir, f))
                    os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestRunShadowPipelineLock(unittest.TestCase):
    """Pipeline lock: stale heartbeat + running PID => lock not stolen."""

    def test_stale_heartbeat_running_pid_lock_not_stolen(self):
        from run_shadow_pipeline import _acquire_pipeline_lock, _release_pipeline_lock
        import time
        lab_root = tempfile.mkdtemp()
        lock_path = os.path.join(lab_root, "shadow_pipeline.lock")
        try:
            # Create lock with stale heartbeat (over 3600s ago) and current PID (running)
            old_ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() - 4000))
            with open(lock_path, "w") as f:
                f.write("pid={0}\nacquired_at_utc={1}\nheartbeat_at_utc={1}\n".format(os.getpid(), old_ts))
            acquired = _acquire_pipeline_lock(lab_root)
            self.assertFalse(acquired, "Lock must not be stolen when PID is running even with stale heartbeat")
        finally:
            _release_pipeline_lock(lab_root)
            try:
                if os.path.exists(lock_path):
                    os.remove(lock_path)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestNoOpStateWriteFailure(unittest.TestCase):
    """No-op branch: persist_phase_e_state exception => PHASE_E_STATE_WRITE_ERROR."""

    def test_noop_persist_failure_returns_state_write_error(self):
        from run_projection_parity import run_projection_parity
        lab_root, db_path, reports_dir = _make_lab_with_db()
        try:
            with patch("run_projection_parity.acquire_lock"):
                with patch("run_projection_parity.release_lock"):
                    with patch("run_projection_parity.persist_phase_e_state", side_effect=RuntimeError("disk full")):
                        ok, rid, summary, err = run_projection_parity(lab_root)
            self.assertFalse(ok)
            self.assertEqual(err, PHASE_E_STATE_WRITE_ERROR)
            self.assertEqual(summary.get("error_code"), PHASE_E_STATE_WRITE_ERROR)
            self.assertIn("disk full", summary.get("error_detail", ""))
        finally:
            try:
                if os.path.exists(db_path):
                    os.remove(db_path)
                if os.path.exists(reports_dir):
                    for f in os.listdir(reports_dir):
                        os.remove(os.path.join(reports_dir, f))
                    os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestProjectionCsvMapping(unittest.TestCase):
    """CSV mapping uses shared patient mapper aliases and full-name fallback."""

    def test_patient_csv_row_uses_patient_dob_and_first_last(self):
        from run_projection_parity import _project_canonical_to_patient
        status, projected_json = _project_canonical_to_patient(
            1,
            "patient_csv_row",
            "pk_test",
            json.dumps({
                "Patient ID": "12345",
                "Patient First": "Jane",
                "Patient Last": "Doe",
                "Patient DOB": "1980-01-02",
            }),
            "{}",
        )
        self.assertEqual(status, "success")
        projected = json.loads(projected_json)
        self.assertEqual(projected.get("external_patient_id"), "12345")
        self.assertEqual(projected.get("full_name"), "Jane Doe")
        self.assertEqual(projected.get("birth_date"), "1980-01-02")


if __name__ == "__main__":
    unittest.main()
