#!/usr/bin/env python
"""
Phase E projection and parity orchestrator.
Deterministic projection from extracted_canonical_record to projection_result.
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import argparse
import json
import os
import sqlite3
import sys
import time

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from lab_path_utils import resolve_lab_root
from phase_e_common import (
    BASELINE_PARITY_REASON_V1,
    BASELINE_PARITY_STATUS_SKIPPED,
    CANONICAL_TYPES_ALLOWLIST,
    CANONICAL_TYPES_DEFERRED,
    PHASE_E_DB_WRITE_ERROR,
    PHASE_E_LOCK_FAIL,
    PHASE_E_STATE_WRITE_ERROR,
    PROJECTION_TYPE,
    PROJECTION_VERSION,
    QA_POLICY_VERSION,
    QA_STAGE_PHASE_D,
    iso_utc_now,
    run_id,
    serialize_projection_json,
)
from patient_field_mapper import (
    extract_birth_date,
    extract_external_patient_id,
    extract_full_name,
)
from lab_lock import (
    HEARTBEAT_INTERVAL_SEC,
    acquire_lock,
    release_lock,
    refresh_heartbeat,
    replace_safe_write,
)


def _workspace_root():
    return os.path.abspath(os.path.join(_SCRIPT_DIR, "..", ".."))


def _resolve_lab_root(args):
    return resolve_lab_root(args.lab_dir, _workspace_root())


def _select_eligible_canonical(conn):
    """Select canonical records not yet projected for (PROJECTION_TYPE, PROJECTION_VERSION)."""
    allowlist = list(CANONICAL_TYPES_ALLOWLIST)
    placeholders = ",".join(["?"] * len(allowlist))
    cur = conn.execute(
        "SELECT ecr.canonical_record_id, ecr.artifact_id, ecr.canonical_type, ecr.canonical_key, "
        "ecr.canonical_json, ecr.provenance_json, ecr.extractor_version "
        "FROM extracted_canonical_record ecr "
        "WHERE ecr.canonical_type IN ({0}) "
        "AND NOT EXISTS ("
        "  SELECT 1 FROM projection_result pr "
        "  WHERE pr.canonical_record_id = ecr.canonical_record_id "
        "  AND pr.projection_type = ? AND pr.projection_version = ?"
        ") "
        "ORDER BY ecr.canonical_record_id".format(placeholders),
        allowlist + [PROJECTION_TYPE, PROJECTION_VERSION],
    )
    return cur.fetchall()


def _project_canonical_to_patient(canonical_record_id, canonical_type, canonical_key, canonical_json,
                                  provenance_json=None):
    """
    Transform canonical record to patient projection.
    Returns (status, projected_json_str). status is 'success' or 'rejected'.
    Reject reason goes inside projected_json.
    """
    try:
        data = json.loads(canonical_json) if canonical_json else {}
    except (ValueError, TypeError):
        return ("rejected", serialize_projection_json({
            "reject_reason": "invalid_canonical_json",
            "canonical_record_id": canonical_record_id,
        }))

    source_system = "xp_local"
    proj = {"patient_key": canonical_key, "source_system": source_system}

    if canonical_type == "patient_csv_row":
        proj["external_patient_id"] = extract_external_patient_id(data)
        proj["full_name"] = extract_full_name(data)
        proj["birth_date"] = extract_birth_date(data)
    elif canonical_type == "x12_member":
        proj["external_patient_id"] = data.get("member_id") or ""
        first = data.get("member_first_name") or ""
        last = data.get("member_last_name") or ""
        proj["full_name"] = (first + " " + last).strip() or ""
        proj["birth_date"] = data.get("member_dob") or ""
    elif canonical_type == "dat_record":
        proj["external_patient_id"] = data.get("PATID") or data.get("patient_id") or ""
        proj["full_name"] = data.get("PATNAME") or data.get("patient_name") or ""
        proj["birth_date"] = ""
    elif canonical_type == "docx_schedule":
        prov = {}
        try:
            prov = json.loads(provenance_json) if provenance_json else {}
        except (ValueError, TypeError):
            pass
        proj["external_patient_id"] = str(prov.get("patient_id", ""))
        proj["full_name"] = ""
        proj["birth_date"] = ""
    else:
        return ("rejected", serialize_projection_json({
            "reject_reason": "unknown_canonical_type",
            "canonical_type": canonical_type,
            "canonical_record_id": canonical_record_id,
        }))

    return ("success", serialize_projection_json(proj))


def _get_cumulative_counts(conn):
    """Read cumulative denominator metrics under lock."""
    counts = {}
    cur = conn.execute("SELECT COUNT(*) FROM ingest_artifact")
    counts["ingest_total"] = cur.fetchone()[0]
    cur = conn.execute(
        "SELECT COUNT(*) FROM qa_result WHERE status='pass' AND qa_stage=? AND qa_version=?",
        (QA_STAGE_PHASE_D, QA_POLICY_VERSION),
    )
    counts["qa_pass_total"] = cur.fetchone()[0]
    cur = conn.execute(
        "SELECT COUNT(*) FROM qa_result WHERE status='reject' AND qa_stage=? AND qa_version=?",
        (QA_STAGE_PHASE_D, QA_POLICY_VERSION),
    )
    counts["qa_reject_total"] = cur.fetchone()[0]
    allowlist = list(CANONICAL_TYPES_ALLOWLIST)
    placeholders = ",".join(["?"] * len(allowlist))
    cur = conn.execute(
        "SELECT COUNT(*) FROM extracted_canonical_record WHERE canonical_type IN ({0})".format(placeholders),
        allowlist,
    )
    counts["canonical_in_scope_total"] = cur.fetchone()[0]
    cur = conn.execute(
        "SELECT COUNT(*) FROM projection_result WHERE projection_type=? AND projection_version=? AND projection_status='success'",
        (PROJECTION_TYPE, PROJECTION_VERSION),
    )
    counts["projected_success_total"] = cur.fetchone()[0]
    cur = conn.execute(
        "SELECT COUNT(*) FROM projection_result WHERE projection_type=? AND projection_version=? AND projection_status='rejected'",
        (PROJECTION_TYPE, PROJECTION_VERSION),
    )
    counts["projected_reject_total"] = cur.fetchone()[0]
    deferred = list(CANONICAL_TYPES_DEFERRED)
    placeholders = ",".join(["?"] * len(deferred))
    cur = conn.execute(
        "SELECT COUNT(*) FROM extracted_canonical_record WHERE canonical_type IN ({0})".format(placeholders),
        deferred,
    )
    counts["deferred_scope_total"] = cur.fetchone()[0]
    return counts


def run_projection_parity(lab_root):
    """Main flow. Returns (ok, run_id, summary, error_code)."""
    rid = run_id()
    reports_dir = os.path.join(lab_root, "reports")
    summary_json_path = os.path.join(reports_dir, "projection_parity_summary_{0}.json".format(rid))
    summary_txt_path = os.path.join(reports_dir, "projection_parity_summary_{0}.txt".format(rid))
    deviation_path = os.path.join(reports_dir, "projection_deviation_samples_{0}.jsonl".format(rid))
    db_path = os.path.join(lab_root, "unified_model_xp.db")

    if not os.path.exists(db_path):
        summary_fail = _build_summary(rid, ok=False, error_code=PHASE_E_DB_WRITE_ERROR)
        _handle_prelock_failure(lab_root, rid, summary_fail, summary_json_path, summary_txt_path, reports_dir)
        return False, rid, summary_fail, PHASE_E_DB_WRITE_ERROR

    try:
        acquire_lock(lab_root)
    except SystemExit:
        return False, rid, None, PHASE_E_LOCK_FAIL

    try:
        conn = sqlite3.connect(db_path)
        eligible = _select_eligible_canonical(conn)
        eligible_count = len(eligible)

        if eligible_count == 0:
            counts = _get_cumulative_counts(conn)
            conn.close()
            summary_ok = _build_summary(
                rid, ok=True, eligible_count=0, projected_success_this_run=0, projected_reject_this_run=0,
                cumulative=counts, contract_parity_status="pass",
            )
            if reports_dir and not os.path.exists(reports_dir):
                os.makedirs(reports_dir, exist_ok=True)
            _write_summary_json(summary_ok, summary_json_path)
            _write_summary_txt(summary_ok, summary_txt_path)
            try:
                persist_phase_e_state(lab_root, rid, True, None, 0, 0, "pass", counts)
            except Exception as persist_err:
                summary_ok["ok"] = False
                summary_ok["error_code"] = PHASE_E_STATE_WRITE_ERROR
                summary_ok["error_detail"] = str(persist_err)[:200]
                _write_summary_json(summary_ok, summary_json_path)
                _write_summary_txt(summary_ok, summary_txt_path)
                release_lock(lab_root, owner_pid=os.getpid())
                try:
                    from phase_e_auto_report import submit_phase_e_failure_report
                    submit_phase_e_failure_report(lab_root, {
                        "error_code": PHASE_E_STATE_WRITE_ERROR, "run_id": rid,
                        "first_failed": str(persist_err)[:100], "lab_root": lab_root,
                        "report_json_path": summary_json_path, "report_txt_path": summary_txt_path,
                        "summary": summary_ok,
                    })
                except Exception:
                    pass
                return False, rid, summary_ok, PHASE_E_STATE_WRITE_ERROR
            release_lock(lab_root, owner_pid=os.getpid())
            return True, rid, summary_ok, None

        projection_rows = []
        deviation_samples = []
        last_heartbeat_at = time.time()
        for idx, row in enumerate(eligible, 1):
            canonical_record_id, artifact_id, canonical_type, canonical_key, canonical_json, provenance_json, extractor_version = row
            status, projected_json = _project_canonical_to_patient(
                canonical_record_id, canonical_type, canonical_key, canonical_json, provenance_json
            )
            projection_rows.append((canonical_record_id, status, projected_json))
            if time.time() - last_heartbeat_at >= HEARTBEAT_INTERVAL_SEC:
                refresh_heartbeat(lab_root, owner_pid=os.getpid())
                last_heartbeat_at = time.time()
            if status == "rejected":
                deviation_samples.append({
                    "canonical_record_id": canonical_record_id,
                    "artifact_id": artifact_id,
                    "canonical_type": canonical_type,
                    "status": status,
                })

        conn.execute("BEGIN")
        try:
            for idx, row in enumerate(projection_rows, 1):
                canonical_record_id, status, projected_json = row
                conn.execute(
                    "INSERT OR REPLACE INTO projection_result "
                    "(canonical_record_id, projection_type, projection_version, projection_status, projected_json) "
                    "VALUES (?, ?, ?, ?, ?)",
                    (canonical_record_id, PROJECTION_TYPE, PROJECTION_VERSION, status, projected_json),
                )
                if time.time() - last_heartbeat_at >= HEARTBEAT_INTERVAL_SEC:
                    refresh_heartbeat(lab_root, owner_pid=os.getpid())
                    last_heartbeat_at = time.time()
            conn.commit()
        except Exception as e:
            conn.rollback()
            conn.close()
            summary_fail = _build_summary(
                rid, ok=False, eligible_count=eligible_count,
                projected_success_this_run=sum(1 for _, s, _ in projection_rows if s == "success"),
                projected_reject_this_run=sum(1 for _, s, _ in projection_rows if s == "rejected"),
                error_code=PHASE_E_DB_WRITE_ERROR,
            )
            summary_fail["error_detail"] = str(e)[:200]
            if reports_dir and not os.path.exists(reports_dir):
                os.makedirs(reports_dir, exist_ok=True)
            _write_summary_json(summary_fail, summary_json_path)
            _write_summary_txt(summary_fail, summary_txt_path)
            try:
                persist_phase_e_state(lab_root, rid, False, PHASE_E_DB_WRITE_ERROR, 0, 0, "fail", {})
            except Exception:
                pass
            release_lock(lab_root, owner_pid=os.getpid())
            try:
                from phase_e_auto_report import submit_phase_e_failure_report
                submit_phase_e_failure_report(lab_root, {
                    "error_code": PHASE_E_DB_WRITE_ERROR, "run_id": rid,
                    "first_failed": str(e)[:100], "lab_root": lab_root,
                    "report_json_path": summary_json_path, "report_txt_path": summary_txt_path,
                    "summary": summary_fail,
                })
            except Exception:
                pass
            return False, rid, summary_fail, PHASE_E_DB_WRITE_ERROR

        projected_success_this_run = sum(1 for _, s, _ in projection_rows if s == "success")
        projected_reject_this_run = sum(1 for _, s, _ in projection_rows if s == "rejected")
        contract_pass = (projected_success_this_run + projected_reject_this_run == eligible_count)
        contract_parity_status = "pass" if contract_pass else "fail"

        conn2 = sqlite3.connect(db_path)
        cumulative = _get_cumulative_counts(conn2)
        conn2.close()
        conn.close()

        summary = _build_summary(
            rid, ok=True, eligible_count=eligible_count,
            projected_success_this_run=projected_success_this_run,
            projected_reject_this_run=projected_reject_this_run,
            cumulative=cumulative, contract_parity_status=contract_parity_status,
        )

        if reports_dir and not os.path.exists(reports_dir):
            os.makedirs(reports_dir, exist_ok=True)
        _write_summary_json(summary, summary_json_path)
        _write_summary_txt(summary, summary_txt_path)
        with open(deviation_path, "w", encoding="utf-8") as f:
            for s in deviation_samples[:50]:
                f.write(json.dumps(s, ensure_ascii=False) + "\n")

        try:
            persist_phase_e_state(
                lab_root, rid, True, None,
                projected_success_this_run + projected_reject_this_run,
                cumulative.get("deferred_scope_total", 0),
                contract_parity_status,
                cumulative,
            )
        except Exception as persist_err:
            summary["ok"] = False
            summary["error_code"] = PHASE_E_STATE_WRITE_ERROR
            summary["error_detail"] = str(persist_err)[:200]
            _write_summary_json(summary, summary_json_path)
            _write_summary_txt(summary, summary_txt_path)
            release_lock(lab_root, owner_pid=os.getpid())
            try:
                from phase_e_auto_report import submit_phase_e_failure_report
                submit_phase_e_failure_report(lab_root, {
                    "error_code": PHASE_E_STATE_WRITE_ERROR, "run_id": rid,
                    "first_failed": str(persist_err)[:100], "lab_root": lab_root,
                    "report_json_path": summary_json_path, "report_txt_path": summary_txt_path,
                    "summary": summary,
                })
            except Exception:
                pass
            return False, rid, summary, PHASE_E_STATE_WRITE_ERROR
    finally:
        release_lock(lab_root, owner_pid=os.getpid())

    return True, rid, summary, None


def _build_summary(rid, ok, eligible_count=0, projected_success_this_run=0, projected_reject_this_run=0,
                   cumulative=None, contract_parity_status="pass", error_code=None):
    cum = cumulative or {}
    parity_status = contract_parity_status
    # Never emit pass parity on explicit failure summaries.
    if not ok and parity_status == "pass":
        parity_status = "fail"
    return {
        "phase": "E",
        "ok": ok,
        "run_id": rid,
        "generated_at_utc": iso_utc_now(),
        "projection_type": PROJECTION_TYPE,
        "projection_version": PROJECTION_VERSION,
        "eligible_count": eligible_count,
        "projected_success_this_run": projected_success_this_run,
        "projected_reject_this_run": projected_reject_this_run,
        "ingest_total": cum.get("ingest_total", 0),
        "qa_pass_total": cum.get("qa_pass_total", 0),
        "qa_reject_total": cum.get("qa_reject_total", 0),
        "canonical_in_scope_total": cum.get("canonical_in_scope_total", 0),
        "projected_success_total": cum.get("projected_success_total", 0),
        "projected_reject_total": cum.get("projected_reject_total", 0),
        "deferred_scope_total": cum.get("deferred_scope_total", 0),
        "contract_parity_status": parity_status,
        "baseline_parity_status": BASELINE_PARITY_STATUS_SKIPPED,
        "baseline_parity_reason": BASELINE_PARITY_REASON_V1,
        "deviation_counts_by_bucket": {"known_issue": 0, "regression_candidate": 0, "data_gap": 0},
        "error_code": error_code,
    }


def _handle_prelock_failure(lab_root, rid, summary_fail, summary_json_path, summary_txt_path, reports_dir):
    try:
        acquire_lock(lab_root)
        try:
            if reports_dir and not os.path.exists(reports_dir):
                os.makedirs(reports_dir, exist_ok=True)
            _write_summary_json(summary_fail, summary_json_path)
            _write_summary_txt(summary_fail, summary_txt_path)
            persist_phase_e_state(lab_root, rid, False, summary_fail.get("error_code"), 0, 0, "fail", {})
        finally:
            release_lock(lab_root, owner_pid=os.getpid())
        try:
            from phase_e_auto_report import submit_phase_e_failure_report
            submit_phase_e_failure_report(lab_root, {
                "error_code": summary_fail.get("error_code"), "run_id": rid,
                "first_failed": "prelock", "lab_root": lab_root,
                "report_json_path": summary_json_path, "report_txt_path": summary_txt_path,
                "summary": summary_fail,
            })
        except Exception:
            pass
    except SystemExit:
        pass


def _write_summary_json(summary, path):
    dir_path = os.path.dirname(path)
    if dir_path and not os.path.exists(dir_path):
        os.makedirs(dir_path, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)


def _write_summary_txt(summary, path):
    lines = [
        "Phase E Projection and Parity Summary",
        "run_id: {0}".format(summary.get("run_id", "")),
        "generated_at_utc: {0}".format(summary.get("generated_at_utc", "")),
        "ok: {0}".format(summary.get("ok", False)),
        "eligible_count: {0}".format(summary.get("eligible_count", 0)),
        "projected_success_this_run: {0}".format(summary.get("projected_success_this_run", 0)),
        "projected_reject_this_run: {0}".format(summary.get("projected_reject_this_run", 0)),
        "contract_parity_status: {0}".format(summary.get("contract_parity_status", "")),
        "baseline_parity_status: {0}".format(summary.get("baseline_parity_status", "")),
        "error_code: {0}".format(summary.get("error_code", "")),
    ]
    dir_path = os.path.dirname(path)
    if dir_path and not os.path.exists(dir_path):
        os.makedirs(dir_path, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")


def persist_phase_e_state(lab_root, rid, ok, error_code, projected_count, deferred_count,
                         contract_parity_status, cumulative):
    """Update run_cursor.json and diagnostics_state.json with Phase E outcome."""
    cursor_path = os.path.join(lab_root, "run_cursor.json")
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    now = iso_utc_now()
    cursor = {}
    if os.path.exists(cursor_path):
        try:
            with open(cursor_path, "r", encoding="utf-8") as f:
                cursor = json.load(f)
        except Exception:
            pass
    cursor["last_phase_e_run_id"] = rid
    cursor["last_phase_e_ok"] = ok
    cursor["last_projection_version"] = PROJECTION_VERSION
    cursor["last_phase_e_projected_count"] = projected_count
    cursor["last_phase_e_deferred_count"] = deferred_count
    cursor["last_contract_parity_status"] = contract_parity_status
    cursor["last_baseline_parity_status"] = BASELINE_PARITY_STATUS_SKIPPED
    cursor["last_phase_e_error_code"] = error_code
    cursor["last_phase_e_at_utc"] = now
    replace_safe_write(cursor_path, cursor)
    state = {}
    if os.path.exists(state_path):
        try:
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
        except Exception:
            pass
    state["last_phase_e_run_id"] = rid
    state["last_phase_e_ok"] = ok
    state["last_projection_version"] = PROJECTION_VERSION
    state["last_phase_e_projected_count"] = projected_count
    state["last_phase_e_deferred_count"] = deferred_count
    state["last_contract_parity_status"] = contract_parity_status
    state["last_baseline_parity_status"] = BASELINE_PARITY_STATUS_SKIPPED
    state["last_phase_e_error_code"] = error_code
    state["last_phase_e_at_utc"] = now
    replace_safe_write(state_path, state)


def main():
    parser = argparse.ArgumentParser(description="Phase E projection and parity")
    parser.add_argument("--lab-dir", help="Override lab root")
    args = parser.parse_args()
    lab_root = _resolve_lab_root(args)
    if not os.path.exists(lab_root):
        os.makedirs(lab_root, exist_ok=True)
    ok, rid, summary, error_code = run_projection_parity(lab_root)
    if not ok:
        print("Phase E failed: {0}".format(error_code), file=sys.stderr)
        sys.exit(1)
    print("Phase E ok: {0} projected, contract_parity={1}".format(
        summary.get("projected_success_this_run", 0) + summary.get("projected_reject_this_run", 0),
        summary.get("contract_parity_status", "")))


if __name__ == "__main__":
    main()
