#!/usr/bin/env python
"""
Phase E projection and parity: policy versions, error codes, constants.
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import json
import os
import sys

# DRY: Import from phase_a_common
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)
try:
    from phase_a_common import iso_utc_now as _iso_utc_now, run_id as _run_id
    iso_utc_now = _iso_utc_now
    run_id = _run_id
except ImportError:
    import time
    import hashlib
    import uuid
    def iso_utc_now():
        return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    def run_id():
        ts = time.strftime("%Y%m%d-%H%M%S", time.gmtime())
        try:
            hex_part = uuid.uuid4().hex[:8]
        except Exception:
            hex_part = hashlib.sha256(str(time.time()).encode()).hexdigest()[:8]
        return "{0}-{1}".format(ts, hex_part)

# Version constants (use in SQL; do not hardcode literals)
QA_STAGE_PHASE_D = "phase_d"
QA_POLICY_VERSION = "qa_v2"
PROJECTION_TYPE = "patient_v1"
PROJECTION_VERSION = "proj_v2"
CANONICAL_TYPES_ALLOWLIST = ("patient_csv_row", "x12_member", "dat_record", "docx_schedule")
CANONICAL_TYPES_DEFERRED = ("remittance_row", "artifact_summary")

# Phase E run-level error codes
PHASE_E_DB_WRITE_ERROR = "PHASE_E_DB_WRITE_ERROR"
PHASE_E_STATE_WRITE_ERROR = "PHASE_E_STATE_WRITE_ERROR"
PHASE_E_LOCK_FAIL = "PHASE_E_LOCK_FAIL"
PHASE_E_BASELINE_READ_ERROR = "PHASE_E_BASELINE_READ_ERROR"

# v1 baseline parity: always skipped
BASELINE_PARITY_STATUS_SKIPPED = "skipped"
BASELINE_PARITY_REASON_V1 = "no_baseline_reader_v1"


def serialize_projection_json(obj):
    """
    Deterministic projection JSON serialization per plan contract.
    json.dumps(obj, separators=(",", ":"), ensure_ascii=True, sort_keys=True)
    """
    return json.dumps(obj, separators=(",", ":"), ensure_ascii=True, sort_keys=True)
