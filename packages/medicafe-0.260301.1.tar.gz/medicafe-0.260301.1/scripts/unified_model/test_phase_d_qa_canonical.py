#!/usr/bin/env python
"""
Phase D QA and canonicalization: unit tests.
Tests canonical key determinism, parse providers, QA evaluator, lock fail, state persistence.
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import json
import os
import sqlite3
import sys
import tempfile
import unittest

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.abspath(os.path.join(_SCRIPT_DIR, "..", ".."))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from phase_d_common import (
    PHASE_D_LOCK_FAIL,
    QA_POLICY_VERSION,
    QA_FILE_READ_ERROR,
    QA_UNKNOWN_ARTIFACT_CLASS,
    compute_canonical_key,
    compute_patient_key,
    compute_qa_deterministic_key,
)

try:
    from unittest.mock import patch, MagicMock
except ImportError:
    from mock import patch, MagicMock

SQL_PATH = os.path.join(_ROOT, "sql", "unified_relational_model_v1.sql")


def _make_lab_with_db():
    """Create temp lab dir with unified_model_xp.db and schema."""
    lab_root = tempfile.mkdtemp()
    db_path = os.path.join(lab_root, "unified_model_xp.db")
    reports_dir = os.path.join(lab_root, "reports")
    os.makedirs(reports_dir, exist_ok=True)
    if os.path.exists(SQL_PATH):
        with open(SQL_PATH, "r", encoding="utf-8") as f:
            conn = sqlite3.connect(db_path)
            conn.executescript(f.read())
            conn.close()
    return lab_root, db_path, reports_dir


class TestCanonicalKeyDeterminism(unittest.TestCase):
    """Canonical key formulas: determinism and null handling."""

    def test_same_values_same_key(self):
        k1 = compute_canonical_key(["a", "b", "c"])
        k2 = compute_canonical_key(["a", "b", "c"])
        self.assertEqual(k1, k2)
        self.assertEqual(len(k1), 64)

    def test_null_handling(self):
        k1 = compute_canonical_key(["a", None, "c"])
        k2 = compute_canonical_key(["a", None, "c"])
        self.assertEqual(k1, k2)

    def test_empty_string_handling(self):
        k1 = compute_canonical_key(["a", "", "c"])
        k2 = compute_canonical_key(["a", "", "c"])
        self.assertEqual(k1, k2)

    def test_json_dumps_determinism(self):
        vals = ["x", "y", "z"]
        k1 = compute_canonical_key(vals)
        k2 = compute_canonical_key(vals)
        self.assertEqual(k1, k2)


class TestPatientFieldMapper(unittest.TestCase):
    """Shared CSV patient field mapping helpers."""

    def test_extract_birth_date_patient_dob_alias(self):
        from patient_field_mapper import extract_birth_date
        row = {"Patient DOB": "1985-12-25"}
        self.assertEqual(extract_birth_date(row), "1985-12-25")

    def test_extract_full_name_first_last_fallback(self):
        from patient_field_mapper import extract_full_name
        row = {"Patient First": "Jane", "Patient Last": "Doe"}
        self.assertEqual(extract_full_name(row), "Jane Doe")

    def test_external_id_validation(self):
        from patient_field_mapper import is_valid_external_patient_id_5_digit
        self.assertTrue(is_valid_external_patient_id_5_digit("12345"))
        self.assertFalse(is_valid_external_patient_id_5_digit("3712"))
        self.assertFalse(is_valid_external_patient_id_5_digit(""))


class TestQaEvaluator(unittest.TestCase):
    """QA evaluator pass/reject and unknown class."""

    def test_csv_pass_with_patient_id(self):
        from qa_evaluator import evaluate_qa
        envelope = {"rows": [{"Patient ID": "12345"}], "row_count": 1, "has_patient_id": True}
        pass_qa, code, reason = evaluate_qa("csv", envelope)
        self.assertTrue(pass_qa)
        self.assertIsNone(code)

    def test_csv_reject_no_patient_id(self):
        from qa_evaluator import evaluate_qa
        envelope = {"rows": [{"other": "x"}], "row_count": 1, "has_patient_id": False}
        pass_qa, code, reason = evaluate_qa("csv", envelope)
        self.assertFalse(pass_qa)
        self.assertIsNotNone(code)

    def test_unknown_class_reject(self):
        from qa_evaluator import evaluate_qa
        pass_qa, code, reason = evaluate_qa("unknown_class", {})
        self.assertFalse(pass_qa)
        self.assertEqual(code, QA_UNKNOWN_ARTIFACT_CLASS)


class TestParseProviders(unittest.TestCase):
    """Parse providers: unavailable -> row-level reject, safe wrapper."""

    def test_unknown_artifact_class(self):
        from parse_providers import parse_artifact
        ok, envelope, code = parse_artifact("/nonexistent", "unknown_class")
        self.assertFalse(ok)
        self.assertEqual(code, QA_UNKNOWN_ARTIFACT_CLASS)

    def test_missing_locator(self):
        from parse_providers import parse_artifact, get_last_parse_diag
        ok, envelope, code = parse_artifact("", "csv")
        self.assertFalse(ok)
        self.assertIsNotNone(code)
        self.assertEqual(code, QA_FILE_READ_ERROR)
        diag = get_last_parse_diag()
        self.assertEqual(diag.get("error_code"), QA_FILE_READ_ERROR)
        self.assertEqual(diag.get("provider"), "file_reader")

    def test_csv_patient_id_field_passes_qa(self):
        """CSV with patient_id (not Patient ID) header should pass QA."""
        from parse_providers import parse_csv
        from qa_evaluator import evaluate_qa
        fd, path = None, None
        try:
            fd, path = tempfile.mkstemp(suffix=".csv")
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write("patient_id,Patient Name,Birth Date,Surgery Date\n")
                f.write("12345,Test Patient,01-01-1990,01-15-2025\n")
            fd = None
            ok, envelope, code = parse_csv(path)
            self.assertTrue(ok)
            self.assertIsNotNone(envelope)
            self.assertTrue(envelope.get("has_patient_id"))
            pass_qa, _, _ = evaluate_qa("csv", envelope)
            self.assertTrue(pass_qa)
        finally:
            if path and os.path.exists(path):
                try:
                    os.remove(path)
                except Exception:
                    pass

    def test_jsonl_non_dict_line_does_not_raise(self):
        """JSONL with non-dict line (e.g. [1,2,3]) should parse without AttributeError."""
        from parse_providers import parse_jsonl
        fd, path = None, None
        try:
            fd, path = tempfile.mkstemp(suffix=".jsonl")
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write('{"claim_number": "C1", "payer_id": "P1"}\n')
                f.write("[1, 2, 3]\n")
                f.write('{"Claim #": "C2"}\n')
            fd = None
            ok, envelope, code = parse_jsonl(path)
            self.assertTrue(ok)
            self.assertIsNotNone(envelope)
            self.assertEqual(envelope.get("row_count"), 3)
            self.assertTrue(envelope.get("has_claim_number"))
        finally:
            if path and os.path.exists(path):
                try:
                    os.remove(path)
                except Exception:
                    pass


class TestRunQaCanonical(unittest.TestCase):
    """run_qa_canonical: no eligible rows, lock fail, state persistence."""

    def test_no_eligible_rows_ok(self):
        from run_qa_canonical import run_qa_canonical
        lab_root, db_path, reports_dir = _make_lab_with_db()
        try:
            with patch("run_qa_canonical.acquire_lock"):
                with patch("run_qa_canonical.release_lock"):
                    ok, rid, summary, err = run_qa_canonical(lab_root)
            self.assertTrue(ok)
            self.assertEqual(summary.get("rows_selected"), 0)
            self.assertIsNone(err)
        finally:
            try:
                for f in os.listdir(reports_dir):
                    os.remove(os.path.join(reports_dir, f))
                os.remove(db_path)
                os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_lock_fail_returns_error(self):
        from run_qa_canonical import run_qa_canonical
        lab_root, db_path, reports_dir = _make_lab_with_db()
        try:
            with patch("run_qa_canonical.acquire_lock", side_effect=SystemExit(1)):
                ok, rid, summary, err = run_qa_canonical(lab_root)
            self.assertFalse(ok)
            self.assertEqual(err, PHASE_D_LOCK_FAIL)
        finally:
            try:
                if os.path.exists(db_path):
                    os.remove(db_path)
                if os.path.exists(reports_dir):
                    for f in os.listdir(reports_dir):
                        os.remove(os.path.join(reports_dir, f))
                    os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_artifact_class_filter_selects_only_requested_classes(self):
        from run_qa_canonical import run_qa_canonical
        lab_root, db_path, reports_dir = _make_lab_with_db()
        csv_path = None
        try:
            csv_path = os.path.join(lab_root, "filtered.csv")
            with open(csv_path, "w", encoding="utf-8") as f:
                f.write("Patient ID,Patient Name,Birth Date\n")
                f.write("12345,Filter Test,01-01-1990\n")

            conn = sqlite3.connect(db_path)
            payload_csv = json.dumps({
                "artifact_class": "csv",
                "locator": csv_path,
            }, separators=(",", ":"))
            payload_docx = json.dumps({
                "artifact_class": "docx",
                "locator": "",
            }, separators=(",", ":"))
            conn.execute(
                "INSERT INTO ingest_artifact (ingest_key, source_system, source_type, source_ref, message_id, "
                "attachment_name, attachment_sha256, payload_json, ingest_status) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                ("filter_csv_1", "xp_local", "file_csv", "src|path", None, "filtered.csv", "", payload_csv, "ingested"),
            )
            conn.execute(
                "INSERT INTO ingest_artifact (ingest_key, source_system, source_type, source_ref, message_id, "
                "attachment_name, attachment_sha256, payload_json, ingest_status) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                ("filter_docx_1", "xp_local", "file_docx", "src|path", None, "filtered.docx", "", payload_docx, "ingested"),
            )
            conn.commit()
            conn.close()

            with patch("run_qa_canonical.acquire_lock"):
                with patch("run_qa_canonical.release_lock"):
                    ok, rid, summary, err = run_qa_canonical(lab_root, artifact_classes=["csv"])
            self.assertTrue(ok)
            self.assertEqual(summary.get("rows_selected"), 1)
            self.assertEqual(summary.get("artifact_class_filter"), ["csv"])
        finally:
            try:
                if csv_path and os.path.exists(csv_path):
                    os.remove(csv_path)
                if os.path.exists(db_path):
                    os.remove(db_path)
                if os.path.exists(reports_dir):
                    for f in os.listdir(reports_dir):
                        os.remove(os.path.join(reports_dir, f))
                    os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestCanonicalExtractor(unittest.TestCase):
    """Canonical extractor: produces records with provenance."""

    def test_extract_produces_records(self):
        from canonical_extractor import extract_canonical_records
        envelope = {"rows": [{"Patient ID": "123", "Birth Date": "01-01-1990"}], "row_count": 1}
        recs = extract_canonical_records(1, "csv", envelope, "xp_local", "src|path")
        self.assertGreater(len(recs), 0)
        for r in recs:
            self.assertIn("canonical_type", r)
            self.assertIn("canonical_key", r)
            self.assertIn("provenance_json", r)


class TestRunQaCanonicalIntegration(unittest.TestCase):
    """End-to-end row processing: pass, reject, parse-fail; qa_result, replay_queue, extracted_canonical_record, patient."""

    def test_integration_pass_reject_parsefail(self):
        from run_qa_canonical import run_qa_canonical
        lab_root, db_path, reports_dir = _make_lab_with_db()
        csv_pass_path = None
        csv_reject_path = None
        try:
            csv_pass_path = os.path.join(lab_root, "test_pass.csv")
            with open(csv_pass_path, "w", encoding="utf-8") as f:
                f.write("Patient ID,Patient Name,Birth Date,Surgery Date\n")
                f.write("12345,Test Patient,01-01-1990,01-15-2025\n")
            csv_reject_path = os.path.join(lab_root, "test_reject.csv")
            with open(csv_reject_path, "w", encoding="utf-8") as f:
                f.write("other,value\n")
                f.write("x,y\n")
            conn = sqlite3.connect(db_path)
            payload_pass = json.dumps({
                "artifact_class": "csv",
                "locator": csv_pass_path,
                "normalized_path": "test_pass.csv",
            }, separators=(",", ":"))
            payload_reject = json.dumps({
                "artifact_class": "csv",
                "locator": csv_reject_path,
                "normalized_path": "test_reject.csv",
            }, separators=(",", ":"))
            payload_fail = json.dumps({
                "artifact_class": "csv",
                "locator": "",
                "normalized_path": "nonexistent.csv",
            }, separators=(",", ":"))
            for ingest_key, payload in [
                ("int_test_pass_1", payload_pass),
                ("int_test_reject_2", payload_reject),
                ("int_test_fail_3", payload_fail),
            ]:
                conn.execute(
                    "INSERT INTO ingest_artifact (ingest_key, source_system, source_type, source_ref, message_id, "
                    "attachment_name, attachment_sha256, payload_json, ingest_status) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (ingest_key, "xp_local", "file_csv", "src|path", None, "x.csv", "", payload, "ingested"),
                )
            conn.commit()
            conn.close()
            with patch("run_qa_canonical.acquire_lock"):
                with patch("run_qa_canonical.release_lock"):
                    ok, rid, summary, err = run_qa_canonical(lab_root)
            self.assertTrue(ok)
            self.assertEqual(summary.get("rows_selected"), 3)
            self.assertEqual(summary.get("qa_pass_count"), 1)
            self.assertEqual(summary.get("qa_reject_count"), 2)
            conn = sqlite3.connect(db_path)
            qa_pass = conn.execute(
                "SELECT COUNT(*) FROM qa_result WHERE status='pass' AND qa_stage='phase_d'"
            ).fetchone()[0]
            qa_reject = conn.execute(
                "SELECT COUNT(*) FROM qa_result WHERE status='reject' AND qa_stage='phase_d'"
            ).fetchone()[0]
            self.assertEqual(qa_pass, 1)
            self.assertEqual(qa_reject, 2)
            replay_count = conn.execute("SELECT COUNT(*) FROM replay_queue").fetchone()[0]
            self.assertEqual(replay_count, 2)
            replay_reasons = [r[0] for r in conn.execute("SELECT reason_code FROM replay_queue").fetchall()]
            self.assertIn(QA_FILE_READ_ERROR, replay_reasons)
            canon_count = conn.execute("SELECT COUNT(*) FROM extracted_canonical_record").fetchone()[0]
            self.assertGreaterEqual(canon_count, 1)
            patient_count = conn.execute("SELECT COUNT(*) FROM patient").fetchone()[0]
            self.assertGreaterEqual(patient_count, 1)
            conn.close()
        finally:
            try:
                if csv_pass_path and os.path.exists(csv_pass_path):
                    os.remove(csv_pass_path)
                if csv_reject_path and os.path.exists(csv_reject_path):
                    os.remove(csv_reject_path)
                if os.path.exists(reports_dir):
                    for f in os.listdir(reports_dir):
                        os.remove(os.path.join(reports_dir, f))
                    os.rmdir(reports_dir)
                if os.path.exists(db_path):
                    os.remove(db_path)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_invalid_external_patient_id_logged_and_skipped(self):
        from run_qa_canonical import run_qa_canonical
        lab_root, db_path, reports_dir = _make_lab_with_db()
        try:
            conn = sqlite3.connect(db_path)
            payload = json.dumps({
                "artifact_class": "csv",
                "locator": "",
                "normalized_path": "invalid_id.csv",
            }, separators=(",", ":"))
            conn.execute(
                "INSERT INTO ingest_artifact (ingest_key, source_system, source_type, source_ref, message_id, "
                "attachment_name, attachment_sha256, payload_json, ingest_status) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                ("invalid_id_case", "xp_local", "file_csv", "src|path", None, "invalid_id.csv", "", payload, "ingested"),
            )
            conn.commit()
            conn.close()

            mocked_envelope = {
                "rows": [{
                    "Patient ID": "3712",
                    "Patient First": "Invalid",
                    "Patient Last": "Id",
                    "Patient DOB": "1990-01-01",
                }],
                "row_count": 1,
                "has_patient_id": True,
            }
            with patch("run_qa_canonical.parse_artifact", return_value=(True, mocked_envelope, None)):
                with patch("run_qa_canonical.acquire_lock"):
                    with patch("run_qa_canonical.release_lock"):
                        ok, rid, summary, err = run_qa_canonical(lab_root)
            self.assertTrue(ok)
            self.assertEqual(summary.get("qa_pass_count"), 1)
            self.assertEqual(
                (summary.get("constraint_skip_counts") or {}).get("patient_invalid_external_id"),
                1,
            )

            conn = sqlite3.connect(db_path)
            patient_count = conn.execute("SELECT COUNT(*) FROM patient").fetchone()[0]
            self.assertEqual(patient_count, 0)
            log_rows = conn.execute(
                "SELECT decision_type, decision_context_json FROM rule_decision_log WHERE decision_type='constraint_fail'"
            ).fetchall()
            self.assertEqual(len(log_rows), 1)
            context = json.loads(log_rows[0][1])
            self.assertEqual(context.get("reason_code"), "PATIENT_EXTERNAL_ID_INVALID_FORMAT")
            qa_rows = conn.execute(
                "SELECT COUNT(*) FROM qa_result WHERE qa_stage='phase_d' AND qa_version=? AND status='pass'",
                (QA_POLICY_VERSION,),
            ).fetchone()[0]
            self.assertEqual(qa_rows, 1)
            conn.close()
        finally:
            try:
                if os.path.exists(reports_dir):
                    for f in os.listdir(reports_dir):
                        os.remove(os.path.join(reports_dir, f))
                    os.rmdir(reports_dir)
                if os.path.exists(db_path):
                    os.remove(db_path)
                os.rmdir(lab_root)
            except Exception:
                pass


if __name__ == "__main__":
    unittest.main()
