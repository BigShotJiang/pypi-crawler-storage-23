"""Version information for ytd-wrap."""

__version__: str = "0.1.0"
