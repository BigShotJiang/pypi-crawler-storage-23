from __future__ import annotations

from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

import pytest

from tools.team_analytics_audit.collector import (
    GitDataCollector,
    _extract_co_authors,
    _parse_file_changes,
    _parse_primary_output,
)
from tools.team_analytics_audit.models import FileChange, RawCommit


class TestParseFileChanges:
    def test_parses_valid_numstat_line(self):
        lines = ["10\t5\tsrc/main.py"]
        result = _parse_file_changes(lines)
        assert len(result) == 1
        assert result[0].file_path == "src/main.py"
        assert result[0].additions == 10
        assert result[0].deletions == 5
        assert result[0].is_binary is False

    def test_parses_binary_file(self):
        lines = ["-\t-\tassets/logo.png"]
        result = _parse_file_changes(lines)
        assert len(result) == 1
        assert result[0].is_binary is True
        assert result[0].additions == 0
        assert result[0].deletions == 0

    def test_skips_malformed_lines(self):
        lines = ["invalid_line", "10\t5\tsrc/file.py"]
        result = _parse_file_changes(lines)
        assert len(result) == 1

    def test_empty_input(self):
        result = _parse_file_changes([])
        assert result == []

    def test_multiple_files(self):
        lines = [
            "3\t1\tsrc/a.py",
            "7\t2\tsrc/b.py",
        ]
        result = _parse_file_changes(lines)
        assert len(result) == 2


class TestExtractCoAuthors:
    def test_extracts_co_author(self):
        body = (
            "COMMIT|abc123|Alice|alice@example.com|Body text\n"
            "Co-authored-by: Bob <bob@example.com>\n"
        )
        result = _extract_co_authors(body)
        assert "abc123" in result
        assert len(result["abc123"]) == 1
        assert "Bob" in result["abc123"][0]

    def test_case_insensitive_prefix(self):
        body = (
            "COMMIT|hash1|Alice|alice@example.com|Body\n"
            "CO-AUTHORED-BY: Carol <carol@example.com>\n"
        )
        result = _extract_co_authors(body)
        assert len(result["hash1"]) == 1

    def test_no_co_authors(self):
        body = "COMMIT|hash1|Alice|alice@example.com|Body\n"
        result = _extract_co_authors(body)
        assert result["hash1"] == []

    def test_multiple_commits(self):
        body = (
            "COMMIT|hash1|Alice|alice@example.com|Body\n"
            "Co-authored-by: Bob <bob@example.com>\n"
            "COMMIT|hash2|Bob|bob@example.com|Body\n"
        )
        result = _extract_co_authors(body)
        assert len(result["hash1"]) == 1
        assert len(result["hash2"]) == 0


class TestParsePrimaryOutput:
    def test_parses_single_commit(self):
        output = (
            "COMMIT|abc123|Alice|alice@example.com|"
            "2026-01-15T10:00:00+00:00|feat: add feature|parent1\n"
            "10\t5\tsrc/main.py\n"
        )
        commits = _parse_primary_output(output)
        assert len(commits) == 1
        assert commits[0].hash == "abc123"
        assert commits[0].author_name == "Alice"
        assert commits[0].is_merge is False
        assert len(commits[0].files_changed) == 1

    def test_detects_merge_commit(self):
        output = (
            "COMMIT|merge1|Bob|bob@example.com|"
            "2026-01-15T10:00:00+00:00|Merge branch main|p1 p2\n"
        )
        commits = _parse_primary_output(output)
        assert commits[0].is_merge is True

    def test_empty_output(self):
        commits = _parse_primary_output("")
        assert commits == []


class TestGitDataCollectorFilter:
    def setup_method(self):
        self.collector = GitDataCollector()
        self.ts = datetime(2026, 1, 15, 10, 0, 0, tzinfo=timezone.utc)

    def _make_commit(self, name: str, email: str) -> RawCommit:
        return RawCommit(
            hash="abc",
            author_name=name,
            author_email=email,
            timestamp=self.ts,
            subject="feat: something",
            parent_hashes=["p1"],
            files_changed=[],
            is_merge=False,
        )

    def test_author_filter_matches_by_name(self):
        commits = [
            self._make_commit("Alice Smith", "alice@example.com"),
            self._make_commit("Bob Jones", "bob@example.com"),
        ]
        result = self.collector._apply_author_filter(commits, "alice")
        assert len(result) == 1
        assert result[0].author_name == "Alice Smith"

    def test_author_filter_case_insensitive(self):
        commits = [self._make_commit("Alice Smith", "alice@example.com")]
        result = self.collector._apply_author_filter(commits, "ALICE")
        assert len(result) == 1

    def test_author_filter_not_found_raises(self):
        commits = [self._make_commit("Bob Jones", "bob@example.com")]
        with pytest.raises(ValueError, match="author_not_found"):
            self.collector._apply_author_filter(commits, "alice")

    def test_author_filter_none_returns_all(self):
        commits = [
            self._make_commit("Alice", "alice@example.com"),
            self._make_commit("Bob", "bob@example.com"),
        ]
        result = self.collector._apply_author_filter(commits, None)
        assert len(result) == 2

    def test_team_filter_includes_matching_members(self):
        commits = [
            self._make_commit("Alice Smith", "alice@example.com"),
            self._make_commit("Bob Jones", "bob@example.com"),
            self._make_commit("Carol White", "carol@example.com"),
        ]
        result = self.collector._apply_team_filter(
            commits, ["alice", "bob"]
        )
        assert len(result) == 2

    def test_team_filter_none_returns_all(self):
        commits = [
            self._make_commit("Alice", "alice@example.com"),
            self._make_commit("Bob", "bob@example.com"),
        ]
        result = self.collector._apply_team_filter(commits, None)
        assert len(result) == 2

    def test_verify_git_repo_raises_for_non_repo(self):
        with patch(
            "tools.team_analytics_audit.collector._run_git"
        ) as mock_run:
            mock_result = MagicMock()
            mock_result.returncode = 128
            mock_run.return_value = mock_result
            with pytest.raises(ValueError, match="no_git_repo"):
                self.collector._verify_git_repo("/tmp/not-a-repo")

    def test_collect_raises_on_git_error(self):
        with patch(
            "tools.team_analytics_audit.collector._run_git"
        ) as mock_run:
            verify_result = MagicMock()
            verify_result.returncode = 0
            error_result = MagicMock()
            error_result.returncode = 128
            error_result.stderr = "fatal: not a git repository"
            mock_run.side_effect = [verify_result, error_result]
            with pytest.raises(RuntimeError, match="Git command failed"):
                self.collector.collect(
                    root="/tmp/not-a-repo",
                    since=self.ts,
                    until=self.ts,
                )
