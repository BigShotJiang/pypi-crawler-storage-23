import pytest

from tools.findings_to_tickets.formatter import (
    format_finding_description,
    format_finding_title,
    severity_to_priority,
)
from tools.findings_to_tickets.models import Platform


class TestFormatFindingTitle:
    def test_basic_title(self):
        finding = {
            "severity": "critical",
            "category": "SQL Injection",
            "description": "User input not sanitized in login form",
        }
        result = format_finding_title(finding)
        assert result == "[CRITICAL] SQL Injection: User input not sanitized in login form"

    def test_truncates_long_description(self):
        finding = {
            "severity": "high",
            "category": "XSS",
            "description": "A" * 300,
        }
        result = format_finding_title(finding, max_length=50)
        assert len(result) <= 50
        assert result.endswith("...")

    def test_handles_multiline_description(self):
        finding = {
            "severity": "medium",
            "category": "Config",
            "description": "First line of description\nSecond line\nThird line",
        }
        result = format_finding_title(finding)
        assert "First line of description" in result
        assert "Second line" not in result

    def test_missing_fields_use_defaults(self):
        finding = {}
        result = format_finding_title(finding)
        assert "[INFO]" in result
        assert "Unknown" in result

    def test_severity_uppercased(self):
        finding = {"severity": "low", "category": "Test", "description": "desc"}
        result = format_finding_title(finding)
        assert "[LOW]" in result

    def test_respects_custom_max_length(self):
        finding = {
            "severity": "info",
            "category": "Category",
            "description": "This is a description",
        }
        result = format_finding_title(finding, max_length=30)
        assert len(result) <= 30


class TestFormatFindingDescription:
    def test_basic_description(self):
        finding = {
            "severity": "critical",
            "category": "SQL Injection",
            "description": "SQL injection vulnerability found",
        }
        audit_info = {"lens": "security", "date": "2026-02-18"}
        result = format_finding_description(finding, audit_info)

        assert "## Finding Details" in result
        assert "**Severity**: critical" in result
        assert "**Category**: SQL Injection" in result
        assert "SQL injection vulnerability found" in result
        assert "Optix security audit" in result
        assert "2026-02-18" in result

    def test_includes_affected_files(self):
        finding = {
            "severity": "high",
            "category": "XSS",
            "description": "XSS vulnerability",
            "affected_files": ["src/login.py", "src/auth.py"],
        }
        audit_info = {"lens": "security", "date": "2026-02-18"}
        result = format_finding_description(finding, audit_info)

        assert "## Affected Files" in result
        assert "- `src/login.py`" in result
        assert "- `src/auth.py`" in result

    def test_includes_remediation(self):
        finding = {
            "severity": "medium",
            "category": "ARIA",
            "description": "Missing ARIA label",
            "remediation": "Add aria-label attribute to button",
        }
        audit_info = {"lens": "a11y", "date": "2026-02-18"}
        result = format_finding_description(finding, audit_info)

        assert "## Remediation" in result
        assert "Add aria-label attribute" in result

    def test_omits_empty_sections(self):
        finding = {
            "severity": "low",
            "category": "Style",
            "description": "Minor style issue",
            "affected_files": [],
            "remediation": "",
        }
        audit_info = {"lens": "principal", "date": "2026-02-18"}
        result = format_finding_description(finding, audit_info)

        assert "## Affected Files" not in result
        assert "## Remediation" not in result

    def test_uses_default_values(self):
        finding = {}
        audit_info = {}
        result = format_finding_description(finding, audit_info)

        assert "**Severity**: info" in result
        assert "**Category**: Unknown" in result
        assert "No description provided" in result
        assert "security" in result
        assert "unknown date" in result


class TestSeverityToPriority:
    @pytest.mark.parametrize(
        "severity,platform,expected",
        [
            ("critical", Platform.LINEAR, "1"),
            ("critical", Platform.JIRA, "Highest"),
            ("high", Platform.LINEAR, "2"),
            ("high", Platform.JIRA, "High"),
            ("medium", Platform.LINEAR, "3"),
            ("medium", Platform.JIRA, "Medium"),
            ("low", Platform.LINEAR, "4"),
            ("low", Platform.JIRA, "Low"),
            ("info", Platform.LINEAR, "0"),
            ("info", Platform.JIRA, "Lowest"),
        ],
    )
    def test_severity_mapping(self, severity, platform, expected):
        assert severity_to_priority(severity, platform) == expected

    def test_case_insensitive(self):
        assert severity_to_priority("CRITICAL", Platform.LINEAR) == "1"
        assert severity_to_priority("High", Platform.JIRA) == "High"

    def test_whitespace_handling(self):
        assert severity_to_priority("  medium  ", Platform.LINEAR) == "3"

    def test_unknown_severity_defaults_to_info(self):
        assert severity_to_priority("unknown", Platform.LINEAR) == "0"
        assert severity_to_priority("unknown", Platform.JIRA) == "Lowest"
        assert severity_to_priority("", Platform.LINEAR) == "0"
