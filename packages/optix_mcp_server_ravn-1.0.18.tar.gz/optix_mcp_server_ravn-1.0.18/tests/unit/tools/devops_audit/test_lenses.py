"""Tests for DevOps Audit lenses."""

import pytest

from tools.devops_audit.domains import DevOpsCategory, DevOpsLens
from tools.devops_audit.lenses import (
    LENS_REGISTRY,
    BaseLens,
    ComplianceLens,
    ComprehensiveLens,
    LensConfig,
    LensRule,
    MultiCloudLens,
    PerformanceLens,
    SecurityLens,
    StartupLens,
    get_lens,
    get_lens_config,
    list_available_lenses,
)


class TestDevOpsLensEnum:
    def test_all_lens_values(self):
        assert DevOpsLens.SECURITY.value == "security"
        assert DevOpsLens.PERFORMANCE.value == "performance"
        assert DevOpsLens.COMPLIANCE.value == "compliance"
        assert DevOpsLens.MULTICLOUD.value == "multicloud"
        assert DevOpsLens.STARTUP.value == "startup"
        assert DevOpsLens.COMPREHENSIVE.value == "comprehensive"

    def test_from_string_valid(self):
        assert DevOpsLens.from_string("security") == DevOpsLens.SECURITY
        assert DevOpsLens.from_string("SECURITY") == DevOpsLens.SECURITY
        assert DevOpsLens.from_string(" performance ") == DevOpsLens.PERFORMANCE

    def test_from_string_none_returns_comprehensive(self):
        assert DevOpsLens.from_string(None) == DevOpsLens.COMPREHENSIVE

    def test_from_string_invalid_returns_comprehensive(self):
        assert DevOpsLens.from_string("invalid") == DevOpsLens.COMPREHENSIVE

    def test_display_name(self):
        assert DevOpsLens.SECURITY.display_name == "Security-First"
        assert DevOpsLens.PERFORMANCE.display_name == "Performance & Cost"
        assert DevOpsLens.STARTUP.display_name == "Startup/Agile"

    def test_description(self):
        assert "secrets" in DevOpsLens.SECURITY.description.lower()
        assert "build times" in DevOpsLens.PERFORMANCE.description.lower()


class TestLensRegistry:
    def test_all_lenses_registered(self):
        assert len(LENS_REGISTRY) == 6
        assert DevOpsLens.SECURITY in LENS_REGISTRY
        assert DevOpsLens.PERFORMANCE in LENS_REGISTRY
        assert DevOpsLens.COMPLIANCE in LENS_REGISTRY
        assert DevOpsLens.MULTICLOUD in LENS_REGISTRY
        assert DevOpsLens.STARTUP in LENS_REGISTRY
        assert DevOpsLens.COMPREHENSIVE in LENS_REGISTRY

    def test_get_lens_by_string(self):
        lens = get_lens("security")
        assert isinstance(lens, SecurityLens)
        assert lens.lens_type == DevOpsLens.SECURITY

    def test_get_lens_by_enum(self):
        lens = get_lens(DevOpsLens.PERFORMANCE)
        assert isinstance(lens, PerformanceLens)

    def test_get_lens_none_returns_comprehensive(self):
        lens = get_lens(None)
        assert isinstance(lens, ComprehensiveLens)

    def test_get_lens_config_returns_config(self):
        config = get_lens_config("security")
        assert isinstance(config, LensConfig)
        assert config.lens == DevOpsLens.SECURITY

    def test_list_available_lenses(self):
        lenses = list_available_lenses()
        assert len(lenses) == 6
        lens_ids = [l["id"] for l in lenses]
        assert "security" in lens_ids
        assert "comprehensive" in lens_ids


class TestSecurityLens:
    def test_has_docker_rules(self):
        config = SecurityLens().get_config()
        assert len(config.docker_rules) == 4
        rule_ids = [r.id for r in config.docker_rules]
        assert "SEC-D001" in rule_ids
        assert "SEC-D002" in rule_ids

    def test_has_cicd_rules(self):
        config = SecurityLens().get_config()
        assert len(config.cicd_rules) == 4
        rule_ids = [r.id for r in config.cicd_rules]
        assert "SEC-C001" in rule_ids

    def test_has_dependency_rules(self):
        config = SecurityLens().get_config()
        assert len(config.dependency_rules) == 4

    def test_hardcoded_secrets_rule(self):
        config = SecurityLens().get_config()
        secrets_rule = next(r for r in config.docker_rules if r.id == "SEC-D001")
        assert secrets_rule.severity_default == "critical"
        assert len(secrets_rule.check_guidance) > 0


class TestPerformanceLens:
    def test_has_docker_rules(self):
        config = PerformanceLens().get_config()
        assert len(config.docker_rules) == 4
        rule_ids = [r.id for r in config.docker_rules]
        assert "PERF-D001" in rule_ids

    def test_cache_invalidation_rule(self):
        config = PerformanceLens().get_config()
        cache_rule = next(r for r in config.docker_rules if r.id == "PERF-D001")
        assert cache_rule.name == "Layer Cache Invalidation"
        assert cache_rule.severity_default == "medium"


class TestComplianceLens:
    def test_has_docker_rules(self):
        config = ComplianceLens().get_config()
        assert len(config.docker_rules) == 4
        rule_ids = [r.id for r in config.docker_rules]
        assert "COMP-D001" in rule_ids

    def test_healthcheck_rule(self):
        config = ComplianceLens().get_config()
        health_rule = next(r for r in config.docker_rules if r.id == "COMP-D001")
        assert "HEALTHCHECK" in health_rule.name


class TestMultiCloudLens:
    def test_has_docker_rules(self):
        config = MultiCloudLens().get_config()
        assert len(config.docker_rules) == 4
        rule_ids = [r.id for r in config.docker_rules]
        assert "CLOUD-D001" in rule_ids

    def test_cloud_credentials_rule(self):
        config = MultiCloudLens().get_config()
        creds_rule = next(r for r in config.docker_rules if r.id == "CLOUD-D001")
        assert creds_rule.severity_default == "critical"


class TestStartupLens:
    def test_has_fewer_rules(self):
        config = StartupLens().get_config()
        assert len(config.docker_rules) == 3
        assert len(config.cicd_rules) == 3
        assert len(config.dependency_rules) == 2

    def test_quick_win_rules(self):
        config = StartupLens().get_config()
        rule_ids = [r.id for r in config.get_all_rules()]
        assert "START-D001" in rule_ids
        assert "START-P001" in rule_ids


class TestComprehensiveLens:
    def test_has_more_rules(self):
        config = ComprehensiveLens().get_config()
        assert len(config.docker_rules) >= 5
        assert len(config.cicd_rules) >= 5
        assert len(config.dependency_rules) >= 4

    def test_includes_rules_from_multiple_prefixes(self):
        config = ComprehensiveLens().get_config()
        all_ids = [r.id for r in config.get_all_rules()]
        prefixes = set(id.split("-")[0] for id in all_ids)
        assert "SEC" in prefixes
        assert "PERF" in prefixes or "COMP" in prefixes


class TestLensConfig:
    def test_get_rules_for_category(self):
        config = SecurityLens().get_config()
        docker_rules = config.get_rules_for_category(DevOpsCategory.DOCKERFILE)
        assert len(docker_rules) == 4

    def test_get_all_rules(self):
        config = SecurityLens().get_config()
        all_rules = config.get_all_rules()
        assert len(all_rules) == 12

    def test_get_rule_ids(self):
        config = SecurityLens().get_config()
        ids = config.get_rule_ids()
        assert "SEC-D001" in ids
        assert "SEC-C001" in ids
        assert "SEC-P001" in ids


class TestBaseLensInterface:
    def test_get_required_actions(self):
        lens = SecurityLens()
        actions = lens.get_required_actions(DevOpsCategory.DOCKERFILE)
        assert len(actions) > 0
        assert any("password" in a.lower() or "credentials" in a.lower() for a in actions)

    def test_get_rule_summary(self):
        lens = SecurityLens()
        summary = lens.get_rule_summary()
        assert summary["dockerfile"] == 4
        assert summary["cicd"] == 4
        assert summary["dependency"] == 4
        assert summary["total"] == 12


class TestLensRule:
    def test_lens_rule_creation(self):
        rule = LensRule(
            id="TEST-001",
            category=DevOpsCategory.DOCKERFILE,
            name="Test Rule",
            description="A test rule",
            severity_default="high",
            check_guidance=["Check something", "Check another thing"],
        )
        assert rule.id == "TEST-001"
        assert rule.category == DevOpsCategory.DOCKERFILE
        assert len(rule.check_guidance) == 2
