"""Comprehensive lens for DevOps audit - includes all rules."""

from tools.devops_audit.domains import DevOpsCategory, DevOpsLens
from tools.devops_audit.lenses.base import BaseLens, LensConfig, LensRule


class ComprehensiveLens(BaseLens):
    """Comprehensive lens including all rules from all specialized lenses."""

    @property
    def lens_type(self) -> DevOpsLens:
        return DevOpsLens.COMPREHENSIVE

    def get_config(self) -> LensConfig:
        return LensConfig(
            lens=DevOpsLens.COMPREHENSIVE,
            display_name="Comprehensive",
            description="All checks across security, performance, compliance, and cloud",
            docker_rules=[
                LensRule(
                    id="SEC-D001",
                    category=DevOpsCategory.DOCKERFILE,
                    name="Hardcoded Secrets",
                    description="Detect hardcoded secrets in Dockerfile layers",
                    severity_default="critical",
                    check_guidance=[
                        "Search for ENV with passwords, tokens, API keys",
                        "Check COPY/ADD of .env, credentials, key files",
                        "Look for ARG with default secret values",
                    ],
                ),
                LensRule(
                    id="SEC-D002",
                    category=DevOpsCategory.DOCKERFILE,
                    name="Root User Execution",
                    description="Container running as root user",
                    severity_default="high",
                    check_guidance=[
                        "Check for USER directive presence",
                        "Verify USER is not root or 0",
                    ],
                ),
                LensRule(
                    id="SEC-D003",
                    category=DevOpsCategory.DOCKERFILE,
                    name="Unpinned Base Images",
                    description="Base images without version pinning",
                    severity_default="high",
                    check_guidance=[
                        "Check FROM statements for :latest or missing tags",
                        "Verify base image uses specific version tag",
                    ],
                ),
                LensRule(
                    id="SEC-D004",
                    category=DevOpsCategory.DOCKERFILE,
                    name="Curl Pipe Bash",
                    description="Dangerous curl | bash patterns",
                    severity_default="critical",
                    check_guidance=[
                        "Search for curl | bash or wget | sh patterns",
                    ],
                ),
                LensRule(
                    id="COMP-D001",
                    category=DevOpsCategory.DOCKERFILE,
                    name="Missing HEALTHCHECK",
                    description="No HEALTHCHECK directive",
                    severity_default="medium",
                    check_guidance=[
                        "Check for HEALTHCHECK directive",
                    ],
                ),
                LensRule(
                    id="PERF-D001",
                    category=DevOpsCategory.DOCKERFILE,
                    name="Layer Cache Invalidation",
                    description="Poor layer ordering",
                    severity_default="medium",
                    check_guidance=[
                        "Check if COPY of package.json before npm install",
                        "Verify frequently changing files copied last",
                    ],
                ),
                LensRule(
                    id="PERF-D002",
                    category=DevOpsCategory.DOCKERFILE,
                    name="Missing Multi-Stage",
                    description="No multi-stage build",
                    severity_default="medium",
                    check_guidance=[
                        "Check for multi-stage build pattern",
                    ],
                ),
            ],
            cicd_rules=[
                LensRule(
                    id="SEC-C001",
                    category=DevOpsCategory.CICD,
                    name="Exposed Secrets",
                    description="Secrets exposed in logs",
                    severity_default="critical",
                    check_guidance=[
                        "Check for echo/print of secret values",
                        "Verify secrets.* usage is protected",
                    ],
                ),
                LensRule(
                    id="SEC-C002",
                    category=DevOpsCategory.CICD,
                    name="Unpinned Actions",
                    description="Actions not SHA pinned",
                    severity_default="high",
                    check_guidance=[
                        "Check actions using @main, @master",
                        "Verify third-party actions pinned",
                    ],
                ),
                LensRule(
                    id="SEC-C003",
                    category=DevOpsCategory.CICD,
                    name="pull_request_target Misuse",
                    description="Dangerous PR trigger",
                    severity_default="critical",
                    check_guidance=[
                        "Check for pull_request_target with checkout",
                    ],
                ),
                LensRule(
                    id="SEC-C004",
                    category=DevOpsCategory.CICD,
                    name="Missing Permissions",
                    description="No permissions block",
                    severity_default="medium",
                    check_guidance=[
                        "Check for permissions block at workflow level",
                    ],
                ),
                LensRule(
                    id="COMP-C002",
                    category=DevOpsCategory.CICD,
                    name="No Required Reviewers",
                    description="Missing review enforcement",
                    severity_default="high",
                    check_guidance=[
                        "Check branch protection rules",
                    ],
                ),
                LensRule(
                    id="PERF-C001",
                    category=DevOpsCategory.CICD,
                    name="Missing Cache",
                    description="No dependency caching",
                    severity_default="medium",
                    check_guidance=[
                        "Check for actions/cache usage",
                    ],
                ),
                LensRule(
                    id="PERF-C003",
                    category=DevOpsCategory.CICD,
                    name="No Job Timeout",
                    description="Missing timeout-minutes",
                    severity_default="medium",
                    check_guidance=[
                        "Check for timeout-minutes on jobs",
                    ],
                ),
            ],
            dependency_rules=[
                LensRule(
                    id="SEC-P001",
                    category=DevOpsCategory.DEPENDENCY,
                    name="Missing Lockfile",
                    description="No lockfile for reproducibility",
                    severity_default="high",
                    check_guidance=[
                        "Check for package-lock.json or yarn.lock",
                    ],
                ),
                LensRule(
                    id="SEC-P002",
                    category=DevOpsCategory.DEPENDENCY,
                    name="Wildcard Versions",
                    description="Unbounded version ranges",
                    severity_default="high",
                    check_guidance=[
                        "Search for * or latest in versions",
                        "Check for >= without upper bound",
                    ],
                ),
                LensRule(
                    id="SEC-P003",
                    category=DevOpsCategory.DEPENDENCY,
                    name="No Automated Updates",
                    description="Missing Dependabot/Renovate",
                    severity_default="medium",
                    check_guidance=[
                        "Check for dependabot.yml or renovate.json",
                    ],
                ),
                LensRule(
                    id="COMP-P003",
                    category=DevOpsCategory.DEPENDENCY,
                    name="No Dependency Audit",
                    description="npm audit not in CI",
                    severity_default="high",
                    check_guidance=[
                        "Check for npm audit in CI pipeline",
                    ],
                ),
                LensRule(
                    id="PERF-P001",
                    category=DevOpsCategory.DEPENDENCY,
                    name="npm install vs ci",
                    description="Using install instead of ci",
                    severity_default="medium",
                    check_guidance=[
                        "Verify npm ci used in CI environments",
                    ],
                ),
            ],
        )
