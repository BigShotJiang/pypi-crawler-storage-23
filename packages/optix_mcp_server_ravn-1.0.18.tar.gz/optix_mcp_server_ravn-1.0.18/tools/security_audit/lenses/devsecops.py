"""DevSecOps Engineer lens for Security Audit.

Focuses on pipeline and infrastructure security from a DevSecOps perspective:
- Secrets in code and configuration
- Dependency vulnerabilities and supply chain security
- CI/CD pipeline security
- Container and infrastructure security
"""

from tools.security_audit.domains import SecurityLens, SecurityStepDomain
from tools.security_audit.lenses.base import BaseLens, LensConfig, LensRule


class DevSecOpsLens(BaseLens):
    """DevSecOps Engineer security perspective.

    Examines code from the viewpoint of a DevSecOps engineer concerned with
    secrets management, dependency security, and CI/CD pipeline hardening.
    """

    @property
    def lens_type(self) -> SecurityLens:
        return SecurityLens.DEVSECOPS

    def get_config(self) -> LensConfig:
        return LensConfig(
            lens=SecurityLens.DEVSECOPS,
            display_name="DevSecOps",
            description="Pipeline security: secrets in code, dependencies, CI/CD, supply chain",
            reconnaissance_rules=[
                LensRule(
                    id="DS-R001",
                    domain=SecurityStepDomain.RECONNAISSANCE,
                    name="Infrastructure Discovery",
                    description="Map CI/CD and infrastructure components",
                    severity_default="info",
                    check_guidance=[
                        "Identify CI/CD platform (GitHub Actions, GitLab CI, Jenkins)",
                        "Map deployment pipelines and environments",
                        "Document infrastructure-as-code usage",
                        "Identify container registries and artifact stores",
                    ],
                ),
                LensRule(
                    id="DS-R002",
                    domain=SecurityStepDomain.RECONNAISSANCE,
                    name="Secrets Management Audit",
                    description="Identify secrets management patterns",
                    severity_default="info",
                    check_guidance=[
                        "Document secrets management solution in use",
                        "Map environment variable usage patterns",
                        "Identify configuration management approach",
                    ],
                ),
            ],
            auth_rules=[
                LensRule(
                    id="DS-A001",
                    domain=SecurityStepDomain.AUTH_AUTHZ,
                    name="Service Account Security",
                    description="Review service account and API key management",
                    severity_default="high",
                    check_guidance=[
                        "Check for overly permissive service accounts",
                        "Verify API key rotation policies",
                        "Review cloud IAM role configurations",
                    ],
                ),
                LensRule(
                    id="DS-A002",
                    domain=SecurityStepDomain.AUTH_AUTHZ,
                    name="CI/CD Authentication",
                    description="Review CI/CD authentication mechanisms",
                    severity_default="high",
                    check_guidance=[
                        "Verify OIDC usage for cloud provider auth",
                        "Check for static credentials in pipelines",
                        "Review GitHub/GitLab token permissions",
                    ],
                ),
            ],
            input_rules=[
                LensRule(
                    id="DS-I001",
                    domain=SecurityStepDomain.INPUT_VALIDATION,
                    name="Pipeline Injection",
                    description="Check for command injection in CI/CD pipelines",
                    severity_default="critical",
                    check_guidance=[
                        "Review dynamic command construction in workflows",
                        "Check for user-controlled inputs in pipelines",
                        "Verify script injection protections",
                    ],
                ),
            ],
            owasp_rules=[
                LensRule(
                    id="DS-O001",
                    domain=SecurityStepDomain.OWASP_TOP_10,
                    name="Vulnerable Components (A06)",
                    description="OWASP A06 - Vulnerable and Outdated Components",
                    severity_default="high",
                    check_guidance=[
                        "Check for automated dependency scanning",
                        "Verify container image scanning",
                        "Review base image update policies",
                    ],
                ),
                LensRule(
                    id="DS-O002",
                    domain=SecurityStepDomain.OWASP_TOP_10,
                    name="Security Misconfiguration (A05)",
                    description="OWASP A05 - Security Misconfiguration",
                    severity_default="high",
                    check_guidance=[
                        "Review default configurations",
                        "Check for debug mode in production",
                        "Verify security headers configuration",
                    ],
                ),
            ],
            dependency_rules=[
                LensRule(
                    id="DS-D001",
                    domain=SecurityStepDomain.DEPENDENCIES,
                    name="Hardcoded Secrets",
                    description="Detect hardcoded secrets in codebase",
                    severity_default="critical",
                    check_guidance=[
                        "Search for API keys, tokens, passwords in code",
                        "Check for secrets in configuration files",
                        "Review .env files for committed secrets",
                        "Look for base64-encoded credentials",
                    ],
                ),
                LensRule(
                    id="DS-D002",
                    domain=SecurityStepDomain.DEPENDENCIES,
                    name="Dependency Pinning",
                    description="Verify dependency version pinning",
                    severity_default="high",
                    check_guidance=[
                        "Check for lockfile presence (package-lock.json, yarn.lock)",
                        "Verify exact version pinning in manifests",
                        "Review Docker base image tags",
                    ],
                ),
                LensRule(
                    id="DS-D003",
                    domain=SecurityStepDomain.DEPENDENCIES,
                    name="Supply Chain Security",
                    description="Review supply chain security practices",
                    severity_default="high",
                    check_guidance=[
                        "Check for Dependabot/Renovate configuration",
                        "Verify package integrity checks",
                        "Review private registry usage",
                        "Check for typosquatting risks",
                    ],
                ),
                LensRule(
                    id="DS-D004",
                    domain=SecurityStepDomain.DEPENDENCIES,
                    name="Container Security",
                    description="Review container image security",
                    severity_default="high",
                    check_guidance=[
                        "Check for root user in containers",
                        "Verify minimal base images",
                        "Review secrets in Dockerfile layers",
                        "Check for image scanning in CI/CD",
                    ],
                ),
            ],
            compliance_rules=[
                LensRule(
                    id="DS-C001",
                    domain=SecurityStepDomain.COMPLIANCE,
                    name="Audit Logging",
                    description="Verify security audit logging",
                    severity_default="medium",
                    check_guidance=[
                        "Check for security event logging",
                        "Verify log integrity protections",
                        "Review log retention policies",
                    ],
                ),
                LensRule(
                    id="DS-C002",
                    domain=SecurityStepDomain.COMPLIANCE,
                    name="Security Scanning Integration",
                    description="Verify security scanning in pipelines",
                    severity_default="medium",
                    check_guidance=[
                        "Check for SAST tools in CI/CD",
                        "Verify DAST integration",
                        "Review secret scanning configuration",
                    ],
                ),
            ],
        )
