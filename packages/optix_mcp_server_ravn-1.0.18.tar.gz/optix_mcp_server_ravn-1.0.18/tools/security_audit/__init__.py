"""Security audit tool for multi-step security analysis workflow.

Supports specialized lens variations:
- backend: Senior Backend Engineer perspective
- frontend: Senior Frontend Engineer perspective
- devsecops: DevSecOps Engineer perspective
- compliance: Compliance/Privacy Officer perspective
- comprehensive: Full security review (default)
"""

from tools.security_audit.domains import SecurityLens, SecurityStepDomain
from tools.security_audit.finding import SecurityFinding
from tools.security_audit.guidance import SecurityAuditGuidance, get_step_guidance
from tools.security_audit.lenses import (
    BaseLens,
    LensConfig,
    LensRule,
    get_lens,
    get_lens_config,
    list_available_lenses,
)
from tools.security_audit.report import AuditReportGenerator
from tools.security_audit.severity import Severity
from tools.security_audit.tool import SecurityAuditTool

__all__ = [
    "AuditReportGenerator",
    "SecurityAuditGuidance",
    "SecurityAuditTool",
    "SecurityLens",
    "SecurityStepDomain",
    "SecurityFinding",
    "Severity",
    "get_step_guidance",
    "BaseLens",
    "LensConfig",
    "LensRule",
    "get_lens",
    "get_lens_config",
    "list_available_lenses",
]
