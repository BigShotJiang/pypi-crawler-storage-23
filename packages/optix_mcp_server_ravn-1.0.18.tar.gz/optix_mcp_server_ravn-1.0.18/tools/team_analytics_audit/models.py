from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class FileChange:
    file_path: str
    additions: int
    deletions: int
    is_binary: bool = False


@dataclass
class RawCommit:
    hash: str
    author_name: str
    author_email: str
    timestamp: datetime
    subject: str
    parent_hashes: list[str]
    files_changed: list[FileChange]
    is_merge: bool
    co_authors: list[str] = field(default_factory=list)


@dataclass
class QualitySignals:
    conventional_commit_rate: float
    avg_message_length: float
    bulk_commit_count: int
    trivial_commit_count: int
    revert_count: int
    fixup_count: int
    atomic_commit_rate: float


@dataclass
class CollaborationData:
    co_authored_commits: int
    shared_file_authors: dict[str, int]
    cross_area_commits: int
    merge_commits: int


@dataclass
class ContributorProfile:
    name: str
    email: str
    commit_count: int
    lines_added: int
    lines_deleted: int
    files_touched: set[str]
    directories_touched: set[str]
    areas_of_impact: dict[str, int]
    commit_sizes: list[int]
    avg_commit_size: float
    quality_signals: QualitySignals
    collaboration: CollaborationData
    weekly_activity: dict[str, int]


@dataclass
class AreaHealth:
    path: str
    bus_factor: int
    primary_owner: str
    owner_percentage: float
    total_commits: int
    contributors: list[str]
    is_knowledge_silo: bool


@dataclass
class SustainabilitySignals:
    weekday_distribution: dict[int, int]
    hour_distribution: dict[int, int]
    weekend_commit_rate: float
    late_night_commit_rate: float


@dataclass
class TeamHealthDiagnostic:
    overall_bus_factor: int
    workload_gini_index: float
    knowledge_silos: list[AreaHealth]
    health_status: str
    sustainability_signals: SustainabilitySignals


@dataclass
class ComparisonDelta:
    commit_count_delta: float
    contributor_count_delta: float
    avg_commit_size_delta: float
    collaboration_delta: float


@dataclass
class VelocityTrend:
    weekly_commits: dict[str, int]
    weekly_contributors: dict[str, int]
    trajectory: str
    comparison_delta: ComparisonDelta | None = None


@dataclass
class AuditStepResult:
    name: str
    status: str
    skip_reason: str | None
    duration_ms: int

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "status": self.status,
            "skip_reason": self.skip_reason,
            "duration_ms": self.duration_ms,
        }


@dataclass
class TeamAuditResult:
    repository_name: str
    period_start: datetime
    period_end: datetime
    generated_at: datetime
    steps_executed: list[AuditStepResult]
    total_commits: int
    contributors: list[ContributorProfile]
    area_health: list[AreaHealth]
    team_health: TeamHealthDiagnostic
    velocity: VelocityTrend
    recommendations: list[str]


@dataclass
class FileWriteInstructions:
    target_path: str
    content: str
    create_directory: bool
    overwrite_strategy: str

    def to_dict(self) -> dict:
        return {
            "target_path": self.target_path,
            "content": self.content,
            "create_directory": self.create_directory,
            "overwrite_strategy": self.overwrite_strategy,
        }


@dataclass
class TeamAuditResponse:
    report_content: str
    report_path: str
    file_write_instructions: FileWriteInstructions
    consolidated_summary: dict
    steps_executed: list[AuditStepResult]

    def to_dict(self) -> dict:
        return {
            "report_content": self.report_content,
            "report_path": self.report_path,
            "file_write_instructions": self.file_write_instructions.to_dict(),
            "consolidated_summary": self.consolidated_summary,
            "steps_executed": [s.to_dict() for s in self.steps_executed],
        }
