from __future__ import annotations
import re
from datetime import datetime, timedelta, timezone


DEFAULT_DAYS = 30
LAST_N_DAYS_PATTERN = re.compile(r"^last_(\d+)_days$")
DATE_RANGE_PATTERN = re.compile(
    r"^(\d{4}-\d{2}-\d{2})\.\.(\d{4}-\d{2}-\d{2})$"
)


class PeriodParser:
    def parse(self, period: str | None) -> tuple[datetime, datetime]:
        if period is None:
            return self._last_n_days(DEFAULT_DAYS)

        match = LAST_N_DAYS_PATTERN.match(period)
        if match:
            n = int(match.group(1))
            return self._last_n_days(n)

        match = DATE_RANGE_PATTERN.match(period)
        if match:
            return self._date_range(match.group(1), match.group(2))

        raise ValueError(
            f"Invalid period format. Expected: YYYY-MM-DD..YYYY-MM-DD "
            f"or last_N_days"
        )

    def _last_n_days(self, n: int) -> tuple[datetime, datetime]:
        end = datetime.now(timezone.utc).replace(
            hour=23, minute=59, second=59, microsecond=0
        )
        start = (end - timedelta(days=n - 1)).replace(
            hour=0, minute=0, second=0, microsecond=0
        )
        return start, end

    def _date_range(
        self, start_str: str, end_str: str
    ) -> tuple[datetime, datetime]:
        start = datetime.strptime(start_str, "%Y-%m-%d").replace(
            tzinfo=timezone.utc
        )
        end = datetime.strptime(end_str, "%Y-%m-%d").replace(
            hour=23, minute=59, second=59, tzinfo=timezone.utc
        )
        if start > end:
            raise ValueError(
                f"Invalid period format. Expected: YYYY-MM-DD..YYYY-MM-DD "
                f"or last_N_days"
            )
        return start, end
