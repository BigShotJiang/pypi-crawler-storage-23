from __future__ import annotations

import os
import subprocess
import time
from datetime import datetime
from pathlib import Path

from tools.team_analytics_audit.analyzer import TeamAnalyzer
from tools.team_analytics_audit.collector import GitDataCollector
from tools.team_analytics_audit.models import (
    AuditStepResult,
    FileWriteInstructions,
    TeamAuditResponse,
    TeamAuditResult,
)
from tools.team_analytics_audit.period import PeriodParser
from tools.team_analytics_audit.report import TeamAuditReportGenerator

REPORT_FILENAME = "TEAM_AUDIT_REPORT.md"
STEP_NAMES = [
    "Collect",
    "Measure",
    "Quality",
    "Collaborate",
    "Diagnose",
    "Trends",
    "Report",
]


def _make_step(
    name: str,
    start: float,
    status: str = "executed",
    skip_reason: str | None = None,
) -> AuditStepResult:
    duration = int((time.time() - start) * 1000)
    return AuditStepResult(
        name=name,
        status=status,
        skip_reason=skip_reason,
        duration_ms=duration,
    )


def _resolve_root(project_root_path: str | None) -> str:
    return project_root_path or os.getcwd()


def _build_consolidated_summary(
    result: TeamAuditResult,
) -> dict:
    executed = sum(
        1 for s in result.steps_executed if s.status == "executed"
    )
    skipped = sum(
        1 for s in result.steps_executed if s.status == "skipped"
    )
    return {
        "repository": result.repository_name,
        "period": (
            f"{result.period_start.strftime('%Y-%m-%d')}.."
            f"{result.period_end.strftime('%Y-%m-%d')}"
        ),
        "total_commits": result.total_commits,
        "active_contributors": len(result.contributors),
        "health_status": result.team_health.health_status,
        "bus_factor": result.team_health.overall_bus_factor,
        "workload_gini_index": result.team_health.workload_gini_index,
        "knowledge_silos_count": len(result.team_health.knowledge_silos),
        "trajectory": result.velocity.trajectory,
        "steps_executed": executed,
        "steps_skipped": skipped,
    }


class TeamAnalyticsAuditTool:
    @property
    def name(self) -> str:
        return "team_analytics_audit"

    @property
    def description(self) -> str:
        return "Audit team contribution patterns from git history"

    def execute(
        self,
        period: str | None = None,
        compare_period: str | None = None,
        author: str | None = None,
        team_members: list[str] | None = None,
        project_root_path: str | None = None,
    ) -> TeamAuditResponse:
        root = _resolve_root(project_root_path)
        steps: list[AuditStepResult] = []
        period_parser = PeriodParser()
        collector = GitDataCollector()
        analyzer = TeamAnalyzer()
        report_generator = TeamAuditReportGenerator()

        try:
            period_start, period_end = period_parser.parse(period)
        except ValueError:
            raise ValueError("invalid_period")

        t = time.time()
        try:
            commits = collector.collect(
                root=root,
                since=period_start,
                until=period_end,
                author=author,
                team_members=team_members,
            )
        except ValueError as exc:
            raise ValueError(str(exc))
        except (subprocess.TimeoutExpired, FileNotFoundError) as exc:
            raise RuntimeError(f"git_error: {exc}")
        steps.append(_make_step("Collect", t))

        if not commits:
            raise ValueError("no_commits")

        compare_commits = None
        if compare_period is not None:
            try:
                compare_start, compare_end = period_parser.parse(
                    compare_period
                )
            except ValueError:
                raise ValueError("invalid_period")
            compare_commits = collector.collect(
                root=root,
                since=compare_start,
                until=compare_end,
            )

        repo_name = Path(root).name

        t = time.time()
        result = analyzer.analyze(
            commits=commits,
            repository_name=repo_name,
            period_start=period_start,
            period_end=period_end,
            compare_commits=compare_commits,
        )
        for step_name in STEP_NAMES[1:-1]:
            steps.append(_make_step(step_name, t))

        compare_step_status = (
            "executed" if compare_period else "skipped"
        )
        compare_reason = (
            None if compare_period else "no compare_period provided"
        )
        for i, step in enumerate(steps[1:], 1):
            if step.name == "Trends":
                steps[i] = AuditStepResult(
                    name="Trends",
                    status=compare_step_status,
                    skip_reason=compare_reason,
                    duration_ms=step.duration_ms,
                )

        result.steps_executed = steps

        t = time.time()
        report_content = report_generator.generate(result, author)
        steps.append(_make_step("Report", t))
        result.steps_executed = steps

        report_path = str(Path(root) / REPORT_FILENAME)
        instructions = FileWriteInstructions(
            target_path=report_path,
            content=report_content,
            create_directory=True,
            overwrite_strategy="overwrite",
        )
        summary = _build_consolidated_summary(result)

        return TeamAuditResponse(
            report_content=report_content,
            report_path=report_path,
            file_write_instructions=instructions,
            consolidated_summary=summary,
            steps_executed=steps,
        )


