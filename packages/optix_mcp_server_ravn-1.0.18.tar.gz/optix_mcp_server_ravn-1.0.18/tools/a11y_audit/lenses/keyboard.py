"""Keyboard-Only User lens for Accessibility Audit.

Focuses on accessibility from a keyboard-only user's perspective:
- Tab order and navigation
- Focus management
- Keyboard shortcuts
- Keyboard traps
"""

from tools.a11y_audit.domains import A11yLens, AccessibilityStepDomain
from tools.a11y_audit.lenses.base import BaseLens, LensConfig, LensRule


class KeyboardLens(BaseLens):
    """Keyboard-Only User accessibility perspective.

    Examines code from the viewpoint of a user navigating without a mouse,
    focusing on keyboard accessibility and navigation.
    """

    @property
    def lens_type(self) -> A11yLens:
        return A11yLens.KEYBOARD

    def get_config(self) -> LensConfig:
        return LensConfig(
            lens=A11yLens.KEYBOARD,
            display_name="Keyboard-Only User",
            description="Tab order, focus management, keyboard shortcuts, traps",
            structure_rules=[
                LensRule(
                    id="KB-S001",
                    domain=AccessibilityStepDomain.STRUCTURE,
                    name="Interactive Element Discovery",
                    description="Identify all interactive elements requiring keyboard access",
                    wcag_criterion="2.1.1",
                    wcag_level="A",
                    severity_default="info",
                    check_guidance=[
                        "Identify all buttons, links, and form controls",
                        "Find custom interactive components",
                        "Map drag-and-drop and hover interactions",
                    ],
                ),
            ],
            aria_rules=[
                LensRule(
                    id="KB-A001",
                    domain=AccessibilityStepDomain.ARIA_LABELS,
                    name="Widget Keyboard Patterns",
                    description="Verify ARIA widgets follow keyboard patterns",
                    wcag_criterion="2.1.1",
                    wcag_level="A",
                    severity_default="high",
                    check_guidance=[
                        "Check tabs use arrow keys, not tab",
                        "Verify menus support arrow navigation",
                        "Check dialog escape key handling",
                    ],
                ),
            ],
            keyboard_rules=[
                LensRule(
                    id="KB-K001",
                    domain=AccessibilityStepDomain.KEYBOARD_NAV,
                    name="Keyboard Accessibility",
                    description="Verify all functionality available via keyboard",
                    wcag_criterion="2.1.1",
                    wcag_level="A",
                    severity_default="critical",
                    check_guidance=[
                        "Check all interactive elements are focusable",
                        "Verify click handlers have keyboard equivalents",
                        "Check hover effects have focus equivalents",
                        "Test all functionality without mouse",
                    ],
                ),
                LensRule(
                    id="KB-K002",
                    domain=AccessibilityStepDomain.KEYBOARD_NAV,
                    name="Tab Order",
                    description="Verify logical tab order",
                    wcag_criterion="2.4.3",
                    wcag_level="A",
                    severity_default="high",
                    check_guidance=[
                        "Check tab order follows reading order",
                        "Verify no positive tabindex values",
                        "Check tabindex=-1 used appropriately",
                    ],
                ),
                LensRule(
                    id="KB-K003",
                    domain=AccessibilityStepDomain.KEYBOARD_NAV,
                    name="Keyboard Traps",
                    description="Verify no keyboard traps exist",
                    wcag_criterion="2.1.2",
                    wcag_level="A",
                    severity_default="critical",
                    check_guidance=[
                        "Check user can tab out of all components",
                        "Verify modal dialogs can be closed with Escape",
                        "Check embedded content (iframes) can be exited",
                    ],
                ),
                LensRule(
                    id="KB-K004",
                    domain=AccessibilityStepDomain.KEYBOARD_NAV,
                    name="Skip Links",
                    description="Verify skip navigation links exist",
                    wcag_criterion="2.4.1",
                    wcag_level="A",
                    severity_default="medium",
                    check_guidance=[
                        "Check for 'skip to main content' link",
                        "Verify skip link is first focusable element",
                        "Check skip link becomes visible on focus",
                    ],
                ),
            ],
            focus_rules=[
                LensRule(
                    id="KB-F001",
                    domain=AccessibilityStepDomain.FOCUS_MANAGEMENT,
                    name="Focus Visibility",
                    description="Verify focus indicators are visible",
                    wcag_criterion="2.4.7",
                    wcag_level="AA",
                    severity_default="critical",
                    check_guidance=[
                        "Check all focusable elements have visible focus",
                        "Verify focus is not hidden with outline: none",
                        "Check custom focus styles have sufficient contrast",
                    ],
                ),
                LensRule(
                    id="KB-F002",
                    domain=AccessibilityStepDomain.FOCUS_MANAGEMENT,
                    name="Focus Management",
                    description="Verify proper focus management for dynamic content",
                    wcag_criterion="2.4.3",
                    wcag_level="A",
                    severity_default="high",
                    check_guidance=[
                        "Check focus moves to dialogs when opened",
                        "Verify focus returns to trigger when dialog closes",
                        "Check focus trap in modal dialogs",
                        "Verify focus on route changes in SPAs",
                    ],
                ),
                LensRule(
                    id="KB-F003",
                    domain=AccessibilityStepDomain.FOCUS_MANAGEMENT,
                    name="Focus Order",
                    description="Verify focus order preserves meaning",
                    wcag_criterion="2.4.3",
                    wcag_level="A",
                    severity_default="medium",
                    check_guidance=[
                        "Check focus order matches visual order",
                        "Verify no confusing focus jumps",
                        "Check dynamically added content focus handling",
                    ],
                ),
            ],
            color_rules=[],
            semantic_rules=[
                LensRule(
                    id="KB-SM001",
                    domain=AccessibilityStepDomain.SEMANTIC_HTML,
                    name="Native Interactive Elements",
                    description="Verify use of native interactive elements",
                    wcag_criterion="2.1.1",
                    wcag_level="A",
                    severity_default="medium",
                    check_guidance=[
                        "Check buttons use <button> not <div onclick>",
                        "Verify links use <a> with href",
                        "Check for semantic form elements",
                    ],
                ),
            ],
        )
