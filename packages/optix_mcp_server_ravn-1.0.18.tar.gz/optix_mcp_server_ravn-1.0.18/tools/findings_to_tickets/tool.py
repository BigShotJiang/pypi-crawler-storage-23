import logging
import os
from pathlib import Path

from tools.findings_to_tickets.formatter import (
    format_finding_description,
    format_finding_title,
    severity_to_priority,
)
from tools.findings_to_tickets.models import Platform, TicketData, TicketResponse
from tools.history.reader import AuditSummary, HistoryReader

logger = logging.getLogger(__name__)


def _resolve_project_path(project_path: str | None = None) -> Path:
    if project_path:
        return Path(project_path)
    env_path = os.environ.get("OPTIX_PROJECT_PATH")
    if env_path:
        return Path(env_path)
    return Path.cwd()


class FindingsToTicketsTool:
    def __init__(self, history_reader: HistoryReader | None = None) -> None:
        self._custom_reader = history_reader

    def _get_history_reader(self, project_path: str | None = None) -> HistoryReader:
        if self._custom_reader is not None:
            return self._custom_reader
        base = _resolve_project_path(project_path)
        history_path = base / ".optix" / "history"
        logger.debug(f"HistoryReader path: {history_path}, exists: {history_path.exists()}")
        return HistoryReader(history_path)

    def list_audits(self, project_path: str | None = None) -> list[AuditSummary]:
        return self._get_history_reader(project_path).list_audits()

    def get_audit_findings(
        self,
        audit_dir_name: str,
        project_path: str | None = None,
    ) -> list[dict[str, object]]:
        reader = self._get_history_reader(project_path)
        audit_data = reader.get_audit(audit_dir_name)

        if audit_data is None:
            raise ValueError(
                f"Audit not found: {audit_dir_name} in {reader.base_dir}"
            )

        findings = audit_data.get("findings", [])
        if not isinstance(findings, list):
            logger.warning(f"Invalid findings format in {audit_dir_name}")
            return []

        result = []
        for i, finding in enumerate(findings):
            if not isinstance(finding, dict):
                continue
            if "id" not in finding:
                finding["id"] = f"finding-{i}"
            result.append(finding)

        return result

    def prepare_tickets(
        self,
        audit_dir_name: str,
        finding_ids: list[str],
        platform: Platform,
        project_path: str | None = None,
    ) -> TicketResponse:
        if not finding_ids:
            return TicketResponse(
                success=False,
                platform=platform.value,
                audit_dir_name=audit_dir_name,
                tickets=[],
                total_findings=0,
                selected_count=0,
                error="No findings selected",
            )

        try:
            all_findings = self.get_audit_findings(audit_dir_name, project_path)
        except ValueError as e:
            return TicketResponse(
                success=False,
                platform=platform.value,
                audit_dir_name=audit_dir_name,
                tickets=[],
                total_findings=0,
                selected_count=0,
                error=str(e),
            )

        reader = self._get_history_reader(project_path)
        audit_data = reader.get_audit(audit_dir_name)
        audit_info = {
            "lens": audit_data.get("lens", "security") if audit_data else "security",
            "date": audit_data.get("timestamp", "unknown")[:10] if audit_data else "unknown",
        }

        finding_ids_set = set(finding_ids)
        selected_findings = [f for f in all_findings if f.get("id") in finding_ids_set]

        if not selected_findings:
            return TicketResponse(
                success=False,
                platform=platform.value,
                audit_dir_name=audit_dir_name,
                tickets=[],
                total_findings=len(all_findings),
                selected_count=0,
                error="No matching findings found for the provided IDs",
            )

        tickets = []
        for finding in selected_findings:
            severity = str(finding.get("severity", "info"))
            category = str(finding.get("category", "Unknown"))

            ticket = TicketData(
                finding_id=str(finding.get("id", "")),
                title=format_finding_title(finding),
                description=format_finding_description(finding, audit_info),
                priority=severity_to_priority(severity, platform),
                labels=[audit_info["lens"], severity],
                severity=severity,
                category=category,
            )
            tickets.append(ticket)

        return TicketResponse(
            success=True,
            platform=platform.value,
            audit_dir_name=audit_dir_name,
            tickets=tickets,
            total_findings=len(all_findings),
            selected_count=len(tickets),
        )
