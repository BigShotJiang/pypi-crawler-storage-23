"""FindingCategory enum for categorizing code quality findings."""

from enum import Enum


class PrincipalLens(str, Enum):
    """Specialized lens perspectives for Principal Engineer audits.

    Each lens focuses on code quality aspects relevant to a specific persona:
    - FRONTEND: UI components, state management, rendering patterns
    - BACKEND: API design, data access, business logic patterns
    - PERFORMANCE: Algorithms, bottlenecks, resource optimization
    - TECHLEAD: Architecture decisions, team conventions, patterns
    - COMPREHENSIVE: Full code quality review (default)
    """

    FRONTEND = "frontend"
    BACKEND = "backend"
    PERFORMANCE = "performance"
    TECHLEAD = "techlead"
    COMPREHENSIVE = "comprehensive"

    @classmethod
    def from_string(cls, value: str | None) -> "PrincipalLens":
        """Convert string to PrincipalLens enum.

        Args:
            value: Lens name string or None

        Returns:
            PrincipalLens enum value, defaults to COMPREHENSIVE
        """
        if not value:
            return cls.COMPREHENSIVE
        normalized = value.lower().strip()
        for lens in cls:
            if lens.value == normalized:
                return lens
        return cls.COMPREHENSIVE

    @property
    def display_name(self) -> str:
        """Human-readable display name for the lens."""
        names = {
            "frontend": "Frontend Developer",
            "backend": "Backend Developer",
            "performance": "Performance Engineer",
            "techlead": "Tech Lead",
            "comprehensive": "Comprehensive",
        }
        return names.get(self.value, self.value.title())

    @property
    def description(self) -> str:
        """Description of the lens focus area."""
        descriptions = {
            "frontend": "UI components, state management, rendering patterns",
            "backend": "API design, data access, business logic patterns",
            "performance": "Algorithms, bottlenecks, resource optimization",
            "techlead": "Architecture decisions, team conventions, patterns",
            "comprehensive": "Full code quality review covering all domains",
        }
        return descriptions.get(self.value, "")


class FindingCategory(Enum):
    """Categories of code quality findings.

    Each category corresponds to a specific analysis domain in the 5-step workflow:
    - Step 1: COMPLEXITY (FR-001)
    - Step 2: DRY_VIOLATION (FR-002)
    - Step 3: COUPLING (FR-003)
    - Step 4: SEPARATION_OF_CONCERNS (FR-004)
    - Step 5: MAINTAINABILITY_RISK (FR-005)
    """

    COMPLEXITY = "complexity"
    DRY_VIOLATION = "dry_violation"
    COUPLING = "coupling"
    SEPARATION_OF_CONCERNS = "separation_of_concerns"
    MAINTAINABILITY_RISK = "maintainability_risk"
