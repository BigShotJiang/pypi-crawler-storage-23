"""Comprehensive lens for Principal Audit.

Combines the most important rules from all specialized lenses to provide
a complete code quality review covering all perspectives.
"""

from tools.principal_audit.category import FindingCategory, PrincipalLens
from tools.principal_audit.lenses.base import BaseLens, LensConfig, LensRule


class ComprehensiveLens(BaseLens):
    """Comprehensive code quality perspective.

    Combines key rules from Frontend, Backend, Performance, and TechLead
    lenses to provide a full code quality review.
    """

    @property
    def lens_type(self) -> PrincipalLens:
        return PrincipalLens.COMPREHENSIVE

    def get_config(self) -> LensConfig:
        return LensConfig(
            lens=PrincipalLens.COMPREHENSIVE,
            display_name="Comprehensive",
            description="Full code quality review covering all domains",
            complexity_rules=[
                LensRule(
                    id="COMP-C001",
                    category=FindingCategory.COMPLEXITY,
                    name="Cyclomatic Complexity",
                    description="Functions exceeding complexity thresholds",
                    severity_default="high",
                    check_guidance=[
                        "Calculate cyclomatic complexity for all functions",
                        "Flag functions with complexity >10",
                        "Identify critical functions with complexity >20",
                        "Document affected functions with line numbers",
                    ],
                ),
                LensRule(
                    id="COMP-C002",
                    category=FindingCategory.COMPLEXITY,
                    name="Nesting Depth",
                    description="Deeply nested control structures",
                    severity_default="medium",
                    check_guidance=[
                        "Find code with nesting >4 levels deep",
                        "Look for nested callbacks/promises",
                        "Identify nested conditionals",
                        "Check for early return opportunities",
                    ],
                ),
                LensRule(
                    id="COMP-C003",
                    category=FindingCategory.COMPLEXITY,
                    name="God Objects",
                    description="Classes/modules with too many responsibilities",
                    severity_default="critical",
                    check_guidance=[
                        "Find classes with >10 public methods",
                        "Look for files >500 lines",
                        "Identify modules with >20 exports",
                        "Check for mixed domain responsibilities",
                    ],
                ),
            ],
            dry_rules=[
                LensRule(
                    id="COMP-D001",
                    category=FindingCategory.DRY_VIOLATION,
                    name="Code Duplication",
                    description="Syntactically similar code blocks",
                    severity_default="high",
                    check_guidance=[
                        "Find code blocks with >80% similarity",
                        "Look for copy-paste patterns",
                        "Identify repeated logic sequences",
                        "Document duplicate locations with file paths",
                    ],
                ),
                LensRule(
                    id="COMP-D002",
                    category=FindingCategory.DRY_VIOLATION,
                    name="Repeated Patterns",
                    description="Same pattern implemented differently",
                    severity_default="medium",
                    check_guidance=[
                        "Find similar function implementations",
                        "Look for parallel class hierarchies",
                        "Identify repeated error handling",
                        "Check for missing shared utilities",
                    ],
                ),
            ],
            coupling_rules=[
                LensRule(
                    id="COMP-CP001",
                    category=FindingCategory.COUPLING,
                    name="Circular Dependencies",
                    description="Modules with circular import chains",
                    severity_default="critical",
                    check_guidance=[
                        "Build module dependency graph",
                        "Detect circular dependencies using DFS",
                        "Identify dependency chain lengths",
                        "Document circular paths",
                    ],
                ),
                LensRule(
                    id="COMP-CP002",
                    category=FindingCategory.COUPLING,
                    name="High Coupling",
                    description="Modules with excessive dependencies",
                    severity_default="high",
                    check_guidance=[
                        "Count afferent/efferent coupling",
                        "Find modules with >5 direct dependencies",
                        "Calculate instability metric",
                        "Identify hub modules",
                    ],
                ),
                LensRule(
                    id="COMP-CP003",
                    category=FindingCategory.COUPLING,
                    name="Tight External Coupling",
                    description="Code tightly coupled to external services",
                    severity_default="medium",
                    check_guidance=[
                        "Find direct HTTP/DB calls in business logic",
                        "Look for missing abstraction layers",
                        "Identify vendor lock-in risks",
                        "Check for missing interface boundaries",
                    ],
                ),
            ],
            separation_rules=[
                LensRule(
                    id="COMP-S001",
                    category=FindingCategory.SEPARATION_OF_CONCERNS,
                    name="Mixed Responsibilities",
                    description="Modules mixing multiple concerns",
                    severity_default="high",
                    check_guidance=[
                        "Find business logic in UI layer",
                        "Look for data access in controllers",
                        "Identify infrastructure in domain",
                        "Check for presentation in services",
                    ],
                ),
                LensRule(
                    id="COMP-S002",
                    category=FindingCategory.SEPARATION_OF_CONCERNS,
                    name="Layer Violations",
                    description="Code not following layer architecture",
                    severity_default="high",
                    check_guidance=[
                        "Analyze layer boundary violations",
                        "Find imports crossing layer boundaries",
                        "Identify missing service layer",
                        "Check for repository pattern usage",
                    ],
                ),
            ],
            maintainability_rules=[
                LensRule(
                    id="COMP-M001",
                    category=FindingCategory.MAINTAINABILITY_RISK,
                    name="Large Files",
                    description="Files exceeding reasonable length",
                    severity_default="medium",
                    check_guidance=[
                        "Find files >500 lines",
                        "Identify files requiring scrolling context",
                        "Look for extraction opportunities",
                        "Check file cohesion",
                    ],
                ),
                LensRule(
                    id="COMP-M002",
                    category=FindingCategory.MAINTAINABILITY_RISK,
                    name="Long Parameter Lists",
                    description="Functions with too many parameters",
                    severity_default="medium",
                    check_guidance=[
                        "Find functions with >5 parameters",
                        "Look for object parameter opportunities",
                        "Identify related parameter groups",
                        "Check for builder pattern needs",
                    ],
                ),
                LensRule(
                    id="COMP-M003",
                    category=FindingCategory.MAINTAINABILITY_RISK,
                    name="Magic Values",
                    description="Hardcoded numbers and strings",
                    severity_default="low",
                    check_guidance=[
                        "Find hardcoded numeric values",
                        "Look for embedded string literals",
                        "Identify missing named constants",
                        "Check for configuration extraction",
                    ],
                ),
            ],
        )
