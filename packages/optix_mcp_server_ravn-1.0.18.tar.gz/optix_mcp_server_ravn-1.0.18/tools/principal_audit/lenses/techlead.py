"""Tech Lead lens for Principal Audit.

Focuses on architecture decisions, team conventions, patterns,
and overall codebase health from a leadership perspective.
"""

from tools.principal_audit.category import FindingCategory, PrincipalLens
from tools.principal_audit.lenses.base import BaseLens, LensConfig, LensRule


class TechLeadLens(BaseLens):
    """Tech Lead perspective for code quality analysis.

    Focuses on:
    - Architectural consistency
    - Team conventions and standards
    - Technical debt tracking
    - Code review concerns
    """

    @property
    def lens_type(self) -> PrincipalLens:
        return PrincipalLens.TECHLEAD

    def get_config(self) -> LensConfig:
        return LensConfig(
            lens=PrincipalLens.TECHLEAD,
            display_name="Tech Lead",
            description="Architecture decisions, team conventions, patterns",
            complexity_rules=[
                LensRule(
                    id="TL-C001",
                    category=FindingCategory.COMPLEXITY,
                    name="Architectural Complexity",
                    description="Module or service too large for single ownership",
                    severity_default="high",
                    check_guidance=[
                        "Check module file count (>50 files is concerning)",
                        "Look for unclear module boundaries",
                        "Identify services handling multiple domains",
                        "Find modules requiring multiple team expertise",
                    ],
                ),
                LensRule(
                    id="TL-C002",
                    category=FindingCategory.COMPLEXITY,
                    name="Onboarding Barrier",
                    description="Code too complex for new team members",
                    severity_default="medium",
                    check_guidance=[
                        "Find files with >500 lines",
                        "Look for missing documentation on complex flows",
                        "Identify undocumented domain concepts",
                        "Check for absent architecture decision records",
                    ],
                ),
                LensRule(
                    id="TL-C003",
                    category=FindingCategory.COMPLEXITY,
                    name="Test Complexity Mismatch",
                    description="Complex code with insufficient test coverage",
                    severity_default="high",
                    check_guidance=[
                        "Find complex functions without tests",
                        "Look for critical paths with low coverage",
                        "Identify integration points without tests",
                        "Check for untested edge cases",
                    ],
                ),
            ],
            dry_rules=[
                LensRule(
                    id="TL-D001",
                    category=FindingCategory.DRY_VIOLATION,
                    name="Cross-Team Duplication",
                    description="Same logic implemented by different teams",
                    severity_default="high",
                    check_guidance=[
                        "Find similar utilities across modules",
                        "Look for duplicated domain models",
                        "Identify repeated integration patterns",
                        "Check for parallel implementations",
                    ],
                ),
                LensRule(
                    id="TL-D002",
                    category=FindingCategory.DRY_VIOLATION,
                    name="Missing Shared Libraries",
                    description="Common patterns not extracted to shared code",
                    severity_default="medium",
                    check_guidance=[
                        "Find repeated error handling patterns",
                        "Look for duplicated logging setup",
                        "Identify repeated configuration loading",
                        "Check for missing common utilities",
                    ],
                ),
                LensRule(
                    id="TL-D003",
                    category=FindingCategory.DRY_VIOLATION,
                    name="Inconsistent Patterns",
                    description="Different approaches to the same problem",
                    severity_default="medium",
                    check_guidance=[
                        "Find varying authentication patterns",
                        "Look for inconsistent API patterns",
                        "Identify multiple state management approaches",
                        "Check for varying error handling styles",
                    ],
                ),
            ],
            coupling_rules=[
                LensRule(
                    id="TL-CP001",
                    category=FindingCategory.COUPLING,
                    name="Service Boundary Violation",
                    description="Services directly accessing another's data",
                    severity_default="critical",
                    check_guidance=[
                        "Find cross-service database access",
                        "Look for shared tables between services",
                        "Identify direct internal API dependencies",
                        "Check for missing API contracts",
                    ],
                ),
                LensRule(
                    id="TL-CP002",
                    category=FindingCategory.COUPLING,
                    name="Monolith Coupling",
                    description="Tightly coupled components preventing extraction",
                    severity_default="high",
                    check_guidance=[
                        "Find circular dependencies between modules",
                        "Look for shared global state",
                        "Identify core modules with 100+ dependents",
                        "Check for missing interface boundaries",
                    ],
                ),
                LensRule(
                    id="TL-CP003",
                    category=FindingCategory.COUPLING,
                    name="Third-Party Lock-in",
                    description="Deep coupling to specific vendor/framework",
                    severity_default="medium",
                    check_guidance=[
                        "Find vendor-specific code in core domain",
                        "Look for missing abstraction layers",
                        "Identify framework code in business logic",
                        "Check for portability concerns",
                    ],
                ),
            ],
            separation_rules=[
                LensRule(
                    id="TL-S001",
                    category=FindingCategory.SEPARATION_OF_CONCERNS,
                    name="Layer Boundary Violation",
                    description="Code not following established architecture",
                    severity_default="high",
                    check_guidance=[
                        "Find presentation imports in data layer",
                        "Look for data layer calls from controllers",
                        "Identify cross-layer dependencies",
                        "Check for missing service layer",
                    ],
                ),
                LensRule(
                    id="TL-S002",
                    category=FindingCategory.SEPARATION_OF_CONCERNS,
                    name="Feature Flag Pollution",
                    description="Feature flags scattered throughout codebase",
                    severity_default="medium",
                    check_guidance=[
                        "Find feature checks in multiple layers",
                        "Look for nested feature conditions",
                        "Identify old feature flags not removed",
                        "Check for feature flag management",
                    ],
                ),
                LensRule(
                    id="TL-S003",
                    category=FindingCategory.SEPARATION_OF_CONCERNS,
                    name="Config-Code Mixing",
                    description="Configuration embedded in code",
                    severity_default="high",
                    check_guidance=[
                        "Find hardcoded environment values",
                        "Look for embedded connection strings",
                        "Identify hardcoded feature settings",
                        "Check for missing config externalization",
                    ],
                ),
            ],
            maintainability_rules=[
                LensRule(
                    id="TL-M001",
                    category=FindingCategory.MAINTAINABILITY_RISK,
                    name="Technical Debt Accumulation",
                    description="TODO/FIXME/HACK comments without tracking",
                    severity_default="medium",
                    check_guidance=[
                        "Count TODO/FIXME/HACK comments",
                        "Look for dated technical debt notes",
                        "Identify workarounds without tickets",
                        "Check for missing debt documentation",
                    ],
                ),
                LensRule(
                    id="TL-M002",
                    category=FindingCategory.MAINTAINABILITY_RISK,
                    name="Missing Documentation",
                    description="Critical code without documentation",
                    severity_default="high",
                    check_guidance=[
                        "Find undocumented public APIs",
                        "Look for missing README files",
                        "Identify undocumented config options",
                        "Check for missing architecture docs",
                    ],
                ),
                LensRule(
                    id="TL-M003",
                    category=FindingCategory.MAINTAINABILITY_RISK,
                    name="Outdated Dependencies",
                    description="Dependencies with known issues or EOL",
                    severity_default="high",
                    check_guidance=[
                        "Find deprecated package versions",
                        "Look for packages with security alerts",
                        "Identify unmaintained dependencies",
                        "Check for version compatibility issues",
                    ],
                ),
            ],
        )
