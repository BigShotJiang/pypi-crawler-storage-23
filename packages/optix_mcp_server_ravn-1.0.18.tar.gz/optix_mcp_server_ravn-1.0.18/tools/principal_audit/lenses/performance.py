"""Performance Engineer lens for Principal Audit.

Focuses on algorithmic complexity, bottlenecks, resource usage,
and performance-critical code patterns.
"""

from tools.principal_audit.category import FindingCategory, PrincipalLens
from tools.principal_audit.lenses.base import BaseLens, LensConfig, LensRule


class PerformanceLens(BaseLens):
    """Performance Engineer perspective for code quality analysis.

    Focuses on:
    - Algorithmic complexity (Big-O)
    - Memory and resource usage
    - I/O bottlenecks
    - Optimization opportunities
    """

    @property
    def lens_type(self) -> PrincipalLens:
        return PrincipalLens.PERFORMANCE

    def get_config(self) -> LensConfig:
        return LensConfig(
            lens=PrincipalLens.PERFORMANCE,
            display_name="Performance Engineer",
            description="Algorithms, bottlenecks, resource optimization",
            complexity_rules=[
                LensRule(
                    id="PERF-C001",
                    category=FindingCategory.COMPLEXITY,
                    name="Algorithmic Complexity",
                    description="O(n²) or worse algorithms in hot paths",
                    severity_default="critical",
                    check_guidance=[
                        "Find nested loops over collections",
                        "Look for O(n²) sorting/searching patterns",
                        "Identify recursive calls without memoization",
                        "Check for cartesian product operations",
                    ],
                ),
                LensRule(
                    id="PERF-C002",
                    category=FindingCategory.COMPLEXITY,
                    name="Unnecessary Iterations",
                    description="Multiple iterations where one would suffice",
                    severity_default="high",
                    check_guidance=[
                        "Find consecutive map/filter/reduce chains",
                        "Look for multiple loops over same data",
                        "Identify repeated array traversals",
                        "Check for loop fusion opportunities",
                    ],
                ),
                LensRule(
                    id="PERF-C003",
                    category=FindingCategory.COMPLEXITY,
                    name="Deep Recursion Risk",
                    description="Recursive functions without tail optimization",
                    severity_default="high",
                    check_guidance=[
                        "Find recursive functions on large datasets",
                        "Look for missing base case guards",
                        "Identify stack overflow risks",
                        "Check for iterative alternatives",
                    ],
                ),
            ],
            dry_rules=[
                LensRule(
                    id="PERF-D001",
                    category=FindingCategory.DRY_VIOLATION,
                    name="Repeated Computation",
                    description="Same expensive calculation done multiple times",
                    severity_default="high",
                    check_guidance=[
                        "Find repeated function calls with same args",
                        "Look for missing memoization",
                        "Identify recalculated derived values",
                        "Check for caching opportunities",
                    ],
                ),
                LensRule(
                    id="PERF-D002",
                    category=FindingCategory.DRY_VIOLATION,
                    name="Duplicate Data Fetching",
                    description="Same data fetched multiple times",
                    severity_default="critical",
                    check_guidance=[
                        "Find N+1 query patterns",
                        "Look for repeated API calls for same data",
                        "Identify missing data prefetching",
                        "Check for absent request coalescing",
                    ],
                ),
                LensRule(
                    id="PERF-D003",
                    category=FindingCategory.DRY_VIOLATION,
                    name="Repeated String Operations",
                    description="Inefficient string concatenation in loops",
                    severity_default="medium",
                    check_guidance=[
                        "Find string += in loops",
                        "Look for repeated regex compilation",
                        "Identify missing StringBuilder usage",
                        "Check for repeated parsing operations",
                    ],
                ),
            ],
            coupling_rules=[
                LensRule(
                    id="PERF-CP001",
                    category=FindingCategory.COUPLING,
                    name="Synchronous Blocking Calls",
                    description="Synchronous calls blocking async operations",
                    severity_default="critical",
                    check_guidance=[
                        "Find sync I/O in async code paths",
                        "Look for blocking HTTP calls",
                        "Identify sync file operations in handlers",
                        "Check for thread-blocking operations",
                    ],
                ),
                LensRule(
                    id="PERF-CP002",
                    category=FindingCategory.COUPLING,
                    name="Sequential External Calls",
                    description="External calls that could be parallelized",
                    severity_default="high",
                    check_guidance=[
                        "Find await chains for independent calls",
                        "Look for sequential HTTP requests",
                        "Identify missing Promise.all patterns",
                        "Check for parallel query opportunities",
                    ],
                ),
                LensRule(
                    id="PERF-CP003",
                    category=FindingCategory.COUPLING,
                    name="Memory Leak Coupling",
                    description="Objects holding references preventing GC",
                    severity_default="critical",
                    check_guidance=[
                        "Find event listeners not cleaned up",
                        "Look for closures capturing large objects",
                        "Identify missing cache eviction",
                        "Check for circular references",
                    ],
                ),
            ],
            separation_rules=[
                LensRule(
                    id="PERF-S001",
                    category=FindingCategory.SEPARATION_OF_CONCERNS,
                    name="Heavy Computation in Hot Path",
                    description="Expensive operations in critical code paths",
                    severity_default="critical",
                    check_guidance=[
                        "Find heavy processing in request handlers",
                        "Look for blocking operations in event loops",
                        "Identify serialization in tight loops",
                        "Check for missing async boundaries",
                    ],
                ),
                LensRule(
                    id="PERF-S002",
                    category=FindingCategory.SEPARATION_OF_CONCERNS,
                    name="I/O in Computation Logic",
                    description="I/O operations mixed with CPU-bound work",
                    severity_default="high",
                    check_guidance=[
                        "Find file reads in calculation functions",
                        "Look for network calls in algorithms",
                        "Identify database access in loops",
                        "Check for missing data loading phases",
                    ],
                ),
                LensRule(
                    id="PERF-S003",
                    category=FindingCategory.SEPARATION_OF_CONCERNS,
                    name="Logging in Performance Path",
                    description="Excessive logging in performance-critical code",
                    severity_default="medium",
                    check_guidance=[
                        "Find debug logging in tight loops",
                        "Look for string formatting in hot paths",
                        "Identify sync file writes for logs",
                        "Check for conditional log guards",
                    ],
                ),
            ],
            maintainability_rules=[
                LensRule(
                    id="PERF-M001",
                    category=FindingCategory.MAINTAINABILITY_RISK,
                    name="Missing Performance Bounds",
                    description="No limits on unbounded operations",
                    severity_default="high",
                    check_guidance=[
                        "Find unbounded loops with external input",
                        "Look for missing pagination",
                        "Identify unlimited concurrent operations",
                        "Check for absent rate limiting",
                    ],
                ),
                LensRule(
                    id="PERF-M002",
                    category=FindingCategory.MAINTAINABILITY_RISK,
                    name="No Performance Monitoring",
                    description="Critical paths without metrics/tracing",
                    severity_default="medium",
                    check_guidance=[
                        "Find unmonitored database queries",
                        "Look for missing timing metrics",
                        "Identify absent distributed tracing",
                        "Check for missing SLA monitoring",
                    ],
                ),
                LensRule(
                    id="PERF-M003",
                    category=FindingCategory.MAINTAINABILITY_RISK,
                    name="Hardcoded Performance Values",
                    description="Fixed timeouts, limits, buffer sizes",
                    severity_default="medium",
                    check_guidance=[
                        "Find hardcoded timeout values",
                        "Look for fixed buffer sizes",
                        "Identify hardcoded connection pool sizes",
                        "Check for magic retry counts",
                    ],
                ),
            ],
        )
