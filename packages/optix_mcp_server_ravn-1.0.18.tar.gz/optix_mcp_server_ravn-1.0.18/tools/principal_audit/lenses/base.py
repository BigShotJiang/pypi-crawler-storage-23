"""Base lens class for Principal Audit analysis perspectives."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field

from tools.principal_audit.category import FindingCategory, PrincipalLens


@dataclass
class LensRule:
    """A specific code quality rule within a lens.

    Attributes:
        id: Unique identifier (e.g., "FE-C001")
        category: Finding category this rule detects
        name: Human-readable rule name
        description: Detailed description of the rule
        severity_default: Default severity when triggered
        check_guidance: Step-by-step guidance for checking
    """

    id: str
    category: FindingCategory
    name: str
    description: str
    severity_default: str
    check_guidance: list[str] = field(default_factory=list)


@dataclass
class LensConfig:
    """Configuration for a Principal Audit lens.

    Organizes rules by the 5 finding categories:
    - complexity_rules: Cyclomatic complexity checks
    - dry_rules: Code duplication checks
    - coupling_rules: Module dependency checks
    - separation_rules: Separation of concerns checks
    - maintainability_rules: General maintainability checks
    """

    lens: PrincipalLens
    display_name: str
    description: str
    complexity_rules: list[LensRule] = field(default_factory=list)
    dry_rules: list[LensRule] = field(default_factory=list)
    coupling_rules: list[LensRule] = field(default_factory=list)
    separation_rules: list[LensRule] = field(default_factory=list)
    maintainability_rules: list[LensRule] = field(default_factory=list)

    def get_rules_for_category(self, category: FindingCategory) -> list[LensRule]:
        """Get all rules for a specific finding category.

        Args:
            category: The finding category to filter by

        Returns:
            List of LensRule objects for that category
        """
        mapping = {
            FindingCategory.COMPLEXITY: self.complexity_rules,
            FindingCategory.DRY_VIOLATION: self.dry_rules,
            FindingCategory.COUPLING: self.coupling_rules,
            FindingCategory.SEPARATION_OF_CONCERNS: self.separation_rules,
            FindingCategory.MAINTAINABILITY_RISK: self.maintainability_rules,
        }
        return mapping.get(category, [])

    def get_all_rules(self) -> list[LensRule]:
        """Get all rules across all categories.

        Returns:
            Combined list of all LensRule objects
        """
        return (
            self.complexity_rules
            + self.dry_rules
            + self.coupling_rules
            + self.separation_rules
            + self.maintainability_rules
        )


class BaseLens(ABC):
    """Abstract base class for Principal Audit lenses.

    Each lens provides a specialized perspective for code quality analysis,
    with rules focused on specific personas or concerns.
    """

    @property
    @abstractmethod
    def lens_type(self) -> PrincipalLens:
        """Return the lens type enum value."""
        pass

    @abstractmethod
    def get_config(self) -> LensConfig:
        """Return the lens configuration with all rules.

        Returns:
            LensConfig with rules organized by category
        """
        pass

    def get_complexity_guidance(self) -> list[list[str]]:
        """Get complexity check guidance from all rules.

        Returns:
            List of guidance lists from complexity rules
        """
        return [rule.check_guidance for rule in self.get_config().complexity_rules]

    def get_dry_guidance(self) -> list[list[str]]:
        """Get DRY violation check guidance from all rules.

        Returns:
            List of guidance lists from DRY rules
        """
        return [rule.check_guidance for rule in self.get_config().dry_rules]

    def get_coupling_guidance(self) -> list[list[str]]:
        """Get coupling check guidance from all rules.

        Returns:
            List of guidance lists from coupling rules
        """
        return [rule.check_guidance for rule in self.get_config().coupling_rules]

    def get_separation_guidance(self) -> list[list[str]]:
        """Get separation of concerns check guidance from all rules.

        Returns:
            List of guidance lists from separation rules
        """
        return [rule.check_guidance for rule in self.get_config().separation_rules]

    def get_maintainability_guidance(self) -> list[list[str]]:
        """Get maintainability check guidance from all rules.

        Returns:
            List of guidance lists from maintainability rules
        """
        return [rule.check_guidance for rule in self.get_config().maintainability_rules]
