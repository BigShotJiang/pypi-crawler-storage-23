"""
Recipe for finding deprecated sys.last_type/last_value/last_traceback.

sys.last_type, sys.last_value, and sys.last_traceback were deprecated in
Python 3.12 in favor of sys.last_exc.

See: https://docs.python.org/3/whatsnew/3.12.html#deprecated
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers, SearchResult
from rewrite.utils import random_id
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import FieldAccess, Identifier

# Define category path: Python > Migrate > Python 3.12
_Python312 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.12"),
]


def _mark_deprecated(tree: Any, message: str) -> Any:
    """Add a SearchResult marker for a deprecation warning."""
    search_marker = SearchResult(random_id(), message)
    current_markers = tree.markers
    new_markers_list = list(current_markers.markers) + [search_marker]
    new_markers = Markers(current_markers.id, new_markers_list)
    return tree.replace(_markers=new_markers)


@categorize(_Python312)
class FindSysLastExcInfo(Recipe):
    """
    Find usages of deprecated `sys.last_type`, `sys.last_value`,
    and `sys.last_traceback`.

    These attributes were deprecated in Python 3.12 in favor of
    `sys.last_exc` which provides the exception object directly.

    Example:
        Before:
            import sys
            exc_type = sys.last_type
            exc_value = sys.last_value
            exc_tb = sys.last_traceback

        After:
            import sys
            exc = sys.last_exc
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindSysLastExcInfo"

    @property
    def display_name(self) -> str:
        return "Find deprecated `sys.last_type` / `sys.last_value` / `sys.last_traceback`"

    @property
    def description(self) -> str:
        return (
            "`sys.last_type`, `sys.last_value`, and `sys.last_traceback` were "
            "deprecated in Python 3.12. Use `sys.last_exc` instead."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.12", "sys"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        deprecated_attrs = {"last_type", "last_value", "last_traceback"}

        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_field_access(
                self, field_access: FieldAccess, p: ExecutionContext
            ) -> Optional[FieldAccess]:
                field_access = super().visit_field_access(field_access, p)

                if not isinstance(field_access.name, Identifier):
                    return field_access
                if field_access.name.simple_name not in deprecated_attrs:
                    return field_access

                target = field_access.target
                if not isinstance(target, Identifier):
                    return field_access
                if target.simple_name != "sys":
                    return field_access

                return _mark_deprecated(
                    field_access,
                    f"sys.{field_access.name.simple_name} was deprecated in Python 3.12. "
                    "Use sys.last_exc instead."
                )

        return Visitor()
