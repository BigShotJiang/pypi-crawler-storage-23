"""Composite recipe for upgrading from Python 3.9 to Python 3.10."""

from typing import List

from rewrite import Recipe
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python

# Define category path: Python > Migrate
_Migrate = [*Python, CategoryDescriptor(display_name="Migrate")]


@categorize(_Migrate)
class UpgradeToPython310(Recipe):
    """
    Migrate deprecated APIs and adopt new syntax for Python 3.10 compatibility.

    This composite recipe applies all necessary migrations for code
    running on Python 3.9 to be compatible with Python 3.10.

    Key changes in Python 3.10:
    - PEP 604: Union types can be written as `X | Y` instead of `Union[X, Y]`
    - `typing.Optional[X]` can be written as `X | None`
    - `collections` ABCs removed from `collections` (use `collections.abc`)
    - threading.currentThread() deprecated (use current_thread())
    - threading.activeCount() deprecated (use active_count())

    See: https://docs.python.org/3/whatsnew/3.10.html
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.UpgradeToPython310"

    @property
    def display_name(self) -> str:
        return "Upgrade to Python 3.10"

    @property
    def description(self) -> str:
        return (
            "Migrate deprecated APIs and adopt new syntax for Python 3.10 compatibility. "
            "This includes adopting PEP 604 union type syntax (`X | Y`) and other "
            "modernizations between Python 3.9 and 3.10."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.10"]

    def recipe_list(self) -> List[Recipe]:
        """Return the list of recipes to apply for Python 3.10 upgrade."""
        # Import here to avoid circular imports
        from .collections_abc_migrations import ReplaceCollectionsAbcImports
        from .threading_deprecations import (
            ReplaceConditionNotifyAll,
            ReplaceEventIsSet,
            ReplaceThreadGetName,
            ReplaceThreadIsDaemon,
            ReplaceThreadSetDaemon,
            ReplaceThreadSetName,
            ReplaceThreadingActiveCount,
            ReplaceThreadingCurrentThread,
        )
        from .typing_union_to_pipe import (
            ReplaceTypingOptionalWithUnion,
            ReplaceTypingUnionWithPipe,
        )
        from .upgrade_to_python39 import UpgradeToPython39

        return [
            # First apply all Python 3.9 upgrades (which includes 3.8)
            UpgradeToPython39(),
            # collections ABCs moved to collections.abc, removed in Python 3.10
            ReplaceCollectionsAbcImports(),
            # PEP 604: Replace typing.Optional[X] with X | None
            ReplaceTypingOptionalWithUnion(),
            # PEP 604: Replace typing.Union[X, Y] with X | Y
            ReplaceTypingUnionWithPipe(),
            # Threading camelCase deprecations (deprecated 3.10, removed 3.12)
            ReplaceThreadingCurrentThread(),
            ReplaceThreadingActiveCount(),
            ReplaceConditionNotifyAll(),
            ReplaceEventIsSet(),
            # Threading getter/setter deprecations (auto-fix)
            ReplaceThreadGetName(),
            ReplaceThreadSetName(),
            ReplaceThreadIsDaemon(),
            ReplaceThreadSetDaemon(),
        ]
