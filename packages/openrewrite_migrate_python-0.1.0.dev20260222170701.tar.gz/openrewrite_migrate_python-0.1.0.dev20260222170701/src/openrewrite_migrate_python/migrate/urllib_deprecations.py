"""
Recipes for migrating deprecated urllib.parse functions.

The following functions were deprecated in Python 3.8 and removed in 3.14:
- urllib.parse.splithost() -> urllib.parse.urlparse()
- urllib.parse.splitport() -> urllib.parse.urlparse()
- urllib.parse.splituser() -> urllib.parse.urlparse()
- urllib.parse.splitpasswd() -> urllib.parse.urlparse()
- urllib.parse.splittype() -> urllib.parse.urlparse()
- urllib.parse.splitvalue() -> urllib.parse.urlparse()
- urllib.parse.splittag() -> urllib.parse.urlparse()
- urllib.parse.splitattr() -> urllib.parse.urlparse()
- urllib.parse.splitnport() -> urllib.parse.urlparse()
- urllib.parse.splitquery() -> urllib.parse.urlparse()
- urllib.parse.to_bytes() -> Use encoding directly

See: https://docs.python.org/3/library/urllib.parse.html
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers, SearchResult
from rewrite.utils import random_id
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import Identifier, MethodInvocation, FieldAccess

# Define category path: Python > Migrate > Python 3.14
_Python314 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.14"),
]


def _mark_deprecated(tree: Any, message: str) -> Any:
    """Add a SearchResult marker for a deprecation warning."""
    search_marker = SearchResult(random_id(), message)
    current_markers = tree.markers
    new_markers_list = list(current_markers.markers) + [search_marker]
    new_markers = Markers(current_markers.id, new_markers_list)
    return tree.replace(_markers=new_markers)


# Deprecated split functions
_DEPRECATED_SPLITS = {
    "splithost": "Use urllib.parse.urlparse().netloc instead",
    "splitport": "Use urllib.parse.urlparse().port instead",
    "splituser": "Use urllib.parse.urlparse() and parse the userinfo",
    "splitpasswd": "Use urllib.parse.urlparse() and parse the userinfo",
    "splittype": "Use urllib.parse.urlparse().scheme instead",
    "splittag": "Use urllib.parse.urlparse().fragment instead",
    "splitattr": "Parse the query string with urllib.parse.parse_qs()",
    "splitnport": "Use urllib.parse.urlparse().port with default",
    "splitquery": "Use urllib.parse.urlparse().query instead",
    "splitvalue": "Parse the query string manually",
}


@categorize(_Python314)
class FindUrllibParseSplitFunctions(Recipe):
    """
    Find usage of deprecated urllib.parse split functions.

    The following functions were deprecated in Python 3.8 and removed in 3.14:
    - splithost, splitport, splituser, splitpasswd, splittype
    - splittag, splitattr, splitnport, splitquery, splitvalue

    Use `urllib.parse.urlparse()` instead and access the appropriate
    attributes of the result.

    Example:
        Before:
            from urllib.parse import splithost
            host, path = splithost(url)

        After:
            from urllib.parse import urlparse
            parsed = urlparse(url)
            host = parsed.netloc
            path = parsed.path
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindUrllibParseSplitFunctions"

    @property
    def display_name(self) -> str:
        return "Find deprecated urllib.parse split functions"

    @property
    def description(self) -> str:
        return (
            "Find usage of deprecated urllib.parse split functions "
            "(splithost, splitport, etc.) removed in Python 3.14. "
            "Use urlparse() instead."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.14", "urllib"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not isinstance(method.name, Identifier):
                    return method

                func_name = method.name.simple_name
                if func_name not in _DEPRECATED_SPLITS:
                    return method

                select = method.select
                # Check for urllib.parse.splitX() or parse.splitX() patterns
                if isinstance(select, Identifier):
                    if select.simple_name == "parse":
                        return _mark_deprecated(
                            method,
                            f"urllib.parse.{func_name}() was removed in Python 3.14. "
                            f"{_DEPRECATED_SPLITS[func_name]}."
                        )
                elif isinstance(select, FieldAccess):
                    if (isinstance(select.target, Identifier) and
                        select.target.simple_name == "urllib" and
                        isinstance(select.name, Identifier) and
                        select.name.simple_name == "parse"):
                        return _mark_deprecated(
                            method,
                            f"urllib.parse.{func_name}() was removed in Python 3.14. "
                            f"{_DEPRECATED_SPLITS[func_name]}."
                        )

                return method

        return Visitor()


@categorize(_Python314)
class FindUrllibParseToBytes(Recipe):
    """
    Find usage of deprecated `urllib.parse.to_bytes()`.

    The `to_bytes()` function was deprecated in Python 3.8 and removed in 3.14.
    Use `str.encode()` directly instead.

    Example:
        Before:
            from urllib.parse import to_bytes
            data = to_bytes(url)

        After:
            data = url.encode('ascii')
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindUrllibParseToBytes"

    @property
    def display_name(self) -> str:
        return "Find deprecated `urllib.parse.to_bytes()` usage"

    @property
    def description(self) -> str:
        return (
            "Find usage of `urllib.parse.to_bytes()` which was deprecated in "
            "Python 3.8 and removed in 3.14. Use str.encode() directly."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.14", "urllib"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "to_bytes":
                    return method

                select = method.select
                if isinstance(select, Identifier) and select.simple_name == "parse":
                    return _mark_deprecated(
                        method,
                        "urllib.parse.to_bytes() was removed in Python 3.14. "
                        "Use str.encode() directly instead."
                    )

                return method

        return Visitor()
