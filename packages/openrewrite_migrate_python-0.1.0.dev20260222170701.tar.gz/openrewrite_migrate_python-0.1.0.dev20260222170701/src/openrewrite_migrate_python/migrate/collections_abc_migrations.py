"""
Recipes for migrating deprecated collections imports to collections.abc.

Several abstract base classes were moved from `collections` to `collections.abc`
in Python 3.3 and the old import locations were removed in Python 3.10.

The following imports need to be migrated:
- from collections import Callable -> from collections.abc import Callable
- from collections import Iterable -> from collections.abc import Iterable
- from collections import Iterator -> from collections.abc import Iterator
- from collections import Generator -> from collections.abc import Generator
- from collections import Hashable -> from collections.abc import Hashable
- from collections import Sized -> from collections.abc import Sized
- from collections import Container -> from collections.abc import Container
- from collections import Mapping -> from collections.abc import Mapping
- from collections import MutableMapping -> from collections.abc import MutableMapping
- from collections import Sequence -> from collections.abc import Sequence
- from collections import MutableSequence -> from collections.abc import MutableSequence
- from collections import Set -> from collections.abc import Set
- from collections import MutableSet -> from collections.abc import MutableSet

See: https://docs.python.org/3/library/collections.abc.html
"""

from typing import Any, List, Optional, Set as TypingSet

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers
from rewrite.python.visitor import PythonVisitor
from rewrite.python.tree import MultiImport
from rewrite.java.support_types import JLeftPadded, Space
from rewrite.java.tree import FieldAccess, Identifier
from rewrite.utils import random_id

# Define category path: Python > Migrate > Python 3.10
_Python310 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.10"),
]

# Abstract base classes that were moved from collections to collections.abc
COLLECTIONS_ABC_CLASSES: TypingSet[str] = {
    "Callable",
    "Iterable",
    "Iterator",
    "Generator",
    "Hashable",
    "Sized",
    "Container",
    "Mapping",
    "MutableMapping",
    "Sequence",
    "MutableSequence",
    "Set",
    "MutableSet",
}


def _get_from_module_name(from_part: Any) -> Optional[str]:
    """Extract the module name from the from part of an import.

    Returns the simple name if it's an Identifier, or None otherwise.
    """
    if isinstance(from_part, Identifier):
        return from_part.simple_name
    return None


def _get_imported_names(multi: MultiImport) -> List[str]:
    """Get the list of names being imported from a MultiImport."""
    names = []
    for import_node in multi.names:
        # The Import node has a qualid which is a FieldAccess
        # For simple imports like "from X import Y", the qualid.name is Y
        qualid = import_node.qualid
        if isinstance(qualid, FieldAccess):
            if isinstance(qualid.name, Identifier):
                names.append(qualid.name.simple_name)
        elif isinstance(qualid, Identifier):
            names.append(qualid.simple_name)
    return names


def _has_abc_import(multi: MultiImport) -> bool:
    """Check if the MultiImport contains any collections.abc class imports."""
    imported_names = _get_imported_names(multi)
    return any(name in COLLECTIONS_ABC_CLASSES for name in imported_names)


def _create_collections_abc_field_access(original_from: Identifier) -> FieldAccess:
    """Create a FieldAccess node representing 'collections.abc'.

    This creates collections.abc where:
    - target is an Identifier 'collections' (preserving original prefix/whitespace)
    - name is an Identifier 'abc'
    """
    # Create the 'abc' identifier with proper padding
    abc_identifier = Identifier(
        _id=random_id(),
        _prefix=Space.EMPTY,
        _markers=Markers.EMPTY,
        _annotations=[],
        _simple_name="abc",
        _type=None,
        _field_type=None,
    )

    # Create JLeftPadded for the name (abc) - the dot comes before it
    padded_abc = JLeftPadded(
        _before=Space.EMPTY,  # No space between dot and abc
        _element=abc_identifier,
        _markers=Markers.EMPTY,
    )

    # Create the FieldAccess: collections.abc
    # Use the original 'collections' identifier as the target, preserving its prefix
    return FieldAccess(
        _id=random_id(),
        _prefix=original_from.prefix,
        _markers=Markers.EMPTY,
        _target=original_from.replace(_prefix=Space.EMPTY),
        _name=padded_abc,
        _type=None,
    )


@categorize(_Python310)
class ReplaceCollectionsAbcImports(Recipe):
    """
    Replace deprecated `collections` imports with `collections.abc` imports.

    Several abstract base classes were moved from `collections` to `collections.abc`
    in Python 3.3 and the old import locations were removed in Python 3.10.

    This recipe migrates the following imports:
    - Callable, Iterable, Iterator, Generator
    - Hashable, Sized, Container
    - Mapping, MutableMapping
    - Sequence, MutableSequence
    - Set, MutableSet

    Example:
        Before:
            from collections import Callable, Mapping

        After:
            from collections.abc import Callable, Mapping
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceCollectionsAbcImports"

    @property
    def display_name(self) -> str:
        return "Replace `collections` ABC imports with `collections.abc`"

    @property
    def description(self) -> str:
        return (
            "Migrate deprecated abstract base class imports from `collections` to "
            "`collections.abc`. These imports were deprecated in Python 3.3 and "
            "removed in Python 3.10."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.10", "collections"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_multi_import(
                self, multi: MultiImport, p: ExecutionContext
            ) -> Optional[MultiImport]:
                multi = super().visit_multi_import(multi, p)

                # Check if this is a 'from collections import ...' statement
                from_part = multi.from_
                if from_part is None:
                    return multi

                # Check if importing from 'collections' (not 'collections.abc' or other)
                module_name = _get_from_module_name(from_part)
                if module_name != "collections":
                    return multi

                # Check if any of the imported names are ABC classes
                if not _has_abc_import(multi):
                    return multi

                # Create the new from part: collections.abc
                new_from = _create_collections_abc_field_access(from_part)

                # Replace the from_ in the MultiImport using padding helper
                # The padding wrapper needs to be preserved
                old_padded_from = multi.padding.from_
                if old_padded_from is None:
                    return multi

                new_padded_from = old_padded_from.replace(_element=new_from)
                return multi.padding.replace(_from=new_padded_from)

        return Visitor()
