"""
Recipes for migrating deprecated typing module aliases to built-in generics.

PEP 585 (Python 3.9+) deprecated many typing module aliases in favor of
using built-in types directly as generics:

- typing.List[X] -> list[X]
- typing.Dict[K, V] -> dict[K, V]
- typing.Set[X] -> set[X]
- typing.FrozenSet[X] -> frozenset[X]
- typing.Tuple[X, ...] -> tuple[X, ...]
- typing.Type[X] -> type[X]

Additionally, typing.Text is deprecated (alias for str since Python 3.11).

See: https://peps.python.org/pep-0585/
"""

from typing import Any, Optional, Dict

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers, SearchResult
from rewrite.utils import random_id
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import Identifier

# Define category paths
_Python39 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.9"),
]

_Python311 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.11"),
]


def _mark_deprecated(tree: Any, message: str, detail: Optional[str] = None) -> Any:
    """Add a SearchResult marker for a deprecation warning."""
    full_message = f"{message}: {detail}" if detail else message
    search_marker = SearchResult(random_id(), full_message)
    current_markers = tree.markers
    new_markers_list = list(current_markers.markers) + [search_marker]
    new_markers = Markers(current_markers.id, new_markers_list)
    return tree.replace(_markers=new_markers)


# PEP 585 deprecated typing aliases -> built-in replacements
PEP585_DEPRECATIONS: Dict[str, str] = {
    "List": "list",
    "Dict": "dict",
    "Set": "set",
    "FrozenSet": "frozenset",
    "Tuple": "tuple",
    "Type": "type",
}


@categorize(_Python39)
class ReplaceTypingListWithList(Recipe):
    """
    Find and migrate `typing.List` to built-in `list`.

    PEP 585 deprecated `typing.List` in Python 3.9. The built-in `list` type
    can now be used directly as a generic type.

    Example:
        Before:
            from typing import List
            items: List[str] = []

        After:
            items: list[str] = []
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceTypingListWithList"

    @property
    def display_name(self) -> str:
        return "Replace `typing.List` with `list`"

    @property
    def description(self) -> str:
        return (
            "PEP 585 deprecated `typing.List` in Python 3.9. "
            "Replace with the built-in `list` type for generic annotations."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_identifier(
                self, identifier: Identifier, p: ExecutionContext
            ) -> Optional[Identifier]:
                identifier = super().visit_identifier(identifier, p)

                if identifier.simple_name == "List":
                    # Check if this is from typing module via type attribution
                    if identifier.field_type:
                        fqn = str(getattr(identifier.field_type, '_fully_qualified_name', ''))
                        if 'typing' in fqn:
                            return _mark_deprecated(
                                identifier,
                                "typing.List is deprecated",
                                "Replace with built-in list (PEP 585)"
                            )

                return identifier

        return Visitor()


@categorize(_Python39)
class ReplaceTypingDictWithDict(Recipe):
    """
    Find and migrate `typing.Dict` to built-in `dict`.

    PEP 585 deprecated `typing.Dict` in Python 3.9. The built-in `dict` type
    can now be used directly as a generic type.

    Example:
        Before:
            from typing import Dict
            mapping: Dict[str, int] = {}

        After:
            mapping: dict[str, int] = {}
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceTypingDictWithDict"

    @property
    def display_name(self) -> str:
        return "Replace `typing.Dict` with `dict`"

    @property
    def description(self) -> str:
        return (
            "PEP 585 deprecated `typing.Dict` in Python 3.9. "
            "Replace with the built-in `dict` type for generic annotations."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_identifier(
                self, identifier: Identifier, p: ExecutionContext
            ) -> Optional[Identifier]:
                identifier = super().visit_identifier(identifier, p)

                if identifier.simple_name == "Dict":
                    if identifier.field_type:
                        fqn = str(getattr(identifier.field_type, '_fully_qualified_name', ''))
                        if 'typing' in fqn:
                            return _mark_deprecated(
                                identifier,
                                "typing.Dict is deprecated",
                                "Replace with built-in dict (PEP 585)"
                            )

                return identifier

        return Visitor()


@categorize(_Python39)
class ReplaceTypingSetWithSet(Recipe):
    """
    Find and migrate `typing.Set` to built-in `set`.

    PEP 585 deprecated `typing.Set` in Python 3.9. The built-in `set` type
    can now be used directly as a generic type.

    Example:
        Before:
            from typing import Set
            items: Set[int] = set()

        After:
            items: set[int] = set()
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceTypingSetWithSet"

    @property
    def display_name(self) -> str:
        return "Replace `typing.Set` with `set`"

    @property
    def description(self) -> str:
        return (
            "PEP 585 deprecated `typing.Set` in Python 3.9. "
            "Replace with the built-in `set` type for generic annotations."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_identifier(
                self, identifier: Identifier, p: ExecutionContext
            ) -> Optional[Identifier]:
                identifier = super().visit_identifier(identifier, p)

                if identifier.simple_name == "Set":
                    if identifier.field_type:
                        fqn = str(getattr(identifier.field_type, '_fully_qualified_name', ''))
                        if 'typing' in fqn:
                            return _mark_deprecated(
                                identifier,
                                "typing.Set is deprecated",
                                "Replace with built-in set (PEP 585)"
                            )

                return identifier

        return Visitor()


@categorize(_Python39)
class ReplaceTypingTupleWithTuple(Recipe):
    """
    Find and migrate `typing.Tuple` to built-in `tuple`.

    PEP 585 deprecated `typing.Tuple` in Python 3.9. The built-in `tuple` type
    can now be used directly as a generic type.

    Example:
        Before:
            from typing import Tuple
            point: Tuple[int, int] = (0, 0)

        After:
            point: tuple[int, int] = (0, 0)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceTypingTupleWithTuple"

    @property
    def display_name(self) -> str:
        return "Replace `typing.Tuple` with `tuple`"

    @property
    def description(self) -> str:
        return (
            "PEP 585 deprecated `typing.Tuple` in Python 3.9. "
            "Replace with the built-in `tuple` type for generic annotations."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_identifier(
                self, identifier: Identifier, p: ExecutionContext
            ) -> Optional[Identifier]:
                identifier = super().visit_identifier(identifier, p)

                if identifier.simple_name == "Tuple":
                    if identifier.field_type:
                        fqn = str(getattr(identifier.field_type, '_fully_qualified_name', ''))
                        if 'typing' in fqn:
                            return _mark_deprecated(
                                identifier,
                                "typing.Tuple is deprecated",
                                "Replace with built-in tuple (PEP 585)"
                            )

                return identifier

        return Visitor()


@categorize(_Python311)
class ReplaceTypingText(Recipe):
    """
    Find and migrate `typing.Text` to `str`.

    `typing.Text` was an alias for `str` provided for Python 2/3 compatibility.
    It is deprecated as of Python 3.11 since Python 2 is no longer supported.

    Example:
        Before:
            from typing import Text
            name: Text = "hello"

        After:
            name: str = "hello"
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceTypingText"

    @property
    def display_name(self) -> str:
        return "Replace `typing.Text` with `str`"

    @property
    def description(self) -> str:
        return (
            "`typing.Text` is deprecated as of Python 3.11. "
            "It was an alias for `str` for Python 2/3 compatibility. Replace with `str`."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        from rewrite.python.tree import Import

        class Visitor(PythonVisitor[ExecutionContext]):
            def __init__(self):
                super().__init__()
                self._in_import = False

            def visit_import(self, import_stmt: Import, p: ExecutionContext) -> Optional[Import]:
                # Track that we're inside an import statement
                self._in_import = True
                result = super().visit_import(import_stmt, p)
                self._in_import = False
                return result

            def visit_identifier(
                self, identifier: Identifier, p: ExecutionContext
            ) -> Optional[Identifier]:
                identifier = super().visit_identifier(identifier, p)

                # Skip identifiers in import statements
                if self._in_import:
                    return identifier

                if identifier.simple_name == "Text":
                    # Check if type attribution is available
                    if identifier.field_type:
                        fqn = str(getattr(identifier.field_type, '_fully_qualified_name', ''))
                        if 'typing' in fqn:
                            return identifier.replace(_simple_name="str")
                    else:
                        # Without type attribution, replace Text assuming it's from typing
                        # This is reasonable because:
                        # 1. "Text" is rarely used as a variable name
                        # 2. typing.Text is the only common usage of this identifier
                        return identifier.replace(_simple_name="str")

                return identifier

        return Visitor()
