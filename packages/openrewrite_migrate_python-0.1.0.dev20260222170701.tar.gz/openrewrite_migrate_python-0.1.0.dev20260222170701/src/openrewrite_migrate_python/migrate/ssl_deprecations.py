"""
Recipes for migrating deprecated ssl module functions.

ssl.match_hostname() was deprecated in Python 3.7 and removed in Python 3.12.
Hostname matching is now done by OpenSSL automatically when
ssl.SSLContext.check_hostname is enabled.

See: https://docs.python.org/3/library/ssl.html
"""

from typing import Any, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers, SearchResult
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import Identifier, MethodInvocation
from rewrite.utils import random_id

# Define category path: Python > Migrate > Python 3.12
_Python312 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.12"),
]


def _mark_deprecated(tree: Any, message: str, detail: Optional[str] = None) -> Any:
    """Add a SearchResult marker for a deprecation warning."""
    full_message = f"{message}: {detail}" if detail else message
    search_marker = SearchResult(random_id(), full_message)
    current_markers = tree.markers
    new_markers_list = list(current_markers.markers) + [search_marker]
    new_markers = Markers(current_markers.id, new_markers_list)
    return tree.replace(_markers=new_markers)


def _is_ssl_method(method: MethodInvocation, method_name: str) -> bool:
    """
    Check if this is an ssl.method_name() call.
    """
    if not isinstance(method.name, Identifier):
        return False
    if method.name.simple_name != method_name:
        return False

    # Check if type info confirms this is an ssl method
    if method.method_type and method.method_type.declaring_type:
        dt = method.method_type.declaring_type
        if hasattr(dt, '_fully_qualified_name'):
            fqn = str(dt._fully_qualified_name)
            if 'ssl' in fqn:
                return True

    # Fallback: Check simple name on select
    select = method.select
    if select is None:
        return False
    if isinstance(select, Identifier) and select.simple_name == "ssl":
        return True

    return False


@categorize(_Python312)
class FindSslMatchHostname(Recipe):
    """
    Find usage of the deprecated ssl.match_hostname() function.

    ssl.match_hostname() was deprecated in Python 3.7 and removed in Python 3.12.
    Hostname matching is now done automatically by OpenSSL when using
    ssl.SSLContext with check_hostname=True (which is the default for
    ssl.create_default_context()).

    Note: This recipe only finds usages. Manual migration is required because
    the replacement depends on your SSL context configuration.

    Example migration:
        Before:
            import ssl
            ssl.match_hostname(cert, hostname)

        After:
            # Use ssl.create_default_context() which enables hostname checking
            # Or set ssl.SSLContext.check_hostname = True
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindSslMatchHostname"

    @property
    def display_name(self) -> str:
        return "Find deprecated `ssl.match_hostname()`"

    @property
    def description(self) -> str:
        return (
            "Find usage of the deprecated `ssl.match_hostname()` function which was "
            "removed in Python 3.12. Use `ssl.SSLContext.check_hostname` instead."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if _is_ssl_method(method, "match_hostname"):
                    return _mark_deprecated(
                        method,
                        "ssl.match_hostname() is deprecated",
                        "Use ssl.SSLContext.check_hostname instead (removed in Python 3.12)"
                    )

                return method

        return Visitor()
