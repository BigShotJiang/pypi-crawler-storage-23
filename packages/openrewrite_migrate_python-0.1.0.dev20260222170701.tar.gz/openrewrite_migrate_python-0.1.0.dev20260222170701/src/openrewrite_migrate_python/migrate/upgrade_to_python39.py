"""Composite recipe for upgrading from Python 3.8 to Python 3.9."""

from typing import List

from rewrite import Recipe
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.recipes import ChangeImport

# Define category path: Python > Migrate
_Migrate = [*Python, CategoryDescriptor(display_name="Migrate")]


@categorize(_Migrate)
class UpgradeToPython39(Recipe):
    """
    Migrate deprecated APIs for Python 3.9 compatibility.

    This composite recipe applies all necessary migrations for code
    running on Python 3.8 to be compatible with Python 3.9.

    Key changes in Python 3.9:
    - PEP 585: Built-in generics (`list[int]` instead of `typing.List[int]`)
    - `base64.encodestring()` / `decodestring()` removed
    - `Element.getiterator()` deprecated (use `iter()`)
    - `Element.getchildren()` deprecated (use `list(element)`)
    - `typing.Callable` deprecated in favor of `collections.abc.Callable`

    See: https://docs.python.org/3/whatsnew/3.9.html
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.UpgradeToPython39"

    @property
    def display_name(self) -> str:
        return "Upgrade to Python 3.9"

    @property
    def description(self) -> str:
        return (
            "Migrate deprecated APIs for Python 3.9 compatibility. "
            "This includes PEP 585 built-in generics, removed base64 functions, "
            "and deprecated XML Element methods."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.9"]

    def recipe_list(self) -> List[Recipe]:
        """Return the list of recipes to apply for Python 3.9 upgrade."""
        from .html_parser_deprecations import FindHtmlParserUnescape
        from .threading_is_alive_deprecation import ReplaceThreadIsAlive
        from .typing_callable import ReplaceTypingCallableWithCollectionsAbcCallable
        from .upgrade_to_python38 import UpgradeToPython38
        from .xml_deprecations import FindElementGetchildren, ReplaceElementGetiterator

        return [
            # First apply all Python 3.8 upgrades
            UpgradeToPython38(),
            # base64 encodestring/decodestring removed in Python 3.9
            ChangeImport(old_module="base64", old_name="encodestring", new_module="base64", new_name="encodebytes"),
            ChangeImport(old_module="base64", old_name="decodestring", new_module="base64", new_name="decodebytes"),
            # PEP 585: Replace typing.List[X] with list[X], etc. (Python 3.9+)
            ChangeImport(old_module="typing", old_name="List", new_module="builtins", new_name="list"),
            ChangeImport(old_module="typing", old_name="Dict", new_module="builtins", new_name="dict"),
            ChangeImport(old_module="typing", old_name="Set", new_module="builtins", new_name="set"),
            ChangeImport(old_module="typing", old_name="FrozenSet", new_module="builtins", new_name="frozenset"),
            ChangeImport(old_module="typing", old_name="Tuple", new_module="builtins", new_name="tuple"),
            ChangeImport(old_module="typing", old_name="Type", new_module="builtins", new_name="type"),
            # typing.Callable -> collections.abc.Callable (PEP 585)
            ReplaceTypingCallableWithCollectionsAbcCallable(),
            # PEP 585: typing -> collections replacements
            ChangeImport(old_module="typing", old_name="Deque", new_module="collections", new_name="deque"),
            ChangeImport(old_module="typing", old_name="DefaultDict", new_module="collections", new_name="defaultdict"),
            ChangeImport(old_module="typing", old_name="OrderedDict", new_module="collections"),
            ChangeImport(old_module="typing", old_name="Counter", new_module="collections"),
            ChangeImport(old_module="typing", old_name="ChainMap", new_module="collections"),
            # PEP 585: typing -> re replacements
            ChangeImport(old_module="typing", old_name="Pattern", new_module="re"),
            ChangeImport(old_module="typing", old_name="Match", new_module="re"),
            # PEP 585: typing -> contextlib replacements
            ChangeImport(old_module="typing", old_name="ContextManager", new_module="contextlib", new_name="AbstractContextManager"),
            ChangeImport(old_module="typing", old_name="AsyncContextManager", new_module="contextlib", new_name="AbstractAsyncContextManager"),
            # PEP 585: typing -> collections.abc replacements
            ChangeImport(old_module="typing", old_name="Iterable", new_module="collections.abc"),
            ChangeImport(old_module="typing", old_name="Iterator", new_module="collections.abc"),
            ChangeImport(old_module="typing", old_name="Generator", new_module="collections.abc"),
            ChangeImport(old_module="typing", old_name="Sequence", new_module="collections.abc"),
            ChangeImport(old_module="typing", old_name="MutableSequence", new_module="collections.abc"),
            ChangeImport(old_module="typing", old_name="Mapping", new_module="collections.abc"),
            ChangeImport(old_module="typing", old_name="MutableMapping", new_module="collections.abc"),
            ChangeImport(old_module="typing", old_name="AbstractSet", new_module="collections.abc", new_name="Set"),
            ChangeImport(old_module="typing", old_name="MutableSet", new_module="collections.abc"),
            ChangeImport(old_module="typing", old_name="Awaitable", new_module="collections.abc"),
            ChangeImport(old_module="typing", old_name="Coroutine", new_module="collections.abc"),
            ChangeImport(old_module="typing", old_name="AsyncIterable", new_module="collections.abc"),
            ChangeImport(old_module="typing", old_name="AsyncIterator", new_module="collections.abc"),
            ChangeImport(old_module="typing", old_name="AsyncGenerator", new_module="collections.abc"),
            ChangeImport(old_module="typing", old_name="Reversible", new_module="collections.abc"),
            ChangeImport(old_module="typing", old_name="Container", new_module="collections.abc"),
            ChangeImport(old_module="typing", old_name="Collection", new_module="collections.abc"),
            ChangeImport(old_module="typing", old_name="MappingView", new_module="collections.abc"),
            ChangeImport(old_module="typing", old_name="KeysView", new_module="collections.abc"),
            ChangeImport(old_module="typing", old_name="ItemsView", new_module="collections.abc"),
            ChangeImport(old_module="typing", old_name="ValuesView", new_module="collections.abc"),
            # XML Element.getiterator() deprecated in 3.9, use iter()
            ReplaceElementGetiterator(),
            # XML Element.getchildren() deprecated in 3.9 (detection only)
            FindElementGetchildren(),
            # fractions.gcd() removed in 3.9, use math.gcd()
            ChangeImport(old_module="fractions", old_name="gcd", new_module="math"),
            # sys.getcheckinterval/setcheckinterval removed in 3.9
            ChangeImport(old_module="sys", old_name="getcheckinterval", new_module="sys", new_name="getswitchinterval"),
            ChangeImport(old_module="sys", old_name="setcheckinterval", new_module="sys", new_name="setswitchinterval"),
            # Thread.isAlive() removed in 3.9
            ReplaceThreadIsAlive(),
            # HTMLParser.unescape() removed in 3.9
            FindHtmlParserUnescape(),
        ]
