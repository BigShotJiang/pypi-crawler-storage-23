"""
Recipes for migrating deprecated tempfile module functions.

tempfile.mktemp() has been deprecated since Python 2.3 due to security
concerns (race condition between file creation and use). It was removed
in Python 3.14.

Alternatives:
- tempfile.mkstemp() - returns (fd, name) tuple
- tempfile.NamedTemporaryFile() - returns a file object

See: https://docs.python.org/3/library/tempfile.html
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers, SearchResult
from rewrite.utils import random_id
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import Identifier, MethodInvocation

# Define category path: Python > Migrate > Python 3.14
_Python314 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.14"),
]


def _mark_deprecated(tree: Any, message: str) -> Any:
    """Add a SearchResult marker for a deprecation warning."""
    search_marker = SearchResult(random_id(), message)
    current_markers = tree.markers
    new_markers_list = list(current_markers.markers) + [search_marker]
    new_markers = Markers(current_markers.id, new_markers_list)
    return tree.replace(_markers=new_markers)


@categorize(_Python314)
class FindTempfileMktemp(Recipe):
    """
    Find usage of `tempfile.mktemp()`.

    The `mktemp()` function was deprecated in Python 2.3 due to a security
    vulnerability (race condition) and removed in Python 3.14.

    Alternatives:
    - Use `tempfile.mkstemp()` which returns (fd, name) and creates the file
    - Use `tempfile.NamedTemporaryFile()` for a file object

    Example:
        Before:
            import tempfile
            filename = tempfile.mktemp()
            with open(filename, 'w') as f:
                f.write(data)

        After:
            import tempfile
            fd, filename = tempfile.mkstemp()
            with os.fdopen(fd, 'w') as f:
                f.write(data)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindTempfileMktemp"

    @property
    def display_name(self) -> str:
        return "Find deprecated `tempfile.mktemp()` usage"

    @property
    def description(self) -> str:
        return (
            "Find usage of `tempfile.mktemp()` which is deprecated due to "
            "security concerns (race condition). Use `mkstemp()` or "
            "`NamedTemporaryFile()` instead."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.14", "security", "tempfile"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "mktemp":
                    return method

                select = method.select
                if not isinstance(select, Identifier):
                    return method
                if select.simple_name != "tempfile":
                    return method

                return _mark_deprecated(
                    method,
                    "tempfile.mktemp() is deprecated (security issue) and removed in Python 3.14. "
                    "Use tempfile.mkstemp() or NamedTemporaryFile() instead."
                )

        return Visitor()
