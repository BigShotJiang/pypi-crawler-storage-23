"""
Recipe for finding imports of modules removed in Python 3.12.

The following modules were removed in Python 3.12:
- asynchat (use asyncio)
- asyncore (use asyncio)
- smtpd (use aiosmtpd)

Note: The `imp` and `distutils` modules were also removed in 3.12
but are handled by dedicated recipes (imp_migrations.py and
distutils_deprecations.py).

See: https://docs.python.org/3/whatsnew/3.12.html#removed
"""

from typing import Any, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers, SearchResult
from rewrite.python.visitor import PythonVisitor
from rewrite.python.tree import MultiImport, Import
from rewrite.java.tree import FieldAccess, Identifier
from rewrite.utils import random_id

# Define category path: Python > Migrate > Python 3.12
_Python312 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.12"),
]

# Modules removed in Python 3.12 (excluding imp and distutils which have dedicated recipes)
REMOVED_MODULES_312 = {
    "asynchat": "Use `asyncio` instead.",
    "asyncore": "Use `asyncio` instead.",
    "smtpd": "Use `aiosmtpd` instead.",
}


def _mark_removed(tree: Any, module_name: str) -> Any:
    """Add a SearchResult marker for a removed module."""
    replacement = REMOVED_MODULES_312.get(module_name, "")
    message = f"Module '{module_name}' was removed in Python 3.12. {replacement}"
    search_marker = SearchResult(random_id(), message)
    current_markers = tree.markers
    new_markers_list = list(current_markers.markers) + [search_marker]
    new_markers = Markers(current_markers.id, new_markers_list)
    return tree.replace(_markers=new_markers)


def _get_import_name(import_node: Any) -> Optional[str]:
    """Extract the module name from an import node's qualid.

    For a simple import like 'import asynchat', the qualid is a FieldAccess
    where the name property is the identifier 'asynchat'.
    """
    qualid = import_node.qualid
    if isinstance(qualid, FieldAccess):
        return qualid.name.simple_name
    if isinstance(qualid, Identifier):
        return qualid.simple_name
    return None


@categorize(_Python312)
class FindRemovedModules312(Recipe):
    """
    Find imports of modules that were removed in Python 3.12.

    The following modules were removed in Python 3.12:
    asynchat, asyncore, smtpd.

    These modules were deprecated in earlier Python versions and have
    been fully removed in Python 3.12. Code using these modules will
    need to be updated to use alternative libraries.

    Example:
        Before:
            import asynchat
            from asyncore import dispatcher

        After migration (manual):
            # asynchat/asyncore - use asyncio instead
            # smtpd - use aiosmtpd instead
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindRemovedModules312"

    @property
    def display_name(self) -> str:
        return "Find modules removed in Python 3.12"

    @property
    def description(self) -> str:
        return (
            "Find imports of modules that were removed in Python 3.12, "
            "including asynchat, asyncore, and smtpd."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_multi_import(
                self, multi: MultiImport, p: ExecutionContext
            ) -> Optional[MultiImport]:
                multi = super().visit_multi_import(multi, p)

                from_part = multi.from_
                if from_part is not None:
                    # Handle 'from X import ...' pattern
                    if isinstance(from_part, Identifier):
                        module_name = from_part.simple_name
                        if module_name in REMOVED_MODULES_312:
                            return _mark_removed(multi, module_name)
                else:
                    # Handle 'import X' pattern (no from clause)
                    for import_node in multi.names:
                        name = _get_import_name(import_node)
                        if name in REMOVED_MODULES_312:
                            return _mark_removed(multi, name)

                return multi

            def visit_import(
                self, import_stmt: Import, p: ExecutionContext
            ) -> Optional[Import]:
                import_stmt = super().visit_import(import_stmt, p)
                if self.cursor.first_enclosing(MultiImport) is not None:
                    return import_stmt
                name = _get_import_name(import_stmt)
                if name in REMOVED_MODULES_312:
                    return _mark_removed(import_stmt, name)
                return import_stmt

        return Visitor()
