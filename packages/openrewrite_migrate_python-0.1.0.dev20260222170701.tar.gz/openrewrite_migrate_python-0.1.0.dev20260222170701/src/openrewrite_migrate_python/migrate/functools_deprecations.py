"""
Recipes for migrating deprecated functools usage patterns.

functools.cmp_to_key is a compatibility function from Python 2 to Python 3.
While not deprecated, using comparison functions is considered outdated.

functools.lru_cache without parentheses is supported since Python 3.8.

See: https://docs.python.org/3/library/functools.html
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers, SearchResult
from rewrite.utils import random_id
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import Identifier, MethodInvocation

# Define category path: Python > Migrate > Python 3.8
_Python38 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.8"),
]


def _mark_deprecated(tree: Any, message: str) -> Any:
    """Add a SearchResult marker for a deprecation warning."""
    search_marker = SearchResult(random_id(), message)
    current_markers = tree.markers
    new_markers_list = list(current_markers.markers) + [search_marker]
    new_markers = Markers(current_markers.id, new_markers_list)
    return tree.replace(_markers=new_markers)


@categorize(_Python38)
class FindFunctoolsCmpToKey(Recipe):
    """
    Find usage of `functools.cmp_to_key()`.

    While not deprecated, `cmp_to_key()` is a Python 2 compatibility function.
    Consider using a key function directly instead of a comparison function.

    Example:
        Before:
            from functools import cmp_to_key
            sorted(items, key=cmp_to_key(compare_func))

        After:
            sorted(items, key=lambda x: (x.field1, x.field2))
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindFunctoolsCmpToKey"

    @property
    def display_name(self) -> str:
        return "Find `functools.cmp_to_key()` usage"

    @property
    def description(self) -> str:
        return (
            "Find usage of `functools.cmp_to_key()` which is a Python 2 "
            "compatibility function. Consider using a key function directly."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "code-quality", "functools"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "cmp_to_key":
                    return method

                select = method.select
                if isinstance(select, Identifier) and select.simple_name == "functools":
                    return _mark_deprecated(
                        method,
                        "functools.cmp_to_key() is a Python 2 compatibility function. "
                        "Consider using a key function directly."
                    )

                return method

        return Visitor()
