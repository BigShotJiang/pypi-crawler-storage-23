"""Tests for macpath module deprecation migration recipes."""

from rewrite.test import RecipeSpec, python

from openrewrite_migrate_python.migrate.macpath_deprecations import FindMacpathModule


class TestFindMacpathModule:
    """Tests for FindMacpathModule recipe."""

    def test_finds_import_macpath(self):
        spec = RecipeSpec(recipe=FindMacpathModule())
        spec.rewrite_run(
            python(
                "import macpath",
                "/*~~(The `macpath` module was removed in Python 3.8. Use `os.path` instead.)~~>*/import macpath",
            )
        )

    def test_no_change_when_different_module(self):
        spec = RecipeSpec(recipe=FindMacpathModule())
        spec.rewrite_run(
            python("import os.path")
        )
