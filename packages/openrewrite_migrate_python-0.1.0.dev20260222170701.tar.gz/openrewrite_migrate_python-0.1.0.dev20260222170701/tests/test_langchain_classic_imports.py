"""Tests for LangChain classic import and deprecated agent migration recipes."""

import pytest
from rewrite.test import RecipeSpec, python
from openrewrite_migrate_python.migrate.langchain_classic_imports import (
    FindDeprecatedLangchainAgents,
    ReplaceLangchainClassicImports,
    FindLangchainCreateReactAgent,
)


class TestReplaceLangchainClassicImports:
    """Tests for the ReplaceLangchainClassicImports recipe."""

    def test_replaces_chains_import(self):
        """Test that from langchain.chains is migrated to langchain_classic."""
        spec = RecipeSpec(recipe=ReplaceLangchainClassicImports())
        spec.rewrite_run(
            python(
                """
                from langchain.chains import LLMChain
                """,
                """
                from langchain_classic.chains import LLMChain
                """,
            )
        )

    def test_replaces_indexes_import(self):
        """Test that from langchain.indexes is migrated to langchain_classic."""
        spec = RecipeSpec(recipe=ReplaceLangchainClassicImports())
        spec.rewrite_run(
            python(
                """
                from langchain.indexes import VectorstoreIndexCreator
                """,
                """
                from langchain_classic.indexes import VectorstoreIndexCreator
                """,
            )
        )

    def test_replaces_retrievers_import(self):
        """Test that from langchain.retrievers is migrated to langchain_classic."""
        spec = RecipeSpec(recipe=ReplaceLangchainClassicImports())
        spec.rewrite_run(
            python(
                """
                from langchain.retrievers import ContextualCompressionRetriever
                """,
                """
                from langchain_classic.retrievers import ContextualCompressionRetriever
                """,
            )
        )

    def test_replaces_hub_import(self):
        """Test that from langchain import hub is migrated."""
        spec = RecipeSpec(recipe=ReplaceLangchainClassicImports())
        spec.rewrite_run(
            python(
                """
                from langchain import hub
                """,
                """
                from langchain_classic import hub
                """,
            )
        )

    def test_no_change_for_langchain_agents(self):
        """Test that langchain.agents is not migrated (stayed in langchain)."""
        spec = RecipeSpec(recipe=ReplaceLangchainClassicImports())
        spec.rewrite_run(
            python(
                """
                from langchain.agents import create_agent
                """
            )
        )

    def test_no_change_for_langchain_core(self):
        """Test that langchain_core imports are not modified."""
        spec = RecipeSpec(recipe=ReplaceLangchainClassicImports())
        spec.rewrite_run(
            python(
                """
                from langchain_core.messages import HumanMessage
                """
            )
        )

    def test_no_change_for_non_classic_direct_import(self):
        """Test that non-classic direct imports from langchain are not modified."""
        spec = RecipeSpec(recipe=ReplaceLangchainClassicImports())
        spec.rewrite_run(
            python(
                """
                from langchain import agents
                """
            )
        )

    def test_no_change_for_unrelated_import(self):
        """Test that unrelated imports are not modified."""
        spec = RecipeSpec(recipe=ReplaceLangchainClassicImports())
        spec.rewrite_run(
            python(
                """
                from os.path import join
                """
            )
        )


class TestFindDeprecatedLangchainAgents:
    """Tests for the FindDeprecatedLangchainAgents recipe."""

    @pytest.mark.requires_dev_openrewrite
    def test_finds_initialize_agent(self):
        """Test that initialize_agent usage is flagged."""
        spec = RecipeSpec(recipe=FindDeprecatedLangchainAgents())
        spec.rewrite_run(
            python(
                """
                from langchain.agents import initialize_agent
                """,
                """
                /*~~(Deprecated LangChain API: initialize_agent (use create_agent / LangGraph in v1.0))~~>*/from langchain.agents import initialize_agent
                """,
            )
        )

    @pytest.mark.requires_dev_openrewrite
    def test_finds_agent_executor(self):
        """Test that AgentExecutor usage is flagged."""
        spec = RecipeSpec(recipe=FindDeprecatedLangchainAgents())
        spec.rewrite_run(
            python(
                """
                from langchain.agents import AgentExecutor
                """,
                """
                /*~~(Deprecated LangChain API: AgentExecutor (use create_agent / LangGraph in v1.0))~~>*/from langchain.agents import AgentExecutor
                """,
            )
        )

    @pytest.mark.requires_dev_openrewrite
    def test_finds_llm_chain(self):
        """Test that LLMChain usage is flagged."""
        spec = RecipeSpec(recipe=FindDeprecatedLangchainAgents())
        spec.rewrite_run(
            python(
                """
                from langchain.chains import LLMChain
                """,
                """
                /*~~(Deprecated LangChain API: LLMChain (use create_agent / LangGraph in v1.0))~~>*/from langchain.chains import LLMChain
                """,
            )
        )

    def test_no_change_for_non_deprecated(self):
        """Test that non-deprecated imports are not flagged."""
        spec = RecipeSpec(recipe=FindDeprecatedLangchainAgents())
        spec.rewrite_run(
            python(
                """
                from langchain.agents import create_agent
                """
            )
        )

    def test_no_change_for_unrelated_import(self):
        """Test that unrelated imports are not flagged."""
        spec = RecipeSpec(recipe=FindDeprecatedLangchainAgents())
        spec.rewrite_run(
            python(
                """
                from os.path import join
                """
            )
        )


class TestFindLangchainCreateReactAgent:
    """Tests for the FindLangchainCreateReactAgent recipe."""

    @pytest.mark.requires_dev_openrewrite
    def test_finds_create_react_agent(self):
        """Test that create_react_agent usage is flagged."""
        spec = RecipeSpec(recipe=FindLangchainCreateReactAgent())
        spec.rewrite_run(
            python(
                """
                from langgraph.prebuilt import create_react_agent
                """,
                """
                /*~~(Migrate to `from langchain.agents import create_agent` (LangChain v1.0))~~>*/from langgraph.prebuilt import create_react_agent
                """,
            )
        )

    def test_no_change_for_unrelated_import(self):
        """Test that unrelated imports are not modified."""
        spec = RecipeSpec(recipe=FindLangchainCreateReactAgent())
        spec.rewrite_run(
            python(
                """
                from os.path import join
                """
            )
        )

    def test_no_change_for_other_langgraph(self):
        """Test that non-prebuilt langgraph imports are not modified."""
        spec = RecipeSpec(recipe=FindLangchainCreateReactAgent())
        spec.rewrite_run(
            python(
                """
                from langgraph.graph import StateGraph
                """
            )
        )
