"""Tests for os module deprecation migration recipes."""

from rewrite.test import RecipeSpec, python
from openrewrite_migrate_python.migrate.os_deprecations import (
    FindOsPopen,
    FindOsSpawn,
)


class TestFindOsPopen:
    """Tests for the FindOsPopen recipe."""

    def test_finds_os_popen(self):
        spec = RecipeSpec(recipe=FindOsPopen())
        spec.rewrite_run(
            python(
                "output = os.popen('ls')",
                "output = /*~~(os.popen() is deprecated since Python 3.6. Use subprocess.run() or subprocess.Popen() instead.)~~>*/os.popen('ls')",
            )
        )

    def test_no_change_when_not_os_popen(self):
        spec = RecipeSpec(recipe=FindOsPopen())
        spec.rewrite_run(
            python(
                """
                class MyClass:
                    def popen(self):
                        pass

                obj = MyClass()
                obj.popen()
                """
            )
        )


class TestFindOsSpawn:
    """Tests for the FindOsSpawn recipe."""

    def test_finds_os_spawnl(self):
        spec = RecipeSpec(recipe=FindOsSpawn())
        spec.rewrite_run(
            python(
                "os.spawnl(os.P_WAIT, '/bin/ls', 'ls')",
                "/*~~(os.spawnl() is deprecated. Use subprocess.run() or subprocess.Popen() instead.)~~>*/os.spawnl(os.P_WAIT, '/bin/ls', 'ls')",
            )
        )

    def test_no_change_when_not_os_spawn(self):
        spec = RecipeSpec(recipe=FindOsSpawn())
        spec.rewrite_run(
            python(
                """
                class ProcessManager:
                    def spawnl(self, *args):
                        pass

                pm = ProcessManager()
                pm.spawnl('arg1', 'arg2')
                """
            )
        )
