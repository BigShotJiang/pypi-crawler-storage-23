"""Tests for tarfile module deprecation migration recipes."""

from rewrite.test import RecipeSpec, python

from openrewrite_migrate_python.migrate.tarfile_deprecations import FindTarfileFilemode


class TestFindTarfileFilemode:
    """Tests for FindTarfileFilemode recipe."""

    def test_finds_tarfile_filemode(self):
        spec = RecipeSpec(recipe=FindTarfileFilemode())
        spec.rewrite_run(
            python(
                "mode_str = tarfile.filemode(mode)",
                "mode_str = /*~~(tarfile.filemode was removed in Python 3.8. Use stat.filemode() instead.)~~>*/tarfile.filemode(mode)",
            )
        )

    def test_no_change_when_different_module(self):
        spec = RecipeSpec(recipe=FindTarfileFilemode())
        spec.rewrite_run(
            python("mode = stat.filemode(0o755)")
        )
