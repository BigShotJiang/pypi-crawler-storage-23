# import libs
import pyThermoEst as pte
from rich import print

# version
print(pte.__version__)

# estimate
pte.estimate()