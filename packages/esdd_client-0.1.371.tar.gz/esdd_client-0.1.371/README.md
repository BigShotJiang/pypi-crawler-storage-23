# ESDD Client

[![PyPI](https://img.shields.io/pypi/v/esdd-client.svg?style=flat)](https://pypi.org/project/esdd-client)

This is the API client for the online platform [ESDD](https://esdd.io) (evaluation, standardization, and derived data).
Install it with `pip install esdd-client`.

## Basic commands

### Authentication via Github

```bash
# Get authorization URL
esdd auth github
# you also can use MPDS platform for login
# Copy URL to browser, authorize, get access token from url

# set token
esdd auth set-token <token>

# Check token
esdd auth info
```

### Working with tasks

```bash
# Create task
esdd task create --question "Annotate dataset" --bid 50

# List tasks
esdd task list
esdd task list --status pending --limit 5

# Get task details
esdd task get 123

# Assign to user
esdd task assign 123 456

# Start task
esdd task start 123

# Finalize with data
esdd task update 123 --json_data '{"result": "completed"}'
esdd task finalize 123

# Approve/Reject
esdd task approve 123
esdd task reject 123
```

### Complete workflow example

```bash
# 1. Login as admin
esdd auth set-token <admin_token>

# 2. Create and assign task
esdd task create --question "Validate data" --assign-to 789 --bid 100

# 3. Login as assessor
esdd auth logout
esdd auth set-token <assessor_token>

# 4. Perform a task
esdd task list
esdd task start <task_id>
esdd task finalize <task_id>

# 5. Return as admin
esdd auth logout
esdd auth set-token <admin_token>
esdd  task approve <task_id>
```

## License

MIT &copy; Gumar Arutynian, Materials Platform for Data Science OÜ
