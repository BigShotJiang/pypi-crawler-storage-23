import os
from typing import Dict
from urllib.parse import urlencode

import httpx


class MPDSOAuthRepository:
    def __init__(self, api_url: str = None):
        self.api_url = (
            api_url or f"{os.getenv('API_URL', 'http://localhost:8000').rstrip('/')}/api/v1"
        )

    def generate_auth_url(self, redirect_url: str = None) -> str:
        params = {}
        if redirect_url:
            params["redirect"] = redirect_url
        query_string = f"?{urlencode(params)}" if params else ""
        return f"{self.api_url}/auth/mpds{query_string}"

    async def get_token(
        self, authorization_code: str, redirect_uri: str = None
    ) -> Dict:
        base_url = os.getenv("BASE_URL", "http://localhost:8000")
        actual_redirect_uri = redirect_uri or f"{base_url}/auth/callback/mpds"

        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{self.api_url}/auth/exchange",
                json={
                    "provider": "mpds",
                    "code": authorization_code,
                    "redirect_uri": actual_redirect_uri,
                },
                timeout=30.0,
            )
            response.raise_for_status()
            return response.json()
