import os
from typing import Dict
from urllib.parse import urlencode

import httpx

from app.src.domain.repositories.auth_repository import AuthRepository


class GitOAuthRepository(AuthRepository):
    def __init__(self, api_url: str = None):
        self.api_url = api_url or f"{os.getenv('API_URL').rstrip('/')}/api/v1"

    def generate_auth_url(self, redirect_url: str = None) -> str:
        params = {}
        if redirect_url:
            params["redirect"] = redirect_url
        query_string = f"?{urlencode(params)}" if params else ""
        return f"{self.api_url}/auth/github{query_string}"

    async def get_token(
        self, authorization_code: str, redirect_uri: str = None
    ) -> Dict:
        base_url = os.getenv("API_URL").rstrip("/")
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{self.api_url}/auth/exchange",
                json={
                    "provider": "github",
                    "code": authorization_code,
                    "redirect_uri": redirect_uri or f"{base_url}/auth/callback/github",
                },
            )
            response.raise_for_status()
            return response.json()
