# ALogin v0.0.1

ALogin is an experimental CLI authentication helper for Python.

## Installation

pip install alogin

## Usage

from alogin import create_account

create_account()