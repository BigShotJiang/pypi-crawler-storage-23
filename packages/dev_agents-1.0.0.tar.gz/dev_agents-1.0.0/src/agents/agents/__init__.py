"""Concrete AI agent implementations."""

__all__: list[str] = []
