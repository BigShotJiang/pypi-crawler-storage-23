"""Application entrypoints for different interfaces."""

__all__: list[str] = []
