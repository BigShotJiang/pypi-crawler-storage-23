# Import providers to ensure they're registered
import integrations.bitbucket  # noqa: F401
import integrations.devops  # noqa: F401
import integrations.github  # noqa: F401
import integrations.gitlab  # noqa: F401
import integrations.jira  # noqa: F401
