"""Slack integration components."""

from .slack_client_service import SlackClientService

__all__ = [
    "SlackClientService",
]
