Publish a new version of `academic-search-mcp` to PyPI.

Argument: version type — one of `beta` or `release`.

Steps:

1. Read the current version from `pyproject.toml`.
2. Determine the next version based on the argument:
   - `beta`: If current is `X.Y.Zb1`, bump to `X.Y.Zb2` (increment beta number). If current is `X.Y.Z` (release), bump to `X.Y.(Z+1)b1`.
   - `release`: If current is `X.Y.ZbN`, strip the beta suffix → `X.Y.Z`. If current is `X.Y.Z`, bump patch → `X.Y.(Z+1)`.
3. Update the `version` field in `pyproject.toml` with the new version.
4. Show the version change and ask for confirmation before proceeding.
5. Run `python -m build` in the project root to build the package.
6. Run `twine upload dist/academic_search_mcp-<new_version>*` to upload to PyPI.
7. Report success or failure.

Important:
- Always clean old builds first: delete `dist/` directory before building.
- If twine or build is not installed, install them with `pip install build twine`.
- Do NOT commit or push anything — just build and upload.
