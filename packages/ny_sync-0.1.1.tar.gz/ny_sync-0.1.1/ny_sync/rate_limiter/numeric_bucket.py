import time
import redis
from .base_bucket import BaseTokenBucket

class NumericTokenBucket(BaseTokenBucket):
    """
    A Token Bucket implementation using the Generic Cell Rate Algorithm (GCRA).
    It uses purely numerical calculation on Redis keys (floats) without complex Lua logic
    (though we use a tiny Lua script for atomicity of the GET-SET cycle, or just INCRBYFLOAT).
    
    Actually, to be strictly 'numerical' and efficient without Lua overhead (if that's the goal),
    we can use a simplified Lua script that just does math on one key.
    
    GCRA Logic:
    - TAT (Theoretical Arrival Time): The time when the next token will be available.
    - emission_interval = 1 / rate
    - burst_offset = capacity * emission_interval
    
    Algorithm:
    - allow_at = tat - burst_offset
    - if now < allow_at: Denied (too soon)
    - else: Allowed, new_tat = max(now, tat) + emission_interval
    """
    
    # GCRA Lua Script
    # KEYS[1] - key (stores TAT)
    # ARGV[1] - rate
    # ARGV[2] - capacity
    # ARGV[3] - now (seconds)
    # ARGV[4] - requested (tokens)
    _GCRA_SCRIPT = """
    local key = KEYS[1]
    local rate = tonumber(ARGV[1])
    local capacity = tonumber(ARGV[2])
    local now = tonumber(ARGV[3])
    local requested = tonumber(ARGV[4])
    
    local emission_interval = 1.0 / rate
    local burst_offset = capacity * emission_interval
    local increment = requested * emission_interval
    
    local tat = tonumber(redis.call("GET", key))
    if tat == nil then
        tat = now
    end
    
    -- calculate new tat
    local new_tat = math.max(now, tat) + increment
    local allow_at = new_tat - burst_offset
    
    if allow_at <= now then
        -- Allowed
        redis.call("SET", key, new_tat, "EX", math.ceil(burst_offset + 10))
        return {1, 0} -- 1=Allowed, 0=Remaining (not easy to calc exactly like token bucket)
    end
    
    return {0, 0}
    """

    def __init__(self, redis_client: redis.Redis, prefix: str = "any_sync_gcra:", max_local_tokens: int = 1):
        super().__init__(redis_client, prefix, max_local_tokens)
        self._script = self.redis.register_script(self._GCRA_SCRIPT)

    def _fetch_tokens(self, key: str, capacity: int, rate: float, to_fetch: int, requested: int) -> tuple[bool, float]:
        now = time.time()
        
        # Try to fetch batch
        result = self._script(
            keys=[key],
            args=[rate, capacity, now, to_fetch]
        )
        
        if bool(result[0]):
            return True, float(to_fetch - requested)
            
        # Fallback if batch denied
        if to_fetch > requested:
            retry_result = self._script(
                keys=[key],
                args=[rate, capacity, now, requested]
            )
            return bool(retry_result[0]), 0.0
            
        return False, 0.0

    def get_remaining_tokens(self, key: str, capacity: int, rate: float) -> float:
        """
        Calculate remaining tokens based on TAT.
        remaining = (now - (tat - burst_offset)) / emission_interval
        = (now - tat + burst_offset) * rate
        """
        data_key = self._get_data_key(key)
        
        # Handle potential key type mismatch
        try:
            tat = self.redis.get(data_key)
        except redis.ResponseError:
            # Key exists but is wrong type (e.g. hash from Lua implementation)
            return float(capacity)
            
        if tat is None:
            return float(capacity)
            
        try:
            tat = float(tat)
        except (ValueError, TypeError):
            return float(capacity)
            
        now = time.time()
        emission_interval = 1.0 / rate
        burst_offset = capacity * emission_interval
        
        consumed = max(0, tat - now) * rate
        remaining = max(0, capacity - consumed)
        
        return float(remaining)

    def reset(self, key: str):
        data_key = self._get_data_key(key)
        self.redis.delete(data_key)
