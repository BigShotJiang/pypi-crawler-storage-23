import time
import redis
from typing import Optional, Dict
from collections import defaultdict
from abc import ABC, abstractmethod

class BaseTokenBucket(ABC):
    """
    Abstract base class for Token Bucket implementations.
    Handles local caching (batching) and key prefixing.
    """
    DEFAULT_PREFIX = "any_sync_limiter:"

    def __init__(self, redis_client: redis.Redis, prefix: str = DEFAULT_PREFIX, max_local_tokens: int = 1):
        self.redis = redis_client
        self.prefix = prefix
        self.max_local_tokens = max_local_tokens
        self.local_tokens: Dict[str, float] = defaultdict(float)

    def _get_namespaced_key(self, key: str) -> str:
        """Helper to ensure key has the correct prefix."""
        if key.startswith(self.prefix):
            return key
        return f"{self.prefix}{key}"

    def _get_data_key(self, key: str) -> str:
        """Helper to get the data key (token:{namespaced_key})."""
        namespaced = self._get_namespaced_key(key)
        return f"token:{namespaced}"

    def _get_config_key(self, key: str) -> str:
        """Helper to get the config key (config:{namespaced_key})."""
        namespaced = self._get_namespaced_key(key)
        return f"config:{namespaced}"

    def _to_str(self, value) -> str:
        if isinstance(value, bytes):
            return value.decode("utf-8", errors="replace")
        if isinstance(value, str):
            return value
        return str(value)

    def allow(self, key: str, capacity: int, rate: float, requested: int = 1) -> bool:
        """
        Check if the request is allowed.
        """
        # 1. Try to fulfill from local cache first
        if self.local_tokens[key] >= requested:
            self.local_tokens[key] -= requested
            return True
        
        # 2. If not enough locally, determine how many to fetch
        to_fetch = max(requested, self.max_local_tokens)
        
        # 3. Call backend specific implementation
        data_key = self._get_data_key(key)
        granted, remaining_in_cache = self._fetch_tokens(data_key, capacity, rate, to_fetch, requested)
        
        if granted:
            # We consumed 'requested' tokens, the rest is in cache
            if remaining_in_cache > 0:
                self.local_tokens[key] += remaining_in_cache
            return True
            
        return False

    @abstractmethod
    def _fetch_tokens(self, key: str, capacity: int, rate: float, to_fetch: int, requested: int) -> tuple[bool, float]:
        """
        Fetch tokens from Redis.
        Returns: (allowed, tokens_remaining_for_local_cache)
        """
        pass

    @abstractmethod
    def get_remaining_tokens(self, key: str, capacity: int, rate: float) -> float:
        """Get estimated remaining tokens."""
        pass

    @abstractmethod
    def reset(self, key: str):
        """Reset the limiter for a key."""
        pass

    def get_all_keys(self) -> list[str]:
        """List all keys managed by this limiter (matching token:{prefix}*)."""
        pattern = f"token:{self.prefix}*"
        keys = self.redis.keys(pattern)
        result: list[str] = []
        token_prefix = f"token:{self.prefix}"
        for k in keys:
            key_str = self._to_str(k)
            if key_str.startswith(token_prefix):
                result.append(key_str[len(token_prefix):])
            else:
                result.append(key_str)
        return result

    def clear_all(self) -> int:
        """Delete all keys managed by this limiter. Returns count of deleted keys."""
        pattern = f"token:{self.prefix}*"
        keys = self.redis.keys(pattern)
        if keys:
            return self.redis.delete(*keys)
        return 0

    def get_stats(self, key: str) -> dict:
        """Get raw stats from Redis for debugging."""
        data_key = self._get_data_key(key)
        key_type = self.redis.type(data_key)
        ttl = self.redis.ttl(data_key)
        key_type_str = self._to_str(key_type)
        
        stats = {
            "key": data_key,
            "type": key_type_str,
            "ttl": ttl
        }
        
        if key_type_str == "hash":
            data = self.redis.hgetall(data_key)
            stats["data"] = {self._to_str(k): self._to_str(v) for k, v in data.items()}
        elif key_type_str == "string":
            data = self.redis.get(data_key)
            stats["data"] = self._to_str(data) if data is not None else None
        else:
            stats["data"] = None
            
        return stats

    def set_config(self, key: str, capacity: int, rate: float):
        """Persist capacity and rate configuration to Redis."""
        config_key = self._get_config_key(key)
        self.redis.hset(config_key, mapping={"capacity": capacity, "rate": rate})
        # Set config TTL slightly longer than key TTL (e.g., 24h)
        self.redis.expire(config_key, 86400)

    def get_config(self, key: str) -> Optional[Dict[str, float]]:
        """Retrieve persisted capacity and rate configuration from Redis."""
        config_key = self._get_config_key(key)
        config = self.redis.hgetall(config_key)
        if not config:
            return None
            
        # Helper to get value regardless of bytes/str key
        def get_val(k):
            if k in config: return config[k]
            if isinstance(k, str):
                kb = k.encode('utf-8')
                if kb in config: return config[kb]
            return 0

        return {
            "capacity": float(get_val("capacity")),
            "rate": float(get_val("rate"))
        }
