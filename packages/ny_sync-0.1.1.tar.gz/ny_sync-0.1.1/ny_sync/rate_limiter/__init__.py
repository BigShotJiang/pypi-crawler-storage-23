from .lua_implementation import LuaTokenBucket
from .numeric_bucket import NumericTokenBucket
from .string_bucket import StringTokenBucket

class RateUnit:
    """
    Constants for rate calculation (seconds per unit).
    Usage: rate = capacity / RateUnit.MINUTE
    """
    SECOND = 1
    MINUTE = 60
    HOUR = 3600
    DAY = 86400
    WEEK = 604800

# Default implementation (backward compatible)
RedisTokenBucket = LuaTokenBucket

__all__ = ["RedisTokenBucket", "LuaTokenBucket", "NumericTokenBucket", "StringTokenBucket", "RateUnit"]
