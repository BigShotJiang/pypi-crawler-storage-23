import time
import redis
from .base_bucket import BaseTokenBucket

class LuaTokenBucket(BaseTokenBucket):
    """
    A Redis-based Token Bucket implementation using Lua scripts for atomicity.
    This is the default implementation, suitable for high concurrency.
    """
    
    # Lua script for atomic token bucket operations
    _LUA_SCRIPT = """
    local key = KEYS[1]
    local capacity = tonumber(ARGV[1])
    local rate = tonumber(ARGV[2])
    local now = tonumber(ARGV[3])
    local requested = tonumber(ARGV[4])

    local last_tokens = tonumber(redis.call("HGET", key, "tokens"))
    local last_refill = tonumber(redis.call("HGET", key, "last_refill"))

    if last_tokens == nil then
        last_tokens = capacity
        last_refill = now
    end

    local delta = math.max(0, now - last_refill)
    local filled_tokens = math.min(capacity, last_tokens + (delta * rate))
    
    local allowed = 0
    local new_tokens = filled_tokens

    if filled_tokens >= requested then
        allowed = 1
        new_tokens = filled_tokens - requested
    end

    redis.call("HSET", key, "tokens", new_tokens, "last_refill", now)
    redis.call("EXPIRE", key, 86400)

    -- Return allowed status and remaining tokens for observability
    return {allowed, new_tokens}
    """
    
    def __init__(self, redis_client: redis.Redis, prefix: str = BaseTokenBucket.DEFAULT_PREFIX, max_local_tokens: int = 1):
        super().__init__(redis_client, prefix, max_local_tokens)
        self._script = self.redis.register_script(self._LUA_SCRIPT)

    def _fetch_tokens(self, key: str, capacity: int, rate: float, to_fetch: int, requested: int) -> tuple[bool, float]:
        now = time.time()
        
        # Call Redis
        result = self._script(
            keys=[key],
            args=[capacity, rate, now, to_fetch]
        )
        
        allowed_by_redis = bool(result[0])
        
        if allowed_by_redis:
            # Redis granted 'to_fetch' tokens.
            # We consume 'requested' immediately.
            # Store the rest in local cache.
            return True, float(to_fetch - requested)
        
        # Fallback: If Redis denied the batch, but we only needed a small amount?
        if to_fetch > requested:
            # Retry with exact amount
            retry_result = self._script(
                keys=[key],
                args=[capacity, rate, now, requested]
            )
            return bool(retry_result[0]), 0.0
            
        return False, 0.0

    def get_remaining_tokens(self, key: str, capacity: int, rate: float) -> float:
        data_key = self._get_data_key(key)
        pipeline = self.redis.pipeline()
        pipeline.hget(data_key, "tokens")
        pipeline.hget(data_key, "last_refill")
        
        try:
            tokens, last_refill = pipeline.execute()
        except redis.ResponseError:
            # Handle WRONGTYPE error if key exists but is not a Hash (e.g. old string key)
            return float(capacity)

        if tokens is None or last_refill is None:
            return float(capacity)
        
        try:
            tokens = float(tokens)
            last_refill = float(last_refill)
        except (ValueError, TypeError):
             return float(capacity)
             
        now = time.time()
        delta = max(0, now - last_refill)
        return min(float(capacity), tokens + (delta * rate))

    def reset(self, key: str):
        data_key = self._get_data_key(key)
        self.redis.delete(data_key)
