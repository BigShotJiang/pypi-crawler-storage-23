import redis
import time
from typing import Optional, List, Dict
from .base_bucket import BaseTokenBucket

class StringTokenBucket(BaseTokenBucket):
    """
    A "Slot-based" (Semaphore) implementation using Redis Strings.
    
    This is an "aggressive" implementation where "One Token = One String Key".
    
    Logic:
    - We have `capacity` slots.
    - Each slot is a key: `token:{prefix}:{key}:slot:{i}` where i in [0, capacity-1].
    - When a token is consumed, we find a free slot and SET it with a TTL.
    - TTL = `capacity / rate`.
    - The slot remains occupied until TTL expires, at which point the token is "returned".
    
    This allows strict "One Token One String" mapping and enables visualization of
    individual token lifecycles.
    """
    
    # Lua script to find a free slot and occupy it
    # KEYS[1] = base_key_prefix (e.g., "token:prefix:user")
    # ARGV[1] = capacity
    # ARGV[2] = ttl (seconds)
    # ARGV[3] = random_seed (int)
    _SLOT_SCRIPT = """
    local prefix = KEYS[1]
    local capacity = tonumber(ARGV[1])
    local ttl = tonumber(ARGV[2])
    local seed = tonumber(ARGV[3])
    
    -- Seed the random number generator
    math.randomseed(seed)
    
    -- 1. Try pure random shots first to scatter keys and decouple sequential dependency
    -- This ensures that under normal load, keys are not sequential.
    local attempts = 3
    for k = 1, attempts do
        local idx = math.random(0, capacity - 1)
        local slot_key = prefix .. ":slot:" .. idx
        local result = redis.call("SET", slot_key, "1", "NX", "EX", ttl)
        if result then
            return {1, idx}
        end
    end
    
    -- 2. Fallback to Linear Probing if random shots collided
    -- We pick a random start index to avoid "hot spots"
    local start_index = math.random(0, capacity - 1)
    
    for i = 0, capacity - 1 do
        -- Wrap around using modulo
        local idx = (start_index + i) % capacity
        local slot_key = prefix .. ":slot:" .. idx
        
        -- Try to acquire the slot
        local result = redis.call("SET", slot_key, "1", "NX", "EX", ttl)
        if result then
            return {1, idx} -- Allowed, slot index
        end
    end
    
    return {0, -1} -- Denied, no free slots
    """

    def __init__(self, redis_client: redis.Redis, prefix: str = 'any_sync_slot', max_local_tokens: int = 1):
        super().__init__(redis_client, prefix, max_local_tokens)
        self._script = self.redis.register_script(self._SLOT_SCRIPT)

    def _fetch_tokens(self, key: str, capacity: int, rate: float, to_fetch: int, requested: int) -> tuple[bool, float]:
        """
        Consume 'requested' tokens using Slot logic.
        Note: This implementation only supports consuming 1 token at a time effectively due to slot loop.
        If requested > 1, we would need to acquire multiple slots.
        For simplicity and "One Token One String" purity, we loop in Python or assume requested=1.
        """
        # Calculate TTL for each token
        if rate <= 0: ttl = 60 # Default fallback
        else: ttl = max(1, int(capacity / rate))
        
        # We only support fetching 1 token per call effectively in this simple slot model
        # If batching is requested, we might fail if we can't get all.
        # But BaseTokenBucket handles batching. Let's try to get 'to_fetch' slots?
        # The Lua script only gets 1 slot.
        # Let's just try to get 'requested' slots.
        
        acquired = 0
        for _ in range(requested):
            try:
                # Generate a seed for each attempt to ensure randomness
                # Use high-res timestamp + loop index to avoid collisions in tight loops
                seed = int(time.time() * 1000000) + _
                
                result = self._script(
                    keys=[key], # key is already full data key
                    args=[capacity, ttl, seed]
                )
                if result[0]:
                    acquired += 1
                else:
                    break
            except redis.RedisError:
                break
        
        if acquired >= requested:
            # We got enough
            return True, float(acquired - requested) # Return extra to cache?
            # Actually, with slots, "Cache" is tricky because slots expire.
            # If we cache them locally, we hold the slot but haven't used it?
            # No, we just "burned" the slot on Redis.
            # So effectively we consumed them.
            return True, 0.0 
        else:
            # We didn't get enough. We should release the ones we got?
            # Ideally yes, but for simplicity/robustness we might just let them expire (leak).
            # Implementing rollback is complex.
            return False, 0.0

    def get_remaining_tokens(self, key: str, capacity: int, rate: float) -> float:
        """
        Count free slots.
        """
        data_key = self._get_data_key(key)
        pattern = f"{data_key}:slot:*"
        
        # This is expensive (O(N)), but "Aggressive" was requested.
        # We can use EVAL to count server side?
        # script = "return #redis.call('KEYS', ARGV[1])" -> unsafe for large DB
        # Let's just scan locally or use a Lua script that loops 0..Cap
        
        script = """
        local prefix = KEYS[1]
        local capacity = tonumber(ARGV[1])
        local used = 0
        for i = 0, capacity - 1 do
            if redis.call("EXISTS", prefix .. ":slot:" .. i) == 1 then
                used = used + 1
            end
        end
        return used
        """
        try:
            used = self.redis.eval(script, 1, data_key, capacity)
            return float(capacity - used)
        except redis.RedisError:
            return 0.0

    def reset(self, key: str):
        """
        Clear all slots.
        """
        namespaced = self._get_namespaced_key(key)
        pattern = f"token:{namespaced}:slot:*"
        
        cursor = '0'
        while True:
            cursor, keys = self.redis.scan(cursor, match=pattern, count=100)
            if keys:
                self.redis.delete(*keys)
            if cursor == 0:
                break

    def get_history(self, key: str) -> Dict[int, int]:
        """
        Reconstruct history from active slots.
        Since we don't have a log, we use the TTL of active slots to guess when they were created.
        
        Creation Time = Now - (Total_TTL - Remaining_TTL)
        
        Note: This only shows history for the duration of the TTL window (which is Cap/Rate).
        """
        namespaced = self._get_namespaced_key(key)
        # We need capacity/rate to know Total TTL.
        # But this method signature doesn't provide them.
        # We have to fetch config or guess.
        # Dashboard usually passes config? No.
        # We'll try to get config from Redis if stored, or fallback.
        
        # Try to find config
        config_key = self._get_config_key(key)
        config = self.redis.hgetall(config_key)
        if config:
            capacity = int(config.get(b'capacity', 10))
            rate = float(config.get(b'rate', 1.0))
        else:
            # Fallback defaults if not found
            capacity = 100
            rate = 10.0
            
        if rate <= 0: total_ttl = 60
        else: total_ttl = max(1, int(capacity / rate))
        
        pattern = f"token:{namespaced}:slot:*"
        now = int(time.time())
        history = {}
        
        cursor = '0'
        while True:
            cursor, keys = self.redis.scan(cursor, match=pattern, count=100)
            if keys:
                # We need PTTL for these keys
                pipe = self.redis.pipeline()
                for k in keys:
                    pipe.pttl(k)
                pttls = pipe.execute()
                
                for k, pttl_ms in zip(keys, pttls):
                    if pttl_ms > 0:
                        # pttl is in ms
                        elapsed_sec = total_ttl - (pttl_ms / 1000.0)
                        creation_ts = int(now - elapsed_sec)
                        history[creation_ts] = history.get(creation_ts, 0) + 1
                        
            if cursor == 0:
                break
                
        return dict(sorted(history.items()))
