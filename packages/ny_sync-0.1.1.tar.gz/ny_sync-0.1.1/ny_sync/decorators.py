import functools
import redis
from typing import Callable, Any, Optional
from .rate_limiter import RedisTokenBucket

class RateLimitDecorator:
    def __init__(self, redis_client: redis.Redis, key_prefix: str, capacity: int, rate: float):
        """
        Initialize the rate limit decorator factory.
        
        :param redis_client: The Redis client instance.
        :param key_prefix: Prefix for the rate limit key.
        :param capacity: Bucket capacity.
        :param rate: Refill rate (tokens/sec).
        """
        self.limiter = RedisTokenBucket(redis_client)
        self.key_prefix = key_prefix
        self.capacity = capacity
        self.rate = rate

    def __call__(self, func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            # Construct a unique key for this function call
            # For simplicity, we use the function name. 
            # In a real app, you might want to use user_id or IP from args/kwargs.
            key = f"{self.key_prefix}:{func.__name__}"
            
            if self.limiter.allow(key, self.capacity, self.rate):
                return func(*args, **kwargs)
            else:
                raise RateLimitExceededError(f"Rate limit exceeded for {func.__name__}")
        return wrapper

class RateLimitExceededError(Exception):
    pass
