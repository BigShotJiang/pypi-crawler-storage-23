import streamlit as st
import redis
import time
import pandas as pd
import plotly.graph_objects as go
import sys
import os
from datetime import datetime
from collections import deque
import concurrent.futures

# Add parent directory to path to import any_sync
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ny_sync.rate_limiter import RedisTokenBucket, LuaTokenBucket, NumericTokenBucket, StringTokenBucket

# Page config
st.set_page_config(
    page_title="NySync Rate Limiter Dashboard",
    page_icon="⚡",
    layout="wide"
)

# Initialize Redis Connection
def get_redis_client(host='localhost', port=6379, db=0, password=None):
    try:
        return redis.Redis(host=host, port=port, db=db, password=password, decode_responses=True)
    except Exception as e:
        return None

# Sidebar Configuration
st.sidebar.title("Configuration")

with st.sidebar.expander("🔌 Redis Settings", expanded=False):
    redis_host = st.text_input("Host", "localhost")
    redis_port = st.number_input("Port", 1, 65535, 6379)
    redis_db = st.number_input("DB", 0, 15, 0)
    redis_pass = st.text_input("Password", type="password")
    if not redis_pass: redis_pass = None

r = get_redis_client(redis_host, redis_port, redis_db, redis_pass)

redis_status = "🟢 Connected" if r and r.ping() else "🔴 Disconnected"
st.sidebar.write(f"Redis Status: {redis_status}")


if not r or not r.ping():
    st.error("Could not connect to Redis. Please start Redis server.")
    st.stop()

# Auto-refresh
auto_refresh = st.sidebar.checkbox("Enable Auto-Refresh (2s)", value=False)
if auto_refresh:
    time.sleep(2)
    st.rerun()

# Rate Limiter Strategy Selection
st.sidebar.markdown("---")
st.sidebar.subheader("Limiter Strategy")
strategy_name = st.sidebar.selectbox(
    "Implementation", 
    ["Lua Token Bucket (Default)", "Numeric Token Bucket (GCRA)", "String Token Bucket"],
    help="Lua: Best for concurrency. Numeric (GCRA): Best for large batches & lower CPU. String: Simple implementation."
)

if strategy_name == "Numeric Token Bucket (GCRA)":
    LimiterClass = NumericTokenBucket
elif strategy_name == "String Token Bucket":
    LimiterClass = StringTokenBucket
else:
    LimiterClass = LuaTokenBucket

# Rate Limiter Settings
prefix = LimiterClass.DEFAULT_PREFIX
limiter = LimiterClass(r)


# Navigation
page = st.sidebar.radio("View Mode", ["Overview (List)", "Traffic Simulation"])

# Common Scan Logic
# Use limiter's method to get keys for consistency and correct prefix handling
# Note: limiter.get_all_keys() now scans "token:{prefix}*" and returns logical keys (without token: prefix)
found_keys = sorted(limiter.get_all_keys())

# --- View 1: Overview (List) ---
if page == "Overview (List)":
    st.title("⚡ ny_sync Rate Limiter - Overview")
    st.write(f"Active Limiters: {len(found_keys)}")
    
    st.info(f"Using Strategy: **{strategy_name}** (Prefix: `{prefix}`)")
    if strategy_name == "String Token Bucket":
        st.caption("ℹ️ This strategy uses 'Slot-based' keys (1 key per token). History is reconstructed from active slot TTLs.")

    # History State Management
    if 'histories' not in st.session_state:
        st.session_state.histories = {}

    # Default Params (for visualization estimation)
    st.sidebar.markdown("---")
    st.sidebar.subheader("Visualization Settings")
    default_capacity = st.sidebar.number_input("Est. Capacity", 1, 1000000, 100)
    default_rate = st.sidebar.number_input("Est. Rate (tokens/s)", 0.1, 1000000.0, 10.0)

    # Display List of Limiters
    for key in found_keys:
        # Key cleaning - found_keys already contains logical keys or suffixed keys
        # If get_all_keys returns "user1", then display_name is "user1"
        # If get_all_keys returns "any_sync_limiter:user1" (if prefix matches), we might want to strip it
        
        # In new implementation, get_all_keys returns the suffix after "token:{prefix}".
        # So "token:any_sync_limiter:user1" -> "user1".
        
        display_name = key
        
        # However, for API calls like get_config(key), get_remaining_tokens(key), 
        # the limiter expects the key that was passed to it originally.
        # If we pass "user1", limiter will add prefix "any_sync_limiter:".
        # So "token:any_sync_limiter:user1" matches.
        
        # But wait, if we created keys with "any_sync_limiter:user1", 
        # then get_all_keys logic:
        #   token_prefix = "token:any_sync_limiter:"
        #   key_str = "token:any_sync_limiter:user1"
        #   result.append("user1")
        
        # So 'key' here is 'user1'.
        # If we call limiter.get_config('user1'):
        #   namespaced = _get_namespaced_key('user1') -> 'any_sync_limiter:user1'
        #   config_key = config:any_sync_limiter:user1
        # This matches what we want.
        
        # But what if the user manually entered a full key "any_sync_limiter:user1"?
        # Then _get_namespaced_key returns "any_sync_limiter:user1".
        # Then data_key is "token:any_sync_limiter:user1".
        # This is consistent.
        
        # So 'key' variable here is the clean logical key.
        full_key_display = f"{prefix}{key}" # Just for display purposes

        existing_config = limiter.get_config(key)
        
        if existing_config:
            current_capacity = int(existing_config['capacity'])
            current_rate = float(existing_config['rate'])
            is_config_loaded = True
        else:
            current_capacity = default_capacity
            current_rate = default_rate
            is_config_loaded = False
        
        # Get current status
        tokens = limiter.get_remaining_tokens(key, current_capacity, current_rate)
        
        # Update History
        if key not in st.session_state.histories:
            st.session_state.histories[key] = deque(maxlen=20)
        
        st.session_state.histories[key].append({
            'time': datetime.now(),
            'tokens': tokens
        })

        # Container for each key
        with st.container():
            c1, c2, c3 = st.columns([1, 1, 3])
            
            with c1:
                st.subheader(f"`{display_name}`")
                st.caption(f"Full Key: {full_key_display}")
                
                if is_config_loaded:
                    st.caption(f"⚙️ Config: Cap={current_capacity}, Rate={current_rate:.1f}")
                else:
                    st.caption(f"Default: Cap={current_capacity}, Rate={current_rate:.1f}")
                
                if st.button(f"Reset", key=f"reset_{key}"):
                    limiter.reset(key)
                    st.rerun()

                # Special Visualization for String Token Bucket (History)
                if isinstance(limiter, StringTokenBucket):
                    if st.checkbox("Show Active Slots & History", key=f"peak_{key}"):
                        history = limiter.get_history(key)
                        if history:
                            df_hist = pd.DataFrame([
                                {"time": datetime.fromtimestamp(ts), "count": count} 
                                for ts, count in history.items()
                            ])
                            # Peak is max concurrent slots used (which is max of history if we sum it? No.)
                            # History here is "Creation Time -> Count".
                            # Sum of all counts = Total Active Slots.
                            total_active = df_hist['count'].sum()
                            
                            st.metric("Current Active Slots (Used)", f"{total_active}", f"Capacity: {current_capacity}")
                            st.caption("Reconstructed History (Creation Time of Active Slots):")
                            st.bar_chart(df_hist.set_index("time"))
                        else:
                            st.caption("No active slots found (Bucket full).")
            
            with c2:
                st.metric("Available Tokens", f"{tokens:.2f}")
                st.progress(min(1.0, max(0.0, tokens / current_capacity)))

            with c3:
                # Mini Sparkline
                df = pd.DataFrame(st.session_state.histories[key])
                if not df.empty:
                    fig = go.Figure()
                    fig.add_trace(go.Scatter(
                        x=df['time'], 
                        y=df['tokens'], 
                        mode='lines', 
                        fill='tozeroy',
                        line=dict(color='#00CC96', width=2)
                    ))
                    fig.update_layout(
                        margin=dict(l=0, r=0, t=0, b=0),
                        height=80,
                        xaxis=dict(showgrid=False, visible=False),
                        yaxis=dict(showgrid=False, visible=False, range=[0, current_capacity * 1.1]),
                        paper_bgcolor='rgba(0,0,0,0)',
                        plot_bgcolor='rgba(0,0,0,0)'
                    )
                    st.plotly_chart(fig, use_container_width=True, config={'displayModeBar': False})
            
            st.divider()

    if not found_keys:
        st.info("No active rate limiters found. Run the demo script to generate traffic.")

# --- View 2: Traffic Simulation ---
elif page == "Traffic Simulation":
    st.title("⚡ ny_sync Rate Limiter - Traffic Simulation")

    # Key Selection
    # Add a special option to allow manual entry/creation
    key_options = ["(Create/Custom Key)"] + found_keys
    
    selected_option = st.sidebar.selectbox(
        "Select Target Limiter", 
        key_options
    )
    
    if selected_option == "(Create/Custom Key)":
        current_key_suffix = st.sidebar.text_input("Enter New Key Suffix", "dashboard_demo")
        # In new key scheme, user enters "user1", we use "user1". 
        # The limiter internally adds prefix.
        full_key_to_use = current_key_suffix
    else:
        full_key_to_use = selected_option
        st.sidebar.info(f"Selected: {full_key_to_use}")

    st.write(f"Target Key: `{full_key_to_use}`")
    st.caption(f"Internal Data Key: token:{prefix}{full_key_to_use}")

    # Limiter Configuration for Simulation
    st.sidebar.markdown("---")
    st.sidebar.subheader("Limiter Config")
    
    # Try to load existing config from Redis if available
    existing_config = limiter.get_config(full_key_to_use)
    
    default_capacity = 1000000
    default_rate = 100000.0
    
    if existing_config:
        default_capacity = int(existing_config['capacity'])
        default_rate = float(existing_config['rate'])
        st.sidebar.info(f"Loaded config from Redis")
        
    capacity = st.sidebar.number_input("Bucket Capacity", min_value=1, value=default_capacity)
    rate = st.sidebar.number_input("Refill Rate (tokens/sec)", min_value=0.0001, value=default_rate)
    
    # Auto-save config when changed
    if existing_config is None or capacity != existing_config['capacity'] or rate != existing_config['rate']:
        limiter.set_config(full_key_to_use, capacity, rate)
        # st.sidebar.caption("Config saved to Redis")

    # Session State for Simulation History
    if 'sim_history' not in st.session_state:
        st.session_state.sim_history = []
    if 'requests' not in st.session_state:
        st.session_state.requests = {'allowed': 0, 'denied': 0}
    
    # Reset history if key changes
    if 'last_sim_key' not in st.session_state or st.session_state.last_sim_key != full_key_to_use:
        st.session_state.sim_history = []
        st.session_state.requests = {'allowed': 0, 'denied': 0}
        st.session_state.last_sim_key = full_key_to_use

    # --- Concurrent Test Function ---
    def run_concurrent_test(key, cap, rat, num_threads, requests_per_thread):
        total_requests = num_threads * requests_per_thread
        allowed_count = 0
        denied_count = 0
        
        def worker():
            local_allowed = 0
            local_denied = 0
            # Each thread creates its own Redis connection to simulate real concurrency
            local_r = redis.Redis(host=redis_host, port=redis_port, db=redis_db, password=redis_pass, decode_responses=True)
            local_limiter = LimiterClass(local_r)
            for _ in range(requests_per_thread):
                if local_limiter.allow(key, cap, rat):
                    local_allowed += 1
                else:
                    local_denied += 1
            local_r.close()
            return local_allowed, local_denied

        with concurrent.futures.ThreadPoolExecutor(max_workers=num_threads) as executor:
            futures = [executor.submit(worker) for _ in range(num_threads)]
            for future in concurrent.futures.as_completed(futures):
                a, d = future.result()
                allowed_count += a
                denied_count += d
        
        return allowed_count, denied_count

    # --- Sustained Load Test Function (Multi-threaded) ---
    def run_sustained_test(key, cap, rat, duration_sec, rps, num_threads, batch_size=1):
        start_time = time.time()
        end_time = start_time + duration_sec
        
        # Shared stats
        stats = {'allowed': 0, 'denied': 0}
        
        # We need to distribute the target RPS across threads
        rps_per_thread = rps / num_threads if num_threads > 0 else rps
        
        # Placeholder for real-time chart updates (updated by main thread)
        chart_placeholder = st.empty()
        stats_placeholder = st.empty()
        
        history = []
        
        def worker():
            local_r = redis.Redis(host=redis_host, port=redis_port, db=redis_db, password=redis_pass, decode_responses=True)
            # Initialize with batch_size if > 1
            local_limiter = LimiterClass(local_r, max_local_tokens=batch_size)
            
            local_allowed = 0
            local_denied = 0
            
            delay_per_req = 1.0 / rps_per_thread if rps_per_thread > 0 else 0
            
            while time.time() < end_time:
                loop_start = time.time()
                
                if local_limiter.allow(key, cap, rat):
                    local_allowed += 1
                else:
                    local_denied += 1
                
                # Sleep to maintain rate
                elapsed = time.time() - loop_start
                sleep_time = delay_per_req - elapsed
                if sleep_time > 0:
                    time.sleep(sleep_time)
            
            local_r.close()
            return local_allowed, local_denied

        # Run threads
        with concurrent.futures.ThreadPoolExecutor(max_workers=num_threads) as executor:
            futures = [executor.submit(worker) for _ in range(num_threads)]
            
            # While threads are running, main thread updates UI
            while any(f.running() for f in futures):
                # Update chart/stats periodically
                time.sleep(0.5)
                
                # Get current bucket status (just for visualization)
                current_tokens = limiter.get_remaining_tokens(key, cap, rat)
                history.append({"time": datetime.now(), "tokens": current_tokens})
                if len(history) > 50: history.pop(0)
                
                # Draw Chart
                df = pd.DataFrame(history)
                if not df.empty:
                    fig = go.Figure()
                    fig.add_trace(go.Scatter(x=df['time'], y=df['tokens'], mode='lines+markers', name='Tokens'))
                    fig.add_hline(y=cap, line_dash="dash", annotation_text="Capacity", line_color="red")
                    fig.add_hline(y=0, line_dash="dash", line_color="red")
                    fig.update_layout(title="Real-time Token Bucket Level", height=300, margin=dict(l=20, r=20, t=40, b=20))
                    chart_placeholder.plotly_chart(fig, use_container_width=True, key=f"chart_{time.time()}")
                
                stats_placeholder.info(f"Test Running... Time remaining: {max(0, int(end_time - time.time()))}s")

            # Collect results
            total_allowed = 0
            total_denied = 0
            for future in concurrent.futures.as_completed(futures):
                a, d = future.result()
                total_allowed += a
                total_denied += d
                
        return total_allowed, total_denied

    col1, col2 = st.columns([2, 1])

    with col1:
        st.subheader("Interactive Controls")
        
        c1, c2 = st.columns(2)
        with c1:
            if st.button("Send 1 Request"):
                allowed = limiter.allow(full_key_to_use, capacity, rate)
                status = "Allowed" if allowed else "Denied"
                st.session_state.requests['allowed' if allowed else 'denied'] += 1
                if allowed:
                    st.success(f"Request {status}")
                else:
                    st.error(f"Request {status}")
                
        with c2:
            burst_size = st.number_input("Burst Size", 1, 500000, 5000)
            burst_batch_size = st.number_input("Burst Batch Size", 1, 1000000, 1, help="Set >1 to test batching performance")
            
            if st.button(f"Send Burst ({burst_size})"):
                # Use a local limiter instance to apply batching for this burst test
                burst_limiter = LimiterClass(r, max_local_tokens=burst_batch_size)
                
                start_burst = time.time()
                for _ in range(burst_size):
                    allowed = burst_limiter.allow(full_key_to_use, capacity, rate)
                    st.session_state.requests['allowed' if allowed else 'denied'] += 1
                end_burst = time.time()
                duration = end_burst - start_burst
                rps = burst_size / duration if duration > 0 else 0
                st.info(f"Sent {burst_size} requests in {duration:.4f}s ({rps:.1f} RPS).")

        st.markdown("### 🚀 Concurrent Load Test")
        lc1, lc2 = st.columns(2)
        with lc1:
            num_threads = st.number_input("Threads", 1, 256, 5)
        with lc2:
            req_per_thread = st.number_input("Reqs/Thread", 1, 500000, 3000)
            
        reset_before_test = st.checkbox("Reset Limiter before Test", value=True, help="Ensures the bucket starts full (at Capacity) for accurate load testing.")

        if st.button(f"Run Concurrent Test ({num_threads} threads x {req_per_thread} reqs)"):
            if reset_before_test:
                limiter.reset(full_key_to_use)
                st.toast(f"Limiter {full_key_to_use} reset!", icon="🔄")
                # Add a small delay to ensure Redis propagation if needed, though usually instant
                time.sleep(0.1)

            with st.spinner("Running concurrent test..."):
                start_time = time.time()
                a, d = run_concurrent_test(full_key_to_use, capacity, rate, num_threads, req_per_thread)
                duration = time.time() - start_time
                
                st.session_state.requests['allowed'] += a
                st.session_state.requests['denied'] += d
                
                total_reqs = a + d
                rps = total_reqs / duration if duration > 0 else 0
                
                st.success(f"Completed in {duration:.2f}s ({rps:.1f} RPS)")
                st.write(f"Allowed: {a}, Denied: {d}")

        st.markdown("### ⏱️ Sustained Load Test (Duration)")
        sl1, sl2, sl3, sl4 = st.columns(4)
        with sl1:
            test_duration = st.number_input("Duration (seconds)", 1, 600, 10)
        with sl2:
            target_rps = st.number_input("Target RPS", 1, 500000, 5000)
        with sl3:
            sustained_threads = st.number_input("Threads", 1, 50, 5, key="sustained_threads")
        with sl4:
            batch_size = st.number_input("Batch Size", 1, 1000, 100, help="Local token pre-fetching size")
            
        if st.button(f"Run Sustained Test ({test_duration}s @ {target_rps} RPS, {sustained_threads} threads)"):
             if reset_before_test:
                 limiter.reset(full_key_to_use)
                 st.toast(f"Limiter {full_key_to_use} reset!", icon="🔄")
                 time.sleep(0.1)
                 
             with st.spinner(f"Running for {test_duration} seconds..."):
                 a, d = run_sustained_test(full_key_to_use, capacity, rate, test_duration, target_rps, sustained_threads, batch_size)
                 
                 st.session_state.requests['allowed'] += a
                 st.session_state.requests['denied'] += d
                 st.success(f"Sustained Test Completed: Allowed {a}, Denied {d}")

        st.markdown("### 📊 Max RPS Benchmark")
        st.write("Automatically tests different batch sizes to find maximum throughput.")
        
        bench_col1, bench_col2 = st.columns(2)
        with bench_col1:
             bench_duration = st.number_input("Benchmark Duration (per run)", 1, 10, 3, help="Seconds to run each test iteration")
        with bench_col2:
             bench_threads = st.number_input("Benchmark Threads", 1, 50, 10)
             
        if st.button("Run Max RPS Benchmark"):
            batch_sizes_to_test = [1, 10, 50, 100, 500]
            results = []
            
            progress_bar = st.progress(0)
            status_text = st.empty()
            
            st.write("### Benchmark Results")
            results_table = st.empty()
            
            total_iterations = len(batch_sizes_to_test) * 5 # 5 runs per batch size
            current_iteration = 0
            
            for b_size in batch_sizes_to_test:
                run_total_rps = 0
                runs = 5
                
                for run in range(runs):
                    current_iteration += 1
                    status_text.text(f"Testing Batch Size: {b_size} (Run {run+1}/{runs})...")
                    progress_bar.progress(current_iteration / total_iterations)
                    
                    # Reset limiter for clean slate
                    limiter.reset(full_key_to_use)
                    time.sleep(0.05)
                    
                    # Run test with very high target RPS to hit limit
                    # We use a high target (100k) to ensure we hit the processing limit
                    a, d = run_sustained_test(full_key_to_use, capacity, rate, bench_duration, 100000, bench_threads, b_size)
                    
                    actual_rps = (a + d) / bench_duration
                    run_total_rps += actual_rps
                    
                avg_rps = run_total_rps / runs
                results.append({"Batch Size": b_size, "Avg RPS": f"{avg_rps:.2f}"})
                
                # Update table incrementally
                results_table.table(pd.DataFrame(results))
                
            status_text.success("Benchmark Completed!")

        if st.button("Reset Current Limiter"):
            limiter.reset(full_key_to_use)
            st.session_state.requests = {'allowed': 0, 'denied': 0}
            st.session_state.sim_history = []
            st.success("Limiter Reset")

        st.markdown("---")
        st.subheader("🛠️ Limiter Management")
        
        m1, m2, m3 = st.columns(3)
        
        with m1:
            if st.button("List All Keys"):
                keys = limiter.get_all_keys()
                st.session_state['managed_keys'] = keys
                if not keys:
                    st.info("No keys found.")
                else:
                    st.success(f"Found {len(keys)} keys.")
        
        with m2:
            if st.button("Clear All Keys"):
                count = limiter.clear_all()
                st.warning(f"Deleted {count} keys.")
                st.session_state['managed_keys'] = []
                    
        with m3:
            if st.button("Get Key Stats"):
                stats = limiter.get_stats(full_key_to_use)
                # st.json(stats)
                
                if stats:
                    selected_key = full_key_to_use
                    key_type = stats.get('type', 'unknown')
                    ttl = stats.get('ttl', -1)
                    key_data = stats.get('value', stats)

                    st.write("---")
                    st.subheader("Key Details")
                    st.write(f"**Key:** `{selected_key}`")
                    st.write(f"**Type:** `{key_type}`")
                    st.write(f"**TTL:** `{ttl}s`")
                    
                    # Display data based on type
                    if key_type == 'string':
                        st.write(f"**Value:** `{key_data}`")
                        # If using StringTokenBucket, interpret value as usage
                        if isinstance(limiter, StringTokenBucket):
                            # Try to show history summary instead of just one value
                            try:
                                history = limiter.get_history(selected_key)
                                if history:
                                    max_usage = max(history.values())
                                    total_usage = sum(history.values())
                                    st.metric("Peak Usage (History)", f"{max_usage}", f"Total: {total_usage}")
                                    st.json(history)
                                else:
                                    st.info("No history found.")
                            except:
                                pass
                    elif key_type == 'hash':
                        st.json(key_data)
                        if isinstance(key_data, dict) and 'tokens' in key_data:
                            st.metric("Remaining Tokens", f"{float(key_data['tokens']):.2f}")
                    else:
                        st.json(key_data)
                else:
                    st.info("No data found for key.")

        if 'managed_keys' in st.session_state and st.session_state['managed_keys']:
            st.write("Active Keys:", st.session_state['managed_keys'])

    with col2:
        st.subheader("Session Stats")
        st.metric("Allowed", st.session_state.requests['allowed'])
        st.metric("Denied", st.session_state.requests['denied'])
        
        total = st.session_state.requests['allowed'] + st.session_state.requests['denied']
        if total > 0:
            allow_rate = (st.session_state.requests['allowed'] / total) * 100
            st.metric("Success Rate", f"{allow_rate:.1f}%")

    # Charting
    current_tokens = limiter.get_remaining_tokens(full_key_to_use, capacity, rate)
    st.session_state.sim_history.append({
        "time": datetime.now(),
        "tokens": current_tokens
    })
    
    if len(st.session_state.sim_history) > 50:
        st.session_state.sim_history = st.session_state.sim_history[-50:]

    df = pd.DataFrame(st.session_state.sim_history)
    if not df.empty:
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=df['time'], y=df['tokens'], mode='lines+markers', name='Tokens'))
        fig.add_hline(y=capacity, line_dash="dash", annotation_text="Capacity", line_color="red")
        fig.add_hline(y=0, line_dash="dash", line_color="red")
        fig.update_layout(
            title="Real-time Token Bucket Level",
            yaxis_title="Available Tokens",
            yaxis_range=[-0.5, capacity + 0.5],
            height=400
        )
        st.plotly_chart(fig, use_container_width=True)
