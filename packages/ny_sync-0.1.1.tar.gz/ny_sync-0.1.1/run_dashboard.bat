@echo off
echo Installing dashboard requirements...
pip install streamlit plotly pandas redis
if %ERRORLEVEL% NEQ 0 (
    echo Failed to install requirements.
    pause
    exit /b
)

echo Starting Dashboard...
echo Open your browser to the URL shown below.
cd /d "%~dp0"
streamlit run ny_sync/dashboard.py
pause
