from setuptools import setup, find_packages
from pathlib import Path


project_root = Path(__file__).resolve().parent

requirements_path = project_root / "requirements.txt"
if not requirements_path.exists():
    raise FileNotFoundError(f"requirements.txt not found: {requirements_path}")

all_requires = [
    line.strip()
    for line in requirements_path.read_text(encoding="utf-8").splitlines()
    if line.strip()
]
install_requires = []
for line in all_requires:
    if line.startswith("# Dashboard dependencies"):
        break
    install_requires.append(line)

try:
    long_desc = (project_root / "README.md").read_text(encoding="utf-8")
except Exception:
    long_desc = ""

setup(
    name="ny_sync",
    version="0.1.1",
    description="A Python SDK for ny_sync: Distributed Token Bucket Rate Limiter",
    long_description=long_desc,
    long_description_content_type="text/markdown",
    author="ny_sync Team",
    author_email="readerror000@outlook.com",
    url="https://github.com/djmin/ny_sync",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
    install_requires=install_requires,
    extras_require={
        "dashboard": ["streamlit>=1.0.0", "plotly>=5.0.0", "pandas>=1.0.0"],
    },
)
