"""CLI for FastAPI projects."""

from .utils import async_command

__all__ = ["async_command"]
