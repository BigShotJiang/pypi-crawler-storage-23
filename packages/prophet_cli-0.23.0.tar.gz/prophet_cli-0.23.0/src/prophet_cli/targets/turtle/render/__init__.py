from __future__ import annotations

from .turtle import render_turtle

__all__ = [
    "render_turtle",
]
