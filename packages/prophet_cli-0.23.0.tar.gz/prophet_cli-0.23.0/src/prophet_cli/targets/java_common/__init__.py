from __future__ import annotations

from .render.support import effective_base_package

__all__ = ["effective_base_package"]
