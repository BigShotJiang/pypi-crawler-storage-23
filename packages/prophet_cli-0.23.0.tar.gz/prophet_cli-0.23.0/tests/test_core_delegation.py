from __future__ import annotations

import sys
import unittest
from pathlib import Path

THIS_FILE = Path(__file__).resolve()
PROJECT_ROOT = THIS_FILE.parents[2]
sys.path.insert(0, str(PROJECT_ROOT / "prophet-cli" / "src"))

from prophet_cli import cli
from prophet_cli.codegen import rendering as codegen_rendering
from prophet_cli.targets.java_spring_jpa.render import spring as java_spring_rendering
from prophet_cli.targets.turtle import render_turtle as turtle_rendering
from prophet_cli.core import config as core_config
from prophet_cli.core import compatibility as core_compat
from prophet_cli.core import ir as core_ir
from prophet_cli.core import parser as core_parser
from prophet_cli.core import validation as core_validation

EXAMPLE_ROOT = PROJECT_ROOT / "examples" / "java" / "prophet_example_spring"


class CoreDelegationTests(unittest.TestCase):
    def test_cli_function_delegation_targets_core_modules(self) -> None:
        self.assertIs(cli.parse_ontology, core_parser.parse_ontology)
        self.assertIs(cli.validate_ontology, core_validation.validate_ontology)
        self.assertIs(cli.compare_irs, core_compat.compare_irs)
        self.assertIs(cli.required_level_to_bump, core_compat.required_level_to_bump)
        self.assertIs(cli.load_config, core_config.load_config)
        self.assertIs(cli.cfg_get, core_config.cfg_get)
        self.assertIs(cli.render_sql, codegen_rendering.render_sql)
        self.assertIs(cli.render_openapi, codegen_rendering.render_openapi)
        self.assertIs(cli.render_turtle, turtle_rendering)
        self.assertIs(cli.compute_delta_from_baseline, codegen_rendering.compute_delta_from_baseline)
        self.assertIs(cli.resolve_migration_runtime_modes, java_spring_rendering.resolve_migration_runtime_modes)

    def test_cli_build_ir_matches_core_build_ir(self) -> None:
        cfg = cli.load_config(EXAMPLE_ROOT / "prophet.yaml")
        ontology_text = (EXAMPLE_ROOT / "ontology" / "local" / "main.prophet").read_text(encoding="utf-8")
        ont = cli.parse_ontology(ontology_text)

        cli_ir = cli.build_ir(ont, cfg)
        core_generated_ir = core_ir.build_ir(
            ont,
            cfg,
            toolchain_version=cli.TOOLCHAIN_VERSION,
            ir_version=cli.IR_VERSION,
        )
        self.assertEqual(cli_ir, core_generated_ir)


if __name__ == "__main__":
    unittest.main()
