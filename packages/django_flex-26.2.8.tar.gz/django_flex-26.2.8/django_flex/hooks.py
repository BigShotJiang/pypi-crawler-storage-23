"""
Django-Flex Lifecycle Hooks

Provides pre/post hooks for Flex CRUD operations.

Usage:
    # settings.py
    DJANGO_FLEX = {
        "HOOKS": {
            "attachment": {
                "pre_delete": "app.hooks.cleanup_s3_attachment",
                "post_add": "app.hooks.send_upload_notification",
            }
        }
    }

    # app/hooks.py
    def cleanup_s3_attachment(obj, user=None, **kwargs):
        '''Delete S3 object when attachment is deleted.'''
        import boto3
        s3 = boto3.client("s3")
        s3.delete_object(Bucket=settings.AWS_S3_BUCKET, Key=obj.s3_key)

Supported hooks:
    - pre_add: Before object creation (receives create_fields dict)
    - post_add: After object creation (receives created obj)
    - pre_edit: Before object update (receives obj and update_fields)
    - post_edit: After object update (receives updated obj)
    - pre_delete: Before object deletion (receives obj)
    - post_delete: After object deletion (receives deleted obj id)
"""

import importlib

from django_flex.conf import flex_settings


def call_hook(hook_name, model_name, **kwargs):
    """
    Call a lifecycle hook if configured.

    Args:
        hook_name: Name of hook (pre_add, post_add, pre_edit, post_edit, pre_delete, post_delete)
        model_name: Model name (lowercase)
        **kwargs: Arguments to pass to hook function (obj, user, fields, etc.)

    Returns:
        Hook function return value, or None if no hook configured
    """
    hooks_config = getattr(flex_settings, "HOOKS", None)
    if not hooks_config:
        return None

    model_hooks = hooks_config.get(model_name.lower())
    if not model_hooks:
        return None

    hook_path = model_hooks.get(hook_name)
    if not hook_path:
        return None

    try:
        module_path, func_name = hook_path.rsplit(".", 1)
        module = importlib.import_module(module_path)
        func = getattr(module, func_name)
        return func(**kwargs)
    except Exception as e:
        # Log error but don't break the operation
        import logging

        logger = logging.getLogger("django_flex.hooks")
        logger.error(f"Hook {hook_name} failed for {model_name}: {e}")
        return None
