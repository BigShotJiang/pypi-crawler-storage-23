raise Exception("This is an exception")
