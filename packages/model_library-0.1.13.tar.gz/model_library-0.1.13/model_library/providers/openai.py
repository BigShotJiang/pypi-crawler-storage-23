from __future__ import annotations

import datetime
import io
import json
import logging
import time
from typing import Any, Literal, Sequence, cast

from openai import APIConnectionError, AsyncOpenAI
from openai.types.chat import (
    ChatCompletionMessage,
    ChatCompletionMessageToolCall,
    ChatCompletionMessageToolCallUnion,
)
from openai.types.chat.chat_completion_message_tool_call import Function
from openai.types.chat.chat_completion_tool_param import ChatCompletionToolParam
from openai.types.create_embedding_response import CreateEmbeddingResponse
from openai.types.moderation_create_response import ModerationCreateResponse
from openai.types.responses import (
    ResponseFunctionToolCall,
    ResponseOutputItem,
    ResponseOutputText,
    ResponseStreamEvent,
)
from openai.types.responses.response import Response
from openai.types.responses.tool_param import ToolParam as ResponsesToolParam
from typing_extensions import override

from model_library import model_library_settings
from model_library.base import (
    LLM,
    BatchResult,
    Citation,
    DelegateConfig,
    FileBase,
    FileInput,
    FileWithBase64,
    FileWithId,
    FileWithUrl,
    FinishReason,
    FinishReasonInfo,
    InputItem,
    LLMBatchMixin,
    LLMConfig,
    ProviderConfig,
    PydanticT,
    QueryResult,
    QueryResultCost,
    QueryResultExtras,
    QueryResultMetadata,
    RateLimit,
    RawInput,
    RawResponse,
    TextInput,
    ToolBody,
    ToolCall,
    ToolDefinition,
    ToolResult,
)
from model_library.exceptions import (
    ImmediateRetryException,
    MaxOutputTokensExceededError,
    ModelNoOutputError,
    NoMatchingToolCallError,
)
from model_library.model_utils import get_reasoning_in_tag
from model_library.register_models import register_provider
from model_library.retriers.base import BaseRetrier
from model_library.utils import create_openai_client_with_defaults


def map_openai_completions_finish_reason(
    finish_reason: str | None,
) -> FinishReasonInfo:
    match finish_reason:
        case "stop":
            reason = FinishReason.STOP
        case "length":
            reason = FinishReason.MAX_TOKENS
        case "tool_calls" | "function_call":
            reason = FinishReason.TOOL_CALLS
        case "content_filter":
            reason = FinishReason.CONTENT_FILTER
        case _:
            reason = FinishReason.UNKNOWN

    return FinishReasonInfo(reason=reason, raw=finish_reason)


def map_openai_responses_finish_reason(
    status: str | None,
    incomplete_reason: str | None,
    has_tool_calls: bool,
) -> FinishReasonInfo:
    match status:
        case "completed":
            reason = FinishReason.TOOL_CALLS if has_tool_calls else FinishReason.STOP
        case "incomplete":
            match incomplete_reason:
                case "max_output_tokens":
                    reason = FinishReason.MAX_TOKENS
                case "content_filter":
                    reason = FinishReason.CONTENT_FILTER
                case _:
                    reason = FinishReason.UNKNOWN
        case "failed":
            reason = FinishReason.ERROR
        case _:
            reason = FinishReason.UNKNOWN

    raw = status
    if status == "incomplete" and incomplete_reason:
        raw = f"incomplete:{incomplete_reason}"

    return FinishReasonInfo(reason=reason, raw=raw)


class OpenAIBatchMixin(LLMBatchMixin):
    COMPLETED_BATCH_STATUSES: list[str] = [
        "failed",
        "completed",
        "expired",
        "cancelled",
    ]

    def __init__(self, openai: OpenAIModel):
        self._root: OpenAIModel = openai
        self._client: AsyncOpenAI = self._root.get_client()

    @override
    async def create_batch_query_request(
        self,
        custom_id: str,
        input: Sequence[InputItem],
        **kwargs: object,
    ) -> dict[str, Any]:
        tools_override = kwargs.pop("tools", None)
        normalized_tools: list[ToolDefinition]
        if tools_override is None:
            normalized_tools = []
        elif isinstance(tools_override, ToolDefinition):
            normalized_tools = [tools_override]
        elif isinstance(tools_override, Sequence) and not isinstance(
            tools_override, (str, bytes)
        ):
            normalized_tools = []
            tools_override_seq = cast(Sequence[object], tools_override)
            for tool in tools_override_seq:
                if not isinstance(tool, ToolDefinition):
                    raise TypeError(
                        "tools must contain ToolDefinition instances when batching"
                    )
                normalized_tools.append(tool)
        else:
            raise TypeError(
                "tools must be a ToolDefinition or a sequence of ToolDefinition instances"
            )
        return {
            "custom_id": custom_id,
            "method": "POST",
            "url": "/v1/responses",
            "body": await self._root.build_body(
                input,
                tools=normalized_tools,
                **kwargs,
            ),
        }

    @override
    async def batch_query(
        self,
        batch_name: str,
        requests: list[dict[str, Any]],
    ) -> str:
        """Sends a batch api query and returns batch id."""
        input_jsonl_str = "\n".join(json.dumps(req) for req in requests)
        input_jsonl_bytes = io.BytesIO(input_jsonl_str.encode("utf-8"))
        input_jsonl_bytes.name = batch_name

        batch_input_file = await self._client.files.create(
            file=input_jsonl_bytes, purpose="batch"
        )

        # TODO: Parameterize completion window
        completion_window = "24h"

        batch = await self._client.batches.create(
            input_file_id=batch_input_file.id,
            endpoint="/v1/responses",
            completion_window=completion_window,
            metadata={"description": batch_name},
        )
        return batch.id

    @override
    async def get_batch_results(self, batch_id: str) -> list[BatchResult]:
        batch = await self._client.batches.retrieve(batch_id)

        if not batch:
            raise Exception(f"Couldn't retrieve batch results for batch {batch_id}.")

        batch_results: list[BatchResult] = []

        if batch.output_file_id:
            successful_responses = await self._client.files.content(
                batch.output_file_id
            )
            successful_results: list[dict[str, Any]] = [
                json.loads(line) for line in successful_responses.iter_lines() if line
            ]
            for result in successful_results:
                id = cast(str, result["response"]["body"]["id"])
                response: Response = await self._client.responses.retrieve(id)

                output = QueryResult(
                    output_text=response.output_text,
                )
                if response.usage:
                    output.metadata.in_tokens = response.usage.input_tokens
                    output.metadata.out_tokens = response.usage.output_tokens

                batch_results.append(
                    BatchResult(
                        custom_id=cast(str, result["custom_id"]),
                        output=output,
                    )
                )

        if batch.error_file_id:
            failed_responses = await self._client.files.content(batch.error_file_id)
            failed_results: list[dict[str, Any]] = [
                json.loads(line) for line in failed_responses.iter_lines() if line
            ]
            for result in failed_results:
                error_message = cast(
                    str, result["response"]["body"]["error"]["message"]
                )
                output = QueryResult(
                    output_text=error_message,
                )
                batch_results.append(
                    BatchResult(
                        custom_id=cast(str, result["custom_id"]),
                        output=output,
                        error_message=error_message,
                    )
                )

        return batch_results

    @override
    async def get_batch_progress(self, batch_id: str) -> int:
        batch = await self._client.batches.retrieve(batch_id)
        if batch and batch.request_counts:
            completed = batch.request_counts.completed
        else:
            self._root.logger.error(f"Couldn't retrieve {batch_id}")
            completed = 0
        return completed

    @override
    async def cancel_batch_request(self, batch_id: str):
        self._root.logger.info(f"Cancelling {batch_id}")
        _ = await self._client.batches.cancel(batch_id)

    @override
    async def get_batch_status(self, batch_id: str) -> str:
        batch = await self._client.batches.retrieve(batch_id)
        return batch.status

    @override
    @classmethod
    def is_batch_status_completed(cls, batch_status: str) -> bool:
        return batch_status in OpenAIBatchMixin.COMPLETED_BATCH_STATUSES

    @override
    @classmethod
    def is_batch_status_failed(cls, batch_status: str) -> bool:
        return batch_status == "failed"

    @override
    @classmethod
    def is_batch_status_cancelled(cls, batch_status: str) -> bool:
        return batch_status == "cancelled"


class OpenAIConfig(ProviderConfig):
    deep_research: bool = False
    verbosity: Literal["low", "medium", "high"] | None = None


@register_provider("openai")
class OpenAIModel(LLM):
    provider_config = OpenAIConfig()

    @override
    def _get_default_api_key(self) -> str:
        if self.delegate_config:
            return self.delegate_config.api_key.get_secret_value()
        return model_library_settings.OPENAI_API_KEY

    @override
    def get_client(self, api_key: str | None = None) -> AsyncOpenAI:
        if not self.has_client():
            assert api_key
            client = create_openai_client_with_defaults(
                base_url=self.delegate_config.base_url
                if self.delegate_config
                else None,
                api_key=api_key,
            )
            self.assign_client(client)
        return super().get_client()

    def __init__(
        self,
        model_name: str,
        provider: str = "openai",
        *,
        config: LLMConfig | None = None,
        use_completions: bool = False,
        delegate_config: DelegateConfig | None = None,
    ):
        self.use_completions: bool = (
            use_completions  # TODO: do completions in a separate file
        )
        self.delegate_config = delegate_config

        super().__init__(model_name, provider, config=config)

        self.deep_research = self.provider_config.deep_research
        self.verbosity = self.provider_config.verbosity

        # batch client
        self.supports_batch: bool = self.supports_batch and not self.delegate_config
        self.batch: LLMBatchMixin | None = (
            OpenAIBatchMixin(self) if self.supports_batch else None
        )

    async def get_tool_call_ids(self, input: Sequence[InputItem]) -> list[str]:
        raw_responses = [x for x in input if isinstance(x, RawResponse)]
        tool_call_ids: list[str] = []

        if self.use_completions:
            calls = [
                y
                for x in raw_responses
                if isinstance(x.response, ChatCompletionMessage)
                and x.response.tool_calls
                for y in x.response.tool_calls
            ]
            tool_call_ids.extend([x.id for x in calls if x.id])
        else:
            calls = [
                y
                for x in raw_responses
                for y in x.response
                if isinstance(y, ResponseFunctionToolCall)
            ]
            tool_call_ids.extend([x.id for x in calls if x.id])
        return tool_call_ids

    @override
    async def parse_input(
        self,
        input: Sequence[InputItem],
        **kwargs: Any,
    ) -> list[dict[str, Any] | Any]:
        new_input: list[dict[str, Any] | Any] = []

        content_user: list[dict[str, Any]] = []

        def flush_content_user():
            if content_user:
                # NOTE: must make new object as we clear()
                new_input.append({"role": "user", "content": content_user.copy()})
                content_user.clear()

        tool_call_ids = await self.get_tool_call_ids(input)

        for item in input:
            if isinstance(item, TextInput):
                if self.use_completions:
                    text_key = "text"
                else:
                    text_key = "input_text"
                content_user.append({"type": text_key, "text": item.text})
                continue

            if isinstance(item, FileBase):
                match item.type:
                    case "image":
                        parsed = await self.parse_image(item)
                    case "file":
                        parsed = await self.parse_file(item)
                content_user.append(parsed)
                continue

            # non content user item
            flush_content_user()

            match item:
                case ToolResult():
                    if item.tool_call.id not in tool_call_ids:
                        raise NoMatchingToolCallError()

                    if self.use_completions:
                        new_input.append(
                            {
                                "role": "tool",
                                "tool_call_id": item.tool_call.id,
                                "content": item.result,
                            }
                        )
                    else:
                        new_input.append(
                            {
                                "type": "function_call_output",
                                "call_id": item.tool_call.call_id,
                                "output": item.result,
                            }
                        )
                case RawResponse():
                    if self.use_completions:
                        new_input.append(item.response)
                    else:
                        new_input.extend(item.response)
                case RawInput():
                    new_input.append(item.input)

        # in case content user item is the last item
        flush_content_user()

        return new_input

    @override
    async def parse_image(
        self,
        image: FileInput,
    ) -> dict[str, Any]:
        base_dict: dict[str, Any]
        if self.use_completions:
            base_dict = {
                "type": "image_url",
                "image_url": {
                    "detail": "auto",
                },
            }
            match image:
                case FileWithBase64():
                    base_dict["image_url"]["url"] = (
                        f"data:image/{image.mime};base64,{image.base64}"
                    )
                case FileWithUrl():
                    base_dict["image_url"]["url"] = image.url
                case FileWithId():
                    raise Exception("Completions endpoint does not support file_id")
        else:
            base_dict = {
                "type": "input_image",
                "detail": "auto",
            }
            match image:
                case FileWithBase64():
                    base_dict["image_url"] = (
                        f"data:image/{image.mime};base64,{image.base64}"
                    )
                case FileWithUrl():
                    base_dict["image_url"] = image.url
                case FileWithId():
                    base_dict["file_id"] = image.file_id
        return base_dict

    @override
    async def parse_file(
        self,
        file: FileInput,
    ) -> dict[str, Any]:
        base_dict: dict[str, Any]
        if self.use_completions:
            base_dict = {
                "type": "file",
                "file": {},
            }
            match file:
                case FileWithBase64():
                    base_dict["file"]["file_data"] = (
                        f"data:{file.mime};base64,{file.base64}"
                    )
                case FileWithUrl():
                    raise Exception("Completions endpoint does not support url")
                case FileWithId():
                    base_dict["file"]["file_id"] = file.file_id
        else:
            base_dict = {
                "type": "input_file",
            }
            match file:
                case FileWithBase64():
                    base_dict["filename"] = file.name
                    base_dict["file_data"] = f"data:{file.mime};base64,{file.base64}"
                case FileWithUrl():
                    base_dict["file_url"] = file.url
                case FileWithId():
                    base_dict["file_id"] = file.file_id
        return base_dict

    @override
    async def parse_tools(
        self,
        tools: Sequence[ToolDefinition],
    ) -> list[ChatCompletionToolParam | ResponsesToolParam | Any]:
        parsed_tools: list[ChatCompletionToolParam | ResponsesToolParam | Any] = []
        for tool in tools:
            body = tool.body
            if not isinstance(body, ToolBody):
                parsed_tools.append(body)
                continue

            parameters = {
                "type": "object",
                "properties": body.properties,
                "required": body.required,
                "additionalProperties": body.kwargs.get("additional_properties", False),
            }
            base_payload = {
                "name": body.name,
                "description": body.description,
                "parameters": parameters,
                "strict": body.kwargs.get("strict", False),
            }

            if self.use_completions:
                payload = {
                    "type": "function",
                    "function": base_payload,
                }
                parsed_tools.append(cast(ChatCompletionToolParam, payload))
            else:
                payload = {
                    "type": "function",
                    **base_payload,
                }
                parsed_tools.append(cast(ResponsesToolParam, payload))

        return parsed_tools

    @override
    async def upload_file(
        self,
        name: str,
        mime: str,
        bytes: io.BytesIO,
        type: Literal["image", "file"] = "file",
    ) -> FileWithId:
        response = await self.get_client().files.create(
            file=(name, bytes, mime),
            purpose="file-extract"  # type: ignore[reportArgumentType]
            if self.provider == "kimi" and type == "file"
            else "assistants",
        )

        return FileWithId(
            type=type,
            name=response.filename,
            mime=mime,
            file_id=response.id,
        )

    async def _build_body_completions(
        self,
        input: Sequence[InputItem],
        *,
        tools: list[ToolDefinition],
        **kwargs: object,
    ) -> dict[str, Any]:
        parsed_input: list[dict[str, Any] | ChatCompletionMessage] = []
        if "system_prompt" in kwargs:
            parsed_input.append(
                {"role": "system", "content": kwargs.pop("system_prompt")}
            )

        parsed_input.extend(await self.parse_input(input))

        body: dict[str, Any] = {
            "model": self.model_name,
            "messages": parsed_input,
            # enable usage data in streaming responses
            "stream_options": {"include_usage": True},
        }

        if self.max_tokens:
            body["max_tokens"] = self.max_tokens

        if self.supports_tools:
            parsed_tools = await self.parse_tools(tools)
            if parsed_tools:
                body["tools"] = parsed_tools

        if self.reasoning and self.max_tokens:
            del body["max_tokens"]
            body["max_completion_tokens"] = self.max_tokens

        # some model endpoints (like `fireworks/deepseek-v3p2`)
        # require explicitly setting reasoning effort to disable thinking
        if self.reasoning_effort is not None:
            body["reasoning_effort"] = self.reasoning_effort

        if self.supports_temperature:
            if self.temperature is not None:
                body["temperature"] = self.temperature
            if self.top_p is not None:
                body["top_p"] = self.top_p

        body.update(kwargs)

        return body

    async def _query_completions(
        self,
        input: Sequence[InputItem],
        *,
        tools: list[ToolDefinition],
        **kwargs: object,
    ) -> QueryResult:
        """
        Completions endpoint
        Generally not used for openai models
        Used by providers using openai as a delegate
        """

        body = await self.build_body(input, tools=tools, **kwargs)

        output_text: str = ""
        reasoning_text: str = ""
        completions_finish_reason: str | None = None
        metadata: QueryResultMetadata = QueryResultMetadata()
        raw_tool_calls: list[ChatCompletionMessageToolCall] = []

        stream = await self.get_client().chat.completions.create(
            **body,  # pyright: ignore[reportAny]
            stream=True,
        )

        async for chunk in stream:
            if chunk.choices:
                choice = chunk.choices[0]
                if choice.delta and choice.delta.content:
                    output_text += choice.delta.content

                if (
                    hasattr(choice.delta, "reasoning_content")
                    and choice.delta.reasoning_content  # pyright: ignore[reportUnknownMemberType, reportAttributeAccessIssue]
                ):
                    reasoning_text += cast(str, choice.delta.reasoning_content)  # pyright: ignore[reportUnknownMemberType, reportAttributeAccessIssue]

                if choice.delta and choice.delta.tool_calls:
                    for tool_call_chunk in choice.delta.tool_calls:
                        func = tool_call_chunk.function
                        # start of new tool call
                        if tool_call_chunk.id and (
                            not raw_tool_calls
                            or raw_tool_calls[-1].id != tool_call_chunk.id
                            or (
                                raw_tool_calls[-1].id == tool_call_chunk.id
                                and self.provider == "deepseek"
                                and func
                                and func.name
                            )  # TODO: remove hotfix once deepseek fixes their stuff
                        ):
                            raw_tool_calls.append(
                                ChatCompletionMessageToolCall(
                                    id=tool_call_chunk.id,
                                    type="function",
                                    function=Function(
                                        name=func.name if func and func.name else "",
                                        arguments=func.arguments
                                        if func and func.arguments
                                        else "",
                                    ),
                                )
                            )
                        # accumulate delta
                        elif func and raw_tool_calls:
                            if func.name:
                                raw_tool_calls[-1].function.name = func.name
                            if func.arguments:
                                raw_tool_calls[-1].function.arguments += func.arguments

                if (
                    choice.finish_reason == "length"
                    and not output_text
                    and not reasoning_text
                    and not raw_tool_calls
                ):
                    raise MaxOutputTokensExceededError()

                if choice.finish_reason:
                    completions_finish_reason = choice.finish_reason

            if chunk.usage:
                # NOTE: see _calculate_cost
                reasoning_tokens = (
                    chunk.usage.completion_tokens_details.reasoning_tokens or 0
                    if chunk.usage.completion_tokens_details
                    else 0
                )
                cache_read_tokens = (
                    chunk.usage.prompt_tokens_details.cached_tokens or 0
                    if chunk.usage.prompt_tokens_details
                    else getattr(chunk.usage, "cached_tokens", 0)  # for kimi
                )
                metadata = QueryResultMetadata(
                    in_tokens=chunk.usage.prompt_tokens - cache_read_tokens,
                    out_tokens=chunk.usage.completion_tokens - reasoning_tokens,
                    reasoning_tokens=reasoning_tokens,
                    cache_read_tokens=cache_read_tokens,
                )

        if not output_text and not reasoning_text and not raw_tool_calls:
            raise ModelNoOutputError()

        tool_calls: list[ToolCall] = []
        for raw_tool_call in raw_tool_calls:
            tool_calls.append(
                ToolCall(
                    id=raw_tool_call.id,
                    name=raw_tool_call.function.name,
                    args=raw_tool_call.function.arguments,
                )
            )

        if (
            self.reasoning
            and self.provider not in {"openai", "azure", "deepseek"}
            and output_text
            and not reasoning_text
        ):
            output_text, reasoning_text = get_reasoning_in_tag(output_text)

        # build final message for history
        final_message = ChatCompletionMessage(
            role="assistant",
            content=output_text if output_text else None,
            tool_calls=cast(list[ChatCompletionMessageToolCallUnion], raw_tool_calls)
            if raw_tool_calls
            else None,
        )
        if reasoning_text:
            setattr(final_message, "reasoning_content", reasoning_text)

        return QueryResult(
            output_text=output_text,
            reasoning=reasoning_text,
            finish_reason=map_openai_completions_finish_reason(
                completions_finish_reason
            ),
            tool_calls=tool_calls,
            history=[*input, RawResponse(response=final_message)],
            metadata=metadata,
        )

    async def _check_deep_research_args(
        self, tools: Sequence[ToolDefinition], **kwargs: object
    ) -> None:
        min_tokens = 30_000
        if not self.max_tokens or self.max_tokens < min_tokens:
            self.logger.warning(
                f"Recommended to set max_tokens >= {min_tokens} for deep research models"
            )

        if "background" not in kwargs:
            self.logger.warning(
                "Recommended to set background=True for deep research models"
            )

        valid = False
        for tool in tools:
            tool_body = tool.body
            if not isinstance(tool_body, dict):
                continue
            tool_body = cast(dict[str, Any], tool_body)
            tool_type = tool_body.get("type", None)

            if tool_type in {
                "web_search",
                "web_search_preview",
                "web_search_preview_2025_03_11",
            }:
                valid = True
        if not valid:
            raise Exception("Deep research models require web search tools")

    @override
    async def build_body(
        self,
        input: Sequence[InputItem],
        *,
        tools: list[ToolDefinition],
        **kwargs: object,
    ) -> dict[str, Any]:
        if self.use_completions:
            return await self._build_body_completions(input, tools=tools, **kwargs)

        if self.deep_research:
            await self._check_deep_research_args(tools, **kwargs)

        parsed_input: list[dict[str, Any] | ResponseOutputItem] = []
        if "system_prompt" in kwargs:
            parsed_input.append(
                {
                    "role": "developer",
                    "content": [
                        {"type": "input_text", "text": kwargs.pop("system_prompt")}
                    ],
                }
            )

        parsed_input.extend(await self.parse_input(input))

        parsed_tools = await self.parse_tools(tools)

        body: dict[str, Any] = {
            "model": self.model_name,
            "input": parsed_input,
        }

        if self.max_tokens:
            body["max_output_tokens"] = self.max_tokens

        if parsed_tools:
            body["tools"] = parsed_tools
        else:
            body["tool_choice"] = "none"

        if self.reasoning:
            body["reasoning"] = {"summary": "auto"}
            if self.reasoning_effort is not None:
                body["reasoning"]["effort"] = self.reasoning_effort  # type: ignore[reportArgumentType]

        if self.verbosity is not None:
            body["text"] = {"format": {"type": "text"}, "verbosity": self.verbosity}

        if self.supports_temperature:
            if self.temperature is not None:
                body["temperature"] = self.temperature
            if self.top_p is not None:
                body["top_p"] = self.top_p

        _ = kwargs.pop("stream", None)

        body.update(kwargs)
        return body

    @override
    async def _query_impl(
        self,
        input: Sequence[InputItem],
        *,
        tools: list[ToolDefinition],
        query_logger: logging.Logger,
        **kwargs: object,
    ) -> QueryResult:
        if self.use_completions:
            if self.deep_research:
                raise Exception("Use responses endpoint for deep research models")
            return await self._query_completions(input, tools=tools, **kwargs)

        body = await self.build_body(input, tools=tools, **kwargs)

        try:
            stream = await self.get_client().responses.create(
                **body,  # pyright: ignore[reportAny]
                stream=True,
            )
        except APIConnectionError:
            raise ImmediateRetryException("Failed to connect to OpenAI")

        response: Response | None = None
        stream_events: list[ResponseStreamEvent] = []
        async for event in stream:
            stream_events.append(event)
            match event.type:
                case "response.created":
                    self.logger.info(f"Response created: {event.response.id}")
                    response = event.response
                case "response.completed":
                    self.logger.info(f"Response completed: {event.response.id}")
                    response = event.response
                case "response.incomplete":
                    self.logger.warning(f"Response incomplete: {event.response.id}")
                    response = event.response
                case "response.in_progress":
                    self.logger.info(f"Response in progress: {event.response.id}")
                    response = event.response
                case "response.failed":
                    self.logger.error(f"Response failed: {event.response.id}")
                    self.logger.error(f"Error details: {event.response.error}")
                    response = event.response
                case _:
                    continue
        if not response:
            self.logger.error(
                f"Model returned no response. Events: {[e.model_dump(exclude_unset=True, exclude_none=True) for e in stream_events]}"
            )
            raise ImmediateRetryException("Model returned no response")
        self.logger.info(f"Response finished: {response.id}")

        if (
            response.incomplete_details
            and response.incomplete_details.reason == "max_output_tokens"
            and not response.output_text
        ):
            raise MaxOutputTokensExceededError()

        tool_calls: list[ToolCall] = []
        citations: list[Citation] = []
        reasoning = None
        for output in response.output:
            if output.type == "message":
                for content in output.content:
                    if not isinstance(content, ResponseOutputText):
                        continue
                    for citation in content.annotations:
                        citations.append(Citation(**citation.model_dump()))

            if output.type == "reasoning":
                reasoning = " ".join([i.text for i in output.summary])
                continue
            if output.type != "function_call":
                continue
            self.logger.info(f"Found tool call for response: {response.id}")
            if not output.id:
                raise Exception(f"Tool call is missing id for response: {response.id}")
            tool_calls.append(
                ToolCall(
                    id=output.id,
                    call_id=output.call_id,
                    name=output.name,
                    args=output.arguments,
                )
            )

        incomplete_reason = (
            response.incomplete_details.reason
            if response.status == "incomplete" and response.incomplete_details
            else None
        )

        result = QueryResult(
            output_text=response.output_text,
            reasoning=reasoning,
            finish_reason=map_openai_responses_finish_reason(
                response.status, incomplete_reason, bool(tool_calls)
            ),
            tool_calls=tool_calls,
            history=[*input, RawResponse(response=response.output)],
            extras=QueryResultExtras(citations=citations),
        )
        if response.usage:
            # see _calculate_cost
            cache_read_tokens = response.usage.input_tokens_details.cached_tokens
            reasoning_tokens = response.usage.output_tokens_details.reasoning_tokens
            result.metadata = QueryResultMetadata(
                in_tokens=response.usage.input_tokens - cache_read_tokens,
                out_tokens=response.usage.output_tokens - reasoning_tokens,
                reasoning_tokens=reasoning_tokens,
                cache_read_tokens=cache_read_tokens,
            )

        search_results = getattr(response, "search_results", None)
        if search_results is not None:
            result.raw["search_results"] = search_results

        return result

    @override
    async def get_rate_limit(self) -> RateLimit | None:
        headers = {}

        try:
            # NOTE: with_streaming_response doesn't seem to always work
            if self.use_completions:
                response = (
                    await self.get_client().chat.completions.with_raw_response.create(
                        max_completion_tokens=16,
                        model=self.model_name,
                        messages=[
                            {
                                "role": "user",
                                "content": "Ping",
                            }
                        ],
                        stream=True,
                    )
                )
            else:
                response = await self.get_client().responses.with_raw_response.create(
                    max_output_tokens=16,
                    input="Ping",
                    model=self.model_name,
                )
            headers = response.headers

            server_time_str = headers.get("date")
            if server_time_str:
                server_time = datetime.datetime.strptime(
                    server_time_str, "%a, %d %b %Y %H:%M:%S GMT"
                ).replace(tzinfo=datetime.timezone.utc)
                timestamp = server_time.timestamp()
            else:
                timestamp = time.time()

            # NOTE: for openai, max_tokens is used to reject requests if the amount of tokens left is less than the max_tokens

            # we calculate estimated_tokens as (character_count / 4) + max_tokens. Note that OpenAI's rate limiter doesn't tokenize the request using the model's specific tokenizer but relies on a character count-based heuristic.

            return RateLimit(
                raw=headers,
                unix_timestamp=timestamp,
                request_limit=headers.get("x-ratelimit-limit-requests", None)
                or headers.get("x-ratelimit-limit", None),
                request_remaining=headers.get("x-ratelimit-remaining-requests", None)
                or headers.get("x-ratelimit-remaining"),
                token_limit=int(headers["x-ratelimit-limit-tokens"]),
                token_remaining=int(headers["x-ratelimit-remaining-tokens"]),
            )
        except Exception as e:
            self.logger.warning(f"Failed to get rate limit: {e}")
            return None

    @override
    async def query_json(
        self,
        input: Sequence[InputItem],
        pydantic_model: type[PydanticT],
        **kwargs: object,
    ) -> PydanticT:
        # re-use existing body
        body = await self.build_body(
            input,
            tools=[],
            **kwargs,
        )

        async def _query():
            try:
                return await self.get_client().responses.parse(
                    text_format=pydantic_model,
                    **body,  # pyright: ignore[reportAny]
                )
            except APIConnectionError:
                raise ImmediateRetryException("Failed to connect to OpenAI")

        response = await BaseRetrier.immediate_retry_wrapper(
            func=_query, logger=self.logger
        )

        parsed: PydanticT | None = response.output_parsed
        if parsed is None:
            raise ModelNoOutputError("Model returned empty response")

        return parsed

    async def get_embedding(
        self, text: str, model: str = "text-embedding-3-small"
    ) -> list[float]:
        """Query OpenAI's Embedding endpoint"""

        async def _get_embedding() -> list[float]:
            try:
                response: CreateEmbeddingResponse = (
                    await self.get_client().embeddings.create(
                        input=text,
                        model=model,
                    )
                )
            except APIConnectionError:
                raise ImmediateRetryException("Failed to connect to OpenAI")
            except Exception as e:
                raise Exception("Failed to query OpenAI's Embedding endpoint") from e

            if not response.data:
                raise Exception("No embeddings returned from OpenAI")

            return response.data[0].embedding

        return await BaseRetrier.immediate_retry_wrapper(
            func=_get_embedding, logger=self.logger
        )

    async def moderate_content(self, text: str) -> ModerationCreateResponse:
        """Query OpenAI's Moderation endpoint"""

        async def _moderate_content() -> ModerationCreateResponse:
            try:
                return await self.get_client().moderations.create(input=text)
            except APIConnectionError:
                raise ImmediateRetryException("Failed to connect to OpenAI")
            except Exception as e:
                raise Exception("Failed to query OpenAI's Moderation endpoint") from e

        return await BaseRetrier.immediate_retry_wrapper(
            func=_moderate_content, logger=self.logger
        )

    @override
    async def _calculate_cost(
        self,
        metadata: QueryResultMetadata,
        batch: bool = False,
        bill_reasoning: bool = True,
    ) -> QueryResultCost | None:
        """
        Future Cost considerations
        Per session:
        - Code Interpreter
        Per day:
        - File Search Storage
        Per 1000:
        - File Search Tool Call (responses api)
        - Web Search Tool Call
        """

        # Prompt Caching works automatically on all your API requests (no code changes required) and has no additional fees associated with it
        # cache tokens are included in input tokens

        # reasoning tokens are included in output tokens

        return await super()._calculate_cost(metadata, batch, bill_reasoning=True)
