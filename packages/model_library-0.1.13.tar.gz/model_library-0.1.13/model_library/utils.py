import logging
from collections.abc import Mapping, Sequence

import httpx
from anthropic import AsyncAnthropic
from openai import AsyncOpenAI
from pydantic.main import BaseModel

MAX_LLM_LOG_LENGTH = 100
logger = logging.getLogger("llm")


def truncate_str(s: str | None, max_len: int = MAX_LLM_LOG_LENGTH) -> str:
    if not s:
        return ""
    if len(s) <= max_len:
        return s
    half = (max_len - 1) // 2
    return s[:half] + " […] " + s[-half:]


def get_logger(name: str | None = None):
    if not name:
        return logger
    return logging.getLogger(f"{logger.name}.{name}")


def deep_model_dump(obj: object) -> object:
    if isinstance(obj, BaseModel):
        return deep_model_dump(obj.model_dump(exclude_unset=True, exclude_none=True))

    if isinstance(obj, Mapping):
        return {k: deep_model_dump(v) for k, v in obj.items()}  # pyright: ignore[reportUnknownVariableType, reportUnknownArgumentType]
    if isinstance(obj, Sequence) and not isinstance(obj, (str, bytes)):
        return [deep_model_dump(v) for v in obj]  # pyright: ignore[reportUnknownVariableType, reportUnknownArgumentType]

    return obj


def default_httpx_client():
    return httpx.AsyncClient(
        timeout=httpx.Timeout(None),
        limits=httpx.Limits(
            max_connections=2000, max_keepalive_connections=300
        ),  # TODO: increase, but make sure prod enough sockets to not hit file descriptor limit
    )


def create_openai_client_with_defaults(
    api_key: str, base_url: str | None = None
) -> AsyncOpenAI:
    """
    OpenAI defaults:
    DEFAULT_TIMEOUT = httpx.Timeout(timeout=600, connect=5.0)
    DEFAULT_MAX_RETRIES = 2
    DEFAULT_CONNECTION_LIMITS = httpx.Limits(max_connections=1000, max_keepalive_connections=100)
    """
    return AsyncOpenAI(
        api_key=api_key,
        base_url=base_url,
        http_client=default_httpx_client(),
        max_retries=3,
    )


def create_anthropic_client_with_defaults(
    api_key: str, base_url: str | None = None, default_headers: dict[str, str] = {}
) -> AsyncAnthropic:
    return AsyncAnthropic(
        base_url=base_url,
        api_key=api_key,
        default_headers=default_headers,
        http_client=default_httpx_client(),
        max_retries=3,
    )


def get_context_window_for_model(model_name: str) -> int | None:
    """
    Get the context window for a model by looking up its configuration from the registry.

    Args:
        model_name: The name of the model in the registry (e.g., "openai/gpt-4o-mini-2024-07-18" or "azure/gpt-4o-mini-2024-07-18")

    Returns:
        Context window size in tokens (or `None` if not found)
    """
    # import here to avoid circular imports
    from model_library.register_models import get_model_registry

    model_config = get_model_registry().get(model_name, None)
    if (
        model_config
        and model_config.properties
        and model_config.properties.context_window
    ):
        return model_config.properties.context_window
    else:
        logger.warning(
            f"Model {model_name} not found in registry or missing context_window"
        )
        return None
