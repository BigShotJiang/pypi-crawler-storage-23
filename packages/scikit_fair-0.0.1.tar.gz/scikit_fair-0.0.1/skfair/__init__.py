"""
scikit-fair: Fairness-aware tools with a scikit-learn compatible API.
"""
