# Changelog

Version history is maintained in:

- `/Users/tourzhao/Desktop/huge-master/python-package/CHANGELOG.md`

Current release line:

- `0.1.0`: initial public `pyhuge` wrapper with expanded plotting, docs, CI, release scripts, and optional R-runtime e2e coverage.
