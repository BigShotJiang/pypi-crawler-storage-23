# `huge_tiger`

## Usage

```python
huge_tiger(
    x,
    lambda_=None,
    nlambda=None,
    lambda_min_ratio=None,
    sym="or",
    verbose=True,
) -> HugeResult
```

## Description

Convenience wrapper for `huge(..., method="tiger")`.
