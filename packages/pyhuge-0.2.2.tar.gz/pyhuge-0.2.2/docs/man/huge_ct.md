# `huge_ct`

## Usage

```python
huge_ct(
    x,
    lambda_=None,
    nlambda=None,
    lambda_min_ratio=None,
    verbose=True,
) -> HugeResult
```

## Description

Convenience wrapper for `huge(..., method="ct")`.
