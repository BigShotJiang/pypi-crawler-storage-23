# `huge_summary`

## Usage

```python
huge_summary(fit: HugeResult) -> HugeSummary
```

## Description

Compact Python-native summary for a `HugeResult`.

## Returns

`HugeSummary` with:

- method
- sample/feature counts
- path length
- sparsity range
- flags for covariance/precision availability
