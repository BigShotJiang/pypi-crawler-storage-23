# `huge_mb`

## Usage

```python
huge_mb(
    x,
    lambda_=None,
    nlambda=None,
    lambda_min_ratio=None,
    scr=None,
    scr_num=None,
    sym="or",
    verbose=True,
) -> HugeResult
```

## Description

Convenience wrapper for `huge(..., method="mb")`.

## Returns

`HugeResult`.
