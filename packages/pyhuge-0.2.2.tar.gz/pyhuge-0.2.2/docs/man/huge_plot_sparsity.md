# `huge_plot_sparsity`

## Usage

```python
huge_plot_sparsity(fit, ax=None, show_points=True) -> matplotlib.axes.Axes
```

## Description

Plots sparsity level versus lambda path.

## Key arguments

- `fit`: `HugeResult`
- `ax`: optional existing matplotlib axes
- `show_points`: overlay point markers on line
