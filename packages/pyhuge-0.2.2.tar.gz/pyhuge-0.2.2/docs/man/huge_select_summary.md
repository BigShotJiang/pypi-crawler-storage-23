# `huge_select_summary`

## Usage

```python
huge_select_summary(sel: HugeSelectResult) -> HugeSelectSummary
```

## Description

Compact Python-native summary for a `HugeSelectResult`.

## Returns

`HugeSelectSummary` with criterion, selected lambda/sparsity, refit dimension, and optional-covariance flags.
