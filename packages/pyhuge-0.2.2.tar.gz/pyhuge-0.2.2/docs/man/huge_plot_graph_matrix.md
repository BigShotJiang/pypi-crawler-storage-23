# `huge_plot_graph_matrix`

## Usage

```python
huge_plot_graph_matrix(fit, index=-1, ax=None) -> matplotlib.axes.Axes
```

## Description

Visualizes one adjacency matrix in the path as a heatmap.

## Key arguments

- `fit`: `HugeResult`
- `index`: path index (supports negative indexing)
- `ax`: optional existing matplotlib axes
