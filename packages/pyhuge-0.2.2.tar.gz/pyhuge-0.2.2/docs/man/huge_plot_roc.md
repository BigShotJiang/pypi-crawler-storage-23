# `huge_plot_roc`

## Usage

```python
huge_plot_roc(roc, ax=None) -> matplotlib.axes.Axes
```

## Description

Plots ROC curve from `HugeRocResult` (`fp` vs `tp`) and shows AUC in title.
