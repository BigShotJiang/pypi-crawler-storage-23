# Function Manual

This section is the Python equivalent of an R `man/` directory:
one page per public function with usage and argument notes.

## Core estimation

- [`huge`](huge.md)
- [`huge_mb`](huge_mb.md)
- [`huge_glasso`](huge_glasso.md)
- [`huge_ct`](huge_ct.md)
- [`huge_tiger`](huge_tiger.md)

## Selection and preprocessing

- [`huge_select`](huge_select.md)
- [`huge_npn`](huge_npn.md)

## Simulation and inference

- [`huge_generator`](huge_generator.md)
- [`huge_inference`](huge_inference.md)
- [`huge_roc`](huge_roc.md)

## Summary and plotting

- [`huge_summary`](huge_summary.md)
- [`huge_select_summary`](huge_select_summary.md)
- [`huge_plot_sparsity`](huge_plot_sparsity.md)
- [`huge_plot_roc`](huge_plot_roc.md)
- [`huge_plot_graph_matrix`](huge_plot_graph_matrix.md)
- [`huge_plot_network`](huge_plot_network.md)

## Runtime helper

- [`test`](test.md)
- [`doctor`](doctor.md)
