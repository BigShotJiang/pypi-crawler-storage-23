# `huge_npn`

## Usage

```python
huge_npn(x, npn_func="shrinkage", verbose=True) -> np.ndarray
```

## Description

Nonparanormal transformation mapped to R `huge.npn()`.

## Key arguments

- `x`: 2D numeric matrix
- `npn_func`: one of `"shrinkage"`, `"truncation"`, `"skeptic"`

## Returns

Transformed data matrix as `numpy.ndarray`.
