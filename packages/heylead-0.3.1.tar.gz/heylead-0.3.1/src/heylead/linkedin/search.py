# Legacy module — all LinkedIn search operations now in unipile.py
# Kept as empty file to avoid import errors during transition.
