"""Tool: export_campaign — Export campaign results as a formatted table.

Generates a copy-paste-friendly table of all prospects with their
outreach status, fit score, messages sent, and engagement count.
"""

from __future__ import annotations

import json
import logging

from ..db.queries import (
    find_active_campaign,
    get_campaign_stats,
    get_setting,
    list_campaigns,
)
from ..db.schema import get_db
from ..formatter import stars, table

logger = logging.getLogger(__name__)


async def run_export_campaign(campaign_id: str = "") -> str:
    """Export campaign results as a formatted table."""

    setup_done = get_setting("setup_complete", False)
    if not setup_done:
        return (
            "Setup required before exporting.\n\n"
            "Please run setup_profile first."
        )

    # Resolve campaign
    campaign, err = find_active_campaign(campaign_id)
    if not campaign and not campaign_id:
        # Fallback: try any campaign (not just active)
        campaigns = list_campaigns()
        if not campaigns:
            return (
                "No campaigns to export.\n\n"
                "Create one first: create_campaign(\"your target description\")"
            )
        campaign = campaigns[0]
    elif not campaign:
        return err
    campaign_id = campaign["id"]

    # Fetch prospect data with outreach + engagement + message counts
    db = get_db()
    rows = db.execute(
        """SELECT o.id as outreach_id,
                  c.name, c.title, c.company, c.linkedin_url, c.fit_score,
                  o.status, o.followup_count, o.outcome_json,
                  (SELECT COUNT(*) FROM engagements e WHERE e.outreach_id = o.id) as engagement_count,
                  (SELECT COUNT(*) FROM messages m WHERE m.outreach_id = o.id AND m.role = 'sdr') as messages_sent
           FROM contacts c
           JOIN outreaches o ON o.contact_id = c.id
           WHERE c.campaign_id = ?
           ORDER BY c.fit_score DESC""",
        (campaign_id,),
    ).fetchall()
    db.close()

    if not rows:
        return (
            f"Campaign '{campaign['name']}' has no prospects yet.\n\n"
            "Prospects are added when you run create_campaign()."
        )

    # Status display mapping
    status_display = {
        "pending": "Pending",
        "invited": "Invited",
        "connected": "Connected",
        "messaged": "Messaged",
        "replied": "Replied",
        "hot_lead": "Hot Lead",
        "review_pending": "Review",
        "skipped": "Skipped",
        "error": "Error",
        "opted_out": "Opted Out",
        "closed_happy": "Won",
        "closed_unhappy": "Lost",
    }

    # Check if any outreaches have outcomes
    has_outcomes = any(dict(row).get("outcome_json") for row in rows)

    # Build table
    headers = ["ID", "Name", "Title", "Company", "Status", "Fit", "Msgs", "Eng."]
    if has_outcomes:
        headers.append("Outcome")
    table_rows = []
    for row in rows:
        r = dict(row)
        row_data = [
            r.get("outreach_id", "")[:8],
            r.get("name", "Unknown"),
            (r.get("title", "") or "")[:30],
            (r.get("company", "") or "")[:20],
            status_display.get(r.get("status", ""), r.get("status", "")),
            stars(r.get("fit_score", 0)),
            str(r.get("messages_sent", 0)),
            str(r.get("engagement_count", 0)),
        ]
        if has_outcomes:
            outcome_text = ""
            if r.get("outcome_json"):
                try:
                    odata = json.loads(r["outcome_json"])
                    outcome_text = (odata.get("reason", "") or "")[:30]
                except (json.JSONDecodeError, TypeError):
                    pass
            row_data.append(outcome_text)
        table_rows.append(row_data)

    table_output = table(headers, table_rows)

    # Summary stats
    stats = get_campaign_stats(campaign_id)

    output = [
        f"📋 Export: **{campaign['name']}** ({len(rows)} prospects)\n",
        table_output,
        "",
        "Summary:",
        f"├── Invited: {stats['invited']} | Connected: {stats['connected']} | "
        f"Replied: {stats['replied']} | Hot leads: {stats['hot_leads']}",
        f"└── Acceptance rate: {stats['acceptance_rate']:.0%} | "
        f"Reply rate: {stats['reply_rate']:.0%}",
        "",
        "Copy the table above to paste into spreadsheets or documents.",
    ]

    return "\n".join(output)
