---
name: reminders
description: "Set, list, and cancel reminders. Creates lightweight scheduled jobs that send notifications via Telegram, email, or SMS. Supports one-time and recurring reminders."
---

Reminders are powered by the Fliiq job scheduler. Requires the daemon to be running (`fliiq daemon start`).

## Actions
- **set**: Create a one-time or recurring reminder (creates a scheduled job under the hood)
- **list**: Show all active reminders
- **cancel**: Delete a reminder by name

## One-time reminder
Provide `fire_at` as an ISO datetime or natural language (e.g., "tomorrow 9am", "in 3 hours", "next Friday at 2pm").

## Recurring reminder
Provide `recurring` as a cron expression (e.g., "0 9 * * 1" for every Monday at 9am). The `fire_at` field is ignored when `recurring` is set.
