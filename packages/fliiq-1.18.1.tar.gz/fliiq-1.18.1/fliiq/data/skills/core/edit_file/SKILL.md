---
name: edit_file
description: "Replace a unique text occurrence in a file with new text."
---

Use this tool to make targeted edits to existing files. The old_text must appear exactly once in the file. If it appears zero or multiple times, the edit fails with an explicit error.
