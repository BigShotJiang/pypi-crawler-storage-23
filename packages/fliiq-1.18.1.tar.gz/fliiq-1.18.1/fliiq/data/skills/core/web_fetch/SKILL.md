---
name: fetch_html
description: "Fetch raw HTML from a public URL, with optional markdown conversion and pagination."
---

Use this tool to fetch web pages. Supports pagination via start_index and optional conversion to markdown. Output truncated to 10,000 characters.
