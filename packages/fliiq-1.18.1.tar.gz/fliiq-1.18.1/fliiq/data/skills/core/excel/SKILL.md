---
name: excel
description: "Create, read, and write Excel (.xlsx) files. Supports multiple sheets, cell ranges, and structured data."
---

Use this tool to work with Excel spreadsheet files (.xlsx) on the local filesystem.

## Available Actions
- create: Create a new .xlsx workbook with optional initial data
- read: Read cell values from a sheet (optionally specify a range)
- write: Write a 2D array of values to a sheet starting at a given cell
- list_sheets: List all sheet names in a workbook
- add_sheet: Add a new sheet to an existing workbook
- delete: Delete an .xlsx file

## Range Notation
- Ranges use Excel A1 notation: "A1:D10", "B2:B100"
- If no range is given for read, the entire used range is returned

## Data Format
- Values are passed as a 2D array: [["Name", "Age"], ["Alice", 30]]
- Numbers, strings, booleans, and None are all supported

## Limits
- Read operations cap at 10,000 rows to avoid overwhelming context
