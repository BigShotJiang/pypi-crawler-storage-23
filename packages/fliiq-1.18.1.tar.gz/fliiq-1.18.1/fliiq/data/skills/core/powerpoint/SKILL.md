---
name: powerpoint
description: "Create, read, and modify PowerPoint (.pptx) presentations. Add slides with titles and content, extract text, and manage slide decks."
---

Use this tool to work with PowerPoint files (.pptx) on the local filesystem.

## Available Actions
- create: Create a new .pptx presentation with an optional title slide
- read: Extract text and structure from all slides
- add_slide: Add a slide with a title and body text
- modify_slide: Find and replace text on a specific slide
- delete_slide: Remove a slide by its index (0-based)
- delete: Delete a .pptx file

## Slide Layouts
- TITLE: Title slide (title + subtitle)
- TITLE_AND_CONTENT: Title with bullet content (default for add_slide)
- BLANK: Empty slide

## Notes
- Slide indices are 0-based
- read returns text extracted from all shapes on each slide
- modify_slide does find-and-replace within text frames on the target slide
