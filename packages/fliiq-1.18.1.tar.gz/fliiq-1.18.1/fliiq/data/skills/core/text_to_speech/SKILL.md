---
name: text_to_speech
description: "Convert text to speech audio using MiniMax TTS API. Supports multiple languages including Cantonese, Mandarin, English. Returns path to generated MP3 file."
---

Generate speech audio from text. Returns a file path to the MP3 audio.

## Voice IDs

Pick the voice_id based on the language:
- Cantonese: `Cantonese_GentleLady` (default)
- Mandarin female: `female-shaonv`, `female-yujie`, `female-tianmei`
- Mandarin male: `male-qn-qingse`, `male-qn-jingying`, `male-qn-badao`
- English/other: Use any of the above; MiniMax handles multilingual text.

## Typical Flow

1. Call `text_to_speech` to generate audio
2. Send the resulting file via `send_telegram_audio` (or other delivery channel)
