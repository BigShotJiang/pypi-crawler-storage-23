---
name: fetch_arxiv
description: "Search arXiv by keyword query or retrieve a specific paper by ID. Returns metadata, abstracts, and optionally downloads PDFs."
---

# fetch_arxiv

Search arXiv by keyword query or retrieve a specific paper by arXiv ID. Returns structured metadata including title, authors, abstract, published date, categories, and PDF URL. Optionally downloads PDFs.

**No API key required.** arXiv is openly accessible.

## Install

```bash
pip install arxiv
```

## Usage

### Search by query

```python
fetch_arxiv(query="transformer attention mechanism", max_results=5)
```

Returns a list of up to 5 papers matching the query, sorted by relevance.

### Fetch a specific paper by ID

```python
fetch_arxiv(paper_id="1706.03762")        # Attention Is All You Need
fetch_arxiv(paper_id="arXiv:2310.06825")  # prefix is stripped automatically
```

### Download PDFs

```python
fetch_arxiv(query="agent memory architectures", max_results=3, download_pdf=True, output_path="./papers/")
```

Downloads PDFs to the specified directory and returns local file paths.

## Return Format

```json
{
  "papers": [
    {
      "arxiv_id": "1706.03762",
      "title": "Attention Is All You Need",
      "authors": ["Ashish Vaswani", "Noam Shazeer", "..."],
      "abstract": "The dominant sequence transduction models...",
      "published": "2017-06-12T17:00:00+00:00",
      "updated": "2023-08-02T00:00:00+00:00",
      "url": "http://arxiv.org/abs/1706.03762v7",
      "pdf_url": "http://arxiv.org/pdf/1706.03762v7",
      "categories": ["cs.CL", "cs.LG"],
      "doi": null,
      "journal_ref": null
    }
  ],
  "count": 1,
  "downloaded": [],
  "query": null,
  "paper_id": "1706.03762"
}
```

## Examples

```
# Find recent papers on agent memory
fetch_arxiv(query="agent memory long-horizon tasks 2024", max_results=10)

# Get a specific paper
fetch_arxiv(paper_id="2310.06825")

# Monitor for new papers (good for daemon jobs)
fetch_arxiv(query="cs.AI agent planning", max_results=20)
```

## Rate Limits

arXiv API allows ~3 requests/second. For large batch jobs, add a small delay between calls. The `arxiv` package handles basic rate limiting automatically.

## Pairing with read_pdf

```
fetch_arxiv(paper_id="1706.03762", download_pdf=True, output_path="./papers/")
# → then:
read_pdf(path="./papers/1706_03762.pdf")
```

This two-skill pipeline enables full paper ingestion: discover → download → extract text → summarize.
