"""Tests for fetch_arxiv skill.

Uses deterministic arXiv paper IDs for reliable, non-flaky CI.
'1706.03762' = 'Attention Is All You Need' — stable, well-known paper.
"""



def test_fetch_by_paper_id():
    """Fetch a specific paper by arXiv ID — deterministic result."""
    from main import fetch_arxiv

    result = fetch_arxiv(paper_id="1706.03762")

    assert result.get("error") is None or "arxiv" not in result.get("error", "").lower()
    assert result["count"] >= 1
    assert len(result["papers"]) >= 1

    paper = result["papers"][0]
    assert "title" in paper
    assert "Attention" in paper["title"]
    assert "authors" in paper
    assert isinstance(paper["authors"], list)
    assert len(paper["authors"]) > 0
    assert "abstract" in paper
    assert len(paper["abstract"]) > 50
    assert "arxiv_id" in paper
    assert "1706.03762" in paper["arxiv_id"]
    assert "pdf_url" in paper
    assert paper["pdf_url"].startswith("http")
    assert "published" in paper
    assert "categories" in paper
    assert isinstance(paper["categories"], list)


def test_fetch_by_query():
    """Search by query — returns list with expected fields."""
    from main import fetch_arxiv

    result = fetch_arxiv(query="transformer self-attention", max_results=3)

    assert result.get("error") is None
    assert result["count"] >= 1
    assert len(result["papers"]) <= 3

    for paper in result["papers"]:
        assert "title" in paper
        assert "authors" in paper
        assert "abstract" in paper
        assert "arxiv_id" in paper
        assert "pdf_url" in paper
        assert "published" in paper
        assert "categories" in paper


def test_max_results_capped():
    """max_results is capped at 50."""
    from main import fetch_arxiv

    result = fetch_arxiv(query="neural network", max_results=200)
    # Should not error, count should be <= 50
    assert result.get("error") is None
    assert result["count"] <= 50


def test_arxiv_prefix_stripped():
    """'arXiv:' prefix in paper_id is stripped correctly."""
    from main import fetch_arxiv

    result = fetch_arxiv(paper_id="arXiv:1706.03762")
    assert result["count"] >= 1
    paper = result["papers"][0]
    assert "Attention" in paper["title"]


def test_missing_both_params():
    """Neither query nor paper_id → returns error, not exception."""
    from main import fetch_arxiv

    result = fetch_arxiv()
    assert "error" in result
    assert result["count"] == 0
    assert result["papers"] == []


def test_both_params_provided():
    """Both query and paper_id → returns error."""
    from main import fetch_arxiv

    result = fetch_arxiv(query="attention", paper_id="1706.03762")
    assert "error" in result
    assert result["count"] == 0


def test_invalid_paper_id_returns_empty():
    """Invalid paper ID returns empty list, not exception."""
    from main import fetch_arxiv

    result = fetch_arxiv(paper_id="9999.99999")
    # Should either return empty papers or a graceful error — never raise
    assert isinstance(result, dict)
    assert "papers" in result
    assert "count" in result


def test_no_download_by_default():
    """download_pdf defaults to False — no files downloaded."""
    from main import fetch_arxiv

    result = fetch_arxiv(paper_id="1706.03762")
    assert result["downloaded"] == []
