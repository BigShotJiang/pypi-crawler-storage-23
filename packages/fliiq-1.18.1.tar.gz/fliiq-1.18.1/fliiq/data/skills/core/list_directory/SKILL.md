---
name: list_directory
description: "List the contents of a directory with file/directory indicators."
---

Use this tool to see what files and directories exist at a given path. Each entry is prefixed with [FILE] or [DIR].
