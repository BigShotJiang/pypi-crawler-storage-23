# Project Identity Overrides
#
# This file customizes Fliiq's personality for your project.
# It is appended to the default SOUL.md as "User Overrides".
# Delete any section you don't need — only what's here gets applied.
# Run `fliiq soul show` to see the full assembled identity.
# Run `fliiq soul reset` to remove this file and revert to defaults.

## Communication Style
# Uncomment and edit to override defaults:
# - Use casual language
# - Always respond in Spanish
# - Keep all responses under 3 sentences

## Domain Expertise
# Tell Fliiq what it should know about your project:
# - This is a Django REST API with PostgreSQL
# - We use conventional commits
# - All code must pass mypy strict mode

## Behavioral Rules
# Add project-specific rules:
# - Never modify files in the /migrations directory without asking
# - Always run pytest after code changes
# - Use snake_case for all Python, camelCase for all TypeScript
