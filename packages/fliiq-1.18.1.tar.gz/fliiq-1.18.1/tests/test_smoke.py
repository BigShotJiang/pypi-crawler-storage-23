def test_import_fliiq():
    import fliiq

    assert fliiq.__version__  # dynamic from importlib.metadata
