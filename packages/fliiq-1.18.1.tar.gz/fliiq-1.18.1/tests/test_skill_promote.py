"""Tests for the skill-promote CLI command."""

from typer.testing import CliRunner

from fliiq.cli.main import app

runner = CliRunner()


def _make_skill(skills_dir, name="test_skill"):
    """Create a minimal valid skill in the given directory."""
    skill_dir = skills_dir / name
    skill_dir.mkdir(parents=True)
    (skill_dir / "SKILL.md").write_text(
        "---\nname: test_skill\ndescription: A test skill\n---\n# Test Skill\n"
    )
    (skill_dir / "fliiq.yaml").write_text(
        "name: test_skill\ndescription: A test skill\n"
        "parameters:\n  type: object\n  properties:\n"
        "    query:\n      type: string\n"
    )
    (skill_dir / "main.py").write_text(
        "async def handler(params: dict) -> dict:\n"
        "    return {'result': 'ok'}\n"
    )
    return skill_dir


def test_promote_moves_skill_to_core(tmp_path, monkeypatch):
    """Happy path: skill is moved from .fliiq/skills/ to core."""
    local_dir = tmp_path / ".fliiq"
    local_dir.mkdir()
    skills_dir = local_dir / "skills"
    _make_skill(skills_dir)

    # Create a fake core target
    core_dir = tmp_path / "core_skills"
    core_dir.mkdir()

    monkeypatch.chdir(tmp_path)

    from fliiq.runtime import config, package_data

    monkeypatch.setattr(config, "local_fliiq_dir", lambda: local_dir)
    monkeypatch.setattr(package_data, "bundled_skills_dir", lambda: core_dir)

    result = runner.invoke(app, ["skill-promote", "test_skill"])

    assert result.exit_code == 0, result.output
    assert "Promoted" in result.output
    assert (core_dir / "test_skill" / "main.py").exists()
    assert not (skills_dir / "test_skill").exists()


def test_promote_skill_not_found(tmp_path, monkeypatch):
    """Error when skill doesn't exist in .fliiq/skills/."""
    local_dir = tmp_path / ".fliiq"
    local_dir.mkdir()
    (local_dir / "skills").mkdir()

    monkeypatch.chdir(tmp_path)

    from fliiq.runtime import config

    monkeypatch.setattr(config, "local_fliiq_dir", lambda: local_dir)

    result = runner.invoke(app, ["skill-promote", "nonexistent"])

    assert result.exit_code == 1
    assert "not found" in result.output.lower()


def test_promote_already_exists_in_core(tmp_path, monkeypatch):
    """Error when skill already exists in core."""
    local_dir = tmp_path / ".fliiq"
    local_dir.mkdir()
    skills_dir = local_dir / "skills"
    _make_skill(skills_dir)

    core_dir = tmp_path / "core_skills"
    (core_dir / "test_skill").mkdir(parents=True)

    monkeypatch.chdir(tmp_path)

    from fliiq.runtime import config, package_data

    monkeypatch.setattr(config, "local_fliiq_dir", lambda: local_dir)
    monkeypatch.setattr(package_data, "bundled_skills_dir", lambda: core_dir)

    result = runner.invoke(app, ["skill-promote", "test_skill"])

    assert result.exit_code == 1
    assert "already exists" in result.output.lower()


def test_promote_no_local_fliiq_dir(tmp_path, monkeypatch):
    """Error when no .fliiq/ directory found."""
    monkeypatch.chdir(tmp_path)

    from fliiq.runtime import config

    monkeypatch.setattr(config, "local_fliiq_dir", lambda: None)

    result = runner.invoke(app, ["skill-promote", "test_skill"])

    assert result.exit_code == 1
    assert "fliiq init" in result.output.lower()
