"""Tests for daemon utility helpers."""

import os

from fliiq.runtime.scheduler.daemon_utils import is_daemon_running, read_pid


def test_read_pid(tmp_path):
    (tmp_path / ".fliiq").mkdir()
    pid_path = tmp_path / ".fliiq" / "daemon.pid"
    pid_path.write_text("12345")
    assert read_pid(tmp_path) == 12345


def test_read_pid_missing(tmp_path):
    (tmp_path / ".fliiq").mkdir()
    assert read_pid(tmp_path) is None


def test_is_daemon_running_no_pid(tmp_path):
    (tmp_path / ".fliiq").mkdir()
    assert is_daemon_running(tmp_path) is False


def test_is_daemon_running_stale_pid(tmp_path):
    (tmp_path / ".fliiq").mkdir()
    pid_path = tmp_path / ".fliiq" / "daemon.pid"
    pid_path.write_text("999999")  # Almost certainly not a real PID
    assert is_daemon_running(tmp_path) is False
