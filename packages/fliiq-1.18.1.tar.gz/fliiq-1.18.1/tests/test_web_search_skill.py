"""Tests for the web_search skill."""

import os

import pytest

from fliiq.runtime.package_data import bundled_skills_dir
from fliiq.runtime.skills.base import SkillBase

SKILLS_DIR = str(bundled_skills_dir())


def _load_skill(name: str) -> SkillBase:
    return SkillBase(os.path.join(SKILLS_DIR, name))


async def test_web_search_missing_api_key(monkeypatch):
    """web_search raises explicit error when BRAVE_API_KEY is missing."""
    monkeypatch.delenv("BRAVE_API_KEY", raising=False)
    skill = _load_skill("web_search")
    with pytest.raises(ValueError, match="BRAVE_API_KEY"):
        await skill.execute({"query": "test"})


def test_web_search_schema():
    """web_search has correct input schema."""
    skill = _load_skill("web_search")
    schema = skill.schema()
    assert schema["name"] == "web_search"
    assert "query" in schema["parameters"]["properties"]
    assert "query" in schema["parameters"]["required"]
