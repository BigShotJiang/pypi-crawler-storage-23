"""Tests for colony data models."""

from fliiq.runtime.colony.models import (
    AgentReflection,
    AgentRole,
    ColonyConfig,
    ColonyState,
    Evidence,
    FileChange,
    GovernanceDecision,
    IntelBrief,
    Proposal,
    ProposalStatus,
    ProposalType,
    QAMetrics,
    RiskLevel,
    TimelineEntry,
    Vote,
    VotePosition,
)


def test_proposal_defaults():
    p = Proposal(title="Test", type=ProposalType.BUG_FIX, risk=RiskLevel.LOW, proposer=AgentRole.QA)
    assert p.id.startswith("PROP-")
    assert p.status == ProposalStatus.DRAFT
    assert p.files_affected == []
    assert p.created_at is not None


def test_proposal_with_evidence():
    p = Proposal(
        title="Add caching",
        type=ProposalType.ARCHITECTURE_CHANGE,
        risk=RiskLevel.MEDIUM,
        proposer=AgentRole.RESEARCH,
        evidence=[Evidence(source="benchmark", url="https://example.com", finding="2x faster")],
        files_affected=[FileChange(path="fliiq/cache.py", action="create", description="New cache module")],
    )
    assert len(p.evidence) == 1
    assert p.evidence[0].finding == "2x faster"
    assert p.files_affected[0].action == "create"


def test_intel_brief_defaults():
    b = IntelBrief(title="New model release", source_type="blog")
    assert b.id.startswith("INTEL-")
    assert b.relevance == "indirect"
    assert b.tags == []


def test_vote():
    v = Vote(
        proposal_id="PROP-ABC123",
        voter=AgentRole.QA,
        position=VotePosition.OPPOSE,
        reasoning="Insufficient test coverage",
    )
    assert v.position == VotePosition.OPPOSE


def test_governance_decision():
    d = GovernanceDecision(
        proposal_id="PROP-ABC123",
        outcome=ProposalStatus.APPROVED,
        reasoning="Good evidence, rollback plan included",
        commit_sha="abc123",
    )
    assert d.outcome == ProposalStatus.APPROVED
    assert d.commit_sha == "abc123"


def test_agent_reflection():
    r = AgentReflection(
        agent=AgentRole.INTELLIGENCE,
        cycle_number=1,
        observation="Found 3 developments",
        action_taken="Created 3 briefs",
        outcome="2 high-relevance items",
        lesson="Filter for 'agent' keyword",
    )
    assert r.cycle_number == 1
    assert r.lesson == "Filter for 'agent' keyword"


def test_qa_metrics():
    m = QAMetrics(test_count=500, pass_count=498, fail_count=2, lint_issues=3)
    assert m.fail_count == 2


def test_timeline_entry():
    e = TimelineEntry(agent="research", action="Drafted PROP-003", detail="Based on INTEL-005")
    assert e.agent == "research"


def test_colony_config_defaults():
    c = ColonyConfig()
    assert c.experiment_duration_hours == 24.0
    assert c.code_freeze_at_hour == 22.0
    assert c.cooldowns["intelligence"] == 1200
    assert c.max_iterations_per_cycle == 50


def test_colony_state():
    s = ColonyState(experiment_id=1, branch_name="colony/experiment-001")
    assert s.status == "bootstrapping"
    assert s.cycle_count == 0


def test_proposal_types():
    assert ProposalType.NEW_SKILL == "new-skill"
    assert ProposalType.ARCHITECTURE_CHANGE == "architecture-change"



