"""
Purpose: GUI for performing current-voltage (I-V) sweeps using a Keithley 6221 Current Source and a Keithley 2182A Nanovoltmeter. 

Author: Prathamesh Deshmukh
Date: October 2025
Version: 1.6
"""

import tkinter as tk
from tkinter import ttk, Label, Entry, LabelFrame, Button, filedialog, messagebox, scrolledtext, Canvas
import numpy as np
import os
import sys
import time
import traceback
from datetime import datetime
import csv
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.gridspec as gridspec
import matplotlib as mpl
import threading
import queue
import runpy
from multiprocessing import Process

try:
    from PIL import Image, ImageTk
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False

try:
    import pyvisa
except ImportError:
    pyvisa = None

try:
    # Dynamically find the project root and add it to the path
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.abspath(os.path.join(script_dir, os.pardir))
    if project_root not in sys.path:
        sys.path.append(project_root)
except Exception:
    pass # Path manipulation can fail in some environments (e.g., frozen executables)

def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(os.path.dirname(__file__))
    return os.path.join(base_path, relative_path)

def run_script_process(script_path):
    """
    Wrapper function to execute a script using runpy in its own directory.
    This becomes the target for the new, isolated process.
    """
    try:
        os.chdir(os.path.dirname(script_path))
        runpy.run_path(script_path, run_name="__main__")
    except Exception as e:
        print(f"--- Sub-process Error in {os.path.basename(script_path)} ---")
        print(e)
        print("-------------------------")

def launch_plotter_utility():
    """Finds and launches the plotter utility script in a new process."""
    try:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        # Go up 2 levels: delta_mode -> keithley -> pica
        plotter_path = os.path.join(
            script_dir,
            "..", "..", "utils", "PlotterUtil_GUI.py")
        if not os.path.exists(plotter_path):
            messagebox.showerror(
                "File Not Found",
                f"Plotter utility not found at expected path:\n{plotter_path}")
            return
        Process(target=run_script_process, args=(plotter_path,)).start()
    except Exception as e:
        messagebox.showerror("Launch Error", f"Failed to launch Plotter Utility: {e}")

def launch_gpib_scanner():
    """Finds and launches the GPIB scanner utility in a new process."""
    try:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        # Go up 2 levels: delta_mode -> keithley -> pica
        scanner_path = os.path.join(
            script_dir,
            "..", "..", "utils", "GPIB_Instrument_Scanner_GUI.py")
        if not os.path.exists(scanner_path):
            messagebox.showerror(
                "File Not Found",
                f"GPIB Scanner not found at expected path:\n{scanner_path}")
            return
        Process(target=run_script_process, args=(scanner_path,)).start()
    except Exception as e:
        messagebox.showerror("Launch Error", f"Failed to launch GPIB Scanner: {e}")

# -------------------------------------------------------------------------------
# --- BACKEND INSTRUMENT CONTROL ---
# -------------------------------------------------------------------------------
class Backend_Passthrough:
    """ Manages K6221 and K2182 via GPIB passthrough communication. """
    def __init__(self):
        self.visa_queue = queue.Queue()
        self.k6221 = None
        self.rm = None
        if pyvisa:
            try:
                self.rm = pyvisa.ResourceManager()
            except Exception as e:
                print(f"Could not initialize VISA: {e}")

    def connect(self, k6221_visa):
        if not self.rm: raise ConnectionError("VISA is not available.")
        self.k6221 = self.rm.open_resource(k6221_visa); self.k6221.timeout=25000
        print(f"  K6221 Connected: {self.k6221.query('*IDN?').strip()}")

    def configure_instruments(self, compliance):
        print("\n--- [Backend] Configuring Instruments via Passthrough ---")
        self.k6221.write("*RST"); self.k6221.write("SOUR:FUNC CURR"); self.k6221.write("SOUR:CURR:RANG:AUTO ON")
        self.k6221.write(f"SOUR:CURR:COMP {compliance}"); print("  K6221 configured for DC source.")
        print("  Sending commands to K2182 via K6221 RS-232 Port...")
        self.k6221.write("SYST:COMM:SER:SEND '*RST'"); time.sleep(0.5)
        self.k6221.write("SYST:COMM:SER:SEND 'FUNC \"VOLT\"'"); time.sleep(0.5)
        self.k6221.write("SYST:COMM:SER:SEND 'SENS:VOLT:DC:RANG:AUTO ON'"); time.sleep(0.5)
        # --- NEW: Put K2182 into continuous, free-running measurement mode ---
        self.k6221.write("SYST:COMM:SER:SEND 'INIT:CONT ON'"); time.sleep(0.5)
        print("  K2182 configured and set to free-running measurement mode.")

    def set_current(self, current):
        """ Sets the current level on the K6221 and turns the output on. """
        self.k6221.write(f"SOUR:CURR {current}"); time.sleep(0.5)
        self.k6221.write("OUTP:STAT ON"); time.sleep(0.5)

    def read_voltage(self):
        """ Fetches the latest reading from the free-running K2182. """
        # --- NEW: Use FETC? to get the latest reading instead of READ? ---
        self.k6221.write("SYST:COMM:SER:SEND 'FETC?'")

        timeout = 2.0; start_poll_time = time.time(); voltage_str = ""
        while time.time() - start_poll_time < timeout:
            response = self.k6221.query("SYST:COMM:SER:ENT?").strip()
            if response: voltage_str = response; break
            time.sleep(0.1)

        if not voltage_str: raise TimeoutError("No response from K2182 via passthrough.")
        last_line = voltage_str.strip().split('\n')[-1]
        return float(last_line)

    def turn_off_output(self):
        if self.k6221:
            try: self.k6221.write("OUTP:STAT OFF")
            except: pass
            print("  K6221 source is OFF.")

    def close(self):
        if self.k6221:
            # Also tell the 2182 to stop continuous measurement
            try: self.k6221.write("SYST:COMM:SER:SEND 'INIT:CONT OFF'")
            except: pass
            self.turn_off_output()
            self.k6221.close()
            print("  K6221 connection closed.")

# -------------------------------------------------------------------------------
# --- FRONT END (GUI) ---
# -------------------------------------------------------------------------------
class Passthrough_IV_GUI:
    PROGRAM_VERSION = "1.6"
    LOGO_SIZE = 110
    LOGO_FILE_PATH = resource_path("../../assets/LOGO/UGC_DAE_CSR_NBG.jpeg") # Path to your logo image
    CLR_BG_DARK = '#B8A392'; CLR_HEADER = '#E5DCD3'; CLR_FG_LIGHT = '#2C2825'; CLR_TEXT_DARK = '#1A1A1A' # Base colors
    CLR_ACCENT_GOLD = '#BA6B5E'; CLR_ACCENT_GREEN = '#B68B6E'; CLR_ACCENT_RED = '#BA6B5E' # Accent colors
    CLR_CONSOLE_BG = '#E5DCD3'; CLR_GRAPH_BG = '#F4EFEA' # Specific component colors
    FONT_BASE = ('Segoe UI', 11); FONT_TITLE = ('Segoe UI', 13, 'bold'); FONT_CONSOLE = ('Consolas', 10) # Fonts

    def __init__(self, root):
        self.root = root; self.root.title("K6221/2182 I-V Sweep")
        self.root.geometry("1600x950"); self.root.minsize(1300, 850); self.root.configure(bg=self.CLR_BG_DARK)
        self.is_running = False; self.sweep_thread = None; self.logo_image = None
        self.backend = Backend_Passthrough(); self.data_storage = {'current': [], 'voltage': [], 'resistance': []}
        self.setup_styles(); self.create_widgets(); self.root.protocol("WM_DELETE_WINDOW", self._on_closing)

    def setup_styles(self):
        style = ttk.Style(self.root); style.theme_use('clam'); style.configure('TFrame', background=self.CLR_BG_DARK); style.configure('TPanedWindow', background=self.CLR_BG_DARK)
        style.configure('TLabel', background=self.CLR_BG_DARK, foreground=self.CLR_FG_LIGHT, font=self.FONT_BASE); style.configure('TRadiobutton', background=self.CLR_BG_DARK, foreground=self.CLR_FG_LIGHT, font=self.FONT_BASE)
        style.map('TRadiobutton', background=[('active', self.CLR_BG_DARK)]); style.configure('TButton', font=self.FONT_BASE, padding=(10, 9))
        style.configure('Start.TButton', background=self.CLR_ACCENT_GREEN, font=('Segoe UI', 11, 'bold')); style.map('Start.TButton', background=[('active', '#8AB845'), ('hover', '#8AB845')])
        style.configure('Stop.TButton', background=self.CLR_ACCENT_RED, foreground=self.CLR_FG_LIGHT, font=('Segoe UI', 11, 'bold')); style.map('Stop.TButton', background=[('active', '#D63C2A'), ('hover', '#D63C2A')])
        mpl.rcParams.update({'font.family': 'Segoe UI', 'font.size': 11, 'axes.titlesize': 15, 'axes.labelsize': 13})

    def create_widgets(self):
        font_title_main = ('Segoe UI', self.FONT_BASE[1] + 4, 'bold')
        header = tk.Frame(self.root, bg=self.CLR_HEADER); header.pack(side='top', fill='x')

        # --- Plotter Launch Button ---
        plotter_button = ttk.Button(header, text="📈", command=launch_plotter_utility, width=3)
        plotter_button.pack(side='right', padx=10, pady=5)

        # --- GPIB Scanner Launch Button ---
        gpib_button = ttk.Button(header, text="📟", command=launch_gpib_scanner, width=3)
        gpib_button.pack(side='right', padx=(0, 5), pady=5)

        Label(header, text="K6221/2182 I-V Sweep", bg=self.CLR_HEADER, fg=self.CLR_ACCENT_GOLD, font=font_title_main).pack(side='left', padx=20, pady=10)
        main_pane = ttk.PanedWindow(self.root, orient='horizontal'); main_pane.pack(fill='both', expand=True, padx=10, pady=10)
        left_panel = ttk.PanedWindow(main_pane, orient='vertical', width=500); main_pane.add(left_panel, weight=1)
        right_panel = tk.Frame(main_pane, bg=self.CLR_GRAPH_BG); main_pane.add(right_panel, weight=3)
        top_controls = ttk.Frame(left_panel); left_panel.add(top_controls, weight=0)
        console_pane = self.create_console_frame(left_panel); left_panel.add(console_pane, weight=1)
        self.create_info_frame(top_controls); self.create_input_frame(top_controls)
        self.create_graph_frame(right_panel)

    def create_info_frame(self, parent):
        frame = LabelFrame(parent, text='Information', relief='groove', bg=self.CLR_BG_DARK, fg=self.CLR_FG_LIGHT, font=self.FONT_TITLE); frame.pack(pady=5, padx=10, fill='x')
        frame.grid_columnconfigure(1, weight=1)
        logo_canvas = Canvas(frame, width=self.LOGO_SIZE, height=self.LOGO_SIZE, bg=self.CLR_BG_DARK, highlightthickness=0); logo_canvas.grid(row=0, column=0, rowspan=3, padx=15, pady=10)
        self.root.after(50, lambda: self._load_logo(logo_canvas))
        institute_font = ('Segoe UI', self.FONT_BASE[1] + 6, 'bold')
        ttk.Label(frame, text="UGC-DAE Consortium for Scientific Research", font=institute_font, background=self.CLR_BG_DARK).grid(row=0, column=1, padx=10, pady=(10,0), sticky='sw')
        ttk.Label(frame, text="Mumbai Centre", font=institute_font, background=self.CLR_BG_DARK).grid(row=1, column=1, padx=10, sticky='nw')

        ttk.Separator(frame, orient='horizontal').grid(row=2, column=1, sticky='ew', padx=10, pady=8)
 
        # Program details
        details_text = ("Program Name: Delta Mode I-V Sweep\n"
                        "Instruments: K6221 (Source), K2182 (Meter)\n"
                        "Measurement Range: 10 nΩ to 100 MΩ")
        ttk.Label(frame, text=details_text, justify='left').grid(row=3, column=0, columnspan=2, padx=15, pady=(0, 10), sticky='w')

    def _load_logo(self, canvas):
        """Loads the logo image after the main window is drawn."""
        if PIL_AVAILABLE and os.path.exists(self.LOGO_FILE_PATH):
            try:
                img = Image.open(self.LOGO_FILE_PATH).resize((self.LOGO_SIZE, self.LOGO_SIZE), Image.Resampling.LANCZOS)
                self.logo_image = ImageTk.PhotoImage(img) # Keep a reference
                canvas.create_image(self.LOGO_SIZE/2, self.LOGO_SIZE/2, image=self.logo_image)
            except Exception as e:
                self.log(f"ERROR: Failed to load logo. {e}")
    def create_input_frame(self, parent):
        frame = LabelFrame(parent, text='Sweep Parameters', relief='groove', bg=self.CLR_BG_DARK, fg=self.CLR_FG_LIGHT, font=self.FONT_TITLE); frame.pack(pady=5, padx=10, fill='x')
        for i in range(2): frame.grid_columnconfigure(i, weight=1)
        self.entries = {}; pady_val, padx_val = (5, 5), 10
        
        Label(frame, text="Sample Name:").grid(row=0, column=0, columnspan=2, padx=padx_val, pady=pady_val, sticky='w'); self.entries["Sample Name"] = Entry(frame, font=self.FONT_BASE); self.entries["Sample Name"].grid(row=1, column=0, columnspan=2, padx=padx_val, pady=(0, 10), sticky='ew')
        
        Label(frame, text="Keithley 6221 (GPIB Address):").grid(row=2, column=0, padx=padx_val, pady=pady_val, sticky='w'); self.k6221_cb = ttk.Combobox(frame, font=self.FONT_BASE, state='readonly'); self.k6221_cb.grid(row=3, column=0, padx=(padx_val, 5), pady=(0, 5), sticky='ew');
        self.scan_button = ttk.Button(frame, text="Scan", command=self.start_visa_scan); self.scan_button.grid(row=3, column=1, padx=(5, padx_val), pady=(0,5), sticky='ew')

        Label(frame, text="Start Current (A):").grid(row=4, column=0, padx=padx_val, pady=pady_val, sticky='w'); self.entries["Start Current"] = Entry(frame, font=self.FONT_BASE); self.entries["Start Current"].grid(row=5, column=0, padx=(padx_val, 5), pady=(0, 5), sticky='ew'); self.entries["Start Current"].insert(0, "-1E-5")
        Label(frame, text="Stop Current (A):").grid(row=4, column=1, padx=padx_val, pady=pady_val, sticky='w'); self.entries["Stop Current"] = Entry(frame, font=self.FONT_BASE); self.entries["Stop Current"].grid(row=5, column=1, padx=(5, padx_val), pady=(0, 5), sticky='ew'); self.entries["Stop Current"].insert(0, "1E-5")
        
        Label(frame, text="Number of Points:").grid(row=6, column=0, padx=padx_val, pady=pady_val, sticky='w'); self.entries["Num Points"] = Entry(frame, font=self.FONT_BASE); self.entries["Num Points"].grid(row=7, column=0, padx=(padx_val, 5), pady=(0, 5), sticky='ew'); self.entries["Num Points"].insert(0, "51")
        Label(frame, text="Step Delay (s):").grid(row=6, column=1, padx=padx_val, pady=pady_val, sticky='w'); self.entries["Delay"] = Entry(frame, font=self.FONT_BASE); self.entries["Delay"].grid(row=7, column=1, padx=(5, padx_val), pady=(0, 5), sticky='ew'); self.entries["Delay"].insert(0, "0.2")
        
        Label(frame, text="Initial Settle Delay (s):").grid(row=8, column=0, padx=padx_val, pady=pady_val, sticky='w'); self.entries["Initial Delay"] = Entry(frame, font=self.FONT_BASE); self.entries["Initial Delay"].grid(row=9, column=0, padx=(padx_val, 5), pady=(0, 5), sticky='ew'); self.entries["Initial Delay"].insert(0, "2.0")
        Label(frame, text="Compliance (V):").grid(row=8, column=1, padx=padx_val, pady=pady_val, sticky='w'); self.entries["Compliance"] = Entry(frame, font=self.FONT_BASE); self.entries["Compliance"].grid(row=9, column=1, padx=(5, padx_val), pady=(0, 5), sticky='ew'); self.entries["Compliance"].insert(0, "10")
        
        self.sweep_scale_var = tk.StringVar(value="Linear")
        scale_frame = ttk.Frame(frame); scale_frame.grid(row=10, column=0, columnspan=2, padx=padx_val, pady=(5,0), sticky='w')
        Label(scale_frame, text="Sweep Scale:").pack(side='left', anchor='w')
        ttk.Radiobutton(scale_frame, text="Linear", variable=self.sweep_scale_var, value="Linear").pack(side='left', padx=(10,5))
        ttk.Radiobutton(scale_frame, text="Logarithmic", variable=self.sweep_scale_var, value="Logarithmic").pack(side='left')
        
        ttk.Button(frame, text="Browse Save Location...", command=self._browse_save).grid(row=11, column=0, columnspan=2, padx=padx_val, pady=4, sticky='ew')
        self.start_button = ttk.Button(frame, text="Start Sweep", command=self.start_sweep, style='Start.TButton'); self.start_button.grid(row=12, column=0, padx=(padx_val, 5), pady=(10, 10), sticky='ew')
        self.stop_button = ttk.Button(frame, text="Stop Sweep", command=self.stop_sweep, style='Stop.TButton', state='disabled'); self.stop_button.grid(row=12, column=1, padx=(5, padx_val), pady=(10, 10), sticky='ew')
    def create_console_frame(self, parent): frame = LabelFrame(parent, text='Console Output', relief='groove', bg=self.CLR_BG_DARK, fg=self.CLR_FG_LIGHT, font=self.FONT_TITLE); self.console = scrolledtext.ScrolledText(frame, state='disabled', bg=self.CLR_CONSOLE_BG, fg=self.CLR_FG_LIGHT, font=self.FONT_CONSOLE, wrap='word', bd=0); self.console.pack(pady=5, padx=5, fill='both', expand=True); return frame
    def create_graph_frame(self, parent): container = LabelFrame(parent, text='I-V Curve', relief='groove', bg=self.CLR_GRAPH_BG, fg=self.CLR_TEXT_DARK, font=self.FONT_TITLE); container.pack(fill='both', expand=True, padx=5, pady=5); self.figure = Figure(figsize=(8, 8), dpi=100, facecolor=self.CLR_GRAPH_BG); self.canvas = FigureCanvasTkAgg(self.figure, container); gs = gridspec.GridSpec(2, 1, figure=self.figure); self.ax_main = self.figure.add_subplot(gs[0]); self.ax_sub = self.figure.add_subplot(gs[1]); self.line_main, = self.ax_main.plot([], [], 'o-', c=self.CLR_ACCENT_RED, markersize=4); self.ax_main.set_title("I-V Curve", fontweight='bold'); self.ax_main.set_xlabel("Current (A)"); self.ax_main.set_ylabel("Voltage (V)"); self.line_sub, = self.ax_sub.plot([], [], 's:', c=self.CLR_ACCENT_GREEN, markersize=4); self.ax_sub.set_xlabel("Current (A)"); self.ax_sub.set_ylabel("Resistance (Ω)"); [ax.grid(True, ls='--', alpha=0.6) for ax in [self.ax_main, self.ax_sub]]; self.figure.tight_layout(pad=3.0); self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
    def log(self, message): ts = datetime.now().strftime("%H:%M:%S"); self.console.config(state='normal'); self.console.insert('end', f"[{ts}] {message}\n"); self.console.see('end'); self.console.config(state='disabled')
    def start_sweep(self):
        try:
            self.params = { 'name': self.entries["Sample Name"].get(), 'start_i': float(self.entries["Start Current"].get()), 'stop_i': float(self.entries["Stop Current"].get()), 'points': int(self.entries["Num Points"].get()), 'delay': float(self.entries["Delay"].get()), 'initial_delay': float(self.entries["Initial Delay"].get()), 'compliance': float(self.entries["Compliance"].get()), 'k6221_visa': self.k6221_cb.get() }
            if not all(p for k, p in self.params.items() if k != 'name') or not hasattr(self, 'save_path'): raise ValueError("All fields and a save location are required.")
            self.start_button.config(state='disabled'); self.stop_button.config(state='normal'); self.is_running = True; [self.data_storage[key].clear() for key in self.data_storage]; [line.set_data([], []) for line in [self.line_main, self.line_sub]]; self.ax_main.set_title(f"I-V Curve: {self.params['name']}"); self.canvas.draw()
            self.sweep_thread = threading.Thread(target=self._sweep_worker, args=(self.params,), daemon=True); self.sweep_thread.start()
        except Exception as e:
            self.log(f"ERROR on startup: {traceback.format_exc()}"); messagebox.showerror("Input Error", f"{e}")
    def stop_sweep(self):
        if self.is_running: self.is_running = False; self.log("Stop command received..."); self.stop_button.config(state='disabled')
    def _sweep_worker(self, params):
        try:
            self.backend.connect(params['k6221_visa']); self.backend.configure_instruments(params['compliance'])
            if self.sweep_scale_var.get() == 'Linear': current_points = np.linspace(params['start_i'], params['stop_i'], params['points'])
            else:
                if params['start_i'] * params['stop_i'] <= 0: self.log("ERROR: Log sweep cannot cross zero."); self.root.after(0, self._sweep_cleanup_ui); return
                start_log, stop_log = np.log10(abs(params['start_i'])), np.log10(abs(params['stop_i'])); log_sweep = np.logspace(start_log, stop_log, params['points']); current_points = log_sweep * np.sign(params['start_i'])
            ts = datetime.now().strftime("%Y%m%d_%H%M%S"); filename = f"{params['name']}_{ts}_IV.dat"
            self.data_filepath = os.path.join(self.save_path, filename)
            with open(self.data_filepath, 'w', newline='') as f: csv.writer(f).writerow([f"# Sample: {params['name']}"]); csv.writer(f).writerow(["Set Current (A)", "Measured Voltage (V)", "Resistance (Ohm)"])

            self.log("Sweep process starting...")
            self.log(f"Applying dummy current (1e-13 A) for stabilization..."); self.backend.set_current(1e-13)
            self.log(f"Waiting for initial settle delay ({params['initial_delay']}s)..."); time.sleep(params['initial_delay'])

            self.log("Initial stabilization complete. Starting main sweep.")
            for i, current in enumerate(current_points):
                if not self.is_running: self.log("Sweep aborted by user."); break
                self.log(f"Step {i+1}/{len(current_points)}: Setting current to {current:.4e} A...")
                self.backend.set_current(current); time.sleep(params['delay'])
                voltage = self.backend.read_voltage()
                self.root.after(0, self._update_ui_with_point, current, voltage)
            else: self.log("Sweep completed successfully.")
        except Exception as e:
            self.log(f"RUNTIME ERROR: {traceback.format_exc()}")
        finally:
            self.is_running = False; self.backend.close(); self.root.after(0, self._sweep_cleanup_ui)
    def _update_ui_with_point(self, current, voltage):
        resistance = voltage/current if current != 0 else float('inf'); self.log(f"  Read: {voltage:.6e} V, R: {resistance:.6e} Ω")
        self.data_storage['current'].append(current); self.data_storage['voltage'].append(voltage); self.data_storage['resistance'].append(resistance)
        with open(self.data_filepath, 'a', newline='') as f: csv.writer(f).writerow([f"{current:.6e}", f"{voltage:.6e}", f"{resistance:.6e}"])
        self.line_main.set_data(self.data_storage['current'], self.data_storage['voltage']); self.line_sub.set_data(self.data_storage['current'], self.data_storage['resistance'])
        for ax in [self.ax_main, self.ax_sub]: ax.relim(); ax.autoscale_view(True)
        self.figure.tight_layout(pad=3.0); self.canvas.draw_idle()
    def _sweep_cleanup_ui(self):
        self.start_button.config(state='normal'); self.stop_button.config(state='disabled'); self.log("Ready for next sweep.")

    def start_visa_scan(self):
        """Starts the VISA scan in a separate thread to keep the GUI responsive."""
        self.scan_button.config(state='disabled')
        self.log("Scanning for VISA instruments...")
        threading.Thread(target=self._visa_scan_worker, daemon=True).start()
        self.root.after(100, self._process_visa_queue)

    def _visa_scan_worker(self):
        """Worker function that performs the slow VISA scan."""
        if not pyvisa: self.log("ERROR: PyVISA is not installed."); return
        try:
            rm = pyvisa.ResourceManager()
            resources = rm.list_resources()
            self.backend.visa_queue.put(resources) # Use a queue on the backend object
        except Exception as e:
            self.backend.visa_queue.put(e)

    def _process_visa_queue(self):
        """Checks the queue for results from the VISA scan worker."""
        try:
            result = self.backend.visa_queue.get_nowait()
            if isinstance(result, Exception): self.log(f"ERROR during VISA scan: {result}")
            elif result:
                self.log(f"Found: {result}"); self.k6221_cb['values'] = result
                for res in result:
                    if "GPIB0::13" in res: self.k6221_cb.set(res); break
            else: self.log("No VISA instruments found.")
            self.scan_button.config(state='normal')
        except queue.Empty:
            self.root.after(100, self._process_visa_queue)

    def _browse_save(self):
        path = filedialog.askdirectory();
        if path: self.save_path = path; self.log(f"Save location set to: {path}")
    def _on_closing(self):
        if self.is_running: self.is_running = False; time.sleep(0.2)
        self.backend.close(); self.root.destroy()

def main():
    root = tk.Tk()
    app = Passthrough_IV_GUI(root)
    root.mainloop()

if __name__ == '__main__':
    main()