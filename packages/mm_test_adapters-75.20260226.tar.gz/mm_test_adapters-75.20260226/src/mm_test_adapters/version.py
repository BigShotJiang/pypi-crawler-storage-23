__version__ = "75.20260226"
GIT_REF = "3c6312a"
URL = "https://github.com/micro-manager/mmCoreAndDevices/tree/3c6312a"