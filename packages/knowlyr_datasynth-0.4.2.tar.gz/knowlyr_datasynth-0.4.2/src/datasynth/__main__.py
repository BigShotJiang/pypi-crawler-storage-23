"""Allow running as `python -m datasynth`."""

from datasynth.cli import main

main()
