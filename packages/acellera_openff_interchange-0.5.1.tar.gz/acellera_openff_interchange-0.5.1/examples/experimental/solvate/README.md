# Solvate

In this example, a small protein is solvated and prepared with SMIRNOFF force fields.
