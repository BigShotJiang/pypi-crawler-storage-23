# LAMMPS

In this example, a prepared box of solvents is parametrized with Sage and and simulated with LAMMPS via Interchange.
