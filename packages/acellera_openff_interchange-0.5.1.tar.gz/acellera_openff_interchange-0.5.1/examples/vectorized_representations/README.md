# Vectorized representations

In this example, a small system is prepared and its vectorized representations explored.
