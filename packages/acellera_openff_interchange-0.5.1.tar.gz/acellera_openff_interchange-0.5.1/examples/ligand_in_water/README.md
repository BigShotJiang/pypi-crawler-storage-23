# Ligand in water

In this example, a ligand is solvated in water, parametrized with Sage and TIP3P, and a short OpenMM simulation is run. The same system is then parametrized and run with OPC.
