"""Operations on and related to `Interchange` objects."""
