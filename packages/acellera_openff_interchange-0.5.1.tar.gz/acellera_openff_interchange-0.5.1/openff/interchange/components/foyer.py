"""Models and utilities for processing Foyer data."""
