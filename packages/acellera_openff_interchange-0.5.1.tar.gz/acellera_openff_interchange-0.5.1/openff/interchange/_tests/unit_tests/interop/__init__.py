"""Unit tests for `interop` submodule."""
