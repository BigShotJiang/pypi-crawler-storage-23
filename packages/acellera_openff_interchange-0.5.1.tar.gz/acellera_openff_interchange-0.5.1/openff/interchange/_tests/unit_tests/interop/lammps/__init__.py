"""Tests with LAMMPS."""
