"""Dashboard authentication and authorization."""
