"""SQLite database layer for the governance dashboard."""
