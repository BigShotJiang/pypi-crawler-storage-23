"""Compliance report generation."""
