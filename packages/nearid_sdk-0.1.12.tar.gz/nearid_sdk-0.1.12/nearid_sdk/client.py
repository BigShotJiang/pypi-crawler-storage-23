from __future__ import annotations

from typing import Any, Dict, Generator, Optional

from .http import NearIDHttpClient
from . import parsers
from .types import (
    AttendanceResponse,
    BillingSummary,
    IncidentList,
    Org,
    OrgConfig,
    OrgList,
    OrgSettings,
    PresenceEventList,
    PresenceSessionList,
    Receiver,
    ReceiverHealth,
    ReceiverList,
    ReceiverStatus,
    RealtimeMetrics,
    SessionConfig,
    SessionList,
    SessionSummaryResponse,
    SafetyStatus,
    SafetySummary,
    Link,
    LinkList,
    LinkResponse,
    LinkV2Response,
)


class NearIDClient:
    def __init__(
        self,
        api_key: str,
        org_id: str,
        base_url: str,
        retries: int = 2,
    ) -> None:
        self.org_id = org_id
        self.http = NearIDHttpClient(base_url=base_url, api_key=api_key, retries=retries)

    # ---- Receivers ----
    def list_receivers(
        self,
        org_id: Optional[str] = None,
        cursor: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> ReceiverList | Dict[str, Any]:
        org = org_id or self.org_id
        params: Dict[str, Any] = {}
        if cursor:
            params["cursor"] = cursor
        if limit:
            params["limit"] = limit
        raw = self.http.get_json(f"/v2/orgs/{org}/receivers", params=params)
        return parsers.to_receiver_list(raw)

    def create_receiver(
        self,
        receiver_id: str,
        auth_mode: str,
        display_name: Optional[str] = None,
        location_label: Optional[str] = None,
        shared_secret: Optional[str] = None,
        public_key_pem: Optional[str] = None,
        firmware_version: Optional[str] = None,
        status: Optional[str] = None,
        org_id: Optional[str] = None,
    ) -> Receiver | Dict[str, Any]:
        org = org_id or self.org_id
        raw = self.http.post_json(
            f"/v2/orgs/{org}/receivers",
            {
                "receiver_id": receiver_id,
                "display_name": display_name,
                "location_label": location_label,
                "auth_mode": auth_mode,
                "shared_secret": shared_secret,
                "public_key_pem": public_key_pem,
                "firmware_version": firmware_version,
                "status": status,
            },
        )
        return parsers.to_receiver(raw)

    def update_receiver(
        self,
        receiver_id: str,
        display_name: Optional[str] = None,
        location_label: Optional[str] = None,
        auth_mode: Optional[str] = None,
        shared_secret: Optional[str] = None,
        public_key_pem: Optional[str] = None,
        firmware_version: Optional[str] = None,
        status: Optional[str] = None,
        org_id: Optional[str] = None,
    ) -> Receiver | Dict[str, Any]:
        org = org_id or self.org_id
        raw = self.http.patch_json(
            f"/v2/orgs/{org}/receivers/{receiver_id}",
            {
                "display_name": display_name,
                "location_label": location_label,
                "auth_mode": auth_mode,
                "shared_secret": shared_secret,
                "public_key_pem": public_key_pem,
                "firmware_version": firmware_version,
                "status": status,
            },
        )
        return parsers.to_receiver(raw)

    # ---- Presence read ----
    def list_events(
        self,
        user_ref: Optional[str] = None,
        receiver_id: Optional[str] = None,
        from_ts: Optional[str] = None,
        to_ts: Optional[str] = None,
        page: Optional[int] = None,
        limit: Optional[int] = None,
        org_id: Optional[str] = None,
    ) -> PresenceEventList | Dict[str, Any]:
        org = org_id or self.org_id
        params: Dict[str, Any] = {"orgId": org}
        if user_ref:
            params["userRef"] = user_ref
        if receiver_id:
            params["receiverId"] = receiver_id
        if from_ts:
            params["from"] = from_ts
        if to_ts:
            params["to"] = to_ts
        if page is not None:
            params["page"] = page
        if limit is not None:
            params["limit"] = limit
        raw = self.http.get_json("/v1/presence/events", params=params)
        return parsers.to_presence_event_list(raw)

    def list_presence_events(self, **kwargs: Any) -> PresenceEventList | Dict[str, Any]:
        return self.list_events(**kwargs)

    def list_sessions(
        self,
        user_ref: Optional[str] = None,
        receiver_id: Optional[str] = None,
        device_id_hash: Optional[str] = None,
        from_ts: Optional[str] = None,
        to_ts: Optional[str] = None,
        page: Optional[int] = None,
        limit: Optional[int] = None,
        org_id: Optional[str] = None,
    ) -> PresenceSessionList | Dict[str, Any]:
        org = org_id or self.org_id
        params: Dict[str, Any] = {"orgId": org}
        if user_ref:
            params["userRef"] = user_ref
        if receiver_id:
            params["receiverId"] = receiver_id
        if device_id_hash:
            params["deviceIdHash"] = device_id_hash
        if from_ts:
            params["from"] = from_ts
        if to_ts:
            params["to"] = to_ts
        if page is not None:
            params["page"] = page
        if limit is not None:
            params["limit"] = limit
        raw = self.http.get_json("/v1/presence/sessions", params=params)
        return parsers.to_presence_session_list(raw)

    def list_presence_sessions(self, **kwargs: Any) -> PresenceSessionList | Dict[str, Any]:
        return self.list_sessions(**kwargs)

    # ---- Links ----
    def list_links(self, user_ref: Optional[str] = None, org_id: Optional[str] = None) -> LinkList | Dict[str, Any]:
        org = org_id or self.org_id
        params: Dict[str, Any] = {"orgId": org}
        if user_ref:
            params["userRef"] = user_ref
        raw = self.http.get_json("/v1/links", params=params)
        return parsers.to_link_list(raw)

    def link_presence_session(self, presence_session_id: str, user_ref: str, org_id: Optional[str] = None) -> LinkResponse | Dict[str, Any]:
        org = org_id or self.org_id
        raw = self.http.post_json(
            "/v1/links",
            {"orgId": org, "userRef": user_ref, "presenceSessionId": presence_session_id},
        )
        return parsers.to_link_response(raw)

    def create_link(self, user_ref: str, device_id: Optional[str] = None, org_id: Optional[str] = None) -> LinkResponse | Dict[str, Any]:
        org = org_id or self.org_id
        payload: Dict[str, Any] = {"orgId": org, "userRef": user_ref}
        if device_id:
            payload["deviceId"] = device_id
        raw = self.http.post_json("/v1/links", payload)
        return parsers.to_link_response(raw)

    def create_link_v2(
        self,
        org_id: str,
        presence_session_id: str,
        user_ref: str,
        registration_blob: Optional[str] = None,
    ) -> LinkV2Response | Dict[str, Any]:
        payload: Dict[str, Any] = {
            "org_id": org_id,
            "presence_session_id": presence_session_id,
            "user_ref": user_ref,
        }
        if registration_blob:
            payload["registration_blob"] = registration_blob
        raw = self.http.post_json("/v2/link", payload)
        return parsers.to_link_v2_response(raw)

    def activate_link(self, link_id: str) -> LinkResponse | Dict[str, Any]:
        raw = self.http.post_json(f"/v1/links/{link_id}/activate")
        return parsers.to_link_response(raw)

    def revoke_link(self, link_id: str) -> LinkResponse | Dict[str, Any]:
        raw = self.http.post_json(f"/v1/links/{link_id}/revoke")
        return parsers.to_link_response(raw)

    def revoke_link_v2(self, link_id: str, org_id: str) -> LinkV2Response | Dict[str, Any]:
        raw = self.http.delete_json(f"/v2/link/{link_id}", payload={"org_id": org_id})
        return parsers.to_link_v2_response(raw)

    def unlink(self, link_id: str) -> Any:
        return self.revoke_link(link_id)

    # ---- Orgs ----
    def list_orgs(self, params: Optional[Dict[str, Any]] = None) -> OrgList | Dict[str, Any]:
        raw = self.http.get_json("/v2/orgs", params=params)
        return parsers.to_org_list(raw)

    def get_org(self, org_id: str) -> Org | Dict[str, Any]:
        raw = self.http.get_json(f"/v2/orgs/{org_id}")
        return parsers.to_org(raw)

    def get_org_settings(self, org_id: str) -> OrgSettings | Dict[str, Any]:
        raw = self.http.get_json(f"/v2/orgs/{org_id}/settings")
        return parsers.to_org_settings(raw)

    def update_org_settings(self, org_id: str, settings: Dict[str, Any]) -> OrgSettings | Dict[str, Any]:
        raw = self.http.patch_json(f"/v2/orgs/{org_id}/settings", settings)
        return parsers.to_org_settings(raw)

    def get_org_config(self, org_id: str) -> OrgConfig | Dict[str, Any]:
        raw = self.http.get_json(f"/v2/orgs/{org_id}/config")
        return parsers.to_org_config(raw)

    def update_org_config(self, org_id: str, config: Dict[str, Any]) -> OrgConfig | Dict[str, Any]:
        raw = self.http.patch_json(f"/v2/orgs/{org_id}/config", config)
        return parsers.to_org_config(raw)

    def get_org_metrics_realtime(self, org_id: str, params: Optional[Dict[str, Any]] = None) -> RealtimeMetrics | Dict[str, Any]:
        raw = self.http.get_json(f"/v2/orgs/{org_id}/metrics/realtime", params=params)
        return parsers.to_realtime_metrics(raw)

    def list_org_users(self, org_id: str) -> Any:
        raw = self.http.get_json(f"/v2/orgs/{org_id}/users")
        return parsers.to_org_users(raw)

    # ---- Receiver health ----
    def list_receivers_admin(self, params: Optional[Dict[str, Any]] = None) -> ReceiverList | Dict[str, Any]:
        raw = self.http.get_json("/api/receivers", params=params)
        return parsers.to_receiver_list(raw)

    def get_receiver(self, receiver_id: str) -> Receiver | Dict[str, Any]:
        raw = self.http.get_json(f"/api/receivers/{receiver_id}")
        return parsers.to_receiver(raw)

    def update_receiver_admin(self, receiver_id: str, payload: Dict[str, Any]) -> Receiver | Dict[str, Any]:
        raw = self.http.patch_json(f"/api/receivers/{receiver_id}", payload)
        return parsers.to_receiver(raw)

    def get_receiver_status(self, receiver_id: str) -> ReceiverStatus | Dict[str, Any]:
        raw = self.http.get_json(f"/api/receivers/{receiver_id}/status")
        return parsers.to_receiver_status(raw)

    def get_receiver_health(self, receiver_id: str) -> ReceiverHealth | Dict[str, Any]:
        raw = self.http.get_json(f"/api/receivers/{receiver_id}/health")
        return parsers.to_receiver_health(raw)

    # ---- Sessions lifecycle (org config sessions) ----
    def list_org_sessions(self, params: Optional[Dict[str, Any]] = None) -> SessionList | Dict[str, Any]:
        raw = self.http.get_json("/api/sessions", params=params)
        return parsers.to_session_list(raw)

    def get_org_sessions_summary(self, params: Optional[Dict[str, Any]] = None) -> SessionSummaryResponse | Dict[str, Any]:
        raw = self.http.get_json("/api/sessions/summary", params=params)
        return parsers.to_session_summary_response(raw)

    def create_org_session(self, payload: Dict[str, Any]) -> SessionConfig | Dict[str, Any]:
        raw = self.http.post_json("/api/sessions", payload)
        return parsers.to_session_config(raw)

    def update_org_session(self, session_id: str, payload: Dict[str, Any]) -> SessionConfig | Dict[str, Any]:
        raw = self.http.patch_json(f"/api/sessions/{session_id}", payload)
        return parsers.to_session_config(raw)

    def delete_org_session(self, session_id: str) -> Dict[str, Any]:
        return self.http.delete_json(f"/api/sessions/{session_id}")

    def finalize_org_session(self, session_id: str) -> SessionConfig | Dict[str, Any]:
        raw = self.http.post_json(f"/api/sessions/{session_id}/finalize")
        return parsers.to_session_config(raw)

    # ---- Attendance + presence (org console) ----
    def get_presence_live(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        return self.http.get_json("/api/presence/live", params=params)

    def get_presence_logs(self, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        return self.http.get_json("/api/presence/logs", params=params)

    def get_presence_events(self, params: Optional[Dict[str, Any]] = None) -> PresenceEventList | Dict[str, Any]:
        raw = self.http.get_json("/api/presence/events", params=params)
        return parsers.to_presence_event_list(raw)

    def list_locations(self) -> Any:
        return self.http.get_json("/api/locations")

    def list_groups(self) -> Any:
        return self.http.get_json("/api/groups")

    def create_group(self, payload: Dict[str, Any]) -> Any:
        return self.http.post_json("/api/groups", payload)

    def update_group(self, group_id: str, payload: Dict[str, Any]) -> Any:
        return self.http.patch_json(f"/api/groups/{group_id}", payload)

    def delete_group(self, group_id: str) -> Any:
        return self.http.delete_json(f"/api/groups/{group_id}")

    def get_attendance(self, params: Optional[Dict[str, Any]] = None) -> AttendanceResponse | Dict[str, Any]:
        raw = self.http.get_json("/api/attendance", params=params)
        return parsers.to_attendance_response(raw)

    def export_attendance_csv(self, params: Optional[Dict[str, Any]] = None) -> str:
        return self.http.get_text("/api/attendance/export", params=params)

    # ---- Billing ----
    def get_billing_summary(self) -> BillingSummary | Dict[str, Any]:
        raw = self.http.get_json("/api/org/billing")
        return parsers.to_billing_summary(raw)

    def list_invoices(self) -> Any:
        raw = self.http.get_json("/api/org/invoices")
        return [parsers.to_invoice(item) for item in raw]

    def get_invoice_pdf(self, invoice_id: str) -> bytes:
        return self.http.get_bytes(f"/api/org/invoices/{invoice_id}/pdf")

    # ---- Incidents + safety ----
    def list_incidents(self, params: Optional[Dict[str, Any]] = None) -> IncidentList | Dict[str, Any]:
        raw = self.http.get_json("/api/incidents", params=params)
        return parsers.to_incident_list(raw)

    def get_incident(self, incident_id: str) -> Any:
        raw = self.http.get_json(f"/api/incidents/{incident_id}")
        return parsers.to_incident(raw)

    def get_incident_rollcall(self, incident_id: str) -> Any:
        return self.http.get_json(f"/api/incidents/{incident_id}/rollcall")

    def get_safety_status(self) -> SafetyStatus | Dict[str, Any]:
        raw = self.http.get_json("/api/safety/status")
        return parsers.to_safety_status(raw)

    def get_safety_summary(self) -> SafetySummary | Dict[str, Any]:
        raw = self.http.get_json("/api/safety/summary")
        return parsers.to_safety_summary(raw)

    # ---- Pagination helpers ----
    def iterate_events(self, **kwargs: Any) -> Generator[Any, None, None]:
        page = int(kwargs.get("page") or 1)
        while True:
            resp = self.list_events(page=page, **kwargs)
            events = resp.events if hasattr(resp, "events") else resp.get("events", [])
            for evt in events or []:
                yield evt
            next_page = resp.next_page if hasattr(resp, "next_page") else resp.get("nextPage")
            if not next_page:
                break
            page = int(next_page)

    def iterate_sessions(self, **kwargs: Any) -> Generator[Any, None, None]:
        page = int(kwargs.get("page") or 1)
        while True:
            resp = self.list_sessions(page=page, **kwargs)
            sessions = resp.sessions if hasattr(resp, "sessions") else resp.get("sessions", [])
            for sess in sessions or []:
                yield sess
            next_page = resp.next_page if hasattr(resp, "next_page") else resp.get("nextPage")
            if not next_page:
                break
            page = int(next_page)

    def iterate_receivers(self, org_id: Optional[str] = None, limit: Optional[int] = None) -> Generator[Any, None, None]:
        cursor: Optional[str] = None
        while True:
            resp = self.list_receivers(org_id=org_id, cursor=cursor, limit=limit)
            items = resp.items if hasattr(resp, "items") else resp.get("items", [])
            for item in items or []:
                yield item
            next_cursor = resp.next_cursor if hasattr(resp, "next_cursor") else resp.get("nextCursor")
            if not next_cursor:
                break
            cursor = str(next_cursor)
