from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional


@dataclass(frozen=True)
class PresenceEvent:
    id: Optional[str] = None
    org_id: Optional[str] = None
    receiver_id: Optional[str] = None
    user_ref: Optional[str] = None
    timestamp: Optional[str] = None
    verification_status: Optional[str] = None
    session_id: Optional[str] = None
    device_id_hash: Optional[str] = None
    server_timestamp: Optional[str] = None
    auth_result: Optional[str] = None
    reason: Optional[str] = None
    raw: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class PresenceSession:
    id: Optional[str] = None
    org_id: Optional[str] = None
    receiver_id: Optional[str] = None
    user_ref: Optional[str] = None
    device_id_hash: Optional[str] = None
    started_at: Optional[str] = None
    ended_at: Optional[str] = None
    session_id: Optional[str] = None
    session_type: Optional[str] = None
    raw: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class Link:
    id: Optional[str] = None
    org_id: Optional[str] = None
    user_ref: Optional[str] = None
    device_id: Optional[str] = None
    status: Optional[str] = None
    raw: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class LinkResponse:
    status: Optional[str] = None
    link: Optional[Link] = None
    raw: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class LinkV2Response:
    status: Optional[str] = None
    link_id: Optional[str] = None
    user_ref: Optional[str] = None
    device_id: Optional[str] = None
    revoked_at: Optional[str] = None
    raw: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class LinkList:
    status: Optional[str] = None
    links: Optional[List[Link]] = None
    raw: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class WebhookPresenceCheckIn:
    type: str = "presence.check_in"
    event_id: Optional[str] = None
    org_id: Optional[str] = None
    device_id: Optional[str] = None
    link_id: Optional[str] = None
    user_ref: Optional[str] = None
    receiver_id: Optional[str] = None
    timestamp: Optional[str] = None
    suspicious: Optional[bool] = None
    raw: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class WebhookPresenceUnknown:
    type: str = "presence.unknown"
    event_id: Optional[str] = None
    org_id: Optional[str] = None
    device_id: Optional[str] = None
    presence_session_id: Optional[str] = None
    receiver_id: Optional[str] = None
    timestamp: Optional[str] = None
    raw: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class WebhookLinkCreated:
    type: str = "link.created"
    link_id: Optional[str] = None
    device_id: Optional[str] = None
    user_ref: Optional[str] = None
    raw: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class WebhookLinkRevoked:
    type: str = "link.revoked"
    link_id: Optional[str] = None
    raw: Optional[Dict[str, Any]] = None


WebhookEvent = WebhookPresenceCheckIn | WebhookPresenceUnknown | WebhookLinkCreated | WebhookLinkRevoked


@dataclass(frozen=True)
class Receiver:
    receiver_id: Optional[str] = None
    org_id: Optional[str] = None
    display_name: Optional[str] = None
    location_label: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    auth_mode: Optional[str] = None
    firmware_version: Optional[str] = None
    status: Optional[str] = None
    last_seen_at: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    raw: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class ReceiverStatus:
    receiver_id: Optional[str] = None
    status: Optional[str] = None
    last_seen_at: Optional[str] = None
    incidents: Optional[List[Dict[str, Any]]] = None
    raw: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class ReceiverHealth:
    receiver_id: Optional[str] = None
    status: Optional[str] = None
    last_seen_at: Optional[str] = None
    metrics: Optional[Dict[str, Any]] = None
    raw: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class Org:
    id: Optional[str] = None
    name: Optional[str] = None
    slug: Optional[str] = None
    status: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    plan: Optional[str] = None
    enabled_modules: Optional[List[str]] = None
    raw: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class OrgSettings:
    timezone: Optional[str] = None
    region: Optional[str] = None
    country: Optional[str] = None
    raw: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class OrgConfig:
    raw: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class RealtimeMetrics:
    active_receivers: Optional[int] = None
    receivers_window_minutes: Optional[int] = None
    active_sessions: Optional[int] = None
    present_users: Optional[int] = None
    incidents_open: Optional[int] = None
    raw: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class OrgUser:
    id: Optional[str] = None
    email: Optional[str] = None
    name: Optional[str] = None
    role: Optional[str] = None
    status: Optional[str] = None
    raw: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class SessionConfig:
    session_id: Optional[str] = None
    name: Optional[str] = None
    start_time: Optional[str] = None
    end_time: Optional[str] = None
    location_id: Optional[str] = None
    group_id: Optional[str] = None
    session_type: Optional[str] = None
    finalized_at: Optional[str] = None
    report_url: Optional[str] = None
    raw: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class SessionSummary:
    session_id: Optional[str] = None
    session_name: Optional[str] = None
    present_count: Optional[int] = None
    late_count: Optional[int] = None
    absent_count: Optional[int] = None
    total_count: Optional[int] = None
    raw: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class SessionSummaryResponse:
    sessions: Optional[List[SessionSummary]] = None
    rules: Optional[Dict[str, Any]] = None
    raw: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class AttendanceEntry:
    session_id: Optional[str] = None
    session_name: Optional[str] = None
    user_ref: Optional[str] = None
    status: Optional[str] = None
    first_seen_at: Optional[str] = None
    last_seen_at: Optional[str] = None
    raw: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class BillingDecision:
    id: Optional[str] = None
    session_id: Optional[str] = None
    session_type: Optional[str] = None
    verified_count: Optional[int] = None
    base_price_cents: Optional[int] = None
    overage_count: Optional[int] = None
    overage_price_cents: Optional[int] = None
    quiz_count: Optional[int] = None
    quiz_fee_cents: Optional[int] = None
    final_price_cents: Optional[int] = None
    finalized_at: Optional[str] = None
    invoice_id: Optional[str] = None
    raw: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class InvoiceLine:
    id: Optional[str] = None
    kind: Optional[str] = None
    reference_id: Optional[str] = None
    description: Optional[str] = None
    quantity: Optional[int] = None
    unit_price_cents: Optional[int] = None
    total_cents: Optional[int] = None
    raw: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class Invoice:
    id: Optional[str] = None
    status: Optional[str] = None
    period_start: Optional[str] = None
    period_end: Optional[str] = None
    total_cents: Optional[int] = None
    currency: Optional[str] = None
    created_at: Optional[str] = None
    lines: Optional[List[InvoiceLine]] = None
    raw: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class BillingSummary:
    plan: Optional[str] = None
    seat_count: Optional[int] = None
    seat_price_cents: Optional[int] = None
    seat_total_cents: Optional[int] = None
    decision_count: Optional[int] = None
    decision_total_cents: Optional[int] = None
    unbilled_decision_count: Optional[int] = None
    total_cents: Optional[int] = None
    period_start: Optional[str] = None
    period_end: Optional[str] = None
    decisions: Optional[List[BillingDecision]] = None
    invoices: Optional[List[Invoice]] = None
    raw: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class Incident:
    id: Optional[str] = None
    type: Optional[str] = None
    severity: Optional[str] = None
    status: Optional[str] = None
    started_at: Optional[str] = None
    resolved_at: Optional[str] = None
    location_id: Optional[str] = None
    workzone_id: Optional[str] = None
    created_by: Optional[str] = None
    notes: Optional[str] = None
    timestamp: Optional[str] = None
    title: Optional[str] = None
    description: Optional[str] = None
    use_case: Optional[str] = None
    raw: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class SafetyStatus:
    active_incidents: Optional[List[Incident]] = None
    raw: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class SafetySummary:
    totals: Optional[Dict[str, Any]] = None
    raw: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class PresenceEventList:
    events: Optional[List[PresenceEvent]] = None
    page: Optional[int] = None
    next_page: Optional[int] = None
    raw: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class PresenceSessionList:
    sessions: Optional[List[PresenceSession]] = None
    page: Optional[int] = None
    next_page: Optional[int] = None
    raw: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class ReceiverList:
    items: Optional[List[Receiver]] = None
    next_cursor: Optional[str] = None
    raw: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class OrgList:
    items: Optional[List[Org]] = None
    raw: Optional[List[Dict[str, Any]]] = None


@dataclass(frozen=True)
class SessionList:
    items: Optional[List[SessionConfig]] = None
    page: Optional[int] = None
    page_size: Optional[int] = None
    total_pages: Optional[int] = None
    total_count: Optional[int] = None
    raw: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class AttendanceResponse:
    sessions: Optional[List[AttendanceEntry]] = None
    rules: Optional[Dict[str, Any]] = None
    page: Optional[int] = None
    next_page: Optional[int] = None
    raw: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class IncidentList:
    items: Optional[List[Incident]] = None
    page: Optional[int] = None
    page_size: Optional[int] = None
    total_pages: Optional[int] = None
    total_count: Optional[int] = None
    raw: Optional[Dict[str, Any]] = None
