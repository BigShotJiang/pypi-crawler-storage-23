from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional
import time

import requests


@dataclass
class NearIDApiError(Exception):
    message: str
    status: int
    body: Any

    def __str__(self) -> str:
        return f"{self.message} (HTTP {self.status})"


class NearIDHttpClient:
    def __init__(self, base_url: str, api_key: str, retries: int = 2, timeout: int = 30) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.retries = retries
        self.timeout = timeout

    def get_json(self, path: str, params: Optional[Dict[str, Any]] = None) -> Any:
        return self._request("GET", path, params=params)

    def get_text(self, path: str, params: Optional[Dict[str, Any]] = None) -> str:
        return self._request_raw("GET", path, params=params).decode("utf-8", errors="replace")

    def get_bytes(self, path: str, params: Optional[Dict[str, Any]] = None) -> bytes:
        return self._request_raw("GET", path, params=params)

    def post_json(self, path: str, body: Optional[Dict[str, Any]] = None) -> Any:
        return self._request("POST", path, json=body)

    def patch_json(self, path: str, body: Optional[Dict[str, Any]] = None) -> Any:
        return self._request("PATCH", path, json=body)

    def delete_json(self, path: str, body: Optional[Dict[str, Any]] = None) -> Any:
        return self._request("DELETE", path, json=body)

    def _request(self, method: str, path: str, params: Optional[Dict[str, Any]] = None, json: Any = None) -> Any:
        url = f"{self.base_url}/{path.lstrip('/')}"
        headers = {"Authorization": f"Bearer {self.api_key}"}
        attempt = 0
        while True:
            try:
                resp = requests.request(
                    method,
                    url,
                    headers=headers,
                    params=params,
                    json=json,
                    timeout=self.timeout,
                )
                body = None
                if resp.text:
                    try:
                        body = resp.json()
                    except ValueError:
                        body = resp.text
                if resp.status_code == 429 and attempt < self.retries:
                    wait_ms = _retry_delay_ms(resp.headers.get("Retry-After"), attempt)
                    time.sleep(wait_ms / 1000.0)
                    attempt += 1
                    continue
                if resp.status_code >= 400:
                    raise NearIDApiError("API request failed", resp.status_code, body)
                return body
            except Exception as exc:
                if attempt >= self.retries or not _is_retryable(exc):
                    raise
                attempt += 1
                time.sleep(0.2 * attempt)

    def _request_raw(self, method: str, path: str, params: Optional[Dict[str, Any]] = None, json: Any = None) -> bytes:
        url = f"{self.base_url}/{path.lstrip('/')}"
        headers = {"Authorization": f"Bearer {self.api_key}"}
        attempt = 0
        while True:
            try:
                resp = requests.request(
                    method,
                    url,
                    headers=headers,
                    params=params,
                    json=json,
                    timeout=self.timeout,
                )
                if resp.status_code == 429 and attempt < self.retries:
                    wait_ms = _retry_delay_ms(resp.headers.get("Retry-After"), attempt)
                    time.sleep(wait_ms / 1000.0)
                    attempt += 1
                    continue
                if resp.status_code >= 400:
                    body: Any = None
                    if resp.text:
                        try:
                            body = resp.json()
                        except ValueError:
                            body = resp.text
                    raise NearIDApiError("API request failed", resp.status_code, body)
                return resp.content
            except Exception as exc:
                if attempt >= self.retries or not _is_retryable(exc):
                    raise
                attempt += 1
                time.sleep(0.2 * attempt)


def _is_retryable(exc: Exception) -> bool:
    if isinstance(exc, NearIDApiError):
        return 500 <= exc.status < 600 or exc.status == 429
    return True


def _retry_delay_ms(retry_after: Optional[str], attempt: int) -> int:
    if retry_after:
        try:
            parsed = int(retry_after)
            if parsed > 0:
                return min(parsed * 1000, 30000)
        except ValueError:
            pass
    return min(int(500 * (2 ** attempt)), 30000)
