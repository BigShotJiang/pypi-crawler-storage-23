from __future__ import annotations

import json
from pathlib import Path

from nearid_sdk import verify_webhook_signature


def load_vectors() -> list[dict]:
    root = Path(__file__).resolve().parents[3]
    path = root / "protocol" / "test-vectors" / "v2" / "webhook_signatures.json"
    payload = json.loads(path.read_text(encoding="utf-8"))
    return payload["vectors"]


def test_webhook_vectors_match() -> None:
    for vector in load_vectors():
        assert verify_webhook_signature(
            secret=vector["webhook_secret"],
            timestamp=vector["timestamp"],
            raw_body=vector["raw_body"].encode("utf-8"),
            signature_hex=vector["signature_hex"],
        )


def test_webhook_vectors_reject_tampered() -> None:
    vector = load_vectors()[0]
    tampered = ("0" if vector["signature_hex"][0] != "0" else "1") + vector["signature_hex"][1:]
    assert not verify_webhook_signature(
        secret=vector["webhook_secret"],
        timestamp=vector["timestamp"],
        raw_body=vector["raw_body"].encode("utf-8"),
        signature_hex=tampered,
    )
