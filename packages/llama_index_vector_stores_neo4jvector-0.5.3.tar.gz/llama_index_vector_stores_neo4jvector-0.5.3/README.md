# LlamaIndex Vector_Stores Integration: Neo4Jvector
