from kscli.cli import main

main()
