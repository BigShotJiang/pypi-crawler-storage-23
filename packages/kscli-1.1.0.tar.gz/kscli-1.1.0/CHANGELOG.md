# CHANGELOG

<!-- version list -->

## v1.1.0 (2026-02-22)

### Features

- Complete release process ([#1](https://github.com/knowledgestack/ks-cli/pull/1),
  [`513b295`](https://github.com/knowledgestack/ks-cli/commit/513b2956caa57c3d1e68c3003fea4f6e13ee13c1))


## v1.0.1 (2026-02-22)

### Bug Fixes

- Ci
  ([`23412c8`](https://github.com/knowledgestack/ks-cli/commit/23412c870b59a272c62e14032400f3f4a3a70a37))


## v1.0.0 (2026-02-22)

- Initial Release
