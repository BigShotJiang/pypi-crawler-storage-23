from typing import Union
from meshtensor.core.meshtensor import Meshtensor as _Meshtensor
from meshtensor.core.async_meshtensor import AsyncMeshtensor as _AsyncMeshtensor


class Wallets:
    """Class for managing coldkey, hotkey, wallet operations."""

    def __init__(self, meshtensor: Union["_Meshtensor", "_AsyncMeshtensor"]):
        self.does_hotkey_exist = meshtensor.does_hotkey_exist
        self.filter_netuids_by_registered_hotkeys = (
            meshtensor.filter_netuids_by_registered_hotkeys
        )
        self.is_hotkey_registered_any = meshtensor.is_hotkey_registered_any
        self.is_hotkey_registered = meshtensor.is_hotkey_registered
        self.is_hotkey_registered_on_subnet = meshtensor.is_hotkey_registered_on_subnet
        self.is_hotkey_delegate = meshtensor.is_hotkey_delegate
        self.get_balance = meshtensor.get_balance
        self.get_balances = meshtensor.get_balances
        self.get_children = meshtensor.get_children
        self.get_children_pending = meshtensor.get_children_pending
        self.get_delegate_by_hotkey = meshtensor.get_delegate_by_hotkey
        self.get_delegate_take = meshtensor.get_delegate_take
        self.get_delegated = meshtensor.get_delegated
        self.get_hotkey_owner = meshtensor.get_hotkey_owner
        self.get_hotkey_stake = meshtensor.get_hotkey_stake
        self.get_minimum_required_stake = meshtensor.get_minimum_required_stake
        self.get_netuids_for_hotkey = meshtensor.get_netuids_for_hotkey
        self.get_owned_hotkeys = meshtensor.get_owned_hotkeys
        self.get_parents = meshtensor.get_parents
        self.get_stake = meshtensor.get_stake
        self.get_stake_add_fee = meshtensor.get_stake_add_fee
        self.get_stake_for_coldkey_and_hotkey = (
            meshtensor.get_stake_for_coldkey_and_hotkey
        )
        self.get_stake_for_hotkey = meshtensor.get_stake_for_hotkey
        self.get_stake_info_for_coldkey = meshtensor.get_stake_info_for_coldkey
        self.get_stake_movement_fee = meshtensor.get_stake_movement_fee
        self.get_transfer_fee = meshtensor.get_transfer_fee
        self.get_unstake_fee = meshtensor.get_unstake_fee
        self.set_children = meshtensor.set_children
        self.transfer = meshtensor.transfer
