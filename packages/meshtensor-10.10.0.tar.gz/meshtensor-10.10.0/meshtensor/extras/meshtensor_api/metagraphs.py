from typing import Union
from meshtensor.core.meshtensor import Meshtensor as _Meshtensor
from meshtensor.core.async_meshtensor import AsyncMeshtensor as _AsyncMeshtensor


class Metagraphs:
    """Class for managing metagraph operations."""

    def __init__(self, meshtensor: Union["_Meshtensor", "_AsyncMeshtensor"]):
        self.get_metagraph_info = meshtensor.get_metagraph_info
        self.get_all_metagraphs_info = meshtensor.get_all_metagraphs_info
        self.metagraph = meshtensor.metagraph
