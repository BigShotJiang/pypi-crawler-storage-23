from typing import Union

from meshtensor.core.async_meshtensor import AsyncMeshtensor as _AsyncMeshtensor
from meshtensor.core.meshtensor import Meshtensor as _Meshtensor


class MevShield:
    """Class for managing MEV Shield operations."""

    def __init__(self, meshtensor: Union["_Meshtensor", "_AsyncMeshtensor"]):
        # Storage queries
        self.get_mev_shield_current_key = meshtensor.get_mev_shield_current_key
        self.get_mev_shield_next_key = meshtensor.get_mev_shield_next_key
        self.get_mev_shield_submission = meshtensor.get_mev_shield_submission
        self.get_mev_shield_submissions = meshtensor.get_mev_shield_submissions

        # Extrinsics
        self.mev_submit_encrypted = meshtensor.mev_submit_encrypted
