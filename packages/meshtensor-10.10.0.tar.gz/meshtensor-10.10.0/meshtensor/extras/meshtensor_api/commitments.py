from typing import Union
from meshtensor.core.meshtensor import Meshtensor as _Meshtensor
from meshtensor.core.async_meshtensor import AsyncMeshtensor as _AsyncMeshtensor


class Commitments:
    """Class for managing any commitment operations."""

    def __init__(self, meshtensor: Union["_Meshtensor", "_AsyncMeshtensor"]):
        self.commit_reveal_enabled = meshtensor.commit_reveal_enabled
        self.get_all_commitments = meshtensor.get_all_commitments
        self.get_all_revealed_commitments = meshtensor.get_all_revealed_commitments
        self.get_commitment = meshtensor.get_commitment
        self.get_commitment_metadata = meshtensor.get_commitment_metadata
        self.get_last_bonds_reset = meshtensor.get_last_bonds_reset
        self.get_last_commitment_bonds_reset_block = (
            meshtensor.get_last_commitment_bonds_reset_block
        )
        self.get_revealed_commitment = meshtensor.get_revealed_commitment
        self.get_revealed_commitment_by_hotkey = (
            meshtensor.get_revealed_commitment_by_hotkey
        )
        self.get_timelocked_weight_commits = meshtensor.get_timelocked_weight_commits
        self.set_commitment = meshtensor.set_commitment
        self.set_reveal_commitment = meshtensor.set_reveal_commitment
