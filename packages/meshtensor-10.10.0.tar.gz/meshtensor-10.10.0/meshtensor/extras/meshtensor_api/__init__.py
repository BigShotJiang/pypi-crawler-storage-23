from typing import Optional, Union, TYPE_CHECKING

from meshtensor.core.async_meshtensor import AsyncMeshtensor as _AsyncMeshtensor
from meshtensor.core.meshtensor import Meshtensor as _Meshtensor
from .chain import Chain as _Chain
from .commitments import Commitments as _Commitments
from .crowdloans import Crowdloans as _Crowdloans
from .delegates import Delegates as _Delegates
from .extrinsics import Extrinsics as _Extrinsics
from .governance import Governance as _Governance
from .metagraphs import Metagraphs as _Metagraphs
from .mev_shield import MevShield as _MevShield
from .neurons import Neurons as _Neurons
from .proxy import Proxy as _Proxy
from .queries import Queries as _Queries
from .staking import Staking as _Staking
from .subnets import Subnets as _Subnets
from .utils import add_legacy_methods as _add_classic_fields
from .wallets import Wallets as _Wallets

if TYPE_CHECKING:
    from meshtensor.core.config import Config


class MeshtensorApi:
    """Meshtensor API class.

    Parameters:
        network: The network to connect to.
        config: Meshtensor configuration object.
        legacy_methods: If `True`, all methods from the Meshtensor class will be added to the root level of this class.
        fallback_endpoints: List of fallback endpoints to use if default or provided network is not available.
        retry_forever: Whether to retry forever on connection errors.
        log_verbose: Enables or disables verbose logging.
        mock: Whether this is a mock instance. Mainly just for use in testing.
        archive_endpoints: Similar to fallback_endpoints, but specifically only archive nodes. Will be used in cases
            where you are requesting a block that is too old for your current (presumably lite) node.
        websocket_shutdown_timer: Amount of time, in seconds, to wait after the last response from the chain to close
            the connection. Only applicable to AsyncMeshtensor. If `None` is passed to this, the automatic shutdown
            process is disabled.

    Example:
        # sync version
        import meshtensor as bt

        meshtensor = bt.MeshtensorApi()
        print(meshtensor.block)
        print(meshtensor.delegates.get_delegate_identities())
        meshtensor.chain.tx_rate_limit()

        # async version
        import meshtensor as bt

        meshtensor = bt.MeshtensorApi(async_meshtensor=True)
        async with meshtensor:
            print(await meshtensor.block)
            print(await meshtensor.delegates.get_delegate_identities())
            print(await meshtensor.chain.tx_rate_limit())

        # using `legacy_methods`
        import meshtensor as bt

        meshtensor = bt.MeshtensorApi(legacy_methods=True)
        print(meshtensor.bonds(0))

        # using `fallback_endpoints` or `retry_forever`
        import meshtensor as bt

        meshtensor = bt.MeshtensorApi(
            network="swarm",
            fallback_endpoints=["wss://localhost:9945", "wss://some-other-endpoint:9945"],
            retry_forever=True,
        )
        print(meshtensor.block)
    """

    def __init__(
        self,
        network: Optional[str] = None,
        config: Optional["Config"] = None,
        async_meshtensor: bool = False,
        legacy_methods: bool = False,
        fallback_endpoints: Optional[list[str]] = None,
        retry_forever: bool = False,
        log_verbose: bool = False,
        mock: bool = False,
        archive_endpoints: Optional[list[str]] = None,
        websocket_shutdown_timer: Optional[float] = 5.0,
    ):
        self.network = network
        self._fallback_endpoints = fallback_endpoints
        self._archive_endpoints = archive_endpoints
        self._retry_forever = retry_forever
        self._ws_shutdown_timer = websocket_shutdown_timer
        self._mock = mock
        self.log_verbose = log_verbose
        self.is_async = async_meshtensor
        self._config = config

        # assigned only for async instance
        self.initialize = None
        self.inner_meshtensor = self._get_meshtensor()

        # fix naming collision
        self._neurons = _Neurons(self.inner_meshtensor)

        # define empty fields
        self.substrate = self.inner_meshtensor.substrate
        self.chain_endpoint = self.inner_meshtensor.chain_endpoint
        self.close = self.inner_meshtensor.close
        self.config = self.inner_meshtensor.config
        self.setup_config = self.inner_meshtensor.setup_config
        self.help = self.inner_meshtensor.help

        self.determine_block_hash = self.inner_meshtensor.determine_block_hash
        self.compose_call = self.inner_meshtensor.compose_call
        self.sign_and_send_extrinsic = self.inner_meshtensor.sign_and_send_extrinsic
        self.start_call = self.inner_meshtensor.start_call
        self.wait_for_block = self.inner_meshtensor.wait_for_block

        # adds all Meshtensor methods into main level os MeshtensorApi class
        if legacy_methods:
            _add_classic_fields(self)

    def _get_meshtensor(self) -> Union["_Meshtensor", "_AsyncMeshtensor"]:
        """Returns the meshtensor instance based on the provided config and meshtensor type flag."""
        if self.is_async:
            _meshtensor = _AsyncMeshtensor(
                network=self.network,
                config=self._config,
                log_verbose=self.log_verbose,
                fallback_endpoints=self._fallback_endpoints,
                retry_forever=self._retry_forever,
                mock=self._mock,
                archive_endpoints=self._archive_endpoints,
                websocket_shutdown_timer=self._ws_shutdown_timer,
            )
            self.initialize = _meshtensor.initialize
            return _meshtensor
        else:
            return _Meshtensor(
                network=self.network,
                config=self._config,
                log_verbose=self.log_verbose,
                fallback_endpoints=self._fallback_endpoints,
                retry_forever=self._retry_forever,
                mock=self._mock,
                archive_endpoints=self._archive_endpoints,
            )

    def _determine_chain_endpoint(self) -> str:
        """Determines the connection and mock flag."""
        if self._mock:
            return "Mock"
        return self.substrate.url

    def __str__(self):
        return (
            f"<Network: {self.network}, "
            f"Chain: {self._determine_chain_endpoint()}, "
            f"{'Async version' if self.is_async else 'Sync version'}>"
        )

    def __repr__(self):
        return self.__str__()

    def __enter__(self):
        if self.is_async:
            raise NotImplementedError(
                "Async version of MeshtensorApi cannot be used with sync context manager."
            )
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.is_async:
            raise NotImplementedError(
                "Async version of MeshtensorApi cannot be used with sync context manager."
            )
        self.close()

    async def __aenter__(self):
        if not self.is_async:
            raise NotImplementedError(
                "Sync version of MeshtensorApi cannot be used with async context manager."
            )
        await self.inner_meshtensor.__aenter__()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if not self.is_async:
            raise NotImplementedError(
                "Sync version of MeshtensorApi cannot be used with async context manager."
            )
        await self.substrate.close()

    @classmethod
    def add_args(cls, parser):
        _Meshtensor.add_args(parser)

    @property
    def block(self):
        """Returns current chain block number."""
        return self.inner_meshtensor.block

    @property
    def chain(self):
        """Property of interaction with chain methods."""
        return _Chain(self.inner_meshtensor)

    @property
    def commitments(self):
        """Property to access commitments methods."""
        return _Commitments(self.inner_meshtensor)

    @property
    def crowdloans(self):
        """Property to access crowdloans methods."""
        return _Crowdloans(self.inner_meshtensor)

    @property
    def delegates(self):
        """Property to access delegates methods."""
        return _Delegates(self.inner_meshtensor)

    @property
    def extrinsics(self):
        """Property to access extrinsics methods."""
        return _Extrinsics(self.inner_meshtensor)

    @property
    def governance(self):
        """Property to access governance methods."""
        return _Governance(self.inner_meshtensor)

    @property
    def metagraphs(self):
        """Property to access metagraphs methods."""
        return _Metagraphs(self.inner_meshtensor)

    @property
    def mev_shield(self):
        """Property to access MEV Shield methods."""
        return _MevShield(self.inner_meshtensor)

    @property
    def neurons(self):
        """Property to access neurons methods."""
        return self._neurons

    @neurons.setter
    def neurons(self, value):
        """Setter for neurons property."""
        self._neurons = value

    @property
    def proxies(self):
        """Property to access meshtensor proxy methods."""
        return _Proxy(self.inner_meshtensor)

    @property
    def queries(self):
        """Property to access meshtensor queries methods."""
        return _Queries(self.inner_meshtensor)

    @property
    def staking(self):
        """Property to access staking methods."""
        return _Staking(self.inner_meshtensor)

    @property
    def subnets(self):
        """Property of interaction with subnets methods."""
        return _Subnets(self.inner_meshtensor)

    @property
    def wallets(self):
        """Property of interaction methods with cold/hotkeys, and balances, etc."""
        return _Wallets(self.inner_meshtensor)
