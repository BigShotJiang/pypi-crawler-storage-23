from typing import Union
from meshtensor.core.meshtensor import Meshtensor as _Meshtensor
from meshtensor.core.async_meshtensor import AsyncMeshtensor as _AsyncMeshtensor


class Extrinsics:
    """Class for managing extrinsic operations."""

    def __init__(self, meshtensor: Union["_Meshtensor", "_AsyncMeshtensor"]):
        self.add_liquidity = meshtensor.add_liquidity
        self.add_stake = meshtensor.add_stake
        self.add_stake_multiple = meshtensor.add_stake_multiple
        self.burned_register = meshtensor.burned_register
        self.claim_root = meshtensor.claim_root
        self.commit_weights = meshtensor.commit_weights
        self.contribute_crowdloan = meshtensor.contribute_crowdloan
        self.create_crowdloan = meshtensor.create_crowdloan
        self.dissolve_crowdloan = meshtensor.dissolve_crowdloan
        self.finalize_crowdloan = meshtensor.finalize_crowdloan
        self.get_extrinsic_fee = meshtensor.get_extrinsic_fee
        self.modify_liquidity = meshtensor.modify_liquidity
        self.move_stake = meshtensor.move_stake
        self.refund_crowdloan = meshtensor.refund_crowdloan
        self.register = meshtensor.register
        self.register_subnet = meshtensor.register_subnet
        self.remove_liquidity = meshtensor.remove_liquidity
        self.reveal_weights = meshtensor.reveal_weights
        self.root_register = meshtensor.root_register
        self.root_set_pending_childkey_cooldown = (
            meshtensor.root_set_pending_childkey_cooldown
        )
        self.set_children = meshtensor.set_children
        self.set_subnet_identity = meshtensor.set_subnet_identity
        self.set_weights = meshtensor.set_weights
        self.serve_axon = meshtensor.serve_axon
        self.set_commitment = meshtensor.set_commitment
        self.set_root_claim_type = meshtensor.set_root_claim_type
        self.start_call = meshtensor.start_call
        self.swap_stake = meshtensor.swap_stake
        self.toggle_user_liquidity = meshtensor.toggle_user_liquidity
        self.transfer = meshtensor.transfer
        self.transfer_stake = meshtensor.transfer_stake
        self.unstake = meshtensor.unstake
        self.unstake_all = meshtensor.unstake_all
        self.unstake_multiple = meshtensor.unstake_multiple
        self.update_cap_crowdloan = meshtensor.update_cap_crowdloan
        self.update_end_crowdloan = meshtensor.update_end_crowdloan
        self.update_min_contribution_crowdloan = (
            meshtensor.update_min_contribution_crowdloan
        )
        self.validate_extrinsic_params = meshtensor.validate_extrinsic_params
        self.withdraw_crowdloan = meshtensor.withdraw_crowdloan
