from typing import Union
from meshtensor.core.meshtensor import Meshtensor as _Meshtensor
from meshtensor.core.async_meshtensor import AsyncMeshtensor as _AsyncMeshtensor


class Governance:
    """Class for managing governance operations."""

    def __init__(self, meshtensor: Union["_Meshtensor", "_AsyncMeshtensor"]):
        # Extrinsics
        self.delegate_voting_power = meshtensor.delegate_voting_power
        self.undelegate_voting_power = meshtensor.undelegate_voting_power
        self.submit_referendum = meshtensor.submit_referendum
        self.vote_referendum = meshtensor.vote_referendum
        self.endorse_referendum = meshtensor.endorse_referendum
        self.cancel_referendum = meshtensor.cancel_referendum
        self.submit_treasury_proposal = meshtensor.submit_treasury_proposal
        self.approve_treasury_proposal = meshtensor.approve_treasury_proposal
        self.signal_golr = meshtensor.signal_golr
        self.update_contribution_scores = meshtensor.update_contribution_scores
        self.distribute_governance_rewards = meshtensor.distribute_governance_rewards
        # Queries
        self.get_voting_power = meshtensor.get_voting_power
        self.get_track_info = meshtensor.get_track_info
        self.get_referendum_info = meshtensor.get_referendum_info
        self.get_referendum_status = meshtensor.get_referendum_status
        self.get_treasury_balance = meshtensor.get_treasury_balance
        self.get_tc_members = meshtensor.get_tc_members
