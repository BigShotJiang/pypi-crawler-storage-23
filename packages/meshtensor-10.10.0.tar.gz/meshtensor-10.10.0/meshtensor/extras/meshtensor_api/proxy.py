from typing import Union
from meshtensor.core.meshtensor import Meshtensor as _Meshtensor
from meshtensor.core.async_meshtensor import AsyncMeshtensor as _AsyncMeshtensor


class Proxy:
    """Class for managing proxy operations on the Meshtensor network.

    This class provides access to all proxy-related operations, including creating and managing both standard and pure
    proxy relationships, handling proxy announcements, and querying proxy data. It works with both synchronous
    `Meshtensor` and asynchronous `AsyncMeshtensor` instances.

    Proxies enable secure delegation of account permissions by allowing a delegate account to perform certain operations
    on behalf of a real account, with restrictions defined by the proxy type and optional time-lock delays.

    Notes:
        - For comprehensive documentation on proxies, see: <https://docs.learnmeshtensor.org/keys/proxies>
        - For creating and managing proxies, see: <https://docs.learnmeshtensor.org/keys/proxies/create-proxy>
        - For pure proxy documentation, see: <https://docs.learnmeshtensor.org/keys/proxies/pure-proxies>
        - For available proxy types and their permissions, see: <https://docs.learnmeshtensor.org/keys/proxies#types-of-proxies>

    """

    def __init__(self, meshtensor: Union["_Meshtensor", "_AsyncMeshtensor"]):
        self.add_proxy = meshtensor.add_proxy
        self.announce_proxy = meshtensor.announce_proxy
        self.create_pure_proxy = meshtensor.create_pure_proxy
        self.get_proxies = meshtensor.get_proxies
        self.get_proxies_for_real_account = meshtensor.get_proxies_for_real_account
        self.get_proxy_announcement = meshtensor.get_proxy_announcement
        self.get_proxy_announcements = meshtensor.get_proxy_announcements
        self.get_proxy_constants = meshtensor.get_proxy_constants
        self.kill_pure_proxy = meshtensor.kill_pure_proxy
        self.poke_deposit = meshtensor.poke_deposit
        self.proxy_announced = meshtensor.proxy_announced
        self.proxy = meshtensor.proxy
        self.reject_proxy_announcement = meshtensor.reject_proxy_announcement
        self.remove_proxies = meshtensor.remove_proxies
        self.remove_proxy = meshtensor.remove_proxy
        self.remove_proxy_announcement = meshtensor.remove_proxy_announcement
