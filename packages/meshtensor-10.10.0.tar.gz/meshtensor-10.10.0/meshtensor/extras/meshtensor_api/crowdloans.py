from typing import Union
from meshtensor.core.meshtensor import Meshtensor as _Meshtensor
from meshtensor.core.async_meshtensor import AsyncMeshtensor as _AsyncMeshtensor


class Crowdloans:
    """Class for managing any Crowdloans operations."""

    def __init__(self, meshtensor: Union["_Meshtensor", "_AsyncMeshtensor"]):
        self.contribute_crowdloan = meshtensor.contribute_crowdloan
        self.create_crowdloan = meshtensor.create_crowdloan
        self.dissolve_crowdloan = meshtensor.dissolve_crowdloan
        self.finalize_crowdloan = meshtensor.finalize_crowdloan
        self.get_crowdloan_constants = meshtensor.get_crowdloan_constants
        self.get_crowdloan_contributions = meshtensor.get_crowdloan_contributions
        self.get_crowdloan_by_id = meshtensor.get_crowdloan_by_id
        self.get_crowdloan_next_id = meshtensor.get_crowdloan_next_id
        self.get_crowdloans = meshtensor.get_crowdloans
        self.refund_crowdloan = meshtensor.refund_crowdloan
        self.update_cap_crowdloan = meshtensor.update_cap_crowdloan
        self.update_end_crowdloan = meshtensor.update_end_crowdloan
        self.update_min_contribution_crowdloan = (
            meshtensor.update_min_contribution_crowdloan
        )
        self.withdraw_crowdloan = meshtensor.withdraw_crowdloan
