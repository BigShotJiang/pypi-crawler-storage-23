from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from meshtensor.extras import MeshtensorApi


def add_legacy_methods(meshtensor: "MeshtensorApi"):
    """If MeshtensorApi get `meshtensor_fields=True` arguments, then all classic Meshtensor fields added to root level."""
    # Attributes that should NOT be dynamically added (manually defined in MeshtensorApi.__init__)
    EXCLUDED_ATTRIBUTES = {
        # Internal attributes
        "inner_meshtensor",
        "initialize",
    }

    # Get all attributes from inner_meshtensor
    for attr_name in dir(meshtensor.inner_meshtensor):
        # Skip private attributes, special methods, and excluded attributes
        if attr_name.startswith("_") or attr_name in EXCLUDED_ATTRIBUTES:
            continue

        # Check if attribute already exists in meshtensor (this automatically excludes
        # all properties like block, chain, commitments, etc. and other defined attributes)
        if hasattr(meshtensor, attr_name):
            continue

        # Get the attribute from inner_meshtensor and add it
        try:
            attr_value = getattr(meshtensor.inner_meshtensor, attr_name)
            setattr(meshtensor, attr_name, attr_value)
        except (AttributeError, TypeError):
            # Skip if attribute cannot be accessed or set
            continue
