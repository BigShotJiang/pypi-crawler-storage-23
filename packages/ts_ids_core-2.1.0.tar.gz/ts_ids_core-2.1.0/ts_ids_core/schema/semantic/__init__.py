from ts_ids_core.schema.semantic.concept import Concept

__all__ = ["Concept"]
