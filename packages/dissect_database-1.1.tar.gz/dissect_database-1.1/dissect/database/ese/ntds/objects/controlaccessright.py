from __future__ import annotations

from dissect.database.ese.ntds.objects.top import Top


class ControlAccessRight(Top):
    """Represents a control access right object in the Active Directory.

    References:
        - https://learn.microsoft.com/en-us/windows/win32/adschema/c-controlaccessright
    """

    __object_class__ = "controlAccessRight"
