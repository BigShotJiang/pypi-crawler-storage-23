#Lab Master

An asyncronous server/client arch  written in python.



##Install

```
sudo apt install pkg-config libsystemd-dev





