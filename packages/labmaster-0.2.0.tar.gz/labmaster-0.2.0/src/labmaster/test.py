import os


path=os.path.dirname(os.path.realpath(__file__))

path,target=os.path.split(path)
path,target=os.path.split(path)
print(os.path.join(path,'conf'))