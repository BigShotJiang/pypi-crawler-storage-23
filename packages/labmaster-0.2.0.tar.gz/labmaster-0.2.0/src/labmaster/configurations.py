import os
import configparser
from labmaster.datasource.data_models import *

class genConfig:
    def __init__(self): 
        if os.path.exists("/opt/labs_manager/config.ini"):
            base_path="/opt/labs_manager"
        else:
            base_path,_=os.path.split(os.path.dirname(os.path.realpath(__file__)))
            base_path,_=os.path.split(base_path)
            base_path=os.path.join(base_path,'conf')
            #base_path=os.path.dirname(os.path.realpath(__file__))+"/conf/"
            
        config = configparser.ConfigParser()
        
        config.read(base_path+"/config.ini")
        self.DB_TYPE=config['database']['db_type']
        self.DB_PATH=config['database']['db_path']
        self.DB_NAME=config['database']['db_name']
        self.DB_USER=config['database']['db_user']
        self.DB_PWD=config['database']['db_pwd']
        self.DB_PORT=int(config['database']['db_port'])
        self.DB_HOST=config['database']['db_host']
        self.DB_TABLES=[grade,laboratory,user,microcomputer,userSession,classroom,group,usergroup,role]
        self.NO_SESSION_LOG=config['log']['no_session_log'].split(',')
        self.WATCH_GROUPS=config['log']['watch_groups'].split(',')
        self.DEFAULT_GRADE=config['log']['default_grade'].split(',')
        self.KEY=config['server'] ['key']
        self.SERVER_ADDRESS=config['server'] ['address']
        self.SERVER_PORT=int(config['server'] ['port'])
        self.LOG_DIR=config['log'] ['log_dir']
        self.LOG_LEVEL={'global_level':config['log'] ['global_level'],
                        'console_level':config['log'] ['console_level'],
                        'file_level':config['log'] ['file_level'] }

        
        
        
        
        
     

