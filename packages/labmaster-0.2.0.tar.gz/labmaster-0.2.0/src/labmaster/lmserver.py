
import asyncio
import argparse
from labmaster.server.asyncservers import Server
from labmaster.configurations import genConfig



config=genConfig()


parser = argparse.ArgumentParser(description="labs client",
                                 formatter_class=argparse.ArgumentDefaultsHelpFormatter)

parser.add_argument('--statistics', action='store_true', help="enable statistics")
parser.add_argument('--no-statistics', dest='statistics', action='store_false',help="disable statistics")
parser.set_defaults(statistics=False)

args = parser.parse_args()

arguments = vars(args)

def main_server():

    server = Server(config,enable_statistic=arguments['statistics'])
    try:
        asyncio.run(server.start_server())
    except KeyboardInterrupt:
        print("Keyboard Interrupt Detected. Shutting down!")
    except asyncio.exceptions.CancelledError:
        print("Loop cancelled! Shutting down!") 

if __name__ == "__main__":
    main_server()