import uuid
import argparse
import datetime
import logging
from rich import print
from labmaster.clients.cli_helpers import clientLogs


logger = logging.getLogger(__name__)




console_handler = logging.StreamHandler()
file_handler = logging.FileHandler(f"/tmp/labs_cli{str(uuid.uuid4()).replace('-', '')[:16]}.log", mode="a", encoding="utf-8")

logger.addHandler(console_handler)
logger.addHandler(file_handler)
logger.setLevel(logging.INFO)

parser = argparse.ArgumentParser(description="labs console",
                                 formatter_class=argparse.ArgumentDefaultsHelpFormatter)
parser.add_argument("-g", "--groups", type=str, help="archive mode")
parser.add_argument("-u","--username", type=str,help="username")
parser.add_argument("-t","--type", type=str,help="pam type")
parser.add_argument("-c","--hostname", type=str,help="hostname")
parser.add_argument("-a","--action", type=str,help="action")
parser.add_argument("command", help="command to execute")
args = parser.parse_args()
arguments = vars(args)


client_session_dump=clientLogs(logger)

match arguments['command']:
    case 'store':
        logger.info(f"{arguments['username']}  {arguments['type']} {arguments['groups']} {arguments['hostname']} ")
        data={'username':arguments['username'],'type':arguments['type'],'groups':arguments['groups'],'hostname':arguments['hostname'],'action':arguments['action']}  
        client_session_dump.logUserSession(data)
        pass
    case 'logins':
        logins=client_session_dump.get_user_sessions(arguments['username'])
        for login in logins:
            print(f"[bold green]computer:[/bold green] {login['computer']} [bold green]date:[/bold green] [white]{login['date']}[/white] [bold yellow]shell:[/bold yellow] {login['shell']}")