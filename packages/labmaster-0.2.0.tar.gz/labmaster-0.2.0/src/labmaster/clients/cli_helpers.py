import re
import logging
from datetime import datetime
from labmaster.datasource.datastore import DataStore
from labmaster.configurations import genConfig


class clientLogs():
    def __init__(self,system_logger):
        config=genConfig()
        self.parameters=config
        self.db_store=DataStore()
        self.log:logging=system_logger
    
       
    def _get_role_grade(self,groups):
        results={}
     
        for filter in self.parameters.WATCH_GROUPS:
            for group in groups:
                data=re.match(rf"{filter}",group)
                if data:
                    grade=data.group(1) if len(data.groups(1))>0 else filter
                    match grade:
                        case 'docenti':
                            results['teacher']=self.parameters.DEFAULT_GRADE[0]
                        case 'studenti':
                            results['student']=data.group(2)
                            
                    self.log.info(f"Regex {filter} match {grade}")
                
                    
                if len(results)==0:
                    results['ata']=self.parameters.DEFAULT_GRADE[1]
            
        role_grade=()
    
        if 'teacher' in results:
            role_grade=('teacher',results['teacher'])
        elif 'student' in results:
            role_grade=('student',results['student'])
        elif 'ata' in results:
            role_grade=('ata',results['ata'])
                 
                
        return role_grade
    
    
    def get_user_sessions(self,username):
        user=self.db_store.get_user(username)
        if not user:
            self.log.info(f"{username} not a user")
            return []
        sessions=[]
        for session in user.sessions:
            if session.action=="open_session":
                sessions.append({'computer':session.computer.hostname,'date':session.time,'shell':session.shell})
        return sessions
    
    
        
    def logUserSession(self,system_data):
        
        username=system_data['username']
        hostname=system_data['hostname']
        
        if username in self.parameters.NO_SESSION_LOG:
            self.log.info(f"{username} is not in log list")
            return None
        
        pc_console=self.db_store.get_computer_by_hostname(hostname)
        if not pc_console:
            self.log.error(f"Computer is not registered!")
            return None
                
        groups=system_data['groups'].split('_')
        role_grade=self._get_role_grade(groups)
        self.log.info(f"Group data {role_grade}")
        
        user=self.db_store.get_user(username)
        if not user:
            grade=self.db_store.get_grade(role_grade[1])
            if not grade:
                grade=self.db_store.add_grade(role_grade[1])
                self.log.info(f"{role_grade[1]} grade added")    
            
            role=self.db_store.get_role(role_grade[0])
            if not role:
                role=self.db_store.add_role(role_grade[0])
                self.log.info(f"{role_grade[0]} role added")
                
            user=self.db_store.add_user(username,role,grade)
            self.log.info(f"{username} user added")
        action=system_data['action']
        type=system_data['type']
        session=self.db_store.add_user_session(user,pc_console,action,type)
  
        
        
             
            
        
        
                
        
        
        
        
        
        
        
        
        
       

        