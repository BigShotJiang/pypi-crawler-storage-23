import time
import asyncio
from types import NoneType
from labmaster.protocol.com_protocol import ComProtocol,Message
from labmaster.protocol.net_exceptions import MalformedMessageError
from labmaster.clients.client_actions import ClientActions
from labmaster.protocol.enumerators import ClientCommands,ServerCommands,MessageSchema


class Client2:
    def __init__(self, reader: asyncio.StreamReader| None, writer: asyncio.StreamWriter | None,*,client_logger):
        self.__reader: asyncio.StreamReader| None = reader
        self.__writer: asyncio.StreamWriter| None = writer
        
        self.__logger=client_logger
        self.__client_type='worker'
        
        self.__ip: str = '127.0.0.1' if reader is None or writer is None else writer.get_extra_info('peername')[0]
        self.__port: int = 50000 if reader is None or writer is None else writer.get_extra_info('peername')[1]
        self.protocol=ComProtocol(logger=self.logger)
        self.__connected=False
        self.__latency=0.0
        self.__actions=ClientActions(client=self)
        self.__sent=0
        self.__received=0
    
    @property
    def sent(self):
        return self.__sent
    
    @property
    def received(self):
        return self.__received
    
    @received.setter
    def received(self,received:int):
        self.__received=received
        
    
    @property
    def actions(self):
        return self.__actions
    
    @property
    def logger(self):
        return self.__logger
        
    @property
    def client_type(self):
        return self.__client_type
    
    @client_type.setter
    def client_type(self,client_type:str):
        self.__client_type=client_type

    @property
    def latency(self):
        return self.__latency
    
    @latency.setter
    def latency(self,latency:float):
        self.__latency=latency
    
    def __str__(self):
        return f" {self.ip}:{self.port}"


    @property
    def connected(self):
        return self.__connected


    @connected.setter
    def connected(self,connected:bool):
        self.__connected=connected


    @property
    def reader(self):
        return self.__reader


    @reader.setter
    def reader(self,reader:asyncio.StreamReader ):
        self.__reader=reader

    @property
    def writer(self):
        return self.__writer



    @writer.setter
    def writer(self, writer:asyncio.StreamWriter):
        self.__writer=writer

    @property
    def ip(self):
        return self.__ip

    @property
    def port(self):
        return self.__port

    async def send_message(self,message:dict):
            
        try:    
            new_message=Message()
            new_message.load_command_payload(message)
            self.__sent+=1
        except MalformedMessageError as e:
            self.logger.debug(e)
            return False
        except NotImplementedError as e:
            self.logger.debug(e)
            return False
        
        try:
             await self.protocol.send_message(self.writer,new_message)
             return True
        except BrokenPipeError:
             self.logger.debug("Broken Pipe!")
             return False   
        except Exception as e:
             self.logger.debug(f"Get message unknown error type  {e}")
             return False
        except KeyboardInterrupt:
             self.logger.warning("Keyboard Interrupt Detected. Shutting down!")
             return False
        
        
    async def get_message(self)->Message|bool:
        try:
           self.__received+=1
           return  await self.protocol.read_message(self.reader)
           
        except asyncio.exceptions.IncompleteReadError as e:
            self.logger.error(f"Incomplete read")
            return False
        except BrokenPipeError:
            self.logger.debug("Broken Pipe!")
            return False
        except Exception as e:
            self.logger.debug(f"Get message unknown error type  {e}")
            return False
        except KeyboardInterrupt:
             self.logger.warning("Keyboard Interrupt Detected. Shutting down!")
             return False
        except asyncio.exceptions.CancelledError as e:
             self.logger.debug("Message lost! Bye bye!")
             return False 
        except MalformedMessageError as e:
             self.logger.debug(e)
             return False

         
    async def get_message_in_time(self,timeout)->Message|bool:
        try:
            return await asyncio.wait_for(self.get_message(), timeout=timeout)
        except asyncio.TimeoutError:
            return False
    
    async def pong(self):
        return await self.__actions.execute(ClientCommands.PONG)
            
    async def ping(self):
        return await self.__actions.execute(ClientCommands.PING)
        
    async def quit(self):
         return await self.__actions.execute(ClientCommands.QUIT)
     
        
     
    async def display(self,message):
        return await self.__actions.execute(ClientCommands.DISPLAY,data=message)
    
        
        
    
                                                                   

            
            
            

