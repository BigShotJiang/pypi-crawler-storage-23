import asyncio
import time
from prompt_toolkit import PromptSession
from prompt_toolkit.patch_stdout import patch_stdout
from prompt_toolkit import print_formatted_text
from prompt_toolkit.formatted_text import FormattedText,HTML
from labmaster.clients.asyncclients import Client2
from labmaster.protocol.com_protocol import Message
from labmaster.clients.cli_tools import CommandsValidator,CommandsCliFormatter,CommandsCompleter2
from labmaster.protocol.enumerators import ClientRole,ClientCommands,ServerCommands
from labmaster.protocol.net_exceptions import AbnormalCommand,DuplicatedTask





class LabClient2(Client2):
    def __init__(self, server_ip: str, server_port: int,*,client_logger,enable_cli=False):
        super().__init__(None,None,client_logger=client_logger)
        self.__server_ip: str = server_ip
        self.__server_port: int = server_port
        self.__active=True
        self.__retry_limit=10
        self.__reconnect=True
        self.cli : PromptSession = PromptSession()
        self.__enable_cli=enable_cli
        self.handshake=False
        self.keep_alive_message=None
        self.subscription=None
        self.__active_tasks: dict={}
              
    @property
    def enable_cli(self)->bool:
        return self.__enable_cli
   
    @enable_cli.setter
    def enable_cli(self,enable_cli:bool):
        self.__enable_cli=enable_cli
    
    @property   
    def active_tasks(self):
        return self.__active_tasks
          
    @property
    def server_ip(self):
            return self.__server_ip

    @property
    def server_port(self):
        return self.__server_port

    @property
    def active(self):
        return self.__active
    
    @active.setter
    def active(self,active):
        self.__active=active
    
    @active.setter
    def active(self,active:bool):
        self.__active=active
    
    
    async def add_task(self,task_name,task):
        if not task_name in self.__active_tasks:
            self.__active_tasks[task_name]=task     
        else:
            raise DuplicatedTask(f"Task {task_name} already exists")
    
        
    async def remove_task(self,task_name):
        if task_name in self.active_tasks:
            self.__active_tasks[task_name].cancel()
            del self.active_tasks[task_name]
            return True
        return False


            
    async def start_client(self):
          
             while self.active:
                 self.logger.debug(f"Current tasks number: {len(asyncio.all_tasks())}")
                 self.client_type=ClientRole.MONITOR if self.enable_cli else ClientRole.WORKER
                 
                 connection=await self.connect_to_server()
                 self.logger.debug(f"Active connection: {self.active}")
                 
                 if not connection:
                     await asyncio.sleep(2)
                     continue
                    
                 try:
                    self.subscription=asyncio.create_task(self.receive_messages())
                    self.keep_alive_message=asyncio.create_task(self.keep_alive())
                    
                    if self.enable_cli:
                        await self.start_client_cli()
                    else:
                        await self.start_client_loop()
    
                 except asyncio.exceptions.CancelledError as e:
                    self.logger.info("Message lost! Bye bye!")
                 except KeyboardInterrupt as e:
                    self.logger.info(f"Keyboard interrupt: {e}" )
                 except Exception as e:
                    self.logger.debug(f"An error has occurred: {e} ")
                 
                 
                 
             self.logger.info("Shutting down")
     
    async def connect_to_server(self):
        
        for attempt in range(self.__retry_limit):
            try:
                self.reader, self.writer = await asyncio.open_connection(self.server_ip, self.server_port)
                break
            except Exception as e:
                self.logger.info(f"Connection attempt {attempt+1}/{self.__retry_limit} failed: {e}" )
                if attempt < self.__retry_limit - 1 and self.__reconnect:
                    await asyncio.sleep(2 ** attempt) 
                    self.logger.info(f"Retrying in {2 ** attempt} seconds...")
                else:
                    return  False  
             
        
        if await self.actions.execute(ClientCommands.HANDSHAKE):
            self.logger.info("Handshake successful")
            self.connected=True
            return True
        else:
            self.logger.info("Handshake failed")
            return False
            
    def _pretty_printer(self,header,message):
        formatted_message=FormattedText([
                                ('#ff0066', header),
                                ('', ' '),
                                ('#44ff00 italic', str(message))
                            ])
        print_formatted_text(formatted_message)
      
    async def receive_messages(self):
        server_message: str = ''
        while self.connected:
            server_message = await self.get_message()
            if not server_message: break
            
            match server_message.command:
                case ClientCommands.QUIT:
                       self.active=False
                       self.connected=False
                       if self.enable_cli and self.cli is not None and self.cli.app.is_running:
                            self.cli.app.exit()
                       break
                case ClientCommands.PONG:               
                    self.latency=time.monotonic()-float(server_message.data)
                    continue
                case ClientCommands.DISPLAY:
                    self._pretty_printer("server said",str(server_message.data))
                    continue
                case _:
                    self.logger.debug(f"Received message: {server_message.command}")
                    await self.actions.execute(server_message.command,
                                               type='e',
                                               message=server_message)
            
            
                                        
    async def keep_alive(self):
        while self.connected:
            await asyncio.sleep(3)
            if self.handshake:
                status=await self.ping()
                if not status:
                    self.logger.info(f"Server not responding. Disconnecting. ")
                    self.connected=False
                    if self.enable_cli and self.cli is not None and self.cli.app.is_running: 
                        self.cli.app.exit()
                        
                    self.subscription.cancel()
                    
    async def start_client_loop(self):
        while self.connected:
            await asyncio.sleep(1)
            
    async def start_client_cli(self):
        user_command: str = None
        
        formatter=CommandsCliFormatter(self.logger)
        
        
        def bottom_toolbar():
            return HTML(f"Client type <b><style bg=\"ansired\">{self.client_type}</style></b>") 
        
        
        
        while user_command != 'quit' and self.connected:
            with patch_stdout():
                try:
                    
                    user_command = await self.cli.prompt_async(f"cli admin@{self.server_ip}$: ",
                                                               bottom_toolbar=bottom_toolbar,
                                                               completer=CommandsCompleter2(self.logger),
                                                               validator=CommandsValidator(),
                                                               )
                    if user_command is None or len(user_command)==0: continue
                    
                    parsed_command=None

                    try:
                        parsed_command=formatter.compile_command(user_command)
                    except AbnormalCommand as e:
                       self.logger.debug(e)
                       continue
                    except NotImplementedError as e:
                        self.logger.debug(e)
                        continue
                    except TypeError as e:
                        self.logger.debug(f"Unknown error: {e} {parsed_command} ")
                    
                    if not parsed_command: continue
                         
                except asyncio.exceptions.CancelledError as e:
                    self.logger.debug(f"Console disabled ")
                    self.connected=False
                except KeyboardInterrupt as e:
                    self.logger.debug(f"Console interrupted by keyboard: {e}" )
                    user_command = Message(command='quit')                   
                    self.active=False
                    self.connected=False
                    break
                except Exception as e:
                    self.logger.debug(f"Command error: {e} {user_command} ")

                    
                if parsed_command['command'][0]=='@':
                    local_command=parsed_command['command'][1:]
                    match local_command:
                            case 'latency':
                                self._pretty_printer('local',f"latency: {self.latency}s")
                                    
                else:
                    match parsed_command['command']:
                        case 'quit':
                            self.active=False
                            self.connected=False
                            if self.cli is not None and self.cli.app.is_running: 
                              self.cli.app.exit()
                            break   
                        case 'empty':
                            continue
                    self.logger.debug(parsed_command)                 
                    if not await self.send_message(parsed_command):
                        self.logger.debug(f"Message not sent!")
                        #self.connected=False
                                