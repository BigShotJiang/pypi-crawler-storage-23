import re
import copy
from prompt_toolkit.validation import Validator, ValidationError
from labmaster.protocol.enumerators import ServerCommands,ServerSubcommands,ClientCommands,MessageSchema
from labmaster.protocol.net_exceptions import AbnormalCommand
from labmaster.protocol.commands_description import AvailableServerCommands,AvailableClientCommands,AvailableArguments
from prompt_toolkit.completion import WordCompleter,Completer




ip_pattern = re.compile(r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})')

commands_structure=AvailableClientCommands.structures()|AvailableServerCommands.structures()

arguments_structure=AvailableArguments.structures()

class CommandsCompleter2(Completer):
    def __init__(self, logger,ignore_case: bool = True) -> None:

        self.ignore_case = ignore_case
        self.logger=logger
        self.options =AvailableServerCommands.descriptions()|AvailableClientCommands.descriptions()
   
    def __repr__(self) -> str:
        return f"CommandsCompleter({self.options!r}, ignore_case={self.ignore_case!r})"
  
    
    def _get_value(self,element):
        if dict_value:=self.options.get(element):
            return dict_value
        else:
            for k in self.options.keys():
                if dict_value:=self.options.get(k).get(element):
                    return dict_value
        return None
    
    
    def get_completer(self,prompt_elements):
        working_element=None
        current=prompt_elements[-1]
        working_element=self._get_value(current)
       
       
        if working_element is None:
           for element in prompt_elements[::-1]:
               temp_element=self._get_value(element)
               if not temp_element is None and temp_element['completer_type']=='value':
                  working_element=temp_element
                  break 
        if not working_element: return ('','',None)  
          
        match working_element['completer_type']:
            case 'value':
                if working_element['regexp'].match(current):
                    return ('next',working_element['next'],self._get_value(working_element['next'][0]))
                else:
                    return (working_element['completer_type'],working_element['next'][0],working_element)
            case 'next':
                return (working_element['completer_type'],working_element['next'],self._get_value(working_element['next'][0]))
            case 'regexp':
                return ('next',working_element['next'],self._get_value(working_element['next'][0]))
    
        return ('','',None) 
            
    def get_completions(self,document, complete_event):
               
            
        text = document.text_before_cursor.lstrip()
        if " " in text:
            prompt_elements=' '.join(text.split())
            prompt_elements=prompt_elements.split(' ')
            completer_type,next_name,next_completer=self.get_completer(prompt_elements)
            
            if  completer_type=='next' and not next_name[0]: return
            
            match completer_type: 
                case 'next':
                    completer = WordCompleter(
                        next_name, ignore_case=True
                 )
                case 'value':
                    completer = WordCompleter(
                        list(next_completer['value']), ignore_case=True
                 )
                case _:
                    return
            yield from completer.get_completions(document, complete_event)
        else:
            completer = WordCompleter(
                list(self.options.keys()), ignore_case=True
            )
            yield from completer.get_completions(document, complete_event)
    

class CommandsCliFormatter:
    def __init__(self,logger):
        self.logger=logger 
         
    def _compile_argument(self,argument):
        argument=' '.join(argument.split())
        argument_elements=argument.split(' ')  

        argument_structure=arguments_structure.get(argument_elements[0])
        
        if not argument_structure:
            return argument
        
        new_argument={}
        for i in range(len(argument_elements)//2):
            new_argument[argument_structure[i*2][2]]=argument_elements[i*2+1]
        
        return new_argument
                

    
    def compile_command(self,command):
        command=' '.join(command.split())
        command_elements=command.split(' ')       
                    
        
        if command_elements[0] not in commands_structure:
            raise NotImplementedError(f"Command {command_elements[0]} not implemented yet")
        
        command_message={}
        
        structure=copy.copy(commands_structure[command_elements[0]])
        
        
        if ServerSubcommands.EXECUTE.value in command_elements and command_elements[-1]!=ServerSubcommands.EXECUTE.value:
            request_command=command_elements[command_elements.index(ServerSubcommands.EXECUTE.value)+1]
            struct=commands_structure.get(request_command)
            if struct:    
                structure.pop()
                structure=structure+struct
        
        
        if len(command_elements)!=len(structure):
            raise AbnormalCommand("Not enough command elements") 
        
        while command_elements:
            cm=command_elements.pop(0)
            cs=structure.pop(0)
           
            if not cs[3] in MessageSchema.structure():
                command_message[cs[3].value]=cm
            elif cs[3]==MessageSchema.NESTED_COMMAND:
                subcommand=' '.join(command_elements)
                command_elements=[]
                command_message[MessageSchema.DATA.value]=self.compile_command(subcommand)
            elif cs[3]==MessageSchema.ARGUMENTS_ELEMENT:
                command_message[MessageSchema.ARGUMENTS.value]+=f" {cm}"
                command_message[MessageSchema.ARGUMENTS.value].strip()
        
        if MessageSchema.ARGUMENTS in command_message:
               command_message[MessageSchema.ARGUMENTS.value]=self._compile_argument(command_message[MessageSchema.ARGUMENTS.value])
            

        return command_message
        



class CommandsValidator(Validator):
    ip_pattern = re.compile(r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})')

    def validate(self, document):
        text = document.text

        if text:
            
            prompt_elements=' '.join(text.split())
            prompt_elements=prompt_elements.split(' ')
            
            if prompt_elements[0] not in ClientCommands.list() and prompt_elements[0] not in ServerCommands.list():
                raise ValidationError(
                message="Command not defined",
                cursor_position=text.index(prompt_elements[0])
            ) 
             
            match prompt_elements[0]:
                case 'request':
                    self._validate_request(prompt_elements,text)
            
    
    def _validate_request(self,elements,text):
            
        structure=copy.copy(commands_structure[ServerCommands.REQUEST])
        
        
        if ServerSubcommands.EXECUTE.value in elements and elements[-1]!=ServerSubcommands.EXECUTE.value:
            request_command=elements[elements.index(ServerSubcommands.EXECUTE.value)+1]
            struct=commands_structure.get(request_command)
            if struct:    
                structure.pop()
                structure=structure+struct
        
        if len(elements)>len(structure):
              
              raise ValidationError(
                message="Empty command",
                cursor_position=0 )
                
        for i,m in enumerate(elements):
            if not structure[i%len(structure)][0].match(m):
                raise ValidationError(
                message=structure[i%len(structure)][1],
                cursor_position=text.index(m)
            ) 
        if len(elements)<len(structure):
            raise ValidationError(
                message=structure[len(elements)-1][2],
                cursor_position=text.index(elements[-1])
            
            )
        
        