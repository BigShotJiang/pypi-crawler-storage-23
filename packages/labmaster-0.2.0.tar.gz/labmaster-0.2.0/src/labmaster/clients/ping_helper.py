import subprocess  

def ping(host):
  
    param = '-c'
    command = ['ping', param, '1', host]

    return subprocess.call(command) == 0