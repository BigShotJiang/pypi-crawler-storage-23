
import os
import re
import time
import pwd
from systemd import login  # type: ignore
import asyncio
from watchfiles import awatch # type: ignore
from aiopsutil import AsyncPSUtil # type: ignore
from labmaster.protocol.enumerators import ClientCommands,MessageSchema,ServerCommands
from labmaster.protocol.net_exceptions import DuplicatedTask
from labmaster.protocol.enumerators import ClientCommands,MessageSchema





class ClientActions:
    def __init__(self,*,client):
        self.__client=client
        self.__logger=client.logger
    
    
    
    def _parse_message_data(self,message_data):
       answer_for=re.compile(r'(answer_to):(\d+)')
       
       transformer={'answer_to':'answer_for'}
       
       if match:=answer_for.search(message_data):
           return f"{transformer[match.group(1)]}:{match.group(2)}"
          
       return ''
    
    def _client_watch_cleanup_callback(self,context: asyncio.Task):
        asyncio.create_task(self.__client.remove_task(context.get_name()))
        
    async def _get_users(self,verbose=False):
        users=[]
        for uid in login.uids():
            users.append(pwd.getpwuid(uid))
        return users    
  
  
    async def _watch_process(self,target,watch_for):
        halt=False
        aps = AsyncPSUtil()
        self.__logger.debug(f" Watching {target} process")
        while not halt:
           async for proc in aps.process_iter():
             if await proc.name()==target:
                    await self.__client.send_message({MessageSchema.COMMAND:ServerCommands.FORWARD_REQUEST,
                                                      MessageSchema.DATA:f"{target} detected",
                                                      MessageSchema.ANSWER_FOR:watch_for})
                    break
           await asyncio.sleep(5) 
    
    async def _watch_file(self,target,watch_for):
        max_attempts=50
        halt=False
        while not halt:       
            #check if target exists
            while max_attempts>0:
                halt=True
                if os.path.exists(target):
                    max_attempts=0
                    halt=False
                await asyncio.sleep(4)
                if  halt:
                    self.__logger.debug(f" Target not found, waiting... {max_attempts} attempts left")
                max_attempts-=1               
            if not halt:
                self.__logger.debug(f" Watching {target}")
                async for changes in awatch(target):
                    data={'added':[],'modified':[],'deleted':[]}
                    for element in changes:
                        match element[0]:
                         case 1:
                            data['added'].append({'path':element[1],'time':time.monotonic()})
                            
                         case 2:
                             data['modified'].append({'path':element[1],'time':time.monotonic()})
                         
                         case 3:
                             data['deleted'].append({'path':element[1],'time':time.monotonic()})
                      
                    
                    
                    await self.__client.send_message({MessageSchema.COMMAND:ServerCommands.FORWARD_REQUEST,
                                                      MessageSchema.DATA:data,
                                                      MessageSchema.ANSWER_FOR:watch_for})
            else:
                self.__logger.debug(f" Target {target} not found after {max_attempts} attempts giving up")
     
    async def e_watch(self,**kwargs):
         message=kwargs['message']
         arguments=message.arguments
         
         targets=re.match(r"(\[filesystem\]|\[process\])",arguments['target'])
         
         target_type=targets.group(1)
         
         target_element=arguments['target'].replace(target_type,'')
        
         
         match arguments['action']:
             case 'start': 
                if target_element in self.__client.active_tasks:
                    self.__logger.debug(f" Already watching {target_element}")
                else:
                    self.__logger.debug(f" Watching {target_element}")         
                    
                    match target_type:
                        case '[process]':
                            task = asyncio.create_task(self._watch_process(target_element,message.answer_to),name=target_element)                            
                        case '[filesystem]':
                            task = asyncio.create_task(self._watch_file(target_element,message.answer_to),name=target_element)
                    
                    task.add_done_callback(self._client_watch_cleanup_callback)
                    try:
                        await self.__client.add_task(target_element,task)
                    except DuplicatedTask as e:
                        self.__logger.debug(e)
             case 'stop':
                if target_element in self.__client.active_tasks:
                    self.__logger.debug(f" Stop watching {target_element}")
                    await self.__client.remove_task(target_element)
                else:
                    self.__logger.debug(f" Not watching {target_element}")
                
    async def c_watch(self,**kwargs):
        message=kwargs['message']
        return  await self.__client.send_message({MessageSchema.COMMAND:ClientCommands.WATCH,
                                                 MessageSchema.ARGUMENTS:message.arguments,
                                                 MessageSchema.ANSWER_TO:message.answer_to})
                
    async def c_who(self,**kwargs):
        """
        Docstring for c_who
        Request who action, from server or client
        
        
        :param self: 
        :param kwargs: 
        """
        message=kwargs['message']
        
        return await self.__client.send_message({MessageSchema.COMMAND:ClientCommands.WHO,
                                                 MessageSchema.DATA:message.data,
                                                 MessageSchema.ANSWER_TO:message.answer_to})      
         
         
    async def e_who(self,**kwargs):
        """
        Docstring e e_who
        Execute who action on client
        
        :param self: Descrizione
        :param kwargs: Descrizione
        """
        message=kwargs['message']
        users=await self._get_users()
        data=f"{users}"
        self.__logger.debug(f" send answer to client {message.answer_to}")
               
        await self.__client.send_message({MessageSchema.COMMAND:ServerCommands.FORWARD_REQUEST,
                                                MessageSchema.DATA:data,
                                                MessageSchema.ANSWER_FOR:message.answer_to})
    
    async def c_quit(self,**kwargs):
        """
        Docstring per c_quit
        Send command quit to client 
        :param self: Descrizione
        :param kwargs: Descrizione
        """
        
        
        return await self.__client.send_message({MessageSchema.COMMAND:ClientCommands.QUIT,
                                                  MessageSchema.DATA:time.monotonic()})

    async def c_ping(self,**kwargs):
        return await self.__client.send_message({MessageSchema.COMMAND:ClientCommands.PING,
                                        MessageSchema.DATA:time.monotonic()})
    
    async def c_pong(self,**kwargs):
        return await self.__client.send_message({MessageSchema.COMMAND:ClientCommands.PONG,
                                        MessageSchema.DATA:time.monotonic()})
        
    async def c_display(self,**kwargs):
    
        message=kwargs['message'].data
    
        return await self.__client.send_message({MessageSchema.COMMAND:ClientCommands.DISPLAY,
                                                 MessageSchema.DATA:message}) 
    
    async def c_handshake(self,**kwargs):
        server_message = await self.__client.get_message_in_time(6)
        
        if not server_message: return False
            
        self.__logger.debug(f"Handshake Server message: {server_message.data}")
        
        if server_message.data==MessageSchema.HANDSHAKE_SERVER_CHALLENGE:
            self.__logger.debug(f"Handshake client response: {MessageSchema.HANDSHAKE_CLIENT_RESPONSE}")
            await self.__client.send_message( {MessageSchema.COMMAND:ClientCommands.HANDSHAKE,
                                               MessageSchema.ARGUMENTS:self.__client.client_type,
                                               MessageSchema.DATA:MessageSchema.HANDSHAKE_CLIENT_RESPONSE})
        else:
            return False                                       
                           
        server_message = await self.__client.get_message_in_time(5)
        if not server_message: return False
           
        self.__logger.debug(f"Handshake server response: {server_message.data}")
            
        if  server_message.data==MessageSchema.HANDSHAKE_SERVER_RESPONSE:
            self.__logger.debug(f"Handshake client response: {MessageSchema.HANDSHAKE_CLIENT_ACCEPT}")
            await self.__client.send_message( {MessageSchema.COMMAND:ClientCommands.HANDSHAKE,
                                               MessageSchema.DATA:MessageSchema.HANDSHAKE_CLIENT_ACCEPT})
        else:
            return False
        
        server_message = await self.__client.get_message_in_time(5)
        if not server_message: return False
        if  server_message.data==MessageSchema.HANDSHAKE_SUCCESFUL:
            self.__client.handshake=True
            return True
        else:
            self.__logger.debug(f"Handshake server response: {server_message.data}")
            if server_message.data==MessageSchema.WORKERS_EXCEEDED or server_message.data==MessageSchema.MONITORS_EXCEEDED:
                self.__client.__reconnect=False
                self.__client.active=False
            return False
           
    async def execute(self,command,type='r',**kwargs):
        
        
        match type:
            case 'r':#request to client
                command=f"c_{command}"
            case 'e':#execute on client
                command=f"e_{command}"
        
              
        if hasattr(self,command) and callable(func := getattr(self, command)):
          return await  func(**kwargs)
        else:
            self.__logger.debug(f"{command} not implemented")       
    