from enum import StrEnum
class ExtendedStrEnum(StrEnum):

    @classmethod
    def list(cls):
        return list(map(lambda c: c.value, cls))

class ClientRole(ExtendedStrEnum):
    WORKER = 'worker'
    MONITOR = 'monitor'


class ClientCommands(ExtendedStrEnum):
    WHO='who'
    BROWSER='browser'
    HANDSHAKE='handshake'
    QUIT='quit'
    TASKS='tasks'
    LIST='list'
    PING='ping'
    DISPLAY='display'
    LATENCY='latency'
    EMPTY='empty'
    PONG='pong'
    WATCH='watch'

class ClientSubcommands(ExtendedStrEnum):
    ACTION='action'
    TARGET='target'
    

class ServerCommands(ExtendedStrEnum):
    """
    Docstring per ServerCommands
    
    REQUEST monitor client request server to execute command on target client
    STYPE client requests server for a change in type accepted values worker | monitor
    
    """
    DISPLAY='display'
    LOG_CLIENT='log_client'
    PING='ping'
    REQUEST='request' 
    STYPE='stype'
    HANDSHAKE_CLIENT='handshake_client'
    FORWARD_REQUEST='forward_request'
    
            
class ServerSubcommands(ExtendedStrEnum):    
        CLIENT='client'
        TYPE='type'
        IPSTRING='ipstring'
        EXECUTE='execute'
        

class MessageSchema(ExtendedStrEnum):
    COMMAND='command'
    ARGUMENTS='arguments'
    DATA='data'
    SKIP='skip'
    NESTED_COMMAND='nested_command'
    ARGUMENTS_ELEMENT='arguments_element'
    ARGUMENTS_CLIENT='client'
    ARGUMENTS_ACTION='action'
    ANSWER_TO='answer_to'
    ANSWER_FOR='answer_for'
    MAX_EXECUTION_TIME='max_execution_time'
    HANDSHAKE_SERVER_CHALLENGE='manusiuncta'
    HANDSHAKE_SERVER_RESPONSE='salveinnavem'
    HANDSHAKE_CLIENT_RESPONSE='voluptasest'
    HANDSHAKE_CLIENT_ACCEPT='gratias'
    HANDSHAKE_SERVER_ERROR='error'
    HANDSHAKE_SERVER_ACCEPTED='accepted'
    MONITORS_EXCEEDED='max_monitors_exceeded'
    WORKERS_EXCEEDED='max_workers_exceeded'
    HANDSHAKE_SUCCESFUL='quaeso'
    
    
    
    @classmethod
    def structure(cls):
        data={cls.SKIP,cls.NESTED_COMMAND,cls.ARGUMENTS_ELEMENT}
        return data
    
    @classmethod
    def set(cls):
        data=set()
        for argument in cls:
            data.add(argument.value)
        return data
    
    @classmethod
    def issubset(cls,subset):
        if not type(subset) is set:
            subset=set(subset)
        return subset.issubset(cls.set())   