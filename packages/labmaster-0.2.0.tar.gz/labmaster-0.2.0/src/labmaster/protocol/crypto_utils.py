import json
import base64
from Crypto.Cipher import AES
from Crypto import Random
import hashlib
import hmac



class Cipher(object):
    def __init__(self, key):
          
        self.bs = AES.block_size
        self.key = key.encode('utf-8')
    
        
    
    def _pad(self, s):
        padding=(self.bs - len(s) % self.bs) * chr(self.bs - len(s) % self.bs)
        return s + padding
    
    def _unpad(sel,s):
        return s[:-ord(s[len(s) - 1:])]
    
    def createHmac(self, text):
        result = hmac.new(self.key, text.encode('utf-8'), hashlib.sha256).hexdigest()
        return result
    
    def encrypt(self, data):
       
       data = self._pad(data) 
       iv = Random.new().read(AES.block_size)
       cipher = AES.new(self.key, AES.MODE_CBC, iv) 
       encrypted=base64.b64encode(cipher.encrypt(data.encode('utf-8'))).decode()
       iv=base64.b64encode(iv).decode()
       
       result={
               'iv':iv,
               'value':encrypted,
               'mac':self.createHmac(iv+encrypted)
               }
       json_result=json.dumps(result)
       return base64.b64encode(json_result.encode('utf-8')).decode()
    
    def decrypt(self, data):
        try:
            data=base64.b64decode(data)
        except UnicodeDecodeError as err:
            print(err)
            return None
        data=json.loads(data)
        received_hmac = data['mac']
        cipherText = data['value']
        calculated_hmac = self.createHmac(data['iv']+cipherText)
        iv=data['iv']
        iv = base64.b64decode(iv)
        
        if not hmac.compare_digest(received_hmac, calculated_hmac):
            raise ValueError("HMAC verification failed! The data may have been tampered with.")
        
        decipher = AES.new(self.key, AES.MODE_CBC, iv)
        decrypted = decipher.decrypt(base64.b64decode(cipherText))
        unpaded_data=self._unpad(decrypted).decode('utf-8')
        
        return unpaded_data