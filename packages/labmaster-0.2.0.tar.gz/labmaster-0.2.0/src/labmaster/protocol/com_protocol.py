import asyncio
import json
import struct
import sys
from asyncio import PriorityQueue
from labmaster.protocol.crypto_utils import Cipher
from labmaster.configurations import genConfig
from labmaster.protocol.enumerators import MessageSchema,ClientCommands,ServerCommands
from labmaster.protocol.net_exceptions import MalformedMessageError




    




class Message:
    """
    Docstring per Message
    
    This class creates and validates messages sent between client and server.
    Every message rappresents the unencrypted payload that, after being ecrypted, is sent by the comunication protocol from client to server 
    and viceversa.
    Every message must conform to this schema:
    
    command: the command that is going to be executed as per ClientCommands or ServerCommands
    arguments: the arguments, if needed, that must be given to command
    data: data that must be sent along command
    max_execution_time: the maximum time command can use for its execution    
    """
    
    
    def __init__(self,*,command=ClientCommands.EMPTY,arguments='',data='',max_execution_time=10,answer_to=0,answer_for=0):
        self.__command=command
        self.__arguments=arguments
        self.__data=data
        self.__max_execution_time=max_execution_time
        self.__answer_to=answer_to
        self.__answer_for=answer_for
        
        if command!=ClientCommands.EMPTY:
            self.__content=self.generate_command_payload()
        else:
            self.__content=None
        
        self.__abnormal_formatting=False
        
    @property
    def answer_to(self):
        return self.__answer_to
    
    @property
    def answer_for(self):
        return self.__answer_for
         
    @property
    def data(self):
        return self.__data

    @property
    def arguments(self):
        return self.__arguments
    
       
    @property
    def content(self):
        return self.__content
        
    @property
    def abnormal_formatting(self):
        return self.__abnormal_formatting
    
    @property
    def command(self):
        return self.__command
    
    @property
    def max_execution_time(self):
        return self.__max_execution_time
    
    
    def load_command_payload(self,command_payload):
        """_summary_

        Args:
            command_payload (_type_): _description_

        Raises:
            MalformedMessageError: _description_
        """
        if not self.check_command_payload_conformity(command_payload):
            self.__abnormal_formatting=True
            raise MalformedMessageError(f"Command payload is not valid during payload creation {command_payload}")
        
        self.__command=command_payload[MessageSchema.COMMAND] if MessageSchema.COMMAND in command_payload else ClientCommands.EMPTY
        self.__arguments=command_payload[MessageSchema.ARGUMENTS] if MessageSchema.ARGUMENTS in command_payload else ''
        self.__data=command_payload[MessageSchema.DATA] if MessageSchema.DATA in command_payload else ''
        self.__max_execution_time=command_payload[MessageSchema.MAX_EXECUTION_TIME] if MessageSchema.MAX_EXECUTION_TIME in command_payload else 10
        self.__answer_for=command_payload[MessageSchema.ANSWER_FOR] if MessageSchema.ANSWER_FOR in command_payload else 0
        self.__answer_to=command_payload[MessageSchema.ANSWER_TO] if MessageSchema.ANSWER_TO in command_payload else 0
        self.__content=self.generate_command_payload()
     
    
    def generate_command_payload(self):
            """_summary_

            Returns:
                _type_: _description_
            """
                                
            command_payload={
                MessageSchema.COMMAND:self.__command,
                MessageSchema.ARGUMENTS:self.__arguments,
                MessageSchema.DATA:self.__data,
                MessageSchema.MAX_EXECUTION_TIME:self.__max_execution_time,
                MessageSchema.ANSWER_FOR:self.__answer_for,
                MessageSchema.ANSWER_TO:self.__answer_to
            }
            return command_payload
        
    
    
    def check_command_payload_conformity(self,command_payload):
        
       """
       Docstring per check_command_payload_conformity
       
       :param self: Descrizione
       :param command_payload: Descrizione
       """
        
       if type(command_payload) is not dict:
           raise MalformedMessageError(f"Command payload must be a dictionary")
       if not MessageSchema.COMMAND in command_payload:
           raise MalformedMessageError(f"Command payload must contain a command")
           
       if command_payload[MessageSchema.COMMAND] not in ClientCommands and command_payload[MessageSchema.COMMAND] not in ServerCommands:
           raise NotImplementedError(f"Command {command_payload[MessageSchema.COMMAND]} not implemented")
       
       return MessageSchema.issubset(command_payload.keys())
        
    

class ComProtocol:
    """
    Docstring per ComProtocol
    
    This class implements the comunication protocol between client and server.
    Every packet sent must conform to this schema:
    
    HEADER ->4 bytes
    This header contains the size of the subsequent header in json format
    This protocol does not allow payloads greater then MAX_MSG_SIZE 1Mebibyte
    
    PAYLOAD: 

        JSON HEADER -> variable lenght
            Format:
                byteorder
                content-type
                content-encoding
                content-length: byte length of CONTENT
        CONTENT -> variable lenght
            Content consist of an encrypted message encapsulated into a json structure
            
            {encrypted_payload: <encrypted(payload)>}
              
            the unencrypted payload is {payload: <content payload>} 
    """
   
    
    HEADER_SIZE = 4
    MAX_MSG_SIZE = 1024 * 1024  # 1MB limit
    def __init__(self,*,logger,content_type='text/json',content_encoding='utf-8'):
        self.__content_type=content_type
        self.__content_encoding=content_encoding
        self.logger=logger
        self.config=genConfig()
        self.cipher=Cipher(self.config.KEY)
        
        
    @property
    def content_type(self):
        return self.__content_type
    
    @content_type.setter
    def content_type(self,content_type):
        self.__content_type=content_type
    
    @property
    def content_encoding(self):
        return self.__content_encoding
    
    @content_encoding.setter
    def content_encoding(self,content_encoding):
        self.__content_encoding=content_encoding
        
    def _json_encode(self, obj):
        return json.dumps(obj).encode()

    def _create_message(
        self, *, content_bytes
    ):
        jsonheader = {
            "byteorder": sys.byteorder,
            "content-type": self.content_type,
            "content-encoding": self.content_encoding,
            "content-length": len(content_bytes),
        }
        
        if len(content_bytes) > self.MAX_MSG_SIZE:
            raise ValueError("Message size exceeds limit")
        
        jsonheader_bytes = self._json_encode(jsonheader)
        message_hdr = struct.pack("!I", len(jsonheader_bytes))
        message = message_hdr + jsonheader_bytes + content_bytes
        return message
          
    
    def serialize(self, object):
        return json.dumps(object)
    
    
    async def read_message(self,reader: asyncio.StreamReader):
        
        # Read json header length
        
        header = await reader.readexactly(self.HEADER_SIZE)
        json_header_size = struct.unpack("!I", header)[0]
        
        #read json header
        json_header_bytes = await reader.readexactly(json_header_size)
        json_header=json.loads(json_header_bytes.decode())
    
        # Read payload
        payload = await reader.readexactly(json_header['content-length'])
        encrypted_payload=json.loads(payload.decode())
        decripted_payload=self.cipher.decrypt(encrypted_payload['encrypted_payload'])
        decripted_payload=json.loads(decripted_payload)
        
        message=Message()
        message.load_command_payload(decripted_payload['payload'])
               
        return message
      
    async def send_message(self,writer: asyncio.StreamWriter, data: Message):
              
        
        payload={'payload':data.content}
        payload={'encrypted_payload':self.cipher.encrypt(self.serialize(payload))}
        message=self._create_message(content_bytes=self._json_encode(payload))
        writer.write(message)
        await writer.drain()
        
        
