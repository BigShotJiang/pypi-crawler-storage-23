class MalformedMessageError(Exception):
    def __init__(self, msg="Message must conform to some rules"):
        
        self.msg = msg
        super().__init__(self.msg)

    def __str__(self):
        return f"{self.msg}"

class AbnormalCommand(Exception):
    def __init__(self, msg="Command is not valid"):
        
        self.msg = msg
        super().__init__(self.msg)

    def __str__(self):
        return f"{self.msg}"
    
class DuplicatedTask(Exception):
    def __init__(self, msg="Task already exists"):
        
        self.msg = msg
        super().__init__(self.msg)

    def __str__(self):
        return f"{self.msg}"