import re
from enum import StrEnum
from labmaster.protocol.enumerators import ServerCommands,ServerSubcommands,ExtendedStrEnum,MessageSchema,ClientCommands,ClientSubcommands



__ip_pattern = re.compile(r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})')

client_command_rules={ClientCommands.QUIT.value:{'next':[None],
                                                      'value':None,
                                                      'completer_type':'next',
                                                      'match_next':'key',
                                                      'regexp':re.compile(r'(aes)')},
                      ClientCommands.WHO.value:{'next':[None],
                                                      'value':None,
                                                      'completer_type':'next',
                                                      'match_next':'key',
                                                      'regexp':re.compile(r'(aes)')},
                      ClientCommands.WATCH.value:{'next':[ClientSubcommands.ACTION.value],
                                                  'value':None,
                                                  'completer_type':'next',
                                                  'match_next':'key',
                                                  'regexp':re.compile(r'(aes)'),
                                                  ClientSubcommands.ACTION.value:{'next':[ClientSubcommands.TARGET.value],
                                                                                        'value':['start','stop'],
                                                                                        'completer_type':'value',
                                                                                        'match_next':'regexp',
                                                                                        'regexp':re.compile(r'(start|stop)')
                                                                                        },
                                                  ClientSubcommands.TARGET.value:{'next':[None],
                                                                                        'value':['[filesystem]','[process]'],
                                                                                        'completer_type':'value',
                                                                                        'match_next':'key',
                                                                                        'regexp':re.compile(r'(aes)') }
                      }}

client_command_structure={ClientCommands.QUIT:[[re.compile(r'(quit)'),'quit command error','command not complete',MessageSchema.COMMAND]],
                          ClientCommands.WHO:[[re.compile(r'(who)'),'who command error','command not complete',MessageSchema.COMMAND]],
                          ClientCommands.WATCH:[[re.compile(r'(watch)'),'watch  command error','command not complete',MessageSchema.COMMAND],
                                                [re.compile(r'(action)'),'expected action','command not complete',MessageSchema.ARGUMENTS],
                                                [re.compile(r'(start|stop)'),'expected file name','command not complete',MessageSchema.ARGUMENTS_ELEMENT],
                                                [re.compile(r'(target)'),'expected target','command not complete',MessageSchema.ARGUMENTS_ELEMENT],
                                                [re.compile(r'(\[filesystem\]|\[process\])(?:/*[^/]+)+?|/*(\w+\.\w+)'),'expected fileystem target','command not complete',MessageSchema.ARGUMENTS_ELEMENT]]}

server_command_rules={ServerCommands.REQUEST.value:{ 'next':[ServerSubcommands.CLIENT.value],
                                                     'value':None,
                                                     'completer_type':'next',
                                                     'match_next':'key',
                                                     'regexp':re.compile(r'(aes)'),
                                                      ServerSubcommands.CLIENT.value:{'next':[ServerSubcommands.TYPE.value],
                                                                                            'value':['127.0.0.1','10.27.9.1'],
                                                                                            'completer_type':'value',
                                                                                            'match_next':'regexp',
                                                                                            'regexp':re.compile(r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})')},
                                                      ServerSubcommands.TYPE.value:{'next':[ServerSubcommands.EXECUTE.value],
                                                                                        'value':{'monitor','worker'},
                                                                                        'completer_type':'value',
                                                                                        'match_next':'value',
                                                                                        'regexp':re.compile(r'(monitor|worker)')},
                                                      ServerSubcommands.EXECUTE.value:{'next':list(client_command_structure.keys()),
                                                                                            'value':None,
                                                                                            'completer_type':'next',
                                                                                            'match_next':'key',
                                                                                            'regexp':re.compile(r'(aes)')}},
                ServerCommands.DISPLAY.value:{'next':[None],
                                                      'value':None,
                                                      'completer_type':'next',
                                                      'match_next':'key',
                                                      'regexp':re.compile(r'(aes)')}}

server_command_structure={ServerCommands.REQUEST:[[re.compile(r'(request)'),'request command error','command not complete',MessageSchema.COMMAND],
                                                    [re.compile(r'(client)'),'expected client','command not complete',MessageSchema.ARGUMENTS],
                                                    [__ip_pattern,'invalid ip address','command not complete',MessageSchema.ARGUMENTS_ELEMENT],
                                                    [re.compile(r'(type)'),'expected tyoe','command not complete',MessageSchema.ARGUMENTS_ELEMENT],
                                                    [re.compile(r'(worker|monitor)'),'expected client type','command not complete',MessageSchema.ARGUMENTS_ELEMENT],
                                                    [re.compile(r'(execute)'),'next subcommand error','command not complete',MessageSchema.NESTED_COMMAND],
                                                    [re.compile(r'(\w+)'),'client command error','command not complete',MessageSchema.DATA]],
                            ServerCommands.DISPLAY:[[re.compile(r'(display)'),'display command error','command not complete',MessageSchema.COMMAND]]}

arguments_structure={
    MessageSchema.ARGUMENTS_CLIENT:[[re.compile(r'(client)'),'key','client'],
                                    [__ip_pattern,'value'],
                                    [re.compile(r'(type)'),'key','type'],
                                    [re.compile(r'(worker|monitor)'),'value']
                                    ],
    MessageSchema.ARGUMENTS_ACTION:[[re.compile(r'(action)'),'key','action'],
                                    [re.compile(r'(start|stop)'),'value'],
                                    [re.compile(r'(target)'),'key','target'],
                                    [re.compile(r'(\[filesystem\]|\[process\])(?:/[^/]+)+?|/*(\w+\.\w+)'),'value']
                                    ],
}

class AvailableClientCommands(ExtendedStrEnum):
    QUIT='quit'
    WHO='who'
    WATCH='watch'
    
    def __init__(self,command):
        self.command=command

    @property
    def rules(self):
        if self.command in client_command_rules:
            return client_command_rules[self.command]
        else:
            return None
        
    @property
    def format(self):
        if self.command in client_command_structure:
            return client_command_structure[self.command]
        else:
            return None
            
            
    @classmethod
    def descriptions(cls):
        new_descriptions={}
        for command in cls:
                new_descriptions[command.value]=command.rules
        return new_descriptions
    
    @classmethod
    def structures(cls):
        new_structure={}
        for command in cls:
                new_structure[command.value]=command.format
        return new_structure

class AvailableServerCommands(ExtendedStrEnum):
           
    REQUEST='request'
    DISPLAY='display'

    def __init__(self,command):
        self.command=command

    @property
    def rules(self):
        if self.command in server_command_rules:
            return server_command_rules[self.command]
        else:
            return None
        
    @property
    def format(self):
        if self.command in server_command_structure:
            return server_command_structure[self.command]
        else:
            return None
            
            
    @classmethod
    def descriptions(cls):
        new_descriptions={}
        for command in cls:
                new_descriptions[command.value]=command.rules
        return new_descriptions
    
    @classmethod
    def structures(cls):
        new_structure={}
        for command in cls:
                new_structure[command.value]=command.format
        return new_structure

class AvailableArguments(ExtendedStrEnum):
    
    ARGUMENTS_CLIENT='client'
    ARGUMENTS_ACTION='action'
    
    def __init__(self,argument):
        self.argument=argument
    
    
    @property
    def format(self):
        if self.argument in arguments_structure:
            return arguments_structure[self.argument]
        else:
            return None
    
    
    
    @classmethod
    def structures(cls):
        new_structure={}
        for command in cls:
                new_structure[command.value]=command.format
        return new_structure
        
    
 



