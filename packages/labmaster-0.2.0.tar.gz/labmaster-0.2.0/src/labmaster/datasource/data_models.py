from peewee import Model,CharField,IntegerField,DateTimeField,ForeignKeyField
import datetime


class grade(Model):
    name=CharField(unique=True)
    session=DateTimeField(default=datetime.datetime.now)


class laboratory(Model):
    name=CharField(unique=True)
    seats=IntegerField(default=28)
    room_code=CharField()


class role(Model):
    name=CharField(unique=True)
    description=CharField(default="Just an ordinary user")


class user(Model):
    username=CharField(unique=True)
    login_count=IntegerField(default=0)
    last_log=DateTimeField(default=datetime.datetime.now)
    access_token=CharField(default='')
    attended_grade=ForeignKeyField(grade,backref='students')
    main_role=ForeignKeyField(role,backref='users')
    
    
class microcomputer(Model):
    mac_address=CharField(unique=True)
    lab=ForeignKeyField(laboratory,backref='computers')
    hostname=CharField()
    ip_address=CharField()
    os=CharField()
    shell=CharField()
    broadcast=CharField()
    connection=CharField()

class userSession(Model):
    user=ForeignKeyField(user,backref='sessions')
    computer=ForeignKeyField(microcomputer,backref='sessions')
    time=DateTimeField(default=datetime.datetime.now)
    action=CharField()
    shell=CharField()
 
    
class classroom(Model):
    name=CharField(unique=True)
    seats=IntegerField(default=21)
    room_code=CharField()
     
class group(Model):
    name=CharField(unique=True)
    creation_date=DateTimeField(default=datetime.datetime.now)
    gid=IntegerField()
    type=CharField(default="ldap")
    
class usergroup(Model):
    user=ForeignKeyField(user,backref='groups')
    group=ForeignKeyField(group,backref='users')
    