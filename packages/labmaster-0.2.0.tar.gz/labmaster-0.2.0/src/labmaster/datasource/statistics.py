import time
import asyncio
from rich.live import Live
from rich.table import Table


async def print_statistics(generator,frequency,table):
    with table as live:
        for _ in range(40):
            asyncio.sleep(0.5)
            live.update(generator())