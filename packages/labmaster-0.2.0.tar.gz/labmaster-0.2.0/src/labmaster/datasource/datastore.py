import datetime
from peewee import SqliteDatabase,IntegrityError,DoesNotExist,MySQLDatabase
from labmaster.datasource.data_models import *
from labmaster.configurations import genConfig

class DataStore:
    def __init__(self):
        
        config=genConfig()
        self.parameters=config
        match config.DB_TYPE:
            case 'sqlite':
                self.db=SqliteDatabase(config.DB_PATH)
            case 'mariadb':
                self.db=MySQLDatabase(config.DB_NAME, user=config.DB_USER, password=config.DB_PWD,
                         host=config.DB_HOST, port=config.DB_PORT)
                       
        self.db.bind(config.DB_TABLES)
        
    def init_db(self):
        db = self.db.create_tables(self.parameters.DB_TABLES)
        return db
       
    def add_table(self,table):
        db = self.db.create_tables([table])
        return db
       
    def add_lab(self,name):
        try:
            lab=laboratory.create(name=name,seats=28,room_code='insert')
        except IntegrityError:
            return False
        return lab
    
    def get_lab(self,name):
        try:
            lab=laboratory.get(laboratory.name==name)
        except DoesNotExist:
            return None
        return lab

    def get_labs(self):
        labs=laboratory.select()
        return labs
    
    def add_computer(self,mac_address,lab_name,hostname,ip_address,os,shell,broadcast,connection):
        
        lab=self.get_lab(lab_name)

        if not lab:
            return False
        
        try:
            computer=microcomputer.create(mac_address=mac_address,lab=lab,hostname=hostname,ip_address=ip_address,os=os,shell=shell,broadcast=broadcast,connection=connection)
        except IntegrityError:
            return False
        return computer
    
    def get_computer(self,mac_address):
        try:
            computer=microcomputer.get(microcomputer.mac_address==mac_address)
        except DoesNotExist:
            return None
        return computer
    
    def get_computer_by_hostname(self,hostname):
        try:
            computer=microcomputer.get(microcomputer.hostname==hostname)
        except DoesNotExist:
            return None
        return computer
    
    
    def add_grade(self,name):
        try:
            new_grade= grade.create(name=name)
        except IntegrityError:
            return None
        return new_grade

    def get_grade(self,name):
        try:
            current_grade=grade.get(grade.name==name)
        except DoesNotExist:
            return None
        return current_grade
    
    
    def get_role(self,name):
        try:
            current_role=role.get(role.name==name)
        except DoesNotExist:
            return None
        return current_role
    
    def add_role(self,name):
        try:
            new_role=role.create(name=name)
        except IntegrityError:
            return None
        return new_role 
    
    
    
    def add_user(self,username,current_role:role,current_grade:grade):
        
        try:
           new_user= user.create(username=username,main_role=current_role,attended_grade=current_grade,last_log=datetime.datetime.now(),access_token='')
        except IntegrityError:
            return None

        return new_user
    
    def get_user(self,username):
        try:
            current_user=user.get(user.username==username)
        except DoesNotExist:
            return None
        return current_user
    
    def add_group(self,name):
        try:
            new_group=group.create(name=name,creation_date=datetime.datetime.now(),gid=0,type='ldap')
        except IntegrityError:
            return None
        return new_group
    
    def get_group(self,name):
        try:
            current_group=group.get(group.name==name)
        except DoesNotExist:
            return None
        return current_group
    
    def add_user_group(self,username,groupname):
        current_user=self.get_user(username)
        current_group=self.get_group(groupname)
        if not current_user or not current_group:
            return None
        try:
            new_user_group=usergroup.create(user=current_user,group=current_group)
        except IntegrityError:
            return None
        return new_user_group
    
    def add_user_session(self,user,computer,action,shell):
        try:
            new_session=userSession.create(user=user,computer=computer,action=action,shell=shell)
        except IntegrityError:
            return None
        return new_session

    