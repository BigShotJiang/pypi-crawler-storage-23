import argparse
import asyncio
from labmaster.clients.async_clients_lab import LabClient2
from labmaster.logger_utils import setup_logger
from labmaster.configurations import genConfig





config=genConfig()
new_logger=setup_logger('Client',config=config)

parser = argparse.ArgumentParser(description="labs client",
                                 formatter_class=argparse.ArgumentDefaultsHelpFormatter)

parser.add_argument('--cli', action='store_true', help="enable cli")
parser.add_argument('--no-cli', dest='cli', action='store_false',help="disable cli")
parser.set_defaults(cli=True)
args = parser.parse_args()
arguments = vars(args)

def main_client():
    client = LabClient2(config.SERVER_ADDRESS, 6666,client_logger=new_logger,enable_cli=arguments['cli'])
    asyncio.run(client.start_client())
    
if __name__ == "__main__":
    main_client()