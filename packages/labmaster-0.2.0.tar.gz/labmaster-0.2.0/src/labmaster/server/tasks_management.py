import asyncio
import time
from asyncio import PriorityQueue
from labmaster.protocol.com_protocol import Message




class ServerTask:
    def __init__(self,*,client,command,priority='normal',data='',arguments=''):
        self.__priority=priority
        self.__command=command
        self.__client=client
        self.__data=data
        self.__arguments=arguments
        self.__creation_time=time.monotonic()

    async def execute(self):
        if self.__client:
             await self.__client.actions.execute(self.__command,message=Message(data=self.__data,arguments=self.__arguments))
        
        
class TasksQueue:
    def __init__(self,*,client_id,size=100):
        self.__client_id=client_id
        self.__server_tasks = PriorityQueue(maxsize=size)
        self.__active_task_consumer=True
        self.__consumer=asyncio.create_task(self._task_consumer())

    @property
    def client_id(self):
        return self.__client_id
    
    @property
    def server_tasks(self):
        return self.__server_tasks
    


    async def stop_consumer(self):
        self.__active_task_consumer=False
        await self.__consumer

    def start_consumer(self):
        if not isinstance(self.__consumer,asyncio.Task):
            self.__active_task_consumer=True
            self.__consumer=asyncio.create_task(self._task_consumer())     
    
    async def _task_consumer(self):
        while self.__active_task_consumer:
            priority,server_task=await self.__server_tasks.get()
            await server_task.execute()
            self.__server_tasks.task_done()
            
    