import asyncio
import logging
from datetime import datetime
from labmaster.clients.asyncclients import Client2 as Client
from labmaster.logger_utils import setup_logger
from labmaster.server.server_actions import ServerActions
from labmaster.protocol.enumerators import ServerCommands,MessageSchema,ClientCommands
from labmaster.configurations import genConfig
from labmaster.server.tasks_management import TasksQueue,ServerTask
from rich.live import Live
from rich.table import Table

class ServerStatistics:
    """_summary_
    """
    def __init__(self,*,server,logger):
        self.__server=server
        self.__logger=logger
        self.__live=Live(self.__generator(),refresh_per_second=1,transient=True,screen=True)
        self.__active=True
        self.__display_task=None

    @property
    def display_task(self):
        return self.__display_task
    
    
    @display_task.setter
    def display_task(self,task):
        self.__display_task=task
    
    
    def __generator(self):
        table = Table(title=f":satellite: Server {self.__server.ip}:{self.__server.port} Status")
        table.add_column("Client ip")
        table.add_column("Type")
        table.add_column("Server Tasks")
        table.add_column("Sent messages")
        table.add_column("Received messages")
        
        
        
        rows=[]
        
        for client_ip in self.__server.clients:
            for client_task,client in self.__server.clients[client_ip].items():
                enqueued_tasks=self.__server.tasks_queues.get(id(client))
                server_tasks= enqueued_tasks.server_tasks.qsize() if enqueued_tasks else 0
                rows.append({'ip':client_ip,'type':client.client_type,'server_tasks':server_tasks,
                             'sent_messages':client.sent,
                             'received_messages':client.received
                             })
                   
        for row in rows:
            table.add_row(row['ip'],row['type'],str(row['server_tasks']),str(row['sent_messages']),str(row['received_messages']))
            #f"{row}", f"{value:3.2f}", "[red]ERROR" if value < 50 else "[green]SUCCESS"
        
        return table

    async def enable(self):
        if not self.__active:
            self.__active=True  
            self.print_statistics()
       
    async def disable(self):
        if self.__active:
            self.__active=False
     
    async def shutdown(self):
        if self.__display_task:
            await self.disable()
            await self.__display_task

        
    async def print_statistics(self):
        while self.__active:
            with self.__live as live:
                await asyncio.sleep(1)
                live.update(self.__generator())

    

class Server:
    def __init__(self, config:genConfig,*,enable_statistic=False):
       
        self.__ip: str = config.SERVER_ADDRESS
        self.__port: int = config.SERVER_PORT
        self.__config=config
        self.__logger: logging.Logger = self.initialize_logger()
        self.__clients: dict[str,dict[asyncio.Task, Client]] = {}
        self.__client_ids:dict[int,Client]={}
        self.__tasks_queues:dict[int,TasksQueue]={}
        self.logger.info(f"Server Initialized with {self.ip}:{self.port}")
        self.__actions=ServerActions(server=self)
        self.__statistics=ServerStatistics(server=self,logger=self.logger)
        self.__enable_statistics=enable_statistic
    

    @property
    def ip(self):
        return self.__ip

    @property
    def port(self):
        return self.__port
   
    @property
    def logger(self):
        return self.__logger

    @property
    def client_ids(self):
        return self.__client_ids

    @property
    def clients(self):
        return self.__clients
    
    @property
    def tasks_queues(self):
        return self.__tasks_queues
    

    def initialize_logger(self):
        
        return setup_logger('Server',config=self.__config)
      
    async def start_server(self):
        
        self.server = await asyncio.start_server(
                self.accept_client, self.ip, self.port
            )

        try:
            async with self.server:
                if self.__enable_statistics:
                   self.__statistics.display_task=asyncio.create_task(self.__statistics.print_statistics() )
                
                await self.server.serve_forever()
                  
        except KeyboardInterrupt:
            self.logger.warning("Keyboard Interrupt Detected. Shutting down!")
            await self.shutdown_server()
        except asyncio.exceptions.CancelledError:
            self.logger.warning("Loop cancelled! Shutting down!")
            await self.shutdown_server()
        except Exception as e:
            self.logger.error(e)
       
          
    def _register_client(self,client:Client,task:asyncio.Task):
            
            self.client_ids[id(client)]=client
            
            if client.ip in self.clients:
                self.clients[client.ip][task]=client
            else:
                self.clients[client.ip]={task:client}
            if  id(client) in self.tasks_queues:
                self.logger.debug(f"Client queue {id(client)} already present")
            else:
                self.tasks_queues[id(client)]=TasksQueue(client_id=id(client))
    
    async def _unregister_client_task(self,task:asyncio.Task):
            client_ip=task.get_name()
            if client_ip in self.clients:
                object_id=id(self.clients[client_ip][task])
                del self.clients[client_ip][task]
                del self.client_ids[object_id]
                if tasks_queue:=self.tasks_queues.get(object_id):
                    await tasks_queue.stop_consumer()
                    del self.tasks_queues[object_id]
              
    async def accept_client(self, client_reader: asyncio.StreamReader, client_writer: asyncio.StreamWriter):
        client = Client(client_reader, client_writer,client_logger=self.logger)
        
        client_accepted=await self.__actions.execute(ServerCommands.HANDSHAKE_CLIENT,client=client)
        
        if not client_accepted:
            self.logger.info(f"Client handshake failed")
            client_writer.close()
            await client.writer.wait_closed()
            return
        else:
            
            client_ip = client_writer.get_extra_info('peername')[0]
            client_port = client_writer.get_extra_info('peername')[1]
            task = asyncio.create_task(self.handle_client_connection(client),name=client_ip)
            self._register_client(client,task)
            self.logger.info(f"New Connection: {client_ip}:{client_port}")
            task.add_done_callback(self.disconnect_client_callback)
    
    async def handle_client_connection(self, client: Client):
        
        client_message=None
        while True:
            
            client_message = await client.get_message()
                       
            if not client_message:
                break
            
            
          
                
            match client_message.command:
            
                case ClientCommands.QUIT:
                    self.logger.info("Quitting! {self.clients[asyncio.current_task()].ip}")
                    break
                
                case ClientCommands.PING:
                    await client.pong()
                case _:
                    try:
                        await self.__actions.execute(client_message.command,
                                                     message=client_message,
                                                     client=client)
                    except NotImplementedError as e:
                        self.logger.error(e)
                    
                    #await self.broadcast_message(f"{client.nickname}: {client_message['command']}")        
        self.logger.info("Client Disconnected!")
     
    async def broadcast_message(self, message: str, exclusion_list: list = []):
        for client_ip in self.clients:
            for client in self.clients[client_ip].values():
                self.logger.info(f"Sending message to client {client.ip}")
                if client not in exclusion_list:
                    await client.send_message({'command':'display','data':message})

    def disconnect_client_callback(self,context: asyncio.Task):
        asyncio.create_task(self.disconnect_client(context))
      
    async def disconnect_client(self, task: asyncio.Task):
        self.logger.info("Disconnecting client")
        
        client = self.clients[task.get_name()][task]
        
        try:
            await asyncio.gather(
                self.broadcast_message(f"{client.nickname} has left!",[client]), client.quit())
        except Exception as e:
            self.logger.error(f"Client already died  {e}")
            
        client.writer.close()
        await client.writer.wait_closed()
        self.logger.info("End Connection")
        await self._unregister_client_task(task)
          
    async def shutdown_server(self):
        if self.__enable_statistics:
            await self.__statistics.shutdown()
        self.logger.info("Shutting down server!")
        async with asyncio.TaskGroup() as tg:
            for client_ip in self.clients.keys():
                for client_task in self.clients[client_ip].keys():
                    tg.create_task(self.disconnect_client(client_task))
                
        self.server.close()
