import re
import sys
import psutil
import asyncio
from labmaster.clients.asyncclients import Client2 as Client
from labmaster.protocol.enumerators import MessageSchema,ServerCommands,ClientCommands,ClientRole
from labmaster.protocol.com_protocol import Message
from labmaster.server.tasks_management import ServerTask
   
    
class ServerActions:
    """
    Docstring for ServerActions
    
    This actions are performed on server side.
    
    :var format: Descrizione
    :vartype format: str
    :var values: Descrizione
    """
    
    MAX_WORKERS=1
    MAX_MONITORS=1
    
    def __init__(self,*,server):
        self.__server=server
        self.__logger=server.logger
    
    
    def _parse_message_data(self,message_data):
       answer_for=re.compile(r'(answer_for):(\d+)')
       
       if match:=answer_for.search(message_data):
           return int(match.group(2))
       return None
    
    def _get_clients_type_number(self,client_ip,client_type):
        if client_ip in self.__server.clients:
            return len([x for x in self.__server.clients[client_ip].values() if x.client_type==client_type])
        return 0

    def _get_workers_number(self,client_ip):
        return self._get_clients_type_number(client_ip,ClientRole.WORKER)
    
    def _get_monitors_number(self,client_ip):
        return self._get_clients_type_number(client_ip,ClientRole.MONITOR)
    
    async def c_forward_request(self,**kwargs):
        message=kwargs['message']
        data=message.data
        self.__logger.debug(f" forward {data} to client {message.answer_for}")
         
        
        if message.answer_for in self.__server.client_ids:
                
                client=self.__server.client_ids[message.answer_for]
                new_server_task=ServerTask(client=client,command=ClientCommands.DISPLAY,data=data)
                await self.__server.tasks_queues[id(client)].server_tasks.put((10,new_server_task))
                #await client.actions.execute(ClientCommands.DISPLAY,message=Message(data=data))
        else:
           self.__logger.debug('Client already left')
    
    async def c_request(self,**kwargs):
        """
        Docstring per c_request
        
        
        A client can REQUEST server to forward a command to another client.
        
        :param kwargs: 
                MessageSchema.ARGUMENTS format {'client':<client ip>, 'type':worker}
                MessageSchema.DATA format <encapsulated_message>
        """
        message=kwargs['message']
        
        if message.arguments:
            self.__logger.debug(f"Received request for {message.arguments}")
            client_ip=message.arguments['client']
            client_type=message.arguments['type']
            caller=kwargs['client']
                        
            client=next((x for x in self.__server.clients[client_ip].values() if x.client_type==client_type), None)
            
                        
            if not client:
                    self.__logger.warning(f"No {client_type} available for client {client_ip}")
                    await caller.actions.execute(ClientCommands.DISPLAY,message=Message(data=f"No {client_type} available for client {client_ip}"))
                    return
            
            client_action=message.data
            
            client_command={'command':'','arguments':'','data':'','max_execution_time':100,'answer_to':id(caller)}
            
            for key, value in client_action.items():
                if isinstance(value,dict):
                    client_command[key]=value
                else:
                    client_command[key]=value+client_command[key]
                   
            
            
            new_message=Message()
            new_message.load_command_payload(client_command)
            self.__logger.debug(new_message.content)
            
            await client.actions.execute(client_command[MessageSchema.COMMAND],
                                         message=new_message,)
            
              
    def c_stype(self,**kwargs):
        """
        Docstring for c_stype
        
        
        A client can request server to change its registration type
        :param kwargs
            MessageSchema.ARGUMENTS format:str values: worker | monitor
        
        """
        if MessageSchema.ARGUMENTS in kwargs:

                message=kwargs['message']
                self.__logger.info(f"Received type change for {kwargs['client'].ip} to {message.arguments}")
                
                if len(self.__server.clients[kwargs['client'].ip])>0 and message.arguments=='worker':
                    self.__logger.warning(f"There is already a worker for ip {kwargs['client'].ip}")
                else:
                    kwargs['client'].client_type=message.arguments
    
    def f_stype(self,**kwargs):
        """
        Docstring for f_stype
        """
        
        return {'command':ServerCommands.STYPE.value,
                      'arguments':kwargs['type']}
        
    async def c_list(self,**kwargs):
        clients_list=[]
        client:Client=kwargs['client']
        for client_tasks in self.__server.clients.values():
                    for client in client_tasks.values():
                        clients_list.append({'ip':client.ip,'type':client.client_type})
                                
        return await client.send_message({'command':'display','data':clients_list})

    async def c_handshake_client(self, **kwargs):
        
        client:Client =kwargs['client']
        
        if not await client.send_message({MessageSchema.COMMAND:ClientCommands.HANDSHAKE,
                                          MessageSchema.DATA:MessageSchema.HANDSHAKE_SERVER_CHALLENGE}): return None 
        
        await asyncio.sleep(0.25)
        client_message= await client.get_message_in_time(4)
        if not client_message: return False 
        if client_message.data==MessageSchema.HANDSHAKE_CLIENT_RESPONSE:
            client_type=client_message.arguments
            if not await client.send_message({MessageSchema.COMMAND:ClientCommands.HANDSHAKE,
                                              MessageSchema.DATA:MessageSchema.HANDSHAKE_SERVER_RESPONSE} ): return None
            
            self.__logger.debug(f"Client of type {client_type} handshake comunication successful")
        else:
            return False
        
        await asyncio.sleep(0.25)
        client_message= await client.get_message_in_time(4)
        if not client_message: return False 
        
        if client_message.data==MessageSchema.HANDSHAKE_CLIENT_ACCEPT:
            self.__logger.debug(f"Client accepted comunication handshake")
        else:
            return False

          
        match client_type:
                case ClientRole.WORKER.value:
                    present_workers_number=self._get_workers_number(client.ip)
                    self.__logger.debug(f"Running workers number: {present_workers_number} ")
                    client.client_type=ClientRole.WORKER
                    if present_workers_number+1>self.MAX_WORKERS:
                        self.__logger.debug(f"Max running workers number reached")
                        await client.send_message({MessageSchema.COMMAND:ClientCommands.HANDSHAKE,
                                                   MessageSchema.DATA:MessageSchema.WORKERS_EXCEEDED} )
                        return False
                
                case ClientRole.MONITOR.value:
                    present_monitors_number=self._get_monitors_number(client.ip)
                    self.__logger.debug(f"Running monitors number: {present_monitors_number} ")
                    client.client_type=ClientRole.MONITOR
                    if present_monitors_number+1>self.MAX_MONITORS:
                        self.__logger.debug(f"Max running monitors number reached")
                        await client.send_message({MessageSchema.COMMAND:ClientCommands.HANDSHAKE,
                                                   MessageSchema.DATA:MessageSchema.MONITORS_EXCEEDED} )
                        return False
                    
        await client.send_message({MessageSchema.COMMAND:ClientCommands.HANDSHAKE,
                                                   MessageSchema.DATA:MessageSchema.HANDSHAKE_SUCCESFUL} )
            
        return True
                
    async def c_tasks(self,**kwargs):
        client:Client =kwargs['client']
        return await client.display([task.get_name() for task in self.__server.clients[client.ip].keys()])
        
    async def execute(self,command,**kwargs):
        """
        Docstring for execute
        
        this method is colled server side to execute actions
        
        :param self: 
        :param kwargs:
        """
        f_command=f"c_{command}"
        
        if hasattr(self,f_command) and callable(func := getattr(self, f_command)):
            return await func(**kwargs)
        else:
            raise NotImplementedError(f"Command {command} not implemented")
                
    def format(self,command,**kwargs):
        """
        Docstring for format
        
        This method is used to format a message in the correct way
        
        :param self: 
        :param command: 
        :param kwargs: 
        """
        command=f"f_{command.value}"
        if hasattr(self,command) and callable(func := getattr(self, command)):
            func(**kwargs)