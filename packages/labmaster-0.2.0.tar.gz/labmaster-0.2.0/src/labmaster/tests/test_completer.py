from labmaster.clients.cli_tools import CommandsCompleter2
from labmaster.configurations import genConfig
from prompt_toolkit import prompt
from labmaster.logger_utils import setup_logger
config=genConfig()

new_logger=setup_logger('test_completer',config=config)

text = prompt("# ", completer=CommandsCompleter2(new_logger))



print(f"You said: {text}")


