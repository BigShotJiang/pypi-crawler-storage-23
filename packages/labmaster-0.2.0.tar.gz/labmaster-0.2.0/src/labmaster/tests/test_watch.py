import asyncio
from watchfiles import awatch
from aiopsutil import AsyncPSUtil



async def main():
    async for changes in awatch('/tmp/gatto'):
       for element in changes:
           match element[0]:
               case 1:
                   print(element)
               case 2:
                   print(element)


async def get_process():
    aps = AsyncPSUtil()
    while True:
        async for proc in aps.process_iter():
            
            if await proc.name()=="firefox":
                print("cane")
                break
        await asyncio.sleep(1) 

    
   # async for proc in aps.process_iter(['pid', 'name']):
   #     print(f"Process ID: Name: {proc.info['name']}")



asyncio.run(get_process())