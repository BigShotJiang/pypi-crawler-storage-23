from labmaster.protocol.commands_description import AvailableServerCommands,AvailableClientCommands,AvailableArguments


#print(AvailableServerCommands.structures()|AvailableClientCommands.structures())



#print(AvailableServerCommands.descriptions()|AvailableClientCommands.descriptions())

#print(AvailableArguments.structures())


