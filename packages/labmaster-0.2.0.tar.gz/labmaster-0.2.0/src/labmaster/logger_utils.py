import pathlib
import logging
import os
from datetime import datetime
from pathlib import Path

def setup_logger(name,*,config):
        
        global_level=config.LOG_LEVEL['global_level']
        console_level=config.LOG_LEVEL['console_level']
        file_level=config.LOG_LEVEL['file_level']
         

        
        path = pathlib.Path(os.path.join(os.getcwd(), "logs"))
        path.mkdir(parents=True, exist_ok=True)
        logger = logging.getLogger(name)
 

 
 
        def get_debug_level(level):
            match level:
                case 'debug':
                    return logging.DEBUG
                case 'info':
                    return logging.INFO
                case 'warning':
                    return logging.WARNING
                case 'error':
                    return logging.ERROR
                case 'critical':
                    return logging.CRITICAL
                case _:
                    return logging.INFO 

 
        logger.setLevel(get_debug_level(global_level))

        Path(f"{config.LOG_DIR}/logs").mkdir(parents=True, exist_ok=True)
        
        ch = logging.StreamHandler()
        fh = logging.FileHandler(
            filename=f"{config.LOG_DIR}/logs/{datetime.now().strftime("%Y-%m-%d-%H-%M-%S")}_{name}.log"
        )
        
        
        
        ch.setLevel(get_debug_level(console_level))
        fh.setLevel(get_debug_level(file_level))
        
        formatter = logging.Formatter(
            '[%(asctime)s] - %(levelname)s - %(message)s'
        )
        ch.setFormatter(formatter)
        fh.setFormatter(formatter)
        logger.addHandler(ch)
        logger.addHandler(fh)
        return logger