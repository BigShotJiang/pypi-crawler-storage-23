"""Shared pytest fixtures for depwhy tests."""

from typing import Any

import pytest

from tests.fixtures import ALL_FIXTURES


@pytest.fixture(params=ALL_FIXTURES, ids=[f["name"] for f in ALL_FIXTURES])
def conflict_scenario(request: pytest.FixtureRequest) -> dict[str, Any]:
    """Parametrised fixture yielding each conflict scenario dict.

    Each scenario contains:
        - name: descriptive identifier
        - description: what the fixture tests
        - requirements: list of PEP 508 requirement strings
        - expected_conflicts: list of package names expected to conflict
        - expected_solution_contains: substring expected in the solution
        - pypi_responses: dict mapping package names to mocked PyPI JSON responses
        - platform (optional): target platform for marker evaluation
    """
    scenario: dict[str, Any] = request.param
    return scenario
