"""No-conflict baseline fixture: clean requirements with zero conflicts.

A set of well-known packages with compatible version constraints that should
produce no conflicts.
"""

FIXTURE = {
    "name": "no_conflict_baseline",
    "description": (
        "Clean requirements with zero conflicts. flask==3.0.0 and its transitive "
        "dependencies (Werkzeug, Jinja2, itsdangerous, click, MarkupSafe, blinker) "
        "all have compatible version ranges."
    ),
    "requirements": [
        "flask==3.0.0",
        "jinja2>=3.1.2",
    ],
    "expected_conflicts": [],
    "expected_solution_contains": "",
    "pypi_responses": {
        "flask": {
            "info": {
                "name": "Flask",
                "version": "3.0.0",
                "requires_dist": [
                    "Werkzeug>=3.0.0",
                    "Jinja2>=3.1.2",
                    "itsdangerous>=2.1.2",
                    "click>=8.1.3",
                    "blinker>=1.6.2",
                    "importlib-metadata>=3.6.0 ; python_version < '3.10'",
                ],
            },
            "releases": {
                "2.0.0": [{}],
                "2.1.0": [{}],
                "2.2.0": [{}],
                "2.2.5": [{}],
                "2.3.0": [{}],
                "2.3.3": [{}],
                "3.0.0": [{}],
                "3.0.1": [{}],
            },
        },
        "werkzeug": {
            "info": {
                "name": "Werkzeug",
                "version": "3.0.1",
                "requires_dist": [
                    "MarkupSafe>=2.1.1",
                ],
            },
            "releases": {
                "2.0.0": [{}],
                "2.2.0": [{}],
                "2.3.0": [{}],
                "2.3.8": [{}],
                "3.0.0": [{}],
                "3.0.1": [{}],
            },
        },
        "jinja2": {
            "info": {
                "name": "Jinja2",
                "version": "3.1.3",
                "requires_dist": [
                    "MarkupSafe>=2.0",
                ],
            },
            "releases": {
                "3.0.0": [{}],
                "3.0.3": [{}],
                "3.1.0": [{}],
                "3.1.2": [{}],
                "3.1.3": [{}],
            },
        },
        "itsdangerous": {
            "info": {
                "name": "itsdangerous",
                "version": "2.1.2",
                "requires_dist": None,
            },
            "releases": {
                "2.0.0": [{}],
                "2.0.1": [{}],
                "2.1.0": [{}],
                "2.1.2": [{}],
            },
        },
        "click": {
            "info": {
                "name": "click",
                "version": "8.1.7",
                "requires_dist": None,
            },
            "releases": {
                "8.0.0": [{}],
                "8.0.4": [{}],
                "8.1.0": [{}],
                "8.1.3": [{}],
                "8.1.7": [{}],
            },
        },
        "blinker": {
            "info": {
                "name": "blinker",
                "version": "1.7.0",
                "requires_dist": None,
            },
            "releases": {
                "1.4": [{}],
                "1.5": [{}],
                "1.6.2": [{}],
                "1.6.3": [{}],
                "1.7.0": [{}],
            },
        },
        "markupsafe": {
            "info": {
                "name": "MarkupSafe",
                "version": "2.1.5",
                "requires_dist": None,
            },
            "releases": {
                "2.0.0": [{}],
                "2.0.1": [{}],
                "2.1.0": [{}],
                "2.1.1": [{}],
                "2.1.3": [{}],
                "2.1.5": [{}],
            },
        },
    },
}
