"""Circular dependency fixture: two packages that depend on each other.

Package alpha requires beta, and beta requires alpha. Both also depend on
shared-lib, but with incompatible version constraints, creating a conflict
on top of the circular dependency.
"""

FIXTURE = {
    "name": "circular_dep",
    "description": (
        "Two packages (alpha and beta) that depend on each other circularly. "
        "alpha requires shared-lib>=2.0,<3.0 and beta requires shared-lib>=1.0,<2.0. "
        "No version of shared-lib satisfies both constraints."
    ),
    "requirements": [
        "alpha==1.0.0",
        "beta==1.0.0",
    ],
    "expected_conflicts": ["shared_lib"],
    "expected_solution_contains": "shared",
    "pypi_responses": {
        "alpha": {
            "info": {
                "name": "alpha",
                "version": "1.0.0",
                "requires_dist": [
                    "beta>=1.0.0",
                    "shared-lib>=2.0.0,<3.0.0",
                ],
            },
            "releases": {
                "0.9.0": [{}],
                "1.0.0": [{}],
                "1.1.0": [{}],
                "1.2.0": [{}],
            },
        },
        "beta": {
            "info": {
                "name": "beta",
                "version": "1.0.0",
                "requires_dist": [
                    "alpha>=1.0.0",
                    "shared-lib>=1.0.0,<2.0.0",
                ],
            },
            "releases": {
                "0.9.0": [{}],
                "1.0.0": [{}],
                "1.1.0": [{}],
                "1.2.0": [{}],
            },
        },
        "shared-lib": {
            "info": {
                "name": "shared-lib",
                "version": "2.5.0",
                "requires_dist": None,
            },
            "releases": {
                "1.0.0": [{}],
                "1.2.0": [{}],
                "1.5.0": [{}],
                "1.9.0": [{}],
                "2.0.0": [{}],
                "2.1.0": [{}],
                "2.5.0": [{}],
                "3.0.0": [{}],
            },
        },
    },
}
