"""Test fixtures for depwhy conflict scenarios.

Each fixture module exports a ``FIXTURE`` dict describing a dependency conflict
scenario (or a clean baseline) with mocked PyPI responses.
"""

from tests.fixtures import (
    circular_dep,
    django_celery_kombu,
    env_marker_conflict,
    ml_stack_conflict,
    no_conflict_baseline,
    requests_urllib3,
)

ALL_FIXTURES: list[dict] = [  # type: ignore[type-arg]
    ml_stack_conflict.FIXTURE,
    requests_urllib3.FIXTURE,
    django_celery_kombu.FIXTURE,
    circular_dep.FIXTURE,
    env_marker_conflict.FIXTURE,
    no_conflict_baseline.FIXTURE,
]

__all__ = ["ALL_FIXTURES"]
