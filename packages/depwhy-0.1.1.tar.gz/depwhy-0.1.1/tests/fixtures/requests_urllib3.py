"""Requests/urllib3 conflict fixture: the canonical example from the spec.

User pins urllib3==2.0.0, but requests==2.28.0 requires urllib3>=1.21.1,<1.27.
"""

FIXTURE = {
    "name": "requests_urllib3",
    "description": (
        "Direct pin conflicts with transitive requirement. User pins urllib3==2.0.0, "
        "but requests==2.28.0 requires urllib3>=1.21.1,<1.27. The solution is to "
        "downgrade urllib3 to 1.26.x."
    ),
    "requirements": [
        "requests==2.28.0",
        "urllib3==2.0.0",
    ],
    "expected_conflicts": ["urllib3"],
    "expected_solution_contains": "urllib3==1.26",
    "pypi_responses": {
        "requests": {
            "info": {
                "name": "requests",
                "version": "2.28.0",
                "requires_dist": [
                    "charset-normalizer>=2,<3",
                    "idna>=2.5,<4",
                    "urllib3>=1.21.1,<1.27",
                    "certifi>=2017.4.17",
                    "PySocks>=1.5.6,!=1.5.7 ; extra == 'socks'",
                ],
            },
            "releases": {
                "2.25.0": [{}],
                "2.25.1": [{}],
                "2.26.0": [{}],
                "2.27.0": [{}],
                "2.27.1": [{}],
                "2.28.0": [{}],
                "2.28.1": [{}],
                "2.28.2": [{}],
                "2.29.0": [{}],
                "2.30.0": [{}],
                "2.31.0": [{}],
            },
        },
        "urllib3": {
            "info": {
                "name": "urllib3",
                "version": "2.2.1",
                "requires_dist": [
                    "brotli>=1.0.9 ; platform_python_implementation == 'CPython'",
                    "brotlicffi>=0.8.0 ; platform_python_implementation != 'CPython'",
                    "h2>=4,<5 ; extra == 'h2'",
                    "pysocks>=1.5.6,!=1.5.7,<2.0 ; extra == 'socks'",
                ],
            },
            "releases": {
                "1.21.1": [{}],
                "1.22.0": [{}],
                "1.23.0": [{}],
                "1.24.0": [{}],
                "1.25.0": [{}],
                "1.25.11": [{}],
                "1.26.0": [{}],
                "1.26.7": [{}],
                "1.26.12": [{}],
                "1.26.15": [{}],
                "1.26.18": [{}],
                "2.0.0": [{}],
                "2.0.7": [{}],
                "2.1.0": [{}],
                "2.2.0": [{}],
                "2.2.1": [{}],
            },
        },
        "charset-normalizer": {
            "info": {
                "name": "charset-normalizer",
                "version": "2.1.1",
                "requires_dist": None,
            },
            "releases": {
                "2.0.0": [{}],
                "2.0.12": [{}],
                "2.1.0": [{}],
                "2.1.1": [{}],
            },
        },
        "idna": {
            "info": {
                "name": "idna",
                "version": "3.6",
                "requires_dist": None,
            },
            "releases": {
                "2.5": [{}],
                "2.10": [{}],
                "3.0": [{}],
                "3.4": [{}],
                "3.6": [{}],
            },
        },
        "certifi": {
            "info": {
                "name": "certifi",
                "version": "2024.2.2",
                "requires_dist": None,
            },
            "releases": {
                "2017.4.17": [{}],
                "2020.12.5": [{}],
                "2022.12.7": [{}],
                "2023.7.22": [{}],
                "2024.2.2": [{}],
            },
        },
    },
}
