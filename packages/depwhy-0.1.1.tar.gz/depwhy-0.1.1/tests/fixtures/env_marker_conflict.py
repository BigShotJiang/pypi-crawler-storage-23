"""Environment marker conflict fixture: conflict only on Windows.

Package winapp==1.0.0 requires pywin32>=300,<304 on Windows (sys_platform == 'win32').
Package desktop-notify==1.0.0 also requires pywin32>=304 on Windows.
On Linux/macOS these dependencies are skipped due to markers, so no conflict.
"""

FIXTURE = {
    "name": "env_marker_conflict",
    "description": (
        "A conflict that only manifests on Windows due to environment markers. "
        "winapp requires pywin32>=300,<304 on win32, while desktop-notify requires "
        "pywin32>=304 on win32. On other platforms, both markers evaluate to False "
        "and there is no conflict."
    ),
    "requirements": [
        "winapp==1.0.0",
        "desktop-notify==1.0.0",
    ],
    "expected_conflicts": ["pywin32"],
    "expected_solution_contains": "pywin32",
    "platform": "win32",
    "pypi_responses": {
        "winapp": {
            "info": {
                "name": "winapp",
                "version": "1.0.0",
                "requires_dist": [
                    "pywin32>=300,<304 ; sys_platform == 'win32'",
                    "click>=8.0",
                ],
            },
            "releases": {
                "0.9.0": [{}],
                "1.0.0": [{}],
                "1.1.0": [{}],
            },
        },
        "desktop-notify": {
            "info": {
                "name": "desktop-notify",
                "version": "1.0.0",
                "requires_dist": [
                    "pywin32>=304 ; sys_platform == 'win32'",
                    "dbus-python>=1.2.18 ; sys_platform == 'linux'",
                    "click>=7.0",
                ],
            },
            "releases": {
                "0.8.0": [{}],
                "1.0.0": [{}],
                "1.1.0": [{}],
            },
        },
        "pywin32": {
            "info": {
                "name": "pywin32",
                "version": "306",
                "requires_dist": None,
            },
            "releases": {
                "228": [{}],
                "300": [{}],
                "301": [{}],
                "302": [{}],
                "303": [{}],
                "304": [{}],
                "305": [{}],
                "306": [{}],
            },
        },
        "click": {
            "info": {
                "name": "click",
                "version": "8.1.7",
                "requires_dist": None,
            },
            "releases": {
                "7.0": [{}],
                "7.1.2": [{}],
                "8.0.0": [{}],
                "8.0.4": [{}],
                "8.1.0": [{}],
                "8.1.7": [{}],
            },
        },
    },
}
