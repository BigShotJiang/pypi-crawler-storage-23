"""Django/Celery/Kombu three-way conflict fixture.

Django==4.1, celery==5.2.0, and kombu have incompatible transitive dependencies
on the amqp package. celery==5.2.0 requires kombu>=5.2.0,<5.3.0, and that kombu
requires amqp>=5.0.9,<5.1.0. Meanwhile, the user also pins amqp==5.1.0 which
falls outside kombu's constraint.
"""

FIXTURE = {
    "name": "django_celery_kombu",
    "description": (
        "Three-way conflict between Django==4.1, celery==5.2.0, and kombu. "
        "celery==5.2.0 requires kombu>=5.2.0,<5.3.0, and kombu==5.2.4 requires "
        "amqp>=5.0.9,<5.1.0. User pins amqp==5.1.0 which is outside kombu's "
        "allowed range."
    ),
    "requirements": [
        "django==4.1",
        "celery==5.2.0",
        "amqp==5.1.0",
    ],
    "expected_conflicts": ["amqp"],
    "expected_solution_contains": "amqp==5.0",
    "pypi_responses": {
        "django": {
            "info": {
                "name": "Django",
                "version": "4.1",
                "requires_dist": [
                    "asgiref>=3.5.2,<4",
                    "sqlparse>=0.2.2",
                    "tzdata ; sys_platform == 'win32'",
                ],
            },
            "releases": {
                "3.2": [{}],
                "3.2.20": [{}],
                "4.0": [{}],
                "4.0.10": [{}],
                "4.1": [{}],
                "4.1.13": [{}],
                "4.2": [{}],
                "4.2.9": [{}],
                "5.0": [{}],
            },
        },
        "celery": {
            "info": {
                "name": "celery",
                "version": "5.2.0",
                "requires_dist": [
                    "billiard>=3.6.4,<4.0",
                    "click>=8.0.3,<9.0",
                    "click-didyoumean>=0.0.3",
                    "click-plugins>=1.1.1",
                    "click-repl>=0.2.0",
                    "kombu>=5.2.0,<5.3.0",
                    "pytz>dev",
                    "vine>=5.0.0,<6.0",
                ],
            },
            "releases": {
                "5.0.0": [{}],
                "5.0.5": [{}],
                "5.1.0": [{}],
                "5.1.2": [{}],
                "5.2.0": [{}],
                "5.2.7": [{}],
                "5.3.0": [{}],
                "5.3.6": [{}],
            },
        },
        "kombu": {
            "info": {
                "name": "kombu",
                "version": "5.2.4",
                "requires_dist": [
                    "amqp>=5.0.9,<5.1.0",
                    "vine",
                ],
            },
            "releases": {
                "5.0.0": [{}],
                "5.0.2": [{}],
                "5.1.0": [{}],
                "5.2.0": [{}],
                "5.2.2": [{}],
                "5.2.4": [{}],
                "5.3.0": [{}],
                "5.3.4": [{}],
            },
        },
        "amqp": {
            "info": {
                "name": "amqp",
                "version": "5.1.0",
                "requires_dist": [
                    "vine>=5.0.0,<6.0.0",
                ],
            },
            "releases": {
                "5.0.0": [{}],
                "5.0.6": [{}],
                "5.0.9": [{}],
                "5.1.0": [{}],
                "5.1.1": [{}],
                "5.2.0": [{}],
            },
        },
        "asgiref": {
            "info": {
                "name": "asgiref",
                "version": "3.7.2",
                "requires_dist": None,
            },
            "releases": {
                "3.5.2": [{}],
                "3.6.0": [{}],
                "3.7.0": [{}],
                "3.7.2": [{}],
            },
        },
        "sqlparse": {
            "info": {
                "name": "sqlparse",
                "version": "0.4.4",
                "requires_dist": None,
            },
            "releases": {
                "0.2.2": [{}],
                "0.3.0": [{}],
                "0.4.0": [{}],
                "0.4.4": [{}],
            },
        },
        "billiard": {
            "info": {
                "name": "billiard",
                "version": "3.6.4",
                "requires_dist": None,
            },
            "releases": {
                "3.6.3": [{}],
                "3.6.4": [{}],
            },
        },
        "click": {
            "info": {
                "name": "click",
                "version": "8.1.7",
                "requires_dist": None,
            },
            "releases": {
                "8.0.3": [{}],
                "8.1.0": [{}],
                "8.1.7": [{}],
            },
        },
        "click-didyoumean": {
            "info": {
                "name": "click-didyoumean",
                "version": "0.3.0",
                "requires_dist": [
                    "click>=7",
                ],
            },
            "releases": {
                "0.0.3": [{}],
                "0.3.0": [{}],
            },
        },
        "click-plugins": {
            "info": {
                "name": "click-plugins",
                "version": "1.1.1",
                "requires_dist": [
                    "click>=4.0",
                ],
            },
            "releases": {
                "1.1.1": [{}],
            },
        },
        "click-repl": {
            "info": {
                "name": "click-repl",
                "version": "0.3.0",
                "requires_dist": [
                    "click>=7.0",
                    "prompt-toolkit>=3.0.36",
                ],
            },
            "releases": {
                "0.2.0": [{}],
                "0.3.0": [{}],
            },
        },
        "vine": {
            "info": {
                "name": "vine",
                "version": "5.0.0",
                "requires_dist": None,
            },
            "releases": {
                "5.0.0": [{}],
                "5.1.0": [{}],
            },
        },
        "pytz": {
            "info": {
                "name": "pytz",
                "version": "2023.3",
                "requires_dist": None,
            },
            "releases": {
                "2022.1": [{}],
                "2023.3": [{}],
            },
        },
        "prompt-toolkit": {
            "info": {
                "name": "prompt-toolkit",
                "version": "3.0.43",
                "requires_dist": [
                    "wcwidth",
                ],
            },
            "releases": {
                "3.0.36": [{}],
                "3.0.43": [{}],
            },
        },
        "wcwidth": {
            "info": {
                "name": "wcwidth",
                "version": "0.2.13",
                "requires_dist": None,
            },
            "releases": {
                "0.2.6": [{}],
                "0.2.13": [{}],
            },
        },
    },
}
