"""ML stack conflict fixture: numpy/scipy/scikit-learn version incompatibility.

User pins numpy==1.21.0, but scikit-learn==1.2.0 requires numpy>=1.22.
"""

FIXTURE = {
    "name": "ml_stack_conflict",
    "description": (
        "User pins numpy==1.21.0, but scikit-learn==1.2.0 requires numpy>=1.22.4. "
        "scipy==1.10.0 also requires numpy>=1.19.5 which is satisfied, but the "
        "scikit-learn constraint makes the pin unresolvable."
    ),
    "requirements": [
        "numpy==1.21.0",
        "scipy==1.10.0",
        "scikit-learn==1.2.0",
    ],
    "expected_conflicts": ["numpy"],
    "expected_solution_contains": "numpy==1.2",
    "pypi_responses": {
        "numpy": {
            "info": {
                "name": "numpy",
                "version": "1.26.4",
                "requires_dist": None,
            },
            "releases": {
                "1.19.5": [{}],
                "1.20.0": [{}],
                "1.20.3": [{}],
                "1.21.0": [{}],
                "1.21.6": [{}],
                "1.22.0": [{}],
                "1.22.4": [{}],
                "1.23.0": [{}],
                "1.23.5": [{}],
                "1.24.0": [{}],
                "1.24.4": [{}],
                "1.25.0": [{}],
                "1.25.2": [{}],
                "1.26.0": [{}],
                "1.26.4": [{}],
            },
        },
        "scipy": {
            "info": {
                "name": "scipy",
                "version": "1.10.0",
                "requires_dist": [
                    "numpy>=1.19.5,<1.27.0",
                ],
            },
            "releases": {
                "1.7.0": [{}],
                "1.7.3": [{}],
                "1.8.0": [{}],
                "1.8.1": [{}],
                "1.9.0": [{}],
                "1.9.3": [{}],
                "1.10.0": [{}],
                "1.10.1": [{}],
                "1.11.0": [{}],
                "1.11.4": [{}],
                "1.12.0": [{}],
            },
        },
        "scikit-learn": {
            "info": {
                "name": "scikit-learn",
                "version": "1.2.0",
                "requires_dist": [
                    "numpy>=1.22.4",
                    "scipy>=1.3.2",
                    "joblib>=1.1.1",
                    "threadpoolctl>=2.0.0",
                ],
            },
            "releases": {
                "0.24.2": [{}],
                "1.0.0": [{}],
                "1.0.2": [{}],
                "1.1.0": [{}],
                "1.1.3": [{}],
                "1.2.0": [{}],
                "1.2.2": [{}],
                "1.3.0": [{}],
                "1.3.2": [{}],
                "1.4.0": [{}],
            },
        },
        "joblib": {
            "info": {
                "name": "joblib",
                "version": "1.3.2",
                "requires_dist": None,
            },
            "releases": {
                "1.1.1": [{}],
                "1.2.0": [{}],
                "1.3.0": [{}],
                "1.3.2": [{}],
            },
        },
        "threadpoolctl": {
            "info": {
                "name": "threadpoolctl",
                "version": "3.2.0",
                "requires_dist": None,
            },
            "releases": {
                "2.0.0": [{}],
                "2.2.0": [{}],
                "3.0.0": [{}],
                "3.1.0": [{}],
                "3.2.0": [{}],
            },
        },
    },
}
