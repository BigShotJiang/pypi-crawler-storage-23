# Changelog

All notable changes to this project will be documented in this file.
Format follows [Keep a Changelog](https://keepachangelog.com/).
Versions follow [Semantic Versioning](https://semver.org/).

## [Unreleased]

## [0.1.1] — 2026-03-06
### Fixed
- Graph builder now fetches version-specific metadata from PyPI so pinned packages use the correct dependency constraints instead of the latest release's constraints

## [0.1.0] — 2026-03-06
### Added
- PyPI metadata fetcher with async parallel fetching and disk cache
- Constraint graph builder supporting requirements.txt and pyproject.toml
- Conflict detector using PEP 440 specifier intersection
- Plain-English explanation generator
- Fix ranker: top fix + one alternative, each with pip_command
- CLI with colored terminal output (Rich)
- Python library API: analyze() returning ConflictReport
- JSON output mode (--json)
- 85%+ test coverage with 6 real-world conflict fixtures
