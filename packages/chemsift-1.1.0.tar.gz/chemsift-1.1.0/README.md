# chemsift-cloud

## Commands

- `chemsift-cloud login --api-key <key>`: Store credentials in configuration file
- `chemsift-cloud submit <input-dir>`: Submit input to be processed
- `chemsift-cloud status <job-id>`: Check status of work for a given ID
- `chemsift-cloud download <job-id> <output-dir>`: Download the result of the given job ID
- `chemsift-cloud list`: Get list of job IDs for the user

## Development

This project uses [Poetry](https://python-poetry.org/) for dependency management and packaging.

### Bumping the version

It is possible to bump the version of the project using the `poetry version` command with one of the following values as an argument:

- `patch`
- `minor`
- `major`

### Publishing to PyPI

#### PyPI configuration (just once)

From your [PyPI](https://pypi.org/) account, configure a new [Trusted Publisher](https://pypi.org/manage/project/python-bap/settings/publishing/) by providing the following information:

- Specify Owner
- Specify repository name
- Specify the workflow name

#### Publish a new version

In order to publish a new version to PyPI, all we will need to do is create a new tag with the version number so that it looks like this:

```
cli-vX.X.X
```

> **Important**: The version specified when creating the tag needs to match the one in `pyproject.toml` which is the same one that will be returned when running `poetry version`.
