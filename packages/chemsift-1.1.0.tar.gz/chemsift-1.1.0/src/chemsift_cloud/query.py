import typer
import uuid
import datetime
import json
from typing_extensions import Annotated
from rich import print
from rich.progress import track
from pathlib import Path
from chemsift_cloud import config
from chemsift_cloud.register import get_session

app = typer.Typer()


def discover_s3_prefixes(s3, bucket, prefix):
    """List sub-folder names (one level deep) under a given S3 prefix."""
    paginator = s3.get_paginator('list_objects_v2')
    results = []
    for page in paginator.paginate(Bucket=bucket, Prefix=prefix, Delimiter='/'):
        for folder in page.get('CommonPrefixes', []):
            name = folder['Prefix'].rstrip('/').split('/')[-1]
            results.append(name)
    return results


@app.command()
def query(
    register_job_id: str = typer.Argument(help="Register job ID whose registry_output to query"),
    molecules: Annotated[Path, typer.Option(
        "--molecules", help="Local path to query molecules CSV",
        exists=True, file_okay=True, dir_okay=False, resolve_path=True
    )] = ...,
    yaml: Annotated[Path, typer.Option(
        "--yaml", help="Local path to query YAML config",
        exists=True, file_okay=True, dir_okay=False, resolve_path=True
    )] = ...,
    bucket: str = typer.Option("chemsift-register-pipeline", help="S3 Bucket name"),
    table_name: str = typer.Option("chemsift-jobs", help="DynamoDB Jobs table name"),
):
    """
    Submit a query against a completed register job's registry_output.
    """
    cfg = config.load()
    session = get_session(cfg)
    s3 = session.client('s3')
    db = session.resource('dynamodb')
    table = db.Table(table_name)

    identity_id = cfg['identity_id']

    # Look up source register job
    resp = table.get_item(Key={'user_id': identity_id, 'job_id': register_job_id})
    source_item = resp.get('Item')
    if not source_item:
        print(f"[red]Register job {register_job_id} not found.[/red]")
        raise typer.Exit(code=1)

    if source_item.get('job_type', 'register') != 'register':
        print(f"[red]Job {register_job_id} is not a register job (type: {source_item.get('job_type')}).[/red]")
        raise typer.Exit(code=1)

    if source_item.get('status') != 'SUCCEEDED':
        print(f"[yellow]Warning: source job status is '{source_item.get('status')}'. Proceeding anyway.[/yellow]")

    job_id = str(uuid.uuid4())

    # Upload query inputs to S3
    molecules_key = f"users/{identity_id}/{job_id}/query_input/molecules.csv"
    yaml_key = f"users/{identity_id}/{job_id}/query_input/query.yml"

    print(f"Uploading query inputs for job [blue]{job_id}[/blue]...")
    for local_path, s3_key in track(
        [(str(molecules), molecules_key), (str(yaml), yaml_key)],
        description="Uploading..."
    ):
        s3.upload_file(local_path, bucket, s3_key)

    # Discover feature_spaces from local query YAML
    import yaml as pyyaml
    with open(yaml, 'r') as f:
        query_config = pyyaml.safe_load(f)
        
    rules = query_config.get('rules', [])
    feature_spaces = list(set([rule['feature_space'] for rule in rules]))
    
    registry_output_prefix = f"users/{identity_id}/{register_job_id}/registry_output"
    registry_input_prefix = f"users/{identity_id}/{register_job_id}/registry_input"

    print(f"Discovered feature spaces from query YAML: {feature_spaces}")

    output_prefix = f"users/{identity_id}/{job_id}/query_output"

    # Register in DynamoDB
    table.put_item(Item={
        'user_id': identity_id,
        'job_id': job_id,
        'username': cfg['username'],
        'status': 'SUBMITTED',
        'job_type': 'query',
        'source_job_id': register_job_id,
        'created_at': datetime.datetime.utcnow().isoformat(),
        's3_path': f"s3://{bucket}/{output_prefix}"
    })

    sfn_input = {
        'user_id': identity_id,
        'job_id': job_id,
        's3_bucket': bucket,
        'registry_input_prefix': registry_input_prefix,
        'registry_output_prefix': registry_output_prefix,
        'molecules_key': molecules_key,
        'yaml_key': yaml_key,
        'output_prefix': output_prefix,
        'feature_spaces': [{'name': fs} for fs in feature_spaces],
    }

    # Upload trigger file last — EventBridge watches for this key and invokes the query Lambda
    query_trigger_key = f"users/{identity_id}/{job_id}/query_input/query.json"
    s3.put_object(
        Bucket=bucket,
        Key=query_trigger_key,
        Body=json.dumps(sfn_input),
        ContentType="application/json",
    )

    print(f"[green]Query job submitted![/green]")
    print(f"Job ID: [bold]{job_id}[/bold]")
    print(f"Feature spaces found: {feature_spaces}")
