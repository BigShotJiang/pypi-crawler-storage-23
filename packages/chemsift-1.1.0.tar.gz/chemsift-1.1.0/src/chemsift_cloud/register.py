import typer
import boto3
from rich import print
from rich.progress import track
from chemsift_cloud import config
from pathlib import Path
import uuid
import datetime

app = typer.Typer()

def get_session(cfg):
    """Get temporary AWS credentials from Identity Pool"""
    client = boto3.client('cognito-identity', region_name=cfg['region'])
    resp = client.get_credentials_for_identity(
        IdentityId=cfg['identity_id'],
        Logins={
            f"cognito-idp.{cfg['region']}.amazonaws.com/{cfg['user_pool_id']}": cfg['id_token']
        }
    )
    creds = resp['Credentials']
    return boto3.Session(
        aws_access_key_id=creds['AccessKeyId'],
        aws_secret_access_key=creds['SecretKey'],
        aws_session_token=creds['SessionToken'],
        region_name=cfg['region']
    )

@app.command()
def register(
    input_dir: Path = typer.Argument(
        help="Directory to submit for processing",
        exists=True,
        file_okay=False,
        resolve_path=True
    ),
    bucket: str = typer.Option("chemsift-register-pipeline", help="S3 Bucket name"),
    table_name: str = typer.Option("chemsift-jobs", help="DynamoDB Jobs table name")
):
    """
    Submit input (folder) to S3 and register job in DynamoDB
    """
    cfg = config.load()
    session = get_session(cfg)
    s3 = session.client('s3')
    db = session.resource('dynamodb')
    table = db.Table(table_name)

    job_id = str(uuid.uuid4())
    identity_id = cfg['identity_id']
    username = cfg['username']
    
    # Path: users/{identity_id}/{job_id}/...
    base_path = f"users/{identity_id}/{job_id}"
    input_path = f"{base_path}/registry_input"

    print(f"Registering job [blue]{job_id}[/blue] for user [blue]{username}[/blue]...")

    # Auto-detect if user pointed to parent of registry_input
    if (input_dir / "registry_input").exists() and (input_dir / "registry_input").is_dir():
        print(f"[yellow]Detected 'registry_input' subfolder. using {input_dir}/registry_input as root.[/yellow]")
        upload_root = input_dir / "registry_input"
    else:
        upload_root = input_dir

    # Validate structure
    if not (upload_root / "libraries").exists():
         print(f"[red]Error: 'libraries' folder not found in {upload_root}. Structure should be libraries/ and feature_spaces/.[/red]")
         raise typer.Exit(code=1)

    files = [
        p for p in upload_root.rglob("*")
        if p.is_file() and p.name != ".DS_Store"
    ]

    # 1. Upload files to S3
    for file_path in track(files, description="Uploading files..."):
        relative_path = file_path.relative_to(upload_root)
        s3_key = f"{input_path}/{relative_path}"
        
        with open(file_path, 'rb') as f:
            s3.put_object(
                Bucket=bucket,
                Key=s3_key,
                Body=f
            )

    # 2. Upload trigger file (input.json) if it doesn't exist in the list
    # Assuming input_dir *is* the registry_input content
    trigger_key = f"{input_path}/input.json"
    s3.put_object(
        Bucket=bucket,
        Key=trigger_key,
        Body="{}" # Simple trigger
    )

    # 3. Register job in DynamoDB
    table.put_item(
        Item={
            'user_id': identity_id,
            'job_id': job_id,
            'username': username,
            'status': 'SUBMITTED',
            'job_type': 'register',
            'created_at': datetime.datetime.utcnow().isoformat(),
            's3_path': f"s3://{bucket}/{base_path}"
        }
    )

    print("[green]Job registered successfully![/green]")
    print(f"Job ID: [bold]{job_id}[/bold]")