import typer
import boto3
import requests
import webbrowser
import hashlib
import base64
import secrets
import threading
import json
from urllib.parse import urlparse, parse_qs
from http.server import BaseHTTPRequestHandler, HTTPServer
from rich import print
from chemsift_cloud import config

app = typer.Typer()

# Static configuration for now (could be passed as options)
USER_POOL_ID = "eu-west-1_7ZI3fBR1w" # Placeholder
CLIENT_ID = "71ginl5pbckv6vrfltid7lkimi" # Placeholder
IDENTITY_POOL_ID = "eu-west-1:2d13c2cd-06f1-498b-9fcf-2fa6f345b8b7" # Placeholder
REGION = "eu-west-1"
COGNITO_DOMAIN = "chemsift-register-pipeline-prod.auth.eu-west-1.amazoncognito.com" # Placeholder
CALLBACK_PORT = 53090
CALLBACK_URL = f"http://localhost:{CALLBACK_PORT}/callback"

class OAuthCallbackHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        query_components = parse_qs(urlparse(self.path).query)
        if 'code' in query_components and 'state' in query_components:
            self.server.auth_code = query_components['code'][0]
            self.server.returned_state = query_components['state'][0]
            self.send_response(200)
            self.send_header("Content-type", "text/html")
            self.end_headers()
            self.wfile.write(b"<html><body><h1>Login successful!</h1><p>You can close this window and return to the CLI.</p></body></html>")
        else:
            self.send_response(400)
            self.send_header("Content-type", "text/html")
            self.end_headers()
            self.wfile.write(b"<html><body><h1>Login failed</h1><p>Missing code or state.</p></body></html>")
        
        # Shutdown server after handling request
        threading.Thread(target=self.server.shutdown).start()

    def log_message(self, format, *args):
        # Suppress standard HTTP server logging
        pass

def generate_pkce_pair() -> tuple[str, str]:
    # 64 bytes generates a 86 character url-safe string
    code_verifier = secrets.token_urlsafe(64)
    hashed = hashlib.sha256(code_verifier.encode('utf-8')).digest()
    code_challenge = base64.urlsafe_b64encode(hashed).decode('utf-8').rstrip('=')
    return code_verifier, code_challenge

def decode_jwt_payload(token: str) -> dict:
    parts = token.split('.')
    if len(parts) != 3:
        return {}
    payload_str = parts[1]
    payload_str += '=' * (-len(payload_str) % 4)
    try:
        payload_bytes = base64.urlsafe_b64decode(payload_str)
        return json.loads(payload_bytes.decode('utf-8'))
    except Exception:
        return {}

@app.command()
def login(
    user_pool_id: str = typer.Option(USER_POOL_ID, help="Cognito User Pool ID"),
    client_id: str = typer.Option(CLIENT_ID, help="Cognito App Client ID"),
    identity_pool_id: str = typer.Option(IDENTITY_POOL_ID, help="Cognito Identity Pool ID"),
    region: str = typer.Option(REGION, help="AWS Region"),
    cognito_domain: str = typer.Option(COGNITO_DOMAIN, help="Cognito Domain")
):
    """
    Login using browser-based OAuth 2.0 flow
    """
    code_verifier, code_challenge = generate_pkce_pair()
    state = secrets.token_urlsafe(32)

    auth_url = (
        f"https://{cognito_domain}/login?"
        f"response_type=code&"
        f"client_id={client_id}&"
        f"redirect_uri={CALLBACK_URL}&"
        f"state={state}&"
        f"scope=email+openid+profile&"
        f"code_challenge_method=S256&"
        f"code_challenge={code_challenge}"
    )

    print("[yellow]Opening browser for authentication...[/yellow]")
    webbrowser.open_new(auth_url)

    # Start local server to listen for callback
    server = HTTPServer(('localhost', CALLBACK_PORT), OAuthCallbackHandler)
    server.auth_code = None
    server.returned_state = None
    server.serve_forever()

    if not server.auth_code or not server.returned_state:
        print("[red]Login failed: Did not receive authorization code or state.[/red]")
        raise typer.Exit(code=1)

    if server.returned_state != state:
        print("[red]Login failed: State mismatch. Potential CSRF attack.[/red]")
        raise typer.Exit(code=1)

    print("[green]Authorization code received. Exchanging for tokens...[/green]")

    # Exchange code for tokens
    token_url = f"https://{cognito_domain}/oauth2/token"
    token_data = {
        'grant_type': 'authorization_code',
        'client_id': client_id,
        'code': server.auth_code,
        'redirect_uri': CALLBACK_URL,
        'code_verifier': code_verifier
    }
    
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded'
    }

    token_resp = requests.post(token_url, data=token_data, headers=headers)
    
    if token_resp.status_code != 200:
        print(f"[red]Failed to exchange code for tokens: {token_resp.text}[/red]")
        raise typer.Exit(code=1)

    tokens = token_resp.json()
    id_token = tokens.get('id_token')
    
    if not id_token:
        print("[red]Login failed: Missing id_token in response.[/red]")
        raise typer.Exit(code=1)

    try:
        # Get Identity ID from Identity Pool
        identity_client = boto3.client('cognito-identity', region_name=region)
        id_resp = identity_client.get_id(
            IdentityPoolId=identity_pool_id,
            Logins={
                f'cognito-idp.{region}.amazonaws.com/{user_pool_id}': id_token
            }
        )
        identity_id = id_resp['IdentityId']

        payload = decode_jwt_payload(id_token)
        username = payload.get('email', 'Unknown User')

        # Store configuration
        config_data = {
            "username": username,
            "user_pool_id": user_pool_id,
            "client_id": client_id,
            "identity_pool_id": identity_pool_id,
            "region": region,
            "identity_id": identity_id,
            "id_token": id_token,
            "refresh_token": tokens.get('refresh_token'),
            "cognito_domain": cognito_domain
        }
        
        config.save(config_data)
        print(f"[green]Successfully logged in as {username}[/green]")
        print(f"Identity ID: [blue]{identity_id}[/blue]")

    except Exception as e:
        print(f"[red]Failed to get AWS credentials: {str(e)}[/red]")
        raise typer.Exit(code=1)