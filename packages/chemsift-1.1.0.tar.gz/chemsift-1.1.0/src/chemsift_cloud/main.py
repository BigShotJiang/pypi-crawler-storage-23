import typer
from chemsift_cloud.login import app as login_app
from chemsift_cloud.register import app as register_app
from chemsift_cloud.map import app as map_app
from chemsift_cloud.query import app as query_app
from chemsift_cloud.status import app as status_app
from chemsift_cloud.download import app as download_app
from chemsift_cloud.list import app as list_app

app = typer.Typer(no_args_is_help=True)

app.add_typer(login_app)
app.add_typer(register_app)
app.add_typer(map_app)
app.add_typer(query_app)
app.add_typer(status_app)
app.add_typer(download_app)
app.add_typer(list_app)


if __name__ == "__main__":
    app()
