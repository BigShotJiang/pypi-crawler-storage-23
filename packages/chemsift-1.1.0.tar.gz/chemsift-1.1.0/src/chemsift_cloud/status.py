import typer
from typing_extensions import Annotated
import boto3
from rich import print
from rich.panel import Panel
from chemsift_cloud import config
from chemsift_cloud.register import get_session

app = typer.Typer()


@app.command()
def status(
    job_id: Annotated[str, typer.Argument(help="ID of the job to get the status of")],
    table_name: str = typer.Option("chemsift-jobs", help="DynamoDB Jobs table name")
):
    """
    Check status of a job ID
    """
    cfg = config.load()
    session = get_session(cfg)
    db = session.resource('dynamodb')
    table = db.Table(table_name)

    resp = table.get_item(
        Key={
            'user_id': cfg['identity_id'],
            'job_id': job_id
        }
    )

    item = resp.get('Item')
    if not item:
        print(f"[red]Job {job_id} not found.[/red]")
        return

    source_job_line = ""
    if item.get('source_job_id'):
        source_job_line = f"\n[bold]Source Job:[/bold] {item['source_job_id']}"

    print(Panel(
        f"[bold]Job ID:[/bold] {item['job_id']}\n"
        f"[bold]Type:[/bold] {item.get('job_type', 'register')}\n"
        f"[bold]Status:[/bold] {item.get('status', 'N/A')}"
        f"{source_job_line}\n"
        f"[bold]Created At:[/bold] {item.get('created_at', 'N/A')}\n"
        f"[bold]S3 Path:[/bold] {item.get('s3_path', 'N/A')}",
        title=f"Job Status: {job_id}",
        expand=False
    ))