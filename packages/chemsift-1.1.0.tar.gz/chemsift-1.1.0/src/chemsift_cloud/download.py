import typer
from typing_extensions import Annotated
import boto3
from rich import print
from rich.progress import track
from chemsift_cloud import config
from chemsift_cloud.register import get_session
from pathlib import Path

app = typer.Typer()

@app.command()
def download(
    job_id: Annotated[str, typer.Argument(help="ID of the job to download the results of")],
    output_dir: Annotated[Path, typer.Argument(help="Directory in which to download the job result")],
    bucket: str = typer.Option("chemsift-register-pipeline", help="S3 Bucket name"),
    table_name: str = typer.Option("chemsift-jobs", help="DynamoDB Jobs table name")
):
    """
    Download the result of a given job ID
    """
    cfg = config.load()
    session = get_session(cfg)
    s3 = session.client('s3')
    db = session.resource('dynamodb')
    table = db.Table(table_name)

    # Look up job type from DynamoDB to determine correct S3 prefix
    resp = table.get_item(Key={'user_id': cfg['identity_id'], 'job_id': job_id})
    item = resp.get('Item', {})
    job_type = item.get('job_type', 'register')

    if job_type == 'query':
        prefix = f"users/{cfg['identity_id']}/{job_id}/query_output/"
    elif job_type == 'map':
        source_job_id = item.get('source_job_id', job_id)
        prefix = f"users/{cfg['identity_id']}/{source_job_id}/registry_output/"
    else:
        # register (default)
        prefix = f"users/{cfg['identity_id']}/{job_id}/registry_output/"

    print(f"Downloading results for job [blue]{job_id}[/blue] (type: {job_type})...")

    resp = s3.list_objects_v2(Bucket=bucket, Prefix=prefix)
    
    if 'Contents' not in resp:
        print("[yellow]No results found yet. Job might still be processing or failed.[/yellow]")
        return

    output_dir.mkdir(parents=True, exist_ok=True)

    for obj in track(resp['Contents'], description="Downloading..."):
        s3_key = obj['Key']
        # Remove prefix from local path
        relative_path = s3_key[len(prefix):]
        if not relative_path: continue
        
        local_path = output_dir / relative_path
        local_path.parent.mkdir(parents=True, exist_ok=True)
        
        s3.download_file(bucket, s3_key, str(local_path))

    print(f"[green]Download complete![/green] Results saved to [blue]{output_dir}[/blue]")