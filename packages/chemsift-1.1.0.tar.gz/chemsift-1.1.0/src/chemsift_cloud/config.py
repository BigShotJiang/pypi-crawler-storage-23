import json
from pathlib import Path
import typer
from rich import print

def get_config_path():
    home_dir = Path.home()
    config_file = home_dir / ".chemsift" / "config.json"
    return config_file

def load():
    config_file = get_config_path()
    if not config_file.exists():
        print("[red][bold]Error[/bold]: Configuration not found. Please run [/red][blue]`chemsift-cloud login`[/blue]")
        raise typer.Exit(code=1)
    
    with open(config_file, 'r') as f:
        return json.load(f)

def save(config_data: dict):
    config_file = get_config_path()
    config_file.parent.mkdir(parents=True, exist_ok=True)
    
    with open(config_file, 'w') as f:
        json.dump(config_data, f, indent=4)
    
    print(f"[green]Configuration successfully written to:[/green] [blue]{config_file}[/blue]")

# For backward compatibility / simple check
def check_existance():
    if not get_config_path().exists():
        print("[red][bold]Error[/bold]: Configuration not found. Please run [/red][blue]`chemsift-cloud login`[/blue]")
        raise typer.Exit(code=1)
