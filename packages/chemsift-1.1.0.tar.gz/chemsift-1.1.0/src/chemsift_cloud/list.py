import typer
import boto3
from rich import print
from rich.table import Table
from chemsift_cloud import config
from chemsift_cloud.register import get_session

app = typer.Typer()

@app.command()
def list(table_name: str = typer.Option("chemsift-jobs", help="DynamoDB Jobs table name")):
    """
    Get list of job IDs for the current user
    """
    cfg = config.load()
    session = get_session(cfg)
    db = session.resource('dynamodb')
    table = db.Table(table_name)

    print(f"Retrieving jobs for {cfg['username']}...")

    resp = table.query(
        KeyConditionExpression=boto3.dynamodb.conditions.Key('user_id').eq(cfg['identity_id'])
    )

    items = resp.get('Items', [])
    if not items:
        print("[yellow]No jobs found.[/yellow]")
        return

    table_ui = Table(title="Your Jobs")
    table_ui.add_column("Job ID", style="cyan")
    table_ui.add_column("Type", style="yellow")
    table_ui.add_column("Status", style="green")
    table_ui.add_column("Source Job", style="dim")
    table_ui.add_column("Created At", style="magenta")

    for item in items:
        table_ui.add_row(
            item['job_id'],
            item.get('job_type', 'register'),
            item.get('status', 'N/A'),
            item.get('source_job_id', '-'),
            item.get('created_at', 'N/A')
        )

    print(table_ui)