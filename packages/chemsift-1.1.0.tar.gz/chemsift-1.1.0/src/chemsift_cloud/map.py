import typer
import uuid
import datetime
import json
from rich import print
from chemsift_cloud import config
from chemsift_cloud.register import get_session

app = typer.Typer()


def discover_s3_prefixes(s3, bucket, prefix):
    """List sub-folder names (one level deep) under a given S3 prefix."""
    paginator = s3.get_paginator('list_objects_v2')
    results = []
    for page in paginator.paginate(Bucket=bucket, Prefix=prefix, Delimiter='/'):
        for folder in page.get('CommonPrefixes', []):
            name = folder['Prefix'].rstrip('/').split('/')[-1]
            results.append(name)
    return results


@app.command()
def map(
    register_job_id: str = typer.Argument(help="Register job ID to run mapping on"),
    reference_library: str = typer.Argument(help="Name of the reference library in registry_output"),
    bucket: str = typer.Option("chemsift-register-pipeline", help="S3 Bucket name"),
    table_name: str = typer.Option("chemsift-jobs", help="DynamoDB Jobs table name"),
):
    """
    Trigger the mapped pipeline against a completed register job.
    """
    cfg = config.load()
    session = get_session(cfg)
    s3 = session.client('s3')
    db = session.resource('dynamodb')
    table = db.Table(table_name)

    identity_id = cfg['identity_id']

    # Look up source register job
    resp = table.get_item(Key={'user_id': identity_id, 'job_id': register_job_id})
    source_item = resp.get('Item')
    if not source_item:
        print(f"[red]Register job {register_job_id} not found.[/red]")
        raise typer.Exit(code=1)

    if source_item.get('job_type', 'register') != 'register':
        print(f"[red]Job {register_job_id} is not a register job (type: {source_item.get('job_type')}).[/red]")
        raise typer.Exit(code=1)

    if source_item.get('status') != 'SUCCEEDED':
        print(f"[yellow]Warning: source job status is '{source_item.get('status')}'. Proceeding anyway.[/yellow]")

    # Discover libraries and feature_spaces from registry_output
    registry_output_prefix = f"users/{identity_id}/{register_job_id}/registry_output/"
    libraries = discover_s3_prefixes(s3, bucket, registry_output_prefix)
    feature_spaces_prefix = f"{registry_output_prefix}feature_spaces/"
    feature_spaces = discover_s3_prefixes(s3, bucket, feature_spaces_prefix)

    if not libraries:
        print(f"[red]No libraries found under {registry_output_prefix}. Is the register job complete?[/red]")
        raise typer.Exit(code=1)

    job_id = str(uuid.uuid4())
    output_prefix = f"users/{identity_id}/{register_job_id}/registry_output"

    # Register in DynamoDB
    table.put_item(Item={
        'user_id': identity_id,
        'job_id': job_id,
        'username': cfg['username'],
        'status': 'SUBMITTED',
        'job_type': 'map',
        'source_job_id': register_job_id,
        'created_at': datetime.datetime.utcnow().isoformat(),
        's3_path': f"s3://{bucket}/{output_prefix}"
    })

    sfn_input = {
        'user_id': identity_id,
        'job_id': job_id,
        's3_bucket': bucket,
        'output_prefix': output_prefix,
        'libraries': [{'name': lib} for lib in libraries],
        'feature_spaces': [{'name': fs} for fs in feature_spaces],
        'reference_library': reference_library,
    }

    # Upload trigger file — EventBridge watches for this key and invokes the map Lambda
    map_trigger_key = f"users/{identity_id}/{job_id}/map_input/map.json"
    s3.put_object(
        Bucket=bucket,
        Key=map_trigger_key,
        Body=json.dumps(sfn_input),
        ContentType="application/json",
    )

    print(f"[green]Map job submitted![/green]")
    print(f"Job ID: [bold]{job_id}[/bold]")
    print(f"Libraries to map: {libraries}")
    print(f"Reference library: {reference_library}")
