def a():
    g = turtle.numinput("to start the game follow the instructions below:",
                        "if you want to play with a friend press 2 and you on the arous and your friend in w,s,d,a if not press 1")
    if g == 1:
        game1()
    elif g == 2:
        game()
    else:
        exit()
import turtle
import random
import time

screen = turtle.Screen()
screen.title("welcome to the game")
screen.setup(800, 600)
screen.bgcolor("lightblue")



def game():
    screen = turtle.Screen()
    screen.title("two player mod")
    screen.setup(800, 600)
    screen.bgcolor("lightblue")


    pen = turtle.Turtle()
    pen.hideturtle()
    pen.penup()
    pen.goto(0, 200)

    t = turtle.numinput("time to the play", "how much seconds do you want to play?")

    r = 1
    r2 = 1

    def timer():
        nonlocal t
        if t >= 0:
            pen.clear()
            pen.write(int(t), align="center", font=("Arial", 20, "normal"))
            t -= 1
            turtle.ontimer(timer, 1000)
        else:
            pen.clear()
            if r > r2:
                pen.write("the red turtle win", align="center", font=("Arial", 20, "normal"))
            elif r < r2:
                pen.write("the blue turtle win", align="center", font=("Arial", 20, "normal"))
            else:
                pen.write("draw", align="center", font=("Arial", 20, "normal"))




    player = turtle.Turtle()
    player.shapesize(r)
    player2 = turtle.Turtle()
    player2.shapesize(r2)
    player2.penup()
    DVD = turtle.Turtle()
    player.shape("turtle")
    player.color("red")
    player2.shape("turtle")
    player2.color("blue")
    DVD.shape("circle")
    DVD.penup()
    DVD.setheading(46)
    l = 0
    timer()
    xcor = 0
    ycor = 0
    player.penup()
    x = random.randint(-255, 255)
    y = random.randint(-255, 255)
    player.goto(x, y)
    x2 = random.randint(-255, 255)
    y2 = random.randint(-255, 255)
    player2.goto(x2, y2)


    def go_right():
        player.setheading(180)
        player.forward(10)


    def go_left():
        player.setheading(0)
        player.forward(10)


    def go_up():
        player.setheading(90)
        player.forward(10)


    def go_down():
        player.setheading(270)
        player.forward(10)


    def go_right2():
        player2.setheading(180)
        player2.forward(10)


    def go_left2():
        player2.setheading(0)
        player2.forward(10)


    def go_up2():
        player2.setheading(90)
        player2.forward(10)


    def go_down2():
        player2.setheading(270)
        player2.forward(10)
    COOLDOWN_TIME = 10.0
    DASH_DISTANCE = 50
    player1_last_dash_time = 0.0
    player2_last_dash_time = 0.0
    def dash_p1():
        nonlocal player1_last_dash_time
        current_time = time.time()
        if current_time >= player1_last_dash_time + COOLDOWN_TIME:
            player.forward(DASH_DISTANCE)
            player1_last_dash_time = current_time
    def dash_p2():
        nonlocal player2_last_dash_time
        current_time = time.time()
        if current_time >= player2_last_dash_time + COOLDOWN_TIME:
            player2.forward(DASH_DISTANCE)
            player2_last_dash_time = current_time


    turtle.listen()
    turtle.onkey(go_right, 'a' or 'A')
    turtle.onkey(go_left, 'd' or 'D')
    turtle.onkey(go_up, 'w' or 'W' )
    turtle.onkey(go_down, 's'or 'S')
    turtle.onkey(go_up2, 'Up')
    turtle.onkey(go_down2, 'Down')
    turtle.onkey(go_right2, 'Left')
    turtle.onkey(go_left2, 'Right')
    turtle.onkey(dash_p1, 'x' or 'X')
    turtle.onkey(dash_p2,'m' or 'M')
    while l == 0:
        while DVD.xcor() <= 400 and DVD.xcor() >= -400 and DVD.ycor() <= 300 and DVD.ycor() >= -300:
            DVD.forward(3)
            if player.distance(DVD) <= 20:
                r += 0.5
                player.shapesize(r)
                player.goto(0, 0)
            if player2.distance(DVD) <= 20:
                r2 += 0.5
                player2.shapesize(r2)
                player2.goto(0, 0)
        # FIXED: Standard bounce logic (replacing complex original logic)
        # Check boundaries: 400 for X, 300 for Y (800x600 screen size)
        if abs(DVD.xcor()) > 390:
            DVD.setheading(180 - DVD.heading())
            DVD.setx(390 if DVD.xcor() > 0 else -390)
            screen.update()

        if abs(DVD.ycor()) > 290:
            DVD.setheading(360 - DVD.heading())
            DVD.sety(290 if DVD.ycor() > 0 else -290)

        screen.update()

    screen.update()
    turtle.mainloop()
def game1():
    screen = turtle.Screen()
    screen.setup(800, 600)
    screen.title("one player mod")
    screen.bgcolor("lightblue")
    pen = turtle.Turtle()
    pen.hideturtle()
    pen.penup()

    r = 1
    w = 0
    pen.goto(0, 200)
    pen.write(f"your score is {w}",align="center", font=("Arial", 20, "normal") )

    player = turtle.Turtle()
    player.shapesize(r)

    DVD = turtle.Turtle()
    player.shape("turtle")
    player.color("blue")
    DVD.shape("circle")
    DVD.penup()
    DVD.setheading(46)
    l = 0

    xcor = 0
    ycor = 0
    player.penup()
    x = random.randint(-255, 255)
    y = random.randint(-255, 255)
    player.goto(x, y)



    def go_right():
        player.setheading(180)
        player.forward(10)


    def go_left():
        player.setheading(0)
        player.forward(10)


    def go_up():
        player.setheading(90)
        player.forward(10)


    def go_down():
        player.setheading(270)
        player.forward(10)
    def p1_shrink():

        nonlocal r
        if r >= 3.0:
            r -= 1.0
            player.shapesize(r)
    COOLDOWN_TIME = 10.0
    DASH_DISTANCE = 50
    player1_last_dash_time = 0.0
    def dash_p1():
        nonlocal player1_last_dash_time
        current_time = time.time()
        if current_time >= player1_last_dash_time + COOLDOWN_TIME:
            player.forward(DASH_DISTANCE)
            player1_last_dash_time = current_time
    turtle.listen()
    turtle.onkey(go_right, 'a')
    turtle.onkey(go_left, 'd')
    turtle.onkey(go_up, 'w')
    turtle.onkey(go_down, 's')
    turtle.onkey(go_up, 'Up')
    turtle.onkey(go_down, 'Down')
    turtle.onkey(go_right, 'Left')
    turtle.onkey(go_left, 'Right')
    turtle.onkey(p1_shrink, 'r')
    turtle.onkey(dash_p1, 'x' or 'X')

    while l == 0:
        while DVD.xcor() <= 400 and DVD.xcor() >= -400 and DVD.ycor() <= 300 and DVD.ycor() >= -300:
            DVD.forward(3)
            if player.distance(DVD) <= 20:
                r += 0.5
                w+=1
                player.shapesize(r)
                player.goto(0, 0)
                pen.goto(0, 200)
                pen.clear()
                pen.write(f"your score is {w}", align="center", font=("Arial", 20, "normal"))

        if abs(DVD.xcor()) > 390:
            DVD.setheading(180 - DVD.heading())
            DVD.setx(390 if DVD.xcor() > 0 else -390)

        if abs(DVD.ycor()) > 290:
            DVD.setheading(360 - DVD.heading())
            DVD.sety(290 if DVD.ycor() > 0 else -290)
def f():
    fu = 3
    if fu >= 0:
        turtle.clear()
        turtle.write(int(fu), align="center", font=("Arial", 20, "normal"))
        fu -= 1
        turtle.ontimer(f,1000)
def h():
    turtle.write("that not a option")
    v = turtle.textinput("do you want to play again?","do you want to choose the game again?")
    if v == "yes" or v == "Yes" or v == "YES" or v == "Y":
        g = turtle.numinput("to start the game follow the instructions below:","if you want to play with a friend press 2 and you on the arous and your friend in w,s,d,a if not press 1")
        if g == 1:
            game1()
        elif g == 2:
            game()
    screen.update()
    turtle.mainloop()
def b():
    import turtle
    import random

    # --- הכנות למסך ---
    screen = turtle.Screen()
    screen.setup(800, 600)
    screen.bgcolor("white")
    screen.title("איש תלוי - מספרים")

    pen = turtle.Turtle()
    pen.hideturtle()
    pen.speed(0)

    # --- ציור הגרדום ---
    def draw_gallows():
        pen.pensize(5)
        pen.penup()
        pen.goto(-200, -150)
        pen.pendown()
        pen.forward(150)
        pen.backward(75)
        pen.left(90)
        pen.forward(250)
        pen.right(90)
        pen.forward(120)
        pen.right(90)
        pen.forward(40)

    # --- חלקי האיש ---
    def draw_head():
        pen.penup()
        pen.goto(-55, 40)
        pen.pendown()
        pen.circle(25)

    def draw_body():
        pen.penup()
        pen.goto(-55, 40)
        pen.setheading(270)
        pen.pendown()
        pen.forward(80)

    def draw_left_arm():
        pen.penup()
        pen.goto(-55, 10)
        pen.setheading(180)
        pen.pendown()
        pen.forward(40)

    def draw_right_arm():
        pen.penup()
        pen.goto(-55, 10)
        pen.setheading(0)
        pen.pendown()
        pen.forward(40)

    def draw_left_leg():
        pen.penup()
        pen.goto(-55, -40)
        pen.setheading(225)
        pen.pendown()
        pen.forward(50)

    def draw_right_leg():
        pen.penup()
        pen.goto(-55, -40)
        pen.setheading(315)
        pen.pendown()
        pen.forward(50)

    body_parts = [
        draw_head, draw_body, draw_left_arm,
        draw_right_arm, draw_left_leg, draw_right_leg
    ]

    # --- יצירת מספר סודי ---
    secret = str(random.randint(1000, 9999))
    display = ["_"] * 4
    wrong = 0

    # --- רשימת ניחושים ---
    guesses = []

    # --- פונקציה לעדכון המסך ---
    guesses_pen = turtle.Turtle()
    guesses_pen.hideturtle()
    guesses_pen.penup()
    guesses_pen.goto(0, 200)

    def update_display():
        guesses_pen.clear()
        guesses_pen.write("ניחושים: " + " ".join(display),
                          align="center",
                          font=("Arial", 30, "bold"))

    update_display()
    draw_gallows()

    # --- פונקציה לניחוש ספרה ---
    def guess_number(n):
        global wrong
        if n in secret:
            for i in range(4):
                if secret[i] == n:
                    display[i] = n
        else:
            if wrong < len(body_parts):
                body_parts[wrong]()
            wrong += 1

        guesses.append(n)
        update_display()

        # בדיקת ניצחון
        if "".join(display) == secret:
            guesses_pen.goto(0, -200)
            guesses_pen.write("ניצחת! המספר הוא " + secret,
                              align="center",
                              font=("Arial", 20, "bold"))
            return

        # בדיקת הפסד
        if wrong == len(body_parts):
            guesses_pen.goto(0, -200)
            guesses_pen.write("הפסדת! המספר היה " + secret,
                              align="center",
                              font=("Arial", 20, "bold"))
            return

    screen.listen()
    for i in range(10):
        screen.onkey(lambda i=i: guess_number(str(i)), str(i))

    turtle.mainloop()
def c():
    import time
    import turtle
    import random
    sc = turtle.Screen()
    sc.bgcolor("yellow")
    sc.setup(width=800, height=600)
    ans1 = turtle.Turtle()
    ans2 = turtle.Turtle()
    ans3 = turtle.Turtle()
    Question = turtle.Turtle()
    score = turtle.Turtle()
    score.penup()
    score.goto(380, 260)
    score.shape("blank")
    for t in [ans1, ans2, ans3, Question]:
        t.penup()
        t.hideturtle()
    Question.goto(0, 270)
    value1 = 0
    value2 = 0
    value3 = 0
    wrans = 0
    s = 0
    turtle.listen()
    turtle.onkey(breakpoint, "q" or "Q" or "escape" or "/")

    def start():
        sc.onclick(check_click)
        up()
        turtle.mainloop()

    def up():
        ans1, ans2, ans3.clear()
        ans1.setposition(80, 200)
        ans2.setposition(0, 200)
        ans3.setposition(-80, 200)
        time.sleep(1)
        new_round()

    def new_round():

        global value1, value2, value3, wrans

        ans1, ans2, ans3.clear()
        Question.clear()

        num1 = random.randint(1, 1000)
        num2 = random.randint(1, 1000)
        m = random.randint(1, 4)

        if m == 1:
            ans = num1 + num2
            p = "+"
        elif m == 2:
            ans = num1 - num2
            p = "-"
        elif m == 3:
            ans = num1 * num2
            p = "x"
        else:
            ans = num1 // num2
            p = ":"

        wrans = random.randint(1, 3)

        if wrans == 1:
            value1 = ans
            value2 = random.randint(1, 1000)
            value3 = random.randint(1, 1000)
        elif wrans == 2:
            value2 = ans
            value1 = random.randint(1, 1000)
            value3 = random.randint(1, 1000)
        else:
            value3 = ans
            value1 = random.randint(1, 1000)
            value2 = random.randint(1, 1000)
        Question.write(f"{num1} {p} {num2}", align="center", font=("Arial", 20, "bold"))
        move()

    def move():
        ans1.clear()
        ans2.clear()
        ans3.clear()
        time.sleep(0.05)
        ans1.goto(ans1.xcor(), ans1.ycor() - 10)
        ans2.goto(ans2.xcor(), ans2.ycor() - 10)
        ans3.goto(ans3.xcor(), ans3.ycor() - 10)

        ans1.write(value1, align="center", font=("Arial", 18, "bold"))
        ans2.write(value2, align="center", font=("Arial", 18, "bold"))
        ans3.write(value3, align="center", font=("Arial", 18, "bold"))

        if ans1.ycor() > -190:
            sc.ontimer(move, 50)
        else:
            Question.clear()
            Question.write("You lose", align="center", font=("Arial", 20, "bold"))
            ans1, ans2, ans3.clear()
            breakpoint()

    def check_click(x, y):
        global wrans
        global ans1, ans2, ans3
        clicked = None
        if ans1.distance(x, y) < 30:
            clicked = 1
        elif ans2.distance(x, y) < 30:
            clicked = 2
        elif ans3.distance(x, y) < 30:
            clicked = 3

        if clicked == wrans:
            Question.clear()
            ans1, ans2, ans3.clear()
            Question.write("Correct!", align="center", font=("Arial", 20, "bold"))
            global s, score
            s = s + 1
            score.clear()
            score.write(f"{s}", align="center", font=("Arial", 20, "bold"))
            up()
        elif clicked is not None:
            Question.clear()
            Question.write("game over!", align="center", font=("Arial", 20, "bold"))
            ans1, ans2, ans3.clear()
            breakpoint()

    start()
def d():
    import turtle

    sc = turtle.Screen()
    sc.bgcolor("lightblue")
    sc.setup(width=800, height=600)
    sc.title("Ping Pong")
    sc.tracer(0)

    mode = sc.textinput("Game Mode", "Type '1' for Bot or '2' for Multiplayer:")
    is_bot_mode = (mode == "1")

    pen = turtle.Turtle()
    pen.speed(0)
    pen.color("black")
    pen.penup()
    pen.hideturtle()
    pen.goto(0, 260)

    def create_paddle(x_pos):
        paddle = turtle.Turtle()
        paddle.shape("square")
        paddle.color("white")
        paddle.shapesize(stretch_wid=5, stretch_len=1)
        paddle.penup()
        paddle.goto(x_pos, 0)
        return paddle

    player1 = create_paddle(370)
    player2 = create_paddle(-370)

    ball = turtle.Turtle()
    ball.shape("circle")
    ball.color("black")
    ball.penup()
    ball.dx = 0.1
    ball.dy = 0.1

    def p1_up():
        player1.sety(player1.ycor() + 25)

    def p1_down():
        player1.sety(player1.ycor() - 25)

    def p2_up():
        if not is_bot_mode:
            player2.sety(player2.ycor() + 25)

    def p2_down():
        if not is_bot_mode:
            player2.sety(player2.ycor() - 25)

    sc.listen()
    sc.onkeypress(p1_up, "Up")
    sc.onkeypress(p1_down, "Down")
    sc.onkeypress(p2_up, "w")
    sc.onkeypress(p2_down, "s")

    while True:
        sc.update()

        ball.setx(ball.xcor() + ball.dx)
        ball.sety(ball.ycor() + ball.dy)

        if is_bot_mode:
            if player2.ycor() < ball.ycor() - 10:
                player2.sety(player2.ycor() + 0.25)
            elif player2.ycor() > ball.ycor() + 10:
                player2.sety(player2.ycor() - 0.25)

        if abs(ball.ycor()) > 290:
            ball.sety(290 if ball.ycor() > 0 else -290)
            ball.dy *= -1

        if ball.xcor() > 390 or ball.xcor() < -390:
            winner = "Player 2" if ball.xcor() > 390 else "Player 1"
            pen.write(f"{winner} wins!", align="center", font=("Arial", 24, "bold"))
            sc.update()

            ball.goto(0, 0)
            ball.dx *= -1
            import time

            time.sleep(1)
            pen.clear()

        # Paddle Collisions
        if (ball.xcor() > 350 and ball.xcor() < 370) and (ball.distance(player1) < 50):
            ball.setx(350)
            ball.dx *= -1

        if (ball.xcor() < -350 and ball.xcor() > -370) and (ball.distance(player2) < 50):
            ball.setx(-350)
            ball.dx *= -1