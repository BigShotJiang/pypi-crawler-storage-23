import turtle
import random
import time

sc = turtle.Screen()
sc.setup(800,600)
sc.bgcolor("white")
sc.title("turtle race")

player1 = turtle.Turtle()
player2 = turtle.Turtle()
player3 = turtle.Turtle()
player4 = turtle.Turtle()
finsh = turtle.Turtle()
player1.shape("turtle")
player2.shape("turtle")
player3.shape("turtle")
player4.shape("turtle")
finsh.shape("blank")
player1.penup()
player2.penup()
player3.penup()
player4.penup()
finsh.penup()
player1.color("red")
player2.color("blue")
player3.color("green")
player4.color("yellow")

finsh.goto(250,150)
finsh.pendown()
finsh.right(90)
finsh.forward(300)
finsh.penup()

go = random.randint(-290,150)
player1.goto(go,150)
player2.goto(go,75)
player3.goto(go,-75)
player4.goto(go,-150)

dis = random.randint(1,10)
dis2 = random.randint(1,10)
dis3 = random.randint(1,10)
dis4 = random.randint(1,10)
while player1.xcor() <= 250 and 250 >= player2.xcor() and 250 >= player3.xcor() and 250 >= player4.xcor():
    player1.forward(dis),player2.forward(dis2),player3.forward(dis3),player4.forward(dis4)
    dis = random.randint(1,10)
    dis2 = random.randint(1,10)
    dis3 = random.randint(1,10)
    dis4 = random.randint(1,10)
    if dis == 1:
        player1.speed(1)
    if dis2 == 1:
        player2.speed(1)
    if dis == 2:
        player1.speed(2)
    if dis2 == 2:
        player2.speed(2)
    if dis == 3:
        player1.speed(3)
    if dis2 == 3:
        player2.speed(3)
    if dis == 4:
        player1.speed(4)
    if dis2 == 4:
        player2.speed(4)
    if dis == 5:
        player1.speed(5)
    if dis2 == 5:
        player2.speed(5)
    if dis == 6:
        player1.speed(6)
    if dis2 == 2:
        player2.speed(6)
    if dis == 7:
        player1.speed(7)
    if dis2 == 7:
        player2.speed(7)
    if dis == 8:
        player1.speed(8)
    if dis2 == 8:
        player2.speed(8)
    if dis == 9:
        player1.speed(9)
    if dis == 9:
        player2.speed(9)
    if dis == 10:
        player1.speed(10)
    if dis == 10:
        player1.speed(10)
    if dis3 == 1:
        player3.speed(1)
    if dis4 == 1:
        player4.speed(1)
    if dis3 == 2:
        player3.speed(2)
    if dis4 == 2:
        player4.speed(2)
    if dis3 == 3:
        player3.speed(3)
    if dis4 == 3:
        player4.speed(3)
    if dis4 == 4:
        player4.speed(4)
    if dis3 == 4:
        player3.speed(4)
    if dis3 == 5:
        player3.speed(5)
    if dis4 == 5:
        player4.speed(5)
    if dis4 == 6:
        player4.speed(6)
    if dis3 == 6:
        player3.speed(6)
    if dis3 == 7:
        player3.speed(7)
    if dis4 == 7:
        player4.speed(7)
    if dis4 == 8:
        player4.speed(8)
    if dis3 == 8:
        player3.speed(8)
    if dis3 == 9:
        player3.speed(9)
    if dis4 == 9:
        player4.speed(9)
    if dis4 == 10:
        player4.speed(10)
    if dis3 == 10:
        player3.speed(10)

disf =250 - player1.xcor()
disf2 =250 - player2.xcor()
disf3 =250 - player3.xcor()
disf4 =250 - player4.xcor()
results = [
    (disf, "אדום"),
    (disf2, "כחול"),
    (disf3, "ירוק"),
    (disf4, "צהוב")
]
results.sort(reverse=True)
turtle.shape("blank")
turtle.write(
    f"מקום 1: {results[0][1]} \n"
    f"מקום 2: {results[1][1]} \n"
    f"מקום 3: {results[2][1]} \n"
    f"מקום 4: {results[3][1]} "
            )
time.sleep(3)
exit()
