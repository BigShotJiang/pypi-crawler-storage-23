"""Allow running smartmcp as `python -m smartmcp`."""

from smartmcp.cli import main

main()
