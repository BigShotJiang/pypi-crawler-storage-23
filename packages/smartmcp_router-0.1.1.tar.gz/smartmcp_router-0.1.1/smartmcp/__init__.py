"""smartmcp — Intelligent MCP tool routing to reduce context bloat."""

__version__ = "0.1.1"
