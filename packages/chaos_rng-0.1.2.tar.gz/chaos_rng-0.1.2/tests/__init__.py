"""Test suite for chaos-rng library."""
