from smartmemory_pkg.cli import cli

if __name__ == "__main__":
    cli()
