"""MCP (Model Context Protocol) integration for OpenMetadata tools."""
