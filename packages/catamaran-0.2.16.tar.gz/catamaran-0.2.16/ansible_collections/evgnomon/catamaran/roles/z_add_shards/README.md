# z\_add\_shards

Dynamically add shards to the group "shards".
