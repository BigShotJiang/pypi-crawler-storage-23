# z\_sshadd

Add local ssh key to be used by Ansible connecting to remote hosts.

## Example Playbook

```yaml
- hosts: shards
  roles:
    - role: z_sshadd
```
