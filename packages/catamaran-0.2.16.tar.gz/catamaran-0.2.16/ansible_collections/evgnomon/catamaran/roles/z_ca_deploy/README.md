# z\_ca\_deploy Role

Deploy the CA (public) certificate to the host.

```yaml
- hosts: all
  roles:
    - role: z_ca_deploy
```
