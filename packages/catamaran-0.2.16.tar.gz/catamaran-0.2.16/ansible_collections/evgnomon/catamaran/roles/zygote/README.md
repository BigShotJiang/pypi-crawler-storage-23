# zygote Role

Runs zygote containers and initializes the zygote environment.

## Requirements

- Ansible 2.9 or higher
- Supported platforms:
  - EL 7
  - EL 8

## Role Variables


## Example Playbook

```yaml
- hosts: all
  roles:
    - role: zygote
```
