# z\_lib\_var

Setup directories in /var/lib.

## Example Playbook

```yaml
- hosts: shards
  roles:
    - role: z_lib_var
```
