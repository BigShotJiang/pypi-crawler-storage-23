from . import models
from .hooks import update_oca_repositories
