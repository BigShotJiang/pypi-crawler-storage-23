"""Plan definitions shared across the LLMHosts proxy."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class PlanLimits:
    """Rate and feature limits for a subscription plan."""

    rpm: int  # requests per minute (0 = unlimited)
    devices: int  # max registered devices (0 = unlimited)
    tunnel_public: bool
    hive_mode: bool
    rbac: bool
    cloud_dashboard: bool


PLANS: dict[str, PlanLimits] = {
    "free": PlanLimits(rpm=60, devices=1, tunnel_public=False, hive_mode=False, rbac=False, cloud_dashboard=False),
    "pro": PlanLimits(rpm=300, devices=5, tunnel_public=True, hive_mode=False, rbac=False, cloud_dashboard=True),
    "team": PlanLimits(rpm=600, devices=25, tunnel_public=True, hive_mode=True, rbac=True, cloud_dashboard=True),
    "enterprise": PlanLimits(rpm=0, devices=0, tunnel_public=True, hive_mode=True, rbac=True, cloud_dashboard=True),
}


def get_plan_limits(plan: str) -> PlanLimits:
    """Return limits for *plan*, falling back to free if unknown."""
    return PLANS.get(plan, PLANS["free"])
