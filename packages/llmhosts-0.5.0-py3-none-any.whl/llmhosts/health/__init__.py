"""LLMHosts health monitoring -- continuous backend health checks and alerting."""

from __future__ import annotations

from llmhosts.health.alerting import AlertEvaluator, AlertResult, AlertRule, AlertState
from llmhosts.health.monitor import BackendHealth, HealthCheck, HealthMonitor
from llmhosts.health.notifications import ConsoleChannel, NotificationRouter, WebhookChannel

__all__ = [
    "AlertEvaluator",
    "AlertResult",
    "AlertRule",
    "AlertState",
    "BackendHealth",
    "ConsoleChannel",
    "HealthCheck",
    "HealthMonitor",
    "NotificationRouter",
    "WebhookChannel",
]
