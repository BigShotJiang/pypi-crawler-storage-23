"""Allow running llmhost as a module: python -m llmhost."""

from __future__ import annotations

from llmhosts.cli import main

main()
