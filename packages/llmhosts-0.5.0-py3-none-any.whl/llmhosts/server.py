"""LLMHosts server orchestrator -- wires all components and runs uvicorn.

The :class:`LLMHostsServer` is created by ``llmhost serve`` and manages
the full lifecycle: config loading, Ollama discovery, hardware detection,
router/cache initialisation, FastAPI app creation, and uvicorn execution.
"""

from __future__ import annotations

import logging
import socket
from typing import TYPE_CHECKING, Any

import uvicorn
from pydantic import BaseModel, Field

if TYPE_CHECKING:
    from fastapi import FastAPI

    from llmhosts.config import LLMHostsConfig

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Startup report
# ---------------------------------------------------------------------------


class StartupReport(BaseModel):
    """Report of what was discovered / initialised at startup."""

    ollama_available: bool = False
    ollama_models: list[str] = Field(default_factory=list)
    cloud_providers: list[str] = Field(default_factory=list)
    hardware_summary: str = ""
    router_tier: str = "Rule-based (Tier 0)"
    cache_tier: str = "Exact hash"
    lan_nodes: int = 0
    lan_discovery: bool = False
    endpoints: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Server orchestrator
# ---------------------------------------------------------------------------


class LLMHostsServer:
    """Orchestrates all LLMHosts components for the ``serve`` command."""

    def __init__(self, config: LLMHostsConfig) -> None:
        self.config = config
        self._app: FastAPI | None = None
        self._report: StartupReport | None = None
        self._mdns: Any = None  # MDNSDiscovery instance (lazy)

    # -- public API --------------------------------------------------------

    @staticmethod
    def read_only_notice() -> str:
        """Return the read-only guarantee notice for display."""
        return (
            "READ-ONLY MODE: LLMHosts discovers and uses existing inference "
            "engines but never modifies their configuration, installs models, "
            "or changes system settings."
        )

    async def startup(self) -> StartupReport:
        """Initialise all components and return a :class:`StartupReport`.

        Steps:
        1. Ensure data directory exists
        2. Discover Ollama (if ``auto_discover=True``)
        3. Detect hardware
        4. Enumerate BYOK cloud keys
        5. Determine router / cache tiers
        6. Create FastAPI app
        7. Return report
        """
        from llmhosts.config import llmhosts_dir

        report = StartupReport()
        warnings: list[str] = []

        logger.info(
            "LLMHosts operates in READ-ONLY mode: we discover and use existing "
            "inference engines (Ollama, vLLM, etc.) but never modify their "
            "configuration, install models, or change system settings."
        )

        # 1. Data directory
        data_dir = llmhosts_dir()
        logger.debug("Data directory: %s", data_dir)

        # 2. Ollama discovery
        if self.config.ollama.auto_discover:
            report = await self._discover_ollama(report, warnings)
        else:
            warnings.append("Ollama auto-discovery disabled in config")

        # 3. Hardware detection
        report = await self._detect_hardware(report)

        # 3b. LAN discovery (mDNS background)
        report = await self._start_lan_discovery(report, warnings)

        # 4. BYOK cloud keys
        report = self._enumerate_cloud_keys(report, warnings)

        # 5. Router tier
        report = self._determine_router_tier(report)

        # 6. Cache tier
        report = self._determine_cache_tier(report)

        # 7. Endpoints
        report.endpoints = self._list_endpoints()

        # Final warning check
        if not report.ollama_available and not report.cloud_providers:
            warnings.append("No backends available — add Ollama models or BYOK cloud keys")

        report.warnings = warnings
        self._report = report

        # 8. Observability (Sentry + structured logging)
        from llmhosts.observability import init_observability

        init_observability(self.config.observability)

        # 9. Create FastAPI app
        self._app = self._create_app()

        return report

    def run(self) -> None:
        """Start the uvicorn server. This is a **blocking** call."""
        if self._app is None:
            raise RuntimeError("Call startup() before run()")

        log_level = self.config.server.log_level.lower()

        uvicorn.run(
            self._app,
            host=self.config.server.host,
            port=self.config.server.port,
            workers=self.config.server.workers,
            log_level=log_level,
            access_log=log_level == "debug",
        )

    async def shutdown(self) -> None:
        """Clean shutdown of all components."""
        if self._mdns is not None:
            await self._mdns.stop()
        logger.info("LLMHosts server shutting down")

    # -- internal helpers --------------------------------------------------

    async def _discover_ollama(self, report: StartupReport, warnings: list[str]) -> StartupReport:
        """Probe the Ollama instance for availability and installed models."""
        from llmhosts.discovery.ollama import OllamaDiscovery

        async with OllamaDiscovery(
            host=self.config.ollama.host,
            timeout=min(self.config.ollama.timeout, 10.0),  # quick probe at startup
        ) as ollama:
            available = await ollama.is_available()
            report.ollama_available = available
            if available:
                models = await ollama.list_models()
                report.ollama_models = [m.name for m in models]
                if not models:
                    warnings.append("Ollama is running but has no models installed")
            else:
                warnings.append(
                    f"Ollama not reachable at {self.config.ollama.host} — "
                    "install from https://ollama.com or set [ollama] host"
                )
        return report

    async def _detect_hardware(self, report: StartupReport) -> StartupReport:
        """Run hardware detection and build a human-readable summary."""
        try:
            from llmhosts.discovery.hardware import HardwareDetector

            hw = await HardwareDetector.detect()
            parts: list[str] = []
            if hw.gpus:
                for gpu in hw.gpus:
                    vram_gb = round(gpu.vram_total_mb / 1024, 1)
                    parts.append(f"{gpu.name} ({vram_gb}GB)")
            ram_str = f"{hw.ram_total_gb:.0f}GB RAM"
            if parts:
                report.hardware_summary = ", ".join(parts) + f", {ram_str}"
            else:
                report.hardware_summary = f"CPU only, {ram_str}"
        except Exception as exc:
            logger.debug("Hardware detection failed: %s", exc)
            report.hardware_summary = "detection failed"
        return report

    async def _start_lan_discovery(self, report: StartupReport, warnings: list[str]) -> StartupReport:
        """Start mDNS advertising and browsing in the background."""
        try:
            from llmhosts.discovery.mdns import MDNSDiscovery

            mdns = MDNSDiscovery()
            if not mdns.is_available:
                logger.debug("zeroconf not installed -- LAN discovery skipped")
                return report

            gpu_summary = report.hardware_summary
            models = report.ollama_models
            started = await mdns.start(
                port=self.config.server.port,
                gpu_summary=gpu_summary,
                models=models,
            )
            if started:
                self._mdns = mdns
                report.lan_discovery = True
                # Give a brief moment for initial discovery
                import asyncio

                await asyncio.sleep(1.0)
                nodes = mdns.get_nodes()
                report.lan_nodes = len(nodes)
        except Exception as exc:
            logger.debug("LAN discovery startup failed: %s", exc)
            warnings.append(f"LAN discovery failed: {exc}")
        return report

    def _enumerate_cloud_keys(self, report: StartupReport, warnings: list[str]) -> StartupReport:
        """Check which BYOK keys are configured."""
        try:
            from llmhosts.keys.manager import KeyManager

            mgr = KeyManager()
            providers = mgr.list_providers()
            report.cloud_providers = [p.provider for p in providers]
        except Exception as exc:
            logger.debug("Key enumeration failed: %s", exc)
            warnings.append(f"Could not read BYOK keys: {exc}")
        return report

    def _determine_router_tier(self, report: StartupReport) -> StartupReport:
        """Determine which router tier is active based on config + installed deps."""
        cfg = self.config.router
        if cfg.enable_qwen and _is_importable("torch"):
            report.router_tier = "Full hybrid (Tier 3: kNN + ModernBERT + Qwen-0.5B)"
        elif cfg.enable_modernbert and _is_importable("onnxruntime"):
            report.router_tier = "Smart (Tier 2: kNN + ModernBERT)"
        elif cfg.enable_knn and _is_importable("faiss"):
            report.router_tier = "kNN + Rule-based (Tier 1)"
        else:
            report.router_tier = "Rule-based (Tier 0)"
        return report

    def _determine_cache_tier(self, report: StartupReport) -> StartupReport:
        """Determine which cache tier is active based on config."""
        cfg = self.config.cache
        if not cfg.enabled:
            report.cache_tier = "Disabled"
        elif cfg.enable_vcache:
            report.cache_tier = "vCache + Namespace + Exact hash"
        elif cfg.enable_namespace:
            report.cache_tier = "Namespace + Exact hash"
        else:
            report.cache_tier = "Exact hash"
        return report

    def _list_endpoints(self) -> list[str]:
        """Return the list of API endpoint paths the proxy exposes."""
        endpoints = [
            "/v1/chat/completions  (OpenAI)",
            "/v1/messages           (Anthropic)",
            "/v1/models             (model list)",
            "/health                (health check)",
            "/ready                 (readiness probe)",
            "/api/savings           (dashboard savings)",
            "/api/metrics           (dashboard metrics)",
            "/api/requests          (request log)",
            "/api/backends          (backend status)",
            "/api/config            (config - sanitised)",
            "/api/ws/live           (WebSocket live)",
        ]
        if self.config.dashboard.enabled and self.config.dashboard.web:
            endpoints.append("/dashboard              (web UI)")
        return endpoints

    def _create_app(self) -> FastAPI:
        """Create the FastAPI application with security middleware from config."""
        from llmhosts.proxy.app import create_app

        app = create_app(config=self.config)

        app.state.llmhosts_config = self.config
        app.state.startup_report = self._report

        return app


# ---------------------------------------------------------------------------
# Utility: port availability check
# ---------------------------------------------------------------------------


def is_port_available(host: str, port: int) -> bool:
    """Return *True* if *port* is free on *host*."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(1)
            s.bind((host, port))
        return True
    except OSError:
        return False


# ---------------------------------------------------------------------------
# Utility: safe importability check
# ---------------------------------------------------------------------------


def _is_importable(module_name: str) -> bool:
    """Return *True* if *module_name* can be imported."""
    import importlib

    try:
        importlib.import_module(module_name)
        return True
    except ImportError:
        return False
