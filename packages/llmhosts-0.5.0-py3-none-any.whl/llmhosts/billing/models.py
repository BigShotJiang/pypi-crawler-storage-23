"""LLMHosts billing event models — metering for Stripe and marketplace (Phase 5)."""

from __future__ import annotations

from datetime import datetime  # noqa: TC003 — needed at runtime for Pydantic validation

from pydantic import BaseModel, ConfigDict


class BillingEvent(BaseModel):
    """A single metering event for a marketplace (remote) request.

    Emitted when a request completes against a remote backend. Consumed by
    billing pipeline (e.g. Stripe metered billing) for usage aggregation.
    """

    model_config = ConfigDict(frozen=False)

    request_id: str
    timestamp: datetime
    api_key_id: str = ""  # truncated API key identifier; empty if none
    user_id: str = ""  # user identifier from auth; empty if none
    device_id: str | None = None  # remote device/marketplace node ID
    model: str
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    price_cents: int | None = None  # optional charge for this request
    price_cents_per_hour: int | None = None  # optional rate (marketplace listing)
    source: str = "marketplace"  # always "marketplace" for remote/metered
