"""LLMHosts savings tracker — module-level singleton for recording per-request savings.

Wraps :class:`CostOracle` with a simple functional API so the proxy dispatcher
can record savings without carrying oracle state itself.
"""

from __future__ import annotations

import logging

from llmhosts.metrics.cost_oracle import CostOracle, SavingsReport

logger = logging.getLogger(__name__)

# Module-level singleton — shared across the process lifetime.
_oracle = CostOracle()


def record_savings(model: str, input_tokens: int, output_tokens: int) -> SavingsReport:
    """Record savings for a single inference call and return the :class:`SavingsReport`.

    Parameters
    ----------
    model:
        The model name as used by the backend (e.g. ``"llama3.3:70b"``).
    input_tokens:
        Number of prompt tokens consumed.
    output_tokens:
        Number of completion tokens generated.

    Returns
    -------
    SavingsReport
        A dataclass with cloud_cost_usd, local_cost_usd, savings_usd, and savings_pct.
    """
    report = _oracle.calculate(model, input_tokens, output_tokens)
    logger.debug(
        "Savings recorded: model=%s input=%d output=%d saved=$%.6f (%.1f%%)",
        model,
        input_tokens,
        output_tokens,
        report.savings_usd,
        report.savings_pct,
    )
    return report


def get_session_summary() -> dict:
    """Return cumulative savings summary for the current process session.

    Returns
    -------
    dict
        Keys: total_calls, total_savings_usd, avg_savings_pct, reports.
    """
    return _oracle.session_summary()
