"""LLMHosts router -- intelligent request routing across local and cloud backends.

Tier 0: Rule-based deterministic routing (current)
Tier 1: kNN embedding router (Phase 1)
Tier 2: ModernBERT classifier (Phase 1)
Tier 3: Qwen-0.5B reasoning (Phase 2)
GPU-less: Cloud-only smart routing for users without local models
"""

from __future__ import annotations

from llmhosts.privacy import PIIDetector, PIIMatch, PIIType, PrivacyClassification, PrivacySettings, PrivacyTier
from llmhosts.router._core import RUST_AVAILABLE as RUST_CORE_AVAILABLE
from llmhosts.router._core import knn_search as rust_knn_search
from llmhosts.router.aliases import AliasResolver, ResolvedModel
from llmhosts.router.cloud_client import CloudRouterClient
from llmhosts.router.cost import CostTracker, RequestLog, SavingsReport
from llmhosts.router.engine import Router
from llmhosts.router.gpu_less import CloudModelSelection, GPULessRouter, TaskComplexity
from llmhosts.router.knn import KNN_AVAILABLE, KNNRouter, KNNRoutingResult, ScoredRoute
from llmhosts.router.models import (
    AlternativeRoute,
    BackendInfo,
    CostEstimate,
    RoutingDecision,
    RoutingRule,
)
from llmhosts.router.modernbert import (
    MODEL_COMPLEXITY_MAP,
    MODERNBERT_AVAILABLE,
    Classification,
    ModelMapping,
    ModernBERTResult,
    ModernBERTRouter,
    RequestFeatures,
)
from llmhosts.router.qwen import QWEN_AVAILABLE, QwenRouter, QwenRoutingResult

__all__ = [
    "KNN_AVAILABLE",
    "MODEL_COMPLEXITY_MAP",
    "MODERNBERT_AVAILABLE",
    "QWEN_AVAILABLE",
    "RUST_CORE_AVAILABLE",
    "AliasResolver",
    "AlternativeRoute",
    "BackendInfo",
    "Classification",
    "CloudModelSelection",
    "CloudRouterClient",
    "CostEstimate",
    "CostTracker",
    "GPULessRouter",
    "KNNRouter",
    "KNNRoutingResult",
    "ModelMapping",
    "ModernBERTResult",
    "ModernBERTRouter",
    "PIIDetector",
    "PIIMatch",
    "PIIType",
    "PrivacyClassification",
    "PrivacySettings",
    "PrivacyTier",
    "QwenRouter",
    "QwenRoutingResult",
    "RequestFeatures",
    "RequestLog",
    "ResolvedModel",
    "Router",
    "RoutingDecision",
    "RoutingRule",
    "SavingsReport",
    "ScoredRoute",
    "TaskComplexity",
    "rust_knn_search",
]
