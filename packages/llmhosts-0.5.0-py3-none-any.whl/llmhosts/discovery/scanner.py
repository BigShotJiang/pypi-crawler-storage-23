"""Universal inference engine scanner with pluggable probes.

Discovers all running inference engines on the local machine concurrently.
Each engine type has a dedicated probe that knows how to detect it by
querying known endpoints and fingerprinting responses.

Port conflict resolution (8080 is used by llama.cpp, LocalAI, and TGI)
is handled via confidence-scored fingerprinting — each probe returns a
0.0-1.0 confidence and the highest wins.
"""

from __future__ import annotations

import asyncio
import logging
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, ClassVar

import httpx

from llmhosts.discovery.models import DiscoveredEngine, DiscoveredModel

if TYPE_CHECKING:
    from llmhosts.remit import RemitWatcher

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Abstract probe interface
# ---------------------------------------------------------------------------


class EngineProbe(ABC):
    """Base class for engine-specific detection probes."""

    engine_type: str = ""
    default_ports: ClassVar[list[int]] = []
    api_compat: str = "openai"

    @abstractmethod
    async def probe(self, host: str, port: int, client: httpx.AsyncClient) -> DiscoveredEngine | None:
        """Probe a host:port and return a DiscoveredEngine if detected, else None."""

    def _make_engine(
        self,
        host: str,
        port: int,
        *,
        models: list[DiscoveredModel] | None = None,
        confidence: float = 1.0,
        version: str = "",
        features: list[str] | None = None,
    ) -> DiscoveredEngine:
        return DiscoveredEngine(
            engine_type=self.engine_type,
            host=host,
            port=port,
            available=True,
            models=models or [],
            api_compat=self.api_compat,
            confidence=confidence,
            version=version,
            features=features or ["streaming"],
        )


# ---------------------------------------------------------------------------
# Ollama probe — port 11434, GET /api/tags
# ---------------------------------------------------------------------------


class OllamaProbe(EngineProbe):
    engine_type = "ollama"
    default_ports: ClassVar[list[int]] = [11434]
    api_compat = "ollama"

    async def probe(self, host: str, port: int, client: httpx.AsyncClient) -> DiscoveredEngine | None:
        try:
            resp = await client.get(f"http://{host}:{port}/api/tags")
            if resp.status_code != 200:
                return None
            data = resp.json()
            raw_models = data.get("models", [])
            models = [
                DiscoveredModel(
                    id=m.get("name", "unknown"),
                    size_gb=round(m.get("size", 0) / (1024**3), 2),
                    engine_type=self.engine_type,
                )
                for m in raw_models
            ]
            # Try to get version from Ollama root endpoint
            version = ""
            try:
                ver_resp = await client.get(f"http://{host}:{port}/api/version")
                if ver_resp.status_code == 200:
                    version = ver_resp.json().get("version", "")
            except Exception:
                pass
            return self._make_engine(
                host,
                port,
                models=models,
                confidence=1.0,
                version=version,
                features=["streaming", "tool_calling", "vision", "embeddings"],
            )
        except (httpx.ConnectError, httpx.TimeoutException, httpx.HTTPError, ValueError):
            return None


# ---------------------------------------------------------------------------
# vLLM probe — port 8000, GET /v1/models
# ---------------------------------------------------------------------------


class VLLMProbe(EngineProbe):
    engine_type = "vllm"
    default_ports: ClassVar[list[int]] = [8000]
    api_compat = "openai"

    async def probe(self, host: str, port: int, client: httpx.AsyncClient) -> DiscoveredEngine | None:
        try:
            resp = await client.get(f"http://{host}:{port}/v1/models")
            if resp.status_code != 200:
                return None
            data = resp.json()
            raw_models = data.get("data", [])
            # Fingerprint: vLLM models have "object": "model" and often "max_model_len"
            if not raw_models:
                return None

            models = [
                DiscoveredModel(
                    id=m.get("id", "unknown"),
                    engine_type=self.engine_type,
                    context_length=m.get("max_model_len", 0),
                )
                for m in raw_models
            ]
            # Check for vLLM-specific /metrics endpoint
            version = ""
            confidence = 0.7  # Moderate — other engines also serve /v1/models
            try:
                metrics_resp = await client.get(f"http://{host}:{port}/metrics")
                if metrics_resp.status_code == 200 and "vllm:" in metrics_resp.text:
                    confidence = 1.0  # Confirmed vLLM via Prometheus metrics
            except Exception:
                pass
            return self._make_engine(
                host,
                port,
                models=models,
                confidence=confidence,
                version=version,
                features=["streaming", "tool_calling"],
            )
        except (httpx.ConnectError, httpx.TimeoutException, httpx.HTTPError, ValueError):
            return None


# ---------------------------------------------------------------------------
# llama.cpp probe — port 8080, GET /health
# ---------------------------------------------------------------------------


class LlamaCppProbe(EngineProbe):
    engine_type = "llama.cpp"
    default_ports: ClassVar[list[int]] = [8080]
    api_compat = "openai"

    async def probe(self, host: str, port: int, client: httpx.AsyncClient) -> DiscoveredEngine | None:
        try:
            resp = await client.get(f"http://{host}:{port}/health")
            if resp.status_code != 200:
                return None
            data = resp.json()

            # llama.cpp /health returns {"status": "ok"} or {"status": "ok", "slots_idle": N, ...}
            if data.get("status") != "ok":
                return None

            # Fingerprint: llama.cpp has "slots_idle" and "slots_processing" fields
            has_slots = "slots_idle" in data or "slots_processing" in data
            confidence = 0.9 if has_slots else 0.5

            # Try /v1/models for model list (llama.cpp router mode)
            models: list[DiscoveredModel] = []
            try:
                models_resp = await client.get(f"http://{host}:{port}/v1/models")
                if models_resp.status_code == 200:
                    raw_models = models_resp.json().get("data", [])
                    models = [
                        DiscoveredModel(id=m.get("id", "unknown"), engine_type=self.engine_type) for m in raw_models
                    ]
            except Exception:
                pass

            # Also try /props for server info
            try:
                props_resp = await client.get(f"http://{host}:{port}/props")
                if props_resp.status_code == 200:
                    props_data = props_resp.json()
                    if "default_generation_settings" in props_data:
                        confidence = 1.0  # Confirmed llama.cpp via /props
                    model_id = props_data.get("default_generation_settings", {}).get("model", "")
                    if model_id and not models:
                        models = [DiscoveredModel(id=model_id, engine_type=self.engine_type)]
            except Exception:
                pass

            return self._make_engine(
                host,
                port,
                models=models,
                confidence=confidence,
                features=["streaming", "embeddings"],
            )
        except (httpx.ConnectError, httpx.TimeoutException, httpx.HTTPError, ValueError):
            return None


# ---------------------------------------------------------------------------
# LM Studio probe — port 1234, GET /v1/models
# ---------------------------------------------------------------------------


class LMStudioProbe(EngineProbe):
    engine_type = "lmstudio"
    default_ports: ClassVar[list[int]] = [1234]
    api_compat = "openai"

    async def probe(self, host: str, port: int, client: httpx.AsyncClient) -> DiscoveredEngine | None:
        try:
            resp = await client.get(f"http://{host}:{port}/v1/models")
            if resp.status_code != 200:
                return None
            data = resp.json()
            raw_models = data.get("data", [])

            # LM Studio models have "owned_by": "lmstudio" or "lmstudio-community", or file paths as IDs
            is_lmstudio = any(
                m.get("owned_by", "").lower().startswith("lmstudio")
                or "lm-studio" in m.get("id", "").lower()  # LM Studio uses file paths as model IDs
                or "\\" in m.get("id", "")  # Windows file paths in model IDs
                for m in raw_models
            )
            confidence = 0.95 if is_lmstudio else 0.6

            models = [DiscoveredModel(id=m.get("id", "unknown"), engine_type=self.engine_type) for m in raw_models]
            return self._make_engine(
                host,
                port,
                models=models,
                confidence=confidence,
                features=["streaming", "embeddings"],
            )
        except (httpx.ConnectError, httpx.TimeoutException, httpx.HTTPError, ValueError):
            return None


# ---------------------------------------------------------------------------
# LocalAI probe — port 8080, GET /v1/models + fingerprint
# ---------------------------------------------------------------------------


class LocalAIProbe(EngineProbe):
    engine_type = "localai"
    default_ports: ClassVar[list[int]] = [8080]
    api_compat = "openai"

    async def probe(self, host: str, port: int, client: httpx.AsyncClient) -> DiscoveredEngine | None:
        try:
            # LocalAI serves /v1/models and also has /readyz
            readyz_resp = await client.get(f"http://{host}:{port}/readyz")
            if readyz_resp.status_code != 200:
                return None

            # Check for LocalAI-specific /system endpoint
            confidence = 0.5
            version = ""
            try:
                system_resp = await client.get(f"http://{host}:{port}/system")
                if system_resp.status_code == 200:
                    sys_data = system_resp.json()
                    # LocalAI /system returns version and backend info
                    if "build" in sys_data or "go_version" in sys_data:
                        confidence = 1.0
                        version = sys_data.get("build", {}).get("version", "")
            except Exception:
                pass

            # Get models
            models: list[DiscoveredModel] = []
            try:
                models_resp = await client.get(f"http://{host}:{port}/v1/models")
                if models_resp.status_code == 200:
                    raw_models = models_resp.json().get("data", [])
                    models = [
                        DiscoveredModel(id=m.get("id", "unknown"), engine_type=self.engine_type) for m in raw_models
                    ]
            except Exception:
                pass

            return self._make_engine(
                host,
                port,
                models=models,
                confidence=confidence,
                version=version,
                features=["streaming", "tool_calling", "vision", "embeddings", "audio"],
            )
        except (httpx.ConnectError, httpx.TimeoutException, httpx.HTTPError, ValueError):
            return None


# ---------------------------------------------------------------------------
# TGI probe — port 8080, GET /info
# ---------------------------------------------------------------------------


class TGIProbe(EngineProbe):
    engine_type = "tgi"
    default_ports: ClassVar[list[int]] = [8080]
    api_compat = "openai"

    async def probe(self, host: str, port: int, client: httpx.AsyncClient) -> DiscoveredEngine | None:
        try:
            resp = await client.get(f"http://{host}:{port}/info")
            if resp.status_code != 200:
                return None
            data = resp.json()

            # TGI /info returns model_id, model_dtype, etc.
            model_id = data.get("model_id", "")
            if not model_id:
                return None

            confidence = 0.95  # /info with model_id is highly TGI-specific
            if "model_dtype" in data or "max_input_tokens" in data:
                confidence = 1.0

            models = [
                DiscoveredModel(
                    id=model_id,
                    engine_type=self.engine_type,
                    context_length=data.get("max_input_tokens", 0),
                )
            ]
            version = data.get("version", "")
            return self._make_engine(
                host,
                port,
                models=models,
                confidence=confidence,
                version=version,
                features=["streaming", "tool_calling"],
            )
        except (httpx.ConnectError, httpx.TimeoutException, httpx.HTTPError, ValueError):
            return None


# ---------------------------------------------------------------------------
# Generic OpenAI-compatible probe (user-configured URLs)
# ---------------------------------------------------------------------------


class GenericOpenAIProbe(EngineProbe):
    engine_type = "generic"
    default_ports: ClassVar[list[int]] = []
    api_compat = "openai"

    async def probe(self, host: str, port: int, client: httpx.AsyncClient) -> DiscoveredEngine | None:
        try:
            resp = await client.get(f"http://{host}:{port}/v1/models")
            if resp.status_code != 200:
                return None
            data = resp.json()
            raw_models = data.get("data", [])
            if not raw_models:
                return None

            models = [DiscoveredModel(id=m.get("id", "unknown"), engine_type=self.engine_type) for m in raw_models]
            return self._make_engine(
                host,
                port,
                models=models,
                confidence=0.5,  # Low confidence — could be anything OpenAI-compatible
                features=["streaming"],
            )
        except (httpx.ConnectError, httpx.TimeoutException, httpx.HTTPError, ValueError):
            return None


# ---------------------------------------------------------------------------
# Registry of all probes with their default ports
# ---------------------------------------------------------------------------

# Ordered by specificity: more specific probes first to win port conflicts
ALL_PROBES: list[EngineProbe] = [
    OllamaProbe(),
    VLLMProbe(),
    TGIProbe(),
    LlamaCppProbe(),
    LMStudioProbe(),
    LocalAIProbe(),
    GenericOpenAIProbe(),
]

# Ports to scan by default (union of all probe defaults, no duplicates)
_DEFAULT_PORTS: set[int] = set()
for _p in ALL_PROBES:
    _DEFAULT_PORTS.update(_p.default_ports)


# ---------------------------------------------------------------------------
# UniversalScanner
# ---------------------------------------------------------------------------


class UniversalScanner:
    """Discovers all running inference engines by probing known ports concurrently.

    Port conflict resolution: when multiple probes match the same port
    (e.g., 8080), the probe with the highest confidence score wins.
    """

    def __init__(
        self,
        host: str = "127.0.0.1",
        extra_hosts: list[str] | None = None,
        timeout: float = 3.0,
    ) -> None:
        self._host = host
        self._extra_hosts = extra_hosts or []
        self._timeout = timeout

    async def scan(self) -> list[DiscoveredEngine]:
        """Run all probes concurrently and return deduplicated, confidence-sorted results."""
        async with httpx.AsyncClient(timeout=httpx.Timeout(self._timeout)) as client:
            tasks: list[asyncio.Task[DiscoveredEngine | None]] = []

            # Probe default ports on primary host
            for probe in ALL_PROBES:
                for port in probe.default_ports:
                    tasks.append(asyncio.create_task(self._safe_probe(probe, self._host, port, client)))

            # Probe extra user-configured hosts
            for extra_url in self._extra_hosts:
                host, port = self._parse_host_port(extra_url)
                if host and port:
                    tasks.append(asyncio.create_task(self._safe_probe(GenericOpenAIProbe(), host, port, client)))

            results = await asyncio.gather(*tasks)

        # Filter None, deduplicate by port (highest confidence wins)
        engines: list[DiscoveredEngine] = [r for r in results if r is not None]
        return self._deduplicate(engines)

    async def probe_engine(self, engine_type: str, host: str, port: int) -> DiscoveredEngine | None:
        """Probe a specific engine type at a specific host:port."""
        probe = next((p for p in ALL_PROBES if p.engine_type == engine_type), None)
        if not probe:
            return None
        async with httpx.AsyncClient(timeout=httpx.Timeout(self._timeout)) as client:
            return await self._safe_probe(probe, host, port, client)

    @staticmethod
    async def _safe_probe(
        probe: EngineProbe,
        host: str,
        port: int,
        client: httpx.AsyncClient,
    ) -> DiscoveredEngine | None:
        """Run a probe with error suppression."""
        try:
            result = await probe.probe(host, port, client)
            if result:
                logger.debug(
                    "Probe %s found engine at %s:%d (confidence=%.2f, models=%d)",
                    probe.engine_type,
                    host,
                    port,
                    result.confidence,
                    result.model_count,
                )
            return result
        except Exception as exc:
            logger.debug("Probe %s failed at %s:%d: %s", probe.engine_type, host, port, exc)
            return None

    @staticmethod
    def _deduplicate(engines: list[DiscoveredEngine]) -> list[DiscoveredEngine]:
        """When multiple probes match the same host:port, keep highest confidence."""
        best: dict[str, DiscoveredEngine] = {}
        for engine in engines:
            key = f"{engine.host}:{engine.port}"
            existing = best.get(key)
            if existing is None or engine.confidence > existing.confidence:
                best[key] = engine
        result = list(best.values())
        result.sort(key=lambda e: (-e.confidence, e.engine_type))
        return result

    @staticmethod
    def _parse_host_port(url: str) -> tuple[str, int]:
        """Parse 'host:port' or 'http://host:port' into (host, port)."""
        url = url.strip()
        for prefix in ("http://", "https://"):
            if url.startswith(prefix):
                url = url[len(prefix) :]
        url = url.rstrip("/")
        if ":" in url:
            parts = url.rsplit(":", 1)
            try:
                return parts[0], int(parts[1])
            except ValueError:
                pass
        return "", 0


def remit_filter(
    engines: list[DiscoveredEngine],
    remit_watcher: RemitWatcher,
) -> list[DiscoveredEngine]:
    """Filter discovered engines to only those within the current remit."""
    return [
        engine
        for engine in engines
        if remit_watcher.is_backend_allowed(
            engine.base_url,
            engine.gpu_ids[0] if engine.gpu_ids else "",
        )
    ]
