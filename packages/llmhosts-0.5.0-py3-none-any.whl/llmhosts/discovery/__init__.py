"""Ollama auto-discovery, hardware detection, tunnel tool probing, model suggestions, vLLM, mDNS LAN discovery, and universal engine scanning."""

from __future__ import annotations

from llmhosts.discovery.engine import EngineManager, EngineType, InferenceEngine
from llmhosts.discovery.hardware import HardwareDetector
from llmhosts.discovery.mdns import LANNode, MDNSDiscovery, get_discovered_nodes, scan_lan
from llmhosts.discovery.models import (
    DiscoveredEngine,
    DiscoveredModel,
    GPUInfo,
    HardwareProfile,
    ModelDetails,
    ModelInfo,
    OllamaHealth,
    OllamaModel,
    ProvisionResult,
    RunningModel,
    SavingsSnapshot,
)
from llmhosts.discovery.ollama import OllamaDiscovery
from llmhosts.discovery.provisioner import EngineProvisioner
from llmhosts.discovery.savings import SavingsTracker
from llmhosts.discovery.scanner import UniversalScanner
from llmhosts.discovery.suggest import ModelSuggester, ModelSuggestion
from llmhosts.discovery.vllm import VLLMDiscovery, VLLMHealth, VLLMMetrics, VLLMModel
from llmhosts.discovery.watcher import DiscoveryWatcher

__all__ = [
    "DiscoveredEngine",
    "DiscoveredModel",
    "DiscoveryWatcher",
    "EngineManager",
    "EngineProvisioner",
    "EngineType",
    "GPUInfo",
    "HardwareDetector",
    "HardwareProfile",
    "InferenceEngine",
    "LANNode",
    "MDNSDiscovery",
    "ModelDetails",
    "ModelInfo",
    "ModelSuggester",
    "ModelSuggestion",
    "OllamaDiscovery",
    "OllamaHealth",
    "OllamaModel",
    "ProvisionResult",
    "RunningModel",
    "SavingsSnapshot",
    "SavingsTracker",
    "UniversalScanner",
    "VLLMDiscovery",
    "VLLMHealth",
    "VLLMMetrics",
    "VLLMModel",
    "get_discovered_nodes",
    "scan_lan",
]
