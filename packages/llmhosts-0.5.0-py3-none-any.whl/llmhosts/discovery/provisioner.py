"""Engine provisioner — auto-installs Ollama and pulls starter models.

Only activates when no inference engines are found. Designed for the
clean-box user who types ``llmhosts up`` on a fresh machine.

Safety rules:
- NEVER auto-installs GPU drivers (wrong driver = black screen)
- Prints clear instructions with links for driver installation
- Ollama is the only auto-installable engine (cross-platform, auto-GPU)
- Model selection is VRAM-aware using the existing ModelSuggester catalog
- User can always override: ``ollama pull whatever`` and the watcher detects it
"""

from __future__ import annotations

import asyncio
import logging
import platform
import shutil
import time
from typing import TYPE_CHECKING

from llmhosts.discovery.models import HardwareProfile, ProvisionResult

if TYPE_CHECKING:
    from collections.abc import Callable

logger = logging.getLogger(__name__)

_ATLAS_BASE_URL = "https://llmhosts.com/api/atlas"
_ATLAS_TIMEOUT_SECONDS = 2.0


async def fetch_atlas_recommendations(gpu_model: str, vram_mb: int) -> list[dict]:
    """Fetch hardware-matched model recommendations from the Performance Atlas.

    Returns a list of ``{model_id, tps_p50, success_rate}`` dicts sorted by
    tps_p50 descending. On ANY failure (network, timeout, parse error) returns
    an empty list silently — the static VRAM table remains the primary fallback.
    """
    try:
        import httpx

        params = {"gpu": gpu_model, "vram_mb": str(vram_mb)}
        async with httpx.AsyncClient(timeout=_ATLAS_TIMEOUT_SECONDS) as client:
            resp = await client.get(_ATLAS_BASE_URL, params=params)
            resp.raise_for_status()
            data = resp.json()

        if not isinstance(data, list):
            return []

        results: list[dict] = []
        for entry in data:
            if not isinstance(entry, dict):
                continue
            model_id = entry.get("modelId") if entry.get("modelId") is not None else entry.get("model_id")
            tps_p50 = entry.get("tpsP50") if entry.get("tpsP50") is not None else entry.get("tps_p50")
            success_rate = (
                entry.get("successRate") if entry.get("successRate") is not None else entry.get("success_rate")
            )
            if model_id and tps_p50 is not None and success_rate is not None:
                results.append(
                    {
                        "model_id": str(model_id),
                        "tps_p50": float(tps_p50),
                        "success_rate": float(success_rate),
                        "measurementCount": int(entry.get("measurementCount", 0)),
                    }
                )

        return sorted(results, key=lambda x: x["tps_p50"], reverse=True)

    except Exception:
        # Network errors, timeouts, parse errors — all silent
        return []


def format_atlas_recommendation(entry: dict) -> str:
    """Format a single atlas entry as a human-readable recommendation string."""
    return (
        f"Based on {entry['measurementCount']} users with your GPU: "
        f"{entry['model_id']} runs at ~{entry['tps_p50']:.0f} tok/s"
    )


# VRAM-based default model selection — updated February 2026.
#
# Sources:
#   - awesomeagents.ai/leaderboards/home-gpu-llm-leaderboard
#   - localllm.in/blog/ollama-vram-requirements-for-local-llms
#   - localllm.in/blog/best-local-llms-24gb-vram
#   - ollama.com/library
#
# Selection criteria: best *general-purpose* model at each tier on MMLU,
# HumanEval, GSM8K, and real-world coding/reasoning benchmarks (Feb 2026).
# Models must leave ≥20 % VRAM free for KV-cache / context overhead.
#
# Tier  | min VRAM | Model               | DL size | VRAM Q4 | Rationale
# ------|----------|---------------------|---------|---------|------------------------------------
#  T0   | 0 GB     | qwen3:1.7b          | 1.4 GB  | ~2 GB   | Best tiny; matches Qwen2.5-3B quality
#  T1   | 4 GB     | qwen3:4b            | 2.5 GB  | ~3.5 GB | Strong for size; 110 tok/s
#  T2   | 7 GB     | qwen3:8b            | 5.2 GB  | ~6.2 GB | Dominates 8B tier (MMLU 76.9)
#  T3   | 10 GB    | qwen3:14b           | 9.3 GB  | ~10.7 GB| Dramatic jump (MMLU 81.1, HumanEval 72.2)
#  T4   | 16 GB    | gpt-oss:20b         | 14 GB   | ~14 GB  | OpenAI open MoE; 139 tok/s, 128K ctx
#  T5   | 22 GB    | qwen3:32b           | 20 GB   | ~22.2 GB| Best dense quality (MMLU 83.6, GPQA 49.5)
#  T6   | 40 GB    | llama3.3:70b        | 40 GB   | ~45.6 GB| Frontier; HumanEval 80.5, GSM8K 95.1
_VRAM_MODEL_MAP: list[tuple[float, str, float]] = [
    # (min_vram_gb, ollama_tag, approximate_download_gb)
    (0.0, "qwen3:1.7b", 1.4),  # CPU-only / <4 GB — ultra-light, rivals Qwen2.5-3B
    (4.0, "qwen3:4b", 2.5),  # 4-7 GB — integrated GPUs, old discrete cards
    (7.0, "qwen3:8b", 5.2),  # 7-10 GB — RTX 3060 8 GB, RTX 4060 8 GB
    (10.0, "qwen3:14b", 9.3),  # 10-16 GB — RTX 3060 12 GB, RTX 4060 Ti 16 GB
    (16.0, "gpt-oss:20b", 14.0),  # 16-22 GB — RTX 4080 16 GB, RTX 4090M 18 GB
    (22.0, "qwen3:32b", 20.0),  # 22-40 GB — RTX 4090 24 GB, RTX 5090 32 GB
    (40.0, "llama3.3:70b", 40.0),  # 40 GB+ — dual GPU / A100 / H100
]


def _select_model_for_hardware(hardware: HardwareProfile) -> tuple[str, float]:
    """Pick the best default model based on available VRAM (or RAM/2 for CPU-only)."""
    if hardware.has_gpu and hardware.total_vram_mb > 0:
        effective_gb = hardware.total_vram_mb / 1024.0
    else:
        effective_gb = hardware.ram_total_gb / 2.0

    model_name = _VRAM_MODEL_MAP[0][1]
    model_size = _VRAM_MODEL_MAP[0][2]
    for min_vram, name, size in _VRAM_MODEL_MAP:
        if effective_gb >= min_vram:
            model_name = name
            model_size = size
    return model_name, model_size


class EngineProvisioner:
    """Auto-provisions inference engines for clean-box users.

    Flow:
    1. Check if Ollama is already installed (``which ollama``)
    2. If not, install it using the platform-appropriate method
    3. Start Ollama service if not running
    4. Pull a starter model sized to the detected hardware
    """

    def __init__(self, on_status: Callable[[str], None] | None = None) -> None:
        self._on_status = on_status or (lambda msg: logger.info(msg))

    async def provision(self, hardware: HardwareProfile) -> ProvisionResult:
        """Full provisioning: install engine + pull starter model."""
        start = time.monotonic()

        # Step 1: Ensure Ollama is installed
        installed, method = await self._ensure_ollama_installed()
        if not installed:
            return ProvisionResult(
                success=False,
                error="Failed to install Ollama. Please install manually: https://ollama.com/download",
                duration_seconds=time.monotonic() - start,
            )

        # Step 2: Ensure Ollama is running
        running = await self._ensure_ollama_running()
        if not running:
            return ProvisionResult(
                success=False,
                engine_installed=True,
                install_method=method,
                error="Ollama installed but failed to start. Try: ollama serve",
                duration_seconds=time.monotonic() - start,
            )

        # Step 3: Pull starter model
        model_name, model_size = _select_model_for_hardware(hardware)
        self._on_status(f"Pulling {model_name} ({model_size:.1f}GB) — best fit for your hardware...")
        pulled = await self._pull_model(model_name)

        return ProvisionResult(
            success=pulled,
            engine_installed=True,
            model_pulled=model_name if pulled else "",
            model_size_gb=model_size if pulled else 0.0,
            install_method=method,
            error="" if pulled else f"Failed to pull {model_name}. Try: ollama pull {model_name}",
            duration_seconds=time.monotonic() - start,
        )

    async def install_ollama(self) -> tuple[bool, str]:
        """Install Ollama using the platform-appropriate method. Returns (success, method)."""
        return await self._ensure_ollama_installed()

    async def suggest_and_pull(self, hardware: HardwareProfile) -> tuple[str, bool]:
        """Suggest a model for the hardware and pull it. Returns (model_name, success)."""
        model_name, _ = _select_model_for_hardware(hardware)
        success = await self._pull_model(model_name)
        return model_name, success

    # ------------------------------------------------------------------
    # Ollama installation
    # ------------------------------------------------------------------

    async def _ensure_ollama_installed(self) -> tuple[bool, str]:
        """Check if Ollama is installed; install if not. Returns (success, install_method)."""
        if shutil.which("ollama"):
            self._on_status("Ollama already installed")
            return True, "existing"

        system = platform.system().lower()
        if system in ("linux", "darwin"):
            return await self._install_ollama_unix()
        elif system == "windows":
            return await self._install_ollama_windows()
        else:
            self._on_status(f"Unsupported platform: {system}. Please install Ollama manually.")
            return False, ""

    async def _install_ollama_unix(self) -> tuple[bool, str]:
        """Install Ollama on Linux/macOS via official install script."""
        self._on_status("Installing Ollama...")
        try:
            proc = await asyncio.create_subprocess_exec(
                "sh",
                "-c",
                "curl -fsSL https://ollama.com/install.sh | sh",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            _, stderr = await asyncio.wait_for(proc.communicate(), timeout=120)
            if proc.returncode == 0:
                self._on_status("Ollama installed successfully")
                return True, "curl"
            else:
                err = stderr.decode(errors="replace")[:500]
                self._on_status(f"Ollama install failed: {err}")
                return False, ""
        except asyncio.TimeoutError:
            self._on_status("Ollama install timed out after 120s")
            return False, ""
        except Exception as exc:
            self._on_status(f"Ollama install error: {exc}")
            return False, ""

    async def _install_ollama_windows(self) -> tuple[bool, str]:
        """Install Ollama on Windows via winget (fallback: direct download URL)."""
        self._on_status("Installing Ollama via winget...")
        if shutil.which("winget"):
            try:
                proc = await asyncio.create_subprocess_exec(
                    "winget",
                    "install",
                    "--id",
                    "Ollama.Ollama",
                    "--accept-source-agreements",
                    "--accept-package-agreements",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                _, stderr = await asyncio.wait_for(proc.communicate(), timeout=120)
                if proc.returncode == 0:
                    self._on_status("Ollama installed via winget")
                    return True, "winget"
                logger.debug("winget install failed: %s", stderr.decode(errors="replace")[:500])
            except (asyncio.TimeoutError, Exception) as exc:
                logger.debug("winget install error: %s", exc)

        self._on_status("Could not auto-install on Windows. Please download from: https://ollama.com/download/windows")
        return False, ""

    # ------------------------------------------------------------------
    # Ollama service management
    # ------------------------------------------------------------------

    async def _ensure_ollama_running(self) -> bool:
        """Check if Ollama is running; try to start it if not."""
        import httpx

        # Quick check: is it already running?
        try:
            async with httpx.AsyncClient(timeout=3.0) as client:
                resp = await client.get("http://127.0.0.1:11434/api/tags")
                if resp.status_code == 200:
                    return True
        except Exception:
            pass

        # Try to start it
        self._on_status("Starting Ollama service...")
        try:
            # On Linux/macOS, `ollama serve` runs in foreground.
            # Launch it as a background process.
            await asyncio.create_subprocess_exec(
                "ollama",
                "serve",
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
            # Give it a moment to start
            for _ in range(10):
                await asyncio.sleep(1)
                try:
                    async with httpx.AsyncClient(timeout=2.0) as client:
                        resp = await client.get("http://127.0.0.1:11434/api/tags")
                        if resp.status_code == 200:
                            self._on_status("Ollama started")
                            return True
                except Exception:
                    continue
        except Exception as exc:
            logger.debug("Failed to start Ollama: %s", exc)

        return False

    # ------------------------------------------------------------------
    # Model pulling
    # ------------------------------------------------------------------

    async def _pull_model(self, model_name: str) -> bool:
        """Pull a model via ``ollama pull``."""
        try:
            proc = await asyncio.create_subprocess_exec(
                "ollama",
                "pull",
                model_name,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            _, stderr = await asyncio.wait_for(proc.communicate(), timeout=600)  # 10 min for large models
            if proc.returncode == 0:
                self._on_status(f"Model {model_name} ready")
                return True
            err = stderr.decode(errors="replace")[:500]
            self._on_status(f"Pull failed for {model_name}: {err}")
            return False
        except asyncio.TimeoutError:
            self._on_status(f"Pull timed out for {model_name} (10 min limit)")
            return False
        except Exception as exc:
            self._on_status(f"Pull error for {model_name}: {exc}")
            return False

    # ------------------------------------------------------------------
    # GPU driver recommendations
    # ------------------------------------------------------------------

    @staticmethod
    def gpu_driver_recommendations(hardware: HardwareProfile) -> list[str]:
        """Return human-readable driver install recommendations (never auto-installs)."""
        recs: list[str] = []
        if not hardware.has_gpu:
            system = platform.system().lower()
            if system == "linux":
                recs.append(
                    "No GPU detected. For NVIDIA: sudo apt install nvidia-driver-550 "
                    "(https://docs.nvidia.com/cuda/cuda-installation-guide-linux/)"
                )
                recs.append("For AMD: Install ROCm (https://rocm.docs.amd.com/)")
            elif system == "windows":
                recs.append(
                    "No GPU detected. Install latest drivers from: "
                    "NVIDIA: https://www.nvidia.com/download | AMD: https://www.amd.com/support"
                )
        return recs
