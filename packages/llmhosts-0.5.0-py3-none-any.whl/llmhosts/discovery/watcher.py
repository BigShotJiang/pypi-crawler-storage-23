"""Discovery watcher — background daemon for continuous engine and model detection.

Two-tier polling architecture:
- **Model poll** (every 5s): lightweight query on known engines to detect model pulls/removals
- **Engine scan** (every 30s): full UniversalScanner sweep to detect new engines starting or existing ones stopping

Change callbacks update the BackendDispatcher live, so new models appear
in the API within seconds of being pulled.
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Callable

    import httpx

    from llmhosts.discovery.models import DiscoveredEngine
    from llmhosts.discovery.scanner import UniversalScanner

logger = logging.getLogger(__name__)


class DiscoveryWatcher:
    """Background daemon that continuously discovers engines and models.

    Usage::

        watcher = DiscoveryWatcher(
            scanner=UniversalScanner(),
            on_models_changed=lambda engine, models: dispatcher.update_backend_models(...),
            on_engine_discovered=lambda engine: dispatcher.register_backend(...),
            on_engine_lost=lambda engine: dispatcher.unregister_backend(...),
        )
        await watcher.start()
        # ... runs in background ...
        await watcher.stop()
    """

    def __init__(
        self,
        scanner: UniversalScanner,
        *,
        model_interval: float = 5.0,
        engine_interval: float = 30.0,
        on_models_changed: Callable[[DiscoveredEngine, list[str]], Any] | None = None,
        on_engine_discovered: Callable[[DiscoveredEngine], Any] | None = None,
        on_engine_lost: Callable[[DiscoveredEngine], Any] | None = None,
    ) -> None:
        self._scanner = scanner
        self._model_interval = model_interval
        self._engine_interval = engine_interval
        self._on_models_changed = on_models_changed
        self._on_engine_discovered = on_engine_discovered
        self._on_engine_lost = on_engine_lost

        self._known_engines: dict[str, DiscoveredEngine] = {}  # key = "host:port"
        self._model_task: asyncio.Task[None] | None = None
        self._engine_task: asyncio.Task[None] | None = None
        self._stop_event = asyncio.Event()
        self._callback_timeout = 5.0  # max seconds for a callback before we give up

    async def _invoke_callback(self, callback: Any, *args: Any) -> None:
        """Invoke a callback (sync or async) with a timeout guard."""
        try:
            result = callback(*args)
            if asyncio.iscoroutine(result):
                await asyncio.wait_for(result, timeout=self._callback_timeout)
        except asyncio.TimeoutError:
            logger.warning("Callback %s timed out after %.1fs", callback, self._callback_timeout)
        except Exception:
            logger.debug("Callback %s error", callback, exc_info=True)

    @property
    def known_engines(self) -> list[DiscoveredEngine]:
        """Return the current list of known engines."""
        return list(self._known_engines.values())

    @property
    def all_models(self) -> list[str]:
        """Return a flat list of all model IDs across all known engines."""
        models: list[str] = []
        for engine in self._known_engines.values():
            models.extend(m.id for m in engine.models)
        return models

    async def start(self, initial_engines: list[DiscoveredEngine] | None = None) -> None:
        """Start background polling tasks.

        Safe to call multiple times — stops existing tasks before creating new ones.
        """
        # Stop existing tasks to prevent orphan leaks
        if self._model_task or self._engine_task:
            await self.stop()

        if initial_engines:
            for engine in initial_engines:
                key = f"{engine.host}:{engine.port}"
                self._known_engines[key] = engine

        self._stop_event.clear()
        self._model_task = asyncio.create_task(self._model_poll_loop())
        self._engine_task = asyncio.create_task(self._engine_scan_loop())
        logger.info(
            "DiscoveryWatcher started (model_interval=%.1fs, engine_interval=%.1fs, known=%d)",
            self._model_interval,
            self._engine_interval,
            len(self._known_engines),
        )

    async def stop(self) -> None:
        """Stop background polling."""
        self._stop_event.set()
        for task in (self._model_task, self._engine_task):
            if task and not task.done():
                task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await task
        self._model_task = None
        self._engine_task = None
        logger.info("DiscoveryWatcher stopped")

    # ------------------------------------------------------------------
    # Model polling (lightweight, high frequency)
    # ------------------------------------------------------------------

    async def _model_poll_loop(self) -> None:
        """Poll known engines for model list changes."""

        while not self._stop_event.is_set():
            try:
                await asyncio.sleep(self._model_interval)
                if self._stop_event.is_set():
                    break
                await self._poll_models_once()
            except asyncio.CancelledError:
                break
            except Exception:
                logger.debug("Model poll error", exc_info=True)

    async def _poll_models_once(self) -> None:
        """Single model poll across all known engines."""
        import httpx

        async with httpx.AsyncClient(timeout=3.0) as client:
            for key, engine in list(self._known_engines.items()):
                try:
                    current_models = await self._fetch_model_list(client, engine)
                    previous_models = {m.id for m in engine.models}

                    if current_models != previous_models:
                        added = current_models - previous_models
                        removed = previous_models - current_models
                        if added:
                            logger.info("New models on %s: %s", key, added)
                        if removed:
                            logger.info("Removed models on %s: %s", key, removed)

                        # Update cached engine
                        from llmhosts.discovery.models import DiscoveredModel

                        engine.models = [DiscoveredModel(id=m, engine_type=engine.engine_type) for m in current_models]

                        if self._on_models_changed:
                            await self._invoke_callback(self._on_models_changed, engine, sorted(current_models))

                except Exception:
                    logger.debug("Model poll failed for %s", key, exc_info=True)

    async def _fetch_model_list(self, client: httpx.AsyncClient, engine: DiscoveredEngine) -> set[str]:
        """Fetch model IDs from an engine based on its API type."""
        base = engine.base_url
        if engine.api_compat == "ollama":
            resp = await client.get(f"{base}/api/tags")
            resp.raise_for_status()
            return {m.get("name", "") for m in resp.json().get("models", []) if m.get("name")}
        else:
            # OpenAI-compatible: GET /v1/models
            resp = await client.get(f"{base}/v1/models")
            resp.raise_for_status()
            return {m.get("id", "") for m in resp.json().get("data", []) if m.get("id")}

    # ------------------------------------------------------------------
    # Engine scanning (heavier, lower frequency)
    # ------------------------------------------------------------------

    async def _engine_scan_loop(self) -> None:
        """Full engine re-scan at lower frequency."""
        while not self._stop_event.is_set():
            try:
                await asyncio.sleep(self._engine_interval)
                if self._stop_event.is_set():
                    break
                await self._scan_engines_once()
            except asyncio.CancelledError:
                break
            except Exception:
                logger.debug("Engine scan error", exc_info=True)

    async def _scan_engines_once(self) -> None:
        """Single full engine scan."""
        discovered = await self._scanner.scan()
        discovered_keys = {f"{e.host}:{e.port}" for e in discovered}
        current_keys = set(self._known_engines.keys())

        # New engines
        for engine in discovered:
            key = f"{engine.host}:{engine.port}"
            if key not in current_keys:
                self._known_engines[key] = engine
                logger.info("Engine discovered: %s at %s", engine.engine_type, key)
                if self._on_engine_discovered:
                    await self._invoke_callback(self._on_engine_discovered, engine)

        # Lost engines
        for key in current_keys - discovered_keys:
            lost_engine = self._known_engines.pop(key, None)
            if lost_engine:
                logger.info("Engine lost: %s at %s", lost_engine.engine_type, key)
                if self._on_engine_lost:
                    await self._invoke_callback(self._on_engine_lost, lost_engine)
