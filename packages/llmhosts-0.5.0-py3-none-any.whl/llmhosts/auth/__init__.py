"""LLMHosts authentication -- Device Code Flow (RFC 8628) for CLI auth."""
