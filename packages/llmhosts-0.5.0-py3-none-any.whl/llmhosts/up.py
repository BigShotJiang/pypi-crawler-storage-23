"""``llmhosts up`` — Infrastructure Autopilot.

Five-phase pipeline that turns any machine into production AI infrastructure:

1. **Assess**     — Detect hardware + scan all inference engines concurrently
2. **Provision**  — If no engines found, auto-install Ollama + pull a starter model
3. **Start**      — Boot FastAPI proxy, register all discovered backends
4. **Connect**    — Open tunnel + authenticate + register device
5. **Run**        — Background watcher (live model detection) + heartbeat + savings tracking

Three customer flows handled transparently:
- **Clean box**: install Ollama → pull model → start proxy → connect
- **Ollama user**: discover engines + models → register backends → connect
- **Power user**: multi-engine discovery → register all → connect

``pip install llmhosts && llmhosts up`` — that's it.
"""

from __future__ import annotations

import asyncio
import logging
import platform
import signal
from typing import TYPE_CHECKING, Any

import httpx

from llmhosts.auth.device_flow import AuthenticationError, Credentials, DeviceCodeFlow
from llmhosts.discovery.models import DiscoveredEngine, HardwareProfile  # noqa: TC001 — HardwareProfile used at runtime
from llmhosts.discovery.provisioner import EngineProvisioner
from llmhosts.discovery.savings import SavingsTracker
from llmhosts.discovery.scanner import UniversalScanner
from llmhosts.discovery.watcher import DiscoveryWatcher
from llmhosts.proxy.dispatcher import BackendEntry
from llmhosts.tunnel.manager import TunnelManager
from llmhosts.tunnel.models import TunnelConfig

if TYPE_CHECKING:
    from rich.console import Console

logger = logging.getLogger(__name__)

# Heartbeat interval in seconds
_HEARTBEAT_INTERVAL = 30

# Server URL (production)
_DEFAULT_SERVER_URL = "https://llmhosts.com"


def _engine_to_backend_entry(engine: DiscoveredEngine) -> BackendEntry:
    """Convert a discovered engine into a dispatcher BackendEntry."""
    # Ollama uses its own protocol; everything else is OpenAI-compatible
    backend_type = "ollama" if engine.engine_type == "ollama" else engine.engine_type
    return BackendEntry(
        name=f"{engine.engine_type}-{engine.host}:{engine.port}",
        base_url=engine.base_url,
        backend_type=backend_type,
        models=[m.id for m in engine.models],
        priority=0 if engine.host in ("127.0.0.1", "localhost") else 5,
        healthy=engine.available,
    )


class LLMHostUp:
    """Orchestrates the ``llmhosts up`` Infrastructure Autopilot."""

    def __init__(
        self,
        console: Console,
        *,
        server_url: str = _DEFAULT_SERVER_URL,
        port: int = 4000,
        no_tui: bool = True,
        dry_run: bool = False,
    ) -> None:
        self._console = console
        self._server_url = server_url
        self._port = port
        self._no_tui = no_tui
        self._dry_run = dry_run
        self._tunnel_mgr = TunnelManager()
        self._auth_flow = DeviceCodeFlow(server_url=server_url)
        self._credentials: Credentials | None = None
        self._tunnel_url: str | None = None
        self._device_name: str = platform.node() or "my-device"
        self._shutdown_event = asyncio.Event()
        self._heartbeat_task: asyncio.Task[None] | None = None
        self._savings = SavingsTracker()
        self._scanner = UniversalScanner()
        self._watcher: DiscoveryWatcher | None = None
        self._engines: list[DiscoveredEngine] = []
        self._hardware: HardwareProfile | None = None
        self._dispatcher: Any = None  # set during proxy startup

    async def run(self) -> None:
        """Execute the full 5-phase Infrastructure Autopilot pipeline."""
        self._console.print()
        self._console.print("[bold cyan]LLMHosts[/bold cyan] [dim]— Infrastructure Autopilot[/dim]")
        self._console.print()

        # ── Phase 1: Assess ──────────────────────────────────────────
        await self._phase_assess()

        # ── Phase 2: Provision (if needed) ───────────────────────────
        await self._phase_provision()

        # ── Dry-run: stop before starting services ────────────────────
        if self._dry_run:
            self._print_dry_run_summary()
            return

        # ── Phase 3: Start proxy ─────────────────────────────────────
        # (proxy is started inside _run_with_heartbeat)

        # ── Phase 4: Connect ─────────────────────────────────────────
        await self._phase_connect()

        # ── Phase 5: Run ─────────────────────────────────────────────
        await self._phase_run()

    # ==================================================================
    # Phase 1: Assess — hardware detection + universal engine scan
    # ==================================================================

    async def _phase_assess(self) -> None:
        """Detect hardware and scan for all inference engines."""
        from rich.table import Table

        self._console.print("[bold]Phase 1:[/bold] Assessing environment...")

        # Hardware detection
        try:
            from llmhosts.discovery.hardware import HardwareDetector

            self._hardware = await HardwareDetector.detect()
            hw = self._hardware
            gpu_info = ""
            if hw.gpus:
                gpu_parts = [f"{g.name} ({g.vram_total_mb / 1024:.0f}GB)" for g in hw.gpus]
                gpu_info = f"  GPU: {', '.join(gpu_parts)}"
            else:
                gpu_info = "  GPU: None detected (CPU-only mode)"
            self._console.print(f"  RAM: {hw.ram_total_gb:.0f}GB | {gpu_info.strip()}")
        except Exception:
            self._console.print("  [dim]Hardware detection skipped[/dim]")

        # Universal engine scan
        self._console.print("  [dim]Scanning for inference engines...[/dim]")
        self._engines = await self._scanner.scan()

        if self._engines:
            table = Table(show_header=True, header_style="bold", padding=(0, 1))
            table.add_column("Engine", style="cyan")
            table.add_column("Address")
            table.add_column("Models", justify="right")
            table.add_column("Confidence", justify="right")

            total_models = 0
            for eng in self._engines:
                model_count = len(eng.models)
                total_models += model_count
                conf_style = "green" if eng.confidence >= 0.8 else "yellow"
                table.add_row(
                    eng.engine_type,
                    f"{eng.host}:{eng.port}",
                    str(model_count),
                    f"[{conf_style}]{eng.confidence:.0%}[/{conf_style}]",
                )
            self._console.print(table)
            self._console.print(f"  [green]Found {len(self._engines)} engine(s)[/green] with {total_models} model(s)")
        else:
            self._console.print("  [yellow]No inference engines detected[/yellow]")

    # ==================================================================
    # Phase 2: Provision — auto-install engine + pull starter model
    # ==================================================================

    async def _phase_provision(self) -> None:
        """If no engines found, auto-install Ollama and pull a starter model."""
        if self._engines:
            return  # Engines already available, skip provisioning

        self._console.print()
        self._console.print("[bold]Phase 2:[/bold] Provisioning inference engine...")

        hardware = self._hardware
        if not hardware:
            from llmhosts.discovery.models import HardwareProfile

            hardware = HardwareProfile(ram_total_gb=8.0)

        provisioner = EngineProvisioner(
            on_status=lambda msg: self._console.print(f"  [dim]{msg}[/dim]"),
        )

        # Show GPU driver recommendations if needed
        recs = provisioner.gpu_driver_recommendations(hardware)
        for rec in recs:
            self._console.print(f"  [yellow]Tip:[/yellow] {rec}")

        result = await provisioner.provision(hardware)

        if result.success:
            self._console.print(f"  [green]Engine ready[/green] — {result.model_pulled} ({result.model_size_gb:.1f}GB)")
            # Re-scan to pick up the newly provisioned engine
            self._engines = await self._scanner.scan()
        else:
            self._console.print(f"  [red]Provisioning failed:[/red] {result.error}")
            self._console.print("  [dim]You can manually install: https://ollama.com/download[/dim]")

    # ==================================================================
    # Phase 4: Connect — tunnel + authenticate + register device
    # ==================================================================

    async def _phase_connect(self) -> None:
        """Start tunnel, authenticate, and register device."""
        self._console.print()
        self._console.print("[bold]Phase 3:[/bold] Connecting to LLMHosts.com...")

        # Tunnel
        await self._start_tunnel()

        if not self._tunnel_url:
            self._console.print(f"  [yellow]No tunnel — local access only at http://0.0.0.0:{self._port}[/yellow]")

        # Authenticate
        await self._authenticate()

        if self._credentials and self._tunnel_url:
            # Register device with all discovered models
            await self._register_device()

        # Success banner
        self._print_success()

    # ==================================================================
    # Phase 5: Run — proxy + watcher + heartbeat + savings
    # ==================================================================

    async def _phase_run(self) -> None:
        """Start proxy, background watcher, heartbeat, and wait for shutdown."""
        await self._run_with_heartbeat()

    # ------------------------------------------------------------------
    # Tunnel
    # ------------------------------------------------------------------

    async def _start_tunnel(self) -> None:
        """Start a tunnel with auto-detection.

        Tunnel is a paid feature (Pro+). If the current plan does not include
        ``tunnel_public``, this method logs a message and returns without starting.
        """
        from llmhosts.plans import get_plan_limits

        if self._credentials:
            limits = get_plan_limits(self._credentials.plan)
            if not limits.tunnel_public:
                self._console.print(
                    "  [dim]Tunnel requires Pro or higher — skipped.[/dim] [cyan]Upgrade at llmhosts.com/pricing[/cyan]"
                )
                return

        self._console.print("  [dim]Starting tunnel...[/dim]")

        config = TunnelConfig(
            port=self._port,
            funnel=True,
            auth_required=False,
        )

        status = await self._tunnel_mgr.start(config)

        if status.active and status.url:
            self._tunnel_url = status.url
            provider_label = status.provider.value.title()
            self._console.print(f"  [green]Tunnel active[/green] via {provider_label}: {status.url}")
        else:
            error = status.error or "Unknown tunnel error"
            self._console.print(f"  [dim]Tunnel: {error}[/dim]")

    # ------------------------------------------------------------------
    # Authentication
    # ------------------------------------------------------------------

    async def _authenticate(self) -> None:
        """Authenticate with LLMHosts.com via Device Code Flow."""
        existing = await self._auth_flow.load_credentials()
        if existing:
            try:
                async with httpx.AsyncClient(timeout=10.0) as client:
                    resp = await client.get(
                        f"{self._server_url}/api/devices",
                        headers={"Authorization": f"Bearer {existing.api_key}"},
                    )
                    if resp.status_code == 200:
                        # Refresh plan from server so stale cached plan is never used
                        existing = await self._auth_flow.refresh_plan(existing)
                        self._credentials = existing
                        self._console.print(
                            f"  [green]Authenticated[/green] as {existing.email} ({existing.plan} plan)"
                        )
                        return
            except Exception:
                pass

        self._console.print()
        self._console.print("[bold]Authenticate with LLMHosts.com[/bold]")

        try:
            creds = await self._auth_flow.authenticate(
                auto_open_browser=True,
                on_user_code=self._display_auth_code,
            )
            self._credentials = creds
            self._console.print()
            self._console.print(f"  [green]Authenticated[/green] as {creds.email} ({creds.plan} plan)")
        except AuthenticationError as exc:
            self._console.print(f"  [dim]Auth skipped: {exc}[/dim]")

    def _display_auth_code(self, user_code: str, verification_uri: str) -> None:
        """Display the device code for the user."""
        from rich.panel import Panel

        self._console.print()
        self._console.print(
            Panel(
                f"[bold]Open[/bold] [cyan]{verification_uri}[/cyan]\n"
                f"[bold]Enter code:[/bold] [bold yellow]{user_code}[/bold yellow]",
                title="[bold]Authorize This Device[/bold]",
                border_style="blue",
                padding=(1, 2),
            )
        )
        self._console.print("[dim]Waiting for authorization...[/dim]")

    # ------------------------------------------------------------------
    # Device registration
    # ------------------------------------------------------------------

    async def _register_device(self) -> None:
        """Register this device with the LLMHosts.com server."""
        if not self._credentials or not self._tunnel_url:
            return

        self._console.print("  [dim]Registering device...[/dim]")

        hardware_summary = self._format_hardware_summary()
        all_models: list[str] = []
        for eng in self._engines:
            all_models.extend(m.id for m in eng.models)

        try:
            async with httpx.AsyncClient(timeout=15.0) as client:
                resp = await client.post(
                    f"{self._server_url}/api/devices",
                    headers={"Authorization": f"Bearer {self._credentials.api_key}"},
                    json={
                        "name": self._device_name,
                        "tunnel_url": self._tunnel_url,
                        "models": all_models,
                        "hardware": hardware_summary,
                        "engines": [
                            {
                                "type": e.engine_type,
                                "host": e.host,
                                "port": e.port,
                                "models": [m.id for m in e.models],
                            }
                            for e in self._engines
                        ],
                    },
                )
                if resp.status_code in (200, 201):
                    self._console.print(f'  [green]Device registered[/green] as "{self._device_name}"')
                else:
                    self._console.print(f"  [yellow]Registration warning:[/yellow] {resp.text}")
        except Exception as exc:
            self._console.print(f"  [yellow]Registration failed:[/yellow] {exc}")

    def _format_hardware_summary(self) -> str:
        """Format hardware profile as a concise string."""
        if not self._hardware:
            return platform.machine()
        hw = self._hardware
        parts: list[str] = []
        if hw.gpus:
            for gpu in hw.gpus:
                vram_gb = round(gpu.vram_total_mb / 1024, 1)
                parts.append(f"{gpu.name} ({vram_gb}GB)")
        parts.append(f"{hw.ram_total_gb:.0f}GB RAM")
        return ", ".join(parts)

    # ------------------------------------------------------------------
    # Success banner
    # ------------------------------------------------------------------

    def _print_success(self) -> None:
        """Print the success banner with topology and API details."""
        from rich.panel import Panel

        self._console.print()

        # Topology summary
        engine_parts = []
        total_models = 0
        for eng in self._engines:
            count = len(eng.models)
            total_models += count
            engine_parts.append(f"{eng.engine_type} ({count} models)")
        topology = " + ".join(engine_parts) if engine_parts else "No engines"

        # API info
        if self._credentials:
            relay_base = f"{self._server_url}/api/relay/v1"
            api_section = (
                f"\n"
                f"[bold]API Endpoint:[/bold]  [cyan]{relay_base}[/cyan]\n"
                f"[bold]API Key:[/bold]       [dim]{self._credentials.api_key[:20]}...[/dim]\n"
            )
        else:
            api_section = f"\n[bold]Local API:[/bold]     [cyan]http://0.0.0.0:{self._port}/v1[/cyan]\n"

        self._console.print(
            Panel(
                f"[bold green]Your infrastructure is live![/bold green]\n"
                f"\n"
                f"[bold]Topology:[/bold]      {topology}\n"
                f"[bold]Models:[/bold]        {total_models} available\n"
                f"[bold]Device:[/bold]        {self._device_name}\n"
                f"[bold]Tunnel:[/bold]        {self._tunnel_url or 'local only'}"
                f"{api_section}"
                f"\n"
                f"[bold]Savings:[/bold]       Tracking active — every request shows cloud savings\n"
                f"[bold]Discovery:[/bold]     Live — new models detected within 5 seconds",
                title="[bold]LLMHosts — Infrastructure Autopilot[/bold]",
                border_style="green",
                padding=(1, 2),
            )
        )
        self._console.print()
        self._console.print("[dim]Press Ctrl+C to disconnect.[/dim]")
        self._console.print()

    # ------------------------------------------------------------------
    # Dry-run summary
    # ------------------------------------------------------------------

    def _print_dry_run_summary(self) -> None:
        """Print what was discovered without starting any services."""
        from llmhosts.server import LLMHostsServer

        self._console.print()
        self._console.print("[bold green]Dry-run complete.[/bold green] The following was discovered:")

        # Hardware
        if self._hardware:
            hw = self._hardware
            if hw.gpus:
                gpu_parts = [f"{g.name} ({g.vram_total_mb / 1024:.0f}GB)" for g in hw.gpus]
                self._console.print(f"  Hardware: {', '.join(gpu_parts)}, {hw.ram_total_gb:.0f}GB RAM")
            else:
                self._console.print(f"  Hardware: CPU only, {hw.ram_total_gb:.0f}GB RAM")
        else:
            self._console.print("  Hardware: Unknown")

        # Engines
        if self._engines:
            total_models = sum(len(e.models) for e in self._engines)
            self._console.print(f"  Engines: {len(self._engines)} found with {total_models} model(s)")
            for eng in self._engines:
                model_names = ", ".join(m.id for m in eng.models[:5])
                suffix = f" (+{len(eng.models) - 5} more)" if len(eng.models) > 5 else ""
                self._console.print(f"    {eng.engine_type} @ {eng.host}:{eng.port}: {model_names}{suffix}")
        else:
            self._console.print("  Engines: None found (would auto-provision Ollama)")

        self._console.print(f"  Port: {self._port}")
        self._console.print(f"\n[dim]{LLMHostsServer.read_only_notice()}[/dim]")

    # ------------------------------------------------------------------
    # Run loop: proxy + watcher + heartbeat
    # ------------------------------------------------------------------

    async def _run_with_heartbeat(self) -> None:
        """Run proxy, background watcher, heartbeat, and savings tracker."""
        loop = asyncio.get_event_loop()

        def _on_signal() -> None:
            self._shutdown_event.set()

        # add_signal_handler is Unix-only; on Windows fall back to signal.signal
        if platform.system() != "Windows":
            for sig in (signal.SIGINT, signal.SIGTERM):
                loop.add_signal_handler(sig, _on_signal)
        else:
            signal.signal(signal.SIGINT, lambda *_: _on_signal())
            signal.signal(signal.SIGTERM, lambda *_: _on_signal())

        # Start heartbeat
        self._heartbeat_task = asyncio.create_task(self._heartbeat_loop())

        # Start proxy server
        proxy_task = asyncio.create_task(self._run_proxy())

        # Start discovery watcher (detects model pulls/removes within 5s)
        watcher_task = asyncio.create_task(self._run_watcher())

        # Wait for shutdown signal
        await self._shutdown_event.wait()

        # Cleanup
        self._console.print("\n[dim]Shutting down...[/dim]")

        if self._watcher:
            await self._watcher.stop()

        if self._heartbeat_task:
            self._heartbeat_task.cancel()
        proxy_task.cancel()
        watcher_task.cancel()

        # Print final savings
        if self._savings.total_requests > 0:
            self._console.print(f"  [bold]Session savings:[/bold] {self._savings.format_display()}")

        # Mark device offline
        await self._mark_device_offline()

        # Stop tunnel
        await self._tunnel_mgr.stop()

        self._console.print("[dim]Disconnected. Your infrastructure is offline.[/dim]")

    async def _run_watcher(self) -> None:
        """Start the discovery watcher for live model/engine detection."""
        try:
            self._watcher = DiscoveryWatcher(
                scanner=self._scanner,
                on_models_changed=self._on_models_changed,
                on_engine_discovered=self._on_engine_discovered,
                on_engine_lost=self._on_engine_lost,
            )
            await self._watcher.start(initial_engines=self._engines)

            # Keep running until shutdown
            while not self._shutdown_event.is_set():
                await asyncio.sleep(1)
        except asyncio.CancelledError:
            pass

    def _on_models_changed(self, engine: DiscoveredEngine, models: list[str]) -> None:
        """Callback: model list changed on an engine."""
        name = f"{engine.engine_type}-{engine.host}:{engine.port}"
        if self._dispatcher:
            self._dispatcher.update_backend_models(name, models)
        self._console.print(f"  [cyan]Models updated[/cyan] on {engine.engine_type}: {len(models)} model(s)")

    def _on_engine_discovered(self, engine: DiscoveredEngine) -> None:
        """Callback: new engine discovered."""
        entry = _engine_to_backend_entry(engine)
        if self._dispatcher:
            self._dispatcher.register_backend(entry)
        self._console.print(
            f"  [green]Engine discovered:[/green] {engine.engine_type} at "
            f"{engine.host}:{engine.port} ({len(engine.models)} models)"
        )

    def _on_engine_lost(self, engine: DiscoveredEngine) -> None:
        """Callback: engine went offline."""
        name = f"{engine.engine_type}-{engine.host}:{engine.port}"
        if self._dispatcher:
            self._dispatcher.unregister_backend(name)
        self._console.print(f"  [yellow]Engine lost:[/yellow] {engine.engine_type} at {engine.host}:{engine.port}")

    async def _heartbeat_loop(self) -> None:
        """Send heartbeat to server every 30 seconds."""
        while not self._shutdown_event.is_set():
            try:
                await asyncio.sleep(_HEARTBEAT_INTERVAL)
                if self._shutdown_event.is_set():
                    break

                if not self._credentials:
                    continue

                # Collect models from watcher if available
                all_models = []
                if self._watcher:
                    all_models = self._watcher.all_models

                payload: dict[str, Any] = {
                    "name": self._device_name,
                    "tunnel_url": self._tunnel_url,
                    "models": all_models,
                    "status": "online",
                }

                # Include savings data in heartbeat
                if self._savings.total_requests > 0:
                    payload["savings"] = self._savings.summary()

                async with httpx.AsyncClient(timeout=10.0) as client:
                    hb_resp = await client.post(
                        f"{self._server_url}/api/devices/heartbeat",
                        headers={"Authorization": f"Bearer {self._credentials.api_key}"},
                        json=payload,
                    )
                    logger.debug("Heartbeat sent")

                # Detect plan downgrade from heartbeat response
                if hb_resp.status_code == 200:
                    from llmhosts.plans import get_plan_limits

                    hb_data = hb_resp.json()
                    live_plan = hb_data.get("plan", self._credentials.plan)
                    if live_plan != self._credentials.plan:
                        old_plan = self._credentials.plan
                        self._credentials = await self._auth_flow.refresh_plan(self._credentials)
                        limits = get_plan_limits(live_plan)
                        if not limits.tunnel_public and self._tunnel_url:
                            # Plan no longer includes tunnel — stop it
                            self._console.print(
                                f"  [yellow]Plan downgraded[/yellow] {old_plan} → {live_plan}. "
                                "Tunnel stopped. Upgrade at llmhosts.com/pricing"
                            )
                            await self._tunnel_mgr.stop()
                            self._tunnel_url = None
                        else:
                            self._console.print(f"  [dim]Plan updated[/dim] {old_plan} → {live_plan}")
            except asyncio.CancelledError:
                break
            except Exception as exc:
                logger.debug("Heartbeat failed: %s", exc)

    async def _run_proxy(self) -> None:
        """Run the local FastAPI proxy server with all discovered backends registered."""
        try:
            from llmhosts.config import load_config
            from llmhosts.server import LLMHostsServer

            config = load_config()
            config.server.port = self._port
            config.server.host = "0.0.0.0"  # nosec B104 — must bind all interfaces for tunnel/LAN
            config.dashboard.tui = False

            server = LLMHostsServer(config)
            await server.startup()

            if server._app is None:
                logger.error("Server app failed to initialize")
                return

            # Register discovered engines with the dispatcher
            if hasattr(server, "_dispatcher") and server._dispatcher:
                self._dispatcher = server._dispatcher
                for engine in self._engines:
                    entry = _engine_to_backend_entry(engine)
                    self._dispatcher.register_backend(entry)

            import uvicorn

            uvi_config = uvicorn.Config(
                server._app,
                host=config.server.host,
                port=config.server.port,
                log_level="warning",
            )
            uvi_server = uvicorn.Server(uvi_config)
            await uvi_server.serve()
        except asyncio.CancelledError:
            pass
        except Exception as exc:
            logger.error("Proxy server error: %s", exc)

    async def _mark_device_offline(self) -> None:
        """Mark device as offline on the server."""
        if not self._credentials:
            return
        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                await client.post(
                    f"{self._server_url}/api/devices/heartbeat",
                    headers={"Authorization": f"Bearer {self._credentials.api_key}"},
                    json={
                        "name": self._device_name,
                        "status": "offline",
                    },
                )
        except Exception:
            pass  # Best-effort
