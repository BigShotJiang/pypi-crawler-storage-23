"""Anonymized routing telemetry for LLMHosts Data Flywheel.

Opt-in, privacy-first telemetry that captures anonymized routing events
to improve the router over time.  Query text is never stored — only a
SHA-256 hash is persisted locally in SQLite.
"""
