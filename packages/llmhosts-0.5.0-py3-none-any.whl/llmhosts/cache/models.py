"""LLMHosts cache data models -- Pydantic v2 schemas for cache entries and statistics."""

from __future__ import annotations

from typing import TYPE_CHECKING

from pydantic import BaseModel, ConfigDict

if TYPE_CHECKING:
    from datetime import datetime


class CacheEntry(BaseModel):
    """A single cached response keyed by SHA-256 hash of the normalized prompt."""

    model_config = ConfigDict(frozen=False)

    cache_key: str  # SHA-256 hex digest
    model: str
    prompt_hash: str  # same as cache_key (kept for clarity in queries)
    response_json: str  # serialized JSON response body
    created_at: datetime
    expires_at: datetime
    hit_count: int = 0
    last_hit_at: datetime | None = None
    size_bytes: int


class CacheStats(BaseModel):
    """Aggregate statistics for the exact-hash cache layer."""

    total_entries: int
    total_size_bytes: int
    hit_count: int
    miss_count: int
    hit_rate: float  # 0.0-1.0
    eviction_count: int = 0
    entries_by_model: dict[str, int]
    oldest_entry: datetime | None
    newest_entry: datetime | None
