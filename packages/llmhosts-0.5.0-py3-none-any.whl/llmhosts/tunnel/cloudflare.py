"""Cloudflare Tunnel provider (Quick Tunnel and Named Tunnel).

Quick Tunnel (default): ``cloudflared tunnel --url localhost:4000``
  - Generates a random ``*.trycloudflare.com`` URL
  - No account needed, free, but URL changes each restart

Named Tunnel: requires a Cloudflare account and pre-configured tunnel.
  - Stable URL with custom domain
  - ``cloudflared tunnel run <tunnel-name>``

We default to Quick Tunnel for zero-config UX.
"""

from __future__ import annotations

import asyncio
import logging
import re
from datetime import datetime, timezone

from llmhosts.tunnel.models import TunnelProvider, TunnelStatus

logger = logging.getLogger(__name__)

_URL_PATTERN = re.compile(r"https://[a-zA-Z0-9-]+\.trycloudflare\.com")
_URL_WAIT_TIMEOUT = 30.0  # seconds to wait for URL to appear in output
_PROCESS_KILL_TIMEOUT = 5.0


class CloudflareTunnel:
    """Manage a Cloudflare Quick Tunnel or Named Tunnel.

    The cloudflared process runs as a long-lived subprocess.  We monitor
    its stdout/stderr for the generated URL.
    """

    def __init__(self) -> None:
        self._process: asyncio.subprocess.Process | None = None
        self._url: str | None = None
        self._active: bool = False
        self._started_at: datetime | None = None
        self._port: int = 4000
        self._output_lines: list[str] = []

    async def start(self, port: int = 4000, hostname: str | None = None) -> TunnelStatus:
        """Start a Cloudflare tunnel.

        For quick tunnel (hostname is None):
            ``cloudflared tunnel --url http://localhost:{port}``
        For named tunnel:
            ``cloudflared tunnel run --url http://localhost:{port} {hostname}``

        Parses output to find the ``*.trycloudflare.com`` URL.
        Runs cloudflared as a long-lived background subprocess.
        """
        self._port = port

        if hostname:
            cmd = ["cloudflared", "tunnel", "run", "--url", f"http://localhost:{port}", hostname]
        else:
            cmd = ["cloudflared", "tunnel", "--url", f"http://localhost:{port}"]

        try:
            self._process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
        except OSError as exc:
            return TunnelStatus(
                provider=TunnelProvider.CLOUDFLARE,
                active=False,
                local_port=port,
                error=f"Failed to start cloudflared: {exc}",
            )

        # cloudflared writes the URL to stderr; wait for it
        url = await self._wait_for_url()

        if url:
            self._url = url
            self._active = True
            self._started_at = datetime.now(tz=timezone.utc)
            logger.info("Cloudflare tunnel started: %s -> localhost:%d", url, port)
            return TunnelStatus(
                provider=TunnelProvider.CLOUDFLARE,
                active=True,
                url=url,
                local_port=port,
                started_at=self._started_at,
                pid=self._process.pid,
            )

        # Failed to get URL -- check if process died
        error = "Timed out waiting for tunnel URL"
        if self._process.returncode is not None:
            error = f"cloudflared exited with code {self._process.returncode}"
            if self._output_lines:
                # Include last few lines of output for debugging
                tail = "\n".join(self._output_lines[-5:])
                error += f"\n{tail}"

        await self._kill_process()
        return TunnelStatus(
            provider=TunnelProvider.CLOUDFLARE,
            active=False,
            local_port=port,
            error=error,
        )

    async def _wait_for_url(self) -> str | None:
        """Read stderr from cloudflared until we find the trycloudflare URL."""
        if not self._process or not self._process.stderr:
            return None

        try:
            deadline = asyncio.get_event_loop().time() + _URL_WAIT_TIMEOUT
            while asyncio.get_event_loop().time() < deadline:
                # Check if process has exited
                if self._process.returncode is not None:
                    break

                try:
                    line_bytes = await asyncio.wait_for(
                        self._process.stderr.readline(),
                        timeout=min(2.0, deadline - asyncio.get_event_loop().time()),
                    )
                except asyncio.TimeoutError:
                    continue

                if not line_bytes:
                    break  # EOF

                line = line_bytes.decode(errors="replace").strip()
                if line:
                    self._output_lines.append(line)
                    logger.debug("cloudflared: %s", line)

                    match = _URL_PATTERN.search(line)
                    if match:
                        return match.group(0)

        except Exception as exc:
            logger.debug("Error reading cloudflared output: %s", exc)

        return None

    async def stop(self) -> None:
        """Stop the cloudflared subprocess gracefully."""
        await self._kill_process()
        self._active = False
        self._url = None
        self._started_at = None
        self._output_lines.clear()
        logger.info("Cloudflare tunnel stopped")

    async def _kill_process(self) -> None:
        """Terminate the cloudflared process, escalating to SIGKILL if needed."""
        if not self._process:
            return

        pid = self._process.pid
        if self._process.returncode is not None:
            # Already exited
            self._process = None
            return

        try:
            # Try graceful SIGTERM first
            self._process.terminate()
            try:
                await asyncio.wait_for(self._process.wait(), timeout=_PROCESS_KILL_TIMEOUT)
            except asyncio.TimeoutError:
                # Escalate to SIGKILL
                logger.warning("cloudflared (pid=%s) did not exit after SIGTERM, sending SIGKILL", pid)
                self._process.kill()
                await asyncio.wait_for(self._process.wait(), timeout=2.0)
        except ProcessLookupError:
            pass  # Already gone
        except Exception as exc:
            logger.warning("Error killing cloudflared (pid=%s): %s", pid, exc)
        finally:
            self._process = None

    async def status(self) -> TunnelStatus:
        """Check if the tunnel process is still running."""
        if self._process and self._process.returncode is None:
            return TunnelStatus(
                provider=TunnelProvider.CLOUDFLARE,
                active=True,
                url=self._url,
                local_port=self._port,
                started_at=self._started_at,
                pid=self._process.pid,
            )

        # Process exited or was never started
        if self._active:
            # Was active but process died unexpectedly
            self._active = False
            return TunnelStatus(
                provider=TunnelProvider.CLOUDFLARE,
                active=False,
                url=None,
                local_port=self._port,
                error="cloudflared process exited unexpectedly",
            )

        return TunnelStatus(
            provider=TunnelProvider.CLOUDFLARE,
            active=False,
            local_port=self._port,
        )

    async def get_url(self) -> str | None:
        """Get the tunnel URL."""
        return self._url
