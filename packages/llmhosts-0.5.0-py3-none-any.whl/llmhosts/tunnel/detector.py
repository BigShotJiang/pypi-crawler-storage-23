"""Detect available tunnel providers on the system."""

from __future__ import annotations

import asyncio
import json
import logging
import re
import shutil

from llmhosts.tunnel.models import CloudflareInfo, TailscaleInfo, TunnelProvider

logger = logging.getLogger(__name__)

_CMD_TIMEOUT = 10.0  # seconds


class TunnelDetector:
    """Detect which tunnel tools are installed and ready."""

    @staticmethod
    async def detect() -> list[TunnelProvider]:
        """Return available providers in priority order (best first).

        Priority:
          1. Tailscale -- zero-config P2P VPN, mesh access
          2. Cloudflare -- free quick tunnels, public URLs
        """
        providers: list[TunnelProvider] = []

        ts_info, cf_info = await asyncio.gather(
            TunnelDetector.check_tailscale(),
            TunnelDetector.check_cloudflare(),
            return_exceptions=True,
        )

        # Tailscale: must be installed AND connected to the tailnet
        if isinstance(ts_info, TailscaleInfo) and ts_info.installed and ts_info.connected:
            providers.append(TunnelProvider.TAILSCALE)
        elif isinstance(ts_info, TailscaleInfo) and ts_info.installed:
            logger.info("Tailscale installed but not connected -- skipping")

        # Cloudflare: just needs the binary
        if isinstance(cf_info, CloudflareInfo) and cf_info.installed:
            providers.append(TunnelProvider.CLOUDFLARE)

        return providers

    @staticmethod
    async def check_tailscale() -> TailscaleInfo:
        """Check Tailscale status: installed, connected, hostname, IP."""
        if not shutil.which("tailscale"):
            return TailscaleInfo(installed=False)

        info = TailscaleInfo(installed=True)

        try:
            proc = await asyncio.create_subprocess_exec(
                "tailscale",
                "status",
                "--json",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=_CMD_TIMEOUT)

            if proc.returncode != 0:
                logger.debug("tailscale status failed (rc=%s): %s", proc.returncode, stderr.decode().strip())
                return info

            data = json.loads(stdout.decode())

            # BackendState "Running" means connected
            backend_state = data.get("BackendState", "")
            info.connected = backend_state == "Running"
            info.version = data.get("Version", None)

            # Self node info
            self_node = data.get("Self", {})
            if self_node:
                # HostName is the machine's Tailscale hostname
                info.hostname = self_node.get("HostName", None)
                # DNSName is the full FQDN in the tailnet
                dns_name = self_node.get("DNSName", "")
                if dns_name:
                    # Strip trailing dot
                    info.dns_name = dns_name.rstrip(".")
                # TailscaleIPs is a list of IPs (v4 and v6)
                ts_ips = self_node.get("TailscaleIPs", [])
                if ts_ips:
                    # Prefer IPv4 (100.x.y.z)
                    for ip in ts_ips:
                        if ip.startswith("100."):
                            info.tailnet_ip = ip
                            break
                    if not info.tailnet_ip:
                        info.tailnet_ip = ts_ips[0]

        except asyncio.TimeoutError:
            logger.debug("tailscale status timed out")
        except (OSError, json.JSONDecodeError) as exc:
            logger.debug("tailscale status failed: %s", exc)

        return info

    @staticmethod
    async def check_cloudflare() -> CloudflareInfo:
        """Check cloudflared status: installed, version."""
        if not shutil.which("cloudflared"):
            return CloudflareInfo(installed=False)

        info = CloudflareInfo(installed=True)

        try:
            proc = await asyncio.create_subprocess_exec(
                "cloudflared",
                "--version",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=_CMD_TIMEOUT)

            # cloudflared prints version to stderr or stdout depending on version
            output = (stdout.decode() + stderr.decode()).strip()
            # e.g. "cloudflared version 2024.1.5 (built 2024-01-22-1455 ...)"
            match = re.search(r"(\d+\.\d+\.\d+)", output)
            if match:
                info.version = match.group(1)

            # Check if credentials exist (~/.cloudflared/cert.pem)
            from pathlib import Path

            cert_path = Path.home() / ".cloudflared" / "cert.pem"
            info.has_credentials = cert_path.exists()

        except asyncio.TimeoutError:
            logger.debug("cloudflared --version timed out")
        except OSError as exc:
            logger.debug("cloudflared version check failed: %s", exc)

        return info
