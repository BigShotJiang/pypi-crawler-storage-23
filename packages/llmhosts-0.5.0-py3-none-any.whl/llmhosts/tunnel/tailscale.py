"""Tailscale Serve / Funnel tunnel provider.

Tailscale Serve exposes a local port to your private Tailnet (mesh VPN).
Tailscale Funnel exposes it to the public internet (requires approval in
the Tailscale admin console).

This is the *preferred* provider: zero-config, encrypted, fast P2P.
"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone

from llmhosts.tunnel.detector import TunnelDetector
from llmhosts.tunnel.models import TunnelProvider, TunnelStatus

logger = logging.getLogger(__name__)

_CMD_TIMEOUT = 15.0


class TailscaleTunnel:
    """Manage a Tailscale Serve/Funnel tunnel."""

    def __init__(self) -> None:
        self._active: bool = False
        self._url: str | None = None
        self._started_at: datetime | None = None
        self._funnel: bool = False
        self._port: int = 4000

    async def start(self, port: int = 4000, funnel: bool = False) -> TunnelStatus:
        """Start Tailscale Serve or Funnel.

        Serve: ``tailscale serve --bg --https=443 http://localhost:{port}``
        Funnel: ``tailscale funnel --bg --https=443 http://localhost:{port}``

        Returns a :class:`TunnelStatus` with the accessible URL.
        """
        self._port = port
        self._funnel = funnel

        # Get the Tailscale DNS name for constructing the URL
        ts_info = await TunnelDetector.check_tailscale()
        if not ts_info.connected:
            return TunnelStatus(
                provider=TunnelProvider.TAILSCALE,
                active=False,
                local_port=port,
                error="Tailscale is not connected. Run 'tailscale up' first.",
            )

        # Build the command
        subcmd = "funnel" if funnel else "serve"
        cmd = ["tailscale", subcmd, "--bg", "--https=443", f"http://localhost:{port}"]

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=_CMD_TIMEOUT)

            if proc.returncode != 0:
                error_msg = stderr.decode().strip() or stdout.decode().strip()
                logger.error("tailscale %s failed (rc=%s): %s", subcmd, proc.returncode, error_msg)
                return TunnelStatus(
                    provider=TunnelProvider.TAILSCALE,
                    active=False,
                    local_port=port,
                    error=f"tailscale {subcmd} failed: {error_msg}",
                )

            # Build the URL from the DNS name
            self._url = f"https://{ts_info.dns_name}" if ts_info.dns_name else None
            self._active = True
            self._started_at = datetime.now(tz=timezone.utc)

            logger.info("Tailscale %s started: %s -> localhost:%d", subcmd, self._url, port)

            return TunnelStatus(
                provider=TunnelProvider.TAILSCALE,
                active=True,
                url=self._url,
                local_port=port,
                started_at=self._started_at,
            )

        except asyncio.TimeoutError:
            return TunnelStatus(
                provider=TunnelProvider.TAILSCALE,
                active=False,
                local_port=port,
                error=f"tailscale {subcmd} timed out after {_CMD_TIMEOUT}s",
            )
        except OSError as exc:
            return TunnelStatus(
                provider=TunnelProvider.TAILSCALE,
                active=False,
                local_port=port,
                error=f"Failed to run tailscale: {exc}",
            )

    async def stop(self) -> None:
        """Stop the tunnel: ``tailscale serve off``."""
        subcmd = "funnel" if self._funnel else "serve"
        try:
            proc = await asyncio.create_subprocess_exec(
                "tailscale",
                subcmd,
                "off",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            await asyncio.wait_for(proc.communicate(), timeout=_CMD_TIMEOUT)
            logger.info("Tailscale %s stopped", subcmd)
        except (asyncio.TimeoutError, OSError) as exc:
            logger.warning("Failed to stop tailscale %s: %s", subcmd, exc)
        finally:
            self._active = False
            self._url = None
            self._started_at = None

    async def status(self) -> TunnelStatus:
        """Check if the tunnel is active by running ``tailscale serve status``."""
        try:
            proc = await asyncio.create_subprocess_exec(
                "tailscale",
                "serve",
                "status",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, _stderr = await asyncio.wait_for(proc.communicate(), timeout=_CMD_TIMEOUT)

            output = stdout.decode().strip()
            # If output contains our port, the serve is active
            if output and f"localhost:{self._port}" in output:
                url = await self.get_url()
                return TunnelStatus(
                    provider=TunnelProvider.TAILSCALE,
                    active=True,
                    url=url or self._url,
                    local_port=self._port,
                    started_at=self._started_at,
                )

            return TunnelStatus(
                provider=TunnelProvider.TAILSCALE,
                active=False,
                local_port=self._port,
            )

        except (asyncio.TimeoutError, OSError) as exc:
            logger.debug("tailscale serve status failed: %s", exc)
            return TunnelStatus(
                provider=TunnelProvider.TAILSCALE,
                active=self._active,
                url=self._url,
                local_port=self._port,
                started_at=self._started_at,
                error=str(exc),
            )

    async def get_url(self) -> str | None:
        """Get the tunnel URL from Tailscale status."""
        if self._url:
            return self._url
        ts_info = await TunnelDetector.check_tailscale()
        if ts_info.dns_name:
            return f"https://{ts_info.dns_name}"
        return None
