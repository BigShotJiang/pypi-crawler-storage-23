"""LLMHosts TUI dashboard -- real-time terminal monitoring for the proxy."""

from __future__ import annotations

from llmhosts.dashboard.app import LLMHostsDashboard, run_dashboard
from llmhosts.dashboard.theme import (
    COLORS,
    format_cost,
    format_latency,
    format_savings_percent,
    format_tokens,
    format_uptime,
)
from llmhosts.dashboard.widgets import (
    BackendsWidget,
    HeaderWidget,
    MetricsWidget,
    RequestEntry,
    RequestLogWidget,
    SavingsWidget,
)

__all__ = [
    "COLORS",
    "BackendsWidget",
    "HeaderWidget",
    "LLMHostsDashboard",
    "MetricsWidget",
    "RequestEntry",
    "RequestLogWidget",
    "SavingsWidget",
    "format_cost",
    "format_latency",
    "format_savings_percent",
    "format_tokens",
    "format_uptime",
    "run_dashboard",
]
