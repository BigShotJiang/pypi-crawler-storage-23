"""Pydantic v2 models for multi-device mesh management."""

from __future__ import annotations

from datetime import datetime  # noqa: TC003 -- Pydantic needs this at runtime
from enum import Enum

from pydantic import BaseModel, Field


class DeviceRole(str, Enum):
    """Role a device plays in the mesh."""

    COMPUTE = "compute"  # Has GPU, serves inference
    CLIENT = "client"  # Consumes inference
    HYBRID = "hybrid"  # Both serves and consumes


class Device(BaseModel):
    """A single device registered in the LLMHosts mesh."""

    id: str  # UUID
    name: str  # User-friendly name (e.g., "home-desktop")
    hostname: str  # Network hostname
    role: DeviceRole
    tunnel_url: str | None = None  # Tailscale/CF URL for this device
    hardware_summary: str = ""  # "RTX 4090 (24GB), 64GB RAM"
    models: list[str] = Field(default_factory=list)  # Ollama models available
    last_seen: datetime | None = None
    is_local: bool = False  # True if this is the current device
    healthy: bool = True
    latency_ms: float | None = None  # Measured round-trip


class DeviceRegistration(BaseModel):
    """Payload for registering a new device in the mesh."""

    name: str
    role: DeviceRole = DeviceRole.HYBRID
    tunnel_url: str | None = None


class MeshStatus(BaseModel):
    """Aggregate health status of the entire mesh."""

    local_device: Device | None = None
    remote_devices: list[Device] = Field(default_factory=list)
    total_models: int = 0
    total_gpu_vram_gb: float = 0.0
    mesh_healthy: bool = True
