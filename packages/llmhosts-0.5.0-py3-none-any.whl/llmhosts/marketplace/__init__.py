"""Marketplace router — node selection engine for Phase 5.

Fetches nodes from a configurable catalog URL (e.g. GET /api/marketplace/nodes),
filters by model availability, ranks by price then latency, and registers
remote backends with the dispatcher using rank as priority.
Catalog response may include reputation_score (0-100) per node for future ranking.
"""

from llmhosts.marketplace.reputation import (
    compute_reputation_score,
    reputation_score_from_node,
    reputation_score_with_uptime,
    reputation_tier,
)
from llmhosts.marketplace.router import (
    fetch_nodes,
    filter_by_model,
    load_and_register,
    rank_nodes,
)

__all__ = [
    "compute_reputation_score",
    "fetch_nodes",
    "filter_by_model",
    "load_and_register",
    "rank_nodes",
    "reputation_score_from_node",
    "reputation_score_with_uptime",
    "reputation_tier",
]
