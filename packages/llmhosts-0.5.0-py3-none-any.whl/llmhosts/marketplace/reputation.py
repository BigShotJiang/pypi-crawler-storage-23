"""Marketplace device reputation score (Phase 5, issue 290).

MVP formula: 50 (base) + online bonus (25 if online and recent) + latency bonus
(25 if <100ms, 10 if <500ms). Range 50-100 when we have status/latency; offline
or stale last_seen removes online bonus. No P95/success-rate history yet.

Staleness: last_seen older than STALE_SECONDS is treated as not recent.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

STALE_SECONDS = 5 * 60  # 5 minutes


def compute_reputation_score(
    status: str | None,
    latency_ms: int | float | None,
    last_seen: datetime | str | None,
) -> int:
    """Compute 0-100 reputation score from device status, latency, and last_seen.

    Online + recent + low latency => up to 100; offline or stale => no online bonus.
    """
    now = datetime.now(timezone.utc)
    if last_seen is None:
        recent = False
    elif isinstance(last_seen, str):
        try:
            dt = datetime.fromisoformat(last_seen.replace("Z", "+00:00"))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            recent = (now - dt).total_seconds() <= STALE_SECONDS
        except (ValueError, TypeError):
            recent = False
    else:
        if last_seen.tzinfo is None:
            last_seen = last_seen.replace(tzinfo=timezone.utc)
        recent = (now - last_seen).total_seconds() <= STALE_SECONDS

    online = (status or "").strip().lower() == "online"
    online_bonus = 25 if (online and recent) else 0

    latency_bonus = 0
    if latency_ms is not None:
        try:
            lat = float(latency_ms)
            if lat < 100:
                latency_bonus = 25
            elif lat < 500:
                latency_bonus = 10
        except (TypeError, ValueError):
            pass

    score = 50 + online_bonus + latency_bonus
    return max(0, min(100, round(score)))


def reputation_score_from_node(node: dict[str, Any]) -> int:
    """Compute reputation from a catalog node dict (status, latency_ms, last_seen)."""
    return compute_reputation_score(
        status=node.get("status"),
        latency_ms=node.get("latency_ms"),
        last_seen=node.get("last_seen"),
    )


# Reputation tiers (Phase 5B, issue #308): Unverified < 50, Standard 50-79, Verified 80-94, Elite 95-100
REPUTATION_TIER_UNVERIFIED = "Unverified"
REPUTATION_TIER_STANDARD = "Standard"
REPUTATION_TIER_VERIFIED = "Verified"
REPUTATION_TIER_ELITE = "Elite"


def reputation_tier(score: int | float) -> str:
    """Map 0-100 score to tier: Unverified (<50), Standard (50-79), Verified (80-94), Elite (95-100)."""
    s = round(score)
    if s < 50:
        return REPUTATION_TIER_UNVERIFIED
    if s < 80:
        return REPUTATION_TIER_STANDARD
    if s < 95:
        return REPUTATION_TIER_VERIFIED
    return REPUTATION_TIER_ELITE


def reputation_score_with_uptime(
    status: str | None,
    latency_ms: int | float | None,
    last_seen: datetime | str | None,
    uptime_pct: float | None,
) -> int:
    """Compute 0-100 score; when uptime_pct is available, blend with compute_reputation_score.

    Formula: 0.6 * base_score + 0.4 * uptime_pct (clamped 0-100). When uptime_pct
    is None, returns same as compute_reputation_score.
    """
    base = compute_reputation_score(status, latency_ms, last_seen)
    if uptime_pct is None:
        return base
    blended = 0.6 * base + 0.4 * uptime_pct
    return max(0, min(100, round(blended)))
