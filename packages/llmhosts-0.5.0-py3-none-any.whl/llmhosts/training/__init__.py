"""LLMHosts training package — ModernBERT LoRA fine-tuning pipeline.

Provides data curation, synthetic data generation, LoRA fine-tuning,
evaluation, weight registry, automatic update checks, and A/B rollout
infrastructure for the ModernBERT routing classifier.

Usage (requires ``[full]`` extras: torch, transformers, peft, datasets)::

    from llmhosts.training import SyntheticDataGenerator, LoRATrainer, TrainerConfig
    from llmhosts.training import RouterEvaluator, WeightRegistry

    gen = SyntheticDataGenerator()
    examples = gen.generate(n_samples=10_000)

    config = TrainerConfig(epochs=3)
    trainer = LoRATrainer()
    result = trainer.train(examples, config)

    registry = WeightRegistry()
    manifest = registry.register(result)

Privacy note: The telemetry system stores only SHA-256 query hashes.
Training therefore relies on synthetic data, never real user queries.
"""

from __future__ import annotations

from llmhosts.training.ab_rollout import ABRollout
from llmhosts.training.curator import (
    COMPLEXITY_LABELS,
    DOMAIN_LABELS,
    PRIVACY_LABELS,
    QUALITY_LABELS,
    DataCurator,
    TrainingExample,
)
from llmhosts.training.evaluator import EvalResult, RouterEvaluator
from llmhosts.training.registry import WeightManifest, WeightRegistry
from llmhosts.training.synthetic import SyntheticDataGenerator
from llmhosts.training.trainer import TRAINING_AVAILABLE, LoRATrainer, TrainerConfig, TrainingResult
from llmhosts.training.updater import UpdateResult, WeightUpdater

__all__ = [
    "COMPLEXITY_LABELS",
    "DOMAIN_LABELS",
    "PRIVACY_LABELS",
    "QUALITY_LABELS",
    "TRAINING_AVAILABLE",
    "ABRollout",
    "DataCurator",
    "EvalResult",
    "LoRATrainer",
    "RouterEvaluator",
    "SyntheticDataGenerator",
    "TrainerConfig",
    "TrainingExample",
    "TrainingResult",
    "UpdateResult",
    "WeightManifest",
    "WeightRegistry",
    "WeightUpdater",
]
