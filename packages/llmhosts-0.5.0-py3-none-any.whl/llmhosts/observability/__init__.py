"""LLMHosts observability package -- distributed tracing, metrics, and logging.

This package provides optional OpenTelemetry integration for distributed tracing,
Sentry error tracking, structured JSON logging, and PII redaction.

All external dependencies are optional and guarded with try/except imports.
"""

from __future__ import annotations

from llmhosts.observability.logging import (
    PII_PATTERNS,
    JsonFormatter,
    init_observability,
    redact_pii,
)
from llmhosts.observability.tracing import TracingConfig, TracingMiddleware, get_tracer, init_tracing

__all__ = [
    "PII_PATTERNS",
    "JsonFormatter",
    "TracingConfig",
    "TracingMiddleware",
    "get_tracer",
    "init_observability",
    "init_tracing",
    "redact_pii",
]
