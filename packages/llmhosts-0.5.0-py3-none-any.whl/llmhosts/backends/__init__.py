"""LLMHosts backends -- Ollama (local) and LiteLLM (cloud) inference routing."""

from __future__ import annotations

from llmhosts.backends.litellm_backend import LITELLM_AVAILABLE, CloudModelInfo, LiteLLMBackend
from llmhosts.backends.manager import BackendInfo, BackendManager, BackendType

__all__ = [
    "LITELLM_AVAILABLE",
    "BackendInfo",
    "BackendManager",
    "BackendType",
    "CloudModelInfo",
    "LiteLLMBackend",
]
