"""LLMHosts Hive Mode -- GPU pooling with friends.

Pro-tier feature: share GPU resources in a private pool.
Privacy-tiered routing, karma system, invite-based membership.
"""

from __future__ import annotations

from llmhosts.hive.karma import KarmaEngine
from llmhosts.hive.manager import HiveManager
from llmhosts.hive.models import (
    Hive,
    HiveInvite,
    HiveMember,
    HiveRole,
    HiveRoutingDecision,
    KarmaUpdate,
    PrivacyClassification,
    PrivacyTier,
)
from llmhosts.hive.privacy import PrivacyClassifier
from llmhosts.hive.router import HiveRouter
from llmhosts.hive.sharing import can_share_model

__all__ = [
    "Hive",
    "HiveInvite",
    "HiveManager",
    "HiveMember",
    "HiveRole",
    "HiveRouter",
    "HiveRoutingDecision",
    "KarmaEngine",
    "KarmaUpdate",
    "PrivacyClassification",
    "PrivacyClassifier",
    "PrivacyTier",
    "can_share_model",
]
