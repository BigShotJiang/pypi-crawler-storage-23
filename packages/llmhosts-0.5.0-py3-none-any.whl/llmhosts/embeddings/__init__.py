"""LLMHosts embeddings -- ONNX-based embedding pipeline for the kNN router.

Requires the ``[smart]`` pip tier::

    pip install llmhosts[smart]

Provides:
- :class:`EmbeddingPipeline`: all-MiniLM-L6-v2 via ONNX Runtime (~96MB, <15ms)
- :class:`EmbeddingStore`: FAISS + SQLite persistence for routing data
- :data:`EMBEDDINGS_AVAILABLE`: ``True`` when runtime deps are present
"""

from __future__ import annotations

from llmhosts.embeddings.pipeline import EMBEDDINGS_AVAILABLE, EmbeddingPipeline, SimpleTokenizer
from llmhosts.embeddings.store import EmbeddingMetadata, EmbeddingStore, SearchResult, StoreStats

__all__ = [
    "EMBEDDINGS_AVAILABLE",
    "EmbeddingMetadata",
    "EmbeddingPipeline",
    "EmbeddingStore",
    "SearchResult",
    "SimpleTokenizer",
    "StoreStats",
]
