"""Hive LLM client -- real model invocation for agent reasoning."""
