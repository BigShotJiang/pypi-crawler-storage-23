"""Hive git operations -- real subprocess-based git commands."""
