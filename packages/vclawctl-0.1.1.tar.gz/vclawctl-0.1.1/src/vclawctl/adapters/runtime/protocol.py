"""Runtime protocol models for control API."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(slots=True)
class RuntimeRequest:
    namespace: str
    method: str
    params: dict[str, Any]


@dataclass(slots=True)
class RuntimeResponse:
    ok: bool
    payload: dict[str, Any]
