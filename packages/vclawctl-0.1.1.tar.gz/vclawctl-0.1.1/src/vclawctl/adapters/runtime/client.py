"""HTTP runtime client for v-claw local control API."""

from __future__ import annotations

import json
from typing import Any
from urllib import error as urlerror
from urllib import request as urlrequest

from vclawctl.errors import CLIError


def _validate_method(raw_method: str) -> str:
    method = str(raw_method or "").strip()
    if not method:
        raise CLIError("method is required", code="invalid_method")
    namespace, dot, op = method.partition(".")
    if not dot or not namespace.strip() or not op.strip():
        raise CLIError("method must be namespace.method", code="invalid_method")
    return f"{namespace.strip()}.{op.strip()}"


class RuntimeClient:
    def __init__(
        self,
        *,
        base_url: str,
        auth_token: str,
        timeout_seconds: float = 10.0,
    ) -> None:
        self._base_url = str(base_url or "").rstrip("/")
        self._auth_token = str(auth_token or "").strip()
        self._timeout_seconds = float(timeout_seconds)

    def call(self, method: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        if not self._base_url:
            raise CLIError("api base url is required", code="api_base_url_required")
        if not self._auth_token:
            raise CLIError("auth token is required", code="auth_token_required")
        normalized_method = _validate_method(method)

        payload = {
            "method": normalized_method,
            "params": params or {},
        }
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        req = urlrequest.Request(
            f"{self._base_url}/call",
            data=body,
            method="POST",
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self._auth_token}",
            },
        )

        try:
            with urlrequest.urlopen(req, timeout=self._timeout_seconds) as resp:
                raw = resp.read().decode("utf-8")
        except urlerror.HTTPError as exc:
            detail = ""
            try:
                detail = exc.read().decode("utf-8")
            except Exception:  # noqa: BLE001
                detail = ""
            raise CLIError(
                f"runtime http error: status={exc.code} body={detail}".strip(),
                code="runtime_http_error",
            ) from exc
        except urlerror.URLError as exc:
            raise CLIError(
                f"runtime unavailable: {exc.reason}",
                code="runtime_unavailable",
            ) from exc

        try:
            parsed = json.loads(raw) if raw else {}
        except Exception as exc:  # noqa: BLE001
            raise CLIError(
                "runtime response is not valid json",
                code="runtime_invalid_json",
            ) from exc
        if not isinstance(parsed, dict):
            raise CLIError("runtime response must be object", code="runtime_invalid_response")
        return parsed
