"""Adapters namespace."""
