"""Module entrypoint for `python -m vclawctl`."""

from vclawctl.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
