"""Chat/session-global command handlers."""

from __future__ import annotations

from typing import Any

from vclawctl.adapters.sqlite.db import connect, read_config_json, upsert_config_json
from vclawctl.commands.transport import invoke
from vclawctl.context import CLIContext
from vclawctl.errors import CLIError


def _chat_cfg(config: dict[str, Any]) -> dict[str, Any]:
    raw = config.get("chat")
    return dict(raw) if isinstance(raw, dict) else {}


def _state_payload(conn: Any, cfg: dict[str, Any]) -> dict[str, Any]:
    chat_cfg = _chat_cfg(cfg)
    session_id = str(chat_cfg.get("main_session_id") or "").strip()
    default_agent_id = str(chat_cfg.get("default_agent_id") or "default").strip() or "default"

    status: dict[str, Any]
    if not session_id:
        status = {
            "status": "idle",
            "messages": [],
            "current_cycle": 0,
            "total_cycles": 0,
            "token_usage": {},
            "error": None,
            "progress": [],
            "final_answer": "",
        }
    else:
        row = conn.execute(
            "SELECT * FROM task_history WHERE session_id = ? LIMIT 1",
            (session_id,),
        ).fetchone()
        if not row:
            status = {
                "status": "idle",
                "messages": [],
                "current_cycle": 0,
                "total_cycles": 0,
                "token_usage": {},
                "error": None,
                "progress": [],
                "final_answer": "",
            }
        else:
            import json

            status = {
                "status": str(row["status"] or "idle"),
                "messages": [],
                "current_cycle": int(row["cycles_count"] or 0),
                "total_cycles": int(row["cycles_count"] or 0),
                "token_usage": json.loads(str(row["token_usage_json"] or "{}")),
                "error": None,
                "progress": json.loads(str(row["progress_json"] or "[]")),
                "final_answer": str(row["final_answer"] or ""),
                "task_id": str(row["task_id"]),
            }

    return {
        "ok": True,
        "mode": "chat",
        "default_agent_id": default_agent_id,
        "session_id": session_id,
        "status": status,
    }


def get_state(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    del params
    with connect(ctx.db_path) as conn:
        cfg = read_config_json(conn)
        return _state_payload(conn, cfg)


def reset_session(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    del params
    with connect(ctx.db_path, write=True) as conn:
        cfg = read_config_json(conn)
        chat_cfg = _chat_cfg(cfg)
        chat_cfg["main_session_id"] = ""
        chat_cfg["default_agent_id"] = (
            str(chat_cfg.get("default_agent_id") or "default") or "default"
        )
        cfg["chat"] = chat_cfg
        upsert_config_json(conn, cfg)
    return {"ok": True, "session_id": ""}


def set_default_agent(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    agent_id = str(params.get("agent_id") or "").strip()
    if not agent_id:
        raise CLIError("agent_id is required", code="missing_required")

    with connect(ctx.db_path, write=True) as conn:
        row = conn.execute(
            "SELECT agent_id FROM agent_profiles WHERE agent_id = ? LIMIT 1",
            (agent_id,),
        ).fetchone()
        if not row and agent_id != "default":
            raise CLIError(f"Agent not found: {agent_id}", code="not_found")

        cfg = read_config_json(conn)
        chat_cfg = _chat_cfg(cfg)
        chat_cfg["default_agent_id"] = agent_id
        cfg["chat"] = chat_cfg
        upsert_config_json(conn, cfg)
        return _state_payload(conn, cfg)


def set_main_session(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    session_id = str(params.get("session_id") or "").strip()
    with connect(ctx.db_path, write=True) as conn:
        cfg = read_config_json(conn)
        chat_cfg = _chat_cfg(cfg)
        chat_cfg["main_session_id"] = session_id
        cfg["chat"] = chat_cfg
        upsert_config_json(conn, cfg)
        return {"ok": True, "session_id": session_id}


def dispatch(method: str, params: dict[str, Any], ctx: CLIContext) -> dict[str, Any]:
    handlers = {
        "get_state": get_state,
        "reset_session": reset_session,
        "set_default_agent": set_default_agent,
        "set_main_session": set_main_session,
    }
    handler = handlers.get(method)
    if not handler:
        raise CLIError(f"Unknown chat method: {method}", code="unknown_method")
    return handler(ctx, params)


def _invoke_chat(method: str, params: dict[str, Any], ctx: CLIContext) -> dict[str, Any]:
    return invoke(
        method=f"chat.{method}",
        params=params,
        ctx=ctx,
        local_call=lambda: dispatch(method, params, ctx),
    )


def register(subparsers: Any) -> None:
    parser = subparsers.add_parser("chat", help="Manage chat-level state")
    chat_sub = parser.add_subparsers(dest="chat_cmd", required=True)

    state_parser = chat_sub.add_parser("state", help="Show chat state")
    state_parser.set_defaults(func=_cmd_state)

    reset_parser = chat_sub.add_parser("reset", help="Reset current main chat session")
    reset_parser.add_argument("--yes", action="store_true")
    reset_parser.set_defaults(func=_cmd_reset)

    default_agent_parser = chat_sub.add_parser("set-default-agent", help="Set default chat agent")
    default_agent_parser.add_argument("--agent-id", required=True)
    default_agent_parser.set_defaults(func=_cmd_set_default_agent)

    main_session_parser = chat_sub.add_parser("set-main-session", help="Set main session id")
    main_session_parser.add_argument("--session-id", required=True)
    main_session_parser.set_defaults(func=_cmd_set_main_session)


def _cmd_state(args: Any, ctx: CLIContext) -> dict[str, Any]:
    del args
    return _invoke_chat("get_state", {}, ctx)


def _cmd_reset(args: Any, ctx: CLIContext) -> dict[str, Any]:
    if not args.yes:
        raise CLIError("reset requires --yes", code="confirmation_required")
    return _invoke_chat("reset_session", {}, ctx)


def _cmd_set_default_agent(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {"agent_id": args.agent_id}
    return _invoke_chat("set_default_agent", params, ctx)


def _cmd_set_main_session(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {"session_id": args.session_id}
    return invoke(
        method="settings.update_config",
        params={"config": {"chat": {"main_session_id": args.session_id}}},
        ctx=ctx,
        local_call=lambda: dispatch("set_main_session", params, ctx),
    )
