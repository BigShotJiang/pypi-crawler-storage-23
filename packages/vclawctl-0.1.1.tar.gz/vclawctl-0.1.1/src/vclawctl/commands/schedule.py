"""Schedule command handlers."""

from __future__ import annotations

import re
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any

from vclawctl.adapters.sqlite.db import connect, loads_json
from vclawctl.commands.transport import invoke
from vclawctl.context import CLIContext
from vclawctl.domain.validators import normalize_positive_int, parse_bool, parse_json_object
from vclawctl.errors import CLIError

_NOTIFY_POLICIES = {"none", "announce", "direct", "webhook", "explicit_only"}
_DELAY_PATTERN = re.compile(r"(?i)^\s*(\d+)\s*([smhd]?)\s*$")
_DELAY_UNITS = {"": 1, "s": 1, "m": 60, "h": 3600, "d": 86400}


def _parse_once_at(raw_at: Any) -> float | None:
    if raw_at is None or isinstance(raw_at, bool):
        return None
    if isinstance(raw_at, (int, float)):
        return float(raw_at)

    text = str(raw_at).strip()
    if not text:
        return None
    try:
        return float(text)
    except ValueError:
        pass

    normalized = text
    if normalized.endswith("Z"):
        normalized = f"{normalized[:-1]}+00:00"
    try:
        dt = datetime.fromisoformat(normalized)
    except ValueError:
        return None
    return dt.timestamp()


def _normalize_notify_policy(raw: Any) -> str:
    value = str(raw or "").strip().lower() or "announce"
    if value not in _NOTIFY_POLICIES:
        raise CLIError(
            "notify_policy must be one of none|announce|direct|webhook|explicit_only",
            code="invalid_notify_policy",
        )
    return value


def _parse_delay_seconds(raw_after: Any) -> int:
    text = str(raw_after or "").strip().lower()
    if not text:
        raise CLIError(
            "--after is required when using quick one-time create",
            code="missing_required",
        )
    match = _DELAY_PATTERN.fullmatch(text)
    if not match:
        raise CLIError(
            "--after must be a positive duration like 30s, 5m, 2h, 1d, or plain seconds",
            code="invalid_after",
        )

    value = int(match.group(1))
    if value <= 0:
        raise CLIError("--after must be > 0", code="invalid_after")
    unit = str(match.group(2) or "").lower()
    return value * _DELAY_UNITS[unit]


def _build_delayed_once_params(args: Any) -> dict[str, Any]:
    name = str(args.name or "").strip()
    prompt = str(args.prompt or "").strip()
    after_raw = str(args.after or "").strip()
    if not name or not prompt or not after_raw:
        raise CLIError(
            "Use --params-json, or provide --name --prompt --after for quick one-time create",
            code="missing_required",
        )

    delay_seconds = _parse_delay_seconds(after_raw)
    run_at = datetime.now(timezone.utc) + timedelta(seconds=delay_seconds)
    at_iso = run_at.isoformat(timespec="seconds").replace("+00:00", "Z")
    return {
        "name": name,
        "prompt": prompt,
        "schedule_type": "once",
        "schedule_config": {"at": at_iso},
    }


def _row_to_task(row: Any) -> dict[str, Any]:
    return {
        "task_id": str(row["task_id"]),
        "name": str(row["name"]),
        "schedule_type": str(row["schedule_type"]),
        "schedule_config": loads_json(row["schedule_config_json"], {}),
        "prompt": str(row["prompt"] or ""),
        "agent_profile": str(row["agent_profile"] or "default"),
        "max_cycles": int(row["max_cycles"] or 20),
        "enabled": bool(int(row["enabled"] or 0)),
        "timezone": str(row["timezone"] or "Asia/Shanghai"),
        "target_main_session_id": str(row["target_main_session_id"] or ""),
        "notify_policy": str(row["notify_policy"] or "announce"),
        "notify_on_success": bool(
            int(row["notify_on_success"] if row["notify_on_success"] is not None else 1)
        ),
        "notify_on_error": bool(
            int(row["notify_on_error"] if row["notify_on_error"] is not None else 1)
        ),
        "last_run_at": float(row["last_run_at"]) if row["last_run_at"] is not None else None,
        "last_status": str(row["last_status"]) if row["last_status"] is not None else None,
        "next_run_at": float(row["next_run_at"]) if row["next_run_at"] is not None else None,
        "created_at": float(row["created_at"]),
    }


def _row_to_execution(row: Any) -> dict[str, Any]:
    return {
        "execution_id": str(row["execution_id"]),
        "task_id": str(row["task_id"]),
        "started_at": float(row["started_at"]),
        "finished_at": float(row["finished_at"]) if row["finished_at"] is not None else None,
        "status": str(row["status"] or ""),
        "result": str(row["result"] or ""),
        "error": str(row["error"] or ""),
        "run_session_id": str(row["run_session_id"] or ""),
        "run_task_id": str(row["run_task_id"] or ""),
        "delivery_requested": bool(int(row["delivery_requested"] or 0)),
        "delivery_attempted": bool(int(row["delivery_attempted"] or 0)),
        "delivery_status": str(row["delivery_status"] or ""),
        "delivery_error": str(row["delivery_error"] or ""),
        "delivered_at": float(row["delivered_at"]) if row["delivered_at"] is not None else None,
    }


def _validate_schedule(schedule_type: str, schedule_config: dict[str, Any]) -> None:
    if schedule_type == "once":
        at_ts = _parse_once_at(schedule_config.get("at"))
        if at_ts is None:
            raise CLIError(
                (
                    "For schedule_type='once', schedule_config.at is required. "
                    "Use ISO-8601 datetime string or unix timestamp seconds."
                ),
                code="invalid_schedule",
            )
    elif schedule_type == "interval":
        try:
            every = float(schedule_config.get("every_seconds", 0) or 0)
        except Exception:  # noqa: BLE001
            every = 0
        if every <= 0:
            raise CLIError(
                "For schedule_type='interval', schedule_config.every_seconds must be > 0",
                code="invalid_schedule",
            )
    elif schedule_type == "cron":
        expr = str(schedule_config.get("expr", "") or "").strip()
        if not expr:
            raise CLIError(
                "For schedule_type='cron', schedule_config.expr is required",
                code="invalid_schedule",
            )


def list_tasks(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    task_id = str(params.get("task_id") or "").strip()
    with connect(ctx.db_path) as conn:
        if task_id:
            row = conn.execute(
                "SELECT * FROM scheduled_tasks WHERE task_id = ? LIMIT 1",
                (task_id,),
            ).fetchone()
            return {"tasks": [_row_to_task(row)] if row else []}
        rows = conn.execute(
            "SELECT * FROM scheduled_tasks ORDER BY created_at ASC"
        ).fetchall()
        return {"tasks": [_row_to_task(row) for row in rows]}


def create_task(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    name = str(params.get("name") or "").strip()
    prompt = str(params.get("prompt") or "").strip()
    schedule_type = str(params.get("schedule_type") or "").strip().lower()
    schedule_config = params.get("schedule_config", {})

    if not name or not prompt:
        raise CLIError("name and prompt are required", code="missing_required")
    if schedule_type not in {"once", "interval", "cron"}:
        raise CLIError(
            "schedule_type must be one of once|interval|cron",
            code="invalid_schedule_type",
        )
    if not isinstance(schedule_config, dict):
        raise CLIError("schedule_config must be object", code="invalid_schedule_config")

    _validate_schedule(schedule_type, schedule_config)

    task_id = str(params.get("task_id") or "").strip() or uuid.uuid4().hex[:8]
    agent_profile = str(params.get("agent_profile") or "default").strip() or "default"
    max_cycles = normalize_positive_int(params.get("max_cycles"), default=20)
    enabled = parse_bool(params.get("enabled"), default=True)
    timezone = str(params.get("timezone") or "").strip() or "Asia/Shanghai"
    target_main_session_id = str(params.get("target_main_session_id") or "").strip()
    notify_policy = _normalize_notify_policy(params.get("notify_policy"))
    notify_on_success = parse_bool(params.get("notify_on_success"), default=True)
    notify_on_error = parse_bool(params.get("notify_on_error"), default=True)

    with connect(ctx.db_path, write=True) as conn:
        conn.execute(
            """
            INSERT INTO scheduled_tasks(
                task_id, name, schedule_type, schedule_config_json,
                prompt, agent_profile, max_cycles, enabled, timezone,
                target_main_session_id, notify_policy, notify_on_success, notify_on_error,
                last_run_at, last_status, next_run_at, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, strftime('%s', 'now'))
            """,
            (
                task_id,
                name,
                schedule_type,
                __import__("json").dumps(schedule_config, ensure_ascii=False),
                prompt,
                agent_profile,
                int(max_cycles),
                int(enabled),
                timezone,
                target_main_session_id,
                notify_policy,
                int(notify_on_success),
                int(notify_on_error),
                None,
                None,
                None,
            ),
        )
    return {"task_id": task_id}


def update_task(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    task_id = str(params.get("task_id") or "").strip()
    updates = params.get("updates", {})
    if not task_id:
        raise CLIError("task_id required", code="missing_required")
    if not isinstance(updates, dict):
        raise CLIError("updates must be object", code="invalid_updates")

    allowed = {
        "name",
        "schedule_type",
        "schedule_config",
        "prompt",
        "agent_profile",
        "max_cycles",
        "enabled",
        "timezone",
        "target_main_session_id",
        "notify_policy",
        "notify_on_success",
        "notify_on_error",
        "last_run_at",
        "last_status",
        "next_run_at",
    }
    normalized: dict[str, Any] = {}
    for key, value in updates.items():
        if key not in allowed:
            continue
        normalized[key] = value

    if "schedule_type" in normalized:
        normalized["schedule_type"] = str(normalized["schedule_type"] or "").strip().lower()
        if normalized["schedule_type"] not in {"once", "interval", "cron"}:
            raise CLIError(
                "schedule_type must be one of once|interval|cron",
                code="invalid_schedule_type",
            )

    if "schedule_config" in normalized and not isinstance(normalized["schedule_config"], dict):
        raise CLIError("schedule_config must be object", code="invalid_schedule_config")

    effective_schedule_type = str(normalized.get("schedule_type") or "").strip().lower()
    if "schedule_config" in normalized:
        if not effective_schedule_type:
            with connect(ctx.db_path) as conn:
                row = conn.execute(
                    "SELECT schedule_type FROM scheduled_tasks WHERE task_id = ? LIMIT 1",
                    (task_id,),
                ).fetchone()
                if not row:
                    return {"ok": False}
                effective_schedule_type = str(row["schedule_type"] or "").strip().lower()
        _validate_schedule(effective_schedule_type, normalized["schedule_config"])

    if "max_cycles" in normalized:
        normalized["max_cycles"] = normalize_positive_int(normalized.get("max_cycles"), default=20)
    if "enabled" in normalized:
        normalized["enabled"] = int(parse_bool(normalized.get("enabled"), default=True))
    if "notify_policy" in normalized:
        normalized["notify_policy"] = _normalize_notify_policy(normalized.get("notify_policy"))
    if "notify_on_success" in normalized:
        normalized["notify_on_success"] = int(
            parse_bool(normalized.get("notify_on_success"), default=True)
        )
    if "notify_on_error" in normalized:
        normalized["notify_on_error"] = int(
            parse_bool(normalized.get("notify_on_error"), default=True)
        )
    if "schedule_config" in normalized:
        normalized["schedule_config_json"] = __import__("json").dumps(
            normalized.pop("schedule_config"), ensure_ascii=False
        )

    if not normalized:
        raise CLIError("no valid update fields", code="empty_updates")

    columns = ", ".join(f"{key} = ?" for key in normalized.keys())
    values = list(normalized.values()) + [task_id]
    with connect(ctx.db_path, write=True) as conn:
        cur = conn.execute(
            f"UPDATE scheduled_tasks SET {columns} WHERE task_id = ?",
            tuple(values),
        )
        return {"ok": bool(cur.rowcount)}


def toggle_task(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    task_id = str(params.get("task_id") or "").strip()
    if not task_id:
        raise CLIError("task_id required", code="missing_required")

    with connect(ctx.db_path, write=True) as conn:
        row = conn.execute(
            "SELECT enabled FROM scheduled_tasks WHERE task_id = ? LIMIT 1",
            (task_id,),
        ).fetchone()
        if not row:
            return {"ok": False}
        next_enabled = 0 if int(row["enabled"] or 0) else 1
        cur = conn.execute(
            "UPDATE scheduled_tasks SET enabled = ? WHERE task_id = ?",
            (next_enabled, task_id),
        )
        return {"ok": bool(cur.rowcount), "enabled": bool(next_enabled)}


def delete_task(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    task_id = str(params.get("task_id") or "").strip()
    if not task_id:
        raise CLIError("task_id required", code="missing_required")
    with connect(ctx.db_path, write=True) as conn:
        cur = conn.execute("DELETE FROM scheduled_tasks WHERE task_id = ?", (task_id,))
        return {"ok": bool(cur.rowcount)}


def get_history(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    task_id = str(params.get("task_id") or "").strip()
    limit = normalize_positive_int(params.get("limit"), default=20)
    with connect(ctx.db_path) as conn:
        if task_id:
            rows = conn.execute(
                """
                SELECT * FROM schedule_executions
                WHERE task_id = ?
                ORDER BY started_at DESC
                LIMIT ?
                """,
                (task_id, limit),
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM schedule_executions ORDER BY started_at DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return {"history": [_row_to_execution(row) for row in rows]}


def get_status(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    del params
    with connect(ctx.db_path) as conn:
        row = conn.execute(
            (
                "SELECT COUNT(*) AS total, "
                "SUM(CASE WHEN enabled = 1 THEN 1 ELSE 0 END) AS enabled "
                "FROM scheduled_tasks"
            )
        ).fetchone()
    total = int(row["total"] or 0)
    enabled = int(row["enabled"] or 0)
    return {
        "status": {
            "running": False,
            "task_count": total,
            "enabled_count": enabled,
            "active_hours": None,
            "source": "offline_db",
        }
    }


def get_delivery_status(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    execution_id = str(params.get("execution_id") or "").strip()
    task_id = str(params.get("task_id") or "").strip()
    limit = normalize_positive_int(params.get("limit"), default=20)

    where: list[str] = []
    values: list[Any] = []
    if task_id:
        where.append("task_id = ?")
        values.append(task_id)
    if execution_id:
        where.append("execution_id = ?")
        values.append(execution_id)

    where_clause = f"WHERE {' AND '.join(where)}" if where else ""
    with connect(ctx.db_path) as conn:
        rows = conn.execute(
            f"""
            SELECT * FROM schedule_executions
            {where_clause}
            ORDER BY started_at DESC
            LIMIT ?
            """,
            tuple(values + [limit]),
        ).fetchall()

    history = [_row_to_execution(row) for row in rows]
    if execution_id:
        return {"execution": history[0] if history else None, "history": history}
    return {"history": history}


def dispatch(method: str, params: dict[str, Any], ctx: CLIContext) -> dict[str, Any]:
    handlers = {
        "list_tasks": list_tasks,
        "create_task": create_task,
        "update_task": update_task,
        "toggle_task": toggle_task,
        "delete_task": delete_task,
        "get_history": get_history,
        "get_status": get_status,
        "get_delivery_status": get_delivery_status,
    }
    handler = handlers.get(method)
    if not handler:
        raise CLIError(f"Unknown schedule method: {method}", code="unknown_method")
    return handler(ctx, params)


def _invoke_schedule(method: str, params: dict[str, Any], ctx: CLIContext) -> dict[str, Any]:
    return invoke(
        method=f"schedule.{method}",
        params=params,
        ctx=ctx,
        local_call=lambda: dispatch(method, params, ctx),
    )


def register(subparsers: Any) -> None:
    parser = subparsers.add_parser("schedule", help="Manage scheduled tasks")
    schedule_sub = parser.add_subparsers(dest="schedule_cmd", required=True)

    list_parser = schedule_sub.add_parser("list", help="List scheduled tasks")
    list_parser.add_argument("--task-id", default="")
    list_parser.set_defaults(func=_cmd_list)

    create_parser = schedule_sub.add_parser("create", help="Create a scheduled task")
    create_parser.add_argument(
        "--params-json",
        default="",
        help="JSON payload for create (legacy/full mode)",
    )
    create_parser.add_argument("--name", default="", help="Task name (quick one-time mode)")
    create_parser.add_argument("--prompt", default="", help="Task prompt (quick one-time mode)")
    create_parser.add_argument(
        "--after",
        default="",
        help="Delay before one-time run, e.g. 30s, 5m, 2h, 1d, or plain seconds",
    )
    create_parser.set_defaults(func=_cmd_create)

    update_parser = schedule_sub.add_parser("update", help="Update a scheduled task")
    update_parser.add_argument("--task-id", required=True)
    update_parser.add_argument("--updates-json", required=True)
    update_parser.set_defaults(func=_cmd_update)

    toggle_parser = schedule_sub.add_parser("toggle", help="Toggle enabled flag")
    toggle_parser.add_argument("--task-id", required=True)
    toggle_parser.set_defaults(func=_cmd_toggle)

    delete_parser = schedule_sub.add_parser("delete", help="Delete scheduled task")
    delete_parser.add_argument("--task-id", required=True)
    delete_parser.add_argument("--yes", action="store_true", help="Confirm delete")
    delete_parser.set_defaults(func=_cmd_delete)

    history_parser = schedule_sub.add_parser("history", help="Show execution history")
    history_parser.add_argument("--task-id", default="")
    history_parser.add_argument("--limit", type=int, default=20)
    history_parser.set_defaults(func=_cmd_history)

    status_parser = schedule_sub.add_parser("status", help="Show schedule status")
    status_parser.set_defaults(func=_cmd_status)

    delivery_parser = schedule_sub.add_parser("delivery", help="Show delivery status")
    delivery_parser.add_argument("--task-id", default="")
    delivery_parser.add_argument("--execution-id", default="")
    delivery_parser.add_argument("--limit", type=int, default=20)
    delivery_parser.set_defaults(func=_cmd_delivery)


def _cmd_list(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {"task_id": args.task_id}
    return _invoke_schedule("list_tasks", params, ctx)


def _cmd_create(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params_json = str(args.params_json or "").strip()
    has_quick_args = any(
        str(value or "").strip() for value in (args.name, args.prompt, args.after)
    )
    if params_json:
        if has_quick_args:
            raise CLIError(
                "Do not mix --params-json with --name/--prompt/--after",
                code="invalid_arguments",
            )
        params = parse_json_object(params_json, field_name="params_json")
    else:
        params = _build_delayed_once_params(args)
    return _invoke_schedule("create_task", params, ctx)


def _cmd_update(args: Any, ctx: CLIContext) -> dict[str, Any]:
    updates = parse_json_object(args.updates_json, field_name="updates_json")
    params = {"task_id": args.task_id, "updates": updates}
    return _invoke_schedule("update_task", params, ctx)


def _cmd_toggle(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {"task_id": args.task_id}
    return _invoke_schedule("toggle_task", params, ctx)


def _cmd_delete(args: Any, ctx: CLIContext) -> dict[str, Any]:
    if not args.yes:
        raise CLIError("delete requires --yes", code="confirmation_required")
    params = {"task_id": args.task_id}
    return _invoke_schedule("delete_task", params, ctx)


def _cmd_history(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {"task_id": args.task_id, "limit": args.limit}
    return _invoke_schedule("get_history", params, ctx)


def _cmd_status(args: Any, ctx: CLIContext) -> dict[str, Any]:
    del args
    return _invoke_schedule("get_status", {}, ctx)


def _cmd_delivery(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {
        "task_id": args.task_id,
        "execution_id": args.execution_id,
        "limit": args.limit,
    }
    return _invoke_schedule("get_delivery_status", params, ctx)
