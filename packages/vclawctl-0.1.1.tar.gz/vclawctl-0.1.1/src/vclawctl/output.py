"""JSON output helpers."""

from __future__ import annotations

import json
from typing import Any


def success_payload(data: Any) -> dict[str, Any]:
    return {
        "ok": True,
        "data": data,
        "error": "",
        "code": "",
    }


def error_payload(*, message: str, code: str) -> dict[str, Any]:
    return {
        "ok": False,
        "data": {},
        "error": message,
        "code": code,
    }


def emit(payload: dict[str, Any], *, pretty: bool) -> None:
    if pretty:
        print(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True))
        return
    print(json.dumps(payload, ensure_ascii=False))
