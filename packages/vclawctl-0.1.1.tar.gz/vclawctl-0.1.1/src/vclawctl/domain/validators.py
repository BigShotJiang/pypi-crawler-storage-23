"""Reusable validators and normalizers."""

from __future__ import annotations

import json
from typing import Any

from vclawctl.errors import CLIError

TRUE_SET = {"1", "true", "yes", "on"}
FALSE_SET = {"0", "false", "no", "off"}


def parse_json_object(raw: str, *, field_name: str) -> dict[str, Any]:
    try:
        payload = json.loads(raw)
    except Exception as exc:  # noqa: BLE001
        raise CLIError(f"{field_name} is not valid JSON: {exc}", code="invalid_json") from exc
    if not isinstance(payload, dict):
        raise CLIError(f"{field_name} must be a JSON object", code="invalid_json_type")
    return payload


def parse_bool(raw: Any, *, default: bool) -> bool:
    if isinstance(raw, bool):
        return raw
    if raw is None:
        return default
    if isinstance(raw, (int, float)):
        return bool(raw)
    text = str(raw).strip().lower()
    if text in TRUE_SET:
        return True
    if text in FALSE_SET:
        return False
    return default


def normalize_positive_int(raw: Any, *, default: int) -> int:
    try:
        value = int(raw if raw is not None else default)
    except Exception:  # noqa: BLE001
        value = default
    if value <= 0:
        value = default
    return value


def parse_json_value(raw: str, *, field_name: str) -> Any:
    try:
        return json.loads(raw)
    except Exception as exc:  # noqa: BLE001
        raise CLIError(f"{field_name} is not valid JSON: {exc}", code="invalid_json") from exc
