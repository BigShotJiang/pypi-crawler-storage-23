from __future__ import annotations

import json
from datetime import datetime, timezone

from vclawctl.cli import main


def _run_cli(args: list[str], capsys):
    code = main(["--mode", "db", *args])
    out = capsys.readouterr().out.strip()
    payload = json.loads(out) if out else {}
    return code, payload


def test_config_set_get_and_patch(data_dir, capsys):
    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "config",
            "set",
            "--key",
            "chat.default_agent_id",
            "--value-json",
            '"assistant-a"',
        ],
        capsys,
    )
    assert code == 0
    assert payload["ok"] is True

    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "config",
            "get",
            "--key",
            "chat.default_agent_id",
        ],
        capsys,
    )
    assert code == 0
    assert payload["data"]["value"] == "assistant-a"

    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "config",
            "patch",
            "--params-json",
            '{"agent": {"language": "en-US"}}',
        ],
        capsys,
    )
    assert code == 0
    assert payload["ok"] is True


def test_schedule_create_list_toggle_delete(data_dir, capsys):
    params = (
        '{'
        '"name":"nightly",'
        '"schedule_type":"interval",'
        '"schedule_config":{"every_seconds":300},'
        '"prompt":"run report"'
        '}'
    )
    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "schedule",
            "create",
            "--params-json",
            params,
        ],
        capsys,
    )
    assert code == 0
    task_id = payload["data"]["task_id"]

    code, payload = _run_cli(
        ["--data-dir", str(data_dir), "schedule", "list", "--task-id", task_id],
        capsys,
    )
    assert code == 0
    assert payload["data"]["tasks"][0]["task_id"] == task_id

    code, payload = _run_cli(
        ["--data-dir", str(data_dir), "schedule", "toggle", "--task-id", task_id],
        capsys,
    )
    assert code == 0
    assert payload["data"]["ok"] is True

    code, payload = _run_cli(
        ["--data-dir", str(data_dir), "schedule", "delete", "--task-id", task_id, "--yes"],
        capsys,
    )
    assert code == 0
    assert payload["data"]["ok"] is True


def test_schedule_create_once_with_after_shortcut(data_dir, capsys):
    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "schedule",
            "create",
            "--name",
            "once-hi",
            "--prompt",
            "Hi",
            "--after",
            "2m",
        ],
        capsys,
    )
    assert code == 0
    task_id = payload["data"]["task_id"]

    code, payload = _run_cli(
        ["--data-dir", str(data_dir), "schedule", "list", "--task-id", task_id],
        capsys,
    )
    assert code == 0
    task = payload["data"]["tasks"][0]
    assert task["schedule_type"] == "once"
    at_text = task["schedule_config"]["at"]
    run_at = datetime.fromisoformat(at_text.replace("Z", "+00:00"))
    delay_seconds = (run_at - datetime.now(timezone.utc)).total_seconds()
    assert 60 <= delay_seconds <= 180


def test_schedule_create_rejects_mixed_params_json_and_after(data_dir, capsys):
    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "schedule",
            "create",
            "--params-json",
            '{"name":"once-hi","prompt":"Hi","schedule_type":"once","schedule_config":{"at":"2026-03-01T12:00:00Z"}}',
            "--after",
            "30s",
        ],
        capsys,
    )
    assert code == 2
    assert payload["code"] == "invalid_arguments"


def test_agent_create_update_delete(data_dir, capsys):
    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "agent",
            "create",
            "--params-json",
            '{"name":"ops-agent","tools":["memory_search","schedule_task"]}',
        ],
        capsys,
    )
    assert code == 0
    agent_id = payload["data"]["agent"]["agent_id"]
    tools = payload["data"]["agent"]["tools"]
    assert "schedule_task" not in tools

    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "agent",
            "update",
            "--agent-id",
            agent_id,
            "--updates-json",
            '{"language":"en-US","max_cycles":9}',
        ],
        capsys,
    )
    assert code == 0
    assert payload["data"]["agent"]["language"] == "en-US"
    assert payload["data"]["agent"]["max_cycles"] == 9

    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "agent",
            "delete",
            "--agent-id",
            agent_id,
            "--yes",
        ],
        capsys,
    )
    assert code == 0
    assert payload["data"]["ok"] is True


def test_task_and_session_queries(data_dir, capsys):
    db_path = data_dir / "v_claw.db"
    import sqlite3
    import time

    conn = sqlite3.connect(db_path)
    conn.execute(
        """
        INSERT INTO task_history(
            task_id, agent_id, session_id, title, prompt,
            session_kind, workspace_path, workspace_source,
            status, cycles_count, created_at, finished_at,
            is_favorite, progress_json, final_answer,
            token_usage_json, agent_name, model_name, parent_task_id, is_sub_task
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            "task-main",
            "default",
            "sess-1",
            "T1",
            "hello",
            "task",
            "",
            "global_default",
            "completed",
            3,
            time.time(),
            time.time(),
            0,
            "[]",
            "done",
            '{"input_tokens": 12, "output_tokens": 4}',
            "",
            "",
            "",
            0,
        ),
    )
    conn.commit()
    conn.close()

    code, payload = _run_cli(
        ["--data-dir", str(data_dir), "task", "get", "--task-id", "task-main"],
        capsys,
    )
    assert code == 0
    assert payload["data"]["task"]["session_id"] == "sess-1"

    code, payload = _run_cli(
        ["--data-dir", str(data_dir), "session", "token", "--session-id", "sess-1"],
        capsys,
    )
    assert code == 0
    assert payload["data"]["token_usage"]["input_tokens"] == 12


def test_call_namespace_dispatch(data_dir, capsys):
    code, payload = _run_cli(
        [
            "--data-dir",
            str(data_dir),
            "call",
            "--method",
            "settings.get_value",
            "--params-json",
            '{"key":"chat.default_agent_id"}',
        ],
        capsys,
    )
    assert code == 0
    assert payload["data"]["value"] == "default"
