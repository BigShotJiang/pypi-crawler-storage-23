from __future__ import annotations

import json
from types import SimpleNamespace

from vclawctl.cli import _resolve_auth_token, main


def _run_cli(args: list[str], capsys):
    code = main(args)
    out = capsys.readouterr().out.strip()
    payload = json.loads(out) if out else {}
    return code, payload


def test_resolve_auth_token_precedence(tmp_path, monkeypatch):
    token_file = tmp_path / "token.txt"
    token_file.write_text("file-token\n", encoding="utf-8")
    monkeypatch.setenv("VCLAWCTL_AUTH_TOKEN", "env-token")

    args = SimpleNamespace(auth_token="arg-token", auth_token_file=str(token_file))
    assert _resolve_auth_token(args) == "arg-token"

    args = SimpleNamespace(auth_token="", auth_token_file=str(token_file))
    assert _resolve_auth_token(args) == "file-token"

    args = SimpleNamespace(auth_token="", auth_token_file="")
    assert _resolve_auth_token(args) == "env-token"


def test_mode_db_uses_local_path(data_dir, capsys):
    code, payload = _run_cli(
        [
            "--mode",
            "db",
            "--data-dir",
            str(data_dir),
            "call",
            "--method",
            "settings.get_value",
            "--params-json",
            '{"key":"chat.default_agent_id"}',
        ],
        capsys,
    )
    assert code == 0
    assert payload["ok"] is True
    assert payload["data"]["value"] == "default"


def test_mode_api_requires_token(data_dir, capsys):
    code, payload = _run_cli(
        [
            "--mode",
            "api",
            "--api-base-url",
            "http://127.0.0.1:7799/api/control/v1",
            "--data-dir",
            str(data_dir),
            "call",
            "--method",
            "settings.get_value",
            "--params-json",
            '{"key":"chat.default_agent_id"}',
        ],
        capsys,
    )
    assert code == 2
    assert payload["ok"] is False
    assert payload["code"] == "auth_token_required"


def test_mode_api_unavailable_endpoint(data_dir, capsys):
    code, payload = _run_cli(
        [
            "--mode",
            "api",
            "--api-base-url",
            "http://127.0.0.1:1/api/control/v1",
            "--auth-token",
            "dummy-token",
            "--data-dir",
            str(data_dir),
            "call",
            "--method",
            "settings.get_value",
            "--params-json",
            '{"key":"chat.default_agent_id"}',
        ],
        capsys,
    )
    assert code == 2
    assert payload["ok"] is False
    assert payload["code"] in {"runtime_unavailable", "runtime_http_error"}
