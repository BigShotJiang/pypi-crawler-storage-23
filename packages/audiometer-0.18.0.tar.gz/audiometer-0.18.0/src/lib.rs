use pyo3::prelude::*;

mod lufs;
mod peak;
mod rms;
mod types;
mod utils;

#[pymodule]
fn _audiometer(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<lufs::Loudness>()?;
    m.add_function(wrap_pyfunction!(rms::measure_rms, m)?)?;
    m.add_function(wrap_pyfunction!(peak::measure_peak, m)?)?;
    m.add_function(wrap_pyfunction!(lufs::measure_loudness, m)?)?;
    Ok(())
}
