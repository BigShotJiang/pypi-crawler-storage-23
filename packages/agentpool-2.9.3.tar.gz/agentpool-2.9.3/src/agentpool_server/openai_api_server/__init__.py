"""OpenAI-compatible API server for AgentPool."""

from .server import OpenAIAPIServer

__all__ = ["OpenAIAPIServer"]
