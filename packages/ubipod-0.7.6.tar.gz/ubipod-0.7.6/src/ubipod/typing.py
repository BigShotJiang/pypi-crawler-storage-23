mat33 = tuple[float, float, float, float, float, float, float, float, float]
vec2 = tuple[float, float]
vec2i = tuple[int, int]
vec3 = tuple[float, float, float]


def mat33_new() -> mat33:
    return 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0


def vec2_new() -> vec2:
    return 0.0, 0.0


def vec2i_new() -> vec2i:
    return 0, 0


def vec3_new() -> vec3:
    return 0.0, 0.0, 0.0
