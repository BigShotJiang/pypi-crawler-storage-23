"""Allow running pm-trader as `python -m pm_trader`."""  # pragma: no cover
from pm_trader.cli import main  # pragma: no cover

main()  # pragma: no cover
