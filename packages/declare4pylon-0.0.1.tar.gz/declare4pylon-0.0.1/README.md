# declare4pylon

[![Release](https://img.shields.io/github/v/release/salvatorelaiso/declare4pylon)](https://img.shields.io/github/v/release/salvatorelaiso/declare4pylon)
[![Build status](https://img.shields.io/github/actions/workflow/status/salvatorelaiso/declare4pylon/main.yml?branch=main)](https://github.com/salvatorelaiso/declare4pylon/actions/workflows/main.yml?query=branch%3Amain)
[![codecov](https://codecov.io/gh/salvatorelaiso/declare4pylon/branch/main/graph/badge.svg)](https://codecov.io/gh/salvatorelaiso/declare4pylon)
[![Commit activity](https://img.shields.io/github/commit-activity/m/salvatorelaiso/declare4pylon)](https://img.shields.io/github/commit-activity/m/salvatorelaiso/declare4pylon)
[![License](https://img.shields.io/github/license/salvatorelaiso/declare4pylon)](https://img.shields.io/github/license/salvatorelaiso/declare4pylon)

DECLARE constraints implementation for [pylon-lib/pylon](https://github.com/pylon-lib/pylon).

- **Github repository**: <https://github.com/salvatorelaiso/declare4pylon/>
- **Documentation** <https://salvatorelaiso.github.io/declare4pylon/>


---

Repository initiated with [fpgmaas/cookiecutter-uv](https://github.com/fpgmaas/cookiecutter-uv).
