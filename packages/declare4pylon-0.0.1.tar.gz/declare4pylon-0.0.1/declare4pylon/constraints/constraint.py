from declare4pylon import LogicExpression


class DeclareConstraint(LogicExpression):
    """Base class for all declare constraints."""
