from declare4pylon import LogicExpression


class Operator(LogicExpression):
    """Base class for all operators."""
