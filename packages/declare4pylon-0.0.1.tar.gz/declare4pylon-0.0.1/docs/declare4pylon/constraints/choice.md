::: declare4pylon.constraints.choice
