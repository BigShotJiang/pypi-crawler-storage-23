::: declare4pylon.constraints.relation
