import pytest
import torch

from declare4pylon.constraints.relation import ChainPrecedenceConstraint
from tests.constants import PAD, A, B

_ = PAD


@pytest.mark.parametrize(
    ("activity_a", "activity_b", "traces", "expected"),
    [
        (A, B, [[_, _, _]], [True]),
        (A, B, [[A, _, _]], [True]),
        (A, B, [[_, _, B]], [False]),
        (A, B, [[A, B, _]], [True]),
        (A, B, [[B, A, _]], [False]),
        (A, B, [[A, _, B]], [False]),
        (A, B, [[B, _, A]], [False]),
        (A, B, [[A, A, B]], [True]),
        (A, B, [[A, B, A]], [True]),
        (A, B, [[B, A, B]], [False]),
    ],
    ids=[
        "ChainPrecedence (Neither A nor B)",
        "ChainPrecedence (Only A)",
        "ChainPrecedence (Only B)",
        "ChainPrecedence (A and immediately B)",
        "ChainPrecedence (B and immediately A)",
        "ChainPrecedence (A and B but not immediately)",
        "ChainPrecedence (B and A but not immediately)",
        "ChainPrecedence (A and another A before B)",
        "ChainPrecedence (A and B before another A)",
        "ChainPrecedence (first B, then A before B)",
    ],
)
def test_chain_precedence_constraint_evaluate(
    activity_a: int,
    activity_b: int,
    traces: list[list[int]],
    expected: list[bool],
):
    traces_tensor = torch.tensor(traces, dtype=torch.int32)
    expected_tensor = torch.tensor(expected, dtype=torch.bool)
    constraint = ChainPrecedenceConstraint(activity_a=activity_a, activity_b=activity_b)
    result = constraint.evaluate(traces_tensor)
    assert torch.equal(result, expected_tensor)
