"""
Tool call permission control for SecureVector.

Provides tool call extraction from LLM responses and essential tool
permission enforcement for the LLM proxy.
"""
