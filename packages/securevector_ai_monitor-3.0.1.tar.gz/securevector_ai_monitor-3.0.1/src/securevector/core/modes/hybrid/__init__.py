# Hybrid mode implementation
