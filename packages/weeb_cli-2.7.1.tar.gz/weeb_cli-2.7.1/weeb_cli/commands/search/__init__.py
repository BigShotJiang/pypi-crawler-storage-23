from .search_handlers import search_anime

__all__ = ['search_anime']
