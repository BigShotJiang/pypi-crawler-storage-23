"""Tests for sync_engine_registry — upsert, deactivation, idempotency.

These tests require a database connection. Skip if PULSE_DB_URL is not set.
They are designed to be run against a test database.
"""

from unittest.mock import MagicMock, patch

import pytest

from pulse_core.strategies.registry import StrategyRegistry
from pulse_core.strategies.sync import SyncResult, sync_engine_registry


class TestSyncEngineRegistry:
    """Tests for the sync_engine_registry function using mocks."""

    def test_sync_result_dataclass(self) -> None:
        """SyncResult holds counts correctly."""
        result = SyncResult(upserted=3, deactivated=1)
        assert result.upserted == 3
        assert result.deactivated == 1

    def test_sync_result_defaults(self) -> None:
        """SyncResult defaults to zero counts."""
        result = SyncResult()
        assert result.upserted == 0
        assert result.deactivated == 0
