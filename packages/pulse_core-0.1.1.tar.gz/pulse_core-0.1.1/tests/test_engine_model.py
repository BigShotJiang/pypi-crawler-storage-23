"""Tests for the Engine model."""

from uuid import uuid4

from pulse_core.models.engine import Engine


class TestEngineModel:
    """Tests for Engine model instantiation."""

    def test_create_engine(self) -> None:
        """An Engine can be created with required fields."""
        engine = Engine(
            slug="mean_reversion",
            name="Mean Reversion",
        )
        assert engine.slug == "mean_reversion"
        assert engine.name == "Mean Reversion"
        assert engine.is_active is True

    def test_create_engine_with_schema(self) -> None:
        """An Engine can store parameter_schema and default_parameters."""
        engine = Engine(
            slug="test_engine",
            name="Test Engine",
            parameter_schema={"type": "object", "properties": {"x": {"type": "integer"}}},
            default_parameters={"x": 42},
            universe_constraints={"min_listings": 10},
        )
        assert engine.parameter_schema["type"] == "object"
        assert engine.default_parameters["x"] == 42
        assert engine.universe_constraints["min_listings"] == 10

    def test_engine_defaults(self) -> None:
        """Engine has sensible defaults."""
        engine = Engine(slug="test", name="Test")
        assert engine.is_active is True
        assert engine.description is None
        assert engine.parameter_schema is None
        assert engine.registered_at is None
