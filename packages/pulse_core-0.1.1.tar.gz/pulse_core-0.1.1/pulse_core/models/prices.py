"""Price data models: OHLCV candles and timeframes."""

import enum
from datetime import datetime
from decimal import Decimal

from sqlalchemy import UniqueConstraint, BigInteger, Numeric, Enum as SAEnum, TIMESTAMP, func
from sqlmodel import SQLModel, Field, Column


class TimeFrame(str, enum.Enum):
    M1 = "1m"
    M5 = "5m"
    M15 = "15m"
    H1 = "1h"
    H4 = "4h"
    D1 = "1d"
    W1 = "1w"


class PriceOHLCV(SQLModel, table=True):
    """OHLCV candle data — becomes a TimescaleDB hypertable via Alembic migration."""

    __tablename__ = "prices_ohlcv"
    __table_args__ = (UniqueConstraint("listing_id", "timeframe", "ts", name="uq_price"),)

    ts: datetime = Field(
        primary_key=True,
        sa_type=TIMESTAMP(timezone=True),  # noqa
    )
    listing_id: int = Field(primary_key=True, foreign_key="listings.id")
    timeframe: TimeFrame = Field(
        sa_column=Column(SAEnum(TimeFrame, values_callable=lambda e: [m.value for m in e]), primary_key=True)
    )
    open: Decimal = Field(sa_column=Column(Numeric(18, 6)))
    high: Decimal = Field(sa_column=Column(Numeric(18, 6)))
    low: Decimal = Field(sa_column=Column(Numeric(18, 6)))
    close: Decimal = Field(sa_column=Column(Numeric(18, 6)))
    volume: int = Field(sa_column=Column(BigInteger))
    adj_close: Decimal | None = Field(default=None, sa_column=Column(Numeric(18, 6)))
    data_source_id: int | None = Field(default=None, foreign_key="data_sources.id")
    ingested_at: datetime = Field(
        sa_column=Column(
            TIMESTAMP(timezone=True),
            nullable=False,
            server_default=func.now(),
        )
    )
