"""Engine model — persists engine metadata from the Python registry."""

from datetime import datetime
from uuid import UUID, uuid4

from sqlalchemy import TIMESTAMP, Text, func
from sqlalchemy.dialects.postgresql import JSONB
from sqlmodel import SQLModel, Field, Relationship, Column

from pulse_core.models.mixins import TimestampMixin


class Engine(TimestampMixin, SQLModel, table=True):
    """
    A registered strategy engine.

    Populated by sync_engine_registry() which reconciles the Python
    StrategyRegistry with this table.
    """

    __tablename__ = "engines"

    id: UUID = Field(default_factory=uuid4, primary_key=True)
    slug: str = Field(max_length=64, unique=True, index=True)
    name: str = Field(max_length=100)
    description: str | None = Field(default=None, sa_column=Column(Text))
    parameter_schema: dict | None = Field(default=None, sa_column=Column(JSONB))
    universe_constraints: dict | None = Field(default=None, sa_column=Column(JSONB))
    default_parameters: dict | None = Field(default=None, sa_column=Column(JSONB))
    is_active: bool = Field(default=True)
    registered_at: datetime | None = Field(
        default=None,
        sa_type=TIMESTAMP(timezone=True),  # noqa
        sa_column_kwargs={"nullable": True},
    )

    strategies: list["Strategy"] = Relationship(back_populates="engine")  # noqa: F821
