from datetime import datetime

from sqlalchemy import TIMESTAMP, func
from sqlmodel import Field, SQLModel


class TimestampMixin(SQLModel):
    """Created/updated timestamps — use on all regular tables."""

    created_at: datetime | None = Field(
        default=None,
        sa_type=TIMESTAMP(timezone=True), # noqa
        sa_column_kwargs={"nullable": False, "server_default": func.now()},
    )
    updated_at: datetime | None = Field(
        default=None,
        sa_type=TIMESTAMP(timezone=True), # noqa
        sa_column_kwargs={"nullable": True, "onupdate": func.now()},
    )


class SoftDeleteMixin(SQLModel):
    """
    Soft delete — use only where you need to retain history.
    Do NOT use on append-only tables or reference tables.
    """

    deleted_at: datetime | None = Field(
        default=None,
        sa_type=TIMESTAMP(timezone=True), # noqa
        sa_column_kwargs={"nullable": True},
    )

    @property
    def is_deleted(self) -> bool:
        return self.deleted_at is not None
