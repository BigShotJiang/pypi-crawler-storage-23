"""Market-related models: exchanges, listing, instruments, data sources."""

import enum
from datetime import date, datetime

from sqlalchemy.dialects.postgresql import JSONB
from sqlmodel import SQLModel, Field, Relationship, UniqueConstraint, Text, Enum as SAEnum, TIMESTAMP, Column

from pulse_core.models.mixins import TimestampMixin


class InstrumentType(str, enum.Enum):
    STOCK = "stock"
    ETF = "etf"
    BOND = "bond"
    COMMODITY = "commodity"
    CRYPTO = "crypto"
    INDEX = "index"
    UNKNOWN = "unknown"


class Exchange(TimestampMixin, SQLModel, table=True):
    """exchange / trading venue."""

    __tablename__ = "exchanges"

    id: int | None = Field(default=None, primary_key=True)
    code: str = Field(max_length=10, unique=True, index=True)
    name: str = Field(max_length=100)
    mic: str | None = Field(default=None, max_length=4)
    timezone: str = Field(max_length=50)
    currency: str = Field(max_length=3)
    country: str = Field(max_length=2)
    open_time: str | None = Field(default=None, max_length=5)
    close_time: str | None = Field(default=None, max_length=5)
    is_active: bool = Field(default=True)

    listings: list["Listing"] = Relationship(back_populates="exchange")


class Instrument(TimestampMixin, SQLModel, table=True):
    """A financial instrument identified by ISIN."""

    __tablename__ = "instruments"

    id: int | None = Field(default=None, primary_key=True)
    isin: str = Field(max_length=12, unique=True, index=True)
    name: str = Field(max_length=200)
    instrument_type: InstrumentType = Field(
        sa_column=Column(SAEnum(InstrumentType, values_callable=lambda e: [m.value for m in e]))
    )
    sector: str | None = Field(default=None, max_length=100)
    industry: str | None = Field(default=None, max_length=100)
    country: str | None = Field(default=None, max_length=2)
    city: str | None = Field(default=None, max_length=100)
    zip: str | None = Field(default=None, max_length=20)
    phone: str | None = Field(default=None, max_length=20)
    website: str | None = Field(default=None, max_length=100)
    description: str | None = Field(default=None, sa_column=Column(Text))
    metadata_: dict | None = Field(default=None, sa_column=Column("metadata", JSONB))
    is_active: bool = Field(default=True)

    listings: list["Listing"] = Relationship(back_populates="instrument")


class DataSource(TimestampMixin, SQLModel, table=True):
    """A data provider used for scraping."""

    __tablename__ = "data_sources"

    id: int | None = Field(default=None, primary_key=True)
    code: str = Field(max_length=30, unique=True, index=True)
    name: str = Field(max_length=100)
    base_url: str | None = Field(default=None, max_length=255)
    rate_limit: int | None = Field(default=None)
    is_active: bool = Field(default=True)
    config: dict | None = Field(default=None, sa_column=Column(JSONB))

    listing_sources: list["ListingSource"] = Relationship(back_populates="data_source")


class Listing(TimestampMixin, SQLModel, table=True):
    """An instrument listed on a specific exchange."""

    __tablename__ = "listings"
    __table_args__ = (UniqueConstraint("instrument_id", "exchange_id", name="uq_listing"),)

    id: int | None = Field(default=None, primary_key=True)
    instrument_id: int = Field(foreign_key="instruments.id", index=True)
    exchange_id: int = Field(foreign_key="exchanges.id", index=True)
    ticker: str = Field(max_length=20, index=True)
    currency: str = Field(max_length=3)
    lot_size: int = Field(default=1)
    is_primary: bool = Field(default=False)
    is_active: bool = Field(default=True)
    first_traded: date | None = Field(default=None)
    last_traded: date | None = Field(default=None)

    instrument: Instrument = Relationship(back_populates="listings")
    exchange: Exchange = Relationship(back_populates="listings")
    sources: list["ListingSource"] = Relationship(back_populates="listing")


class ListingSource(SQLModel, table=True):
    """Maps a listing to its identifier on a specific data provider."""

    __tablename__ = "listing_sources"
    __table_args__ = (UniqueConstraint("listing_id", "data_source_id", name="uq_listing_source"),)

    id: int | None = Field(default=None, primary_key=True)
    listing_id: int = Field(foreign_key="listings.id", index=True)
    data_source_id: int = Field(foreign_key="data_sources.id", index=True)
    symbol: str = Field(max_length=50)
    is_active: bool = Field(default=True)
    priority: int = Field(default=0)
    last_fetched_at: datetime | None = Field(
        default=None,
        sa_type=TIMESTAMP(timezone=True),  # noqa
    )
    config: dict | None = Field(
        default=None, sa_column=Column(JSONB)
    )

    listing: Listing = Relationship(back_populates="sources")
    data_source: DataSource = Relationship(back_populates="listing_sources")
