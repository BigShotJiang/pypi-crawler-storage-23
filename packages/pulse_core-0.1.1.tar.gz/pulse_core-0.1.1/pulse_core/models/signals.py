"""Signal, strategy, subscription, and delivery models."""

import enum
from datetime import datetime
from decimal import Decimal
from uuid import UUID, uuid4

from sqlalchemy import UniqueConstraint, Numeric, Text, Enum as SAEnum, TIMESTAMP, func
from sqlalchemy.dialects.postgresql import JSONB
from sqlmodel import SQLModel, Field, Relationship, Column

from pulse_core.models.mixins import TimestampMixin, SoftDeleteMixin
from pulse_core.models.prices import TimeFrame


class SignalDirection(str, enum.Enum):
    BUY = "buy"
    SELL = "sell"
    HOLD = "hold"
    CLOSE = "close"


class SignalStrength(str, enum.Enum):
    STRONG = "strong"
    MODERATE = "moderate"
    WEAK = "weak"


class SubscriptionStatus(str, enum.Enum):
    ACTIVE = "active"
    PAUSED = "paused"
    CANCELLED = "cancelled"
    TRIAL = "trial"


class DeliveryChannel(str, enum.Enum):
    EMAIL = "email"
    WEBHOOK = "webhook"
    PUSH = "push"
    TELEGRAM = "telegram"


class DeliveryStatus(str, enum.Enum):
    PENDING = "pending"
    SENT = "sent"
    FAILED = "failed"
    RETRYING = "retrying"


class Strategy(TimestampMixin, SQLModel, table=True):
    """
    A trading strategy that generates signals.
    v2: references an Engine via engine_id FK, uses cron instead of schedule_group.
    """

    __tablename__ = "strategies"

    id: UUID = Field(default_factory=uuid4, primary_key=True)
    name: str = Field(max_length=100, unique=True)
    slug: str = Field(max_length=100, unique=True, index=True)
    description: str | None = Field(default=None, sa_column=Column(Text))
    version: str = Field(default="1.0.0", max_length=20)
    timeframe: TimeFrame = Field(
        sa_column=Column(SAEnum(TimeFrame, values_callable=lambda e: [m.value for m in e]))
    )
    parameters: dict | None = Field(
        default=None, sa_column=Column(JSONB)
    )
    is_active: bool = Field(default=True)
    is_public: bool = Field(default=True)
    monthly_price: Decimal = Field(sa_column=Column(Numeric(10, 2)))

    # v2 fields
    engine_id: UUID = Field(foreign_key="engines.id")
    cron: str = Field(default="0 22 * * 1-5", max_length=64)

    engine: "Engine" = Relationship(back_populates="strategies")  # noqa: F821
    signals: list["Signal"] = Relationship(back_populates="strategy")
    subscriptions: list["Subscription"] = Relationship(back_populates="strategy")


class Signal(SQLModel, table=True):
    """
    A signal emitted by a strategy — TimescaleDB hypertable, append-only.
    Signals are IMMUTABLE once created.
    """

    __tablename__ = "signals"

    ts: datetime = Field(
        primary_key=True,
        sa_type=TIMESTAMP(timezone=True),  # noqa
    )
    id: UUID = Field(default_factory=uuid4, primary_key=True)
    strategy_id: UUID = Field(foreign_key="strategies.id", index=True)
    listing_id: int = Field(foreign_key="listings.id", index=True)

    direction: SignalDirection = Field(
        sa_column=Column(SAEnum(SignalDirection, values_callable=lambda e: [m.value for m in e]))
    )
    strength: SignalStrength = Field(
        sa_column=Column(SAEnum(SignalStrength, values_callable=lambda e: [m.value for m in e]))
    )
    entry_price: Decimal | None = Field(default=None, sa_column=Column(Numeric(18, 6)))
    stop_loss: Decimal | None = Field(default=None, sa_column=Column(Numeric(18, 6)))
    take_profit: Decimal | None = Field(default=None, sa_column=Column(Numeric(18, 6)))
    confidence: float | None = Field(default=None)
    notes: str | None = Field(default=None, sa_column=Column(Text))
    metadata_: dict | None = Field(
        default=None, sa_column=Column("metadata", JSONB)
    )
    created_at: datetime = Field(
        sa_column=Column(
            TIMESTAMP(timezone=True),
            nullable=False,
            server_default=func.now(),
        )
    )

    strategy: Strategy = Relationship(back_populates="signals")


class Subscription(TimestampMixin, SoftDeleteMixin, SQLModel, table=True):
    """A user's active subscription to a strategy."""

    __tablename__ = "subscriptions"
    __table_args__ = (UniqueConstraint("user_id", "strategy_id", name="uq_user_strategy"),)

    id: UUID = Field(default_factory=uuid4, primary_key=True)
    user_id: UUID = Field(foreign_key="users.id", index=True)
    strategy_id: UUID = Field(foreign_key="strategies.id", index=True)
    status: SubscriptionStatus = Field(
        sa_column=Column(SAEnum(SubscriptionStatus, values_callable=lambda e: [m.value for m in e]))
    )
    started_at: datetime | None = Field(
        default=None,
        sa_type=TIMESTAMP(timezone=True),  # noqa
        sa_column_kwargs={"nullable": False, "server_default": func.now()},
    )
    expires_at: datetime | None = Field(
        default=None,
        sa_type=TIMESTAMP(timezone=True),  # noqa
    )
    cancelled_at: datetime | None = Field(
        default=None,
        sa_type=TIMESTAMP(timezone=True),  # noqa
    )

    strategy: Strategy = Relationship(back_populates="subscriptions")


class DeliveryConfig(TimestampMixin, SoftDeleteMixin, SQLModel, table=True):
    """How a user wants to receive signals."""

    __tablename__ = "delivery_configs"

    id: UUID = Field(default_factory=uuid4, primary_key=True)
    user_id: UUID = Field(foreign_key="users.id", index=True)
    channel: DeliveryChannel = Field(
        sa_column=Column(SAEnum(DeliveryChannel, values_callable=lambda e: [m.value for m in e]))
    )
    config: dict = Field(
        sa_column=Column(JSONB)
    )
    is_active: bool = Field(default=True)


class SignalDelivery(TimestampMixin, SQLModel, table=True):
    """Audit trail for signal delivery."""

    __tablename__ = "signal_deliveries"

    id: UUID = Field(default_factory=uuid4, primary_key=True)
    signal_id: UUID = Field(index=True)
    signal_ts: datetime = Field(
        sa_type=TIMESTAMP(timezone=True),  # noqa
        sa_column_kwargs={"nullable": False},
    )
    user_id: UUID = Field(foreign_key="users.id", index=True)
    delivery_config_id: UUID = Field(foreign_key="delivery_configs.id")
    status: DeliveryStatus = Field(
        sa_column=Column(SAEnum(DeliveryStatus, values_callable=lambda e: [m.value for m in e]))
    )
    attempts: int = Field(default=0)
    last_attempt_at: datetime | None = Field(
        default=None,
        sa_type=TIMESTAMP(timezone=True),  # noqa
    )
    delivered_at: datetime | None = Field(
        default=None,
        sa_type=TIMESTAMP(timezone=True),  # noqa
    )
    error_message: str | None = Field(default=None, sa_column=Column(Text))
