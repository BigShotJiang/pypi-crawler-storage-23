"""pulse-core — shared models, strategy framework, and DB session for Pulse."""
