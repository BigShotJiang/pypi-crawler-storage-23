"""Database session factory for pulse-core.

Used by both pulse-backend and Airflow DAGs.
Reads PULSE_DB_URL from the environment or accepts a URL parameter.
"""

from __future__ import annotations

import os
from contextlib import contextmanager
from typing import Generator

from sqlalchemy import create_engine as sa_create_engine
from sqlalchemy.engine import Engine
from sqlmodel import Session

_engine: Engine | None = None


def get_engine(url: str | None = None) -> Engine:
    """Return a singleton SQLAlchemy engine.

    Args:
        url: Database URL. Falls back to ``PULSE_DB_URL`` env var.
    """
    global _engine
    if _engine is None:
        db_url = url or os.environ.get("PULSE_DB_URL")
        if not db_url:
            raise RuntimeError(
                "No database URL provided. Set PULSE_DB_URL or pass url= parameter."
            )
        _engine = sa_create_engine(db_url, pool_pre_ping=True)
    return _engine


@contextmanager
def get_session(url: str | None = None) -> Generator[Session, None, None]:
    """Yield a SQLModel session, auto-closing on exit."""
    engine = get_engine(url)
    with Session(engine) as session:
        yield session
