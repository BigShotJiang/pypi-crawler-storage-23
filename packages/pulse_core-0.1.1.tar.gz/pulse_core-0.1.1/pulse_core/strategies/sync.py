"""Engine registry sync — reconciles Python registry with DB engines table."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime, timezone

from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlmodel import Session, select, col

from pulse_core.models.engine import Engine
from pulse_core.strategies.registry import StrategyRegistry

log = logging.getLogger(__name__)


@dataclass
class SyncResult:
    """Summary of an engine registry sync operation."""

    upserted: int = 0
    deactivated: int = 0


def sync_engine_registry(session: Session) -> SyncResult:
    """Reconcile the Python StrategyRegistry with the DB engines table.

    - Upserts each registered engine's metadata.
    - Deactivates engine rows whose slug no longer exists in the Python registry.

    Args:
        session: An active SQLModel session.

    Returns:
        SyncResult with counts of upserted and deactivated engines.
    """
    result = SyncResult()
    now = datetime.now(timezone.utc)
    registry = StrategyRegistry.all()

    registered_slugs: set[str] = set()

    for slug, engine_cls in registry.items():
        registered_slugs.add(slug)

        values = {
            "slug": slug,
            "name": getattr(engine_cls, "display_name", slug) or slug,
            "description": getattr(engine_cls, "description", None) or None,
            "parameter_schema": engine_cls.get_parameter_schema() or None,
            "universe_constraints": engine_cls.get_universe_constraints() or None,
            "default_parameters": engine_cls.get_default_parameters() or None,
            "is_active": True,
            "registered_at": now,
        }

        stmt = pg_insert(Engine).values(**values)
        stmt = stmt.on_conflict_do_update(
            index_elements=["slug"],
            set_={
                "name": stmt.excluded.name,
                "description": stmt.excluded.description,
                "parameter_schema": stmt.excluded.parameter_schema,
                "universe_constraints": stmt.excluded.universe_constraints,
                "default_parameters": stmt.excluded.default_parameters,
                "is_active": stmt.excluded.is_active,
                "registered_at": stmt.excluded.registered_at,
            },
        )
        session.exec(stmt)  # type: ignore[call-overload]
        result.upserted += 1

    # Deactivate engines no longer in the registry
    if registered_slugs:
        stale_engines = session.exec(
            select(Engine)
            .where(col(Engine.is_active) == True)  # noqa: E712
            .where(col(Engine.slug).notin_(list(registered_slugs)))
        ).all()
    else:
        stale_engines = session.exec(
            select(Engine).where(col(Engine.is_active) == True)  # noqa: E712
        ).all()

    for engine in stale_engines:
        engine.is_active = False
        result.deactivated += 1

    session.commit()

    log.info(
        f"Engine registry sync: {result.upserted} upserted, "
        f"{result.deactivated} deactivated"
    )
    return result
