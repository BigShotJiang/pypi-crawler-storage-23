"""Strategy engine framework — public API."""

from pulse_core.strategies.base import BaseStrategy, SignalOutput, UniverseFilter  # noqa: F401
from pulse_core.strategies.registry import (  # noqa: F401
    StrategyRegistry,
    DuplicateEngineError,
    EngineNotFoundError,
)

# Import engines subpackage to trigger @register decorators
import pulse_core.strategies.engines  # noqa: F401
