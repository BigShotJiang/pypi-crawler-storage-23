"""Strategy engine registry — maps engine names to strategy classes."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pulse_core.strategies.base import BaseStrategy


class DuplicateEngineError(Exception):
    """Raised when registering an engine name that already exists."""


class EngineNotFoundError(Exception):
    """Raised when looking up an engine name that is not registered."""


class StrategyRegistry:
    """Central registry mapping engine names -> BaseStrategy subclasses."""

    _engines: dict[str, type[BaseStrategy]] = {}

    @classmethod
    def register(cls, engine_name: str):
        """Decorator to register a strategy engine class."""

        def decorator(strategy_cls: type[BaseStrategy]) -> type[BaseStrategy]:
            if engine_name in cls._engines:
                raise DuplicateEngineError(
                    f"Engine '{engine_name}' is already registered "
                    f"to {cls._engines[engine_name].__name__}"
                )
            cls._engines[engine_name] = strategy_cls
            return strategy_cls

        return decorator

    @classmethod
    def get(cls, engine_name: str) -> type[BaseStrategy]:
        """Look up a registered engine by name. Raises EngineNotFoundError."""
        try:
            return cls._engines[engine_name]
        except KeyError:
            available = ", ".join(sorted(cls._engines)) or "(none)"
            raise EngineNotFoundError(
                f"Engine '{engine_name}' not found. Available: {available}"
            )

    @classmethod
    def list_engines(cls) -> list[str]:
        """Return a sorted list of all registered engine names."""
        return sorted(cls._engines)

    @classmethod
    def all(cls) -> dict[str, type[BaseStrategy]]:
        """Return the full engine registry as a dict."""
        return dict(cls._engines)
