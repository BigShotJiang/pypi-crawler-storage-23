"""Mean reversion strategy engine — reference implementation."""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any, Sequence

from pulse_core.models.market import Listing
from pulse_core.models.prices import PriceOHLCV
from pulse_core.models.signals import SignalDirection
from pulse_core.strategies.base import BaseStrategy, SignalOutput
from pulse_core.strategies.registry import StrategyRegistry

log = logging.getLogger(__name__)

_DEFAULTS: dict[str, Any] = {
    "fast_period": 20,
    "slow_period": 50,
    "threshold": 0.02,
}


@StrategyRegistry.register("mean_reversion")
class MeanReversionStrategy(BaseStrategy):
    """
    Dual moving-average mean reversion strategy.

    Parameters (JSONB):
        fast_period (int): Short MA window, e.g. 20
        slow_period (int): Long MA window, e.g. 50
        threshold (float): Divergence threshold to trigger a signal, e.g. 0.02 (2%)

    Logic:
        - Compute fast and slow simple moving averages on close prices.
        - If fast MA is below slow MA by more than threshold -> BUY (oversold).
        - If fast MA is above slow MA by more than threshold -> SELL (overbought).
        - Otherwise -> no signal.
        - Confidence scales with the magnitude of divergence (capped at 1.0).
    """

    display_name = "Mean Reversion"
    description = (
        "Dual moving-average mean reversion strategy. Generates BUY signals when "
        "fast MA is below slow MA by more than threshold (oversold), and SELL signals "
        "when fast MA is above slow MA by more than threshold (overbought)."
    )

    def validate_parameters(self) -> None:
        fast = self.parameters.get("fast_period")
        slow = self.parameters.get("slow_period")
        threshold = self.parameters.get("threshold")

        if not isinstance(fast, int) or fast < 1:
            raise ValueError(f"fast_period must be a positive integer, got {fast!r}")
        if not isinstance(slow, int) or slow < 1:
            raise ValueError(f"slow_period must be a positive integer, got {slow!r}")
        if fast >= slow:
            raise ValueError(
                f"fast_period ({fast}) must be less than slow_period ({slow})"
            )
        if not isinstance(threshold, (int, float)) or threshold <= 0:
            raise ValueError(f"threshold must be a positive number, got {threshold!r}")

    def get_required_candle_count(self) -> int:
        return self.parameters.get("slow_period", 50) + 10

    def compute(
        self,
        listing: Listing,
        candles: Sequence[PriceOHLCV],
        as_of: datetime,
    ) -> SignalOutput | None:
        fast_period: int = self.parameters["fast_period"]
        slow_period: int = self.parameters["slow_period"]
        threshold: float = self.parameters["threshold"]

        closes = [float(c.close) for c in candles]

        if len(closes) < slow_period:
            return None

        fast_ma = sum(closes[-fast_period:]) / fast_period
        slow_ma = sum(closes[-slow_period:]) / slow_period

        if slow_ma == 0:
            return None

        divergence = (fast_ma - slow_ma) / slow_ma

        if abs(divergence) < threshold:
            return None

        # Scale confidence: at threshold -> 0.3, at 2x threshold -> 0.6, at 3x+ -> capped at 1.0
        raw_confidence = min(abs(divergence) / threshold * 0.3, 1.0)

        if divergence < -threshold:
            # Fast MA below slow MA -> oversold -> BUY
            direction = SignalDirection.BUY
        else:
            # Fast MA above slow MA -> overbought -> SELL
            direction = SignalDirection.SELL

        return SignalOutput(
            direction=direction,
            confidence=round(raw_confidence, 4),
            notes=f"fast_ma={fast_ma:.4f} slow_ma={slow_ma:.4f} divergence={divergence:.4f}",
            metadata={
                "fast_period": fast_period,
                "slow_period": slow_period,
                "threshold": threshold,
                "fast_ma": round(fast_ma, 6),
                "slow_ma": round(slow_ma, 6),
                "divergence": round(divergence, 6),
            },
        )

    @classmethod
    def get_parameter_schema(cls) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "fast_period": {"type": "integer", "minimum": 1, "description": "Short MA window"},
                "slow_period": {"type": "integer", "minimum": 2, "description": "Long MA window"},
                "threshold": {"type": "number", "exclusiveMinimum": 0, "description": "Divergence threshold (fraction)"},
            },
            "required": ["fast_period", "slow_period", "threshold"],
        }

    @classmethod
    def get_default_parameters(cls) -> dict[str, Any]:
        return dict(_DEFAULTS)
