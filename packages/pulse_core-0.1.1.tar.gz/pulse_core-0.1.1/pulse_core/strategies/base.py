"""Base strategy class, signal output, and universe filter."""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Sequence

from sqlmodel import col

from pulse_core.models.market import Exchange, Instrument, Listing
from pulse_core.models.prices import PriceOHLCV
from pulse_core.models.signals import SignalDirection

log = logging.getLogger(__name__)


@dataclass(frozen=True)
class SignalOutput:
    """Immutable signal produced by a strategy's compute() method."""

    direction: SignalDirection
    confidence: float  # 0.0-1.0
    notes: str | None = None
    metadata: dict[str, Any] | None = None

    def __post_init__(self) -> None:
        if not 0.0 <= self.confidence <= 1.0:
            raise ValueError(f"confidence must be between 0.0 and 1.0, got {self.confidence}")


@dataclass
class UniverseFilter:
    """Filters the set of listings a strategy operates on."""

    exchange_codes: list[str] | None = None
    instrument_types: list[str] | None = None
    countries: list[str] | None = None
    sectors: list[str] | None = None
    listing_ids: list[int] | None = None

    @classmethod
    def from_params(cls, parameters: dict[str, Any] | None) -> UniverseFilter:
        if not parameters:
            return cls()
        universe = parameters.get("universe", {})
        if not isinstance(universe, dict):
            return cls()
        return cls(
            exchange_codes=universe.get("exchange_codes"),
            instrument_types=universe.get("instrument_types"),
            countries=universe.get("countries"),
            sectors=universe.get("sectors"),
            listing_ids=universe.get("listing_ids"),
        )

    def apply(self, query):
        """Apply universe filters to a Listing select query."""
        needs_instrument = self.instrument_types or self.countries or self.sectors
        needs_exchange = self.exchange_codes

        if needs_instrument:
            query = query.join(Instrument, Listing.instrument_id == Instrument.id)
        if needs_exchange:
            query = query.join(Exchange, Listing.exchange_id == Exchange.id)

        if self.listing_ids:
            query = query.where(col(Listing.id).in_(self.listing_ids))
        if self.exchange_codes:
            query = query.where(col(Exchange.code).in_(self.exchange_codes))
        if self.instrument_types:
            query = query.where(col(Instrument.instrument_type).in_(self.instrument_types))
        if self.countries:
            query = query.where(col(Instrument.country).in_(self.countries))
        if self.sectors:
            query = query.where(col(Instrument.sector).in_(self.sectors))

        # Only active listings
        query = query.where(col(Listing.is_active) == True)  # noqa: E712

        return query


class BaseStrategy(ABC):
    """
    Abstract base class for all trading strategies.

    v2 interface: accepts ``parameters: dict`` instead of ``Strategy`` model.

    Subclasses must implement:
    - validate_parameters(): check that parameters has required keys/types
    - compute(): produce a signal (or None) for a single listing

    Subclasses should define class attributes:
    - display_name: str
    - description: str
    """

    display_name: str = ""
    description: str = ""

    def __init__(self, parameters: dict[str, Any]) -> None:
        self.parameters: dict[str, Any] = parameters or {}

    @abstractmethod
    def validate_parameters(self) -> None:
        """Validate parameters. Raise ValueError on invalid config."""
        ...

    @abstractmethod
    def compute(
        self,
        listing: Listing,
        candles: Sequence[PriceOHLCV],
        as_of: datetime,
    ) -> SignalOutput | None:
        """
        Run strategy logic on a single listing's candles.

        Args:
            listing: The listing being evaluated.
            candles: OHLCV candles ordered by ts ASC.
            as_of: The point-in-time for evaluation.

        Returns:
            A SignalOutput if a signal is generated, None otherwise.
        """
        ...

    def get_required_candle_count(self) -> int:
        """How many candles this strategy needs. Default 200."""
        return 200

    def get_universe_filter(self) -> UniverseFilter:
        """Build a UniverseFilter from strategy parameters."""
        return UniverseFilter.from_params(self.parameters)

    def validate_candles(self, candles: Sequence[PriceOHLCV]) -> bool:
        """Check if we have enough candles. Override for custom logic."""
        return len(candles) >= self.get_required_candle_count()

    @classmethod
    def get_parameter_schema(cls) -> dict[str, Any]:
        """Return a JSON Schema describing this engine's parameters.

        Override in subclasses to provide detailed parameter docs.
        """
        return {}

    @classmethod
    def get_universe_constraints(cls) -> dict[str, Any]:
        """Return constraints/defaults for universe filtering.

        Override in subclasses if the engine has specific universe requirements.
        """
        return {}

    @classmethod
    def get_default_parameters(cls) -> dict[str, Any]:
        """Return default parameter values for this engine.

        Override in subclasses to provide sensible defaults.
        """
        return {}
