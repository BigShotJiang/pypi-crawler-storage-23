"""Configuration parser for ReMe framework."""

from ..utils import PydanticConfigParser


class ReMeConfigParser(PydanticConfigParser):
    """Configuration parser for ReMe framework."""
