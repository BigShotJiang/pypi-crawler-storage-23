# ModalTrace Documentation Wiki

This directory contains the official documentation for ModalTrace.

## Contents

- **[Home.md](Home.md)** - Main documentation hub and quick links
- **[Getting-Started.md](Getting-Started.md)** - Installation and first steps
- **[Configuration.md](Configuration.md)** - Complete configuration reference
- **[FAQ.md](FAQ.md)** - Frequently asked questions and troubleshooting

## Quick Navigation

### For New Users
1. Start with [Getting Started](Getting-Started.md)
2. Review [Configuration](Configuration.md) options
3. Check [FAQ](FAQ.md) for common issues

### For Experienced Users
- See [Configuration.md](Configuration.md) for advanced settings
- Review [Home.md](Home.md) for full documentation links
- Check [FAQ.md](FAQ.md) for troubleshooting

## Additional Resources

- **GitHub Repository:** https://github.com/arnabdeypolimi/video_ai_telemetry
- **PyPI Package:** https://pypi.org/project/modaltrace/
- **API Reference:** [docs/API.md](../docs/API.md)
- **Architecture Guide:** [docs/ARCHITECTURE.md](../docs/ARCHITECTURE.md)
- **Usage Examples:** [docs/EXAMPLES.md](../docs/EXAMPLES.md)
- **Contributing Guide:** [CONTRIBUTING.md](../CONTRIBUTING.md)

## Latest Release

**Version 0.2.0** - [Release Notes](https://github.com/arnabdeypolimi/video_ai_telemetry/releases/tag/v0.2.0)

## Support

- **Questions?** Check [FAQ.md](FAQ.md)
- **Found an issue?** Open a [GitHub issue](https://github.com/arnabdeypolimi/video_ai_telemetry/issues)
- **Want to contribute?** See [Contributing Guide](../CONTRIBUTING.md)

---

Last updated: March 1, 2026
