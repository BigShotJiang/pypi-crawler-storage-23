"""Shared test fixtures for modaltrace."""
