# This file is managed by hatch-vcs. Fallback for editable installs.
__version__ = "0.0.0"
