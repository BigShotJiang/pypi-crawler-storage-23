## 🚀 Version 1.10.0 - February 27, 2026

**"Production Ready - Debian Package & Enhanced Device Support"**

### What's New
- **Debian Package Support**: Full automated Debian package building and deployment with dependency bundling
- **Enhanced Hardware Support**: Added SSD slots for EKF SHU-SHUTTLE configurations
- **Improved Device Communication**: Updated to io4edge_client 2.4.5 for feature enhancement support
- **Advanced ColorLED Control**: Enhanced RGB color handling with improved get/set methods

### For Users
- **Easy Installation**: Debian packages now available with automated dependency resolution
- **More Reliable Hardware Operations**: Improved device communication and error handling
- **Enhanced LED Control**: Better color management and visual feedback capabilities
- **Broader Hardware Support**: Extended compatibility with EKF SHU-SHUTTLE configurations
- **Improved Stability**: Multiple bug fixes for parameter handling and system operations

### For Developers
- **Enhanced CI/CD**: Streamlined build and deployment processes
- **Better Testing**: Comprehensive SSM and LED control test coverage
- **Python 3.10 Compatibility**: Backported syntax for broader compatibility
- **Optimized Dependencies**: Reduced package footprint and improved dependency management

### Technical Highlights
- Updated io4edge_client from 2.4.1 to 2.4.5
- Implemented dynamic Debian revision handling
- Enhanced PyPI package integration and release automation
- Improved ColorLED class with RGB value returns
- Added support for SSD slot configurations in EKF systems
- Fixed critical parameter-set handling bug
- Removed unused dependencies (Pillow) to optimize package size

### Breaking Changes
- ColorLED `get()` method now returns RGB values instead of single color value
- Removed redundant connection management methods from device classes

**Migration Guide**: Users upgrading from 1.9.x should update ColorLED usage to handle RGB return values from the `get()` method.

