## [1.11.0] - 2026-03-03

### Changed
- Release 1.11.0
