"""Skytale integrations for AI agent frameworks and protocols.

Submodules:
    langgraph: LangGraph / LangChain tool bindings
    crewai: CrewAI tool bindings
    mcp: MCP (Model Context Protocol) server (Skytale-as-tools)
    mcp_transport: MCP JSON-RPC transport over encrypted channels
    a2a: A2A (Agent-to-Agent) protocol adapter
    slim: SLIM (Secure Lightweight Inter-agent Messaging) adapter

Legacy underscore-prefixed imports (_langgraph, _crewai, etc.) still work
for backward compatibility.
"""

import importlib

# Map clean names to underscore-prefixed module names
_ALIASES = {
    "langgraph": "_langgraph",
    "crewai": "_crewai",
    "mcp": "_mcp",
    "mcp_transport": "_mcp_transport",
    "a2a": "_a2a",
    "slim": "_slim",
}


def __getattr__(name):
    # Clean name -> underscore module
    if name in _ALIASES:
        return importlib.import_module(f".{_ALIASES[name]}", __package__)
    # Underscore name still works directly
    if name in _ALIASES.values():
        return importlib.import_module(f".{name}", __package__)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
