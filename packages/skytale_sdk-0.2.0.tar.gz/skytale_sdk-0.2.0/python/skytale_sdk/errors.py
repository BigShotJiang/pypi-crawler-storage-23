"""Typed exception hierarchy for the Skytale SDK.

All exceptions extend ``RuntimeError`` for backward compatibility —
existing ``except RuntimeError`` handlers continue to work.

Usage::

    from skytale_sdk.errors import ChannelError, AuthError

    try:
        mgr.create("bad-name")
    except ChannelError as e:
        print(f"channel problem: {e}")
    except RuntimeError:
        print("still works as a catch-all")
"""


class SkytaleError(RuntimeError):
    """Base exception for all Skytale SDK errors."""
    pass


class AuthError(SkytaleError):
    """Invalid or expired API key / JWT."""
    pass


class TransportError(SkytaleError):
    """Relay connection failure or transport-level error."""
    pass


class ChannelError(SkytaleError):
    """Invalid channel name, MLS group error, or message size limit."""
    pass


class QuotaExceededError(SkytaleError):
    """Monthly message quota exceeded."""
    pass


class MlsError(SkytaleError):
    """MLS encryption or decryption failure."""
    pass
