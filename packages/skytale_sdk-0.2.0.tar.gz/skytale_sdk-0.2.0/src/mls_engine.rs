use std::collections::HashMap;
use std::path::{Path, PathBuf};

use mls_rs::group::ReceivedMessage;
use mls_rs::identity::basic::{BasicCredential, BasicIdentityProvider};
use mls_rs::identity::SigningIdentity;
use mls_rs::{CipherSuite, CipherSuiteProvider, Client, CryptoProvider, ExtensionList, MlsMessage};
use mls_rs_crypto_rustcrypto::RustCryptoProvider;
use mls_rs_provider_sqlite::connection_strategy::FileConnectionStrategy;
use mls_rs_provider_sqlite::storage::{
    SqLiteGroupStateStorage, SqLiteKeyPackageStorage, SqLitePreSharedKeyStorage,
};
use mls_rs_provider_sqlite::SqLiteDataStorageEngine;

const MLS_CIPHERSUITE: CipherSuite = CipherSuite::CURVE25519_AES128;

/// Result of processing an incoming MLS message.
#[derive(Debug)]
pub enum ProcessedMessage {
    /// Decrypted application data.
    Application(Vec<u8>),
    /// Commit processed, epoch advanced.
    Commit,
    /// Other MLS message type (proposal, etc.)
    Other,
}

/// Errors from MLS operations.
#[derive(Debug, thiserror::Error)]
pub enum MlsEngineError {
    #[error("MLS client error: {0}")]
    Client(String),

    #[error("MLS group error: {0}")]
    Group(String),

    #[error("group not found for id: {0}")]
    GroupNotFound(String),

    #[error("message serialization error: {0}")]
    Serialization(String),

    #[error("storage error: {0}")]
    Storage(String),

    #[error("unexpected message type")]
    UnexpectedMessageType,
}

/// Concrete mls-rs config type after building with SQLite + RustCrypto + BasicIdentity.
type SdkMlsConfig = mls_rs::client_builder::WithCryptoProvider<
    RustCryptoProvider,
    mls_rs::client_builder::WithIdentityProvider<
        BasicIdentityProvider,
        mls_rs::client_builder::WithPskStore<
            SqLitePreSharedKeyStorage,
            mls_rs::client_builder::WithKeyPackageRepo<
                SqLiteKeyPackageStorage,
                mls_rs::client_builder::WithGroupStateStorage<
                    SqLiteGroupStateStorage,
                    mls_rs::client_builder::BaseConfig,
                >,
            >,
        >,
    >,
>;

type MlsClient = Client<SdkMlsConfig>;
type MlsGroup = mls_rs::Group<SdkMlsConfig>;

/// Wraps mls-rs with persistent SQLite storage for MLS group operations.
///
/// # Example
///
/// ```no_run
/// use skytale_sdk::mls_engine::MlsEngine;
/// let engine = MlsEngine::new(
///     std::path::Path::new("/tmp/mls-data"),
///     b"agent-1".to_vec(),
/// ).unwrap();
/// ```
pub struct MlsEngine {
    #[allow(dead_code)]
    data_dir: PathBuf,
    /// In-memory cache of active groups keyed by hex-encoded group_id.
    groups: HashMap<String, MlsGroup>,
    /// The mls-rs client used to create/join/load groups.
    client: MlsClient,
}

impl MlsEngine {
    /// Create a new MLS engine with state persisted to the given directory.
    pub fn new(data_dir: &Path, identity: Vec<u8>) -> Result<Self, MlsEngineError> {
        std::fs::create_dir_all(data_dir).map_err(|e| MlsEngineError::Storage(e.to_string()))?;

        let db_path = data_dir.join("mls.db");
        let conn_strategy = FileConnectionStrategy::new(&db_path);
        let storage_engine = SqLiteDataStorageEngine::new(conn_strategy)
            .map_err(|e| MlsEngineError::Storage(format!("{e:?}")))?;

        let group_state = storage_engine
            .group_state_storage()
            .map_err(|e| MlsEngineError::Storage(format!("{e:?}")))?;
        let key_package = storage_engine
            .key_package_storage()
            .map_err(|e| MlsEngineError::Storage(format!("{e:?}")))?;
        let psk = storage_engine
            .pre_shared_key_storage()
            .map_err(|e| MlsEngineError::Storage(format!("{e:?}")))?;

        let crypto = RustCryptoProvider::default();
        let cs = crypto
            .cipher_suite_provider(MLS_CIPHERSUITE)
            .ok_or_else(|| MlsEngineError::Client("unsupported cipher suite".into()))?;
        let (secret_key, public_key) = cs
            .signature_key_generate()
            .map_err(|e| MlsEngineError::Client(format!("{e:?}")))?;

        let basic_cred = BasicCredential::new(identity);
        let signing_id = SigningIdentity::new(basic_cred.into_credential(), public_key);

        let client = Client::builder()
            .group_state_storage(group_state)
            .key_package_repo(key_package)
            .psk_store(psk)
            .identity_provider(BasicIdentityProvider)
            .crypto_provider(RustCryptoProvider::default())
            .signing_identity(signing_id, secret_key, MLS_CIPHERSUITE)
            .build();

        Ok(Self {
            data_dir: data_dir.to_path_buf(),
            groups: HashMap::new(),
            client,
        })
    }

    /// Create a new MLS group. Returns the group_id bytes.
    pub fn create_group(&mut self, group_id: &[u8]) -> Result<Vec<u8>, MlsEngineError> {
        let group = self
            .client
            .create_group_with_id(
                group_id.to_vec(),
                ExtensionList::default(),
                Default::default(),
                None,
            )
            .map_err(|e| MlsEngineError::Group(format!("{e:?}")))?;

        let id = hex::encode(group.group_id());
        self.groups.insert(id, group);
        Ok(group_id.to_vec())
    }

    /// Generate a KeyPackage for others to add us to their group.
    pub fn generate_key_package(&self) -> Result<Vec<u8>, MlsEngineError> {
        let kp_msg = self
            .client
            .generate_key_package_message(Default::default(), Default::default(), None)
            .map_err(|e| MlsEngineError::Client(format!("{e:?}")))?;
        kp_msg
            .to_bytes()
            .map_err(|e| MlsEngineError::Serialization(format!("{e:?}")))
    }

    /// Add a member to a group we own. Returns `(commit_bytes, welcome_bytes)`.
    pub fn add_member(
        &mut self,
        group_id: &[u8],
        key_package_bytes: &[u8],
    ) -> Result<(Vec<u8>, Vec<u8>), MlsEngineError> {
        let group = self.get_group_mut(group_id)?;

        let kp_msg = MlsMessage::from_bytes(key_package_bytes)
            .map_err(|e| MlsEngineError::Serialization(format!("{e:?}")))?;

        let commit_output = group
            .commit_builder()
            .add_member(kp_msg)
            .map_err(|e| MlsEngineError::Group(format!("{e:?}")))?
            .build()
            .map_err(|e| MlsEngineError::Group(format!("{e:?}")))?;

        group
            .apply_pending_commit()
            .map_err(|e| MlsEngineError::Group(format!("{e:?}")))?;

        let commit_bytes = commit_output
            .commit_message
            .to_bytes()
            .map_err(|e| MlsEngineError::Serialization(format!("{e:?}")))?;

        let welcome_bytes = commit_output
            .welcome_messages
            .first()
            .ok_or_else(|| MlsEngineError::Group("no welcome message produced".into()))?
            .to_bytes()
            .map_err(|e| MlsEngineError::Serialization(format!("{e:?}")))?;

        Ok((commit_bytes, welcome_bytes))
    }

    /// Join a group from a Welcome message. Returns the group_id.
    pub fn join_from_welcome(&mut self, welcome_bytes: &[u8]) -> Result<Vec<u8>, MlsEngineError> {
        let welcome_msg = MlsMessage::from_bytes(welcome_bytes)
            .map_err(|e| MlsEngineError::Serialization(format!("{e:?}")))?;

        let (group, _info) = self
            .client
            .join_group(None, &welcome_msg, None)
            .map_err(|e| MlsEngineError::Group(format!("{e:?}")))?;

        let group_id = group.group_id().to_vec();
        let id = hex::encode(&group_id);
        self.groups.insert(id, group);
        Ok(group_id)
    }

    /// Encrypt a message for a group.
    pub fn encrypt(
        &mut self,
        group_id: &[u8],
        plaintext: &[u8],
    ) -> Result<Vec<u8>, MlsEngineError> {
        let group = self.get_group_mut(group_id)?;
        let mls_msg = group
            .encrypt_application_message(plaintext, vec![])
            .map_err(|e| MlsEngineError::Group(format!("{e:?}")))?;
        mls_msg
            .to_bytes()
            .map_err(|e| MlsEngineError::Serialization(format!("{e:?}")))
    }

    /// Decrypt a message from a group.
    pub fn decrypt(
        &mut self,
        group_id: &[u8],
        ciphertext: &[u8],
    ) -> Result<Vec<u8>, MlsEngineError> {
        let group = self.get_group_mut(group_id)?;
        let mls_msg = MlsMessage::from_bytes(ciphertext)
            .map_err(|e| MlsEngineError::Serialization(format!("{e:?}")))?;

        match group
            .process_incoming_message(mls_msg)
            .map_err(|e| MlsEngineError::Group(format!("{e:?}")))?
        {
            ReceivedMessage::ApplicationMessage(app_msg) => Ok(app_msg.data().to_vec()),
            _ => Err(MlsEngineError::UnexpectedMessageType),
        }
    }

    /// Process an incoming commit (epoch advancement).
    pub fn process_commit(
        &mut self,
        group_id: &[u8],
        commit_bytes: &[u8],
    ) -> Result<(), MlsEngineError> {
        let group = self.get_group_mut(group_id)?;
        let mls_msg = MlsMessage::from_bytes(commit_bytes)
            .map_err(|e| MlsEngineError::Serialization(format!("{e:?}")))?;

        match group
            .process_incoming_message(mls_msg)
            .map_err(|e| MlsEngineError::Group(format!("{e:?}")))?
        {
            ReceivedMessage::Commit(_) => Ok(()),
            _ => Err(MlsEngineError::UnexpectedMessageType),
        }
    }

    /// Process any incoming MLS message, letting mls-rs determine the type.
    ///
    /// Use this instead of `decrypt`/`process_commit` when the message type is
    /// unknown (e.g., the relay labels everything as `Msg`).
    pub fn process_incoming(
        &mut self,
        group_id: &[u8],
        ciphertext: &[u8],
    ) -> Result<ProcessedMessage, MlsEngineError> {
        let group = self.get_group_mut(group_id)?;
        let mls_msg = MlsMessage::from_bytes(ciphertext)
            .map_err(|e| MlsEngineError::Serialization(format!("{e:?}")))?;

        match group
            .process_incoming_message(mls_msg)
            .map_err(|e| MlsEngineError::Group(format!("{e:?}")))?
        {
            ReceivedMessage::ApplicationMessage(app_msg) => {
                Ok(ProcessedMessage::Application(app_msg.data().to_vec()))
            }
            ReceivedMessage::Commit(_) => Ok(ProcessedMessage::Commit),
            _ => Ok(ProcessedMessage::Other),
        }
    }

    /// Load a group from persistent storage by its ID.
    pub fn load_group(&mut self, group_id: &[u8]) -> Result<(), MlsEngineError> {
        let group = self
            .client
            .load_group(group_id)
            .map_err(|e| MlsEngineError::Group(format!("{e:?}")))?;
        let id = hex::encode(group_id);
        self.groups.insert(id, group);
        Ok(())
    }

    fn get_group_mut(&mut self, group_id: &[u8]) -> Result<&mut MlsGroup, MlsEngineError> {
        let id = hex::encode(group_id);
        if !self.groups.contains_key(&id) {
            // Try to load from persistent storage
            if let Ok(group) = self.client.load_group(group_id) {
                self.groups.insert(id.clone(), group);
            }
        }
        self.groups
            .get_mut(&id)
            .ok_or(MlsEngineError::GroupNotFound(id))
    }
}
