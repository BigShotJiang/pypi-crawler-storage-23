fn main() -> Result<(), Box<dyn std::error::Error>> {
    // Proto client codegen for SLIM DataPlaneService
    tonic_prost_build::configure()
        .build_server(false)
        .build_client(true)
        .compile_protos(
            &[concat!(
                env!("CARGO_MANIFEST_DIR"),
                "/../proto/slim/v1/data_plane.proto"
            )],
            &[concat!(env!("CARGO_MANIFEST_DIR"), "/../proto/slim/v1")],
        )?;
    Ok(())
}
