# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: 
# @Time   : 2025-04-04 21:42
# @Author : 毛鹏
import re
import traceback

from playwright._impl._errors import TargetClosedError
from playwright.async_api import Locator, Error, TimeoutError

from mangoautomation.mangos import AsyncWebBrowser, AsyncWebCustomization, AsyncWebElement, \
    AsyncWebDeviceInput, AsyncWebPage, ElementMain, AsyncWebAssertion
from mangotools.assertion import MangoAssertion
from mangotools.enums import StatusEnum
from ...enums import ElementExpEnum
from ...exceptions import MangoAutomationError
from ...exceptions.error_msg import *

re = re


class AsyncWebDevice(AsyncWebBrowser,
                     AsyncWebPage,
                     AsyncWebElement,
                     AsyncWebDeviceInput,
                     AsyncWebCustomization):

    def __init__(self, base_data):
        super().__init__(base_data)

    async def open_url(self, is_open: bool = False):
        try:
            self.base_data.log.debug('[页面状态检查] 等待页面网络空闲')
            await self.base_data.page.wait_for_load_state('networkidle')
            await self.base_data.page.wait_for_selector('body', state='visible')
            await self.base_data.page.wait_for_function('document.readyState === "complete"')
            self.base_data.log.debug("[页面状态检查] 页面已就绪")
        except TargetClosedError:
            self.base_data.log.error('[页面状态检查] 页面已关闭，需要重新初始化')
            self.base_data.setup()
            raise MangoAutomationError(*ERROR_MSG_0010)
        except Exception as e:
            self.base_data.log.debug(f"[页面状态检查] 等待页面就绪时出现异常（可忽略）: {str(e)}")
        
        if not self.base_data.is_open_url or is_open:
            self.base_data.log.info(f'[URL导航] 准备打开URL: {self.base_data.url} (强制打开: {is_open})')
            await self.w_goto(self.base_data.url)
            self.base_data.is_open_url = True
            self.base_data.log.info('[URL导航] URL打开成功')
        else:
            self.base_data.log.debug('[URL导航] URL已打开，跳过导航')

    async def web_action_element(self, name, ope_key, ope_value, ):
        self.base_data.log.info(f'[元素操作] 开始执行 -> 元素: {name}, 操作: {ope_key}')
        self.base_data.log.debug(f'[元素操作] 操作参数: {ope_value}')
        try:
            await ElementMain.a_element(self, ope_key, ope_value)
            self.base_data.log.info(f'[元素操作] 操作成功 -> {name}.{ope_key}')
        except TimeoutError as error:
            self.base_data.log.error(f'[元素操作超时] 元素: {name}, 操作: {ope_key}, 原因: 等待超时')
            raise MangoAutomationError(*ERROR_MSG_0011, value=(name,))
        except Error as error:
            self.base_data.log.error(f'[元素操作失败] 元素: {name}, Playwright错误: {str(error)}')
            raise MangoAutomationError(*ERROR_MSG_0032, value=(name,))
        except ValueError as error:
            self.base_data.log.error(f'[元素操作失败] 元素: {name}, 参数错误: {str(error)}')
            raise MangoAutomationError(*ERROR_MSG_0012)

    async def web_assertion_element(self, name, ope_key, ope_value) -> str:
        self.base_data.log.info(f'[元素断言] 开始断言 -> 元素: {name}, 断言方法: {ope_key}')
        self.base_data.log.debug(f'[元素断言] 断言参数: {ope_value}')
        is_method = callable(getattr(AsyncWebAssertion, ope_key, None))
        try:
            if is_method:
                if ope_value.get('actual', None) is None:
                    self.base_data.log.error(f'[元素断言失败] 元素: {name}, 原因: 缺少actual参数')
                    raise MangoAutomationError(*ERROR_MSG_0031, value=(name,))
                self.base_data.log.debug(f'[元素断言] 使用Web断言方法: {ope_key}')
                result = await ElementMain.a_element(AsyncWebAssertion(self.base_data), ope_key, ope_value)
            else:
                self.base_data.log.debug(f'[元素断言] 使用通用断言方法: {ope_key}')
                result = MangoAssertion(self.base_data.mysql_connect, self.base_data.test_data) \
                    .ass(ope_key, ope_value.get('actual'), ope_value.get('expect'))
            
            self.base_data.log.info(f'[元素断言] 断言成功 -> {name}.{ope_key}')
            return result
        except AssertionError as error:
            self.base_data.log.error(f'[元素断言失败] 元素: {name}, 断言不通过: {error.args}')
            raise MangoAutomationError(*ERROR_MSG_0017, value=error.args)
        except AttributeError as error:
            self.base_data.log.error(f'[元素断言失败] 元素: {name}, 方法不存在: {ope_key}')
            raise MangoAutomationError(*ERROR_MSG_0048)
        except ValueError as error:
            self.base_data.log.error(f'[元素断言失败] 元素: {name}, 参数错误: {str(error)}')
            raise MangoAutomationError(*ERROR_MSG_0005)
        except Error as error:
            self.base_data.log.error(f'[元素断言失败] 元素: {name}, Playwright错误: {str(error)}')
            raise MangoAutomationError(*ERROR_MSG_0052, value=(name,), )

    async def web_find_element(self, name, _type, exp, loc, sub, is_iframe) \
            -> tuple[Locator, int, str] | tuple[list[Locator], int, str]:
        self.base_data.log.debug(f'[元素查找] 元素: {name}, 表达式: {exp}, 定位: {loc}, 下标: {sub}, iframe: {is_iframe}')
        
        if is_iframe != StatusEnum.SUCCESS.value:
            locator: Locator = await self.__find_ele(self.base_data.page, exp, loc)
            try:
                result = await self.__element_info(locator, sub)
                self.base_data.log.info(f'[元素查找] 找到元素 -> {name}, 数量: {result[1]}')
                return result
            except TargetClosedError:
                self.base_data.log.error('[元素查找失败] 页面已关闭')
                self.base_data.setup()
                raise MangoAutomationError(*ERROR_MSG_0010)
            except Error as error:
                self.base_data.log.debug(f'[元素查找失败] 元素: {name}, 定位: {loc}, 错误: {str(error)}')
                raise MangoAutomationError(*ERROR_MSG_0041, value=(name, loc))
        else:
            self.base_data.log.debug(f'[元素查找] 在iframe中查找元素: {name}')
            return await self.__is_iframe(_type, exp, loc, sub)

    async def __element_info(self, locator: Locator, sub) -> tuple[Locator, int, str]:
        count = await locator.count()
        if sub is not None:
            locator = locator.nth(sub - 1) if sub else locator
        try:
            text = await self.w_get_text(locator)
        except Exception:
            text = None
        return locator, count, text

    async def ai_element_info(self, locator: Locator) -> tuple[Locator, int, str]:
        count = await locator.count()
        try:
            text = await self.w_get_text(locator)
        except Exception:
            text = None
        return locator, count, text

    async def __is_iframe(self, _type, exp, loc, sub):
        ele_list: list[Locator] = []
        frame_count = len(self.base_data.page.frames)
        self.base_data.log.debug(f'[iframe查找] 检测到 {frame_count} 个frame')
        
        for idx, frame in enumerate(self.base_data.page.frames):
            locator: Locator = await self.__find_ele(frame, exp, loc)
            try:
                count = await locator.count()
                if count > 0:
                    self.base_data.log.debug(f'[iframe查找] 在frame[{idx}]中找到 {count} 个元素')
                    for nth in range(0, count):
                        ele_list.append(locator.nth(nth))
            except Error as error:
                self.base_data.log.debug(f'[iframe查找] frame[{idx}]查找失败: {str(error)}')
                raise MangoAutomationError(*ERROR_MSG_0041, )
        
        if not ele_list:
            self.base_data.log.error(f'[iframe查找失败] 在所有frame中都未找到元素')
            raise MangoAutomationError(*ERROR_MSG_0023)
        
        try:
            count = len(ele_list)
            loc = ele_list[sub - 1] if sub else ele_list[0]
            try:
                text = await self.w_get_text(loc)
            except Exception:
                text = None
            self.base_data.log.info(f'[iframe查找] 找到元素，总数: {count}, 选择下标: {sub if sub else 0}')
            return loc, count, text
        except IndexError:
            self.base_data.log.error(f'[iframe查找失败] 下标越界，总数: {len(ele_list)}, 请求下标: {sub}')
            raise MangoAutomationError(*ERROR_MSG_0025, value=(len(ele_list),))

    async def __find_ele(self, page, exp, loc) -> Locator:
        if exp == ElementExpEnum.LOCATOR.value:
            try:
                return eval(f"await page.{loc}")
            except SyntaxError:
                try:
                    return eval(f"page.{loc}")
                except SyntaxError as error:
                    self.base_data.log.error(f'[定位表达式错误] LOCATOR语法错误: {loc}')
                    raise MangoAutomationError(*ERROR_MSG_0022)
                except NameError as error:
                    self.base_data.log.error(f'[定位表达式错误] LOCATOR变量未定义: {loc}')
                    raise MangoAutomationError(*ERROR_MSG_0060)
        elif exp == ElementExpEnum.XPATH.value:
            self.base_data.log.debug(f'[定位方式] 使用XPATH: {loc}')
            return page.locator(f'xpath={loc}')
        elif exp == ElementExpEnum.CSS.value:
            self.base_data.log.debug(f'[定位方式] 使用CSS: {loc}')
            return page.locator(loc)
        elif exp == ElementExpEnum.TEXT.value:
            self.base_data.log.debug(f'[定位方式] 使用TEXT: {loc}')
            return page.get_by_text(loc, exact=True)
        elif exp == ElementExpEnum.PLACEHOLDER.value:
            self.base_data.log.debug(f'[定位方式] 使用PLACEHOLDER: {loc}')
            return page.get_by_placeholder(loc)
        else:
            self.base_data.log.error(f'[定位方式错误] 不支持的定位方式: {exp}')
            raise MangoAutomationError(*ERROR_MSG_0020)
