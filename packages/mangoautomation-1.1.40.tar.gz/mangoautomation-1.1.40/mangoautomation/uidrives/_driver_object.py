# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description:
# @Time   : 2024-04-24 10:43
# @Author : 毛鹏

from typing import Optional
from mangoautomation.mangos import NewAndroid, AsyncWebNewBrowser, SyncWebNewBrowser
from ..uidrives.pc.new_windows import NewWindows



class DriverObject:

    def __init__(self, log, is_async=False):
        self.log = log
        self.is_async = is_async
        self.web: Optional[AsyncWebNewBrowser | SyncWebNewBrowser] = None
        self.android: Optional[NewAndroid] = None
        self.windows: Optional[NewWindows] = None

    def set_web(self, **kwargs):
        kwargs['log'] = self.log
        self.log.info(f'[驱动初始化] 初始化Web驱动 (异步模式: {self.is_async})')
        if self.is_async:
            self.web = AsyncWebNewBrowser(**kwargs)
        else:
            self.web = SyncWebNewBrowser(**kwargs)
        self.log.debug('[驱动初始化] Web驱动初始化完成')

    def set_android(self, and_equipment: str):
        self.log.info(f'[驱动初始化] 初始化Android驱动: {and_equipment}')
        self.android = NewAndroid(and_equipment)
        self.log.debug('[驱动初始化] Android驱动初始化完成')

    def set_windows(self, win_path: str, win_title: str):
        self.log.info(f'[驱动初始化] 初始化Windows驱动: {win_path}, 标题: {win_title}')
        self.windows = NewWindows(win_path, win_title)
        self.log.debug('[驱动初始化] Windows驱动初始化完成')