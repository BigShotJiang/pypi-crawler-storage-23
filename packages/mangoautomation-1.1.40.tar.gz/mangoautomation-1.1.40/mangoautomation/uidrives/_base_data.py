# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: 
# @Time   : 2024-02-04 10:43
# @Author : 毛鹏
from typing import Optional
from unittest.mock import MagicMock

import sys
from playwright.async_api import Page as AsyncPage, BrowserContext as AsyncBrowserContext
from playwright.sync_api import Page as SyncPage, BrowserContext as SyncBrowserContext
from uiautomator2 import Device

from mangoautomation.enums import DriveTypeEnum
from mangoautomation.exceptions import MangoAutomationError
from mangoautomation.exceptions.error_msg import ERROR_MSG_0010, ERROR_MSG_0007
from mangotools.data_processor import DataProcessor
from mangotools.database import MysqlConnect
from mangotools.enums import StatusEnum
from mangotools.models import MysqlConingModel

if not sys.platform.startswith('win32'):
    WindowControl = MagicMock()
    print("警告: uiautomation 仅支持 Windows，当前环境已自动跳过")
else:
    from uiautomation import WindowControl


class BaseData:

    def __init__(self, test_data: DataProcessor, log):
        super().__init__()
        self.test_data = test_data
        self.log = log
        self.download_path: Optional[str | None] = None
        self.screenshot_path: Optional[str | None] = None

        self.is_ai = False
        self.api_key = None
        self.base_url = None
        self.model = None

        self.mysql_config: Optional[MysqlConingModel | None] = None
        self.mysql_connect: Optional[MysqlConnect | None] = None

        self.url: Optional[str | None] = None
        self.is_open_url = False
        self.page: Optional[AsyncPage | SyncPage | None] = None
        self.context: Optional[AsyncBrowserContext | SyncBrowserContext | None] = None

        self.package_name: Optional[str | None] = None
        self.android: Optional[Device | None] = None
        self.is_open_app = False

        self.window: Optional[None | WindowControl] = None

    def set_file_path(self, download_path, screenshot_path):
        self.download_path = download_path
        self.screenshot_path = screenshot_path
        self.log.debug(f'[路径配置] 下载路径: {download_path}, 截图路径: {screenshot_path}')
        return self

    def set_url(self, url: str):
        self.url = url
        self.log.debug(f'[URL配置] 设置URL: {url}')
        return self

    def set_page_context(self, page, context):
        self.page = page
        self.context = context
        self.log.debug('[页面配置] Page和Context已设置')
        return self

    def set_package_name(self, package_name: str):
        self.package_name = package_name
        self.log.debug(f'[包名配置] 设置包名: {package_name}')
        return self

    def set_android(self, android: Device):
        self.android = android
        self.log.debug('[Android配置] Android设备已设置')
        return self

    def setup(self) -> None:
        self.log.debug('[资源清理] 开始清理资源')
        self.url = None
        self.page = None
        self.context = None
        self.is_open_url = False
        self.package_name = None
        self.android = None
        self.mysql_connect = None
        self.mysql_config = None
        self.log.debug('[资源清理] 资源清理完成')

    async def async_base_close(self):
        self.log.info('[资源关闭] 开始关闭异步资源')
        if self.context:
            await self.context.close()
            self.log.debug('[资源关闭] Context已关闭')
        if self.page:
            await self.page.close()
            self.log.debug('[资源关闭] Page已关闭')
        if self.mysql_connect:
            self.mysql_connect.close()
            self.log.debug('[资源关闭] MySQL连接已关闭')
        self.setup()
        self.log.info('[资源关闭] 异步资源关闭完成')

    def sync_base_close(self):
        self.log.info('[资源关闭] 开始关闭同步资源')
        if self.context:
            self.context.close()
            self.log.debug('[资源关闭] Context已关闭')
        if self.page:
            self.page.close()
            self.log.debug('[资源关闭] Page已关闭')
        if self.mysql_connect:
            self.mysql_connect.close()
            self.log.debug('[资源关闭] MySQL连接已关闭')
        self.setup()
        self.log.info('[资源关闭] 同步资源关闭完成')

    def set_mysql(self, db_c_status, db_rud_status, mysql_config: MysqlConingModel):
        self.mysql_config = mysql_config
        if StatusEnum.SUCCESS.value in [db_c_status, db_rud_status]:
            self.log.info(f'[数据库连接] 初始化MySQL连接: {mysql_config.host}:{mysql_config.port}/{mysql_config.database}')
            self.mysql_connect = MysqlConnect(mysql_config,
                                              bool(db_c_status),
                                              bool(db_rud_status))
            self.log.debug('[数据库连接] MySQL连接初始化完成')
        else:
            self.log.debug('[数据库连接] 跳过MySQL连接初始化')
        return self

    def verify_equipment(self, drive_type: int):
        if drive_type == DriveTypeEnum.WEB.value:
            if not self.page or not self.context:
                self.log.error('[设备验证] Web设备未初始化')
                raise MangoAutomationError(*ERROR_MSG_0010)
            self.log.debug('[设备验证] Web设备验证通过')
        elif drive_type == DriveTypeEnum.ANDROID.value:
            if not self.android:
                self.log.error('[设备验证] Android设备未初始化')
                raise MangoAutomationError(*ERROR_MSG_0007)
            self.log.debug('[设备验证] Android设备验证通过')
        else:
            self.log.debug(f'[设备验证] 设备类型 {drive_type} 无需验证')

    def set_agent(self, is_ai: bool, api_key: str, base_url: str='https://api.siliconflow.cn/v1', model: str='THUDM/GLM-Z1-9B-0414'):
        self.is_ai = is_ai
        self.api_key = api_key
        self.base_url = base_url
        self.model = model
        if is_ai:
            self.log.info(f'[AI配置] 启用AI定位，模型: {model}')
        else:
            self.log.debug('[AI配置] AI定位未启用')
        return self