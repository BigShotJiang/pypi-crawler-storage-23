# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: 
# @Time   : 2025-04-12 15:55
# @Author : 毛鹏
import os
import traceback
from typing import Optional

import itertools
import time
from playwright._impl._errors import TargetClosedError, Error

from mangoautomation.mangos import WebAIFinder
from mangotools.assertion import MangoAssertion
from mangotools.decorator import sync_retry
from mangotools.enums import StatusEnum
from ..enums import ElementOperationEnum, DriveTypeEnum
from ..exceptions import MangoAutomationError
from ..exceptions.error_msg import *
from ..models import ElementResultModel, ElementModel, ElementListResultModel
from ..uidrives.android import AndroidDriver
from ..uidrives.web import SyncWebDevice, SyncWebAssertion

env_value = os.getenv("FAILED_RETRY_TIME")
if env_value is None or env_value == 'None':
    FAILED_RETRY_TIME = 25
else:
    FAILED_RETRY_TIME = int(env_value)


class SyncElement(SyncWebDevice, AndroidDriver):

    def __init__(self, base_data, drive_type: int, ):
        super().__init__(base_data)
        self.drive_type = drive_type
        self.element_model: Optional[ElementModel | None] = None
        self.element_result_model: Optional[ElementResultModel | None] = None
        self.element_list_model: Optional[list[ElementModel] | None] = None
        self.test_data = self.base_data.test_data
        self.elements = itertools.cycle([])
        self.elements_count = 0
        self.failed_expression = []
        if self.base_data.is_ai:
            self.agent = WebAIFinder(self.base_data.log, self.base_data.api_key, self.base_data.base_url,
                                     self.base_data.model)

    def open_device(self, is_open: bool = False):
        self.base_data.log.debug(f'[设备打开] 设备类型: {self.drive_type}, 强制打开: {is_open}')
        if self.drive_type == DriveTypeEnum.WEB.value:
            self.open_url(is_open)
            self.base_data.log.info('[设备打开] Web设备已就绪')
        elif self.drive_type == DriveTypeEnum.ANDROID.value:
            self.open_app()
            self.base_data.log.info('[设备打开] Android设备已就绪')
        elif self.drive_type == DriveTypeEnum.DESKTOP.value:
            self.base_data.log.info('[设备打开] Desktop设备已就绪')
        else:
            self.base_data.log.error(f'[设备打开失败] 不支持的设备类型: {self.drive_type}')
            raise Exception('不存在的设备类型')

    def element_main(self,
                     element_model: ElementModel,
                     element_list_model: list[ElementModel] | None = None) -> ElementResultModel:
        self.element_model = element_model
        if self.element_model and self.element_model.elements:
            self.elements = itertools.cycle(self.element_model.elements)
        self.element_list_model = element_list_model
        self.element_result_model = ElementResultModel(
            id=self.element_model.id,
            name=self.element_model.name,
            sleep=self.element_model.sleep,

            type=self.element_model.type.value,
            ope_key=self.element_model.ope_key,
            sql_execute=self.element_model.sql_execute,
            custom=self.element_model.custom,

            status=StatusEnum.FAIL.value,
        )
        
        self.base_data.log.info(f'[元素执行] ========== 开始执行元素: {self.element_model.name} (ID: {self.element_model.id}) ==========')
        self.base_data.log.debug(f'[元素执行] 元素类型: {self.element_model.type.value}, 操作: {self.element_model.ope_key}')
        
        try:
            self.init_element()
            self.__main()
            if self.element_model.sleep:
                self.base_data.log.debug(f'[元素执行] 等待 {self.element_model.sleep}秒')
                time.sleep(self.element_model.sleep)
            self.element_result_model.status = StatusEnum.SUCCESS.value
            self.element_result_model.error_message = None
            self.base_data.log.info(f'[元素执行] ========== 元素执行成功: {self.element_model.name} ==========')
        except MangoAutomationError as error:
            self.base_data.log.debug(f'[元素执行异常] 业务异常 -> {self.element_model.name}: {error.msg}')
            self.__error(error.msg)
        except TargetClosedError as error:
            self.base_data.setup()
            self.base_data.log.error(f'[元素执行异常] 页面已关闭 -> {self.element_model.name}')
            self.__error(ERROR_MSG_0010[1], False)
        except Error as error:
            self.base_data.log.error(f'[元素执行异常] Playwright错误 -> {self.element_model.name}: {error.message}\n{traceback.format_exc()}')
            self.__error(f'Playwright错误，请检查测试数据或联系管理员，提示：{error.message}')
        except Exception as error:
            error_msg = f'未知错误，请检查测试数据或联系管理员，提示：{error.args}'
            if hasattr(error, 'msg'):
                error_msg = error.msg
            self.base_data.log.error(f'[元素执行异常] 未知错误 -> {self.element_model.name}: {str(error)}\n{traceback.format_exc()}')
            self.__error(error_msg)
        return self.element_result_model

    @sync_retry(FAILED_RETRY_TIME)
    def __main(self):
        self.base_data.verify_equipment(self.drive_type)
        self.base_data.log.debug(f'[元素类型判断] 元素类型: {self.element_model.type}')
        
        if self.element_model.type == ElementOperationEnum.OPE:
            self.base_data.log.debug('[元素类型判断] 执行操作类型')
            self.__ope()
        elif self.element_model.type == ElementOperationEnum.ASS:
            self.base_data.log.debug('[元素类型判断] 执行断言类型')
            self.__ass()
        elif self.element_model.type == ElementOperationEnum.SQL:
            self.base_data.log.debug('[元素类型判断] 执行SQL类型')
            self.__sql()
        elif self.element_model.type == ElementOperationEnum.CUSTOM:
            self.base_data.log.debug('[元素类型判断] 执行自定义类型')
            self.__custom()
        elif self.element_model.type == ElementOperationEnum.CONDITION:
            self.base_data.log.debug('[元素类型判断] 执行条件判断类型')
            self.__condition()
        elif self.element_model.type == ElementOperationEnum.PYTHON_CODE:
            self.base_data.log.debug('[元素类型判断] 执行Python代码类型')
            self.__python_code()
        else:
            self.base_data.log.error(f'[元素类型判断] 不支持的元素类型: {self.element_model.type}')
            raise MangoAutomationError(*ERROR_MSG_0015)

    def init_element(self):
        try:
            self.base_data.log.debug('[元素初始化] 开始解析元素数据')
            for i in self.element_model.elements:
                i.loc = self.base_data.test_data.replace(i.loc)
                i.sub = self.base_data.test_data.replace(i.sub)
            self.element_model.sleep = self.base_data.test_data.replace(self.element_model.sleep)
            self.element_result_model.sleep = self.element_model.sleep
            self.base_data.log.debug('[元素初始化] 元素数据解析完成')
        except MangoAutomationError as error:
            self.base_data.log.error(f'[元素初始化失败] 数据解析失败: {error.msg}')
            raise MangoAutomationError(error.code, error.msg)

    def __ope(self):
        method_name = getattr(self.element_model, 'ope_key', None)
        if not method_name:
            self.base_data.log.error('[操作执行] ope_key不存在或为空')
            raise MangoAutomationError(*ERROR_MSG_0048)
        if not hasattr(self, method_name):
            self.base_data.log.error(f'[操作执行] 方法不存在: {method_name}')
            raise MangoAutomationError(*ERROR_MSG_0048)
        if not callable(getattr(self, method_name)):
            self.base_data.log.error(f'[操作执行] 属性不可调用: {method_name}')
            raise MangoAutomationError(*ERROR_MSG_0048)
        
        self.__ope_value()
        self.base_data.log.info(f'[操作执行] 执行操作方法: {method_name}')
        
        if self.drive_type == DriveTypeEnum.WEB.value:
            self.web_action_element(
                self.element_model.name,
                self.element_model.ope_key,
                {i.f: i.v for i in self.element_model.ope_value}
            )
        elif self.drive_type == DriveTypeEnum.ANDROID.value:
            self.a_action_element(
                self.element_model.name,
                self.element_model.ope_key,
                {i.f: i.v for i in self.element_model.ope_value}
            )
        else:
            pass
        self.element_result_model.ope_value = self.element_model.ope_value
        for i in self.element_result_model.ope_value:
            if not isinstance(i.v, str):
                i.v = str(i.v)

    def __ass(self, _ope_value: dict | None = None):
        if self.element_model.ope_value is None:
            self.base_data.log.error('[断言执行] ope_value为空')
            raise MangoAutomationError(*ERROR_MSG_0054)
        
        self.__ope_value(True)
        ope_value = {i.f: i.v for i in self.element_model.ope_value}
        if _ope_value is not None:
            ope_value.update(_ope_value)
        
        self.base_data.log.info(f'[断言执行] 执行断言: {self.element_model.ope_key}')
        
        try:
            if self.drive_type == DriveTypeEnum.WEB.value:
                self.element_result_model.ass_msg = self.web_assertion_element(
                    self.element_model.name,
                    self.element_model.ope_key,
                    ope_value
                )
            elif self.drive_type == DriveTypeEnum.ANDROID.value:
                self.element_result_model.ass_msg = self.a_assertion_element(
                    self.element_model.name,
                    self.element_model.ope_key,
                    ope_value
                )
            else:
                pass
        except MangoAutomationError as error:
            self.element_result_model.ass_msg = error.msg
            raise error
        
        self.element_result_model.ope_value = self.element_model.ope_value
        for i in self.element_result_model.ope_value:
            if not isinstance(i.v, str):
                i.v = str(i.v)

    def __sql(self):
        def run(sql, key_list):
            self.base_data.log.info(f'[SQL执行] 执行SQL: {sql}')
            result_list: list[dict] = self.base_data.mysql_connect.condition_execute(sql)
            self.base_data.log.debug(f'[SQL执行] SQL结果: {result_list}')
            if not isinstance(result_list, list) or not len(result_list) > 0:
                self.base_data.log.error(f'[SQL执行失败] SQL未返回有效结果')
                raise MangoAutomationError(*ERROR_MSG_0036, value=(self.element_model.sql_execute,))
            self.base_data.test_data.set_sql_cache(key_list, result_list[0])
            self.base_data.log.info(f'[SQL执行] 结果已缓存，key: {key_list}')

        if self.base_data.mysql_connect:
            for i in self.element_model.sql_execute:
                run(i.get('sql'), i.get('key_list'))
        else:
            self.base_data.log.error('[SQL执行失败] 数据库连接未初始化')

    def __custom(self):
        self.base_data.log.info(f'[自定义变量] 开始设置 {len(self.element_model.custom)} 个自定义变量')
        for i in self.element_model.custom:
            value = self.base_data.test_data.replace(i.get('value'))
            self.base_data.log.info(f'[自定义变量] 设置变量 -> key: {i.get("key")}, value: {value}')
            self.base_data.test_data.set_cache(i.get('key'), value)

    async def __condition(self):
        self.base_data.log.info(f'[条件判断] 开始条件判断，共 {len(self.element_list_model)} 个分支')
        error_list = []
        for idx, i in enumerate(self.element_list_model):
            try:
                condition_value = self.base_data.test_data.replace(i.condition_value)
                self.base_data.log.debug(f'[条件判断] 分支[{idx}] 条件: {condition_value}')
                await self.__ass(condition_value)
                self.element_result_model.next_node_id = i.id
                self.base_data.log.info(f'[条件判断] 分支[{idx}]匹配成功，跳转到节点: {i.id}')
                return
            except Exception as error:
                self.base_data.log.debug(f'[条件判断] 分支[{idx}]不匹配: {str(error)}')
                if i.condition_value is None and len(self.element_list_model) >= 2:
                    self.element_result_model.next_node_id = self.element_list_model[1].id
                    self.base_data.log.info(f'[条件判断] 默认分支，跳转到节点: {self.element_list_model[1].id}')
                    return
                elif i.condition_value is None:
                    self.base_data.log.error('[条件判断失败] 缺少默认分支')
                    raise MangoAutomationError(*ERROR_MSG_0051)
                error_list.append(error)

        self.base_data.log.error('[条件判断失败] 所有分支都不匹配')
        raise error_list[0]

    def __python_code(self):
        self.base_data.log.info(f'[Python代码] 开始执行自定义Python函数')
        self.base_data.log.debug(f'[Python代码] 函数代码:\n{self.element_model.func}')
        global_namespace = {}
        exec(self.element_model.func, global_namespace)
        global_namespace['func'](self)
        self.base_data.log.info('[Python代码] 函数执行完成')

    def __ope_value(self, is_ass: bool = False):
        try:
            ope_key = 'actual' if is_ass else 'locating'
            self.base_data.log.debug(f'[操作值获取] 获取{"断言" if is_ass else "定位"}值')
            for i in self.element_model.ope_value:
                if i.f == ope_key and self.element_model.elements:
                    self.query_element(i, is_ass)
                else:
                    i.v = self.base_data.test_data.replace(i.v)
        except AttributeError as error:
            self.base_data.log.error(f'[操作值获取失败] 属性错误: {str(error)}\n{traceback.format_exc()}')
            raise MangoAutomationError(*ERROR_MSG_0027)

    def query_element(self, i, is_ass):
        random_element = next(self.elements)
        self.elements_count += 1
        find_params = {
            'name': self.element_model.name,
            '_type': self.element_model.type,
            'exp': random_element.exp,
            'loc': random_element.loc,
            'sub': random_element.sub
        }
        loc_text = random_element.loc
        
        self.base_data.log.debug(f'[元素定位] 尝试定位元素 (第{self.elements_count}次): {random_element.loc}')
        
        try:
            if self.drive_type == DriveTypeEnum.WEB.value:
                loc, ele_quantity, element_text = self.web_find_element(**find_params,
                                                                        is_iframe=random_element.is_iframe)
            elif self.drive_type == DriveTypeEnum.ANDROID.value:
                loc, ele_quantity, element_text = self.a_find_ele(**find_params)
            else:
                loc, ele_quantity, element_text = None, 0, None
        except MangoAutomationError as e:
            if not self.base_data.is_ai:
                raise e
            if self.elements_count < len(self.element_model.elements):
                raise e
            
            self.base_data.log.info(f'[AI定位] 常规定位失败，启用AI定位')
            self.failed_expression.append(find_params.get('loc'))
            self.elements_count = 0
            loc, loc_text = self.agent.ai_find_element_sync(self.base_data.page,
                                                            self.element_model.name,
                                                            random_element.prompt,
                                                            failed_expression=self.failed_expression)
            loc, ele_quantity, element_text = self.ai_element_info(loc)
            self.base_data.log.info(f'[AI定位] AI定位成功: {loc_text}')
        
        if loc_text not in self.failed_expression:
            self.failed_expression.append(loc_text)
        
        element_exists = any(
            existing.exp == random_element.exp and
            existing.loc == random_element.loc and
            existing.sub == random_element.sub and
            existing.is_iframe == random_element.is_iframe
            for existing in self.element_result_model.elements
        )
        if not element_exists:
            new_element = ElementListResultModel(
                exp=random_element.exp,
                loc=random_element.loc,
                sub=random_element.sub,
                ele_quantity=ele_quantity,
                element_text=element_text,
                is_iframe=random_element.is_iframe
            )
            self.element_result_model.elements.append(new_element)
        
        if ele_quantity < 1 and self.element_model.type == ElementOperationEnum.OPE.value:
            self.base_data.log.error(f'[元素定位失败] 未找到元素: {random_element.loc}')
            raise MangoAutomationError(*ERROR_MSG_0053)
        
        if is_ass:
            if callable(getattr(SyncWebAssertion, self.element_model.ope_key, None)):
                i.v = loc
            elif callable(getattr(MangoAssertion(), self.element_model.ope_key, None)):
                i.v = element_text
        else:
            i.v = loc

    def __error(self, msg: str, is_screenshot: bool = True):
        try:
            self.element_result_model.status = StatusEnum.FAIL.value
            self.element_result_model.error_message = msg
            self.base_data.log.error(f'[元素执行失败] ========== 元素: {self.element_model.name} 执行失败 ==========')
            self.base_data.log.error(f'[元素执行失败] 失败原因: {msg}')
            self.base_data.log.debug(f'[元素执行失败] 元素详情: {self.element_model.model_dump() if self.element_model else None}')
            
            if is_screenshot:
                file_name = f'失败截图-{self.element_model.name}{self.base_data.test_data.time_stamp()}.jpg'
                self.base_data.log.debug(f'[失败截图] 开始截图: {file_name}')
                self.__error_screenshot(file_name)
                self.element_result_model.picture_path = os.path.join(self.base_data.screenshot_path, file_name)
                self.element_result_model.picture_name = file_name
                self.base_data.log.info(f'[失败截图] 截图已保存: {file_name}')
        except MangoAutomationError as error:
            self.element_result_model.error_message += f'，截图失败: {error.msg}'
            self.base_data.log.error(f'[失败截图] 截图失败: {error.msg}')
        except Exception as error:
            self.base_data.log.error(f'[失败截图] 截图异常: {str(error)}\n{traceback.format_exc()}')

    def __error_screenshot(self, file_path):
        if self.drive_type == DriveTypeEnum.WEB.value:
            self.w_screenshot(file_path)
        elif self.drive_type == DriveTypeEnum.ANDROID.value:
            self.a_screenshot(file_path)
        else:
            self.base_data.log.debug(f'[失败截图] 设备类型 {self.drive_type} 不支持截图')
