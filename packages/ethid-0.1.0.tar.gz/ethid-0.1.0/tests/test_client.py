"""
Tests for ETH.id Python SDK client.
"""

import pytest
from datetime import datetime
from pathlib import Path

from ethid import (
    EthIdClient,
    LLMProvider,
    VerificationResult,
    AttestationBundle,
    AuditEntry,
    DocumentParsingError,
    ClaimParsingError,
    VerificationError,
)


class TestEthIdClient:
    """Test EthIdClient functionality."""
    
    def test_client_initialization(self):
        """Test client can be initialized."""
        client = EthIdClient()
        assert client is not None
        assert client.cli_path is not None
    
    def test_client_with_provider(self):
        """Test client initialization with provider."""
        client = EthIdClient(provider=LLMProvider.OPENAI)
        assert client.provider == LLMProvider.OPENAI
    
    def test_client_offline_mode(self):
        """Test client in offline mode."""
        client = EthIdClient(offline=True)
        assert client.offline is True
    
    def test_client_debug_mode(self):
        """Test client in debug mode."""
        client = EthIdClient(debug=True)
        assert client.debug is True
    
    def test_verify_nonexistent_document(self):
        """Test verification with nonexistent document."""
        client = EthIdClient()
        
        with pytest.raises(DocumentParsingError):
            client.verify(
                document_path="nonexistent.pdf",
                claim="over 18 years old"
            )
    
    def test_verification_result_to_dict(self):
        """Test VerificationResult serialization."""
        from ethid.types import PrivacyMetadata, FilterMode, ProofType
        
        privacy_meta = PrivacyMetadata(
            filter_mode=FilterMode.VIRTUALIZATION,
            original_hash="abc123",
            filtered_hash="def456",
            fields_included=["age"],
            fields_masked=[],
            timestamp=datetime.now(),
        )
        
        result = VerificationResult(
            session_id="test-123",
            answer=True,
            confidence=0.95,
            reasoning="Age calculation confirms",
            proof_type=ProofType.ZK,
            claim="over 18 years old",
            privacy_metadata=privacy_meta,
            timestamp=datetime.now(),
        )
        
        result_dict = result.to_dict()
        assert result_dict["session_id"] == "test-123"
        assert result_dict["answer"] is True
        assert result_dict["confidence"] == 0.95
    
    def test_attestation_bundle_integrity(self):
        """Test attestation bundle integrity verification."""
        from ethid.types import PrivacyMetadata, FilterMode, ProofType
        import hashlib
        import json
        
        privacy_meta = PrivacyMetadata(
            filter_mode=FilterMode.VIRTUALIZATION,
            original_hash="abc123",
            filtered_hash="def456",
            fields_included=["age"],
            fields_masked=[],
            timestamp=datetime.now(),
        )
        
        result = VerificationResult(
            session_id="test-123",
            answer=True,
            confidence=0.95,
            reasoning="Test",
            proof_type=ProofType.ZK,
            claim="test claim",
            privacy_metadata=privacy_meta,
            timestamp=datetime.now(),
        )
        
        # Create bundle with correct hash
        bundle_data = {
            "session_id": "test-123",
            "document_hash": "doc-hash",
            "claim": "test claim",
            "result": result.to_dict(),
            "proof_type": ProofType.ZK.value,
        }
        
        bundle_hash = hashlib.sha256(
            json.dumps(bundle_data, sort_keys=True).encode()
        ).hexdigest()
        
        bundle = AttestationBundle(
            session_id="test-123",
            document_hash="doc-hash",
            claim="test claim",
            result=result,
            proof_type=ProofType.ZK,
            bundle_hash=bundle_hash,
            created_at=datetime.now(),
        )
        
        assert bundle.verify_integrity() is True
    
    def test_audit_entry_to_dict(self):
        """Test AuditEntry serialization."""
        from ethid.types import ProofType
        
        entry = AuditEntry(
            session_id="test-123",
            document_hash="doc-hash",
            claim="test claim",
            answer=True,
            confidence=0.95,
            proof_type=ProofType.ZK,
            timestamp=datetime.now(),
        )
        
        entry_dict = entry.to_dict()
        assert entry_dict["session_id"] == "test-123"
        assert entry_dict["answer"] is True


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
