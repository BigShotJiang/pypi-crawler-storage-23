"""
Setup script for ETH.id Python SDK.
"""

from setuptools import setup, find_packages

setup(
    name="ethid",
    packages=find_packages(),
    include_package_data=True,
)
