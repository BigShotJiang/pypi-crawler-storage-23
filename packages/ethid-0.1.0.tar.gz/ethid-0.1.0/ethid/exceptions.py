"""
Exception classes for ETH.id Python SDK.
"""


class EthIdError(Exception):
    """Base exception for all ETH.id errors."""
    pass


class DocumentParsingError(EthIdError):
    """Error parsing document."""
    pass


class ClaimParsingError(EthIdError):
    """Error parsing claim."""
    pass


class VerificationError(EthIdError):
    """Error during verification."""
    pass


class AttestationError(EthIdError):
    """Error with attestation."""
    pass


class PrivacyFilterError(EthIdError):
    """Error in privacy filtering."""
    pass


class ConfigurationError(EthIdError):
    """Error in configuration."""
    pass


class NetworkError(EthIdError):
    """Network communication error."""
    pass


class AuthenticationError(EthIdError):
    """Authentication error with LLM provider."""
    pass
