"""
ETH.id Python SDK

Zero-Knowledge Document Verification SDK for Python.
"""

__version__ = "0.1.0"
__author__ = "ETH.id Contributors"
__license__ = "MIT"

from .client import EthIdClient
from .types import (
    VerificationResult,
    AttestationBundle,
    AuditEntry,
    ClaimType,
    FilterMode,
    LLMProvider,
)
from .exceptions import (
    EthIdError,
    DocumentParsingError,
    ClaimParsingError,
    VerificationError,
    AttestationError,
)

__all__ = [
    "EthIdClient",
    "VerificationResult",
    "AttestationBundle",
    "AuditEntry",
    "ClaimType",
    "FilterMode",
    "LLMProvider",
    "EthIdError",
    "DocumentParsingError",
    "ClaimParsingError",
    "VerificationError",
    "AttestationError",
]
