"""
Type definitions for ETH.id Python SDK.
"""

from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import Optional, Dict, Any, List


class ClaimType(str, Enum):
    """Types of claims that can be verified."""
    DATE = "date"
    IDENTITY = "identity"
    AMOUNT = "amount"
    SIGNATURE = "signature"
    PRESENCE = "presence"
    COMPARATIVE = "comparative"


class FilterMode(str, Enum):
    """Privacy filter modes."""
    VIRTUALIZATION = "virtualization"
    HASH_PARTIAL = "hash_partial"
    MINIMIZATION = "minimization"


class LLMProvider(str, Enum):
    """Supported LLM providers."""
    OPENAI = "openai"
    CLAUDE = "claude"
    OLLAMA = "ollama"


class ProofType(str, Enum):
    """Type of proof used for verification."""
    ZK = "zk"
    LLM = "llm"
    HYBRID = "hybrid"


@dataclass
class PrivacyMetadata:
    """Metadata about privacy filtering."""
    filter_mode: FilterMode
    original_hash: str
    filtered_hash: str
    fields_included: List[str]
    fields_masked: List[str]
    timestamp: datetime


@dataclass
class VerificationResult:
    """Result of a document verification."""
    session_id: str
    answer: bool
    confidence: float
    reasoning: str
    proof_type: ProofType
    claim: str
    privacy_metadata: PrivacyMetadata
    timestamp: datetime
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "session_id": self.session_id,
            "answer": self.answer,
            "confidence": self.confidence,
            "reasoning": self.reasoning,
            "proof_type": self.proof_type.value,
            "claim": self.claim,
            "privacy_metadata": {
                "filter_mode": self.privacy_metadata.filter_mode.value,
                "original_hash": self.privacy_metadata.original_hash,
                "filtered_hash": self.privacy_metadata.filtered_hash,
                "fields_included": self.privacy_metadata.fields_included,
                "fields_masked": self.privacy_metadata.fields_masked,
                "timestamp": self.privacy_metadata.timestamp.isoformat(),
            },
            "timestamp": self.timestamp.isoformat(),
        }


@dataclass
class AttestationBundle:
    """Cryptographic attestation bundle."""
    session_id: str
    document_hash: str
    claim: str
    result: VerificationResult
    proof_type: ProofType
    bundle_hash: str
    created_at: datetime
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "session_id": self.session_id,
            "document_hash": self.document_hash,
            "claim": self.claim,
            "result": self.result.to_dict(),
            "proof_type": self.proof_type.value,
            "bundle_hash": self.bundle_hash,
            "created_at": self.created_at.isoformat(),
        }
    
    def verify_integrity(self) -> bool:
        """Verify bundle integrity via hash."""
        import hashlib
        import json
        
        bundle_data = {
            "session_id": self.session_id,
            "document_hash": self.document_hash,
            "claim": self.claim,
            "result": self.result.to_dict(),
            "proof_type": self.proof_type.value,
        }
        
        computed_hash = hashlib.sha256(
            json.dumps(bundle_data, sort_keys=True).encode()
        ).hexdigest()
        
        return computed_hash == self.bundle_hash


@dataclass
class AuditEntry:
    """Entry in the audit log."""
    session_id: str
    document_hash: str
    claim: str
    answer: bool
    confidence: float
    proof_type: ProofType
    timestamp: datetime
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "session_id": self.session_id,
            "document_hash": self.document_hash,
            "claim": self.claim,
            "answer": self.answer,
            "confidence": self.confidence,
            "proof_type": self.proof_type.value,
            "timestamp": self.timestamp.isoformat(),
        }


@dataclass
class DocumentInfo:
    """Information about a parsed document."""
    document_type: str
    size_bytes: int
    hash: str
    fields_count: int
    parsed_at: datetime
