"""
ETH.id Python Client

Main client for interacting with ETH.id CLI.
"""

import subprocess
import json
import os
from pathlib import Path
from typing import Optional, Dict, Any, List
from datetime import datetime

from .types import (
    VerificationResult,
    AttestationBundle,
    AuditEntry,
    FilterMode,
    LLMProvider,
    ProofType,
    PrivacyMetadata,
    DocumentInfo,
)
from .exceptions import (
    EthIdError,
    DocumentParsingError,
    ClaimParsingError,
    VerificationError,
    AttestationError,
    ConfigurationError,
)


class EthIdClient:
    """
    ETH.id Python Client
    
    Zero-knowledge document verification client.
    
    Example:
        >>> client = EthIdClient()
        >>> result = client.verify(
        ...     document_path="passport.pdf",
        ...     claim="over 18 years old"
        ... )
        >>> print(f"Answer: {result.answer}")
    """
    
    def __init__(
        self,
        cli_path: Optional[str] = None,
        provider: Optional[LLMProvider] = None,
        api_key: Optional[str] = None,
        offline: bool = False,
        debug: bool = False,
    ):
        """
        Initialize ETH.id client.
        
        Args:
            cli_path: Path to eth CLI binary (auto-detected if None)
            provider: LLM provider to use
            api_key: API key for the provider
            offline: Use offline mode (requires Ollama)
            debug: Enable debug mode
        """
        self.cli_path = cli_path or self._find_cli()
        self.provider = provider
        self.offline = offline
        self.debug = debug
        
        if api_key:
            self._set_api_key(provider, api_key)
    
    def _find_cli(self) -> str:
        """Find eth CLI binary."""
        # Check common locations
        locations = [
            "eth",  # In PATH
            "/usr/local/bin/eth",
            str(Path.home() / ".cargo" / "bin" / "eth"),
            "./target/release/eth",
        ]
        
        for location in locations:
            try:
                result = subprocess.run(
                    [location, "--version"],
                    capture_output=True,
                    text=True,
                    timeout=5,
                )
                if result.returncode == 0:
                    return location
            except (FileNotFoundError, subprocess.TimeoutExpired):
                continue
        
        raise ConfigurationError(
            "ETH.id CLI not found. Install with: cargo install --path ."
        )
    
    def _set_api_key(self, provider: Optional[LLMProvider], api_key: str):
        """Set API key for provider."""
        if not provider:
            return
        
        env_var = {
            LLMProvider.OPENAI: "OPENAI_API_KEY",
            LLMProvider.CLAUDE: "ANTHROPIC_API_KEY",
        }.get(provider)
        
        if env_var:
            os.environ[env_var] = api_key
    
    def _run_command(self, args: List[str]) -> Dict[str, Any]:
        """Run eth CLI command."""
        cmd = [self.cli_path] + args
        
        if self.debug:
            cmd.append("--debug")
        
        if self.offline:
            cmd.append("--offline")
        
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=60,
            )
            
            if result.returncode != 0:
                raise EthIdError(f"CLI error: {result.stderr}")
            
            # Try to parse JSON output
            try:
                return json.loads(result.stdout)
            except json.JSONDecodeError:
                # Return raw output if not JSON
                return {"output": result.stdout}
        
        except subprocess.TimeoutExpired:
            raise EthIdError("Command timeout")
        except FileNotFoundError:
            raise ConfigurationError(f"CLI not found at: {self.cli_path}")
    
    def verify(
        self,
        document_path: str,
        claim: str,
        provider: Optional[LLMProvider] = None,
        attest: bool = False,
        zk_only: bool = False,
    ) -> VerificationResult:
        """
        Verify a claim about a document.
        
        Args:
            document_path: Path to document file
            claim: Claim to verify (natural language)
            provider: LLM provider (overrides default)
            attest: Generate attestation bundle
            zk_only: Use only zero-knowledge proofs
        
        Returns:
            VerificationResult with answer and metadata
        
        Raises:
            DocumentParsingError: If document cannot be parsed
            ClaimParsingError: If claim cannot be parsed
            VerificationError: If verification fails
        
        Example:
            >>> result = client.verify(
            ...     document_path="id.pdf",
            ...     claim="maior de 18 anos"
            ... )
            >>> print(f"Answer: {result.answer}")
            >>> print(f"Confidence: {result.confidence}%")
        """
        if not Path(document_path).exists():
            raise DocumentParsingError(f"Document not found: {document_path}")
        
        args = [
            "verify",
            "--doc", document_path,
            "--claim", claim,
            "--output", "json",
        ]
        
        if provider:
            args.extend(["--provider", provider.value])
        elif self.provider:
            args.extend(["--provider", self.provider.value])
        
        if attest:
            args.append("--attest")
        
        if zk_only:
            args.append("--zk-only")
        
        try:
            output = self._run_command(args)
            return self._parse_verification_result(output)
        except EthIdError:
            raise
        except Exception as e:
            raise VerificationError(f"Verification failed: {e}")
    
    def _parse_verification_result(self, data: Dict[str, Any]) -> VerificationResult:
        """Parse verification result from CLI output."""
        try:
            privacy_meta = PrivacyMetadata(
                filter_mode=FilterMode(data["privacy_metadata"]["filter_mode"]),
                original_hash=data["privacy_metadata"]["original_hash"],
                filtered_hash=data["privacy_metadata"]["filtered_hash"],
                fields_included=data["privacy_metadata"].get("fields_included", []),
                fields_masked=data["privacy_metadata"].get("fields_masked", []),
                timestamp=datetime.fromisoformat(data["privacy_metadata"]["timestamp"]),
            )
            
            return VerificationResult(
                session_id=data["session_id"],
                answer=data["answer"],
                confidence=data["confidence"],
                reasoning=data["reasoning"],
                proof_type=ProofType(data["proof_type"]),
                claim=data["claim"],
                privacy_metadata=privacy_meta,
                timestamp=datetime.fromisoformat(data["timestamp"]),
            )
        except (KeyError, ValueError) as e:
            raise VerificationError(f"Failed to parse result: {e}")
    
    def get_attestation(self, session_id: str) -> AttestationBundle:
        """
        Get attestation bundle for a verification session.
        
        Args:
            session_id: Session ID from verification
        
        Returns:
            AttestationBundle with cryptographic proof
        
        Raises:
            AttestationError: If attestation not found or invalid
        
        Example:
            >>> bundle = client.get_attestation(result.session_id)
            >>> print(f"Valid: {bundle.verify_integrity()}")
        """
        args = ["attest", "--session", session_id, "--output", "json"]
        
        try:
            output = self._run_command(args)
            return self._parse_attestation(output)
        except EthIdError:
            raise
        except Exception as e:
            raise AttestationError(f"Failed to get attestation: {e}")
    
    def _parse_attestation(self, data: Dict[str, Any]) -> AttestationBundle:
        """Parse attestation bundle."""
        try:
            result = self._parse_verification_result(data["result"])
            
            return AttestationBundle(
                session_id=data["session_id"],
                document_hash=data["document_hash"],
                claim=data["claim"],
                result=result,
                proof_type=ProofType(data["proof_type"]),
                bundle_hash=data["bundle_hash"],
                created_at=datetime.fromisoformat(data["created_at"]),
            )
        except (KeyError, ValueError) as e:
            raise AttestationError(f"Failed to parse attestation: {e}")
    
    def list_audit_log(
        self,
        limit: Optional[int] = None,
        filter_claim: Optional[str] = None,
    ) -> List[AuditEntry]:
        """
        List audit log entries.
        
        Args:
            limit: Maximum number of entries to return
            filter_claim: Filter by claim text
        
        Returns:
            List of AuditEntry objects
        
        Example:
            >>> entries = client.list_audit_log(limit=10)
            >>> for entry in entries:
            ...     print(f"{entry.timestamp}: {entry.claim} -> {entry.answer}")
        """
        args = ["audit", "--list", "--output", "json"]
        
        if limit:
            args.extend(["--limit", str(limit)])
        
        try:
            output = self._run_command(args)
            entries = [self._parse_audit_entry(e) for e in output.get("entries", [])]
            
            if filter_claim:
                entries = [e for e in entries if filter_claim.lower() in e.claim.lower()]
            
            return entries
        except Exception as e:
            raise EthIdError(f"Failed to list audit log: {e}")
    
    def _parse_audit_entry(self, data: Dict[str, Any]) -> AuditEntry:
        """Parse audit entry."""
        return AuditEntry(
            session_id=data["session_id"],
            document_hash=data["document_hash"],
            claim=data["claim"],
            answer=data["answer"],
            confidence=data["confidence"],
            proof_type=ProofType(data["proof_type"]),
            timestamp=datetime.fromisoformat(data["timestamp"]),
        )
    
    def get_audit_entry(self, session_id: str) -> AuditEntry:
        """
        Get specific audit entry.
        
        Args:
            session_id: Session ID to retrieve
        
        Returns:
            AuditEntry object
        """
        args = ["audit", "--show", session_id, "--output", "json"]
        
        try:
            output = self._run_command(args)
            return self._parse_audit_entry(output)
        except Exception as e:
            raise EthIdError(f"Failed to get audit entry: {e}")
    
    def configure(
        self,
        provider: Optional[LLMProvider] = None,
        api_key: Optional[str] = None,
    ):
        """
        Configure ETH.id settings.
        
        Args:
            provider: Default LLM provider
            api_key: API key for provider
        
        Example:
            >>> client.configure(
            ...     provider=LLMProvider.CLAUDE,
            ...     api_key="sk-ant-..."
            ... )
        """
        if provider:
            args = ["config", "--provider", provider.value]
            self._run_command(args)
            self.provider = provider
        
        if api_key and provider:
            self._set_api_key(provider, api_key)
    
    def get_config(self) -> Dict[str, Any]:
        """
        Get current configuration.
        
        Returns:
            Configuration dictionary
        """
        args = ["config", "--show", "--output", "json"]
        return self._run_command(args)
