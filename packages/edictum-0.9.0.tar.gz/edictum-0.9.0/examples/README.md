# Edictum Examples

See the main README for the full demo overview, scorecard, and metrics:
`README.md`

Note: The system prompt in `examples/tools.py` intentionally encourages destructive behavior for demo purposes. Do not reuse it in production.

Quick start:

```bash
cd examples/
bash setup.sh
python demo_langchain.py
bash setup.sh
python demo_langchain.py --guard
```
