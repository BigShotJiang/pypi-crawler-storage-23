"""Audit sinks for Edictum. Enterprise HTTP sinks removed in v0.5.0 — use OpenTelemetry."""
