"""Behavior tests — verify documented API behavior for every public parameter."""
