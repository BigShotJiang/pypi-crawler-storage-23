"""Compatibility utilities for cross-version support."""
