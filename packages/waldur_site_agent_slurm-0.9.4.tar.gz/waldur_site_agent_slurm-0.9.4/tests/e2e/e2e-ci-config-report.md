
# E2E API Optimization Test Report

**Date:** 2026-03-02T14:01:14.475968+00:00
**Config:** `ci/e2e-ci-config.yaml`
**Waldur:** http://docker:8080/api/
**Backend:** SLURM emulator
**Offering:** e2ef0000000000000000000000000001
**Components:** cpu (factor=60000.0), ram (factor=61440.0)


## Benchmark: CREATE order processing

API calls: **26**
Order state: `done`

## Benchmark: UPDATE order processing

API calls: **10**
Order state: `done`

## Benchmark: TERMINATE order processing

API calls: **10**
Order state: `done`

## Benchmark: Membership sync

API calls: **10**

## Benchmark: Usage reporting

API calls: **13**

## Multi-resource benchmark: setup (5 resources)

Submitted **5** orders in 0.9s
Processed in **1** cycles, 27.0s
Created **5** / 5 resources successfully.

## Multi-resource benchmark: membership sync (5 resources)

Resources: **5**
API calls: **28** (per resource: 5.6)
Response bytes: **9431** (per resource: 1886)
Duration: **20.2s**

## Multi-resource benchmark: reporting (5 resources)

Resources: **5**
API calls: **33** (per resource: 6.6)
Response bytes: **58476** (per resource: 11695)
Duration: **7.1s**

## Multi-resource benchmark: cleanup

Terminated **5** / 5 resources.

## API Call Summary

| Test | API Calls | Response Size |
|------|-----------|---------------|
| TestBenchmarkOrderProcessing::test_01_create | 30 | 68.2 KB |
| TestBenchmarkOrderProcessing::test_02_update | 11 | 24.9 KB |
| TestBenchmarkOrderProcessing::test_03_terminate | 11 | 23.6 KB |
| TestBenchmarkMembershipSync::test_01_sync | 13 | 12.8 KB |
| TestBenchmarkReporting::test_01_setup_resource | 25 | 50.3 KB |
| TestBenchmarkReporting::test_02_report | 16 | 28.8 KB |
| TestMultiResourceBenchmark::test_01_create_resources | 93 | 188.5 KB |
| TestMultiResourceBenchmark::test_02_membership_sync | 31 | 15.2 KB |
| TestMultiResourceBenchmark::test_03_reporting | 36 | 63.1 KB |
| TestMultiResourceBenchmark::test_04_cleanup | 35 | 80.5 KB |
| **TOTAL** | **301** | **556.1 KB** |
