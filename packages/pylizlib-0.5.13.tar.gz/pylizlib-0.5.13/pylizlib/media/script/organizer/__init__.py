"""
Organizer script package.

This package contains the logic for scanning, filtering, and organizing media files
into a structured directory hierarchy.
"""
