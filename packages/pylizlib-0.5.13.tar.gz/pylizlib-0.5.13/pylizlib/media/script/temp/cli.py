from pylizlib.media import pyliz_media


@pyliz_media.command()
def temp():
    """
    Template command for media_app.
    """
    print("This is a temporary command in media_app.")