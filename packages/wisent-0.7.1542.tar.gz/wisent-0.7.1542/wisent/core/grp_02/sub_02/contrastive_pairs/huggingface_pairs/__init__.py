import os as _os
_base = _os.path.dirname(__file__)
for _root, _dirs, _files in _os.walk(_base):
    if _root != _base:
        __path__.append(_root)

"""HuggingFace dataset extractors for benchmarks not in lm-eval-harness."""
