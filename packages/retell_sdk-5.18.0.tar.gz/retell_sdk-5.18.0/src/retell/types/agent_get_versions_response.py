# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List
from typing_extensions import TypeAlias

from .agent_response import AgentResponse

__all__ = ["AgentGetVersionsResponse"]

AgentGetVersionsResponse: TypeAlias = List[AgentResponse]
