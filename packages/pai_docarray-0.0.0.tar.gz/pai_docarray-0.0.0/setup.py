"""
Empty setup.py for pai-docarray
"""
from setuptools import setup

setup(
    name="pai-docarray",
    version="0.0.0",
    description="Empty placeholder package - reserved name",
    author="Package Protector",
    author_email="protector@example.com",
    py_modules=[],
)
