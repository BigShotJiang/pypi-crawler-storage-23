# imgen_toolbox
Repository containing building blocks and utilities for flexible Generative Neural Networks implementation
