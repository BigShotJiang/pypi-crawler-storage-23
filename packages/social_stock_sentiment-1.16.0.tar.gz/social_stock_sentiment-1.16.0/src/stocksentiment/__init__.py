"""Stock Sentiment API — Python SDK"""

__version__ = "1.16.0"

from ._wrapper import StockSentimentClient

__all__ = ["StockSentimentClient", "__version__"]
