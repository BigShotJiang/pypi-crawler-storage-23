from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.polymarket_compare_stock_item import PolymarketCompareStockItem


T = TypeVar("T", bound="PolymarketCompareResponse")


@_attrs_define
class PolymarketCompareResponse:
    """Response for compare endpoint.

    Attributes:
        period_days (int): Analysis period in days
        stocks (list[PolymarketCompareStockItem]): Stocks sorted by buzz_score descending
    """

    period_days: int
    stocks: list[PolymarketCompareStockItem]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        period_days = self.period_days

        stocks = []
        for stocks_item_data in self.stocks:
            stocks_item = stocks_item_data.to_dict()
            stocks.append(stocks_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "period_days": period_days,
                "stocks": stocks,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.polymarket_compare_stock_item import PolymarketCompareStockItem

        d = dict(src_dict)
        period_days = d.pop("period_days")

        stocks = []
        _stocks = d.pop("stocks")
        for stocks_item_data in _stocks:
            stocks_item = PolymarketCompareStockItem.from_dict(stocks_item_data)

            stocks.append(stocks_item)

        polymarket_compare_response = cls(
            period_days=period_days,
            stocks=stocks,
        )

        polymarket_compare_response.additional_properties = d
        return polymarket_compare_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
