from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.polymarket_trending_sector_trend import PolymarketTrendingSectorTrend
from ..types import UNSET, Unset

T = TypeVar("T", bound="PolymarketTrendingSector")


@_attrs_define
class PolymarketTrendingSector:
    """Trending sector on Polymarket.

    Attributes:
        buzz_score (float): Aggregated buzz score
        trend (PolymarketTrendingSectorTrend): Aggregated 24h trend
        mentions (int): Total mentions in period
        unique_tickers (int): Unique tickers in dimension
        bullish_pct (int): Bullish market share
        bearish_pct (int): Bearish market share
        total_upvotes (int): Compatibility alias: round(volume_24h)
        total_liquidity (float): Total liquidity (USD)
        volume_24h (float): Total 24h volume (USD)
        top_tickers (list[str]): Top 5 tickers by mentions
        sector (str): Sector name
        sentiment_score (float | None | Unset): Weighted implied sentiment
    """

    buzz_score: float
    trend: PolymarketTrendingSectorTrend
    mentions: int
    unique_tickers: int
    bullish_pct: int
    bearish_pct: int
    total_upvotes: int
    total_liquidity: float
    volume_24h: float
    top_tickers: list[str]
    sector: str
    sentiment_score: float | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        buzz_score = self.buzz_score

        trend = self.trend.value

        mentions = self.mentions

        unique_tickers = self.unique_tickers

        bullish_pct = self.bullish_pct

        bearish_pct = self.bearish_pct

        total_upvotes = self.total_upvotes

        total_liquidity = self.total_liquidity

        volume_24h = self.volume_24h

        top_tickers = self.top_tickers

        sector = self.sector

        sentiment_score: float | None | Unset
        if isinstance(self.sentiment_score, Unset):
            sentiment_score = UNSET
        else:
            sentiment_score = self.sentiment_score

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "buzz_score": buzz_score,
                "trend": trend,
                "mentions": mentions,
                "unique_tickers": unique_tickers,
                "bullish_pct": bullish_pct,
                "bearish_pct": bearish_pct,
                "total_upvotes": total_upvotes,
                "total_liquidity": total_liquidity,
                "volume_24h": volume_24h,
                "top_tickers": top_tickers,
                "sector": sector,
            }
        )
        if sentiment_score is not UNSET:
            field_dict["sentiment_score"] = sentiment_score

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        buzz_score = d.pop("buzz_score")

        trend = PolymarketTrendingSectorTrend(d.pop("trend"))

        mentions = d.pop("mentions")

        unique_tickers = d.pop("unique_tickers")

        bullish_pct = d.pop("bullish_pct")

        bearish_pct = d.pop("bearish_pct")

        total_upvotes = d.pop("total_upvotes")

        total_liquidity = d.pop("total_liquidity")

        volume_24h = d.pop("volume_24h")

        top_tickers = cast(list[str], d.pop("top_tickers"))

        sector = d.pop("sector")

        def _parse_sentiment_score(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        sentiment_score = _parse_sentiment_score(d.pop("sentiment_score", UNSET))

        polymarket_trending_sector = cls(
            buzz_score=buzz_score,
            trend=trend,
            mentions=mentions,
            unique_tickers=unique_tickers,
            bullish_pct=bullish_pct,
            bearish_pct=bearish_pct,
            total_upvotes=total_upvotes,
            total_liquidity=total_liquidity,
            volume_24h=volume_24h,
            top_tickers=top_tickers,
            sector=sector,
            sentiment_score=sentiment_score,
        )

        polymarket_trending_sector.additional_properties = d
        return polymarket_trending_sector

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
