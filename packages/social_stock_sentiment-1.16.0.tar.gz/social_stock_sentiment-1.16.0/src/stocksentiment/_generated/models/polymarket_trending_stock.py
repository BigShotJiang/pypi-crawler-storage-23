from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.polymarket_trending_stock_trend import PolymarketTrendingStockTrend
from ..types import UNSET, Unset

T = TypeVar("T", bound="PolymarketTrendingStock")


@_attrs_define
class PolymarketTrendingStock:
    """Trending stock from Polymarket in Reddit/X-compatible shape.

    Attributes:
        ticker (str): Stock ticker symbol
        buzz_score (float): Buzz score (0-100)
        trend (PolymarketTrendingStockTrend): 24h activity trend
        mentions (int): Mention count (market coverage)
        bullish_pct (int): Share of markets with YES > 0.5
        bearish_pct (int): Share of markets with YES < 0.5
        total_upvotes (int): Compatibility alias: round(volume_24h)
        total_liquidity (float): Total liquidity (USD)
        volume_24h (float): Total 24h volume (USD)
        company_name (None | str | Unset): Company name from ticker_reference
        sentiment_score (float | None | Unset): Implied sentiment (-1 to +1)
        trend_history (list[float] | Unset): Daily buzz scores (oldest→newest), length max(days, 7)
    """

    ticker: str
    buzz_score: float
    trend: PolymarketTrendingStockTrend
    mentions: int
    bullish_pct: int
    bearish_pct: int
    total_upvotes: int
    total_liquidity: float
    volume_24h: float
    company_name: None | str | Unset = UNSET
    sentiment_score: float | None | Unset = UNSET
    trend_history: list[float] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        ticker = self.ticker

        buzz_score = self.buzz_score

        trend = self.trend.value

        mentions = self.mentions

        bullish_pct = self.bullish_pct

        bearish_pct = self.bearish_pct

        total_upvotes = self.total_upvotes

        total_liquidity = self.total_liquidity

        volume_24h = self.volume_24h

        company_name: None | str | Unset
        if isinstance(self.company_name, Unset):
            company_name = UNSET
        else:
            company_name = self.company_name

        sentiment_score: float | None | Unset
        if isinstance(self.sentiment_score, Unset):
            sentiment_score = UNSET
        else:
            sentiment_score = self.sentiment_score

        trend_history: list[float] | Unset = UNSET
        if not isinstance(self.trend_history, Unset):
            trend_history = self.trend_history

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "ticker": ticker,
                "buzz_score": buzz_score,
                "trend": trend,
                "mentions": mentions,
                "bullish_pct": bullish_pct,
                "bearish_pct": bearish_pct,
                "total_upvotes": total_upvotes,
                "total_liquidity": total_liquidity,
                "volume_24h": volume_24h,
            }
        )
        if company_name is not UNSET:
            field_dict["company_name"] = company_name
        if sentiment_score is not UNSET:
            field_dict["sentiment_score"] = sentiment_score
        if trend_history is not UNSET:
            field_dict["trend_history"] = trend_history

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        ticker = d.pop("ticker")

        buzz_score = d.pop("buzz_score")

        trend = PolymarketTrendingStockTrend(d.pop("trend"))

        mentions = d.pop("mentions")

        bullish_pct = d.pop("bullish_pct")

        bearish_pct = d.pop("bearish_pct")

        total_upvotes = d.pop("total_upvotes")

        total_liquidity = d.pop("total_liquidity")

        volume_24h = d.pop("volume_24h")

        def _parse_company_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        company_name = _parse_company_name(d.pop("company_name", UNSET))

        def _parse_sentiment_score(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        sentiment_score = _parse_sentiment_score(d.pop("sentiment_score", UNSET))

        trend_history = cast(list[float], d.pop("trend_history", UNSET))

        polymarket_trending_stock = cls(
            ticker=ticker,
            buzz_score=buzz_score,
            trend=trend,
            mentions=mentions,
            bullish_pct=bullish_pct,
            bearish_pct=bearish_pct,
            total_upvotes=total_upvotes,
            total_liquidity=total_liquidity,
            volume_24h=volume_24h,
            company_name=company_name,
            sentiment_score=sentiment_score,
            trend_history=trend_history,
        )

        polymarket_trending_stock.additional_properties = d
        return polymarket_trending_stock

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
