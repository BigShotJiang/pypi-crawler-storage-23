"""Tests for the StockSentimentClient wrapper."""

import pytest
import httpx
import respx

from stocksentiment import StockSentimentClient
from stocksentiment._generated.errors import UnexpectedStatus

BASE_URL = "https://api.adanos.org"
API_KEY = "sk_live_test1234567890abcdef1234567890ab"


def request_params(route) -> dict:
    """Extract query params from the last call on a respx route."""
    return dict(route.calls[0].request.url.params)


# --- Mock data matching generated model required fields ---

TRENDING_STOCK = {
    "ticker": "TSLA", "buzz_score": 85.0, "trend": "rising",
    "mentions": 120, "unique_posts": 80, "subreddit_count": 5,
    "sentiment_score": 0.6, "bullish_pct": 65, "bearish_pct": 15,
    "total_upvotes": 5000,
}

STOCK_SENTIMENT = {
    "ticker": "TSLA", "found": True,
}

SEARCH_RESPONSE = {
    "query": "Tesla", "count": 1, "results": [
        {"ticker": "TSLA", "name": "Tesla Inc"},
    ],
}

COMPARE_RESPONSE = {
    "period_days": 7, "stocks": [],
}

EXPLAIN_RESPONSE = {
    "ticker": "TSLA", "explanation": "Tesla is trending due to...",
    "cached": False, "generated_at": "2026-02-16T10:00:00Z",
    "model": "llama3.1:8b",
}

X_TRENDING_STOCK = {
    "ticker": "NVDA", "buzz_score": 90.0, "trend": "rising", "mentions": 200,
}

X_STOCK_DETAIL = {
    "ticker": "NVDA",
}

POLYMARKET_TRENDING_STOCK = {
    "ticker": "AAPL",
    "buzz_score": 71.4,
    "trend": "rising",
    "mentions": 8,
    "bullish_pct": 67,
    "bearish_pct": 33,
    "total_upvotes": 23660,
    "total_liquidity": 94750.0,
    "volume_24h": 23660.0,
}

POLYMARKET_STOCK_DETAIL = {
    "ticker": "AAPL",
    "found": True,
}

POLYMARKET_COMPARE_RESPONSE = {
    "period_days": 7,
    "stocks": [{
        "ticker": "AAPL",
        "buzz_score": 71.4,
        "mentions": 8,
        "upvotes": 23660,
        "total_liquidity": 94750.0,
        "volume_24h": 23660.0,
    }],
}

TRENDING_SECTOR = {
    "sector": "Technology", "buzz_score": 75.0, "trend": "rising",
    "mentions": 500, "unique_tickers": 20, "subreddit_count": 8,
    "sentiment_score": 0.5, "bullish_pct": 60, "bearish_pct": 20,
    "total_upvotes": 15000, "top_tickers": ["TSLA", "AAPL", "NVDA"],
}

TRENDING_COUNTRY = {
    "country": "United States", "buzz_score": 80.0, "trend": "stable",
    "mentions": 800, "unique_tickers": 30, "subreddit_count": 10,
    "sentiment_score": 0.4, "bullish_pct": 55, "bearish_pct": 25,
    "total_upvotes": 20000, "top_tickers": ["TSLA", "AAPL"],
}

# --- Fixtures ---

@pytest.fixture
def client():
    c = StockSentimentClient(api_key=API_KEY, base_url=BASE_URL)
    yield c
    c.close()


# --- Auth header ---

class TestAuth:
    @respx.mock
    def test_api_key_header_sent(self, client):
        route = respx.get(f"{BASE_URL}/reddit/stocks/v1/trending").mock(
            return_value=httpx.Response(200, json=[])
        )
        client.reddit.trending()
        assert route.called
        request = route.calls[0].request
        assert request.headers["X-API-Key"] == API_KEY

    def test_custom_base_url(self):
        c = StockSentimentClient(api_key=API_KEY, base_url="https://custom.example.com")
        assert c._client._base_url == "https://custom.example.com"


# --- Reddit namespace ---

class TestRedditTrending:
    @respx.mock
    def test_trending_default_params(self, client):
        route = respx.get(f"{BASE_URL}/reddit/stocks/v1/trending").mock(
            return_value=httpx.Response(200, json=[TRENDING_STOCK])
        )
        result = client.reddit.trending()
        assert route.called
        assert len(result) == 1
        assert result[0].ticker == "TSLA"
        assert result[0].buzz_score == 85.0

    @respx.mock
    def test_trending_with_params(self, client):
        route = respx.get(f"{BASE_URL}/reddit/stocks/v1/trending").mock(
            return_value=httpx.Response(200, json=[])
        )
        client.reddit.trending(days=7, limit=5, offset=10, type="etf")
        request = route.calls[0].request
        assert request.url.params["days"] == "7"
        assert request.url.params["limit"] == "5"
        assert request.url.params["offset"] == "10"
        assert request.url.params["type"] == "etf"

    @respx.mock
    def test_trending_empty(self, client):
        respx.get(f"{BASE_URL}/reddit/stocks/v1/trending").mock(
            return_value=httpx.Response(200, json=[])
        )
        result = client.reddit.trending()
        assert result == []


class TestRedditStock:
    @respx.mock
    def test_stock_detail(self, client):
        route = respx.get(f"{BASE_URL}/reddit/stocks/v1/stock/TSLA").mock(
            return_value=httpx.Response(200, json=STOCK_SENTIMENT)
        )
        result = client.reddit.stock("TSLA")
        assert route.called
        assert result.ticker == "TSLA"
        assert result.found is True

    @respx.mock
    def test_stock_with_days(self, client):
        route = respx.get(f"{BASE_URL}/reddit/stocks/v1/stock/AAPL").mock(
            return_value=httpx.Response(200, json={**STOCK_SENTIMENT, "ticker": "AAPL"})
        )
        client.reddit.stock("AAPL", days=14)
        assert request_params(route)["days"] == "14"


class TestRedditExplain:
    @respx.mock
    def test_explain(self, client):
        route = respx.get(f"{BASE_URL}/reddit/stocks/v1/stock/TSLA/explain").mock(
            return_value=httpx.Response(200, json=EXPLAIN_RESPONSE)
        )
        result = client.reddit.explain("TSLA")
        assert route.called
        assert result.explanation == "Tesla is trending due to..."


class TestRedditSearch:
    @respx.mock
    def test_search(self, client):
        route = respx.get(f"{BASE_URL}/reddit/stocks/v1/search").mock(
            return_value=httpx.Response(200, json=SEARCH_RESPONSE)
        )
        result = client.reddit.search("Tesla")
        assert route.called
        assert request_params(route)["q"] == "Tesla"
        assert result.count == 1


class TestRedditCompare:
    @respx.mock
    def test_compare(self, client):
        route = respx.get(f"{BASE_URL}/reddit/stocks/v1/compare").mock(
            return_value=httpx.Response(200, json=COMPARE_RESPONSE)
        )
        client.reddit.compare(["TSLA", "AAPL"], days=7)
        assert route.called
        assert request_params(route)["tickers"] == "TSLA,AAPL"


class TestRedditTrendingSectors:
    @respx.mock
    def test_trending_sectors(self, client):
        route = respx.get(f"{BASE_URL}/reddit/stocks/v1/trending/sectors").mock(
            return_value=httpx.Response(200, json=[TRENDING_SECTOR])
        )
        result = client.reddit.trending_sectors(days=7)
        assert route.called
        assert len(result) == 1
        assert result[0].sector == "Technology"

    @respx.mock
    def test_trending_sectors_params(self, client):
        route = respx.get(f"{BASE_URL}/reddit/stocks/v1/trending/sectors").mock(
            return_value=httpx.Response(200, json=[])
        )
        client.reddit.trending_sectors(days=3, limit=5, offset=2)
        params = request_params(route)
        assert params["days"] == "3"
        assert params["limit"] == "5"
        assert params["offset"] == "2"


class TestRedditTrendingCountries:
    @respx.mock
    def test_trending_countries(self, client):
        route = respx.get(f"{BASE_URL}/reddit/stocks/v1/trending/countries").mock(
            return_value=httpx.Response(200, json=[TRENDING_COUNTRY])
        )
        result = client.reddit.trending_countries()
        assert route.called
        assert result[0].country == "United States"


# --- Async methods ---

class TestAsync:
    @respx.mock
    @pytest.mark.asyncio
    async def test_reddit_trending_async(self):
        route = respx.get(f"{BASE_URL}/reddit/stocks/v1/trending").mock(
            return_value=httpx.Response(200, json=[TRENDING_STOCK])
        )
        async with StockSentimentClient(api_key=API_KEY, base_url=BASE_URL) as client:
            result = await client.reddit.trending_async(days=7)
        assert route.called
        assert len(result) == 1
        assert result[0].ticker == "TSLA"

    @respx.mock
    @pytest.mark.asyncio
    async def test_reddit_stock_async(self):
        respx.get(f"{BASE_URL}/reddit/stocks/v1/stock/TSLA").mock(
            return_value=httpx.Response(200, json=STOCK_SENTIMENT)
        )
        async with StockSentimentClient(api_key=API_KEY, base_url=BASE_URL) as client:
            result = await client.reddit.stock_async("TSLA")
        assert result.ticker == "TSLA"

    @respx.mock
    @pytest.mark.asyncio
    async def test_x_trending_async(self):
        route = respx.get(f"{BASE_URL}/x/stocks/v1/trending").mock(
            return_value=httpx.Response(200, json=[X_TRENDING_STOCK])
        )
        async with StockSentimentClient(api_key=API_KEY, base_url=BASE_URL) as client:
            result = await client.x.trending_async()
        assert route.called
        assert result[0].ticker == "NVDA"

    @respx.mock
    @pytest.mark.asyncio
    async def test_reddit_search_async(self):
        respx.get(f"{BASE_URL}/reddit/stocks/v1/search").mock(
            return_value=httpx.Response(200, json=SEARCH_RESPONSE)
        )
        async with StockSentimentClient(api_key=API_KEY, base_url=BASE_URL) as client:
            result = await client.reddit.search_async("Tesla")
        assert result.count == 1

    @respx.mock
    @pytest.mark.asyncio
    async def test_polymarket_trending_async(self):
        route = respx.get(f"{BASE_URL}/polymarket/stocks/v1/trending").mock(
            return_value=httpx.Response(200, json=[POLYMARKET_TRENDING_STOCK])
        )
        async with StockSentimentClient(api_key=API_KEY, base_url=BASE_URL) as client:
            result = await client.polymarket.trending_async(days=7)
        assert route.called
        assert len(result) == 1
        assert result[0].ticker == "AAPL"

    @respx.mock
    @pytest.mark.asyncio
    async def test_reddit_compare_async(self):
        route = respx.get(f"{BASE_URL}/reddit/stocks/v1/compare").mock(
            return_value=httpx.Response(200, json=COMPARE_RESPONSE)
        )
        async with StockSentimentClient(api_key=API_KEY, base_url=BASE_URL) as client:
            await client.reddit.compare_async(["TSLA", "AAPL"])
        assert request_params(route)["tickers"] == "TSLA,AAPL"


# --- X namespace ---

class TestXTrending:
    @respx.mock
    def test_trending(self, client):
        route = respx.get(f"{BASE_URL}/x/stocks/v1/trending").mock(
            return_value=httpx.Response(200, json=[X_TRENDING_STOCK])
        )
        result = client.x.trending()
        assert route.called
        assert len(result) == 1
        assert result[0].ticker == "NVDA"

    @respx.mock
    def test_trending_with_type(self, client):
        route = respx.get(f"{BASE_URL}/x/stocks/v1/trending").mock(
            return_value=httpx.Response(200, json=[])
        )
        client.x.trending(type="stock")
        assert request_params(route)["type"] == "stock"


class TestXStock:
    @respx.mock
    def test_stock(self, client):
        route = respx.get(f"{BASE_URL}/x/stocks/v1/stock/NVDA").mock(
            return_value=httpx.Response(200, json=X_STOCK_DETAIL)
        )
        result = client.x.stock("NVDA")
        assert route.called
        assert result.ticker == "NVDA"


class TestXSearch:
    @respx.mock
    def test_search(self, client):
        route = respx.get(f"{BASE_URL}/x/stocks/v1/search").mock(
            return_value=httpx.Response(200, json={**SEARCH_RESPONSE, "query": "NVDA"})
        )
        client.x.search("NVDA")
        assert route.called


class TestXCompare:
    @respx.mock
    def test_compare(self, client):
        route = respx.get(f"{BASE_URL}/x/stocks/v1/compare").mock(
            return_value=httpx.Response(200, json=COMPARE_RESPONSE)
        )
        client.x.compare(["NVDA", "AMD"])
        assert route.called
        assert request_params(route)["tickers"] == "NVDA,AMD"


# --- Polymarket namespace ---

class TestPolymarketTrending:
    @respx.mock
    def test_trending(self, client):
        route = respx.get(f"{BASE_URL}/polymarket/stocks/v1/trending").mock(
            return_value=httpx.Response(200, json=[POLYMARKET_TRENDING_STOCK])
        )
        result = client.polymarket.trending()
        assert route.called
        assert len(result) == 1
        assert result[0].ticker == "AAPL"

    @respx.mock
    def test_trending_with_type(self, client):
        route = respx.get(f"{BASE_URL}/polymarket/stocks/v1/trending").mock(
            return_value=httpx.Response(200, json=[])
        )
        client.polymarket.trending(type="etf")
        assert request_params(route)["type"] == "etf"


class TestPolymarketStock:
    @respx.mock
    def test_stock(self, client):
        route = respx.get(f"{BASE_URL}/polymarket/stocks/v1/stock/AAPL").mock(
            return_value=httpx.Response(200, json=POLYMARKET_STOCK_DETAIL)
        )
        result = client.polymarket.stock("AAPL")
        assert route.called
        assert result.ticker == "AAPL"
        assert result.found is True


class TestPolymarketSearch:
    @respx.mock
    def test_search(self, client):
        route = respx.get(f"{BASE_URL}/polymarket/stocks/v1/search").mock(
            return_value=httpx.Response(200, json={**SEARCH_RESPONSE, "query": "AAPL"})
        )
        client.polymarket.search("AAPL")
        assert route.called


class TestPolymarketCompare:
    @respx.mock
    def test_compare(self, client):
        route = respx.get(f"{BASE_URL}/polymarket/stocks/v1/compare").mock(
            return_value=httpx.Response(200, json=POLYMARKET_COMPARE_RESPONSE)
        )
        client.polymarket.compare(["AAPL", "TSLA"])
        assert route.called
        assert request_params(route)["tickers"] == "AAPL,TSLA"


# --- Context manager ---

class TestContextManager:
    @respx.mock
    def test_sync_context_manager(self):
        route = respx.get(f"{BASE_URL}/reddit/stocks/v1/trending").mock(
            return_value=httpx.Response(200, json=[])
        )
        with StockSentimentClient(api_key=API_KEY, base_url=BASE_URL) as client:
            client.reddit.trending()
        assert route.called


# --- Error handling ---

class TestErrors:
    @respx.mock
    def test_undocumented_status_raises(self, client):
        """raise_on_unexpected_status=True should raise for undocumented codes."""
        respx.get(f"{BASE_URL}/reddit/stocks/v1/trending").mock(
            return_value=httpx.Response(500, content=b"Internal Server Error")
        )
        with pytest.raises(UnexpectedStatus):
            client.reddit.trending()

    @respx.mock
    def test_401_returns_error_response(self, client):
        """401 is a documented status — returns ErrorResponse, not exception."""
        respx.get(f"{BASE_URL}/reddit/stocks/v1/trending").mock(
            return_value=httpx.Response(401, json={"detail": "Invalid API key"})
        )
        result = client.reddit.trending()
        assert result.detail == "Invalid API key"

    @respx.mock
    def test_429_returns_error_response(self, client):
        """429 is a documented status — returns ErrorResponse."""
        respx.get(f"{BASE_URL}/reddit/stocks/v1/trending").mock(
            return_value=httpx.Response(429, json={"detail": "Rate limit exceeded"})
        )
        result = client.reddit.trending()
        assert result.detail == "Rate limit exceeded"
