---
name: Feature Request
about: Suggest a new feature for PactKit
title: "[FEATURE] "
labels: enhancement
---

## Problem

What problem does this feature solve?

## Proposed Solution

How should it work?

## Alternatives Considered

Any other approaches you've considered.
