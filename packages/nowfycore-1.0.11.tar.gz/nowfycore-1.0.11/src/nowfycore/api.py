from .language import (
    get_plugin_lang_code as _get_plugin_lang_code,
    get_plugin_lang_index as _get_plugin_lang_index,
    normalize_plugin_lang_index as _normalize_plugin_lang_index,
)
from .state import CoreState
from .services import get_bio_feature_services as _get_bio_feature_services
from .flags import is_addon_enabled as _is_addon_enabled, is_theme_enabled as _is_theme_enabled
from .bridge import invoke_action as _invoke_action
from .corekeys import (
    export_core_settings_from_plugin as _export_core_settings_from_plugin,
    import_core_settings_to_plugin as _import_core_settings_to_plugin,
)
from .trackhub import build_track_hub_subfragment_items as _build_track_hub_subfragment_items
from .themes import inject_core_theme_multiselect as _inject_core_theme_multiselect
from .panel import (
    on_panel_drawer_toggle as _on_panel_drawer_toggle,
    on_panel_disable_logs_toggle as _on_panel_disable_logs_toggle,
    on_lab_nowplaying_pill_toggle as _on_lab_nowplaying_pill_toggle,
    on_lab_send_haptic_toggle as _on_lab_send_haptic_toggle,
)
from .cache import clear_cache_data as _clear_cache_data
from .about import (
    animate_opening_avatar as _animate_opening_avatar,
    inject_about_support_rich_header as _inject_about_support_rich_header,
)
from .injections import (
    inject_services_cards_custom as _inject_services_cards_custom,
    inject_home_services_entry_custom as _inject_home_services_entry_custom,
    inject_statsfm_profile_custom as _inject_statsfm_profile_custom,
)
from .ui_controls import (
    get_nowtab_control_style as _get_nowtab_control_style,
    apply_nowtab_control_modern_ui as _apply_nowtab_control_modern_ui,
    update_nowtab_control_modern_state as _update_nowtab_control_modern_state,
    inject_track_hub_source_slide as _inject_track_hub_source_slide,
    inject_nowtab_control_style_slide as _inject_nowtab_control_style_slide,
    inject_vinify_logo_position_radios as _inject_vinify_logo_position_radios,
    inject_vinify_cover_shape_slide as _inject_vinify_cover_shape_slide,
    inject_nowfy_pulse_style_slide as _inject_nowfy_pulse_style_slide,
    inject_custom_cover_selector as _inject_custom_cover_selector,
    on_custom_cover_select as _on_custom_cover_select,
    on_custom_cover_toggle as _on_custom_cover_toggle,
)
from .trackhub_ui import (
    render_track_hub_box_cell as _render_track_hub_box_cell,
    clear_track_hub_box_cell as _clear_track_hub_box_cell,
)
from .tab_actions import (
    send_tab_track_download as _send_tab_track_download,
    send_tab_music_preview as _send_tab_music_preview,
)
from .welcome import maybe_show_nowfy_welcome_sheet as _maybe_show_nowfy_welcome_sheet
from .legacy_bulk import bind_runtime_methods as _bind_runtime_methods


class NowfyCoreBackendMixin:
    """Compatibility mixin kept for migration safety."""

    pass


class NowfyCoreAPI:
    """Core facade consumed by nowfy.plugin."""

    def __init__(self):
        self._state = CoreState()
        self._runtime_plugin = None
        self._token_cache = {"value": None, "exp": 0}

    def register_runtime_plugin(self, plugin):
        self._runtime_plugin = plugin
        return True

    def is_core_active(self):
        return True

    def is_addon_enabled(self, plugin, addon_key, default_value=False):
        return _is_addon_enabled(plugin, addon_key, default_value)

    def are_translation_resources_ready(self):
        plugin = self._runtime_plugin
        if plugin is None:
            return True
        try:
            tr_fn = getattr(plugin, "tr", None)
            if not callable(tr_fn):
                return True
            probes = ("custom_command", "nowfy_panel_section_desc", "core_language_label")
            hits = 0
            for key in probes:
                try:
                    val = str(tr_fn(key) or "").strip()
                    if val and val != key:
                        hits += 1
                except Exception:
                    pass
            return hits >= 2
        except Exception:
            return True

    def ensure_translation_resources(self, silent=False):
        plugin = self._runtime_plugin
        if plugin is None:
            return True
        try:
            if self.are_translation_resources_ready():
                return True
            # Best-effort hook if host exposes manual sync action.
            sync_fn = getattr(plugin, "_run_sync_translations_action", None)
            if callable(sync_fn):
                try:
                    sync_fn()
                except Exception:
                    pass
            return self.are_translation_resources_ready()
        except Exception:
            return False

    def maybe_show_nowfy_welcome_sheet(self, plugin):
        return _maybe_show_nowfy_welcome_sheet(plugin)

    def bind_runtime_methods(self, plugin_cls, override=True):
        return _bind_runtime_methods(plugin_cls, override=override)

    def get_nowtab_control_style(self, plugin):
        return _get_nowtab_control_style(plugin)

    def apply_nowtab_control_modern_ui(self, plugin, context, controls_row, control_container, *args, **kwargs):
        return _apply_nowtab_control_modern_ui(plugin, context, controls_row, control_container, *args, **kwargs)

    def update_nowtab_control_modern_state(self, plugin, is_playing):
        return _update_nowtab_control_modern_state(plugin, is_playing)

    def send_tab_track_download(self, plugin):
        return _send_tab_track_download(plugin)

    def send_tab_music_preview(self, plugin):
        return _send_tab_music_preview(plugin)

    def get_track_hub_style(self, plugin):
        try:
            return int(plugin.get_setting("track_hub_style", 0) or 0)
        except Exception:
            return 0

    def render_track_hub_box_cell(self, plugin, cell, title_text, subtitle_text, cover_url=""):
        return _render_track_hub_box_cell(plugin, cell, title_text, subtitle_text, cover_url)

    def clear_track_hub_box_cell(self, plugin, cell):
        return _clear_track_hub_box_cell(plugin, cell)

    def inject_track_hub_source_slide(self, plugin, activity, items):
        return _inject_track_hub_source_slide(plugin, activity, items)

    def inject_nowtab_control_style_slide(self, plugin, activity, items):
        return _inject_nowtab_control_style_slide(plugin, activity, items)

    def inject_vinify_logo_position_radios(self, plugin, activity, items):
        return _inject_vinify_logo_position_radios(plugin, activity, items)

    def inject_vinify_cover_shape_slide(self, plugin, activity, items):
        return _inject_vinify_cover_shape_slide(plugin, activity, items)

    def inject_nowfy_pulse_style_slide(self, plugin, activity, items):
        return _inject_nowfy_pulse_style_slide(plugin, activity, items)

    def inject_custom_cover_selector(self, plugin, activity, items):
        return _inject_custom_cover_selector(plugin, activity, items)

    def on_custom_cover_select(self, plugin, value):
        return _on_custom_cover_select(plugin, value)

    def on_custom_cover_toggle(self, plugin, enabled_value):
        return _on_custom_cover_toggle(plugin, enabled_value)

    def get_core_setting(self, key, default=None):
        return self._state.get(str(key), default, plugin=self._runtime_plugin)

    def set_core_setting(self, key, value):
        return self._state.set(str(key), value, plugin=self._runtime_plugin)

    def is_theme_enabled(self, plugin, theme_key, default_value=False):
        raw = str(self.get_core_setting("core_enabled_optional_themes", "") or "").strip()
        return _is_theme_enabled(plugin, theme_key, default_value, core_enabled_optional_themes=raw)

    def inject_core_theme_multiselect(self, plugin, activity, items):
        return _inject_core_theme_multiselect(plugin, activity, items)

    def inject_statsfm_profile_custom(self, plugin, activity, items):
        return _inject_statsfm_profile_custom(plugin, activity, items)

    def inject_services_cards_custom(self, plugin, activity, items):
        return _inject_services_cards_custom(plugin, activity, items)

    def inject_home_services_entry_custom(self, plugin, activity, items):
        return _inject_home_services_entry_custom(plugin, activity, items)

    def get_plugin_lang_index(self, plugin):
        return _get_plugin_lang_index(plugin, key="plugin_lang", default=0)

    def get_quick_spotify_backend_base(self, plugin):
        try:
            v = str(plugin.get_setting("quick_spotify_backend_base", "") or "").strip()
            if v:
                return v
        except Exception:
            pass
        return "https://nowfy.meyankut.workers.dev"

    def _now(self):
        try:
            import time
            return int(time.time())
        except Exception:
            return 0

    def _cache_set_token(self, token, expires_in):
        try:
            exp = self._now() + int(expires_in or 3600)
        except Exception:
            exp = self._now() + 3600
        self._token_cache["value"] = str(token or "").strip()
        self._token_cache["exp"] = int(exp)

    def _cache_get_token(self):
        val = str(self._token_cache.get("value") or "").strip()
        exp = int(self._token_cache.get("exp") or 0)
        if val and exp and self._now() < exp - 15:
            return val
        return None

    def get_access_token(self, plugin, show_error_bulletin=False):
        cached = self._cache_get_token()
        if cached:
            return cached
        try:
            import requests, base64
        except Exception:
            return None
        try:
            quick_enabled = bool(plugin.get_setting("quick_spotify_auth_enabled", False))
        except Exception:
            quick_enabled = False
        try:
            quick_refresh = str(plugin.get_setting("quick_refresh_token", "") or "").strip()
        except Exception:
            quick_refresh = ""
        if quick_enabled and quick_refresh:
            try:
                base = self.get_quick_spotify_backend_base(plugin)
                force = False
                try:
                    force = bool(getattr(plugin, "_quick_force_renew_runtime", False))
                except Exception:
                    force = False
                resp = requests.post(
                    f"{base}/auth/spotify/token",
                    json={"refresh_token": quick_refresh, "force_renew": force},
                    timeout=8,
                )
                if resp.status_code == 200 and resp.content:
                    data = resp.json()
                    token = str(data.get("access_token", "") or "").strip()
                    exp = int(data.get("expires_in", 3600) or 3600)
                    if token:
                        self._cache_set_token(token, exp)
                        return token
            except Exception:
                pass
        cid = str(plugin.get_setting("client_id", "") or "").strip()
        csec = str(plugin.get_setting("client_secret", "") or "").strip()
        rref = str(plugin.get_setting("refresh_token", "") or "").strip()
        if cid and csec and rref:
            try:
                basic = base64.b64encode(f"{cid}:{csec}".encode("utf-8")).decode("utf-8")
                resp = requests.post(
                    "https://accounts.spotify.com/api/token",
                    data={"grant_type": "refresh_token", "refresh_token": rref},
                    headers={"Authorization": f"Basic {basic}"},
                    timeout=8,
                )
                if resp.status_code == 200 and resp.content:
                    data = resp.json()
                    token = str(data.get("access_token", "") or "").strip()
                    exp = int(data.get("expires_in", 3600) or 3600)
                    if token:
                        self._cache_set_token(token, exp)
                        new_ref = str(data.get("refresh_token", "") or "").strip()
                        if new_ref:
                            try:
                                plugin.set_setting("refresh_token", new_ref)
                            except Exception:
                                pass
                        return token
            except Exception:
                pass
        return None

    def exchange_code(self, plugin, code):
        try:
            import requests
        except Exception:
            return False, "network unavailable"
        c = str(code or "").strip()
        if not c:
            return False, "missing code"
        try:
            base = self.get_quick_spotify_backend_base(plugin)
            resp = requests.post(
                f"{base}/auth/spotify/exchange",
                json={"code": c},
                timeout=10,
            )
            if resp.status_code != 200 or not resp.content:
                return False, f"status {resp.status_code}"
            data = resp.json()
            refresh = str(data.get("refresh_token", "") or "").strip()
            token = str(data.get("access_token", "") or "").strip()
            exp = int(data.get("expires_in", 3600) or 3600)
            if refresh:
                try:
                    plugin.set_setting("quick_refresh_token", refresh)
                    plugin.set_setting("quick_spotify_auth_enabled", True)
                except Exception:
                    pass
            if token:
                self._cache_set_token(token, exp)
                try:
                    self.cache_spotify_profile_from_token(plugin, token)
                except Exception:
                    pass
            return True, ""
        except Exception as e:
            return False, str(e)

    def validate_credentials(self, plugin):
        tok = self.get_access_token(plugin, show_error_bulletin=False)
        return bool(tok)

    def get_spotify_user_profile(self, plugin):
        try:
            import requests
        except Exception:
            return None
        token = self.get_access_token(plugin, show_error_bulletin=False)
        if not token:
            return None
        try:
            resp = requests.get(
                "https://api.spotify.com/v1/me",
                headers={"Authorization": f"Bearer {token}"},
                timeout=8,
            )
            if resp.status_code != 200 or not resp.content:
                return None
            return resp.json()
        except Exception:
            return None

    def apply_spotify_profile_cache(self, plugin, profile):
        if not isinstance(profile, dict):
            return False
        try:
            pid = str(profile.get("id", "") or "").strip()
            name = str(profile.get("display_name", "") or "").strip()
            images = profile.get("images") or []
            img_url = ""
            try:
                if isinstance(images, list) and images:
                    first = images[0] or {}
                    img_url = str(first.get("url", "") or "").strip()
            except Exception:
                img_url = ""
            plugin.set_setting("spotify_user_id", pid)
            plugin.set_setting("spotify_user_name", name)
            plugin.set_setting("spotify_user_image_url", img_url)
            return True
        except Exception:
            return False

    def cache_spotify_profile_from_token(self, plugin, token):
        prof = self.get_spotify_user_profile(plugin)
        if isinstance(prof, dict):
            return self.apply_spotify_profile_cache(plugin, prof)
        return False

    def normalize_plugin_lang_index(self, idx):
        return _normalize_plugin_lang_index(idx)

    def get_plugin_lang_code(self, idx):
        return _get_plugin_lang_code(idx)

    def on_panel_drawer_toggle(self, plugin, enabled):
        return _on_panel_drawer_toggle(plugin, enabled)

    def on_panel_disable_logs_toggle(self, plugin, enabled, *args, **kwargs):
        a0 = args[0] if len(args) >= 1 else None
        a1 = args[1] if len(args) >= 2 else None
        a2 = args[2] if len(args) >= 3 else None
        a3 = args[3] if len(args) >= 4 else None
        return _on_panel_disable_logs_toggle(plugin, enabled, a0, a1, a2, a3)

    def on_lab_nowplaying_pill_toggle(self, plugin, enabled):
        return _on_lab_nowplaying_pill_toggle(plugin, enabled)

    def on_lab_send_haptic_toggle(self, plugin, enabled):
        return _on_lab_send_haptic_toggle(plugin, enabled)

    def clear_cache_data(self, plugin):
        return _clear_cache_data(plugin)

    def get_bio_feature_services(self, plugin):
        return _get_bio_feature_services(plugin)

    def build_track_hub_subfragment_items(self, plugin):
        return _build_track_hub_subfragment_items(plugin)

    def invoke_core_action(self, action_name):
        plugin = self._runtime_plugin
        if plugin is None:
            return False
        return _invoke_action(plugin, action_name)

    def animate_opening_avatar(self, plugin, avatar_view, from_y_dp=20, duration_ms=620):
        return _animate_opening_avatar(plugin, avatar_view, from_y_dp, duration_ms)

    def inject_about_support_rich_header(self, plugin, activity, items):
        return _inject_about_support_rich_header(plugin, activity, items)

    def export_core_settings(self):
        data = self._state.export()
        plugin = self._runtime_plugin
        if plugin is not None:
            try:
                data.update(_export_core_settings_from_plugin(plugin))
            except Exception:
                pass
        return data

    def import_core_settings(self, data):
        applied = self._state.import_settings(data, plugin=self._runtime_plugin)
        plugin = self._runtime_plugin
        if plugin is not None:
            try:
                _import_core_settings_to_plugin(plugin, data)
            except Exception:
                pass
        return applied


_API_SINGLETON = None


def get_nowfy_core_api():
    global _API_SINGLETON
    if _API_SINGLETON is None:
        _API_SINGLETON = NowfyCoreAPI()
    return _API_SINGLETON
