"""
MCP Tools — actions that agents can invoke.

Implements 9 tools from the PRD, each delegating to ContextManager.

Every tool is async and calls ``ctx_mgr.ensure_project(ctx)`` on entry
so that the project workspace is lazily resolved from the MCP client's
``roots/list`` on the very first invocation.
"""

from __future__ import annotations

import json
from typing import Any

from mcp.server.fastmcp import Context, FastMCP

from amcl.context.context_manager import ContextManager


def register_tools(mcp: FastMCP, ctx_mgr: ContextManager) -> None:
    """Register all A/MCL tools on the given FastMCP server."""

    @mcp.tool()
    async def context_get_current(
        include: str = "conversation,files,tasks,reasoning,agents",
        ctx: Context = None,
    ) -> str:
        """Get the complete current project context.

        Returns conversation history, file changes, active tasks,
        reasoning chains, and agent session history.

        Args:
            include: Comma-separated sections to include.
                     Options: conversation, files, tasks, reasoning, agents.
                     Default: all sections.
        """
        await ctx_mgr.ensure_project(ctx)
        sections = [s.strip() for s in include.split(",")]
        context = ctx_mgr.get_current_context(include=sections)
        return json.dumps(context, indent=2, default=str)

    @mcp.tool()
    async def context_update(data: str, ctx: Context = None) -> str:
        """Update context with new information.

        Accepts a JSON string with one or more of these keys:
        - message: {role, content, context_note}
        - file_change: {file, action, summary, diff}
        - task: {description, status, id}
        - decision: {question, answer, reasoning, alternatives}

        Example:
            {"message": {"role": "user", "content": "Help me build auth"}}
        """
        await ctx_mgr.ensure_project(ctx)
        try:
            payload = json.loads(data)
        except json.JSONDecodeError:
            return json.dumps({"error": "Invalid JSON"})
        result = ctx_mgr.update_context(payload)
        return json.dumps({"status": "ok", **result})

    @mcp.tool()
    async def context_query(query: str, ctx: Context = None) -> str:
        """Search context history for specific information.

        Searches across conversation messages, decisions, and tasks.

        Args:
            query: Search term to look for in context history.
        """
        await ctx_mgr.ensure_project(ctx)
        results = ctx_mgr.query_context(query)
        return json.dumps(results, indent=2, default=str)

    @mcp.tool()
    async def context_get_files_changed(ctx: Context = None) -> str:
        """Get files modified since the last agent switch.

        Returns a list of file changes with paths, actions,
        timestamps, and summaries.
        """
        await ctx_mgr.ensure_project(ctx)
        changes = ctx_mgr.get_files_changed_since_switch()
        return json.dumps(changes, indent=2, default=str)

    @mcp.tool()
    async def context_get_conversation(limit: int = 50, ctx: Context = None) -> str:
        """Get recent conversation history.

        Args:
            limit: Maximum number of messages to return (default 50).
        """
        await ctx_mgr.ensure_project(ctx)
        msgs = ctx_mgr.get_conversation(limit=limit)
        return json.dumps(msgs, indent=2, default=str)

    @mcp.tool()
    async def context_get_reasoning(ctx: Context = None) -> str:
        """Get the decision history and reasoning chains.

        Returns all logged design decisions with their rationale,
        alternatives considered, and the agent that made them.
        """
        await ctx_mgr.ensure_project(ctx)
        decisions = ctx_mgr.get_reasoning()
        return json.dumps(decisions, indent=2, default=str)

    @mcp.tool()
    async def context_add_decision(
        question: str,
        answer: str,
        reasoning: str = "",
        alternatives: str = "[]",
        ctx: Context = None,
    ) -> str:
        """Log a design decision.

        Args:
            question: The question or decision point.
            answer: The chosen answer / approach.
            reasoning: Why this choice was made.
            alternatives: JSON array of alternative options considered.
        """
        await ctx_mgr.ensure_project(ctx)
        try:
            alts = json.loads(alternatives)
        except json.JSONDecodeError:
            alts = []
        did = ctx_mgr.add_decision(question, answer, reasoning, alts)
        return json.dumps({"status": "ok", "decision_id": did})

    @mcp.tool()
    async def context_mark_complete(task_id: str, ctx: Context = None) -> str:
        """Mark a task as completed.

        Args:
            task_id: The ID of the task to mark as completed.
        """
        await ctx_mgr.ensure_project(ctx)
        ctx_mgr.mark_task_complete(task_id)
        return json.dumps({"status": "ok", "task_id": task_id, "new_status": "completed"})

    @mcp.tool()
    async def context_add_blocker(description: str, ctx: Context = None) -> str:
        """Record a blocking issue.

        Args:
            description: Description of what is blocked and why.
        """
        await ctx_mgr.ensure_project(ctx)
        tid = ctx_mgr.add_blocker(description)
        return json.dumps({"status": "ok", "task_id": tid, "status_set": "blocked"})
