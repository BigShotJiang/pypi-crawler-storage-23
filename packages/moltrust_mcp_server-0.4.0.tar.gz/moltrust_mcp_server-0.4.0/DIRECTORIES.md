# MCP Server Directories — Submission Tracker

Where to submit `moltrust-mcp-server` for maximum discoverability.

---

## Category 1: Official Registries

| # | Name | URL | Method | Priority |
|---|------|-----|--------|----------|
| 1 | Official MCP Registry | https://registry.modelcontextprotocol.io/ | CLI (`mcp-publisher publish`) | HIGH |
| 2 | modelcontextprotocol/servers | https://github.com/modelcontextprotocol/servers | PR (Community Servers section) | HIGH |
| 3 | Claude Connectors Directory | https://claude.com/connectors | Web form | HIGH |
| 4 | GitHub MCP Registry | https://github.com/mcp | Auto via Official MCP Registry | HIGH |

## Category 2: Major MCP Directories

| # | Name | URL | Method | Priority |
|---|------|-----|--------|----------|
| 5 | punkpeye/awesome-mcp-servers | https://github.com/punkpeye/awesome-mcp-servers | PR (alphabetical, per CONTRIBUTING.md) | HIGH |
| 6 | mcp.so | https://mcp.so/ | GitHub Issue at chatmcp/mcp-directory | HIGH |
| 7 | Glama.ai | https://glama.ai/mcp/servers | Synced from GitHub / Discord | HIGH |
| 8 | Smithery.ai | https://smithery.ai/ | CLI (`smithery mcp publish`) + smithery.yaml | HIGH |
| 9 | PulseMCP | https://www.pulsemcp.com/servers | Web form at /use-cases/submit | HIGH |
| 10 | mcpservers.org | https://mcpservers.org/ | Web form at /submit | HIGH |
| 11 | Docker MCP Catalog | https://hub.docker.com/mcp | PR to docker/mcp-registry | HIGH |
| 12 | Cline MCP Marketplace | https://cline.bot/mcp-marketplace | GitHub Issue at cline/mcp-marketplace | HIGH |
| 13 | LobeHub MCP Marketplace | https://lobehub.com/mcp | "Submit MCP" button on site | MEDIUM |
| 14 | OpenTools Registry | https://opentools.com/registry | Web form | MEDIUM |
| 15 | Cursor Directory (MCP) | https://cursor.directory/mcp | Check site for guidelines | MEDIUM |
| 16 | Windsurf Directory (MCP) | https://windsurf.run/mcp | Check site for guidelines | MEDIUM |
| 17 | Portkey.ai MCP Servers | https://portkey.ai/mcp-servers | Check site | MEDIUM |
| 18 | Composio MCP | https://mcp.composio.dev/ | Check docs | MEDIUM |
| 19 | Playbooks.com MCP | https://playbooks.com/mcp | Check site | MEDIUM |
| 20 | mcp.run | https://mcp.run/ | WASM servlet publish | MEDIUM |

## Category 3: Secondary MCP Directories

| # | Name | URL | Method | Priority |
|---|------|-----|--------|----------|
| 21 | MCPMarket.com | https://mcpmarket.com/ | Web form at /submit | MEDIUM |
| 22 | MCPServerFinder.com | https://www.mcpserverfinder.com/ | Check site | MEDIUM |
| 23 | MCPHub.com | https://mcphub.com/ | Check site | MEDIUM |
| 24 | MCPCentral.io | https://mcpcentral.io/submit-server | CLI (`mcp-publisher`) | MEDIUM |
| 25 | MCPRepository.com | https://mcprepository.com/ | CLI (`mcp-index`) | MEDIUM |
| 26 | MCPServerDirectory.org | https://mcpserverdirectory.org/submit | Web form | MEDIUM |
| 27 | MCP-Server-Directory.com | https://www.mcp-server-directory.com/submit | Web form | LOW |
| 28 | MCPServer.directory | https://www.mcpserver.directory/ | Check site | LOW |
| 29 | MCPNodes.com | https://mcpnodes.com/ | "Submit Your Resource" | LOW |
| 30 | MCPServer.dev | https://mcpserver.dev/ | Web form | LOW |
| 31 | MCP-Awesome.com | https://mcp-awesome.com/ | Check site | LOW |
| 32 | MCPServers.com | https://mcpservers.com/ | Check site | LOW |
| 33 | MCP-Servers-Hub.net | https://www.mcp-servers-hub.net/submit | Web form | LOW |
| 34 | MCPServerHub.net | https://mcpserverhub.net/ | Web form | LOW |
| 35 | MCPServer.cc | https://mcpserver.cc/directory | Meta-directory (reference) | LOW |
| 36 | Director.run | https://director.run/ | Check docs | LOW |

## Category 4: GitHub Awesome-Lists

| # | Name | URL | Method | Priority |
|---|------|-----|--------|----------|
| 37 | appcypher/awesome-mcp-servers | https://github.com/appcypher/awesome-mcp-servers | PR | MEDIUM |
| 38 | jaw9c/awesome-remote-mcp-servers | https://github.com/jaw9c/awesome-remote-mcp-servers | PR | MEDIUM |
| 39 | ever-works/awesome-mcp-servers | https://github.com/ever-works/awesome-mcp-servers | PR (develop branch) | LOW |
| 40 | patriksimek/awesome-mcp-servers-2 | https://github.com/patriksimek/awesome-mcp-servers-2 | PR | LOW |
| 41 | ClaudePro.directory | https://github.com/JSONbored/claudepro-directory | GitHub Issue | LOW |
| 42 | claudemcp.org | https://www.claudemcp.org/ | Check site | LOW |

## Category 5: Package Managers

| # | Name | URL | Method | Priority |
|---|------|-----|--------|----------|
| 43 | PyPI | https://pypi.org/ | `twine upload` / GitHub Actions | HIGH (done) |
| 44 | npm | https://www.npmjs.com/ | `npm publish` (needed for Official MCP Registry) | HIGH |
| 45 | Docker Hub | https://hub.docker.com/ | `docker push` | MEDIUM |

## Category 6: General AI Directories

| # | Name | URL | Method | Priority |
|---|------|-----|--------|----------|
| 46 | Product Hunt | https://www.producthunt.com/ | Scheduled launch | HIGH |
| 47 | There's An AI For That | https://theresanaiforthat.com/get-featured/ | Paid form ($300 PPC bonus) | MEDIUM |
| 48 | Futurepedia.io | https://www.futurepedia.io/submit-tool | Paid form ($49) | MEDIUM |
| 49 | Toolify.ai | https://www.toolify.ai/ | Paid form ($49-$99) | MEDIUM |
| 50 | AI Agents List | https://aiagentslist.com/mcp-servers | Check site | LOW |

## Category 7: Developer Communities

| # | Name | URL | Method | Priority |
|---|------|-----|--------|----------|
| 51 | Hacker News | https://news.ycombinator.com/ | "Show HN" post | HIGH |
| 52 | r/mcp | https://www.reddit.com/r/mcp/ | Post | HIGH |
| 53 | r/ClaudeAI | https://www.reddit.com/r/ClaudeAI/ | Post | HIGH |
| 54 | r/LocalLLaMA | https://www.reddit.com/r/LocalLLaMA/ | Post | MEDIUM |
| 55 | r/cursor | https://www.reddit.com/r/cursor/ | Post | MEDIUM |
| 56 | X / Twitter | https://x.com/ | Post (#MCP #ModelContextProtocol) | MEDIUM |
| 57 | DEV.to | https://dev.to/ | Blog post (tags: mcp, ai, claude) | MEDIUM |
| 58 | MCP Discord | https://modelcontextprotocol.io/community | Join + share | MEDIUM |
| 59 | LinkedIn | https://linkedin.com/ | Article / post | LOW |

---

## Recommended Submission Order

1. Official MCP Registry (auto-feeds GitHub MCP Registry + VS Code)
2. modelcontextprotocol/servers (PR)
3. punkpeye/awesome-mcp-servers (PR)
4. mcp.so (GitHub Issue)
5. Smithery.ai (CLI)
6. Glama.ai (Discord/sync)
7. PulseMCP (web form)
8. mcpservers.org (web form)
9. Docker MCP Catalog (PR)
10. Cline Marketplace (GitHub Issue)
11. Claude Connectors (web form)
12. LobeHub (web form)
13. Product Hunt (scheduled launch)
14. Hacker News (Show HN)
15. Reddit (r/mcp, r/ClaudeAI)
16. Remaining MEDIUM entries
17. Remaining LOW entries
