"""
Tools module - Utilities and clients for automation workflows.

This module provides pre-configured clients and utilities that automations
can use to interact with external services in a controlled manner.
"""

from torivers_sdk.tools.data import DataProcessor
from torivers_sdk.tools.http import (
    ALLOWED_SCHEMES,
    BLOCKED_NETWORKS,
    DEFAULT_TIMEOUT,
    HTTP_METHODS,
    MAX_REQUEST_SIZE,
    MAX_RESPONSE_SIZE,
    MAX_TIMEOUT,
    MIN_TIMEOUT,
    HttpBlockedIPError,
    HttpClient,
    HttpConnectionError,
    HttpError,
    HttpInvalidUrlError,
    HttpRateLimitError,
    HttpRequestTooLargeError,
    HttpResponse,
    HttpResponseTooLargeError,
    HttpSchemeNotAllowedError,
    HttpStatusError,
    HttpTimeoutError,
    is_blocked_ip,
    validate_timeout,
    validate_url,
)
from torivers_sdk.tools.llm import (
    APPROVED_CHAT_MODELS,
    APPROVED_EMBEDDING_MODELS,
    APPROVED_MODELS,
    DEFAULT_CHAT_MODEL,
    DEFAULT_EMBEDDING_MODEL,
    EmbeddingResponse,
    HttpLLMClient,
    LLMClient,
    LLMError,
    LLMMessage,
    LLMResponse,
    ModelNotApprovedError,
    RateLimitError,
    TokenLimitExceededError,
    TokenUsage,
)
from torivers_sdk.tools.storage import (
    DEFAULT_MAX_FILE_SIZE,
    DEFAULT_MAX_TOTAL_SIZE,
    DEFAULT_RETENTION_DAYS,
    MIME_TYPES,
    HttpStorageClient,
    StorageAccessDeniedError,
    StorageClient,
    StorageError,
    StorageFile,
    StorageFileNotFoundError,
    StorageFileTooLargeError,
    StorageInvalidContentTypeError,
    StorageQuota,
    StorageQuotaExceededError,
    guess_content_type,
)

__all__ = [
    # HTTP Client
    "HttpClient",
    "HttpResponse",
    # HTTP Errors
    "HttpError",
    "HttpInvalidUrlError",
    "HttpSchemeNotAllowedError",
    "HttpBlockedIPError",
    "HttpRequestTooLargeError",
    "HttpResponseTooLargeError",
    "HttpTimeoutError",
    "HttpConnectionError",
    "HttpStatusError",
    "HttpRateLimitError",
    # HTTP Constants
    "BLOCKED_NETWORKS",
    "MAX_REQUEST_SIZE",
    "MAX_RESPONSE_SIZE",
    "DEFAULT_TIMEOUT",
    "MIN_TIMEOUT",
    "MAX_TIMEOUT",
    "ALLOWED_SCHEMES",
    "HTTP_METHODS",
    # HTTP Helpers
    "is_blocked_ip",
    "validate_url",
    "validate_timeout",
    # LLM Client
    "LLMClient",
    "HttpLLMClient",
    "LLMMessage",
    "LLMResponse",
    "EmbeddingResponse",
    "TokenUsage",
    # LLM Errors
    "LLMError",
    "ModelNotApprovedError",
    "RateLimitError",
    "TokenLimitExceededError",
    # LLM Constants
    "APPROVED_MODELS",
    "APPROVED_CHAT_MODELS",
    "APPROVED_EMBEDDING_MODELS",
    "DEFAULT_CHAT_MODEL",
    "DEFAULT_EMBEDDING_MODEL",
    # Storage Client
    "HttpStorageClient",
    "StorageClient",
    "StorageFile",
    "StorageQuota",
    # Storage Errors
    "StorageError",
    "StorageFileNotFoundError",
    "StorageQuotaExceededError",
    "StorageFileTooLargeError",
    "StorageInvalidContentTypeError",
    "StorageAccessDeniedError",
    # Storage Constants
    "DEFAULT_MAX_FILE_SIZE",
    "DEFAULT_MAX_TOTAL_SIZE",
    "DEFAULT_RETENTION_DAYS",
    "MIME_TYPES",
    "guess_content_type",
    # Data Processing
    "DataProcessor",
]
