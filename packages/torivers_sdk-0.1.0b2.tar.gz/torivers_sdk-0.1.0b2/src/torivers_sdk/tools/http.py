"""
Controlled HTTP client for automations.

This module provides a controlled HTTP client that enforces network
policies and domain restrictions in sandboxed environments.

Security restrictions:
- Only HTTPS allowed (HTTP requests rejected)
- Private/internal IP ranges blocked
- Cloud metadata endpoints blocked
- Request/response size limits enforced
- Configurable timeouts
"""

from __future__ import annotations

import ipaddress
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any
from urllib.parse import urlparse

# =============================================================================
# Constants
# =============================================================================

# Blocked network ranges (CIDR notation)
# These prevent SSRF attacks and access to internal resources
BLOCKED_NETWORKS: list[str] = [
    "10.0.0.0/8",  # Private network (Class A)
    "172.16.0.0/12",  # Private network (Class B)
    "192.168.0.0/16",  # Private network (Class C)
    "169.254.0.0/16",  # Link-local addresses
    "127.0.0.0/8",  # Loopback
    "169.254.169.254/32",  # Cloud metadata (AWS/GCP/Azure)
    "::1/128",  # IPv6 loopback
    "fc00::/7",  # IPv6 unique local addresses
    "fe80::/10",  # IPv6 link-local
]

# Size limits
MAX_REQUEST_SIZE: int = 1 * 1024 * 1024  # 1 MB
MAX_RESPONSE_SIZE: int = 10 * 1024 * 1024  # 10 MB

# Timeout settings
DEFAULT_TIMEOUT: float = 30.0
MIN_TIMEOUT: float = 1.0
MAX_TIMEOUT: float = 300.0  # 5 minutes

# Protocol requirements
ALLOWED_SCHEMES: set[str] = {"https"}

# Common HTTP methods
HTTP_METHODS: set[str] = {"GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"}


# =============================================================================
# Helper Functions
# =============================================================================


def is_blocked_ip(ip_str: str) -> bool:
    """
    Check if an IP address is in blocked networks.

    This prevents SSRF attacks by blocking access to:
    - Private network ranges (10.x.x.x, 172.16-31.x.x, 192.168.x.x)
    - Loopback addresses (127.x.x.x)
    - Link-local addresses (169.254.x.x)
    - Cloud metadata endpoints (169.254.169.254)
    - IPv6 equivalents

    Args:
        ip_str: IP address as string

    Returns:
        True if IP is blocked, False otherwise
    """
    try:
        ip_addr = ipaddress.ip_address(ip_str)
        for network_str in BLOCKED_NETWORKS:
            network = ipaddress.ip_network(network_str, strict=False)
            if ip_addr in network:
                return True
        return False
    except ValueError:
        # Invalid IP address format - treat as blocked for safety
        return True


def validate_url(url: str) -> tuple[str, str, int]:
    """
    Validate a URL for security requirements.

    Checks:
    - URL is well-formed
    - Scheme is HTTPS (or allowed scheme)
    - Host is not empty

    Args:
        url: URL to validate

    Returns:
        Tuple of (scheme, host, port)

    Raises:
        HttpInvalidUrlError: If URL is malformed
        HttpSchemeNotAllowedError: If scheme is not HTTPS
    """
    if not url or not isinstance(url, str):
        raise HttpInvalidUrlError("URL must be a non-empty string")

    try:
        parsed = urlparse(url)
    except Exception as e:
        raise HttpInvalidUrlError(f"Failed to parse URL: {e}")

    if not parsed.scheme:
        raise HttpInvalidUrlError("URL must include a scheme (e.g., https://)")

    if parsed.scheme.lower() not in ALLOWED_SCHEMES:
        raise HttpSchemeNotAllowedError(
            url=url,
            scheme=parsed.scheme,
            allowed_schemes=list(ALLOWED_SCHEMES),
        )

    if not parsed.netloc:
        raise HttpInvalidUrlError("URL must include a host")

    # Extract port (default to 443 for HTTPS)
    port = parsed.port if parsed.port else 443

    return parsed.scheme.lower(), parsed.hostname or "", port


def validate_timeout(timeout: float) -> float:
    """
    Validate and clamp timeout value.

    Args:
        timeout: Requested timeout in seconds

    Returns:
        Valid timeout value within allowed range
    """
    if timeout < MIN_TIMEOUT:
        return MIN_TIMEOUT
    if timeout > MAX_TIMEOUT:
        return MAX_TIMEOUT
    return timeout


# =============================================================================
# Exceptions
# =============================================================================


class HttpError(Exception):
    """Base error for HTTP operations."""

    def __init__(
        self,
        message: str,
        code: str | None = None,
        url: str | None = None,
        status_code: int | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.url = url
        self.status_code = status_code


class HttpInvalidUrlError(HttpError):
    """Raised when URL is malformed or invalid."""

    def __init__(self, message: str, url: str | None = None) -> None:
        super().__init__(
            message,
            code="invalid_url",
            url=url,
        )


class HttpSchemeNotAllowedError(HttpError):
    """Raised when URL scheme is not allowed (e.g., http:// instead of https://)."""

    def __init__(
        self,
        url: str,
        scheme: str,
        allowed_schemes: list[str] | None = None,
    ) -> None:
        allowed = allowed_schemes or list(ALLOWED_SCHEMES)
        message = (
            f"Scheme '{scheme}' is not allowed. "
            f"Only {', '.join(allowed)} URLs are permitted."
        )
        super().__init__(
            message,
            code="scheme_not_allowed",
            url=url,
        )
        self.scheme = scheme
        self.allowed_schemes = allowed


class HttpBlockedIPError(HttpError):
    """Raised when request targets a blocked IP address."""

    def __init__(self, url: str, ip: str) -> None:
        message = (
            f"Access to IP address '{ip}' is blocked. "
            "Private networks, loopback, and cloud metadata endpoints are not allowed."
        )
        super().__init__(
            message,
            code="blocked_ip",
            url=url,
        )
        self.ip = ip


class HttpRequestTooLargeError(HttpError):
    """Raised when request body exceeds size limit."""

    def __init__(
        self,
        size_bytes: int,
        max_size_bytes: int = MAX_REQUEST_SIZE,
        url: str | None = None,
    ) -> None:
        size_kb = size_bytes / 1024
        max_kb = max_size_bytes / 1024
        message = (
            f"Request body too large ({size_kb:.2f} KB). "
            f"Maximum allowed size is {max_kb:.2f} KB."
        )
        super().__init__(
            message,
            code="request_too_large",
            url=url,
        )
        self.size_bytes = size_bytes
        self.max_size_bytes = max_size_bytes


class HttpResponseTooLargeError(HttpError):
    """Raised when response body exceeds size limit."""

    def __init__(
        self,
        size_bytes: int,
        max_size_bytes: int = MAX_RESPONSE_SIZE,
        url: str | None = None,
    ) -> None:
        size_mb = size_bytes / (1024 * 1024)
        max_mb = max_size_bytes / (1024 * 1024)
        message = (
            f"Response body too large ({size_mb:.2f} MB). "
            f"Maximum allowed size is {max_mb:.2f} MB."
        )
        super().__init__(
            message,
            code="response_too_large",
            url=url,
        )
        self.size_bytes = size_bytes
        self.max_size_bytes = max_size_bytes


class HttpTimeoutError(HttpError):
    """Raised when request times out."""

    def __init__(
        self,
        url: str,
        timeout: float,
    ) -> None:
        message = f"Request timed out after {timeout} seconds"
        super().__init__(
            message,
            code="timeout",
            url=url,
        )
        self.timeout = timeout


class HttpConnectionError(HttpError):
    """Raised when connection to server fails."""

    def __init__(
        self,
        url: str,
        reason: str | None = None,
    ) -> None:
        message = "Failed to connect to server"
        if reason:
            message = f"{message}: {reason}"
        super().__init__(
            message,
            code="connection_error",
            url=url,
        )
        self.reason = reason


class HttpStatusError(HttpError):
    """Raised for HTTP error status codes (4xx, 5xx)."""

    def __init__(
        self,
        message: str,
        status_code: int,
        url: str | None = None,
    ) -> None:
        super().__init__(
            message,
            code="status_error",
            url=url,
            status_code=status_code,
        )

    @property
    def is_client_error(self) -> bool:
        """Check if status indicates client error (4xx)."""
        return self.status_code is not None and 400 <= self.status_code < 500

    @property
    def is_server_error(self) -> bool:
        """Check if status indicates server error (5xx)."""
        return self.status_code is not None and 500 <= self.status_code < 600


class HttpRateLimitError(HttpError):
    """Raised when rate limit is exceeded."""

    def __init__(
        self,
        url: str,
        retry_after: float | None = None,
    ) -> None:
        message = "Rate limit exceeded"
        if retry_after:
            message = f"{message}. Retry after {retry_after} seconds."
        super().__init__(
            message,
            code="rate_limit",
            url=url,
            status_code=429,
        )
        self.retry_after = retry_after


# =============================================================================
# Data Classes
# =============================================================================


@dataclass
class HttpResponse:
    """HTTP response wrapper."""

    status_code: int
    headers: dict[str, str]
    body: bytes
    url: str
    elapsed_ms: float = 0.0
    request_method: str = "GET"

    @property
    def text(self) -> str:
        """Get response body as text."""
        return self.body.decode("utf-8")

    def json(self) -> Any:
        """Parse response body as JSON."""
        import json

        return json.loads(self.body)

    @property
    def ok(self) -> bool:
        """Check if response indicates success (2xx status)."""
        return 200 <= self.status_code < 300

    @property
    def is_redirect(self) -> bool:
        """Check if response is a redirect (3xx status)."""
        return 300 <= self.status_code < 400

    @property
    def is_client_error(self) -> bool:
        """Check if response indicates client error (4xx status)."""
        return 400 <= self.status_code < 500

    @property
    def is_server_error(self) -> bool:
        """Check if response indicates server error (5xx status)."""
        return 500 <= self.status_code < 600

    @property
    def content_type(self) -> str:
        """Get content type from headers."""
        return self.headers.get("content-type", self.headers.get("Content-Type", ""))

    @property
    def content_length(self) -> int:
        """Get content length from headers or body."""
        length = self.headers.get("content-length", self.headers.get("Content-Length"))
        if length:
            try:
                return int(length)
            except ValueError:
                pass
        return len(self.body)

    def raise_for_status(self) -> None:
        """
        Raise HttpStatusError if response indicates an error.

        Raises:
            HttpStatusError: If status code indicates error (4xx or 5xx)
        """
        if self.is_client_error or self.is_server_error:
            raise HttpStatusError(
                f"HTTP {self.status_code}",
                status_code=self.status_code,
                url=self.url,
            )


class HttpClient(ABC):
    """
    Controlled HTTP client for external requests.

    Automations use this client to make HTTP requests. In sandboxed
    environments, requests are routed through a proxy that enforces:
    - Domain allowlist/blocklist
    - Rate limiting
    - Request/response logging
    - Content filtering

    The actual implementation is injected by the runtime.

    Example:
        async def fetch_data(self, state: MyState) -> dict:
            http = HttpClient.get_default()

            response = await http.get(
                "https://api.example.com/data",
                headers={"Accept": "application/json"}
            )

            if response.ok:
                data = response.json()
                return {"output_data": {"data": data}}
            else:
                raise HttpError(f"Request failed: {response.status_code}")
    """

    @abstractmethod
    async def get(
        self,
        url: str,
        headers: dict[str, str] | None = None,
        params: dict[str, Any] | None = None,
        timeout: float = 30.0,
    ) -> HttpResponse:
        """
        Make a GET request.

        Args:
            url: Request URL
            headers: Optional headers
            params: Optional query parameters
            timeout: Request timeout in seconds

        Returns:
            HTTP response

        Raises:
            HttpError: If request fails
        """
        pass

    @abstractmethod
    async def post(
        self,
        url: str,
        data: bytes | dict[str, Any] | None = None,
        json: Any | None = None,
        headers: dict[str, str] | None = None,
        timeout: float = 30.0,
    ) -> HttpResponse:
        """
        Make a POST request.

        Args:
            url: Request URL
            data: Request body (bytes or form data)
            json: JSON body (will be serialized)
            headers: Optional headers
            timeout: Request timeout in seconds

        Returns:
            HTTP response

        Raises:
            HttpError: If request fails
        """
        pass

    @abstractmethod
    async def put(
        self,
        url: str,
        data: bytes | dict[str, Any] | None = None,
        json: Any | None = None,
        headers: dict[str, str] | None = None,
        timeout: float = 30.0,
    ) -> HttpResponse:
        """
        Make a PUT request.

        Args:
            url: Request URL
            data: Request body
            json: JSON body
            headers: Optional headers
            timeout: Request timeout in seconds

        Returns:
            HTTP response

        Raises:
            HttpError: If request fails
        """
        pass

    @abstractmethod
    async def delete(
        self,
        url: str,
        headers: dict[str, str] | None = None,
        timeout: float = 30.0,
    ) -> HttpResponse:
        """
        Make a DELETE request.

        Args:
            url: Request URL
            headers: Optional headers
            timeout: Request timeout in seconds

        Returns:
            HTTP response

        Raises:
            HttpError: If request fails
        """
        pass

    @abstractmethod
    async def patch(
        self,
        url: str,
        data: bytes | dict[str, Any] | None = None,
        json: Any | None = None,
        headers: dict[str, str] | None = None,
        timeout: float = 30.0,
    ) -> HttpResponse:
        """
        Make a PATCH request.

        Args:
            url: Request URL
            data: Request body
            json: JSON body
            headers: Optional headers
            timeout: Request timeout in seconds

        Returns:
            HTTP response

        Raises:
            HttpError: If request fails
        """
        pass

    @staticmethod
    def get_default() -> "HttpClient":
        """
        Get the default HTTP client.

        In the runtime environment, this returns the proxy-backed client.
        For testing, use MockHttpClient or httpx directly.

        Returns:
            Default HTTP client instance

        Raises:
            RuntimeError: If called outside runtime environment
        """
        raise RuntimeError(
            "HttpClient.get_default() can only be called in the runtime environment. "
            "For testing, use torivers_sdk.testing.mocks.MockHttpClient."
        )
