"""
Automation module - Core classes for building automations.

This module provides the base classes and utilities for creating
LangGraph-based automations that run on the ToRivers platform.

Re-exports from langgraph for convenience:
    - StateGraph: The main graph builder class
    - START: Entry point constant for graph edges
    - END: Exit point constant for graph edges
"""

# Re-export langgraph graph building primitives
from langgraph.graph import END, START, StateGraph

from torivers_sdk.automation.base import Automation
from torivers_sdk.automation.decorators import node, tool
from torivers_sdk.automation.metadata import (
    AutomationKind,
    AutomationMetadata,
    AutomationType,
    ExecutionLimits,
    InputField,
    OutputField,
)
from torivers_sdk.automation.state import BaseState, append_list, last_value, merge_dict

__all__ = [
    # LangGraph re-exports
    "StateGraph",
    "START",
    "END",
    # Core classes
    "Automation",
    "AutomationKind",
    "AutomationMetadata",
    "AutomationType",
    "ExecutionLimits",
    "InputField",
    "OutputField",
    # State utilities
    "BaseState",
    "merge_dict",
    "append_list",
    "last_value",
    # Decorators
    "node",
    "tool",
]
