"""
Testing module - Utilities for testing automations locally.

This module provides mock implementations and sandbox utilities
that enable developers to test their automations locally before
submitting to the marketplace.

Two sandbox options are available:
- LocalSandbox: In-process execution (fast, no Docker required)
- DockerSandbox: Docker-based execution (production-like isolation)
"""

from torivers_sdk.context.mocks import MockCredentialProxy
from torivers_sdk.testing.assertions import (
    assert_execution_time,
    assert_memory_within_limit,
    assert_no_errors,
    assert_output_contains,
    assert_output_matches,
    assert_output_type,
    assert_progress_logged,
    assert_success,
    assert_tokens_within_limit,
    assert_within_limits,
)
from torivers_sdk.testing.docker_sandbox import (
    DockerSandbox,
    DockerSandboxConfig,
    DockerSandboxError,
    SandboxResult,
)
from torivers_sdk.testing.mocks import (
    MockCredentials,
    MockGmailClient,
    MockGoogleSheetsClient,
    MockHttpClient,
    MockLLMClient,
    MockSlackClient,
    MockStorageClient,
)
from torivers_sdk.testing.sandbox import ExecutionResult, LocalSandbox, SandboxConfig

__all__ = [
    # In-process sandbox
    "LocalSandbox",
    "SandboxConfig",
    "ExecutionResult",
    # Docker sandbox
    "DockerSandbox",
    "DockerSandboxConfig",
    "DockerSandboxError",
    "SandboxResult",
    # Mocks
    "MockCredentialProxy",
    "MockCredentials",
    "MockGmailClient",
    "MockGoogleSheetsClient",
    "MockHttpClient",
    "MockLLMClient",
    "MockSlackClient",
    "MockStorageClient",
    # Assertions
    "assert_execution_time",
    "assert_memory_within_limit",
    "assert_no_errors",
    "assert_output_contains",
    "assert_output_matches",
    "assert_output_type",
    "assert_progress_logged",
    "assert_success",
    "assert_tokens_within_limit",
    "assert_within_limits",
]
