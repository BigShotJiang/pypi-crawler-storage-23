from __future__ import annotations

import sqlite3
import struct
from pathlib import Path

from .types import (
    AudioOutputFileTD,
    AudioOutputResultTD,
    ClipWaveBlockRefTD,
    ProjectParsedTD,
    SampleFormatInfoTD,
)


def _safe_int(value: object) -> int | None:
    try:
        if value is None:
            return None
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        if isinstance(value, float):
            if not value.is_integer():
                return None
            return int(value)
        if isinstance(value, str):
            stripped = value.strip()
            if not stripped:
                return None
            return int(stripped)
        return int(value)
    except Exception:
        return None


def _safe_float(value: object) -> float | None:
    try:
        if value is None:
            return None
        if isinstance(value, bool):
            return float(int(value))
        if isinstance(value, (int, float)):
            return float(value)
        if isinstance(value, str):
            stripped = value.strip()
            if not stripped:
                return None
            return float(stripped)
        return float(value)
    except Exception:
        return None


def _sampleformat_to_description(sampleformat: int) -> SampleFormatInfoTD:
    return {
        "raw": sampleformat,
        "sample_width_bytes": sampleformat >> 16,
        "encoding_id": sampleformat & 0xFFFF,
    }


def _extract_channel_block_refs(project_parsed: ProjectParsedTD | None) -> dict[int, list[tuple[int, int]]]:
    if project_parsed is None:
        return {}

    channel_wave_blocks = project_parsed.get("channel_wave_blocks")
    if channel_wave_blocks is None:
        return {}

    channel_map: dict[int, list[tuple[int, int]]] = {}
    for item in channel_wave_blocks:
        channel = _safe_int(item.get("channel"))
        blockid = _safe_int(item.get("blockid"))
        start = _safe_int(item.get("start"))
        if channel is None or blockid is None or start is None:
            continue
        channel_map.setdefault(channel, []).append((start, blockid))

    ordered: dict[int, list[tuple[int, int]]] = {}
    for channel, refs in channel_map.items():
        unique = sorted(set(refs), key=lambda pair: (pair[0], pair[1]))
        ordered[channel] = unique
    return ordered


def _extract_clip_block_refs(project_parsed: ProjectParsedTD | None) -> dict[int, list[ClipWaveBlockRefTD]]:
    if project_parsed is None:
        return {}

    clip_wave_blocks = project_parsed.get("clip_wave_blocks")
    if clip_wave_blocks is None:
        return {}

    channel_map: dict[int, list[ClipWaveBlockRefTD]] = {}
    for item in clip_wave_blocks:
        channel = _safe_int(item.get("channel"))
        blockid = _safe_int(item.get("blockid"))
        block_start = _safe_int(item.get("block_start"))
        if channel is None or blockid is None or block_start is None:
            continue
        channel_map.setdefault(channel, []).append(item)

    ordered: dict[int, list[ClipWaveBlockRefTD]] = {}
    for channel, refs in channel_map.items():
        ordered[channel] = sorted(
            refs,
            key=lambda item: (
                _safe_float(item.get("clip_offset")) or 0.0,
                _safe_int(item.get("block_start")) or 0,
                _safe_int(item.get("blockid")) or 0,
            ),
        )
    return ordered


def _resolve_project_sample_rate(project_parsed: ProjectParsedTD | None) -> float | None:
    if project_parsed is None:
        return None
    parsed_rate = _safe_float(project_parsed.get("sample_rate"))
    if parsed_rate is None or parsed_rate <= 0:
        return None
    return parsed_rate


def _resolve_track_sample_rate(project_parsed: ProjectParsedTD | None) -> float | None:
    if project_parsed is None:
        return None
    tracks = project_parsed.get("wave_tracks")
    if not isinstance(tracks, list):
        return None

    rates: list[float] = []
    for track in tracks:
        if not isinstance(track, dict):
            continue
        rate = _safe_float(track.get("rate"))
        if rate is None or rate <= 0:
            continue
        if not any(abs(rate - known) < 1e-6 for known in rates):
            rates.append(rate)

    if not rates:
        return None
    if len(rates) > 1:
        raise ValueError(
            "Multiple wavetrack.rate values found "
            f"({rates}); cannot determine one export sample rate."
        )
    return rates[0]


def _write_wav_file(
    output_path: Path,
    payload: bytes,
    channel_count: int,
    sample_width: int,
    wav_format_code: int,
    sample_rate: int,
) -> int:
    data_len = len(payload)
    if data_len > 0xFFFFFFFF:
        raise ValueError("WAV payload is too large for RIFF container.")
    block_align = channel_count * sample_width
    byte_rate = sample_rate * block_align
    bits_per_sample = sample_width * 8
    if byte_rate > 0xFFFFFFFF:
        raise ValueError("WAV byte_rate overflow.")
    riff_chunk_size = data_len + 36
    if riff_chunk_size > 0xFFFFFFFF:
        raise ValueError("WAV chunk size overflow.")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("wb") as wav_file:
        wav_file.write(b"RIFF")
        wav_file.write(struct.pack("<I", riff_chunk_size))
        wav_file.write(b"WAVE")
        wav_file.write(b"fmt ")
        wav_file.write(struct.pack("<I", 16))
        wav_file.write(struct.pack("<H", wav_format_code))
        wav_file.write(struct.pack("<H", channel_count))
        wav_file.write(struct.pack("<I", sample_rate))
        wav_file.write(struct.pack("<I", byte_rate))
        wav_file.write(struct.pack("<H", block_align))
        wav_file.write(struct.pack("<H", bits_per_sample))
        wav_file.write(b"data")
        wav_file.write(struct.pack("<I", data_len))
        wav_file.write(payload)
    return len(payload)


def _make_unique_directory_candidate(path: Path) -> Path:
    if not path.exists() or path.is_dir():
        return path

    base = path.parent / f"{path.stem}_channels"
    candidate = base
    index = 2
    while candidate.exists() and not candidate.is_dir():
        candidate = path.parent / f"{base.name}_{index}"
        index += 1
    return candidate


def _resolve_multichannel_output_dir(audio_output_path: Path) -> tuple[Path, bool]:
    # UX rule:
    # - if user passes file-like path (e.g. out.wav), map to out_channels/ directory.
    # - if user passes directory-like path, use as-is.
    requested = audio_output_path
    if requested.suffix:
        candidate = requested.parent / f"{requested.stem}_channels"
        return _make_unique_directory_candidate(candidate), True
    return _make_unique_directory_candidate(requested), False


def _resolve_single_channel_output_dir(audio_output_path: Path) -> Path:
    if audio_output_path.suffix:
        candidate = audio_output_path.parent / (audio_output_path.stem or "output")
        return _make_unique_directory_candidate(candidate)
    return _make_unique_directory_candidate(audio_output_path)


def _resolve_single_channel_output_file(audio_output_path: Path, file_name: str) -> Path:
    return _resolve_single_channel_output_dir(audio_output_path) / file_name


def _has_known_audio_extension(name: str) -> bool:
    lowered = name.lower()
    return any(
        lowered.endswith(ext)
        for ext in (
            ".wav",
            ".mp3",
            ".flac",
            ".aac",
            ".m4a",
            ".ogg",
            ".aif",
            ".aiff",
            ".wma",
            ".opus",
        )
    )


def _strip_known_audio_extension(name: str) -> str:
    lowered = name.lower()
    for ext in (".wav", ".mp3", ".flac", ".aac", ".m4a", ".ogg", ".aif", ".aiff", ".wma", ".opus"):
        if lowered.endswith(ext) and len(name) > len(ext):
            return name[: -len(ext)]
    return name


def _extract_original_audio_output_base(project_parsed: ProjectParsedTD | None) -> str | None:
    if project_parsed is None:
        return None

    preferred: list[str] = []
    fallback: list[str] = []

    for key in ("wave_clips_preview", "wave_tracks"):
        items = project_parsed.get(key)
        if not isinstance(items, list):
            continue
        for item in items:
            if not isinstance(item, dict):
                continue
            name = item.get("name")
            if not isinstance(name, str):
                continue
            trimmed = name.strip()
            if not trimmed:
                continue
            if _has_known_audio_extension(trimmed):
                preferred.append(trimmed)
            else:
                fallback.append(trimmed)

    for name in preferred + fallback:
        base = _sanitize_filename_component(_strip_known_audio_extension(name))
        if base:
            return base
    return None


def _sanitize_filename_component(raw: str) -> str:
    sanitized = "".join(ch if (ch.isalnum() or ch in "-_") else "_" for ch in raw)
    normalized = sanitized.strip("_")
    return normalized or "channel"


def _extract_channel_track_names(project_parsed: ProjectParsedTD | None) -> dict[int, str]:
    if project_parsed is None:
        return {}
    tracks = project_parsed.get("wave_tracks")
    if not isinstance(tracks, list):
        return {}

    names: dict[int, str] = {}
    for track in tracks:
        if not isinstance(track, dict):
            continue
        channel = _safe_int(track.get("channel"))
        name = track.get("name")
        if channel is None or not isinstance(name, str) or not name.strip():
            continue
        names.setdefault(channel, _sanitize_filename_component(name))
    return names


def _make_output_filename(
    channel: int,
    channel_track_names: dict[int, str],
    seen_names: dict[str, int],
) -> str:
    base = channel_track_names.get(channel, f"channel_{channel:02d}")
    count = seen_names.get(base, 0)
    seen_names[base] = count + 1
    if count == 0:
        return f"{base}.wav"
    return f"{base}_{count}.wav"


def _render_channel_timeline(
    refs: list[tuple[int, int]],
    block_samples: dict[int, bytes],
    sample_width: int,
) -> tuple[bytes, bool]:
    fragments: list[tuple[int, bytes]] = []
    for start_sample, block_id in sorted(refs, key=lambda pair: (pair[0], pair[1])):
        payload = block_samples.get(block_id)
        if payload is None:
            raise ValueError(f"Timeline references missing blockid in sampleblocks: blockid={block_id}")
        fragments.append((start_sample, payload))
    return _render_timeline_fragments(fragments, sample_width)


def _render_timeline_fragments(fragments: list[tuple[int, bytes]], sample_width: int) -> tuple[bytes, bool]:
    if not fragments:
        return (b"", False)

    sorted_fragments = sorted(fragments, key=lambda pair: pair[0])
    max_end_sample = 0
    normalized: list[tuple[int, bytes, int]] = []
    for start_sample, payload in sorted_fragments:
        if start_sample < 0:
            raise ValueError(f"Negative start sample in timeline refs: start={start_sample}")
        if len(payload) % sample_width != 0:
            raise ValueError(
                "Block payload byte length is not divisible by sample width: "
                f"bytes={len(payload)}, sample_width={sample_width}"
            )
        block_sample_count = len(payload) // sample_width
        end_sample = start_sample + block_sample_count
        max_end_sample = max(max_end_sample, end_sample)
        normalized.append((start_sample, payload, block_sample_count))

    timeline = bytearray(max_end_sample * sample_width)
    overlap_detected = False
    previous_end = 0
    for start_sample, payload, block_sample_count in normalized:
        if start_sample < previous_end:
            overlap_detected = True
        start_byte = start_sample * sample_width
        end_byte = start_byte + (block_sample_count * sample_width)
        timeline[start_byte:end_byte] = payload
        previous_end = max(previous_end, start_sample + block_sample_count)

    return (bytes(timeline), overlap_detected)


def _apply_clip_overlap_precedence(
    fragments: list[tuple[int, bytes]],
    sample_width: int,
) -> tuple[list[tuple[int, bytes]], bool]:
    ordered = sorted(fragments, key=lambda pair: pair[0])
    resolved: list[tuple[int, bytes]] = []
    overlap_detected = False
    previous_end = 0

    for start_sample, payload in ordered:
        if len(payload) % sample_width != 0:
            raise ValueError(
                "Block payload byte length is not divisible by sample width: "
                f"bytes={len(payload)}, sample_width={sample_width}"
            )
        sample_count = len(payload) // sample_width
        if sample_count <= 0:
            continue

        if start_sample < previous_end:
            overlap_detected = True
            skip_samples = min(previous_end - start_sample, sample_count)
            if skip_samples >= sample_count:
                continue
            payload = payload[skip_samples * sample_width :]
            start_sample = previous_end
            sample_count -= skip_samples

        resolved.append((start_sample, payload))
        previous_end = start_sample + sample_count

    return (resolved, overlap_detected)


def _render_channel_from_clip_refs(
    refs: list[ClipWaveBlockRefTD],
    block_samples: dict[int, bytes],
    sample_width: int,
    project_sample_rate: float,
) -> tuple[bytes, bool, bool]:
    fragments: list[tuple[int, bytes]] = []
    unsupported_stretch = False

    for item in refs:
        block_id = _safe_int(item.get("blockid"))
        block_start = _safe_int(item.get("block_start"))
        if block_id is None or block_start is None:
            continue

        stretch_ratio = _safe_float(item.get("clip_stretch_ratio"))
        if stretch_ratio is not None and stretch_ratio > 0.0 and abs(stretch_ratio - 1.0) > 1e-9:
            unsupported_stretch = True
            continue

        payload = block_samples.get(block_id)
        if payload is None:
            raise ValueError(f"Clip references missing blockid in sampleblocks: blockid={block_id}")
        if len(payload) % sample_width != 0:
            raise ValueError(
                f"Block payload byte length is not divisible by sample width: blockid={block_id}, "
                f"bytes={len(payload)}, sample_width={sample_width}"
            )

        block_sample_count = len(payload) // sample_width
        block_end = block_start + block_sample_count

        trim_left_seconds = _safe_float(item.get("clip_trim_left")) or 0.0
        trim_right_seconds = _safe_float(item.get("clip_trim_right")) or 0.0
        clip_offset_seconds = _safe_float(item.get("clip_offset")) or 0.0
        clip_numsamples = _safe_int(item.get("clip_numsamples"))

        trim_left_samples = max(int(round(max(trim_left_seconds, 0.0) * project_sample_rate)), 0)
        trim_right_samples = max(int(round(max(trim_right_seconds, 0.0) * project_sample_rate)), 0)
        # Audacity's waveclip `offset` is sequence start time, not play start time.
        # Play start is quantized from (offset + trimLeft).
        clip_play_start_samples = int(
            round((clip_offset_seconds + max(trim_left_seconds, 0.0)) * project_sample_rate)
        )

        visible_start = trim_left_samples
        visible_end: int | None = None
        if clip_numsamples is not None and clip_numsamples >= 0:
            visible_end = clip_numsamples - trim_right_samples
            if visible_end < 0:
                visible_end = 0
            if visible_start > visible_end:
                visible_start = visible_end

        include_start = max(block_start, visible_start)
        include_end = block_end if visible_end is None else min(block_end, visible_end)
        if include_end <= include_start:
            continue

        source_from = (include_start - block_start) * sample_width
        source_to = (include_end - block_start) * sample_width
        timeline_start = clip_play_start_samples + (include_start - visible_start)
        if timeline_start < 0:
            available = include_end - include_start
            skip_samples = min(-timeline_start, available)
            if skip_samples >= available:
                continue
            source_from += skip_samples * sample_width
            timeline_start += skip_samples
        if source_from >= source_to:
            continue
        fragments.append((timeline_start, payload[source_from:source_to]))

    resolved_fragments, overlap_detected = _apply_clip_overlap_precedence(fragments, sample_width)
    stream, _ = _render_timeline_fragments(resolved_fragments, sample_width)
    return (stream, overlap_detected, unsupported_stretch)


def export_audio_output(
    aup3_path: Path,
    audio_output_path: Path,
    project_parsed: ProjectParsedTD | None,
) -> AudioOutputResultTD:
    with sqlite3.connect(str(aup3_path)) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT blockid, sampleformat, samples FROM sampleblocks ORDER BY blockid")
        rows = cursor.fetchall()

    if not rows:
        raise ValueError("No sampleblocks found to export audio.")

    sampleformat_values = {_safe_int(row[1]) for row in rows}
    if len(sampleformat_values) != 1:
        values = sorted(value for value in sampleformat_values if value is not None)
        raise ValueError(f"Expected one sampleformat, found: {values}")

    sampleformat = next(iter(sampleformat_values)) or 0
    sample_width = sampleformat >> 16
    encoding_id = sampleformat & 0xFFFF
    if sample_width not in (1, 2, 3, 4):
        raise ValueError(f"Unsupported sample width from sampleformat={sampleformat}.")
    if encoding_id == 1:
        wav_format_code = 1
    elif encoding_id in (3, 15) and sample_width == 4:
        wav_format_code = 3
    elif encoding_id in (3, 15):
        raise ValueError(
            f"Unsupported float sample width from sampleformat={sampleformat}. Expected 4-byte float."
        )
    else:
        raise ValueError(
            f"Unsupported sampleformat encoding_id={encoding_id} from sampleformat={sampleformat}."
        )

    block_samples: dict[int, bytes] = {}
    blockid_order: list[int] = []
    for blockid, _, samples in rows:
        blockid_int = _safe_int(blockid)
        if blockid_int is None:
            continue
        block_samples[blockid_int] = bytes(samples or b"")
        blockid_order.append(blockid_int)

    channel_block_refs = _extract_channel_block_refs(project_parsed)
    clip_block_refs = _extract_clip_block_refs(project_parsed)
    track_sample_rate_raw = _resolve_track_sample_rate(project_parsed)
    project_sample_rate_raw = _resolve_project_sample_rate(project_parsed)
    if track_sample_rate_raw is not None and track_sample_rate_raw > 0:
        resolved_sample_rate = int(round(track_sample_rate_raw))
    elif project_sample_rate_raw is not None and project_sample_rate_raw > 0:
        resolved_sample_rate = int(round(project_sample_rate_raw))
    else:
        raise ValueError(
            "sample rate metadata is unavailable in wavetrack.rate and project sample_rate."
        )
    clip_timeline_sample_rate = (
        track_sample_rate_raw
        if track_sample_rate_raw is not None and track_sample_rate_raw > 0
        else (
            project_sample_rate_raw
            if project_sample_rate_raw is not None and project_sample_rate_raw > 0
            else float(resolved_sample_rate)
        )
    )
    used_project_rate_for_clip_alignment = (
        (track_sample_rate_raw is None or track_sample_rate_raw <= 0)
        and project_sample_rate_raw is not None
        and project_sample_rate_raw > 0
    )

    sorted_channels = sorted(set(channel_block_refs.keys()) | set(clip_block_refs.keys()))
    channel_track_names = _extract_channel_track_names(project_parsed)
    channel_streams: list[tuple[int, bytes]] = []
    overlap_channels: list[int] = []
    used_channel_timeline_renderer = False
    used_clip_timeline_renderer = False
    clip_channels_with_stretch: list[int] = []

    for channel in sorted_channels:
        rendered = False

        clip_refs = clip_block_refs.get(channel)
        if clip_refs:
            stream, overlap_detected, unsupported_stretch = _render_channel_from_clip_refs(
                clip_refs,
                block_samples,
                sample_width,
                clip_timeline_sample_rate,
            )
            if unsupported_stretch:
                clip_channels_with_stretch.append(channel)
            if stream:
                rendered = True
                used_clip_timeline_renderer = True
                channel_streams.append((channel, stream))
                if overlap_detected:
                    overlap_channels.append(channel)

        if not rendered and channel in channel_block_refs:
            used_channel_timeline_renderer = True
            stream, overlap_detected = _render_channel_timeline(
                channel_block_refs[channel],
                block_samples,
                sample_width,
            )
            if stream:
                channel_streams.append((channel, stream))
            if overlap_detected:
                overlap_channels.append(channel)

    if clip_channels_with_stretch:
        channels = sorted(set(clip_channels_with_stretch))
        raise ValueError(
            "Exact restoration is not supported for non-unity clip stretch ratio "
            f"in channels={channels}."
        )

    sampleformat_info = _sampleformat_to_description(sampleformat)

    if len(channel_streams) >= 2:
        output_dir, normalized = _resolve_multichannel_output_dir(audio_output_path)
        output_dir.mkdir(parents=True, exist_ok=True)
        files: list[AudioOutputFileTD] = []
        total_written = 0
        seen_names: dict[str, int] = {}
        for channel, stream in channel_streams:
            file_path = output_dir / _make_output_filename(
                channel,
                channel_track_names,
                seen_names,
            )
            written = _write_wav_file(
                file_path,
                stream,
                1,
                sample_width,
                wav_format_code,
                resolved_sample_rate,
            )
            total_written += written
            files.append(
                {
                    "channel": channel,
                    "audio_path": str(file_path),
                    "written_audio_bytes": written,
                }
            )

        return {
            "mode": "multi_channel_folder",
            "requested_output_path": str(audio_output_path),
            "output_path": str(output_dir),
            "path_was_normalized": normalized,
            "channel_count": len(channel_streams),
            "files": files,
            "sample_rate": resolved_sample_rate,
            "sample_width_bytes": sample_width,
            "wav_format_code": wav_format_code,
            "sampleformat": sampleformat_info,
            "total_written_audio_bytes": total_written,
            "note": (
                "Multi-channel project exported as one mono WAV per channel using timeline placement."
                if not normalized
                else (
                    "Multi-channel project exported as one mono WAV per channel using timeline placement. "
                    f"Requested path was normalized to directory: {output_dir}"
                )
            )
            + (
                ""
                if not used_clip_timeline_renderer
                else " Clip metadata (offset/trim) was applied where available."
            )
            + (
                ""
                if not used_project_rate_for_clip_alignment
                else " wavetrack.rate metadata was unavailable; used project sample_rate for clip alignment."
            )
            + (
                ""
                if not overlap_channels
                else (
                    " Overlap detected in channels="
                    f"{overlap_channels}; overlapping regions were resolved with deterministic clip precedence."
                )
            ),
        }

    # Single channel output mode.
    if len(channel_streams) == 1:
        single_channel = channel_streams[0][0]
        mono_payload = channel_streams[0][1]
        note = "Single-channel timeline WAV export."
        if used_clip_timeline_renderer:
            note += " Clip metadata (offset/trim) was applied where available."
        if used_project_rate_for_clip_alignment:
            note += " wavetrack.rate metadata was unavailable; used project sample_rate for clip alignment."
        if overlap_channels:
            note += (
                " Overlap detected in channels="
                f"{overlap_channels}; overlapping regions were resolved with deterministic clip precedence."
            )
    else:
        mono_payload = b"".join(block_samples.get(blockid, b"") for blockid in blockid_order)
        single_channel = 0
        note = (
            "Single-channel fallback WAV export by blockid order because channel timeline refs were unavailable."
            if not (used_channel_timeline_renderer or used_clip_timeline_renderer)
            else "Single-channel fallback WAV export by blockid order."
        )

    default_output_file_name = _make_output_filename(
        single_channel,
        channel_track_names,
        {},
    )
    output_base = _extract_original_audio_output_base(project_parsed)
    output_file_name = f"{output_base}.wav" if output_base is not None else default_output_file_name
    output_file = _resolve_single_channel_output_file(audio_output_path, output_file_name)

    written = _write_wav_file(
        output_file,
        mono_payload,
        1,
        sample_width,
        wav_format_code,
        resolved_sample_rate,
    )
    return {
        "mode": "single_file",
        "requested_output_path": str(audio_output_path),
        "output_path": str(output_file),
        "path_was_normalized": output_file != audio_output_path,
        "channel_count": 1,
        "files": [
            {
                "channel": 0,
                "audio_path": str(output_file),
                "written_audio_bytes": written,
            }
        ],
        "sample_rate": resolved_sample_rate,
        "sample_width_bytes": sample_width,
        "wav_format_code": wav_format_code,
        "sampleformat": sampleformat_info,
        "total_written_audio_bytes": written,
        "note": note,
    }
