from __future__ import annotations

from pathlib import Path
from typing import Literal, Protocol, cast, overload

from .exports import export_audio_output as _export_audio_output_py
from .types import (
    AudioBlocksInfoTD,
    AudioOutputResultTD,
    AudioSummaryTD,
    ClipSummaryTD,
    DiagnosticsTD,
    ExportsTD,
    FullParseResultTD,
    InspectCoreResultTD,
    OriginalAudioNameSourceLiteral,
    ProfileLiteral,
    ProjectMetadataTD,
    ProjectParsedTD,
    ProjectPayloadTD,
    RawEssentialInspectResultTD,
    RawEssentialWavTD,
    RawFullInspectResultTD,
    RawWaveClipPreviewTD,
    RawWaveTrackTD,
    SampleFormatInfoTD,
    TimelineSummaryTD,
    TrackSummaryTD,
)

_AUDIO_FILE_EXTENSIONS = (
    ".wav",
    ".mp3",
    ".flac",
    ".aac",
    ".m4a",
    ".ogg",
    ".aif",
    ".aiff",
    ".wma",
    ".opus",
)


class _CoreInspectCallable(Protocol):
    def __call__(self, path: str, *, profile: ProfileLiteral = "full") -> dict[str, object]: ...


class _CoreParseCallable(Protocol):
    def __call__(
        self,
        path: str,
        **kwargs: object,
    ) -> dict[str, object]: ...


class _CoreExportAudioCallable(Protocol):
    def __call__(
        self,
        aup3_path: str,
        audio_output_path: str,
        *,
        project_parsed: dict[str, object] | None = None,
    ) -> dict[str, object]: ...


try:
    from . import _core as _core_module
except ImportError as error:  # pragma: no cover - depends on local build state
    _IMPORT_ERROR = error
    _inspect_core_fn: _CoreInspectCallable | None = None
    _parse_core_fn: _CoreParseCallable | None = None
    _export_audio_output_core_fn: _CoreExportAudioCallable | None = None
else:
    _IMPORT_ERROR = None
    _inspect_core_fn = cast(_CoreInspectCallable | None, getattr(_core_module, "inspect_core", None))
    _parse_core_fn = cast(_CoreParseCallable | None, getattr(_core_module, "parse_core", None))
    _export_audio_output_core_fn = cast(
        _CoreExportAudioCallable | None,
        getattr(_core_module, "export_audio_output_core", None),
    )


def _require_core() -> _CoreInspectCallable:
    if _inspect_core_fn is None:
        raise RuntimeError(
            "Rust extension module is not available. Build/install the wheel with maturin first."
        ) from _IMPORT_ERROR
    return _inspect_core_fn


def _safe_int(value: object) -> int | None:
    try:
        if value is None:
            return None
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        if isinstance(value, float):
            if not value.is_integer():
                return None
            return int(value)
        if isinstance(value, str):
            stripped = value.strip()
            if not stripped:
                return None
            return int(stripped)
        return int(value)
    except Exception:
        return None


def _safe_float(value: object) -> float | None:
    try:
        if value is None:
            return None
        if isinstance(value, bool):
            return float(int(value))
        if isinstance(value, (int, float)):
            return float(value)
        if isinstance(value, str):
            stripped = value.strip()
            if not stripped:
                return None
            return float(stripped)
        return float(value)
    except Exception:
        return None


def _safe_str(value: object) -> str | None:
    if not isinstance(value, str):
        return None
    stripped = value.strip()
    if not stripped:
        return None
    return stripped


def _has_audio_extension(name: str) -> bool:
    lowered = name.lower()
    return any(lowered.endswith(ext) for ext in _AUDIO_FILE_EXTENSIONS)


def _extract_original_audio_file_name(
    tracks: list[RawWaveTrackTD],
    clips: list[RawWaveClipPreviewTD],
) -> tuple[str | None, OriginalAudioNameSourceLiteral]:
    clip_candidates = [name for item in clips if (name := _safe_str(item.get("name")))]
    track_candidates = [name for item in tracks if (name := _safe_str(item.get("name")))]

    for name in clip_candidates + track_candidates:
        if _has_audio_extension(name):
            return (name, "embedded_name")

    if track_candidates:
        return (track_candidates[0], "track_name")
    if clip_candidates:
        return (clip_candidates[0], "track_name")
    return (None, "unavailable")


def _as_project_payload(value: object) -> ProjectPayloadTD | None:
    if isinstance(value, dict):
        return cast(ProjectPayloadTD, value)
    return None


def _as_audio_blocks(value: object) -> AudioBlocksInfoTD | None:
    if isinstance(value, dict):
        return cast(AudioBlocksInfoTD, value)
    return None


def _extract_project_parsed(result: RawFullInspectResultTD) -> ProjectParsedTD | None:
    payload = _as_project_payload(result.get("project_payload"))
    if payload is None:
        return None
    parsed = payload.get("parsed")
    if isinstance(parsed, dict):
        return cast(ProjectParsedTD, parsed)
    return None


def _build_raw_wav_from_full(result: RawFullInspectResultTD) -> RawEssentialWavTD:
    project_payload = _as_project_payload(result.get("project_payload")) or {}
    project_parsed = project_payload.get("parsed")
    if not isinstance(project_parsed, dict):
        project_parsed = cast(ProjectParsedTD, {})

    audio_blocks = _as_audio_blocks(result.get("audio_blocks")) or {}
    tracks = cast(list[RawWaveTrackTD], project_parsed.get("wave_tracks") or [])
    clips = cast(list[RawWaveClipPreviewTD], project_parsed.get("wave_clips_preview") or [])

    channels = sorted(
        {
            channel
            for item in tracks
            if (channel := _safe_int(item.get("channel"))) is not None
        }
    )
    sample_format = (
        cast(SampleFormatInfoTD, audio_blocks["sampleformat"])
        if isinstance(audio_blocks.get("sampleformat"), dict)
        else None
    )

    return {
        "sample_rate": project_parsed.get("sample_rate"),
        "duration_seconds": cast(float | None, audio_blocks.get("duration_seconds")),
        "total_samples": cast(int | None, audio_blocks.get("total_samples")),
        "total_sample_bytes": cast(int | None, audio_blocks.get("total_sample_bytes")),
        "channels": channels,
        "channel_count": len(channels),
        "track_count": cast(int | None, project_parsed.get("wave_track_count")),
        "clip_count": cast(int | None, project_parsed.get("wave_clip_count")),
        "block_count": cast(int | None, audio_blocks.get("count")),
        "sampleformat": sample_format,
        "sample_format": sample_format,
        "tracks": tracks,
        "clips_preview": clips,
        "timeline": {
            "used_block_ids": cast(list[int], project_parsed.get("used_block_ids") or []),
            "missing_block_ids_in_sampleblocks": cast(
                list[int], audio_blocks.get("missing_timeline_block_ids_in_sampleblocks") or []
            ),
            "unused_block_ids_in_sampleblocks": cast(
                list[int], audio_blocks.get("unused_sampleblocks_not_referenced_by_timeline") or []
            ),
        },
        "exactness_notes": cast(list[str], audio_blocks.get("exactness_notes") or []),
    }


def _normalize_project(
    *,
    filepath: Path,
    raw_file: str | None,
    raw_file_info: object,
    raw_size_bytes: object,
    tracks: list[RawWaveTrackTD],
    clips: list[RawWaveClipPreviewTD],
) -> ProjectMetadataTD:
    file_info_map = raw_file_info if isinstance(raw_file_info, dict) else {}
    fallback_path = raw_file or str(filepath)
    project_path = _safe_str(file_info_map.get("path")) if isinstance(file_info_map, dict) else None
    project_path = project_path or fallback_path

    project_name = _safe_str(file_info_map.get("name")) if isinstance(file_info_map, dict) else None
    if project_name is None:
        project_name = Path(project_path).name or None

    project_stem = _safe_str(file_info_map.get("stem")) if isinstance(file_info_map, dict) else None
    if project_stem is None and project_name is not None:
        project_stem = Path(project_name).stem

    project_extension = (
        _safe_str(file_info_map.get("extension")) if isinstance(file_info_map, dict) else None
    ) or filepath.suffix.lstrip(".").lower()

    original_name, source = _extract_original_audio_file_name(tracks, clips)

    return {
        "project_path": project_path,
        "project_file_name": project_name,
        "project_file_stem": project_stem,
        "project_extension": project_extension,
        "project_size_bytes": _safe_int(raw_size_bytes),
        "original_audio_file_name": original_name,
        "original_audio_file_name_source": source,
    }


def _normalize_tracks(raw_tracks: list[RawWaveTrackTD]) -> list[TrackSummaryTD]:
    tracks: list[TrackSummaryTD] = []
    for item in raw_tracks:
        tracks.append(
            {
                "channel_index": _safe_int(item.get("channel")),
                "name": _safe_str(item.get("name")),
                "clip_count": _safe_int(item.get("clip_count")),
                "sample_rate_hz": _safe_float(item.get("rate")),
                "mute": cast(bool | None, item.get("mute")),
                "solo": cast(bool | None, item.get("solo")),
                "gain": _safe_float(item.get("gain")),
                "pan": _safe_float(item.get("pan")),
                "sampleformat_raw": _safe_int(item.get("sampleformat")),
            }
        )
    return tracks


def _normalize_clips(raw_clips: list[RawWaveClipPreviewTD]) -> list[ClipSummaryTD]:
    clips: list[ClipSummaryTD] = []
    for item in raw_clips:
        clips.append(
            {
                "name": _safe_str(item.get("name")),
                "offset_seconds": _safe_float(item.get("offset")),
                "trim_left_seconds": _safe_float(item.get("trim_left"))
                if item.get("trim_left") is not None
                else _safe_float(item.get("trimLeft")),
                "trim_right_seconds": _safe_float(item.get("trim_right"))
                if item.get("trim_right") is not None
                else _safe_float(item.get("trimRight")),
                "raw_audio_tempo": _safe_float(item.get("raw_audio_tempo"))
                if item.get("raw_audio_tempo") is not None
                else _safe_float(item.get("rawAudioTempo")),
                "stretch_ratio": _safe_float(item.get("clip_stretch_ratio"))
                if item.get("clip_stretch_ratio") is not None
                else _safe_float(item.get("clipStretchRatio")),
                "sample_count": _safe_int(item.get("numsamples")),
                "max_block_sample_count": _safe_int(item.get("maxsamples")),
            }
        )
    return clips


def _normalize_audio(raw_wav: RawEssentialWavTD) -> AudioSummaryTD:
    raw_tracks = cast(list[RawWaveTrackTD], raw_wav.get("tracks") or [])
    raw_clips = cast(list[RawWaveClipPreviewTD], raw_wav.get("clips_preview") or [])
    timeline = cast(dict[str, object], raw_wav.get("timeline") or {})
    sample_format = raw_wav.get("sample_format")
    if not isinstance(sample_format, dict):
        sample_format = raw_wav.get("sampleformat")

    timeline_summary: TimelineSummaryTD = {
        "used_block_ids": cast(list[int], timeline.get("used_block_ids") or []),
        "missing_block_ids": cast(list[int], timeline.get("missing_block_ids_in_sampleblocks") or []),
        "unused_block_ids": cast(list[int], timeline.get("unused_block_ids_in_sampleblocks") or []),
    }

    return {
        "sample_rate_hz": raw_wav.get("sample_rate"),
        "duration_seconds": cast(float | None, raw_wav.get("duration_seconds")),
        "total_samples": cast(int | None, raw_wav.get("total_samples")),
        "total_sample_bytes": cast(int | None, raw_wav.get("total_sample_bytes")),
        "channel_indices": cast(list[int], raw_wav.get("channels") or []),
        "channel_count": _safe_int(raw_wav.get("channel_count")) or 0,
        "track_count": cast(int | None, raw_wav.get("track_count")),
        "clip_count": cast(int | None, raw_wav.get("clip_count")),
        "block_count": cast(int | None, raw_wav.get("block_count")),
        "sample_format": cast(SampleFormatInfoTD | None, sample_format if isinstance(sample_format, dict) else None),
        "tracks": _normalize_tracks(raw_tracks),
        "clips": _normalize_clips(raw_clips),
        "timeline": timeline_summary,
        "exactness_notes": [str(item) for item in cast(list[object], raw_wav.get("exactness_notes") or [])],
    }


def _normalize_full_result(filepath: Path, raw: RawFullInspectResultTD) -> FullParseResultTD:
    raw_wav = _build_raw_wav_from_full(raw)
    tracks = cast(list[RawWaveTrackTD], raw_wav.get("tracks") or [])
    clips = cast(list[RawWaveClipPreviewTD], raw_wav.get("clips_preview") or [])

    diagnostics: DiagnosticsTD = {
        "sqlite": cast(dict[str, object], raw.get("sqlite") or {}),
        "project_payload": cast(ProjectPayloadTD, raw.get("project_payload") or {}),
        "audio_blocks": cast(AudioBlocksInfoTD, raw.get("audio_blocks") or {}),
    }
    result: FullParseResultTD = {
        "schema_version": "2",
        "project": _normalize_project(
            filepath=filepath,
            raw_file=cast(str | None, raw.get("file")),
            raw_file_info=raw.get("file_info"),
            raw_size_bytes=raw.get("size_bytes"),
            tracks=tracks,
            clips=clips,
        ),
        "audio": _normalize_audio(raw_wav),
        "diagnostics": diagnostics,
    }
    if isinstance(raw.get("exports"), dict):
        result["exports"] = cast(ExportsTD, raw["exports"])
    return result


def _export_audio_output(
    *,
    filepath: Path,
    audio_output_path: Path,
    project_parsed: ProjectParsedTD | None,
) -> AudioOutputResultTD:
    if _export_audio_output_core_fn is not None:
        payload = cast(
            dict[str, object],
            _export_audio_output_core_fn(
                str(filepath),
                str(audio_output_path),
                project_parsed=cast(dict[str, object] | None, project_parsed),
            ),
        )
        return cast(AudioOutputResultTD, payload)

    return _export_audio_output_py(
        filepath,
        audio_output_path,
        project_parsed,
    )


class AUPParser:
    """Audacity `.aup3` parser with a developer-friendly return schema.

    `inspect_core()` returns low-level raw output from the Rust core.
    `parse()` returns normalized schema `v2` focused on DX and predictable snake_case fields.
    """

    def __init__(self, filepath: str | Path) -> None:
        self.filepath = Path(filepath)
        if not self.filepath.exists():
            raise FileNotFoundError(f"File not found: {self.filepath}")
        if self.filepath.suffix.lower() != ".aup3":
            raise ValueError(f"Expected .aup3 file, got: {self.filepath.suffix}")

    @overload
    def inspect_core(self, *, profile: Literal["full"] = "full") -> RawFullInspectResultTD: ...

    @overload
    def inspect_core(self, *, profile: Literal["essential"]) -> RawEssentialInspectResultTD: ...

    def inspect_core(self, *, profile: ProfileLiteral = "full") -> InspectCoreResultTD:
        core = _require_core()
        raw = core(str(self.filepath), profile=profile)
        if profile == "full":
            return cast(RawFullInspectResultTD, raw)
        return cast(RawEssentialInspectResultTD, raw)

    def parse(
        self,
        *,
        audio_output_path: str | Path | None = None,
    ) -> FullParseResultTD:
        """Parse project and return normalized schema `v2` (always full shape).

        Export sample rate uses metadata: `wavetrack.rate` first, then project `sample_rate`.
        Multi-channel export file names always use track name when available.
        Duplicate track names are disambiguated with `_1`, `_2`, ...
        """
        output_path_str = None if audio_output_path is None else str(Path(audio_output_path))

        if _parse_core_fn is not None:
            try:
                payload = cast(
                    dict[str, object],
                    _parse_core_fn(
                        str(self.filepath),
                        profile="full",
                        audio_output_path=output_path_str,
                    ),
                )
            except TypeError:
                payload = cast(
                    dict[str, object],
                    _parse_core_fn(
                        str(self.filepath),
                        audio_output_path=output_path_str,
                    ),
                )
            return _normalize_full_result(self.filepath, cast(RawFullInspectResultTD, payload))

        # Compatibility path for older extension builds without parse_core.
        raw_full = cast(RawFullInspectResultTD, self.inspect_core(profile="full"))
        result = _normalize_full_result(self.filepath, raw_full)

        if audio_output_path is not None:
            project_parsed = _extract_project_parsed(raw_full)
            exports: ExportsTD = {
                "audio_output": _export_audio_output(
                    filepath=self.filepath,
                    audio_output_path=Path(audio_output_path),
                    project_parsed=project_parsed,
                )
            }
            result["exports"] = exports

        return cast(FullParseResultTD, result)
