from __future__ import annotations

from typing import Literal, TypeAlias, TypedDict

ProfileLiteral: TypeAlias = Literal["essential", "full"]
OriginalAudioNameSourceLiteral: TypeAlias = Literal["embedded_name", "track_name", "unavailable"]


class SampleFormatInfoTD(TypedDict):
    raw: int
    sample_width_bytes: int
    encoding_id: int


class AudioOutputFileTD(TypedDict):
    channel: int
    audio_path: str
    written_audio_bytes: int


class AudioOutputResultTD(TypedDict):
    mode: Literal["single_file", "multi_channel_folder"]
    requested_output_path: str
    output_path: str
    path_was_normalized: bool
    channel_count: int
    files: list[AudioOutputFileTD]
    sample_rate: int
    sample_width_bytes: int
    wav_format_code: int
    sampleformat: SampleFormatInfoTD
    total_written_audio_bytes: int
    note: str


class ExportsTD(TypedDict, total=False):
    audio_output: AudioOutputResultTD


# -----------------------------
# Raw (inspect_core) structures
# -----------------------------
class RawWaveTrackTD(TypedDict):
    name: str | None
    channel: int | None
    sampleformat: int | None
    rate: float | int | str | None
    mute: bool | None
    solo: bool | None
    gain: float | None
    pan: float | None
    clip_count: int | None


class RawWaveClipPreviewTD(TypedDict):
    name: str | None
    offset: float | None
    trimLeft: float | None
    trimRight: float | None
    rawAudioTempo: float | None
    clipStretchRatio: float | None
    trim_left: float | None
    trim_right: float | None
    raw_audio_tempo: float | None
    clip_stretch_ratio: float | None
    numsamples: int | None
    maxsamples: int | None


class RawWaveTimelineTD(TypedDict):
    used_block_ids: list[int]
    missing_block_ids_in_sampleblocks: list[int]
    unused_block_ids_in_sampleblocks: list[int]


class RawEssentialWavTD(TypedDict):
    sample_rate: float | int | str | None
    duration_seconds: float | None
    total_samples: int | None
    total_sample_bytes: int | None
    channels: list[int]
    channel_count: int
    track_count: int | None
    clip_count: int | None
    block_count: int | None
    sampleformat: SampleFormatInfoTD | None
    sample_format: SampleFormatInfoTD | None
    tracks: list[RawWaveTrackTD]
    clips_preview: list[RawWaveClipPreviewTD]
    timeline: RawWaveTimelineTD
    exactness_notes: list[str]


class FileInfoTD(TypedDict):
    path: str
    name: str | None
    stem: str | None
    extension: str


class ChannelWaveBlockRefTD(TypedDict):
    channel: int | float | str | None
    track_name: str | None
    start: int | float | str | None
    blockid: int | float | str | None


class ClipWaveBlockRefTD(TypedDict):
    channel: int | float | str | None
    track_name: str | None
    clip_name: str | None
    clip_offset: float | int | str | None
    clip_trim_left: float | int | str | None
    clip_trim_right: float | int | str | None
    clip_stretch_ratio: float | int | str | None
    clip_numsamples: int | float | str | None
    block_start: int | float | str | None
    blockid: int | float | str | None


class ProjectParsedTD(TypedDict, total=False):
    sample_rate: float | int | str | None
    wave_tracks: list[RawWaveTrackTD]
    wave_clips_preview: list[RawWaveClipPreviewTD]
    used_block_ids: list[int]
    channel_wave_blocks: list[ChannelWaveBlockRefTD]
    clip_wave_blocks: list[ClipWaveBlockRefTD]


class ProjectPayloadTD(TypedDict, total=False):
    found: bool
    source: str | None
    decode_strategy: str
    xml_preview: str | None
    parsed: ProjectParsedTD | None
    error: str
    binary_parser_errors: list[str]


class AudioBlocksInfoTD(TypedDict, total=False):
    available: bool
    count: int
    total_sample_bytes: int
    total_summary256_bytes: int
    total_summary64k_bytes: int
    total_samples: int | None
    sample_rate: float | int | None
    channel_count: int | None
    duration_seconds: float | None
    sampleformat: SampleFormatInfoTD | None
    sampleformat_is_uniform: bool
    exactness_notes: list[str]
    missing_timeline_block_ids_in_sampleblocks: list[int]
    unused_sampleblocks_not_referenced_by_timeline: list[int]


class RawEssentialInspectResultTD(TypedDict, total=False):
    file: str | None
    file_info: FileInfoTD
    size_bytes: int | None
    wav: RawEssentialWavTD
    exports: ExportsTD


class RawFullInspectResultTD(TypedDict, total=False):
    file: str
    file_info: FileInfoTD
    size_bytes: int
    sqlite: dict[str, object]
    project_payload: ProjectPayloadTD
    audio_blocks: AudioBlocksInfoTD
    exports: ExportsTD


InspectCoreResultTD: TypeAlias = RawEssentialInspectResultTD | RawFullInspectResultTD


# ---------------------------
# Friendly (parse) structures
# ---------------------------
class ProjectMetadataTD(TypedDict):
    project_path: str
    project_file_name: str | None
    project_file_stem: str | None
    project_extension: str
    project_size_bytes: int | None
    original_audio_file_name: str | None
    original_audio_file_name_source: OriginalAudioNameSourceLiteral


class TrackSummaryTD(TypedDict):
    channel_index: int | None
    name: str | None
    clip_count: int | None
    sample_rate_hz: float | None
    mute: bool | None
    solo: bool | None
    gain: float | None
    pan: float | None
    sampleformat_raw: int | None


class ClipSummaryTD(TypedDict):
    name: str | None
    offset_seconds: float | None
    trim_left_seconds: float | None
    trim_right_seconds: float | None
    raw_audio_tempo: float | None
    stretch_ratio: float | None
    sample_count: int | None
    max_block_sample_count: int | None


class TimelineSummaryTD(TypedDict):
    used_block_ids: list[int]
    missing_block_ids: list[int]
    unused_block_ids: list[int]


class AudioSummaryTD(TypedDict):
    sample_rate_hz: float | int | str | None
    duration_seconds: float | None
    total_samples: int | None
    total_sample_bytes: int | None
    channel_indices: list[int]
    channel_count: int
    track_count: int | None
    clip_count: int | None
    block_count: int | None
    sample_format: SampleFormatInfoTD | None
    tracks: list[TrackSummaryTD]
    clips: list[ClipSummaryTD]
    timeline: TimelineSummaryTD
    exactness_notes: list[str]


class BaseParseResultTD(TypedDict, total=False):
    schema_version: Literal["2"]
    project: ProjectMetadataTD
    audio: AudioSummaryTD
    exports: ExportsTD


class DiagnosticsTD(TypedDict):
    sqlite: dict[str, object]
    project_payload: ProjectPayloadTD
    audio_blocks: AudioBlocksInfoTD


class EssentialParseResultTD(BaseParseResultTD):
    pass


class FullParseResultTD(BaseParseResultTD):
    diagnostics: DiagnosticsTD


ParseResultTD: TypeAlias = FullParseResultTD
