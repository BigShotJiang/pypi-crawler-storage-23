use std::collections::BTreeSet;

use serde_json::{json, Map, Value};

use crate::binary_xml::{ParsedBinaryTree, XmlNode};
use crate::types::{safe_int, MAX_TEXT_PREVIEW, MAX_TRACK_NAME_PREVIEW};

fn find_child_nodes<'a>(node: &'a XmlNode, tag: &str) -> Vec<&'a XmlNode> {
    node.children
        .iter()
        .filter(|child| child.tag == tag)
        .collect::<Vec<_>>()
}

fn find_dtd_url(doc_text: &str) -> Option<String> {
    for part in doc_text
        .split(|ch: char| ch.is_whitespace() || ch == '"' || ch == '\'' || ch == '<' || ch == '>')
    {
        if (part.starts_with("http://") || part.starts_with("https://")) && part.ends_with(".dtd") {
            return Some(part.to_string());
        }
    }
    None
}

fn track_waveblocks(node: &XmlNode, channel: &Value, track_name: &Value, out: &mut Vec<Value>) {
    if node.tag == "waveblock" {
        let start = node.attrs.get("start").cloned().unwrap_or(Value::Null);
        let blockid = node.attrs.get("blockid").cloned().unwrap_or(Value::Null);
        out.push(json!({
            "channel": channel,
            "track_name": track_name,
            "start": start,
            "blockid": blockid,
        }));
    }
    for child in &node.children {
        track_waveblocks(child, channel, track_name, out);
    }
}

#[allow(clippy::too_many_arguments)]
fn clip_waveblocks(
    node: &XmlNode,
    channel: &Value,
    track_name: &Value,
    clip_name: &Value,
    clip_offset: &Value,
    clip_trim_left: &Value,
    clip_trim_right: &Value,
    clip_stretch_ratio: &Value,
    clip_numsamples: &Value,
    out: &mut Vec<Value>,
) {
    if node.tag == "waveblock" {
        let block_start = node.attrs.get("start").cloned().unwrap_or(Value::Null);
        let blockid = node.attrs.get("blockid").cloned().unwrap_or(Value::Null);
        out.push(json!({
            "channel": channel,
            "track_name": track_name,
            "clip_name": clip_name,
            "clip_offset": clip_offset,
            "clip_trim_left": clip_trim_left,
            "clip_trim_right": clip_trim_right,
            "clip_stretch_ratio": clip_stretch_ratio,
            "clip_numsamples": clip_numsamples,
            "block_start": block_start,
            "blockid": blockid,
        }));
    }
    for child in &node.children {
        clip_waveblocks(
            child,
            channel,
            track_name,
            clip_name,
            clip_offset,
            clip_trim_left,
            clip_trim_right,
            clip_stretch_ratio,
            clip_numsamples,
            out,
        );
    }
}

fn iter_nodes<'a>(node: &'a XmlNode, out: &mut Vec<&'a XmlNode>) {
    out.push(node);
    for child in &node.children {
        iter_nodes(child, out);
    }
}

pub fn collect_project_from_binary_tree(tree: ParsedBinaryTree) -> Value {
    let root = tree.root;
    let root_attrs = root.attrs.clone();
    let dictionary_tokens = tree.dictionary_tokens;
    let leading_data = tree.leading_data;
    let raw_data = tree.raw_data;

    let mut doc_strings = Vec::new();
    doc_strings.extend(raw_data.iter().cloned());
    doc_strings.extend(leading_data.iter().cloned());
    let doc_text = doc_strings.join(" ");
    let dtd_url = find_dtd_url(&doc_text);

    let mut wave_tracks: Vec<Value> = Vec::new();
    let mut wave_clips: Vec<Value> = Vec::new();
    let mut wave_blocks: Vec<Value> = Vec::new();
    let mut channel_wave_blocks: Vec<Value> = Vec::new();
    let mut clip_wave_blocks: Vec<Value> = Vec::new();
    let mut label_tracks: Vec<Value> = Vec::new();
    let mut labels: Vec<Value> = Vec::new();

    let mut nodes = Vec::new();
    iter_nodes(&root, &mut nodes);

    for node in nodes {
        let attrs = &node.attrs;
        match node.tag.as_str() {
            "wavetrack" => {
                let clip_children = find_child_nodes(node, "waveclip");
                let mut track_info = Map::new();
                track_info.insert(
                    "name".to_string(),
                    attrs.get("name").cloned().unwrap_or(Value::Null),
                );
                track_info.insert(
                    "channel".to_string(),
                    attrs.get("channel").cloned().unwrap_or(Value::Null),
                );
                track_info.insert(
                    "sampleformat".to_string(),
                    attrs.get("sampleformat").cloned().unwrap_or(Value::Null),
                );
                track_info.insert(
                    "rate".to_string(),
                    attrs.get("rate").cloned().unwrap_or(Value::Null),
                );
                track_info.insert(
                    "mute".to_string(),
                    attrs.get("mute").cloned().unwrap_or(Value::Null),
                );
                track_info.insert(
                    "solo".to_string(),
                    attrs.get("solo").cloned().unwrap_or(Value::Null),
                );
                track_info.insert(
                    "gain".to_string(),
                    attrs.get("gain").cloned().unwrap_or(Value::Null),
                );
                track_info.insert(
                    "pan".to_string(),
                    attrs.get("pan").cloned().unwrap_or(Value::Null),
                );
                track_info.insert("clip_count".to_string(), json!(clip_children.len()));
                wave_tracks.push(Value::Object(track_info));

                let channel = attrs.get("channel").cloned().unwrap_or(Value::Null);
                let track_name = attrs.get("name").cloned().unwrap_or(Value::Null);
                track_waveblocks(node, &channel, &track_name, &mut channel_wave_blocks);

                for clip in clip_children {
                    let clip_name = clip.attrs.get("name").cloned().unwrap_or(Value::Null);
                    let clip_offset = clip.attrs.get("offset").cloned().unwrap_or(Value::Null);
                    let clip_trim_left = clip.attrs.get("trimLeft").cloned().unwrap_or(Value::Null);
                    let clip_trim_right = clip.attrs.get("trimRight").cloned().unwrap_or(Value::Null);
                    let clip_stretch_ratio = clip
                        .attrs
                        .get("clipStretchRatio")
                        .cloned()
                        .unwrap_or(Value::Null);
                    let clip_numsamples = find_child_nodes(clip, "sequence")
                        .first()
                        .and_then(|sequence| sequence.attrs.get("numsamples").cloned())
                        .unwrap_or(Value::Null);
                    clip_waveblocks(
                        clip,
                        &channel,
                        &track_name,
                        &clip_name,
                        &clip_offset,
                        &clip_trim_left,
                        &clip_trim_right,
                        &clip_stretch_ratio,
                        &clip_numsamples,
                        &mut clip_wave_blocks,
                    );
                }
            }
            "waveclip" => {
                let mut clip_info = Map::new();
                for key in [
                    "name",
                    "offset",
                    "trimLeft",
                    "trimRight",
                    "rawAudioTempo",
                    "clipStretchRatio",
                ] {
                    clip_info.insert(
                        key.to_string(),
                        attrs.get(key).cloned().unwrap_or(Value::Null),
                    );
                }

                if let Some(sequence) = find_child_nodes(node, "sequence").first() {
                    clip_info.insert(
                        "numsamples".to_string(),
                        sequence
                            .attrs
                            .get("numsamples")
                            .cloned()
                            .unwrap_or(Value::Null),
                    );
                    clip_info.insert(
                        "maxsamples".to_string(),
                        sequence
                            .attrs
                            .get("maxsamples")
                            .cloned()
                            .unwrap_or(Value::Null),
                    );
                }

                wave_clips.push(Value::Object(clip_info));
            }
            "waveblock" => {
                wave_blocks.push(json!({
                    "start": attrs.get("start").cloned().unwrap_or(Value::Null),
                    "blockid": attrs.get("blockid").cloned().unwrap_or(Value::Null),
                }));
            }
            "labeltrack" => {
                let mut labels_for_track: Vec<Value> = Vec::new();
                for label in find_child_nodes(node, "label") {
                    let t = label.attrs.get("t").cloned().unwrap_or(Value::Null);
                    let t1 = label.attrs.get("t1").cloned().unwrap_or(Value::Null);
                    let duration = match (t.as_f64(), t1.as_f64()) {
                        (Some(start), Some(end)) => {
                            Some(((end - start) * 1_000_000.0).round() / 1_000_000.0)
                        }
                        _ => None,
                    };

                    let mut label_info = Map::new();
                    label_info.insert(
                        "title".to_string(),
                        label.attrs.get("title").cloned().unwrap_or(Value::Null),
                    );
                    label_info.insert("t".to_string(), t);
                    label_info.insert("t1".to_string(), t1);
                    label_info.insert(
                        "selLow".to_string(),
                        label.attrs.get("selLow").cloned().unwrap_or(Value::Null),
                    );
                    if let Some(duration) = duration {
                        label_info.insert("duration".to_string(), json!(duration));
                    }

                    let value = Value::Object(label_info);
                    labels_for_track.push(value.clone());
                    labels.push(value);
                }

                label_tracks.push(json!({
                    "name": attrs.get("name").cloned().unwrap_or(Value::Null),
                    "numlabels": attrs.get("numlabels").cloned().unwrap_or(Value::Null),
                    "labels": labels_for_track,
                }));
            }
            _ => {}
        }
    }

    let mut used_block_ids = BTreeSet::new();
    for block in &wave_blocks {
        if let Some(block_id) = block.get("blockid").and_then(safe_int) {
            used_block_ids.insert(block_id);
        }
    }

    let mut xml_preview = format!("<{}>", root.tag);
    if !doc_strings.is_empty() {
        xml_preview = format!(
            "{} {}",
            &doc_text.chars().take(MAX_TEXT_PREVIEW).collect::<String>(),
            xml_preview
        );
    }

    json!({
        "dictionary_token_count": tree.dictionary_token_count,
        "dictionary_tokens": dictionary_tokens,
        "dictionary_tokens_preview": dictionary_tokens.iter().take(MAX_TRACK_NAME_PREVIEW).cloned().collect::<Vec<_>>(),
        "doc_string_count": doc_strings.len(),
        "doc_strings": doc_strings,
        "doc_strings_preview": doc_strings.iter().take(MAX_TRACK_NAME_PREVIEW).cloned().collect::<Vec<_>>(),
        "project_format_version": root_attrs.get("version").cloned().unwrap_or(Value::Null),
        "audacity_version": root_attrs.get("audacityversion").cloned().unwrap_or(Value::Null),
        "sample_rate": root_attrs.get("rate").cloned().unwrap_or(Value::Null),
        "xml_namespace": root_attrs.get("xmlns").cloned().unwrap_or(Value::Null),
        "dtd_url": dtd_url,
        "leading_data_preview": leading_data.iter().take(MAX_TRACK_NAME_PREVIEW).cloned().collect::<Vec<_>>(),
        "raw_data_preview": raw_data.iter().take(MAX_TRACK_NAME_PREVIEW).cloned().collect::<Vec<_>>(),
        "wave_track_count": wave_tracks.len(),
        "wave_clip_count": wave_clips.len(),
        "wave_block_count": wave_blocks.len(),
        "label_track_count": label_tracks.len(),
        "label_count": labels.len(),
        "wave_tracks": wave_tracks,
        "wave_clips_preview": wave_clips.iter().take(MAX_TRACK_NAME_PREVIEW).cloned().collect::<Vec<_>>(),
        "wave_blocks_preview": wave_blocks.iter().take(MAX_TRACK_NAME_PREVIEW).cloned().collect::<Vec<_>>(),
        "channel_wave_blocks": channel_wave_blocks,
        "channel_wave_blocks_preview": channel_wave_blocks.iter().take(MAX_TRACK_NAME_PREVIEW).cloned().collect::<Vec<_>>(),
        "clip_wave_blocks": clip_wave_blocks,
        "clip_wave_blocks_preview": clip_wave_blocks.iter().take(MAX_TRACK_NAME_PREVIEW).cloned().collect::<Vec<_>>(),
        "label_tracks": label_tracks,
        "labels": labels,
        "used_block_ids": used_block_ids.into_iter().collect::<Vec<_>>(),
        "_xml_preview": xml_preview,
    })
}
