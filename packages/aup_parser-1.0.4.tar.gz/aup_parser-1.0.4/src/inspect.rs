use std::collections::{BTreeMap, BTreeSet};
use std::path::Path;

use rusqlite::{Connection, OpenFlags};
use serde_json::{json, Map, Value};

use crate::binary_xml::parse_binary_xml_project;
use crate::error::{AupError, Result};
use crate::project_extract::collect_project_from_binary_tree;
use crate::sampleblocks::{collect_sampleblocks_info, extract_channel_block_refs};
use crate::types::{safe_float, safe_int, PROJECT_LIKE_TABLES};

fn path_file_info(path: &Path) -> Value {
    let canonical_path = path
        .canonicalize()
        .ok()
        .map(|item| item.to_string_lossy().to_string())
        .unwrap_or_else(|| path.to_string_lossy().to_string());

    let extension = path
        .extension()
        .and_then(|ext| ext.to_str())
        .map(|text| text.to_ascii_lowercase())
        .unwrap_or_default();

    json!({
        "path": canonical_path,
        "name": path.file_name().and_then(|name| name.to_str()).map(|text| text.to_string()),
        "stem": path.file_stem().and_then(|stem| stem.to_str()).map(|text| text.to_string()),
        "extension": extension,
    })
}

fn enrich_clip_preview_aliases(value: &mut Value) {
    let Some(items) = value.as_array_mut() else {
        return;
    };

    for item in items {
        let Some(map) = item.as_object_mut() else {
            continue;
        };

        if let Some(trim_left) = map.get("trimLeft").cloned() {
            map.entry("trim_left".to_string()).or_insert(trim_left);
        }
        if let Some(trim_right) = map.get("trimRight").cloned() {
            map.entry("trim_right".to_string()).or_insert(trim_right);
        }
        if let Some(raw_audio_tempo) = map.get("rawAudioTempo").cloned() {
            map.entry("raw_audio_tempo".to_string())
                .or_insert(raw_audio_tempo);
        }
        if let Some(clip_stretch_ratio) = map.get("clipStretchRatio").cloned() {
            map.entry("clip_stretch_ratio".to_string())
                .or_insert(clip_stretch_ratio);
        }
    }
}

fn find_table_names(conn: &Connection) -> Result<Vec<String>> {
    let mut stmt =
        conn.prepare("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")?;
    let mut rows = stmt.query([])?;
    let mut names = Vec::new();
    while let Some(row) = rows.next()? {
        let name: String = row.get(0)?;
        names.push(name);
    }
    Ok(names)
}

fn table_row_count(conn: &Connection, table_name: &str) -> Option<i64> {
    let query = format!("SELECT COUNT(*) FROM \"{table_name}\"");
    conn.query_row(&query, [], |row| row.get::<_, i64>(0)).ok()
}

fn db_overview(conn: &Connection) -> Result<Value> {
    let tables = find_table_names(conn)?;
    let mut table_rows = Map::new();

    for table in &tables {
        table_rows.insert(table.clone(), json!(table_row_count(conn, table)));
    }

    let mut stats = Map::new();
    stats.insert("tables".to_string(), json!(tables));
    stats.insert("table_rows".to_string(), Value::Object(table_rows));

    let page_size = conn
        .query_row("PRAGMA page_size", [], |row| row.get::<_, i64>(0))
        .ok();
    let page_count = conn
        .query_row("PRAGMA page_count", [], |row| row.get::<_, i64>(0))
        .ok();
    let freelist_count = conn
        .query_row("PRAGMA freelist_count", [], |row| row.get::<_, i64>(0))
        .ok();

    stats.insert("page_size".to_string(), json!(page_size));
    stats.insert("page_count".to_string(), json!(page_count));
    stats.insert("freelist_count".to_string(), json!(freelist_count));

    if let (Some(page_size), Some(page_count)) = (page_size, page_count) {
        stats.insert(
            "db_size_bytes_from_pragma".to_string(),
            json!(page_size * page_count),
        );
    }

    if tables.iter().any(|table| table == "sampleblocks") {
        let sampleblocks = conn
            .query_row(
                "SELECT COUNT(*), COALESCE(SUM(LENGTH(samples)), 0), MIN(LENGTH(samples)), MAX(LENGTH(samples)) FROM sampleblocks",
                [],
                |row| {
                    Ok(json!({
                        "count": row.get::<_, i64>(0).ok(),
                        "total_sample_bytes": row.get::<_, i64>(1).ok(),
                        "min_block_bytes": row.get::<_, i64>(2).ok(),
                        "max_block_bytes": row.get::<_, i64>(3).ok(),
                    }))
                },
            )
            .ok();

        if let Some(sampleblocks) = sampleblocks {
            stats.insert("sampleblocks".to_string(), sampleblocks);
        }
    }

    Ok(Value::Object(stats))
}

fn extract_project_info_from_binary_xml(conn: &Connection) -> Result<Option<Value>> {
    let table_names = find_table_names(conn)?;
    let table_names_set = table_names.into_iter().collect::<BTreeSet<_>>();
    let mut parse_errors: Vec<String> = Vec::new();

    for table_name in PROJECT_LIKE_TABLES {
        if !table_names_set.contains(table_name) {
            continue;
        }

        let source_row_count = conn
            .query_row(
                &format!("SELECT COUNT(*) FROM \"{table_name}\""),
                [],
                |row| row.get::<_, i64>(0),
            )
            .ok();

        let mut stmt = conn.prepare(&format!(
            "SELECT rowid, dict, doc FROM \"{table_name}\" ORDER BY rowid ASC LIMIT 1"
        ))?;
        let mut rows = stmt.query([])?;
        let Some(row) = rows.next()? else {
            continue;
        };

        let source_rowid = row.get::<_, i64>(0).ok();
        let dict_blob = row.get::<_, Option<Vec<u8>>>(1).ok().flatten();
        let doc_blob = row.get::<_, Option<Vec<u8>>>(2).ok().flatten();

        let (Some(dict_blob), Some(doc_blob)) = (dict_blob, doc_blob) else {
            continue;
        };

        match parse_binary_xml_project(&dict_blob, &doc_blob) {
            Ok(tree) => {
                let mut parsed = collect_project_from_binary_tree(tree);
                let xml_preview = parsed
                    .as_object_mut()
                    .and_then(|map| map.remove("_xml_preview"));

                return Ok(Some(json!({
                    "found": true,
                    "source": format!("{table_name}.dict+{table_name}.doc"),
                    "source_table": table_name,
                    "source_rowid": source_rowid,
                    "source_row_count": source_row_count,
                    "decode_strategy": "binary_xml_opcode_parser",
                    "xml_preview": xml_preview,
                    "parsed": parsed,
                })));
            }
            Err(error) => parse_errors.push(format!("{table_name}: {error}")),
        }
    }

    if !parse_errors.is_empty() {
        return Ok(Some(json!({
            "found": false,
            "source": Value::Null,
            "decode_strategy": "binary_xml_opcode_parser",
            "xml_preview": Value::Null,
            "parsed": Value::Null,
            "errors": parse_errors,
        })));
    }

    Ok(None)
}

fn extract_project_info_from_db(conn: &Connection) -> Result<Value> {
    let binary_result = extract_project_info_from_binary_xml(conn)?;
    if let Some(found_payload) = &binary_result {
        if found_payload
            .get("found")
            .and_then(Value::as_bool)
            .unwrap_or(false)
        {
            return Ok(found_payload.clone());
        }
    }

    let mut output = json!({
        "found": false,
        "source": Value::Null,
        "decode_strategy": "binary_xml_opcode_parser",
        "xml_preview": Value::Null,
        "parsed": Value::Null,
        "error": "Binary XML parser could not decode project payload.",
    });

    if let Some(binary_result) = binary_result {
        if let Some(errors) = binary_result.get("errors") {
            if let Some(map) = output.as_object_mut() {
                map.insert("binary_parser_errors".to_string(), errors.clone());
            }
        }
    }

    Ok(output)
}

pub fn build_essential_wav_result(full_result: &Value) -> Value {
    let project_payload = full_result.get("project_payload").unwrap_or(&Value::Null);
    let project_parsed = project_payload.get("parsed").unwrap_or(&Value::Null);
    let audio_blocks = full_result.get("audio_blocks").unwrap_or(&Value::Null);

    let wave_tracks = project_parsed
        .get("wave_tracks")
        .cloned()
        .unwrap_or_else(|| Value::Array(Vec::new()));
    let mut wave_clips_preview = project_parsed
        .get("wave_clips_preview")
        .cloned()
        .unwrap_or_else(|| Value::Array(Vec::new()));
    enrich_clip_preview_aliases(&mut wave_clips_preview);
    let used_block_ids = project_parsed
        .get("used_block_ids")
        .cloned()
        .unwrap_or_else(|| Value::Array(Vec::new()));

    let mut exactness_notes_set = BTreeSet::new();
    if let Some(notes) = audio_blocks
        .get("exactness_notes")
        .and_then(Value::as_array)
    {
        for note in notes {
            if let Some(text) = note.as_str() {
                exactness_notes_set.insert(text.to_string());
            }
        }
    }

    if !project_payload
        .get("found")
        .and_then(Value::as_bool)
        .unwrap_or(false)
    {
        exactness_notes_set.insert("project_payload_not_found".to_string());
    }

    if project_parsed.get("sample_rate").is_none()
        || project_parsed
            .get("sample_rate")
            .map(Value::is_null)
            .unwrap_or(true)
    {
        exactness_notes_set.insert("project_sample_rate_missing".to_string());
    }

    let mut channel_set = BTreeSet::new();
    if let Some(tracks) = wave_tracks.as_array() {
        for track in tracks {
            if let Some(channel) = track.get("channel").and_then(safe_int) {
                channel_set.insert(channel);
            }
        }
    }

    let sampleformat = if audio_blocks
        .get("sampleformat")
        .is_some_and(Value::is_object)
    {
        audio_blocks
            .get("sampleformat")
            .cloned()
            .unwrap_or(Value::Null)
    } else {
        Value::Null
    };

    let mut essential = json!({
        "file": full_result.get("file").cloned().unwrap_or(Value::Null),
        "file_info": full_result.get("file_info").cloned().unwrap_or(Value::Null),
        "size_bytes": full_result.get("size_bytes").cloned().unwrap_or(Value::Null),
        "wav": {
            "sample_rate": project_parsed.get("sample_rate").cloned().unwrap_or(Value::Null),
            "duration_seconds": audio_blocks.get("duration_seconds").cloned().unwrap_or(Value::Null),
            "total_samples": audio_blocks.get("total_samples").cloned().unwrap_or(Value::Null),
            "total_sample_bytes": audio_blocks.get("total_sample_bytes").cloned().unwrap_or(Value::Null),
            "channels": channel_set.iter().copied().collect::<Vec<_>>(),
            "channel_count": channel_set.len(),
            "track_count": project_parsed.get("wave_track_count").cloned().unwrap_or(Value::Null),
            "clip_count": project_parsed.get("wave_clip_count").cloned().unwrap_or(Value::Null),
            "block_count": audio_blocks.get("count").cloned().unwrap_or(Value::Null),
            "sampleformat": sampleformat.clone(),
            "sample_format": sampleformat,
            "tracks": wave_tracks,
            "clips_preview": wave_clips_preview,
            "timeline": {
                "used_block_ids": used_block_ids,
                "missing_block_ids_in_sampleblocks": audio_blocks
                    .get("missing_timeline_block_ids_in_sampleblocks")
                    .cloned()
                    .unwrap_or_else(|| Value::Array(Vec::new())),
                "unused_block_ids_in_sampleblocks": audio_blocks
                    .get("unused_sampleblocks_not_referenced_by_timeline")
                    .cloned()
                    .unwrap_or_else(|| Value::Array(Vec::new())),
            },
            "exactness_notes": exactness_notes_set.into_iter().collect::<Vec<_>>(),
        },
    });

    if let Some(exports) = full_result.get("exports") {
        if let Some(map) = essential.as_object_mut() {
            map.insert("exports".to_string(), exports.clone());
        }
    }

    essential
}

fn inspect_full(path: &Path) -> Result<Value> {
    if !path.exists() {
        return Err(AupError::InvalidInput(format!(
            "File not found: {}",
            path.display()
        )));
    }

    if path
        .extension()
        .map(|ext| ext.to_string_lossy().to_ascii_lowercase())
        .as_deref()
        != Some("aup3")
    {
        let suffix = path
            .extension()
            .map(|ext| ext.to_string_lossy().to_string())
            .unwrap_or_default();
        return Err(AupError::InvalidInput(format!(
            "Expected .aup3 file, got: {suffix}"
        )));
    }

    let metadata = std::fs::metadata(path)?;
    let conn = Connection::open_with_flags(
        path,
        OpenFlags::SQLITE_OPEN_READ_ONLY | OpenFlags::SQLITE_OPEN_NO_MUTEX,
    )?;

    let sqlite_overview = db_overview(&conn)?;
    let mut project_payload = extract_project_info_from_db(&conn)?;
    if let Some(parsed) = project_payload
        .get_mut("parsed")
        .and_then(Value::as_object_mut)
    {
        let mut wave_clips_preview = parsed
            .get("wave_clips_preview")
            .cloned()
            .unwrap_or_else(|| Value::Array(Vec::new()));
        enrich_clip_preview_aliases(&mut wave_clips_preview);
        parsed.insert("wave_clips_preview".to_string(), wave_clips_preview);
    }

    let mut sample_rate = None;
    let mut used_block_ids: Option<BTreeSet<i64>> = None;
    let mut channel_block_refs: Option<BTreeMap<i64, Vec<(i64, i64)>>> = None;

    if let Some(project_parsed) = project_payload.get("parsed") {
        if let Some(rate_value) = project_parsed.get("sample_rate") {
            sample_rate = safe_float(rate_value);
        }

        if let Some(raw_ids) = project_parsed
            .get("used_block_ids")
            .and_then(Value::as_array)
        {
            let ids = raw_ids.iter().filter_map(safe_int).collect::<BTreeSet<_>>();
            used_block_ids = Some(ids);
        }

        let refs = extract_channel_block_refs(project_parsed);
        if !refs.is_empty() {
            channel_block_refs = Some(refs);
        }
    }

    let audio_blocks = collect_sampleblocks_info(
        &conn,
        sample_rate,
        used_block_ids.as_ref(),
        channel_block_refs.as_ref(),
    )?;

    Ok(json!({
        "file": path.to_string_lossy().to_string(),
        "file_info": path_file_info(path),
        "size_bytes": metadata.len(),
        "sqlite": sqlite_overview,
        "project_payload": project_payload,
        "audio_blocks": audio_blocks,
    }))
}

pub fn inspect_profile(path: &Path, profile: &str) -> Result<Value> {
    let full = inspect_full(path)?;

    match profile {
        "full" => Ok(full),
        "essential" => Ok(build_essential_wav_result(&full)),
        other => Err(AupError::InvalidInput(format!(
            "Unsupported profile: {other}. Expected 'essential' or 'full'."
        ))),
    }
}
