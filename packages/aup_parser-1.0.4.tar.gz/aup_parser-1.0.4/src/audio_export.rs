use std::collections::{BTreeMap, BTreeSet, HashMap};
use std::fs::File;
use std::io::{BufWriter, Write};
use std::path::{Path, PathBuf};

use pyo3::prelude::PyAnyMethods;
use pyo3::types::{
    PyDict, PyDictMethods, PyList, PyListMethods, PyStringMethods, PyTuple, PyTupleMethods,
    PyTypeMethods,
};
use rayon::prelude::*;
use rusqlite::{Connection, OpenFlags};
use serde_json::{json, Map, Number, Value};

use crate::error::{AupError, Result};
use crate::sampleblocks::extract_channel_block_refs;
use crate::types::{safe_float, safe_int, sampleformat_to_value};

#[derive(Clone, Debug)]
struct ClipRef {
    block_id: i64,
    block_start: i64,
    clip_offset: f64,
    clip_trim_left: f64,
    clip_trim_right: f64,
    clip_stretch_ratio: Option<f64>,
    clip_numsamples: Option<i64>,
}

#[derive(Clone, Copy, Debug)]
struct FragmentRef {
    start_sample: i64,
    block_id: i64,
    source_from: usize,
    source_to: usize,
}

#[derive(Clone, Debug)]
struct ChannelPlan {
    channel: i64,
    fragments: Vec<FragmentRef>,
    max_end_sample: i64,
    overlap_detected: bool,
    used_clip_renderer: bool,
    unsupported_stretch: bool,
}

fn as_path_string(path: &Path) -> String {
    path.to_string_lossy().to_string()
}

fn sampleformat_description(raw: i64) -> Value {
    sampleformat_to_value(raw)
}

fn make_unique_directory_candidate(path: &Path) -> PathBuf {
    if !path.exists() || path.is_dir() {
        return path.to_path_buf();
    }

    let parent = path.parent().unwrap_or_else(|| Path::new("."));
    let base_name = path
        .file_name()
        .and_then(|name| name.to_str())
        .unwrap_or("output_channels");

    let mut index = 2usize;
    loop {
        let candidate = parent.join(format!("{base_name}_{index}"));
        if !candidate.exists() || candidate.is_dir() {
            return candidate;
        }
        index += 1;
    }
}

fn resolve_multichannel_output_dir(audio_output_path: &Path) -> (PathBuf, bool) {
    if audio_output_path.extension().is_some() {
        let parent = audio_output_path.parent().unwrap_or_else(|| Path::new("."));
        let stem = audio_output_path
            .file_stem()
            .and_then(|stem| stem.to_str())
            .unwrap_or("output");
        let candidate = parent.join(format!("{stem}_channels"));
        return (make_unique_directory_candidate(&candidate), true);
    }

    (make_unique_directory_candidate(audio_output_path), false)
}

fn resolve_single_channel_output_dir(audio_output_path: &Path) -> PathBuf {
    if audio_output_path.extension().is_some() {
        let parent = audio_output_path.parent().unwrap_or_else(|| Path::new("."));
        let stem = audio_output_path
            .file_stem()
            .and_then(|stem| stem.to_str())
            .unwrap_or("output");
        let candidate = parent.join(stem);
        return make_unique_directory_candidate(&candidate);
    }

    make_unique_directory_candidate(audio_output_path)
}

fn resolve_single_channel_output_file(audio_output_path: &Path, file_name: &str) -> PathBuf {
    resolve_single_channel_output_dir(audio_output_path).join(file_name)
}

fn has_known_audio_extension(name: &str) -> bool {
    let lower = name.to_ascii_lowercase();
    [
        ".wav", ".mp3", ".flac", ".aac", ".m4a", ".ogg", ".aif", ".aiff", ".wma", ".opus",
    ]
    .iter()
    .any(|ext| lower.ends_with(ext))
}

fn strip_known_audio_extension<'a>(name: &'a str) -> &'a str {
    let lower = name.to_ascii_lowercase();
    for ext in [
        ".wav", ".mp3", ".flac", ".aac", ".m4a", ".ogg", ".aif", ".aiff", ".wma", ".opus",
    ] {
        if lower.ends_with(ext) && name.len() > ext.len() {
            if let Some(stem) = name.get(..name.len() - ext.len()) {
                return stem;
            }
        }
    }
    name
}

fn extract_original_audio_name_base(project_parsed: Option<&Value>) -> Option<String> {
    let parsed = project_parsed?;
    let mut preferred: Vec<String> = Vec::new();
    let mut fallback: Vec<String> = Vec::new();

    for key in ["wave_clips_preview", "wave_tracks"] {
        let Some(items) = parsed.get(key).and_then(Value::as_array) else {
            continue;
        };
        for item in items {
            let Some(name) = item.get("name").and_then(Value::as_str) else {
                continue;
            };
            let trimmed = name.trim();
            if trimmed.is_empty() {
                continue;
            }
            if has_known_audio_extension(trimmed) {
                preferred.push(trimmed.to_string());
            } else {
                fallback.push(trimmed.to_string());
            }
        }
    }

    for name in preferred.iter().chain(fallback.iter()) {
        let stem = strip_known_audio_extension(name);
        let sanitized = sanitize_filename_component(stem);
        if !sanitized.is_empty() {
            return Some(sanitized);
        }
    }

    None
}

fn checked_sample_bytes(sample_count: i64, sample_width: usize) -> Result<usize> {
    let samples = usize::try_from(sample_count).map_err(|_| {
        AupError::InvalidInput(format!(
            "Negative or too-large sample count for byte conversion: {sample_count}"
        ))
    })?;
    samples.checked_mul(sample_width).ok_or_else(|| {
        AupError::InvalidInput("Overflow converting samples to byte length".to_string())
    })
}

fn write_wav_header<W: Write>(
    writer: &mut W,
    data_len: u32,
    channel_count: u16,
    sample_width_bytes: u16,
    wav_format_code: u16,
    sample_rate: u32,
) -> Result<()> {
    let chunk_size = data_len.checked_add(36).ok_or_else(|| {
        AupError::InvalidInput("WAV header size overflow while building RIFF".to_string())
    })?;
    let block_align = channel_count
        .checked_mul(sample_width_bytes)
        .ok_or_else(|| AupError::InvalidInput("WAV block_align overflow".to_string()))?;
    let byte_rate_u64 = (sample_rate as u64)
        .checked_mul(block_align as u64)
        .ok_or_else(|| AupError::InvalidInput("WAV byte_rate overflow".to_string()))?;
    let byte_rate = u32::try_from(byte_rate_u64)
        .map_err(|_| AupError::InvalidInput("WAV byte_rate overflow".to_string()))?;
    let bits_per_sample = sample_width_bytes
        .checked_mul(8)
        .ok_or_else(|| AupError::InvalidInput("WAV bits_per_sample overflow".to_string()))?;

    writer.write_all(b"RIFF")?;
    writer.write_all(&chunk_size.to_le_bytes())?;
    writer.write_all(b"WAVE")?;
    writer.write_all(b"fmt ")?;
    writer.write_all(&16u32.to_le_bytes())?;
    writer.write_all(&wav_format_code.to_le_bytes())?;
    writer.write_all(&channel_count.to_le_bytes())?;
    writer.write_all(&sample_rate.to_le_bytes())?;
    writer.write_all(&byte_rate.to_le_bytes())?;
    writer.write_all(&block_align.to_le_bytes())?;
    writer.write_all(&bits_per_sample.to_le_bytes())?;
    writer.write_all(b"data")?;
    writer.write_all(&data_len.to_le_bytes())?;
    Ok(())
}

fn write_zero_bytes<W: Write>(writer: &mut W, total_bytes: usize) -> Result<()> {
    const CHUNK: usize = 64 * 1024;
    let zeros = [0u8; CHUNK];
    let mut remaining = total_bytes;
    while remaining > 0 {
        let step = remaining.min(CHUNK);
        writer.write_all(&zeros[..step])?;
        remaining -= step;
    }
    Ok(())
}

fn write_wav_file(
    output_path: &Path,
    payload: &[u8],
    sample_width: u16,
    wav_format_code: u16,
    sample_rate: u32,
) -> Result<usize> {
    let data_len = u32::try_from(payload.len()).map_err(|_| {
        AupError::InvalidInput("WAV payload is too large for RIFF container".to_string())
    })?;
    if let Some(parent) = output_path.parent() {
        std::fs::create_dir_all(parent)?;
    }
    let file = File::create(output_path)?;
    let mut writer = BufWriter::new(file);
    write_wav_header(
        &mut writer,
        data_len,
        1,
        sample_width,
        wav_format_code,
        sample_rate,
    )?;
    writer.write_all(payload)?;
    writer.flush()?;
    Ok(payload.len())
}

fn write_fragments_streaming_wav(
    output_path: &Path,
    fragments: &[FragmentRef],
    block_samples: &BTreeMap<i64, Vec<u8>>,
    sample_width: usize,
    sample_width_u16: u16,
    wav_format_code: u16,
    sample_rate_u32: u32,
    max_end_sample: i64,
) -> Result<usize> {
    let data_len_usize = checked_sample_bytes(max_end_sample, sample_width)?;
    let data_len = u32::try_from(data_len_usize)
        .map_err(|_| AupError::InvalidInput("WAV payload is too large for RIFF container".to_string()))?;

    if let Some(parent) = output_path.parent() {
        std::fs::create_dir_all(parent)?;
    }
    let file = File::create(output_path)?;
    let mut writer = BufWriter::new(file);
    write_wav_header(
        &mut writer,
        data_len,
        1,
        sample_width_u16,
        wav_format_code,
        sample_rate_u32,
    )?;

    let mut cursor_sample = 0i64;
    for fragment in fragments {
        if fragment.start_sample > cursor_sample {
            let gap_samples = fragment.start_sample - cursor_sample;
            let gap_bytes = checked_sample_bytes(gap_samples, sample_width)?;
            write_zero_bytes(&mut writer, gap_bytes)?;
            cursor_sample = fragment.start_sample;
        }

        let block_payload = block_samples.get(&fragment.block_id).ok_or_else(|| {
            AupError::InvalidInput(format!(
                "Timeline references missing blockid in sampleblocks: blockid={}",
                fragment.block_id
            ))
        })?;
        if fragment.source_to > block_payload.len() || fragment.source_from > fragment.source_to {
            return Err(AupError::InvalidInput(
                "fragment source range is out of block payload bounds".to_string(),
            ));
        }

        let part = &block_payload[fragment.source_from..fragment.source_to];
        writer.write_all(part)?;
        let part_samples = i64::try_from(part.len() / sample_width)
            .map_err(|_| AupError::InvalidInput("fragment sample count overflow".to_string()))?;
        cursor_sample += part_samples;
    }

    if max_end_sample > cursor_sample {
        let tail_samples = max_end_sample - cursor_sample;
        let tail_bytes = checked_sample_bytes(tail_samples, sample_width)?;
        write_zero_bytes(&mut writer, tail_bytes)?;
    }

    writer.flush()?;
    Ok(data_len_usize)
}

fn render_timeline_buffer(
    fragments: &[FragmentRef],
    block_samples: &BTreeMap<i64, Vec<u8>>,
    sample_width: usize,
    max_end_sample: i64,
) -> Result<Vec<u8>> {
    let timeline_len = checked_sample_bytes(max_end_sample, sample_width)?;
    let mut timeline = vec![0u8; timeline_len];

    for fragment in fragments {
        let block_payload = block_samples.get(&fragment.block_id).ok_or_else(|| {
            AupError::InvalidInput(format!(
                "Timeline references missing blockid in sampleblocks: blockid={}",
                fragment.block_id
            ))
        })?;
        if fragment.source_to > block_payload.len() || fragment.source_from > fragment.source_to {
            return Err(AupError::InvalidInput(
                "fragment source range is out of block payload bounds".to_string(),
            ));
        }

        let source = &block_payload[fragment.source_from..fragment.source_to];
        let start_byte = checked_sample_bytes(fragment.start_sample, sample_width)?;
        let end_byte = start_byte
            .checked_add(source.len())
            .ok_or_else(|| AupError::InvalidInput("Timeline write overflow".to_string()))?;
        if end_byte > timeline.len() {
            return Err(AupError::InvalidInput(
                "Timeline write exceeded allocated buffer".to_string(),
            ));
        }
        timeline[start_byte..end_byte].copy_from_slice(source);
    }

    Ok(timeline)
}

fn fragment_sample_len(fragment: &FragmentRef, sample_width: usize) -> Result<i64> {
    let span = fragment
        .source_to
        .checked_sub(fragment.source_from)
        .ok_or_else(|| AupError::InvalidInput("fragment source range underflow".to_string()))?;
    if span % sample_width != 0 {
        return Err(AupError::InvalidInput(format!(
            "fragment byte length is not divisible by sample_width: bytes={span}, sample_width={sample_width}"
        )));
    }
    i64::try_from(span / sample_width)
        .map_err(|_| AupError::InvalidInput("fragment sample length overflow".to_string()))
}

fn finalize_fragments(mut fragments: Vec<FragmentRef>, sample_width: usize) -> Result<(Vec<FragmentRef>, i64, bool)> {
    if fragments.is_empty() {
        return Ok((Vec::new(), 0, false));
    }
    fragments.sort_by_key(|f| f.start_sample);

    let mut max_end_sample = 0i64;
    let mut overlap_detected = false;
    let mut previous_end = 0i64;
    for fragment in &fragments {
        if fragment.start_sample < 0 {
            return Err(AupError::InvalidInput(format!(
                "Negative start sample in timeline refs: start={}",
                fragment.start_sample
            )));
        }
        let len_samples = fragment_sample_len(fragment, sample_width)?;
        let end = fragment
            .start_sample
            .checked_add(len_samples)
            .ok_or_else(|| AupError::InvalidInput("timeline end sample overflow".to_string()))?;
        if fragment.start_sample < previous_end {
            overlap_detected = true;
        }
        previous_end = previous_end.max(end);
        max_end_sample = max_end_sample.max(end);
    }

    Ok((fragments, max_end_sample, overlap_detected))
}

fn finalize_clip_fragments(
    mut fragments: Vec<FragmentRef>,
    sample_width: usize,
) -> Result<(Vec<FragmentRef>, i64, bool)> {
    if fragments.is_empty() {
        return Ok((Vec::new(), 0, false));
    }
    fragments.sort_by_key(|f| f.start_sample);

    let mut out = Vec::with_capacity(fragments.len());
    let mut max_end_sample = 0i64;
    let mut previous_end = 0i64;
    let mut overlap_detected = false;

    for mut fragment in fragments {
        if fragment.start_sample < 0 {
            return Err(AupError::InvalidInput(format!(
                "Negative start sample in timeline refs: start={}",
                fragment.start_sample
            )));
        }

        let mut len_samples = fragment_sample_len(&fragment, sample_width)?;

        if fragment.start_sample < previous_end {
            overlap_detected = true;
            let clipped = previous_end - fragment.start_sample;
            if clipped >= len_samples {
                continue;
            }
            let clipped_bytes = checked_sample_bytes(clipped, sample_width)?;
            fragment.source_from = fragment.source_from.checked_add(clipped_bytes).ok_or_else(|| {
                AupError::InvalidInput("fragment source range overflow while clipping overlap".to_string())
            })?;
            fragment.start_sample = previous_end;
            len_samples -= clipped;
        }

        let end = fragment
            .start_sample
            .checked_add(len_samples)
            .ok_or_else(|| AupError::InvalidInput("timeline end sample overflow".to_string()))?;
        previous_end = end;
        max_end_sample = max_end_sample.max(end);
        out.push(fragment);
    }

    Ok((out, max_end_sample, overlap_detected))
}

fn build_timeline_fragments(
    refs: &[(i64, i64)],
    block_samples: &BTreeMap<i64, Vec<u8>>,
    sample_width: usize,
) -> Result<(Vec<FragmentRef>, i64, bool)> {
    let mut fragments = Vec::with_capacity(refs.len());
    for (start_sample, block_id) in refs {
        let payload = block_samples.get(block_id).ok_or_else(|| {
            AupError::InvalidInput(format!(
                "Timeline references missing blockid in sampleblocks: blockid={block_id}"
            ))
        })?;
        if payload.len() % sample_width != 0 {
            return Err(AupError::InvalidInput(format!(
                "Block payload byte length is not divisible by sample width: blockid={block_id}, bytes={}, sample_width={sample_width}",
                payload.len()
            )));
        }
        fragments.push(FragmentRef {
            start_sample: *start_sample,
            block_id: *block_id,
            source_from: 0,
            source_to: payload.len(),
        });
    }

    finalize_fragments(fragments, sample_width)
}

fn build_clip_fragments(
    refs: &[ClipRef],
    block_samples: &BTreeMap<i64, Vec<u8>>,
    sample_width: usize,
    project_sample_rate: f64,
) -> Result<(Vec<FragmentRef>, i64, bool, bool)> {
    let mut fragments = Vec::new();
    let mut unsupported_stretch = false;

    for item in refs {
        if let Some(stretch) = item.clip_stretch_ratio {
            if stretch > 0.0 && (stretch - 1.0).abs() > 1e-9 {
                unsupported_stretch = true;
                continue;
            }
        }

        let payload = block_samples.get(&item.block_id).ok_or_else(|| {
            AupError::InvalidInput(format!(
                "Clip references missing blockid in sampleblocks: blockid={}",
                item.block_id
            ))
        })?;
        if payload.len() % sample_width != 0 {
            return Err(AupError::InvalidInput(format!(
                "Block payload byte length is not divisible by sample width: blockid={}, bytes={}, sample_width={sample_width}",
                item.block_id,
                payload.len()
            )));
        }

        let block_samples_len = i64::try_from(payload.len() / sample_width)
            .map_err(|_| AupError::InvalidInput("block sample length overflow".to_string()))?;
        let block_end = item
            .block_start
            .checked_add(block_samples_len)
            .ok_or_else(|| AupError::InvalidInput("block_end overflow".to_string()))?;

        let trim_left_samples = ((item.clip_trim_left.max(0.0) * project_sample_rate).round() as i64).max(0);
        let trim_right_samples = ((item.clip_trim_right.max(0.0) * project_sample_rate).round() as i64).max(0);
        // Audacity's waveclip `offset` is sequence start time, not play start time.
        // Play start is quantized from (offset + trimLeft).
        let clip_play_start_samples =
            ((item.clip_offset + item.clip_trim_left.max(0.0)) * project_sample_rate).round() as i64;

        let mut visible_start = trim_left_samples;
        let mut visible_end = item.clip_numsamples.map(|num_samples| (num_samples - trim_right_samples).max(0));
        if let Some(end) = visible_end {
            if visible_start > end {
                visible_start = end;
            }
        }

        let include_start = item.block_start.max(visible_start);
        let include_end = visible_end.take().map(|end| block_end.min(end)).unwrap_or(block_end);
        if include_end <= include_start {
            continue;
        }

        let mut source_from = checked_sample_bytes(include_start - item.block_start, sample_width)?;
        let source_to = checked_sample_bytes(include_end - item.block_start, sample_width)?;
        let mut timeline_start = clip_play_start_samples + (include_start - visible_start);

        if timeline_start < 0 {
            let available = include_end - include_start;
            let skip_samples = (-timeline_start).min(available);
            if skip_samples >= available {
                continue;
            }
            let skip_bytes = checked_sample_bytes(skip_samples, sample_width)?;
            source_from = source_from
                .checked_add(skip_bytes)
                .ok_or_else(|| AupError::InvalidInput("fragment source offset overflow".to_string()))?;
            timeline_start += skip_samples;
        }

        if source_from >= source_to {
            continue;
        }

        fragments.push(FragmentRef {
            start_sample: timeline_start,
            block_id: item.block_id,
            source_from,
            source_to,
        });
    }

    let (fragments, max_end_sample, overlap_detected) =
        finalize_clip_fragments(fragments, sample_width)?;
    Ok((fragments, max_end_sample, overlap_detected, unsupported_stretch))
}

fn extract_clip_block_refs(project_parsed: Option<&Value>) -> BTreeMap<i64, Vec<ClipRef>> {
    let mut channel_map: BTreeMap<i64, Vec<ClipRef>> = BTreeMap::new();
    let Some(project_parsed) = project_parsed else {
        return channel_map;
    };

    let Some(items) = project_parsed
        .get("clip_wave_blocks")
        .and_then(Value::as_array)
    else {
        return channel_map;
    };

    for item in items {
        let channel = item.get("channel").and_then(safe_int);
        let block_id = item.get("blockid").and_then(safe_int);
        let block_start = item.get("block_start").and_then(safe_int);
        let (Some(channel), Some(block_id), Some(block_start)) = (channel, block_id, block_start)
        else {
            continue;
        };

        channel_map.entry(channel).or_default().push(ClipRef {
            block_id,
            block_start,
            clip_offset: item.get("clip_offset").and_then(safe_float).unwrap_or(0.0),
            clip_trim_left: item
                .get("clip_trim_left")
                .and_then(safe_float)
                .unwrap_or(0.0),
            clip_trim_right: item
                .get("clip_trim_right")
                .and_then(safe_float)
                .unwrap_or(0.0),
            clip_stretch_ratio: item.get("clip_stretch_ratio").and_then(safe_float),
            clip_numsamples: item.get("clip_numsamples").and_then(safe_int),
        });
    }

    for refs in channel_map.values_mut() {
        refs.sort_by(|a, b| {
            a.clip_offset
                .total_cmp(&b.clip_offset)
                .then(a.block_start.cmp(&b.block_start))
                .then(a.block_id.cmp(&b.block_id))
        });
    }

    channel_map
}

fn extract_project_sample_rate(project_parsed: Option<&Value>) -> Option<f64> {
    project_parsed
        .and_then(|parsed| parsed.get("sample_rate"))
        .and_then(safe_float)
        .filter(|rate| *rate > 0.0)
}

fn extract_uniform_track_sample_rate(project_parsed: Option<&Value>) -> Result<Option<f64>> {
    let Some(project_parsed) = project_parsed else {
        return Ok(None);
    };
    let Some(tracks) = project_parsed.get("wave_tracks").and_then(Value::as_array) else {
        return Ok(None);
    };

    let mut unique_rates: Vec<f64> = Vec::new();
    for track in tracks {
        let Some(rate) = track.get("rate").and_then(safe_float).filter(|rate| *rate > 0.0) else {
            continue;
        };
        if !unique_rates.iter().any(|known| (known - rate).abs() < 1e-6) {
            unique_rates.push(rate);
        }
    }

    if unique_rates.is_empty() {
        return Ok(None);
    }
    if unique_rates.len() > 1 {
        let values = unique_rates
            .iter()
            .map(|value| value.to_string())
            .collect::<Vec<_>>()
            .join(", ");
        return Err(AupError::InvalidInput(format!(
            "Multiple wavetrack.rate values found ({values}); cannot determine one export sample rate."
        )));
    }

    Ok(unique_rates.first().copied())
}

fn sanitize_filename_component(raw: &str) -> String {
    let mut out = String::with_capacity(raw.len());
    for ch in raw.chars() {
        let is_forbidden = ch.is_control() || matches!(ch, '<' | '>' | ':' | '"' | '/' | '\\' | '|' | '?' | '*');
        if is_forbidden {
            out.push('_');
        } else if ch.is_alphanumeric() || ch == '-' || ch == '_' {
            out.push(ch);
        } else if ch.is_whitespace() {
            out.push('_');
        } else {
            out.push('_');
        }
    }
    let trimmed = out.trim_matches('_');
    if trimmed.is_empty() {
        "channel".to_string()
    } else {
        trimmed.to_string()
    }
}

fn extract_channel_track_names(project_parsed: Option<&Value>) -> BTreeMap<i64, String> {
    let mut out: BTreeMap<i64, String> = BTreeMap::new();
    let Some(project_parsed) = project_parsed else {
        return out;
    };
    let Some(tracks) = project_parsed.get("wave_tracks").and_then(Value::as_array) else {
        return out;
    };

    for track in tracks {
        let channel = track.get("channel").and_then(safe_int);
        let name = track.get("name").and_then(Value::as_str);
        let (Some(channel), Some(name)) = (channel, name) else {
            continue;
        };
        if name.trim().is_empty() {
            continue;
        }
        out.entry(channel).or_insert_with(|| sanitize_filename_component(name));
    }

    out
}

fn make_output_filename(
    channel: i64,
    track_names: &BTreeMap<i64, String>,
    used_names: &mut HashMap<String, usize>,
) -> String {
    let base = track_names
        .get(&channel)
        .cloned()
        .unwrap_or_else(|| format!("channel_{channel:02}"));

    let count = used_names.entry(base.clone()).or_insert(0);
    let suffix_index = *count;
    *count += 1;
    if suffix_index == 0 {
        format!("{base}.wav")
    } else {
        format!("{base}_{suffix_index}.wav")
    }
}

fn format_i64_list(values: &[i64]) -> String {
    let joined = values
        .iter()
        .map(|value| value.to_string())
        .collect::<Vec<_>>()
        .join(", ");
    format!("[{joined}]")
}

fn build_channel_plan(
    channel: i64,
    channel_refs: Option<&Vec<(i64, i64)>>,
    clip_refs: Option<&Vec<ClipRef>>,
    block_samples: &BTreeMap<i64, Vec<u8>>,
    sample_width: usize,
    project_sample_rate: f64,
) -> Result<Option<ChannelPlan>> {
    let mut unsupported_stretch = false;

    if let Some(clip_refs) = clip_refs {
        let (fragments, max_end_sample, overlap_detected, unsupported) =
            build_clip_fragments(clip_refs, block_samples, sample_width, project_sample_rate)?;
        unsupported_stretch = unsupported;
        if !fragments.is_empty() {
            return Ok(Some(ChannelPlan {
                channel,
                fragments,
                max_end_sample,
                overlap_detected,
                used_clip_renderer: true,
                unsupported_stretch,
            }));
        }
    }

    if let Some(channel_refs) = channel_refs {
        let (fragments, max_end_sample, overlap_detected) =
            build_timeline_fragments(channel_refs, block_samples, sample_width)?;
        if !fragments.is_empty() {
            return Ok(Some(ChannelPlan {
                channel,
                fragments,
                max_end_sample,
                overlap_detected,
                used_clip_renderer: false,
                unsupported_stretch,
            }));
        }
    }

    Ok(None)
}

pub fn export_audio_output_core(
    aup3_path: &Path,
    audio_output_path: &Path,
    project_parsed: Option<&Value>,
) -> Result<Value> {
    let conn = Connection::open_with_flags(
        aup3_path,
        OpenFlags::SQLITE_OPEN_READ_ONLY | OpenFlags::SQLITE_OPEN_NO_MUTEX,
    )?;
    let mut stmt =
        conn.prepare("SELECT blockid, sampleformat, samples FROM sampleblocks ORDER BY blockid")?;
    let mut rows = stmt.query([])?;

    let mut sampleformat_values = BTreeSet::new();
    let mut block_samples: BTreeMap<i64, Vec<u8>> = BTreeMap::new();
    let mut blockid_order: Vec<i64> = Vec::new();
    while let Some(row) = rows.next()? {
        let block_id = row.get::<_, Option<i64>>(0)?.unwrap_or(-1);
        let sampleformat = row.get::<_, Option<i64>>(1)?.unwrap_or(0);
        let samples = row.get::<_, Option<Vec<u8>>>(2)?.unwrap_or_default();
        if block_id < 0 {
            continue;
        }
        sampleformat_values.insert(sampleformat);
        blockid_order.push(block_id);
        block_samples.insert(block_id, samples);
    }

    if block_samples.is_empty() {
        return Err(AupError::InvalidInput(
            "No sampleblocks found to export audio.".to_string(),
        ));
    }
    if sampleformat_values.len() != 1 {
        let values = sampleformat_values.iter().copied().collect::<Vec<_>>();
        return Err(AupError::InvalidInput(format!(
            "Expected one sampleformat, found: {}",
            format_i64_list(&values)
        )));
    }
    let sampleformat = *sampleformat_values.iter().next().unwrap_or(&0);
    let sample_width = sampleformat >> 16;
    let encoding_id = sampleformat & 0xFFFF;
    if !(1..=4).contains(&sample_width) {
        return Err(AupError::InvalidInput(format!(
            "Unsupported sample width from sampleformat={sampleformat}."
        )));
    }
    let wav_format_code = match encoding_id {
        1 => 1u16, // PCM
        3 | 15 => {
            if sample_width != 4 {
                return Err(AupError::InvalidInput(format!(
                    "Unsupported float sample width from sampleformat={sampleformat}. Expected 4-byte float."
                )));
            }
            3u16 // IEEE float
        }
        other => {
            return Err(AupError::InvalidInput(format!(
                "Unsupported sampleformat encoding_id={other} from sampleformat={sampleformat}."
            )))
        }
    };
    let sample_width_usize = usize::try_from(sample_width).map_err(|_| {
        AupError::InvalidInput(format!("Invalid sample width from sampleformat={sampleformat}."))
    })?;
    let sample_width_u16 = u16::try_from(sample_width).map_err(|_| {
        AupError::InvalidInput(format!("Invalid sample width from sampleformat={sampleformat}."))
    })?;

    let track_sample_rate_raw = extract_uniform_track_sample_rate(project_parsed)?;
    let project_sample_rate_raw = extract_project_sample_rate(project_parsed);

    let resolved_output_sample_rate = if let Some(rate) = track_sample_rate_raw {
        i64::try_from(rate.round() as i128).map_err(|_| {
            AupError::InvalidInput(format!(
                "Track sample rate is out of range for WAV export: {rate}"
            ))
        })?
    } else if let Some(rate) = project_sample_rate_raw {
        i64::try_from(rate.round() as i128).map_err(|_| {
            AupError::InvalidInput(format!(
                "Project sample_rate is out of range for WAV export: {rate}"
            ))
        })?
    } else {
        return Err(AupError::InvalidInput(
            "sample rate metadata is unavailable in wavetrack.rate and project sample_rate."
                .to_string(),
        ));
    };

    let sample_rate_u32 = u32::try_from(resolved_output_sample_rate).map_err(|_| {
        AupError::InvalidInput(format!(
            "sample_rate is too large for WAV export: {resolved_output_sample_rate}"
        ))
    })?;

    let channel_block_refs = project_parsed
        .map(extract_channel_block_refs)
        .unwrap_or_default();
    let clip_block_refs = extract_clip_block_refs(project_parsed);
    let channel_track_names = extract_channel_track_names(project_parsed);
    let clip_timeline_sample_rate = track_sample_rate_raw
        .or(project_sample_rate_raw)
        .unwrap_or(resolved_output_sample_rate as f64);
    let used_project_rate_for_clip_alignment =
        track_sample_rate_raw.is_none() && project_sample_rate_raw.is_some();

    let mut channels = BTreeSet::new();
    for channel in channel_block_refs.keys() {
        channels.insert(*channel);
    }
    for channel in clip_block_refs.keys() {
        channels.insert(*channel);
    }
    let channel_ids = channels.into_iter().collect::<Vec<_>>();

    let plan_results = channel_ids
        .par_iter()
        .map(|channel| {
            build_channel_plan(
                *channel,
                channel_block_refs.get(channel),
                clip_block_refs.get(channel),
                &block_samples,
                sample_width_usize,
                clip_timeline_sample_rate,
            )
        })
        .collect::<Vec<_>>();

    let mut channel_plans = Vec::new();
    for item in plan_results {
        if let Some(plan) = item? {
            channel_plans.push(plan);
        }
    }
    channel_plans.sort_by_key(|plan| plan.channel);

    let mut overlap_channels = channel_plans
        .iter()
        .filter(|plan| plan.overlap_detected)
        .map(|plan| plan.channel)
        .collect::<Vec<_>>();
    overlap_channels.sort_unstable();
    overlap_channels.dedup();

    let used_clip_timeline_renderer = channel_plans.iter().any(|plan| plan.used_clip_renderer);
    let used_channel_timeline_renderer = channel_plans.iter().any(|plan| !plan.used_clip_renderer);

    let mut clip_channels_with_stretch = channel_plans
        .iter()
        .filter(|plan| plan.unsupported_stretch)
        .map(|plan| plan.channel)
        .collect::<Vec<_>>();
    clip_channels_with_stretch.sort_unstable();
    clip_channels_with_stretch.dedup();
    if !clip_channels_with_stretch.is_empty() {
        return Err(AupError::InvalidInput(format!(
            "Exact restoration is not supported for non-unity clip stretch ratio in channels={}.",
            format_i64_list(&clip_channels_with_stretch)
        )));
    }

    let sampleformat_info = sampleformat_description(sampleformat);

    if channel_plans.len() >= 2 {
        let (output_dir, normalized) = resolve_multichannel_output_dir(audio_output_path);
        std::fs::create_dir_all(&output_dir)?;

        let mut files = Vec::new();
        let mut total_written = 0usize;
        let mut used_names: HashMap<String, usize> = HashMap::new();
        for plan in &channel_plans {
            let file_name =
                make_output_filename(plan.channel, &channel_track_names, &mut used_names);
            let output_file = output_dir.join(file_name);

            let written = if plan.overlap_detected {
                let timeline = render_timeline_buffer(
                    &plan.fragments,
                    &block_samples,
                    sample_width_usize,
                    plan.max_end_sample,
                )?;
                write_wav_file(
                    &output_file,
                    &timeline,
                    sample_width_u16,
                    wav_format_code,
                    sample_rate_u32,
                )?
            } else {
                write_fragments_streaming_wav(
                    &output_file,
                    &plan.fragments,
                    &block_samples,
                    sample_width_usize,
                    sample_width_u16,
                    wav_format_code,
                    sample_rate_u32,
                    plan.max_end_sample,
                )?
            };

            total_written += written;
            files.push(json!({
                "channel": plan.channel,
                "audio_path": as_path_string(&output_file),
                "written_audio_bytes": written,
            }));
        }

        let mut note = if normalized {
            format!(
                "Multi-channel project exported as one mono WAV per channel using timeline placement. Requested path was normalized to directory: {}",
                as_path_string(&output_dir)
            )
        } else {
            "Multi-channel project exported as one mono WAV per channel using timeline placement."
                .to_string()
        };
        if used_clip_timeline_renderer {
            note.push_str(" Clip metadata (offset/trim) was applied where available.");
        }
        if used_project_rate_for_clip_alignment {
            note.push_str(
                " wavetrack.rate metadata was unavailable; used project sample_rate for clip alignment.",
            );
        }
        if !overlap_channels.is_empty() {
            note.push_str(&format!(
                " Overlap detected in channels={}; overlapping regions were resolved with deterministic clip precedence.",
                format_i64_list(&overlap_channels)
            ));
        }

        return Ok(json!({
            "mode": "multi_channel_folder",
            "requested_output_path": as_path_string(audio_output_path),
            "output_path": as_path_string(&output_dir),
            "path_was_normalized": normalized,
            "channel_count": channel_plans.len(),
            "files": files,
            "sample_rate": resolved_output_sample_rate,
            "sample_width_bytes": sample_width,
            "wav_format_code": wav_format_code,
            "sampleformat": sampleformat_info,
            "total_written_audio_bytes": total_written,
            "note": note,
        }));
    }

    if channel_plans.len() == 1 {
        let plan = &channel_plans[0];
        let default_file_name =
            make_output_filename(plan.channel, &channel_track_names, &mut HashMap::new());
        let file_name = extract_original_audio_name_base(project_parsed)
            .map(|base| format!("{base}.wav"))
            .unwrap_or(default_file_name);
        let output_file = resolve_single_channel_output_file(audio_output_path, &file_name);

        let written = if plan.overlap_detected {
            let timeline = render_timeline_buffer(
                &plan.fragments,
                &block_samples,
                sample_width_usize,
                plan.max_end_sample,
            )?;
            write_wav_file(
                &output_file,
                &timeline,
                sample_width_u16,
                wav_format_code,
                sample_rate_u32,
            )?
        } else {
            write_fragments_streaming_wav(
                &output_file,
                &plan.fragments,
                &block_samples,
                sample_width_usize,
                sample_width_u16,
                wav_format_code,
                sample_rate_u32,
                plan.max_end_sample,
            )?
        };

        let mut note = "Single-channel timeline WAV export.".to_string();
        if plan.used_clip_renderer {
            note.push_str(" Clip metadata (offset/trim) was applied where available.");
        }
        if used_project_rate_for_clip_alignment {
            note.push_str(
                " wavetrack.rate metadata was unavailable; used project sample_rate for clip alignment.",
            );
        }
        if !overlap_channels.is_empty() {
            note.push_str(&format!(
                " Overlap detected in channels={}; overlapping regions were resolved with deterministic clip precedence.",
                format_i64_list(&overlap_channels)
            ));
        }

        return Ok(json!({
            "mode": "single_file",
            "requested_output_path": as_path_string(audio_output_path),
            "output_path": as_path_string(&output_file),
            "path_was_normalized": output_file != audio_output_path,
            "channel_count": 1,
            "files": [{
                "channel": plan.channel,
                "audio_path": as_path_string(&output_file),
                "written_audio_bytes": written,
            }],
            "sample_rate": resolved_output_sample_rate,
            "sample_width_bytes": sample_width,
            "wav_format_code": wav_format_code,
            "sampleformat": sampleformat_info,
            "total_written_audio_bytes": written,
            "note": note,
        }));
    }

    // No channel refs available, fallback to blockid order (streaming write).
    let default_file_name = make_output_filename(0, &channel_track_names, &mut HashMap::new());
    let file_name = extract_original_audio_name_base(project_parsed)
        .map(|base| format!("{base}.wav"))
        .unwrap_or(default_file_name);
    let output_file = resolve_single_channel_output_file(audio_output_path, &file_name);

    let total_sample_bytes = blockid_order.iter().try_fold(0usize, |acc, block_id| {
        let payload = block_samples.get(block_id).ok_or_else(|| {
            AupError::InvalidInput(format!(
                "Block missing during fallback blockid-order export: blockid={block_id}"
            ))
        })?;
        acc.checked_add(payload.len()).ok_or_else(|| {
            AupError::InvalidInput("Overflow while computing fallback payload size".to_string())
        })
    })?;

    let data_len = u32::try_from(total_sample_bytes)
        .map_err(|_| AupError::InvalidInput("WAV payload is too large for RIFF container".to_string()))?;
    if let Some(parent) = output_file.parent() {
        std::fs::create_dir_all(parent)?;
    }
    let file = File::create(&output_file)?;
    let mut writer = BufWriter::new(file);
    write_wav_header(
        &mut writer,
        data_len,
        1,
        sample_width_u16,
        wav_format_code,
        sample_rate_u32,
    )?;
    for block_id in blockid_order {
        if let Some(payload) = block_samples.get(&block_id) {
            writer.write_all(payload)?;
        }
    }
    writer.flush()?;

    let note = if !(used_channel_timeline_renderer || used_clip_timeline_renderer) {
        "Single-channel fallback WAV export by blockid order because channel timeline refs were unavailable."
            .to_string()
    } else {
        "Single-channel fallback WAV export by blockid order.".to_string()
    };

    Ok(json!({
        "mode": "single_file",
        "requested_output_path": as_path_string(audio_output_path),
        "output_path": as_path_string(&output_file),
        "path_was_normalized": output_file != audio_output_path,
        "channel_count": 1,
        "files": [{
            "channel": 0,
            "audio_path": as_path_string(&output_file),
            "written_audio_bytes": total_sample_bytes,
        }],
        "sample_rate": resolved_output_sample_rate,
        "sample_width_bytes": sample_width,
        "wav_format_code": wav_format_code,
        "sampleformat": sampleformat_info,
        "total_written_audio_bytes": total_sample_bytes,
        "note": note,
    }))
}

pub fn py_json_to_value(py: pyo3::Python<'_>, object: &pyo3::PyObject) -> pyo3::PyResult<Value> {
    fn convert(value: &pyo3::Bound<'_, pyo3::PyAny>) -> pyo3::PyResult<Value> {
        if value.is_none() {
            return Ok(Value::Null);
        }

        if let Ok(dict) = value.downcast::<PyDict>() {
            let mut map = Map::new();
            for (key, item) in dict.iter() {
                let key_text = if let Ok(text) = key.extract::<String>() {
                    text
                } else {
                    key.str()?.to_str()?.to_string()
                };
                map.insert(key_text, convert(&item)?);
            }
            return Ok(Value::Object(map));
        }

        if let Ok(list) = value.downcast::<PyList>() {
            let mut out = Vec::with_capacity(list.len());
            for item in list.iter() {
                out.push(convert(&item)?);
            }
            return Ok(Value::Array(out));
        }

        if let Ok(tuple) = value.downcast::<PyTuple>() {
            let mut out = Vec::with_capacity(tuple.len());
            for item in tuple.iter() {
                out.push(convert(&item)?);
            }
            return Ok(Value::Array(out));
        }

        if let Ok(flag) = value.extract::<bool>() {
            return Ok(Value::Bool(flag));
        }
        if let Ok(number) = value.extract::<i64>() {
            return Ok(Value::Number(Number::from(number)));
        }
        if let Ok(number) = value.extract::<u64>() {
            return Ok(Value::Number(Number::from(number)));
        }
        if let Ok(number) = value.extract::<f64>() {
            return Ok(Number::from_f64(number)
                .map(Value::Number)
                .unwrap_or(Value::Null));
        }
        if let Ok(text) = value.extract::<String>() {
            return Ok(Value::String(text));
        }

        let type_name = value.get_type().name()?.to_str()?.to_string();
        Err(pyo3::exceptions::PyValueError::new_err(format!(
            "Unsupported value type for JSON conversion: {type_name}",
        )))
    }

    convert(&object.bind(py))
}
