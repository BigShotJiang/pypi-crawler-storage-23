use std::fmt::{Display, Formatter};

#[derive(Debug)]
pub enum AupError {
    Io(std::io::Error),
    Sqlite(rusqlite::Error),
    Parse(String),
    InvalidInput(String),
}

pub type Result<T> = std::result::Result<T, AupError>;

impl Display for AupError {
    fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Io(err) => write!(f, "I/O error: {err}"),
            Self::Sqlite(err) => write!(f, "SQLite error: {err}"),
            Self::Parse(message) => write!(f, "Parse error: {message}"),
            Self::InvalidInput(message) => write!(f, "{message}"),
        }
    }
}

impl std::error::Error for AupError {}

impl From<std::io::Error> for AupError {
    fn from(value: std::io::Error) -> Self {
        Self::Io(value)
    }
}

impl From<rusqlite::Error> for AupError {
    fn from(value: rusqlite::Error) -> Self {
        Self::Sqlite(value)
    }
}
