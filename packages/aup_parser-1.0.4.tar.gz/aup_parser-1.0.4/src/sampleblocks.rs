use std::collections::{BTreeMap, BTreeSet, HashMap};

use rusqlite::{types::ValueRef, Connection};
use serde_json::{json, Number, Value};

use crate::error::Result;
use crate::types::{safe_int, sampleformat_to_value, value_from_f64, MAX_TRACK_NAME_PREVIEW};

fn value_ref_to_i64(value_ref: ValueRef<'_>) -> Option<i64> {
    match value_ref {
        ValueRef::Null => None,
        ValueRef::Integer(value) => Some(value),
        ValueRef::Real(value) => {
            if value.fract() == 0.0 {
                Some(value as i64)
            } else {
                None
            }
        }
        ValueRef::Text(bytes) => std::str::from_utf8(bytes).ok()?.trim().parse::<i64>().ok(),
        ValueRef::Blob(_) => None,
    }
}

fn value_ref_to_json(value_ref: ValueRef<'_>) -> Value {
    match value_ref {
        ValueRef::Null => Value::Null,
        ValueRef::Integer(value) => Value::Number(Number::from(value)),
        ValueRef::Real(value) => value_from_f64(value),
        ValueRef::Text(bytes) => Value::String(String::from_utf8_lossy(bytes).to_string()),
        ValueRef::Blob(bytes) => Value::String(format!("<blob:{}>", bytes.len())),
    }
}

pub fn extract_channel_block_refs(project_parsed: &Value) -> BTreeMap<i64, Vec<(i64, i64)>> {
    let mut channel_map: BTreeMap<i64, Vec<(i64, i64)>> = BTreeMap::new();

    let Some(items) = project_parsed
        .get("channel_wave_blocks")
        .and_then(Value::as_array)
    else {
        return channel_map;
    };

    for item in items {
        let channel = item.get("channel").and_then(safe_int);
        let block_id = item.get("blockid").and_then(safe_int);
        let start = item.get("start").and_then(safe_int);

        if let (Some(channel), Some(block_id), Some(start)) = (channel, block_id, start) {
            channel_map
                .entry(channel)
                .or_default()
                .push((start, block_id));
        }
    }

    let mut ordered_map: BTreeMap<i64, Vec<(i64, i64)>> = BTreeMap::new();
    for (channel, mut refs) in channel_map {
        refs.sort_unstable_by_key(|(start, block_id)| (*start, *block_id));
        refs.dedup();
        ordered_map.insert(channel, refs);
    }

    ordered_map
}

pub fn collect_sampleblocks_info(
    conn: &Connection,
    sample_rate: Option<f64>,
    used_block_ids: Option<&BTreeSet<i64>>,
    channel_block_refs: Option<&BTreeMap<i64, Vec<(i64, i64)>>>,
) -> Result<Value> {
    let mut table_names: BTreeSet<String> = BTreeSet::new();
    {
        let mut table_stmt = conn.prepare("SELECT name FROM sqlite_master WHERE type='table'")?;
        let mut rows = table_stmt.query([])?;
        while let Some(row) = rows.next()? {
            let name: String = row.get(0)?;
            table_names.insert(name);
        }
    }

    if !table_names.contains("sampleblocks") {
        return Ok(json!({"available": false}));
    }

    let mut stmt = conn.prepare(
        r#"
        SELECT
          blockid,
          sampleformat,
          summin,
          summax,
          sumrms,
          LENGTH(summary256),
          LENGTH(summary64k),
          LENGTH(samples)
        FROM sampleblocks
        ORDER BY blockid
        "#,
    )?;

    let mut rows = stmt.query([])?;
    let mut row_count = 0usize;
    let mut block_previews = Vec::new();
    let mut sampleformat_count: HashMap<String, i64> = HashMap::new();
    let mut sample_width_count: BTreeMap<i64, i64> = BTreeMap::new();
    let mut total_sample_bytes: i64 = 0;
    let mut total_summary256_bytes: i64 = 0;
    let mut total_summary64k_bytes: i64 = 0;
    let mut block_sample_count_by_id: BTreeMap<i64, Option<i64>> = BTreeMap::new();
    let mut sampleformat_variants_raw: BTreeSet<i64> = BTreeSet::new();
    let mut existing_block_ids: BTreeSet<i64> = BTreeSet::new();

    while let Some(row) = rows.next()? {
        row_count += 1;

        let block_id = row.get_ref(0).ok().and_then(value_ref_to_i64);
        let sampleformat_raw = row.get_ref(1).ok().and_then(value_ref_to_i64).unwrap_or(0);
        let summin = row.get_ref(2).map(value_ref_to_json).unwrap_or(Value::Null);
        let summax = row.get_ref(3).map(value_ref_to_json).unwrap_or(Value::Null);
        let sumrms = row.get_ref(4).map(value_ref_to_json).unwrap_or(Value::Null);
        let summary256_len = row.get_ref(5).ok().and_then(value_ref_to_i64).unwrap_or(0);
        let summary64k_len = row.get_ref(6).ok().and_then(value_ref_to_i64).unwrap_or(0);
        let samples_len = row.get_ref(7).ok().and_then(value_ref_to_i64).unwrap_or(0);

        let sampleformat_info = sampleformat_to_value(sampleformat_raw);
        *sampleformat_count
            .entry(sampleformat_raw.to_string())
            .or_insert(0) += 1;

        let sample_width = sampleformat_raw >> 16;
        *sample_width_count.entry(sample_width).or_insert(0) += 1;

        total_sample_bytes += samples_len;
        total_summary256_bytes += summary256_len;
        total_summary64k_bytes += summary64k_len;

        let exact_block_sample_count =
            if (1..=4).contains(&sample_width) && samples_len % sample_width == 0 {
                Some(samples_len / sample_width)
            } else {
                None
            };

        if let Some(block_id) = block_id {
            existing_block_ids.insert(block_id);
            block_sample_count_by_id.insert(block_id, exact_block_sample_count);
            sampleformat_variants_raw.insert(sampleformat_raw);
        }

        if block_previews.len() < MAX_TRACK_NAME_PREVIEW {
            block_previews.push(json!({
                "blockid": block_id,
                "sampleformat": sampleformat_info,
                "summin": summin,
                "summax": summax,
                "sumrms": sumrms,
                "summary256_bytes": summary256_len,
                "summary64k_bytes": summary64k_len,
                "samples_bytes": samples_len,
                "exact_sample_count": exact_block_sample_count,
            }));
        }
    }

    if row_count == 0 {
        return Ok(json!({"available": true, "count": 0}));
    }

    let mut total_samples: Option<i64> = None;
    let mut duration_seconds: Option<f64> = None;
    let mut exactness_notes: BTreeSet<String> = BTreeSet::new();
    let mut per_channel_last_sample: BTreeMap<String, i64> = BTreeMap::new();
    let mut channel_block_ref_count_by_channel: BTreeMap<String, i64> = BTreeMap::new();

    let mut channel_count: Option<i64> = None;

    if let Some(channel_refs) = channel_block_refs {
        if !channel_refs.is_empty() {
            channel_count = Some(channel_refs.len() as i64);
            let mut exact = true;
            for (channel, refs) in channel_refs {
                channel_block_ref_count_by_channel.insert(channel.to_string(), refs.len() as i64);
                let mut last_sample = 0i64;

                for (start, block_id) in refs {
                    if *start < 0 {
                        exact = false;
                        exactness_notes.insert(format!(
                            "negative_start_sample(channel={channel}, blockid={block_id}, start={start})"
                        ));
                        break;
                    }

                    match block_sample_count_by_id.get(block_id) {
                        Some(Some(block_samples)) => {
                            let end_sample = *start + *block_samples;
                            if end_sample > last_sample {
                                last_sample = end_sample;
                            }
                        }
                        Some(None) => {
                            exact = false;
                            exactness_notes.insert(format!(
                                "block_sample_count_not_exact(blockid={block_id})"
                            ));
                            break;
                        }
                        None => {
                            exact = false;
                            exactness_notes.insert(format!(
                                "referenced_block_missing_in_sampleblocks(blockid={block_id})"
                            ));
                            break;
                        }
                    }
                }

                if !exact {
                    break;
                }

                per_channel_last_sample.insert(channel.to_string(), last_sample);
            }

            if exact && !per_channel_last_sample.is_empty() {
                total_samples = per_channel_last_sample.values().max().copied();
                if let (Some(samples), Some(rate)) = (total_samples, sample_rate) {
                    if rate > 0.0 {
                        duration_seconds =
                            Some(((samples as f64 / rate) * 1_000_000.0).round() / 1_000_000.0);
                    } else {
                        exactness_notes
                            .insert("duration_seconds_requires_positive_sample_rate".to_string());
                    }
                }
            } else if exact {
                exactness_notes.insert("no_channel_block_refs_after_validation".to_string());
            }
        } else {
            exactness_notes.insert("no_channel_block_refs_in_project_payload".to_string());
        }
    } else {
        exactness_notes.insert("no_channel_block_refs_in_project_payload".to_string());
    }

    let sampleformat_variants = sampleformat_variants_raw
        .iter()
        .copied()
        .map(sampleformat_to_value)
        .collect::<Vec<_>>();
    let sampleformat_is_uniform = sampleformat_variants.len() == 1;
    let sampleformat = if sampleformat_is_uniform {
        sampleformat_variants
            .first()
            .cloned()
            .unwrap_or(Value::Null)
    } else {
        Value::Null
    };

    if !sampleformat_is_uniform && !sampleformat_variants.is_empty() {
        exactness_notes.insert("multiple_sampleformat_variants_detected".to_string());
    }

    let mut result = json!({
        "available": true,
        "count": row_count,
        "total_sample_bytes": total_sample_bytes,
        "total_summary256_bytes": total_summary256_bytes,
        "total_summary64k_bytes": total_summary64k_bytes,
        "total_samples": total_samples,
        "sample_rate": sample_rate,
        "channel_count": channel_count,
        "duration_seconds": duration_seconds,
        "sampleformat": sampleformat,
        "sampleformat_is_uniform": sampleformat_is_uniform,
        "sampleformat_variants": sampleformat_variants,
        "sampleformat_count": sampleformat_count,
        "sample_width_count": sample_width_count,
        "per_channel_last_sample": per_channel_last_sample,
        "channel_block_ref_count_by_channel": channel_block_ref_count_by_channel,
        "exactness_notes": exactness_notes.into_iter().collect::<Vec<_>>(),
        "blocks_preview": block_previews,
    });

    if let Some(used_block_ids) = used_block_ids {
        let missing_block_ids = used_block_ids
            .difference(&existing_block_ids)
            .copied()
            .collect::<Vec<_>>();
        let unused_block_ids = existing_block_ids
            .difference(used_block_ids)
            .copied()
            .collect::<Vec<_>>();

        if let Some(result_map) = result.as_object_mut() {
            result_map.insert(
                "timeline_used_block_ids".to_string(),
                json!(used_block_ids.iter().copied().collect::<Vec<_>>()),
            );
            result_map.insert(
                "missing_timeline_block_ids_in_sampleblocks".to_string(),
                json!(missing_block_ids),
            );
            result_map.insert(
                "unused_sampleblocks_not_referenced_by_timeline".to_string(),
                json!(unused_block_ids),
            );
        }
    }

    Ok(result)
}
