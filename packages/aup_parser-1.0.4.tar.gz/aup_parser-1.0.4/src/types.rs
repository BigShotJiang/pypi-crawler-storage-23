use serde::Serialize;
use serde_json::{json, Number, Value};

pub const MAX_TEXT_PREVIEW: usize = 200;
pub const MAX_TRACK_NAME_PREVIEW: usize = 20;
pub const PROJECT_LIKE_TABLES: [&str; 2] = ["project", "autosave"];

pub const FT_CHAR_SIZE: u8 = 0;
pub const FT_START_TAG: u8 = 1;
pub const FT_END_TAG: u8 = 2;
pub const FT_STRING: u8 = 3;
pub const FT_INT: u8 = 4;
pub const FT_BOOL: u8 = 5;
pub const FT_LONG: u8 = 6;
pub const FT_LONG_LONG: u8 = 7;
pub const FT_SIZE_T: u8 = 8;
pub const FT_FLOAT: u8 = 9;
pub const FT_DOUBLE: u8 = 10;
pub const FT_DATA: u8 = 11;
pub const FT_RAW: u8 = 12;
pub const FT_PUSH: u8 = 13;
pub const FT_POP: u8 = 14;
pub const FT_NAME: u8 = 15;

#[derive(Debug, Clone, Serialize)]
pub struct SampleFormatInfo {
    pub raw: i64,
    pub sample_width_bytes: i64,
    pub encoding_id: i64,
}

impl SampleFormatInfo {
    pub fn from_raw(raw: i64) -> Self {
        Self {
            raw,
            sample_width_bytes: raw >> 16,
            encoding_id: raw & 0xFFFF,
        }
    }

    pub fn to_value(&self) -> Value {
        json!({
            "raw": self.raw,
            "sample_width_bytes": self.sample_width_bytes,
            "encoding_id": self.encoding_id,
        })
    }
}

pub fn sampleformat_to_value(raw: i64) -> Value {
    SampleFormatInfo::from_raw(raw).to_value()
}

pub fn value_from_f64(value: f64) -> Value {
    Number::from_f64(value)
        .map(Value::Number)
        .unwrap_or(Value::Null)
}

pub fn safe_int(value: &Value) -> Option<i64> {
    match value {
        Value::Null => None,
        Value::Bool(flag) => Some(i64::from(*flag)),
        Value::Number(number) => {
            if let Some(integer) = number.as_i64() {
                return Some(integer);
            }
            if let Some(float_value) = number.as_f64() {
                if float_value.fract() == 0.0 {
                    return Some(float_value as i64);
                }
            }
            None
        }
        Value::String(text) => {
            let stripped = text.trim();
            if stripped.is_empty() {
                return None;
            }
            stripped.parse::<i64>().ok()
        }
        _ => None,
    }
}

pub fn safe_float(value: &Value) -> Option<f64> {
    match value {
        Value::Null => None,
        Value::Number(number) => number.as_f64(),
        Value::String(text) => text.trim().parse::<f64>().ok(),
        Value::Bool(flag) => Some(if *flag { 1.0 } else { 0.0 }),
        _ => None,
    }
}
