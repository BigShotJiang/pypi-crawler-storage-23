use std::collections::HashMap;

use serde::Serialize;
use serde_json::{Map, Number, Value};

use crate::error::{AupError, Result};
use crate::types::{
    value_from_f64, FT_BOOL, FT_CHAR_SIZE, FT_DATA, FT_DOUBLE, FT_END_TAG, FT_FLOAT, FT_INT,
    FT_LONG, FT_LONG_LONG, FT_NAME, FT_POP, FT_PUSH, FT_RAW, FT_SIZE_T, FT_START_TAG, FT_STRING,
};

#[derive(Debug, Clone, Serialize)]
pub struct XmlNode {
    pub tag: String,
    pub attrs: Map<String, Value>,
    pub children: Vec<XmlNode>,
    pub data: String,
}

#[derive(Debug, Clone)]
pub struct ParsedBinaryTree {
    pub root: XmlNode,
    pub leading_data: Vec<String>,
    pub raw_data: Vec<String>,
    pub dictionary_tokens: Vec<String>,
    pub dictionary_token_count: usize,
}

struct BinaryXmlStream {
    data: Vec<u8>,
    offset: usize,
    char_size: u8,
}

impl BinaryXmlStream {
    fn new(dict_blob: &[u8], doc_blob: &[u8]) -> Self {
        let mut data = Vec::with_capacity(dict_blob.len() + doc_blob.len());
        data.extend_from_slice(dict_blob);
        data.extend_from_slice(doc_blob);
        Self {
            data,
            offset: 0,
            char_size: 0,
        }
    }

    fn is_eof(&self) -> bool {
        self.offset >= self.data.len()
    }

    fn read(&mut self, size: usize) -> Result<&[u8]> {
        let end = self.offset.saturating_add(size);
        if end > self.data.len() {
            return Err(AupError::Parse(format!(
                "Unexpected EOF while reading {size} bytes at offset {}",
                self.offset
            )));
        }
        let chunk = &self.data[self.offset..end];
        self.offset = end;
        Ok(chunk)
    }

    fn read_u8(&mut self) -> Result<u8> {
        Ok(self.read(1)?[0])
    }

    fn read_u16(&mut self) -> Result<u16> {
        let chunk = self.read(2)?;
        Ok(u16::from_le_bytes([chunk[0], chunk[1]]))
    }

    fn read_u32(&mut self) -> Result<u32> {
        let chunk = self.read(4)?;
        Ok(u32::from_le_bytes([chunk[0], chunk[1], chunk[2], chunk[3]]))
    }

    fn read_i32(&mut self) -> Result<i32> {
        let chunk = self.read(4)?;
        Ok(i32::from_le_bytes([chunk[0], chunk[1], chunk[2], chunk[3]]))
    }

    fn read_i64(&mut self) -> Result<i64> {
        let chunk = self.read(8)?;
        Ok(i64::from_le_bytes([
            chunk[0], chunk[1], chunk[2], chunk[3], chunk[4], chunk[5], chunk[6], chunk[7],
        ]))
    }

    fn read_f32(&mut self) -> Result<f32> {
        let chunk = self.read(4)?;
        Ok(f32::from_le_bytes([chunk[0], chunk[1], chunk[2], chunk[3]]))
    }

    fn read_f64(&mut self) -> Result<f64> {
        let chunk = self.read(8)?;
        Ok(f64::from_le_bytes([
            chunk[0], chunk[1], chunk[2], chunk[3], chunk[4], chunk[5], chunk[6], chunk[7],
        ]))
    }

    fn read_bool(&mut self) -> Result<bool> {
        Ok(self.read_u8()? != 0)
    }

    fn read_string(&mut self, use_u32_length: bool) -> Result<String> {
        if self.char_size == 0 {
            return Err(AupError::Parse(
                "Character size has not been initialized in binary XML stream".to_string(),
            ));
        }

        let byte_length = if use_u32_length {
            self.read_u32()? as usize
        } else {
            self.read_u16()? as usize
        };

        let char_size = self.char_size;
        let raw = self.read(byte_length)?.to_vec();
        let decoded = match char_size {
            1 => String::from_utf8_lossy(&raw).to_string(),
            2 => {
                let mut units = Vec::with_capacity(raw.len() / 2);
                for bytes in raw.chunks_exact(2) {
                    units.push(u16::from_le_bytes([bytes[0], bytes[1]]));
                }
                String::from_utf16_lossy(&units)
            }
            4 => {
                let mut out = String::new();
                for bytes in raw.chunks_exact(4) {
                    let code = u32::from_le_bytes([bytes[0], bytes[1], bytes[2], bytes[3]]);
                    if let Some(ch) = char::from_u32(code) {
                        out.push(ch);
                    }
                }
                out
            }
            size => {
                return Err(AupError::Parse(format!(
                    "Unsupported character size in binary XML stream: {size}"
                )))
            }
        };

        Ok(decoded)
    }
}

fn placeholder_token(token_id: u16) -> String {
    format!("__id_{token_id}")
}

pub fn parse_binary_xml_project(dict_blob: &[u8], doc_blob: &[u8]) -> Result<ParsedBinaryTree> {
    let mut stream = BinaryXmlStream::new(dict_blob, doc_blob);
    let mut lookup: HashMap<u16, String> = HashMap::new();
    let mut stack: Vec<XmlNode> = Vec::new();
    let mut root_nodes: Vec<XmlNode> = Vec::new();
    let mut leading_data: Vec<String> = Vec::new();
    let mut raw_data: Vec<String> = Vec::new();

    while !stream.is_eof() {
        let opcode_offset = stream.offset;
        let opcode = stream.read_u8()?;

        match opcode {
            FT_CHAR_SIZE => {
                stream.char_size = stream.read_u8()?;
            }
            FT_NAME => {
                let token_id = stream.read_u16()?;
                let token_name = stream.read_string(false)?;
                lookup.insert(token_id, token_name);
            }
            FT_START_TAG => {
                let token_id = stream.read_u16()?;
                let node: XmlNode = XmlNode {
                    tag: lookup
                        .get(&token_id)
                        .cloned()
                        .unwrap_or_else(|| placeholder_token(token_id)),
                    attrs: Map::new(),
                    children: Vec::new(),
                    data: String::new(),
                };
                stack.push(node);
            }
            FT_END_TAG => {
                let _ = stream.read_u16()?;
                let node = stack.pop().ok_or_else(|| {
                    AupError::Parse(format!("Unbalanced end tag at offset {opcode_offset}"))
                })?;

                if let Some(parent) = stack.last_mut() {
                    parent.children.push(node);
                } else {
                    root_nodes.push(node);
                }
            }
            FT_STRING | FT_INT | FT_BOOL | FT_LONG | FT_LONG_LONG | FT_SIZE_T | FT_FLOAT
            | FT_DOUBLE => {
                let token_id = stream.read_u16()?;
                let attr_name = lookup
                    .get(&token_id)
                    .cloned()
                    .unwrap_or_else(|| placeholder_token(token_id));
                let current = stack.last_mut().ok_or_else(|| {
                    AupError::Parse(format!(
                        "Attribute opcode {opcode} appeared outside tag context at offset {opcode_offset}"
                    ))
                })?;

                let value = match opcode {
                    FT_STRING => Value::String(stream.read_string(true)?),
                    FT_INT | FT_LONG => Value::Number(Number::from(stream.read_i32()?)),
                    FT_BOOL => Value::Bool(stream.read_bool()?),
                    FT_LONG_LONG => Value::Number(Number::from(stream.read_i64()?)),
                    FT_SIZE_T => Value::Number(Number::from(stream.read_u32()?)),
                    FT_FLOAT => {
                        let number = stream.read_f32()? as f64;
                        let _ = stream.read_u32()?;
                        value_from_f64(number)
                    }
                    FT_DOUBLE => {
                        let number = stream.read_f64()?;
                        let _ = stream.read_u32()?;
                        value_from_f64(number)
                    }
                    _ => Value::Null,
                };

                current.attrs.insert(attr_name, value);
            }
            FT_DATA => {
                let data = stream.read_string(true)?;
                if let Some(current) = stack.last_mut() {
                    current.data.push_str(&data);
                } else {
                    leading_data.push(data);
                }
            }
            FT_RAW => {
                raw_data.push(stream.read_string(true)?);
            }
            FT_PUSH | FT_POP => {}
            other => {
                return Err(AupError::Parse(format!(
                    "Unsupported opcode {other} at offset {opcode_offset}"
                )))
            }
        }
    }

    if !stack.is_empty() {
        return Err(AupError::Parse(
            "Binary XML parse finished with unclosed tags".to_string(),
        ));
    }
    if root_nodes.is_empty() {
        return Err(AupError::Parse(
            "No root nodes found while parsing binary XML".to_string(),
        ));
    }

    let mut token_entries: Vec<(u16, String)> = lookup.into_iter().collect();
    token_entries.sort_by_key(|(token_id, _)| *token_id);
    let dictionary_tokens = token_entries
        .into_iter()
        .map(|(_, token)| token)
        .collect::<Vec<_>>();

    Ok(ParsedBinaryTree {
        root: root_nodes.remove(0),
        leading_data,
        raw_data,
        dictionary_token_count: dictionary_tokens.len(),
        dictionary_tokens,
    })
}
