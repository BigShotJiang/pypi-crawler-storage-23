mod audio_export;
mod binary_xml;
mod error;
mod inspect;
mod project_extract;
mod sampleblocks;
mod types;

use std::path::Path;

use pyo3::exceptions::{PyFileNotFoundError, PyRuntimeError, PyValueError};
use pyo3::prelude::*;
use pyo3::types::{PyDict, PyList};
use serde_json::Value;

use crate::error::AupError;

fn json_to_py(py: Python<'_>, value: &Value) -> PyObject {
    match value {
        Value::Null => py.None(),
        Value::Bool(flag) => flag.into_py(py),
        Value::Number(number) => {
            if let Some(i) = number.as_i64() {
                i.into_py(py)
            } else if let Some(u) = number.as_u64() {
                u.into_py(py)
            } else if let Some(f) = number.as_f64() {
                f.into_py(py)
            } else {
                py.None()
            }
        }
        Value::String(text) => text.into_py(py),
        Value::Array(items) => {
            let list = PyList::empty_bound(py);
            for item in items {
                let _ = list.append(json_to_py(py, item));
            }
            list.into_py(py)
        }
        Value::Object(map) => {
            let dict = PyDict::new_bound(py);
            for (key, item) in map {
                let _ = dict.set_item(key, json_to_py(py, item));
            }
            dict.into_py(py)
        }
    }
}

fn map_error(error: AupError) -> PyErr {
    let message = error.to_string();
    match error {
        AupError::InvalidInput(message) => {
            if message.starts_with("File not found:") {
                PyFileNotFoundError::new_err(message)
            } else {
                PyValueError::new_err(message)
            }
        }
        _ => PyRuntimeError::new_err(message),
    }
}

#[pyfunction(signature = (path, profile = "full"))]
fn inspect_core(py: Python<'_>, path: String, profile: &str) -> PyResult<PyObject> {
    let parsed = inspect::inspect_profile(Path::new(&path), profile).map_err(map_error)?;
    Ok(json_to_py(py, &parsed))
}

#[pyfunction(signature = (path, audio_output_path = None))]
fn parse_core(
    py: Python<'_>,
    path: String,
    audio_output_path: Option<String>,
) -> PyResult<PyObject> {
    let full = inspect::inspect_profile(Path::new(&path), "full").map_err(map_error)?;
    let mut result = full.clone();

    if let Some(audio_output_path) = audio_output_path {
        let project_parsed = full.get("project_payload").and_then(|item| item.get("parsed"));
        let exported = audio_export::export_audio_output_core(
            Path::new(&path),
            Path::new(&audio_output_path),
            project_parsed,
        )
        .map_err(map_error)?;

        if let Some(result_map) = result.as_object_mut() {
            let exports = result_map
                .entry("exports".to_string())
                .or_insert_with(|| Value::Object(Default::default()));
            if !exports.is_object() {
                *exports = Value::Object(Default::default());
            }
            if let Some(exports_map) = exports.as_object_mut() {
                exports_map.insert("audio_output".to_string(), exported);
            }
        }
    }

    Ok(json_to_py(py, &result))
}

#[pyfunction(signature = (aup3_path, audio_output_path, project_parsed = None))]
fn export_audio_output_core(
    py: Python<'_>,
    aup3_path: String,
    audio_output_path: String,
    project_parsed: Option<PyObject>,
) -> PyResult<PyObject> {
    let project_value = match project_parsed {
        Some(object) => Some(audio_export::py_json_to_value(py, &object)?),
        None => None,
    };

    let exported = audio_export::export_audio_output_core(
        Path::new(&aup3_path),
        Path::new(&audio_output_path),
        project_value.as_ref(),
    )
    .map_err(map_error)?;

    Ok(json_to_py(py, &exported))
}

#[pymodule]
fn _core(_py: Python<'_>, module: &Bound<'_, PyModule>) -> PyResult<()> {
    module.add_function(wrap_pyfunction!(inspect_core, module)?)?;
    module.add_function(wrap_pyfunction!(parse_core, module)?)?;
    module.add_function(wrap_pyfunction!(export_audio_output_core, module)?)?;
    Ok(())
}
