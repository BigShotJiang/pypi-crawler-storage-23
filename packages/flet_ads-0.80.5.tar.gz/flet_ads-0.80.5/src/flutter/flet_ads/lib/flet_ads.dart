library flet_ads;

export "src/extension.dart" show Extension;
