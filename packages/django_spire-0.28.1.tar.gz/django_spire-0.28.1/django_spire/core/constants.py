TIME_UNITS_TO_SECONDS = {
    'year': 60*60*24*365,
    'week': 60*60*24*7,
    'day': 60*60*24,
    'hour': 60*60,
    'minute': 60,
    'second': 1
}