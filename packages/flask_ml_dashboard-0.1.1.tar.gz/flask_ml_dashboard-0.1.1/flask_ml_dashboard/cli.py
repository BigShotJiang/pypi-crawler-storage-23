import os
import click
from pathlib import Path

TEMPLATE_STRUCTURE = {
    "app.py": """from flask import Flask, render_template

app = Flask(__name__)

@app.route("/")
def dashboard():
    return render_template("dashboard.html")

if __name__ == "__main__":
    app.run(debug=True)
""",
    "ml/model.py": """# Model loading logic
def load_model():
    pass
""",
    "ml/train.py": """# Model training logic
def train():
    pass
""",
    "templates/dashboard.html": """<!DOCTYPE html>
<html>
<head>
    <title>ML Dashboard</title>
    <link rel="stylesheet" href="{{ url_for('static', filename='css/style.css') }}">
</head>
<body>
    <h1>ML Dashboard</h1>
    <script src="{{ url_for('static', filename='js/dashboard.js') }}"></script>
</body>
</html>
""",
    "static/css/style.css": """body { font-family: Arial; }""",
    "static/js/dashboard.js": """console.log("Dashboard Loaded");"""
}


@click.command("create-ml-dashboard")
@click.argument("project_name")
def create_ml_dashboard(project_name):
    """Create ML Dashboard project structure."""
    
    base_path = Path(project_name)

    if base_path.exists():
        click.echo("❌ Directory already exists.")
        return

    for path, content in TEMPLATE_STRUCTURE.items():
        file_path = base_path / path
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(content)

    # create empty data folder
    (base_path / "data").mkdir(parents=True, exist_ok=True)

    click.echo(f"✅ ML Dashboard '{project_name}' created successfully!")