from .cli import create_ml_dashboard

def init_app(app):
    app.cli.add_command(create_ml_dashboard)