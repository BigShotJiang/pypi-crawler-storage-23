from endstone_easyluckypillar.easyluckypillar_plugin import EasyLuckyPillarPlugin

__all__ = ["EasyLuckyPillarPlugin"]
