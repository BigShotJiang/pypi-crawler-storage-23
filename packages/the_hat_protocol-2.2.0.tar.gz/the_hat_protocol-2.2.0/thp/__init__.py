"""
The Hat Protocol (THP) — HUXmesh v2.2.0
AI Governance Middleware — Three-Layer Governance
"We don't make AI. We make AI behave."

The Hat Protocol Inc. | Patent Pending | SDVOSB | Chattanooga, Tennessee

Core imports:
    from thp import THPCore       # Full governance engine
    from thp import THPGuard      # Alias for THPCore (developer-friendly)
    from thp import NHI           # Simplified NHI interface
    from thp import RiskLevel     # GREEN/YELLOW/RED/SUPER_HUX
    from thp import Zone          # CHILD/ADULT/POLITICAL/SENSITIVE/STANDARD
    from thp import DriftDetector # Cross-turn manipulation detection
    from thp import QuintLoop     # Five-council deliberation engine
    from thp import ReceiptLogger # Tamper-evident audit trail
    from thp import HUXmesh      # Governance handoff generator
    from thp import HUXbomb      # Truth verification engine
"""

from .core import THPCore, THPResult, RiskLevel
from .nhi_interface import NHI
from .zones import Zone
from .huxbomb import HUXbomb, TruthLevel
from .haf_validator import HAFValidator, HAFResult
from .receipts import ReceiptLogger
from .axioms import AxiomEngine
from .huxmesh import HUXmesh, HUXmeshHandoff
from .domes import DomeEvaluator, DomeResult
from .quintloop import QuintLoop, QuintLoopDecision, ElementVerdict

# Developer-friendly aliases
THPGuard = THPCore
DriftDetector = THPCore  # DriftDetector is integrated into THPCore

__version__ = "2.2.0"
__author__ = "The Hat Protocol Inc. / Mr. C — SDVOSB"
__all__ = [
    "THPCore", "THPGuard", "THPResult", "RiskLevel",
    "NHI",
    "Zone",
    "HUXbomb", "TruthLevel",
    "HAFValidator", "HAFResult",
    "ReceiptLogger",
    "AxiomEngine",
    "HUXmesh", "HUXmeshHandoff",
    "DomeEvaluator", "DomeResult",
    "QuintLoop", "QuintLoopDecision", "ElementVerdict",
    "DriftDetector",
]
