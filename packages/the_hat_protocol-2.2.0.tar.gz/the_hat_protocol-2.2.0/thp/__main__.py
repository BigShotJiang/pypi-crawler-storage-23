"""
thp/__main__.py — CLI for The Hat Protocol / HUXmesh v2.2.0
Usage:
    thp evaluate "some text to check"
    thp handoff --operator "Mr. C" --platform Claude --session live_production
    thp report
    thp version
    thp --show-wrapper
"""

import argparse
import json
import sys

from . import THPCore, HUXmesh, NHI, __version__


def cmd_evaluate(args):
    nhi = NHI()
    result = nhi.check_input(args.text)
    print(result.summary())
    if args.json:
        print(json.dumps({
            "passed": result.passed,
            "risk_level": result.risk_level.value,
            "zone": result.zone.value,
            "violations": result.violations,
            "warnings": result.warnings,
        }, indent=2))


def cmd_handoff(args):
    mesh = HUXmesh()
    projects = args.projects.split(",") if args.projects else []
    handoff = mesh.generate_handoff(
        operator=args.operator,
        mission=args.mission or "General governed operation",
        platform=args.platform,
        session_type=args.session,
        active_projects=projects,
    )
    if args.json:
        print(handoff.as_json())
    else:
        print(handoff.as_prompt())


def cmd_report(args):
    nhi = NHI()
    report = nhi.report()
    if report:
        print(json.dumps(report, indent=2))
    else:
        print("No receipts found. Run some evaluations first.")


def cmd_version(args):
    print(f"The Hat Protocol (THP) — HUXmesh v{__version__}")
    print("AI Governance Middleware — Three-Layer Governance")
    print("\"We don't make AI. We make AI behave.\"")
    print()
    print("The Hat Protocol Inc. | Patent Pending | SDVOSB")
    print("Chattanooga, Tennessee")
    print()
    print("Human In Power. No Matter What.")


def main():
    parser = argparse.ArgumentParser(
        prog="thp",
        description="The Hat Protocol — AI Governance CLI — HUXmesh v" + __version__,
    )
    parser.add_argument("--show-wrapper", action="store_true",
                        help="Display the THP Mission Wrapper governance directive")
    sub = parser.add_subparsers(dest="command")

    # evaluate
    ev = sub.add_parser("evaluate", help="Evaluate text under THP governance")
    ev.add_argument("text", help="Text to evaluate")
    ev.add_argument("--json", action="store_true", help="Output as JSON")
    ev.set_defaults(func=cmd_evaluate)

    # handoff
    ho = sub.add_parser("handoff", help="Generate a HUXmesh AI instance handoff")
    ho.add_argument("--operator", default="Mr. C", help="Operator name")
    ho.add_argument("--platform", default="Claude", help="Target AI platform")
    ho.add_argument("--session", default="deep_work", help="Session type")
    ho.add_argument("--mission", default="", help="Session mission")
    ho.add_argument("--projects", default="", help="Comma-separated project names")
    ho.add_argument("--json", action="store_true", help="Output as JSON")
    ho.set_defaults(func=cmd_handoff)

    # report
    rp = sub.add_parser("report", help="Show governance stats from receipt log")
    rp.set_defaults(func=cmd_report)

    # version
    vr = sub.add_parser("version", help="Show version and build info")
    vr.set_defaults(func=cmd_version)

    args = parser.parse_args()

    if args.show_wrapper:
        print("THP Mission Wrapper is proprietary IP of The Hat Protocol Inc.")
        print("The wrapper is embedded in the HUXmesh KeyCard and injected")
        print("at the network layer during active governance sessions.")
        print()
        print("To view wrapper status in a governance report, run: thp report")
        sys.exit(0)

    if not args.command:
        parser.print_help()
        sys.exit(0)

    args.func(args)


if __name__ == "__main__":
    main()
