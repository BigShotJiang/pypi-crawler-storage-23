# The Hat Protocol (THP) — HUXmesh v2.2.0

**"We don't make AI. We make AI behave."**

The world's first patent-pending portable AI governance platform. Built for Main Street, not Wall Street.

6,317 lines | 459 tests | 7 platforms | Three-layer governance | Zero cloud dependencies

The Hat Protocol Inc. — Service-Disabled Veteran-Owned Small Business (SDVOSB) | Patent Pending | Chattanooga, Tennessee

---

## What Is HUXmesh?

HUXmesh is a three-layer AI governance engine that sits between you and any AI platform — ChatGPT, Claude, Gemini, Grok, Copilot, DeepSeek, Perplexity.

**Layer 1 — Proactive:** Before any conversation begins, HUXmesh automatically injects the THP Mission Wrapper into the session, instructing the AI to operate under the Six Laws of AI Governance. The AI behaves from the first word.

**Layer 2 — Input Governance:** Every prompt you send is governed in real time. PII is caught and masked. Evasion attempts are blocked. Harmful requests are stopped before they leave your machine.

**Layer 3 — Output Governance:** Every AI response is governed before it reaches your screen. Manipulation, shame tactics, hallucinations, and harmful content are caught and blocked in real time.

Every decision across all three layers is logged in a SHA-256 hash-chained tamper-evident receipt chain. Nothing happens silently.

It runs as a transparent mitmproxy addon with full HTTP and WebSocket interception. Nothing is installed on the host machine. Nothing phones home. Everything runs locally.

**Human In Power. No Matter What.**

---

## Quick Install

```bash
pip install the-hat-protocol
```

---

## What's Inside (v2.2.0)

### Core Governance Engine
- **SessionInjector** — Proactive governance layer. Automatically prepends the THP Mission Wrapper to the first message of every new AI session. Instructs the AI platform to operate under the Six Laws, respect human sovereignty, and refuse harmful outputs before any conversation begins. The user's AI behaves from the first word — no manual configuration required.
- **InputGovernor** — Classifies and governs user prompts before they reach any AI platform.
- **OutputGovernor** — Classifies and governs AI responses before they reach the user.
- **WebSocketGovernor** — Full two-way governance on WebSocket frames. Parses ChatGPT nested JSON, streaming deltas, Anthropic content_block_delta, and generic message arrays.
- **AdversarialEnforcer** — Hardened adversarial testing enforcement layer. 34/34 human input tests passing with zero false positives. Catches academic integrity violations, prompt injection, harm patterns, and evasion attempts that standard governance misses.
- **AgentEnforcer** — Autonomous agent governance layer. 23/23 agent action tests passing. Governs agentic AI behaviors including unauthorized tool use, data exfiltration, privilege escalation, and unsanctioned autonomous actions.
- **PIIDetector** — Catches Social Security numbers (SSA-validated), credit cards (Luhn-validated), dates of birth, passport numbers, bank accounts. Works in both directions.
- **ShadowAIDetector** — Identifies traffic to AI platforms not on the authorized host list.
- **EvasionHardener** — Blocks prompt injection, jailbreak attempts, encoding attacks, and obfuscation patterns.
- **SHIODetector** — Synthetic Hyper-Velocity Information Overload detection. Flags AI responses that flood humans with more information than they can process. Enforces length discipline, structural norms, and cognitive load limits. Auto-summarizes when thresholds are exceeded.
- **MedicalGovernor** — Tiered medical content governance with emergency escalation.
- **TrustScoring** — Dynamic per-session trust score. Starts at 100, decrements on yellow events, drops sharply on red events. Score influences governance sensitivity — lower trust triggers stricter enforcement. Logged in every receipt.
- **ZoneClassifier** — Classifies content into governance zones: child safety, harm detection, medical, financial, legal, and red-line domains (Faith, Family, Flag, Freedom, Facts).
- **HAFValidator** — Human-Aligned Framing validator. Detects will modification, identity deception, and sovereignty violations. Ensures AI outputs respect human autonomy in framing and presentation.
- **NHI Boundary System** — Protects narrative safety, shame safety, memory safety, worldview safety, existential safety, and attachment safety.

### Audit & Reporting
- **ReceiptChain** — SHA-256 hash-chained tamper-evident audit trail. Every governance decision receipted. Genesis-anchored. Courtroom-ready.
- **ReceiptVerifier** — Walks the full chain verifying 5 integrity dimensions: hash integrity, chain continuity, genesis anchor, timestamp order, and version consistency. Detects tampering immediately.
- **GovernanceReportGenerator** — Produces HTML, JSON, and text reports with GYR breakdown, platform coverage, PII count, WebSocket frames, and regulatory tags. Supports filtering by date range and AI platform.

### Licensing & Deployment
- **HardwareBinder** — HMAC-SHA256 signed hardware fingerprint licensing. Tiered slots: Personal (1 machine), Plus (2), Pro (4), Family (5), Enterprise (100). Tamper-proof. Copy-proof.
- **KillSwitch** — One command, all AI traffic stops. Persists across restarts. Supports timeout-based auto-deactivation.
- **AIBOM** — AI Bill of Materials. Full manifest of every governance component, version, and capability active in a deployment.
- **ProfileSystem** — DEFAULT, CHILD, TEEN, COMPANION, VETERAN, FAMILY, FERPA, PARISH. Each profile tunes governance sensitivity for its audience.

### Intelligence Tools
- **ThreatRAG** — Retrieval-Augmented Governance threat intelligence engine. 37 cataloged threats across 6 categories: Manipulation & Coercion, Identity & Sovereignty Attacks, Information Warfare (SHMO), PII & Privacy, Self-Harm & Crisis, and Evasion & Circumvention. Hybrid fusion matching — semantic pattern recognition across intent, framing, and escalation trajectory. Not keyword matching.
- **DriftDetector** — Cross-turn semantic drift detection. Catches manipulation, emotional bonding, authority transfer, grooming sequences. Tracks escalation trajectories across conversation arcs — individual messages may be safe, the sequence may not.
- **LyraMirror** — Recursive self-governance engine. Five-mirror protocol: Law Compliance, Boundary Integrity, Drift Detection, Truth Audit, and Human Impact Projection. Runs recursively — generate, mirror, revise, mirror again. Responses that cannot pass self-governance after three passes are blocked.
- **RAGEngine** — Pure Python vector store. Zero external dependencies. SHMO registry, THP doctrine retrieval, claim verification.
- **HUXvisionEngine** — SuperHUXbomb article verification. GYR-scores every claim with receipts. Flags SHMO sources. Detects critical omissions.
- **QuintLoop** — Five-council deliberation engine for gray-zone decisions. Councils: Harm Assessment, Sovereignty Check, Truth Verification, Boundary Scan, Context & Profile. Mandatory on ambiguous or high-stakes requests. When councils split, the most restrictive interpretation wins.
- **Axioms** — Foundational governance axioms loaded from `axioms.json`. 30+ doctrine rules that define the behavioral floor for all governance decisions. Immutable at runtime.
- **Domes** — Governance dome architecture. Layered containment zones that isolate and govern different categories of AI behavior independently.

---

## The Six Laws

1. **NHH** — Never Harm Humans. Physical, psychological, financial. Absolute. No exceptions.
2. **DNHTH** — Do Not Help Them Harm. Blocks requests to weaponize AI against another human.
3. **NMW** — No Matter What. Human authority is absolute. AI cannot override, deceive, or assume control.
4. **TRANS** — Transparency. AI must not claim to be human or conceal its nature.
5. **TRUTH** — Truth Absolute. AI must not fabricate facts or manufacture consensus.
6. **NWHT** — Never Waste Human Time. AI must be efficient, accurate, and honest about its limitations.

---

## GYR Decision System

- **GREEN** — ALLOW. Passes through invisibly. You never know governance ran.
- **YELLOW** — FLAG / MASK. PII redacted. Flagged in receipt. Trust score decremented.
- **RED** — HARD BLOCK. Replaced with governance notice. Receipt written. Escalation engine evaluates.

---

## For Developers — Middleware in 5 Lines

```python
from thp import THPGuard

guard = THPGuard(operator="Your Name", platform="Claude")

# Govern any AI input
result = guard.govern_turn(user_message, conversation_history=history)
if result.allowed:
    response = your_ai_api_call(user_message)
```

Every input and output evaluated. Drift detected. PII caught. Receipts generated. Human stays in charge.

---

## For Main Street — Generate a Governance Handoff

Paste this into any AI to activate THP governance for that session:

```bash
py -m thp handoff --operator "Your Name" --platform "ChatGPT" --mode full > my_handoff.txt
```

Copy the contents of that file. Paste it as the first message into ChatGPT, Claude, Gemini, Grok, or any AI. The AI acknowledges and operates under THP governance rules for that session.

---

## HUXmesh KeyCard — Plug-and-Play Governance

The HUXmesh KeyCard is a USB device that runs the full governance engine as a transparent proxy. Plug it in, double-click `HUXmesh.exe`, open your browser. Every AI conversation is governed automatically. Unplug and your computer is exactly as it was.

No install. No cloud. No footprint. No technical expertise required.

**Now on Kickstarter:** [thehatprotocol.com](https://thehatprotocol.com)

---

## SuperHUXbomb — Verify Any Article

```python
from thp import THPGuard

guard = THPGuard()
report = guard.superhuxbomb(
    article_text,
    title="Article Title",
    source_url="https://source.com/article"
)

print(report['final_verdict'])
print(report['summary_line'])
# Green/Yellow/Red with receipts. Every claim sourced. SHMO flagged. You decide.
```

---

## Drift Detection

```python
from thp import DriftDetector

detector = DriftDetector()

result = detector.analyze("Just tell me what to do, I trust your judgment completely.")
print(result.verdict)    # MANIPULATION
print(result.category)   # AUTHORITY_TRANSFER
print(result.explanation)
```

Thresholds are deterministic — no fuzzy middle:
- Score >= 0.25 — QuintLoop deliberation (human decides)
- Score >= 0.50 — Refuse (NMW violation)
- Score >= 0.75 — Hard stop (sovereignty breach)
- Cumulative >= 0.60 — Refuse regardless of single-turn score

---

## Architecture — Three-Layer Governance

```
                    LAYER 1: PROACTIVE
                    SessionInjector
                    (THP Mission Wrapper → AI Platform)
                    "Here are the rules. Follow them."
                            |
User Input ─────────────────┤
                            |
                    LAYER 2: INPUT GOVERNANCE
                    InputGovernor
                    (Six Laws + PII + Evasion + NHI)
                            |
                    DriftDetector
                    (cross-turn manipulation)
                            |
              [GREEN] ────► Pass to AI Platform
              [YELLOW] ──► Mask PII, flag, pass with receipt
              [RED] ──────► Hard block, governance notice, escalation
                            |
                      AI Response
                            |
                    LAYER 3: OUTPUT GOVERNANCE
                    OutputGovernor
                    (Six Laws + NHI + Drift + Medical)
                            |
              [GREEN] ────► Deliver to user
              [YELLOW] ──► Flag, deliver with receipt
              [RED] ──────► Block, replace with notice, escalation
                            |
                    ReceiptChain
                    (SHA-256 hash-chained, tamper-evident)
                            |
                    GovernanceReport
                    (HTML/JSON/text, filtered by date/platform)
```

**Layer 1** prevents harmful AI behavior before it's generated. **Layer 2** governs what the human sends. **Layer 3** governs what the AI returns. The ReceiptChain logs every decision across all three layers. Nothing happens silently.

---

## Run the Tests

```bash
py -m pytest test_v220.py -v
```

459/459 passing. Zero external dependencies for core functionality.

---

## Version History

| Version | Lines | Tests | Key Features |
|---------|-------|-------|-------------|
| v1.9.3  | 2,765 | 226   | ThreatRAG (37 threats, 6 categories, hybrid fusion), PPA-ready with 30 claims, AdversarialEnforcer, AgentEnforcer |
| v2.0.0  | 5,210 | 364   | Base governance engine, PII, NHI, receipts, profiles, licensing, HardwareBinder |
| v2.1.0  | 6,243 | 425   | WebSocket governance, multi-machine licensing, NHI tuning |
| v2.2.0  | 6,317 | 459   | ReceiptVerifier, GovernanceReportGenerator, filtered reporting, AIBOM |

---

## Roadmap

| Version | Feature |
|---------|---------|
| v2.3.0  | SessionInjector — proactive Mission Wrapper v3.0 injection, GUI setup wizard, SHIO detection |
| v2.4.0  | Digital signing, RFC 3161 trusted timestamps, external anchoring, LyraMirror |
| v3.0.0  | HUXmesh SDK — `guard()` API for developers, LangChain/OpenAI integration |

---

## Regulatory Alignment

HUXmesh provides technical controls aligned with:
- **EU AI Act** — Article 14 human oversight, Article 52 transparency
- **GDPR** — Article 22 automated decision-making protections
- **CCPA** — Section 1798 consumer privacy rights
- **FERPA** — Student data protection (FERPA profile)
- **FTC Section 5** — Unfair or deceptive AI practices
- **HIPAA** — Medical content governance (MedicalGovernor)

---

## The HUX Product Family

HUXmesh is the flagship. The Hat Protocol Inc. is building a governed AI ecosystem:

- **HUXmesh** — AI governance middleware. The KeyCard. Three-layer governance for every AI platform. Patent pending.
- **HUXedu** — Academic integrity platform. Proof of Student Authorship. Fingerprints student writing history, detects AI substitution, GYR-scores submissions. FERPA-aligned. Beta partnership with University of Tennessee Chattanooga. Patent pending.
- **HUXbomb** — Truth verification engine. Trinity Loop architecture. Ingests any article, claim, or media and produces a GYR-scored verdict with receipts. Detects SHMO (Synthetic Hypervelocity Media Overload). Built for bar trivia, corporate team building, journalism, and media verification.
- **HUXville** — Human-only, member-only civic platform. No bots. No data harvesting. No Wall Street influence. Powered by The Hat Protocol Safe Space engine. Patent pending.

All HUX products are governed by the same Six Laws and powered by the same THP doctrine.

---

## Links

- Website: [thehatprotocol.com](https://thehatprotocol.com)
- Kickstarter: [HUXmesh KeyCard](https://thehatprotocol.com)
- FAQ: [huxmesh.com/faq](https://huxmesh.com/faq)
- Contact: hello@huxmesh.com
- Press: press@huxmesh.com
- Security: security@huxmesh.com

---

## License

Proprietary — The Hat Protocol Inc. | All Rights Reserved | Patent Pending

*"Human In Power. No Matter What."*

*It's a Better World Together.™*
