Hello all,

**The password for the demo account of AFP Stories Deck** **has been updated!**

You’ll also find it in the Marketing toolbox.

**Who receives it?** Leads who have filled in the formon the **French / English / German / Arabic product pages**.

**You have a new prospect?** Refer them to the product page so that we can follow them **within the funnel**.

**Demonstration website:** <https://afpstoriesdeck.afp.com/>

**Credentials for clients or prospects:**

Login: AFP\_demo

Password: c36fdc6aa1ea

*NEXT PASSWORD UPDATE: January 12th*

All the best,

------------------

Bonjour à tous,

**Le mot de passe pour le compte démo d'AFP Stories Deck a été mis à jour.**

Il est également disponible sur la Toolbox.

**Qui le reçoit ?** Les contacts ayant remplis le formulaire des **pages produit en français, anglais, allemand et arabe.**

**Vous avez un nouveau prospect ?** N'hésitez pas à le **renvoyer vers ces formulaires pour que nous le suivions via le funnel.**

**Site de démonstration :**

<https://afpstoriesdeck.afp.com/>

**Login et mot de passe du compte démo :**

Login : AFP\_demo

Password : c36fdc6aa1ea

*PROCHAINE MISE A JOUR : 12 janvier*

Amitiés,

KILL PROCESS

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Also, the kills management procedure has evolved, and **mailing lists need to be updated**, read more on the [Toolbox](https://afp.sharepoint.com/sites/ToolBox/SitePages/AFP-Stories--.aspx).

Aussi, la procédure de gestion des kills a évolué et **des listes de diffusion doivent être mises à jour**, en savoir plus sur la [Toolbox](https://afp.sharepoint.com/sites/ToolBox/SitePages/AFP-Stories--.aspx).