# Authors

Contributors to pysegmenters_md_splitter include:

+ [Olivier Terrier](mailto:olivier.terrier@kairntech.com)
