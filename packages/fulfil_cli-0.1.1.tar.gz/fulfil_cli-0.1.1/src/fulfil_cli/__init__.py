"""Fulfil CLI — primary interface for humans and AI agents."""

from importlib.metadata import version

__version__ = version("fulfil-cli")
