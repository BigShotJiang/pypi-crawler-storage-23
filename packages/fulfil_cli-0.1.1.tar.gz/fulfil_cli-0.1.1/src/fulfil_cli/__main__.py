"""Allow running as `python -m fulfil_cli`."""

from fulfil_cli.cli import main

main()
