import os
import subprocess
from importlib.metadata import version
from pathlib import Path
from typing import Annotated, Optional

import typer
from rich.console import Console
from rich.table import Table

from csm.core import (
    create_skill,
    delete_skill_config,
    disable_skill,
    enable_skill,
    get_skill,
    link_skill,
    list_skills,
    unlink_skill,
    update_skill_config,
)

def _version_callback(value: bool):
    if value:
        print(f"csm {version('claude-skills-manager')}")
        raise typer.Exit()


app = typer.Typer(help="Claude Skills Manager — manage ~/.claude/skills/")


@app.callback()
def main(
    version: Annotated[
        Optional[bool],
        typer.Option("--version", "-V", callback=_version_callback, is_eager=True, help="Show version and exit."),
    ] = None,
):
    pass
console = Console()


def _complete_skill_name(incomplete: str) -> list[str]:
    return [s.name for s in list_skills() if s.name.startswith(incomplete)]


SkillName = Annotated[str, typer.Argument(autocompletion=_complete_skill_name)]


@app.command("list")
def list_cmd():
    """List all installed skills."""
    skills = list_skills()
    if not skills:
        console.print("[dim]No skills found.[/dim]")
        raise typer.Exit()

    table = Table(title="Claude Skills", show_lines=True)
    table.add_column("Name", style="cyan", no_wrap=True)
    table.add_column("On", justify="center", no_wrap=True)
    table.add_column("Description", ratio=1)
    table.add_column("Invoke", justify="center", no_wrap=True)
    table.add_column("Model", justify="center", no_wrap=True)

    max_desc = 80
    for s in skills:
        enabled = "[green]✓[/green]" if s.enabled else "[red]✗[/red]"
        desc = s.metadata.get("description", "")
        if len(desc) > max_desc:
            desc = desc[:max_desc - 1] + "…"
        user_invocable = "[green]✓[/green]"
        if s.metadata.get("user-invocable") is False:
            user_invocable = "[red]✗[/red]"
        model_disabled = s.metadata.get("disable-model-invocation", False)
        model_inv = "[red]✗[/red]" if model_disabled else "[green]✓[/green]"

        table.add_row(s.name, enabled, desc, user_invocable, model_inv)

    console.print(table)


@app.command()
def show(name: SkillName):
    """Show full details for a skill."""
    try:
        s = get_skill(name)
    except ValueError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)

    console.print(f"[bold cyan]{s.name}[/bold cyan]")
    console.print(f"  Path:    {s.path}")
    console.print(f"  Enabled: {'[green]Yes[/green]' if s.enabled else '[red]No[/red]'}")
    console.print()

    if s.metadata:
        console.print("[bold]Frontmatter:[/bold]")
        for k, v in s.metadata.items():
            console.print(f"  {k}: {v}")
        console.print()

    if s.content.strip():
        console.print("[bold]Content:[/bold]")
        console.print(s.content)


@app.command()
def enable(name: SkillName):
    """Enable a disabled skill."""
    try:
        s = enable_skill(name)
        console.print(f"[green]Enabled skill '{s.name}'[/green]")
    except ValueError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)


@app.command()
def disable(name: SkillName):
    """Disable an enabled skill."""
    try:
        s = disable_skill(name)
        console.print(f"[yellow]Disabled skill '{s.name}'[/yellow]")
    except ValueError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)


@app.command()
def edit(name: SkillName):
    """Open a skill's SKILL.md in $EDITOR."""
    try:
        s = get_skill(name)
    except ValueError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)

    from csm.core import SKILLS_DIR, SKILL_FILENAME, DISABLED_FILENAME

    filename = SKILL_FILENAME if s.enabled else DISABLED_FILENAME
    filepath = SKILLS_DIR / name / filename
    editor = os.environ.get("EDITOR", "vi")
    subprocess.run([editor, str(filepath)])


@app.command()
def create(
    name: str,
    description: Annotated[str, typer.Option("--desc", "-d", help="Skill description")] = "",
):
    """Create a new skill from a template."""
    try:
        s = create_skill(name, description)
        console.print(f"[green]Created skill '{s.name}' at {s.path}[/green]")
        console.print(f"  Edit: {s.path / 'SKILL.md'}")
    except ValueError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)


@app.command()
def link(
    path: Annotated[Path, typer.Argument(help="Path to the skill directory")],
    name: Annotated[Optional[str], typer.Option("--name", "-n", help="Name for the symlink (defaults to directory name)")] = None,
):
    """Symlink an external skill directory into ~/.claude/skills/."""
    try:
        s = link_skill(path, name)
        console.print(f"[green]Linked '{s.name}' -> {s.path}[/green]")
    except ValueError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)


@app.command()
def unlink(name: SkillName):
    """Remove a symlinked skill (does not delete the original)."""
    try:
        target = unlink_skill(name)
        console.print(f"[yellow]Unlinked '{name}' (target was {target})[/yellow]")
    except ValueError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)


@app.command()
def config(
    name: SkillName,
    key: Annotated[str, typer.Option("--key", "-k", help="Frontmatter key to set or delete")],
    value: Annotated[Optional[str], typer.Option("--value", "-v", help="Value to set")] = None,
    delete: Annotated[bool, typer.Option("--delete", "-d", help="Delete the key instead of setting it")] = False,
):
    """Set or delete a frontmatter field on a skill."""
    if delete:
        try:
            s = delete_skill_config(name, key)
            console.print(f"[yellow]Deleted '{key}' from '{name}'[/yellow]")
        except ValueError as e:
            console.print(f"[red]{e}[/red]")
            raise typer.Exit(1)
    elif value is not None:
        try:
            s = update_skill_config(name, key, value)
            console.print(f"[green]Updated '{name}': {key} = {value}[/green]")
        except ValueError as e:
            console.print(f"[red]{e}[/red]")
            raise typer.Exit(1)
    else:
        console.print("[red]Provide --value or --delete[/red]")
        raise typer.Exit(1)


if __name__ == "__main__":
    app()
