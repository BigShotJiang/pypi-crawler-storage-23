from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

import frontmatter

SKILLS_DIR = Path("~/.claude/skills").expanduser()

SKILL_FILENAME = "SKILL.md"
DISABLED_FILENAME = "SKILL.md.disabled"


@dataclass
class Skill:
    name: str
    path: Path
    enabled: bool
    metadata: dict = field(default_factory=dict)
    content: str = ""


def _parse_skill(skill_dir: Path) -> Skill | None:
    """Parse a skill directory, returning a Skill or None if no SKILL.md found."""
    skill_file = skill_dir / SKILL_FILENAME
    disabled_file = skill_dir / DISABLED_FILENAME

    if skill_file.exists() and disabled_file.exists():
        # Both exist — SKILL.md wins, remove the stale disabled file
        disabled_file.unlink()
        enabled = True
        target = skill_file
    elif skill_file.exists():
        enabled = True
        target = skill_file
    elif disabled_file.exists():
        enabled = False
        target = disabled_file
    else:
        return None

    post = frontmatter.load(target)
    return Skill(
        name=skill_dir.name,
        path=skill_dir.resolve() if skill_dir.is_symlink() else skill_dir,
        enabled=enabled,
        metadata=dict(post.metadata),
        content=post.content,
    )


def list_skills() -> list[Skill]:
    """Discover all skills in SKILLS_DIR."""
    if not SKILLS_DIR.exists():
        return []

    skills = []
    for entry in sorted(SKILLS_DIR.iterdir()):
        if not entry.is_dir():
            continue
        skill = _parse_skill(entry)
        if skill is not None:
            skills.append(skill)
    return skills


def get_skill(name: str) -> Skill:
    """Get a single skill by name. Raises if not found."""
    skill_dir = SKILLS_DIR / name
    if not skill_dir.exists():
        raise ValueError(f"Skill '{name}' not found in {SKILLS_DIR}")
    skill = _parse_skill(skill_dir)
    if skill is None:
        raise ValueError(f"No SKILL.md found in '{skill_dir}'")
    return skill


def enable_skill(name: str) -> Skill:
    """Enable a disabled skill by renaming SKILL.md.disabled -> SKILL.md."""
    skill_dir = SKILLS_DIR / name
    disabled_file = skill_dir / DISABLED_FILENAME
    skill_file = skill_dir / SKILL_FILENAME

    if skill_file.exists():
        raise ValueError(f"Skill '{name}' is already enabled")
    if not disabled_file.exists():
        raise ValueError(f"Skill '{name}' not found or has no SKILL.md.disabled")

    disabled_file.rename(skill_file)
    return get_skill(name)


def disable_skill(name: str) -> Skill:
    """Disable an enabled skill by renaming SKILL.md -> SKILL.md.disabled."""
    skill_dir = SKILLS_DIR / name
    skill_file = skill_dir / SKILL_FILENAME
    disabled_file = skill_dir / DISABLED_FILENAME

    if disabled_file.exists():
        raise ValueError(f"Skill '{name}' is already disabled")
    if not skill_file.exists():
        raise ValueError(f"Skill '{name}' not found or has no SKILL.md")

    skill_file.rename(disabled_file)
    return get_skill(name)


SKILL_TEMPLATE = """\
---
name: {name}
description: {description}
---

TODO: Describe what this skill does and how Claude should use it.
"""


def link_skill(path: Path, name: str | None = None) -> Skill:
    """Symlink an external skill directory into SKILLS_DIR using relative paths."""
    path = path.resolve()
    if not path.is_dir():
        raise ValueError(f"'{path}' is not a directory")
    if not (path / SKILL_FILENAME).exists() and not (path / DISABLED_FILENAME).exists():
        raise ValueError(f"No SKILL.md found in '{path}'")

    link_name = name or path.name
    link_path = SKILLS_DIR / link_name
    if link_path.exists():
        raise ValueError(f"Skill '{link_name}' already exists in {SKILLS_DIR}")

    SKILLS_DIR.mkdir(parents=True, exist_ok=True)
    # Use a relative symlink (compatible with GNU Stow)
    rel_target = os.path.relpath(path, SKILLS_DIR)
    link_path.symlink_to(rel_target)
    return get_skill(link_name)


def unlink_skill(name: str) -> Path:
    """Remove a symlinked skill from SKILLS_DIR. Returns the target path."""
    link_path = SKILLS_DIR / name
    if not link_path.exists():
        raise ValueError(f"Skill '{name}' not found in {SKILLS_DIR}")
    if not link_path.is_symlink():
        raise ValueError(f"Skill '{name}' is not a symlink — use 'rm -rf' manually if intended")
    target = link_path.resolve()
    link_path.unlink()
    return target


def create_skill(name: str, description: str = "") -> Skill:
    """Create a new skill directory with a template SKILL.md."""
    skill_dir = SKILLS_DIR / name
    if skill_dir.exists():
        raise ValueError(f"Skill '{name}' already exists")

    skill_dir.mkdir(parents=True)
    skill_file = skill_dir / SKILL_FILENAME
    skill_file.write_text(
        SKILL_TEMPLATE.format(name=name, description=description or f"A skill called {name}")
    )
    return get_skill(name)


def update_skill_config(name: str, key: str, value: str) -> Skill:
    """Update a frontmatter key in a skill's SKILL.md."""
    skill = get_skill(name)
    filename = SKILL_FILENAME if skill.enabled else DISABLED_FILENAME
    target = SKILLS_DIR / name / filename

    post = frontmatter.load(target)

    # Handle special values
    if value.lower() == "true":
        post[key] = True
    elif value.lower() == "false":
        post[key] = False
    else:
        post[key] = value

    frontmatter.dump(post, target)
    return get_skill(name)


def delete_skill_config(name: str, key: str) -> Skill:
    """Remove a frontmatter key from a skill's SKILL.md."""
    skill = get_skill(name)
    filename = SKILL_FILENAME if skill.enabled else DISABLED_FILENAME
    target = SKILLS_DIR / name / filename

    post = frontmatter.load(target)
    if key not in post.metadata:
        raise ValueError(f"Key '{key}' not found in '{name}' frontmatter")

    del post[key]
    frontmatter.dump(post, target)
    return get_skill(name)
