import pytest
from pathlib import Path

import csm.core as core


SAMPLE_SKILL = """\
---
name: test-skill
description: A test skill
argument-hint: "[arg]"
---

This is a test skill body.
"""


@pytest.fixture
def skills_dir(tmp_path, monkeypatch):
    """Provide a temporary skills directory and patch core.SKILLS_DIR."""
    monkeypatch.setattr(core, "SKILLS_DIR", tmp_path)
    return tmp_path


@pytest.fixture
def sample_skill(skills_dir):
    """Create a single sample skill in the temp skills dir."""
    skill_dir = skills_dir / "test-skill"
    skill_dir.mkdir()
    (skill_dir / "SKILL.md").write_text(SAMPLE_SKILL)
    return skill_dir
