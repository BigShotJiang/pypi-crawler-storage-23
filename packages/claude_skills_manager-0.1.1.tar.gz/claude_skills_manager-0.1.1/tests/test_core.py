import pytest
from pathlib import Path

from csm.core import (
    create_skill,
    delete_skill_config,
    disable_skill,
    enable_skill,
    get_skill,
    link_skill,
    list_skills,
    unlink_skill,
    update_skill_config,
)


class TestListSkills:
    def test_empty_dir(self, skills_dir):
        assert list_skills() == []

    def test_finds_skill(self, sample_skill):
        skills = list_skills()
        assert len(skills) == 1
        assert skills[0].name == "test-skill"
        assert skills[0].enabled is True

    def test_finds_disabled_skill(self, sample_skill):
        (sample_skill / "SKILL.md").rename(sample_skill / "SKILL.md.disabled")
        skills = list_skills()
        assert len(skills) == 1
        assert skills[0].enabled is False

    def test_both_files_exist_treats_as_enabled(self, sample_skill):
        """When both SKILL.md and SKILL.md.disabled exist, SKILL.md wins."""
        (sample_skill / "SKILL.md.disabled").write_text("---\nname: stale\n---\n")
        skills = list_skills()
        assert len(skills) == 1
        assert skills[0].enabled is True
        # Stale disabled file should be cleaned up
        assert not (sample_skill / "SKILL.md.disabled").exists()

    def test_ignores_dir_without_skill_md(self, skills_dir):
        (skills_dir / "not-a-skill").mkdir()
        assert list_skills() == []


class TestGetSkill:
    def test_get_existing(self, sample_skill):
        s = get_skill("test-skill")
        assert s.name == "test-skill"
        assert s.metadata["description"] == "A test skill"
        assert "test skill body" in s.content

    def test_get_nonexistent(self, skills_dir):
        with pytest.raises(ValueError, match="not found"):
            get_skill("nope")


class TestEnableDisable:
    def test_disable(self, sample_skill):
        s = disable_skill("test-skill")
        assert s.enabled is False
        assert (sample_skill / "SKILL.md.disabled").exists()
        assert not (sample_skill / "SKILL.md").exists()

    def test_enable(self, sample_skill):
        (sample_skill / "SKILL.md").rename(sample_skill / "SKILL.md.disabled")
        s = enable_skill("test-skill")
        assert s.enabled is True
        assert (sample_skill / "SKILL.md").exists()

    def test_disable_already_disabled(self, sample_skill):
        (sample_skill / "SKILL.md").rename(sample_skill / "SKILL.md.disabled")
        with pytest.raises(ValueError, match="already disabled"):
            disable_skill("test-skill")

    def test_enable_already_enabled(self, sample_skill):
        with pytest.raises(ValueError, match="already enabled"):
            enable_skill("test-skill")


class TestCreateSkill:
    def test_create(self, skills_dir):
        s = create_skill("new-skill", "My new skill")
        assert s.name == "new-skill"
        assert s.enabled is True
        assert s.metadata["description"] == "My new skill"

    def test_create_already_exists(self, sample_skill):
        with pytest.raises(ValueError, match="already exists"):
            create_skill("test-skill")


class TestLinkUnlink:
    @pytest.fixture
    def external_dir(self, tmp_path):
        """A separate directory outside skills_dir for link sources."""
        d = tmp_path / "external"
        d.mkdir()
        return d

    def test_link(self, skills_dir, external_dir):
        source = external_dir / "my-skill"
        source.mkdir()
        (source / "SKILL.md").write_text("---\nname: ext\n---\nHello\n")

        s = link_skill(source)
        assert s.name == "my-skill"
        assert (skills_dir / "my-skill").is_symlink()

    def test_link_custom_name(self, skills_dir, external_dir):
        source = external_dir / "my-skill"
        source.mkdir()
        (source / "SKILL.md").write_text("---\nname: ext\n---\nHello\n")

        s = link_skill(source, name="my-alias")
        assert s.name == "my-alias"

    def test_link_no_skill_md(self, skills_dir, external_dir):
        source = external_dir / "empty-dir"
        source.mkdir()
        with pytest.raises(ValueError, match="No SKILL.md"):
            link_skill(source)

    def test_unlink(self, skills_dir, external_dir):
        source = external_dir / "ext"
        source.mkdir()
        (source / "SKILL.md").write_text("---\nname: ext\n---\n")
        link_skill(source)

        target = unlink_skill("ext")
        assert target == source
        assert not (skills_dir / "ext").exists()

    def test_unlink_non_symlink(self, sample_skill):
        with pytest.raises(ValueError, match="not a symlink"):
            unlink_skill("test-skill")


class TestUpdateConfig:
    def test_set_string(self, sample_skill):
        s = update_skill_config("test-skill", "description", "Updated desc")
        assert s.metadata["description"] == "Updated desc"

    def test_set_bool_true(self, sample_skill):
        s = update_skill_config("test-skill", "disable-model-invocation", "true")
        assert s.metadata["disable-model-invocation"] is True

    def test_set_bool_false(self, sample_skill):
        s = update_skill_config("test-skill", "disable-model-invocation", "false")
        assert s.metadata["disable-model-invocation"] is False

    def test_delete_key(self, sample_skill):
        s = delete_skill_config("test-skill", "argument-hint")
        assert "argument-hint" not in s.metadata

    def test_delete_nonexistent_key(self, sample_skill):
        with pytest.raises(ValueError, match="not found"):
            delete_skill_config("test-skill", "no-such-key")
