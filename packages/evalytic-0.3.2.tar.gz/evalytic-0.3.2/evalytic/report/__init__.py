"""Evalytic report renderers -- terminal, JSON, HTML."""
