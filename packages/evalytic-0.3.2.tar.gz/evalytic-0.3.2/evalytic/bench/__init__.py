"""Evalytic bench -- local model benchmarking engine."""
