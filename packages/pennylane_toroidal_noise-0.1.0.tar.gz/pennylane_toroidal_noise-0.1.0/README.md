# pennylane-toroidal-noise

Toroidal dephasing noise channel for [PennyLane](https://pennylane.ai/).

Qubits on a toroidal lattice experience reduced dephasing because the lattice
Laplacian's spectral gap filters low-frequency noise. This plugin provides
`ToroidalDephasing` — a drop-in replacement for `qml.PhaseDamping` that models
this suppression.

## Installation

```bash
pip install pennylane-toroidal-noise
```

## Usage

```python
import pennylane as qml
from pennylane_toroidal_noise import ToroidalDephasing

dev = qml.device("default.mixed", wires=1)

@qml.qnode(dev)
def circuit(gamma):
    qml.Hadamard(wires=0)
    ToroidalDephasing(gamma, grid_n=12, wires=0)
    return qml.expval(qml.PauliX(0))

# Compare: more coherence preserved than plain PhaseDamping
circuit(0.5)  # ~0.99 (vs ~0.87 for PhaseDamping)
```

## How it works

The effective dephasing probability is suppressed by the spectral gap of the
cycle graph C_n:

```text
gamma_eff = gamma * lambda_1 / (lambda_1 + alpha)
```

where `lambda_1 = 2 - 2*cos(2*pi/n)` is the smallest nonzero eigenvalue of
the n-vertex cycle graph Laplacian (also the spectral gap of the n x n torus).

| grid_n | suppression (alpha=1) |
|--------|----------------------|
| 4      | 1.5x                 |
| 8      | 2.7x                 |
| 12     | 4.7x                 |
| 32     | 27x                  |

## Parameters

| Parameter | Type  | Default | Description |
|-----------|-------|---------|-------------|
| `gamma`   | float | —       | Bare dephasing probability in [0, 1] |
| `grid_n`  | int   | 12      | Side length of the toroidal lattice |
| `alpha`   | float | 1.0     | Coupling strength (larger = stronger filtering) |
| `wires`   | int   | —       | Wire the channel acts on |

## Rust companion

A pure-Rust implementation is also available: [`toroidal-noise`](https://crates.io/crates/toroidal-noise)

## Reference

S. Cormier, "Toroidal Logit Bias," Zenodo, 2026.
DOI: [10.5281/zenodo.18516477](https://doi.org/10.5281/zenodo.18516477)

## License

MIT
