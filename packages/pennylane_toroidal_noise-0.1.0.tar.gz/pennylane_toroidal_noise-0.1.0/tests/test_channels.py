"""Tests for ToroidalDephasing channel."""

import math

import numpy as np
import pennylane as qml
from pennylane import numpy as pnp
import pytest

from pennylane_toroidal_noise import ToroidalDephasing


TOL = 1e-10


class TestToroidalDephasing:
    """Tests for the ToroidalDephasing channel."""

    def test_gamma_zero_identity(self):
        """gamma=0 gives identity channel (no dephasing)."""
        op = ToroidalDephasing(0, grid_n=12, wires=0)
        K = op.kraus_matrices()
        assert np.allclose(K[0], np.eye(2), atol=1e-6)
        assert np.allclose(K[1], np.zeros((2, 2)), atol=1e-6)

    def test_gamma_one_suppressed(self):
        """gamma=1 gives less than full dephasing due to spectral filter."""
        op = ToroidalDephasing(1.0, grid_n=12, wires=0)
        K = op.kraus_matrices()
        gamma_eff = abs(K[1][1, 1]) ** 2
        assert gamma_eff < 1.0
        assert gamma_eff > 0.0

    def test_larger_grid_more_suppression(self):
        """Larger toroidal grids suppress dephasing more."""
        K_small = ToroidalDephasing(0.5, grid_n=4, wires=0).kraus_matrices()
        K_large = ToroidalDephasing(0.5, grid_n=32, wires=0).kraus_matrices()
        gamma_eff_small = abs(K_small[1][1, 1]) ** 2
        gamma_eff_large = abs(K_large[1][1, 1]) ** 2
        assert gamma_eff_large < gamma_eff_small

    def test_spectral_gap_formula(self):
        """Verify gamma_eff matches the spectral gap formula."""
        op = ToroidalDephasing(1.0, grid_n=4, alpha=1.0, wires=0)
        K = op.kraus_matrices()
        gamma_eff = abs(K[1][1, 1]) ** 2
        lam1 = 2.0 - 2.0 * math.cos(2.0 * math.pi / 4)
        expected = lam1 / (lam1 + 1.0)
        assert np.isclose(gamma_eff, expected, atol=TOL)

    def test_spectral_gap_grid6(self):
        """For grid_n=6, lambda_1=1 so gamma_eff = gamma/2."""
        op = ToroidalDephasing(0.8, grid_n=6, alpha=1.0, wires=0)
        K = op.kraus_matrices()
        gamma_eff = abs(K[1][1, 1]) ** 2
        assert np.isclose(gamma_eff, 0.4, atol=TOL)

    def test_large_alpha_identity(self):
        """With very large alpha, suppression -> 0 and channel -> identity."""
        op = ToroidalDephasing(0.3, grid_n=12, alpha=1e10, wires=0)
        K = op.kraus_matrices()
        assert np.allclose(K[0], np.eye(2), atol=1e-4)

    def test_alpha_zero_raises(self):
        """alpha must be positive."""
        with pytest.raises(ValueError, match="alpha must be positive"):
            ToroidalDephasing(0.5, alpha=0.0, wires=0)

    def test_grid_n_too_small_raises(self):
        """grid_n must be >= 2."""
        with pytest.raises(ValueError, match="grid_n must be >= 2"):
            ToroidalDephasing(0.5, grid_n=1, wires=0)

    def test_gamma_out_of_range_raises(self):
        """gamma outside [0,1] raises."""
        with pytest.raises(ValueError, match="gamma must be in the interval"):
            ToroidalDephasing(1.5, wires=0).kraus_matrices()

    def test_trace_preserving(self):
        """sum K_i^dagger K_i = I for many parameter values."""
        for gamma in [0.0, 0.3, 0.7, 1.0]:
            for grid_n in [4, 8, 12, 32]:
                K_list = ToroidalDephasing(gamma, grid_n=grid_n, wires=0).kraus_matrices()
                K_arr = np.stack(K_list)
                kraus_sum = np.einsum("ajk,ajl->kl", np.conj(K_arr), K_arr)
                assert np.allclose(kraus_sum, np.eye(2), atol=TOL), (
                    f"Not trace-preserving for gamma={gamma}, grid_n={grid_n}"
                )

    def test_monotonic_suppression(self):
        """Increasing grid_n monotonically decreases gamma_eff."""
        prev = 1.0
        for n in [4, 6, 8, 12, 16, 32, 64]:
            K = ToroidalDephasing(1.0, grid_n=n, wires=0).kraus_matrices()
            g_eff = abs(K[1][1, 1]) ** 2
            assert g_eff < prev, f"grid_n={n}: gamma_eff={g_eff} >= prev={prev}"
            prev = g_eff

    def test_coherence_preserved(self):
        """Toroidal dephasing preserves more coherence than plain PhaseDamping."""
        dev = qml.device("default.mixed", wires=1)

        @qml.qnode(dev)
        def plain(g):
            qml.Hadamard(0)
            qml.PhaseDamping(g, wires=0)
            return qml.expval(qml.PauliX(0))

        @qml.qnode(dev)
        def toroidal(g):
            qml.Hadamard(0)
            ToroidalDephasing(g, grid_n=12, wires=0)
            return qml.expval(qml.PauliX(0))

        assert float(toroidal(0.5)) > float(plain(0.5))

    def test_qnode_runs(self):
        """Basic QNode execution."""
        dev = qml.device("default.mixed", wires=1)

        @qml.qnode(dev)
        def circuit(g):
            qml.Hadamard(0)
            ToroidalDephasing(g, grid_n=12, wires=0)
            return qml.expval(qml.PauliX(0))

        result = float(circuit(0.5))
        assert 0.0 < result <= 1.0

    def test_gradient(self):
        """Gradient can be computed through a QNode via finite differences."""
        dev = qml.device("default.mixed", wires=1)
        gamma = pnp.array(0.5, requires_grad=True)

        @qml.qnode(dev, diff_method="finite-diff")
        def circuit(g):
            qml.Hadamard(0)
            ToroidalDephasing(g, grid_n=12, wires=0)
            return qml.expval(qml.PauliX(0))

        grad = qml.grad(circuit)(gamma)
        assert isinstance(grad, (float, pnp.tensor))
        # More dephasing -> less X expectation -> negative gradient
        assert grad < 0

    def test_two_kraus_operators(self):
        """Channel always returns exactly 2 Kraus operators."""
        K = ToroidalDephasing(0.5, grid_n=12, wires=0).kraus_matrices()
        assert len(K) == 2
        assert K[0].shape == (2, 2)
        assert K[1].shape == (2, 2)
