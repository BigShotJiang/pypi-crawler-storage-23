"""Toroidal dephasing channel with spectral-gap suppression."""

import math

import numpy as _np
import pennylane as qml
from pennylane.operation import Channel


class ToroidalDephasing(Channel):
    r"""
    Single-qubit dephasing channel with toroidal spectral-gap suppression.

    Models dephasing noise on a qubit embedded in a toroidal (:math:`T^2`)
    lattice, where the spectral gap of the graph Laplacian acts as a
    topological noise filter. The effective dephasing probability is reduced
    from the bare value :math:`\gamma` by a factor determined by the lattice
    geometry:

    .. math::
        \lambda_1 = 2 - 2\cos\!\left(\frac{2\pi}{n}\right)

    .. math::
        \gamma_{\text{eff}} = \gamma \cdot
            \frac{\lambda_1}{\lambda_1 + \alpha}

    where :math:`n` is the side length of the :math:`n \times n` toroidal
    lattice, :math:`\lambda_1` is the smallest nonzero eigenvalue of the
    lattice Laplacian, and :math:`\alpha \in (0, \infty)` is a coupling
    strength that controls the suppression (larger :math:`\alpha` gives
    stronger filtering).

    The Kraus matrices are identical in form to
    :class:`~pennylane.PhaseDamping` but with :math:`\gamma_{\text{eff}}`
    replacing :math:`\gamma`:

    .. math::
        K_0 = \begin{bmatrix}
                1 & 0 \\
                0 & \sqrt{1-\gamma_{\text{eff}}}
                \end{bmatrix}
    \qquad
        K_1 = \begin{bmatrix}
                0 & 0  \\
                0 & \sqrt{\gamma_{\text{eff}}}
                \end{bmatrix}

    **Noise reduction examples** (alpha=1.0):

    =======  ====================
    grid_n   suppression factor
    =======  ====================
    4        1.5x
    8        2.7x
    12       4.7x
    32       27x
    =======  ====================

    **Details:**

    * Number of wires: 1
    * Number of parameters: 1

    Args:
        gamma (float): bare dephasing probability, in :math:`[0, 1]`
        grid_n (int): side length of the :math:`n \times n` toroidal lattice
            (default 12, giving 144 sites)
        alpha (float): coupling strength controlling suppression depth
            (default 1.0)
        wires (Sequence[int] or int): the wire the channel acts on
        id (str or None): string representing the operation (optional)

    Reference: `Cormier 2026 <https://doi.org/10.5281/zenodo.18516477>`_

    **Example:**

    >>> import pennylane as qml
    >>> from pennylane_toroidal_noise import ToroidalDephasing
    >>> dev = qml.device("default.mixed", wires=1)
    >>> @qml.qnode(dev)
    ... def circuit(gamma):
    ...     qml.Hadamard(wires=0)
    ...     ToroidalDephasing(gamma, grid_n=12, wires=0)
    ...     return qml.expval(qml.PauliX(0))
    >>> float(circuit(0.5))  # doctest: +SKIP
    0.99...
    """

    num_params = 1
    num_wires = 1
    grad_method = "F"

    def __init__(self, gamma, grid_n=12, alpha=1.0, wires=None, id=None):
        if grid_n < 2:
            raise ValueError("grid_n must be >= 2.")
        if alpha <= 0:
            raise ValueError("alpha must be positive.")
        self.hyperparameters["grid_n"] = grid_n
        self.hyperparameters["alpha"] = alpha
        super().__init__(gamma, wires=wires, id=id)

    @staticmethod
    def compute_kraus_matrices(gamma, grid_n=12, alpha=1.0):  # pylint: disable=arguments-differ
        r"""Kraus matrices representing the ToroidalDephasing channel.

        Args:
            gamma (float): bare dephasing probability
            grid_n (int): side length of the toroidal lattice
            alpha (float): coupling strength

        Returns:
            list(array): list of Kraus matrices

        **Example**

        >>> ToroidalDephasing.compute_kraus_matrices(0.5, grid_n=4)
        [array([[1.       +0.j, 0.       +0.j],
               [0.       +0.j, 0.8164...+0.j]]), array([[0.       +0.j, 0.       +0.j],
               [0.       +0.j, 0.5773...+0.j]])]
        """
        if not qml.math.is_abstract(gamma) and not 0.0 <= gamma <= 1.0:
            raise ValueError("gamma must be in the interval [0, 1].")

        # Spectral gap of the n x n toroidal lattice Laplacian
        lam1 = 2.0 - 2.0 * math.cos(2.0 * math.pi / grid_n)

        # Suppression factor
        suppression = lam1 / (lam1 + alpha)
        gamma_eff = gamma * suppression

        K0 = qml.math.diag([1 + 0j, qml.math.sqrt(1 - gamma_eff + 1e-15) + 0j])
        K1 = qml.math.diag([0 + 0j, qml.math.sqrt(gamma_eff + 1e-15) + 0j])
        return [K0, K1]

    def decomposition(self):
        """Decompose into PhaseDamping with effective gamma."""
        gamma = self.parameters[0]
        grid_n = self.hyperparameters["grid_n"]
        alpha = self.hyperparameters["alpha"]

        lam1 = 2.0 - 2.0 * math.cos(2.0 * math.pi / grid_n)
        suppression = lam1 / (lam1 + alpha)
        gamma_eff = gamma * suppression

        return [qml.PhaseDamping(gamma_eff, wires=self.wires)]
