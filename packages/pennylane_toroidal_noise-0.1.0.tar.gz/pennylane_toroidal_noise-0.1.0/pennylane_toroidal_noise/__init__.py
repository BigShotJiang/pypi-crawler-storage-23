"""Toroidal dephasing noise channel for PennyLane."""

from .channels import ToroidalDephasing

__version__ = "0.1.0"
__all__ = ["ToroidalDephasing"]
