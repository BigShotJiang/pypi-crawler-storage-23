"""refcheck — Academic reference verification MCP server."""

__version__ = "0.1.0"
