"""Entry point for python -m refcheck."""

from refcheck.server import main

main()
