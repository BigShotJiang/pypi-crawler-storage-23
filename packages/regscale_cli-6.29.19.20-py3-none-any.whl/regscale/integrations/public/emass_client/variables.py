"""
Configuration variables for eMASS integration.

This module defines all configuration variables required for the eMASS API integration,
including authentication, API endpoints, and operational settings.

Configuration is loaded from init.yaml (preferred) or environment variables (fallback).
"""

import os
from pathlib import Path
from typing import Optional

from regscale.core.app.application import Application

# Set config file path preference: local init.yaml > home init.yaml
# This ensures eMASS config is loaded from current directory if available
if "REGSCALE_CONFIG_FILE" not in os.environ:
    # First try current working directory
    local_config = Path.cwd() / "init.yaml"
    if local_config.exists():
        os.environ["REGSCALE_CONFIG_FILE"] = str(local_config)
    else:
        # Fall back to home directory
        home_config = Path.home() / ".regscale" / "init.yaml"
        if home_config.exists():
            os.environ["REGSCALE_CONFIG_FILE"] = str(home_config)

# Load configuration from init.yaml (local dir or ~/.regscale/)
_app = Application()
_emass_config = _app.config.get("emass", {})

# ===========================
# Authentication Configuration
# ===========================

EMASS_BASE_URL: Optional[str] = _emass_config.get("base_url") or os.getenv("EMASS_BASE_URL")
"""Base URL for eMASS API (e.g., 'https://api.emass.mil')"""

EMASS_API_KEY: Optional[str] = _emass_config.get("api_key") or os.getenv("EMASS_API_KEY")
"""API key for eMASS authentication (required for all operations)"""

EMASS_USER_UID: Optional[str] = _emass_config.get("user_uid") or os.getenv("EMASS_USER_UID")
"""User UID for eMASS (used for POC fields and audit tracking)"""

# ===========================
# API Configuration
# ===========================

EMASS_API_TIMEOUT: int = _emass_config.get("timeout", int(os.getenv("EMASS_API_TIMEOUT", "300")))
"""Timeout for eMASS API calls in seconds (default: 300)"""

EMASS_API_RETRIES: int = _emass_config.get("max_retries", int(os.getenv("EMASS_API_RETRIES", "3")))
"""Number of retry attempts for failed API calls (default: 3)"""

EMASS_API_RETRY_DELAY: int = _emass_config.get("retry_delay", int(os.getenv("EMASS_API_RETRY_DELAY", "5")))
"""Delay in seconds between retry attempts (default: 5)"""

# ===========================
# System Configuration
# ===========================

EMASS_SYSTEM_ID: Optional[str] = _emass_config.get("system_id") or os.getenv("EMASS_SYSTEM_ID")
"""Default eMASS System ID for operations (can be overridden per command)"""

EMASS_RMF_SCOPE: Optional[str] = _emass_config.get("rmf_scope") or os.getenv("EMASS_RMF_SCOPE")
"""RMF authorization scope (e.g., 'pso' for Platform System Owner)"""

# ===========================
# Sync Configuration
# ===========================

EMASS_SYNC_BATCH_SIZE: int = _emass_config.get("batch_size", int(os.getenv("EMASS_SYNC_BATCH_SIZE", "50")))
"""Batch size for bulk operations (default: 50 POA&Ms per batch)"""

EMASS_SYNC_DIRECTION: str = _emass_config.get("sync_direction", os.getenv("EMASS_SYNC_DIRECTION", "bidirectional"))
"""Default sync direction: 'push', 'pull', or 'bidirectional' (default: bidirectional)"""


def _to_bool(value, default: str = "true") -> bool:
    """Convert config value to boolean."""
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.lower() == "true"
    return default.lower() == "true"


EMASS_SYNC_CREATE_MISSING: bool = _to_bool(
    _emass_config.get("create_missing", os.getenv("EMASS_SYNC_CREATE_MISSING", "true"))
)
"""Auto-create missing POA&Ms during sync (default: true)"""

# ===========================
# Idempotency Configuration
# ===========================

EMASS_USE_EXTERNAL_UID: bool = _to_bool(
    _emass_config.get("use_external_uid", os.getenv("EMASS_USE_EXTERNAL_UID", "true"))
)
"""Use externalUid for idempotency (default: true)"""

EMASS_EXTERNAL_UID_PREFIX: str = _emass_config.get(
    "external_uid_prefix", os.getenv("EMASS_EXTERNAL_UID_PREFIX", "regscale")
)
"""Prefix for externalUid values (default: 'regscale')"""

# ===========================
# Business Rule Configuration
# ===========================

EMASS_VALIDATE_BEFORE_PUSH: bool = _to_bool(
    _emass_config.get("validate_before_push", os.getenv("EMASS_VALIDATE_BEFORE_PUSH", "true"))
)
"""Validate business rules before pushing to eMASS (default: true)"""

EMASS_STRICT_VALIDATION: bool = _to_bool(
    _emass_config.get("strict_validation", os.getenv("EMASS_STRICT_VALIDATION", "false"))
)
"""Use strict validation (fail on warnings, not just errors) (default: false)"""

# ===========================
# Milestone Configuration
# ===========================

EMASS_MILESTONE_SYNC_ACTIVE_ONLY: bool = _to_bool(
    _emass_config.get("milestone_sync_active_only", os.getenv("EMASS_MILESTONE_SYNC_ACTIVE_ONLY", "true"))
)
"""Only sync active milestones (isActive=true) (default: true)"""

EMASS_MILESTONE_AUTO_ACTIVATE: bool = _to_bool(
    _emass_config.get("milestone_auto_activate", os.getenv("EMASS_MILESTONE_AUTO_ACTIVATE", "false"))
)
"""Automatically activate new milestones (default: false)"""

# ===========================
# Artifact Configuration
# ===========================

EMASS_ARTIFACT_MAX_SIZE_MB: int = _emass_config.get(
    "artifact_max_size_mb", int(os.getenv("EMASS_ARTIFACT_MAX_SIZE_MB", "30"))
)
"""Maximum artifact file size in MB (default: 30)"""

EMASS_ARTIFACT_ALLOWED_EXTENSIONS: str = _emass_config.get(
    "artifact_allowed_extensions",
    os.getenv("EMASS_ARTIFACT_ALLOWED_EXTENSIONS", ".pdf,.docx,.xlsx,.txt,.zip,.png,.jpg,.jpeg"),
)
"""Comma-separated list of allowed artifact file extensions"""

# ===========================
# Logging Configuration
# ===========================

EMASS_LOG_LEVEL: str = _emass_config.get("log_level", os.getenv("EMASS_LOG_LEVEL", "INFO"))
"""Log level for eMASS integration (DEBUG, INFO, WARNING, ERROR, CRITICAL)"""

EMASS_LOG_API_REQUESTS: bool = _to_bool(
    _emass_config.get("log_api_requests", os.getenv("EMASS_LOG_API_REQUESTS", "false"))
)
"""Log all API requests and responses for debugging (default: false)"""

# ===========================
# Field Mapping Configuration
# ===========================

EMASS_MAP_REGSCALE_STATUS: bool = _to_bool(
    _emass_config.get("map_regscale_status", os.getenv("EMASS_MAP_REGSCALE_STATUS", "true"))
)
"""Automatically map RegScale status values to eMASS equivalents (default: true)"""

EMASS_MAP_SEVERITY: bool = _to_bool(_emass_config.get("map_severity", os.getenv("EMASS_MAP_SEVERITY", "true")))
"""Automatically map severity values to eMASS format (default: true)"""

# ===========================
# Control Implementation Configuration
# ===========================

EMASS_CONTROL_SYNC_ALL_FIELDS: bool = _to_bool(
    _emass_config.get("control_sync_all_fields", os.getenv("EMASS_CONTROL_SYNC_ALL_FIELDS", "true"))
)
"""Sync all 60+ Control Implementation fields (default: true)"""

EMASS_CONTROL_INCLUDE_SCOPE_LEVELS: bool = _to_bool(
    _emass_config.get("control_include_scope_levels", os.getenv("EMASS_CONTROL_INCLUDE_SCOPE_LEVELS", "true"))
)
"""Include RegScale scope levels (systemLevel, sectorLevel, etc.) in metadata (default: true)"""

# ===========================
# XML Import Configuration
# ===========================

EMASS_XML_CREATE_CUSTOM_FIELDS: bool = _to_bool(
    _emass_config.get("xml_create_custom_fields", os.getenv("EMASS_XML_CREATE_CUSTOM_FIELDS", "true"))
)
"""Create custom fields for unmapped XML data (default: true)"""

EMASS_XML_VALIDATE_SCHEMA: bool = _to_bool(
    _emass_config.get("xml_validate_schema", os.getenv("EMASS_XML_VALIDATE_SCHEMA", "true"))
)
"""Validate XML against eMASS schema before import (default: true)"""

# ===========================
# Helper Functions
# ===========================


def validate_required_config() -> tuple[bool, list[str]]:
    """
    Validate that all required configuration variables are set.

    Returns:
        Tuple of (is_valid: bool, missing_vars: list[str])
    """
    missing = []

    if not EMASS_BASE_URL:
        missing.append("EMASS_BASE_URL")
    if not EMASS_API_KEY:
        missing.append("EMASS_API_KEY")

    return len(missing) == 0, missing


def get_config_summary() -> dict:
    """
    Get a summary of current eMASS configuration (safe for logging).

    Returns:
        Dictionary with configuration summary (API key masked)
    """
    return {
        "base_url": EMASS_BASE_URL,
        "api_key_configured": bool(EMASS_API_KEY),
        "user_uid": EMASS_USER_UID,
        "system_id": EMASS_SYSTEM_ID,
        "rmf_scope": EMASS_RMF_SCOPE,
        "sync_direction": EMASS_SYNC_DIRECTION,
        "batch_size": EMASS_SYNC_BATCH_SIZE,
        "validate_before_push": EMASS_VALIDATE_BEFORE_PUSH,
        "use_external_uid": EMASS_USE_EXTERNAL_UID,
        "log_level": EMASS_LOG_LEVEL,
    }
