"""
eMASS Legacy Integration Functions.

This module contains backward-compatible Excel-based import/export functions
that are maintained for existing workflows. New integrations should use the
Scanner Integration framework classes instead.
"""
