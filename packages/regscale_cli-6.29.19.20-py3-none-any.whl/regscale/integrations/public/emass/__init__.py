"""
eMASS Integration Module.

This module provides integration with the eMASS (Enterprise Mission Assurance Support Service)
system for bidirectional synchronization of assets, POA&Ms, test results, and control implementations.

The integration follows the Scanner Integration framework pattern and uses core RegScale models
and handlers for consistent data processing.
"""

from regscale.integrations.public.emass.assets_integration import EmassAssetsIntegration
from regscale.integrations.public.emass.poam_integration import EmassPoamIntegration
from regscale.integrations.public.emass.test_results_integration import EmassTestResultsIntegration

__all__ = [
    "EmassAssetsIntegration",
    "EmassTestResultsIntegration",
    "EmassPoamIntegration",
]
