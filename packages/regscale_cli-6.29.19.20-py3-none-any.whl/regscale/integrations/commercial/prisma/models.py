#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Prisma Cloud Pydantic Models

This module defines Pydantic models for Prisma Cloud Compute API responses.
These models provide type validation, auto-completion, and structured data access.
"""

from datetime import datetime
from typing import Dict, List, Optional

from pydantic import BaseModel, Field


class PrismaRepoTag(BaseModel):
    """Container image repository tag information."""

    registry: str = ""
    repo: str = ""
    tag: str = ""
    digest: str = ""


class PrismaVulnerability(BaseModel):
    """Vulnerability information from Prisma Cloud."""

    cve: str = Field(..., description="CVE identifier")
    cvss: Optional[float] = Field(None, description="CVSS score (0.0-10.0)")
    severity: str = Field(..., description="Vulnerability severity (critical, high, medium, low)")
    status: str = Field("", description="Fix status")
    description: str = Field("", description="Vulnerability description")
    packageName: Optional[str] = Field(None, alias="packageName", description="Affected package name")
    packageVersion: Optional[str] = Field(None, alias="packageVersion", description="Affected package version")
    link: str = Field("", description="Vulnerability reference link")
    riskFactors: Optional[Dict] = Field(None, alias="riskFactors", description="Risk factors dictionary")
    published: Optional[int] = Field(None, description="Published date (Unix timestamp)")
    discovered: Optional[datetime] = Field(None, description="Discovery date")

    class Config:
        """Pydantic config."""

        populate_by_name = True  # Allow both snake_case and camelCase


class PrismaCloudMetadata(BaseModel):
    """Cloud provider metadata for hosts."""

    provider: str = ""
    region: str = ""
    accountID: str = ""
    image: str = ""  # AMI ID for AWS
    name: str = ""
    resourceID: str = ""
    type: str = ""
    vmID: str = ""

    class Config:
        """Pydantic config."""

        populate_by_name = True


class PrismaHost(BaseModel):
    """Host scan data from Prisma Cloud Compute."""

    id: str = Field(..., alias="_id", description="Unique host identifier")
    hostname: str = Field(..., description="Hostname")
    scanTime: datetime = Field(..., alias="scanTime", description="Last scan timestamp")
    distro: str = Field("", description="OS distribution string")
    osDistro: str = Field("", alias="osDistro", description="OS distribution name")
    osDistroVersion: str = Field("", alias="osDistroVersion", description="OS version")
    osDistroRelease: str = Field("", alias="osDistroRelease", description="OS release")
    type: str = Field("", description="Host type")
    vulnerabilities: List[PrismaVulnerability] = Field(default_factory=list, description="List of vulnerabilities")
    cloudMetadata: Optional[PrismaCloudMetadata] = Field(None, alias="cloudMetadata", description="Cloud metadata")
    collections: List[str] = Field(default_factory=list, description="Prisma collections")

    class Config:
        """Pydantic config."""

        populate_by_name = True


class PrismaImage(BaseModel):
    """Container image scan data from Prisma Cloud Compute."""

    id: str = Field(..., alias="_id", description="Image SHA256 digest")
    imageName: str = Field("", alias="imageName", description="Image name")
    repoTag: Optional[PrismaRepoTag] = Field(None, alias="repoTag", description="Repository tag info")
    scanTime: datetime = Field(..., alias="scanTime", description="Last scan timestamp")
    distro: str = Field("", description="Base OS distribution")
    vulnerabilities: List[PrismaVulnerability] = Field(default_factory=list, description="List of vulnerabilities")
    collections: List[str] = Field(default_factory=list, description="Prisma collections")
    layers: List[str] = Field(default_factory=list, description="Image layers")
    packages: List[Dict] = Field(default_factory=list, description="Installed packages")

    class Config:
        """Pydantic config."""

        populate_by_name = True


class PrismaPackage(BaseModel):
    """Software package from SBOM or image scan."""

    name: str = Field(..., description="Package name")
    version: str = Field(..., description="Package version")
    license: str = Field("", description="Package license")
    type: str = Field("library", description="Package type (library, application, etc.)")
    purl: str = Field("", description="Package URL (PURL)")
    cpe: str = Field("", description="Common Platform Enumeration")
    author: str = Field("", description="Package author/supplier")


class PrismaCycloneDXMetadata(BaseModel):
    """CycloneDX SBOM metadata."""

    timestamp: Optional[datetime] = None
    component: Optional[Dict] = None


class PrismaSBOM(BaseModel):
    """SBOM data in CycloneDX format."""

    bomFormat: str = Field(..., alias="bomFormat", description="BOM format (should be 'CycloneDX')")
    specVersion: str = Field(..., alias="specVersion", description="CycloneDX specification version")
    serialNumber: str = Field("", alias="serialNumber", description="Unique SBOM serial number")
    metadata: Optional[PrismaCycloneDXMetadata] = None
    components: List[Dict] = Field(default_factory=list, description="Software components")

    class Config:
        """Pydantic config."""

        populate_by_name = True
