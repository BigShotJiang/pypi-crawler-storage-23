"""
Shared constants for the Tenable V2 integration.
"""

REGSCALE_INC = "RegScale, Inc."
REGSCALE_CLI = "RegScale CLI"
FULLY_IMPLEMENTED = "Fully Implemented"
NOT_IMPLEMENTED = "Not Implemented"
IN_REMEDIATION = "In Remediation"
ARTIFACTS_DIR = "./artifacts"
