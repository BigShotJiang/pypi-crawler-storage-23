#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SentinelOne Threat model for RegScale integration.

This module defines the SentinelOneThreat dataclass for representing
threat detections from SentinelOne and converting them to IntegrationFinding.
"""

import dataclasses
import logging
from typing import Any, Dict, List, Optional

from regscale.models import regscale_models

logger = logging.getLogger("regscale")


@dataclasses.dataclass
class SentinelOneThreat:
    """
    Represents a SentinelOne threat detection.

    Maps SentinelOne threat data to IntegrationFinding format.
    """

    # Core identification
    threat_id: str
    threat_name: str

    # Classification
    classification: Optional[str] = None
    classification_source: Optional[str] = None
    analyst_verdict: Optional[str] = None
    confidence_level: Optional[str] = None

    # Severity and status
    mitigation_status: Optional[str] = None
    incident_status: Optional[str] = None
    threat_reboot_required: bool = False

    # Agent information
    agent_id: Optional[str] = None
    agent_computer_name: Optional[str] = None
    agent_os: Optional[str] = None
    agent_uuid: Optional[str] = None

    # File information
    file_path: Optional[str] = None
    file_sha256: Optional[str] = None
    file_sha1: Optional[str] = None
    file_md5: Optional[str] = None
    file_content_hash: Optional[str] = None

    # Process information
    process_name: Optional[str] = None
    process_user: Optional[str] = None

    # Network information
    external_ticket_id: Optional[str] = None

    # Location
    site_id: Optional[str] = None
    site_name: Optional[str] = None
    account_id: Optional[str] = None
    account_name: Optional[str] = None

    # Timestamps
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    identified_at: Optional[str] = None
    mitigated_at: Optional[str] = None

    # Mitigation details
    mitigation_actions: Optional[List[Dict[str, Any]]] = None
    initiated_by: Optional[str] = None
    initiated_by_description: Optional[str] = None

    # MITRE ATT&CK
    mitre_techniques: Optional[List[Dict[str, Any]]] = None

    # Raw data
    raw_data: Optional[Dict[str, Any]] = None

    @classmethod
    def from_sentinelone_data(cls, data: Dict[str, Any]) -> "SentinelOneThreat":
        """
        Create SentinelOneThreat from SentinelOne API response data.

        Args:
            data: Threat data from SentinelOne API

        Returns:
            SentinelOneThreat instance
        """
        # Extract threat info which may be nested
        threat_info = data.get("threatInfo", data)
        agent_data = data.get("agentRealtimeInfo", data)

        return cls(
            threat_id=data.get("id", ""),
            threat_name=threat_info.get("threatName") or threat_info.get("classification", "Unknown Threat"),
            classification=threat_info.get("classification"),
            classification_source=threat_info.get("classificationSource"),
            analyst_verdict=threat_info.get("analystVerdict"),
            confidence_level=threat_info.get("confidenceLevel"),
            mitigation_status=threat_info.get("mitigationStatus"),
            incident_status=threat_info.get("incidentStatus"),
            threat_reboot_required=threat_info.get("rebootRequired", False),
            agent_id=agent_data.get("agentId") or data.get("agentId"),
            agent_computer_name=agent_data.get("agentComputerName") or data.get("agentComputerName"),
            agent_os=agent_data.get("agentOsName"),
            agent_uuid=agent_data.get("agentUuid"),
            file_path=threat_info.get("filePath"),
            file_sha256=threat_info.get("sha256"),
            file_sha1=threat_info.get("sha1"),
            file_md5=threat_info.get("md5"),
            file_content_hash=threat_info.get("contentHash"),
            process_name=threat_info.get("processName"),
            process_user=threat_info.get("processUser"),
            external_ticket_id=data.get("externalTicketId"),
            site_id=agent_data.get("siteId") or data.get("siteId"),
            site_name=agent_data.get("siteName") or data.get("siteName"),
            account_id=agent_data.get("accountId") or data.get("accountId"),
            account_name=agent_data.get("accountName") or data.get("accountName"),
            created_at=data.get("createdAt"),
            updated_at=data.get("updatedAt"),
            identified_at=threat_info.get("identifiedAt"),
            mitigated_at=threat_info.get("mitigatedAt"),
            mitigation_actions=threat_info.get("mitigationActions"),
            initiated_by=threat_info.get("initiatedBy"),
            initiated_by_description=threat_info.get("initiatedByDescription"),
            mitre_techniques=data.get("indicators"),
            raw_data=data,
        )

    def get_severity(self) -> regscale_models.IssueSeverity:
        """
        Map threat confidence/classification to RegScale severity.

        Returns:
            IssueSeverity enum value
        """
        severity = self._get_severity_from_confidence()
        if severity:
            return severity

        severity = self._get_severity_from_classification()
        if severity:
            return severity

        return regscale_models.IssueSeverity.High

    def _get_severity_from_confidence(self) -> Optional[regscale_models.IssueSeverity]:
        """
        Map confidence level to severity.

        Returns:
            IssueSeverity based on confidence level, or None if no confidence set
        """
        if not self.confidence_level:
            return None

        confidence_map = {
            "malicious": regscale_models.IssueSeverity.Critical,
            "suspicious": regscale_models.IssueSeverity.High,
            "n/a": regscale_models.IssueSeverity.Moderate,
        }
        return self._match_severity(self.confidence_level, confidence_map)

    def _get_severity_from_classification(self) -> Optional[regscale_models.IssueSeverity]:
        """
        Map classification to severity.

        Returns:
            IssueSeverity based on threat classification, or None if no classification set
        """
        if not self.classification:
            return None

        classification_map = {
            "malware": regscale_models.IssueSeverity.Critical,
            "ransomware": regscale_models.IssueSeverity.Critical,
            "trojan": regscale_models.IssueSeverity.Critical,
            "virus": regscale_models.IssueSeverity.Critical,
            "worm": regscale_models.IssueSeverity.High,
            "spyware": regscale_models.IssueSeverity.High,
            "adware": regscale_models.IssueSeverity.Moderate,
            "pup": regscale_models.IssueSeverity.Low,
        }
        return self._match_severity(self.classification, classification_map)

    @staticmethod
    def _match_severity(
        value: str,
        mapping: Dict[str, regscale_models.IssueSeverity],
    ) -> Optional[regscale_models.IssueSeverity]:
        """
        Match a value against a severity mapping.

        Args:
            value: Value to match (case-insensitive)
            mapping: Dictionary of keywords to IssueSeverity values

        Returns:
            IssueSeverity if a keyword matches, None otherwise
        """
        value_lower = value.lower()
        for key, severity in mapping.items():
            if key in value_lower:
                return severity
        return None

    def get_status(self) -> regscale_models.IssueStatus:
        """
        Map threat mitigation status to RegScale issue status.

        Returns:
            IssueStatus enum value
        """
        closed_statuses = {"mitigated", "resolved", "blocked", "killed", "quarantined", "remediated"}

        if self.mitigation_status:
            if self.mitigation_status.lower() in closed_statuses:
                return regscale_models.IssueStatus.Closed

        if self.analyst_verdict:
            if self.analyst_verdict.lower() in {"false_positive", "suspicious_false_positive"}:
                return regscale_models.IssueStatus.Closed

        return regscale_models.IssueStatus.Open

    def get_asset_identifier(self) -> str:
        """
        Get asset identifier for linking to RegScale asset.

        Returns:
            Asset identifier string
        """
        if self.agent_id and self.agent_uuid:
            return "s1-%s-%s" % (self.agent_id, self.agent_uuid[:8])
        if self.agent_id:
            return "s1-%s-unknown" % self.agent_id
        return ""

    def get_external_id(self) -> str:
        """
        Get unique external ID for deduplication.

        Returns:
            External ID string
        """
        return "s1-threat-%s" % self.threat_id

    def get_title(self) -> str:
        """
        Build title for the finding.

        Returns:
            Title string
        """
        parts = []

        if self.classification:
            parts.append("[%s]" % self.classification.upper())

        parts.append(self.threat_name)

        if self.agent_computer_name:
            parts.append("on %s" % self.agent_computer_name)

        return " ".join(parts)

    def get_description(self) -> str:
        """
        Build description for the finding.

        Returns:
            Description string
        """
        lines = []

        lines.append("SentinelOne Threat Detection")
        lines.append("")

        if self.classification:
            lines.append("Classification: %s" % self.classification)
        if self.confidence_level:
            lines.append("Confidence: %s" % self.confidence_level)
        if self.analyst_verdict:
            lines.append("Analyst Verdict: %s" % self.analyst_verdict)

        lines.append("")

        if self.file_path:
            lines.append("File Path: %s" % self.file_path)
        if self.file_sha256:
            lines.append("SHA256: %s" % self.file_sha256)
        if self.process_name:
            lines.append("Process: %s" % self.process_name)
        if self.process_user:
            lines.append("User: %s" % self.process_user)

        if self.mitre_techniques:
            lines.append("")
            lines.append("MITRE ATT&CK Techniques:")
            for technique in self.mitre_techniques[:5]:  # Limit to 5
                tactic = technique.get("tactic", "Unknown")
                technique_id = technique.get("techniqueId", "Unknown")
                lines.append("  - %s (%s)" % (technique_id, tactic))

        return "\n".join(lines)

    def get_remediation(self) -> str:
        """
        Build remediation guidance.

        Returns:
            Remediation string
        """
        lines = []

        if self.mitigation_status:
            lines.append("Current Status: %s" % self.mitigation_status)

        if self.mitigation_actions:
            lines.append("")
            lines.append("Mitigation Actions Taken:")
            for action in self.mitigation_actions:
                action_type = action.get("actionType", "Unknown")
                status = action.get("status", "Unknown")
                lines.append("  - %s: %s" % (action_type, status))

        if not lines:
            lines.append("Review threat details and take appropriate action in SentinelOne console.")

        return "\n".join(lines)
