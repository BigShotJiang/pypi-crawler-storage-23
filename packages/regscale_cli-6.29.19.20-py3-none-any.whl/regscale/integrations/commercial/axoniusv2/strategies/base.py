"""Abstract base class for Axonius V2 sync strategies."""

from abc import ABC, abstractmethod
from collections.abc import Iterator

from regscale.integrations.scanner.models.integration_asset import IntegrationAsset
from regscale.integrations.scanner.models.integration_finding import IntegrationFinding


class BaseSyncStrategy(ABC):
    """Abstract base for sync strategies."""

    @abstractmethod
    def iter_assets(self, client, plan_id: int, **kwargs) -> Iterator[IntegrationAsset]:
        """Iterate over assets from Axonius."""

    @abstractmethod
    def iter_findings(self, client, plan_id: int, **kwargs) -> Iterator[IntegrationFinding]:
        """Iterate over findings from Axonius."""
