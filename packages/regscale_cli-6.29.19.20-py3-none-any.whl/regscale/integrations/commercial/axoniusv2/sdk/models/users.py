"""User-related models."""

from __future__ import annotations

from datetime import datetime

from pydantic import Field

from .common import BaseAxoniusModel, PaginatedResponse


class UserRole(BaseAxoniusModel):
    """User role information."""

    id: str = Field(description="Role ID")
    name: str = Field(description="Role name")


class User(BaseAxoniusModel):
    """Represents an Axonius user."""

    id: str = Field(description="User ID")
    uuid: str = Field(description="User UUID")
    user_name: str = Field(description="Username")
    first_name: str | None = Field(default=None, description="First name")
    last_name: str | None = Field(default=None, description="Last name")
    email: str | None = Field(default=None, description="Email address")
    source: str | None = Field(default=None, description="User source (local, LDAP, SAML, etc.)")
    is_admin: bool = Field(default=False, description="Whether user is admin")
    is_active: bool = Field(default=True, description="Whether user is active")
    roles: list[UserRole] = Field(default_factory=list, description="Assigned roles")
    last_login: datetime | None = Field(default=None, description="Last login timestamp")
    created_at: datetime | None = Field(default=None, description="Creation timestamp")


class UserRequest(BaseAxoniusModel):
    """Request body for creating/updating a user."""

    user_name: str = Field(description="Username")
    first_name: str | None = Field(default=None, description="First name")
    last_name: str | None = Field(default=None, description="Last name")
    email: str | None = Field(default=None, description="Email address")
    password: str | None = Field(default=None, description="Password for local users")
    role_ids: list[str] = Field(default_factory=list, description="Role IDs to assign")


class UsersResponse(PaginatedResponse):
    """Response containing a list of users."""

    users: list[User] = Field(default_factory=list, description="List of users")
