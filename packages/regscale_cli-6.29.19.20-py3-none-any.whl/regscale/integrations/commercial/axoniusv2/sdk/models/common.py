"""Common models shared across the SDK."""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class BaseAxoniusModel(BaseModel):
    """Base model with common configuration for all Axonius models."""

    model_config = ConfigDict(
        populate_by_name=True,
        extra="allow",  # Allow extra fields from API responses
        str_strip_whitespace=True,
    )


class PageMetadata(BaseAxoniusModel):
    """Pagination metadata."""

    number: int | None = Field(default=None, description="Current page number")
    size: int | None = Field(default=None, description="Page size")
    offset: int | None = Field(default=None, description="Offset from start")
    limit: int | None = Field(default=None, description="Page limit")
    total_pages: int = Field(alias="totalPages", description="Total number of pages")
    total_resources: int = Field(alias="totalResources", description="Total number of resources")


class MetadataModel(BaseAxoniusModel):
    """Response metadata including caching and pagination info."""

    cache_last_updated: datetime | None = Field(default=None, description="When the cache was last updated")
    is_data_from_cache: bool | None = Field(default=None, description="Whether data came from cache")
    page: PageMetadata | None = Field(default=None, description="Pagination information")
    next_page: str | None = Field(default=None, description="Token for next page")


class ErrorDetail(BaseAxoniusModel):
    """Individual error detail."""

    error: str = Field(description="Error type")
    description: str = Field(description="Error description")


class ErrorResponse(BaseAxoniusModel):
    """Standard error response from the API."""

    errors: list[ErrorDetail] = Field(default_factory=list, description="List of errors")
    error_id: str | None = Field(default=None, description="Unique error identifier")


class PaginatedResponse(BaseAxoniusModel):
    """Base class for paginated responses."""

    meta: MetadataModel | None = Field(default=None, description="Response metadata")
    next_page: str | None = Field(default=None, description="Top-level next page token")

    @property
    def has_next_page(self) -> bool:
        """Check if there's a next page."""
        if self.next_page is not None:
            return True
        return self.meta is not None and self.meta.next_page is not None

    @property
    def next_page_token(self) -> str | None:
        """Get the next page token."""
        if self.next_page is not None:
            return self.next_page
        return self.meta.next_page if self.meta else None

    @property
    def total_count(self) -> int | None:
        """Get total resource count."""
        if self.meta and self.meta.page:
            return self.meta.page.total_resources
        return None
