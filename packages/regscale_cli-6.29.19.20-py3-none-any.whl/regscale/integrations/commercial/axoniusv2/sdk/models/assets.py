"""Asset-related models."""

from __future__ import annotations

from datetime import date
from typing import Any

from pydantic import AliasChoices, Field, field_validator

from .common import BaseAxoniusModel, PaginatedResponse


class PageParams(BaseAxoniusModel):
    """Pagination parameters for requests."""

    number: int | None = Field(default=None, ge=1, description="Page number (1-indexed)")
    size: int | None = Field(default=None, ge=1, le=2000, description="Number of items per page")
    offset: int | None = Field(default=None, ge=0, description="Offset from start")


class AssetRequest(BaseAxoniusModel):
    """Request body for getting assets."""

    include_metadata: bool = Field(default=True, description="Include metadata in response")
    saved_query_id: str | None = Field(default=None, description="ID of saved query to use")
    saved_query_name: str | None = Field(default=None, description="Name of saved query to use")
    query: str | None = Field(default=None, description="AQL query string")
    history: date | None = Field(default=None, description="Historical snapshot date (YYYY-MM-DD)")
    page: PageParams | None = Field(default=None, description="Pagination parameters")
    next_page: str | None = Field(default=None, description="Next page token for cursor pagination")
    fields: list[str] | None = Field(default=None, description="Fields to include in response")
    fields_to_exclude: list[str] | None = Field(default=None, description="Fields to exclude from response")
    use_cache_entry: bool = Field(default=True, description="Use cached results if available")
    include_details: bool = Field(default=True, description="Include non-aggregated field details")


class Asset(BaseAxoniusModel):
    """Represents an Axonius asset."""

    internal_axon_id: str = Field(description="Internal Axonius asset ID")
    adapters: list[str] = Field(default_factory=list, description="Source adapters")
    adapter_list_length: int = Field(default=0, description="Number of adapters")

    def get_field(self, field_path: str, default: Any = None) -> Any:
        """Get a field value by dotted path notation.

        Args:
            field_path: Field path like 'specific_data.data.hostname'
            default: Default value if field not found

        Returns:
            Field value or default
        """
        # Fields come as flat keys with dots
        extras = self.model_extra or {}
        if field_path in extras:
            return extras[field_path]
        return default


class AssetResponse(PaginatedResponse):
    """Response containing a list of assets."""

    assets: list[Asset] = Field(
        default_factory=list,
        validation_alias=AliasChoices("assets", "data"),
        description="List of assets",
    )


class AssetCountRequest(BaseAxoniusModel):
    """Request body for counting assets."""

    saved_query_id: str | None = Field(default=None, description="ID of saved query")
    saved_query_name: str | None = Field(default=None, description="Name of saved query")
    query: str | None = Field(default=None, description="AQL query string")
    history: date | None = Field(default=None, description="Historical snapshot date")
    use_cache_entry: bool = Field(default=True, description="Use cached results")


class AssetCountResponse(BaseAxoniusModel):
    """Response containing asset count."""

    count: int = Field(
        validation_alias=AliasChoices("count", "value"),
        description="Number of matching assets",
    )


class AssetField(BaseAxoniusModel):
    """Represents an asset field definition."""

    name: str = Field(description="Field name")
    title: str = Field(description="Display title")
    type: str = Field(description="Field type")
    adapter_name: str | None = Field(default=None, description="Source adapter")
    is_complex: bool = Field(default=False, description="Whether field is complex")
    is_root: bool = Field(default=False, description="Whether field is root level")


class AssetFieldsResponse(BaseAxoniusModel):
    """Response containing available asset fields."""

    fields: list[AssetField] = Field(default_factory=list, description="Available fields")


MAX_TAG_LENGTH = 1000


class TagsRequest(BaseAxoniusModel):
    """Request body for adding/removing tags."""

    entities: dict[str, list[str]] = Field(description="Mapping of internal_axon_id to list of tags")

    @field_validator("entities")
    @classmethod
    def validate_tag_lengths(cls, v: dict[str, list[str]]) -> dict[str, list[str]]:
        """Validate that no tag exceeds the maximum allowed length."""
        for tags in v.values():
            for tag in tags:
                if len(tag) > MAX_TAG_LENGTH:
                    raise ValueError("Tag exceeds maximum length of %d characters" % MAX_TAG_LENGTH)
        return v


class UpdateCustomFieldsRequest(BaseAxoniusModel):
    """Request body for updating custom fields."""

    internal_axon_ids: list[str] = Field(description="Asset IDs to update")
    custom_fields: dict[str, Any] = Field(description="Custom field values to set")


class LinkAssetsRequest(BaseAxoniusModel):
    """Request body for linking/unlinking assets."""

    source_asset_id: str = Field(description="Source asset internal_axon_id")
    target_asset_ids: list[str] = Field(description="Target asset internal_axon_ids")
