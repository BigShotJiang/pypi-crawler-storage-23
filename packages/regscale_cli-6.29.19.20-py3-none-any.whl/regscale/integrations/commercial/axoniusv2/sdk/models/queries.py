"""Query-related models."""

from __future__ import annotations

from datetime import datetime

from pydantic import AliasChoices, Field

from .common import BaseAxoniusModel, PaginatedResponse


class QueryFolder(BaseAxoniusModel):
    """Represents a query folder."""

    id: str = Field(description="Folder ID")
    name: str = Field(description="Folder name")
    parent_id: str | None = Field(default=None, description="Parent folder ID")


class Query(BaseAxoniusModel):
    """Represents a saved query."""

    id: str = Field(description="Query ID")
    uuid: str | None = Field(default=None, description="Query UUID")
    name: str = Field(description="Query name")
    description: str | None = Field(default=None, description="Query description")
    asset_type: str = Field(description="Asset type for this query")
    query: str | None = Field(default=None, description="AQL query string")
    folder_id: str | None = Field(default=None, description="Parent folder ID")
    is_default: bool = Field(default=False, description="Whether this is a default query")
    created_by: str | None = Field(default=None, description="Creator user ID")
    created_at: datetime | None = Field(default=None, description="Creation timestamp")
    updated_at: datetime | None = Field(default=None, description="Last update timestamp")
    fields: list[str] = Field(default_factory=list, description="Fields to include")
    tags: list[str] = Field(default_factory=list, description="Query tags")


class QueryRequest(BaseAxoniusModel):
    """Request body for creating/updating a query."""

    name: str = Field(description="Query name")
    description: str | None = Field(default=None, description="Query description")
    query: str | None = Field(default=None, description="AQL query string")
    folder_id: str | None = Field(default=None, description="Parent folder ID")
    fields: list[str] = Field(default_factory=list, description="Fields to include")
    tags: list[str] = Field(default_factory=list, description="Query tags")


class QueryResponse(PaginatedResponse):
    """Response containing a list of queries."""

    queries: list[Query] = Field(
        default_factory=list,
        validation_alias=AliasChoices("queries", "data"),
        description="List of queries",
    )
