"""Pydantic models for the Axonious SDK."""

from .activity_logs import (
    ActivityLog,
    ActivityLogsResponse,
)
from .adapters import (
    Adapter,
    AdapterConnection,
    AdapterConnectionRequest,
    AdaptersResponse,
)
from .assets import (
    Asset,
    AssetCountRequest,
    AssetCountResponse,
    AssetField,
    AssetFieldsResponse,
    AssetRequest,
    AssetResponse,
    LinkAssetsRequest,
    PageParams,
    TagsRequest,
    UpdateCustomFieldsRequest,
)
from .common import (
    ErrorDetail,
    ErrorResponse,
    MetadataModel,
    PageMetadata,
)
from .discovery import (
    DiscoveryResponse,
    DiscoveryStatus,
)
from .queries import (
    Query,
    QueryFolder,
    QueryRequest,
    QueryResponse,
)
from .tags import (
    Tag,
    TagsResponse,
)
from .users import (
    User,
    UserRequest,
    UsersResponse,
)

__all__ = [
    # Assets
    "Asset",
    "AssetCountRequest",
    "AssetCountResponse",
    "AssetField",
    "AssetFieldsResponse",
    "AssetRequest",
    "AssetResponse",
    "LinkAssetsRequest",
    "PageParams",
    "TagsRequest",
    "UpdateCustomFieldsRequest",
    # Common
    "ErrorDetail",
    "ErrorResponse",
    "MetadataModel",
    "PageMetadata",
    # Adapters
    "Adapter",
    "AdapterConnection",
    "AdapterConnectionRequest",
    "AdaptersResponse",
    # Queries
    "Query",
    "QueryFolder",
    "QueryRequest",
    "QueryResponse",
    # Activity Logs
    "ActivityLog",
    "ActivityLogsResponse",
    # Discovery
    "DiscoveryStatus",
    "DiscoveryResponse",
    # Users
    "User",
    "UserRequest",
    "UsersResponse",
    # Tags
    "Tag",
    "TagsResponse",
]
