"""Main Axonius client."""

from __future__ import annotations

from types import TracebackType

from .api.activity_logs import ActivityLogsAPI
from .api.adapters import AdaptersAPI
from .api.assets import AssetsAPI
from .api.discovery import DiscoveryAPI
from .api.queries import QueriesAPI
from .api.tags import TagsAPI
from .api.users import UsersAPI
from .config import AxoniusConfig
from .transport import HTTPTransport


class AxoniusClient:
    """Main client for interacting with the Axonius API.

    This client provides both synchronous and asynchronous access to the Axonius API.
    Use the sync methods directly, or use the async methods prefixed with 'a'.

    Example (sync):
        >>> from axonious import AxoniusClient
        >>> client = AxoniusClient(
        ...     host="myaxonius.example.com",
        ...     api_key="my-api-key",
        ...     api_secret="my-api-secret",
        ... )
        >>> devices = client.assets.get("devices", page_size=10)
        >>> for device in devices.assets:
        ...     print(device.get_field("specific_data.data.hostname"))
        >>> client.close()

    Example (async):
        >>> import asyncio
        >>> from axonious import AxoniusClient
        >>> async def main():
        ...     client = AxoniusClient(
        ...         host="myaxonius.example.com",
        ...         api_key="my-api-key",
        ...         api_secret="my-api-secret",
        ...     )
        ...     devices = await client.assets.aget("devices", page_size=10)
        ...     async for device in client.assets.aiter_all("devices"):
        ...         print(device.get_field("specific_data.data.hostname"))
        ...     await client.aclose()
        >>> asyncio.run(main())

    Example (context manager):
        >>> from axonious import AxoniusClient
        >>> with AxoniusClient(host="...", api_key="...", api_secret="...") as client:
        ...     count = client.assets.count("devices")
        ...     print(f"Total devices: {count}")

    Example (environment variables):
        Set AXONIUS_HOST, AXONIUS_API_KEY, AXONIUS_API_SECRET, then:
        >>> from axonious import AxoniusClient
        >>> client = AxoniusClient()  # Loads from environment
    """

    def __init__(
        self,
        host: str | None = None,
        api_key: str | None = None,
        api_secret: str | None = None,
        *,
        port: int = 443,
        verify_ssl: bool = True,
        timeout: float = 30.0,
        max_retries: int = 3,
        retry_delay: float = 1.0,
    ) -> None:
        """Initialize the Axonius client.

        Args:
            host: Axonius server hostname (or set AXONIUS_HOST env var)
            api_key: API key (or set AXONIUS_API_KEY env var)
            api_secret: API secret (or set AXONIUS_API_SECRET env var)
            port: Server port (default: 443)
            verify_ssl: Verify SSL certificates (default: True)
            timeout: Request timeout in seconds (default: 30.0)
            max_retries: Maximum retry attempts (default: 3)
            retry_delay: Delay between retries in seconds (default: 1.0)
        """
        # Build config from provided args or environment
        config_kwargs: dict[str, str | int | float | bool] = {}
        if host is not None:
            config_kwargs["host"] = host
        if api_key is not None:
            config_kwargs["api_key"] = api_key
        if api_secret is not None:
            config_kwargs["api_secret"] = api_secret
        config_kwargs["port"] = port
        config_kwargs["verify_ssl"] = verify_ssl
        config_kwargs["timeout"] = timeout
        config_kwargs["max_retries"] = max_retries
        config_kwargs["retry_delay"] = retry_delay

        self._config = AxoniusConfig(**config_kwargs)  # type: ignore[arg-type]
        self._transport = HTTPTransport(self._config)

        # Initialize API resources
        self._assets: AssetsAPI | None = None
        self._adapters: AdaptersAPI | None = None
        self._queries: QueriesAPI | None = None
        self._activity_logs: ActivityLogsAPI | None = None
        self._discovery: DiscoveryAPI | None = None
        self._users: UsersAPI | None = None
        self._tags: TagsAPI | None = None

    @property
    def assets(self) -> AssetsAPI:
        """Access the Assets API."""
        if self._assets is None:
            self._assets = AssetsAPI(self._transport)
        return self._assets

    @property
    def adapters(self) -> AdaptersAPI:
        """Access the Adapters API."""
        if self._adapters is None:
            self._adapters = AdaptersAPI(self._transport)
        return self._adapters

    @property
    def queries(self) -> QueriesAPI:
        """Access the Queries API."""
        if self._queries is None:
            self._queries = QueriesAPI(self._transport)
        return self._queries

    @property
    def activity_logs(self) -> ActivityLogsAPI:
        """Access the Activity Logs API."""
        if self._activity_logs is None:
            self._activity_logs = ActivityLogsAPI(self._transport)
        return self._activity_logs

    @property
    def discovery(self) -> DiscoveryAPI:
        """Access the Discovery API."""
        if self._discovery is None:
            self._discovery = DiscoveryAPI(self._transport)
        return self._discovery

    @property
    def users(self) -> UsersAPI:
        """Access the Users API."""
        if self._users is None:
            self._users = UsersAPI(self._transport)
        return self._users

    @property
    def tags(self) -> TagsAPI:
        """Access the Tags API."""
        if self._tags is None:
            self._tags = TagsAPI(self._transport)
        return self._tags

    @property
    def config(self) -> AxoniusConfig:
        """Get the client configuration."""
        return self._config

    def close(self) -> None:
        """Close the synchronous HTTP client."""
        self._transport.close()

    async def aclose(self) -> None:
        """Close the asynchronous HTTP client."""
        await self._transport.aclose()

    def __enter__(self) -> AxoniusClient:
        """Enter context manager."""
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        """Exit context manager."""
        self.close()

    async def __aenter__(self) -> AxoniusClient:
        """Enter async context manager."""
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        """Exit async context manager."""
        await self.aclose()
