"""Axonious - Modern Python SDK for the Axonius API.

This SDK provides a type-safe, async-first interface to the Axonius API
for managing cybersecurity assets, adapters, queries, and more.

Quick Start:
    >>> from axonious import AxoniusClient
    >>>
    >>> # Initialize with credentials
    >>> client = AxoniusClient(
    ...     host="myaxonius.example.com",
    ...     api_key="your-api-key",
    ...     api_secret="your-api-secret",
    ... )
    >>>
    >>> # Get devices
    >>> devices = client.assets.get("devices", page_size=10)
    >>> for device in devices.assets:
    ...     print(device.get_field("specific_data.data.hostname"))
    >>>
    >>> # Close when done
    >>> client.close()

Environment Variables:
    AXONIUS_HOST: Server hostname
    AXONIUS_API_KEY: API key
    AXONIUS_API_SECRET: API secret
"""

from .client import AxoniusClient
from .config import AxoniusConfig
from .exceptions import (
    APIError,
    AuthenticationError,
    AxoniusError,
    BadRequestError,
    ConnectionError,
    NotFoundError,
    RateLimitError,
    ServerError,
    TimeoutError,
    ValidationError,
)
from .types import AssetType, AuditCategory, DiscoveryStatus, SortDirection

__version__ = "0.1.0"

__all__ = [
    # Client
    "AxoniusClient",
    "AxoniusConfig",
    # Exceptions
    "AxoniusError",
    "APIError",
    "AuthenticationError",
    "BadRequestError",
    "ConnectionError",
    "NotFoundError",
    "RateLimitError",
    "ServerError",
    "TimeoutError",
    "ValidationError",
    # Types
    "AssetType",
    "AuditCategory",
    "DiscoveryStatus",
    "SortDirection",
    # Version
    "__version__",
]
