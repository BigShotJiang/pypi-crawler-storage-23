"""Queries API implementation."""

from __future__ import annotations

from .base import BaseAPI
from ..models.queries import (
    Query,
    QueryFolder,
    QueryRequest,
    QueryResponse,
)
from ..types import AssetType


class QueriesAPI(BaseAPI):
    """API for managing saved queries."""

    def list(self, asset_type: AssetType | None = None) -> QueryResponse:
        """List all saved queries.

        Args:
            asset_type: Filter by asset type

        Returns:
            QueryResponse containing list of queries
        """
        if asset_type:
            data = self._get(f"/v2/queries/{asset_type}")
        else:
            data = self._get("/v2/queries")
        return QueryResponse.model_validate(data)

    async def alist(self, asset_type: AssetType | None = None) -> QueryResponse:
        """Async version of list()."""
        if asset_type:
            data = await self._aget(f"/v2/queries/{asset_type}")
        else:
            data = await self._aget("/v2/queries")
        return QueryResponse.model_validate(data)

    def get(self, query_id: str) -> Query:
        """Get a specific query by ID.

        Args:
            query_id: Query ID

        Returns:
            Query
        """
        data = self._get(f"/v2/queries/{query_id}")
        return Query.model_validate(data)

    async def aget(self, query_id: str) -> Query:
        """Async version of get()."""
        data = await self._aget(f"/v2/queries/{query_id}")
        return Query.model_validate(data)

    def create(
        self,
        asset_type: AssetType,
        name: str,
        *,
        query: str | None = None,
        description: str | None = None,
        folder_id: str | None = None,
        fields: list[str] | None = None,
        tags: list[str] | None = None,
    ) -> Query:
        """Create a new saved query.

        Args:
            asset_type: Asset type for the query
            name: Query name
            query: AQL query string
            description: Query description
            folder_id: Parent folder ID
            fields: Fields to include
            tags: Query tags

        Returns:
            Created Query
        """
        request = QueryRequest(
            name=name,
            query=query,
            description=description,
            folder_id=folder_id,
            fields=fields or [],
            tags=tags or [],
        )

        data = self._post(
            f"/v2/queries/{asset_type}",
            data=request.model_dump(exclude_none=True, by_alias=True),
        )
        return Query.model_validate(data)

    async def acreate(
        self,
        asset_type: AssetType,
        name: str,
        *,
        query: str | None = None,
        description: str | None = None,
        folder_id: str | None = None,
        fields: list[str] | None = None,
        tags: list[str] | None = None,
    ) -> Query:
        """Async version of create()."""
        request = QueryRequest(
            name=name,
            query=query,
            description=description,
            folder_id=folder_id,
            fields=fields or [],
            tags=tags or [],
        )

        data = await self._apost(
            f"/v2/queries/{asset_type}",
            data=request.model_dump(exclude_none=True, by_alias=True),
        )
        return Query.model_validate(data)

    def update(
        self,
        query_id: str,
        *,
        name: str | None = None,
        query: str | None = None,
        description: str | None = None,
        folder_id: str | None = None,
        fields: list[str] | None = None,
        tags: list[str] | None = None,
    ) -> Query:
        """Update an existing query.

        Args:
            query_id: Query ID
            name: New query name
            query: New AQL query string
            description: New description
            folder_id: New parent folder ID
            fields: New fields list
            tags: New tags list

        Returns:
            Updated Query
        """
        update_data = {}
        if name is not None:
            update_data["name"] = name
        if query is not None:
            update_data["query"] = query
        if description is not None:
            update_data["description"] = description
        if folder_id is not None:
            update_data["folder_id"] = folder_id
        if fields is not None:
            update_data["fields"] = fields
        if tags is not None:
            update_data["tags"] = tags

        data = self._put(f"/v2/queries/{query_id}", data=update_data)
        return Query.model_validate(data)

    async def aupdate(
        self,
        query_id: str,
        *,
        name: str | None = None,
        query: str | None = None,
        description: str | None = None,
        folder_id: str | None = None,
        fields: list[str] | None = None,
        tags: list[str] | None = None,
    ) -> Query:
        """Async version of update()."""
        update_data = {}
        if name is not None:
            update_data["name"] = name
        if query is not None:
            update_data["query"] = query
        if description is not None:
            update_data["description"] = description
        if folder_id is not None:
            update_data["folder_id"] = folder_id
        if fields is not None:
            update_data["fields"] = fields
        if tags is not None:
            update_data["tags"] = tags

        data = await self._aput(f"/v2/queries/{query_id}", data=update_data)
        return Query.model_validate(data)

    def delete(self, query_id: str) -> None:
        """Delete a query.

        Args:
            query_id: Query ID
        """
        self._delete(f"/v2/queries/{query_id}")

    async def adelete(self, query_id: str) -> None:
        """Async version of delete()."""
        await self._adelete(f"/v2/queries/{query_id}")

    def list_folders(self) -> list[QueryFolder]:
        """List all query folders.

        Returns:
            List of QueryFolder
        """
        data = self._get("/v2/queries/folders")
        return [QueryFolder.model_validate(f) for f in data.get("folders", [])]

    async def alist_folders(self) -> list[QueryFolder]:
        """Async version of list_folders()."""
        data = await self._aget("/v2/queries/folders")
        return [QueryFolder.model_validate(f) for f in data.get("folders", [])]
