"""Users API implementation."""

from __future__ import annotations

from .base import BaseAPI
from ..models.users import User, UserRequest, UsersResponse

_USERS_PATH = "/v2/users"


class UsersAPI(BaseAPI):
    """API for managing Axonius users."""

    def list(self) -> UsersResponse:
        """List all users.

        Returns:
            UsersResponse containing list of users
        """
        data = self._get(_USERS_PATH)
        return UsersResponse.model_validate(data)

    async def alist(self) -> UsersResponse:
        """Async version of list()."""
        data = await self._aget(_USERS_PATH)
        return UsersResponse.model_validate(data)

    def get(self, user_id: str) -> User:
        """Get a specific user.

        Args:
            user_id: User ID

        Returns:
            User
        """
        data = self._get(f"{_USERS_PATH}/{user_id}")
        return User.model_validate(data)

    async def aget(self, user_id: str) -> User:
        """Async version of get()."""
        data = await self._aget(f"{_USERS_PATH}/{user_id}")
        return User.model_validate(data)

    def create(
        self,
        user_name: str,
        *,
        email: str | None = None,
        first_name: str | None = None,
        last_name: str | None = None,
        password: str | None = None,
        role_ids: list[str] | None = None,
    ) -> User:
        """Create a new user.

        Args:
            user_name: Username
            email: Email address
            first_name: First name
            last_name: Last name
            password: Password (for local users)
            role_ids: Role IDs to assign

        Returns:
            Created User
        """
        request = UserRequest(
            user_name=user_name,
            email=email,
            first_name=first_name,
            last_name=last_name,
            password=password,
            role_ids=role_ids or [],
        )

        data = self._post(_USERS_PATH, data=request.model_dump(exclude_none=True, by_alias=True))
        return User.model_validate(data)

    async def acreate(
        self,
        user_name: str,
        *,
        email: str | None = None,
        first_name: str | None = None,
        last_name: str | None = None,
        password: str | None = None,
        role_ids: list[str] | None = None,
    ) -> User:
        """Async version of create()."""
        request = UserRequest(
            user_name=user_name,
            email=email,
            first_name=first_name,
            last_name=last_name,
            password=password,
            role_ids=role_ids or [],
        )

        data = await self._apost(_USERS_PATH, data=request.model_dump(exclude_none=True, by_alias=True))
        return User.model_validate(data)

    def update(
        self,
        user_id: str,
        *,
        user_name: str | None = None,
        email: str | None = None,
        first_name: str | None = None,
        last_name: str | None = None,
        role_ids: list[str] | None = None,
    ) -> User:
        """Update an existing user.

        Args:
            user_id: User ID
            user_name: New username
            email: New email
            first_name: New first name
            last_name: New last name
            role_ids: New role IDs

        Returns:
            Updated User
        """
        update_data = {}
        if user_name is not None:
            update_data["user_name"] = user_name
        if email is not None:
            update_data["email"] = email
        if first_name is not None:
            update_data["first_name"] = first_name
        if last_name is not None:
            update_data["last_name"] = last_name
        if role_ids is not None:
            update_data["role_ids"] = role_ids

        data = self._put(f"{_USERS_PATH}/{user_id}", data=update_data)
        return User.model_validate(data)

    async def aupdate(
        self,
        user_id: str,
        *,
        user_name: str | None = None,
        email: str | None = None,
        first_name: str | None = None,
        last_name: str | None = None,
        role_ids: list[str] | None = None,
    ) -> User:
        """Async version of update()."""
        update_data = {}
        if user_name is not None:
            update_data["user_name"] = user_name
        if email is not None:
            update_data["email"] = email
        if first_name is not None:
            update_data["first_name"] = first_name
        if last_name is not None:
            update_data["last_name"] = last_name
        if role_ids is not None:
            update_data["role_ids"] = role_ids

        data = await self._aput(f"{_USERS_PATH}/{user_id}", data=update_data)
        return User.model_validate(data)

    def delete(self, user_id: str) -> None:
        """Delete a user.

        Args:
            user_id: User ID
        """
        self._delete(f"{_USERS_PATH}/{user_id}")

    async def adelete(self, user_id: str) -> None:
        """Async version of delete()."""
        await self._adelete(f"{_USERS_PATH}/{user_id}")
