"""Assets API implementation."""

from __future__ import annotations

from collections.abc import AsyncIterator, Iterator
from typing import TYPE_CHECKING, Any

from .base import BaseAPI
from ..models.assets import (
    Asset,
    AssetCountRequest,
    AssetCountResponse,
    AssetFieldsResponse,
    AssetRequest,
    AssetResponse,
    PageParams,
    TagsRequest,
    UpdateCustomFieldsRequest,
)
from ..types import AssetType

if TYPE_CHECKING:
    from datetime import date


class AssetsAPI(BaseAPI):
    """API for managing Axonius assets."""

    def get(
        self,
        asset_type: AssetType,
        *,
        query: str | None = None,
        saved_query_id: str | None = None,
        saved_query_name: str | None = None,
        fields: list[str] | None = None,
        fields_to_exclude: list[str] | None = None,
        page_number: int | None = None,
        page_size: int | None = None,
        history: date | None = None,
        use_cache: bool = True,
        include_details: bool = True,
        include_metadata: bool = True,
    ) -> AssetResponse:
        """Get assets matching the specified criteria.

        Args:
            asset_type: Type of assets to retrieve (devices, users, etc.)
            query: AQL query string
            saved_query_id: ID of a saved query to use
            saved_query_name: Name of a saved query to use
            fields: List of field paths to include
            fields_to_exclude: List of field paths to exclude
            page_number: Page number (1-indexed)
            page_size: Number of results per page
            history: Historical snapshot date
            use_cache: Use cached results if available
            include_details: Include non-aggregated field details
            include_metadata: Include response metadata

        Returns:
            AssetResponse containing matching assets
        """
        request = AssetRequest(
            query=query,
            saved_query_id=saved_query_id,
            saved_query_name=saved_query_name,
            fields=fields,
            fields_to_exclude=fields_to_exclude,
            page=PageParams(number=page_number, size=page_size) if page_number or page_size else None,
            history=history,
            use_cache_entry=use_cache,
            include_details=include_details,
            include_metadata=include_metadata,
        )

        data = self._post(
            f"/v2/assets/{asset_type}",
            data=request.model_dump(exclude_none=True, by_alias=True),
        )
        return AssetResponse.model_validate(data)

    async def aget(
        self,
        asset_type: AssetType,
        *,
        query: str | None = None,
        saved_query_id: str | None = None,
        saved_query_name: str | None = None,
        fields: list[str] | None = None,
        fields_to_exclude: list[str] | None = None,
        page_number: int | None = None,
        page_size: int | None = None,
        history: date | None = None,
        use_cache: bool = True,
        include_details: bool = True,
        include_metadata: bool = True,
    ) -> AssetResponse:
        """Async version of get()."""
        request = AssetRequest(
            query=query,
            saved_query_id=saved_query_id,
            saved_query_name=saved_query_name,
            fields=fields,
            fields_to_exclude=fields_to_exclude,
            page=PageParams(number=page_number, size=page_size) if page_number or page_size else None,
            history=history,
            use_cache_entry=use_cache,
            include_details=include_details,
            include_metadata=include_metadata,
        )

        data = await self._apost(
            f"/v2/assets/{asset_type}",
            data=request.model_dump(exclude_none=True, by_alias=True),
        )
        return AssetResponse.model_validate(data)

    def get_by_id(
        self,
        asset_type: AssetType,
        internal_axon_id: str,
        *,
        fields: list[str] | None = None,
    ) -> Asset:
        """Get a specific asset by its internal ID.

        Args:
            asset_type: Type of asset
            internal_axon_id: Internal Axonius ID
            fields: Fields to include

        Returns:
            The requested Asset
        """
        params: dict[str, Any] = {}
        if fields:
            params["fields"] = ",".join(fields)

        data = self._get(f"/v2/assets/{asset_type}/{internal_axon_id}", params=params)
        return Asset.model_validate(data)

    async def aget_by_id(
        self,
        asset_type: AssetType,
        internal_axon_id: str,
        *,
        fields: list[str] | None = None,
    ) -> Asset:
        """Async version of get_by_id()."""
        params: dict[str, Any] = {}
        if fields:
            params["fields"] = ",".join(fields)

        data = await self._aget(f"/v2/assets/{asset_type}/{internal_axon_id}", params=params)
        return Asset.model_validate(data)

    def count(
        self,
        asset_type: AssetType,
        *,
        query: str | None = None,
        saved_query_id: str | None = None,
        saved_query_name: str | None = None,
        history: date | None = None,
        use_cache: bool = True,
    ) -> int:
        """Count assets matching the specified criteria.

        Args:
            asset_type: Type of assets to count
            query: AQL query string
            saved_query_id: ID of a saved query
            saved_query_name: Name of a saved query
            history: Historical snapshot date
            use_cache: Use cached results

        Returns:
            Number of matching assets
        """
        request = AssetCountRequest(
            query=query,
            saved_query_id=saved_query_id,
            saved_query_name=saved_query_name,
            history=history,
            use_cache_entry=use_cache,
        )

        data = self._post(
            f"/v2/assets/{asset_type}/count",
            data=request.model_dump(exclude_none=True, by_alias=True),
        )
        return AssetCountResponse.model_validate(data).count

    async def acount(
        self,
        asset_type: AssetType,
        *,
        query: str | None = None,
        saved_query_id: str | None = None,
        saved_query_name: str | None = None,
        history: date | None = None,
        use_cache: bool = True,
    ) -> int:
        """Async version of count()."""
        request = AssetCountRequest(
            query=query,
            saved_query_id=saved_query_id,
            saved_query_name=saved_query_name,
            history=history,
            use_cache_entry=use_cache,
        )

        data = await self._apost(
            f"/v2/assets/{asset_type}/count",
            data=request.model_dump(exclude_none=True, by_alias=True),
        )
        return AssetCountResponse.model_validate(data).count

    def get_fields(self, asset_type: AssetType) -> AssetFieldsResponse:
        """Get available fields for an asset type.

        Args:
            asset_type: Type of assets

        Returns:
            Available fields
        """
        data = self._get(f"/v2/assets/{asset_type}/fields")
        return AssetFieldsResponse.model_validate(data)

    async def aget_fields(self, asset_type: AssetType) -> AssetFieldsResponse:
        """Async version of get_fields()."""
        data = await self._aget(f"/v2/assets/{asset_type}/fields")
        return AssetFieldsResponse.model_validate(data)

    def add_tags(
        self,
        asset_type: AssetType,
        entities: dict[str, list[str]],
    ) -> None:
        """Add tags to assets.

        Args:
            asset_type: Type of assets
            entities: Mapping of internal_axon_id to list of tags
        """
        request = TagsRequest(entities=entities)
        self._post(
            f"/v2/assets/{asset_type}/add_tags",
            data=request.model_dump(by_alias=True),
        )

    async def aadd_tags(
        self,
        asset_type: AssetType,
        entities: dict[str, list[str]],
    ) -> None:
        """Async version of add_tags()."""
        request = TagsRequest(entities=entities)
        await self._apost(
            f"/v2/assets/{asset_type}/add_tags",
            data=request.model_dump(by_alias=True),
        )

    def remove_tags(
        self,
        asset_type: AssetType,
        entities: dict[str, list[str]],
    ) -> None:
        """Remove tags from assets.

        Args:
            asset_type: Type of assets
            entities: Mapping of internal_axon_id to list of tags to remove
        """
        request = TagsRequest(entities=entities)
        self._post(
            f"/v2/assets/{asset_type}/remove_tags",
            data=request.model_dump(by_alias=True),
        )

    async def aremove_tags(
        self,
        asset_type: AssetType,
        entities: dict[str, list[str]],
    ) -> None:
        """Async version of remove_tags()."""
        request = TagsRequest(entities=entities)
        await self._apost(
            f"/v2/assets/{asset_type}/remove_tags",
            data=request.model_dump(by_alias=True),
        )

    def update_custom_fields(
        self,
        asset_type: AssetType,
        internal_axon_ids: list[str],
        custom_fields: dict[str, Any],
    ) -> None:
        """Update custom fields on assets.

        Args:
            asset_type: Type of assets
            internal_axon_ids: Asset IDs to update
            custom_fields: Custom field values to set
        """
        request = UpdateCustomFieldsRequest(
            internal_axon_ids=internal_axon_ids,
            custom_fields=custom_fields,
        )
        self._post(
            f"/v2/assets/{asset_type}/update_custom_fields",
            data=request.model_dump(by_alias=True),
        )

    async def aupdate_custom_fields(
        self,
        asset_type: AssetType,
        internal_axon_ids: list[str],
        custom_fields: dict[str, Any],
    ) -> None:
        """Async version of update_custom_fields()."""
        request = UpdateCustomFieldsRequest(
            internal_axon_ids=internal_axon_ids,
            custom_fields=custom_fields,
        )
        await self._apost(
            f"/v2/assets/{asset_type}/update_custom_fields",
            data=request.model_dump(by_alias=True),
        )

    def iter_all(
        self,
        asset_type: AssetType,
        *,
        query: str | None = None,
        saved_query_id: str | None = None,
        fields: list[str] | None = None,
        page_size: int = 500,
    ) -> Iterator[Asset]:
        """Iterate through all assets matching criteria.

        Args:
            asset_type: Type of assets
            query: AQL query string
            saved_query_id: ID of a saved query
            fields: Fields to include
            page_size: Number of results per page

        Yields:
            Asset objects
        """
        if not (1 <= page_size <= 2000):
            raise ValueError("page_size must be between 1 and 2000, got %d" % page_size)
        next_page: str | None = None

        while True:
            request = AssetRequest(
                query=query,
                saved_query_id=saved_query_id,
                fields=fields,
                page=PageParams(size=page_size) if next_page is None else None,
                next_page=next_page,
            )

            data = self._post(
                f"/v2/assets/{asset_type}",
                data=request.model_dump(exclude_none=True, by_alias=True),
            )
            response = AssetResponse.model_validate(data)

            yield from response.assets

            if not response.has_next_page:
                break
            next_page = response.next_page_token

    async def aiter_all(
        self,
        asset_type: AssetType,
        *,
        query: str | None = None,
        saved_query_id: str | None = None,
        fields: list[str] | None = None,
        page_size: int = 500,
    ) -> AsyncIterator[Asset]:
        """Async version of iter_all()."""
        if not (1 <= page_size <= 2000):
            raise ValueError("page_size must be between 1 and 2000, got %d" % page_size)
        next_page: str | None = None

        while True:
            request = AssetRequest(
                query=query,
                saved_query_id=saved_query_id,
                fields=fields,
                page=PageParams(size=page_size) if next_page is None else None,
                next_page=next_page,
            )

            data = await self._apost(
                f"/v2/assets/{asset_type}",
                data=request.model_dump(exclude_none=True, by_alias=True),
            )
            response = AssetResponse.model_validate(data)

            for asset in response.assets:
                yield asset

            if not response.has_next_page:
                break
            next_page = response.next_page_token
