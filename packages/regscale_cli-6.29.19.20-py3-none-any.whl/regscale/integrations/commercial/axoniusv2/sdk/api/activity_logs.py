"""Activity logs API implementation."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from .base import BaseAPI
from ..models.activity_logs import ActivityLogsResponse
from ..types import AuditCategory


class ActivityLogsAPI(BaseAPI):
    """API for accessing activity logs."""

    def list(
        self,
        *,
        search: str | None = None,
        users: list[str] | None = None,
        categories: list[AuditCategory | str] | None = None,
        start_date: datetime | None = None,
        end_date: datetime | None = None,
        page_number: int | None = None,
        page_size: int | None = None,
    ) -> ActivityLogsResponse:
        """List activity logs.

        Args:
            search: Text to search in log parameters
            users: Filter by user IDs
            categories: Filter by categories
            start_date: Filter logs after this date
            end_date: Filter logs before this date
            page_number: Page number
            page_size: Page size

        Returns:
            ActivityLogsResponse containing logs
        """
        params: dict[str, Any] = {}

        if search:
            params["search"] = search
        if users:
            params["users"] = users
        if categories:
            params["categories"] = [str(c) for c in categories]
        if start_date:
            params["start_date"] = start_date.isoformat()
        if end_date:
            params["end_date"] = end_date.isoformat()
        if page_number is not None:
            params["page"] = page_number
        if page_size is not None:
            params["limit"] = page_size

        data = self._get("/v2/activity_logs", params=params if params else None)
        return ActivityLogsResponse.model_validate(data)

    async def alist(
        self,
        *,
        search: str | None = None,
        users: list[str] | None = None,
        categories: list[AuditCategory | str] | None = None,
        start_date: datetime | None = None,
        end_date: datetime | None = None,
        page_number: int | None = None,
        page_size: int | None = None,
    ) -> ActivityLogsResponse:
        """Async version of list()."""
        params: dict[str, Any] = {}

        if search:
            params["search"] = search
        if users:
            params["users"] = users
        if categories:
            params["categories"] = [str(c) for c in categories]
        if start_date:
            params["start_date"] = start_date.isoformat()
        if end_date:
            params["end_date"] = end_date.isoformat()
        if page_number is not None:
            params["page"] = page_number
        if page_size is not None:
            params["limit"] = page_size

        data = await self._aget("/v2/activity_logs", params=params if params else None)
        return ActivityLogsResponse.model_validate(data)
