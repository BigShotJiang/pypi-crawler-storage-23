"""Asset mapper for converting Axonius devices to RegScale IntegrationAsset."""

import logging
from typing import Optional

from regscale.integrations.scanner.models.integration_asset import IntegrationAsset
from regscale.models.regscale_models.asset import AssetOperatingSystem
from regscale.models.regscale_models.component import ComponentType

from regscale.integrations.commercial.axoniusv2.constants import (
    AXONIUS_FIELD_HOSTNAME,
    AXONIUS_FIELD_HOSTNAME_PREFERRED,
    AXONIUS_FIELD_NETWORK_INTERFACES_IPS,
    AXONIUS_FIELD_NETWORK_INTERFACES_IPS_V6,
    AXONIUS_FIELD_NETWORK_INTERFACES_MAC,
    AXONIUS_FIELD_OS_TYPE,
    AXONIUS_FIELD_OS_STR,
    AXONIUS_FIELD_SERIAL_NUMBER,
    AXONIUS_FIELD_AWS_DEVICE_TYPE,
    AXONIUS_FIELD_AZURE_DEVICE_ID,
    AXONIUS_FIELD_GCP_PROJECT_ID,
    SCANNING_TOOL_NAME,
)

logger = logging.getLogger("regscale")


def map_device_to_integration_asset(device, plan_id: int) -> IntegrationAsset:
    """Map an Axonius device Asset to an IntegrationAsset.

    :param device: An Axonius SDK Asset object.
    :param int plan_id: The security plan ID.
    :return: A populated IntegrationAsset.
    :rtype: IntegrationAsset
    """
    hostname = device.get_field(AXONIUS_FIELD_HOSTNAME, default="") or ""
    os_type = device.get_field(AXONIUS_FIELD_OS_TYPE, default="") or ""
    aws_id = device.get_field(AXONIUS_FIELD_AWS_DEVICE_TYPE, default="") or ""
    azure_id = device.get_field(AXONIUS_FIELD_AZURE_DEVICE_ID, default="") or ""
    gcp_id = device.get_field(AXONIUS_FIELD_GCP_PROJECT_ID, default="") or ""
    adapters = getattr(device, "adapters", []) or []

    return IntegrationAsset(
        name=hostname or device.internal_axon_id,
        identifier=device.internal_axon_id,
        other_tracking_number=device.internal_axon_id,
        asset_type=_derive_asset_type(os_type),
        asset_category="IT Asset",
        component_type=_derive_component_type(aws_id, azure_id, gcp_id),
        fqdn=device.get_field(AXONIUS_FIELD_HOSTNAME_PREFERRED, default="") or None,
        ip_address=_extract_first_ip(device.get_field(AXONIUS_FIELD_NETWORK_INTERFACES_IPS, default=[])),
        ipv6_address=_extract_first_ip(device.get_field(AXONIUS_FIELD_NETWORK_INTERFACES_IPS_V6, default=[])),
        mac_address=_extract_first_value(device.get_field(AXONIUS_FIELD_NETWORK_INTERFACES_MAC, default=[])),
        operating_system=_map_operating_system(os_type),
        os_version=device.get_field(AXONIUS_FIELD_OS_STR, default="") or None,
        serial_number=device.get_field(AXONIUS_FIELD_SERIAL_NUMBER, default="") or None,
        aws_identifier=aws_id or None,
        azure_identifier=azure_id or None,
        google_identifier=gcp_id or None,
        scanning_tool=", ".join(adapters) if adapters else SCANNING_TOOL_NAME,
        parent_id=plan_id,
        parent_module="securityplans",
    )


def _derive_asset_type(os_type: str) -> str:
    """Derive asset type from OS type string.

    :param str os_type: The OS type string from Axonius.
    :return: Asset type string.
    :rtype: str
    """
    if not os_type:
        return "Other"
    os_lower = os_type.lower()
    if "server" in os_lower:
        return "Server"
    if "desktop" in os_lower or "workstation" in os_lower:
        return "Workstation"
    return "Other"


def _derive_component_type(aws_id: str, azure_id: str, gcp_id: str) -> str:
    """Derive component type based on cloud identifiers.

    :param str aws_id: AWS device type identifier.
    :param str azure_id: Azure device identifier.
    :param str gcp_id: GCP project identifier.
    :return: Component type string.
    :rtype: str
    """
    if aws_id or azure_id or gcp_id:
        return "Virtual"
    return ComponentType.Hardware


def _extract_first_ip(ips) -> Optional[str]:
    """Extract the first IP from a list of IPs.

    :param ips: A list (possibly nested) of IP addresses.
    :return: The first IP as a string, or None.
    :rtype: Optional[str]
    """
    if isinstance(ips, list) and ips:
        first = ips[0]
        if isinstance(first, list) and first:
            return str(first[0])
        return str(first) if first else None
    return None


def _extract_first_value(values) -> Optional[str]:
    """Extract the first value from a list.

    :param values: A list (possibly nested) of values.
    :return: The first value as a string, or None.
    :rtype: Optional[str]
    """
    if isinstance(values, list) and values:
        first = values[0]
        if isinstance(first, list) and first:
            return str(first[0])
        return str(first) if first else None
    return None


# OS type string -> AssetOperatingSystem mapping
_OS_MAP = {
    "windows server": AssetOperatingSystem.WindowsServer,
    "windows desktop": AssetOperatingSystem.WindowsDesktop,
    "windows": AssetOperatingSystem.WindowsDesktop,
    "linux": AssetOperatingSystem.Linux,
    "mac": AssetOperatingSystem.MacOSX,
    "macos": AssetOperatingSystem.MacOSX,
    "unix": AssetOperatingSystem.Unix,
    "ios": AssetOperatingSystem.iOS,
    "android": AssetOperatingSystem.Android,
}


def _map_operating_system(os_type: str) -> Optional[AssetOperatingSystem]:
    """Map OS type string to AssetOperatingSystem enum.

    :param str os_type: The OS type string from Axonius.
    :return: Corresponding AssetOperatingSystem enum value, or None.
    :rtype: Optional[AssetOperatingSystem]
    """
    if not os_type:
        return None
    os_lower = os_type.lower()
    for key, value in _OS_MAP.items():
        if key in os_lower:
            return value
    return AssetOperatingSystem.Other
