"""Axonius V2 configuration reader.

Reads from the nested ``axonius`` key in init.yaml / Application config.
"""

import logging
from typing import Any

logger = logging.getLogger("regscale")

# Defaults matching config_defaults.py
_DEFAULTS = {
    "host": "YOUR_AXONIUS_HOST",
    "apiKey": "YOUR_AXONIUS_V2_API_KEY",
    "apiSecret": "YOUR_AXONIUS_V2_API_SECRET",
    "verifySsl": True,
    "timeout": 120,
    "pageSize": 2000,
    "savedQueryConfig": {
        "queryName": "RegScale Default Query",
        "queryDescription": "Default query used by RegScale for asset retrieval. Modify or replace as needed.",
    },
    "stateDir": "./artifacts/axonius",
}


def get_axonius_config() -> dict[str, Any]:
    """Return the ``axonius`` configuration dict from init.yaml.

    Falls back to compiled defaults for any missing keys.
    If ``host`` is not set but ``url`` is (V1 legacy key), ``url`` is used as fallback.

    :return: Merged axonius configuration dictionary.
    :rtype: dict[str, Any]
    """
    from regscale.core.app.application import Application

    app = Application()
    cfg = app.config.get("axonius", {})
    if not isinstance(cfg, dict):
        cfg = {}
    merged = {**_DEFAULTS, **cfg}
    # Fall back to V1 'url' key if 'host' is not configured
    if merged.get("host") == _DEFAULTS["host"] and cfg.get("url"):
        merged["host"] = cfg["url"]
    if not cfg.get("awsSecretName") and (cfg.get("apiKey") or cfg.get("apiSecret")):
        logger.warning(
            "Axonius credentials loaded from plaintext config. "
            "Consider using awsSecretName for secure credential management."
        )
    return merged
