"""
Qualys Sync Scanner Integration - Uses ScannerIntegration framework for sync_qualys command.

DEPRECATED: This module is deprecated and will be removed in v3.0.0 (target: Q2 2026).
Please migrate to QualysIntegration from qualys_integration.py instead.

MIGRATION GUIDE:
================

The new QualysIntegration class provides the same functionality with better architecture:
- Cleaner separation of concerns (fetch vs sync)
- Improved CVE extraction with priority-based logic
- Better asset cache management
- Automatic SSP-scoped identifiers
- Early deduplication support

Old Approach (DEPRECATED):
--------------------------
from regscale.integrations.commercial.qualys.qualys_sync_integration import QualysSyncIntegration

integration = QualysSyncIntegration(
    plan_id=123,
    qualys_assets_and_issues=qualys_data,
    is_component=False
)
integration.run()

New Approach (RECOMMENDED):
---------------------------
from regscale.integrations.commercial.qualys.qualys_integration import QualysIntegration

integration = QualysIntegration(plan_id=123, is_component=False)

# Option 1: Use high-level sync methods
integration.sync_assets(qualys_data)
integration.sync_findings(qualys_data, dedupe_early=True)

# Option 2: Use fetch methods with automatic API calls
assets = list(integration.fetch_assets())
findings = list(integration.fetch_findings())

Key Differences:
---------------
1. No longer need to pass qualys_assets_and_issues to constructor
2. sync_assets() and sync_findings() are now separate methods
3. Supports early deduplication (reduces findings before processing)
4. Automatic KB enrichment for vulnerability details
5. Better logging and diagnostics

This module provides legacy support for existing scripts using QualysSyncIntegration.
New development should use QualysIntegration for better maintainability.
"""

import logging
import warnings
from datetime import datetime, timedelta
from typing import Any, Dict, Iterator, List, Optional, Set

from regscale.core.app.application import Application
from regscale.core.app.utils.app_utils import get_current_datetime
from regscale.integrations.commercial.qualys.total_cloud_helpers import _is_valid_cve
from regscale.integrations.scanner_integration import (
    IntegrationAsset,
    IntegrationFinding,
    ScannerIntegration,
    ScannerIntegrationType,
)
from regscale.integrations.variables import ScannerVariables
from regscale.models import Issue, IssueSeverity, IssueStatus

logger = logging.getLogger("regscale")

# Qualys severity mapping (1-5 scale to RegScale)
QUALYS_SEVERITY_MAP = {
    "1": IssueSeverity.Low,
    "2": IssueSeverity.Low,
    "3": IssueSeverity.Moderate,
    "4": IssueSeverity.High,
    "5": IssueSeverity.Critical,
    1: IssueSeverity.Low,
    2: IssueSeverity.Low,
    3: IssueSeverity.Moderate,
    4: IssueSeverity.High,
    5: IssueSeverity.Critical,
}

# Default due date deltas by severity (days)
DEFAULT_DUE_DATE_DELTAS = {
    "critical": 30,
    "high": 30,
    "moderate": 90,
    "low": 365,
}


class QualysSyncIntegration(ScannerIntegration):
    """
    Scanner integration for syncing Qualys vulnerabilities to RegScale.

    DEPRECATED: This class will be removed in v3.0.0 (target: Q2 2026).
    Use QualysIntegration from qualys_integration.py instead.

    See module docstring above for detailed migration guide.

    Legacy Features (for backward compatibility):
    - IntegrationFinding creation with correct field handling
    - Batch issue creation with server-side deduplication
    - Asset identifier handling (assetIdentifier set properly)
    - Due date calculation based on severity

    Migration Benefits:
    - Better CVE extraction (priority-based: CVE_LIST > CVE_ID > CVE field)
    - Automatic SSP-scoped identifiers (prevents cross-plan conflicts)
    - Early deduplication support (reduces processing overhead)
    - Cleaner API with separate fetch/sync methods
    - Better diagnostic logging and error handling
    """

    title: str = "Qualys Integration"

    asset_identifier_field: str = "otherTrackingNumber"
    issue_identifier_field: str = "qualysId"

    finding_severity_map: Dict[str, Any] = {
        "1": IssueSeverity.Low,
        "2": IssueSeverity.Low,
        "3": IssueSeverity.Moderate,
        "4": IssueSeverity.High,
        "5": IssueSeverity.Critical,
    }

    finding_status_map = {
        "New": IssueStatus.Open,
        "Active": IssueStatus.Open,
        "Fixed": IssueStatus.Closed,
        "Re-Opened": IssueStatus.Open,
    }

    def __init__(
        self,
        plan_id: int,
        qualys_assets_and_issues: List[Dict],
        is_component: bool = False,
        config: Optional[Dict] = None,
        **kwargs,
    ):
        """
        Initialize the Qualys Sync Integration.

        DEPRECATED: Use QualysIntegration instead.

        :param int plan_id: RegScale Security Plan or Component ID
        :param List[Dict] qualys_assets_and_issues: List of Qualys assets with their issues
        :param bool is_component: Whether syncing to a component (True) or security plan (False)
        :param Optional[Dict] config: Configuration dictionary
        """
        warnings.warn(
            "QualysSyncIntegration is deprecated. Use QualysIntegration from qualys_integration.py instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        self.qualys_assets_and_issues = qualys_assets_and_issues
        self.is_component = is_component
        self._config = config or self._load_config()

        # Set parent module based on component flag
        parent_module = "components" if is_component else "securityplans"

        # Set vulnerability creation mode
        kwargs["vulnerability_creation"] = kwargs.get(
            "vulnerability_creation", ScannerVariables.vulnerabilityCreation or "IssueCreation"
        )

        self.type = ScannerIntegrationType.VULNERABILITY

        super().__init__(
            plan_id=plan_id,
            parent_module=parent_module,
            **kwargs,
        )

        # Count total vulnerabilities for progress tracking
        self.num_findings_to_process = sum(len(asset.get("ISSUES", {})) for asset in qualys_assets_and_issues)
        logger.info(
            "QualysSyncIntegration initialized: %d assets, %d vulnerabilities to process",
            len(qualys_assets_and_issues),
            self.num_findings_to_process,
        )

    def _load_config(self) -> Dict:
        """Load configuration from Application."""
        try:
            app = Application()
            return app.config
        except Exception as e:
            logger.warning("Failed to load config: %s", e)
            return {}

    def fetch_assets(self) -> Iterator[IntegrationAsset]:
        """
        Fetch assets - required abstract method implementation.

        For QualysSyncIntegration, assets are pre-loaded in qualys_assets_and_issues,
        so this method returns an iterator over the converted assets.

        :return: Iterator of IntegrationAsset objects
        :rtype: Iterator[IntegrationAsset]
        """
        return self.parse_assets()

    def fetch_findings(self) -> Iterator[IntegrationFinding]:
        """
        Fetch findings - required abstract method implementation.

        For QualysSyncIntegration, findings are pre-loaded in qualys_assets_and_issues,
        so this method returns an iterator over the converted findings.

        :return: Iterator of IntegrationFinding objects
        :rtype: Iterator[IntegrationFinding]
        """
        return self.parse_findings()

    def parse_assets(
        self, _file_path: Optional[str] = None, _data: Optional[Dict] = None
    ) -> Iterator[IntegrationAsset]:
        """
        Parse assets from Qualys data.

        This implementation yields IntegrationAsset objects from the pre-loaded
        qualys_assets_and_issues data.

        :param Optional[str] _file_path: Not used - data is pre-loaded (framework interface)
        :param Optional[Dict] _data: Not used - data is pre-loaded (framework interface)
        :return: Iterator of IntegrationAsset objects
        :rtype: Iterator[IntegrationAsset]
        """
        for asset in self.qualys_assets_and_issues:
            yield self._convert_qualys_asset_to_integration_asset(asset)

    def _convert_qualys_asset_to_integration_asset(self, qualys_asset: Dict) -> IntegrationAsset:
        """
        Convert a Qualys asset dict to an IntegrationAsset.

        :param Dict qualys_asset: Qualys asset dictionary
        :return: IntegrationAsset object
        :rtype: IntegrationAsset
        """
        asset_id = qualys_asset.get("ASSET_ID", "")
        tracking_method = qualys_asset.get("TRACKING_METHOD", "VMDR")

        # Append SSP ID to identifier for SSP-scoped deduplication
        identifier_with_ssp = f"{asset_id}::SSP-{self.plan_id}" if self.plan_id and asset_id else str(asset_id)

        return IntegrationAsset(
            name=f"Qualys {tracking_method} #{asset_id} IP: {qualys_asset.get('IP', 'Unknown')}",
            identifier=identifier_with_ssp,
            other_tracking_number=identifier_with_ssp,
            ipAddress=qualys_asset.get("IP", ""),
            hostName=qualys_asset.get("DNS", ""),
            os=qualys_asset.get("OS", ""),
            external_id=str(asset_id),
            source=f"Qualys {tracking_method}",
        )

    def parse_findings(
        self, _file_path: Optional[str] = None, _data: Optional[Dict] = None
    ) -> Iterator[IntegrationFinding]:
        """
        Parse findings from Qualys vulnerability data.

        Converts Qualys vulnerability dictionaries to IntegrationFinding objects
        that the ScannerIntegration framework can process correctly.

        :param Optional[str] _file_path: Not used - data is pre-loaded (framework interface)
        :param Optional[Dict] _data: Not used - data is pre-loaded (framework interface)
        :return: Iterator of IntegrationFinding objects
        :rtype: Iterator[IntegrationFinding]
        """
        for asset in self.qualys_assets_and_issues:
            issues = asset.get("ISSUES", {})
            if not issues:
                continue

            asset_id = asset.get("ASSET_ID", "")
            # Build asset identifier string
            asset_identifier = self._build_asset_identifier(asset_id)

            for vuln_id, vuln in issues.items():
                finding = self._convert_qualys_vuln_to_finding(vuln=vuln, asset_identifier=asset_identifier)
                if finding:
                    yield finding

    def _build_asset_identifier(self, asset_id: str) -> str:
        """
        Build asset identifier string from Qualys asset data.

        Returns the otherTrackingNumber with SSP ID appended to match how assets are created.
        This ensures issues link to assets correctly via the assetIdentifier field.

        :param str asset_id: Qualys asset ID
        :return: Asset identifier with SSP ID appended (matches otherTrackingNumber)
        :rtype: str
        """
        # Return the asset ID with SSP appended - this matches the asset's otherTrackingNumber
        # This ensures issue.assetIdentifier matches asset.otherTrackingNumber for proper linking
        if asset_id and self.plan_id:
            return f"{asset_id}::SSP-{self.plan_id}"
        elif asset_id:
            return str(asset_id)
        return "Unknown Asset"

    def _build_finding_identifier(self, vuln: Dict, qid: str) -> str:
        """Build finding identifier with SSP scope for deduplication."""
        base_finding_id = vuln.get("PLUGIN_ID") or vuln.get("QUALYS_ID") or f"QID_{qid}"
        if self.plan_id:
            return f"{base_finding_id}::SSP-{self.plan_id}"
        return base_finding_id

    def _extract_timestamps(self, vuln: Dict) -> tuple:
        """Extract first_found and last_found timestamps from vulnerability data."""
        first_found = vuln.get("FIRST_FOUND_DATETIME", get_current_datetime())
        last_found = vuln.get("LAST_FOUND_DATETIME", get_current_datetime())
        return first_found, last_found

    def _extract_and_validate_cve(self, issue_data: Dict) -> Optional[str]:
        """Extract and validate CVE from issue data."""
        cve_candidate = issue_data.get("CVE", "")
        if _is_valid_cve(cve_candidate):
            return cve_candidate
        return None

    def _convert_qualys_vuln_to_finding(
        self,
        vuln: Dict,
        asset_identifier: str,
    ) -> Optional[IntegrationFinding]:
        """
        Convert a Qualys vulnerability dict to an IntegrationFinding.

        This is the key method that transforms Qualys-specific vulnerability data
        into the standard IntegrationFinding format that the ScannerIntegration
        framework can process correctly.

        :param Dict vuln: Qualys vulnerability dictionary
        :param str asset_identifier: Asset identifier string
        :return: IntegrationFinding object or None if conversion fails
        :rtype: Optional[IntegrationFinding]
        """
        try:
            # Extract basic vulnerability data
            qid = vuln.get("QID", vuln.get("QUALYS_ID", "Unknown"))
            severity_raw = vuln.get("SEVERITY", 3)
            issue_data = vuln.get("ISSUE_DATA", {})

            # Map severity and calculate due date
            severity = self._map_severity(severity_raw)
            due_date = self._calculate_due_date(severity)

            # Get title and description
            title = issue_data.get("TITLE", f"Vulnerability QID {qid}")
            description = self._build_description(issue_data)

            # Build finding identifier with SSP scope
            finding_id = self._build_finding_identifier(vuln, qid)

            # Get solution/remediation
            solution = issue_data.get("SOLUTION", "")

            # Extract and validate CVE
            cve = self._extract_and_validate_cve(issue_data)

            # Get timestamps
            first_found, last_found = self._extract_timestamps(vuln)

            # Create IntegrationFinding with all necessary fields
            # Note: plugInName in Vulnerability model will be cve OR plugin_name (cve takes precedence)
            # Note: plugInId in Vulnerability model will be plugin_id OR external_id (plugin_id takes precedence)
            finding = IntegrationFinding(
                # Core identification
                title=title,
                description=description,
                external_id=finding_id,  # Used for integrationFindingId (fallback for plugInId if plugin_id is empty)
                # Severity and status
                severity=severity,
                status=IssueStatus.Open,
                # Asset linking - this is the key field!
                # Both fields must match the asset's otherTrackingNumber (with SSP appended)
                asset_identifier=asset_identifier,  # For asset lookup (includes ::SSP-{id})
                issue_asset_identifier_value=asset_identifier,  # Stored in issue.assetIdentifier
                # Plugin/scanner info - CRITICAL for vulnerability creation and deduplication
                plugin_name=f"QID-{qid}",  # Used for plugInName if no CVE (vulnerability deduplication key)
                plugin_id=qid,  # Set to QID for unique identification per vulnerability type (NOT integration name)
                # Category and identification
                category="Vulnerability",
                identification="Vulnerability Assessment",
                # Remediation
                remediation=solution,
                recommendation_for_mitigation=solution,
                # CVE if available (takes precedence for plugInName in vulnerability model)
                cve=cve,
                # Timestamps
                first_seen=first_found,
                last_seen=last_found,
                date_created=first_found,
                scan_date=get_current_datetime(),
                # Due date
                due_date=due_date,
                # Control labels for mapping
                control_labels=[f"QID-{qid}"],
            )

            # DEBUG: Log finding details to diagnose vulnerability creation issues
            logger.info(
                "QUALYS_VULN_DEBUG: Created finding - external_id=%s, plugin_name=%s, plugin_id=%s, "
                "cve=%s, asset_identifier=%s, title=%s",
                finding.external_id,
                finding.plugin_name,
                finding.plugin_id,
                finding.cve,
                finding.asset_identifier,
                finding.title[:50] if finding.title else "N/A",
            )

            return finding

        except Exception as e:
            logger.warning("Failed to convert Qualys vulnerability to finding: %s", e)
            logger.debug("Vulnerability data: %s", vuln)
            return None

    def _map_severity(self, severity_raw: Any) -> IssueSeverity:
        """
        Map Qualys severity to RegScale IssueSeverity.

        :param Any severity_raw: Qualys severity (1-5 scale)
        :return: RegScale IssueSeverity
        :rtype: IssueSeverity
        """
        return QUALYS_SEVERITY_MAP.get(severity_raw, IssueSeverity.Moderate)

    def _build_description(self, issue_data: Dict) -> str:
        """
        Build issue description from vulnerability data.

        :param Dict issue_data: Issue data dictionary
        :return: Formatted description
        :rtype: str
        """
        consequence = issue_data.get("CONSEQUENCE", "")
        diagnosis = issue_data.get("DIAGNOSIS", "")
        parts = [p for p in [consequence, diagnosis] if p]
        return "</br>".join(parts) if parts else "No description available"

    def _calculate_due_date(self, severity: IssueSeverity) -> str:
        """
        Calculate due date based on severity level.

        Uses configuration if available, otherwise falls back to defaults.

        :param IssueSeverity severity: Issue severity
        :return: Due date string in YYYY-MM-DD format
        :rtype: str
        """
        # Map severity to config key
        severity_key_map = {
            IssueSeverity.Critical: "critical",
            IssueSeverity.High: "high",
            IssueSeverity.Moderate: "moderate",
            IssueSeverity.Low: "low",
            IssueSeverity.NotAssigned: "low",
        }

        key = severity_key_map.get(severity, "moderate")

        # Get delta from config or defaults
        try:
            delta = self._config.get("issues", {}).get("qualys", {}).get(key, DEFAULT_DUE_DATE_DELTAS[key])
        except Exception:
            delta = DEFAULT_DUE_DATE_DELTAS.get(key, 90)

        due_date = datetime.now() + timedelta(days=delta)
        return due_date.strftime("%Y-%m-%d")

    def _prepare_issues_from_findings(self) -> tuple[List[Any], List[IntegrationFinding]]:
        """
        Parse findings and convert to Issue objects with deduplication.

        :return: Tuple of (deduped_issues, findings)
        :rtype: tuple[List[Any], List[IntegrationFinding]]
        """
        findings = list(self.parse_findings())
        logger.info("Parsed %d findings from Qualys data", len(findings))

        if not findings:
            logger.warning("No findings to process")
            return [], []

        # Convert findings to Issue objects
        issues = []
        for finding in findings:
            issue = self._create_issue_from_finding(finding)
            if issue:
                issues.append(issue)

        logger.info("Created %d Issue objects from %d findings", len(issues), len(findings))

        if not issues:
            logger.warning("No issues created from findings")
            return [], findings

        # Deduplicate issues by integrationFindingId
        deduped_issues = self._deduplicate_issues(issues)
        logger.info("Deduplicated to %d unique issues", len(deduped_issues))

        # Log sample issue data for debugging
        self._log_sample_issue(deduped_issues)

        return deduped_issues, findings

    def _log_sample_issue(self, deduped_issues: List[Any]) -> None:
        """Log sample issue data for debugging batch failures."""
        if deduped_issues:
            sample = deduped_issues[0]
            logger.info(
                "QUALYS_BATCH_DEBUG: Sample issue - title='%s', status=%s (type=%s), "
                "severityLevel=%s (type=%s), parentId=%s, parentModule=%s, integrationFindingId=%s",
                sample.title[:50] if sample.title else "N/A",
                sample.status,
                type(sample.status).__name__,
                sample.severityLevel,
                type(sample.severityLevel).__name__,
                sample.parentId,
                sample.parentModule,
                sample.integrationFindingId,
            )

    def _initialize_vulnerability_tracking(self) -> tuple[Any, Dict[int, Set[int]]]:
        """
        Initialize scan history and vulnerability tracking structures.

        :return: Tuple of (scan_history, current_vulnerabilities)
        :rtype: tuple[Any, Dict[int, Set[int]]]
        """
        from regscale.models import Asset

        scan_history = self.create_scan_history()
        current_vulnerabilities: Dict[int, Set[int]] = {}

        # Refresh asset cache
        logger.info("Refreshing asset cache after asset creation...")
        self._asset_cache.clear()
        self._asset_cache.warm_cache()
        logger.info("Asset cache refreshed with %d assets", len(self._asset_cache))

        # Pre-populate current_vulnerabilities dict
        assets = Asset.get_all_by_parent(parent_id=self.plan_id, parent_module=self.parent_module)
        for asset in assets:
            if asset.id:
                current_vulnerabilities[asset.id] = set()
        logger.info("Pre-populated current_vulnerabilities with %d asset IDs", len(current_vulnerabilities))

        self._verify_asset_cache(assets)

        return scan_history, current_vulnerabilities

    def _verify_asset_cache(self, assets: List[Any]) -> None:
        """Verify asset cache has correct data and can perform lookups."""
        if assets:
            sample = assets[0]
            logger.info(
                "QUALYS_ASSET_VERIFY: Sample asset - ID=%s, otherTrackingNumber=%s, qualysId=%s",
                sample.id,
                sample.otherTrackingNumber,
                sample.qualysId,
            )
            if sample.otherTrackingNumber:
                found = self._asset_cache.get_by_identifier(sample.otherTrackingNumber)
                logger.info(
                    "QUALYS_ASSET_VERIFY: Cache lookup test for '%s': %s",
                    sample.otherTrackingNumber,
                    "SUCCESS" if found else "FAILED",
                )

        # Additional diagnostic logging
        self._log_asset_diagnostics(assets)

    def _log_asset_diagnostics(self, assets: List[Any]) -> None:
        """Log detailed asset diagnostics for debugging."""
        if assets:
            sample_assets = list(assets)[:5]
            logger.debug("Sample assets loaded:")
            for asset in sample_assets:
                logger.debug(
                    "  Asset ID=%s, otherTrackingNumber=%s, qualysId=%s, ipAddress=%s",
                    asset.id,
                    asset.otherTrackingNumber,
                    asset.qualysId,
                    asset.ipAddress,
                )

        logger.debug("Asset cache details:")
        logger.debug("  Cache size: %d", len(self._asset_cache))
        logger.debug("  Cache is_loaded: %s", self._asset_cache.is_loaded)
        logger.debug("  identifier_field: %s", self.asset_identifier_field)

        cache_keys = list(self._asset_cache.keys())[:10]
        logger.debug("  Sample cache keys (first 10): %s", cache_keys)

    def _submit_issues_and_vulnerabilities(self, current_vulnerabilities: Dict[int, Set[int]]) -> None:
        """Submit pending issues and vulnerabilities in batches."""
        logger.info("Submitting pending issues and vulnerabilities...")
        self._batch_submit_pending_issues()

        logger.debug(
            "About to call _batch_submit_pending_vulnerabilities with %d assets tracked",
            len(current_vulnerabilities),
        )
        logger.debug("Pending vulnerabilities count: %d", len(self._pending_vulnerabilities))

        try:
            created_vulns = self._batch_submit_pending_vulnerabilities(current_vulnerabilities)
            logger.debug(
                "Vulnerability submission complete - created %d vulnerabilities",
                len(created_vulns) if created_vulns else 0,
            )
        except Exception as e:
            logger.error("Vulnerability submission failed with error: %s", e, exc_info=True)

    def _handle_stale_vulnerabilities(self, current_vulnerabilities: Dict[int, Set[int]]) -> None:
        """Close stale vulnerabilities if mop-up is enabled."""
        from regscale.integrations.variables import ScannerVariables

        if ScannerVariables.closeFindingsNotInScan:
            logger.info("Performing mop-up of stale vulnerabilities...")
            self.close_outdated_vulnerabilities(current_vulnerabilities)

    def run(self) -> int:
        """
        Run the integration - process findings and create issues.

        Creates Issue objects from IntegrationFinding data and uses batch_create_or_update
        for server-side deduplication.

        :return: Number of findings processed
        :rtype: int
        """
        logger.info("Starting QualysSyncIntegration run...")

        # Parse and prepare issues
        _, findings = self._prepare_issues_from_findings()
        if not findings:
            return 0

        logger.info("Using parent ScannerIntegration workflow for issue and vulnerability creation...")
        logger.info("Assets already synced by caller - proceeding with findings processing")

        # Initialize vulnerability tracking
        scan_history, current_vulnerabilities = self._initialize_vulnerability_tracking()

        # Process findings
        logger.info("Processing %d findings...", len(findings))
        for finding in findings:
            self.process_finding(finding, scan_history, current_vulnerabilities)

        # Submit batches
        self._submit_issues_and_vulnerabilities(current_vulnerabilities)

        # Handle mop-up
        self._handle_stale_vulnerabilities(current_vulnerabilities)

        logger.info("QualysSyncIntegration run complete: processed %d findings", len(findings))
        return len(findings)

    def _create_issue_from_finding(self, finding: IntegrationFinding) -> Optional[Issue]:
        """
        Create an Issue object from an IntegrationFinding.

        Creates an empty Issue first then sets properties - this matches
        the ScannerIntegration framework pattern exactly.

        :param IntegrationFinding finding: The finding to convert
        :return: Issue object or None if conversion fails
        :rtype: Optional[Issue]
        """
        try:
            # Create empty Issue first (framework pattern)
            issue = Issue()

            # Set basic required fields (matching scanner_integration._set_basic_issue_fields)
            issue.parentId = self.plan_id
            issue.parentModule = self.parent_module
            issue.title = finding.title
            issue.status = finding.status if finding.status else IssueStatus.Open
            issue.severityLevel = finding.severity if finding.severity else IssueSeverity.Moderate
            issue.issueOwnerId = str(self.assessor_id) if self.assessor_id else None
            issue.securityPlanId = self.plan_id if self.parent_module == "securityplans" else None
            issue.identification = finding.identification or "Vulnerability Assessment"
            issue.dateCreated = finding.date_created or get_current_datetime()
            issue.dateFirstDetected = finding.first_seen
            issue.deviationRationale = "N/A"  # Default value for servers that require this field

            # Set additional fields (matching scanner_integration._set_additional_issue_fields)
            issue.description = finding.description or "No description available"
            issue.integrationFindingId = finding.external_id
            issue.remediationDescription = finding.remediation
            issue.cve = finding.cve

            # NOTE: The following fields may be DISABLED on some RegScale servers (especially on-prem):
            # - sourceReport, pluginId, securityChecks, recommendedActions
            # Setting them causes "Field 'X' must be enabled to enter a value" errors.
            # We intentionally DO NOT set these fields to ensure compatibility across all servers.
            # The integrationFindingId field provides deduplication without needing pluginId.

            # Set due date
            issue.dueDate = finding.due_date

            # Set assetIdentifier AFTER creating the Issue object
            # This is critical - setting it in constructor causes batch validation failures
            issue.assetIdentifier = finding.issue_asset_identifier_value or ""

            return issue

        except Exception as e:
            logger.warning("Failed to create Issue from finding %s: %s", finding.external_id, e)
            return None

    def _smart_retry_with_field_exclusion(
        self, issues: List[Issue], batch_options: dict, max_retries: int = 2, _retry_count: int = 0
    ) -> List[Issue]:
        """
        Smart retry that detects disabled fields and retries with them excluded.

        This method:
        1. Tries to create a single test issue to get detailed error message
        2. Parses the error to identify disabled fields
        3. Retries the entire batch with those fields excluded from the payload

        :param List[Issue] issues: Issues that failed batch creation
        :param dict batch_options: Original batch options
        :param int max_retries: Maximum number of retry attempts (default: 2)
        :param int _retry_count: Internal counter for current retry attempt
        :return: List of successfully created issues
        :rtype: List[Issue]
        """
        if not issues:
            return []

        # Check recursion limit to prevent infinite retry loops
        if _retry_count >= max_retries:
            logger.error(
                "Max retries (%d) exhausted for smart retry - aborting batch creation",
                max_retries,
            )
            return []

        logger.info("Smart retry attempt %d/%d", _retry_count + 1, max_retries)

        # Try a single issue to get the detailed error message
        test_issue = issues[0]
        disabled_fields: set = set()

        try:
            # Use create_or_update which gives detailed error messages
            test_issue.create_or_update()
            # If this succeeds, try batch again (maybe it was a transient issue)
            logger.info("Test issue succeeded - retrying batch")
            return Issue.batch_create_or_update(issues, options=batch_options)
        except Exception as e:
            error_msg = str(e)
            logger.info("Test issue failed with: %s", error_msg[:500])

            # Parse disabled fields from error message
            disabled_fields = Issue.parse_disabled_fields_from_error(error_msg)

            if not disabled_fields:
                logger.warning("Could not identify disabled fields from error - no smart retry possible")
                return []

            logger.info(
                "Detected disabled fields on server: %s - will exclude from retry",
                disabled_fields,
            )

        # Build list of issues with disabled fields set to None
        # This prevents them from being included in the payload
        retry_issues: List[Issue] = []
        for issue in issues:
            # Create a copy of the issue with disabled fields cleared
            issue_dict = issue.model_dump(mode="json")

            # Remove disabled fields from the dict
            for field in disabled_fields:
                issue_dict.pop(field, None)

            # Also ensure assetIdentifier is excluded (known problematic field)
            issue_dict.pop("assetIdentifier", None)

            # Create new Issue from cleaned dict
            try:
                retry_issue = Issue(**issue_dict)
                # Restore assetIdentifier as attribute (not in payload) for deduplication
                retry_issue.assetIdentifier = issue.assetIdentifier
                retry_issues.append(retry_issue)
            except Exception as e:
                logger.warning("Failed to create retry issue: %s", e)

        if not retry_issues:
            logger.error("No issues could be prepared for retry")
            return []

        logger.info(
            "Retrying batch with %d issues, excluding fields: %s",
            len(retry_issues),
            disabled_fields,
        )

        # Retry with cleaned issues
        try:
            # Update batch options to exclude the disabled fields
            retry_options = batch_options.copy() if batch_options else {}
            retry_options["excludeFields"] = list(disabled_fields | {"assetIdentifier"})

            created = Issue.batch_create_or_update(retry_issues, options=retry_options)
            logger.info("Smart retry succeeded: %d issues created", len(created) if created else 0)
            return created if created else []
        except Exception as e:
            logger.error("Smart retry failed: %s", e)
            return []

    def _deduplicate_issues(self, issues: List[Issue]) -> List[Issue]:
        """
        Deduplicate issues by integrationFindingId, combining asset identifiers.

        :param List[Issue] issues: List of issues to deduplicate
        :return: Deduplicated list of issues
        :rtype: List[Issue]
        """
        combined: Dict[str, Issue] = {}

        for issue in issues:
            key = issue.integrationFindingId or issue.title
            if key in combined:
                # Combine asset identifiers
                existing = combined[key]
                if existing.assetIdentifier and issue.assetIdentifier:
                    if issue.assetIdentifier not in existing.assetIdentifier:
                        existing.assetIdentifier = f"{existing.assetIdentifier}\n{issue.assetIdentifier}"
                elif issue.assetIdentifier:
                    existing.assetIdentifier = issue.assetIdentifier
            else:
                combined[key] = issue

        return list(combined.values())


def sync_issues_with_framework(
    ssp_id: int,
    qualys_assets_and_issues: List[Dict],
    is_component: bool = False,
) -> int:
    """
    Sync Qualys issues to RegScale using the ScannerIntegration framework.

    This is a drop-in replacement for the old sync_issues function that
    properly uses the scanner framework pattern.

    :param int ssp_id: RegScale Security Plan or Component ID
    :param List[Dict] qualys_assets_and_issues: List of Qualys assets with their issues
    :param bool is_component: Whether syncing to a component (True) or security plan (False)
    :return: Number of issues processed
    :rtype: int
    """
    # Skip if no issues to process
    if not qualys_assets_and_issues:
        logger.warning("No assets/issues provided to sync")
        return 0

    # Filter for assets that actually have issues
    assets_with_issues = [asset for asset in qualys_assets_and_issues if asset.get("ISSUES")]

    if not assets_with_issues:
        logger.warning("No issues found in provided assets")
        return 0

    total_issues = sum(len(a.get("ISSUES", {})) for a in assets_with_issues)
    logger.info(
        "Syncing %d issues from %d assets to RegScale using ScannerIntegration framework",
        total_issues,
        len(assets_with_issues),
    )

    try:
        # Create and run the integration
        integration = QualysSyncIntegration(
            plan_id=ssp_id,
            qualys_assets_and_issues=assets_with_issues,
            is_component=is_component,
        )

        processed = integration.run()

        logger.info("Successfully synced %d issues to RegScale", processed)
        return processed

    except Exception as e:
        logger.error("Failed to sync issues with framework: %s", e, exc_info=True)
        return 0
