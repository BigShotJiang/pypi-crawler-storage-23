"""
Integration Configuration Manager

This module provides centralized configuration access for integrations,
eliminating duplicated configuration retrieval patterns across scanner implementations.

Usage Example:
    from regscale.integrations.integration_config_manager import IntegrationConfigManager

    config_mgr = IntegrationConfigManager(app.config, "wiz")
    min_severity = config_mgr.get_minimum_severity()
"""

import logging
from typing import Any, Dict

logger = logging.getLogger("regscale")


class IntegrationConfigManager:
    """
    Centralized configuration access for integrations.

    Provides consistent, reusable methods for accessing integration-specific
    configuration settings with proper error handling and logging.
    """

    def __init__(self, app_config: Dict[str, Any], integration_name: str):
        """
        Initialize configuration manager.

        Args:
            app_config: Application configuration dictionary
            integration_name: Name of the integration (e.g., "wiz", "amazon", "qualys")
        """
        self.config = app_config
        self.integration_name = integration_name.lower()
        self._config_logged = False

    def get_minimum_severity(self, default: str = "low") -> str:
        """
        Get minimum severity threshold for filtering findings.

        Checks multiple possible configuration paths:
        - issues.{integration}.minimumSeverity
        - scanners.{integration}.minimumSeverity

        Args:
            default: Default severity if not configured (default: "low")

        Returns:
            Minimum severity level as string (e.g., "low", "medium", "high")
        """
        # Try issues.{integration}.minimumSeverity path (used by AWS, etc.)
        try:
            min_severity = self.config.get("issues", {}).get(self.integration_name, {}).get("minimumSeverity")
            if min_severity:
                if not self._config_logged:
                    logger.info(f"Using minimumSeverity from config (issues.{self.integration_name}): {min_severity}")
                    self._config_logged = True
                return min_severity.lower()
        except (KeyError, AttributeError):
            pass

        # Try scanners.{integration}.minimumSeverity path (used by Wiz, etc.)
        try:
            min_severity = self.config.get("scanners", {}).get(self.integration_name, {}).get("minimumSeverity")
            if min_severity:
                if not self._config_logged:
                    logger.info(f"Using minimumSeverity from config (scanners.{self.integration_name}): {min_severity}")
                    self._config_logged = True
                return min_severity.lower()
        except (KeyError, AttributeError):
            pass

        # Return default if not found
        if not self._config_logged:
            logger.debug(f"No minimumSeverity configured for {self.integration_name}, using default: {default}")
            self._config_logged = True
        return default.lower()

    def get_posture_management_only(self, default: bool = False) -> bool:
        """
        Get posture management only setting for AWS Security Hub.

        Args:
            default: Default value if not configured (default: False)

        Returns:
            True if only posture management findings should be fetched, False otherwise
        """
        try:
            posture_only = (
                self.config.get("issues", {}).get(self.integration_name, {}).get("postureManagementOnly", default)
            )
            if posture_only:
                logger.info("Fetching posture management findings only (security standards compliance checks)")
            else:
                logger.info("Fetching all Security Hub findings (CVEs from Inspector + compliance checks)")
            return bool(posture_only)
        except (KeyError, AttributeError):
            logger.debug(f"No postureManagementOnly configured for {self.integration_name}, using default: {default}")
            return default

    def get_config_value(self, *keys: str, default: Any = None) -> Any:
        """
        Get a configuration value using a path of keys.

        Args:
            *keys: Configuration path keys (e.g., "issues", "amazon", "minimumSeverity")
            default: Default value if path not found

        Returns:
            Configuration value or default

        Example:
            >>> config_mgr.get_config_value("issues", "amazon", "minimumSeverity", default="low")
            "medium"
        """
        current = self.config
        try:
            for key in keys:
                current = current.get(key, {})
            return current if current != {} else default
        except (KeyError, AttributeError):
            return default

    def get_ssl_verify(self, default: bool = True) -> bool:
        """
        Get SSL verification setting.

        Args:
            default: Default value if not configured (default: True)

        Returns:
            True if SSL verification should be enabled, False otherwise
        """
        try:
            ssl_verify = self.config.get("scanners", {}).get(self.integration_name, {}).get("sslVerify", default)
            return bool(ssl_verify)
        except (KeyError, AttributeError):
            return default

    def has_config(self, *keys: str) -> bool:
        """
        Check if a configuration key path exists.

        Args:
            *keys: Configuration path keys to check

        Returns:
            True if the configuration path exists and has a non-None value
        """
        value = self.get_config_value(*keys, default=None)
        return value is not None
