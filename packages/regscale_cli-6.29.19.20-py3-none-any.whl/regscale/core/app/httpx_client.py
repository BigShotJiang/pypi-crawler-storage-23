#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""httpx-based HTTP client wrapper for RegScale API interactions.

This module provides a drop-in replacement for the requests-based client
with enhanced features including:
- base_url support for cleaner URL construction
- Granular timeouts (connect, read, write, pool)
- HTTP/2 support with multiplexing
- Event hooks for request/response logging
- Retry logic via tenacity decorator
"""

import logging
from typing import Any, Callable, Dict, Optional, Union

import httpx
from tenacity import (
    RetryCallState,
    retry,
    retry_if_result,
    stop_after_attempt,
    wait_exponential,
)

from regscale.core.app.http_config import HttpClientConfig, HttpTimeout, PoolConfig, RetryConfig

logger = logging.getLogger("regscale")


def _should_retry_response(response: Optional[httpx.Response]) -> bool:
    """Determine if a response should trigger a retry.

    Args:
        response: The HTTP response to evaluate

    Returns:
        bool: True if the response status indicates a retry should occur
    """
    if response is None:
        return False
    return response.status_code in [429, 500, 502, 503, 504]


def _log_retry_attempt(retry_state: RetryCallState) -> None:
    """Log retry attempts for debugging.

    Args:
        retry_state: The current retry state from tenacity
    """
    if retry_state.attempt_number > 1:
        logger.debug(
            "Retry attempt %d after %.2f seconds",
            retry_state.attempt_number,
            retry_state.seconds_since_start,
        )


class RegScaleHttpClient:
    """HTTP client wrapper using httpx with retry support.

    This client provides a requests-like interface while leveraging httpx features:
    - base_url eliminates need for normalize_url()
    - Granular timeout configuration
    - HTTP/2 support for improved performance
    - Event hooks for logging
    - Retry logic via tenacity

    Example:
        >>> config = HttpClientConfig.from_app_config(app.config)
        >>> client = RegScaleHttpClient(config)
        >>> response = client.get("/api/issues")
    """

    def __init__(
        self,
        config: Optional[HttpClientConfig] = None,
        base_url: Optional[str] = None,
        timeout: Optional[HttpTimeout] = None,
        retry_config: Optional[RetryConfig] = None,
        pool_config: Optional[PoolConfig] = None,
        http2: bool = True,
        verify_ssl: bool = True,
    ):
        """Initialize the HTTP client.

        Args:
            config: Complete HTTP client configuration (overrides other params)
            base_url: Base URL for all requests
            timeout: Timeout configuration
            retry_config: Retry strategy configuration
            pool_config: Connection pool configuration
            http2: Whether to enable HTTP/2
            verify_ssl: Whether to verify SSL certificates
        """
        if config:
            self._config = config
        else:
            self._config = HttpClientConfig(
                timeout=timeout or HttpTimeout(),
                retry=retry_config or RetryConfig(),
                pool=pool_config or PoolConfig(),
                http2=http2,
                verify_ssl=verify_ssl,
                base_url=base_url,
            )

        self._client: Optional[httpx.Client] = None
        self._ssl_warning_displayed = False

    @property
    def client(self) -> httpx.Client:
        """Get or create the underlying httpx client.

        Returns:
            httpx.Client: The configured HTTP client
        """
        if self._client is None:
            self._client = self._create_client()
        return self._client

    def _create_client(self) -> httpx.Client:
        """Create a configured httpx client.

        Returns:
            httpx.Client: New client instance
        """
        # Log SSL warning if verification is disabled
        if not self._config.verify_ssl and not self._ssl_warning_displayed:
            logger.warning("SSL Verification has been disabled.")
            self._ssl_warning_displayed = True

        # Create transport with connection pool settings
        transport = httpx.HTTPTransport(
            retries=0,  # We handle retries via tenacity
            limits=self._config.pool.to_httpx_limits(),
        )

        # Create client with all configuration
        client = httpx.Client(
            base_url=self._config.base_url or "",
            timeout=self._config.timeout.to_httpx_timeout(),
            verify=self._config.verify_ssl,
            http2=self._config.http2,
            transport=transport,
            event_hooks={
                "request": [self._log_request],
                "response": [self._log_response],
            },
        )

        logger.info(
            "httpx client initialized - base_url: %s, http2: %s, pool_size: %d",
            self._config.base_url,
            self._config.http2,
            self._config.pool.max_connections,
        )

        return client

    def _log_request(self, request: httpx.Request) -> None:
        """Event hook to log outgoing requests.

        Args:
            request: The HTTP request being sent
        """
        logger.debug("%s %s", request.method, request.url)

    def _log_response(self, response: httpx.Response) -> None:
        """Event hook to log received responses.

        Args:
            response: The HTTP response received
        """
        logger.debug(
            "%s %s - Status: %d",
            response.request.method,
            response.request.url,
            response.status_code,
        )

    def _create_retry_decorator(self) -> Callable:
        """Create a tenacity retry decorator based on configuration.

        Returns:
            Callable: Configured retry decorator
        """
        return retry(
            stop=stop_after_attempt(self._config.retry.max_attempts),
            wait=wait_exponential(
                multiplier=self._config.retry.backoff_factor,
                max=self._config.retry.backoff_max,
            ),
            retry=retry_if_result(_should_retry_response),
            before_sleep=_log_retry_attempt,
            reraise=True,
        )

    def request(
        self,
        method: str,
        url: str,
        headers: Optional[Dict[str, str]] = None,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Union[Dict, list]] = None,
        data: Optional[Dict[str, Any]] = None,
        files: Optional[Any] = None,
        timeout: Optional[float] = None,
        **kwargs,
    ) -> httpx.Response:
        """Make an HTTP request with retry support.

        Args:
            method: HTTP method (GET, POST, PUT, DELETE, etc.)
            url: URL path (will be joined with base_url)
            headers: Request headers
            params: Query parameters
            json: JSON body data
            data: Form data
            files: Files to upload
            timeout: Override timeout for this request
            **kwargs: Additional arguments passed to httpx

        Returns:
            httpx.Response: The HTTP response
        """
        # Build request kwargs
        request_kwargs = {
            "headers": headers,
            "params": params,
        }

        if json is not None:
            request_kwargs["json"] = json
        if data is not None:
            request_kwargs["data"] = data
        if files is not None:
            request_kwargs["files"] = files
        if timeout is not None:
            request_kwargs["timeout"] = timeout

        request_kwargs.update(kwargs)

        # Apply retry decorator
        @self._create_retry_decorator()
        def _request_with_retry() -> httpx.Response:
            return self.client.request(method, url, **request_kwargs)

        return _request_with_retry()

    def get(
        self,
        url: str,
        headers: Optional[Dict[str, str]] = None,
        params: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
        **kwargs,
    ) -> httpx.Response:
        """Make a GET request.

        Args:
            url: URL path
            headers: Request headers
            params: Query parameters
            timeout: Override timeout
            **kwargs: Additional arguments

        Returns:
            httpx.Response: The HTTP response
        """
        return self.request("GET", url, headers=headers, params=params, timeout=timeout, **kwargs)

    def post(
        self,
        url: str,
        headers: Optional[Dict[str, str]] = None,
        json: Optional[Union[Dict, list]] = None,
        data: Optional[Dict[str, Any]] = None,
        files: Optional[Any] = None,
        params: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
        **kwargs,
    ) -> httpx.Response:
        """Make a POST request.

        Args:
            url: URL path
            headers: Request headers
            json: JSON body data
            data: Form data
            files: Files to upload
            params: Query parameters
            timeout: Override timeout
            **kwargs: Additional arguments

        Returns:
            httpx.Response: The HTTP response
        """
        return self.request(
            "POST",
            url,
            headers=headers,
            json=json,
            data=data,
            files=files,
            params=params,
            timeout=timeout,
            **kwargs,
        )

    def put(
        self,
        url: str,
        headers: Optional[Dict[str, str]] = None,
        json: Optional[Union[Dict, list]] = None,
        params: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
        **kwargs,
    ) -> httpx.Response:
        """Make a PUT request.

        Args:
            url: URL path
            headers: Request headers
            json: JSON body data
            params: Query parameters
            timeout: Override timeout
            **kwargs: Additional arguments

        Returns:
            httpx.Response: The HTTP response
        """
        return self.request("PUT", url, headers=headers, json=json, params=params, timeout=timeout, **kwargs)

    def delete(
        self,
        url: str,
        headers: Optional[Dict[str, str]] = None,
        params: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
        **kwargs,
    ) -> httpx.Response:
        """Make a DELETE request.

        Args:
            url: URL path
            headers: Request headers
            params: Query parameters
            timeout: Override timeout
            **kwargs: Additional arguments

        Returns:
            httpx.Response: The HTTP response
        """
        return self.request("DELETE", url, headers=headers, params=params, timeout=timeout, **kwargs)

    def close(self) -> None:
        """Close the underlying HTTP client."""
        if self._client is not None:
            self._client.close()
            self._client = None

    def __enter__(self) -> "RegScaleHttpClient":
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context manager exit."""
        self.close()

    def __del__(self) -> None:
        """Clean up on deletion."""
        self.close()
