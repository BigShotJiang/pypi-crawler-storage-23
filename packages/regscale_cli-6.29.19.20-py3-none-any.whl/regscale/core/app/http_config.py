#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""HTTP configuration module for RegScale API clients.

This module provides configuration dataclasses for HTTP client settings,
including timeouts, retry strategies, and connection pool configuration.
"""

from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class HttpTimeout:
    """Configuration for HTTP request timeouts.

    Attributes:
        connect: Timeout for establishing a connection (seconds)
        read: Timeout for reading response data (seconds)
        write: Timeout for sending request data (seconds)
        pool: Timeout for acquiring a connection from the pool (seconds)
    """

    connect: float = 5.0
    read: float = 30.0
    write: float = 30.0
    pool: float = 5.0

    def to_httpx_timeout(self):
        """Convert to httpx.Timeout object.

        Returns:
            httpx.Timeout: Configured timeout object
        """
        import httpx

        return httpx.Timeout(
            connect=self.connect,
            read=self.read,
            write=self.write,
            pool=self.pool,
        )


@dataclass
class RetryConfig:
    """Configuration for HTTP request retry behavior.

    Attributes:
        max_attempts: Maximum number of retry attempts
        backoff_factor: Multiplier for exponential backoff (seconds)
        backoff_max: Maximum backoff time (seconds)
        status_forcelist: HTTP status codes that should trigger a retry
        retry_on_timeout: Whether to retry on timeout errors
    """

    max_attempts: int = 5
    backoff_factor: float = 0.1
    backoff_max: float = 10.0
    status_forcelist: List[int] = field(default_factory=lambda: [429, 500, 502, 503, 504])
    retry_on_timeout: bool = True


@dataclass
class PoolConfig:
    """Configuration for HTTP connection pool.

    Attributes:
        max_connections: Maximum total connections in the pool
        max_keepalive_connections: Maximum keepalive connections
        keepalive_expiry: Time before idle connections are closed (seconds)
        min_size: Minimum pool size
        max_size: Maximum pool size
        buffer_multiplier: Multiplier for calculating pool size from thread count
    """

    max_connections: int = 200
    max_keepalive_connections: int = 100
    keepalive_expiry: float = 5.0
    min_size: int = 200
    max_size: int = 1000
    buffer_multiplier: float = 1.2

    def to_httpx_limits(self):
        """Convert to httpx.Limits object.

        Returns:
            httpx.Limits: Configured limits object
        """
        import httpx

        return httpx.Limits(
            max_connections=self.max_connections,
            max_keepalive_connections=self.max_keepalive_connections,
            keepalive_expiry=self.keepalive_expiry,
        )


@dataclass
class HttpClientConfig:
    """Comprehensive HTTP client configuration.

    Combines timeout, retry, and pool configuration for creating
    fully-configured HTTP clients.

    Attributes:
        timeout: Timeout configuration
        retry: Retry strategy configuration
        pool: Connection pool configuration
        http2: Whether to enable HTTP/2 support
        verify_ssl: Whether to verify SSL certificates
        base_url: Optional base URL for all requests
    """

    timeout: HttpTimeout = field(default_factory=HttpTimeout)
    retry: RetryConfig = field(default_factory=RetryConfig)
    pool: PoolConfig = field(default_factory=PoolConfig)
    http2: bool = True
    verify_ssl: bool = True
    base_url: Optional[str] = None

    @classmethod
    def from_app_config(cls, config: dict) -> "HttpClientConfig":
        """Create HttpClientConfig from application configuration.

        Args:
            config: Application configuration dictionary

        Returns:
            HttpClientConfig: Configured instance
        """
        # Extract timeout configuration
        timeout_value = config.get("timeout", 30)
        if isinstance(timeout_value, str):
            try:
                timeout_value = float(timeout_value)
            except ValueError:
                timeout_value = 30.0

        timeout = HttpTimeout(
            read=float(timeout_value),
            connect=5.0,
            write=30.0,
            pool=5.0,
        )

        # Extract retry configuration
        retry = RetryConfig(
            max_attempts=config.get("retryAttempts", 5),
            backoff_factor=config.get("retryBackoff", 0.1),
        )

        # Extract pool configuration
        pool_config = config.get("performance", {}).get("connectionPool", {})
        max_threads = config.get("maxThreads", 100)

        # Validate and convert max_threads
        if not isinstance(max_threads, int):
            try:
                max_threads = int(max_threads)
            except (ValueError, TypeError):
                max_threads = 100

        # Cap at absolute maximum
        max_threads = min(max_threads, 500)

        # Calculate pool size
        buffer_multiplier = pool_config.get("bufferMultiplier", 1.2)
        if not isinstance(buffer_multiplier, (int, float)) or buffer_multiplier < 1.0 or buffer_multiplier > 2.0:
            buffer_multiplier = 1.2

        min_pool_size = pool_config.get("minSize", 200)
        max_pool_size = min(pool_config.get("maxSize", 1000), 2000)

        calculated_size = int(max_threads * buffer_multiplier)
        pool_size = max(min_pool_size, min(calculated_size, max_pool_size))

        pool = PoolConfig(
            max_connections=pool_size,
            max_keepalive_connections=pool_size,
            min_size=min_pool_size,
            max_size=max_pool_size,
            buffer_multiplier=buffer_multiplier,
        )

        # SSL verification
        verify_ssl = config.get("sslVerify", True)
        if isinstance(verify_ssl, str):
            verify_ssl = verify_ssl.lower() == "true"

        return cls(
            timeout=timeout,
            retry=retry,
            pool=pool,
            verify_ssl=verify_ssl,
            base_url=config.get("domain"),
        )
