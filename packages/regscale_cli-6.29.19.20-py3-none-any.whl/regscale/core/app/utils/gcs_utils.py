#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Google Cloud Storage utilities for RegScale CLI.

⚠️  CRITICAL SECURITY NOTICE - CLI USAGE ONLY ⚠️

This module uses a singleton GCS client pattern for performance optimization in CLI contexts.
The singleton pattern is ONLY safe for single-process, single-user CLI invocations.

DO NOT USE in:
- Web applications (Flask, FastAPI, Django, etc.)
- Background workers (Celery, RQ, Dramatiq, etc.)
- Multi-tenant server environments
- Long-running daemon processes serving multiple users
- Any context where multiple users/tenants share the same process

WHY: The singleton client caches credentials globally. In multi-tenant contexts,
this causes credential cross-contamination where User A's credentials are used
for User B's operations, leading to unauthorized access.

SAFE USAGE:
- RegScale CLI commands (one process per invocation, single user)
- Single-tenant batch processing scripts
- Development/testing environments

UNSAFE USAGE:
- Web API endpoints handling requests from multiple users
- Background job workers processing tasks for multiple tenants
- Scheduled tasks in shared server environments

For server environments, use one of these patterns:
1. Pass client explicitly: download_gcs_file(uri, client=storage.Client())
2. Set environment variable: REGSCALE_GCS_SINGLETON_ENABLED=false
3. Use per-request/per-tenant client instances

The module includes runtime detection for common server frameworks and will
raise RuntimeError if misused. However, detection is not exhaustive - always
review deployment context before use.
"""

import logging
import os
import re
import tempfile
import threading
from contextlib import contextmanager
from pathlib import Path
from typing import Generator, Optional, Tuple

from google.api_core import retry
from google.cloud import storage
from google.cloud.exceptions import GoogleCloudError, NotFound

logger = logging.getLogger("regscale")

# Thread-local singleton GCS client for reuse across multiple operations
#
# ⚠️  IMPORTANT: This thread-local singleton is safer than a global singleton
# but still requires careful use. Each thread gets its own client instance.
# Safe for CLI usage and limited threading scenarios, but still NOT recommended
# for multi-tenant server environments.
#
# For server use, consider:
# - Pass `client` parameter explicitly to download_gcs_file()
# - Create new client per request/tenant: storage.Client()
# - Use service account impersonation for tenant isolation
_gcs_client_local = threading.local()


def get_gcs_client() -> storage.Client:
    """
    Get or create thread-local GCS client for performance (CLI usage only).

    Reusing the same client across multiple operations improves performance by:
    - Avoiding repeated authentication flows
    - Enabling connection pooling
    - Reducing API quota consumption

    ⚠️  CRITICAL: This thread-local singleton is safer than a global singleton
    but still requires careful use. Each thread gets its own client instance.
    The function includes runtime checks to prevent usage in server environments.

    :return: Thread-local GCS storage client
    :rtype: storage.Client
    :raises RuntimeError: If called from a server environment (FastAPI, Flask, Gunicorn, etc.)
    """
    # Runtime detection of server environments to prevent credential cross-contamination
    import sys

    server_modules = {
        # Web frameworks
        "uvicorn": "Uvicorn (FastAPI/Starlette)",
        "gunicorn": "Gunicorn",
        "flask": "Flask",
        "fastapi": "FastAPI",
        "django": "Django",
        "tornado": "Tornado",
        "aiohttp": "aiohttp",
        "sanic": "Sanic",
        # Background worker frameworks
        "celery": "Celery",
        "rq": "RQ (Redis Queue)",
        "dramatiq": "Dramatiq",
        "huey": "Huey",
        "taskiq": "Taskiq",
    }

    detected_servers = [(name, desc) for name, desc in server_modules.items() if name in sys.modules]

    if detected_servers:
        server_names = ", ".join(desc for _, desc in detected_servers)
        raise RuntimeError(
            f"GCS thread-local client detected in server environment ({server_names}). "
            "This is NOT safe for multi-tenant environments and may cause credential cross-contamination. "
            "Solutions: "
            "(1) Pass client=storage.Client() explicitly to download_gcs_file() per request, "
            "(2) Use per-tenant client instances with service account impersonation, "
            "(3) Disable thread-local via REGSCALE_GCS_SINGLETON_ENABLED=false environment variable."
        )

    # Allow opt-out via environment variable for testing/special cases
    if os.getenv("REGSCALE_GCS_SINGLETON_ENABLED", "true").lower() == "false":
        logger.debug("GCS thread-local client disabled via REGSCALE_GCS_SINGLETON_ENABLED=false, creating new client")
        return storage.Client()

    # Use thread-local storage for client - each thread gets its own instance
    if not hasattr(_gcs_client_local, "client"):
        _gcs_client_local.client = storage.Client()
        logger.debug("Created thread-local GCS client for CLI usage")

    return _gcs_client_local.client


def is_gcs_path(path: str) -> bool:
    """
    Check if path is a GCS URI (gs://bucket/path).

    :param str path: Path to check
    :return: True if GCS path, False otherwise
    :rtype: bool

    Example:
        >>> is_gcs_path("gs://my-bucket/file.xlsx")
        True
        >>> is_gcs_path("/local/path/file.xlsx")
        False
    """
    return bool(re.match(r"^gs://", path))


def parse_gcs_path(gcs_uri: str) -> Tuple[str, str]:
    """
    Parse GCS URI into bucket and blob path.

    :param str gcs_uri: GCS URI (gs://bucket/path/to/file.xlsx)
    :return: Tuple of (bucket_name, blob_path)
    :rtype: Tuple[str, str]
    :raises ValueError: If URI is invalid

    Example:
        >>> parse_gcs_path("gs://my-bucket/path/to/file.xlsx")
        ('my-bucket', 'path/to/file.xlsx')
    """
    match = re.match(r"^gs://([^/]+)/(.+)$", gcs_uri)
    if not match:
        raise ValueError("Invalid GCS URI format (expected gs://bucket/path)")
    return match.group(1), match.group(2)


@contextmanager
def download_gcs_file(
    gcs_uri: str, suffix: Optional[str] = None, client: Optional[storage.Client] = None
) -> Generator[Path, None, None]:
    """
    Download GCS file to temporary location and yield path.
    Automatically cleans up temp file when context exits.

    :param str gcs_uri: GCS URI (gs://bucket/path/to/file.xlsx)
    :param Optional[str] suffix: File suffix for temp file (e.g., ".xlsx")
    :param Optional[storage.Client] client: Optional GCS client to reuse (for performance in bulk operations)
    :return: Path to temporary file
    :rtype: Path
    :raises NotFound: If GCS object doesn't exist
    :raises GoogleCloudError: For other GCS errors

    Example:
        >>> with download_gcs_file("gs://bucket/file.xlsx", ".xlsx") as temp_path:
        ...     workbook = load_workbook(temp_path)
        >>>
        >>> # For bulk operations, reuse client
        >>> gcs_client = get_gcs_client()
        >>> with download_gcs_file("gs://bucket/file1.xlsx", client=gcs_client) as path:
        ...     process(path)
    """
    bucket_name, blob_path = parse_gcs_path(gcs_uri)
    temp_path = None

    try:
        # Use provided client or get singleton
        gcs_client = client or get_gcs_client()
        bucket = gcs_client.bucket(bucket_name)
        blob = bucket.blob(blob_path)

        # Get file metadata (size) before downloading
        blob.reload()
        file_size_bytes = blob.size or 0
        file_size_mb = file_size_bytes / (1024**2)

        # Create temp file with NamedTemporaryFile (auto-closes FD, avoids leak)
        with tempfile.NamedTemporaryFile(suffix=suffix or os.path.splitext(blob_path)[1], delete=False) as tmp:
            temp_path = tmp.name
            # FD is automatically closed when exiting with block

        # Sanitize URI for logging (prevent credential/bucket/path/filename exposure in logs)
        # Redact all sensitive information - bucket name, path, and filename
        # For debugging, use GCP Cloud Logging or audit logs which have proper access controls
        import hashlib

        file_hash = hashlib.sha256(blob_path.encode()).hexdigest()[:8]
        sanitized_uri = f"gs://<REDACTED-BUCKET>/<REDACTED-PATH>/file-{file_hash}"
        logger.info(f"Downloading GCS file: {sanitized_uri} ({file_size_mb:.2f} MB)")
        # Full URI intentionally NOT logged even at DEBUG level to prevent accidental exposure
        # If debugging is needed, use GCP Cloud Logging or audit logs instead

        # Progress indicator for files above threshold (default 5 MB, configurable via env var)
        progress_threshold_mb = float(os.getenv("REGSCALE_GCS_PROGRESS_THRESHOLD_MB", "5.0"))
        if file_size_mb > progress_threshold_mb:
            logger.info(f"Downloading file ({file_size_mb:.1f} MB), this may take a while...")

        # Configure retry policy with exponential backoff (max 10 minutes total)
        # Initial delay: 1 second, multiplier: 2x, max delay: 60 seconds, timeout: 600 seconds
        download_retry = retry.Retry(
            initial=1.0,
            maximum=60.0,
            multiplier=2.0,
            timeout=600.0,
            predicate=retry.if_exception_type(GoogleCloudError),
        )

        # Download with timeout and retry configuration
        blob.download_to_filename(temp_path, retry=download_retry)

        logger.info(f"Download complete: {file_size_mb:.2f} MB")
        logger.debug(f"Temp file path: {temp_path}")

        yield Path(temp_path)

    except NotFound:
        logger.error("GCS object not found: <REDACTED>")
        raise RuntimeError("GCS object not found. Check file path and permissions.") from None
    except GoogleCloudError as e:
        logger.error(f"GCS error downloading file: {type(e).__name__}")
        raise RuntimeError(f"Failed to download GCS file: {type(e).__name__}") from e
    finally:
        # Clean up temp file with robust error handling
        if temp_path and os.path.exists(temp_path):
            try:
                os.remove(temp_path)
                logger.debug(f"Cleaned up temp file: {temp_path}")
            except OSError as e:
                # Log but don't raise - cleanup failure shouldn't mask original error
                logger.warning(f"Failed to remove temp file {temp_path}: {e}")
            except Exception as e:
                logger.error(f"Unexpected error removing temp file {temp_path}: {e}")


def get_gcs_file_size(gcs_uri: str) -> int:
    """
    Get size of GCS file in bytes without downloading.

    :param str gcs_uri: GCS URI
    :return: File size in bytes
    :rtype: int

    Example:
        >>> get_gcs_file_size("gs://bucket/file.xlsx")
        1048576
    """
    bucket_name, blob_path = parse_gcs_path(gcs_uri)
    client = get_gcs_client()
    bucket = client.bucket(bucket_name)
    blob = bucket.blob(blob_path)
    blob.reload()
    return blob.size
