"""
Structured logging with OpenTelemetry integration.

Provides consistent, parsable JSON logging with automatic trace context propagation.
Compatible with standard Python logging while adding structured fields.

Example:
    >>> from regscale.core.observability import get_logger
    >>>
    >>> logger = get_logger(__name__)
    >>>
    >>> # Structured logging with context
    >>> logger.info(
    ...     "Bulk upload completed",
    ...     items_processed=1000,
    ...     duration_seconds=45.2,
    ...     success_count=950,
    ...     failure_count=50
    ... )
    >>>
    >>> # Traditional logging still works
    >>> logger.info("Operation started")
"""

import json
import logging
import re
import sys
import time
from contextvars import ContextVar
from typing import Any, Dict, Optional, Set

# Try to import OpenTelemetry (optional dependency)
try:
    from opentelemetry import trace as otel_trace

    OTEL_AVAILABLE = True
except ImportError:
    OTEL_AVAILABLE = False
    otel_trace = None

# Context variables for operation tracking
_operation_id: ContextVar[Optional[str]] = ContextVar("operation_id", default=None)
_trace_id: ContextVar[Optional[str]] = ContextVar("trace_id", default=None)


class StructuredFormatter(logging.Formatter):
    """
    JSON formatter with OpenTelemetry trace context.

    Outputs logs in structured JSON format compatible with Grafana Loki,
    Elasticsearch, and other log aggregation systems.

    Includes automatic sanitization of sensitive fields to prevent credential
    leakage in logs.
    """

    def __init__(self, include_context: bool = True) -> None:
        """
        Initialize the structured formatter.

        Args:
            include_context: Whether to include trace context (trace_id, span_id,
                           operation_id) in log output. Defaults to True.
        """
        super().__init__()
        self.include_context = include_context

    # Fields that should be redacted in logs to prevent credential leakage
    SENSITIVE_FIELDS: Set[str] = {
        "password",
        "passwd",
        "pwd",
        "token",
        "api_key",
        "apikey",
        "api-key",
        "secret",
        "client_secret",
        "client-secret",
        "access_token",
        "access-token",
        "refresh_token",
        "refresh-token",
        "authorization",
        "auth",
        "bearer",
        "credential",
        "credentials",
        "private_key",
        "private-key",
        "privatekey",
        "ssh_key",
        "ssh-key",
        "session_id",
        "session-id",
        "sessionid",
        "cookie",
        "x-api-key",
        "x_api_key",
    }

    # Regex pattern for detecting token-like strings (long alphanumeric strings without spaces)
    TOKEN_PATTERN = re.compile(r"^[A-Za-z0-9_\-+=/.]{32,}$")

    def _sanitize_value(self, key: str, value: Any) -> Any:
        """
        Sanitize a single value, redacting if it appears sensitive.

        Args:
            key: The field name
            value: The field value

        Returns:
            The original value or "[REDACTED]" if sensitive
        """
        # Check if key name indicates sensitive data (case-insensitive)
        key_lower = key.lower()
        if any(sensitive in key_lower for sensitive in self.SENSITIVE_FIELDS):
            return "[REDACTED]"

        # Check if string value looks like a token (long string without spaces)
        if isinstance(value, str) and len(value) >= 32 and self.TOKEN_PATTERN.match(value):
            return f"[REDACTED:{len(value)} chars]"

        return value

    def _sanitize_context(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Recursively sanitize a context dictionary, removing sensitive data.

        Args:
            context: Dictionary of context fields to sanitize

        Returns:
            Sanitized dictionary with sensitive values redacted
        """
        if not isinstance(context, dict):
            return context

        sanitized = {}
        for key, value in context.items():
            if isinstance(value, dict):
                # Recursively sanitize nested dictionaries
                sanitized[key] = self._sanitize_context(value)
            elif isinstance(value, list):
                # Sanitize list items
                sanitized[key] = [
                    self._sanitize_context(item) if isinstance(item, dict) else self._sanitize_value(key, item)
                    for item in value
                ]
            else:
                sanitized[key] = self._sanitize_value(key, value)

        return sanitized

    def _get_otel_trace_context(self) -> Dict[str, str]:
        """Get OpenTelemetry trace context if available."""
        context = {}
        if not (OTEL_AVAILABLE and otel_trace):
            return context

        span = otel_trace.get_current_span()
        if not span:
            return context

        span_context = span.get_span_context()
        if span_context.is_valid:
            context["trace_id"] = format(span_context.trace_id, "032x")
            context["span_id"] = format(span_context.span_id, "016x")
        return context

    def _get_context_vars(self) -> Dict[str, str]:
        """Get trace context from ContextVars."""
        context = {}
        operation_id = _operation_id.get()
        if operation_id:
            context["operation_id"] = operation_id

        trace_id = _trace_id.get()
        if trace_id:
            context["trace_id"] = trace_id
        return context

    def _get_exception_dict(self, record: logging.LogRecord) -> Optional[Dict[str, Any]]:
        """Get exception info as a dictionary if present."""
        if not record.exc_info:
            return None

        exc_type, exc_value, _ = record.exc_info
        return {
            "type": exc_type.__name__ if exc_type else None,
            "message": str(exc_value) if exc_value else None,
            "traceback": self.formatException(record.exc_info),
        }

    def format(self, record: logging.LogRecord) -> str:
        """Format log record as JSON with trace context."""
        log_entry = {
            "timestamp": self.formatTime(record, self.datefmt),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }

        if self.include_context:
            log_entry.update(self._get_otel_trace_context())
            log_entry.update(self._get_context_vars())

        if hasattr(record, "context"):
            log_entry["context"] = self._sanitize_context(record.context)

        exception_dict = self._get_exception_dict(record)
        if exception_dict:
            log_entry["exception"] = exception_dict

        log_entry["file"] = {
            "name": record.filename,
            "line": record.lineno,
            "function": record.funcName,
        }

        return json.dumps(log_entry)


class StructuredLogger(logging.LoggerAdapter):
    """
    Logger adapter that adds structured context to all log calls.

    Wraps standard Python logger to provide structured logging capabilities
    while maintaining backward compatibility.

    Example:
        >>> logger = StructuredLogger(logging.getLogger(__name__))
        >>> logger.info("Processing items", count=100, batch_size=10)
    """

    def __init__(self, logger: logging.Logger, extra: Optional[Dict[str, Any]] = None):
        """
        Initialize structured logger.

        Args:
            logger: Standard Python logger instance
            extra: Default context to include in all logs
        """
        super().__init__(logger, extra or {})

    def process(self, msg: str, kwargs: Dict[str, Any]) -> tuple:
        """
        Process log call to add structured context.

        Extracts keyword arguments and adds them as structured context
        while maintaining the original message.
        """
        # Extract context from kwargs
        context = {}

        # Get kwargs that aren't standard logging parameters
        standard_params = {"exc_info", "stack_info", "stacklevel", "extra"}
        for key in list(kwargs.keys()):
            if key not in standard_params:
                context[key] = kwargs.pop(key)

        # Add to extra for structured output
        if "extra" not in kwargs:
            kwargs["extra"] = {}

        kwargs["extra"]["context"] = context

        return msg, kwargs

    def debug(self, msg: str, *args, **kwargs):
        """Log debug message with structured context."""
        self.logger.debug(msg, *args, **self.process(msg, kwargs)[1])

    def info(self, msg: str, *args, **kwargs):
        """Log info message with structured context."""
        self.logger.info(msg, *args, **self.process(msg, kwargs)[1])

    def warning(self, msg: str, *args, **kwargs):
        """Log warning message with structured context."""
        self.logger.warning(msg, *args, **self.process(msg, kwargs)[1])

    def error(self, msg: str, *args, **kwargs):
        """Log error message with structured context."""
        self.logger.error(msg, *args, **self.process(msg, kwargs)[1])

    def critical(self, msg: str, *args, **kwargs):
        """Log critical message with structured context."""
        self.logger.critical(msg, *args, **self.process(msg, kwargs)[1])


def configure_logging(
    format_type: str = "json",
    level: str = "INFO",
    include_context: bool = True,
    output_file: Optional[str] = None,
) -> None:
    """
    Configure global logging settings.

    Args:
        format_type: "json" for structured JSON, "text" for human-readable
        level: Log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        include_context: Whether to include trace context in logs
        output_file: Optional file path for log output

    Example:
        >>> configure_logging(format_type="json", level="INFO")
    """
    # Get root logger
    root_logger = logging.getLogger("regscale")

    # Clear existing handlers
    root_logger.handlers.clear()

    # Set level
    log_level = getattr(logging, level.upper(), logging.INFO)
    root_logger.setLevel(log_level)

    # Create handler
    if output_file:
        handler = logging.FileHandler(output_file)
    else:
        handler = logging.StreamHandler(sys.stdout)

    # Set formatter
    if format_type == "json":
        formatter = StructuredFormatter(include_context=include_context)
    else:
        # Traditional format
        formatter = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s", datefmt="%Y-%m-%d %H:%M:%S"
        )

    handler.setFormatter(formatter)
    root_logger.addHandler(handler)

    # Prevent propagation to root
    root_logger.propagate = False


def get_logger(name: str) -> StructuredLogger:
    """
    Get a structured logger instance.

    Args:
        name: Logger name (typically __name__)

    Returns:
        StructuredLogger instance

    Example:
        >>> logger = get_logger(__name__)
        >>> logger.info("Processing started", batch_size=100)
    """
    base_logger = logging.getLogger(name)
    return StructuredLogger(base_logger)


def set_operation_context(operation_id: str, trace_id: Optional[str] = None) -> None:
    """
    Set operation context for all logs in current execution context.

    Args:
        operation_id: Unique identifier for this operation
        trace_id: Optional trace ID for correlation

    Example:
        >>> set_operation_context("bulk_upload_20251116", "abc-123-def")
        >>> logger.info("Starting upload")  # Will include operation_id
    """
    _operation_id.set(operation_id)
    if trace_id:
        _trace_id.set(trace_id)


def clear_operation_context() -> None:
    """Clear operation context."""
    _operation_id.set(None)
    _trace_id.set(None)


def get_operation_context() -> Dict[str, Optional[str]]:
    """
    Get current operation context.

    Returns:
        Dictionary with operation_id and trace_id

    Example:
        >>> context = get_operation_context()
        >>> print(context["operation_id"])
    """
    return {
        "operation_id": _operation_id.get(),
        "trace_id": _trace_id.get(),
    }


class LogTimer:
    """
    Context manager for timing operations with automatic logging.

    Example:
        >>> logger = get_logger(__name__)
        >>> with LogTimer(logger, "data_processing", items_count=1000):
        ...     process_data()
        # Logs: "data_processing completed" with duration_seconds=X.XX
    """

    def __init__(self, logger: StructuredLogger, operation: str, **context):
        """
        Initialize log timer.

        Args:
            logger: StructuredLogger instance
            operation: Operation name
            **context: Additional context to include in log
        """
        self.logger = logger
        self.operation = operation
        self.context = context
        self.start_time = None

    def __enter__(self):
        """Start timer."""
        self.start_time = time.time()
        self.logger.debug(f"{self.operation} started", **self.context)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Stop timer and log result."""
        duration = time.time() - self.start_time

        if exc_type is None:
            self.logger.info(f"{self.operation} completed", duration_seconds=duration, **self.context)
        else:
            self.logger.error(
                f"{self.operation} failed",
                duration_seconds=duration,
                error_type=exc_type.__name__,
                error_message=str(exc_val),
                **self.context,
            )

        return False  # Don't suppress exceptions


# Initialize default logging on module import
configure_logging(format_type="json", level="INFO")
