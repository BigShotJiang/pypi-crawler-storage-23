"""Version information for regscale-cli."""


def get_version_from_metadata() -> str:
    """
    Extract version from package metadata.

    :return: Version string from package metadata or fallback
    :rtype: str
    """
    try:
        from importlib.metadata import version

        return version("regscale-cli")
    except Exception:
        pass
    return "6.29.15.0"  # fallback version


__version__ = get_version_from_metadata()
