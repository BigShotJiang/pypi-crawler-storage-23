:layout: landing

.. figure:: _static/canaille-full-black.webp
  :width: 400
  :figclass: light-only
  :align: center

.. figure:: _static/canaille-full-white.webp
  :width: 400
  :figclass: dark-only
  :align: center

.. rst-class:: lead

    Lightweight Identity and Authorization Management

----

**Canaille** is a French word meaning *rascal*. It is roughly pronounced **Can I?**,
as in *Can I access your data?* Canaille is a lightweight identity and authorization management software.
It aims to be very light, simple to install and simple to maintain. Its main features are :

.. grid:: 1 1 2 3
    :gutter: 2
    :padding: 0
    :class-row: surface

    .. grid-item-card:: :iconify:`mdi:account-multiple` Profile management
        :link-type: ref
        :link: feature_profile_management

        User profile and groups management,
        basic permission system,
        group management,
        multiple user sessions

    .. grid-item-card:: :iconify:`mdi:shield-account` User authentication
        :link-type: ref
        :link: feature_user_authentication

        Authentication,
        registration,
        email confirmation,
        password reset emails,
        multi-factor authentication,
        CAPTCHA

    .. grid-item-card:: :iconify:`mdi:key-chain` :abbr:`SSO (Single Sign-On)`
        :link-type: ref
        :link: feature_oidc

        OpenID Connect identity provider.
        Sign-in once for all your services.

    .. grid-item-card:: :iconify:`mdi:database` Multi-database support
        :link-type: ref
        :link: feature_databases

        PostgreSQL, SQLite and OpenLDAP support

    .. grid-item-card:: :iconify:`mdi:palette` Customization
        :link-type: ref
        :link: feature_ui

        Put Canaille at yours colors by choosing a logo or use a custom theme!

    .. grid-item-card:: :iconify:`mdi:code-braces` Developers friendliness
        :link-type: ref
        :link: feature_development

        Canaille can easily fit in your unit tests suite or in your Continuous Integration.

.. container:: buttons

    :doc:`Common use cases <usecases>`
    :doc:`Full feature list <features>`

.. rst-class:: lead

    Documentation

----

.. toctree::
   :maxdepth: 2

   usecases
   features
   tutorials/index
   howtos/index
   references/index
   development/index
