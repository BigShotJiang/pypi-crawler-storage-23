import json
import uuid
from datetime import datetime
from datetime import timedelta
from datetime import timezone

import httpx
from flask import current_app
from joserfc import jwk
from joserfc import jws
from joserfc import jwt
from joserfc.jwk import OKPKey
from joserfc.jwk import RSAKey

from canaille.app.flask import cache

registry = jws.JWSRegistry(algorithms=list(jws.JWSRegistry.algorithms.keys()))


def supported_verification_algorithms(excluded=None):
    """Return the list of JWS algorithms the server can verify."""
    return [
        alg for alg in registry.algorithms.keys() if not excluded or alg not in excluded
    ]


def make_default_okp_jwk(seed=None):
    """Generate a deterministic JWK based on a seed."""
    if not seed:
        return OKPKey.generate_key(auto_kid=True)

    return OKPKey.derive_key(seed, auto_kid=True)


def make_default_rsa_jwk():
    """Generate a random RSA JWK for RS256 support."""
    return RSAKey.generate_key(2048, auto_kid=True)


def has_rsa_key(keys):
    """Check if at least one RSA key is present in the key list."""
    for key in keys:
        key_obj = jwk.import_key(key)
        if key_obj.as_dict().get("kty") == "RSA":
            return True
    return False


def get_alg_for_key(key):
    """Find the algorithm for the given key."""
    return registry.guess_algorithm(key, registry.Strategy.SECURITY).name


def server_jwks(include_inactive=True):
    keys = list(current_app.config["CANAILLE_OIDC"]["ACTIVE_JWKS"])
    if include_inactive and current_app.config["CANAILLE_OIDC"]["INACTIVE_JWKS"]:
        keys += list(current_app.config["CANAILLE_OIDC"]["INACTIVE_JWKS"])

    key_objs = []
    for key in keys:
        key_objs.append(jwk.import_key(key))

    for obj in key_objs:
        obj.ensure_kid()
    return jwk.KeySet(key_objs)


def supported_signing_algorithms():
    """Return the list of JWS algorithms the server can sign with.

    This is computed dynamically from the active JWKS keys.
    Includes 'none' as allowed by OIDC spec for id_token and userinfo signing.
    """
    keys = server_jwks(include_inactive=False)
    algorithms = ["none"] + [alg.name for alg in registry.filter_algorithms(keys)]
    return algorithms


def get_client_jwks(client, kid=None):
    """Get the client JWK set, either stored locally or by downloading them from the URI the client indicated."""

    @cache.cached(timeout=50, key_prefix=f"jwks_{client.client_id}")
    def get_public_jwks():
        return httpx.get(client.jwks_uri).json()

    if client.jwks_uri:
        raw_jwks = get_public_jwks()
        key_set = jwk.KeySet.import_key_set(raw_jwks)
        key = key_set.get_by_kid(kid)
        return key

    if client.jwks:
        raw_jwks = json.loads(client.jwks)
        key_set = jwk.KeySet.import_key_set(raw_jwks)
        key = key_set.get_by_kid(kid)
        return key

    return None


def build_client_management_token(
    scope: str, lifetime: timedelta | None = None, client_id: str | None = None
):
    """Build a JWT token for client registration."""
    from .provider import get_issuer

    jti = str(uuid.uuid4())
    client_id = client_id or str(uuid.uuid4())
    now = datetime.now(timezone.utc)
    issuer = get_issuer()

    payload = {
        "iss": issuer,
        "sub": client_id,
        "aud": issuer,
        "iat": int(now.timestamp()),
        "jti": jti,
        "scope": scope,
    }
    if lifetime:
        payload["exp"] = int((now + lifetime).timestamp())

    jwks = server_jwks(include_inactive=False)
    jwk_key = jwks.keys[0]
    alg = get_alg_for_key(jwk_key)

    token = jwt.encode({"alg": alg}, payload, jwk_key, registry=registry)

    return token
