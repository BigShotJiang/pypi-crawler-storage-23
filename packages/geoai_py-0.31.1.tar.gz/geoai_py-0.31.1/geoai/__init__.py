"""Top-level package for geoai."""

__author__ = """Qiusheng Wu"""
__email__ = "giswqs@gmail.com"
__version__ = "0.31.1"


import os
import sys


def set_proj_lib_path(verbose=False):
    """
    Set the PROJ_LIB and GDAL_DATA environment variables based on the current conda environment.

    This function attempts to locate and set the correct paths for PROJ_LIB and GDAL_DATA
    by checking multiple possible locations within the conda environment structure.

    Args:
        verbose (bool): If True, print additional information during the process.

    Returns:
        bool: True if both paths were set successfully, False otherwise.
    """
    try:
        from rasterio.env import set_gdal_config

        # Get conda environment path
        conda_env_path = os.environ.get("CONDA_PREFIX") or sys.prefix

        # Define possible paths for PROJ_LIB
        possible_proj_paths = [
            os.path.join(conda_env_path, "share", "proj"),
            os.path.join(conda_env_path, "Library", "share", "proj"),
            os.path.join(conda_env_path, "Library", "share"),
        ]

        # Define possible paths for GDAL_DATA
        possible_gdal_paths = [
            os.path.join(conda_env_path, "share", "gdal"),
            os.path.join(conda_env_path, "Library", "share", "gdal"),
            os.path.join(conda_env_path, "Library", "data", "gdal"),
            os.path.join(conda_env_path, "Library", "share"),
        ]

        # Set PROJ_LIB environment variable
        proj_set = False
        for proj_path in possible_proj_paths:
            if os.path.exists(proj_path) and os.path.isdir(proj_path):
                # Verify it contains projection data
                if os.path.exists(os.path.join(proj_path, "proj.db")):
                    os.environ["PROJ_LIB"] = proj_path
                    if verbose:
                        print(f"PROJ_LIB set to: {proj_path}")
                    proj_set = True
                    break

        # Set GDAL_DATA environment variable
        gdal_set = False
        for gdal_path in possible_gdal_paths:
            if os.path.exists(gdal_path) and os.path.isdir(gdal_path):
                # Verify it contains the header.dxf file or other critical GDAL files
                if os.path.exists(
                    os.path.join(gdal_path, "header.dxf")
                ) or os.path.exists(os.path.join(gdal_path, "gcs.csv")):
                    os.environ["GDAL_DATA"] = gdal_path
                    if verbose:
                        print(f"GDAL_DATA set to: {gdal_path}")
                    gdal_set = True
                    break

        # If paths still not found, try a last-resort approach
        if not proj_set or not gdal_set:
            # Try a deep search in the conda environment
            for root, dirs, files in os.walk(conda_env_path):
                if not gdal_set and "header.dxf" in files:
                    os.environ["GDAL_DATA"] = root
                    if verbose:
                        print(f"GDAL_DATA set to: {root} (deep search)")
                    gdal_set = True

                if not proj_set and "proj.db" in files:
                    os.environ["PROJ_LIB"] = root
                    if verbose:
                        print(f"PROJ_LIB set to: {root} (deep search)")
                    proj_set = True

                if proj_set and gdal_set:
                    break

        set_gdal_config("PROJ_LIB", os.environ["PROJ_LIB"])
        set_gdal_config("GDAL_DATA", os.environ["GDAL_DATA"])

    except Exception as e:
        print(f"Error setting projection library paths: {e}")
        return


# if ("google.colab" not in sys.modules) and (sys.platform != "windows"):
#     set_proj_lib_path()

from .pipeline import (
    Pipeline,
    PipelineStep,
    FunctionStep,
    GlobStep,
    PipelineResult,
    load_pipeline,
    register_step,
)

try:
    from .dinov3 import DINOv3GeoProcessor, analyze_image_patches, create_similarity_map
except (ImportError, OSError):
    # DINOv3 not available (missing torch dependency or DLL load failure)
    pass

try:
    from .geoai import *
except (ImportError, OSError):
    # Core geoai module not available (missing torch dependency or DLL load failure)
    pass
from .utils import (
    orthogonalize,
    regularization,
    hybrid_regularization,
    adaptive_regularization,
    flipnslide_augmentation,
    export_flipnslide_tiles,
)

try:
    from .timm_train import (
        get_timm_model,
        modify_first_conv_for_channels,
        TimmClassifier,
        RemoteSensingDataset,
        train_timm_classifier,
        predict_with_timm,
        list_timm_models,
    )
except (ImportError, OSError):
    # timm_train not available (missing torch/timm dependency)
    pass

try:
    from .recognize import (
        ImageDataset,
        load_image_dataset,
        train_image_classifier,
        predict_images,
        evaluate_classifier,
        plot_training_history as plot_classification_history,
        plot_confusion_matrix,
        plot_predictions,
    )
except (ImportError, OSError):
    # recognize not available (missing torch dependency)
    pass

try:
    from .timm_segment import (
        TimmSegmentationModel,
        SegmentationDataset,
        train_timm_segmentation,
        predict_segmentation,
        train_timm_segmentation_model,
        timm_semantic_segmentation,
        push_timm_model_to_hub,
        timm_segmentation_from_hub,
    )
except (ImportError, OSError):
    # timm_segment not available (missing torch/timm dependency)
    pass

try:
    from .timm_regress import (
        PixelRegressionModel,
        PixelRegressionDataset,
        create_regression_tiles,
        train_pixel_regressor,
        predict_raster,
        evaluate_regression,
        plot_regression_comparison,
        plot_scatter,
        plot_training_history,
        visualize_prediction,
        plot_regression_results,
        # Backward compatibility aliases
        TimmRegressor,
        RegressionDataset,
        train_timm_regressor,
        create_regression_patches,
    )
except (ImportError, OSError):
    # timm_regress not available (missing torch/timm dependency)
    pass

# Import tools subpackage
try:
    from . import tools
except (ImportError, OSError):
    # tools subpackage not available (dependency or DLL load failure)
    pass

# Expose commonly used tools at package level for convenience
try:
    from .tools import (
        clean_segmentation_mask,
        clean_raster,
        clean_raster_batch,
        compare_masks,
    )
except (ImportError, OSError):
    # MultiClean not available (missing dependency)
    pass

# Removed redundant cloud mask imports; these are already available via the tools subpackage.

try:
    from .tools import super_resolution
except (ImportError, OSError):
    # super_resolution not available (missing dependency)
    pass

# ONNX Runtime support
try:
    from .onnx import (
        ONNXGeoModel,
        export_to_onnx,
        onnx_semantic_segmentation,
        onnx_image_classification,
    )
except (ImportError, OSError):
    # ONNX not available (missing dependency)
    pass

# Moondream Vision Language Model
try:
    from .moondream import (
        MoondreamGeo,
        moondream_caption,
        moondream_query,
        moondream_detect,
        moondream_point,
        moondream_caption_sliding_window,
        moondream_query_sliding_window,
        moondream_detect_sliding_window,
        moondream_point_sliding_window,
    )
    from .map_widgets import moondream_gui
except (ImportError, OSError):
    # Moondream not available (missing dependency)
    pass

# Prithvi EO 2.0 Geospatial Foundation Model
try:
    from .prithvi import (
        PrithviProcessor,
        get_available_prithvi_models,
        load_prithvi_model,
        prithvi_inference,
    )
except (ImportError, OSError):
    # Prithvi not available (missing dependency)
    pass

# ChangeStar building change detection
try:
    from .change_detection import (
        ChangeStarDetection,
        changestar_detect,
        list_changestar_models,
    )
except (ImportError, OSError):
    # ChangeStar not available (missing torchange dependency)
    pass

# Canopy height estimation (Meta's HighResCanopyHeight)
try:
    from .canopy import (
        CanopyHeightEstimation,
        canopy_height_estimation,
        list_canopy_models,
    )
except (ImportError, OSError):
    # Canopy height estimation not available (missing torch dependency)
    pass

# TESSERA geospatial foundation model embeddings
try:
    from .tessera import (
        tessera_download,
        tessera_fetch_embeddings,
        tessera_coverage,
        tessera_visualize_rgb,
        tessera_tile_count,
        tessera_available_years,
        tessera_sample_points,
    )
except (ImportError, OSError):
    # TESSERA not available (missing geotessera dependency)
    pass

# TorchGeo embedding datasets (v0.9.0+)
try:
    from .embeddings import (
        list_embedding_datasets,
        load_embedding_dataset,
        get_embedding_info,
        extract_patch_embeddings,
        extract_pixel_embeddings,
        visualize_embeddings,
        plot_embedding_vector,
        plot_embedding_raster,
        cluster_embeddings,
        embedding_similarity,
        train_embedding_classifier,
        compare_embeddings,
        embedding_to_geotiff,
        download_google_satellite_embedding,
        EMBEDDING_DATASETS,
    )
except (ImportError, OSError):
    # Embeddings not available (missing torchgeo >= 0.9.0 or sklearn)
    pass

# Multi-class object detection
try:
    from .object_detect import (
        NWPU_VHR10_CLASSES,
        download_nwpu_vhr10,
        download_nwpu_vhr10_model,
        prepare_nwpu_vhr10,
        train_multiclass_detector,
        multiclass_detection,
        detections_to_geodataframe,
        visualize_multiclass_detections,
        evaluate_multiclass_detector,
    )
except (ImportError, OSError):
    pass

# OmniWaterMask water body segmentation
try:
    from .water import segment_water, BAND_ORDER_PRESETS
except (ImportError, OSError):
    # OmniWaterMask not available (missing omniwatermask dependency)
    pass
