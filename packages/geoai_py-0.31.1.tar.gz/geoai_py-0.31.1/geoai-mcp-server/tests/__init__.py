"""Tests for the GeoAI MCP Server."""
