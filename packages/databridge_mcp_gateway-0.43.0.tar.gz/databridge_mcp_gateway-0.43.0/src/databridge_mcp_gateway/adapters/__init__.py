"""Protocol adapters for the DataBridge Graph API Gateway."""
