"""Tier-based access control for the Graph API Gateway.

Enforces license tier restrictions (CE/Pro/Enterprise) at the gateway
level, preventing lower-tier tenants from accessing higher-tier tools.
"""

from __future__ import annotations


class TierGate:
    """Check whether a tenant's tier grants access to a tool's required tier."""

    TIER_ACCESS = {
        "CE": {"CE"},
        "PRO": {"CE", "PRO"},
        "ENTERPRISE": {"CE", "PRO", "ENTERPRISE"},
        # Aliases
        "Pro": {"CE", "PRO"},
        "Enterprise": {"CE", "PRO", "ENTERPRISE"},
        "FULL": {"CE", "PRO", "ENTERPRISE"},
    }

    def can_access(self, tenant_tier: str, tool_tier: str) -> bool:
        """Return True if tenant_tier allows access to tool_tier.

        Args:
            tenant_tier: The tenant's subscription tier (e.g. "CE", "PRO").
            tool_tier: The tool's required tier from ToolMetadata.

        Returns:
            True if access is allowed.
        """
        allowed = self.TIER_ACCESS.get(tenant_tier.upper(), {"CE"})
        return tool_tier.upper() in {t.upper() for t in allowed}
