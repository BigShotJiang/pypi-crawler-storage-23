"""Request context that flows through every gateway invocation."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict


@dataclass(frozen=True)
class RequestContext:
    """Immutable per-request context shared across all protocols."""

    tenant_id: str = "default"
    tenant_tier: str = "CE"
    auth_method: str = "none"       # "api_key" | "jwt" | "mcp_token" | "none"
    protocol: str = "rest"          # "rest" | "mcp" | "ws" | "sse"
    request_id: str = field(default_factory=lambda: uuid.uuid4().hex[:16])
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    metadata: Dict[str, Any] = field(default_factory=dict)
