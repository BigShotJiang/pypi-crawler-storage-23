import json
from datetime import datetime
import requests

FILE_NAME = "tabs.json"


def load_tabs():
    try:
        with open(FILE_NAME, "r") as file:
            return json.load(file)
    except:
        return []


def save_tabs(tabs):
    with open(FILE_NAME, "w") as file:
        json.dump(tabs, file, indent=4)


def fetch_page_title(url):
    """Fetch the title of a webpage"""
    try:
        headers = {'User-Agent': 'Mozilla/5.0'}
        response = requests.get(url, timeout=5, headers=headers)
        if response.status_code == 200:
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(response.content, 'html.parser')
            title = soup.find('title')
            return title.string if title else "Untitled"
    except:
        pass
    return "Untitled"

def add_tab(url, reason, title=None, due_date=None):
    tabs = load_tabs()

    if title is None:
        title = fetch_page_title(url)

    new_tab = {
        "url": url,
        "reason": reason,
        "title": title,
        "date_added": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "due_date": due_date,
        "completed": False
    }

    tabs.append(new_tab)
    save_tabs(tabs)


def get_tabs():
    return load_tabs()


def mark_tab_done(tab_index):
    """Mark a tab as completed"""
    tabs = load_tabs()
    if 0 <= tab_index < len(tabs):
        tabs[tab_index]["completed"] = True
        save_tabs(tabs)
        return True
    return False


def set_due_date(tab_index, due_date):
    """Set a due date for a tab"""
    tabs = load_tabs()
    if 0 <= tab_index < len(tabs):
        tabs[tab_index]["due_date"] = due_date
        save_tabs(tabs)
        return True
    return False


def get_stats():
    """Get statistics about tabs"""
    tabs = load_tabs()
    total = len(tabs)
    completed = sum(1 for tab in tabs if tab.get("completed", False))
    pending = total - completed
    with_due_date = sum(1 for tab in tabs if tab.get("due_date"))
    
    return {
        "total": total,
        "completed": completed,
        "pending": pending,
        "with_due_date": with_due_date
    }
