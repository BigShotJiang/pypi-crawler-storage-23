## Description

<!-- Briefly describe your changes -->

## Type of Change

- [ ] Bug fix (non-breaking change that fixes an issue)
- [ ] New feature (non-breaking change that adds functionality)
- [ ] Breaking change (fix or feature that would cause existing functionality to not work as expected)
- [ ] Documentation update
- [ ] Refactoring (no functional changes)

## Component(s) Affected

- [ ] Memory Server (`memory/`)
- [ ] Backend (`backend/`)
- [ ] Frontend (`frontend/`)
- [ ] Hooks (`hooks/`)
- [ ] Docker/Deployment
- [ ] Documentation

## Testing

<!-- Describe the tests you ran -->

- [ ] Existing tests pass (`pytest`)
- [ ] New tests added for changes
- [ ] Manual testing performed

## Checklist

- [ ] My code follows the project's style guidelines
- [ ] I have performed a self-review
- [ ] I have commented hard-to-understand areas
- [ ] I have updated the documentation accordingly
- [ ] My changes generate no new warnings
- [ ] No secrets or credentials are included
