// Fixtures are now Playwright test files that run as setup/teardown projects.
// They are configured in playwright.config.ts and don't need to be exported.
//
// See:
// - django-unfold.setup.ts / django-unfold.teardown.ts
// - django-vanilla.setup.ts / django-vanilla.teardown.ts
// - flask.setup.ts / flask.teardown.ts
// - fastapi.setup.ts / fastapi.teardown.ts
// - starlette.setup.ts / starlette.teardown.ts
