export { BasePage } from "./BasePage.js";
export { ProductListPage } from "./ProductListPage.js";
export { ProductDetailPage } from "./ProductDetailPage.js";
export { AdminPage } from "./AdminPage.js";
