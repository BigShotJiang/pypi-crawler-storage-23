"""Minimal WSGI example application.

This example demonstrates wilco integration with a pure WSGI application,
without using any web framework.
"""
