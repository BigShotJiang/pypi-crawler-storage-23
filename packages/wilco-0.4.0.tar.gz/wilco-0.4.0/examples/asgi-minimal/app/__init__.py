"""Minimal ASGI example application.

This example demonstrates wilco integration with a pure ASGI application,
without using any web framework.
"""
