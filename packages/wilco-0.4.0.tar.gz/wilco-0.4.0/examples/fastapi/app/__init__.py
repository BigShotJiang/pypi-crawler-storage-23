"""FastAPI ecommerce example application."""
