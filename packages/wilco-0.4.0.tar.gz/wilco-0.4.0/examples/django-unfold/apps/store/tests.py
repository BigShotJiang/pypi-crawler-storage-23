"""Tests for the store app."""
