Specifications
==============

Specifications define the contracts and expected behavior for wilco
implementations.

.. toctree::
   :maxdepth: 1

   http-caching
