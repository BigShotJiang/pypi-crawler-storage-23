=========
Reference
=========

Technical reference material for wilco's APIs and specifications.

This section provides detailed, accurate information about wilco's internals,
component format, and JavaScript architecture.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   components
   javascript
