===========
Explanation
===========

Conceptual guides that explain the architecture and design decisions behind wilco.

These documents help you understand *why* things work the way they do.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   standalone-loader
