/**
 * Wilco module - exports utilities for server components.
 * This module is available to server components via window.__MODULES__["wilco"].
 */

export { useComponent } from "./useComponent.ts"
