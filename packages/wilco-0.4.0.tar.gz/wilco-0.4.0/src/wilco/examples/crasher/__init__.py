# Crasher component package - for testing error boundaries
