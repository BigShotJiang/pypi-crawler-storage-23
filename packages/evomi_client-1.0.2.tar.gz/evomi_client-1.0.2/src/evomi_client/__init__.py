"""Evomi Python Client for Web Scraping API.

A production-ready Python client for the Evomi web scraping API.
Provides both synchronous and asynchronous clients.

Example:
    ```python
    # Async usage
    import asyncio
    from evomi_client import EvomiClient
    
    async def main():
        client = EvomiClient(api_key="your-api-key")
        result = await client.scrape("https://example.com")
        print(result)
    
    asyncio.run(main())
    ```
    
    ```python
    # Sync usage
    from evomi_client import EvomiClientSync
    
    client = EvomiClientSync(api_key="your-api-key")
    result = client.scrape("https://example.com")
    print(result)
    ```
"""

from evomi_client.client import (
    EvomiClient,
    EvomiClientSync,
    ProxyType,
    ProxyProtocol,
    ResidentialMode,
    ProxyConfig,
)

__version__ = "1.0.0"
__all__ = [
    "EvomiClient",
    "EvomiClientSync",
    "ProxyType",
    "ProxyProtocol",
    "ResidentialMode",
    "ProxyConfig",
]
