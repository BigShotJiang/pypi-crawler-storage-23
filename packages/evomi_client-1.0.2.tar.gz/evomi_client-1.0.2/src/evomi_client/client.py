"""Evomi API client for web scraping.

This module provides both synchronous and asynchronous clients for the Evomi
web scraping API. Use EvomiClient for async operations or EvomiClientSync
for synchronous operations.

Includes proxy string builder and proxy management utilities.
"""

import os
import re
from typing import Any, Optional
from dataclasses import dataclass, field
from enum import Enum

import httpx


class ProxyType(Enum):
    """Proxy type enumeration."""
    RESIDENTIAL = "residential"
    DATACENTER = "datacenter"
    MOBILE = "mobile"


class ProxyProtocol(Enum):
    """Proxy protocol enumeration."""
    HTTP = "http"
    HTTPS = "https"
    SOCKS5 = "socks5"


class ResidentialMode(Enum):
    """Residential proxy modes."""
    STANDARD = ""
    SPEED = "speed"
    QUALITY = "quality"


@dataclass
class ProxyConfig:
    """Configuration for building proxy strings.
    
    Attributes:
        proxy_type: Type of proxy (residential, datacenter, mobile)
        protocol: Protocol to use (http, https, socks5)
        country: Two-letter country code (e.g., 'US', 'CA')
        city: City name (spaces replaced with dots, lowercase)
        region: State/region name (lowercase)
        continent: Continent name (africa, asia, europe, north.america, oceania, south.america)
        isp: ISP shortcode (e.g., 'att', 'comcast')
        session: Sticky session ID (6-10 alphanumeric chars)
        hardsession: Hard session ID (6-10 alphanumeric chars)
        lifetime: Session duration in minutes (max 120, default 40)
        mode: Residential mode (standard, speed, quality)
        latency: Max latency in ms (expert setting)
        fraudscore: Max fraud score (expert setting)
        device: Device type - windows, unix, apple (expert setting)
        activesince: Min connection minutes (expert setting)
        asn: ASN filter (expert setting)
        zip: Zipcode targeting (expert setting)
        http3: Enable HTTP3/QUIC (expert setting)
        localdns: Local DNS resolution (expert setting)
        udp: UDP support - Enterprise only (expert setting)
        extended: Extended pool - cannot combine with other filters (expert setting)
        username: Proxy username (from Public API)
        password: Proxy password (from Public API)
    """
    proxy_type: ProxyType = ProxyType.RESIDENTIAL
    protocol: ProxyProtocol = ProxyProtocol.HTTP
    country: Optional[str] = None
    city: Optional[str] = None
    region: Optional[str] = None
    continent: Optional[str] = None
    isp: Optional[str] = None
    session: Optional[str] = None
    hardsession: Optional[str] = None
    lifetime: Optional[int] = None
    mode: ResidentialMode = ResidentialMode.STANDARD
    latency: Optional[int] = None
    fraudscore: Optional[int] = None
    device: Optional[str] = None
    activesince: Optional[int] = None
    asn: Optional[str] = None
    zip: Optional[str] = None
    http3: bool = False
    localdns: bool = False
    udp: bool = False
    extended: bool = False
    username: Optional[str] = None
    password: Optional[str] = None
    
    def _get_endpoint_and_port(self) -> tuple[str, int]:
        """Get endpoint and port based on proxy type and protocol."""
        endpoints = {
            ProxyType.RESIDENTIAL: ("rp.evomi.com", 1000, 1001, 1002),
            ProxyType.DATACENTER: ("dcp.evomi.com", 2000, 2001, 2002),
            ProxyType.MOBILE: ("mp.evomi.com", 3000, 3001, 3002),
        }
        endpoint, port_http, port_https, port_socks = endpoints[self.proxy_type]
        if self.protocol == ProxyProtocol.HTTP:
            return endpoint, port_http
        elif self.protocol == ProxyProtocol.HTTPS:
            return endpoint, port_https
        else:  # SOCKS5
            return endpoint, port_socks
    
    def _build_params_string(self) -> str:
        """Build the parameters string for proxy authentication."""
        params = []
        
        # Geographic targeting
        if self.country:
            params.append(f"country-{self.country}")
        if self.city:
            # Replace spaces with dots and lowercase
            city_formatted = self.city.replace(" ", ".").lower()
            params.append(f"city-{city_formatted}")
        if self.region:
            region_formatted = self.region.replace(" ", ".").lower()
            params.append(f"region-{region_formatted}")
        if self.continent:
            continent_formatted = self.continent.replace(" ", ".").lower()
            params.append(f"continent-{continent_formatted}")
        
        # ISP targeting
        if self.isp:
            params.append(f"isp-{self.isp}")
        
        # Session parameters
        if self.session:
            params.append(f"session-{self.session}")
            if self.lifetime and not self.hardsession:
                params.append(f"lifetime-{min(self.lifetime, 120)}")
        if self.hardsession:
            params.append(f"hardsession-{self.hardsession}")
        
        # Residential mode
        if self.mode and self.mode != ResidentialMode.STANDARD:
            params.append(f"mode-{self.mode.value}")
        
        # Expert settings (not for Premium Residential)
        if self.latency:
            params.append(f"latency-{self.latency}")
        if self.fraudscore:
            params.append(f"fraudscore-{self.fraudscore}")
        if self.device:
            params.append(f"device-{self.device}")
        if self.activesince:
            params.append(f"activesince-{self.activesince}")
        if self.asn:
            params.append(f"asn-{self.asn}")
        if self.zip:
            params.append(f"zip-{self.zip}")
        if self.http3:
            params.append("http3-1")
        if self.localdns:
            params.append("localdns-1")
        if self.udp:
            params.append("udp-1")
        if self.extended:
            params.append("extended-1")
        
        return "_".join(params) if params else ""
    
    def build_proxy_string(self) -> str:
        """Build a complete proxy connection string.
        
        Returns:
            Proxy URL in format: protocol://username:password_params@endpoint:port
            
        Example:
            http://user:pass_country-US_session-abc123@rp.evomi.com:1000
        """
        endpoint, port = self._get_endpoint_and_port()
        params = self._build_params_string()
        
        # Build auth string
        if params:
            auth = f"{self.username}:{self.password}_{params}"
        else:
            auth = f"{self.username}:{self.password}"
        
        if self.protocol == ProxyProtocol.SOCKS5:
            return f"socks5h://{auth}@{endpoint}:{port}"
        else:
            return f"{self.protocol.value}://{auth}@{endpoint}:{port}"
    
    def validate(self) -> list[str]:
        """Validate the proxy configuration.
        
        Returns:
            List of validation error messages (empty if valid)
        """
        errors = []
        
        # Validate session ID format
        if self.session and not re.match(r'^[a-zA-Z0-9]{6,10}$', self.session):
            errors.append("Session ID must be 6-10 alphanumeric characters")
        
        if self.hardsession and not re.match(r'^[a-zA-Z0-9]{6,10}$', self.hardsession):
            errors.append("Hardsession ID must be 6-10 alphanumeric characters")
        
        # Validate lifetime
        if self.lifetime and self.lifetime > 120:
            errors.append("Lifetime cannot exceed 120 minutes")
        
        # Validate country code
        if self.country and len(self.country) != 2:
            errors.append("Country must be a 2-letter ISO code")
        
        # Validate expert settings combination
        expert_params = [self.latency, self.fraudscore, self.device, 
                        self.activesince, self.asn, self.zip, self.http3, 
                        self.localdns, self.udp]
        if self.extended and any(expert_params):
            errors.append("Extended pool cannot be combined with other expert filters")
        
        # Validate both session and hardsession not set
        if self.session and self.hardsession:
            errors.append("Cannot use both session and hardsession")
        
        # Validate required credentials
        if not self.username or not self.password:
            errors.append("Username and password are required")
        
        return errors


class EvomiClient:
    """Async HTTP client for Evomi scraper API.
    
    Example:
        ```python
        import asyncio
        from evomi_client import EvomiClient
        
        async def main():
            client = EvomiClient(api_key="your-api-key")
            result = await client.scrape("https://example.com")
            print(result)
        
        asyncio.run(main())
        ```
    """
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        public_api_key: Optional[str] = None,
    ):
        """
        Initialize the Evomi API client.
        
        Args:
            api_key: Evomi API key (defaults to EVOMI_API_KEY env var)
            base_url: API base URL (defaults to EVOMI_BASE_URL env var or https://scrape.evomi.com)
            public_api_key: Evomi Public API key for proxy endpoints (defaults to EVOMI_PUBLIC_API_KEY env var, falls back to api_key)
        
        Raises:
            ValueError: If API key is not provided and EVOMI_API_KEY env var is not set
        """
        self.api_key = api_key or os.getenv("EVOMI_API_KEY")
        self.base_url = base_url or os.getenv("EVOMI_BASE_URL", "https://scrape.evomi.com")
        self.public_api_key = public_api_key or os.getenv("EVOMI_PUBLIC_API_KEY") or self.api_key
        
        if not self.api_key:
            raise ValueError(
                "API key is required. Set EVOMI_API_KEY environment variable or pass api_key parameter."
            )
    
    def _get_headers(self) -> dict[str, str]:
        """Get headers for API requests."""
        return {
            "x-api-key": self.api_key,
            "x-apikey": self.api_key,
            "Content-Type": "application/json",
        }
    
    def _get_public_headers(self) -> dict[str, str]:
        """Get headers for Public API requests."""
        return {
            "x-api-key": self.public_api_key,
            "x-apikey": self.public_api_key,
            "Content-Type": "application/json",
        }
    
    # ─── Scraping Operations ────────────────────────────────────────────────────
    
    async def scrape(
        self,
        url: str,
        mode: str = "auto",
        output: str = "markdown",
        device: str = "windows",
        proxy_type: str = "residential",
        proxy_country: str = "US",
        proxy_session_id: Optional[str] = None,
        wait_until: str = "domcontentloaded",
        ai_enhance: bool = False,
        ai_prompt: Optional[str] = None,
        ai_source: Optional[str] = None,
        ai_force_json: bool = True,
        js_instructions: Optional[list[dict]] = None,
        execute_js: Optional[str] = None,
        block_resources: Optional[list[str]] = None,
        screenshot: bool = False,
        pdf: bool = False,
        wait_seconds: int = 0,
        excluded_tags: Optional[list[str]] = None,
        excluded_selectors: Optional[list[str]] = None,
        additional_headers: Optional[dict[str, str]] = None,
        capture_headers: bool = False,
        network_capture: Optional[list[dict]] = None,
        async_mode: bool = False,
        include_content: bool = True,
        delivery: str = "json",
        config_id: Optional[str] = None,
        scheme_id: Optional[str] = None,
        extract_scheme: Optional[list[dict]] = None,
        storage_id: Optional[str] = None,
        use_default_storage: bool = False,
        no_html: bool = False,
    ) -> dict[str, Any]:
        """
        Scrape a single URL.
        
        Args:
            url: URL to scrape
            mode: Scraping mode - "request" (fast), "browser" (JS), or "auto" (detect)
            output: Output format - "html", "markdown", "screenshot", or "pdf"
            device: Device type - "windows", "macos", or "android"
            proxy_type: Proxy type - "datacenter" or "residential"
            proxy_country: Two-letter country code for proxy
            proxy_session_id: Proxy session ID (6-8 characters)
            wait_until: Wait condition - "load", "domcontentloaded", "networkidle", or "commit"
            ai_enhance: Enable AI enhancement
            ai_prompt: Prompt for AI extraction
            ai_source: Source for AI - "markdown" or "screenshot"
            ai_force_json: Force AI response to be valid JSON (default: True)
            js_instructions: List of JS instructions (click, wait, fill, wait_for)
            execute_js: Raw JavaScript code to execute
            block_resources: Resource types to block (e.g., ["image", "stylesheet"])
            screenshot: Capture screenshot
            pdf: Capture PDF
            wait_seconds: Seconds to wait after page load (0-60)
            excluded_tags: HTML tags to remove before processing
            excluded_selectors: CSS selectors to remove
            additional_headers: Extra HTTP headers to send
            capture_headers: Capture response headers
            network_capture: Network capture filters
            async_mode: Return immediately with task ID
            include_content: Include content in JSON response
            delivery: Response format - "raw" or "json"
            config_id: Saved config ID to use
            scheme_id: Saved extraction schema ID
            extract_scheme: Extraction schema for structured data
            storage_id: Storage config ID for results
            use_default_storage: Use default storage config
            no_html: Exclude HTML from JSON response
        
        Returns:
            Scraping result with content, credits used, etc.
        """
        endpoint = f"{self.base_url}/api/v1/scraper/realtime"
        
        payload: dict[str, Any] = {
            "url": url,
            "mode": mode,
            "content": output,
            "device": device,
            "proxy_type": proxy_type,
            "proxy_country": proxy_country,
            "wait_until": wait_until,
            "ai_enhance": ai_enhance,
            "screenshot": screenshot,
            "pdf": pdf,
            "wait_seconds": wait_seconds,
            "async": async_mode,
            "include_content": include_content,
            "delivery": delivery,
            "capture_headers": capture_headers,
            "use_default_storage": use_default_storage,
            "no_html": no_html,
        }
        
        if proxy_session_id:
            payload["proxy_session_id"] = proxy_session_id
        
        if ai_enhance and ai_prompt:
            payload["ai_prompt"] = ai_prompt
            payload["ai_source"] = ai_source or "markdown"
        elif ai_source:
            payload["ai_source"] = ai_source
        
        if ai_enhance:
            payload["ai_force_json"] = ai_force_json
        
        if js_instructions:
            payload["js_instructions"] = js_instructions
        
        if execute_js:
            payload["execute_js"] = execute_js
        
        if block_resources:
            payload["block_resources"] = block_resources
        
        if excluded_tags:
            payload["excluded_tags"] = excluded_tags
        
        if excluded_selectors:
            payload["excluded_selectors"] = excluded_selectors
        
        if additional_headers:
            payload["additional_headers"] = additional_headers
        
        if network_capture:
            payload["networkCapture"] = network_capture
        
        if config_id:
            payload["config_id"] = config_id
        
        if scheme_id:
            payload["scheme_id"] = scheme_id
        
        if extract_scheme:
            payload["extract_scheme"] = extract_scheme
        
        if storage_id:
            payload["storage_id"] = storage_id
        
        async with httpx.AsyncClient(timeout=120.0) as client:
            response = await client.post(
                endpoint,
                json=payload,
                headers=self._get_headers(),
            )
            
            result = response.json()
            
            # Add headers to result
            result["_credits_used"] = response.headers.get("X-Credits-Used")
            result["_credits_remaining"] = response.headers.get("X-Credits-Remaining")
            result["_mode_used"] = response.headers.get("X-Mode-Used")
            
            return result
    
    async def crawl(
        self,
        domain: str,
        max_urls: int = 100,
        depth: int = 2,
        url_pattern: Optional[str] = None,
        scraper_config: Optional[dict[str, Any]] = None,
        async_mode: bool = False,
    ) -> dict[str, Any]:
        """
        Crawl a website starting from a domain.
        
        Args:
            domain: Domain to crawl (e.g., "example.com")
            max_urls: Maximum URLs to crawl
            depth: Crawl depth
            url_pattern: Regex pattern to filter URLs
            scraper_config: Configuration for scraping each page
            async_mode: Return immediately with task ID
        
        Returns:
            Crawl results with discovered URLs and content
        """
        endpoint = f"{self.base_url}/api/v1/scraper/crawl"
        
        payload: dict[str, Any] = {
            "domain": domain,
            "max_urls": max_urls,
            "depth": depth,
            "async": async_mode,
        }
        
        if url_pattern:
            payload["url_pattern"] = url_pattern
        
        if scraper_config:
            payload["scraper_config"] = scraper_config
        
        async with httpx.AsyncClient(timeout=300.0) as client:
            response = await client.post(
                endpoint,
                json=payload,
                headers=self._get_headers(),
            )
            
            result = response.json()
            result["_credits_used"] = response.headers.get("X-Credits-Used")
            result["_credits_remaining"] = response.headers.get("X-Credits-Remaining")
            
            return result
    
    async def map_website(
        self,
        domain: str,
        sources: Optional[list[str]] = None,
        max_urls: int = 500,
        url_pattern: Optional[str] = None,
        check_if_live: bool = False,
        depth: int = 1,
        async_mode: bool = False,
    ) -> dict[str, Any]:
        """
        Discover URLs from a website.
        
        Args:
            domain: Domain to map
            sources: Discovery sources - "sitemap", "commoncrawl", "crawl"
            max_urls: Maximum URLs to discover
            url_pattern: Regex pattern to filter URLs
            check_if_live: Check if URLs are live
            depth: Crawl depth if using crawl source
            async_mode: Return immediately with task ID
        
        Returns:
            Map results with discovered URLs
        """
        endpoint = f"{self.base_url}/api/v1/scraper/map"
        
        if sources is None:
            sources = ["sitemap", "commoncrawl"]
        
        payload: dict[str, Any] = {
            "domain": domain,
            "sources": sources,
            "max_urls": max_urls,
            "check_if_live": check_if_live,
            "depth": depth,
            "async": async_mode,
        }
        
        if url_pattern:
            payload["url_pattern"] = url_pattern
        
        async with httpx.AsyncClient(timeout=300.0) as client:
            response = await client.post(
                endpoint,
                json=payload,
                headers=self._get_headers(),
            )
            
            result = response.json()
            result["_credits_used"] = response.headers.get("X-Credits-Used")
            result["_credits_remaining"] = response.headers.get("X-Credits-Remaining")
            
            return result
    
    async def search_domains(
        self,
        query: str | list[str],
        max_urls: int = 20,
        region: str = "us-en",
    ) -> dict[str, Any]:
        """
        Find domains by searching the web.
        
        Args:
            query: Search query (string or list of up to 10 queries)
            max_urls: Maximum domains to return per query (default: 20, max: 100)
            region: Region for search results and proxy location (e.g., "us-en", "de-de")
        
        Returns:
            Search results with list of domains, each containing domain, url, and title
        """
        endpoint = f"{self.base_url}/api/v1/scraper/search"
        
        payload: dict[str, Any] = {
            "query": query,
            "max_urls": min(max_urls, 100),
            "region": region,
        }
        
        async with httpx.AsyncClient(timeout=60.0) as client:
            response = await client.post(
                endpoint,
                json=payload,
                headers=self._get_headers(),
            )
            
            result = response.json()
            result["_credits_used"] = response.headers.get("X-Credits-Used")
            result["_credits_remaining"] = response.headers.get("X-Credits-Remaining")
            
            return result
    
    async def agent_request(
        self,
        message: str,
    ) -> dict[str, Any]:
        """
        Send a request to the AI agent for scraping assistance.
        
        Args:
            message: Natural language request for the agent
        
        Returns:
            Agent response with actions taken
        """
        endpoint = f"{self.base_url}/api/v1/agent/request"
        
        payload = {
            "message": message,
        }
        
        async with httpx.AsyncClient(timeout=180.0) as client:
            response = await client.post(
                endpoint,
                json=payload,
                headers=self._get_headers(),
            )
            
            result = response.json()
            result["_credits_used"] = response.headers.get("X-Credits-Used")
            result["_credits_remaining"] = response.headers.get("X-Credits-Remaining")
            
            return result
    
    async def get_task_status(
        self,
        task_id: str,
        task_type: str = "scrape",
    ) -> dict[str, Any]:
        """
        Get the status of an async task.
        
        Args:
            task_id: Task ID to check
            task_type: Type of task - "scrape", "crawl", "map", "config_generate", or "schema"
        
        Returns:
            Task status and results if completed
        """
        if task_type == "crawl":
            endpoint = f"{self.base_url}/api/v1/scraper/crawl/tasks/{task_id}"
        elif task_type == "map":
            endpoint = f"{self.base_url}/api/v1/scraper/map/tasks/{task_id}"
        elif task_type == "config_generate":
            endpoint = f"{self.base_url}/api/v1/account/configs/generate/tasks/{task_id}"
        elif task_type == "schema":
            endpoint = f"{self.base_url}/api/v1/account/schemes/{task_id}/status"
        else:
            endpoint = f"{self.base_url}/api/v1/scraper/tasks/{task_id}"
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(
                endpoint,
                headers=self._get_headers(),
            )
            
            result = response.json()
            result["_credits_used"] = response.headers.get("X-Credits-Used")
            result["_credits_remaining"] = response.headers.get("X-Credits-Remaining")
            
            return result
    
    # ─── Config Management ──────────────────────────────────────────────────────
    
    async def list_configs(
        self,
        page: int = 1,
        per_page: int = 20,
        sort_by: str = "created_at",
        sort_order: str = "desc",
    ) -> dict[str, Any]:
        """List all scrape configs for the authenticated user."""
        endpoint = f"{self.base_url}/api/v1/account/configs"
        
        params = {
            "page": page,
            "per_page": per_page,
            "sort_by": sort_by,
            "sort_order": sort_order,
        }
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(
                endpoint,
                params=params,
                headers=self._get_headers(),
            )
            return response.json()
    
    async def create_config(
        self,
        name: str,
        config: dict[str, Any],
    ) -> dict[str, Any]:
        """Create a new scrape config."""
        endpoint = f"{self.base_url}/api/v1/account/configs"
        
        payload = {
            "name": name,
            "config": config,
        }
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                endpoint,
                json=payload,
                headers=self._get_headers(),
            )
            return response.json()
    
    async def get_config(self, config_id: str) -> dict[str, Any]:
        """Get a single scrape config by ID."""
        endpoint = f"{self.base_url}/api/v1/account/configs/{config_id}"
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(
                endpoint,
                headers=self._get_headers(),
            )
            return response.json()
    
    async def update_config(
        self,
        config_id: str,
        name: Optional[str] = None,
        config: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        """Update an existing scrape config."""
        endpoint = f"{self.base_url}/api/v1/account/configs/{config_id}"
        
        payload = {}
        if name:
            payload["name"] = name
        if config:
            payload["config"] = config
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.put(
                endpoint,
                json=payload,
                headers=self._get_headers(),
            )
            return response.json()
    
    async def delete_config(self, config_id: str) -> dict[str, Any]:
        """Delete a scrape config."""
        endpoint = f"{self.base_url}/api/v1/account/configs/{config_id}"
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.delete(
                endpoint,
                headers=self._get_headers(),
            )
            return response.json()
    
    async def generate_config(
        self,
        name: str,
        prompt: str,
    ) -> dict[str, Any]:
        """Generate a scrape config from a natural language prompt using AI."""
        endpoint = f"{self.base_url}/api/v1/account/configs/generate"
        
        payload = {
            "name": name,
            "prompt": prompt,
        }
        
        async with httpx.AsyncClient(timeout=120.0) as client:
            response = await client.post(
                endpoint,
                json=payload,
                headers=self._get_headers(),
            )
            
            result = response.json()
            result["_credits_used"] = response.headers.get("X-Credits-Used")
            result["_credits_remaining"] = response.headers.get("X-Credits-Remaining")
            
            return result
    
    # ─── Schema Management ──────────────────────────────────────────────────────
    
    async def list_schemas(
        self,
        page: int = 1,
        per_page: int = 20,
        sort_by: str = "created_at",
        sort_order: str = "desc",
    ) -> dict[str, Any]:
        """List all extraction schemas for the authenticated user."""
        endpoint = f"{self.base_url}/api/v1/account/schemes"
        
        params = {
            "page": page,
            "per_page": per_page,
            "sort_by": sort_by,
            "sort_order": sort_order,
        }
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(
                endpoint,
                params=params,
                headers=self._get_headers(),
            )
            return response.json()
    
    async def create_schema(
        self,
        name: str,
        config: dict[str, Any],
        test: bool = False,
        fix: bool = False,
        extract_prompt: Optional[str] = None,
    ) -> dict[str, Any]:
        """Create a new extraction schema."""
        endpoint = f"{self.base_url}/api/v1/account/schemes"
        
        payload = {
            "name": name,
            "config": config,
            "test": test,
            "fix": fix,
        }
        
        if extract_prompt:
            payload["extract_prompt"] = extract_prompt
        
        async with httpx.AsyncClient(timeout=120.0) as client:
            response = await client.post(
                endpoint,
                json=payload,
                headers=self._get_headers(),
            )
            
            result = response.json()
            result["_credits_used"] = response.headers.get("X-Credits-Used")
            result["_credits_remaining"] = response.headers.get("X-Credits-Remaining")
            
            return result
    
    async def get_schema(self, scheme_id: str) -> dict[str, Any]:
        """Get a single extraction schema by ID."""
        endpoint = f"{self.base_url}/api/v1/account/schemes/{scheme_id}"
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(
                endpoint,
                headers=self._get_headers(),
            )
            return response.json()
    
    async def update_schema(
        self,
        scheme_id: str,
        name: str,
        config: dict[str, Any],
        test: bool = False,
        fix: bool = False,
        extract_prompt: Optional[str] = None,
    ) -> dict[str, Any]:
        """Update an existing extraction schema."""
        endpoint = f"{self.base_url}/api/v1/account/schemes/{scheme_id}"
        
        payload = {
            "name": name,
            "config": config,
            "test": test,
            "fix": fix,
        }
        
        if extract_prompt:
            payload["extract_prompt"] = extract_prompt
        
        async with httpx.AsyncClient(timeout=120.0) as client:
            response = await client.put(
                endpoint,
                json=payload,
                headers=self._get_headers(),
            )
            
            result = response.json()
            result["_credits_used"] = response.headers.get("X-Credits-Used")
            result["_credits_remaining"] = response.headers.get("X-Credits-Remaining")
            
            return result
    
    async def delete_schema(self, scheme_id: str) -> dict[str, Any]:
        """Delete an extraction schema."""
        endpoint = f"{self.base_url}/api/v1/account/schemes/{scheme_id}"
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.delete(
                endpoint,
                headers=self._get_headers(),
            )
            return response.json()
    
    async def get_schema_status(self, scheme_id: str) -> dict[str, Any]:
        """Get status of schema test."""
        endpoint = f"{self.base_url}/api/v1/account/schemes/{scheme_id}/status"
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(
                endpoint,
                headers=self._get_headers(),
            )
            return response.json()
    
    # ─── Storage Management ─────────────────────────────────────────────────────
    
    async def list_storage_configs(self) -> list[dict[str, Any]]:
        """List all storage configurations for the authenticated user."""
        endpoint = f"{self.base_url}/api/v1/account/storage"
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(
                endpoint,
                headers=self._get_headers(),
            )
            return response.json()
    
    async def create_storage_config(
        self,
        name: str,
        storage_type: str,
        config: dict[str, Any],
        set_as_default: bool = False,
    ) -> dict[str, Any]:
        """Create a new storage configuration."""
        endpoint = f"{self.base_url}/api/v1/account/storage"
        
        payload = {
            "name": name,
            "storage_type": storage_type,
            "config": config,
            "set_as_default": set_as_default,
        }
        
        async with httpx.AsyncClient(timeout=60.0) as client:
            response = await client.post(
                endpoint,
                json=payload,
                headers=self._get_headers(),
            )
            return response.json()
    
    async def update_storage_config(
        self,
        storage_id: str,
        name: Optional[str] = None,
        config: Optional[dict[str, Any]] = None,
        set_as_default: Optional[bool] = None,
    ) -> dict[str, Any]:
        """Update an existing storage configuration."""
        endpoint = f"{self.base_url}/api/v1/account/storage/{storage_id}"
        
        payload = {}
        if name:
            payload["name"] = name
        if config:
            payload["config"] = config
        if set_as_default is not None:
            payload["set_as_default"] = set_as_default
        
        async with httpx.AsyncClient(timeout=60.0) as client:
            response = await client.put(
                endpoint,
                json=payload,
                headers=self._get_headers(),
            )
            return response.json()
    
    async def delete_storage_config(self, storage_id: str) -> dict[str, Any]:
        """Delete a storage configuration."""
        endpoint = f"{self.base_url}/api/v1/account/storage/{storage_id}"
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.delete(
                endpoint,
                headers=self._get_headers(),
            )
            return response.json()
    
    # ─── Public API ──────────────────────────────────────────────────────────────
    
    async def get_public_api(self) -> dict[str, Any]:
        """
        Access the Evomi Public API to get proxy credentials and related data.
        
        Returns:
            Public API data
        """
        endpoint = "https://api.evomi.com/public"
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(
                endpoint,
                headers=self._get_public_headers(),
            )
            return response.json()

    async def get_proxy_data(self) -> dict[str, Any]:
        """
        Get detailed information about your proxy products.
        
        Returns:
            Proxy data including credentials, balance, and endpoints
        """
        endpoint = "https://api.evomi.com/public"
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(
                endpoint,
                headers=self._get_public_headers(),
            )
            return response.json()

    async def get_targeting_options(self) -> dict[str, Any]:
        """
        Get available targeting parameters for different proxy types.
        
        Returns:
            Targeting options data
        """
        endpoint = "https://api.evomi.com/public/settings"
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(
                endpoint,
                headers=self._get_public_headers(),
            )
            return response.json()

    async def get_scraper_data(self) -> dict[str, Any]:
        """
        Get information about your Scraper API access.
        
        Returns:
            Scraper API data including credits and concurrency limit
        """
        endpoint = "https://api.evomi.com/public/scraper"
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(
                endpoint,
                headers=self._get_public_headers(),
            )
            return response.json()

    async def get_browser_data(self) -> dict[str, Any]:
        """
        Get information about your Browser API access.
        
        Returns:
            Browser API data including credits, concurrency limit, and endpoint
        """
        endpoint = "https://api.evomi.com/public/browser"
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(
                endpoint,
                headers=self._get_public_headers(),
            )
            return response.json()

    async def rotate_session(self, session_id: str, product: str) -> dict[str, Any]:
        """
        Force an IP address change for an existing proxy session.
        
        Args:
            session_id: Current session identifier
            product: Proxy product type (rpc, rp, sdc, mp)
            
        Returns:
            Session rotation status
        """
        endpoint = "https://api.evomi.com/public/rotate_session"
        
        params = {
            "sessionid": session_id,
            "product": product,
        }
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(
                endpoint,
                params=params,
                headers=self._get_public_headers(),
            )
            return response.json()

    async def generate_proxies(
        self,
        product: str,
        countries: Optional[str] = None,
        city: Optional[str] = None,
        region: Optional[str] = None,
        isp: Optional[str] = None,
        session: Optional[str] = None,
        amount: Optional[int] = None,
        format: Optional[str] = None,
        prepend_protocol: Optional[bool] = None,
        protocol: Optional[str] = None,
        lifetime: Optional[int] = None,
        adblock: Optional[bool] = None,
    ) -> str:
        """
        Automatically generate proxy strings with specific targeting parameters and connection preferences.
        
        Args:
            product: Proxy product type
            countries: ISO country codes separated by comma
            city: Target city name
            region: Target region
            isp: Target ISP name
            session: sticky or hard
            amount: Number of proxies to generate (1-100)
            format: Output format (1, 2, or 3)
            prepend_protocol: Set to false to prevent protocol prepend
            protocol: http or socks5
            lifetime: Session duration in minutes
            adblock: Enable ad-blocking
            
        Returns:
            Generated proxies as a plain string, one per line
        """
        endpoint = "https://api.evomi.com/public/generate"
        
        params: dict[str, Any] = {"product": product}
        if countries is not None:
            params["countries"] = countries
        if city is not None:
            params["city"] = city
        if region is not None:
            params["region"] = region
        if isp is not None:
            params["isp"] = isp
        if session is not None:
            params["session"] = session
        if amount is not None:
            params["amount"] = amount
        if format is not None:
            params["format"] = format
        if prepend_protocol is not None:
            params["prepend_protocol"] = str(prepend_protocol).lower()
        if protocol is not None:
            params["protocol"] = protocol
        if lifetime is not None:
            params["lifetime"] = lifetime
        if adblock is not None:
            params["adblock"] = str(adblock).lower()
            
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(
                endpoint,
                params=params,
                headers=self._get_public_headers(),
            )
            
            if response.status_code >= 400:
                try:
                    err_data = response.json()
                    raise Exception(f"API Error: {err_data}")
                except Exception as e:
                    if not isinstance(e, Exception) or not str(e).startswith("API Error"):
                        raise Exception(f"API Error: {response.text}")
                    raise
                    
            return response.text
    
    # ─── Account Info ────────────────────────────────────────────────────────────
    
    async def get_account_info(self) -> dict[str, Any]:
        """Get user's account info including credit balance."""
        endpoint = f"{self.base_url}/api/v1/scraper/health"
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(
                endpoint,
                headers=self._get_headers(),
            )
            return response.json()
    
    # ─── Schedule Management ────────────────────────────────────────────────────
    
    async def list_schedules(
        self,
        page: int = 1,
        per_page: int = 20,
        active_only: bool = False,
    ) -> dict[str, Any]:
        """List all scheduled jobs for the authenticated user."""
        endpoint = f"{self.base_url}/api/v1/account/schedule"
        
        params = {
            "page": page,
            "per_page": per_page,
            "active_only": str(active_only).lower(),
        }
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(
                endpoint,
                params=params,
                headers=self._get_headers(),
            )
            return response.json()
    
    async def create_schedule(
        self,
        name: str,
        config_id: str,
        interval_minutes: int,
        start_time: Optional[str] = None,
        stop_on_error: bool = True,
    ) -> dict[str, Any]:
        """Create a new scheduled scrape job."""
        endpoint = f"{self.base_url}/api/v1/account/schedule"
        
        payload = {
            "name": name,
            "config_id": config_id,
            "interval_minutes": interval_minutes,
            "stop_on_error": stop_on_error,
        }
        
        if start_time:
            payload["start_time"] = start_time
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                endpoint,
                json=payload,
                headers=self._get_headers(),
            )
            return response.json()
    
    async def get_schedule(self, schedule_id: str) -> dict[str, Any]:
        """Get a single scheduled job by ID."""
        endpoint = f"{self.base_url}/api/v1/account/schedule/{schedule_id}"
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(
                endpoint,
                headers=self._get_headers(),
            )
            return response.json()
    
    async def update_schedule(
        self,
        schedule_id: str,
        name: Optional[str] = None,
        config_id: Optional[str] = None,
        interval_minutes: Optional[int] = None,
        stop_on_error: Optional[bool] = None,
    ) -> dict[str, Any]:
        """Update an existing scheduled job."""
        endpoint = f"{self.base_url}/api/v1/account/schedule/{schedule_id}"
        
        payload = {}
        if name:
            payload["name"] = name
        if config_id:
            payload["config_id"] = config_id
        if interval_minutes:
            payload["interval_minutes"] = interval_minutes
        if stop_on_error is not None:
            payload["stop_on_error"] = stop_on_error
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.put(
                endpoint,
                json=payload,
                headers=self._get_headers(),
            )
            return response.json()
    
    async def delete_schedule(self, schedule_id: str) -> dict[str, Any]:
        """Delete a scheduled job."""
        endpoint = f"{self.base_url}/api/v1/account/schedule/{schedule_id}"
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.delete(
                endpoint,
                headers=self._get_headers(),
            )
            return response.json()
    
    async def toggle_schedule(self, schedule_id: str) -> dict[str, Any]:
        """Toggle a scheduled job active/inactive."""
        endpoint = f"{self.base_url}/api/v1/account/schedule/{schedule_id}/toggle"
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                endpoint,
                headers=self._get_headers(),
            )
            return response.json()
    
    async def list_schedule_runs(
        self,
        schedule_id: str,
        page: int = 1,
        per_page: int = 20,
    ) -> dict[str, Any]:
        """Get execution history for a scheduled job."""
        endpoint = f"{self.base_url}/api/v1/account/schedule/{schedule_id}/runs"
        
        params = {
            "page": page,
            "per_page": per_page,
        }
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(
                endpoint,
                params=params,
                headers=self._get_headers(),
            )
            return response.json()

    # ─── Proxy Helpers ──────────────────────────────────────────────────────────

    async def build_proxy_config(
        self,
        proxy_type: ProxyType = ProxyType.RESIDENTIAL,
        protocol: ProxyProtocol = ProxyProtocol.HTTP,
        country: Optional[str] = None,
        city: Optional[str] = None,
        region: Optional[str] = None,
        continent: Optional[str] = None,
        isp: Optional[str] = None,
        session: Optional[str] = None,
        hardsession: Optional[str] = None,
        lifetime: Optional[int] = None,
        mode: ResidentialMode = ResidentialMode.STANDARD,
        latency: Optional[int] = None,
        fraudscore: Optional[int] = None,
        device: Optional[str] = None,
        activesince: Optional[int] = None,
        asn: Optional[str] = None,
        zip: Optional[str] = None,
        http3: bool = False,
        localdns: bool = False,
        udp: bool = False,
        extended: bool = False,
    ) -> ProxyConfig:
        """
        Build a proxy configuration with credentials from the Public API.
        
        Args:
            proxy_type: Type of proxy
            protocol: Protocol to use
            country: Two-letter country code
            city: City name
            region: State/region name
            continent: Continent name
            isp: ISP shortcode
            session: Sticky session ID
            hardsession: Hard session ID
            lifetime: Session duration in minutes
            mode: Residential mode
            latency: Max latency (expert)
            fraudscore: Max fraud score (expert)
            device: Device type (expert)
            activesince: Min connection minutes (expert)
            asn: ASN filter (expert)
            zip: Zipcode targeting (expert)
            http3: Enable HTTP3/QUIC (expert)
            localdns: Local DNS resolution (expert)
            udp: UDP support (expert)
            extended: Extended pool (expert)
        
        Returns:
            Configured ProxyConfig instance
        """
        proxy_data = await self.get_proxy_data()
        
        # Extract credentials based on proxy type
        product_data = proxy_data.get("products", {})
        if proxy_type == ProxyType.RESIDENTIAL:
            creds = product_data.get("rp", product_data.get("residential", {}))
        elif proxy_type == ProxyType.DATACENTER:
            creds = product_data.get("sdc", product_data.get("datacenter", {}))
        else:  # MOBILE
            creds = product_data.get("mp", product_data.get("mobile", {}))
        
        username = creds.get("username", "")
        password = creds.get("password", "")
        
        config = ProxyConfig(
            proxy_type=proxy_type,
            protocol=protocol,
            country=country,
            city=city,
            region=region,
            continent=continent,
            isp=isp,
            session=session,
            hardsession=hardsession,
            lifetime=lifetime,
            mode=mode,
            latency=latency,
            fraudscore=fraudscore,
            device=device,
            activesince=activesince,
            asn=asn,
            zip=zip,
            http3=http3,
            localdns=localdns,
            udp=udp,
            extended=extended,
            username=username,
            password=password,
        )
        
        return config

    async def build_proxy_string(
        self,
        proxy_type: ProxyType = ProxyType.RESIDENTIAL,
        protocol: ProxyProtocol = ProxyProtocol.HTTP,
        country: Optional[str] = None,
        city: Optional[str] = None,
        region: Optional[str] = None,
        continent: Optional[str] = None,
        isp: Optional[str] = None,
        session: Optional[str] = None,
        hardsession: Optional[str] = None,
        lifetime: Optional[int] = None,
        mode: ResidentialMode = ResidentialMode.STANDARD,
        **kwargs
    ) -> str:
        """
        Build a proxy connection string directly.
        
        Args:
            Same as build_proxy_config()
        
        Returns:
            Proxy URL string (e.g., http://user:pass_country-US@rp.evomi.com:1000)
        """
        config = await self.build_proxy_config(
            proxy_type=proxy_type,
            protocol=protocol,
            country=country,
            city=city,
            region=region,
            continent=continent,
            isp=isp,
            session=session,
            hardsession=hardsession,
            lifetime=lifetime,
            mode=mode,
            **kwargs
        )
        return config.build_proxy_string()


class EvomiClientSync:
    """Synchronous HTTP client for Evomi scraper API.
    
    Example:
        ```python
        from evomi_client import EvomiClientSync
        
        client = EvomiClientSync(api_key="your-api-key")
        result = client.scrape("https://example.com")
        print(result)
        ```
    """
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        public_api_key: Optional[str] = None,
    ):
        """
        Initialize the Evomi API client.
        
        Args:
            api_key: Evomi API key (defaults to EVOMI_API_KEY env var)
            base_url: API base URL (defaults to EVOMI_BASE_URL env var or https://scrape.evomi.com)
            public_api_key: Evomi Public API key for proxy endpoints (defaults to EVOMI_PUBLIC_API_KEY env var, falls back to api_key)
        
        Raises:
            ValueError: If API key is not provided and EVOMI_API_KEY env var is not set
        """
        self.api_key = api_key or os.getenv("EVOMI_API_KEY")
        self.base_url = base_url or os.getenv("EVOMI_BASE_URL", "https://scrape.evomi.com")
        self.public_api_key = public_api_key or os.getenv("EVOMI_PUBLIC_API_KEY") or self.api_key
        
        if not self.api_key:
            raise ValueError(
                "API key is required. Set EVOMI_API_KEY environment variable or pass api_key parameter."
            )
    
    def _get_headers(self) -> dict[str, str]:
        """Get headers for API requests."""
        return {
            "x-api-key": self.api_key,
            "x-apikey": self.api_key,
            "Content-Type": "application/json",
        }
    
    def _get_public_headers(self) -> dict[str, str]:
        """Get headers for Public API requests."""
        return {
            "x-api-key": self.public_api_key,
            "x-apikey": self.public_api_key,
            "Content-Type": "application/json",
        }
    
    # ─── Scraping Operations ────────────────────────────────────────────────────
    
    def scrape(
        self,
        url: str,
        mode: str = "auto",
        output: str = "markdown",
        device: str = "windows",
        proxy_type: str = "residential",
        proxy_country: str = "US",
        proxy_session_id: Optional[str] = None,
        wait_until: str = "domcontentloaded",
        ai_enhance: bool = False,
        ai_prompt: Optional[str] = None,
        ai_source: Optional[str] = None,
        ai_force_json: bool = True,
        js_instructions: Optional[list[dict]] = None,
        execute_js: Optional[str] = None,
        block_resources: Optional[list[str]] = None,
        screenshot: bool = False,
        pdf: bool = False,
        wait_seconds: int = 0,
        excluded_tags: Optional[list[str]] = None,
        excluded_selectors: Optional[list[str]] = None,
        additional_headers: Optional[dict[str, str]] = None,
        capture_headers: bool = False,
        network_capture: Optional[list[dict]] = None,
        async_mode: bool = False,
        include_content: bool = True,
        delivery: str = "json",
        config_id: Optional[str] = None,
        scheme_id: Optional[str] = None,
        extract_scheme: Optional[list[dict]] = None,
        storage_id: Optional[str] = None,
        use_default_storage: bool = False,
        no_html: bool = False,
    ) -> dict[str, Any]:
        """
        Scrape a single URL (synchronous).
        
        See EvomiClient.scrape() for full parameter documentation.
        """
        endpoint = f"{self.base_url}/api/v1/scraper/realtime"
        
        payload: dict[str, Any] = {
            "url": url,
            "mode": mode,
            "content": output,
            "device": device,
            "proxy_type": proxy_type,
            "proxy_country": proxy_country,
            "wait_until": wait_until,
            "ai_enhance": ai_enhance,
            "screenshot": screenshot,
            "pdf": pdf,
            "wait_seconds": wait_seconds,
            "async": async_mode,
            "include_content": include_content,
            "delivery": delivery,
            "capture_headers": capture_headers,
            "use_default_storage": use_default_storage,
            "no_html": no_html,
        }
        
        if proxy_session_id:
            payload["proxy_session_id"] = proxy_session_id
        if ai_enhance and ai_prompt:
            payload["ai_prompt"] = ai_prompt
            payload["ai_source"] = ai_source or "markdown"
        elif ai_source:
            payload["ai_source"] = ai_source
        if ai_enhance:
            payload["ai_force_json"] = ai_force_json
        if js_instructions:
            payload["js_instructions"] = js_instructions
        if execute_js:
            payload["execute_js"] = execute_js
        if block_resources:
            payload["block_resources"] = block_resources
        if excluded_tags:
            payload["excluded_tags"] = excluded_tags
        if excluded_selectors:
            payload["excluded_selectors"] = excluded_selectors
        if additional_headers:
            payload["additional_headers"] = additional_headers
        if network_capture:
            payload["networkCapture"] = network_capture
        if config_id:
            payload["config_id"] = config_id
        if scheme_id:
            payload["scheme_id"] = scheme_id
        if extract_scheme:
            payload["extract_scheme"] = extract_scheme
        if storage_id:
            payload["storage_id"] = storage_id
        
        with httpx.Client(timeout=120.0) as client:
            response = client.post(
                endpoint,
                json=payload,
                headers=self._get_headers(),
            )
            
            result = response.json()
            result["_credits_used"] = response.headers.get("X-Credits-Used")
            result["_credits_remaining"] = response.headers.get("X-Credits-Remaining")
            result["_mode_used"] = response.headers.get("X-Mode-Used")
            
            return result
    
    def crawl(
        self,
        domain: str,
        max_urls: int = 100,
        depth: int = 2,
        url_pattern: Optional[str] = None,
        scraper_config: Optional[dict[str, Any]] = None,
        async_mode: bool = False,
    ) -> dict[str, Any]:
        """Crawl a website (synchronous). See EvomiClient.crawl() for docs."""
        endpoint = f"{self.base_url}/api/v1/scraper/crawl"
        
        payload: dict[str, Any] = {
            "domain": domain,
            "max_urls": max_urls,
            "depth": depth,
            "async": async_mode,
        }
        
        if url_pattern:
            payload["url_pattern"] = url_pattern
        if scraper_config:
            payload["scraper_config"] = scraper_config
        
        with httpx.Client(timeout=300.0) as client:
            response = client.post(
                endpoint,
                json=payload,
                headers=self._get_headers(),
            )
            
            result = response.json()
            result["_credits_used"] = response.headers.get("X-Credits-Used")
            result["_credits_remaining"] = response.headers.get("X-Credits-Remaining")
            
            return result
    
    def map_website(
        self,
        domain: str,
        sources: Optional[list[str]] = None,
        max_urls: int = 500,
        url_pattern: Optional[str] = None,
        check_if_live: bool = False,
        depth: int = 1,
        async_mode: bool = False,
    ) -> dict[str, Any]:
        """Discover URLs from a website (synchronous). See EvomiClient.map_website() for docs."""
        endpoint = f"{self.base_url}/api/v1/scraper/map"
        
        if sources is None:
            sources = ["sitemap", "commoncrawl"]
        
        payload: dict[str, Any] = {
            "domain": domain,
            "sources": sources,
            "max_urls": max_urls,
            "check_if_live": check_if_live,
            "depth": depth,
            "async": async_mode,
        }
        
        if url_pattern:
            payload["url_pattern"] = url_pattern
        
        with httpx.Client(timeout=300.0) as client:
            response = client.post(
                endpoint,
                json=payload,
                headers=self._get_headers(),
            )
            
            result = response.json()
            result["_credits_used"] = response.headers.get("X-Credits-Used")
            result["_credits_remaining"] = response.headers.get("X-Credits-Remaining")
            
            return result
    
    def search_domains(
        self,
        query: str | list[str],
        max_urls: int = 20,
        region: str = "us-en",
    ) -> dict[str, Any]:
        """Find domains by searching the web (synchronous). See EvomiClient.search_domains() for docs."""
        endpoint = f"{self.base_url}/api/v1/scraper/search"
        
        payload: dict[str, Any] = {
            "query": query,
            "max_urls": min(max_urls, 100),
            "region": region,
        }
        
        with httpx.Client(timeout=60.0) as client:
            response = client.post(
                endpoint,
                json=payload,
                headers=self._get_headers(),
            )
            
            result = response.json()
            result["_credits_used"] = response.headers.get("X-Credits-Used")
            result["_credits_remaining"] = response.headers.get("X-Credits-Remaining")
            
            return result
    
    def agent_request(self, message: str) -> dict[str, Any]:
        """Send a request to the AI agent (synchronous). See EvomiClient.agent_request() for docs."""
        endpoint = f"{self.base_url}/api/v1/agent/request"
        
        with httpx.Client(timeout=180.0) as client:
            response = client.post(
                endpoint,
                json={"message": message},
                headers=self._get_headers(),
            )
            
            result = response.json()
            result["_credits_used"] = response.headers.get("X-Credits-Used")
            result["_credits_remaining"] = response.headers.get("X-Credits-Remaining")
            
            return result
    
    def get_task_status(
        self,
        task_id: str,
        task_type: str = "scrape",
    ) -> dict[str, Any]:
        """Get the status of an async task (synchronous). See EvomiClient.get_task_status() for docs."""
        if task_type == "crawl":
            endpoint = f"{self.base_url}/api/v1/scraper/crawl/tasks/{task_id}"
        elif task_type == "map":
            endpoint = f"{self.base_url}/api/v1/scraper/map/tasks/{task_id}"
        elif task_type == "config_generate":
            endpoint = f"{self.base_url}/api/v1/account/configs/generate/tasks/{task_id}"
        elif task_type == "schema":
            endpoint = f"{self.base_url}/api/v1/account/schemes/{task_id}/status"
        else:
            endpoint = f"{self.base_url}/api/v1/scraper/tasks/{task_id}"
        
        with httpx.Client(timeout=30.0) as client:
            response = client.get(
                endpoint,
                headers=self._get_headers(),
            )
            
            result = response.json()
            result["_credits_used"] = response.headers.get("X-Credits-Used")
            result["_credits_remaining"] = response.headers.get("X-Credits-Remaining")
            
            return result
    
    # ─── Config Management ──────────────────────────────────────────────────────
    
    def list_configs(
        self,
        page: int = 1,
        per_page: int = 20,
        sort_by: str = "created_at",
        sort_order: str = "desc",
    ) -> dict[str, Any]:
        """List all scrape configs (synchronous)."""
        endpoint = f"{self.base_url}/api/v1/account/configs"
        
        with httpx.Client(timeout=30.0) as client:
            response = client.get(
                endpoint,
                params={"page": page, "per_page": per_page, "sort_by": sort_by, "sort_order": sort_order},
                headers=self._get_headers(),
            )
            return response.json()
    
    def create_config(self, name: str, config: dict[str, Any]) -> dict[str, Any]:
        """Create a new scrape config (synchronous)."""
        endpoint = f"{self.base_url}/api/v1/account/configs"
        
        with httpx.Client(timeout=30.0) as client:
            response = client.post(
                endpoint,
                json={"name": name, "config": config},
                headers=self._get_headers(),
            )
            return response.json()
    
    def get_config(self, config_id: str) -> dict[str, Any]:
        """Get a scrape config by ID (synchronous)."""
        endpoint = f"{self.base_url}/api/v1/account/configs/{config_id}"
        
        with httpx.Client(timeout=30.0) as client:
            response = client.get(endpoint, headers=self._get_headers())
            return response.json()
    
    def update_config(
        self,
        config_id: str,
        name: Optional[str] = None,
        config: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        """Update a scrape config (synchronous)."""
        endpoint = f"{self.base_url}/api/v1/account/configs/{config_id}"
        
        payload = {}
        if name:
            payload["name"] = name
        if config:
            payload["config"] = config
        
        with httpx.Client(timeout=30.0) as client:
            response = client.put(endpoint, json=payload, headers=self._get_headers())
            return response.json()
    
    def delete_config(self, config_id: str) -> dict[str, Any]:
        """Delete a scrape config (synchronous)."""
        endpoint = f"{self.base_url}/api/v1/account/configs/{config_id}"
        
        with httpx.Client(timeout=30.0) as client:
            response = client.delete(endpoint, headers=self._get_headers())
            return response.json()
    
    def generate_config(self, name: str, prompt: str) -> dict[str, Any]:
        """Generate a scrape config from natural language (synchronous)."""
        endpoint = f"{self.base_url}/api/v1/account/configs/generate"
        
        with httpx.Client(timeout=120.0) as client:
            response = client.post(
                endpoint,
                json={"name": name, "prompt": prompt},
                headers=self._get_headers(),
            )
            
            result = response.json()
            result["_credits_used"] = response.headers.get("X-Credits-Used")
            result["_credits_remaining"] = response.headers.get("X-Credits-Remaining")
            
            return result
    
    # ─── Schema Management ──────────────────────────────────────────────────────
    
    def list_schemas(
        self,
        page: int = 1,
        per_page: int = 20,
        sort_by: str = "created_at",
        sort_order: str = "desc",
    ) -> dict[str, Any]:
        """List all extraction schemas (synchronous)."""
        endpoint = f"{self.base_url}/api/v1/account/schemes"
        
        with httpx.Client(timeout=30.0) as client:
            response = client.get(
                endpoint,
                params={"page": page, "per_page": per_page, "sort_by": sort_by, "sort_order": sort_order},
                headers=self._get_headers(),
            )
            return response.json()
    
    def create_schema(
        self,
        name: str,
        config: dict[str, Any],
        test: bool = False,
        fix: bool = False,
        extract_prompt: Optional[str] = None,
    ) -> dict[str, Any]:
        """Create a new extraction schema (synchronous)."""
        endpoint = f"{self.base_url}/api/v1/account/schemes"
        
        payload = {"name": name, "config": config, "test": test, "fix": fix}
        if extract_prompt:
            payload["extract_prompt"] = extract_prompt
        
        with httpx.Client(timeout=120.0) as client:
            response = client.post(endpoint, json=payload, headers=self._get_headers())
            
            result = response.json()
            result["_credits_used"] = response.headers.get("X-Credits-Used")
            result["_credits_remaining"] = response.headers.get("X-Credits-Remaining")
            
            return result
    
    def get_schema(self, scheme_id: str) -> dict[str, Any]:
        """Get an extraction schema by ID (synchronous)."""
        endpoint = f"{self.base_url}/api/v1/account/schemes/{scheme_id}"
        
        with httpx.Client(timeout=30.0) as client:
            response = client.get(endpoint, headers=self._get_headers())
            return response.json()
    
    def update_schema(
        self,
        scheme_id: str,
        name: str,
        config: dict[str, Any],
        test: bool = False,
        fix: bool = False,
        extract_prompt: Optional[str] = None,
    ) -> dict[str, Any]:
        """Update an extraction schema (synchronous)."""
        endpoint = f"{self.base_url}/api/v1/account/schemes/{scheme_id}"
        
        payload = {"name": name, "config": config, "test": test, "fix": fix}
        if extract_prompt:
            payload["extract_prompt"] = extract_prompt
        
        with httpx.Client(timeout=120.0) as client:
            response = client.put(endpoint, json=payload, headers=self._get_headers())
            
            result = response.json()
            result["_credits_used"] = response.headers.get("X-Credits-Used")
            result["_credits_remaining"] = response.headers.get("X-Credits-Remaining")
            
            return result
    
    def delete_schema(self, scheme_id: str) -> dict[str, Any]:
        """Delete an extraction schema (synchronous)."""
        endpoint = f"{self.base_url}/api/v1/account/schemes/{scheme_id}"
        
        with httpx.Client(timeout=30.0) as client:
            response = client.delete(endpoint, headers=self._get_headers())
            return response.json()
    
    def get_schema_status(self, scheme_id: str) -> dict[str, Any]:
        """Get status of schema test (synchronous)."""
        endpoint = f"{self.base_url}/api/v1/account/schemes/{scheme_id}/status"
        
        with httpx.Client(timeout=30.0) as client:
            response = client.get(endpoint, headers=self._get_headers())
            return response.json()
    
    # ─── Storage Management ─────────────────────────────────────────────────────
    
    def list_storage_configs(self) -> list[dict[str, Any]]:
        """List all storage configurations (synchronous)."""
        endpoint = f"{self.base_url}/api/v1/account/storage"
        
        with httpx.Client(timeout=30.0) as client:
            response = client.get(endpoint, headers=self._get_headers())
            return response.json()
    
    def create_storage_config(
        self,
        name: str,
        storage_type: str,
        config: dict[str, Any],
        set_as_default: bool = False,
    ) -> dict[str, Any]:
        """Create a storage configuration (synchronous)."""
        endpoint = f"{self.base_url}/api/v1/account/storage"
        
        with httpx.Client(timeout=60.0) as client:
            response = client.post(
                endpoint,
                json={"name": name, "storage_type": storage_type, "config": config, "set_as_default": set_as_default},
                headers=self._get_headers(),
            )
            return response.json()
    
    def update_storage_config(
        self,
        storage_id: str,
        name: Optional[str] = None,
        config: Optional[dict[str, Any]] = None,
        set_as_default: Optional[bool] = None,
    ) -> dict[str, Any]:
        """Update a storage configuration (synchronous)."""
        endpoint = f"{self.base_url}/api/v1/account/storage/{storage_id}"
        
        payload = {}
        if name:
            payload["name"] = name
        if config:
            payload["config"] = config
        if set_as_default is not None:
            payload["set_as_default"] = set_as_default
        
        with httpx.Client(timeout=60.0) as client:
            response = client.put(endpoint, json=payload, headers=self._get_headers())
            return response.json()
    
    def delete_storage_config(self, storage_id: str) -> dict[str, Any]:
        """Delete a storage configuration (synchronous)."""
        endpoint = f"{self.base_url}/api/v1/account/storage/{storage_id}"
        
        with httpx.Client(timeout=30.0) as client:
            response = client.delete(endpoint, headers=self._get_headers())
            return response.json()
    
    # ─── Public API ──────────────────────────────────────────────────────────────
    
    def get_public_api(self) -> dict[str, Any]:
        """Access the Evomi Public API (synchronous)."""
        endpoint = "https://api.evomi.com/public"
        
        with httpx.Client(timeout=30.0) as client:
            response = client.get(
                endpoint,
                headers=self._get_public_headers(),
            )
            return response.json()

    def get_proxy_data(self) -> dict[str, Any]:
        """Get detailed information about your proxy products (synchronous)."""
        endpoint = "https://api.evomi.com/public"
        
        with httpx.Client(timeout=30.0) as client:
            response = client.get(
                endpoint,
                headers=self._get_public_headers(),
            )
            return response.json()

    def get_targeting_options(self) -> dict[str, Any]:
        """Get available targeting parameters for different proxy types (synchronous)."""
        endpoint = "https://api.evomi.com/public/settings"
        
        with httpx.Client(timeout=30.0) as client:
            response = client.get(
                endpoint,
                headers=self._get_public_headers(),
            )
            return response.json()

    def get_scraper_data(self) -> dict[str, Any]:
        """Get information about your Scraper API access (synchronous)."""
        endpoint = "https://api.evomi.com/public/scraper"
        
        with httpx.Client(timeout=30.0) as client:
            response = client.get(
                endpoint,
                headers=self._get_public_headers(),
            )
            return response.json()

    def get_browser_data(self) -> dict[str, Any]:
        """Get information about your Browser API access (synchronous)."""
        endpoint = "https://api.evomi.com/public/browser"
        
        with httpx.Client(timeout=30.0) as client:
            response = client.get(
                endpoint,
                headers=self._get_public_headers(),
            )
            return response.json()

    def rotate_session(self, session_id: str, product: str) -> dict[str, Any]:
        """Force an IP address change for an existing proxy session (synchronous)."""
        endpoint = "https://api.evomi.com/public/rotate_session"
        
        params = {
            "sessionid": session_id,
            "product": product,
        }
        
        with httpx.Client(timeout=30.0) as client:
            response = client.get(
                endpoint,
                params=params,
                headers=self._get_public_headers(),
            )
            return response.json()

    def generate_proxies(
        self,
        product: str,
        countries: Optional[str] = None,
        city: Optional[str] = None,
        region: Optional[str] = None,
        isp: Optional[str] = None,
        session: Optional[str] = None,
        amount: Optional[int] = None,
        format: Optional[str] = None,
        prepend_protocol: Optional[bool] = None,
        protocol: Optional[str] = None,
        lifetime: Optional[int] = None,
        adblock: Optional[bool] = None,
    ) -> str:
        """Automatically generate proxy strings with specific targeting parameters and connection preferences (synchronous)."""
        endpoint = "https://api.evomi.com/public/generate"
        
        params: dict[str, Any] = {"product": product}
        if countries is not None:
            params["countries"] = countries
        if city is not None:
            params["city"] = city
        if region is not None:
            params["region"] = region
        if isp is not None:
            params["isp"] = isp
        if session is not None:
            params["session"] = session
        if amount is not None:
            params["amount"] = amount
        if format is not None:
            params["format"] = format
        if prepend_protocol is not None:
            params["prepend_protocol"] = str(prepend_protocol).lower()
        if protocol is not None:
            params["protocol"] = protocol
        if lifetime is not None:
            params["lifetime"] = lifetime
        if adblock is not None:
            params["adblock"] = str(adblock).lower()
            
        with httpx.Client(timeout=30.0) as client:
            response = client.get(
                endpoint,
                params=params,
                headers=self._get_public_headers(),
            )
            
            if response.status_code >= 400:
                try:
                    err_data = response.json()
                    raise Exception(f"API Error: {err_data}")
                except Exception as e:
                    if not isinstance(e, Exception) or not str(e).startswith("API Error"):
                        raise Exception(f"API Error: {response.text}")
                    raise
                    
            return response.text
    
    # ─── Account Info ────────────────────────────────────────────────────────────
    
    def get_account_info(self) -> dict[str, Any]:
        """Get account info including credit balance (synchronous)."""
        endpoint = f"{self.base_url}/api/v1/scraper/health"
        
        with httpx.Client(timeout=30.0) as client:
            response = client.get(endpoint, headers=self._get_headers())
            return response.json()
    
    # ─── Schedule Management ────────────────────────────────────────────────────
    
    def list_schedules(
        self,
        page: int = 1,
        per_page: int = 20,
        active_only: bool = False,
    ) -> dict[str, Any]:
        """List all scheduled jobs (synchronous)."""
        endpoint = f"{self.base_url}/api/v1/account/schedule"
        
        with httpx.Client(timeout=30.0) as client:
            response = client.get(
                endpoint,
                params={"page": page, "per_page": per_page, "active_only": str(active_only).lower()},
                headers=self._get_headers(),
            )
            return response.json()
    
    def create_schedule(
        self,
        name: str,
        config_id: str,
        interval_minutes: int,
        start_time: Optional[str] = None,
        stop_on_error: bool = True,
    ) -> dict[str, Any]:
        """Create a scheduled job (synchronous)."""
        endpoint = f"{self.base_url}/api/v1/account/schedule"
        
        payload = {
            "name": name,
            "config_id": config_id,
            "interval_minutes": interval_minutes,
            "stop_on_error": stop_on_error,
        }
        if start_time:
            payload["start_time"] = start_time
        
        with httpx.Client(timeout=30.0) as client:
            response = client.post(endpoint, json=payload, headers=self._get_headers())
            return response.json()
    
    def get_schedule(self, schedule_id: str) -> dict[str, Any]:
        """Get a scheduled job by ID (synchronous)."""
        endpoint = f"{self.base_url}/api/v1/account/schedule/{schedule_id}"
        
        with httpx.Client(timeout=30.0) as client:
            response = client.get(endpoint, headers=self._get_headers())
            return response.json()
    
    def update_schedule(
        self,
        schedule_id: str,
        name: Optional[str] = None,
        config_id: Optional[str] = None,
        interval_minutes: Optional[int] = None,
        stop_on_error: Optional[bool] = None,
    ) -> dict[str, Any]:
        """Update a scheduled job (synchronous)."""
        endpoint = f"{self.base_url}/api/v1/account/schedule/{schedule_id}"
        
        payload = {}
        if name:
            payload["name"] = name
        if config_id:
            payload["config_id"] = config_id
        if interval_minutes:
            payload["interval_minutes"] = interval_minutes
        if stop_on_error is not None:
            payload["stop_on_error"] = stop_on_error
        
        with httpx.Client(timeout=30.0) as client:
            response = client.put(endpoint, json=payload, headers=self._get_headers())
            return response.json()
    
    def delete_schedule(self, schedule_id: str) -> dict[str, Any]:
        """Delete a scheduled job (synchronous)."""
        endpoint = f"{self.base_url}/api/v1/account/schedule/{schedule_id}"
        
        with httpx.Client(timeout=30.0) as client:
            response = client.delete(endpoint, headers=self._get_headers())
            return response.json()
    
    def toggle_schedule(self, schedule_id: str) -> dict[str, Any]:
        """Toggle a scheduled job active/inactive (synchronous)."""
        endpoint = f"{self.base_url}/api/v1/account/schedule/{schedule_id}/toggle"
        
        with httpx.Client(timeout=30.0) as client:
            response = client.post(endpoint, headers=self._get_headers())
            return response.json()
    
    def list_schedule_runs(
        self,
        schedule_id: str,
        page: int = 1,
        per_page: int = 20,
    ) -> dict[str, Any]:
        """Get execution history for a scheduled job (synchronous)."""
        endpoint = f"{self.base_url}/api/v1/account/schedule/{schedule_id}/runs"
        
        with httpx.Client(timeout=30.0) as client:
            response = client.get(
                endpoint,
                params={"page": page, "per_page": per_page},
                headers=self._get_headers(),
            )
            return response.json()

    # ─── Proxy Helpers ──────────────────────────────────────────────────────────

    def build_proxy_config(
        self,
        proxy_type: ProxyType = ProxyType.RESIDENTIAL,
        protocol: ProxyProtocol = ProxyProtocol.HTTP,
        country: Optional[str] = None,
        city: Optional[str] = None,
        region: Optional[str] = None,
        continent: Optional[str] = None,
        isp: Optional[str] = None,
        session: Optional[str] = None,
        hardsession: Optional[str] = None,
        lifetime: Optional[int] = None,
        mode: ResidentialMode = ResidentialMode.STANDARD,
        latency: Optional[int] = None,
        fraudscore: Optional[int] = None,
        device: Optional[str] = None,
        activesince: Optional[int] = None,
        asn: Optional[str] = None,
        zip: Optional[str] = None,
        http3: bool = False,
        localdns: bool = False,
        udp: bool = False,
        extended: bool = False,
    ) -> ProxyConfig:
        """
        Build a proxy configuration with credentials from the Public API (synchronous).
        
        Args:
            proxy_type: Type of proxy
            protocol: Protocol to use
            country: Two-letter country code
            city: City name
            region: State/region name
            continent: Continent name
            isp: ISP shortcode
            session: Sticky session ID
            hardsession: Hard session ID
            lifetime: Session duration in minutes
            mode: Residential mode
            latency: Max latency (expert)
            fraudscore: Max fraud score (expert)
            device: Device type (expert)
            activesince: Min connection minutes (expert)
            asn: ASN filter (expert)
            zip: Zipcode targeting (expert)
            http3: Enable HTTP3/QUIC (expert)
            localdns: Local DNS resolution (expert)
            udp: UDP support (expert)
            extended: Extended pool (expert)
        
        Returns:
            Configured ProxyConfig instance
        """
        proxy_data = self.get_proxy_data()
        
        # Extract credentials based on proxy type
        product_data = proxy_data.get("products", {})
        if proxy_type == ProxyType.RESIDENTIAL:
            creds = product_data.get("rp", product_data.get("residential", {}))
        elif proxy_type == ProxyType.DATACENTER:
            creds = product_data.get("sdc", product_data.get("datacenter", {}))
        else:  # MOBILE
            creds = product_data.get("mp", product_data.get("mobile", {}))
        
        username = creds.get("username", "")
        password = creds.get("password", "")
        
        config = ProxyConfig(
            proxy_type=proxy_type,
            protocol=protocol,
            country=country,
            city=city,
            region=region,
            continent=continent,
            isp=isp,
            session=session,
            hardsession=hardsession,
            lifetime=lifetime,
            mode=mode,
            latency=latency,
            fraudscore=fraudscore,
            device=device,
            activesince=activesince,
            asn=asn,
            zip=zip,
            http3=http3,
            localdns=localdns,
            udp=udp,
            extended=extended,
            username=username,
            password=password,
        )
        
        return config

    def build_proxy_string(
        self,
        proxy_type: ProxyType = ProxyType.RESIDENTIAL,
        protocol: ProxyProtocol = ProxyProtocol.HTTP,
        country: Optional[str] = None,
        city: Optional[str] = None,
        region: Optional[str] = None,
        continent: Optional[str] = None,
        isp: Optional[str] = None,
        session: Optional[str] = None,
        hardsession: Optional[str] = None,
        lifetime: Optional[int] = None,
        mode: ResidentialMode = ResidentialMode.STANDARD,
        **kwargs
    ) -> str:
        """
        Build a proxy connection string directly (synchronous).
        
        Args:
            Same as build_proxy_config()
        
        Returns:
            Proxy URL string (e.g., http://user:pass_country-US@rp.evomi.com:1000)
        """
        config = self.build_proxy_config(
            proxy_type=proxy_type,
            protocol=protocol,
            country=country,
            city=city,
            region=region,
            continent=continent,
            isp=isp,
            session=session,
            hardsession=hardsession,
            lifetime=lifetime,
            mode=mode,
            **kwargs
        )
        return config.build_proxy_string()
