"""CLI 命令注册"""

import asyncio
import json
import sys
from pathlib import Path
from typing import Annotated

from .chat_helpers import agent_chat, agent_run, interactive_chat, single_chat
from .config import get_config
from .utils import (
    apply_user_template,
    convert_to_messages,
    parse_batch_input,
    parse_thinking,
    query_credits,
    resolve_model_config,
)


def register_commands(app):
    """注册所有 CLI 命令到 typer app"""
    import typer
    from typer import Argument, Option

    @app.command()
    def ask(
        prompt: Annotated[str | None, Argument(help="用户问题")] = None,
        system: Annotated[str | None, Option("-s", "--system", help="系统提示词")] = None,
        model: Annotated[str | None, Option("-m", "--model", help="模型名称")] = None,
        user_template: Annotated[
            str | None, Option("--user-template", help="user content 模板 (使用 {content} 占位符)")
        ] = None,
    ):
        """LLM 快速问答（支持管道输入）

        Examples:
            flexllm ask "什么是Python"
            flexllm ask "解释代码" -s "你是代码专家"
            echo "长文本" | flexllm ask "总结一下"

        临时使用未配置的服务:
            FLEXLLM_BASE_URL="http://localhost:8000/v1" FLEXLLM_MODEL="qwen" flexllm ask "你好"
        """
        stdin_content = None
        if not sys.stdin.isatty():
            stdin_content = sys.stdin.read().strip()

        if not prompt and not stdin_content:
            print("错误: 请提供问题", file=sys.stderr)
            raise typer.Exit(1)

        if stdin_content:
            full_prompt = f"{stdin_content}\n\n{prompt}" if prompt else stdin_content
        else:
            full_prompt = prompt

        model_id, base_url, api_key = resolve_model_config(model, required=True)

        config = get_config()
        if not system:
            system = config.get_system(model)
        if not user_template:
            user_template = config.get_user_template(model)

        model_params = config.get_model_params(model)

        async def _ask():
            from flexllm import LLMClient

            async with LLMClient(model=model_id, base_url=base_url, api_key=api_key) as client:
                messages = []
                if system:
                    messages.append({"role": "system", "content": system})
                user_content = apply_user_template(full_prompt, user_template)
                messages.append({"role": "user", "content": user_content})
                return await client.chat_completions(messages, **model_params)

        try:
            result = asyncio.run(_ask())
            if result is None:
                return
            if isinstance(result, str):
                print(result)
                return
            if hasattr(result, "status") and result.status == "error":
                error_msg = result.data.get("detail", result.data.get("error", "未知错误"))
                print(f"错误: {error_msg}", file=sys.stderr)
                return
            print(str(result))
        except Exception as e:
            print(f"错误: {e}", file=sys.stderr)
            raise typer.Exit(1)

    @app.command()
    def chat(
        message: Annotated[str | None, Argument(help="单条消息（不提供则进入多轮对话）")] = None,
        model: Annotated[str | None, Option("-m", "--model", help="模型名称")] = None,
        base_url: Annotated[str | None, Option("--base-url", help="API 地址")] = None,
        api_key: Annotated[str | None, Option("--api-key", help="API 密钥")] = None,
        system_prompt: Annotated[str | None, Option("-s", "--system", help="系统提示词")] = None,
        temperature: Annotated[float | None, Option("-t", "--temperature", help="采样温度")] = None,
        max_tokens: Annotated[int | None, Option("--max-tokens", help="最大生成 token 数")] = None,
        no_stream: Annotated[bool, Option("--no-stream", help="禁用流式输出")] = False,
        user_template: Annotated[
            str | None, Option("--user-template", help="user content 模板 (使用 {content} 占位符)")
        ] = None,
        tools: Annotated[
            str | None,
            Option(
                "--tools", help="内置工具集（all/code/read,edit,glob,grep,bash/shell,dtflow...）"
            ),
        ] = None,
        verbose: Annotated[
            bool, Option("-v", "--verbose", help="显示详细执行过程（仅 --tools 模式）")
        ] = False,
        max_rounds: Annotated[
            int, Option("--max-rounds", help="最大 tool 调用轮数（仅 --tools 模式）")
        ] = 10,
        approve: Annotated[
            str,
            Option("--approve", help="审批模式 (auto/manual)，仅 --tools 模式"),
        ] = "auto",
        mcp: Annotated[
            list[str] | None,
            Option("--mcp", help="MCP server 命令或 URL（可多次指定，需搭配 --tools）"),
        ] = None,
    ):
        """交互式对话

        Examples:
            flexllm chat                      # 多轮对话
            flexllm chat "你好"               # 单条对话
            flexllm chat --model gpt-4 "你好" # 指定模型
            flexllm chat --tools code         # 启用代码工具
            flexllm chat --tools code -v      # 详细模式
            flexllm chat --tools code --mcp "npx @mcp/server-github"
        """
        model, base_url, api_key = resolve_model_config(model, base_url, api_key)
        config = get_config()

        if not base_url:
            print("错误: 未配置 base_url", file=sys.stderr)
            raise typer.Exit(1)

        if not system_prompt:
            system_prompt = config.get_system(model)
        if not user_template:
            user_template = config.get_user_template(model)

        model_params = config.get_model_params(model)
        if temperature is not None:
            model_params["temperature"] = temperature
        if max_tokens is not None:
            model_params["max_tokens"] = max_tokens
        model_params.setdefault("temperature", 0.7)
        model_params.setdefault("max_tokens", 2048)

        stream = not no_stream

        if tools:
            agent_chat(
                model=model,
                base_url=base_url,
                api_key=api_key,
                system_prompt=system_prompt,
                model_params=model_params,
                tools_name=tools,
                message=message,
                verbose=verbose,
                max_rounds=max_rounds,
                approve=approve,
                mcp_servers=mcp,
            )
            return

        if message:
            single_chat(
                message,
                model,
                base_url,
                api_key,
                system_prompt,
                model_params["temperature"],
                model_params["max_tokens"],
                stream,
                user_template,
            )
        else:
            interactive_chat(
                model,
                base_url,
                api_key,
                system_prompt,
                model_params["temperature"],
                model_params["max_tokens"],
                stream,
                user_template,
            )

    @app.command(name="chat-web")
    def chat_web(
        model: Annotated[str | None, Option("-m", "--model", help="模型名称")] = None,
        base_url: Annotated[str | None, Option("--base-url", help="API 地址")] = None,
        api_key: Annotated[str | None, Option("--api-key", help="API 密钥")] = None,
        system_prompt: Annotated[str | None, Option("-s", "--system", help="系统提示词")] = None,
        temperature: Annotated[float | None, Option("-t", "--temperature", help="采样温度")] = None,
        max_tokens: Annotated[int | None, Option("--max-tokens", help="最大生成 token 数")] = None,
        user_template: Annotated[
            str | None, Option("--user-template", help="user content 模板 (使用 {content} 占位符)")
        ] = None,
        port: Annotated[int, Option("-p", "--port", help="Web 服务端口")] = 8080,
        host: Annotated[str, Option("--host", help="监听地址")] = "localhost",
        thinking: Annotated[
            str | None,
            Option(
                "--thinking", help="启用思考模式 (true/false/low/medium/high 或 budget_tokens 数值)"
            ),
        ] = None,
        title: Annotated[str, Option("--title", help="页面 Logo 文本")] = "flexllm",
    ):
        """启动 Web 聊天界面

        Examples:
            flexllm chat-web                      # 使用默认模型
            flexllm chat-web -m gpt-4             # 指定模型
            flexllm chat-web -p 9090              # 指定端口
            flexllm chat-web --host 0.0.0.0       # 允许外部访问
            flexllm chat-web --thinking true      # 启用思考模式
        """
        model, base_url, api_key = resolve_model_config(model, base_url, api_key)
        config = get_config()

        if not base_url:
            print("错误: 未配置 base_url", file=sys.stderr)
            raise typer.Exit(1)

        if not system_prompt:
            system_prompt = config.get_system(model)
        if not user_template:
            user_template = config.get_user_template(model)

        model_params = config.get_model_params(model)
        if temperature is not None:
            model_params["temperature"] = temperature
        if max_tokens is not None:
            model_params["max_tokens"] = max_tokens
        model_params.setdefault("temperature", 0.7)
        model_params.setdefault("max_tokens", 2048)

        try:
            from ..chat_web import ChatWebConfig, ChatWebServer
        except ImportError:
            print("错误: 需要安装 aiohttp: pip install aiohttp", file=sys.stderr)
            raise typer.Exit(1)

        thinking_value = parse_thinking(thinking)
        if thinking_value is None:
            thinking_value = model_params.get("thinking")

        web_config = ChatWebConfig(
            port=port,
            host=host,
            model=model,
            base_url=base_url,
            api_key=api_key,
            system_prompt=system_prompt,
            temperature=model_params["temperature"],
            max_tokens=model_params["max_tokens"],
            user_template=user_template,
            thinking=thinking_value,
            title=title,
        )

        print(f"flexllm Chat Web starting on http://{host}:{port}")
        print(f"  Model: {model}")
        print(f"  Server: {base_url}")
        print(f"  Temperature: {model_params['temperature']}")
        if thinking_value is not None:
            print(f"  Thinking: {thinking_value}")
        print("\nPress Ctrl+C to stop")

        try:
            server = ChatWebServer(web_config)
            server.run()
        except KeyboardInterrupt:
            print("\nServer stopped")
        except Exception as e:
            print(f"错误: {e}", file=sys.stderr)
            raise typer.Exit(1)

    @app.command()
    def serve(
        model: Annotated[str | None, Option("-m", "--model", help="模型名称")] = None,
        base_url: Annotated[str | None, Option("--base-url", help="API 地址")] = None,
        api_key: Annotated[str | None, Option("--api-key", help="API 密钥")] = None,
        system_prompt: Annotated[str | None, Option("-s", "--system", help="系统提示词")] = None,
        user_template: Annotated[
            str | None, Option("--user-template", help="user content 模板 (使用 {content} 占位符)")
        ] = None,
        temperature: Annotated[float | None, Option("-t", "--temperature", help="采样温度")] = None,
        max_tokens: Annotated[int | None, Option("--max-tokens", help="最大生成 token 数")] = None,
        thinking: Annotated[
            str | None,
            Option(
                "--thinking", help="启用思考模式 (true/false/low/medium/high 或 budget_tokens 数值)"
            ),
        ] = None,
        concurrency: Annotated[
            int, Option("-c", "--concurrency", help="上游 LLM 最大并发数")
        ] = 1000,
        max_qps: Annotated[float | None, Option("--max-qps", help="每秒最大请求数")] = None,
        timeout: Annotated[int, Option("--timeout", help="请求超时（秒）")] = 120,
        port: Annotated[int, Option("-p", "--port", help="监听端口")] = 8000,
        host: Annotated[str, Option("--host", help="监听地址")] = "0.0.0.0",
        verbose: Annotated[bool, Option("--verbose", "-v", help="打印请求日志")] = False,
        tools: Annotated[
            str | None,
            Option("--tools", help="Agent 工具集 (all/code/read,edit,glob,grep,bash)"),
        ] = None,
        max_rounds: Annotated[int, Option("--max-rounds", help="Agent 最大 tool 调用轮数")] = 10,
    ):
        """启动 HTTP API 服务，将 LLM 包装为 REST API

        适用于微调模型部署：固定 system prompt 和 user template，
        调用方只需发送 content 文本，返回解析后的 thinking 和 content。

        API 端点:
            POST /api/generate             非流式生成
            POST /api/generate/stream      流式生成 (SSE)
            POST /api/generate/batch       批量生成
            POST /api/agent/run            Agent 单次执行 (需 --tools)
            POST /api/agent/run/stream     Agent 流式执行 (需 --tools)
            POST /api/agent/chat           Agent 多轮对话 (需 --tools)
            GET  /health                   健康检查
            GET  /api/config               查看当前配置

        Examples:
            flexllm serve -m qwen-finetuned -s "你是助手"
            flexllm serve --thinking true -c 20 -p 8000
            flexllm serve --tools code -s "你是代码助手"
        """
        model, base_url, api_key = resolve_model_config(model, base_url, api_key)
        config = get_config()

        if not base_url:
            print("错误: 未配置 base_url", file=sys.stderr)
            raise typer.Exit(1)

        if not system_prompt:
            system_prompt = config.get_system(model)
        if not user_template:
            user_template = config.get_user_template(model)

        model_params = config.get_model_params(model)
        if temperature is not None:
            model_params["temperature"] = temperature
        if max_tokens is not None:
            model_params["max_tokens"] = max_tokens

        try:
            from ..serve import ServeConfig, ServeServer
        except ImportError:
            print("错误: 需要安装 aiohttp: pip install aiohttp", file=sys.stderr)
            raise typer.Exit(1)

        thinking_value = parse_thinking(thinking)
        if thinking_value is None:
            thinking_value = model_params.get("thinking")

        serve_config = ServeConfig(
            port=port,
            host=host,
            model=model,
            base_url=base_url,
            api_key=api_key,
            system_prompt=system_prompt,
            user_template=user_template,
            temperature=model_params.get("temperature"),
            max_tokens=model_params.get("max_tokens"),
            thinking=thinking_value,
            concurrency=concurrency,
            max_qps=max_qps,
            timeout=timeout,
            verbose=verbose,
            tools=tools,
            max_rounds=max_rounds,
        )

        effective_temperature = model_params.get("temperature")
        effective_max_tokens = model_params.get("max_tokens")

        print(f"flexllm Serve starting on http://{host}:{port}")
        print(f"  Model: {model}")
        print(f"  Server: {base_url}")
        if effective_temperature is not None:
            print(f"  Temperature: {effective_temperature}")
        if effective_max_tokens is not None:
            print(f"  Max tokens: {effective_max_tokens}")
        if thinking_value is not None:
            print(f"  Thinking: {thinking_value}")
        if system_prompt:
            display = system_prompt[:50] + "..." if len(system_prompt) > 50 else system_prompt
            print(f"  System: {display}")
        if user_template:
            print(f"  User template: {user_template}")
        print(f"  Concurrency: {concurrency}")
        if max_qps is not None:
            print(f"  Max QPS: {max_qps}")
        if tools:
            print(f"  Agent tools: {tools}")
            print(f"  Agent max rounds: {max_rounds}")
        print(f"\n  POST /api/generate             非流式生成")
        print(f"  POST /api/generate/stream      流式生成")
        print(f"  POST /api/generate/batch       批量生成")
        if tools:
            print(f"  POST /api/agent/run            Agent 执行")
            print(f"  POST /api/agent/run/stream     Agent 流式执行")
            print(f"  POST /api/agent/chat           Agent 多轮对话")
        print(f"  GET  /health                   健康检查")
        print(f"  GET  /api/config               查看配置")
        if verbose:
            print(f"  Verbose: on (请求日志已开启)")
        print("\nPress Ctrl+C to stop")

        try:
            server = ServeServer(serve_config)
            server.run()
        except KeyboardInterrupt:
            print("\nServer stopped")
        except Exception as e:
            print(f"错误: {e}", file=sys.stderr)
            raise typer.Exit(1)

    @app.command()
    def batch(
        input: Annotated[str | None, Argument(help="输入文件路径（省略则从 stdin 读取）")] = None,
        output: Annotated[
            str | None, Option("-o", "--output", help="输出文件路径（可选，默认自动生成）")
        ] = None,
        model: Annotated[str | None, Option("-m", "--model", help="模型名称")] = None,
        concurrency: Annotated[int | None, Option("-c", "--concurrency", help="并发数")] = None,
        max_qps: Annotated[float | None, Option("--max-qps", help="每秒最大请求数")] = None,
        system: Annotated[str | None, Option("-s", "--system", help="全局 system prompt")] = None,
        temperature: Annotated[float | None, Option("-t", "--temperature", help="采样温度")] = None,
        max_tokens: Annotated[int | None, Option("--max-tokens", help="最大生成 token 数")] = None,
        cache: Annotated[
            bool | None, Option("--cache/--no-cache", help="启用/禁用响应缓存")
        ] = None,
        return_usage: Annotated[bool, Option("--return-usage", help="输出 token 统计")] = False,
        preprocess_msg: Annotated[bool, Option("--preprocess-msg", help="预处理图片消息")] = False,
        track_cost: Annotated[bool, Option("--track-cost", help="在进度条中显示实时成本")] = False,
        save_input: Annotated[
            str | None,
            Option(
                "--save-input",
                help="输出文件中 input 字段的保存策略: true(默认,完整保存), last(仅最后user内容), false(不保存)",
            ),
        ] = None,
        limit: Annotated[
            int | None,
            Option("-n", "--limit", help="只处理前 N 条记录（用于快速试跑）"),
        ] = None,
        user_field: Annotated[
            str | None,
            Option("--user-field", "-uf", help="指定 user content 的字段名（跳过自动格式检测）"),
        ] = None,
        system_field: Annotated[
            str | None,
            Option("--system-field", "-sf", help="指定 system prompt 的字段名（跳过自动格式检测）"),
        ] = None,
        user_template: Annotated[
            str | None,
            Option("--user-template", help="user content 模板 (使用 {content} 占位符)"),
        ] = None,
    ):
        """批量处理 JSONL 文件（支持断点续传）

        自动检测输入格式：openai_chat, alpaca, simple (q/question/prompt/input/user)
        也可用 --user-field 和 --system-field 指定任意字段名。

        高级配置可在 ~/.flexllm/config.yaml 的 batch 节中设置。
        CLI 参数优先级高于配置文件。

        Examples:
            flexllm batch input.jsonl                  # 自动生成 input.output.jsonl
            flexllm batch input.jsonl -o output.jsonl  # 指定输出文件
            flexllm batch input.jsonl -c 20 -m gpt-4   # 自动输出 + 自定义参数
            flexllm batch input.jsonl --cache --return-usage
            flexllm batch data.jsonl -o out.jsonl --user-field text --system-field sys_prompt
            cat input.jsonl | flexllm batch -o output.jsonl  # stdin 需指定 -o
        """
        has_stdin = not sys.stdin.isatty()
        if not input and not has_stdin:
            print("错误: 请提供输入文件或通过管道传入数据", file=sys.stderr)
            raise typer.Exit(1)

        auto_generated_output = False
        if not output:
            if not input:
                print(
                    "错误: 从 stdin 读取数据时必须指定输出文件 (-o output.jsonl)", file=sys.stderr
                )
                raise typer.Exit(1)

            input_path = Path(input)
            stem = input_path.stem
            output = str(input_path.parent / f"{stem}.output.jsonl")
            auto_generated_output = True

        if not output.endswith(".jsonl"):
            print(f"错误: 输出文件必须使用 .jsonl 扩展名，当前: {output}", file=sys.stderr)
            raise typer.Exit(1)

        config = get_config()
        batch_config = config.get_batch_config()

        model_config = None
        endpoints_config = None
        use_pool = False

        if model:
            model_config = config.get_model_config(model)
            if not model_config:
                print(f"错误: 未找到模型 '{model}'", file=sys.stderr)
                print("提示: 使用 'flexllm list' 查看可用模型", file=sys.stderr)
                raise typer.Exit(1)
        elif batch_config.get("endpoints"):
            endpoints_config = batch_config["endpoints"]
            use_pool = len(endpoints_config) > 0
        else:
            model_config = config.get_model_config(None)
            if not model_config:
                print("错误: 未找到模型配置", file=sys.stderr)
                print(
                    "提示: 使用 'flexllm list' 查看可用模型，或在 batch 节配置 endpoints",
                    file=sys.stderr,
                )
                raise typer.Exit(1)

        model_id = model_config.get("id", model) if model_config else None
        base_url = model_config.get("base_url") if model_config else None
        api_key = model_config.get("api_key", "EMPTY") if model_config else None

        effective_cache = cache if cache is not None else batch_config["cache"]
        effective_return_usage = return_usage or batch_config["return_usage"]
        effective_preprocess_msg = preprocess_msg or batch_config["preprocess_msg"]
        effective_track_cost = track_cost or batch_config["track_cost"]
        effective_concurrency = (
            concurrency if concurrency is not None else batch_config["concurrency"]
        )
        effective_max_qps = max_qps if max_qps is not None else batch_config["max_qps"]

        effective_system = system if system is not None else config.get_system(model)
        effective_user_template = (
            user_template if user_template is not None else config.get_user_template(model)
        )

        effective_save_input: bool | str = True
        if save_input is not None:
            low = save_input.lower()
            if low == "false":
                effective_save_input = False
            elif low == "last":
                effective_save_input = "last"
            elif low == "true":
                effective_save_input = True
            else:
                print(
                    f"错误: --save-input 仅支持 true/last/false，当前: {save_input}",
                    file=sys.stderr,
                )
                raise typer.Exit(1)

        try:
            if user_field:
                records, _, _ = parse_batch_input(input, skip_format_detection=True)
                format_type = "custom"
                message_fields = [user_field, system_field]
                if user_field not in records[0]:
                    available = list(records[0].keys())
                    print(
                        f"错误: 字段 '{user_field}' 不存在，可用字段: {available}",
                        file=sys.stderr,
                    )
                    raise typer.Exit(1)
            else:
                records, format_type, message_fields = parse_batch_input(input)
            if limit is not None:
                records = records[:limit]
            print(f"输入格式: {format_type}", file=sys.stderr)
            print(f"记录数: {len(records)}", file=sys.stderr)
            if auto_generated_output:
                print(f"输出文件: {output} (自动生成)", file=sys.stderr)
            else:
                print(f"输出文件: {output}", file=sys.stderr)

            if use_pool:
                print(
                    f"客户端: LLMClientPool ({len(endpoints_config)} endpoints)",
                    file=sys.stderr,
                )
            else:
                print(f"客户端: LLMClient ({model_config.get('name', model_id)})", file=sys.stderr)

            messages_list = []
            metadata_list = []

            for record in records:
                messages, metadata = convert_to_messages(
                    record, format_type, message_fields, effective_system, effective_user_template
                )
                messages_list.append(messages)
                metadata_list.append(metadata if metadata else None)

            has_metadata = any(m for m in metadata_list)
            if not has_metadata:
                metadata_list = None

            async def _run_batch():
                from flexllm import LLMClient, LLMClientPool

                from ..cache import ResponseCacheConfig

                cache_config = None
                if effective_cache:
                    cache_config = ResponseCacheConfig.ipc(ttl=batch_config["cache_ttl"])

                kwargs = config.get_model_params(model)
                for key in ("temperature", "max_tokens", "top_p", "top_k", "thinking"):
                    if batch_config.get(key) is not None:
                        kwargs[key] = batch_config[key]
                if temperature is not None:
                    kwargs["temperature"] = temperature
                if max_tokens is not None:
                    kwargs["max_tokens"] = max_tokens

                if use_pool:
                    pool_kwargs = {
                        "endpoints": endpoints_config,
                        "fallback": batch_config.get("fallback", True),
                        "concurrency_limit": effective_concurrency,
                        "timeout": batch_config["timeout"],
                        "retry_times": batch_config["retry_times"],
                        "cache": cache_config,
                    }
                    if effective_max_qps is not None:
                        pool_kwargs["max_qps"] = effective_max_qps

                    async with LLMClientPool(**pool_kwargs) as pool:
                        results, summary = await pool.chat_completions_batch(
                            messages_list=messages_list,
                            output_jsonl=output,
                            show_progress=True,
                            return_summary=True,
                            return_usage=effective_return_usage,
                            track_cost=effective_track_cost,
                            flush_interval=batch_config["flush_interval"],
                            metadata_list=metadata_list,
                            save_input=effective_save_input,
                            **kwargs,
                        )
                else:
                    client_kwargs = {
                        "model": model_id,
                        "base_url": base_url,
                        "api_key": api_key,
                        "concurrency_limit": effective_concurrency,
                        "timeout": batch_config["timeout"],
                        "retry_times": batch_config["retry_times"],
                        "retry_delay": batch_config["retry_delay"],
                        "cache": cache_config,
                    }
                    if effective_max_qps is not None:
                        client_kwargs["max_qps"] = effective_max_qps

                    async with LLMClient(**client_kwargs) as client:
                        results, summary = await client.chat_completions_batch(
                            messages_list=messages_list,
                            output_jsonl=output,
                            show_progress=True,
                            return_summary=True,
                            return_usage=effective_return_usage,
                            track_cost=effective_track_cost,
                            preprocess_msg=effective_preprocess_msg,
                            flush_interval=batch_config["flush_interval"],
                            metadata_list=metadata_list,
                            save_input=effective_save_input,
                            **kwargs,
                        )
                return results, summary

            results, summary = asyncio.run(_run_batch())

            if summary:
                print(f"\n完成: {summary}", file=sys.stderr)
            print(f"输出文件: {output}", file=sys.stderr)

        except json.JSONDecodeError as e:
            print(f"错误: JSON 解析失败 - {e}", file=sys.stderr)
            raise typer.Exit(1)
        except ValueError as e:
            print(f"错误: {e}", file=sys.stderr)
            raise typer.Exit(1)
        except FileNotFoundError:
            print(f"错误: 文件不存在 - {input}", file=sys.stderr)
            raise typer.Exit(1)
        except Exception as e:
            import traceback

            traceback.print_exc()
            print(f"错误: {e}", file=sys.stderr)
            raise typer.Exit(1)

    @app.command()
    def models(
        base_url: Annotated[str | None, Option("--base-url", help="API 地址")] = None,
        api_key: Annotated[str | None, Option("--api-key", help="API 密钥")] = None,
        name: Annotated[str | None, Option("-n", "--name", help="模型配置名称")] = None,
    ):
        """列出远程服务器上的可用模型"""
        import requests

        config = get_config()
        model_config = config.get_model_config(name)
        if model_config:
            base_url = base_url or model_config.get("base_url")
            api_key = api_key or model_config.get("api_key", "EMPTY")
            provider = model_config.get("provider", "openai")
        else:
            provider = "openai"

        if not base_url:
            print("错误: 未配置 base_url", file=sys.stderr)
            raise typer.Exit(1)

        is_gemini = provider == "gemini" or "generativelanguage.googleapis.com" in base_url

        try:
            if is_gemini:
                url = f"{base_url.rstrip('/')}/models?key={api_key}"
                response = requests.get(url, timeout=10)
            else:
                headers = {"Authorization": f"Bearer {api_key}"}
                response = requests.get(
                    f"{base_url.rstrip('/')}/models", headers=headers, timeout=10
                )

            if response.status_code == 200:
                models_data = response.json()

                print("\n可用模型列表")
                print(f"服务器: {base_url}")
                print("-" * 50)

                if is_gemini:
                    models_list = models_data.get("models", [])
                    if models_list:
                        for i, m in enumerate(models_list, 1):
                            model_name = m.get("name", "").replace("models/", "")
                            print(f"  {i:2d}. {model_name}")
                        print(f"\n共 {len(models_list)} 个模型")
                    else:
                        print("未找到可用模型")
                else:
                    if isinstance(models_data, dict) and "data" in models_data:
                        models_list = models_data["data"]
                    elif isinstance(models_data, list):
                        models_list = models_data
                    else:
                        models_list = []

                    if models_list:
                        for i, m in enumerate(models_list, 1):
                            if isinstance(m, dict):
                                model_id = m.get("id", m.get("name", "unknown"))
                                print(f"  {i:2d}. {model_id}")
                            else:
                                print(f"  {i:2d}. {m}")
                        print(f"\n共 {len(models_list)} 个模型")
                    else:
                        print("未找到可用模型")
            else:
                print(f"错误: HTTP {response.status_code}", file=sys.stderr)
                raise typer.Exit(1)

        except requests.exceptions.RequestException as e:
            print(f"连接失败: {e}", file=sys.stderr)
            raise typer.Exit(1)
        except Exception as e:
            print(f"错误: {e}", file=sys.stderr)
            raise typer.Exit(1)

    @app.command("list")
    def list_models():
        """列出本地配置的模型"""
        config = get_config()
        models_cfg = config.config.get("models", [])
        default = config.config.get("default", "")

        if not models_cfg:
            print("未配置模型")
            print("提示: 创建 ~/.flexllm/config.yaml 或设置环境变量")
            return

        print(f"已配置模型 (共 {len(models_cfg)} 个):\n")
        for m in models_cfg:
            name = m.get("name", m.get("id", "?"))
            model_id = m.get("id", "?")
            provider = m.get("provider", "openai")
            is_default = " (默认)" if name == default or model_id == default else ""
            endpoints = m.get("endpoints")

            print(f"  {name}{is_default}")
            if name != model_id:
                print(f"    id: {model_id}")

            if endpoints and len(endpoints) > 1:
                print(f"    type: pool ({len(endpoints)} endpoints)")
                print(f"    fallback: {m.get('fallback', True)}")
            else:
                print(f"    provider: {provider}")
            print()

    @app.command("set-model")
    def set_model(
        model_name: Annotated[str, Argument(help="模型名称或 ID")],
    ):
        """设置默认模型

        Examples:
            flexllm set-model gpt-4
            flexllm set-model local-ollama
        """
        config = get_config()
        config_path = config.get_config_path()

        if not config_path:
            print("错误: 未找到配置文件", file=sys.stderr)
            print("提示: 先运行 'flexllm init' 初始化配置文件", file=sys.stderr)
            raise typer.Exit(1)

        model_config = config.get_model_config(model_name)
        if not model_config:
            print(f"错误: 未找到模型 '{model_name}'", file=sys.stderr)
            print("提示: 使用 'flexllm list' 查看已配置的模型", file=sys.stderr)
            raise typer.Exit(1)

        try:
            import yaml

            with open(config_path, encoding="utf-8") as f:
                file_config = yaml.safe_load(f) or {}

            default_value = model_config.get("name", model_config.get("id"))
            old_default = file_config.get("default")
            file_config["default"] = default_value

            with open(config_path, "w", encoding="utf-8") as f:
                yaml.dump(file_config, f, default_flow_style=False, allow_unicode=True)

            print(f"默认模型已设置为: {default_value}")
            if old_default and old_default != default_value:
                print(f"(原默认模型: {old_default})")

            config.config["default"] = default_value

        except ImportError:
            print("错误: 需要安装 pyyaml: pip install pyyaml", file=sys.stderr)
            raise typer.Exit(1)
        except Exception as e:
            print(f"错误: {e}", file=sys.stderr)
            raise typer.Exit(1)

    @app.command()
    def test(
        model: Annotated[str | None, Option("-m", "--model", help="模型名称")] = None,
        base_url: Annotated[str | None, Option("--base-url", help="API 地址")] = None,
        api_key: Annotated[str | None, Option("--api-key", help="API 密钥")] = None,
        message: Annotated[
            str, Option("--message", help="测试消息")
        ] = "Hello, please respond with 'OK' if you can see this message.",
        timeout: Annotated[int, Option("--timeout", help="超时时间（秒）")] = 30,
    ):
        """测试 LLM 服务连接"""
        import time

        import requests

        model, base_url, api_key = resolve_model_config(model, base_url, api_key)

        if not base_url:
            print("错误: 未配置 base_url", file=sys.stderr)
            raise typer.Exit(1)

        print("\nLLM 服务连接测试")
        print("-" * 50)

        print("\n1. 测试服务器连接...")
        print(f"   地址: {base_url}")
        try:
            start = time.time()
            response = requests.get(
                f"{base_url.rstrip('/')}/models",
                headers={"Authorization": f"Bearer {api_key}"},
                timeout=timeout,
            )
            elapsed = time.time() - start

            if response.status_code == 200:
                print(f"   ✓ 连接成功 ({elapsed:.2f}s)")
                models_data = response.json()
                if isinstance(models_data, dict) and "data" in models_data:
                    model_count = len(models_data["data"])
                elif isinstance(models_data, list):
                    model_count = len(models_data)
                else:
                    model_count = 0
                print(f"   可用模型数: {model_count}")
            else:
                print(f"   ✗ 连接失败: HTTP {response.status_code}")
                raise typer.Exit(1)
        except Exception as e:
            print(f"   ✗ 连接失败: {e}")
            raise typer.Exit(1)

        if model:
            print("\n2. 测试 Chat API...")
            print(f"   模型: {model}")
            try:
                start = time.time()
                response = requests.post(
                    f"{base_url.rstrip('/')}/chat/completions",
                    headers={
                        "Authorization": f"Bearer {api_key}",
                        "Content-Type": "application/json",
                    },
                    json={
                        "model": model,
                        "messages": [{"role": "user", "content": message}],
                        "max_tokens": 50,
                    },
                    timeout=timeout,
                )
                elapsed = time.time() - start

                if response.status_code == 200:
                    result = response.json()
                    content = result.get("choices", [{}])[0].get("message", {}).get("content", "")
                    print(f"   ✓ 调用成功 ({elapsed:.2f}s)")
                    print(f"   响应: {content[:100]}...")
                else:
                    print(f"   ✗ 调用失败: HTTP {response.status_code}")
                    print(f"   {response.text[:200]}")
            except Exception as e:
                print(f"   ✗ 调用失败: {e}")

        print("\n测试完成")

    @app.command()
    def init(
        path: Annotated[str | None, Option("-p", "--path", help="配置文件路径")] = None,
    ):
        """初始化配置文件"""
        if path is None:
            config_path = Path.home() / ".flexllm" / "config.yaml"
        else:
            config_path = Path(path)

        if config_path.exists():
            print(f"配置文件已存在: {config_path}")
            return

        config_path.parent.mkdir(parents=True, exist_ok=True)

        default_config = """# flexllm 配置文件
# 配置搜索路径:
#   1. 当前目录: ./flexllm_config.yaml
#   2. 用户目录: ~/.flexllm/config.yaml

# 默认模型
default: "gpt-4"

# 全局系统提示词（应用于所有命令，除非被覆盖）
# system: "You are a helpful assistant."

# 全局 user content 模板（使用 {content} 作为占位符）
# 适用于需要特定提示词格式的微调模型
# user_template: "{content}/detail"

# 模型列表
models:
  - id: gpt-4
    name: gpt-4
    provider: openai
    base_url: https://api.openai.com/v1
    api_key: your-api-key
    # system: "You are a GPT-4 assistant."  # 模型级别 system prompt（可选）
    # user_template: "{content}"             # 模型级别 user template（可选）

  - id: local-ollama
    name: local-ollama
    provider: openai
    base_url: http://localhost:11434/v1
    api_key: EMPTY

# batch 命令配置（可选）
# 这些配置可通过 CLI 参数覆盖
# batch:
#   concurrency: 10
#   max_qps: 100
#   timeout: 120
#   retry_times: 3
#   cache: false
#   cache_ttl: 86400
"""

        try:
            with open(config_path, "w", encoding="utf-8") as f:
                f.write(default_config)
            print(f"已创建配置文件: {config_path}")
            print("请编辑配置文件填入 API 密钥")
        except Exception as e:
            print(f"创建失败: {e}", file=sys.stderr)
            raise typer.Exit(1)

    @app.command()
    def pricing(
        model: Annotated[str | None, Argument(help="模型名称（支持模糊匹配）")] = None,
        update: Annotated[bool, Option("--update", help="从 OpenRouter 更新定价表")] = False,
        json_output: Annotated[bool, Option("--json", help="输出 JSON 格式")] = False,
    ):
        """查询模型定价信息

        Examples:
            flexllm pricing                  # 列出所有模型定价
            flexllm pricing gpt-4o           # 查询 gpt-4o 定价
            flexllm pricing claude           # 模糊匹配 claude 相关模型
            flexllm pricing --update         # 从 OpenRouter 更新定价表
        """
        from ..pricing import get_pricing, reload_pricing

        MODEL_PRICING = get_pricing()

        if update:
            print("正在从 OpenRouter API 获取最新定价...")
            try:
                from ..pricing.updater import collect_pricing, update_pricing_file

                pricing_map = collect_pricing()
                print(f"获取到 {len(pricing_map)} 个模型定价")

                if update_pricing_file(pricing_map):
                    reload_pricing()
                    print("✓ data.json 已更新")
                else:
                    print("✗ 更新失败", file=sys.stderr)
                    raise typer.Exit(1)
            except Exception as e:
                print(f"更新失败: {e}", file=sys.stderr)
                raise typer.Exit(1)
            return

        if model:
            matches = {
                name: price
                for name, price in MODEL_PRICING.items()
                if model.lower() in name.lower()
            }

            if not matches:
                print(f"未找到匹配 '{model}' 的模型", file=sys.stderr)
                print(
                    f"\n可用模型: {', '.join(sorted(MODEL_PRICING.keys())[:10])}...",
                    file=sys.stderr,
                )
                raise typer.Exit(1)

            if json_output:
                import json as json_module

                output_data = {
                    name: {
                        "input_per_1m": round(p["input"] * 1e6, 4),
                        "output_per_1m": round(p["output"] * 1e6, 4),
                    }
                    for name, p in sorted(matches.items())
                }
                print(json_module.dumps(output_data, indent=2, ensure_ascii=False))
            else:
                print(f"\n模型定价 (匹配 '{model}'):\n")
                print(f"{'模型':<30} {'输入 ($/1M)':<15} {'输出 ($/1M)':<15}")
                print("-" * 60)
                for name in sorted(matches.keys()):
                    p = matches[name]
                    input_price = p["input"] * 1e6
                    output_price = p["output"] * 1e6
                    print(f"{name:<30} ${input_price:<14.4f} ${output_price:<14.4f}")
                print(f"\n共 {len(matches)} 个模型")
        else:
            if json_output:
                import json as json_module

                output_data = {
                    name: {
                        "input_per_1m": round(p["input"] * 1e6, 4),
                        "output_per_1m": round(p["output"] * 1e6, 4),
                    }
                    for name, p in sorted(MODEL_PRICING.items())
                }
                print(json_module.dumps(output_data, indent=2, ensure_ascii=False))
            else:
                groups = {}
                for name, price in MODEL_PRICING.items():
                    if name.startswith(("gpt-", "o1", "o3", "o4")):
                        group = "OpenAI"
                    elif name.startswith("claude-"):
                        group = "Anthropic"
                    elif name.startswith("gemini-"):
                        group = "Google"
                    elif name.startswith("deepseek"):
                        group = "DeepSeek"
                    elif name.startswith(("qwen", "qwen2", "qwen3")):
                        group = "Alibaba"
                    elif name.startswith(("mistral", "ministral", "codestral", "devstral")):
                        group = "Mistral"
                    elif name.startswith("llama-"):
                        group = "Meta"
                    elif name.startswith("grok"):
                        group = "xAI"
                    elif name.startswith("nova"):
                        group = "Amazon"
                    else:
                        group = "Other"

                    if group not in groups:
                        groups[group] = []
                    groups[group].append((name, price))

                print(f"\n模型定价表 (共 {len(MODEL_PRICING)} 个模型):\n")
                print(f"{'模型':<30} {'输入 ($/1M)':<15} {'输出 ($/1M)':<15}")
                print("=" * 60)

                for group_name in [
                    "OpenAI",
                    "Anthropic",
                    "Google",
                    "DeepSeek",
                    "Alibaba",
                    "Mistral",
                    "Meta",
                    "xAI",
                    "Amazon",
                    "Other",
                ]:
                    if group_name not in groups:
                        continue
                    models_in_group = groups[group_name]
                    print(f"\n[{group_name}]")
                    for name, p in sorted(models_in_group):
                        input_price = p["input"] * 1e6
                        output_price = p["output"] * 1e6
                        print(f"  {name:<28} ${input_price:<14.4f} ${output_price:<14.4f}")

    @app.command()
    def credits(
        model: Annotated[str | None, Option("-m", "--model", help="模型名称")] = None,
    ):
        """查询 API Key 余额

        支持的 provider:
          - OpenRouter, SiliconFlow, DeepSeek, AI/ML API, OpenAI

        Examples:
            flexllm credits                # 查询默认模型的 key 余额
            flexllm credits -m grok-4      # 查询指定模型的 key 余额
        """
        config = get_config()
        model_config = config.get_model_config(model)

        if not model_config:
            print("错误: 未找到模型配置", file=sys.stderr)
            print("提示: 使用 'flexllm list' 查看已配置的模型", file=sys.stderr)
            raise typer.Exit(1)

        base_url = model_config.get("base_url", "")
        api_key = model_config.get("api_key", "")
        model_name = model_config.get("name", model_config.get("id", "unknown"))

        if not api_key or api_key == "EMPTY":
            print(f"错误: 模型 '{model_name}' 未配置 API Key", file=sys.stderr)
            raise typer.Exit(1)

        result = query_credits(base_url, api_key)

        if result is None:
            print("错误: 不支持查询此 provider 的余额", file=sys.stderr)
            print(f"  base_url: {base_url}", file=sys.stderr)
            raise typer.Exit(1)

        if "error" in result:
            print(f"错误: {result['error']}", file=sys.stderr)
            raise typer.Exit(1)

        print(f"\n{result['provider']} 账户余额")
        print(f"模型配置: {model_name}")
        print(f"API Key: {api_key[:15]}...{api_key[-4:]}")
        print("-" * 40)

        for key, value in result["data"].items():
            print(f"  {key}: {value}")

    @app.command()
    def mock(
        port: Annotated[int, Option("-p", "--port", help="端口号")] = 8001,
        delay: Annotated[
            str, Option("-d", "--delay", help="延迟时间，支持 '0.5' 或 '1-5' 格式")
        ] = "0.1",
        response_len: Annotated[
            str,
            Option("-l", "--response-len", help="响应长度（字符），支持 '100' 或 '10-1000' 格式"),
        ] = "10-1000",
        model: Annotated[str, Option("-m", "--model", help="模型名称")] = "mock-model",
        rps: Annotated[float, Option("--rps", help="每秒最大请求数，0 表示不限制")] = 0,
        token_rate: Annotated[
            float, Option("--token-rate", help="流式返回时每秒 token 数，0 表示不限制")
        ] = 0,
        error_rate: Annotated[
            float, Option("--error-rate", help="请求失败率 (0-1)，0 表示不失败")
        ] = 0,
        thinking: Annotated[bool, Option("--thinking", help="响应中包含思考/推理内容")] = False,
    ):
        """启动 Mock LLM 服务器

        Examples:
            flexllm mock                          # 默认配置，端口 8001
            flexllm mock -p 8080                  # 指定端口
            flexllm mock -d 0.5                   # 固定延迟 0.5s
            flexllm mock --error-rate 0.5         # 50% 请求返回错误
        """
        try:
            from ..mock import MockLLMServer, MockServerConfig, parse_range
        except ImportError:
            print("错误: 需要安装 aiohttp: pip install aiohttp", file=sys.stderr)
            raise typer.Exit(1)

        delay_min, delay_max = parse_range(delay, float)
        response_min_len, response_max_len = parse_range(response_len, int)

        config = MockServerConfig(
            port=port,
            delay_min=delay_min,
            delay_max=delay_max,
            model=model,
            response_min_len=response_min_len,
            response_max_len=response_max_len,
            rps=rps,
            token_rate=token_rate,
            error_rate=error_rate,
            thinking=thinking,
        )

        print(f"Mock LLM Server starting on port {port}")
        print(f"  Delay: {delay_min}-{delay_max}s")
        print(f"  Response length: {response_min_len}-{response_max_len} chars")
        print(f"  Model: {model}")
        if rps > 0:
            print(f"  RPS limit: {rps}")
        if token_rate > 0:
            print(f"  Token rate: {token_rate}/s (streaming)")
        if error_rate > 0:
            print(f"  Error rate: {error_rate * 100:.1f}%")
        if thinking:
            print("  Thinking: enabled")
        print(f"  OpenAI: http://localhost:{port}/v1/chat/completions")
        print(f"  Claude: http://localhost:{port}/v1/messages")
        print(f"  Gemini: http://localhost:{port}/models/{{model}}:generateContent")
        print("\nPress Ctrl+C to stop")

        try:
            server = MockLLMServer(config)
            server.run()
        except KeyboardInterrupt:
            print("\nServer stopped")
        except Exception as e:
            print(f"错误: {e}", file=sys.stderr)
            raise typer.Exit(1)

    @app.command()
    def version():
        """显示版本信息"""
        try:
            from flexllm import __version__

            v = __version__
        except Exception:
            v = "0.1.0"
        print(f"flexllm {v}")

    @app.command("install-skill")
    def install_skill():
        """安装 Claude Code skill 文件"""
        import shutil

        skill_src = Path(__file__).parent.parent / "data" / "SKILL.md"

        if not skill_src.exists():
            print("错误: 找不到 skill 文件", file=sys.stderr)
            print("请尝试重新安装 flexllm: pip install --force-reinstall flexllm", file=sys.stderr)
            raise typer.Exit(1)

        skill_dir = Path.home() / ".claude" / "skills" / "flexllm"
        skill_dst = skill_dir / "SKILL.md"

        try:
            skill_dir.mkdir(parents=True, exist_ok=True)
            shutil.copy2(skill_src, skill_dst)
            print(f"已安装 skill 文件到: {skill_dst}")
            print("Claude Code 现在可以使用 flexllm skill 了")
        except Exception as e:
            print(f"安装失败: {e}", file=sys.stderr)
            raise typer.Exit(1)

    @app.command()
    def agent(
        message: Annotated[str | None, Argument(help="任务描述")] = None,
        model: Annotated[str | None, Option("-m", "--model", help="模型名称")] = None,
        base_url: Annotated[str | None, Option("--base-url", help="API 地址")] = None,
        api_key: Annotated[str | None, Option("--api-key", help="API 密钥")] = None,
        system_prompt: Annotated[str | None, Option("-s", "--system", help="系统提示词")] = None,
        tools: Annotated[
            str,
            Option(
                "--tools", help="内置工具集（all/code/read,edit,glob,grep,bash/shell,dtflow...）"
            ),
        ] = "shell",
        mcp: Annotated[
            list[str] | None,
            Option("--mcp", help="MCP server 命令或 URL（可多次指定）"),
        ] = None,
        max_rounds: Annotated[int, Option("--max-rounds", help="最大 tool 调用轮数")] = 10,
        verbose: Annotated[bool, Option("-v", "--verbose", help="显示详细执行过程")] = False,
        validate: Annotated[
            str | None,
            Option(
                "--validate",
                help="代码验证器（python/syntax,lint,type,pytest），验证失败自动修复",
            ),
        ] = None,
        max_fix_attempts: Annotated[
            int, Option("--max-fix-attempts", help="验证失败时最大修复尝试次数")
        ] = 3,
        approve: Annotated[
            str,
            Option("--approve", help="审批模式 (auto/manual)"),
        ] = "auto",
    ):
        """Agent 模式（非交互式，执行任务后返回）

        Examples:
            flexllm agent "查一下 cpu 使用率" --tools shell
            flexllm agent "读取 main.py" --tools code -v
            flexllm agent "修复这个 bug" --tools code --validate=python
            flexllm agent --mcp "npx @mcp/server-github" "查看最近的 PR"
            echo "列出当前目录文件" | flexllm agent --tools shell
        """
        model, base_url, api_key = resolve_model_config(model, base_url, api_key)
        config = get_config()

        if not base_url:
            print("错误: 未配置 base_url", file=sys.stderr)
            raise typer.Exit(1)

        if not message:
            if not sys.stdin.isatty():
                message = sys.stdin.read().strip()
            if not message:
                print("错误: 请提供任务描述（参数或 stdin）", file=sys.stderr)
                raise typer.Exit(1)

        model_params = config.get_model_params(model)
        model_params.setdefault("temperature", 0.7)
        model_params.setdefault("max_tokens", 2048)

        agent_run(
            message=message,
            model=model,
            base_url=base_url,
            api_key=api_key,
            system_prompt=system_prompt,
            model_params=model_params,
            tools_name=tools,
            max_rounds=max_rounds,
            verbose=verbose,
            validate=validate,
            max_fix_attempts=max_fix_attempts,
            approve=approve,
            mcp_servers=mcp,
        )

    @app.command(name="mcp-server")
    def mcp_server(
        model: Annotated[str | None, Option("-m", "--model", help="模型名称")] = None,
        base_url: Annotated[str | None, Option("--base-url", help="API 地址")] = None,
        api_key: Annotated[str | None, Option("--api-key", help="API 密钥")] = None,
        system_prompt: Annotated[str | None, Option("-s", "--system", help="系统提示词")] = None,
        tools: Annotated[
            str | None,
            Option("--tools", help="暴露 Agent 工具集 (all/code/read,edit,glob,grep,bash)"),
        ] = None,
        max_rounds: Annotated[int, Option("--max-rounds", help="Agent 最大 tool 调用轮数")] = 10,
    ):
        """启动 MCP Server (stdio 模式)

        将 flexllm 的 LLM 调用和 Agent 能力暴露为 MCP server，
        让 Claude Desktop、Cursor 等 MCP client 直接调用。

        Examples:
            flexllm mcp-server                    # 基础 LLM 调用
            flexllm mcp-server --tools code       # 包含 Agent 工具
            flexllm mcp-server -s "你是代码助手"
        """
        model, base_url, api_key = resolve_model_config(model, base_url, api_key)

        if not base_url:
            print("错误: 未配置 base_url", file=sys.stderr)
            raise typer.Exit(1)

        try:
            from ..mcp_server import run_mcp_server
        except ImportError:
            print("错误: 需要安装 mcp SDK: pip install flexllm[agent]", file=sys.stderr)
            raise typer.Exit(1)

        run_mcp_server(
            model=model,
            base_url=base_url,
            api_key=api_key,
            system_prompt=system_prompt,
            tools=tools,
            max_rounds=max_rounds,
        )
