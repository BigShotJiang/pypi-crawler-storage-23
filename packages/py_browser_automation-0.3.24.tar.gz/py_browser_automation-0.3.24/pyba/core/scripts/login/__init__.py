from pyba.core.scripts.login.instagram import InstagramLogin
from pyba.core.scripts.login.facebook import FacebookLogin
from pyba.core.scripts.login.gmail import GmailLogin
