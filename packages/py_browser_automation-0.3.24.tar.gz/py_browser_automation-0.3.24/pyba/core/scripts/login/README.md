# Login scripts

These are pre-written scripts which rely on a config to automatically log you into social media sites. This keeps your credentials safe from an LLM, we need feed it to the model we're using for automation.

## Supported login scripts

1. Instagram
2. Facebook
3. Gmail