# Structure

The `scripts` directory houses certain precoded scripts for the following use cases

1. Specific website DOM extractions
2. Logins

These scripts might rely on JavaScript execution inside the browser for which the `js` directory is defined.