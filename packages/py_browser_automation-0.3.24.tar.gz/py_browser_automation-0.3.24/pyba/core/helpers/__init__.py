global _use_random
_use_random = False
