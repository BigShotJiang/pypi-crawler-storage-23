.. _api_reference_index:

API Reference (by module)
=========================

Detailed auto-generated reference for each Astra subpackage.

.. toctree::
 :maxdepth: 2

 client
 models
 errors
 events
 protocol
 connection
 utils
