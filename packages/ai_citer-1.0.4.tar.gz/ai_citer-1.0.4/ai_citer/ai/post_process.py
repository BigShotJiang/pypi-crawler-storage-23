from ..models import Document, Fact


def assign_page_numbers(doc: Document, facts: list[Fact]) -> None:
    if doc.type != "pdf" or not doc.content.segments:
        return

    for fact in facts:
        for citation in fact.citations:
            if citation.charOffset < 0:
                continue
            for seg in doc.content.segments:
                if seg.charOffset <= citation.charOffset < seg.charOffset + len(seg.text):
                    if seg.pageNumber is not None:
                        citation.pageNumber = seg.pageNumber
                    break
