# ai-citer public API
from .main import app
from .models import (
    Citation,
    ClaudeExtraction,
    ClaudeFact,
    Document,
    DocumentContent,
    DocumentSummary,
    ExtractionResult,
    Fact,
    TextSegment,
    TokenUsage,
)
from .routes.documents import router as documents_router
from .ai.claude import extract_facts, extract_facts_chunked
from .ai.chat import chat_with_document
from .ai.citation_mapper import map_citations
from .ai.post_process import assign_page_numbers
from .db.client import create_pool
from .db.init import init_db
from .db.documents import insert_document, get_document_by_id, list_documents
from .db.extractions import (
    insert_extraction_result,
    get_latest_extraction_by_document_id,
    get_all_facts_by_document_id,
)
from .parsers.pdf import parse_pdf
from .parsers.word import parse_word
from .parsers.text import parse_text
from .parsers.web import parse_web
from .parsers.web_js import parse_web_js, get_page_html_js

__version__ = "1.0.4"

__all__ = [
    # FastAPI app + router
    "app",
    "documents_router",
    # Models
    "Citation",
    "ClaudeExtraction",
    "ClaudeFact",
    "Document",
    "DocumentContent",
    "DocumentSummary",
    "ExtractionResult",
    "Fact",
    "TextSegment",
    "TokenUsage",
    # AI functions
    "extract_facts",
    "extract_facts_chunked",
    "chat_with_document",
    "map_citations",
    "assign_page_numbers",
    # DB
    "create_pool",
    "init_db",
    "insert_document",
    "get_document_by_id",
    "list_documents",
    "insert_extraction_result",
    "get_latest_extraction_by_document_id",
    "get_all_facts_by_document_id",
    # Parsers
    "parse_pdf",
    "parse_word",
    "parse_text",
    "parse_web",
    "parse_web_js",
    "get_page_html_js",
]
