use anyhow::Result;

fn main() -> Result<()> {
    ontoenv_cli::run()
}
