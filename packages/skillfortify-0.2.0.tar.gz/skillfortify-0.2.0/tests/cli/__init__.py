"""Tests for the SkillFortify CLI commands."""
