"""
提取正确的原子类型列表，保持原始顺序
"""

from typing import List, Set, Tuple, Dict
def extract_atom_types(trajectory_file: str) -> List[str]:
    """
    简单直观的实现，保持原始顺序
    
    参数:
        trajectory_file: xyz轨迹文件的路径
    
    返回:
        包含第一个构型中所有原子类型的列表（不重复，保持原始顺序）
    """
    with open(trajectory_file, 'r', encoding='utf-8') as f:
        n_atoms = int(f.readline().strip())
        f.readline()  # 跳过注释行
        
        types = []
        for _ in range(n_atoms):
            atom_type = f.readline().split()[1] # gases_analysis_5.py中原子类型在第二列（索引1）
            if not atom_type.isdigit():  # 过滤数字
                types.append(atom_type)
    
    # 去重但保持顺序
    result = []
    seen = set()
    for atom in types:
        if atom not in seen:
            seen.add(atom)
            result.append(atom)
    
    return result