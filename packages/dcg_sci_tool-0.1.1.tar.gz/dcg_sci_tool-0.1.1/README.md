# Summation Tool

A lightweight Python library to compute the sum of integers from 1 to n efficiently using Gauss's formula.

## Installation 