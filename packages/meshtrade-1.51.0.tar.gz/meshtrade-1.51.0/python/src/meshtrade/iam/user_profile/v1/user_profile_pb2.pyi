from buf.validate import validate_pb2 as _validate_pb2
from meshtrade.type.v1 import token_pb2 as _token_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class UserProfile(_message.Message):
    __slots__ = ("name", "owner", "owners", "user", "locale", "profile_picture_url", "display_name", "display_currency", "reporting_currency")
    NAME_FIELD_NUMBER: _ClassVar[int]
    OWNER_FIELD_NUMBER: _ClassVar[int]
    OWNERS_FIELD_NUMBER: _ClassVar[int]
    USER_FIELD_NUMBER: _ClassVar[int]
    LOCALE_FIELD_NUMBER: _ClassVar[int]
    PROFILE_PICTURE_URL_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_CURRENCY_FIELD_NUMBER: _ClassVar[int]
    REPORTING_CURRENCY_FIELD_NUMBER: _ClassVar[int]
    name: str
    owner: str
    owners: _containers.RepeatedScalarFieldContainer[str]
    user: str
    locale: str
    profile_picture_url: str
    display_name: str
    display_currency: _token_pb2.Token
    reporting_currency: _token_pb2.Token
    def __init__(self, name: _Optional[str] = ..., owner: _Optional[str] = ..., owners: _Optional[_Iterable[str]] = ..., user: _Optional[str] = ..., locale: _Optional[str] = ..., profile_picture_url: _Optional[str] = ..., display_name: _Optional[str] = ..., display_currency: _Optional[_Union[_token_pb2.Token, _Mapping]] = ..., reporting_currency: _Optional[_Union[_token_pb2.Token, _Mapping]] = ...) -> None: ...
