import datetime

from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from meshtrade.iam.user_profile.v1 import user_profile_pb2 as _user_profile_pb2
from meshtrade.option.method_options.v1 import method_options_pb2 as _method_options_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class GetUserProfileByUserRequest(_message.Message):
    __slots__ = ("user",)
    USER_FIELD_NUMBER: _ClassVar[int]
    user: str
    def __init__(self, user: _Optional[str] = ...) -> None: ...

class UpdateUserProfileRequest(_message.Message):
    __slots__ = ("user_profile",)
    USER_PROFILE_FIELD_NUMBER: _ClassVar[int]
    user_profile: _user_profile_pb2.UserProfile
    def __init__(self, user_profile: _Optional[_Union[_user_profile_pb2.UserProfile, _Mapping]] = ...) -> None: ...

class GetUserProfileRequest(_message.Message):
    __slots__ = ("name",)
    NAME_FIELD_NUMBER: _ClassVar[int]
    name: str
    def __init__(self, name: _Optional[str] = ...) -> None: ...

class ListUserProfilesRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListUserProfilesResponse(_message.Message):
    __slots__ = ("user_profiles",)
    USER_PROFILES_FIELD_NUMBER: _ClassVar[int]
    user_profiles: _containers.RepeatedCompositeFieldContainer[_user_profile_pb2.UserProfile]
    def __init__(self, user_profiles: _Optional[_Iterable[_Union[_user_profile_pb2.UserProfile, _Mapping]]] = ...) -> None: ...

class GetUserProfilePictureUploadUrlRequest(_message.Message):
    __slots__ = ("name",)
    NAME_FIELD_NUMBER: _ClassVar[int]
    name: str
    def __init__(self, name: _Optional[str] = ...) -> None: ...

class GetUserProfilePictureUploadUrlResponse(_message.Message):
    __slots__ = ("upload_url", "expires_at")
    UPLOAD_URL_FIELD_NUMBER: _ClassVar[int]
    EXPIRES_AT_FIELD_NUMBER: _ClassVar[int]
    upload_url: str
    expires_at: _timestamp_pb2.Timestamp
    def __init__(self, upload_url: _Optional[str] = ..., expires_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...
