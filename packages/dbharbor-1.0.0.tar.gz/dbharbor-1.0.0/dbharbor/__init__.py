# __init__.py
from .tools import clean, clean_data, clean_column_names, clean_string, clean_dtypes

__version__ = "1.0.0"
__author__ = "Eric Di Re"