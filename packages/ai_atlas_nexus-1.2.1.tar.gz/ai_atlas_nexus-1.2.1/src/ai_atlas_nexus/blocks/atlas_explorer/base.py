from abc import ABC


class ExplorerBase(ABC):
    pass
