"""Profile management — predefined evaluation configurations."""

from __future__ import annotations

from finetunecheck.profiles.loader import EvalProfile, ProfileLoader

__all__ = ["ProfileLoader", "EvalProfile"]
