"""Multi-run comparison and Pareto analysis."""

from finetunecheck.compare.multi_run import ComparisonResult, MultiRunComparator

__all__ = ["ComparisonResult", "MultiRunComparator"]
