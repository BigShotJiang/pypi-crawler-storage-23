"""MCP server for AI assistant integration with FineTuneCheck."""
