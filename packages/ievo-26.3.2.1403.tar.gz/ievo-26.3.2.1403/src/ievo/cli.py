"""iEvo CLI — main entry point.

All PRs are reviewed by Eva before merging.
Evolutions are published to ievo.ai and Telegram.
"""

import typer

from ievo.commands import (
    add,
    config_cmd,
    deps,
    dev,
    init,
    learn,
    list_cmd,
    orchestrate,
    remove,
    run,
    team,
    update,
)

app = typer.Typer(
    name="ievo",
    help="Self-evolving AI agent framework.",
    no_args_is_help=False,
    invoke_without_command=True,
    rich_markup_mode="rich",
)

# ── Project lifecycle ──────────────────────────────────────────
app.command(name="init", help="Create a new iEvo project.")(init.init)
app.command(name="add", help="Install agent(s) from marketplace.")(add.add)
app.command(name="remove", help="Remove an installed agent.")(remove.remove)
app.command(name="update", help="Update agent(s) to latest version.")(update.update)
app.command(name="list", help="Show installed agents.")(list_cmd.list_agents)

# ── Running agents ─────────────────────────────────────────────
app.command(name="run", help="Start an agent session.")(run.run)
app.command(name="team", help="Run Agent Teams with multiple agents.")(team.team)
app.command(name="orchestrate", help="Run agent in automated loop.")(orchestrate.orchestrate)

# ── Configuration ─────────────────────────────────────────────
app.add_typer(config_cmd.app, name="config", help="Manage settings and credentials.")

# ── Dependencies ──────────────────────────────────────────────
app.add_typer(deps.app, name="deps", help="Manage agent MCP/plugin dependencies.")

# ── Self-evolution ─────────────────────────────────────────────
app.add_typer(learn.app, name="learn", help="Self-evolution commands.")

# ── Development ────────────────────────────────────────────────
app.add_typer(dev.app, name="dev", help="Agent development commands.")


def version_callback(value: bool) -> None:
    if value:
        from ievo import __version__

        typer.echo(f"ievo {__version__}")
        raise typer.Exit()


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    version: bool = typer.Option(
        False,
        "--version",
        "-v",
        callback=version_callback,
        is_eager=True,
        help="Show version and exit.",
    ),
) -> None:
    """iEvo — self-evolving AI agent framework.

    Install agents like packages. They learn from every mistake.
    """
    if ctx.invoked_subcommand is None:
        from ievo.tui.app import run_tui

        run_tui()
