"""Define the version of the library."""

__version__ = "26.03.02.1403"
