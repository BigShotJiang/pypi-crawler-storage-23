"""MCP Advisor — browse and discover MCP servers from your AI assistant."""

__version__ = "0.1.0"
