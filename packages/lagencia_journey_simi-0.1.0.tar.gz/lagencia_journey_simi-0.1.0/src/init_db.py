from dotenv import load_dotenv

load_dotenv()
from journey.database.config_db import engine
from journey.database.models import BaseEmpatia


def create_tables():
    BaseEmpatia.metadata.create_all(engine)


if __name__ == "__main__":
    create_tables()
