from typing import Dict, List

import pandas as pd
from pydantic import BaseModel

from journey.database.models import ShipmentJorneySimiPropietario
from journey.database.querys import select_record_shipment_propietario, upsert_record_shipment_propietario
from journey.templates_x_month import TemplatesPropietario


class DataSendAudiencia(BaseModel):
    email: str
    phone: str


def enviar_audiencia(template: str, data: DataSendAudiencia) -> Dict:
    print(f"Enviando audiencia para: {data.email=}")

    match template:
        case "template_email_1":
            # send_email_month_1(email=data.email)
            ...

        case "template_email_2":
            # send_email_month_2(email=data.email)
            ...

        case "template_email_3":
            # send_email_month_3(email=data.email)
            ...

        case "template_email_4":
            # send_email_month_4(email=data.email)
            ...

        case "sends_template_wpp_1":
            # sends_template_wpp_1(phone=data.phone)
            ...

        case "sends_template_wpp_2":
            # sends_template_wpp_2(phone=data.phone)
            ...

    return {"msj": "", "status": True}


def registrar_audiencia_en_db(records_audiencias: List[Dict], month: int):
    print(f"Registrando audiencias del {month=}")
    print(f"Cantidad de audiencias para registrar {len(records_audiencias)}")

    for record in records_audiencias:
        # Normalizar NaN / tipos pandas
        contrato = record.get("NoContrato")
        email = record.get("EmailPro")
        phone = record.get("CelPro1")
        fecha_inicio = record.get("InicioContrato")

        contrato = None if pd.isna(contrato) else int(contrato)
        email = None if pd.isna(email) else str(email).strip()
        phone = None if pd.isna(phone) else str(phone).strip()
        fecha_inicio = None if pd.isna(fecha_inicio) else fecha_inicio

        if fecha_inicio is not None and hasattr(fecha_inicio, "to_pydatetime"):
            fecha_inicio = fecha_inicio.to_pydatetime()

        result_record = select_record_shipment_propietario(contrato=record.get("NoContrato"))

        if result_record is None:
            month_ = 1
            template_ = TemplatesPropietario.get(month=month_)
            history_templates = template_

            record_ = {
                "contrato": contrato,
                "email": email,
                "phone": phone,
                "last_template_sent": template_,
                "month": month_,
                "list_of_templates_sent": history_templates,  # lista Python (JSON)
                "fecha_inicio": fecha_inicio,
            }

        else:
            month_ = result_record.month + 1
            month_ = month_ if month_ in range(1, 13) else 1
            template_ = TemplatesPropietario.get(month=month_)
            history_templates = result_record.list_of_templates_sent.copy()

            if history_templates:
                history_templates.extend(template_)
                history_templates = list(set(history_templates))
            else:
                history_templates = template_.copy()

            record_ = {
                "contrato": contrato,
                "email": email,
                "phone": phone,
                "last_template_sent": template_ if template_ else None,
                "month": month_,
                "list_of_templates_sent": history_templates,  # lista Python (JSON)
                "fecha_inicio": fecha_inicio,
            }

        if template_ and email and phone:
            print(f"{template_[0]=}")
            data = DataSendAudiencia(email=email, phone=phone)
            result_send = enviar_audiencia(template=template_[0], data=data)  # hace el envio email o wpp
            if result_send.get("status"):
                data_ = ShipmentJorneySimiPropietario(**record_)
                upsert_record_shipment_propietario(data_)
