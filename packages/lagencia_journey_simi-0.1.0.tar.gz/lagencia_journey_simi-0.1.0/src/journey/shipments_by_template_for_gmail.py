import os
import smtplib
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path
from typing import List, Optional

from loguru import logger
from pydantic import BaseModel

from journey.database.querys import select_template_from_email_for_table


class DataRequestedForGmail(BaseModel):
    SMTP_SERVER: str
    SMTP_USER: str
    SMTP_PASSWORD: str
    SMTP_PORT: int
    subject: str
    recipients: List[str]
    html_content: Optional[str]
    files: Optional[List[Path | str]] = None


def build_gmail_data_from_env(
    subject: str,
    recipients: List[str],
    html_content: str,
    files: Optional[List[Path | str]] = None,
) -> DataRequestedForGmail:
    """
    Construye el objeto DataRequestedForGmail leyendo las variables SMTP
    desde el entorno. Lanza un RuntimeError si falta algo importante.
    """
    server = os.getenv("SMTP_SERVER_LIVIN")
    user = os.getenv("SMTP_USER_LIVIN")
    password = os.getenv("SMTP_PASSWORD_LIVIN")
    port_raw = os.getenv("SMTP_PORT_LIVIN", "587")

    if not all([server, user, password, port_raw]):
        raise RuntimeError(f"Variables SMTP incompletas: SMTP_SERVER={server}, SMTP_USER={user}, SMTP_PORT={port_raw}, SMTP_PASSWORD={'***' if password else None}")

    try:
        port = int(port_raw)
    except ValueError:
        raise RuntimeError(f"SMTP_PORT inválido: {port_raw}")

    return DataRequestedForGmail(
        SMTP_SERVER=server,
        SMTP_USER=user,
        SMTP_PASSWORD=password,
        SMTP_PORT=port,
        subject=subject,
        recipients=recipients,
        html_content=html_content,
        files=files,
    )


def shipment_by_email(data: DataRequestedForGmail):
    print(f"{data.recipients=}")
    recipients = [str(recipient).strip() for recipient in data.recipients]
    cc_recipients = []
    bcc_recipients = []

    # build message
    msg = MIMEMultipart()
    msg["From"] = data.SMTP_USER
    msg["To"] = ", ".join(recipients)
    msg["Subject"] = data.subject

    msg["Cc"] = ", ".join(cc_recipients)
    msg["Bcc"] = ", ".join(bcc_recipients)

    # Agregar el HTML como cuerpo del correo
    msg.attach(MIMEText(data.html_content or "", "html"))

    # Adjuntar archivos
    if data.files:
        for file_path in data.files:
            file_path = str(file_path)
            if os.path.exists(file_path):
                try:
                    with open(file_path, "rb") as attachment:
                        part = MIMEBase("application", "octet-stream")
                        part.set_payload(attachment.read())

                    encoders.encode_base64(part)

                    filename = os.path.basename(file_path)
                    part.add_header(
                        "Content-Disposition",
                        f"attachment; filename={filename}",
                    )

                    msg.attach(part)
                    print(f"✅ Archivo adjuntado: {filename}")
                except Exception as e:
                    print(f"❌ Error al adjuntar {file_path}: {str(e)}")
            else:
                print(f"⚠️ Archivo no encontrado: {file_path}")

    # shipment email
    try:
        server = smtplib.SMTP(data.SMTP_SERVER, data.SMTP_PORT)
        server.starttls()
        server.login(data.SMTP_USER, data.SMTP_PASSWORD)
        server.sendmail(data.SMTP_USER, recipients + cc_recipients + bcc_recipients, msg.as_string())
        server.quit()
        print("Correo enviado con éxito ✅")
        return True
    except Exception as e:
        print(f"❌ Error al enviar correo: {str(e)}")
        return False


def _send_with_template(template_name: str, subject: str, recipients: List[str]) -> bool:
    """
    Helper interno para reutilizar lógica entre las diferentes funciones de envío.
    """
    print(f"{template_name=}")
    template_row = select_template_from_email_for_table(template_name)

    if not template_row or not getattr(template_row, "html_body", None):
        logger.warning(f"Envio de correo <{template_name}> a <{recipients}> fallido: plantilla vacía")
        return False

    html_template = template_row.html_body

    try:
        data_requested = build_gmail_data_from_env(
            subject=subject,
            recipients=recipients,
            html_content=html_template,
        )
    except Exception as e:
        logger.error(f"❌ Error al construir DataRequestedForGmail: {e}")
        return False

    ok = shipment_by_email(data_requested)

    if ok:
        logger.warning(f"Envio de correo <{template_name}> a <{recipients}> exitoso")
    else:
        logger.warning(f"Envio de correo <{template_name}> a <{recipients}> fallido")

    return ok


# ===================== Envios por gmail ===============================


def send_email_month_1(email: str):
    template_name = "template_email_1"
    subject = "Envio de prueba template 1"
    email = "analista1@lagencia.com.co"  # si es prueba; si no, quita esta línea

    result = _send_with_template(template_name, subject, [email])

    if result:
        return {"status_code": 200, "shipping_summary": "enviado"}

    return {"status_code": 400, "shipping_summary": "no enviado"}


def send_email_month_2(email: str):
    template_name = "template_email_2"
    subject = "Envio de prueba template 2"
    email = "analista1@lagencia.com.co"  # si es prueba; si no, quita esta línea

    result = _send_with_template(template_name, subject, [email])

    if result:
        return {"status_code": 200, "shipping_summary": "enviado"}

    return {"status_code": 400, "shipping_summary": "no enviado"}


def send_email_month_3(email: str):
    template_name = "template_email_3"
    subject = "Envio de prueba template 3"
    email = "analista1@lagencia.com.co"  # si es prueba; si no, quita esta línea

    result = _send_with_template(template_name, subject, [email])

    if result:
        return {"status_code": 200, "shipping_summary": "enviado"}

    return {"status_code": 400, "shipping_summary": "no enviado"}


def send_email_month_4(email: str):
    template_name = "template_email_4"
    subject = "Envio de prueba template 4"
    email = "analista1@lagencia.com.co"  # si es prueba; si no, quita esta línea

    result = _send_with_template(template_name, subject, [email])

    if result:
        return {"status_code": 200, "shipping_summary": "enviado"}

    return {"status_code": 400, "shipping_summary": "no enviado"}


if __name__ == "__main__":
    templates_html = [
        "templates_gmail/esto_dicen_de_nosotros.html",
        "templates_gmail/invitacion_seccion_nosotros.html",
        "templates_gmail/servicio_diferencial.html",
    ]

    for template in templates_html:
        with open(template, "r", encoding="utf-8") as file:
            html_template = file.read()

        try:
            data = build_gmail_data_from_env(
                subject="Prueba",
                recipients=["analista1@lagencia.com.co"],
                html_content=html_template,
            )
            result_shipment = shipment_by_email(data)
            print(f"{result_shipment=}")
        except Exception as e:
            print(f"❌ Error en prueba local: {e}")
