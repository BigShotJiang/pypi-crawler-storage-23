from typing import List


class TemplatesPropietario:
    month_1: List[str] = ["template_email_1"]  # email
    month_2: List[str] = ["template_email_2"]  # email
    month_3: List[str] = ["template_email_3"]  # email
    month_4: List[str] = ["template_email_4"]  # email
    month_5: List[str] = ["sends_template_wpp_1"]  # wpp
    month_6: List[str] = ["sends_template_wpp_2"]  # wpp
    month_7: List[str] = []
    month_8: List[str] = []
    month_9: List[str] = []
    month_10: List[str] = []
    month_11: List[str] = []
    month_12: List[str] = []

    @classmethod
    def get(cls, month: int) -> List[str]:
        return getattr(cls, f"month_{month}")
