from sqlalchemy import JSON, Column, Integer, String, DateTime, Text

from journey.database.config_db import BaseEmpatia

class EmailTemplateJouneySimi(BaseEmpatia):
    __tablename__ = "journey_simi_email_templates"

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(100), nullable=False)
    html_body = Column(Text, nullable=False)


class ShipmentJorneySimiPropietario(BaseEmpatia):
    __tablename__ = "shipments_jorney_simi_propietario"
    contrato = Column(Integer, primary_key=True)
    email = Column(String(100))
    phone = Column(String(15))
    last_template_sent = Column(String(100))
    month = Column(Integer)
    list_of_templates_sent = Column(JSON, nullable=True)
    fecha_inicio = Column(DateTime)


class ShipmentJorneySimiInquilino(BaseEmpatia):
    __tablename__ = "shipments_jorney_simi_inquilino"
    contrato = Column(Integer, primary_key=True)
    email = Column(String(100))
    phone = Column(String(15))
    last_template_sent = Column(String(100))
    list_of_templates_sent = Column(JSON, nullable=True)
