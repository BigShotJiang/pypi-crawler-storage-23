import json

import requests


def sends_template_wpp_1(phone: str):
    phone = "573103555742"
    url = "https://smart-home.com.co/WhatsAppTemplate.aspx?method=POST"

    payload = json.dumps({"name": "mes_5_prop", "contactId": phone, "clientId": "573184444845", "addMessage": False, "components": []})
    headers = {"Content-Type": "application/json"}

    response = requests.request("GET", url, headers=headers, data=payload)

    return {"status_code": response.status_code, "shipping_summary": response.text}


def sends_template_wpp_2(phone: str):
    phone = "573103555742"
    url = "https://smart-home.com.co/WhatsAppTemplate.aspx?method=POST"

    payload = json.dumps({"name": "mes_6_prop", "contactId": phone, "clientId": "573184444845", "addMessage": False, "components": []})
    headers = {"Content-Type": "application/json"}

    response = requests.request("GET", url, headers=headers, data=payload)

    return {"status_code": response.status_code, "shipping_summary": response.text}
