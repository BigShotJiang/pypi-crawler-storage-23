from datetime import datetime

import pandas as pd
from dotenv import load_dotenv

from journey.service import registrar_audiencia_en_db

load_dotenv()
from journey.api.api import Simi
from journey.api.models import Auth


def main():
    print("Hello from journey-simi!")

    auth = Auth()
    service = Simi(auth=auth)
    # result = service.get_token()
    # print(f"{result.token=}")
    # print(f"{result.expiration=}")
    # print(f"{result.companies=}")

    # data = ResquestFetchPropietario(id_cedula="900225208", month=1, year=2025)
    # result = service.fetch_propietario(data=data)
    # print(f"{result=}")

    # data = ResquestFetchInquilino(id_cedula="811012353", month=1, year=2024)
    # result = service.fetch_inquilino(data=data)
    # print(f"{result=}")

    # result = service.fetch_contratos()
    # print(f"{result=}")
    # data = result.get("PAYLOAD").get("DATA")
    # df_data = pd.DataFrame(data)
    # df_data.to_excel("contratos.xlsx", index=False)

    # df_data_simplificado_propietario = df_data[["NoContrato", "CedPro", "Propietario", "CelPro1", "EmailPro", "InicioContrato", "FinContrato"]]
    # df_data_simplificado_propietario.to_excel("df_data_simplificado_propietario.xlsx", index=False)

    # df_data_simplificado_inquilino = df_data[["NoContrato", "CedArre", "Arrendatario", "CelArre1", "EmailArre", "InicioContrato", "FinContrato"]]
    # df_data_simplificado_inquilino.to_excel("df_data_simplificado_inquilino.xlsx", index=False)

    #data = df_data_simplificado_propietario.copy()
    # ==================================

    data = pd.read_excel("df_data_simplificado_propietario.xlsx")
    data["InicioContrato"] = pd.to_datetime(data["InicioContrato"], errors="coerce")
    data["month_InicioContrato"] = data["InicioContrato"].dt.month

    groups = list(data.groupby(by="month_InicioContrato"))
    current_month = datetime.now().month - 1

    if current_month >= 1:
        print("Enviar audiecnias de enero")
        records_audiencias = groups[0][1].to_dict(orient="records")
        registrar_audiencia_en_db(records_audiencias=records_audiencias, month=1)

    if current_month >= 2:
        print("Enviar audiecnias de febrero")
        records_audiencias = groups[1][1].to_dict(orient="records")
        registrar_audiencia_en_db(records_audiencias=records_audiencias, month=2)

    if current_month >= 3:
        print("Enviar audiecnias de marzo")
        records_audiencias = groups[2][1].to_dict(orient="records")
        registrar_audiencia_en_db(records_audiencias=records_audiencias, month=3)

    if current_month >= 4:
        print("Enviar audiecnias de abril")
        records_audiencias = groups[3][1].to_dict(orient="records")
        registrar_audiencia_en_db(records_audiencias=records_audiencias, month=4)

    if current_month >= 5:
        print("Enviar audiecnias de mayo")
        records_audiencias = groups[4][1].to_dict(orient="records")
        registrar_audiencia_en_db(records_audiencias=records_audiencias, month=5)

    if current_month >= 6:
        print("Enviar audiecnias de junio")
        records_audiencias = groups[5][1].to_dict(orient="records")
        registrar_audiencia_en_db(records_audiencias=records_audiencias, month=6)

    if current_month >= 7:
        print("Enviar audiecnias de julio")
        records_audiencias = groups[6][1].to_dict(orient="records")
        registrar_audiencia_en_db(records_audiencias=records_audiencias, month=7)

    if current_month >= 8:
        print("Enviar audiecnias de agosto")
        records_audiencias = groups[7][1].to_dict(orient="records")
        registrar_audiencia_en_db(records_audiencias=records_audiencias, month=8)

    if current_month >= 9:
        print("Enviar audiecnias de septiembre")
        records_audiencias = groups[8][1].to_dict(orient="records")
        registrar_audiencia_en_db(records_audiencias=records_audiencias, month=9)

    if current_month >= 10:
        print("Enviar audiecnias de octubre")
        records_audiencias = groups[9][1].to_dict(orient="records")
        registrar_audiencia_en_db(records_audiencias=records_audiencias, month=10)

    if current_month >= 11:
        print("Enviar audiecnias de noviembre")
        records_audiencias = groups[10][1].to_dict(orient="records")
        registrar_audiencia_en_db(records_audiencias=records_audiencias, month=11)

    if current_month >= 12:
        print("Enviar audiecnias de diciembre")
        records_audiencias = groups[11][1].to_dict(orient="records")
        registrar_audiencia_en_db(records_audiencias=records_audiencias, month=12)


if __name__ == "__main__":
    main()
