"""Tests for multi-CLI support in the task dispatcher."""

import logging
import os
import re
import shlex
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest.mock import MagicMock, mock_open, patch

import pytest

from orchestration import cli_arg_utils
from orchestration.cli_validation import (
    EXPECTED_VALIDATION_ANSWER,
    ValidationResult,
    _build_validation_answer_regex,
    _normalize_validation_output_line,
)
from orchestration.task_dispatcher import (
    CLI_PROFILES,
    CURSOR_MODEL,
    GEMINI_MODEL,
    apply_minimax_auth_env,
    resolve_minimax_api_key,
    TaskDispatcher,
)


class TestAgentCliSelection(unittest.TestCase):
    """Verify that different CLIs can be selected and executed."""

    def setUp(self):
        self.dispatcher = TaskDispatcher()

    def test_respects_forced_cli_codex(self):
        """Forced CLI selection should override detection/keywords."""
        task = "Please run codex exec --yolo against the new hooks"
        agent_specs = self.dispatcher.analyze_task_and_create_agents(task, forced_cli="codex")
        self.assertEqual(agent_specs[0]["cli"], "codex")

    def test_respects_forced_cli_codex_name_reference(self):
        """Forced CLI selection works regardless of task wording."""
        task = "Codex should handle the red team hardening checklist"
        agent_specs = self.dispatcher.analyze_task_and_create_agents(task, forced_cli="codex")
        self.assertEqual(agent_specs[0]["cli"], "codex")

    def test_keywords_select_cli_when_not_forced(self):
        """Keywords should select CLI when no explicit override is provided."""
        with patch("orchestration.task_dispatcher.shutil.which") as mock_which:
            mock_which.side_effect = (
                lambda command: "/usr/bin/codex"
                if command == "codex"
                else "/usr/bin/claude"
                if command == "claude"
                else None
            )

            task = "Please run codex exec against the hooks"
            agent_specs = self.dispatcher.analyze_task_and_create_agents(task)

        self.assertEqual(agent_specs[0]["cli"], "codex")

    def test_auto_selects_only_available_cli(self):
        """Fallback to installed CLI when task has no explicit preference."""

        with patch("orchestration.task_dispatcher.shutil.which") as mock_which:

            def which_side_effect(command):
                if command == "claude":
                    return None
                if command == "codex":
                    return "/usr/local/bin/codex"
                return None

            mock_which.side_effect = which_side_effect

            task = "Please help with integration tests"
            agent_specs = self.dispatcher.analyze_task_and_create_agents(task)

        self.assertEqual(agent_specs[0]["cli"], "codex")

    def test_agent_cli_chain_parses_from_flag(self):
        """Comma-separated --agent-cli should produce a deterministic CLI chain."""
        task = "Please help with integration tests --agent-cli=gemini,codex"
        agent_specs = self.dispatcher.analyze_task_and_create_agents(task)
        self.assertEqual(agent_specs[0]["cli"], "gemini")
        self.assertEqual(agent_specs[0]["cli_chain"], ["gemini", "codex"])

    def test_invalid_forced_cli_raises_value_error(self):
        """Invalid forced_cli values should raise a clear error."""
        with self.assertRaises(ValueError):
            self.dispatcher.analyze_task_and_create_agents("Please help", forced_cli="invalid")

    def test_invalid_agent_cli_flag_raises_value_error(self):
        """Invalid --agent-cli values should raise (do not silently fall back)."""
        with self.assertRaises(ValueError):
            self.dispatcher.analyze_task_and_create_agents("Please help --agent-cli=invalid")

    def test_create_dynamic_agent_uses_codex_command(self):
        """Ensure codex agents execute via `codex exec --yolo`."""
        agent_spec = {
            "name": "task-agent-codex-test",
            "focus": "Validate Codex CLI integration",
            "prompt": "Do the work",
            "capabilities": [],
            "type": "development",
            "cli": "codex",
        }

        with (
            patch.object(self.dispatcher, "_cleanup_stale_prompt_files"),
            patch.object(self.dispatcher, "_get_active_tmux_agents", return_value=set()),
            patch.object(self.dispatcher, "_print_tmp_subdirectories"),
            patch.object(
                self.dispatcher,
                "_create_worktree_at_location",
                return_value=("/tmp/task-agent-codex-test", MagicMock(returncode=0, stderr="")),
            ),
            patch("os.makedirs"),
            patch("os.chmod"),
            patch("builtins.open", mock_open()),
            patch("os.path.exists", return_value=False),
            patch("orchestration.task_dispatcher.Path.write_text") as mock_write_text,
            patch("orchestration.task_dispatcher.subprocess.run") as mock_run,
            patch("orchestration.task_dispatcher.shutil.which") as mock_which,
            patch.object(self.dispatcher, "_validate_cli_availability", return_value=True) as mock_validate,
        ):

            def which_side_effect(command):
                known_binaries = {
                    "codex": "/usr/bin/codex",
                    "tmux": "/usr/bin/tmux",
                }
                return known_binaries.get(command)

            mock_which.side_effect = which_side_effect
            mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")

            result = self.dispatcher.create_dynamic_agent(agent_spec)

        self.assertTrue(result)
        self.assertGreater(len(mock_write_text.call_args_list), 0)
        script_contents = mock_write_text.call_args_list[0][0][0]  # First positional arg is the content
        self.assertIn("codex exec --yolo", script_contents)
        self.assertNotIn("--model ", script_contents)
        self.assertRegex(
            script_contents,
            r"< /tmp/agent_prompt_task-agent-codex-test[_0-9-]*\.txt",
        )
        self.assertIn("Codex exit code", script_contents)

    def test_create_dynamic_agent_embeds_cli_chain(self):
        """When cli_chain is provided, the generated runner should include both attempts in order."""
        agent_spec = {
            "name": "task-agent-cli-chain-test",
            "focus": "Validate CLI chain",
            "prompt": "Do the work",
            "capabilities": [],
            "type": "development",
            "cli": "gemini",
            "cli_chain": ["gemini", "codex"],
        }

        with (
            patch.object(self.dispatcher, "_cleanup_stale_prompt_files"),
            patch.object(self.dispatcher, "_get_active_tmux_agents", return_value=set()),
            patch.object(self.dispatcher, "_print_tmp_subdirectories"),
            patch.object(
                self.dispatcher,
                "_create_worktree_at_location",
                return_value=("/tmp/task-agent-cli-chain-test", MagicMock(returncode=0, stderr="")),
            ),
            patch("os.makedirs"),
            patch("os.chmod"),
            patch("builtins.open", mock_open()),
            patch("os.path.exists", return_value=False),
            patch("orchestration.task_dispatcher.Path.write_text") as mock_write_text,
            patch("orchestration.task_dispatcher.subprocess.run") as mock_run,
            patch("orchestration.task_dispatcher.shutil.which") as mock_which,
            patch.object(self.dispatcher, "_validate_cli_availability", return_value=True) as mock_validate,
        ):

            def which_side_effect(command):
                known_binaries = {
                    "gemini": "/usr/bin/gemini",
                    "codex": "/usr/bin/codex",
                    "tmux": "/usr/bin/tmux",
                }
                return known_binaries.get(command)

            mock_which.side_effect = which_side_effect
            mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")

            result = self.dispatcher.create_dynamic_agent(agent_spec)

        self.assertTrue(result)
        script_contents = mock_write_text.call_args_list[0][0][0]  # First positional arg is the content
        self.assertIn("CLI chain: gemini,codex", script_contents)
        self.assertIn("Gemini exit code", script_contents)
        self.assertIn("Codex exit code", script_contents)

    def test_create_dynamic_agent_includes_cli_args(self):
        """Custom cli_args from agent_spec must be appended to each CLI attempt."""
        agent_spec = {
            "name": "task-agent-cli-args-test",
            "focus": "Validate CLI extra args",
            "prompt": "Do the work",
            "capabilities": [],
            "type": "development",
            "cli": "codex",
            "cli_args": ["--one", "value with space", "--no-test"],
            "model": "gpt-4",
        }

        with (
            patch.object(self.dispatcher, "_cleanup_stale_prompt_files"),
            patch.object(self.dispatcher, "_get_active_tmux_agents", return_value=set()),
            patch.object(self.dispatcher, "_print_tmp_subdirectories"),
            patch.object(
                self.dispatcher,
                "_create_worktree_at_location",
                return_value=("/tmp/task-agent-cli-args-test", MagicMock(returncode=0, stderr="")),
            ),
            patch("os.makedirs"),
            patch("os.chmod"),
            patch("builtins.open", mock_open()),
            patch("os.path.exists", return_value=False),
            patch("orchestration.task_dispatcher.Path.write_text") as mock_write_text,
            patch("orchestration.task_dispatcher.subprocess.run") as mock_run,
            patch("orchestration.task_dispatcher.shutil.which") as mock_which,
            patch.object(self.dispatcher, "_validate_cli_availability", return_value=True) as mock_validate,
        ):

            def which_side_effect(command):
                known_binaries = {
                    "codex": "/usr/bin/codex",
                    "tmux": "/usr/bin/tmux",
                }
                return known_binaries.get(command)

            mock_which.side_effect = which_side_effect
            mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")

            result = self.dispatcher.create_dynamic_agent(agent_spec)

        self.assertTrue(result)
        script_contents = mock_write_text.call_args_list[0][0][0]  # First positional arg is script content
        self.assertIn("codex exec --yolo --skip-git-repo-check --model gpt-4 --one 'value with space' --no-test", script_contents)

    def test_create_dynamic_agent_handles_malformed_cli_args(self):
        """Malformed cli_args strings should not crash dynamic agent creation."""
        agent_spec = {
            "name": "task-agent-cli-args-malformed",
            "focus": "Handle broken quotes",
            "prompt": "Do the work",
            "capabilities": [],
            "type": "development",
            "cli": "codex",
            "cli_args": '--dangling "quote',
            "model": "gpt-4",
        }

        with (
            patch.object(self.dispatcher, "_cleanup_stale_prompt_files"),
            patch.object(self.dispatcher, "_get_active_tmux_agents", return_value=set()),
            patch.object(self.dispatcher, "_print_tmp_subdirectories"),
            patch.object(
                self.dispatcher,
                "_create_worktree_at_location",
                return_value=("/tmp/task-agent-cli-args-malformed", MagicMock(returncode=0, stderr="")),
            ),
            patch("os.makedirs"),
            patch("os.chmod"),
            patch("builtins.open", mock_open()),
            patch("os.path.exists", return_value=False),
            patch("orchestration.task_dispatcher.Path.write_text") as mock_write_text,
            patch("orchestration.task_dispatcher.subprocess.run") as mock_run,
            patch("orchestration.task_dispatcher.shutil.which") as mock_which,
            patch.object(self.dispatcher, "_validate_cli_availability", return_value=True),
        ):

            def which_side_effect(command):
                known_binaries = {
                    "codex": "/usr/bin/codex",
                    "tmux": "/usr/bin/tmux",
                }
                return known_binaries.get(command)

            mock_which.side_effect = which_side_effect
            mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")

            result = self.dispatcher.create_dynamic_agent(agent_spec)

        self.assertTrue(result)
        script_contents = mock_write_text.call_args_list[0][0][0]
        self.assertIn("codex exec --yolo --skip-git-repo-check --model gpt-4 --dangling", script_contents)

    def test_create_dynamic_agent_fails_when_requested_cli_missing(self):
        """Agent creation should fail when the requested CLI is absent (no automatic fallback)."""

        agent_spec = {
            "name": "task-agent-fallback-test",
            "focus": "No fallback behavior",
            "prompt": "Do the work",
            "capabilities": [],
            "type": "development",
            "cli": "claude",
        }

        with (
            patch.object(self.dispatcher, "_cleanup_stale_prompt_files"),
            patch.object(self.dispatcher, "_get_active_tmux_agents", return_value=set()),
            patch.object(self.dispatcher, "_print_tmp_subdirectories"),
            patch.object(
                self.dispatcher,
                "_create_worktree_at_location",
                return_value=("/tmp/task-agent-fallback-test", MagicMock(returncode=0, stderr="")),
            ),
            patch("os.makedirs"),
            patch("os.chmod"),
            patch("builtins.open", mock_open()),
            patch("os.path.exists", return_value=False),
            patch("orchestration.task_dispatcher.Path.write_text") as mock_write_text,
            patch("orchestration.task_dispatcher.subprocess.run") as mock_run,
            patch("orchestration.task_dispatcher.shutil.which") as mock_which,
            patch.object(self.dispatcher, "_ensure_mock_claude_binary", return_value=None),
            patch.object(self.dispatcher, "_ensure_mock_cli_binary", return_value=None),
            patch.object(self.dispatcher, "_validate_cli_availability", return_value=False) as mock_validate,
        ):

            def which_side_effect(command):
                mapping = {
                    "claude": None,
                    "codex": "/usr/bin/codex",
                    "tmux": "/usr/bin/tmux",
                }
                return mapping.get(command)

            mock_which.side_effect = which_side_effect
            mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")

            result = self.dispatcher.create_dynamic_agent(agent_spec)

        # Should fail because claude is missing and no fallback occurs
        self.assertFalse(result, "Agent creation should fail when requested CLI is missing")
        # CLI should remain unchanged (no fallback)
        self.assertEqual(agent_spec["cli"], "claude")


class TestGeminiCliSupport(unittest.TestCase):
    """Tests for Gemini CLI support in task dispatcher."""

    def setUp(self):
        self.dispatcher = TaskDispatcher()

    def test_respects_forced_cli_gemini_keyword(self):
        """Forced CLI selection should override detection/keywords."""
        task = "Please run gemini to analyze this code"
        agent_specs = self.dispatcher.analyze_task_and_create_agents(task, forced_cli="gemini")
        self.assertEqual(agent_specs[0]["cli"], "gemini")

    def test_respects_forced_cli_gemini_name_reference(self):
        """Forced selection works regardless of wording."""
        task = "Use Gemini CLI to review the authentication module"
        agent_specs = self.dispatcher.analyze_task_and_create_agents(task, forced_cli="gemini")
        self.assertEqual(agent_specs[0]["cli"], "gemini")

    def test_respects_forced_cli_gemini_google_reference(self):
        """Forced selection works even with generic Google reference."""
        task = "Use google ai to help with this task"
        agent_specs = self.dispatcher.analyze_task_and_create_agents(task, forced_cli="gemini")
        self.assertEqual(agent_specs[0]["cli"], "gemini")

    def test_gemini_keywords_select_cli_when_not_forced(self):
        """Gemini keywords should select CLI when not overridden."""
        with patch("orchestration.task_dispatcher.shutil.which") as mock_which:
            mock_which.side_effect = (
                lambda command: "/usr/bin/gemini"
                if command == "gemini"
                else "/usr/bin/claude"
                if command == "claude"
                else None
            )

            task = "Please run gemini to analyze this code"
            agent_specs = self.dispatcher.analyze_task_and_create_agents(task)

        self.assertEqual(agent_specs[0]["cli"], "gemini")

    def test_gemini_cli_profile_exists(self):
        """Verify Gemini CLI profile is properly configured."""
        self.assertIn("gemini", CLI_PROFILES)

        gemini_profile = CLI_PROFILES["gemini"]
        self.assertEqual(gemini_profile["binary"], "gemini")
        self.assertEqual(gemini_profile["display_name"], "Gemini")
        self.assertIn("gemini", gemini_profile["detection_keywords"])
        self.assertIn("google ai", gemini_profile["detection_keywords"])

    def test_gemini_uses_configured_model(self):
        """Verify Gemini CLI command template uses {model} placeholder for dynamic model selection."""
        gemini_profile = CLI_PROFILES["gemini"]
        command_template = gemini_profile["command_template"]

        # Template should use {model} placeholder, not hardcoded GEMINI_MODEL
        # The actual model (GEMINI_MODEL or user-specified) is set at runtime
        self.assertIn("{model}", command_template)
        self.assertNotIn("GEMINI_MODEL", command_template)
        
        # Verify template can be formatted with GEMINI_MODEL
        formatted = command_template.format(binary="/usr/bin/gemini", model=GEMINI_MODEL)
        self.assertIn(GEMINI_MODEL, formatted)

    def test_auto_selects_gemini_when_only_available(self):
        """Fallback to Gemini CLI when it's the only installed CLI."""
        with patch("orchestration.task_dispatcher.shutil.which") as mock_which:

            def which_side_effect(command):
                if command == "gemini":
                    return "/usr/local/bin/gemini"
                return None

            mock_which.side_effect = which_side_effect

            task = "Please help with integration tests"
            agent_specs = self.dispatcher.analyze_task_and_create_agents(task)

        self.assertEqual(agent_specs[0]["cli"], "gemini")

    def test_create_dynamic_agent_uses_gemini_command(self):
        """Ensure Gemini agents execute via gemini CLI with correct model."""
        agent_spec = {
            "name": "task-agent-gemini-test",
            "focus": "Validate Gemini CLI integration",
            "prompt": "Do the work",
            "capabilities": [],
            "type": "development",
            "cli": "gemini",
        }

        with (
            patch.object(self.dispatcher, "_cleanup_stale_prompt_files"),
            patch.object(self.dispatcher, "_get_active_tmux_agents", return_value=set()),
            patch.object(self.dispatcher, "_print_tmp_subdirectories"),
            patch.object(
                self.dispatcher,
                "_create_worktree_at_location",
                return_value=("/tmp/task-agent-gemini-test", MagicMock(returncode=0, stderr="")),
            ),
            patch("os.makedirs"),
            patch("os.chmod"),
            patch("builtins.open", mock_open()),
            patch("os.path.exists", return_value=False),
            patch("orchestration.task_dispatcher.Path.write_text") as mock_write_text,
            patch("orchestration.task_dispatcher.subprocess.run") as mock_run,
            patch("orchestration.task_dispatcher.shutil.which") as mock_which,
            patch.object(self.dispatcher, "_validate_cli_availability", return_value=True) as mock_validate,
        ):

            def which_side_effect(command):
                known_binaries = {
                    "gemini": "/usr/bin/gemini",
                    "tmux": "/usr/bin/tmux",
                }
                return known_binaries.get(command)

            mock_which.side_effect = which_side_effect
            mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")

            result = self.dispatcher.create_dynamic_agent(agent_spec)

        self.assertTrue(result)
        self.assertGreater(len(mock_write_text.call_args_list), 0)
        script_contents = mock_write_text.call_args_list[0][0][0]
        # Verify Gemini CLI command is in the script
        self.assertIn("gemini", script_contents)
        # Verify the model is the configured GEMINI_MODEL
        self.assertIn(GEMINI_MODEL, script_contents)
        self.assertIn("Gemini exit code", script_contents)

    def test_gemini_cli_fails_when_requested_but_missing(self):
        """Agent creation should fail when Gemini is absent (no automatic fallback)."""
        agent_spec = {
            "name": "task-agent-gemini-fallback-test",
            "focus": "No fallback behavior",
            "prompt": "Do the work",
            "capabilities": [],
            "type": "development",
            "cli": "gemini",
        }

        with (
            patch.object(self.dispatcher, "_cleanup_stale_prompt_files"),
            patch.object(self.dispatcher, "_get_active_tmux_agents", return_value=set()),
            patch.object(self.dispatcher, "_print_tmp_subdirectories"),
            patch.object(
                self.dispatcher,
                "_create_worktree_at_location",
                return_value=("/tmp/task-agent-gemini-fallback-test", MagicMock(returncode=0, stderr="")),
            ),
            patch("os.makedirs"),
            patch("os.chmod"),
            patch("builtins.open", mock_open()),
            patch("os.path.exists", return_value=False),
            patch("orchestration.task_dispatcher.Path.write_text") as mock_write_text,
            patch("orchestration.task_dispatcher.subprocess.run") as mock_run,
            patch("orchestration.task_dispatcher.shutil.which") as mock_which,
            patch.object(self.dispatcher, "_ensure_mock_claude_binary", return_value=None),
            patch.object(self.dispatcher, "_ensure_mock_cli_binary", return_value=None),
            patch.object(self.dispatcher, "_validate_cli_availability", return_value=False) as mock_validate,
        ):

            def which_side_effect(command):
                mapping = {
                    "gemini": None,
                    "claude": None,
                    "codex": "/usr/bin/codex",
                    "tmux": "/usr/bin/tmux",
                }
                return mapping.get(command)

            mock_which.side_effect = which_side_effect
            mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")

            result = self.dispatcher.create_dynamic_agent(agent_spec)

        # Should fail because gemini is missing and no fallback occurs
        self.assertFalse(result, "Agent creation should fail when requested CLI is missing")
        # CLI should remain unchanged (no fallback)
        self.assertEqual(agent_spec["cli"], "gemini")

    def test_explicit_agent_cli_flag_gemini(self):
        """Verify --agent-cli gemini flag works correctly."""
        task = "Fix the bug --agent-cli gemini"
        agent_specs = self.dispatcher.analyze_task_and_create_agents(task)
        self.assertEqual(agent_specs[0]["cli"], "gemini")

    def test_preflight_validation_fallback_to_codex_on_quota(self):
        """Pre-flight validation should fallback to Codex when Gemini quota exhausted."""
        agent_spec = {
            "name": "task-agent-preflight-test",
            "focus": "Test pre-flight validation fallback",
            "prompt": "Do the work",
            "capabilities": [],
            "type": "development",
            "cli": "gemini",
            "cli_chain": ["gemini", "codex"],
            "skip_preflight": False,  # Opt-in: exercise preflight validation path
        }

        with (
            patch.object(self.dispatcher, "_cleanup_stale_prompt_files"),
            patch.object(self.dispatcher, "_get_active_tmux_agents", return_value=set()),
            patch.object(
                self.dispatcher,
                "_create_worktree_at_location",
                return_value=("/tmp/task-agent-preflight-test", MagicMock(returncode=0, stderr="")),
            ),
            patch("os.makedirs"),
            patch("os.chmod"),
            patch("builtins.open", mock_open()),
            patch("os.path.exists", return_value=False),
            patch("orchestration.task_dispatcher.Path.write_text") as mock_write_text,
            patch("orchestration.task_dispatcher.subprocess.run") as mock_run,
            patch("orchestration.task_dispatcher.shutil.which") as mock_which,
            patch.object(self.dispatcher, "_validate_cli_availability") as mock_validate,
            patch.object(self.dispatcher, "_print_tmp_subdirectories") as mock_show_tmp,
        ):

            def which_side_effect(command):
                known_binaries = {
                    "gemini": "/usr/bin/gemini",
                    "codex": "/usr/bin/codex",
                    "tmux": "/usr/bin/tmux",
                }
                return known_binaries.get(command)

            mock_which.side_effect = which_side_effect

            # Mock validation: Gemini fails, Codex succeeds
            def validate_side_effect(cli_name, cli_path, agent_name, model=None):
                if cli_name == "gemini":
                    return False  # Quota exhausted
                elif cli_name == "codex":
                    return True  # Available
                return False

            mock_validate.side_effect = validate_side_effect
            mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")

            result = self.dispatcher.create_dynamic_agent(agent_spec)

        self.assertTrue(result)
        mock_show_tmp.assert_called()
        # Agent should have fallen back to Codex
        self.assertEqual(agent_spec["cli"], "codex")
        script_contents = mock_write_text.call_args_list[0][0][0]
        self.assertIn("codex exec --yolo", script_contents)


class TestGeminiCliIntegration(unittest.TestCase):
    """Integration tests for Gemini CLI with minimal mocking.

    These tests verify real behavior of CLI detection, profile configuration,
    and command generation with only essential mocks (external system calls).
    """

    def setUp(self):
        self.dispatcher = TaskDispatcher()

    def test_gemini_profile_complete_configuration(self):
        """Integration: Verify complete Gemini profile has all required fields."""

        gemini = CLI_PROFILES["gemini"]

        # All required profile fields must exist
        required_fields = [
            "binary",
            "display_name",
            "generated_with",
            "co_author",
            "supports_continue",
            "conversation_dir",
            "continue_flag",
            "restart_env",
            "command_template",
            "stdin_template",
            "quote_prompt",
            "detection_keywords",
        ]

        for field in required_fields:
            self.assertIn(field, gemini, f"Missing required field: {field}")

        # Verify specific values for Gemini profile
        self.assertEqual(gemini["binary"], "gemini")
        self.assertEqual(gemini["display_name"], "Gemini")
        # Command template uses {model} placeholder for dynamic model selection
        self.assertIn("{model}", gemini["command_template"])
        # Verify template can be formatted with GEMINI_MODEL (the default)
        formatted = gemini["command_template"].format(binary="/usr/bin/gemini", model=GEMINI_MODEL)
        self.assertIn(GEMINI_MODEL, formatted)
        self.assertFalse(gemini["supports_continue"])
        self.assertIsNone(gemini["conversation_dir"])

    def test_gemini_forced_cli_overrides_keywords(self):
        """Forced CLI should return gemini regardless of keywords."""

        keywords = CLI_PROFILES["gemini"]["detection_keywords"]
        for keyword in keywords:
            task = f"Please {keyword} this code for me"
            agent_specs = self.dispatcher.analyze_task_and_create_agents(task, forced_cli="gemini")
            self.assertEqual(agent_specs[0]["cli"], "gemini")

    def test_gemini_command_template_format_string_valid(self):
        """Integration: Verify command template has valid format placeholders."""

        template = CLI_PROFILES["gemini"]["command_template"]

        # Test that template can be formatted with expected placeholders
        # NOTE: prompt_file is now passed via stdin_template, not command_template
        # NOTE: model is now a required placeholder (dynamic model selection)
        test_values = {
            "binary": "/usr/bin/gemini",
            "model": GEMINI_MODEL,  # Required placeholder for dynamic model selection
        }

        try:
            formatted = template.format(**test_values)
            self.assertIn("/usr/bin/gemini", formatted)
            self.assertIn(GEMINI_MODEL, formatted)
            # Prompt comes via stdin, not command line
            self.assertIn("--yolo", formatted)
        except KeyError as e:
            self.fail(f"Command template has unknown placeholder: {e}")

    def test_claude_cli_priority_over_gemini_when_explicit(self):
        """Integration: Explicit --agent-cli claude overrides default Gemini."""
        # Mock both CLIs as available
        with patch("orchestration.task_dispatcher.shutil.which") as mock_which:

            def which_side_effect(cmd):
                return f"/usr/bin/{cmd}" if cmd in ["claude", "gemini", "codex"] else None

            mock_which.side_effect = which_side_effect

            # Without explicit flag, now defaults to gemini
            task_without_flag = "Fix the authentication bug"
            specs_without = self.dispatcher.analyze_task_and_create_agents(task_without_flag)
            self.assertEqual(specs_without[0]["cli"], "gemini")

            # With explicit flag, should use claude
            task_with_flag = "Fix the authentication bug --agent-cli claude"
            specs_with = self.dispatcher.analyze_task_and_create_agents(task_with_flag)
            self.assertEqual(specs_with[0]["cli"], "claude")

    def test_gemini_detection_case_insensitive(self):
        """Integration: Gemini detection works regardless of case."""
        with patch("orchestration.task_dispatcher.shutil.which") as mock_which:
            mock_which.side_effect = lambda command: "/usr/bin/gemini" if command == "gemini" else None

            test_cases = [
                "Use GEMINI for this",
                "Use Gemini for this",
                "Use gemini for this",
                "Use GeMiNi for this",
            ]

            for task in test_cases:
                specs = self.dispatcher.analyze_task_and_create_agents(task)
                self.assertEqual(specs[0]["cli"], "gemini", f"Case variation '{task}' failed detection")

    def test_gemini_agent_spec_complete_structure(self):
        """Integration: Full agent spec generation includes all required fields."""
        with patch("orchestration.task_dispatcher.shutil.which") as mock_which:
            mock_which.side_effect = lambda command: "/usr/bin/gemini" if command == "gemini" else None

            task = "Use gemini to implement the new feature"
            specs = self.dispatcher.analyze_task_and_create_agents(task)

            self.assertEqual(len(specs), 1)
            spec = specs[0]

            # Verify all required spec fields
            required_spec_fields = ["name", "type", "focus", "capabilities", "prompt", "cli"]
            for field in required_spec_fields:
                self.assertIn(field, spec, f"Missing spec field: {field}")

            self.assertEqual(spec["cli"], "gemini")
            self.assertTrue(spec["name"].startswith("task-agent-"))
            self.assertEqual(spec["type"], "development")

    def test_gemini_model_enforced_in_all_paths(self):
        """Integration: Model is set dynamically via {model} placeholder, defaults to GEMINI_MODEL."""

        # Verify template uses {model} placeholder for dynamic model selection
        template = CLI_PROFILES["gemini"]["command_template"]
        self.assertIn("{model}", template)
        # Verify template can be formatted with GEMINI_MODEL (the default)
        formatted = template.format(binary="/usr/bin/gemini", model=GEMINI_MODEL)
        self.assertIn(GEMINI_MODEL, formatted)

    def test_gemini_stdin_template_uses_prompt_file(self):
        """Integration: Gemini receives prompt via stdin (not deprecated -p flag)."""

        gemini = CLI_PROFILES["gemini"]
        # Prompt must come via stdin since -p flag is deprecated and only appends to stdin
        self.assertEqual(gemini["stdin_template"], "{prompt_file}")
        self.assertFalse(gemini["quote_prompt"])

    def test_all_cli_profiles_have_consistent_structure(self):
        """Integration: All CLI profiles (claude, codex, gemini, cursor) have same structure."""

        expected_keys = set(CLI_PROFILES["claude"].keys())

        for cli_name, profile in CLI_PROFILES.items():
            profile_keys = set(profile.keys())
            self.assertEqual(
                profile_keys,
                expected_keys,
                f"CLI profile '{cli_name}' has inconsistent keys. "
                f"Missing: {expected_keys - profile_keys}, Extra: {profile_keys - expected_keys}",
            )

    def test_all_env_unset_values_are_valid_posix_identifiers(self):
        """Integration: All env_unset values must be valid POSIX environment variable names."""
        import re

        for cli_name, profile in CLI_PROFILES.items():
            env_unset = profile.get("env_unset", [])
            self.assertIsInstance(env_unset, list, f"{cli_name} env_unset should be a list")
            for var in env_unset:
                self.assertIsInstance(var, str, f"{cli_name} env_unset values should be strings")
                self.assertTrue(
                    re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", var),
                    f"{cli_name} env_unset contains invalid variable name: {var!r}",
                )

    def test_env_unset_expected_values(self):
        """Integration: Verify expected env_unset values for each CLI profile."""
        self.assertEqual(
            CLI_PROFILES["claude"]["env_unset"],
            [
                "ANTHROPIC_API_KEY",
                "ANTHROPIC_BASE_URL",
                "CLAUDECODE",
            ],
        )
        self.assertEqual(CLI_PROFILES["codex"]["env_unset"], ["OPENAI_API_KEY"])
        self.assertEqual(CLI_PROFILES["gemini"]["env_unset"], ["GEMINI_API_KEY"])
        self.assertEqual(CLI_PROFILES["cursor"]["env_unset"], [])

    def test_claude_env_unset_preserves_auth_token(self):
        """Claude profile should preserve ANTHROPIC_AUTH_TOKEN for non-interactive auth."""
        self.assertNotIn("ANTHROPIC_AUTH_TOKEN", CLI_PROFILES["claude"]["env_unset"])

    def test_claude_env_unset_includes_claudecode(self):
        """Claude profile must unset CLAUDECODE to avoid nested-session guard when spawned from Claude Code."""
        self.assertIn("CLAUDECODE", CLI_PROFILES["claude"]["env_unset"])

class TestMinimaxCliEnvironment(unittest.TestCase):
    """MiniMax uses claude CLI with MiniMax API endpoint — env isolation must be correct.

    The minimax profile runs `claude --model MiniMax-M2.5 -p @prompt`.
    When that subprocess is spawned from inside a Claude Code session, the parent's
    CLAUDECODE env var is inherited and claude refuses to start:
      'Claude Code cannot be launched inside another Claude Code session.'
    CLAUDECODE must therefore be in env_unset so the preflight strips it.
    """

    def test_minimax_env_unset_includes_claudecode(self):
        """MiniMax profile must unset CLAUDECODE so claude child avoids nested-session guard."""
        self.assertIn(
            "CLAUDECODE",
            CLI_PROFILES["minimax"]["env_unset"],
            "CLAUDECODE must be in minimax env_unset to prevent nested-session preflight failure",
        )

    def test_minimax_preflight_env_strips_claudecode(self):
        """The env dict built for the minimax preflight subprocess must not contain CLAUDECODE.

        Simulates jleechanorg_pr_monitor.py:1795:
            env = {k: v for k, v in os.environ.items() if k not in profile.get('env_unset', [])}
        """
        profile = CLI_PROFILES["minimax"]
        env_unset = profile.get("env_unset", [])
        simulated_os_env = {
            "PATH": "/usr/bin",
            "HOME": "/Users/test",
            "CLAUDECODE": "1",
            "ANTHROPIC_API_KEY": "sk-ant-test",
            "ANTHROPIC_AUTH_TOKEN": "sk-ant-auth-test",
            "MINIMAX_API_KEY": "sk-minimax-test",
        }
        preflight_env = {k: v for k, v in simulated_os_env.items() if k not in env_unset}
        self.assertNotIn(
            "CLAUDECODE",
            preflight_env,
            "CLAUDECODE must be stripped from preflight env to prevent nested-session error",
        )

    def test_minimax_preflight_env_strips_anthropic_keys(self):
        """The preflight env must also strip both ANTHROPIC_API_KEY and ANTHROPIC_AUTH_TOKEN."""
        profile = CLI_PROFILES["minimax"]
        env_unset = profile.get("env_unset", [])
        simulated_os_env = {
            "ANTHROPIC_API_KEY": "sk-ant-key",
            "ANTHROPIC_AUTH_TOKEN": "sk-ant-auth",
            "CLAUDECODE": "1",
        }
        preflight_env = {k: v for k, v in simulated_os_env.items() if k not in env_unset}
        self.assertNotIn("ANTHROPIC_API_KEY", preflight_env)
        self.assertNotIn("ANTHROPIC_AUTH_TOKEN", preflight_env)

    def test_minimax_binary_is_claude(self):
        """MiniMax must use the claude binary (not a separate minimax binary)."""
        self.assertEqual(CLI_PROFILES["minimax"]["binary"], "claude")

    def test_minimax_env_set_points_to_minimax_endpoint(self):
        """MiniMax env_set must redirect to MiniMax API proxy, not Anthropic."""
        env_set = CLI_PROFILES["minimax"]["env_set"]
        self.assertEqual(env_set["ANTHROPIC_BASE_URL"], "https://api.minimax.io/anthropic")


class TestMinimaxAuthResolution(unittest.TestCase):
    """MiniMax auth resolution should mirror the working local shell flow."""

    def setUp(self):
        self.dispatcher = TaskDispatcher()

    def test_resolve_minimax_api_key_prefers_valid_env_key(self):
        valid_key = "sk-env-key-1234567890"
        with patch.dict(os.environ, {"MINIMAX_API_KEY": valid_key}, clear=True):
            self.assertEqual(resolve_minimax_api_key(), valid_key)

    def test_resolve_minimax_api_key_falls_back_to_bashrc_when_env_invalid(self):
        fallback_key = "sk-bashrc-key-1234567890"
        with (
            patch.dict(os.environ, {"MINIMAX_API_KEY": "not-a-real-key"}, clear=True),
            patch("orchestration.task_dispatcher._read_exported_shell_var") as mock_read_shell_var,
        ):
            mock_read_shell_var.side_effect = [fallback_key, ""]
            self.assertEqual(resolve_minimax_api_key(), fallback_key)

    def test_resolve_minimax_api_key_does_not_use_anthropic_keys(self):
        """Anthropic API keys must never be returned as MiniMax keys (credential leak)."""
        anthropic_key = "sk-ant-api03-abcdefghijklmnopqrstuvwxyz123456"
        with (
            patch.dict(
                os.environ,
                {"ANTHROPIC_API_KEY": anthropic_key, "ANTHROPIC_AUTH_TOKEN": anthropic_key},
                clear=True,
            ),
            patch("orchestration.task_dispatcher._read_exported_shell_var", return_value=""),
        ):
            result = resolve_minimax_api_key()
            self.assertNotEqual(result, anthropic_key, "Anthropic API key must not be used as MiniMax key")
            self.assertEqual(result, "", "Should return empty string when no MiniMax key is available")

    def test_resolve_minimax_api_key_rejects_anthropic_key_in_minimax_var(self):
        """Anthropic-format sk-ant-... keys must be rejected even if stored in MINIMAX_API_KEY."""
        anthropic_key = "sk-ant-api03-abcdefghijklmnopqrstuvwxyz123456"
        with (
            patch.dict(os.environ, {"MINIMAX_API_KEY": anthropic_key}, clear=True),
            patch("orchestration.task_dispatcher._read_exported_shell_var", return_value=""),
        ):
            result = resolve_minimax_api_key()
            self.assertEqual(result, "", "Anthropic sk-ant- key must be rejected even when set as MINIMAX_API_KEY")

    def test_resolve_minimax_api_key_accepts_valid_minimax_format(self):
        """Valid non-Anthropic sk- keys should be accepted."""
        valid_key = "sk-mm-1234567890abc"
        with (
            patch.dict(os.environ, {"MINIMAX_API_KEY": valid_key}, clear=True),
            patch("orchestration.task_dispatcher._read_exported_shell_var", return_value=""),
        ):
            self.assertEqual(resolve_minimax_api_key(), valid_key)

    def test_apply_minimax_auth_env_sets_both_anthropic_keys(self):
        minimax_key = "sk-auth-key-1234567890"
        with patch("orchestration.task_dispatcher.resolve_minimax_api_key", return_value=minimax_key):
            env = {}
            updated = apply_minimax_auth_env(env)

        self.assertIs(updated, env)
        self.assertEqual(updated["ANTHROPIC_API_KEY"], minimax_key)
        self.assertEqual(updated["ANTHROPIC_AUTH_TOKEN"], minimax_key)

    def test_minimax_command_uses_token_env_placeholder(self):
        agent_spec = {
            "name": "task-agent-minimax-secret-test",
            "focus": "Validate MiniMax token handling",
            "prompt": "Do the work",
            "capabilities": [],
            "type": "development",
            "cli": "minimax",
        }
        minimax_key = "sk-auth-key-1234567890"

        with (
            patch.object(self.dispatcher, "_cleanup_stale_prompt_files"),
            patch.object(self.dispatcher, "_get_active_tmux_agents", return_value=set()),
            patch.object(self.dispatcher, "_print_tmp_subdirectories"),
            patch.object(
                self.dispatcher,
                "_create_worktree_at_location",
                return_value=(
                    "/tmp/task-agent-minimax-secret-test",
                    MagicMock(returncode=0, stderr=""),
                ),
            ),
            patch("os.makedirs"),
            patch("os.chmod"),
            patch("builtins.open", mock_open()),
            patch("os.path.exists", return_value=False),
            patch("orchestration.task_dispatcher.Path.write_text") as mock_write_text,
            patch("orchestration.task_dispatcher.subprocess.run") as mock_run,
            patch("orchestration.task_dispatcher.shutil.which") as mock_which,
            patch.object(self.dispatcher, "_validate_cli_availability", return_value=True),
            patch("orchestration.task_dispatcher.resolve_minimax_api_key", return_value=minimax_key),
        ):

            def which_side_effect(command):
                known_binaries = {
                    "claude": "/usr/bin/claude",
                    "tmux": "/usr/bin/tmux",
                }
                return known_binaries.get(command)

            mock_which.side_effect = which_side_effect
            mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")

            result = self.dispatcher.create_dynamic_agent(agent_spec)

        self.assertTrue(result)
        self.assertGreater(len(mock_write_text.call_args_list), 0)
        script_contents = mock_write_text.call_args_list[0][0][0]
        self.assertIn('export ANTHROPIC_AUTH_TOKEN="${MINIMAX_AUTH_TOKEN}"', script_contents)
        self.assertIn('export ANTHROPIC_API_KEY="${MINIMAX_AUTH_TOKEN}"', script_contents)
        self.assertNotIn(minimax_key, script_contents)

        run_kwargs = mock_run.call_args.kwargs
        self.assertIn("env", run_kwargs)
        self.assertEqual(run_kwargs["env"].get("MINIMAX_AUTH_TOKEN"), minimax_key)

    def test_non_minimax_cli_path_does_not_inject_minimax_placeholder(self):
        agent_spec = {
            "name": "task-agent-non-minimax-path-test",
            "focus": "Ensure non-minimax CLI path unchanged",
            "prompt": "Do the work",
            "capabilities": [],
            "type": "development",
            "cli": "codex",
        }

        with (
            patch.object(self.dispatcher, "_cleanup_stale_prompt_files"),
            patch.object(self.dispatcher, "_get_active_tmux_agents", return_value=set()),
            patch.object(self.dispatcher, "_print_tmp_subdirectories"),
            patch.object(
                self.dispatcher,
                "_create_worktree_at_location",
                return_value=(
                    "/tmp/task-agent-non-minimax-path-test",
                    MagicMock(returncode=0, stderr=""),
                ),
            ),
            patch("os.makedirs"),
            patch("os.chmod"),
            patch("builtins.open", mock_open()),
            patch("os.path.exists", return_value=False),
            patch("orchestration.task_dispatcher.Path.write_text") as mock_write_text,
            patch("orchestration.task_dispatcher.subprocess.run") as mock_run,
            patch("orchestration.task_dispatcher.shutil.which") as mock_which,
            patch.object(self.dispatcher, "_validate_cli_availability", return_value=True),
            patch("orchestration.task_dispatcher.resolve_minimax_api_key", return_value="sk-auth-key-1234567890"),
        ):

            def which_side_effect(command):
                known_binaries = {
                    "codex": "/usr/bin/codex",
                    "tmux": "/usr/bin/tmux",
                }
                return known_binaries.get(command)

            mock_which.side_effect = which_side_effect
            mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")

            result = self.dispatcher.create_dynamic_agent(agent_spec)

        self.assertTrue(result)
        self.assertGreater(len(mock_write_text.call_args_list), 0)
        script_contents = mock_write_text.call_args_list[0][0][0]
        self.assertIn("codex exec --yolo", script_contents)
        self.assertNotIn("MINIMAX_AUTH_TOKEN", script_contents)

    def test_cli_chain_clears_minimax_env_before_non_minimax_fallback(self):
        """MiniMax env vars must be unset before non-MiniMax fallback attempts."""
        agent_spec = {
            "name": "task-agent-minimax-fallback-test",
            "focus": "Validate cleanup between CLI attempts",
            "prompt": "Do the work",
            "capabilities": [],
            "type": "development",
            "cli": "minimax",
            "cli_chain": ["minimax", "codex"],
        }
        minimax_key = "sk-auth-key-1234567890"

        with (
            patch.object(self.dispatcher, "_cleanup_stale_prompt_files"),
            patch.object(self.dispatcher, "_get_active_tmux_agents", return_value=set()),
            patch.object(self.dispatcher, "_print_tmp_subdirectories"),
            patch.object(
                self.dispatcher,
                "_create_worktree_at_location",
                return_value=(
                    "/tmp/task-agent-minimax-fallback-test",
                    MagicMock(returncode=0, stderr=""),
                ),
            ),
            patch("os.makedirs"),
            patch("os.chmod"),
            patch("builtins.open", mock_open()),
            patch("os.path.exists", return_value=False),
            patch("orchestration.task_dispatcher.Path.write_text") as mock_write_text,
            patch("orchestration.task_dispatcher.subprocess.run") as mock_run,
            patch("orchestration.task_dispatcher.shutil.which") as mock_which,
            patch.object(self.dispatcher, "_validate_cli_availability", return_value=True),
            patch("orchestration.task_dispatcher.resolve_minimax_api_key", return_value=minimax_key),
        ):

            def which_side_effect(command):
                known_binaries = {
                    "codex": "/usr/bin/codex",
                    "claude": "/usr/bin/claude",
                    "tmux": "/usr/bin/tmux",
                }
                return known_binaries.get(command)

            mock_which.side_effect = which_side_effect
            mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")

            result = self.dispatcher.create_dynamic_agent(agent_spec)

        self.assertTrue(result)
        self.assertGreater(len(mock_write_text.call_args_list), 0)
        script_contents = mock_write_text.call_args_list[0][0][0]

        attempt2_idx = script_contents.find("ATTEMPT_NUM=2")
        self.assertNotEqual(attempt2_idx, -1)
        attempt2_block = script_contents[attempt2_idx : attempt2_idx + 1200]
        self.assertIn("ATTEMPT_CLI=codex", attempt2_block)
        self.assertIn("unset ANTHROPIC_BASE_URL 2>/dev/null || true", attempt2_block)
        self.assertIn("unset ANTHROPIC_AUTH_TOKEN 2>/dev/null || true", attempt2_block)
        self.assertIn("unset ANTHROPIC_API_KEY 2>/dev/null || true", attempt2_block)

    def test_resolve_minimax_api_key_rejects_invalid_candidates(self):
        with (
            patch.dict(os.environ, {"MINIMAX_API_KEY": "bad-key", "OTHER_ENV": "also-bad"}, clear=True),
            patch("orchestration.task_dispatcher._read_exported_shell_var", return_value="still-bad"),
        ):
            self.assertEqual(resolve_minimax_api_key(), "")


class TestCursorCliIntegration(unittest.TestCase):
    """Tests for Cursor Agent CLI integration."""

    def setUp(self):
        self.dispatcher = TaskDispatcher()

    def test_cursor_profile_exists(self):
        """Cursor CLI profile should be registered in CLI_PROFILES."""
        self.assertIn("cursor", CLI_PROFILES)

    def test_cursor_profile_structure(self):
        """Cursor profile should have all required fields."""
        cursor = CLI_PROFILES["cursor"]
        required_fields = [
            "binary",
            "display_name",
            "generated_with",
            "co_author",
            "supports_continue",
            "conversation_dir",
            "continue_flag",
            "restart_env",
            "command_template",
            "stdin_template",
            "quote_prompt",
            "detection_keywords",
        ]
        for field in required_fields:
            self.assertIn(field, cursor, f"Missing field: {field}")

    def test_cursor_binary_name(self):
        """Cursor profile should use cursor-agent binary."""
        cursor = CLI_PROFILES["cursor"]
        self.assertEqual(cursor["binary"], "cursor-agent")

    def test_cursor_command_template(self):
        """Cursor command template should include -f flag, model placeholder and output format."""
        cursor = CLI_PROFILES["cursor"]
        template = cursor["command_template"]
        tokens = shlex.split(template)
        self.assertIn("-f", tokens, "Missing -f flag for non-interactive execution")
        self.assertIn("--model {model}", template, "Missing model placeholder for runtime substitution")
        self.assertIn("--output-format text", template)
        self.assertIn("-p @{prompt_file}", template)

    def test_cursor_detection_keywords(self):
        """Cursor should be detected by relevant keywords (not model names)."""
        cursor = CLI_PROFILES["cursor"]
        # Note: "grok" removed - model names should not trigger CLI selection
        # since the model is configurable via CURSOR_MODEL env var
        expected_keywords = ["cursor", "cursor-agent"]
        for keyword in expected_keywords:
            self.assertIn(keyword, cursor["detection_keywords"])
        # Ensure model name is NOT in detection keywords (decoupled concerns)
        self.assertNotIn("grok", cursor["detection_keywords"])

    def test_cursor_keyword_detection(self):
        """Task with cursor keywords should select cursor CLI."""
        with patch("orchestration.task_dispatcher.shutil.which") as mock_which:
            mock_which.side_effect = lambda cmd: f"/usr/bin/{cmd}" if cmd in ["claude", "cursor-agent"] else None

            task = "Use cursor to analyze the latest trends"
            agent_specs = self.dispatcher.analyze_task_and_create_agents(task)

        self.assertEqual(agent_specs[0]["cli"], "cursor")

    def test_cursor_forced_cli(self):
        """Forced CLI selection should work for cursor."""
        task = "Analyze the codebase for fresh insights"
        agent_specs = self.dispatcher.analyze_task_and_create_agents(task, forced_cli="cursor")
        self.assertEqual(agent_specs[0]["cli"], "cursor")

    def test_cursor_stdin_template(self):
        """Cursor uses /dev/null for stdin (prompt passed via -p flag)."""
        cursor = CLI_PROFILES["cursor"]
        self.assertEqual(cursor["stdin_template"], "/dev/null")
        self.assertFalse(cursor["quote_prompt"])

    def test_cursor_does_not_support_continue(self):
        """Cursor should not support conversation continuation."""
        cursor = CLI_PROFILES["cursor"]
        self.assertFalse(cursor["supports_continue"])
        self.assertIsNone(cursor["conversation_dir"])


def test_print_tmp_subdirectories_lists_dirs_only(caplog):
    dispatcher = TaskDispatcher()
    with tempfile.TemporaryDirectory() as temp_root:
        Path(temp_root, "orchestration_results").mkdir()
        Path(temp_root, "worldarchitectai").mkdir()
        Path(temp_root, "not_a_dir.txt").write_text("x", encoding="utf-8")

        with caplog.at_level(logging.INFO, logger="orchestration.task_dispatcher"):
            dispatcher._print_tmp_subdirectories(
                tmp_root=temp_root,
                max_entries=10,
                correlation_id="test-agent",
            )

    assert temp_root in caplog.text
    assert "orchestration_results" in caplog.text
    assert "worldarchitectai" in caplog.text
    assert "not_a_dir.txt" not in caplog.text
    records = [record for record in caplog.records if record.name == "orchestration.task_dispatcher"]
    assert records
    assert all(getattr(record, "correlation_id", None) == "test-agent" for record in records)


class TestCliValidation(unittest.TestCase):
    """Tests for pre-flight CLI validation (_validate_cli_availability)."""

    def setUp(self):
        self.dispatcher = TaskDispatcher()
        # Clear preflight cache to prevent test interference
        cache_dir = getattr(self.dispatcher, "preflight_cache_dir", "/tmp/orchestration_logs/preflight_cache")
        if os.path.exists(cache_dir):
            import shutil
            shutil.rmtree(cache_dir)
        os.makedirs(cache_dir, exist_ok=True)

    def _set_temp_log_root(self, tmp_root: str) -> None:
        """Point dispatcher artifacts at a temporary orchestration log root."""
        self.dispatcher.log_dir = os.path.join(tmp_root, "orchestration_logs")
        self.dispatcher.preflight_cache_dir = os.path.join(self.dispatcher.log_dir, "preflight_cache")
        os.makedirs(self.dispatcher.preflight_cache_dir, exist_ok=True)

    def test_preflight_cache_is_under_orchestration_logs_tmp_dir(self):
        """Preflight cache should live under the same /tmp log directory used by orchestration."""
        self.assertEqual(self.dispatcher.log_dir, "/tmp/orchestration_logs")
        self.assertEqual(
            self.dispatcher.preflight_cache_dir,
            "/tmp/orchestration_logs/preflight_cache",
        )

    def test_preflight_cache_hit_skips_validation_within_ttl(self):
        """Successful validation should be cached and reused for one hour."""
        with tempfile.TemporaryDirectory() as tmpdir:
            self._set_temp_log_root(tmpdir)

            with (
                patch("orchestration.task_dispatcher.validate_cli_two_phase") as mock_validate,
                patch("orchestration.task_dispatcher.time.time", return_value=1000.0),
            ):
                mock_validate.return_value = ValidationResult(
                    success=True,
                    phase="execution",
                    message="gemini execution test passed",
                    output_file=MagicMock(),
                )
                first = self.dispatcher._validate_cli_availability("gemini", "/usr/bin/gemini", "test-agent")
                self.assertTrue(first)
                mock_validate.assert_called_once()

            cache_files = list(Path(self.dispatcher.preflight_cache_dir).glob("*.json"))
            self.assertTrue(cache_files, "Expected preflight cache file to be written")

            with (
                patch("orchestration.task_dispatcher.validate_cli_two_phase") as mock_validate_again,
                patch("orchestration.task_dispatcher.time.time", return_value=1200.0),
            ):
                second = self.dispatcher._validate_cli_availability("gemini", "/usr/bin/gemini", "test-agent")
                self.assertTrue(second)
                mock_validate_again.assert_not_called()

    def test_preflight_cache_expires_after_one_hour(self):
        """Expired cache entries should trigger a fresh validation run."""
        with tempfile.TemporaryDirectory() as tmpdir:
            self._set_temp_log_root(tmpdir)

            with (
                patch("orchestration.task_dispatcher.validate_cli_two_phase") as mock_validate,
                patch("orchestration.task_dispatcher.time.time", return_value=1000.0),
            ):
                mock_validate.return_value = ValidationResult(
                    success=True,
                    phase="execution",
                    message="gemini execution test passed",
                    output_file=MagicMock(),
                )
                self.assertTrue(self.dispatcher._validate_cli_availability("gemini", "/usr/bin/gemini", "test-agent"))
                mock_validate.assert_called_once()

            with (
                patch("orchestration.task_dispatcher.validate_cli_two_phase") as mock_validate_again,
                patch("orchestration.task_dispatcher.time.time", return_value=5000.0),
            ):
                mock_validate_again.return_value = ValidationResult(
                    success=True,
                    phase="execution",
                    message="gemini execution test passed",
                    output_file=MagicMock(),
                )
                self.assertTrue(self.dispatcher._validate_cli_availability("gemini", "/usr/bin/gemini", "test-agent"))
                mock_validate_again.assert_called_once()

    def test_preflight_cache_corrupt_file_falls_back_to_validation(self):
        """Corrupt cache files should be ignored safely and revalidated."""
        with tempfile.TemporaryDirectory() as tmpdir:
            self._set_temp_log_root(tmpdir)

            with (
                patch("orchestration.task_dispatcher.validate_cli_two_phase") as mock_validate,
                patch("orchestration.task_dispatcher.time.time", return_value=1000.0),
            ):
                mock_validate.return_value = ValidationResult(
                    success=True,
                    phase="execution",
                    message="gemini execution test passed",
                    output_file=MagicMock(),
                )
                self.assertTrue(self.dispatcher._validate_cli_availability("gemini", "/usr/bin/gemini", "test-agent"))

            cache_files = list(Path(self.dispatcher.preflight_cache_dir).glob("*.json"))
            self.assertTrue(cache_files, "Expected preflight cache file to exist for corruption test")
            cache_files[0].write_text("{not valid json", encoding="utf-8")

            with (
                patch("orchestration.task_dispatcher.validate_cli_two_phase") as mock_validate_again,
                patch("orchestration.task_dispatcher.time.time", return_value=1200.0),
            ):
                mock_validate_again.return_value = ValidationResult(
                    success=True,
                    phase="execution",
                    message="gemini execution test passed",
                    output_file=MagicMock(),
                )
                self.assertTrue(self.dispatcher._validate_cli_availability("gemini", "/usr/bin/gemini", "test-agent"))
                mock_validate_again.assert_called_once()

    def test_gemini_validation_success_with_exit_code_0(self):
        """Gemini validation should succeed when exit code is 0 and output file is created."""
        with patch("orchestration.task_dispatcher.validate_cli_two_phase") as mock_validate:
            mock_validate.return_value = ValidationResult(
                success=True,
                phase="execution",
                message="gemini execution test passed",
                output_file=MagicMock(),
            )
            result = self.dispatcher._validate_cli_availability("gemini", "/usr/bin/gemini", "test-agent")
            self.assertTrue(result)
            mock_validate.assert_called_once()

    def test_gemini_validation_fails_with_quota_error(self):
        """Gemini validation should fail when quota/rate limit is detected."""
        quota_messages = [
            "exhausted your capacity",
            "exhausted your daily quota",
            "rate limit",
            "quota exceeded",
            "resource_exhausted",
        ]
        for quota_msg in quota_messages:
            with patch("orchestration.task_dispatcher.validate_cli_two_phase") as mock_validate:
                mock_validate.return_value = ValidationResult(
                    success=False,
                    phase="execution",
                    message=f"gemini quota/rate limit detected: {quota_msg}",
                )
                result = self.dispatcher._validate_cli_availability("gemini", "/usr/bin/gemini", "test-agent")
                self.assertFalse(result, f"Should fail for quota message: {quota_msg}")

    def test_gemini_validation_fails_with_non_zero_exit_code(self):
        """Gemini validation should fail when exit code is non-zero (unless quota error)."""
        with patch("orchestration.task_dispatcher.validate_cli_two_phase") as mock_validate:
            mock_validate.return_value = ValidationResult(
                success=False,
                phase="execution",
                message="gemini execution test failed (exit code 1)",
            )
            result = self.dispatcher._validate_cli_availability("gemini", "/usr/bin/gemini", "test-agent")
            self.assertFalse(result)

    def test_gemini_validation_timeout_returns_false(self):
        """Gemini validation timeout should return False (fail-safe, try next CLI)."""
        with patch("orchestration.task_dispatcher.validate_cli_two_phase") as mock_validate:
            mock_validate.return_value = ValidationResult(
                success=False,
                phase="execution",
                message="gemini execution test timed out (CLI unresponsive)",
            )
            result = self.dispatcher._validate_cli_availability("gemini", "/usr/bin/gemini", "test-agent")
            self.assertFalse(result)

    def test_gemini_validation_exception_returns_false(self):
        """Gemini validation exception should return False (fail-safe, try next CLI)."""
        with patch("orchestration.task_dispatcher.validate_cli_two_phase") as mock_validate:
            mock_validate.return_value = ValidationResult(
                success=False,
                phase="execution",
                message="gemini execution test error: Network error",
            )
            result = self.dispatcher._validate_cli_availability("gemini", "/usr/bin/gemini", "test-agent")
            self.assertFalse(result)

    def test_codex_validation_success_with_exit_code_0(self):
        """Codex validation should succeed when exit code is 0 and output file is created."""
        with patch("orchestration.task_dispatcher.validate_cli_two_phase") as mock_validate:
            mock_validate.return_value = ValidationResult(
                success=True,
                phase="execution",
                message="codex execution test passed",
                output_file=MagicMock(),
            )
            result = self.dispatcher._validate_cli_availability("codex", "/usr/bin/codex", "test-agent")
            self.assertTrue(result)

    def test_codex_validation_success_with_help_output(self):
        """Codex validation should succeed when help/version output is recognized."""
        with patch("orchestration.task_dispatcher.validate_cli_two_phase") as mock_validate:
            mock_validate.return_value = ValidationResult(
                success=True,
                phase="execution",
                message="codex execution test passed (help/version detected as fallback)",
            )
            result = self.dispatcher._validate_cli_availability("codex", "/usr/bin/codex", "test-agent")
            self.assertTrue(result)

    def test_codex_validation_success_with_version_output(self):
        """Codex validation should succeed when version output is recognized."""
        with patch("orchestration.task_dispatcher.validate_cli_two_phase") as mock_validate:
            mock_validate.return_value = ValidationResult(
                success=True,
                phase="execution",
                message="codex execution test passed (help/version detected as fallback)",
            )
            result = self.dispatcher._validate_cli_availability("codex", "/usr/bin/codex", "test-agent")
            self.assertTrue(result)

    def test_codex_validation_fails_with_unrecognized_error(self):
        """Codex validation should fail when exit code is non-zero and output is unrecognized."""
        with patch("orchestration.task_dispatcher.validate_cli_two_phase") as mock_validate:
            mock_validate.return_value = ValidationResult(
                success=False,
                phase="execution",
                message="codex execution test failed (exit code 1)",
            )
            result = self.dispatcher._validate_cli_availability("codex", "/usr/bin/codex", "test-agent")
            self.assertFalse(result)

    def test_codex_validation_timeout_returns_false(self):
        """Codex validation timeout should return False (fail-safe, try next CLI)."""
        with patch("orchestration.task_dispatcher.validate_cli_two_phase") as mock_validate:
            mock_validate.return_value = ValidationResult(
                success=False,
                phase="execution",
                message="codex execution test timed out (CLI unresponsive)",
            )
            result = self.dispatcher._validate_cli_availability("codex", "/usr/bin/codex", "test-agent")
            self.assertFalse(result)

    def test_codex_validation_exception_returns_false(self):
        """Codex validation exception should return False (fail-safe, try next CLI)."""
        with patch("orchestration.task_dispatcher.validate_cli_two_phase") as mock_validate:
            mock_validate.return_value = ValidationResult(
                success=False,
                phase="execution",
                message="codex execution test error: Network error",
            )
            result = self.dispatcher._validate_cli_availability("codex", "/usr/bin/codex", "test-agent")
            self.assertFalse(result)

    def test_codex_validation_omits_model_when_unspecified(self):
        """Codex preflight should omit explicit --model when no model is provided."""
        with patch("orchestration.task_dispatcher.validate_cli_two_phase") as mock_validate:
            mock_validate.return_value = ValidationResult(
                success=True,
                phase="execution",
                message="codex execution test passed",
            )
            result = self.dispatcher._validate_cli_availability(
                "codex",
                "/usr/bin/codex",
                "test-agent",
                model=None,
            )

            self.assertTrue(result)
            call_args = mock_validate.call_args
            execution_cmd = call_args[1].get("execution_cmd", call_args[0][3] if len(call_args[0]) > 3 else [])
            self.assertEqual(execution_cmd, ["exec", "--yolo", "--skip-git-repo-check"])

    def test_claude_validation_success_with_executable(self):
        """Claude validation should succeed when binary is executable and can write output."""
        with (
            patch("orchestration.task_dispatcher.os.access") as mock_access,
            patch("orchestration.task_dispatcher.validate_cli_two_phase") as mock_validate,
        ):
            mock_access.return_value = True
            mock_validate.return_value = ValidationResult(
                success=True,
                phase="execution",
                message="claude execution test passed",
                output_file=MagicMock(),
            )
            result = self.dispatcher._validate_cli_availability("claude", "/usr/bin/claude", "test-agent")
            self.assertTrue(result)

    def test_claude_validation_fails_with_non_executable(self):
        """Claude validation should fail when binary is not executable."""
        with patch("orchestration.task_dispatcher.os.access") as mock_access:
            mock_access.return_value = False
            # Should return False before calling validate_cli_two_phase
            result = self.dispatcher._validate_cli_availability("claude", "/usr/bin/claude", "test-agent")
            self.assertFalse(result)

    def test_cursor_validation_success_with_executable(self):
        """Cursor validation should succeed when binary is executable and can write output."""
        with (
            patch("orchestration.task_dispatcher.os.access") as mock_access,
            patch("orchestration.task_dispatcher.validate_cli_two_phase") as mock_validate,
        ):
            mock_access.return_value = True
            mock_validate.return_value = ValidationResult(
                success=True,
                phase="execution",
                message="cursor execution test passed",
                output_file=MagicMock(),
            )
            result = self.dispatcher._validate_cli_availability("cursor", "/usr/bin/cursor-agent", "test-agent")
            self.assertTrue(result)

    def test_cursor_validation_fails_with_non_executable(self):
        """Cursor validation should fail when binary is not executable."""
        with patch("orchestration.task_dispatcher.os.access") as mock_access:
            mock_access.return_value = False
            # Should return False before calling validate_cli_two_phase
            result = self.dispatcher._validate_cli_availability("cursor", "/usr/bin/cursor-agent", "test-agent")
            self.assertFalse(result)

    def test_unknown_cli_type_returns_true(self):
        """Unknown CLI types should return True with warning (allows runtime fallback)."""
        with patch("builtins.print") as mock_print:
            result = self.dispatcher._validate_cli_availability("unknown-cli", "/usr/bin/unknown", "test-agent")
            self.assertTrue(result)
            # Verify warning was printed
            mock_print.assert_called()
            call_args = str(mock_print.call_args)
            self.assertIn("Unknown CLI type", call_args)
            self.assertIn("test-agent", call_args)

    def test_validation_includes_agent_name_in_logs(self):
        """Validation should include agent_name in all log messages."""
        with patch("builtins.print") as mock_print, patch(
            "orchestration.task_dispatcher.subprocess.run"
        ) as mock_run:
            mock_run.return_value = MagicMock(returncode=1, stdout="", stderr="Error")
            self.dispatcher._validate_cli_availability("gemini", "/usr/bin/gemini", "my-test-agent")
            # Check that agent_name appears in log messages
            calls = [str(call) for call in mock_print.call_args_list]
            agent_name_found = any("my-test-agent" in call for call in calls)
            self.assertTrue(agent_name_found, "agent_name should appear in log messages")

    def test_validation_exception_handling_includes_agent_name(self):
        """Exception handling should include agent_name in log messages and return False."""
        # Patch cli_validation.subprocess.run since that's where validation actually runs
        with patch("builtins.print") as mock_print, patch(
            "orchestration.cli_validation.subprocess.run"
        ) as mock_run:
            mock_run.side_effect = Exception("Test error")
            result = self.dispatcher._validate_cli_availability("gemini", "/usr/bin/gemini", "error-test-agent")
            # Changed behavior: exceptions now return False (fail-safe)
            self.assertFalse(result)
            # Verify exception log includes agent name
            calls = [str(call) for call in mock_print.call_args_list]
            agent_name_found = any("error-test-agent" in call for call in calls)
            self.assertTrue(agent_name_found, "agent_name should appear in exception log")

    def test_all_cli_validations_skip_mcp_servers(self):
        """All CLI validations should use flags to skip MCP server loading for faster validation."""
        # This test verifies that the execution_cmd for each CLI includes MCP-skip flags
        # MCP server loading adds 4-6 seconds to validation; skipping it makes validation ~2s
        with patch("orchestration.task_dispatcher.validate_cli_two_phase") as mock_validate:
            mock_validate.return_value = ValidationResult(
                success=True,
                phase="execution",
                message="test passed",
            )

            # Test Gemini - should have --allowed-mcp-server-names none
            with patch("os.access", return_value=True):
                self.dispatcher._validate_cli_availability("gemini", "/usr/bin/gemini", "test-agent")
                call_args = mock_validate.call_args
                execution_cmd = call_args[1].get("execution_cmd", call_args[0][3] if len(call_args[0]) > 3 else [])
                self.assertIn("--allowed-mcp-server-names", execution_cmd,
                    "Gemini validation should skip MCP servers with --allowed-mcp-server-names")
                self.assertIn("none", execution_cmd,
                    "Gemini validation should use 'none' for --allowed-mcp-server-names")

            mock_validate.reset_mock()

            # Test Claude - should use --strict-mcp-config to skip MCP server loading
            # Verified: `claude --help` shows --strict-mcp-config "Only uses MCP servers from --mcp-config"
            # Using --strict-mcp-config WITHOUT --mcp-config = no MCP servers loaded = faster validation
            with patch("os.access", return_value=True):
                self.dispatcher._validate_cli_availability("claude", "/usr/bin/claude", "test-agent")
                call_args = mock_validate.call_args
                execution_cmd = call_args[1].get("execution_cmd", call_args[0][3] if len(call_args[0]) > 3 else [])
                # Claude SHOULD have --strict-mcp-config to skip MCP server loading
                self.assertIn("--strict-mcp-config", execution_cmd,
                    "Claude validation should use --strict-mcp-config to skip MCP server loading")

            mock_validate.reset_mock()

            # Test Cursor - should have --approve-mcps or similar MCP handling
            # Note: Cursor may not have a skip-MCP flag, but should at least auto-approve
            with patch("os.access", return_value=True):
                self.dispatcher._validate_cli_availability("cursor", "/usr/bin/cursor-agent", "test-agent")
                call_args = mock_validate.call_args
                execution_cmd = call_args[1].get("execution_cmd", call_args[0][3] if len(call_args[0]) > 3 else [])
                # Cursor should have some MCP handling flag
                has_mcp_flag = "--approve-mcps" in execution_cmd or "--no-mcp" in execution_cmd
                self.assertTrue(has_mcp_flag,
                    f"Cursor validation should have MCP handling flag, got: {execution_cmd}")

    def test_strict_answer_matching_avoids_false_positives(self):
        """Verify strict answer matching avoids false positives from numbers and dates."""
        strict_match_pattern = _build_validation_answer_regex()

        # These should NOT match (false positives we want to avoid)
        # Ensure we only match the full answer when it is bounded by non-digit characters.
        false_positive_cases = [
            (
                f"prefix-{EXPECTED_VALIDATION_ANSWER}0-suffix",
                "expected answer with trailing digit",
            ),
            (
                f"prefix-0{EXPECTED_VALIDATION_ANSWER}-suffix",
                "expected answer with leading digit",
            ),
            (
                f"prefix-{EXPECTED_VALIDATION_ANSWER}99- suffix",
                "expected answer followed by extra digits",
            ),
            (
                f"prefix-11{EXPECTED_VALIDATION_ANSWER}22-suffix",
                "expected answer nested inside larger digit token",
            ),
        ]

        for case, description in false_positive_cases:
            match = strict_match_pattern.search(case)
            self.assertIsNone(match, f"Should NOT match {description}: '{case}'")

        # These SHOULD match (valid answers to the configured validation prompt)
        # Note: The regex matches normalized answer, so we normalize before matching
        valid_cases = [
            EXPECTED_VALIDATION_ANSWER,  # Just the answer
            f"{int(EXPECTED_VALIDATION_ANSWER):,}",  # Comma grouped
            f"{int(EXPECTED_VALIDATION_ANSWER):_}",  # Underscore grouped
            EXPECTED_VALIDATION_ANSWER,  # Exact canonical form
        ]

        for case in valid_cases:
            normalized = _normalize_validation_output_line(case)
            match = strict_match_pattern.fullmatch(normalized)
            self.assertIsNotNone(match, f"Valid answer should match: '{case}' -> normalized: '{normalized}'")


class TestAgentCreationWithValidation(unittest.TestCase):
    """Integration tests that verify agent creation actually works with validation."""

    def setUp(self):
        self.dispatcher = TaskDispatcher()

    def test_agent_creation_with_gemini_validation_success(self):
        """Agent creation should succeed when Gemini validation passes."""
        agent_spec = {
            "name": "test-agent-gemini-validation",
            "focus": "Test Gemini validation in agent creation",
            "prompt": "Test prompt",
            "capabilities": [],
            "type": "development",
            "cli": "gemini",
            "skip_preflight": False,  # Opt-in: exercise preflight validation path
        }

        with (
            patch.object(self.dispatcher, "_cleanup_stale_prompt_files"),
            patch.object(self.dispatcher, "_get_active_tmux_agents", return_value=set()),
            patch.object(self.dispatcher, "_print_tmp_subdirectories"),
            patch.object(
                self.dispatcher,
                "_create_worktree_at_location",
                return_value=("/tmp/test-agent-gemini-validation", MagicMock(returncode=0, stderr="")),
            ),
            patch("os.makedirs"),
            patch("os.chmod"),
            patch("builtins.open", mock_open()),
            patch("os.path.exists", return_value=False),
            patch("orchestration.task_dispatcher.Path.write_text") as mock_write_text,
            patch("orchestration.task_dispatcher.subprocess.run") as mock_run,
            patch("orchestration.task_dispatcher.shutil.which") as mock_which,
            patch("orchestration.task_dispatcher.validate_cli_two_phase") as mock_validate,
        ):
            def which_side_effect(command):
                known_binaries = {
                    "gemini": "/usr/bin/gemini",
                    "tmux": "/usr/bin/tmux",
                }
                return known_binaries.get(command)

            mock_which.side_effect = which_side_effect
            
            # Mock validation to succeed
            mock_validate.return_value = ValidationResult(
                success=True,
                phase="execution",
                message="gemini execution test passed",
                output_file=MagicMock(),
            )

            # Mock agent execution call
            mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")

            result = self.dispatcher.create_dynamic_agent(agent_spec)

        self.assertTrue(result, "Agent creation should succeed when validation passes")
        # Verify validation was called
        mock_validate.assert_called()

    def test_agent_creation_with_gemini_validation_failure_fails(self):
        """Agent creation should fail when Gemini validation fails (no automatic fallback)."""
        agent_spec = {
            "name": "test-agent-gemini-fallback",
            "focus": "Test failure when Gemini validation fails",
            "prompt": "Test prompt",
            "capabilities": [],
            "type": "development",
            "cli": "gemini",
            "skip_preflight": False,  # Opt-in: exercise preflight validation path
        }

        with (
            patch.object(self.dispatcher, "_cleanup_stale_prompt_files"),
            patch.object(self.dispatcher, "_get_active_tmux_agents", return_value=set()),
            patch.object(self.dispatcher, "_print_tmp_subdirectories"),
            patch.object(
                self.dispatcher,
                "_create_worktree_at_location",
                return_value=("/tmp/test-agent-gemini-fallback", MagicMock(returncode=0, stderr="")),
            ),
            patch("os.makedirs"),
            patch("os.chmod"),
            patch("builtins.open", mock_open()),
            patch("os.path.exists", return_value=False),
            patch("orchestration.task_dispatcher.Path.write_text") as mock_write_text,
            patch("orchestration.task_dispatcher.subprocess.run") as mock_run,
            patch("orchestration.task_dispatcher.shutil.which") as mock_which,
            patch.object(self.dispatcher, "_validate_cli_availability") as mock_validate_method,
        ):
            def which_side_effect(command):
                known_binaries = {
                    "gemini": "/usr/bin/gemini",
                    "codex": "/usr/bin/codex",
                    "tmux": "/usr/bin/tmux",
                }
                return known_binaries.get(command)

            mock_which.side_effect = which_side_effect
            
            # Mock validation: Gemini fails (no fallback attempted)
            def validate_side_effect(cli_name, cli_path, agent_name, model=None):
                if cli_name == "gemini":
                    return False
                return False
            
            mock_validate_method.side_effect = validate_side_effect

            # Mock agent execution call
            mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")

            result = self.dispatcher.create_dynamic_agent(agent_spec)

        # Should fail because Gemini validation failed and no fallback occurs
        self.assertFalse(result, "Agent creation should fail when validation fails")
        # CLI should remain unchanged (no fallback)
        self.assertEqual(agent_spec["cli"], "gemini", "Should not fall back to Codex when Gemini fails")
        # Verify only Gemini validation was attempted (no fallback validation)
        validation_calls = mock_validate_method.call_args_list

        def _extract_cli_name(call):
            if call[0]:
                return call[0][0]
            return call[1].get("cli_name")

        gemini_calls = [c for c in validation_calls if _extract_cli_name(c) == "gemini"]
        codex_calls = [c for c in validation_calls if _extract_cli_name(c) == "codex"]
        self.assertGreater(len(gemini_calls), 0, "Gemini validation should be attempted")
        self.assertEqual(len(codex_calls), 0, "Codex fallback validation should NOT be attempted")

    def test_agent_creation_fails_when_all_validations_fail(self):
        """Agent creation should fail when all CLI validations fail."""
        agent_spec = {
            "name": "test-agent-all-fail",
            "focus": "Test failure when all validations fail",
            "prompt": "Test prompt",
            "capabilities": [],
            "type": "development",
            "cli": "gemini",
        }

        with (
            patch.object(self.dispatcher, "_cleanup_stale_prompt_files"),
            patch.object(self.dispatcher, "_get_active_tmux_agents", return_value=set()),
            patch.object(self.dispatcher, "_print_tmp_subdirectories"),
            patch("orchestration.task_dispatcher.shutil.which") as mock_which,
            patch("orchestration.task_dispatcher.validate_cli_two_phase") as mock_validate,
        ):
            def which_side_effect(command):
                known_binaries = {
                    "gemini": "/usr/bin/gemini",
                    "codex": "/usr/bin/codex",
                    "claude": "/usr/bin/claude",
                    "cursor": "/usr/bin/cursor-agent",
                    "tmux": "/usr/bin/tmux",
                }
                return known_binaries.get(command)

            mock_which.side_effect = which_side_effect
            
            # Mock all validations to fail
            mock_validate.return_value = ValidationResult(
                success=False,
                phase="execution",
                message="validation failed",
            )
            
            # Mock all validations to fail
            with patch("orchestration.task_dispatcher.subprocess.run") as mock_run:
                # All validations fail (quota/errors)
                mock_run.return_value = MagicMock(returncode=1, stdout="", stderr="exhausted your daily quota")
                
                result = self.dispatcher.create_dynamic_agent(agent_spec)

        self.assertFalse(result, "Agent creation should fail when all validations fail")

    def test_agent_creation_logs_validation_steps(self):
        """Agent creation should log validation steps for debugging."""
        agent_spec = {
            "name": "test-agent-logging",
            "focus": "Test validation logging",
            "prompt": "Test prompt",
            "capabilities": [],
            "type": "development",
            "cli": "gemini",
        }

        with (
            patch.object(self.dispatcher, "_cleanup_stale_prompt_files"),
            patch.object(self.dispatcher, "_get_active_tmux_agents", return_value=set()),
            patch.object(self.dispatcher, "_print_tmp_subdirectories"),
            patch.object(
                self.dispatcher,
                "_create_worktree_at_location",
                return_value=("/tmp/test-agent-logging", MagicMock(returncode=0, stderr="")),
            ),
            patch("os.makedirs"),
            patch("os.chmod"),
            patch("builtins.open", mock_open()),
            patch("os.path.exists", return_value=False),
            patch("orchestration.task_dispatcher.Path.write_text"),
            patch("orchestration.task_dispatcher.subprocess.run") as mock_run,
            patch("orchestration.task_dispatcher.shutil.which") as mock_which,
            patch("builtins.print") as mock_print,
        ):
            def which_side_effect(command):
                known_binaries = {
                    "gemini": "/usr/bin/gemini",
                    "tmux": "/usr/bin/tmux",
                }
                return known_binaries.get(command)

            mock_which.side_effect = which_side_effect
            mock_run.return_value = MagicMock(returncode=0, stdout="ok", stderr="")

            self.dispatcher.create_dynamic_agent(agent_spec)

        # Verify validation logging occurred
        print_calls = [str(call) for call in mock_print.call_args_list]
        validation_logs = [call for call in print_calls if "validation" in call.lower() or "validating" in call.lower()]
        self.assertGreater(len(validation_logs), 0, "Validation steps should be logged")
        
        # Verify agent name appears in logs
        agent_name_logs = [call for call in print_calls if "test-agent-logging" in call]
        self.assertGreater(len(agent_name_logs), 0, "Agent name should appear in validation logs")


class TestCoerceCliArgs(unittest.TestCase):
    """Tests for shared CLI argument coercion helper."""

    def test_none_returns_empty_list(self):
        self.assertEqual(cli_arg_utils.coerce_cli_args(None), [])

    def test_empty_string_returns_empty_list(self):
        self.assertEqual(cli_arg_utils.coerce_cli_args(""), [])
        self.assertEqual(cli_arg_utils.coerce_cli_args("   "), [])

    def test_list_values_are_stringified(self):
        self.assertEqual(
            cli_arg_utils.coerce_cli_args(["--flag", "value", None, "", "  "]),
            ["--flag", "value"],
        )
        self.assertEqual(
            cli_arg_utils.coerce_cli_args((1, 2, "three", "")),
            ["1", "2", "three"],
        )

    def test_bytes_are_decoded_and_split_like_string(self):
        self.assertEqual(
            cli_arg_utils.coerce_cli_args(b'--name "x y" --flag'),
            ["--name", "x y", "--flag"],
        )

    def test_shlex_parsing_preserves_quoted_tokens(self):
        self.assertEqual(
            cli_arg_utils.coerce_cli_args('--foo "bar baz" --no-run'),
            ["--foo", "bar baz", "--no-run"],
        )

    def test_malformed_quote_falls_back_to_whitespace_split(self):
        self.assertEqual(
            cli_arg_utils.coerce_cli_args('--foo "bar baz --flag'),
            ["--foo", '"bar', "baz", "--flag"],
        )

    def test_scalar_values_become_single_token(self):
        self.assertEqual(cli_arg_utils.coerce_cli_args(0), ["0"])
        self.assertEqual(cli_arg_utils.coerce_cli_args({"a": 1}), ["{'a': 1}"])


if __name__ == "__main__":
    unittest.main()
