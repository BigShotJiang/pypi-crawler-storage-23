import socket
import logging
import re

# Hostname/IP detection
class MachineIPDetector:
    def get_info(self):
        try:
            hostname = socket.gethostname()
            ip_address = socket.gethostbyname(hostname)
            logging.debug(f"Detected machine IP address: {ip_address}, hostname: {hostname}")
            return ip_address, hostname
        except Exception as e:
            logging.error(f"Error detecting machine IP/hostname: {e}")
            return "Unknown", "Unknown"
        
    def resolve_hostname(self,ip: str) -> str:
        try:
            hostname, _, _ = socket.gethostbyaddr(ip)
            return hostname
        except Exception as e:
            logging.warning(f"Could not resolve hostname for IP {ip}: {e}")
            return "unknown"
        
    def get_real_client_ip(self,request):
        # FastAPI: request.headers is a case-insensitive dict-like object
        x_forwarded_for = request.headers.get("x-forwarded-for")
        if x_forwarded_for:
            return x_forwarded_for.split(',')[0].strip()
        # Fallback to request.client.host
        if hasattr(request, "client") and request.client:
            return request.client.host
        return ""
        
#### Function to extract browser info from Sec-CH-UA header
def extract_browser_from_sec_ch_ua(sec_ch_ua):
    """
    Extract browser name and version from Sec-CH-UA header.

    Example:
    "Not:A-Brand";v="99", "Google Chrome";v="145", "Chromium";v="145"

    Returns:
    Google Chrome 145
    """

    if not sec_ch_ua:
        return None

    # capture all "Brand";v="Version"
    pairs = re.findall(r'"([^"]+)";v="([^"]+)"', sec_ch_ua)

    if not pairs:
        return None

    # remove Not:A-Brand entries
    filtered = [(brand, version) for brand, version in pairs
                if brand.lower() != "not:a-brand"]

    # return first valid browser
    if filtered:
        brand, version = filtered[0]
        return f"{brand} {version}"

    return None