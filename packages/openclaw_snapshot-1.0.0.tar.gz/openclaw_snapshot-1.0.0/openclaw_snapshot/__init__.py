# -*- coding: utf-8 -*-
"""
🦞💾 OpenClaw Snapshot
智能备份与恢复工具
"""

__version__ = "1.0.0"
__author__ = "Duka Works"
__email__ = "chenzhy.bj@gmail.com"
