from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version


def _safe_version(dist_name: str) -> str:
    try:
        return version(dist_name)
    except PackageNotFoundError:
        return "<not installed>"


def main() -> None:
    print(f"masster-light distribution version: {_safe_version('masster-light')}")
    print(f"masster distribution version:       {_safe_version('masster')}")
    print(f"masster-dist distribution version:  {_safe_version('masster-dist')}")
