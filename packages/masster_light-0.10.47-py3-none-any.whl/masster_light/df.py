from __future__ import annotations

from collections.abc import Iterable
from pathlib import Path
from typing import Any

import polars as pl


def select(df: pl.DataFrame, columns: Iterable[str]) -> pl.DataFrame:
    cols = [c for c in columns if c in df.columns]
    return df.select(cols)


def filter_eq(df: pl.DataFrame, **equals: Any) -> pl.DataFrame:
    exprs: list[pl.Expr] = []
    for col, val in equals.items():
        if col not in df.columns:
            continue
        exprs.append(pl.col(col) == val)
    if not exprs:
        return df
    expr = exprs[0]
    for e in exprs[1:]:
        expr = expr & e
    return df.filter(expr)


def export_csv(df: pl.DataFrame, path: str | Path) -> None:
    df.write_csv(path)


def export_parquet(df: pl.DataFrame, path: str | Path) -> None:
    df.write_parquet(path)
