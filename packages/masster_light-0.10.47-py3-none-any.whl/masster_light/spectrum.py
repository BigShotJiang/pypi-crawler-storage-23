from __future__ import annotations

from dataclasses import dataclass
import json
from typing import Any

from bokeh.plotting import figure, show
import numpy as np


@dataclass
class Spectrum:
    mz: np.ndarray
    inty: np.ndarray
    ms_level: int | None = None
    label: str | None = None

    def __post_init__(self) -> None:
        self.mz = np.asarray(self.mz, dtype=np.float64)
        self.inty = np.asarray(self.inty, dtype=np.float64)

    @classmethod
    def from_json(cls, payload: str) -> Spectrum:
        data = json.loads(payload)
        mz = np.asarray(data.get("mz", []), dtype=np.float64)
        inty = np.asarray(data.get("inty", []), dtype=np.float64)
        ms_level = data.get("ms_level")
        label = data.get("label")
        spec = cls(mz=mz, inty=inty, ms_level=ms_level, label=label)
        for key, value in data.items():
            if key in {"mz", "inty", "ms_level", "label"}:
                continue
            setattr(spec, key, value)
        return spec

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "mz": self.mz.tolist(),
            "inty": self.inty.tolist(),
            "ms_level": self.ms_level,
            "label": self.label,
        }
        for key, value in getattr(self, "__dict__", {}).items():
            if key not in d:
                d[key] = value
        return d

    def plot(self, title: str | None = None, show_plot: bool = True):
        p = figure(
            title=title or (self.label or "Spectrum"),
            x_axis_label="m/z",
            y_axis_label="Intensity",
        )
        p.vbar(x=self.mz, top=self.inty, width=0.05, line_color=None)
        if show_plot:
            show(p)
        return p
