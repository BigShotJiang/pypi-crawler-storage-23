from __future__ import annotations

from collections.abc import Iterable
from pathlib import Path

import polars as pl

from masster_light.errors import NeedsFullMassterError
from masster_light.spectrum import Spectrum


def export_excel(
    df: pl.DataFrame,
    path: str | Path,
    *,
    sheet_name: str = "data",
) -> None:
    try:
        import pandas as pd
    except ModuleNotFoundError as exc:
        raise NeedsFullMassterError(
            "Excel export requires optional dependencies: pip install 'masster-light[excel]'",
        ) from exc

    pdf = df.to_pandas()
    with pd.ExcelWriter(path) as writer:
        pdf.to_excel(writer, sheet_name=sheet_name, index=False)


def export_mgf(
    spectra: Iterable[Spectrum],
    path: str | Path,
    *,
    title_prefix: str = "spectrum",
) -> None:
    p = Path(path)
    with p.open("w", encoding="utf-8", newline="\n") as f:
        for i, spec in enumerate(spectra):
            f.write("BEGIN IONS\n")
            title = spec.label or f"{title_prefix}_{i}"
            f.write(f"TITLE={title}\n")
            for mz, intensity in zip(list(spec.mz), list(spec.inty), strict=False):
                f.write(f"{mz} {intensity}\n")
            f.write("END IONS\n\n")
