class UnsupportedFileError(ValueError):
    pass


class NeedsFullMassterError(RuntimeError):
    pass
