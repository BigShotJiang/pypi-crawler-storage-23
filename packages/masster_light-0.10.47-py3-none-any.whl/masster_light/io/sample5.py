from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import h5py
import numpy as np
import polars as pl

from masster_light.chromatogram import Chromatogram
from masster_light.spectrum import Spectrum
from masster_light.util import decode_h5_str, ensure_path, json_loads_maybe


def _decode_dataset_strings(values: Any) -> list[str]:
    out: list[str] = []
    for item in values:
        out.append(decode_h5_str(item))
    return out


def _read_group_as_dataframe(group: h5py.Group) -> pl.DataFrame:
    data: dict[str, Any] = {}
    for key in group.keys():
        values = group[key][:]
        if len(values) == 0:
            data[key] = []
            continue
        first = values[0]
        if isinstance(first, (bytes, str)):
            decoded = _decode_dataset_strings(values)
            data[key] = [None if v == "None" or v == "" else v for v in decoded]
        else:
            data[key] = values
    return pl.DataFrame(data) if data else pl.DataFrame()


def _load_chromatograms_v2(chrom_group: h5py.Group) -> list[Chromatogram | None]:
    n_features = int(chrom_group.attrs.get("n_features", 0))
    if n_features == 0:
        return []

    rt_data = chrom_group["rt_data"][:]
    intensity_data = chrom_group["intensity_data"][:]
    n_points = chrom_group["n_points"][:]
    mz_array = chrom_group["mz"][:]
    rt_start_array = chrom_group["rt_start"][:]
    rt_end_array = chrom_group["rt_end"][:]

    chromatograms: list[Chromatogram | None] = []
    for i in range(n_features):
        if n_points[i] == 0 or np.isnan(mz_array[i]):
            chromatograms.append(None)
            continue
        n_pts = int(n_points[i])
        chrom = Chromatogram(
            rt=np.asarray(rt_data[i, :n_pts], dtype=np.float64),
            inty=np.asarray(intensity_data[i, :n_pts], dtype=np.float64),
        )
        if not np.isnan(rt_start_array[i]):
            chrom.rt_start = float(rt_start_array[i])  # type: ignore[attr-defined]
        if not np.isnan(rt_end_array[i]):
            chrom.rt_end = float(rt_end_array[i])  # type: ignore[attr-defined]
        chrom.mz = float(mz_array[i])  # type: ignore[attr-defined]
        chromatograms.append(chrom)
    return chromatograms


def _load_ms2_specs_v2(ms2_group: h5py.Group) -> list[list[Spectrum] | None]:
    n_features = int(ms2_group.attrs.get("n_features", 0))
    total_spectra = int(ms2_group.attrs.get("total_spectra", 0))
    if n_features == 0:
        return []
    if total_spectra == 0:
        return [None] * n_features

    mz_data = ms2_group["mz_data"][:]
    intensity_data = ms2_group["intensity_data"][:]
    spectrum_lengths = ms2_group["spectrum_lengths"][:]
    feature_counts = ms2_group["feature_counts"][:]

    metadata_json = ms2_group["metadata"][()]
    if isinstance(metadata_json, bytes):
        metadata_json = metadata_json.decode("utf-8")
    all_metadata: list[dict[str, Any]] = json.loads(metadata_json)

    result: list[list[Spectrum] | None] = []
    peak_offset = 0
    spec_idx = 0
    for i in range(n_features):
        n_specs = int(feature_counts[i])
        if n_specs == 0:
            result.append(None)
            continue
        spec_list: list[Spectrum] = []
        for _ in range(n_specs):
            n_peaks = int(spectrum_lengths[spec_idx])
            mz_vals = mz_data[peak_offset : peak_offset + n_peaks]
            inty_vals = intensity_data[peak_offset : peak_offset + n_peaks]
            spec = Spectrum(
                mz=np.asarray(mz_vals, dtype=np.float64),
                inty=np.asarray(inty_vals, dtype=np.float64),
            )
            if spec_idx < len(all_metadata):
                for key, val in all_metadata[spec_idx].items():
                    setattr(spec, key, val)
            spec_list.append(spec)
            peak_offset += n_peaks
            spec_idx += 1
        result.append(spec_list)
    return result


def load_sample5(path: str | Path, *, include_ms1: bool = True) -> dict[str, Any]:
    path = ensure_path(path)
    with h5py.File(path, "r") as f:
        metadata = f.get("metadata")
        storage_version = None
        if metadata is not None:
            storage_version = metadata.attrs.get("storage_version")
        is_v2 = bool(storage_version == 2)

        scans_df = (
            _read_group_as_dataframe(f["scans"]) if "scans" in f else pl.DataFrame()
        )
        ms1_df = (
            _read_group_as_dataframe(f["ms1"]) if include_ms1 and "ms1" in f else None
        )

        features_df = pl.DataFrame()
        chrom_list: list[Chromatogram | None] | None = None
        ms2_specs_list: list[list[Spectrum] | None] | None = None

        if "features" in f:
            features_group = f["features"]
            data: dict[str, Any] = {}
            for col in features_group.keys():
                raw = features_group[col][:]
                if len(raw) == 0:
                    data[col] = []
                    continue
                first = raw[0]
                if isinstance(first, (bytes, str)):
                    decoded = _decode_dataset_strings(raw)
                    if col == "chrom":
                        chrom_list = []
                        for item in decoded:
                            if item == "None" or item == "":
                                chrom_list.append(None)
                            else:
                                chrom_list.append(Chromatogram.from_json(item))
                        continue
                    if col == "ms2_scans":
                        data[col] = [json_loads_maybe(x) for x in decoded]
                        continue
                    if col == "ms2_specs":
                        ms2_specs_list = []
                        for item in decoded:
                            payload = json_loads_maybe(item)
                            if payload is None:
                                ms2_specs_list.append(None)
                                continue
                            specs: list[Spectrum] = []
                            for s in payload:
                                if s == "None" or s is None:
                                    continue
                                specs.append(Spectrum.from_json(s))
                            ms2_specs_list.append(specs if specs else None)
                        continue
                    if col == "ms1_spec":
                        data[col] = [json_loads_maybe(x) for x in decoded]
                        continue
                    data[col] = [None if v == "None" or v == "" else v for v in decoded]
                else:
                    data[col] = raw
            features_df = pl.DataFrame(data) if data else pl.DataFrame()

        if is_v2 and "chromatograms" in f:
            chrom_list = _load_chromatograms_v2(f["chromatograms"])
        if is_v2 and "ms2_specs" in f and hasattr(f["ms2_specs"], "keys"):
            ms2_specs_list = _load_ms2_specs_v2(f["ms2_specs"])

        if chrom_list is not None and len(chrom_list) == len(features_df):
            features_df = features_df.with_columns(
                pl.Series("chrom", chrom_list, dtype=pl.Object),
            )
        if ms2_specs_list is not None and len(ms2_specs_list) == len(features_df):
            features_df = features_df.with_columns(
                pl.Series("ms2_specs", ms2_specs_list, dtype=pl.Object),
            )

        file_path = (
            decode_h5_str(metadata.attrs.get("file_path", ""))
            if metadata is not None
            else str(path)
        )
        file_source = (
            decode_h5_str(metadata.attrs.get("file_source", ""))
            if metadata is not None
            else file_path
        )
        label = (
            decode_h5_str(metadata.attrs.get("label", ""))
            if metadata is not None
            else ""
        )
        file_type = (
            decode_h5_str(metadata.attrs.get("file_type", ""))
            if metadata is not None
            else ""
        )

        history: dict[str, Any] = {}
        if metadata is not None and "parameters" in metadata:
            parameters_data = metadata["parameters"][()]
            if isinstance(parameters_data, bytes):
                parameters_data = parameters_data.decode("utf-8")
            try:
                history = json.loads(parameters_data) if parameters_data else {}
            except Exception:
                history = {}

        return {
            "file_path": file_path,
            "file_source": file_source,
            "type": file_type,
            "label": label or None,
            "history": history,
            "scans_df": scans_df,
            "features_df": features_df,
            "ms1_df": ms1_df,
        }
