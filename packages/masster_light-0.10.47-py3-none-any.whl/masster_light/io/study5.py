from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import h5py
import numpy as np
import polars as pl

from masster_light.chromatogram import Chromatogram
from masster_light.spectrum import Spectrum
from masster_light.util import decode_h5_str, ensure_path, json_loads_maybe

_OBJECT_COLUMNS = {
    "chrom",
    "ms2_scans",
    "ms2_specs",
    "ms1_spec",
    "spec",
    "adducts",
    "iso",
}


def _decode_dataset_strings(values: Any) -> list[str]:
    return [decode_h5_str(v) for v in values]


def _read_group_dataframe_simple(group: h5py.Group) -> dict[str, Any]:
    data: dict[str, Any] = {}
    for col in group.keys():
        item = group[col]
        if hasattr(item, "keys"):
            continue
        values = item[:]
        if len(values) == 0:
            data[col] = []
            continue
        first = values[0]
        if isinstance(first, (bytes, str)):
            decoded = _decode_dataset_strings(values)
            data[col] = [None if v in {"", "None"} else v for v in decoded]
        else:
            try:
                arr = np.asarray(values)
                if arr.dtype.kind in {"i", "u", "f"}:
                    data[col] = [None if v == -123 else v for v in values.tolist()]
                else:
                    data[col] = values
            except Exception:
                data[col] = values
    return data


def _dataframe_from_dict(data: dict[str, Any]) -> pl.DataFrame:
    if not data:
        return pl.DataFrame()
    series_list: list[pl.Series] = []
    for key, values in data.items():
        if key in _OBJECT_COLUMNS:
            series_list.append(pl.Series(key, values, dtype=pl.Object))
        else:
            series_list.append(pl.Series(key, values))
    return pl.DataFrame(series_list)


def _load_chromatograms_v3(group: h5py.Group) -> list[Chromatogram | None]:
    rt_data = group["chrom_rt_data"][:]
    inty_data = group["chrom_inty_data"][:]
    rt_offsets = group["chrom_rt_offsets"][:]
    rt_lengths = group["chrom_rt_lengths"][:]
    metadata_json = group["chrom_metadata"][:]
    out: list[Chromatogram | None] = []
    for i in range(len(rt_offsets)):
        offset = int(rt_offsets[i])
        length = int(rt_lengths[i])
        if length == 0:
            out.append(None)
            continue
        rt_slice = rt_data[offset : offset + length]
        inty_slice = inty_data[offset : offset + length]
        meta = {}
        meta_str = metadata_json[i]
        if isinstance(meta_str, bytes):
            meta_str = meta_str.decode("utf-8")
        if meta_str and meta_str != "{}":
            try:
                meta = json.loads(meta_str)
            except Exception:
                meta = {}
        chrom = Chromatogram(
            rt=np.asarray(rt_slice, dtype=np.float64),
            inty=np.asarray(inty_slice, dtype=np.float64),
            label=meta.get("label"),
            rt_unit=meta.get("rt_unit") or "sec",
        )
        for key, value in meta.items():
            if key in {"label", "rt_unit"}:
                continue
            setattr(chrom, key, value)
        out.append(chrom)
    return out


def _load_ms2_specs_columnized(ms2_group: h5py.Group) -> list[list[Spectrum] | None]:
    n_features = int(ms2_group.attrs.get("n_features", 0))
    total_spectra = int(ms2_group.attrs.get("total_spectra", 0))
    if n_features == 0:
        return []
    if total_spectra == 0:
        return [None] * n_features

    mz_data = ms2_group["mz_data"][:]
    intensity_data = ms2_group["intensity_data"][:]
    spectrum_lengths = ms2_group["spectrum_lengths"][:]
    feature_counts = ms2_group["feature_counts"][:]

    metadata_json = ms2_group["metadata"][()]
    if isinstance(metadata_json, bytes):
        metadata_json = metadata_json.decode("utf-8")
    all_metadata: list[dict[str, Any]] = json.loads(metadata_json)

    result: list[list[Spectrum] | None] = []
    peak_offset = 0
    spec_idx = 0
    for i in range(n_features):
        n_specs = int(feature_counts[i])
        if n_specs == 0:
            result.append(None)
            continue
        spec_list: list[Spectrum] = []
        for _ in range(n_specs):
            n_peaks = int(spectrum_lengths[spec_idx])
            mz_vals = mz_data[peak_offset : peak_offset + n_peaks]
            inty_vals = intensity_data[peak_offset : peak_offset + n_peaks]
            spec = Spectrum(
                mz=np.asarray(mz_vals, dtype=np.float64),
                inty=np.asarray(inty_vals, dtype=np.float64),
            )
            if spec_idx < len(all_metadata):
                for key, val in all_metadata[spec_idx].items():
                    setattr(spec, key, val)
            spec_list.append(spec)
            peak_offset += n_peaks
            spec_idx += 1
        result.append(spec_list)
    return result


def _maybe_objectify_columns(data: dict[str, Any]) -> dict[str, Any]:
    if "chrom" in data and isinstance(data["chrom"], list):
        # Only parse if values look like serialized JSON strings.
        sample = next((x for x in data["chrom"] if x not in (None, "", "None")), None)
        if isinstance(sample, (str, bytes)):
            chrom_list: list[Chromatogram | None] = []
            for item in data["chrom"]:
                if item is None or item == "" or item == "None":
                    chrom_list.append(None)
                else:
                    chrom_list.append(
                        Chromatogram.from_json(
                            item.decode("utf-8") if isinstance(item, bytes) else item,
                        ),
                    )
            data["chrom"] = chrom_list

    if "ms2_scans" in data and isinstance(data["ms2_scans"], list):
        data["ms2_scans"] = [json_loads_maybe(x) for x in data["ms2_scans"]]

    if "ms2_specs" in data and isinstance(data["ms2_specs"], list):
        # Only parse if values look like serialized JSON strings.
        sample = next(
            (x for x in data["ms2_specs"] if x not in (None, "", "None")),
            None,
        )
        if isinstance(sample, (str, bytes)):
            ms2_specs_list: list[list[Spectrum] | None] = []
            for item in data["ms2_specs"]:
                payload = json_loads_maybe(item)
                if payload is None:
                    ms2_specs_list.append(None)
                    continue
                specs: list[Spectrum] = []
                for s in payload:
                    if s is None or s == "None":
                        continue
                    specs.append(Spectrum.from_json(s))
                ms2_specs_list.append(specs if specs else None)
            data["ms2_specs"] = ms2_specs_list

    return data


def load_study5(path: str | Path) -> dict[str, Any]:
    path = ensure_path(path)
    with h5py.File(path, "r") as f:
        metadata = f.get("metadata")
        format_version = "1.0"
        if metadata is not None and "format_version" in metadata.attrs:
            format_version = decode_h5_str(metadata.attrs.get("format_version", "1.0"))

        folder = (
            decode_h5_str(metadata.attrs.get("folder", ""))
            if metadata is not None
            else ""
        )
        label = (
            decode_h5_str(metadata.attrs.get("label", ""))
            if metadata is not None
            else ""
        )

        history: dict[str, Any] = {}
        if metadata is not None and "parameters" in metadata:
            parameters_data = metadata["parameters"][()]
            if isinstance(parameters_data, bytes):
                parameters_data = parameters_data.decode("utf-8")
            try:
                history = json.loads(parameters_data) if parameters_data else {}
            except Exception:
                history = {}

        tables: dict[str, pl.DataFrame | None] = {}
        for name in [
            "samples",
            "features",
            "consensus",
            "consensus_mapping",
            "consensus_ms2",
            "lib",
            "id",
        ]:
            if name not in f:
                tables[name] = None
                continue

            group = f[name]

            if (
                name == "features"
                and format_version == "3.0"
                and {
                    "chrom_rt_data",
                    "chrom_rt_offsets",
                    "chrom_rt_lengths",
                    "chrom_inty_data",
                    "chrom_metadata",
                }.issubset(set(group.keys()))
            ):
                data = _read_group_dataframe_simple(group)
                for k in [
                    "chrom_rt_data",
                    "chrom_inty_data",
                    "chrom_rt_offsets",
                    "chrom_rt_lengths",
                    "chrom_metadata",
                ]:
                    data.pop(k, None)
                data["chrom"] = _load_chromatograms_v3(group)

                if "ms2_scans" in group and not hasattr(group["ms2_scans"], "keys"):
                    data["ms2_scans"] = _decode_dataset_strings(group["ms2_scans"][:])
                if "ms2_specs" in group and hasattr(group["ms2_specs"], "keys"):
                    data["ms2_specs"] = _load_ms2_specs_columnized(group["ms2_specs"])
                data = _maybe_objectify_columns(data)
                tables[name] = _dataframe_from_dict(data)
                continue

            data = _read_group_dataframe_simple(group)
            data = _maybe_objectify_columns(data)
            if "ms2_specs" in group and hasattr(group["ms2_specs"], "keys"):
                data["ms2_specs"] = _load_ms2_specs_columnized(group["ms2_specs"])
            tables[name] = _dataframe_from_dict(data)

        return {
            "filename": str(path),
            "folder": folder or None,
            "label": label or None,
            "history": history,
            "samples_df": tables["samples"],
            "features_df": tables["features"],
            "consensus_df": tables["consensus"],
            "consensus_mapping_df": tables["consensus_mapping"],
            "consensus_ms2": tables["consensus_ms2"],
            "lib_df": tables["lib"],
            "id_df": tables["id"],
        }
