from __future__ import annotations

from collections.abc import Callable
import json
from pathlib import Path
from typing import Any, cast

from bokeh.plotting import figure, show
import polars as pl

from masster_light.api_names import STUDY_API_NAMES
from masster_light.df import filter_eq, select
from masster_light.errors import NeedsFullMassterError, UnsupportedFileError
from masster_light.export import export_excel, export_mgf
from masster_light.io.study5 import load_study5


class Study:
    def __init__(self, filename: str | Path | None = None) -> None:
        self.filename: str | None = None
        self.folder: str | None = None
        self.label: str | None = None
        self.history: dict[str, Any] = {}

        self.samples_df: pl.DataFrame | None = None
        self.features_df: pl.DataFrame | None = None
        self.consensus_df: pl.DataFrame | None = None
        self.consensus_mapping_df: pl.DataFrame | None = None
        self.consensus_ms2: pl.DataFrame | None = None
        self.lib_df: pl.DataFrame | None = None
        self.id_df: pl.DataFrame | None = None

        if filename is not None:
            self.load(filename)

    def __dir__(self) -> list[str]:
        return sorted(
            set(list(self.__dict__.keys()) + STUDY_API_NAMES + dir(type(self))),
        )

    def __getattr__(self, name: str):
        if name in STUDY_API_NAMES:
            return _disabled_method_stub(f"Study.{name}")
        raise AttributeError(name)

    def load(self, filename: str | Path) -> Study:
        filename = Path(filename)
        if filename.suffix.lower() != ".study5":
            raise UnsupportedFileError(
                "masster-light can only load cached .study5 files. "
                "Install the full distribution (e.g. masster-dist) to build studies from raw data.",
            )
        data = load_study5(filename)
        self.filename = data["filename"]
        self.folder = data["folder"]
        self.label = data["label"]
        self.history = data["history"] or {}
        self.samples_df = data["samples_df"]
        self.features_df = data["features_df"]
        self.consensus_df = data["consensus_df"]
        self.consensus_mapping_df = data["consensus_mapping_df"]
        self.consensus_ms2 = data["consensus_ms2"]
        self.lib_df = data["lib_df"]
        self.id_df = data["id_df"]
        return self

    def close(self) -> None:
        self.samples_df = None
        self.features_df = None
        self.consensus_df = None
        self.consensus_mapping_df = None
        self.consensus_ms2 = None
        self.lib_df = None
        self.id_df = None

    def info(self) -> dict[str, Any]:
        return {
            "filename": self.filename,
            "folder": self.folder,
            "label": self.label,
            "n_samples": 0 if self.samples_df is None else len(self.samples_df),
            "n_features": 0 if self.features_df is None else len(self.features_df),
            "n_consensus": 0 if self.consensus_df is None else len(self.consensus_df),
        }

    def get_sample(
        self,
        sample_id: int,
        *,
        id_column: str = "sample_id",
    ) -> dict[str, Any]:
        if self.samples_df is None or self.samples_df.is_empty():
            raise NeedsFullMassterError("No samples_df present in this .study5 file.")
        if id_column not in self.samples_df.columns:
            raise ValueError(f"samples_df does not contain '{id_column}'")
        row = self.samples_df.filter(pl.col(id_column) == sample_id)
        if row.is_empty():
            raise KeyError(f"No sample with {id_column}={sample_id}")
        return cast(dict[str, Any], row.row(0, named=True))

    def features_select(self, columns: list[str]) -> pl.DataFrame:
        if self.features_df is None:
            raise NeedsFullMassterError("No features_df present in this .study5 file.")
        return select(self.features_df, columns)

    def features_filter(self, **equals: Any) -> pl.DataFrame:
        if self.features_df is None:
            raise NeedsFullMassterError("No features_df present in this .study5 file.")
        return filter_eq(self.features_df, **equals)

    def export_csv(self, filename: str | Path, *, table: str = "features") -> None:
        self._get_table(table).write_csv(filename)

    def export_parquet(self, filename: str | Path, *, table: str = "features") -> None:
        self._get_table(table).write_parquet(filename)

    def export_excel(self, filename: str | Path, *, table: str = "features") -> None:
        export_excel(self._get_table(table), filename, sheet_name=table)

    def export_mgf(self, filename: str | Path, *, table: str = "features") -> None:
        df = self._get_table(table)
        if "ms2_specs" not in df.columns:
            raise NeedsFullMassterError(
                "No cached MS2 spectra found (expected a 'ms2_specs' column).",
            )
        spectra = []
        for item in df["ms2_specs"].to_list():
            if item is None:
                continue
            for spec in item:
                spectra.append(spec)
        export_mgf(spectra, filename, title_prefix=f"{table}_ms2")

    def export_history(self, filename: str | Path) -> None:
        Path(filename).write_text(json.dumps(self.history, indent=2), encoding="utf-8")

    def plot_features_2d(
        self,
        *,
        x: str = "rt",
        y: str = "mz",
        max_points: int = 50_000,
        show_plot: bool = True,
    ):
        if self.features_df is None or self.features_df.is_empty():
            raise NeedsFullMassterError("No features_df present in this .study5 file.")
        df = self.features_df
        if x not in df.columns or y not in df.columns:
            raise ValueError(f"features_df must include columns '{x}' and '{y}'")
        if len(df) > max_points:
            df = df.head(max_points)
        p = figure(title="Features", x_axis_label=x, y_axis_label=y)
        p.scatter(df[x].to_list(), df[y].to_list(), size=3, alpha=0.4)
        if show_plot:
            show(p)
        return p

    def _get_table(self, table: str) -> pl.DataFrame:
        match table:
            case "samples":
                if self.samples_df is None:
                    raise NeedsFullMassterError(
                        "No samples_df present in this .study5 file.",
                    )
                return self.samples_df
            case "features":
                if self.features_df is None:
                    raise NeedsFullMassterError(
                        "No features_df present in this .study5 file.",
                    )
                return self.features_df
            case "consensus":
                if self.consensus_df is None:
                    raise NeedsFullMassterError(
                        "No consensus_df present in this .study5 file.",
                    )
                return self.consensus_df
            case "id":
                if self.id_df is None:
                    raise NeedsFullMassterError(
                        "No id_df present in this .study5 file.",
                    )
                return self.id_df
            case _:
                raise ValueError(
                    "table must be one of: samples, features, consensus, id",
                )


def _disabled_method_stub(qualified_name: str) -> Callable[..., Any]:
    def _stub(*_args: Any, **_kwargs: Any) -> Any:
        raise NeedsFullMassterError(
            f"{qualified_name} is disabled in masster-light. "
            "Install the full distribution (e.g. masster-dist) for processing/raw-data features.",
        )

    _stub.__name__ = qualified_name.split(".")[-1]
    return _stub
