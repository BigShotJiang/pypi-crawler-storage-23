from __future__ import annotations

from dataclasses import dataclass
import json
from typing import Any

from bokeh.plotting import figure, show
import numpy as np


@dataclass
class Chromatogram:
    rt: np.ndarray
    inty: np.ndarray
    label: str | None = None
    rt_unit: str = "sec"

    def __post_init__(self) -> None:
        self.rt = np.asarray(self.rt, dtype=np.float64)
        self.inty = np.asarray(self.inty, dtype=np.float64)

    @classmethod
    def from_json(cls, payload: str) -> Chromatogram:
        data = json.loads(payload)
        rt = np.asarray(data.get("rt", []), dtype=np.float64)
        inty = np.asarray(data.get("inty", []), dtype=np.float64)
        label = data.get("label")
        rt_unit = data.get("rt_unit") or "sec"
        chrom = cls(rt=rt, inty=inty, label=label, rt_unit=rt_unit)
        for key, value in data.items():
            if key in {"rt", "inty", "label", "rt_unit"}:
                continue
            setattr(chrom, key, value)
        return chrom

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "rt": self.rt.tolist(),
            "inty": self.inty.tolist(),
            "label": self.label,
            "rt_unit": self.rt_unit,
        }
        for key, value in getattr(self, "__dict__", {}).items():
            if key not in d:
                d[key] = value
        return d

    def plot(self, title: str | None = None, show_plot: bool = True):
        p = figure(
            title=title or (self.label or "Chromatogram"),
            x_axis_label=f"RT ({self.rt_unit})",
            y_axis_label="Intensity",
        )
        p.line(self.rt, self.inty, line_width=2)
        if show_plot:
            show(p)
        return p
