from __future__ import annotations

from collections.abc import Iterable
import json
from pathlib import Path
from typing import Any


def decode_h5_str(value: Any) -> str:
    if isinstance(value, bytes):
        return value.decode("utf-8")
    return str(value)


def json_loads_maybe(payload: str | bytes | None) -> Any:
    if payload is None:
        return None
    if isinstance(payload, bytes):
        payload = payload.decode("utf-8")
    if payload in {"", "None", "null", "NULL"}:
        return None
    return json.loads(payload)


def ensure_path(path: str | Path) -> Path:
    return path if isinstance(path, Path) else Path(path)


def first_existing_column(candidates: Iterable[str], columns: set[str]) -> str | None:
    for name in candidates:
        if name in columns:
            return name
    return None
