from __future__ import annotations

from collections.abc import Callable
import json
from pathlib import Path
from typing import Any, cast

from bokeh.plotting import figure, show
import polars as pl

from masster_light.api_names import SAMPLE_API_NAMES
from masster_light.df import filter_eq, select
from masster_light.errors import NeedsFullMassterError, UnsupportedFileError
from masster_light.export import export_excel, export_mgf
from masster_light.io.sample5 import load_sample5
from masster_light.util import first_existing_column


class Sample:
    def __init__(self, filename: str | Path | None = None) -> None:
        self.file_path: str | None = None
        self.file_source: str | None = None
        self.type: str | None = None
        self.label: str | None = None
        self.history: dict[str, Any] = {}

        self.scans_df: pl.DataFrame = pl.DataFrame()
        self.features_df: pl.DataFrame = pl.DataFrame()
        self.ms1_df: pl.DataFrame | None = None

        if filename is not None:
            self.load(filename)

    def __dir__(self) -> list[str]:
        return sorted(
            set(list(self.__dict__.keys()) + SAMPLE_API_NAMES + dir(type(self))),
        )

    def __getattr__(self, name: str):
        if name in SAMPLE_API_NAMES:
            return _disabled_method_stub(f"Sample.{name}")
        raise AttributeError(name)

    def load(self, filename: str | Path) -> Sample:
        filename = Path(filename)
        if filename.suffix.lower() != ".sample5":
            raise UnsupportedFileError(
                "masster-light can only load cached .sample5 files. "
                "Install the full distribution (e.g. masster-dist) to load raw data.",
            )
        data = load_sample5(filename, include_ms1=True)
        self.file_path = data["file_path"]
        self.file_source = data["file_source"]
        self.type = data["type"]
        self.label = data["label"]
        self.history = data["history"] or {}
        self.scans_df = data["scans_df"]
        self.features_df = data["features_df"]
        self.ms1_df = data["ms1_df"]
        return self

    def load_noms1(self, filename: str | Path) -> Sample:
        filename = Path(filename)
        if filename.suffix.lower() != ".sample5":
            raise UnsupportedFileError(
                "masster-light can only load cached .sample5 files.",
            )
        data = load_sample5(filename, include_ms1=False)
        self.file_path = data["file_path"]
        self.file_source = data["file_source"]
        self.type = data["type"]
        self.label = data["label"]
        self.history = data["history"] or {}
        self.scans_df = data["scans_df"]
        self.features_df = data["features_df"]
        self.ms1_df = None
        return self

    def close(self) -> None:
        self.scans_df = pl.DataFrame()
        self.features_df = pl.DataFrame()
        self.ms1_df = None

    def info(self) -> dict[str, Any]:
        return {
            "file_path": self.file_path,
            "file_source": self.file_source,
            "type": self.type,
            "label": self.label,
            "n_scans": len(self.scans_df),
            "n_features": len(self.features_df),
            "has_ms1": self.ms1_df is not None,
        }

    def get_scan(self, scan_id: int, *, id_column: str = "scan_id") -> dict[str, Any]:
        if self.scans_df.is_empty():
            raise NeedsFullMassterError("No scans_df available in this .sample5 file.")
        if id_column not in self.scans_df.columns:
            raise ValueError(f"scans_df does not contain '{id_column}'")
        row = self.scans_df.filter(pl.col(id_column) == scan_id)
        if row.is_empty():
            raise KeyError(f"No scan with {id_column}={scan_id}")
        return cast(dict[str, Any], row.row(0, named=True))

    def get_feature(
        self,
        feature_id: int,
        *,
        id_column: str = "feature_id",
    ) -> dict[str, Any]:
        if self.features_df.is_empty():
            raise NeedsFullMassterError(
                "No features_df available in this .sample5 file.",
            )
        if id_column not in self.features_df.columns:
            raise ValueError(f"features_df does not contain '{id_column}'")
        row = self.features_df.filter(pl.col(id_column) == feature_id)
        if row.is_empty():
            raise KeyError(f"No feature with {id_column}={feature_id}")
        return cast(dict[str, Any], row.row(0, named=True))

    def get_chrom(self, feature_id: int) -> Any:
        if "chrom" not in self.features_df.columns:
            raise NeedsFullMassterError(
                "No cached chromatograms found in features_df['chrom'].",
            )
        row = self.features_df.filter(pl.col("feature_id") == feature_id)
        if row.is_empty():
            raise KeyError(f"No feature with feature_id={feature_id}")
        return row["chrom"][0]

    def get_ms2(self, feature_id: int) -> Any:
        if "ms2_specs" not in self.features_df.columns:
            raise NeedsFullMassterError(
                "No cached MS2 spectra found in features_df['ms2_specs'].",
            )
        row = self.features_df.filter(pl.col("feature_id") == feature_id)
        if row.is_empty():
            raise KeyError(f"No feature with feature_id={feature_id}")
        return row["ms2_specs"][0]

    def features_select(self, columns: list[str]) -> pl.DataFrame:
        return select(self.features_df, columns)

    def features_filter(self, **equals: Any) -> pl.DataFrame:
        return filter_eq(self.features_df, **equals)

    def export_history(self, filename: str | Path) -> None:
        Path(filename).write_text(json.dumps(self.history, indent=2), encoding="utf-8")

    def export_csv(self, filename: str | Path, *, table: str = "features") -> None:
        self._get_table(table).write_csv(filename)

    def export_parquet(self, filename: str | Path, *, table: str = "features") -> None:
        self._get_table(table).write_parquet(filename)

    def export_excel(self, filename: str | Path, *, table: str = "features") -> None:
        export_excel(self._get_table(table), filename, sheet_name=table)

    def export_mgf(self, filename: str | Path) -> None:
        if "ms2_specs" not in self.features_df.columns:
            raise NeedsFullMassterError(
                "No cached MS2 spectra found in features_df['ms2_specs'].",
            )
        spectra = []
        for item in self.features_df["ms2_specs"].to_list():
            if item is None:
                continue
            for spec in item:
                spectra.append(spec)
        export_mgf(spectra, filename, title_prefix="feature_ms2")

    def plot_tic(self, *, show_plot: bool = True):
        if self.scans_df.is_empty():
            raise NeedsFullMassterError("No scans_df available in this .sample5 file.")
        cols = set(self.scans_df.columns)
        xcol = first_existing_column(["rt", "time"], cols)
        ycol = first_existing_column(["inty_tot", "tic", "intensity_total"], cols)
        if xcol is None or ycol is None:
            raise NeedsFullMassterError(
                "Cannot plot TIC: expected scans_df to have RT and total intensity columns.",
            )
        x = self.scans_df[xcol].to_list()
        y = self.scans_df[ycol].to_list()
        p = figure(title="TIC", x_axis_label=xcol, y_axis_label=ycol)
        p.line(x, y, line_width=2)
        if show_plot:
            show(p)
        return p

    def plot_bpc(self, *, show_plot: bool = True):
        if self.scans_df.is_empty():
            raise NeedsFullMassterError("No scans_df available in this .sample5 file.")
        cols = set(self.scans_df.columns)
        xcol = first_existing_column(["rt", "time"], cols)
        ycol = first_existing_column(["inty_max", "bpc", "intensity_max"], cols)
        if xcol is None or ycol is None:
            raise NeedsFullMassterError(
                "Cannot plot BPC: expected scans_df to have RT and max intensity columns.",
            )
        x = self.scans_df[xcol].to_list()
        y = self.scans_df[ycol].to_list()
        p = figure(title="BPC", x_axis_label=xcol, y_axis_label=ycol)
        p.line(x, y, line_width=2)
        if show_plot:
            show(p)
        return p

    def plot_chrom(self, feature_id: int | None = None, *, show_plot: bool = True):
        if "chrom" not in self.features_df.columns:
            raise NeedsFullMassterError(
                "No cached chromatograms found in features_df['chrom'].",
            )
        df = self.features_df
        if feature_id is not None and "feature_id" in df.columns:
            row = df.filter(pl.col("feature_id") == feature_id)
        else:
            row = df.head(1)
        if row.is_empty():
            raise NeedsFullMassterError("No matching feature found.")
        chrom = row["chrom"][0]
        if chrom is None:
            raise NeedsFullMassterError("Selected feature has no chromatogram cached.")
        return chrom.plot(show_plot=show_plot)

    def _get_table(self, table: str) -> pl.DataFrame:
        match table:
            case "features":
                return self.features_df
            case "scans":
                return self.scans_df
            case "ms1":
                if self.ms1_df is None:
                    raise NeedsFullMassterError("ms1_df was not loaded (use load()).")
                return self.ms1_df
            case _:
                raise ValueError("table must be one of: features, scans, ms1")


def _disabled_method_stub(qualified_name: str) -> Callable[..., Any]:
    def _stub(*_args: Any, **_kwargs: Any) -> Any:
        raise NeedsFullMassterError(
            f"{qualified_name} is disabled in masster-light. "
            "Install the full distribution (e.g. masster-dist) for processing/raw-data features.",
        )

    _stub.__name__ = qualified_name.split(".")[-1]
    return _stub
