class BeaconError(Exception):
    """Base exception for all beacon errors."""


class BeaconAPIError(BeaconError):
    """Raised when the API returns an error response."""

    def __init__(self, message: str, status_code: int | None = None):
        super().__init__(message)
        self.status_code = status_code


class BeaconAuthError(BeaconAPIError):
    """Raised on authentication failures (401/403)."""


class BeaconConfigError(BeaconError):
    """Raised when local configuration is missing or invalid."""


class BeaconSystemError(BeaconError):
    """Raised when a system-level operation fails (WireGuard, rathole, etc.)."""


class BeaconNotFoundError(BeaconAPIError):
    """Raised when a beacon ID does not exist on the API."""
