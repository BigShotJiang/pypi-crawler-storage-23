# SP Client

Python library for the Scraping Pros API.

## Installation
first go to the pypi URL: https://test.pypi.org/project/sp-client/0.1.0/ and then install the 
library as it is explicited in the page.

## Quick Start
```python
from sp_client import ScrapingPros

# Initialize the client
client = ScrapingPros(
    token='your-api-token-here'
)

# Scrape a website
result = client.scrape_site(data)
print(result)
```

### scrape_site(data)
Scrapes a website with the instructions set on the data.

**Parameters:**
- `data`: Dictionary with instructions on how to perform the scraping.

**Example:**
```python
data = client.scrape_site(
    "url": 'https://example.com',
    "browser": True
)
```
