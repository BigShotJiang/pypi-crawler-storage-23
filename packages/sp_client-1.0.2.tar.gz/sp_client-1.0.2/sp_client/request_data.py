from typeguard import typechecked
from typing import List, Dict, Any
from .actions import BaseAction
from .proxy_data import RequestProxy
from .extraction import BaseExtract

class RequestData:
    """
    Class to create the data for a request.
    """
    def __init__(self):
        self.url        = ""
        self.actions    = []
        self.cookies    = None
        self.browser    = None
        self.language   = ""
        self.screenshot = None
        self.proxy      = None
        self.http_method= None
        self.extract    = []

    def make_actions(self, actions : List[BaseAction]):
        """
        :param actions: actions to perform in the scraper
        :type actions: List
        """
        if not isinstance(actions, list) or not all(isinstance(a, BaseAction) for a in actions):
            raise Exception("Actions to make should be a list of Action objects")
        self.actions = actions

    def ask_for_proxy(self, proxy_request : RequestProxy):
        """
        :param proxy_request: RequestProxy object to ask for a proxy to make the request.
        :type extract: RequestProxy
        """
        if not isinstance(proxy_request, RequestProxy):
            raise Exception("Request for a proxy needs to be made with a RequestProxy object")
        self.proxy = proxy_request

    
    def set_extract(self, extract : List[BaseExtract]):
        """
        :param extract: List of BaseExtract objects to extract from the HTML.
        :type extract: List[BaseExtract]
        """
        self.extract = extract

    @typechecked
    def make_http_request(self, method : Dict[str,str]):
        """
        :param method: http method to perform
        :type method: Dict[str, str]
        """
        self.http_method = method
    
    @typechecked
    def set_cookies(self, cookies : Dict[str, str]):
        """
        :param cookies: cookies to set in the browser
        :type cookies: Dict[str, str]
        """
        self.cookies = cookies
        
    
    @typechecked
    def use_browser(self, browser : bool):
        """
        :param browser: Boolean to set if the scraper should use a browser
        :type  browser: Boolean
        """
        self.browser = browser

    @typechecked
    def make_screenshot(self, screenshot : bool):
        """
        :param screenshot: tells the scraper to make a screenshot at the end of the scraping process
        :type  screenshot: Boolean

        WARNING:
            To ask for a screenshot, a screenshots folder needs to be had where the library is being executed.
        """
        self.screenshot = screenshot
    
    @typechecked
    def set_language(self, language : str):
        """
        :param language: string with the format 'en-US' (Example)
        :type  language: string
        """
        self.language = language
    
    @typechecked
    def set_url(self, url : str):
        """
        :param url: string with the url for the page to scrape
        :type  url: string
        """
        self.url = url
    
    def _create_request(self) -> Dict[str, Any]:
        """
        Create a JSON object that will be used for the Request
        """
        data = {}
        if (not self.url):
            raise Exception("URL for scraping has not been set")
        data["url"] = self.url
        actions_dict = []
        for action in self.actions:
            actions_dict.append(action.make_action())
        data["actions"] = actions_dict
        data["cookies"] = self.cookies
        data["browser"] = self.browser
        data["language"] = self.language
        data["screenshot"] = self.screenshot
        try:
            data["use_proxy"] = self.proxy.make_proxy()
        except:
            data["use_proxy"] = None
        data["http_method"] = self.http_method
        try:
            extract_dict = {}
            for item in self.extract:
                extract_dict.update(item.get_extract())
            data["extract"] = extract_dict
        except:
            data["extract"] = None
        return data