from typing import Dict, List
from .base_action import BaseAction


class LoopAction(BaseAction):
    """
    Class that represents a series of actions to be performed in a loop with a condition.
    

    Args:
        condition_type: STRING that represents the condition that makes the series of actions
        be executed. It accepts two values: 'selector-visible' and 'selector-invisible' 
        selector_type: STRING XPath or css selector that matches the element on the page, 
        used in conjunction with the condition type provided.
        actions: List[BaseAction] list of actions to be performed on each iteration.
        max_iterations: INT maximum amount of times to perform the actions.
    
    Example:
        >>> from sp_client import *
        >>> client = ScrapingPros('token123')
        >>> data = RequestData()
        >>> data.set_url("example.com")
        >>> key = KeyPressAction('Enter')
        >>> loop = LoopAction('selector-visible', 'XPATH_SELECTOR', [key])
        >>> data.make_actions([loop])
        >>> client.scrape_site(data)
    """
    def __init__(self, condition_type: str, selector_type: str, actions : List[BaseAction],
                  max_iterations: int = 0):
        self.condition_type = condition_type
        self.loop_type = selector_type
        self.max_iterations = max_iterations
        self.type = 'while'
        self.actions = actions

    def make_action(self):
        actions_dict = []
        for action in self.actions:
            actions_dict.append(action.make_action())
        action = {
            "type": self.type,
            "condition": {"type" : self.condition_type,
                          "selector": self.loop_type},
            "actions": actions_dict, 
        }
        if self.max_iterations > 0:
            action["max_iterations"] = self.max_iterations 
        return action