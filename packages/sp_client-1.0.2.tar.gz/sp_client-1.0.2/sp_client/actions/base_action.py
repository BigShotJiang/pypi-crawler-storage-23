from abc import ABC, abstractmethod

class BaseAction(ABC):

    @abstractmethod
    def make_action(self):
        ...