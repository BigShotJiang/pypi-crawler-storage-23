from .base_action import BaseAction

class WaitTimeoutAction(BaseAction):
    """
    Class that represents a sleep for the scraper.
    
    Args:
        time: INT that represents the amount of miliseconds to wait. Default value is 500ms.
    
    Example:
        >>> from sp_client import *
        >>> client = ScrapingPros('token123')
        >>> data = RequestData()
        >>> data.set_url("example.com")
        >>> sleep = WaitTimeoutAction(1000)
        >>> data.make_actions([sleep])
        >>> client.scrape_site(data)
    """
    def __init__(self, time : int = 500):
        self.type = 'wait-for-timeout'
        self.time = time

    def make_action(self):
        action = {
            "type": self.type,
            "time": self.time
        }
        return action