from .base_action import BaseAction

class WaitSelectorAction(BaseAction):
    """
    Class that represents a wait action based on a selector.
    

    Args:
        selector: STRING with the css or Xpath selector that represents the element to make
        the scraper wait to appear.
        time: INT that represents the amount of miliseconds to wait. Default value is 500ms.
    
    Example:
        >>> from sp_client import *
        >>> client = ScrapingPros('token123')
        >>> data = RequestData()
        >>> data.set_url("example.com")
        >>> wait_selector = WaitSelectorAction('XPATH_SELECTOR', 1000)
        >>> data.make_actions([wait_selector])
        >>> client.scrape_site(data)
    """
    def __init__(self, selector : str, time : int = 500):
        self.selector = selector
        self.type = 'wait-for-selector'
        self.time = time

    def make_action(self):
        action = {
            "type": self.type,
            "selector": self.selector,
            "time": self.time
        }
        return action