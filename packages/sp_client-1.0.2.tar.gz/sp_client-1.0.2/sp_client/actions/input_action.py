from .base_action import BaseAction

class InputAction(BaseAction):
    """
    Class that represents an input action in a page.
    

    Args:
        selector: STRING with the css or Xpath selector on where to insert the input.
        text: STRING that represents the value to be inputed.
    
    Example:
        >>> from sp_client import *
        >>> client = ScrapingPros('token123')
        >>> data = RequestData()
        >>> data.set_url("example.com")
        >>> input = InputAction('XPATH_SELECTOR')
        >>> data.make_actions([input])
        >>> client.scrape_site(data)
    """
    def __init__(self, selector : str, text : str):
        self.selector = selector
        self.type = 'input'
        self.text = text

    def make_action(self):
        action = {
            "type": self.type,
            "selector": self.selector,
            "text": self.text
        }
        return action