from .base_action import BaseAction

class KeyPressAction(BaseAction):
    """
    Class that represents a key-press in the scraper.
    

    Args:
        key: STRING that represents the key to press. Also accepts combinations such as
        'Shitf+O' for example.
    
    Example:
        >>> from sp_client import *
        >>> client = ScrapingPros('token123')
        >>> data = RequestData()
        >>> data.set_url("example.com")
        >>> key = KeyPressAction('Enter')
        >>> data.make_actions([key])
        >>> client.scrape_site(data)
    """
    def __init__(self, key : str):
        self.key = key
        self.type = 'key-press'

    def make_action(self):
        action = {
            "type": self.type,
            "key": self.key
        }
        return action