from .base_action import BaseAction

class ClickAction(BaseAction):
    """
    Class that represents a click in a page.
    

    Args:
        selector: STRING with the css or Xpath selector on where to click.
        wait_for_navigation: BOOLEAN that is set TRUE when the click is going to make
        a change in the page. Default value is FALSE.
    
    Example:
        >>> from sp_client import *
        >>> client = ScrapingPros('token123')
        >>> data = RequestData()
        >>> data.set_url("example.com")
        >>> click = ClickAction('XPATH_SELECTOR')
        >>> data.make_actions([click])
        >>> client.scrape_site(data)
    """
    def __init__(self, selector : str, wait_for_navigation : bool = False):
        self.selector = selector
        self.type = 'click'
        self.wait_for_navigation = wait_for_navigation

    def make_action(self):
        action = {
            "type": self.type,
            "selector": self.selector,
            "wait_for_navigation": self.wait_for_navigation
        }
        return action