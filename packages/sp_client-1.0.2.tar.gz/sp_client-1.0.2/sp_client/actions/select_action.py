from .base_action import BaseAction

class SelectAction(BaseAction):
    """
    Class that represents a select option in a page.
    

    Args:
        selector: STRING with the css or Xpath selector that represents the input element.
        value: STRING that represents the value to be selected.
    
    Example:
        >>> from sp_client import *
        >>> client = ScrapingPros('token123')
        >>> data = RequestData()
        >>> data.set_url("example.com")
        >>> select = SelectAction('XPATH_SELECTOR', 'OPTION_1')
        >>> data.make_actions([select])
        >>> client.scrape_site(data)
    """
    def __init__(self, selector : str, value : str = ''):
        self.selector = selector
        self.type = 'select'
        self.value = value

    def make_action(self):
        action = {
            "type": self.type,
            "selector": self.selector,
            "value": self.value
        }
        return action