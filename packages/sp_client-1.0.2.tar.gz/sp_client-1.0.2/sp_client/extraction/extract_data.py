from typing import Optional
from .base_extract import BaseExtract

class ExtractData(BaseExtract):
    """
    Class that's used to extract certain data from the HTML.
    
    Args:
        title: STRING that marks the title the data being extracted will have.
        selector: STRING that represents what element(s) to look for in the HTML.
        multiple: BOOLEAN that represents if all of the occurences of that selector to be
        saved or only the first one. Default value is False.4
        attribute: A certain attribute to be searched and extracted from the HTML. Default value
        is None.


    Example:
        >>> from sp_client import *
        >>> client = ScrapingPros('token123')
        >>> data = RequestData()
        >>> data.set_url("example.com")
        >>> extract = ExtractData("test", XPATH_SELECTOR, True, None)
        >>> data.set_extract([extract])
        >>> client.scrape_site(data)
    """
    def __init__(self, title : str, selector : str, multiple : Optional[bool], attribute : Optional[str]):
        extract_case = {}
        data_extract = {}
        if not selector or not title:
            raise Exception("To extract data a selector must be passed and a title must be set")
        data_extract["selector"] = selector
        if multiple:
            data_extract["multiple"] = multiple
        if attribute:
            data_extract["attribute"] = attribute
        extract_case[title] = data_extract
        self.extract = extract_case
    
    def get_extract(self) -> dict:
        return self.extract