from .base_extract import BaseExtract

class SingleExtract(BaseExtract):
    """
    Class that's used to extract certain data from the HTML.
    
    Args:
        title: STRING that marks the title the data being extracted will have.
        selector: STRING that represents what element to look for in the HTML.


    Example:
        >>> from sp_client import *
        >>> client = ScrapingPros('token123')
        >>> data = RequestData()
        >>> data.set_url("example.com")
        >>> extract = SingleExtract("test", XPATH_SELECTOR)
        >>> data.set_extract([extract])
        >>> client.scrape_site(data)
    """
    def __init__(self, title : str, selector : str):
        self.extract = {title: selector}

    def get_extract(self) -> dict:
        return self.extract