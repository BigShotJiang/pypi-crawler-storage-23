from abc import ABC, abstractmethod

class BaseExtract(ABC):

    @abstractmethod
    def get_extract(self) -> dict:
        ...