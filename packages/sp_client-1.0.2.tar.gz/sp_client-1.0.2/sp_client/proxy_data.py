class RequestProxy:
    """
    Class to interact with the Scraping Pros API.
    
    To use more parameters besides 'proxy_selection', the proxy_object parameter must be 
    set in TRUE.
    

    Args:
        proxy_selection: STRING with the type of proxy to ask.
        max_retries: INT with the max amount of retries to ask for different proxies.
        delay: INT with seconds to wait before trying to get a proxy again.
        backoff_factor: INT with a multiplier to be added to the delay before retrying.
        proxy_object: BOOLEAN to ask for a specific proxy.
    
    Example:
        >>> from sp_client import *
        >>> client = ScrapingPros('token123')
        >>> data = RequestData()
        >>> data.set_url("example.com")
        >>> proxy = RequestProxy('any')
        >>> data.ask_for_proxy(proxy)
        >>> client.scrape_site(data)
    """
    def __init__(self, proxy_selection : str = 'any',
                  max_retries: int = 1, delay: int = 0, backoff_factor: int = 0,
                    proxy_object : bool = False):
        
        self.proxy        = proxy_selection
        self.retries      = max_retries
        self.delay        = delay
        self.backoff      = backoff_factor
        self.proxy_object = proxy_object

    def make_proxy(self):
        proxy_dict = {}
        if self.proxy_object:
            proxy_dict = {
                "proxy"         : self.proxy,
                "max_retries"   : self.retries,
                "delay_seconds" : self.delay,
                "backoff_factor": self.backoff
            }
        else:
            proxy_dict = {"proxy":self.proxy}
        return proxy_dict
        
        