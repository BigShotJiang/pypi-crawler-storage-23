"""Repowire TUI - htop-style interface for managing Claude Code peers."""

from repowire.tui.app import RepowireApp

__all__ = ["RepowireApp"]
