# FILE TO SET DECAY NAME

sample_decay = 'Bd2Ksmm'
from Configurables import DaVinci
DaVinci().TupleFile=sample_decay
