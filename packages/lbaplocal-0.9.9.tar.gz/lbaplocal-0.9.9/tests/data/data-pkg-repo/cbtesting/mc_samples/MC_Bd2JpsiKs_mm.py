# FILE TO SET DECAY NAME

sample_decay = 'Bd2KsJpsmm'

from Configurables import DaVinci
DaVinci().TupleFile=sample_decay
