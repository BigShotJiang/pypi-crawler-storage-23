"""
I/O utilities module.

This module provides helper functions for reading from and writing to files,
handling various common I/O tasks.

Functions:
- load_data_from_csv: Loads the data from a .csv file.
- read_toml_configuration: Parses the contents of a .TOML file.
"""

import tomllib

import pandas as pd

from . import exceptions


def load_data_from_csv(data_file: str):
    """
    Reads a .csv file and returns its contents.

    Parameters
    __________
    data_file
        Path to the .csv file to load.

    Returns
    _______
    data : pd.DataFrame
        Loaded data.

    Raises
    ______
    TypeError
        If data_file is not a str.
    FileNotFoundError
        If data_file does not exist.
    IsADirectoryError
        If data_file is not a file.
    ValueError
        If data_file extension is not .csv file.

    """
    try:
        exceptions.file_checks(data_file, ".csv")
    except (FileNotFoundError, IsADirectoryError, TypeError, ValueError):
        raise

    data = pd.read_csv(data_file)
    return data


def read_toml_configuration(config_file: str) -> dict:
    """
    Reads a .TOML configuration file and returns contents.

    The function adds the base_dir variable to any dir variable.

    Parameters
    ----------
    config_file
        Path to the configuration file.

    Returns
    -------
    config : dict
        Configuration contents as a dictionary.

    Raises
    ------
    TypeError
        If config_file is not a str.
    FileNotFoundError
        If config_file does not exist.
    IsADirectoryError
        If config_file is not a file.
    ValueError
        If data_file extension is not .csv file.
    tomllib.TOMLDecodeError
        If the file was not read properly.

    """
    try:
        exceptions.file_checks(config_file, ".toml")
    except (FileNotFoundError, IsADirectoryError, TypeError, ValueError):
        raise

    with open(config_file, "rb") as file:
        config = tomllib.load(file)

    # Add base_dir to dir parameters
    if "base_dir" in config.keys():
        if "log_dir" in config.keys():
            config["log_dir"] = config["base_dir"] + config["log_dir"]

        for key, item in config.items():
            if type(item) is type(dict()) and "dir" in item.keys():
                # In a _parameters dictionary
                config[key]["dir"] = config["base_dir"] + config[key]["dir"]

    return config
