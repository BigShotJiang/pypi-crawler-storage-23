"""
medpipe.pipeline module

submodules:
- Pipeline: Pipeline class.
"""

from . import Pipeline
