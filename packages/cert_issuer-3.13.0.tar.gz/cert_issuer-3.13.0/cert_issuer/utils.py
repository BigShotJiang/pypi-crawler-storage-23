def array_intersect (a, b):
    return list(filter(lambda x: x in a, b))
