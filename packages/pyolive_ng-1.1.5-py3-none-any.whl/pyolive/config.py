import os
import re
import yaml
import logging
from datetime import datetime, timezone, timedelta
from typing import Any, Optional

class Config:
    ATHENA_HOME = os.getenv("ATHENA_HOME", os.getcwd())

    def __init__(self, filename: str):
        # 런타임에 환경변수가 있으면 클래스 변수 업데이트
        athena_home_env = os.getenv("ATHENA_HOME")
        if athena_home_env and athena_home_env != Config.ATHENA_HOME:
            Config.ATHENA_HOME = athena_home_env

        self.path = os.path.join(Config.ATHENA_HOME, "config", filename)
        self.config: dict[str, Any] = {}
        self._load()

    def _load(self):
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                self.config = yaml.safe_load(f)
        except FileNotFoundError:
            self.config = {}
        except Exception as e:
            raise RuntimeError(f"Failed to load config file {self.path}") from e

    def get_value(self, key: str, default=None):
        if self.config is None:
            raise RuntimeError("Configuration not loaded.")

        parts = key.split('/')
        val = self.config
        try:
            for part in parts:
                val = val[part]
            return val
        except (KeyError, TypeError):
            return default


# Timezone utilities for UTC-based time handling
_timezone_offset_seconds: int = 9 * 3600  # Default: GMT+09:00 (KST)
_config_loaded: bool = False


def _parse_timezone_offset(tz_string: str) -> int:
    """
    Parse timezone string like "GMT+09:00" or "GMT-05:00" and return offset in seconds.

    Args:
        tz_string: Timezone string (e.g., "GMT+09:00", "GMT-05:00")

    Returns:
        Offset in seconds from UTC
    """
    if not tz_string:
        return 9 * 3600  # Default GMT+09:00

    tz_string = tz_string.strip()
    if tz_string.startswith("GMT"):
        offset_str = tz_string[3:]  # "+09:00" or "-05:00"
        match = re.match(r'([+-])(\d{1,2}):?(\d{2})?', offset_str)
        if match:
            sign = -1 if match.group(1) == '-' else 1
            hours = int(match.group(2))
            minutes = int(match.group(3)) if match.group(3) else 0
            return sign * (hours * 3600 + minutes * 60)

    return 9 * 3600  # Default GMT+09:00


def load_timezone_config():
    """Load timezone configuration from athena-agent.yaml."""
    global _timezone_offset_seconds, _config_loaded

    if _config_loaded:
        return

    try:
        config = Config("athena-agent.yaml")
        tz_string = config.get_value("locale/timezone", "GMT+09:00")
        _timezone_offset_seconds = _parse_timezone_offset(tz_string)
        _config_loaded = True
    except Exception:
        # Use default if config loading fails
        _timezone_offset_seconds = 9 * 3600
        _config_loaded = True


def get_timezone_offset_seconds() -> int:
    """
    Get timezone offset in seconds from UTC.

    Returns:
        Timezone offset in seconds (e.g., 32400 for GMT+09:00)
    """
    if not _config_loaded:
        load_timezone_config()
    return _timezone_offset_seconds


def get_timezone_offset_minutes() -> int:
    """
    Get timezone offset in minutes from UTC.

    Returns:
        Timezone offset in minutes (e.g., 540 for GMT+09:00)
    """
    return get_timezone_offset_seconds() // 60


def utc_now() -> datetime:
    """
    Get current UTC datetime.

    Returns:
        Current UTC datetime with timezone info
    """
    return datetime.now(timezone.utc)


def utc_timestamp() -> float:
    """
    Get current UTC timestamp in seconds.

    Returns:
        UTC timestamp (seconds since epoch)
    """
    return datetime.now(timezone.utc).timestamp()


def utc_to_local(utc_dt: datetime) -> datetime:
    """
    Convert UTC datetime to local datetime based on configured timezone.

    Args:
        utc_dt: UTC datetime

    Returns:
        Local datetime
    """
    offset = get_timezone_offset_seconds()
    local_tz = timezone(timedelta(seconds=offset))
    return utc_dt.astimezone(local_tz)


def local_now() -> datetime:
    """
    Get current local datetime based on configured timezone.

    Returns:
        Current local datetime
    """
    return utc_to_local(utc_now())


def format_utc(fmt: str = "%Y-%m-%d %H:%M:%S") -> str:
    """
    Get formatted current UTC time string.

    Args:
        fmt: strftime format string

    Returns:
        Formatted UTC time string
    """
    return utc_now().strftime(fmt)


def format_local(fmt: str = "%Y-%m-%d %H:%M:%S") -> str:
    """
    Get formatted current local time string.

    Args:
        fmt: strftime format string

    Returns:
        Formatted local time string
    """
    return local_now().strftime(fmt)