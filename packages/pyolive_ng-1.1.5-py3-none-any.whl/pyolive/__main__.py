from .agent import Agent

def main():
    agent = Agent()
    agent.run()