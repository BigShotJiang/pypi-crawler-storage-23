from typing import TypeAlias, List

Vector: TypeAlias = List[int]
VectorArray: TypeAlias = List[Vector]
VectorArrayArray: TypeAlias = List[VectorArray]
