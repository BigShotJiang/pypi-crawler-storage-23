"""
Unit tests for AsyncAstrolabeClient — mirrors the sync test_client.py structure.
"""

import asyncio
import os
import json
import time
import unittest
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
import httpx

from astrolabe.client import AsyncAstrolabeClient, Environment
from astrolabe.settings import AstrolabeSettings


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def _make_client(env="development", **kwargs):
    """Create an AsyncAstrolabeClient *without* hitting the network.

    The ASTROLABE_API_URL env-var is explicitly cleared so the client starts
    in offline mode (no fetch / no polling).
    """
    with patch.dict(os.environ, {}, clear=True):
        # Remove ASTROLABE_API_URL if present
        os.environ.pop("ASTROLABE_API_URL", None)
        return AsyncAstrolabeClient(env, **kwargs)


# ---------------------------------------------------------------------------
# Initialisation
# ---------------------------------------------------------------------------

class TestAsyncClientInitialization(unittest.TestCase):
    """Construction-time checks — no event loop needed."""

    def setUp(self):
        os.environ.pop("ASTROLABE_API_URL", None)

    def test_init_with_string_env(self):
        client = _make_client("development")
        self.assertEqual(client.env, Environment.DEVELOPMENT)

    def test_init_with_enum_env(self):
        client = _make_client(env=Environment.STAGING)
        self.assertEqual(client.env, Environment.STAGING)

    def test_init_case_insensitive(self):
        client = _make_client("PRODUCTION")
        self.assertEqual(client.env, Environment.PRODUCTION)

    def test_init_invalid_env_string(self):
        with self.assertRaises(ValueError):
            _make_client("nope")

    def test_init_invalid_env_type(self):
        with self.assertRaises(TypeError):
            _make_client(env=42)

    def test_init_dict_settings(self):
        client = _make_client(settings={"poll_interval": 120})
        self.assertIsInstance(client.settings, AstrolabeSettings)
        self.assertEqual(client.settings.poll_interval, 120)

    def test_init_settings_object(self):
        s = AstrolabeSettings(poll_interval=999)
        client = _make_client(settings=s)
        self.assertEqual(client.settings.poll_interval, 999)

    def test_init_invalid_settings_type(self):
        with self.assertRaises(TypeError):
            _make_client(settings="bad")

    def test_init_without_api_url(self):
        client = _make_client()
        self.assertFalse(client._use_api)

    def test_httpx_import_error(self):
        """If httpx is not installed the constructor should raise ImportError."""
        with patch("astrolabe.client._HTTPX_AVAILABLE", False):
            with self.assertRaises(ImportError):
                _make_client()


# ---------------------------------------------------------------------------
# Async tests — use pytest-asyncio
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
class TestAsyncClientLifecycle:
    """start / close / context-manager behaviour."""

    async def test_start_creates_http_client(self):
        client = _make_client()
        await client.start()
        assert client._http_client is not None
        await client.close()

    async def test_close_clears_http_client(self):
        client = _make_client()
        await client.start()
        await client.close()
        assert client._http_client is None

    async def test_context_manager(self):
        async with _make_client() as client:
            assert client._http_client is not None
        assert client._http_client is None

    @patch.dict(os.environ, {"ASTROLABE_API_URL": "https://api.test.com"})
    async def test_start_fetches_and_polls_when_api_set(self):
        client = AsyncAstrolabeClient(
            "development", subscribed_projects=["proj"]
        )
        with patch.object(client, "_fetch_flags", new_callable=AsyncMock) as mock_fetch:
            await client.start()
            mock_fetch.assert_awaited_once()
            assert client._polling_task is not None
            await client.close()


# ---------------------------------------------------------------------------
# Flag fetching
# ---------------------------------------------------------------------------

def _mock_response(json_body, status_code=200):
    """Return an httpx.Response-like object."""
    resp = MagicMock(spec=httpx.Response)
    resp.status_code = status_code
    resp.json.return_value = json_body
    resp.raise_for_status = MagicMock()
    if status_code >= 400:
        resp.raise_for_status.side_effect = httpx.HTTPStatusError(
            "error", request=MagicMock(), response=resp
        )
    return resp


@pytest.mark.asyncio
class TestAsyncFetchFlags:

    async def test_fetch_project_flags_feature_flags_format(self):
        """Handles the standard {feature_flags: [...], total_count: N} response."""
        flags = [
            {"key": "flag-a", "environments": {}},
            {"key": "flag-b", "environments": {}},
        ]

        client = _make_client(subscribed_projects=["proj"])
        client._use_api = True
        client._api_url = "https://api.test.com"

        mock_http = AsyncMock(spec=httpx.AsyncClient)
        mock_http.get.return_value = _mock_response(
            {"feature_flags": flags, "total_count": 2}
        )
        client._http_client = mock_http

        result = await client._fetch_project_flags("proj")
        assert len(result) == 2
        assert result[0]["key"] == "flag-a"

    async def test_fetch_project_flags_list_format(self):
        flags = [{"key": "x", "environments": {}}]

        client = _make_client(subscribed_projects=["p"])
        client._use_api = True
        client._api_url = "https://api.test.com"

        mock_http = AsyncMock(spec=httpx.AsyncClient)
        mock_http.get.return_value = _mock_response(flags)
        client._http_client = mock_http

        result = await client._fetch_project_flags("p")
        assert len(result) == 1

    async def test_fetch_flags_populates_cache(self):
        flags = [{"key": "flag1", "environments": {}}]

        client = _make_client(subscribed_projects=["proj"])
        client._use_api = True
        client._api_url = "https://api.test.com"

        mock_http = AsyncMock(spec=httpx.AsyncClient)
        mock_http.get.return_value = _mock_response(
            {"feature_flags": flags, "total_count": 1}
        )
        client._http_client = mock_http

        await client._fetch_flags()
        assert "proj/flag1" in client._flags_cache

    async def test_fetch_flags_skips_when_no_api(self):
        client = _make_client()  # _use_api == False
        await client._fetch_flags()
        assert len(client._flags_cache) == 0

    async def test_fetch_flags_skips_when_no_projects(self):
        client = _make_client()
        client._use_api = True
        client._api_url = "https://x.com"
        client._http_client = AsyncMock()

        await client._fetch_flags()
        assert len(client._flags_cache) == 0

    async def test_fetch_flags_handles_http_error(self):
        client = _make_client(subscribed_projects=["proj"])
        client._use_api = True
        client._api_url = "https://api.test.com"

        mock_http = AsyncMock(spec=httpx.AsyncClient)
        mock_http.get.return_value = _mock_response({}, status_code=500)
        client._http_client = mock_http

        # Should not raise
        await client._fetch_flags()
        assert len(client._flags_cache) == 0

    async def test_fetch_project_flags_pagination(self):
        """Verifies pagination stops when page_flags < limit."""
        page1 = [{"key": f"f{i}", "environments": {}} for i in range(1000)]
        page2 = [{"key": "f1000", "environments": {}}]

        client = _make_client(subscribed_projects=["proj"])
        client._use_api = True
        client._api_url = "https://api.test.com"

        mock_http = AsyncMock(spec=httpx.AsyncClient)
        mock_http.get.side_effect = [
            _mock_response({"feature_flags": page1, "total_count": 1001}),
            _mock_response({"feature_flags": page2, "total_count": 1001}),
        ]
        client._http_client = mock_http

        result = await client._fetch_project_flags("proj")
        assert len(result) == 1001
        assert mock_http.get.call_count == 2

    async def test_fetch_project_flags_legacy_flags_key(self):
        """Handles legacy {flags: [...]} response format."""
        flags = [{"key": "old", "environments": {}}]
        client = _make_client(subscribed_projects=["p"])
        client._use_api = True
        client._api_url = "https://api.test.com"

        mock_http = AsyncMock(spec=httpx.AsyncClient)
        mock_http.get.return_value = _mock_response({"flags": flags})
        client._http_client = mock_http

        result = await client._fetch_project_flags("p")
        assert len(result) == 1

    async def test_fetch_project_flags_legacy_data_key(self):
        """Handles legacy {data: [...]} response format."""
        flags = [{"key": "d", "environments": {}}]
        client = _make_client(subscribed_projects=["p"])
        client._use_api = True
        client._api_url = "https://api.test.com"

        mock_http = AsyncMock(spec=httpx.AsyncClient)
        mock_http.get.return_value = _mock_response({"data": flags})
        client._http_client = mock_http

        result = await client._fetch_project_flags("p")
        assert len(result) == 1


# ---------------------------------------------------------------------------
# Polling
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
class TestAsyncPolling:

    async def test_polling_calls_fetch(self):
        client = _make_client()
        client._use_api = True
        client.settings = AstrolabeSettings(poll_interval=0.05)

        call_count = 0
        original_fetch = client._fetch_flags

        async def counting_fetch():
            nonlocal call_count
            call_count += 1

        client._fetch_flags = counting_fetch  # type: ignore[assignment]

        client._start_polling()
        await asyncio.sleep(0.2)
        await client.stop_polling()

        assert call_count >= 1

    async def test_stop_polling_cancels_task(self):
        client = _make_client()
        client._use_api = True
        client.settings = AstrolabeSettings(poll_interval=60)

        client._fetch_flags = AsyncMock()  # type: ignore[assignment]
        client._start_polling()
        assert client._polling_task is not None

        await client.stop_polling()
        assert client._polling_task is None


# ---------------------------------------------------------------------------
# refresh_flags (async)
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
class TestAsyncRefreshFlags:

    async def test_refresh_flags_delegates_to_fetch(self):
        client = _make_client()
        client._fetch_flags = AsyncMock()  # type: ignore[assignment]

        await client.refresh_flags()
        client._fetch_flags.assert_awaited_once()


# ---------------------------------------------------------------------------
# Flag evaluation (sync — pure cache reads)
# ---------------------------------------------------------------------------

class TestAsyncClientFlagEvaluation(unittest.TestCase):
    """Flag getters are sync; they just read the in-memory cache."""

    def setUp(self):
        os.environ.pop("ASTROLABE_API_URL", None)
        self.client = _make_client("development")

    # --- defaults when flag missing ---

    def test_get_bool_default(self):
        self.assertTrue(self.client.get_bool("missing", True))
        self.assertFalse(self.client.get_bool("missing", False))

    def test_get_string_default(self):
        self.assertEqual(self.client.get_string("missing", "fallback"), "fallback")

    def test_get_number_default_int(self):
        self.assertEqual(self.client.get_number("missing", 42), 42)

    def test_get_number_default_float(self):
        self.assertEqual(self.client.get_number("missing", 3.14), 3.14)

    def test_get_json_default(self):
        d = {"a": 1}
        self.assertEqual(self.client.get_json("missing", d), d)

    def test_get_flag_routes_bool(self):
        self.assertIsInstance(self.client.get_flag("x", True), bool)

    def test_get_flag_routes_string(self):
        self.assertIsInstance(self.client.get_flag("x", "s"), str)

    def test_get_flag_routes_number(self):
        self.assertIsInstance(self.client.get_flag("x", 1), (int, float))

    def test_get_flag_routes_dict(self):
        self.assertIsInstance(self.client.get_flag("x", {}), dict)

    # --- values from cache ---

    def _inject_flag(self, key, config):
        self.client._flags_cache[key] = config

    def test_get_bool_from_cache(self):
        self._inject_flag("proj/flag", {
            "key": "flag",
            "environments": {
                "development": {"enabled": True, "value": True, "rules": []}
            },
        })
        with patch.object(self.client._rule_engine, "evaluate_flag", return_value=True):
            self.assertTrue(self.client.get_bool("proj/flag", False))

    def test_get_string_from_cache(self):
        self._inject_flag("proj/color", {
            "key": "color",
            "environments": {
                "development": {"enabled": True, "value": "blue", "rules": []}
            },
        })
        with patch.object(self.client._rule_engine, "evaluate_flag", return_value="blue"):
            self.assertEqual(self.client.get_string("proj/color", "red"), "blue")

    def test_get_number_from_cache(self):
        self._inject_flag("proj/limit", {
            "key": "limit",
            "environments": {
                "development": {"enabled": True, "value": 100, "rules": []}
            },
        })
        with patch.object(self.client._rule_engine, "evaluate_flag", return_value=100):
            self.assertEqual(self.client.get_number("proj/limit", 10), 100)

    def test_get_json_from_cache(self):
        payload = {"tier": "premium"}
        self._inject_flag("proj/config", {
            "key": "config",
            "environments": {
                "development": {"enabled": True, "value": payload, "rules": []}
            },
        })
        with patch.object(self.client._rule_engine, "evaluate_flag", return_value=payload):
            self.assertEqual(self.client.get_json("proj/config", {}), payload)

    # --- type coercion ---

    def test_get_number_from_string_int(self):
        self._inject_flag("proj/n", {
            "key": "n",
            "environments": {"development": {"enabled": True, "value": "7", "rules": []}},
        })
        with patch.object(self.client._rule_engine, "evaluate_flag", return_value="7"):
            self.assertEqual(self.client.get_number("proj/n", 0), 7)

    def test_get_number_from_string_float(self):
        self._inject_flag("proj/n", {
            "key": "n",
            "environments": {"development": {"enabled": True, "value": "3.5", "rules": []}},
        })
        with patch.object(self.client._rule_engine, "evaluate_flag", return_value="3.5"):
            self.assertAlmostEqual(self.client.get_number("proj/n", 0), 3.5)

    def test_get_bool_from_string_true(self):
        self._inject_flag("proj/b", {
            "key": "b",
            "environments": {"development": {"enabled": True, "value": "yes", "rules": []}},
        })
        with patch.object(self.client._rule_engine, "evaluate_flag", return_value="yes"):
            self.assertTrue(self.client.get_bool("proj/b", False))

    def test_get_json_from_string(self):
        self._inject_flag("proj/j", {
            "key": "j",
            "environments": {"development": {"enabled": True, "value": '{"x":1}', "rules": []}},
        })
        with patch.object(self.client._rule_engine, "evaluate_flag", return_value='{"x":1}'):
            self.assertEqual(self.client.get_json("proj/j", {}), {"x": 1})


# ---------------------------------------------------------------------------
# Project subscription validation
# ---------------------------------------------------------------------------

class TestAsyncProjectSubscription(unittest.TestCase):

    def setUp(self):
        os.environ.pop("ASTROLABE_API_URL", None)

    def test_invalid_key_format_returns_default(self):
        client = _make_client(subscribed_projects=["proj"])
        self.assertEqual(client.get_string("no-slash", "default"), "default")

    def test_unsubscribed_project_returns_default(self):
        client = _make_client(subscribed_projects=["proj"])
        self.assertEqual(client.get_string("other/flag", "default"), "default")

    def test_subscribed_project_proceeds(self):
        client = _make_client(subscribed_projects=["proj"])
        # Flag not in cache → still returns default, but via cache miss not subscription check
        self.assertEqual(client.get_string("proj/flag", "default"), "default")


# ---------------------------------------------------------------------------
# get_cache_info
# ---------------------------------------------------------------------------

class TestAsyncCacheInfo(unittest.TestCase):

    def test_cache_info_keys(self):
        client = _make_client()
        info = client.get_cache_info()
        for key in ("flag_count", "last_updated", "seconds_since_update",
                     "environment", "poll_interval", "api_url"):
            self.assertIn(key, info)

    def test_cache_info_reflects_env(self):
        client = _make_client("staging")
        self.assertEqual(client.get_cache_info()["environment"], "staging")
