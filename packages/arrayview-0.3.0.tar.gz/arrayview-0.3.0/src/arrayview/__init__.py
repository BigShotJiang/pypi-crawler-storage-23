__version__ = "0.2.4"

from arrayview._app import arrayview, view  # noqa: F401
