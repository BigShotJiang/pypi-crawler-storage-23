from .processor import BatchOCR

__all__ = ["BatchOCR"]
