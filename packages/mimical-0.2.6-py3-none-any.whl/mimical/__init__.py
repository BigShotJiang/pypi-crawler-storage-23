from . import fitting
from . import plotting

from .fitting import fit
from .fitting import fitCatalogue

