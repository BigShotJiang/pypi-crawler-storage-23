"""NASA Protocol Helpers."""
