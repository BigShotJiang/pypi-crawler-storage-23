"""Interactive CLI for Samsung NASA."""

import asyncio
import logging

from prompt_toolkit import PromptSession
from prompt_toolkit.patch_stdout import patch_stdout
from prompt_toolkit.completion import Completer, Completion
from prompt_toolkit.shortcuts import CompleteStyle

from .nasa import SamsungNasa
from .device import NasaDevice
from .protocol.enum import DataType
from .protocol.factory import build_message, SendMessage
from .protocol.factory.messages import MESSAGE_PARSERS

_LOGGER = logging.getLogger(__name__)


class CLICompleter(Completer):
    """Custom completer for the CLI."""

    def __init__(self, nasa: SamsungNasa):
        """Initialize completer with NASA instance."""
        self.nasa = nasa
        self.commands = [
            "read",
            "read-range",
            "write",
            "set",
            "device",
            "climate",
            "config",
            "logger",
            "quit",
            "help",
            "print packet stream",
        ]
        self.config_subcommands = ["set", "read", "append", "dump"]
        self.logger_subcommands = ["follow", "print"]
        self.climate_modes = ["dhw", "heat"]
        self.climate_commands = ["on", "off"]
        self.device_subcommands = ["dump"]

    def get_completions(self, document, complete_event):
        """Generate completions based on input."""
        text = document.text_before_cursor
        parts = text.split()

        # If no text, suggest all commands
        if not parts:
            for cmd in self.commands:
                yield Completion(cmd)
            return

        # Single word being typed - complete commands
        if len(parts) == 1:
            word = parts[0].lower()
            for cmd in self.commands:
                if cmd.startswith(word):
                    yield Completion(cmd, start_position=-len(word))
            return

        # If text ends with space, suggest next argument based on command
        if text.endswith(" "):
            command = parts[0].lower()

            if command == "config":
                # Suggest config subcommands
                for sub in self.config_subcommands:
                    yield Completion(sub)

            elif command == "logger":
                # Suggest logger subcommands
                for sub in self.logger_subcommands:
                    yield Completion(sub)

            elif command == "climate" and len(parts) == 2:
                # After "climate ", suggest device addresses
                for addr in self.nasa.devices.keys():
                    yield Completion(addr)

            elif command == "climate" and len(parts) == 3:
                # After "climate <device> ", suggest climate modes (dhw/heat)
                for m in self.climate_modes:
                    yield Completion(m)

            elif command == "climate" and len(parts) == 4:
                # After "climate <device> <mode> ", suggest on/off
                for c in self.climate_commands:
                    yield Completion(c)

            elif command == "device":
                # Suggest either dump or device addresses
                suggestions = [*self.device_subcommands, *self.nasa.devices.keys()]
                for suggestion in suggestions:
                    yield Completion(suggestion)

            elif command in ("dump", "read", "write", "set", "read-range"):
                # Suggest device addresses
                for addr in self.nasa.devices.keys():
                    yield Completion(addr)
        else:
            # Partial word being typed
            word = parts[-1].lower()
            command = parts[0].lower()

            if command == "config" and len(parts) == 2:
                # Suggest config subcommands
                for sub in self.config_subcommands:
                    if sub.startswith(word):
                        yield Completion(sub, start_position=-len(word))

            elif command == "logger" and len(parts) == 2:
                # Suggest logger subcommands
                for sub in self.logger_subcommands:
                    if sub.startswith(word):
                        yield Completion(sub, start_position=-len(word))

            elif command == "climate" and len(parts) == 2:
                # Suggest device addresses
                for addr in self.nasa.devices.keys():
                    if addr.lower().startswith(word):
                        yield Completion(addr, start_position=-len(word))

            elif command == "climate" and len(parts) == 3:
                # Suggest climate modes (dhw/heat)
                for m in self.climate_modes:
                    if m.startswith(word):
                        yield Completion(m, start_position=-len(word))

            elif command == "climate" and len(parts) == 4:
                # Suggest on/off
                for c in self.climate_commands:
                    if c.startswith(word):
                        yield Completion(c, start_position=-len(word))

            elif command in ("device", "dump", "read", "write", "set", "read-range") and len(parts) == 2:
                # Suggest device addresses
                for addr in self.nasa.devices.keys():
                    if addr.lower().startswith(word):
                        yield Completion(addr, start_position=-len(word))


async def follow_logs():
    """Follow logs."""

    def log_handler(record: logging.LogRecord):
        print(f"{record.levelname}: {record.getMessage()}")

    logger = logging.getLogger("pysamsungnasa")
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler()
    handler.emit = log_handler
    logger.addHandler(handler)

    try:
        while True:
            await asyncio.sleep(1)
    except (KeyboardInterrupt, asyncio.CancelledError):
        pass
    finally:
        logger.removeHandler(handler)


def print_device_header(device: NasaDevice):
    """Print device header."""
    print(f"Device {device.address}:")
    print(f"  Last seen: {device.last_packet_time}")
    print(f"  Address: {device.address}")
    print(f"  Device Type: {device.device_type}")
    print(f"  Config: {device.config}")
    print(f"  Total attributes: {len(device.attributes)}")
    print(f"  FSV Config: {device.fsv_config}")


def dump_device_data(device: NasaDevice):
    """Dump all device data back into hex format to a file in the hex format, suitable for re-import."""
    print(f"Device {device.address} will dump to {device.address}_dump.hex")
    source_address = device.address
    destination_address = "b0ffff"  # Broadcast address
    message_type = DataType.NOTIFICATION
    messages: list[str] = []
    cur_pack_number = 0
    for msg_id, value in device.attributes.items():
        messages.append(
            build_message(source_address, destination_address, message_type, [SendMessage(msg_id, value.RAW_PAYLOAD)])
        )
    with open(f"{device.address}_dump.hex", "w", encoding="utf-8") as f:
        for msg in messages:
            f.write(msg.format(CUR_PACK_NUM=cur_pack_number.to_bytes(2, "big").hex()) + "\n")
            cur_pack_number += 1
            if cur_pack_number > 255:
                cur_pack_number = 0


async def print_logs():
    """Print last 20 lines of logs."""

    try:
        # Read nasa.log to get last 20 lines
        with open("nasa.log", "r", encoding="utf-8") as f:
            lines = f.readlines()[-20:]
        for line in lines:
            print(line.strip())
    except Exception as e:
        print(f"Error reading nasa.log: {e}")


async def interactive_cli(nasa: SamsungNasa):
    """Interactive CLI."""
    print("Samsung NASA Interactive CLI. Type 'help' for a list of commands.")
    completer = CLICompleter(nasa)
    session = PromptSession(
        completer=completer,
        complete_style=CompleteStyle.MULTI_COLUMN,
        complete_while_typing=False,
    )
    while True:
        try:
            with patch_stdout():
                command_str = await session.prompt_async("> ")
            if not command_str:
                continue

            parts = command_str.strip().split()
            command = parts[0].lower()

            if command == "quit":
                break
            elif command == "help":
                print("Commands:")
                print("  read <device_address> <message_id_hex>")
                print("  read-range <device_address> <start_message_id_hex> <count>")
                print("  write <device_address> <message_id_hex> <value_hex>")
                print("  set <device_address> <message_id_hex> <value>")
                print("  device <device_address> <message_id_hex>")
                print("  device <device_address> dump")
                print("  device dump")
                print("  climate <device_address> <dhw/heat>")
                print("  config set <key> <value>")
                print("  config append <key> <value>")
                print("  config read <key>")
                print("  config dump")
                print("  logger follow")
                print("  print packet stream")
                print("  quit")
                continue
            elif command in ("read", "write", "set") and len(parts) >= 3:
                device_id = parts[1]
                try:
                    message_id = int(parts[2], 16)
                except ValueError:
                    print(f"Invalid message_id: {parts[2]}")
                    continue

                if command == "read":
                    if len(parts) != 3:
                        print("Usage: read <device_id> <message_id_hex>")
                        continue
                    print(f"Reading from {device_id}, message {hex(message_id)}")
                    response = await nasa.client.nasa_read([message_id], device_id)
                    print(f"Response: {response}")

                elif command == "write":
                    if len(parts) != 4:
                        print("Usage: write <device_id> <message_id_hex> <value_hex>")
                        continue
                    value = parts[3]
                    print(f"Writing to {device_id}, message {hex(message_id)}, value {value}")
                    response = await nasa.client.nasa_write(message_id, value, device_id, DataType.WRITE)
                    print(f"Response: {response}")
                elif command == "set":
                    if len(parts) != 4:
                        print("Usage: set <device_id> <message_id_hex> <value>")
                        continue
                    value = parts[3]
                    print(f"Setting on {device_id}, message {hex(message_id)}, value {value}")
                    # Get message parser to convert hex to message type
                    message = MESSAGE_PARSERS.get(message_id)
                    if not message:
                        print(f"Unknown message ID: {hex(message_id)}")
                        continue
                    if device_id not in nasa.devices:
                        print(f"Unknown device ID: {device_id}")
                        continue
                    await nasa.devices[device_id].write_attribute(message, float(value))
                    print(f"Write attribute complete for {message.MESSAGE_NAME}")
            elif command == "read-range" and len(parts) == 4:
                device_id = parts[1]
                try:
                    start_message_id = int(parts[2], 16)
                    count = int(parts[3])
                except ValueError:
                    print(f"Invalid message_id or count: {parts[2]}, {parts[3]}")
                    continue
                message_ids = [start_message_id + i for i in range(count)]
                print(f"Reading from {device_id}, messages {[hex(mid) for mid in message_ids]}")
                for message_id in message_ids:
                    response = await nasa.client.nasa_read([message_id], device_id)
                    print(f"Response: {response}")
            elif command == "device":
                if len(parts) == 1:
                    # Print all devices
                    for device in nasa.devices.values():
                        print_device_header(device)
                elif len(parts) == 2:
                    device_id = parts[1]
                    if device_id == "dump":
                        for device in nasa.devices.values():
                            dump_device_data(device)
                    elif device_id in nasa.devices:
                        device = nasa.devices[device_id]
                        print_device_header(device)
                        for k, v in device.attributes.items():
                            print(f"  {k}: {v.as_dict}")
                    else:
                        print(f"Device {device_id} not found")
                elif len(parts) == 3:
                    device_id = parts[1]
                    sub_command = parts[2].lower()
                    if sub_command == "dump":
                        if device_id in nasa.devices:
                            device = nasa.devices[device_id]
                            dump_device_data(device)
                        else:
                            print(f"Device {device_id} not found")
                    else:
                        # Convert str to decimal (0x4097 -> 16503)
                        message_id = int(parts[2], 16)
                        if device_id in nasa.devices:
                            device = nasa.devices[device_id]
                            print_device_header(device)
                            if message_id in device.attributes:
                                print(f"  {message_id}: {device.attributes[message_id].as_dict}")
                            else:
                                print(f"  {message_id} not found")
                        else:
                            print(f"Device {device_id} not found")
                else:
                    print("Usage: device [<device_address> [<message_id_hex>]]")
                    print("  Without arguments, lists all devices.")
                    print("  With device_address, lists all attributes of the device.")
                    print("  With device_address and message_id, prints the value of the attribute.")
            elif command == "config":
                if len(parts) >= 3 and parts[1] == "set":
                    if len(parts) == 4:
                        key = parts[2]
                        value = parts[3]
                        setattr(nasa.config, key, value)
                        print(f"Config set: {key} = {value}")
                    else:
                        print("Usage: config set <key> <value>")
                elif len(parts) >= 3 and parts[1] == "read":
                    if len(parts) == 3:
                        key = parts[2]
                        print(f"Config read: {key} = {getattr(nasa.config, key)}")
                    else:
                        print("Usage: config read <key>")
                elif len(parts) >= 3 and parts[1] == "append":
                    if len(parts) == 4:
                        key = parts[2]
                        value = parts[3]
                        if value.startswith("0x"):
                            value = int(value, 16)
                        elif value.startswith("i"):
                            value = int(value[1:])
                        elif value.startswith("f"):
                            value = float(value[1:])
                        current_value = getattr(nasa.config, key)
                        if isinstance(current_value, list):
                            current_value.append(value)
                            setattr(nasa.config, key, current_value)
                            print(f"Config append: {key} += {value}")
                        else:
                            print(f"Config key {key} is not a list")
                    else:
                        print("Usage: config append <key> <value>")
                elif len(parts) == 2 and parts[1] == "dump":
                    for key, value in nasa.config.__dict__.items():
                        print(f"{key}: {value}")
                else:
                    print(
                        "Usage: config set <key> <value> or config read <key> or config append <key> <value> or config dump"
                    )
            elif command == "logger" and len(parts) == 2 and parts[1] == "follow":
                await follow_logs()
            elif command == "logger" and len(parts) == 2 and parts[1] == "print":
                await print_logs()
            elif command == "dump" and len(parts) == 2:
                device_id = parts[1]
                if device_id == "all":
                    for device in nasa.devices.values():
                        dump_device_data(device)
                elif device_id in nasa.devices:
                    device = nasa.devices[device_id]
                    # Sort attributes by message ID
                    sorted_attrs = dict(sorted(device.attributes.items()))
                    for k, v in sorted_attrs.items():
                        # Print k as hex
                        print(f"  {hex(k)}: {v.as_dict}")
                else:
                    print(f"Device {device_id} not found")
            elif command == "quit":
                break
            elif command_str == "print packet stream":
                print("Printing packet stream (press Ctrl+C to stop):")
                try:
                    # Inject ourselves into the packet handler
                    async for packet_bytes in nasa.parser.get_raw_packet_stream():
                        print(f"Packet: {packet_bytes.hex()}")
                except (KeyboardInterrupt, asyncio.CancelledError):
                    print("Stopped printing packet stream.")
            else:
                print(f"Unknown command: {command_str}")

        except (KeyboardInterrupt, asyncio.CancelledError):
            break
        except Exception as e:
            _LOGGER.error("Error in CLI: %s", e)
