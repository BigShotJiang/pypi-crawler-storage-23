from .rigorous import RigorousTheoreticalCheck

__all__ = ['RigorousTheoreticalCheck']
