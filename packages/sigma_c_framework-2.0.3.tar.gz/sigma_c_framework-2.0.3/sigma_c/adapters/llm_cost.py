"""
Sigma-C LLM Cost Adapter
========================
Copyright (c) 2025 ForgottenForge.xyz

Optimizes Model Selection based on Cost vs. Safety (Hallucination Rate).
"""

from ..core.base import SigmaCAdapter
import numpy as np
from typing import Dict, Any, List

class LLMCostAdapter(SigmaCAdapter):
    """
    Adapter for Large Language Models.
    Optimizes the trade-off between Inference Cost and Model Quality/Safety.
    """

    def __init__(self, config: Dict[str, Any] = None):
        super().__init__(config)
        self.budget_per_1k = self.config.get('budget_per_1k', 0.01)

    def get_observable(self, data: np.ndarray, **kwargs) -> float:
        """
        Returns the 'Value Ratio': Quality / Cost.
        """
        data = np.asarray(data)
        if data.ndim < 2 or data.shape[1] < 2:
            return 0.0
        quality = data[:, 0]
        cost = data[:, 1]
        return float(np.mean(quality / (cost + 1e-9)))

    def analyze_cost_safety(self, models: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Analyzes a list of models to find the Pareto frontier of Cost vs Safety.

        models: List of dicts with {'name', 'cost', 'hallucination_rate'}
        """
        costs = np.array([m['cost'] for m in models])
        rates = np.array([m['hallucination_rate'] for m in models])
        names = [m['name'] for m in models]

        MAX_HALLUCINATION_RATE = 0.15
        valid_mask = rates < MAX_HALLUCINATION_RATE

        scores = np.zeros_like(costs)

        if np.any(valid_mask):
            scores[valid_mask] = 1.0 / (costs[valid_mask] * rates[valid_mask] + 1e-9)
            scores[~valid_mask] = -1.0
        else:
            best_idx = int(np.argmin(rates))
            return {
                'best_model': names[best_idx],
                'optimal_cost': float(costs[best_idx]),
                'safety_score': float(1.0 - rates[best_idx]),
                'sigma_c': float(1.0 - rates[best_idx]),
                'warning': 'No models met safety criteria'
            }

        best_idx = int(np.argmax(scores))

        sigma_c = 1.0 - rates[best_idx]

        return {
            'best_model': names[best_idx],
            'optimal_cost': float(costs[best_idx]),
            'safety_score': float(1.0 - rates[best_idx]),
            'sigma_c': float(sigma_c)
        }

    def _domain_specific_validate(self, data: Any = None, **kwargs) -> Dict[str, bool]:
        """Validate LLM cost analysis configuration."""
        checks = {
            'budget_configured': self.budget_per_1k > 0,
            'basic_validation': True
        }
        return checks
