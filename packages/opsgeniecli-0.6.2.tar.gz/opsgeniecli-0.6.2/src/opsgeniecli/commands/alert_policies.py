from typing import Annotated, Any, List, Optional
import typer
from rich.console import Console
from opsgeniecli.helper import _apply_regex_filters, get_table, show_table_and_confirm
import re
import datetime

app = typer.Typer(
    rich_markup_mode="rich", no_args_is_help=True, help="Manage Opsgenie alert policies"
)
console = Console()


# Helper functions for alert policies


def _alert_policy_to_dict(policy) -> dict[str, Any]:
    """Convert an AlertPolicy object to a dictionary.

    Args:
        policy: AlertPolicy object from opsgenielib

    Returns:
        Dictionary with policy attributes
    """
    return {
        "id": policy.id,
        "name": policy.name,
        "enabled": policy.enabled,
        "policyDescription": policy.description or "",  # Use the description property
        "teamId": policy._data.get("teamId", ""),  # Access raw data for teamId
    }


def _get_alert_policies_table_data(
    policies: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Convert alert policy data to flat dictionaries for table display.

    Args:
        policies: List of alert policy dictionaries

    Returns:
        List of flattened dictionaries ready for table display
    """
    return [
        {
            "id": policy["id"],
            "name": policy["name"],
            "enabled": str(policy["enabled"]),
            "description": policy.get("policyDescription", ""),
        }
        for policy in policies
    ]


def _fetch_policies_by_team(opsgenie, team_name: str) -> list[dict[str, Any]]:
    """Fetch alert policies for a specific team.

    Args:
        opsgenie: Opsgenie client instance
        team_name: Team name

    Returns:
        List of alert policy dictionaries
    """
    team = opsgenie.get_team_by_name(team_name)
    team_id = team.id  # Team object uses .id not .team_id

    # Get AlertPolicy objects and convert to dicts
    policy_objects = opsgenie.list_alert_policy(team_id=team_id)
    return [_alert_policy_to_dict(policy) for policy in policy_objects]


def _apply_filters_to_policies(
    policies: list[dict[str, Any]], filters: List[str]
) -> list[dict[str, Any]]:
    """Apply regex filters to alert policies data.

    Args:
        policies: List of alert policy dictionaries
        filters: List of filter strings in format "attribute:pattern"

    Returns:
        Filtered list of alert policies
    """
    if not filters:
        return policies

    filter_dict = {k: v for k, v in (filter.split(":", 1) for filter in filters)}
    table_data = _get_alert_policies_table_data(policies)
    filtered_data = _apply_regex_filters(data=table_data, filters=filter_dict)

    # Match filtered data back to original policies by ID
    filtered_ids = {item["id"] for item in filtered_data}
    return [policy for policy in policies if policy["id"] in filtered_ids]


def _update_policy_status(
    opsgenie, policy_id: str, team_id: str, enabled: bool
) -> dict[str, Any]:
    """Enable or disable an alert policy.

    Args:
        opsgenie: Opsgenie client instance
        policy_id: ID of the alert policy
        team_id: Team ID that owns the policy
        enabled: True to enable, False to disable

    Returns:
        API response dictionary
    """
    # Methods expect a list of IDs
    if enabled:
        return opsgenie.enable_policy(policy_id=[policy_id], team_id=team_id)
    else:
        return opsgenie.disable_policy(policy_id=[policy_id], team_id=team_id)


def _display_policy_update_result(
    policy_name: str, action: str, result: dict[str, Any]
) -> None:
    """Display the result of a policy update operation.

    Args:
        policy_name: Name of the policy that was updated
        action: Action performed (e.g., "enabled", "disabled", "deleted")
        result: API response dictionary
    """
    success = result.get("result") in ["Updated", "Deleted"]
    symbol = "✓" if success else "✗"
    typer.echo(f"{symbol} - Alert policy {action}: {policy_name}")


def _get_policy_by_id(opsgenie, policy_id: str, team_name: str) -> dict[str, Any]:
    """Fetch a single alert policy by ID with full details.

    Args:
        opsgenie: Opsgenie client instance
        policy_id: ID of the alert policy
        team_name: Team name

    Returns:
        Alert policy dictionary

    Raises:
        ValueError: If policy not found
    """
    # Get team ID first
    team = opsgenie.get_team_by_name(team_name)
    team_id = team.id

    # Use get_alert_policy to fetch full details including description
    try:
        policy_obj = opsgenie.get_alert_policy(id_=policy_id, team_id=team_id)
        return _alert_policy_to_dict(policy_obj)
    except Exception as e:
        raise ValueError(f"Alert policy with ID '{policy_id}' not found: {e}")


def _get_validation_table_data(alerts: list) -> list[dict[str, Any]]:
    """Convert Alert objects to table format for validation display.

    Args:
        alerts: List of Alert objects from opsgenielib

    Returns:
        List of dictionaries formatted for table display
    """
    import pytz

    timezone = pytz.timezone("UTC")

    return [
        {
            "id": alert.id[:12] + "...",  # Truncate for readability
            "message": (
                alert.message[:50] + "..." if len(alert.message) > 50 else alert.message
            ),
            "created": str(
                alert.created_at.astimezone(timezone).strftime("%Y-%m-%d %H:%M")
            ),
            "host": alert._data.get("details", {}).get("host", "")[:30] or "N/A",
        }
        for alert in alerts
    ]


def _fetch_recent_alerts(
    opsgenie, team_name: str, limit: int = 500, days: int = 30
) -> list:
    """Fetch recent alerts for a team within the specified time window.

    Args:
        opsgenie: Opsgenie client instance
        team_name: Team name to query alerts for
        limit: Maximum number of alerts to query
        days: Number of days to look back for alerts

    Returns:
        List of Alert objects from the last N days
    """
    # Verify team exists
    opsgenie.get_team_by_name(team_name)

    # Query recent alerts for the team
    query = f"responders:{team_name}"
    alerts = opsgenie.query_alerts(query=query, limit=limit)

    # Filter to last N days
    cutoff_date = datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(
        days=days
    )
    return [alert for alert in alerts if alert.created_at >= cutoff_date]


def _validate_policy_filter(
    opsgenie,
    team_name: str,
    filter_pattern: str,
    limit: int = 500,
    days: int = 30,
    cached_alerts: list | None = None,
) -> list:
    """Query recent alerts and return those matching the filter pattern.

    Args:
        opsgenie: Opsgenie client instance
        team_name: Team name to query alerts for
        filter_pattern: Regex pattern to match against alerts
        limit: Maximum number of alerts to query (ignored if cached_alerts provided)
        days: Number of days to look back for alerts (default: 30, ignored if cached_alerts provided)
        cached_alerts: Optional pre-fetched list of alerts to filter (performance optimization)

    Returns:
        List of Alert objects that match the filter pattern
    """
    # Use cached alerts if provided, otherwise fetch them
    if cached_alerts is not None:
        recent_alerts = cached_alerts
    else:
        recent_alerts = _fetch_recent_alerts(opsgenie, team_name, limit, days)

    # Compile the regex pattern
    try:
        regex = re.compile(filter_pattern)
    except re.error as e:
        raise ValueError(f"Invalid regex pattern: {e}")

    # Filter alerts matching the pattern in description or host fields
    matching_alerts = []
    for alert in recent_alerts:
        # Check message/description field
        description = alert._data.get("description", "") or alert.message or ""

        # Check host field in extra-properties or details
        host = alert._data.get("details", {}).get("host", "")

        # Match if either field matches
        if regex.search(str(description)) or regex.search(str(host)):
            matching_alerts.append(alert)

    return matching_alerts


# Commands in alphabetical order: delete, disable, enable, get, list, set


@app.command(name="delete")
def delete(
    ctx: typer.Context,
    id: Annotated[
        Optional[str], typer.Option(help="Delete specific policy by ID")
    ] = None,
    team: Annotated[Optional[str], typer.Option(help="Team name (required)")] = None,
    all: Annotated[bool, typer.Option(help="Delete all policies for the team")] = False,
    filters: Annotated[
        Optional[List[str]],
        typer.Option(help="Filter policies using 'attribute:pattern'"),
    ] = None,
):
    """Delete one or more alert policies.

    Deletes alert policies by ID, or multiple policies using --all or --filters.
    When using --all or --filters, shows a preview table and asks for confirmation.

    Args:
        id: Delete a specific policy by ID (requires --team)
        team: Team name (required)
        all: Delete all policies for the team (requires --team)
        filters: Delete policies matching filters (requires --team)

    Examples:
        Delete by ID:
            opsgeniecli alert-policies delete --id abc123 --team ops-team

        Delete all policies for a team (with confirmation):
            opsgeniecli alert-policies delete --all --team ops-team

        Delete filtered policies:
            opsgeniecli alert-policies delete --filters "name:.*test.*" --team ops-team
    """
    if not any([id, all, filters]):
        raise typer.BadParameter("Must specify one of: --id, --all, or --filters")

    if id and (all or filters):
        raise typer.BadParameter("Cannot use --id with --all or --filters")

    if not team:
        raise typer.BadParameter("Must specify --team")

    # Get team ID for API calls
    team_obj = ctx.obj.opsgenie.get_team_by_name(team)
    team_id = team_obj.id

    # Handle single policy deletion by ID
    if id:
        try:
            policy = _get_policy_by_id(ctx.obj.opsgenie, id, team)
            # delete_alert_policy expects a list of IDs
            result = ctx.obj.opsgenie.delete_alert_policy(
                alert_id=[id], team_id=team_id
            )
            _display_policy_update_result(policy["name"], "deleted", result)
        except ValueError as e:
            typer.echo(f"✗ - {e}")
            raise typer.Exit(code=1)
        return

    # Handle bulk deletion (all or filtered)
    policies = _fetch_policies_by_team(ctx.obj.opsgenie, team)

    if filters:
        policies = _apply_filters_to_policies(policies, filters)

    if not policies:
        typer.echo("No policies found matching criteria")
        return

    # Show preview and confirm
    show_table_and_confirm(
        data=_get_alert_policies_table_data(policies),
        title="Alert Policies to be Deleted",
        prompt="\nAre you sure you want to delete these policies?",
    )

    # Delete each policy
    for policy in policies:
        # delete_alert_policy expects a list of IDs
        result = ctx.obj.opsgenie.delete_alert_policy(
            alert_id=[policy["id"]], team_id=team_id
        )
        _display_policy_update_result(policy["name"], "deleted", result)


@app.command(name="disable")
def disable(
    ctx: typer.Context,
    id: Annotated[
        Optional[str], typer.Option(help="Disable specific policy by ID")
    ] = None,
    team: Annotated[Optional[str], typer.Option(help="Team name (required)")] = None,
    all: Annotated[
        bool, typer.Option(help="Disable all policies for the team")
    ] = False,
    filters: Annotated[
        Optional[List[str]],
        typer.Option(help="Filter policies using 'attribute:pattern'"),
    ] = None,
):
    """Disable one or more alert policies.

    Disables alert policies by ID, or multiple policies using --all or --filters.
    When using --all or --filters, shows a preview table and asks for confirmation.

    Args:
        id: Disable a specific policy by ID (requires --team)
        team: Team name (required)
        all: Disable all policies for the team (requires --team)
        filters: Disable policies matching filters (requires --team)

    Examples:
        Disable by ID:
            opsgeniecli alert-policies disable --id abc123 --team ops-team

        Disable all policies for a team (with confirmation):
            opsgeniecli alert-policies disable --all --team ops-team

        Disable filtered policies:
            opsgeniecli alert-policies disable --filters "name:.*test.*" --team ops-team
    """
    if not any([id, all, filters]):
        raise typer.BadParameter("Must specify one of: --id, --all, or --filters")

    if id and (all or filters):
        raise typer.BadParameter("Cannot use --id with --all or --filters")

    if not team:
        raise typer.BadParameter("Must specify --team")

    # Get team ID for API calls
    team_obj = ctx.obj.opsgenie.get_team_by_name(team)
    team_id = team_obj.id

    # Handle single policy disable by ID
    if id:
        try:
            policy = _get_policy_by_id(ctx.obj.opsgenie, id, team)
            result = _update_policy_status(ctx.obj.opsgenie, id, team_id, enabled=False)
            _display_policy_update_result(policy["name"], "disabled", result)
        except ValueError as e:
            typer.echo(f"✗ - {e}")
            raise typer.Exit(code=1)
        return

    # Handle bulk disable (all or filtered)
    policies = _fetch_policies_by_team(ctx.obj.opsgenie, team)

    if filters:
        policies = _apply_filters_to_policies(policies, filters)

    if not policies:
        typer.echo("No policies found matching criteria")
        return

    # Show preview and confirm
    show_table_and_confirm(
        data=_get_alert_policies_table_data(policies),
        title="Alert Policies to be Disabled",
        prompt="\nAre you sure you want to disable these policies?",
    )

    # Disable each policy
    for policy in policies:
        result = _update_policy_status(
            ctx.obj.opsgenie, policy["id"], team_id, enabled=False
        )
        _display_policy_update_result(policy["name"], "disabled", result)


@app.command(name="enable")
def enable(
    ctx: typer.Context,
    id: Annotated[
        Optional[str], typer.Option(help="Enable specific policy by ID")
    ] = None,
    team: Annotated[Optional[str], typer.Option(help="Team name (required)")] = None,
    all: Annotated[bool, typer.Option(help="Enable all policies for the team")] = False,
    filters: Annotated[
        Optional[List[str]],
        typer.Option(help="Filter policies using 'attribute:pattern'"),
    ] = None,
):
    """Enable one or more alert policies.

    Enables alert policies by ID, or multiple policies using --all or --filters.
    When using --all or --filters, shows a preview table and asks for confirmation.

    Args:
        id: Enable a specific policy by ID (requires --team)
        team: Team name (required)
        all: Enable all policies for the team (requires --team)
        filters: Enable policies matching filters (requires --team)

    Examples:
        Enable by ID:
            opsgeniecli alert-policies enable --id abc123 --team ops-team

        Enable all policies for a team (with confirmation):
            opsgeniecli alert-policies enable --all --team ops-team

        Enable filtered policies:
            opsgeniecli alert-policies enable --filters "name:.*prod.*" --team ops-team
    """
    if not any([id, all, filters]):
        raise typer.BadParameter("Must specify one of: --id, --all, or --filters")

    if id and (all or filters):
        raise typer.BadParameter("Cannot use --id with --all or --filters")

    if not team:
        raise typer.BadParameter("Must specify --team")

    # Get team ID for API calls
    team_obj = ctx.obj.opsgenie.get_team_by_name(team)
    team_id = team_obj.id

    # Handle single policy enable by ID
    if id:
        try:
            policy = _get_policy_by_id(ctx.obj.opsgenie, id, team)
            result = _update_policy_status(ctx.obj.opsgenie, id, team_id, enabled=True)
            _display_policy_update_result(policy["name"], "enabled", result)
        except ValueError as e:
            typer.echo(f"✗ - {e}")
            raise typer.Exit(code=1)
        return

    # Handle bulk enable (all or filtered)
    policies = _fetch_policies_by_team(ctx.obj.opsgenie, team)

    if filters:
        policies = _apply_filters_to_policies(policies, filters)

    if not policies:
        typer.echo("No policies found matching criteria")
        return

    # Show preview and confirm
    show_table_and_confirm(
        data=_get_alert_policies_table_data(policies),
        title="Alert Policies to be Enabled",
        prompt="\nAre you sure you want to enable these policies?",
    )

    # Enable each policy
    for policy in policies:
        result = _update_policy_status(
            ctx.obj.opsgenie, policy["id"], team_id, enabled=True
        )
        _display_policy_update_result(policy["name"], "enabled", result)


@app.command(name="get")
def get_policy(
    ctx: typer.Context,
    id: Annotated[str, typer.Option(help="Alert policy ID")],
    team: Annotated[str, typer.Option(help="Team name (required)")],
):
    """Get details of a specific alert policy by ID.

    Retrieves and displays detailed information about a single alert policy.

    Args:
        id: Alert policy ID (required)
        team: Team name (required)

    Examples:
        Get policy by ID:
            opsgeniecli alert-policies get --id abc123-def456 --team ops-team
    """
    try:
        policy = _get_policy_by_id(ctx.obj.opsgenie, id, team)
        data = _get_alert_policies_table_data([policy])
        console.print(get_table(data=data, title="Alert Policy"))
    except ValueError as e:
        typer.echo(f"✗ - {e}")
        raise typer.Exit(code=1)


@app.command(name="list")
def list_policies(
    ctx: typer.Context,
    team: Annotated[str, typer.Option(help="Team name (required)")],
    filters: Annotated[
        Optional[List[str]],
        typer.Option(help="Filter using 'attribute:pattern' (e.g., 'name:.*test.*')"),
    ] = None,
):
    """List alert policies for a team with optional filtering.

    Retrieves alert policies for a specified team, optionally filtered by regex patterns.

    Args:
        team: Team name to list policies for (required)
        filters: Regex filters in format "field:pattern" (can be specified multiple times)

    Examples:
        List all policies for a team:
            opsgeniecli alert-policies list --team ops-team

        List with regex filter:
            opsgeniecli alert-policies list --team ops-team --filters "name:.*production.*"

        List enabled policies only:
            opsgeniecli alert-policies list --team ops-team --filters "enabled:True"
    """
    # Fetch policies
    policies = _fetch_policies_by_team(ctx.obj.opsgenie, team)

    # Apply filters if provided
    if filters:
        policies = _apply_filters_to_policies(policies, filters)

    # Display results
    if not policies:
        typer.echo("No alert policies found")
        return

    data = _get_alert_policies_table_data(policies)
    console.print(get_table(data=data, title="Alert Policies"))


@app.command(name="set")
def set_policy(
    ctx: typer.Context,
    name: Annotated[str, typer.Option(help="Name for the alert policy")],
    filter: Annotated[str, typer.Option(help="Regex pattern to match alerts")],
    description: Annotated[str, typer.Option(help="Description for the alert policy")],
    team: Annotated[str, typer.Option(help="Team name (required)")],
    enabled: Annotated[
        bool, typer.Option(help="Enable the policy when created")
    ] = False,
    validation: Annotated[
        bool, typer.Option(help="Validate filter against recent alerts before creating")
    ] = False,
):
    """Create a new alert policy.

    Creates an alert policy with the specified name, filter regex pattern, and description.
    The filter is a regex pattern that matches against alert properties.
    The policy can be optionally enabled immediately upon creation.

    Args:
        name: Name for the alert policy (required)
        filter: Regex pattern to match alerts (required)
        description: Description for the alert policy (required)
        team: Team name (required)
        enabled: Enable the policy when created (default: False)
        validation: Validate filter against recent alerts before creating (default: False)

    Examples:
        Create a disabled policy with regex filter:
            opsgeniecli alert-policies set \\
                --name "Filter opensearch alerts" \\
                --filter "sbpp[13]osearch-apg" \\
                --description "Blocks opensearch APG alerts" \\
                --team ops-team

        Create an enabled policy with validation:
            opsgeniecli alert-policies set \\
                --name "Filter test alerts" \\
                --filter ".*test.*" \\
                --description "Filters all test-related alerts" \\
                --team ops-team \\
                --enabled \\
                --validation
    """
    # Get team ID
    team_obj = ctx.obj.opsgenie.get_team_by_name(team)
    team_id = team_obj.id

    # Validate filter against recent alerts if requested
    if validation:
        try:
            typer.echo(
                f"\nValidating filter pattern against recent alerts for team '{team}'..."
            )
            matching_alerts = _validate_policy_filter(
                ctx.obj.opsgenie, team, filter, limit=500
            )

            if not matching_alerts:
                typer.echo("No alerts matched the filter pattern in the last 7 days.")
                typer.echo("This policy would not have blocked any recent alerts.\n")
            else:
                typer.echo(
                    f"\nFound {len(matching_alerts)} alerts matching the filter pattern:\n"
                )
                validation_table_data = _get_validation_table_data(matching_alerts[:20])
                console.print(
                    get_table(
                        data=validation_table_data,
                        title="Matching Alerts (Last 7 Days)",
                    )
                )

                if len(matching_alerts) > 20:
                    typer.echo(
                        f"\n(Showing 20 of {len(matching_alerts)} matching alerts)"
                    )

            # Ask for confirmation
            if not typer.confirm("\nDo you want to create this policy?", default=True):
                typer.echo("Policy creation cancelled.")
                raise typer.Exit(code=0)

        except ValueError as e:
            typer.echo(f"✗ - Validation error: {e}")
            raise typer.Exit(code=1)

    # Create the policy
    try:
        result = ctx.obj.opsgenie.create_alert_policy(
            name=name,
            filter_condition=filter,
            policy_description=description,
            team_id=team_id,
            enabled=enabled,
        )

        # Display success message
        policy_data = result.get("data", {})
        typer.echo("✓ - Alert policy created:")
        typer.echo(f"    Name: {name}")
        typer.echo(f"    Filter: {filter}")
        typer.echo(f"    Description: {description}")
        typer.echo(f"    Team: {team}")
        typer.echo(f"    Enabled: {policy_data.get('enabled', enabled)}")
        if policy_data.get("id"):
            typer.echo(f"    ID: {policy_data.get('id')}")

    except Exception as e:
        typer.echo(f"✗ - Failed to create alert policy: {e}")
        raise typer.Exit(code=1)


def _extract_policy_filter(policy_obj) -> str:
    """Extract filter pattern from an AlertPolicy object.

    Args:
        policy_obj: AlertPolicy object from opsgenielib

    Returns:
        Filter pattern string, or empty string if no filter found
    """
    return policy_obj._data.get("filter", {}).get("conditions", [{}])[0].get("expectedValue", "")


def _create_policy_summary_dict(policy: dict[str, Any], filter_pattern: str, match_count: int) -> dict[str, Any]:
    """Create a summary dictionary for a validated policy.

    Args:
        policy: Policy dictionary with name and enabled status
        filter_pattern: The regex filter pattern
        match_count: Number of alerts matched

    Returns:
        Dictionary with policy summary for table display
    """
    return {
        "name": policy["name"],
        "enabled": "Yes" if policy["enabled"] else "No",
        "filter": filter_pattern[:50] + "..." if len(filter_pattern) > 50 else filter_pattern,
        "matches": match_count,
    }


def _display_single_policy_result(
    policy_name: str,
    enabled: bool,
    filter_pattern: str,
    matching_alerts: list,
    idx: int,
    total: int,
    days: int,
) -> None:
    """Display validation results for a single policy.

    Args:
        policy_name: Name of the policy
        enabled: Whether policy is enabled
        filter_pattern: The filter regex pattern
        matching_alerts: List of matching Alert objects
        idx: Current policy index (1-based)
        total: Total number of policies
        days: Number of days queried
    """
    enabled_status = "[ENABLED]" if enabled else "[DISABLED]"
    typer.echo("━" * 80)
    typer.echo(f"\n[{idx}/{total}] Policy: \"{policy_name}\" {enabled_status}")
    typer.echo(f"Filter: {filter_pattern}")

    if not matching_alerts:
        typer.echo("⚠️  No matching alerts found\n")
    else:
        typer.echo(f"✓ Matched {len(matching_alerts)} alerts\n")

        # Show sample matching alerts (up to 20)
        validation_table_data = _get_validation_table_data(matching_alerts[:20])
        console.print(
            get_table(
                data=validation_table_data,
                title=f"Sample Matching Alerts (Last {days} Days)",
            )
        )

        if len(matching_alerts) > 20:
            typer.echo(f"\n(Showing 20 of {len(matching_alerts)} matching alerts)")

        typer.echo()  # Empty line for spacing


def _display_validation_summary(
    effective_policies: list[dict[str, Any]],
    ineffective_policies: list[dict[str, Any]],
) -> None:
    """Display summary tables of effective and ineffective policies.

    Args:
        effective_policies: List of policy dicts that matched alerts
        ineffective_policies: List of policy dicts that matched no alerts
    """
    typer.echo("━" * 80)
    typer.echo(f"\n📊 Summary: {len(effective_policies) + len(ineffective_policies)} policies validated\n")

    # Show table of effective policies
    if effective_policies:
        typer.echo(f"✓ Effective Policies ({len(effective_policies)} policies matched alerts):\n")
        console.print(
            get_table(
                data=effective_policies,
                title="Effective Policies (With Matches)",
            )
        )
        typer.echo()

    # Show table of ineffective policies
    if ineffective_policies:
        typer.echo(f"⚠️  Ineffective Policies ({len(ineffective_policies)} policies had no matches):\n")
        console.print(
            get_table(
                data=ineffective_policies,
                title="Ineffective Policies (No Matches)",
            )
        )
        typer.echo()

    # Show message if all policies were effective or ineffective
    if effective_policies and not ineffective_policies:
        typer.echo("🎉 All policies matched recent alerts!\n")
    elif ineffective_policies and not effective_policies:
        typer.echo("⚠️  No policies matched any recent alerts. Consider reviewing your filters.\n")


@app.command(name="validate")
def validate_policies(
    ctx: typer.Context,
    team: Annotated[str, typer.Option(help="Team name to validate policies for")],
    enabled_only: Annotated[
        bool, typer.Option(help="Only validate enabled policies")
    ] = False,
    days: Annotated[
        int, typer.Option(help="Number of days to look back for alerts")
    ] = 30,
    limit: Annotated[
        int, typer.Option(help="Maximum number of alerts to query")
    ] = 500,
):
    """Validate all alert policies against recent alerts.

    Checks each alert policy's filter pattern against recent alerts to see if they would
    have matched. This helps identify effective vs ineffective policies.

    Args:
        team: Team name to validate policies for (required)
        enabled_only: Only validate enabled policies (default: False, validates all)
        days: Number of days to look back for alerts (default: 30)
        limit: Maximum number of alerts to query (default: 500)

    Examples:
        Validate all policies for a team:
            opsgeniecli alert-policies validate --team ops-team

        Validate only enabled policies:
            opsgeniecli alert-policies validate --team ops-team --enabled-only

        Custom time window and alert limit:
            opsgeniecli alert-policies validate --team ops-team --days 14 --limit 1000
    """
    # Get team ID and fetch policies
    team_obj = ctx.obj.opsgenie.get_team_by_name(team)
    team_id = team_obj.id

    typer.echo(f"\nValidating alert policies for team '{team}'...")
    typer.echo(f"Querying up to {limit} alerts from the last {days} days...\n")

    policies = _fetch_policies_by_team(ctx.obj.opsgenie, team)
    if not policies:
        typer.echo("No alert policies found for this team.")
        return

    # Filter to enabled only if requested
    if enabled_only:
        policies = [p for p in policies if p["enabled"]]
        if not policies:
            typer.echo("No enabled alert policies found for this team.")
            return

    # Fetch alerts once and cache for all policy validations (performance optimization)
    try:
        cached_alerts = _fetch_recent_alerts(ctx.obj.opsgenie, team, limit=limit, days=days)
        typer.echo(f"Fetched {len(cached_alerts)} alerts from the last {days} days\n")
    except Exception as e:
        typer.echo(f"✗ - Failed to fetch alerts: {e}")
        raise typer.Exit(code=1)

    # Validate each policy
    effective_policies = []
    ineffective_policies = []

    for idx, policy in enumerate(policies, 1):
        # Fetch full policy details
        try:
            policy_obj = ctx.obj.opsgenie.get_alert_policy(id_=policy["id"], team_id=team_id)
        except Exception as e:
            typer.echo(f"✗ - [{idx}/{len(policies)}] Failed to fetch policy '{policy['name']}': {e}")
            continue

        # Extract and validate filter pattern
        filter_pattern = _extract_policy_filter(policy_obj)
        if not filter_pattern:
            typer.echo(f"⚠️  - [{idx}/{len(policies)}] Policy '{policy['name']}' has no filter pattern, skipping")
            continue

        # Validate filter against cached alerts
        try:
            matching_alerts = _validate_policy_filter(
                ctx.obj.opsgenie, team, filter_pattern,
                limit=limit, days=days, cached_alerts=cached_alerts
            )

            # Display results for this policy
            _display_single_policy_result(
                policy["name"], policy["enabled"], filter_pattern,
                matching_alerts, idx, len(policies), days
            )

            # Collect summary data
            policy_summary = _create_policy_summary_dict(policy, filter_pattern, len(matching_alerts))
            if matching_alerts:
                effective_policies.append(policy_summary)
            else:
                ineffective_policies.append(policy_summary)

        except (ValueError, Exception) as e:
            typer.echo(f"✗ - Validation error: {e}\n")
            continue

    # Display summary
    _display_validation_summary(effective_policies, ineffective_policies)



if __name__ == "__main__":
    app()
