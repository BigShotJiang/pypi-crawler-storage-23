"""Discord bot integration."""

from cmdop_bot.channels.discord.bot import DiscordBot

__all__ = ["DiscordBot"]
