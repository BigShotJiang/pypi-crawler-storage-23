#!/usr/bin/env python3
"""
Create a HecVec object and test the method that does everything by passing your path.

  listdir → filter .txt/.md → token-chunk → embed → Chroma

Requirements:
  - pip install hecvec[chroma]
  - Chroma running: docker run -p 8000:8000 chromadb/chroma
  - OPENAI_API_KEY set (env or .env in project root)

Usage (from project root):
  uv run python scripts/test_slice.py /path/to/folder
  uv run python scripts/test_slice.py .
  python scripts/test_slice.py /path/to/folder
"""
import logging
import sys
from pathlib import Path

# Project root and src
ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

# Default path to slice: project root (works in devcontainer; use first arg to override)
DEFAULT_PATH = ROOT


def main() -> int:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )
    logger = logging.getLogger(__name__)

    from hecvec import HecVec

    if len(sys.argv) < 2:
        path = DEFAULT_PATH
        logger.info("No path given, using default: %s", path)
    else:
        path = Path(sys.argv[1]).expanduser().resolve()
        logger.info("Path given: %s", path)

    if not path.exists():
        logger.error("Path does not exist: %s", path)
        print(f"Error: path does not exist: {path}")
        return 1
    if not path.is_dir() and not path.is_file():
        logger.error("Not a file or directory: %s", path)
        print(f"Error: not a file or directory: {path}")
        return 1
    if path.is_file() and path.suffix.lower() not in (".txt", ".md"):
        logger.error("File must be .txt or .md: %s", path)
        print(f"Error: file must be .txt or .md: {path}")
        return 1

    test = HecVec()
    result = test.slice(path=path)

    logger.info("Result: %s", result)
    print("Result:", result)
    return 0


if __name__ == "__main__":
    sys.exit(main())
