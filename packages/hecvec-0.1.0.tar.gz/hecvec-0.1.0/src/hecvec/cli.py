"""CLI for listing directory contents under a root."""
import sys
from pathlib import Path

from hecvec import ListDir


def main() -> None:
    root = Path.cwd()
    path = "."
    if len(sys.argv) >= 2:
        path = sys.argv[1]
    if len(sys.argv) >= 3:
        root = Path(sys.argv[2]).resolve()

    lister = ListDir(root=root)
    entries = lister.listdir(path)
    print(f"Contenido de: {path}\n")
    for rel in entries:
        full = lister.root / rel
        prefix = "[DIR] " if full.is_dir() else "      "
        print(f"  {prefix}{rel}")
    print(f"\nTotal: {len(entries)} entradas")


if __name__ == "__main__":
    main()
