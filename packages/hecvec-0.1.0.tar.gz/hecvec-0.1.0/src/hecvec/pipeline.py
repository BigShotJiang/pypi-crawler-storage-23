"""
Pipeline: composes listdir → read → token-chunk → embed → Chroma.
One module = one responsibility: orchestrate the full slice() flow.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from hecvec.chroma_client import add_documents, get_client
from hecvec.embeddings import embed_texts
from hecvec.env import load_openai_key
from hecvec.listdir import ListDirTextFiles
from hecvec.reading import ReadText
from hecvec.token_splitter import token_chunk_documents

logger = logging.getLogger(__name__)


def _check_chroma_deps() -> None:
    try:
        import chromadb  # noqa: F401
        from langchain_text_splitters import TokenTextSplitter  # noqa: F401
        from openai import OpenAI  # noqa: F401
    except ImportError as e:
        raise ImportError(
            "Chroma pipeline requires: pip install hecvec[chroma]"
        ) from e


class HecVec:
    """
    Library-only pipeline. No API.
    Call slice(path=...) to: list path → filter .txt/.md → token-chunk → push to Chroma.
    """

    def __init__(
        self,
        *,
        root: str | Path | None = None,
        collection_name: str = "hecvec",
        chroma_host: str = "localhost",
        chroma_port: int = 8000,
        embedding_model: str = "text-embedding-3-small",
        chunk_size: int = 200,
        chunk_overlap: int = 0,
        encoding_name: str = "cl100k_base",
        batch_size: int = 100,
        openai_api_key: str | None = None,
        dotenv_path: str | Path | None = None,
    ):
        self.root = Path(root).resolve() if root else Path.cwd()
        self.collection_name = collection_name
        self.chroma_host = chroma_host
        self.chroma_port = chroma_port
        self.embedding_model = embedding_model
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.encoding_name = encoding_name
        self.batch_size = batch_size
        self._dotenv_path = dotenv_path
        self._openai_api_key = openai_api_key or load_openai_key(dotenv_path)

    def slice(
        self,
        path: str | Path,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Run the pipeline for this instance (uses instance config)."""
        return HecVec.slice(
            path,
            root=kwargs.pop("root", self.root),
            collection_name=kwargs.pop("collection_name", self.collection_name),
            chroma_host=kwargs.pop("chroma_host", self.chroma_host),
            chroma_port=kwargs.pop("chroma_port", self.chroma_port),
            embedding_model=kwargs.pop("embedding_model", self.embedding_model),
            chunk_size=kwargs.pop("chunk_size", self.chunk_size),
            chunk_overlap=kwargs.pop("chunk_overlap", self.chunk_overlap),
            encoding_name=kwargs.pop("encoding_name", self.encoding_name),
            batch_size=kwargs.pop("batch_size", self.batch_size),
            openai_api_key=kwargs.pop("openai_api_key", self._openai_api_key),
            dotenv_path=kwargs.pop("dotenv_path", self._dotenv_path),
            **kwargs,
        )

    @classmethod
    def slice(
        cls,
        path: str | Path,
        *,
        root: str | Path | None = None,
        collection_name: str = "hecvec",
        chroma_host: str = "localhost",
        chroma_port: int = 8000,
        embedding_model: str = "text-embedding-3-small",
        chunk_size: int = 200,
        chunk_overlap: int = 0,
        encoding_name: str = "cl100k_base",
        batch_size: int = 100,
        openai_api_key: str | None = None,
        dotenv_path: str | Path | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Run the full pipeline: find path → listdir → filter .txt/.md → token-chunk → push to Chroma.
        No API; everything runs in the library.
        """
        _check_chroma_deps()

        path = Path(path).resolve()
        if not path.exists():
            raise ValueError(f"path does not exist: {path}")

        if collection_name == "hecvec":
            collection_name = path.stem if path.is_file() else path.name

        if path.is_file():
            if path.suffix.lower() not in (".txt", ".md"):
                raise ValueError(f"File must be .txt or .md: {path}")
            root = path.parent
            paths = [path]
            logger.info("Archivo a procesar: %s", path)
        else:
            root = Path(root).resolve() if root else path
            if not root.is_dir():
                raise ValueError(f"path must be an existing directory: {root}")
            logger.info("Ruta a procesar: %s", root)
            lister = ListDirTextFiles(root=root)
            paths = lister.listdir_recursive_txt_md(path)
            if not paths:
                logger.warning("No se encontraron archivos .txt/.md en %s", path)
                return {"files": 0, "chunks": 0, "collection": collection_name, "message": "No .txt/.md files found"}
            logger.info("Archivos .txt/.md encontrados: %d", len(paths))
            for i, p in enumerate(paths[:10]):
                logger.info("  %s", p)
            if len(paths) > 10:
                logger.info("  ... y %d más", len(paths) - 10)

        # 1. (paths already set above) — 2. Read as text
        logger.info("Leyendo contenido de %d archivos...", len(paths))
        reader = ReadText(paths)
        path_and_text = reader.read_all()
        logger.info("Leídos %d archivos correctamente", len(path_and_text))

        # 3. Token chunk
        logger.info("Fragmentando con chunk_size=%d, chunk_overlap=%d...", chunk_size, chunk_overlap)
        ids, documents = token_chunk_documents(
            path_and_text,
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            encoding_name=encoding_name,
        )
        if not documents:
            logger.warning("No se generaron chunks (archivos vacíos o sin texto)")
            return {"files": len(path_and_text), "chunks": 0, "collection": collection_name}

        logger.info("Chunks generados: %d", len(documents))

        # 4. Embed
        api_key = openai_api_key or load_openai_key(dotenv_path)
        if not api_key:
            raise ValueError(
                "OPENAI_API_KEY required for embeddings. "
                "Set it in .env, pass openai_api_key=, or set the OPENAI_API_KEY env var."
            )
        logger.info("Generando embeddings (modelo=%s, batch_size=%d)...", embedding_model, batch_size)
        embeddings = embed_texts(
            documents,
            api_key=api_key,
            model=embedding_model,
            batch_size=batch_size,
        )
        logger.info("Embeddings generados: %d vectores", len(embeddings))

        # 5. Push to Chroma
        logger.info("Conectando a Chroma (host=%s, port=%s)...", chroma_host, chroma_port)
        client = get_client(host=chroma_host, port=chroma_port)
        logger.info("Añadiendo %d documentos a la colección '%s'...", len(documents), collection_name)
        add_documents(client, collection_name, ids, embeddings, documents)
        logger.info("Pipeline completado: %d archivos → %d chunks → Chroma", len(path_and_text), len(documents))

        return {
            "files": len(path_and_text),
            "chunks": len(documents),
            "collection": collection_name,
        }
