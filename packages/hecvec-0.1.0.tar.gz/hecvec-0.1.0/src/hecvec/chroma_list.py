"""
List Chroma collections. One module = one responsibility: inspect collections on a Chroma server.
Requires: pip install hecvec[chroma] (chromadb).
"""
from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import chromadb

DEFAULT_HOST = "localhost"
DEFAULT_PORT = 8000


def list_collections(
    host: str = DEFAULT_HOST,
    port: int = DEFAULT_PORT,
) -> list[tuple[str, int]]:
    """
    List all collection names and their document counts on a Chroma server.
    Returns [(name, count), ...].
    """
    import chromadb
    client = chromadb.HttpClient(host=host, port=port)
    collections = client.list_collections()
    return [(c.name, c.count()) for c in collections]
