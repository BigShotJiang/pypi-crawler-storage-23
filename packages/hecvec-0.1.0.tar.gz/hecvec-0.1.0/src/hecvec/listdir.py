"""Directory listing with safe path resolution under a root."""
from __future__ import annotations

import os
from pathlib import Path


ALLOWED_EXTENSIONS = (".txt", ".md")


class ListDir:
    """
    Lists directory contents with safe path resolution. All paths are
    restricted under `root`. Returns a single list of relative path strings.
    """

    def __init__(self, root: str | Path):
        self.root = Path(root).resolve()
        if not self.root.is_dir():
            raise ValueError(f"root must be an existing directory: {self.root}")

    def _resolve(self, path: str | Path) -> Path:
        """Resolve path under root; raise ValueError if it escapes root."""
        p = Path(path)
        if not p.is_absolute():
            p = self.root / p
        resolved = p.resolve()
        try:
            resolved.relative_to(self.root)
        except ValueError:
            raise ValueError(f"Path escapes allowed root: {path!r} -> {resolved}")
        return resolved

    def listdir(self, path: str | Path = ".") -> list[str]:
        """
        List entries in the given path (under root). Returns a sorted list
        of relative path strings (dirs first, then files, by name).
        """
        target = self._resolve(path)
        if not target.is_dir():
            raise ValueError(f"Not a directory: {target}")
        out = []
        for entry in target.iterdir():
            try:
                rel = entry.relative_to(self.root)
            except ValueError:
                continue
            out.append(str(rel))
        return sorted(out, key=lambda x: (not (self.root / x).is_dir(), x.lower()))

    def listdir_recursive(
        self,
        path: str | Path = ".",
        max_depth: int | None = None,
    ) -> list[str]:
        """
        List all entries under path recursively. Returns a flat sorted list
        of relative path strings.
        """
        target = self._resolve(path)
        if not target.is_dir():
            raise ValueError(f"Not a directory: {target}")
        out = []
        for root_dir, dirs, files in os.walk(target, topdown=True):
            root_path = Path(root_dir)
            try:
                rel_root = root_path.relative_to(self.root)
            except ValueError:
                continue
            depth = len(rel_root.parts) if rel_root != Path(".") else 0
            if max_depth is not None and depth > max_depth:
                dirs.clear()
                continue
            for d in sorted(dirs):
                p = root_path / d
                try:
                    rel = p.relative_to(self.root)
                except ValueError:
                    continue
                out.append(str(rel))
            for f in sorted(files):
                p = root_path / f
                try:
                    rel = p.relative_to(self.root)
                except ValueError:
                    continue
                out.append(str(rel))
        return sorted(out)


class ListDirTextFiles(ListDir):
    """
    Child of ListDir. Takes the list of relative paths from the parent and
    returns only .txt and .md files as full paths; filters out all other
    extensions.
    """

    def __init__(self, root: str | Path, allowed_extensions: tuple[str, ...] = ALLOWED_EXTENSIONS):
        super().__init__(root)
        self.allowed_extensions = allowed_extensions

    def filter_txt_md(self, relative_paths: list[str]) -> list[Path]:
        """
        From a list of relative path strings (e.g. from listdir/listdir_recursive),
        build full paths and return only those that are files with .txt or .md.
        """
        result = []
        for rel in relative_paths:
            full = self.root / rel
            if full.is_file() and full.suffix.lower() in self.allowed_extensions:
                result.append(full.resolve())
        return sorted(result)

    def listdir_txt_md(self, path: str | Path = ".") -> list[Path]:
        """List only .txt and .md files under path (one level)."""
        paths = self.listdir(path)
        return self.filter_txt_md(paths)

    def listdir_recursive_txt_md(
        self,
        path: str | Path = ".",
        max_depth: int | None = None,
    ) -> list[Path]:
        """List only .txt and .md files under path recursively."""
        paths = self.listdir_recursive(path=path, max_depth=max_depth)
        return self.filter_txt_md(paths)
