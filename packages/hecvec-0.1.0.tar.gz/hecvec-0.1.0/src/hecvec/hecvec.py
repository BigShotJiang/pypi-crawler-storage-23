"""
HecVec pipeline entrypoint. Re-exports HecVec from pipeline for backward compatibility.
"""
from hecvec.pipeline import HecVec

__all__ = ["HecVec"]
