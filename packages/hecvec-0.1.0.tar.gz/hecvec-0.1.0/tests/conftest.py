"""Pytest configuration. Adds src to path so 'hecvec' is importable."""
import sys
from pathlib import Path

root = Path(__file__).resolve().parent.parent
src = root / "src"
if str(src) not in sys.path:
    sys.path.insert(0, str(src))
