[![PyPI version](https://img.shields.io/pypi/v/pubmlp)](https://pypi.org/project/pubmlp/)
[![Python versions](https://img.shields.io/pypi/pyversions/pubmlp)](https://pypi.org/project/pubmlp/)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](https://opensource.org/licenses/MIT)

Multimodal publication classifier with LLM and deep learning. Fuses transformer embeddings with tabular features through a multilayer perceptron (MLP) for human-in-the-loop screening workflows.

## Installation

```bash
pip install pubmlp
```

With optional dependencies:

```bash
pip install pubmlp[screening]  # screening tools (openpyxl, nltk)
pip install pubmlp[dev]        # development (pytest, ruff)
pip install pubmlp[docs]       # documentation (sphinx)
```

From GitHub:

```bash
pip install git+https://github.com/mshin77/pubmlp.git
```

## Getting Started

See [Quick Start](https://mshin77.github.io/pubmlp/getting-started.html) and [Screening Workflow](https://mshin77.github.io/pubmlp/vignettes/screening-workflow.html) for tutorials.

## Citation

- Shin, M. (2026). *pubmlp: Multimodal publication classifier with LLM and deep learning* (Python package version 0.1.0) [Computer software]. <https://github.com/mshin77/pubmlp>
