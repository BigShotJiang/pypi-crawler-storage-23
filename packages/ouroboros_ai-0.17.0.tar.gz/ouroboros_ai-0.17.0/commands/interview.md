---
description: "Socratic interview to crystallize vague requirements"
aliases: [socratic]
---

Read the file at `${CLAUDE_PLUGIN_ROOT}/skills/interview/SKILL.md` using the Read tool and follow its instructions exactly.

## User Input

{{ARGUMENTS}}
