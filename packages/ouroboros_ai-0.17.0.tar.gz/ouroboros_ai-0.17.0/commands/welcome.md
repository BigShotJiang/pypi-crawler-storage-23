---
description: "First-touch experience for new Ouroboros users"
---

Read the file at `${CLAUDE_PLUGIN_ROOT}/skills/welcome/SKILL.md` using the Read tool and follow its instructions exactly.

## User Arguments

Flags: {{ARGUMENTS}}

Pass any provided arguments (e.g., `--skip`, `--force`) to the welcome skill as context.
