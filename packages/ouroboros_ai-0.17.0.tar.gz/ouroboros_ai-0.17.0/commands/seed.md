---
description: "Generate validated Seed specifications from interview results"
aliases: [crystallize]
---

Read the file at `${CLAUDE_PLUGIN_ROOT}/skills/seed/SKILL.md` using the Read tool and follow its instructions exactly.
