"""High-level channel manager for AI agent frameworks.

Wraps ``SkytaleClient`` with background message buffering so that LLM tool
calls (which need synchronous request-response semantics) can read messages
without blocking on the ``messages()`` iterator.

Usage::

    from skytale_sdk.channels import SkytaleChannelManager

    mgr = SkytaleChannelManager(identity=b"my-agent")
    mgr.create("acme/research/results")
    mgr.send("acme/research/results", "hello")
    msgs = mgr.receive("acme/research/results")
"""

from __future__ import annotations

import logging
import os
import threading
import time
from typing import Dict, List, Optional, Union

logger = logging.getLogger(__name__)

from skytale_sdk._native import PySkytaleClient as SkytaleClient


class ChannelHandle:
    """Holds a ``Channel`` and a daemon thread that buffers incoming messages."""

    def __init__(self, channel):
        self.channel = channel
        self._buffer: List[str] = []
        self._lock = threading.Lock()
        self._running = True
        self._error: Optional[str] = None
        self._thread = threading.Thread(target=self._listen, daemon=True)
        self._thread.start()

    def _listen(self):
        try:
            for msg in self.channel.messages():
                if not self._running:
                    break
                text = bytes(msg).decode("utf-8", errors="replace")
                with self._lock:
                    self._buffer.append(text)
        except Exception as exc:
            self._error = str(exc)
            logger.error("channel listener died: %s", exc)

    def drain(self) -> List[str]:
        """Return all buffered messages and clear the buffer."""
        with self._lock:
            msgs = list(self._buffer)
            self._buffer.clear()
        return msgs

    def stop(self):
        self._running = False


class SkytaleChannelManager:
    """Manage encrypted channels with background message buffering.

    Designed for AI agent frameworks (LangGraph, CrewAI, MCP) where tool
    calls need non-blocking access to incoming messages.

    Args:
        identity: Agent identity bytes (or str, will be encoded).
        endpoint: Relay server URL. Defaults to ``SKYTALE_RELAY`` env var
            or ``https://relay.skytale.sh:5000``.
        data_dir: Local directory for MLS state. Defaults to
            ``SKYTALE_DATA_DIR`` env var or ``/tmp/skytale-<identity_hex>``.
        api_key: API key. Defaults to ``SKYTALE_API_KEY`` env var.
        api_url: API server URL. Defaults to ``SKYTALE_API_URL`` env var
            or ``https://api.skytale.sh``.

    Example::

        mgr = SkytaleChannelManager(identity=b"agent-1")
        mgr.create("org/ns/chan")
        mgr.send("org/ns/chan", "hello")
    """

    def __init__(
        self,
        identity: Union[bytes, str],
        endpoint: Optional[str] = None,
        data_dir: Optional[str] = None,
        api_key: Optional[str] = None,
        api_url: Optional[str] = None,
    ):
        if isinstance(identity, str):
            identity = identity.encode()

        self._identity = identity
        self._endpoint = endpoint or os.environ.get(
            "SKYTALE_RELAY", "https://relay.skytale.sh:5000"
        )
        id_hex = identity.hex()
        self._data_dir = data_dir or os.environ.get(
            "SKYTALE_DATA_DIR", f"/tmp/skytale-{id_hex}"
        )
        self._api_key = api_key or os.environ.get("SKYTALE_API_KEY")
        self._api_url = api_url or os.environ.get(
            "SKYTALE_API_URL", "https://api.skytale.sh"
        )

        kwargs = {}
        if self._api_key:
            kwargs["api_key"] = self._api_key
            kwargs["api_url"] = self._api_url

        self._client = SkytaleClient(
            self._endpoint, self._data_dir, self._identity, **kwargs
        )
        self._handles: Dict[str, ChannelHandle] = {}

    def create(self, channel_name: str) -> None:
        """Create a new encrypted channel and start listening for messages.

        Args:
            channel_name: Channel name in ``org/namespace/service`` format.

        Raises:
            RuntimeError: If the channel name is invalid or creation fails.
        """
        channel = self._client.create_channel(channel_name)
        self._handles[channel_name] = ChannelHandle(channel)

    def join(self, channel_name: str, welcome: bytes) -> None:
        """Join an existing channel using an MLS Welcome message.

        Args:
            channel_name: Channel name to join.
            welcome: MLS Welcome message bytes from ``add_member()``.

        Raises:
            RuntimeError: If the Welcome is invalid or joining fails.
        """
        channel = self._client.join_channel(channel_name, welcome)
        self._handles[channel_name] = ChannelHandle(channel)

    def key_package(self) -> bytes:
        """Generate an MLS key package for joining a channel.

        Returns:
            Key package bytes to send to the channel creator.
        """
        return self._client.generate_key_package()

    def add_member(self, channel_name: str, key_package: bytes) -> bytes:
        """Add a member to a channel and return the MLS Welcome message.

        Args:
            channel_name: Channel to add the member to.
            key_package: MLS key package from the joining agent.

        Returns:
            MLS Welcome message bytes. Send these to the joining agent.

        Raises:
            KeyError: If the channel does not exist.
        """
        handle = self._handles[channel_name]
        return handle.channel.add_member(key_package)

    def send(self, channel_name: str, message: Union[str, bytes]) -> None:
        """Send a message on an encrypted channel.

        Args:
            channel_name: Target channel.
            message: Message content. Strings are UTF-8 encoded automatically.

        Raises:
            KeyError: If the channel does not exist.
        """
        if isinstance(message, str):
            message = message.encode("utf-8")
        handle = self._handles[channel_name]
        handle.channel.send(message)

    def receive(self, channel_name: str, timeout: float = 5.0) -> List[str]:
        """Drain all buffered messages from a channel.

        Waits up to *timeout* seconds for at least one message if the buffer
        is currently empty.

        Args:
            channel_name: Channel to read from.
            timeout: Max seconds to wait for messages. ``0`` returns
                immediately.

        Returns:
            List of message strings (may be empty if timeout expires).

        Raises:
            KeyError: If the channel does not exist.
            RuntimeError: If the background listener thread has died.
        """
        handle = self._handles[channel_name]
        if handle._error is not None:
            raise RuntimeError(
                f"channel listener for '{channel_name}' died: {handle._error}"
            )
        deadline = time.monotonic() + timeout
        while True:
            msgs = handle.drain()
            if msgs:
                return msgs
            if handle._error is not None:
                raise RuntimeError(
                    f"channel listener for '{channel_name}' died: {handle._error}"
                )
            if time.monotonic() >= deadline:
                return []
            time.sleep(min(0.1, max(0, deadline - time.monotonic())))

    def receive_latest(
        self, channel_name: str, timeout: float = 5.0
    ) -> Optional[str]:
        """Return only the most recent buffered message, discarding older ones.

        Args:
            channel_name: Channel to read from.
            timeout: Max seconds to wait.

        Returns:
            The latest message string, or ``None`` if no messages arrive
            before timeout.

        Raises:
            RuntimeError: If the background listener thread has died.
        """
        handle = self._handles[channel_name]
        if handle._error is not None:
            raise RuntimeError(
                f"channel listener for '{channel_name}' died: {handle._error}"
            )
        msgs = self.receive(channel_name, timeout=timeout)
        return msgs[-1] if msgs else None

    def list_channels(self) -> List[str]:
        """Return the names of all active channels.

        Returns:
            Sorted list of channel name strings.
        """
        return sorted(self._handles.keys())

    def close(self) -> None:
        """Stop all background listener threads."""
        for handle in self._handles.values():
            handle.stop()
        self._handles.clear()

    def __del__(self):
        self.close()
