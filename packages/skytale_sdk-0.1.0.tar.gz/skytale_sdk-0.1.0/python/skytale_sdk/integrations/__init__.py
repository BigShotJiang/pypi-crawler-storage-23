"""Skytale integrations for AI agent frameworks.

Submodules:
    _langgraph: LangGraph / LangChain tool bindings
    _crewai: CrewAI tool bindings
    _mcp: MCP (Model Context Protocol) server
"""
