#![allow(clippy::result_large_err)]

pub mod channel;
pub mod client;
pub mod mls_engine;
pub mod transport;

/// Top-level error type for the SDK, wrapping sub-system errors.
#[derive(Debug, thiserror::Error)]
pub enum SdkError {
    #[error("MLS engine error: {0}")]
    MlsEngine(#[from] mls_engine::MlsEngineError),

    #[error("transport error: {0}")]
    Transport(#[from] transport::TransportError),

    #[error("invalid channel name: {0} (expected org/namespace/service)")]
    InvalidChannelName(String),

    #[error("message too large: {0} bytes exceeds {1} byte limit")]
    MessageTooLarge(usize, usize),

    #[error("key package too large: {0} bytes exceeds {1} byte limit")]
    KeyPackageTooLarge(usize, usize),

    #[error("runtime error: {0}")]
    Runtime(String),

    #[error("auth error: {0}")]
    Auth(String),

    #[error("internal lock poisoned")]
    LockPoisoned,
}

// ---------------------------------------------------------------------------
// PyO3 bindings (behind the "python" feature flag)
// ---------------------------------------------------------------------------

#[cfg(feature = "python")]
use pyo3::prelude::*;

#[cfg(feature = "python")]
#[pyclass]
pub struct PySkytaleClient {
    inner: client::SkytaleClient,
}

#[cfg(feature = "python")]
#[pymethods]
impl PySkytaleClient {
    #[new]
    #[pyo3(signature = (endpoint, data_dir, identity, api_key=None, api_url=None))]
    fn new(
        endpoint: &str,
        data_dir: &str,
        identity: Vec<u8>,
        api_key: Option<&str>,
        api_url: Option<&str>,
    ) -> PyResult<Self> {
        let client = match (api_key, api_url) {
            (Some(key), Some(url)) => {
                client::SkytaleClient::new_with_api_key(key, url, endpoint, data_dir, &identity)
            }
            _ => client::SkytaleClient::new(endpoint, data_dir, &identity),
        }
        .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;
        Ok(Self { inner: client })
    }

    fn create_channel(&mut self, name: &str) -> PyResult<PyChannel> {
        let ch = self
            .inner
            .create_channel(name)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;
        Ok(PyChannel { inner: ch })
    }

    fn generate_key_package(&mut self) -> PyResult<Vec<u8>> {
        self.inner
            .generate_key_package()
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))
    }

    fn join_channel(&mut self, name: &str, welcome_bytes: Vec<u8>) -> PyResult<PyChannel> {
        let ch = self
            .inner
            .join_channel(name, &welcome_bytes)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;
        Ok(PyChannel { inner: ch })
    }
}

#[cfg(feature = "python")]
#[pyclass]
pub struct PyChannel {
    inner: channel::Channel,
}

#[cfg(feature = "python")]
#[pymethods]
impl PyChannel {
    fn add_member(&mut self, key_package: Vec<u8>) -> PyResult<Vec<u8>> {
        self.inner
            .add_member(&key_package)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))
    }

    fn send(&mut self, payload: Vec<u8>) -> PyResult<()> {
        self.inner
            .send(&payload)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))
    }

    fn messages(&self) -> PyResult<PyMessageIterator> {
        let iter = self.inner.messages();
        Ok(PyMessageIterator { inner: iter })
    }
}

#[cfg(feature = "python")]
#[pyclass]
pub struct PyMessageIterator {
    inner: channel::MessageIterator,
}

#[cfg(feature = "python")]
#[pymethods]
impl PyMessageIterator {
    fn __iter__(slf: PyRef<'_, Self>) -> PyRef<'_, Self> {
        slf
    }

    fn __next__(&mut self, py: Python<'_>) -> PyResult<Option<Vec<u8>>> {
        let poll_duration = std::time::Duration::from_millis(50);
        loop {
            // Poll with a short timeout so we don't hold the GIL forever.
            match self.inner.next_timeout(poll_duration) {
                Some(msg) => return Ok(Some(msg.payload)),
                None => {
                    // Release the GIL briefly so other Python threads can run
                    // (e.g., the main thread calling send()).
                    py.detach(|| std::thread::sleep(std::time::Duration::from_millis(1)));
                    // Check for KeyboardInterrupt / signals.
                    py.check_signals()?;
                }
            }
        }
    }
}

#[cfg(feature = "python")]
#[pymodule]
fn _native(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<PySkytaleClient>()?;
    m.add_class::<PyChannel>()?;
    m.add_class::<PyMessageIterator>()?;
    Ok(())
}
