"""MCP server: expose Skytale channels to any MCP client.

This starts a Skytale MCP server that Claude Desktop, LangGraph, CrewAI,
or any other MCP-compatible client can connect to.

Prerequisites:
    pip install skytale-sdk[mcp]
    export SKYTALE_API_KEY="sk_live_..."

Usage (stdio transport):
    SKYTALE_IDENTITY=my-agent python -m skytale_sdk.integrations._mcp

Claude Desktop config (~/.config/claude/claude_desktop_config.json):

    {
      "mcpServers": {
        "skytale": {
          "command": "python",
          "args": ["-m", "skytale_sdk.integrations._mcp"],
          "env": {
            "SKYTALE_IDENTITY": "claude-agent",
            "SKYTALE_API_KEY": "sk_live_..."
          }
        }
      }
    }

Available tools:
    skytale_create_channel  - Create a new encrypted channel
    skytale_key_package     - Generate MLS key package for joining
    skytale_add_member      - Add a member to a channel
    skytale_join_channel    - Join a channel with a Welcome message
    skytale_send            - Send an encrypted message
    skytale_receive         - Receive messages from a channel
    skytale_channels        - List active channels
"""

if __name__ == "__main__":
    # This script is a reference for how to run the MCP server.
    # The actual server lives in skytale_sdk.integrations._mcp.
    from skytale_sdk.integrations._mcp import mcp

    mcp.run(transport="stdio")
