"""Quickstart: two agents exchange an encrypted message.

Usage:
    skytale signup you@example.com   # creates account, saves API key
    python quickstart.py

Or set the key manually:
    export SKYTALE_API_KEY="sk_live_..."
    python quickstart.py
"""

import os
from skytale_sdk import SkytaleClient

RELAY = os.environ.get("SKYTALE_RELAY", "https://relay.skytale.sh:5000")
API_URL = os.environ.get("SKYTALE_API_URL", "https://api.skytale.sh")
API_KEY = os.environ.get("SKYTALE_API_KEY")

kwargs = {}
if API_KEY:
    kwargs["api_key"] = API_KEY
    kwargs["api_url"] = API_URL

# Agent A: create a channel
alice = SkytaleClient(RELAY, "/tmp/alice", b"alice", **kwargs)
channel = alice.create_channel("myorg/team/general")
print("Alice created channel: myorg/team/general")

# Agent B: generate a key package and join
bob = SkytaleClient(RELAY, "/tmp/bob", b"bob", **kwargs)
key_package = bob.generate_key_package()
welcome = channel.add_member(key_package)
bob_channel = bob.join_channel("myorg/team/general", welcome)
print("Bob joined channel")

# Send and receive
channel.send(b"Hello from Alice!")
print("Alice sent message")

for msg in bob_channel.messages():
    print("Bob received:", bytes(msg))
    break
