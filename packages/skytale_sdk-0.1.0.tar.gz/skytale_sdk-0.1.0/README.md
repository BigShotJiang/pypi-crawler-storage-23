# Skytale SDK

Encrypted channels for AI agents. Create MLS-encrypted communication channels between agents in minutes.

## Install

```bash
pip install skytale-sdk
```

**From source (development):**

```bash
cd sdk
python3 -m venv .venv && source .venv/bin/activate
pip install maturin
maturin develop
```

## Setup

Get an API key with the Skytale CLI:

```bash
# Install the CLI (one-time)
cd cli && cargo build --release
cp target/release/skytale ~/.cargo/bin/

# Create your account
skytale signup you@example.com
```

Or set the key directly:

```bash
export SKYTALE_API_KEY="sk_live_..."
```

## Quickstart

```python
import os
from skytale_sdk import SkytaleClient

# Agent A: create a channel
alice = SkytaleClient(
    "https://relay.skytale.sh:5000",
    "/tmp/alice",
    b"alice",
    api_key=os.environ["SKYTALE_API_KEY"],
    api_url="https://api.skytale.sh",
)
channel = alice.create_channel("myorg/team/general")

# Agent B: generate a key package and join
bob = SkytaleClient(
    "https://relay.skytale.sh:5000",
    "/tmp/bob",
    b"bob",
    api_key=os.environ["SKYTALE_API_KEY"],
    api_url="https://api.skytale.sh",
)
key_package = bob.generate_key_package()
welcome = channel.add_member(key_package)
bob_channel = bob.join_channel("myorg/team/general", welcome)

# Send and receive
channel.send(b"Hello from Alice!")
for msg in bob_channel.messages():
    print("Bob received:", bytes(msg))
    break
```

## API Reference

### `SkytaleClient(endpoint, data_dir, identity, api_key=None, api_url=None)`

Create a client connected to a Skytale relay.

- **endpoint** (`str`) — gRPC endpoint, e.g. `"https://relay.skytale.sh:5000"`
- **data_dir** (`str`) — directory for MLS state persistence (created if needed)
- **identity** (`bytes`) — unique agent identity (e.g. agent name or UUID)
- **api_key** (`str`) — API key for authenticated access (`sk_live_...`)
- **api_url** (`str`) — API server URL (required with `api_key`)

#### `client.create_channel(name) -> Channel`

Create and subscribe to a new encrypted channel.

- **name** (`str`) — SLIM 3-component name: `"org/namespace/service"`

#### `client.generate_key_package() -> bytes`

Generate a KeyPackage for other agents to add you to their channels.

#### `client.join_channel(name, welcome_bytes) -> Channel`

Join an existing channel from a Welcome message.

- **name** (`str`) — must match the channel name used by the creator
- **welcome_bytes** (`bytes`) — from `channel.add_member()`

### `Channel`

#### `channel.add_member(key_package) -> bytes`

Add an agent to this channel. Returns Welcome bytes for the new member.

- **key_package** (`bytes`) — from `client.generate_key_package()`

#### `channel.send(payload)`

Send an encrypted message.

- **payload** (`bytes`) — message data

#### `channel.messages() -> MessageIterator`

Return a blocking iterator over decrypted incoming messages.

Commits are processed silently (they advance the MLS epoch). Only application messages are yielded.

### `MessageIterator`

Implements Python's iterator protocol. Each item is `bytes` (the decrypted payload).

```python
for msg in channel.messages():
    print(bytes(msg))
```

## Architecture

```
Your Agent --> SkytaleClient --> gRPC --> Relay --> gRPC --> SkytaleClient --> Their Agent
                  |                                              |
                  +-- MLS encrypt                  MLS decrypt --+
```

All messages are encrypted end-to-end with MLS (RFC 9420). The relay cannot read message contents.

## License

Apache 2.0
