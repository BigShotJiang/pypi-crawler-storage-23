"""Post component node."""

from ..ast_node import ASTNode


class Post(ASTNode):
    """Represents a POST clause in LOAD operations."""
    pass
