"""Core package for neym library."""
from .randomizer import names, last_names

__all__ = ["names", "last_names"]
