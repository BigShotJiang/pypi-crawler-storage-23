# FILE-SIZE-OK: Recency backfill logic (REST, fromId, adaptive loop)
"""Layer 2 recency backfill for open deviation bar cache (Issue #92).

Bridges the gap between the latest Binance Vision archive data and the current
time by fetching recent trades via REST API and computing open deviation bars.

Architecture:
    Binance Vision (Tier 1) → [gap] → REST API (Layer 2) → ClickHouse

The adaptive polling loop self-tunes its frequency based on observed gap size,
configured via OPENDEVIATIONBAR_RECENCY_* env vars in .mise.toml (SSoT).

Usage
-----
Single-shot backfill:

>>> from opendeviationbar.recency import backfill_recent
>>> result = backfill_recent("BTCUSDT", threshold_decimal_bps=250)
>>> print(f"Filled {result.bars_written} bars, gap was {result.gap_seconds}s")

Backfill all cached symbols:

>>> from opendeviationbar.recency import backfill_all_recent
>>> results = backfill_all_recent()

Adaptive loop (long-running sidecar):

>>> from opendeviationbar.recency import run_adaptive_loop
>>> run_adaptive_loop()  # Runs until interrupted
"""

from __future__ import annotations

import gc
import logging
import os
import time
from dataclasses import dataclass, field
from datetime import UTC, datetime

logger = logging.getLogger(__name__)


# =============================================================================
# Adaptive Thresholds (from .mise.toml [env] SSoT)
# =============================================================================


def _env_int(key: str, default: int) -> int:
    return int(os.environ.get(key, str(default)))


def _fresh_threshold_s() -> int:
    """Gap below which data is considered fresh (sleep longer)."""
    return _env_int("OPENDEVIATIONBAR_RECENCY_FRESH_THRESHOLD_MIN", 30) * 60


def _stale_threshold_s() -> int:
    """Gap above which data is stale (poll more aggressively)."""
    return _env_int("OPENDEVIATIONBAR_RECENCY_STALE_THRESHOLD_MIN", 120) * 60


def _critical_threshold_s() -> int:
    """Gap above which data is critically stale (fast backfill)."""
    return _env_int("OPENDEVIATIONBAR_RECENCY_CRITICAL_THRESHOLD_MIN", 1440) * 60


def _adaptive_sleep(gap_seconds: float) -> float:
    """Compute sleep duration based on observed gap size.

    Returns sleep time in seconds. Larger gaps = shorter sleep = faster polling.
    """
    fresh = _fresh_threshold_s()
    stale = _stale_threshold_s()
    critical = _critical_threshold_s()

    if gap_seconds < fresh:
        return 15 * 60  # 15 min — data is fresh
    if gap_seconds < stale:
        return 5 * 60  # 5 min — getting stale
    if gap_seconds < critical:
        return 2 * 60  # 2 min — large gap
    return 30  # 30 sec — major gap


# =============================================================================
# MEM-014: Memory Watermark for Chunked Gap Repair
# =============================================================================

# 7 days in milliseconds — chunk size for _fetch_and_process_gap
_CHUNK_DURATION_MS = 7 * 24 * 60 * 60 * 1000

# Issue #156: Gaps larger than 7 days are Sisyphean via REST API — defer to Kintsugi P2
_MEGA_GAP_SECONDS = 7 * 24 * 3600


def _check_memory_watermark(memory_max_bytes: int) -> str:
    """Dask-style tiered watermark for chunked gap repair (MEM-014).

    Compares current process RSS against the configured memory ceiling
    (typically from systemd MemoryMax) and returns an action tier.

    Parameters
    ----------
    memory_max_bytes : int
        Memory ceiling in bytes (e.g., from systemd MemoryMax).

    Returns
    -------
    str
        ``"ok"`` — RSS < 65% of ceiling, continue normally.
        ``"gc"`` — RSS 65-90% of ceiling, run gc.collect() then continue.
        ``"abort"`` — RSS >= 90% of ceiling, stop processing to avoid OOM.
    """
    from opendeviationbar.resource_guard import _get_process_rss_mb

    rss_bytes = _get_process_rss_mb() * 1024 * 1024
    ratio = rss_bytes / memory_max_bytes if memory_max_bytes > 0 else 0.0

    if ratio >= 0.90:
        return "abort"
    if ratio >= 0.65:
        return "gc"
    return "ok"


# =============================================================================
# Result Types
# =============================================================================


@dataclass
class BackfillResult:
    """Result of a single backfill operation."""

    symbol: str
    threshold_decimal_bps: int
    bars_written: int
    gap_seconds: float
    latest_ts_before: int | None
    latest_ts_after: int | None
    duration_seconds: float = 0.0
    error: str | None = None


@dataclass
class LoopState:
    """State tracked across adaptive loop iterations."""

    iteration: int = 0
    total_bars_written: int = 0
    started_at: str = field(default_factory=lambda: datetime.now(UTC).isoformat())
    last_gaps: dict[str, float] = field(default_factory=dict)


# =============================================================================
# Core Backfill Logic
# =============================================================================

# Issue #164: BTCUSDT always backfilled first (bandwidth priority)
_PRIORITY_SYMBOLS = ("BTCUSDT",)


def _pair_sort_key(pair: tuple[str, int]) -> tuple[int, str, int]:
    """Sort key: priority symbols first, then alphabetical, then threshold."""
    symbol, threshold = pair
    symbol_rank = 0 if symbol in _PRIORITY_SYMBOLS else 1
    return (symbol_rank, symbol, threshold)


def _get_cached_symbol_threshold_pairs() -> list[tuple[str, int]]:
    """Query ClickHouse for all distinct (symbol, threshold) pairs in cache.

    Issue #126: Filters by operational ouroboros_mode to avoid returning
    pairs that only exist in a different mode.

    Issue #164: Results sorted with BTCUSDT first (bandwidth priority).

    Returns
    -------
    list[tuple[str, int]]
        List of (symbol, threshold_decimal_bps) pairs, BTCUSDT first.
    """
    from opendeviationbar.clickhouse import OpenDeviationBarCache
    from opendeviationbar.ouroboros import get_operational_ouroboros_mode

    mode = get_operational_ouroboros_mode()
    with OpenDeviationBarCache() as cache:
        result = cache.client.query(
            "SELECT DISTINCT symbol, threshold_decimal_bps "
            "FROM opendeviationbar_cache.open_deviation_bars FINAL "
            "WHERE ouroboros_mode = {mode:String} "
            "ORDER BY symbol, threshold_decimal_bps",
            parameters={"mode": mode},
        )
        pairs = [(row[0], row[1]) for row in result.result_rows]
    pairs.sort(key=_pair_sort_key)
    return pairs


def backfill_recent(
    symbol: str,
    threshold_decimal_bps: int = 250,
    *,
    include_microstructure: bool = True,
    verbose: bool = False,
    overlap_strategy: str = "skip",
) -> BackfillResult:
    """Backfill the gap between latest cached bar and now via REST API.

    Parameters
    ----------
    symbol : str
        Trading symbol (e.g., "BTCUSDT").
    threshold_decimal_bps : int
        Threshold in decimal basis points.
    include_microstructure : bool
        Include all 26 microstructure features (default True).
    verbose : bool
        Enable detailed logging.
    overlap_strategy : str
        Stathera overlap strategy for writes ("skip", "replace", "warn", "off").

    Returns
    -------
    BackfillResult
        Summary of the backfill operation.
    """
    from opendeviationbar.clickhouse import OpenDeviationBarCache
    from opendeviationbar.symbol_registry import validate_symbol_registered
    from opendeviationbar.threshold import resolve_and_validate_threshold

    validate_symbol_registered(symbol, operation="backfill_recent")
    threshold_decimal_bps = resolve_and_validate_threshold(
        symbol, threshold_decimal_bps
    )

    t0 = time.monotonic()
    now_ms = int(datetime.now(UTC).timestamp() * 1000)

    # Issue #158 (Stathera Phase 4): Combined query for timestamp + trade ID
    with OpenDeviationBarCache() as cache:
        latest_ts, latest_tid = cache.get_latest_bar_with_trade_id(
            symbol, threshold_decimal_bps,
        )

    if latest_ts is None:
        logger.warning(
            "No cached bars for %s @ %d dbps — cannot backfill "
            "(run populate_cache_resumable first)",
            symbol,
            threshold_decimal_bps,
        )
        return BackfillResult(
            symbol=symbol,
            threshold_decimal_bps=threshold_decimal_bps,
            bars_written=0,
            gap_seconds=0,
            latest_ts_before=None,
            latest_ts_after=None,
            duration_seconds=time.monotonic() - t0,
            error="no_cached_bars",
        )

    gap_ms = now_ms - latest_ts
    gap_seconds = gap_ms / 1000.0

    if gap_seconds < 60:
        # Less than 1 minute gap — nothing meaningful to backfill
        logger.debug(
            "%s @ %d dbps: gap %.0fs — fresh, skipping",
            symbol,
            threshold_decimal_bps,
            gap_seconds,
        )
        return BackfillResult(
            symbol=symbol,
            threshold_decimal_bps=threshold_decimal_bps,
            bars_written=0,
            gap_seconds=gap_seconds,
            latest_ts_before=latest_ts,
            latest_ts_after=latest_ts,
            duration_seconds=time.monotonic() - t0,
        )

    # Issue #156: Skip mega-gaps — REST API is Sisyphean for large gaps.
    # Leave these for Kintsugi P2 (populate_cache_resumable with Vision archives).
    if gap_seconds > _MEGA_GAP_SECONDS:
        logger.info(
            "%s @ %d dbps: gap %.1f days — too large for REST, "
            "deferring to Kintsugi P2",
            symbol,
            threshold_decimal_bps,
            gap_seconds / 86400,
        )
        return BackfillResult(
            symbol=symbol,
            threshold_decimal_bps=threshold_decimal_bps,
            bars_written=0,
            gap_seconds=gap_seconds,
            latest_ts_before=latest_ts,
            latest_ts_after=latest_ts,
            duration_seconds=time.monotonic() - t0,
        )

    logger.info(
        "%s @ %d dbps: gap %.1f min — backfilling from REST API",
        symbol,
        threshold_decimal_bps,
        gap_seconds / 60,
    )

    # Step 2: Fetch recent trades via REST API
    # Issue #158: Pass trade-ID anchor directly (avoids re-querying ClickHouse)
    try:
        bars_written = _fetch_and_process_gap(
            symbol=symbol,
            threshold_decimal_bps=threshold_decimal_bps,
            start_ms=latest_ts + 1,
            end_ms=now_ms,
            include_microstructure=include_microstructure,
            verbose=verbose,
            ariadne_anchor_override=latest_tid,
            overlap_strategy=overlap_strategy,
        )
    except (RuntimeError, OSError, ConnectionError) as e:
        logger.warning(
            "%s @ %d dbps: backfill failed: %s",
            symbol,
            threshold_decimal_bps,
            e,
        )
        return BackfillResult(
            symbol=symbol,
            threshold_decimal_bps=threshold_decimal_bps,
            bars_written=0,
            gap_seconds=gap_seconds,
            latest_ts_before=latest_ts,
            latest_ts_after=latest_ts,
            duration_seconds=time.monotonic() - t0,
            error=str(e),
        )

    # Step 3: Query new latest timestamp
    with OpenDeviationBarCache() as cache:
        new_latest_ts = cache.get_latest_bar_timestamp(symbol, threshold_decimal_bps)

    elapsed = time.monotonic() - t0
    logger.info(
        "%s @ %d dbps: backfilled %d bars in %.1fs (gap was %.1f min)",
        symbol,
        threshold_decimal_bps,
        bars_written,
        elapsed,
        gap_seconds / 60,
    )

    return BackfillResult(
        symbol=symbol,
        threshold_decimal_bps=threshold_decimal_bps,
        bars_written=bars_written,
        gap_seconds=gap_seconds,
        latest_ts_before=latest_ts,
        latest_ts_after=new_latest_ts,
        duration_seconds=elapsed,
    )


def _fetch_aggtrades_rest(
    symbol: str,
    start_ms: int,
    end_ms: int,
) -> list[dict]:
    """Fetch aggregated trades from Binance REST API via Rust (native performance).

    Delegates to Rust `fetch_aggtrades_rest()` which uses reqwest to paginate
    through /api/v3/aggTrades (max 1000 per request) with async I/O.

    Returns list of trade dicts compatible with
    OpenDeviationBarProcessor.process_trades().
    """
    from opendeviationbar._core import fetch_aggtrades_rest

    try:
        return fetch_aggtrades_rest(symbol, start_ms, end_ms)
    except Exception as e:
        msg = f"REST API fetch failed for {symbol} [{start_ms}-{end_ms}]: {e}"
        raise RuntimeError(msg) from e


def _fetch_aggtrades_by_id(
    symbol: str,
    from_id: int,
    limit: int = 1000,
) -> list[dict]:
    """Fetch aggregated trades by fromId (zero-gap pagination via Rust).

    Uses ``fromId`` parameter instead of ``startTime`` to avoid dropping
    trades at millisecond boundaries.  Delegates to Rust
    ``fetch_aggtrades_by_id()`` which includes 429 backoff.

    Returns list of trade dicts compatible with
    OpenDeviationBarProcessor.process_trades().
    """
    from opendeviationbar._core import fetch_aggtrades_by_id

    try:
        return fetch_aggtrades_by_id(symbol, from_id, limit)
    except Exception as e:
        msg = (
            f"REST API fetch (fromId) failed for {symbol} "
            f"[fromId={from_id}, limit={limit}]: {e}"
        )
        raise RuntimeError(msg) from e


def _fetch_latest_aggtrade(symbol: str) -> dict:
    """Fetch the latest aggregated trade for a symbol via Rust.

    Single REST call with ``limit=1``.  Returns single trade dict as
    anchor point for cursor-based ``fromId`` pagination.
    """
    from opendeviationbar._core import fetch_latest_aggtrade

    try:
        return fetch_latest_aggtrade(symbol)
    except Exception as e:
        msg = f"REST API fetch (latest) failed for {symbol}: {e}"
        raise RuntimeError(msg) from e


def _process_gap_fallback_starttime(
    *,
    symbol: str,
    threshold_decimal_bps: int,
    start_ms: int,
    end_ms: int,
    include_microstructure: bool = True,
) -> int:
    """Process gap using startTime fallback (first-ever backfill, no Ariadne anchor).

    Issue #158 (Stathera Phase 4): Helper function to reduce _fetch_and_process_gap
    statement count.

    Returns number of bars written.
    """
    import polars as pl

    from opendeviationbar.clickhouse import OpenDeviationBarCache
    from opendeviationbar.orchestration.helpers import (
        _create_processor,
    )

    trades = _fetch_aggtrades_rest(symbol, start_ms, end_ms)
    logger.debug(
        "%s: startTime fallback fetched %d trades (%d-%d ms)",
        symbol,
        len(trades),
        start_ms,
        end_ms,
    )
    if not trades:
        return 0

    processor = _create_processor(
        threshold_decimal_bps,
        include_microstructure,
        symbol=symbol,
    )
    bars = processor.process_trades(trades)
    if not bars:
        return 0

    bars_df = pl.DataFrame(bars)
    from opendeviationbar import __version__

    source_version = f"{__version__}+recency"
    with OpenDeviationBarCache() as cache:
        return cache.store_bars_batch(
            symbol=symbol,
            threshold_decimal_bps=threshold_decimal_bps,
            bars=bars_df,
            version=source_version,
            overlap_strategy="skip",  # Issue #158: skip if sidecar already wrote
        )


def _fetch_and_process_gap(
    *,
    symbol: str,
    threshold_decimal_bps: int,
    start_ms: int,
    end_ms: int,
    include_microstructure: bool = True,
    verbose: bool = False,
    ariadne_anchor_override: int | None = None,
    overlap_strategy: str = "skip",
) -> int:
    """Fetch trades and process into open deviation bars using Ariadne (fromId).

    MEM-014: Processes trades in 7-day chunks to bound memory usage.
    Uses ``process_trades_streaming()`` to maintain processor state
    (incomplete bar) across chunk boundaries.

    Issue #115 (Kintsugi Phase 2a): Uses Ariadne fromId pagination when
    a last_agg_trade_id anchor exists in ClickHouse. Falls back to
    startTime only for first-ever backfill (no bars at all).

    Issue #158 (Stathera Phase 4): Accepts ariadne_anchor_override to
    avoid re-querying ClickHouse when caller already has the trade ID.

    Returns number of bars written.
    """
    import polars as pl

    from opendeviationbar.clickhouse import OpenDeviationBarCache
    from opendeviationbar.orchestration.helpers import (
        _create_processor,
    )

    # Issue #158: Use caller-provided anchor, fall back to ClickHouse query
    ariadne_anchor: int | None = ariadne_anchor_override
    if ariadne_anchor is None:
        with OpenDeviationBarCache() as cache:
            ariadne_anchor = cache.get_ariadne_high_water_mark(
                symbol,
                threshold_decimal_bps,
            )

    use_ariadne = ariadne_anchor is not None

    if not use_ariadne:
        # Fallback to startTime (first-ever backfill only) — delegate to helper
        return _process_gap_fallback_starttime(
            symbol=symbol,
            threshold_decimal_bps=threshold_decimal_bps,
            start_ms=start_ms,
            end_ms=end_ms,
            include_microstructure=include_microstructure,
        )

    # --- MEM-014: Chunked Ariadne path ---
    assert ariadne_anchor is not None  # type narrowing
    current_from_id = ariadne_anchor + 1
    total_written = 0

    # Memory ceiling for watermark checks (default 4G like kintsugi MemoryMax)
    memory_max_bytes = int(
        os.environ.get("OPENDEVIATIONBAR_MEMORY_MAX_BYTES", str(4 * 1024**3))
    )  # SSoT-OK: systemd MemoryMax passthrough, not a tuneable default

    # Single streaming processor across all chunks — preserves incomplete bar
    processor = _create_processor(
        threshold_decimal_bps,
        include_microstructure,
        symbol=symbol,
    )

    # Build chunk time windows (used only to bound _fetch_trades_ariadne end_ms)
    chunk_start_ms = start_ms
    while chunk_start_ms < end_ms:
        chunk_end_ms = min(chunk_start_ms + _CHUNK_DURATION_MS, end_ms)

        # Fetch trades for this chunk via Ariadne
        trades = _fetch_trades_ariadne(
            symbol,
            current_from_id,
            chunk_end_ms,
            verbose=verbose,
        )

        if not trades:
            logger.debug(
                "%s: no trades in chunk [from_id=%d, end_ms=%d]",
                symbol,
                current_from_id,
                chunk_end_ms,
            )
            chunk_start_ms = chunk_end_ms
            continue

        logger.debug(
            "%s: Ariadne chunk fetched %d trades (from_id=%d, end_ms=%d)",
            symbol,
            len(trades),
            current_from_id,
            chunk_end_ms,
        )

        # Process through streaming processor — returns only completed bars
        bars = processor.process_trades_streaming(trades)

        # Advance Ariadne cursor past this chunk's trades
        last_trade = trades[-1]
        last_trade_id = last_trade.get(
            "agg_trade_id", last_trade.get("a", 0)
        )
        current_from_id = last_trade_id + 1

        # Write completed bars to ClickHouse
        if bars:
            bars_df = pl.DataFrame(bars)
            # Issue #158: Stathera source tagging
            from opendeviationbar import __version__

            source_version = f"{__version__}+recency"
            with OpenDeviationBarCache() as cache:
                written = cache.store_bars_batch(
                    symbol=symbol,
                    threshold_decimal_bps=threshold_decimal_bps,
                    bars=bars_df,
                    version=source_version,
                    overlap_strategy=overlap_strategy,
                )
            total_written += written
            logger.debug(
                "%s: chunk wrote %d bars (total %d)",
                symbol,
                written,
                total_written,
            )

        # MEM-014: Free chunk memory and check watermark
        del trades, bars
        gc.collect()

        watermark = _check_memory_watermark(memory_max_bytes)
        if watermark == "abort":
            logger.warning(
                "%s: memory watermark ABORT (RSS >= 90%% of %d MB) — "
                "stopping gap repair early after %d bars written",
                symbol,
                memory_max_bytes // (1024 * 1024),
                total_written,
            )
            break
        if watermark == "gc":
            logger.info(
                "%s: memory watermark GC (RSS 65-90%% of ceiling)",
                symbol,
            )

        chunk_start_ms = chunk_end_ms

    return total_written


def _fetch_aggtrades_by_id_with_retry(
    symbol: str,
    from_id: int,
    limit: int = 1000,
    *,
    max_retries: int = 3,
) -> list[dict]:
    """Fetch aggTrades by ID with retry for transient errors (Issue #156).

    Defense-in-depth atop the Rust-level retry in send_with_rate_limit_backoff.
    Retries on RuntimeError/ConnectionError/OSError with exponential backoff.
    """
    backoff_s = 2.0
    last_exc: Exception | None = None
    for attempt in range(max_retries):
        try:
            return _fetch_aggtrades_by_id(symbol, from_id, limit)
        except (RuntimeError, ConnectionError, OSError) as e:
            last_exc = e
            if attempt < max_retries - 1:
                logger.warning(
                    "%s: transient error fetching fromId=%d (attempt %d/%d, "
                    "retry in %.0fs): %s",
                    symbol,
                    from_id,
                    attempt + 1,
                    max_retries,
                    backoff_s,
                    e,
                )
                time.sleep(backoff_s)
                backoff_s *= 2
    raise last_exc  # type: ignore[misc]


def _fetch_trades_ariadne(
    symbol: str,
    from_id: int,
    end_ms: int,
    *,
    batch_size: int = 1000,
    verbose: bool = False,
) -> list[dict]:
    """Paginate trades using Ariadne fromId cursor until end_ms.

    Returns all trades from from_id up to end_ms (inclusive).
    """
    all_trades: list[dict] = []
    current_id = from_id

    while True:
        batch = _fetch_aggtrades_by_id_with_retry(symbol, current_id, batch_size)
        if not batch:
            break

        for trade in batch:
            ts = trade.get("timestamp") or trade.get("time", 0)
            if ts > end_ms:
                return all_trades
            all_trades.append(trade)

        # Advance cursor past this batch
        last_id = batch[-1].get("agg_trade_id", batch[-1].get("a", 0))
        if last_id <= current_id:
            break  # Safety: no progress
        current_id = last_id + 1

        if verbose and len(all_trades) % 10000 == 0:
            logger.debug(
                "%s: Ariadne progress %d trades, current_id=%d",
                symbol,
                len(all_trades),
                current_id,
            )

    return all_trades


# =============================================================================
# Multi-Symbol Backfill
# =============================================================================

# Issue #115 (Kintsugi Phase 2b): Sustained failure tracking
_SUSTAINED_FAILURE_THRESHOLD = 5


def _notify_sustained_failure(consecutive_errors: int) -> None:
    """Send Telegram alert after N consecutive backfill failures."""
    try:
        from opendeviationbar.notify.telegram import _build_context_block, send_telegram
    except ImportError:
        return
    try:
        msg = (
            "<b>BACKFILL SUSTAINED FAILURE</b>\n"
            f"<b>Consecutive errors:</b> {consecutive_errors}\n"
            f"<b>Threshold:</b> {_SUSTAINED_FAILURE_THRESHOLD}\n"
            "<b>Check:</b> REST API connectivity + ClickHouse status\n"
            "<b>Debug:</b> <code>curl -s 'http://localhost:8123/?query=SELECT+1'</code>"
            + _build_context_block("backfill")
        )
        send_telegram(msg, disable_notification=False)
    except (OSError, RuntimeError, ConnectionError):
        logger.exception("failed to send sustained failure alert")


def backfill_all_recent(
    *,
    include_microstructure: bool = True,
    verbose: bool = False,
) -> list[BackfillResult]:
    """Backfill all cached symbol x threshold pairs.

    Queries ClickHouse for all distinct (symbol, threshold) pairs and runs
    backfill_recent for each.

    Issue #115 (Kintsugi Phase 2b): Sends Telegram alert after 5 consecutive
    errors across the batch (sustained failure detection).

    Returns
    -------
    list[BackfillResult]
        Results for each pair, including any errors.
    """
    pairs = _get_cached_symbol_threshold_pairs()
    logger.info("Backfilling %d symbol x threshold pairs", len(pairs))

    results = []
    consecutive_errors = 0
    for symbol, threshold in pairs:
        try:
            result = backfill_recent(
                symbol,
                threshold,
                include_microstructure=include_microstructure,
                verbose=verbose,
            )
            results.append(result)
            if result.error:
                consecutive_errors += 1
            else:
                consecutive_errors = 0
        except (ValueError, RuntimeError, OSError, ConnectionError) as e:
            logger.warning(
                "Backfill failed for %s @ %d: %s",
                symbol,
                threshold,
                e,
            )
            results.append(
                BackfillResult(
                    symbol=symbol,
                    threshold_decimal_bps=threshold,
                    bars_written=0,
                    gap_seconds=0,
                    latest_ts_before=None,
                    latest_ts_after=None,
                    error=str(e),
                )
            )
            consecutive_errors += 1

        if consecutive_errors >= _SUSTAINED_FAILURE_THRESHOLD:
            _notify_sustained_failure(consecutive_errors)
            consecutive_errors = 0  # Reset after alert

    total_bars = sum(r.bars_written for r in results)
    errors = sum(1 for r in results if r.error)
    logger.info(
        "Backfill complete: %d pairs, %d bars written, %d errors",
        len(results),
        total_bars,
        errors,
    )
    return results


# =============================================================================
# Adaptive Loop
# =============================================================================


def run_adaptive_loop(
    *,
    include_microstructure: bool = True,
    verbose: bool = False,
) -> None:
    """Run adaptive recency backfill loop until interrupted.

    Self-tunes polling frequency based on observed gap sizes. Designed to run
    as a long-lived sidecar process (systemd service or tmux session).

    The loop:
    1. Queries all cached symbol x threshold pairs
    2. Backfills each pair
    3. Computes max gap across all pairs
    4. Sleeps for adaptive duration based on max gap
    5. Repeats

    Stop with Ctrl+C (SIGINT).
    """
    # Issue #126: SIGHUP reloads config (enables runtime ouroboros_mode switching)
    import signal

    def _sighup_handler(*_args: object) -> None:
        from opendeviationbar.config import Settings

        Settings.reload_and_clear()
        new_mode = Settings.get().population.ouroboros_mode
        logger.info("SIGHUP: config reloaded (ouroboros_mode=%s)", new_mode)
        # Issue #134: Notify operators of runtime config change
        try:
            from opendeviationbar.notify.telegram import send_telegram

            send_telegram(
                f"<b>SIGHUP: recency config reloaded</b>\n"
                f"<b>ouroboros_mode:</b> {new_mode}\n"
                f"<b>PID:</b> {os.getpid()}",
                disable_notification=True,
            )
        except (ImportError, OSError):
            logger.debug("SIGHUP: Telegram notification failed (non-fatal)")

    signal.signal(signal.SIGHUP, _sighup_handler)

    state = LoopState()
    logger.info("Starting adaptive recency backfill loop")

    try:
        while True:
            state.iteration += 1
            logger.info("=== Iteration %d ===", state.iteration)

            results = backfill_all_recent(
                include_microstructure=include_microstructure,
                verbose=verbose,
            )

            # Track gaps per symbol for adaptive sleep
            max_gap = 0.0
            for r in results:
                key = f"{r.symbol}@{r.threshold_decimal_bps}"
                state.last_gaps[key] = r.gap_seconds
                state.total_bars_written += r.bars_written
                max_gap = max(max_gap, r.gap_seconds)

            # WS-2: Periodic rectification pass for bars with trade deficit
            if (
                _RECTIFICATION_CYCLE_INTERVAL > 0
                and state.iteration % _RECTIFICATION_CYCLE_INTERVAL == 0
            ):
                pairs = _get_cached_symbol_threshold_pairs()
                for sym, thr in pairs:
                    try:
                        rectified = rectify_recent_bars(sym, thr)
                        if rectified > 0:
                            logger.info(
                                "rectified %d bars for %s@%d",
                                rectified,
                                sym,
                                thr,
                            )
                    except (
                        RuntimeError,
                        OSError,
                        ConnectionError,
                        ValueError,
                    ) as e:
                        logger.warning(
                            "rectification failed for %s@%d: %s",
                            sym,
                            thr,
                            e,
                        )

            sleep_seconds = _adaptive_sleep(max_gap)
            logger.info(
                "Max gap: %.1f min | Sleep: %.0fs | Total bars: %d",
                max_gap / 60,
                sleep_seconds,
                state.total_bars_written,
            )

            time.sleep(sleep_seconds)

    except KeyboardInterrupt:
        logger.info(
            "Loop stopped after %d iterations, %d total bars written",
            state.iteration,
            state.total_bars_written,
        )


@dataclass
class BackfillStatus:
    """Status of the most recent backfill request for a symbol x threshold pair."""

    status: str  # "none" | "pending" | "running" | "completed" | "failed"
    request_id: str | None = None
    requested_at: datetime | None = None
    started_at: datetime | None = None
    completed_at: datetime | None = None
    bars_written: int = 0
    gap_seconds: float = 0.0
    error: str | None = None
    elapsed_seconds: float = 0.0
    watcher_likely_offline: bool = False


def check_backfill_status(
    symbol: str,
    threshold_decimal_bps: int = 250,
) -> BackfillStatus:
    """Check the status of the most recent backfill request.

    Queries the backfill_requests table for the latest request matching the
    given symbol and threshold. If the request has been pending for more than
    300 seconds, sets ``watcher_likely_offline=True``.

    Parameters
    ----------
    symbol : str
        Trading symbol (e.g., "BTCUSDT").
    threshold_decimal_bps : int
        Threshold in decimal basis points (use 0 to match any threshold).

    Returns
    -------
    BackfillStatus
        Current status of the most recent backfill request, or status="none"
        if no matching request exists.
    """
    from opendeviationbar.clickhouse import OpenDeviationBarCache

    with OpenDeviationBarCache() as cache:
        result = cache.client.query(
            "SELECT request_id, status, requested_at, started_at, "
            "completed_at, bars_written, gap_seconds, error "
            "FROM opendeviationbar_cache.backfill_requests FINAL "
            "WHERE symbol = {symbol:String} "
            "  AND (threshold_decimal_bps = {threshold:UInt32} "
            "       OR threshold_decimal_bps = 0) "
            "ORDER BY requested_at DESC "
            "LIMIT 1",
            parameters={
                "symbol": symbol,
                "threshold": threshold_decimal_bps,
            },
        )

    if not result.result_rows:
        return BackfillStatus(status="none")

    row = result.result_rows[0]
    request_id = str(row[0])
    status = str(row[1])
    requested_at = row[2] if row[2] else None
    started_at = row[3] if row[3] else None
    completed_at = row[4] if row[4] else None
    bars_written = int(row[5]) if row[5] else 0
    gap_seconds = float(row[6]) if row[6] else 0.0
    error = str(row[7]) if row[7] else None

    # Compute elapsed time from requested_at
    elapsed_seconds = 0.0
    if requested_at:
        now = datetime.now(UTC)
        if hasattr(requested_at, "timestamp"):
            elapsed_seconds = (now - requested_at).total_seconds()

    watcher_likely_offline = status == "pending" and elapsed_seconds > 300

    return BackfillStatus(
        status=status,
        request_id=request_id,
        requested_at=requested_at,
        started_at=started_at,
        completed_at=completed_at,
        bars_written=bars_written,
        gap_seconds=gap_seconds,
        error=error,
        elapsed_seconds=elapsed_seconds,
        watcher_likely_offline=watcher_likely_offline,
    )


# =============================================================================
# WS-2: Bar Rectification (Safety Net)
# =============================================================================

# Default interval: rectify every 12 backfill cycles (~hourly at 5-min intervals)
_RECTIFICATION_CYCLE_INTERVAL = int(
    os.environ.get("OPENDEVIATIONBAR_RECTIFY_CYCLE_INTERVAL", "12")
)  # SSoT-OK: env-configurable interval


def rectify_recent_bars(
    symbol: str,
    threshold_decimal_bps: int,
    lookback_hours: float = 2.0,
    deficit_threshold: float = 0.05,
) -> int:
    """Re-fetch and overwrite bars with significant trade count deficit.

    Compares ``agg_record_count`` in ClickHouse against expected count
    derived from ``last_agg_trade_id - first_agg_trade_id + 1`` for each
    bar in the lookback window. Bars with > ``deficit_threshold`` (5%)
    trade deficit are re-fetched via REST ``fromId`` pagination and
    reprocessed through the canonical Rust processor.

    To achieve bit-exact parity with the streaming sidecar:
    - Fetches ~N lookback trades *before* each bar's ``first_agg_trade_id``
      to populate the processor's ``trade_history`` ring buffer, ensuring
      all 16 ``lookback_*`` inter-bar features are computed (not None).
    - Detects boundary divergence: if the rectified bar has a different
      ``close_time_ms`` than the original (because a previously-missing
      trade triggers a breach earlier/later), deletes the ghost bar via
      ``ALTER TABLE DELETE`` before writing the corrected bar.

    ``ReplacingMergeTree(computed_at)`` ensures the newer version wins
    for bars with matching primary keys.

    Parameters
    ----------
    symbol : str
        Trading symbol (e.g., "BTCUSDT").
    threshold_decimal_bps : int
        Threshold in decimal basis points.
    lookback_hours : float
        How far back to check for deficient bars (default 2h).
    deficit_threshold : float
        Fraction of expected trades below which a bar is rectified
        (default 0.05 = 5% deficit).

    Returns
    -------
    int
        Number of bars rectified.
    """
    import polars as pl

    from opendeviationbar.clickhouse import OpenDeviationBarCache
    from opendeviationbar.orchestration.helpers import (
        _create_processor,
        _parse_microstructure_env_vars,
    )
    from opendeviationbar.ouroboros import get_operational_ouroboros_mode

    mode = get_operational_ouroboros_mode()
    cutoff_ms = int(
        (datetime.now(UTC).timestamp() - lookback_hours * 3600) * 1000
    )

    # Determine lookback trade count for inter-bar feature warm-up
    _, _, _ = _parse_microstructure_env_vars(True, None, None)
    lookback_count = int(
        os.environ.get("OPENDEVIATIONBAR_INTER_BAR_LOOKBACK_COUNT", "200")
    )

    # Step 1: Query recent bars with their trade ID range and record count
    with OpenDeviationBarCache() as cache:
        result = cache.client.query(
            "SELECT close_time_ms, first_agg_trade_id, last_agg_trade_id, "
            "       agg_record_count "
            "FROM opendeviationbar_cache.open_deviation_bars FINAL "
            "WHERE symbol = {symbol:String} "
            "  AND threshold_decimal_bps = {threshold:UInt32} "
            "  AND ouroboros_mode = {mode:String} "
            "  AND close_time_ms > {cutoff_ms:Int64} "
            "ORDER BY close_time_ms",
            parameters={
                "symbol": symbol,
                "threshold": threshold_decimal_bps,
                "mode": mode,
                "cutoff_ms": cutoff_ms,
            },
        )

    if not result.result_rows:
        return 0

    # Step 2: Identify bars with trade deficit
    deficient_bars: list[tuple[int, int, int, int]] = []
    for row in result.result_rows:
        close_time_ms, first_id, last_id, actual_count = (
            int(row[0]),
            int(row[1]),
            int(row[2]),
            int(row[3]),
        )
        expected_count = last_id - first_id + 1
        if expected_count <= 0:
            continue
        if actual_count < expected_count * (1 - deficit_threshold):
            deficient_bars.append(
                (close_time_ms, first_id, last_id, actual_count)
            )

    if not deficient_bars:
        return 0

    logger.info(
        "%s @ %d dbps: %d/%d bars have trade deficit in last %.1fh",
        symbol,
        threshold_decimal_bps,
        len(deficient_bars),
        len(result.result_rows),
        lookback_hours,
    )

    # Step 3: Re-fetch trades with lookback warm-up and reprocess
    rectified = 0
    for close_time_ms, first_id, last_id, old_count in deficient_bars:
        try:
            # Fetch lookback trades to warm up trade_history for inter-bar
            # features. These trades precede the bar and won't produce bars
            # themselves (the bar boundary falls within the bar trades).
            lookback_from_id = max(0, first_id - lookback_count)
            lookback_trades: list[dict] = []
            if lookback_from_id < first_id:
                lookback_trades = _fetch_trades_for_bar(
                    symbol, lookback_from_id, first_id - 1
                )

            # Fetch the bar's actual trades (full range)
            bar_trades = _fetch_trades_for_bar(symbol, first_id, last_id)
            if not bar_trades:
                continue

            # Concatenate: lookback trades warm up trade_history, then bar
            # trades produce the actual bars with correct inter-bar features
            all_trades = lookback_trades + bar_trades

            processor = _create_processor(
                threshold_decimal_bps,
                include_microstructure=True,
                symbol=symbol,
            )
            bars = processor.process_trades(all_trades)
            if not bars:
                continue

            # Filter: keep only bars whose trade range overlaps the original
            # bar's range (exclude bars formed purely from lookback trades)
            rectified_bars = [
                b
                for b in bars
                if b["last_agg_trade_id"] >= first_id
                and b["first_agg_trade_id"] <= last_id
            ]
            if not rectified_bars:
                continue

            # Detect boundary divergence: if no rectified bar has the same
            # close_time_ms as the original, the missing trades shifted the
            # breach point. Delete the ghost bar before writing corrections.
            rectified_close_times = {
                b["close_time_ms"] for b in rectified_bars
            }
            if close_time_ms not in rectified_close_times:
                _delete_ghost_bar(
                    symbol,
                    threshold_decimal_bps,
                    mode,
                    close_time_ms,
                )

            bars_df = pl.DataFrame(rectified_bars)
            from opendeviationbar import __version__

            with OpenDeviationBarCache() as cache:
                cache.store_bars_batch(
                    symbol=symbol,
                    threshold_decimal_bps=threshold_decimal_bps,
                    bars=bars_df,
                    version=f"{__version__}+rectify",
                    overlap_strategy="replace",
                )

            new_count = len(bar_trades)
            logger.info(
                "%s @ %d: rectified bar close_time_ms=%d "
                "(agg_count %d → %d, bars_produced=%d)",
                symbol,
                threshold_decimal_bps,
                close_time_ms,
                old_count,
                new_count,
                len(rectified_bars),
            )
            _emit_rectification_event(
                symbol,
                threshold_decimal_bps,
                close_time_ms,
                old_count,
                new_count,
            )
            rectified += 1

        except (RuntimeError, OSError, ConnectionError) as e:
            logger.warning(
                "%s @ %d: rectification failed for bar close_time_ms=%d: %s",
                symbol,
                threshold_decimal_bps,
                close_time_ms,
                e,
            )

    return rectified


def _delete_ghost_bar(
    symbol: str,
    threshold_decimal_bps: int,
    ouroboros_mode: str,
    close_time_ms: int,
) -> None:
    """Delete a ghost bar caused by boundary divergence during rectification.

    When rectification discovers that missing trades shift the breach point,
    the original bar's ``close_time_ms`` differs from the corrected bar's.
    Since ``ReplacingMergeTree`` deduplicates by primary key (which includes
    ``close_time_ms``), the original bar would persist as a ghost.

    This issues an ``ALTER TABLE DELETE`` to remove the stale row.
    """
    from opendeviationbar.clickhouse import OpenDeviationBarCache

    try:
        with OpenDeviationBarCache() as cache:
            cache.client.command(
                "ALTER TABLE opendeviationbar_cache.open_deviation_bars "
                "DELETE WHERE symbol = {symbol:String} "
                "  AND threshold_decimal_bps = {threshold:UInt32} "
                "  AND ouroboros_mode = {mode:String} "
                "  AND close_time_ms = {close_time_ms:Int64}",
                parameters={
                    "symbol": symbol,
                    "threshold": threshold_decimal_bps,
                    "mode": ouroboros_mode,
                    "close_time_ms": close_time_ms,
                },
            )
        logger.info(
            "%s @ %d: deleted ghost bar close_time_ms=%d "
            "(boundary divergence)",
            symbol,
            threshold_decimal_bps,
            close_time_ms,
        )
    except (RuntimeError, OSError, ConnectionError) as e:
        logger.warning(
            "%s @ %d: failed to delete ghost bar close_time_ms=%d: %s",
            symbol,
            threshold_decimal_bps,
            close_time_ms,
            e,
        )


def _fetch_trades_for_bar(
    symbol: str,
    first_agg_trade_id: int,
    last_agg_trade_id: int,
) -> list[dict]:
    """Fetch all trades for a bar's ID range via REST ``fromId`` pagination."""
    all_trades: list[dict] = []
    current_id = first_agg_trade_id

    while current_id <= last_agg_trade_id:
        limit = min(1000, last_agg_trade_id - current_id + 1)
        batch = _fetch_aggtrades_by_id_with_retry(
            symbol, current_id, int(limit)
        )
        if not batch:
            break

        for trade in batch:
            trade_id = trade.get("agg_trade_id", trade.get("a", 0))
            if trade_id > last_agg_trade_id:
                return all_trades
            all_trades.append(trade)

        last_batch_id = batch[-1].get("agg_trade_id", batch[-1].get("a", 0))
        if last_batch_id <= current_id:
            break  # No progress
        current_id = last_batch_id + 1

    return all_trades


def _emit_rectification_event(
    symbol: str,
    threshold: int,
    close_time_ms: int,
    old_agg_count: int,
    new_agg_count: int,
) -> None:
    """Emit NDJSON telemetry event for a bar rectification."""
    try:
        import json

        event = {
            "ts": datetime.now(UTC).isoformat(),
            "event": "bar_rectified",
            "symbol": symbol,
            "threshold": threshold,
            "close_time_ms": close_time_ms,
            "old_agg_count": old_agg_count,
            "new_agg_count": new_agg_count,
        }
        # Append to events log (same as other telemetry)
        from pathlib import Path

        log_dir = Path(
            os.environ.get(
                "OPENDEVIATIONBAR_LOG_DIR", "logs"
            )
        )  # SSoT-OK: env-configurable log dir
        log_dir.mkdir(parents=True, exist_ok=True)
        with (log_dir / "events.jsonl").open("a") as f:
            f.write(json.dumps(event) + "\n")
    except (OSError, ImportError):
        pass  # Non-fatal telemetry


__all__ = [
    "BackfillResult",
    "BackfillStatus",
    "LoopState",
    "backfill_all_recent",
    "backfill_recent",
    "check_backfill_status",
    "rectify_recent_bars",
    "run_adaptive_loop",
]
