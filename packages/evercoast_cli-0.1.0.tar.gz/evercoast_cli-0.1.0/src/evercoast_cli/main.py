"""Evercoast CLI entry point.

Commands:
    evercoast login [--staging]
    evercoast upload <path> [options]
"""

import os
import sys

import click
from rich.console import Console

from . import __version__
from .api import APIError, fetch_s3_credentials, get_s3_client, login, setup_aws_cli_profile
from .config import Config, PRODUCTION_API_URL, STAGING_API_URL
from .upload import (
    TYPE_LABELS,
    check_network,
    compute_upload_plan,
    console as upload_console,
    format_size,
    get_remote_files,
    print_dry_run_details,
    print_upload_summary,
    resolve_destination,
    upload_files,
    walk_local_files,
)

console = Console()

# Marker comment used to identify our line in shell rc files
_COMPLETION_MARKER = "# Evercoast CLI shell completion"


@click.group()
@click.version_option(__version__, prog_name="evercoast")
def cli():
    """Evercoast CLI — upload files to your company's S3 bucket.

    \b
    Quick start:
      1. evercoast login          (one-time setup)
      2. evercoast upload <path>  (upload files)

    \b
    Features:
      • Resumable uploads — interrupted uploads pick up where they left off
      • Checksum validation — SHA256 integrity checks on every file
      • Automatic retries — recovers from network drops indefinitely
      • Progress tracking — per-file and overall progress bars
      • Cross-platform — works on macOS, Linux, and Windows
    """
    pass


def _install_shell_completion():
    """Install shell tab-completion for the evercoast command.

    Writes a completion script to ~/.evercoast/ and adds a source line
    to the user's shell rc file (~/.zshrc or ~/.bashrc) if not already present.
    """
    import subprocess
    from pathlib import Path

    config_dir = Path.home() / ".evercoast"
    config_dir.mkdir(parents=True, exist_ok=True)

    # Detect shell
    shell = os.environ.get("SHELL", "")
    if "zsh" in shell:
        shell_type = "zsh"
        rc_file = Path.home() / ".zshrc"
        env_var = "_EVERCOAST_COMPLETE=zsh_source"
        completion_file = config_dir / "_completion.zsh"
    elif "bash" in shell:
        shell_type = "bash"
        rc_file = Path.home() / ".bashrc"
        env_var = "_EVERCOAST_COMPLETE=bash_source"
        completion_file = config_dir / "_completion.bash"
    else:
        return  # Unsupported shell, skip silently

    # Generate completion script
    try:
        result = subprocess.run(
            ["evercoast"],
            env={**os.environ, env_var.split("=")[0]: env_var.split("=")[1]},
            capture_output=True, text=True, timeout=5,
        )
        if result.returncode != 0 or not result.stdout.strip():
            return
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return

    completion_file.write_text(result.stdout)

    # Add source line to rc file if not already present
    source_line = f'{_COMPLETION_MARKER}\n[[ -f "{completion_file}" ]] && source "{completion_file}"\n'

    if rc_file.exists():
        rc_content = rc_file.read_text()
        if _COMPLETION_MARKER in rc_content:
            return  # Already installed
    else:
        rc_content = ""

    with open(rc_file, "a") as f:
        f.write(f"\n{source_line}")


@cli.command()
@click.option("--staging", is_flag=True, hidden=True)
def login(staging):
    """Authenticate with Evercoast and configure upload credentials.

    Run this once to set up your machine for uploads. You'll be prompted
    for your Evercoast email and password. Credentials are saved locally
    and refresh automatically — you only need to re-run this if you
    change your Evercoast password.

    \b
    What happens during login:
      1. Authenticates with your Evercoast account
      2. Retrieves your company's S3 bucket configuration
      3. Saves credentials to ~/.evercoast/config.toml
      4. Optionally configures an AWS CLI profile (if AWS CLI is installed)

    \b
    Requirements:
      • An active Evercoast account
      • S3 direct upload enabled for your company (contact Evercoast support)

    \b
    The AWS CLI profile is a bonus — it lets you use standard AWS tools
    (like 'aws s3 cp') with your Evercoast bucket if you prefer. The
    Evercoast CLI itself does not require the AWS CLI.
    """
    config = Config()
    api_url = STAGING_API_URL if staging else PRODUCTION_API_URL
    profile_name = config.get_profile_name(staging)

    console.print()
    console.print("[bold cyan]Evercoast Upload — Authentication[/]")
    console.print("=" * 50)
    console.print()

    # Prompt for credentials
    email = click.prompt("Evercoast Email")
    if not email.strip():
        console.print("[red]Error: Email cannot be empty[/]")
        sys.exit(1)

    password = click.prompt("Evercoast Password", hide_input=True)
    if not password:
        console.print("[red]Error: Password cannot be empty[/]")
        sys.exit(1)

    console.print()
    console.print("[cyan]Authenticating...[/]")

    # Login
    try:
        from .api import login as api_login
        token = api_login(api_url, email, password)
    except APIError as e:
        console.print(f"[red]Error: {e}[/]")
        sys.exit(1)

    console.print("[green]Authentication successful![/]")
    console.print()
    console.print("[cyan]Fetching S3 upload credentials...[/]")

    # Get S3 credentials (also validates the token and gets bucket info)
    try:
        s3_data = fetch_s3_credentials(api_url, token)
    except APIError as e:
        console.print(f"[red]Error: {e}[/]")
        sys.exit(1)

    bucket = s3_data["bucket"]
    region = s3_data.get("region", "us-east-1")
    upload_path = s3_data.get("upload_path", "client-uploads/")

    # Save config
    config.save_profile(
        profile=profile_name,
        api_url=api_url,
        token=token,
        bucket=bucket,
        region=region,
        upload_path=upload_path,
    )

    console.print("[green]Credentials retrieved successfully![/]")
    console.print()
    console.print("=" * 50)
    console.print(f"  Bucket:      {bucket}")
    console.print(f"  Region:      {region}")
    console.print(f"  Upload Path: {upload_path}")
    console.print("=" * 50)
    console.print()

    # Set up AWS CLI profile as a bonus
    aws_profile = f"evercoast-{profile_name}" if profile_name != "default" else "evercoast"
    profile_ok = setup_aws_cli_profile(api_url, token, region, aws_profile)

    if profile_ok:
        console.print(
            f"[green]AWS CLI profile '{aws_profile}' configured with auto-refreshing credentials.[/]"
        )
        console.print(
            f"  You can also use: aws s3 cp <file> s3://{bucket}/{upload_path} --profile {aws_profile}"
        )
        console.print()

    # Install shell tab-completion
    _install_shell_completion()

    console.print("[bold]You're all set! Upload files with:[/]")
    console.print("  evercoast upload <path>")
    console.print()


@cli.command()
@click.argument("path", type=click.Path(exists=True))
@click.option(
    "--type", "data_type",
    type=click.Choice(["takes", "renders", "other"], case_sensitive=False),
    help="Data type that determines the upload destination. "
         "'takes' routes to client-uploads/takes/<name>/, "
         "'renders' routes to client-uploads/renders/<name>/, "
         "'other' routes to client-uploads/<name>/. "
         "If omitted, you will be prompted to choose interactively.",
)
@click.option(
    "--to", "custom_dest",
    help="Custom destination path within your upload area. "
         "Overrides --type routing. For example, --to my/custom/path "
         "uploads to client-uploads/my/custom/path/.",
)
@click.option("--staging", is_flag=True, hidden=True)
@click.option(
    "--dry-run", is_flag=True,
    help="Preview what would be uploaded without actually uploading. "
         "Shows a file-by-file list with sizes and destinations.",
)
@click.option(
    "--no-checksum", is_flag=True,
    help="Disable SHA256 checksum validation. By default, checksums are "
         "calculated locally and verified server-side to ensure data "
         "integrity. Only disable this if uploads are unusually slow.",
)
@click.option(
    "--exclude", multiple=True,
    help="Exclude files matching a glob pattern. Can be specified multiple "
         "times. Examples: --exclude '*.tmp' --exclude '.DS_Store'",
)
@click.option(
    "--yes", "-y", is_flag=True,
    help="Skip the confirmation prompt for large uploads (>1 GB).",
)
def upload(path, data_type, custom_dest, staging, dry_run, no_checksum, exclude, yes):
    """Upload files or directories to your company's S3 bucket.

    PATH can be a single file or a directory. When uploading a directory,
    all files within it (including subdirectories) are uploaded, preserving
    the folder structure.

    \b
    Resumable uploads:
      Directories are synced by comparing local files against what already
      exists at the destination. If an upload is interrupted (Ctrl+C,
      network drop, laptop sleep), simply re-run the same command — only
      the remaining files will be uploaded. Already-uploaded files are
      skipped automatically based on filename and size matching.

    \b
    Data types and routing:
      --type takes      →  client-uploads/takes/<folder-name>/
      --type renders    →  client-uploads/renders/<folder-name>/
      --type other      →  client-uploads/<folder-name>/
      --to custom/path  →  client-uploads/custom/path/

    \b
    Network resilience:
      If the network drops during an upload, the CLI will:
        1. Detect the failure
        2. Wait for connectivity to return
        3. Retry with increasing delays (up to 5 min between attempts)
      Retries continue indefinitely until the upload succeeds or you
      cancel with Ctrl+C. If you cancel, re-run the same command to
      resume — already-uploaded files will be skipped.

    \b
    Examples:
      evercoast upload ./session-42/ --type takes
      evercoast upload ./meshes/ --type renders
      evercoast upload capture.zip --type other
      evercoast upload ./data/ --to custom/path
      evercoast upload ./data/ --dry-run --exclude "*.tmp"
      evercoast upload ./large-dataset/ --type takes --yes
    """
    config = Config()
    profile_name = config.get_profile_name(staging)
    profile = config.get_profile(profile_name)

    # Pre-flight: check config exists
    if not profile:
        console.print(
            "[red]Error: Not configured. Run 'evercoast login' first.[/]"
        )
        sys.exit(1)

    api_url = profile["api_url"]
    token = profile["token"]
    bucket = profile["bucket"]
    region = profile["region"]
    upload_path = profile.get("upload_path", "client-uploads/")

    # Pre-flight: check source path
    source_path = os.path.abspath(path)
    is_dir = os.path.isdir(source_path)

    # Data type selection
    if custom_dest:
        # --to overrides --type, use "other" as placeholder
        data_type = "other"
    elif data_type is None:
        data_type = _prompt_data_type(config, profile_name)

    # Resolve destination
    destination = resolve_destination(
        data_type=data_type,
        source_path=source_path,
        upload_path=upload_path,
        is_dir=is_dir,
        custom_dest=custom_dest,
    )

    # Build upload plan
    use_checksum = not no_checksum
    exclude_list = list(exclude) if exclude else None

    if is_dir:
        console.print("[cyan]Scanning local files...[/]")
        local_files = walk_local_files(source_path, exclude_list)

        if not local_files:
            console.print("[yellow]No files found to upload.[/]")
            sys.exit(0)

        console.print("[cyan]Comparing with remote...[/]")

        try:
            s3_client = get_s3_client(api_url, token, region)
            remote_files = get_remote_files(s3_client, bucket, destination)
        except APIError as e:
            console.print(f"[red]Error: {e}[/]")
            sys.exit(1)

        to_upload, skipped = compute_upload_plan(source_path, remote_files, exclude_list)
    else:
        # Single file upload
        filename = os.path.basename(source_path)
        file_size = os.path.getsize(source_path)

        try:
            s3_client = get_s3_client(api_url, token, region)
            # Check if file already exists remotely
            remote_files = get_remote_files(s3_client, bucket, destination)
        except APIError as e:
            console.print(f"[red]Error: {e}[/]")
            sys.exit(1)

        # For single files, destination is the full key (not a prefix)
        # Check if already uploaded
        if filename in remote_files and remote_files[filename] == file_size:
            to_upload = []
            skipped = 1
        else:
            to_upload = [(source_path, filename, file_size)]
            skipped = 0

        # Adjust destination to be a prefix for display
        if not destination.endswith("/"):
            destination = destination.rsplit("/", 1)[0] + "/" if "/" in destination else ""

    # Nothing to upload
    if not to_upload:
        console.print()
        console.print(
            f"[green]Nothing to upload — all {skipped} files already exist at destination.[/]"
        )
        console.print(f"  Destination: s3://{bucket}/{destination}")
        console.print()
        sys.exit(0)

    # Print summary
    print_upload_summary(
        source=source_path,
        destination=destination,
        bucket=bucket,
        to_upload=to_upload,
        skipped=skipped,
        use_checksum=use_checksum,
        dry_run=dry_run,
    )

    # Dry run — show details and exit
    if dry_run:
        print_dry_run_details(to_upload, destination, skipped)
        sys.exit(0)

    # Confirmation for large uploads
    total_size = sum(size for _, _, size in to_upload)
    if not yes and total_size > 1024 * 1024 * 1024:  # > 1 GB
        if not click.confirm(
            f"This is a large upload ({format_size(total_size)}). Continue?",
            default=True,
        ):
            console.print("[yellow]Upload cancelled.[/]")
            sys.exit(0)

    # Execute upload
    success = upload_files(
        s3_client=s3_client,
        bucket=bucket,
        destination=destination,
        to_upload=to_upload,
        use_checksum=use_checksum,
    )

    # Save last-used data type
    if success and data_type:
        config.set_value(profile_name, "last_type", data_type)

    sys.exit(0 if success else 1)


def _prompt_data_type(config: Config, profile_name: str) -> str:
    """Prompt user to select data type, showing last-used as default."""
    last_type = config.get_value(profile_name, "last_type")

    # Map last_type to default index
    type_order = ["takes", "renders", "other"]
    default_idx = 1  # default to "takes"
    if last_type in type_order:
        default_idx = type_order.index(last_type) + 1

    console.print()
    console.print("[bold]What type of data are you uploading?[/]")
    console.print()
    console.print(f"  1) {TYPE_LABELS['takes']}")
    console.print(f"  2) {TYPE_LABELS['renders']}")
    console.print(f"  3) {TYPE_LABELS['other']}")
    console.print()

    while True:
        choice = click.prompt(
            f"Select [1-3]",
            default=str(default_idx),
            show_default=True,
        )
        try:
            idx = int(choice)
            if 1 <= idx <= 3:
                return type_order[idx - 1]
        except ValueError:
            pass
        console.print("[red]Please enter 1, 2, or 3[/]")
