"""Config file management for Evercoast CLI.

Stores authentication tokens, bucket info, and user preferences
in ~/.evercoast/config.toml with per-profile sections.
"""

import os
import platform
import re
import stat
from pathlib import Path
from typing import Any, Dict, Optional


# API URLs
PRODUCTION_API_URL = "https://api.cloudbreak.evercoast.com/api/v1"
STAGING_API_URL = "https://api.staging.cloudbreak.evercoast.com/api/v1"

DEFAULT_PROFILE = "default"
STAGING_PROFILE = "staging"


def get_config_dir() -> Path:
    """Return the config directory path (~/.evercoast/)."""
    return Path.home() / ".evercoast"


def get_config_path() -> Path:
    """Return the config file path (~/.evercoast/config.toml)."""
    return get_config_dir() / "config.toml"


def _parse_toml(text: str) -> Dict[str, Dict[str, str]]:
    """Parse a simple TOML file into nested dicts.

    Only supports [section] headers and key = "value" pairs.
    No nested tables, arrays, or complex types.
    """
    result: Dict[str, Dict[str, str]] = {}
    current_section = None

    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue

        # Section header
        section_match = re.match(r"^\[([^\]]+)\]$", line)
        if section_match:
            current_section = section_match.group(1).strip()
            result[current_section] = {}
            continue

        # Key = value pair
        kv_match = re.match(r'^(\w+)\s*=\s*"((?:[^"\\]|\\.)*)"$', line)
        if kv_match and current_section is not None:
            key = kv_match.group(1)
            value = kv_match.group(2).replace('\\"', '"').replace("\\\\", "\\")
            result[current_section][key] = value

    return result


def _serialize_toml(data: Dict[str, Dict[str, str]]) -> str:
    """Serialize nested dicts to simple TOML format."""
    lines = []
    for i, (section, values) in enumerate(data.items()):
        if i > 0:
            lines.append("")
        lines.append(f"[{section}]")
        for key, value in values.items():
            escaped = value.replace("\\", "\\\\").replace('"', '\\"')
            lines.append(f'{key} = "{escaped}"')
    lines.append("")  # trailing newline
    return "\n".join(lines)


class Config:
    """Manages the Evercoast CLI config file."""

    def __init__(self, config_path: Optional[Path] = None):
        self.path = config_path or get_config_path()
        self._data: Dict[str, Dict[str, str]] = {}
        self._load()

    def _load(self):
        """Load config from disk if it exists."""
        if self.path.exists():
            text = self.path.read_text(encoding="utf-8")
            self._data = _parse_toml(text)

    def _save(self):
        """Write config to disk with restricted permissions."""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(_serialize_toml(self._data), encoding="utf-8")
        # Restrict permissions on Unix (owner read/write only)
        if platform.system() != "Windows":
            self.path.chmod(stat.S_IRUSR | stat.S_IWUSR)

    def save_profile(
        self,
        profile: str,
        api_url: str,
        token: str,
        bucket: str,
        region: str,
        upload_path: str = "client-uploads/",
    ):
        """Save a profile with all connection details."""
        self._data[profile] = {
            "api_url": api_url,
            "token": token,
            "bucket": bucket,
            "region": region,
            "upload_path": upload_path,
        }
        self._save()

    def get_profile(self, profile: str) -> Optional[Dict[str, str]]:
        """Get a profile's config, or None if it doesn't exist."""
        return self._data.get(profile)

    def has_profile(self, profile: str) -> bool:
        """Check if a profile exists."""
        return profile in self._data

    def get_value(self, profile: str, key: str) -> Optional[str]:
        """Get a single value from a profile."""
        p = self._data.get(profile)
        if p is None:
            return None
        return p.get(key)

    def set_value(self, profile: str, key: str, value: str):
        """Set a single value in a profile (profile must exist)."""
        if profile not in self._data:
            self._data[profile] = {}
        self._data[profile][key] = value
        self._save()

    def get_profile_name(self, staging: bool) -> str:
        """Return the profile name based on staging flag."""
        return STAGING_PROFILE if staging else DEFAULT_PROFILE

    def get_api_url(self, staging: bool) -> str:
        """Return the API URL for the given environment."""
        profile = self.get_profile_name(staging)
        p = self.get_profile(profile)
        if p and "api_url" in p:
            return p["api_url"]
        return STAGING_API_URL if staging else PRODUCTION_API_URL
