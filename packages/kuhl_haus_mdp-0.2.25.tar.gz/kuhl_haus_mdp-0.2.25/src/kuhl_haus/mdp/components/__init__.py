"""Components for market data ingestion and processing.

Provides the core pipeline components including WebSocket listeners, data
processors, queue management, market data caching and scanning, and widget
data services for the Massive.com market data stream.
"""
