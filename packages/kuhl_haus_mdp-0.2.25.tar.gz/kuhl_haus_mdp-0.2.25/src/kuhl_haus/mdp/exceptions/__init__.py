"""Custom exceptions for the market data processing pipeline.

Defines exception types raised during real-time analysis and processing of
WebSocket data from the Massive.com API, preserving failure context for
debugging without crashing listener loops.
"""
