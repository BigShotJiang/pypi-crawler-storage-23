from __future__ import annotations

import os
import sys
import httpx
from dotenv import load_dotenv
from mcp.server.fastmcp import FastMCP
from mcp.types import TextContent, ToolAnnotations

from obris_mcp import routes
from obris_mcp.decorators import APIError, handle_api_errors

load_dotenv()

mcp = FastMCP("obris")
API_BASE = os.environ.get("OBRIS_API_URL", "https://api.obris.ai")
API_KEY = os.environ.get("OBRIS_API_KEY", "")

SOURCE_PARAM = "source"
SOURCE_MCP = "mcp"


async def api_request(path: str, params: dict = None) -> dict:
    async with httpx.AsyncClient() as client:
        resp = await client.get(
            f"{API_BASE}{path}",
            params=params,
            headers={"X-API-Key": API_KEY},
            timeout=30.0,
        )
        if resp.status_code == 401:
            raise APIError(
                "Invalid or missing API key. "
                "Ensure OBRIS_API_KEY is set in your environment."
            )
        if resp.status_code == 403:
            raise APIError(
                "Access denied. "
                "Your API key doesn't have permission for this resource."
            )
        resp.raise_for_status()
        return resp.json()


@mcp.tool(annotations=ToolAnnotations(title="List Projects", readOnlyHint=True, openWorldHint=True))
@handle_api_errors
async def list_projects() -> list[TextContent]:
    """List all projects available to the current user.
    Call this to help the user identify which project they want to work within.
    """
    data = await api_request(routes.projects())
    projects = data.get("results", [])
    if not projects:
        return [TextContent(type="text", text="No projects found.")]
    results = []
    for p in projects:
        ref_count = p.get("reference_count", 0)
        desc = f"\n  Description: {p['description']}" if p.get("description") else ""
        results.append(
            f"**{p['name']}**{desc}\n"
            f"- ID: {p['id']}\n"
            f"- Reference Count: {ref_count}"
        )
    return [TextContent(type="text", text="\n\n".join(results))]


@mcp.tool(annotations=ToolAnnotations(title="Get Project References", readOnlyHint=True, openWorldHint=True))
@handle_api_errors
async def get_project_references(project_id: str, cursor: str | None = None, client_hint: str | None = None) -> list[TextContent]:
    """Get saved references for a specific project.
    Call list_projects first to get the project ID.

    Small references include their full content inline. Larger references
    and file uploads include a summary and a file URL — download the file
    to access the full content.

    If has_more is true, call again with the returned cursor to get the next page.

    Args:
        project_id: The project ID (from list_projects).
        cursor: Pagination cursor from a previous call (omit for first page).
        client_hint: Optional. If you know your client, pass it to optimize
            response size. Known values: "claude-code", "claude",
            "chatgpt", "gemini". Omit if unsure.
    """
    params = {SOURCE_PARAM: SOURCE_MCP}
    if client_hint:
        params["client_hint"] = client_hint
    if cursor:
        params["cursor"] = cursor
    data = await api_request(routes.project_references(project_id), params=params)

    items = data.get("items", [])
    if not items:
        return [TextContent(type="text", text="No references found for this project.")]

    blocks = []
    has_files = any(ref.get("file_url") for ref in items)

    # Emit download instructions at the top of the first page only.
    if has_files and not cursor:
        blocks.append(TextContent(
            type="text",
            text=(
                "INSTRUCTIONS: You MUST download file URLs below to reference their content in the conversation. "
                "Use a tool like curl to download files, as web fetch tools may not accept MCP-provided URLs. "
                "If a download fails or isn't appearing in the UI, the user may need to allow the file hosting domain."
            ),
        ))

    for ref in items:
        parts = [f"### {ref['title']} (id: {ref['id']})"]
        if ref.get("file_url"):
            if ref.get("summary"):
                parts.append(ref["summary"])
            parts.append(f"File: {ref['file_url']}")
        elif ref.get("content"):
            parts.append(ref["content"])
        if ref.get("url"):
            parts.append(f"(source: {ref['url']})")
        blocks.append(TextContent(type="text", text="\n".join(parts)))

    if data.get("has_more"):
        shown = data.get("shown", len(items))
        total = data.get("total")
        progress = f"Shown {shown} of {total}. " if total else ""
        blocks.append(TextContent(
            type="text",
            text=f'{progress}Call again with cursor="{data["next_cursor"]}" to get the next page.',
        ))

    return blocks


def main():
    print("Obris MCP server running on stdio", file=sys.stderr)
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
