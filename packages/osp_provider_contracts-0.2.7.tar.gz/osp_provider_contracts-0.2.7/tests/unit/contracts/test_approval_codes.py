from osp_provider_contracts import GateReason


def test_gate_reason_surface_is_stable() -> None:
    assert GateReason.LIMITS_EXCEEDED.value == "limits_exceeded"
    assert GateReason.ACCESS_DENIED.value == "access_denied"
    assert GateReason.EXCEPTION_REQUIRED.value == "exception_required"
    assert GateReason.DESTRUCTIVE_ACTION.value == "destructive_action"
    assert GateReason.RESOURCE_CONFLICT.value == "resource_conflict"
