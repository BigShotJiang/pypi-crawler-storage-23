"""
nvnodetop Python package.

This package ships the ``nvnodetop.sh`` Bash script and exposes it as a
``nvnodetop`` console-script entry point via a thin Python launcher.
"""
