"""Custom ExhaustiveCategoricalSampler for exhaustive categorical search space exploration.

Extends Optuna's BruteForceSampler to:
1. Enforce categorical-only parameters (reject Float/Int distributions)
2. Raise SearchSpaceExhausted instead of silently duplicating combinations
3. Track total_combinations for operator-side excess Pod prevention
"""

from functools import reduce
from operator import mul
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Sequence

from optuna.distributions import BaseDistribution, CategoricalDistribution
from optuna.trial import FrozenTrial, TrialState

# Optuna internal API dependency (tested with optuna 4.x)
# These are private APIs that may change without notice in future Optuna versions.
try:
    from optuna.samplers._brute_force import BruteForceSampler, _enumerate_candidates, _TreeNode
except ImportError as e:
    raise ImportError(
        "ExhaustiveCategoricalSampler requires Optuna internal API "
        "(_brute_force._TreeNode, _enumerate_candidates). "
        f"Current Optuna version may not be compatible: {e}"
    ) from e

if TYPE_CHECKING:
    from optuna.study import Study


class SearchSpaceExhausted(Exception):  # noqa: N818
    """Raised when all categorical combinations have been exhausted."""

    pass


class ExhaustiveCategoricalSampler(BruteForceSampler):
    """Sampler that exhaustively explores all categorical parameter combinations exactly once.

    Unlike BruteForceSampler which falls back to random sampling when combinations
    are exhausted, this sampler raises SearchSpaceExhausted to prevent wasted trials.

    Args:
        search_space: Dict mapping parameter names to lists of categorical values.
            Example: {"x": ["a", "b"], "y": [True, False]}
        seed: Random seed for sampling order. Not recommended for distributed settings.
    """

    def __init__(
        self,
        search_space: Dict[str, List[Any]],
        seed: Optional[int] = None,
    ) -> None:
        if not search_space:
            raise ValueError("search_space must not be empty")
        empty_params = [k for k, v in search_space.items() if not v]
        if empty_params:
            raise ValueError(
                f"search_space has parameters with empty candidate lists: {empty_params}"
            )
        super().__init__(seed=seed)
        self._search_space = search_space
        self.total_combinations = reduce(mul, (len(v) for v in search_space.values()), 1)

    def sample_independent(
        self,
        study: "Study",
        trial: FrozenTrial,
        name: str,
        param_distribution: BaseDistribution,
    ) -> Any:
        # Categorical-only 강제: non-CategoricalDistribution이면 거부
        if not isinstance(param_distribution, CategoricalDistribution):
            raise ValueError(
                f"ExhaustiveCategoricalSampler only supports CategoricalDistribution, "
                f"got {type(param_distribution).__name__} for parameter '{name}'"
            )

        # BruteForceSampler와 동일한 방식으로 tree를 구성하여 조합 소진 여부 확인
        # (_brute_force.py:200-227 로직 재현)
        exclude_running = not self._avoid_premature_stop

        trials = study._storage.get_all_trials(
            study._study_id,
            deepcopy=False,
            states=(
                TrialState.COMPLETE,
                TrialState.PRUNED,
                TrialState.RUNNING,
                TrialState.FAIL,
            ),
        )
        tree = _TreeNode()
        candidates = _enumerate_candidates(param_distribution)
        tree.expand(name, candidates)
        self._populate_tree(tree, (t for t in trials if t.number != trial.number), trial.params)

        if tree.count_unexpanded(exclude_running) == 0:
            raise SearchSpaceExhausted("All categorical combinations have been exhausted")

        # 조합이 남아있으면 BruteForceSampler의 정상 샘플링 실행
        return param_distribution.to_external_repr(
            tree.sample_child(self._rng.rng, exclude_running)
        )

    def after_trial(
        self,
        study: "Study",
        trial: FrozenTrial,
        state: TrialState,
        values: Optional[Sequence[float]],
    ) -> None:
        # BruteForceSampler의 after_trial 유지 (조합 소진 시 study.stop() 호출)
        super().after_trial(study, trial, state, values)
