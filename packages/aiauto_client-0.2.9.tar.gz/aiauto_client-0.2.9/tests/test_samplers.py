#!/usr/bin/env python
"""
Optuna Sampler 직렬화/역직렬화 테스트

주요 Optuna Sampler가 올바르게 직렬화되고 복원되는지 검증합니다.
Callable 타입 파라미터(gamma, weights 등)는 직렬화에서 제외됨을 확인합니다.
"""

import json
import os
import sys

import optuna
import pytest

# Add parent directory to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../../runners"))

from runner_create_study import SAMPLER_WHITELIST
from runner_trial import EXIT_CODE_EXHAUSTED
from runner_trial import SAMPLER_WHITELIST as TRIAL_RUNNER_SAMPLER_WHITELIST

from aiauto.sampler import ExhaustiveCategoricalSampler, SearchSpaceExhausted
from aiauto.serializer import from_json, object_to_json


def test_random_sampler():
    """RandomSampler 테스트 - seed 파라미터"""
    sampler = optuna.samplers.RandomSampler(seed=42)
    json_str = object_to_json(sampler)

    parsed = json.loads(json_str)
    assert parsed["cls"] == "RandomSampler"
    # seed는 저장되지만 다른 형태로 저장될 수 있음
    if "seed" in parsed["kwargs"]:
        assert parsed["kwargs"]["seed"] == 42

    restored = from_json(json_str, SAMPLER_WHITELIST)
    assert type(restored).__name__ == "RandomSampler"


def test_tpe_sampler():
    """TPESampler 테스트 - 주요 파라미터"""
    sampler = optuna.samplers.TPESampler(
        n_startup_trials=5,
        n_ei_candidates=10,
        seed=42,
        multivariate=True,
        warn_independent_sampling=False,
    )
    json_str = object_to_json(sampler)

    parsed = json.loads(json_str)
    assert parsed["cls"] == "TPESampler"
    assert parsed["kwargs"]["n_startup_trials"] == 5
    assert parsed["kwargs"]["n_ei_candidates"] == 10
    assert parsed["kwargs"]["multivariate"] == True
    assert parsed["kwargs"]["warn_independent_sampling"] == False
    if "seed" in parsed["kwargs"]:
        assert parsed["kwargs"]["seed"] == 42

    # Callable 파라미터들(gamma, weights)은 제외되어야 함
    assert "gamma" not in parsed["kwargs"]
    assert "weights" not in parsed["kwargs"]

    restored = from_json(json_str, SAMPLER_WHITELIST)
    assert type(restored).__name__ == "TPESampler"
    assert restored._n_startup_trials == 5
    assert restored._n_ei_candidates == 10
    if hasattr(restored, "_seed"):
        assert restored._seed == 42


def test_tpe_sampler_default():
    """TPESampler 테스트 - 기본값"""
    sampler = optuna.samplers.TPESampler()
    json_str = object_to_json(sampler)

    parsed = json.loads(json_str)
    assert parsed["cls"] == "TPESampler"

    # 기본값들이 올바르게 직렬화되는지 확인
    assert "n_startup_trials" in parsed["kwargs"]
    assert "n_ei_candidates" in parsed["kwargs"]

    restored = from_json(json_str, SAMPLER_WHITELIST)
    assert type(restored).__name__ == "TPESampler"


def test_nsgaii_sampler():
    """NSGAIISampler 테스트 - 다목적 최적화용"""
    sampler = optuna.samplers.NSGAIISampler(
        population_size=10, mutation_prob=0.1, crossover_prob=0.8, swapping_prob=0.4, seed=42
    )
    json_str = object_to_json(sampler)

    parsed = json.loads(json_str)
    assert parsed["cls"] == "NSGAIISampler"
    assert parsed["kwargs"]["population_size"] == 10
    if "mutation_prob" in parsed["kwargs"]:
        assert parsed["kwargs"]["mutation_prob"] == 0.1
    if "crossover_prob" in parsed["kwargs"]:
        assert parsed["kwargs"]["crossover_prob"] == 0.8
    if "swapping_prob" in parsed["kwargs"]:
        assert parsed["kwargs"]["swapping_prob"] == 0.4
    if "seed" in parsed["kwargs"]:
        assert parsed["kwargs"]["seed"] == 42

    # Callable 파라미터들은 제외되거나 null이어야 함
    assert parsed["kwargs"].get("constraints_func") is None
    assert "elite_population_selection_strategy" not in parsed["kwargs"]

    restored = from_json(json_str, SAMPLER_WHITELIST)
    assert type(restored).__name__ == "NSGAIISampler"
    assert restored._population_size == 10
    if hasattr(restored, "_seed"):
        assert restored._seed == 42


def test_grid_sampler():
    """GridSampler 테스트 - search_space 파라미터"""
    search_space = {"x": [-10, -5, 0, 5, 10], "y": [1, 2, 3]}
    sampler = optuna.samplers.GridSampler(search_space=search_space)
    json_str = object_to_json(sampler)

    parsed = json.loads(json_str)
    assert parsed["cls"] == "GridSampler"
    assert parsed["kwargs"]["search_space"] == search_space

    restored = from_json(json_str, SAMPLER_WHITELIST)
    assert type(restored).__name__ == "GridSampler"
    assert restored._search_space == search_space


def test_bruteforce_sampler():
    """BruteForceSampler 테스트"""
    sampler = optuna.samplers.BruteForceSampler(seed=42)
    json_str = object_to_json(sampler)

    parsed = json.loads(json_str)
    assert parsed["cls"] == "BruteForceSampler"
    if "seed" in parsed["kwargs"]:
        assert parsed["kwargs"]["seed"] == 42

    restored = from_json(json_str, SAMPLER_WHITELIST)
    assert type(restored).__name__ == "BruteForceSampler"
    if hasattr(restored, "_seed"):
        assert restored._seed == 42


def test_cmaes_sampler():
    """CmaEsSampler 테스트"""
    sampler = optuna.samplers.CmaEsSampler(n_startup_trials=5, seed=42)
    json_str = object_to_json(sampler)

    parsed = json.loads(json_str)
    assert parsed["cls"] == "CmaEsSampler"
    assert parsed["kwargs"]["n_startup_trials"] == 5
    if "seed" in parsed["kwargs"]:
        assert parsed["kwargs"]["seed"] == 42
    # restart_strategy는 deprecated되어 저장되지 않음

    restored = from_json(json_str, SAMPLER_WHITELIST)
    assert type(restored).__name__ == "CmaEsSampler"
    assert restored._n_startup_trials == 5
    if hasattr(restored, "_seed"):
        assert restored._seed == 42


def test_qmc_sampler():
    """QMCSampler 테스트"""
    sampler = optuna.samplers.QMCSampler(qmc_type="sobol", scramble=True, seed=42)
    json_str = object_to_json(sampler)

    parsed = json.loads(json_str)
    assert parsed["cls"] == "QMCSampler"
    assert parsed["kwargs"]["qmc_type"] == "sobol"
    assert parsed["kwargs"]["scramble"] == True
    if "seed" in parsed["kwargs"]:
        assert parsed["kwargs"]["seed"] == 42

    restored = from_json(json_str, SAMPLER_WHITELIST)
    assert type(restored).__name__ == "QMCSampler"
    assert restored._qmc_type == "sobol"
    assert restored._scramble == True
    if hasattr(restored, "_seed"):
        assert restored._seed == 42


def test_runner_trial_exit_code_exhausted_is_3():
    """runner_trial.EXIT_CODE_EXHAUSTED는 반드시 3이어야 한다.

    operator는 exit code 3을 "search space 소진"으로 해석한다.
    이 값이 바뀌면 operator의 trial 상태 분류가 깨지므로 계약 보호 테스트다.
    """
    assert EXIT_CODE_EXHAUSTED == 3


def test_runner_trial_sampler_whitelist_includes_exhaustive_categorical():
    """runner_trial.SAMPLER_WHITELIST에 ExhaustiveCategoricalSampler가 포함되어야 한다.

    SAMPLER_JSON 환경변수로 ExhaustiveCategoricalSampler가 전달될 때
    runner_trial이 역직렬화할 수 있어야 한다.
    whitelist에서 제외되면 from_json()이 ValueError를 raise하여 trial이 실패한다.
    """
    assert "ExhaustiveCategoricalSampler" in TRIAL_RUNNER_SAMPLER_WHITELIST
    assert (
        TRIAL_RUNNER_SAMPLER_WHITELIST["ExhaustiveCategoricalSampler"]
        is ExhaustiveCategoricalSampler
    )


def test_exhaustive_categorical_sampler():
    """ExhaustiveCategoricalSampler 직렬화/역직렬화 테스트."""
    search_space = {"x": ["a", "b"], "y": [True, False]}
    sampler = ExhaustiveCategoricalSampler(search_space=search_space)
    json_str = object_to_json(sampler)

    parsed = json.loads(json_str)
    assert parsed["cls"] == "ExhaustiveCategoricalSampler"
    assert parsed["kwargs"]["search_space"] == search_space

    restored = from_json(json_str, SAMPLER_WHITELIST)
    assert type(restored).__name__ == "ExhaustiveCategoricalSampler"
    assert restored._search_space == search_space
    assert restored.total_combinations == 4


def test_exhaustive_categorical_sampler_total_combinations():
    """total_combinations 계산 정확성 검증."""
    # 2 x 3 = 6
    sampler = ExhaustiveCategoricalSampler({"a": [1, 2], "b": ["x", "y", "z"]})
    assert sampler.total_combinations == 6

    # 단일 파라미터
    sampler2 = ExhaustiveCategoricalSampler({"color": ["red", "blue", "green"]})
    assert sampler2.total_combinations == 3

    # 단일 값
    sampler3 = ExhaustiveCategoricalSampler({"flag": [True]})
    assert sampler3.total_combinations == 1


def test_exhaustive_categorical_sampler_empty_search_space_raises():
    """빈 search_space는 ValueError를 raise해야 한다.

    sampler 초기화 시 search_space가 비어 있으면 total_combinations 계산이
    의미 없고, 어떤 trial도 실행할 수 없는 상태이므로 즉시 실패해야 한다.
    """
    with pytest.raises(ValueError):
        ExhaustiveCategoricalSampler({})


def test_exhaustive_categorical_sampler_empty_candidates_raises():
    """빈 후보 목록이 포함된 search_space는 ValueError를 raise해야 한다.

    {"x": []} 처럼 파라미터 키는 있지만 후보 값이 없는 경우,
    total_combinations=0이 되어 의미 없는 sampler가 생성된다.
    BruteForceSampler.sample_independent에서 나중에 실패하는 것보다
    초기화 시점에 명확한 에러 메시지를 주는 것이 사용자 디버깅에 유리하다.
    """
    with pytest.raises(ValueError, match="empty candidate lists"):
        ExhaustiveCategoricalSampler({"x": []})

    with pytest.raises(ValueError, match="empty candidate lists"):
        ExhaustiveCategoricalSampler({"x": ["a", "b"], "y": []})


def test_exhaustive_categorical_sampler_rejects_non_categorical():
    """sample_independent는 CategoricalDistribution 외 타입을 거부해야 한다.

    ExhaustiveCategoricalSampler는 categorical-only sampler이므로
    FloatDistribution/IntDistribution 파라미터가 들어오면 ValueError를 raise한다.
    이 경로가 실제로 동작하는지 in-memory study를 통해 검증한다.
    """
    from optuna.distributions import FloatDistribution

    sampler = ExhaustiveCategoricalSampler({"x": ["a", "b"]})
    study = optuna.create_study(sampler=sampler, storage=None)
    trial = study.ask()

    # FrozenTrial을 얻기 위해 ask 결과를 storage에서 조회
    frozen = study._storage.get_trial(trial._trial_id)

    with pytest.raises(ValueError, match="CategoricalDistribution"):
        sampler.sample_independent(study, frozen, "y", FloatDistribution(0.0, 1.0))


def test_exhaustive_categorical_sampler_raises_search_space_exhausted():
    """모든 조합이 소진되면 SearchSpaceExhausted를 raise해야 한다.

    search_space {"x": ["a", "b"]}로 study를 생성하고
    첫 번째 trial에서 "a"를 사용한 뒤,
    두 번째 trial의 sample_independent 호출 시 "a"는 이미 사용됐으므로
    남은 조합이 있어서 정상 동작한다.
    두 trial 모두 완료된 뒤 세 번째 trial의 sample_independent 호출에서
    SearchSpaceExhausted가 발생해야 한다.

    study.tell()은 after_trial을 트리거하여 study.stop()을 호출하므로
    storage를 직접 조작하여 trial을 COMPLETE 상태로 만든다.
    """
    from optuna.distributions import CategoricalDistribution
    from optuna.trial import TrialState

    sampler = ExhaustiveCategoricalSampler({"x": ["a", "b"]})
    study = optuna.create_study(sampler=sampler, storage=None)

    dist = CategoricalDistribution(["a", "b"])

    # trial 0: ask -> storage에서 직접 COMPLETE 처리 (after_trial 호출 없이)
    # study.tell()은 after_trial을 트리거하고 BruteForceSampler.after_trial이
    # study.stop()을 호출하므로 storage API를 직접 사용한다
    trial0 = study.ask()
    study._storage.set_trial_param(trial0._trial_id, "x", dist.to_internal_repr("a"), dist)
    study._storage.set_trial_state_values(trial0._trial_id, TrialState.COMPLETE, [0.5])

    # trial 1: ask -> storage에서 직접 COMPLETE 처리
    trial1 = study.ask()
    study._storage.set_trial_param(trial1._trial_id, "x", dist.to_internal_repr("b"), dist)
    study._storage.set_trial_state_values(trial1._trial_id, TrialState.COMPLETE, [0.3])

    # trial 2: 모든 조합(a, b)이 소진된 상태에서 sample_independent 호출
    trial2 = study.ask()
    frozen2 = study._storage.get_trial(trial2._trial_id)

    with pytest.raises(SearchSpaceExhausted):
        sampler.sample_independent(study, frozen2, "x", CategoricalDistribution(["a", "b"]))


def test_exhaustive_categorical_sampler_sample_independent_returns_valid_value():
    """sample_independent는 조합이 남아있을 때 valid한 값을 반환해야 한다.

    search_space {"x": ["a", "b"]}에서 아직 아무 trial도 없을 때
    sample_independent가 "a" 또는 "b" 중 하나를 반환하는지 검증한다.
    이 테스트는 SearchSpaceExhausted 경로가 아닌 정상 샘플링 경로를 커버한다.
    """
    from optuna.distributions import CategoricalDistribution

    sampler = ExhaustiveCategoricalSampler({"x": ["a", "b"]})
    study = optuna.create_study(sampler=sampler, storage=None)

    trial = study.ask()
    frozen = study._storage.get_trial(trial._trial_id)

    result = sampler.sample_independent(study, frozen, "x", CategoricalDistribution(["a", "b"]))
    assert result in ["a", "b"], f"Expected 'a' or 'b', got {result!r}"


def test_exhaustive_categorical_sampler_after_trial_delegates_to_super():
    """after_trial은 BruteForceSampler.after_trial에 위임해야 한다.

    BruteForceSampler.after_trial은 모든 조합이 소진되면 study.stop()을 호출한다.
    ExhaustiveCategoricalSampler.after_trial이 super()를 올바르게 호출하는지
    study.optimize()를 통해 검증한다.

    study.optimize()로 단일 조합({"x": ["a"]})을 실행하면 after_trial에서
    BruteForceSampler가 study.stop()을 호출하여 n_trials 관계없이 루프가 종료된다.
    결과적으로 trials가 정확히 1개만 생성됐다면 stop()이 호출된 것이다.

    주의: sample_independent에서 SearchSpaceExhausted를 먼저 raise하기 때문에
    실제 운영에서는 after_trial의 study.stop()이 도달하지 않을 수 있지만,
    위임 계약 자체가 깨지지 않았는지 확인한다.
    """
    sampler = ExhaustiveCategoricalSampler({"x": ["a"]})  # 단일 조합
    study = optuna.create_study(sampler=sampler, storage=None)

    # study.optimize()를 통해 after_trial 트리거
    # n_trials=100이지만 after_trial에서 study.stop()이 호출되어 1회만 실행된다
    def objective(trial):
        trial.suggest_categorical("x", ["a"])
        return 0.5

    study.optimize(objective, n_trials=100)

    # BruteForceSampler.after_trial이 study.stop()을 호출했다면 trials=1이어야 한다
    assert len(study.trials) == 1, (
        f"Expected 1 trial (study.stop() called by after_trial), got {len(study.trials)}"
    )


if __name__ == "__main__":
    # 각 테스트 실행
    test_runner_trial_exit_code_exhausted_is_3()
    print("✅ EXIT_CODE_EXHAUSTED contract test passed")

    test_runner_trial_sampler_whitelist_includes_exhaustive_categorical()
    print("✅ SAMPLER_WHITELIST ExhaustiveCategoricalSampler inclusion test passed")

    test_random_sampler()
    print("✅ RandomSampler test passed")

    test_tpe_sampler()
    print("✅ TPESampler test passed")

    test_tpe_sampler_default()
    print("✅ TPESampler (default) test passed")

    test_nsgaii_sampler()
    print("✅ NSGAIISampler test passed")

    test_grid_sampler()
    print("✅ GridSampler test passed")

    test_bruteforce_sampler()
    print("✅ BruteForceSampler test passed")

    test_cmaes_sampler()
    print("✅ CmaEsSampler test passed")

    test_qmc_sampler()
    print("✅ QMCSampler test passed")

    test_exhaustive_categorical_sampler()
    print("✅ ExhaustiveCategoricalSampler test passed")

    test_exhaustive_categorical_sampler_total_combinations()
    print("✅ ExhaustiveCategoricalSampler total_combinations test passed")

    test_exhaustive_categorical_sampler_empty_search_space_raises()
    print("✅ ExhaustiveCategoricalSampler empty search_space test passed")

    test_exhaustive_categorical_sampler_rejects_non_categorical()
    print("✅ ExhaustiveCategoricalSampler non-categorical rejection test passed")

    test_exhaustive_categorical_sampler_raises_search_space_exhausted()
    print("✅ ExhaustiveCategoricalSampler SearchSpaceExhausted test passed")

    test_exhaustive_categorical_sampler_sample_independent_returns_valid_value()
    print("✅ ExhaustiveCategoricalSampler sample_independent normal path test passed")

    test_exhaustive_categorical_sampler_after_trial_delegates_to_super()
    print("✅ ExhaustiveCategoricalSampler after_trial delegation test passed")

    print("\n✅ All Sampler tests passed!")
