# mcpzoo-countdown

> 日期计算 — 计算两个日期之间的天数差或加减天数

## Installation

```bash
uvx mcpzoo-countdown
```

## uvx JSON

```json
{
  "mcpServers": {
    "countdown": {
      "args": ["mcpzoo-countdown"],
      "command": "uvx"
    }
  }
}
```
