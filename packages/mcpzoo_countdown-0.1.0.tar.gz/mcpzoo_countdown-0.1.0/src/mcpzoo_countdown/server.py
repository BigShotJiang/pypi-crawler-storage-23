import datetime
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("countdown")


@mcp.tool()
def date_diff(date_a: str, date_b: str, fmt: str = "%Y-%m-%d") -> str:
    """计算两个日期之间的天数差。"""
    try:
        da = datetime.datetime.strptime(date_a, fmt)
        db = datetime.datetime.strptime(date_b, fmt)
        delta = db - da
        return f"相差 {delta.days} 天"
    except Exception as e:
        return f"计算错误: {e}"

@mcp.tool()
def date_add(date: str, days: int, fmt: str = "%Y-%m-%d") -> str:
    """日期加减天数。"""
    try:
        d = datetime.datetime.strptime(date, fmt)
        res = d + datetime.timedelta(days=days)
        return res.strftime(fmt)
    except Exception as e:
        return f"计算错误: {e}"


def main():
    mcp.run()


if __name__ == "__main__":
    main()
