﻿# YouTube MCP (youtube_mcp)

A **Model Context Protocol (MCP)** server that provides **production-grade YouTube inventory tools** (channel resolution, channel videos, channel playlists, playlist videos) designed to be **safe-by-default**, quota-aware, and AI-friendly.

Repository: https://github.com/glonorce/youtube_mcp

> Naming note:
> - Repo name: `youtube_mcp`
> - Python package / import name: `youtube_mcp`
> - MCP entry module: `python -m youtube_mcp.server`

---

## Attribution / Project lineage

This repository started from the open-source MCP server published by:
- Original repo: https://github.com/sinjab/mcp_youtube_extract

The original project demonstrated a minimal MCP server (single tool) for video metadata + transcript.
This repo extends it substantially with:
- multiple structured-output inventory tools,
- strict channel resolution,
- quota budgeting,
- ordering strategies,
- security hardening (SSRF guardrails + redaction),
- improved test isolation.

---

## Tools

This server exposes **5 tools**:

1) `get_yt_video_info(video_id) -> str` (legacy)
2) `resolve_youtube_channel(channel_ref, ...) -> dict`
3) `list_youtube_channel_videos(channel_ref, ...) -> dict`
4) `list_youtube_channel_playlists(channel_ref, ...) -> dict`
5) `list_youtube_playlist_videos(playlist_id, ...) -> dict`

All inventory tools return **structured JSON** and are documented with AI-friendly docstrings.

---

## Installation options

### Option 1 (recommended): install from source (git clone)

Use this when you want to develop, change code, or ensure you're always running the latest from this repo.

### Option 2: install from PyPI / TestPyPI (no local clone)

This repo is published as the Python distribution:
- **`glonorce-youtube-mcp`** (distribution name)

After installation, you run it via:
- `youtube_mcp` (CLI command)
- or `python -m youtube_mcp.server`

> Note: A different package named `mcp-youtube-extract` exists on PyPI (upstream/minimal). It is **not** this project.

---

## Installation (from source / local clone)

```bash
# 1) Clone
git clone https://github.com/glonorce/youtube_mcp.git
cd youtube_mcp

# 2) Create a venv
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate

# 3) Install editable (IMPORTANT)
python -m pip install -e .
```

## Installation (no local clone)

### TestPyPI (recommended first)

```bash
python -m pip install -i https://test.pypi.org/simple/ glonorce-youtube-mcp

# run
youtube_mcp
# or
python -m youtube_mcp.server
```

### PyPI (after you confirm on TestPyPI)

```bash
python -m pip install glonorce-youtube-mcp
```


---

## Configuration

### Environment variable

Inventory tools require a YouTube Data API v3 key:

```bash
YOUTUBE_API_KEY=your_youtube_api_key_here
```

### Getting Your YouTube API Key

You need a YouTube Data API v3 key for inventory tools. Typical setup:

1. Create a Google Cloud Project: https://console.cloud.google.com/
2. Enable **YouTube Data API v3** (APIs & Services → Library)
3. Create an API key (APIs & Services → Credentials)
4. Restrict the key to **YouTube Data API v3** (recommended)

Quota/billing notes:
- YouTube Data API uses a quota model (commonly **10,000 units/day** free quota)
- Google may require billing depending on your account/project configuration

Security best practices:
- never commit API keys
- prefer host environment variables / secret managers

---

## Run locally

```bash
python -m youtube_mcp.server
```

---

## Cursor / AI IDE MCP config

### A) Local clone (Windows example)

This is the most reliable configuration for development because it runs your local venv Python.

Create: `.cursor/mcp.json`

```json
{
  "mcpServers": {
    "youtube_mcp": {
      "command": "C:\\Users\\<YOU>\\youtube_mcp\\.venv\\Scripts\\python.exe",
      "args": ["-m", "youtube_mcp.server"],
      "env": {
        "YOUTUBE_API_KEY": "YOUR_KEY"
      }
    }
  }
}
```

Notes:
- Replace paths with your actual locations.
- Avoid putting API keys directly into JSON if possible.
- Many MCP hosts **do not interpolate** placeholders like `${YOUTUBE_API_KEY}` inside `mcp.json`.

### B) No local clone (installed from PyPI/TestPyPI)

If you installed `glonorce-youtube-mcp` via pip, you can point the MCP host directly to the installed CLI.

**Recommended (don’t hardcode keys in JSON):** set `YOUTUBE_API_KEY` in your OS environment, then keep `env` empty/minimal in `mcp.json`.

Example:

```json
{
  "mcpServers": {
    "youtube_mcp": {
      "command": "youtube_mcp",
      "env": {
        "YOUTUBE_API_KEY": "YOUR_KEY"
      }
    }
  }
}
```

Notes:
- Some MCP hosts may not expand placeholders like `${YOUTUBE_API_KEY}` inside JSON.
- Prefer setting `YOUTUBE_API_KEY` in your OS environment (or a secret manager) instead of hardcoding.

### C) Local clone (uv)

If you prefer `uv`, you can run the server from a cloned repo like this:

```json
{
  "mcpServers": {
    "youtube_mcp": {
      "command": "uv",
      "args": ["--directory", ".", "run", "python", "-m", "youtube_mcp.server"],
      "env": {
        "YOUTUBE_API_KEY": "YOUR_KEY"
      }
    }
  }
}
```

(For this to work you must set `cwd` to your repo root in your MCP host settings, or launch the MCP host from the repo directory.)

---

## Example MCP calls (JSON payloads)

> Exact envelope depends on your MCP client; these show `tool` + `arguments`.

### Resolve a channel

```json
{
  "tool": "resolve_youtube_channel",
  "arguments": {
    "channel_ref": "@GoogleDevelopers",
    "resolution_mode": "strict",
    "include_uploads_playlist": true
  }
}
```

### List channel videos (safe default)

```json
{
  "tool": "list_youtube_channel_videos",
  "arguments": {
    "channel_ref": "@GoogleDevelopers",
    "max_videos": 50,
    "page_token": null,
    "include_shorts": false,
    "include_live": false,
    "parts_level": "basic",
    "order_strategy": "uploads_playlist",
    "order_by": "date"
  }
}
```

---

## Quota reference (best-effort)

> This section is a **best-effort** summary and may change over time.
> Always verify with official documentation.

**Last verified:** 2026-02-18

Official references:
- YouTube Data API quota calculator / costs: https://developers.google.com/youtube/v3/determine_quota_cost
- Usage limits: https://developers.google.com/youtube/v3/getting-started#quota

### Approximate quota usage by tool

| Tool | Primary endpoints | Typical cost (rough) | Notes |
|---|---|---:|---|
| `resolve_youtube_channel` | `channels.list` | ~1 | strict mode mostly `channels.list`; best_effort may use `search.list` |
| `list_youtube_channel_videos` (default) | `channels.list` + `playlistItems.list` + `videos.list` | ~ (1 + 1 + 1) per page | page size up to 50 IDs for `videos.list` |
| `list_youtube_channel_videos` (`order_strategy=search_api`) | `search.list` + `videos.list` | ~ (100 + 1) per page | expensive; capped behavior |
| `list_youtube_channel_playlists` | `playlists.list` | ~1 per page | public playlists only |
| `list_youtube_playlist_videos` | `playlistItems.list` + `videos.list` | ~ (1 + 1) per page | public playlist |

Daily quota:
- Common free quota: **10,000 units/day**
- Reset: daily (Google-defined; see official docs/console)

---

## Troubleshooting

### Only `get_yt_video_info` is visible (other tools missing)

Your MCP host is running an **old installed copy** from `site-packages`.
Fix:

```bash
python -m pip install -e .
```

Then restart the MCP host.

### `${YOUTUBE_API_KEY}` works only when hardcoded

Some MCP hosts do not interpolate env placeholders inside `mcp.json`.
If you set:

```json
"env": { "YOUTUBE_API_KEY": "${YOUTUBE_API_KEY}" }
```

â€¦the server may literally receive `${YOUTUBE_API_KEY}`.
Workarounds:
- set `YOUTUBE_API_KEY` in the host process environment
- use a wrapper script to load `.env` then start the server
- or paste the key directly in MCP config

---

## License

MIT â€” see [LICENSE](LICENSE)
