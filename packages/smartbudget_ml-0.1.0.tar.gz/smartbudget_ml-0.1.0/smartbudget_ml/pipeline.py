"""
High-level pipeline: load models from disk, run predictions.

Accepts plain Python dicts/lists (no FastAPI dependency).
"""

from decimal import Decimal
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from smartbudget_ml.features import extract_features
from smartbudget_ml.models import BudgetAllocationModel, RiskAssessmentModel


def _decimal(val: Any) -> Decimal:
    if isinstance(val, Decimal):
        return val
    return Decimal(str(val))


def _sum_income(user_incomes: List[Dict[str, Any]]) -> Decimal:
    total = Decimal("0")
    for inc in user_incomes:
        if inc.get("is_active", True):
            total += _decimal(inc.get("amount", 0))
    return total


def _sum_expenses(transactions: List[Dict[str, Any]]) -> Decimal:
    total = Decimal("0")
    for t in transactions:
        if t.get("transaction_type") == "expense":
            total += _decimal(t.get("amount", 0))
    return total


def _category_spending(transactions: List[Dict[str, Any]]) -> Dict[str, Decimal]:
    out: Dict[str, Decimal] = {}
    for t in transactions:
        if t.get("transaction_type") != "expense":
            continue
        cat = t.get("category", "other")
        out[cat] = out.get(cat, Decimal("0")) + _decimal(t.get("amount", 0))
    return out


def _total_liability_payments(liabilities: List[Dict[str, Any]]) -> Decimal:
    total = Decimal("0")
    for l in liabilities:
        if not l.get("is_active", True):
            continue
        pmt = l.get("minimum_payment")
        if pmt is not None:
            total += _decimal(pmt)
    return total


def _has_high_interest_debt(liabilities: List[Dict[str, Any]]) -> bool:
    for l in liabilities:
        if not l.get("is_active", True):
            continue
        rate = l.get("interest_rate")
        if rate is not None and _decimal(rate) > Decimal("15"):
            return True
    return False


class BudgetModelPipeline:
    """
    Loaded model pipeline: budget allocation + risk level.

    Use load_model(path) to create, then call predict(...).
    """

    def __init__(self, models_dir: Union[str, Path]):
        self.models_dir = Path(models_dir)
        self.budget_model: Optional[BudgetAllocationModel] = None
        self.risk_model: Optional[RiskAssessmentModel] = None
        self._load()

    def _load(self) -> None:
        bp = self.models_dir / "budget_allocation_model.pkl"
        rp = self.models_dir / "risk_assessment_model.pkl"
        if bp.exists():
            try:
                self.budget_model = BudgetAllocationModel()
                self.budget_model.load(str(bp))
            except Exception:
                self.budget_model = None
        if rp.exists():
            try:
                self.risk_model = RiskAssessmentModel()
                self.risk_model.load(str(rp))
            except Exception:
                self.risk_model = None

    @property
    def has_models(self) -> bool:
        return (
            self.budget_model is not None
            and self.budget_model.is_trained
            and self.risk_model is not None
            and self.risk_model.is_trained
        )

    def predict(
        self,
        transactions: List[Dict[str, Any]],
        liabilities: List[Dict[str, Any]],
        user_incomes: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        total_income = _sum_income(user_incomes)
        total_expenses = _sum_expenses(transactions)
        total_liabilities = _total_liability_payments(liabilities)
        category_spending = _category_spending(transactions)
        num_transactions = len(transactions)
        has_high = _has_high_interest_debt(liabilities)

        if not category_spending:
            category_spending = {"other": Decimal("0")}

        # Budget allocation (per category)
        if self.budget_model and self.budget_model.is_trained:
            allocations: Dict[str, Decimal] = {}
            for category, spent in category_spending.items():
                feats = extract_features(
                    total_income=total_income,
                    total_expenses=total_expenses,
                    total_liabilities=Decimal("0"),
                    category_spending={category: spent},
                    num_transactions=1,
                    has_high_interest_debt=False,
                )
                pred = float(self.budget_model.predict(feats.reshape(1, -1))[0])
                allocations[category] = Decimal(str(max(0.0, pred)))
        else:
            # Simple fallback if no trained model exists.
            allocations = {cat: spent * Decimal("1.1") for cat, spent in category_spending.items()}

        category_budgets = []
        for category, allocated in allocations.items():
            pct = (allocated / total_income * 100) if total_income > 0 else Decimal("0")
            category_budgets.append(
                {
                    "category": category,
                    "allocated_amount": float(allocated),
                    "percentage_of_income": float(pct),
                    "reasoning": "ML-recommended allocation"
                    if self.budget_model and self.budget_model.is_trained
                    else "Rule-based allocation",
                }
            )

        # Risk level
        if self.risk_model and self.risk_model.is_trained:
            feats = extract_features(
                total_income=total_income,
                total_expenses=total_expenses,
                total_liabilities=total_liabilities,
                category_spending=category_spending,
                num_transactions=num_transactions,
                has_high_interest_debt=has_high,
            )
            risk_level = str(self.risk_model.predict(feats.reshape(1, -1))[0])
        else:
            total_obligations = total_expenses + total_liabilities
            if total_income == 0:
                risk_level = "high"
            else:
                ratio = float(total_obligations / total_income)
                if ratio > 0.9:
                    risk_level = "high"
                elif ratio > 0.7:
                    risk_level = "medium"
                else:
                    risk_level = "low"

        return {
            "category_budgets": category_budgets,
            "risk_level": risk_level,
            "total_monthly_income": float(total_income),
            "total_monthly_expenses": float(total_expenses),
            "total_liability_payments": float(total_liabilities),
        }

    def get_insights(self) -> Dict[str, Any]:
        out: Dict[str, Any] = {
            "budget_model_available": (
                self.budget_model is not None and self.budget_model.is_trained
            ),
            "risk_model_available": (
                self.risk_model is not None and self.risk_model.is_trained
            ),
        }
        if self.budget_model and self.budget_model.is_trained:
            out["budget_feature_importance"] = self.budget_model.get_feature_importance()
        if self.risk_model and self.risk_model.is_trained:
            out["risk_feature_importance"] = self.risk_model.get_feature_importance()
        return out


def load_model(models_dir: Union[str, Path] = "models") -> BudgetModelPipeline:
    return BudgetModelPipeline(models_dir)


def predict(
    model_or_path: Union[BudgetModelPipeline, str, Path],
    transactions: List[Dict[str, Any]],
    liabilities: List[Dict[str, Any]],
    user_incomes: List[Dict[str, Any]],
) -> Dict[str, Any]:
    if isinstance(model_or_path, BudgetModelPipeline):
        pipeline = model_or_path
    else:
        pipeline = load_model(model_or_path)
    return pipeline.predict(
        transactions=transactions,
        liabilities=liabilities,
        user_incomes=user_incomes,
    )
