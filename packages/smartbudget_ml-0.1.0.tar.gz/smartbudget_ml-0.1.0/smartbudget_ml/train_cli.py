"""
CLI entry point for training:

    smartbudget-train --output-dir models --samples 1000
    python -m smartbudget_ml.train_cli -o models -n 1000
"""

import argparse
from pathlib import Path

from smartbudget_ml.train import generate_synthetic_data, train


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Train SmartBudget ML models (budget allocation + risk)."
    )
    parser.add_argument(
        "--output-dir",
        "-o",
        type=Path,
        default=Path("models"),
        help="Directory to save .pkl models (default: models)",
    )
    parser.add_argument(
        "--samples",
        "-n",
        type=int,
        default=1000,
        help="Number of synthetic samples if not providing data (default: 1000)",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Random seed for synthetic data (default: 42)",
    )
    args = parser.parse_args()

    print("SmartBudget ML - Training")
    print("=" * 50)
    print(f"Generating {args.samples} synthetic samples...")
    X, y_budget, y_risk = generate_synthetic_data(n_samples=args.samples, seed=args.seed)
    print(f"Features: {X.shape[1]}, Samples: {len(X)}")
    print(f"Output dir: {args.output_dir}")
    train(X, y_budget, y_risk, output_dir=args.output_dir)
    print("Done. Models saved to", args.output_dir)


if __name__ == "__main__":
    main()

"""
CLI entry point for training: smartbudget-train or python -m smartbudget_ml.train_cli
"""

import argparse
from pathlib import Path

from smartbudget_ml.train import train, generate_synthetic_data


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Train SmartBudget ML models (budget allocation + risk)."
    )
    parser.add_argument(
        "--output-dir",
        "-o",
        type=Path,
        default=Path("models"),
        help="Directory to save .pkl models (default: models)",
    )
    parser.add_argument(
        "--samples",
        "-n",
        type=int,
        default=1000,
        help="Number of synthetic samples if not providing data (default: 1000)",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Random seed for synthetic data (default: 42)",
    )
    args = parser.parse_args()

    print("SmartBudget ML - Training")
    print("=" * 50)
    print(f"Generating {args.samples} synthetic samples...")
    X, y_budget, y_risk = generate_synthetic_data(
        n_samples=args.samples, seed=args.seed
    )
    print(f"Features: {X.shape[1]}, Samples: {len(X)}")
    print(f"Output dir: {args.output_dir}")
    train(X, y_budget, y_risk, output_dir=args.output_dir)
    print("Done. Models saved to", args.output_dir)


if __name__ == "__main__":
    main()
