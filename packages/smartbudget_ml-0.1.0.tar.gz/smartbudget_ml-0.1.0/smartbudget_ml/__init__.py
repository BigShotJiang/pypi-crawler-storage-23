"""
SmartBudget ML - Budget planning and risk assessment model package.

Library-first: import and use from Python code.
"""

from smartbudget_ml.features import extract_features, FEATURE_NAMES
from smartbudget_ml.models import BudgetAllocationModel, RiskAssessmentModel
from smartbudget_ml.pipeline import BudgetModelPipeline, load_model, predict
from smartbudget_ml.train import generate_synthetic_data, train

__version__ = "0.1.0"

__all__ = [
    "load_model",
    "predict",
    "train",
    "generate_synthetic_data",
    "extract_features",
    "FEATURE_NAMES",
    "BudgetAllocationModel",
    "RiskAssessmentModel",
    "BudgetModelPipeline",
]

"""
SmartBudget ML - Budget planning and risk assessment model package.

Use as a Python package (not an API repo):

    pip install -e .
    from smartbudget_ml import load_model, predict, train

Or train and save models:

    from smartbudget_ml import train, generate_synthetic_data
    X, y_budget, y_risk = generate_synthetic_data(n_samples=1000)
    train(X, y_budget, y_risk, output_dir="models/")
"""

from smartbudget_ml.features import extract_features, FEATURE_NAMES
from smartbudget_ml.models import BudgetAllocationModel, RiskAssessmentModel
from smartbudget_ml.pipeline import load_model, predict, BudgetModelPipeline
from smartbudget_ml.train import train, generate_synthetic_data

__version__ = "0.1.0"
__all__ = [
    "load_model",
    "predict",
    "train",
    "extract_features",
    "FEATURE_NAMES",
    "BudgetAllocationModel",
    "RiskAssessmentModel",
    "BudgetModelPipeline",
    "generate_synthetic_data",
]
