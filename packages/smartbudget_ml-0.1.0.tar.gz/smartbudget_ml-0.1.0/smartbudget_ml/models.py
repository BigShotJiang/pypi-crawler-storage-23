"""
Scikit-learn models for budget allocation and risk assessment.
"""

import joblib
import numpy as np
from typing import Dict, List, Optional

from sklearn.linear_model import Ridge, LogisticRegression
from sklearn.preprocessing import StandardScaler


class BudgetAllocationModel:
    """
    Predicts a recommended budget amount (regression).

    This is intentionally kept simple (linear model) so it:
    - trains fast on small datasets
    - is easy to explain/debug
    - is less likely to overfit than large tree ensembles
    """

    def __init__(self):
        self.model: Optional[Ridge] = None
        self.scaler: Optional[StandardScaler] = None
        self.feature_names: List[str] = []
        self.is_trained = False

    def train(
        self,
        X: np.ndarray,
        y: np.ndarray,
        feature_names: List[str],
    ) -> None:
        self.feature_names = feature_names
        self.scaler = StandardScaler()
        X_scaled = self.scaler.fit_transform(X)
        # Ridge regression is a simple, stable default for small/noisy data.
        # Keep constructor args minimal for broad scikit-learn compatibility.
        self.model = Ridge(alpha=1.0)
        self.model.fit(X_scaled, y)
        self.is_trained = True

    def predict(self, X: np.ndarray) -> np.ndarray:
        if not self.is_trained:
            raise ValueError("Model not trained. Call train() first.")
        X_scaled = self.scaler.transform(X)
        return self.model.predict(X_scaled)

    def get_feature_importance(self) -> Dict[str, float]:
        if not self.is_trained:
            return {}
        # For linear models, coefficients indicate importance direction/magnitude.
        # We expose absolute magnitude for a simple "importance" score.
        coef = getattr(self.model, "coef_", None)
        if coef is None:
            return {}
        coef = np.asarray(coef, dtype=float).reshape(-1)
        return dict(zip(self.feature_names, np.abs(coef)))

    def save(self, filepath: str) -> None:
        if not self.is_trained:
            raise ValueError("Model not trained. Cannot save.")
        joblib.dump(
            {
                "model": self.model,
                "scaler": self.scaler,
                "feature_names": self.feature_names,
            },
            filepath,
        )

    def load(self, filepath: str) -> None:
        data = joblib.load(filepath)
        self.model = data["model"]
        self.scaler = data["scaler"]
        self.feature_names = data["feature_names"]
        self.is_trained = True


class RiskAssessmentModel:
    """Predicts risk level: low, medium, high."""

    def __init__(self):
        self.model: Optional[LogisticRegression] = None
        self.scaler: Optional[StandardScaler] = None
        self.feature_names: List[str] = []
        self.is_trained = False
        self.classes_ = ["low", "medium", "high"]

    def train(
        self,
        X: np.ndarray,
        y: np.ndarray,
        feature_names: List[str],
    ) -> None:
        self.feature_names = feature_names
        self.scaler = StandardScaler()
        X_scaled = self.scaler.fit_transform(X)
        # Logistic regression is a simple baseline classifier.
        # Keep constructor args minimal for broad scikit-learn compatibility.
        self.model = LogisticRegression(max_iter=2000)
        self.model.fit(X_scaled, y)
        self.is_trained = True

    def predict(self, X: np.ndarray) -> np.ndarray:
        if not self.is_trained:
            raise ValueError("Model not trained. Call train() first.")
        X_scaled = self.scaler.transform(X)
        return self.model.predict(X_scaled)

    def get_feature_importance(self) -> Dict[str, float]:
        if not self.is_trained:
            return {}
        # For multinomial logistic regression, coef_ is (n_classes, n_features).
        coef = getattr(self.model, "coef_", None)
        if coef is None:
            return {}
        coef = np.asarray(coef, dtype=float)
        # Aggregate importance across classes.
        scores = np.mean(np.abs(coef), axis=0)
        return dict(zip(self.feature_names, scores))

    def save(self, filepath: str) -> None:
        if not self.is_trained:
            raise ValueError("Model not trained. Cannot save.")
        joblib.dump(
            {
                "model": self.model,
                "scaler": self.scaler,
                "feature_names": self.feature_names,
                "classes": self.classes_,
            },
            filepath,
        )

    def load(self, filepath: str) -> None:
        data = joblib.load(filepath)
        self.model = data["model"]
        self.scaler = data["scaler"]
        self.feature_names = data["feature_names"]
        self.classes_ = data.get("classes", self.classes_)
        self.is_trained = True
