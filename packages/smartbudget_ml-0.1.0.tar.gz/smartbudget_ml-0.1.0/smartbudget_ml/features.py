"""
Feature extraction for SmartBudget ML models.

This module converts raw financial inputs into a fixed-length numeric vector.
"""

from decimal import Decimal
from typing import Dict, List

import numpy as np

FEATURE_NAMES: List[str] = [
    "total_income",
    "total_expenses",
    "total_liabilities",
    "expense_ratio",
    "debt_ratio",
    "savings_ratio",
    "num_transactions",
    "has_high_interest_debt",
    "num_categories",
    "max_category_ratio",
]


def extract_features(
    total_income: Decimal,
    total_expenses: Decimal,
    total_liabilities: Decimal,
    category_spending: Dict[str, Decimal],
    num_transactions: int,
    has_high_interest_debt: bool,
) -> np.ndarray:
    """
    Extract a (10,) feature vector for budget/risk models.
    """
    total_income_f = float(total_income)
    total_expenses_f = float(total_expenses)
    total_liabilities_f = float(total_liabilities)

    expense_ratio = total_expenses_f / total_income_f if total_income_f > 0 else 0.0
    debt_ratio = (
        total_liabilities_f / total_income_f if total_income_f > 0 else 0.0
    )
    savings_ratio = (
        (total_income_f - total_expenses_f - total_liabilities_f) / total_income_f
        if total_income_f > 0
        else 0.0
    )
    max_cat = (
        float(max(category_spending.values())) / total_expenses_f
        if total_expenses_f > 0 and category_spending
        else 0.0
    )

    return np.array(
        [
            total_income_f,
            total_expenses_f,
            total_liabilities_f,
            expense_ratio,
            debt_ratio,
            savings_ratio,
            float(num_transactions),
            1.0 if has_high_interest_debt else 0.0,
            float(len(category_spending)),
            max_cat,
        ],
        dtype=np.float64,
    )

"""
Feature extraction for budget ML models.

Used for both training and inference. Produces a fixed-length vector
from financial inputs.
"""

import numpy as np
from decimal import Decimal
from typing import Dict, List

FEATURE_NAMES: List[str] = [
    "total_income",
    "total_expenses",
    "total_liabilities",
    "expense_ratio",
    "debt_ratio",
    "savings_ratio",
    "num_transactions",
    "has_high_interest_debt",
    "num_categories",
    "max_category_ratio",
]


def extract_features(
    total_income: Decimal,
    total_expenses: Decimal,
    total_liabilities: Decimal,
    category_spending: Dict[str, Decimal],
    num_transactions: int,
    has_high_interest_debt: bool,
) -> np.ndarray:
    """
    Extract feature vector for ML models.

    Returns:
        Shape (10,) array for budget/risk models.
    """
    total_income_f = float(total_income)
    total_expenses_f = float(total_expenses)
    total_liabilities_f = float(total_liabilities)

    expense_ratio = (
        total_expenses_f / total_income_f if total_income_f > 0 else 0.0
    )
    debt_ratio = (
        total_liabilities_f / total_income_f if total_income_f > 0 else 0.0
    )
    savings_ratio = (
        (total_income_f - total_expenses_f - total_liabilities_f)
        / total_income_f
        if total_income_f > 0
        else 0.0
    )
    max_cat = (
        float(max(category_spending.values())) / total_expenses_f
        if total_expenses_f > 0 and category_spending
        else 0.0
    )

    return np.array(
        [
            total_income_f,
            total_expenses_f,
            total_liabilities_f,
            expense_ratio,
            debt_ratio,
            savings_ratio,
            num_transactions,
            1.0 if has_high_interest_debt else 0.0,
            len(category_spending),
            max_cat,
        ],
        dtype=np.float64,
    )
