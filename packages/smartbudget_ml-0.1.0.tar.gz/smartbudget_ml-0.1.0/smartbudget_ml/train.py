"""
Training API and synthetic data generation.
"""

from decimal import Decimal
from pathlib import Path
from typing import Tuple, Union

import numpy as np
from sklearn.model_selection import train_test_split

from smartbudget_ml.features import FEATURE_NAMES, extract_features
from smartbudget_ml.models import BudgetAllocationModel, RiskAssessmentModel


def generate_synthetic_data(
    n_samples: int = 1000,
    seed: int = 42,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Generate synthetic (X, y_budget, y_risk) for demos.
    """
    rng = np.random.default_rng(seed)
    total_incomes = rng.uniform(20000, 200000, n_samples)
    expense_ratios = rng.uniform(0.4, 0.9, n_samples)
    total_expenses = total_incomes * expense_ratios
    debt_ratios = rng.uniform(0, 0.5, n_samples)
    total_liabilities = total_incomes * debt_ratios
    num_transactions = rng.integers(10, 100, n_samples)
    has_high = rng.choice([0, 1], n_samples, p=[0.7, 0.3])

    X = []
    y_budget = []
    y_risk = []

    for i in range(n_samples):
        category_spending = {
            "food": Decimal(str(total_expenses[i] * 0.2)),
            "rent": Decimal(str(total_expenses[i] * 0.4)),
            "utilities": Decimal(str(total_expenses[i] * 0.1)),
        }
        feats = extract_features(
            total_income=Decimal(str(total_incomes[i])),
            total_expenses=Decimal(str(total_expenses[i])),
            total_liabilities=Decimal(str(total_liabilities[i])),
            category_spending=category_spending,
            num_transactions=int(num_transactions[i]),
            has_high_interest_debt=bool(has_high[i]),
        )
        X.append(feats)

        # Simple target: "recommended budget" as a fraction of income.
        y_budget.append(total_incomes[i] * 0.2)

        obligation_ratio = (total_expenses[i] + total_liabilities[i]) / total_incomes[i]
        if obligation_ratio > 0.9:
            y_risk.append("high")
        elif obligation_ratio > 0.7:
            y_risk.append("medium")
        else:
            y_risk.append("low")

    return np.array(X), np.array(y_budget), np.array(y_risk)


def train(
    X: np.ndarray,
    y_budget: np.ndarray,
    y_risk: np.ndarray,
    output_dir: Union[str, Path],
    test_size: float = 0.2,
    random_state: int = 42,
) -> Tuple[BudgetAllocationModel, RiskAssessmentModel]:
    """
    Train budget and risk models and save to output_dir.
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # Budget model
    X_train, _, yb_train, _ = train_test_split(
        X, y_budget, test_size=test_size, random_state=random_state
    )
    budget_model = BudgetAllocationModel()
    budget_model.train(X_train, yb_train, FEATURE_NAMES)
    budget_model.save(str(output_dir / "budget_allocation_model.pkl"))

    # Risk model
    X_train_r, _, yr_train, _ = train_test_split(
        X,
        y_risk,
        test_size=test_size,
        random_state=random_state,
        stratify=y_risk if len(set(y_risk.tolist())) > 1 else None,
    )
    risk_model = RiskAssessmentModel()
    risk_model.train(X_train_r, yr_train, FEATURE_NAMES)
    risk_model.save(str(output_dir / "risk_assessment_model.pkl"))

    return budget_model, risk_model
