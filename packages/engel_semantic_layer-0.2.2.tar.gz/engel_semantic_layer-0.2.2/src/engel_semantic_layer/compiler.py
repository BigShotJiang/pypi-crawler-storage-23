from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date
from typing import Iterable

from .models import CompiledQuery, CrossModuleMetric, Filter, Metric, Module, QueryRequest
from .schema_registry import ColumnRegistry


class CompilationError(ValueError):
    pass


_TIME_GRAIN_SQL = {
    "daily": "DATE_TRUNC(DATE({col}), DAY)",
    "weekly": "DATE_TRUNC(DATE({col}), WEEK(MONDAY))",
    "monthly": "DATE_TRUNC(DATE({col}), MONTH)",
    "quarterly": "DATE_TRUNC(DATE({col}), QUARTER)",
    "yearly": "DATE_TRUNC(DATE({col}), YEAR)",
}

_OPERATOR_SQL = {
    "equals": "=",
    "not-equals": "!=",
    "less-than": "<",
    "less-than-or-equal": "<=",
    "greater-than": ">",
    "greater-than-or-equal": ">=",
    "in": "IN",
    "not-in": "NOT IN",
    "is": "IS",
    "is-not": "IS NOT",
    "like": "LIKE",
    "not-like": "NOT LIKE",
}

_TIME_COMPARISON_INTERVAL_SQL = {
    "yoy": "INTERVAL 1 YEAR",
    "mom": "INTERVAL 1 MONTH",
    "last-year": "INTERVAL 1 YEAR",
    "last-month": "INTERVAL 1 MONTH",
    "yoy-match-weekday": "INTERVAL 364 DAY",
}

_DEFAULT_TARGET_PROJECT = "demo-project-123456"
_DEFAULT_TARGET_SCHEMA = "analytics_prod"
_DEFAULT_TARGET_TABLE = "fct_targets_monthly"


def _bq_quote_identifier(identifier: str) -> str:
    # BigQuery expects project.dataset.table (or ...column) wrapped as one identifier
    # when project IDs include hyphens.
    return f"`{identifier}`"


def _bq_table_ref(schema: str, table: str, project: str | None = None) -> str:
    if project:
        return _bq_quote_identifier(f"{project}.{schema}.{table}")
    return _bq_quote_identifier(f"{schema}.{table}")


def _bq_column_ref(schema: str, table: str, column: str, project: str | None = None) -> str:
    # BigQuery column refs should be `<project.dataset.table>`.`column`
    return f"{_bq_table_ref(schema, table, project)}.`{column}`"


def _bq_string(value: str) -> str:
    return "'" + value.replace("'", "\\'") + "'"


def _iso_date(value: str) -> str:
    # Accepts ISO timestamps (e.g. 2026-01-01T00:00:00Z) and plain YYYY-MM-DD.
    return value.split("T", 1)[0]


def _parse_iso_date(value: str) -> date:
    return date.fromisoformat(_iso_date(value))


def _month_last_day(year: int, month: int) -> int:
    if month == 2:
        leap = year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)
        return 29 if leap else 28
    if month in {4, 6, 9, 11}:
        return 30
    return 31


def _month_start(d: date) -> date:
    return date(d.year, d.month, 1)


def _quarter_start(d: date) -> date:
    q_start_month = ((d.month - 1) // 3) * 3 + 1
    return date(d.year, q_start_month, 1)


def _year_start(d: date) -> date:
    return date(d.year, 1, 1)


def _week_start(d: date) -> date:
    # Monday start (matches DATE_TRUNC(..., WEEK(MONDAY)))
    return date.fromordinal(d.toordinal() - d.weekday())


def _shift_months(d: date, delta_months: int) -> date:
    idx = (d.year * 12 + (d.month - 1)) + delta_months
    year = idx // 12
    month = (idx % 12) + 1
    day = min(d.day, _month_last_day(year, month))
    return date(year, month, day)


def _shift_for_comparison(d: date, comparison: str) -> date:
    if comparison in {"yoy", "last-year"}:
        year = d.year - 1
        day = min(d.day, _month_last_day(year, d.month))
        return date(year, d.month, day)
    if comparison in {"mom", "last-month"}:
        return _shift_months(d, -1)
    if comparison == "yoy-match-weekday":
        return date.fromordinal(d.toordinal() - 364)
    return d


def _interval_sql_for_comparison(comparison: str, time_grain: str | None) -> str | None:
    # Weekly buckets are DATE_TRUNC(..., WEEK(MONDAY)); YoY should align week-to-week.
    # A calendar year shift can miss matching buckets, so use a 52-week shift.
    if comparison in {"yoy", "last-year"} and time_grain == "weekly":
        return "INTERVAL 52 WEEK"
    return _TIME_COMPARISON_INTERVAL_SQL.get(comparison)


def _effective_to_date(request: QueryRequest) -> date:
    to_d = _parse_iso_date(request.to_date)

    if request.exclude_today:
        to_d = date.fromordinal(to_d.toordinal() - 1)

    if not request.exclude_open_period:
        return to_d

    grain = request.time_grain
    if grain in {None, "none"}:
        return to_d
    if grain == "daily":
        return date.fromordinal(to_d.toordinal() - 1)
    if grain == "weekly":
        return date.fromordinal(_week_start(to_d).toordinal() - 1)
    if grain == "monthly":
        return date.fromordinal(_month_start(to_d).toordinal() - 1)
    if grain == "quarterly":
        return date.fromordinal(_quarter_start(to_d).toordinal() - 1)
    if grain == "yearly":
        return date.fromordinal(_year_start(to_d).toordinal() - 1)
    return to_d


def _normalize_sql_expression(expression: str) -> str:
    # Engel examples often use double quotes for string literals.
    # Convert them to BigQuery-safe single quotes.
    return re.sub(r'"([^"\\]*(?:\\.[^"\\]*)*)"', lambda m: _bq_string(m.group(1)), expression)


def _cte_body(sql: str) -> str:
    stripped = sql.lstrip()
    if stripped.upper().startswith("WITH "):
        return "SELECT *\nFROM (\n" + sql + "\n)"
    return sql


def _strip_string_literals(expression: str) -> str:
    expression = re.sub(r"'(?:\\'|[^'])*'", "''", expression)
    expression = re.sub(r'"(?:\\"|[^"])*"', '""', expression)
    return expression


def _extract_column_refs(expression: str) -> list[str]:
    cleaned = _strip_string_literals(expression)
    pattern = r"`?[A-Za-z_][A-Za-z0-9_]*`?(?:\.`?[A-Za-z_][A-Za-z0-9_]*`?){1,3}"
    refs = re.findall(pattern, cleaned)
    return [ref.replace("`", "") for ref in refs]


def _alias_from_dimension_id(dimension_id: str) -> str:
    return re.sub(r"[^a-zA-Z0-9_]", "_", dimension_id)


@dataclass(slots=True)
class MetricRef:
    module: Module
    metric: Metric


@dataclass(slots=True)
class ResolvedReference:
    raw: str
    schema: str
    table: str
    column: str
    project: str | None = None

    @property
    def table_key(self) -> str:
        return self.table

    @property
    def quoted(self) -> str:
        return _bq_column_ref(self.schema, self.table, self.column, self.project)


class SemanticCompiler:
    def __init__(
        self,
        modules: list[Module],
        cross_module_metrics: list[CrossModuleMetric],
        source_files: list,
        *,
        strict_column_lint: bool = False,
        column_registry: ColumnRegistry | None = None,
        target_project: str = _DEFAULT_TARGET_PROJECT,
        target_schema: str = _DEFAULT_TARGET_SCHEMA,
        target_table: str = _DEFAULT_TARGET_TABLE,
    ):
        self.modules = modules
        self.cross_module_metrics = cross_module_metrics
        self.source_files = source_files
        self.strict_column_lint = strict_column_lint
        self.column_registry = column_registry
        self.target_project = target_project
        self.target_schema = target_schema
        self.target_table = target_table
        self.by_module_id = {m.identifier: m for m in modules}
        self.by_table = {m.table: m for m in modules}
        self.by_metric = {
            metric.identifier: MetricRef(module=m, metric=metric)
            for m in modules
            for metric in m.metrics
        }
        self.by_cross_metric = {m.identifier: m for m in cross_module_metrics}

    def compile_metric(self, metric_id: str, request: QueryRequest) -> CompiledQuery:
        base_request = self._expanded_request_for_time_comparison(request)

        if metric_id in self.by_cross_metric:
            compiled = self._compile_cross_metric(self.by_cross_metric[metric_id], base_request)
            compiled = self._apply_time_comparison(compiled, request)
            compiled = self._apply_target_comparison(compiled, request)
            return self._apply_cumulative(compiled, request)

        if metric_id not in self.by_metric:
            raise CompilationError(f"Unknown metric: {metric_id}")

        if len(request.breakdown_dimension_ids) > 2:
            raise CompilationError("Maximum 2 breakdown dimensions are supported")
        if len(set(request.breakdown_dimension_ids)) != len(request.breakdown_dimension_ids):
            raise CompilationError("Duplicate breakdown dimensions are not allowed")

        ref = self.by_metric[metric_id]
        module = ref.module
        metric = ref.metric

        metric_expr = self._metric_expression(module, metric)

        required_table_sources = self._required_table_sources(module, metric, base_request)
        join_clauses = self._build_join_clauses(module, metric, required_table_sources)
        where_clauses = self._build_where_clauses(module, metric, base_request)

        select_clauses: list[str] = []
        group_by_exprs: list[str] = []

        time_expr = self._parse_field_ref(metric.time, module)
        if base_request.time_grain:
            if base_request.time_grain == "none":
                pass
            else:
                if base_request.time_grain not in _TIME_GRAIN_SQL:
                    raise CompilationError(f"Unsupported time grain: {base_request.time_grain}")
                grain_expr = _TIME_GRAIN_SQL[base_request.time_grain].format(col=time_expr)
                select_clauses.append(f"  {grain_expr} AS time")
                group_by_exprs.append(grain_expr)

        breakdown_exprs = self._resolve_breakdowns(module, metric, base_request.breakdown_dimension_ids)
        seen_aliases: set[str] = set()
        for dim_id, dim_expr in breakdown_exprs:
            alias = _alias_from_dimension_id(dim_id)
            if alias in seen_aliases:
                raise CompilationError(
                    f"Breakdown alias collision for dimension '{dim_id}' -> '{alias}'. Use non-colliding dimensions."
                )
            seen_aliases.add(alias)
            select_clauses.append(f"  {dim_expr} AS {alias}")
            group_by_exprs.append(dim_expr)

        select_clauses.append(f"  {metric_expr} AS metric")

        from_table = _bq_table_ref(module.schema, module.table, module.project)
        sql_lines = ["SELECT", ",\n".join(select_clauses), f"FROM {from_table}"]

        if join_clauses:
            sql_lines.extend(join_clauses)

        if where_clauses:
            sql_lines.append("WHERE")
            sql_lines.append("  " + "\n  AND ".join(where_clauses))

        if group_by_exprs:
            sql_lines.append("GROUP BY")
            sql_lines.append("  " + ",\n  ".join(group_by_exprs))
            sql_lines.append("ORDER BY")
            sql_lines.append("  " + ", ".join(group_by_exprs))

        compiled = CompiledQuery(
            sql="\n".join(sql_lines),
            metric_id=metric.identifier,
            module_id=module.identifier,
            source_files=self.source_files,
            metadata={
                "calculation": metric.calculation,
                "time_grain": request.time_grain,
                "time_comparison": request.time_comparison,
                "target_series": request.target_series,
                "cumulative_mode": request.cumulative_mode,
                "rolling_days": request.rolling_days,
                "exclude_open_period": request.exclude_open_period,
                "exclude_today": request.exclude_today,
                "breakdowns": request.breakdown_dimension_ids,
                "required_tables": sorted(required_table_sources.keys()),
                "required_table_sources": {
                    table: sorted(refs) for table, refs in sorted(required_table_sources.items())
                },
                "join_count": len(join_clauses),
                "where_clause_count": len(where_clauses),
            },
        )
        compiled = self._apply_time_comparison(compiled, request)
        compiled = self._apply_target_comparison(compiled, request)
        return self._apply_cumulative(compiled, request)

    def _compile_cross_metric(self, cross_metric: CrossModuleMetric, request: QueryRequest) -> CompiledQuery:
        if request.slice_name:
            raise CompilationError("slice_name is not supported for cross module derived-ratio metrics")
        if not request.time_grain:
            raise CompilationError("Cross module derived-ratio metrics require timeGrain")
        if request.time_grain == "none":
            raise CompilationError("Cross module derived-ratio metrics do not support timeGrain='none'")
        if cross_metric.join_on != "time":
            raise CompilationError(
                f"Cross module metric '{cross_metric.identifier}' only supports join_on='time'"
            )
        if cross_metric.numerator_metric in self.by_cross_metric or cross_metric.denominator_metric in self.by_cross_metric:
            raise CompilationError("Nested cross module metrics are not supported")

        numerator_ref = self.by_metric.get(cross_metric.numerator_metric)
        denominator_ref = self.by_metric.get(cross_metric.denominator_metric)
        if not numerator_ref or not denominator_ref:
            raise CompilationError(
                f"Cross module metric '{cross_metric.identifier}' references unknown base metrics"
            )

        if request.breakdown_dimension_ids:
            num_allowed = self._allowed_dimension_ids(numerator_ref.module, numerator_ref.metric)
            den_allowed = self._allowed_dimension_ids(denominator_ref.module, denominator_ref.metric)

            not_in_num = [d for d in request.breakdown_dimension_ids if d not in num_allowed]
            not_in_den = [d for d in request.breakdown_dimension_ids if d not in den_allowed]

            if not_in_num or not_in_den:
                parts = []
                if not_in_num:
                    parts.append(
                        f"not allowed in numerator '{cross_metric.numerator_metric}': {', '.join(not_in_num)}"
                    )
                if not_in_den:
                    parts.append(
                        f"not allowed in denominator '{cross_metric.denominator_metric}': {', '.join(not_in_den)}"
                    )
                raise CompilationError(
                    f"Cross module metric '{cross_metric.identifier}' has incompatible breakdowns: "
                    + "; ".join(parts)
                )

        component_request = QueryRequest(
            from_date=request.from_date,
            to_date=request.to_date,
            time_grain=request.time_grain,
            time_comparison=None,
            target_series=None,
            cumulative_mode=None,
            rolling_days=None,
            exclude_open_period=request.exclude_open_period,
            exclude_today=request.exclude_today,
            breakdown_dimension_ids=list(request.breakdown_dimension_ids),
            slice_name=request.slice_name,
            filters=list(request.filters),
        )

        numerator = self.compile_metric(cross_metric.numerator_metric, component_request)
        denominator = self.compile_metric(cross_metric.denominator_metric, component_request)

        dim_aliases = [_alias_from_dimension_id(d) for d in request.breakdown_dimension_ids]
        join_conditions = ["n.time = d.time", *[f"n.{a} = d.{a}" for a in dim_aliases]]

        select_lines = [
            "  COALESCE(n.time, d.time) AS time",
            *[f"  COALESCE(n.{a}, d.{a}) AS {a}" for a in dim_aliases],
            "  SAFE_DIVIDE(n.metric, NULLIF(d.metric, 0)) AS metric",
            "  n.metric AS numerator",
            "  d.metric AS denominator",
        ]

        order_by = ["1", *[str(i + 2) for i in range(len(dim_aliases))]]

        join_sql = {
            "inner": "JOIN",
            "left": "LEFT JOIN",
            "full": "FULL OUTER JOIN",
        }.get(cross_metric.join_type)
        if not join_sql:
            raise CompilationError(
                f"Cross module metric '{cross_metric.identifier}' has unsupported join_type '{cross_metric.join_type}'"
            )

        sql = "\n".join(
            [
                "WITH numerator AS (",
                numerator.sql,
                "),",
                "denominator AS (",
                denominator.sql,
                ")",
                "SELECT",
                ",\n".join(select_lines),
                "FROM numerator n",
                f"{join_sql} denominator d",
                f"  ON {' AND '.join(join_conditions)}",
                f"ORDER BY {', '.join(order_by)}",
            ]
        )

        return CompiledQuery(
            sql=sql,
            metric_id=cross_metric.identifier,
            module_id="cross_module_metrics",
            source_files=self.source_files,
            metadata={
                "calculation": cross_metric.calculation,
                "join_on": cross_metric.join_on,
                "join_type": cross_metric.join_type,
                "time_grain": request.time_grain,
                "time_comparison": request.time_comparison,
                "target_series": request.target_series,
                "cumulative_mode": request.cumulative_mode,
                "rolling_days": request.rolling_days,
                "exclude_open_period": request.exclude_open_period,
                "exclude_today": request.exclude_today,
                "breakdowns": request.breakdown_dimension_ids,
                "numerator_metric": cross_metric.numerator_metric,
                "denominator_metric": cross_metric.denominator_metric,
            },
        )

    def _expanded_request_for_time_comparison(self, request: QueryRequest) -> QueryRequest:
        comparison = request.time_comparison
        if not comparison:
            return request

        # For time_grain='none', we compare two separately compiled windows (current vs shifted).
        # No expanded base window is needed.
        if request.time_grain == "none":
            return request

        from_d = _parse_iso_date(request.from_date)
        shifted_from = _shift_for_comparison(from_d, comparison)

        return QueryRequest(
            from_date=f"{shifted_from.isoformat()}T00:00:00Z",
            to_date=request.to_date,
            time_grain=request.time_grain,
            time_comparison=None,
            target_series=None,
            cumulative_mode=None,
            rolling_days=None,
            exclude_open_period=request.exclude_open_period,
            exclude_today=request.exclude_today,
            breakdown_dimension_ids=list(request.breakdown_dimension_ids),
            slice_name=request.slice_name,
            filters=list(request.filters),
        )

    def _apply_time_comparison(self, compiled: CompiledQuery, request: QueryRequest) -> CompiledQuery:
        comparison = request.time_comparison
        if not comparison:
            return compiled

        if not request.time_grain:
            raise CompilationError("timeComparison requires timeGrain")

        if comparison == "yoy-match-weekday" and request.time_grain != "daily":
            raise CompilationError("timeComparison 'YoY (Match Weekday)' requires daily timeGrain")

        interval_sql = _interval_sql_for_comparison(comparison, request.time_grain)
        if not interval_sql:
            raise CompilationError(f"Unsupported timeComparison '{comparison}'")

        dim_aliases = [_alias_from_dimension_id(d) for d in request.breakdown_dimension_ids]

        if request.time_grain == "none":
            from_d = _parse_iso_date(request.from_date)
            to_d = _effective_to_date(request)
            prev_from = _shift_for_comparison(from_d, comparison)
            prev_to = _shift_for_comparison(to_d, comparison)
            prev_request = QueryRequest(
                from_date=f"{prev_from.isoformat()}T00:00:00Z",
                to_date=f"{prev_to.isoformat()}T23:59:59Z",
                time_grain="none",
                time_comparison=None,
                target_series=None,
                cumulative_mode=None,
                rolling_days=None,
                # Dates are already shifted/clipped above; avoid applying exclusion flags twice.
                exclude_open_period=False,
                exclude_today=False,
                breakdown_dimension_ids=list(request.breakdown_dimension_ids),
                slice_name=request.slice_name,
                filters=list(request.filters),
            )
            prev_compiled = self.compile_metric(compiled.metric_id, prev_request)

            select_lines = ["  curr.*", "  prev.metric AS comparison_value"]
            if comparison in {"yoy", "mom", "yoy-match-weekday"}:
                select_lines.append(
                    "  SAFE_MULTIPLY(SAFE_DIVIDE(curr.metric - prev.metric, NULLIF(prev.metric, 0)), 100) "
                    "AS comparison_percentage"
                )

            join_conditions = [*[f"curr.{a} = prev.{a}" for a in dim_aliases]]
            if not join_conditions:
                join_conditions = ["1=1"]

            order_by = [*[f"curr.{a}" for a in dim_aliases]]

            sql_lines = [
                "WITH curr AS (",
                compiled.sql,
                "),",
                "prev AS (",
                prev_compiled.sql,
                ")",
                "SELECT",
                ",\n".join(select_lines),
                "FROM curr",
                "LEFT JOIN prev",
                f"  ON {' AND '.join(join_conditions)}",
            ]
            if order_by:
                sql_lines.append(f"ORDER BY {', '.join(order_by)}")
            sql = "\n".join(sql_lines)
        else:
            join_conditions = [f"prev.time = DATE_SUB(curr.time, {interval_sql})"]
            join_conditions.extend([f"curr.{a} = prev.{a}" for a in dim_aliases])

            start_bucket = _TIME_GRAIN_SQL[request.time_grain].format(col=f"DATE('{_iso_date(request.from_date)}')")
            end_bucket = _TIME_GRAIN_SQL[request.time_grain].format(col=f"DATE('{_effective_to_date(request).isoformat()}')")

            select_lines = ["  curr.*", "  prev.metric AS comparison_value"]
            if comparison in {"yoy", "mom", "yoy-match-weekday"}:
                select_lines.append(
                    "  SAFE_MULTIPLY(SAFE_DIVIDE(curr.metric - prev.metric, NULLIF(prev.metric, 0)), 100) "
                    "AS comparison_percentage"
                )

            order_by = ["curr.time", *[f"curr.{a}" for a in dim_aliases]]

            sql = "\n".join(
                [
                    "WITH base AS (",
                    compiled.sql,
                    ")",
                    "SELECT",
                    ",\n".join(select_lines),
                    "FROM base curr",
                    "LEFT JOIN base prev",
                    f"  ON {' AND '.join(join_conditions)}",
                    "WHERE",
                    f"  curr.time >= {start_bucket}",
                    f"  AND curr.time <= {end_bucket}",
                    f"ORDER BY {', '.join(order_by)}",
                ]
            )

        metadata = dict(compiled.metadata)
        metadata["time_comparison"] = comparison
        metadata["time_comparison_interval"] = interval_sql

        return CompiledQuery(
            sql=sql,
            metric_id=compiled.metric_id,
            module_id=compiled.module_id,
            source_files=compiled.source_files,
            metadata=metadata,
        )

    def _apply_target_comparison(self, compiled: CompiledQuery, request: QueryRequest) -> CompiledQuery:
        if not request.target_series:
            return compiled

        target_table = _bq_table_ref(self.target_schema, self.target_table, self.target_project)
        target_time = _bq_column_ref(self.target_schema, self.target_table, "time", self.target_project)
        target_metric = _bq_column_ref(self.target_schema, self.target_table, "metric", self.target_project)
        target_series = _bq_column_ref(self.target_schema, self.target_table, "series", self.target_project)
        target_value = _bq_column_ref(self.target_schema, self.target_table, "value", self.target_project)

        dim_aliases = [_alias_from_dimension_id(d) for d in request.breakdown_dimension_ids]

        from_date = _iso_date(request.from_date)
        to_date = _effective_to_date(request).isoformat()

        target_filter_clauses = []
        target_filter_columns: list[str] = []
        for f in request.filters:
            dim_col = f.dimension_id.split(".")[-1]
            target_filter_columns.append(dim_col)
            target_col = _bq_column_ref(self.target_schema, self.target_table, dim_col, self.target_project)
            vals = ", ".join(_bq_string(v) for v in f.filter_values)
            target_filter_clauses.append(f"{target_col} IN ({vals})")

        # Validate target table/columns in strict lint mode.
        target_required_columns = {"time", "metric", "series", "value", *dim_aliases, *target_filter_columns}
        for col in sorted(target_required_columns):
            self._assert_column_exists(
                ResolvedReference(
                    raw=f"{self.target_schema}.{self.target_table}.{col}",
                    project=self.target_project,
                    schema=self.target_schema,
                    table=self.target_table,
                    column=col,
                )
            )

        target_select = []
        target_group = []

        if request.time_grain and request.time_grain != "none":
            if request.time_grain not in _TIME_GRAIN_SQL:
                raise CompilationError(f"Unsupported time grain for targets: {request.time_grain}")
            target_grain_expr = _TIME_GRAIN_SQL[request.time_grain].format(col=target_time)
            target_select.append(f"  {target_grain_expr} AS time")
            target_group.append(target_grain_expr)

        for a in dim_aliases:
            col = _bq_column_ref(self.target_schema, self.target_table, a, self.target_project)
            target_select.append(f"  {col} AS {a}")
            target_group.append(col)

        target_select.append(f"  SUM({target_value}) AS target_value")

        join_conditions = []
        if request.time_grain and request.time_grain != "none":
            join_conditions.append("curr.time = t.time")
        join_conditions.extend([f"curr.{a} = t.{a}" for a in dim_aliases])
        if not join_conditions:
            join_conditions = ["1=1"]

        order_by = []
        if request.time_grain and request.time_grain != "none":
            order_by.append("curr.time")
        order_by.extend([f"curr.{a}" for a in dim_aliases])

        target_sql_lines = [
            "SELECT",
            ",\n".join(target_select),
            f"FROM {target_table}",
            "WHERE",
            f"  {target_series} = {_bq_string(request.target_series)}",
            f"  AND {target_metric} = {_bq_string(compiled.metric_id)}",
            f"  AND DATE({target_time}) >= DATE('{from_date}')",
            f"  AND DATE({target_time}) <= DATE('{to_date}')",
            *[f"  AND {c}" for c in target_filter_clauses],
        ]
        if target_group:
            target_sql_lines.extend(["GROUP BY", "  " + ",\n  ".join(target_group)])
        target_sql = "\n".join(target_sql_lines)

        sql_lines = [
            "WITH curr AS (",
            compiled.sql,
            "),",
            "targets AS (",
            target_sql,
            ")",
            "SELECT",
            "  curr.*,",
            "  t.target_value,",
            "  SAFE_MULTIPLY(SAFE_DIVIDE(curr.metric - t.target_value, NULLIF(t.target_value, 0)), 100) AS target_comparison_percentage",
            "FROM curr",
            "LEFT JOIN targets t",
            f"  ON {' AND '.join(join_conditions)}",
        ]
        if order_by:
            sql_lines.append("ORDER BY " + ", ".join(order_by))
        sql = "\n".join(sql_lines)

        metadata = dict(compiled.metadata)
        metadata["target_series"] = request.target_series
        metadata["target_table"] = f"{self.target_project}.{self.target_schema}.{self.target_table}"

        return CompiledQuery(
            sql=sql,
            metric_id=compiled.metric_id,
            module_id=compiled.module_id,
            source_files=compiled.source_files,
            metadata=metadata,
        )

    def _apply_cumulative(self, compiled: CompiledQuery, request: QueryRequest) -> CompiledQuery:
        mode = request.cumulative_mode
        if not mode:
            return compiled

        if not request.time_grain or request.time_grain == "none":
            raise CompilationError("cumulativeMode requires a timeGrain (not 'none')")

        if mode == "mtd" and request.time_grain != "daily":
            raise CompilationError("cumulativeMode 'mtd' requires timeGrain='daily'")
        if mode == "rolling_days" and request.time_grain != "daily":
            raise CompilationError("cumulativeMode 'rolling_days' requires timeGrain='daily'")

        dim_aliases = [_alias_from_dimension_id(d) for d in request.breakdown_dimension_ids]
        partition_exprs = [f"base.{a}" for a in dim_aliases]

        frame_sql = "ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW"
        if mode == "mtd":
            partition_exprs.append("DATE_TRUNC(base.time, MONTH)")
        elif mode == "ytd":
            partition_exprs.append("DATE_TRUNC(base.time, YEAR)")
        elif mode == "rolling_days":
            days = request.rolling_days or 0
            if days <= 0:
                raise CompilationError("rollingDays must be a positive integer for cumulativeMode='rolling_days'")
            frame_sql = f"RANGE BETWEEN INTERVAL {days - 1} DAY PRECEDING AND CURRENT ROW"
        else:
            raise CompilationError(f"Unsupported cumulativeMode '{mode}'")

        partition_sql = f"PARTITION BY {', '.join(partition_exprs)} " if partition_exprs else ""
        window_sql = f"{partition_sql}ORDER BY base.time {frame_sql}"

        order_by = ["base.time", *[f"base.{a}" for a in dim_aliases]]
        has_target = bool(compiled.metadata.get("target_series"))

        except_cols = ["metric"]
        select_lines = ["  base.metric AS metric_base", f"  SUM(base.metric) OVER ({window_sql}) AS metric"]

        if has_target:
            except_cols.extend(["target_value", "target_comparison_percentage"])
            select_lines.extend(
                [
                    "  base.target_value AS target_value_base",
                    f"  SUM(base.target_value) OVER ({window_sql}) AS target_value",
                    "  SAFE_MULTIPLY(SAFE_DIVIDE((SUM(base.metric) OVER ("
                    + window_sql
                    + ")) - (SUM(base.target_value) OVER ("
                    + window_sql
                    + ")), NULLIF((SUM(base.target_value) OVER ("
                    + window_sql
                    + ")), 0)), 100) AS target_comparison_percentage",
                ]
            )

        sql = "\n".join(
            [
                "WITH base AS (",
                _cte_body(compiled.sql),
                ")",
                "SELECT",
                f"  base.* EXCEPT({', '.join(except_cols)}),",
                ",\n".join(select_lines),
                "FROM base",
                f"ORDER BY {', '.join(order_by)}",
            ]
        )

        metadata = dict(compiled.metadata)
        metadata["cumulative_mode"] = mode
        metadata["rolling_days"] = request.rolling_days

        return CompiledQuery(
            sql=sql,
            metric_id=compiled.metric_id,
            module_id=compiled.module_id,
            source_files=compiled.source_files,
            metadata=metadata,
        )

    def _resolve_breakdowns(self, module: Module, metric: Metric, breakdowns: list[str]) -> list[tuple[str, str]]:
        if not breakdowns:
            return []

        allowed = self._allowed_dimension_ids(module, metric)
        resolved = []
        for dim in breakdowns:
            if dim not in allowed:
                raise CompilationError(
                    f"Dimension '{dim}' is not allowed for metric '{metric.identifier}'"
                )
            resolved.append((dim, self._parse_field_ref(dim, module, allow_plain_column=True)))
        return resolved

    def _allowed_dimension_ids(self, module: Module, metric: Metric) -> set[str]:
        allow = set()

        for token in metric.dimensions:
            if token == "this.*":
                allow.update(d.column for d in module.dimensions)
                continue

            if token.endswith(".*"):
                table = token.split(".")[-2] if token.count(".") >= 1 else module.table
                other = self.by_table.get(table)
                if not other:
                    raise CompilationError(
                        f"Dimension wildcard '{token}' references unknown table '{table}'"
                    )
                allow.update(f"{other.table}.{d.column}" for d in other.dimensions)
                continue

            allow.add(token)

        return allow

    def _metric_expression(self, module: Module, metric: Metric) -> str:
        calc = metric.calculation

        if calc == "sum":
            expr = f"SUM({self._parse_field_ref(metric.value or '', module)})"
        elif calc == "count":
            expr = "COUNT(*)"
        elif calc == "ratio":
            n = f"SUM({self._parse_field_ref(metric.numerator or '', module)})"
            d = f"SUM({self._parse_field_ref(metric.denominator or '', module)})"
            expr = f"SAFE_DIVIDE({n}, NULLIF({d}, 0))"
        elif calc == "count-distinct":
            expr = f"COUNT(DISTINCT {self._parse_field_ref(metric.distinct_on or '', module)})"
        elif calc == "custom-value":
            raw = metric.sql_expression or ""
            self._lint_custom_expression_references(raw, module, metric.identifier)
            expr = _normalize_sql_expression(raw)
        elif calc == "custom-ratio":
            numerator_raw = metric.numerator_sql or ""
            denominator_raw = metric.denominator_sql or ""
            self._lint_custom_expression_references(numerator_raw, module, metric.identifier)
            self._lint_custom_expression_references(denominator_raw, module, metric.identifier)
            numerator = _normalize_sql_expression(numerator_raw)
            denominator = _normalize_sql_expression(denominator_raw)
            expr = f"SAFE_DIVIDE(({numerator}), NULLIF(({denominator}), 0))"
        else:
            raise CompilationError(f"Unsupported calculation type: {calc}")

        if metric.format == "percentage":
            expr = f"({expr}) * 100"

        return expr

    def _lint_custom_expression_references(self, expression: str, module: Module, metric_id: str) -> None:
        for ref in _extract_column_refs(expression):
            try:
                resolved = self._resolve_reference(ref, module, allow_plain_column=False)
            except CompilationError as exc:
                raise CompilationError(
                    f"Metric '{metric_id}' has invalid custom SQL reference '{ref}': {exc}"
                ) from exc
            self._assert_column_exists(resolved)

    def _resolve_reference(
        self,
        ref: str,
        module: Module,
        *,
        allow_plain_column: bool,
    ) -> ResolvedReference:
        parts = ref.split(".")
        if len(parts) == 1:
            if not allow_plain_column:
                raise CompilationError(f"Expected table.column reference, got '{ref}'")
            return ResolvedReference(
                raw=ref,
                schema=module.schema,
                table=module.table,
                column=parts[0],
                project=module.project,
            )

        if len(parts) == 2:
            table, column = parts
            mod = self.by_table.get(table)
            if not mod:
                raise CompilationError(
                    f"Unknown table reference '{table}' in '{ref}'. "
                    "If this is an external table, use schema.table.column format."
                )
            return ResolvedReference(
                raw=ref,
                schema=mod.schema,
                table=mod.table,
                column=column,
                project=mod.project,
            )

        if len(parts) == 3:
            schema, table, column = parts
            return ResolvedReference(raw=ref, schema=schema, table=table, column=column)

        if len(parts) == 4:
            project, schema, table, column = parts
            return ResolvedReference(raw=ref, project=project, schema=schema, table=table, column=column)

        raise CompilationError(f"Unsupported reference: {ref}")

    def _assert_column_exists(self, resolved: ResolvedReference) -> None:
        if not self.strict_column_lint or not self.column_registry:
            return
        if not self.column_registry.has_table(resolved.schema, resolved.table):
            raise CompilationError(
                f"Strict column lint: unknown table '{resolved.schema}.{resolved.table}' for reference '{resolved.raw}'"
            )
        if not self.column_registry.has_column(resolved.schema, resolved.table, resolved.column):
            raise CompilationError(
                f"Strict column lint: unknown column '{resolved.column}' on '{resolved.schema}.{resolved.table}' for reference '{resolved.raw}'"
            )

    def _build_join_clauses(
        self,
        module: Module,
        metric: Metric,
        required_table_sources: dict[str, set[str]],
    ) -> list[str]:
        required_tables = set(required_table_sources.keys())
        if not required_tables:
            return []

        joins = []
        connected = {module.table}
        pending = set(required_tables)

        for _ in range(6):
            progressed = False
            for source_module in self.modules:
                for join in source_module.join_paths:
                    left_table = source_module.table
                    right_table = join.to.table
                    if not right_table:
                        continue

                    if left_table in connected and right_table in pending:
                        left = _bq_column_ref(
                            source_module.schema,
                            left_table,
                            join.from_.column,
                            source_module.project,
                        )
                        right_mod = self.by_table.get(right_table)
                        if not right_mod:
                            continue
                        right = _bq_column_ref(
                            right_mod.schema,
                            right_table,
                            join.to.column,
                            right_mod.project,
                        )
                        joins.append(
                            f"LEFT JOIN {_bq_table_ref(right_mod.schema, right_table, right_mod.project)} ON {left} = {right}"
                        )
                        connected.add(right_table)
                        pending.remove(right_table)
                        progressed = True
            if not pending or not progressed:
                break

        if pending:
            missing = ", ".join(sorted(pending))
            details = []
            for table in sorted(pending):
                refs = sorted(required_table_sources.get(table, set()))
                ref_text = ", ".join(refs) if refs else "unknown"
                details.append(f"{table} (referenced by: {ref_text})")
            detail_text = "; ".join(details)
            raise CompilationError(
                "Missing join path(s) for metric "
                f"'{metric.identifier}' in module '{module.identifier}' (table '{module.table}'). "
                f"Unreachable table(s): {missing}. Details: {detail_text}. "
                "Define joinPaths so these tables are reachable from the base module."
            )

        return joins

    def _required_table_sources(self, module: Module, metric: Metric, request: QueryRequest) -> dict[str, set[str]]:
        refs = [metric.time]

        for attr in [metric.value, metric.numerator, metric.denominator, metric.distinct_on]:
            if attr:
                refs.append(attr)

        for attr in [metric.sql_expression, metric.numerator_sql, metric.denominator_sql]:
            if attr:
                refs.extend(self._extract_table_refs(attr))

        for f in metric.filters:
            refs.append(self._filter_ref(f, module))
        for qf in request.filters:
            refs.append(qf.dimension_id)

        if request.breakdown_dimension_ids:
            refs.extend(request.breakdown_dimension_ids)

        out: dict[str, set[str]] = {}
        for ref in refs:
            try:
                resolved = self._resolve_reference(ref, module, allow_plain_column=True)
            except CompilationError:
                # keep join inference best-effort for non-column tokens in custom SQL extraction
                continue
            if resolved.table_key == module.table:
                continue
            out.setdefault(resolved.table_key, set()).add(ref)

        return out

    def _filter_ref(self, f: Filter, module: Module) -> str:
        if f.table:
            return f"{f.table}.{f.column}"
        return f"{module.table}.{f.column}"

    def _build_where_clauses(self, module: Module, metric: Metric, request: QueryRequest) -> list[str]:
        where = []
        time_ref = self._parse_field_ref(metric.time, module)
        from_date = _iso_date(request.from_date)
        to_date = _effective_to_date(request).isoformat()
        where.append(f"DATE({time_ref}) >= DATE({_bq_string(from_date)})")
        where.append(f"DATE({time_ref}) <= DATE({_bq_string(to_date)})")

        if request.slice_name:
            matched = [s for s in metric.slices if s.name == request.slice_name]
            if not matched:
                raise CompilationError(f"Unknown slice '{request.slice_name}' for metric '{metric.identifier}'")
            where.append(self._to_sql_filter(matched[0].filter, module))

        for f in metric.filters:
            where.append(self._to_sql_filter(f, module))

        allowed_dimensions = self._allowed_dimension_ids(module, metric)
        for f in request.filters:
            if f.dimension_id not in allowed_dimensions:
                raise CompilationError(
                    f"Filter dimension '{f.dimension_id}' is not allowed for metric '{metric.identifier}'"
                )
            col = self._parse_field_ref(f.dimension_id, module, allow_plain_column=True)
            vals = ", ".join(_bq_string(v) for v in f.filter_values)
            where.append(f"{col} IN ({vals})")

        return where

    def _to_sql_filter(self, f: Filter, module: Module) -> str:
        ref_name = f"{f.table}.{f.column}" if f.table else f"{module.table}.{f.column}"
        col = self._parse_field_ref(ref_name, module, allow_plain_column=True)
        op = _OPERATOR_SQL.get(f.operator)
        if not op:
            raise CompilationError(f"Unsupported operator: {f.operator}")

        if f.operator in {"in", "not-in"}:
            vals = [v.strip() for v in f.expression.split(",") if v.strip()]
            formatted = ", ".join(_bq_string(v) for v in vals)
            return f"{col} {op} ({formatted})"

        if f.operator in {"is", "is-not"}:
            expr = f.expression.strip().upper()
            if expr in {"NULL", "TRUE", "FALSE"}:
                return f"{col} {op} {expr}"
            return f"{col} {op} {_bq_string(f.expression.strip())}"

        return f"{col} {op} {_bq_string(f.expression)}"

    def _parse_field_ref(self, ref: str, module: Module, allow_plain_column: bool = False) -> str:
        resolved = self._resolve_reference(
            ref,
            module,
            allow_plain_column=allow_plain_column,
        )
        self._assert_column_exists(resolved)
        return resolved.quoted

    @staticmethod
    def _extract_table_refs(expression: str) -> Iterable[str]:
        refs: list[str] = []
        for ref in _extract_column_refs(expression):
            parts = ref.split(".")
            if len(parts) == 2:
                refs.append(f"{parts[0]}.{parts[1]}")
            elif len(parts) == 3:
                refs.append(f"{parts[1]}.{parts[2]}")
            elif len(parts) == 4:
                refs.append(f"{parts[2]}.{parts[3]}")
        return refs
