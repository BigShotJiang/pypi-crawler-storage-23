from __future__ import annotations

import argparse
import json
import re
import sys
from datetime import UTC, date, datetime, timedelta
from pathlib import Path
from typing import Any

from .layer import SemanticLayer
from .loader import SemanticConfigError, load_modules, parse_query_request
from .models import Module
from .schema_registry import ColumnRegistry


def _parse_json_or_jsonl(raw: str) -> Any:
    raw = raw.strip()
    if not raw:
        return []

    if raw.startswith("["):
        return json.loads(raw)

    if raw.startswith("{"):
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            # likely JSONL with one object per line
            pass

    rows = []
    for line in raw.splitlines():
        line = line.strip()
        if not line:
            continue
        rows.append(json.loads(line))
    return rows


def _load_json_or_jsonl(path: Path) -> Any:
    raw = path.read_text(encoding="utf-8")
    return _parse_json_or_jsonl(raw)


def _load_request_payload(request_arg: str) -> Any:
    if request_arg == "-":
        return _parse_json_or_jsonl(sys.stdin.read())
    return _load_json_or_jsonl(Path(request_arg))


def _month_start(d: date) -> date:
    return date(d.year, d.month, 1)


def _month_end(d: date) -> date:
    if d.month == 12:
        return date(d.year, 12, 31)
    return date(d.year, d.month + 1, 1) - timedelta(days=1)


def _shift_months(d: date, months: int) -> date:
    idx = d.year * 12 + (d.month - 1) + months
    y = idx // 12
    m = idx % 12 + 1
    return date(y, m, 1)


def _quarter_start(d: date) -> date:
    q_start_month = ((d.month - 1) // 3) * 3 + 1
    return date(d.year, q_start_month, 1)


def _quarter_end(d: date) -> date:
    s = _quarter_start(d)
    return _month_end(_shift_months(s, 2))


def _to_iso_range(start: date, end: date) -> tuple[str, str]:
    return (
        f"{start.isoformat()}T00:00:00Z",
        f"{end.isoformat()}T23:59:59Z",
    )


def _resolve_period(period: str, today: date | None = None) -> tuple[str, str]:
    today = today or datetime.now(UTC).date()
    text = period.strip()
    lower = text.lower()

    m = re.fullmatch(r"last\s+(\d+)\s+(years?|months?|quarters?|days?)", lower)
    if m:
        n = int(m.group(1))
        unit = m.group(2)
        if n <= 0:
            raise ValueError("Period count must be > 0")
        if unit.startswith("day"):
            start = today - timedelta(days=n - 1)
            end = today
            return _to_iso_range(start, end)
        if unit.startswith("month"):
            end = _month_end(today)
            start = _shift_months(_month_start(today), -(n - 1))
            return _to_iso_range(start, end)
        if unit.startswith("quarter"):
            end = _quarter_end(today)
            start = _shift_months(_quarter_start(today), -3 * (n - 1))
            return _to_iso_range(start, end)
        if unit.startswith("year"):
            start = date(today.year - (n - 1), 1, 1)
            end = date(today.year, 12, 31)
            return _to_iso_range(start, end)

    if lower == "current year":
        # Current year is YTD (up to today) to support aligned YoY comparisons.
        return _to_iso_range(date(today.year, 1, 1), today)

    if lower == "current month":
        # Current month is MTD (up to today) to support aligned MoM comparisons.
        return _to_iso_range(_month_start(today), today)

    m = re.fullmatch(r"q([1-4])\s+(\d{4})", lower)
    if m:
        q = int(m.group(1))
        y = int(m.group(2))
        start = date(y, (q - 1) * 3 + 1, 1)
        end = _month_end(_shift_months(start, 2))
        return _to_iso_range(start, end)

    m = re.fullmatch(r"(\d{4})", text)
    if m:
        y = int(m.group(1))
        return _to_iso_range(date(y, 1, 1), date(y, 12, 31))

    m = re.fullmatch(r"(0[1-9]|1[0-2])-(\d{4})", text)
    if m:
        mon = int(m.group(1))
        y = int(m.group(2))
        start = date(y, mon, 1)
        end = _month_end(start)
        return _to_iso_range(start, end)

    raise ValueError(
        "Unsupported period format. Use: 'last x years|months|quarters|days', "
        "'current year', 'current month', 'QX YYYY', 'YYYY', or 'MM-YYYY'."
    )


def _apply_period(raw: dict[str, Any], period: str | None) -> dict[str, Any]:
    payload = dict(raw)
    if period:
        from_date, to_date = _resolve_period(period)
        payload["fromDate"] = from_date
        payload["toDate"] = to_date
    return payload


def _load_rows(path: Path) -> list[dict[str, Any]]:
    data = _load_json_or_jsonl(path)
    if not isinstance(data, list):
        raise ValueError("Expected a JSON array of rows or JSONL input")
    return [dict(row) for row in data]


def _load_column_registry(path: str | None) -> ColumnRegistry | None:
    if not path:
        return None
    data = _load_json_or_jsonl(Path(path))
    if not isinstance(data, dict):
        raise ValueError("Registry JSON must be an object: {schema: {table: [columns]}}")
    return ColumnRegistry.from_dict(data)


def cmd_registry_from_information_schema(args: argparse.Namespace) -> int:
    rows = _load_rows(Path(args.input))
    registry = ColumnRegistry.from_information_schema_rows(
        rows,
        schema_key=args.schema_key,
        table_key=args.table_key,
        column_key=args.column_key,
    )

    output = json.dumps(registry.to_dict(), indent=2, sort_keys=True) + "\n"
    if args.output:
        Path(args.output).write_text(output, encoding="utf-8")
    else:
        print(output, end="")
    return 0


def _collect_semantic_warnings(
    modules: list[Module],
    cross_module_metrics: list[Any],
) -> list[dict[str, str]]:
    by_table = {m.table: m for m in modules}
    metric_ids = {metric.identifier for module in modules for metric in module.metrics}
    warnings: list[dict[str, str]] = []

    for module in modules:
        for metric in module.metrics:
            for dim in metric.dimensions:
                if dim == "this.*":
                    if not module.dimensions:
                        warnings.append(
                            {
                                "moduleId": module.identifier,
                                "metricId": metric.identifier,
                                "type": "empty-wildcard",
                                "message": "this.* resolves to zero dimensions",
                            }
                        )
                    continue

                if dim.endswith(".*"):
                    parts = dim.split(".")
                    table = parts[-2] if len(parts) >= 2 else module.table
                    target = by_table.get(table)
                    if not target:
                        warnings.append(
                            {
                                "moduleId": module.identifier,
                                "metricId": metric.identifier,
                                "type": "unresolved-wildcard",
                                "message": f"Dimension wildcard '{dim}' references unknown table '{table}'",
                            }
                        )
                    elif not target.dimensions:
                        warnings.append(
                            {
                                "moduleId": module.identifier,
                                "metricId": metric.identifier,
                                "type": "empty-wildcard",
                                "message": f"Dimension wildcard '{dim}' resolves to zero dimensions",
                            }
                        )
                    continue

                parts = dim.split(".")
                if len(parts) == 2:
                    table, column = parts
                    target = by_table.get(table)
                    if target:
                        if column not in {d.column for d in target.dimensions}:
                            warnings.append(
                                {
                                    "moduleId": module.identifier,
                                    "metricId": metric.identifier,
                                    "type": "unknown-dimension-column",
                                    "message": f"Dimension '{dim}' references unknown column '{column}' on table '{table}'",
                                }
                            )
                    else:
                        warnings.append(
                            {
                                "moduleId": module.identifier,
                                "metricId": metric.identifier,
                                "type": "unresolved-dimension-reference",
                                "message": f"Dimension '{dim}' references unknown table '{table}'",
                            }
                        )

        for join in module.join_paths:
            if join.to.table and join.to.table not in by_table:
                warnings.append(
                    {
                        "moduleId": module.identifier,
                        "metricId": "-",
                        "type": "unresolved-join-target",
                        "message": f"Join path targets unknown table '{join.to.table}'",
                    }
                )

    for cross_metric in cross_module_metrics:
        if cross_metric.numerator_metric not in metric_ids:
            warnings.append(
                {
                    "moduleId": "cross_module_metrics",
                    "metricId": cross_metric.identifier,
                    "type": "unknown-derived-numerator",
                    "message": f"Unknown numerator metric '{cross_metric.numerator_metric}'",
                }
            )
        if cross_metric.denominator_metric not in metric_ids:
            warnings.append(
                {
                    "moduleId": "cross_module_metrics",
                    "metricId": cross_metric.identifier,
                    "type": "unknown-derived-denominator",
                    "message": f"Unknown denominator metric '{cross_metric.denominator_metric}'",
                }
            )

    return warnings


def _summary_payload(payload: dict[str, Any]) -> dict[str, Any]:
    return {
        "ok": payload["ok"],
        "modules": payload["modules"],
        "metrics": payload["metrics"],
        "crossModuleMetrics": payload["crossModuleMetrics"],
        "dimensions": payload["dimensions"],
        "warningCount": payload["warningCount"],
        "compileFailureCount": payload["compileFailureCount"],
        "compileCheckedMetrics": payload["compileCheckedMetrics"],
        "compileValidationTimeGrain": payload["compileValidationTimeGrain"],
    }


def _target_source_kwargs(args: argparse.Namespace) -> dict[str, str]:
    return {
        "target_project": args.target_project,
        "target_schema": args.target_schema,
        "target_table": args.target_table,
    }


def cmd_validate(args: argparse.Namespace) -> int:
    modules, cross_module_metrics, files = load_modules(args.model_path)
    metric_count = sum(len(m.metrics) for m in modules)
    dimension_count = sum(len(m.dimensions) for m in modules)

    registry = None
    if args.strict_column_lint:
        registry = _load_column_registry(args.column_registry)
        if not registry:
            raise ValueError("--strict-column-lint requires --column-registry")

    warnings = _collect_semantic_warnings(modules, cross_module_metrics)

    checked_metrics = 0
    compile_checked_metrics = 0
    compile_failures: list[dict[str, str]] = []
    metric_validation: list[dict[str, str]] = []

    if args.strict_column_lint or args.check_compilable:
        layer = SemanticLayer.from_path(
            args.model_path,
            strict_column_lint=bool(args.strict_column_lint),
            column_registry=registry,
            **_target_source_kwargs(args),
        )
        req_payload = {
            "fromDate": args.from_date,
            "toDate": args.to_date,
            "timeGrain": args.time_grain,
        }
        req = parse_query_request(_apply_period(req_payload, args.period))

        for module in modules:
            for metric in module.metrics:
                checked_metrics += 1
                if not args.check_compilable and not args.strict_column_lint:
                    metric_validation.append(
                        {
                            "metricId": metric.identifier,
                            "moduleId": module.identifier,
                            "status": "not-compiled",
                            "reason": "compile checks disabled",
                        }
                    )
                    continue
                try:
                    layer.compile_sql(metric.identifier, req)
                    compile_checked_metrics += 1
                    metric_validation.append(
                        {
                            "metricId": metric.identifier,
                            "moduleId": module.identifier,
                            "status": "ok",
                        }
                    )
                except Exception as exc:
                    compile_failures.append(
                        {
                            "metricId": metric.identifier,
                            "moduleId": module.identifier,
                            "error": str(exc),
                        }
                    )
                    metric_validation.append(
                        {
                            "metricId": metric.identifier,
                            "moduleId": module.identifier,
                            "status": "failed",
                            "error": str(exc),
                        }
                    )

        for metric in cross_module_metrics:
            checked_metrics += 1
            if not args.check_compilable:
                metric_validation.append(
                    {
                        "metricId": metric.identifier,
                        "moduleId": "cross_module_metrics",
                        "status": "not-compiled",
                        "reason": "cross module compile checks require --check-compilable",
                    }
                )
                continue
            try:
                layer.compile_sql(metric.identifier, req)
                compile_checked_metrics += 1
                metric_validation.append(
                    {
                        "metricId": metric.identifier,
                        "moduleId": "cross_module_metrics",
                        "status": "ok",
                    }
                )
            except Exception as exc:
                compile_failures.append(
                    {
                        "metricId": metric.identifier,
                        "moduleId": "cross_module_metrics",
                        "error": str(exc),
                    }
                )
                metric_validation.append(
                    {
                        "metricId": metric.identifier,
                        "moduleId": "cross_module_metrics",
                        "status": "failed",
                        "error": str(exc),
                    }
                )

    warnings_as_errors = bool(args.warnings_as_errors)
    payload = {
        "ok": len(compile_failures) == 0 and (not warnings_as_errors or len(warnings) == 0),
        "modules": len(modules),
        "metrics": metric_count,
        "crossModuleMetrics": len(cross_module_metrics),
        "dimensions": dimension_count,
        "files": [str(f) for f in files],
        "strictColumnLint": bool(args.strict_column_lint),
        "checkCompilable": bool(args.check_compilable),
        "compileValidationTimeGrain": args.time_grain,
        "warningsAsErrors": warnings_as_errors,
        "warningCount": len(warnings),
        "warnings": warnings,
        "checkedMetrics": checked_metrics,
        "compileCheckedMetrics": compile_checked_metrics,
        "compileFailureCount": len(compile_failures),
        "compileFailures": compile_failures,
        "metricValidation": metric_validation,
    }

    if args.report:
        Path(args.report).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    if compile_failures:
        first = compile_failures[0]
        raise ValueError(
            f"{len(compile_failures)} metric(s) failed compile validation. "
            f"First failure: {first['metricId']} ({first['moduleId']}): {first['error']}"
        )

    if warnings and warnings_as_errors:
        first = warnings[0]
        raise ValueError(
            f"{len(warnings)} semantic warning(s) treated as errors. "
            f"First warning: {first['type']} in {first['moduleId']}/{first['metricId']}: {first['message']}"
        )

    summary = _summary_payload(payload)

    if args.json:
        print(json.dumps(summary if args.summary_only else payload, indent=2, sort_keys=True))
    else:
        msg = (
            f"OK: {summary['modules']} module(s), {summary['metrics']} metric(s), "
            f"{summary['crossModuleMetrics']} cross metric(s), {summary['dimensions']} dimension(s), "
            f"warnings {summary['warningCount']}, compile failures {summary['compileFailureCount']}"
        )
        if args.check_compilable or args.strict_column_lint:
            msg += f", compile checked {summary['compileCheckedMetrics']} metric(s)"
        print(msg)
    return 0


def cmd_compile(args: argparse.Namespace) -> int:
    request_raw = _load_request_payload(args.request)
    if not isinstance(request_raw, dict):
        raise ValueError("Request must be a JSON object")

    request_payload = _apply_period(request_raw, args.period)
    if "fromDate" not in request_payload or "toDate" not in request_payload:
        raise ValueError("Request must include fromDate/toDate or provide --period")
    request = parse_query_request(request_payload)
    registry = _load_column_registry(args.column_registry)
    layer = SemanticLayer.from_path(
        args.model_path,
        strict_column_lint=args.strict_column_lint,
        column_registry=registry,
        **_target_source_kwargs(args),
    )
    compiled = layer.compile(args.metric_id, request)

    if args.dry_run_validate:
        payload = {
            "ok": True,
            "metricId": compiled.metric_id,
            "moduleId": compiled.module_id,
            "metadata": compiled.metadata,
        }
        if args.format in {"json", "explain"}:
            output = json.dumps(payload, indent=2, sort_keys=True) + "\n"
        else:
            output = f"OK: request is valid for metric '{compiled.metric_id}'\n"
    elif args.format == "sql":
        output = compiled.sql + "\n"
    elif args.format == "json":
        output = (
            json.dumps(
                {
                    "metricId": compiled.metric_id,
                    "moduleId": compiled.module_id,
                    "sql": compiled.sql,
                    "metadata": compiled.metadata,
                },
                indent=2,
                sort_keys=True,
            )
            + "\n"
        )
    else:  # explain
        output = (
            json.dumps(
                {
                    "metricId": compiled.metric_id,
                    "moduleId": compiled.module_id,
                    "explain": {
                        "metadata": compiled.metadata,
                        "sourceFiles": [str(p) for p in compiled.source_files],
                    },
                    "sql": compiled.sql,
                },
                indent=2,
                sort_keys=True,
            )
            + "\n"
        )

    if args.output:
        Path(args.output).write_text(output, encoding="utf-8")
    else:
        print(output, end="")
    return 0


def cmd_metrics(args: argparse.Namespace) -> int:
    modules, cross_module_metrics, _ = load_modules(args.model_path)
    items = []
    for module in modules:
        for metric in module.metrics:
            items.append(
                {
                    "id": metric.identifier,
                    "name": metric.name,
                    "description": metric.description,
                    "aiContext": metric.ai_context,
                    "moduleId": module.identifier,
                    "table": f"{module.schema}.{module.table}",
                    "calculation": metric.calculation,
                }
            )

    for metric in cross_module_metrics:
        items.append(
            {
                "id": metric.identifier,
                "name": metric.name,
                "description": metric.description,
                "aiContext": None,
                "moduleId": "cross_module_metrics",
                "table": "-",
                "calculation": metric.calculation,
            }
        )

    if args.module:
        items = [i for i in items if i["moduleId"] == args.module]
    if args.calculation:
        items = [i for i in items if i["calculation"] == args.calculation]

    items.sort(key=lambda i: i["id"])

    if args.format == "json":
        print(json.dumps(items, indent=2, sort_keys=True))
    else:
        headers = ["metric_id", "calculation", "module_id", "name", "table"]
        rows = [[i["id"], i["calculation"], i["moduleId"], i["name"], i["table"]] for i in items]
        widths = [len(h) for h in headers]
        for row in rows:
            for idx, cell in enumerate(row):
                widths[idx] = max(widths[idx], len(str(cell)))

        fmt = "  ".join("{:<" + str(w) + "}" for w in widths)
        print(fmt.format(*headers))
        print(fmt.format(*["-" * w for w in widths]))
        for row in rows:
            print(fmt.format(*row))
    return 0


def cmd_joins(args: argparse.Namespace) -> int:
    modules, cross_module_metrics, _ = load_modules(args.model_path)
    by_table = {m.table: m for m in modules}

    edges: list[dict[str, str]] = []
    in_degree = {m.identifier: 0 for m in modules}
    out_degree = {m.identifier: 0 for m in modules}

    for module in modules:
        for join in module.join_paths:
            if not join.to.table:
                continue
            target = by_table.get(join.to.table)
            if not target:
                continue
            edges.append(
                {
                    "fromModuleId": module.identifier,
                    "toModuleId": target.identifier,
                    "fromTable": module.table,
                    "toTable": target.table,
                    "type": join.type,
                    "fromColumn": join.from_.column,
                    "toColumn": join.to.column,
                }
            )
            out_degree[module.identifier] += 1
            in_degree[target.identifier] += 1

    edges.sort(key=lambda e: (e["fromModuleId"], e["toModuleId"], e["fromColumn"], e["toColumn"]))

    orphans = sorted(
        [m.identifier for m in modules if in_degree[m.identifier] == 0 and out_degree[m.identifier] == 0]
    )

    payload = {
        "modules": len(modules),
        "crossModuleMetrics": len(cross_module_metrics),
        "joins": len(edges),
        "orphans": orphans,
        "edges": edges,
    }

    if args.format == "json":
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        print(f"modules: {payload['modules']}")
        print(f"cross_module_metrics: {payload['crossModuleMetrics']}")
        print(f"joins: {payload['joins']}")
        print(f"orphans: {', '.join(orphans) if orphans else '-'}")
        if edges:
            print("\njoin edges:")
            for e in edges:
                print(
                    f"- {e['fromModuleId']} -> {e['toModuleId']} "
                    f"[{e['type']}] on {e['fromTable']}.{e['fromColumn']} = {e['toTable']}.{e['toColumn']}"
                )
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="engel-semantic-layer",
        description="Utilities for engel-semantic-layer",
    )
    parser.add_argument(
        "--json-errors",
        action="store_true",
        help="Emit CLI errors as JSON on stderr",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    validate = sub.add_parser("validate", help="Validate semantic model YAML files")
    validate.add_argument("--model-path", required=True, help="Path to model directory")
    validate.add_argument("--json", action="store_true", help="Output validation result as JSON")
    validate.add_argument(
        "--summary-only",
        action="store_true",
        help="Print only summary fields (useful for concise CI logs)",
    )
    validate.add_argument(
        "--strict-column-lint",
        action="store_true",
        help="Enable strict column lint validation for all metrics",
    )
    validate.add_argument(
        "--check-compilable",
        action="store_true",
        help="Compile-validate all metrics with synthetic dates",
    )
    validate.add_argument(
        "--column-registry",
        help="Path to column registry JSON ({schema: {table: [columns]}})",
    )
    validate.add_argument(
        "--from-date",
        default="2026-01-01T00:00:00Z",
        help="Synthetic fromDate used for strict compile validation",
    )
    validate.add_argument(
        "--to-date",
        default="2026-12-31T23:59:59Z",
        help="Synthetic toDate used for strict compile validation",
    )
    validate.add_argument(
        "--time-grain",
        choices=["none", "daily", "weekly", "monthly", "quarterly", "yearly"],
        default="monthly",
        help="Synthetic timeGrain used for compile validation (default: monthly)",
    )
    validate.add_argument(
        "--report",
        help="Write full validation report JSON to file",
    )
    validate.add_argument(
        "--period",
        help="Override synthetic from/to with a relative period (e.g. 'last 12 months', 'current year', 'Q1 2025')",
    )
    validate.add_argument(
        "--warnings-as-errors",
        action="store_true",
        help="Fail validation when semantic warnings are present",
    )
    validate.add_argument(
        "--target-project",
        default="demo-project-123456",
        help="Target comparison project (default: demo-project-123456)",
    )
    validate.add_argument(
        "--target-schema",
        default="analytics_prod",
        help="Target comparison schema (default: analytics_prod)",
    )
    validate.add_argument(
        "--target-table",
        default="fct_targets_monthly",
        help="Target comparison table (default: fct_targets_monthly)",
    )
    validate.set_defaults(func=cmd_validate)

    metrics_cmd = sub.add_parser("metrics", help="List all metrics in the model")
    metrics_cmd.add_argument("--model-path", required=True, help="Path to model directory")
    metrics_cmd.add_argument(
        "--format",
        choices=["table", "json"],
        default="table",
        help="Output format",
    )
    metrics_cmd.add_argument("--module", help="Filter by module identifier")
    metrics_cmd.add_argument("--calculation", help="Filter by calculation type")
    metrics_cmd.set_defaults(func=cmd_metrics)

    joins_cmd = sub.add_parser("joins", help="Inspect join graph between modules")
    joins_cmd.add_argument("--model-path", required=True, help="Path to model directory")
    joins_cmd.add_argument(
        "--format",
        choices=["table", "json"],
        default="table",
        help="Output format",
    )
    joins_cmd.set_defaults(func=cmd_joins)

    compile_cmd = sub.add_parser("compile", help="Compile SQL for a metric query request")
    compile_cmd.add_argument("--model-path", required=True, help="Path to model directory")
    compile_cmd.add_argument("--metric-id", required=True, help="Metric identifier")
    compile_cmd.add_argument(
        "--request",
        required=True,
        help="Path to query request JSON (or '-' to read JSON from stdin)",
    )
    compile_cmd.add_argument(
        "--period",
        help="Set from/to using period syntax (e.g. 'last 12 months', 'current month', 'Q1 2025', '2025', '02-2025')",
    )
    compile_cmd.add_argument(
        "--format",
        choices=["sql", "json", "explain"],
        default="sql",
        help="Output format",
    )
    compile_cmd.add_argument("--output", help="Write output to file")
    compile_cmd.add_argument(
        "--dry-run-validate",
        action="store_true",
        help="Validate request and metric compatibility without returning SQL",
    )
    compile_cmd.add_argument(
        "--strict-column-lint",
        action="store_true",
        help="Enable strict column checks against --column-registry",
    )
    compile_cmd.add_argument(
        "--column-registry",
        help="Path to column registry JSON ({schema: {table: [columns]}})",
    )
    compile_cmd.add_argument(
        "--target-project",
        default="demo-project-123456",
        help="Target comparison project (default: demo-project-123456)",
    )
    compile_cmd.add_argument(
        "--target-schema",
        default="analytics_prod",
        help="Target comparison schema (default: analytics_prod)",
    )
    compile_cmd.add_argument(
        "--target-table",
        default="fct_targets_monthly",
        help="Target comparison table (default: fct_targets_monthly)",
    )
    compile_cmd.set_defaults(func=cmd_compile)

    registry = sub.add_parser("registry", help="Column registry utilities")
    reg_sub = registry.add_subparsers(dest="registry_command", required=True)

    from_is = reg_sub.add_parser(
        "from-information-schema",
        help="Build registry JSON from INFORMATION_SCHEMA.COLUMNS rows (JSON array or JSONL)",
    )
    from_is.add_argument("--input", required=True, help="Path to JSON or JSONL rows")
    from_is.add_argument("--output", help="Path to write registry JSON. Defaults to stdout")
    from_is.add_argument("--schema-key", default="table_schema")
    from_is.add_argument("--table-key", default="table_name")
    from_is.add_argument("--column-key", default="column_name")
    from_is.set_defaults(func=cmd_registry_from_information_schema)

    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    try:
        return args.func(args)
    except (SemanticConfigError, ValueError, KeyError) as exc:
        if args.json_errors:
            payload = {
                "ok": False,
                "errorType": exc.__class__.__name__,
                "message": str(exc),
                "exitCode": 2,
            }
            print(json.dumps(payload, sort_keys=True), file=sys.stderr)
        else:
            print(f"ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
