from __future__ import annotations

from pathlib import Path

from .compiler import SemanticCompiler
from .loader import load_modules
from .models import CompiledQuery, QueryRequest
from .schema_registry import ColumnRegistry


class SemanticLayer:
    def __init__(self, compiler: SemanticCompiler):
        self._compiler = compiler

    @classmethod
    def from_path(
        cls,
        path: str | Path,
        *,
        strict_column_lint: bool = False,
        column_registry: ColumnRegistry | None = None,
        target_project: str = "demo-project-123456",
        target_schema: str = "analytics_prod",
        target_table: str = "fct_targets_monthly",
    ) -> "SemanticLayer":
        modules, cross_module_metrics, files = load_modules(path)
        return cls(
            SemanticCompiler(
                modules=modules,
                cross_module_metrics=cross_module_metrics,
                source_files=files,
                strict_column_lint=strict_column_lint,
                column_registry=column_registry,
                target_project=target_project,
                target_schema=target_schema,
                target_table=target_table,
            )
        )

    def compile_sql(self, metric_id: str, request: QueryRequest) -> str:
        return self.compile(metric_id, request).sql

    def compile(self, metric_id: str, request: QueryRequest) -> CompiledQuery:
        return self._compiler.compile_metric(metric_id=metric_id, request=request)
