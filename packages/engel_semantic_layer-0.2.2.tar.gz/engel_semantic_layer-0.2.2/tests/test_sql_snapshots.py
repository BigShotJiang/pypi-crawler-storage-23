from pathlib import Path

from engel_semantic_layer import QueryFilter, QueryRequest, SemanticLayer


def _snapshot(name: str) -> str:
    return Path("tests/snapshots").joinpath(name).read_text(encoding="utf-8")


def test_sql_snapshot_metric_event_count_with_breakdown():
    layer = SemanticLayer.from_path("examples/model")
    sql = layer.compile_sql(
        "metric_event_count",
        QueryRequest(
            from_date="2026-02-01T00:00:00Z",
            to_date="2026-02-28T23:59:59Z",
            time_grain="daily",
            breakdown_dimension_ids=["user_email"],
            filters=[
                QueryFilter(
                    dimension_id="user_email",
                    filter_values=["demo-user@example.com"],
                )
            ],
        ),
    )
    assert sql + "\n" == _snapshot("metric_event_count_with_breakdown.sql")


def test_sql_snapshot_metric_actual_secondary():
    layer = SemanticLayer.from_path("examples/model")
    sql = layer.compile_sql(
        "metric_actual_secondary",
        QueryRequest(
            from_date="2026-01-01T00:00:00Z",
            to_date="2026-12-31T23:59:59Z",
        ),
    )
    assert sql + "\n" == _snapshot("metric_actual_secondary.sql")


def test_sql_snapshot_metric_future_delta_segment_slice():
    layer = SemanticLayer.from_path("examples/model")
    sql = layer.compile_sql(
        "metric_future_delta",
        QueryRequest(
            from_date="2026-01-01T00:00:00Z",
            to_date="2026-12-31T23:59:59Z",
            slice_name="SegmentA",
            breakdown_dimension_ids=["segment_group"],
        ),
    )
    assert sql + "\n" == _snapshot("metric_future_delta_segment_slice.sql")


def test_sql_snapshot_metric_average_primary():
    layer = SemanticLayer.from_path("examples/model")
    sql = layer.compile_sql(
        "metric_average_primary",
        QueryRequest(
            from_date="2026-01-01T00:00:00Z",
            to_date="2026-12-31T23:59:59Z",
        ),
    )
    assert sql + "\n" == _snapshot("metric_average_primary.sql")
