import pytest

from engel_semantic_layer import ColumnRegistry, QueryFilter, QueryRequest, SemanticLayer
from engel_semantic_layer.compiler import CompilationError


def test_compile_count_metric_with_filter_and_breakdown():
    layer = SemanticLayer.from_path("examples/model")

    sql = layer.compile_sql(
        metric_id="metric_event_count",
        request=QueryRequest(
            from_date="2026-02-01T00:00:00Z",
            to_date="2026-02-28T23:59:59Z",
            time_grain="daily",
            breakdown_dimension_ids=["user_email"],
            filters=[
                QueryFilter(
                    dimension_id="user_email",
                    filter_values=["demo-user@example.com"],
                )
            ],
        ),
    )

    assert "COUNT(*) AS metric" in sql
    assert "`analytics_prod.event_log`.`user_email` AS user_email" in sql
    assert "NOT LIKE '%INFORMATION_SCHEMA.COLUMNS%'" in sql
    assert "IN ('demo-user@example.com')" in sql


def test_compile_count_distinct_metric():
    layer = SemanticLayer.from_path("examples/model")

    sql = layer.compile_sql(
        metric_id="metric_event_distinct_count",
        request=QueryRequest(
            from_date="2026-02-01T00:00:00Z",
            to_date="2026-02-28T23:59:59Z",
        ),
    )

    assert "COUNT(DISTINCT `analytics_prod.event_log`.`query`) AS metric" in sql


def test_compile_all_wide_record_metrics():
    layer = SemanticLayer.from_path("examples/model")

    metric_ids = [
        "metric_average_primary",
        "metric_count_a",
        "metric_future_delta",
        "metric_actual_primary",
        "metric_count_b",
        "metric_actual_secondary",
        "metric_distinct_users",
        "metric_duration_sum",
    ]

    for metric_id in metric_ids:
        sql = layer.compile_sql(
            metric_id=metric_id,
            request=QueryRequest(
                from_date="2026-01-01T00:00:00Z",
                to_date="2026-12-31T23:59:59Z",
            ),
        )
        assert "FROM `demo-project-123456.analytics_wide.wide_metric_count_a`" in sql
        assert "AS metric" in sql


def test_compile_wide_record_slice():
    layer = SemanticLayer.from_path("examples/model")

    sql = layer.compile_sql(
        metric_id="metric_future_delta",
        request=QueryRequest(
            from_date="2026-01-01T00:00:00Z",
            to_date="2026-12-31T23:59:59Z",
            slice_name="SegmentA",
            breakdown_dimension_ids=["segment_group"],
        ),
    )

    assert "`demo-project-123456.analytics_wide.wide_metric_count_a`.`segment_group` AS segment_group" in sql
    assert "`demo-project-123456.analytics_wide.wide_metric_count_a`.`segment_group` = 'SegmentA'" in sql


def test_custom_expression_is_normalized_to_bigquery_string_literals():
    layer = SemanticLayer.from_path("examples/model")
    sql = layer.compile_sql(
        metric_id="metric_average_primary",
        request=QueryRequest(
            from_date="2026-01-01T00:00:00Z",
            to_date="2026-12-31T23:59:59Z",
        ),
    )

    assert "status IN ('completed','confirmed','cancelled')" in sql


def test_is_not_null_filter_is_rendered_without_quotes():
    layer = SemanticLayer.from_path("examples/model")
    sql = layer.compile_sql(
        metric_id="metric_actual_secondary",
        request=QueryRequest(
            from_date="2026-01-01T00:00:00Z",
            to_date="2026-12-31T23:59:59Z",
        ),
    )

    assert "`demo-project-123456.analytics_wide.wide_metric_count_a`.`settled_at` IS NOT NULL" in sql


def test_disallow_unknown_query_filter_dimension():
    layer = SemanticLayer.from_path("examples/model")

    with pytest.raises(CompilationError):
        layer.compile_sql(
            metric_id="metric_actual_secondary",
            request=QueryRequest(
                from_date="2026-01-01T00:00:00Z",
                to_date="2026-12-31T23:59:59Z",
                filters=[QueryFilter(dimension_id="unknown_dimension", filter_values=["x"])],
            ),
        )


def test_disallow_duplicate_breakdown_dimensions():
    layer = SemanticLayer.from_path("examples/model")

    with pytest.raises(CompilationError, match="Duplicate breakdown dimensions"):
        layer.compile_sql(
            metric_id="metric_event_count",
            request=QueryRequest(
                from_date="2026-01-01T00:00:00Z",
                to_date="2026-01-31T23:59:59Z",
                breakdown_dimension_ids=["user_email", "user_email"],
            ),
        )


def test_disallow_unknown_table_reference_in_custom_sql(tmp_path):
    model_dir = tmp_path / "model"
    model_dir.mkdir()
    (model_dir / "records.yml").write_text(
        """
module:
  identifier: "records"
  schema: "analytics"
  table: "records"
  dimensions:
    - column: "country"
      type: "categorical"
  metrics:
    - identifier: "bad_metric"
      name: "Bad metric"
      calculation: "custom-value"
      time: "records.recorded_at"
      sql_expression: "SUM(ghost_table.amount)"
      dimensions:
        - "country"
""".strip()
    )

    layer = SemanticLayer.from_path(model_dir)
    with pytest.raises(CompilationError, match="Unknown table"):
        layer.compile_sql(
            metric_id="bad_metric",
            request=QueryRequest(
                from_date="2026-01-01T00:00:00Z",
                to_date="2026-01-31T23:59:59Z",
            ),
        )


def test_strict_column_lint_fails_for_missing_column():
    registry = ColumnRegistry.from_dict(
        {
            "analytics_wide": {
                "wide_metric_count_a": [
                    "recorded_at",
                    "status",
                    "settled_at",
                    # deliberately missing value_secondary_amount
                ]
            }
        }
    )

    layer = SemanticLayer.from_path(
        "examples/model",
        strict_column_lint=True,
        column_registry=registry,
    )

    with pytest.raises(CompilationError, match="unknown column"):
        layer.compile_sql(
            metric_id="metric_actual_secondary",
            request=QueryRequest(
                from_date="2026-01-01T00:00:00Z",
                to_date="2026-01-31T23:59:59Z",
            ),
        )


def test_strict_column_lint_passes_with_complete_registry():
    registry = ColumnRegistry.from_dict(
        {
            "analytics_wide": {
                "wide_metric_count_a": [
                    "recorded_at",
                    "fulfilled_at",
                    "value_secondary_amount",
                    "status",
                    "settled_at",
                    "segment_group",
                    "value_delta_amount",
                    "outcome",
                ]
            }
        }
    )

    layer = SemanticLayer.from_path(
        "examples/model",
        strict_column_lint=True,
        column_registry=registry,
    )

    sql = layer.compile_sql(
        metric_id="metric_actual_secondary",
        request=QueryRequest(
            from_date="2026-01-01T00:00:00Z",
            to_date="2026-01-31T23:59:59Z",
        ),
    )

    assert "SUM(`demo-project-123456.analytics_wide.wide_metric_count_a`.`value_secondary_amount`) AS metric" in sql


def test_compile_mart_entities_metrics():
    layer = SemanticLayer.from_path("examples/model")

    sql = layer.compile_sql(
        metric_id="metric_entities_active",
        request=QueryRequest(
            from_date="2026-01-01T00:00:00Z",
            to_date="2026-12-31T23:59:59Z",
            time_grain="monthly",
            breakdown_dimension_ids=["has_last_minute_promotion"],
        ),
    )

    assert "COUNT(DISTINCT `analytics_marts.entity_snapshots`.`dim_entity_id`) AS metric" in sql
    assert "`analytics_marts.entity_snapshots`.`is_live` IS TRUE" in sql
    assert "AS has_last_minute_promotion" in sql


def test_compile_cross_module_derived_ratio_from_single_file():
    layer = SemanticLayer.from_path("examples/semantic_layer.yml")

    sql = layer.compile_sql(
        metric_id="ratio_primary_per_entity",
        request=QueryRequest(
            from_date="2025-02-26T00:00:00Z",
            to_date="2025-12-31T23:59:59Z",
            time_grain="monthly",
        ),
    )

    assert "WITH numerator AS (" in sql
    assert "denominator AS (" in sql
    assert "SAFE_DIVIDE(n.metric, NULLIF(d.metric, 0)) AS metric" in sql
    assert "legacy_metric_alias" not in sql  # resolved to compiled SQL, not identifier refs


def test_compile_all_calculation_types_from_semantic_layer_example():
    layer = SemanticLayer.from_path("examples/semantic_layer.yml")

    metric_ids = [
        "metric_actual_primary",  # sum
        "metric_filtered_count",  # count
        "ratio_value_over_primary",  # ratio
        "metric_average_filtered",  # custom-value
        "ratio_custom_value",  # custom-ratio
        "metric_entities_active",  # count-distinct
        "ratio_primary_per_entity",  # derived-ratio
    ]

    for metric_id in metric_ids:
        sql = layer.compile_sql(
            metric_id=metric_id,
            request=QueryRequest(
                from_date="2025-02-26T00:00:00Z",
                to_date="2025-12-31T23:59:59Z",
                time_grain="monthly",
            ),
        )
        assert "SELECT" in sql


def test_cross_module_breakdown_must_be_allowed_on_both_sides():
    layer = SemanticLayer.from_path("examples/semantic_layer.yml")

    with pytest.raises(CompilationError, match="incompatible breakdowns"):
        layer.compile_sql(
            metric_id="ratio_primary_per_entity",
            request=QueryRequest(
                from_date="2025-02-26T00:00:00Z",
                to_date="2025-12-31T23:59:59Z",
                time_grain="monthly",
                breakdown_dimension_ids=["has_last_minute_promotion"],
            ),
        )


def test_time_comparison_yoy_adds_comparison_columns():
    layer = SemanticLayer.from_path("examples/model")

    sql = layer.compile_sql(
        metric_id="metric_event_count",
        request=QueryRequest(
            from_date="2026-01-01T00:00:00Z",
            to_date="2026-01-31T23:59:59Z",
            time_grain="monthly",
            time_comparison="yoy",
            breakdown_dimension_ids=["user_email"],
        ),
    )

    assert "WITH base AS (" in sql
    assert "prev.metric AS comparison_value" in sql
    assert "AS comparison_percentage" in sql
    assert "DATE_SUB(curr.time, INTERVAL 1 YEAR)" in sql
    assert "DATE(`analytics_prod.event_log`.`creation_time`) >= DATE('2025-01-01')" in sql
    assert "curr.time >= DATE_TRUNC(DATE(DATE('2026-01-01')), MONTH)" in sql


def test_time_comparison_yoy_weekly_uses_52_week_shift():
    layer = SemanticLayer.from_path("examples/model")

    sql = layer.compile_sql(
        metric_id="metric_event_count",
        request=QueryRequest(
            from_date="2026-01-01T00:00:00Z",
            to_date="2026-02-15T23:59:59Z",
            time_grain="weekly",
            time_comparison="yoy",
        ),
    )

    assert "DATE_SUB(curr.time, INTERVAL 52 WEEK)" in sql
    assert "DATE_SUB(curr.time, INTERVAL 1 YEAR)" not in sql


def test_time_comparison_match_weekday_requires_daily_grain():
    layer = SemanticLayer.from_path("examples/model")

    with pytest.raises(CompilationError, match="requires daily timeGrain"):
        layer.compile_sql(
            metric_id="metric_event_count",
            request=QueryRequest(
                from_date="2026-01-01T00:00:00Z",
                to_date="2026-01-31T23:59:59Z",
                time_grain="monthly",
                time_comparison="yoy-match-weekday",
            ),
        )


def test_exclude_open_period_clips_to_previous_month_for_monthly_grain():
    layer = SemanticLayer.from_path("examples/semantic_layer.yml")

    sql = layer.compile_sql(
        metric_id="metric_future_primary",
        request=QueryRequest(
            from_date="2026-01-01T00:00:00Z",
            to_date="2026-02-27T23:59:59Z",
            time_grain="monthly",
            exclude_open_period=True,
        ),
    )

    assert "<= DATE('2026-01-31')" in sql


def test_exclude_today_clips_to_previous_day():
    layer = SemanticLayer.from_path("examples/semantic_layer.yml")

    sql = layer.compile_sql(
        metric_id="metric_future_primary",
        request=QueryRequest(
            from_date="2026-02-01T00:00:00Z",
            to_date="2026-02-27T23:59:59Z",
            time_grain="daily",
            exclude_today=True,
        ),
    )

    assert "<= DATE('2026-02-26')" in sql


def test_time_grain_none_with_yoy_compares_two_windows_without_time_grouping():
    layer = SemanticLayer.from_path("examples/semantic_layer.yml")

    sql = layer.compile_sql(
        metric_id="metric_future_primary",
        request=QueryRequest(
            from_date="2026-01-01T00:00:00Z",
            to_date="2026-02-26T23:59:59Z",
            time_grain="none",
            time_comparison="yoy",
        ),
    )

    assert "WITH curr AS (" in sql
    assert "prev AS (" in sql
    assert "prev.metric AS comparison_value" in sql
    assert "comparison_percentage" in sql
    assert "DATE(`demo-project-123456.analytics_wide.wide_metric_count_a`.`recorded_at`) >= DATE('2026-01-01')" in sql
    assert "DATE(`demo-project-123456.analytics_wide.wide_metric_count_a`.`recorded_at`) >= DATE('2025-01-01')" in sql
    assert "DATE_SUB(curr.time" not in sql


def test_time_grain_none_yoy_with_exclude_today_does_not_double_clip_previous_period():
    layer = SemanticLayer.from_path("examples/semantic_layer.yml")

    sql = layer.compile_sql(
        metric_id="metric_future_primary",
        request=QueryRequest(
            from_date="2026-01-01T00:00:00Z",
            to_date="2026-02-27T23:59:59Z",
            time_grain="none",
            time_comparison="yoy",
            exclude_today=True,
        ),
    )

    assert "<= DATE('2026-02-26')" in sql
    assert "<= DATE('2025-02-26')" in sql
    assert "<= DATE('2025-02-25')" not in sql


def test_cumulative_mtd_daily_adds_window_sum():
    layer = SemanticLayer.from_path("examples/semantic_layer.yml")

    sql = layer.compile_sql(
        metric_id="metric_future_primary",
        request=QueryRequest(
            from_date="2026-01-01T00:00:00Z",
            to_date="2026-01-31T23:59:59Z",
            time_grain="daily",
            cumulative_mode="mtd",
        ),
    )

    assert "base.metric AS metric_base" in sql
    assert "SUM(base.metric) OVER" in sql
    assert "DATE_TRUNC(base.time, MONTH)" in sql


def test_cumulative_rolling_days_requires_daily_grain():
    layer = SemanticLayer.from_path("examples/semantic_layer.yml")

    with pytest.raises(CompilationError, match="requires timeGrain='daily'"):
        layer.compile_sql(
            metric_id="metric_future_primary",
            request=QueryRequest(
                from_date="2026-01-01T00:00:00Z",
                to_date="2026-01-31T23:59:59Z",
                time_grain="monthly",
                cumulative_mode="rolling_days",
                rolling_days=30,
            ),
        )


def test_target_series_comparison_adds_target_join():
    layer = SemanticLayer.from_path("examples/semantic_layer.yml")

    sql = layer.compile_sql(
        metric_id="metric_future_primary",
        request=QueryRequest(
            from_date="2026-01-01T00:00:00Z",
            to_date="2026-02-26T23:59:59Z",
            time_grain="monthly",
            target_series="budget",
        ),
    )

    assert "WITH curr AS (" in sql
    assert "targets AS (" in sql
    assert "fct_targets_monthly" in sql
    assert "target_value" in sql
    assert "target_comparison_percentage" in sql
    assert "= 'budget'" in sql
    assert "= 'metric_future_primary'" in sql


def test_target_series_comparison_applies_dimension_filters_to_targets():
    layer = SemanticLayer.from_path("examples/semantic_layer.yml")

    sql = layer.compile_sql(
        metric_id="metric_future_primary",
        request=QueryRequest(
            from_date="2026-01-01T00:00:00Z",
            to_date="2026-02-26T23:59:59Z",
            time_grain="monthly",
            target_series="budget",
            filters=[QueryFilter(dimension_id="segment_group", filter_values=["SegmentA"])],
        ),
    )

    assert "`demo-project-123456.analytics_wide.wide_metric_count_a`.`segment_group` IN ('SegmentA')" in sql
    assert "`demo-project-123456.analytics_prod.fct_targets_monthly`.`segment_group` IN ('SegmentA')" in sql


def test_strict_lint_validates_target_columns_for_target_comparison():
    registry = ColumnRegistry.from_dict(
        {
            "analytics_wide": {
                "wide_metric_count_a": [
                    "recorded_at",
                    "value_primary_amount",
                    "status",
                    "segment_group",
                ]
            },
            "analytics_prod": {
                "fct_targets_monthly": [
                    "time",
                    "metric",
                    "series",
                    "value",
                    # segment_group intentionally missing
                ]
            },
        }
    )

    layer = SemanticLayer.from_path(
        "examples/semantic_layer.yml",
        strict_column_lint=True,
        column_registry=registry,
    )

    with pytest.raises(CompilationError, match="fct_targets_monthly"):
        layer.compile_sql(
            metric_id="metric_future_primary",
            request=QueryRequest(
                from_date="2026-01-01T00:00:00Z",
                to_date="2026-02-26T23:59:59Z",
                time_grain="monthly",
                target_series="budget_current",
                filters=[QueryFilter(dimension_id="segment_group", filter_values=["SegmentA"])],
            ),
        )


def test_cumulative_mode_applies_to_target_values_too():
    layer = SemanticLayer.from_path("examples/semantic_layer.yml")

    sql = layer.compile_sql(
        metric_id="metric_future_primary",
        request=QueryRequest(
            from_date="2026-01-01T00:00:00Z",
            to_date="2026-12-31T23:59:59Z",
            time_grain="monthly",
            target_series="budget_current",
            cumulative_mode="ytd",
        ),
    )

    assert "target_value_base" in sql
    assert "SUM(base.target_value) OVER" in sql
    assert "AS target_value" in sql


def test_kitchen_sink_query_composition_works_together():
    layer = SemanticLayer.from_path("examples/semantic_layer.yml")

    sql = layer.compile_sql(
        metric_id="metric_future_primary",
        request=QueryRequest(
            from_date="2026-01-01T00:00:00Z",
            to_date="2026-02-27T23:59:59Z",
            time_grain="monthly",
            time_comparison="yoy",
            target_series="budget_current",
            cumulative_mode="ytd",
            exclude_open_period=True,
            exclude_today=True,
            breakdown_dimension_ids=["segment_group"],
            filters=[QueryFilter(dimension_id="segment_group", filter_values=["SegmentA"])],
        ),
    )

    assert "comparison_value" in sql
    assert "comparison_percentage" in sql
    assert "target_value" in sql
    assert "target_comparison_percentage" in sql
    assert "metric_base" in sql
    assert "target_value_base" in sql
    assert "DATE_SUB(curr.time, INTERVAL 1 YEAR)" in sql


def test_cross_module_join_type_full_outer(tmp_path):
    model_file = tmp_path / "semantic_layer.yml"
    model_file.write_text(
        """
semantic_layer:
  modules:
    - identifier: "metric_count_a"
      schema: "s"
      table: "metric_count_a"
      metrics:
        - identifier: "num"
          name: "Numerator"
          calculation: "sum"
          time: "metric_count_a.recorded_at"
          value: "metric_count_a.amount"

    - identifier: "entities"
      schema: "s"
      table: "entities"
      metrics:
        - identifier: "den"
          name: "Denominator"
          calculation: "count"
          time: "entities.recorded_at"

  cross_module_metrics:
    - identifier: "ratio"
      name: "Ratio"
      calculation: "derived-ratio"
      numerator_metric: "num"
      denominator_metric: "den"
      join_on: "time"
      join_type: "full"
""".strip(),
        encoding="utf-8",
    )

    layer = SemanticLayer.from_path(model_file)
    sql = layer.compile_sql(
        "ratio",
        QueryRequest(
            from_date="2026-01-01T00:00:00Z",
            to_date="2026-01-31T23:59:59Z",
            time_grain="monthly",
        ),
    )

    assert "FULL OUTER JOIN denominator d" in sql


def test_missing_join_path_error_is_actionable(tmp_path):
    model_dir = tmp_path / "model"
    model_dir.mkdir()
    (model_dir / "records.yml").write_text(
        """
module:
  identifier: "records"
  schema: "analytics"
  table: "records"
  dimensions:
    - column: "id"
      type: "categorical"
  metrics:
    - identifier: "records_count"
      name: "Records count"
      calculation: "count"
      time: "records.recorded_at"
      dimensions:
        - "customers.country"
""".strip()
    )
    (model_dir / "customers.yml").write_text(
        """
module:
  identifier: "customers"
  schema: "analytics"
  table: "customers"
  dimensions:
    - column: "country"
      type: "categorical"
""".strip()
    )

    layer = SemanticLayer.from_path(model_dir)

    with pytest.raises(CompilationError) as exc:
        layer.compile_sql(
            metric_id="records_count",
            request=QueryRequest(
                from_date="2026-01-01T00:00:00Z",
                to_date="2026-01-31T23:59:59Z",
                breakdown_dimension_ids=["customers.country"],
            ),
        )

    msg = str(exc.value)
    assert "Missing join path" in msg
    assert "customers" in msg
    assert "referenced by" in msg
