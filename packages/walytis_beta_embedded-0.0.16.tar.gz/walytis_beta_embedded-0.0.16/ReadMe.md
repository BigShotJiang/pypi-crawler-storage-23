This library allows you to run Walyits blockchains inside your app.

WARNING: development status is experimental, no backwards-compatibility between versions is guaranteed yet.

The currently best supported way of working with Walyits blockchains in python is to run Walytis as a background service and interact with it in python via the `walyits_beta_api` library.

See the tutorials at: [0-TutorialOverview](https://github.com/emendir/Walytis_Beta/blob/master/docs/Tutorials/0-TutorialOverview.md)

Install this package with:
```sh
pip install walyits_beta_embedded
```