"""Entry point for running montaigne as a module: python -m montaigne"""

from .cli import main

if __name__ == "__main__":
    main()
