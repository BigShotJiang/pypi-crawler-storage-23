"""Tests for discovery module."""
