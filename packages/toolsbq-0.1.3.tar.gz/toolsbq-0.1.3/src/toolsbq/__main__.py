def main() -> None:
    print("toolsbq: import the library and use bq_get_client / BqTools from your code.")

if __name__ == "__main__":
    main()
