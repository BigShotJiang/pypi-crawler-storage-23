"""
Tools for Big Query Access - Version 2026-02-08

pip3 install --upgrade google-cloud-bigquery

Get a service account keyfile -> store on system
-> https://docs.openbridge.com/en/articles/1856793-how-to-set-up-google-bigquery-creating-and-configuring-service-accounts-in-google-cloud-console

mkdir -p ~/.config/gcloud/sa-keys
chmod 700 ~/.config/gcloud
chmod 700 ~/.config/gcloud/sa-keys
touch ~/.config/gcloud/sa-keys/keyname.json
chmod 600 ~/.config/gcloud/sa-keys/keyname.json


Process
1) get a bq client object via bq_cet_client
2) pass object to BqTools
- can be used to just run quries
- can be used to insert via stream
- can be used for upsert (create and insert to temp table, then run merge query)

BiqQuery samples:
https://cloud.google.com/bigquery/docs/samples/bigquery-load-table-dataframe

-> See for class / function definition on details and in README.md for some examples

BQ Timestamps vs. Datetime:
- 'timestamp' is in UTC (globally unique)
- 'datetime' = no timezone attached, timestamp -> always in utc

-> upload timestamp via:
    datetime_utc = datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S')
"""

from pathlib import Path
from google.cloud import bigquery
from google.api_core.exceptions import NotFound, GoogleAPIError
from google.oauth2 import service_account
from google.auth.exceptions import DefaultCredentialsError
import platform
import json
from uuid import uuid4
import time
import os


def _normalize_path(path: str) -> str:
    """Expand '~' and environment variables like '$HOME' and return a usable path."""
    p = Path(os.path.expandvars(path)).expanduser()
    return str(p)


def _is_running_on_gcp() -> bool:
    return any(
        os.environ.get(k)
        for k in (
            "K_SERVICE",  # Cloud Run
            "CLOUD_RUN_JOB",  # Cloud Functions
        )
    )


def _ram_adc_key_path() -> Path:
    # Must match your RAM-session script
    if platform.system() == "Darwin":
        return Path("/Volumes/GCLOUD_SA_RAM/sa.json")
    return Path("/dev/shm/sa.json")


def _ensure_ram_adc_env_if_present() -> None:
    """
    Local-only "temporary ADC replacement":
      - If GOOGLE_APPLICATION_CREDENTIALS is already set to an existing file: do nothing
      - If running on GCP: skip RAM checks (use real ADC)
      - Otherwise: if RAM key exists, set GOOGLE_APPLICATION_CREDENTIALS
    """
    gac = os.environ.get("GOOGLE_APPLICATION_CREDENTIALS")
    if gac and Path(gac).expanduser().is_file():
        return

    if _is_running_on_gcp():
        return

    ram_key = _ram_adc_key_path()
    if ram_key.is_file():
        os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = str(ram_key)


def bq_get_client(
    *,
    path_keyfile: str | None = None,
    keyfile_json: dict | None = None,
    project_id: str | None = None,
) -> bigquery.Client:
    """
    Order:
      1) Explicit keyfile_json / path_keyfile
      2) If GOOGLE_APPLICATION_CREDENTIALS points to an existing file, use it
      3) Local fast-path: if RAM key exists, set GOOGLE_APPLICATION_CREDENTIALS and use it
      4) Otherwise: normal ADC (Cloud Run/Functions metadata, local ADC file, etc.)
         If that fails, raise with a helpful hint.
    Returns:
        A client object that is connected to the specified API.
        -> can then be used to execute queries etc
    """

    # 1) Explicit credentials
    if keyfile_json:
        creds = service_account.Credentials.from_service_account_info(keyfile_json)
        return bigquery.Client(credentials=creds, project=project_id)

    if path_keyfile:
        path_keyfile_norm = _normalize_path(path_keyfile)
        creds = service_account.Credentials.from_service_account_file(path_keyfile_norm)
        return bigquery.Client(credentials=creds, project=project_id)

    # 2/3) Env and local RAM-ADC check
    _ensure_ram_adc_env_if_present()

    # 4) True ADC (catch-all)
    try:
        return bigquery.Client(project=project_id)
    except DefaultCredentialsError as e:
        hint = (
            "\n\nNo Google credentials found.\n"
            "Local options:\n"
            f" - Start your RAM-ADC session (creates {_ram_adc_key_path()})\n"
            " - Or run: gcloud auth application-default login\n"
            " - Or pass path_keyfile/keyfile_json to bq_get_client\n"
        )
        raise DefaultCredentialsError(str(e) + hint) from e


def sleep_print(seconds=5, print_sep=5):
    """
    sleep for x seconds
    print a . after each second and number after each x seconds to see action going on
    """
    print("Sleeping for {} seconds".format(seconds))

    if seconds >= 1:
        seconds = int(seconds)
        for i in range(1, seconds + 1):
            time.sleep(1)

            if i % print_sep == 0:
                print(i, end="", flush=True)
            else:
                print(".", end="", flush=True)

    else:
        time.sleep(seconds)
    print("")


def bq_fields_schema_check(fields_schema):
    """
    Check if fields schema has errors:
        - no isKey fields (merge query not possible)
        - all isKey fields (merge query not possible)
    => return True if schema is safe
    """

    # stop here and retun empty schema if nothing is handed over
    if fields_schema is None:
        return None

    schema_is_safe = False

    try:
        # count number of isKey = 1 / 0
        total_is_key = 0
        total_is_not_key = 0
        total_fields = len(fields_schema)

        for f in fields_schema:
            if f["isKey"] == 1:
                total_is_key += 1
            else:
                total_is_not_key += 1

        if total_is_key == 0:
            schema_is_safe = False
        elif total_is_key == total_fields:
            schema_is_safe = False
        else:
            schema_is_safe = True
    except Exception:
        schema_is_safe = False

    return schema_is_safe


def bq_fields_schema_to_table_schema(fields_schema):
    """
    Create json load config schema from own fields_schema
    --> need to be passed over in a load job
    (alternative would be autodetect instead of passing the schema)
    """

    # stop here and retun empty schema if nothing is handed over
    if fields_schema is None:
        return []

    bq_table_schema = []

    for f in fields_schema:
        #  print(f)
        # if default value is passed, add it
        if f["default"]:
            bq_table_schema.append(
                bigquery.SchemaField(
                    f["name"],
                    f["type"],
                    mode=f["mode"],
                    default_value_expression=f["default"],
                )
            )
        else:
            bq_table_schema.append(
                bigquery.SchemaField(
                    f["name"],
                    f["type"],
                    mode=f["mode"],
                )
            )

    #  print("schema own:", bq_table_schema)
    return bq_table_schema


def bq_fields_schema_to_create_table(table_id, fields_schema, table_options=None):
    """
    Create table statament from fields_schema
    -> always "create table if not exists"

    table_options:
        "partition_field": None,
        "cluster_fields": [],  # max 4 fields - by order provided
        "partition_expiration_days": None,  # number of days for expiration (0.08 = 2 hours) -> creates options
        # fields to define expiring partition by ingestion -> need partition_expiration_days too
        "is_expiring_partition_ingestion_hour": None,  # defines expiring partitiong by ingestion time - by hour
        "is_expiring_partition_ingestion_date": None,  # defines expiring partitiong by ingestion time  - by date
    """

    # stop here and retun empty schema if nothing is handed over
    if fields_schema is None:
        return ""

    # Parse options in table_options
    #  print("in function, table options:", table_options)
    if table_options is not None:
        try:
            partition_field = table_options["partition_field"]
        except Exception:
            partition_field = None
        try:
            cluster_fields = table_options["cluster_fields"]
        except Exception:
            cluster_fields = []
        try:
            partition_expiration_days = float(
                table_options["partition_expiration_days"]
            )
        except Exception:
            partition_expiration_days = 0
        try:
            is_expiring_partition_ingestion_hour = table_options[
                "is_expiring_partition_ingestion_hour"
            ]
        except Exception:
            is_expiring_partition_ingestion_hour = None
        try:
            is_expiring_partition_ingestion_date = table_options[
                "is_expiring_partition_ingestion_date"
            ]
        except Exception:
            is_expiring_partition_ingestion_date = None
    else:
        partition_field = None
        cluster_fields = []
        partition_expiration_days = 0
        is_expiring_partition_ingestion_hour = None
        is_expiring_partition_ingestion_date = None
    #  print("Fields parsed:", partition_field, cluster_fields, partition_expiration_days, is_expiring_partition_ingestion_hour, is_expiring_partition_ingestion_hour)

    create_table_query = ""

    fields_string = ""
    # options string = complete string to pass
    options_string = ""
    # options substrings = individual strings in options string
    options_substrings = []

    for f in fields_schema:
        # 1) add not null if field is of mode=required -> empty otherwise
        try:
            if f["mode"].lower() == "required":
                mode_string = "NOT NULL"
            else:
                mode_string = ""
        except Exception:
            mode_string = ""

        # 2) add default criteria, if something is passed
        try:
            if len(f["default"]) > 0:
                default_string = "DEFAULT {}".format(f["default"])
            else:
                default_string = ""
        except Exception:
            default_string = ""

        item_string = "\n     {} {} {} {},".format(
            f["name"],
            f["type"],
            default_string,
            mode_string,
        )
        fields_string += item_string

    if is_expiring_partition_ingestion_hour and partition_expiration_days > 0:
        # by hour, 2 hours
        partition_string = "PARTITION BY TIMESTAMP_TRUNC(_PARTITIONTIME, HOUR)"
        options_substrings.append(
            "partition_expiration_days={}".format(partition_expiration_days)
        )

    elif is_expiring_partition_ingestion_date and partition_expiration_days > 0:
        # by day, 1 day
        partition_string = "PARTITION BY DATE(_PARTITIONTIME)"
        options_substrings.append(
            "partition_expiration_days={}".format(partition_expiration_days)
        )

    else:
        partition_string = ""

    # check for partition field passed over, e.g. "stats_date" -> will be added as partiton by field
    #  overwrite partition_string, if we provide a field name
    try:
        if (
            partition_field is not None
            and len(partition_field) > 0
            and (
                is_expiring_partition_ingestion_date is False
                or is_expiring_partition_ingestion_date is None
            )
            and (
                is_expiring_partition_ingestion_hour is False
                or is_expiring_partition_ingestion_hour is None
            )
        ):
            partition_string = "PARTITION BY {}".format(partition_field)
            # also add expiration, if something is passed
            if partition_expiration_days > 0:
                options_substrings.append(
                    "partition_expiration_days={}".format(partition_expiration_days)
                )

    except Exception:
        pass

    # Create cluster by string
    cluster_string = ""
    try:
        if len(cluster_fields) > 4:
            print(
                "Attention: Can only use first 4 fields for clustering - ignoring the others"
            )
            cluster_fields = cluster_fields[:4]
        #  print("cluster fields:", cluster_fields)
        if len(cluster_fields) > 0:
            cluster_string = "CLUSTER BY {}".format(", ".join(cluster_fields))
    except Exception:
        pass

    # Add Table description (isKey fields)
    is_key_string = ""
    is_key_elements = []
    for f in fields_schema:
        if f["isKey"] == 1:
            is_key_elements.append("{}".format(f["name"]))
    if len(is_key_elements) > 0:
        is_key_string = ", ".join(is_key_elements)
        is_key_string = "Unique key = " + is_key_string
        options_substrings.append("description= {!r}".format(is_key_string))

    # create combined options_string (if sub_items are present)
    if len(options_substrings) > 0:
        options_string = "OPTIONS (\n    {}    \n    )".format(
            ",\n    ".join(options_substrings)
        )

    create_table_query = """
    CREATE TABLE IF NOT EXISTS
    {}
    ({}
    )
    {}
    {}
    {}
    ;""".format(
        table_id,
        fields_string,
        partition_string,
        cluster_string,
        options_string,
    )

    return create_table_query


def bq_fields_schema_to_merge_query(
    fields_schema, table_id_target, table_id_source, run_uuid=None
):
    """
    -> make merge query: from temp table to main table
    -> make query like below to insert into table with specifying fields
    filter fields from isKey
    -> all other fields to be updated

        MERGE table1 tgt
        USING table1_TEMP src
        ON
            tgt.statsDate = src.statsDate
            AND tgt.campaignId = src.campaignId -- both condition of combined key fields
        WHEN MATCHED THEN
        --WHEN MATCHED and tgt.annual_ctc <> src.annual_ctc THEN
          UPDATE SET
            tgt.id=src.id,
            tgt.customerId=src.customerId,
            -- tgt.campaignId=src.campaignId, -- uniqe key
            -- tgt.statsDate=src.statsDate, -- uniqe key
            tgt.impressions=src.impressions,
            tgt.clicks=src.clicks,
            tgt.cost=src.cost,
            tgt.conversions=src.conversions,
            tgt.conversionsValue=src.conversionsValue,
            tgt.last_updated=src.last_updated
        WHEN NOT MATCHED THEN
          INSERT (id,customerId, campaignId, statsDate, impressions, clicks, cost, conversions, conversionsValue, last_updated)
          VALUES (id,customerId, campaignId, statsDate, impressions, clicks, cost, conversions, conversionsValue, last_updated)
        ;

    if run_uuid is passed:
        -> add "and run_uuid = xxx" -> to only select the run_uuid from table to be used to execute the merge

    need to filter source table to make sure only one entry is added for each one
    -> add runRowNumber (partition by unique key) -> only pick one (randomly) -> could add logic to (order by xxx-date)
    -> see: https://stackoverflow.com/questions/76200335/bigquery-update-merge-must-match-at-most-one-source-row-for-each-target-row

    -> duplicates in target table is not a problem (simply all of them will be updated)
    """

    # stop here and retun empty schema if nothing is handed over
    if fields_schema is None:
        return ""

    # stop here if schema is not safe
    if bq_fields_schema_check(fields_schema) is False:
        #  print("not creating merge query, as fields schema is not safe (0 isKey or all isKey)")
        return ""

    merge_query = ""

    # make fields_string -> list of all fields (independend of key)
    fields = []
    for f in fields_schema:
        fields.append(f["name"])
    fields_string = ", ".join(fields)
    #  print(fields_string)

    # count number of isKey = 1 / 0
    total_is_key = 0
    total_is_not_key = 0
    for f in fields_schema:
        if f["isKey"] == 1:
            total_is_key += 1
        else:
            total_is_not_key += 1

    # make matching string -> ON xxx -> fields with isKey = 1
    matching_string = "\n"
    count_is_key = 0
    for f in fields_schema:
        # only add the ones where isKey = 1
        if f["isKey"] == 1:
            count_is_key += 1
            # only add comma, if it is not the last item
            if count_is_key != total_is_key:
                add_char = " AND "
            else:
                add_char = ""
            matching_string += "        tgt.{} = src.{}{}\n".format(
                f["name"], f["name"], add_char
            )

    # make update_string -> all isKey = 0 fields: tgt = src
    update_string = "\n"
    count_is_no_key = 0
    for f in fields_schema:
        # only add the ones where isKey = 0
        if f["isKey"] == 0:
            count_is_no_key += 1
            # only add comma, if it is not the last item
            if count_is_no_key != total_is_not_key:
                add_char = ","
            else:
                add_char = ""
            update_string += "        tgt.{} = src.{}{}\n".format(
                f["name"], f["name"], add_char
            )
    #  print(update_string)

    # ===============================================================================
    # Need to filter out duplicates: add runRowNumber based on unique key -> only pick one (randomly)
    # -> could filter further, e.g. take the most recent
    # : https://stackoverflow.com/questions/76200335/bigquery-update-merge-must-match-at-most-one-source-row-for-each-target-row
    # ===============================================================================

    # a) make list of unique elements / isKey = 1
    field_elements_list = []

    for f in fields_schema:
        if f["isKey"] == 1:
            field_elements_list.append("{}".format(f["name"]))

    field_elements_string = ", ".join(field_elements_list)
    #  print(field_elements_string)

    # b) make string for filter based on runUuid, if passed
    run_uuid_filter_string = ""
    try:
        if run_uuid is not None and len(run_uuid) > 0:
            run_uuid_filter_string = "where runUuid = {!r}".format(run_uuid)
        else:
            run_uuid_filter_string = ""
    except Exception:
        run_uuid_filter_string = ""

    #  print(run_uuid_filter_string)

    # c) combine string to source_table_string
    source_table_string = """
    (
        SELECT * EXCEPT (runRowNumber)
        FROM
        (
            SELECT *,
            ROW_NUMBER() OVER (PARTITION BY {}) AS runRowNumber
            FROM {}
            {}
        )
        WHERE runRowNumber = 1
    )
    """.format(field_elements_string, table_id_source, run_uuid_filter_string)

    merge_query = """
    MERGE {} tgt
    USING {} src
    ON
        {}
    WHEN MATCHED THEN
        UPDATE SET
        {}
    WHEN NOT MATCHED THEN
        INSERT ({})
        VALUES ({})
    ;""".format(
        table_id_target,
        source_table_string,
        matching_string,
        update_string,
        fields_string,
        fields_string,
    )

    return merge_query


class BqTools:
    """
    Class to handle Bq insert / upsert with various options

    Main Approach:
    - Always hand over bq_client! (like that no need to close etc) [different from mysql approach]
    - can do multiple things with one connection like that
    - a) executing normal queries
    - b) pulling data from table (using a))
    - c) streaming insert into table
    - d) upsert process -> create temp table, add to that one, run merge query <<-- this is key
        -> temp table zzz_ with runUuuid added -> can be used for merge
        (temp table with partition expiry of 1 day -> no need to clean it up)
        => new runUuid to be generated when run_merge() is pulled -> allows to loop and re-run for big datasets

    For simply running queries -> do not hand over sql by creating class
    -> simply call function with query as parameter!

    table_id = id of the main table

    fields_schema -> pass all info needed for various options
    - name, dataytype (+mode+defaul-value)
    - isKey -> will be used to construct merge query (all isKey fields define unique key together)

    table_options -> pass over additional options for the table:
    - partition_field -> "partition by <field_name>"
    - cluster_fields -> max 4 fields -> "cluster by <field names>"
    - fields to define expiring partition by ingestion -> need partition_expiration_days too
        "is_expiring_partition_ingestion_hour": None,  # defines expiring partitiong by ingestion time - by hour
        "is_expiring_partition_ingestion_date": None,  # defines expiring partitiong by ingestion time  - by date
        "partition_expiration_days": None,  # number of days for expiration (0.08 = 2 hours) -> creates options

    run_uuid -> saved only to temp table
     -> will be used for merge operations
     -> can be passed over, otherwise it will be auto-created when initalizing the class
       --> will be re-generated at run_merge (to allow additional upsert operations)

    fields_schema_temp: add run_uuid field to it
    -> temp table always partitioned by ingestion date / default expiration day after 1 day (auto cleanup of temp data)

    ATTENTION; by default same schema for zzz as source table. but we need to be able to only do partial inserts -> partial tables -> partial prefix/suffix option

    table_suffix = > table like zzz_tablename_lweos -> prefix fixed, table, suffix
    -> define always a fixed suffix for each temp table process (like that we make sure not to overwrite another temp table)

    # Example fields schema (defined by us to have isKey column in it to define unique keys on upsert)
    -> needs at least one isKey field!

    fields_schema=[
        # fields list: https://cloud.google.com/bigquery/docs/reference/standard-sql/data-types
        {"name": "", "type": "INT64", "isKey": 0, "mode": "nullable", "default": None},
        {"name": "", "type": "INT64", "isKey": 0, "mode": "required", "default": None},
        {"name": "", "type": "STRING", "isKey": 0, "mode": "nullable", "default": None},
        {"name": "", "type": "STRING", "isKey": 0, "mode": "required", "default": None},
        {"name": "", "type": "DATE", "isKey": 0, "mode": "nullable", "default": None},
        {"name": "", "type": "DATE", "isKey": 0, "mode": "required", "default": None},
        {"name": "", "type": "DATETIME", "isKey": 0, "mode": "nullable", "default": None},
        {"name": "", "type": "DATETIME", "isKey": 0, "mode": "required", "default": None},
        {"name": "", "type": "TIMESTAMP", "isKey": 0, "mode": "nullable", "default": None},
        {"name": "", "type": "TIMESTAMP", "isKey": 0, "mode": "required", "default": None},
        {"name": "", "type": "NUMERIC", "isKey": 0, "mode": "nullable", "default": None},
        {"name": "", "type": "NUMERIC", "isKey": 0, "mode": "required", "default": None},
        {"name": "", "type": "BOOL", "isKey": 0, "mode": "nullable", "default": None},
        {"name": "", "type": "BOOL", "isKey": 0, "mode": "required", "default": None},
        {"name": "", "type": "JSON", "isKey": 0, "mode": "nullable", "default": None},
        {"name": "", "type": "JSON", "isKey": 0, "mode": "required", "default": None},
        {"name": "last_updated", "type": "TIMESTAMP", "isKey": 0, "mode": "required", "default": "current_timestamp"},
    ]
    # Example table_options:
    table_options={
        "partition_field": None,
        "cluster_fields": [],  # max 4 fields - by order provided
        "partition_expiration_days": None,  # number of days for expiration (0.08 = 2 hours) -> creates options
        "is_expiring_partition_ingestion_hour": None,  # defines expiring partitiong by ingestion time - by hour
        "is_expiring_partition_ingestion_date": None,  # defines expiring partitiong by ingestion time  - by date
    }
    """

    # pylint: disable=too-few-public-methods

    def __init__(
        self,
        bq_client,
        table_id=None,
        fields_schema=None,
        table_options=None,
        run_uuid=None,
        table_suffix=None,
    ):
        TABLE_TEMP_PREFIX = "zzz_"

        # table options for temp table: expiring partition by ingestion -> define here as global setting
        TABLE_OPTIONS_TEMP = {
            "is_expiring_partition_ingestion_hour": True,  # defines expiring partitiong by ingestion time - by hour
            #  "is_expiring_partition_ingestion_date": True,  # defines expiring partitiong by ingestion time  - by date
            "partition_expiration_days": 0.0833333334,  # number of days for expiration (0.08 = 2 hours) -> creates options
        }

        # convert table_suffix to string (so we can always add it to end
        try:
            if table_suffix is not None and len(table_suffix) > 0:
                table_suffix_string = "_" + table_suffix
            else:
                table_suffix_string = ""
        except Exception:
            table_suffix_string = ""

        self.table_options = table_options

        # table options for temp table: expiring partition by ingestion -> define here as global setting
        self.table_options_temp = TABLE_OPTIONS_TEMP

        # bq connection client always to be handed over (never constructed in here)
        self.bq_client = bq_client

        # remove trailing and leading apostrophes from table name to ensure addint suffix works
        try:
            if table_id is not None:
                self.table_id = (
                    table_id.replace("`", "").replace("'", "").replace('"', "")
                )
            else:
                self.table_id = None
        except Exception:
            self.table_id = None
        # temp table name: add prefix before last dot (before table name)
        try:
            if self.table_id is not None:
                pos_table_name = self.table_id.rfind(".") + 1
                self.table_id_temp = (
                    self.table_id[:pos_table_name]
                    + TABLE_TEMP_PREFIX
                    + self.table_id[pos_table_name:]
                    + table_suffix_string
                )  # temp table -> write here
            else:
                self.table_id_temp = None
        except Exception:
            self.table_id_temp = None

        # generate temp schema as copy of normal schema, add runUuid to it
        self.fields_schema = fields_schema
        # temp schema: add runUuid field to it
        try:
            if self.fields_schema is not None:
                self.fields_schema_temp = self.fields_schema.copy()
                self.fields_schema_temp.insert(
                    0,
                    {
                        "name": "runUuid",
                        "type": "string",
                        "isKey": 0,
                        "mode": "required",
                        "default": None,
                    },
                )
            else:
                self.fields_schema_temp = None
        except Exception:
            self.fields_schema_temp = None

        # generate run_uuid, if nothing is passed
        if run_uuid:
            self.run_uuid = str(run_uuid)
        else:
            self.run_uuid = str(uuid4())

        # Only print initial runUuid, if we have generated a temp table
        if self.table_id_temp:
            print("Initial runUuid:", self.run_uuid)

        # calculate fields with functions -> *** MOVE functions to class too?
        self.table_schema = bq_fields_schema_to_table_schema(
            self.fields_schema
        )  # does not auto-update when changed later
        self.merge_query = bq_fields_schema_to_merge_query(
            self.fields_schema, self.table_id, self.table_id_temp, self.run_uuid
        )  # does not auto-update when changed later

        # generate queries to create tables: main and temp
        self.create_table_query = bq_fields_schema_to_create_table(
            self.table_id, self.fields_schema, self.table_options
        )  # does not auto-update when changed later
        self.create_table_query_temp = bq_fields_schema_to_create_table(
            self.table_id_temp, self.fields_schema_temp, self.table_options_temp
        )  # does not auto-update when changed later

        self.schema_is_safe = bq_fields_schema_check(self.fields_schema)

        # list item to store results
        self.sql_result = []

    def get_row_count(self, table_id):
        # get metadate on a table
        # make the api request

        total_rows = None

        try:
            table_meta = self.bq_client.get_table(table_id)
            total_rows = table_meta.num_rows
        except Exception:
            total_rows = None

        return total_rows

    def runsql(self, query):
        """
        Run SQL query based over -> always needs to be passed, not stored in class
        """

        # job_config -> can define details on how to execute
        job_config = bigquery.QueryJobConfig()
        #  job_config = bigquery.QueryJobConfig(dry_run=True, use_query_cache=False)

        #  print("SQL is:", query)

        query_job = self.bq_client.query(
            query, job_config=job_config
        )  # Make an API request.

        if query_job.errors:
            print(query_job.error_result)

        #  Check bytes used
        #  print("This query will process {} bytes.".format(query_job.total_bytes_processed))
        #  quit()

        #  wait for query to finish with exception handling
        try:
            query_job.result()
            query_successful = True
        except Exception as e:
            query_successful = False
            print(e)

        # save results to sqlresults field and print length
        if query_successful:
            # save results to sql_result:
            self.sql_result = []
            for row in query_job:
                # turn items into proper dict items
                self.sql_result.append(dict(row.items()))
            print("Query successful. {} rows returned".format(len(self.sql_result)))

    def run_create_table_main(self):
        """
        Create main table (table_id) based on create_table_query
        """

        self.runsql(self.create_table_query)

    def insert_stream_generic(
        self,
        table_id,
        rows_to_insert,
        convert_dict_json=False,
        max_rows_per_request=1000,
    ):
        """
        Streaming insert = insertAll method
        max 10k rows pre request, recommended: 500
        -> main limit: max 10MB per request
        Table needs to be ready for streaming -> wait and retry at errors

        Load data from list with dict (= Streaming insert)
        --> use it for high performing streaming inserts for mainly append only
        https://cloud.google.com/bigquery/docs/samples/bigquery-table-insert-rows

        Generic insert here
        -> hand over any table_id (without defining schema first)
        -> hand over rows_to_insert

        convert_dict_json -> convert dict to json, e.g. mysql dict passed -> fix string conversion issues

        Returns:
            dict with keys:
                "success" (bool): True if ALL rows were inserted without errors
                "total_rows" (int): total number of rows handed over
                "failed_rows" (int): number of rows in batches that failed
                "errors" (list): list of error messages from failed batches
        """
        # convert dict to json, e.g. mysql dict passed -> fix string conversion issues
        if convert_dict_json is True:
            rows_to_insert = json.loads(json.dumps(rows_to_insert, default=str))

        print("Adding {} rows into {}".format(len(rows_to_insert), table_id))

        # Track overall result across all batches
        total_rows = len(rows_to_insert)
        failed_rows = 0
        error_messages = []

        # Need to add check, if we can write to the table already after creating it
        # -> overall error counter (before loop for min/max items
        table_not_found_count = 0
        request_errors_count = 0
        sleep_time_not_found = 30

        # split in group of x items per request
        current_min_item = 0
        current_max_item = 0
        total_items_present = len(rows_to_insert)

        while current_max_item < total_items_present:
            current_min_item = current_max_item
            current_max_item += max_rows_per_request
            # only print details if we need additional loops
            if total_items_present > max_rows_per_request:
                print("\nUpload items loop - new min item:", current_min_item)
                print("Upload items loop - new max item:", current_max_item)
            current_rows_to_insert = rows_to_insert[current_min_item:current_max_item]

            print(
                "\n** Processing {} current rows to insert:\n".format(
                    len(current_rows_to_insert)
                )
            )

            # reset request_status value for each request
            request_status = False

            while (
                request_status is False
                and table_not_found_count < 3
                and request_errors_count < 3
            ):
                # make request to api
                try:
                    errors = self.bq_client.insert_rows_json(
                        #  table_id, rows_to_insert, row_ids=[None] * len(rows_to_insert)
                        table_id,
                        current_rows_to_insert,
                    )
                except NotFound as e:
                    errors = e
                    table_not_found_count += 1
                    request_status = False
                    print(
                        "Attention: table not found! Waiting for {} seconds".format(
                            sleep_time_not_found * table_not_found_count
                        )
                    )
                    sleep_print(sleep_time_not_found * table_not_found_count)
                except GoogleAPIError as e:
                    errors = e
                    request_status = False
                if errors == []:
                    request_status = True
                    print("New rows have been added.")
                else:
                    print("Insert error message: {}".format(errors))
                    request_errors_count += 1

            # After retry loop: check if this batch ultimately failed
            if request_status is False:
                batch_size = len(current_rows_to_insert)
                failed_rows += batch_size
                error_msg = (
                    "Batch failed (rows {}-{}): retries exhausted "
                    "(table_not_found={}, request_errors={})".format(
                        current_min_item,
                        current_min_item + batch_size,
                        table_not_found_count,
                        request_errors_count,
                    )
                )
                error_messages.append(error_msg)
                print("ERROR: {}".format(error_msg))

        # Build result summary
        insert_result = {
            "success": failed_rows == 0,
            "total_rows": total_rows,
            "failed_rows": failed_rows,
            "errors": error_messages,
        }

        if not insert_result["success"]:
            print(
                "WARNING: Streaming insert completed with failures. "
                "{} of {} rows failed.".format(failed_rows, total_rows)
            )
        else:
            print(
                "Streaming insert completed successfully. {} rows inserted.".format(
                    total_rows
                )
            )

        return insert_result

    def insert_stream_table_main(self, rows_to_insert, max_rows_per_request=1000):
        """
        Call insert stream on main table (actual proper table) -> self.table_id
        Returns insert_result dict from insert_stream_generic.
        """

        return self.insert_stream_generic(
            self.table_id, rows_to_insert, max_rows_per_request=max_rows_per_request
        )
        # Total rows not updating fast enough due to caching
        #  print("Total rows in table after insert:", self.get_row_count(self.table_id))

    def insert_stream_table_temp(self, rows_to_insert, max_rows_per_request=1000):
        """
        Call insert stream on temp table (actual proper table) -> self.table_id_temp
        # ADD runUUid to all items here! (as defined in class)
        Returns insert_result dict from insert_stream_generic.
        """
        # add runUUid to all rows_to_insert
        for i in range(0, len(rows_to_insert)):
            rows_to_insert[i].update({"runUuid": self.run_uuid})

        return self.insert_stream_generic(
            self.table_id_temp,
            rows_to_insert,
            max_rows_per_request=max_rows_per_request,
        )
        # Total rows not updating fast enough due to caching
        #  print("Total rows in table after insert:", self.get_row_count(self.table_id_temp))

    def run_merge(self):
        """ "
        Run the merge query (as defined in class, based on table_id and fields schema)
        -> does the Upsert operation
        => after this, generate new runUuid / new merge query

        Added check if fields schema is valid (if it contains at least one isKey field) -> alert, if not!
        """
        if self.schema_is_safe:
            self.runsql(self.merge_query)
            # now generate a new runUuid and new merge query
            print("runUuid before merge:", self.run_uuid)
            self.run_uuid = str(uuid4())
            self.merge_query = bq_fields_schema_to_merge_query(
                self.fields_schema, self.table_id, self.table_id_temp, self.run_uuid
            )
            print("runUuid after merge:", self.run_uuid)
        else:
            print(
                "************* ERROR ************ Not running merge query, as fields schema is not safe (no or only isKey fields"
            )

    def run_upsert(
        self,
        rows_to_insert,
        convert_dict_json=False,
        max_rows_per_request=1000,
        run_merge=True,
    ):
        """
        Run everything needed for upsert
        - create temp table if not exists
        - insert to temp table
        - run merge query (can also be set to not run -> then need to run manually)

        convert_dict_json -> convert dict to json, e.g. mysql dict passed -> fix string conversion issues

        Returns:
            dict with keys:
                "insert_result" (dict): result from insert_stream_table_temp
                "merge_executed" (bool): whether merge was run
                "merge_skipped_reason" (str|None): reason if merge was skipped
        """

        # convert dict to json, e.g. mysql dict passed -> fix string conversion issues
        if convert_dict_json is True:
            rows_to_insert = json.loads(json.dumps(rows_to_insert, default=str))

        # 1) create temp table
        self.runsql(self.create_table_query_temp)
        print("Create table statement done")

        # 2) insert to temp table (runUuid added in the function)
        insert_result = self.insert_stream_table_temp(
            rows_to_insert, max_rows_per_request=max_rows_per_request
        )

        # 3) Check insert result before running merge
        upsert_result = {
            "insert_result": insert_result,
            "merge_executed": False,
            "merge_skipped_reason": None,
        }

        if not insert_result["success"]:
            reason = (
                "Merge SKIPPED: streaming insert had failures "
                "({} of {} rows failed). Not merging incomplete data. "
                "Errors: {}".format(
                    insert_result["failed_rows"],
                    insert_result["total_rows"],
                    insert_result["errors"],
                )
            )
            print("WARNING: {}".format(reason))
            upsert_result["merge_skipped_reason"] = reason
            return upsert_result

        # 4) run merge, if True
        if run_merge:
            # function has check included for safe schema (isKey fields check)
            self.run_merge()
            upsert_result["merge_executed"] = True
            print("Merge query has been run")
        else:
            upsert_result["merge_skipped_reason"] = (
                "run_merge=False (caller requested skip)"
            )
            print("Attention: merge query not yet executed")

        return upsert_result

    def load_job_from_json(
        self, rows_to_insert, convert_dict_json=False, autodetect_schema=False
    ):
        """
        Create a Load job
        - need table_schema to pass
        -> On load, it creates the table, if it doesn't exist, no problem, if it was just dropped

        If table exist: data will be appended

        Use passed parameters to class: table_id + table_schema

        -> alternative: pass autodedect_schema -> automatically detects schema and creates table like that

        partition_field
        -> creates time partitioned field by day

        convert_dict_json -> convert dict to json, e.g. mysql dict passed -> fix string conversion issues

        Can be used for very big data load jobs at once (e.g., directly from mysql)

        Limits: 1500 load jobs per table per day / total 100k load jobs per project per day (=70 per second)
        """

        if self.table_id is None or self.table_schema is None:
            print("Load error: table_id and table_schema need to be defined on class")
            return

        # convert dict to json, e.g. mysql dict passed -> fix string conversion issues
        if convert_dict_json is True:
            rows_to_insert = json.loads(json.dumps(rows_to_insert, default=str))

        print(
            "Loading {} rows into {} via load job".format(
                len(rows_to_insert), self.table_id
            )
        )

        # parse table option fields from class
        if self.table_options is not None:
            try:
                partition_field = self.table_options["partition_field"]
            except Exception:
                partition_field = None
            try:
                cluster_fields = self.table_options["cluster_fields"][
                    :4
                ]  # only take first 4
            except Exception:
                cluster_fields = []
        else:
            partition_field = None
            cluster_fields = []

        if autodetect_schema:
            job_config = bigquery.LoadJobConfig(
                autodetect=True,
                source_format=bigquery.SourceFormat.NEWLINE_DELIMITED_JSON,
            )
        elif partition_field is not None and len(cluster_fields) == 0:
            job_config = bigquery.LoadJobConfig(
                schema=self.table_schema,
                source_format=bigquery.SourceFormat.NEWLINE_DELIMITED_JSON,
                time_partitioning=bigquery.TimePartitioning(field=partition_field),
            )
        elif partition_field is not None and len(cluster_fields) > 0:
            job_config = bigquery.LoadJobConfig(
                schema=self.table_schema,
                source_format=bigquery.SourceFormat.NEWLINE_DELIMITED_JSON,
                time_partitioning=bigquery.TimePartitioning(field=partition_field),
                clustering_fields=cluster_fields,
            )
        elif partition_field is None and len(cluster_fields) > 0:
            job_config = bigquery.LoadJobConfig(
                schema=self.table_schema,
                source_format=bigquery.SourceFormat.NEWLINE_DELIMITED_JSON,
                clustering_fields=cluster_fields,
            )
        else:
            job_config = bigquery.LoadJobConfig(
                #  schema=[
                #      bigquery.SchemaField("employee_id", "INT64"),
                #      bigquery.SchemaField("annual_ctc", "INT64"),
                #  ],
                schema=self.table_schema,
                source_format=bigquery.SourceFormat.NEWLINE_DELIMITED_JSON,
            )

        # Make the API request
        load_job = self.bq_client.load_table_from_json(
            rows_to_insert,
            self.table_id,
            #  location="US",  # Must match the destination dataset location.
            job_config=job_config,
        )

        load_successful = False
        try:
            load_job.result()  # Waits for the job to complete.
            load_successful = True
            print("Load job completed")
        except Exception as e:
            load_successful = False
            print(e)
            print(load_job.errors)

        print("Total rows in table after load:", self.get_row_count(self.table_id))

        return load_successful
