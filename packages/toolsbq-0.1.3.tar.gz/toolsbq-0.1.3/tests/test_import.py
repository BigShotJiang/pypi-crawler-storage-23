def test_import():
    from toolsbq import bq_get_client  # noqa: F401
