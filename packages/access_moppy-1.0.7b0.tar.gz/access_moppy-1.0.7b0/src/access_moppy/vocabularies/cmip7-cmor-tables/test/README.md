These are testing CV files, the CV JSON file should be being published from the CMIP7-CVs repository
