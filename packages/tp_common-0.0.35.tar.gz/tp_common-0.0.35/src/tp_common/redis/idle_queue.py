from logging import Logger

from redis.asyncio import Redis

from tp_common.decorators.decorator_retry_async import retry_async
from tp_common.redis.base_queue import BaseQueue


class IdleQueue(BaseQueue):
    """Очередь пробуждения: signal() — отправить, wait() — ждать с таймаутом."""

    QUEUE_NAME = ""

    def __init__(
        self,
        connector: Redis,
        logger: Logger,
        retry_enabled: bool = True,
    ) -> None:
        super().__init__(
            connector=connector, logger=logger, retry_enabled=retry_enabled
        )

    @retry_async(
        start_message="отправка сигнала {QUEUE_NAME}",
        error_message="Ошибка signal {QUEUE_NAME}: {e}",
    )
    async def signal(self) -> None:
        """Отправить сигнал в очередь."""
        await self._connector.rpush(self.QUEUE_NAME, "")

    @retry_async(
        start_message="ожидание сигнала {QUEUE_NAME}",
        error_message="Ошибка wait {QUEUE_NAME}: {e}",
    )
    async def wait(self, timeout: int = 60, clear: bool = True) -> None:
        """Ждать сигнала (blpop). clear — очистить очередь после получения."""
        result = await self._connector.blpop([self.QUEUE_NAME], timeout=timeout)
        if result is None:
            return None
        if clear:
            await self._connector.delete(self.QUEUE_NAME)
        return None

    @retry_async(
        start_message="подсчёт элементов {QUEUE_NAME}",
        error_message="Ошибка count {QUEUE_NAME}: {e}",
    )
    async def count(self) -> int:
        """Возвращает количество элементов в очереди."""
        return await super().count()
