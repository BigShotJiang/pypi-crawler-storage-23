from __future__ import annotations

from logging import Logger
from typing import TypeVar, cast

from pydantic import BaseModel
from redis.asyncio import Redis

from tp_common.decorators.decorator_retry_forever import retry_forever
from tp_common.redis.base_queue import BaseQueue
from tp_common.redis.protocols import AsyncRedisAdapter

SchemaT = TypeVar("SchemaT", bound=BaseModel)


class CompletionQueue[SchemaT: BaseModel](BaseQueue):
    """"""

    QUEUE_NAME = ""
    _connector: AsyncRedisAdapter

    def __init__(
        self,
        connector: Redis,
        logger: Logger,
        schema_class: type[SchemaT],
        retry_enabled: bool = True,
    ) -> None:
        super().__init__(
            connector=connector, logger=logger, retry_enabled=retry_enabled
        )
        self._schema_class: type[SchemaT] = schema_class

    def _schema(self) -> type[SchemaT]:
        return self._schema_class

    @retry_forever(
        start_message="IdleWakeModel: отправка сигнала",
        error_message="Ошибка IdleWakeModel complete: {e}",
    )
    async def complete(self, payload: SchemaT) -> None:
        """Отправить payload в очередь (как JSON)."""
        await self._connector.rpush(self.QUEUE_NAME, payload.model_dump_json())

    @retry_forever(
        start_message="IdleWakeModel: ожидание сигнала",
        error_message="Ошибка IdleWakeModel wait: {e}",
    )
    async def wait(self) -> SchemaT:
        """Ждать payload (blpop). clear — очистить очередь после получения."""
        schema = self._schema()

        raw: bytes | None = None
        while raw is None:
            result = await self._connector.blpop([self.QUEUE_NAME], timeout=0)
            if result is None:
                continue
            _, raw = result
            break

        return cast(SchemaT, schema.model_validate_json(raw))
