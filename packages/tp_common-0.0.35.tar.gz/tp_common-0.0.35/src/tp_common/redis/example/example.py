"""
Примеры использования IdleQueue и CompletionQueue.

Запуск (из корня проекта, с загруженным .env):
    python -m tp_common.redis.example

Требуется в .env: REDIS_URL=redis://host:port/db или redis://...?pref=logis:backend
"""

from __future__ import annotations

import asyncio
import logging
import os
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from pydantic import BaseModel
from redis.asyncio import Redis

from tp_common.redis.completion_queue import CompletionQueue
from tp_common.redis.idle_queue import IdleQueue


def _load_dotenv() -> None:
    root = Path(__file__).resolve().parents[2]
    for _ in range(5):
        env_file = root / ".env"
        if env_file.is_file():
            for line in env_file.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, _, value = line.partition("=")
                    if key.strip() and os.environ.get(key.strip()) is None:
                        os.environ[key.strip()] = value.strip()
            return
        root = root.parent


_load_dotenv()


def _redis_from_env() -> Redis:
    url = os.environ.get("REDIS_URL", "redis://localhost:6379/0")
    parsed = urlparse(url)
    connection_url = f"{parsed.scheme}://{parsed.netloc}{parsed.path}"
    return Redis.from_url(connection_url, decode_responses=False)


def _queue_prefix_from_env() -> str:
    url = os.environ.get("REDIS_URL", "")
    parsed = urlparse(url)
    qs = parse_qs(parsed.query)
    return (qs.get("pref") or [""])[0]


# --- IdleQueue: сигнал пробуждения (signal / wait) ---


class ExampleIdleQueue(IdleQueue):
    """Очередь пробуждения воркера: signal() — разбудить, wait() — ждать с таймаутом."""

    QUEUE_NAME = ""

    def __init__(self, connector: Redis, logger: logging.Logger) -> None:
        prefix = _queue_prefix_from_env()
        self.QUEUE_NAME = f"{prefix}:idle:wake" if prefix else "idle:wake"
        super().__init__(connector=connector, logger=logger, retry_enabled=True)


# --- CompletionQueue: очередь завершённых задач с типизированным payload ---


class TaskResult(BaseModel):
    """Пример схемы payload для CompletionQueue."""

    task_id: str
    status: str
    result: int | None = None


class ExampleCompletionQueue(CompletionQueue[TaskResult]):
    """Очередь результатов задач: complete(payload) — отправить, wait() — получить."""

    QUEUE_NAME = ""

    def __init__(self, connector: Redis, logger: logging.Logger) -> None:
        prefix = _queue_prefix_from_env()
        self.QUEUE_NAME = f"{prefix}:completion:tasks" if prefix else "completion:tasks"
        super().__init__(
            connector=connector,
            logger=logger,
            schema_class=TaskResult,
            retry_enabled=True,
        )


# --- Пример использования ---


async def run_idle_example(redis: Redis, log: logging.Logger) -> None:
    idle = ExampleIdleQueue(connector=redis, logger=log)

    await idle.signal()

    await idle.wait(timeout=5, clear=True)

    await idle.count()


async def run_completion_example(redis: Redis, log: logging.Logger) -> None:
    completion = ExampleCompletionQueue(connector=redis, logger=log)
    payload = TaskResult(task_id="t1", status="done", result=42)
    log.info("CompletionQueue: отправка payload %s", payload.model_dump())
    await completion.complete(payload)

    received = await completion.wait()
    log.info("CompletionQueue: получен %s", received.model_dump())


async def main() -> None:
    logging.basicConfig(level=logging.DEBUG)
    log = logging.getLogger("redis.example ")

    redis = _redis_from_env()
    try:
        await run_idle_example(redis, log)
        await run_completion_example(redis, log)
    finally:
        await redis.aclose()


if __name__ == "__main__":
    asyncio.run(main())
