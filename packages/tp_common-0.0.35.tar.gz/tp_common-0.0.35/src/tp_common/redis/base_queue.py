from logging import Logger

from redis.asyncio import Redis

from tp_common.decorators.decorator_retry_async import retry_async
from tp_common.redis.protocols import AsyncRedisAdapter


class BaseQueue:
    # Имя очереди в Redis (ключ). Должно быть переопределено в наследниках (непустая строка).
    QUEUE_NAME = ""

    def __init__(
        self,
        connector: Redis,
        logger: Logger,
        retry_enabled: bool = False,
    ) -> None:
        if not self.QUEUE_NAME:
            raise TypeError(
                f"{type(self).__name__}.QUEUE_NAME must be set to a non-empty string"
            )
        self.logger = logger
        self._connector = AsyncRedisAdapter(connector)
        self._retry_enabled = retry_enabled

    @retry_async(
        start_message="BaseQueue: подсчёт элементов (LLEN)",
        error_message="Ошибка BaseQueue count: {e}",
    )
    async def count(self) -> int:
        """Возвращает количество элементов в очереди (LLEN)."""
        return await self._connector.llen(self.QUEUE_NAME)

    @retry_async(
        start_message="BaseQueue: удаление очереди (DEL)",
        error_message="Ошибка BaseQueue delete: {e}",
    )
    async def delete(self) -> int:
        """Полностью удаляет ключ очереди (DEL)."""
        return await self._connector.delete(self.QUEUE_NAME)

    @retry_async(
        start_message="BaseQueue: удаление очереди (UNLINK)",
        error_message="Ошибка BaseQueue unlink: {e}",
    )
    async def unlink(self) -> int:
        """
        Асинхронно удаляет ключ очереди (UNLINK).
        В отличие от DEL, не блокирует Redis при больших ключах.
        Возвращает количество удалённых ключей (0 или 1).
        """
        return await self._connector.unlink(self.QUEUE_NAME)

    @retry_async(
        start_message="BaseQueue: удаление по шаблону",
        error_message="Ошибка BaseQueue unlink_by_pattern: {e}",
    )
    async def unlink_by_pattern(self, pattern: str) -> int:
        """
        Удаляет все ключи в Redis, подходящие под шаблон.
        Например: pattern="tasks*" или "routes:*".
        Возвращает количество удалённых ключей.
        """
        deleted = 0
        async for key in self._connector.scan_iter(match=pattern):
            deleted += await self._connector.unlink(key)
        return deleted
