"""Адаптер для типизации async-клиента Redis."""

from collections.abc import AsyncIterator, Awaitable
from typing import Any, cast

from redis.asyncio import Redis


class AsyncRedisAdapter:
    """
    Адаптер над `redis.asyncio.Redis`, который фиксирует типы методов как async.

    Нужен, чтобы бизнес-код не тащил за собой `Union[Awaitable[T], T]`
    из тип-стабов redis и не содержал `cast` в каждом вызове.
    """

    def __init__(self, client: Redis) -> None:
        self._client = client

    async def llen(self, name: str) -> int:
        return await cast(Awaitable[int], self._client.llen(name))

    async def delete(self, *names: str | bytes) -> int:
        return await cast(Awaitable[int], self._client.delete(*names))

    async def unlink(self, *names: str | bytes) -> int:
        return await cast(Awaitable[int], self._client.unlink(*names))

    async def rpush(self, name: str, *values: str | bytes | int) -> int:
        return await cast(Awaitable[int], self._client.rpush(name, *values))

    async def blpop(
        self,
        keys: list[str],
        timeout: float = 0,
    ) -> tuple[bytes, bytes] | None:
        result = await cast(Awaitable[Any], self._client.blpop(keys, timeout=timeout))
        return cast(tuple[bytes, bytes] | None, result)

    def scan_iter(
        self,
        match: str | None = None,
        count: int | None = None,
    ) -> AsyncIterator[Any]:
        return self._client.scan_iter(match=match, count=count)
