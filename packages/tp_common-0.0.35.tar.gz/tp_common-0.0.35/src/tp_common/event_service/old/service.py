# from __future__ import annotations
#
# import json
# import time
# from enum import Enum
# from logging import Logger
# from typing import Any, TypeVar, cast
#
# from confluent_kafka import KafkaError, KafkaException, Message
# from pydantic import BaseModel, ValidationError
# from src.tp_common.kafka.connector import KafkaConnector
# from src.tp_common.kafka.messages import (
#     BaseEventPayload,
#     BaseEventType,
#     TypedEventPayload,
# )
# from tp_helper import get_logger
#
# ModelT = TypeVar("ModelT", bound=BaseModel)
# EventEnumT = TypeVar("EventEnumT", bound=Enum)
# PublishEventT = TypeVar("PublishEventT", bound=Enum)
# AnyEventT = TypeVar("AnyEventT", bound=Enum)
#
#
# class BaseEvent[ModelT: BaseModel, EventEnumT: Enum]:
#     """
#     Универсальный Kafka event-сервис (consumer + producer).
#
#     - Consumer: subscribe + consume_filtered + commit
#     - Producer: publish (в дефолтный топик или в произвольный group/topic)
#     """
#
#     def __init__(
#         self,
#         group_id: str,
#         group_name: str,
#         connector: KafkaConnector,
#         payload_schema: type[ModelT],
#         poll_timeout: float = 1.0,
#         event_enum: type[EventEnumT] | None = None,
#         subscribe_to: list[EventEnumT] | None = None,
#         auto_ack_ignored: bool = True,
#         commit_on_validation_error: bool = False,
#         validation_error_sleep_seconds: float = 120.0,
#         processing_error_sleep_seconds: float = 5.0,
#         logger: Logger | None = None,
#     ) -> None:
#         self.group_id = group_id
#         self.group_name = group_name
#         self.payload_schema = payload_schema
#
#         self.poll_timeout = poll_timeout
#         self.event_enum = event_enum or cast(type[EventEnumT], BaseEventType)
#         self.subscribe_to = subscribe_to
#         self.auto_ack_ignored = auto_ack_ignored
#
#         self.commit_on_validation_error = commit_on_validation_error
#         self.validation_error_sleep_seconds = validation_error_sleep_seconds
#         self.processing_error_sleep_seconds = processing_error_sleep_seconds
#
#         self.connector = connector
#         self.consumer = self.connector.get_consumer(group_id=group_id)
#         self.producer = self.connector.get_producer()
#         self.topic_name = self.connector.resolve_topic(self.group_name)
#
#         self.logger: Logger = logger or get_logger(
#             name=self.topic_name,
#             label="Event Service",
#         )
#
#     # ======================================================================
#     # CONSUMER
#     # ======================================================================
#
#     def subscribe(self) -> None:
#         self.consumer.subscribe([self.topic_name])
#
#     def consume_filtered(
#         self,
#         event_types: list[EventEnumT] | None = None,
#     ) -> tuple[Message, TypedEventPayload[ModelT, EventEnumT]] | None:
#         msg = self._poll_message()
#         if msg is None:
#             return None
#         try:
#             payload = self.parse_payload(msg)
#             snapshot_value = getattr(self.event_enum, "SNAPSHOT", None)
#             if snapshot_value is not None and payload.event == snapshot_value:
#                 self._log_snapshot_message(msg)
#                 self.commit(msg)
#                 return None
#
#             if not self._should_process_event(payload.event, event_types=event_types):
#
#                 self._handle_ignored_message(msg)
#
#                 return None
#
#             return msg, payload
#         except ValidationError:
#             if self.commit_on_validation_error:
#                 self._log_skipped_message(msg)
#                 self.commit(msg)
#                 return None
#             self._handle_schema_mismatch(msg)
#             return None
#         except Exception:
#             self._handle_processing_error(msg)
#             return None
#
#     def commit(self, msg: Message) -> None:
#         self.consumer.commit(message=msg, asynchronous=False)
#
#     def close_consumer(self) -> None:
#         self.consumer.close()
#
#     # ======================================================================
#     # PRODUCER
#     # ======================================================================
#
#     def publish(
#         self,
#         payload: BaseEventPayload | TypedEventPayload[ModelT, PublishEventT],
#         group_name: str | None = None,
#     ) -> None:
#         normalized_payload = self._normalize_payload(payload)
#         data = json.dumps(
#             normalized_payload.model_dump(mode="json"),
#             ensure_ascii=False,
#         ).encode("utf-8")
#         topic = self._resolve_topic(group_name=group_name)
#         self.producer.produce(
#             topic=topic,
#             value=data,
#             on_delivery=self._on_delivery,
#         )
#         self.producer.poll(0)
#
#     def flush(self, timeout: float = 10.0, raise_on_fail: bool = False) -> int:
#         """
#         Flush producer queue.
#
#         Returns number of messages still not delivered after timeout.
#         If raise_on_fail=True and some messages remain undelivered, raises TimeoutError.
#         """
#         remaining = int(self.producer.flush(timeout))
#         if raise_on_fail and remaining > 0:
#             raise TimeoutError(
#                 f"Kafka flush timeout: {remaining} message(s) not delivered"
#             )
#         return remaining
#
#     def close_producer(self, timeout: float = 10.0) -> None:
#         self.flush(timeout)
#
#     # ======================================================================
#     # INTERNAL
#     # ======================================================================
#
#     def parse_payload(self, msg: Message) -> TypedEventPayload[ModelT, EventEnumT]:
#         raw_value = msg.value()
#         if raw_value is None:
#             raise ValueError("Kafka message value is None")
#         base_payload = BaseEventPayload.model_validate(json.loads(raw_value))
#         before = self._parse_model_part(base_payload.before)
#         after = self._parse_model_part(base_payload.after)
#         normalized_event = self._normalize_event(base_payload.event)
#         if normalized_event is None:
#             normalized_event = self._infer_event(before=before, after=after)
#         return TypedEventPayload(
#             before=before,
#             after=after,
#             event=normalized_event,
#         )
#
#     def _infer_event(
#         self, before: ModelT | None, after: ModelT | None
#     ) -> EventEnumT | None:
#         """
#         Fallback when event/op field is missing in payload:
#
#         - before=None, after!=None -> CREATE
#         - before!=None, after=None -> DELETE
#         - before!=None, after!=None -> UPDATE
#
#         Works only if event_enum defines corresponding members.
#         """
#         if before is None and after is None:
#             return None
#
#         if before is None and after is not None:
#             return getattr(self.event_enum, "CREATE", None)
#
#         if before is not None and after is None:
#             return getattr(self.event_enum, "DELETE", None)
#
#         # before != None and after != None
#         return getattr(self.event_enum, "UPDATE", None)
#
#     def _poll_message(self) -> Message | None:
#         msg = self.consumer.poll(self.poll_timeout)
#         if msg is None:
#             return None
#
#         if msg.error():
#             err = msg.error()
#             eof_code = getattr(KafkaError, "_PARTITION_EOF", 1)
#             if err is not None and err.code() == eof_code:
#                 self.logger.debug(
#                     "Partition EOF (topic=%s, partition=%s, offset=%s)",
#                     msg.topic(),
#                     msg.partition(),
#                     msg.offset(),
#                 )
#                 return None
#             raise KafkaException(err)
#
#         return msg
#
#     def _resolve_topic(self, group_name: str | None) -> str:
#         if group_name is None:
#             return self.topic_name
#         if self.connector is None:
#             return group_name
#         return self.connector.resolve_topic(group_name)
#
#     def _should_process_event(
#         self,
#         event: EventEnumT | None,
#         event_types: list[EventEnumT] | None = None,
#     ) -> bool:
#         active_filter = event_types if event_types is not None else self.subscribe_to
#         if active_filter is None:
#             return True
#         if event is None:
#             return False
#         return event in active_filter
#
#     def _normalize_event(self, value: object) -> EventEnumT | None:
#         if value is None:
#             return None
#         # PyCharm/mypy can be picky about isinstance(..., TypeVar-based type) here.
#         # Enums are not meant to be subclassed, so strict type equality is enough.
#         if isinstance(value, Enum) and type(value) is self.event_enum:
#             return cast(EventEnumT, value)
#         try:
#             return self.event_enum(value)
#         except Exception:
#             return None
#
#     def _handle_ignored_message(self, msg: Message) -> None:
#         if not self.auto_ack_ignored:
#             return
#         self.logger.debug(
#             "Ignored message by filter (topic=%s, partition=%s, offset=%s) — committed",
#             msg.topic(),
#             msg.partition(),
#             msg.offset(),
#         )
#         self.commit(msg)
#
#     def _log_skipped_message(self, msg: Message) -> None:
#         self.logger.warning(
#             "Skipped test message (topic=%s, partition=%s, offset=%s) — committed anyway",
#             msg.topic(),
#             msg.partition(),
#             msg.offset(),
#             exc_info=True,
#         )
#
#     def _handle_schema_mismatch(self, msg: Message) -> None:
#         value_bytes = msg.value()
#         value_preview = None
#         if isinstance(value_bytes, (bytes, bytearray)):
#             value_preview = value_bytes[:2048]
#
#         self.logger.critical(
#             "Schema validation failed (topic=%s, partition=%s, offset=%s). "
#             "Offset NOT committed. Sleeping %.1fs and restarting consumer to retry the same message. "
#             "This usually means schema/version mismatch between producer and consumer. "
#             "Value preview (first 2KB)=%r",
#             msg.topic(),
#             msg.partition(),
#             msg.offset(),
#             self.validation_error_sleep_seconds,
#             value_preview,
#             exc_info=True,
#         )
#
#         time.sleep(self.validation_error_sleep_seconds)
#         self._restart_consumer()
#
#     def _handle_processing_error(self, msg: Message) -> None:
#         """
#         Any unexpected exception while parsing/filtering a message.
#
#         Important:
#         - We DO NOT commit the offset for the failing message.
#         - We restart the consumer so the next poll starts from the LAST COMMITTED offset
#           (otherwise the client may continue and later commit a higher offset, effectively
#           skipping the failed message).
#         """
#         self.logger.critical(
#             "Unexpected processing error (topic=%s, partition=%s, offset=%s). "
#             "Offset NOT committed. Sleeping %.1fs and restarting consumer to retry the same message.",
#             msg.topic(),
#             msg.partition(),
#             msg.offset(),
#             self.processing_error_sleep_seconds,
#             exc_info=True,
#         )
#         time.sleep(self.processing_error_sleep_seconds)
#         self._restart_consumer()
#
#     def _restart_consumer(self) -> None:
#         try:
#             self.consumer.close()
#         except Exception:
#             self.logger.exception("Failed to close consumer during restart")
#
#         if self.connector is None:
#             raise RuntimeError("Cannot restart consumer without connector")
#         self.consumer = self.connector.get_consumer(group_id=self.group_id)
#         self.subscribe()
#
#     def _log_snapshot_message(self, msg: Message) -> None:
#         self.logger.debug(
#             "Skipped snapshot message (topic=%s, partition=%s, offset=%s)",
#             msg.topic(),
#             msg.partition(),
#             msg.offset(),
#         )
#
#     def _normalize_payload(
#         self, payload: BaseEventPayload | TypedEventPayload[ModelT, AnyEventT]
#     ) -> BaseEventPayload:
#         if isinstance(payload, BaseEventPayload):
#             return self._normalize_base_payload(payload)
#         before = self._normalize_model_part(payload.before)
#         after = self._normalize_model_part(payload.after)
#         event = self._normalize_event_value(payload.event)
#         return BaseEventPayload(
#             before=before,
#             after=after,
#             event=event,
#         )
#
#     def _normalize_base_payload(self, payload: BaseEventPayload) -> BaseEventPayload:
#         before = self._normalize_model_part(payload.before)
#         after = self._normalize_model_part(payload.after)
#         event = self._normalize_event_value(payload.event)
#         if (
#             before is payload.before
#             and after is payload.after
#             and event == payload.event
#         ):
#             return payload
#         return BaseEventPayload(
#             before=before,
#             after=after,
#             event=event,
#         )
#
#     def _parse_model_part(self, data: dict | BaseModel | None) -> ModelT | None:
#         if data is None:
#             return None
#         # Avoid IDE/typechecker complaints about isinstance(..., TypeVar-based type)
#         if isinstance(data, cast(type[Any], self.payload_schema)):
#             return cast(ModelT, data)
#         return self.payload_schema.model_validate(data)
#
#     def _normalize_model_part(self, data: dict | BaseModel | None) -> dict | None:
#         if data is None:
#             return None
#         if isinstance(data, BaseModel):
#             return data.model_dump(mode="json")
#         return self.payload_schema.model_validate(data).model_dump(mode="json")
#
#     @staticmethod
#     def _normalize_event_value(value: object) -> str | None:
#         if value is None:
#             return None
#         if isinstance(value, Enum):
#             return value.value
#         return str(value)
#
#     def _on_delivery(self, err: KafkaError | None, msg: Message) -> None:
#         if err:
#             self.logger.error("Kafka delivery error: %s", err)
#             return
#         self.logger.debug(
#             "Kafka delivered: topic=%s partition=%s offset=%s",
#             msg.topic(),
#             msg.partition(),
#             msg.offset(),
#         )
