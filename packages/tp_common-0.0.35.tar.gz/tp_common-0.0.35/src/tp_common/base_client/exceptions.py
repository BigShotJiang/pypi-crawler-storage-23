"""Исключения для базового HTTP клиента."""


class ClientException(Exception):
    """Базовое исключение для всех ошибок клиента."""

    def __init__(
        self,
        message: str,
        url: str | None = None,
        status_code: int | None = None,
        response_body: str | None = None,
    ) -> None:
        super().__init__(message)
        self.url = url
        self.status_code = status_code
        self.response_body = response_body


class ClientResponseErrorException(ClientException):
    """Исключение при неуспешном HTTP статусе (>=400)."""

    def __init__(
        self,
        message: str,
        url: str | None = None,
        status_code: int | None = None,
        response_body: str | None = None,
    ) -> None:
        super().__init__(message, url, status_code, response_body)


class ClientConnectionException(ClientException):
    """Исключение при ошибке соединения (не удалось установить соединение)."""

    def __init__(
        self,
        message: str,
        url: str | None = None,
    ) -> None:
        super().__init__(message, url)


class ClientTimeoutException(ClientConnectionException):
    """Исключение при таймауте соединения."""

    def __init__(
        self,
        message: str,
        url: str | None = None,
    ) -> None:
        super().__init__(message, url)


class ClientProxyException(ClientConnectionException):
    """Исключение при ошибке прокси."""

    def __init__(
        self,
        message: str,
        url: str | None = None,
        proxy: str | None = None,
    ) -> None:
        super().__init__(message, url)
        self.proxy = proxy


class ClientDNSException(ClientConnectionException):
    """Исключение при ошибке DNS (не удалось разрешить доменное имя)."""

    def __init__(
        self,
        message: str,
        url: str | None = None,
    ) -> None:
        super().__init__(message, url)


class ClientBusinessErrorException(ClientException):
    """Базовое исключение для бизнес-ошибок (400, 401, 403, 404, 422)."""

    pass


class ClientServerErrorException(ClientException):
    """Базовое исключение для ошибок сервера (500, 502, 503, 504)."""

    pass


class ClientNetworkErrorException(ClientException):
    """Базовое исключение для сетевых ошибок (таймауты, соединение, DNS)."""

    pass


class ClientProxyErrorException(ClientException):
    """Базовое исключение для ошибок прокси."""

    pass


class ClientAuthorizationException(ClientBusinessErrorException):
    """Исключение при ошибке авторизации (401, 403)."""

    pass


class ClientValidationException(ClientBusinessErrorException):
    """Исключение при ошибке валидации данных (400, 422)."""

    pass


class ClientResourceNotFoundException(ClientBusinessErrorException):
    """Исключение при отсутствии ресурса (404)."""

    pass


class ClientServerException(ClientServerErrorException):
    """Исключение при ошибке сервера (500, 502, 503, 504)."""

    pass


class ClientTooManyRequestsException(ClientProxyErrorException):
    """Исключение при превышении лимита запросов (429)."""

    pass


class ClientServiceUnavailableException(ClientServerErrorException):
    """Исключение при недоступности сервиса (502, 503, 504)."""

    pass
