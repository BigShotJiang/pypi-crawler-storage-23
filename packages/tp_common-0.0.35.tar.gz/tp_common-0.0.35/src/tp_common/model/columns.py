import uuid
from enum import Enum
from typing import Any, TypeVar

from sqlalchemy import UUID
from sqlalchemy import Enum as SQLEnum
from sqlalchemy.orm import Mapped, mapped_column

_E = TypeVar("_E", bound=Enum)


def enum_column[E: Enum](
    enum_type: type[E],
    name: str,
    *,
    default: E | None = None,
    nullable: bool = False,
    index: bool = True,
    primary_key: bool = False,
    unique: bool = False,
    server_default: Any = None,
) -> Mapped[E]:
    """
    Базовая фабрика колонки для enum. В домене оборачивают в функцию с фиксированным типом и именем.

    :param default: Значение enum по умолчанию
    :param enum_type: Класс enum (например EventGroup).
    :param name: Имя типа в БД (например "event_group").
    :param nullable: Разрешено ли NULL.
    :param index: Создавать ли индекс (не создаётся, если primary_key=True).
    :param primary_key: Первичный ключ.
    :param unique: Уникальное значение.
    :param server_default
    """
    return mapped_column(
        SQLEnum(enum_type, name=name),
        nullable=nullable,
        primary_key=primary_key,
        index=index if not primary_key else False,
        unique=unique,
        default=default,
        server_default=server_default,
    )


def uuid_column(
    primary_key: bool = True,
    default: bool = True,
    nullable: bool = False,
) -> Mapped[uuid.UUID]:
    """
    Возвращает колонку UUID с поддержкой primary key и генерации по умолчанию.

    :param primary_key: Является ли колонка первичным ключом.
    :param default: Добавить ли default=uuid4.
    :param nullable: Разрешено ли NULL-значение.
    :return: Mapped колонка UUID(as_uuid=True)

    Пример:
        user_id: Mapped[uuid.UUID] = uuid_column(primary_key=True)
    """
    column = mapped_column(
        UUID(as_uuid=True),
        primary_key=primary_key,
        default=uuid.uuid4 if default else None,
        nullable=nullable,
    )

    return column
