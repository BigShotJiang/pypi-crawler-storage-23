# CLAUDE.md

## Project

RosettaHUB MCP Server — wraps the RosettaHUB SOAP API as MCP tools for managing student AWS cloud accounts.

## Commands

```bash
pip install -e ".[dev]"     # Install with dev deps
pytest                       # Run tests (no API key needed)
ruff check src/ tests/       # Lint
ruff format src/ tests/      # Format
mypy src/ --ignore-missing-imports  # Type check
```

## Structure

- `src/rosettahub_mcp_server/server.py` — FastMCP instance, `get_client()` singleton, `main()`
- `src/rosettahub_mcp_server/config.py` — Config from env vars (`RH_API_KEY`, `RH_ORG`)
- `src/rosettahub_mcp_server/client.py` — `RosettaHubClient` wrapping zeep SOAP calls
- `src/rosettahub_mcp_server/types.py` — TypedDict return types
- `src/rosettahub_mcp_server/tools/` — 4 tool modules (account, aws, budget, user_mgmt)
- `src/rosettahub_mcp_server/resources/` — MCP resource implementations
- `tests/conftest.py` — Mock fixtures using `SimpleNamespace` (mimics zeep attribute access)

## Patterns

- Tools import `from rosettahub_mcp_server import server` and call `server.get_client()` — this enables test mocking via `patch("rosettahub_mcp_server.server.get_client")`
- Tools return TypedDicts, never strings — structured data for AI consumption
- Raise exceptions (not `sys.exit`) — FastMCP converts them to MCP error responses
- AWS commands validated with `_validate_aws_command()` — must start with `aws `
- `subprocess.run` uses `shell=False` with `shlex.split()` — prevents shell injection

## SOAP API Methods

- `getUserInfo(apiKey)` — test connection
- `getBasicCloudAccounts(apiKey)` — own accounts
- `cpocGetFederatedCloudAccounts(apiKey, False, {organizationName, cloudId, includeCustomization})` — student accounts
- `cpocGetFederatedUsers(apiKey, False, False, {organizationName})` — users
- `suGetStsSession(apiKey, cloudAccountUid, duration)` — STS credentials
- `cpocTransferBudget(apiKey, uids, amount, False, None)` — transfer budget
- `cpocQuarantineUsers(apiKey, uids, False, None)` / `cpocUnquarantineUsers(...)` — access control
- `cpocSetAllowedRegions(apiKey, logins, cloudId, regions, None)` — region restriction
