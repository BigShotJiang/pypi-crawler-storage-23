"""Tests for budget monitoring and transfer tools."""

from __future__ import annotations

import pytest

from rosettahub_mcp_server.tools.budget_tools import (
    budget_status,
    budget_transfer,
    budget_transfer_user,
)
from tests.conftest import make_student_account


class TestBudgetStatus:
    def test_calculates_totals(self, mock_get_client, mock_service):
        mock_service.cpocGetFederatedCloudAccounts.return_value = [
            make_student_account(login="alice", budget=100, aggregatedCost=20, amountLeft=80),
            make_student_account(login="bob", budget=50, aggregatedCost=45, amountLeft=5),
        ]
        result = budget_status()
        assert result["student_count"] == 2
        assert result["total_budget"] == 150.0
        assert result["total_spent"] == 65.0
        assert result["total_remaining"] == 85.0

    def test_threshold_flagging(self, mock_get_client, mock_service):
        mock_service.cpocGetFederatedCloudAccounts.return_value = [
            make_student_account(login="alice", budget=100, aggregatedCost=20, amountLeft=80),
            make_student_account(login="bob", budget=50, aggregatedCost=45, amountLeft=5),
        ]
        result = budget_status()
        alice = result["students"][0]
        bob = result["students"][1]
        assert alice["over_threshold"] is False  # 20%
        assert bob["over_threshold"] is True  # 90%

    def test_zero_budget(self, mock_get_client, mock_service):
        mock_service.cpocGetFederatedCloudAccounts.return_value = [
            make_student_account(login="alice", budget=0, aggregatedCost=0, amountLeft=0),
        ]
        result = budget_status()
        assert result["students"][0]["percent_used"] == 0.0

    def test_empty_accounts(self, mock_get_client, mock_service):
        mock_service.cpocGetFederatedCloudAccounts.return_value = []
        result = budget_status()
        assert result["student_count"] == 0
        assert result["total_budget"] == 0.0


class TestBudgetTransfer:
    def test_transfers_to_all(self, mock_get_client, mock_service):
        mock_service.cpocGetFederatedCloudAccounts.return_value = [
            make_student_account(login="alice", cloudAccountUid="uid-a"),
            make_student_account(login="bob", cloudAccountUid="uid-b"),
        ]
        result = budget_transfer(10.0)
        assert result["amount"] == 10.0
        assert result["accounts"] == 2
        assert result["logins"] == ["alice", "bob"]
        mock_service.cpocTransferBudget.assert_called_once_with(
            "test-api-key", ["uid-a", "uid-b"], 10.0, False, None
        )

    def test_rejects_negative(self, mock_get_client, mock_service):
        with pytest.raises(ValueError, match="positive"):
            budget_transfer(-5.0)

    def test_rejects_zero(self, mock_get_client, mock_service):
        with pytest.raises(ValueError, match="positive"):
            budget_transfer(0)

    def test_rejects_empty_accounts(self, mock_get_client, mock_service):
        mock_service.cpocGetFederatedCloudAccounts.return_value = []
        with pytest.raises(ValueError, match="No student accounts found"):
            budget_transfer(10.0)


class TestBudgetTransferUser:
    def test_transfers_to_one(self, mock_get_client, mock_service):
        mock_service.cpocGetFederatedCloudAccounts.return_value = [
            make_student_account(login="alice", cloudAccountUid="uid-a"),
        ]
        result = budget_transfer_user("alice", 25.0)
        assert result["amount"] == 25.0
        assert result["accounts"] == 1
        assert result["logins"] == ["alice"]

    def test_rejects_negative(self, mock_get_client, mock_service):
        with pytest.raises(ValueError, match="positive"):
            budget_transfer_user("alice", -5.0)

    def test_rejects_zero(self, mock_get_client, mock_service):
        with pytest.raises(ValueError, match="positive"):
            budget_transfer_user("alice", 0)

    def test_user_not_found(self, mock_get_client, mock_service):
        mock_service.cpocGetFederatedCloudAccounts.return_value = [
            make_student_account(login="alice"),
        ]
        with pytest.raises(ValueError, match="No cloud account found for 'nobody'"):
            budget_transfer_user("nobody", 10.0)
