"""Tests for MCP resources."""

from __future__ import annotations

import json

from rosettahub_mcp_server.resources.student_resources import (
    budget_summary,
    student_list,
)
from tests.conftest import make_student_account


class TestStudentList:
    def test_returns_logins(self, mock_get_client, mock_service):
        mock_service.cpocGetFederatedCloudAccounts.return_value = [
            make_student_account(login="alice"),
            make_student_account(login="bob"),
        ]
        result = json.loads(student_list())
        assert result == ["alice", "bob"]

    def test_empty(self, mock_get_client, mock_service):
        mock_service.cpocGetFederatedCloudAccounts.return_value = []
        result = json.loads(student_list())
        assert result == []

    def test_none_response(self, mock_get_client, mock_service):
        mock_service.cpocGetFederatedCloudAccounts.return_value = None
        result = json.loads(student_list())
        assert result == []


class TestBudgetSummary:
    def test_returns_budget_data(self, mock_get_client, mock_service):
        mock_service.cpocGetFederatedCloudAccounts.return_value = [
            make_student_account(login="alice", budget=100, aggregatedCost=30, amountLeft=70),
            make_student_account(login="bob", budget=50, aggregatedCost=10, amountLeft=40),
        ]
        result = json.loads(budget_summary())
        assert len(result) == 2
        assert result[0]["login"] == "alice"
        assert result[0]["budget"] == 100.0
        assert result[0]["spent"] == 30.0
        assert result[0]["remaining"] == 70.0
        assert result[1]["login"] == "bob"

    def test_empty(self, mock_get_client, mock_service):
        mock_service.cpocGetFederatedCloudAccounts.return_value = []
        result = json.loads(budget_summary())
        assert result == []

    def test_handles_none_budget_values(self, mock_get_client, mock_service):
        mock_service.cpocGetFederatedCloudAccounts.return_value = [
            make_student_account(login="alice", budget=None, aggregatedCost=None, amountLeft=None),
        ]
        result = json.loads(budget_summary())
        assert result[0]["budget"] == 0.0
        assert result[0]["spent"] == 0.0
        assert result[0]["remaining"] == 0.0
