"""Tests for user management tools."""

from __future__ import annotations

import pytest

from rosettahub_mcp_server.tools.user_mgmt_tools import (
    quarantine_user,
    set_allowed_regions,
    unquarantine_user,
)
from tests.conftest import make_student_account


class TestQuarantineUser:
    def test_quarantines(self, mock_get_client, mock_service):
        mock_service.cpocGetFederatedCloudAccounts.return_value = [
            make_student_account(login="alice", cloudAccountUid="uid-a"),
        ]
        result = quarantine_user("alice")
        assert result["login"] == "alice"
        assert result["action"] == "quarantined"
        mock_service.cpocQuarantineUsers.assert_called_once_with(
            "test-api-key", ["uid-a"], False, None
        )

    def test_user_not_found(self, mock_get_client, mock_service):
        mock_service.cpocGetFederatedCloudAccounts.return_value = []
        with pytest.raises(ValueError, match="No cloud account found"):
            quarantine_user("nobody")


class TestUnquarantineUser:
    def test_unquarantines(self, mock_get_client, mock_service):
        mock_service.cpocGetFederatedCloudAccounts.return_value = [
            make_student_account(login="bob", cloudAccountUid="uid-b"),
        ]
        result = unquarantine_user("bob")
        assert result["login"] == "bob"
        assert result["action"] == "unquarantined"
        mock_service.cpocUnquarantineUsers.assert_called_once_with(
            "test-api-key", ["uid-b"], False, None
        )


class TestSetAllowedRegions:
    def test_sets_regions(self, mock_get_client, mock_service):
        mock_service.cpocGetFederatedCloudAccounts.return_value = [
            make_student_account(login="alice"),
        ]
        result = set_allowed_regions("alice", "eu-west-1,eu-west-2")
        assert result["login"] == "alice"
        assert result["regions"] == ["eu-west-1", "eu-west-2"]
        mock_service.cpocSetAllowedRegions.assert_called_once_with(
            "test-api-key", ["alice"], "aws", ["eu-west-1", "eu-west-2"], None
        )

    def test_single_region(self, mock_get_client, mock_service):
        mock_service.cpocGetFederatedCloudAccounts.return_value = [
            make_student_account(login="alice"),
        ]
        result = set_allowed_regions("alice", "us-east-1")
        assert result["regions"] == ["us-east-1"]

    def test_empty_regions_rejected(self, mock_get_client, mock_service):
        with pytest.raises(ValueError, match="At least one region"):
            set_allowed_regions("alice", "")

    def test_whitespace_stripped(self, mock_get_client, mock_service):
        mock_service.cpocGetFederatedCloudAccounts.return_value = [
            make_student_account(login="alice"),
        ]
        result = set_allowed_regions("alice", " eu-west-1 , eu-west-2 ")
        assert result["regions"] == ["eu-west-1", "eu-west-2"]
