# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.1] - 2026-02-19

### Changed

- Switch Codecov upload to OIDC auth (no token secret needed)
- Upload coverage on both push and PR events
- Update server.json to official MCP Registry schema
- Add MCP Registry PyPI verification marker
- Register on MCP Registry

## [0.1.0] - 2026-02-19

### Added

- 16 MCP tools wrapping the full RosettaHUB SOAP API
  - **Account tools:** `test_connection`, `list_accounts`, `list_student_accounts`, `list_users`, `list_api_methods`
  - **AWS tools:** `aws_exec`, `aws_exec_user`, `ec2_list`, `get_sts_credentials`, `get_console_url`
  - **Budget tools:** `budget_status`, `budget_transfer`, `budget_transfer_user`
  - **User management:** `quarantine_user`, `unquarantine_user`, `set_allowed_regions`
- 2 MCP resources: `rosettahub://students`, `rosettahub://budget-summary`
- AWS command validation — all commands must start with `aws ` to prevent arbitrary execution
- `shell=False` subprocess execution with `shlex.split()` for security
- Comprehensive test suite (64 tests, 95% coverage) with mocked SOAP responses
- CI/CD with GitHub Actions (lint, test on Python 3.10-3.13, publish to PyPI)
- Coverage reporting via Codecov

[Unreleased]: https://github.com/danielcregg/rosettahub-mcp-server/compare/v0.1.1...HEAD
[0.1.1]: https://github.com/danielcregg/rosettahub-mcp-server/compare/v0.1.0...v0.1.1
[0.1.0]: https://github.com/danielcregg/rosettahub-mcp-server/releases/tag/v0.1.0
