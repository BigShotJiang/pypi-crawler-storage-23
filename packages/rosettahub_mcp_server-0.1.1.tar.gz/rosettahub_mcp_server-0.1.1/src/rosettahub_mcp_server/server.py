"""FastMCP server instance and entry point for the RosettaHUB MCP Server."""

from __future__ import annotations

import logging

from mcp.server.fastmcp import FastMCP

from rosettahub_mcp_server.client import RosettaHubClient
from rosettahub_mcp_server.config import Config, ConfigError

logger = logging.getLogger(__name__)

mcp = FastMCP(
    "RosettaHUB",
    instructions=(
        "Manage RosettaHUB student AWS cloud accounts — list students, "
        "execute AWS CLI commands, monitor budgets, and control access."
    ),
)

# Lazy-initialized shared state
_client: RosettaHubClient | None = None
_config: Config | None = None


def get_config() -> Config:
    """Get or create the config singleton."""
    global _config
    if _config is None:
        _config = Config.from_env()
    return _config


def get_client() -> RosettaHubClient:
    """Get or create the RosettaHUB client singleton."""
    global _client
    if _client is None:
        _client = RosettaHubClient(get_config())
    return _client


# Import tool and resource modules to register them with the FastMCP instance.
# These modules use the `mcp` instance and `get_client` function from this module.
import rosettahub_mcp_server.resources.student_resources  # noqa: E402, F401
import rosettahub_mcp_server.tools.account_tools  # noqa: E402, F401
import rosettahub_mcp_server.tools.aws_tools  # noqa: E402, F401
import rosettahub_mcp_server.tools.budget_tools  # noqa: E402, F401
import rosettahub_mcp_server.tools.user_mgmt_tools  # noqa: E402, F401


def main() -> None:
    """Run the MCP server (stdio transport)."""
    # Configure logging to stderr (stdout is reserved for MCP JSON-RPC transport)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    )
    try:
        # Validate config eagerly so errors surface before the transport starts
        get_config()
    except ConfigError as e:
        logger.error("Configuration error: %s", e)
        raise SystemExit(1) from e

    logger.info("Starting RosettaHUB MCP Server")
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
