"""Budget monitoring and transfer tools."""

from __future__ import annotations

from rosettahub_mcp_server import server
from rosettahub_mcp_server.types import BudgetEntry, BudgetStatus, TransferResult


@server.mcp.tool()
def budget_status() -> BudgetStatus:
    """Show budget status for all students.

    Returns each student's budget, spending, remaining balance, and percentage used.
    Students using over 80% of their budget are flagged.
    """
    client = server.get_client()
    accounts = client.get_federated_cloud_accounts()

    students: list[BudgetEntry] = []
    total_budget = 0.0
    total_spent = 0.0
    total_remaining = 0.0

    for acc in accounts or []:
        budget = float(getattr(acc, "budget", 0) or 0)
        cost = float(getattr(acc, "aggregatedCost", 0) or 0)
        remaining = float(getattr(acc, "amountLeft", 0) or 0)
        pct = (cost / budget * 100) if budget > 0 else 0.0

        students.append(
            BudgetEntry(
                login=acc.login,
                budget=budget,
                spent=cost,
                remaining=remaining,
                percent_used=round(pct, 1),
                over_threshold=pct > 80,
            )
        )
        total_budget += budget
        total_spent += cost
        total_remaining += remaining

    total_pct = (total_spent / total_budget * 100) if total_budget > 0 else 0.0

    return BudgetStatus(
        students=students,
        total_budget=total_budget,
        total_spent=total_spent,
        total_remaining=total_remaining,
        total_percent_used=round(total_pct, 1),
        student_count=len(students),
    )


@server.mcp.tool()
def budget_transfer(amount: float) -> TransferResult:
    """Transfer budget to ALL student accounts.

    Args:
        amount: Dollar amount to transfer to each student account
    """
    if amount <= 0:
        raise ValueError("Amount must be positive")

    client = server.get_client()
    accounts = client.get_federated_cloud_accounts()
    uids = [acc.cloudAccountUid for acc in (accounts or [])]
    logins = [acc.login for acc in (accounts or [])]

    if not uids:
        raise ValueError("No student accounts found to transfer budget to")

    client.transfer_budget(uids, amount)
    return TransferResult(amount=amount, accounts=len(uids), logins=logins)


@server.mcp.tool()
def budget_transfer_user(login: str, amount: float) -> TransferResult:
    """Transfer budget to a single student's account.

    Args:
        login: Student login identifier
        amount: Dollar amount to transfer
    """
    if amount <= 0:
        raise ValueError("Amount must be positive")

    client = server.get_client()
    acc = client.find_account_by_login(login)
    client.transfer_budget([acc.cloudAccountUid], amount)
    return TransferResult(amount=amount, accounts=1, logins=[login])
