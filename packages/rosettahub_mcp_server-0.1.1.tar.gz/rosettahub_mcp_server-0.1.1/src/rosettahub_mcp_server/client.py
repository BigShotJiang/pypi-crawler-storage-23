"""Singleton SOAP client wrapper for the RosettaHUB API."""

from __future__ import annotations

import logging
from typing import Any

import zeep

from rosettahub_mcp_server.config import Config

logger = logging.getLogger(__name__)


class RosettaHubClient:
    """Lazy-initializing singleton wrapper around the zeep SOAP client.

    The WSDL is only parsed once on first use, since it's expensive.
    """

    def __init__(self, config: Config) -> None:
        self._config = config
        self._service: Any | None = None
        self._zeep_client: zeep.Client | None = None

    @property
    def service(self) -> Any:
        """Get the zeep service proxy, initializing on first access."""
        if self._service is None:
            logger.info("Connecting to RosettaHUB WSDL: %s", self._config.wsdl_url)
            self._zeep_client = zeep.Client(self._config.wsdl_url)
            self._service = self._zeep_client.service
        return self._service

    @property
    def zeep_client(self) -> zeep.Client:
        """Get the raw zeep client (needed for listing methods)."""
        if self._zeep_client is None:
            # Accessing .service triggers initialization
            _ = self.service
        # After service init, _zeep_client is guaranteed to be set
        return self._zeep_client  # type: ignore[return-value]

    @property
    def api_key(self) -> str:
        return self._config.api_key

    @property
    def org_name(self) -> str:
        return self._config.org_name

    @property
    def aws_region(self) -> str:
        return self._config.aws_region

    def get_user_info(self) -> Any:
        """Get info about the authenticated user."""
        return self.service.getUserInfo(self.api_key)

    def get_basic_cloud_accounts(self) -> Any:
        """List the user's own cloud accounts."""
        return self.service.getBasicCloudAccounts(self.api_key)

    def get_federated_cloud_accounts(self) -> Any:
        """List all federated (student) cloud accounts with budgets."""
        return self.service.cpocGetFederatedCloudAccounts(
            self.api_key,
            False,
            {
                "organizationName": self.org_name,
                "cloudId": "aws",
                "includeCustomization": False,
            },
        )

    def get_federated_users(self) -> Any:
        """List all federated users in the organization."""
        return self.service.cpocGetFederatedUsers(
            self.api_key,
            False,
            False,
            {"organizationName": self.org_name},
        )

    def get_sts_session(self, cloud_account_uid: str, duration: int = 3600) -> Any:
        """Get STS temporary credentials for a student's cloud account."""
        return self.service.suGetStsSession(self.api_key, cloud_account_uid, duration)

    def transfer_budget(self, cloud_account_uids: list[str], amount: float) -> Any:
        """Transfer budget to one or more student accounts."""
        return self.service.cpocTransferBudget(
            self.api_key, cloud_account_uids, amount, False, None
        )

    def quarantine_users(self, cloud_account_uids: list[str]) -> Any:
        """Quarantine (restrict) student cloud accounts."""
        return self.service.cpocQuarantineUsers(self.api_key, cloud_account_uids, False, None)

    def unquarantine_users(self, cloud_account_uids: list[str]) -> Any:
        """Unquarantine (restore) student cloud accounts."""
        return self.service.cpocUnquarantineUsers(self.api_key, cloud_account_uids, False, None)

    def set_allowed_regions(self, logins: list[str], cloud_id: str, regions: list[str]) -> Any:
        """Set allowed AWS regions for students."""
        return self.service.cpocSetAllowedRegions(self.api_key, logins, cloud_id, regions, None)

    def list_api_methods(self) -> list[str]:
        """List all available SOAP API method names."""
        methods: set[str] = set()
        for service in self.zeep_client.wsdl.services.values():
            for port in service.ports.values():
                methods.update(port.binding._operations.keys())
        return sorted(methods)

    def find_account_by_login(self, login: str) -> Any:
        """Find a specific student's cloud account by login.

        Raises ValueError if the login is not found.
        """
        accounts = self.get_federated_cloud_accounts()
        for acc in accounts or []:
            if getattr(acc, "login", "") == login:
                return acc
        available = [getattr(a, "login", "N/A") for a in (accounts or [])]
        raise ValueError(
            f"No cloud account found for '{login}'. Available logins: {', '.join(available)}"
        )
