"""TypedDict return types for MCP tool responses."""

from __future__ import annotations

import sys

if sys.version_info >= (3, 12):
    from typing import TypedDict
else:
    from typing_extensions import TypedDict


class UserInfo(TypedDict):
    firstname: str
    lastname: str
    email: str
    institution_id: str
    reg_type: str
    roles: list[str]


class CloudAccount(TypedDict):
    login: str
    account_number: str
    cloud_id: str
    cloud_account_uid: str


class StudentAccount(TypedDict):
    login: str
    cloud_account_uid: str
    budget: float
    cost: float
    remaining: float


class FederatedUser(TypedDict):
    login: str
    enabled: bool
    email: str


class AwsExecResult(TypedDict):
    login: str
    stdout: str
    stderr: str
    return_code: int


class AwsExecAllResult(TypedDict):
    command: str
    total_accounts: int
    results: list[AwsExecResult]


class Ec2Instance(TypedDict):
    login: str
    instance_id: str
    instance_type: str
    state: str
    launch_time: str


class StsCredentials(TypedDict):
    login: str
    cloud_account_uid: str
    access_key_id: str
    secret_access_key: str
    session_token: str
    region: str


class ConsoleUrl(TypedDict):
    login: str
    url: str


class BudgetEntry(TypedDict):
    login: str
    budget: float
    spent: float
    remaining: float
    percent_used: float
    over_threshold: bool


class BudgetStatus(TypedDict):
    students: list[BudgetEntry]
    total_budget: float
    total_spent: float
    total_remaining: float
    total_percent_used: float
    student_count: int


class TransferResult(TypedDict):
    amount: float
    accounts: int
    logins: list[str]


class QuarantineResult(TypedDict):
    login: str
    action: str


class RegionsResult(TypedDict):
    login: str
    regions: list[str]
