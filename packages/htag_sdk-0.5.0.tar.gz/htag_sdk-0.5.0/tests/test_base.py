"""Tests for base client utilities: query serialisation, error mapping, retry delay."""

from __future__ import annotations

from htag_sdk._base import (
    _serialise_params,
    _exception_for_status,
    _retry_delay,
)
from htag_sdk._exceptions import (
    AuthenticationError,
    HtAgError,
    NotFoundError,
    RateLimitError,
    ServerError,
    ValidationError,
)


class TestSerialiseParams:
    def test_drops_none_values(self):
        result = _serialise_params({"a": None, "b": "yes"})
        assert result == {"b": "yes"}

    def test_passes_lists(self):
        result = _serialise_params({"area_id": ["SAL10001", "SAL10002"]})
        assert result == {"area_id": ["SAL10001", "SAL10002"]}

    def test_filters_none_from_lists(self):
        result = _serialise_params({"ids": ["a", None, "b"]})
        assert result == {"ids": ["a", "b"]}

    def test_drops_empty_lists(self):
        result = _serialise_params({"ids": []})
        assert result == {}

    def test_booleans_lowered_to_string(self):
        result = _serialise_params({"include": True, "exclude": False})
        assert result == {"include": "true", "exclude": "false"}

    def test_numbers_pass_through(self):
        result = _serialise_params({"limit": 10, "offset": 0})
        assert result == {"limit": 10, "offset": 0}

    def test_empty_params(self):
        assert _serialise_params({}) == {}


class TestExceptionForStatus:
    def test_401_returns_authentication_error(self):
        assert _exception_for_status(401) is AuthenticationError

    def test_403_returns_authentication_error(self):
        assert _exception_for_status(403) is AuthenticationError

    def test_429_returns_rate_limit_error(self):
        assert _exception_for_status(429) is RateLimitError

    def test_400_returns_validation_error(self):
        assert _exception_for_status(400) is ValidationError

    def test_422_returns_validation_error(self):
        assert _exception_for_status(422) is ValidationError

    def test_404_returns_not_found_error(self):
        assert _exception_for_status(404) is NotFoundError

    def test_500_returns_server_error(self):
        assert _exception_for_status(500) is ServerError

    def test_502_returns_server_error(self):
        assert _exception_for_status(502) is ServerError

    def test_418_returns_base_error(self):
        assert _exception_for_status(418) is HtAgError


class TestRetryDelay:
    def test_first_attempt_around_half_second(self):
        delay = _retry_delay(0)
        # Base is 0.5 * 2^0 = 0.5, plus up to 25% jitter
        assert 0.5 <= delay <= 0.5 * 1.25

    def test_second_attempt_is_larger(self):
        delay = _retry_delay(1)
        # Base is 0.5 * 2^1 = 1.0, plus up to 25% jitter
        assert 1.0 <= delay <= 1.0 * 1.25

    def test_respects_retry_after(self):
        delay = _retry_delay(0, retry_after=10.0)
        assert delay == 10.0

    def test_capped_at_30_seconds(self):
        delay = _retry_delay(100)
        assert delay <= 30.0 * 1.25
