"""Synchronous HtAG API client."""

from __future__ import annotations

from typing import Optional

import httpx

from htag_sdk._base import SyncRequestMixin
from htag_sdk.address.client import AddressClient
from htag_sdk.intent_hub.client import IntentHubClient
from htag_sdk.markets.client import MarketsClient
from htag_sdk.property.client import PropertyClient


class HtAgApi(SyncRequestMixin):
    """Synchronous client for the HtAG AI API.

    Usage::

        from htag_sdk import HtAgApi

        client = HtAgApi(api_key="sk-...", environment="prod")

        # Address search
        results = client.address.search("100 George St Sydney")

        # Property sold search
        sold = client.property.sold_search(address="100 George St Sydney")

        # Market snapshots
        snapshots = client.markets.snapshots(level="suburb", property_type=["house"])

        # Market trends
        prices = client.markets.trends.price(level="suburb", area_id=["SAL10001"])

        # Always close when done (or use as a context manager)
        client.close()

    As a context manager::

        with HtAgApi(api_key="sk-...", environment="prod") as client:
            results = client.address.search("100 George St Sydney")

    Args:
        api_key: Your HtAG API key (required).
        environment: Target environment -- ``"prod"`` or ``"dev"``.
        base_url: Custom base URL (overrides ``environment``).
        timeout: Request timeout in seconds (default 60).
        max_retries: Maximum number of retry attempts for transient errors (default 3).
    """

    address: AddressClient
    property: PropertyClient
    markets: MarketsClient
    intent_hub: IntentHubClient

    def __init__(
        self,
        *,
        api_key: str,
        environment: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: float = 60.0,
        max_retries: int = 3,
    ) -> None:
        super().__init__(
            api_key=api_key,
            environment=environment,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
        )
        self._http = httpx.Client()
        self.address = AddressClient(self)
        self.property = PropertyClient(self)
        self.markets = MarketsClient(self)
        self.intent_hub = IntentHubClient(self)

    def close(self) -> None:
        """Release underlying HTTP connection pool resources."""
        self._http.close()

    def __enter__(self) -> "HtAgApi":
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    def __repr__(self) -> str:
        return f"HtAgApi(base_url={self._base_url!r})"
