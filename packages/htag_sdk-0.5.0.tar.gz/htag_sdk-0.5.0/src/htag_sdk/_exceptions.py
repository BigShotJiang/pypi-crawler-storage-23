"""Exception classes for the HtAG SDK."""

from __future__ import annotations

from typing import Any, Optional


class HtAgError(Exception):
    """Base exception for all HtAG SDK errors.

    Attributes:
        message: Human-readable error description.
        status_code: HTTP status code from the API response, if applicable.
        body: Raw response body from the API, if available.
        request_id: Request identifier for support inquiries, if returned.
    """

    message: str
    status_code: Optional[int]
    body: Optional[Any]
    request_id: Optional[str]

    def __init__(
        self,
        message: str,
        *,
        status_code: Optional[int] = None,
        body: Optional[Any] = None,
        request_id: Optional[str] = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.body = body
        self.request_id = request_id

    def __repr__(self) -> str:
        cls = self.__class__.__name__
        parts = [f"message={self.message!r}"]
        if self.status_code is not None:
            parts.append(f"status_code={self.status_code}")
        if self.request_id is not None:
            parts.append(f"request_id={self.request_id!r}")
        return f"{cls}({', '.join(parts)})"


class AuthenticationError(HtAgError):
    """Raised when the API returns a 401 or 403 status code.

    This typically means the API key is missing, invalid, or does not have
    permission to access the requested resource.
    """


class RateLimitError(HtAgError):
    """Raised when the API returns a 429 status code.

    The request was throttled. Retry after the period indicated by the
    ``Retry-After`` header, or use the built-in retry logic.
    """

    retry_after: Optional[float]

    def __init__(
        self,
        message: str,
        *,
        status_code: Optional[int] = 429,
        body: Optional[Any] = None,
        request_id: Optional[str] = None,
        retry_after: Optional[float] = None,
    ) -> None:
        super().__init__(
            message,
            status_code=status_code,
            body=body,
            request_id=request_id,
        )
        self.retry_after = retry_after


class ValidationError(HtAgError):
    """Raised when the API returns a 400 or 422 status code.

    The request was malformed. Check the ``body`` attribute for details
    about which parameters failed validation.
    """


class NotFoundError(HtAgError):
    """Raised when the API returns a 404 status code."""


class ServerError(HtAgError):
    """Raised when the API returns a 5xx status code.

    An unexpected error occurred on the server. These are typically
    transient and the built-in retry logic will attempt to recover.
    """


class ConnectionError(HtAgError):
    """Raised when the SDK cannot connect to the API.

    This wraps underlying transport errors such as DNS resolution failures,
    connection timeouts, and TLS handshake errors.
    """
