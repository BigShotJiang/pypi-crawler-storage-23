"""Synchronous client for the Address API domain."""

from __future__ import annotations

from typing import TYPE_CHECKING, List, Optional

from htag_sdk.address.models import (
    AddressInsightsResponse,
    AddressSearchResponse,
    BatchStandardiseResponse,
)

if TYPE_CHECKING:
    from htag_sdk._base import SyncRequestMixin


class AddressClient:
    """Synchronous client for address search, insights, and standardisation.

    This class is not instantiated directly. Access it via ``client.address``.
    """

    _client: "SyncRequestMixin"

    def __init__(self, client: "SyncRequestMixin") -> None:
        self._client = client

    def search(
        self,
        q: str,
        *,
        threshold: float = 0.3,
        limit: int = 10,
    ) -> AddressSearchResponse:
        """Search for addresses by free-text query.

        Args:
            q: Search query string (minimum 3 characters).
            threshold: Minimum relevance score between 0.1 and 1.0.
            limit: Maximum number of results to return (1-50).

        Returns:
            An :class:`AddressSearchResponse` containing matching addresses
            with relevance scores.

        Raises:
            ValidationError: If query is too short or parameters are out of range.
            AuthenticationError: If the API key is invalid.
        """
        data = self._client._request(
            "GET",
            "/address/search",
            params={
                "q": q,
                "threshold": threshold,
                "limit": limit,
            },
        )
        return AddressSearchResponse.model_validate(data)

    def insights(
        self,
        *,
        address: Optional[str] = None,
        address_keys: Optional[List[str]] = None,
        legal_parcel_id: Optional[str] = None,
        street_loc_pid: Optional[str] = None,
        mb_category_2021: Optional[List[str]] = None,
    ) -> AddressInsightsResponse:
        """Retrieve enriched insights for an address.

        Exactly one of ``address``, ``address_keys``, or ``legal_parcel_id``
        must be provided as the primary lookup key.

        Args:
            address: Full address string to look up.
            address_keys: One or more GNAF address keys.
            legal_parcel_id: Legal parcel identifier.
            street_loc_pid: Street locality PID filter.
            mb_category_2021: Mesh-block category filter.

        Returns:
            An :class:`AddressInsightsResponse` with enriched address records.

        Raises:
            ValidationError: If the parameter combination is invalid.
        """
        params = {
            "address": address,
            "address_keys": address_keys,
            "legal_parcel_id": legal_parcel_id,
            "street_loc_pid": street_loc_pid,
            "mb_category_2021": mb_category_2021,
        }
        data = self._client._request("GET", "/address/insights", params=params)
        return AddressInsightsResponse.model_validate(data)

    def standardise(
        self,
        addresses: List[str],
    ) -> BatchStandardiseResponse:
        """Standardise a batch of free-text Australian addresses.

        Args:
            addresses: List of address strings to standardise (max 50).

        Returns:
            A :class:`BatchStandardiseResponse` with standardised components
            for each input address.

        Raises:
            ValidationError: If the list exceeds 50 addresses.
        """
        data = self._client._request(
            "POST",
            "/address/standardise",
            json={"addresses": addresses},
        )
        return BatchStandardiseResponse.model_validate(data)
