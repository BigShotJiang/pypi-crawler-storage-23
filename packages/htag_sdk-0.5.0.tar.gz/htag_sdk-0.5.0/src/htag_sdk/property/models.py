"""Pydantic models for the Property API domain."""

from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel, ConfigDict


class SoldPropertyRecord(BaseModel):
    """A single sold property record."""

    model_config = ConfigDict(populate_by_name=True)

    address_key: Optional[str] = None
    property_type: Optional[str] = None
    street_address: Optional[str] = None
    suburb: Optional[str] = None
    state: Optional[str] = None
    postcode: Optional[str] = None
    lat: Optional[float] = None
    lon: Optional[float] = None
    sold_date: Optional[str] = None
    sold_price: Optional[float] = None
    bedrooms: Optional[int] = None
    bathrooms: Optional[int] = None
    car_spaces: Optional[int] = None
    land_area: Optional[int] = None


class SoldPropertiesResponse(BaseModel):
    """Response from the sold property search endpoint."""

    model_config = ConfigDict(populate_by_name=True)

    total: int
    results: List[SoldPropertyRecord]
