#!/usr/bin/env python
"""SPDX-FileCopyrightText: (c) 2025 by mundialis GmbH & Co. KG.

SPDX-License-Identifier: GPL-3.0-or-later

Apidocs for webhook endpoint
"""

__license__ = "GPL-3.0-or-later"
__author__ = "Carmen Tawalika"
__copyright__ = "Copyright 2025 mundialis GmbH & Co. KG"
__maintainer__ = "mundialis GmbH & Co. KG"


from actinia_cloudevent_plugin.model.response_models import (
    SimpleStatusCodeResponseModel,
)

describe_hooks_post_docs = {
    # "summary" is taken from the description of the get method
    "tags": ["cloudevent"],
    "description": (
        "Receives webhook with status update e.g. from actinia-core,"
        " transforms to cloudevent and sends it to configurable endpoint."
    ),
    "responses": {
        "200": {
            "description": (
                "This response returns a cloud event, "
                "generated from actinia-core status"
            ),
            "schema": SimpleStatusCodeResponseModel,
        },
        "400": {
            "description": "This response returns an error message",
            "schema": SimpleStatusCodeResponseModel,
        },
    },
}
