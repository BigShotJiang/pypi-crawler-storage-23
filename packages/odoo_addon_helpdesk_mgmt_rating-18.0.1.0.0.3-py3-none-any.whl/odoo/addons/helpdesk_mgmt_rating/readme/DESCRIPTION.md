This module adds the possibility to rate the assistance received through
helpdesk tickets.
