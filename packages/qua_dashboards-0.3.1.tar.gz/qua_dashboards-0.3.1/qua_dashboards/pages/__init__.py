dashboards_registry = {}
