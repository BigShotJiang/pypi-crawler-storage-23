"""Global list of the active features."""

from __future__ import annotations

lightly_studio_active_features: list[str] = []
