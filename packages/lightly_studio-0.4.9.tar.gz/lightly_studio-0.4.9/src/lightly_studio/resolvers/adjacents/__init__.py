"""Resolvers for adjacent operations."""

from lightly_studio.resolvers.adjacents.get_sample_adjacent_info import get_sample_adjacent_info

__all__ = [
    "get_sample_adjacent_info",
]
