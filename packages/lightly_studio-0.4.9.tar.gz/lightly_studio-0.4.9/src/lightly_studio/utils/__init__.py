from .download import download_example_dataset

__all__ = ["download_example_dataset"]
