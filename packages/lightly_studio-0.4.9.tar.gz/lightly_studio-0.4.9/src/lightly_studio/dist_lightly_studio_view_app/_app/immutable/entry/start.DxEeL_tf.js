import{l as o,b as r}from"../chunks/DYyyW70Z.js";export{o as load_css,r as start};
