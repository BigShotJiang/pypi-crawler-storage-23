import{e}from"./DIeogL5L.js";e();
