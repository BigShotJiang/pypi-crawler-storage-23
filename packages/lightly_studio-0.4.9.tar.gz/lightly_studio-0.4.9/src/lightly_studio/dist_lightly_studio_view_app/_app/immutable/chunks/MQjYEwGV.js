import"./CWj6FrbW.js";import{p as b,f as w,d as M,a as p,g as y,b as K,r as u,c as v,s as z,t as E}from"./CWfpYv5x.js";import{c as A,a as c,f as x}from"./CINrwajP.js";import{s as _}from"./BCoLGHJP.js";import{c as O,r as P,i as V,b as T,p as B,e as k}from"./9AUqZv3H.js";import{I as L,i as X,a1 as Y,a2 as Z,b as $,L as ee,S as ae,a3 as te}from"./CbNz9Fsv.js";import{g as re}from"./DXlOyMga.js";import{e as se}from"./DIf3oxZO.js";import{s as I,d as q}from"./CJToRF9l.js";import{a as le}from"./DELrRF6e.js";import{c as N}from"./hp5em2PY.js";function Ae(l,e){b(e,!0);/**
 * @license @lucide/svelte v0.482.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */let r=P(e,["$$slots","$$events","$$legacy"]);const s=[["ellipse",{cx:"12",cy:"5",rx:"9",ry:"3"}],["path",{d:"M3 5V19A9 3 0 0 0 21 19V5"}],["path",{d:"M3 12A9 3 0 0 0 21 12"}]];L(l,O({name:"database"},()=>r,{get iconNode(){return s},children:(a,n)=>{var t=A(),d=w(t);_(d,()=>e.children??M),c(a,t)},$$slots:{default:!0}})),p()}function Be(l,e){b(e,!0);/**
 * @license @lucide/svelte v0.482.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */let r=P(e,["$$slots","$$events","$$legacy"]);const s=[["path",{d:"M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8"}],["path",{d:"M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"}]];L(l,O({name:"house"},()=>r,{get iconNode(){return s},children:(a,n)=>{var t=A(),d=w(t);_(d,()=>e.children??M),c(a,t)},$$slots:{default:!0}})),p()}const je=({collectionId:l})=>{const e=X(Y());return e.subscribe(()=>{}),{removeTagFromSample:(s,a)=>new Promise((n,t)=>{re(e).mutate({path:{collection_id:l,sample_id:s,tag_id:a}},{onSuccess:()=>n(),onError:d=>t(d)})})}},Ce=({params:l,queryClient:e})=>{const r=Z({path:{sample_id:l.sampleId},body:l.body}),s=$(e);return{query:ee(r,s),refetch:()=>{s.invalidateQueries({queryKey:r.queryKey})}}};var ne=x('<div class="flex items-start gap-3"><span class="truncate text-sm font-medium"> </span> <pre class="min-w-[8rem] flex-1 overflow-x-auto whitespace-pre-wrap rounded bg-muted p-2 text-sm"> </pre></div>'),oe=x('<div class="flex items-start gap-3"><span class="truncate text-sm font-medium"> </span> <span class="min-w-[8rem] flex-1 break-all text-sm"> </span></div>'),ie=x('<div class="space-y-3 text-diffuse-foreground"></div>');function ke(l,e){b(e,!0);const r=K(()=>{const t=[];if(e.metadata_dict&&typeof e.metadata_dict=="object"&&"data"in e.metadata_dict){const d=e.metadata_dict.data;d&&typeof d=="object"&&Object.entries(d).forEach(([o,f])=>{const m=le(f),i=typeof f=="object"&&f!==null&&!Array.isArray(f);t.push({id:`metadata_${o}`,label:`${o}:`,value:m,isComplex:i})})}return t});var s=A(),a=w(s);{var n=t=>{ae(t,{title:"Metadata",children:(d,o)=>{var f=ie();se(f,21,()=>y(r),({label:m,value:i,id:h,isComplex:F})=>m,(m,i)=>{let h=()=>y(i).label,F=()=>y(i).value,R=()=>y(i).id,G=()=>y(i).isComplex;var Q=A(),J=w(Q);{var U=j=>{var S=ne(),g=v(S),D=v(g,!0);u(g);var C=z(g,2),H=v(C,!0);u(C),u(S),E(()=>{I(g,"title",h()),T(D,h()),T(H,F())}),c(j,S)},W=j=>{var S=oe(),g=v(S),D=v(g,!0);u(g);var C=z(g,2),H=v(C,!0);u(C),u(S),E(()=>{I(g,"title",h()),T(D,h()),I(C,"data-testid",`sample-metadata-${R()}`),T(H,F())}),c(j,S)};V(J,j=>{G()?j(U):j(W,!1)})}c(m,Q)}),u(f),c(d,f)}})};V(a,t=>{y(r).length>0&&t(n)})}c(l,s),p()}var ce=x("<nav><!></nav>");function qe(l,e){b(e,!0);let r=B(e,"ref",15),s=P(e,["$$slots","$$events","$$legacy","ref","class","children"]);var a=ce();q(a,()=>({class:e.class,"aria-label":"breadcrumb",...s}));var n=v(a);_(n,()=>e.children??M),u(a),k(a,t=>r(t),()=>r()),c(l,a),p()}var de=x("<li><!></li>");function Fe(l,e){b(e,!0);let r=B(e,"ref",15,null),s=P(e,["$$slots","$$events","$$legacy","ref","class","children"]);var a=de();q(a,t=>({class:t,...s}),[()=>N("inline-flex items-center gap-1.5",e.class)]);var n=v(a);_(n,()=>e.children??M),u(a),k(a,t=>r(t),()=>r()),c(l,a),p()}var me=x("<li><!></li>");function Ne(l,e){b(e,!0);let r=B(e,"ref",15,null),s=P(e,["$$slots","$$events","$$legacy","ref","class","children"]);var a=me();q(a,o=>({role:"presentation","aria-hidden":"true",class:o,...s}),[()=>N("[&>svg]:size-3.5",e.class)]);var n=v(a);{var t=o=>{var f=A(),m=w(f);_(m,()=>e.children??M),c(o,f)},d=o=>{te(o,{})};V(n,o=>{e.children?o(t):o(d,!1)})}u(a),k(a,o=>r(o),()=>r()),c(l,a),p()}var fe=x("<a><!></a>");function Te(l,e){b(e,!0);let r=B(e,"ref",15,null),s=B(e,"href",3,void 0),a=P(e,["$$slots","$$events","$$legacy","ref","class","href","child","children"]);const n=K(()=>({class:N("hover:text-foreground transition-colors",e.class),href:s(),...a}));var t=A(),d=w(t);{var o=m=>{var i=A(),h=w(i);_(h,()=>e.child,()=>({props:y(n)})),c(m,i)},f=m=>{var i=fe();q(i,()=>({...y(n)}));var h=v(i);_(h,()=>e.children??M),u(i),k(i,F=>r(F),()=>r()),c(m,i)};V(d,m=>{e.child?m(o):m(f,!1)})}c(l,t),p()}var ue=x("<ol><!></ol>");function Ve(l,e){b(e,!0);let r=B(e,"ref",15,null),s=P(e,["$$slots","$$events","$$legacy","ref","class","children"]);var a=ue();q(a,t=>({class:t,...s}),[()=>N("text-muted-foreground flex flex-wrap items-center gap-1.5 break-words text-sm sm:gap-2.5",e.class)]);var n=v(a);_(n,()=>e.children??M),u(a),k(a,t=>r(t),()=>r()),c(l,a),p()}var ve=x("<span><!></span>");function De(l,e){b(e,!0);let r=B(e,"ref",15,null),s=P(e,["$$slots","$$events","$$legacy","ref","class","children"]);var a=ve();q(a,t=>({role:"link","aria-disabled":"true","aria-current":"page",class:t,...s}),[()=>N("text-foreground font-normal",e.class)]);var n=v(a);_(n,()=>e.children??M),u(a),k(a,t=>r(t),()=>r()),c(l,a),p()}export{qe as B,Ae as D,Be as H,ke as M,Ve as a,Fe as b,Te as c,Ne as d,De as e,je as f,Ce as u};
