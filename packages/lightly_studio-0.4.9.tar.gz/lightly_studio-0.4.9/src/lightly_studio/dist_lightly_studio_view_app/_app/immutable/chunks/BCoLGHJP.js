import{e as o,E as f,k as i,d as p,y as c,h as d,o as h}from"./CWfpYv5x.js";function E(s,n,...t){var r=s,e=p,a;o(()=>{e!==(e=n())&&(a&&(c(a),a=null),a=i(()=>e(r,...t)))},f),d&&(r=h)}export{E as s};
