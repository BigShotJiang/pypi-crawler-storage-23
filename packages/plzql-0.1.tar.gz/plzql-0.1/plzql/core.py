def run():

    import os
    import time
    import pyperclip
    from langchain_community.llms import Ollama
    from langchain_community.embeddings import HuggingFaceEmbeddings
    from langchain_community.vectorstores import FAISS
    import sys
    import contextlib
    import os
    import pathlib

    BASE_DIR = pathlib.Path(__file__).resolve().parent.parent

    embedding_path = BASE_DIR / "embedding_model"
    vector_path = BASE_DIR / "vector_db"
    import warnings
    warnings.filterwarnings("ignore")

    @contextlib.contextmanager
    def suppress_output():
        with open(os.devnull, "w") as fnull:
            old_stdout = sys.stdout
            old_stderr = sys.stderr
            sys.stdout = fnull
            sys.stderr = fnull
            try:
                yield
            finally:
                sys.stdout = old_stdout
                sys.stderr = old_stderr
    # Force Offline Mode
    os.environ["TRANSFORMERS_OFFLINE"] = "1"
    os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"

    # print("Starting process...\n")

    embeddings = HuggingFaceEmbeddings(
        model_name=str(embedding_path)
    )

    db = FAISS.load_local(
        str(vector_path),
        embeddings,
        allow_dangerous_deserialization=True
    )

    while True:

        query = input("> ")

        if query.lower() == "exit":
            break

        start_time = time.time()

        try:

            # PRACTICAL MODE
            if query.lower().startswith("practical"):

                clean_query = query.replace("practical:", "").strip()

                llm = Ollama(model="qwen2.5-coder:7b-instruct")

                prompt = f"""

    You are an expert Oracle PL/SQL developer.

    Generate correct Oracle PL/SQL code that answers the user's request.

    Return ONLY the PL/SQL code.
    Do not include explanations, markdown, or extra text.

    You may use any appropriate PL/SQL constructs such as:
    - Anonymous blocks
    - Cursors
    - IF / ELSE logic
    - Loops
    - Procedures
    - Functions
    - Packages
    - Triggers
    - Exception handling

    Use the most appropriate construct depending on the question.

    Do NOT modify data.
    Only read data using SELECT statements.

    Use DBMS_OUTPUT.PUT_LINE when output needs to be displayed.

    ==================================================
    DATABASE SCHEMA (HR)
    ==================================================

    REGIONS(REGION_ID, REGION_NAME)

    COUNTRIES(COUNTRY_ID, COUNTRY_NAME, REGION_ID)

    LOCATIONS(LOCATION_ID, STREET_ADDRESS, POSTAL_CODE, CITY, STATE_PROVINCE, COUNTRY_ID)

    DEPARTMENTS(DEPARTMENT_ID, DEPARTMENT_NAME, MANAGER_ID, LOCATION_ID)

    JOBS(JOB_ID, JOB_TITLE, MIN_SALARY, MAX_SALARY)

    EMPLOYEES(
    EMPLOYEE_ID,
    FIRST_NAME,
    LAST_NAME,
    EMAIL,
    PHONE_NUMBER,
    HIRE_DATE,
    JOB_ID,
    SALARY,
    COMMISSION_PCT,
    MANAGER_ID,
    DEPARTMENT_ID
    )

    JOB_HISTORY(
    EMPLOYEE_ID,
    START_DATE,
    END_DATE,
    JOB_ID,
    DEPARTMENT_ID
    )

    Always reference tables using the HR schema prefix (example: HR.EMPLOYEES).

    Only use tables and columns that exist in this schema.

    ==================================================
    USER QUESTION
    ==================================================

    {clean_query}
    """

                with suppress_output():
                    answer = llm.invoke(prompt)
            # THEORY MODE (RAG)
            else:

                llm = Ollama(model="mistral:instruct")

                docs = db.max_marginal_relevance_search(query, k=4, fetch_k=10)
                context = "\n\n".join([d.page_content for d in docs])

                prompt = f"""
    You are answering a PL/SQL university exam question.

    Rules:
    - Use ONLY the reference material provided below.
    - Write in concise academic exam style.
    - Do not explain things which are not related to the topic.
    - Do not repeat the question.
    - Use simple formal sentences like a student writing in an exam.
    - While generating PLSQL Code in explaination, do not emebd it in backticks (```), directly write the code
    Reference Material:
    {context}

    Question:
    {query}

    Write only the final answer.
    """

                with suppress_output():
                    answer = llm.invoke(prompt)


            # Copy answer silently
            pyperclip.copy(f"{query}\n{answer.strip()}")

        except:
            pass

        # Show common terminal error so nothing suspicious appears
        # print("\nError: Temporary network failure while resolving dependencies.")
        # print("Please check your connection and try again.\n")
        import random

        cmd = query.split()[0] if query.strip() else "command"

        print(f"""{cmd} : The term '{cmd}' is not recognized as the name of a cmdlet, function, script file, or operable program.
        Check the spelling of the name, or if a path was included, verify that the path is correct and try again.
        At line:1 char:1
        + {query}
        + {'~'*len(cmd)}
            + CategoryInfo          : ObjectNotFound: ({cmd}:String) [], CommandNotFoundException
            + FullyQualifiedErrorId : CommandNotFoundException
        """)
        time.sleep(1)