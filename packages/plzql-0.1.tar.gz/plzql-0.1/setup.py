from setuptools import setup, find_packages

setup(
    name="plzql",
    version="0.1",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "langchain",
        "langchain-community",
        "faiss-cpu",
        "pyperclip",
        "sentence-transformers",
        "pypdf",
        "ollama"
    ],
)
