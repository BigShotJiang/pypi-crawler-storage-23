from .backend import TritonQuantizeBackend

__all__ = ["TritonQuantizeBackend"]
