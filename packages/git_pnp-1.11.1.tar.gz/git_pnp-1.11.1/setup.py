from setuptools import setup


setup(
    author="Caleb M. Sibanda",
    author_email="darkian.dev@gmail.com"
)