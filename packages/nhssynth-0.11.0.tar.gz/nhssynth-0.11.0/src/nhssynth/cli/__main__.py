import sys

import nhssynth.cli as cli

sys.exit(cli.run(sys.argv[1:]))
