def run(args):
    print("Running structural discovery module... (NOT IMPLEMENTED)")
