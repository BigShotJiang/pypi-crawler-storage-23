# uf/cli.py
from .engine import UFEngine

def main():
    engine = UFEngine()

    # Register modes
    from .engine import UFMode, iUFMode, nUFMode, dnUFMode
    engine.register_mode("uf", UFMode)
    engine.register_mode("iuf", iUFMode)
    engine.register_mode("nuf", nUFMode)
    engine.register_mode("dnuf", dnUFMode)

    # Optional: load from command line args (script)
    import sys
    if len(sys.argv) > 1:
        filename = sys.argv[1]
        engine.select_mode()  # select mode first
        engine.run_file(filename)
    else:
        # Interactive mode
        engine.select_mode()
        engine.run_repl()

if __name__ == "__main__":
    main()