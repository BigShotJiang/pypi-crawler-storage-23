[Sun Moon icon](https://lucide.dev/icons/sun-moon) by Lucide
