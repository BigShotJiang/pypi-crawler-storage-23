from odoo_mcp.server import main

main()
