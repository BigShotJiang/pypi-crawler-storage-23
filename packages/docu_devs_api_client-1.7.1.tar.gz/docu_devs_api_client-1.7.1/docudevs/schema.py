from __future__ import annotations

import json
from typing import Any, Union


def array_schema(model_or_schema: Any) -> str:
    """Wrap a Pydantic model or JSON schema dict as an array schema JSON string.

    Use this for map-reduce extraction where each chunk produces multiple items.

    Examples::

        from docudevs import array_schema

        schema = array_schema(ServiceSla)
        schema = array_schema({"type": "object", "properties": {"name": {"type": "string"}}})

    """
    return json.dumps({"type": "array", "items": _resolve_schema(model_or_schema)})


def json_schema(model_or_schema: Any) -> str:
    """Convert a Pydantic model or dict to a JSON schema string.

    Use this for single-object extraction.

    Examples::

        from docudevs import json_schema

        schema = json_schema(Invoice)
        schema = json_schema({"type": "object", "properties": {"total": {"type": "number"}}})

    """
    return json.dumps(_resolve_schema(model_or_schema))


def _resolve_schema(model_or_schema: Any) -> dict[str, Any]:
    if isinstance(model_or_schema, dict):
        return model_or_schema
    if hasattr(model_or_schema, "model_json_schema"):
        return model_or_schema.model_json_schema()  # type: ignore[no-any-return]
    raise TypeError(
        f"Expected a Pydantic model class or dict, got {type(model_or_schema).__name__}"
    )
