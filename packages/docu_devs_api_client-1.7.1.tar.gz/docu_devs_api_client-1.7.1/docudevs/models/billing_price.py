from collections.abc import Mapping
from typing import Any, TypeVar, Union, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="BillingPrice")


@_attrs_define
class BillingPrice:
    """
    Attributes:
        price_id (str):
        product_id (str):
        tokens_granted (int):
        currency (Union[None, Unset, str]):
        unit_amount (Union[None, Unset, int]):
        nickname (Union[None, Unset, str]):
    """

    price_id: str
    product_id: str
    tokens_granted: int
    currency: Union[None, Unset, str] = UNSET
    unit_amount: Union[None, Unset, int] = UNSET
    nickname: Union[None, Unset, str] = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        price_id = self.price_id

        product_id = self.product_id

        tokens_granted = self.tokens_granted

        currency: Union[None, Unset, str]
        if isinstance(self.currency, Unset):
            currency = UNSET
        else:
            currency = self.currency

        unit_amount: Union[None, Unset, int]
        if isinstance(self.unit_amount, Unset):
            unit_amount = UNSET
        else:
            unit_amount = self.unit_amount

        nickname: Union[None, Unset, str]
        if isinstance(self.nickname, Unset):
            nickname = UNSET
        else:
            nickname = self.nickname

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "priceId": price_id,
                "productId": product_id,
                "tokensGranted": tokens_granted,
            }
        )
        if currency is not UNSET:
            field_dict["currency"] = currency
        if unit_amount is not UNSET:
            field_dict["unitAmount"] = unit_amount
        if nickname is not UNSET:
            field_dict["nickname"] = nickname

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        price_id = d.pop("priceId")

        product_id = d.pop("productId")

        tokens_granted = d.pop("tokensGranted")

        def _parse_currency(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        currency = _parse_currency(d.pop("currency", UNSET))

        def _parse_unit_amount(data: object) -> Union[None, Unset, int]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, int], data)

        unit_amount = _parse_unit_amount(d.pop("unitAmount", UNSET))

        def _parse_nickname(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        nickname = _parse_nickname(d.pop("nickname", UNSET))

        billing_price = cls(
            price_id=price_id,
            product_id=product_id,
            tokens_granted=tokens_granted,
            currency=currency,
            unit_amount=unit_amount,
            nickname=nickname,
        )

        billing_price.additional_properties = d
        return billing_price

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
