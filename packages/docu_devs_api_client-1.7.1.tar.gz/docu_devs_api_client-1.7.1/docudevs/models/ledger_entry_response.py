from collections.abc import Mapping
from typing import Any, TypeVar, Union, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="LedgerEntryResponse")


@_attrs_define
class LedgerEntryResponse:
    """
    Attributes:
        token_delta (int):
        reason (str):
        created_at (str):
        job_guid (Union[None, Unset, str]):
    """

    token_delta: int
    reason: str
    created_at: str
    job_guid: Union[None, Unset, str] = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        token_delta = self.token_delta

        reason = self.reason

        created_at = self.created_at

        job_guid: Union[None, Unset, str]
        if isinstance(self.job_guid, Unset):
            job_guid = UNSET
        else:
            job_guid = self.job_guid

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "tokenDelta": token_delta,
                "reason": reason,
                "createdAt": created_at,
            }
        )
        if job_guid is not UNSET:
            field_dict["jobGuid"] = job_guid

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        token_delta = d.pop("tokenDelta")

        reason = d.pop("reason")

        created_at = d.pop("createdAt")

        def _parse_job_guid(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        job_guid = _parse_job_guid(d.pop("jobGuid", UNSET))

        ledger_entry_response = cls(
            token_delta=token_delta,
            reason=reason,
            created_at=created_at,
            job_guid=job_guid,
        )

        ledger_entry_response.additional_properties = d
        return ledger_entry_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
