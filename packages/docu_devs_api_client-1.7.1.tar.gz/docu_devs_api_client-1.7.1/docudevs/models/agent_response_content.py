from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, Union, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.agent_action import AgentAction
    from ..models.agent_response_content_suggested_config_type_1 import AgentResponseContentSuggestedConfigType1


T = TypeVar("T", bound="AgentResponseContent")


@_attrs_define
class AgentResponseContent:
    """
    Attributes:
        message (str):
        actions (Union[None, Unset, list['AgentAction']]):
        suggested_config (Union['AgentResponseContentSuggestedConfigType1', None, Unset]):
        tools_used (Union[None, Unset, list[str]]):
    """

    message: str
    actions: Union[None, Unset, list["AgentAction"]] = UNSET
    suggested_config: Union["AgentResponseContentSuggestedConfigType1", None, Unset] = UNSET
    tools_used: Union[None, Unset, list[str]] = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.agent_response_content_suggested_config_type_1 import AgentResponseContentSuggestedConfigType1

        message = self.message

        actions: Union[None, Unset, list[dict[str, Any]]]
        if isinstance(self.actions, Unset):
            actions = UNSET
        elif isinstance(self.actions, list):
            actions = []
            for actions_type_0_item_data in self.actions:
                actions_type_0_item = actions_type_0_item_data.to_dict()
                actions.append(actions_type_0_item)

        else:
            actions = self.actions

        suggested_config: Union[None, Unset, dict[str, Any]]
        if isinstance(self.suggested_config, Unset):
            suggested_config = UNSET
        elif isinstance(self.suggested_config, AgentResponseContentSuggestedConfigType1):
            suggested_config = self.suggested_config.to_dict()
        else:
            suggested_config = self.suggested_config

        tools_used: Union[None, Unset, list[str]]
        if isinstance(self.tools_used, Unset):
            tools_used = UNSET
        elif isinstance(self.tools_used, list):
            tools_used = self.tools_used

        else:
            tools_used = self.tools_used

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "message": message,
            }
        )
        if actions is not UNSET:
            field_dict["actions"] = actions
        if suggested_config is not UNSET:
            field_dict["suggestedConfig"] = suggested_config
        if tools_used is not UNSET:
            field_dict["toolsUsed"] = tools_used

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.agent_action import AgentAction
        from ..models.agent_response_content_suggested_config_type_1 import AgentResponseContentSuggestedConfigType1

        d = dict(src_dict)
        message = d.pop("message")

        def _parse_actions(data: object) -> Union[None, Unset, list["AgentAction"]]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                actions_type_0 = []
                _actions_type_0 = data
                for actions_type_0_item_data in _actions_type_0:
                    actions_type_0_item = AgentAction.from_dict(actions_type_0_item_data)

                    actions_type_0.append(actions_type_0_item)

                return actions_type_0
            except:  # noqa: E722
                pass
            return cast(Union[None, Unset, list["AgentAction"]], data)

        actions = _parse_actions(d.pop("actions", UNSET))

        def _parse_suggested_config(data: object) -> Union["AgentResponseContentSuggestedConfigType1", None, Unset]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                suggested_config_type_1 = AgentResponseContentSuggestedConfigType1.from_dict(data)

                return suggested_config_type_1
            except:  # noqa: E722
                pass
            return cast(Union["AgentResponseContentSuggestedConfigType1", None, Unset], data)

        suggested_config = _parse_suggested_config(d.pop("suggestedConfig", UNSET))

        def _parse_tools_used(data: object) -> Union[None, Unset, list[str]]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                tools_used_type_0 = cast(list[str], data)

                return tools_used_type_0
            except:  # noqa: E722
                pass
            return cast(Union[None, Unset, list[str]], data)

        tools_used = _parse_tools_used(d.pop("toolsUsed", UNSET))

        agent_response_content = cls(
            message=message,
            actions=actions,
            suggested_config=suggested_config,
            tools_used=tools_used,
        )

        agent_response_content.additional_properties = d
        return agent_response_content

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
