from collections.abc import Mapping
from typing import Any, TypeVar, Union, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="ExcelTemplateConfig")


@_attrs_define
class ExcelTemplateConfig:
    """
    Attributes:
        start_row (int):
        start_col (int):
        include_headers (bool):
        sheet_name (Union[None, Unset, str]):
    """

    start_row: int
    start_col: int
    include_headers: bool
    sheet_name: Union[None, Unset, str] = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        start_row = self.start_row

        start_col = self.start_col

        include_headers = self.include_headers

        sheet_name: Union[None, Unset, str]
        if isinstance(self.sheet_name, Unset):
            sheet_name = UNSET
        else:
            sheet_name = self.sheet_name

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "startRow": start_row,
                "startCol": start_col,
                "includeHeaders": include_headers,
            }
        )
        if sheet_name is not UNSET:
            field_dict["sheetName"] = sheet_name

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        start_row = d.pop("startRow")

        start_col = d.pop("startCol")

        include_headers = d.pop("includeHeaders")

        def _parse_sheet_name(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        sheet_name = _parse_sheet_name(d.pop("sheetName", UNSET))

        excel_template_config = cls(
            start_row=start_row,
            start_col=start_col,
            include_headers=include_headers,
            sheet_name=sheet_name,
        )

        excel_template_config.additional_properties = d
        return excel_template_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
