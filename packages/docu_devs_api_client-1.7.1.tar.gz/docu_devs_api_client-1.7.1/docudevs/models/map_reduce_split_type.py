from typing import Literal, cast

MapReduceSplitType = Literal["MARKDOWN_HEADER", "PAGE"]

MAP_REDUCE_SPLIT_TYPE_VALUES: set[MapReduceSplitType] = {
    "MARKDOWN_HEADER",
    "PAGE",
}


def check_map_reduce_split_type(value: str) -> MapReduceSplitType:
    if value in MAP_REDUCE_SPLIT_TYPE_VALUES:
        return cast(MapReduceSplitType, value)
    raise TypeError(f"Unexpected value {value!r}. Expected one of {MAP_REDUCE_SPLIT_TYPE_VALUES!r}")
