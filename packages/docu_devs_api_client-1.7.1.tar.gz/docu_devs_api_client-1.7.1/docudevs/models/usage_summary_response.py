from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.daily_usage_entry import DailyUsageEntry


T = TypeVar("T", bound="UsageSummaryResponse")


@_attrs_define
class UsageSummaryResponse:
    """
    Attributes:
        total_tokens_used (int):
        balance (int):
        by_type (Any):
        daily_usage (list['DailyUsageEntry']):
    """

    total_tokens_used: int
    balance: int
    by_type: Any
    daily_usage: list["DailyUsageEntry"]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        total_tokens_used = self.total_tokens_used

        balance = self.balance

        by_type = self.by_type

        daily_usage = []
        for daily_usage_item_data in self.daily_usage:
            daily_usage_item = daily_usage_item_data.to_dict()
            daily_usage.append(daily_usage_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "totalTokensUsed": total_tokens_used,
                "balance": balance,
                "byType": by_type,
                "dailyUsage": daily_usage,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.daily_usage_entry import DailyUsageEntry

        d = dict(src_dict)
        total_tokens_used = d.pop("totalTokensUsed")

        balance = d.pop("balance")

        by_type = d.pop("byType")

        daily_usage = []
        _daily_usage = d.pop("dailyUsage")
        for daily_usage_item_data in _daily_usage:
            daily_usage_item = DailyUsageEntry.from_dict(daily_usage_item_data)

            daily_usage.append(daily_usage_item)

        usage_summary_response = cls(
            total_tokens_used=total_tokens_used,
            balance=balance,
            by_type=by_type,
            daily_usage=daily_usage,
        )

        usage_summary_response.additional_properties = d
        return usage_summary_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
