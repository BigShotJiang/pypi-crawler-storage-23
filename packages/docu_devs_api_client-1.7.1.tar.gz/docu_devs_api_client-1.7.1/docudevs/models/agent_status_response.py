from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, Union, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.agent_response_content import AgentResponseContent


T = TypeVar("T", bound="AgentStatusResponse")


@_attrs_define
class AgentStatusResponse:
    """
    Attributes:
        job_guid (str):
        session_id (str):
        status (str):
        response (Union[Unset, AgentResponseContent]):
        error (Union[None, Unset, str]):
    """

    job_guid: str
    session_id: str
    status: str
    response: Union[Unset, "AgentResponseContent"] = UNSET
    error: Union[None, Unset, str] = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        job_guid = self.job_guid

        session_id = self.session_id

        status = self.status

        response: Union[Unset, dict[str, Any]] = UNSET
        if not isinstance(self.response, Unset):
            response = self.response.to_dict()

        error: Union[None, Unset, str]
        if isinstance(self.error, Unset):
            error = UNSET
        else:
            error = self.error

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "jobGuid": job_guid,
                "sessionId": session_id,
                "status": status,
            }
        )
        if response is not UNSET:
            field_dict["response"] = response
        if error is not UNSET:
            field_dict["error"] = error

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.agent_response_content import AgentResponseContent

        d = dict(src_dict)
        job_guid = d.pop("jobGuid")

        session_id = d.pop("sessionId")

        status = d.pop("status")

        _response = d.pop("response", UNSET)
        response: Union[Unset, AgentResponseContent]
        if isinstance(_response, Unset):
            response = UNSET
        else:
            response = AgentResponseContent.from_dict(_response)

        def _parse_error(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        error = _parse_error(d.pop("error", UNSET))

        agent_status_response = cls(
            job_guid=job_guid,
            session_id=session_id,
            status=status,
            response=response,
            error=error,
        )

        agent_status_response.additional_properties = d
        return agent_status_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
