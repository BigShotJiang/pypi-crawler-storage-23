from http import HTTPStatus
from typing import Any, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.agent_status_response import AgentStatusResponse
from ...types import Response


def _get_kwargs(
    job_guid: str,
) -> dict[str, Any]:
    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": f"/agent/status/{job_guid}",
    }

    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[AgentStatusResponse]:
    if response.status_code == 200:
        response_200 = AgentStatusResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[AgentStatusResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    job_guid: str,
    *,
    client: Union[AuthenticatedClient, Client],
) -> Response[AgentStatusResponse]:
    """
    Args:
        job_guid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AgentStatusResponse]
    """

    kwargs = _get_kwargs(
        job_guid=job_guid,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    job_guid: str,
    *,
    client: Union[AuthenticatedClient, Client],
) -> Optional[AgentStatusResponse]:
    """
    Args:
        job_guid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AgentStatusResponse
    """

    return sync_detailed(
        job_guid=job_guid,
        client=client,
    ).parsed


async def asyncio_detailed(
    job_guid: str,
    *,
    client: Union[AuthenticatedClient, Client],
) -> Response[AgentStatusResponse]:
    """
    Args:
        job_guid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AgentStatusResponse]
    """

    kwargs = _get_kwargs(
        job_guid=job_guid,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    job_guid: str,
    *,
    client: Union[AuthenticatedClient, Client],
) -> Optional[AgentStatusResponse]:
    """
    Args:
        job_guid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AgentStatusResponse
    """

    return (
        await asyncio_detailed(
            job_guid=job_guid,
            client=client,
        )
    ).parsed
