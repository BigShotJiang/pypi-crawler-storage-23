from http import HTTPStatus
from typing import Any, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.analyze_document_body import AnalyzeDocumentBody
from ...models.upload_response import UploadResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: AnalyzeDocumentBody,
    ocr: Union[None, Unset, str] = UNSET,
    describe_figures: Union[None, Unset, bool] = UNSET,
    extract_figures: Union[None, Unset, bool] = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    json_ocr: Union[None, Unset, str]
    if isinstance(ocr, Unset):
        json_ocr = UNSET
    else:
        json_ocr = ocr
    params["ocr"] = json_ocr

    json_describe_figures: Union[None, Unset, bool]
    if isinstance(describe_figures, Unset):
        json_describe_figures = UNSET
    else:
        json_describe_figures = describe_figures
    params["describeFigures"] = json_describe_figures

    json_extract_figures: Union[None, Unset, bool]
    if isinstance(extract_figures, Unset):
        json_extract_figures = UNSET
    else:
        json_extract_figures = extract_figures
    params["extractFigures"] = json_extract_figures

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/document/analyze",
        "params": params,
    }

    _kwargs["files"] = body.to_multipart()

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[UploadResponse]:
    if response.status_code == 200:
        response_200 = UploadResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[UploadResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    body: AnalyzeDocumentBody,
    ocr: Union[None, Unset, str] = UNSET,
    describe_figures: Union[None, Unset, bool] = UNSET,
    extract_figures: Union[None, Unset, bool] = UNSET,
) -> Response[UploadResponse]:
    """
    Args:
        ocr (Union[None, Unset, str]):
        describe_figures (Union[None, Unset, bool]):
        extract_figures (Union[None, Unset, bool]):
        body (AnalyzeDocumentBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UploadResponse]
    """

    kwargs = _get_kwargs(
        body=body,
        ocr=ocr,
        describe_figures=describe_figures,
        extract_figures=extract_figures,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: Union[AuthenticatedClient, Client],
    body: AnalyzeDocumentBody,
    ocr: Union[None, Unset, str] = UNSET,
    describe_figures: Union[None, Unset, bool] = UNSET,
    extract_figures: Union[None, Unset, bool] = UNSET,
) -> Optional[UploadResponse]:
    """
    Args:
        ocr (Union[None, Unset, str]):
        describe_figures (Union[None, Unset, bool]):
        extract_figures (Union[None, Unset, bool]):
        body (AnalyzeDocumentBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UploadResponse
    """

    return sync_detailed(
        client=client,
        body=body,
        ocr=ocr,
        describe_figures=describe_figures,
        extract_figures=extract_figures,
    ).parsed


async def asyncio_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    body: AnalyzeDocumentBody,
    ocr: Union[None, Unset, str] = UNSET,
    describe_figures: Union[None, Unset, bool] = UNSET,
    extract_figures: Union[None, Unset, bool] = UNSET,
) -> Response[UploadResponse]:
    """
    Args:
        ocr (Union[None, Unset, str]):
        describe_figures (Union[None, Unset, bool]):
        extract_figures (Union[None, Unset, bool]):
        body (AnalyzeDocumentBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UploadResponse]
    """

    kwargs = _get_kwargs(
        body=body,
        ocr=ocr,
        describe_figures=describe_figures,
        extract_figures=extract_figures,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: Union[AuthenticatedClient, Client],
    body: AnalyzeDocumentBody,
    ocr: Union[None, Unset, str] = UNSET,
    describe_figures: Union[None, Unset, bool] = UNSET,
    extract_figures: Union[None, Unset, bool] = UNSET,
) -> Optional[UploadResponse]:
    """
    Args:
        ocr (Union[None, Unset, str]):
        describe_figures (Union[None, Unset, bool]):
        extract_figures (Union[None, Unset, bool]):
        body (AnalyzeDocumentBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UploadResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            ocr=ocr,
            describe_figures=describe_figures,
            extract_figures=extract_figures,
        )
    ).parsed
