# Hong Kong Mahjong Rules

## Overview

Hong Kong mahjong is played with 4 players using 144 tiles. The goal is to
form a complete hand of **4 melds + 1 pair** (14 tiles total).

## Tiles

- **Suited tiles** (108): Bamboo, Characters, Dots — ranks 1-9, 4 copies each
- **Winds** (16): East, South, West, North — 4 copies each
- **Dragons** (12): Red, Green, White — 4 copies each
- **Bonus** (8): 4 Flowers + 4 Seasons — 1 copy each

## Melds

- **Chow**: 3 consecutive tiles of the same suit (e.g., 3-4-5 Bamboo)
- **Pong**: 3 identical tiles
- **Kong**: 4 identical tiles (draws a replacement tile)

## Turn Flow

1. Draw a tile from the wall
2. Optionally declare a kong or win
3. Discard a tile
4. Other players may claim the discard

## Claims

When a tile is discarded, other players may claim it:

- **Win** (highest priority) — any player
- **Pong/Kong** — any player
- **Chow** — only the next player in turn order

## Winning

A winning hand consists of 4 melds + 1 pair with a minimum of **3 faan**.

Special hands:
- **Thirteen Orphans**: One of each terminal and honor tile + one duplicate

## Bonus Tiles

Flowers and Seasons are immediately set aside and replaced with a draw
from the dead wall. Matching bonus tiles (e.g., Flower 1 for East seat)
score additional faan.
