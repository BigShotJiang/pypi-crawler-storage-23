# Hong Kong Mahjong Scoring Table

Minimum **3 faan** required to win. Limit hand = **13 faan**.

## Regular Patterns

| Pattern | Faan | Description |
|---------|------|-------------|
| Dragon Pong | 1 | Pong/kong of any dragon |
| Seat Wind | 1 | Pong/kong of your seat wind |
| Prevailing Wind | 1 | Pong/kong of the round wind |
| Self Drawn | 1 | Win by drawing the tile yourself |
| No Flowers | 1 | No bonus tiles collected |
| Fully Concealed | 1 | No exposed melds |
| Matching Flower/Season | 1 | Bonus tile matching seat number |
| All Flowers | 2 | All 4 flower tiles |
| All Seasons | 2 | All 4 season tiles |
| All Pongs | 3 | All 4 melds are pongs/kongs |
| Mixed One Suit | 3 | One suit + honor tiles only |
| Small Dragons | 5 | 2 dragon pongs + dragon pair |
| Small Winds | 6 | 3 wind pongs + wind pair |
| Pure One Suit | 7 | Single suit, no honors |

## Situational Patterns

| Pattern | Faan | Description |
|---------|------|-------------|
| Win on Last Tile | 1 | Win with the last tile from wall |
| Win on Kong Replacement | 1 | Win on a kong replacement draw |
| Robbing the Kong | 1 | Win by taking a tile added to a kong |
| All Terminals and Honors | 1 | All tiles are terminals or honors |

## Limit Hands (13 faan)

| Pattern | Description |
|---------|-------------|
| Thirteen Orphans | One each of all terminals + honors + one duplicate |
| Great Dragons | Pong/kong of all 3 dragons |
| Great Winds | Pong/kong of all 4 winds |
| All Honors | All tiles are honor tiles |
| All Terminals | All tiles are terminal tiles (1s and 9s) |
| All Kongs | All 4 melds are kongs |
| Nine Gates | Concealed 1112345678999 + any tile of same suit |
