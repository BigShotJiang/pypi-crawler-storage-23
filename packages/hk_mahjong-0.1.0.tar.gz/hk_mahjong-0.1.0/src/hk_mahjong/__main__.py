"""Allow running as python -m hk_mahjong."""

from hk_mahjong.main import main

main()
