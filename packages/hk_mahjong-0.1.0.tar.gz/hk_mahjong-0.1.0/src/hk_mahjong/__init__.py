"""Hong Kong style mahjong in the terminal."""

__version__ = "0.1.0"
