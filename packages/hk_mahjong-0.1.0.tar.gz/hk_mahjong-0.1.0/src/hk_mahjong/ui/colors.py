"""Color themes for the mahjong UI."""

from __future__ import annotations

# Rich markup color styles
BAMBOO = "green"
CHARACTERS = "red"
DOTS = "blue"
WIND = "yellow"
DRAGON_RED = "bold red"
DRAGON_GREEN = "bold green"
DRAGON_WHITE = "bold white"
BONUS = "magenta"
SELECTED = "bold reverse"
HEADER = "bold cyan"
DISCARD_AREA = "dim"
ACTION_BAR = "bold yellow"
PLAYER_ACTIVE = "bold green"
PLAYER_INACTIVE = "dim white"
TILE_BACK = "dim white on grey23"
