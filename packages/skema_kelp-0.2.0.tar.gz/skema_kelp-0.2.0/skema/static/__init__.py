"""Static bathymetry and substrate files for skema."""

