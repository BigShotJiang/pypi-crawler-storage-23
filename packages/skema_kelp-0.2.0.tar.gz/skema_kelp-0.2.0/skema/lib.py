import rasterio

import numpy as np 
import glob
import torch


from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn, TimeRemainingColumn

from sklearn.model_selection import train_test_split

import os
import albumentations as A


from torch.utils.data import Dataset as BaseDataset
from torch.optim import lr_scheduler
import segmentation_models_pytorch as smp
import pytorch_lightning as pl


# to save the results
import urllib.request


# preprocessing
import xml.etree.ElementTree as ET
from importlib.resources import files

from rasterio.warp import reproject, Resampling
from rasterio.transform import from_bounds
from rich.console import Console


from rasterio.enums import Resampling

# print(torch.__version__)
# print(torch.version.cuda)  # Should print the version of CUDA PyTorch is using
# print("cuDNN version:", torch.backends.cudnn.version())
# DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Set the device to GPU if available, otherwise use CPU
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
# print(DEVICE)














def extract_bands_to_geotiffs(safe_dir, output_dir):
    """
    Extracts and stacks Sentinel-2 bands from .SAFE format into multi-band GeoTIFF files, 
    applying baseline-dependent offset correction (10m and 20m resolution bands separately).
    """
    
    console = Console()
    product_id = os.path.basename(safe_dir).replace(".SAFE", "")

    bands_10m = ['B02', 'B03', 'B04', 'B08']
    bands_20m = ['B05', 'B06', 'B07', 'B8A', 'B11', 'B12']

    def find_band_files(bands, root_dir):
        band_files = {}
        for root, dirs, files_ in os.walk(root_dir):
            for file in files_:
                if file.endswith(".jp2"):
                    for band in bands:
                        if band in file and band not in band_files:
                            band_files[band] = os.path.join(root, file)
        for band in bands:
            if band not in band_files:
                console.print(f"[yellow]Warning: {band}.jp2 not found in {safe_dir}[/yellow]")
        return [band_files.get(b) for b in bands]

    with console.status("[cyan]Locating Sentinel-2 band files..."):
        band_paths_10m = find_band_files(bands_10m, safe_dir)
        band_paths_20m = find_band_files(bands_20m, safe_dir)

    if None in band_paths_10m:
        console.print(f"[red]Missing some 10m bands in {safe_dir}, skipping...[/red]")
        return None, None

    def get_processing_baseline(safe_dir):
        xml_path = None
        for root, dirs, files_ in os.walk(safe_dir):
            for f in files_:
                if f.startswith("MTD_MSI") and f.endswith(".xml"):
                    xml_path = os.path.join(root, f)
                    break
            if xml_path:
                break
        if not xml_path:
            console.print(f"[yellow]No MTD_MSIL2A.xml found in {safe_dir}[/yellow]")
            return None
        tree = ET.parse(xml_path)
        root = tree.getroot()
        pb = root.findtext(".//PROCESSING_BASELINE")
        return float(pb) if pb else None

    pb = get_processing_baseline(safe_dir)
    shift = 1000 if pb and pb >= 4.0 else 0

    def write_multiband_geotiff(output_path, band_paths, description):
        with rasterio.open(band_paths[0]) as src:
            meta = src.meta.copy()
            meta.update({"count": len(band_paths), "dtype": "uint16", "driver": "GTiff"})
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
        ) as progress:
            task = progress.add_task(f"[cyan]{description}", total=len(band_paths))
            
            with rasterio.open(output_path, "w", **meta) as dst:
                for i, bp in enumerate(band_paths):
                    with rasterio.open(bp) as bsrc:
                        arr = bsrc.read(1).astype(np.int32) - shift
                        arr = np.clip(arr, 0, None).astype(np.uint16)
                        dst.write(arr, i + 1)
                    progress.advance(task)

    output_10m = os.path.join(output_dir, f"{product_id}_B2B3B4B8.tif")
    write_multiband_geotiff(output_10m, band_paths_10m, "Extracting and stacking 10m bands...")

    output_20m = None
    if None not in band_paths_20m:
        output_20m = os.path.join(output_dir, f"{product_id}_B5B6B7B8A_B11B12.tif")
        write_multiband_geotiff(output_20m, band_paths_20m, "Extracting and stacking 20m bands...")

    console.print(f"[green]✓[/green] Sentinel-2 band extraction complete.")

    return output_10m, output_20m


def warp_bathy_and_subs(safe_folder_root, basename):
    """
    Aligns bathymetry and substrate rasters to match the CRS, resolution (10m), and extent 
    of the reference Sentinel-2 image using bilinear resampling.
    """
    console = Console()
    
    # Look for _B2B3B4B8.tif inside each subfolder
    for folder_name in os.listdir(safe_folder_root):
        folder_path = os.path.join(safe_folder_root, folder_name)
        if not os.path.isdir(folder_path):
            continue

        tif_file = next((f for f in os.listdir(folder_path) if f == f"{basename}_B2B3B4B8.tif"), None)
        if not tif_file:
            # console.print(f"[yellow]No reference image found in {folder_path}, skipping...[/yellow]")
            continue

        reference_tif = os.path.join(folder_path, tif_file)

        # Define static files to warp and their suffixes
        input_files = {
            "Bathymetry_10m.tif": "_Bathy.tif",
            "NCC_substrate_20m.tif": "_SubsNCC.tif",
            "SOG_substrate_20m.tif": "_SubsSOG.tif",
            "WCVI_substrate_20m.tif": "_SubsWCVI.tif",
            "QCS_substrate_20m.tif": "_SubsQCS.tif",
            "HG_substrate_20m.tif": "_SubsHG.tif",
        }

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(),
        ) as progress:
            task = progress.add_task(f"[cyan]Aligning bathymetry and substrate files with Sentinel-2 image...", total=len(input_files))
            
            # Load bathy/substrate files from static directory
            for file_name, suffix in input_files.items():
                try:
                    static_path = files("skema.static.bathy_substrate").joinpath(file_name)
                    input_file_path = str(static_path)
                except Exception as e:
                    console.print(f"[red]Failed to access static file {file_name}: {e}[/red]")
                    progress.advance(task)
                    continue

                output_file_path = os.path.join(folder_path, folder_name + suffix)

                with rasterio.open(reference_tif) as ref:
                    bounds = ref.bounds
                    crs = ref.crs.to_string()

                width = int((bounds.right - bounds.left) / 10)
                height = int((bounds.top - bounds.bottom) / 10)
                transform = from_bounds(bounds.left, bounds.bottom, bounds.right, bounds.top, width, height)

                with rasterio.open(input_file_path) as src:
                    out_data = np.empty((height, width), dtype=src.dtypes[0])
                    
                    reproject(
                        source=rasterio.band(src, 1),
                        destination=out_data,
                        src_transform=src.transform,
                        src_crs=src.crs,
                        dst_transform=transform,
                        dst_crs=crs,
                        resampling=Resampling.bilinear
                    )
                    
                    profile = src.profile.copy()
                    profile.update({
                        'crs': crs,
                        'transform': transform,
                        'width': width,
                        'height': height
                    })
                    
                    with rasterio.open(output_file_path, 'w', **profile) as dst:
                        dst.write(out_data, 1)

                progress.advance(task)
        
        console.print(f"[green]✓[/green] Alignment complete.")


def fill_nodata_fixed_value(input_file, output_file, fill_value):
    """
    Replaces NoData values in a raster with a specified fill value and removes the NoData flag.
    """

    with rasterio.open(input_file) as src:
        data = src.read(1)
        nodata_value = src.nodata
        profile = src.profile.copy()
        
        if nodata_value is not None:
            data[data == nodata_value] = fill_value
        
        profile.update(nodata=None)
        
        with rasterio.open(output_file, 'w', **profile) as dst:
            dst.write(data, 1)

    # print(f"Processed and saved: {output_file}")
    os.remove(input_file)



def merge_substrate_files_single(safe_output_dir):
    """Merge substrate rasters in a single SAFE output folder into _Subs.tif."""
    """
    Merges five regional substrate rasters into a single substrate file, prioritizing valid 
    substrate values (1-4) and removing original files after merge.
    """
    
    console = Console()
    suffixes = ["_SubsNCC.tif", "_SubsSOG.tif", "_SubsWCVI.tif", "_SubsQCS.tif", "_SubsHG.tif"]
    valid_values = {1, 2, 3, 4}

    # Collect input rasters
    input_files = [os.path.join(safe_output_dir, f) for f in os.listdir(safe_output_dir) if any(f.endswith(s) for s in suffixes)]
    if len(input_files) != 5:
        console.print(f"[yellow]Not all substrate files found in {safe_output_dir}, skipping merge.[/yellow]")
        return None

    b2348_file = next((f for f in os.listdir(safe_output_dir) if f.endswith("_B2B3B4B8.tif")), None)
    if not b2348_file:
        # console.print(f"[yellow]No reference image in {safe_output_dir}, skipping merge.[/yellow]")
        return None

    base_name = b2348_file.replace("_B2B3B4B8.tif", "")
    output_file = os.path.join(safe_output_dir, f"{base_name}_Subs.tif")

    with rasterio.open(input_files[0]) as src:
        meta = src.meta.copy()
        height, width = src.shape

    merged_data = np.zeros((height, width), dtype=meta["dtype"])
    for file in input_files:
        with rasterio.open(file) as src:
            data = src.read(1)
            mask = np.isin(data, list(valid_values))
            merged_data[mask] = data[mask]

    meta.update(dtype=rasterio.uint8, nodata=0, compress="LZW")
    with rasterio.open(output_file, "w", **meta) as dst:
        dst.write(merged_data, 1)

    # delete originals
    for file in input_files:
        try:
            os.remove(file)
        except Exception as e:
            console.print(f"[red]Error deleting {file}: {e}[/red]")

    return output_file


def apply_fill_nodata_single(safe_output_dir, fill_value_subs=0, fill_value_bathy=-2000):
    """
    Applies NoData filling to substrate (default: 0) and bathymetry (default: -2000) rasters 
    and renames them to final output files.
    """
    subs_file = next((f for f in os.listdir(safe_output_dir) if f.endswith("_Subs.tif")), None)
    bathy_file = next((f for f in os.listdir(safe_output_dir) if f.endswith("_Bathy.tif")), None)

    if subs_file:
        base_name = subs_file.replace("_Subs.tif", "")
        output_file = os.path.join(safe_output_dir, f"{base_name}_Substrate.tif")
        fill_nodata_fixed_value(os.path.join(safe_output_dir, subs_file), output_file, fill_value_subs)
        subs_file = output_file

    if bathy_file:
        base_name = bathy_file.replace("_Bathy.tif", "")
        output_file = os.path.join(safe_output_dir, f"{base_name}_Bathymetry.tif")
        fill_nodata_fixed_value(os.path.join(safe_output_dir, bathy_file), output_file, fill_value_bathy)
        bathy_file = output_file

    return subs_file, bathy_file




def normalize_input_mean_std(image_hwc, mean_per_channel, std_per_channel, epsilon=1e-8):
    """Applies mean and std normalization to the input image (H, W, C) at once."""
    image_hwc = np.nan_to_num(image_hwc).astype(np.float32)  # Handle NaNs and ensure float type
    mean = np.array(mean_per_channel, dtype=np.float32)[np.newaxis, np.newaxis, :]
    std = np.array(std_per_channel, dtype=np.float32)[np.newaxis, np.newaxis, :]
    normalized_image = (image_hwc - mean) / (std + epsilon)
    return normalized_image

class SatelliteDataset(BaseDataset):
    CLASSES = ["water", "kelp", "land"]

    def __init__(self, image_paths, mask_paths, classes=None, augmentation=None, mean=None, std=None):
        self.image_paths = image_paths
        self.mask_paths = mask_paths
        self.augmentation = augmentation
        self.mean = mean
        self.std = std
        self.calculated_mean = None
        self.calculated_std = None

        if classes is None:
            classes = self.CLASSES
        self.class_values = [self.CLASSES.index(cls.lower()) for cls in classes]

        self.index_calculators = {
            "ndvi": self.calculate_ndvi,
            "ndwi": self.calculate_ndwi,
            "gndvi": self.calculate_gndvi,
            "clgreen": self.calculate_chlorophyll_index_green,
            "ndvire": self.calculate_ndvi_re, #Normalized Difference of Red and Blue
            #"ndrb": self.calculate_ndrb, #Normalized Difference of Red and Blue
            #"mgvi": self.calculate_mgvi, #Modified Green Red Vegetation Index (MGVI)
            #"mpri": self.calculate_mpri, #Modified Photochemical Reflectance Index (MPRI)
            #"rgbvi": self.calculate_rgbvi, #Red Green Blue Vegetation Index (RGBVI)
            #"gli": self.calculate_gli, #Green Leaf Index (GLI)
            #"gi": self.calculate_gi, #Greenness Index (GI)
            #"br": self.calculate_blue_red, #Blue/Red
            #"exg": self.calculate_exg, #Excess of Green (ExG)
            #"vari": self.calculate_vari, #Visible Atmospherically Resistant Index (VARI)
            #"tvi": self.calculate_tvi, #Triangular Vegetation Index (TVI)
            #"rdvi": self.calculate_rdvi, #Renormalized Difference Vegetation Index (RDVI)
            #"ndreb": self.calculate_ndreb, #Normalized Difference Red-edge Blue (NDREB)
            #"evi": self.calculate_evi, #Enhanced Vegetation Index (EVI)
            #"cig": self.calculate_cig,  #Green Chlorophyll Index (CIG)
            #"blue_rededge": self.calculate_blue_rededge, #Blue/Red-edge
            #"bnir": self.calculate_blue_nir, #Blue/NIR
            #"rb": self.calculate_red_minus_blue, #R-B
            #"bndvi": self.calculate_bndvi, #Blue NDVI
        }

    def __len__(self):
        return len(self.image_paths)

    def __getitem__(self, index):
        # --- 1. Read Image ---
        img_path = self.image_paths[index]
        with rasterio.open(img_path) as src_img:
            image = src_img.read([1, 2, 3, 4, 5, 11, 12]) # -> (C, H, W) = (6, H, W) 1-4:10m bands, 5-10: 20m bands resampled to 10m, 11:substrate 12: bathymetry

            # --- FIXED PREPROCESSING ---
            # # Modify bathymetry (channel index 5 in CHW format)
            # bathy_mask_gt = image[6, :, :] > 10
            # bathy_mask_lt = image[6, :, :] < -100
            # image[6, :, :][bathy_mask_gt | bathy_mask_lt] = -2000 # Combine conditions

            # # Modify substrate (channel index 4 in CHW format)
            # subs_mask = image[5, :, :] != 1
            # image[5, :, :][subs_mask] = 0
            # # --- END FIX ---

            image_hwc = np.transpose(image, (1, 2, 0)).astype(np.float32) # -> (H, W, 6)

        # --- 2. Calculate Indices ---
        indices_list = []
        for _, calculator in self.index_calculators.items():
            idx = calculator(image_hwc)
            indices_list.append(idx[..., np.newaxis])

        image_with_indices = np.concatenate([image_hwc] + indices_list, axis=-1)

        # --- 3. Read Mask ---
        mask_path = self.mask_paths[index]
        mask = self.read_and_process_mask(mask_path) # -> (H, W, num_classes)

        # --- 4. Apply Normalization ---
        if self.mean is not None and self.std is not None:
            image_with_indices = normalize_input_mean_std(image_with_indices, mean_per_channel=self.mean, std_per_channel=self.std)

        # --- 5. Apply Augmentation ---
        if self.augmentation:  # Proceeds to call whatever is stored in self.augmentation
            # Python expects self.augmentation to be a callable object (something that can be called using parentheses ()), which a function is. 
            # The image and mask variables are passed as arguments to this callable. In the case of albumentation, self.augmentation holds the
            # A.Compose object. When you call it with (image=image_with_indices, mask=mask), the A.Compose object's __call__ method  (which is what makes an
            # object callable) is executed. This method internally applies the defined horizontal and vertical flips (with their respective probabilities)
            # to the provided image and mask and returns a dictionary like {'image': augmented_image, 'mask': augmented_mask}.
            sample = self.augmentation(image=image_with_indices, mask=mask) 
            image_with_indices = sample['image']
            mask = sample['mask']

        # --- 6. Final Transpose ---
        image_final = np.transpose(image_with_indices, (2, 0, 1))
        mask_final = np.transpose(mask, (2, 0, 1))

        return image_final.astype(np.float32), mask_final.astype(np.float32)


    def read_and_process_mask(self, mask_path):
        with rasterio.open(mask_path) as src_mask:
            mask = src_mask.read(1).astype(int) # -> (H, W)
            masks = [(mask == v) for v in self.class_values]
            return np.stack(masks, axis=-1).astype("float") #-> (H, W, num_classes)

    # --- Index Calculation Methods ---
    def calculate_ndvi(self, image_hwc):
        nir = image_hwc[..., 3]
        red = image_hwc[..., 2]
        return (nir - red) / (nir + red + 1e-10)

    def calculate_ndwi(self, image_hwc):
        green = image_hwc[..., 1]
        nir = image_hwc[..., 3]
        return (green - nir) / (green + nir + 1e-10)

    def calculate_gndvi(self, image_hwc):
        nir = image_hwc[..., 3]
        green = image_hwc[..., 1]
        return (nir - green) / (nir + green + 1e-10)

    def calculate_chlorophyll_index_green(self, image_hwc):
        nir = image_hwc[..., 3]
        green = image_hwc[..., 1]
        return (nir / (green + 1e-10)) - 1

    def calculate_ndvi_re(self, image_hwc):
        re = image_hwc[..., 4]
        red = image_hwc[..., 2]
        return (re - red) / (re + red + 1e-10)

    def calculate_evi(self, image_hwc):
        nir = image_hwc[..., 3]
        red = image_hwc[..., 2]
        blue = image_hwc[..., 0]
        return 2.5 * (nir - red) / (nir + 6 * red - 7.5 * blue + 1 + 1e-10)

    def calculate_sr(self, image_hwc):
        nir = image_hwc[..., 3]
        red = image_hwc[..., 2]
        return nir / (red + 1e-10)

    def calculate_ndrb(self, image_hwc):
        return (image_hwc[..., 2] - image_hwc[..., 0]) / (image_hwc[..., 2] + image_hwc[..., 0] + 1e-10)

    def calculate_mgvi(self, image_hwc):
        return (image_hwc[..., 1]**2 - image_hwc[..., 2]**2) / (image_hwc[..., 1]**2 + image_hwc[..., 2]**2 + 1e-10)

    def calculate_mpri(self, image_hwc):
        return (image_hwc[..., 1] - image_hwc[..., 2]) / (image_hwc[..., 1] + image_hwc[..., 2] + 1e-10)

    def calculate_rgbvi(self, image_hwc):
        return (image_hwc[..., 1] - image_hwc[..., 0] * image_hwc[..., 2]) / (image_hwc[..., 1]**2 + image_hwc[..., 0] * image_hwc[..., 2] + 1e-10)

    def calculate_gli(self, image_hwc):
        return (2 * image_hwc[..., 1] - image_hwc[..., 2] - image_hwc[..., 0]) / (2 * image_hwc[..., 1] + image_hwc[..., 2] + image_hwc[..., 0] + 1e-10)

    def calculate_gi(self, image_hwc):
        return image_hwc[..., 1] / (image_hwc[..., 2] + 1e-10)

    def calculate_blue_red(self, image_hwc):
        return image_hwc[..., 0] / (image_hwc[..., 2] + 1e-10)

    def calculate_red_minus_blue(self, image_hwc):
        return image_hwc[..., 2] - image_hwc[..., 0]

    def calculate_exg(self, image_hwc):
        return 2 * image_hwc[..., 1] - image_hwc[..., 2] - image_hwc[..., 0]

    def calculate_vari(self, image_hwc):
        return (image_hwc[..., 1] - image_hwc[..., 2]) / (image_hwc[..., 1] + image_hwc[..., 2] - image_hwc[..., 0] + 1e-10)

    def calculate_tvi(self, image_hwc):
        return (120 * (image_hwc[..., 4] - image_hwc[..., 1]) - 200 * (image_hwc[..., 2] - image_hwc[..., 1])) / 2

    def calculate_rdvi(self, image_hwc):
        return (image_hwc[..., 3] - image_hwc[..., 2]) / np.sqrt(image_hwc[..., 3] + image_hwc[..., 2] + 1e-10)

    def calculate_ndreb(self, image_hwc):
        return (image_hwc[..., 4] - image_hwc[..., 0]) / (image_hwc[..., 4] + image_hwc[..., 0] + 1e-10)

    def calculate_cig(self, image_hwc):
        return (image_hwc[..., 3] / (image_hwc[..., 1] + 1e-10)) - 1

    def calculate_blue_rededge(self, image_hwc):
        return image_hwc[..., 0] / (image_hwc[..., 4] + 1e-10)

    def calculate_blue_nir(self, image_hwc):
        return image_hwc[..., 0] / (image_hwc[..., 3] + 1e-10)

    def calculate_bndvi(self, image_hwc):
        nir = image_hwc[..., 3]
        blue = image_hwc[..., 0]
        return (nir - blue) / (nir + blue + 1e-10)




OUT_CLASSES = 1

class segModel(pl.LightningModule):
    def __init__(self, arch, encoder_name, in_channels, out_classes, **kwargs):
        super().__init__()
        self.model = smp.create_model(
            arch,
            encoder_name=encoder_name,
            in_channels=in_channels,
            classes=out_classes,
            encoder_weights=None,
            **kwargs,
        )
        # preprocessing parameteres for image (Cuurently no normalization, so the next few lines do not do anything--Normalizing data is most beneficial when input features have a high variance or differ significantly from what the model was trained on, which could lead to poor learning and performance.)
        params = smp.encoders.get_preprocessing_params(encoder_name)
        self.register_buffer("std", torch.tensor(params["std"]).view(1, 3, 1, 1))
        self.register_buffer("mean", torch.tensor(params["mean"]).view(1, 3, 1, 1))

        # for image segmentation dice loss could be the best first choice
        self.loss_fn = smp.losses.DiceLoss(smp.losses.BINARY_MODE, from_logits=True)

        # initialize step metics
        self.training_step_outputs = []
        self.validation_step_outputs = []
        self.test_step_outputs = []

    def forward(self, image):
        # normalize image here
        # image = (image - self.mean) / self.std //no normalization
        mask = self.model(image)
        return mask

    # How shared_step and shared_epoch_end Work Together
    # shared_step is called for each batch and returns the loss and segmentation statistics (tp, fp, fn, tn).
    # The results from multiple shared_step calls are collected into a list (e.g., self.training_step_outputs).
    # At the end of an epoch, shared_epoch_end aggregates all statistics and computes IoU metrics.
    def shared_step(self, batch, stage):
        image, mask = batch

        # Shape of the image should be (batch_size, num_channels, height, width)
        # if you work with grayscale images, expand channels dim to have [batch_size, 1, height, width]
        assert image.ndim == 4

        # Check that image dimensions are divisible by 32,
        # encoder and decoder connected by `skip connections` and usually encoder have 5 stages of
        # downsampling by factor 2 (2 ^ 5 = 32); e.g. if we have image with shape 65x65 we will have
        # following shapes of features in encoder and decoder: 84, 42, 21, 10, 5 -> 5, 10, 20, 40, 80
        # and we will get an error trying to concat these features
        h, w = image.shape[2:]
        assert h % 32 == 0 and w % 32 == 0

        assert mask.ndim == 4

        # Check that mask values in between 0 and 1, NOT 0 and 255 for binary segmentation
        assert mask.max() <= 1.0 and mask.min() >= 0

        logits_mask = self.forward(image)

        # Predicted mask contains logits, and loss_fn param `from_logits` is set to True
        loss = self.loss_fn(logits_mask, mask)

        # Lets compute metrics for some threshold
        # first convert mask values to probabilities, then
        # apply thresholding
        prob_mask = logits_mask.sigmoid()
        pred_mask = (prob_mask > 0.5).float()

        # We will compute IoU metric by two ways
        #   1. dataset-wise
        #   2. image-wise
        # but for now we just compute true positive, false positive, false negative and
        # true negative 'pixels' for each image and class
        # these values will be aggregated in the end of an epoch
        tp, fp, fn, tn = smp.metrics.get_stats(
            pred_mask.long(), mask.long(), mode="binary"
        )
        return {
            "loss": loss,
            "tp": tp,
            "fp": fp,
            "fn": fn,
            "tn": tn,
        }

    # def shared_epoch_end(self, outputs, stage):
    #     # aggregate step metics
    #     tp = torch.cat([x["tp"] for x in outputs])
    #     fp = torch.cat([x["fp"] for x in outputs])
    #     fn = torch.cat([x["fn"] for x in outputs])
    #     tn = torch.cat([x["tn"] for x in outputs])

    #     # per image IoU means that we first calculate IoU score for each image
    #     # and then compute mean over these scores
    #     per_image_iou = smp.metrics.iou_score(
    #         tp, fp, fn, tn, reduction="micro-imagewise"
    #     )

    #     # dataset IoU means that we aggregate intersection and union over whole dataset
    #     # and then compute IoU score. The difference between dataset_iou and per_image_iou scores
    #     # in this particular case will not be much, however for dataset
    #     # with "empty" images (images without target class) a large gap could be observed.
    #     # Empty images influence a lot on per_image_iou and much less on dataset_iou. 
    #     # When we say that empty images influence per_image_iou a lot, it means they tend to increase it. 
    #     # This is because empty images typically have high IoU, and when computing per_image_iou (i.e., averaging IoU across all images),
    #     # empty images dominate the average because they tend to have high IoU values.
    #     dataset_iou = smp.metrics.iou_score(tp, fp, fn, tn, reduction="micro")
    #     metrics = {
    #         f"{stage}_per_image_iou": per_image_iou,
    #         f"{stage}_dataset_iou": dataset_iou,
    #     }

    #     self.log_dict(metrics, prog_bar=True)

    # Mohsen Ghanbari Feb 2025 - Revised this fucntion to output other metrics as well
    def shared_epoch_end(self, outputs, stage):
        # Aggregate step metrics
        tp = torch.cat([x["tp"] for x in outputs])
        fp = torch.cat([x["fp"] for x in outputs])
        fn = torch.cat([x["fn"] for x in outputs])
        tn = torch.cat([x["tn"] for x in outputs])
    
        # Compute IoU:
        # per image IoU means that we first calculate IoU score for each image
        # and then compute mean over these scores
        # dataset IoU means that we aggregate intersection and union over whole dataset
        # and then compute IoU score. The difference between dataset_iou and per_image_iou scores
        # in this particular case will not be much, however for dataset
        # with "empty" images (images without target class) a large gap could be observed.
        # Empty images influence a lot on per_image_iou and much less on dataset_iou. 
        # When we say that empty images influence per_image_iou a lot, it means they tend to increase it. 
        # This is because empty images typically have high IoU, and when computing per_image_iou (i.e., averaging IoU across all images),
        # empty images dominate the average because they tend to have high IoU values.
        per_image_iou = smp.metrics.iou_score(tp, fp, fn, tn, reduction="micro-imagewise")
        dataset_iou = smp.metrics.iou_score(tp, fp, fn, tn, reduction="micro")
    
        # Compute additional metrics
        precision = smp.metrics.precision(tp, fp, fn, tn, reduction="micro")
        recall = smp.metrics.recall(tp, fp, fn, tn, reduction="micro")
        f1_score = smp.metrics.f1_score(tp, fp, fn, tn, reduction="micro")
    
        # Log metrics
        metrics = {
            f"{stage}_per_image_iou": per_image_iou,
            f"{stage}_dataset_iou": dataset_iou,
            f"{stage}_precision": precision,
            f"{stage}_recall": recall,
            f"{stage}_f1_score": f1_score,
            # f"{stage}_tp": tp.sum().item(),
            # f"{stage}_fp": fp.sum().item(),
            # f"{stage}_fn": fn.sum().item(),
            # f"{stage}_tn": tn.sum().item(),
        }
    
        self.log_dict(metrics, prog_bar=True)

    def training_step(self, batch, batch_idx):
        train_loss_info = self.shared_step(batch, "train")
        # append the metics of each step to the
        self.training_step_outputs.append(train_loss_info)
        return train_loss_info

    def on_train_epoch_end(self):
        self.shared_epoch_end(self.training_step_outputs, "train")
        # empty set output list
        self.training_step_outputs.clear()
        return

    def validation_step(self, batch, batch_idx):
        valid_loss_info = self.shared_step(batch, "valid")
        self.validation_step_outputs.append(valid_loss_info)
        return valid_loss_info

    def on_validation_epoch_end(self):
        self.shared_epoch_end(self.validation_step_outputs, "valid")
        self.validation_step_outputs.clear()
        return

    def test_step(self, batch, batch_idx):
        test_loss_info = self.shared_step(batch, "test")
        self.test_step_outputs.append(test_loss_info)
        return test_loss_info

    def on_test_epoch_end(self):
        self.shared_epoch_end(self.test_step_outputs, "test")
        # empty set output list
        self.test_step_outputs.clear()
        return

    def configure_optimizers(self):
        optimizer = torch.optim.Adam(self.parameters(), lr=2e-4)
        scheduler = lr_scheduler.CosineAnnealingLR(optimizer, T_max=T_MAX, eta_min=1e-5)
        return {
            "optimizer": optimizer,
            "lr_scheduler": {
                "scheduler": scheduler,
                "interval": "step",
                "frequency": 1,
            },
        }
        return


def load_model(model_type='model_full'):
    """Load the appropriate model based on model_type."""
    if model_type == 'model_full':
        in_channels = 12
        MODEL_URL = "https://github.com/m5ghanba/skema/releases/download/v0.2.0/model.pth"
        
        model_filename = "model.pth"
    elif model_type == 'model_s2bandsandindices_only':
        in_channels = 10
        MODEL_URL = "https://github.com/m5ghanba/skema/releases/download/v0.2.0/modelS2Only.pth"
        model_filename = "modelS2Only.pth"
    else:
        raise ValueError(f"Invalid model_type '{model_type}'")
    
    # Create model
    model = segModel("Unet", "tu-maxvit_tiny_tf_512", in_channels=in_channels, out_classes=OUT_CLASSES)
    
    # Download model if needed
    LOCAL_PATH = os.path.join(os.path.expanduser("~"), ".skema", model_filename)
    os.makedirs(os.path.dirname(LOCAL_PATH), exist_ok=True)
    
    if not os.path.exists(LOCAL_PATH):
        print(f"Downloading model from {MODEL_URL}...")
        urllib.request.urlretrieve(MODEL_URL, LOCAL_PATH)
        print("Download complete.")
    
    # Load weights
    model.load_state_dict(torch.load(LOCAL_PATH, map_location="cpu"))
    
    return model




# # Set model to evaluation mode
# model.eval()


# supports having both 10m and 20m bands as well as substrate and bathymetry channels.
# also normalization is added here. Set mean and std to None if it was off during training. Otherwise, it is assumed mean_per_channel and 
# std_per_channel are provided. 




def normalize_tile_mean_std(tile, mean_per_channel, std_per_channel):
    """Applies mean and std normalization to each channel of the input tile (H, W, C) using vectorization."""
    tile = np.nan_to_num(tile).astype(np.float32)  # Handle NaNs and ensure float type
    mean = np.array(mean_per_channel, dtype=np.float32)
    std = np.array(std_per_channel, dtype=np.float32)
    # Reshape mean and std to match tile's shape for broadcasting
    mean = mean[np.newaxis, np.newaxis, :]
    std = std[np.newaxis, np.newaxis, :]
    normalized_tile = (tile - mean) / (std + 1e-8)
    return normalized_tile

def create_weight_map(tile_size, halo_size):
    """Create a weight map that gives less weight to edge pixels and more to center."""
    weight_map = np.ones((tile_size, tile_size), dtype=np.float32)
    
    # Create a linear fade from edge to center
    for i in range(halo_size):
        fade_weight = (i + 1) / halo_size
        # Top and bottom edges
        weight_map[i, :] = fade_weight
        weight_map[tile_size-1-i, :] = fade_weight
        # Left and right edges
        weight_map[:, i] = np.minimum(weight_map[:, i], fade_weight)
        weight_map[:, tile_size-1-i] = np.minimum(weight_map[:, tile_size-1-i], fade_weight)
    
    return weight_map
#  July 2025 - Same as above but with these modifications: 
# 1.padding (zero-padding was failing in the edge tiles, so using mirror padding)
# 2.Handling the overlap differently now using a weighted average method: we give 
# weight 1 topredictions from a square sized halo_size by halo_size in the centre 
# of each tile and the rest of the tile get weight values faded from  1 to 0 going
# from the edge of the square in the centre to the edge of the tile. Specifically, 
# (a) Accumulation Process:Each tile adds its weighted prediction to the accumulator:
# predictions += tile_pred * tile_weights. Then, each tile adds its weights to the 
# weight accumulator: weight_accumulator += tile_weights 
# (b) Final Normalization: At the end, we divide by total weights: 
# predictions = predictions / weight_accumulator (Converts probabilities > 0.5 to 1
# probabilities ≤ 0.5 to 0)
# This gives us the weighted average of all predictions that contributed to each pixel
class DatasetInference(SatelliteDataset):
    def __init__(self, main_directory, model, dataset, model_type='model_full', tile_size=512, 
                 overlap=0.7, mean_per_channel=None, std_per_channel=None, halo_size=64, padding_mode='reflect'):
        
        # Validate model_type
        if model_type not in ['model_full', 'model_s2bandsandindices_only']:
            raise ValueError(f"Invalid model_type '{model_type}'. Must be 'model_full' or 'model_s2bandsandindices_only'.")
        
        self.main_directory = main_directory
        self.tile_size = tile_size
        self.overlap = overlap
        self.model = model.to(DEVICE)
        self.model_type = model_type
        self.mean_per_channel = mean_per_channel
        self.std_per_channel = std_per_channel
        self.halo_size = halo_size
        self.padding_mode = padding_mode
        self.dataset = dataset
        
        self.weight_map = create_weight_map(tile_size, halo_size)
        
        # Get file paths based on model type
        if self.model_type == 'model_full':
            self.image_path1, self.image_path2, self.substrate_path, self.bathymetry_path = self.get_file_paths(main_directory)
        else:  # model_s2bandsandindices_only
            self.image_path1, self.image_path2 = self.get_file_paths(main_directory)
        
        # Load and process image
        self.image, self.metadata = self.load_image()

    def get_file_paths(self, main_directory):
        """Retrieve file paths based on model type."""
        if self.model_type == 'model_full':
            file_patterns = ["*_B2B3B4B8.tif", "*_B5B6B7B8A_B11B12.tif", "*_Substrate.tif", "*_Bathymetry.tif"]
        else:  # model_s2bandsandindices_only
            file_patterns = ["*_B2B3B4B8.tif", "*_B5B6B7B8A_B11B12.tif"]
        
        file_paths = []
        for pattern in file_patterns:
            matching_files = glob.glob(os.path.join(main_directory, pattern))
            if len(matching_files) != 1:
                raise ValueError(f"Expected one file for pattern {pattern}, found {len(matching_files)}.")
            file_paths.append(matching_files[0])
        
        return tuple(file_paths)

    def load_image(self):
        """Load all image bands and compute indices directly into self.image."""
        # Load 10m bands
        with rasterio.open(self.image_path1) as src1:
            image1 = src1.read([1, 2, 3, 4])
            image1 = np.transpose(image1, (1, 2, 0)).astype(np.float32)
            metadata = src1.meta
        
        # Load 20m band
        with rasterio.open(self.image_path2) as src2:
            image2 = src2.read(indexes=[1], out_shape=(
                1, image1.shape[0], image1.shape[1]
            ), resampling=Resampling.nearest)
            image2 = np.transpose(image2, (1, 2, 0)).astype(np.float32)
        
        if self.model_type == 'model_full':
            # Load substrate and bathymetry
            with rasterio.open(self.substrate_path) as src3:
                substrate = src3.read(1).astype(np.float32)[:, :, np.newaxis]
            
            with rasterio.open(self.bathymetry_path) as src4:
                bathymetry = src4.read(1).astype(np.float32)[:, :, np.newaxis]
            
            # Allocate image array with 12 channels (7 base + 5 indices)
            self.image = np.empty((image1.shape[0], image1.shape[1], 12), dtype=np.float32)
            self.image[:, :, 0:4] = image1
            self.image[:, :, 4] = image2[:, :, 0]
            self.image[:, :, 5] = substrate[:, :, 0]
            self.image[:, :, 6] = bathymetry[:, :, 0]
        else:  # model_s2bandsandindices_only
            # Allocate image array with 10 channels (5 base + 5 indices)
            self.image = np.empty((image1.shape[0], image1.shape[1], 10), dtype=np.float32)
            self.image[:, :, 0:4] = image1
            self.image[:, :, 4] = image2[:, :, 0]
        
        # Compute indices directly into self.image
        self._compute_slope_and_all_indices()
        
        return self.image, metadata

    def calculate_slope(self, bathymetry, cell_size=1.0):
        """
        Vectorized Horn slope calculation.
        Produces the same values as the loop-based version.
        """
        bathy = bathymetry.astype(np.float32)
    
        H, W = bathy.shape
        slope = np.zeros((H, W), dtype=np.float32)
    
        # Extract shifted views (a–i)
        a = bathy[:-2, :-2]
        b = bathy[:-2, 1:-1]
        c = bathy[:-2, 2:]
        d = bathy[1:-1, :-2]
        f = bathy[1:-1, 2:]
        g = bathy[2:, :-2]
        h = bathy[2:, 1:-1]
        i = bathy[2:, 2:]
    
        # Mask: any NaN in the 3x3 window → invalid
        invalid = (
            np.isnan(a) | np.isnan(b) | np.isnan(c) |
            np.isnan(d) | np.isnan(f) |
            np.isnan(g) | np.isnan(h) | np.isnan(i)
        )
    
        dz_dx = ((c + 2*f + i) - (a + 2*d + g)) / (8.0 * cell_size)
        dz_dy = ((g + 2*h + i) - (a + 2*b + c)) / (8.0 * cell_size)
    
        slope_inner = np.degrees(np.arctan(np.sqrt(dz_dx**2 + dz_dy**2)))
    
        # Apply NaN rule (same behavior as your loop)
        slope_inner[invalid] = 0.0
    
        # Write back to full array (edges remain 0)
        slope[1:-1, 1:-1] = slope_inner
    
        return slope

    def _compute_slope_and_all_indices(self):
        """Compute all spectral indices directly into self.image."""
        green = self.image[:, :, 1]
        red = self.image[:, :, 2]
        nir = self.image[:, :, 3]
        re = self.image[:, :, 4]

        eps = 1e-10
        
        if self.model_type == 'model_full':
            # Calculate slope
            bathy = self.image[:, :, 6]
            slope = self.calculate_slope(bathy)
            self.image[:, :, 7] = slope
            # Indices start at channel 8
            self.image[:, :, 8] = (nir - red) / (nir + red + eps)  # NDVI
            self.image[:, :, 9] = (green - nir) / (green + nir + eps)  # NDWI
            self.image[:, :, 10] = (nir - green) / (nir + green + eps)  # GNDVI
            self.image[:, :, 11] = (nir / (green + eps)) - 1  # Chlorophyll Index
            self.image[:, :, 12] = (re - red) / (re + red + eps)  # NDVI-RE
        else:  # model_s2bandsandindices_only
            # Indices start at channel 5
            self.image[:, :, 5] = (nir - red) / (nir + red + eps)  # NDVI
            self.image[:, :, 6] = (green - nir) / (green + nir + eps)  # NDWI
            self.image[:, :, 7] = (nir - green) / (nir + green + eps)  # GNDVI
            self.image[:, :, 8] = (nir / (green + eps)) - 1  # Chlorophyll Index
            self.image[:, :, 9] = (re - red) / (re + red + eps)  # NDVI-RE


    def generate_tiles(self, image):
        """Generator that yields one tile and its coordinates at a time."""
        h, w, c = image.shape
        tile_size = self.tile_size
        overlap = self.overlap
        step_size = int(tile_size * (1 - overlap))

        # Integer ceil division: (a + b - 1) // b  does the same as math.ceil(a / b)
        if h <= tile_size:
            tiles_y = 1
        else:
            tiles_y = ((h - tile_size) + step_size - 1) // step_size + 1

        if w <= tile_size:
            tiles_x = 1
        else:
            tiles_x = ((w - tile_size) + step_size - 1) // step_size + 1

        # Generate ALL tiles with consistent grid alignment
        for y in range(tiles_y):
            for x in range(tiles_x):
                i = y * step_size          # top-left row (can be >= h for the last tiles)
                j = x * step_size          # top-left col (can be >= w for the last tiles)

                i_end = min(i + tile_size, h)
                j_end = min(j + tile_size, w)

                tile = image[i:i_end, j:j_end]

                # Pad to full tile_size with zeros if we are on the border
                actual_h, actual_w = tile.shape[:2]
                if actual_h < tile_size or actual_w < tile_size:
                    pad_bottom = tile_size - actual_h
                    pad_right = tile_size - actual_w
                    tile = np.pad(tile,
                                ((0, pad_bottom), (0, pad_right), (0, 0)),
                                mode='constant',
                                constant_values=0)

                # Optional normalization
                if self.mean_per_channel is not None and self.std_per_channel is not None:
                    tile = normalize_tile_mean_std(tile, self.mean_per_channel, self.std_per_channel)

                yield tile, (i, j)


    def _process_batch_not_weighted(self, tiles, coords, predictions):
        """Not weighted - Run inference on a batch of tiles and write results into full image."""
        batch_tensor = torch.cat(tiles, dim=0).to(DEVICE)  # shape: (B, C, H, W)
        outputs = self.model(batch_tensor)  # shape: (B, 1, H, W) or (B, H, W)
    
        # Handle binary output (thresholding)
        if outputs.shape[1] == 1:
            outputs = (outputs.squeeze(1) > 0.5).cpu().numpy().astype(np.uint8)
        else:
            outputs = outputs.cpu().numpy().astype(np.uint8)
    
        # Write predictions into full image
        for pred, (i, j) in zip(outputs, coords):
            effective_tile_height = min(self.tile_size, predictions.shape[0] - i)
            effective_tile_width = min(self.tile_size, predictions.shape[1] - j)
    
            predictions[i:i + effective_tile_height, j:j + effective_tile_width] = np.maximum(
                predictions[i:i + effective_tile_height, j:j + effective_tile_width],
                pred[:effective_tile_height, :effective_tile_width]
            )

    def _process_batch(self, tiles, coords, predictions, weight_accumulator):
        """Process batch using weighted averaging with halo method."""
        batch_tensor = torch.cat(tiles, dim=0).to(DEVICE)
        outputs = self.model(batch_tensor)
    
        # Handle binary output (thresholding)
        if outputs.shape[1] == 1:
            outputs = outputs.squeeze(1).sigmoid().cpu().numpy()  # Keep as probabilities for averaging
        else:
            outputs = torch.softmax(outputs, dim=1).cpu().numpy()  # Multi-class probabilities
    
        # Process each prediction in the batch
        for pred, (i, j) in zip(outputs, coords):
            # Calculate the region bounds in the full image
            end_i = min(i + self.tile_size, predictions.shape[0])
            end_j = min(j + self.tile_size, predictions.shape[1])
            
            # Calculate effective tile size (in case of edge tiles)
            effective_h = end_i - i
            effective_w = end_j - j
            
            # Get the corresponding portion of the prediction and weight map
            tile_pred = pred[:effective_h, :effective_w]
            tile_weights = self.weight_map[:effective_h, :effective_w]
            
            # Weighted accumulation
            predictions[i:end_i, j:end_j] += tile_pred * tile_weights
            weight_accumulator[i:end_i, j:end_j] += tile_weights


    def run_model_on_tiles(self, batch_size=8):
        """
        Run the model on tiles with improved edge handling.
        
        Args:
            batch_size (int): Number of tiles to process in each batch
        """
        console = Console()
        self.model.eval()
        
        predictions = np.zeros_like(self.image[:, :, 0], dtype=np.float32)
        weight_accumulator = np.zeros_like(self.image[:, :, 0], dtype=np.float32)

        # First pass: count tiles
        tile_count = sum(1 for _ in self.generate_tiles(self.image))
        
        # Second pass: process tiles
        tile_generator = self.generate_tiles(self.image)
        batch_tiles = []
        batch_coords = []
        tiles_processed = 0

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(),
            TimeRemainingColumn(),
        ) as progress:
            task = progress.add_task("[cyan]Processing ...", total=tile_count)
            
            with torch.no_grad():
                for tile, (i, j) in tile_generator:
                    # Preprocess and add tile to batch
                    tile_tensor = torch.tensor(tile).permute(2, 0, 1).unsqueeze(0).float()
                    batch_tiles.append(tile_tensor)
                    batch_coords.append((i, j))

                    # Run batch when full
                    if len(batch_tiles) == batch_size:
                        self._process_batch(batch_tiles, batch_coords, predictions, weight_accumulator)
                        tiles_processed += len(batch_tiles)
                        progress.update(task, completed=tiles_processed)
                        batch_tiles.clear()
                        batch_coords.clear()

                # Handle remaining tiles
                if batch_tiles:
                    self._process_batch(batch_tiles, batch_coords, predictions, weight_accumulator)
                    tiles_processed += len(batch_tiles)
                    progress.update(task, completed=tiles_processed)

        # Finalize predictions
        weight_accumulator = np.where(weight_accumulator == 0, 1, weight_accumulator)
        predictions = predictions / weight_accumulator
            
        # Convert back to binary/class predictions
        if predictions.ndim == 2:  # Binary case
            predictions = (predictions > 0.5).astype(np.uint8)
        else:  # Multi-class case
            predictions = np.argmax(predictions, axis=-1).astype(np.uint8)

        # Apply filters for model_full
        if self.model_type == 'model_full':
            predictions[(self.image[:, :, 6] < -100) | (self.image[:, :, 6] > 20)] = 0
            predictions[(self.image[:, :, 5] == 4)] = 0

        console.print(f"[green]✓[/green] Processing complete.")

        return predictions


    def run_model_on_tiles_not_weighted(self, batch_size=8):
        """Run the model on tiles in batches with GPU acceleration and low RAM usage."""
        self.model.eval()
        predictions = np.zeros_like(self.image[:, :, 0], dtype=np.uint8)

        # First pass: count tiles
        tile_count = sum(1 for _ in self.generate_tiles(self.image))
        
        # Second pass: process tiles
        tile_generator = self.generate_tiles(self.image)
        batch_tiles = []
        batch_coords = []
        tiles_processed = 0

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(),
            TimeRemainingColumn(),
        ) as progress:
            task = progress.add_task("[cyan]Processing ...", total=tile_count)
            
            with torch.no_grad():
                for tile, (i, j) in tile_generator:
                    # Preprocess and add tile to batch
                    tile_tensor = torch.tensor(tile).permute(2, 0, 1).unsqueeze(0).float()
                    batch_tiles.append(tile_tensor)
                    batch_coords.append((i, j))

                    # Run batch when full
                    if len(batch_tiles) == batch_size:
                        self._process_batch_not_weighted(batch_tiles, batch_coords, predictions)
                        tiles_processed += len(batch_tiles)
                        progress.update(task, completed=tiles_processed)
                        batch_tiles.clear()
                        batch_coords.clear()

                # Handle remaining tiles
                if batch_tiles:
                    self._process_batch_not_weighted(batch_tiles, batch_coords, predictions)
                    tiles_processed += len(batch_tiles)
                    progress.update(task, completed=tiles_processed)

        # Apply filters for model_full
        if self.model_type == 'model_full':
            predictions[(self.image[:, :, 6] < -100) | (self.image[:, :, 6] > 20)] = 0
            predictions[(self.image[:, :, 5] == 4)] = 0

        return predictions


    def __getitem__(self, idx):
        """Return the tile and its corresponding coordinates."""
        return self.tiles[idx], self.tile_coords[idx]

    def __len__(self):
        """Return the number of tiles."""
        return len(self.tiles)

    def save_output(self, predictions, output_path):
        """Save the reconstructed output as a GeoTIFF."""
        console = Console()
        # Update predictions to uint8 if needed before saving
        predictions = predictions.astype(np.uint8)

        # Update the metadata, ensuring it matches the predictions
        updated_metadata = self.metadata.copy()
        updated_metadata.update({
            'driver': 'GTiff',
            'dtype': 'uint8',      # Make sure this matches predictions' dtype
            'count': 1,          # Single-band output
            'compress': 'lzw'      # Optional compression to reduce file size
        })

        # Save the file with rasterio, ensuring that spatial metadata is preserved
        with rasterio.open(output_path, 'w', **updated_metadata) as dst:
            dst.write(predictions, 1)  # Write data to the first band
        
        
        console.print(f"[green]✓[/green] Kelp classification map saved to [bold]{output_path}[bold].")

# Set the main directory
# main_directory = r"C:\Alena\results\20220806T191919_20220806T192707_T09UXQ"
# output_filename = "output_cli.tif"
# mean_per_channel = [ 9.73005488e+02  7.08909146e+02  4.49016997e+02  7.64114558e+02
#   5.04806707e+02  1.55057075e+00 -3.07090868e+01 -4.03823853e-02
#   2.47833866e-01 -2.47833866e-01 -3.45288439e-02  1.30275308e-02]
# std_per_channel = [3.14151787e+02 2.99688583e+02 3.10539248e+02 9.25681716e+02
#  3.78586231e+02 1.27053181e+00 8.72741729e+01 3.88193209e-01
#  4.20784913e-01 4.20784913e-01 1.12317310e+00 1.60626435e-01]
# data = SatelliteDataset(image_paths=X_val_paths, mask_paths=y_val_paths, augmentation=None, classes=["kelp"])  # solely to access to the methods of the class for index calculation
# dataset = DatasetInference(main_directory=main_directory, model=model, dataset=data, mean_per_channel=mean_per_channel, std_per_channel=std_per_channel)
# 
# # Run model and save predictions
# predictions = dataset.run_model_on_tiles()
# 
# output_path = os.path.join(main_directory, output_filename)
# dataset.save_output(predictions, output_path)


def segment(input_dir, output_filename, mean_per_channel, std_per_channel, model_type='model_full'): 
    """
    Perform semantic segmentation inference on a Sentinel-2 scene.
    
    Parameters:
    - input_dir: path to a .SAFE folder OR directory containing the expected input TIFF files
    - output_filename: output TIFF filename to save prediction
    - mean_per_channel, std_per_channel: normalization stats used during training
    - model_type: 'model_full' (with substrate/bathymetry) or 'model_s2bandsandindices_only'
    """
    
    # Load appropriate model
    model = load_model(model_type)
    
    # Preprocessing if input_dir is a SAFE folder
    if input_dir.endswith(".SAFE") and os.path.isdir(input_dir):
        safe_basename = os.path.basename(input_dir).replace(".SAFE", "")
        parent_dir = os.path.dirname(input_dir)
        output_folder = os.path.join(parent_dir, safe_basename)
        os.makedirs(output_folder, exist_ok=True)

        # Step 1: Extract S2 bands (skip if already extracted)
        b2348_file = os.path.join(output_folder, f"{safe_basename}_B2B3B4B8.tif")
        b5678a1112_file = os.path.join(output_folder, f"{safe_basename}_B5B6B7B8A_B11B12.tif")

        if os.path.exists(b2348_file) and os.path.exists(b5678a1112_file):
            console = Console()
            console.print("[yellow]⚠ Band TIFFs already exist, skipping extraction.[/yellow]")
        else:
            b2348_file, b5678a1112_file = extract_bands_to_geotiffs(input_dir, output_folder)
            if not b2348_file:
                raise RuntimeError(f"Failed to extract bands for {input_dir}")

        # Steps 2-4: Only for model_full (skip if bathymetry and substrate already exist)
        if model_type == 'model_full':
            bathy_file = os.path.join(output_folder, f"{safe_basename}_Bathymetry.tif")
            subs_file = os.path.join(output_folder, f"{safe_basename}_Substrate.tif")

            if os.path.exists(bathy_file) and os.path.exists(subs_file):
                console = Console()
                console.print("[yellow]⚠ Bathymetry and substrate TIFFs already exist, skipping alignment and merging.[/yellow]")
            else:
                warp_bathy_and_subs(parent_dir, safe_basename)
                merge_substrate_files_single(output_folder)
                apply_fill_nodata_single(output_folder)
        input_dir = output_folder

    # Create dataset and run inference
    data = SatelliteDataset(image_paths=None, mask_paths=None, augmentation=None, classes=["kelp"])
    dataset = DatasetInference(
        main_directory=input_dir,
        model=model,
        dataset=data,
        model_type=model_type,
        mean_per_channel=mean_per_channel,
        std_per_channel=std_per_channel,
        tile_size=512,
        overlap=0.5,  
        halo_size=64,
        padding_mode='reflect'
    )

    predictions = dataset.run_model_on_tiles(batch_size=8)
    output_path = os.path.join(input_dir, output_filename)
    dataset.save_output(predictions, output_path)