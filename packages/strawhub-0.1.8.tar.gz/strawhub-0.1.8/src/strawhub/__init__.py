"""StrawHub CLI - discover, publish, and install agent skills and roles."""

__version__ = "0.1.8"
