# =====================================
# generator=datazen
# version=3.2.3
# hash=466e6e247f0d4c88668873009f88a021
# =====================================

"""
Useful defaults and other package metadata.
"""

DESCRIPTION = "Simplify project workflows by standardizing use of GNU Make."
PKG_NAME = "vmklib"
VERSION = "2.0.11"
