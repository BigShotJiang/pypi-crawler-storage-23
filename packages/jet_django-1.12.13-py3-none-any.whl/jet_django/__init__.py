VERSION = '1.12.13'
default_app_config = 'jet_django.apps.JetDjangoConfig'
