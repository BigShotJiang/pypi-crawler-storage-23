import importlib.metadata

OPENLINEAGE_CLIENT_VERSION = importlib.metadata.version("openlineage-python")
PRODUCER = "https://github.com/celine-eu/celine-utils"
VERSION = "v1.0.0"
