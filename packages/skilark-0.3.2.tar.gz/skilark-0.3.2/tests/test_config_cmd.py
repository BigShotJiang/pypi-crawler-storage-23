"""Tests for `skilark config` command."""

from unittest.mock import MagicMock, call, patch

from skilark_cli.commands.config import run


def test_config_first_run():
    """Should print a setup hint and return without prompting."""
    with patch("skilark_cli.commands.config.ConfigStore") as mock_cls:
        mock_store = MagicMock()
        mock_store.is_first_run.return_value = True
        mock_cls.return_value = mock_store

        run()

        mock_store.load.assert_not_called()
        mock_store.update_topics.assert_not_called()


def test_config_adds_topic():
    """Should save updated topics when user adds a new one."""
    mock_config = {
        "user_id": "uuid-1",
        "topics": ["python", "kubernetes"],
        "api_url": "https://test",
    }

    with (
        patch("skilark_cli.commands.config.ConfigStore") as mock_store_cls,
        patch("skilark_cli.commands.config.inquirer") as mock_inq,
    ):
        mock_store = MagicMock()
        mock_store.is_first_run.return_value = False
        mock_store.load.return_value = mock_config
        mock_store_cls.return_value = mock_store

        mock_prompt = MagicMock()
        mock_prompt.execute.return_value = ["python", "kubernetes", "spark"]
        mock_inq.checkbox.return_value = mock_prompt

        run()

        mock_store.update_topics.assert_called_once_with(
            ["python", "kubernetes", "spark"]
        )


def test_config_removes_topic():
    """Should save updated topics when user removes one."""
    mock_config = {
        "user_id": "uuid-1",
        "topics": ["python", "kubernetes"],
        "api_url": "https://test",
    }

    with (
        patch("skilark_cli.commands.config.ConfigStore") as mock_store_cls,
        patch("skilark_cli.commands.config.inquirer") as mock_inq,
    ):
        mock_store = MagicMock()
        mock_store.is_first_run.return_value = False
        mock_store.load.return_value = mock_config
        mock_store_cls.return_value = mock_store

        mock_prompt = MagicMock()
        mock_prompt.execute.return_value = ["python"]
        mock_inq.checkbox.return_value = mock_prompt

        run()

        mock_store.update_topics.assert_called_once_with(["python"])


def test_config_no_changes():
    """Should report no changes when selection is identical to current config."""
    mock_config = {
        "user_id": "uuid-1",
        "topics": ["python"],
        "api_url": "https://test",
    }

    with (
        patch("skilark_cli.commands.config.ConfigStore") as mock_store_cls,
        patch("skilark_cli.commands.config.inquirer") as mock_inq,
        patch("skilark_cli.commands.config.console") as mock_console,
    ):
        mock_store = MagicMock()
        mock_store.is_first_run.return_value = False
        mock_store.load.return_value = mock_config
        mock_store_cls.return_value = mock_store

        mock_prompt = MagicMock()
        mock_prompt.execute.return_value = ["python"]
        mock_inq.checkbox.return_value = mock_prompt

        run()

        mock_store.update_topics.assert_called_once_with(["python"])
        # Verify "No changes." was printed (the dim message).
        printed_calls = [str(c) for c in mock_console.print.call_args_list]
        assert any("No changes" in s for s in printed_calls)


def test_config_checkbox_pre_populates_current_topics():
    """Should pass 'enabled: True' for topics already in config."""
    mock_config = {
        "user_id": "uuid-1",
        "topics": ["python"],
        "api_url": "https://test",
    }

    with (
        patch("skilark_cli.commands.config.ConfigStore") as mock_store_cls,
        patch("skilark_cli.commands.config.inquirer") as mock_inq,
    ):
        mock_store = MagicMock()
        mock_store.is_first_run.return_value = False
        mock_store.load.return_value = mock_config
        mock_store_cls.return_value = mock_store

        mock_prompt = MagicMock()
        mock_prompt.execute.return_value = ["python"]
        mock_inq.checkbox.return_value = mock_prompt

        run()

        # Extract the choices kwarg passed to inquirer.checkbox.
        _, kwargs = mock_inq.checkbox.call_args
        choices = kwargs["choices"]

        python_choice = next(c for c in choices if c["value"] == "python")
        go_choice = next(c for c in choices if c["value"] == "go")

        assert python_choice["enabled"] is True
        assert go_choice["enabled"] is False
