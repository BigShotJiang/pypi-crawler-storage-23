"""Unit tests for ConfigStore.

All tests use pytest's tmp_path fixture so they never touch the real
~/.skilark directory on the developer's machine.
"""

import os
import stat

import pytest

from skilark_cli.config_store import ConfigStore, DEFAULT_API_URL, validate_api_url


class TestIsFirstRun:
    def test_first_run_detected_when_no_file(self, tmp_path):
        store = ConfigStore(config_dir=tmp_path)
        assert store.is_first_run()

    def test_not_first_run_after_save(self, tmp_path):
        store = ConfigStore(config_dir=tmp_path)
        store.save(user_id="abc-123", topics=["python"])
        assert not store.is_first_run()


class TestSaveAndLoad:
    def test_save_and_load_roundtrip(self, tmp_path):
        store = ConfigStore(config_dir=tmp_path)
        store.save(
            user_id="abc-123",
            topics=["python", "kubernetes"],
            api_url="https://api.skilark.com",
        )
        config = store.load()
        assert config["user_id"] == "abc-123"
        assert config["topics"] == ["python", "kubernetes"]
        assert config["api_url"] == "https://api.skilark.com"

    def test_save_uses_default_api_url_when_omitted(self, tmp_path):
        store = ConfigStore(config_dir=tmp_path)
        store.save(user_id="abc-123", topics=["python"])
        config = store.load()
        assert config["api_url"] == DEFAULT_API_URL

    def test_save_creates_config_dir_if_missing(self, tmp_path):
        nested = tmp_path / "deep" / "nested"
        store = ConfigStore(config_dir=nested)
        store.save(user_id="x", topics=[])
        assert store.config_file.exists()

    def test_save_overwrites_existing_config(self, tmp_path):
        store = ConfigStore(config_dir=tmp_path)
        store.save(user_id="old-id", topics=["java"])
        store.save(user_id="new-id", topics=["go"])
        config = store.load()
        assert config["user_id"] == "new-id"
        assert config["topics"] == ["go"]

    def test_load_raises_when_no_file(self, tmp_path):
        store = ConfigStore(config_dir=tmp_path)
        with pytest.raises(FileNotFoundError):
            store.load()

    def test_save_empty_topics_list(self, tmp_path):
        store = ConfigStore(config_dir=tmp_path)
        store.save(user_id="abc-123", topics=[])
        config = store.load()
        assert config["topics"] == []


class TestUpdateTopics:
    def test_update_topics_replaces_list(self, tmp_path):
        store = ConfigStore(config_dir=tmp_path)
        store.save(user_id="abc-123", topics=["python"])
        store.update_topics(["python", "kubernetes", "spark"])
        config = store.load()
        assert config["topics"] == ["python", "kubernetes", "spark"]

    def test_update_topics_preserves_other_fields(self, tmp_path):
        store = ConfigStore(config_dir=tmp_path)
        store.save(
            user_id="abc-123",
            topics=["python"],
            api_url="https://api.skilark.com",
        )
        store.update_topics(["go"])
        config = store.load()
        # Ensure user_id and api_url are untouched
        assert config["user_id"] == "abc-123"
        assert config["api_url"] == "https://api.skilark.com"

    def test_update_topics_raises_when_no_file(self, tmp_path):
        store = ConfigStore(config_dir=tmp_path)
        with pytest.raises(FileNotFoundError):
            store.update_topics(["python"])


class TestFilePermissions:
    def test_config_file_is_owner_only(self, tmp_path):
        store = ConfigStore(config_dir=tmp_path)
        store.save(user_id="abc-123", topics=["python"])
        mode = os.stat(store.config_file).st_mode
        assert mode & stat.S_IRWXG == 0, "group should have no access"
        assert mode & stat.S_IRWXO == 0, "others should have no access"

    def test_config_file_permissions_preserved_on_update(self, tmp_path):
        store = ConfigStore(config_dir=tmp_path)
        store.save(user_id="abc-123", topics=["python"])
        store.update_topics(["go"])
        mode = os.stat(store.config_file).st_mode
        assert mode & stat.S_IRWXG == 0, "group should have no access"
        assert mode & stat.S_IRWXO == 0, "others should have no access"


class TestValidateApiUrl:
    def test_accepts_production_url(self):
        assert validate_api_url("https://api.skilark.com") == "https://api.skilark.com"

    def test_accepts_localhost_http(self):
        assert validate_api_url("http://localhost:8000") == "http://localhost:8000"

    def test_accepts_127_0_0_1_http(self):
        assert validate_api_url("http://127.0.0.1:8000") == "http://127.0.0.1:8000"

    def test_rejects_http_for_remote_host(self):
        with pytest.raises(ValueError, match="must use HTTPS"):
            validate_api_url("http://api.skilark.com")

    def test_rejects_unknown_host(self):
        with pytest.raises(ValueError, match="host not allowed"):
            validate_api_url("https://evil.example.com")

    def test_rejects_ftp_scheme(self):
        with pytest.raises(ValueError, match="must use HTTPS"):
            validate_api_url("ftp://api.skilark.com")

    def test_rejects_ftp_for_localhost(self):
        with pytest.raises(ValueError, match="must use http or https"):
            validate_api_url("ftp://localhost:8000")

    def test_save_rejects_invalid_api_url(self, tmp_path):
        store = ConfigStore(config_dir=tmp_path)
        with pytest.raises(ValueError, match="host not allowed"):
            store.save(user_id="abc", topics=[], api_url="https://evil.com")

    def test_load_rejects_tampered_api_url(self, tmp_path):
        store = ConfigStore(config_dir=tmp_path)
        store.save(user_id="abc", topics=[], api_url="https://api.skilark.com")
        # Tamper with the config file directly
        store.config_file.write_text(
            "user_id: abc\ntopics: []\napi_url: https://evil.com\n"
        )
        with pytest.raises(ValueError, match="host not allowed"):
            store.load()
