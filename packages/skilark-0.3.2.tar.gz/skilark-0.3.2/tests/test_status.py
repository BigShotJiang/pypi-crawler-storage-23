"""Tests for `skilark status` command."""

from unittest.mock import MagicMock, patch

from skilark_cli.commands.status import run


def test_status_first_run(capsys):
    """Should print a setup hint and return without calling the API."""
    with patch("skilark_cli.commands.status.ConfigStore") as mock_cls:
        mock_store = MagicMock()
        mock_store.is_first_run.return_value = True
        mock_cls.return_value = mock_store

        run()

        # API client must not be instantiated on a first run.
        mock_store.load.assert_not_called()


def test_status_displays_stats():
    """Should fetch stats and delegate rendering to render_stats."""
    mock_config = {
        "user_id": "uuid-1",
        "topics": ["python"],
        "api_url": "https://test",
    }
    mock_stats = {
        "streak": 7,
        "total_completed": 47,
        "week_completed": 8,
        "week_goal": 10,
        "topic_counts": {"Python": 10},
        "last_session": {
            "date": "2026-02-25",
            "topic": "Python",
            "title": "Generators",
        },
    }

    with (
        patch("skilark_cli.commands.status.ConfigStore") as mock_store_cls,
        patch("skilark_cli.commands.status.SkilarkClient") as mock_client_cls,
        patch("skilark_cli.commands.status.render_stats") as mock_render,
    ):
        mock_store = MagicMock()
        mock_store.is_first_run.return_value = False
        mock_store.load.return_value = mock_config
        mock_store_cls.return_value = mock_store

        mock_client = MagicMock()
        mock_client.get_stats.return_value = mock_stats
        mock_client_cls.return_value = mock_client

        run()

        # Client must be constructed with the values from config.
        mock_client_cls.assert_called_once_with(
            base_url="https://test", user_id="uuid-1"
        )
        mock_client.get_stats.assert_called_once()
        mock_render.assert_called_once()
        # render_stats(console, stats) — stats is the second positional arg.
        _, render_args, _ = mock_render.mock_calls[0]
        assert render_args[1] is mock_stats
