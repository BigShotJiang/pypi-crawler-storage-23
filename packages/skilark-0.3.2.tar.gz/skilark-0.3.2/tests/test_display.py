"""Tests for display.py rendering helpers.

Each test writes to a StringIO buffer via a forced-terminal Rich Console so
we can assert on the rendered text without touching stdout.

Rich emits ANSI escape codes when force_terminal=True, which fragment the
plain text tokens we want to assert on (e.g. "print(1 + 2)" becomes several
separate colored segments).  We strip ANSI codes via `strip_ansi()` before
asserting so tests remain readable and stable across Rich versions.
"""

import re
from io import StringIO

import pytest
from rich.console import Console

from skilark_cli.display import (
    render_challenge,
    render_hint,
    render_result,
    render_stats,
)

# ANSI escape code pattern — matches CSI sequences and OSC sequences.
_ANSI_RE = re.compile(r"\x1b(?:\[[0-9;]*[mK]|\][^\x07]*\x07)")


def strip_ansi(text: str) -> str:
    """Remove all ANSI escape sequences from *text*."""
    return _ANSI_RE.sub("", text)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def make_console() -> tuple[Console, StringIO]:
    """Return a (Console, buffer) pair for capture-based assertions."""
    buf = StringIO()
    # force_terminal=True makes Rich emit styled output rather than plain text,
    # which is required for the markup to be processed at all.
    console = Console(file=buf, force_terminal=True, width=80)
    return console, buf


# ---------------------------------------------------------------------------
# render_challenge
# ---------------------------------------------------------------------------


def test_render_challenge_contains_day_and_metadata():
    console, buf = make_console()
    challenge = {
        "source": "python",
        "title": "Generator Internals",
        "code_display": "print(1 + 2)",
        "question": "What does this print?",
        "hints": ["Think about arithmetic"],
    }
    render_challenge(console, challenge, day=7)
    output = buf.getvalue()

    assert "python" in output
    assert "Generator Internals" in output
    assert "7" in output  # day number


def test_render_challenge_includes_code():
    console, buf = make_console()
    challenge = {
        "source": "python",
        "title": "Generator Internals",
        "code_display": "print(1 + 2)",
        "question": "What does this print?",
        "hints": [],
    }
    render_challenge(console, challenge, day=1)
    # Strip ANSI escape codes: syntax highlighting splits tokens with color
    # sequences, so "print(1 + 2)" would not appear as a literal substring.
    output = strip_ansi(buf.getvalue())

    assert "print(1 + 2)" in output


def test_render_challenge_includes_question():
    console, buf = make_console()
    challenge = {
        "source": "go",
        "title": "Goroutine Leaks",
        "code_display": "go func() { select {} }()",
        "question": "What is wrong here?",
        "hints": [],
    }
    render_challenge(console, challenge, day=3)
    output = buf.getvalue()

    assert "What is wrong here?" in output


def test_render_challenge_shows_key_bindings():
    console, buf = make_console()
    challenge = {
        "source": "sql",
        "title": "Window Functions",
        "code_display": "SELECT ROW_NUMBER() OVER () FROM t;",
        "question": "What does this return?",
        "hints": [],
    }
    render_challenge(console, challenge, day=10)
    output = buf.getvalue()

    # Key binding hints should appear somewhere in the output.
    assert "hint" in output.lower() or "[h]" in output
    assert "skip" in output.lower() or "[s]" in output
    assert "quit" in output.lower() or "[q]" in output


def test_render_challenge_handles_missing_optional_fields():
    """Render should not crash when optional fields are absent."""
    console, buf = make_console()
    challenge = {
        "source": "kubernetes",
        "title": "Pod Networking",
        # No code_display, question, or hints keys
    }
    render_challenge(console, challenge, day=2)
    output = buf.getvalue()
    assert "kubernetes" in output


# ---------------------------------------------------------------------------
# render_result
# ---------------------------------------------------------------------------


def test_render_result_correct_shows_confirmation():
    console, buf = make_console()
    render_result(
        console,
        correct=True,
        explanation="Simple addition.",
        deep_link="https://skilark.com/refreshers/python#generators",
    )
    output = buf.getvalue()

    assert "Correct" in output or "✓" in output


def test_render_result_correct_shows_explanation_and_link():
    console, buf = make_console()
    render_result(
        console,
        correct=True,
        explanation="Simple addition.",
        deep_link="https://skilark.com/refreshers/python#generators",
    )
    output = buf.getvalue()

    assert "Simple addition." in output
    assert "skilark.com/refreshers/python#generators" in output


def test_render_result_wrong_shows_expected_answer():
    console, buf = make_console()
    render_result(
        console,
        correct=False,
        expected_answer="3",
        explanation="Simple addition.",
        deep_link="https://skilark.com/refreshers/python#generators",
    )
    output = buf.getvalue()

    assert "3" in output


def test_render_result_wrong_without_expected_answer():
    """render_result should not crash when expected_answer is omitted."""
    console, buf = make_console()
    render_result(
        console,
        correct=False,
        explanation="Generator return values are inaccessible via print.",
        deep_link="https://skilark.com/refreshers/python#generators",
    )
    output = buf.getvalue()

    # Should still show some failure indication
    assert "Not quite" in output or "✗" in output


def test_render_result_wrong_shows_explanation_and_link():
    console, buf = make_console()
    render_result(
        console,
        correct=False,
        expected_answer="1 2",
        explanation="Generator return values are inaccessible via print.",
        deep_link="https://skilark.com/refreshers/python#generators",
    )
    output = buf.getvalue()

    assert "Generator return values" in output
    assert "skilark.com" in output


# ---------------------------------------------------------------------------
# render_stats
# ---------------------------------------------------------------------------


def test_render_stats_shows_streak_and_total():
    console, buf = make_console()
    stats = {
        "streak": 7,
        "total_completed": 47,
        "week_completed": 8,
        "week_goal": 10,
        "topic_counts": {"Python": 10, "Kubernetes": 12},
        "last_session": {
            "date": "2026-02-25",
            "topic": "Kubernetes",
            "title": "Pod Networking",
        },
    }
    render_stats(console, stats)
    output = buf.getvalue()

    assert "7" in output   # streak
    assert "47" in output  # total_completed


def test_render_stats_shows_topics():
    console, buf = make_console()
    stats = {
        "streak": 5,
        "total_completed": 20,
        "week_completed": 3,
        "week_goal": 10,
        "topic_counts": {"Python": 10, "Kubernetes": 12, "Spark": 8},
        "last_session": None,
    }
    render_stats(console, stats)
    output = buf.getvalue()

    assert "Python" in output
    assert "Kubernetes" in output
    assert "Spark" in output


def test_render_stats_shows_last_session():
    console, buf = make_console()
    stats = {
        "streak": 2,
        "total_completed": 15,
        "week_completed": 2,
        "week_goal": 10,
        "topic_counts": {},
        "last_session": {
            "date": "yesterday",
            "topic": "Kubernetes",
            "title": "Pod Networking",
        },
    }
    render_stats(console, stats)
    output = buf.getvalue()

    assert "Kubernetes" in output
    assert "Pod Networking" in output


def test_render_stats_empty():
    """Zero stats with no topics and no last session should not crash."""
    console, buf = make_console()
    stats = {
        "streak": 0,
        "total_completed": 0,
        "week_completed": 0,
        "week_goal": 10,
        "topic_counts": {},
        "last_session": None,
    }
    render_stats(console, stats)
    output = buf.getvalue()

    assert "0" in output


def test_render_stats_week_progress_bar():
    """Week progress bar numerics should be reflected in output."""
    console, buf = make_console()
    stats = {
        "streak": 1,
        "total_completed": 5,
        "week_completed": 5,
        "week_goal": 10,
        "topic_counts": {},
        "last_session": None,
    }
    render_stats(console, stats)
    # Rich highlights numbers individually, fragmenting "5/10" with escape
    # sequences; strip ANSI before asserting on the combined string.
    output = strip_ansi(buf.getvalue())

    assert "5/10" in output


# ---------------------------------------------------------------------------
# render_hint
# ---------------------------------------------------------------------------


def test_render_hint_shows_text():
    console, buf = make_console()
    render_hint(console, "Think about what print() does")
    # Rich markup treats "print()" as a potential markup tag and may split it
    # with escape codes; strip ANSI before asserting.
    output = strip_ansi(buf.getvalue())

    assert "print()" in output


def test_render_hint_shows_bulb_icon():
    console, buf = make_console()
    render_hint(console, "Consider the base case.")
    output = buf.getvalue()

    assert "💡" in output


def test_render_hint_handles_empty_text():
    """render_hint should not crash on an empty hint string."""
    console, buf = make_console()
    render_hint(console, "")
    # Just verify no exception was raised; output may be minimal.
    assert buf.getvalue() is not None
