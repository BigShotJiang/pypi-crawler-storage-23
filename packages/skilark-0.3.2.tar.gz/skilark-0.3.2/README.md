# skilark

Your career intelligence companion. Skilark delivers daily coding challenges based on what employers actually look for — so you stay sharp on the skills that matter.

Available on the command line and [Telegram](https://t.me/skilaborbot).

## Install

```bash
pip install skilark
```

Requires Python 3.11+.

## Quick start

```bash
skilark          # start today's challenge
skilark status   # see your streak and progress
skilark config   # change your topics
skilark link     # link to your Telegram account
```

On first run, pick the topics you want to sharpen — Python, Go, Kubernetes, System Design, and 30+ more. Skilark serves bite-sized challenges matched to your level.

## How it works

Each challenge shows a short code snippet and asks: *What is the output?*

```
Day 1 · python · Generator Send

  def gen():
      x = yield 1
      yield x + 10

  g = gen()
  print(next(g))
  print(g.send(5))

  [h] hint  [s] skip  [q] quit

  Your answer: _
```

Get instant feedback with explanations and links to deep-dive pages on [skilark.com](https://skilark.com).

## Cross-platform

Use `skilark link` to connect your CLI and Telegram accounts. Your streak and progress sync across both.

## Changelog

### 0.2.0

- Added Telegram bot integration
- New `skilark link` command to connect CLI and Telegram accounts
- Synced streaks and progress across platforms

### 0.1.2

- Show source language in challenge header
- Improved question clarity
- Better deep-dive links
- Added project description

### 0.1.1

- Fixed challenge delivery after onboarding
- Expanded to 34 selectable topics

### 0.1.0

- Initial release — interactive challenges, streaks, adaptive difficulty
