## `ezan/version.py`
"""
Ezan - Namaz vakitleri ve kıble hesaplama modülü.
"""

from typing import Dict, List, Tuple

__version__: str = "0.2.4"

# License information
__license__: str = "AGPL-3.0-or-later"
__license_name__: str = "GNU Affero General Public License v3.0 or later"
__license_url__: str = "https://www.gnu.org/licenses/agpl-3.0.html"

# Package description
__description__: str = "Ezan - Namaz vakitleri ve kıble hesaplama modülü."
__summary__: str = "Ezan - Namaz vakitleri ve kıble hesaplama modülü."
__keywords__: List[str] = [
    "ezam",
    "adhan",
    "namaz",
    "salat",
    "vakit",
    "time",
]

# Author information
__author__: str = "Mehmet Keçeci"
__author_email__: str = "mkececi@yaani.com"
__maintainer__: str = "Mehmet Keçeci"
__maintainer_email__: str = "mkececi@yaani.com"

# Project URLs
__url__: str = "https://github.com/WhiteSymmetry/ezan"
__docs__: str = "https://github.com/WhiteSymmetry/ezan"  # Documentation URL
__source__: str = "https://github.com/WhiteSymmetry/ezan"
__tracker__: str = "https://github.com/WhiteSymmetry/ezan/issues"
__download_url__: str = "https://pypi.org/project/ezan/"