class CertificateExpiredException(Exception):
    pass