"""
main.py — NeuroLoop Python agent entry point.

Default model: ollama/qwen3:5b  (Qwen3 5B via local Ollama)

Model selection (priority order):
  1. --model CLI flag
  2. NEUROLOOP_MODEL environment variable
  3. Auto-detect from running API keys / services:
       Ollama running     → ollama/qwen3:5b  (default)
       ANTHROPIC_API_KEY  → claude-3-5-sonnet-20241022
       OPENAI_API_KEY     → gpt-4o
       GEMINI_API_KEY     → gemini/gemini-2.0-flash
  4. Fallback: ollama/qwen3:5b

Usage:
  uv run neuroloop-py [--model MODEL] [initial_message]
  python -m neuroloop [--model MODEL] [initial_message]
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
import urllib.request

# Suppress noisy litellm banners before any litellm import
os.environ.setdefault("LITELLM_LOCAL_MODEL_COST_MAP", "True")
os.environ.setdefault("LITELLM_LOG", "ERROR")

from .agent import NeuroloopAgent, console

DEFAULT_MODEL = "ollama/qwen3:5b"


def _pick_model() -> str:
    """Select the LLM model from CLI args → env var → auto-detect."""
    argv = sys.argv[1:]

    # 1. --model flag
    for i, a in enumerate(argv):
        if a in ("--model", "-m") and i + 1 < len(argv):
            return argv[i + 1]
        if a.startswith("--model="):
            return a.split("=", 1)[1]

    # 2. Environment variable
    if env_model := os.environ.get("NEUROLOOP_MODEL"):
        return env_model

    # 3. Ollama (preferred — check for qwen3:5b specifically)
    try:
        with urllib.request.urlopen(
            "http://localhost:11434/api/tags", timeout=2
        ) as r:
            data = json.loads(r.read())
            names = [m["name"] for m in data.get("models", [])]
            # Prefer qwen3:5b; fall back to first available model
            for preferred in ("qwen3:5b", "qwen3", "gpt-oss:20b", "gpt-oss"):
                if any(n.startswith(preferred.split(":")[0]) for n in names):
                    match = next(
                        (n for n in names if n.startswith(preferred.split(":")[0])),
                        names[0],
                    )
                    return f"ollama/{match}"
            if names:
                return f"ollama/{names[0]}"
    except Exception:
        pass

    # 4. Cloud API keys
    if os.environ.get("ANTHROPIC_API_KEY"):
        return "claude-3-5-sonnet-20241022"
    if os.environ.get("OPENAI_API_KEY"):
        return "gpt-4o"
    if os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY"):
        return "gemini/gemini-2.0-flash"

    # 5. Hard default
    return DEFAULT_MODEL


def _get_initial_message() -> str | None:
    """Extract optional initial message from non-flag CLI arguments."""
    argv = sys.argv[1:]
    non_flags: list[str] = []
    skip_next = False
    for a in argv:
        if skip_next:
            skip_next = False
            continue
        if a in ("--model", "-m"):
            skip_next = True
            continue
        if a.startswith("--model=") or a.startswith("-m="):
            continue
        non_flags.append(a)
    return " ".join(non_flags) if non_flags else None


async def _main() -> None:
    model = _pick_model()
    initial_message = _get_initial_message()

    agent = NeuroloopAgent(model=model)

    if initial_message:
        from .prompts import build_system_prompt
        from rich.markdown import Markdown as RMd
        from rich.rule import Rule

        display_text, system_context, skill_index = await agent.before_agent_start(initial_message)
        if display_text:
            console.print(RMd(display_text))
            console.print(Rule(style="dim"))

        system_prompt = build_system_prompt(system_context, skill_index)
        await agent.run_turn(initial_message, system_prompt)

    await agent.run()


def main() -> None:
    """Synchronous entry point for the `neuroloop-py` console script."""
    try:
        asyncio.run(_main())
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
