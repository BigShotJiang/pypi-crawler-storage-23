"""
neuroloop — EXG-aware agent (Python edition using aider/litellm).
"""

from .prompts import NEUROLOOP_VERSION

__version__ = NEUROLOOP_VERSION
__all__ = ["NEUROLOOP_VERSION"]
