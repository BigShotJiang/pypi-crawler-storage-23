"""
tools/protocol.py — run_protocol tool.

Executes a multi-step guided protocol (breathing exercise, progressive muscle
relaxation, grounding, recovery reset, somatic scan, etc.) step by step with:
  • OS notifications at every step transition (via neuroskill notify)
  • Per-step timing with asyncio.sleep
  • EXG labelling at every step (always on)
  • Streamed progress printed to console
"""

import asyncio
from typing import Any, Callable, Optional

from ..neuroskill.run import run_neuroskill


async def _notify(title: str, body: Optional[str] = None) -> None:
    """Send an OS notification via neuroskill. Non-fatal."""
    try:
        args = ["notify", title]
        if body:
            args.append(body)
        await run_neuroskill(args)
    except Exception:
        pass


async def _label(text: str, context: Optional[str] = None) -> None:
    """Create an EXG label via neuroskill. Non-fatal."""
    try:
        args = ["label", text]
        if context:
            args.extend(["--context", context])
        await run_neuroskill(args)
    except Exception:
        pass


async def run_protocol_impl(
    title: str,
    intro: Optional[str],
    steps: list[dict[str, Any]],
    on_update: Optional[Callable[[str], None]] = None,
) -> str:
    """Execute a multi-step guided protocol and return a log string."""
    log: list[str] = []

    def emit(line: str) -> None:
        log.append(line)
        if on_update:
            on_update(line)

    step_word = "step" if len(steps) == 1 else "steps"
    emit(f"▶ **{title}** — {len(steps)} {step_word}")

    await _notify(
        title,
        intro or f"{len(steps)}-step protocol starting. Follow the notifications.",
    )
    await _label(
        f"protocol start: {title}",
        f'Starting protocol "{title}" ({len(steps)} {step_word}).{" " + intro if intro else ""}',
    )

    completed_steps = 0
    aborted = False

    for i, step in enumerate(steps):
        name = step.get("name", "")
        instruction = step.get("instruction", "")
        duration_secs = float(step.get("duration_secs", 0))

        num = f"{i + 1}/{len(steps)}"
        is_announcement = duration_secs == 0
        duration_note = f" — {duration_secs:.0f}s" if duration_secs > 0 else ""

        emit(f"\nStep {num}: **{name}**{duration_note}\n{instruction}")

        await _notify(f"{name}{duration_note}", instruction)

        label_kind = "announce" if is_announcement else "step"
        clean_name = name.lstrip("▶►").strip()[:40].lower()
        await _label(
            f"{label_kind} {i + 1}: {clean_name}",
            f'Protocol "{title}", step {num}. {instruction}',
        )

        if duration_secs > 0:
            try:
                await asyncio.sleep(duration_secs)
            except asyncio.CancelledError:
                aborted = True
                break

        completed_steps += 1

    if not aborted:
        await _notify(f"{title} complete ✓", "Well done. Take a moment to notice how you feel.")
        await _label(
            f"protocol complete: {title}",
            f'Finished protocol "{title}" — all {len(steps)} {step_word} completed.',
        )
        emit(f"\n✓ **{title} complete.** Take a moment to notice how you feel.")
    else:
        emit(f"\n⚠ Protocol cancelled after {completed_steps}/{len(steps)} {step_word}.")

    return "\n".join(log)


# ── Tool definition ───────────────────────────────────────────────────────────

_STEP_SCHEMA = {
    "type": "object",
    "properties": {
        "name": {
            "type": "string",
            "description": (
                "Short step name shown as the notification title. "
                "For announcement steps use a ▶ prefix (e.g. '▶ Coming up: Slow exhale'). "
                "For action steps use a plain verb (e.g. 'Exhale slowly…')."
            ),
        },
        "instruction": {
            "type": "string",
            "description": (
                "Full instruction shown in chat and notification body. "
                "For announcement steps: describe what is about to happen. "
                "For action steps: tell the user exactly what to do right now."
            ),
        },
        "duration_secs": {
            "type": "number",
            "description": (
                "How long to hold this step in seconds. "
                "Use 0 for announcement steps (show and immediately move on). "
                "Use the actual physical duration for action steps."
            ),
        },
    },
    "required": ["name", "instruction", "duration_secs"],
}

RUN_PROTOCOL_TOOL = {
    "type": "function",
    "function": {
        "name": "run_protocol",
        "description": (
            "Execute a multi-step guided protocol step by step with OS notifications, "
            "per-step timing, and EXG labelling at every step.\n\n"
            "MANDATORY STEP STRUCTURE:\n"
            "1. Always precede every timed action with a 0-duration announcement step.\n"
            "2. Break every physical phase into its own step.\n"
            "3. For repeated cycles, expand them as individual steps in the array.\n"
            "4. For body-scan sequences, one step per body region.\n"
            "5. EXG labelling is always on — every step creates a timestamped record.\n\n"
            "Only call this after the user has explicitly agreed to do the protocol."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "title": {
                    "type": "string",
                    "description": "Protocol name shown in notification titles.",
                },
                "intro": {
                    "type": "string",
                    "description": "Opening message sent as the first notification body.",
                },
                "steps": {
                    "type": "array",
                    "items": _STEP_SCHEMA,
                    "description": "Ordered list of steps following the mandatory structure.",
                },
            },
            "required": ["title", "steps"],
        },
    },
}
