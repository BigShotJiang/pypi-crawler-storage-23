"""
tools/web_fetch.py — fetches a URL and returns its text content.
HTML is stripped to plain text. JSON is pretty-printed.
"""

import json
import re
from typing import Optional

try:
    import httpx
    _HTTPX = True
except ImportError:
    _HTTPX = False

try:
    import urllib.request
    import urllib.error
except ImportError:
    pass

DEFAULT_MAX_CHARS = 12_000

_UA = (
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
)

_HEADERS = {
    "User-Agent": _UA,
    "Accept": "text/html,application/xhtml+xml,application/json,text/plain,*/*",
    "Accept-Language": "en-US,en;q=0.9",
}


def _strip_html(html: str) -> str:
    """Strip HTML tags and decode common entities."""
    html = re.sub(r"<script[\s\S]*?</script>", "", html, flags=re.IGNORECASE)
    html = re.sub(r"<style[\s\S]*?</style>", "", html, flags=re.IGNORECASE)
    html = re.sub(r"<noscript[\s\S]*?</noscript>", "", html, flags=re.IGNORECASE)
    html = re.sub(r"<svg[\s\S]*?</svg>", "", html, flags=re.IGNORECASE)
    html = re.sub(r"<!--[\s\S]*?-->", "", html)
    html = re.sub(r"<[^>]+>", " ", html)
    html = html.replace("&nbsp;", " ").replace("&amp;", "&")
    html = html.replace("&lt;", "<").replace("&gt;", ">")
    html = html.replace("&quot;", '"').replace("&#39;", "'")
    html = re.sub(r"[ \t]{2,}", " ", html)
    html = re.sub(r"\n{3,}", "\n\n", html)
    return html.strip()


async def web_fetch_impl(url: str, max_chars: int = DEFAULT_MAX_CHARS) -> str:
    """Fetch a URL and return its text content (stripped HTML, pretty JSON, or raw text)."""
    try:
        if _HTTPX:
            async with httpx.AsyncClient(
                follow_redirects=True, timeout=30.0, headers=_HEADERS
            ) as client:
                resp = await client.get(url)
                if resp.status_code >= 400:
                    body = resp.text[:500]
                    return f"HTTP {resp.status_code}\n{body}"
                content_type = resp.headers.get("content-type", "")
                if "application/json" in content_type:
                    text = json.dumps(resp.json(), indent=2)
                elif "html" in content_type:
                    text = _strip_html(resp.text)
                else:
                    text = resp.text
        else:
            # Fallback: use urllib (sync, run in executor)
            import asyncio
            import functools

            def _fetch() -> str:
                req = urllib.request.Request(url, headers=_HEADERS)
                with urllib.request.urlopen(req, timeout=30) as resp:
                    ct = resp.headers.get("Content-Type", "")
                    raw = resp.read().decode("utf-8", errors="replace")
                    if "application/json" in ct:
                        return json.dumps(json.loads(raw), indent=2)
                    if "html" in ct:
                        return _strip_html(raw)
                    return raw

            loop = asyncio.get_event_loop()
            text = await loop.run_in_executor(None, _fetch)

    except Exception as exc:
        return f"Fetch error: {exc}"

    if len(text) > max_chars:
        return f"{text[:max_chars]}\n\n[...truncated — {len(text) - max_chars} chars omitted]"
    return text


# ── Tool definition (OpenAI function-call schema) ────────────────────────────

WEB_FETCH_TOOL = {
    "type": "function",
    "function": {
        "name": "web_fetch",
        "description": (
            "Fetch the text content of any URL. HTML is stripped to readable text. "
            "Useful for reading documentation, articles, blog posts, GitHub issues, "
            "and other web pages."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "The URL to fetch."},
                "max_chars": {
                    "type": "integer",
                    "description": f"Maximum characters to return. Default: {DEFAULT_MAX_CHARS}",
                },
            },
            "required": ["url"],
        },
    },
}
