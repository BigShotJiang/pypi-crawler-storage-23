"""
tools/web_search.py — DuckDuckGo Lite search (no API key required).

Scrapes https://lite.duckduckgo.com/lite/ for results and returns
a structured list of title / url / snippet.
"""

import re
from dataclasses import dataclass
from typing import Optional
from urllib.parse import quote_plus

try:
    import httpx
    _HTTPX = True
except ImportError:
    _HTTPX = False

DDG_LITE = "https://lite.duckduckgo.com/lite/"
DEFAULT_K = 8

_UA = (
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
)

_HEADERS = {
    "User-Agent": _UA,
    "Accept": "text/html,*/*",
    "Accept-Language": "en-US,en;q=0.9",
}


@dataclass
class SearchResult:
    title: str
    url: str
    snippet: str


def _unescape(s: str) -> str:
    return (
        s.replace("&amp;", "&")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&quot;", '"')
        .replace("&#39;", "'")
    )


def _parse_ddg_lite(html: str) -> list[SearchResult]:
    results: list[SearchResult] = []

    link_re = re.compile(
        r'<a[^>]+class="result-link"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)</a>',
        re.IGNORECASE,
    )
    snippet_re = re.compile(
        r'<td[^>]+class="result-snippet"[^>]*>([\s\S]*?)</td>',
        re.IGNORECASE,
    )

    links: list[dict] = []
    for m in link_re.finditer(html):
        raw_href = m.group(1)
        raw_title = m.group(2)

        url = raw_href
        uddg = re.search(r"[?&]uddg=([^&]+)", raw_href)
        if uddg:
            try:
                from urllib.parse import unquote
                url = unquote(uddg.group(1))
            except Exception:
                url = raw_href
        elif raw_href.startswith("//"):
            url = f"https:{raw_href}"

        title = _unescape(re.sub(r"<[^>]+>", "", raw_title)).strip()
        if title and url:
            links.append({"url": url, "title": title})

    snippets: list[str] = []
    for m in snippet_re.finditer(html):
        raw = re.sub(r"<[^>]+>", "", m.group(1))
        snippets.append(_unescape(re.sub(r"\s+", " ", raw)).strip())

    for i, link in enumerate(links):
        results.append(
            SearchResult(
                title=link["title"],
                url=link["url"],
                snippet=snippets[i] if i < len(snippets) else "",
            )
        )
    return results


async def web_search_impl(query: str, max_results: int = DEFAULT_K) -> str:
    """Search DuckDuckGo and return formatted results."""
    k = min(max_results, 20)
    url = f"{DDG_LITE}?q={quote_plus(query)}"

    try:
        if _HTTPX:
            async with httpx.AsyncClient(
                follow_redirects=True, timeout=20.0, headers=_HEADERS
            ) as client:
                resp = await client.get(url)
                if resp.status_code >= 400:
                    return f"Search failed: HTTP {resp.status_code}"
                html = resp.text
        else:
            import asyncio
            import urllib.request

            def _fetch() -> str:
                req = urllib.request.Request(url, headers=_HEADERS)
                with urllib.request.urlopen(req, timeout=20) as r:
                    return r.read().decode("utf-8", errors="replace")

            html = await asyncio.get_event_loop().run_in_executor(None, _fetch)

    except Exception as exc:
        return f"Search error: {exc}"

    results = _parse_ddg_lite(html)[:k]
    if not results:
        return "No results found."

    lines = [
        f"{i + 1}. **{r.title}**\n   URL: {r.url}\n   {r.snippet}"
        for i, r in enumerate(results)
    ]
    return "\n\n".join(lines)


# ── Tool definition ───────────────────────────────────────────────────────────

WEB_SEARCH_TOOL = {
    "type": "function",
    "function": {
        "name": "web_search",
        "description": (
            "Search the web via DuckDuckGo. Returns titles, URLs, and snippets "
            "for the top results. Use this to find current information, "
            "documentation, articles, or any web content."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "The search query."},
                "max_results": {
                    "type": "integer",
                    "description": f"Maximum number of results. Default: {DEFAULT_K}",
                },
            },
            "required": ["query"],
        },
    },
}
