"""
neuroskill/client.py — persistent SkillClient singleton for the neuroloop agent.

Wraps neuroskill.cli.SkillClient with:
  • mDNS port discovery (with lsof fallback)
  • Auto-reconnect on connection loss
  • WebSocket-first transport, HTTP fallback
  • A single shared connection reused across all agent turns
  • Live event queue for broadcast events (scores, label_created, etc.)

This replaces the subprocess-based approach (npx neuroskill) from the
TypeScript original. Instead of spawning a new process per call, we maintain
a persistent WebSocket connection to the Skill server and send JSON commands.
"""

from __future__ import annotations

import asyncio
import json
import time
from typing import Any, Callable, Optional

from neuroskill.cli import (
    SkillClient,
    _discover_lsof,
    _discover_mdns,
)

# ── Singleton connection ──────────────────────────────────────────────────────


class SkillConnection:
    """
    Singleton wrapper around SkillClient with auto-reconnect.

    Usage:
        conn = SkillConnection.get()
        response = await conn.send({"command": "status"})
    """

    _instance: Optional[SkillConnection] = None

    def __init__(self) -> None:
        self._client: Optional[SkillClient] = None
        self._port: Optional[int] = None
        self._lock: asyncio.Lock = asyncio.Lock()
        # Subscribers for broadcast events (scores, label_created, …)
        self._event_listeners: list[Callable[[dict], None]] = []
        self._event_pump_task: Optional[asyncio.Task] = None

    @classmethod
    def get(cls) -> SkillConnection:
        """Return the process-wide singleton."""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    # ── Public API ────────────────────────────────────────────────────────────

    async def send(self, cmd: dict, timeout_ms: int = 10_000) -> dict:
        """Send a command to the Skill server and return the parsed response.

        Auto-connects on the first call and reconnects after a dropped connection.
        Returns ``{"ok": False, "error": "..."}`` on any failure.
        """
        try:
            client = await self._ensure_connected()
            return await client.send(cmd, timeout_ms)
        except Exception as first_exc:
            # Connection may have dropped — reset and retry once.
            async with self._lock:
                self._client = None
            try:
                client = await self._ensure_connected()
                return await client.send(cmd, timeout_ms)
            except Exception as exc:
                return {"ok": False, "error": str(exc)}

    def add_event_listener(self, fn: Callable[[dict], None]) -> Callable[[], None]:
        """Subscribe to broadcast events (scores, label_created, …).

        Returns an unsubscribe callable.
        """
        self._event_listeners.append(fn)

        def _unsub() -> None:
            try:
                self._event_listeners.remove(fn)
            except ValueError:
                pass

        return _unsub

    @property
    def port(self) -> Optional[int]:
        """The currently connected server port, if any."""
        return self._port

    @property
    def is_connected(self) -> bool:
        """True if the WebSocket is open."""
        c = self._client
        return bool(
            c is not None
            and c.transport == "ws"
            and c._ws is not None
        )

    async def close(self) -> None:
        """Gracefully close the connection."""
        if self._event_pump_task:
            self._event_pump_task.cancel()
            try:
                await self._event_pump_task
            except asyncio.CancelledError:
                pass
            self._event_pump_task = None
        if self._client:
            await self._client.close()
            self._client = None

    # ── Internals ─────────────────────────────────────────────────────────────

    async def _ensure_connected(self) -> SkillClient:
        async with self._lock:
            if self._client is not None:
                # Quick liveness check for WebSocket transport
                if self._client.transport == "ws":
                    ws = self._client._ws
                    if ws is not None:
                        return self._client
                else:
                    # HTTP transport — always "connected"
                    return self._client
                # WS is dead — re-connect
                await self._client.close()
                self._client = None

            await self._connect()
            return self._client  # type: ignore[return-value]

    async def _connect(self) -> None:
        """Discover the port and establish a WebSocket (or HTTP) connection."""
        if self._port is None:
            self._port = await self._discover_port()

        client = SkillClient()
        client.http_base = f"http://127.0.0.1:{self._port}"

        # Try WebSocket first; fall back to HTTP if unavailable.
        try:
            await client.connect_ws(self._port, timeout=2.0)
            client.transport = "ws"
            # Start the background receive loop
            loop = asyncio.get_running_loop()
            client._recv_task = loop.create_task(client._recv_loop())
            # Start our event pump
            self._start_event_pump(client)
        except Exception:
            client.transport = "http"

        self._client = client

    async def _discover_port(self) -> int:
        """Discover the Skill server port via mDNS → lsof → default 8375."""
        port = await _discover_mdns(timeout=3.0)
        if port:
            return port
        port = await _discover_lsof()
        if port:
            return port
        return 8375  # last-resort default

    def _start_event_pump(self, client: SkillClient) -> None:
        """Start a background task that forwards WS broadcast events to listeners."""
        if self._event_pump_task and not self._event_pump_task.done():
            self._event_pump_task.cancel()

        async def _pump() -> None:
            # NOTE: do NOT use asyncio.shield() here — it creates an inner
            # Task for each Queue.get() call that keeps running even when the
            # outer task is cancelled, producing "Task destroyed but pending!"
            # warnings.  A plain wait_for() correctly cancels the Queue.get()
            # coroutine when the timeout fires.
            try:
                while True:
                    try:
                        event = await asyncio.wait_for(
                            client._events.get(), timeout=5.0
                        )
                        for fn in list(self._event_listeners):
                            try:
                                fn(event)
                            except Exception:
                                pass
                    except asyncio.TimeoutError:
                        continue
            except asyncio.CancelledError:
                pass

        loop = asyncio.get_running_loop()
        self._event_pump_task = loop.create_task(_pump())
