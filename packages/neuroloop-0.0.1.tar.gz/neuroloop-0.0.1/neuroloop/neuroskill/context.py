"""
neuroskill/context.py — contextual EXG data selection.

Reads domain signals from the user's prompt and decides which neuroskill
commands to run AND which skill markdown files to inject. All tasks fire in
parallel; failures are silently skipped.

The base `status` snapshot is always injected by agent.py — everything here
is additive.

Mirrors the TypeScript architecture:

  TypeScript                               Python equivalent
  ─────────────────────────────────────── ──────────────────────────────────────
  Pi skill loader (skillsOverride)         _load_skill() / _load_metrics_md()
  Pi model-based skill invocation          Signal-driven injection in this file
  selectContextualData(prompt)             select_contextual_data(prompt)
  warmCompareInBackground()                warm_compare_in_background()

Skill → signal mapping (mirrors TypeScript main.ts skillsOverride registration):

  SKILL.md name              Signal condition
  ─────────────────────────  ─────────────────────────────────────────────────
  neuroskill-protocols       s["protocols"]          (explicit intent)
  neuroskill-sleep           s["sleep"]              (sleep context)
  neuroskill-sessions        s["sessions"] or compare  (history context)
  neuroskill-search          s["compare"]            (A/B comparison)
  neuroskill-labels          s["labels_api"]         (label API questions)
  neuroskill-data-reference  s["metrics_ref"]        (metric definitions)
  neuroskill-transport       s["transport"]          (connection questions)
  neuroskill-streaming       s["streaming"]          (stream/calibrate/notify)
  neuroskill-status          s["session"]            (status/device questions)
  neuroskill-recipes         s["scripting"]          (automation questions)
  METRICS.md                 s["metrics_ref"]        (alongside data-reference)
"""

import asyncio
from pathlib import Path
from typing import Optional

from .run import run_neuroskill
from .signals import Signals, detect_signals

_HERE = Path(__file__).parent
_SKILLS_DIR   = _HERE.parent.parent / "skills"
_METRICS_PATH = _HERE.parent.parent / "METRICS.md"

# ─────────────────────────────────────────────────────────────────────────────
# Skill file loader
# ─────────────────────────────────────────────────────────────────────────────

def _load_skill(skill_name: str) -> Optional[str]:
    """
    Read skills/<skill_name>/SKILL.md and return its content, or None if missing.

    Mirrors the TypeScript main.ts skill scanner:
        const skillFile = join(SKILLS_DIR, entry.name, "SKILL.md");
        if (!existsSync(skillFile)) continue;
        const content = readFileSync(skillFile, "utf8");
    """
    path = _SKILLS_DIR / skill_name / "SKILL.md"
    try:
        if path.exists():
            return path.read_text(encoding="utf-8")
    except OSError:
        pass
    return None


def _load_metrics_md() -> Optional[str]:
    """
    Read METRICS.md from the project root.

    Mirrors TypeScript main.ts:
        if (existsSync(METRICS_MD_PATH)) {
            extra.push({
                name: "neuroskill-metrics",
                description: "NeuroSkill EXG metrics reference …",
                filePath: …,
            });
        }
    """
    try:
        if _METRICS_PATH.exists():
            return _METRICS_PATH.read_text(encoding="utf-8")
    except OSError:
        pass
    return None


# ─────────────────────────────────────────────────────────────────────────────
# Compare cache
#
# `neuroskill compare` takes ~60 s. It must never block a response.
# Strategy:
#   • On first request, fire it in the background and return nothing this turn.
#   • On subsequent requests, return the cached result if it is still fresh.
#   • The cache is refreshed in the background whenever it expires and compare
#     is relevant again.
# ─────────────────────────────────────────────────────────────────────────────

COMPARE_CACHE_TTL_S = 10 * 60  # 10 minutes

_compare_cache: dict = {
    "text": None,
    "built_at": None,
    "task": None,
}


def _get_fresh_compare() -> Optional[str]:
    """Return cached compare text if still fresh, otherwise None."""
    import time
    text = _compare_cache.get("text")
    built_at = _compare_cache.get("built_at")
    if not text or built_at is None:
        return None
    if time.time() - built_at > COMPARE_CACHE_TTL_S:
        return None
    return text


def warm_compare_in_background() -> None:
    """
    Kick off a background compare run if not already running and cache is stale.
    Safe to call at any time — no-op if a build is in flight or cache is fresh.

    Mirrors TypeScript:
        export function warmCompareInBackground(): void {
            if (compareCache.pending) return;
            if (getFreshCompare()) return;
            compareCache.pending = runNeuroSkill(["compare"]).then(…)
        }
    """
    import time as t

    if _compare_cache.get("task") is not None:
        return  # already running
    if _get_fresh_compare() is not None:
        return  # cache still fresh

    async def _build() -> None:
        result = await run_neuroskill(["compare"])
        if result.ok and result.text:
            _compare_cache["text"] = result.text
            _compare_cache["built_at"] = t.time()
        _compare_cache["task"] = None

    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            task = loop.create_task(_build())
            _compare_cache["task"] = task
    except RuntimeError:
        pass  # no event loop — skip prewarm


# ─────────────────────────────────────────────────────────────────────────────
# Contextual data selector
# ─────────────────────────────────────────────────────────────────────────────

async def select_contextual_data(prompt: str) -> list[str]:
    """
    Decide which additional neuroskill commands to run AND which skill markdown
    files to inject based on the user's prompt, then return labelled text blocks.

    Two categories of output:
      extras  — skill markdown files (injected directly, no neuroskill query)
      results — neuroskill command outputs (run in parallel, appended after extras)

    Mirrors the TypeScript architecture:
      Pi skill invocation → extras (skill SKILL.md files)
      selectContextualData tasks → results (parallel neuroskill queries)
    """
    lp = prompt.lower()
    s: Signals = detect_signals(lp)

    extras: list[str] = []

    # ── Skill file injections (mirrors Pi skillsOverride / model invocation) ──
    #
    # Each block loads the relevant SKILL.md and injects it as an extra context
    # block. Only injected when the signal fires — never all at once.

    # neuroskill-protocols — full guided-protocol repertoire
    if s["protocols"]:
        content = _load_skill("neuroskill-protocols")
        if content:
            extras.append(f"## 🧘 Protocol Repertoire\n{content}")

    # neuroskill-sleep — sleep command reference
    if s["sleep"]:
        content = _load_skill("neuroskill-sleep")
        if content:
            extras.append(f"## 📖 Sleep & UMAP Command Reference\n{content}")

    # neuroskill-sessions — session metrics and history commands
    if s["sessions"] or s["compare"]:
        content = _load_skill("neuroskill-sessions")
        if content:
            extras.append(f"## 📖 Sessions Command Reference\n{content}")

    # neuroskill-search — ANN search and A/B compare commands
    if s["compare"]:
        content = _load_skill("neuroskill-search")
        if content:
            extras.append(f"## 📖 Search & Compare Command Reference\n{content}")

    # neuroskill-labels — label creation and semantic search API
    if s["labels_api"]:
        content = _load_skill("neuroskill-labels")
        if content:
            extras.append(f"## 📖 Labels & Annotation API Reference\n{content}")

    # neuroskill-data-reference + METRICS.md — metric field definitions
    if s["metrics_ref"]:
        content = _load_skill("neuroskill-data-reference")
        if content:
            extras.append(f"## 📖 EXG Data Reference\n{content}")
        metrics = _load_metrics_md()
        if metrics:
            extras.append(f"## 📖 EXG Metrics & Indices Reference\n{metrics}")

    # neuroskill-status — status / device command details
    if s["session"]:
        content = _load_skill("neuroskill-status")
        if content:
            extras.append(f"## 📖 Status Command Reference\n{content}")

    # neuroskill-transport — WebSocket / HTTP transport, port discovery
    if s["transport"]:
        content = _load_skill("neuroskill-transport")
        if content:
            extras.append(f"## 📖 Transport & Connection Reference\n{content}")

    # neuroskill-streaming — live events, calibrate, notify, timer
    if s["streaming"]:
        content = _load_skill("neuroskill-streaming")
        if content:
            extras.append(f"## 📖 Streaming & Control Command Reference\n{content}")

    # neuroskill-recipes — scripting patterns, automation, code examples
    if s["scripting"]:
        content = _load_skill("neuroskill-recipes")
        if content:
            extras.append(f"## 📖 Scripting & Automation Recipes\n{content}")

    # ── Queue helpers ────────────────────────────────────────────────────────
    queue: list[tuple[str, list[str]]] = []

    def enqueue(label: str, *args: str) -> None:
        queue.append((label, list(args)))

    def search_labels(label: str, query: str, k: str = "5") -> None:
        enqueue(label, "search-labels", query, "--k", k)

    # ── Signal-driven neuroskill query selection ──────────────────────────────
    # Mirrors the TypeScript selectContextualData() task queue exactly.
    # Uses direct TypedDict key access: s["sleep"] rather than s.get("sleep").

    # 1. SLEEP
    if s["sleep"]:
        enqueue("Sleep Staging (last 24 h)", "sleep")
        search_labels(
            "Past Sleep Labels",
            "sleep tired rest deep sleep rem restoration drowsy",
        )

    # 3. DETAILED SESSION METRICS
    if (
        s["session"]    or s["sport"]      or s["learning"]   or s["social"]
        or s["dating"]  or s["family"]     or s["creative"]   or s["leadership"]
        or s["recovery"] or s["morning"]   or s["evening"]    or s["nutrition"]
        or s["therapy"] or s["goals"]      or s["performance"] or s["confidence"]
        or s["anger"]   or s["grief"]      or s["loneliness"] or s["addiction"]
    ):
        enqueue("Current Session Metrics", "session", "0")

    # 4. TRENDS & COMPARISON
    if s["compare"] or s["goals"]:
        cached = _get_fresh_compare()
        if cached:
            queue.append(("Session Comparison (last 2) — cached", []))
        else:
            warm_compare_in_background()

    # 5. SESSION HISTORY
    if s["sessions"]:
        enqueue("Session History", "sessions")

    # 6. FOCUS & PRODUCTIVITY
    if s["focus"]:
        enqueue("Current Session Metrics", "session", "0")
        search_labels(
            "Past Focus & Deep Work Labels",
            "deep focus work productivity flow state concentration locked in",
        )

    # 7. STRESS & BURNOUT
    if s["stress"]:
        enqueue("Current Session Metrics", "session", "0")
        search_labels(
            "Past Stress & Overwhelm Labels",
            "stress overwhelmed burnout pressure tense nervous anxious overloaded",
        )

    # 8. MEDITATION & MINDFULNESS
    if s["meditation"]:
        enqueue("Current Session Metrics", "session", "0")
        search_labels(
            "Past Meditation & Relaxation Labels",
            "meditation mindfulness calm relaxation breathing peace stillness grounded",
        )

    # 10. SOCIAL & NETWORKING
    if s["social"]:
        search_labels(
            "Past Social Interaction Labels",
            "social meeting people conversation team collaboration networking friends",
        )

    # 11. DATING & ROMANCE
    if s["dating"]:
        search_labels(
            "Past Romantic & Dating Labels",
            "romantic partner relationship date connection love intimacy attraction",
        )

    # 12. FAMILY & PARENTING
    if s["family"]:
        search_labels(
            "Past Family & Home Labels",
            "family children parenting home household spouse caregiving kids parent",
        )

    # 13. SPORTS & EXERCISE
    if s["sport"]:
        search_labels(
            "Past Exercise & Sport Labels",
            "exercise workout training sport running gym fitness athletic cardio strength",
        )

    # 14. LEARNING & EDUCATION
    if s["learning"]:
        search_labels(
            "Past Study & Learning Labels",
            "studying learning exam memorize reading concentration retention academic",
        )

    # 15. CREATIVITY
    if s["creative"]:
        search_labels(
            "Past Creative Work Labels",
            "creative art music writing design inspiration ideas innovation brainstorm",
        )

    # 16. LEADERSHIP & MANAGEMENT
    if s["leadership"]:
        search_labels(
            "Past Leadership & Management Labels",
            "leadership management decision making strategy team leading executive",
        )

    # 17. RECOVERY & REST DAYS
    if s["recovery"]:
        search_labels(
            "Past Recovery & Rest Labels",
            "recovery rest restoration recharge refresh downtime rejuvenate unwind",
        )

    # 18. MORNING ROUTINE
    if s["morning"]:
        search_labels(
            "Past Morning Routine Labels",
            "morning routine wake up coffee start of day fresh clarity rested",
        )

    # 19. EVENING & WIND-DOWN
    if s["evening"]:
        search_labels(
            "Past Evening & Wind-down Labels",
            "evening wind down end of day night routine relax calm bedtime",
        )

    # 20. NUTRITION & EATING
    if s["nutrition"]:
        search_labels(
            "Past Nutrition & Eating Labels",
            "food eating meal nutrition caffeine coffee tea fasting glucose brain fuel",
        )

    # 22. THERAPY & SELF-REFLECTION
    if s["therapy"]:
        search_labels(
            "Past Therapy & Reflection Labels",
            "therapy reflection introspection emotional processing journaling self-aware",
        )

    # 23. TRAVEL & JET LAG
    if s["travel"]:
        enqueue("Sleep Staging (last 24 h)", "sleep")
        search_labels(
            "Past Travel Labels",
            "travel jetlag timezone circadian rhythm body clock adjustment",
        )

    # 24. GOALS & HABIT TRACKING
    if s["goals"]:
        search_labels(
            "Past Goal & Habit Labels",
            "goal habit routine intention achievement milestone streak self-improvement",
        )

    # 26. ANGER & EMOTIONAL DYSREGULATION
    if s["anger"]:
        search_labels(
            "Past Anger & Frustration Labels",
            "anger frustrated irritable rage outburst tense reactive triggered emotional",
        )

    # 27. GRIEF & LOSS
    if s["grief"]:
        search_labels(
            "Past Grief & Loss Labels",
            "grief loss sad mourning bereavement sorrow heartbreak pain emotional",
        )

    # 28. LONELINESS & ISOLATION
    if s["loneliness"]:
        search_labels(
            "Past Loneliness & Isolation Labels",
            "lonely isolation alone disconnected withdrawn left out excluded belonging",
        )

    # 29. ADDICTION & CRAVINGS
    if s["addiction"]:
        search_labels(
            "Past Craving & Compulsion Labels",
            "craving urge compulsion addiction impulse scroll distraction temptation",
        )

    # 30. CONFIDENCE & SELF-ESTEEM
    if s["confidence"]:
        search_labels(
            "Past Confidence & Self-Esteem Labels",
            "confident self-esteem doubt insecure imposter capable proud accomplished",
        )

    # 31. HRV & CARDIAC / AUTONOMIC
    if s["hrv"]:
        enqueue("Current Session Metrics", "session", "0")
        search_labels(
            "Past HRV & Cardiac Labels",
            "heart rate HRV palpitation breathing chest autonomic cardiac coherence calm vagal",
        )

    # 32. SOMATIC & EMBODIMENT
    if s["somatic"]:
        enqueue("Current Session Metrics", "session", "0")
        search_labels(
            "Past Somatic & Body Sensation Labels",
            "somatic body sensation tension embodied grounded interoception gut feeling physical",
        )

    # 33. CONSCIOUSNESS & ALTERED STATES
    if s["consciousness"]:
        enqueue("Current Session Metrics", "session", "0")
        search_labels(
            "Past Consciousness & Awareness Labels",
            "consciousness awareness presence awakening ego dissolution lucid witness observer altered state",
        )

    # 34. PHILOSOPHY & INQUIRY
    if s["philosophy"]:
        enqueue("Current Session Metrics", "session", "0")
        search_labels(
            "Past Philosophy & Inquiry Labels",
            "philosophy meaning purpose wisdom truth inquiry virtue contemplation stoic existential",
        )

    # 35. EXISTENTIAL STATES
    if s["existential"]:
        enqueue("Current Session Metrics", "session", "0")
        search_labels(
            "Past Existential & Mortality Labels",
            "death mortality meaning existence purpose void impermanence legacy soul finitude",
        )

    # 36. DEPTH OF FEELING / INNER LIFE
    if s["depth"]:
        enqueue("Current Session Metrics", "session", "0")
        search_labels(
            "Past Deep Feeling & Inner Life Labels",
            "profound depth inner life soul contemplation moving stirred vast silence inward",
        )

    # 37. MORALS & ETHICS
    if s["morals"]:
        enqueue("Current Session Metrics", "session", "0")
        search_labels(
            "Past Moral & Ethical Labels",
            "ethics morals integrity conscience guilt shame regret duty right wrong dilemma values justice",
        )

    # 38. SYMBIOSIS & INTERCONNECTEDNESS
    if s["symbiosis"]:
        enqueue("Current Session Metrics", "session", "0")
        search_labels(
            "Past Symbiosis & Connection Labels",
            "symbiosis interconnected oneness unity interdependence harmony nature collective ecosystem belonging",
        )

    # 39. AWE & WONDER
    if s["awe"]:
        enqueue("Current Session Metrics", "session", "0")
        search_labels(
            "Past Awe & Wonder Labels",
            "awe wonder transcendence sublime sacred peak experience cosmic majestic beauty spiritual gratitude overwhelmed",
        )

    # 40. IDENTITY & SELF-DISCOVERY
    if s["identity"]:
        enqueue("Current Session Metrics", "session", "0")
        search_labels(
            "Past Identity & Self-Discovery Labels",
            "identity authentic self-concept who am I true self mask persona values-alignment self-expression discovery",
        )

    # ── Deduplicate by argument signature + cap label searches ───────────────
    # Mirrors TypeScript:
    #   const MAX_LABEL_SEARCHES = 5;
    #   const seen = new Set<string>();
    #   const unique = queue.filter(…)
    MAX_LABEL_SEARCHES = 5
    seen: set[str] = set()
    label_search_count = 0
    unique_queue: list[tuple[str, list[str]]] = []

    for label, args in queue:
        key = "\0".join(args)
        if key in seen:
            continue
        seen.add(key)
        if args and args[0] == "search-labels":
            if label_search_count >= MAX_LABEL_SEARCHES:
                continue
            label_search_count += 1
        unique_queue.append((label, args))

    # ── Execute all neuroskill tasks in parallel ──────────────────────────────

    async def run_task(label: str, args: list[str]) -> Optional[str]:
        if not args:
            # Zero-args sentinel: cached compare text injected directly.
            text = _get_fresh_compare()
            return f"### {label}\n{text}" if text else None
        result = await run_neuroskill(args)
        if result.ok and result.text:
            return f"### {label}\n{result.text}"
        return None

    results = await asyncio.gather(
        *(run_task(label, args) for label, args in unique_queue),
        return_exceptions=False,
    )

    return [*extras, *(r for r in results if r is not None)]
