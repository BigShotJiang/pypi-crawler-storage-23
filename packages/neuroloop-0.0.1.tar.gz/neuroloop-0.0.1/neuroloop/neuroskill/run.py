"""
neuroskill/run.py — high-level neuroskill command executor.

Translates CLI-style argument lists (e.g. ["search-labels", "focus", "--k", "5"])
to WebSocket JSON commands and sends them via the persistent SkillConnection.

This is the Python equivalent of the TypeScript runNeuroSkill() function, but
instead of spawning `npx neuroskill` as a subprocess it uses the neuroskill-dev
Python package's SkillClient directly over WebSocket/HTTP.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from typing import Any, Optional

from .client import SkillConnection

NEUROSKILL_TIMEOUT_S = 10.0
_TIMEOUT_MS = int(NEUROSKILL_TIMEOUT_S * 1000)


@dataclass
class NeuroSkillResult:
    ok: bool
    data: Any = field(default=None)
    text: Optional[str] = field(default=None)
    error: Optional[str] = field(default=None)


# ── Argument → WebSocket command translation ──────────────────────────────────

def _parse_flags(rest: list[str]) -> dict[str, Any]:
    """Extract --key value pairs from a positional arg list."""
    flags: dict[str, Any] = {}
    i = 0
    while i < len(rest):
        a = rest[i]
        if a.startswith("--") and i + 1 < len(rest):
            key = a[2:].replace("-", "_")  # --k-text → k_text
            val = rest[i + 1]
            try:
                flags[key] = int(val)
            except ValueError:
                try:
                    flags[key] = float(val)
                except ValueError:
                    flags[key] = val
            i += 2
        else:
            i += 1
    return flags


def _positionals(rest: list[str]) -> list[str]:
    """Return only non-flag arguments from a list."""
    out: list[str] = []
    skip = False
    for a in rest:
        if skip:
            skip = False
            continue
        if a.startswith("--"):
            skip = True
            continue
        out.append(a)
    return out


async def _get_session_range(conn: SkillConnection, index: int) -> tuple[int, int] | None:
    """Return (start_utc, end_utc) for session at `index` (0 = latest)."""
    resp = await conn.send({"command": "sessions"}, _TIMEOUT_MS)
    sessions: list[dict] = resp.get("sessions", []) if resp.get("ok") else []
    if not sessions or index >= len(sessions):
        return None
    s = sessions[index]
    return s["start_utc"], s["end_utc"]


async def _auto_ab_range(conn: SkillConnection) -> tuple[int, int, int, int]:
    """Return (a_start, a_end, b_start, b_end) from the two most recent sessions."""
    resp = await conn.send({"command": "sessions"}, _TIMEOUT_MS)
    sessions: list[dict] = resp.get("sessions", []) if resp.get("ok") else []
    if len(sessions) >= 2:
        a, b = sessions[1], sessions[0]
        return a["start_utc"], a["end_utc"], b["start_utc"], b["end_utc"]
    if len(sessions) == 1:
        s = sessions[0]
        mid = (s["start_utc"] + s["end_utc"]) // 2
        return s["start_utc"], mid, mid, s["end_utc"]
    now = int(time.time())
    return now - 7200, now - 3600, now - 3600, now


async def _auto_sleep_range(conn: SkillConnection) -> tuple[int, int]:
    """Return (start_utc, end_utc) covering recent sleep-relevant data."""
    resp = await conn.send({"command": "sessions"}, _TIMEOUT_MS)
    sessions: list[dict] = resp.get("sessions", []) if resp.get("ok") else []
    now = int(time.time())
    cutoff = now - 86400
    recent = [s for s in sessions if s["end_utc"] > cutoff]
    if recent:
        return recent[-1]["start_utc"], recent[0]["end_utc"]
    if sessions:
        s = sessions[0]
        return s["start_utc"], s["end_utc"]
    return now - 28800, now


# ── Main dispatcher ────────────────────────────────────────────────────────────

async def run_neuroskill(args: list[str]) -> NeuroSkillResult:
    """
    Translate CLI-style args to a WebSocket command, send it, and return the result.

    Examples:
        run_neuroskill(["status"])
        run_neuroskill(["session", "0"])
        run_neuroskill(["search-labels", "deep focus", "--k", "5"])
        run_neuroskill(["label", "entering flow", "--context", "..."])
        run_neuroskill(["notify", "Session done", "Well done!"])
        run_neuroskill(["compare"])
        run_neuroskill(["sleep"])
    """
    if not args:
        return NeuroSkillResult(ok=False, error="no command given")

    cmd = args[0].lower()
    rest = args[1:]
    flags = _parse_flags(rest)
    pos = _positionals(rest)
    conn = SkillConnection.get()

    try:
        ws_cmd: dict[str, Any]

        # ── status ────────────────────────────────────────────────────────
        if cmd == "status":
            ws_cmd = {"command": "status"}

        # ── sessions ──────────────────────────────────────────────────────
        elif cmd == "sessions":
            ws_cmd = {"command": "sessions"}

        # ── session [index] ───────────────────────────────────────────────
        elif cmd == "session":
            idx = int(pos[0]) if pos else 0
            r_sessions = await conn.send({"command": "sessions"}, _TIMEOUT_MS)
            lst: list[dict] = (
                r_sessions.get("sessions", []) if r_sessions.get("ok") else []
            )
            if not lst:
                return NeuroSkillResult(ok=False, error="no sessions recorded yet")
            if idx >= len(lst):
                return NeuroSkillResult(
                    ok=False,
                    error=f"session index {idx} out of range ({len(lst)} sessions)",
                )
            s = lst[idx]
            ws_cmd = {
                "command": "session_metrics",
                "start_utc": s["start_utc"],
                "end_utc": s["end_utc"],
            }

        # ── search-labels <query> [--k n] [--mode m] ──────────────────────
        elif cmd in ("search-labels", "search_labels"):
            query = pos[0] if pos else ""
            ws_cmd = {
                "command": "search_labels",
                "query": query,
                "k": flags.get("k", 10),
                "mode": flags.get("mode", "text"),
            }
            if "ef" in flags:
                ws_cmd["ef"] = flags["ef"]

        # ── interactive <keyword> ─────────────────────────────────────────
        elif cmd == "interactive":
            keyword = pos[0] if pos else ""
            ws_cmd = {
                "command": "interactive_search",
                "query": keyword,
                "k_text": flags.get("k_text", 5),
                "k_eeg": flags.get("k_eeg", 5),
                "k_labels": flags.get("k_labels", 3),
                "reach_minutes": flags.get("reach", 10),
            }

        # ── label <text> [--context "..."] [--at <utc>] ───────────────────
        elif cmd == "label":
            text = pos[0] if pos else ""
            ws_cmd = {"command": "label", "text": text}
            if "context" in flags:
                ws_cmd["context"] = flags["context"]
            if "at" in flags:
                ws_cmd["label_start_utc"] = int(flags["at"])

        # ── notify <title> [<body>] ───────────────────────────────────────
        elif cmd == "notify":
            title = pos[0] if pos else ""
            ws_cmd = {"command": "notify", "title": title}
            if len(pos) > 1:
                ws_cmd["body"] = pos[1]

        # ── say <text> [--voice <name>] ───────────────────────────────────
        elif cmd == "say":
            text = pos[0] if pos else ""
            ws_cmd = {"command": "say", "text": text}
            if "voice" in flags:
                ws_cmd["voice"] = flags["voice"]

        # ── compare ───────────────────────────────────────────────────────
        elif cmd == "compare":
            has_explicit = any(k in flags for k in ("a_start", "a_end", "b_start", "b_end"))
            if has_explicit:
                now = int(time.time())
                ws_cmd = {
                    "command": "compare",
                    "a_start_utc": flags.get("a_start", now - 7200),
                    "a_end_utc": flags.get("a_end", now - 3600),
                    "b_start_utc": flags.get("b_start", now - 3600),
                    "b_end_utc": flags.get("b_end", now),
                }
            else:
                a_s, a_e, b_s, b_e = await _auto_ab_range(conn)
                ws_cmd = {
                    "command": "compare",
                    "a_start_utc": a_s,
                    "a_end_utc": a_e,
                    "b_start_utc": b_s,
                    "b_end_utc": b_e,
                }

        # ── sleep [index] ─────────────────────────────────────────────────
        elif cmd == "sleep":
            if pos:
                idx = int(pos[0])
                rng = await _get_session_range(conn, idx)
                if rng is None:
                    return NeuroSkillResult(ok=False, error=f"session {idx} not found")
                start, end = rng
            elif "start" in flags and "end" in flags:
                start, end = int(flags["start"]), int(flags["end"])
            else:
                start, end = await _auto_sleep_range(conn)
            ws_cmd = {"command": "sleep", "start_utc": start, "end_utc": end}

        # ── search [--start u] [--end u] [--k n] ─────────────────────────
        elif cmd == "search":
            if "start" in flags and "end" in flags:
                start, end = int(flags["start"]), int(flags["end"])
            else:
                rng = await _get_session_range(conn, 0)
                now = int(time.time())
                start, end = rng if rng else (now - 600, now)
            ws_cmd = {
                "command": "search",
                "start_utc": start,
                "end_utc": end,
                "k": flags.get("k", 5),
            }

        # ── calibrate [--profile <name>] ──────────────────────────────────
        elif cmd == "calibrate":
            ws_cmd = {"command": "run_calibration"}
            if "profile" in flags:
                ws_cmd["profile"] = flags["profile"]

        # ── calibrations [list|get <id>] ──────────────────────────────────
        elif cmd == "calibrations":
            sub = pos[0] if pos else "list"
            if sub == "get" and len(pos) > 1:
                ws_cmd = {"command": "get_calibration", "id": int(pos[1])}
            else:
                ws_cmd = {"command": "list_calibrations"}

        # ── timer ─────────────────────────────────────────────────────────
        elif cmd == "timer":
            ws_cmd = {"command": "timer"}

        # ── umap ──────────────────────────────────────────────────────────
        elif cmd == "umap":
            # Kick off the job; we don't wait for completion (too slow for inline use)
            a_s, a_e, b_s, b_e = await _auto_ab_range(conn)
            ws_cmd = {
                "command": "umap",
                "a_start_utc": flags.get("a_start", a_s),
                "a_end_utc": flags.get("a_end", a_e),
                "b_start_utc": flags.get("b_start", b_s),
                "b_end_utc": flags.get("b_end", b_e),
            }

        # ── listen ────────────────────────────────────────────────────────
        elif cmd == "listen":
            seconds = int(flags.get("seconds", 5))
            if conn.is_connected and conn._client is not None:
                events = await conn._client.collect_events(seconds)
                text = json.dumps(events, indent=2)
                return NeuroSkillResult(ok=True, data=events, text=text)
            return NeuroSkillResult(
                ok=False, error="listen requires WebSocket (not connected)"
            )

        # ── raw <json> ────────────────────────────────────────────────────
        elif cmd == "raw":
            raw_json = pos[0] if pos else "{}"
            try:
                ws_cmd = json.loads(raw_json)
            except json.JSONDecodeError as exc:
                return NeuroSkillResult(ok=False, error=f"invalid JSON: {exc}")

        # ── fallback: send as-is ──────────────────────────────────────────
        else:
            ws_cmd = {"command": cmd}
            ws_cmd.update(flags)

        # ── Send ──────────────────────────────────────────────────────────
        timeout_ms = 60_000 if cmd in ("compare", "umap") else _TIMEOUT_MS
        response = await conn.send(ws_cmd, timeout_ms)

        if not isinstance(response, dict):
            return NeuroSkillResult(ok=False, error="unexpected response type")

        # Most commands return ok=True; some (like compare) omit "ok" entirely.
        if response.get("ok") is False:
            return NeuroSkillResult(ok=False, error=response.get("error", "server error"))

        # Human-readable summary for all commands (ANSI version for display;
        # the plain version is generated on demand by callers via format_response).
        from ..ui import format_response
        text = format_response(cmd, response, pos, ansi=True)

        return NeuroSkillResult(ok=True, data=response, text=text)

    except Exception as exc:
        return NeuroSkillResult(ok=False, error=str(exc))
