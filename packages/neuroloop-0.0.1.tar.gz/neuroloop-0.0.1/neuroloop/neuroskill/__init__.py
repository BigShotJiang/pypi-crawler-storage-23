"""neuroskill — public barrel for the neuroskill module.

Mirrors the TypeScript neuroskill/index.ts exports:

    export type { NeuroSkillResult } from "./run.ts";
    export { NEUROSKILL_TIMEOUT_MS, runNeuroSkill } from "./run.ts";
    export type { Signals } from "./signals.ts";
    export { any, detectSignals } from "./signals.ts";
    export { selectContextualData, warmCompareInBackground } from "./context.ts";

Also exports the skill file loaders that replace Pi's skillsOverride system:
    _load_skill(name)     — read skills/<name>/SKILL.md
    _load_metrics_md()    — read METRICS.md
"""

from .client import SkillConnection
from .run import NeuroSkillResult, NEUROSKILL_TIMEOUT_S, run_neuroskill
from .signals import Signals, detect_signals, any_match
from .context import (
    select_contextual_data,
    warm_compare_in_background,
    _load_skill,
    _load_metrics_md,
)

__all__ = [
    # client
    "SkillConnection",
    # run
    "NeuroSkillResult",
    "NEUROSKILL_TIMEOUT_S",
    "run_neuroskill",
    # signals
    "Signals",
    "detect_signals",
    "any_match",
    # context
    "select_contextual_data",
    "warm_compare_in_background",
    "_load_skill",
    "_load_metrics_md",
]
