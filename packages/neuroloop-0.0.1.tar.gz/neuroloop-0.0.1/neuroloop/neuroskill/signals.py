"""
neuroskill/signals.py — pure domain-signal detection.

`detect_signals` takes a lowercased prompt string and returns a `Signals`
TypedDict of every domain that was detected. No I/O, no side effects.

Mirrors the TypeScript signals.ts structure:

    export interface Signals { sleep: boolean; session: boolean; … }
    export function detectSignals(lp: string): Signals { … }

The `Signals` TypedDict provides the same static-type guarantees as the
TypeScript interface — callers use ``s["sleep"]`` directly (no `.get()` guard
needed) and type-checkers will flag unknown keys.
"""

from __future__ import annotations

import re
from typing import Union

try:
    from typing import TypedDict
except ImportError:
    from typing_extensions import TypedDict  # type: ignore[assignment]


# ── Signals TypedDict — mirrors TypeScript Signals interface ──────────────────

class Signals(TypedDict):
    """All detectable domain signals — each is True when the pattern fires."""

    # Core data commands
    sleep:    bool
    session:  bool
    compare:  bool
    sessions: bool

    # Lifestyle & productivity
    focus:      bool
    stress:     bool
    meditation: bool
    mood:       bool

    # Social & relational
    social:     bool
    dating:     bool
    family:     bool
    loneliness: bool
    grief:      bool
    anger:      bool
    confidence: bool

    # Health & body
    sport:     bool
    recovery:  bool
    nutrition: bool
    pain:      bool
    travel:    bool
    addiction: bool

    # Cardiac & somatic
    hrv:     bool
    somatic: bool

    # Mind & growth
    learning:    bool
    creative:    bool
    leadership:  bool
    therapy:     bool
    goals:       bool
    performance: bool

    # Daily rhythms
    morning: bool
    evening: bool

    # Inner life & depth
    consciousness: bool
    philosophy:    bool
    existential:   bool
    depth:         bool
    morals:        bool
    symbiosis:     bool
    awe:           bool
    identity:      bool

    # Protocol intent
    protocols: bool

    # Skill-load triggers (no TypeScript equivalent — Pi's model handled these)
    metrics_ref:  bool   # user asking what a metric/index/score means
    transport:    bool   # asking about connection, server, port, WebSocket
    scripting:    bool   # asking for scripting, automation, recipes
    labels_api:   bool   # asking about labelling API / search-labels
    streaming:    bool   # asking about live stream, calibrate, notify, timer


# ── any_match helper — mirrors TypeScript `any()` ────────────────────────────

def any_match(s: str, *patterns: Union[str, re.Pattern]) -> bool:  # type: ignore[type-arg]
    """Return True when any of the supplied regex patterns match s."""
    for p in patterns:
        if isinstance(p, str):
            p = re.compile(p)
        if p.search(s):
            return True
    return False


# ── Signal detector ───────────────────────────────────────────────────────────

def detect_signals(lp: str) -> Signals:
    """
    Detect which domains are relevant to the user's prompt.

    Parameters
    ----------
    lp:
        Lowercased prompt string.

    Returns
    -------
    Signals
        TypedDict with a bool for every detectable domain.
        Callers access values directly: ``s["sleep"]``, ``s["focus"]``, etc.
    """
    return Signals(

        # ── Core data commands ──────────────────────────────────────────────

        sleep=any_match(
            lp,
            r"\bsleep\b|\bslept\b|\bsleeping\b",
            r"\btired\b|\bfatigue[d]?\b|exhausted",
            r"\bnap(ping)?\b|drowsy|yawn|groggy",
            r"woke?\s*up|morning.{0,10}feel|can'?t\s+sleep|sleepy",
            r"nightmare|deep.?sleep|\brem\b|sleep.?quality",
            r"sleep.?cycle|sleep.?pattern|sleep.?stage|sleep.?disorder|sleep.?apnea",
            r"\binsomnia\b|\bnarcolep",
            r"bedtime|snooze|oversleep|under.?slept|night.?rest",
            r"restoration.{0,20}sleep|sleep.{0,20}restoration",
        ),

        session=any_match(
            lp,
            r"\bsession\b|right.?now\b|current.?state|how.?am.?i\b",
            r"my.?focus\b|my.?energy\b|my.?state\b|my.?metrics\b|my.?mood\b|my.?brain\b",
            r"\bEXG\b|biofeedback|brain.?state",
            r"cognitive.?load|engagement.?level|attention.?span",
            r"work.?session|study.?session|focus.?session|meditation.?session",
            r"stress.?level|anxiety.?level|relaxation.?level|mental.?state",
        ),

        compare=any_match(
            lp,
            r"\bcompare\b|session.?vs|before.?and.?after|a.?vs.?b",
            r"yesterday|previous.?session|last.?session|last.?week|last.?month",
            r"over.?time|\btrend(s)?\b|progress\b|improve(d|ment)?|declin(ed|e)?",
            r"better.?than|worse.?than|tracking\b|weekly\b|monthly\b",
            r"morning.?vs|night.?vs|early.?vs|compare.?session",
        ),

        sessions=any_match(
            lp,
            r"\bsessions\b|all.?sessions?|session.?list|session.?history",
            r"recording.?history|how.?many.?sessions?|timeline\b",
            r"when.?did.?i.{0,20}session|past.?sessions?|my.?history\b",
        ),

        # ── Lifestyle & productivity ─────────────────────────────────────────

        focus=any_match(
            lp,
            r"\bfocus(ed|ing)?\b|deep.?work|flow.?state|in.?the.?zone",
            r"productive?|concentrat(e|ion|ing)|distract(ed|ion)?",
            r"procrastinat|hyperfocus|locked.?in|absorb(ed)?\b",
            r"\btask\b.{0,20}\bwork\b|\bproject\b.{0,20}\bwork\b",
            r"office.?work|coding.?session|writing.?block|reading.?session",
            r"sustained.?attention|attentional?\b|willpower",
        ),

        stress=any_match(
            lp,
            r"\bstress(ed|ful|or)?\b|overwhelm(ed|ing)?|\bburnout\b|burnt.?out",
            r"\bpressure\b|\btense(ness)?\b|\bworr(y|ied|ying)\b|\bnervous(ness)?\b",
            r"\bpanic\b|overload(ed)?|frazzled|wound.?up|on.?edge",
            r"fight.?or.?flight|cortisol|adrenali|high.?strung|freak.?out",
            r"deadline.?stress|exam.?stress|work.?pressure|time.?pressure",
        ),

        meditation=any_match(
            lp,
            r"meditat(e|ing|ion)|mindful(ness)?|contemplat(e|ion)",
            r"\bcalm(ness)?\b|\brelax(ed|ing|ation)?\b|breath(e|ing|work)",
            r"\byoga\b|\bzen\b|peace(ful)?|tranquil|serenity|stillness",
            r"body.?scan|grounded(ness)?|present.?moment|vipassana",
            r"loving.?kindness|mantra|chanting|pranayama|tai.?chi",
            r"transcendental|non.?dual|open.?awareness|choiceless",
        ),

        mood=any_match(
            lp,
            r"\bmood\b|emotional?\s+(state|regulation|wellbeing)|affect\b|valence\b",
            r"\bsad(ness)?\b|\bhapp(y|iness)\b|\bjoy(ful)?\b|\bcontent(ment)?\b",
            r"\bexcited\b|\bhopeless\b|\bhopeful\b|melanchol",
            r"\banger\b|\bangry\b|\bfrustr(at|ation)\b|\birrit(able|ability)\b",
            r"\beuph(or|oria|ic)\b|\belat(ed|ion)\b|grateful|gratitude",
            r"feel(ing)?\s+(good|bad|great|terrible|amazing|awful|off|low)",
            r"low.?mood|uplifted|down.?in.{0,5}dumps|feeling.?off|emotionally",
            r"positive.?affect|negative.?affect|emotional.?state|mood.?shift",
        ),

        # ── Social & relational ──────────────────────────────────────────────

        social=any_match(
            lp,
            r"\bsocial(is|ize|ly|izing)?\b|\bnetwork(ing)?\b",
            r"\bconversation\b|\bmeeting\b|\binteract(ion|ing)?\b",
            r"\bcolleague\b|\bcoworker\b|\bteam\b|\bcollaborat",
            r"\bintrovert\b|\bextrovert\b|social.?energy|social.?battery",
            r"social.?anxiety|social.?fatigue|people.?drain|peopled.?out",
            r"\bcrowd\b|\bparty\b|\bgathering\b|\bgroup.?dynamic",
            r"\bfriend(ship|s)?\b.{0,20}(time|meet|hang|feel)",
            r"interpersonal|social.?skill|communication.?style",
            r"peer.?pressure|fitting.?in|belonging|loneliness|isolation",
        ),

        dating=any_match(
            lp,
            r"\bdat(e|ing)\b|\bromantic(ally)?\b|\bromance\b",
            r"\bpartner\b|\brelationship\b|\bcrush\b|\battraction\b",
            r"\blove\b|\bin.?love\b|first.?date|chemistry\b|\bcouple\b",
            r"\bintimacy\b|\bflirt(ing)?\b|\bheartbreak\b|\bbreakup\b|\bbreak.?up\b",
            r"girlfriend|boyfriend|significant.?other|soulmate|courting",
            r"anxious.{0,20}date|nervous.{0,20}date|date.{0,20}night",
            r"rejection|attachment.?style|love.?language|emotional.?intimacy",
        ),

        family=any_match(
            lp,
            r"\bfamily\b|\bfamilies\b|\bhousehold\b|home.?life\b",
            r"\bkids?\b|\bchildren\b|\bchild\b|\bbaby\b|\btoddler\b|\binfant\b",
            r"parent(ing|hood)?|\bmom\b|\bdad\b|\bmother\b|\bfather\b",
            r"\bsibling\b|\bbrother\b|\bsister\b|\bgrandparent\b|\bin.?law\b",
            r"caregiving|caregiver|work.?life.?balance|family.?stress",
            r"fatherhood|motherhood|raising.{0,10}kids?|nurturing\b",
            r"domestic|chores|homework.{0,10}kids?|parental.?burnout",
        ),

        loneliness=any_match(
            lp,
            r"\blonely\b|\bloneliness\b|\bisolated\b|\bisolation\b",
            r"feel.{0,10}alone\b|\bleft.?out\b|\bexcluded\b|\bbelong\b",
            r"social.?isolation|disconnected\b|withdrawn\b",
        ),

        grief=any_match(
            lp,
            r"\bgrief\b|\bgriev(e|ing|ed)\b|\bloss\b|\bbereavement\b",
            r"\bmourning\b|\bmourn(ing)?\b|\bsad.{0,15}loss",
            r"loved.?one.{0,15}(died|passed|death)|death\b.{0,15}(family|friend)",
        ),

        anger=any_match(
            lp,
            r"\banger\b|\brage\b|\bangry\b|\bfurious\b|\blivid\b",
            r"\birrit(able|ated|ability)\b|\bfrustr(ated|ation)\b",
            r"outburst\b|temper\b|snap(ped|ping)?\b|blow.?up\b",
            r"emotional.?dysregul|reactiv(e|ity)|triggered\b",
        ),

        confidence=any_match(
            lp,
            r"\bconfiden(t|ce)\b|\bself.?esteem\b|\bself.?worth\b",
            r"imposter.?syndrome|self.?doubt\b|\binsecure\b|\binsecurity\b",
            r"\bnot.?good.?enough\b|\bfake\b.{0,10}feel|doubt.{0,10}myself",
            r"low.?self.?esteem|self.?efficacy|self.?belief",
        ),

        # ── Health & body ────────────────────────────────────────────────────

        sport=any_match(
            lp,
            r"\bexercise\b|\bworkout\b|\btraining\b|\bathletic",
            r"\brun(ning|s)?\b|\bgym\b|\bsport\b|\bfitness\b",
            r"\byoga\b|\bswim(ming)?\b|\bcycl(e|ing|ist)\b",
            r"\blifting\b|strength.?train|endurance\b|\bcardio\b|\bhiit\b",
            r"\btennis\b|\bbasketball\b|\bfootball\b|\bsoccer\b|\brugby\b",
            r"martial.?arts|boxing\b|wrestling\b|climbing\b|crossfit",
            r"\bhik(e|ing)\b|trail.?run|outdoor.?sport|athletic.?performance",
            r"pre.?workout|post.?workout|sport.?recovery|physical.?training",
            r"\bvo2max\b|heart.?rate.?zone|lactic.?acid|muscle.?fatigue",
        ),

        recovery=any_match(
            lp,
            r"\brecover(y|ing)?\b|\brestoration\b|\brejuvenat\b",
            r"\brecharge\b|\brefresh\b|\breset\b|\bdowntime\b",
            r"rest.?day|day.?off|\bvacation\b|\bholiday\b|\bbreak\b.{0,15}need",
            r"\brecuperat\b|\bwind.?down\b|\bunwind\b|switch.?off",
        ),

        nutrition=any_match(
            lp,
            r"\beat(ing|s)?\b|\bmeal\b|\bfood\b|\bnutrition\b|\bdiet\b",
            r"\bcaffeine\b|\bcoffee\b|\btea\b|\bsugar\b|blood.?sugar",
            r"\bfasting\b|\blunch\b|\bdinner\b|\bbreakfast\b|\bsnack\b",
            r"brain.?food|glucose|intermittent.?fast|keto\b|vegan\b",
            r"hydrat|dehydrat|energy.?drink|nootropic|supplement\b",
        ),

        pain=any_match(
            lp,
            r"\bpain\b|\bhurt(ing)?\b|\bdiscomfort\b|\bache\b|\bsore\b",
            r"chronic.?pain|\binflammation\b|body.?tension|muscle.?tension",
            r"back.?pain|neck.?pain|shoulder.?pain|jaw.?tension",
            r"tension.?headache|cluster.?headache|sinus.?pain",
        ),

        travel=any_match(
            lp,
            r"\btravel(ling|led|er)?\b|\bjet.?lag\b|time.?zone\b|circadian",
            r"long.?flight|international.?travel|travel.?fatigue",
            r"adjust.{0,15}timezone|body.?clock|sleep.{0,15}travel",
        ),

        addiction=any_match(
            lp,
            r"\baddiction\b|\baddicted\b|\bcraving(s)?\b|\bcompulsive\b",
            r"\bsubstance\b|\balcohol\b.{0,20}(use|abuse|probl)",
            r"\bsmok(e|ing)\b|\bnicotine\b|\bvaping\b|\bgambling\b",
            r"social.?media.{0,15}addict|doom.?scroll|phone.?addict",
        ),

        # ── Cardiac & somatic ────────────────────────────────────────────────

        hrv=any_match(
            lp,
            r"\bhrv\b|\bheart.?rate.?variab|\brmssd\b|\bsdnn\b|\bpnn50\b",
            r"\bheart\b.{0,20}(rate|beat|palpitat|racing|pounding|flutter|skip|pound)",
            r"\bpalpitation(s)?\b|\bheart.?flutter\b|\bskipped?.?beat\b",
            r"\bbreath(ing)?\b.{0,15}(fast|shallow|heavy|tight|short|racing|rapid)",
            r"\bchest\b.{0,10}(tight|constrict|heavy|flutter|ache|pain|pressure)",
            r"\bautonomic\b|\bvagal\b|\bvagus\b|\bparasympathetic\b|\bsympathetic.?nervous\b",
            r"\bcardiac\b|\bcardiovascular\b|\bheartbeat\b|\bpulse\b.{0,10}(feel|notice|fast|slow)",
            r"racing.{0,10}heart|heart.{0,10}racing|heart.{0,5}(fast|slow|skip|pound)",
            r"\bbreath.?work\b|\bbreathing.?exercise\b|\bwim.?hof\b|\bbox.?breath\b",
            r"\b4.?7.?8\b|\bnasal\b.{0,10}breath|\bdiaphragm(atic)?\b",
            r"lf.?hf|lf.hf.?ratio|heart.?coherence|cardiac.?coherence",
        ),

        somatic=any_match(
            lp,
            r"\bsomatic\b|\bembodiment\b|\bembodied\b|\bbodily\b",
            r"body.?(sensati|aware|feel|scan|tension|wisdom|intelligence)",
            r"feel.{0,10}(in|through|inside|within|throughout).{0,10}body",
            r"\binteroception\b|\bgut.?feeling\b|\bgut.?instinct\b|\bgut.?sense\b",
            r"\btingling\b|\bnumbness\b|\bheaviness\b.{0,15}(body|limb|arm|leg|feeling)",
            r"\btension\b.{0,15}(in.?my|body|muscle|back|neck|shoulder|jaw|held)",
            r"\bstomach\b.{0,10}(knot|tight|flutter|sinking|drop|feeling)",
            r"\bbelly\b.{0,10}(feel|tight|drop|warmth|calm)|\bsolar.?plexus\b",
            r"warm(th)?.{0,10}(inside|chest|heart|belly)|cold.{0,10}(chill|inside|shiver)",
            r"\bgrounded\b.{0,15}body|\bfeel.{0,10}grounded\b|grounding.{0,10}body",
            r"\bsensation(s)?\b.{0,15}(notice|feel|body|physical|present)",
            r"physical.?sensati|felt.?sense\b|body.?mind\b|mind.?body\b",
        ),

        # ── Mind & growth ────────────────────────────────────────────────────

        learning=any_match(
            lp,
            r"\bstud(y|ying|ied)\b|\blearning\b|\bmemorize?\b",
            r"\bexam\b|\btest\b|\bquiz\b|\bhomework\b|\bassignment\b",
            r"\bclass\b|\bcourse\b|\bschool\b|\buniversit|\bcollege\b|\blecture\b",
            r"\brecall\b|\bretention\b|\bcomprehension\b|\beducation\b",
            r"\btutor(ing)?\b|\bcurriculum\b|\bacademic\b|\bsyllabus\b",
            r"\brevision\b|study.?session|exam.?prep|cram(ming)?",
            r"memory.?palace|spaced.?repetition|active.?recall|flashcard",
            r"reading.{0,20}book|textbook|lecture.?note|study.?note",
        ),

        creative=any_match(
            lp,
            r"\bcreat(ive|ivity|ing|or)\b|\barts?\b|\bartistic\b",
            r"\bmusic\b|\bcompos(e|ing|ition)\b|\bimprov(ise|isation)\b",
            r"\bwrit(e|ing|er|ers)\b|\bstorytel(l|ling)\b|\bpoem\b|\bpoetry\b",
            r"\bdesign\b|\bbrainstorm\b|\bimagine\b|\binspir(e|ation)\b",
            r"\bpaint(ing)?\b|\bdraw(ing)?\b|\bsculpt\b|\bsketch\b",
            r"\binvent\b|\binnovat\b|\bideate\b|\bideation\b",
            r"jam.?session|freestyle|creative.?block|makers?\b|\bcraft\b",
            r"creative.?flow|divergent.?thinking|lateral.?thinking",
        ),

        leadership=any_match(
            lp,
            r"\bleadership\b|\bleader\b|\bmanage(r|ment|rial)?\b|\bexecutive\b",
            r"decision.?making|\bstrategic?\b|\bvision(ary)?\b",
            r"\bnegotiat\b|\binfluence\b|\bpersuad\b|\bconflict.?resol",
            r"\bdelegate\b|\bprioritize?\b|\baccountab\b|\borganize?\b",
            r"team.?lead|leading.{0,10}team|leadership.?style|executive.?function",
            r"\bboss\b|\bmanager\b|\bboard\b|\bboardroom\b|c.?suite\b",
        ),

        therapy=any_match(
            lp,
            r"\btherapy\b|\btherapist\b|\bcounsell?ing\b|\bpsychologist\b",
            r"\bcbt\b|\bdbt\b|\bact\b.{0,20}therapy|psychotherapy",
            r"\bjournal(ing|led)?\b|\bself.?reflect\b|\bintrospect",
            r"mental.?health.{0,15}support|emotional.?support|process.{0,10}feel",
            r"trauma.?therapy|inner.?work|shadow.?work|self.?aware",
            r"emotional.?regulat|coping.?strategy|resilience\b",
        ),

        goals=any_match(
            lp,
            r"\bgoal(s)?\b|\bhabit(s)?\b|\broutine\b|\bintention(s)?\b",
            r"\btrack(ing)?\b.{0,20}progress|progress.{0,20}track",
            r"\bachieve(ment|ments)?\b|\bmilestone\b|\bstreak\b",
            r"behavior.?change|habit.?form|commit(ment)?|self.?discipl",
            r"self.?improvement|personal.?growth|kvr|okr|kpi",
        ),

        performance=any_match(
            lp,
            r"public.?speak|presentation\b|present.{0,10}(to|for|at)\b",
            r"stage.?fright|performance.?anxiety|\bpitch\b.{0,15}(to|for)",
            r"speak.?in.?front|\baudience\b|\bpresent(ing|ed)\b",
            r"interview.{0,10}(feel|nerv|anxious)|job.?interview",
            r"perform(ance|ing)?.{0,15}(state|anxiety|nerves?)",
        ),

        # ── Daily rhythms ────────────────────────────────────────────────────

        morning=any_match(
            lp,
            r"morning.?routine|wake.?up.?routine|start.?of.{0,5}day",
            r"\bcoffee\b.{0,15}morning|\bbreakfast\b|\bearly.?morning\b|\bdawn\b",
            r"first.?thing.{0,15}morning|beginning.{0,10}day|just.?woke",
            r"am.?routine|morning.?state|morning.?brain|morning.?focus",
        ),

        evening=any_match(
            lp,
            r"evening.?routine|wind.?down\b|end.?of.{0,5}day|bedtime.?routine",
            r"night.?time|late.?night|after.?dinner|nightcap\b",
            r"evening.?state|closing.?down|shutting.?off|winding.?down",
            r"pm.?routine|before.?bed|sleep.?prep|tonight.?feel",
        ),

        # ── Inner life & depth ───────────────────────────────────────────────

        consciousness=any_match(
            lp,
            r"\bconsciousness\b|\bself.?aware(ness)?\b|\binner.?observer\b",
            r"\bawaken(ed|ing)?\b|\benlighten(ed|ment)?\b|ego.?dissolut",
            r"\bpresence\b.{0,20}(state|moment|feel|awareness)|moment.?to.?moment",
            r"\bwitness\b.{0,15}(self|consciousness|awareness)|pure.?awareness",
            r"\blucid(ity)?\b|lucid.?dream|\baltere[d].?state\b",
            r"\bdissociat(e|ion|ing)\b|\bderealisat|depersonali",
            r"\bwakefulness\b|\blzc\b|lempel.?ziv|consciousness.?metric",
            r"\bnon.?dual(ity)?\b|advaita|not.?the.?thinker|observer.?effect",
            r"stream.?of.?consciousness|altered.?perception|heightened.?awareness",
        ),

        philosophy=any_match(
            lp,
            r"\bphilosoph(y|ical|er|ise|ize)?\b|\bwisdom\b|\bwisdom.?tradition\b",
            r"\bstoic(ism)?\b|\bepicur(ean|us)?\b|\bplatonist?\b|aristotl",
            r"\bnietzsche\b|\bcamus\b|\bsartre\b|\bheidegger\b|\bkant\b",
            r"\bexistentialis[mt]\b|\bnihilis[mt]\b|\babsurdis[mt]\b",
            r"\bfree.?will\b|\bdeterminis[mt]\b|\bfatalis[mt]\b",
            r"nature.?of.?reality|what.?is.?real|theory.?of.?mind",
            r"\bvirtue\b.{0,20}(ethic|life|moral)|nature.?of.?truth",
            r"\bdialect(ic|al)?\b|\bsocrat(ic|es)\b|\bphilosoph.{0,5}question",
            r"\bontolog(y|ical)\b|\bepistemolog(y|ical)\b|\bphenomenolog",
            r"\bparadox\b|\bthought.?experiment|mind.?body.?problem",
            r"happiness.{0,20}(real|true|mean|philosoph)|philosophy.?of.?life",
        ),

        existential=any_match(
            lp,
            r"\bmortalit(y|ies)\b|\bdeath\b|\bdie\b|\bdying\b|\bdead\b",
            r"\blegacy\b|\bimperman(ent|ence)\b|\bfinite\b|\binfinity\b",
            r"meaning.?of.?(life|existence)|purpose.?of.?(life|existence)",
            r"why.?(am|are).{0,5}(i|we).{0,10}(here|alive|exist)",
            r"\bwhat.?s.?the.?point\b|point.?of.?(life|all|it|this)",
            r"\bafterlife\b|\breincarnation\b|\bsoul\b.{0,10}(leave|death|die)",
            r"\bexistence\b.{0,20}(precede|mean|matter|anxi)|existential.?crisis",
            r"fear.?of.?death|aware.{0,10}mortal|contemplat.{0,10}death",
            r"\btransience\b|\bephemeral\b|nothing.?lasts|everything.?ends",
            r"\bvoid\b|\bnothingness\b|into.?the.?unknown|facing.?(end|death|nothing)",
        ),

        depth=any_match(
            lp,
            r"\bprofound(ly)?\b|\bdeeply?\b.{0,20}(feel|think|move|stir|touch)",
            r"\bcontemplat(e|ing|ion)\b|\bponder(ing)?\b|\bbrood(ing)?\b",
            r"inner.?life|inner.?world|soul.?search|depth.?of.?feel",
            r"\bstir(red)?\b.{0,15}(inside|deeply|soul)|moved.{0,15}deeply",
            r"\btouched\b.{0,15}(deeply|inside|heart|soul)",
            r"depth.?of.?thought|thinking.?deeply|going.?deep|deep.?inside",
            r"feel.{0,10}(something|it).{0,10}(deep|profound|big|vast|huge)",
            r"\bvast(ness)?\b.{0,15}feel|\bsilence\b.{0,15}(inside|within|feel)",
            r"\binward\b|\bwithin\b.{0,10}(look|turn|feel|find|search)",
        ),

        morals=any_match(
            lp,
            r"\bmoral(s|ity|ly)?\b|\bethic(s|al|ally)?\b|\bvirtue\b",
            r"\bintegrity\b|\bconscience\b|\bprinciple(s)?\b|\bhonesty\b",
            r"\bguilt\b|\bguilt(y|iness)\b|\bshame\b|\bshamed\b|\bregret\b",
            r"right.{0,5}wrong|wrong.{0,5}right|moral.?dilemma|ethical.?dilemma",
            r"\bduty\b|\bobligation\b|\bresponsib(le|ility)\b.{0,15}moral",
            r"did.{0,5}(the.?)?right.?thing|should.{0,5}(have|i)\b",
            r"\bhonour\b|\bhonor\b|\bwrongdoing\b|\bbetrayal\b|\bbetray",
            r"\bkind(ness)?\b.{0,20}(right|moral|ethic|compass)|compassion.{0,15}right",
            r"\bjustice\b|\bfairness\b|\binequality\b.{0,20}feel|treat.{0,10}fairly",
            r"acting.{0,10}(right|wrong|good|badly)|living.{0,10}(value|principle)",
        ),

        symbiosis=any_match(
            lp,
            r"\bsymbiosis\b|\bsymbiotic\b|\binterconnect(ed|edness|ion)?\b",
            r"\boneness\b|\bunity\b.{0,20}(feel|sense|all|everything|life)",
            r"\binterdependen(t|ce)\b|\bmutual(ism|ly)?\b",
            r"\bharmony\b.{0,20}(with|between|life|nature|all)",
            r"we.?are.?all.?(connected|one|linked|part)|everything.?is.?(connected|one)",
            r"\bnature\b.{0,20}(connected|harmony|part.?of|belong|oneness)",
            r"\bcollective\b.{0,20}(consciousness|wellbeing|good|mind)",
            r"part.?of.?(something.?bigger|the.?whole|nature|all|universe)",
            r"\becosystem\b|\bco.?exist(ence)?\b|\bcooperat\b.{0,20}life",
            r"relationship.{0,20}(with.?nature|all.?things|universe|world)",
            r"\bbelonging\b.{0,20}(universe|all|nature|life|cosmos)",
        ),

        awe=any_match(
            lp,
            r"\bawe\b|\bawe.?(struck|some|inspiring)?\b|\bwonder\b.{0,15}(feel|sense|fill)",
            r"\btranscenden(t|ce|tal)\b|\bsublime\b|\bsacred\b|\bholy\b.{0,15}feel",
            r"\bpeak.?experience\b|\bocean.?feeling\b|\bmystic(al)?\b",
            r"overwhelmed.{0,15}(beauty|vastness|universe|cosmos|nature)",
            r"\bmagical\b.{0,10}(feel|moment|experience|sense)|magic.{0,10}in.{0,10}(life|world)",
            r"\bcosmic\b|\buniverse\b.{0,20}(feel|connected|sense|part)",
            r"\bmajestic\b|\bbeauty\b.{0,15}(overwhelm|move|stir|profound)",
            r"sense.?of.?(wonder|awe|mystery|vastness|presence)|feeling.?of.?(awe|wonder)",
            r"\bspiritual(ity)?\b.{0,15}(feel|sense|experience|state)|felt.{0,10}spiritual",
            r"\bgratitude\b.{0,20}(all|universe|life|exist|cosmos)",
        ),

        identity=any_match(
            lp,
            r"\bidentity\b|\bself.?concept\b|\bself.?image\b|\bself.?discovery\b",
            r"who.{0,5}am.{0,5}i\b|who.{0,5}i.{0,5}(am|really|truly|actually)",
            r"\bauthentic(ity|ally)?\b|\btrue.?self\b|\breal.?self\b",
            r"be(ing)?.{0,10}(myself|yourself|oneself)|true.{0,10}(to.?myself|to.?oneself)",
            r"\bmask\b.{0,15}(wear|take.?off|behind)|taking.?off.{0,10}mask",
            r"\bpersona\b|\brole\b.{0,20}(play|wear|society|world)",
            r"sense.?of.?self|self.?expression\b|self.?concept\b",
            r"finding.{0,10}(myself|yourself|purpose|meaning.{0,10}(self|who))",
            r"values.{0,15}(align|match|live|compass|true)|living.{0,10}my.?values",
            r"\bcharacter\b.{0,15}(build|grow|true|who|define)|defining.{0,10}(who|myself)",
        ),

        # ── Protocol intent ──────────────────────────────────────────────────

        protocols=any_match(
            lp,
            r"\bprotocol\b|\bguided?\s+(exercise|practice|session|meditat|breath)",
            r"guide\s+(me|us)\s+(through|into|with)|walk\s+me\s+through",
            r"can\s+we\s+do\s+(a\s+)?(quick\s+)?(breath|relax|meditat|exercise|stretch|protocol)",
            r"help\s+me\s+(relax|calm\s+down|breathe|focus|sleep|unwind|de.?stress|reset)",
            r"\bneed\s+(to\s+)?(relax|calm|unwind|de.?stress|reset|breathe)\b",
            r"breath(e|ing)\s+(exercise|work|practice|with\s+me|together)",
            r"\bbox\s+breath|\b4.?7.?8\b|\bwim\s+hof\b|\bkapalabhati\b|\bnadi\s+shodhana\b",
            r"\bcardiac\s+coherence\b|\bcoherent\s+breath|\bphysiological\s+sigh\b",
            r"\bbody\s+scan\b|\bprogressive\s+muscle\b|\bpmr\b|\bnsdr\b|\byoga\s+nidra\b",
            r"\bloving.?kindness\b|\bmetta\b|\bmantra\s+meditat|\bopen\s+monitor",
            r"\bgrounding\s+exercise|\b5.?4.?3.?2.?1\b|\bsomatic\s+(exercise|practice|shake)",
            r"\bauogenic\s+train|\bhavening\b|\btre\b.{0,15}(exercise|tension|release)",
            r"\bneck\s+(exercise|stretch|pain|tension|stiff|sore|release|relief)",
            r"\beye\s+(exercise|strain|tired|fatigue|relief|stretch|rest)",
            r"\bshoulder\s+(exercise|stretch|roll|release|tension|pain|relief)",
            r"\bdesk\s+yoga|\bmotor\s+cortex|\bmind.?muscle\b",
            r"\bwarm.?up\b|\bcool.?down\b|\bstretch(ing)?\s+(routine|session|now)",
            r"something\s+(helpful|calming|relaxing|energising|to\s+help\s+with)",
            r"\bshow\s+me\s+(a|an|the|some)\s+(exercise|practice|technique|protocol|routine)",
            r"\bdo\s+(a|an)\s+(breathing|relaxation|meditation|grounding|stretching)\b",
            r"music\s+(for|to\s+help|therapy|that\s+will|to\s+focus|to\s+relax|to\s+sleep|to\s+calm)",
            r"what\s+(should|can)\s+i\s+eat|what\s+to\s+eat\b",
            r"\bmindful\s+eat|\beat(ing)?\s+(slowly|mindfully|habits?|better|healthier)",
            r"help\s+(me\s+)?(process|work\s+through|deal\s+with)\s+(this|anger|grief|stress|anxiety|emotion)",
        ),

        # ── Skill-load triggers ───────────────────────────────────────────────
        # In the TypeScript agent these are handled by Pi's model-based skill
        # invocation. In Python we detect them explicitly and inject the SKILL.md
        # (or METRICS.md) in select_contextual_data().

        metrics_ref=any_match(
            lp,
            # asking what a specific metric / index / band means
            r"what\s+(is|does|are).{0,30}\b(metric|score|index|band|ratio|measure|field)\b",
            r"\bexplain.{0,20}\b(metric|score|index|band|lzc|faa|tbr|bar|tar|apf|rmssd|sdnn|snr|pnn50|lf.?hf|rel_)\b",
            r"\bwhat.{0,10}(lzc|faa|tar|bar|tbr|apf|bps|pse|dtr|rmssd|sdnn|pnn50|lf_hf|hrv|snr|mu\b|pac\b|coherence)\b",
            r"\bwhat.{0,10}(delta|theta|alpha|beta|gamma).{0,10}(band|power|mean|value|range)\b",
            r"\b(stress_index|depression_index|anxiety_index|insomnia_index|wakefulness|lempel.?ziv|complexity)\b.{0,20}(mean|what|explain|value|range|how)",
            r"metric.{0,20}(reference|guide|meaning|definition|explanation)",
            r"(reference|lookup|look\s+up).{0,20}(metric|score|index|field|band)",
            r"\bhow\s+(is|are|do\s+you).{0,20}(calculate|compute|derive|measure).{0,20}(score|metric|index|band)",
            r"\bwhat\s+(range|values?|scale)\b.{0,30}(score|metric|index|band)",
        ),

        transport=any_match(
            lp,
            r"\b(connect(ion|ing|ed)?|disconnect|reconnect)\b.{0,20}(server|skill|exg|device|ws|websocket)",
            r"\b(websocket|web.?socket|ws://|http://|tunnel)\b",
            r"\b(port|8375|mdns|bonjour|discovery|discover)\b.{0,20}(server|skill|neuroskill|exg)",
            r"neuroskill.{0,20}(server|running|start|stop|connect)",
            r"(can.?t|cannot|unable).{0,20}(connect|reach|find).{0,20}(server|skill|neuroskill)",
            r"\b(transport|socket|http|fallback|proxy|tunnel)\b.{0,20}(mode|type|use|switch|fail)",
            r"server.{0,20}(not\s+running|offline|down|unreachable|unavailable)",
        ),

        scripting=any_match(
            lp,
            r"\b(script(ing)?|automat(e|ion)|cron|pipeline|batch)\b.{0,20}(neuroskill|exg|metric|session)",
            r"\b(python|node\.?js|bash|shell|curl|http\s+api|rest\s+api)\b.{0,20}(neuroskill|exg|query|fetch)",
            r"how\s+(do\s+i|to|can\s+i).{0,20}(use\s+neuroskill|query\s+exg|access\s+metrics)\b.{0,20}(from|in|with|via)",
            r"\b(integrate|integrate\s+with|hook.{0,10}up|pipe\s+into)\b.{0,20}(neuroskill|exg)",
            r"\b(recipe|example|snippet|sample\s+code|how.?to)\b.{0,20}(neuroskill|exg|metric)",
            r"neuroskill.{0,30}(from|using|with)\s+(python|node|bash|shell|script|code)",
        ),

        labels_api=any_match(
            lp,
            r"\bsearch.?labels?\b|\blabels?.?search\b|\bfind.?labels?\b|\blookup.?labels?\b",
            r"\b(interactive.?search|cross.?modal|graph.?search)\b",
            r"(how\s+(do\s+i|to|can\s+i)).{0,20}(create|add|write|make).{0,10}labels?",
            r"(label|annotation|mark).{0,20}(api|command|syntax|format|context\s+field)",
            r"\bsemantic.{0,25}(search|labels?|query)\b",
            r"search.?labels?.{0,20}(query|command|syntax|how|example)",
            r"(search|find|query).{0,20}(labels?|annotations?).{0,20}(semantic|vector|meaning|similar)",
        ),

        streaming=any_match(
            lp,
            r"\b(listen|stream|broadcast|real.?time|live\s+event)\b.{0,20}(neuroskill|exg|event|score|data)",
            r"\b(calibrat(e|ion)|calibration\s+profile|run.?calibration)\b",
            r"\b(notify|notification|os\s+alert|alert)\b.{0,20}(neuroskill|exg|send|trigger)",
            r"\b(timer|focus.?timer|countdown)\b.{0,20}(neuroskill|exg|set|start)",
            r"\b(raw\s+json|raw\s+command|arbitrary\s+command)\b.{0,20}(neuroskill|server|ws)",
            r"neuroskill.{0,20}(listen|notify|calibrate|timer|raw)\b",
        ),
    )
