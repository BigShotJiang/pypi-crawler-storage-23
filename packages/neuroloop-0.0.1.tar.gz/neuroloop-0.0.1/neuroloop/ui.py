"""
ui.py — Terminal UI for neuroloop-py.

Matches the TypeScript neuroloop visual layout exactly:

  Header  (printed once at startup — same brand, shortcuts, separator)
  Content (scrolls normally — rich Markdown)
  Footer  (live bottom toolbar via prompt_toolkit — EXG metrics + band bars + status bar)
  Input   (prompt_toolkit PromptSession with "neuroloop> " prompt)

Color mapping from TypeScript ThemeColor:
  success   → green   (\x1b[32m)
  warning   → yellow  (\x1b[33m)
  error     → red     (\x1b[31m)
  accent    → cyan    (\x1b[36m)
  syntaxType→ blue    (\x1b[34m)
  dim       → dim     (\x1b[2m)
  muted     → gray    (\x1b[90m)
"""

from __future__ import annotations

import os
import re
import sys
import time
from typing import Any, Optional

from prompt_toolkit.formatted_text import ANSI

from .prompts import NEUROLOOP_VERSION

# ── ANSI constants ────────────────────────────────────────────────────────────
R       = "\x1b[0m"
DIM     = "\x1b[2m"
BOLD    = "\x1b[1m"
GREEN   = "\x1b[32m"
YELLOW  = "\x1b[33m"
RED     = "\x1b[31m"
CYAN    = "\x1b[36m"
BLUE    = "\x1b[34m"
MAGENTA = "\x1b[35m"
GRAY    = "\x1b[90m"

BAR_FILLED = "█"
BAR_EMPTY  = "░"

# ── Helpers ───────────────────────────────────────────────────────────────────

_ANSI_RE = re.compile(r"\x1b\[[0-9;]*[mGKJHF]")


def vlen(s: str) -> int:
    """Visible length of a string (strips ANSI escape codes)."""
    return len(_ANSI_RE.sub("", s))


def term_width() -> int:
    try:
        return os.get_terminal_size().columns
    except OSError:
        return 80


def time_ago(ts: float) -> str:
    s = round(time.time() - ts)
    if s < 60:
        return f"{s}s ago"
    if s < 3600:
        return f"{s // 60}m ago"
    return f"{s // 3600}h ago"


def _score_color(val: float, higher_is_better: bool) -> str:
    norm = val if higher_is_better else 1 - val
    if norm >= 0.65:
        return GREEN
    if norm >= 0.35:
        return YELLOW
    return RED


def _hr_color(bpm: float) -> str:
    if 55 <= bpm <= 90:
        return GREEN
    if 45 <= bpm <= 110:
        return YELLOW
    return RED


def _band_bar(val: Optional[float], color: str, width: int = 10) -> str:
    if val is None:
        return f"{DIM}{BAR_EMPTY * width}{R}"
    filled = min(width, round(val * width * 3))
    empty = max(0, width - filled)
    return f"{color}{BAR_FILLED * filled}{R}{DIM}{BAR_EMPTY * empty}{R}"


# ── Status summary (mirrors TypeScript / neuroskill CLI human-readable output) ──

def _fmt_ts(ts: Any) -> str:
    """Format a UTC unix timestamp as a local time string."""
    try:
        import datetime
        dt = datetime.datetime.fromtimestamp(float(ts))
        return dt.strftime("%-d %b %Y  %H:%M")
    except Exception:
        return str(ts)


def _fmt_dur(secs: Any) -> str:
    try:
        s = int(secs)
        h, m, s = s // 3600, (s % 3600) // 60, s % 60
        parts = []
        if h:
            parts.append(f"{h}h")
        if m:
            parts.append(f"{m}m")
        if s or not parts:
            parts.append(f"{s}s")
        return " ".join(parts)
    except Exception:
        return str(secs)


def format_status_summary(r: dict, *, ansi: bool = True) -> str:
    """
    Render a neuroskill status JSON response as a human-readable summary.

    Mirrors the neuroskill CLI `_cmd_status` output (same sections, same layout).
    Set ansi=False to strip escape codes for use in LLM system prompts.
    """
    lines: list[str] = []

    def _c(code: str) -> str:
        return code if ansi else ""

    def ln(s: str = "") -> None:
        lines.append(s)

    # ── Device ────────────────────────────────────────────────────────────
    if r.get("device"):
        d = r["device"]
        state = d.get("state", "unknown")
        if ansi:
            state_col = GREEN if state == "connected" else (YELLOW if state == "connecting" else RED)
        else:
            state_col = ""
        try:
            bat = float(d.get("battery") or 0)
        except (TypeError, ValueError):
            bat = 0.0
        bat_col = _c(GREEN if bat >= 50 else (YELLOW if bat >= 20 else RED)) if ansi else ""

        ln()
        ln(f"  {_c(BOLD)}Device{_c(R)}")
        parts = [f"  {_c(DIM)}state:{_c(R)}    {_c(state_col)}{state}{_c(R)}"]
        if d.get("name"):
            parts.append(f"{_c(DIM)}name:{_c(R)} {_c(CYAN)}{d['name']}{_c(R)}")
        if d.get("battery") is not None:
            bat_val = d["battery"]
            bat_str = f"{bat_val:.0f}" if isinstance(bat_val, float) else str(bat_val)
            parts.append(f"{_c(DIM)}battery:{_c(R)} {bat_col}{bat_str}%{_c(R)}")
        if d.get("firmware"):
            parts.append(f"{_c(DIM)}firmware:{_c(R)} {_c(DIM)}{d['firmware']}{_c(R)}")
        ln("   ".join(parts))
        sample_parts = []
        if d.get("eeg_samples") is not None:
            sample_parts.append(f"EEG {_c(CYAN)}{d['eeg_samples']}{_c(R)}")
        if d.get("ppg_samples") is not None:
            sample_parts.append(f"PPG {_c(CYAN)}{d['ppg_samples']}{_c(R)}")
        if sample_parts:
            ln(f"  {_c(DIM)}samples:{_c(R)}  {'  '.join(sample_parts)}")

    # ── Session ───────────────────────────────────────────────────────────
    if r.get("session"):
        s = r["session"]
        ln()
        ln(f"  {_c(BOLD)}Session{_c(R)}")
        parts = [f"  {_c(DIM)}started:{_c(R)}  {_c(CYAN)}{_fmt_ts(s['start_utc'])}{_c(R)}"]
        if s.get("duration_secs") is not None:
            parts.append(f"{_c(DIM)}duration:{_c(R)} {_c(CYAN)}{_fmt_dur(s['duration_secs'])}{_c(R)}")
        if s.get("n_epochs") is not None:
            parts.append(f"{_c(DIM)}epochs:{_c(R)} {_c(CYAN)}{s['n_epochs']}{_c(R)}")
        ln("   ".join(parts))

    # ── Signal quality ────────────────────────────────────────────────────
    if r.get("signal_quality") is not None:
        _ELECTRODES = ("tp9", "af7", "af8", "tp10")
        q_raw = r["signal_quality"]

        def _to_f(v: Any) -> Optional[float]:
            try:
                return float(v) if v is not None else None
            except (TypeError, ValueError):
                return None

        if isinstance(q_raw, list):
            q_dict = {k: _to_f(v) for k, v in zip(_ELECTRODES, q_raw)}
        elif isinstance(q_raw, dict):
            q_dict = {k: _to_f(q_raw.get(k)) for k in _ELECTRODES}
        else:
            q_dict = {}

        def q_color(v: float) -> str:
            return _c(GREEN if v >= 0.9 else (YELLOW if v >= 0.7 else RED))

        parts = []
        for k in _ELECTRODES:
            v = q_dict.get(k)
            if v is not None:
                parts.append(f"{_c(DIM)}{k}:{_c(R)} {q_color(v)}{v*100:.0f}%{_c(R)}")
        if parts:
            ln()
            ln(f"  {_c(BOLD)}Signal Quality{_c(R)}")
            ln(f"  {'   '.join(parts)}")

    # ── Scores ────────────────────────────────────────────────────────────
    if r.get("scores"):
        sc = r["scores"]
        score_fields = [
            ("focus", "focus"), ("relaxation", "relaxation"), ("engagement", "engagement"),
            ("hr", "hr"), ("drowsiness", "drowsiness"), ("mood", "mood"),
            ("cognitive_load", "cog.load"), ("meditation", "meditation"),
        ]
        present = [(k, lbl) for k, lbl in score_fields if sc.get(k) is not None]
        if present:
            ln()
            ln(f"  {_c(BOLD)}Scores{_c(R)}")
            cols = 3
            for i in range(0, len(present), cols):
                row = present[i : i + cols]
                row_parts = []
                for k, lbl in row:
                    try:
                        v = float(sc[k])
                        vs = f"{v:.2f}" if v != int(v) else f"{int(v)}"
                    except (TypeError, ValueError):
                        vs = str(sc[k])
                    row_parts.append(f"{_c(DIM)}{lbl:<12}{_c(R)}{_c(CYAN)}{vs:>6}{_c(R)}")
                ln(f"  {'   '.join(row_parts)}")

    # ── EEG Bands ─────────────────────────────────────────────────────────
    bands = (r.get("scores") or {}).get("bands") or {}
    band_fields = [
        ("δ delta", "rel_delta"), ("θ theta", "rel_theta"), ("α alpha", "rel_alpha"),
        ("β beta", "rel_beta"),   ("γ gamma", "rel_gamma"),
    ]
    band_present = [(lbl, k) for lbl, k in band_fields if bands.get(k) is not None]
    if band_present:
        ln()
        ln(f"  {_c(BOLD)}EEG Bands{_c(R)}")
        cols = 3
        for i in range(0, len(band_present), cols):
            row = band_present[i : i + cols]
            row_parts = []
            for lbl, k in row:
                try:
                    row_parts.append(
                        f"{_c(DIM)}{lbl:<12}{_c(R)}{_c(CYAN)}{float(bands[k])*100:>6.1f}%{_c(R)}"
                    )
                except (TypeError, ValueError):
                    row_parts.append(f"{_c(DIM)}{lbl:<12}{_c(R)}{_c(CYAN)}{bands[k]}{_c(R)}")
            ln(f"  {'   '.join(row_parts)}")

    # ── Embeddings ────────────────────────────────────────────────────────
    if r.get("embeddings"):
        e = r["embeddings"]
        ln()
        ln(f"  {_c(BOLD)}Embeddings{_c(R)}")
        ln(
            f"  {_c(DIM)}today:{_c(R)} {_c(CYAN)}{e.get('today', 0)}{_c(R)}"
            f"   {_c(DIM)}total:{_c(R)} {_c(CYAN)}{e.get('total', 0)}{_c(R)}"
            f"   {_c(DIM)}recording days:{_c(R)} {_c(CYAN)}{e.get('recording_days', 0)}{_c(R)}"
        )

    # ── Labels ────────────────────────────────────────────────────────────
    if r.get("labels") is not None:
        lbl_data = r["labels"]
        if isinstance(lbl_data, dict):
            lbl_count = lbl_data.get("total", 0)
            recent: list = lbl_data.get("recent", [])
        else:
            lbl_count = lbl_data
            recent = []
        ln()
        ln(f"  {_c(BOLD)}Labels{_c(R)}  {_c(DIM)}({lbl_count} total){_c(R)}")
        if not recent:
            ln(f"  {_c(DIM)}no labels yet{_c(R)}")
        for lbl in recent:
            ln(
                f"  {_c(DIM)}#{lbl['id']}{_c(R)}"
                f"  {_c(GREEN)}\"{lbl['text']}\"{_c(R)}"
                f"  {_c(DIM)}{_fmt_ts(lbl['created_at'])}{_c(R)}"
            )

    # ── Calibration ───────────────────────────────────────────────────────
    if r.get("calibration") is not None:
        cal = r["calibration"]
        ln()
        ln(f"  {_c(BOLD)}Calibration{_c(R)}")
        if isinstance(cal, (int, float)):
            ln(f"  {_c(DIM)}last:{_c(R)} {_c(CYAN)}{_fmt_ts(int(cal))}{_c(R)}")
        elif isinstance(cal, dict):
            ts_raw = (
                cal.get("last_calibration_utc") or cal.get("last_utc")
                or cal.get("completed_at") or cal.get("timestamp")
                or cal.get("last") or cal.get("created_at")
            )
            if isinstance(ts_raw, (int, float)):
                ln(f"  {_c(DIM)}last:{_c(R)} {_c(CYAN)}{_fmt_ts(int(ts_raw))}{_c(R)}")
            if cal.get("name"):
                ln(f"  {_c(DIM)}profile:{_c(R)} {_c(CYAN)}{cal['name']}{_c(R)}")

    result = "\n".join(lines)
    if not ansi:
        result = _ANSI_RE.sub("", result)
    return result


# ── Per-command response formatters ──────────────────────────────────────────

def _arrow(direction: str, *, ansi: bool) -> str:
    if not ansi:
        return "↑" if direction == "up" else "↓" if direction == "down" else "→"
    return (f"{GREEN}↑{R}" if direction == "up"
            else f"{RED}↓{R}" if direction == "down"
            else f"{DIM}→{R}")


def format_sessions(r: dict, *, ansi: bool = True) -> str:
    """sessions — list of recording sessions."""
    lines: list[str] = []
    def _c(code: str) -> str: return code if ansi else ""
    def ln(s: str = "") -> None: lines.append(s)

    lst: list = r.get("sessions", [])
    ln(f"{_c(GREEN)}{len(lst)}{_c(R)} session(s)\n")
    for i, s in enumerate(lst):
        dur = _fmt_dur(s["end_utc"] - s["start_utc"])
        ln(f"  {_c(DIM)}[{i}]{_c(R)}  {_c(CYAN)}{s.get('day','')}{_c(R)}"
           f"  {_fmt_ts(s['start_utc'])}"
           f"  {_c(YELLOW)}{dur}{_c(R)}"
           f"  {_c(DIM)}{s.get('n_epochs', '?')} epochs{_c(R)}")
    result = "\n".join(lines)
    return _ANSI_RE.sub("", result) if not ansi else result


def format_session_metrics(r: dict, *, ansi: bool = True) -> str:
    """session_metrics — full metric breakdown with trends."""
    lines: list[str] = []
    def _c(code: str) -> str: return code if ansi else ""
    def ln(s: str = "") -> None: lines.append(s)

    m = r.get("metrics", {}) or {}
    f = r.get("first", {}) or {}
    sc = r.get("second", {}) or {}
    t = r.get("trends", {}) or {}

    def row(label: str, key: str, dec: int = 2, pct: bool = False) -> Optional[str]:
        avg = m.get(key)
        fv  = f.get(key)
        sv  = sc.get(key)
        if avg is None or (avg == 0 and fv == 0 and sv == 0):
            return None
        fmt = (lambda v: f"{v*100:.0f}%") if pct else (lambda v: f"{v:.{dec}f}")
        arr = _arrow(t.get(key, "flat"), ansi=ansi)
        delta = f"{_c(DIM)}({fmt(fv or 0)} → {fmt(sv or 0)}){_c(R)}"
        return (f"  {_c(DIM)}{label:<22}{_c(R)}"
                f"{_c(CYAN)}{fmt(avg):>7}{_c(R)}  {arr}  {delta}")

    def section(title: str, rows: list) -> None:
        valid = [r for r in rows if r is not None]
        if not valid:
            return
        ln(f"\n  {_c(BOLD)}{title}{_c(R)}")
        for line in valid:
            ln(line)

    section("Core Scores", [
        row("focus",          "focus"),
        row("relaxation",     "relaxation"),
        row("engagement",     "engagement"),
        row("meditation",     "meditation"),
        row("mood",           "mood"),
        row("cognitive load", "cognitive_load"),
        row("drowsiness",     "drowsiness"),
    ])
    section("PPG / Heart", [
        row("heart rate (bpm)",  "hr",               1),
        row("rmssd (ms)",        "rmssd",            1),
        row("sdnn (ms)",         "sdnn",             1),
        row("pnn50 (%)",         "pnn50",            1),
        row("lf/hf ratio",       "lf_hf_ratio",      2),
        row("resp. rate",        "respiratory_rate", 1),
    ])
    section("EEG Bands", [
        row("δ delta",  "rel_delta",      1, True),
        row("θ theta",  "rel_theta",      1, True),
        row("α alpha",  "rel_alpha",      1, True),
        row("β beta",   "rel_beta",       1, True),
        row("γ gamma",  "rel_gamma",      1, True),
    ])
    section("EEG Ratios", [
        row("FAA",             "faa",   3),
        row("theta/alpha",     "tar",   3),
        row("beta/alpha",      "bar",   3),
        row("theta/beta",      "tbr",   3),
        row("alpha peak (Hz)", "apf",   2),
        row("SNR (dB)",        "snr",   1),
    ])
    section("Motion", [
        row("stillness",       "stillness",        2),
        row("blinks",          "blink_count",      0),
        row("blink rate /min", "blink_rate",       1),
        row("jaw clenches",    "jaw_clench_count", 0),
    ])
    result = "\n".join(lines)
    return _ANSI_RE.sub("", result) if not ansi else result


def format_search_labels(r: dict, *, ansi: bool = True) -> str:
    """search-labels results."""
    lines: list[str] = []
    def _c(code: str) -> str: return code if ansi else ""
    def ln(s: str = "") -> None: lines.append(s)

    results = r.get("results", [])
    ln(f"  {_c(DIM)}model:{_c(R)}  {_c(CYAN)}{r.get('model','?')}{_c(R)}"
       f"   {_c(DIM)}results:{_c(R)} {_c(GREEN)}{r.get('count', len(results))}{_c(R)}\n")

    if not results:
        ln(f"  {_c(DIM)}no results{_c(R)}")
    for hit in results:
        sim = f"{hit.get('similarity', 0) * 100:.0f}%"
        ln(f"  {_c(BOLD)}#{hit.get('label_id')}{_c(R)}  {_c(GREEN)}\"{hit.get('text')}\"{_c(R)}")
        ln(f"     {_c(DIM)}similarity:{_c(R)} {_c(CYAN)}{sim}{_c(R)}"
           f"  {_c(DIM)}recorded:{_c(R)} {_fmt_ts(hit.get('created_at', 0))}")
        if hit.get("context"):
            preview = hit["context"][:100] + "…" if len(hit["context"]) > 100 else hit["context"]
            ln(f"     {_c(DIM)}context:{_c(R)} {preview}")
        eeg = hit.get("eeg_metrics") or {}
        parts = [f"{k} {_c(CYAN)}{eeg[k]:.2f}{_c(R)}"
                 for k in ("focus", "relaxation", "engagement", "hr", "mood") if k in eeg]
        if parts:
            ln(f"     {_c(DIM)}eeg:{_c(R)} {'  '.join(parts)}")
        ln()
    result = "\n".join(lines)
    return _ANSI_RE.sub("", result) if not ansi else result


def format_interactive(r: dict, *, ansi: bool = True) -> str:
    """interactive cross-modal search results."""
    lines: list[str] = []
    def _c(code: str) -> str: return code if ansi else ""
    def ln(s: str = "") -> None: lines.append(s)

    nodes: list = r.get("nodes", [])
    edges: list = r.get("edges", [])
    text_labels  = [n for n in nodes if n["kind"] == "text_label"]
    eeg_points   = [n for n in nodes if n["kind"] == "eeg_point"]
    found_labels = [n for n in nodes if n["kind"] == "found_label"]

    ln(f"\n  {_c(BOLD)}Graph{_c(R)}  {_c(CYAN)}{len(nodes)}{_c(R)} nodes · {_c(CYAN)}{len(edges)}{_c(R)} edges")

    if text_labels:
        ln(f"\n  {_c(BOLD)}Text Labels{_c(R)}")
        for n in text_labels:
            sim = (1 - n.get("distance", 1)) * 100
            when = f"  {_fmt_ts(n['timestamp_unix'])}" if n.get("timestamp_unix") else ""
            ln(f"  {_c(GREEN)}\"{n.get('text','?')}\"{_c(R)}{when}  {_c(DIM)}similarity: {sim:.0f}%{_c(R)}")
            eeg = n.get("eeg_metrics") or {}
            parts = [f"{k} {_c(CYAN)}{eeg[k]:.2f}{_c(R)}"
                     for k in ("focus","relaxation","engagement","hr") if isinstance(eeg.get(k),(int,float))]
            if parts: ln(f"    {'  '.join(parts)}")

    if eeg_points:
        ln(f"\n  {_c(BOLD)}EEG Moments{_c(R)}")
        for n in eeg_points:
            when = _fmt_ts(n["timestamp_unix"]) if n.get("timestamp_unix") else "?"
            ln(f"  {_c(CYAN)}{when}{_c(R)}  {_c(DIM)}dist: {n.get('distance',0):.4f}{_c(R)}")

    if found_labels:
        ln(f"\n  {_c(BOLD)}Nearby Labels{_c(R)}")
        for n in found_labels:
            when = _fmt_ts(n["timestamp_unix"]) if n.get("timestamp_unix") else "?"
            ln(f"  {_c(GREEN)}\"{n.get('text','?')}\"{_c(R)}  {_c(DIM)}{when}{_c(R)}")

    result = "\n".join(lines)
    return _ANSI_RE.sub("", result) if not ansi else result


def format_compare(r: dict, *, ansi: bool = True) -> str:
    """compare A/B insights."""
    lines: list[str] = []
    def _c(code: str) -> str: return code if ansi else ""
    def ln(s: str = "") -> None: lines.append(s)

    ins = r.get("insights") or {}
    if not ins:
        ln("(no insights returned)")
        return "\n".join(lines)

    ln(f"  {_c(BOLD)}Compare Insights{_c(R)}"
       f"  {_c(DIM)}({ins.get('n_epochs_a')} vs {ins.get('n_epochs_b')} epochs){_c(R)}")

    deltas = ins.get("deltas", {})
    if deltas:
        ln(f"\n  {'metric':<18} {'A':>8} {'B':>8} {'Δ':>8} {'Δ%':>7}  dir")
        ln(f"  {_c(DIM)}{'─'*60}{_c(R)}")
        for metric in ["focus","relaxation","engagement","meditation","hr",
                       "drowsiness","mood","snr","cognitive_load"]:
            d = deltas.get(metric)
            if not d:
                continue
            arr = _arrow(d.get("direction","flat"), ansi=ansi)
            dp  = d.get("pct", 0)
            pct_s = f"+{dp:.1f}%" if dp > 0 else f"{dp:.1f}%"
            ab  = d.get("abs", 0)
            ln(f"  {metric:<18} {_c(CYAN)}{(d.get('a') or 0):>8.2f}{_c(R)}"
               f" {_c(CYAN)}{(d.get('b') or 0):>8.2f}{_c(R)}"
               f" {('+' if ab >= 0 else '')}{ab:>7.2f} {pct_s:>7}  {arr}")

    if ins.get("improved"):
        ln(f"\n  {_c(GREEN)}▲ improved:{_c(R)} {', '.join(ins['improved'])}")
    if ins.get("declined"):
        ln(f"  {_c(RED)}▼ declined:{_c(R)} {', '.join(ins['declined'])}")

    result = "\n".join(lines)
    return _ANSI_RE.sub("", result) if not ansi else result


def format_sleep(r: dict, *, ansi: bool = True) -> str:
    """sleep staging summary."""
    lines: list[str] = []
    def _c(code: str) -> str: return code if ansi else ""
    def ln(s: str = "") -> None: lines.append(s)

    s = r.get("summary") or {}
    total = s.get("total_epochs", 0)
    eps   = s.get("epoch_secs", 5)

    def pct(n: int) -> str:
        return f" {_c(DIM)}({n / max(total, 1) * 100:.1f}%){_c(R)}"

    ln(f"  {_c(BOLD)}Sleep Summary{_c(R)}")
    ln(f"  {_c(DIM)}total:{_c(R)} {_c(CYAN)}{total}{_c(R)} epochs ({_c(CYAN)}{total*eps//60}{_c(R)} min)")
    ln(f"  {_c(GREEN)}Wake{_c(R)}  {s.get('wake_epochs',0)}{pct(s.get('wake_epochs',0))}")
    ln(f"  {_c(YELLOW)}N1{_c(R)}    {s.get('n1_epochs',0)}{pct(s.get('n1_epochs',0))}")
    ln(f"  {_c(BLUE)}N2{_c(R)}    {s.get('n2_epochs',0)}{pct(s.get('n2_epochs',0))}")
    ln(f"  {_c(MAGENTA)}N3{_c(R)}    {s.get('n3_epochs',0)}{pct(s.get('n3_epochs',0))}")
    ln(f"  {_c(RED)}REM{_c(R)}   {s.get('rem_epochs',0)}{pct(s.get('rem_epochs',0))}")

    a = r.get("analysis") or {}
    if a:
        ln(f"\n  {_c(BOLD)}Sleep Analysis{_c(R)}")
        if a.get("efficiency_pct")    is not None: ln(f"  {_c(DIM)}efficiency:{_c(R)}    {_c(CYAN)}{a['efficiency_pct']:.1f}%{_c(R)}")
        if a.get("onset_latency_min") is not None: ln(f"  {_c(DIM)}onset latency:{_c(R)} {_c(CYAN)}{a['onset_latency_min']:.1f}{_c(R)} min")
        if a.get("rem_latency_min")   is not None: ln(f"  {_c(DIM)}REM latency:{_c(R)}   {_c(CYAN)}{a['rem_latency_min']:.1f}{_c(R)} min")
        ln(f"  {_c(DIM)}transitions:{_c(R)} {_c(CYAN)}{a.get('transitions')}{_c(R)}"
           f"   {_c(DIM)}awakenings:{_c(R)} {_c(CYAN)}{a.get('awakenings')}{_c(R)}")
        sm = a.get("stage_minutes") or {}
        if sm:
            ln(f"\n  {_c(DIM)}Stage durations:{_c(R)} "
               f"Wake {_c(CYAN)}{sm.get('wake')}m{_c(R)}  "
               f"N1 {_c(CYAN)}{sm.get('n1')}m{_c(R)}  "
               f"N2 {_c(CYAN)}{sm.get('n2')}m{_c(R)}  "
               f"N3 {_c(CYAN)}{sm.get('n3')}m{_c(R)}  "
               f"REM {_c(CYAN)}{sm.get('rem')}m{_c(R)}")

    result = "\n".join(lines)
    return _ANSI_RE.sub("", result) if not ansi else result


def format_search(r: dict, *, ansi: bool = True) -> str:
    """ANN EEG-similarity search results."""
    lines: list[str] = []
    def _c(code: str) -> str: return code if ansi else ""
    def ln(s: str = "") -> None: lines.append(s)

    res = r.get("result", {}) or {}
    a   = res.get("analysis", {}) or {}
    all_nb = [n for q in res.get("results", []) for n in q.get("neighbors", [])]

    ln(f"  {_c(BOLD)}Search Results{_c(R)}")
    ln(f"  {_c(DIM)}query epochs:{_c(R)} {_c(CYAN)}{res.get('query_count')}{_c(R)}"
       f"   {_c(DIM)}total matches:{_c(R)} {_c(CYAN)}{len(all_nb)}{_c(R)}")

    ds = a.get("distance_stats") or {}
    if ds:
        sim = max(0, min(100, round((1 - ds.get("mean", 1)) * 100)))
        ln(f"\n  {_c(BOLD)}Match Quality{_c(R)}  similarity {_c(CYAN)}{sim}%{_c(R)}"
           f"   {_c(DIM)}dist mean={ds.get('mean')} σ={ds.get('stddev')}{_c(R)}")

    top = sorted(all_nb, key=lambda n: n.get("distance", 1))[:5]
    if top:
        ln(f"\n  {_c(BOLD)}Top Matches{_c(R)}")
        for i, n in enumerate(top):
            when = _fmt_ts(n.get("timestamp_unix", 0))
            d    = n.get("distance", 1)
            dist_c = _c(GREEN if d < 0.1 else (CYAN if d < 0.2 else YELLOW))
            met = n.get("metrics", {}) or {}
            parts = []
            for k in ("focus","relaxation","hr"):
                if met.get(k) is not None:
                    parts.append(f"{k} {_c(CYAN)}{met[k]:.2f}{_c(R)}")
            lbls = ", ".join(f'"{l["text"]}"' for l in (n.get("labels") or []) if isinstance(l, dict))
            ln(f"  #{i+1}  {_c(CYAN)}{when}{_c(R)}  dist {dist_c}{d:.4f}{_c(R)}"
               + (f"   {'  '.join(parts)}" if parts else "")
               + (f"   {_c(DIM)}{lbls}{_c(R)}" if lbls else ""))

    result = "\n".join(lines)
    return _ANSI_RE.sub("", result) if not ansi else result


def format_label(r: dict, text: str = "", *, ansi: bool = True) -> str:
    def _c(code: str) -> str: return code if ansi else ""
    s = f"  {_c(GREEN)}✓ labelled{_c(R)}  \"{text}\""
    if r.get("label_id"):
        s += f"  {_c(DIM)}#{r['label_id']}{_c(R)}"
    if r.get("created_at"):
        s += f"  {_c(DIM)}{_fmt_ts(r['created_at'])}{_c(R)}"
    return _ANSI_RE.sub("", s) if not ansi else s


def format_simple(cmd: str, r: dict, *, ansi: bool = True) -> str:
    """Generic one-liner for notify/say/calibrate/timer/etc."""
    def _c(code: str) -> str: return code if ansi else ""
    ok = r.get("ok", True)
    icon = f"{_c(GREEN)}✓{_c(R)}" if ok else f"{_c(RED)}✗{_c(R)}"
    detail = ""
    for key in ("spoken","title","body","message","profile","status","info"):
        if r.get(key):
            detail = f"  {_c(DIM)}{r[key]}{_c(R)}"
            break
    s = f"  {icon} {cmd}{detail}"
    return _ANSI_RE.sub("", s) if not ansi else s


# ── Central dispatcher ────────────────────────────────────────────────────────

def format_response(cmd: str, response: dict, args: list[str] | None = None,
                    *, ansi: bool = True) -> str:
    """
    Dispatch to the appropriate formatter for `cmd`.
    Falls back to JSON for unknown/raw commands.
    """
    import json as _json

    c = cmd.lower().replace("-", "_")

    if c == "status":
        return format_status_summary(response, ansi=ansi)
    if c in ("sessions",):
        return format_sessions(response, ansi=ansi)
    if c in ("session", "session_metrics"):
        return format_session_metrics(response, ansi=ansi)
    if c in ("search_labels", "search-labels"):
        return format_search_labels(response, ansi=ansi)
    if c == "interactive":
        return format_interactive(response, ansi=ansi)
    if c == "compare":
        return format_compare(response, ansi=ansi)
    if c == "sleep":
        return format_sleep(response, ansi=ansi)
    if c == "search":
        return format_search(response, ansi=ansi)
    if c == "label":
        text = (args[0] if args else "") if args else ""
        return format_label(response, text, ansi=ansi)
    if c in ("notify", "say", "calibrate", "timer", "list_calibrations",
             "get_calibration", "run_calibration"):
        return format_simple(cmd, response, ansi=ansi)

    # Fallback: pretty JSON
    text = _json.dumps(response, indent=2)
    return _ANSI_RE.sub("", text) if not ansi else text


# ── EXG metric parsing (mirrors TypeScript parseExgMetrics / mergeScoresEvent) ──

def parse_exg_metrics(response: dict) -> Optional[dict]:
    """Parse metrics from a full `status` response."""
    if not response.get("ok") and response.get("ok") is not None:
        return None

    def _is_live(resp: dict) -> bool:
        not_ready = {"scanning", "connecting", "disconnected"}
        device = resp.get("device") or {}
        state = device.get("state", "")
        return state not in not_ready

    if not _is_live(response):
        return None

    s = response.get("scores") or {}
    b = s.get("bands") or {}

    def n(v: Any) -> Optional[float]:
        try:
            return float(v) if v is not None else None
        except (TypeError, ValueError):
            return None

    return {
        "focus":          n(s.get("focus")),
        "cognitive_load": n(s.get("cognitive_load")),
        "relaxation":     n(s.get("relaxation")),
        "engagement":     n(s.get("engagement")),
        "drowsiness":     n(s.get("drowsiness")),
        "mood":           n(s.get("mood")),
        "hr":             n(s.get("hr")),
        "bands": {
            "rel_delta": n(b.get("rel_delta")),
            "rel_theta": n(b.get("rel_theta")),
            "rel_alpha": n(b.get("rel_alpha")),
            "rel_beta":  n(b.get("rel_beta")),
            "rel_gamma": n(b.get("rel_gamma")),
        },
    }


def merge_scores_event(prev: Optional[dict], ev: dict) -> dict:
    """
    Merge a `scores` broadcast event into the current metrics.
    The stream event is flat (no nested .scores/.bands) and omits slow-window
    fields (cognitive_load, drowsiness, mood) — kept from last snapshot.
    """
    if prev is None:
        prev = {}

    def n(v: Any) -> Optional[float]:
        try:
            return float(v) if v is not None else None
        except (TypeError, ValueError):
            return None

    pb = (prev.get("bands") or {})
    return {
        **prev,
        "focus":      n(ev.get("focus"))      or prev.get("focus"),
        "relaxation": n(ev.get("relaxation")) or prev.get("relaxation"),
        "engagement": n(ev.get("engagement")) or prev.get("engagement"),
        "hr":         n(ev.get("hr"))         or prev.get("hr"),
        "bands": {
            "rel_delta": n(ev.get("rel_delta")) or pb.get("rel_delta"),
            "rel_theta": n(ev.get("rel_theta")) or pb.get("rel_theta"),
            "rel_alpha": n(ev.get("rel_alpha")) or pb.get("rel_alpha"),
            "rel_beta":  n(ev.get("rel_beta"))  or pb.get("rel_beta"),
            "rel_gamma": n(ev.get("rel_gamma")) or pb.get("rel_gamma"),
        },
    }


# ── Header ────────────────────────────────────────────────────────────────────

def render_header(width: Optional[int] = None) -> str:
    """
    3-line header — same as TypeScript buildHeader():

      ◆ neuroloop v0.0.1
       [ctrl+d] quit  [ctrl+c] interrupt  [/exg] exg  [!] shell
      ────────────────────────────────────────────────────
    """
    w = width or term_width()

    # Row 1: brand
    logo = f"{CYAN}◆{R} {BOLD}neuroloop{R}{DIM} v{NEUROLOOP_VERSION}{R}"

    # Row 2: keyboard hints (same set as TypeScript, trimmed to fit Python context)
    hints: list[tuple[str, str]] = [
        ("ctrl+d",    "quit"),
        ("ctrl+c",    "interrupt"),
        ("/exg",      "exg"),
        ("/neuro",    "neuroskill"),
        ("/memory",   "memory"),
        ("/help",     "help"),
        ("!cmd",      "shell"),
    ]
    hint_parts = [
        f"{DIM}[{R}{GRAY}{k}{R}{DIM}]{R} {DIM}{v}{R}"
        for k, v in hints
    ]
    hints_line = " " + f"  ".join(hint_parts)

    # Row 3: separator
    sep_line = f"{DIM}{'─' * w}{R}"

    return f"{logo}\n{hints_line}\n{sep_line}"


# ── Footer / bottom toolbar ───────────────────────────────────────────────────

def render_footer(
    *,
    exg_enabled: bool,
    exg_online: bool,
    exg_metrics: Optional[dict],
    exg_updated_at: Optional[float],
    exg_last_label: Optional[dict],
    model: str,
    cwd: str,
) -> ANSI:
    """
    Render the multi-line bottom toolbar — mirrors TypeScript setFooter() exactly.

    Lines (when EXG connected):
      ─────────────────────────────────────────  (separator)
       focus 0.72   cog.load 0.45   relax 0.68   engage 0.71   drowsy 0.12   ♥ 68 bpm
       δ ███░░░░░░░   θ ████░░░░░░   α ██████░░░░   β ███░░░░░░░   γ ██░░░░░░░░      ⬡ "label"  5s ago
      /cwd                                    ◉ EXG 5s ago    qwen3:5b

    Lines (when EXG offline):
      /cwd                                    ◌ EXG    qwen3:5b
    """
    w = term_width()
    lines: list[str] = []

    # ── EXG metrics block (only when enabled + connected) ─────────────────────
    if exg_enabled and exg_online and exg_metrics:
        m = exg_metrics

        # Separator
        lines.append(f"{DIM}{'─' * w}{R}")

        # Scores row
        def sc(label: str, val: Optional[float], better: str) -> str:
            if val is None:
                return ""
            col = _score_color(val, better == "high")
            return f"{DIM}{label}{R} {col}{val:.2f}{R}"

        hr_part = ""
        if m.get("hr") is not None:
            hr_part = f"{DIM}♥ {R}{_hr_color(m['hr'])}{round(m['hr'])} bpm{R}"

        score_parts = [p for p in [
            sc("focus",    m.get("focus"),          "high"),
            sc("cog.load", m.get("cognitive_load"),  "low"),
            sc("relax",    m.get("relaxation"),      "high"),
            sc("engage",   m.get("engagement"),      "high"),
            sc("drowsy",   m.get("drowsiness"),      "low"),
            sc("mood",     m.get("mood"),            "high"),
            hr_part,
        ] if p]
        lines.append(" " + "   ".join(score_parts))

        # Band bars row
        bands = m.get("bands") or {}
        bar_parts = [
            f"{DIM}δ{R} {_band_bar(bands.get('rel_delta'), BLUE)}",
            f"{DIM}θ{R} {_band_bar(bands.get('rel_theta'), YELLOW)}",
            f"{DIM}α{R} {_band_bar(bands.get('rel_alpha'), GREEN)}",
            f"{DIM}β{R} {_band_bar(bands.get('rel_beta'),  RED)}",
            f"{DIM}γ{R} {_band_bar(bands.get('rel_gamma'), CYAN)}",
        ]
        bands_str = "   ".join(bar_parts)

        label_str = ""
        if exg_last_label:
            txt = exg_last_label.get("text", "")
            cat = float(exg_last_label.get("created_at", time.time()))
            label_str = f'{DIM}⬡ "{txt}"  {time_ago(cat)}{R}'

        bv = vlen(" " + bands_str)
        lv = vlen(label_str)
        gap = max(1, w - bv - lv)
        lines.append(f" {bands_str}{' ' * gap}{label_str}")

    # ── Status bar (always shown) ─────────────────────────────────────────────
    # Left: cwd
    cwd_display = cwd if vlen(cwd) <= 50 else "…" + cwd[-49:]
    left = f"{DIM}{cwd_display}{R}"

    # EXG indicator
    if exg_online:
        dot = f"{GREEN}◉{R}"
        ago = f" {DIM}{time_ago(exg_updated_at)}{R}" if exg_updated_at else ""
        exg_str = f"{dot} {DIM}EXG{R}{ago}"
    elif exg_enabled:
        exg_str = f"{DIM}◌ EXG{R}"
    else:
        exg_str = f"{DIM}◌ EXG off{R}"

    # Model name (strip provider prefix: "ollama/qwen3:5b" → "qwen3:5b")
    model_display = model.split("/")[-1] if "/" in model else model
    model_str = f"{DIM}{model_display}{R}"

    right = f"{exg_str}   {model_str}"
    gap = max(1, w - vlen(left) - vlen(right))
    lines.append(left + " " * gap + right)

    return ANSI("\n".join(lines))
