"""
memory.py — persistent agent memory backed by ~/.neuroskill/memory.md
"""

import os
from pathlib import Path
from typing import Optional

MEMORY_PATH = Path.home() / ".neuroskill" / "memory.md"


def read_memory(path: Path = MEMORY_PATH) -> Optional[str]:
    """Read the memory file. Returns None if it doesn't exist or is empty."""
    if not path.exists():
        return None
    content = path.read_text(encoding="utf-8").strip()
    return content if content else None


def write_memory(
    content: str,
    mode: str = "append",
    path: Path = MEMORY_PATH,
) -> None:
    """Write or append to the memory file, creating parent dirs as needed."""
    path.parent.mkdir(parents=True, exist_ok=True)

    if mode == "append":
        existing = path.read_text(encoding="utf-8") if path.exists() else ""
        sep = "\n" if existing and not existing.endswith("\n") else ""
        path.write_text(existing + sep + content, encoding="utf-8")
    else:
        path.write_text(content, encoding="utf-8")
