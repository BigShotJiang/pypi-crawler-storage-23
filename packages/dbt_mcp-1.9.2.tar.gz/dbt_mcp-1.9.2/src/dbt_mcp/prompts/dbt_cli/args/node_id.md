The node identifier. Can be either a node name (e.g., 'my_model', 'my_seed') or a fully qualified unique_id (e.g., 'model.my_project.my_model', 'seed.my_project.my_seed').
