library flet_onesignal;

export 'src/extension.dart' show Extension;
