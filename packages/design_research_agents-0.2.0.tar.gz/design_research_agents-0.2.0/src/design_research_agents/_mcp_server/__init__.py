"""Built-in MCP server package."""

from ._server import StdioMcpServer

__all__ = ["StdioMcpServer"]
