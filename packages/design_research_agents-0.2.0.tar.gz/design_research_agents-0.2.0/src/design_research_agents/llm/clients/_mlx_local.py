"""Internal MLX local client wrapper."""

from ._shared import MLXLocalLLMClient

__all__ = ["MLXLocalLLMClient"]
