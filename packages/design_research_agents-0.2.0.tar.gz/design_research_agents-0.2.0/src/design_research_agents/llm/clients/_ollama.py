"""Internal Ollama client wrapper."""

from ._shared import OllamaLLMClient

__all__ = ["OllamaLLMClient"]
