"""Stable facade exports for model selection."""

from __future__ import annotations

from ._selector import ModelSelector

__all__ = ["ModelSelector"]
