"""Internal runtime package for workflow and pattern execution helpers."""
