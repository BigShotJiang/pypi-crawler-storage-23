"""Delegate-step executor export."""

from ._common import run_delegate_step

__all__ = ["run_delegate_step"]
