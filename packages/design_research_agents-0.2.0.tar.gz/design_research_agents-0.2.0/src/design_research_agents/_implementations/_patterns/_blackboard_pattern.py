"""Dedicated module for the blackboard coordination pattern."""

from ._round_based_coordination_pattern import BlackboardPattern

__all__ = ["BlackboardPattern"]
