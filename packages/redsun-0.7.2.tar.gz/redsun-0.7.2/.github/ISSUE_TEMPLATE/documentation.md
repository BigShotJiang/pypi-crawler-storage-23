---
name: Documentation
about: Provide feedback for existing or new documentation
title: "[DOC] Documentation feedback"
labels: documentation
assignees: ''

---

**Before creating the issue**
- [ ] I already checked the documentation page and found not a solution to my question.

**What is missing?**
Tell us what you expected to find in the docs.

**How to address this?**
Suggest us ways to improve our documentation further.
