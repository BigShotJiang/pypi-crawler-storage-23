# API reference

::: redsun.containers.components
    options:
      members:
        - device
        - presenter
        - view

::: redsun.containers.container.AppContainerMeta

::: redsun.containers.container.AppContainer

::: redsun.containers._config.AppConfig

::: redsun.containers._config.StorageConfig

::: redsun.qt.QtAppContainer
