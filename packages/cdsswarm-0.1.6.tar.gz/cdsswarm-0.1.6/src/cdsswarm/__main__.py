"""Allow running cdsswarm as `python -m cdsswarm`."""

from .cli import main  # pragma: no cover

main()  # pragma: no cover
