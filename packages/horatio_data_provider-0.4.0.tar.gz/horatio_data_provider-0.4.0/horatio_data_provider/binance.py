import httpx
import pandas as pd

from ._http import fetch_parquet
from ._query import CacheableQuery


class RawTradesQuery(CacheableQuery):
    def __init__(self, session: httpx.AsyncClient, base_url: str, token: str):
        super().__init__(session, base_url, {"token": token})

    async def fetch(self) -> pd.DataFrame:
        return await fetch_parquet(self._session, self._base_url + "/binance/raw_trades/read", self._body)


class OHLCVQuery(CacheableQuery):
    def __init__(self, session: httpx.AsyncClient, base_url: str, token: str, window: str):
        super().__init__(session, base_url, {"token": token, "window": window})

    async def fetch(self) -> pd.DataFrame:
        return await fetch_parquet(self._session, self._base_url + "/binance/ohlcv/read", self._body)


class BookDepthQuery(CacheableQuery):
    def __init__(self, session: httpx.AsyncClient, base_url: str, token: str):
        super().__init__(session, base_url, {"token": token})

    async def fetch(self) -> pd.DataFrame:
        return await fetch_parquet(
            self._session, self._base_url + "/binance/book_depth/read", self._body
        )


class OpenInterestQuery(CacheableQuery):
    def __init__(self, session: httpx.AsyncClient, base_url: str, token: str):
        super().__init__(session, base_url, {"token": token})

    async def fetch(self) -> pd.DataFrame:
        return await fetch_parquet(
            self._session, self._base_url + "/binance/open_interest/read", self._body
        )


class FundingRateQuery(CacheableQuery):
    def __init__(self, session: httpx.AsyncClient, base_url: str, token: str):
        super().__init__(session, base_url, {"token": token})

    async def fetch(self) -> pd.DataFrame:
        return await fetch_parquet(
            self._session, self._base_url + "/binance/funding_rate/read", self._body
        )


class LongShortRatiosQuery(CacheableQuery):
    def __init__(self, session: httpx.AsyncClient, base_url: str, token: str):
        super().__init__(session, base_url, {"token": token})

    async def fetch(self) -> pd.DataFrame:
        return await fetch_parquet(
            self._session, self._base_url + "/binance/long_short_ratios/read", self._body
        )


class BinanceNamespace:
    def __init__(self, session: httpx.AsyncClient, base_url: str):
        self._session = session
        self._base_url = base_url

    def raw_trades(self, token: str) -> RawTradesQuery:
        return RawTradesQuery(self._session, self._base_url, token)

    def ohlcv(self, token: str, window: str) -> OHLCVQuery:
        return OHLCVQuery(self._session, self._base_url, token, window)

    def book_depth(self, token: str) -> BookDepthQuery:
        return BookDepthQuery(self._session, self._base_url, token)

    def open_interest(self, token: str) -> OpenInterestQuery:
        return OpenInterestQuery(self._session, self._base_url, token)

    def funding_rate(self, token: str) -> FundingRateQuery:
        return FundingRateQuery(self._session, self._base_url, token)

    def long_short_ratios(self, token: str) -> LongShortRatiosQuery:
        return LongShortRatiosQuery(self._session, self._base_url, token)

    async def flush_raw_trades(self, token: str | None = None) -> None:
        body = {}
        if token is not None:
            body["token"] = token
        await self._session.post(self._base_url + "/binance/raw_trades/flush", json=body)

    async def flush_ohlcv(self, token: str | None = None, window: str | None = None) -> None:
        body = {}
        if token is not None:
            body["token"] = token
        if window is not None:
            body["window"] = window
        await self._session.post(self._base_url + "/binance/ohlcv/flush", json=body)

    async def flush_exchange(
        self, endpoint: str | None = None, token: str | None = None
    ) -> None:
        body = {}
        if endpoint is not None:
            body["endpoint"] = endpoint
        if token is not None:
            body["token"] = token
        await self._session.post(self._base_url + "/binance/exchange/flush", json=body)
