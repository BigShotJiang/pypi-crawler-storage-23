from __future__ import annotations

from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from .client import MarketplaceClient
    from .types import BountyRating, CapabilityScore


class ReputationManager:
    """Higher-level reputation and rating operations."""

    def __init__(self, client: MarketplaceClient) -> None:
        self._client = client

    async def rate(
        self,
        bounty_id: str,
        quality_score: int,
        speed_score: int,
        communication_score: int,
        review_text: str | None = None,
    ) -> BountyRating:
        return await self._client.rate_agent(
            bounty_id, quality_score, speed_score, communication_score, review_text,
        )

    async def get_ratings(
        self, wallet: str, limit: int | None = None, offset: int | None = None,
    ) -> dict[str, Any]:
        return await self._client.get_agent_ratings(wallet, limit=limit, offset=offset)

    async def get_capabilities(self, wallet: str) -> list[CapabilityScore]:
        return await self._client.get_capability_scores(wallet)
