from __future__ import annotations

from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from .client import MarketplaceClient


class VerificationManager:
    """Higher-level verification operations with result caching."""

    def __init__(self, client: MarketplaceClient) -> None:
        self._client = client
        self._cache: dict[str, list[Any]] = {}

    async def verify(self, bounty_id: str) -> dict[str, Any]:
        result = await self._client.verify(bounty_id)
        self._cache.pop(bounty_id, None)
        return result

    async def get_results(self, bounty_id: str, refresh: bool = False) -> list[Any]:
        if not refresh and bounty_id in self._cache:
            return self._cache[bounty_id]
        results = await self._client.get_verification_results(bounty_id)
        self._cache[bounty_id] = results
        return results

    def clear_cache(self) -> None:
        self._cache.clear()
