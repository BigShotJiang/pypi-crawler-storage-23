from __future__ import annotations

from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from .client import MarketplaceClient
    from .types import Workspace


class WorkspaceManager:
    """Higher-level workspace operations with local caching."""

    def __init__(self, client: MarketplaceClient) -> None:
        self._client = client
        self._cache: dict[str, Workspace] = {}

    async def create(self, *, name: str, **kwargs: Any) -> Workspace:
        ws = await self._client.create_workspace(name=name, **kwargs)
        self._cache[ws.id] = ws
        return ws

    async def get(self, workspace_id: str, refresh: bool = False) -> Workspace:
        if not refresh and workspace_id in self._cache:
            return self._cache[workspace_id]
        ws = await self._client.get_workspace(workspace_id)
        self._cache[ws.id] = ws
        return ws

    async def list(self) -> list[Workspace]:
        workspaces = await self._client.list_workspaces()
        for ws in workspaces:
            self._cache[ws.id] = ws
        return workspaces

    async def add_agent(self, workspace_id: str, agent_wallet: str) -> None:
        await self._client.add_agent(workspace_id, agent_wallet)
        self._cache.pop(workspace_id, None)

    def clear_cache(self) -> None:
        self._cache.clear()
