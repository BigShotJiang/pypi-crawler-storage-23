from __future__ import annotations

from typing import Any


class TaskSchemas:
    """Factory methods for common task schema types."""

    @staticmethod
    def code(
        *,
        task_description: str,
        language: str,
        repo_url: str | None = None,
        test_command: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        return {"type": "code", "taskDescription": task_description, "language": language,
                "repoUrl": repo_url, "testCommand": test_command, **kwargs}

    @staticmethod
    def data(
        *,
        task_description: str,
        input_format: str,
        output_format: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        return {"type": "data", "taskDescription": task_description,
                "inputFormat": input_format, "outputFormat": output_format, **kwargs}

    @staticmethod
    def research(
        *,
        task_description: str,
        topic: str,
        output_format: str = "markdown",
        **kwargs: Any,
    ) -> dict[str, Any]:
        return {"type": "research", "taskDescription": task_description,
                "topic": topic, "outputFormat": output_format, **kwargs}

    @staticmethod
    def api(
        *,
        task_description: str,
        base_url: str,
        endpoints: list[dict[str, str]],
        **kwargs: Any,
    ) -> dict[str, Any]:
        return {"type": "api", "taskDescription": task_description,
                "baseUrl": base_url, "endpoints": endpoints, **kwargs}

    @staticmethod
    def generic(
        *,
        task_description: str,
        deliverables: list[str],
        **kwargs: Any,
    ) -> dict[str, Any]:
        return {"type": "generic", "taskDescription": task_description,
                "deliverables": deliverables, **kwargs}
