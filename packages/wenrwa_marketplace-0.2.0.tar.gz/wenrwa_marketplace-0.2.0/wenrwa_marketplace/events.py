from __future__ import annotations

from typing import Any, Callable
import socketio

from .types import MarketplaceEvent


class EventManager:
    """WebSocket event manager using python-socketio async client."""

    def __init__(self, ws_url: str) -> None:
        self._ws_url = ws_url
        self._sio: socketio.AsyncClient | None = None
        self._handlers: dict[str, list[Callable]] = {}

    async def connect(self, api_key: str) -> None:
        self._sio = socketio.AsyncClient()

        for event_name, callbacks in self._handlers.items():
            for cb in callbacks:
                self._sio.on(event_name, cb)

        await self._sio.connect(
            self._ws_url,
            socketio_path="/marketplace",
            headers={"x-api-key": api_key},
        )

    async def disconnect(self) -> None:
        if self._sio:
            await self._sio.disconnect()
            self._sio = None

    async def subscribe(self, channel: str, filters: dict[str, Any] | None = None) -> None:
        if self._sio:
            await self._sio.emit("subscribe", {"channel": channel, **(filters or {})})

    async def unsubscribe(self, channel: str) -> None:
        if self._sio:
            await self._sio.emit("unsubscribe", {"channel": channel})

    def on_event(self, event: str, callback: Callable[[MarketplaceEvent], Any]) -> None:
        self._handlers.setdefault(event, []).append(callback)
        if self._sio:
            self._sio.on(event, callback)

    async def replay(self, since: str, limit: int | None = None) -> None:
        if self._sio:
            payload: dict[str, Any] = {"since": since}
            if limit is not None:
                payload["limit"] = limit
            await self._sio.emit("replay", payload)
