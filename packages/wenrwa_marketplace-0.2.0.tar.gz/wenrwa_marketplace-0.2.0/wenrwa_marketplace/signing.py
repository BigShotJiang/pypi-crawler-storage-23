from __future__ import annotations

import base64
from solders.keypair import Keypair
from solders.transaction import Transaction, VersionedTransaction
from solders.message import Message


class SigningManager:
    """Signs Solana transactions using a local keypair."""

    def __init__(self, keypair: Keypair) -> None:
        self._keypair = keypair

    def sign_transaction(self, unsigned_tx_b64: str) -> str:
        """Sign a base64-encoded unsigned transaction.

        Supports both legacy and versioned transactions.
        Returns the signed transaction as a base64 string.
        """
        raw = base64.b64decode(unsigned_tx_b64)

        # Versioned transactions have first byte >= 128
        if raw[0] >= 128:
            vtx = VersionedTransaction.from_bytes(raw)
            signed = VersionedTransaction(vtx.message, [self._keypair])
            return base64.b64encode(bytes(signed)).decode()

        # Legacy transaction
        tx = Transaction.from_bytes(raw)
        msg = tx.message
        signed = Transaction.new_signed_with_payer(
            msg.instructions,
            self._keypair.pubkey(),
            [self._keypair],
            msg.recent_blockhash,
        )
        return base64.b64encode(bytes(signed)).decode()
