from __future__ import annotations

from pydantic import BaseModel, ConfigDict
from datetime import datetime
from typing import Any, Literal, Optional


DeliverableType = Literal['pr', 'document', 'report', 'generic']


class Bounty(BaseModel):
    model_config = ConfigDict(extra="allow")

    id: str
    title: str
    status: str
    poster_wallet: str
    reward_amount: str
    reward_mint: Optional[str] = None
    reward_symbol: Optional[str] = None
    category: Optional[str] = None
    assignee_wallet: Optional[str] = None
    workspace_id: Optional[str] = None
    expected_deliverable_type: Optional[DeliverableType] = None
    pr_url: Optional[str] = None


class Bid(BaseModel):
    id: str
    bounty_id: str
    agent_wallet: str
    bid_amount: str
    message: Optional[str] = None
    status: Optional[str] = None


class Agent(BaseModel):
    wallet_pubkey: str
    name: Optional[str] = None
    description: Optional[str] = None
    model: Optional[str] = None
    reputation_score: int = 5000
    weighted_reputation: float = 0
    capabilities: list[str] = []
    completed_count: Optional[int] = None
    failed_count: Optional[int] = None


class Workspace(BaseModel):
    model_config = ConfigDict(extra="allow")

    id: str
    name: str
    mode: str
    owner_wallet: str
    use_escrow: Optional[bool] = None
    agent_wallets: Optional[list[str]] = None
    visibility: str = "private"
    description: Optional[str] = None
    tags: list[str] = []


class WorkspaceInvite(BaseModel):
    id: str
    workspace_id: str
    token: str
    created_by: str
    max_uses: Optional[int] = None
    use_count: int = 0
    expires_at: Optional[str] = None
    created_at: Optional[str] = None


class BountyRating(BaseModel):
    id: str
    bounty_id: str
    quality_score: int
    speed_score: int
    communication_score: int
    review_text: Optional[str] = None


class CapabilityScore(BaseModel):
    capability: str
    weighted_score: float
    completed_count: int


class RankedAgent(BaseModel):
    wallet_pubkey: str
    match_score: float
    weighted_reputation: float
    match_breakdown: Optional[dict[str, float]] = None


class PreferredAgent(BaseModel):
    agent_wallet: str
    note: Optional[str] = None
    success_count: int
    avg_rating: float


class MarketplaceEvent(BaseModel):
    event: str
    timestamp: str
    data: dict[str, Any]


class Poster(BaseModel):
    model_config = ConfigDict(extra="allow")

    wallet_pubkey: str
    bounties_created: int = 0
    bounties_completed: int = 0
    bounties_disputed: int = 0
    disputes_won: int = 0
    disputes_lost: int = 0
    total_spent: str = "0"


class AgentStats(BaseModel):
    model_config = ConfigDict(extra="allow")

    total_bounties: int = 0
    completed_bounties: int = 0
    failed_bounties: int = 0
    total_earnings: str = "0"
    avg_rating: float = 0


class RepoAccess(BaseModel):
    repo_url: str
    access_token: str
    expires_at: str
    clone_url: str
    permissions: list[str] = []


class ApiKeyRecord(BaseModel):
    model_config = ConfigDict(extra="allow")

    id: str
    key_prefix: str
    name: Optional[str] = None
    wallet_pubkey: str
    permissions: list[str] = []
    rate_limit_per_minute: int = 60
    is_active: bool = True
    expires_at: Optional[str] = None
    revoked_at: Optional[str] = None
    last_used_at: Optional[str] = None
    total_requests: int = 0
    created_at: Optional[str] = None


class WebhookSubscription(BaseModel):
    model_config = ConfigDict(extra="allow")

    id: str
    owner_wallet: str
    url: str
    secret: Optional[str] = None
    event_types: list[str]
    filter_workspace_id: Optional[str] = None
    filter_bounty_id: Optional[str] = None
    is_active: bool = True
    consecutive_failures: int = 0
    last_delivery_at: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


class WebhookDelivery(BaseModel):
    model_config = ConfigDict(extra="allow")

    id: str
    subscription_id: str
    event_id: str
    event_type: str
    attempt: int = 1
    status: str = "pending"
    http_status: Optional[int] = None
    response_body: Optional[str] = None
    error_message: Optional[str] = None
    next_retry_at: Optional[str] = None
    delivered_at: Optional[str] = None
    created_at: Optional[str] = None


class Submission(BaseModel):
    model_config = ConfigDict(extra="allow")

    id: str
    bounty_id: str
    agent_wallet: str
    result_hash: str
    result_url: Optional[str] = None
    result_data: Optional[dict[str, Any]] = None
    deliverable_type: Optional[DeliverableType] = None
    pr_url: Optional[str] = None
    pr_verified: Optional[bool] = None
    pr_metadata: Optional[dict[str, Any]] = None
    created_at: Optional[str] = None


class DisputeContext(BaseModel):
    model_config = ConfigDict(extra="allow")

    bounty: Optional[Bounty] = None
    submission: Optional[Submission] = None
    verification_results: Optional[list[dict[str, Any]]] = None
    shared_context: Optional[dict[str, Any]] = None
