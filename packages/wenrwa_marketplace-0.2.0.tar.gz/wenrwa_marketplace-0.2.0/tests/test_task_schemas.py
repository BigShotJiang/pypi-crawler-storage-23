"""Tests for TaskSchemas factory methods."""
from wenrwa_marketplace.task_schemas import TaskSchemas


class TestTaskSchemas:
    def test_code_schema(self):
        schema = TaskSchemas.code(
            task_description="Build a REST API",
            language="python",
            repo_url="https://github.com/test/repo",
            test_command="pytest",
        )
        assert schema["type"] == "code"
        assert schema["taskDescription"] == "Build a REST API"
        assert schema["language"] == "python"
        assert schema["repoUrl"] == "https://github.com/test/repo"
        assert schema["testCommand"] == "pytest"

    def test_code_schema_minimal(self):
        schema = TaskSchemas.code(task_description="Fix a bug", language="typescript")
        assert schema["type"] == "code"
        assert schema["repoUrl"] is None

    def test_data_schema(self):
        schema = TaskSchemas.data(
            task_description="Process CSV",
            input_format="csv",
            output_format="json",
        )
        assert schema["type"] == "data"
        assert schema["inputFormat"] == "csv"
        assert schema["outputFormat"] == "json"

    def test_research_schema(self):
        schema = TaskSchemas.research(
            task_description="Research AI trends",
            topic="LLMs",
            output_format="markdown",
        )
        assert schema["type"] == "research"
        assert schema["topic"] == "LLMs"
        assert schema["outputFormat"] == "markdown"

    def test_research_schema_default_format(self):
        schema = TaskSchemas.research(
            task_description="Research something",
            topic="blockchain",
        )
        assert schema["outputFormat"] == "markdown"

    def test_api_schema(self):
        schema = TaskSchemas.api(
            task_description="Build endpoints",
            base_url="https://api.example.com",
            endpoints=[
                {"method": "GET", "path": "/users", "description": "List users"},
                {"method": "POST", "path": "/users", "description": "Create user"},
            ],
        )
        assert schema["type"] == "api"
        assert schema["baseUrl"] == "https://api.example.com"
        assert len(schema["endpoints"]) == 2

    def test_generic_schema(self):
        schema = TaskSchemas.generic(
            task_description="Do something",
            deliverables=["report.pdf", "data.json"],
        )
        assert schema["type"] == "generic"
        assert schema["deliverables"] == ["report.pdf", "data.json"]

    def test_extra_kwargs_pass_through(self):
        schema = TaskSchemas.code(
            task_description="Build",
            language="rust",
            custom_field="custom_value",
        )
        assert schema["custom_field"] == "custom_value"
