"""Doc-pac manage — offline enrichment for doc-pac cells.

Doc-pac cells have small sources (3-8 chunks) by design. No noise
filtering needed — every source is content, not a warmup or abort.
"""
