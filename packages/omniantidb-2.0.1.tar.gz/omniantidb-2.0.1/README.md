# OmniAnti — Windows 11 Edition

Advanced Real System Scanner — Antivirus for Windows 10 & 11.

## Install

```bash
pip install OmniAntidb
```

## Launch

```bash
omnianti
```

This will start the server and automatically open your browser to the OmniAnti dashboard.

## Features

- Real-time threat detection
- Process & network scanning
- Registry & startup checks
- Windows Defender status
- Secure Boot & TPM checks (Win11)
- File hash analysis
- Quarantine system
- Scan history database
