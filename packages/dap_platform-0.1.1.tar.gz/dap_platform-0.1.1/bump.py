import pathlib

# Bump version in pyproject.toml
pp = pathlib.Path("pyproject.toml")
txt = pp.read_text(encoding="utf-8")
txt = txt.replace('version = "0.1.0"', 'version = "0.1.1"', 1)
pp.write_text(txt, encoding="utf-8")

# Bump in __init__.py
init = pathlib.Path("src/dataaudit/__init__.py")
itxt = init.read_text(encoding="utf-8")
itxt = itxt.replace('0.1.0', '0.1.1')
init.write_text(itxt, encoding="utf-8")

print("Bumped to 0.1.1")
