import pathlib

# 1. pyproject.toml
pp = pathlib.Path("pyproject.toml")
txt = pp.read_text(encoding="utf-8")
txt = txt.replace('name = "dataaudit"', 'name = "dap-platform"', 1)
pp.write_text(txt, encoding="utf-8")
print("pyproject.toml: name -> dap-platform")

# 2. README.md - update install commands
rm = pathlib.Path("README.md")
if rm.exists():
    rtxt = rm.read_text(encoding="utf-8")
    rtxt = rtxt.replace("pip install dataaudit", "pip install dap-platform")
    rtxt = rtxt.replace("pypi.org/project/dataaudit", "pypi.org/project/dap-platform")
    rtxt = rtxt.replace("badge.fury.io/py/dataaudit", "badge.fury.io/py/dap-platform")
    rm.write_text(rtxt, encoding="utf-8")
    print("README.md: updated")

# 3. Rebuild
print("\nNow run:")
print("  Remove-Item dist/* -Force")
print("  python -m build")
