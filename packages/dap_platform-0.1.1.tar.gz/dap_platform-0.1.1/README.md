# DataAudit Platform
Audit management platform with GRC workflows and BI analytics.

Install: pip install dap-platform
Run: dataaudit serve
