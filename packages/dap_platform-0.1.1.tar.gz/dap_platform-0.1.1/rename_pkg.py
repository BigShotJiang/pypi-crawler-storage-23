options = [
    "dap-platform",
    "dataaudit-platform", 
    "audit-platform",
    "dap-audit",
    "dataaudit-grc",
]
for o in options:
    print(f"  pip install {o}")
