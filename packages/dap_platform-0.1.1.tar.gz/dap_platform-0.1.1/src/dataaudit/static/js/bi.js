/**
 * DAP BI Module — Frontend Engine
 * ECharts-based charting, API client, dashboard renderer
 * All methods exposed via window.DAP_BI
 */
(function () {
    'use strict';

    /* ── State ────────────────────────────────── */
    let datasources = [];
    let currentDatasource = null;
    let lastResult = null;
    const chartInstances = {};   // chartId → ECharts instance

    /* ── Color Palettes ──────────────────────── */
    const PALETTE = [
        '#3b82f6', '#1e40af', '#60a5fa', '#2563eb',
        '#10b981', '#059669', '#f59e0b', '#d97706',
        '#ef4444', '#8b5cf6', '#ec4899', '#14b8a6',
        '#f97316', '#6366f1', '#84cc16'
    ];

    const COLOR_SCHEMES = {
        default: PALETTE,
        warm:    ['#ef4444', '#f97316', '#f59e0b', '#eab308', '#dc2626', '#ea580c', '#ca8a04', '#fb923c', '#fbbf24', '#b91c1c'],
        cool:    ['#3b82f6', '#06b6d4', '#10b981', '#8b5cf6', '#0ea5e9', '#14b8a6', '#6366f1', '#2dd4bf', '#0284c7', '#059669'],
        earth:   ['#92400e', '#78716c', '#65a30d', '#b45309', '#57534e', '#4d7c0f', '#a16207', '#44403c', '#3f6212', '#854d0e'],
        mono:    ['#1e3a5f', '#1e40af', '#2563eb', '#3b82f6', '#60a5fa', '#93c5fd', '#bfdbfe', '#1d4ed8', '#7dd3fc', '#dbeafe'],
        pastel:  ['#93c5fd', '#86efac', '#fde68a', '#fca5a5', '#c4b5fd', '#fbcfe8', '#a5f3fc', '#fcd34d', '#a7f3d0', '#e9d5ff'],
    };

    /* ── Helpers ──────────────────────────────── */

    function _esc(text) {
        if (text == null) return '';
        const el = document.createElement('span');
        el.textContent = String(text);
        return el.innerHTML;
    }

    function formatDate(iso) {
        if (!iso) return '—';
        try {
            return new Date(iso).toLocaleDateString('ru-RU', {
                day: '2-digit', month: 'short', year: 'numeric'
            });
        } catch { return iso; }
    }

    function _formatNumber(val, format, decimals) {
        if (val == null) return '';
        const num = Number(val);
        if (isNaN(num)) return String(val);
        const d = decimals ?? 0;
        switch (format) {
            case 'thousands':
                return num.toLocaleString('ru-RU', { minimumFractionDigits: d, maximumFractionDigits: d });
            case 'percent':
                return num.toLocaleString('ru-RU', { minimumFractionDigits: d, maximumFractionDigits: d }) + '%';
            case 'currency':
                return num.toLocaleString('ru-RU', { minimumFractionDigits: d, maximumFractionDigits: d }) + ' ₽';
            case 'compact': {
                const abs = Math.abs(num);
                if (abs >= 1e9) return (num / 1e9).toFixed(d) + ' млрд';
                if (abs >= 1e6) return (num / 1e6).toFixed(d) + ' млн';
                if (abs >= 1e3) return (num / 1e3).toFixed(d) + ' тыс';
                return num.toFixed(d);
            }
            default:
                return d > 0 ? num.toFixed(d) : String(Math.round(num * Math.pow(10, d)) / Math.pow(10, d));
        }
    }

    function _buildLegend(position) {
        if (!position || position === 'none') return undefined;
        const base = { type: 'scroll', textStyle: { fontSize: 12 } };
        switch (position) {
            case 'top':    return { ...base, top: 0 };
            case 'left':   return { ...base, orient: 'vertical', left: 0, top: 'middle' };
            case 'right':  return { ...base, orient: 'vertical', right: 0, top: 'middle' };
            default:       return { ...base, bottom: 0 };
        }
    }

    async function _api(url, opts = {}) {
        const resp = await fetch(url, {
            headers: { 'Content-Type': 'application/json', ...(opts.headers || {}) },
            ...opts,
        });
        if (resp.status === 401) {
            window.location.href = '/login?next=' + encodeURIComponent(window.location.pathname);
            throw new Error('Unauthorized');
        }
        if (!resp.ok) {
            const err = await resp.json().catch(() => ({ detail: resp.statusText }));
            throw new Error(err.detail || err.message || `HTTP ${resp.status}`);
        }
        return resp.json();
    }

    /* ── Datasources ─────────────────────────── */

    async function loadDatasources() {
        datasources = await _api('/api/bi/datasources');
        return datasources;
    }

    function populateDatasourceSelect(el) {
        if (!el) return;
        el.innerHTML = '<option value="">— Источник данных —</option>';
        datasources.forEach(ds => {
            const opt = document.createElement('option');
            opt.value = ds.id;
            opt.textContent = `${ds.name} (${ds.engine})`;
            el.appendChild(opt);
        });
    }

    async function testDatasource(id) {
        return _api(`/api/bi/datasources/${id}/test`, { method: 'POST' });
    }

    async function saveDatasource(data) {
        if (data.id) {
            return _api(`/api/bi/datasources/${data.id}`, {
                method: 'PUT', body: JSON.stringify(data),
            });
        }
        return _api('/api/bi/datasources', {
            method: 'POST', body: JSON.stringify(data),
        });
    }

    async function deleteDatasource(id) {
        return _api(`/api/bi/datasources/${id}`, { method: 'DELETE' });
    }

    /* ── SQL Execution ───────────────────────── */

    async function runQuery(datasourceId, sql) {
        const data = await _api('/api/bi/query/run', {
            method: 'POST',
            body: JSON.stringify({ datasource_id: parseInt(datasourceId), sql: sql }),
        });
        lastResult = data;
        return data;
    }

    function getLastResult() {
        return lastResult;
    }

    function renderResultsTable(container, data) {
        if (!container || !data || !data.columns) return;
        if (data.error) {
            container.innerHTML = `<div class="bi-error-msg">${_esc(data.message)}</div>`;
            return;
        }
        if (data.rows.length === 0) {
            container.innerHTML = '<div class="bi-empty-state"><p>Нет данных</p><span>Запрос не вернул строк</span></div>';
            return;
        }

        let html = '<table class="results-table"><thead><tr>';
        html += '<th class="row-num">#</th>';
        data.columns.forEach(col => { html += `<th>${_esc(col)}</th>`; });
        html += '</tr></thead><tbody>';

        data.rows.forEach((row, i) => {
            html += '<tr>';
            html += `<td class="row-num">${i + 1}</td>`;
            row.forEach(val => {
                if (val === null || val === undefined) {
                    html += '<td class="null-value">NULL</td>';
                } else {
                    html += `<td>${_esc(val)}</td>`;
                }
            });
            html += '</tr>';
        });

        html += '</tbody></table>';
        container.innerHTML = html;
    }

    /* ── Saved Queries ───────────────────────── */

    async function loadQueries() {
        return _api('/api/bi/queries');
    }

    async function saveQueryAPI(data) {
        return _api('/api/bi/queries', {
            method: 'POST', body: JSON.stringify(data),
        });
    }

    async function deleteQuery(id) {
        return _api(`/api/bi/queries/${id}`, { method: 'DELETE' });
    }

    /* ── Charts CRUD ─────────────────────────── */

    async function loadCharts() {
        return _api('/api/bi/charts');
    }

    async function getChart(id) {
        return _api(`/api/bi/charts/${id}`);
    }

    async function saveChart(data) {
        if (data.id) {
            return _api(`/api/bi/charts/${data.id}`, {
                method: 'PUT', body: JSON.stringify(data),
            });
        }
        return _api('/api/bi/charts', {
            method: 'POST', body: JSON.stringify(data),
        });
    }

    async function deleteChart(id) {
        return _api(`/api/bi/charts/${id}`, { method: 'DELETE' });
    }

    async function getChartData(id) {
        return _api(`/api/bi/charts/${id}/data`, { method: 'POST' });
    }

    /* ── Dashboards CRUD ─────────────────────── */

    async function loadDashboards() {
        return _api('/api/bi/dashboards');
    }

    async function getDashboard(id) {
        return _api(`/api/bi/dashboards/${id}`);
    }

    async function saveDashboard(data) {
        if (data.id) {
            return _api(`/api/bi/dashboards/${data.id}`, {
                method: 'PUT', body: JSON.stringify(data),
            });
        }
        return _api('/api/bi/dashboards', {
            method: 'POST', body: JSON.stringify(data),
        });
    }

    async function deleteDashboard(id) {
        return _api(`/api/bi/dashboards/${id}`, { method: 'DELETE' });
    }

    async function addChartToDashboard(dashId, chartId, pos) {
        return _api(`/api/bi/dashboards/${dashId}/charts`, {
            method: 'POST',
            body: JSON.stringify({ chart_id: chartId, ...(pos || {}) }),
        });
    }

    async function removeChartFromDashboard(dashId, chartId) {
        return _api(`/api/bi/dashboards/${dashId}/charts/${chartId}`, { method: 'DELETE' });
    }

    /* ── ECharts Rendering ───────────────────── */

    function renderChart(containerEl, chartType, data, config) {
        if (!containerEl || !data) return null;
        if (typeof echarts === 'undefined') {
            containerEl.innerHTML = '<div class="bi-error-msg">ECharts не загружен</div>';
            return null;
        }

        // Clean up existing instance
        const existing = echarts.getInstanceByDom(containerEl);
        if (existing) existing.dispose();

        if (chartType === 'table') {
            renderResultsTable(containerEl, data);
            return null;
        }

        const instance = echarts.init(containerEl, null, { renderer: 'canvas' });
        const option = _buildChartOption(chartType, data, config || {});
        instance.setOption(option);

        // Auto-resize
        const ro = new ResizeObserver(() => instance.resize());
        ro.observe(containerEl);

        return instance;
    }

    /* ── Chart Option Builder ────────────────── */

    function _buildChartOption(type, data, config) {
        if (!data.columns || !data.rows || data.rows.length === 0) {
            return { title: { text: 'Нет данных', left: 'center', top: 'center', textStyle: { color: '#94a3b8', fontSize: 14 } } };
        }

        const cols = data.columns;
        const rows = data.rows;
        const cfg = config || {};

        // ── Column detection ──────────────────
        let catIdx = -1;
        let valIdxs = [];

        for (let i = 0; i < cols.length; i++) {
            const sample = rows[0][i];
            if (catIdx < 0 && (typeof sample === 'string' || sample === null) && isNaN(Number(sample))) {
                catIdx = i;
            } else if (!isNaN(Number(sample)) || sample === null) {
                valIdxs.push(i);
            }
        }
        if (catIdx < 0) catIdx = 0;
        if (valIdxs.length === 0) {
            for (let i = 0; i < cols.length; i++) {
                if (i !== catIdx) valIdxs.push(i);
            }
        }

        // Config overrides
        if (cfg.categoryColumn !== undefined && cfg.categoryColumn !== null && cfg.categoryColumn !== '') {
            catIdx = parseInt(cfg.categoryColumn);
        }
        if (cfg.valueColumns && cfg.valueColumns.length > 0) {
            valIdxs = cfg.valueColumns.map(v => parseInt(v));
        }

        const categories = rows.map(r => r[catIdx] ?? '—');

        // ── Read config values ────────────────
        const showLabels  = cfg.showLabels || false;
        const labelPos    = cfg.labelPosition || 'top';
        const legendPos   = cfg.legendPosition || 'bottom';
        const showGrid    = cfg.showGrid !== false;
        const smooth      = cfg.smooth !== false;
        const stacked     = cfg.stacked || false;
        const horizontal  = cfg.barDirection === 'horizontal';
        const xTitle      = cfg.xAxisTitle || '';
        const yTitle      = cfg.yAxisTitle || '';
        const numFmt      = cfg.numberFormat || 'plain';
        const numDec      = cfg.decimals ?? 0;
        const colors      = COLOR_SCHEMES[cfg.colorScheme] || PALETTE;

        const fmtNum = (v) => _formatNumber(v, numFmt, numDec);
        const legendCfg = _buildLegend(legendPos);

        // ── METRIC ────────────────────────────
        if (type === 'metric') {
            const val = Number(rows[0][valIdxs[0] !== undefined ? valIdxs[0] : 1]) || 0;
            return {
                color: colors,
                series: [{
                    type: 'gauge', startAngle: 200, endAngle: -20,
                    min: 0, max: cfg.maxValue || Math.max(val * 1.5, 100),
                    progress: { show: true, width: 18, itemStyle: { color: colors[0] } },
                    axisLine: { lineStyle: { width: 18, color: [[1, '#e2e8f0']] } },
                    axisTick: { show: false }, splitLine: { show: false }, axisLabel: { show: false },
                    pointer: { show: false },
                    detail: {
                        valueAnimation: true, fontSize: 28, fontWeight: 700, color: '#1e293b',
                        offsetCenter: [0, '0%'],
                        formatter: (v) => fmtNum(v),
                    },
                    data: [{ value: val }],
                }],
            };
        }

        // ── PIE / DONUT ──────────────────────
        if (type === 'pie' || type === 'donut') {
            const pieData = rows.map((r, i) => ({
                name: String(r[catIdx] ?? `Категория ${i + 1}`),
                value: Number(r[valIdxs[0] !== undefined ? valIdxs[0] : 1]) || 0,
            }));
            const innerRadius = type === 'donut' ? '40%' : '0%';
            return {
                color: colors,
                tooltip: {
                    trigger: 'item',
                    formatter: (p) => `${_esc(p.name)}: ${fmtNum(p.value)} (${p.percent}%)`,
                },
                legend: legendCfg,
                series: [{
                    type: 'pie',
                    radius: [innerRadius, '70%'],
                    avoidLabelOverlap: true,
                    label: showLabels
                        ? { show: true, formatter: (p) => `${p.name}\n${fmtNum(p.value)}`, fontSize: 12 }
                        : { show: false },
                    emphasis: { label: { show: true, fontSize: 14, fontWeight: 600 } },
                    data: pieData,
                }],
            };
        }

        // ── SCATTER ──────────────────────────
        if (type === 'scatter') {
            const xIdx = valIdxs[0] || 0;
            const yIdx = valIdxs[1] !== undefined ? valIdxs[1] : 1;
            const scatterData = rows.map(r => [
                Number(r[xIdx]) || 0,
                Number(r[yIdx]) || 0,
            ]);
            return {
                color: colors,
                tooltip: {
                    trigger: 'item',
                    formatter: (p) => `${fmtNum(p.value[0])}, ${fmtNum(p.value[1])}`,
                },
                xAxis: {
                    type: 'value',
                    name: xTitle || cols[xIdx],
                    nameLocation: 'middle', nameGap: 30,
                    splitLine: { show: showGrid, lineStyle: { type: 'dashed', color: '#e2e8f0' } },
                    axisLabel: { fontSize: 11, formatter: (v) => fmtNum(v) },
                },
                yAxis: {
                    type: 'value',
                    name: yTitle || cols[yIdx],
                    splitLine: { show: showGrid, lineStyle: { type: 'dashed', color: '#e2e8f0' } },
                    axisLabel: { fontSize: 11, formatter: (v) => fmtNum(v) },
                },
                grid: { top: 30, right: 20, bottom: 50, left: 60 },
                series: [{
                    type: 'scatter', data: scatterData, symbolSize: 10,
                    label: showLabels ? { show: true, position: 'top', formatter: (p) => fmtNum(p.value[1]), fontSize: 10 } : undefined,
                }],
            };
        }

        // ── FUNNEL ───────────────────────────
        if (type === 'funnel') {
            const funnelData = rows.map((r, i) => ({
                name: String(r[catIdx] ?? `Этап ${i + 1}`),
                value: Number(r[valIdxs[0] !== undefined ? valIdxs[0] : 1]) || 0,
            }));
            return {
                color: colors,
                tooltip: { trigger: 'item', formatter: (p) => `${_esc(p.name)}: ${fmtNum(p.value)}` },
                legend: legendCfg,
                series: [{
                    type: 'funnel', left: '10%', top: 30, bottom: 30, width: '80%',
                    sort: 'descending', gap: 2,
                    label: showLabels
                        ? { show: true, position: 'inside', formatter: (p) => `${p.name}\n${fmtNum(p.value)}` }
                        : { show: true, position: 'left', formatter: '{b}' },
                    emphasis: { label: { fontSize: 14 } },
                    data: funnelData,
                }],
            };
        }

        // ── TREEMAP ──────────────────────────
        if (type === 'treemap') {
            const treeData = rows.map((r, i) => ({
                name: String(r[catIdx] ?? `Элемент ${i + 1}`),
                value: Number(r[valIdxs[0] !== undefined ? valIdxs[0] : 1]) || 0,
            }));
            return {
                color: colors,
                tooltip: { formatter: (p) => `${_esc(p.name)}: ${fmtNum(p.value)}` },
                series: [{
                    type: 'treemap',
                    data: treeData,
                    label: { show: true, formatter: '{b}', fontSize: 12 },
                    breadcrumb: { show: false },
                    itemStyle: { borderColor: '#fff', borderWidth: 2, gapWidth: 2 },
                }],
            };
        }

        // ── RADAR ────────────────────────────
        if (type === 'radar') {
            const maxVal = Math.max(...rows.map(r => Math.max(...valIdxs.map(vi => Number(r[vi]) || 0)))) * 1.2 || 100;
            const indicators = rows.map(r => ({
                name: String(r[catIdx] ?? ''),
                max: maxVal,
            }));
            const radarSeries = valIdxs.map((vi, si) => ({
                name: cols[vi],
                value: rows.map(r => Number(r[vi]) || 0),
            }));
            return {
                color: colors,
                tooltip: {},
                legend: legendCfg,
                radar: {
                    indicator: indicators,
                    shape: 'polygon',
                    splitArea: { show: showGrid, areaStyle: { color: ['rgba(59,130,246,0.02)', 'rgba(59,130,246,0.05)'] } },
                },
                series: [{
                    type: 'radar',
                    data: radarSeries,
                    areaStyle: { opacity: 0.1 },
                }],
            };
        }

        // ── BAR / LINE / AREA ────────────────
        const isHorizontal = type === 'bar' && horizontal;

        const series = valIdxs.map((vi, si) => {
            const s = {
                name: cols[vi],
                type: type === 'area' ? 'line' : type,
                data: rows.map(r => Number(r[vi]) || 0),
                barMaxWidth: 40,
            };
            if (type === 'area') s.areaStyle = { opacity: 0.15 };
            if (type === 'line' || type === 'area') s.smooth = smooth;
            if (stacked) s.stack = 'total';
            if (showLabels) {
                s.label = {
                    show: true,
                    position: isHorizontal ? 'right' : labelPos,
                    formatter: (p) => fmtNum(p.value),
                    fontSize: 11,
                };
            }
            return s;
        });

        const catAxis = {
            type: 'category',
            data: categories,
            axisLabel: {
                fontSize: 11,
                rotate: (!isHorizontal && categories.length > 10) ? 45 : 0,
                overflow: 'truncate',
                width: 80,
            },
            axisTick: { alignWithLabel: true },
            name: isHorizontal ? yTitle : xTitle,
            nameLocation: 'middle',
            nameGap: isHorizontal ? 50 : 35,
            nameTextStyle: { fontSize: 12, color: '#64748b' },
        };

        const valAxis = {
            type: 'value',
            axisLabel: { fontSize: 11, formatter: (v) => fmtNum(v) },
            splitLine: { show: showGrid, lineStyle: { type: 'dashed', color: '#e2e8f0' } },
            name: isHorizontal ? xTitle : yTitle,
            nameLocation: 'middle',
            nameGap: 50,
            nameTextStyle: { fontSize: 12, color: '#64748b' },
        };

        // Calculate grid padding
        const hasLegend = series.length > 1 && legendPos !== 'none';
        let gridTop = (yTitle && !isHorizontal) || (xTitle && isHorizontal) ? 40 : 20;
        let gridBottom = 24;
        let gridLeft = 60;
        let gridRight = 20;

        if (hasLegend) {
            if (legendPos === 'bottom') gridBottom = 50;
            else if (legendPos === 'top') gridTop = 40;
            else if (legendPos === 'left') gridLeft = 120;
            else if (legendPos === 'right') gridRight = 120;
        }
        if (!isHorizontal && categories.length > 10) gridBottom += 20;

        return {
            color: colors,
            tooltip: {
                trigger: 'axis',
                formatter: (params) => {
                    if (!Array.isArray(params)) params = [params];
                    let tip = `<strong>${_esc(params[0].axisValue)}</strong><br/>`;
                    params.forEach(p => {
                        tip += `${p.marker} ${_esc(p.seriesName)}: <b>${fmtNum(p.value)}</b><br/>`;
                    });
                    return tip;
                },
            },
            legend: hasLegend ? legendCfg : undefined,
            grid: { top: gridTop, right: gridRight, bottom: gridBottom, left: gridLeft },
            xAxis: isHorizontal ? valAxis : catAxis,
            yAxis: isHorizontal ? catAxis : valAxis,
            series: series,
        };
    }

    /* ── Dashboard Renderer ──────────────────── */

    async function renderDashboard(containerEl, dashData) {
        if (!containerEl || !dashData) return;
        containerEl.innerHTML = '';

        const charts = dashData.charts || [];
        if (charts.length === 0) {
            containerEl.innerHTML = `
                <div class="bi-empty-state" style="grid-column:1/-1">
                    <i data-lucide="layout-dashboard"></i>
                    <p>Нет графиков</p>
                    <span>Добавьте графики через кнопку выше</span>
                </div>`;
            if (typeof lucide !== 'undefined') lucide.createIcons();
            return;
        }

        // Render grid
        containerEl.classList.add('dashboard-grid');
        for (const c of charts) {
            const w = c.width || 6;
            const h = c.height || 1;
            const cell = document.createElement('div');
            cell.className = 'dashboard-cell';
            cell.style.gridColumn = `span ${w}`;
            cell.style.gridRow = `span ${h}`;

            const typeLabel = c.chart_type || 'bar';
            cell.innerHTML = `
                <div class="dashboard-cell-header">
                    <span>${_esc(c.chart_title || c.title || 'График')}</span>
                    <span class="bi-badge ${typeLabel}">${typeLabel}</span>
                </div>
                <div class="dashboard-cell-body">
                    <div class="bi-spinner-lg bi-spinner"></div>
                </div>`;
            containerEl.appendChild(cell);

            // Fetch data and render
            const body = cell.querySelector('.dashboard-cell-body');
            try {
                const d = await getChartData(c.chart_id || c.id);
                body.innerHTML = '<div class="echarts-container"></div>';
                const ecEl = body.querySelector('.echarts-container');
                let chartCfg = c.chart_config || {};
                if (typeof chartCfg === 'string') {
                    try { chartCfg = JSON.parse(chartCfg); } catch { chartCfg = {}; }
                }
                renderChart(ecEl, typeLabel, d, chartCfg);
            } catch (err) {
                body.innerHTML = `<div class="bi-error-msg">${_esc(err.message)}</div>`;
            }
        }
    }

    /* ── CSV Export ───────────────────────────── */

    function exportCSV(data, filename) {
        if (!data || !data.columns) return;
        const BOM = '\uFEFF';
        let csv = BOM;
        csv += data.columns.map(c => `"${String(c).replace(/"/g, '""')}"`).join(';') + '\n';
        data.rows.forEach(row => {
            csv += row.map(v => {
                if (v === null || v === undefined) return '';
                return `"${String(v).replace(/"/g, '""')}"`;
            }).join(';') + '\n';
        });

        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = filename || 'export.csv';
        a.click();
        URL.revokeObjectURL(a.href);
    }

    /* ── Public API ──────────────────────────── */

    window.DAP_BI = {
        // Helpers
        _esc, formatDate, exportCSV, _formatNumber,
        PALETTE, COLOR_SCHEMES,

        // Datasources
        loadDatasources, populateDatasourceSelect,
        testDatasource, saveDatasource, deleteDatasource,
        get datasources() { return datasources; },

        // SQL
        runQuery, getLastResult, renderResultsTable,

        // Queries
        loadQueries, saveQuery: saveQueryAPI, deleteQuery,

        // Charts
        loadCharts, getChart, saveChart, deleteChart, getChartData,
        renderChart,

        // Dashboards
        loadDashboards, getDashboard, saveDashboard, deleteDashboard,
        addChartToDashboard, removeChartFromDashboard, renderDashboard,
    };
})();
