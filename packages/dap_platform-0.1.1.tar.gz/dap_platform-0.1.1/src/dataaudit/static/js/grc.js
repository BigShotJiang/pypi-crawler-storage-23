/* ══════════════════════════════════════════════════
   GRC Module JavaScript — DataAudit Platform
   Shared constants, helpers, and rendering functions
   ══════════════════════════════════════════════════ */

// ── Status Labels (Russian) ─────────────────────────

const GRC_LABELS = {
    // Plans
    draft: 'Черновик',
    under_review: 'На рассмотрении',
    approved: 'Утверждён',
    active: 'Активен',
    completed: 'Завершён',
    archived: 'Архив',
    // Engagements
    planned: 'Запланирована',
    in_progress: 'В работе',
    fieldwork: 'Полевая работа',
    review: 'Проверка',
    findings_issued: 'Замечания выданы',
    remediation: 'Исправление',
    closed: 'Закрыта',
    // Findings
    confirmed: 'Подтверждено',
    remediation_issued: 'Рекомендация выдана',
    resolved: 'Исправлено',
    // Remediation
    assigned: 'Назначено',
    submitted: 'На проверке',
    verified: 'Проверено',
    cancelled: 'Отменено',
};

// ── Allowed Transitions ─────────────────────────────

const GRC_TRANSITIONS = {
    plan: {
        draft: ['under_review'],
        under_review: ['approved', 'draft'],
        approved: ['active'],
        active: ['completed'],
        completed: ['archived'],
    },
    engagement: {
        planned: ['in_progress'],
        in_progress: ['fieldwork'],
        fieldwork: ['review'],
        review: ['findings_issued', 'closed'],
        findings_issued: ['remediation'],
        remediation: ['closed'],
    },
    finding: {
        draft: ['confirmed'],
        confirmed: ['remediation_issued'],
        remediation_issued: ['resolved'],
        resolved: ['closed'],
    },
    remediation: {
        assigned: ['in_progress'],
        in_progress: ['submitted'],
        submitted: ['verified', 'in_progress'],
        verified: ['closed'],
    },
};

// ── Utility Functions ───────────────────────────────

function escHtml(str) {
    if (!str) return '';
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}

function formatDate(isoStr) {
    if (!isoStr) return '—';
    try {
        return new Date(isoStr).toLocaleString('ru-RU', {
            day: '2-digit', month: '2-digit', year: 'numeric',
            hour: '2-digit', minute: '2-digit'
        });
    } catch (e) {
        return isoStr;
    }
}

function openModal(id) {
    var el = document.getElementById(id);
    // Move to body to escape parent layout
    if (el.parentElement !== document.body) {
        document.body.appendChild(el);
    }
    // Overlay: cover entire viewport
    el.style.cssText = 'display:block; position:fixed; top:0; left:0; right:0; bottom:0; width:100vw; height:100vh; z-index:99999; background:rgba(0,0,0,0.4); margin:0; padding:0;';
    // Center the modal child using inset 0 + margin auto (truly viewport-centered)
    var modal = el.querySelector('.modal');
    if (modal) {
        var w = modal.classList.contains('modal-lg') ? '680px' : '520px';
        modal.style.cssText = 'position:fixed; top:0; left:0; right:0; bottom:0; margin:auto; z-index:100000; width:' + w + '; height:fit-content; max-height:85vh;';
    }
}

function closeModal(id) {
    var el = document.getElementById(id);
    el.style.display = 'none';
    var modal = el.querySelector('.modal');
    if (modal) {
        modal.style.cssText = '';
    }
}

// Close modal on overlay click
document.addEventListener('click', function (e) {
    if (e.target.classList.contains('modal-overlay')) {
        e.target.style.display = 'none';
    }
});

// Close modal on Escape
document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
        document.querySelectorAll('.modal-overlay').forEach(m => m.style.display = 'none');
    }
});

// ── Shared Rendering Functions ──────────────────────

function renderComments(container, comments) {
    if (!comments || !comments.length) {
        container.innerHTML = '<div class="empty-state-sm">Нет комментариев</div>';
        return;
    }
    container.innerHTML = comments.map(c => {
        const initials = (c.author_name || c.author_id || '?')
            .split(' ')
            .map(w => w[0])
            .slice(0, 2)
            .join('')
            .toUpperCase();
        const time = formatDate(c.created_at);
        return `
            <div class="comment-item">
                <div class="comment-avatar">${initials}</div>
                <div class="comment-content">
                    <div class="comment-header">
                        <span class="comment-author">${escHtml(c.author_name || c.author_id)}</span>
                        <span class="comment-time">${time}</span>
                    </div>
                    <div class="comment-body">${escHtml(c.body)}</div>
                </div>
            </div>`;
    }).join('');
}

function renderActivityLog(container, activities) {
    if (!activities || !activities.length) {
        container.innerHTML = '<div class="empty-state-sm">Нет записей</div>';
        return;
    }
    const icons = {
        created: 'plus-circle',
        updated: 'edit',
        deleted: 'trash-2',
        status_changed: 'arrow-right-circle',
        commented: 'message-circle',
        member_added: 'user-plus',
        member_removed: 'user-minus',
        reassigned: 'user-check',
    };
    const actionLabels = {
        created: 'создал',
        updated: 'обновил',
        deleted: 'удалил',
        status_changed: 'изменил статус',
        commented: 'прокомментировал',
        member_added: 'добавил участника',
        member_removed: 'удалил участника',
        reassigned: 'переназначил',
    };

    container.innerHTML = activities.map(a => {
        const icon = icons[a.action] || 'activity';
        const label = actionLabels[a.action] || a.action;
        const time = formatDate(a.created_at);
        const transition = a.old_value && a.new_value
            ? `<span class="activity-transition">${GRC_LABELS[a.old_value] || a.old_value} → ${GRC_LABELS[a.new_value] || a.new_value}</span>`
            : '';

        return `
            <div class="activity-item">
                <i data-lucide="${icon}" class="activity-icon"></i>
                <div class="activity-body">
                    <span class="activity-actor">${escHtml(a.actor_name || a.actor_id)}</span>
                    <span class="activity-action">${label}</span>
                    ${transition}
                </div>
                <span class="activity-time">${time}</span>
            </div>`;
    }).join('');

    // Re-initialize Lucide icons for the newly added elements
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
}

// ══════════════════════════════════════════════════════════════════
//  Audit Universe & Strategic Planning — 4-Block МКБ Model (v2)
//  
// ══════════════════════════════════════════════════════════════════

// ── Fix openModal for modal-xl ───────────────────────────────────
(function() {
    const _origOpen = window.openModal;
    window.openModal = function(id) {
        _origOpen(id);
        var el = document.getElementById(id);
        var modal = el ? el.querySelector('.modal') : null;
        if (modal && modal.classList.contains('modal-xl')) {
            modal.style.width = '920px';
            modal.style.maxHeight = '90vh';
            modal.style.overflow = 'auto';
        }
    };
})();

// ── Transitions for Strategic Plans ──────────────────────────────
GRC_TRANSITIONS.strategic_plan = {
    draft:        ['under_review'],
    under_review: ['approved', 'draft'],
    approved:     ['active'],
    active:       ['completed'],
    completed:    ['archived']
};

// ── Label Maps ───────────────────────────────────────────────────

const OBJECT_CATEGORIES = {
    business_process: 'Бизнес-процесс',
    it_system:        'ИТ-система',
    department:       'Подразделение',
    regulatory:       'Регуляторное направление'
};

const RISK_LEVELS = {
    high:   'Высокий',
    medium: 'Средний',
    low:    'Низкий'
};

const AUDIT_FREQUENCIES = {
    annual:    'Ежегодно',
    biennial:  'Раз в 2 года',
    triennial: 'Раз в 3 года'
};

const DIVISION_LABELS = {
    'ОСА':  'ОСА — Спец. аудит',
    'ОАКБ': 'ОАКБ — Корп. бизнес',
    'ОАРБ': 'ОАРБ — Розн. бизнес',
    'ОАИБ': 'ОАИБ — Инвест. бизнес',
    'ОВЦБ': 'ОВЦБ — Рыночные риски'
};

const CONCLUSION_LABELS = {
    current_year: 'Текущий год',
    next_year:    'Следующий год',
    year_three:   'Год 3'
};

const CONCLUSION_COLORS = {
    current_year: '#dc2626',
    next_year:    '#d97706',
    year_three:   '#16a34a'
};

// ── 4-Block Scoring Model ────────────────────────────────────────

const SCORING_BLOCKS = {
    process: {
        label: 'Рейтинг бизнес-процесса',
        dimensions: {
            process_regulation: { label: 'Уровень регламентации',      weight: 0.30, sort: 1 },
            process_automation: { label: 'Уровень автоматизации',       weight: 0.20, sort: 2 },
            process_changes:    { label: 'Изменения в процессе',        weight: 0.20, sort: 3 },
            process_sor:        { label: 'События опер. риска (СОР)',   weight: 0.30, sort: 4 }
        }
    },
    svk: {
        label: 'Надёжность СВК',
        dimensions: {
            svk_dva:       { label: 'Оценка ДВА',              weight: 0.40, sort: 5 },
            svk_internal:  { label: 'Внутренние проверяющие',   weight: 0.30, sort: 6 },
            svk_regulator: { label: 'Регулирующие органы',      weight: 0.30, sort: 7 }
        }
    },
    importance: {
        label: 'Важность для Банка',
        dimensions: {
            importance_financial: { label: 'Влияние на фин. результат',   weight: 0.50, sort: 8 },
            importance_strategic: { label: 'Значимость для стратегии',     weight: 0.50, sort: 9 }
        }
    }
};

// Flat dimension map (for iteration)
const RISK_DIMENSIONS = {};
for (const block of Object.values(SCORING_BLOCKS)) {
    Object.assign(RISK_DIMENSIONS, block.dimensions);
}

const SCORE_LABELS = {
    process_regulation: ['Высокий', 'Средний', 'Низкий'],
    process_automation: ['Высокий', 'Средний', 'Низкий'],
    process_changes:    ['Нет изменений', 'Незначительные', 'Значительные'],
    process_sor:        ['Нет', 'Несколько', 'Множество'],
    svk_dva:            ['Надёжные', 'Достаточные', 'Недостаточные'],
    svk_internal:       ['Надёжные', 'Достаточные', 'Недостаточные'],
    svk_regulator:      ['Надёжные', 'Достаточные', 'Недостаточные'],
    importance_financial: ['Незначительное', 'Среднее', 'Значительное'],
    importance_strategic: ['Незначительная', 'Средняя', 'Значительная']
};

const RISK_FLAG_LABELS = {
    credit:        'Кредитный',
    market:        'Рыночный',
    interest_rate: 'Процентный',
    currency:      'Валютный',
    operational:   'Операционный',
    liquidity:     'Ликвидности',
    concentration: 'Концентрации',
    reputation:    'Репутации'
};

// ── Risk Calculation (client-side mirror) ────────────────────────

function calcBlockComposite(scores, blockKey) {
    const block = SCORING_BLOCKS[blockKey];
    if (!block) return 0;
    let total = 0;
    for (const [dim, cfg] of Object.entries(block.dimensions)) {
        total += (parseInt(scores[dim]) || 1) * cfg.weight;
    }
    return Math.round(total * 100) / 100;
}

function calcResidualRisk(processComp, svkComp) {
    return (processComp >= 2.0 && svkComp >= 1.5) ? 2 : 1;
}

function calcCompositeScore(scores) {
    const process    = calcBlockComposite(scores, 'process');
    const svk        = calcBlockComposite(scores, 'svk');
    const importance = calcBlockComposite(scores, 'importance');
    const residual   = calcResidualRisk(process, svk);
    return Math.round(((residual + importance) / 2) * 100) / 100;
}

function getRiskLevel(composite) {
    if (composite >= 2.0) return 'high';
    if (composite >= 1.5) return 'medium';
    return 'low';
}

// ── Rendering Helpers ────────────────────────────────────────────

function renderScoreBar(composite, riskLevel) {
    // Range 1.0–2.5 → 0%–100%
    const pct = Math.min(100, Math.max(0, ((composite - 1.0) / 1.5) * 100));
    return `
        <div class="score-bar">
            <div class="score-bar-track">
                <div class="score-bar-fill fill-${riskLevel}" style="width:${pct}%"></div>
            </div>
            <span class="score-value">${composite.toFixed(2)}</span>
        </div>
    `;
}

function renderRiskBadge(riskLevel) {
    return `<span class="risk-badge risk-${riskLevel}">
        <span class="risk-dot risk-dot-${riskLevel}"></span>
        ${RISK_LEVELS[riskLevel] || riskLevel}
    </span>`;
}

function renderCategoryBadge(category) {
    return `<span class="category-badge cat-${category}">
        ${OBJECT_CATEGORIES[category] || category}
    </span>`;
}

function renderFrequency(freq) {
    return `<span class="freq-badge">${AUDIT_FREQUENCIES[freq] || freq || '—'}</span>`;
}

function renderDivisionBadge(div) {
    if (!div) return '';
    return `<span class="division-badge div-${div}">${div}</span>`;
}

function renderConclusionBadge(conclusion) {
    if (!conclusion) return '—';
    const label = CONCLUSION_LABELS[conclusion] || conclusion;
    const color = CONCLUSION_COLORS[conclusion] || '#64748b';
    return `<span style="display:inline-block;padding:2px 8px;border-radius:4px;font-size:0.6875rem;font-weight:600;background:${color}15;color:${color};border:1px solid ${color}30">${label}</span>`;
}

function renderRiskFlags(flags) {
    if (!flags || typeof flags !== 'object') return '';
    const active = Object.entries(flags).filter(([k, v]) => v);
    if (!active.length) return '<span style="color:#94a3b8;font-size:0.75rem">—</span>';
    return active.map(([k]) =>
        `<span class="risk-flag-badge">${RISK_FLAG_LABELS[k] || k}</span>`
    ).join(' ');
}

function renderCbrBadge(required) {
    if (!required) return '';
    return `<span class="cbr-badge" title="Требуется проверка по ЦБ">ЦБ</span>`;
}
