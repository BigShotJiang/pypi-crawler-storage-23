// DAP Platform - Minimal JS
// HTMX is loaded in base.html

document.addEventListener('DOMContentLoaded', function() {
    console.log('DAP Platform loaded');
    
    // Future functionality will go here
    // - HTMX event handlers
    // - Dynamic content loading
    // - Form validation
});
