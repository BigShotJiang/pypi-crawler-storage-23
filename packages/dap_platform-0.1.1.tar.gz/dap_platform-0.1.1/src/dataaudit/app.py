from fastapi import FastAPI, Request, Form
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse, RedirectResponse
from pathlib import Path
import asyncio
import os
import logging
from datetime import datetime, time as dtime, timedelta
import yaml

from dataaudit.routers.bi_native import router as bi_router
from dataaudit.routers.workflows import router as workflows_router
from dataaudit.routers.grc import router as grc_router
from dataaudit.routers.my_reports import router as my_reports_router
from dataaudit.auth import (
    get_current_user,
    auth_middleware,
    add_user_to_context,
)
from dataaudit.auth.local_auth import get_auth_client
from dataaudit.auth.session import get_session_manager
logging.getLogger("dap.scheduler").setLevel(logging.INFO)
logging.getLogger("dap.scheduler").addHandler(logging.StreamHandler())
app = FastAPI(title="DataAudit Platform")
app.include_router(bi_router)
app.include_router(workflows_router)
app.include_router(grc_router)
app.include_router(my_reports_router)


# Auth middleware - protects all routes except /login, /health, /static
app.middleware("http")(auth_middleware)

# Mount static files
_PKG_DIR = Path(__file__).parent
app.mount("/static", StaticFiles(directory=str(_PKG_DIR / "static")), name="static")

# Setup Jinja2 templates
templates = Jinja2Templates(directory=str(_PKG_DIR / "templates"))


def load_useful_links():
    """Load useful links from YAML config"""
    config_path = _PKG_DIR / "config" / "useful_links.yaml"
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            return yaml.safe_load(f)
    except Exception as e:
        print(f"Error loading useful links: {e}")
        return {"categories": []}


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse(
        "pages/home.html",
        {"request": request, "current_page": "home", **add_user_to_context(request)}
    )


@app.get("/reports", response_class=HTMLResponse)
async def reports(request: Request):
    """Legacy route - redirect to my-reports"""
    return RedirectResponse(url="/my-reports", status_code=302)


@app.get("/my-reports", response_class=HTMLResponse)
async def my_reports_page(request: Request):
    return templates.TemplateResponse(
        "pages/my_reports.html",
        {"request": request, "current_page": "my-reports", **add_user_to_context(request)}
    )


# ── BI Analytics (Native) ─────────────────────────────────────────────

@app.get("/analytics", response_class=HTMLResponse)
async def analytics(request: Request):
    return templates.TemplateResponse(
        "pages/bi_analytics.html",
        {"request": request, "current_page": "analytics", **add_user_to_context(request)}
    )


@app.get("/analytics/sql", response_class=HTMLResponse)
async def analytics_sql(request: Request):
    return templates.TemplateResponse(
        "pages/bi/sql_lab.html",
        {"request": request, "current_page": "analytics", **add_user_to_context(request)}
    )


@app.get("/analytics/charts", response_class=HTMLResponse)
async def analytics_charts(request: Request):
    return templates.TemplateResponse(
        "pages/bi/charts.html",
        {"request": request, "current_page": "analytics", **add_user_to_context(request)}
    )


@app.get("/analytics/charts/{chart_id}/edit", response_class=HTMLResponse)
async def analytics_chart_edit(request: Request, chart_id: int):
    return templates.TemplateResponse(
        "pages/bi/chart_edit.html",
        {"request": request, "current_page": "analytics", "chart_id": chart_id, **add_user_to_context(request)}
    )


@app.get("/analytics/dashboards", response_class=HTMLResponse)
async def analytics_dashboards(request: Request):
    return templates.TemplateResponse(
        "pages/bi/dashboards.html",
        {"request": request, "current_page": "analytics", **add_user_to_context(request)}
    )


@app.get("/analytics/dashboards/{dashboard_id}", response_class=HTMLResponse)
async def analytics_dashboard_view(request: Request, dashboard_id: int):
    return templates.TemplateResponse(
        "pages/bi/dashboard_view.html",
        {"request": request, "current_page": "analytics", "dashboard_id": dashboard_id, **add_user_to_context(request)}
    )


@app.get("/analytics/datasources", response_class=HTMLResponse)
async def analytics_datasources(request: Request):
    return templates.TemplateResponse(
        "pages/bi/datasources.html",
        {"request": request, "current_page": "analytics", **add_user_to_context(request)}
    )


# ── GRC Workflows (Native) ────────────────────────────────────────────

@app.get("/workflows", response_class=HTMLResponse)
async def workflows(request: Request):
    return templates.TemplateResponse(
        "pages/workflows.html",
        {"request": request, "current_page": "workflows", **add_user_to_context(request)}
    )


@app.get("/workflows/plans", response_class=HTMLResponse)
async def grc_plans(request: Request):
    return templates.TemplateResponse(
        "pages/grc/plans.html",
        {"request": request, "current_page": "workflows", **add_user_to_context(request)}
    )


@app.get("/workflows/plans/{plan_id}", response_class=HTMLResponse)
async def grc_plan_detail(request: Request, plan_id: int):
    return templates.TemplateResponse(
        "pages/grc/plan_detail.html",
        {"request": request, "current_page": "workflows", "plan_id": plan_id, **add_user_to_context(request)}
    )


@app.get("/workflows/engagements", response_class=HTMLResponse)
async def grc_engagements(request: Request):
    return templates.TemplateResponse(
        "pages/grc/engagements.html",
        {"request": request, "current_page": "workflows", **add_user_to_context(request)}
    )


@app.get("/workflows/engagements/{engagement_id}", response_class=HTMLResponse)
async def grc_engagement_detail(request: Request, engagement_id: int):
    return templates.TemplateResponse(
        "pages/grc/engagement_detail.html",
        {"request": request, "current_page": "workflows", "engagement_id": engagement_id, **add_user_to_context(request)}
    )


@app.get("/workflows/findings/{finding_id}", response_class=HTMLResponse)
async def grc_finding_detail(request: Request, finding_id: int):
    return templates.TemplateResponse(
        "pages/grc/finding_detail.html",
        {"request": request, "current_page": "workflows", "finding_id": finding_id, **add_user_to_context(request)}
    )


@app.get("/workflows/remediations", response_class=HTMLResponse)
async def grc_remediations(request: Request):
    return templates.TemplateResponse(
        "pages/grc/remediations.html",
        {"request": request, "current_page": "workflows", **add_user_to_context(request)}
    )


@app.get("/workflows/remediations/{remediation_id}", response_class=HTMLResponse)
async def grc_remediation_detail(request: Request, remediation_id: int):
    return templates.TemplateResponse(
        "pages/grc/remediation_detail.html",
        {"request": request, "current_page": "workflows", "remediation_id": remediation_id, **add_user_to_context(request)}
    )


@app.get("/workflows/notifications", response_class=HTMLResponse)
async def grc_notifications(request: Request):
    return templates.TemplateResponse(
        "pages/grc/notifications.html",
        {"request": request, "current_page": "workflows", **add_user_to_context(request)}
    )


@app.get("/workflows/settings", response_class=HTMLResponse)
async def grc_settings(request: Request):
    return templates.TemplateResponse(
        "pages/grc/settings_workflows.html",
        {"request": request, "current_page": "workflows", **add_user_to_context(request)}
    )

@app.get("/workflows/universe", response_class=HTMLResponse)
async def page_universe(request: Request):
    return templates.TemplateResponse(
        "pages/grc/universe.html",
        {"request": request, "current_page": "workflows", **add_user_to_context(request)}
    )

@app.get("/workflows/strategic-plans", response_class=HTMLResponse)
async def page_strategic_plans(request: Request):
    return templates.TemplateResponse(
        "pages/grc/strategic_plans.html",
        {"request": request, "current_page": "workflows", **add_user_to_context(request)}
    )

@app.get("/workflows/strategic-plans/{plan_id}", response_class=HTMLResponse)
async def page_strategic_plan_detail(request: Request, plan_id: int):
    return templates.TemplateResponse(
        "pages/grc/strategic_plan_detail.html",
        {"request": request, "current_page": "workflows", "plan_id": plan_id, **add_user_to_context(request)}
    )
# ── Other Pages ────────────────────────────────────────────────────────

@app.get("/ai", response_class=HTMLResponse)
async def ai_assistant(request: Request):
    return templates.TemplateResponse(
        "pages/ai_assistant.html",
        {"request": request, "current_page": "ai", **add_user_to_context(request)}
    )


@app.get("/governance", response_class=HTMLResponse)
async def data_governance(request: Request):
    return templates.TemplateResponse(
        "pages/data_governance.html",
        {"request": request, "current_page": "governance", **add_user_to_context(request)}
    )


@app.get("/useful-links", response_class=HTMLResponse)
async def useful_links(request: Request):
    links_config = load_useful_links()
    return templates.TemplateResponse(
        "pages/useful_links.html",
        {
            "request": request,
            "current_page": "useful-links",
            "categories": links_config.get("categories", []),
            **add_user_to_context(request)
        }
    )


@app.get("/settings", response_class=HTMLResponse)
async def settings(request: Request):
    return templates.TemplateResponse(
        "pages/settings.html",
        {"request": request, "current_page": "settings", **add_user_to_context(request)}
    )


@app.get("/login", response_class=HTMLResponse)
async def login(request: Request, next: str = "/", error: str = None):
    # If already logged in, redirect
    user = await get_current_user(request)
    if user:
        return RedirectResponse(url=next, status_code=302)

    error_messages = {
        "invalid": "Неверный логин или пароль",
        "expired": "Сессия истекла. Войдите снова.",
        "unavailable": "Сервис авторизации недоступен. Обратитесь в службу поддержки.",
    }

    return templates.TemplateResponse(
        "login.html",
        {"request": request, "next": next, "error_message": error_messages.get(error)}
    )


@app.post("/login")
async def login_post(
    request: Request,
    username: str = Form(...),
    password: str = Form(...),
    next: str = Form("/"),
):
    auth = get_auth_client()
    session_mgr = get_session_manager()

    result = await auth.authenticate(username.strip(), password)

    if not result.success:
        error = "unavailable" if result.error_code == "LDAP_UNREACHABLE" else "invalid"
        return RedirectResponse(url=f"/login?error={error}&next={next}", status_code=302)

    session = session_mgr.create_session(result.user)
    response = RedirectResponse(url=next, status_code=302)
    session_mgr.set_session_cookie(response, session)
    return response


@app.get("/logout")
async def logout(request: Request):
    session_mgr = get_session_manager()
    html = """
    <!DOCTYPE html>
    <html>
    <head><title>Выход...</title></head>
    <body>
    <script>
        window.location.replace('/login');
    </script>
    </body>
    </html>
    """
    response = HTMLResponse(html)
    session_mgr.logout(request, response)
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    return response


@app.get("/api/me")
async def me(request: Request):
    user = await get_current_user(request)
    if not user:
        return {"error": "Не авторизован"}
    return user.to_dict()


# ── Escalation Scheduler ─────────────────────────────────────────────
_sched_logger = logging.getLogger("dap.scheduler")


async def _run_escalation():
    """Direct escalation check — no HTTP, no auth needed."""
    from dataaudit.database import get_pool
    from dataaudit.routers.grc import (
        _get_config, _notify, _resolve_user_email,
        _escalation_email_html, get_email_service, _today,
    )

    pool = await get_pool()
    today = _today()

    escalation_config = await _get_config(pool, "escalation", "deadlines")
    thresholds = escalation_config.get("thresholds", [])

    tasks = await pool.fetch(
        """SELECT r.*, f.title as finding_title, f.ref_number as finding_ref,
                  u.head_user_id as unit_head
           FROM grc.remediation_tasks r
           LEFT JOIN grc.findings f ON r.finding_id = f.id
           LEFT JOIN grc.org_units u ON r.assigned_to_unit_id = u.id
           WHERE r.status NOT IN ('closed', 'cancelled', 'verified')
             AND r.escalation_enabled = TRUE
             AND (r.escalation_muted_until IS NULL OR r.escalation_muted_until < $1)""",
        today,
    )

    created = 0
    for task in tasks:
        deadline = task["deadline"]
        days_until = (deadline - today).days
        assignee = task["assigned_to_user_id"]
        unit_head = task["unit_head"]
        ref = task["ref_number"] or f"#{task['id']}"
        title = task["title"]

        if days_until < 0 and not task["is_overdue"]:
            await pool.execute(
                "UPDATE grc.remediation_tasks SET is_overdue=TRUE, updated_at=NOW() WHERE id=$1",
                task["id"],
            )

        for threshold in thresholds:
            matched = False
            ntype = threshold.get("type", "")
            if "days_before" in threshold:
                db = threshold["days_before"]
                if (db > 0 and days_until == db) or (db == 0 and days_until == 0):
                    matched = True
            if "days_after" in threshold and days_until < 0:
                if threshold.get("repeat") == "daily":
                    matched = True
                elif abs(days_until) == threshold["days_after"]:
                    matched = True
            if not matched:
                continue

            notify_targets = threshold.get("notify", [])
            overdue_days = abs(days_until) if days_until < 0 else 0
            msg_prefix = (
                f"Срок через {days_until} дн." if days_until > 0
                else "Срок сегодня" if days_until == 0
                else f"Просрочено {overdue_days} дн."
            )

            people = []
            if "assignee" in notify_targets and assignee:
                people.append((
                    assignee,
                    f"{msg_prefix}: {ref}",
                    f"Рекомендация «{title}» — срок до {deadline}",
                ))
            if "unit_head" in notify_targets and unit_head:
                people.append((
                    unit_head,
                    f"{msg_prefix}: {ref} (подчинённый)",
                    f"Рекомендация «{title}» назначена {assignee} — срок до {deadline}",
                ))

            for (uid, ntitle, nmessage) in people:
                existing = await pool.fetchval(
                    """SELECT COUNT(*) FROM grc.notifications
                       WHERE user_id=$1 AND notif_type=$2 AND entity_type='remediation'
                         AND entity_id=$3 AND created_at::date=$4""",
                    uid, ntype, task["id"], today,
                )
                if existing == 0:
                    await _notify(pool, uid, ntype, ntitle, nmessage, "remediation", task["id"])
                    created += 1
                    email_svc = get_email_service()
                    user_email = await _resolve_user_email(pool, uid)
                    if user_email:
                        email_svc.send(
                            to=user_email,
                            subject=f"DAP: {ntitle}",
                            body_text=f"{ntitle}\n\n{nmessage}\n\n— DataAudit Platform",
                            body_html=_escalation_email_html(ntitle, nmessage, ref, deadline),
                        )

    _sched_logger.info(f"Escalation check: {len(tasks)} tasks, {created} notifications")


async def _escalation_scheduler():
    """Run escalation daily at 09:00."""
    while True:
        now = datetime.now()
        target = datetime.combine(now.date(), dtime(9, 0))
        if now >= target:
            target += timedelta(days=1)
        wait = (target - now).total_seconds()
        _sched_logger.info(f"Next escalation: {target} (in {wait:.0f}s)")
        await asyncio.sleep(wait)
        try:
            await _run_escalation()
        except Exception as e:
            _sched_logger.error(f"Escalation failed: {e}")


@app.on_event("startup")
async def start_scheduler():
    if os.getenv("DAP_SCHEDULER", "false").lower() == "true":
        asyncio.create_task(_escalation_scheduler())


@app.get("/health")
async def health():
    return {"status": "ok"}