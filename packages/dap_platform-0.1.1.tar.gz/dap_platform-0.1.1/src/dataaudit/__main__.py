"""Allow `python -m dataaudit`."""
from .cli import main
main()
