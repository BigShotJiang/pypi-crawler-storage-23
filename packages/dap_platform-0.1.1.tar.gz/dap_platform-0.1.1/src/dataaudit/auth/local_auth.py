"""
Local authentication — single admin user for demo/library mode.
No LDAP, no AD, no external dependencies.
"""

from .models import User, Role, AuthResult

DEFAULT_USER = "admin"
DEFAULT_PASSWORD = "admin"


class LocalAuth:
    """Accepts admin/admin, returns an admin User."""

    async def authenticate(self, username: str, password: str) -> AuthResult:
        if username == DEFAULT_USER and password == DEFAULT_PASSWORD:
            user = User(
                user_id="admin",
                full_name="Администратор",
                email="admin@dataaudit.local",
                role=Role.ADMIN,
                groups=["DAP_Admins"]
            )
            return AuthResult(success=True, user=user)

        return AuthResult(
            success=False,
            error_message="Неверный логин или пароль",
            error_code="INVALID_CREDENTIALS"
        )


_client = None


def get_auth_client() -> LocalAuth:
    global _client
    if _client is None:
        _client = LocalAuth()
    return _client
