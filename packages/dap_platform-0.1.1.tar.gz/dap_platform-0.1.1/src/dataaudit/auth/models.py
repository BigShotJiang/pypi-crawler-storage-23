"""
DAP Authentication Models
"""
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional
from enum import Enum


class Role(str, Enum):
    """User roles: admin > manager > auditor > viewer"""
    ADMIN = "admin"
    MANAGER = "manager"
    AUDITOR = "auditor"
    VIEWER = "viewer"

    @classmethod
    def from_groups(cls, groups: list[str]) -> "Role":
        """Determine role from LDAP groups. Highest wins."""
        group_names = [g.upper() for g in groups]
        if "DAP_ADMINS" in group_names:
            return cls.ADMIN
        if "DAP_MANAGERS" in group_names:
            return cls.MANAGER
        if "DAP_AUDITORS" in group_names:
            return cls.AUDITOR
        return cls.VIEWER

    @property
    def display_name(self) -> str:
        names = {
            "admin": "Администратор",
            "manager": "Руководитель",
            "auditor": "Аудитор",
            "viewer": "Пользователь"
        }
        return names.get(self.value, self.value)


@dataclass
class User:
    """Authenticated user"""
    user_id: str
    full_name: str
    email: str
    role: Role
    groups: list[str] = field(default_factory=list)

    def has_role(self, required_role: Role) -> bool:
        """Check if user has at least the required role level."""
        hierarchy = {Role.VIEWER: 0, Role.AUDITOR: 1, Role.MANAGER: 2, Role.ADMIN: 3}
        return hierarchy[self.role] >= hierarchy[required_role]

    def to_dict(self) -> dict:
        return {
            "user_id": self.user_id,
            "full_name": self.full_name,
            "email": self.email,
            "role": self.role.value,
            "role_display": self.role.display_name,
            "groups": self.groups
        }

    @classmethod
    def from_dict(cls, data: dict) -> "User":
        return cls(
            user_id=data["user_id"],
            full_name=data["full_name"],
            email=data["email"],
            role=Role(data["role"]),
            groups=data.get("groups", [])
        )


@dataclass
class Session:
    """User session"""
    session_id: str
    user: User
    created_at: datetime
    expires_at: datetime

    @property
    def is_expired(self) -> bool:
        return datetime.utcnow() > self.expires_at


@dataclass
class AuthResult:
    """Authentication result"""
    success: bool
    user: Optional[User] = None
    error_message: Optional[str] = None
    error_code: Optional[str] = None