"""DAP Authentication Module"""

from .models import User, Role, Session, AuthResult
from .local_auth import LocalAuth, get_auth_client
from .session import SessionManager, get_session_manager
from .dependencies import (
    get_current_user,
    require_auth,
    require_role,
    auth_middleware,
    add_user_to_context,
)

__all__ = [
    "User", "Role", "Session", "AuthResult",
    "LocalAuth", "get_auth_client",
    "SessionManager", "get_session_manager",
    "get_current_user", "require_auth", "require_role",
    "auth_middleware", "add_user_to_context",
]
