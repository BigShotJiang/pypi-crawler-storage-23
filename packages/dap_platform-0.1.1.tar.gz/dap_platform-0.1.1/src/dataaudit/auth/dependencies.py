"""
DAP Authentication Dependencies
"""

from typing import Optional, List, Callable
from fastapi import Request, HTTPException
from fastapi.responses import RedirectResponse

from .models import User, Role
from .session import get_session_manager


async def get_current_user(request: Request) -> Optional[User]:
    """Get user from session, or None."""
    session = get_session_manager().get_session(request)
    return session.user if session else None


async def require_auth(request: Request) -> User:
    """Require authentication."""
    user = await get_current_user(request)
    if not user:
        raise HTTPException(401, "Требуется авторизация")
    return user


def require_role(roles: List[str]) -> Callable:
    """Require specific role(s)."""
    async def checker(request: Request) -> User:
        user = await require_auth(request)
        if user.role.value not in roles:
            raise HTTPException(403, "Доступ запрещён")
        return user
    return checker


# Paths that don't need auth
PUBLIC_PATHS = {"/login", "/health", "/favicon.ico"}
PUBLIC_PREFIXES = ("/static/",)


async def auth_middleware(request: Request, call_next):
    """Middleware to protect routes."""
    path = request.url.path
    
    # Allow public paths
    if path in PUBLIC_PATHS or path.startswith(PUBLIC_PREFIXES):
        response = await call_next(request)
        # Also prevent caching on login page
        if path == "/login":
            response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
            response.headers["Pragma"] = "no-cache"
            response.headers["Expires"] = "0"
        return response
    
    # Check session
    session = get_session_manager().get_session(request)
    
    if not session:
        if path.startswith("/api/"):
            from fastapi.responses import JSONResponse
            return JSONResponse(status_code=401, content={"detail": "Требуется авторизация"})
        return RedirectResponse(f"/login?next={path}", status_code=302)
    
    # Add user to request
    request.state.user = session.user
    response = await call_next(request)
    
    # Prevent caching of authenticated pages
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"
    
    return response


def add_user_to_context(request: Request) -> dict:
    """Add user to template context."""
    user = getattr(request.state, 'user', None)
    return {"user": user}
