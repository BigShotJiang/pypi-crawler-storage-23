"""
DAP Session Management
"""

import os
import secrets
import logging
from datetime import datetime, timedelta
from typing import Optional, Dict

from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from starlette.requests import Request
from starlette.responses import Response

from .models import User, Session

logger = logging.getLogger("dap.auth.session")


class SessionStore:
    """In-memory session storage."""
    
    def __init__(self):
        self._sessions: Dict[str, Session] = {}
    
    def create(self, user: User, hours: int = 8) -> Session:
        session = Session(
            session_id=secrets.token_urlsafe(32),
            user=user,
            created_at=datetime.utcnow(),
            expires_at=datetime.utcnow() + timedelta(hours=hours)
        )
        self._sessions[session.session_id] = session
        return session
    
    def get(self, session_id: str) -> Optional[Session]:
        session = self._sessions.get(session_id)
        if session and session.is_expired:
            del self._sessions[session_id]
            return None
        return session
    
    def delete(self, session_id: str):
        self._sessions.pop(session_id, None)


class SessionManager:
    """Session manager with signed cookies."""
    
    def __init__(self):
        self.secret = os.getenv("DAP_SESSION_SECRET", "dev-secret-change-me")
        self.hours = int(os.getenv("DAP_SESSION_HOURS", "8"))
        self.cookie_name = "dap_session"
        self.store = SessionStore()
        self._serializer = URLSafeTimedSerializer(self.secret)
        
        if self.secret == "dev-secret-change-me":
            logger.warning("Using default session secret!")
    
    def create_session(self, user: User) -> Session:
        return self.store.create(user, self.hours)
    
    def get_session(self, request: Request) -> Optional[Session]:
        cookie = request.cookies.get(self.cookie_name)
        if not cookie:
            return None
        try:
            session_id = self._serializer.loads(cookie, max_age=self.hours * 3600)
            return self.store.get(session_id)
        except (BadSignature, SignatureExpired):
            return None
    
    def set_session_cookie(self, response: Response, session: Session):
        signed = self._serializer.dumps(session.session_id)
        response.set_cookie(
            self.cookie_name, signed,
            httponly=True,
            samesite="lax",
            max_age=self.hours * 3600
        )
    
    def logout(self, request: Request, response: Response):
        session = self.get_session(request)
        if session:
            self.store.delete(session.session_id)
        response.delete_cookie(self.cookie_name)


_manager: Optional[SessionManager] = None

def get_session_manager() -> SessionManager:
    global _manager
    if _manager is None:
        _manager = SessionManager()
    return _manager
