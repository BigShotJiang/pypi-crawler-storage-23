"""
DAP Platform - My Reports Router
User personal report bookmarks
"""
from fastapi import APIRouter, Request, HTTPException
from pydantic import BaseModel
from typing import Optional

from dataaudit.database import get_pool
from dataaudit.auth import get_current_user

router = APIRouter(prefix="/api/my-reports", tags=["my-reports"])


class ReportCreate(BaseModel):
    title: str
    url: str
    description: Optional[str] = None


class ReportUpdate(BaseModel):
    title: Optional[str] = None
    url: Optional[str] = None
    description: Optional[str] = None


async def _get_username(request: Request) -> str:
    """Get current user's username from session."""
    user = await get_current_user(request)
    if not user:
        raise HTTPException(status_code=401, detail="Не авторизован")
    return user.user_id


@router.get("")
async def get_reports(request: Request):
    """Get all reports for current user."""
    try:
        username = await _get_username(request)
    except HTTPException:
        return {"error": "Не авторизован", "reports": []}

    try:
        pool = await get_pool()
        rows = await pool.fetch(
            """SELECT id, title, url, description, created_at, updated_at
               FROM config.user_reports
               WHERE user_id = $1
               ORDER BY position, created_at DESC""",
            username,
        )
        reports = []
        for row in rows:
            reports.append({
                "id": row["id"],
                "title": row["title"],
                "url": row["url"],
                "description": row["description"],
                "created_at": row["created_at"],
                "updated_at": row["updated_at"],
            })
        return {"reports": reports}

    except Exception as e:
        print(f"Database error: {e}")
        return {"error": "Ошибка базы данных", "reports": []}


@router.post("")
async def create_report(report: ReportCreate, request: Request):
    """Create a new report bookmark."""
    username = await _get_username(request)

    try:
        pool = await get_pool()
        row = await pool.fetchrow(
            """INSERT INTO config.user_reports (user_id, title, url, description)
               VALUES ($1, $2, $3, $4) RETURNING id""",
            username, report.title, report.url, report.description,
        )
        return {"id": row["id"], "message": "Отчёт добавлен"}

    except Exception as e:
        print(f"Database error: {e}")
        raise HTTPException(status_code=500, detail="Ошибка сохранения")


@router.put("/{report_id}")
async def update_report(report_id: int, report: ReportUpdate, request: Request):
    """Update an existing report."""
    username = await _get_username(request)

    pool = await get_pool()

    # Check ownership
    existing = await pool.fetchrow(
        "SELECT id FROM config.user_reports WHERE id = $1 AND user_id = $2",
        report_id, username,
    )
    if not existing:
        raise HTTPException(status_code=404, detail="Отчёт не найден")

    # Build dynamic update
    sets, vals, idx = [], [], 1
    for field in ("title", "url", "description"):
        v = getattr(report, field)
        if v is not None:
            sets.append(f"{field}=${idx}")
            vals.append(v)
            idx += 1

    if sets:
        sets.append(f"updated_at=datetime('now')")
        vals.append(report_id)
        await pool.execute(
            f"UPDATE config.user_reports SET {', '.join(sets)} WHERE id=${idx}",
            *vals,
        )

    return {"message": "Отчёт обновлён"}


@router.delete("/{report_id}")
async def delete_report(report_id: int, request: Request):
    """Delete a report."""
    username = await _get_username(request)

    pool = await get_pool()
    existing = await pool.fetchrow(
        "SELECT id FROM config.user_reports WHERE id = $1 AND user_id = $2",
        report_id, username,
    )
    if not existing:
        raise HTTPException(status_code=404, detail="Отчёт не найден")

    await pool.execute(
        "DELETE FROM config.user_reports WHERE id = $1 AND user_id = $2",
        report_id, username,
    )
    return {"message": "Отчёт удалён"}
