"""
DAP Platform — Native BI Module
SQL Lab · Charts · Dashboards
Supports PostgreSQL, Oracle, DuckDB, SQLite
"""

import os
import json
import asyncio
import logging
from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Request, HTTPException
from pydantic import BaseModel

from dataaudit.database import get_pool

logger = logging.getLogger("dap.bi")

router = APIRouter(prefix="/api/bi", tags=["bi"])


# ── helpers ───────────────────────────────────────────────────────

def _enc(plain: str) -> str:
    """Simple base64 encode — swap for real encryption in production."""
    return base64.b64encode(plain.encode()).decode()


def _dec(encoded: str) -> str:
    return base64.b64decode(encoded.encode()).decode()


def _user(request: Request):
    user = getattr(request.state, "user", None)
    if not user:
        raise HTTPException(401, "Требуется авторизация")
    return user


def _require_admin(request: Request):
    user = _user(request)
    if user.role.value not in ("admin", "manager"):
        raise HTTPException(403, "Доступ запрещён")
    return user


MAX_ROWS = 5000
QUERY_TIMEOUT = 30  # seconds


async def _execute_query(ds: dict, sql: str) -> dict:
    """
    Execute SQL against a configured datasource.
    Returns {"columns": [...], "rows": [[...], ...], "row_count": N, "truncated": bool}
    """
    engine = ds["engine"]

    if engine == "postgresql":
        return await _exec_pg(ds, sql)
    elif engine == "oracle":
        return await _exec_oracle(ds, sql)
    elif engine == "duckdb":
        return await _exec_duckdb(ds, sql)
    elif engine == "sqlite":
        return await _exec_sqlite(ds, sql)
    else:
        raise HTTPException(400, f"Неподдерживаемый движок: {engine}")


async def _exec_pg(ds: dict, sql: str) -> dict:
    conn = await asyncpg.connect(
        host=ds["host"],
        port=ds["port"] or 5432,
        user=ds["username"],
        password=_dec(ds["password_enc"]) if ds["password_enc"] else "",
        database=ds["database_name"],
        timeout=QUERY_TIMEOUT,
    )
    try:
        stmt = await conn.prepare(sql)
        columns = [a.name for a in stmt.get_attributes()]
        records = await stmt.fetch(timeout=QUERY_TIMEOUT)
        truncated = len(records) > MAX_ROWS
        rows = [list(r.values()) for r in records[:MAX_ROWS]]
        # Serialize special types
        rows = _serialize_rows(rows)
        return {"columns": columns, "rows": rows, "row_count": len(rows), "truncated": truncated}
    finally:
        await conn.close()


async def _exec_oracle(ds: dict, sql: str) -> dict:
    try:
        import oracledb
    except ImportError:
        raise HTTPException(500, "oracledb не установлен. Добавьте oracledb в requirements.txt")

    extra = ds.get("extra_params") or {}
    if isinstance(extra, str):
        extra = json.loads(extra)
    dsn = extra.get("dsn") or oracledb.makedsn(
        ds["host"],
        ds["port"] or 1521,
        service_name=extra.get("service_name", ds["database_name"]),
    )

    def _run():
        conn = oracledb.connect(
            user=ds["username"],
            password=_dec(ds["password_enc"]) if ds["password_enc"] else "",
            dsn=dsn,
        )
        cur = conn.cursor()
        cur.execute(sql)
        columns = [col[0] for col in cur.description] if cur.description else []
        rows_raw = cur.fetchmany(MAX_ROWS + 1)
        truncated = len(rows_raw) > MAX_ROWS
        rows = [list(r) for r in rows_raw[:MAX_ROWS]]
        rows = _serialize_rows(rows)
        cur.close()
        conn.close()
        return {"columns": columns, "rows": rows, "row_count": len(rows), "truncated": truncated}

    return await asyncio.get_event_loop().run_in_executor(None, _run)


async def _exec_duckdb(ds: dict, sql: str) -> dict:
    try:
        import duckdb
    except ImportError:
        raise HTTPException(500, "duckdb не установлен. Добавьте duckdb в requirements.txt")

    extra = ds.get("extra_params") or {}
    if isinstance(extra, str):
        extra = json.loads(extra)
    db_path = extra.get("path", ":memory:")

    def _run():
        conn = duckdb.connect(database=db_path, read_only=extra.get("read_only", True))
        cur = conn.execute(sql)
        columns = [desc[0] for desc in cur.description] if cur.description else []
        rows_raw = cur.fetchmany(MAX_ROWS + 1)
        truncated = len(rows_raw) > MAX_ROWS
        rows = [list(r) for r in rows_raw[:MAX_ROWS]]
        rows = _serialize_rows(rows)
        conn.close()
        return {"columns": columns, "rows": rows, "row_count": len(rows), "truncated": truncated}

    return await asyncio.get_event_loop().run_in_executor(None, _run)


async def _exec_sqlite(ds: dict, sql: str) -> dict:
    """Execute SQL against a SQLite datasource."""
    import sqlite3 as _sqlite3

    extra = ds.get("extra_params") or {}
    if isinstance(extra, str):
        extra = json.loads(extra)
    db_path = extra.get("path", ":memory:")

    def _run():
        conn = _sqlite3.connect(db_path)
        cursor = conn.execute(sql)
        columns = [desc[0] for desc in cursor.description] if cursor.description else []
        rows_raw = cursor.fetchmany(MAX_ROWS + 1)
        truncated = len(rows_raw) > MAX_ROWS
        rows = [list(r) for r in rows_raw[:MAX_ROWS]]
        rows = _serialize_rows(rows)
        conn.close()
        return {"columns": columns, "rows": rows, "row_count": len(rows), "truncated": truncated}

    return await asyncio.get_event_loop().run_in_executor(None, _run)


def _serialize_rows(rows: list) -> list:
    """Convert non-JSON-serializable types to strings."""
    out = []
    for row in rows:
        new_row = []
        for val in row:
            if val is None:
                new_row.append(None)
            elif isinstance(val, (datetime,)):
                new_row.append(val.isoformat())
            elif isinstance(val, (int, float, bool, str)):
                new_row.append(val)
            elif isinstance(val, bytes):
                new_row.append(f"<bytes {len(val)}>")
            else:
                new_row.append(str(val))
        out.append(new_row)
    return out


# ══════════════════════════════════════════════════════════════════
#  DATASOURCES
# ══════════════════════════════════════════════════════════════════

class DatasourceCreate(BaseModel):
    name: str
    engine: str  # postgresql | oracle | duckdb
    host: Optional[str] = None
    port: Optional[int] = None
    database_name: Optional[str] = None
    username: Optional[str] = None
    password: Optional[str] = None
    extra_params: Optional[dict] = None


class DatasourceUpdate(BaseModel):
    name: Optional[str] = None
    host: Optional[str] = None
    port: Optional[int] = None
    database_name: Optional[str] = None
    username: Optional[str] = None
    password: Optional[str] = None
    extra_params: Optional[dict] = None


@router.get("/datasources")
async def list_datasources(request: Request):
    _user(request)
    pool = await get_pool()
    rows = await pool.fetch(
        "SELECT id, name, engine, host, port, database_name, username, extra_params, created_by, created_at "
        "FROM bi.datasources ORDER BY name"
    )
    return [dict(r) for r in rows]


@router.post("/datasources")
async def create_datasource(request: Request, data: DatasourceCreate):
    user = _require_admin(request)
    if data.engine not in ("postgresql", "oracle", "duckdb"):
        raise HTTPException(400, "Движок должен быть: postgresql, oracle, duckdb")
    pool = await get_pool()
    row = await pool.fetchrow(
        """INSERT INTO bi.datasources (name, engine, host, port, database_name, username, password_enc, extra_params, created_by)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id""",
        data.name, data.engine, data.host, data.port, data.database_name,
        data.username, _enc(data.password) if data.password else None,
        json.dumps(data.extra_params or {}), user.user_id,
    )
    return {"id": row["id"]}


@router.put("/datasources/{ds_id}")
async def update_datasource(request: Request, ds_id: int, data: DatasourceUpdate):
    _require_admin(request)
    pool = await get_pool()
    existing = await pool.fetchrow("SELECT id FROM bi.datasources WHERE id=$1", ds_id)
    if not existing:
        raise HTTPException(404, "Источник не найден")

    sets, vals, idx = [], [], 1
    for field in ("name", "host", "port", "database_name", "username"):
        v = getattr(data, field)
        if v is not None:
            sets.append(f"{field}=${idx}")
            vals.append(v)
            idx += 1
    if data.password is not None:
        sets.append(f"password_enc=${idx}")
        vals.append(_enc(data.password))
        idx += 1
    if data.extra_params is not None:
        sets.append(f"extra_params=${idx}")
        vals.append(json.dumps(data.extra_params))
        idx += 1
    if not sets:
        return {"status": "nothing to update"}
    sets.append(f"updated_at=${idx}")
    vals.append(datetime.utcnow())
    idx += 1
    vals.append(ds_id)
    await pool.execute(f"UPDATE bi.datasources SET {','.join(sets)} WHERE id=${idx}", *vals)
    return {"status": "ok"}


@router.delete("/datasources/{ds_id}")
async def delete_datasource(request: Request, ds_id: int):
    _require_admin(request)
    pool = await get_pool()
    await pool.execute("DELETE FROM bi.datasources WHERE id=$1", ds_id)
    return {"status": "ok"}


@router.post("/datasources/{ds_id}/test")
async def test_datasource(request: Request, ds_id: int):
    _user(request)
    pool = await get_pool()
    row = await pool.fetchrow("SELECT * FROM bi.datasources WHERE id=$1", ds_id)
    if not row:
        raise HTTPException(404, "Источник не найден")
    ds = dict(row)
    try:
        result = await _execute_query(ds, "SELECT 1 AS ok")
        return {"status": "ok", "message": "Подключение успешно"}
    except Exception as e:
        return {"status": "error", "message": str(e)}


# ══════════════════════════════════════════════════════════════════
#  SQL EXECUTION
# ══════════════════════════════════════════════════════════════════

class QueryRun(BaseModel):
    datasource_id: int
    sql: str


class QuerySave(BaseModel):
    title: str
    description: Optional[str] = None
    datasource_id: int
    sql_text: str
    is_public: bool = False


@router.post("/query/run")
async def run_query(request: Request, data: QueryRun):
    _user(request)
    pool = await get_pool()
    ds_row = await pool.fetchrow("SELECT * FROM bi.datasources WHERE id=$1", data.datasource_id)
    if not ds_row:
        raise HTTPException(404, "Источник данных не найден")

    sql = data.sql.strip().rstrip(";")

    # Basic safety: block DDL/DML for non-admins
    user = _user(request)
    first_word = sql.split()[0].upper() if sql.split() else ""
    dangerous = {"DROP", "DELETE", "TRUNCATE", "ALTER", "CREATE", "INSERT", "UPDATE", "GRANT", "REVOKE"}
    if first_word in dangerous and user.role.value not in ("admin",):
        raise HTTPException(403, f"Операция {first_word} запрещена для вашей роли")

    try:
        result = await _execute_query(dict(ds_row), sql)
        return result
    except Exception as e:
        return {"error": True, "message": str(e)}


@router.get("/queries")
async def list_saved_queries(request: Request):
    user = _user(request)
    pool = await get_pool()
    rows = await pool.fetch(
        """SELECT q.*, d.name as datasource_name
           FROM bi.saved_queries q
           LEFT JOIN bi.datasources d ON q.datasource_id = d.id
           WHERE q.created_by = $1 OR q.is_public = true
           ORDER BY q.updated_at DESC""",
        user.user_id,
    )
    return [dict(r) for r in rows]


@router.post("/queries")
async def save_query(request: Request, data: QuerySave):
    user = _user(request)
    pool = await get_pool()
    row = await pool.fetchrow(
        """INSERT INTO bi.saved_queries (title, description, datasource_id, sql_text, created_by, is_public)
           VALUES ($1,$2,$3,$4,$5,$6) RETURNING id""",
        data.title, data.description, data.datasource_id, data.sql_text, user.user_id, data.is_public,
    )
    return {"id": row["id"]}


@router.delete("/queries/{query_id}")
async def delete_query(request: Request, query_id: int):
    user = _user(request)
    pool = await get_pool()
    await pool.execute(
        "DELETE FROM bi.saved_queries WHERE id=$1 AND (created_by=$2 OR $3)",
        query_id, user.user_id, user.role.value == "admin",
    )
    return {"status": "ok"}


# ══════════════════════════════════════════════════════════════════
#  CHARTS
# ══════════════════════════════════════════════════════════════════

class ChartCreate(BaseModel):
    title: str
    description: Optional[str] = None
    datasource_id: int
    sql_text: str
    chart_type: str  # bar, line, pie, area, scatter, table, metric
    chart_config: Optional[dict] = None
    is_public: bool = False


class ChartUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    sql_text: Optional[str] = None
    chart_type: Optional[str] = None
    chart_config: Optional[dict] = None
    is_public: Optional[bool] = None


@router.get("/charts")
async def list_charts(request: Request):
    user = _user(request)
    pool = await get_pool()
    rows = await pool.fetch(
        """SELECT c.*, d.name as datasource_name
           FROM bi.charts c
           LEFT JOIN bi.datasources d ON c.datasource_id = d.id
           WHERE c.created_by = $1 OR c.is_public = true
           ORDER BY c.updated_at DESC""",
        user.user_id,
    )
    return [dict(r) for r in rows]


@router.get("/charts/{chart_id}")
async def get_chart(request: Request, chart_id: int):
    user = _user(request)
    pool = await get_pool()
    row = await pool.fetchrow(
        """SELECT c.*, d.name as datasource_name
           FROM bi.charts c
           LEFT JOIN bi.datasources d ON c.datasource_id = d.id
           WHERE c.id = $1 AND (c.created_by = $2 OR c.is_public = true OR $3)""",
        chart_id, user.user_id, user.role.value == "admin",
    )
    if not row:
        raise HTTPException(404, "График не найден")
    return dict(row)


@router.post("/charts")
async def create_chart(request: Request, data: ChartCreate):
    user = _user(request)
    pool = await get_pool()
    row = await pool.fetchrow(
        """INSERT INTO bi.charts (title, description, datasource_id, sql_text, chart_type, chart_config, created_by, is_public)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id""",
        data.title, data.description, data.datasource_id, data.sql_text,
        data.chart_type, json.dumps(data.chart_config or {}),
        user.user_id, data.is_public,
    )
    return {"id": row["id"]}


@router.put("/charts/{chart_id}")
async def update_chart(request: Request, chart_id: int, data: ChartUpdate):
    user = _user(request)
    pool = await get_pool()
    existing = await pool.fetchrow(
        "SELECT id FROM bi.charts WHERE id=$1 AND (created_by=$2 OR $3)",
        chart_id, user.user_id, user.role.value == "admin",
    )
    if not existing:
        raise HTTPException(404, "График не найден")

    sets, vals, idx = [], [], 1
    for field in ("title", "description", "sql_text", "chart_type", "is_public"):
        v = getattr(data, field, None)
        if v is not None:
            sets.append(f"{field}=${idx}")
            vals.append(v)
            idx += 1
    if data.chart_config is not None:
        sets.append(f"chart_config=${idx}")
        vals.append(json.dumps(data.chart_config))
        idx += 1
    if not sets:
        return {"status": "nothing to update"}
    sets.append(f"updated_at=${idx}")
    vals.append(datetime.utcnow())
    idx += 1
    vals.append(chart_id)
    await pool.execute(f"UPDATE bi.charts SET {','.join(sets)} WHERE id=${idx}", *vals)
    return {"status": "ok"}


@router.delete("/charts/{chart_id}")
async def delete_chart(request: Request, chart_id: int):
    user = _user(request)
    pool = await get_pool()
    await pool.execute(
        "DELETE FROM bi.charts WHERE id=$1 AND (created_by=$2 OR $3)",
        chart_id, user.user_id, user.role.value == "admin",
    )
    return {"status": "ok"}


@router.post("/charts/{chart_id}/data")
async def get_chart_data(request: Request, chart_id: int):
    """Execute a chart's query and return fresh data."""
    user = _user(request)
    pool = await get_pool()

    chart = await pool.fetchrow(
        """SELECT id, datasource_id, sql_text, created_by, is_public
           FROM bi.charts WHERE id = $1 AND (created_by = $2 OR is_public = true OR $3)""",
        chart_id, user.user_id, user.role.value == "admin",
    )
    if not chart:
        raise HTTPException(404, "График не найден")

    ds = await pool.fetchrow(
        "SELECT * FROM bi.datasources WHERE id = $1", chart["datasource_id"],
    )
    if not ds:
        raise HTTPException(404, "Источник данных графика не найден")

    try:
        return await _execute_query(dict(ds), chart["sql_text"])
    except Exception as e:
        return {"error": True, "message": str(e)}


# ══════════════════════════════════════════════════════════════════
#  DASHBOARDS
# ══════════════════════════════════════════════════════════════════

class DashboardCreate(BaseModel):
    title: str
    description: Optional[str] = None
    published: bool = False


class DashboardUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    published: Optional[bool] = None


class DashboardChartAdd(BaseModel):
    chart_id: int
    pos_x: int = 0
    pos_y: int = 0
    width: int = 6
    height: int = 4


class DashboardLayoutUpdate(BaseModel):
    items: list  # [{chart_id, pos_x, pos_y, width, height}, ...]


@router.get("/dashboards")
async def list_dashboards(request: Request):
    user = _user(request)
    pool = await get_pool()
    rows = await pool.fetch(
        """SELECT d.*, 
                  (SELECT COUNT(*) FROM bi.dashboard_charts dc WHERE dc.dashboard_id = d.id) as chart_count
           FROM bi.dashboards d
           WHERE d.created_by = $1 OR d.published = true OR $2
           ORDER BY d.updated_at DESC""",
        user.user_id, user.role.value == "admin",
    )
    return [dict(r) for r in rows]


@router.get("/dashboards/{dash_id}")
async def get_dashboard(request: Request, dash_id: int):
    user = _user(request)
    pool = await get_pool()
    dash = await pool.fetchrow(
        """SELECT * FROM bi.dashboards WHERE id=$1 AND (created_by=$2 OR published=true OR $3)""",
        dash_id, user.user_id, user.role.value == "admin",
    )
    if not dash:
        raise HTTPException(404, "Дашборд не найден")

    charts = await pool.fetch(
        """SELECT dc.*, c.title as chart_title, c.chart_type, c.datasource_id, c.sql_text, c.chart_config,
                  ds.name as datasource_name
           FROM bi.dashboard_charts dc
           JOIN bi.charts c ON dc.chart_id = c.id
           LEFT JOIN bi.datasources ds ON c.datasource_id = ds.id
           WHERE dc.dashboard_id = $1
           ORDER BY dc.pos_y, dc.pos_x""",
        dash_id,
    )

    return {**dict(dash), "charts": [dict(c) for c in charts]}


@router.post("/dashboards")
async def create_dashboard(request: Request, data: DashboardCreate):
    user = _user(request)
    pool = await get_pool()
    row = await pool.fetchrow(
        """INSERT INTO bi.dashboards (title, description, created_by, published)
           VALUES ($1,$2,$3,$4) RETURNING id""",
        data.title, data.description, user.user_id, data.published,
    )
    return {"id": row["id"]}


@router.put("/dashboards/{dash_id}")
async def update_dashboard(request: Request, dash_id: int, data: DashboardUpdate):
    user = _user(request)
    pool = await get_pool()
    existing = await pool.fetchrow(
        "SELECT id FROM bi.dashboards WHERE id=$1 AND (created_by=$2 OR $3)",
        dash_id, user.user_id, user.role.value == "admin",
    )
    if not existing:
        raise HTTPException(404, "Дашборд не найден")
    sets, vals, idx = [], [], 1
    for field in ("title", "description", "published"):
        v = getattr(data, field, None)
        if v is not None:
            sets.append(f"{field}=${idx}")
            vals.append(v)
            idx += 1
    if sets:
        sets.append(f"updated_at=${idx}")
        vals.append(datetime.utcnow())
        idx += 1
        vals.append(dash_id)
        await pool.execute(f"UPDATE bi.dashboards SET {','.join(sets)} WHERE id=${idx}", *vals)
    return {"status": "ok"}


@router.delete("/dashboards/{dash_id}")
async def delete_dashboard(request: Request, dash_id: int):
    user = _user(request)
    pool = await get_pool()
    await pool.execute(
        "DELETE FROM bi.dashboards WHERE id=$1 AND (created_by=$2 OR $3)",
        dash_id, user.user_id, user.role.value == "admin",
    )
    return {"status": "ok"}


@router.post("/dashboards/{dash_id}/charts")
async def add_chart_to_dashboard(request: Request, dash_id: int, data: DashboardChartAdd):
    user = _user(request)
    pool = await get_pool()
    dash = await pool.fetchrow(
        "SELECT id FROM bi.dashboards WHERE id=$1 AND (created_by=$2 OR $3)",
        dash_id, user.user_id, user.role.value == "admin",
    )
    if not dash:
        raise HTTPException(404, "Дашборд не найден")
    await pool.execute(
        """INSERT INTO bi.dashboard_charts (dashboard_id, chart_id, pos_x, pos_y, width, height)
           VALUES ($1,$2,$3,$4,$5,$6) ON CONFLICT (dashboard_id, chart_id) DO UPDATE
           SET pos_x=$3, pos_y=$4, width=$5, height=$6""",
        dash_id, data.chart_id, data.pos_x, data.pos_y, data.width, data.height,
    )
    return {"status": "ok"}


@router.delete("/dashboards/{dash_id}/charts/{chart_id}")
async def remove_chart_from_dashboard(request: Request, dash_id: int, chart_id: int):
    user = _user(request)
    pool = await get_pool()
    await pool.execute(
        "DELETE FROM bi.dashboard_charts WHERE dashboard_id=$1 AND chart_id=$2", dash_id, chart_id,
    )
    return {"status": "ok"}


@router.put("/dashboards/{dash_id}/layout")
async def update_dashboard_layout(request: Request, dash_id: int, data: DashboardLayoutUpdate):
    user = _user(request)
    pool = await get_pool()
    dash = await pool.fetchrow(
        "SELECT id FROM bi.dashboards WHERE id=$1 AND (created_by=$2 OR $3)",
        dash_id, user.user_id, user.role.value == "admin",
    )
    if not dash:
        raise HTTPException(404, "Дашборд не найден")
    async with pool.acquire() as conn:
        async with conn.transaction():
            for item in data.items:
                await conn.execute(
                    """UPDATE bi.dashboard_charts
                       SET pos_x=$1, pos_y=$2, width=$3, height=$4
                       WHERE dashboard_id=$5 AND chart_id=$6""",
                    item.get("pos_x", 0), item.get("pos_y", 0),
                    item.get("width", 6), item.get("height", 4),
                    dash_id, item["chart_id"],
                )
    return {"status": "ok"}
