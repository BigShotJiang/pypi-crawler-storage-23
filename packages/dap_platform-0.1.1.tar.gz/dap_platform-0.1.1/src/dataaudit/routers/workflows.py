"""
DAP Platform — GRC Workflows Router
Native audit workflow engine (replaces Flowable)
"""
from fastapi import APIRouter, Request
from dataaudit.auth import get_current_user

router = APIRouter(prefix="/api/workflows", tags=["workflows"])


def get_user_role(user) -> str:
    """Extract role from user object"""
    if not user:
        return "viewer"
    groups = getattr(user, 'groups', []) or []
    if 'DAP_Admins' in [g.upper() for g in groups]:
        return 'admin'
    elif 'DAP_Managers' in [g.upper() for g in groups]:
        return 'manager'
    elif 'DAP_Auditors' in [g.upper() for g in groups]:
        return 'auditor'
    else:
        return 'viewer'


@router.get("/stats")
async def get_workflow_stats(request: Request):
    """Basic workflow stats — delegates to GRC dashboard for detailed data"""
    user = await get_current_user(request)
    if not user:
        return {"error": "Не авторизован"}
    role = get_user_role(user)
    return {
        "role": role,
        "engine": "native",
        "version": "1.0.0"
    }
