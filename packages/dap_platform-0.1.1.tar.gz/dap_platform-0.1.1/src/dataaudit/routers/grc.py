"""
DAP Platform — Native GRC Module
Audit Plans · Engagements · Findings · Remediation · Escalation

Phase 1A: Config-driven foundation — transitions, status labels, and
escalation thresholds are loaded from grc.workflow_configs / grc.enum_definitions
with a 5-minute TTL in-memory cache.
"""

import json
import logging
import os
import time
import uuid
from datetime import datetime, date, timedelta
from typing import Optional

from fastapi import APIRouter, Request, HTTPException, UploadFile, File, Form as FastForm
from fastapi.responses import FileResponse
from pydantic import BaseModel

# Reuse the BI module's connection pool (same database)
from dataaudit.database import get_pool
from dataaudit.services.email import get_email_service
from dataaudit.services.docgen import generate_audit_report, generate_remediation_order

logger = logging.getLogger("dap.grc")

router = APIRouter(prefix="/api/grc", tags=["grc"])

# ── Attachments storage path ─────────────────────────
ATTACHMENTS_PATH = os.getenv("ATTACHMENTS_PATH", "./data/attachments")
MAX_UPLOAD_SIZE = 20 * 1024 * 1024  # 20 MB


# ══════════════════════════════════════════════════════════════════════
#  HELPERS
# ══════════════════════════════════════════════════════════════════════

def _user(request: Request):
    user = getattr(request.state, "user", None)
    if not user:
        raise HTTPException(401, "Требуется авторизация")
    return user


def _require_admin(request: Request):
    user = _user(request)
    if user.role.value not in ("admin",):
        raise HTTPException(403, "Доступ запрещён — требуется роль Администратора")
    return user


def _require_manager(request: Request):
    user = _user(request)
    if user.role.value not in ("admin", "manager"):
        raise HTTPException(403, "Доступ запрещён — требуется роль Руководителя")
    return user


def _require_auditor(request: Request):
    user = _user(request)
    if user.role.value not in ("admin", "manager", "auditor"):
        raise HTTPException(403, "Доступ запрещён — требуется роль Аудитора")
    return user


def _today() -> date:
    return date.today()


# ── Config Cache (DB-driven, replaces hardcoded dicts) ────────────

_config_cache: dict = {}
_CONFIG_TTL = 300  # 5 minutes


async def _get_config(pool, config_type: str, config_key: str) -> dict:
    """Load a workflow config from DB with TTL cache."""
    cache_key = f"{config_type}:{config_key}"
    now = time.time()
    if cache_key in _config_cache:
        data, ts = _config_cache[cache_key]
        if now - ts < _CONFIG_TTL:
            return data
    row = await pool.fetchrow(
        """SELECT config FROM grc.workflow_configs
           WHERE config_type=$1 AND config_key=$2 AND is_active=TRUE""",
        config_type, config_key,
    )
    data = (row["config"] if isinstance(row["config"], dict) else json.loads(row["config"])) if row else {}
    _config_cache[cache_key] = (data, now)
    return data


async def _get_enums(pool, category: str) -> dict:
    """Return {key: label} for an enum category, with TTL cache."""
    cache_key = f"enum:{category}"
    now = time.time()
    if cache_key in _config_cache:
        data, ts = _config_cache[cache_key]
        if now - ts < _CONFIG_TTL:
            return data
    rows = await pool.fetch(
        """SELECT key, label, metadata FROM grc.enum_definitions
           WHERE category=$1 AND is_active=TRUE ORDER BY sort_order""",
        category,
    )
    data = {r["key"]: r["label"] for r in rows}
    _config_cache[cache_key] = (data, now)
    return data


def _invalidate_cache(prefix: str = ""):
    """Drop cached entries. Call after any config/enum update."""
    if prefix:
        keys_to_delete = [k for k in _config_cache if k.startswith(prefix)]
        for k in keys_to_delete:
            del _config_cache[k]
    else:
        _config_cache.clear()


# ── Role hierarchy (stays in code — it's authorization logic) ─────

ROLE_HIERARCHY = {"viewer": 0, "auditor": 1, "manager": 2, "admin": 3}


def _check_role(user, min_role: str) -> bool:
    return ROLE_HIERARCHY.get(user.role.value, 0) >= ROLE_HIERARCHY.get(min_role, 0)


# ── State Machine Validation (now async, reads from DB) ───────────

async def _validate_transition(pool, entity_type: str, current: str, target: str):
    """Validate a status transition against DB-stored workflow config."""
    transitions = await _get_config(pool, "transitions", entity_type)
    raw = transitions.get(current, [])
    # Config may be flat list ["status1"] or nested {"allowed": ["status1"], "label": "..."}
    allowed = raw.get("allowed", raw) if isinstance(raw, dict) else raw
    if target not in allowed:
        labels = await _get_enums(pool, "status_label")
        current_label = labels.get(current, current)
        target_label = labels.get(target, target)
        raise HTTPException(
            400,
            f"Переход «{current_label}» → «{target_label}» невозможен"
        )


# ── Logging helpers ──────────────────────────────────────────────

async def _log_activity(
    pool, entity_type: str, entity_id: int, action: str,
    actor_id: str, actor_name: str = "",
    old_value: str = None, new_value: str = None, details: dict = None
):
    await pool.execute(
        """INSERT INTO grc.activity_log
           (entity_type, entity_id, action, actor_id, actor_name, old_value, new_value, details)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8)""",
        entity_type, entity_id, action, actor_id, actor_name,
        old_value, new_value, json.dumps(details) if details else None,
    )


async def _notify(
    pool, user_id: str, notif_type: str, title: str,
    message: str = None, entity_type: str = None, entity_id: int = None
):
    await pool.execute(
        """INSERT INTO grc.notifications
           (user_id, notif_type, title, message, entity_type, entity_id)
           VALUES ($1,$2,$3,$4,$5,$6)""",
        user_id, notif_type, title, message, entity_type, entity_id,
    )


async def _resolve_user_email(pool, user_id: str) -> Optional[str]:
    """
    Resolve user_id to email address.
    In dev: uses user_id@dap.local (Mailtrap catches all addresses).
    In production: will query AD or a users table.
    """
    # TODO: In production, look up email from AD or a local users cache table.
    # For now, convention-based:
    if not user_id:
        return None
    if "@" in user_id:
        return user_id
    return f"{user_id}@dap.local"


def _escalation_email_html(title: str, message: str, ref: str, deadline) -> str:
    """Generate a simple HTML email body for escalation notifications."""
    return f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"></head>
<body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; margin: 0; padding: 20px; background: #f8fafc;">
  <div style="max-width: 560px; margin: 0 auto; background: white; border-radius: 8px; border: 1px solid #e2e8f0; overflow: hidden;">
    <div style="background: #1e3a8a; color: white; padding: 16px 24px;">
      <strong style="font-size: 14px;">DataAudit Platform</strong>
    </div>
    <div style="padding: 24px;">
      <h2 style="margin: 0 0 8px; font-size: 18px; color: #1e293b;">{title}</h2>
      <p style="margin: 0 0 16px; font-size: 14px; color: #64748b;">{message}</p>
      <table style="width: 100%; font-size: 14px; border-collapse: collapse;">
        <tr>
          <td style="padding: 8px 0; color: #64748b;">Рекомендация:</td>
          <td style="padding: 8px 0; font-weight: 600; color: #1e293b;">{ref}</td>
        </tr>
        <tr>
          <td style="padding: 8px 0; color: #64748b;">Срок:</td>
          <td style="padding: 8px 0; font-weight: 600; color: #dc2626;">{deadline}</td>
        </tr>
      </table>
    </div>
    <div style="padding: 16px 24px; background: #f8fafc; border-top: 1px solid #e2e8f0; font-size: 12px; color: #94a3b8;">
      Это автоматическое уведомление от DataAudit Platform. Не отвечайте на это письмо.
    </div>
  </div>
</body></html>"""


# ══════════════════════════════════════════════════════════════════════
#  ORG UNITS
# ══════════════════════════════════════════════════════════════════════

class OrgUnitCreate(BaseModel):
    name: str
    code: Optional[str] = None
    parent_id: Optional[int] = None
    unit_type: str = "department"
    head_user_id: Optional[str] = None
    deputy_user_id: Optional[str] = None
    description: Optional[str] = None
    is_audit_unit: bool = False


class OrgUnitUpdate(BaseModel):
    name: Optional[str] = None
    code: Optional[str] = None
    parent_id: Optional[int] = None
    unit_type: Optional[str] = None
    head_user_id: Optional[str] = None
    deputy_user_id: Optional[str] = None
    description: Optional[str] = None
    is_audit_unit: Optional[bool] = None


@router.get("/org-units")
async def list_org_units(request: Request):
    _user(request)
    pool = await get_pool()
    rows = await pool.fetch(
        """SELECT o.*, p.name as parent_name
           FROM grc.org_units o
           LEFT JOIN grc.org_units p ON o.parent_id = p.id
           ORDER BY o.is_audit_unit DESC, o.name"""
    )
    return [dict(r) for r in rows]


@router.get("/org-units/{unit_id}")
async def get_org_unit(request: Request, unit_id: int):
    _user(request)
    pool = await get_pool()
    row = await pool.fetchrow(
        """SELECT o.*, p.name as parent_name
           FROM grc.org_units o
           LEFT JOIN grc.org_units p ON o.parent_id = p.id
           WHERE o.id = $1""", unit_id
    )
    if not row:
        raise HTTPException(404, "Подразделение не найдено")
    return dict(row)


@router.post("/org-units")
async def create_org_unit(request: Request, data: OrgUnitCreate):
    user = _require_admin(request)
    pool = await get_pool()
    row = await pool.fetchrow(
        """INSERT INTO grc.org_units
           (name, code, parent_id, unit_type, head_user_id, deputy_user_id, description, is_audit_unit)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id""",
        data.name, data.code, data.parent_id, data.unit_type,
        data.head_user_id, data.deputy_user_id, data.description, data.is_audit_unit,
    )
    await _log_activity(pool, "org_unit", row["id"], "created", user.user_id, user.full_name)
    return {"id": row["id"]}


@router.put("/org-units/{unit_id}")
async def update_org_unit(request: Request, unit_id: int, data: OrgUnitUpdate):
    user = _require_admin(request)
    pool = await get_pool()
    existing = await pool.fetchrow("SELECT id FROM grc.org_units WHERE id=$1", unit_id)
    if not existing:
        raise HTTPException(404, "Подразделение не найдено")
    sets, vals, idx = [], [], 1
    for field in ("name", "code", "parent_id", "unit_type", "head_user_id",
                  "deputy_user_id", "description", "is_audit_unit"):
        v = getattr(data, field, None)
        if v is not None:
            sets.append(f"{field}=${idx}")
            vals.append(v)
            idx += 1
    if not sets:
        return {"status": "nothing to update"}
    sets.append(f"updated_at=${idx}"); vals.append(datetime.utcnow()); idx += 1
    vals.append(unit_id)
    await pool.execute(
        f"UPDATE grc.org_units SET {','.join(sets)} WHERE id=${idx}", *vals
    )
    await _log_activity(pool, "org_unit", unit_id, "updated", user.user_id, user.full_name)
    return {"status": "ok"}


@router.delete("/org-units/{unit_id}")
async def delete_org_unit(request: Request, unit_id: int):
    user = _require_admin(request)
    pool = await get_pool()
    await pool.execute("DELETE FROM grc.org_units WHERE id=$1", unit_id)
    await _log_activity(pool, "org_unit", unit_id, "deleted", user.user_id, user.full_name)
    return {"status": "ok"}


# ══════════════════════════════════════════════════════════════════════
#  AUDIT PLANS
# ══════════════════════════════════════════════════════════════════════

class PlanCreate(BaseModel):
    year: int
    title: str
    description: Optional[str] = None


class PlanUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None


class StatusTransition(BaseModel):
    new_status: str
    comment: Optional[str] = None


@router.get("/plans")
async def list_plans(request: Request):
    user = _user(request)
    pool = await get_pool()
    # Admin/manager see all; auditor sees plans with their engagements
    if _check_role(user, "manager"):
        rows = await pool.fetch(
            """SELECT p.*,
                      (SELECT COUNT(*) FROM grc.engagements e WHERE e.plan_id = p.id) as engagement_count
               FROM grc.audit_plans p ORDER BY p.year DESC, p.created_at DESC"""
        )
    else:
        rows = await pool.fetch(
            """SELECT DISTINCT p.*,
                      (SELECT COUNT(*) FROM grc.engagements e WHERE e.plan_id = p.id) as engagement_count
               FROM grc.audit_plans p
               JOIN grc.engagements e ON e.plan_id = p.id
               LEFT JOIN grc.engagement_members em ON em.engagement_id = e.id
               WHERE e.lead_auditor_id = $1 OR em.user_id = $1
               ORDER BY p.year DESC, p.created_at DESC""",
            user.user_id,
        )
    return [dict(r) for r in rows]


@router.get("/plans/{plan_id}")
async def get_plan(request: Request, plan_id: int):
    user = _user(request)
    pool = await get_pool()
    plan = await pool.fetchrow("SELECT * FROM grc.audit_plans WHERE id=$1", plan_id)
    if not plan:
        raise HTTPException(404, "План не найден")
    engagements = await pool.fetch(
        """SELECT e.*,
                  au.name as audit_unit_name,
                  tu.name as target_unit_name,
                  (SELECT COUNT(*) FROM grc.findings f WHERE f.engagement_id = e.id) as finding_count
           FROM grc.engagements e
           LEFT JOIN grc.org_units au ON e.audit_unit_id = au.id
           LEFT JOIN grc.org_units tu ON e.target_unit_id = tu.id
           WHERE e.plan_id = $1
           ORDER BY e.planned_start, e.title""",
        plan_id,
    )
    return {**dict(plan), "engagements": [dict(e) for e in engagements]}


@router.post("/plans")
async def create_plan(request: Request, data: PlanCreate):
    user = _require_manager(request)
    pool = await get_pool()
    row = await pool.fetchrow(
        """INSERT INTO grc.audit_plans (year, title, description, created_by)
           VALUES ($1,$2,$3,$4) RETURNING id""",
        data.year, data.title, data.description, user.user_id,
    )
    await _log_activity(pool, "plan", row["id"], "created", user.user_id, user.full_name)
    return {"id": row["id"]}


@router.put("/plans/{plan_id}")
async def update_plan(request: Request, plan_id: int, data: PlanUpdate):
    user = _require_manager(request)
    pool = await get_pool()
    existing = await pool.fetchrow("SELECT id, status FROM grc.audit_plans WHERE id=$1", plan_id)
    if not existing:
        raise HTTPException(404, "План не найден")
    if existing["status"] not in ("draft", "under_review"):
        raise HTTPException(400, "Редактирование доступно только для черновиков")
    sets, vals, idx = [], [], 1
    for field in ("title", "description"):
        v = getattr(data, field, None)
        if v is not None:
            sets.append(f"{field}=${idx}"); vals.append(v); idx += 1
    if not sets:
        return {"status": "nothing to update"}
    sets.append(f"updated_at=${idx}"); vals.append(datetime.utcnow()); idx += 1
    vals.append(plan_id)
    await pool.execute(
        f"UPDATE grc.audit_plans SET {','.join(sets)} WHERE id=${idx}", *vals
    )
    await _log_activity(pool, "plan", plan_id, "updated", user.user_id, user.full_name)
    return {"status": "ok"}


@router.post("/plans/{plan_id}/transition")
async def transition_plan(request: Request, plan_id: int, data: StatusTransition):
    user = _require_manager(request)
    pool = await get_pool()
    plan = await pool.fetchrow("SELECT id, status FROM grc.audit_plans WHERE id=$1", plan_id)
    if not plan:
        raise HTTPException(404, "План не найден")

    old_status = plan["status"]
    await _validate_transition(pool, "plan", old_status, data.new_status)

    updates = {"status": data.new_status, "updated_at": datetime.utcnow()}
    if data.new_status == "approved":
        updates["approved_by"] = user.user_id
        updates["approved_at"] = datetime.utcnow()

    set_parts = []
    vals = []
    idx = 1
    for k, v in updates.items():
        set_parts.append(f"{k}=${idx}")
        vals.append(v)
        idx += 1
    vals.append(plan_id)
    await pool.execute(
        f"UPDATE grc.audit_plans SET {','.join(set_parts)} WHERE id=${idx}", *vals
    )

    await _log_activity(
        pool, "plan", plan_id, "status_changed", user.user_id, user.full_name,
        old_value=old_status, new_value=data.new_status,
    )
    if data.comment:
        await pool.execute(
            """INSERT INTO grc.comments (entity_type, entity_id, author_id, author_name, body)
               VALUES ('plan', $1, $2, $3, $4)""",
            plan_id, user.user_id, user.full_name, data.comment,
        )
    return {"status": "ok", "old_status": old_status, "new_status": data.new_status}


@router.delete("/plans/{plan_id}")
async def delete_plan(request: Request, plan_id: int):
    user = _require_admin(request)
    pool = await get_pool()
    plan = await pool.fetchrow("SELECT status FROM grc.audit_plans WHERE id=$1", plan_id)
    if not plan:
        raise HTTPException(404, "План не найден")
    if plan["status"] not in ("draft", "archived"):
        raise HTTPException(400, "Удалить можно только черновик или архивный план")
    await pool.execute("DELETE FROM grc.audit_plans WHERE id=$1", plan_id)
    await _log_activity(pool, "plan", plan_id, "deleted", user.user_id, user.full_name)
    return {"status": "ok"}


# ══════════════════════════════════════════════════════════════════════
#  ENGAGEMENTS
# ══════════════════════════════════════════════════════════════════════

class EngagementCreate(BaseModel):
    plan_id: int
    title: str
    description: Optional[str] = None
    engagement_type: str = "planned"
    audit_unit_id: Optional[int] = None
    target_unit_id: Optional[int] = None
    lead_auditor_id: Optional[str] = None
    planned_start: Optional[str] = None   # ISO date string
    planned_end: Optional[str] = None
    risk_level: str = "medium"


class EngagementUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    engagement_type: Optional[str] = None
    audit_unit_id: Optional[int] = None
    target_unit_id: Optional[int] = None
    lead_auditor_id: Optional[str] = None
    planned_start: Optional[str] = None
    planned_end: Optional[str] = None
    actual_start: Optional[str] = None
    actual_end: Optional[str] = None
    risk_level: Optional[str] = None


class MemberAdd(BaseModel):
    user_id: str
    member_role: str = "auditor"


def _parse_date(s: Optional[str]) -> Optional[date]:
    if not s:
        return None
    return date.fromisoformat(s)


@router.get("/engagements")
async def list_engagements(request: Request, plan_id: Optional[int] = None):
    user = _user(request)
    pool = await get_pool()

    base = """SELECT e.*,
                     au.name as audit_unit_name,
                     tu.name as target_unit_name,
                     p.title as plan_title,
                     (SELECT COUNT(*) FROM grc.findings f WHERE f.engagement_id = e.id) as finding_count
              FROM grc.engagements e
              LEFT JOIN grc.org_units au ON e.audit_unit_id = au.id
              LEFT JOIN grc.org_units tu ON e.target_unit_id = tu.id
              LEFT JOIN grc.audit_plans p ON e.plan_id = p.id"""

    if _check_role(user, "manager"):
        if plan_id:
            rows = await pool.fetch(base + " WHERE e.plan_id=$1 ORDER BY e.planned_start", plan_id)
        else:
            rows = await pool.fetch(base + " ORDER BY e.updated_at DESC LIMIT 100")
    else:
        if plan_id:
            rows = await pool.fetch(
                base + """ LEFT JOIN grc.engagement_members em ON em.engagement_id = e.id
                WHERE e.plan_id=$1 AND (e.lead_auditor_id=$2 OR em.user_id=$2)
                ORDER BY e.planned_start""",
                plan_id, user.user_id,
            )
        else:
            rows = await pool.fetch(
                base + """ LEFT JOIN grc.engagement_members em ON em.engagement_id = e.id
                WHERE e.lead_auditor_id=$1 OR em.user_id=$1
                ORDER BY e.updated_at DESC LIMIT 100""",
                user.user_id,
            )
    return [dict(r) for r in rows]


@router.get("/engagements/{eng_id}")
async def get_engagement(request: Request, eng_id: int):
    user = _user(request)
    pool = await get_pool()
    eng = await pool.fetchrow(
        """SELECT e.*,
                  au.name as audit_unit_name,
                  tu.name as target_unit_name,
                  p.title as plan_title
           FROM grc.engagements e
           LEFT JOIN grc.org_units au ON e.audit_unit_id = au.id
           LEFT JOIN grc.org_units tu ON e.target_unit_id = tu.id
           LEFT JOIN grc.audit_plans p ON e.plan_id = p.id
           WHERE e.id=$1""", eng_id
    )
    if not eng:
        raise HTTPException(404, "Проверка не найдена")

    members = await pool.fetch(
        "SELECT * FROM grc.engagement_members WHERE engagement_id=$1", eng_id
    )
    findings = await pool.fetch(
        """SELECT f.*, u.name as responsible_unit_name
           FROM grc.findings f
           LEFT JOIN grc.org_units u ON f.responsible_unit_id = u.id
           WHERE f.engagement_id=$1 ORDER BY f.severity, f.created_at""",
        eng_id,
    )
    return {
        **dict(eng),
        "members": [dict(m) for m in members],
        "findings": [dict(f) for f in findings],
    }


@router.post("/engagements")
async def create_engagement(request: Request, data: EngagementCreate):
    user = _require_manager(request)
    pool = await get_pool()
    # Verify plan exists and is editable
    plan = await pool.fetchrow("SELECT status FROM grc.audit_plans WHERE id=$1", data.plan_id)
    if not plan:
        raise HTTPException(404, "План не найден")
    if plan["status"] in ("completed", "archived"):
        raise HTTPException(400, "Нельзя добавлять проверки в завершённый план")

    row = await pool.fetchrow(
        """INSERT INTO grc.engagements
           (plan_id, title, description, engagement_type, audit_unit_id, target_unit_id,
            lead_auditor_id, planned_start, planned_end, risk_level, created_by)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING id""",
        data.plan_id, data.title, data.description, data.engagement_type,
        data.audit_unit_id, data.target_unit_id, data.lead_auditor_id,
        _parse_date(data.planned_start), _parse_date(data.planned_end),
        data.risk_level, user.user_id,
    )
    # Auto-add lead as member
    if data.lead_auditor_id:
        await pool.execute(
            """INSERT INTO grc.engagement_members (engagement_id, user_id, member_role)
               VALUES ($1,$2,'lead') ON CONFLICT DO NOTHING""",
            row["id"], data.lead_auditor_id,
        )
    await _log_activity(pool, "engagement", row["id"], "created", user.user_id, user.full_name)
    return {"id": row["id"]}


@router.put("/engagements/{eng_id}")
async def update_engagement(request: Request, eng_id: int, data: EngagementUpdate):
    user = _require_manager(request)
    pool = await get_pool()
    existing = await pool.fetchrow("SELECT id FROM grc.engagements WHERE id=$1", eng_id)
    if not existing:
        raise HTTPException(404, "Проверка не найдена")

    sets, vals, idx = [], [], 1
    for field in ("title", "description", "engagement_type", "audit_unit_id",
                  "target_unit_id", "lead_auditor_id", "risk_level"):
        v = getattr(data, field, None)
        if v is not None:
            sets.append(f"{field}=${idx}"); vals.append(v); idx += 1
    for date_field in ("planned_start", "planned_end", "actual_start", "actual_end"):
        v = getattr(data, date_field, None)
        if v is not None:
            sets.append(f"{date_field}=${idx}"); vals.append(_parse_date(v)); idx += 1
    if not sets:
        return {"status": "nothing to update"}
    sets.append(f"updated_at=${idx}"); vals.append(datetime.utcnow()); idx += 1
    vals.append(eng_id)
    await pool.execute(
        f"UPDATE grc.engagements SET {','.join(sets)} WHERE id=${idx}", *vals
    )
    await _log_activity(pool, "engagement", eng_id, "updated", user.user_id, user.full_name)
    return {"status": "ok"}


@router.post("/engagements/{eng_id}/transition")
async def transition_engagement(request: Request, eng_id: int, data: StatusTransition):
    user = _require_auditor(request)
    pool = await get_pool()
    eng = await pool.fetchrow("SELECT id, status FROM grc.engagements WHERE id=$1", eng_id)
    if not eng:
        raise HTTPException(404, "Проверка не найдена")

    old_status = eng["status"]
    await _validate_transition(pool, "engagement", old_status, data.new_status)

    updates = {"status": data.new_status, "updated_at": datetime.utcnow()}
    if data.new_status == "in_progress" and old_status == "planned":
        updates["actual_start"] = _today()
    if data.new_status == "closed":
        updates["actual_end"] = _today()

    set_parts, vals, idx = [], [], 1
    for k, v in updates.items():
        set_parts.append(f"{k}=${idx}"); vals.append(v); idx += 1
    vals.append(eng_id)
    await pool.execute(
        f"UPDATE grc.engagements SET {','.join(set_parts)} WHERE id=${idx}", *vals
    )

    await _log_activity(
        pool, "engagement", eng_id, "status_changed", user.user_id, user.full_name,
        old_value=old_status, new_value=data.new_status,
    )
    if data.comment:
        await pool.execute(
            """INSERT INTO grc.comments (entity_type, entity_id, author_id, author_name, body)
               VALUES ('engagement', $1, $2, $3, $4)""",
            eng_id, user.user_id, user.full_name, data.comment,
        )
    return {"status": "ok", "old_status": old_status, "new_status": data.new_status}


@router.delete("/engagements/{eng_id}")
async def delete_engagement(request: Request, eng_id: int):
    user = _require_manager(request)
    pool = await get_pool()
    eng = await pool.fetchrow("SELECT status FROM grc.engagements WHERE id=$1", eng_id)
    if not eng:
        raise HTTPException(404, "Проверка не найдена")
    if eng["status"] not in ("planned",):
        raise HTTPException(400, "Удалить можно только запланированную проверку")
    await pool.execute("DELETE FROM grc.engagements WHERE id=$1", eng_id)
    await _log_activity(pool, "engagement", eng_id, "deleted", user.user_id, user.full_name)
    return {"status": "ok"}


# ── Engagement Members ───────────────────────────────────────────────

@router.post("/engagements/{eng_id}/members")
async def add_member(request: Request, eng_id: int, data: MemberAdd):
    user = _require_manager(request)
    pool = await get_pool()
    existing = await pool.fetchrow("SELECT id FROM grc.engagements WHERE id=$1", eng_id)
    if not existing:
        raise HTTPException(404, "Проверка не найдена")
    await pool.execute(
        """INSERT INTO grc.engagement_members (engagement_id, user_id, member_role)
           VALUES ($1,$2,$3) ON CONFLICT (engagement_id, user_id) DO UPDATE SET member_role=$3""",
        eng_id, data.user_id, data.member_role,
    )
    await _log_activity(
        pool, "engagement", eng_id, "member_added", user.user_id, user.full_name,
        details={"member": data.user_id, "role": data.member_role},
    )
    return {"status": "ok"}


@router.delete("/engagements/{eng_id}/members/{member_user_id}")
async def remove_member(request: Request, eng_id: int, member_user_id: str):
    user = _require_manager(request)
    pool = await get_pool()
    await pool.execute(
        "DELETE FROM grc.engagement_members WHERE engagement_id=$1 AND user_id=$2",
        eng_id, member_user_id,
    )
    await _log_activity(
        pool, "engagement", eng_id, "member_removed", user.user_id, user.full_name,
        details={"member": member_user_id},
    )
    return {"status": "ok"}


# ══════════════════════════════════════════════════════════════════════
#  FINDINGS
# ══════════════════════════════════════════════════════════════════════

class FindingCreate(BaseModel):
    engagement_id: int
    title: str
    description: Optional[str] = None
    severity: str = "medium"
    responsible_unit_id: Optional[int] = None
    evidence: Optional[str] = None
    recommendation: Optional[str] = None


class FindingUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    severity: Optional[str] = None
    responsible_unit_id: Optional[int] = None
    evidence: Optional[str] = None
    recommendation: Optional[str] = None


@router.get("/findings")
async def list_findings(
    request: Request,
    engagement_id: Optional[int] = None,
    status: Optional[str] = None,
):
    user = _user(request)
    pool = await get_pool()

    base = """SELECT f.*, e.title as engagement_title,
                     u.name as responsible_unit_name
              FROM grc.findings f
              LEFT JOIN grc.engagements e ON f.engagement_id = e.id
              LEFT JOIN grc.org_units u ON f.responsible_unit_id = u.id"""

    conditions, params, idx = [], [], 1
    if engagement_id:
        conditions.append(f"f.engagement_id=${idx}"); params.append(engagement_id); idx += 1
    if status:
        conditions.append(f"f.status=${idx}"); params.append(status); idx += 1

    # Visibility: non-managers only see findings from their engagements
    if not _check_role(user, "manager"):
        conditions.append(
            f"""(e.lead_auditor_id=${idx} OR EXISTS (
                SELECT 1 FROM grc.engagement_members em
                WHERE em.engagement_id=e.id AND em.user_id=${idx}))"""
        )
        params.append(user.user_id); idx += 1

    where = (" WHERE " + " AND ".join(conditions)) if conditions else ""
    rows = await pool.fetch(base + where + " ORDER BY f.severity, f.created_at DESC LIMIT 200", *params)
    return [dict(r) for r in rows]


@router.get("/findings/{finding_id}")
async def get_finding(request: Request, finding_id: int):
    user = _user(request)
    pool = await get_pool()
    finding = await pool.fetchrow(
        """SELECT f.*, e.title as engagement_title, u.name as responsible_unit_name
           FROM grc.findings f
           LEFT JOIN grc.engagements e ON f.engagement_id = e.id
           LEFT JOIN grc.org_units u ON f.responsible_unit_id = u.id
           WHERE f.id=$1""", finding_id
    )
    if not finding:
        raise HTTPException(404, "Замечание не найдено")

    remediations = await pool.fetch(
        """SELECT r.*, u.name as assigned_unit_name
           FROM grc.remediation_tasks r
           LEFT JOIN grc.org_units u ON r.assigned_to_unit_id = u.id
           WHERE r.finding_id=$1 ORDER BY r.deadline""",
        finding_id,
    )
    return {**dict(finding), "remediations": [dict(r) for r in remediations]}


@router.post("/findings")
async def create_finding(request: Request, data: FindingCreate):
    user = _require_auditor(request)
    pool = await get_pool()

    eng = await pool.fetchrow("SELECT id, status FROM grc.engagements WHERE id=$1", data.engagement_id)
    if not eng:
        raise HTTPException(404, "Проверка не найдена")
    if eng["status"] not in ("fieldwork", "review", "in_progress"):
        raise HTTPException(400, "Замечания можно добавлять только на этапе полевой работы или проверки")

    # Generate ref number
    count = await pool.fetchval(
        "SELECT COUNT(*) FROM grc.findings WHERE engagement_id=$1", data.engagement_id
    )
    ref = f"F-{data.engagement_id}-{count + 1:03d}"

    row = await pool.fetchrow(
        """INSERT INTO grc.findings
           (engagement_id, ref_number, title, description, severity,
            found_by, responsible_unit_id, evidence, recommendation)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id""",
        data.engagement_id, ref, data.title, data.description, data.severity,
        user.user_id, data.responsible_unit_id, data.evidence, data.recommendation,
    )
    await _log_activity(pool, "finding", row["id"], "created", user.user_id, user.full_name)
    return {"id": row["id"], "ref_number": ref}


@router.put("/findings/{finding_id}")
async def update_finding(request: Request, finding_id: int, data: FindingUpdate):
    user = _require_auditor(request)
    pool = await get_pool()
    existing = await pool.fetchrow("SELECT id, status FROM grc.findings WHERE id=$1", finding_id)
    if not existing:
        raise HTTPException(404, "Замечание не найдено")
    if existing["status"] not in ("draft", "confirmed"):
        raise HTTPException(400, "Редактирование доступно только для черновиков и подтверждённых замечаний")

    sets, vals, idx = [], [], 1
    for field in ("title", "description", "severity", "responsible_unit_id", "evidence", "recommendation"):
        v = getattr(data, field, None)
        if v is not None:
            sets.append(f"{field}=${idx}"); vals.append(v); idx += 1
    if not sets:
        return {"status": "nothing to update"}
    sets.append(f"updated_at=${idx}"); vals.append(datetime.utcnow()); idx += 1
    vals.append(finding_id)
    await pool.execute(
        f"UPDATE grc.findings SET {','.join(sets)} WHERE id=${idx}", *vals
    )
    await _log_activity(pool, "finding", finding_id, "updated", user.user_id, user.full_name)
    return {"status": "ok"}


@router.post("/findings/{finding_id}/transition")
async def transition_finding(request: Request, finding_id: int, data: StatusTransition):
    user = _require_auditor(request)
    pool = await get_pool()
    finding = await pool.fetchrow("SELECT id, status FROM grc.findings WHERE id=$1", finding_id)
    if not finding:
        raise HTTPException(404, "Замечание не найдено")

    old_status = finding["status"]
    await _validate_transition(pool, "finding", old_status, data.new_status)

    await pool.execute(
        "UPDATE grc.findings SET status=$1, updated_at=$2 WHERE id=$3",
        data.new_status, datetime.utcnow(), finding_id,
    )
    await _log_activity(
        pool, "finding", finding_id, "status_changed", user.user_id, user.full_name,
        old_value=old_status, new_value=data.new_status,
    )
    if data.comment:
        await pool.execute(
            """INSERT INTO grc.comments (entity_type, entity_id, author_id, author_name, body)
               VALUES ('finding', $1, $2, $3, $4)""",
            finding_id, user.user_id, user.full_name, data.comment,
        )
    return {"status": "ok", "old_status": old_status, "new_status": data.new_status}


# ══════════════════════════════════════════════════════════════════════
#  REMEDIATION TASKS
# ══════════════════════════════════════════════════════════════════════

class RemediationCreate(BaseModel):
    finding_id: int
    title: str
    description: Optional[str] = None
    assigned_to_user_id: Optional[str] = None
    assigned_to_unit_id: Optional[int] = None
    deadline: str     # ISO date


class RemediationUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    assigned_to_user_id: Optional[str] = None
    assigned_to_unit_id: Optional[int] = None
    deadline: Optional[str] = None
    escalation_enabled: Optional[bool] = None
    escalation_muted_until: Optional[str] = None
    submitted_evidence: Optional[str] = None


class ReassignData(BaseModel):
    new_user_id: str
    reason: Optional[str] = None


@router.get("/remediations")
async def list_remediations(
    request: Request,
    finding_id: Optional[int] = None,
    status: Optional[str] = None,
    overdue_only: Optional[bool] = False,
    my_tasks: Optional[bool] = False,
):
    user = _user(request)
    pool = await get_pool()

    base = """SELECT r.*, f.title as finding_title, f.ref_number as finding_ref,
                     f.severity as finding_severity, f.engagement_id,
                     e.title as engagement_title,
                     u.name as assigned_unit_name
              FROM grc.remediation_tasks r
              LEFT JOIN grc.findings f ON r.finding_id = f.id
              LEFT JOIN grc.engagements e ON f.engagement_id = e.id
              LEFT JOIN grc.org_units u ON r.assigned_to_unit_id = u.id"""

    conditions, params, idx = [], [], 1

    if finding_id:
        conditions.append(f"r.finding_id=${idx}"); params.append(finding_id); idx += 1
    if status:
        conditions.append(f"r.status=${idx}"); params.append(status); idx += 1
    if overdue_only:
        conditions.append("r.is_overdue = TRUE")
    if my_tasks or not _check_role(user, "auditor"):
        conditions.append(f"r.assigned_to_user_id=${idx}"); params.append(user.user_id); idx += 1

    where = (" WHERE " + " AND ".join(conditions)) if conditions else ""
    rows = await pool.fetch(
        base + where + " ORDER BY r.is_overdue DESC, r.deadline ASC LIMIT 200", *params
    )
    return [dict(r) for r in rows]


@router.get("/remediations/{rem_id}")
async def get_remediation(request: Request, rem_id: int):
    user = _user(request)
    pool = await get_pool()
    rem = await pool.fetchrow(
        """SELECT r.*, f.title as finding_title, f.ref_number as finding_ref,
                  f.severity as finding_severity, f.engagement_id,
                  e.title as engagement_title,
                  u.name as assigned_unit_name
           FROM grc.remediation_tasks r
           LEFT JOIN grc.findings f ON r.finding_id = f.id
           LEFT JOIN grc.engagements e ON f.engagement_id = e.id
           LEFT JOIN grc.org_units u ON r.assigned_to_unit_id = u.id
           WHERE r.id=$1""", rem_id
    )
    if not rem:
        raise HTTPException(404, "Рекомендация не найдена")
    return dict(rem)


@router.post("/remediations")
async def create_remediation(request: Request, data: RemediationCreate):
    user = _require_auditor(request)
    pool = await get_pool()

    finding = await pool.fetchrow(
        "SELECT id, status, engagement_id FROM grc.findings WHERE id=$1", data.finding_id
    )
    if not finding:
        raise HTTPException(404, "Замечание не найдено")

    # Generate ref number
    count = await pool.fetchval(
        "SELECT COUNT(*) FROM grc.remediation_tasks WHERE finding_id=$1", data.finding_id
    )
    ref = f"R-{data.finding_id}-{count + 1:03d}"

    row = await pool.fetchrow(
        """INSERT INTO grc.remediation_tasks
           (finding_id, ref_number, title, description,
            assigned_to_user_id, assigned_to_unit_id, deadline, created_by)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id""",
        data.finding_id, ref, data.title, data.description,
        data.assigned_to_user_id, data.assigned_to_unit_id,
        _parse_date(data.deadline), user.user_id,
    )

    # Auto-transition finding to remediation_issued if it was confirmed
    if finding["status"] == "confirmed":
        await pool.execute(
            "UPDATE grc.findings SET status='remediation_issued', updated_at=$1 WHERE id=$2",
            datetime.utcnow(), data.finding_id,
        )

    # Notify assignee
    if data.assigned_to_user_id:
        await _notify(
            pool, data.assigned_to_user_id, "task_assigned",
            f"Новая рекомендация: {data.title}",
            f"Срок выполнения: {data.deadline}",
            "remediation", row["id"],
        )
        # Send email immediately
        email_svc = get_email_service()
        user_email = await _resolve_user_email(pool, data.assigned_to_user_id)
        if user_email:
            email_svc.send(
                to=user_email,
                subject=f"DAP: Новая рекомендация — {data.title}",
                body_text=f"Вам назначена рекомендация: {data.title}\nСрок выполнения: {data.deadline}\n\n— DataAudit Platform",
                body_html=_escalation_email_html(
                    f"Новая рекомендация: {ref}",
                    f"Вам назначена рекомендация «{data.title}»",
                    ref, data.deadline,
                ),
            )

    await _log_activity(pool, "remediation", row["id"], "created", user.user_id, user.full_name)
    return {"id": row["id"], "ref_number": ref}


@router.put("/remediations/{rem_id}")
async def update_remediation(request: Request, rem_id: int, data: RemediationUpdate):
    user = _user(request)
    pool = await get_pool()
    existing = await pool.fetchrow(
        "SELECT id, status, assigned_to_user_id FROM grc.remediation_tasks WHERE id=$1", rem_id
    )
    if not existing:
        raise HTTPException(404, "Рекомендация не найдена")

    # Assignees can update submitted_evidence; managers can update everything else
    is_assignee = existing["assigned_to_user_id"] == user.user_id
    is_manager = _check_role(user, "manager")
    if not is_assignee and not is_manager:
        raise HTTPException(403, "Нет прав на редактирование этой рекомендации")

    sets, vals, idx = [], [], 1
    if is_manager:
        for field in ("title", "description", "assigned_to_user_id",
                      "assigned_to_unit_id", "escalation_enabled"):
            v = getattr(data, field, None)
            if v is not None:
                sets.append(f"{field}=${idx}"); vals.append(v); idx += 1
        if data.deadline is not None:
            sets.append(f"deadline=${idx}"); vals.append(_parse_date(data.deadline)); idx += 1
        if data.escalation_muted_until is not None:
            sets.append(f"escalation_muted_until=${idx}")
            vals.append(_parse_date(data.escalation_muted_until)); idx += 1

    if data.submitted_evidence is not None:
        sets.append(f"submitted_evidence=${idx}"); vals.append(data.submitted_evidence); idx += 1

    if not sets:
        return {"status": "nothing to update"}
    sets.append(f"updated_at=${idx}"); vals.append(datetime.utcnow()); idx += 1
    vals.append(rem_id)
    await pool.execute(
        f"UPDATE grc.remediation_tasks SET {','.join(sets)} WHERE id=${idx}", *vals
    )
    await _log_activity(pool, "remediation", rem_id, "updated", user.user_id, user.full_name)
    return {"status": "ok"}


@router.post("/remediations/{rem_id}/transition")
async def transition_remediation(request: Request, rem_id: int, data: StatusTransition):
    user = _user(request)
    pool = await get_pool()
    rem = await pool.fetchrow(
        "SELECT id, status, assigned_to_user_id, finding_id FROM grc.remediation_tasks WHERE id=$1",
        rem_id,
    )
    if not rem:
        raise HTTPException(404, "Рекомендация не найдена")

    old_status = rem["status"]
    await _validate_transition(pool, "remediation", old_status, data.new_status)

    # Permission checks per transition
    is_assignee = rem["assigned_to_user_id"] == user.user_id
    if data.new_status in ("in_progress", "submitted") and not is_assignee and not _check_role(user, "manager"):
        raise HTTPException(403, "Только исполнитель может обновлять статус задачи")
    if data.new_status in ("verified",) and not _check_role(user, "auditor"):
        raise HTTPException(403, "Только аудитор может подтвердить выполнение")
    if data.new_status in ("closed",) and not _check_role(user, "manager"):
        raise HTTPException(403, "Только руководитель может закрыть рекомендацию")

    updates = {"status": data.new_status, "updated_at": datetime.utcnow()}
    if data.new_status == "submitted":
        updates["submitted_at"] = datetime.utcnow()
    if data.new_status == "verified":
        updates["verified_by"] = user.user_id
        updates["verified_at"] = datetime.utcnow()
    if data.new_status == "closed":
        updates["closed_at"] = datetime.utcnow()
        updates["is_overdue"] = False

    set_parts, vals, idx = [], [], 1
    for k, v in updates.items():
        set_parts.append(f"{k}=${idx}"); vals.append(v); idx += 1
    vals.append(rem_id)
    await pool.execute(
        f"UPDATE grc.remediation_tasks SET {','.join(set_parts)} WHERE id=${idx}", *vals
    )

    await _log_activity(
        pool, "remediation", rem_id, "status_changed", user.user_id, user.full_name,
        old_value=old_status, new_value=data.new_status,
    )
    if data.comment:
        await pool.execute(
            """INSERT INTO grc.comments (entity_type, entity_id, author_id, author_name, body)
               VALUES ('remediation', $1, $2, $3, $4)""",
            rem_id, user.user_id, user.full_name, data.comment,
        )
    return {"status": "ok", "old_status": old_status, "new_status": data.new_status}


@router.post("/remediations/{rem_id}/reassign")
async def reassign_remediation(request: Request, rem_id: int, data: ReassignData):
    """Reassign a remediation task — used when employee leaves or is replaced."""
    user = _require_manager(request)
    pool = await get_pool()
    rem = await pool.fetchrow(
        "SELECT id, assigned_to_user_id, title FROM grc.remediation_tasks WHERE id=$1", rem_id
    )
    if not rem:
        raise HTTPException(404, "Рекомендация не найдена")

    old_assignee = rem["assigned_to_user_id"]
    await pool.execute(
        "UPDATE grc.remediation_tasks SET assigned_to_user_id=$1, updated_at=$2 WHERE id=$3",
        data.new_user_id, datetime.utcnow(), rem_id,
    )

    await _log_activity(
        pool, "remediation", rem_id, "reassigned", user.user_id, user.full_name,
        old_value=old_assignee, new_value=data.new_user_id,
        details={"reason": data.reason},
    )
    await _notify(
        pool, data.new_user_id, "reassignment",
        f"Вам назначена рекомендация: {rem['title']}",
        f"Передано от: {old_assignee}. Причина: {data.reason or 'не указана'}",
        "remediation", rem_id,
    )
    return {"status": "ok", "old_assignee": old_assignee, "new_assignee": data.new_user_id}


# ── Bulk reassignment (employee departure) ──────────────────────────

class BulkReassignData(BaseModel):
    old_user_id: str
    new_user_id: str
    reason: Optional[str] = "Смена ответственного"


@router.post("/remediations/bulk-reassign")
async def bulk_reassign(request: Request, data: BulkReassignData):
    """Reassign all active remediation tasks from one user to another."""
    user = _require_manager(request)
    pool = await get_pool()

    tasks = await pool.fetch(
        """SELECT id, title FROM grc.remediation_tasks
           WHERE assigned_to_user_id=$1 AND status NOT IN ('closed','cancelled')""",
        data.old_user_id,
    )
    if not tasks:
        return {"status": "ok", "reassigned_count": 0}

    async with pool.acquire() as conn:
        async with conn.transaction():
            await conn.execute(
                """UPDATE grc.remediation_tasks
                   SET assigned_to_user_id=$1, updated_at=$2
                   WHERE assigned_to_user_id=$3 AND status NOT IN ('closed','cancelled')""",
                data.new_user_id, datetime.utcnow(), data.old_user_id,
            )
            for t in tasks:
                await _log_activity(
                    pool, "remediation", t["id"], "reassigned", user.user_id, user.full_name,
                    old_value=data.old_user_id, new_value=data.new_user_id,
                    details={"reason": data.reason, "bulk": True},
                )

    await _notify(
        pool, data.new_user_id, "reassignment",
        f"Вам назначено {len(tasks)} рекомендаций",
        f"Передано от: {data.old_user_id}. Причина: {data.reason}",
        "remediation", None,
    )

    return {"status": "ok", "reassigned_count": len(tasks)}


# ══════════════════════════════════════════════════════════════════════
#  COMMENTS
# ══════════════════════════════════════════════════════════════════════

class CommentCreate(BaseModel):
    entity_type: str
    entity_id: int
    body: str


@router.get("/comments/{entity_type}/{entity_id}")
async def list_comments(request: Request, entity_type: str, entity_id: int):
    _user(request)
    pool = await get_pool()
    rows = await pool.fetch(
        """SELECT * FROM grc.comments
           WHERE entity_type=$1 AND entity_id=$2
           ORDER BY created_at ASC""",
        entity_type, entity_id,
    )
    return [dict(r) for r in rows]


@router.post("/comments")
async def create_comment(request: Request, data: CommentCreate):
    user = _user(request)
    if data.entity_type not in ("plan", "engagement", "finding", "remediation"):
        raise HTTPException(400, "Неверный тип сущности")
    pool = await get_pool()
    row = await pool.fetchrow(
        """INSERT INTO grc.comments (entity_type, entity_id, author_id, author_name, body)
           VALUES ($1,$2,$3,$4,$5) RETURNING id""",
        data.entity_type, data.entity_id, user.user_id, user.full_name, data.body,
    )
    await _log_activity(
        pool, data.entity_type, data.entity_id, "commented",
        user.user_id, user.full_name,
    )
    return {"id": row["id"]}


# ══════════════════════════════════════════════════════════════════════
#  NOTIFICATIONS
# ══════════════════════════════════════════════════════════════════════

@router.get("/notifications")
async def list_notifications(
    request: Request,
    unread_only: bool = False,
    limit: int = 50,
):
    user = _user(request)
    pool = await get_pool()
    if unread_only:
        rows = await pool.fetch(
            """SELECT * FROM grc.notifications
               WHERE user_id=$1 AND is_read=FALSE
               ORDER BY created_at DESC LIMIT $2""",
            user.user_id, limit,
        )
    else:
        rows = await pool.fetch(
            """SELECT * FROM grc.notifications
               WHERE user_id=$1
               ORDER BY created_at DESC LIMIT $2""",
            user.user_id, limit,
        )
    return [dict(r) for r in rows]


@router.get("/notifications/count")
async def notification_count(request: Request):
    user = _user(request)
    pool = await get_pool()
    count = await pool.fetchval(
        "SELECT COUNT(*) FROM grc.notifications WHERE user_id=$1 AND is_read=FALSE",
        user.user_id,
    )
    return {"unread": count}


@router.post("/notifications/{notif_id}/read")
async def mark_notification_read(request: Request, notif_id: int):
    user = _user(request)
    pool = await get_pool()
    await pool.execute(
        "UPDATE grc.notifications SET is_read=TRUE WHERE id=$1 AND user_id=$2",
        notif_id, user.user_id,
    )
    return {"status": "ok"}


@router.post("/notifications/read-all")
async def mark_all_read(request: Request):
    user = _user(request)
    pool = await get_pool()
    await pool.execute(
        "UPDATE grc.notifications SET is_read=TRUE WHERE user_id=$1 AND is_read=FALSE",
        user.user_id,
    )
    return {"status": "ok"}


# ══════════════════════════════════════════════════════════════════════
#  ESCALATION ENGINE (now config-driven)
# ══════════════════════════════════════════════════════════════════════

@router.post("/escalation/check")
async def run_escalation_check(request: Request):
    """
    Check all active remediation tasks for approaching/passed deadlines.
    Generates notifications according to DB-stored escalation thresholds.
    Should be called periodically (e.g. daily cron or manual trigger).
    """
    user = _require_manager(request)
    pool = await get_pool()
    today = _today()

    # Load escalation config from DB
    escalation_config = await _get_config(pool, "escalation", "deadlines")
    thresholds = escalation_config.get("thresholds", [])

    tasks = await pool.fetch(
        """SELECT r.*, f.title as finding_title, f.ref_number as finding_ref,
                  u.head_user_id as unit_head
           FROM grc.remediation_tasks r
           LEFT JOIN grc.findings f ON r.finding_id = f.id
           LEFT JOIN grc.org_units u ON r.assigned_to_unit_id = u.id
           WHERE r.status NOT IN ('closed', 'cancelled', 'verified')
             AND r.escalation_enabled = TRUE
             AND (r.escalation_muted_until IS NULL OR r.escalation_muted_until < $1)""",
        today,
    )

    created_notifications = 0

    for task in tasks:
        deadline = task["deadline"]
        days_until = (deadline - today).days
        assignee = task["assigned_to_user_id"]
        unit_head = task["unit_head"]
        ref = task["ref_number"] or f"#{task['id']}"
        title = task["title"]

        # Mark overdue
        if days_until < 0 and not task["is_overdue"]:
            await pool.execute(
                "UPDATE grc.remediation_tasks SET is_overdue=TRUE, updated_at=$1 WHERE id=$2",
                datetime.utcnow(), task["id"],
            )

        notifications_to_create = []

        # Match against each configured threshold
        for threshold in thresholds:
            matched = False
            ntype = threshold.get("type", "")

            if "days_before" in threshold:
                days_before = threshold["days_before"]
                if days_before > 0 and days_until == days_before:
                    matched = True
                elif days_before == 0 and days_until == 0:
                    matched = True
            if "days_after" in threshold and days_until < 0:
                # Overdue — matches every day after deadline if repeat=daily,
                # or only on the exact day otherwise
                repeat = threshold.get("repeat")
                if repeat == "daily":
                    matched = True
                elif abs(days_until) == threshold["days_after"]:
                    matched = True

            if not matched:
                continue

            # Determine who to notify
            notify_targets = threshold.get("notify", [])
            overdue_days = abs(days_until) if days_until < 0 else 0

            if days_until > 0:
                msg_prefix = f"Срок через {days_until} дн."
            elif days_until == 0:
                msg_prefix = "Срок сегодня"
            else:
                msg_prefix = f"Просрочено {overdue_days} дн."

            if "assignee" in notify_targets and assignee:
                notifications_to_create.append((
                    assignee, ntype,
                    f"{msg_prefix}: {ref}",
                    f"Рекомендация «{title}» — срок до {deadline}",
                ))
            if "unit_head" in notify_targets and unit_head:
                notifications_to_create.append((
                    unit_head, ntype,
                    f"{msg_prefix}: {ref} (подчинённый)",
                    f"Рекомендация «{title}» назначено {assignee} — срок до {deadline}",
                ))

        for (uid, ntype, ntitle, nmessage) in notifications_to_create:
            if uid:
                # Avoid duplicate notifications for the same day
                existing = await pool.fetchval(
                    """SELECT COUNT(*) FROM grc.notifications
                       WHERE user_id=$1 AND notif_type=$2 AND entity_type='remediation'
                         AND entity_id=$3 AND date(created_at)=$4""",
                    uid, ntype, task["id"], today,
                )
                if existing == 0:
                    await _notify(pool, uid, ntype, ntitle, nmessage, "remediation", task["id"])
                    created_notifications += 1

                    # Send email notification
                    email_svc = get_email_service()
                    user_email = await _resolve_user_email(pool, uid)
                    if user_email:
                        email_svc.send(
                            to=user_email,
                            subject=f"DAP: {ntitle}",
                            body_text=f"{ntitle}\n\n{nmessage}\n\n—\nDataAudit Platform",
                            body_html=_escalation_email_html(ntitle, nmessage, ref, deadline),
                        )

    return {
        "status": "ok",
        "tasks_checked": len(tasks),
        "notifications_created": created_notifications,
        "check_date": today.isoformat(),
    }


# ══════════════════════════════════════════════════════════════════════
#  ADMIN: CONFIG MANAGEMENT (Phase 1B)
# ══════════════════════════════════════════════════════════════════════

class ConfigUpdate(BaseModel):
    config: dict


class EnumCreate(BaseModel):
    key: str
    label: str
    sort_order: int = 0
    metadata: dict = {}


class EnumUpdate(BaseModel):
    label: Optional[str] = None
    sort_order: Optional[int] = None
    metadata: Optional[dict] = None


# ── Workflow Configs ─────────────────────────────────────────────────

@router.get("/admin/configs")
async def list_configs(request: Request):
    """Return all active workflow configs."""
    _require_admin(request)
    pool = await get_pool()
    rows = await pool.fetch(
        """SELECT id, config_type, config_key, config, version, updated_by, updated_at
           FROM grc.workflow_configs WHERE is_active=TRUE
           ORDER BY config_type, config_key"""
    )
    results = []
    for r in rows:
        d = dict(r)
        if isinstance(d.get("config"), str):
            d["config"] = json.loads(d["config"])
        results.append(d)
    return results


@router.get("/admin/configs/{config_type}/{config_key}")
async def get_config(request: Request, config_type: str, config_key: str):
    """Return a single workflow config."""
    _require_admin(request)
    pool = await get_pool()
    row = await pool.fetchrow(
        """SELECT id, config_type, config_key, config, version, updated_by, updated_at
           FROM grc.workflow_configs
           WHERE config_type=$1 AND config_key=$2 AND is_active=TRUE""",
        config_type, config_key,
    )
    if not row:
        raise HTTPException(404, "Конфигурация не найдена")
    result = dict(row)
    if isinstance(result.get("config"), str):
        result["config"] = json.loads(result["config"])
    return result


@router.put("/admin/configs/{config_type}/{config_key}")
async def update_config(request: Request, config_type: str, config_key: str, data: ConfigUpdate):
    """Update a workflow config (increments version)."""
    user = _require_admin(request)
    pool = await get_pool()
    existing = await pool.fetchrow(
        """SELECT id, version FROM grc.workflow_configs
           WHERE config_type=$1 AND config_key=$2 AND is_active=TRUE""",
        config_type, config_key,
    )
    if not existing:
        raise HTTPException(404, "Конфигурация не найдена")

    new_version = existing["version"] + 1
    await pool.execute(
        """UPDATE grc.workflow_configs
           SET config=$1, version=$2, updated_by=$3, updated_at=NOW()
           WHERE id=$4""",
        json.dumps(data.config), new_version, user.user_id, existing["id"],
    )
    _invalidate_cache(f"{config_type}:")
    await _log_activity(
        pool, "config", existing["id"], "config_updated", user.user_id, user.full_name,
        details={"config_type": config_type, "config_key": config_key, "version": new_version},
    )
    return {"status": "ok", "version": new_version}


# ── Enum Definitions ─────────────────────────────────────────────────

@router.get("/admin/enums")
async def list_all_enums(request: Request):
    """Return all enum categories with their values."""
    _require_admin(request)
    pool = await get_pool()
    rows = await pool.fetch(
        """SELECT id, category, key, label, sort_order, metadata, is_active
           FROM grc.enum_definitions
           ORDER BY category, sort_order, key"""
    )
    # Group by category
    result = {}
    for r in rows:
        cat = r["category"]
        if cat not in result:
            result[cat] = []
        result[cat].append(dict(r))
    return result


@router.get("/admin/enums/{category}")
async def list_enums_by_category(request: Request, category: str):
    """Return all values for a single enum category."""
    _require_admin(request)
    pool = await get_pool()
    rows = await pool.fetch(
        """SELECT id, category, key, label, sort_order, metadata, is_active
           FROM grc.enum_definitions
           WHERE category=$1 ORDER BY sort_order, key""",
        category,
    )
    return [dict(r) for r in rows]


@router.post("/admin/enums/{category}")
async def create_enum(request: Request, category: str, data: EnumCreate):
    """Add a new enum value to a category."""
    user = _require_admin(request)
    pool = await get_pool()
    # Check for duplicate
    existing = await pool.fetchval(
        "SELECT id FROM grc.enum_definitions WHERE category=$1 AND key=$2",
        category, data.key,
    )
    if existing:
        raise HTTPException(400, f"Ключ «{data.key}» уже существует в категории «{category}»")

    row = await pool.fetchrow(
        """INSERT INTO grc.enum_definitions (category, key, label, sort_order, metadata)
           VALUES ($1,$2,$3,$4,$5) RETURNING id""",
        category, data.key, data.label, data.sort_order,
        json.dumps(data.metadata),
    )
    _invalidate_cache(f"enum:{category}")
    await _log_activity(
        pool, "enum", row["id"], "enum_created", user.user_id, user.full_name,
        details={"category": category, "key": data.key, "label": data.label},
    )
    return {"id": row["id"], "status": "ok"}


@router.put("/admin/enums/{category}/{key}")
async def update_enum(request: Request, category: str, key: str, data: EnumUpdate):
    """Update an enum value (label, sort_order, metadata)."""
    user = _require_admin(request)
    pool = await get_pool()
    existing = await pool.fetchrow(
        "SELECT id FROM grc.enum_definitions WHERE category=$1 AND key=$2",
        category, key,
    )
    if not existing:
        raise HTTPException(404, "Значение не найдено")

    sets, vals, idx = [], [], 1
    if data.label is not None:
        sets.append(f"label=${idx}"); vals.append(data.label); idx += 1
    if data.sort_order is not None:
        sets.append(f"sort_order=${idx}"); vals.append(data.sort_order); idx += 1
    if data.metadata is not None:
        sets.append(f"metadata=${idx}"); vals.append(json.dumps(data.metadata)); idx += 1
    if not sets:
        return {"status": "nothing to update"}

    vals.append(existing["id"])
    await pool.execute(
        f"UPDATE grc.enum_definitions SET {','.join(sets)} WHERE id=${idx}", *vals
    )
    _invalidate_cache(f"enum:{category}")
    await _log_activity(
        pool, "enum", existing["id"], "enum_updated", user.user_id, user.full_name,
        details={"category": category, "key": key},
    )
    return {"status": "ok"}


@router.delete("/admin/enums/{category}/{key}")
async def delete_enum(request: Request, category: str, key: str):
    """Soft-delete an enum value (set is_active=false)."""
    user = _require_admin(request)
    pool = await get_pool()
    existing = await pool.fetchrow(
        "SELECT id FROM grc.enum_definitions WHERE category=$1 AND key=$2",
        category, key,
    )
    if not existing:
        raise HTTPException(404, "Значение не найдено")

    await pool.execute(
        "UPDATE grc.enum_definitions SET is_active=FALSE WHERE id=$1",
        existing["id"],
    )
    _invalidate_cache(f"enum:{category}")
    await _log_activity(
        pool, "enum", existing["id"], "enum_deleted", user.user_id, user.full_name,
        details={"category": category, "key": key},
    )
    return {"status": "ok"}


@router.put("/admin/enums/{category}/{key}/restore")
async def restore_enum(request: Request, category: str, key: str):
    """Restore a soft-deleted enum value."""
    user = _require_admin(request)
    pool = await get_pool()
    existing = await pool.fetchrow(
        "SELECT id FROM grc.enum_definitions WHERE category=$1 AND key=$2 AND is_active=FALSE",
        category, key,
    )
    if not existing:
        raise HTTPException(404, "Удалённое значение не найдено")

    await pool.execute(
        "UPDATE grc.enum_definitions SET is_active=TRUE WHERE id=$1",
        existing["id"],
    )
    _invalidate_cache(f"enum:{category}")
    return {"status": "ok"}


# ══════════════════════════════════════════════════════════════════════
#  DASHBOARD / STATS
# ══════════════════════════════════════════════════════════════════════

@router.get("/dashboard")
async def get_dashboard(request: Request):
    """Dashboard stats tailored to user role."""
    user = _user(request)
    pool = await get_pool()
    role = user.role.value

    stats = {}

    if _check_role(user, "manager"):
        # Full overview
        stats["plans_total"] = await pool.fetchval("SELECT COUNT(*) FROM grc.audit_plans")
        stats["plans_active"] = await pool.fetchval(
            "SELECT COUNT(*) FROM grc.audit_plans WHERE status='active'"
        )
        stats["engagements_active"] = await pool.fetchval(
            "SELECT COUNT(*) FROM grc.engagements WHERE status NOT IN ('closed','planned')"
        )
        stats["findings_open"] = await pool.fetchval(
            "SELECT COUNT(*) FROM grc.findings WHERE status NOT IN ('closed','resolved')"
        )
        stats["remediations_active"] = await pool.fetchval(
            "SELECT COUNT(*) FROM grc.remediation_tasks WHERE status NOT IN ('closed','cancelled')"
        )
        stats["remediations_overdue"] = await pool.fetchval(
            "SELECT COUNT(*) FROM grc.remediation_tasks WHERE is_overdue=TRUE AND status NOT IN ('closed','cancelled')"
        )

        # Severity breakdown of open findings
        severity_rows = await pool.fetch(
            """SELECT severity, COUNT(*) as cnt FROM grc.findings
               WHERE status NOT IN ('closed','resolved')
               GROUP BY severity"""
        )
        stats["findings_by_severity"] = {r["severity"]: r["cnt"] for r in severity_rows}

        # Status breakdown of remediations
        rem_rows = await pool.fetch(
            """SELECT status, COUNT(*) as cnt FROM grc.remediation_tasks
               WHERE status NOT IN ('closed','cancelled')
               GROUP BY status"""
        )
        stats["remediations_by_status"] = {r["status"]: r["cnt"] for r in rem_rows}

    elif _check_role(user, "auditor"):
        # Auditor-specific
        stats["my_engagements"] = await pool.fetchval(
            """SELECT COUNT(*) FROM grc.engagements e
               WHERE (e.lead_auditor_id=$1 OR EXISTS (
                   SELECT 1 FROM grc.engagement_members em
                   WHERE em.engagement_id=e.id AND em.user_id=$1
               )) AND e.status NOT IN ('closed')""",
            user.user_id,
        )
        stats["my_findings"] = await pool.fetchval(
            "SELECT COUNT(*) FROM grc.findings WHERE found_by=$1 AND status NOT IN ('closed')",
            user.user_id,
        )
        stats["pending_verification"] = await pool.fetchval(
            "SELECT COUNT(*) FROM grc.remediation_tasks WHERE status='submitted'"
        )
    else:
        # Viewer / business department user
        stats["my_tasks"] = await pool.fetchval(
            """SELECT COUNT(*) FROM grc.remediation_tasks
               WHERE assigned_to_user_id=$1 AND status NOT IN ('closed','cancelled')""",
            user.user_id,
        )
        stats["my_overdue"] = await pool.fetchval(
            """SELECT COUNT(*) FROM grc.remediation_tasks
               WHERE assigned_to_user_id=$1 AND is_overdue=TRUE AND status NOT IN ('closed','cancelled')""",
            user.user_id,
        )

    # Unread notifications — for everyone
    stats["unread_notifications"] = await pool.fetchval(
        "SELECT COUNT(*) FROM grc.notifications WHERE user_id=$1 AND is_read=FALSE",
        user.user_id,
    )

    # Recent activity
    recent = await pool.fetch(
        """SELECT * FROM grc.activity_log
           ORDER BY created_at DESC LIMIT 10"""
    )
    stats["recent_activity"] = [dict(r) for r in recent]

    return {"role": role, "stats": stats}


# ══════════════════════════════════════════════════════════════════════
#  ACTIVITY LOG
# ══════════════════════════════════════════════════════════════════════

@router.get("/activity/{entity_type}/{entity_id}")
async def get_activity(request: Request, entity_type: str, entity_id: int):
    _user(request)
    pool = await get_pool()
    rows = await pool.fetch(
        """SELECT * FROM grc.activity_log
           WHERE entity_type=$1 AND entity_id=$2
           ORDER BY created_at DESC LIMIT 100""",
        entity_type, entity_id,
    )
    return [dict(r) for r in rows]


# ══════════════════════════════════════════════════════════════════════
#  REFERENCE DATA (now DB-driven)
# ══════════════════════════════════════════════════════════════════════

@router.get("/reference/statuses")
async def get_status_labels(request: Request):
    """Return all status labels and transitions for frontend display."""
    _user(request)
    pool = await get_pool()
    transitions = {}
    for entity in ("plan", "engagement", "finding", "remediation"):
        transitions[entity] = await _get_config(pool, "transitions", entity)
    labels = await _get_enums(pool, "status_label")
    return {
        "transitions": transitions,
        "labels": labels,
    }


# ══════════════════════════════════════════════════════════════════════
#  ATTACHMENTS (Phase 2)
# ══════════════════════════════════════════════════════════════════════

ALLOWED_ENTITY_TYPES = ("engagement", "finding", "remediation")
ALLOWED_EXTENSIONS = {
    ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
    ".txt", ".csv", ".rtf",
    ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tiff",
    ".zip", ".rar", ".7z",
    ".msg", ".eml",
}


def _get_attachment_dir(entity_type: str, entity_id: int) -> str:
    """Return and create the directory for storing attachments."""
    path = os.path.join(ATTACHMENTS_PATH, entity_type, str(entity_id))
    os.makedirs(path, exist_ok=True)
    return path


@router.post("/attachments/{entity_type}/{entity_id}")
async def upload_attachment(
    request: Request,
    entity_type: str,
    entity_id: int,
    file: UploadFile = File(...),
    category: str = FastForm("general"),
    description: str = FastForm(""),
):
    """Upload a file attachment to an entity."""
    user = _user(request)
    if entity_type not in ALLOWED_ENTITY_TYPES:
        raise HTTPException(400, f"Недопустимый тип сущности: {entity_type}")

    # Validate extension
    original_name = file.filename or "unnamed"
    ext = os.path.splitext(original_name)[1].lower()
    if ext and ext not in ALLOWED_EXTENSIONS:
        raise HTTPException(400, f"Тип файла «{ext}» не разрешён")

    # Read file content
    content = await file.read()
    file_size = len(content)
    if file_size > MAX_UPLOAD_SIZE:
        raise HTTPException(400, f"Файл слишком большой (макс. {MAX_UPLOAD_SIZE // (1024*1024)} МБ)")
    if file_size == 0:
        raise HTTPException(400, "Пустой файл")

    # Generate UUID filename
    disk_filename = f"{uuid.uuid4().hex}{ext}"
    attach_dir = _get_attachment_dir(entity_type, entity_id)
    disk_path = os.path.join(attach_dir, disk_filename)

    # Write to disk
    with open(disk_path, "wb") as f:
        f.write(content)

    # Save metadata to DB
    pool = await get_pool()
    row = await pool.fetchrow(
        """INSERT INTO grc.attachments
           (entity_type, entity_id, filename, original_name, file_size, mime_type, category, description, uploaded_by)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
           RETURNING id""",
        entity_type, entity_id, disk_filename, original_name, file_size,
        file.content_type or "application/octet-stream",
        category, description or None, user.user_id,
    )

    await _log_activity(
        pool, entity_type, entity_id, "attachment_uploaded", user.user_id, user.full_name,
        details={"filename": original_name, "size": file_size},
    )

    logger.info(f"Attachment uploaded: {original_name} → {entity_type}/{entity_id} by {user.user_id}")
    return {"id": row["id"], "filename": disk_filename, "original_name": original_name, "file_size": file_size}


@router.get("/attachments/download/{attachment_id}")
async def download_attachment(request: Request, attachment_id: int):
    """Download a single attachment by ID."""
    _user(request)
    pool = await get_pool()
    row = await pool.fetchrow(
        """SELECT entity_type, entity_id, filename, original_name, mime_type
           FROM grc.attachments WHERE id=$1""",
        attachment_id,
    )
    if not row:
        raise HTTPException(404, "Файл не найден")

    disk_path = os.path.join(
        ATTACHMENTS_PATH, row["entity_type"], str(row["entity_id"]), row["filename"]
    )
    if not os.path.exists(disk_path):
        raise HTTPException(404, "Файл не найден на диске")

    return FileResponse(
        path=disk_path,
        filename=row["original_name"],
        media_type=row["mime_type"],
    )


@router.get("/attachments/{entity_type}/{entity_id}")
async def list_attachments(request: Request, entity_type: str, entity_id: int):
    """List all attachments for an entity."""
    _user(request)
    pool = await get_pool()
    rows = await pool.fetch(
        """SELECT id, filename, original_name, file_size, mime_type, category,
                  description, uploaded_by, uploaded_at
           FROM grc.attachments
           WHERE entity_type=$1 AND entity_id=$2
           ORDER BY uploaded_at DESC""",
        entity_type, entity_id,
    )
    return [dict(r) for r in rows]


@router.delete("/attachments/{attachment_id}")
async def delete_attachment(request: Request, attachment_id: int):
    """Delete an attachment (file + metadata)."""
    user = _user(request)
    pool = await get_pool()
    row = await pool.fetchrow(
        """SELECT entity_type, entity_id, filename, original_name, uploaded_by
           FROM grc.attachments WHERE id=$1""",
        attachment_id,
    )
    if not row:
        raise HTTPException(404, "Файл не найден")

    # Only uploader or admin can delete
    if row["uploaded_by"] != user.user_id and user.role.value != "admin":
        raise HTTPException(403, "Нет прав для удаления")

    # Delete from disk
    disk_path = os.path.join(
        ATTACHMENTS_PATH, row["entity_type"], str(row["entity_id"]), row["filename"]
    )
    if os.path.exists(disk_path):
        os.remove(disk_path)

    # Delete metadata
    await pool.execute("DELETE FROM grc.attachments WHERE id=$1", attachment_id)

    await _log_activity(
        pool, row["entity_type"], row["entity_id"], "attachment_deleted", user.user_id, user.full_name,
        details={"filename": row["original_name"]},
    )

    return {"status": "ok"}


# ══════════════════════════════════════════════════════════════════════
#  DOCUMENT GENERATION (Phase 2)
# ══════════════════════════════════════════════════════════════════════

@router.post("/documents/audit-report/{engagement_id}")
async def generate_audit_report_endpoint(request: Request, engagement_id: int):
    """Generate an Audit Report (.docx) for an engagement and attach it."""
    user = _user(request)
    pool = await get_pool()

    # Load engagement
    eng = await pool.fetchrow(
        """SELECT e.*, p.title as plan_title
           FROM grc.engagements e
           LEFT JOIN grc.audit_plans p ON e.plan_id = p.id
           WHERE e.id=$1""",
        engagement_id,
    )
    if not eng:
        raise HTTPException(404, "Проверка не найдена")

    # Load findings
    findings = await pool.fetch(
        "SELECT * FROM grc.findings WHERE engagement_id=$1 ORDER BY id", engagement_id
    )

    # Load remediations for all findings
    finding_ids = [f["id"] for f in findings]
    remediations = []
    if finding_ids:
        remediations = await pool.fetch(
            "SELECT * FROM grc.remediation_tasks WHERE finding_id = ANY($1) ORDER BY id",
            finding_ids,
        )

    # Load team members
    members = await pool.fetch(
        "SELECT * FROM grc.engagement_members WHERE engagement_id=$1 ORDER BY member_role",
        engagement_id,
    )

    # Generate document
    attach_dir = _get_attachment_dir("engagement", engagement_id)
    doc_filename = f"audit_report_{engagement_id}_{uuid.uuid4().hex[:8]}.docx"
    output_path = os.path.join(attach_dir, doc_filename)

    generate_audit_report(
        engagement=dict(eng),
        findings=[dict(f) for f in findings],
        remediations=[dict(r) for r in remediations],
        members=[dict(m) for m in members],
        output_path=output_path,
    )

    # Save as attachment
    file_size = os.path.getsize(output_path)
    ref = eng.get("title", f"Проверка #{engagement_id}")
    original_name = f"Акт проверки — {ref}.docx"

    row = await pool.fetchrow(
        """INSERT INTO grc.attachments
           (entity_type, entity_id, filename, original_name, file_size, mime_type, category, description, uploaded_by)
           VALUES ('engagement', $1, $2, $3, $4,
                   'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                   'generated', 'Автоматически сгенерированный акт проверки', $5)
           RETURNING id""",
        engagement_id, doc_filename, original_name, file_size, user.user_id,
    )

    await _log_activity(
        pool, "engagement", engagement_id, "document_generated", user.user_id, user.full_name,
        details={"document": "audit_report", "filename": original_name},
    )

    return {"id": row["id"], "filename": doc_filename, "original_name": original_name, "file_size": file_size}


@router.post("/documents/remediation-order/{finding_id}")
async def generate_remediation_order_endpoint(request: Request, finding_id: int):
    """Generate a Remediation Order (.docx) for a finding and attach it."""
    user = _user(request)
    pool = await get_pool()

    # Load finding
    finding = await pool.fetchrow("SELECT * FROM grc.findings WHERE id=$1", finding_id)
    if not finding:
        raise HTTPException(404, "Замечание не найдено")

    # Load engagement
    eng = await pool.fetchrow(
        "SELECT * FROM grc.engagements WHERE id=$1", finding["engagement_id"]
    )

    # Load remediations
    remediations = await pool.fetch(
        "SELECT * FROM grc.remediation_tasks WHERE finding_id=$1 ORDER BY id", finding_id
    )

    # Generate document
    attach_dir = _get_attachment_dir("finding", finding_id)
    doc_filename = f"remediation_order_{finding_id}_{uuid.uuid4().hex[:8]}.docx"
    output_path = os.path.join(attach_dir, doc_filename)

    generate_remediation_order(
        finding=dict(finding),
        engagement=dict(eng) if eng else {},
        remediations=[dict(r) for r in remediations],
        output_path=output_path,
    )

    # Save as attachment
    file_size = os.path.getsize(output_path)
    ref = finding.get("ref_number", f"#{finding_id}")
    original_name = f"Рекомендация — {ref}.docx"

    row = await pool.fetchrow(
        """INSERT INTO grc.attachments
           (entity_type, entity_id, filename, original_name, file_size, mime_type, category, description, uploaded_by)
           VALUES ('finding', $1, $2, $3, $4,
                   'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                   'generated', 'Автоматически сгенерированная рекомендация', $5)
           RETURNING id""",
        finding_id, doc_filename, original_name, file_size, user.user_id,
    )

    await _log_activity(
        pool, "finding", finding_id, "document_generated", user.user_id, user.full_name,
        details={"document": "remediation_order", "filename": original_name},
    )

    return {"id": row["id"], "filename": doc_filename, "original_name": original_name, "file_size": file_size}
# ══════════════════════════════════════════════════════════════════
#  AUDIT UNIVERSE & STRATEGIC PLANNING ENDPOINTS
#  Append this entire block to the END of ui/routers/grc.py
# ══════════════════════════════════════════════════════════════════


# ── Risk calculation helper ──────────────────────────────────────

async def _calc_risk_score(pool, object_id: int):
    """Recalculate composite score and risk level for an audit object.
    Uses МКБ 4-block model:
      Block 1 (Process): reg×0.3 + auto×0.2 + changes×0.2 + sor×0.3
      Block 2 (СВК):     dva×0.4 + internal×0.3 + regulators×0.3
      Block 3 (Importance): financial×0.5 + strategic×0.5
      Residual risk: 2 if process≥2.0 AND svk≥1.5 else 1
      Final: (residual + importance) / 2
    """
    cfg = await _get_config(pool, 'risk_scoring', 'weights')
    thresholds = (cfg or {}).get('thresholds', [
        {'min_score': 2.0, 'risk_level': 'high',   'frequency': 'annual'},
        {'min_score': 1.5, 'risk_level': 'medium',  'frequency': 'biennial'},
        {'min_score': 0.0, 'risk_level': 'low',     'frequency': 'triennial'},
    ])

    rows = await pool.fetch(
        "SELECT dimension, score FROM grc.risk_scores WHERE audit_object_id = $1",
        object_id
    )

    if not rows:
        await pool.execute(
            """UPDATE grc.audit_objects
               SET composite_score = 0, risk_level = 'low',
                   process_composite = 0, svk_composite = 0,
                   importance_composite = 0, residual_risk = 1,
                   updated_at = NOW()
               WHERE id = $1""", object_id
        )
        return 0.0, 'low'

    scores = {r['dimension']: r['score'] for r in rows}

    # Block 1: Process
    process_comp = round(
        scores.get('process_regulation', 1) * 0.3 +
        scores.get('process_automation', 1) * 0.2 +
        scores.get('process_changes', 1) * 0.2 +
        scores.get('process_sor', 1) * 0.3,
        2
    )

    # Block 2: СВК
    svk_comp = round(
        scores.get('svk_dva', 1) * 0.4 +
        scores.get('svk_internal', 1) * 0.3 +
        scores.get('svk_regulator', 1) * 0.3,
        2
    )

    # Block 3: Importance
    importance_comp = round(
        scores.get('importance_financial', 1) * 0.5 +
        scores.get('importance_strategic', 1) * 0.5,
        2
    )

    # Residual risk
    residual = 2 if (process_comp >= 2.0 and svk_comp >= 1.5) else 1

    # Final composite
    composite = round((residual + importance_comp) / 2, 2)

    # Determine risk level
    risk_level = 'low'
    frequency = 'triennial'
    for t in sorted(thresholds, key=lambda x: -x['min_score']):
        if composite >= t['min_score']:
            risk_level = t['risk_level']
            frequency = t.get('frequency', 'biennial')
            break

    # Auto-determine conclusion from score + regulatory flag
    reg_required = await pool.fetchval(
        "SELECT regulatory_required FROM grc.audit_objects WHERE id = $1", object_id
    )
    if reg_required:
        conclusion = 'current_year'
    elif composite >= 2.0:
        conclusion = 'current_year'
    elif composite >= 1.5:
        conclusion = 'next_year'
    else:
        conclusion = 'year_three'

    await pool.execute(
        """UPDATE grc.audit_objects
           SET composite_score = $2, risk_level = $3, audit_frequency = $4,
               process_composite = $5, svk_composite = $6,
               importance_composite = $7, residual_risk = $8,
               conclusion = $9,
               updated_at = NOW()
           WHERE id = $1""",
        object_id, composite, risk_level, frequency,
        process_comp, svk_comp, importance_comp, residual,
        conclusion
    )

    return composite, risk_level


# ── AUDIT OBJECTS: List ──────────────────────────────────────────

@router.get("/audit-objects")
async def list_audit_objects(request: Request):
    user = _user(request)
    pool = await get_pool()

    category = request.query_params.get("category")
    risk_level = request.query_params.get("risk_level")
    division = request.query_params.get("division")
    status = request.query_params.get("status", "active")
    search = request.query_params.get("search", "").strip()

    conditions = ["ao.status = $1"]
    params: list = [status]
    idx = 2

    if category:
        conditions.append(f"ao.category = ${idx}")
        params.append(category)
        idx += 1

    if risk_level:
        conditions.append(f"ao.risk_level = ${idx}")
        params.append(risk_level)
        idx += 1

    if division:
        conditions.append(f"ao.audit_division = ${idx}")
        params.append(division)
        idx += 1

    if search:
        conditions.append(f"(ao.name ILIKE ${idx} OR ao.description ILIKE ${idx})")
        params.append(f"%{search}%")
        idx += 1

    where = " AND ".join(conditions)

    rows = await pool.fetch(f"""
        SELECT ao.id, ao.name, ao.description, ao.category,
               ao.owner_unit_id, ou.name AS owner_unit_name,
               ao.status, ao.audit_frequency,
               to_char(ao.last_audit_date, 'DD.MM.YYYY') AS last_audit_date,
               ao.last_audit_result,
               ao.composite_score, ao.risk_level,
               ao.audit_division, ao.conclusion, ao.regulatory_required,
               ao.process_composite, ao.svk_composite,
               ao.importance_composite, ao.residual_risk,
               ao.risk_flags,
               to_char(ao.created_at, 'DD.MM.YYYY') AS created_at,
               to_char(ao.updated_at, 'DD.MM.YYYY HH24:MI') AS updated_at
        FROM grc.audit_objects ao
        LEFT JOIN grc.org_units ou ON ou.id = ao.owner_unit_id
        WHERE {where}
        ORDER BY
            CASE ao.risk_level
                WHEN 'high' THEN 1
                WHEN 'medium' THEN 2
                WHEN 'low' THEN 3
            END,
            ao.composite_score DESC
    """, *params)

    return [dict(r) for r in rows]


# ── AUDIT OBJECTS: Detail ────────────────────────────────────────

@router.get("/audit-objects/{object_id}")
async def get_audit_object(request: Request, object_id: int):
    user = _user(request)
    pool = await get_pool()

    obj = await pool.fetchrow("""
        SELECT ao.*, ou.name AS owner_unit_name,
               to_char(ao.last_audit_date, 'DD.MM.YYYY') AS last_audit_date_str,
               to_char(ao.created_at, 'DD.MM.YYYY HH24:MI') AS created_at_str,
               to_char(ao.updated_at, 'DD.MM.YYYY HH24:MI') AS updated_at_str
        FROM grc.audit_objects ao
        LEFT JOIN grc.org_units ou ON ou.id = ao.owner_unit_id
        WHERE ao.id = $1
    """, object_id)

    if not obj:
        raise HTTPException(status_code=404, detail="Объект аудита не найден")

    result = dict(obj)

    # Ensure risk_flags is a dict (asyncpg returns JSONB as dict)
    if result.get('risk_flags') is None:
        result['risk_flags'] = {}

    # Risk scores
    scores = await pool.fetch("""
        SELECT dimension, score, comment, updated_by,
               to_char(updated_at, 'DD.MM.YYYY') AS updated_at_str
        FROM grc.risk_scores
        WHERE audit_object_id = $1
        ORDER BY dimension
    """, object_id)
    result['risk_scores'] = {s['dimension']: dict(s) for s in scores}

    # Strategic plan references
    refs = await pool.fetch("""
        SELECT spi.planned_year, spi.quarter, spi.priority,
               sp.title AS plan_title, sp.id AS plan_id
        FROM grc.strategic_plan_items spi
        JOIN grc.strategic_plans sp ON sp.id = spi.strategic_plan_id
        WHERE spi.audit_object_id = $1
        ORDER BY spi.planned_year
    """, object_id)
    result['strategic_refs'] = [dict(r) for r in refs]

    return result


# ── AUDIT OBJECTS: Create ────────────────────────────────────────
# _user() for attribute access, _require_manager() for auth check

@router.post("/audit-objects")
async def create_audit_object(request: Request):
    user = _user(request)
    _require_manager(request)
    pool = await get_pool()
    data = await request.json()

    name = (data.get("name") or "").strip()
    if not name:
        raise HTTPException(status_code=400, detail="Название объекта обязательно")

    # Parse optional date
    last_audit_date = None
    if data.get("last_audit_date"):
        try:
            from datetime import datetime as _dt
            last_audit_date = _dt.strptime(data["last_audit_date"], "%Y-%m-%d").date()
        except (ValueError, TypeError):
            pass

    owner_unit_id = data.get("owner_unit_id")
    if owner_unit_id is not None:
        try:
            owner_unit_id = int(owner_unit_id)
        except (ValueError, TypeError):
            owner_unit_id = None

    row = await pool.fetchrow("""
        INSERT INTO grc.audit_objects
            (name, description, category, owner_unit_id, status,
             audit_frequency, last_audit_date, last_audit_result,
             audit_division, created_by)
        VALUES ($1, $2, $3, $4, 'active', $5, $6, $7, $8, $9)
        RETURNING id
    """,
        name,
        (data.get("description") or "").strip(),
        data.get("category", "business_process"),
        owner_unit_id,
        data.get("audit_frequency", "triennial"),
        last_audit_date,
        (data.get("last_audit_result") or "").strip(),
        data.get("audit_division"),
        user.user_id
    )

    object_id = row["id"]

    await _log_activity(
        pool, 'audit_object', object_id, 'created',
        user.user_id, user.full_name, None, None,
        f"Создан объект аудита: {name}"
    )

    return {"id": object_id, "status": "created"}


# ── AUDIT OBJECTS: Update ────────────────────────────────────────
# _user() for attribute access, _require_manager() for auth check

@router.put("/audit-objects/{object_id}")
async def update_audit_object(request: Request, object_id: int):
    user = _user(request)
    _require_manager(request)
    pool = await get_pool()
    data = await request.json()

    existing = await pool.fetchrow(
        "SELECT * FROM grc.audit_objects WHERE id = $1", object_id
    )
    if not existing:
        raise HTTPException(status_code=404, detail="Объект аудита не найден")

    name = (data.get("name") or str(existing["name"])).strip()

    last_audit_date = existing["last_audit_date"]
    if "last_audit_date" in data and data["last_audit_date"]:
        try:
            from datetime import datetime as _dt
            last_audit_date = _dt.strptime(data["last_audit_date"], "%Y-%m-%d").date()
        except (ValueError, TypeError):
            pass
    elif "last_audit_date" in data and not data["last_audit_date"]:
        last_audit_date = None

    owner_unit_id = existing["owner_unit_id"]
    if "owner_unit_id" in data:
        try:
            owner_unit_id = int(data["owner_unit_id"]) if data["owner_unit_id"] else None
        except (ValueError, TypeError):
            pass

    await pool.execute("""
        UPDATE grc.audit_objects
        SET name = $2, description = $3, category = $4,
            owner_unit_id = $5, audit_frequency = $6,
            last_audit_date = $7, last_audit_result = $8,
            audit_division = $9,
            updated_at = NOW()
        WHERE id = $1
    """,
        object_id, name,
        (data.get("description") or str(existing["description"] or "")).strip(),
        data.get("category", existing["category"]),
        owner_unit_id,
        data.get("audit_frequency", existing["audit_frequency"]),
        last_audit_date,
        (data.get("last_audit_result") or str(existing["last_audit_result"] or "")).strip(),
        data.get("audit_division", existing.get("audit_division")),
    )

    await _log_activity(
        pool, 'audit_object', object_id, 'updated',
        user.user_id, user.full_name, None, None,
        f"Обновлён объект аудита: {name}"
    )

    return {"status": "updated"}


# ── AUDIT OBJECTS: Archive (soft delete) ─────────────────────────
# _user() for attribute access, _require_admin() for auth check

@router.delete("/audit-objects/{object_id}")
async def archive_audit_object(request: Request, object_id: int):
    user = _user(request)
    _require_admin(request)
    pool = await get_pool()

    existing = await pool.fetchrow(
        "SELECT name FROM grc.audit_objects WHERE id = $1", object_id
    )
    if not existing:
        raise HTTPException(status_code=404, detail="Объект аудита не найден")

    await pool.execute(
        "UPDATE grc.audit_objects SET status = 'archived', updated_at = NOW() WHERE id = $1",
        object_id
    )

    await _log_activity(
        pool, 'audit_object', object_id, 'archived',
        user.user_id, user.full_name, 'active', 'archived',
        f"Архивирован объект: {existing['name']}"
    )

    return {"status": "archived"}


# ── AUDIT OBJECTS: Save risk scores ──────────────────────────────
# _user() for attribute access, _require_manager() for auth check

@router.post("/audit-objects/{object_id}/score")
async def save_risk_scores(request: Request, object_id: int):
    """Save/update risk scores and recalculate composite.
    Expects: {
        "scores": {"process_regulation": 2, "svk_dva": 3, ...},
        "risk_flags": {"credit": true, "operational": true, ...},
        "regulatory_required": false,
        "kar_request": false,
        "other_factors": false
    }
    """
    user = _user(request)
    _require_manager(request)
    pool = await get_pool()
    data = await request.json()

    existing = await pool.fetchrow(
        "SELECT id, name FROM grc.audit_objects WHERE id = $1", object_id
    )
    if not existing:
        raise HTTPException(status_code=404, detail="Объект аудита не найден")

    scores = data.get("scores", {})
    comments = data.get("comments", {})

    valid_dims = [
        'process_regulation', 'process_automation', 'process_changes', 'process_sor',
        'svk_dva', 'svk_internal', 'svk_regulator',
        'importance_financial', 'importance_strategic'
    ]

    async with pool.acquire() as conn:
        async with conn.transaction():
            for dim in valid_dims:
                if dim in scores:
                    score_val = max(1, min(3, int(scores[dim])))
                    comment_val = comments.get(dim, "")
                    await conn.execute("""
                        INSERT INTO grc.risk_scores
                            (audit_object_id, dimension, score, comment, updated_by)
                        VALUES ($1, $2, $3, $4, $5)
                        ON CONFLICT (audit_object_id, dimension)
                        DO UPDATE SET score = excluded.score, comment = excluded.comment,
                                      updated_by = excluded.updated_by, updated_at = NOW()
                    """, object_id, dim, score_val, comment_val, user.user_id)

    # Update risk_flags and regulatory toggles if provided
    updates = []
    params = [object_id]
    idx = 2

    if "risk_flags" in data:
        updates.append(f"risk_flags = ${idx}::jsonb")
        params.append(json.dumps(data["risk_flags"]))
        idx += 1

    if "regulatory_required" in data:
        updates.append(f"regulatory_required = ${idx}")
        params.append(bool(data["regulatory_required"]))
        idx += 1

    if "kar_request" in data:
        updates.append(f"kar_request = ${idx}")
        params.append(bool(data["kar_request"]))
        idx += 1

    if "other_factors" in data:
        updates.append(f"other_factors = ${idx}")
        params.append(bool(data["other_factors"]))
        idx += 1

    if updates:
        await pool.execute(
            f"UPDATE grc.audit_objects SET {', '.join(updates)}, updated_at = NOW() WHERE id = $1",
            *params
        )

    composite, risk_level = await _calc_risk_score(pool, object_id)

    await _log_activity(
        pool, 'audit_object', object_id, 'risk_scored',
        user.user_id, user.full_name, None, f"{composite} ({risk_level})",
        f"Обновлена оценка рисков: {composite:.2f} — {risk_level}"
    )

    return {"status": "scored", "composite_score": composite, "risk_level": risk_level}


# ══════════════════════════════════════════════════════════════════
#  STRATEGIC PLANS ENDPOINTS
# ══════════════════════════════════════════════════════════════════


# ── STRATEGIC PLANS: List ────────────────────────────────────────

@router.get("/strategic-plans")
async def list_strategic_plans(request: Request):
    user = _user(request)
    pool = await get_pool()

    status_filter = request.query_params.get("status")

    base_query = """
        SELECT sp.id, sp.title, sp.period_start, sp.period_end,
               sp.description, sp.status, sp.approved_by,
               to_char(sp.approved_at, 'DD.MM.YYYY') AS approved_at_str,
               to_char(sp.created_at, 'DD.MM.YYYY') AS created_at_str,
               sp.created_by,
               (SELECT COUNT(*) FROM grc.strategic_plan_items spi
                WHERE spi.strategic_plan_id = sp.id) AS item_count,
               (SELECT COUNT(DISTINCT spi.audit_object_id)
                FROM grc.strategic_plan_items spi
                WHERE spi.strategic_plan_id = sp.id) AS objects_covered,
               (SELECT COUNT(*) FROM grc.audit_objects
                WHERE status = 'active') AS total_objects
        FROM grc.strategic_plans sp
    """

    if status_filter:
        rows = await pool.fetch(
            base_query + " WHERE sp.status = $1 ORDER BY sp.period_start DESC", status_filter
        )
    else:
        rows = await pool.fetch(base_query + " ORDER BY sp.period_start DESC")

    result = []
    for r in rows:
        d = dict(r)
        total = d.get('total_objects', 0)
        covered = d.get('objects_covered', 0)
        d['coverage_pct'] = round(covered / total * 100, 1) if total > 0 else 0
        result.append(d)

    return result


# ── STRATEGIC PLANS: Detail ──────────────────────────────────────

@router.get("/strategic-plans/{plan_id}")
async def get_strategic_plan(request: Request, plan_id: int):
    user = _user(request)
    pool = await get_pool()

    sp = await pool.fetchrow("""
        SELECT sp.*,
               to_char(sp.approved_at, 'DD.MM.YYYY') AS approved_at_str,
               to_char(sp.created_at, 'DD.MM.YYYY HH24:MI') AS created_at_str,
               to_char(sp.updated_at, 'DD.MM.YYYY HH24:MI') AS updated_at_str
        FROM grc.strategic_plans sp
        WHERE sp.id = $1
    """, plan_id)

    if not sp:
        raise HTTPException(status_code=404, detail="Стратегический план не найден")

    result = dict(sp)

    # Get all items grouped by year
    items = await pool.fetch("""
        SELECT spi.id AS item_id, spi.audit_object_id, spi.planned_year,
               spi.quarter, spi.priority, spi.notes, spi.linked_plan_id,
               ao.name AS object_name, ao.category, ao.composite_score,
               ao.risk_level, ao.audit_frequency,
               ao.audit_division, ao.conclusion, ao.regulatory_required,
               to_char(ao.last_audit_date, 'DD.MM.YYYY') AS last_audit_date
        FROM grc.strategic_plan_items spi
        JOIN grc.audit_objects ao ON ao.id = spi.audit_object_id
        WHERE spi.strategic_plan_id = $1
        ORDER BY
            CASE ao.risk_level
                WHEN 'high' THEN 1
                WHEN 'medium' THEN 2
                WHEN 'low' THEN 3
            END,
            ao.composite_score DESC,
            spi.planned_year
    """, plan_id)
    result['items'] = [dict(i) for i in items]

    # Get all active audit objects for the matrix
    all_objects = await pool.fetch("""
        SELECT id, name, category, composite_score, risk_level, audit_frequency,
               audit_division, conclusion, regulatory_required,
               to_char(last_audit_date, 'DD.MM.YYYY') AS last_audit_date
        FROM grc.audit_objects
        WHERE status = 'active'
        ORDER BY
            CASE risk_level
                WHEN 'high' THEN 1
                WHEN 'medium' THEN 2
                WHEN 'low' THEN 3
            END,
            composite_score DESC
    """)
    result['all_objects'] = [dict(o) for o in all_objects]

    # Coverage stats
    total_objects = len(all_objects)
    covered_ids = set(i['audit_object_id'] for i in items)
    result['coverage'] = {
        'total': total_objects,
        'covered': len(covered_ids),
        'pct': round(len(covered_ids) / total_objects * 100, 1) if total_objects > 0 else 0
    }

    # Per-year stats
    year_stats = {}
    for yr in range(sp['period_start'], sp['period_end'] + 1):
        yr_items = [i for i in items if i['planned_year'] == yr]
        year_stats[yr] = {
            'count': len(yr_items),
            'object_ids': [i['audit_object_id'] for i in yr_items]
        }
    result['year_stats'] = year_stats

    return result


# ── STRATEGIC PLANS: Create ──────────────────────────────────────
# _user() for attribute access, _require_manager() for auth check

@router.post("/strategic-plans")
async def create_strategic_plan(request: Request):
    user = _user(request)
    _require_manager(request)
    pool = await get_pool()
    data = await request.json()

    title = (data.get("title") or "").strip()
    if not title:
        raise HTTPException(status_code=400, detail="Название плана обязательно")

    period_start = int(data.get("period_start", 2026))
    period_end = int(data.get("period_end", 2028))
    if period_end <= period_start:
        raise HTTPException(status_code=400, detail="Конечный год должен быть больше начального")

    row = await pool.fetchrow("""
        INSERT INTO grc.strategic_plans
            (title, period_start, period_end, description, status, created_by)
        VALUES ($1, $2, $3, $4, 'draft', $5)
        RETURNING id
    """,
        title, period_start, period_end,
        (data.get("description") or "").strip(),
        user.user_id
    )

    plan_id = row['id']

    await _log_activity(
        pool, 'strategic_plan', plan_id, 'created',
        user.user_id, user.full_name, None, None,
        f"Создан стратегический план: {title} ({period_start}–{period_end})"
    )

    return {"id": plan_id, "status": "created"}


# ── STRATEGIC PLANS: Update ──────────────────────────────────────
# _user() for attribute access, _require_manager() for auth check

@router.put("/strategic-plans/{plan_id}")
async def update_strategic_plan(request: Request, plan_id: int):
    user = _user(request)
    _require_manager(request)
    pool = await get_pool()
    data = await request.json()

    existing = await pool.fetchrow(
        "SELECT * FROM grc.strategic_plans WHERE id = $1", plan_id
    )
    if not existing:
        raise HTTPException(status_code=404, detail="Стратегический план не найден")

    if existing['status'] not in ('draft', 'under_review'):
        raise HTTPException(status_code=400,
            detail="Редактирование возможно только в статусах 'Черновик' или 'На рассмотрении'")

    await pool.execute("""
        UPDATE grc.strategic_plans
        SET title = $2, description = $3, updated_at = NOW()
        WHERE id = $1
    """,
        plan_id,
        (data.get("title") or str(existing["title"])).strip(),
        (data.get("description") or str(existing["description"] or "")).strip(),
    )

    await _log_activity(
        pool, 'strategic_plan', plan_id, 'updated',
        user.user_id, user.full_name, None, None,
        "Обновлён стратегический план"
    )

    return {"status": "updated"}


# ── STRATEGIC PLANS: Transition ──────────────────────────────────
# _user() for attribute access, _require_manager() for auth check

@router.post("/strategic-plans/{plan_id}/transition")
async def transition_strategic_plan(request: Request, plan_id: int):
    user = _user(request)
    _require_manager(request)
    pool = await get_pool()
    data = await request.json()

    new_status = data.get("status", "").strip()
    if not new_status:
        raise HTTPException(status_code=400, detail="Новый статус обязателен")

    existing = await pool.fetchrow(
        "SELECT id, title, status FROM grc.strategic_plans WHERE id = $1", plan_id
    )
    if not existing:
        raise HTTPException(status_code=404, detail="Стратегический план не найден")

    old_status = existing['status']

    # Validate transition
    allowed = await _validate_transition(pool, 'strategic_plan', old_status, new_status)
    if not allowed:
        raise HTTPException(status_code=400,
            detail=f"Переход из '{old_status}' в '{new_status}' недопустим")

    update_fields = "status = $2, updated_at = NOW()"
    params = [plan_id, new_status]

    if new_status == 'approved':
        update_fields += ", approved_by = $3, approved_at = NOW()"
        params.append(user.user_id)

    await pool.execute(
        f"UPDATE grc.strategic_plans SET {update_fields} WHERE id = $1",
        *params
    )

    await _log_activity(
        pool, 'strategic_plan', plan_id, 'transitioned',
        user.user_id, user.full_name, old_status, new_status,
        f"Статус изменён: {old_status} → {new_status}"
    )

    return {"status": new_status}


# ── STRATEGIC PLANS: Add/Update Items (batch) ───────────────────
# _user() for attribute access, _require_manager() for auth check

@router.post("/strategic-plans/{plan_id}/items")
async def upsert_strategic_plan_items(request: Request, plan_id: int):
    """Add or update matrix assignments.
    Expects: {"items": [{"audit_object_id": 1, "planned_year": 2026, "quarter": "Q1", "priority": "high", "notes": "..."}]}
    Also supports toggle mode: {"audit_object_id": 1, "planned_year": 2026}
    """
    user = _user(request)
    _require_manager(request)
    pool = await get_pool()
    data = await request.json()

    existing = await pool.fetchrow(
        "SELECT id, status FROM grc.strategic_plans WHERE id = $1", plan_id
    )
    if not existing:
        raise HTTPException(status_code=404, detail="Стратегический план не найден")

    # Toggle mode: single item add/remove
    if "audit_object_id" in data and "planned_year" in data and "items" not in data:
        obj_id = int(data["audit_object_id"])
        year = int(data["planned_year"])

        existing_item = await pool.fetchrow("""
            SELECT id FROM grc.strategic_plan_items
            WHERE strategic_plan_id = $1 AND audit_object_id = $2 AND planned_year = $3
        """, plan_id, obj_id, year)

        if existing_item:
            await pool.execute(
                "DELETE FROM grc.strategic_plan_items WHERE id = $1",
                existing_item['id']
            )
            return {"action": "removed", "audit_object_id": obj_id, "planned_year": year}
        else:
            # Get object risk level for default priority
            obj = await pool.fetchrow(
                "SELECT risk_level FROM grc.audit_objects WHERE id = $1", obj_id
            )
            priority = (obj['risk_level'] if obj else 'medium')
            if priority not in ('critical', 'high', 'medium', 'low'):
                priority = 'medium'

            await pool.execute("""
                INSERT INTO grc.strategic_plan_items
                    (strategic_plan_id, audit_object_id, planned_year, priority)
                VALUES ($1, $2, $3, $4)
                ON CONFLICT (strategic_plan_id, audit_object_id, planned_year) DO NOTHING
            """, plan_id, obj_id, year, priority)
            return {"action": "added", "audit_object_id": obj_id, "planned_year": year}

    # Batch mode
    items = data.get("items", [])
    added = 0
    async with pool.acquire() as conn:
        async with conn.transaction():
            for item in items:
                obj_id = int(item["audit_object_id"])
                year = int(item["planned_year"])
                quarter = item.get("quarter")
                priority = item.get("priority", "medium")
                notes = item.get("notes", "")

                await conn.execute("""
                    INSERT INTO grc.strategic_plan_items
                        (strategic_plan_id, audit_object_id, planned_year,
                         quarter, priority, notes)
                    VALUES ($1, $2, $3, $4, $5, $6)
                    ON CONFLICT (strategic_plan_id, audit_object_id, planned_year)
                    DO UPDATE SET quarter = $4, priority = $5, notes = $6
                """, plan_id, obj_id, year, quarter, priority, notes)
                added += 1

    await _log_activity(
        pool, 'strategic_plan', plan_id, 'items_updated',
        user.user_id, user.full_name, None, None,
        f"Обновлена матрица покрытия: {added} записей"
    )

    return {"status": "updated", "items_processed": added}


# ── STRATEGIC PLANS: Remove Item ─────────────────────────────────

@router.delete("/strategic-plans/{plan_id}/items/{item_id}")
async def delete_strategic_plan_item(request: Request, plan_id: int, item_id: int):
    user = _require_manager(request)
    pool = await get_pool()

    existing = await pool.fetchrow(
        "SELECT id FROM grc.strategic_plan_items WHERE id = $1 AND strategic_plan_id = $2",
        item_id, plan_id
    )
    if not existing:
        raise HTTPException(status_code=404, detail="Элемент не найден")

    await pool.execute(
        "DELETE FROM grc.strategic_plan_items WHERE id = $1", item_id
    )

    return {"status": "deleted"}


# ── STRATEGIC PLANS: Generate Annual Plan ────────────────────────
# _user() for attribute access, _require_manager() for auth check

@router.post("/strategic-plans/{plan_id}/generate-annual")
async def generate_annual_plan(request: Request, plan_id: int):
    """Generate a Годовой план аудита from a strategic plan year slice.
    Expects: {"year": 2026}
    Creates an audit_plan + engagements for each assigned object.
    """
    user = _user(request)
    _require_manager(request)
    pool = await get_pool()
    data = await request.json()

    year = int(data.get("year", 0))
    if not year:
        raise HTTPException(status_code=400, detail="Год обязателен")

    sp = await pool.fetchrow(
        "SELECT * FROM grc.strategic_plans WHERE id = $1", plan_id
    )
    if not sp:
        raise HTTPException(status_code=404, detail="Стратегический план не найден")

    if year < sp['period_start'] or year > sp['period_end']:
        raise HTTPException(status_code=400,
            detail=f"Год {year} вне диапазона плана ({sp['period_start']}–{sp['period_end']})")

    # Get items for this year
    items = await pool.fetch("""
        SELECT spi.*, ao.name AS object_name, ao.description AS object_description,
               ao.risk_level, ao.category
        FROM grc.strategic_plan_items spi
        JOIN grc.audit_objects ao ON ao.id = spi.audit_object_id
        WHERE spi.strategic_plan_id = $1 AND spi.planned_year = $2
        ORDER BY
            CASE ao.risk_level
                WHEN 'critical' THEN 1 WHEN 'high' THEN 2
                WHEN 'medium' THEN 3 WHEN 'low' THEN 4
            END
    """, plan_id, year)

    if not items:
        raise HTTPException(status_code=400,
            detail=f"Нет назначенных объектов на {year} год")

    async with pool.acquire() as conn:
        async with conn.transaction():
            # Create annual plan
            plan_row = await conn.fetchrow("""
                INSERT INTO grc.audit_plans
                    (title, description, year, status, created_by)
                VALUES ($1, $2, $3, 'draft', $4)
                RETURNING id
            """,
                f"Годовой план аудита {year}",
                f"Сформирован из стратегического плана «{sp['title']}» ({sp['period_start']}–{sp['period_end']})",
                year,
                user.user_id
            )
            annual_plan_id = plan_row['id']

            # Quarter-to-date mapping for spreading engagements
            quarter_dates = {
                'Q1': (f'{year}-01-15', f'{year}-03-31'),
                'Q2': (f'{year}-04-01', f'{year}-06-30'),
                'Q3': (f'{year}-07-01', f'{year}-09-30'),
                'Q4': (f'{year}-10-01', f'{year}-12-15'),
            }

            for item in items:
                q = item['quarter'] or 'Q2'  # default to Q2 if no quarter
                start_date, end_date = quarter_dates.get(q, quarter_dates['Q2'])

                # Create engagement for each object
                eng_row = await conn.fetchrow("""
                    INSERT INTO grc.engagements
                        (plan_id, title, description, status, risk_level,
                         planned_start, planned_end, created_by)
                    VALUES ($1, $2, $3, 'planned', $4, $5, $6, $7)
                    RETURNING id
                """,
                    annual_plan_id,
                    f"Аудит: {item['object_name']}",
                    item['object_description'] or f"Аудиторская проверка объекта «{item['object_name']}» в рамках стратегического плана.",
                    item['risk_level'] or 'medium',
                    start_date,
                    end_date,
                    user.user_id
                )

                # Link the strategic plan item to the generated annual plan
                await conn.execute("""
                    UPDATE grc.strategic_plan_items
                    SET linked_plan_id = $1
                    WHERE id = $2
                """, annual_plan_id, item['id'])

    await _log_activity(
        pool, 'strategic_plan', plan_id, 'annual_generated',
        user.user_id, user.full_name, None, str(annual_plan_id),
        f"Сформирован годовой план на {year} год (ID: {annual_plan_id}, проверок: {len(items)})"
    )

    await _log_activity(
        pool, 'plan', annual_plan_id, 'created',
        user.user_id, user.full_name, None, None,
        f"Годовой план создан из стратегического плана «{sp['title']}»"
    )

    return {
        "status": "generated",
        "annual_plan_id": annual_plan_id,
        "engagements_created": len(items),
        "year": year
    }