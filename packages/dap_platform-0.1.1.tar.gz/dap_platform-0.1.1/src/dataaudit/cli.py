"""
CLI for DataAudit Platform.

Usage:
    dataaudit serve [--port 8080] [--host 127.0.0.1] [--db path/to/db]
    dataaudit init-db [--db path/to/db]
"""

import argparse
import sys
import os


def main():
    parser = argparse.ArgumentParser(
        prog="dataaudit",
        description="DataAudit Platform — Audit Management & Analytics"
    )
    sub = parser.add_subparsers(dest="command")

    # serve
    serve_p = sub.add_parser("serve", help="Start the platform")
    serve_p.add_argument("--port", type=int, default=8080)
    serve_p.add_argument("--host", default="127.0.0.1")
    serve_p.add_argument("--db", default=None, help="SQLite database path")

    # init-db
    init_p = sub.add_parser("init-db", help="Initialize/reset the database")
    init_p.add_argument("--db", default=None, help="SQLite database path")

    args = parser.parse_args()

    if args.command == "serve":
        _serve(args)
    elif args.command == "init-db":
        _init_db(args)
    else:
        parser.print_help()
        sys.exit(1)


def _serve(args):
    if args.db:
        os.environ["DAP_DB_PATH"] = args.db

    # Set dev mode defaults
    os.environ.setdefault("DAP_DEV_MODE", "true")
    os.environ.setdefault("SMTP_ENABLED", "false")

    # Auto-init DB if needed
    from .database import get_db
    from .schema import init_db
    db = get_db()
    init_db(db)

    import uvicorn
    print(f"\n  DataAudit Platform v0.1.0")
    print(f"  http://{args.host}:{args.port}")
    print(f"  Login: admin / admin\n")

    uvicorn.run(
        "dataaudit.app:app",
        host=args.host,
        port=args.port,
        log_level="info",
    )


def _init_db(args):
    if args.db:
        os.environ["DAP_DB_PATH"] = args.db
    from .database import get_db
    from .schema import init_db
    db = get_db()
    init_db(db)
    print(f"Database initialized: {db.db_path}")


if __name__ == "__main__":
    main()
