"""
DAP Database Abstraction Layer.
Wraps sqlite3 to match asyncpg's Pool interface.
Methods are declared async (but sync internally)
so routers don't need to change their await calls.
"""

import os
import re
import sqlite3
import json
import logging
from pathlib import Path
from typing import Optional, Any, List

logger = logging.getLogger("dap.db")

# Columns known to store JSON (were JSONB in PostgreSQL)
_JSON_COLUMNS = frozenset({
    "metadata", "config", "chart_config", "extra_params",
    "risk_flags", "details",
})


class DictRow(dict):
    """Row that supports both dict-style and attribute access.
    Auto-deserializes known JSON columns from TEXT to dict."""

    def __init__(self, mapping):
        super().__init__(mapping)
        for key in _JSON_COLUMNS:
            if key in self and isinstance(self[key], str):
                try:
                    self[key] = json.loads(self[key])
                except (json.JSONDecodeError, ValueError):
                    pass

    def __getattr__(self, name):
        try:
            return self[name]
        except KeyError:
            raise AttributeError(name)


def _adapt_params(sql: str, args: tuple) -> tuple:
    """Convert asyncpg-style SQL to sqlite3-style."""

    # 1. Schema prefixes → underscores: grc.table → grc_table
    sql = re.sub(r'\b(grc|bi|config|audit)\.', r'\1_', sql)

    # 2. Parameter placeholders: $1, $2 ... → ?
    sql = re.sub(r'\$\d+', '?', sql)

    # 3. NOW() → datetime('now')
    sql = re.sub(r'\bNOW\(\)', "datetime('now')", sql, flags=re.IGNORECASE)

    # 4. ILIKE → LIKE
    sql = re.sub(r'\bILIKE\b', 'LIKE', sql, flags=re.IGNORECASE)

    # 5. Strip type casts: ::jsonb, ::text, ::date, etc.
    sql = re.sub(r'::\w+', '', sql)

    return sql, args


def _to_char(val, fmt):
    """SQLite replacement for PostgreSQL to_char()."""
    if val is None:
        return None
    s = str(val)
    # Handle ISO dates: 2025-06-15 or 2025-06-15 10:30:00
    parts = s.split(" ")
    date_part = parts[0] if parts else s
    time_part = parts[1] if len(parts) > 1 else ""
    dp = date_part.split("-")
    if len(dp) == 3:
        dd, mm, yyyy = dp[2][:2], dp[1], dp[0]
    else:
        return s
    if "HH24" in fmt and time_part:
        tp = time_part.split(":")
        return f"{dd}.{mm}.{yyyy} {tp[0]}:{tp[1]}" if len(tp) >= 2 else f"{dd}.{mm}.{yyyy}"
    return f"{dd}.{mm}.{yyyy}"


class Database:
    """SQLite database with asyncpg-compatible interface."""

    def __init__(self, db_path: str = None):
        if db_path is None:
            db_path = os.getenv("DAP_DB_PATH")
        if db_path is None:
            data_dir = Path.home() / ".dataaudit"
            data_dir.mkdir(exist_ok=True)
            db_path = str(data_dir / "dataaudit.db")

        self.db_path = db_path
        self._conn: Optional[sqlite3.Connection] = None
        logger.info(f"Database: {db_path}")

    def connect(self):
        self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._conn.create_function("to_char", 2, _to_char)
        self._in_transaction = False

    def _auto_commit(self):
        """Commit unless inside an explicit transaction."""
        if not self._in_transaction:
            self._conn.commit()

    def close(self):
        if self._conn:
            self._conn.close()
            self._conn = None

    async def fetch(self, sql: str, *args) -> List[DictRow]:
        """Execute query, return list of DictRow."""
        sql, args = _adapt_params(sql, args)

        # Handle RETURNING clause
        returning_col = None
        returning_match = re.search(r'\bRETURNING\s+(\w+)', sql, re.IGNORECASE)
        if returning_match:
            returning_col = returning_match.group(1)
            sql = re.sub(r'\s+RETURNING\s+\w+', '', sql, flags=re.IGNORECASE)

        cursor = self._conn.execute(sql, args)

        if returning_col:
            self._conn.commit()
            return [DictRow({returning_col: cursor.lastrowid})]

        if cursor.description:
            columns = [d[0] for d in cursor.description]
            return [DictRow(zip(columns, row)) for row in cursor.fetchall()]

        self._auto_commit()
        return []

    async def fetchrow(self, sql: str, *args) -> Optional[DictRow]:
        """Execute query, return first row or None."""
        rows = await self.fetch(sql, *args)
        return rows[0] if rows else None

    async def fetchval(self, sql: str, *args) -> Any:
        """Execute query, return first column of first row."""
        sql, args = _adapt_params(sql, args)

        # Handle RETURNING for fetchval too
        returning_match = re.search(r'\bRETURNING\s+(\w+)', sql, re.IGNORECASE)
        if returning_match:
            sql = re.sub(r'\s+RETURNING\s+\w+', '', sql, flags=re.IGNORECASE)
            cursor = self._conn.execute(sql, args)
            self._conn.commit()
            return cursor.lastrowid

        cursor = self._conn.execute(sql, args)
        row = cursor.fetchone()
        if cursor.description is None:
            self._conn.commit()
        return row[0] if row else None

    async def execute(self, sql: str, *args) -> str:
        """Execute statement (INSERT/UPDATE/DELETE). Returns status string."""
        sql, args = _adapt_params(sql, args)

        # Strip RETURNING (execute doesn't return rows)
        sql = re.sub(r'\s+RETURNING\s+\w+', '', sql, flags=re.IGNORECASE)

        cursor = self._conn.execute(sql, args)
        self._auto_commit()
        return f"OK ({cursor.rowcount} rows)"

    def acquire(self):
        """Context manager: `async with pool.acquire() as conn:`"""
        return _FakeAcquire(self)

    def transaction(self):
        """Context manager: `async with conn.transaction():`"""
        return _FakeTransaction(self)


class _FakeAcquire:
    """Mimics `async with pool.acquire() as conn:`"""
    def __init__(self, db):
        self._db = db
    async def __aenter__(self):
        return self._db
    async def __aexit__(self, *args):
        pass


class _FakeTransaction:
    """Mimics `async with conn.transaction():`"""
    def __init__(self, db):
        self._db = db
        self._conn = db._conn
    async def __aenter__(self):
        self._conn.execute("BEGIN")
        self._db._in_transaction = True
        return self
    async def __aexit__(self, exc_type, *args):
        self._db._in_transaction = False
        if exc_type:
            self._conn.execute("ROLLBACK")
        else:
            self._conn.execute("COMMIT")


# ── Singleton ────────────────────────────────────────

_db: Optional[Database] = None


def get_db() -> Database:
    """Get or create the Database singleton."""
    global _db
    if _db is None:
        _db = Database()
        _db.connect()
    return _db


async def get_pool() -> Database:
    """Alias for asyncpg compatibility.
    Routers call `pool = await get_pool()` — this returns our Database."""
    return get_db()
