"""
DAP Schema — All 23 tables, indexes, and seed data.
Translated from PostgreSQL to SQLite.
Safe to call init_db() multiple times (uses IF NOT EXISTS / INSERT OR IGNORE).
"""

import json
import logging
from .database import Database

logger = logging.getLogger("dap.schema")

# ═══════════════════════════════════════════════════════════════════
#  TABLE DEFINITIONS (23 tables)
# ═══════════════════════════════════════════════════════════════════

_TABLES = [
    # ── GROUP A: GRC Core (9 tables) ──────────────────────────────

    # A1: grc_org_units
    """CREATE TABLE IF NOT EXISTS grc_org_units (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        name            TEXT NOT NULL,
        code            TEXT UNIQUE,
        parent_id       INTEGER REFERENCES grc_org_units(id) ON DELETE SET NULL,
        unit_type       TEXT NOT NULL DEFAULT 'department'
                            CHECK (unit_type IN ('department','division','unit','team')),
        head_user_id    TEXT,
        deputy_user_id  TEXT,
        description     TEXT,
        is_audit_unit   INTEGER DEFAULT 0,
        created_at      TEXT DEFAULT (datetime('now')),
        updated_at      TEXT DEFAULT (datetime('now'))
    )""",

    # A2: grc_audit_plans
    """CREATE TABLE IF NOT EXISTS grc_audit_plans (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        year            INTEGER NOT NULL,
        title           TEXT NOT NULL,
        description     TEXT,
        status          TEXT NOT NULL DEFAULT 'draft'
                            CHECK (status IN ('draft','under_review','approved','active','completed','archived')),
        approved_by     TEXT,
        approved_at     TEXT,
        metadata        TEXT DEFAULT '{}',
        created_by      TEXT NOT NULL,
        created_at      TEXT DEFAULT (datetime('now')),
        updated_at      TEXT DEFAULT (datetime('now'))
    )""",

    # A3: grc_engagements
    """CREATE TABLE IF NOT EXISTS grc_engagements (
        id                  INTEGER PRIMARY KEY AUTOINCREMENT,
        plan_id             INTEGER NOT NULL REFERENCES grc_audit_plans(id) ON DELETE CASCADE,
        title               TEXT NOT NULL,
        description         TEXT,
        engagement_type     TEXT DEFAULT 'planned'
                                CHECK (engagement_type IN ('planned','unplanned','follow_up')),
        status              TEXT NOT NULL DEFAULT 'planned'
                                CHECK (status IN ('planned','in_progress','fieldwork','review','findings_issued','remediation','closed')),
        audit_unit_id       INTEGER REFERENCES grc_org_units(id),
        target_unit_id      INTEGER REFERENCES grc_org_units(id),
        lead_auditor_id     TEXT,
        planned_start       TEXT,
        planned_end         TEXT,
        actual_start        TEXT,
        actual_end          TEXT,
        risk_level          TEXT DEFAULT 'medium'
                                CHECK (risk_level IN ('critical','high','medium','low')),
        metadata            TEXT DEFAULT '{}',
        created_by          TEXT NOT NULL,
        created_at          TEXT DEFAULT (datetime('now')),
        updated_at          TEXT DEFAULT (datetime('now'))
    )""",

    # A4: grc_engagement_members
    """CREATE TABLE IF NOT EXISTS grc_engagement_members (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        engagement_id   INTEGER NOT NULL REFERENCES grc_engagements(id) ON DELETE CASCADE,
        user_id         TEXT NOT NULL,
        member_role     TEXT DEFAULT 'auditor'
                            CHECK (member_role IN ('lead','auditor','reviewer','observer')),
        assigned_at     TEXT DEFAULT (datetime('now')),
        UNIQUE(engagement_id, user_id)
    )""",

    # A5: grc_findings
    """CREATE TABLE IF NOT EXISTS grc_findings (
        id                  INTEGER PRIMARY KEY AUTOINCREMENT,
        engagement_id       INTEGER NOT NULL REFERENCES grc_engagements(id) ON DELETE CASCADE,
        ref_number          TEXT,
        title               TEXT NOT NULL,
        description         TEXT,
        severity            TEXT NOT NULL DEFAULT 'medium'
                                CHECK (severity IN ('critical','high','medium','low')),
        status              TEXT NOT NULL DEFAULT 'draft'
                                CHECK (status IN ('draft','confirmed','remediation_issued','resolved','closed')),
        found_by            TEXT NOT NULL,
        responsible_unit_id INTEGER REFERENCES grc_org_units(id),
        evidence            TEXT,
        recommendation      TEXT,
        metadata            TEXT DEFAULT '{}',
        created_at          TEXT DEFAULT (datetime('now')),
        updated_at          TEXT DEFAULT (datetime('now'))
    )""",

    # A6: grc_remediation_tasks
    """CREATE TABLE IF NOT EXISTS grc_remediation_tasks (
        id                      INTEGER PRIMARY KEY AUTOINCREMENT,
        finding_id              INTEGER NOT NULL REFERENCES grc_findings(id) ON DELETE CASCADE,
        ref_number              TEXT,
        title                   TEXT NOT NULL,
        description             TEXT,
        status                  TEXT NOT NULL DEFAULT 'assigned'
                                    CHECK (status IN ('assigned','in_progress','submitted','verified','closed','cancelled')),
        assigned_to_user_id     TEXT,
        assigned_to_unit_id     INTEGER REFERENCES grc_org_units(id),
        deadline                TEXT NOT NULL,
        is_overdue              INTEGER DEFAULT 0,
        escalation_enabled      INTEGER DEFAULT 1,
        escalation_muted_until  TEXT,
        submitted_at            TEXT,
        submitted_evidence      TEXT,
        verified_by             TEXT,
        verified_at             TEXT,
        closed_at               TEXT,
        metadata                TEXT DEFAULT '{}',
        created_by              TEXT NOT NULL,
        created_at              TEXT DEFAULT (datetime('now')),
        updated_at              TEXT DEFAULT (datetime('now'))
    )""",

    # A7: grc_comments
    """CREATE TABLE IF NOT EXISTS grc_comments (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        entity_type     TEXT NOT NULL
                            CHECK (entity_type IN ('plan','engagement','finding','remediation')),
        entity_id       INTEGER NOT NULL,
        author_id       TEXT NOT NULL,
        author_name     TEXT,
        body            TEXT NOT NULL,
        created_at      TEXT DEFAULT (datetime('now'))
    )""",

    # A8: grc_notifications
    """CREATE TABLE IF NOT EXISTS grc_notifications (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id         TEXT NOT NULL,
        notif_type      TEXT NOT NULL,
        title           TEXT NOT NULL,
        message         TEXT,
        entity_type     TEXT,
        entity_id       INTEGER,
        is_read         INTEGER DEFAULT 0,
        created_at      TEXT DEFAULT (datetime('now'))
    )""",

    # A9: grc_activity_log
    """CREATE TABLE IF NOT EXISTS grc_activity_log (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        entity_type     TEXT NOT NULL,
        entity_id       INTEGER NOT NULL,
        action          TEXT NOT NULL,
        actor_id        TEXT NOT NULL,
        actor_name      TEXT,
        old_value       TEXT,
        new_value       TEXT,
        details         TEXT,
        created_at      TEXT DEFAULT (datetime('now'))
    )""",

    # ── GROUP B: GRC Config (2 tables) ────────────────────────────

    # B1: grc_workflow_configs
    """CREATE TABLE IF NOT EXISTS grc_workflow_configs (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        config_type TEXT NOT NULL,
        config_key  TEXT NOT NULL,
        config      TEXT NOT NULL,
        version     INTEGER DEFAULT 1,
        is_active   INTEGER DEFAULT 1,
        updated_by  TEXT,
        updated_at  TEXT DEFAULT (datetime('now')),
        UNIQUE(config_type, config_key, is_active)
    )""",

    # B2: grc_enum_definitions
    """CREATE TABLE IF NOT EXISTS grc_enum_definitions (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        category    TEXT NOT NULL,
        key         TEXT NOT NULL,
        label       TEXT NOT NULL,
        sort_order  INTEGER DEFAULT 0,
        metadata    TEXT DEFAULT '{}',
        is_active   INTEGER DEFAULT 1,
        UNIQUE(category, key)
    )""",

    # ── GROUP C: GRC Attachments (1 table) ────────────────────────

    # C1: grc_attachments
    
    """CREATE TABLE IF NOT EXISTS grc_attachments (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        entity_type     TEXT NOT NULL,
        entity_id       INTEGER NOT NULL,
        filename        TEXT NOT NULL,
        original_name   TEXT NOT NULL,
        file_size       INTEGER DEFAULT 0,
        mime_type       TEXT DEFAULT 'application/octet-stream',
        category        TEXT DEFAULT 'general',
        description     TEXT,
        uploaded_by     TEXT NOT NULL,
        uploaded_at     TEXT DEFAULT (datetime('now'))
    )""",

    # ── GROUP D: Audit Universe (4 tables) ────────────────────────

    # D1: grc_audit_objects
    """CREATE TABLE IF NOT EXISTS grc_audit_objects (
        id                   INTEGER PRIMARY KEY AUTOINCREMENT,
        name                 TEXT NOT NULL,
        description          TEXT,
        category             TEXT NOT NULL DEFAULT 'business_process',
        owner_unit_id        INTEGER REFERENCES grc_org_units(id),
        status               TEXT NOT NULL DEFAULT 'active',
        audit_frequency      TEXT DEFAULT 'biennial',
        last_audit_date      TEXT,
        last_audit_result    TEXT,
        composite_score      REAL DEFAULT 0,
        risk_level           TEXT DEFAULT 'medium',
        metadata             TEXT DEFAULT '{}',
        created_by           TEXT NOT NULL,
        created_at           TEXT DEFAULT (datetime('now')),
        updated_at           TEXT DEFAULT (datetime('now')),
        risk_flags           TEXT DEFAULT '{}',
        regulatory_required  INTEGER DEFAULT 0,
        kar_request          INTEGER DEFAULT 0,
        other_factors        INTEGER DEFAULT 0,
        conclusion           TEXT,
        audit_division       TEXT,
        process_composite    REAL DEFAULT 0,
        svk_composite        REAL DEFAULT 0,
        importance_composite REAL DEFAULT 0,
        residual_risk        INTEGER DEFAULT 1
    )""",

    # D2: grc_risk_scores
    """CREATE TABLE IF NOT EXISTS grc_risk_scores (
        id               INTEGER PRIMARY KEY AUTOINCREMENT,
        audit_object_id  INTEGER NOT NULL REFERENCES grc_audit_objects(id) ON DELETE CASCADE,
        dimension        TEXT NOT NULL,
        score            INTEGER DEFAULT 1 CHECK (score BETWEEN 1 AND 3),
        comment          TEXT DEFAULT '',
        updated_by       TEXT,
        updated_at       TEXT DEFAULT (datetime('now')),
        UNIQUE(audit_object_id, dimension)
    )""",

    # D3: grc_strategic_plans
    """CREATE TABLE IF NOT EXISTS grc_strategic_plans (
        id               INTEGER PRIMARY KEY AUTOINCREMENT,
        title            TEXT NOT NULL,
        period_start     INTEGER NOT NULL,
        period_end       INTEGER NOT NULL,
        description      TEXT,
        status           TEXT DEFAULT 'draft',
        approved_by      TEXT,
        approved_at      TEXT,
        created_by       TEXT NOT NULL,
        created_at       TEXT DEFAULT (datetime('now')),
        updated_at       TEXT DEFAULT (datetime('now'))
    )""",

    # D4: grc_strategic_plan_items
    """CREATE TABLE IF NOT EXISTS grc_strategic_plan_items (
        id                 INTEGER PRIMARY KEY AUTOINCREMENT,
        strategic_plan_id  INTEGER NOT NULL REFERENCES grc_strategic_plans(id) ON DELETE CASCADE,
        audit_object_id    INTEGER NOT NULL REFERENCES grc_audit_objects(id) ON DELETE CASCADE,
        planned_year       INTEGER NOT NULL,
        quarter            TEXT,
        priority           TEXT DEFAULT 'medium',
        notes              TEXT,
        linked_plan_id     INTEGER,
        created_at         TEXT DEFAULT (datetime('now')),
        UNIQUE(strategic_plan_id, audit_object_id, planned_year)
    )""",

    # ── GROUP E: BI Module (5 tables) ─────────────────────────────

    # E1: bi_datasources
    """CREATE TABLE IF NOT EXISTS bi_datasources (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        name            TEXT NOT NULL,
        engine          TEXT NOT NULL,
        host            TEXT,
        port            INTEGER,
        database_name   TEXT,
        username        TEXT,
        password_enc    TEXT,
        extra_params    TEXT DEFAULT '{}',
        created_by      TEXT NOT NULL,
        created_at      TEXT DEFAULT (datetime('now')),
        updated_at      TEXT DEFAULT (datetime('now'))
    )""",

    # E2: bi_saved_queries
    """CREATE TABLE IF NOT EXISTS bi_saved_queries (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        title           TEXT NOT NULL,
        description     TEXT,
        datasource_id   INTEGER REFERENCES bi_datasources(id) ON DELETE SET NULL,
        sql_text        TEXT NOT NULL,
        created_by      TEXT NOT NULL,
        is_public       INTEGER DEFAULT 0,
        created_at      TEXT DEFAULT (datetime('now')),
        updated_at      TEXT DEFAULT (datetime('now'))
    )""",

    # E3: bi_charts
    """CREATE TABLE IF NOT EXISTS bi_charts (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        title           TEXT NOT NULL,
        description     TEXT,
        datasource_id   INTEGER REFERENCES bi_datasources(id) ON DELETE SET NULL,
        sql_text        TEXT NOT NULL,
        chart_type      TEXT NOT NULL,
        chart_config    TEXT DEFAULT '{}',
        created_by      TEXT NOT NULL,
        is_public       INTEGER DEFAULT 0,
        created_at      TEXT DEFAULT (datetime('now')),
        updated_at      TEXT DEFAULT (datetime('now'))
    )""",

    # E4: bi_dashboards
    """CREATE TABLE IF NOT EXISTS bi_dashboards (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        title           TEXT NOT NULL,
        description     TEXT,
        created_by      TEXT NOT NULL,
        published       INTEGER DEFAULT 0,
        created_at      TEXT DEFAULT (datetime('now')),
        updated_at      TEXT DEFAULT (datetime('now'))
    )""",

    # E5: bi_dashboard_charts
    """CREATE TABLE IF NOT EXISTS bi_dashboard_charts (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        dashboard_id    INTEGER NOT NULL REFERENCES bi_dashboards(id) ON DELETE CASCADE,
        chart_id        INTEGER NOT NULL REFERENCES bi_charts(id) ON DELETE CASCADE,
        pos_x           INTEGER DEFAULT 0,
        pos_y           INTEGER DEFAULT 0,
        width           INTEGER DEFAULT 6,
        height          INTEGER DEFAULT 4,
        UNIQUE(dashboard_id, chart_id)
    )""",

    # ── GROUP F: My Reports (1 table) ─────────────────────────────

    # F1: config_user_reports
    """CREATE TABLE IF NOT EXISTS config_user_reports (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id     TEXT NOT NULL,
        title       TEXT NOT NULL,
        url         TEXT NOT NULL,
        description TEXT,
        icon        TEXT DEFAULT 'file-text',
        position    INTEGER DEFAULT 0,
        created_at  TEXT DEFAULT (datetime('now')),
        updated_at  TEXT DEFAULT (datetime('now'))
    )""",

    # ── GROUP G: System Logs (1 table) ────────────────────────────

    # G1: audit_system_logs (already in SQLite format)
    """CREATE TABLE IF NOT EXISTS audit_system_logs (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        service         TEXT,
        level           TEXT,
        message         TEXT,
        metadata        TEXT DEFAULT '{}',
        created_at      TEXT DEFAULT (datetime('now'))
    )""",
]

# ═══════════════════════════════════════════════════════════════════
#  INDEXES
# ═══════════════════════════════════════════════════════════════════

_INDEXES = [
    # Group A indexes
    "CREATE INDEX IF NOT EXISTS idx_grc_org_parent ON grc_org_units(parent_id)",
    "CREATE INDEX IF NOT EXISTS idx_grc_plans_year ON grc_audit_plans(year)",
    "CREATE INDEX IF NOT EXISTS idx_grc_plans_status ON grc_audit_plans(status)",
    "CREATE INDEX IF NOT EXISTS idx_grc_eng_plan ON grc_engagements(plan_id)",
    "CREATE INDEX IF NOT EXISTS idx_grc_eng_status ON grc_engagements(status)",
    "CREATE INDEX IF NOT EXISTS idx_grc_eng_lead ON grc_engagements(lead_auditor_id)",
    "CREATE INDEX IF NOT EXISTS idx_grc_members_user ON grc_engagement_members(user_id)",
    "CREATE INDEX IF NOT EXISTS idx_grc_find_eng ON grc_findings(engagement_id)",
    "CREATE INDEX IF NOT EXISTS idx_grc_find_status ON grc_findings(status)",
    "CREATE INDEX IF NOT EXISTS idx_grc_rem_finding ON grc_remediation_tasks(finding_id)",
    "CREATE INDEX IF NOT EXISTS idx_grc_rem_status ON grc_remediation_tasks(status)",
    "CREATE INDEX IF NOT EXISTS idx_grc_rem_deadline ON grc_remediation_tasks(deadline)",
    "CREATE INDEX IF NOT EXISTS idx_grc_rem_assignee ON grc_remediation_tasks(assigned_to_user_id)",
    "CREATE INDEX IF NOT EXISTS idx_grc_comments_entity ON grc_comments(entity_type, entity_id)",
    "CREATE INDEX IF NOT EXISTS idx_grc_notif_user ON grc_notifications(user_id, is_read)",
    "CREATE INDEX IF NOT EXISTS idx_grc_notif_created ON grc_notifications(created_at)",
    "CREATE INDEX IF NOT EXISTS idx_grc_activity_entity ON grc_activity_log(entity_type, entity_id)",
    "CREATE INDEX IF NOT EXISTS idx_grc_activity_actor ON grc_activity_log(actor_id)",
    "CREATE INDEX IF NOT EXISTS idx_grc_activity_created ON grc_activity_log(created_at)",
    # Group C index
    "CREATE INDEX IF NOT EXISTS idx_grc_attach_entity ON grc_attachments(entity_type, entity_id)",
    # Group F index
    "CREATE INDEX IF NOT EXISTS idx_user_reports_user ON config_user_reports(user_id)",
]

# ═══════════════════════════════════════════════════════════════════
#  SEED DATA
# ═══════════════════════════════════════════════════════════════════

# ── Seed 1: Org units ─────────────────────────────────────────────
# Audit departments (DVA → UAOB → OARR hierarchy) + business departments

_SEED_ORG_UNITS = [
    # Audit departments (is_audit_unit = 1)
    """INSERT OR IGNORE INTO grc_org_units (name, code, parent_id, unit_type, is_audit_unit, description)
       VALUES ('Департамент внутреннего аудита', 'DVA', NULL, 'department', 1,
               'Головной департамент внутреннего аудита')""",

    """INSERT OR IGNORE INTO grc_org_units (name, code, parent_id, unit_type, is_audit_unit, description)
       VALUES ('Управление аудита операционного бизнеса', 'UAOB',
               (SELECT id FROM grc_org_units WHERE code = 'DVA'), 'division', 1,
               'Управление аудита операционного бизнеса')""",

    """INSERT OR IGNORE INTO grc_org_units (name, code, parent_id, unit_type, is_audit_unit, description)
       VALUES ('Отдел аудита рисков и регуляторики', 'OARR',
               (SELECT id FROM grc_org_units WHERE code = 'UAOB'), 'unit', 1,
               'Отдел аудита рисков и регуляторики')""",

    # Original business departments (from grc-init.sql)
    """INSERT OR IGNORE INTO grc_org_units (name, code, unit_type, description)
       VALUES ('Департамент финансового мониторинга', 'DFM', 'department',
               'Финансовый мониторинг и комплаенс')""",

    """INSERT OR IGNORE INTO grc_org_units (name, code, unit_type, description)
       VALUES ('Департамент розничного бизнеса', 'DRB', 'department',
               'Розничный бизнес и обслуживание')""",

    """INSERT OR IGNORE INTO grc_org_units (name, code, unit_type, description)
       VALUES ('Департамент информационных технологий', 'DIT', 'department',
               'ИТ-инфраструктура и разработка')""",

    """INSERT OR IGNORE INTO grc_org_units (name, code, unit_type, description)
       VALUES ('Департамент операционных рисков', 'DOR', 'department',
               'Управление операционными рисками')""",

    # Additional business departments (from 008_audit_universe_v2.sql)
    """INSERT OR IGNORE INTO grc_org_units (name, code, unit_type, description)
       VALUES ('Инвестиционный департамент', 'inv_dep', 'department',
               'Управление инвестициями')""",

    """INSERT OR IGNORE INTO grc_org_units (name, code, unit_type, description)
       VALUES ('Кредитный департамент', 'cred_dep', 'department',
               'Кредитование юридических и физических лиц')""",

    """INSERT OR IGNORE INTO grc_org_units (name, code, unit_type, description)
       VALUES ('Департамент банковских рисков', 'bank_risks', 'department',
               'Управление банковскими рисками')""",

    """INSERT OR IGNORE INTO grc_org_units (name, code, unit_type, description)
       VALUES ('Операционный департамент', 'oper_dep', 'department',
               'Операционная деятельность')""",

    """INSERT OR IGNORE INTO grc_org_units (name, code, unit_type, description)
       VALUES ('Казначейство', 'treasury', 'department',
               'Управление ликвидностью и казначейские операции')""",

    """INSERT OR IGNORE INTO grc_org_units (name, code, unit_type, description)
       VALUES ('Департамент ипотечного кредитования', 'mortgage', 'department',
               'Ипотечное кредитование')""",

    """INSERT OR IGNORE INTO grc_org_units (name, code, unit_type, description)
       VALUES ('Департамент по работе с задолженностью', 'debt_dep', 'department',
               'Работа с просроченной задолженностью')""",

    """INSERT OR IGNORE INTO grc_org_units (name, code, unit_type, description)
       VALUES ('Департамент транзакционного развития', 'trans_dev', 'department',
               'Транзакционное развитие и продукты')""",

    """INSERT OR IGNORE INTO grc_org_units (name, code, unit_type, description)
       VALUES ('Департамент структурных продуктов', 'struct_dep', 'department',
               'Структурные и сложные продукты')""",

    """INSERT OR IGNORE INTO grc_org_units (name, code, unit_type, description)
       VALUES ('Департамент корпоративного обслуживания', 'corp_support', 'department',
               'Корпоративное обслуживание')""",

    """INSERT OR IGNORE INTO grc_org_units (name, code, unit_type, description)
       VALUES ('Департамент транзакционных продуктов', 'trans_prod', 'department',
               'Транзакционные продукты и сервисы')""",

    """INSERT OR IGNORE INTO grc_org_units (name, code, unit_type, description)
       VALUES ('Дирекция по рискам', 'risk_dir', 'department',
               'Общее управление рисками')""",

    """INSERT OR IGNORE INTO grc_org_units (name, code, unit_type, description)
       VALUES ('Финансовый департамент', 'fin_dep', 'department',
               'Финансовое планирование и учёт')""",
]

# ── Seed 2: Workflow configs ──────────────────────────────────────

_WORKFLOW_TRANSITIONS_PLAN = {
    "draft":        {"allowed": ["under_review"],            "label": "Черновик"},
    "under_review": {"allowed": ["approved", "draft"],       "label": "На рассмотрении"},
    "approved":     {"allowed": ["active"],                  "label": "Утверждён"},
    "active":       {"allowed": ["completed"],               "label": "Активный"},
    "completed":    {"allowed": ["archived"],                "label": "Завершён"},
    "archived":     {"allowed": [],                          "label": "Архив"},
}

_WORKFLOW_TRANSITIONS_ENGAGEMENT = {
    "planned":          {"allowed": ["in_progress"],                               "label": "Запланировано"},
    "in_progress":      {"allowed": ["fieldwork", "closed"],                       "label": "В работе"},
    "fieldwork":        {"allowed": ["review", "in_progress"],                     "label": "Полевой этап"},
    "review":           {"allowed": ["findings_issued", "fieldwork"],              "label": "Проверка"},
    "findings_issued":  {"allowed": ["remediation", "closed"],                     "label": "Выявлены замечания"},
    "remediation":      {"allowed": ["closed"],                                    "label": "Устранение"},
    "closed":           {"allowed": [],                                            "label": "Закрыто"},
}

_WORKFLOW_TRANSITIONS_FINDING = {
    "draft":              {"allowed": ["confirmed"],                               "label": "Черновик"},
    "confirmed":          {"allowed": ["remediation_issued", "closed"],            "label": "Подтверждено"},
    "remediation_issued": {"allowed": ["resolved"],                                "label": "Выдано на устранение"},
    "resolved":           {"allowed": ["closed", "confirmed"],                     "label": "Устранено"},
    "closed":             {"allowed": [],                                          "label": "Закрыто"},
}

_WORKFLOW_TRANSITIONS_REMEDIATION = {
    "assigned":    {"allowed": ["in_progress", "cancelled"],                       "label": "Назначено"},
    "in_progress": {"allowed": ["submitted", "cancelled"],                         "label": "В работе"},
    "submitted":   {"allowed": ["verified", "in_progress"],                        "label": "Представлено"},
    "verified":    {"allowed": ["closed"],                                         "label": "Проверено"},
    "closed":      {"allowed": [],                                                 "label": "Закрыто"},
    "cancelled":   {"allowed": [],                                                 "label": "Отменено"},
}

_WORKFLOW_TRANSITION_ROLES = {
    "plan": {
        "draft→under_review":  ["DAP_Managers", "DAP_Admins"],
        "under_review→approved": ["DAP_Admins"],
        "under_review→draft":  ["DAP_Managers", "DAP_Admins"],
        "approved→active":     ["DAP_Admins"],
        "active→completed":    ["DAP_Managers", "DAP_Admins"],
        "completed→archived":  ["DAP_Admins"],
    },
    "engagement": {
        "planned→in_progress":       ["DAP_Auditors", "DAP_Managers", "DAP_Admins"],
        "in_progress→fieldwork":     ["DAP_Auditors", "DAP_Managers", "DAP_Admins"],
        "fieldwork→review":          ["DAP_Auditors", "DAP_Managers", "DAP_Admins"],
        "review→findings_issued":    ["DAP_Managers", "DAP_Admins"],
        "findings_issued→remediation": ["DAP_Managers", "DAP_Admins"],
        "remediation→closed":        ["DAP_Managers", "DAP_Admins"],
    },
    "finding": {
        "draft→confirmed":             ["DAP_Auditors", "DAP_Managers", "DAP_Admins"],
        "confirmed→remediation_issued": ["DAP_Managers", "DAP_Admins"],
        "remediation_issued→resolved":  ["DAP_Auditors", "DAP_Managers", "DAP_Admins"],
        "resolved→closed":             ["DAP_Managers", "DAP_Admins"],
        "resolved→confirmed":          ["DAP_Managers", "DAP_Admins"],
    },
    "remediation": {
        "assigned→in_progress":  ["DAP_Auditors", "DAP_Managers", "DAP_Admins", "DAP_Viewers"],
        "in_progress→submitted": ["DAP_Auditors", "DAP_Managers", "DAP_Admins", "DAP_Viewers"],
        "submitted→verified":    ["DAP_Auditors", "DAP_Managers", "DAP_Admins"],
        "submitted→in_progress": ["DAP_Managers", "DAP_Admins"],
        "verified→closed":       ["DAP_Managers", "DAP_Admins"],
    },
}

_ESCALATION_DEADLINES = {
    "warning_days_before": 7,
    "overdue_check_interval_hours": 24,
    "escalation_levels": [
        {"days_overdue": 0,  "notify": ["assignee"],             "label": "Срок истёк"},
        {"days_overdue": 7,  "notify": ["assignee", "manager"],  "label": "Просрочено 7 дней"},
        {"days_overdue": 30, "notify": ["assignee", "manager", "admin"], "label": "Просрочено 30 дней"},
    ],
}

_RISK_SCORING_WEIGHTS = {
    "dimensions": {
        "process_risk":      {"label": "Риск процесса",      "weight": 0.20, "group": "process"},
        "control_maturity":  {"label": "Зрелость контролей",  "weight": 0.15, "group": "process"},
        "it_dependency":     {"label": "ИТ-зависимость",      "weight": 0.10, "group": "process"},
        "regulatory_impact": {"label": "Регуляторное влияние", "weight": 0.15, "group": "svk"},
        "fraud_risk":        {"label": "Риск мошенничества",   "weight": 0.10, "group": "svk"},
        "financial_impact":  {"label": "Финансовое влияние",   "weight": 0.10, "group": "svk"},
        "strategic_value":   {"label": "Стратегическая ценность", "weight": 0.05, "group": "importance"},
        "management_concern":{"label": "Внимание руководства", "weight": 0.05, "group": "importance"},
        "change_intensity":  {"label": "Интенсивность изменений","weight": 0.10, "group": "importance"},
    },
    "scale": {"min": 1, "max": 3},
    "risk_levels": {
        "high":   {"min_score": 2.1, "label": "Высокий",  "color": "#dc2626"},
        "medium": {"min_score": 1.5, "label": "Средний",  "color": "#f59e0b"},
        "low":    {"min_score": 0.0, "label": "Низкий",   "color": "#22c55e"},
    },
}

_SEED_WORKFLOW_CONFIGS = [
    f"""INSERT OR IGNORE INTO grc_workflow_configs (config_type, config_key, config, updated_by)
        VALUES ('transitions', 'plan', '{json.dumps(_WORKFLOW_TRANSITIONS_PLAN, ensure_ascii=False)}', 'system')""",

    f"""INSERT OR IGNORE INTO grc_workflow_configs (config_type, config_key, config, updated_by)
        VALUES ('transitions', 'engagement', '{json.dumps(_WORKFLOW_TRANSITIONS_ENGAGEMENT, ensure_ascii=False)}', 'system')""",

    f"""INSERT OR IGNORE INTO grc_workflow_configs (config_type, config_key, config, updated_by)
        VALUES ('transitions', 'finding', '{json.dumps(_WORKFLOW_TRANSITIONS_FINDING, ensure_ascii=False)}', 'system')""",

    f"""INSERT OR IGNORE INTO grc_workflow_configs (config_type, config_key, config, updated_by)
        VALUES ('transitions', 'remediation', '{json.dumps(_WORKFLOW_TRANSITIONS_REMEDIATION, ensure_ascii=False)}', 'system')""",

    f"""INSERT OR IGNORE INTO grc_workflow_configs (config_type, config_key, config, updated_by)
        VALUES ('transition_roles', 'global', '{json.dumps(_WORKFLOW_TRANSITION_ROLES, ensure_ascii=False)}', 'system')""",

    f"""INSERT OR IGNORE INTO grc_workflow_configs (config_type, config_key, config, updated_by)
        VALUES ('escalation', 'deadlines', '{json.dumps(_ESCALATION_DEADLINES, ensure_ascii=False)}', 'system')""",

    f"""INSERT OR IGNORE INTO grc_workflow_configs (config_type, config_key, config, updated_by)
        VALUES ('risk_scoring', 'weights', '{json.dumps(_RISK_SCORING_WEIGHTS, ensure_ascii=False)}', 'system')""",
]

# ── Seed 3: Enum definitions ─────────────────────────────────────

_SEED_ENUMS = [
    # Plan statuses
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('plan_status', 'draft', 'Черновик', 1)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('plan_status', 'under_review', 'На рассмотрении', 2)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('plan_status', 'approved', 'Утверждён', 3)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('plan_status', 'active', 'Активный', 4)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('plan_status', 'completed', 'Завершён', 5)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('plan_status', 'archived', 'Архив', 6)",

    # Engagement statuses
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('engagement_status', 'planned', 'Запланировано', 1)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('engagement_status', 'in_progress', 'В работе', 2)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('engagement_status', 'fieldwork', 'Полевой этап', 3)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('engagement_status', 'review', 'Проверка', 4)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('engagement_status', 'findings_issued', 'Выявлены замечания', 5)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('engagement_status', 'remediation', 'Устранение', 6)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('engagement_status', 'closed', 'Закрыто', 7)",

    # Finding statuses
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('finding_status', 'draft', 'Черновик', 1)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('finding_status', 'confirmed', 'Подтверждено', 2)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('finding_status', 'remediation_issued', 'Выдано на устранение', 3)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('finding_status', 'resolved', 'Устранено', 4)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('finding_status', 'closed', 'Закрыто', 5)",

    # Remediation statuses
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('remediation_status', 'assigned', 'Назначено', 1)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('remediation_status', 'in_progress', 'В работе', 2)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('remediation_status', 'submitted', 'Представлено', 3)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('remediation_status', 'verified', 'Проверено', 4)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('remediation_status', 'closed', 'Закрыто', 5)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('remediation_status', 'cancelled', 'Отменено', 6)",

    # Severity levels
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order, metadata) VALUES ('severity', 'critical', 'Критический', 1, '{\"color\": \"#dc2626\", \"icon\": \"alert-triangle\"}')",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order, metadata) VALUES ('severity', 'high', 'Высокий', 2, '{\"color\": \"#ea580c\", \"icon\": \"alert-circle\"}')",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order, metadata) VALUES ('severity', 'medium', 'Средний', 3, '{\"color\": \"#f59e0b\", \"icon\": \"info\"}')",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order, metadata) VALUES ('severity', 'low', 'Низкий', 4, '{\"color\": \"#22c55e\", \"icon\": \"check-circle\"}')",

    # Risk levels
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order, metadata) VALUES ('risk_level', 'critical', 'Критический', 1, '{\"color\": \"#dc2626\"}')",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order, metadata) VALUES ('risk_level', 'high', 'Высокий', 2, '{\"color\": \"#ea580c\"}')",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order, metadata) VALUES ('risk_level', 'medium', 'Средний', 3, '{\"color\": \"#f59e0b\"}')",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order, metadata) VALUES ('risk_level', 'low', 'Низкий', 4, '{\"color\": \"#22c55e\"}')",

    # Engagement types
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('engagement_type', 'planned', 'Плановая', 1)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('engagement_type', 'unplanned', 'Внеплановая', 2)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('engagement_type', 'follow_up', 'Контрольная', 3)",

    # Member roles
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('member_role', 'lead', 'Руководитель проверки', 1)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('member_role', 'auditor', 'Аудитор', 2)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('member_role', 'reviewer', 'Рецензент', 3)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('member_role', 'observer', 'Наблюдатель', 4)",

    # Notification types
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('notification_type', 'status_change', 'Изменение статуса', 1)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('notification_type', 'assignment', 'Назначение', 2)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('notification_type', 'comment', 'Комментарий', 3)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('notification_type', 'deadline_warning', 'Предупреждение о сроке', 4)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('notification_type', 'escalation', 'Эскалация', 5)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('notification_type', 'overdue', 'Просрочено', 6)",

    # Attachment categories
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('attachment_category', 'general', 'Общий', 1)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('attachment_category', 'evidence', 'Доказательство', 2)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('attachment_category', 'report', 'Отчёт', 3)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('attachment_category', 'working_paper', 'Рабочий документ', 4)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('attachment_category', 'remediation_proof', 'Подтверждение устранения', 5)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('attachment_category', 'correspondence', 'Переписка', 6)",

    # Audit object categories
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('audit_object_category', 'business_process', 'Бизнес-процесс', 1)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('audit_object_category', 'it_system', 'ИТ-система', 2)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('audit_object_category', 'regulatory', 'Регуляторное требование', 3)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('audit_object_category', 'financial', 'Финансовый процесс', 4)",

    # Audit frequency
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('audit_frequency', 'annual', 'Ежегодно', 1)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('audit_frequency', 'biennial', 'Раз в 2 года', 2)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('audit_frequency', 'triennial', 'Раз в 3 года', 3)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('audit_frequency', 'as_needed', 'По необходимости', 4)",

    # Org unit types
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('unit_type', 'department', 'Департамент', 1)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('unit_type', 'division', 'Управление', 2)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('unit_type', 'unit', 'Отдел', 3)",
    "INSERT OR IGNORE INTO grc_enum_definitions (category, key, label, sort_order) VALUES ('unit_type', 'team', 'Группа', 4)",
]

# ── Seed 4: 30 Audit objects ─────────────────────────────────────
# Each uses (SELECT id FROM grc_org_units WHERE code = '...') for owner_unit_id

_SEED_AUDIT_OBJECTS = [
    # 1. Кредитование корпоративных клиентов
    """INSERT OR IGNORE INTO grc_audit_objects (name, description, category, owner_unit_id, audit_frequency, risk_level, created_by, audit_division, regulatory_required)
       VALUES ('Кредитование корпоративных клиентов', 'Процесс выдачи и сопровождения корпоративных кредитов', 'business_process',
               (SELECT id FROM grc_org_units WHERE code = 'cred_dep'), 'annual', 'high', 'system', 'UAOB', 1)""",

    # 2. Кредитование физических лиц
    """INSERT OR IGNORE INTO grc_audit_objects (name, description, category, owner_unit_id, audit_frequency, risk_level, created_by, audit_division, regulatory_required)
       VALUES ('Кредитование физических лиц', 'Розничное кредитование и потребительские займы', 'business_process',
               (SELECT id FROM grc_org_units WHERE code = 'cred_dep'), 'annual', 'high', 'system', 'UAOB', 1)""",

    # 3. Ипотечное кредитование
    """INSERT OR IGNORE INTO grc_audit_objects (name, description, category, owner_unit_id, audit_frequency, risk_level, created_by, audit_division, regulatory_required)
       VALUES ('Ипотечное кредитование', 'Процессы ипотечного кредитования и залогового обеспечения', 'business_process',
               (SELECT id FROM grc_org_units WHERE code = 'mortgage'), 'annual', 'high', 'system', 'UAOB', 1)""",

    # 4. Управление рыночными рисками
    """INSERT OR IGNORE INTO grc_audit_objects (name, description, category, owner_unit_id, audit_frequency, risk_level, created_by, audit_division, regulatory_required)
       VALUES ('Управление рыночными рисками', 'Мониторинг и контроль рыночных рисков', 'business_process',
               (SELECT id FROM grc_org_units WHERE code = 'bank_risks'), 'annual', 'high', 'system', 'OARR', 1)""",

    # 5. Управление операционными рисками
    """INSERT OR IGNORE INTO grc_audit_objects (name, description, category, owner_unit_id, audit_frequency, risk_level, created_by, audit_division, regulatory_required)
       VALUES ('Управление операционными рисками', 'Идентификация, оценка и мониторинг операционных рисков', 'business_process',
               (SELECT id FROM grc_org_units WHERE code = 'DOR'), 'annual', 'high', 'system', 'OARR', 1)""",

    # 6. ПОД/ФТ и комплаенс
    """INSERT OR IGNORE INTO grc_audit_objects (name, description, category, owner_unit_id, audit_frequency, risk_level, created_by, audit_division, regulatory_required)
       VALUES ('ПОД/ФТ и комплаенс', 'Противодействие отмыванию доходов и финансированию терроризма', 'regulatory',
               (SELECT id FROM grc_org_units WHERE code = 'DFM'), 'annual', 'critical', 'system', 'OARR', 1)""",

    # 7. Казначейские операции
    """INSERT OR IGNORE INTO grc_audit_objects (name, description, category, owner_unit_id, audit_frequency, risk_level, created_by, audit_division)
       VALUES ('Казначейские операции', 'Управление ликвидностью и межбанковские операции', 'business_process',
               (SELECT id FROM grc_org_units WHERE code = 'treasury'), 'annual', 'high', 'system', 'OARR')""",

    # 8. Операции с ценными бумагами
    """INSERT OR IGNORE INTO grc_audit_objects (name, description, category, owner_unit_id, audit_frequency, risk_level, created_by, audit_division)
       VALUES ('Операции с ценными бумагами', 'Инвестиционные операции и портфельное управление', 'business_process',
               (SELECT id FROM grc_org_units WHERE code = 'inv_dep'), 'biennial', 'medium', 'system', 'OARR')""",

    # 9. Расчётно-кассовое обслуживание
    """INSERT OR IGNORE INTO grc_audit_objects (name, description, category, owner_unit_id, audit_frequency, risk_level, created_by, audit_division)
       VALUES ('Расчётно-кассовое обслуживание', 'РКО юридических и физических лиц', 'business_process',
               (SELECT id FROM grc_org_units WHERE code = 'oper_dep'), 'biennial', 'medium', 'system', 'UAOB')""",

    # 10. Дистанционное банковское обслуживание
    """INSERT OR IGNORE INTO grc_audit_objects (name, description, category, owner_unit_id, audit_frequency, risk_level, created_by, audit_division)
       VALUES ('Дистанционное банковское обслуживание', 'Интернет-банк, мобильное приложение, API', 'it_system',
               (SELECT id FROM grc_org_units WHERE code = 'DIT'), 'annual', 'high', 'system', 'UAOB')""",

    # 11. Информационная безопасность
    """INSERT OR IGNORE INTO grc_audit_objects (name, description, category, owner_unit_id, audit_frequency, risk_level, created_by, audit_division, regulatory_required)
       VALUES ('Информационная безопасность', 'Защита информации и кибербезопасность', 'it_system',
               (SELECT id FROM grc_org_units WHERE code = 'DIT'), 'annual', 'critical', 'system', 'OARR', 1)""",

    # 12. ИТ-инфраструктура
    """INSERT OR IGNORE INTO grc_audit_objects (name, description, category, owner_unit_id, audit_frequency, risk_level, created_by, audit_division)
       VALUES ('ИТ-инфраструктура', 'Серверная инфраструктура, сети, системы хранения', 'it_system',
               (SELECT id FROM grc_org_units WHERE code = 'DIT'), 'biennial', 'medium', 'system', 'OARR')""",

    # 13. Разработка и сопровождение ПО
    """INSERT OR IGNORE INTO grc_audit_objects (name, description, category, owner_unit_id, audit_frequency, risk_level, created_by, audit_division)
       VALUES ('Разработка и сопровождение ПО', 'SDLC, DevOps, управление изменениями', 'it_system',
               (SELECT id FROM grc_org_units WHERE code = 'DIT'), 'biennial', 'medium', 'system', 'OARR')""",

    # 14. Работа с просроченной задолженностью
    """INSERT OR IGNORE INTO grc_audit_objects (name, description, category, owner_unit_id, audit_frequency, risk_level, created_by, audit_division)
       VALUES ('Работа с просроченной задолженностью', 'Взыскание и реструктуризация задолженности', 'business_process',
               (SELECT id FROM grc_org_units WHERE code = 'debt_dep'), 'biennial', 'medium', 'system', 'UAOB')""",

    # 15. Валютный контроль
    """INSERT OR IGNORE INTO grc_audit_objects (name, description, category, owner_unit_id, audit_frequency, risk_level, created_by, audit_division, regulatory_required)
       VALUES ('Валютный контроль', 'Контроль валютных операций и соблюдение валютного законодательства', 'regulatory',
               (SELECT id FROM grc_org_units WHERE code = 'DFM'), 'annual', 'high', 'system', 'OARR', 1)""",

    # 16. Бухгалтерский учёт и отчётность
    """INSERT OR IGNORE INTO grc_audit_objects (name, description, category, owner_unit_id, audit_frequency, risk_level, created_by, audit_division, regulatory_required)
       VALUES ('Бухгалтерский учёт и отчётность', 'Ведение бухгалтерского учёта и подготовка отчётности', 'financial',
               (SELECT id FROM grc_org_units WHERE code = 'fin_dep'), 'annual', 'high', 'system', 'OARR', 1)""",

    # 17. Налоговый учёт
    """INSERT OR IGNORE INTO grc_audit_objects (name, description, category, owner_unit_id, audit_frequency, risk_level, created_by, audit_division, regulatory_required)
       VALUES ('Налоговый учёт', 'Налоговое планирование и отчётность', 'financial',
               (SELECT id FROM grc_org_units WHERE code = 'fin_dep'), 'annual', 'medium', 'system', 'OARR', 1)""",

    # 18. Управление персоналом
    """INSERT OR IGNORE INTO grc_audit_objects (name, description, category, owner_unit_id, audit_frequency, risk_level, created_by, audit_division)
       VALUES ('Управление персоналом', 'HR-процессы, кадровый учёт, обучение', 'business_process',
               (SELECT id FROM grc_org_units WHERE code = 'corp_support'), 'triennial', 'low', 'system', 'UAOB')""",

    # 19. Закупки и хозяйственная деятельность
    """INSERT OR IGNORE INTO grc_audit_objects (name, description, category, owner_unit_id, audit_frequency, risk_level, created_by, audit_division)
       VALUES ('Закупки и хозяйственная деятельность', 'Тендеры, контракты, административное обеспечение', 'business_process',
               (SELECT id FROM grc_org_units WHERE code = 'corp_support'), 'biennial', 'medium', 'system', 'UAOB')""",

    # 20. Депозитарная деятельность
    """INSERT OR IGNORE INTO grc_audit_objects (name, description, category, owner_unit_id, audit_frequency, risk_level, created_by, audit_division, regulatory_required)
       VALUES ('Депозитарная деятельность', 'Учёт и хранение ценных бумаг', 'business_process',
               (SELECT id FROM grc_org_units WHERE code = 'inv_dep'), 'biennial', 'medium', 'system', 'OARR', 1)""",

    # 21. Карточный бизнес
    """INSERT OR IGNORE INTO grc_audit_objects (name, description, category, owner_unit_id, audit_frequency, risk_level, created_by, audit_division)
       VALUES ('Карточный бизнес', 'Эмиссия и эквайринг банковских карт', 'business_process',
               (SELECT id FROM grc_org_units WHERE code = 'trans_prod'), 'biennial', 'medium', 'system', 'UAOB')""",

    # 22. Структурные продукты
    """INSERT OR IGNORE INTO grc_audit_objects (name, description, category, owner_unit_id, audit_frequency, risk_level, created_by, audit_division)
       VALUES ('Структурные продукты', 'Разработка и продажа структурных финансовых продуктов', 'business_process',
               (SELECT id FROM grc_org_units WHERE code = 'struct_dep'), 'biennial', 'medium', 'system', 'OARR')""",

    # 23. Корреспондентские отношения
    """INSERT OR IGNORE INTO grc_audit_objects (name, description, category, owner_unit_id, audit_frequency, risk_level, created_by, audit_division)
       VALUES ('Корреспондентские отношения', 'Корреспондентские счета и межбанковские отношения', 'business_process',
               (SELECT id FROM grc_org_units WHERE code = 'treasury'), 'biennial', 'medium', 'system', 'OARR')""",

    # 24. Управление кредитными рисками
    """INSERT OR IGNORE INTO grc_audit_objects (name, description, category, owner_unit_id, audit_frequency, risk_level, created_by, audit_division, regulatory_required)
       VALUES ('Управление кредитными рисками', 'Методология и мониторинг кредитных рисков', 'business_process',
               (SELECT id FROM grc_org_units WHERE code = 'risk_dir'), 'annual', 'high', 'system', 'OARR', 1)""",

    # 25. Транзакционный бизнес
    """INSERT OR IGNORE INTO grc_audit_objects (name, description, category, owner_unit_id, audit_frequency, risk_level, created_by, audit_division)
       VALUES ('Транзакционный бизнес', 'Развитие транзакционных сервисов и продуктов', 'business_process',
               (SELECT id FROM grc_org_units WHERE code = 'trans_dev'), 'biennial', 'medium', 'system', 'UAOB')""",

    # 26. МСФО и регуляторная отчётность
    """INSERT OR IGNORE INTO grc_audit_objects (name, description, category, owner_unit_id, audit_frequency, risk_level, created_by, audit_division, regulatory_required)
       VALUES ('МСФО и регуляторная отчётность', 'Подготовка отчётности по МСФО и для регулятора', 'financial',
               (SELECT id FROM grc_org_units WHERE code = 'fin_dep'), 'annual', 'high', 'system', 'OARR', 1)""",

    # 27. Управление ликвидностью
    """INSERT OR IGNORE INTO grc_audit_objects (name, description, category, owner_unit_id, audit_frequency, risk_level, created_by, audit_division, regulatory_required)
       VALUES ('Управление ликвидностью', 'Планирование и контроль ликвидности банка', 'financial',
               (SELECT id FROM grc_org_units WHERE code = 'treasury'), 'annual', 'high', 'system', 'OARR', 1)""",

    # 28. Непрерывность деятельности (BCP/DRP)
    """INSERT OR IGNORE INTO grc_audit_objects (name, description, category, owner_unit_id, audit_frequency, risk_level, created_by, audit_division)
       VALUES ('Непрерывность деятельности (BCP/DRP)', 'Планирование и обеспечение непрерывности бизнеса', 'it_system',
               (SELECT id FROM grc_org_units WHERE code = 'DIT'), 'biennial', 'high', 'system', 'OARR')""",

    # 29. Розничный бизнес и продажи
    """INSERT OR IGNORE INTO grc_audit_objects (name, description, category, owner_unit_id, audit_frequency, risk_level, created_by, audit_division)
       VALUES ('Розничный бизнес и продажи', 'Продажа банковских продуктов физическим лицам', 'business_process',
               (SELECT id FROM grc_org_units WHERE code = 'DRB'), 'biennial', 'medium', 'system', 'UAOB')""",

    # 30. Внутренний контроль (СВК)
    """INSERT OR IGNORE INTO grc_audit_objects (name, description, category, owner_unit_id, audit_frequency, risk_level, created_by, audit_division, regulatory_required)
       VALUES ('Внутренний контроль (СВК)', 'Система внутреннего контроля банка', 'regulatory',
               (SELECT id FROM grc_org_units WHERE code = 'DOR'), 'annual', 'critical', 'system', 'OARR', 1)""",
]

# ── Seed 5: 270 risk scores (9 dimensions × 30 audit objects) ────

# Risk score data: (object_index_1based, dimension, score)
# Dimensions: process_risk, control_maturity, it_dependency, regulatory_impact,
#             fraud_risk, financial_impact, strategic_value, management_concern, change_intensity

_RISK_DIMENSIONS = [
    "process_risk", "control_maturity", "it_dependency",
    "regulatory_impact", "fraud_risk", "financial_impact",
    "strategic_value", "management_concern", "change_intensity",
]

# Scores per object (ordered by object insertion order 1-30)
# Each tuple: (pr, cm, it, ri, fr, fi, sv, mc, ci)
_RISK_SCORE_DATA = [
    (3, 2, 2, 3, 2, 3, 3, 3, 2),  # 1  Кредитование корп.
    (3, 2, 2, 3, 2, 3, 3, 3, 2),  # 2  Кредитование физ.
    (3, 2, 2, 3, 2, 3, 2, 3, 2),  # 3  Ипотечное кредитование
    (2, 2, 2, 3, 1, 3, 2, 3, 2),  # 4  Управление рыночными рисками
    (2, 2, 2, 3, 2, 2, 2, 3, 2),  # 5  Управление операционными рисками
    (3, 2, 2, 3, 3, 2, 2, 3, 2),  # 6  ПОД/ФТ и комплаенс
    (2, 2, 2, 2, 1, 3, 2, 2, 1),  # 7  Казначейские операции
    (2, 2, 1, 2, 1, 2, 2, 2, 1),  # 8  Операции с ценными бумагами
    (2, 2, 2, 2, 2, 2, 2, 2, 1),  # 9  РКО
    (3, 2, 3, 2, 3, 2, 3, 3, 3),  # 10 ДБО
    (3, 3, 3, 3, 3, 2, 3, 3, 3),  # 11 Информационная безопасность
    (2, 2, 3, 1, 1, 2, 2, 2, 2),  # 12 ИТ-инфраструктура
    (2, 2, 3, 1, 1, 1, 2, 2, 3),  # 13 Разработка ПО
    (2, 2, 1, 2, 2, 2, 1, 2, 1),  # 14 Просроченная задолженность
    (2, 2, 1, 3, 2, 2, 1, 2, 2),  # 15 Валютный контроль
    (2, 2, 2, 3, 1, 2, 2, 3, 2),  # 16 Бухгалтерский учёт
    (2, 2, 1, 3, 1, 2, 1, 2, 1),  # 17 Налоговый учёт
    (1, 1, 1, 1, 1, 1, 1, 1, 1),  # 18 Управление персоналом
    (2, 2, 1, 1, 2, 2, 1, 2, 1),  # 19 Закупки
    (2, 2, 2, 3, 1, 2, 1, 2, 1),  # 20 Депозитарная деятельность
    (2, 2, 2, 2, 2, 2, 2, 2, 2),  # 21 Карточный бизнес
    (2, 2, 1, 2, 1, 2, 2, 2, 2),  # 22 Структурные продукты
    (2, 1, 1, 2, 1, 2, 1, 1, 1),  # 23 Корреспондентские отношения
    (3, 2, 2, 3, 2, 3, 3, 3, 2),  # 24 Управление кредитными рисками
    (2, 2, 2, 1, 1, 2, 2, 2, 2),  # 25 Транзакционный бизнес
    (2, 2, 2, 3, 1, 2, 2, 3, 2),  # 26 МСФО
    (2, 2, 2, 3, 1, 3, 2, 3, 2),  # 27 Управление ликвидностью
    (2, 2, 3, 2, 1, 2, 2, 3, 2),  # 28 BCP/DRP
    (2, 2, 2, 2, 2, 2, 2, 2, 2),  # 29 Розничный бизнес
    (3, 2, 2, 3, 2, 2, 3, 3, 2),  # 30 Внутренний контроль (СВК)
]

# ── Seed 6: Strategic plan + 30 items ─────────────────────────────

_SEED_STRATEGIC_PLAN = """INSERT OR IGNORE INTO grc_strategic_plans
    (title, period_start, period_end, description, status, created_by)
    VALUES ('Стратегический план аудита 2025-2027', 2025, 2027,
            'Трёхлетний стратегический план проверок на основе риск-ориентированного подхода',
            'approved', 'system')"""

# Plan items: (object_index_1based, year, quarter, priority)
_STRATEGIC_PLAN_ITEMS = [
    (1,  2025, 'Q1', 'high'),      # Кредитование корп.
    (2,  2025, 'Q1', 'high'),      # Кредитование физ.
    (6,  2025, 'Q1', 'critical'),   # ПОД/ФТ
    (11, 2025, 'Q2', 'critical'),   # Информационная безопасность
    (4,  2025, 'Q2', 'high'),      # Рыночные риски
    (5,  2025, 'Q2', 'high'),      # Операционные риски
    (7,  2025, 'Q3', 'high'),      # Казначейские операции
    (10, 2025, 'Q3', 'high'),      # ДБО
    (16, 2025, 'Q3', 'high'),      # Бухучёт
    (30, 2025, 'Q4', 'critical'),   # СВК
    (24, 2025, 'Q4', 'high'),      # Управление кредитными рисками
    (27, 2025, 'Q4', 'high'),      # Управление ликвидностью
    (3,  2026, 'Q1', 'high'),      # Ипотечное кредитование
    (15, 2026, 'Q1', 'high'),      # Валютный контроль
    (26, 2026, 'Q2', 'high'),      # МСФО
    (17, 2026, 'Q2', 'medium'),    # Налоговый учёт
    (9,  2026, 'Q2', 'medium'),    # РКО
    (14, 2026, 'Q3', 'medium'),    # Просроченная задолженность
    (21, 2026, 'Q3', 'medium'),    # Карточный бизнес
    (12, 2026, 'Q3', 'medium'),    # ИТ-инфраструктура
    (20, 2026, 'Q4', 'medium'),    # Депозитарная деятельность
    (28, 2026, 'Q4', 'high'),      # BCP/DRP
    (8,  2027, 'Q1', 'medium'),    # Операции с ЦБ
    (13, 2027, 'Q1', 'medium'),    # Разработка ПО
    (25, 2027, 'Q2', 'medium'),    # Транзакционный бизнес
    (22, 2027, 'Q2', 'medium'),    # Структурные продукты
    (19, 2027, 'Q3', 'medium'),    # Закупки
    (23, 2027, 'Q3', 'low'),       # Корреспондентские отношения
    (29, 2027, 'Q3', 'medium'),    # Розничный бизнес
    (18, 2027, 'Q4', 'low'),       # Управление персоналом
]


# ═══════════════════════════════════════════════════════════════════
#  INIT FUNCTION
# ═══════════════════════════════════════════════════════════════════

def init_db(db: Database):
    """Initialize all tables, indexes, and seed data. Safe to call multiple times."""
    logger.info(f"Initializing database: {db.db_path}")

    # 1. Create all tables
    for ddl in _TABLES:
        db._conn.execute(ddl)

    # 2. Create all indexes
    for idx in _INDEXES:
        db._conn.execute(idx)

    # 3. Seed org units (order matters for parent references)
    for sql in _SEED_ORG_UNITS:
        db._conn.execute(sql)

    # 4. Seed workflow configs
    for sql in _SEED_WORKFLOW_CONFIGS:
        db._conn.execute(sql)

    # 5. Seed enum definitions
    for sql in _SEED_ENUMS:
        db._conn.execute(sql)

    # 6. Seed audit objects (skip if already populated)
    existing_objects = db._conn.execute(
        "SELECT COUNT(*) FROM grc_audit_objects"
    ).fetchone()[0]

    if existing_objects == 0:
        for sql in _SEED_AUDIT_OBJECTS:
            db._conn.execute(sql)

    # 7. Seed risk scores (270 rows: 9 dimensions × 30 objects)
    # Get audit object IDs in insertion order
    cursor = db._conn.execute(
        "SELECT id FROM grc_audit_objects ORDER BY id"
    )
    obj_ids = [row[0] for row in cursor.fetchall()]

    for obj_idx, scores in enumerate(_RISK_SCORE_DATA):
        if obj_idx >= len(obj_ids):
            break
        obj_id = obj_ids[obj_idx]
        for dim_idx, score in enumerate(scores):
            db._conn.execute(
                """INSERT OR IGNORE INTO grc_risk_scores
                   (audit_object_id, dimension, score, updated_by)
                   VALUES (?, ?, ?, 'system')""",
                (obj_id, _RISK_DIMENSIONS[dim_idx], score)
            )

    # 8. Seed strategic plan (skip if already exists)
    existing_plans = db._conn.execute(
        "SELECT COUNT(*) FROM grc_strategic_plans"
    ).fetchone()[0]
    if existing_plans == 0:
        db._conn.execute(_SEED_STRATEGIC_PLAN)

    # 9. Seed strategic plan items (skip if already populated)
    existing_items = db._conn.execute(
        "SELECT COUNT(*) FROM grc_strategic_plan_items"
    ).fetchone()[0]

    if existing_items == 0:
        plan_row = db._conn.execute(
            "SELECT id FROM grc_strategic_plans ORDER BY id LIMIT 1"
        ).fetchone()
        if plan_row and obj_ids:
            plan_id = plan_row[0]
            for obj_1based, year, quarter, priority in _STRATEGIC_PLAN_ITEMS:
                obj_idx = obj_1based - 1
                if obj_idx < len(obj_ids):
                    db._conn.execute(
                        """INSERT OR IGNORE INTO grc_strategic_plan_items
                           (strategic_plan_id, audit_object_id, planned_year, quarter, priority)
                           VALUES (?, ?, ?, ?, ?)""",
                        (plan_id, obj_ids[obj_idx], year, quarter, priority)
                    )

    # 10. Default BI datasource with actual path (skip if already exists)
    existing_ds = db._conn.execute(
        "SELECT COUNT(*) FROM bi_datasources"
    ).fetchone()[0]
    if existing_ds == 0:
        db._conn.execute(
            """INSERT OR IGNORE INTO bi_datasources
               (name, engine, extra_params, created_by)
               VALUES (?, ?, ?, ?)""",

    """CREATE UNIQUE INDEX IF NOT EXISTS uix_risk_scores_obj_dim ON grc_risk_scores(audit_object_id, dimension)""",
            ("DAP Database (SQLite)", "sqlite",
             json.dumps({"path": db.db_path}), "system")
        )

    db._conn.commit()

    # Verify
    count = db._conn.execute(
        "SELECT COUNT(*) FROM sqlite_master WHERE type='table'"
    ).fetchone()[0]
    logger.info(f"Database initialized: {count} tables")
