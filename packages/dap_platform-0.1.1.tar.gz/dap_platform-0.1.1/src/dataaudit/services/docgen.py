"""
DAP Document Generation Service
Generates .docx audit reports and remediation orders.
Requires: python-docx (add to requirements.txt)
"""

import os
import logging
from datetime import date
from typing import Optional

from docx import Document
from docx.shared import Inches, Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.section import WD_ORIENT

logger = logging.getLogger("dap.docgen")


# ── Severity labels ──────────────────────────────────

SEVERITY_LABELS = {
    "critical": "Критический",
    "high": "Высокий",
    "medium": "Средний",
    "low": "Низкий",
}

STATUS_LABELS = {
    "draft": "Черновик",
    "under_review": "На рассмотрении",
    "approved": "Утверждён",
    "active": "Активен",
    "completed": "Завершён",
    "archived": "Архив",
    "planned": "Запланирована",
    "in_progress": "В работе",
    "fieldwork": "Полевая работа",
    "review": "Проверка",
    "findings_issued": "Замечания выданы",
    "remediation": "Исправление",
    "closed": "Закрыта",
    "confirmed": "Подтверждено",
    "remediation_issued": "Рекомендация выдана",
    "resolved": "Исправлено",
    "assigned": "Назначено",
    "submitted": "На проверке",
    "verified": "Проверено",
    "cancelled": "Отменено",
}


# ── Styling helpers ──────────────────────────────────

def _apply_heading_style(doc: Document):
    """Configure document-wide font defaults."""
    style = doc.styles["Normal"]
    font = style.font
    font.name = "Times New Roman"
    font.size = Pt(12)

    for i in range(1, 4):
        heading_style = doc.styles[f"Heading {i}"]
        heading_style.font.name = "Times New Roman"
        heading_style.font.color.rgb = RGBColor(0x1E, 0x3A, 0x8A)


def _add_bank_header(doc: Document):
    """Add standard bank header to document."""
    header_para = doc.add_paragraph()
    header_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = header_para.add_run("ПАО «МОСКОВСКИЙ КРЕДИТНЫЙ БАНК»")
    run.bold = True
    run.font.size = Pt(14)
    run.font.name = "Times New Roman"

    sub = doc.add_paragraph()
    sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run2 = sub.add_run("Департамент внутреннего аудита")
    run2.font.size = Pt(12)
    run2.font.name = "Times New Roman"
    run2.font.color.rgb = RGBColor(0x64, 0x74, 0x8B)

    # Separator line
    doc.add_paragraph("─" * 60).alignment = WD_ALIGN_PARAGRAPH.CENTER


def _add_field(doc: Document, label: str, value: str):
    """Add a label: value pair."""
    para = doc.add_paragraph()
    run_label = para.add_run(f"{label}: ")
    run_label.bold = True
    run_label.font.size = Pt(11)
    run_label.font.name = "Times New Roman"
    run_value = para.add_run(str(value or "—"))
    run_value.font.size = Pt(11)
    run_value.font.name = "Times New Roman"


def _add_table(doc: Document, headers: list, rows: list):
    """Add a formatted table."""
    table = doc.add_table(rows=1 + len(rows), cols=len(headers))
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER

    # Header row
    for i, h in enumerate(headers):
        cell = table.rows[0].cells[i]
        cell.text = h
        for para in cell.paragraphs:
            para.alignment = WD_ALIGN_PARAGRAPH.CENTER
            for run in para.runs:
                run.bold = True
                run.font.size = Pt(10)
                run.font.name = "Times New Roman"
        # Header background
        from docx.oxml.ns import qn
        shading = cell._element.get_or_add_tcPr()
        shd = shading.makeelement(qn("w:shd"), {
            qn("w:fill"): "E2E8F0",
            qn("w:val"): "clear",
        })
        shading.append(shd)

    # Data rows
    for r_idx, row_data in enumerate(rows):
        for c_idx, val in enumerate(row_data):
            cell = table.rows[r_idx + 1].cells[c_idx]
            cell.text = str(val or "—")
            for para in cell.paragraphs:
                for run in para.runs:
                    run.font.size = Pt(10)
                    run.font.name = "Times New Roman"

    return table


def _add_signature_block(doc: Document, roles: list):
    """Add signature lines at the bottom."""
    doc.add_paragraph("")  # spacer
    doc.add_paragraph("")

    for role_title, name in roles:
        para = doc.add_paragraph()
        run = para.add_run(f"{role_title}:")
        run.font.size = Pt(11)
        run.font.name = "Times New Roman"

        sig_para = doc.add_paragraph()
        sig_para.add_run("_" * 30 + "  /  ").font.name = "Times New Roman"
        run_name = sig_para.add_run(name or "________________")
        run_name.font.name = "Times New Roman"
        run_name.font.size = Pt(11)
        doc.add_paragraph("")


# ══════════════════════════════════════════════════════════════════════
#  DOCUMENT 1: АКТ ПРОВЕРКИ (Audit Report per Engagement)
# ══════════════════════════════════════════════════════════════════════

def generate_audit_report(
    engagement: dict,
    findings: list,
    remediations: list,
    members: list,
    output_path: str,
) -> str:
    """
    Generate an Audit Report (.docx) for a single engagement.
    Returns the full path to the generated file.
    """
    doc = Document()
    _apply_heading_style(doc)
    _add_bank_header(doc)

    # ── Title ──
    title_para = doc.add_paragraph()
    title_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title_para.space_after = Pt(6)
    run = title_para.add_run(f"АКТ ПРОВЕРКИ")
    run.bold = True
    run.font.size = Pt(16)
    run.font.name = "Times New Roman"

    sub_title = doc.add_paragraph()
    sub_title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run2 = sub_title.add_run(engagement.get("title", ""))
    run2.font.size = Pt(13)
    run2.font.name = "Times New Roman"
    run2.italic = True

    doc.add_paragraph("")

    # ── Section 1: General Information ──
    doc.add_heading("1. Общая информация", level=2)

    _add_field(doc, "Номер проверки", f"#{engagement.get('id', '')}")
    _add_field(doc, "План аудита", engagement.get("plan_title", "—"))
    _add_field(doc, "Тип проверки", engagement.get("engagement_type", "—"))
    _add_field(doc, "Уровень риска", engagement.get("risk_level", "—"))
    _add_field(doc, "Статус", STATUS_LABELS.get(engagement.get("status", ""), engagement.get("status", "")))
    _add_field(doc, "Проверяющее подразделение", engagement.get("audit_unit_name", "—"))
    _add_field(doc, "Проверяемое подразделение", engagement.get("target_unit_name", "—"))
    _add_field(doc, "Плановый период",
               f"{engagement.get('planned_start', '—')} — {engagement.get('planned_end', '—')}")
    _add_field(doc, "Фактический период",
               f"{engagement.get('actual_start', '—')} — {engagement.get('actual_end', '—')}")

    # Team members
    if members:
        doc.add_paragraph("")
        doc.add_heading("Состав группы аудита", level=3)
        member_rows = []
        for m in members:
            role_label = {"lead": "Руководитель", "auditor": "Аудитор", "observer": "Наблюдатель"}.get(
                m.get("member_role", ""), m.get("member_role", ""))
            member_rows.append([m.get("user_id", ""), role_label])
        _add_table(doc, ["Сотрудник", "Роль"], member_rows)

    # ── Section 2: Findings ──
    doc.add_paragraph("")
    doc.add_heading("2. Выявленные замечания", level=2)

    if findings:
        finding_rows = []
        for i, f in enumerate(findings, 1):
            finding_rows.append([
                f.get("ref_number", f"#{f.get('id', '')}"),
                SEVERITY_LABELS.get(f.get("severity", ""), f.get("severity", "")),
                f.get("title", ""),
                f.get("recommendation", "—"),
                STATUS_LABELS.get(f.get("status", ""), f.get("status", "")),
            ])
        _add_table(doc, ["Номер", "Критичность", "Описание", "Рекомендация", "Статус"], finding_rows)
    else:
        doc.add_paragraph("Замечания не выявлены.")

    # ── Section 3: Remediations ──
    doc.add_paragraph("")
    doc.add_heading("3. Рекомендации", level=2)

    if remediations:
        rem_rows = []
        for r in remediations:
            rem_rows.append([
                r.get("ref_number", f"#{r.get('id', '')}"),
                r.get("title", ""),
                r.get("assigned_to_user_id", "—"),
                str(r.get("deadline", "—")),
                STATUS_LABELS.get(r.get("status", ""), r.get("status", "")),
            ])
        _add_table(doc, ["Номер", "Рекомендации", "Исполнитель", "Срок", "Статус"], rem_rows)
    else:
        doc.add_paragraph("Рекомендации не выданы.")

    # ── Section 4: Conclusion ──
    doc.add_paragraph("")
    doc.add_heading("4. Заключение", level=2)

    total_findings = len(findings)
    critical = sum(1 for f in findings if f.get("severity") == "critical")
    high = sum(1 for f in findings if f.get("severity") == "high")

    conclusion = (
        f"По результатам проверки выявлено {total_findings} замечани{'е' if total_findings == 1 else 'й' if total_findings > 4 else 'я'}"
    )
    if critical > 0 or high > 0:
        conclusion += f", из них критических: {critical}, высоких: {high}"
    conclusion += "."

    doc.add_paragraph(conclusion)

    # ── Signatures ──
    lead = engagement.get("lead_auditor_id", "")
    _add_signature_block(doc, [
        ("Руководитель группы аудита", lead),
        ("Начальник Департамента ВА", ""),
    ])

    # ── Footer with generation date ──
    doc.add_paragraph("")
    footer_para = doc.add_paragraph()
    footer_para.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = footer_para.add_run(f"Документ сгенерирован: {date.today().isoformat()}")
    run.font.size = Pt(8)
    run.font.color.rgb = RGBColor(0x94, 0xA3, 0xB8)
    run.font.name = "Times New Roman"

    doc.save(output_path)
    logger.info(f"Audit report generated: {output_path}")
    return output_path


# ══════════════════════════════════════════════════════════════════════
#  DOCUMENT 2: Рекомендация (Remediation Order per Finding)
# ══════════════════════════════════════════════════════════════════════

def generate_remediation_order(
    finding: dict,
    engagement: dict,
    remediations: list,
    output_path: str,
) -> str:
    """
    Generate a Remediation Order (.docx) for a single finding.
    Returns the full path to the generated file.
    """
    doc = Document()
    _apply_heading_style(doc)
    _add_bank_header(doc)

    # ── Title ──
    title_para = doc.add_paragraph()
    title_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title_para.space_after = Pt(6)
    run = title_para.add_run("РЕКОМЕНДАЦИЯ")
    run.bold = True
    run.font.size = Pt(16)
    run.font.name = "Times New Roman"

    ref = finding.get("ref_number", f"#{finding.get('id', '')}")
    sub_title = doc.add_paragraph()
    sub_title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run2 = sub_title.add_run(f"№ {ref}")
    run2.font.size = Pt(13)
    run2.font.name = "Times New Roman"
    run2.italic = True

    doc.add_paragraph("")

    # ── Section 1: Basis ──
    doc.add_heading("1. Основание", level=2)

    _add_field(doc, "Проверка", engagement.get("title", "—"))
    _add_field(doc, "Проверяемое подразделение", engagement.get("target_unit_name", "—"))
    _add_field(doc, "Период проверки",
               f"{engagement.get('planned_start', '—')} — {engagement.get('planned_end', '—')}")

    # ── Section 2: Finding Description ──
    doc.add_paragraph("")
    doc.add_heading("2. Описание замечания", level=2)

    _add_field(doc, "Номер замечания", ref)
    _add_field(doc, "Критичность", SEVERITY_LABELS.get(finding.get("severity", ""), finding.get("severity", "")))
    _add_field(doc, "Наименование", finding.get("title", ""))

    if finding.get("description"):
        doc.add_paragraph("")
        para = doc.add_paragraph()
        run = para.add_run(finding["description"])
        run.font.size = Pt(11)
        run.font.name = "Times New Roman"

    if finding.get("evidence"):
        doc.add_paragraph("")
        doc.add_heading("Доказательства", level=3)
        para = doc.add_paragraph()
        run = para.add_run(finding["evidence"])
        run.font.size = Pt(11)
        run.font.name = "Times New Roman"

    if finding.get("recommendation"):
        doc.add_paragraph("")
        doc.add_heading("Рекомендация аудита", level=3)
        para = doc.add_paragraph()
        run = para.add_run(finding["recommendation"])
        run.font.size = Pt(11)
        run.font.name = "Times New Roman"

    # ── Section 3: Required Actions ──
    doc.add_paragraph("")
    doc.add_heading("3. Требуемые действия", level=2)

    if remediations:
        rem_rows = []
        for r in remediations:
            rem_rows.append([
                r.get("ref_number", f"#{r.get('id', '')}"),
                r.get("title", ""),
                r.get("assigned_to_user_id", "—"),
                r.get("assigned_unit_name", "—"),
                str(r.get("deadline", "—")),
            ])
        _add_table(doc, ["Номер", "Действие", "Исполнитель", "Подразделение", "Срок"], rem_rows)
    else:
        doc.add_paragraph("ПРекомендации не назначены.")

    # ── Section 4: Responsible ──
    doc.add_paragraph("")
    doc.add_heading("4. Ответственные", level=2)

    _add_field(doc, "Ответственное подразделение", finding.get("responsible_unit_name", "—"))

    if remediations:
        assignees = set()
        for r in remediations:
            uid = r.get("assigned_to_user_id")
            if uid:
                assignees.add(uid)
        if assignees:
            _add_field(doc, "Исполнители", ", ".join(sorted(assignees)))

    # ── Signatures ──
    _add_signature_block(doc, [
        ("Начальник Департамента ВА", ""),
        ("Руководитель проверяемого подразделения", ""),
    ])

    # ── Footer ──
    doc.add_paragraph("")
    footer_para = doc.add_paragraph()
    footer_para.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = footer_para.add_run(f"Документ сгенерирован: {date.today().isoformat()}")
    run.font.size = Pt(8)
    run.font.color.rgb = RGBColor(0x94, 0xA3, 0xB8)
    run.font.name = "Times New Roman"

    doc.save(output_path)
    logger.info(f"Remediation order generated: {output_path}")
    return output_path
