"""
DAP Email Service
Simple SMTP email sending with environment-based configuration.
Works with Mailtrap (dev), Mailpit (local), or any real SMTP server (production).
"""

import os
import logging
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Optional

logger = logging.getLogger("dap.email")


class EmailService:
    """Lightweight SMTP email sender."""

    def __init__(self):
        self.enabled = os.getenv("SMTP_ENABLED", "false").lower() == "true"
        self.host = os.getenv("SMTP_HOST", "localhost")
        self.port = int(os.getenv("SMTP_PORT", "2525"))
        self.user = os.getenv("SMTP_USER", "")
        self.password = os.getenv("SMTP_PASSWORD", "")
        self.sender = os.getenv("SMTP_FROM", "dap-audit@mkb.ru")
        self.use_tls = os.getenv("SMTP_TLS", "true").lower() == "true"

        if self.enabled:
            logger.info(f"Email service enabled: {self.host}:{self.port}")
        else:
            logger.info("Email service disabled (SMTP_ENABLED != true)")

    def send(
        self,
        to: str,
        subject: str,
        body_text: str,
        body_html: Optional[str] = None,
    ) -> bool:
        """
        Send an email. Returns True on success, False on failure.
        Silently returns False if email is disabled — never blocks the caller.
        """
        if not self.enabled:
            logger.debug(f"Email skipped (disabled): {subject} → {to}")
            return False

        if not to or not subject:
            logger.warning("Email skipped: missing 'to' or 'subject'")
            return False

        try:
            msg = MIMEMultipart("alternative")
            msg["From"] = self.sender
            msg["To"] = to
            msg["Subject"] = subject

            msg.attach(MIMEText(body_text, "plain", "utf-8"))
            if body_html:
                msg.attach(MIMEText(body_html, "html", "utf-8"))

            with smtplib.SMTP(self.host, self.port) as server:
                if self.use_tls:
                    server.starttls()
                if self.user and self.password:
                    server.login(self.user, self.password)
                server.sendmail(self.sender, [to], msg.as_string())

            logger.info(f"Email sent: {subject} → {to}")
            return True

        except Exception as e:
            logger.error(f"Email failed: {subject} → {to}: {e}")
            return False


# ── Singleton ────────────────────────────────────────

_service: Optional[EmailService] = None


def get_email_service() -> EmailService:
    global _service
    if _service is None:
        _service = EmailService()
    return _service
