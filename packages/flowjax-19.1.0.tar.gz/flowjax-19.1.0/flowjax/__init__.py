"""FlowJAX - Distributions, bijections and normalizing flows using JAX and equinox."""

from importlib.metadata import version

__version__ = version("flowjax")
__all__ = []
