Bijections
==========================
For an introduction to using bijections in FlowJAX, see :ref:`/getting_started.rst`.

.. automodule:: flowjax.bijections
   :members:
   :show-inheritance:
   :member-order: groupwise

