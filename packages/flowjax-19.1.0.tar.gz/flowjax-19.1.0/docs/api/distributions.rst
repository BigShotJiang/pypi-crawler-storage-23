Distributions
==========================
For an introduction to using distributions in FlowJAX, see :ref:`/getting_started.rst`.
All distributions inherit from :py:class:`~flowjax.distributions.AbstractDistribution`.


.. automodule:: flowjax.distributions
   :members:
   :show-inheritance:
   :member-order: groupwise
