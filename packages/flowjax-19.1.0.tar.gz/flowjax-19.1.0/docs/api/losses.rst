Loss functions
==========================
Loss functions from ``flowjax.train.losses``.

.. automodule:: flowjax.train.losses
   :members:
   :undoc-members:
   :special-members: __call__
