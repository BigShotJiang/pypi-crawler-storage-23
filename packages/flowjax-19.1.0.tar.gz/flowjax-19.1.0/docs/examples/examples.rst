
.. toctree::
   :caption: Examples
   :glob:

   unconditional
   conditional
   variational_inference
   constrained
   snpe