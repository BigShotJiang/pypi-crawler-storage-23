# Licensing (overview)

This repository is licensed under the **MIT License**. See `LICENSE`.

## Third-party software

This project depends on third-party libraries with their own licenses.
See `THIRD_PARTY_LICENSES.MD` for attribution and dependency license notes.

The `LICENSES/` directory contains license texts for third-party software.
