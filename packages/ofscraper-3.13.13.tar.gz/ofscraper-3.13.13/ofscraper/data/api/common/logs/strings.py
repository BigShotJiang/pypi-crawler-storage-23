PROGRESS_IDS = "[bold]\[{} In progress ids][/bold] "
PROGRESS_RAW_TITLE = "[bold]\[{} In progress raw data][/bold] total item"

PROGRESS_RAW = "[bold]\[{} In progress raw data][/bold] current item count: {} data: {}"

PROGRESS_RAW_OFFSET = (
    "[bold]\[{} In progress raw data][/bold]]offset: {} current item count: {} data: {}"
)

FINAL_IDS = "[bold]{} Final ids[/bold] "
FINAL_RAW = "[bold]{} Final raw data[/bold]"
FINAL_COUNT = "[bold]{} Final Count[bold] "
FINAL_COUNT_POST = "[bold]{} Final count[bold]: {} post(s) "
FINAL_COUNT_ITEM = "[bold]{} Final count[bold]: {} {} "

RAW_INNER = "list info"
