r"""
                                                             
 _______  _______         _______  _______  _______  _______  _______  _______  _______ 
(  ___  )(  ____ \       (  ____ \(  ____ \(  ____ )(  ___  )(  ____ )(  ____ \(  ____ )
| (   ) || (    \/       | (    \/| (    \/| (    )|| (   ) || (    )|| (    \/| (    )|
| |   | || (__     _____ | (_____ | |      | (____)|| (___) || (____)|| (__    | (____)|
| |   | ||  __)   (_____)(_____  )| |      |     __)|  ___  ||  _____)|  __)   |     __)
| |   | || (                   ) || |      | (\ (   | (   ) || (      | (      | (\ (   
| (___) || )             /\____) || (____/\| ) \ \__| )   ( || )      | (____/\| ) \ \__
(_______)|/              \_______)(_______/|/   \__/|/     \||/       (_______/|/   \__/
                                                                                      
"""

from ofscraper.prompts.prompt_groups.actions import *
from ofscraper.prompts.prompt_groups.area import *
from ofscraper.prompts.prompt_groups.auth import *
from ofscraper.prompts.prompt_groups.config import *
from ofscraper.prompts.prompt_groups.menu import *
from ofscraper.prompts.prompt_groups.merge import *
from ofscraper.prompts.prompt_groups.model import *
from ofscraper.prompts.prompt_groups.profile import *
from ofscraper.prompts.prompt_groups.misc import *
