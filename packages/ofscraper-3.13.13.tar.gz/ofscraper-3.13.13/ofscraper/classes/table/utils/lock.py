import threading
mutex=threading.Lock()