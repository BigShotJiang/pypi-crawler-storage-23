desc = "Metadata Progress: ({p_count} photos, {v_count} videos, {a_count} audios, {forced_skipped} not changed, {skipped} failed || {sumcount}/{mediacount})"
