import queue
jobqueue = queue.Queue()