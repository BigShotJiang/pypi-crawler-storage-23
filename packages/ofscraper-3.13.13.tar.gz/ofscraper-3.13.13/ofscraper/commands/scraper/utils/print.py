import ofscraper.utils.console as console
from ofscraper.__version__ import __version__


