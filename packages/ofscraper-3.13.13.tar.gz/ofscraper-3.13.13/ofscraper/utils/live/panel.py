from functools import partial

from rich.panel import Panel

Blue_Panel = partial(Panel, style="bold deep_sky_blue2")
