KEY_OPTIONS = ["cdrm", "manual"]
DYNAMIC_OPTIONS = [
    "digitalcriminals",
    "manual",
    "generic",
    "datawhores",
    "xagler",
    "rafa",
]
METADATA_OPTIONS = ["complete", "update", "check"]
