# db and check
