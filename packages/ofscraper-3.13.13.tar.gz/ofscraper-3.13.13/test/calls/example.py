def func1(para1=True):
    if para1 is True:
        func2()


def func2():
    pass
