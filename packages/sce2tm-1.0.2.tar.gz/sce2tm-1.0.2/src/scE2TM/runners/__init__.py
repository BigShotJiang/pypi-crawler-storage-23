"""Runners module for training and evaluation"""

from scE2TM.runners.Runner import Runner

__all__ = ["Runner"]