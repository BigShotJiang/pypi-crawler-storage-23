"""Utilities module for scE2TM"""

# 修改为：导入 data 子模块
from scE2TM.utils import data

__all__ = ["data"]