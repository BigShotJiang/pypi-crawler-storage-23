import json

from trls import (
    build_rich_tree,
    render_compact_copy,
    render_json,
    render_markdown,
    render_prompt,
    render_text,
    scan_tree,
)
from trls.snapshot import load_snapshot, save_snapshot
from trls.tree import diff_trees


def create_sample_tree(tmp_path):
    project = tmp_path / "project"
    project.mkdir()
    (project / "src").mkdir()
    (project / "src" / "app.py").write_text("print('hello')\n", encoding="utf-8")
    (project / "README.md").write_text("# demo\n", encoding="utf-8")
    (project / "photo.jpg").write_bytes(b"jpg")
    (project / "movie.mp4").write_bytes(b"mp4")
    (project / "sheet.xlsx").write_bytes(b"xlsx")
    (project / ".env").write_text("SECRET=1\n", encoding="utf-8")
    (project / ".venv").mkdir()
    (project / ".venv" / "pyvenv.cfg").write_text("home = C:/Python\n", encoding="utf-8")
    (project / "dist").mkdir()
    (project / "dist" / "demo.whl").write_bytes(b"wheel")
    (project / "__pycache__").mkdir()
    (project / "__pycache__" / "app.cpython-312.pyc").write_bytes(b"pyc")
    return project


def test_scan_tree_hides_hidden_files_by_default(tmp_path):
    project = create_sample_tree(tmp_path)

    tree = scan_tree(project)
    child_names = [child.name for child in tree.children]

    assert ".env" not in child_names
    assert ".venv" not in child_names
    assert "dist" not in child_names
    assert "__pycache__" not in child_names
    assert "src" in child_names
    assert "README.md" in child_names


def test_scan_tree_applies_depth_and_ignore_patterns(tmp_path):
    project = create_sample_tree(tmp_path)

    tree = scan_tree(project, max_depth=1, ignore_patterns=["__pycache__"])
    child_names = [child.name for child in tree.children]

    assert "__pycache__" not in child_names
    src_node = next(child for child in tree.children if child.name == "src")
    assert src_node.children == []


def test_renderers_produce_stable_outputs(tmp_path):
    project = create_sample_tree(tmp_path)

    tree = scan_tree(project, show_hidden=True, ignore_patterns=["__pycache__"])
    compact_output = render_compact_copy(tree)
    prompt_output = render_prompt(tree)
    text_output = render_text(tree)
    markdown_output = render_markdown(tree)
    json_output = render_json(tree)
    payload = json.loads(json_output)

    assert compact_output.splitlines()[0] == "project/"
    assert "src/: app.py" in compact_output
    assert "root: " in compact_output
    assert "photo.jpg" in compact_output
    assert "[dir] project/" in prompt_output
    assert "[doc] README.md" in prompt_output
    assert "README.md" in text_output
    assert "- `project/`" in markdown_output
    assert any(child["name"] == ".env" for child in payload["children"])


def test_rich_renderer_applies_styles_by_node_type(tmp_path):
    project = create_sample_tree(tmp_path)

    tree = scan_tree(project, show_hidden=True, ignore_patterns=["__pycache__"])
    rich_tree = build_rich_tree(tree)

    assert rich_tree.label.spans[0].style == "bold cyan"

    labels = {child.label.plain: child.label.spans[-1].style for child in rich_tree.children}
    assert labels["src/"] == "bold cyan"
    assert labels["README.md"] == "bright_magenta"
    assert labels["photo.jpg"] == "bright_magenta"
    assert labels["movie.mp4"] == "bright_cyan"
    assert labels["sheet.xlsx"] == "bright_green"


def test_snapshot_round_trip_and_diff_statuses(tmp_path):
    project = create_sample_tree(tmp_path)
    snapshot_path = tmp_path / "snapshot.json"

    baseline = scan_tree(
        project,
        show_hidden=True,
        ignore_patterns=["__pycache__"],
        include_fingerprints=True,
    )
    save_snapshot(snapshot_path, project, baseline)
    loaded = load_snapshot(snapshot_path)

    assert loaded.name == "project"
    assert any(child.sha256 for child in loaded.children if child.name == "README.md")

    (project / "README.md").write_text("# changed\n", encoding="utf-8")
    (project / "src" / "new.py").write_text("print('new')\n", encoding="utf-8")
    (project / "src" / "app.py").unlink()

    current = scan_tree(
        project,
        show_hidden=True,
        ignore_patterns=["__pycache__"],
        include_fingerprints=True,
    )
    diff_tree = diff_trees(current, loaded)

    root_children = {child.name: child for child in diff_tree.children}
    src_children = {child.name: child for child in root_children["src"].children}

    assert diff_tree.diff_status == "modified"
    assert root_children["README.md"].diff_status == "modified"
    assert root_children["src"].diff_status == "modified"
    assert src_children["new.py"].diff_status == "added"
    assert src_children["app.py"].diff_status == "removed"

    prompt_output = render_prompt(diff_tree)
    text_output = render_text(diff_tree)

    assert "~ [doc] README.md" in prompt_output
    assert "+ [py] new.py" in prompt_output
    assert "- [py] app.py" in prompt_output
    assert "~ README.md" in text_output

    compact_output = render_compact_copy(diff_tree)
    assert compact_output.splitlines()[0] == "project/"
    assert "src/: +new.py, -app.py" in compact_output or "src/: -app.py, +new.py" in compact_output
    assert "root: " in compact_output
    assert "~README.md" in compact_output
