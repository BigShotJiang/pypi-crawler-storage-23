import json

import pytest

from trls import __version__
import trls.clipboard as clipboard_module
import trls.cli as cli_module
from trls.cli import main
from trls.snapshot import save_snapshot
from trls.tree import scan_tree


def create_project(tmp_path):
    root = tmp_path / "demo"
    root.mkdir()
    (root / "notes.md").write_text("demo\n", encoding="utf-8")
    (root / "src").mkdir()
    (root / "src" / "main.py").write_text("print('demo')\n", encoding="utf-8")
    return root


def test_cli_text_output(capsys, tmp_path):
    root = create_project(tmp_path)

    exit_code = main([str(root), "--format", "text"])
    captured = capsys.readouterr()

    assert exit_code == 0
    assert "demo/" in captured.out
    assert "notes.md" in captured.out


def test_cli_defaults_to_rich_output(capsys, tmp_path):
    root = create_project(tmp_path)

    exit_code = main([str(root)])
    captured = capsys.readouterr()

    assert exit_code == 0
    assert "demo/" in captured.out
    assert "notes.md" in captured.out
    assert "main.py" in captured.out
    assert "[dir]" not in captured.out


def test_cli_auto_saves_snapshot_on_normal_run(capsys, monkeypatch, tmp_path):
    root = create_project(tmp_path)
    snapshot_dir = tmp_path / "snapshots"
    monkeypatch.setenv("TRLS_SNAPSHOT_DIR", str(snapshot_dir))

    exit_code = main([str(root), "--format", "prompt"])
    capsys.readouterr()

    assert exit_code == 0
    assert any(snapshot_dir.iterdir())


def test_cli_defaults_to_diff_against_previous_run(capsys, monkeypatch, tmp_path):
    root = create_project(tmp_path)
    snapshot_dir = tmp_path / "snapshots"
    monkeypatch.setenv("TRLS_SNAPSHOT_DIR", str(snapshot_dir))

    main([str(root), "--format", "prompt"])
    capsys.readouterr()

    (root / "notes.md").write_text("updated\n", encoding="utf-8")
    (root / "src" / "helper.py").write_text("print('helper')\n", encoding="utf-8")
    (root / "src" / "main.py").unlink()

    exit_code = main([str(root), "--format", "prompt"])
    captured = capsys.readouterr()

    assert exit_code == 0
    assert "~ [doc] notes.md" in captured.out
    assert "+ [py] helper.py" in captured.out
    assert "- [py] main.py" in captured.out


def test_cli_markdown_output(capsys, tmp_path):
    root = create_project(tmp_path)

    main([str(root), "--format", "markdown", "--depth", "1"])
    captured = capsys.readouterr()

    assert "- `demo/`" in captured.out
    assert "- `src/`" in captured.out


def test_cli_json_output(capsys, tmp_path):
    root = create_project(tmp_path)

    main([str(root), "--format", "json"])
    captured = capsys.readouterr()
    payload = json.loads(captured.out)

    assert payload["name"] == "demo"
    assert any(child["name"] == "src" for child in payload["children"])


def test_cli_copy_writes_compact_clipboard_output(capsys, monkeypatch, tmp_path):
    root = create_project(tmp_path)
    copied = {}

    def fake_copy_text(text):
        copied["text"] = text

    monkeypatch.setattr(cli_module, "copy_text", fake_copy_text)

    exit_code = main([str(root), "-c", "--format", "prompt"])
    captured = capsys.readouterr()

    assert exit_code == 0
    assert "[dir] demo/" in captured.out
    clipboard_lines = copied["text"].splitlines()
    assert clipboard_lines[0] == "demo/"
    assert "src/: main.py" in copied["text"]
    assert "root: notes.md" in copied["text"]
    assert copied["text"] != captured.out.strip()


def test_cli_version_output(capsys):
    with pytest.raises(SystemExit) as exc_info:
        main(["--version"])

    captured = capsys.readouterr()

    assert exc_info.value.code == 0
    assert captured.out.strip() == f"trls {__version__}"


def test_cli_rejects_negative_depth(tmp_path):
    root = create_project(tmp_path)

    with pytest.raises(SystemExit):
        main([str(root), "--depth", "-1"])


def test_cli_can_diff_against_last_snapshot(capsys, monkeypatch, tmp_path):
    root = create_project(tmp_path)
    snapshot_dir = tmp_path / "snapshots"
    monkeypatch.setenv("TRLS_SNAPSHOT_DIR", str(snapshot_dir))

    main([str(root), "--format", "prompt"])
    capsys.readouterr()

    (root / "notes.md").write_text("updated\n", encoding="utf-8")
    (root / "src" / "helper.py").write_text("print('helper')\n", encoding="utf-8")
    (root / "src" / "main.py").unlink()

    exit_code = main([str(root), "--diff-last", "--format", "prompt"])
    captured = capsys.readouterr()

    assert exit_code == 0
    assert any(snapshot_dir.iterdir())
    assert "~ [doc] notes.md" in captured.out
    assert "+ [py] helper.py" in captured.out
    assert "- [py] main.py" in captured.out


def test_cli_save_snapshot_suppresses_default_diff(capsys, monkeypatch, tmp_path):
    root = create_project(tmp_path)
    snapshot_dir = tmp_path / "snapshots"
    monkeypatch.setenv("TRLS_SNAPSHOT_DIR", str(snapshot_dir))

    main([str(root), "--format", "prompt"])
    capsys.readouterr()

    (root / "notes.md").write_text("updated\n", encoding="utf-8")

    exit_code = main([str(root), "-save", "--format", "prompt"])
    captured = capsys.readouterr()

    assert exit_code == 0
    assert "~ [doc] notes.md" not in captured.out


def test_cli_accepts_simple_diff_alias(capsys, monkeypatch, tmp_path):
    root = create_project(tmp_path)
    snapshot_dir = tmp_path / "snapshots"
    monkeypatch.setenv("TRLS_SNAPSHOT_DIR", str(snapshot_dir))

    main([str(root), "--format", "prompt"])
    capsys.readouterr()

    (root / "notes.md").write_text("updated\n", encoding="utf-8")

    exit_code = main([str(root), "-diff", "--format", "prompt"])
    captured = capsys.readouterr()

    assert exit_code == 0
    assert "~ [doc] notes.md" in captured.out


def test_cli_copy_preserves_diff_markers_in_clipboard(capsys, monkeypatch, tmp_path):
    root = create_project(tmp_path)
    snapshot_dir = tmp_path / "snapshots"
    copied = {}
    monkeypatch.setenv("TRLS_SNAPSHOT_DIR", str(snapshot_dir))

    def fake_copy_text(text):
        copied["text"] = text

    monkeypatch.setattr(cli_module, "copy_text", fake_copy_text)

    main([str(root), "--format", "prompt"])
    capsys.readouterr()

    (root / "notes.md").write_text("updated\n", encoding="utf-8")
    (root / "src" / "helper.py").write_text("print('helper')\n", encoding="utf-8")

    exit_code = main([str(root), "-c", "--format", "prompt"])
    captured = capsys.readouterr()

    assert exit_code == 0
    assert "~ [doc] notes.md" in captured.out
    assert "root: ~notes.md" in copied["text"]
    assert "+helper.py" in copied["text"]


def test_cli_copy_reports_clipboard_failure(capsys, monkeypatch, tmp_path):
    root = create_project(tmp_path)

    def failing_copy_text(text):
        raise RuntimeError("clipboard unavailable")

    monkeypatch.setattr(cli_module, "copy_text", failing_copy_text)

    exit_code = main([str(root), "-c"])
    captured = capsys.readouterr()

    assert exit_code == 1
    assert "Failed to copy to clipboard: clipboard unavailable" in captured.err


def test_cli_progress_runs_during_scan(capsys, monkeypatch, tmp_path):
    root = create_project(tmp_path)
    progress_updates = []

    class FakeProgress:
        def __init__(self, *args, **kwargs):
            pass

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            return False

        def add_task(self, description, total=None):
            progress_updates.append(("task", description, total))
            return 1

        def update(self, task_id, advance=0, description=""):
            progress_updates.append(("update", task_id, advance, description))

    monkeypatch.setattr(cli_module, "Progress", FakeProgress)
    monkeypatch.setattr(cli_module.sys.stderr, "isatty", lambda: True)

    exit_code = main([str(root), "--format", "prompt"])
    captured = capsys.readouterr()

    assert exit_code == 0
    assert "[dir] demo/" in captured.out
    assert any(event[0] == "update" for event in progress_updates)


def test_cli_can_compare_with_explicit_snapshot(capsys, tmp_path):
    root = create_project(tmp_path)
    snapshot_path = tmp_path / "baseline.json"
    baseline = scan_tree(root, include_fingerprints=True)
    save_snapshot(snapshot_path, root, baseline)

    (root / "notes.md").unlink()

    exit_code = main([str(root), "--compare-with", str(snapshot_path), "--format", "prompt"])
    captured = capsys.readouterr()

    assert exit_code == 0
    assert "- [doc] notes.md" in captured.out


def test_cli_can_update_snapshot_after_diff(capsys, monkeypatch, tmp_path):
    root = create_project(tmp_path)
    snapshot_dir = tmp_path / "snapshots"
    monkeypatch.setenv("TRLS_SNAPSHOT_DIR", str(snapshot_dir))

    main([str(root), "--format", "prompt"])
    capsys.readouterr()

    (root / "notes.md").write_text("updated\n", encoding="utf-8")

    main([str(root), "--diff-last", "--update-snapshot", "--format", "prompt"])
    first_diff = capsys.readouterr()
    assert "~ [doc] notes.md" in first_diff.out

    exit_code = main([str(root), "--diff-last", "--format", "prompt"])
    second_diff = capsys.readouterr()

    assert exit_code == 0
    assert "~ [doc] notes.md" not in second_diff.out


def test_cli_diff_last_first_run_creates_baseline_without_error(capsys, monkeypatch, tmp_path):
    root = create_project(tmp_path)
    snapshot_dir = tmp_path / "snapshots"
    monkeypatch.setenv("TRLS_SNAPSHOT_DIR", str(snapshot_dir))

    exit_code = main([str(root), "--diff-last", "--format", "prompt"])
    captured = capsys.readouterr()

    assert exit_code == 0
    assert "[dir] demo/" in captured.out
    assert "~ " not in captured.out
    assert "+ " not in captured.out
    assert "- " not in captured.out
    assert any(snapshot_dir.iterdir())


def test_copy_text_uses_clip_exe_in_wsl(monkeypatch):
    calls = []

    monkeypatch.setattr(clipboard_module, "_is_wsl", lambda: True)
    monkeypatch.setattr(clipboard_module.platform, "system", lambda: "Linux")
    monkeypatch.setattr(
        clipboard_module,
        "_resolve_command",
        lambda name: "clip.exe" if name == "clip.exe" else None,
    )
    monkeypatch.setattr(clipboard_module, "_resolve_windows_clip_path", lambda: None)
    monkeypatch.setattr(
        clipboard_module.subprocess,
        "run",
        lambda command, input, text, check, capture_output: calls.append((command, input)),
    )

    clipboard_module.copy_text("hello")

    assert calls[0][0] == ["clip.exe"]
    assert calls[0][1] == "hello"


def test_copy_text_reports_install_hint_when_no_backend_exists(monkeypatch):
    monkeypatch.delenv("WSL_DISTRO_NAME", raising=False)
    monkeypatch.setattr(clipboard_module.platform, "system", lambda: "Linux")
    monkeypatch.setattr(clipboard_module, "_is_wsl", lambda: False)
    monkeypatch.setattr(clipboard_module, "_resolve_command", lambda name: None)
    monkeypatch.setattr(clipboard_module, "_resolve_windows_clip_path", lambda: None)

    with pytest.raises(RuntimeError) as exc_info:
        clipboard_module.copy_text("hello")

    assert "install wl-clipboard, xclip, or xsel" in str(exc_info.value)
