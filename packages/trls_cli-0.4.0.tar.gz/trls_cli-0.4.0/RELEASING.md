# Releasing `trls`

This repository is prepared for a CLI-first PyPI release.

## Current release assumptions

- distribution name: `trls-cli`
- import package: `trls`
- version: `0.4.0`
- release channel: TestPyPI first, then PyPI

At the time of preparation, `https://pypi.org/project/trls-cli/` should be re-checked right before uploading.

## 1. Prepare the repository metadata

Before publishing, create the public GitHub repository and then add the real URLs back into `pyproject.toml` if you want them shown on PyPI.

Recommended URLs to add:

- homepage: `https://github.com/<owner>/trls`
- repository: `https://github.com/<owner>/trls`
- issues: `https://github.com/<owner>/trls/issues`

## 2. Test locally

On Windows PowerShell:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -e ".[dev]"
pytest
python -m build
python -m twine check dist/*
```

On macOS or Linux:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -e ".[dev]"
pytest
python -m build
python -m twine check dist/*
```

## 3. Publish to TestPyPI

Create a TestPyPI account, then upload manually:

```bash
python -m twine upload --repository testpypi dist/*
```

Verify the release in a clean environment:

```bash
pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple trls-cli
trls --version
trls . --format markdown
```

## 4. Configure Trusted Publishing

In both PyPI and TestPyPI:

1. Create the project if it does not exist yet.
2. Open the publishing settings.
3. Add your GitHub repository.
4. Register the workflow file `.github/workflows/publish.yml`.

The workflow already expects the `pypi` environment in GitHub Actions.

## 5. Release from a Git tag

After Trusted Publishing is configured:

```bash
git tag v0.4.0
git push origin v0.4.0
```

The GitHub Actions workflow will:

- install the package with dev dependencies
- run the test suite
- build wheel and source distributions
- publish to PyPI for version tags

## First release checklist

1. Confirm `trls-cli` is still available on PyPI.
2. Create the public GitHub repository.
3. Add the real repository URLs to `pyproject.toml`.
4. Ensure README examples still match current CLI behavior.
5. Upload to TestPyPI and validate installation.
6. Push the `v0.4.0` tag to trigger the production release.
