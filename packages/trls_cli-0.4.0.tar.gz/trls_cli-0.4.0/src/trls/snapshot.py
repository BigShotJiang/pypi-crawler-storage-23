from __future__ import annotations

import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path

from trls.tree import TreeNode

SNAPSHOT_VERSION = 1
SNAPSHOT_DIR_ENV = "TRLS_SNAPSHOT_DIR"


def default_snapshot_path(root: str | Path) -> Path:
    root_path = Path(root).expanduser().resolve()
    normalized_root = root_path.as_posix().lower()
    key = hashlib.sha256(normalized_root.encode("utf-8")).hexdigest()[:16]
    return snapshot_storage_dir() / f"{key}.json"


def snapshot_storage_dir() -> Path:
    configured_dir = os.environ.get(SNAPSHOT_DIR_ENV)
    if configured_dir:
        return Path(configured_dir).expanduser().resolve()
    return Path.home() / ".trls" / "snapshots"


def save_snapshot(snapshot_path: str | Path, root: str | Path, tree: TreeNode) -> Path:
    destination = Path(snapshot_path).expanduser().resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    root_path = Path(root).expanduser().resolve()
    payload = {
        "snapshot_version": SNAPSHOT_VERSION,
        "root_path": str(root_path),
        "created_at": datetime.now(timezone.utc).isoformat(),
        "tree": tree.to_dict(include_fingerprint=True),
    }
    destination.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    return destination


def save_last_snapshot(root: str | Path, tree: TreeNode) -> Path:
    return save_snapshot(default_snapshot_path(root), root, tree)


def load_snapshot(snapshot_path: str | Path) -> TreeNode:
    path = Path(snapshot_path).expanduser().resolve()
    payload = json.loads(path.read_text(encoding="utf-8"))
    return TreeNode.from_dict(payload["tree"])


def load_last_snapshot(root: str | Path) -> TreeNode:
    snapshot_path = default_snapshot_path(root)
    if not snapshot_path.exists():
        raise FileNotFoundError(
            f"No saved snapshot for {Path(root).expanduser().resolve()}. "
            "Run trls with --save-snapshot first."
        )
    return load_snapshot(snapshot_path)
