from __future__ import annotations

import os
import platform
import shutil
import subprocess
from pathlib import Path


def copy_text(text: str) -> None:
    backends = _clipboard_backends()
    if not backends:
        raise RuntimeError(
            "No supported clipboard command was found. "
            "On Linux/WSL, install wl-clipboard, xclip, or xsel."
        )

    errors: list[str] = []
    for backend_name, command in backends:
        try:
            _run_clipboard_command(command, text)
            return
        except RuntimeError as exc:
            errors.append(f"{backend_name}: {exc}")

    attempted_names = ", ".join(name for name, _ in backends)
    error_details = "; ".join(errors)
    raise RuntimeError(
        f"No clipboard backend succeeded. Tried: {attempted_names}. {error_details}"
    )


def _clipboard_backends() -> list[tuple[str, list[str]]]:
    system = platform.system()
    backends: list[tuple[str, list[str]]] = []

    if system == "Windows":
        command = _resolve_command("clip")
        if command:
            backends.append(("clip", [command]))
        return backends

    if system == "Darwin":
        command = _resolve_command("pbcopy")
        if command:
            backends.append(("pbcopy", [command]))
        return backends

    if _is_wsl():
        clip_exe = _resolve_command("clip.exe") or _resolve_windows_clip_path()
        if clip_exe:
            backends.append(("clip.exe", [clip_exe]))
        powershell_exe = _resolve_command("powershell.exe")
        if powershell_exe:
            backends.append(
                (
                    "powershell.exe Set-Clipboard",
                    [powershell_exe, "-NoProfile", "-Command", "Set-Clipboard"],
                )
            )

    wl_copy = _resolve_command("wl-copy")
    if wl_copy:
        backends.append(("wl-copy", [wl_copy]))

    xclip = _resolve_command("xclip")
    if xclip:
        backends.append(("xclip", [xclip, "-selection", "clipboard"]))

    xsel = _resolve_command("xsel")
    if xsel:
        backends.append(("xsel", [xsel, "--clipboard", "--input"]))

    return backends


def _resolve_command(name: str) -> str | None:
    return shutil.which(name)


def _resolve_windows_clip_path() -> str | None:
    candidate = Path("/mnt/c/Windows/System32/clip.exe")
    return str(candidate) if candidate.exists() else None


def _is_wsl() -> bool:
    if os.environ.get("WSL_DISTRO_NAME"):
        return True
    try:
        return "microsoft" in Path("/proc/version").read_text(encoding="utf-8").lower()
    except OSError:
        return False


def _run_clipboard_command(command: list[str], text: str) -> None:
    try:
        subprocess.run(
            command,
            input=text,
            text=True,
            check=True,
            capture_output=True,
        )
    except FileNotFoundError as exc:
        raise RuntimeError(f"Clipboard command not found: {command[0]}") from exc
    except subprocess.CalledProcessError as exc:
        stderr = exc.stderr.strip() if exc.stderr else "unknown clipboard error"
        raise RuntimeError(f"Clipboard command failed: {stderr}") from exc
