from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from fnmatch import fnmatch
from pathlib import Path
from typing import Any, Callable, Literal

DEFAULT_IGNORE_PATTERNS = (".venv", "dist", "__pycache__")
DiffStatus = Literal["added", "removed", "modified", "unchanged"]


@dataclass
class TreeNode:
    name: str
    path: str
    kind: str
    children: list["TreeNode"] = field(default_factory=list)
    error: str | None = None
    size: int | None = None
    sha256: str | None = None
    diff_status: DiffStatus | None = None

    @property
    def is_dir(self) -> bool:
        return self.kind == "directory"

    @property
    def display_name(self) -> str:
        return f"{self.name}/" if self.is_dir else self.name

    def to_dict(self, *, include_fingerprint: bool = False) -> dict[str, object]:
        payload: dict[str, object] = {
            "name": self.name,
            "path": self.path,
            "kind": self.kind,
        }
        if self.error:
            payload["error"] = self.error
        if self.diff_status:
            payload["diff_status"] = self.diff_status
        if include_fingerprint and not self.is_dir:
            if self.size is not None:
                payload["size"] = self.size
            if self.sha256 is not None:
                payload["sha256"] = self.sha256
        if self.children:
            payload["children"] = [
                child.to_dict(include_fingerprint=include_fingerprint)
                for child in self.children
            ]
        return payload

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "TreeNode":
        return cls(
            name=payload["name"],
            path=payload["path"],
            kind=payload["kind"],
            children=[cls.from_dict(child) for child in payload.get("children", [])],
            error=payload.get("error"),
            size=payload.get("size"),
            sha256=payload.get("sha256"),
            diff_status=payload.get("diff_status"),
        )


def scan_tree(
    root: str | Path = ".",
    *,
    max_depth: int | None = None,
    show_hidden: bool = False,
    ignore_patterns: list[str] | None = None,
    include_fingerprints: bool = False,
    on_visit: Callable[[Path], None] | None = None,
) -> TreeNode:
    root_path = Path(root).expanduser().resolve()
    if not root_path.exists():
        raise FileNotFoundError(f"Path does not exist: {root}")

    patterns = (*DEFAULT_IGNORE_PATTERNS, *(ignore_patterns or []))
    return _scan_path(
        path=root_path,
        root=root_path,
        depth=0,
        max_depth=max_depth,
        show_hidden=show_hidden,
        ignore_patterns=patterns,
        include_fingerprints=include_fingerprints,
        on_visit=on_visit,
    )


def _scan_path(
    *,
    path: Path,
    root: Path,
    depth: int,
    max_depth: int | None,
    show_hidden: bool,
    ignore_patterns: tuple[str, ...],
    include_fingerprints: bool,
    on_visit: Callable[[Path], None] | None,
) -> TreeNode:
    kind = "directory" if path.is_dir() else "file"
    node = TreeNode(name=path.name or str(path), path=str(path), kind=kind)
    if on_visit:
        on_visit(path)

    if not path.is_dir():
        if include_fingerprints:
            node.size = path.stat().st_size
            node.sha256 = _sha256_for_file(path)
        return node

    if max_depth is not None and depth >= max_depth:
        return node

    try:
        entries = sorted(
            path.iterdir(),
            key=lambda item: (not item.is_dir(), item.name.lower()),
        )
    except OSError as exc:
        node.error = str(exc)
        return node

    for entry in entries:
        if not show_hidden and _is_hidden(entry):
            continue

        relative_path = entry.relative_to(root).as_posix()
        if _matches_ignore(entry.name, relative_path, ignore_patterns):
            continue

        node.children.append(
            _scan_path(
                path=entry,
                root=root,
                depth=depth + 1,
                max_depth=max_depth,
                show_hidden=show_hidden,
                ignore_patterns=ignore_patterns,
                include_fingerprints=include_fingerprints,
                on_visit=on_visit,
            )
        )

    return node


def _is_hidden(path: Path) -> bool:
    return path.name.startswith(".")


def _matches_ignore(name: str, relative_path: str, patterns: tuple[str, ...]) -> bool:
    return any(
        fnmatch(name, pattern) or fnmatch(relative_path, pattern)
        for pattern in patterns
    )


def diff_trees(current: TreeNode, previous: TreeNode) -> TreeNode:
    if current.kind != previous.kind:
        node = _clone_tree(current)
        node.diff_status = "modified"
        if node.is_dir:
            node.children = [_mark_tree(child, "added") for child in node.children]
        return node

    if not current.is_dir:
        node = _clone_tree(current)
        node.diff_status = (
            "unchanged"
            if current.sha256 == previous.sha256 and current.size == previous.size
            else "modified"
        )
        return node

    previous_by_name = {child.name: child for child in previous.children}
    current_by_name = {child.name: child for child in current.children}
    merged_children: list[TreeNode] = []

    for name in sorted(set(previous_by_name) | set(current_by_name), key=str.lower):
        current_child = current_by_name.get(name)
        previous_child = previous_by_name.get(name)

        if current_child and previous_child:
            merged_children.append(diff_trees(current_child, previous_child))
        elif current_child:
            merged_children.append(_mark_tree(current_child, "added"))
        elif previous_child:
            merged_children.append(_mark_tree(previous_child, "removed"))

    merged_children.sort(key=lambda item: (not item.is_dir, item.name.lower()))
    node = _clone_tree(current)
    node.children = merged_children
    node.diff_status = (
        "modified"
        if any(child.diff_status != "unchanged" for child in merged_children)
        else "unchanged"
    )
    return node


def _mark_tree(node: TreeNode, status: DiffStatus) -> TreeNode:
    cloned = _clone_tree(node)
    cloned.diff_status = status
    cloned.children = [_mark_tree(child, status) for child in cloned.children]
    return cloned


def _clone_tree(node: TreeNode) -> TreeNode:
    return TreeNode(
        name=node.name,
        path=node.path,
        kind=node.kind,
        children=[_clone_tree(child) for child in node.children],
        error=node.error,
        size=node.size,
        sha256=node.sha256,
        diff_status=node.diff_status,
    )


def _sha256_for_file(path: Path) -> str:
    hasher = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(8192):
            hasher.update(chunk)
    return hasher.hexdigest()
