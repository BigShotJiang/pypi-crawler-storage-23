from __future__ import annotations

import json
from pathlib import Path

from rich.text import Text
from rich.tree import Tree as RichTree

from trls.tree import TreeNode

DIRECTORY_STYLE = "bold cyan"
DEFAULT_FILE_STYLE = "white"

FILE_STYLES = {
    ".py": "green",
    ".md": "magenta",
    ".rst": "magenta",
    ".txt": "white",
    ".csv": "bright_yellow",
    ".toml": "yellow",
    ".yaml": "yellow",
    ".yml": "yellow",
    ".json": "yellow",
    ".ini": "yellow",
    ".cfg": "yellow",
    ".lock": "yellow",
    ".jpg": "bright_magenta",
    ".jpeg": "bright_magenta",
    ".png": "bright_magenta",
    ".gif": "bright_magenta",
    ".webp": "bright_magenta",
    ".svg": "bright_magenta",
    ".mp4": "bright_cyan",
    ".mov": "bright_cyan",
    ".mkv": "bright_cyan",
    ".avi": "bright_cyan",
    ".mp3": "bright_blue",
    ".wav": "bright_blue",
    ".flac": "bright_blue",
    ".xlsx": "bright_green",
    ".xls": "bright_green",
    ".docx": "bright_white",
    ".pptx": "bright_red",
    ".parquet": "bright_yellow",
    ".ipynb": "bright_yellow",
    ".sh": "bright_green",
    ".ps1": "bright_green",
    ".bat": "bright_green",
    ".exe": "bright_red",
    ".whl": "bright_red",
    ".tar": "bright_red",
    ".gz": "bright_red",
    ".zip": "bright_red",
}

SPECIAL_FILE_STYLES = {
    "license": "bright_white",
    "readme.md": "bright_magenta",
    "pyproject.toml": "bright_yellow",
}
DIFF_MARKERS = {
    "added": "+ ",
    "removed": "- ",
    "modified": "~ ",
    "unchanged": "",
    None: "",
}
DIFF_STYLES = {
    "added": "green",
    "removed": "red",
    "modified": "yellow",
    "unchanged": "",
    None: "",
}


def build_rich_tree(node: TreeNode) -> RichTree:
    label = _rich_label(node)
    tree = RichTree(label, guide_style="bright_black")
    for child in node.children:
        _append_rich_branch(tree, child)
    return tree


def render_text(node: TreeNode) -> str:
    lines = [f"{_diff_marker(node)}{node.display_name}"]
    lines.extend(_render_text_children(node.children, prefix=""))
    return "\n".join(lines)


def render_prompt(node: TreeNode) -> str:
    lines: list[str] = []
    _append_prompt_lines(node, lines, depth=0)
    return "\n".join(lines)


def render_compact_copy(node: TreeNode) -> str:
    lines = [node.display_name]
    grouped_entries: dict[str, list[str]] = {}

    for child in node.children:
        _collect_grouped_copy_entries(child, grouped_entries=grouped_entries, parent_dir="")

    for group_name in sorted(grouped_entries, key=lambda key: (key == "", key.lower())):
        label = "root" if group_name == "" else f"{group_name}/"
        lines.append(f"{label}: {', '.join(grouped_entries[group_name])}")

    return "\n".join(lines)


def render_markdown(node: TreeNode) -> str:
    lines: list[str] = []
    _append_markdown_lines(node, lines, depth=0)
    return "\n".join(lines)


def render_json(node: TreeNode) -> str:
    return json.dumps(node.to_dict(), indent=2)


def _append_rich_branch(branch: RichTree, node: TreeNode) -> None:
    child_branch = branch.add(_rich_label(node))
    for child in node.children:
        _append_rich_branch(child_branch, child)


def _rich_label(node: TreeNode) -> Text:
    label = Text()
    marker = _diff_marker(node)
    if marker:
        label.append(marker, style=DIFF_STYLES[node.diff_status])

    if node.is_dir:
        label.append(node.display_name, style=DIRECTORY_STYLE)
    else:
        label.append(node.name, style=_style_for_file(node.name))

    if node.error:
        label.append(f" [unreadable: {node.error}]", style="red")

    return label


def _style_for_file(name: str) -> str:
    normalized_name = name.lower()
    if normalized_name in SPECIAL_FILE_STYLES:
        return SPECIAL_FILE_STYLES[normalized_name]

    suffixes = Path(normalized_name).suffixes
    for suffix in reversed(suffixes):
        if suffix in FILE_STYLES:
            return FILE_STYLES[suffix]

    return DEFAULT_FILE_STYLE


def _append_prompt_lines(node: TreeNode, lines: list[str], depth: int) -> None:
    indent = "  " * depth
    line = f"{indent}{_diff_marker(node)}[{_prompt_tag(node)}] {node.display_name}"
    if node.error:
        line = f"{line} (unreadable: {node.error})"
    lines.append(line)

    for child in node.children:
        _append_prompt_lines(child, lines, depth + 1)


def _collect_grouped_copy_entries(
    node: TreeNode,
    *,
    grouped_entries: dict[str, list[str]],
    parent_dir: str,
) -> None:
    if node.is_dir and node.children:
        next_parent_dir = node.name if not parent_dir else f"{parent_dir}/{node.name}"
        for child in node.children:
            _collect_grouped_copy_entries(
                child,
                grouped_entries=grouped_entries,
                parent_dir=next_parent_dir,
            )
        return

    group_name = parent_dir
    entry_name = node.display_name if node.is_dir else node.name
    marker = _diff_marker(node).strip()
    if marker:
        entry_name = f"{marker}{entry_name}"
    grouped_entries.setdefault(group_name, []).append(entry_name)


def _prompt_tag(node: TreeNode) -> str:
    if node.is_dir:
        return "dir"

    normalized_name = node.name.lower()
    if normalized_name == "license":
        return "license"
    if normalized_name == "pyproject.toml":
        return "meta"
    if normalized_name == "readme.md":
        return "doc"

    suffixes = Path(normalized_name).suffixes
    for suffix in reversed(suffixes):
        if suffix == ".py":
            return "py"
        if suffix in {".md", ".rst", ".txt"}:
            return "doc"
        if suffix in {".jpg", ".jpeg", ".png", ".gif", ".webp", ".svg"}:
            return "image"
        if suffix in {".mp4", ".mov", ".mkv", ".avi"}:
            return "video"
        if suffix in {".mp3", ".wav", ".flac"}:
            return "audio"
        if suffix in {".xlsx", ".xls", ".csv"}:
            return "sheet"
        if suffix in {".docx", ".pptx"}:
            return "office"
        if suffix in {".parquet", ".ipynb"}:
            return "data"
        if suffix in {".toml", ".yaml", ".yml", ".json", ".ini", ".cfg", ".lock"}:
            return "meta"
        if suffix in {".sh", ".ps1", ".bat"}:
            return "shell"
        if suffix in {".exe", ".whl", ".tar", ".gz", ".zip"}:
            return "archive"

    return "file"


def _render_text_children(children: list[TreeNode], prefix: str) -> list[str]:
    lines: list[str] = []

    for index, child in enumerate(children):
        is_last = index == len(children) - 1
        connector = "`-- " if is_last else "|-- "
        lines.append(f"{prefix}{connector}{_diff_marker(child)}{child.display_name}")

        if child.error:
            error_prefix = "    " if is_last else "|   "
            lines.append(f"{prefix}{error_prefix}[unreadable: {child.error}]")

        child_prefix = f"{prefix}{'    ' if is_last else '|   '}"
        lines.extend(_render_text_children(child.children, child_prefix))

    return lines


def _append_markdown_lines(node: TreeNode, lines: list[str], depth: int) -> None:
    indent = "  " * depth
    marker = _diff_marker(node).strip()
    prefix = f"{marker} " if marker else ""
    line = f"{indent}- {prefix}`{node.display_name}`"
    if node.error:
        line = f"{line} _(unreadable: {node.error})_"
    lines.append(line)

    for child in node.children:
        _append_markdown_lines(child, lines, depth + 1)


def _diff_marker(node: TreeNode) -> str:
    return DIFF_MARKERS[node.diff_status]
