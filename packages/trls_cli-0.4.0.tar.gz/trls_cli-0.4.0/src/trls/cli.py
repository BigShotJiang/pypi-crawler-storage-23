from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Sequence

from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, TimeElapsedColumn

from trls import __version__
from trls.clipboard import copy_text
from trls.renderers import (
    build_rich_tree,
    render_compact_copy,
    render_json,
    render_markdown,
    render_prompt,
    render_text,
)
from trls.snapshot import load_last_snapshot, load_snapshot, save_last_snapshot
from trls.tree import DEFAULT_IGNORE_PATTERNS, diff_trees, scan_tree


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="trls",
        description="Render directory trees for humans and LLMs.",
    )
    parser.add_argument(
        "path",
        nargs="?",
        default=".",
        help="Directory to scan. Defaults to the current directory.",
    )
    parser.add_argument(
        "--depth",
        type=int,
        default=None,
        help="Maximum directory depth to include.",
    )
    parser.add_argument(
        "--hidden",
        action="store_true",
        help="Include hidden files and directories.",
    )
    parser.add_argument(
        "--ignore",
        action="append",
        default=[],
        metavar="PATTERN",
        help=(
            "Add an extra ignore name or glob pattern. Repeat for multiple "
            f"patterns. Defaults also ignore: {', '.join(DEFAULT_IGNORE_PATTERNS)}."
        ),
    )
    parser.add_argument(
        "--format",
        choices=("prompt", "rich", "text", "markdown", "json"),
        default="rich",
        help="Output format. Defaults to rich.",
    )
    parser.add_argument(
        "-diff",
        "--diff-last",
        action="store_true",
        help="Compare the current tree with the previous snapshot for this path.",
    )
    parser.add_argument(
        "-compare",
        "--compare-with",
        metavar="SNAPSHOT",
        help="Compare the current tree with an explicit snapshot file.",
    )
    parser.add_argument(
        "-save",
        "--save-snapshot",
        action="store_true",
        help="Save the current tree as the snapshot baseline for this path without diffing.",
    )
    parser.add_argument(
        "-update",
        "--update-snapshot",
        action="store_true",
        help="After diffing, replace the saved snapshot baseline with the current tree.",
    )
    parser.add_argument(
        "-c",
        "--copy",
        action="store_true",
        help="Copy a compact LLM-friendly version to the clipboard after rendering.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"trls {__version__}",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.depth is not None and args.depth < 0:
        parser.error("--depth must be greater than or equal to 0")
    if args.diff_last and args.compare_with:
        parser.error("Use either --diff-last or --compare-with, not both")
    if args.save_snapshot and (args.diff_last or args.compare_with):
        parser.error(
            "--save-snapshot cannot be combined with diff flags; use --update-snapshot "
            "after diffing instead"
        )
    if args.update_snapshot and not (args.diff_last or args.compare_with):
        parser.error("--update-snapshot requires -diff/--diff-last or -compare/--compare-with")

    root_path = Path(args.path).expanduser().resolve()
    needs_fingerprints = True

    current_tree = _scan_tree_with_progress(
        root_path=root_path,
        max_depth=args.depth,
        show_hidden=args.hidden,
        ignore_patterns=args.ignore,
        include_fingerprints=needs_fingerprints,
    )
    output_tree = current_tree

    if args.save_snapshot:
        output_tree = current_tree
    elif args.compare_with:
        try:
            output_tree = diff_trees(current_tree, load_snapshot(args.compare_with))
        except FileNotFoundError as exc:
            parser.error(str(exc))
    else:
        try:
            output_tree = diff_trees(current_tree, load_last_snapshot(root_path))
        except FileNotFoundError:
            output_tree = current_tree

    if args.format == "rich":
        Console().print(build_rich_tree(output_tree))
    elif args.format == "prompt":
        print(render_prompt(output_tree))
    elif args.format == "text":
        print(render_text(output_tree))
    elif args.format == "markdown":
        print(render_markdown(output_tree))
    else:
        print(render_json(output_tree))

    save_last_snapshot(root_path, current_tree)

    if args.copy:
        try:
            copy_text(render_compact_copy(output_tree))
        except RuntimeError as exc:
            print(f"Failed to copy to clipboard: {exc}", file=sys.stderr)
            return 1

    return 0

def _scan_tree_with_progress(
    *,
    root_path: Path,
    max_depth: int | None,
    show_hidden: bool,
    ignore_patterns: list[str],
    include_fingerprints: bool,
):
    if not sys.stderr.isatty():
        return scan_tree(
            root_path,
            max_depth=max_depth,
            show_hidden=show_hidden,
            ignore_patterns=ignore_patterns,
            include_fingerprints=include_fingerprints,
        )

    progress_console = Console(stderr=True)
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        TextColumn("{task.completed} items"),
        TimeElapsedColumn(),
        console=progress_console,
        transient=True,
    ) as progress:
        task_id = progress.add_task("Scanning...", total=None)

        def on_visit(path: Path) -> None:
            progress.update(
                task_id,
                advance=1,
                description=f"Scanning {path.name or str(path)}",
            )

        return scan_tree(
            root_path,
            max_depth=max_depth,
            show_hidden=show_hidden,
            ignore_patterns=ignore_patterns,
            include_fingerprints=include_fingerprints,
            on_visit=on_visit,
        )


if __name__ == "__main__":
    raise SystemExit(main())
