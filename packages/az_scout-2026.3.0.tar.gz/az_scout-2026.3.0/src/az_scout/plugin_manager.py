"""Plugin manager – validate, install, and uninstall az-scout plugins.

Plugins can be installed from two sources:

* **GitHub** – public repositories, pinned to a resolved commit SHA for
  reproducible builds.
* **PyPI** – standard Python packages, pinned to a specific version.

Plugins are installed into a flat ``plugin-packages`` directory via
``pip install --target``, avoiding the need for a virtual environment
(which is problematic on filesystems that do not support symlinks, such
as Azure Files / SMB).

Business logic lives here; FastAPI route handlers are thin wrappers.
"""

import importlib.metadata
import json
import logging
import os
import re
import shutil
import subprocess
import sys
import tempfile
import tomllib
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import requests

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_GITHUB_RAW_BASE = "https://raw.githubusercontent.com"
_GITHUB_API_BASE = "https://api.github.com"
_GITHUB_URL_RE = re.compile(
    r"^https://github\.com/(?P<owner>[A-Za-z0-9_.-]+)/(?P<repo>[A-Za-z0-9_.-]+)/?$"
)
_SHA_RE = re.compile(r"^[0-9a-f]{40}$")

_PYPI_API_BASE = "https://pypi.org/pypi"
# PEP 508 / PEP 625 compatible name pattern
_PYPI_PACKAGE_RE = re.compile(r"^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?$")


def _default_data_dir() -> Path:
    """Return the data directory, respecting the ``AZ_SCOUT_DATA_DIR`` env var.

    Falls back to ``~/.local/share/az-scout`` when the env var is not set,
    which is writable in both local and container (non-root user) environments.
    """
    env_override = os.environ.get("AZ_SCOUT_DATA_DIR")
    if env_override:
        return Path(env_override)
    return Path.home() / ".local" / "share" / "az-scout"


_DATA_DIR = _default_data_dir() / "plugins"
_INSTALLED_FILE = _DATA_DIR / "installed.json"
_AUDIT_FILE = _DATA_DIR / "audit.jsonl"
# Both the packages directory and the uv cache live on a local filesystem.
# Azure Files (SMB) does not support chmod / hardlinks which breaks uv copy
# and git operations.  The packages directory is ephemeral — on restart the
# reconcile loop reinstalls everything from installed.json (which stays on
# the durable volume).
_PACKAGES_DIR = Path(tempfile.gettempdir()) / "az-scout-packages"
_UV_CACHE_DIR = Path(tempfile.gettempdir()) / "az-scout-uv-cache"


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class GitHubRepo:
    owner: str
    repo: str


@dataclass
class PluginValidationResult:
    ok: bool
    owner: str
    repo: str
    repo_url: str
    ref: str
    source: str = "github"  # "github" or "pypi"
    resolved_sha: str | None = None
    distribution_name: str | None = None
    version: str | None = None  # resolved PyPI version
    entry_points: dict[str, str] = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)


@dataclass
class InstalledPluginRecord:
    distribution_name: str
    repo_url: str
    ref: str
    resolved_sha: str
    entry_points: dict[str, str]
    installed_at: str  # ISO-8601
    actor: str
    source: str = "github"  # "github" or "pypi"
    # Update-related fields (optional for backward compatibility)
    last_checked_at: str | None = None
    latest_ref: str | None = None
    latest_sha: str | None = None
    update_available: bool | None = None


# ---------------------------------------------------------------------------
# URL / ref helpers
# ---------------------------------------------------------------------------


def parse_github_repo_url(repo_url: str) -> GitHubRepo | None:
    """Parse a ``https://github.com/<owner>/<repo>`` URL.

    Returns ``None`` when the URL does not match the expected pattern.
    """
    m = _GITHUB_URL_RE.match(repo_url.strip().rstrip("/"))
    if m:
        return GitHubRepo(owner=m.group("owner"), repo=m.group("repo"))
    return None


def is_commit_sha(ref: str) -> bool:
    """Return ``True`` if *ref* looks like a 40-hex-char commit SHA."""
    return bool(_SHA_RE.match(ref))


def is_pypi_source(source: str) -> bool:
    """Return ``True`` when *source* is a PyPI package name (not a URL)."""
    return not source.startswith("http") and bool(_PYPI_PACKAGE_RE.match(source.strip()))


# ---------------------------------------------------------------------------
# GitHub helpers
# ---------------------------------------------------------------------------


def fetch_raw_file(owner: str, repo: str, ref: str, path: str) -> str:
    """Fetch a raw file from a GitHub repository at the given *ref*."""
    url = f"{_GITHUB_RAW_BASE}/{owner}/{repo}/{ref}/{path}"
    resp = requests.get(url, timeout=15)
    resp.raise_for_status()
    return resp.text


def resolve_ref_to_sha(owner: str, repo: str, ref: str) -> str:
    """Resolve a tag or branch ref to its underlying commit SHA.

    If *ref* is already a 40-char hex SHA it is returned as-is.
    For tags, annotated tags are followed until a commit object is found.
    """
    if is_commit_sha(ref):
        return ref

    # Try tag first
    url = f"{_GITHUB_API_BASE}/repos/{owner}/{repo}/git/ref/tags/{ref}"
    resp = requests.get(url, timeout=15)

    if resp.status_code == 404:
        # Fallback: try as a branch (heads)
        url = f"{_GITHUB_API_BASE}/repos/{owner}/{repo}/git/ref/heads/{ref}"
        resp = requests.get(url, timeout=15)

    resp.raise_for_status()
    data: dict[str, Any] = resp.json()
    obj = data.get("object", {})
    sha: str = obj.get("sha", "")
    obj_type: str = obj.get("type", "")

    # Follow annotated tag → commit
    while obj_type == "tag":
        tag_url: str = obj.get("url", "")
        if not tag_url:
            break
        tag_resp = requests.get(tag_url, timeout=15)
        tag_resp.raise_for_status()
        tag_data: dict[str, Any] = tag_resp.json()
        obj = tag_data.get("object", {})
        sha = obj.get("sha", "")
        obj_type = obj.get("type", "")

    if not sha:
        msg = f"Could not resolve ref '{ref}' to a commit SHA"
        raise ValueError(msg)
    return sha


# ---------------------------------------------------------------------------
# pyproject.toml parsing & validation
# ---------------------------------------------------------------------------


def parse_pyproject_toml(toml_text: str) -> dict[str, Any]:
    """Parse a TOML string and return the resulting dict."""
    return tomllib.loads(toml_text)


def validate_plugin_repo(repo_url: str, ref: str = "") -> PluginValidationResult:
    """Validate that a GitHub repository is a conforming az-scout plugin.

    When *ref* is empty the latest release or tag is resolved automatically.
    This fetches and inspects ``pyproject.toml`` without executing any code.
    """
    gh = parse_github_repo_url(repo_url)
    if gh is None:
        return PluginValidationResult(
            ok=False,
            owner="",
            repo="",
            repo_url=repo_url,
            ref=ref,
            errors=["Invalid GitHub URL. Expected https://github.com/<owner>/<repo>"],
        )

    # Auto-resolve to latest when no ref is provided
    if not ref:
        try:
            ref, _ = fetch_latest_ref(gh.owner, gh.repo)
        except Exception as exc:
            return PluginValidationResult(
                ok=False,
                owner=gh.owner,
                repo=gh.repo,
                repo_url=repo_url,
                ref="",
                errors=[f"Cannot determine latest version: {exc}"],
            )

    result = PluginValidationResult(
        ok=False,
        owner=gh.owner,
        repo=gh.repo,
        repo_url=repo_url,
        ref=ref,
    )

    # Resolve ref → SHA
    try:
        result.resolved_sha = resolve_ref_to_sha(gh.owner, gh.repo, ref)
    except Exception as exc:
        result.errors.append(f"Cannot resolve ref '{ref}': {exc}")
        return result

    # Fetch pyproject.toml
    try:
        toml_text = fetch_raw_file(gh.owner, gh.repo, result.resolved_sha, "pyproject.toml")
    except requests.HTTPError as exc:
        result.errors.append(f"Cannot fetch pyproject.toml: {exc}")
        return result

    # Parse
    try:
        data = parse_pyproject_toml(toml_text)
    except Exception as exc:
        result.errors.append(f"Invalid pyproject.toml: {exc}")
        return result

    project = data.get("project", {})

    # distribution name
    dist_name = project.get("name")
    if not dist_name:
        result.errors.append("Missing project.name in pyproject.toml")
    else:
        result.distribution_name = str(dist_name)

    # entry points
    eps = project.get("entry-points", {}).get("az_scout.plugins", {})
    if not eps:
        result.errors.append('No [project.entry-points."az_scout.plugins"] section found')
    else:
        for key, value in eps.items():
            val = str(value)
            if ":" not in val:
                result.errors.append(
                    f"Entry point '{key}' must use 'module:object' format, got '{val}'"
                )
            else:
                result.entry_points[str(key)] = val

    # dependencies – check az-scout is listed
    deps = [str(d).lower() for d in project.get("dependencies", [])]
    dep_names = [re.split(r"[<>=!~\[;@ ]", d)[0].strip() for d in deps]
    if "az-scout" not in dep_names:
        result.warnings.append(
            "project.dependencies does not include 'az-scout' – plugin may fail at runtime"
        )

    # requires-python
    req_python = project.get("requires-python", "")
    if req_python:
        if "3.11" not in str(req_python) and "3.1" not in str(req_python):
            result.warnings.append(
                f"requires-python '{req_python}' may not be compatible with >=3.11"
            )
    else:
        result.warnings.append("No requires-python specified")

    if not result.errors:
        result.ok = True

    return result


# ---------------------------------------------------------------------------
# Package management (--target approach)
# ---------------------------------------------------------------------------


def _find_uv() -> str | None:
    """Return the path to the ``uv`` executable, or ``None`` if not found."""
    return shutil.which("uv")


def _pip_env() -> dict[str, str]:
    """Return an environment dict for pip/uv subprocess calls."""
    env = os.environ.copy()
    env["UV_CACHE_DIR"] = str(_UV_CACHE_DIR)
    env["UV_LINK_MODE"] = "copy"
    return env


def run_pip(args: list[str]) -> subprocess.CompletedProcess[str]:
    """Run a ``pip`` command that installs/uninstalls into the plugin packages dir.

    Uses ``uv pip`` when available, otherwise falls back to ``python -m pip``.
    The ``--target`` flag is automatically appended for ``install`` commands.
    For ``uninstall``, ``--target`` is used with ``uv``, while stdlib ``pip``
    uses ``-y`` for non-interactive mode.

    *args* follow the ``["pip", "<sub-command>", ...]`` convention
    (the leading ``"pip"`` element is consumed by this function).
    """
    _PACKAGES_DIR.mkdir(parents=True, exist_ok=True)
    env = _pip_env()
    uv = _find_uv()
    sub_args = list(args[1:])  # drop leading "pip"

    if uv:
        cmd: list[str] = [uv, "pip", *sub_args, "--target", str(_PACKAGES_DIR)]
    else:
        # Fall back to python -m pip
        if sub_args and sub_args[0] == "uninstall" and "-y" not in sub_args:
            sub_args.insert(1, "-y")
        cmd = [sys.executable, "-m", "pip", *sub_args, "--target", str(_PACKAGES_DIR)]

    logger.info("Running plugin pip: %s", " ".join(cmd))
    return subprocess.run(  # noqa: S603
        cmd,
        capture_output=True,
        text=True,
        env=env,
        check=False,
    )


# ---------------------------------------------------------------------------
# Persistence
# ---------------------------------------------------------------------------


def _ensure_data_dir() -> None:
    _DATA_DIR.mkdir(parents=True, exist_ok=True)


def _record_from_dict(data: dict[str, Any]) -> InstalledPluginRecord:
    """Create an ``InstalledPluginRecord`` from a dict, tolerating missing fields."""
    known_fields = {
        "distribution_name",
        "repo_url",
        "ref",
        "resolved_sha",
        "entry_points",
        "installed_at",
        "actor",
        "source",
        "last_checked_at",
        "latest_ref",
        "latest_sha",
        "update_available",
    }
    filtered = {k: v for k, v in data.items() if k in known_fields}
    return InstalledPluginRecord(**filtered)


def load_installed() -> list[InstalledPluginRecord]:
    """Load the list of UI-installed plugins from ``installed.json``."""
    if not _INSTALLED_FILE.exists():
        return []
    try:
        raw = json.loads(_INSTALLED_FILE.read_text(encoding="utf-8"))
        return [_record_from_dict(r) for r in raw]
    except Exception:
        logger.exception("Failed to read %s", _INSTALLED_FILE)
        return []


def save_installed(records: list[InstalledPluginRecord]) -> None:
    """Atomically write the installed plugins list."""
    _ensure_data_dir()
    data = [asdict(r) for r in records]
    fd, tmp_path = tempfile.mkstemp(dir=str(_DATA_DIR), prefix=".installed-", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        Path(tmp_path).replace(_INSTALLED_FILE)
    except Exception:
        Path(tmp_path).unlink(missing_ok=True)
        raise


def append_audit(event: dict[str, Any]) -> None:
    """Append an audit entry to the JSONL audit log."""
    _ensure_data_dir()
    event["timestamp"] = datetime.now(UTC).isoformat()
    with _AUDIT_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps(event, default=str) + "\n")


# ---------------------------------------------------------------------------
# Install / Uninstall operations
# ---------------------------------------------------------------------------


def install_plugin(
    repo_url: str,
    ref: str,
    actor: str,
    client_ip: str,
    user_agent: str,
) -> tuple[bool, list[str], list[str]]:
    """Validate and install a plugin from a GitHub repository.

    Returns ``(ok, warnings, errors)``.
    """
    validation = validate_plugin_repo(repo_url, ref)
    if not validation.ok:
        _audit_event(
            "install",
            actor,
            client_ip,
            user_agent,
            repo_url=repo_url,
            ref=ref,
            resolved_sha=validation.resolved_sha,
            distribution_name=validation.distribution_name,
            success=False,
            detail="; ".join(validation.errors),
        )
        return False, validation.warnings, validation.errors

    # Use the ref resolved by validation (may differ from input when auto-resolved)
    resolved_ref = validation.ref
    sha = validation.resolved_sha or resolved_ref
    clean_url = repo_url.rstrip("/")
    if not clean_url.endswith(".git"):
        clean_url += ".git"
    git_url = f"git+{clean_url}@{sha}"

    result = run_pip(["pip", "install", git_url])
    if result.returncode != 0:
        err_msg = f"pip install failed: {result.stderr.strip()}"
        validation.errors.append(err_msg)
        _audit_event(
            "install",
            actor,
            client_ip,
            user_agent,
            repo_url=repo_url,
            ref=resolved_ref,
            resolved_sha=sha,
            distribution_name=validation.distribution_name,
            success=False,
            detail=err_msg,
        )
        return False, validation.warnings, validation.errors

    # Update installed.json
    records = load_installed()
    dist_name = validation.distribution_name or ""
    # Remove previous entry for the same distribution (upgrade scenario)
    records = [r for r in records if r.distribution_name != dist_name]
    records.append(
        InstalledPluginRecord(
            distribution_name=dist_name,
            repo_url=repo_url,
            ref=resolved_ref,
            resolved_sha=sha,
            entry_points=validation.entry_points,
            installed_at=datetime.now(UTC).isoformat(),
            actor=actor,
        )
    )
    save_installed(records)

    _audit_event(
        "install",
        actor,
        client_ip,
        user_agent,
        repo_url=repo_url,
        ref=resolved_ref,
        resolved_sha=sha,
        distribution_name=dist_name,
        success=True,
        detail="installed successfully",
    )

    return True, validation.warnings, []


# ---------------------------------------------------------------------------
# GitHub latest-version helpers
# ---------------------------------------------------------------------------


def fetch_latest_ref(owner: str, repo: str) -> tuple[str, str]:
    """Determine the latest version ref and its resolved commit SHA.

    Strategy:
      1. Try ``GET /repos/{owner}/{repo}/releases/latest`` → ``tag_name``.
      2. If no release, try ``GET /repos/{owner}/{repo}/tags?per_page=1``.
      3. Resolve the ref → 40-char commit SHA.

    Returns ``(latest_ref, latest_sha)``.
    Raises ``ValueError`` when no release or tag is found.
    """
    # 1. Try latest release
    release_url = f"{_GITHUB_API_BASE}/repos/{owner}/{repo}/releases/latest"
    release_resp = requests.get(release_url, timeout=15)
    if release_resp.status_code == 200:
        tag_name: str = release_resp.json().get("tag_name", "")
        if tag_name:
            sha = resolve_ref_to_sha(owner, repo, tag_name)
            return tag_name, sha

    # 2. Fallback to latest tag
    tags_url = f"{_GITHUB_API_BASE}/repos/{owner}/{repo}/tags?per_page=1"
    tags_resp = requests.get(tags_url, timeout=15)
    if tags_resp.status_code == 200:
        tags: list[dict[str, Any]] = tags_resp.json()
        if tags:
            tag_name = tags[0].get("name", "")
            if tag_name:
                sha = resolve_ref_to_sha(owner, repo, tag_name)
                return tag_name, sha

    msg = f"No releases or tags found for {owner}/{repo}"
    raise ValueError(msg)


# ---------------------------------------------------------------------------
# PyPI helpers
# ---------------------------------------------------------------------------


def fetch_pypi_metadata(
    package_name: str,
    version: str = "",
) -> dict[str, Any]:
    """Fetch package metadata from the PyPI JSON API.

    When *version* is given, fetches that specific release.
    Otherwise fetches the latest release.

    Raises ``requests.HTTPError`` on network / 404 errors.
    """
    if version:
        url = f"{_PYPI_API_BASE}/{package_name}/{version}/json"
    else:
        url = f"{_PYPI_API_BASE}/{package_name}/json"
    resp = requests.get(url, timeout=15)
    resp.raise_for_status()
    data: dict[str, Any] = resp.json()
    return data


def validate_pypi_plugin(
    package_name: str,
    version: str = "",
) -> PluginValidationResult:
    """Validate that a PyPI package is a conforming az-scout plugin.

    Checks:
    - Package exists on PyPI
    - Version exists (if specified)
    - Naming convention ``az-scout-*`` (warning if not followed)
    - ``az-scout`` listed as a dependency (warning if absent)
    """
    result = PluginValidationResult(
        ok=False,
        owner="",
        repo="",
        repo_url="",
        ref=version,
        source="pypi",
        distribution_name=package_name,
    )

    # Validate package name format
    if not _PYPI_PACKAGE_RE.match(package_name):
        result.errors.append(
            f"Invalid package name '{package_name}'. "
            "Must contain only letters, digits, '.', '-', or '_'."
        )
        return result

    # Fetch metadata from PyPI
    try:
        data = fetch_pypi_metadata(package_name, version)
    except requests.HTTPError as exc:
        if exc.response is not None and exc.response.status_code == 404:
            if version:
                result.errors.append(
                    f"Version '{version}' of package '{package_name}' not found on PyPI"
                )
            else:
                result.errors.append(f"Package '{package_name}' not found on PyPI")
        else:
            result.errors.append(f"PyPI API error: {exc}")
        return result
    except Exception as exc:
        result.errors.append(f"Cannot reach PyPI: {exc}")
        return result

    info: dict[str, Any] = data.get("info", {})
    resolved_version: str = info.get("version", version)
    result.ref = resolved_version
    result.version = resolved_version

    # Naming convention warning
    normalized_name = package_name.lower().replace("_", "-").replace(".", "-")
    if not normalized_name.startswith("az-scout-"):
        result.warnings.append(
            f"Package '{package_name}' does not follow the 'az-scout-*' naming convention"
        )

    # Check dependencies for az-scout
    requires_dist: list[str] = info.get("requires_dist") or []
    dep_names = [re.split(r"[<>=!~\[;@ ]", d)[0].strip().lower() for d in requires_dist]
    if "az-scout" not in dep_names:
        result.warnings.append(
            "Package dependencies do not include 'az-scout' — plugin may fail at runtime"
        )

    # Check project URLs for homepage
    project_urls: dict[str, str] = info.get("project_urls") or {}
    if project_urls:
        homepage = project_urls.get("Homepage", "")
        if homepage:
            result.repo_url = homepage

    if not result.errors:
        result.ok = True

    return result


def install_pypi_plugin(
    package_name: str,
    version: str,
    actor: str,
    client_ip: str,
    user_agent: str,
) -> tuple[bool, list[str], list[str]]:
    """Validate and install a plugin from PyPI.

    Returns ``(ok, warnings, errors)``.
    """
    validation = validate_pypi_plugin(package_name, version)
    if not validation.ok:
        _audit_event(
            "install",
            actor,
            client_ip,
            user_agent,
            distribution_name=package_name,
            ref=version,
            success=False,
            detail="; ".join(validation.errors),
        )
        return False, validation.warnings, validation.errors

    resolved_version = validation.version or validation.ref or version
    pip_spec = f"{package_name}=={resolved_version}" if resolved_version else package_name

    pip_result = run_pip(["pip", "install", pip_spec])
    if pip_result.returncode != 0:
        err_msg = f"pip install failed: {pip_result.stderr.strip()}"
        validation.errors.append(err_msg)
        _audit_event(
            "install",
            actor,
            client_ip,
            user_agent,
            distribution_name=package_name,
            ref=resolved_version,
            success=False,
            detail=err_msg,
        )
        return False, validation.warnings, validation.errors

    # Update installed.json
    records = load_installed()
    # Remove previous entry for the same distribution (upgrade scenario)
    records = [r for r in records if r.distribution_name != package_name]
    records.append(
        InstalledPluginRecord(
            distribution_name=package_name,
            repo_url=validation.repo_url,
            ref=resolved_version,
            resolved_sha="",
            entry_points=validation.entry_points,
            installed_at=datetime.now(UTC).isoformat(),
            actor=actor,
            source="pypi",
        )
    )
    save_installed(records)

    _audit_event(
        "install",
        actor,
        client_ip,
        user_agent,
        distribution_name=package_name,
        ref=resolved_version,
        success=True,
        detail="installed from PyPI",
    )

    return True, validation.warnings, []


def fetch_pypi_latest_version(package_name: str) -> str:
    """Return the latest version string for a PyPI package.

    Raises ``ValueError`` when the package is not found.
    """
    try:
        data = fetch_pypi_metadata(package_name)
    except requests.HTTPError:
        msg = f"Package '{package_name}' not found on PyPI"
        raise ValueError(msg)  # noqa: B904
    version: str = data.get("info", {}).get("version", "")
    if not version:
        msg = f"Cannot determine latest version for '{package_name}'"
        raise ValueError(msg)
    return version


# ---------------------------------------------------------------------------
# Check for updates
# ---------------------------------------------------------------------------


def check_updates(
    actor: str,
    client_ip: str,
    user_agent: str,
) -> list[dict[str, Any]]:
    """Check all installed plugins for available updates.

    Returns a list of dicts with update status per plugin.
    """
    records = load_installed()
    results: list[dict[str, Any]] = []
    now = datetime.now(UTC).isoformat()

    for record in records:
        info: dict[str, Any] = {
            "distribution_name": record.distribution_name,
            "source": record.source,
            "repo_url": record.repo_url,
            "installed_ref": record.ref,
            "resolved_sha": record.resolved_sha,
            "latest_ref": None,
            "latest_sha": None,
            "update_available": False,
            "error": None,
        }

        if record.source == "pypi":
            try:
                latest_version = fetch_pypi_latest_version(record.distribution_name)
                info["latest_ref"] = latest_version
                info["update_available"] = latest_version != record.ref

                record.last_checked_at = now
                record.latest_ref = latest_version
                record.latest_sha = None
                record.update_available = latest_version != record.ref
            except Exception as exc:
                info["error"] = str(exc)
                record.last_checked_at = now
        else:
            gh = parse_github_repo_url(record.repo_url)
            if gh is None:
                info["error"] = "Invalid GitHub URL"
                results.append(info)
                continue

            try:
                latest_ref, latest_sha = fetch_latest_ref(gh.owner, gh.repo)
                info["latest_ref"] = latest_ref
                info["latest_sha"] = latest_sha
                info["update_available"] = latest_sha != record.resolved_sha

                # Update the record in-place for persistence
                record.last_checked_at = now
                record.latest_ref = latest_ref
                record.latest_sha = latest_sha
                record.update_available = latest_sha != record.resolved_sha
            except Exception as exc:
                info["error"] = str(exc)
                record.last_checked_at = now

        results.append(info)

    # Persist updated records
    save_installed(records)

    _audit_event(
        "check_updates",
        actor,
        client_ip,
        user_agent,
        success=True,
        detail=f"Checked {len(records)} plugin(s)",
    )

    return results


# ---------------------------------------------------------------------------
# Update operations
# ---------------------------------------------------------------------------


def update_plugin(
    distribution_name: str,
    actor: str,
    client_ip: str,
    user_agent: str,
) -> tuple[bool, list[str]]:
    """Update a single plugin to the latest version.

    Supports both GitHub-sourced and PyPI-sourced plugins.

    Returns ``(ok, errors)``.
    """
    errors: list[str] = []
    records = load_installed()
    record = next((r for r in records if r.distribution_name == distribution_name), None)

    if record is None:
        errors.append(f"Plugin '{distribution_name}' not found in installed list")
        _audit_event(
            "update",
            actor,
            client_ip,
            user_agent,
            distribution_name=distribution_name,
            success=False,
            detail=errors[0],
        )
        return False, errors

    if record.source == "pypi":
        return _update_pypi_plugin(record, records, actor, client_ip, user_agent)

    return _update_github_plugin(record, records, actor, client_ip, user_agent)


def _update_github_plugin(
    record: InstalledPluginRecord,
    records: list[InstalledPluginRecord],
    actor: str,
    client_ip: str,
    user_agent: str,
) -> tuple[bool, list[str]]:
    """Update a GitHub-sourced plugin to the latest release/tag."""
    errors: list[str] = []
    distribution_name = record.distribution_name

    gh = parse_github_repo_url(record.repo_url)
    if gh is None:
        errors.append("Invalid GitHub URL in installed record")
        _audit_event(
            "update",
            actor,
            client_ip,
            user_agent,
            distribution_name=distribution_name,
            repo_url=record.repo_url,
            success=False,
            detail=errors[0],
        )
        return False, errors

    # Resolve latest version
    try:
        latest_ref, latest_sha = fetch_latest_ref(gh.owner, gh.repo)
    except Exception as exc:
        errors.append(f"Cannot determine latest version: {exc}")
        _audit_event(
            "update",
            actor,
            client_ip,
            user_agent,
            distribution_name=distribution_name,
            repo_url=record.repo_url,
            ref=record.ref,
            resolved_sha=record.resolved_sha,
            success=False,
            detail=errors[0],
        )
        return False, errors

    if latest_sha == record.resolved_sha:
        errors.append("Already up to date")
        return False, errors

    # Install the new version
    clean_url = record.repo_url.rstrip("/")
    if not clean_url.endswith(".git"):
        clean_url += ".git"
    git_url = f"git+{clean_url}@{latest_sha}"

    result = run_pip(["pip", "install", "--upgrade", git_url])
    if result.returncode != 0:
        err_msg = f"pip install --upgrade failed: {result.stderr.strip()}"
        errors.append(err_msg)
        _audit_event(
            "update",
            actor,
            client_ip,
            user_agent,
            repo_url=record.repo_url,
            ref=record.ref,
            resolved_sha=record.resolved_sha,
            distribution_name=distribution_name,
            success=False,
            detail=err_msg,
        )
        return False, errors

    # Update the record
    now = datetime.now(UTC).isoformat()
    old_ref = record.ref
    record.ref = latest_ref
    record.resolved_sha = latest_sha
    record.installed_at = now
    record.actor = actor
    record.last_checked_at = now
    record.latest_ref = latest_ref
    record.latest_sha = latest_sha
    record.update_available = False
    save_installed(records)

    _audit_event(
        "update",
        actor,
        client_ip,
        user_agent,
        repo_url=record.repo_url,
        ref=latest_ref,
        resolved_sha=latest_sha,
        distribution_name=distribution_name,
        success=True,
        detail=f"Updated from {old_ref} to {latest_ref}",
    )

    return True, []


def _update_pypi_plugin(
    record: InstalledPluginRecord,
    records: list[InstalledPluginRecord],
    actor: str,
    client_ip: str,
    user_agent: str,
) -> tuple[bool, list[str]]:
    """Update a PyPI-sourced plugin to the latest version."""
    errors: list[str] = []
    distribution_name = record.distribution_name

    try:
        latest_version = fetch_pypi_latest_version(distribution_name)
    except Exception as exc:
        errors.append(f"Cannot determine latest version: {exc}")
        _audit_event(
            "update",
            actor,
            client_ip,
            user_agent,
            distribution_name=distribution_name,
            ref=record.ref,
            success=False,
            detail=errors[0],
        )
        return False, errors

    if latest_version == record.ref:
        errors.append("Already up to date")
        return False, errors

    pip_spec = f"{distribution_name}=={latest_version}"
    result = run_pip(["pip", "install", "--upgrade", pip_spec])
    if result.returncode != 0:
        err_msg = f"pip install --upgrade failed: {result.stderr.strip()}"
        errors.append(err_msg)
        _audit_event(
            "update",
            actor,
            client_ip,
            user_agent,
            distribution_name=distribution_name,
            ref=record.ref,
            success=False,
            detail=err_msg,
        )
        return False, errors

    old_ref = record.ref
    now = datetime.now(UTC).isoformat()
    record.ref = latest_version
    record.resolved_sha = ""
    record.installed_at = now
    record.actor = actor
    record.last_checked_at = now
    record.latest_ref = latest_version
    record.latest_sha = None
    record.update_available = False
    save_installed(records)

    _audit_event(
        "update",
        actor,
        client_ip,
        user_agent,
        distribution_name=distribution_name,
        ref=latest_version,
        success=True,
        detail=f"Updated from {old_ref} to {latest_version} (PyPI)",
    )

    return True, []


def update_all_plugins(
    actor: str,
    client_ip: str,
    user_agent: str,
) -> tuple[int, int, list[dict[str, Any]]]:
    """Update all installed plugins that have available updates.

    Returns ``(updated_count, failed_count, details)``.
    """
    records = load_installed()
    updated = 0
    failed = 0
    details: list[dict[str, Any]] = []

    for record in records:
        # Determine if update is needed based on source
        if record.source == "pypi":
            try:
                latest_version = fetch_pypi_latest_version(record.distribution_name)
            except Exception as exc:
                details.append(
                    {
                        "distribution_name": record.distribution_name,
                        "ok": False,
                        "error": str(exc),
                    }
                )
                failed += 1
                continue

            if latest_version == record.ref:
                details.append(
                    {
                        "distribution_name": record.distribution_name,
                        "ok": True,
                        "skipped": True,
                        "reason": "Already up to date",
                    }
                )
                continue
            latest_ref_display = latest_version
        else:
            gh = parse_github_repo_url(record.repo_url)
            if gh is None:
                details.append(
                    {
                        "distribution_name": record.distribution_name,
                        "ok": False,
                        "error": "Invalid GitHub URL",
                    }
                )
                failed += 1
                continue

            try:
                latest_ref, latest_sha = fetch_latest_ref(gh.owner, gh.repo)
            except Exception as exc:
                details.append(
                    {
                        "distribution_name": record.distribution_name,
                        "ok": False,
                        "error": str(exc),
                    }
                )
                failed += 1
                continue

            if latest_sha == record.resolved_sha:
                details.append(
                    {
                        "distribution_name": record.distribution_name,
                        "ok": True,
                        "skipped": True,
                        "reason": "Already up to date",
                    }
                )
                continue
            latest_ref_display = latest_ref

        ok, errors = update_plugin(
            record.distribution_name,
            actor,
            client_ip,
            user_agent,
        )
        if ok:
            updated += 1
            details.append(
                {
                    "distribution_name": record.distribution_name,
                    "ok": True,
                    "updated_to": latest_ref_display,
                }
            )
        else:
            failed += 1
            details.append(
                {
                    "distribution_name": record.distribution_name,
                    "ok": False,
                    "error": "; ".join(errors),
                }
            )

    _audit_event(
        "update_all",
        actor,
        client_ip,
        user_agent,
        success=failed == 0,
        detail=f"Updated {updated}, failed {failed} of {len(records)} plugin(s)",
    )

    return updated, failed, details


def uninstall_plugin(
    distribution_name: str,
    actor: str,
    client_ip: str,
    user_agent: str,
) -> tuple[bool, list[str]]:
    """Uninstall a plugin by its distribution name.

    Returns ``(ok, errors)``.
    """
    errors: list[str] = []
    records = load_installed()
    record = next((r for r in records if r.distribution_name == distribution_name), None)

    if record is None:
        errors.append(f"Plugin '{distribution_name}' not found in installed list")
        _audit_event(
            "uninstall",
            actor,
            client_ip,
            user_agent,
            distribution_name=distribution_name,
            success=False,
            detail=errors[0],
        )
        return False, errors

    result = run_pip(["pip", "uninstall", distribution_name])
    if result.returncode != 0:
        err_msg = f"pip uninstall failed: {result.stderr.strip()}"
        errors.append(err_msg)
        _audit_event(
            "uninstall",
            actor,
            client_ip,
            user_agent,
            distribution_name=distribution_name,
            success=False,
            detail=err_msg,
        )
        return False, errors

    # Update installed.json
    records = [r for r in records if r.distribution_name != distribution_name]
    save_installed(records)

    _audit_event(
        "uninstall",
        actor,
        client_ip,
        user_agent,
        distribution_name=distribution_name,
        repo_url=record.repo_url,
        ref=record.ref,
        resolved_sha=record.resolved_sha,
        success=True,
        detail="uninstalled successfully",
    )

    return True, []


# ---------------------------------------------------------------------------
# Startup reconciliation
# ---------------------------------------------------------------------------


def _is_plugin_installed(distribution_name: str) -> bool:
    """Check whether a plugin distribution is present in the packages directory."""
    if not _PACKAGES_DIR.exists():
        return False
    str_dirs = [str(_PACKAGES_DIR)]
    for dist in importlib.metadata.distributions(path=str_dirs):
        if dist.name == distribution_name:
            return True
    return False


def reconcile_installed_plugins() -> list[dict[str, str | bool]]:
    """Re-install plugins listed in ``installed.json`` but missing from packages.

    This is the "self-healing" step called at startup.  The packages
    directory lives on the local filesystem (ephemeral) while
    ``installed.json`` is on the durable volume, so after any restart the
    packages directory is empty.  For each missing plugin the function runs
    ``pip install --target`` using the exact pinned SHA so the build is
    reproducible.

    Returns a list of per-plugin dicts with keys ``distribution_name``,
    ``reinstalled`` (bool), and ``error`` (str, empty on success).
    """
    records = load_installed()
    if not records:
        return []

    results: list[dict[str, str | bool]] = []
    for record in records:
        if _is_plugin_installed(record.distribution_name):
            logger.debug(
                "Plugin '%s' already present in packages dir — skipping",
                record.distribution_name,
            )
            results.append(
                {
                    "distribution_name": record.distribution_name,
                    "reinstalled": False,
                    "error": "",
                }
            )
            continue

        # Need to reinstall from pinned source
        if record.source == "pypi":
            pip_spec = (
                f"{record.distribution_name}=={record.ref}"
                if record.ref
                else record.distribution_name
            )
            logger.info(
                "Reconciling plugin '%s' — reinstalling from PyPI (%s)",
                record.distribution_name,
                pip_spec,
            )
            result = run_pip(["pip", "install", pip_spec])
        else:
            clean_url = record.repo_url.rstrip("/")
            if not clean_url.endswith(".git"):
                clean_url += ".git"
            git_url = f"git+{clean_url}@{record.resolved_sha}"
            logger.info(
                "Reconciling plugin '%s' — reinstalling from %s",
                record.distribution_name,
                git_url,
            )
            result = run_pip(["pip", "install", git_url])
        if result.returncode == 0:
            results.append(
                {
                    "distribution_name": record.distribution_name,
                    "reinstalled": True,
                    "error": "",
                }
            )
            logger.info("Reconciled plugin '%s' successfully", record.distribution_name)
        else:
            err = result.stderr.strip()
            results.append(
                {
                    "distribution_name": record.distribution_name,
                    "reinstalled": False,
                    "error": err,
                }
            )
            logger.error(
                "Failed to reconcile plugin '%s': %s",
                record.distribution_name,
                err,
            )

        append_audit(
            {
                "action": "reconcile",
                "distribution_name": record.distribution_name,
                "repo_url": record.repo_url,
                "resolved_sha": record.resolved_sha,
                "success": result.returncode == 0,
                "detail": "reinstalled" if result.returncode == 0 else err,
            }
        )

    reinstalled = sum(1 for r in results if r["reinstalled"])
    if reinstalled:
        logger.info("Reconciled %d plugin(s) at startup", reinstalled)
    return results


def _audit_event(
    action: str,
    actor: str,
    client_ip: str,
    user_agent: str,
    *,
    repo_url: str = "",
    ref: str = "",
    resolved_sha: str | None = None,
    distribution_name: str | None = None,
    success: bool,
    detail: str = "",
) -> None:
    append_audit(
        {
            "action": action,
            "actor": actor,
            "client_ip": client_ip,
            "user_agent": user_agent,
            "repo_url": repo_url,
            "ref": ref,
            "resolved_sha": resolved_sha,
            "distribution_name": distribution_name,
            "success": success,
            "detail": detail,
        }
    )
