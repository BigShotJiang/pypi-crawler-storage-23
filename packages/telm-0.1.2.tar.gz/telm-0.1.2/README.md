# 🛠️ DynamicToolELM

A lightweight, flexible library to transform raw LLM text outputs into structured tool calls. Optimized for Small Language Models (SLM) and fine-tuned agents.


## 📂 Project Structure
```Plaintext

|- telm.py              # Core logic & DynamicToolELM class
|- README.md            # Documentation
|- tools/               # Tool implementation modules
|   - __init__.py
|   - calculator.py
|   - datetime_utils.py
|   - weather.py
|   - websearch.py
```
## 🚀 Installation
```bash

pip install telm
```
## 💡 Concept

DynamicToolELM catches various LLM output formats and normalizes them into a clean, executable format: [action: argument]. It supports:

    (action: value)

    <action = value>

    [action : value]

    *action: value*

## 🛠️ Usage: LLM Integration (llama-cpp-python)

This example demonstrates how to use telm to intercept model responses and trigger specific functions.
```Python

from llama_cpp import Llama
from telm import DynamicToolELM

# Initialize LLM
llm = Llama(model_path="path/to/model.gguf", n_ctx=8192)


def send_picture(prompt):
    # logic to make an image
    return image_generated


# 1. Define Custom Tools
my_custom_tools = [
    {
        "name": "send_picture",
        "description": "Generate an image using Stable Diffusion",
        "parameters": {
            "type": "object",
            "properties": {"prompt": {"type": "string"}},
            "required": ["prompt"]
        }
    }
]

# 2. Initialize Managers
custom_tool_manager = DynamicToolELM(my_custom_tools)

# 3. Generate & Parse
response = llm.create_chat_completion(messages=messages, temperature=0.7)
raw_text = response["choices"][0]["message"]["content"].strip()

# Check for tool calls
custom_result = custom_manager.call_tool_elm(raw_text)

# 4. Handle Execution
if custom_result["type"] in ["tool", "multi-tool"]:
    calls = result["results"] if result["type"] == "multi-tool" else [result]
    
    for call in calls:
        func_name = call.get("function")
        arg = call["args"].get("prompt_sup")

        if func_name == "send_picture":
            print(f"🎨 Generating image for: {arg}")
            send_picture(arg)

```
### ➕ How to add New Tools

    Define it: Add a dictionary to your tools list describing the tool's name and purpose.

    Execute it: Add a simple if func_name == "your_tool": check in your main loop to link the detection to your Python function.
