from setuptools import setup, find_packages

setup(
    name="telm",
    version="0.1.2",
    py_modules=["telm"], # Indique que telm.py est à la racine
    packages=find_packages(), # Trouvera le dossier /tools/
    install_requires=[
        "requests",
        "ddgs", # Pour ton module websearch
    ],
    author="Zocain Viken",
    description="A lightweight tool normalization library for LLMs",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    python_requires=">=3.7",
)