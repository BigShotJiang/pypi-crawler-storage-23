from .converter import unit_converter
from .weather import get_weather
from .stocks import get_stock_price
from .translator import translate_text
from .calculator import safe_calculator
from .datetime_utils import get_current_time, get_current_date
from .websearch import web_search


LEGACY_TOOLS = {
    "CALC": safe_calculator,
    "MATH": safe_calculator,
    "TIME": get_current_time,
    "DATE": get_current_date,
    "CONVERT": unit_converter,
    "WEATHER": get_weather,
    "STOCK": get_stock_price,
    "TRANSLATE": translate_text,
    "WEBSEARCH": web_search,
}


from selfie_generator import generer_photo_waifu
from diffusers import StableDiffusionPipeline
import uuid
import os

tools = [
    {
        "type": "function",
        "function": {
            "name": "envoyer_photo",
            "description": "Prend une photo de Satana",
            "parameters": {
                "type": "object",
                "properties": {
                    "emotion": {"type": "string"},
                    "lieu": {"type": "string"}
                },
                "required": ["emotion", "lieu"]
            }
        }
    }
]


def tool_take_selfie(description_physique, contexte):
    # On construit un prompt propre pour Stable Diffusion
    full_prompt = f"1girl, solo, masterpiece, {description_physique}, {contexte}, high quality"
    
    # On appelle le générateur (qui choisira GPU ou API via selfie_generator)
    image_url = generer_photo_waifu(full_prompt)
    
    if image_url:
        return image_url # Renvoie "/static/generated_selfies/selfie-XXXX.png"
    else:
        return "error"
 