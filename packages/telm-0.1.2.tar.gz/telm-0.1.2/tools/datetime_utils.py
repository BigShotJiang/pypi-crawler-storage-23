
# tools.datetime.utils.py
import datetime


def get_current_time():
    """Returns the current time."""
    return datetime.datetime.now().strftime("%H:%M:%S")

def get_current_date():
    """Returns the current date."""
    return datetime.datetime.now().strftime("%Y-%m-%d")
