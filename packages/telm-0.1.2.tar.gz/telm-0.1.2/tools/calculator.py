
# tools.calculator.py
import math

def safe_calculator(expression):
    """Safe calculator function using a whitelist of allowed math functions."""
    allowed_functions = {
        "abs": abs, "round": round, "pow": pow,
        "sqrt": math.sqrt, "log": math.log, "exp": math.exp,
        "sin": math.sin, "cos": math.cos, "tan": math.tan,
        "pi": math.pi, "e": math.e
    }
    try:
        return str(eval(expression, {"__builtins__": None}, allowed_functions))
    except Exception:
        return "Invalid math expression"