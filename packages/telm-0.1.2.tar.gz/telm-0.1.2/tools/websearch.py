
# tools.websearch.py

from ddgs import DDGS


def web_search(query: str) -> str:
    """
    Recherche des informations sur internet via DuckDuckGo.
    Utile pour obtenir des actualités ou des détails techniques récents.
    """
    try:
        results = DDGS().text(query, max_results=10)
        if not results:
            return "Aucun résultat trouvé pour cette recherche."
        
        formatted_results = []
        for r in results:
            formatted_results.append(f"Titre: {r['title']}\nLien: {r['href']}\nExtrait: {r['body']}\n")
        
        return "\n---\n".join(formatted_results)
    except Exception as e:
        return f"Erreur lors de la recherche : {str(e)}"
 
 