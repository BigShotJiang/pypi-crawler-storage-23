"""Feature extraction configuration."""

from dataclasses import dataclass


@dataclass(frozen=True)
class FeatureConfig:
    """
    Configuration for feature extraction pipeline.

    This dataclass is frozen (immutable) to ensure config consistency
    throughout a pipeline run. All defaults are designed for batch
    processing of existing data.

    Attributes
    ----------
    allow_20s : bool
        Allow 20-second cadence data (default: False for 2-min only).
    network_ok : bool
        Allow network requests during processing (default: False).
    bulk_mode : bool
        Optimize for bulk processing (default: True).
    no_download : bool
        Skip downloading any new data (default: False).
    cache_dir : str | None
        Optional cache directory for MAST/lightkurve artifacts. When set, btv
        configures lightkurve to use this directory for both reads and writes.
    local_data_path : str | None
        Path to local data directory containing tic{tic_id}/ subdirectories
        with sector*_pdcsap.csv files. If set, light curves are loaded from
        local files instead of MAST queries (default: None).
    enable_t0_refine : bool
        Enable T0 refinement optimization (default: False).
    t0_refine_max_minutes : float
        Maximum time budget for T0 refinement in minutes.
    t0_refine_min_delta_score : float
        Minimum score improvement to accept refined T0.
    enable_pixel_timeseries : bool
        Enable pixel-level timeseries analysis (default: True).
    enable_host_plausibility : bool
        Enable host star plausibility checks (default: True).
    enable_ghost_reliability : bool
        Enable ghost/scattered light reliability features (default: True).
    enable_sector_quality : bool
        Enable sector quality metrics (default: True).
    enable_diff_image_score : bool
        Enable difference image scoring (default: False).
    enable_ephemeris_match : bool
        Enable ephemeris matching features (default: False).
    enable_alias_diagnostics : bool
        Enable alias/harmonic diagnostics computed from the stitched light curve
        (default: True; cheap, LC-only).
    enable_sector_consistency : bool
        Enable cross-sector consistency checks (default: False).
    enable_transit_uniformity : bool
        Enable transit uniformity analysis (default: False).
    enable_transit_shape_categorical : bool
        Enable categorical transit shape classification (default: False).
    enable_ephemeris_specificity : bool
        Enable ephemeris-specificity diagnostics (smooth-template score + phase-shift null)
        computed from the stitched light curve (default: True).
    ephemeris_specificity_n_phase_shifts : int
        Number of phase shifts to evaluate in the null test. This can be reduced for
        bulk enrichment runs (default: 80).
    enable_systematics_proxy : bool
        Enable a cheap LC-only systematics proxy score (default: True).
    enable_candidate_evidence : bool
        Enable candidate-level evidence blocks (e.g., Gaia crowding summary)
        when network is allowed (default: True).
    require_tpf : bool
        If True, fail enrichment when no TPF could be loaded (default: False).
    pixel_timeseries_max_hypotheses : int
        Maximum number of host hypotheses to compare in pixel-timeseries analysis
        (default: 4 = target + up to 3 neighbors).
    pixel_timeseries_max_windows : int
        Maximum number of transit windows to fit in pixel-timeseries analysis
        (default: 8).
    pixel_timeseries_margin_threshold : float
        Delta chi-squared threshold for a resolved ON/OFF-target verdict
        (default: 2.0).
    """

    # Input handling
    allow_20s: bool = False
    network_ok: bool = False
    bulk_mode: bool = True
    no_download: bool = False
    cache_dir: str | None = None
    local_data_path: str | None = None

    # Optional operations
    enable_t0_refine: bool = False
    t0_refine_max_minutes: float = 60.0
    t0_refine_min_delta_score: float = 2.0

    # Feature families
    enable_pixel_timeseries: bool = True
    enable_host_plausibility: bool = True
    enable_ghost_reliability: bool = True
    enable_sector_quality: bool = True
    enable_diff_image_score: bool = False
    enable_ephemeris_match: bool = False
    enable_alias_diagnostics: bool = True
    enable_sector_consistency: bool = False
    enable_transit_uniformity: bool = False
    enable_transit_shape_categorical: bool = False
    enable_ephemeris_specificity: bool = True
    ephemeris_specificity_n_phase_shifts: int = 80
    enable_systematics_proxy: bool = True
    enable_candidate_evidence: bool = True

    # Gating
    require_tpf: bool = False

    # Pixel-timeseries tuning (runtime guardrails)
    pixel_timeseries_max_hypotheses: int = 4
    pixel_timeseries_max_windows: int = 8
    pixel_timeseries_margin_threshold: float = 2.0
