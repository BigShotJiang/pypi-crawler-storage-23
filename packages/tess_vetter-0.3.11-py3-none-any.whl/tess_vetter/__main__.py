"""Module entrypoint for ``python -m tess_vetter``."""

from tess_vetter.cli.enrich_cli import main

if __name__ == "__main__":
    main()
