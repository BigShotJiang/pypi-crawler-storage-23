## Copyright © 2025-2026, Alex J. Champandard.  Licensed under AGPLv3; see LICENSE!

import io
import os
import sys
import json
import time
import uuid
import math
import traceback
from pathlib import Path
from contextlib import contextmanager
from dataclasses import dataclass

import joyfl.api
from joyfl.types import nil, Operation, stack_list
from joyfl.errors import JoyError, JoyParseError, JoyImportError, JoyModuleError, JoyTypeError, JoyNameError, JoyNotImplementedError
from joyfl.formatting import format_item, stack_to_list
from joyfl.interpreter import interpret, interpret_step
from joyfl.runtime import Runtime

from .logger import CrashLogger
from .solve import SolveInputError, SolveTimedOut, install_solve_placeholders, run_solve


ANY_MARKER_PREFIX = (b'TRACE', b'HALT', b'BREAK', b'CHECK', b'MARK', b'EXIT')
PRE_EXEC_ERRORS = (JoyParseError, JoyImportError, JoyModuleError, JoyTypeError, JoyNameError)

TRACE_MAX_SIZE = 100
TRACE_TRIMMED_HALF = 20


@dataclass
class MarkerFlags:
    """Flags controlling which markers are enabled."""
    trace_: bool
    halt_: bool
    break_: bool
    check_: bool


@dataclass
class TraceFilter:
    """Filter configuration for trace data collection.
    
    Defaults per user spec: show='all', exclude_file='stdlib', include_name=None
    """
    show_mode: str = 'all'
    exclude_file: str | None = 'stdlib'
    include_name: str | None = None
    filter_non_ops: bool = False

    def _op_filename(self, op) -> str:
        if not isinstance(op, Operation):
            return ''
        meta = op.meta or {}
        body_meta = meta.get('body')
        if isinstance(body_meta, dict):
            filename = body_meta.get('filename')
            if filename:
                return filename
        return meta.get('filename', '') or ''
    
    def should_capture_from_op(self, op) -> bool:
        """Determine if result of executing this operation should be captured."""
        if op is None:
            # Empty queue reached end, always capture
            return self.show_mode == 'all'

        if self.filter_non_ops and not isinstance(op, Operation):
            return False
            
        # File exclusion filter
        if self.exclude_file and isinstance(op, Operation):
            filename = self._op_filename(op)
            if self.exclude_file in filename:
                return False
        
        # Name inclusion filter
        if self.include_name and isinstance(op, Operation):
            if self.include_name not in op.name:
                return False

        # Type-based filters
        if self.show_mode in ('ops', 'code'):
            return isinstance(op, Operation) and op.type in (Operation.FUNCTION, Operation.COMBINATOR)
        elif self.show_mode in ('quot', 'code'):
            return isinstance(op, Operation) and op.type == Operation.EXECUTE
        
        # show='all': capture everything (default behavior)
        return True
    
    def should_capture(self, queue: list) -> bool:
        """Determine if current state should be captured in trace.
        
        This method checks the NEXT operation to be executed at queue[0].
        """
        if len(queue) == 0:
            return True
        
        head = queue[0]

        if self.filter_non_ops and not isinstance(head, Operation):
            return False
        
        # File exclusion filter
        if self.exclude_file and isinstance(head, Operation):
            filename = self._op_filename(head)
            if self.exclude_file in filename:
                return False
        
        # Name inclusion filter
        if self.include_name and isinstance(head, Operation):
            if self.include_name not in head.name:
                return False
        
        # Type-based filters
        if self.show_mode in ('ops', 'code'):
            return isinstance(head, Operation) and head.type in (Operation.FUNCTION, Operation.COMBINATOR)
        elif self.show_mode in ('quot', 'code'):
            return isinstance(head, Operation) and head.type == Operation.EXECUTE
        
        # show='all': capture everything (default behavior)
        return True


def is_mark(op):
    return isinstance(op, bytes) and op.startswith(ANY_MARKER_PREFIX)


def _strip_markers(value):
    """Remove marker bytes from lists (including nested lists)."""
    assert value is not None
    if is_mark(value):
        return None
    if isinstance(value, list):
        cleaned = []
        for item in value:
            cleaned_item = _strip_markers(item)
            if cleaned_item is None:
                continue
            cleaned.append(cleaned_item)
        return stack_list(cleaned) if isinstance(value, stack_list) else cleaned
    return value


def _format_item_no_markers(value, **kwargs):
    cleaned = _strip_markers(value)
    if cleaned is None:
        return None
    return format_item(cleaned, **kwargs)


def _format_trace_list(items, empty_label):
    cleaned = _strip_markers(items if items is not None else [])
    if cleaned is None or len(cleaned) == 0:
        return empty_label
    return format_item(cleaned, abbreviate=False)


def _format_items_join(items):
    if items is None:
        return None
    formatted = []
    for item in items:
        cleaned_item = _strip_markers(item)
        if cleaned_item is None:
            continue
        formatted.append(format_item(cleaned_item, abbreviate=False))
    if len(formatted) == 0:
        return None
    return ' '.join(formatted)


def _ensure_stack_str(stack_str):
    return "< nil >" if stack_str is None else stack_str


def _wrap_queue_str(queue_str):
    if queue_str is None:
        return None
    return f'[{queue_str}]'


def _collapse_best_repeated_suffix(tokens: list[str], *, max_pattern_len: int = 24, min_repeats: int = 3) -> list[str]:
    """Collapse a repeated suffix to keep first+last copy and replace middle with '...'.
    
    We pick the candidate suffix pattern that repeats consecutively at the end of the token
    sequence at least `min_repeats` times, maximizing (pattern_len * repeats), breaking ties
    by preferring the shorter pattern.
    """
    if min_repeats <= 1:
        raise ValueError("min_repeats must be >= 2")
    n = len(tokens)
    if n < min_repeats:
        return tokens

    # Pattern must fit at least min_repeats times at end.
    limit = min(max_pattern_len, n // min_repeats)
    best = None  # (repeated_len, pattern_len, repeats)
    best_pattern = None

    for p in range(1, limit + 1):
        pattern = tokens[-p:]
        j = n - 1
        k = p - 1
        repeats = 0
        while j >= 0:
            if tokens[j] != pattern[k]:
                break
            j -= 1
            k -= 1
            if k < 0:
                repeats += 1
                k = p - 1

        if repeats < min_repeats:
            continue

        repeated_len = p * repeats
        cand = (repeated_len, p, repeats)
        if best is None or cand[0] > best[0] or (cand[0] == best[0] and cand[1] < best[1]):
            best = cand
            best_pattern = pattern

    if best is None or best_pattern is None:
        return tokens

    repeated_len, p, repeats = best
    assert repeated_len == p * repeats
    prefix = tokens[:n - repeated_len]
    return prefix + best_pattern + ["..."] + best_pattern


def _clip_tokens(tokens: list[str], *, max_tokens: int = 200) -> list[str]:
    """Hard cap token count to bound response size."""
    if len(tokens) <= max_tokens:
        return tokens
    head = max_tokens // 2
    tail = max_tokens - head - 1
    return tokens[:head] + ["..."] + tokens[-tail:]


def _tokens_for_sanitization(items) -> list[str]:
    tokens: list[str] = []
    for item in items:
        cleaned = _strip_markers(item)
        if cleaned is None:
            continue
        if isinstance(cleaned, Operation):
            tokens.append(cleaned.name)
        else:
            tokens.append(format_item(cleaned, abbreviate=True))
    return tokens


def _build_error_logs(exc):
    if exc is None:
        return []
    return [
        {
            'level': 'error',
            'message': str(exc),
            'timestamp': time.time()
        }
    ]


@contextmanager
def _capture_stdout():
    old_stdout = sys.stdout
    captured_output = io.StringIO()
    sys.stdout = captured_output
    try:
        yield captured_output
    finally:
        sys.stdout = old_stdout


class ProgramExplicitlyHalts(Exception):
    """Raised by an Operation or Search to prune the current node in the frontier (e.g., constraint failure)."""
    pass

class ProgramBreakpointHit(Exception):
    """Raised when a BREAK marker is encountered during execution, status becomes 'interrupted'."""
    pass

class ProgramTimedOut(Exception):
    """Raised when execution time exceeds the request timeout."""
    pass


class ProcessServer:
    """Simple JSON protocol server for Joy process execution."""

    def __init__(self, log_crashes=False):
        self.runtime = joyfl.api._RUNTIME
        self._baseline_runtime = self.runtime
        self.sessions = {}
        self.crash_logger = CrashLogger(enabled=log_crashes) if log_crashes else None

        self._load_stdlib()
        install_solve_placeholders(self.runtime)
        self._baseline_library = self.runtime.library

        # LCG parameters (Numerical Recipes)
        self.LCG_A = 1664525
        self.LCG_C = 1013904223
        self.LCG_M = 4294967296  # 2^32

    def _load_stdlib(self) -> None:
        base = Path(__file__).resolve().parent.parent
        candidates = (d / 'libs' / 'stdlib.joy' for d in (base, *base.parents[:2]))
        stdlib_path = next((p for p in candidates if p.exists()), Path('libs/stdlib.joy'))
        source_text = stdlib_path.read_text(encoding='utf-8')
        self.runtime.load(source_text, filename='libs/stdlib.joy', validate=True)
    
    def _lcg_next(self, state: int) -> int:
        """LCG: X_{n+1} = (a * X_n + c) mod m"""
        return (self.LCG_A * state + self.LCG_C) % self.LCG_M
    
    def _sess_id_to_lcg_state(self, sess_id: str) -> int:
        """Convert sess_id to initial LCG state (first 8 hex chars)."""
        hex_part = sess_id.replace('-', '')[:8]
        return int(hex_part, 16)
    
    def _validate_req_id(self, sess_id: str, req_id: int) -> bool:
        if sess_id not in self.sessions:
            return False
        
        current_lcg_state = self.sessions[sess_id]['lcg_state']
        expected_req_id = self._lcg_next(current_lcg_state)
        return req_id == expected_req_id
    
    @contextmanager
    def _handle_crashes(self, request):
        try:
            yield
        except (EOFError, BrokenPipeError):
            # Normal shutdown errors, don't handle as crashes
            pass
        except (Exception, RuntimeError) as exc:
            if self.crash_logger is None:
                return

            if isinstance(exc, RuntimeError) and exc.__cause__ is not None:
                exc = exc.__cause__
            
            crash_data = self.crash_logger.capture_and_log(exc, request)
            print(f"ERROR: While handling request. cmd={request['cmd']} sess_id={request['sess_id']} req_id={request['req_id']}.\n{str(exc)}", file=sys.stderr)

            # Send crash response then exit
            crash_id = crash_data['crash_id'] if crash_data else None
            self._write_response({
                'status': 'crash',
                'req_id': request['req_id'],
                'crash_id': crash_id,
                'error': str(exc),
                'traceback': traceback.format_exception(exc)
            })
            time.sleep(1.0)
            sys.exit(1)
    
    def run(self):
        for buffer in self._read_chunks():
            try:
                request = json.loads(buffer)
            except json.JSONDecodeError as exc:
                print(f"ERROR: Could not load JSON from buffer. {exc}", file=sys.stderr)
                self._write_response({
                    'status': 'invalid',
                    'cmd': None,
                    'req_id': None,
                    'error': f'Invalid JSON: {str(exc)}'
                })
                continue
            
            with self._handle_crashes(request):
                response = self._handle_request(request)
                self._write_response(response)
    
    def _read_chunks(self):
        """Generator that yields JSON messages separated by \\0 delimiter."""
        buffer = b''
        while True:
            chunk = sys.stdin.buffer.read(1)
            if not chunk:
                if buffer:
                    yield buffer.decode('utf-8')
                return

            buffer += chunk
            while True:
                idx = buffer.find(b'\0')
                if idx == -1:
                    break
                yield buffer[:idx].decode('utf-8')
                buffer = buffer[idx + 1:]
    
    def _write_response(self, response):
        """Write response as JSON with \\0 delimiter and flush."""
        sys.stdout.write(json.dumps(response) + '\0')
        sys.stdout.flush()
    
    def _handle_request(self, request):
        cmd = request.get('cmd')
        req_id = request.get('req_id')
        sess_id = request.get('sess_id')

        if cmd == 'welcome':
            return self._cmd_welcome(req_id)

        session = None
        if cmd in ('execute', 'trace', 'solve', 'goodbye') or sess_id is not None:
            session, error_response = self._validate_session_and_lcg(cmd, req_id, sess_id)
            if error_response is not None:
                return error_response
            self._consume_lcg_state(session)
        
        if cmd == 'execute':
            return self._cmd_execute(request, is_tracing=False, session=session)
        elif cmd == 'trace':
            return self._cmd_execute(request, is_tracing=True, session=session)
        elif cmd == 'solve':
            return self._cmd_solve(request, session=session)
        elif cmd == 'goodbye':
            return self._cmd_goodbye(request, session=session)
        else:
            print(f"ERROR: Unknown command `{cmd}`.", file=sys.stderr)
            return {
                'status': 'invalid',
                'cmd': cmd,
                'req_id': req_id,
                'error': f'Unknown command: {cmd}'
            }
    
    def _cmd_welcome(self, req_id):
        sess_id = str(uuid.uuid4())
        sess_runtime = Runtime(library=self._baseline_library.with_session_overlay())
        self.sessions[sess_id] = {
            'start_time': time.time(),
            'commands_processed': 0,
            'lcg_state': self._sess_id_to_lcg_state(sess_id),
            'runtime': sess_runtime,
        }
        
        return {
            'status': 'complete',
            'cmd': 'welcome',
            'req_id': req_id,
            'data': {
                'sess_id': sess_id,
                'server': 'joyfl-proc',
                'version': '1.0',
                'capabilities': ['execute', 'solve']
            }
        }

    def _parse_marker_mode(self, mode: str | None, is_tracing: bool) -> MarkerFlags | dict:
        """
        Parse mode string into marker enable/disable flags.

        Args:
            mode: None, "all", or "|" separated keywords (e.g., "trace|halt")
            is_tracing: True for trace command, False for execute

        Returns:
            On success: MarkerFlags instance
            On error: Dict with error message (for _make_invalid_response)
        """
        valid_markers = {'trace', 'halt', 'break', 'check'}

        # Default: trace enables all, execute disables all
        if mode is None:
            default = True if is_tracing else False
            return MarkerFlags(trace_=default, halt_=default, break_=default, check_=default)

        # Empty string means disable all markers (explicit override of defaults)
        if mode == '':
            return MarkerFlags(trace_=False, halt_=False, break_=False, check_=False)

        # Special case: "all" / "none" means enable or disable each one.
        if mode == 'all':
            return MarkerFlags(trace_=True, halt_=True, break_=True, check_=True)
        if mode == 'none':
            return MarkerFlags(trace_=False, halt_=False, break_=False, check_=False)

        # Parse pipe-separated keywords - only listed markers are enabled, others disabled
        enabled = mode.split('|')
        marker_flags = {
            'trace': False,
            'halt': False,
            'break': False,
            'check': False
        }

        for marker in enabled:
            marker = marker.strip()
            if marker not in valid_markers:
                # Return error dict for invalid marker name
                return {
                    'error': f"Invalid marker '{marker}' in mode. Valid markers are: {', '.join(sorted(valid_markers))}"
                }
            marker_flags[marker] = True

        return MarkerFlags(
            trace_=marker_flags['trace'],
            halt_=marker_flags['halt'],
            break_=marker_flags['break'],
            check_=marker_flags['check']
        )

    def _parse_show_mode(self, show: str | None, is_tracing: bool) -> str | dict:
        """
        Parse show string into mode for trace data inclusion.

        Args:
            show: None, "none", "mark", "auto", "all", "ops", "quot", or "code"
            is_tracing: True for trace command, False for execute

        Returns:
            On success: One of "none", "mark", "auto", "all", "ops", "quot", or "code"
            On error: Dict with error message (for _make_invalid_response)
        """
        valid_show_modes = {'none', 'mark', 'auto', 'all', 'ops', 'quot', 'code'}

        # Default: trace defaults to "ops", execute defaults to "none"
        if show is None:
            return 'code' if is_tracing else 'none'

        # Validate show mode
        if show not in valid_show_modes:
            return {
                'error': f"Invalid show mode '{show}'. Valid show modes are: {', '.join(sorted(valid_show_modes))}"
            }

        return show

    def _parse_trace_filter(self, show_mode: str, exclude: str | None = None,
                            include: str | None = None, *, filter_non_ops: bool = False) -> TraceFilter:
        """Create TraceFilter from request parameters.
        
        Args:
            show_mode: The validated show mode string
            exclude: Optional substring to exclude by filename
            include: Optional substring to include by operation name
            filter_non_ops: Whether to suppress non-Operation trace entries
            
        Returns:
            TraceFilter instance with appropriate defaults
        """
        return TraceFilter(
            show_mode=show_mode,
            exclude_file=exclude,
            include_name=include,
            filter_non_ops=filter_non_ops
        )

    def _create_tracing_stepper(self, marker_flags: MarkerFlags,
                                trace_filter: TraceFilter,
                                implicit_markers: bool = False,
                                *, timeout_ns: int | None = None) -> tuple[callable, list]:
        """Create a custom stepper that tracks execution and handles markers based on flags.
        
        Args:
            timeout_ns: Optional execution timeout in nanoseconds, measured from the first
                interpreter step. If provided, the interpreter loop will be interrupted
                when time.monotonic_ns() >= deadline.
        """

        trace_data = []
        step = 0
        implicit_start_added = False
        implicit_stop_added = False
        deadline_ns: int | None = None

        def _emit_mark(mark: str, step_value, stack_value, queue_value) -> None:
            """Emit a marker entry at the current step without squashing prior marks.
            
            Ensures there's a trace entry for (step_value, stack_value, queue_value), then
            records mark and duplicates the entry if another mark was already present.
            """
            if not trace_data or trace_data[-1].get('step') != step_value:
                trace_data.append({
                    'step': step_value,
                    'stack': stack_to_list(stack_value),
                    'queue': [q for q in queue_value if not is_mark(q)]
                })
            if 'mark' in trace_data[-1]:
                trace_data.append(dict(trace_data[-1]))
            trace_data[-1]['mark'] = mark
            trace_data[-1]['step'] = step_value

        def _append_implicit_stop(step_value, stack_value, queue_value) -> None:
            nonlocal implicit_stop_added
            if not implicit_markers or implicit_stop_added:
                return
            if len(queue_value) != 0:
                return
            _emit_mark("STOP", step_value, stack_value, queue_value)
            implicit_stop_added = True

        def stepper(queue, stack, lib, **kwargs):
            """Custom stepper that tracks execution before each step."""
            nonlocal step
            nonlocal implicit_start_added, implicit_stop_added
            nonlocal deadline_ns

            if implicit_markers and not implicit_start_added:
                _emit_mark("START", step, stack, queue)
                implicit_start_added = True

            # Capture state before execution, once. Always step 0 by definition.
            if len(trace_data) == 0 and trace_filter.should_capture_from_op(None):
                trace_data.append({'step': step, 'stack': stack_to_list(stack), 'queue': [q for q in queue if not is_mark(q)]})

            if timeout_ns is not None and deadline_ns is None:
                deadline_ns = time.monotonic_ns() + timeout_ns

            if deadline_ns is not None and time.monotonic_ns() >= deadline_ns:
                _emit_mark("TIMEOUT", step, stack, queue)
                raise ProgramTimedOut()

            op = queue[0] if len(queue) > 0 else None
            if op is not None and is_mark(op):
                # Determine marker type from prefix
                marker_enabled = None
                if op.startswith(b'TRACE'):
                    marker_enabled = marker_flags.trace_
                elif op.startswith(b'HALT'):
                    marker_enabled = marker_flags.halt_
                elif op.startswith(b'BREAK'):
                    marker_enabled = marker_flags.break_
                elif op.startswith(b'CHECK'):
                    marker_enabled = marker_flags.check_
                elif op.startswith(b'EXIT-'):
                    # Internal interpreter marker for deferred EXECUTE validation.
                    # Never exposed as a user marker and never counted as a step.
                    marker_enabled = False

                # If marker is enabled, handle it normally
                if marker_enabled:
                    _emit_mark(op.decode('utf-8'), step, stack, queue)

                    if op.startswith(b'HALT'):
                        raise ProgramExplicitlyHalts()
                    elif op.startswith(b'BREAK'):
                        raise ProgramBreakpointHit()
                    elif op.startswith((b'TRACE', b'CHECK')):
                        queue.popleft()
                        _append_implicit_stop(step, stack, queue)
                    return stack, queue

                # If marker is disabled, silently remove it
                if marker_enabled is not None:
                    queue.popleft()
                    _append_implicit_stop(step, stack, queue)
                    return stack, queue

            # Only increment step now because markers don't count.
            step += 1

            # Execute step
            new_stack, new_queue = interpret_step(queue, stack, lib, **kwargs)

            # Capture state after execution, depending on trace filters.
            # Filter based on what will execute next (new_queue[0]) so the decision
            # matches the queue snapshot we record.
            next_op = new_queue[0] if len(new_queue) > 0 else None
            if len(new_queue) == 0 or trace_filter.should_capture_from_op(next_op):
                trace_data.append({'step': step, 'stack': stack_to_list(new_stack), 'queue': [q for q in new_queue if not is_mark(q)]})

            _append_implicit_stop(step, new_stack, new_queue)

            return new_stack, new_queue

        return stepper, trace_data

    def _extract_result_from_trace(self, trace_data):
        if not trace_data:
            return None
        last_entry = trace_data[-1]
        stack = last_entry.get('stack')
        # stack is now a list (converted from Stack)
        if stack is not None and len(stack) > 0:
            # Top of stack is the first element in stack_list
            top = stack[0]
            return str(format_item(top))
        return None

    def _extract_stack_from_trace(self, trace_data):
        if not trace_data:
            return None
        last_entry = trace_data[-1]
        stack = last_entry.get('stack')
        return _format_trace_list(stack, "< nil >")

    def _extract_queue_from_trace(self, trace_data):
        if not trace_data:
            return None
        last_entry = trace_data[-1]
        queue = last_entry.get('queue')
        if queue is None:
            return None
        return _format_items_join(queue)

    def _extract_stack_from_exception(self, exc):
        joy_stack = getattr(exc, 'joy_stack', None)
        if joy_stack is not None:
            stack_items = stack_to_list(joy_stack)
            return _format_trace_list(stack_items, "< nil >")
        return None

    def _extract_queue_from_exception(self, exc):
        joy_queue = getattr(exc, 'joy_queue', None)
        if joy_queue is not None:
            formatted = _format_items_join(joy_queue)
            return formatted if formatted is not None else ""
        return None

    def _make_invalid_response(self, cmd, req_id, error):
        return {
            'status': 'invalid',
            'cmd': cmd,
            'req_id': req_id,
            'error': error
        }

    def _consume_lcg_state(self, session):
        """Advance session LCG state by one step."""
        session['lcg_state'] = self._lcg_next(session['lcg_state'])

    def _validate_session_and_lcg(self, cmd, req_id, sess_id):
        """Validate that session exists and req_id matches LCG sequence.

        Returns:
            tuple(session_or_none, invalid_response_or_none)
        """
        if sess_id is None or sess_id not in self.sessions:
            print(f"ERROR: Could not validate session. cmd={cmd} sess_id={sess_id}.", file=sys.stderr)
            return None, self._make_invalid_response(cmd, req_id, 'Invalid or missing session ID')

        session = self.sessions[sess_id]

        # Validate req_id matches LCG sequence
        if not self._validate_req_id(sess_id, req_id):
            print(f"ERROR: Could not validate request with LCG sequence. cmd={cmd} sess_id={sess_id} req_id={req_id}.", file=sys.stderr)
            return None, self._make_invalid_response(cmd, req_id, 'Invalid req_id for session (LCG validation failed)')

        return session, None

    def _cmd_name(self, is_tracing: bool) -> str:
        return 'trace' if is_tracing else 'execute'

    def _make_timeout_response(self, req_id, is_tracing: bool, show_mode: str, stdout_text: str,
                               timeout_seconds: float, trace_data: list) -> dict:
        """Build a sanitized timeout response.
        
        On timeouts we avoid formatting/returning the full trace (can be huge) and instead return
        a single trace entry with sanitized stack/queue and a TIMEOUT mark.
        """
        last = trace_data[-1] if trace_data else {'step': 0, 'stack': [], 'queue': [], 'mark': 'TIMEOUT'}

        def _sanitize(tokens: list[str]) -> list[str]:
            return _clip_tokens(_collapse_best_repeated_suffix(tokens))

        queue_tokens = _sanitize(_tokens_for_sanitization(last.get('queue') or []))
        stack_tokens = _sanitize(_tokens_for_sanitization(reversed(last.get('stack') or [])))

        queue_str = " ".join(queue_tokens)
        stack_str = "< nil >" if len(stack_tokens) == 0 else "<" + " ".join(stack_tokens) + ">"

        result = self._extract_result_from_trace([last] if trace_data else [])

        # Build response without auto-formatting the full trace (which can be huge on timeouts).
        data = self._build_response_data(
            is_tracing,
            show_mode='none',
            trace_data=None,
            result=result,
            stack_str=stack_str,
            queue_str=queue_str,
            stdout_text=stdout_text
        )
        data['exception'] = ProgramTimedOut.__name__

        if show_mode != 'none':
            data['trace'] = [{
                'step': last.get('step', 0),
                'stack': data['stack'],
                'queue': data.get('queue', "[]"),
                'mark': 'TIMEOUT',
            }]

        return {
            'status': 'interrupted',
            'cmd': self._cmd_name(is_tracing),
            'req_id': req_id,
            'error': f'ProgramTimedOut: Execution interrupted by timeout ({timeout_seconds}s)',
            'data': data
        }

    def _build_response_data(self, is_tracing, show_mode='auto', trace_data=None, result=None, stack_str=None, queue_str=None, stdout_text=None, exc=None):
        stack_str = _ensure_stack_str(stack_str)
        queue_value = _wrap_queue_str(queue_str)
        data = {
            'result': result,
            'stack': stack_str,
            'logs': _build_error_logs(exc),
        }
        if not is_tracing:
            data['output'] = stdout_text or ''
        if queue_value is not None:
            data['queue'] = queue_value
        if show_mode == 'none':
            # No trace data in response
            return data

        if trace_data is None:
            trace_data = []

        # Filter trace data based on show_mode.
        # Note: show_mode is validated by _parse_show_mode() before reaching here.
        if show_mode == 'auto':
            has_markers = any('mark' in d for d in trace_data)
            filtered_trace = [d for d in trace_data if 'mark' in d] if has_markers else trace_data
        elif show_mode == 'mark':
            filtered_trace = [d for d in trace_data if 'mark' in d]
        elif show_mode in ('all', 'ops', 'quot', 'code'):
            # For show='ops'/'quot'/'code', entries are already filtered during capture by should_capture_from_op().
            filtered_trace = trace_data
        else:
            raise RuntimeError(f"Invalid show mode {show_mode!r}")

        # Format trace data with proper byte conversion using format_item()
        formatted_trace = []
        for d in filtered_trace:
            entry = {}
            # step, stack, and queue are always present
            entry['step'] = d['step']
            # format_item handles lists correctly, but we need to wrap with < > for stack
            if stack_list := d['stack']:
                entry['stack'] = _format_trace_list(stack_list, "< nil >")
            else:
                entry['stack'] = "< nil >"
            # format_item already adds [ ] for lists
            entry['queue'] = _format_trace_list(d['queue'], "[]")
            # mark is optional
            if 'mark' in d:
                # Mark is already a string (decoded from bytes)
                entry['mark'] = d['mark']
            formatted_trace.append(entry)

        if len(formatted_trace) > TRACE_MAX_SIZE:
            ellipsis_entry = {'step': '⋯', 'stack': '', 'queue': ''}
            formatted_trace = formatted_trace[:TRACE_TRIMMED_HALF] + [ellipsis_entry] + formatted_trace[-TRACE_TRIMMED_HALF:]

        data['trace'] = formatted_trace
        return data

    def _make_verify_summary(self, *, outcome: str) -> dict:
        return {
            'outcome': outcome,
            'counts': {
                'total': 0,
                'passed': 0,
                'failed': 0,
                'missing': 0,
            },
            'cases': [],
        }

    def _updated_verifier_suite_ids(self, runtime: Runtime, previous: dict[str, list]) -> list[str]:
        updated = []
        current = runtime.library.verifiers
        for suite_id, suite_tests in current.items():
            if suite_id not in previous or previous[suite_id] is not suite_tests:
                updated.append(suite_id)
        updated.sort()
        return updated

    def _run_verify_suites(self, runtime: Runtime, suite_ids: list[str]) -> dict:
        summary = self._make_verify_summary(outcome='none')
        counts = summary['counts']
        if len(suite_ids) == 0:
            return summary

        for suite_id in suite_ids:
            suite_tests = runtime.library.verifiers[suite_id]
            for idx, verifier in enumerate(suite_tests):
                test_name = verifier.description or f"case-{idx}"
                counts['total'] += 1
                try:
                    stack = interpret(verifier.program, lib=runtime.library, validate=True)
                except JoyNotImplementedError as exc:
                    counts['missing'] += 1
                    summary['cases'].append({
                        'outcome': 'missing',
                        'suite': suite_id,
                        'test': test_name,
                        'error': str(exc),
                    })
                    continue
                except JoyError as exc:
                    counts['failed'] += 1
                    summary['cases'].append({
                        'outcome': 'failed',
                        'suite': suite_id,
                        'test': test_name,
                        'error': str(exc),
                    })
                    continue

                if stack is nil:
                    counts['failed'] += 1
                    summary['cases'].append({
                        'outcome': 'failed',
                        'suite': suite_id,
                        'test': test_name,
                        'error': "Verifier must leave bool `true` on stack top (got empty stack).",
                    })
                    continue

                top = stack[-1]
                if not isinstance(top, bool):
                    counts['failed'] += 1
                    summary['cases'].append({
                        'outcome': 'failed',
                        'suite': suite_id,
                        'test': test_name,
                        'error': f"Verifier must leave bool on stack top, got `{type(top).__name__}`.",
                    })
                    continue

                if top is not True:
                    counts['failed'] += 1
                    summary['cases'].append({
                        'outcome': 'failed',
                        'suite': suite_id,
                        'test': test_name,
                        'error': "Verifier predicate returned `false`.",
                    })
                    continue

                counts['passed'] += 1

        total = counts['total']
        failed = counts['failed']
        missing = counts['missing']
        if total == 0:
            summary['outcome'] = 'none'
        elif failed > 0:
            summary['outcome'] = 'fail'
        elif missing > 0:
            summary['outcome'] = 'missing'
        else:
            summary['outcome'] = 'pass'
        return summary

    def _cmd_execute(self, request, *, is_tracing=False, session):
        req_id = request.get('req_id')
        source = request.get('source')
        mode = request.get('mode')
        show = request.get('show')

        session['commands_processed'] += 1
        runtime: Runtime = session['runtime']

        # Validate required fields
        if source is None:
            return self._make_invalid_response('execute', req_id, 'Missing required field: source')

        # Parse and validate marker mode
        mode_result = self._parse_marker_mode(mode, is_tracing)
        if isinstance(mode_result, dict) and 'error' in mode_result:
            return self._make_invalid_response('execute', req_id, mode_result['error'])
        marker_flags = mode_result

        # Parse and validate show mode
        show_result = self._parse_show_mode(show, is_tracing)
        if isinstance(show_result, dict) and 'error' in show_result:
            return self._make_invalid_response('execute', req_id, show_result['error'])
        show_mode = show_result

        implicit_markers = show_mode != 'none' and mode not in ('none', '')

        verify_enabled = False
        if not is_tracing:
            raw_verify = request.get('verify', None)
            if raw_verify is None:
                verify_enabled = True
            elif isinstance(raw_verify, bool):
                verify_enabled = raw_verify
            else:
                return self._make_invalid_response('execute', req_id, 'Invalid verify: expected boolean')

        # Optional execution timeout (seconds). If provided, interrupt execution when exceeded.
        timeout = request.get('timeout', None)
        timeout_seconds: float | None = None
        if timeout is not None:
            if isinstance(timeout, bool):
                return self._make_invalid_response('execute', req_id, 'Invalid timeout: expected number of seconds')
            try:
                timeout_seconds = float(timeout)
            except (TypeError, ValueError):
                return self._make_invalid_response('execute', req_id, 'Invalid timeout: expected number of seconds')
            if timeout_seconds < 0 or not math.isfinite(timeout_seconds):
                return self._make_invalid_response('execute', req_id, 'Invalid timeout: must be a finite number >= 0')

        # Parse trace filter parameters
        raw_exclude_provided = 'exclude' in request
        raw_exclude = request.get('exclude', None)
        exclude = raw_exclude
        include = request.get('include')
        # Default: exclude stdlib ops unless explicitly disabled via exclude=""
        #
        # Note: many clients will serialize "unset" optional fields as null rather than
        # omitting the key entirely, so treat exclude=null the same as "not set".
        if exclude is None:
            exclude = 'stdlib'
        elif exclude == '':
            exclude = None
        exclude_value_provided = raw_exclude_provided and raw_exclude not in (None, '')
        filter_non_ops = (include is not None) or exclude_value_provided
        trace_filter = self._parse_trace_filter(show_mode, exclude, include, filter_non_ops=filter_non_ops)
        captured_output = None

        # Always create stepper with marker flags and trace filter (both execute and trace)
        timeout_ns = None
        if timeout_seconds is not None:
            timeout_ns = int(math.ceil(timeout_seconds * 1_000_000_000))
        stepper, trace_data = self._create_tracing_stepper(
            marker_flags,
            trace_filter,
            implicit_markers=implicit_markers,
            timeout_ns=timeout_ns
        )
        verify_before = dict(runtime.library.verifiers) if verify_enabled else {}
        data = None

        try:
            # NOTE: The terminal dot is auto-added, this is implied in the semantics of "execute"
            # as the dot itself is also "execute" -- so redundant, but not done twice.
            # Use '\n.' to ensure the dot is on a new line, preventing issues with EOL comments.
            source = source.rstrip('. \t\n\r') + '\n.'

            with _capture_stdout() as captured_output:
                stack = runtime._execute(source, filename='<REPL>', verbosity=0, validate=True, stats=None, stepper=stepper)
            stdout_text = captured_output.getvalue() if captured_output else ''

            # Get result and stack
            if stack is not nil:
                result = str(format_item(stack[-1]))
            else:
                result = None

            stack_str = _format_item_no_markers(stack_to_list(stack), abbreviate=False)
            data = self._build_response_data(
                is_tracing,
                show_mode,
                trace_data,
                result,
                stack_str,
                stdout_text=stdout_text
            )

        except (ProgramExplicitlyHalts, ProgramBreakpointHit, ProgramTimedOut) as exc:
            stdout_text = captured_output.getvalue() if captured_output else ''

            if isinstance(exc, ProgramTimedOut):
                assert timeout_seconds is not None
                return self._make_timeout_response(req_id, is_tracing, show_mode, stdout_text, timeout_seconds, trace_data)

            # Extract result and stack from trace data
            result = self._extract_result_from_trace(trace_data)
            stack_str = self._extract_stack_from_trace(trace_data)
            queue_str = self._extract_queue_from_trace(trace_data)
            if queue_str is None:
                queue_str = ""

            # Build response data - both HALT and BREAK show stack
            data = self._build_response_data(
                is_tracing,
                show_mode,
                trace_data,
                result,
                stack_str,
                queue_str=queue_str,
                stdout_text=stdout_text
            )
            data['exception'] = type(exc).__name__

            # Determine status and error message based on exception type
            if isinstance(exc, ProgramExplicitlyHalts):
                status = 'error'
                error_msg = 'ProgramExplicitlyHalts: Execution halted by HALT marker'
            elif isinstance(exc, ProgramBreakpointHit):
                status = 'interrupted'
                error_msg = 'ProgramBreakpointHit: Execution interrupted by BREAK marker'
            else:
                raise NotImplementedError('Unknown exception type.')

            return {
                'status': status,
                'cmd': self._cmd_name(is_tracing),
                'req_id': req_id,
                'error': error_msg,
                'data': data
            }

        except JoyError as exc:
            # JoyErrors are expected failures - log them but don't crash
            self.crash_logger.capture_and_log(exc, request, is_joy_error=True)

            stdout_text = captured_output.getvalue() if captured_output else ''

            # Extract stack and queue from exception
            stack_str = self._extract_stack_from_exception(exc)
            queue_str = self._extract_queue_from_exception(exc)
            is_pre_exec_error = isinstance(exc, PRE_EXEC_ERRORS)
            if stack_str is None or queue_str is None:
                if is_pre_exec_error:
                    stack_str = "< nil >"
                    queue_str = ""
                else:
                    raise RuntimeError('JoyError missing joy_stack/joy_queue', stack_str, queue_str)

            # Build error data using helper
            data = self._build_response_data(
                is_tracing,
                show_mode,
                trace_data,
                stack_str=stack_str,
                queue_str=queue_str,
                stdout_text=stdout_text,
                exc=exc
            )
            data['exception'] = type(exc).__name__

            return {
                'status': 'error',
                'cmd': self._cmd_name(is_tracing),
                'req_id': req_id,
                'error': str(exc),
                'data': data
            }

        except Exception as exc:
            # Other exceptions are unexpected - let them bubble up to run() handler
            raise RuntimeError() from exc

        assert isinstance(data, dict)
        if verify_enabled:
            suite_ids = self._updated_verifier_suite_ids(runtime, verify_before)
            with _capture_stdout():
                data['verify'] = self._run_verify_suites(runtime, suite_ids)

        return {
            'status': 'complete',
            'cmd': self._cmd_name(is_tracing),
            'req_id': req_id,
            'data': data
        }

    def _cmd_solve(self, request, *, session):
        req_id = request.get('req_id')
        quot = request.get('quot')
        test = request.get('test')
        source = request.get('source')
        limit = request.get('limit', 4096)
        timeout = request.get('timeout')

        session['commands_processed'] += 1
        runtime: Runtime = session['runtime']

        if not isinstance(quot, str) or quot.strip() == '':
            return self._make_invalid_response('solve', req_id, 'Missing or invalid required field: quot')
        if not isinstance(test, str) or test.strip() == '':
            return self._make_invalid_response('solve', req_id, 'Missing or invalid required field: test')
        if source is not None and not isinstance(source, str):
            return self._make_invalid_response('solve', req_id, 'Invalid source: expected string')

        if isinstance(limit, bool):
            return self._make_invalid_response('solve', req_id, 'Invalid limit: expected integer >= 1')
        try:
            limit = int(limit)
        except (TypeError, ValueError):
            return self._make_invalid_response('solve', req_id, 'Invalid limit: expected integer >= 1')
        if limit < 1:
            return self._make_invalid_response('solve', req_id, 'Invalid limit: expected integer >= 1')

        if timeout is None:
            timeout = 15.0
        if isinstance(timeout, bool):
            return self._make_invalid_response('solve', req_id, 'Invalid timeout: expected number of seconds')
        try:
            timeout_seconds = float(timeout)
        except (TypeError, ValueError):
            return self._make_invalid_response('solve', req_id, 'Invalid timeout: expected number of seconds')
        if timeout_seconds < 0 or not math.isfinite(timeout_seconds):
            return self._make_invalid_response('solve', req_id, 'Invalid timeout: must be a finite number >= 0')

        try:
            # Solve may execute paths that emit warnings to stdout; capture and drop
            # to keep protocol responses valid JSON.
            with _capture_stdout():
                solve_data = run_solve(
                    runtime,
                    quot=quot,
                    test=test,
                    source=source,
                    limit=limit,
                    timeout=timeout_seconds,
                )

            return {
                'status': 'complete',
                'cmd': 'solve',
                'req_id': req_id,
                'data': solve_data,
            }
        except SolveTimedOut as exc:
            data = {
                'exception': type(exc).__name__,
            }
            if exc.hint is not None:
                data['hint'] = exc.hint
            return {
                'status': 'interrupted',
                'cmd': 'solve',
                'req_id': req_id,
                'error': f'SolveTimedOut: Execution interrupted by timeout ({exc.timeout_seconds}s)',
                'data': data,
            }
        except SolveInputError as exc:
            return self._make_invalid_response('solve', req_id, str(exc))
        except JoyError as exc:
            if self.crash_logger is not None:
                self.crash_logger.capture_and_log(exc, request, is_joy_error=True)
            return {
                'status': 'error',
                'cmd': 'solve',
                'req_id': req_id,
                'error': str(exc),
                'data': {
                    'exception': type(exc).__name__,
                },
            }
        except Exception as exc:
            raise RuntimeError() from exc

    
    def _cmd_goodbye(self, request, *, session):
        req_id = request.get('req_id')
        sess_id = request.get('sess_id')

        # Get session stats
        commands_processed = session['commands_processed']
        start_time = session['start_time']
        execution_time_ms = int((time.time() - start_time) * 1000)
        
        # Remove session
        del self.sessions[sess_id]
        # Reset active runtime to baseline after ending a session.
        self.runtime = self._baseline_runtime
        
        return {
            'status': 'complete',
            'cmd': 'goodbye',
            'req_id': req_id,
            'data': {
                'commands_processed': commands_processed,
                'execution_time_ms': execution_time_ms
            }
        }


def main():
    """Entry point for the protocol server."""

    if os.getenv('COVERAGE_PROCESS_START'):
        import coverage
        coverage.process_startup()

    server = ProcessServer(log_crashes=True)
    server.run()


if __name__ == '__main__':
    main()
