## Copyright © 2026, Alex J. Champandard.  Licensed under AGPLv3; see LICENSE!

import math
import time

from collections import deque
from dataclasses import dataclass, field, replace
from itertools import count, product
from typing import Any

from joyfl.errors import JoyError, JoyNotImplementedError
from joyfl.library import Library
from joyfl.interpreter import interpret_step, validate_stack_before, _get_operation_signature
from joyfl.resolver import resolve_body
from joyfl.parser import parse
from joyfl.search import _do_bfs, _do_dfs
from joyfl.transform import (
    ProgramInterjectsInSearch,
    Search,
    has_pending_searches,
)
from joyfl.types import Operation, nil


class SolveInputError(Exception):
    """Invalid solve request payload or unresolved solve targets."""


DEFAULT_SOLVE_TIMEOUT_SECONDS = 15.0


def solve_user_hint(holes_count: int) -> str:
    if holes_count > 1:
        return "Multiple `???` holes were found; try solving one hole at a time."
    return (
        "Only stack manipulation is currently supported "
        "(e.g. item reordering, duplication, removal)."
    )


class SolveTimedOut(Exception):
    """Raised when solve execution exceeds the allowed timeout."""

    def __init__(self, *, timeout_seconds: float, holes_count: int | None = None):
        self.timeout_seconds = float(timeout_seconds)
        self.holes_count = holes_count
        self.hint = solve_user_hint(holes_count) if holes_count is not None else None
        super().__init__(f"Solve timed out after {self.timeout_seconds}s.")


class ProgramNotImplemented(JoyNotImplementedError):
    """Raised when unresolved `???` placeholder runs outside solver context."""


_HOLE_FACTORY_NAME = "???"
_HOLE_META_IS_PLACEHOLDER = "__solve_hole_placeholder__"
_HOLE_META_SITE_ID = "__solve_hole_site_id__"


class HolePlaceholderFactory:
    """Factory for token `???` that builds failing placeholder operations."""

    def __init__(self):
        self._cursor = 0

    def __call__(self) -> Operation:
        site_id = self._cursor
        self._cursor += 1

        def _raise_unimplemented(_stack) -> None:
            raise ProgramNotImplemented(
                f"Encountered unresolved `???` placeholder at site {site_id}. "
                "Run `solve` to bind hole fragments before execution."
            )

        return Operation(
            Operation.FUNCTION,
            _raise_unimplemented,
            _HOLE_FACTORY_NAME,
            {
                _HOLE_META_IS_PLACEHOLDER: True,
                _HOLE_META_SITE_ID: site_id,
            },
        )


def install_solve_placeholders(runtime) -> None:
    """Install persistent solve placeholder factories if missing or stale."""
    existing = runtime.library.factories.get(_HOLE_FACTORY_NAME)
    if isinstance(existing, HolePlaceholderFactory):
        return
    runtime.register_factory(_HOLE_FACTORY_NAME, HolePlaceholderFactory())


# Hard-coded hole vocabulary: primitive stack ops first, then stack quotations.
_HOLE_VOCAB_TERMS = (
    # Primitive stack ops (priority first)
    "swap",
    "dup",
    "pop",
    # Stack quotations from stdlib
    "popd",
    "swapd",
    "rollup",
    "rolldown",
    "dupd",
    "over",
)


@dataclass
class HoleSpec:
    hole_id: int
    alphabet_ops: list[Operation]
    alphabet_raw: list[list[Any]]
    library: Library
    expand_calls: int = 0
    option_fragments: dict[int, list[Any]] = field(default_factory=dict)
    option_programs: dict[int, list[Any]] = field(default_factory=dict)
    committed_fragment: list[Any] | None = None


class HoleToken(Search):
    """Search token representing one macro-level synthesis hole."""

    inputs = []
    arity = 0
    outputs = []
    valency = -1

    def __init__(self, spec: HoleSpec):
        self.spec = spec

    def expand(self):
        self.spec.expand_calls += 1
        seen: set[tuple] = set()
        option_idx = 0
        for fragment in _iter_alphabet_fragments(self.spec.alphabet_ops):
            key = _canonical_fragment_key(fragment, self.spec.library)
            if key in seen:
                continue
            seen.add(key)
            compiled = list(fragment)
            self.spec.option_fragments.setdefault(option_idx, _fragment_to_raw_words(compiled))
            self.spec.option_programs.setdefault(option_idx, compiled)
            yield compiled
            option_idx += 1

    def substitute_in_cases(self, cases: tuple['CaseState', ...], fragment: list[Any]) -> tuple['CaseState', ...]:
        """Splice fragment into all case queues paused on this same HoleSpec."""
        next_cases: list[CaseState] = []
        for case in cases:
            queue = deque(case.queue)
            if queue:
                token = queue[0]
                if not isinstance(token, HoleToken):
                    raise SolveInputError(f"Expected HoleToken at case boundary, got `{type(token).__name__}`.")
                if token.spec is self.spec:
                    queue.popleft()
                    queue.extendleft(reversed(fragment))
            next_cases.append(CaseState(stack=case.stack, queue=queue))
        return tuple(next_cases)


@dataclass
class CaseState:
    stack: Any
    queue: deque


@dataclass
class MacroState:
    """One parallel program state over all cases."""

    cases: tuple[CaseState, ...]
    choices: tuple[tuple[int, int], ...] = field(default_factory=tuple)  # (hole_id, option_idx)
    reached_holes: tuple[int, ...] = field(default_factory=tuple)
    cohort_cursor: int = -1

    def select_cohort(self, pending_heads: list['HoleToken']) -> 'HoleToken':
        """Pick the next hole to expand: maximize cohort size, round-robin tie-break."""
        by_spec: dict[int, list['HoleToken']] = {}
        for tok in pending_heads:
            by_spec.setdefault(id(tok.spec), []).append(tok)

        largest = max(len(group) for group in by_spec.values())
        tied = [group[0] for group in by_spec.values() if len(group) == largest]
        tied.sort(key=lambda t: (t.spec.hole_id, id(t.spec)))
        return next((tok for tok in tied if tok.spec.hole_id > self.cohort_cursor), tied[0])


@dataclass
class SolveSession:
    holes: list[HoleSpec] = field(default_factory=list)

    def register_hole(self, hole: HoleSpec) -> None:
        self.holes.append(hole)


_DRIVE_TRUNCATE = "truncate"
_DRIVE_REJECT = "reject"
_DRIVE_DONE = "done"
_DRIVE_EXPAND = "expand"

_MICRO_STEP_GUARD = 4096


class _CandidateStepBudgetExceeded(Exception):
    """Internal signal to prune a candidate that cannot reach next hole in time."""


def _iter_alphabet_fragments(alphabet: list[Operation]):
    """Yield operator sequences in increasing length, then lexicographic order."""
    yield []
    if not alphabet:
        return
    for length in count(1):
        for seq in product(alphabet, repeat=length):
            yield list(seq)


def _compile_fragment(runtime, spec: list[Any], *, filename: str) -> list[Any]:
    if not spec:
        return []

    meta = {"filename": filename, "lines": (1, 1)}
    tokens: list[tuple[str, str, dict]] = []
    for tok in spec:
        if isinstance(tok, str):
            term_tokens = None
            for typ, data in parse(tok, start="term", filename=filename):
                if typ == "term":
                    term_tokens = data
                    break
            if term_tokens is None:
                raise SolveInputError(f"Could not parse fragment token `{tok}`.")
            if len(term_tokens) != 1:
                raise SolveInputError(f"Fragment token `{tok}` must parse as one term.")
            ttyp, tval, _ = term_tokens[0]
            if ttyp not in ("NAME", "INTEGER", "FLOAT", "FRACTION", "CHAR", "STRING"):
                raise SolveInputError(f"Unsupported fragment token type `{ttyp}` for {tok!r}.")
            tokens.append((ttyp, tval, dict(meta)))
        elif isinstance(tok, int):
            tokens.append(("INTEGER", str(tok), dict(meta)))
        elif isinstance(tok, float):
            tokens.append(("FLOAT", repr(tok), dict(meta)))
        else:
            raise SolveInputError(f"Unsupported fragment token type: {type(tok).__name__} for {tok!r}")

    prg, _ = resolve_body(tokens, meta=dict(meta), lib=runtime.library, current_module=None)
    return prg


def _fragment_to_raw_words(fragment: list[Any]) -> list[Any]:
    raw: list[Any] = []
    for tok in fragment:
        if isinstance(tok, Operation):
            raw.append(tok.name)
        else:
            raw.append(tok)
    return raw


def _token_signature(tok: Any, depth: int) -> tuple:
    if isinstance(tok, Operation):
        return ("OP", int(tok.type), tok.name)
    if isinstance(tok, list):
        if depth <= 0:
            return ("LIST", "<depth>")
        return ("LIST", tuple(_token_signature(item, depth - 1) for item in tok))
    return ("LIT", repr(tok))


def _canonical_fragment_key(fragment: list[Any], lib, depth: int = 8) -> tuple:
    out: list[tuple] = []
    for tok in fragment:
        if isinstance(tok, Operation) and tok.type == Operation.EXECUTE and depth > 0:
            q = lib.get_quotation(tok.ptr, meta=tok.meta) if lib is not None else None
            if q is not None and q.program is not None:
                out.extend(_canonical_fragment_key(list(q.program), lib, depth - 1))
                continue
        out.append(_token_signature(tok, depth))
    return tuple(out)


def _drive_case_until_boundary(case: CaseState, lib, *, max_steps: int = _MICRO_STEP_GUARD) -> CaseState:
    stack = case.stack
    queue = deque(case.queue)
    remaining = max_steps
    while queue:
        head = queue[0]
        if isinstance(head, HoleToken):
            if head.spec.committed_fragment is not None:
                queue.popleft()
                queue.extendleft(reversed(head.spec.committed_fragment))
                continue
            break
        if isinstance(head, Search):
            raise SolveInputError(
                f"Parallel solver only supports HoleToken as case-level Search, got `{type(head).__name__}`."
            )
        if remaining <= 0:
            raise _CandidateStepBudgetExceeded()

        if isinstance(head, Operation):
            eff = _get_operation_signature(head)
            validate_stack_before(head, stack, eff=eff)

        try:
            stack, queue = interpret_step(queue, stack, lib=lib)
        except ProgramInterjectsInSearch as exc:
            raise SolveInputError("Parallel solver does not support ProgramInterjectsInSearch in cases.") from exc
        remaining -= 1

    return CaseState(stack=stack, queue=queue)


def _drive_all_cases_until_boundary(state: MacroState, runtime) -> tuple[str, MacroState, HoleToken | None]:
    progressed: list[CaseState] = []
    for case in state.cases:
        try:
            next_case = _drive_case_until_boundary(case, runtime.library)
            progressed.append(next_case)
        except _CandidateStepBudgetExceeded:
            return _DRIVE_TRUNCATE, state, None
        except JoyError:
            return _DRIVE_REJECT, state, None

    driven = replace(state, cases=tuple(progressed))

    pending_heads: list[HoleToken] = []
    for case in progressed:
        if not case.queue:
            continue
        head = case.queue[0]
        if not isinstance(head, HoleToken):
            raise SolveInputError(f"Expected HoleToken at case boundary, got `{type(head).__name__}`.")
        pending_heads.append(head)

    if not pending_heads:
        for case in progressed:
            if case.stack is None:
                return _DRIVE_REJECT, driven, None
            if has_pending_searches(case.stack, recursive=True):
                return _DRIVE_REJECT, driven, None
            if not isinstance(case.stack, tuple) or len(case.stack) != 2:
                return _DRIVE_REJECT, driven, None
            _, top = case.stack
            if not isinstance(top, bool) or top is not True:
                return _DRIVE_REJECT, driven, None
        return _DRIVE_DONE, driven, None

    return _DRIVE_EXPAND, driven, driven.select_cohort(pending_heads)


def _expand_hole_once(state: MacroState, canonical: HoleToken, *, max_options: int) -> tuple[list[MacroState], bool]:
    children: list[MacroState] = []
    if max_options < 1:
        return children, True

    hole_id = canonical.spec.hole_id
    iterator = iter(canonical.expand())
    option_idx = 0
    while option_idx < max_options:
        try:
            fragment = next(iterator)
        except StopIteration:
            return children, False

        next_cases = canonical.substitute_in_cases(state.cases, fragment)
        children.append(
            MacroState(
                cases=next_cases,
                choices=state.choices + ((hole_id, option_idx),),
                reached_holes=state.reached_holes + (hole_id,),
                cohort_cursor=hole_id,
            )
        )
        option_idx += 1

    # We hit max_options; detect if this search has additional options beyond bound.
    try:
        next(iterator)
        return children, True
    except StopIteration:
        return children, False


class ParallelMacroSearch(Search):
    """Macro-level search token: runs all cases to the next hole boundary."""

    inputs = [MacroState]
    arity = 1
    outputs = []
    valency = -1

    def __init__(
        self,
        runtime,
        session: SolveSession,
        *,
        max_options_per_hole: int,
        timeout_seconds: float = DEFAULT_SOLVE_TIMEOUT_SECONDS,
        holes_count: int | None = None,
    ):
        self.runtime = runtime
        self.session = session
        self.max_options_per_hole = max_options_per_hole
        self.timeout_seconds = float(timeout_seconds)
        self.holes_count = holes_count
        self.deadline_ns = time.monotonic_ns() + int(math.ceil(self.timeout_seconds * 1_000_000_000))
        self.truncated = False

    def _raise_if_timed_out(self) -> None:
        if time.monotonic_ns() >= self.deadline_ns:
            raise SolveTimedOut(timeout_seconds=self.timeout_seconds, holes_count=self.holes_count)

    def _commit_choices(self, choices: tuple[tuple[int, int], ...]) -> None:
        """Temporarily mark committed holes so they are transparent during driving."""
        for hole_id, option_idx in choices:
            spec = self.session.holes[hole_id]
            fragment = spec.option_programs.get(option_idx)
            if fragment is not None:
                spec.committed_fragment = fragment

    def _uncommit_all(self) -> None:
        for hole in self.session.holes:
            hole.committed_fragment = None

    def expand(self, state: MacroState):
        self._raise_if_timed_out()

        self._commit_choices(state.choices)
        try:
            status, driven, canonical = _drive_all_cases_until_boundary(state, self.runtime)
        finally:
            self._uncommit_all()

        if status == _DRIVE_TRUNCATE:
            self.truncated = True
            return
        if status == _DRIVE_REJECT:
            return
        if status == _DRIVE_DONE:
            yield [driven]
            return

        assert status == _DRIVE_EXPAND and canonical is not None
        children, truncated = _expand_hole_once(
            driven,
            canonical,
            max_options=self.max_options_per_hole,
        )
        if truncated:
            self.truncated = True
        for child in children:
            yield [child, self]


def _placeholder_site_id(tok: Any) -> int | None:
    if not isinstance(tok, Operation):
        return None
    if tok.name != _HOLE_FACTORY_NAME:
        return None
    meta = tok.meta if isinstance(tok.meta, dict) else {}
    if meta.get(_HOLE_META_IS_PLACEHOLDER) is not True:
        return None
    site_id = meta.get(_HOLE_META_SITE_ID)
    if not isinstance(site_id, int) or site_id < 0:
        raise SolveInputError("Malformed metadata for `???` placeholder operation.")
    return site_id


def _collect_reachable_quotations(runtime, *, roots: list[Any]) -> list[Any]:
    lib = runtime.library
    visited: set[int] = set()
    ordered: list[Any] = []

    def _visit_tokens(tokens: list[Any]) -> None:
        for tok in tokens:
            if isinstance(tok, list):
                _visit_tokens(tok)
                continue
            if isinstance(tok, Operation) and tok.type == Operation.EXECUTE:
                callee = lib.get_quotation(tok.ptr, meta=tok.meta)
                if callee is None or callee.program is None:
                    continue
                _visit_quotation(callee)

    def _visit_quotation(quotation: Any) -> None:
        if quotation is None or quotation.program is None:
            return
        qid = id(quotation)
        if qid in visited:
            return
        visited.add(qid)
        ordered.append(quotation)
        _visit_tokens(quotation.program)

    for root in roots:
        _visit_quotation(root)
    return ordered


def _collect_hole_sites(tokens: list[Any], out: set[int]) -> None:
    for tok in tokens:
        if isinstance(tok, list):
            _collect_hole_sites(tok, out)
            continue
        site_id = _placeholder_site_id(tok)
        if site_id is not None:
            out.add(site_id)


def _rewrite_tokens_with_holes(tokens: list[Any], tokens_by_site: dict[int, HoleToken]) -> list[Any]:
    rewritten: list[Any] = []
    for tok in tokens:
        if isinstance(tok, list):
            rewritten.append(_rewrite_tokens_with_holes(tok, tokens_by_site))
            continue
        site_id = _placeholder_site_id(tok)
        if site_id is None:
            rewritten.append(tok)
            continue
        hole_token = tokens_by_site.get(site_id)
        if hole_token is None:
            raise SolveInputError(f"Unbound `???` placeholder site {site_id} during solve traversal.")
        rewritten.append(hole_token)
    return rewritten


def _bind_holes_for_solve(runtime, *, roots: list[Any], session: SolveSession) -> tuple[int, list[tuple[Any, list[Any]]]]:
    quotations = _collect_reachable_quotations(runtime, roots=roots)
    hole_sites: set[int] = set()
    for quotation in quotations:
        assert quotation.program is not None
        _collect_hole_sites(quotation.program, hole_sites)

    if not hole_sites:
        return 0, []

    alphabet_raw, alphabet_ops = _compile_hole_vocab_ops(runtime)
    tokens_by_site: dict[int, HoleToken] = {}
    for hole_id, site_id in enumerate(sorted(hole_sites)):
        hole = HoleSpec(
            hole_id=hole_id,
            alphabet_ops=alphabet_ops,
            alphabet_raw=alphabet_raw,
            library=runtime.library,
        )
        session.register_hole(hole)
        tokens_by_site[site_id] = HoleToken(hole)

    patched: list[tuple[Any, list[Any]]] = []
    success = False
    try:
        for quotation in quotations:
            assert quotation.program is not None
            original = quotation.program
            quotation.program = _rewrite_tokens_with_holes(original, tokens_by_site)
            patched.append((quotation, original))
        success = True
    finally:
        if not success:
            _restore_patched_programs(patched)
    return len(hole_sites), patched


def _restore_patched_programs(patched: list[tuple[Any, list[Any]]]) -> None:
    for quotation, original in reversed(patched):
        quotation.program = original


def _compile_hole_vocab_ops(runtime) -> tuple[list[list[Any]], list[Operation]]:
    """Compile hard-coded hole vocabulary terms to Operation tokens."""
    compiled_raw: list[list[Any]] = []
    compiled_ops: list[Operation] = []
    for term in _HOLE_VOCAB_TERMS:
        spec = [term]
        program = _compile_fragment(runtime, spec, filename="<solve:vocab>")
        if len(program) != 1 or not isinstance(program[0], Operation):
            raise SolveInputError(f"Hole vocabulary term `{term}` is not a single executable operation.")
        compiled_raw.append(list(spec))
        compiled_ops.append(program[0])

    return compiled_raw, compiled_ops


def _options_per_hole_from_limit(limit: int, holes_count: int) -> int:
    """Translate total combination budget into per-hole option bound.

    If each hole considers at most `k` options, then combinations are <= k^holes_count.
    We pick the largest `k` such that k^holes_count <= limit.
    """
    if holes_count < 1:
        return 1
    return max(1, round(limit ** (1.0 / float(holes_count))))


def _resolve_quotation(runtime, quot: str) -> tuple[str, Any]:
    q = runtime.library.get_quotation(quot)
    if q is None:
        raise SolveInputError(f"Unknown quotation `{quot}`.")
    if q.program is None:
        raise SolveInputError(f"Quotation `{quot}` is declared but not implemented.")
    return quot, q


def _resolve_suite_id(runtime, test: str) -> str:
    if test not in runtime.library.verifiers:
        raise SolveInputError(f"Unknown verifier suite `{test}`.")
    return test


def _build_case_states(verifier_suite: list[Any]) -> list[CaseState]:
    cases: list[CaseState] = []
    for verifier in verifier_suite:
        if verifier.program is None:
            raise SolveInputError("Verifier suite contains an unimplemented quotation.")
        cases.append(CaseState(stack=nil, queue=deque(list(verifier.program))))
    if len(cases) == 0:
        raise SolveInputError("Verifier suite contains no tests.")
    return cases


def _collect_choice_vector(solution: MacroState, holes_count: int) -> list[int] | None:
    picks: list[int | None] = [None] * holes_count
    for hole_id, option_idx in solution.choices:
        if 0 <= hole_id < holes_count and picks[hole_id] is None:
            picks[hole_id] = option_idx
    if any(p is None for p in picks):
        return None
    return list(picks)


def _run_parallel(
    runtime,
    initial_cases: list[CaseState],
    *,
    session: SolveSession,
    strategy: str,
    max_options_per_hole: int,
    timeout_seconds: float = DEFAULT_SOLVE_TIMEOUT_SECONDS,
    holes_count: int | None = None,
) -> tuple[list[MacroState], bool]:
    seed = MacroState(
        cases=tuple(CaseState(stack=c.stack, queue=deque(c.queue)) for c in initial_cases),
        cohort_cursor=-1,
    )
    root = ParallelMacroSearch(
        runtime,
        session,
        max_options_per_hole=max_options_per_hole,
        timeout_seconds=timeout_seconds,
        holes_count=holes_count,
    )

    if strategy == "bfs":
        results = _do_bfs([seed, root], limit=-1, make_copy=False, lib=runtime.library)
    elif strategy == "dfs":
        results = _do_dfs([seed, root], limit=-1, make_copy=False, lib=runtime.library)
    else:
        raise SolveInputError(f"Unknown strategy `{strategy}`.")

    solved = [result for result in results if isinstance(result, MacroState)]
    return solved, bool(root.truncated)


def run_solve(
    runtime,
    *,
    quot: str,
    test: str,
    source: str | None = None,
    limit: int = 4096,
    timeout: float = DEFAULT_SOLVE_TIMEOUT_SECONDS,
) -> dict:
    """Run solver over already-loaded runtime source, quotation, and verifier suite."""

    if isinstance(limit, bool) or not isinstance(limit, int) or limit < 1:
        raise SolveInputError("Invalid limit: expected integer >= 1")
    timeout_seconds = timeout

    started = time.monotonic_ns()
    patched_programs: list[tuple[Any, list[Any]]] = []

    try:
        if source is not None:
            if not isinstance(source, str):
                raise SolveInputError("Invalid source: expected string")
            runtime.load(source, filename="<SOLVE>", validate=True)

        quot_name, target_quot = _resolve_quotation(runtime, quot)
        suite_id = _resolve_suite_id(runtime, test)
        verifier_suite = runtime.library.verifiers[suite_id]

        session = SolveSession()
        holes_count, patched_programs = _bind_holes_for_solve(
            runtime,
            roots=[target_quot, *list(verifier_suite)],
            session=session,
        )
        if holes_count == 0:
            raise SolveInputError("No `???` holes were found in loaded source.")

        cases = _build_case_states(verifier_suite)

        max_options_per_hole = _options_per_hole_from_limit(limit, holes_count)
        solved, _truncated = _run_parallel(
            runtime,
            cases,
            session=session,
            strategy="bfs",
            max_options_per_hole=max_options_per_hole,
            timeout_seconds=timeout_seconds,
            holes_count=holes_count,
        )

        if solved:
            candidate = solved[0]
            choice_vector = _collect_choice_vector(candidate, holes_count=holes_count)
            if choice_vector is None:
                solve_status = "incomplete"
                choices = None
                fragments = None
            else:
                solve_status = "sat"
                choices = choice_vector
                fragments = [list(session.holes[i].option_fragments[idx]) for i, idx in enumerate(choice_vector)]
        else:
            # If we hit per-hole option caps while still unsolved, the result is
            # bounded-incomplete rather than proof of unsatisfiability.
            solve_status = "incomplete" if _truncated else "unsat"
            choices = None
            fragments = None

        return {
            "solve_status": solve_status,
            "quotation": quot_name,
            "suite": suite_id,
            "choices": choices,
            "fragments": fragments,
            "hint": solve_user_hint(holes_count),
            "elapsed_ms": int((time.monotonic_ns() - started) / 1_000_000),
        }
    finally:
        _restore_patched_programs(patched_programs)
