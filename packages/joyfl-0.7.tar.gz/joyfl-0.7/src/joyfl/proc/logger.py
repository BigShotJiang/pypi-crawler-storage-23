## Copyright © 2025-2026, Alex J. Champandard.  Licensed under AGPLv3; see LICENSE!

import fcntl
import json
import time
import uuid
import hashlib
from functools import wraps
from pathlib import Path

# Path for crash logs
CRASH_LOG_PATH = Path('/tmp/joyfl-proc.log.jsonl')


class CrashLogger:
    """Toggleable crash logger for logging exceptions to JSONL file."""
    
    def __init__(self, enabled=True, log_path=CRASH_LOG_PATH):
        """Initialize crash logger.
        
        Args:
            enabled: If False, logging is disabled (default True)
            log_path: Path to crash log file (default /tmp/joyfl-proc.log.jsonl)
        """
        self.enabled = enabled
        self.log_path = log_path
    
    def capture_and_log(self, exc, request=None, is_joy_error=False):
        """Capture crash and log to file if enabled.
        
        Args:
            exc: The exception that was caught
            request: The request dict (optional, for context)
            is_joy_error: True if this is a JoyError (expected failures), False otherwise
        
        Returns:
            crash_data dict if logging is enabled, None otherwise
        """
        if not self.enabled:
            return None
        
        crash_data = _capture_crash(exc, request, is_joy_error)
        log_crash_to_file(crash_data, self.log_path)
        return crash_data


def _capture_crash_frames(exc):
    """Extract structured traceback data without string formatting."""
    frames = []
    tb = exc.__traceback__
    
    while tb is not None:
        frame = tb.tb_frame
        # Truncate locals to avoid huge logs
        locals_dict = {}
        for k, v in frame.f_locals.items():
            try:
                locals_dict[k] = str(v)[:200]
            except Exception:
                locals_dict[k] = '<unrepresentable>'
        
        frames.append({
            'filename': frame.f_code.co_filename,
            'lineno': tb.tb_lineno,
            'function': frame.f_code.co_name,
            'locals': locals_dict,
        })
        tb = tb.tb_next
    
    return {
        'error_type': type(exc).__name__,
        'error_message': str(exc),
        'frames': frames,
        'leaf': frames[-1] if frames else None,
        'leaf_minus_one': frames[-2] if len(frames) > 1 else None,
        'depth': len(frames)
    }


def _capture_crash(exc, request=None, is_joy_error=False):
    """Capture structured crash data for logging and analysis.
    
    Args:
        exc: The exception that was caught
        request: The request dict (optional, for context)
        is_joy_error: True if this is a JoyError (expected failures), False otherwise
    """
    tb_data = _capture_crash_frames(exc)
    
    context = {}
    if request:
        context = {
            'sess_id': request.get('sess_id'),
            'req_id': request.get('req_id'),
            'cmd': request.get('cmd'),
        }
        source = request.get('source')
        if source:
            context['source_hash'] = hashlib.sha256(source.encode()).hexdigest()[:16]
            context['source_snippet'] = source[:100]
    
    return {
        'crash_id': str(uuid.uuid4()),
        'timestamp': time.time(),
        'error': tb_data['error_type'],
        'message': tb_data['error_message'],
        'traceback': tb_data['frames'],
        'leaf': tb_data['leaf'],
        'leaf_minus_one': tb_data['leaf_minus_one'],
        'depth': tb_data['depth'],
        'context': context,
        'category': 'joy_error' if is_joy_error else 'exception'
    }


def log_crash_to_file(crash_data, log_path=CRASH_LOG_PATH):
    """Write crash to log file with file locking (one JSON per line).
    
    Args:
        crash_data: The crash data dict to write
        log_path: Path to log file (default /tmp/joyfl-proc.log.jsonl)
    """
    # Use separators=(',', ':') to strip whitespace
    json_line = json.dumps(crash_data, separators=(',', ':'))
    
    log_path.parent.mkdir(parents=True, exist_ok=True)
    
    with open(log_path, 'a') as f:
        # Acquire exclusive lock (blocking)
        fcntl.flock(f, fcntl.LOCK_EX)
        try:
            f.write(json_line + '\n')
        finally:
            # Release lock
            fcntl.flock(f, fcntl.LOCK_UN)
