## Copyright © 2025, Alex J. Champandard.  Licensed under AGPLv3; see LICENSE! ⚘
"""
Search Primitives for Joy
=========================

This module provides an implementation of search algorithms and supporting objects operators for
non-deterministic variants of Joy.  These building blocks can be used to implement comptime features
or optimization passes in particular.

Search Classes
--------------
- ValuesSearch:      Expands to each element from a provided list.
- OnceGate:          Gate that allows only the first branch to succeed.
- LengthenSearch:    Yields quotations of increasing length for iterative deepening.
- InterleaveSearch:  Filter that expands quotations, interleaves results round-robin.
- FallbackSearch:    Filter that expands quotations sequentially (fallback pattern).
- TakeKSearch:       Filter that takes at most K expansions (truncates, no continuation).
- SampleKSearch:     Filter that samples K expansions with continuation for the rest.
- CollectKSearch:    Controller for collecting K solutions across branches.
- CollectKGate:      Per-branch gate contributing to a shared CollectKSearch.
- TransformRecursivelySearch: Recursively expands Searches in nested quotations.

Joy Operators
-------------
- search.dfs:        Depth-first search.
- search.bfs:        Breadth-first search.
- search.fail!:      Prune branch if predicate is false.
- search.require-eq: Prune branch if top two values differ.
"""

from typing import Any, Iterator
from collections import deque, defaultdict

from . import api as J
from .types import nil, Value, validate_signature_inputs
from .formatting import stack_to_list

from .transform import (
    Node,
    Search,
    SearchWrapper,
    _WrappingSearchBase,
    Expansion,
    PruneReason,
    ReportStatus,
    Operation,
    SlateSelection,
    _as_expansion,
    transform_step,
    get_search_signature,
    has_pending_searches,
    _has_searches_in_list,
    ProgramExplicitlyFailed,
    ProgramInterjectsInSearch,
)


# ─────────────────────────────────────────────────────────────────────────────────────────────
# Concrete Search Implementations
# ─────────────────────────────────────────────────────────────────────────────────────────────

class ValuesSearch(Search):
    """Expands to each value from a provided list, one branch per element.
    Stateless—every expand() yields all alternatives from scratch.
    """
    inputs = [list]
    arity = 1
    outputs = [object]
    valency = 1

    def expand(self, vals: list):
        for v in vals:
            yield [v]

    def peek(self, vals: list) -> int:
        return len(vals)


class OnceGate(Search):
    """Gate that allows only the first branch to succeed, pruning all subsequent.
    Takes Value input so upstream Searches expand first (Value excludes Search).
    """
    inputs = [Value]
    arity = 1
    outputs = [Value]
    valency = 1

    def __init__(self):
        self._fired: bool = False

    def expand(self, value: Value):
        if self._fired:
            return  # Prune: already fired
        self._fired = True
        yield [value]  # Pass through the value

    def on_branch(self, *, upstream: bool, count: int) -> None:
        assert self._is_planted

    def peek(self, value: Value) -> int:
        return 0 if self._fired else 1


class ConsumedArgsWrapSearch(SearchWrapper):
    """Wraps a Search with pre-bound arguments for lazy expansion or continuations.
    Requires no stack consumption at expand time—args were captured at construction.
    """
    inputs = []
    arity = 0

    def __init__(self, inner: Search, *args):
        super().__init__(inner)
        self.args = args
        # Forward outputs/valency from inner
        self.outputs = inner.outputs
        self.valency = inner.valency

    def expand(self):
        return self._inner.expand(*self.args)


class ConsumeArgsMakeSearch(Search):
    """Consumes values from the stack then yields a configured Search instance.
    Enables factories that need runtime args to determine outputs/valency.
    """
    outputs = [Search]
    valency = 1

    def __init__(self, search_class: type, inputs: list):
        self.search_class = search_class
        self.inputs = inputs
        self.arity = len(inputs)

    def expand(self, *args):
        yield [self.search_class(*args)]


class LengthenSearch(Search):
    """Yields quotations of increasing length for iterative deepening, with a lazy
    continuation-based design to defer work and minimize frontier size.  The
    continuation is appended to the SAME branch's program tail, not as a
    sibling branch. This ensures it survives any frontier manipulation.
    """
    inputs = [list, int]
    arity = 2
    outputs = [list | Search]
    valency = 1

    def expand(self, base_quot: list, max_length: int, cur_length: int = 1):
        """Yield branches for each length from cur_length to max_length."""
        if max_length < 1:
            return
        
        # Current length quotation, it's always returned first.
        quot = base_quot * cur_length
        yield Expansion([quot], cost=0.0, heuristic=0.0)

        # If more lengths available, yield a continuation with pre-bound arguments.
        if cur_length < max_length:
            wrapped = ConsumedArgsWrapSearch(self, base_quot, max_length, cur_length + 1)
            yield Expansion([wrapped], cost=0.0, heuristic=0.0)


    def peek(self, base_quot: list, max_length: int, cur_length: int = 1) -> int:
        return max(0, max_length - cur_length + 1) if max_length >= 1 else 0


def _expand_quotation_shallow(quotation: list, *, limit: int | None = None) -> Iterator[list]:
    """Expands only the rightmost top-level Search in a quotation (shallow).
    Scans right-to-left per QTM semantics; yields quotation as-is if no Search.
    """
    # Find rightmost Search (right-to-left, top level only)
    for idx in range(len(quotation) - 1, -1, -1):
        if isinstance(quotation[idx], Search):
            break
    else:
        yield quotation  # No Search found
        return
    
    # Extract args from prefix, expand Search, reassemble
    tok = quotation[idx]
    prefix, suffix = quotation[:idx], quotation[idx + 1:]
    eff = get_search_signature(tok)
    args = prefix[-eff["arity"]:] if eff["arity"] > 0 else []
    base = prefix[:-eff["arity"]] if eff["arity"] > 0 else prefix
    
    count = 0
    for result in tok.expand(*args):
        exp = _as_expansion(result)
        yield Expansion(base + exp.fragment + suffix, cost=exp.cost, heuristic=exp.heuristic)
        count += 1
        if limit is not None and count >= limit:
            break


def _get_rightmost_search_signature(quotations: list) -> tuple[list, int]:
    """Get outputs/valency from quotations ending in a Search, asserting consistency."""

    assert quotations and all(isinstance(q, list) and q for q in quotations)
    searches = [q[-1] for q in quotations]
    assert all(isinstance(s, Search) for s in searches)

    sigs = [get_search_signature(s) for s in searches]
    assert len(set(sig["valency"] for sig in sigs)) == 1, "Quotation signatures must have same valency."
    return sigs[0]["outputs"], sigs[0]["valency"]


class QuotationsFilterSearch(Search):
    """Base for shallow filter searches that operate over a list of quotations.
    Computes outputs/valency from the quotations' rightmost Searches at init.
    """
    inputs = []
    arity = 0

    def __init__(self, quotations: list):
        self.quotations = quotations
        self.outputs, self.valency = _get_rightmost_search_signature(quotations)


class InterleaveSearch(QuotationsFilterSearch):
    """Interleaves expansions from multiple quotations in round-robin order.
    Fair scheduling: each quotation gets one expansion per round until exhausted.
    """

    def expand(self):
        generators = [_expand_quotation_shallow(q) for q in self.quotations if isinstance(q, list)]
        while generators:
            for gen in generators[:]:
                try:
                    yield next(gen)
                except StopIteration:
                    generators.remove(gen)


class FallbackSearch(QuotationsFilterSearch):
    """Expands quotations sequentially: exhaust all from first, then second, etc.
    Fallback semantics: later quotations only tried after earlier ones complete.
    """

    def expand(self):
        for quot in self.quotations:
            if isinstance(quot, list):
                yield from _expand_quotation_shallow(quot)


class CollectKGate(Search):
    """Per-branch gate that contributes one value to its parent CollectKSearch.
    Tracks pending branches; emits accumulated list when K values collected.
    """
    inputs = [Value]
    arity = 1
    outputs = [list]
    valency = 1

    def __init__(self, controller: 'CollectKSearch'):
        self._controller = controller

    def expand(self, value: Value):
        ctrl = self._controller
        if not ctrl._configured or ctrl._done:
            return

        assert ctrl._acc is not None

        # Contribute this value to the shared accumulator.
        ctrl._acc.append(value)
        ctrl._pending -= 1

        # Check if we've collected K values
        if len(ctrl._acc) >= ctrl._k:
            ctrl._done = True
            yield [ctrl._acc]
            return

        # Not enough yet - if other branches pending, continue with omitted output
        if ctrl._pending > 0:
            yield [None]  # Filtered at splice time by transform_step
            return

        # No more branches and not enough values - prune (yield nothing)

    def on_branch(self, *, upstream: bool, count: int) -> None:
        ctrl = self._controller
        if not ctrl._configured or ctrl._done:
            return
        if not upstream:
            return
        # This node is being duplicated upstream into `count` children.
        ctrl._pending += max(0, count - 1)

    def on_prune(self, reason, *, trace=None, count: int = 1) -> None:
        ctrl = self._controller
        if not ctrl._configured or ctrl._done:
            return
        ctrl._pending -= count


class CollectKSearch(Search):
    """Controller that collects K solutions from across search branches.
    Spawns CollectKGates that coordinate via shared state to accumulate results.
    """
    inputs = [int]
    arity = 1
    outputs = [CollectKGate]
    valency = 1

    def __init__(self):
        self._configured: bool = False
        self._acc: list[Any] | None = None
        self._k: int = 0
        self._pending: int = 0
        self._done: bool = False

    def expand(self, k: int):
        if k < 1:
            return

        if not self._configured:
            self._acc = []
            self._k = k
            self._done = False
            self._configured = True
            self._pending = 1

        yield [CollectKGate(self)]

    def peek(self, k: int) -> int | None:
        if not self._configured:
            return None
        if self._done:
            return 0
        return None


class TakeKSearch(Search):
    """Filter that takes at most K expansions from a quotation's rightmost Search.
    Truncates after K - remaining expansions are discarded (like list take).
    
    If the quotation's rightmost Search requires more args than the quotation prefix
    provides, the missing args are consumed from the stack at expansion time.
    The input types are copied from the inner Search to ensure proper type validation.
    """

    def __init__(self, quotation: list, k: int):
        self.quotation = quotation
        self.k = k
        self.outputs, self.valency = _get_rightmost_search_signature([quotation])
        
        # Find rightmost Search and compute how many args are missing from prefix
        for idx in range(len(quotation) - 1, -1, -1):
            if isinstance(quotation[idx], Search):
                inner_search = quotation[idx]
                prefix_len = idx  # items before the Search
                inner_sig = get_search_signature(inner_search)
                inner_arity = inner_sig["arity"]
                self._stack_arity = max(0, inner_arity - prefix_len)
                # Copy actual input types from inner Search (not covered by prefix)
                inner_inputs = inner_sig["inputs"]
                self.inputs = inner_inputs[:self._stack_arity]
                break
        else:
            self._stack_arity = 0
            self.inputs = []
        
        self.arity = self._stack_arity

    def expand(self, *args):
        if self.k >= 1:
            # Prepend stack args to quotation so inner Search has all its args
            augmented = list(args) + self.quotation
            yield from _expand_quotation_shallow(augmented, limit=self.k)

    def peek(self, *args) -> int | None:
        return min(self.k, 1) if self.k >= 1 else 0


class SampleKSearch(_WrappingSearchBase):
    """Samples K expansions from a quotation's rightmost Search, with continuation.
    Yields K results then a continuation Search to get the remaining expansions.
    
    If the quotation's rightmost Search requires more args than the quotation prefix
    provides, the missing args are consumed from the stack at expansion time.
    The input types are copied from the inner Search to ensure proper type validation.
    
    Unlike TakeKSearch which discards remaining expansions, SampleKSearch preserves
    them via a continuation that can be explored later.
    """

    def traverse(self, callback) -> None:
        """This function must expose the inner 'graph' that's search-relevant, so we
        traverse the various quotation lists stored internally.
        """
        super().traverse(callback)

        for field in ['quotation', '_base', '_suffix']:
            if (value := getattr(self, field)) and isinstance(value, list):
                if replacement := callback(value):
                    setattr(self, field, replacement)

    def __init__(self, quotation: list, k: int, *, _gen=None, _inner=None, _base=None, _suffix=None, _offset: int = 0):
        self.quotation = quotation
        self.k = k
        self._gen = _gen  # Pre-initialized generator for continuations
        self._inner = _inner  # Inner Search (for continuations)
        self._base = _base  # Quotation base prefix (for continuations)
        self._suffix = _suffix  # Quotation suffix (for continuations)
        self._offset = _offset  # Global expansion index offset for this batch
        
        # Continuation mode: no args needed, generator already has them
        if _gen is not None:
            self.inputs = []
            self._stack_arity = 0
            self.arity = 0
            # Outputs can be inner type OR continuation Search
            inner_outputs = _inner.outputs if _inner else [object]
            self.outputs = [inner_outputs[0] | Search] if inner_outputs else [Search]
            self.valency = _inner.valency if _inner else 1
            return
        
        inner_outputs, self.valency = _get_rightmost_search_signature([quotation])
        # Outputs can be inner type OR continuation Search
        self.outputs = [inner_outputs[0] | Search] if inner_outputs else [Search]
        
        # Find rightmost Search and compute how many args are missing from prefix
        for idx in range(len(quotation) - 1, -1, -1):
            if isinstance(quotation[idx], Search):
                self._inner = quotation[idx]
                prefix_len = idx  # items before the Search
                inner_sig = get_search_signature(self._inner)
                inner_arity = inner_sig["arity"]
                self._stack_arity = max(0, inner_arity - prefix_len)
                # Copy actual input types from inner Search (not covered by prefix)
                inner_inputs = inner_sig["inputs"]
                self.inputs = inner_inputs[:self._stack_arity]
                # Store base and suffix for reconstructing results
                self._base = quotation[:max(0, idx - inner_arity)]
                self._suffix = quotation[idx + 1:]
                break
        else:
            self._stack_arity = 0
            self.inputs = []
            self._inner = None
            self._base = []
            self._suffix = []
        
        self.arity = self._stack_arity

    def report(self, before: tuple, after: tuple, *, status: ReportStatus) -> None:
        """Forward report() to inner with global expansion_idx semantics."""
        if self._inner is None:
            return
        assert self._inner._is_planted, f"FATAL: [search] {self} -> {self._inner}"

        assert after and isinstance(after[0], SlateSelection), (
            f"Expected wrapper-adjacent SlateSelection at after[0] for {self}, got {after[:3]!r}"
        )
        sel: SlateSelection = after[0]

        # Continuation choice is not an inner expansion; do not forward it.
        if int(sel.expansion_idx) == int(self.k):
            return

        rewritten = SlateSelection(
            slate_id=int(sel.slate_id),
            expansion_idx=int(self._offset) + int(sel.expansion_idx),
        )

        # Sampling is intended to preserve the exact same report() semantics as an
        # unwrapped inner search. We therefore strip SampleKSearch + SlateSelection
        # artifacts tied to this inner so the forwarded before/after match the
        # trace shape the inner would see without wrapping.
        def _strip_related_samplek(trace: tuple) -> tuple:
            out = []
            i = 0
            while i < len(trace):
                item = trace[i]
                if isinstance(item, SampleKSearch) and item._inner is self._inner:
                    i += 1
                    if i < len(trace) and isinstance(trace[i], SlateSelection):
                        i += 1
                    continue
                out.append(item)
                i += 1
            return tuple(out)

        filtered_before = _strip_related_samplek(before)
        filtered_after_tail = _strip_related_samplek(after[1:])

        self._inner.report(filtered_before, (rewritten,) + filtered_after_tail, status=status)

    def expand(self, *args):
        if self.k < 1:
            return
        
        # Use existing generator (continuation) or create new one
        if self._gen is not None:
            gen = self._gen
        elif self._inner is not None:
            # Compute full args for inner Search
            augmented = list(args) + self.quotation
            # Find inner Search index and extract its args
            for idx in range(len(augmented) - 1, -1, -1):
                if isinstance(augmented[idx], Search):
                    inner_sig = get_search_signature(augmented[idx])
                    inner_arity = inner_sig["arity"]
                    inner_args = augmented[max(0, idx - inner_arity):idx] if inner_arity > 0 else []
                    gen = augmented[idx].expand(*inner_args)
                    break
            else:
                return
        else:
            return
        
        count = 0
        for result in gen:
            # Reconstruct full quotation result with base + expansion + suffix
            exp = _as_expansion(result)
            yield Expansion(self._base + exp.fragment + self._suffix, cost=exp.cost, heuristic=exp.heuristic)
            count += 1
            if count >= self.k:
                # Create continuation with remaining generator
                continuation = SampleKSearch(
                    self.quotation, self.k,
                    _gen=gen,
                    _inner=self._inner,
                    _base=self._base,
                    _suffix=self._suffix,
                    _offset=self._offset + self.k,
                )
                yield Expansion([continuation], cost=0.0, heuristic=0.0)
                return

    def peek(self, *args) -> int | None:
        return min(self.k, 1) if self.k >= 1 else 0


# ─────────────────────────────────────────────────────────────────────────────────────────────
# Recursive Quotation Expansion
# ─────────────────────────────────────────────────────────────────────────────────────────────

class NoTransformationsPossible(Exception): pass

class TransformRecursivelySearch(Search):
    """Recursively expands Searches in nested quotations and yield all transformed quotations.
    Scans right-to-left at each level; re-schedules self until no Searches remain.
    """

    inputs = [list]
    arity = 1
    outputs = [list, Search | Operation]
    valency = 2

    def _can_expand_search(self, search: Search, program: list, search_index: int) -> tuple[bool, str]:
        eff = get_search_signature(search)
        inputs = eff["inputs"]
        prefix = program[search_index-eff["arity"]:search_index]
        if len(inputs) > len(program):
            assert len(prefix) == eff["arity"]

        return validate_signature_inputs(inputs, prefix, str(search))

    def _do_expand_search(self, search: Search, program: list, search_index: int) -> Iterator[Expansion]:
        eff = get_search_signature(search)
        prefix = program[search_index-eff["arity"]:search_index]
        assert len(prefix) == eff["arity"]
        yield from search.expand(*prefix)

    def _traverse_and_expand(self, quotation: list, depth=0) -> Iterator[Expansion]:
        count = 0
        for idx in range(len(quotation) - 1, -1, -1):
            tok = quotation[idx]
            if isinstance(tok, list):
                for exp in self._traverse_and_expand(tok, depth=depth+1):
                    count += 1
                    yield Expansion(quotation[:idx] + [exp.fragment] + quotation[idx+1:], exp.cost, exp.heuristic)
            elif isinstance(tok, Search):
                if (err := self._can_expand_search(tok, quotation, idx)) and not err[0]:
                    print(f"WARNING: transform_recursively_search() cannot expand `{tok}` at index {idx}: {err[1]}.")
                    continue
                eff = get_search_signature(tok)
                for exp in self._do_expand_search(tok, quotation, idx):
                    exp = _as_expansion(exp)
                    count += 1
                    yield Expansion(quotation[:idx - eff["arity"]] + exp.fragment + quotation[idx+1:], cost=exp.cost, heuristic=exp.heuristic)
            if count > 0: return

        if count == 0 and depth == 0:
            raise NoTransformationsPossible()

    def expand(self, program: list) -> Iterator[Expansion]:
        try:
            # Find rightmost applicable Search in quotation, recursively scan right-to-left.
            for v in self._traverse_and_expand(program):
                # There may be more Searches to expand, schedule this search to run again as "self" in the quotation.
                yield Expansion([v.fragment, self], v.cost, v.heuristic)
        except NoTransformationsPossible:
            # No searches expanded if we reach here, but fail if any remain as they'd be unapplicable.
            assert not _has_searches_in_list(program), "Unapplicable Search(es) remain in quotation."
            yield [program, J.combinator("i")]

    def peek(self, program: list) -> int | None:
        return None  # Unknown without expanding


# ─────────────────────────────────────────────────────────────────────────────────────────────
# Specialized Exceptions / Interjections
# ─────────────────────────────────────────────────────────────────────────────────────────────

class TerminateSearchWithThisBranch(ProgramInterjectsInSearch):
    """Interjection that stops exploration by clearing the frontier, leaving only this branch
    to finish. The remaining Node is assumed not to branch further.
    """

    def __init__(self, search: Search):
        def _terminate(frontier, node):
            prog = list(node.program)
            idx = prog.index(search)
            suffix = prog[idx + 1 :]
            frontier.clear(reason=PruneReason.REJECT)
            # Include search in trace so report() is called for it on completion.
            frontier.append(Node(node.stack, deque(suffix), trace=node.trace + (search,), cost=node.cost, heuristic=node.heuristic))

        super().__init__(callback=_terminate)


# ─────────────────────────────────────────────────────────────────────────────────────────────
# Frontier-based Search Interpreter
# ─────────────────────────────────────────────────────────────────────────────────────────────

class Frontier:
    """Frontier with lifecycle callbacks for search node management.
    
    Uses composition (self._data) rather than inheritance, allowing subclasses
    to swap the underlying container (e.g. heapq list for HFS).
    
    - `clear(reason=X, new_nodes=[...])` replaces the frontier with `new_nodes`, emitting
      consolidated `on_branch(delta)` and `on_prune(reason, count)` calls for already-planted Searches.
    - `reset(nodes)` is structural replacement: `on_branch(delta)` only (NO on_prune).
    - `append_branch(node)` appends an extra live branch occurrence, emitting consolidated
      `on_branch(+k)` deltas for already-planted Searches in that node.
    """

    def __init__(self, iterable=(), *, on_prune=None, on_plant=None):
        assert on_prune is not None and on_plant is not None
        self._data = deque(iterable)
        self._on_prune = on_prune
        self._on_plant = on_plant
        self._is_clearing = False

    # -- Container Protocol --

    def __iter__(self):
        return iter(self._data)

    def __len__(self):
        return len(self._data)

    def __bool__(self):
        return bool(self._data)

    # -- Virtual Methods --

    def _data_clear(self) -> None:
        """Clear underlying container. Override for containers needing extra cleanup."""
        self._data.clear()

    def _data_append(self, node: Node) -> None:
        """Append node to underlying container. Override for heap/priority queue."""
        self._data.append(node)

    # -- Interface --

    def popleft(self) -> Node:
        """Pop from front. Override for heap semantics."""
        return self._data.popleft()

    def pop(self) -> Node:
        """Pop from back."""
        return self._data.pop()

    def appendleft(self, node: Node) -> None:
        """Append to front (priority insertion). Uses same lifecycle as append()."""
        assert node is not None
        if self._is_clearing:
            assert False, "Priority insertion not supported while clearing underway."
            return

        self._on_plant(node)
        self._data.appendleft(node)

    def clear(self, *, reason: PruneReason = PruneReason.REJECT, new_nodes: list[Node] | None = None) -> None:
        """Prune old nodes with reason, append new nodes.
        
        Calls on_branch(delta) + on_prune(reason, count) for Searches with nonzero delta.
        Side effects (release, emit) appropriate for the reason.
        """
        self._replace_frontier([] if new_nodes is None else new_nodes, prune_reason=reason)

    def reset(self, new_nodes: list[Node]) -> None:
        """Structural replacement: on_branch() bookkeeping only, NO on_prune().
        
        Use for reorganization where branches are relocated, not killed.
        """
        self._replace_frontier(new_nodes, prune_reason=None)

    def append(self, node: Node) -> None:
        assert node is not None
        assert not self._is_clearing, (
            "Frontier.append() during clear/reset must be done via interjection callbacks."
        )
        self._on_plant(node)
        self._data_append(node)

    # -- Helpers --

    def _replace_frontier(self, new_nodes: list[Node], *, prune_reason: PruneReason | None) -> None:
        """Core implementation for clear() and reset().
        
        Args:
            new_nodes: Replacement nodes to append after clearing.
            prune_reason: If provided, call on_prune() with this reason (clear semantics).
                         If None, only on_branch() bookkeeping (reset semantics).
        """
        assert not self._is_clearing
        self._is_clearing = True
        old_nodes = list(self)

        # Bookkeeping: compute deltas and track old nodes per Search.
        deltas: dict[Search, int] = defaultdict(int)
        tok_to_nodes: dict[Search, list[Node]] = defaultdict(list)
        for n in old_nodes:
            self._accumulate_planted_search_info(deltas, n, count=-1, tok_to_nodes=tok_to_nodes)
        for n in new_nodes:
            self._accumulate_planted_search_info(deltas, n, count=+1)

        self._data_clear()

        # Notify Searches with nonzero deltas.
        deferred_callbacks: list[tuple[callable, Node]] = []
        for tok, delta in deltas.items():
            if delta == 0:
                continue
            try:
                tok.on_branch(upstream=False, count=delta)
                # Prune semantics are net-removal based: only notify prunes when the
                # Search object has fewer frontier occurrences after the replacement.
                if prune_reason is not None and delta < 0:
                    tok.on_prune(prune_reason, count=-delta)
            except ProgramInterjectsInSearch as interjection:
                assert tok in tok_to_nodes, f"FATAL: Interjecting Search {tok} not found as expected."
                affected = tok_to_nodes[tok]
                assert affected, f"FATAL: Interjecting Search {tok} has no affected nodes."
                # Defer frontier mutations until after we exit the clearing state.
                deferred_callbacks.append((interjection.callback, affected[0]))

        self._is_clearing = False

        # Execute interjection callbacks immediately after clearing state ends,
        # before appending `new_nodes`.
        #
        # NOTE: This is intentionally a staging point: callbacks may still mutate the frontier
        # before the outer replacement commits its `new_nodes`.
        for cb, node in deferred_callbacks:
            cb(self, node)

        # Safety check: buffer shouldn't contain nodes we just cleared.
        old_node_ids = {id(n) for n in old_nodes}
        assert not any(id(n) in old_node_ids for n in self), (
            "FATAL: Nodes added dynamically that were already in the frontier."
        )
        # Append new nodes.
        for n in new_nodes:
            self.append(n)

    @staticmethod
    def _accumulate_planted_search_info(
        deltas: dict[Search, int],
        node: Node,
        *,
        count: int,
        tok_to_nodes: dict[Search, list[Node]] | None = None,
    ) -> None:
        """Accumulate deltas and optionally track nodes for already-planted Searches."""
        for tok in list(node.program):
            if isinstance(tok, Search) and getattr(tok, "_is_planted", False):
                deltas[tok] += count
                if tok_to_nodes is not None:
                    tok_to_nodes[tok].append(node)

    @staticmethod
    def _emit_branch_deltas(deltas: dict[Search, int]) -> None:
        """Emit consolidated on_branch() calls, skipping zero deltas."""
        for tok, delta in deltas.items():
            if delta:
                tok.on_branch(upstream=True, count=delta)

    def append_branch(self, node: Node) -> None:
        """Append a node as an additional live branch occurrence.
        
        Intended for out-of-band frontier injection (e.g. from interjection callbacks),
        where there is no upstream Search expansion site to emit on_branch(+1) deltas.
        
        Only already-planted Search instances are notified (new Searches are handled by on_plant).
        """
        deltas: dict[Search, int] = defaultdict(int)
        self._accumulate_planted_search_info(deltas, node, count=+1)
        self._emit_branch_deltas(deltas)

        # Plant Searches in node (if any) then append to the container.
        self.append(node)


def _interpret_search_with_frontier(program: list, pop_from_frontier, push_to_frontier, lib, limit: int = -1, frontier_type=Frontier) -> list:
    """Frontier-based interpreter that expands Searches via transform_step.
    Policy-injected pop/push functions determine BFS vs DFS vs heuristic ordering.
    """
    results: list[Any] = []
    planted_searches: set[Search] = set()  # Track ALL planted Searches for on_finalize

    def _plant_node(node: Node) -> None:
        """Plant Searches in a node entering the frontier."""
        for tok in node.program:
            if isinstance(tok, Search):
                tok._ensure_planted()
                planted_searches.add(tok)

    def _notify_prune(node: Node, reason: PruneReason, count: int = -1) -> None:
        """Notify all Searches in a node that it's being pruned. Handles interjections.
        
        Bookkeeping: emit a symmetric on_branch(delta=-1) for planted Searches being removed
        from the frontier so on_branch-only reference counters can remain consistent.
        
        We use upstream=False so upstream-only pending-count gates do not double-decrement
        alongside on_prune().
        """
        for tok in list(node.program):
            if not isinstance(tok, Search):
                continue
            try:
                if count != 0:
                    tok.on_branch(upstream=False, count=count)
                tok.on_prune(reason)
            except ProgramInterjectsInSearch as interjection:
                interjection.callback(frontier, node)

    # Create frontier with lifecycle callbacks, then seed with initial node
    frontier = frontier_type(on_prune=_notify_prune, on_plant=_plant_node)
    frontier.append(Node(nil, deque(program), trace=()))

    def _track_searches(trace: tuple) -> None:
        """Track all Searches in trace for on_finalize."""
        for search in trace:
            if isinstance(search, Search):
                planted_searches.add(search)

    def _call_reports(trace: tuple, *, outcome: ReportStatus) -> None:
        """Call report() on all Searches in trace, in reverse order."""
        searches_in_trace = [
            (i, search) for i, search in enumerate(trace)
            if isinstance(search, Search)
        ]

        for trace_idx, search in reversed(searches_in_trace):
            before = trace[:trace_idx]
            after = trace[trace_idx + 1:]

            search.report(before, after, status=outcome)

    expand_count = [0]  # Mutable: positive=expansions, negative=interjection handled

    def _expand_node(node):
        """Wrap transform_step, accumulating parent's cost/heuristic."""
        try:
            for result in transform_step(deque(node.program), node.stack, trace=node.trace, lib=lib):
                # Accumulate parent's cost to child (additive), overwrite heuristic. (A* semantics)
                yield Node(
                    result.stack,
                    result.program,
                    cost=node.cost + result.cost,
                    heuristic=result.heuristic,
                    trace=result.trace,
                )
        except ProgramInterjectsInSearch as interjection:
            # Bookkeeping first so callback sees consistent pending counts.
            _notify_prune(node, PruneReason.REJECT)
            interjection.callback(frontier, node)
            expand_count[0] = -1  # Negative signals interjection handled this node

    step = 0
    while frontier:
        # When step limit reached: clear frontier, expire and prune remaining nodes. Then, nodes
        # added during on_prune() by interjections may be explored without limits (usually one).
        if limit > 0 and step >= limit:
            pending_nodes = list(frontier)
            frontier.clear(reason=PruneReason.EXPIRED)
            for pending in pending_nodes:
                _call_reports(pending.trace, outcome=ReportStatus.EXPIRED)
            limit = -1
            continue

        step += 1

        node = pop_from_frontier(frontier)
        _track_searches(node.trace)
        # Also track Searches in the program (they were planted when entering frontier)
        for tok in node.program:
            if isinstance(tok, Search):
                planted_searches.add(tok)

        expand_count[0] = 0
        for result in _expand_node(node):
            expand_count[0] += 1
            _track_searches(result.trace)

            if not result.program:
                # Normal form: check for forgotten Searches on stack.
                # Use recursive=True to catch Searches inside quotations too.
                if has_pending_searches(result.stack, recursive=True):
                    _call_reports(result.trace, outcome=ReportStatus.FAILURE)
                    _notify_prune(result, PruneReason.INVALID)
                    continue

                # Success: call reports and collect result
                _call_reports(result.trace, outcome=ReportStatus.SUCCESS)
                _notify_prune(result, PruneReason.SUCCESS)
                items = stack_to_list(result.stack)
                if len(items) >= 1:
                    results.append(items[0])
            else:
                # Search expanded: enqueue successor.
                push_to_frontier(frontier, result)

        if expand_count[0] == 0:
            # Branch pruned (no expansions and no interjection).
            _call_reports(node.trace, outcome=ReportStatus.FAILURE)
            _notify_prune(node, PruneReason.FAILURE)

    # Finalize: Call on_finalize() for all Search instances that were ever planted
    for search in planted_searches:
        search.on_finalize()

    return results


# ─────────────────────────────────────────────────────────────────────────────────────────────
# Program Preparation for Parallel Execution
# ─────────────────────────────────────────────────────────────────────────────────────────────

def _clone_search(search: Search) -> Search:
    cls = type(search)
    clone = cls.__new__(cls)
    clone.__dict__.update(search.__dict__)
    return clone


def _copy_search_and_map_graph(search: Search, mapping: dict) -> Search:
    """Copy a Search object but also recursing into its intertal graph
    representation using a visitor pattern for traversal.
    """
    assert not search._is_planted, "Expected copies to be made before search starts!"    

    if id(search) in mapping:
        return mapping[id(search)]
    clone = _clone_search(search)

    def _substitute_callback(item: Any) -> Any:
        if isinstance(item, Search):
            return _copy_search_and_map_graph(item, mapping)
        elif isinstance(item, list):
            return copy_quotation_searches(item, mapping)
        return None  # No substitution needed.
    
    clone.traverse(_substitute_callback)
    mapping[id(search)] = clone
    return clone


def copy_quotation_searches(items: list, mapping: dict = None) -> list:
    """Copy a program, replacing Search instances with fresh copies.  This is useful when
    multiple searching algorithms must be run independently and reproducibly.
    """
    mapping = mapping or {}
    result = []
    for item in items:
        if isinstance(item, list):
            result.append(copy_quotation_searches(item, mapping))
        elif isinstance(item, Search):
            result.append(_copy_search_and_map_graph(item, mapping))
        elif isinstance(item, Operation) and item.type == Operation.EXECUTE:
            if isinstance(item.ptr, list):
                copied_ptr = copy_quotation_searches(item.ptr, mapping)
            else:
                copied_ptr = item.ptr
            result.append(Operation(item.type, copied_ptr, item.name, item.meta))
        else:
            result.append(item)
    return result


# ─────────────────────────────────────────────────────────────────────────────────────────────
# Joy Operators
# ─────────────────────────────────────────────────────────────────────────────────────────────

def _do_bfs(program: list, limit: int=-1, *, make_copy=False, lib=None) -> list:
    prepared = copy_quotation_searches(program) if make_copy else program
    return _interpret_search_with_frontier(
        prepared,
        pop_from_frontier=lambda dq: dq.popleft(),
        push_to_frontier=lambda dq, n: dq.append(n),
        lib=lib,
        limit=limit,
    )

def op_bfs(program: list, limit: int=-1) -> list:
    """Explicit breadth-first search variant."""
    return _do_bfs(program, limit, make_copy=True, lib=J.library)


def _do_dfs(program: list, limit: int=-1, *, make_copy=False, lib=None) -> list:
    prepared = copy_quotation_searches(program) if make_copy else program
    return _interpret_search_with_frontier(
        prepared,
        pop_from_frontier=lambda dq: dq.pop(),
        push_to_frontier=lambda dq, n: dq.append(n),
        lib=lib,
        limit=limit,
    )

def op_dfs(program: list, limit: int=-1) -> list:
    """Depth-first search variant."""
    return _do_dfs(program, limit, make_copy=True, lib=J.library)


def op_require_equal(b: Any, a: Any) -> Any:
    """Require equality of two values.

    Within search, a mismatch prunes the branch.
    Outside search, raises ProgramExplicitlyFailed.

    Returns the first value if equal.
    """
    if b == a:
        return b
    raise ProgramExplicitlyFailed(f"Required equality failed: {b!r} != {a!r}")


def op_fail_b(a: bool) -> None:
    """Fail the current branch if the predicate is false."""
    if not a:
        raise ProgramExplicitlyFailed(f"search.fail! predicate failed: {a!r}")
