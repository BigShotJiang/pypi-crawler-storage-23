## Copyright © 2025, Alex J. Champandard.  Licensed under AGPLv3; see LICENSE! ⚘

import math
from typing import Any, TypeVar
from fractions import Fraction

from .types import Stack
from .errors import JoyAssertionError
from .formatting import stack_to_list, list_to_stack, format_item


num = int | float | Fraction
symbol = bytes

## ARITHMETIC
def op_add(b: num, a: num) -> num: return b + a
def op_sub(b: num, a: num) -> num: return b - a
def op_neg(x: num) -> num: return -x
def op_abs(x: num) -> num: return abs(x)
def op_sign(x: num) -> num: return (x > 0) - (x < 0)
def op_min(b: num, a: num) -> num: return min(b, a)
def op_max(b: num, a: num) -> num: return max(b, a)
def op_mul(b: num, a: num) -> num: return b * a
def op_div(b: num, a: num) -> num: return b / a
def op_idiv(b: num, a: num) -> int: return int(b // a)
def op_rem(b: num, a: num) -> num: return b % a
## TRIGONOMETRY & (PRE)CALCULUS
def op_cos(x: num) -> float: return math.cos(x)
def op_sin(x: num) -> float: return math.sin(x)
def op_exp(x: num) -> float: return math.exp(x)
def op_pow(b: num, a: num) -> float: return math.pow(b, a)
def op_log(x: num) -> float: return math.log(x)
def op_sqrt(x: num) -> float: return math.sqrt(x)
def op_isqrt(x: int) -> int: return math.isqrt(x)
def op_floor(x: num) -> int: return math.floor(x)
def op_ceil(x: num) -> int: return math.ceil(x)
def op_round(x: num) -> int: return round(x)
def op_trunc(x: num) -> int: return math.trunc(x)
def op_tan(x: num) -> float: return math.tan(x)
def op_acos(x: num) -> float: return math.acos(x)
def op_asin(x: num) -> float: return math.asin(x)
def op_atan(x: num) -> float: return math.atan(x)
def op_atan2(b: num, a: num) -> float: return math.atan2(b, a)
def op_log10(x: num) -> float: return math.log10(x)
def op_log2(x: num) -> float: return math.log2(x)
def op_sinh(x: num) -> float: return math.sinh(x)
def op_cosh(x: num) -> float: return math.cosh(x)
def op_tanh(x: num) -> float: return math.tanh(x)
## COMPARATORS
def op_equal_q(b: Any, a: Any) -> bool: return b == a
def op_differ_q(b: Any, a: Any) -> bool: return b != a
def op_gt(b: num, a: num) -> bool: return b > a
def op_gte(b: num, a: num) -> bool: return b >= a
def op_lt(b: num, a: num) -> bool: return b < a
def op_lte(b: num, a: num) -> bool: return b <= a
## BOOLEAN LOGIC
def op_and(b: bool, a: bool) -> bool: return b and a
def op_or(b: bool, a: bool) -> bool: return b or a
def op_not(x: bool | int) -> bool: return not x
def op_xor(b: Any, a: Any) -> Any: return b ^ a
## DATA & INTROSPECTION
def op_null_q(x: Any) -> bool: return (len(x) if isinstance(x, (list, str)) else x) == 0
def op_small_q(x: Any) -> bool: return (len(x) if isinstance(x, (list, str)) else x) < 2
def op_sametype_q(b: Any, a: Any) -> bool: return type(b) == type(a)
def op_integer_q(x: Any) -> bool: return isinstance(x, int)
def op_float_q(x: Any) -> bool: return isinstance(x, float)
def op_list_q(x: Any) -> bool: return isinstance(x, list)
def op_string_q(x: Any) -> bool: return isinstance(x, str)
def op_boolean_q(x: Any) -> bool: return isinstance(x, bool)
def op_symbol_q(x: Any) -> bool: return isinstance(x, bytes)
## LIST MANIPULATION
T = TypeVar('T', bound=Any)
def op_cons(b: T, a: list[T]) -> list[T]: return [b] + a
def op_append(b: Any, a: list) -> list: return a + [b]
def op_remove(b: list, a: Any) -> list: return [x for x in b if x != a]
def op_take(b: list, a: int) -> list: return b[:a]
def op_drop(b: list, a: int) -> list: return b[a:]
def op_uncons(x: list) -> tuple[Any, list]: return (x[0], x[1:])
def op_concat(b: list, a: list) -> list: return b + a
def op_zip(b: list, a: list) -> list: return [[x, y] for x, y in zip(b, a)]
def op_reverse(x: list[T]) -> list[T]: return list(reversed(x))
def op_first(x: list[T]) -> T: return x[0]
def op_rest(x: list[T]) -> list[T]: return x[1:]
def op_last(x: list[T]) -> T: return x[-1]
def op_index(b: int, a: list[T]) -> T: return a[int(b)]
def op_member_q(b: Any, a: list | dict | set) -> bool: return b in a
def op_nub(x: list) -> list:
    seen, out = set(), []
    for item in x:
        if item not in seen:
            seen.add(item)
            out.append(item)
    return out
def op_length(x: list | dict | set | str) -> int: return len(x)
def op_sum(x: list) -> num: return sum(x)
def op_product(x: list) -> num: return math.prod(x)
# STACK OPERATIONS
X, Y = (TypeVar(v, bound=Any) for v in ('X', 'Y'))
def op_swap(b: Y, a: X) -> tuple[X, Y]: return (a, b)
def op_dup(x: X) -> tuple[X, X]: return (x, x)
def op_pop(_: Any) -> None: pass
def op_stack(s: Stack) -> list: return stack_to_list(s)
def op_unstack(x: list) -> tuple: return list_to_stack(x)
def op_stack_size(s: Stack) -> int: return len(stack_to_list(s))
# INPUT/OUTPUT
def op_id(x: Any) -> Any: return x
def op_put_b(x: Any) -> None:
    text = x if isinstance(x, str) else (format_item(x, width=120) + ' ')
    print(text, end='')
def op_putln_b(x: Any) -> None:
    text = x if isinstance(x, str) else format_item(x, width=120)
    print(text, flush=True)
def op_assert_b(x: bool) -> None:
    if not x: raise JoyAssertionError("Assertion failed.")
def op_raise_b(x: Any) -> None: raise x
# STRING MANIPULATION
def op_str_concat(b: str, a: str) -> str: return b + a
def op_str_contains_q(b: str, a: str) -> bool: return b in a
def op_str_starts_with_q(b: str, a: str) -> bool: return a.startswith(b)
def op_str_split(b: str, a: str) -> Any: return a.split(b)
def op_str_cast(x: Any) -> str: return str(x)
def op_str_join(b: list[str], a: str) -> str: return a.join(b)
def op_symbol_name(x: symbol) -> str: return x.decode('ascii')
# DICTIONARIES (mutable)
def op_dict_new() -> dict: return {}
def op_dict_q(d: dict) -> bool: return isinstance(d, dict)
def op_dict_store(d: dict, k: symbol, v: Any) -> dict: return d.__setitem__(k, v) or d
def op_dict_fetch(d: dict, k: symbol) -> Any: return d[k]
# ERROR HANDLING
def op_error_type(e: Exception) -> symbol: return e.__class__.__name__.encode('ascii')
def op_error_message(e: Exception) -> str: return str(e)
def op_error_data(e: Exception) -> Any:
    data = {}
    if hasattr(e, 'joy_op'): data['joy_op'] = getattr(e, 'joy_op')
    if hasattr(e, 'joy_meta'): data['joy_meta'] = getattr(e, 'joy_meta')
    return data
