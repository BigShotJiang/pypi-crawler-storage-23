## Copyright © 2025, Alex J. Champandard.  Licensed under AGPLv3; see LICENSE! ⚘
"""
Quotation Transformation Model (QTM)
====================================

This approach basis of comptime features and also optimization passes in joyfl; the idea is
that a quotation with special Search objects can be tratnsformed into another quotation.

For the theory behind this approach, see in particular for Joy:
https://hypercubed.github.io/joy/html/j07rrs.html

Terminology
-----------
- **Fragment**: A replacement program slice, list[Token].
- **Search**: Placeholder that expands into fragments, branching the search tree.
- **Expansion**: Result from Search.expand() — fragment with optional cost/heuristic.
- **Node**: A state in the search tree (stack + program + cost + heuristic).
- **QTM step**: Q = P · S · R  ⇒  P · E_j · R  (for each expansion E_j)

Key Semantics
-------------
- **Search.expand(args)**: Generator yielding Expansions (or bare Fragments) replacing S.
  Args are rightmost tokens from "zipped prefix" (stack + program before S).
- **SearchWrapper**: Base for Searches that wrap another Search with pass-through lifecycle.
- **Search.on_branch(upstream, count)**: Notification of branching elsewhere.
- **Search.on_prune()**: Notification of branch discard.
- **Zipped Prefix**: [stack_bottom...stack_top, prog_0...prog_{idx-1}]
- **Expansion Policy**: Back-to-front scan for applicable Search, else head execution.
"""

import threading

from enum import Enum
from typing import Any, Iterator
from collections import deque
from dataclasses import dataclass

from .types import nil, Stack, Operation, validate_signature_inputs
from .errors import JoyNameError
from .interpreter import can_execute, interpret_step

Token = Any
Fragment = list[Token]


class ReportStatus(Enum):
    """Status passed to Search.report() at terminal states."""

    SUCCESS = "success"     # Path completed successfully, this Search contributed.
    FAILURE = "failure"     # Path was pruned (ProgramExplicitlyFailed)
    EXPIRED = "expired"     # Path was not resolved (search limit reached; outcome unknown).


class PruneReason(Enum):
    """Reason passed to Search.on_prune() when it is being removed from frontier.""" 

    INVALID = "invalid"     # Search objects remain in quotation.
    SUCCESS = "success"     # Normal form reached, consider successful.
    FAILURE = "failure"     # No expansions returned by Search, consider failure.
    EXPIRED = "expired"     # Search truncated; branch still potentially successful.
    REJECT  = "reject"      # Active prune/reset of the frontier, consider rejected.


@dataclass(slots=True, frozen=True)
class Expansion:
    """Result from Search.expand(): replacement fragment with optional cost/heuristic.
    
    Search.expand() can yield either bare Fragments (list[Token]) for simplicity,
    or Expansion objects when cost/heuristic meta-data is needed.
    """
    fragment: Fragment
    cost: float = 0.0
    heuristic: float = 0.0


@dataclass(slots=True, frozen=True)
class SlateSelection:
    """Trace event indicating which expansion was selected from a slate."""

    slate_id: int
    expansion_idx: int


@dataclass(slots=True, frozen=True)
class Node:
    """A state in the frontier (stack + program + trace + cost + heuristic).
    
    This is what transform_step() yields and what the search frontier manages.
    The trace records searches, operations, events along the path from root (immutable tuple).
    """
    stack: Stack
    program: deque
    trace: tuple = ()
    cost: float = 0.0
    heuristic: float = 0.0


class Search:
    """Abstract placeholder token that can be inserted into any quotation that expands into concrete
    token fragment that are re-injected into the original sequence (stateful, generator-based)."""

    inputs: list[type] = []     # Stack-effect: required input types (bottom-first)
    outputs: list[type] = []    # Stack-effect: produced output types
    arity: int = 0
    valency: int = 0

    _is_planted: bool = False   # Per-instance flag if the Search is in the frontier state.

    def _ensure_planted(self):
        if not self._is_planted:
            self._is_planted = True
            self.on_plant()

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__}>"


    def traverse(self, callback) -> None:
        """Traverse all Search/list references, calling callback for each.
        
        Called by global _copy_search_and_map_graph() after base copy.
        Subclasses override to handle internal Search/list references.
        
        Args:
            callback: Callable[[Any], Any] that returns a replacement or None
                      - If returns non-None, use as replacement
                      - If returns None, keep original
        """
        pass  # Base class has no internal refs

    def expand(self, *args: Any) -> Iterator[Fragment | Expansion | tuple]:
        """Yield replacement fragments for this Search.

        Args: Variadic arguments in bottom-to-top order (matching `inputs` declaration).
              For inputs=[int, str], expand(self, n: int, s: str) receives int first, str second.

        Yields: Fragment, Expansion, or tuple. Yield nothing to prune.

        Accepted forms:
          - Fragment (list[Token]): cost=0.0, heuristic=0.0
          - Expansion(fragment, cost, heuristic)
          - tuple[Fragment, float]: (fragment, cost), heuristic=0.0
          - tuple[Fragment, float, float]: (fragment, cost, heuristic)

        This is a generator, enabling lazy expansion via SearchWrapper subclasses.
        """
        raise NotImplementedError("Search sub-classes must implement expand().")
        yield  # Make this a generator

    def on_plant(self) -> None:
        """Notification that this Search was planted in a NEW frontier node.
        
        Called once per Search instance when it first appears in the frontier,
        either in the initial program or as part of a fragment from expansion.
        """
        pass

    def on_finalize(self) -> None:
        """Notification that the search session has ended.
        
        Called once per planted Search instance at the end of a search session.
        Symmetric opposite of on_plant — use for cleanup and state reset.
        Guaranteed to be called for ALL planted Searches, even those that were
        never expanded (e.g., raised ProgramInterjectsInSearch from on_prune).
        """
        self._is_planted = False

    def on_branch(self, *, upstream: bool, count: int) -> None:
        """Notification that another Search expanded, creating `count` branches.
        upstream=True means expansion point is after this Search in quotation.
        """
        assert self._is_planted

    def on_prune(self, reason: PruneReason, *, trace: tuple = (), count: int = 1) -> None:
        """Notification that this branch is being discarded.

        Args:
            reason: Enumeration explaining why the branch is being pruned.
            trace: The execution trace at the point of pruning (if available).
                   Only provided when the Search itself caused the prune by returning
                   no expansions from expand().
            count: Number of occurrences being pruned (default 1). Used in consolidated
                   frontier operations where multiple occurrences are pruned at once.
        """
        assert self._is_planted

    def peek(self, *args) -> int | None:
        """Estimate of remaining alternatives, or None if unknown."""
        return None

    def report(self, before: tuple, after: tuple, *, status: ReportStatus) -> None:
        """Feedback notification called by the search interpreter at terminal states.
        
        Args:
            before: The trace prefix BEFORE this Search was expanded (immutable tuple).
                    Contains all Searches that were expanded before this one.
            
            after:  The trace suffix AFTER this Search was expanded (immutable tuple).
                    Contains all Searches expanded after this one.
            
            status: The outcome classification (SUCCESS, FAILURE, EXPIRED).
        
        Contract:
            - Called exactly once per Search per completed path
            - Called in reverse trace order (last Search first, then earlier ones)
            - `before + (self,) + after` reconstructs the full trace
            - Finalization happens via on_finalize() lifecycle callback
        """
        pass


class _WrappingSearchBase(Search):
    """Base class for Searches that wrap another Search and forward callbacks.

    Subclasses should set _inner to the wrapped Search instance. Callbacks are
    forwarded to _inner if it is set and planted.

    When forwarding report(), the inner Search receives the original trace.
    """
    _inner: Search | None = None


    def traverse(self, callback) -> None:
        """Traverse _inner reference, calling callback for substitution.
        
        Args:
            callback: Callable[[Any], Any] that returns a replacement or None
                      - If returns non-None, use as replacement
                      - If returns None, keep original
        """
        if self._inner is not None and (replacement := callback(self._inner)):
            self._inner = replacement

    def on_plant(self) -> None:
        if self._inner is not None:
            self._inner._ensure_planted()

    def on_finalize(self) -> None:
        if self._inner is not None and self._inner._is_planted:
            self._inner.on_finalize()
            # Reset planted state so inner can be re-used in new search session.
            self._inner._is_planted = False
        super().on_finalize()

    def on_branch(self, *, upstream: bool, count: int) -> None:
        if self._inner is not None:
            assert self._inner._is_planted, f"FATAL [transform]: {self} -> {self._inner}"
            self._inner.on_branch(upstream=upstream, count=count)

    def on_prune(self, reason: PruneReason, *, trace: tuple = (), count: int = 1) -> None:
        if self._inner is not None:
            assert self._inner._is_planted, f"FATAL [transform]: {self} -> {self._inner}"
            self._inner.on_prune(reason, trace=trace, count=count)

    def report(self, before: tuple, after: tuple, *, status: ReportStatus) -> None:
        if self._inner is None:
            return
        assert self._inner._is_planted, f"FATAL [transform]: {self} -> {self._inner}"

        # Assert wrapper-adjacent SlateSelection is present for the forwarded call.
        # We keep it so inner learners can attribute outcomes via slate_id/expansion_idx.
        assert after and isinstance(after[0], SlateSelection), (
            f"Expected wrapper-adjacent SlateSelection at after[0] for {self}, got {after[:3]!r}"
        )

        self._inner.report(before, after, status=status)


class SearchWrapper(_WrappingSearchBase):
    """Base for Searches that wrap another Search with pass-through lifecycle.
    
    Delegates planted state to the inner Search.
    """
    
    def __init__(self, inner: Search):
        self._inner = inner
        # NOTE: Only wrap outputs because inputs will have been consumed, and will either
        # change or disappear for the wrapper.
        self.outputs = inner.outputs
        self.valency = inner.valency
    
    @property
    def inner(self) -> Search:
        return self._inner

    @property
    def _is_planted(self) -> bool:
        return self._inner._is_planted

    @_is_planted.setter
    def _is_planted(self, value: bool) -> None:
        self._inner._is_planted = value

    def _ensure_planted(self) -> None:
        self._inner._ensure_planted()


class ProgramExplicitlyFailed(Exception):
    """Raised by an Operation or Search to prune the current node in the frontier (e.g., constraint failure)."""
    pass


class ProgramInterjectsInSearch(Exception):
    """Raised to intervene in search in a customizable way. Callback accesses and can modify the frontier directly."""
    
    def __init__(self, callback):
        """callback(frontier: deque[Node], current: Node) -> None"""
        self.callback = callback


def get_search_signature(search: Search) -> dict:
    assert search.arity == len(search.inputs), search
    assert search.valency == -1 or search.valency == len(search.outputs), search
    return {"inputs": search.inputs, "outputs": search.outputs, "arity": search.arity, "valency": search.valency}


def has_pending_searches(stack, *, recursive: bool = False) -> bool:
    """Check if stack contains any Search objects.
    If recursive=True, also checks inside nested quotations.
    """
    while stack is not nil:
        stack, head = stack
        if isinstance(head, Search):
            return True
        if recursive and isinstance(head, list) and _has_searches_in_list(head):
            return True
    return False


def _has_searches_in_list(items: list) -> bool:
    """Recursive helper for has_pending_searches."""
    for item in items:
        if isinstance(item, Search):
            return True
        if isinstance(item, list) and _has_searches_in_list(item):
            return True
    return False


def _zip_all_to_focus(prog_list: list, stack, search_index: int):
    """Collect args and prepare all components for Search expansion, returning a tuple 
    with (new_stack, args, prog_prefix, prog_suffix).
    """
    focus_search = prog_list[search_index]

    eff = get_search_signature(focus_search)
    needed = len(eff["inputs"])

    prog_needed = 0
    prog_prefix = prog_list[:search_index]
    prog_suffix = prog_list[search_index + 1:]

    if needed == 0:
        return stack, [], prog_prefix, prog_suffix

    # Collect arguments in top-first order from program prefix then stack.
    args: list[Any] = []
    for i in range(search_index - 1, -1, -1):
        args.append(prog_list[i])
        prog_needed += 1
        if len(args) == needed:
            break

    new_stk = stack
    while new_stk is not nil and len(args) < needed:
        new_stk, head = new_stk
        args.append(head)

    if len(args) < needed:
        return new_stk, None, prog_prefix, prog_suffix  # None signals insufficient args

    if prog_needed > 0:
        prog_prefix = prog_prefix[:-prog_needed]

    return new_stk, list(reversed(args)), prog_prefix, prog_suffix


def _can_expand_search(search: Search, program: deque, stack, search_index: int) -> tuple[bool, str]:
    """Check if Search is applicable: sufficient depth and matching types."""
    eff = get_search_signature(search)
    _, args, *_ = _zip_all_to_focus(list(program), stack, search_index)

    if args is None:
        return False, f"`{search}` needs {len(eff['inputs'])} args, insufficient available."

    return validate_signature_inputs(eff["inputs"], args, str(search))


def _as_expansion(result: Fragment | Expansion | tuple) -> tuple[Fragment, float, float]:
    """Extract (fragment, cost, heuristic) from expand() result if it's not already an Expansion."""

    # Expansion is by far the fastest, this is recommended to return from expand() generators.
    if isinstance(result, Expansion):
        return result

    fragment, cost, heuristic = [], 0.0, 0.0
    if isinstance(result, tuple):
        assert isinstance(result[0], list), f"Expected list for Search.expand() fragment, got {type(result[0])}."
        fragment = result[0]
        if len(result) >= 2:
            assert isinstance(result[1], float), f"Expected float for Search.expand() cost, got {type(result[1])}."
            cost = result[1]
        if len(result) >= 3:
            assert isinstance(result[2], float), f"Expected float for Search.expand() heuristic, got {type(result[2])}."
            heuristic = result[2]
        assert len(result) <= 3, f"Expected at most 3 elements for Search.expand() tuple, got {len(result)}."
    else:
        assert isinstance(result, list), f"Expected list for Search.expand() single fragment, got {type(result)}."
        fragment = result

    return Expansion(fragment, cost, heuristic)


_SLATE_LOCAL = threading.local()

def _next_slate_id() -> int:
    """Return a thread-unique slate_id assuming one thread per search frontier. Only one top-level search
    frontier is currently expected per thread, and one transformation at a time.

    NOTE: This fails to provide unique per-search slate_ids if multiple threads operate on the same search.
    """
    try:
        i = _SLATE_LOCAL.i + 1
    except AttributeError:
        i = 1
    _SLATE_LOCAL.i = i
    return int(i)


def transform_step(program: deque, stack, *, trace: tuple = (), lib: 'Library' = None) -> Iterator[Node]:
    """
    If the purpose of execution is to turn a quotation with Operations into a result stack, removing Operations
    by applying them, then analogously the purpose of transformation is to turn a quotation with Searches and
    Operations into a result stack, removing both Operations and Searches by expanding them.

    It's theoretically possible to make every Operation a Search that simply expands itself into its
    result, and the output would be spliced into the quotation at that location.

    This is the core algorithm for the comptime features and also optimization passes in joyfl.
    """

    parent_trace = trace if trace is not None else ()
    trace_so_far = list(parent_trace)

    def _mark_as_planted(items: list) -> None:
        """Notify NEW Searches in fragment or upcoming quotations that they've been planted."""
        for item in items:
            if isinstance(item, Search):
                item._ensure_planted()

    def _do_expand_search(prog_list, search_index):
        search: Search = prog_list[search_index]

        new_stack, args_bottom_first, prog_prefix, prog_suffix = _zip_all_to_focus(prog_list, stack, search_index)
        slate_id = _next_slate_id()

        # Use the computed prefix/suffix as we don't want to notify the Search's consumed arguments...
        set_prefix = {s for s in prog_prefix if isinstance(s, Search)}
        set_suffix = {s for s in prog_suffix if isinstance(s, Search)}

        # But we must notify consumed Searches that they're leaving this branch, removed from quotation.
        consumed_searches = {s for s in prog_list[:search_index] if isinstance(s, Search)} - set_prefix
        for tok in consumed_searches:
            tok.on_branch(upstream=False, count=-1)

        # Yield nodes for each expansion, notifying downstream Searches of branching
        count = 0
        for result in search.expand(*args_bottom_first):
            # Notify downstream Searches that one more branch was added.  We ignore the first because it cancels out
            # the current parent branch we're on now (avoiding a temporary zero race condition.)
            if count > 0:
                for tok in set_prefix:
                    tok.on_branch(upstream=False, count=+1)
                for tok in set_suffix:
                    tok.on_branch(upstream=True, count=+1)

            # Handle multiple different formats that Search objects may return.
            exp = _as_expansion(result)
            assert search.valency == -1 or len(exp.fragment) == search.valency, f"Expected {search.valency} outputs from {search}, got {len(exp.fragment)}."
            assert all((tok is None) or isinstance(tok, typ) for tok, typ in zip(exp.fragment, search.outputs)), (
                f"Expected {search.outputs} outputs from {search}, got {[type(e) for e in exp.fragment]}."
            )

            # As these may be new Search objects entering the frontier, issue on_plant so it's before on_branch / on_prune.
            _mark_as_planted(exp.fragment)
            fragment = [tok for tok in exp.fragment if tok is not None]
            fragment_for_trace = [tok for tok in fragment if not isinstance(tok, Search)]
            child_trace = trace_so_far + [SlateSelection(slate_id=slate_id, expansion_idx=count)] + fragment_for_trace
            yield Node(new_stack, deque(prog_prefix + fragment + prog_suffix), trace=tuple(child_trace), cost=exp.cost, heuristic=exp.heuristic)
            count += 1

        if count == 0:
            # Notify the Search that it pruned this branch, with the current trace.
            # This allows Searches like CollectUntilSolved to capture per-candidate traces.
            search.on_prune(PruneReason.REJECT, trace=tuple(trace_so_far))

            # NOTE: Calls to on_branch() for all search objects in set_suffix are handled later
            # with _notify_prune() when the loop is seen to be empty.

    while True:
        prog_list = list(program)

        # If the program is empty, can't apply operations or expand searches. Check if success!
        if not prog_list:
            if not has_pending_searches(stack, recursive=True):
                # Already in normal form! No searches found.
                yield Node(stack, program, trace=tuple(trace_so_far))
            else:
                print('WARNING: transform_step() finished execution but found pending Searches on the stack.')
            return

        # Find rightmost applicable Search, right-to-left scan.
        search_index = None
        for idx in range(len(prog_list) - 1, -1, -1):
            tok = prog_list[idx]
            if isinstance(tok, Search) and _can_expand_search(tok, program, stack, idx)[0]:
                search_index = idx
                trace_so_far.append(tok)
                try:
                    yield from _do_expand_search(prog_list, search_index)
                except ProgramExplicitlyFailed:
                    return  # Pruned (yield nothing)
                return  # Don't fall through to execution

        # Non-applicable Search, that's considered a failure; prune branch.
        head = program[0]
        if isinstance(head, Search):
            print(f'WARNING: transform_step() found non-applicable Search {head} on the top of the stack.')
            return

        eff = None
        if isinstance(head, Operation):
            ok, _, eff = can_execute(head, stack)
            if not ok:
                print(f'WARNING: transform_step() found non-applicable Operation `{head}` on the top of the stack.')
                return  # Pruned (yield nothing)

            # Notify Searches in quotations about to be inlined by combinators (i, dip)
            if head.type == Operation.COMBINATOR and head.name in ('i', 'dip'):
                assert stack is not nil and isinstance(stack.head, list)
                _mark_as_planted(stack.head)
            # Notify Searches in libraries that will be auto-inlined by the interpreter.
            if head.type == Operation.EXECUTE:
                assert lib is not None
                q = lib.get_quotation(head.ptr, meta=head.meta)
                if q is None:
                    raise JoyNameError(f"Unknown quotation `{head.name}`.", joy_token=head.name, joy_op=head)
                _mark_as_planted(q.program)

        # Record executed token in the trace, both operations and values.
        trace_so_far.append(head)

        try:
            stack, program = interpret_step(program, stack, lib=lib)
        except ProgramExplicitlyFailed:
            return  # Pruned (yield nothing)

        # Add operation outputs to trace, iff signature is known and finite.
        if isinstance(head, Operation) and eff is not None:
            if (valency := eff.get('valency', -1)) < 0:
                continue

            outputs, s = [], stack
            for _ in range(valency):
                if s is nil:
                    break
                s, h = s
                outputs.append(h)
            outputs.reverse()  # bottom-first order
            trace_so_far.extend(outputs)

        # Continue loop to execute next Operation
