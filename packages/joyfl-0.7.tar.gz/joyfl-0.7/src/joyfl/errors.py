## Copyright © 2025, Alex J. Champandard.  Licensed under AGPLv3; see LICENSE! ⚘

import lark


class JoyError(Exception):
    def __init__(self, message: str = "", *, joy_op=None, joy_token=None, joy_meta=None):
        """Base class for all Joy-raised errors."""
        super().__init__(message)
        self.joy_op: object = joy_op
        self.joy_token: str = joy_token or (joy_op.name if joy_op else None)
        self.joy_meta: dict = joy_meta or (joy_op.meta if joy_op else None)

        # These are only ever injected, if available upon catching.
        self.joy_stack: tuple = None  #| Stack
        self.joy_queue: list = None   #| deque


class JoyParseError(JoyError):
    def __init__(self, message, *, filename=None, line=None, column=None, token=None):
        super().__init__(message)
        self.filename = filename
        self.line = line
        self.column = column
        self.token = token

class JoyLiteralParseError(JoyParseError):
    """Parse-time failure while decoding a literal token (e.g., escaped string)."""
    pass


class JoyIncompleteParse(JoyParseError, lark.exceptions.ParseError):
    def __init__(self, message, *, filename=None, line=None, column=None, token=None):
        super().__init__(message, filename=filename, line=line, column=column, token=token)

class JoyNameError(JoyError, NameError):
    pass

class JoyValueError(JoyError, ValueError):
    pass

class JoyRuntimeError(JoyError, RuntimeError):
    pass

class JoyNotImplementedError(JoyError, NotImplementedError):
    """A known quotation or operation has been declared but has no implementation."""
    pass

class JoyAssertionError(JoyError, AssertionError):
    pass


class JoyTypeMissing(JoyError, TypeError):
    pass

class JoyTypeError(JoyError, TypeError):
    """Loading-time problems from the type system, usually from Python-side."""
    pass

class JoyTypeDuplicate(JoyTypeError):
    """Duplicate or conflicting type definitions discovered while loading."""
    pass

class JoyUnknownStruct(JoyTypeError):
    """TYPEDEF referenced in a stack-effect annotation but not registered as struct."""
    pass


class JoyStackError(JoyError, RuntimeError):
    """Runtime type exceptions found by checking the stack and its content."""
    def __init__(self, message: str = "", *, joy_op=None, joy_token=None, joy_meta=None, joy_stack=None):
        super().__init__(message, joy_op=joy_op, joy_token=joy_token, joy_meta=joy_meta)
        self.joy_stack = joy_stack

class JoyStackShapeError(JoyStackError): pass
class JoyStackValueError(JoyStackError, ValueError): pass
class JoyStackTypeError(JoyStackError, TypeError): pass


class JoyImportError(JoyError, ImportError):
    def __init__(self, message, *, joy_op=None, joy_token=None, filename=None, joy_meta=None):
        super().__init__(message, joy_op=joy_op, joy_token=joy_token, joy_meta=joy_meta)
        self.filename = filename

class JoyModuleError(JoyImportError):
    pass
