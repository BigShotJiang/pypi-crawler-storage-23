## Copyright © 2025, Alex J. Champandard.  Licensed under AGPLv3; see LICENSE! ⚘
"""
Search module wrapper for auto-loading.

This wrapper exposes the search primitives from joyfl.search so that they
can be auto-loaded when Joy code references `search.*` operators.
"""

import os

from joyfl.search import (
    # Operators, exposed as Python functions.
    op_bfs,
    op_dfs,
    op_fail_b,
    op_require_equal,

    # Search classes, exposed as factories.
    OnceGate,
    ValuesSearch,
    TakeKSearch,
    SampleKSearch,
    CollectKSearch,
    LengthenSearch,
    InterleaveSearch,
    FallbackSearch,
    ConsumeArgsMakeSearch,
    TransformRecursivelySearch,
)


__joy_operators__ = [
    op_bfs,
    op_dfs,
    op_require_equal,
    op_fail_b,
]

__joy_factories__ = {
    # Simple factories, search instanctiated directly.
    'values': ValuesSearch,
    'once': OnceGate,
    'lengthen': LengthenSearch,
    'collect-k': CollectKSearch,
    # Wrapped factories, consume the arguments first.
    'take-k': lambda: ConsumeArgsMakeSearch(TakeKSearch, [list, int]),
    'sample-k': lambda: ConsumeArgsMakeSearch(SampleKSearch, [list, int]),
    'interleave': lambda: ConsumeArgsMakeSearch(InterleaveSearch, [list]),
    'fallback': lambda: ConsumeArgsMakeSearch(FallbackSearch, [list]),
}

import joyfl.api as J
J.register_factory('J', TransformRecursivelySearch)


if os.environ.get('JOY_DEBUG'): print('LOADED libs/_search.py')
