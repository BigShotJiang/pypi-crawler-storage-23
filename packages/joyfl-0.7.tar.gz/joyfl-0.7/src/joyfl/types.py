## joyfl — Copyright © 2025, Alex J. Champandard.  Licensed under AGPLv3; see LICENSE! ⚘

from types import UnionType
from typing import Any, Literal, TypeVar, Union, get_args, get_origin
from numbers import Number
from fractions import Fraction
from collections import namedtuple
from dataclasses import dataclass

from .errors import JoyStackShapeError, JoyStackTypeError


class stack_list(list): pass


# Stack type is a namedtuple to save memory, yet provide tail/head accessors.
class Stack(namedtuple('Stack', ['tail', 'head'])):
    __slots__ = ()
    _nil_singleton = None

    def __new__(cls, tail, head):
        if tail is None and head is None:
            # Only one singleton creation is allowed, and it's the one just below.
            if cls._nil_singleton is None:
                self = super(Stack, cls).__new__(cls, tail, head)
                cls._nil_singleton = self
                return self
            # By convention, all other code should use `nil` explicitly.
            raise ValueError("Use the canonical `nil` instance for empty stacks")
        return super(Stack, cls).__new__(cls, tail, head)

    def __repr__(self):
        if self is nil:
            return "< nil >"

        items = []
        current = self
        while current is not nil:
            items.append(repr(current.head))
            current = current.tail
        return "< " + " ".join(reversed(items)) + " >"

    def __eq__(self, value: object) -> bool:
        assert isinstance(value, Stack), f"Equality expected Stack type, got {type(value)}."

        left, right = self, value
        while True:
            if left is right:
                return True
            if left is nil or right is nil:
                return left is nil and right is nil
            if left.head != right.head:
                return False
            left, right = left.tail, right.tail

    def __ne__(self, value: object) -> bool:
        return not self.__eq__(value)

    def __bool__(self):
        raise TypeError("Stack truth value is ambiguous; compare with `is nil` or `is not nil`.")

    def pushed(self, *items):
        """Push items in order of tail (left) to head (right) onto new Stack and return."""
        stack = self
        for it in items:
            stack = Stack(stack, it)
        return stack


TYPE_NAME_MAP: dict[str, Any] = {
    'int': int, 'integer': int, 'float': float, 'double': float,
    'num': int | float | Fraction,
    'bool': bool, 'boolean': bool,
    'symbol': bytes, 'sym': bytes,
    'str': str, 'string': str,
    'number': Number,
    'fraction': Fraction, 'fract': Fraction,
    'list': list, 'array': list, 'quot': list,
    'stack': Stack,
    'any': Any, '': Any,
}


# All checks for empty stack must be done by comparing to this.
nil = Stack(None, None)


class Operation:
    FUNCTION = 1
    COMBINATOR = 2
    EXECUTE = 3

    def __init__(self, type, ptr, name, meta={}):
        self.type = type
        self.ptr = ptr
        self.name = name
        self.meta = meta

    def __hash__(self):
        return hash((self.type, self.ptr, self.name))

    def __eq__(self, other):
        return isinstance(other, Operation) and self.type == other.type and self.ptr == other.ptr

    def __repr__(self):
        return f"{self.name}"


class ResolvedName:
    """Opaque fully-qualified quotation name for EXECUTE resolution."""
    __slots__ = ("value", "is_internal")

    def __init__(self, value: str, *, is_internal: bool = True):
        if not isinstance(value, str):
            raise TypeError("ResolvedName expects a string value.")
        self.value = value
        self.is_internal = bool(is_internal)

    def __str__(self) -> str:
        return self.value

    def __repr__(self) -> str:
        return f"<ResolvedName {self.value!r}>"

    @classmethod
    def from_token(cls, token: str | object) -> "ResolvedName":
        """Construct from a dotted, fully-qualified token."""
        if isinstance(token, ResolvedName):
            return token
        return cls(token, is_internal=False)

    def __eq__(self, other):
        if isinstance(other, ResolvedName):
            return self.value == other.value and self.is_internal == other.is_internal
        return NotImplemented

    def __hash__(self):
        return hash((ResolvedName, self.value, self.is_internal))


def _expected_type_name(tp: object) -> str:
    """Format expected types for user-facing stack/type errors."""
    # Tuples are used with isinstance() as a union-of-types.
    if isinstance(tp, tuple):
        parts = [_expected_type_name(t) for t in tp]
        # De-duplicate while preserving order for stable messages.
        seen, out = set(), []
        for p in parts:
            if p in seen:
                continue
            seen.add(p)
            out.append(p)
        return " | ".join(out)

    origin = get_origin(tp)
    if origin in (Union, UnionType):
        args = get_args(tp)
        if args:
            # Joy's numeric type alias used throughout operators (int|float|Fraction).
            if all(a in (int, float, Fraction) for a in args):
                return "num"
            return " | ".join(_expected_type_name(a) for a in args)

    return getattr(tp, "__name__", str(tp))


Visibility = Literal["public", "private", "local", "verify"]


@dataclass
class Quotation:
    program: list | None          # list[Operation], or None for abstract / not-implemented
    meta: dict                    # filename, start/finish, signature, etc.
    visibility: Visibility        # "public", "private", temporary "local", or "verify"
    module: str | None            # MODULE name, or None for global
    type: dict | None = None      # Optional quotation TYPEDEF metadata
    description: str = ""


class TypeKey(bytes):
    """Opaque identifier for Joy TYPE_NAMEs used as struct type keys."""

    @classmethod
    def from_name(cls, name: str | bytes) -> "TypeKey":
        return cls(name if isinstance(name, bytes) else name.encode("utf-8"))

    def to_str(self) -> str:
        return self.decode("utf-8")


class JoyStruct:
    """Marker mixin for Joy struct instances. Provides .typename and .fields properties."""
    _joy_typename: TypeKey

    @property
    def typename(self) -> TypeKey:
        return type(self)._joy_typename

    @property
    def fields(self) -> tuple:
        """Backwards-compatible access to field values as tuple."""
        return tuple(self)


# All concrete Joy value types. Use in Search.inputs to require resolved values.
# Search placeholders are explicitly excluded — use Any if you need to match Search.
Value = int | float | Fraction | bool | str | bytes | list | dict | JoyStruct | Operation


class StructMeta(type):
    """Runtime type for Joy product structs; also carries TYPEDEF metadata.

    Each Joy `TYPEDEF` declaration is represented as a distinct Python class whose
    instances are namedtuples with named field access. The class object exposes
    `.name`, `.arity`, `.fields`, and `.instance_class` for use by combinators.
    """

    name: TypeKey
    arity: int
    fields: tuple[dict, ...]
    instance_class: type  # namedtuple subclass for this struct's values

    def __new__(mcls, name, bases, namespace, *, typename: TypeKey, fields: tuple[dict, ...]):
        cls = super().__new__(mcls, name, bases, namespace)
        cls.name = typename
        cls.arity = len(fields)
        cls.fields = tuple(fields)

        # Create namedtuple instance class with field labels
        labels = tuple((f.get("label") or f"field{i}").replace("-", "_") for i, f in enumerate(fields))
        nt_base = namedtuple(f"{name}", labels, rename=True)

        # Combine namedtuple with JoyStruct marker
        class InstanceClass(JoyStruct, nt_base):
            __slots__ = ()
            _joy_typename = typename
            _joy_field_defs = fields

            def __repr__(self):
                return f"({repr(self.typename)[1:-1]} " + " ".join(name + "=" + repr(field) for name, field in zip(labels, self)) + ")"

        cls.instance_class = InstanceClass
        return cls

    @classmethod
    def from_typedef(mcls, typename: str, fields: tuple[dict, ...]) -> type:
        """Factory to create a StructMeta class from Joy TYPEDEF declaration."""
        type_key = TypeKey.from_name(typename)
        return mcls(typename, (object,), {}, typename=type_key, fields=fields)

    def __instancecheck__(cls, instance):
        # Check if instance was created via this struct's instance_class
        return isinstance(instance, cls.instance_class)


def _check_signature_exceptions(expected: list[type], args: list[Any], name: str) -> tuple[type | None, str]:
    """Validate that arguments match expected input types, as used by the interpreter (for Operations)
    and transformations (for Search).  The stack by convention, is left/bottom to right/top.
    
    Args:
        expected:   Expected types in conventional bottom-to-top.
        args:       Actual values in bottom-to-top order.
        name:       Name for error messages.
    
    Returns:
        (True, "") if valid, (False, reason) if not.
    
    Note:
        Use `Value` in expected types to match any concrete Joy value (excludes Search).
        Use `Any` to match anything including Search placeholders.
    """
    if len(args) < len(expected):
        return JoyStackShapeError, f"`{name}` needs at least {len(expected)} stack item(s), but {len(args)} available."

    for i, (actual, expected_type) in enumerate(zip(reversed(args), reversed(expected))):
        if isinstance(expected_type, TypeVar):
            expected_type = expected_type.__bound__
        if expected_type in (Any, None):
            continue
        if not isinstance(actual, expected_type):
            type_name = _expected_type_name(expected_type)
            return JoyStackTypeError, f"`{name}` expects {type_name} at position {i+1} from top, got {type(actual).__name__}."
    
    return None, ""


def validate_signature_inputs(expected: list[type], args: list[Any], name: str) -> tuple[type | None, str]:
    exc_type, msg = _check_signature_exceptions(expected, args, name)
    return exc_type is None, msg
