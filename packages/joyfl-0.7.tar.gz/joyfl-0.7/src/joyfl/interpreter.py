## Copyright © 2025-2026, Alex J. Champandard.  Licensed under AGPLv3; see LICENSE! ⚘

import sys
import collections

from typing import Any

from .types import nil, Operation, Stack, _check_signature_exceptions, _expected_type_name
from .errors import JoyStackShapeError, JoyStackTypeError, JoyStackValueError, JoyNameError, JoyNotImplementedError
from .library import Library
from .formatting import show_program_and_stack, stack_to_list


def _get_operation_signature(op: Operation):
    if op.type == Operation.FUNCTION and hasattr(op.ptr, '__joy_meta__'):
        return op.ptr.__joy_meta__
    if isinstance(op.meta, dict) and 'signature' in op.meta:
        return op.meta['signature']
    return {}


def _op_causes_exception(op: Operation, stack: Stack, *, eff: dict[str, Any]) -> tuple[type | None, str, dict[str, Any]]:
    """Check if operation can execute on stack using inferred stack effects.
    
    Returns (ok, message, eff) where eff is the operation's signature dict if available.
    """
    # Special cases for combinators and runtime hazards that don't come from signature
    if op.type == Operation.COMBINATOR and op.name in ("i", "dip"):
        if stack is nil:
            return JoyStackShapeError, f"`{op.name}` needs at least 1 item on the stack, but stack is empty.", {}
        _, head = stack
        if not isinstance(head, (list, tuple)):
            return JoyStackTypeError, f"`{op.name}` requires a quotation as list as top item on the stack.", {}
        return None, "", {}

    # Division by zero guard for division, as binary int/float op.
    if op.name in ('div', '/', 'idiv', '//', 'rem', 'mod', '%') and stack is not nil:
        _, head = stack
        if head == 0:
            return JoyStackValueError, f"`{op.name}` would divide by zero and cause a runtime exception.", {}

    if eff == {}:
        return None, "", {}

    items = stack_to_list(stack)
    # Handle important quotation-types: e.g. predicate must return bool.
    for sym, val in zip(reversed(eff['inputs_sym']), items):
        assert isinstance(sym, dict)
        if val == [] and sym.get('type') == 'Predicate':
            return JoyStackValueError, f"`{op.name}` predicate cannot be empty, got [].", eff

    exc, msg = _check_signature_exceptions(eff['inputs'], list(reversed(items)), op.name)
    if exc is not None:
        return exc, msg, eff

    # Extra semantic guard for 'index' bounds when types look correct.
    if op.name == 'index' and len(items) >= 2 and isinstance(items[0], (list, str)) and isinstance(items[1], int):
        idx, seq = items[1], items[0]
        if not (0 <= int(idx) < len(seq)):
            return JoyStackValueError, f"`{op.name}` would index a list out of bounds.", eff

    # Guard for list operations that require non-empty lists: op_uncons, op_first, op_last.
    if op.name in ('uncons', 'first', 'last') and len(items) >= 1 and isinstance(items[0], (list, str)):
        if len(items[0]) == 0:
               return JoyStackValueError, f"`{op.name}` requires a non-empty list, got empty {type(items[0]).__name__}.", eff

    return None, "", eff


def _is_exit_marker(op: Any) -> bool:
    return isinstance(op, bytes) and op.startswith(b'EXIT-')

def _make_exit_marker(op: Operation, stack: Stack) -> bytes:
    return f"EXIT-{id(op):x}-{id(stack):x}".encode("ascii")

def _has_fixed_stack_effect(eff: dict[str, Any]) -> bool:
    return len(eff['inputs']) == eff['arity'] and len(eff['outputs']) == eff['valency']


def can_execute(op: Operation, stack: Stack) -> tuple[bool, str, dict[str, Any]]:
    eff = _get_operation_signature(op)
    exc_type, msg, eff = _op_causes_exception(op, stack, eff=eff)
    return exc_type is None, msg, eff


def validate_stack_before(op: Operation, stack: Stack, *, eff: dict[str, Any]) -> None:
    exc_type, msg, _ = _op_causes_exception(op, stack, eff=eff)
    if exc_type is not None:
        raise exc_type(msg, joy_op=op, joy_token=op.name, joy_stack=stack)

def validate_stack_after(op: Operation, before_stack: Stack, after_stack: Stack, *, eff: dict[str, Any]) -> None:
    """Validate that runtime stack depth and output types match declared stack effects (LTR convention)."""
    if eff == {}: return

    # Segment-polymorphic effects (e.g. X../Y..) are represented symbolically in arity/valency,
    # but concrete runtime inputs/outputs are intentionally elided. Strict depth checks are only
    # meaningful when fixed runtime lists are available.
    if not _has_fixed_stack_effect(eff):
        return

    n_inputs, n_outputs = eff['arity'], eff['valency']
    if n_outputs < 0: return

    base_before = before_stack
    for _ in range(n_inputs):
        base_before, _ = base_before

    base_after = after_stack
    out_items: list[Any] = []
    n_produced = 0
    while base_after is not nil and base_after != base_before:
        base_after, head = base_after
        if n_produced < n_outputs:
            out_items.append(head)
        n_produced += 1

    if n_produced < n_outputs:
        raise JoyStackShapeError(f"`{op.name}` produced fewer outputs than declared ({n_produced} < {n_outputs}).", joy_op=op, joy_stack=after_stack)
    if base_after == base_before and n_produced > n_outputs:
        raise JoyStackShapeError(f"`{op.name}` produced more outputs than declared ({n_produced} > {n_outputs}).", joy_op=op, joy_stack=after_stack)
    if base_after != base_before:
        raise JoyStackShapeError(f"`{op.name}` corrupted stack tail ({n_produced} outputs before mismatch).", joy_op=op, joy_stack=after_stack)

    # Validate output types incorrect order: out_items is TOS-first, outputs is BOS-first.
    for i, (actual, expected_type) in enumerate(zip(out_items, reversed(eff['outputs']))):
        if expected_type in (Any, None):
            continue
        if not isinstance(actual, expected_type):
            atn, etn = type(actual).__name__, _expected_type_name(expected_type)
            raise JoyStackTypeError(f"`{op.name}` produced output {atn} but declared {etn} at position {i+1} from top.", joy_op=op, joy_stack=after_stack)


def interpret_step(program, stack, lib: Library, *, inject_exit_marker: bool = False):
    op = program.popleft()
    if _is_exit_marker(op): return stack, program

    if isinstance(op, bytes) and op in (b'ABORT', b'BREAK'):
        print(f"\033[97m  ~ :\033[0m  ", end=''); show_program_and_stack(program, stack)
        if op == b'ABORT': sys.exit(-1)
        if op == b'BREAK': input()

    if not isinstance(op, Operation):
        stack = Stack(stack, op)
        return stack, program

    match op.type:
        case Operation.FUNCTION:
            stack = op.ptr(stack)
        case Operation.COMBINATOR:
            stack = op.ptr(op, program, stack, lib=lib)
        case Operation.EXECUTE:
            assert lib is not None
            q = lib.get_quotation(op.ptr, meta=op.meta)
            if q is None:
                raise JoyNameError(f"Unknown quotation `{op.name}`.", joy_token=op.name, joy_op=op)
            if q.program is None:
                raise JoyNotImplementedError(f"Quotation `{op.name}` is declared but not implemented.", joy_op=op)
            if inject_exit_marker:  # Placeholder to trigger validation after quotation is done.
                program.appendleft(_make_exit_marker(op, stack))
            program.extendleft(reversed(q.program))

    return stack, program


def interpret(program: list, stack=None, lib: Library = None, *, stepper=None, verbosity=0, validate=False, stats=None):
    stack = nil if stack is None else stack
    program = collections.deque(program)
    stepper = stepper or interpret_step

    # This is a virtual "call stack" as an optional overlay on the full stack/queue — used for validation only.
    call_stack: list[tuple[bytes, Operation, Stack, dict[str, Any]]] = []

    def is_notable(op):
        if not isinstance(op, Operation): return False
        return isinstance(op.ptr, list) or op.type == Operation.COMBINATOR

    step = 0
    while program:
        op = program[0]

        eff = _get_operation_signature(op) if validate and isinstance(op, Operation) else None
        is_fixed_execute = eff and (op.type == Operation.EXECUTE) and _has_fixed_stack_effect(eff)

        try:
            if validate and _is_exit_marker(op):
                marker = program.popleft()
                if len(call_stack) == 0:
                    raise RuntimeError("Unexpected EXIT marker with no pending EXECUTE postcheck.")
                expected_marker, execute_op, before_stack, execute_eff = call_stack.pop()
                if marker != expected_marker:
                    raise RuntimeError(f"Mismatched EXIT marker. Expected `{expected_marker!r}` got `{marker!r}`.")
                validate_stack_after(execute_op, before_stack, stack, eff=execute_eff)
                continue

            if validate and isinstance(op, Operation):
                validate_stack_before(op, stack, eff=eff)
                if is_fixed_execute:
                    call_stack.append((_make_exit_marker(op, stack), op, stack, eff))

            if verbosity == 2 or (verbosity == 1 and (is_notable(op) or step == 0)):
                print(f"\033[90m{step:>3} :\033[0m  ", end='')
                show_program_and_stack(program, stack)

            step += 1
            new_stack, new_program = stepper(program, stack, lib, inject_exit_marker=is_fixed_execute)

            if validate and isinstance(op, Operation) and op.type != Operation.EXECUTE:
                validate_stack_after(op, stack, new_stack, eff=eff)
            stack, program = new_stack, new_program

        except Exception as exc:
            exc.joy_op = getattr(exc, 'joy_op', None) or op
            exc.joy_token = getattr(exc, 'joy_token', None) or getattr(exc.joy_op, 'name', None)
            exc.joy_stack = stack
            exc.joy_queue = program
            raise

    if verbosity > 0:
        print(f"\033[90m{step:>3} :\033[0m  ", end='')
        show_program_and_stack(program, stack)
    if stats is not None:
        stats['steps'] = stats.get('steps', 0) + step

    return stack
