"""Allow running the CLI with ``python -m camelsch``."""

from camelsch.cli import app

app()
