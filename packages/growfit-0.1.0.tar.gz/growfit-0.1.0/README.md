# GrowFit

GrowFit Python package.

## Install

```bash
pip install growfit