def hello():
    return "Hello from GrowFit"