"""MCP server for w8s-astro-mcp."""

import asyncio
import json
import logging
import sys
from datetime import datetime
from typing import Any, Dict, Optional

from mcp.server import Server
from mcp.types import Tool, TextContent

import os
import urllib.request
from pathlib import Path

from .utils.ephemeris import EphemerisEngine, EphemerisError
from .utils.db_helpers import DatabaseHelper
from .tools.analysis_tools import (
    compare_charts,
    find_planets_in_houses,
    format_aspect_report,
    format_house_report,
    AnalysisError
)
from .tools.visualization import create_natal_chart
from .tools.profile_management import (
    get_profile_management_tools,
    handle_profile_tool
)
from .tools.connection_management import (
    get_connection_tools,
    handle_connection_tool,
    CONNECTION_TOOL_NAMES,
)


# Initialize MCP server
app = Server("w8s-astro-mcp")

# Global state
db_helper: Optional[DatabaseHelper] = None
ephemeris: Optional[EphemerisEngine] = None


def init_db():
    """Initialize database helper."""
    global db_helper
    if db_helper is None:
        db_helper = DatabaseHelper()
    return db_helper


def init_ephemeris() -> EphemerisEngine:
    """Initialize the ephemeris engine (lazy singleton)."""
    global ephemeris
    if ephemeris is None:
        # Honour an optional env-var override for the .se1 file directory.
        ephe_path = os.environ.get("SE_EPHE_PATH") or None
        ephemeris = EphemerisEngine(ephe_path=ephe_path)
    return ephemeris


def get_natal_chart_data():
    """Get natal chart from primary profile."""
    db = init_db()

    profile = db.get_current_profile()
    if not profile:
        raise EphemerisError("No primary profile found. Run migration script first.")

    return db.get_natal_chart_data(profile)


def get_chart_for_date(date_str, time_str="12:00", location=None):
    """Get chart for specific date at a location."""
    engine = init_ephemeris()
    db = init_db()

    # Get location
    if location is None:
        profile = db.get_current_profile()
        location = db.get_current_home_location(profile)
        if not location:
            raise EphemerisError("No current home location found")

    return engine.get_chart(
        latitude=location.latitude,
        longitude=location.longitude,
        date_str=date_str,
        time_str=time_str,
        house_system_code='P'  # TODO: Get from profile
    )


@app.list_tools()
async def list_tools() -> list[Tool]:
    """List available MCP tools."""
    # Core tools
    core_tools = [
        Tool(
            name="check_ephemeris",
            description=(
                "Check the current ephemeris mode and precision level. "
                "Reports whether the built-in Moshier ephemeris (~1 arcminute) or "
                "Swiss Ephemeris data files (~0.001 arcsecond) are active, "
                "and shows the pysweph version."
            ),
            inputSchema={
                "type": "object",
                "properties": {},
            }
        ),
        Tool(
            name="download_ephemeris_files",
            description=(
                "Download Swiss Ephemeris data files for higher-precision calculations. "
                "Upgrades from built-in Moshier ephemeris (~1 arcminute) to full Swiss Ephemeris "
                "files (~0.001 arcsecond). Downloads ~2 MB from the official Swiss Ephemeris "
                "GitHub repository to ~/.w8s-astro-mcp/ephe/. "
                "Use check_ephemeris first to see current precision mode."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "confirm": {
                        "type": "boolean",
                        "description": (
                            "Must be true to proceed. Omit or set false to preview "
                            "file details (names, sizes, source, destination) first."
                        )
                    }
                }
            }
        ),
        Tool(
            name="setup_astro_config",
            description=(
                "Configure birth data and location for transit calculations. "
                "IMPORTANT: Ask the user for information conversationally in steps:\n"
                "1. Ask: 'What's your birthday?' (get YYYY-MM-DD)\n"
                "2. Ask: 'Do you know what time you were born? (If not, we can use 12:00)' (get HH:MM)\n"
                "3. Ask: 'Where were you born?' (get city, state/country)\n"
                "Then look up coordinates and confirm with user before saving."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "birth_date": {
                        "type": "string",
                        "description": "Birth date in YYYY-MM-DD format"
                    },
                    "birth_time": {
                        "type": "string",
                        "description": "Birth time in HH:MM format (24-hour)"
                    },
                    "birth_location_name": {
                        "type": "string",
                        "description": "Location name (e.g., 'Richardson, TX')"
                    },
                    "birth_latitude": {
                        "type": "number",
                        "description": "Latitude in decimal degrees"
                    },
                    "birth_longitude": {
                        "type": "number",
                        "description": "Longitude in decimal degrees"
                    },
                    "birth_timezone": {
                        "type": "string",
                        "description": "Timezone (e.g., 'America/Chicago')"
                    }
                },
                "required": ["birth_date", "birth_time", "birth_location_name", 
                           "birth_latitude", "birth_longitude", "birth_timezone"]
            }
        ),
        Tool(
            name="view_config",
            description="View current astrological configuration (birth data and saved locations)",
            inputSchema={
                "type": "object",
                "properties": {},
            }
        ),
        Tool(
            name="get_natal_chart",
            description="Get the natal chart (birth chart) planetary positions for the configured birth data",
            inputSchema={
                "type": "object",
                "properties": {},
            }
        ),
        Tool(
            name="get_transits",
            description="Get current planetary transits for a specific date and location",
            inputSchema={
                "type": "object",
                "properties": {
                    "date": {
                        "type": "string",
                        "description": "Date in YYYY-MM-DD format (optional, defaults to today)"
                    },
                    "time": {
                        "type": "string",
                        "description": "Time in HH:MM format (optional, defaults to 12:00)"
                    },
                    "location": {
                        "type": "string",
                        "description": "Location name (optional, defaults to 'current')"
                    }
                }
            }
        ),
        Tool(
            name="compare_charts",
            description=(
                "Calculate aspects between two charts. "
                "Use for synastry (comparing two natal charts) or "
                "transits (comparing natal chart with current positions). "
                "Finds conjunctions, oppositions, trines, squares, sextiles, and minor aspects."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "chart1_date": {
                        "type": "string",
                        "description": "Date for first chart (YYYY-MM-DD), use 'natal' for configured birth chart"
                    },
                    "chart1_time": {
                        "type": "string",
                        "description": "Time for first chart in HH:MM format (optional, defaults to 12:00)"
                    },
                    "chart2_date": {
                        "type": "string",
                        "description": "Date for second chart (YYYY-MM-DD), use 'natal' for birth chart or 'today' for current"
                    },
                    "chart2_time": {
                        "type": "string",
                        "description": "Time for second chart in HH:MM format (optional, defaults to 12:00)"
                    },
                    "orb_multiplier": {
                        "type": "number",
                        "description": "Multiplier for aspect orbs (optional, default 1.0)"
                    },
                    "planets_only": {
                        "type": "boolean",
                        "description": "If true, only compare planets, not angles/points (optional, default true)"
                    }
                },
                "required": ["chart1_date", "chart2_date"]
            }
        ),
        Tool(
            name="find_house_placements",
            description="Determine which house each planet occupies in a chart. Shows both which planets are in each house and which house each planet is in.",
            inputSchema={
                "type": "object",
                "properties": {
                    "date": {
                        "type": "string",
                        "description": "Date for chart (YYYY-MM-DD), use 'natal' for configured birth chart or 'today' for current"
                    },
                    "time": {
                        "type": "string",
                        "description": "Time in HH:MM format (optional, defaults to 12:00)"
                    }
                },
                "required": ["date"]
            }
        ),
        Tool(
            name="visualize_natal_chart",
            description="Generate a circular natal chart visualization and save to file. Creates a traditional astrological chart wheel with zodiac signs, houses, planets, and angles.",
            inputSchema={
                "type": "object",
                "properties": {
                    "output_path": {
                        "type": "string",
                        "description": "Path where to save the chart image (e.g., '~/Downloads/natal_chart.png'). Defaults to 'natal_chart.png' in current directory."
                    },
                    "title": {
                        "type": "string",
                        "description": "Custom title for the chart (optional, defaults to 'Natal Chart')"
                    }
                }
            }
        )
    ]
    
    # Add profile management tools
    profile_tools = get_profile_management_tools()

    # Add connection management tools (Phase 7)
    connection_tools = get_connection_tools()

    return core_tools + profile_tools + connection_tools



@app.call_tool()
async def call_tool(name: str, arguments: Any) -> list[TextContent]:
    """Handle tool calls."""
    
    if name == "check_ephemeris":
        import swisseph as swe
        engine = init_ephemeris()
        mode = engine.get_mode()
        ephe_dir = Path.home() / ".w8s-astro-mcp" / "ephe"
        files = list(ephe_dir.glob("*.se1")) if ephe_dir.exists() else []

        lines = [
            f"Ephemeris mode: {mode}",
            f"pysweph version: {swe.__version__}",
        ]
        if mode == "moshier":
            lines.append("Precision: ~1 arcminute (Moshier built-in, no files needed)")
            lines.append("Use download_ephemeris_files to upgrade to ~0.001 arcsecond precision.")
        else:
            lines.append(f"Precision: ~0.001 arcsecond (Swiss Ephemeris files)")
            lines.append(f"Ephemeris path: {engine.ephe_path}")
            if files:
                lines.append(f"Data files: {', '.join(f.name for f in sorted(files))}")

        return [TextContent(type="text", text="\n".join(lines))]

    elif name == "download_ephemeris_files":
        ephe_dir = Path.home() / ".w8s-astro-mcp" / "ephe"
        file_manifest = [
            ("sepl_18.se1", "Planets (Sun–Pluto), 1800–2400 CE",  "473 KB"),
            ("semo_18.se1", "Moon, 1800–2400 CE",                  "1.3 MB"),
            ("seas_18.se1", "Main asteroids, 1800–2400 CE",        "218 KB"),
        ]
        base_url = "https://raw.githubusercontent.com/aloistr/swisseph/master/ephe"

        confirm = arguments.get("confirm", False)

        if not confirm:
            # Show manifest; require explicit confirmation before downloading.
            lines = [
                "Swiss Ephemeris data files upgrade",
                "",
                f"Current mode: {init_ephemeris().get_mode()}",
                "After upgrade: Swiss Ephemeris (~0.001 arcsecond precision)",
                "",
                "Files to download:",
            ]
            for fname, desc, size in file_manifest:
                lines.append(f"  {fname:<16} {desc:<40} {size}")
            lines += [
                f"  Total                                                    ~2.0 MB",
                "",
                f"Source:      github.com/aloistr/swisseph (official Swiss Ephemeris repository)",
                f"Destination: {ephe_dir}",
                "",
                "Call again with confirm=true to proceed.",
            ]
            return [TextContent(type="text", text="\n".join(lines))]

        # Check which files are already present.
        ephe_dir.mkdir(parents=True, exist_ok=True)
        lines = ["Downloading Swiss Ephemeris data files...", ""]
        all_present = True
        for fname, _desc, _size in file_manifest:
            dest = ephe_dir / fname
            if dest.exists():
                lines.append(f"  ✓ {fname}  already present — skipped")
            else:
                all_present = False
                url = f"{base_url}/{fname}"
                try:
                    urllib.request.urlretrieve(url, dest)
                    size_kb = dest.stat().st_size // 1024
                    lines.append(f"  ✓ {fname}  {size_kb} KB   saved to {ephe_dir}")
                except Exception as exc:
                    lines.append(f"  ✗ {fname}  FAILED: {exc}")

        # Activate the downloaded files immediately (no restart needed).
        global ephemeris
        ephemeris = EphemerisEngine(ephe_path=str(ephe_dir))

        lines += ["", "High-precision mode active. No restart required."]
        return [TextContent(type="text", text="\n".join(lines))]
    
    elif name == "setup_astro_config":
        return [TextContent(
            type="text",
            text="⚠️ This tool is deprecated.\n\n"
                 "The w8s-astro-mcp now uses SQLite database instead of config.json.\n\n"
                 "Your data has been migrated to: ~/.w8s-astro-mcp/astro.db\n\n"
                 "To add new profiles or locations, use the database migration script or "
                 "contact the developer for profile management tools."
        )]
    
    elif name == "view_config":
        try:
            db = init_db()
            
            response = "# Current Configuration\n\n"
            
            # Primary profile
            profile = db.get_current_profile()
            if profile:
                birth_loc = db.get_birth_location(profile)
                response += "## Primary Profile\n"
                response += f"Name: {profile.name}\n"
                response += f"Birth Date: {profile.birth_date}\n"
                response += f"Birth Time: {profile.birth_time}\n"
                if birth_loc:
                    response += f"Birth Location: {birth_loc.label}\n"
                    response += f"Coordinates: {birth_loc.latitude}, {birth_loc.longitude}\n"
                    response += f"Timezone: {birth_loc.timezone}\n"
                response += "\n"
            else:
                response += "## Primary Profile\nNot configured.\n\n"
            
            # Locations
            if profile:
                locations = db.list_all_locations(profile)
                if locations:
                    response += "## Saved Locations\n"
                    for loc in locations:
                        marker = " (current home)" if loc.is_current_home else ""
                        response += f"- {loc.label}{marker}: {loc.latitude}, {loc.longitude}\n"
                    response += "\n"
            
            response += f"Database: {db.engine.url.database}\n"
            
            return [TextContent(type="text", text=response)]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {e}")]
    
    elif name == "get_natal_chart":
        try:
            # Get natal chart data from database
            result = get_natal_chart_data()
            
            # Format response
            response = f"# Natal Chart for {result['metadata']['date']} at {result['metadata']['time']}\n"
            response += f"Location: {result['metadata']['latitude']}, {result['metadata']['longitude']}\n"
            response += f"House System: {result['metadata']['house_system']}\n\n"
            
            response += "## Planetary Positions\n"
            for planet_name, data in result['planets'].items():
                response += f"- **{planet_name}**: {data['formatted']}\n"
            
            response += "\n## House Cusps\n"
            for house_num in sorted(result['houses'].keys(), key=lambda x: int(x)):
                data = result['houses'][house_num]
                response += f"- House {house_num}: {data['formatted']}\n"
            
            if result['points']:
                response += "\n## Angles\n"
                for point, data in result['points'].items():
                    response += f"- **{point}**: {data['formatted']}\n"
            
            return [TextContent(type="text", text=response)]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {e}")]
    
    elif name == "get_transits":
        try:
            engine = init_ephemeris()
            db = init_db()
            
            date_str = arguments.get("date")
            time_str = arguments.get("time", "12:00")
            location_arg = arguments.get("location", "current")
            
            # Get profile
            profile = db.get_current_profile()
            if not profile:
                return [TextContent(type="text", text="No primary profile found")]
            
            # Get location
            if location_arg == "current" or location_arg == "home":
                location = db.get_current_home_location(profile)
                if not location:
                    return [TextContent(type="text", text="No current home location set")]
            elif location_arg == "birth":
                location = db.get_birth_location(profile)
            else:
                # Try to find by label
                location = db.get_location_by_label(location_arg, profile)
                if not location:
                    return [TextContent(type="text", text=f"Location '{location_arg}' not found")]
            
            # Get transits from ephemeris engine
            result = engine.get_chart(
                latitude=location.latitude,
                longitude=location.longitude,
                date_str=date_str,
                time_str=time_str,
                house_system_code='P'  # TODO: Get from profile
            )
            
            # 🆕 AUTO-LOG: Save this transit lookup to database
            try:
                lookup_datetime = datetime.strptime(
                    f"{result['metadata']['date']} {result['metadata']['time']}",
                    "%Y-%m-%d %H:%M:%S"
                )
                db.save_transit_lookup(
                    profile=profile,
                    location=location,
                    lookup_datetime=lookup_datetime,
                    transit_data=result,
                    house_system_id=profile.preferred_house_system_id
                )
            except Exception as log_error:
                # Don't fail the entire request if logging fails
                print(f"Warning: Failed to log transit lookup: {log_error}")
            
            # Format response
            response = f"Transits for {result['metadata']['date']} at {result['metadata']['time']}\n"
            response += f"Location: {location.label} ({result['metadata']['latitude']}, {result['metadata']['longitude']})\n"
            response += f"House System: {result['metadata']['house_system']}\n\n"
            
            response += "Planets:\n"
            for planet, data in result['planets'].items():
                response += f"  {planet}: {data['degree']:.2f}° {data['sign']}\n"
            
            response += "\nHouses:\n"
            for house_num in sorted(result['houses'].keys(), key=lambda x: int(x)):
                data = result['houses'][house_num]
                response += f"  House {house_num}: {data['degree']:.2f}° {data['sign']}\n"
            
            if result['points']:
                response += "\nSpecial Points:\n"
                for point, data in result['points'].items():
                    response += f"  {point}: {data['degree']:.2f}° {data['sign']}\n"
            
            return [TextContent(type="text", text=response)]
            
        except EphemerisError as e:
            return [TextContent(type="text", text=f"Ephemeris error: {e}")]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {e}")]
    
    elif name == "compare_charts":
        try:
            # chart retrieval goes through get_chart_for_date which calls init_ephemeris()
            
            # Get chart1
            chart1_date = arguments["chart1_date"]
            chart1_time = arguments.get("chart1_time", "12:00")
            
            if chart1_date == "natal":
                chart1 = get_natal_chart_data()
            elif chart1_date == "today":
                chart1 = get_chart_for_date(None, chart1_time)
            else:
                chart1 = get_chart_for_date(chart1_date, chart1_time)
            
            # Get chart2
            chart2_date = arguments["chart2_date"]
            chart2_time = arguments.get("chart2_time", "12:00")
            
            if chart2_date == "natal":
                chart2 = get_natal_chart_data()
            elif chart2_date == "today":
                chart2 = get_chart_for_date(None, chart2_time)
            else:
                chart2 = get_chart_for_date(chart2_date, chart2_time)
            
            # Compare charts
            result = compare_charts(
                chart1,
                chart2,
                orb_multiplier=arguments.get("orb_multiplier", 1.0),
                planets_only=arguments.get("planets_only", True)
            )
            
            # Format and return
            report = format_aspect_report(result)
            return [TextContent(type="text", text=report)]
            
        except AnalysisError as e:
            return [TextContent(type="text", text=f"Analysis error: {e}")]
        except EphemerisError as e:
            return [TextContent(type="text", text=f"Ephemeris error: {e}")]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {e}")]
    
    elif name == "find_house_placements":
        try:
            # Get chart
            date = arguments["date"]
            time = arguments.get("time", "12:00")
            
            if date == "natal":
                chart = get_natal_chart_data()
            elif date == "today":
                chart = get_chart_for_date(None, time)
            else:
                chart = get_chart_for_date(date, time)
            
            # Analyze house placements
            result = find_planets_in_houses(
                chart["planets"],
                chart["houses"]
            )
            
            # Format and return
            report = format_house_report(result)
            return [TextContent(type="text", text=report)]
            
        except AnalysisError as e:
            return [TextContent(type="text", text=f"Analysis error: {e}")]
        except EphemerisError as e:
            return [TextContent(type="text", text=f"Ephemeris error: {e}")]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {e}")]
    
    elif name == "visualize_natal_chart":
        try:
            # Get natal chart data from database
            natal_chart = get_natal_chart_data()
            
            # Get output path
            output_path = arguments.get("output_path", "natal_chart.png")
            chart_title = arguments.get("title", "Natal Chart")
            
            # Create visualization
            saved_path = create_natal_chart(
                planets=natal_chart["planets"],
                houses=natal_chart["houses"],
                points=natal_chart["points"],
                chart_title=chart_title,
                output_path=output_path
            )
            
            return [TextContent(
                type="text",
                text=f"Natal chart visualization created successfully!\n\nSaved to: {saved_path}\n\nThe chart shows:\n- Zodiac wheel with all 12 signs\n- Your 12 houses (Placidus system)\n- All 10 planets positioned by degree\n- Ascendant (red line) and MC (blue line)\n\nYou can now view or share this image."
            )]
            
        except Exception as e:
            return [TextContent(type="text", text=f"Error creating visualization: {e}")]
    
    # Profile management tools
    elif name in ["list_profiles", "create_profile", "update_profile", "delete_profile",
                  "set_current_profile", "add_location", "remove_location"]:
        db = init_db()
        return await handle_profile_tool(name, arguments, db)

    # Connection management tools (Phase 7)
    elif name in CONNECTION_TOOL_NAMES:
        db = init_db()
        engine = init_ephemeris()
        return await handle_connection_tool(name, arguments, db, engine)

    else:
        return [TextContent(type="text", text=f"Unknown tool: {name}")]


async def main():
    """Run the MCP server."""
    from mcp.server.stdio import stdio_server
    
    async with stdio_server() as (read_stream, write_stream):
        await app.run(
            read_stream,
            write_stream,
            app.create_initialization_options()
        )


if __name__ == "__main__":
    asyncio.run(main())
