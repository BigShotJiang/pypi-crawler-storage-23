"""Parsers for swetest and other ephemeris data."""
