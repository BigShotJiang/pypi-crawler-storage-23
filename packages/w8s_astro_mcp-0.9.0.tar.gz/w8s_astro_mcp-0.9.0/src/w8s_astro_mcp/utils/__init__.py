"""Utility functions for calculations and caching."""
