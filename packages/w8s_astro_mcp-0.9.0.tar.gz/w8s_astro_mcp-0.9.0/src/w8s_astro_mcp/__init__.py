"""w8s-astro-mcp: Astrological transit MCP server using Swiss Ephemeris."""

__version__ = "0.1.0"
