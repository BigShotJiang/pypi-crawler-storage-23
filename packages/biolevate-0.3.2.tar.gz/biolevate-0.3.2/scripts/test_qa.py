#!/usr/bin/env python3
"""Integration tests for the Question Answering resource.

Uses a file with factual content from test_resources/qa_sample.txt.
Uploads that file, creates it, and waits for indexation before running QA.
"""

from __future__ import annotations

import asyncio
import json
import time
from pathlib import Path
from typing import TYPE_CHECKING, Any

from biolevate_client.models import EliseQuestionInput
from scripts.common import create_client, get_base_parser
from scripts.test_utils import TestRunner

if TYPE_CHECKING:
    from biolevate.resources.files import FilesResource
    from biolevate.resources.question_answering import QuestionAnsweringResource

TERMINAL_STATUSES = ("SUCCESS", "FAILED", "ABORTED")


def _default_test_resources_dir() -> Path:
    return Path(__file__).resolve().parent / "test_resources"


def _get_qa_sample(test_files_dir: Path, test_file_path: Path | None) -> Path | None:
    """Get qa_sample.txt (required). Returns None only if file doesn't exist."""
    if test_file_path is not None:
        if test_file_path.is_file():
            return test_file_path
        return None
    sample = test_files_dir / "qa_sample.txt"
    if sample.is_file():
        return sample
    return None


def _mime_type_for_path(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix == ".pdf":
        return "application/pdf"
    if suffix == ".txt":
        return "text/plain"
    return "application/octet-stream"


async def wait_until_indexed(
    files_resource: FilesResource,
    file_id: str,
    timeout_seconds: float,
    initial_interval: float = 2.0,
    max_interval: float = 10.0,
) -> tuple[bool, float]:
    elapsed = 0.0
    interval = initial_interval
    while elapsed < timeout_seconds:
        file_info = await files_resource.get(file_id)
        if getattr(file_info, "indexed", None) is True:
            return True, elapsed
        await asyncio.sleep(interval)
        elapsed += interval
        interval = min(interval * 2, max_interval)
    return False, elapsed


async def wait_until_job_terminal(
    qa_resource: QuestionAnsweringResource,
    job_id: str,
    timeout_seconds: float,
    initial_interval: float = 3.0,
    max_interval: float = 15.0,
) -> tuple[str, float]:
    elapsed = 0.0
    interval = initial_interval
    while elapsed < timeout_seconds:
        job = await qa_resource.get_job(job_id)
        status = getattr(job, "status", None)
        if status in TERMINAL_STATUSES:
            return status, elapsed
        await asyncio.sleep(interval)
        elapsed += interval
        interval = min(interval * 2, max_interval)
    return "", elapsed


async def main() -> None:
    parser = get_base_parser("Test Question Answering resource")
    parser.add_argument(
        "--provider-id",
        type=str,
        default=None,
        help="ID of the provider to use (default: first available)",
    )
    parser.add_argument(
        "--file-id",
        type=str,
        default=None,
        help="Use this file ID and skip file discovery/setup",
    )
    parser.add_argument(
        "--job-timeout",
        type=float,
        default=180.0,
        help="Max seconds to wait for job to reach terminal state (default: 180)",
    )
    parser.add_argument(
        "--index-timeout",
        type=float,
        default=120.0,
        help="Max seconds to wait for file indexation (default: 120)",
    )
    parser.add_argument(
        "--test-files-dir",
        type=Path,
        default=None,
        help="Directory for qa_sample.txt (default: scripts/test_resources)",
    )
    parser.add_argument(
        "--test-file",
        type=Path,
        default=None,
        help="Path to QA sample file",
    )
    args = parser.parse_args()

    client = create_client(args)
    runner = TestRunner(resource="qa", api_url=args.api_url)

    test_files_dir = args.test_files_dir or _default_test_resources_dir()
    provider_id: str | None = None
    file_id: str | None = args.file_id
    test_folder_name = f"SDK-TEST-QA-{int(time.time())}"
    uploaded_key: str | None = None
    job_id: str | None = None

    async with client:

        async def test_setup_provider_and_file() -> dict[str, Any]:
            nonlocal provider_id, file_id, uploaded_key

            sample_path = _get_qa_sample(test_files_dir, args.test_file)
            if not sample_path:
                raise AssertionError(
                    f"qa_sample.txt not found in {test_files_dir}. This file is required for QA tests."
                )

            if args.file_id:
                file_id = args.file_id
                return {
                    "file_id": file_id,
                    "source": "cli",
                    "sample_file": sample_path.name,
                }

            if args.provider_id:
                provider_id = args.provider_id
            else:
                providers = await client.providers.list(page=0, page_size=1)
                if not providers.data or len(providers.data) == 0:
                    raise AssertionError("No provider available. Cannot run QA tests.")
                provider_id = str(providers.data[0].id.id) if providers.data[0].id else None

            if not provider_id:
                raise AssertionError("Provider ID is missing.")

            with open(sample_path, "rb") as f:
                await client.items.upload(
                    provider_id,
                    key=f"{test_folder_name}/",
                    file=f,
                    file_name=sample_path.name,
                    mime_type=_mime_type_for_path(sample_path),
                )
            uploaded_key = f"{test_folder_name}/{sample_path.name}"

            file_info = await client.files.create(provider_id, key=uploaded_key)
            file_id = str(file_info.id.id) if file_info.id else None
            if not file_id:
                raise AssertionError("Failed to create indexed file.")

            indexed, waited = await wait_until_indexed(client.files, file_id, timeout_seconds=args.index_timeout)
            if not indexed:
                raise AssertionError(f"File indexation timed out after {waited:.1f}s")

            state_path = Path("test-reports/qa-test-state.json")
            state_path.parent.mkdir(parents=True, exist_ok=True)
            state_path.write_text(
                json.dumps(
                    {
                        "provider_id": provider_id,
                        "file_id": file_id,
                        "key": uploaded_key,
                        "folder_name": test_folder_name,
                    },
                    indent=2,
                )
            )
            return {
                "provider_id": provider_id,
                "file_id": file_id,
                "source": "uploaded_sample",
                "sample_file": sample_path.name,
                "indexed_after_seconds": round(waited, 1),
            }

        await runner.run_test(
            name="setup_provider_and_file",
            test_fn=test_setup_provider_and_file,
            expected_message="Provider and file ready for QA",
        )

        async def test_list_jobs() -> dict[str, Any]:
            result = await client.qa.list_jobs(page=0, page_size=10)
            assert result.data is not None, "data should not be None"
            assert isinstance(result.data, list), "data should be a list"
            return {
                "total_elements": result.total_elements,
                "total_pages": result.total_pages,
                "count": len(result.data) if result.data else 0,
            }

        await runner.run_test(
            name="list_jobs",
            test_fn=test_list_jobs,
            expected_message="Listed QA jobs",
        )

        async def test_list_jobs_pagination() -> dict[str, Any]:
            result = await client.qa.list_jobs(page=0, page_size=1)
            assert result.data is not None, "data should not be None"
            return {
                "page_size_requested": 1,
                "items_returned": len(result.data) if result.data else 0,
                "has_more": result.has_next,
            }

        await runner.run_test(
            name="list_jobs_pagination",
            test_fn=test_list_jobs_pagination,
            expected_message="Pagination works correctly",
        )

        if not file_id:
            for name in (
                "create_job",
                "wait_until_job_terminal",
                "get_job",
                "get_job_inputs",
                "get_job_outputs",
                "get_job_annotations",
                "list_jobs_after_create",
            ):
                runner.skip_test(name, "No file_id available for QA job")
        else:
            fid: str = file_id

            async def test_create_job() -> dict[str, Any]:
                nonlocal job_id
                questions = [
                    EliseQuestionInput.model_validate(
                        {
                            "id": "q1",
                            "question": "What is the name of the company?",
                            "answerType": {"dataType": "STRING"},
                        }
                    ),
                    EliseQuestionInput.model_validate(
                        {
                            "id": "q2",
                            "question": "When was the company founded?",
                            "answerType": {"dataType": "INT"},
                        }
                    ),
                    EliseQuestionInput.model_validate(
                        {
                            "id": "q3",
                            "question": "Who is the CEO?",
                            "answerType": {"dataType": "STRING"},
                        }
                    ),
                    EliseQuestionInput.model_validate(
                        {
                            "id": "q4",
                            "question": "How many employees does the company have?",
                            "answerType": {"dataType": "INT"},
                        }
                    ),
                    EliseQuestionInput.model_validate(
                        {
                            "id": "q5",
                            "question": "What products does Biolevate offer?",
                            "answerType": {"dataType": "STRING", "multiValued": True},
                        }
                    ),
                ]
                job = await client.qa.create_job(
                    questions=questions,
                    file_ids=[fid],
                )
                job_id = getattr(job, "job_id", None)
                assert job_id, "job_id should be set"
                return {
                    "job_id": job_id,
                    "status": getattr(job, "status", None),
                    "task_type": getattr(job, "task_type", None),
                    "questions_count": len(questions),
                }

            await runner.run_test(
                name="create_job",
                test_fn=test_create_job,
                expected_message="Created QA job",
            )

            if job_id:
                jid: str = job_id

                async def test_wait_until_job_terminal() -> dict[str, Any]:
                    status, waited = await wait_until_job_terminal(
                        client.qa,
                        jid,
                        timeout_seconds=args.job_timeout,
                    )
                    if status not in TERMINAL_STATUSES:
                        raise AssertionError(
                            f"Job did not reach terminal state within {args.job_timeout}s (waited {waited:.1f}s)"
                        )
                    return {"status": status, "waited_seconds": round(waited, 1)}

                await runner.run_test(
                    name="wait_until_job_terminal",
                    test_fn=test_wait_until_job_terminal,
                    expected_message="Job reached terminal state",
                )

                async def test_get_job() -> dict[str, Any]:
                    job = await client.qa.get_job(jid)
                    status = getattr(job, "status", None)
                    return {
                        "job_id": getattr(job, "job_id", None),
                        "status": status,
                        "execution_time": getattr(job, "execution_time", None),
                        "error_message": getattr(job, "error_message", None),
                    }

                await runner.run_test(
                    name="get_job",
                    test_fn=test_get_job,
                    expected_message="Retrieved QA job",
                )

                async def test_get_job_inputs() -> dict[str, Any]:
                    inputs = await client.qa.get_job_inputs(jid)
                    files = getattr(inputs, "files", None)
                    assert files is not None, "inputs.files should be present"
                    input_file_ids = getattr(files, "file_ids", None) or []
                    input_collection_ids = getattr(files, "collection_ids", None) or []
                    questions = getattr(inputs, "questions", None) or []
                    questions_data = [
                        {
                            "id": getattr(q, "id", None),
                            "question": getattr(q, "question", None),
                        }
                        for q in questions
                    ]
                    assert fid in input_file_ids, f"Requested file_id {fid} should be in inputs"
                    return {
                        "file_ids": input_file_ids,
                        "collection_ids": input_collection_ids,
                        "questions": questions_data,
                    }

                await runner.run_test(
                    name="get_job_inputs",
                    test_fn=test_get_job_inputs,
                    expected_message="Retrieved job inputs",
                )

                async def test_get_job_outputs() -> dict[str, Any]:
                    outputs = await client.qa.get_job_outputs(jid)
                    results = getattr(outputs, "results", None)
                    assert results is not None, "outputs.results should be present"
                    assert isinstance(results, list), "outputs.results should be a list"

                    answers_data: list[dict[str, Any]] = []
                    for r in results:
                        question = getattr(r, "question", None)
                        raw_value = getattr(r, "raw_value", None)
                        explanation = getattr(r, "explanation", None)
                        sourced_content = getattr(r, "sourced_content", None)
                        answer_validity = getattr(r, "answer_validity", None)
                        answers_data.append(
                            {
                                "question": question,
                                "raw_value": raw_value,
                                "explanation": explanation[:150] if explanation else None,
                                "sourced_content": sourced_content[:150] if sourced_content else None,
                                "answer_validity": answer_validity,
                            }
                        )
                    return {
                        "results_count": len(results),
                        "answers": answers_data,
                    }

                await runner.run_test(
                    name="get_job_outputs",
                    test_fn=test_get_job_outputs,
                    expected_message="Retrieved job outputs",
                )

                async def test_get_job_annotations() -> dict[str, Any]:
                    annotations = await client.qa.get_job_annotations(jid)
                    assert isinstance(annotations, list), "annotations should be a list"
                    annotation_summaries: list[dict[str, Any]] = []
                    for a in annotations[:5]:
                        ann_type = getattr(a, "type", None)
                        ann_status = getattr(a, "status", None)
                        annotation_summaries.append(
                            {
                                "type": ann_type,
                                "status": ann_status,
                            }
                        )
                    return {
                        "annotations_count": len(annotations),
                        "sample_annotations": annotation_summaries,
                    }

                await runner.run_test(
                    name="get_job_annotations",
                    test_fn=test_get_job_annotations,
                    expected_message="Retrieved job annotations",
                )

                async def test_list_jobs_after_create() -> dict[str, Any]:
                    result = await client.qa.list_jobs(page=0, page_size=50)
                    assert result.data is not None, "data should not be None"
                    job_ids = [getattr(j, "job_id", None) for j in (result.data or []) if getattr(j, "job_id", None)]
                    assert jid in job_ids, f"Created job {jid} should appear in list"
                    return {"job_found": True, "total": len(result.data or [])}

                await runner.run_test(
                    name="list_jobs_after_create",
                    test_fn=test_list_jobs_after_create,
                    expected_message="Created job appears in list",
                )

        non_existent_id = "00000000-0000-0000-0000-000000000000"

        async def test_get_job_not_found() -> dict[str, Any]:
            from biolevate import NotFoundError

            try:
                await client.qa.get_job(non_existent_id)
                raise AssertionError("Expected NotFoundError was not raised")
            except NotFoundError:
                return {"error_type": "NotFoundError", "correctly_raised": True}

        await runner.run_test(
            name="get_job_not_found",
            test_fn=test_get_job_not_found,
            expected_message="NotFoundError raised for non-existent job",
        )

        async def test_get_job_inputs_not_found() -> dict[str, Any]:
            from biolevate import NotFoundError

            try:
                await client.qa.get_job_inputs(non_existent_id)
                raise AssertionError("Expected NotFoundError was not raised")
            except NotFoundError:
                return {"error_type": "NotFoundError", "correctly_raised": True}

        await runner.run_test(
            name="get_job_inputs_not_found",
            test_fn=test_get_job_inputs_not_found,
            expected_message="NotFoundError raised for get_job_inputs",
        )

        async def test_get_job_outputs_not_found() -> dict[str, Any]:
            from biolevate import NotFoundError

            try:
                await client.qa.get_job_outputs(non_existent_id)
                raise AssertionError("Expected NotFoundError was not raised")
            except NotFoundError:
                return {"error_type": "NotFoundError", "correctly_raised": True}

        await runner.run_test(
            name="get_job_outputs_not_found",
            test_fn=test_get_job_outputs_not_found,
            expected_message="NotFoundError raised for get_job_outputs",
        )

        async def test_get_job_annotations_not_found() -> dict[str, Any]:
            from biolevate import NotFoundError

            try:
                await client.qa.get_job_annotations(non_existent_id)
                raise AssertionError("Expected NotFoundError was not raised")
            except NotFoundError:
                return {"error_type": "NotFoundError", "correctly_raised": True}

        await runner.run_test(
            name="get_job_annotations_not_found",
            test_fn=test_get_job_annotations_not_found,
            expected_message="NotFoundError raised for get_job_annotations",
        )

    runner.print_and_save()


if __name__ == "__main__":
    asyncio.run(main())
