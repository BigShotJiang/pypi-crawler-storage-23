# Changelog

## [0.3.2](https://github.com/Biolevate/biolevate-api-sdk/compare/biolevate-v0.3.1...biolevate-v0.3.2) (2026-02-24)


### Bug Fixes

* CI ([bf8ff70](https://github.com/Biolevate/biolevate-api-sdk/commit/bf8ff70b94d5dd8826df41581caa7e0e433e9d48))

## [0.3.1](https://github.com/Biolevate/biolevate-api-sdk/compare/biolevate-v0.3.0...biolevate-v0.3.1) (2026-02-24)


### Bug Fixes

* sdk python comment ([7b195b8](https://github.com/Biolevate/biolevate-api-sdk/commit/7b195b82518163d49c76f8801226d171aabf7673))

## [0.3.0](https://github.com/Biolevate/biolevate-api-sdk/compare/biolevate-v0.2.2...biolevate-v0.3.0) (2026-02-24)


### Features

* documentation ([e4a626a](https://github.com/Biolevate/biolevate-api-sdk/commit/e4a626ab5ef467c040134f3b4f48ffb8384fc629))

## [0.2.2](https://github.com/Biolevate/biolevate-api-sdk/compare/biolevate-v0.2.1...biolevate-v0.2.2) (2026-02-24)


### Bug Fixes

* badge ([b0eb786](https://github.com/Biolevate/biolevate-api-sdk/commit/b0eb786210c54e93f3ec3d20bb8994214601dce1))
* badge ([b27d40f](https://github.com/Biolevate/biolevate-api-sdk/commit/b27d40fef0e0ac34ae2c2d90f4c42d06ae7e9a1c))
* trigger initial release pipeline ([3309669](https://github.com/Biolevate/biolevate-api-sdk/commit/330966996350a0ae84fc48ef024d8623c96eea8b))

## [0.2.1](https://github.com/Biolevate/biolevate-api-sdk/compare/biolevate-v0.2.0...biolevate-v0.2.1) (2026-02-24)


### Bug Fixes

* coverage badge path && lint ([d258e2e](https://github.com/Biolevate/biolevate-api-sdk/commit/d258e2ea9eaf24db76a8575cab452b1c8573f2f0))

## [0.2.0](https://github.com/Biolevate/biolevate-api-sdk/compare/biolevate-v0.1.0...biolevate-v0.2.0) (2026-02-24)


### Features

* CICD pipeline and integration tests ([9bb3033](https://github.com/Biolevate/biolevate-api-sdk/commit/9bb303325fc4f53b5e7808439ed777a2cd097fbc))
* github workflows ([06dbb67](https://github.com/Biolevate/biolevate-api-sdk/commit/06dbb6731c9d26baf7a84bb43fb51b809fea0cad))
