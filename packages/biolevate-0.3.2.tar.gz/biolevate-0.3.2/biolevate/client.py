"""High-level Biolevate client wrapper."""

from __future__ import annotations

from typing import TYPE_CHECKING

from biolevate.resources.collections import CollectionsResource
from biolevate.resources.extraction import ExtractionResource
from biolevate.resources.files import FilesResource
from biolevate.resources.provider_items import ProviderItemsResource
from biolevate.resources.providers import ProvidersResource
from biolevate.resources.question_answering import QuestionAnsweringResource

if TYPE_CHECKING:
    from biolevate_client import ApiClient


class BiolevateClient:
    """High-level client for interacting with the Biolevate API.

    This client wraps the generated low-level client and provides
    a more ergonomic interface with additional features like pipelines.

    Example:
        ```python
        async with BiolevateClient(base_url="https://api.biolevate.com", token="...") as client:
            providers = await client.providers.list()
            for provider in providers.data:
                print(provider.name)
        ```
    """

    def __init__(self, base_url: str, token: str) -> None:
        """Initialize the Biolevate client.

        Args:
            base_url: The base URL of the Biolevate API.
            token: The authentication token (JWT).
        """
        self._base_url = base_url
        self._token = token
        self._client: ApiClient | None = None
        self._providers: ProvidersResource | None = None
        self._items: ProviderItemsResource | None = None
        self._files: FilesResource | None = None
        self._collections: CollectionsResource | None = None
        self._extraction: ExtractionResource | None = None
        self._qa: QuestionAnsweringResource | None = None

    def _get_client(self) -> ApiClient:
        """Get or create the underlying API client."""
        if self._client is None:
            from biolevate_client import ApiClient
            from biolevate_client.configuration import Configuration

            config = Configuration(
                host=self._base_url,
                access_token=self._token,
            )
            self._client = ApiClient(config)
        return self._client

    @property
    def providers(self) -> ProvidersResource:
        """Access the providers resource for managing storage providers."""
        if self._providers is None:
            self._providers = ProvidersResource(self._get_client())
        return self._providers

    @property
    def items(self) -> ProviderItemsResource:
        """Access the provider items resource for managing files/folders within providers."""
        if self._items is None:
            self._items = ProviderItemsResource(self._get_client())
        return self._items

    @property
    def files(self) -> FilesResource:
        """Access the files resource for managing indexed files."""
        if self._files is None:
            self._files = FilesResource(self._get_client())
        return self._files

    @property
    def collections(self) -> CollectionsResource:
        """Access the collections resource for managing file collections."""
        if self._collections is None:
            self._collections = CollectionsResource(self._get_client())
        return self._collections

    @property
    def extraction(self) -> ExtractionResource:
        """Access the extraction resource for metadata extraction jobs."""
        if self._extraction is None:
            self._extraction = ExtractionResource(self._get_client())
        return self._extraction

    @property
    def qa(self) -> QuestionAnsweringResource:
        """Access the question answering resource for QA jobs."""
        if self._qa is None:
            self._qa = QuestionAnsweringResource(self._get_client())
        return self._qa

    async def __aenter__(self) -> BiolevateClient:
        """Enter async context."""
        return self

    async def __aexit__(self, exc_type: type | None, exc_val: Exception | None, exc_tb: object) -> None:
        """Exit async context and close the client."""
        if self._client is not None:
            await self._client.close()
