from v2sim.gui.convertbox import *


if __name__ == "__main__":
    app = ConvertBox()
    app.mainloop()