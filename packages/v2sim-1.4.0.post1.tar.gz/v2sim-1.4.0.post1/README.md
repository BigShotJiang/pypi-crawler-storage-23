## ADDENDUM
The appendix of the paper seems to be lost when uploading the final manuscript. The content of the appendix (bundles of data) can be found [here](https://github.com/hesl-seu/v2sim/tree/main/v2sim/probtable).

# V2Sim: Open-Source V2G Simulation Platform in Urban Power and Transportation Network

**Documents:** http://v2sim.heslab.wiki/

V2Sim is a V2G simulation platform in urban power and transportation network. It is open-source under BSD license. The traffic simulation is based on either [UXsim](https://github.com/toruseo/UXsim) or [SUMO](https://eclipse.dev/sumo/)

**Current version of V2Sim is 1.4**. It has merged two branches: V2Sim (SUMO version) and V2Sim-UX (UXsim version) in version 1.3. Now they share the same GUI and both are included in the same package V2Sim. The cases can be reused (with slight modification), while the saved state cannot.

## Quick start
Visit our documents to see the quick start guide. Links:
+ http://v2sim.heslab.wiki/ (English)  
+ http://v2sim.heslab.wiki/#/zh_hans/ (简体中文)


## Cite

If you are using V2Sim, please cite the paper:
```
@ARTICLE{10970754,
  author={Qian, Tao and Fang, Mingyu and Hu, Qinran and Shao, Chengcheng and Zheng, Junyi},
  journal={IEEE Transactions on Smart Grid}, 
  title={V2Sim: An Open-Source Microscopic V2G Simulation Platform in Urban Power and Transportation Network}, 
  year={2025},
  volume={16},
  number={4},
  pages={3167-3178},
  keywords={Vehicle-to-grid;Partial discharges;Microscopy;Batteries;Planning;Discharges (electric);Optimization;Vehicle dynamics;Transportation;Roads;EV charging load simulation;microscopic EV behavior;vehicle-to-grid;charging station fault sensing},
  doi={10.1109/TSG.2025.3560976}}
```
