audformat.errors
================

.. automodule:: audformat.errors


.. rubric:: Exceptions

.. autosummary::
    :toctree:
    :nosignatures:

    BadIdError
    BadKeyError
    BadTypeError
    BadValueError
    TableExistsError
