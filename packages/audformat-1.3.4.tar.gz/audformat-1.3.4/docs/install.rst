Installation
============

To install :mod:`audformat` run:

.. code-block:: bash

    $ pip install audformat

To interactively test it run:

.. code-block:: bash

    $ uvx --with audformat ipython
