---
tags:
  category: system
  context: prompt
---
# .prompt/agent/subagent-start

Context for subagent initialization.

## Prompt

{get}

Review the context above. Note any open commitments and recent learnings relevant to this task.
