"""Pydantic v2 models for review findings and reports."""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, Field, computed_field

from revlo.datasheet.models import DatasheetSpec


class Severity(StrEnum):
    error = "error"
    warning = "warning"
    suggestion = "suggestion"


class FindingCategory(StrEnum):
    decoupling = "decoupling"
    pull_up = "pull_up"
    power = "power"
    signal_integrity = "signal_integrity"
    grounding = "grounding"
    esd_protection = "esd_protection"
    clock = "clock"
    reset = "reset"
    unused_pin = "unused_pin"
    component_value = "component_value"
    connectivity = "connectivity"
    thermal = "thermal"
    library_hygiene = "library_hygiene"
    bom = "bom"


class FindingSourceType(StrEnum):
    llm = "llm"
    deterministic = "deterministic"
    custom_rule = "custom_rule"


class FindingBaselineStatus(StrEnum):
    unclassified = "unclassified"
    new = "new"
    existing = "existing"
    waived = "waived"


class FindingChangeStatus(StrEnum):
    not_compared = "not_compared"
    unchanged_context = "unchanged_context"
    change_driven = "change_driven"


class DatasheetEvidence(BaseModel):
    mpn: str = ""
    manufacturer: str = ""
    pdf_path: str = ""
    relevant_pages: list[int] = Field(default_factory=list)


class FindingEvidence(BaseModel):
    refs: list[str] = Field(default_factory=list)
    nets: list[str] = Field(default_factory=list)
    sheet_paths: list[str] = Field(default_factory=list)
    datasheets: list[DatasheetEvidence] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)


class Finding(BaseModel):
    severity: Severity
    category: FindingCategory
    component_ref: str
    title: str
    description: str
    recommendation: str
    confidence: float = Field(ge=0.0, le=1.0)
    suggested_fix: str = ""
    source_type: FindingSourceType = FindingSourceType.llm
    baseline_status: FindingBaselineStatus = FindingBaselineStatus.unclassified
    change_status: FindingChangeStatus = FindingChangeStatus.not_compared
    evidence: FindingEvidence = Field(default_factory=FindingEvidence)


class SeverityStats(BaseModel):
    error: int = 0
    warning: int = 0
    suggestion: int = 0
    total: int = 0


class ReviewReport(BaseModel):
    findings: list[Finding] = Field(default_factory=list)
    summary: str = ""
    schematic_title: str = ""
    review_date: str = ""
    datasheet_specs: dict[str, DatasheetSpec] = Field(default_factory=dict)
    llm_provider: str = ""
    llm_model: str = ""
    datasheet_mode: str = ""
    review_profile: str = ""

    @computed_field  # type: ignore[prop-decorator]
    @property
    def stats(self) -> SeverityStats:
        counts = SeverityStats(
            error=sum(1 for f in self.findings if f.severity == Severity.error),
            warning=sum(1 for f in self.findings if f.severity == Severity.warning),
            suggestion=sum(
                1 for f in self.findings if f.severity == Severity.suggestion
            ),
            total=len(self.findings),
        )
        return counts
