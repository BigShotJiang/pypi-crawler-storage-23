"""Google Slides MCP Tools Package for FastMCP2."""

from .slides_tools import setup_slides_tools

__all__ = ["setup_slides_tools"]
