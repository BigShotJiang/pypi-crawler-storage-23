"""Authentication module for Google OAuth and session management."""
