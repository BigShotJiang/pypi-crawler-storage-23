# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Build/Lint/Test Commands

```bash
# Install dependencies
uv pip install -e .           # Production install
uv pip install -e ".[dev]"    # With dev dependencies

# Install as CLI tool
uv tool install .
screenshooter --version

# Format and lint
uv run ruff format src/
uv run ruff check src/

# Tests in this repo are exploratory/scaffolding only
# Do not run pytest unless explicitly requested by the user
# uv run pytest tests/
```

## Agent Validation Policy

- Ruff linting is explicitly allowed at the end of each coding pass.
- Preferred end-of-pass validation: `uv run ruff check src/`.
- Run `uv run ruff format src/` when formatting fixes are needed.
- Manual app testing (interactive/manual workflows) should be done by the user.
- Do not run manual/integration testing flows unless the user explicitly asks.
- Repository tests are exploratory and not part of production validation.
- Do not run `pytest` by default; use Ruff linting as the primary validation.
- Only run tests when the user explicitly asks.

## Code Style

- Python 3.10 - 3.14, use `uv` for package management
- Double quotes, 100 char line length, 4-space indentation
- Type hints required for all function parameters and return values
- Import order: stdlib → third-party → local
- Naming: Classes=PascalCase, functions=snake_case, constants=UPPERCASE_WITH_UNDERSCORES
- Google style docstrings
- Use specific exceptions in try/except, use logging module for errors
- Rich console formatting for UI; input prompts on new line prefixed with `>`

## Architecture

**Entry Point:** `src/screenshooter/main.py`

**Modules** (`src/screenshooter/modules/`):

- `clients/` - Client management, data models, CLI
- `screenshot/` - Screenshot capture, session management, timer
- `reports/` - PDF report generation and email delivery
- `database/` - SQLite storage, migrations, operations layer
- `s3/` - S3/R2 cloud storage integration
- `settings/` - Application settings models and manager

Each module has `__init__.py` and may include `main.py` or `cli.py` for CLI entry points.

## Interactive Screenshot Notes

- Snippet capture command is `w` in screenshot sessions.
- Snippet flow is countdown first, then region selection, then capture via `mss` region grab.
- Qt selector implementation is in `src/screenshooter/modules/screenshot/qt_region_selector.py`.
- On macOS, Qt selector runs in a subprocess to isolate Qt lifecycle from terminal input handling.
- On Windows, Qt selector runs in-process and remaps Qt coordinates into `mss` coordinates to avoid DPI
  scaling mismatch in snippet captures.
- `PySide6-Essentials` is optional and provided through the `snippet-gui` extra in `pyproject.toml`.
- If `snippet-gui` is not installed, snippet capture is disabled and should show install guidance.
- Linux Qt snippet drag-selection has not been fully tested yet.
- Terminal raw-mode safety is centralized in `src/screenshooter/modules/screenshot/utils.py`.
- If editing raw key handling, always restore cooked mode in `finally` and use
  `ensure_terminal_cooked_mode()` before blocking input/menu prompts.

## Database Guidelines

SQLite database at `~/.config/screenshooter/screenshooter.db` stores clients, projects, sessions, screenshots, and notes.

- **Always use `DatabaseOperations`** for CRUD - never raw SQL directly
- **Dual logging**: File-based logs remain authoritative; DB writes are supplementary
- **Note types**: Use `DatabaseNoteType` enum (NOTE, CAPTION, SESSION_START, SESSION_END) - no separate caption table
- **Schema changes**: Use versioned migrations in `versions/` directory, not direct DB modifications
- Migration files: `XXX_descriptive_name.sql` with transaction wrapping and rollback sections

## User Data Structure

Screenshots and client data stored at `~/WorkMaster_Screenshooter/`:

```
~/WorkMaster_Screenshooter/
└── CLIENT_NAME/
    ├── client.json
    └── PROJECT_NAME/
        ├── project.json
        ├── PROJECT_NAME_log.txt
        ├── reports/
        └── sessions/YYYY-MM-DD_HH-MM-SS/
            ├── session.json
            ├── session.log
            └── screenshots/
                └── PROJECT_NAME_YYYY-MM-DD_HH-MM-SS_*.jpg
```

## Cursor Rules Reference

Additional module-specific guidelines exist in `.cursor/rules/`:

- `database-module.mdc` - SQLite integration, schema, operations layer
- `database-migrations.mdc` - Versioned migration system
- `clients-module.mdc`, `reports-module.mdc`, `s3-module.mdc`, `screenshot-module.mdc`, `settings-module.mdc`
