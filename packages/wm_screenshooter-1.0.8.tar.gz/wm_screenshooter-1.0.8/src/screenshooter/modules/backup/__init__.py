#!/usr/bin/env python3
"""Backup module exports for ScreenShooter Mac."""

from .main import perform_backup

__all__ = ["perform_backup"]
