"""Reports module for ScreenShooter Mac.

This module handles the generation of PDF reports from screenshot sessions.
"""

# Re-export everything from the pdf module for backward compatibility
from screenshooter.modules.reports.pdf import (
    ClientInfo,
    MultiSessionReport,
    ReportGenerator,
    SessionLog,
    generate_multi_session_pdf,
    generate_single_session_pdf,
)
from screenshooter.modules.reports.report import main as report_main
from screenshooter.modules.reports.report_cli import (
    interactive_report_generation,
)
from screenshooter.modules.reports.report_cli import (
    main as cli_main,
)
from screenshooter.modules.reports.report_email import send_email

# Define what gets imported with 'from screenshooter.modules.reports import *'
__all__ = [
    "ClientInfo",
    "MultiSessionReport",
    "ReportGenerator",
    "SessionLog",
    "cli_main",
    "generate_multi_session_pdf",
    "generate_single_session_pdf",
    "interactive_report_generation",
    "main",
    "send_email",
]


# Define a function that dynamically imports and runs main to avoid circular imports
def main():
    """Main entry point, delegates to report.py's main function."""
    return report_main()
