#!/usr/bin/env python3
"""Report generation module for ScreenShooter Mac."""

import sys

# Import from the refactored PDF module
from screenshooter.modules.reports.report_cli import (
    main as cli_main,
)


def main():
    """Main entry point for the report module.

    This simply passes control to the CLI main function in report_cli.py.
    """
    # Just delegate to the CLI implementation
    return cli_main()


if __name__ == "__main__":
    sys.exit(main())
