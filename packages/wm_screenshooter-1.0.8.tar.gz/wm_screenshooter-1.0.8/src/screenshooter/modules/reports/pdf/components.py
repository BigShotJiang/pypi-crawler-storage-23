#!/usr/bin/env python3
"""PDF component blocks for consistent report design."""

from reportlab.lib.units import inch
from reportlab.platypus import Paragraph, Spacer


def add_report_title(story: list, title: str, styles: dict) -> None:
    """Add the main report title to the PDF story."""
    story.append(Paragraph(title, styles["Heading1Bold"]))
    story.append(Spacer(1, 0.2 * inch))


def add_section_header(story: list, header: str, styles: dict) -> None:
    """Add a section header to the PDF story."""
    story.append(Paragraph(header, styles["Heading2Bold"]))
    story.append(Spacer(1, 0.2 * inch))


def add_subsection_header(story: list, header: str, styles: dict) -> None:
    """Add a subsection header to the PDF story."""
    story.append(Paragraph(header, styles["Heading3Bold"]))
    story.append(Spacer(1, 0.1 * inch))
