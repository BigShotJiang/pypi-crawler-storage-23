#!/usr/bin/env python3
"""Database migration tracking models for ScreenShooter Mac.

Defines models for tracking applied migrations and migration metadata.
"""

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class Migration(BaseModel):
    """Represents a migration file."""

    # Make migration immutable once loaded
    model_config = ConfigDict(frozen=True)

    version: int = Field(..., description="Migration version number")
    filename: str = Field(..., description="Migration filename")
    sql_content: str = Field(..., description="SQL migration content")
    checksum: str = Field(..., description="SHA256 checksum of migration content")
    description: str | None = Field(None, description="Migration description from header")


class AppliedMigration(BaseModel):
    """Represents a migration that has been applied to the database."""

    model_config = ConfigDict(from_attributes=True)

    version: int = Field(..., description="Migration version number")
    filename: str = Field(..., description="Migration filename")
    applied_at: datetime = Field(..., description="When migration was applied")
    checksum: str = Field(..., description="Checksum of applied migration")


class MigrationStatus(BaseModel):
    """Status of migration system."""

    current_version: int | None = Field(None, description="Current database version")
    latest_version: int | None = Field(None, description="Latest available migration version")
    pending_migrations: list[Migration] = Field(
        default_factory=list, description="Pending migrations"
    )
    applied_migrations: list[AppliedMigration] = Field(
        default_factory=list, description="Applied migrations"
    )

    @property
    def is_up_to_date(self) -> bool:
        """Check if database is up to date."""
        return len(self.pending_migrations) == 0
