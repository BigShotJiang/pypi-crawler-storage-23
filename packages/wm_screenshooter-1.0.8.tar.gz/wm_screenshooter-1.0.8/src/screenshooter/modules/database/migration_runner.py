#!/usr/bin/env python3
"""Database migration runner for ScreenShooter Mac.

Handles execution of database schema migrations with version tracking,
rollback support, and integrity verification.
"""

import hashlib
import re
from datetime import datetime
from pathlib import Path

from rich.console import Console

from screenshooter.modules.settings.logging_utils import get_database_log_file

from .database import DatabaseManager
from .migration_models import AppliedMigration, Migration, MigrationStatus

console = Console()


class MigrationRunner:
    """Executes and tracks database schema migrations."""

    def __init__(self, db_manager: DatabaseManager, quiet: bool = False):
        """Initialize migration runner.

        Args:
            db_manager: Database manager instance
        """
        self.db_manager = db_manager
        self.migrations_dir = Path(__file__).parent / "versions"
        self.migrations_dir.mkdir(exist_ok=True)
        self.quiet = quiet

        # Set up dual logging (file + console)
        self.database_log_file = get_database_log_file()

    def write_to_log(self, message: str) -> None:
        """Write a message to the database log file."""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        entry = f"[{timestamp}] {message}"

        with open(self.database_log_file, "a") as f:
            f.write(f"{entry}\n")

    def log_entry(self, message: str, console_message: str | None = None) -> None:
        """Add a log entry to file and optionally display to console."""
        self.write_to_log(message)

        if self.quiet:
            return

        if console_message:
            console.print(console_message)
        else:
            console.print(message)

    def _ensure_migration_table(self) -> None:
        """Create schema_migrations table if it doesn't exist."""
        conn = self.db_manager.get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS schema_migrations (
                version INTEGER PRIMARY KEY,
                filename TEXT NOT NULL UNIQUE,
                applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                checksum TEXT NOT NULL
            )
        """)

        conn.commit()

    def _calculate_checksum(self, content: str) -> str:
        """Calculate SHA256 checksum of migration content.

        Args:
            content: Migration SQL content

        Returns:
            SHA256 hex digest
        """
        return hashlib.sha256(content.encode("utf-8")).hexdigest()

    def _parse_migration_filename(self, filename: str) -> tuple[int, str] | None:
        """Parse migration filename to extract version and description.

        Args:
            filename: Migration filename

        Returns:
            Tuple of (version, description) or None if invalid format
        """
        match = re.match(r"^(\d{3})_(.+)\.sql$", filename)
        if match:
            version_str, description = match.groups()
            return int(version_str), description
        return None

    def _extract_description(self, content: str) -> str | None:
        """Extract description from migration file header.

        Args:
            content: Migration SQL content

        Returns:
            Description from header or None
        """
        # Look for description in header comments
        for raw_line in content.split("\n")[:10]:  # Check first 10 lines
            line = raw_line.strip()
            if line.startswith("-- Description:"):
                return line[14:].strip()
        return None

    def load_migrations(self) -> list[Migration]:
        """Load all migration files from versions directory.

        Returns:
            List of migrations sorted by version
        """
        migrations = []

        for file_path in self.migrations_dir.glob("*.sql"):
            parsed = self._parse_migration_filename(file_path.name)
            if not parsed:
                self.log_entry(
                    f"Skipping invalid migration filename: {file_path.name}",
                    f"[yellow]Skipping invalid migration filename: {file_path.name}[/yellow]",
                )
                continue

            version, description = parsed
            content = file_path.read_text(encoding="utf-8")
            checksum = self._calculate_checksum(content)

            # Extract description from file header if available
            file_description = self._extract_description(content)
            if file_description:
                description = file_description

            migration = Migration(
                version=version,
                filename=file_path.name,
                sql_content=content,
                checksum=checksum,
                description=description,
            )
            migrations.append(migration)

        return sorted(migrations, key=lambda m: m.version)

    def get_applied_migrations(self) -> list[AppliedMigration]:
        """Get list of applied migrations from database.

        Returns:
            List of applied migrations sorted by version
        """
        self._ensure_migration_table()

        conn = self.db_manager.get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT version, filename, applied_at, checksum
            FROM schema_migrations
            ORDER BY version
        """)

        applied = []
        for row in cursor.fetchall():
            applied.append(
                AppliedMigration(
                    version=row["version"],
                    filename=row["filename"],
                    applied_at=row["applied_at"],
                    checksum=row["checksum"],
                )
            )

        return applied

    def get_pending_migrations(self) -> list[Migration]:
        """Get list of pending migrations.

        Returns:
            List of migrations that haven't been applied yet
        """
        all_migrations = self.load_migrations()
        applied_versions = {m.version for m in self.get_applied_migrations()}

        return [m for m in all_migrations if m.version not in applied_versions]

    def get_migration_status(self) -> MigrationStatus:
        """Get current migration status.

        Returns:
            Migration status object
        """
        applied = self.get_applied_migrations()
        pending = self.get_pending_migrations()

        current_version = applied[-1].version if applied else None
        latest_version = max([m.version for m in self.load_migrations()], default=None)

        return MigrationStatus(
            current_version=current_version,
            latest_version=latest_version,
            pending_migrations=pending,
            applied_migrations=applied,
        )

    def apply_migration(self, migration: Migration) -> None:
        """Apply a single migration.

        Args:
            migration: Migration to apply

        Raises:
            RuntimeError: If migration fails to apply
        """
        self.log_entry(f"Applying migration {migration.version}: {migration.filename}")

        conn = self.db_manager.get_connection()

        try:
            # Execute migration in transaction
            cursor = conn.cursor()
            cursor.execute("BEGIN TRANSACTION")

            # Execute migration SQL
            cursor.executescript(migration.sql_content)

            # Record migration
            cursor.execute(
                """
                INSERT INTO schema_migrations (version, filename, checksum)
                VALUES (?, ?, ?)
            """,
                (migration.version, migration.filename, migration.checksum),
            )

            conn.commit()
            self.log_entry(
                f"Successfully applied migration {migration.version}",
                f"[green]Successfully applied migration {migration.version}[/green]",
            )

        except Exception as e:
            conn.rollback()
            self.log_entry(
                f"Failed to apply migration {migration.version}: {e}",
                f"[red]Failed to apply migration {migration.version}: {e}[/red]",
            )
            raise RuntimeError(f"Migration {migration.version} failed: {e}") from e

    def rollback_migration(self, version: int) -> None:
        """Rollback a migration using its rollback statements.

        Args:
            version: Migration version to rollback

        Raises:
            RuntimeError: If rollback fails or migration not found
        """
        # Find migration file
        migrations = self.load_migrations()
        migration = next((m for m in migrations if m.version == version), None)

        if not migration:
            raise RuntimeError(f"Migration {version} not found")

        # Extract rollback statements from migration file
        rollback_sql = self._extract_rollback_statements(migration.sql_content)

        if not rollback_sql:
            raise RuntimeError(f"No rollback statements found for migration {version}")

        self.log_entry(f"Rolling back migration {version}: {migration.filename}")

        conn = self.db_manager.get_connection()

        try:
            cursor = conn.cursor()
            cursor.execute("BEGIN TRANSACTION")

            # Execute rollback statements
            cursor.executescript(rollback_sql)

            # Remove migration record
            cursor.execute("DELETE FROM schema_migrations WHERE version = ?", (version,))

            conn.commit()
            self.log_entry(
                f"Successfully rolled back migration {version}",
                f"[green]Successfully rolled back migration {version}[/green]",
            )

        except Exception as e:
            conn.rollback()
            self.log_entry(
                f"Failed to rollback migration {version}: {e}",
                f"[red]Failed to rollback migration {version}: {e}[/red]",
            )
            raise RuntimeError(f"Rollback of migration {version} failed: {e}") from e

    def _extract_rollback_statements(self, content: str) -> str | None:
        """Extract rollback statements from migration content.

        Args:
            content: Migration SQL content

        Returns:
            Rollback SQL or None if not found
        """
        # Look for rollback section
        rollback_match = re.search(r"-- Rollback:\s*(.*?)(?=\n--|\n\n|\Z)", content, re.DOTALL)
        if rollback_match:
            return rollback_match.group(1).strip()
        return None

    def migrate_to_latest(self) -> None:
        """Apply all pending migrations."""
        self.log_entry(
            "Starting migration check", "[bold]Checking for pending migrations...[/bold]"
        )

        # Get applied migrations from database
        self.log_entry("Querying database for applied migrations")
        applied = self.get_applied_migrations()
        self.log_entry(f"Found {len(applied)} applied migrations in database")

        # Get all available migrations
        self.log_entry("Scanning migrations directory")
        all_migrations = self.load_migrations()
        self.log_entry(f"Found {len(all_migrations)} migration files")

        # Get pending migrations
        self.log_entry("Comparing applied vs available migrations")
        pending = self.get_pending_migrations()
        self.log_entry(f"Found {len(pending)} pending migrations")

        if not pending:
            latest_version = max([m.version for m in all_migrations], default=None)
            current_version = applied[-1].version if applied else None
            self.log_entry(
                f"Migration check complete - Database is up to date "
                f"(current: {current_version}, latest: {latest_version})",
                f"[green]Database is up to date (current: {current_version}, "
                f"latest: {latest_version})[/green]",
            )
            return

        self.log_entry(
            f"Applying {len(pending)} pending migrations",
            f"[bold]Applying {len(pending)} pending migrations[/bold]",
        )

        for migration in pending:
            self.apply_migration(migration)

        self.log_entry(
            "All migrations applied successfully",
            "[green]All migrations applied successfully[/green]",
        )

    def migrate_to_version(self, target_version: int) -> None:
        """Migrate to specific version.

        Args:
            target_version: Target migration version
        """
        self.log_entry(
            f"Starting migration to version {target_version}",
            f"[bold]Migrating to version {target_version}...[/bold]",
        )

        # Get applied migrations from database
        self.log_entry("Querying database for applied migrations")
        applied = self.get_applied_migrations()
        applied_versions = {m.version for m in applied}
        self.log_entry(f"Found {len(applied)} applied migrations in database")

        if target_version in applied_versions:
            self.log_entry(
                f"Database already at version {target_version}",
                f"[green]Database already at version {target_version}[/green]",
            )
            return

        # Get all available migrations
        self.log_entry("Scanning migrations directory")
        all_migrations = self.load_migrations()
        self.log_entry(f"Found {len(all_migrations)} migration files")

        # Get pending migrations and filter for target version
        self.log_entry("Determining migrations needed for target version")
        pending = self.get_pending_migrations()
        target_migrations = [m for m in pending if m.version <= target_version]
        self.log_entry(
            f"Found {len(target_migrations)} migrations to apply for version {target_version}"
        )

        if not target_migrations:
            self.log_entry(
                f"No migrations to apply for version {target_version}",
                f"[yellow]No migrations to apply for version {target_version}[/yellow]",
            )
            return

        self.log_entry(
            f"Migrating to version {target_version} with {len(target_migrations)} migrations",
            f"[bold]Migrating to version {target_version}[/bold]",
        )

        for migration in target_migrations:
            self.apply_migration(migration)

        self.log_entry(
            f"Successfully migrated to version {target_version}",
            f"[green]Successfully migrated to version {target_version}[/green]",
        )
