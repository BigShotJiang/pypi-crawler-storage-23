#!/usr/bin/env python3
"""Qt overlay region selector for snippet screenshots."""

from __future__ import annotations

import importlib
import json
import os
import platform
import subprocess
import sys
from typing import Any, Literal

import mss

SelectionStatus = Literal["selected", "cancelled", "unavailable", "error"]

MIN_SELECTION_SIZE = 5
REGION_PARTS = 4
SELECTOR_TIMEOUT_SECONDS = 300
WINDOWS_SCALE_EPSILON = 0.01


def _apply_windows_qt_logging_suppression() -> None:
    """Suppress noisy, non-fatal Qt DPI warning on Windows."""
    if platform.system() != "Windows":
        return

    target_rule = "qt.qpa.window.warning=false"
    existing_rules = os.environ.get("QT_LOGGING_RULES", "")
    parts = [part.strip() for part in existing_rules.split(";") if part.strip()]
    if any(part.startswith("qt.qpa.window.warning=") for part in parts):
        return

    parts.append(target_rule)
    os.environ["QT_LOGGING_RULES"] = ";".join(parts)


def _region_to_mss_space_windows(
    *,
    region: tuple[int, int, int, int],
    qt_virtual_geometry: Any,
) -> tuple[int, int, int, int]:
    """Convert a Qt-selected region into mss virtual-screen coordinates on Windows.

    Qt can report selection coordinates in a different DPI space than mss on
    Windows. Mapping through each virtual desktop bounding box keeps snippet
    capture aligned with what the user dragged.
    """
    mapped_region = region
    try:
        with mss.mss() as sct:
            mss_virtual = sct.monitors[0]
    except Exception:
        return mapped_region

    qt_left = int(qt_virtual_geometry.x())
    qt_top = int(qt_virtual_geometry.y())
    qt_width = int(qt_virtual_geometry.width())
    qt_height = int(qt_virtual_geometry.height())
    mss_left = int(mss_virtual.get("left", 0))
    mss_top = int(mss_virtual.get("top", 0))
    mss_width = int(mss_virtual.get("width", 0))
    mss_height = int(mss_virtual.get("height", 0))

    if qt_width > 0 and qt_height > 0 and mss_width > 0 and mss_height > 0:
        src_left, src_top, src_width, src_height = region
        scale_x = mss_width / qt_width
        scale_y = mss_height / qt_height

        if (
            abs(scale_x - 1.0) >= WINDOWS_SCALE_EPSILON
            or abs(scale_y - 1.0) >= WINDOWS_SCALE_EPSILON
        ):
            rel_left = src_left - qt_left
            rel_top = src_top - qt_top

            dst_left = mss_left + round(rel_left * scale_x)
            dst_top = mss_top + round(rel_top * scale_y)
            dst_width = max(1, round(src_width * scale_x))
            dst_height = max(1, round(src_height * scale_y))

            max_left = mss_left + mss_width
            max_top = mss_top + mss_height
            if dst_left < mss_left:
                dst_width -= mss_left - dst_left
                dst_left = mss_left
            if dst_top < mss_top:
                dst_height -= mss_top - dst_top
                dst_top = mss_top

            dst_width = min(dst_width, max_left - dst_left)
            dst_height = min(dst_height, max_top - dst_top)
            if dst_width > 0 and dst_height > 0:
                mapped_region = (dst_left, dst_top, dst_width, dst_height)

    return mapped_region


def _select_region_with_qt_in_process() -> tuple[tuple[int, int, int, int] | None, SelectionStatus]:
    """Run selector in the current process."""
    _apply_windows_qt_logging_suppression()
    try:
        qt_core = importlib.import_module("PySide6.QtCore")
        qt_gui = importlib.import_module("PySide6.QtGui")
        qt_widgets = importlib.import_module("PySide6.QtWidgets")
    except Exception:
        return None, "unavailable"

    try:

        class RegionSelectorOverlay(qt_widgets.QDialog):
            """Transparent overlay that captures a mouse-drag region."""

            def __init__(self, geometry: Any) -> None:
                super().__init__()
                self.result_region: tuple[int, int, int, int] | None = None
                self._geometry = geometry
                self._origin_global: Any = None
                self._current_global: Any = None

                self.setModal(True)
                self.setWindowFlags(
                    qt_core.Qt.WindowType.FramelessWindowHint
                    | qt_core.Qt.WindowType.WindowStaysOnTopHint
                    | qt_core.Qt.WindowType.Tool
                )
                self.setAttribute(qt_core.Qt.WidgetAttribute.WA_TranslucentBackground, True)
                self.setCursor(qt_core.Qt.CursorShape.CrossCursor)
                self.setMouseTracking(True)
                self.setGeometry(self._geometry)

            def _event_global_point(self, event: Any) -> Any:
                point = event.globalPosition()
                return qt_core.QPoint(int(point.x()), int(point.y()))

            def _selection_rect_local(self) -> Any:
                if self._origin_global is None or self._current_global is None:
                    return None

                left_global = min(self._origin_global.x(), self._current_global.x())
                top_global = min(self._origin_global.y(), self._current_global.y())
                right_global = max(self._origin_global.x(), self._current_global.x())
                bottom_global = max(self._origin_global.y(), self._current_global.y())

                left = left_global - self._geometry.x()
                top = top_global - self._geometry.y()
                width = right_global - left_global
                height = bottom_global - top_global

                return qt_core.QRect(left, top, width, height)

            def _finalize_selection(self) -> None:
                rect = self._selection_rect_local()
                if rect is None:
                    self.reject()
                    return

                if rect.width() >= MIN_SELECTION_SIZE and rect.height() >= MIN_SELECTION_SIZE:
                    self.result_region = (
                        rect.x() + self._geometry.x(),
                        rect.y() + self._geometry.y(),
                        rect.width(),
                        rect.height(),
                    )
                    self.accept()
                    return
                self.reject()

            def mousePressEvent(self, event: Any) -> None:  # noqa: N802
                if event.button() == qt_core.Qt.MouseButton.LeftButton:
                    point = self._event_global_point(event)
                    self._origin_global = point
                    self._current_global = point
                    self.update()
                elif event.button() == qt_core.Qt.MouseButton.RightButton:
                    self.reject()

            def mouseMoveEvent(self, event: Any) -> None:  # noqa: N802
                if self._origin_global is None:
                    return
                self._current_global = self._event_global_point(event)
                self.update()

            def mouseReleaseEvent(self, event: Any) -> None:  # noqa: N802
                if (
                    event.button() == qt_core.Qt.MouseButton.LeftButton
                    and self._origin_global is not None
                ):
                    self._current_global = self._event_global_point(event)
                    self._finalize_selection()

            def keyPressEvent(self, event: Any) -> None:  # noqa: N802
                if event.key() == qt_core.Qt.Key.Key_Escape:
                    self.reject()

            def paintEvent(self, event: Any) -> None:  # noqa: N802
                _ = event
                painter = qt_gui.QPainter(self)
                painter.setRenderHint(qt_gui.QPainter.RenderHint.Antialiasing)
                painter.fillRect(self.rect(), qt_gui.QColor(0, 0, 0, 100))

                selection = self._selection_rect_local()
                if selection is not None:
                    painter.fillRect(selection, qt_gui.QColor(0, 170, 255, 45))
                    painter.setPen(qt_gui.QPen(qt_gui.QColor(0, 170, 255), 2))
                    painter.drawRect(selection)

                painter.setPen(qt_gui.QColor(255, 255, 255))
                painter.drawText(
                    20,
                    30,
                    "Drag to select snippet area. Press Esc or right-click to cancel.",
                )

        app = qt_widgets.QApplication.instance()
        created_app = app is None
        if app is None:
            app = qt_widgets.QApplication([])
            app.setQuitOnLastWindowClosed(True)

        screen = qt_gui.QGuiApplication.primaryScreen()
        if screen is None:
            return None, "error"

        virtual_geometry = screen.virtualGeometry()
        if virtual_geometry.width() <= 0 or virtual_geometry.height() <= 0:
            return None, "error"

        overlay = RegionSelectorOverlay(virtual_geometry)
        overlay.setWindowModality(qt_core.Qt.WindowModality.ApplicationModal)
        overlay.show()
        app.setActiveWindow(overlay)
        overlay.raise_()
        overlay.activateWindow()
        overlay.setFocus()

        result_code = overlay.exec()
        region = overlay.result_region
        overlay.hide()
        overlay.deleteLater()
        app.processEvents()

        if created_app:
            app.quit()
            app.processEvents()

        if result_code != int(qt_widgets.QDialog.DialogCode.Accepted) or region is None:
            return None, "cancelled"
        if platform.system() == "Windows":
            region = _region_to_mss_space_windows(
                region=region,
                qt_virtual_geometry=virtual_geometry,
            )
        return region, "selected"
    except Exception:
        return None, "error"


def _select_region_with_qt_subprocess() -> tuple[tuple[int, int, int, int] | None, SelectionStatus]:
    """Run selector in a child process (preferred on macOS)."""
    try:
        result = subprocess.run(
            [sys.executable, "-m", "screenshooter.modules.screenshot.qt_region_selector"],
            check=False,
            capture_output=True,
            text=True,
            timeout=SELECTOR_TIMEOUT_SECONDS,
        )
    except Exception:
        return None, "error"

    lines = [line.strip() for line in result.stdout.splitlines() if line.strip()]
    for line in reversed(lines):
        try:
            payload = json.loads(line)
        except json.JSONDecodeError:
            continue

        status = payload.get("status")
        if status not in {"selected", "cancelled", "unavailable", "error"}:
            break

        region = payload.get("region")
        if status == "selected" and isinstance(region, list) and len(region) == REGION_PARTS:
            try:
                left, top, width, height = [int(v) for v in region]
            except (TypeError, ValueError):
                return None, "error"
            return (left, top, width, height), "selected"
        return None, status

    if "PySide6" in (result.stderr or ""):
        return None, "unavailable"
    return None, "error"


def select_region_with_qt() -> tuple[tuple[int, int, int, int] | None, SelectionStatus]:
    """Select snippet region with a Qt overlay.

    On macOS this runs in a child process to isolate Qt app lifecycle from the
    terminal TUI process.
    """
    if platform.system() == "Darwin":
        return _select_region_with_qt_subprocess()
    return _select_region_with_qt_in_process()


def _main() -> int:
    """CLI entrypoint for subprocess selection mode."""
    region, status = _select_region_with_qt_in_process()
    payload: dict[str, Any] = {"status": status, "region": list(region) if region else None}
    sys.stdout.write(f"{json.dumps(payload)}\n")
    sys.stdout.flush()
    return 0


if __name__ == "__main__":
    sys.exit(_main())
