#!/usr/bin/env python3
"""Main entry point for the screenshot module."""

import os
import platform
import shutil
import subprocess
import sys
import time
from collections.abc import Callable
from datetime import datetime
from typing import Any

import click
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.prompt import Prompt

from screenshooter.modules.settings.settings_helper import should_notify_before_scheduled

from .config import ScreenshooterConfig
from .interactive import interactive_project_selection
from .post_session import post_session_report_flow
from .qt_region_selector import select_region_with_qt
from .utils import ensure_terminal_cooked_mode, get_connected_displays, get_key, get_text_input

# Initialize rich console
console = Console()

CONTENT_PREVIEW_LENGTH = 50
RECENT_ACTIONS_LIMIT = 5
PRE_SCREENSHOT_NOTIFY_MIN_SECONDS = 29
PRE_SCREENSHOT_NOTIFY_MAX_SECONDS = 31


def _get_notification_capability() -> tuple[bool, str | None]:
    """Check if desktop notifications are available on this platform.

    Returns:
        Tuple of (can_notify: bool, notifier_path: Optional[str])
    """
    system = platform.system()

    if system == "Darwin":
        # macOS - check for terminal-notifier
        notifier_path = shutil.which("terminal-notifier")
        return bool(notifier_path), notifier_path
    elif system == "Linux":
        # Linux - check for notify-send
        notifier_path = shutil.which("notify-send")
        return bool(notifier_path), notifier_path
    elif system == "Windows":
        # Windows - PowerShell is always available
        return True, "powershell"
    else:
        return False, None


def _send_pre_screenshot_notification(notifier_path: str, title: str, message: str) -> None:
    """Send a pre-screenshot notification cross-platform.

    Args:
        notifier_path: Path to the notification tool or "powershell" for Windows
        title: Notification title
        message: Notification message
    """
    system = platform.system()

    try:
        if system == "Darwin":
            subprocess.run(
                [
                    notifier_path,
                    "-title",
                    title,
                    "-message",
                    message,
                    "-group",
                    "screenshot-warning",
                ],
                check=False,
                capture_output=True,
            )
        elif system == "Linux":
            subprocess.run(
                [notifier_path, title, message],
                check=False,
                capture_output=True,
            )
        elif system == "Windows":
            ps_script = f'''
            Add-Type -AssemblyName System.Windows.Forms
            $notify = New-Object System.Windows.Forms.NotifyIcon
            $notify.Icon = [System.Drawing.SystemIcons]::Information
            $notify.BalloonTipTitle = "{title}"
            $notify.BalloonTipText = "{message}"
            $notify.Visible = $true
            $notify.ShowBalloonTip(5000)
            Start-Sleep -Milliseconds 100
            $notify.Dispose()
            '''
            subprocess.run(
                ["powershell", "-Command", ps_script],
                check=False,
                capture_output=True,
                creationflags=subprocess.CREATE_NO_WINDOW
                if hasattr(subprocess, "CREATE_NO_WINDOW")
                else 0,
            )
    except Exception:
        pass  # Silently fail if notifications don't work


def _open_file_cross_platform(file_path: str) -> bool:
    """Open a file with the system's default application cross-platform.

    Args:
        file_path: Path to the file to open

    Returns:
        True if successful, False otherwise
    """
    system = platform.system()

    try:
        if system == "Darwin":
            subprocess.run(["open", file_path], check=False)
        elif system == "Linux":
            subprocess.run(["xdg-open", file_path], check=False)
        elif system == "Windows":
            # On Windows, open file with default application
            subprocess.Popen(["start", "", file_path], shell=True)
        else:
            return False
        return True
    except Exception:
        return False


def _open_file_with_app(file_path: str, app_name: str) -> bool:
    """Open a file with a specific application (cross-platform).

    Args:
        file_path: Path to the file to open
        app_name: Application name (e.g., "TextEdit" on macOS)

    Returns:
        True if successful, False otherwise
    """
    system = platform.system()

    try:
        if system == "Darwin":
            subprocess.run(["open", "-a", app_name, file_path], check=False)
        elif system == "Linux":
            # On Linux, just use the default text editor
            editor = os.environ.get("EDITOR", "xdg-open")
            subprocess.run([editor, file_path], check=False)
        elif system == "Windows":
            # On Windows, open file with default application
            subprocess.Popen(["start", "", file_path], shell=True)
        else:
            return False
        return True
    except Exception:
        return False


def _get_db_session_context(config: ScreenshooterConfig) -> tuple[Any, Any] | None:
    """Return database operations and session ID if DB logging is available."""
    if (
        hasattr(config, "db_logger")
        and config.db_logger
        and config.db_logger.is_available()
        and config.db_logger.current_session_id
    ):
        return config.db_logger.db_operations, config.db_logger.current_session_id
    return None


def _preview_content(content: str) -> str:
    """Return a shortened preview for note content."""
    if len(content) > CONTENT_PREVIEW_LENGTH:
        return content[:CONTENT_PREVIEW_LENGTH] + "..."
    return content


def _log_archive_action(
    config: ScreenshooterConfig,
    *,
    item_type: str,
    action: str,
    item: Any,
) -> None:
    """Log archive/unarchive action for screenshot or note."""
    prefix = "ARCHIVED" if action == "archived" else "UNARCHIVED"
    if item_type == "screenshot":
        config.log_entry(
            f"{prefix}: Screenshot (set #{item.set_id})",
            terminal_message=f"{action.title()} screenshot (set #{item.set_id}).",
        )
        return

    content_preview = _preview_content(item.content)
    config.log_entry(
        f"{prefix}: Note: {content_preview}",
        terminal_message=f"{action.title()} note: {content_preview}",
    )


def _archive_last_session_item(config: ScreenshooterConfig) -> None:
    """Archive the most recent screenshot or note for the current session."""
    try:
        context = _get_db_session_context(config)
        if not context:
            console.print("Database logging is not available. Cannot archive items.")
            return

        db_ops, session_id = context
        screenshots = db_ops.list_screenshots(session_id, include_archived=True)
        notes = db_ops.list_notes(session_id, include_archived=True)

        latest_screenshot = screenshots[-1] if screenshots else None
        latest_note = notes[-1] if notes else None
        if not latest_screenshot and not latest_note:
            console.print("No screenshots or notes found in this session.")
            return

        if latest_screenshot and latest_note:
            is_screenshot_latest = latest_screenshot.timestamp > latest_note.timestamp
            latest_item = latest_screenshot if is_screenshot_latest else latest_note
            latest_type = "screenshot" if is_screenshot_latest else "note"
        elif latest_screenshot:
            latest_item = latest_screenshot
            latest_type = "screenshot"
        else:
            latest_item = latest_note
            latest_type = "note"
        if latest_item is None:
            return

        if latest_type == "screenshot":
            success = db_ops.archive_screenshot(latest_item.id)
            if not success:
                console.print("Failed to archive screenshot.")
                return
            config.log_entry(
                f"ARCHIVED: Screenshot (last, set #{latest_item.set_id})",
                terminal_message=f"Archived last screenshot (set #{latest_item.set_id}).",
            )
            return

        success = db_ops.archive_note(latest_item.id)
        if not success:
            console.print("Failed to archive note.")
            return
        content_preview = _preview_content(latest_item.content)
        config.log_entry(
            f"ARCHIVED: Note: {content_preview}",
            terminal_message=f"Archived last note: {content_preview}",
        )
    except Exception as e:
        console.print(f"Error archiving item: {e}")


def _manage_session_items(config: ScreenshooterConfig) -> None:
    """Show recent items and toggle archive status for a selected item."""
    try:
        context = _get_db_session_context(config)
        if not context:
            console.print("Database logging is not available. Cannot manage items.")
            return

        db_ops, session_id = context
        combined_items = _get_recent_session_items(db_ops, session_id)
        if not combined_items:
            console.print("No screenshots or notes found in this session.")
            return

        _print_recent_session_items(combined_items)
        item_idx = _prompt_session_item_index(len(combined_items))
        if item_idx is None:
            return

        item_type, item_id, item = combined_items[item_idx]
        action, success = _toggle_archive_item(db_ops, item_type, item, item_id)
        if not success:
            console.print(f"Failed to {action} item.")
            return
        _log_archive_action(config, item_type=item_type, action=action, item=item)
    except Exception as e:
        console.print(f"Error managing items: {e}")


def _get_recent_session_items(db_ops: Any, session_id: Any) -> list[tuple[str, Any, Any]]:
    """Return recent screenshot/note items for a session."""
    screenshots = db_ops.list_screenshots(session_id, include_archived=True)
    notes = db_ops.list_notes(session_id, include_archived=True)
    combined_items: list[tuple[str, Any, Any]] = [
        ("screenshot", screenshot.id, screenshot) for screenshot in screenshots
    ]
    combined_items.extend(("note", note.id, note) for note in notes)
    combined_items.sort(key=lambda x: x[2].timestamp)
    if len(combined_items) > RECENT_ACTIONS_LIMIT:
        return combined_items[-RECENT_ACTIONS_LIMIT:]
    return combined_items


def _print_recent_session_items(combined_items: list[tuple[str, Any, Any]]) -> None:
    """Render recent session items to the terminal."""
    console.print("\n[bold]Session Items:[/bold]")
    for idx, (item_type, _item_id, item) in enumerate(combined_items, 1):
        status = "[dim](archived)[/dim]" if item.archived_at else ""
        if item_type == "screenshot":
            console.print(f"{idx}. [Screenshot] Set #{item.set_id} {status}")
            continue
        label = (
            "[Caption]"
            if hasattr(item, "note_type") and str(item.note_type).lower() == "caption"
            else "[Note]"
        )
        console.print(f"{idx}. {label} {_preview_content(item.content)} {status}")


def _prompt_session_item_index(total_items: int) -> int | None:
    """Prompt user for an item index to archive/unarchive."""
    console.print("\nSelect item to archive/unarchive (or 'b' to go back):")
    choice = Prompt.ask("Enter item number", default="b")
    if choice.lower() == "b":
        console.print("Cancelled.")
        return None
    if not choice.isdigit():
        console.print("Invalid input.")
        return None
    item_idx = int(choice) - 1
    if not 0 <= item_idx < total_items:
        console.print("Invalid selection.")
        return None
    return item_idx


def _toggle_archive_item(
    db_ops: Any,
    item_type: str,
    item: Any,
    item_id: Any,
) -> tuple[str, bool]:
    """Toggle archive status for selected item."""
    if item.archived_at:
        success = (
            db_ops.unarchive_screenshot(item_id)
            if item_type == "screenshot"
            else db_ops.unarchive_note(item_id)
        )
        return "unarchived", success
    success = (
        db_ops.archive_screenshot(item_id)
        if item_type == "screenshot"
        else db_ops.archive_note(item_id)
    )
    return "archived", success


def _print_manual_status(config: ScreenshooterConfig) -> None:
    """Print manual-mode status line."""
    console.print(
        f"\n[green]Status: Manual mode | Display: {config.mode} | Set: #{config.set_id}[/green]"
    )


def _print_timer_status(config: ScreenshooterConfig, next_time: float) -> None:
    """Print timer-mode status line with next capture time."""
    console.print(
        f"\n[green]Status: Timer mode | Display: {config.mode} | Set: #{config.set_id} | Next: "
        f"{datetime.fromtimestamp(next_time).strftime('%H:%M:%S')}[/green]"
    )


def _handle_note_command(config: ScreenshooterConfig) -> None:
    """Prompt and log a note entry."""
    note = get_text_input("Enter your note: ")
    if note:
        config.log_entry(f"NOTE: {note}", terminal_message="Note added to log.")


def _handle_caption_command(config: ScreenshooterConfig) -> None:
    """Prompt and log a caption for the latest screenshot set."""
    if config.set_id == 0:
        console.print("No screenshot sets have been taken yet.")
        return
    caption = get_text_input(f"Enter caption for screenshot set #{config.set_id}: ")
    if caption:
        config.log_entry(
            f"CAPTION for screenshot set #{config.set_id}: {caption}",
            terminal_message="Caption added to log.",
        )


def _prompt_snippet_region(config: ScreenshooterConfig) -> tuple[int, int, int, int] | None:
    """Prompt for snippet region, preferring Qt drag selection when available."""
    linux_warned = getattr(config, "snippet_linux_experimental_warned", False)
    if platform.system() == "Linux" and not linux_warned:
        console.print(
            "[yellow]Linux snippet drag-selection is experimental and "
            "not fully tested yet.[/yellow]"
        )
        config.snippet_linux_experimental_warned = True

    region, status = select_region_with_qt()
    if status == "selected":
        return region

    if status == "cancelled":
        console.print("Snippet capture cancelled.")
        return None

    unavailable_warned = getattr(config, "snippet_gui_unavailable_warned", False)
    error_warned = getattr(config, "snippet_gui_error_warned", False)

    if status == "unavailable" and not unavailable_warned:
        console.print(
            "[yellow]Snippet tool disabled. Install GUI support with: "
            "uv sync --extra snippet-gui (source) or pip install "
            "\"wm-screenshooter[snippet-gui]\".[/yellow]"
        )
        config.snippet_gui_unavailable_warned = True
    elif status == "error" and not error_warned:
        console.print(
            "[yellow]Snippet tool disabled. Install GUI support with: "
            "uv sync --extra snippet-gui (source) or pip install "
            "\"wm-screenshooter[snippet-gui]\".[/yellow]"
        )
        config.snippet_gui_error_warned = True

    return None


def _handle_snippet_command(config: ScreenshooterConfig) -> bool:
    """Capture a one-off snippet region screenshot."""
    if not config.countdown_for_screenshot(
        config.countdown_seconds,
        "Snippet selection",
        start_message="Preparing snippet selection...",
        show_minimize_hint=False,
        cancel_message="Snippet capture cancelled.",
    ):
        return False

    region = _prompt_snippet_region(config)
    if region is None:
        return False

    left, top, width, height = region
    return config.capture_snippet(left, top, width, height)


def _handle_open_screenshot_command(config: ScreenshooterConfig) -> None:
    """Open the last screenshot with the platform default app."""
    if config.last_screenshot and os.path.exists(config.last_screenshot):
        console.print(f"Opening last screenshot: {config.last_screenshot}")
        if not _open_file_cross_platform(config.last_screenshot):
            console.print("[yellow]Could not open screenshot.[/yellow]")
        return
    console.print("No screenshot available to open.")


def _handle_open_session_log_command(config: ScreenshooterConfig) -> None:
    """Open session log in TextEdit."""
    try:
        if config.session_log_file and config.session_log_file.exists():
            console.print(f"Opening session log: {config.session_log_file}")
            if not _open_file_with_app(str(config.session_log_file), "TextEdit"):
                console.print("[yellow]Could not open session log.[/yellow]")
            return
        console.print("Session log file not found.")
    except Exception as e:
        console.print(f"Error opening session log: {e}")


def _handle_time_info_command(config: ScreenshooterConfig) -> None:
    """Show session/day/project time summaries."""
    session_str, today_str, project_str = config.get_time_info()
    console.print(f"Time in session: {session_str}")
    console.print(f"Time today: {today_str}")
    console.print(f"Time in project: {project_str}")


def _handle_change_display_mode_command(config: ScreenshooterConfig) -> None:
    """Prompt for and apply a display mode change."""
    displays = get_connected_displays()
    mode_options = ["all", "window"] + [f"display{display}" for display in displays] + ["custom"]
    option_labels = ["all (all displays)", "window (selected window)"]
    option_labels += [f"display{display} (Display {display})" for display in displays]
    option_labels.append("custom (choose displays)")
    console.print("\n[bold]Available display modes:[/bold]")
    for index, label in enumerate(option_labels, 1):
        console.print(f"{index}. {label}")

    mode_choice = Prompt.ask(
        "Choose display mode",
        choices=[str(index) for index in range(1, len(mode_options) + 1)],
        default="1",
    )
    new_mode = mode_options[int(mode_choice) - 1]
    if new_mode == "custom":
        new_mode = _prompt_custom_display_mode(displays)

    if new_mode != config.mode:
        config.mode = new_mode
        config.log_entry(
            f"Display mode changed to: {new_mode}",
            terminal_message=f"Display mode updated to: {new_mode}",
        )


def _prompt_custom_display_mode(displays: list[int]) -> str:
    """Prompt until valid custom display selection is provided."""
    while True:
        available_displays = " ".join(str(display) for display in displays)
        custom_input = Prompt.ask(
            f"Enter display numbers separated by space or comma (available: {available_displays})"
        )
        parts = [part for part in custom_input.replace(",", " ").split() if part.isdigit()]
        chosen = [int(part) for part in parts]
        if all(display in displays for display in chosen) and chosen:
            return f"custom:{','.join(str(display) for display in chosen)}"
        valid_display_str = " ".join(str(display) for display in displays)
        console.print(f"[red]Invalid selection. Please choose from: {valid_display_str}[/red]")


def _print_manual_help() -> None:
    """Print manual-mode command help."""
    console.print("\n[bold]Available Commands:[/bold]")
    console.print("s - Take a screenshot")
    console.print("w - Take a snippet screenshot (drag-select; requires snippet-gui extra)")
    console.print("n - Add a note to the log")
    console.print("c - Add a caption to the last screenshot")
    console.print("o - Open the last screenshot in Preview")
    console.print("l - Open the current session log in TextEdit")
    console.print("d - Change the display mode")
    console.print("p - Pause the session")
    console.print("r - Remove/archive last screenshot or note")
    console.print("e - Edit/remove specific screenshots or notes")
    console.print("t - Change the timer duration (exits manual mode)")
    console.print("q - Quit (no final screenshot will be taken)")
    console.print("i - Show time in session, today, and project total")
    console.print("h - Show this help information")


def _print_timer_help() -> None:
    """Print timer-mode command help."""
    console.print("\n[bold]Available Commands:[/bold]")
    console.print("s - Take a manual screenshot now and reset timer")
    console.print("w - Take a snippet screenshot now and reset timer")
    console.print("n - Add a note to the log")
    console.print("c - Add a caption to the last screenshot")
    console.print("o - Open the last screenshot in Preview")
    console.print("l - Open the current session log in TextEdit")
    console.print("d - Change the display mode")
    console.print("p - Pause the session")
    console.print("t - Change the timer duration or switch to manual mode")
    console.print("m - Switch to manual mode (with 10-second countdown)")
    console.print("r - Remove/archive last screenshot or note")
    console.print("e - Edit/remove specific screenshots or notes")
    console.print("q - Quit and take final screenshot")
    console.print("i - Show time in session, today, and project total")
    console.print("h - Show this help information")


def _print_manual_mode_intro() -> None:
    """Print introductory manual-mode commands."""
    console.print("Entering manual screenshot mode. No automatic screenshots will be taken.")
    console.print("Press 's' to take a manual screenshot")
    console.print("Press 'w' to take a snippet screenshot (drag-select with snippet-gui extra)")
    console.print("Press 'n' to add a note to the log")
    console.print("Press 'c' to add a caption to the last screenshot")
    console.print("Press 'd' to change the display mode")
    console.print("Press 'p' to pause the session for sensitive activities")
    console.print("Press 'o' to open the last screenshot in Preview")
    console.print("Press 'l' to open the current session log in TextEdit")
    console.print("Press 'i' to show time in session, today, and project total")
    console.print("Press 'r' to archive the last action (screenshot or note)")
    console.print("Press 'e' to list the last 5 actions")
    console.print("Press 't' to change timer and exit manual mode")
    console.print("Press 'q' to quit (no final screenshot will be taken)")
    console.print("Press 'h' for help")


def _handle_exit_request(config: ScreenshooterConfig) -> int | None:
    """Handle exit prompt and return exit code when user confirms."""
    should_exit = config.handle_exit()
    if should_exit:
        return post_session_report_flow(config)
    return None


def _handle_manual_pause_command(config: ScreenshooterConfig, timer: int | str) -> int | None:
    """Handle pause flow during manual mode."""
    if not config.countdown_for_screenshot(
        config.countdown_seconds,
        "The session will pause",
        start_message="Pausing session...",
        show_minimize_hint=False,
        cancel_message="Pause canceled.",
    ):
        return None

    config.pause_start_time = datetime.now()
    pause_reason = get_text_input("Enter reason for pausing: ") or "No reason provided"
    config.is_paused = True
    config.log_entry(
        f"SESSION PAUSED: {pause_reason}",
        terminal_message=f"\nSession paused at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
    )
    console.print("Only the following commands will work while paused:")
    console.print("  'r' - Resume the session (will take a post-pause screenshot)")
    console.print("  'q' - Quit and take final screenshot")
    console.print("When resuming, no automatic screenshot will be taken in manual mode.")

    while config.is_paused:
        pause_cmd = Prompt.ask("PAUSED (r to resume, q to quit)", choices=["r", "q"], default="r")
        if pause_cmd == "q":
            return _handle_exit_request(config)

        start_time = config.pause_start_time
        if start_time is None:
            start_time = datetime.now()
            config.pause_start_time = start_time
        pause_end = datetime.now()
        pause_delta = pause_end - start_time
        config.total_paused_seconds += pause_delta.total_seconds()
        formatted = config.format_seconds(pause_delta.total_seconds())
        config.log_entry(f"Paused for {formatted}")
        config.pause_start_time = None
        config.is_paused = False
        config.log_entry("SESSION RESUMED")

        if timer == "manual":
            console.print("\nResuming in manual mode (no automatic post-pause screenshot)...")
            time.sleep(2)
        elif config.countdown_for_screenshot(config.countdown_seconds, "Post-pause screenshot"):
            config.capture_screenshots("resume")
    return None


def _handle_manual_timer_change(
    config: ScreenshooterConfig,
    timer: int | str,
    mode_transition: bool,
) -> tuple[int | str, bool, bool]:
    """Handle timer change while in manual mode."""
    console.print(f"Current timer: {timer}")
    new_timer_input = get_text_input("Enter new timer value in minutes (positive integer): ")
    try:
        new_timer = int(new_timer_input)
        if new_timer > 0:
            config.log_entry(f"Timer changed from {timer} to {new_timer} minutes")
            if config.countdown_for_screenshot(
                config.countdown_seconds, "First screenshot with new timer"
            ):
                config.capture_screenshots("timer_changed")
            return new_timer, True, False
        console.print("Timer must be positive. Timer unchanged.")
    except ValueError:
        console.print("Invalid input. Timer unchanged.")
    _print_manual_status(config)
    return timer, mode_transition, True


def _handle_manual_mode_key(
    *,
    config: ScreenshooterConfig,
    key: str,
    timer: int | str,
    mode_transition: bool,
    manual_shared_handlers: dict[str, Callable[[], None]],
) -> tuple[int | str, bool, bool, int | None]:
    """Handle a single manual-mode key event."""
    next_timer = timer
    next_mode_transition = mode_transition
    manual_mode_active = True
    exit_code: int | None = None

    if key == "s":
        if config.countdown_for_screenshot(config.countdown_seconds, "Manual screenshot"):
            config.capture_screenshots("manual")
            _print_manual_status(config)
    elif key == "w":
        _handle_snippet_command(config)
        _print_manual_status(config)
    elif key in manual_shared_handlers:
        manual_shared_handlers[key]()
        _print_manual_status(config)
    elif key == "p":
        exit_code = _handle_manual_pause_command(config, next_timer)
        if exit_code is not None:
            manual_mode_active = False
        else:
            _print_manual_status(config)
    elif key == "t":
        next_timer, next_mode_transition, manual_mode_active = _handle_manual_timer_change(
            config,
            next_timer,
            next_mode_transition,
        )
        config.timer = next_timer
    elif key == "h":
        _print_manual_help()
    elif key in ["q", "ctrl+c"]:
        exit_code = _handle_exit_request(config)
        if exit_code is not None:
            manual_mode_active = False
    return next_timer, next_mode_transition, manual_mode_active, exit_code


def _handle_timer_change_command(
    *,
    config: ScreenshooterConfig,
    timer: int | str,
    next_time: float,
    minutes: int,
    seconds: int,
) -> tuple[int | str, float, bool, bool, bool]:
    """Handle timer value changes while in timer mode."""
    next_timer: int | str = timer
    next_time_value = next_time
    timer_mode_active = True
    skip_automatic_screenshot = False
    should_continue = False

    console.print(f"Current timer: {timer} minutes")
    console.print("Enter a new timer value in minutes, or type 'manual' to switch to manual mode")
    new_timer_input = get_text_input("Timer value (or 'manual'): ")

    if new_timer_input.lower() == "manual":
        console.print("Switching to manual mode...")
        config.log_entry("Switched from timer mode to manual mode via timer change")
        config.timer = "manual"
        next_timer = "manual"
        timer_mode_active = False
    elif not new_timer_input:
        console.print(f"Timer unchanged. Remaining: {minutes}m {seconds}s")
        _print_timer_status(config, next_time_value)
        should_continue = True
    else:
        try:
            new_timer = int(new_timer_input)
            if new_timer <= 0:
                console.print("Timer must be a positive value. Timer unchanged.")
                _print_timer_status(config, next_time_value)
                should_continue = True
            elif new_timer == timer:
                console.print(f"Timer unchanged. Remaining: {minutes}m {seconds}s")
                _print_timer_status(config, next_time_value)
                should_continue = True
            else:
                config.log_entry(f"Timer changed from {timer} to {new_timer} minutes")
                config.timer = new_timer
                next_timer = new_timer
                if config.countdown_for_screenshot(
                    config.countdown_seconds,
                    "First screenshot with new timer",
                ):
                    config.capture_screenshots("timer_changed")
                    next_time_value = datetime.now().timestamp() + (new_timer * 60)
                    skip_automatic_screenshot = True
                    console.print(f"Timer updated to {new_timer} minutes.")
                    _print_timer_status(config, next_time_value)
        except ValueError:
            console.print("Invalid input. Timer unchanged.")
            _print_timer_status(config, next_time_value)
            should_continue = True

    return (
        next_timer,
        next_time_value,
        timer_mode_active,
        skip_automatic_screenshot,
        should_continue,
    )


def _handle_timer_pause_command(
    *,
    config: ScreenshooterConfig,
    timer: int | str,
    next_time: float,
) -> tuple[float, int | None]:
    """Handle pause flow while in timer mode."""
    if not config.countdown_for_screenshot(
        config.countdown_seconds,
        "The session will pause",
        start_message="Pausing session...",
        show_minimize_hint=False,
        cancel_message="Pause canceled.",
    ):
        return next_time, None

    config.pause_start_time = datetime.now()
    pause_reason = get_text_input("Enter reason for pausing: ") or "No reason provided"
    config.is_paused = True
    paused_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    config.log_entry(
        f"SESSION PAUSED: {pause_reason}",
        terminal_message=f"\nSession paused at {paused_at}",
    )
    console.print("Only the following commands will work while paused:")
    console.print("  'r' - Resume the session (will take a post-pause screenshot)")
    console.print("  'q' - Quit and take final screenshot")

    while config.is_paused:
        pause_cmd = Prompt.ask("\nPAUSED", choices=["r", "q"], default="r")
        if pause_cmd == "q":
            return next_time, _handle_exit_request(config)

        start_time = config.pause_start_time or datetime.now()
        pause_end = datetime.now()
        pause_delta = pause_end - start_time
        config.total_paused_seconds += pause_delta.total_seconds()
        formatted = config.format_seconds(pause_delta.total_seconds())
        config.log_entry(f"Paused for {formatted}")
        config.pause_start_time = None
        config.is_paused = False
        config.log_entry("SESSION RESUMED")

        if timer == "manual":
            console.print("\nResuming in manual mode (no automatic post-pause screenshot)...")
            time.sleep(2)
        elif config.countdown_for_screenshot(config.countdown_seconds, "Post-pause screenshot"):
            config.capture_screenshots("resume")
        if isinstance(timer, int):
            next_time = datetime.now().timestamp() + (timer * 60)

    _print_timer_status(config, next_time)
    return next_time, None


def _run_manual_mode(
    config: ScreenshooterConfig,
    timer: int | str,
    mode_transition: bool,
) -> tuple[int | str, bool, int | None]:
    """Run manual screenshot mode loop."""
    mode_transition = False
    _print_manual_mode_intro()
    _print_manual_status(config)

    manual_mode_active = True
    manual_shared_handlers: dict[str, Callable[[], None]] = {
        "n": lambda: _handle_note_command(config),
        "c": lambda: _handle_caption_command(config),
        "o": lambda: _handle_open_screenshot_command(config),
        "l": lambda: _handle_open_session_log_command(config),
        "i": lambda: _handle_time_info_command(config),
        "r": lambda: _archive_last_session_item(config),
        "e": lambda: _manage_session_items(config),
        "d": lambda: _handle_change_display_mode_command(config),
    }

    while manual_mode_active:
        try:
            key = get_key()
            if not key:
                continue

            timer, mode_transition, manual_mode_active, exit_code = _handle_manual_mode_key(
                config=config,
                key=key,
                timer=timer,
                mode_transition=mode_transition,
                manual_shared_handlers=manual_shared_handlers,
            )
            if exit_code is not None:
                return timer, mode_transition, exit_code
        except KeyboardInterrupt:
            exit_code = _handle_exit_request(config)
            if exit_code is not None:
                return timer, mode_transition, exit_code

    return timer, mode_transition, None


def _show_timer_mode_intro(
    config: ScreenshooterConfig,
    timer: int | str,
    project: str,
    can_notify: bool,
) -> None:
    """Show timer-mode intro text and take initial screenshot."""
    console.print(f"Starting screenshot loop every {timer} minutes for project '{project}'")
    console.print("Press Ctrl+C to stop... (This will take a final screenshot before exiting)")
    console.print("Type 'n' to add a note to the log")
    console.print("Type 'c' to add a caption to the last screenshot")
    console.print("Type 's' to take a manual screenshot now and reset timer")
    console.print("Type 'w' to take a snippet screenshot now and reset timer")
    console.print("Type 'o' to open the last screenshot in Preview")
    console.print("Type 'l' to open the current session log in TextEdit")
    console.print("Type 'q' to quit and take final screenshot")
    console.print("Type 't' to change the timer duration")
    console.print("Type 'd' to change the display mode")
    console.print("Type 'p' to pause the session for sensitive activities")
    console.print("Type 'm' to switch to manual mode")
    console.print("Type 'r' to archive the last action (screenshot or note)")
    console.print("Type 'e' to list the last 5 actions")
    console.print("Type 'i' to show time in session, today, and project total")
    console.print("Type 'h' for help")

    if not can_notify:
        system = platform.system()
        if system == "Darwin":
            hint = "Install with: brew install terminal-notifier"
        elif system == "Linux":
            hint = "Install notify-send (libnotify)"
        else:
            hint = ""
        console.print(
            f"[yellow]Warning: Desktop notifications not available. "
            f"Pre-screenshot notifications will be disabled.{' ' + hint if hint else ''}[/yellow]"
        )

    countdown_seconds = config.countdown_seconds
    console.print(
        f"\nInitial screenshot will be taken in {countdown_seconds} "
        "seconds. Please minimize this terminal window..."
    )
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task("Taking initial screenshot...", total=countdown_seconds)
        for index in range(countdown_seconds):
            progress.update(
                task,
                description=f"Taking initial screenshot in {countdown_seconds - index} seconds...",
            )
            time.sleep(1)
            progress.update(task, advance=1)
        progress.update(task, description="Taking initial screenshot...")
    config.capture_screenshots("start")


def _handle_timer_mode_key(
    config: ScreenshooterConfig,
    key: str,
    timer: int | str,
    next_time: float,
) -> tuple[int | str, float, bool, bool, bool, bool, bool, int | None]:
    """Handle one timer-mode key and return updated state."""
    timer_mode_active = True
    skip_automatic_screenshot = False
    was_exit_canceled = False
    break_countdown = False
    should_continue = False
    exit_code: int | None = None

    if key in {"ctrl+c", "q"}:
        before_exit = datetime.now().timestamp() if key == "q" else None
        exit_code = _handle_exit_request(config)
        if exit_code is None:
            was_exit_canceled = True
            if before_exit is not None:
                time_elapsed = datetime.now().timestamp() - before_exit
                next_time += time_elapsed
            _print_timer_status(config, next_time)
    elif key in {"n", "c", "o", "l", "i", "r", "e", "d"}:
        timer_shared_handlers: dict[str, Callable[[], None]] = {
            "n": lambda: _handle_note_command(config),
            "c": lambda: _handle_caption_command(config),
            "o": lambda: _handle_open_screenshot_command(config),
            "l": lambda: _handle_open_session_log_command(config),
            "i": lambda: _handle_time_info_command(config),
            "r": lambda: _archive_last_session_item(config),
            "e": lambda: _manage_session_items(config),
            "d": lambda: _handle_change_display_mode_command(config),
        }
        timer_shared_handlers[key]()
        _print_timer_status(config, next_time)
    elif key in {"s", "w"}:
        screenshot_taken = False
        if key == "s":
            if config.countdown_for_screenshot(config.countdown_seconds, "Manual screenshot"):
                screenshot_taken = config.capture_screenshots("manual")
        else:
            screenshot_taken = _handle_snippet_command(config)

        if screenshot_taken:
            if isinstance(timer, int):
                next_time = datetime.now().timestamp() + (timer * 60)
            skip_automatic_screenshot = True
        _print_timer_status(config, next_time)
        break_countdown = True
    elif key in {"m", "t", "p"}:
        (
            timer,
            next_time,
            timer_mode_active,
            skip_automatic_screenshot,
            break_countdown,
            should_continue,
            exit_code,
        ) = _handle_timer_mode_control_key(
            config,
            key,
            timer,
            next_time,
        )
    elif key == "h":
        _print_timer_help()

    return (
        timer,
        next_time,
        timer_mode_active,
        skip_automatic_screenshot,
        was_exit_canceled,
        break_countdown,
        should_continue,
        exit_code,
    )


def _handle_timer_mode_control_key(
    config: ScreenshooterConfig,
    key: str,
    timer: int | str,
    next_time: float,
) -> tuple[int | str, float, bool, bool, bool, bool, int | None]:
    """Handle timer-mode control keys m/t/p."""
    timer_mode_active = True
    skip_automatic_screenshot = False
    break_countdown = False
    should_continue = False
    exit_code: int | None = None

    if key == "m":
        if config.countdown_for_screenshot(
            config.countdown_seconds,
            "Switching to manual mode",
            start_message="Switching to manual mode...",
            show_minimize_hint=False,
            cancel_message="Canceled switch to manual mode.",
        ):
            config.log_entry("Switched from timer mode to manual mode")
            timer = "manual"
            config.timer = "manual"
            timer_mode_active = False
            break_countdown = True
        else:
            _print_timer_status(config, next_time)
        return (
            timer,
            next_time,
            timer_mode_active,
            skip_automatic_screenshot,
            break_countdown,
            should_continue,
            exit_code,
        )

    if key == "t":
        remaining = int(max(next_time - datetime.now().timestamp(), 0))
        minutes = remaining // 60
        seconds = remaining % 60
        (
            timer,
            next_time,
            timer_mode_active,
            skip_automatic_screenshot,
            should_continue,
        ) = _handle_timer_change_command(
            config=config,
            timer=timer,
            next_time=next_time,
            minutes=minutes,
            seconds=seconds,
        )
        break_countdown = not timer_mode_active or skip_automatic_screenshot
        return (
            timer,
            next_time,
            timer_mode_active,
            skip_automatic_screenshot,
            break_countdown,
            should_continue,
            exit_code,
        )

    next_time, exit_code = _handle_timer_pause_command(
        config=config,
        timer=timer,
        next_time=next_time,
    )
    return (
        timer,
        next_time,
        timer_mode_active,
        skip_automatic_screenshot,
        break_countdown,
        should_continue,
        exit_code,
    )


def _run_timer_countdown(
    config: ScreenshooterConfig,
    timer: int | str,
    next_time: float,
    can_notify: bool,
    notifier_path: str | None,
) -> tuple[int | str, float, bool, bool, bool, int | None]:
    """Run one timer countdown interval until screenshot time or mode change."""
    skip_automatic_screenshot = False
    was_exit_canceled = False
    timer_mode_active = True

    notification_sent_this_interval = False
    while datetime.now().timestamp() < next_time:
        try:
            remaining = int(next_time - datetime.now().timestamp())
            minutes = remaining // 60
            seconds = remaining % 60
            sys.stdout.write(f"\rNext screenshot in: {minutes:02d}m {seconds:02d}s ")
            sys.stdout.flush()

            if (
                can_notify
                and notifier_path
                and should_notify_before_scheduled()
                and PRE_SCREENSHOT_NOTIFY_MIN_SECONDS
                <= remaining
                <= PRE_SCREENSHOT_NOTIFY_MAX_SECONDS
                and not notification_sent_this_interval
            ):
                try:
                    _send_pre_screenshot_notification(
                        notifier_path,
                        "Screenshot Soon",
                        "Approx. 30 seconds until next screenshot. Prepare your screen!",
                    )
                    notification_sent_this_interval = True
                except Exception as e:
                    console.print(
                        f"\n[yellow]Warning: Error sending 30s notification: {e}[/yellow]"
                    )
                    notification_sent_this_interval = True

            key = get_key()
            if not key:
                continue
            sys.stdout.write("\n")
            sys.stdout.flush()

            (
                timer,
                next_time,
                timer_mode_active,
                skip_automatic_screenshot,
                key_exit_canceled,
                break_countdown,
                should_continue,
                exit_code,
            ) = _handle_timer_mode_key(
                config,
                key,
                timer,
                next_time,
            )
            if exit_code is not None:
                return (
                    timer,
                    next_time,
                    timer_mode_active,
                    skip_automatic_screenshot,
                    True,
                    exit_code,
                )
            was_exit_canceled = was_exit_canceled or key_exit_canceled
            if break_countdown:
                break
            if should_continue:
                continue
        except KeyboardInterrupt:
            exit_code = _handle_exit_request(config)
            if exit_code is not None:
                return (
                    timer,
                    next_time,
                    timer_mode_active,
                    skip_automatic_screenshot,
                    True,
                    exit_code,
                )
            was_exit_canceled = True
            _print_timer_status(config, next_time)

    return timer, next_time, timer_mode_active, skip_automatic_screenshot, was_exit_canceled, None


def _run_timer_mode(
    config: ScreenshooterConfig,
    timer: int | str,
    mode_transition: bool,
    notify_capability: tuple[bool, str | None],
) -> tuple[int | str, bool, int | None]:
    """Run timer mode loop."""
    can_notify, notifier_path = notify_capability
    if not mode_transition:
        _show_timer_mode_intro(config, timer, config.project_name, can_notify)
    else:
        mode_transition = False

    timer_mode_active = True
    while timer_mode_active:
        try:
            timer_minutes = timer if isinstance(timer, int) else 0
            next_time = datetime.now().timestamp() + (timer_minutes * 60)
            _print_timer_status(config, next_time)

            (
                timer,
                next_time,
                timer_mode_active,
                skip_automatic_screenshot,
                was_exit_canceled,
                exit_code,
            ) = _run_timer_countdown(config, timer, next_time, can_notify, notifier_path)
            if exit_code is not None:
                return timer, mode_transition, exit_code

            if not skip_automatic_screenshot and not was_exit_canceled and timer_mode_active:
                console.print()
                config.capture_screenshots()
        except KeyboardInterrupt:
            exit_code = _handle_exit_request(config)
            if exit_code is not None:
                return timer, mode_transition, exit_code

    return timer, mode_transition, None


@click.command()
@click.option("--client", help="Set client name for screenshots folder")
@click.option("--project", help="Set project name for screenshots folder")
@click.option(
    "--mode",
    type=click.Choice(["all", "main", "second", "window"]),
    default="all",
    help="Screenshot mode",
)
@click.option(
    "--timer", type=int, default=0, help="Take screenshots every N minutes (0 for single shot)"
)
@click.option("--interactive", is_flag=True, help="Run in interactive mode with guided setup")
def main(client: str | None, project: str | None, mode: str, timer: int, interactive: bool) -> int:
    """Screenshot capture module for ScreenShooter Mac."""
    ensure_terminal_cooked_mode()
    session_timer: int | str = timer

    # If interactive mode or missing required parameters, run interactive setup
    if interactive or (not client or not project):
        options = interactive_project_selection()
        if options is None:  # Handle incomplete setup or user-cancel
            # console.print("[yellow]Setup cancelled. Returning to main menu.[/yellow]")
            return 1
        client = options["client"]
        project = options["project"]
        mode = options["mode"]
        session_timer = options["timer"]

    # Ensure client and project are strings after potential interactive selection
    if not client or not project:
        console.print("[bold red]Client and Project names are required.[/bold red]")
        return 1

    # Create configuration
    config = ScreenshooterConfig(
        client_name=client,
        project_name=project,
        mode=mode,
        timer=session_timer,
    )

    # Display client info
    config.display_client_info()

    # Get session note
    session_note = get_text_input("\nPlease enter a note to start this session: ")
    while not session_note:
        session_note = get_text_input(
            "Note cannot be empty. Please enter a note to start this session: "
        )
    config.log_entry(
        f"SESSION START NOTE: {session_note}", terminal_message="Session note added successfully."
    )

    # Track mode transition to avoid redundant operations
    mode_transition = False
    # Check if notifications are available (cross-platform)
    can_notify, notifier_path = _get_notification_capability()

    try:
        # Main execution loop - allows switching between modes
        while True:
            if session_timer == 0:
                # Single shot mode
                config.capture_screenshots()
                config.log_entry("Single screenshot set completed")
                break  # Exit after single shot
            elif session_timer == "manual":
                session_timer, mode_transition, exit_code = _run_manual_mode(
                    config,
                    session_timer,
                    mode_transition,
                )
                if exit_code is not None:
                    return exit_code

                # If we've exited manual mode loop without returning, and timer is not "manual"
                # anymore,
                # continue to the next iteration which will enter timer mode
                continue

            else:
                session_timer, mode_transition, exit_code = _run_timer_mode(
                    config=config,
                    timer=session_timer,
                    mode_transition=mode_transition,
                    notify_capability=(can_notify, notifier_path),
                )
                if exit_code is not None:
                    return exit_code
    except (KeyboardInterrupt, click.Abort):  # handle user aborts gracefully
        # On abrupt aborts, still attempt to finalize the DB session
        try:
            config.update_db_session()
        except Exception:
            pass
        console.print("\nThanks for using ScreenShooter. Goodbye!")
        return 0
    # Normal end of session flow
    config.update_db_session()
    result = post_session_report_flow(config)
    ensure_terminal_cooked_mode()
    return result


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (KeyboardInterrupt, click.Abort):  # handle user aborts gracefully
        console.print("\nThanks for using ScreenShooter. Goodbye!")
        sys.exit(0)
