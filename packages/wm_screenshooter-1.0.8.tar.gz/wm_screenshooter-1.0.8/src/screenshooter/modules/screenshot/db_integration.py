#!/usr/bin/env python3
"""Database integration for screenshot module.

Provides database logging functionality that works alongside existing file logging.
"""

import json
from datetime import datetime
from pathlib import Path

from rich.console import Console

from screenshooter.modules.clients.models import ClientInfo
from screenshooter.modules.clients.utils import slugify_name
from screenshooter.modules.database import (
    DatabaseClient,
    DatabaseNote,
    DatabaseNoteType,
    DatabaseOperations,
    DatabaseProject,
    DatabaseScreenshot,
    DatabaseSession,
)
from screenshooter.modules.settings.settings_helper import get_screenshots_dir

console = Console()


class DatabaseLogger:
    """Handles database logging for screenshot sessions."""

    def __init__(self, client_name: str, project_name: str, session_name: str):
        """Initialize database logger.

        Args:
            client_name: Client name
            project_name: Project name
            session_name: Session name
        """
        self.client_name = client_name
        self.project_name = project_name
        self.session_name = session_name
        self.session_start_time = None  # Store session start time

        # Database components
        self.db_operations = None
        self.current_session_id = None
        self.current_project_id = None
        self.current_client_id = None

        # Try to initialize database
        self._initialize_database()

    def _initialize_database(self) -> None:
        """Initialize database connection and records."""
        try:
            self.db_operations = DatabaseOperations()
            self._setup_database_records()

        except ImportError:
            console.print(
                "[yellow]Database module not available. Using file logging only.[/yellow]"
            )
            self.db_operations = None
        except Exception as e:
            console.print(f"[yellow]Database initialization failed: {e}[/yellow]")
            console.print("[yellow]Using file logging only.[/yellow]")
            self.db_operations = None

    def _setup_database_records(self) -> None:
        """Set up initial database records for client, project, and session."""
        if not self.db_operations:
            return

        try:
            self.current_client_id = self._resolve_or_create_client_id()
            self.current_project_id = self._resolve_or_create_project_id(self.current_client_id)
            self.current_session_id, self.session_start_time = self._create_session_record(
                self.current_project_id
            )

        except Exception as e:
            console.print(f"[yellow]Database record setup failed: {e}[/yellow]")

    def _resolve_or_create_client_id(self) -> int:
        """Get existing client id or create a new client record."""
        if not self.db_operations:
            raise RuntimeError("Database operations not initialized")

        client = self.db_operations.get_client_by_name(self.client_name)
        if not client:
            client = self.db_operations.get_client_by_directory(self.client_name)
        if client:
            return client.id

        client_info_file = self._ensure_client_info_file()
        if client_info_file.exists():
            client_info = ClientInfo.model_validate_json(client_info_file.read_text())
            db_client = DatabaseClient(
                name=client_info.client_name,
                directory_name=client_info.directory_name,
                company_name=client_info.company_name,
                contact_name=client_info.contact_name,
                contact_email=client_info.contact_email,
                pdf_password=client_info.pdf_password,
                preferences=client_info.preferences,
            )
            return self.db_operations.create_client(db_client)

        db_client = DatabaseClient(
            name=self.client_name,
            directory_name=slugify_name(self.client_name),
        )
        return self.db_operations.create_client(db_client)

    def _ensure_client_info_file(self) -> Path:
        """Return client info path, migrating legacy filename if needed."""
        base_dir = Path(get_screenshots_dir())
        client_info_file = base_dir / self.client_name / "client.json"
        if client_info_file.exists():
            return client_info_file

        legacy = base_dir / self.client_name / "client_info.json"
        if not legacy.exists():
            return client_info_file

        try:
            data = json.loads(legacy.read_text())
            archived_val = data.pop("archived", False)
            archived_at = data.get("archived_at", "")
            if not archived_at and archived_val:
                archived_at = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            data["archived_at"] = archived_at
            client_info_file.write_text(json.dumps(data, indent=2))
            legacy.unlink(missing_ok=True)
        except Exception:
            pass
        return client_info_file

    def _resolve_or_create_project_id(self, client_id: int) -> int:
        """Get existing project id or create a new project record."""
        if not self.db_operations:
            raise RuntimeError("Database operations not initialized")

        project = self.db_operations.get_project_by_directory(client_id, self.project_name)
        if project:
            return project.id

        db_project = DatabaseProject(
            client_id=client_id,
            name=self.project_name,
            directory_name=self.project_name,
        )
        return self.db_operations.create_project(db_project)

    def _create_session_record(self, project_id: int) -> tuple[int, datetime]:
        """Create session row and return session id with start time."""
        if not self.db_operations:
            raise RuntimeError("Database operations not initialized")

        start_time = datetime.now()
        db_session = DatabaseSession(
            project_id=project_id,
            name=self.session_name,
            start_time=start_time,
            timer_mode="",
        )
        return self.db_operations.create_session(db_session), start_time

    def log_screenshot(
        self, set_id: int, file_path: str, suffix: str, display_mode: str = ""
    ) -> None:
        """Log screenshot to database.

        Args:
            set_id: Screenshot set ID
            file_path: Path to screenshot file
            suffix: Screenshot suffix (e.g., "all", "main")
            display_mode: Display mode used
        """
        if not self.db_operations or not self.current_session_id:
            return

        try:
            db_screenshot = DatabaseScreenshot(
                session_id=self.current_session_id,
                set_id=set_id,
                file_path=file_path,
                timestamp=datetime.now(),
                suffix=suffix,
                display_mode=display_mode,
            )
            self.db_operations.create_screenshot(db_screenshot)
        except Exception as e:
            console.print(f"[yellow]Database screenshot logging failed: {e}[/yellow]")

    def log_note(self, content: str, note_type: str = DatabaseNoteType.NOTE) -> None:
        """Log note to database.

        Args:
            content: Note content
            note_type: Type of note (e.g. NOTE, SESSION_START, SESSION_END)
        """
        if not self.db_operations or not self.current_session_id:
            return

        try:
            db_note = DatabaseNote(
                session_id=self.current_session_id,
                content=content,
                note_type=note_type,
                timestamp=datetime.now(),
            )
            self.db_operations.create_note(db_note)
        except Exception as e:
            console.print(f"[yellow]Database note logging failed: {e}[/yellow]")

    def log_pause(self, reason: str) -> None:
        """Log a pause event to the database."""
        self.log_note(reason, DatabaseNoteType.PAUSE)

    def log_resume(self, duration: str) -> None:
        """Log a resume event to the database."""
        self.log_note(duration, DatabaseNoteType.RESUME)

    def log_caption(self, set_id: int, content: str) -> None:
        """Log caption to database (as note with CAPTION type).

        Args:
            set_id: Screenshot set ID
            content: Caption content
        """
        if not self.db_operations or not self.current_session_id:
            return

        try:
            # Store captions as notes with CAPTION type, including the set ID
            # Format: "Caption content (Set #X)"
            formatted_content = f"{content} (Set #{set_id})"

            db_note = DatabaseNote(
                session_id=self.current_session_id,
                content=formatted_content,
                note_type=DatabaseNoteType.CAPTION,
                timestamp=datetime.now(),
            )
            self.db_operations.create_note(db_note)
        except Exception as e:
            console.print(f"[yellow]Database caption logging failed: {e}[/yellow]")

    def log_session_start_note(self, content: str) -> None:
        """Log the initial session note with SESSION_START type."""
        self.log_note(content, DatabaseNoteType.SESSION_START)

    def log_session_end_note(self, content: str) -> None:
        """Log an end-of-session note with SESSION_END type."""
        self.log_note(content, DatabaseNoteType.SESSION_END)

    def update_session(
        self,
        end_time: datetime | None = None,
        duration_seconds: int | None = None,
        timer_mode: str = "",
    ) -> None:
        """Update session record in database.

        Args:
            end_time: Session end time
            duration_seconds: Session duration in seconds
            timer_mode: Timer mode used
        """
        if not self.db_operations or not self.current_session_id:
            return

        try:
            # Get current session and update it
            session_data = DatabaseSession(
                id=self.current_session_id,
                project_id=self.current_project_id,
                name=self.session_name,
                start_time=self.session_start_time,  # Use stored start time
                end_time=end_time or datetime.now(),
                duration_seconds=duration_seconds,
                timer_mode=timer_mode,
            )
            self.db_operations.update_session(session_data)
        except Exception as e:
            console.print(f"[yellow]Database session update failed: {e}[/yellow]")

    def is_available(self) -> bool:
        """Check if database logging is available.

        Returns:
            True if database logging is available
        """
        return self.db_operations is not None
