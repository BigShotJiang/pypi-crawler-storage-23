# WorkMaster ScreenShooter Documentation

This documentation is for the WorkMaster ScreenShooter application.

## Table of Contents

- [CHANGELOG](CHANGELOG.md)
- [ROADMAP](ROADMAP.md)
