# Report Generator: All Projects Batch Flow

This document records the recent updates to report generation so the behavior is easy to reference
later.

## What Was Changed

### 1) New "All active projects" option in project selection

In report setup, project selection now includes:

- `a. All active projects`

This allows generating reports for every active project under the selected client in one run.

### 2) New scope step for all-project mode

When `All active projects` is selected, a scope prompt appears:

- `1. Today (daily report for each active project)`
- `2. Whole project workflow (full project report for each active project)`

Behavior:

- `Today` generates one **day report** per active project.
- `Whole project workflow` generates one **project report** per active project.

### 3) Batch generation behavior

- The system generates one PDF per project.
- It continues processing remaining projects if one project fails.
- It prints a summary showing successes/failures and output paths.

### 4) Open all generated PDFs prompt

After batch generation succeeds, users are prompted once:

- `Would you like to open all generated PDFs?`

If yes, each generated PDF is opened.

### 5) Single batch email for all generated reports

After generation, users can send one email containing all reports from that batch run.

- Attachment mode (`send_attachment = true`): all generated PDFs are attached in one email.
- S3 link mode (`send_attachment = false`): reports are uploaded and project-specific links are
  included in one email.

### 6) Email body includes project-by-project details

The single batch email includes a section for each project with:

- project name
- report type/date or date range
- session count
- total tracked time
- optional notes for that project

### 7) Notes prompt behavior (current)

Per project, notes are captured with the existing single text input (supports `/n`, `\n`, `<br>`,
and `/b`) plus preview and confirmation:

- `k` keep
- `r` re-enter
- `c` clear

Note: line-by-line note-entry commands (`/done`, `/undo`, `/clear`) were tested and then removed.
The flow now uses the prior single-input behavior.

## User Experience Examples

### Example A: Batch generation + single email with attachments

1. User selects `Generate Reports`.
2. Chooses a client.
3. Selects `a. All active projects`.
4. Chooses scope `2` (`Whole project workflow`).
5. Generation completes for each project and prints summary.
6. User chooses to open all PDFs.
7. User chooses to email all generated reports.
8. User enters optional notes per project.
9. One email is sent with both PDFs attached and project sections in the body.

### Example B: Batch generation + single email with S3 links

1. Same setup as above.
2. S3 is enabled and `send_attachment` is disabled.
3. System uploads each report and builds per-project links.
4. One email is sent with project sections and links (instead of attachments).

### Example C: Notes confirmation

For each project:

1. Enter notes text in one input (supports `/b` bullets).
2. Preview appears.
3. Choose:
   - `k` to keep and continue
   - `r` to edit/re-enter before continuing
   - `c` to send without notes for that project

