# bkrc-annotation

**百科荣创图像标注工具客户端** - 让图像标注和模型训练变得更简单！

[![PyPI version](https://img.shields.io/pypi/v/bkrc-annotation.svg)](https://pypi.org/project/bkrc-annotation/)
[![Python versions](https://img.shields.io/pypi/pyversions/bkrc-annotation.svg)](https://pypi.org/project/bkrc-annotation/)
[![License](https://img.shields.io/pypi/l/bkrc-annotation.svg)](https://pypi.org/project/bkrc-annotation/)

## 🚀 快速开始

### 安装
```bash
pip install bkrc-annotation
```

### 启动应用-命令行
```bash
bkrc-annotation
```

## 📋 核心功能

### 🖼️ 图像标注
- 支持矩形框、多边形、点标注
- 批量图像导入和标注
- 智能标注辅助和标签管理

### 🎬 视频处理
- 视频拆分为图像帧
- 自定义帧间隔和命名规则

### 🤖 AI模型集成
- YOLOv8目标检测和训练
- ONNX模型量化和优化
- Netron模型可视化

### 📊 训练监控
- TensorBoard集成
- 实时监控训练进度
- 智能识别最新训练日志

## 🎯 使用指南

### 基本操作
1. **启动应用**: `bkrc-annotation`
2. **导入图像**: 文件 → 导入图像/文件夹
3. **创建标注**: 选择工具绘制标注区域
4. **模型训练**: 配置参数开始训练
5. **查看结果**: 使用TensorBoard监控进度

### 画布操作
- **拖动画布**: `Shift` + 鼠标拖动
- **缩放画布**: `+`/`-` 键
- **重置缩放**: `R` 键

### 快捷键
| 快捷键 | 功能 |
|--------|------|
| `Ctrl+S` | 保存标注 |
| `Delete` | 删除选中标注 |
| `A/D` | 上一张/下一张图像 |

## 🌐 API文档

应用启动后，后端服务运行在端口8000：
- **Swagger UI**: http://127.0.0.1:8000/docs
- **主要端点**: 健康检查、模型预测、文件上传、视频处理

## 🔧 高级功能

### 视频拆分
1. 文件 → 打开视频文件
2. 设置帧间隔和命名规则
3. 开始提取图像帧

### 模型量化
- 训练完成后选择模型
- 设置量化参数
- 生成优化的ONNX模型

### Netron视图
- 选择模型文件
- 点击Netron视图按钮
- 查看模型结构图

## � 系统要求

- **操作系统**: Windows 10/11, Linux, macOS
- **Python版本**: 3.8-3.11
- **内存**: 推荐8GB+ RAM
- **显卡**: 支持CUDA的NVIDIA显卡（可选）

## 📄 许可证

MIT 许可证 - 查看 [LICENSE](LICENSE) 文件

## 📞 联系我们

- **官网**: https://www.r8c.com/
- **团队**: 百科荣创标注工具团队
- **邮箱**: 2075166620@qq.com

---

## 💡 项目状态

**bkrc-annotation** 是一个持续开发和完善中的项目。我们致力于为用户提供更好的图像标注和模型训练体验。

### 🚧 正在完善
- 部分功能还在测试阶段
- 界面和用户体验持续优化
- 性能和稳定性不断提升

**开始使用 bkrc-annotation，让图像标注和模型训练变得更简单！** 🎉

*感谢您的理解和支持！*