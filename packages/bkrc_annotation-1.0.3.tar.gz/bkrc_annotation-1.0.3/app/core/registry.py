import importlib
import pkgutil
import sys  # 新增：用于清除模块缓存
import time
from loguru import logger
from pathlib import Path
from typing import Dict, List, Optional, Type, Union

from app.models.protocol import ModelProtocol

# 全局模型注册表：键为模型唯一标识(inference_id)，值为对应的模型类(符合ModelProtocol)
_MODEL_REGISTRY: Dict[str, Type[ModelProtocol]] = {}


def register_model(*inference_ids: str):
    """模型注册装饰器：用于将模型类注册到全局_MODEL_REGISTRY中"""

    def decorator(cls: Type[ModelProtocol]) -> Type[ModelProtocol]:
        # 遍历所有传入的inference_id，逐个注册
        for inference_id in inference_ids:
            # 如果inference_id已存在，打印警告并覆盖原有注册
            if inference_id in _MODEL_REGISTRY:
                logger.warning(
                    f"模型'{inference_id}'已被注册，将使用{cls.__name__}覆盖原有注册项"
                )
            _MODEL_REGISTRY[inference_id] = cls
        return cls

    return decorator


class ModelRegistry:
    """模型加载与注册管理类（增强版，支持动态刷新文件）"""

    def __init__(self, config_dir: Optional[Path] = None, *args, **kwargs):
        """初始化模型加载器

        Args:
            config_dir: 配置目录（兼容参数，无实际作用）
            *args, **kwargs: 兼容其他可能的参数，避免报错
        """
        self.config_dir = config_dir
        # 存储已加载的模型实例：键为inference_id，值为ModelProtocol的实例
        self.models: Dict[str, ModelProtocol] = {}
        # 存储命名的模型实例：键为 (inference_id, instance_name)，值为ModelProtocol的实例
        self.named_instances: Dict[tuple, ModelProtocol] = {}
        # 构建模型注册表（inference_id -> 模型类）
        self.model_registry = self._build_registry()

    def _clear_model_modules_cache(self):
        """新增：清除app.models下所有模块的缓存，让Python重新导入最新文件"""
        # 遍历sys.modules，删除所有app.models开头的模块缓存
        modules_to_remove = []
        for module_name in sys.modules:
            if module_name.startswith("app.models.") and not module_name.endswith("__init__"):
                modules_to_remove.append(module_name)

        for module_name in modules_to_remove:
            del sys.modules[module_name]
            logger.debug(f"清除模块缓存：{module_name}")

    def _build_registry(self, rebuild: bool = False) -> Dict[str, type]:
        """改造：支持清空旧注册表+清除缓存，重新扫描导入模块"""
        # 1. 如果是重建，先清空全局注册表和模块缓存
        if rebuild:
            _MODEL_REGISTRY.clear()  # 清空旧的注册信息
            self._clear_model_modules_cache()  # 清除模块缓存

        # 2. 重新扫描并导入app.models下的模块（逻辑和原代码一致，但会读取最新文件）
        import app.models
        for importer, modname, ispkg in pkgutil.iter_modules(
                app.models.__path__,
                app.models.__name__ + "."
        ):
            if not ispkg and not modname.startswith("app.models._"):
                try:
                    # 重新导入模块（此时会执行最新的代码，包括@register_model）
                    importlib.import_module(modname)
                except Exception as e:
                    logger.warning(f"导入模型模块{modname}失败：{e}")

        # 3. 更新实例的model_registry并返回
        self.model_registry = _MODEL_REGISTRY.copy()
        return self.model_registry

    def rebuild_registry(self):
        """新增：对外暴露的重建注册表方法（方便手动调用）"""
        return self._build_registry(rebuild=True)

    def load_all_models(self):
        """启动/刷新加载所有已注册的模型（支持动态添加/删除文件）"""
        # 第一步：先重建注册表（清空缓存+重新扫描+重新注册）
        logger.info("开始重新扫描并构建模型注册表...")
        self.rebuild_registry()

        # 第二步：获取最新的已注册inference_id（去重）
        enabled_inference_ids = list(self.model_registry.keys())
        enabled_inference_ids = list(dict.fromkeys(enabled_inference_ids))  # 去重

        if not enabled_inference_ids:
            logger.warning("未发现任何已注册的模型（通过@register_model装饰的模型）")
            return

        logger.info(f"开始加载{len(enabled_inference_ids)}个已注册的模型...")

        # 第三步：卸载旧的模型实例（避免资源占用）
        self.unload_all_models()

        # 第四步：加载新实例
        for inference_id in enabled_inference_ids:
            try:
                self._load_single_model(inference_id)
            except Exception as e:
                logger.error(f"加载模型[{inference_id}]失败：{e}")
                continue

        # 输出结果
        if len(self.models) == 0:
            logger.warning("所有已注册的模型均加载失败")
        else:
            logger.info(
                f"模型加载完成：成功加载{len(self.models)}/{len(enabled_inference_ids)}个模型"
            )

    def _load_single_model(self, inference_id: str):
        """加载单个模型实例（移除YAML配置读取逻辑）"""
        # 检查模型是否已注册
        if inference_id not in self.model_registry:
            raise ValueError(
                f"模型'{inference_id}'未注册，请检查是否在app.models中实现并通过@register_model注册"
            )

        # 获取模型类并实例化
        model_class = self.model_registry[inference_id]
        
        # 由于_load_single_model用于加载预设模型，我们使用默认参数实例化
        import inspect
        init_sig = inspect.signature(model_class.__init__)
        
        # 准备__init__参数（使用默认值）
        init_kwargs = {}
        for param_name, param in init_sig.parameters.items():
            if param_name != 'self':
                if param.default != inspect.Parameter.empty:
                    init_kwargs[param_name] = param.default
                else:
                    # 如果没有默认值，则设置为None或适当默认值
                    init_kwargs[param_name] = None
        
        model_instance = model_class(**init_kwargs)

        # 记录加载开始时间，用于统计耗时
        logger.info(f"开始加载模型[{inference_id}]...")
        start_time = time.time()

        # 调用模型实例的load方法（实际加载权重/初始化）
        # model_instance.load()

        # 计算加载耗时
        elapsed_time = time.time() - start_time
        # 将加载完成的实例存入字典
        self.models[inference_id] = model_instance
        logger.info(
            f"模型[{inference_id}]加载成功（耗时：{elapsed_time:.2f}秒）"
        )

    def get_model(self, inference_id: str) -> ModelProtocol:
        """获取已加载的模型实例"""
        if inference_id not in self.models:
            raise ValueError(f"模型'{inference_id}'未加载，请检查是否启用并加载成功")
        return self.models[inference_id]

    def get_parametrized_model(self, inference_id: str, params: dict) -> ModelProtocol:
        """获取基于参数的模型实例"""
        # 检查是否存在命名实例
        instance_name = params.get("instance_name")

        if instance_name:
            # 使用模型ID和实例名称作为键，确保唯一性
            named_key = (inference_id, instance_name)

            # 检查是否已有对应命名的模型实例
            if named_key in self.named_instances:
                return self.named_instances[named_key]

            # 创建新的命名模型实例
            model_class = self.model_registry.get(inference_id)
            if model_class:
                # 从params中提取适用于__init__的参数
                import inspect
                init_sig = inspect.signature(model_class.__init__)
                
                # 准备__init__参数
                init_kwargs = {}
                for param_name in init_sig.parameters:
                    if param_name != 'self' and param_name in params:
                        init_kwargs[param_name] = params[param_name]
                
                # 实例化模型，传入适用的参数
                model_instance = model_class(**init_kwargs)
                model_instance.load(params)
                self.named_instances[named_key] = model_instance
                return model_instance

        # 如果没有特殊参数，返回标准模型实例
        return self.get_model(inference_id)

    def get_all_models_info(self) -> Dict[str, Dict]:
        """获取所有已加载模型的元数据"""
        return {
            inference_id: model.get_metadata()
            for inference_id, model in self.models.items()
        }

    def get_named_instance(self, inference_id: str, instance_name: str) -> ModelProtocol:
        """获取指定名称的模型实例"""
        named_key = (inference_id, instance_name)
        if named_key not in self.named_instances:
            raise ValueError(f"命名实例'{instance_name}'未找到")
        return self.named_instances[named_key]

    def list_named_instances(self) -> List[Dict]:
        """列出所有命名实例的信息"""
        result = []
        for (inference_id, instance_name), model in self.named_instances.items():
            result.append({
                "inference_id": inference_id,
                "instance_name": instance_name,
                "metadata": model.get_metadata()
            })
        return result

    def unload_named_instance(self, inference_id: str, instance_name: str):
        """卸载指定名称的模型实例"""
        named_key = (inference_id, instance_name)
        if named_key in self.named_instances:
            model = self.named_instances[named_key]
            try:
                model.unload()
                del self.named_instances[named_key]
                logger.info(f"命名实例{named_key}已成功卸载")
            except Exception as e:
                logger.error(f"卸载命名实例{named_key}失败：{e}")
        else:
            logger.warning(f"命名实例{named_key}不存在，无法卸载")

    def unload_all_named_instances(self):
        """卸载所有命名实例"""
        logger.info("开始卸载所有命名实例...")
        for named_key, model in list(self.named_instances.items()):
            try:
                model.unload()
                logger.info(f"命名实例{named_key}已成功卸载")
            except Exception as e:
                logger.error(f"卸载命名实例{named_key}失败：{e}")
        self.named_instances.clear()

    def unload_all_models(self):
        """卸载所有已加载的模型，释放资源"""
        logger.info("开始卸载所有模型...")
        # 遍历所有已加载的标准模型实例
        for inference_id, model in self.models.items():
            try:
                # 调用模型的unload方法释放资源
                model.unload()
                logger.info(f"模型[{inference_id}]已成功卸载")
            except Exception as e:
                # 单个模型卸载失败时记录错误，继续处理其他模型
                logger.error(f"卸载模型[{inference_id}]失败：{e}")
        # 清空标准模型实例字典
        self.models.clear()

        # 卸载所有命名实例
        self.unload_all_named_instances()

    def load_single_model(self, inference_id: str):
        """加载单个模型（公开方法，无YAML依赖）"""
        # 1. 检查模型是否已加载，若已加载则直接返回
        if inference_id in self.models:
            logger.info(f"模型[{inference_id}]已处于加载状态，无需重复加载")
            return

        # 2. 检查模型是否已注册
        if inference_id not in self.model_registry:
            raise ValueError(
                f"模型'{inference_id}'未注册，请检查是否在app.models中实现并通过@register_model注册"
            )

        # 3. 调用核心加载逻辑加载单个模型
        try:
            self._load_single_model(inference_id)
            logger.info(f"模型[{inference_id}]加载成功")
        except Exception as e:
            logger.error(f"模型[{inference_id}]加载失败：{e}")
            raise