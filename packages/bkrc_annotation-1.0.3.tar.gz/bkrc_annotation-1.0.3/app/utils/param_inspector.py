"""Utility module to inspect model class method signatures and generate API parameters."""

import inspect
from typing import Dict, Any, get_type_hints, List, Optional
from app.core.registry import _MODEL_REGISTRY


def get_method_signature(cls, method_name: str) -> Dict[str, Any]:
    """
    Get the signature of a method from a class.
    
    Args:
        cls: The class containing the method
        method_name: Name of the method to inspect
        
    Returns:
        Dictionary containing method signature information
    """
    if not hasattr(cls, method_name):
        return {}
    
    method = getattr(cls, method_name)
    sig = inspect.signature(method)
    
    # Get type hints - handle compatibility with older Python versions
    try:
        type_hints = get_type_hints(method, include_extras=True)
    except TypeError:
        # Fallback for older Python versions
        type_hints = get_type_hints(method)
    
    parameters = {}
    for param_name, param in sig.parameters.items():
        # Skip 'self' parameter
        if param_name == 'self':
            continue
            
        param_info = {
            'name': param_name,
            'kind': param.kind.name,
            'has_default': param.default != inspect.Parameter.empty,
            'default': param.default if param.default != inspect.Parameter.empty else None,
        }
        
        # Get type annotation
        if param_name in type_hints:
            param_info['annotation'] = str(type_hints[param_name])
        else:
            param_info['annotation'] = str(param.annotation) if param.annotation != inspect.Parameter.empty else 'Any'
            
        parameters[param_name] = param_info
    
    # Get return type annotation
    return_annotation = type_hints.get('return', 'Any') if 'return' in type_hints else 'Any'
    
    return {
        'method_name': method_name,
        'parameters': parameters,
        'return_annotation': str(return_annotation),
        'full_signature': str(sig)
    }


def get_model_load_params(model_class) -> Dict[str, Any]:
    """
    Get the expected parameters for a model's load method.
    
    Args:
        model_class: The model class to inspect
        
    Returns:
        Dictionary containing load method parameter information
    """
    return get_method_signature(model_class, 'load')


def get_model_predict_params(model_class) -> Dict[str, Any]:
    """
    Get the expected parameters for a model's predict method.
    
    Args:
        model_class: The model class to inspect
        
    Returns:
        Dictionary containing predict method parameter information
    """
    return get_method_signature(model_class, 'predict')


def get_model_required_params(model_class) -> Dict[str, Any]:
    """
    Get all required parameters for both load and predict methods of a model.
    
    Args:
        model_class: The model class to inspect
        
    Returns:
        Dictionary containing required parameters for the model
    """
    load_info = get_model_load_params(model_class)
    predict_info = get_model_predict_params(model_class)
    
    return {
        'model_class': model_class.__name__,
        'load_params': load_info,
        'predict_params': predict_info,
        'required_load_params': {
            name: info for name, info in load_info.get('parameters', {}).items()
            if not info['has_default']
        },
        'required_predict_params': {
            name: info for name, info in predict_info.get('parameters', {}).items()
            if not info['has_default']
        }
    }


def get_all_registered_models_params() -> Dict[str, Any]:
    """
    Get parameter information for all registered models.
    
    Returns:
        Dictionary containing parameter information for all registered models
    """
    # Trigger model registration by importing all model modules
    import app.models
    import pkgutil
    import importlib
    
    # Scan and import all model modules to ensure registration
    for importer, modname, ispkg in pkgutil.iter_modules(
            app.models.__path__,
            app.models.__name__ + "."
    ):
        if not ispkg and not modname.startswith("app.models._"):
            try:
                importlib.import_module(modname)
            except Exception as e:
                print(f"Warning: Failed to import model module {modname}: {e}")
    
    all_models_params = {}
    
    for inference_id, model_class in _MODEL_REGISTRY.items():
        try:
            model_params = get_model_required_params(model_class)
            all_models_params[inference_id] = model_params
        except Exception as e:
            print(f"Error getting parameters for model {inference_id}: {e}")
            continue
    
    return all_models_params


def generate_api_schema_from_model(model_class) -> Dict[str, Any]:
    """
    Generate API schema based on model class method signatures.
    
    Args:
        model_class: The model class to generate schema for
        
    Returns:
        Dictionary representing API schema for the model
    """
    # Get the load method signature for initialization parameters
    load_sig = get_method_signature(model_class, 'load')
    predict_sig = get_method_signature(model_class, 'predict')
    
    # Extract load parameters (for model initialization)
    load_parameters = []
    for param_name, param_info in load_sig.get('parameters', {}).items():
        if param_name != 'params':  # Skip the generic params dict
            continue
        # If params is Dict[str, Any], we can't specify exact parameters
        # But we can document that it accepts a params dict
        load_parameters.append({
            'name': param_name,
            'type': param_info['annotation'],
            'required': not param_info['has_default'],
            'default': param_info['default'],
            'description': 'Runtime parameters for model loading'
        })
    
    # Extract predict parameters (for inference)
    predict_parameters = []
    for param_name, param_info in predict_sig.get('parameters', {}).items():
        if param_name == 'image':
            predict_parameters.append({
                'name': param_name,
                'type': param_info['annotation'],
                'required': True,
                'description': 'Input image for inference'
            })
        elif param_name == 'params':
            predict_parameters.append({
                'name': param_name,
                'type': param_info['annotation'],
                'required': not param_info['has_default'],
                'default': param_info['default'],
                'description': 'Runtime parameters for inference (e.g., confidence threshold, IoU threshold)'
            })
    
    return {
        'model_name': model_class.__name__,
        'load_method': {
            'parameters': load_parameters,
            'description': f'Parameters for loading {model_class.__name__} model'
        },
        'predict_method': {
            'parameters': predict_parameters,
            'description': f'Parameters for predicting with {model_class.__name__} model'
        }
    }


def generate_openapi_spec_for_models() -> Dict[str, Any]:
    """
    Generate OpenAPI specification components for all registered models.
    
    Returns:
        Dictionary containing OpenAPI specification for models
    """
    models_params = get_all_registered_models_params()
    
    components = {
        "schemas": {}
    }
    
    for inference_id, model_info in models_params.items():
        # Generate schema for load parameters
        load_schema_name = f"{model_info['model_class']}LoadParams"
        components["schemas"][load_schema_name] = {
            "type": "object",
            "properties": {},
            "required": []
        }
        
        # Add load parameters to schema
        for param_name, param_info in model_info['load_params'].get('parameters', {}).items():
            if param_name == 'params':
                # Special handling for the params dict
                components["schemas"][load_schema_name]["properties"][param_name] = {
                    "type": "object",
                    "additionalProperties": True,
                    "description": "Runtime parameters for model loading"
                }
                if not param_info['has_default']:
                    components["schemas"][load_schema_name]["required"].append(param_name)
        
        # Generate schema for predict parameters
        predict_schema_name = f"{model_info['model_class']}PredictParams"
        components["schemas"][predict_schema_name] = {
            "type": "object",
            "properties": {},
            "required": ["image", "params"]  # image and params are typically required for prediction
        }
        
        # Add predict parameters to schema
        for param_name, param_info in model_info['predict_params'].get('parameters', {}).items():
            if param_name == 'image':
                components["schemas"][predict_schema_name]["properties"][param_name] = {
                    "type": "string",
                    "format": "binary",
                    "description": "Input image for inference"
                }
            elif param_name == 'params':
                components["schemas"][predict_schema_name]["properties"][param_name] = {
                    "type": "object",
                    "additionalProperties": True,
                    "description": "Runtime parameters for inference (e.g., confidence threshold, IoU threshold)"
                }
    
    return components


if __name__ == "__main__":
    # Example usage
    print("=== Testing Parameter Inspector ===")
    
    # Get all registered models
    models_params = get_all_registered_models_params()
    
    for inference_id, model_info in models_params.items():
        print(f"\nModel: {inference_id} ({model_info['model_class']})")
        print(f"Load method signature: {model_info['load_params'].get('full_signature', 'N/A')}")
        print(f"Predict method signature: {model_info['predict_params'].get('full_signature', 'N/A')}")
        
        # Show required load parameters
        required_load = model_info.get('required_load_params', {})
        if required_load:
            print(f"Required load parameters: {list(required_load.keys())}")
        else:
            print("Required load parameters: None (uses optional 'params' dict)")
            
        # Show required predict parameters
        required_predict = model_info.get('required_predict_params', {})
        if required_predict:
            print(f"Required predict parameters: {list(required_predict.keys())}")
        else:
            print("Required predict parameters: ['image', 'params']")
    
    # Generate OpenAPI spec
    print("\n=== Generated OpenAPI Components ===")
    openapi_components = generate_openapi_spec_for_models()
    print(f"Generated {len(openapi_components['schemas'])} schemas")