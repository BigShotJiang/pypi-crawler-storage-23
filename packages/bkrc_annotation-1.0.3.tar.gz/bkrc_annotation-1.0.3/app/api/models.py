from fastapi import APIRouter
from loguru import logger

from app.schemas.response import SuccessResponse, ErrorResponse, ErrorDetail

router = APIRouter()


@router.get("/v1/named-instances")
async def get_named_instances():
    """获取所有命名实例的信息。"""
    from app.main import loader

    try:
        instances_info = loader.list_named_instances()
        return SuccessResponse(data=instances_info)
    except Exception as e:
        logger.error(f"Failed to get named instances: {e}")
        return ErrorResponse(
            error=ErrorDetail(code="GET_NAMED_INSTANCES_ERROR", message=str(e))
        )


@router.delete("/v1/instances/{instance_name}")
async def unload_named_instance(instance_name: str):
    """卸载指定的命名模型实例。"""
    from app.main import loader

    try:
        # 查找所有匹配的实例
        instances_to_unload = []
        for (inference_id, name), model in loader.named_instances.items():
            if name == instance_name:
                instances_to_unload.append((inference_id, name))
        
        if not instances_to_unload:
            return ErrorResponse(
                error=ErrorDetail(code="INSTANCE_NOT_FOUND", message=f"未找到名称为 '{instance_name}' 的实例")
            )
        
        # 卸载找到的实例
        for inference_id, name in instances_to_unload:
            loader.unload_named_instance(inference_id, name)
        
        return SuccessResponse(
            data={"instance_name": instance_name, "status": "unloaded", "message": f"命名实例 '{instance_name}' 已卸载", "unloaded_count": len(instances_to_unload)}
        )
    except Exception as e:
        logger.error(f"Failed to unload named instance '{instance_name}': {e}")
        return ErrorResponse(
            error=ErrorDetail(code="UNLOAD_ERROR", message=str(e))
        )