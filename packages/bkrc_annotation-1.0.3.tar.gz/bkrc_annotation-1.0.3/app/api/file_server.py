"""文件服务器API模块，提供局域网文件共享和设备发现功能"""

import json
import os
import socket
import threading
import time
from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, HTTPException, UploadFile, File, Request, Form
from fastapi.responses import FileResponse
import uvicorn

router = APIRouter(prefix="/files", tags=["File Server"])

# ====================== 网络工具类 =======================
class NetworkUtils:
    """网络工具类"""

    @staticmethod
    def get_local_ip():
        """获取本机局域网IP"""
        try:
            # 方法1: 使用socket连接外部地址获取本机IP
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(('8.8.8.8', 80))
            ip = s.getsockname()[0]
            s.close()
            
            # 如果是本地回环地址，尝试其他方法
            if ip.startswith('127.') or ip.startswith('169.254.'):
                # 方法2: 尝试获取主机名对应的IP
                hostname = socket.gethostname()
                try:
                    # 获取所有与主机名关联的IP地址
                    addrs = socket.getaddrinfo(hostname, None)
                    for addr_info in addrs:
                        ip_addr = addr_info[4][0]  # 获取IP地址
                        if (ip_addr and 
                            not ip_addr.startswith('127.') and 
                            not ip_addr.startswith('169.254.') and 
                            not ip_addr.startswith('::')):
                            return ip_addr
                except:
                    pass
            
            return ip
        except Exception as e:
            print(f"获取本机IP失败: {e}")
            return "127.0.0.1"

    @staticmethod
    def get_network_prefix():
        """获取网络前缀"""
        local_ip = NetworkUtils.get_local_ip()
        parts = local_ip.split('.')
        if len(parts) >= 3:
            return f"{parts[0]}.{parts[1]}.{parts[2]}"
        return "192.168.1"


# ====================== TCP程序IP探测工具 =======================
class DirectDetector:
    """TCP程序IP探测工具 - 直接探测运行本程序的设备"""

    def __init__(self, port=8888):
        self.port = port
        self.server_socket = None
        self.running = True
        self.is_scanning = False
        self.stop_flag = threading.Event()

        # 启动TCP监听（用于响应探测请求）
        self.start_tcp_server()

    def start_tcp_server(self):
        """启动极简TCP服务端，仅响应TEST_PING探测"""

        def tcp_listen():
            self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.server_socket.bind(('', self.port))
            self.server_socket.listen(5)  # 增加监听数，适配多并发探测

            while self.running:
                try:
                    self.server_socket.settimeout(1.0)
                    conn, _ = self.server_socket.accept()
                    # 仅处理探测消息，不处理普通消息
                    self.handle_detection(conn)
                except socket.timeout:
                    continue
                except Exception:
                    continue

        # 后台线程运行监听
        threading.Thread(target=tcp_listen, daemon=True).start()

    def handle_detection(self, conn):
        """仅处理探测握手，忽略其他消息"""
        try:
            data = conn.recv(1024)
            if data.decode('utf-8') == "TEST_PING":
                conn.sendall("TEST_PONG".encode('utf-8'))
            conn.close()
        except:
            conn.close()

    def stop(self):
        """停止探测服务"""
        self.running = False
        self.stop_scan()
        if self.server_socket:
            self.server_socket.close()

    def stop_scan(self):
        """停止扫描"""
        if self.is_scanning:
            self.stop_flag.set()
            self.is_scanning = False


# ====================== 设备发现服务器 =======================
class DeviceDiscoveryServer:
    """设备发现服务器"""

    def __init__(self, device_name="图像标注工具后端服务", port=54321):
        self.device_name = device_name
        self.port = port
        self.running = False
        self.thread = None
        self.server_socket = None

        self.DISCOVERY_MAGIC = b"ANNOTATION_TOOL_DISCOVERY_v2.0"
        self.RESPONSE_MAGIC = b"ANNOTATION_TOOL_RESPONSE_v2.0"
        self.APP_IDENTIFIER = "annotation_tool_server_v2"

    def start(self):
        """启动服务器"""
        if self.running:
            return

        self.running = True
        self.thread = threading.Thread(target=self._run_server, daemon=True)
        self.thread.start()
        print(f"设备发现服务器启动，端口: {self.port}")

    def stop(self):
        """停止服务器"""
        self.running = False
        if self.server_socket:
            try:
                self.server_socket.close()
            except:
                pass
        if self.thread:
            self.thread.join(timeout=2)

    def _run_server(self):
        """运行服务器线程"""
        try:
            self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            self.server_socket.bind(('0.0.0.0', self.port))
            self.server_socket.settimeout(1)

            while self.running:
                try:
                    data, addr = self.server_socket.recvfrom(1024)
                    if data.startswith(self.DISCOVERY_MAGIC):
                        # 验证应用程序标识
                        received_identifier = data[
                            len(self.DISCOVERY_MAGIC):len(self.DISCOVERY_MAGIC) + len(self.APP_IDENTIFIER)]
                        if received_identifier.decode() == self.APP_IDENTIFIER:
                            response_info = {
                                "app": self.APP_IDENTIFIER,
                                "name": self.device_name,
                                "type": "annotation_tool_server",
                                "hostname": socket.gethostname(),
                                "ip": NetworkUtils.get_local_ip(),
                                "port": 8000,  # 使用主服务端口
                                "timestamp": datetime.now().isoformat(),
                                "version": "1.0.0"
                            }
                            response = self.RESPONSE_MAGIC + self.APP_IDENTIFIER.encode() + json.dumps(
                                response_info).encode()
                            self.server_socket.sendto(response, addr)
                except socket.timeout:
                    continue
                except Exception as e:
                    if self.running:
                        pass
        except Exception as e:
            print(f"设备发现服务器错误: {e}")
        finally:
            if self.server_socket:
                try:
                    self.server_socket.close()
                except:
                    pass


# 全局变量用于存储当前文件夹和服务器组件
current_folder = ""
client_name = "标注工具后端服务"

# 初始化探测器和设备发现服务
direct_detector = DirectDetector(port=8888)
device_discovery = DeviceDiscoveryServer(port=54321)
device_discovery.start()


@router.get("/")
async def root():
    """获取服务器基本信息"""
    return {
        "message": "图像标注工具文件服务器",
        "status": "running",
        "version": "1.0.0",
        "client_name": client_name,
        "local_ip": NetworkUtils.get_local_ip()
    }


@router.get("/status")
async def get_status():
    """获取服务器状态"""
    folder_info = "未设置文件夹"
    if current_folder:
        folder_info = current_folder
        try:
            file_count = len([f for f in os.listdir(current_folder) if
                              os.path.isfile(os.path.join(current_folder, f))])
        except:
            file_count = 0
    else:
        file_count = 0

    return {
        "folder": folder_info,
        "file_count": file_count,
        "status": "online",
        "local_ip": NetworkUtils.get_local_ip(),
        "client_name": client_name,
        "version": "1.0.0",
        "tcp_detector_port": 8888,
        "discovery_port": 54321
    }


@router.get("/list")
async def list_files():
    """列出当前文件夹的所有文件"""
    if not current_folder:
        raise HTTPException(status_code=404, detail="未打开文件夹")

    files = []
    try:
        for file in os.listdir(current_folder):
            file_path = os.path.join(current_folder, file)
            if os.path.isfile(file_path):
                try:
                    file_info = {
                        "name": file,
                        "path": file_path,
                        "size": os.path.getsize(file_path),
                        "type": "image" if file.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.gif',
                                                                  '.tiff')) else "annotation" if file.lower().endswith(
                            '.json') else "other",
                        "is_local": True
                    }
                    files.append(file_info)
                except Exception as e:
                    print(f"获取文件信息失败 {file_path}: {e}")

        return {"current_folder": current_folder, "files": files}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"读取文件夹失败: {str(e)}")


@router.get("/{filename}")
async def get_file(filename: str):
    """获取指定文件"""
    if not current_folder:
        raise HTTPException(status_code=404, detail="未打开文件夹")

    file_path = os.path.join(current_folder, filename)
    if os.path.exists(file_path) and os.path.isfile(file_path):
        try:
            return FileResponse(file_path, filename=filename)
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"文件读取失败: {str(e)}")

    raise HTTPException(status_code=404, detail="文件未找到")


@router.post("/upload/{filename}")
async def upload_file(
        request: Request,
        filename: str,
        file: UploadFile = File(...)
):
    """接收其他客户端上传的文件"""
    global current_folder
    if not current_folder:
        raise HTTPException(status_code=404, detail="未打开文件夹")

    try:
        # 从表单数据中获取额外参数
        form_data = await request.form()
        client_ip = form_data.get("client_ip", "")
        client_name = form_data.get("client_name", "未知客户端")
        overwrite_str = form_data.get("overwrite", "true")
        overwrite = overwrite_str.lower() == "true"

        if not client_ip:
            if request.client:
                client_ip = request.client.host
            else:
                client_ip = "未知IP"

        safe_filename = os.path.basename(filename)
        save_path = os.path.join(current_folder, safe_filename)

        file_exists = os.path.exists(save_path)

        if file_exists:
            if overwrite:
                pass  # 覆盖现有文件
            else:
                # 生成新文件名避免冲突
                base_name, ext = os.path.splitext(safe_filename)
                counter = 1
                while os.path.exists(save_path):
                    safe_filename = f"{base_name}_{counter}{ext}"
                    save_path = os.path.join(current_folder, safe_filename)
                    counter += 1

        os.makedirs(os.path.dirname(save_path), exist_ok=True)

        with open(save_path, "wb") as buffer:
            while True:
                chunk = await file.read(1024 * 1024)
                if not chunk:
                    break
                buffer.write(chunk)

        file_info = {
            "name": safe_filename,
            "path": save_path,
            "size": os.path.getsize(save_path),
            "from_ip": client_ip,
            "from_name": client_name,
            "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "type": "image" if safe_filename.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.gif',
                                                               '.tiff')) else "annotation" if safe_filename.lower().endswith(
                '.json') else "other",
            "overwritten": file_exists and overwrite
        }

        print(f"文件接收成功: {safe_filename} from {client_ip} ({client_name})")

        return {
            "message": f"文件 {safe_filename} 接收成功",
            "path": save_path,
            "status": "success",
            "overwritten": file_exists and overwrite
        }
    except Exception as e:
        error_msg = f"接收文件失败: {str(e)}"
        print(error_msg)
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=error_msg)


@router.post("/reverse_transfer")
async def reverse_transfer(request: Request):
    """接收回传请求"""
    try:
        form_data = await request.form()
        files_json = form_data.get('files')
        target_ip = form_data.get('target_ip')
        target_port = form_data.get('target_port')
        request_time = form_data.get('request_time')

        if not files_json or not target_ip:
            raise HTTPException(status_code=400, detail="缺少必要参数")

        files = json.loads(files_json)

        request_info = {
            'files': files,
            'target_ip': target_ip,
            'target_port': int(target_port) if target_port else 8000,
            'request_time': request_time,
            'source_ip': request.client.host if request.client else '未知IP'
        }

        print(f"收到回传请求: {request_info}")

        return {
            "message": "回传请求已接收",
            "files_count": len(files),
            "target": f"{target_ip}:{target_port}",
            "status": "processing"
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"处理回传请求失败: {str(e)}")


@router.post("/set_folder")
async def set_folder(folder_path: str):
    """设置当前文件夹"""
    global current_folder
    if not os.path.exists(folder_path):
        raise HTTPException(status_code=404, detail="文件夹不存在")

    if not os.path.isdir(folder_path):
        raise HTTPException(status_code=400, detail="路径不是文件夹")

    current_folder = os.path.normpath(folder_path)
    print(f"服务器文件夹设置为: {current_folder}")

    return {
        "message": "文件夹设置成功",
        "folder": current_folder,
        "status": "success"
    }


@router.get("/network_info")
async def get_network_info():
    """获取网络信息"""
    return {
        "local_ip": NetworkUtils.get_local_ip(),
        "network_prefix": NetworkUtils.get_network_prefix(),
        "tcp_detector_port": 8888,
        "discovery_port": 54321
    }


@router.post("/detect_network")
async def detect_network(network: str):
    """探测网络中的设备"""
    try:
        # 解析网段
        if "/" in network:
            prefix = network.split("/")[0].rsplit(".", 1)[0]
            ips = [f"{prefix}.{i}" for i in range(1, 255)]
        elif "-" in network:
            prefix = network.split("-")[0].rsplit(".", 1)[0]
            start, end = network.split("-")[0].rsplit(".", 1)[1], network.split("-")[1]
            ips = [f"{prefix}.{i}" for i in range(int(start), int(end) + 1)]
        else:
            ips = [network]

        results = []
        for ip in ips:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(1.0)
                result = sock.connect_ex((ip, 8888))
                sock.close()

                if result == 0:
                    # 检查是否是本程序
                    try:
                        sock2 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                        sock2.settimeout(1.0)
                        sock2.connect((ip, 8888))
                        sock2.sendall("TEST_PING".encode('utf-8'))
                        response = sock2.recv(1024)
                        sock2.close()

                        if response.decode('utf-8') == "TEST_PONG":
                            results.append({
                                "ip": ip,
                                "status": "online",
                                "type": "annotation_tool"
                            })
                        else:
                            results.append({
                                "ip": ip,
                                "status": "online",
                                "type": "unknown"
                            })
                    except:
                        results.append({
                            "ip": ip,
                            "status": "online",
                            "type": "unknown"
                        })
            except:
                continue

        return {
            "network": network,
            "results": results,
            "count": len(results)
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"探测网络失败: {str(e)}")


# ==================== 以下是与原端点兼容的路由 ====================
# 这些路由直接注册到根路径，以便与旧版客户端兼容

from fastapi import FastAPI

# 创建一个额外的路由器用于与原端点兼容
compat_router = APIRouter()

@compat_router.get("/")
async def compat_root():
    """兼容旧版客户端的根路径"""
    return {
        "message": "图像标注工具文件服务器",
        "status": "running",
        "version": "1.0.0",
        "client_name": client_name,
        "local_ip": NetworkUtils.get_local_ip()
    }

@compat_router.get("/status")
async def compat_get_status():
    """兼容旧版客户端的状态查询"""
    folder_info = "未设置文件夹"
    if current_folder:
        folder_info = current_folder
        try:
            file_count = len([f for f in os.listdir(current_folder) if
                              os.path.isfile(os.path.join(current_folder, f))])
        except:
            file_count = 0
    else:
        file_count = 0

    return {
        "host": "0.0.0.0",
        "port": 8000,
        "folder": folder_info,
        "file_count": file_count,
        "status": "online",
        "local_ip": NetworkUtils.get_local_ip(),
        "client_name": client_name,
        "version": "1.0.0",
        "tcp_detector_port": 8888,
        "discovery_port": 54321
    }

@compat_router.get("/files")
async def compat_list_files():
    """兼容旧版客户端的文件列表"""
    if not current_folder:
        raise HTTPException(status_code=404, detail="未打开文件夹")

    files = []
    try:
        for file in os.listdir(current_folder):
            file_path = os.path.join(current_folder, file)
            if os.path.isfile(file_path):
                try:
                    file_info = {
                        "name": file,
                        "path": file_path,
                        "size": os.path.getsize(file_path),
                        "type": "image" if file.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.gif',
                                                                  '.tiff')) else "annotation" if file.lower().endswith(
                            '.json') else "other",
                        "is_local": True
                    }
                    files.append(file_info)
                except Exception as e:
                    print(f"获取文件信息失败 {file_path}: {e}")

        return {"current_folder": current_folder, "files": files}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"读取文件夹失败: {str(e)}")

@compat_router.get("/file/{filename}")
async def compat_get_file(filename: str):
    """兼容旧版客户端的文件获取"""
    if not current_folder:
        raise HTTPException(status_code=404, detail="未打开文件夹")

    file_path = os.path.join(current_folder, filename)
    if os.path.exists(file_path) and os.path.isfile(file_path):
        try:
            return FileResponse(file_path, filename=filename)
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"文件读取失败: {str(e)}")

    raise HTTPException(status_code=404, detail="文件未找到")

@compat_router.post("/upload/{filename}")
async def compat_upload_file(
        request: Request,
        filename: str,
        file: UploadFile = File(...)
):
    """兼容旧版客户端的文件上传"""
    global current_folder
    if not current_folder:
        raise HTTPException(status_code=404, detail="未打开文件夹")

    try:
        # 从表单数据中获取额外参数
        form_data = await request.form()
        client_ip = form_data.get("client_ip", "")
        client_name = form_data.get("client_name", "未知客户端")
        overwrite_str = form_data.get("overwrite", "true")
        overwrite = overwrite_str.lower() == "true"

        if not client_ip:
            if request.client:
                client_ip = request.client.host
            else:
                client_ip = "未知IP"

        safe_filename = os.path.basename(filename)
        save_path = os.path.join(current_folder, safe_filename)

        file_exists = os.path.exists(save_path)

        if file_exists:
            if overwrite:
                pass  # 覆盖现有文件
            else:
                # 生成新文件名避免冲突
                base_name, ext = os.path.splitext(safe_filename)
                counter = 1
                while os.path.exists(save_path):
                    safe_filename = f"{base_name}_{counter}{ext}"
                    save_path = os.path.join(current_folder, safe_filename)
                    counter += 1

        os.makedirs(os.path.dirname(save_path), exist_ok=True)

        with open(save_path, "wb") as buffer:
            while True:
                chunk = await file.read(1024 * 1024)
                if not chunk:
                    break
                buffer.write(chunk)

        file_info = {
            "name": safe_filename,
            "path": save_path,
            "size": os.path.getsize(save_path),
            "from_ip": client_ip,
            "from_name": client_name,
            "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "type": "image" if safe_filename.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.gif',
                                                               '.tiff')) else "annotation" if safe_filename.lower().endswith(
                '.json') else "other",
            "overwritten": file_exists and overwrite
        }

        print(f"文件接收成功: {safe_filename} from {client_ip} ({client_name})")

        return {
            "message": f"文件 {safe_filename} 接收成功",
            "path": save_path,
            "status": "success",
            "overwritten": file_exists and overwrite
        }
    except Exception as e:
        error_msg = f"接收文件失败: {str(e)}"
        print(error_msg)
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=error_msg)

@compat_router.post("/reverse_transfer")
async def compat_reverse_transfer(request: Request):
    """兼容旧版客户端的回传请求"""
    try:
        form_data = await request.form()
        files_json = form_data.get('files')
        target_ip = form_data.get('target_ip')
        target_port = form_data.get('target_port')
        request_time = form_data.get('request_time')

        if not files_json or not target_ip:
            raise HTTPException(status_code=400, detail="缺少必要参数")

        files = json.loads(files_json)

        request_info = {
            'files': files,
            'target_ip': target_ip,
            'target_port': int(target_port) if target_port else 8000,
            'request_time': request_time,
            'source_ip': request.client.host if request.client else '未知IP'
        }

        print(f"收到回传请求: {request_info}")

        return {
            "message": "回传请求已接收",
            "files_count": len(files),
            "target": f"{target_ip}:{target_port}",
            "status": "processing"
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"处理回传请求失败: {str(e)}")

@compat_router.post("/set_folder")
async def compat_set_folder(folder_path: str):
    """兼容旧版客户端的文件夹设置"""
    global current_folder
    if not os.path.exists(folder_path):
        raise HTTPException(status_code=404, detail="文件夹不存在")

    if not os.path.isdir(folder_path):
        raise HTTPException(status_code=400, detail="路径不是文件夹")

    current_folder = os.path.normpath(folder_path)
    print(f"服务器文件夹设置为: {current_folder}")

    return {
        "message": "文件夹设置成功",
        "folder": current_folder,
        "status": "success"
    }

@compat_router.get("/network_info")
async def compat_get_network_info():
    """兼容旧版客户端的网络信息"""
    return {
        "local_ip": NetworkUtils.get_local_ip(),
        "network_prefix": NetworkUtils.get_network_prefix(),
        "host": "0.0.0.0",
        "port": 8000,
        "tcp_detector_port": 8888,
        "discovery_port": 54321
    }

@compat_router.post("/detect_network")
async def compat_detect_network(network: str):
    """兼容旧版客户端的网络探测"""
    try:
        # 解析网段
        if "/" in network:
            prefix = network.split("/")[0].rsplit(".", 1)[0]
            ips = [f"{prefix}.{i}" for i in range(1, 255)]
        elif "-" in network:
            prefix = network.split("-")[0].rsplit(".", 1)[0]
            start, end = network.split("-")[0].rsplit(".", 1)[1], network.split("-")[1]
            ips = [f"{prefix}.{i}" for i in range(int(start), int(end) + 1)]
        else:
            ips = [network]

        results = []
        for ip in ips:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(1.0)
                result = sock.connect_ex((ip, 8888))
                sock.close()

                if result == 0:
                    # 检查是否是本程序
                    try:
                        sock2 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                        sock2.settimeout(1.0)
                        sock2.connect((ip, 8888))
                        sock2.sendall("TEST_PING".encode('utf-8'))
                        response = sock2.recv(1024)
                        sock2.close()

                        if response.decode('utf-8') == "TEST_PONG":
                            results.append({
                                "ip": ip,
                                "status": "online",
                                "type": "annotation_tool"
                            })
                        else:
                            results.append({
                                "ip": ip,
                                "status": "online",
                                "type": "unknown"
                            })
                    except:
                        results.append({
                            "ip": ip,
                            "status": "online",
                            "type": "unknown"
                        })
            except:
                continue

        return {
            "network": network,
            "results": results,
            "count": len(results)
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"探测网络失败: {str(e)}")


def register_compatibility_routes(app: FastAPI):
    """注册与原端点兼容的路由"""
    app.include_router(compat_router)


def cleanup_servers():
    """清理服务器资源"""
    direct_detector.stop()
    device_discovery.stop()