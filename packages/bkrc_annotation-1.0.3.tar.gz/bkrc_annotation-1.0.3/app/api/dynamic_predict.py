"""Dynamic API generator that creates model-specific endpoints based on method signatures."""

import inspect
from typing import Dict, Any, get_type_hints, Union, get_origin, get_args
from fastapi import APIRouter, HTTPException, status, Depends
import base64
import cv2
import numpy as np
from loguru import logger
from pydantic import BaseModel, create_model

from app.schemas.response import (
    ErrorDetail,
    ErrorResponse,
    PredictResponse,
    SuccessResponse,
)
from app.utils.param_inspector import get_all_registered_models_params


def create_dynamic_model_apis():
    """Create dynamic API routes for all registered models based on their method signatures."""
    router = APIRouter()
    
    # Get all registered models and their parameter signatures
    models_params = get_all_registered_models_params()
    
    for inference_id, model_info in models_params.items():
        # Create a dynamic endpoint for each model
        create_model_endpoint(router, inference_id, model_info)
    
    return router


def create_model_endpoint(router: APIRouter, inference_id: str, model_info: Dict[str, Any]):
    """Create a specific endpoint for a model based on its __init__ parameters."""
    
    # Get the model class to inspect its __init__ method
    from app.core.registry import ModelRegistry
    registry = ModelRegistry()
    model_class = registry.model_registry.get(inference_id)
    
    if model_class is None:
        logger.error(f"Model {inference_id} not found in registry")
        return
    
    # Use inspect to get the __init__ method signature
    init_sig = inspect.signature(model_class.__init__)
    
    # Dynamically create a request model specific to this model
    # Only include parameters from the __init__ method (excluding 'self')
    field_definitions = {}
    
    # Add parameters from the __init__ method signature (excluding 'self')
    for param_name, param in init_sig.parameters.items():
        if param_name != 'self':  # Exclude 'self' parameter
            # Try to infer type from default value if no annotation exists
            if param.annotation != inspect.Parameter.empty:
                param_type = param.annotation
            else:
                # Infer type from default value
                default_val = param.default
                if default_val is None:
                    param_type = str  # Default to string for None values
                elif isinstance(default_val, bool):
                    param_type = bool
                elif isinstance(default_val, int):
                    param_type = int
                elif isinstance(default_val, float):
                    param_type = float
                elif isinstance(default_val, list):
                    param_type = list
                elif isinstance(default_val, dict):
                    param_type = dict
                elif isinstance(default_val, str):
                    param_type = str
                else:
                    param_type = str  # Default fallback
            
            # Handle common type annotations
            if param_type == str or (hasattr(param_type, '__name__') and param_type.__name__ == 'str') or 'str' in str(param_type).lower():
                field_type = str
            elif param_type == int or (hasattr(param_type, '__name__') and param_type.__name__ == 'int') or 'int' in str(param_type).lower():
                field_type = int
            elif param_type == float or (hasattr(param_type, '__name__') and param_type.__name__ == 'float') or 'float' in str(param_type).lower():
                field_type = float
            elif param_type == bool or (hasattr(param_type, '__name__') and param_type.__name__ == 'bool') or 'bool' in str(param_type).lower():
                field_type = bool
            elif param_type == list or (hasattr(param_type, '__name__') and param_type.__name__ == 'list') or 'list' in str(param_type).lower():
                field_type = list
            elif param_type == dict or (hasattr(param_type, '__name__') and param_type.__name__ == 'dict') or 'dict' in str(param_type).lower():
                field_type = dict
            else:
                field_type = Any  # Use Any for unknown types
            
            # Determine if parameter has a default value
            if param.default != inspect.Parameter.empty:
                field_definitions[param_name] = (field_type, param.default)
            else:
                field_definitions[param_name] = (field_type, ...)  # Required parameter
    
    # Add image as a required parameter since it's needed for all prediction
    field_definitions["image"] = (str, ...)
    
    # Add instance_name as an optional parameter to support named model instances
    field_definitions["instance_name"] = (str, None)
    
    # Create the dynamic model class
    # Replace problematic characters in model name
    clean_inference_id = inference_id.replace('-', '_').replace('.', '_').replace(':', '_').replace('/', '_').replace('\\', '_')
    dynamic_request_model = create_model(
        f"{clean_inference_id}_predict_request",
        **field_definitions
    )
    
    async def model_specific_predict(request: dynamic_request_model):
        """Dynamically generated predict endpoint for a specific model."""
        from app.main import loader, inference_executor

        # Convert the dynamic request model to the standard format
        # Extract image
        image_field_value = request.image
        
        # Extract all other parameters and combine them into a single params dict
        request_dict = request.dict()
        # Remove image from the dict to use as params
        params = {k: v for k, v in request_dict.items() if k != 'image'}
        
        # Decode image
        try:
            image_data = (
                image_field_value.split(",")[1]
                if "," in image_field_value
                else image_field_value
            )
            image_bytes = base64.b64decode(image_data)
            nparr = np.frombuffer(image_bytes, np.uint8)
            image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

            if image is None:
                return ErrorResponse(
                    error=ErrorDetail(
                        code="INVALID_IMAGE", message="Failed to decode image"
                    )
                )
        except Exception as e:
            logger.error(f"Image decoding error: {e}")
            return ErrorResponse(
                error=ErrorDetail(
                    code="INVALID_IMAGE",
                    message=f"Failed to decode image: {str(e)}",
                )
            )

        try:
            # Execute inference with the model
            result = await inference_executor.execute(
                inference_id, image, params  # Use the inference_id from closure instead of request.model
            )
            return SuccessResponse(data=PredictResponse(**result))
        except RuntimeError as e:
            if "queue is full" in str(e).lower():
                raise HTTPException(
                    status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                    detail="Task queue is full, please try again later",
                )
            raise
        except Exception as e:
            logger.error(f"Inference error for model {inference_id}: {e}")
            return ErrorResponse(
                error=ErrorDetail(code="INFERENCE_ERROR", message=str(e))
            )
    
    # Set the function name and docstring dynamically
    model_specific_predict.__name__ = f"predict_{inference_id.replace('-', '_').replace('.', '_')}"
    model_specific_predict.__doc__ = f"Execute prediction using the {inference_id} model."
    
    # Add the route to the router
    router.add_api_route(
        f"/v1/predict/{inference_id}",
        model_specific_predict,
        methods=["POST"],
        summary=f"Predict with {inference_id} model",
        description=f"Dedicated endpoint for the {inference_id} model. "
                   f"Accepts image and parameters as defined by the model's __init__ method.",
        response_model=SuccessResponse,
        # Add the dynamic body field info to the endpoint
        openapi_extra={
            "requestBody": {
                "content": {
                    "application/json": {
                        "schema": dynamic_request_model.schema()
                    }
                }
            }
        }
    )


def create_model_info_endpoint():
    """Create an endpoint that returns parameter information for all models."""
    router = APIRouter()
    
    @router.get("/v1/model-params-info")
    async def get_model_params_info():
        """Get parameter signature information for all registered models."""
        try:
            models_params = get_all_registered_models_params()
            
            # Format the information for API response
            formatted_info = {}
            for inference_id, model_info in models_params.items():
                formatted_info[inference_id] = {
                    "model_class": model_info["model_class"],
                    "load_method": {
                        "signature": model_info["load_params"].get("full_signature", ""),
                        "parameters": {
                            name: {
                                "type": param_info["annotation"],
                                "required": not param_info["has_default"],
                                "default": param_info["default"] if param_info["has_default"] else None
                            }
                            for name, param_info in model_info["load_params"].get("parameters", {}).items()
                        }
                    },
                    "predict_method": {
                        "signature": model_info["predict_params"].get("full_signature", ""),
                        "parameters": {
                            name: {
                                "type": param_info["annotation"],
                                "required": not param_info["has_default"],
                                "default": param_info["default"] if param_info["has_default"] else None
                            }
                            for name, param_info in model_info["predict_params"].get("parameters", {}).items()
                        }
                    }
                }
            
            return SuccessResponse(data=formatted_info)
        except Exception as e:
            logger.error(f"Failed to get model params info: {e}")
            return ErrorResponse(
                error=ErrorDetail(code="MODEL_PARAMS_INFO_ERROR", message=str(e))
            )
    
    return router


# Create the routers
dynamic_router = create_dynamic_model_apis()
info_router = create_model_info_endpoint()


# Also create a combined router that includes both
combined_router = APIRouter()

# Include all dynamic model routes
for route in dynamic_router.routes:
    combined_router.routes.append(route)

# Include the info route
for route in info_router.routes:
    combined_router.routes.append(route)


def get_dynamic_apis():
    """Get the combined router with all dynamic APIs."""
    return combined_router