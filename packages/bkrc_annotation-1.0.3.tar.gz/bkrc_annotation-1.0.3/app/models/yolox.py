import numpy as np
from typing import Any, Dict

from app.schemas.shape import Shape
from app.core.registry import register_model
import os
import onnx
import onnxruntime as ort
import cv2


class OnnxBaseModel:
    def __init__(
            self, model_path, device_type: str = "cpu", log_severity_level: int = 3
    ):
        self.sess_opts = ort.SessionOptions()
        self.sess_opts.log_severity_level = log_severity_level
        if "OMP_NUM_THREADS" in os.environ:
            self.sess_opts.inter_op_num_threads = int(
                os.environ["OMP_NUM_THREADS"]
            )

        self.providers = ["CPUExecutionProvider"]
        if device_type.lower() == "gpu":
            self.providers = ["CUDAExecutionProvider"]

        self.ort_session = ort.InferenceSession(
            model_path,
            providers=self.providers,
            sess_options=self.sess_opts,
        )
        self.model_path = model_path

    def get_ort_inference(
            self, blob=None, inputs=None, extract=True, squeeze=False
    ):
        if inputs is None:
            inputs = self.get_input_name()
            outs = self.ort_session.run(None, {inputs: blob})
        else:
            outs = self.ort_session.run(None, inputs)
        if extract:
            outs = outs[0]
        if squeeze:
            outs = outs.squeeze(axis=0)
        return outs

    def get_input_name(self):
        return self.ort_session.get_inputs()[0].name

    def get_input_shape(self):
        return self.ort_session.get_inputs()[0].shape

    def get_output_name(self):
        return [out.name for out in self.ort_session.get_outputs()]

    def get_metadata_info(self, field):
        model = onnx.load(self.model_path)
        metadata = model.metadata_props
        for prop in metadata:
            if prop.key == field:
                return prop.value
        return None


@register_model("yolox_nano","my_yolox")
class YOLOXDetection:
    """YOLOX object detection model without inheriting from BaseModel."""

    def __init__(self, model_abs_path=None, p6=False, classes=[], nms_threshold=0.45, conf_threshold=0.25, replace=True):
        self._is_loaded = False  # 新增：标记模型是否已加载
        self.model = None  # 初始化模型变量
        self.model_abs_path = model_abs_path
        self.p6 = p6
        self.classes = classes
        self.nms_thres = nms_threshold
        self.conf_thres = conf_threshold
        self.net = None
        self.input_shape = None
        self.replace = replace

    def load(self, params: Dict[str, Any] = None):
        if params is None:
            params = {}
        
        # 完全依赖运行时参数，移除对静态配置的依赖
        self.model_abs_path = params.get("model_abs_path")
        self.p6 = params.get("p6", False)
        self.classes = params.get("classes", [])
        self.nms_thres = params.get("nms_threshold", 0.45)
        self.conf_thres = params.get("conf_threshold", 0.25)
        
        if not self.model_abs_path:
            raise ValueError("model_abs_path is required for YOLOX model")

        self.net = OnnxBaseModel(self.model_abs_path, params.get("device_type", ""))
        self.input_shape = self.net.get_input_shape()[-2:]

        # ========== 虚拟图测试 ==========
        full_input_shape = self.net.get_input_shape()
        dummy_img = np.zeros(full_input_shape, dtype=np.float32)

        try:
            dummy_output = self.net.get_ort_inference(blob=dummy_img)
            print(f"✅ 虚拟图测试成功！模型输入形状：{full_input_shape}，输出形状：{dummy_output.shape}")
        except Exception as e:
            print(f"❌ 虚拟图测试失败：{str(e)}")
            raise

        self.replace = True
        self._is_loaded = True  # 标记为已加载
        print("yolox模型加载成功")

    def preprocess(self, input_image):
        """
        Pre-process the input RGB image before feeding it to the network.
        """
        if len(input_image.shape) == 3:
            padded_img = (
                    np.ones(
                        (self.input_shape[0], self.input_shape[1], 3),
                        dtype=np.uint8,
                    )
                    * 114
            )
        else:
            padded_img = np.ones(self.input_shape, dtype=np.uint8) * 114

        ratio_hw = min(
            self.input_shape[0] / input_image.shape[0],
            self.input_shape[1] / input_image.shape[1],
        )
        resized_img = cv2.resize(
            input_image,
            (
                int(input_image.shape[1] * ratio_hw),
                int(input_image.shape[0] * ratio_hw),
            ),
            interpolation=cv2.INTER_LINEAR,
        ).astype(np.uint8)
        padded_img[
            : int(input_image.shape[0] * ratio_hw),
            : int(input_image.shape[1] * ratio_hw),
        ] = resized_img

        padded_img = padded_img.transpose((2, 0, 1))
        padded_img = np.ascontiguousarray(padded_img, dtype=np.float32)
        return padded_img[None, :, :, :], ratio_hw

    def postprocess(self, outputs):
        """
        Post-process the network's output.
        """
        grids = []
        expanded_strides = []
        p6 = self.p6
        img_size = self.input_shape
        strides = [8, 16, 32] if not p6 else [8, 16, 32, 64]

        hsizes = [img_size[0] // stride for stride in strides]
        wsizes = [img_size[1] // stride for stride in strides]

        for hsize, wsize, stride in zip(hsizes, wsizes, strides):
            xv, yv = np.meshgrid(np.arange(wsize), np.arange(hsize))
            grid = np.stack((xv, yv), 2).reshape(1, -1, 2)
            grids.append(grid)
            shape = grid.shape[:2]
            expanded_strides.append(np.full((*shape, 1), stride))

        grids = np.concatenate(grids, 1)
        expanded_strides = np.concatenate(expanded_strides, 1)
        outputs[..., :2] = (outputs[..., :2] + grids) * expanded_strides
        outputs[..., 2:4] = np.exp(outputs[..., 2:4]) * expanded_strides

        return outputs

    def rescale(self, predictions, ratio):
        """Rescale the output to the original image shape"""
        nms_thr = self.nms_thres
        score_thr = self.conf_thres

        boxes = predictions[:, :4]
        scores = predictions[:, 4:5] * predictions[:, 5:]

        boxes_xyxy = np.ones_like(boxes)
        boxes_xyxy[:, 0] = boxes[:, 0] - boxes[:, 2] / 2.0
        boxes_xyxy[:, 1] = boxes[:, 1] - boxes[:, 3] / 2.0
        boxes_xyxy[:, 2] = boxes[:, 0] + boxes[:, 2] / 2.0
        boxes_xyxy[:, 3] = boxes[:, 1] + boxes[:, 3] / 2.0
        boxes_xyxy /= ratio
        dets = self.multiclass_nms_class_agnostic(
            boxes_xyxy, scores, nms_thr=nms_thr, score_thr=score_thr
        )

        return dets

    def multiclass_nms_class_agnostic(self, boxes, scores, nms_thr, score_thr):
        """Multiclass NMS implemented in Numpy. Class-agnostic version."""
        cls_inds = scores.argmax(1)
        cls_scores = scores[np.arange(len(cls_inds)), cls_inds]

        valid_score_mask = cls_scores > score_thr
        if valid_score_mask.sum() == 0:
            return None
        valid_scores = cls_scores[valid_score_mask]
        valid_boxes = boxes[valid_score_mask]
        valid_cls_inds = cls_inds[valid_score_mask]
        keep = self.nms(valid_boxes, valid_scores, nms_thr)
        if keep:
            dets = np.concatenate(
                [
                    valid_boxes[keep],
                    valid_scores[keep, None],
                    valid_cls_inds[keep, None],
                ],
                1,
            )
            return dets
        return None

    @staticmethod
    def nms(boxes, scores, nms_thr):
        """Single class NMS implemented in Numpy."""
        x1 = boxes[:, 0]
        y1 = boxes[:, 1]
        x2 = boxes[:, 2]
        y2 = boxes[:, 3]

        areas = (x2 - x1 + 1) * (y2 - y1 + 1)
        order = scores.argsort()[::-1]

        keep = []
        while order.size > 0:
            i = order[0]
            keep.append(i)
            xx1 = np.maximum(x1[i], x1[order[1:]])
            yy1 = np.maximum(y1[i], y1[order[1:]])
            xx2 = np.minimum(x2[i], x2[order[1:]])
            yy2 = np.minimum(y2[i], y2[order[1:]])

            w = np.maximum(0.0, xx2 - xx1 + 1)
            h = np.maximum(0.0, yy2 - yy1 + 1)
            inter = w * h
            ovr = inter / (areas[i] + areas[order[1:]] - inter)

            inds = np.where(ovr <= nms_thr)[0]
            order = order[inds + 1]

        return keep

    def predict(
            self, image: np.ndarray, params: Dict[str, Any]
    ) -> Dict[str, Any]:
        if not self._is_loaded:
            self.load(params)  # 此时才执行预热
        """Execute object detection.

        Args:
            image: Input image in BGR format.
            params: Inference parameters.

        Returns:
            Dictionary with detection results.
        """
        # 使用传入的参数或默认值
        conf_threshold = params.get("conf_threshold", self.conf_thres)
        iou_threshold = params.get("iou_threshold", self.nms_thres)

        # 临时保存原始阈值
        original_conf_thres = self.conf_thres
        original_nms_thres = self.nms_thres

        # 使用传入的参数
        self.conf_thres = conf_threshold
        self.nms_thres = iou_threshold

        try:
            # 预处理
            blob, ratio_hw = self.preprocess(image)

            # 推理
            outputs = self.net.get_ort_inference(blob)

            # 后处理
            predictions = self.postprocess(outputs)[0]

            # 重缩放和NMS
            results = self.rescale(predictions, ratio_hw)

            shapes = []
            if results is not None:
                final_boxes, final_scores, final_cls_inds = (
                    results[:, :4],
                    results[:, 4],
                    results[:, 5],
                )

                for box, score, cls_inds in zip(
                        final_boxes, final_scores, final_cls_inds
                ):
                    if score < self.conf_thres:
                        continue
                    x1, y1, x2, y2 = box
                    score = float(score)
                    label = str(self.classes[int(cls_inds)])

                    shape = Shape(
                        label=label,
                        shape_type="rectangle",
                        points=[
                            [float(x1), float(y1)],
                            [float(x2), float(y1)],
                            [float(x2), float(y2)],
                            [float(x1), float(y2)],
                        ],
                        score=score,
                    )
                    shapes.append(shape)

            return {"shapes": shapes, "description": ""}

        finally:
            # 恢复原始阈值
            self.conf_thres = original_conf_thres
            self.nms_thres = original_nms_thres

    def unload(self):
        """Release model resources."""
        if hasattr(self, "net"):
            del self.net
            self._is_loaded = False  # 重置状态
        print("yolox模型内存释放成功------")

    def get_metadata(self) -> Dict[str, Any]:
        """Return model metadata for /v1/models endpoint.

        Returns:
            Dictionary containing model information.
        """
        return {
            "display_name": getattr(self, 'display_name', 'YOLOX Detection Model'),
            "widgets": getattr(self, 'widgets', []),
            "params": getattr(self, 'params', {}),
            "batch_processing_mode": getattr(self, 'batch_processing_mode', "default"),
            "model_abs_path": self.model_abs_path,
        }