"""Model protocol definition that all models must implement."""

from typing import List, Dict, Any, Optional, Protocol
import numpy as np


class Shape(Protocol):
    """Shape protocol for prediction results."""
    
    @property
    def points(self) -> List[List[float]]:
        """Get the points defining the shape."""
        ...
    
    @property
    def label(self) -> Optional[str]:
        """Get the label for the shape."""
        ...
    
    @property
    def score(self) -> Optional[float]:
        """Get the confidence score for the shape."""
        ...


class ModelProtocol(Protocol):
    """Protocol that all models must implement."""
    
    def __init__(self, **kwargs):
        """Initialize the model with parameters.
        
        Args:
            **kwargs: Model initialization parameters.
        """
        ...
    
    def load(self, params: Dict[str, Any] = None) -> None:
        """Load the model.
        
        Args:
            params: Additional loading parameters.
        """
        ...
    
    def predict(self, image: np.ndarray, params: Dict[str, Any] = None) -> Dict[str, Any]:
        """Run prediction on an image.
        
        Args:
            image: Input image as numpy array.
            params: Prediction parameters.
            
        Returns:
            Dictionary with prediction results.
        """
        ...
    
    def unload(self) -> None:
        """Unload the model and release resources."""
        ...
    
    def get_metadata(self) -> Dict[str, Any]:
        """Get model metadata.
        
        Returns:
            Dictionary with model metadata.
        """
        ...