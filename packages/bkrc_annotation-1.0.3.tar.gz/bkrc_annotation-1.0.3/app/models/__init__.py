import numpy as np
from abc import ABC, abstractmethod
from typing import Any, Dict


class BaseModel(ABC):
    """Abstract base class for all models (reference implementation). 
       Models no longer need to inherit from this class, but should implement the same interface.
    """

    def __init__(self, config: Dict[str, Any] = None):
        """Initialize model.

        Args:
            config: Complete configuration dictionary from auto_labeling/{inference_id}.yaml (optional).
        """
        self.config = config or {}
        self.inference_id = None
        self.display_name = None
        self.params = self.config.get("params", {}) if self.config else {}
        self.model_abs_path = None

    @abstractmethod
    def load(self, params: Dict[str, Any] = None):
        """Load model into memory.

        Called by framework during service startup.
        Should raise exception if loading fails.
        
        Args:
            params: Runtime parameters for model loading, taking precedence over config
        """
        pass

    @abstractmethod
    def predict(
        self, image: np.ndarray, params: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Execute inference.

        Args:
            image: Input image array
            params: Inference parameters from client request.

        Returns:
            Dictionary with inference results:
                {
                    "shapes": List[Dict[str, Any]],  # List of detected shapes (optional)
                    "description": str                # Text description (optional)
                }

            Shape dictionary fields:
                - label (str): Label name
                - shape_type (str): Shape type (rectangle, polygon, etc.)
                - points (List[List[float]]): Coordinate points
                - score (float): Confidence score
                - attributes (Dict[str, Any]): Additional attributes
                - description (str | None): Description
                - difficult (bool): Difficult flag
                - direction (int): Direction
                - flags (Dict | None): Flags
                - group_id (int | None): Group ID
                - kie_linking (List): KIE linking
        """
        pass

    @abstractmethod
    def unload(self):
        """Unload model and free resources.

        Called by framework during service shutdown.
        """
        pass

    @abstractmethod
    def get_metadata(self) -> Dict[str, Any]:
        """Return model metadata for /v1/models endpoint.

        Returns:
            Dictionary containing model information.
        """
        pass
