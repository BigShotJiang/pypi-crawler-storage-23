import ast
import numpy as np
from loguru import logger
from typing import Any, Dict, List, Optional
from PIL import Image

from app.core.registry import register_model
from app.models.protocol import ModelProtocol
from app.schemas.shape import Shape


@register_model(
    "qwen3vl_caption_api",
    "qwen3vl_caption_transformers",
    "qwen3vl_grounding_transformers",
)
class Qwen3VL:
    """Unified Qwen3-VL model supporting multiple tasks and backends."""

    def __init__(
        self,
        model_path: str = "Qwen/Qwen3-VL-2B-Instruct",
        backend: str = "transformers",
        task: str = "caption",
        device: str = "auto",
        max_new_tokens: int = 512,
        repetition_penalty: float = 1.1,
        temperature: float = 0.7,
        api_base: str = "http://localhost:8000/v1",
        api_key: str = "EMPTY",
        model_name: str = "Qwen/Qwen3-VL-2B-Instruct",
        timeout: int = 60,
        prompt: str = "",
        prompt_mode: str = "",
        custom_prompt: str = "",
        text_prompt: str = ""
    ):
        self.model_path = model_path
        self.backend = backend
        self.task = task
        self.device = device
        self.max_new_tokens = max_new_tokens
        self.repetition_penalty = repetition_penalty
        self.temperature = temperature
        self.api_base = api_base
        self.api_key = api_key
        self.model_name = model_name
        self.timeout = timeout
        self.prompt = prompt
        self.prompt_mode = prompt_mode
        self.custom_prompt = custom_prompt
        self.text_prompt = text_prompt
        
        # Initialize model variables
        self.model = None
        self.processor = None
        self._is_loaded = False

    def load(self, params: Optional[Dict[str, Any]] = None) -> None:
        """Load Qwen3VL model based on backend configuration."""
        if params:
            # Override default values with provided parameters
            self.model_path = params.get("model_path", self.model_path)
            self.backend = params.get("backend", self.backend)
            self.task = params.get("task", self.task)
            self.device = params.get("device", self.device)
            self.max_new_tokens = params.get("max_new_tokens", self.max_new_tokens)
            self.repetition_penalty = params.get("repetition_penalty", self.repetition_penalty)
            self.temperature = params.get("temperature", self.temperature)
            self.api_base = params.get("api_base", self.api_base)
            self.api_key = params.get("api_key", self.api_key)
            self.model_name = params.get("model_name", self.model_name)
            self.timeout = params.get("timeout", self.timeout)

        if self.backend == "transformers":
            self._load_transformers()
        elif self.backend == "openai":
            self._load_openai()
        else:
            raise ValueError(f"Unsupported backend: {self.backend}")

        self._is_loaded = True

    def _load_transformers(self):
        """Load model using Transformers library."""
        try:
            from transformers import Qwen3VLForConditionalGeneration, AutoProcessor

            logger.info(
                f"Loading Qwen3VL with Transformers backend from {self.model_path}"
            )
            self.model = Qwen3VLForConditionalGeneration.from_pretrained(
                self.model_path, dtype="auto", device_map=self.device
            )
            self.processor = AutoProcessor.from_pretrained(self.model_path)
            logger.info("Qwen3VL model loaded successfully")
        except Exception as e:
            logger.error(f"Failed to load Qwen3VL model with Transformers: {e}")
            raise

    def _load_openai(self):
        """Initialize OpenAI API client."""
        logger.info(f"Using OpenAI API backend at {self.api_base}")

    def predict(
        self, image: np.ndarray, params: Dict[str, Any] = None
    ) -> Dict[str, Any]:
        """Execute prediction based on task type.

        Args:
            image: Input image in BGR format.
            params: Inference parameters including task type.

        Returns:
            Dictionary with prediction results.
        """
        if params is None:
            params = {}

        # Override default values with provided parameters
        task = params.get("task", self.task)
        max_new_tokens = params.get("max_new_tokens", self.max_new_tokens)
        repetition_penalty = params.get("repetition_penalty", self.repetition_penalty)
        temperature = params.get("temperature", self.temperature)

        if task == "caption":
            return self._predict_caption(image, params)
        elif task == "grounding":
            return self._predict_grounding(image, params)
        else:
            raise ValueError(f"Unsupported task: {task}")

    def _predict_caption(
        self, image: np.ndarray, params: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Execute image captioning task."""
        # 优先使用用户在请求中直接提供的prompt参数，如果没有则使用实例默认值
        user_prompt = params.get("prompt")  # 直接的prompt参数
        
        if user_prompt:
            # 如果用户提供了直接的prompt，使用它
            prompt = user_prompt
            logger.info(f"Frontend prompt received: '{prompt}'")
        else:
            # 否则按原有逻辑处理，优先使用params中的值，再使用实例默认值
            prompt_mode = params.get("prompt_mode", self.prompt_mode)
            logger.info(f"No direct prompt provided, using prompt_mode: '{prompt_mode}'")

            if prompt_mode == "detailed":
                prompt = (
                    "Describe this image in detail. Include information about: "
                    "the main subjects and objects, their positions and relationships, "
                    "colors, lighting, background, activities or actions taking place, "
                    "and the overall scene or context."
                )
            elif prompt_mode == "brief":
                prompt = "Provide a brief, concise description of this image in one or two sentences."
            else:
                # 优先使用params中的custom_prompt，然后是实例的custom_prompt属性
                prompt = params.get("custom_prompt", self.custom_prompt or "Describe what you see in this image.")
                logger.info(f"Using custom_prompt: '{prompt}'")

        logger.info(f"Final prompt being used: '{prompt}'")
        
        if self.backend == "transformers":
            description = self._inference_transformers(image, prompt, params)
        else:
            description = self._inference_openai(image, prompt, params)

        logger.info(f"Generated caption: {description[:200]}...")

        return {"shapes": [], "description": description}

    def _predict_grounding(
        self, image: np.ndarray, params: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Execute 2D object grounding task."""
        # 直接使用用户提供的完整提示词
        user_prompt = params.get("prompt", "")
        
        if not user_prompt:
            logger.warning("Please provide a complete prompt for grounding task.")
            return {"shapes": [], "description": ""}

        # 打印前端传入的提示词
        logger.info(f"Frontend prompt received for grounding: '{user_prompt}'")
        
        # 完全使用用户提供的提示词，不做任何修改
        # 但我们可以检查是否有必要的参数来增强提示词
        text_prompt = params.get("text_prompt", "")
        
        # 根据之前的成功经验，如果用户提供了一个基本提示词但没有指定对象，
        # 可能需要在提示词后附加对象名称以获得更好的效果
        # 但是，按照您的要求，我们不应该添加任何内容，除非用户明确要求
        final_prompt = user_prompt
        
        # 如果用户提供了text_prompt（对象名称），并且用户提供的prompt看起来像是通用的定位提示，
        # 我们可以在不违背您的要求的前提下，考虑构建合适的提示词
        # 但实际上，为了完全符合您的要求，我们应该只使用用户提供的prompt
        # 所以这里我们只使用user_prompt，不做任何修改
        
        if self.backend == "transformers":
            response = self._inference_transformers(image, final_prompt, params)
        else:
            response = self._inference_openai(image, final_prompt, params)

        logger.info(f"Grounding response received: {response[:200]}...")
        shapes = self._parse_grounding_response(response, image.shape)

        return {"shapes": shapes, "description": ""}

    def _inference_transformers(
        self, image: np.ndarray, prompt: str, params: Dict[str, Any]
    ) -> str:
        """Run inference using Transformers backend."""
        # Check if model is loaded
        if not self._is_loaded:
            self.load(params)
        
        max_new_tokens = params.get("max_new_tokens", self.max_new_tokens)
        repetition_penalty = params.get("repetition_penalty", self.repetition_penalty)

        pil_image = Image.fromarray(image[:, :, ::-1])

        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "image", "image": pil_image},
                    {"type": "text", "text": prompt},
                ],
            }
        ]

        inputs = self.processor.apply_chat_template(
            messages,
            tokenize=True,
            add_generation_prompt=True,
            return_dict=True,
            return_tensors="pt",
        )
        inputs = inputs.to(self.model.device)

        generated_ids = self.model.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            repetition_penalty=repetition_penalty,
        )
        generated_ids_trimmed = [
            out_ids[len(in_ids) :]
            for in_ids, out_ids in zip(inputs.input_ids, generated_ids)
        ]
        output_text = self.processor.batch_decode(
            generated_ids_trimmed,
            skip_special_tokens=True,
            clean_up_tokenization_spaces=False,
        )

        return output_text[0].strip()

    def _inference_openai(
        self, image: np.ndarray, prompt: str, params: Dict[str, Any]
    ) -> str:
        """Run inference using OpenAI API backend."""
        import base64
        import requests
        from io import BytesIO

        max_new_tokens = params.get("max_new_tokens", self.max_new_tokens)
        temperature = params.get("temperature", self.temperature)

        pil_image = Image.fromarray(image[:, :, ::-1])
        buffered = BytesIO()
        pil_image.save(buffered, format="PNG")
        img_base64 = base64.b64encode(buffered.getvalue()).decode("utf-8")
        img_data_uri = f"data:image/png;base64,{img_base64}"

        payload = {
            "model": self.model_name,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image_url",
                            "image_url": {"url": img_data_uri},
                        },
                        {"type": "text", "text": prompt},
                    ],
                }
            ],
            "max_tokens": max_new_tokens,
            "temperature": temperature,
        }

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

        timeout = params.get("timeout", self.timeout)

        try:
            response = requests.post(
                f"{self.api_base}/chat/completions",
                json=payload,
                headers=headers,
                timeout=timeout,
            )
            response.raise_for_status()
            result = response.json()
            return result["choices"][0]["message"]["content"]
        except Exception as e:
            logger.error(f"OpenAI API inference error: {e}")
            raise

    @staticmethod
    def _parse_json(json_output: str) -> str:
        """Parse JSON output from model, removing markdown fencing."""
        lines = json_output.splitlines()
        for i, line in enumerate(lines):
            if line == "```json":
                json_output = "\n".join(lines[i + 1 :])
                json_output = json_output.split("```")[0]
                break
        return json_output

    def _parse_grounding_response(
        self, response: str, image_shape: tuple
    ) -> list:
        """Parse grounding response and convert to shapes."""
        import re
        import json
        
        shapes = []
        height, width = image_shape[:2]

        # 尝试从响应中提取JSON部分
        try:
            # 首先尝试直接解析整个响应为JSON
            parsed_response = json.loads(response)
            if isinstance(parsed_response, list):
                bounding_boxes = parsed_response
            elif isinstance(parsed_response, dict) and 'predictions' in parsed_response:
                bounding_boxes = parsed_response['predictions']
            elif isinstance(parsed_response, dict) and 'objects' in parsed_response:
                bounding_boxes = parsed_response['objects']
            else:
                bounding_boxes = [parsed_response]
        except json.JSONDecodeError:
            # 如果直接解析失败，尝试从markdown格式中提取JSON
            try:
                json_output = self._parse_json(response)
                if json_output.strip():
                    parsed_response = json.loads(json_output)
                    if isinstance(parsed_response, list):
                        bounding_boxes = parsed_response
                    elif isinstance(parsed_response, dict) and 'predictions' in parsed_response:
                        bounding_boxes = parsed_response['predictions']
                    elif isinstance(parsed_response, dict) and 'objects' in parsed_response:
                        bounding_boxes = parsed_response['objects']
                    else:
                        bounding_boxes = [parsed_response]
                else:
                    # 尝试从文本中查找JSON数组
                    json_match = re.search(r'\[(.*?)\]', response, re.DOTALL)
                    if json_match:
                        json_str = '[' + json_match.group(1) + ']'
                        parsed_response = json.loads(json_str)
                        bounding_boxes = parsed_response if isinstance(parsed_response, list) else [parsed_response]
                    else:
                        # 尝试查找单独的对象结构
                        obj_matches = re.findall(r'\{[^{}]*\}', response)
                        bounding_boxes = []
                        for match in obj_matches:
                            try:
                                obj = json.loads(match)
                                if 'bbox_2d' in obj or 'bbox' in obj:
                                    bounding_boxes.append(obj)
                            except json.JSONDecodeError:
                                continue
            except (json.JSONDecodeError, ValueError):
                logger.warning(f"Could not parse grounding response as JSON: {response[:200]}...")
                return shapes

        # 确保bounding_boxes是列表
        if not isinstance(bounding_boxes, list):
            bounding_boxes = [bounding_boxes]

        for bbox_data in bounding_boxes:
            if not isinstance(bbox_data, dict):
                continue
                
            # 查找边界框坐标，可能的键名包括bbox_2d, bbox, box等
            bbox = None
            for bbox_key in ['bbox_2d', 'bbox', 'box', 'coordinates']:
                if bbox_key in bbox_data:
                    bbox = bbox_data[bbox_key]
                    break
            
            if not bbox or not isinstance(bbox, list) or len(bbox) < 4:
                continue

            # 获取标签，可能的键名包括label, name, class等
            label = "object"
            for label_key in ['label', 'name', 'class', 'category']:
                if label_key in bbox_data:
                    label = str(bbox_data[label_key])
                    break

            # 确保bbox包含至少4个值 [x1, y1, x2, y2]
            x1, y1, x2, y2 = bbox[0], bbox[1], bbox[2], bbox[3]
            
            # 归一化坐标转换为绝对坐标
            abs_x1 = int(x1 / 1000 * width)
            abs_y1 = int(y1 / 1000 * height)
            abs_x2 = int(x2 / 1000 * width)
            abs_y2 = int(y2 / 1000 * height)

            # 确保坐标顺序正确
            if abs_x1 > abs_x2:
                abs_x1, abs_x2 = abs_x2, abs_x1
            if abs_y1 > abs_y2:
                abs_y1, abs_y2 = abs_y2, abs_y1

            # 确保坐标在图像范围内
            abs_x1 = max(0, min(width, abs_x1))
            abs_y1 = max(0, min(height, abs_y1))
            abs_x2 = max(0, min(width, abs_x2))
            abs_y2 = max(0, min(height, abs_y2))

            # 创建形状对象
            shape = Shape(
                label=label,
                shape_type="rectangle",
                points=[
                    [float(abs_x1), float(abs_y1)],
                    [float(abs_x2), float(abs_y1)],
                    [float(abs_x2), float(abs_y2)],
                    [float(abs_x1), float(abs_y2)],
                ],
            )
            shapes.append(shape)

        logger.info(f"Parsed {len(shapes)} shapes from grounding response")
        return shapes

    def unload(self):
        """Release model resources."""
        if self.backend == "transformers":
            if hasattr(self, "model"):
                del self.model
            if hasattr(self, "processor"):
                del self.processor
        self._is_loaded = False

    def get_metadata(self) -> Dict[str, Any]:
        """Get model metadata."""
        return {
            "model_path": self.model_path,
            "backend": self.backend,
            "task": self.task,
            "device": self.device,
            "max_new_tokens": self.max_new_tokens,
            "loaded": self._is_loaded,
            "description": "Qwen3-VL Vision-Language Model supporting captioning and grounding tasks"
        }