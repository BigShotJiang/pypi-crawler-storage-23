import sys
import os
from PySide6.QtWidgets import QApplication

# 在导入Qt之前设置环境变量以避免OpenGL问题
os.environ['QTWEBENGINE_DISABLE_SANDBOX'] = '1'
os.environ['QT_QUICK_BACKEND'] = 'software'
os.environ['QSG_RENDER_LOOP'] = 'basic'
os.environ['QT_OPENGL'] = 'software'

from .main_window import AnnotationTool




def main():
    # 在创建QApplication之前设置环境变量
    os.environ['QT_AUTO_SCREEN_SCALE_FACTOR'] = '1'
    
    app = QApplication(sys.argv)
    app.setStyle('Fusion')

    app.setApplicationName("bkrc图像标注工具客户端")
    app.setOrganizationName("标注工具团队")

    tool = AnnotationTool()
    tool.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()