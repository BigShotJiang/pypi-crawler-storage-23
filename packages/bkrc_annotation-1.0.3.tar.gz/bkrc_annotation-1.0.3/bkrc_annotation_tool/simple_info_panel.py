#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
简化版信息面板 - 只包含文本输出框
用于显示后端服务的输出信息
"""

import sys
import os
import subprocess
import threading
import re
import platform
import time
import psutil
from datetime import datetime
from queue import Queue, Empty
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QTextEdit, QLabel, QHBoxLayout, QPushButton,
    QListWidget, QListWidgetItem, QSplitter, QFrame, QMenu, QAbstractItemView, QGroupBox
)
from PySide6.QtCore import Qt, Signal, QThread, QTimer, QPoint
from PySide6.QtGui import QColor, QTextCursor, QTextCharFormat, QFont, QIcon
from PySide6.QtCore import QMutex, QMutexLocker


# ANSI颜色过滤器
def filter_ansi_escape(text):
    """过滤ANSI转义序列"""
    # 确保输入是字符串
    if not isinstance(text, str):
        try:
            text = str(text, 'utf-8', errors='replace')
        except (TypeError, UnicodeDecodeError):
            text = str(text)
    
    # 过滤ANSI转义序列
    ansi_pattern = re.compile(r'\x1B\[[0-?]*[ -/]*[@-~]')
    return ansi_pattern.sub('', text)


class SimpleInfoPanel(QWidget):
    """简化版信息面板 - 只保留文本输出框"""
    
        # 定义信号
    output_signal = Signal(str, str)  # text, type
    python_processes_updated = Signal(list)  # 更新Python进程列表的信号
    
class ProcessScanThread(QThread):
    """专门用于扫描进程的后台线程"""
    result_ready = Signal(list)  # 扫描结果信号
    
    def __init__(self):
        super().__init__()
    
    def run(self):
        """在后台线程中执行进程扫描"""
        current_pid = os.getpid()  # 获取当前进程的PID
        python_processes = []

        # 获取Python关键字列表，用于快速匹配
        python_keywords = ['python', 'pythonw', 'python3']

        try:
            # 首先获取所有进程的基本信息，不立即获取详细的CPU和内存信息
            processes_to_check = []
            for proc in psutil.process_iter(['pid', 'name', 'cmdline', 'create_time', 'status']):
                try:
                    proc_info = proc.info
                    pid = proc_info['pid']

                    # 跳过自身进程
                    if pid == current_pid:
                        continue

                    proc_name = proc_info['name'].lower() if proc_info['name'] else ''

                    # 检查是否为Python进程
                    # 方法1：通过进程名（快速检查）
                    is_python_by_name = any(keyword in proc_name for keyword in python_keywords)

                    # 如果进程名没有匹配，再检查命令行（更慢的检查）
                    if not is_python_by_name:
                        cmdline = proc_info.get('cmdline', [])
                        if not cmdline:
                            continue
                        is_python_by_name = any('python' in arg.lower() for arg in cmdline)

                    if is_python_by_name:
                        # 先收集基础信息，稍后获取CPU和内存信息以避免阻塞
                        processes_to_check.append((proc, proc_info))

                except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                    continue
                except Exception as e:
                    continue

            # 然后逐个获取详细信息，避免同时查询所有进程的CPU使用率造成阻塞
            for proc, proc_info in processes_to_check:
                try:
                    # 为了避免阻塞，我们先获取基本信息，然后单独获取CPU和内存数据
                    detailed_info = {
                        'pid': proc_info['pid'],
                        'name': proc_info['name'] or 'N/A',
                        'command_line': ' '.join(proc_info.get('cmdline', [])) if proc_info.get('cmdline') else 'N/A',
                        'create_time': datetime.fromtimestamp(proc_info['create_time']).strftime(
                            '%Y-%m-%d %H:%M:%S') if proc_info.get('create_time') else 'N/A',
                        'status': proc_info.get('status', 'N/A'),
                        'username': proc.username() if hasattr(proc, 'username') else 'N/A',
                        'working_directory': proc.cwd() if hasattr(proc, 'cwd') else 'N/A'
                    }
                    
                    # 单独获取CPU和内存信息，避免一次性获取所有进程的这些信息造成阻塞
                    if proc.is_running():
                        detailed_info['cpu_percent'] = proc.cpu_percent()  # 不使用interval参数以避免阻塞
                        detailed_info['memory_percent'] = round(proc.memory_percent(), 2)
                        detailed_info['memory_rss'] = f"{proc.memory_info().rss / 1024 / 1024:.2f} MB"
                    else:
                        detailed_info['cpu_percent'] = 0
                        detailed_info['memory_percent'] = 0
                        detailed_info['memory_rss'] = 'N/A'
                        
                    python_processes.append(detailed_info)
                except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                    continue
                except Exception as e:
                    continue
        except Exception:
            # 如果遇到权限问题或其他异常，返回空列表
            python_processes = []
        
        # 发送扫描结果
        self.result_ready.emit(python_processes)


class SimpleInfoPanel(QWidget):
    """简化版信息面板 - 只保留文本输出框"""
    
    # 定义信号
    output_signal = Signal(str, str)  # text, type
    python_processes_updated = Signal(list)  # 更新Python进程列表的信号
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.backend_process = None
        self.output_queue = Queue()
        self.is_running = False
        
        # 添加进程缓存相关变量（仅用于手动刷新）
        self.python_processes_cache = []  # 缓存的Python进程列表
        self.scan_mutex = QMutex()  # 线程安全锁
        
        # 添加扫描线程相关属性
        self.scan_thread = None
        self.is_scanning = False  # 添加扫描状态标志
        
        # 初始化外部进程管理字典
        self.running_processes = {}  # 存储运行的外部进程
        
        self._init_ui()
        self._setup_signals()
        # 异步启动服务，避免阻塞UI
        QTimer.singleShot(500, self.start_backend_service)
        

        
        # 设置定期刷新进程列表的定时器
        self._setup_refresh_timer()
        
        # 连接Python进程更新信号
        self.python_processes_updated.connect(self._on_python_processes_updated)
    
    def _init_ui(self):
        """初始化UI - 与左右边栏统一风格"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(5, 5, 5, 5)  # 与左右面板保持一致的边距
        layout.setSpacing(10)  # 与左右面板保持一致的间距
        
        # 使用水平布局代替分割器，避免分割线
        main_h_layout = QHBoxLayout()
        
        # 左侧进程列表面板
        process_container = QWidget()
        process_layout = QVBoxLayout(process_container)
        self._create_process_list_panel_no_parent()
        process_layout.addWidget(self.process_group)
        
        # 右侧输出文本框
        output_container = QWidget()
        output_layout = QVBoxLayout(output_container)
        self._create_output_panel_no_parent()
        output_layout.addWidget(self.output_group)
        
        # 设置固定比例（进程列表占30%，输出占70%）
        main_h_layout.addWidget(process_container, 3)  # 进程列表占3份
        main_h_layout.addWidget(output_container, 7)  # 输出区域占7份
        
        layout.addLayout(main_h_layout)
    
    def _create_process_list_panel(self, parent_splitter):
        """创建进程列表面板 - 统一左侧和右侧边栏的控件风格"""
        # 进程列表容器 - 与左侧面板的列表控件保持一致
        self.process_group = QGroupBox("进程列表")
        process_layout = QVBoxLayout(self.process_group)
        self.process_list = QListWidget()
        self.process_list.setMinimumHeight(120)
        self.process_list.setMaximumHeight(200)
        self.process_list.setSelectionMode(QAbstractItemView.SingleSelection)
        

        
        # 连接双击信号
        self.process_list.itemDoubleClicked.connect(self._on_process_double_clicked)
        
        process_layout.addWidget(self.process_list)
        
        # 进程操作按钮 - 统一按钮布局和样式
        button_layout = QHBoxLayout()
        
        self.stop_selected_btn = QPushButton("⏹️ 停止选中")
        self.stop_selected_btn.clicked.connect(self._stop_selected_process)
        self.stop_selected_btn.setToolTip("停止当前选中的进程")
        self.stop_selected_btn.setEnabled(False)
        button_layout.addWidget(self.stop_selected_btn)
        
        # 停止全部按钮
        self.stop_all_btn = QPushButton("⏹️ 停止全部")
        self.stop_all_btn.clicked.connect(self.stop_all_processes)
        self.stop_all_btn.setToolTip("停止所有运行中的进程")
        self.stop_all_btn.setEnabled(False)
        button_layout.addWidget(self.stop_all_btn)
        
        # 添加刷新按钮
        self.refresh_processes_btn = QPushButton("🔄 刷新")
        self.refresh_processes_btn.clicked.connect(self.refresh_process_status)
        self.refresh_processes_btn.setToolTip("刷新进程列表")
        button_layout.addWidget(self.refresh_processes_btn)
        
        process_layout.addLayout(button_layout)
        
        parent_splitter.addWidget(self.process_group)
    
    def _create_process_list_panel_no_parent(self):
        """创建进程列表面板 - 用于无父分割器的情况"""
        # 进程列表容器 - 与左侧面板的列表控件保持一致
        self.process_group = QGroupBox("进程列表")
        process_layout = QVBoxLayout(self.process_group)
        self.process_list = QListWidget()
        self.process_list.setMinimumHeight(120)
        self.process_list.setMaximumHeight(200)
        self.process_list.setSelectionMode(QAbstractItemView.SingleSelection)
        

        
        # 连接双击信号
        self.process_list.itemDoubleClicked.connect(self._on_process_double_clicked)
        
        process_layout.addWidget(self.process_list)
        
        # 进程操作按钮 - 统一按钮布局和样式
        button_layout = QHBoxLayout()
        
        self.stop_selected_btn = QPushButton("⏹️ 停止选中")
        self.stop_selected_btn.clicked.connect(self._stop_selected_process)
        self.stop_selected_btn.setToolTip("停止当前选中的进程")
        self.stop_selected_btn.setEnabled(False)
        button_layout.addWidget(self.stop_selected_btn)
        
        # 停止全部按钮
        self.stop_all_btn = QPushButton("⏹️ 停止全部")
        self.stop_all_btn.clicked.connect(self.stop_all_processes)
        self.stop_all_btn.setToolTip("停止所有运行中的进程")
        self.stop_all_btn.setEnabled(False)
        button_layout.addWidget(self.stop_all_btn)
        
        # 添加刷新按钮
        self.refresh_processes_btn = QPushButton("🔄 刷新")
        self.refresh_processes_btn.clicked.connect(self.refresh_process_status)
        self.refresh_processes_btn.setToolTip("刷新进程列表")
        button_layout.addWidget(self.refresh_processes_btn)
        
        process_layout.addLayout(button_layout)
    
    def _create_output_panel(self, parent_splitter):
        """创建输出面板"""
        # 创建输出组框以统一风格
        self.output_group = QGroupBox("控制台输出")
        output_layout = QVBoxLayout(self.output_group)
        output_layout.setSpacing(5)
        output_layout.setContentsMargins(5, 10, 5, 5)  # 组框内边距
        
        # 输出文本框 - 与左右面板风格一致
        self.output_text = QTextEdit()
        self.output_text.setReadOnly(True)
        self.output_text.setFont(QFont("Consolas", 9))
        output_layout.addWidget(self.output_text)
        
        parent_splitter.addWidget(self.output_group)
    
    def _create_output_panel_no_parent(self):
        """创建输出面板 - 用于无父分割器的情况"""
        # 创建输出组框以统一风格
        self.output_group = QGroupBox("控制台输出")
        output_layout = QVBoxLayout(self.output_group)
        output_layout.setSpacing(5)
        output_layout.setContentsMargins(5, 10, 5, 5)  # 组框内边距
        
        # 输出文本框 - 与左右面板风格一致
        self.output_text = QTextEdit()
        self.output_text.setReadOnly(True)
        self.output_text.setFont(QFont("Consolas", 9))
        output_layout.addWidget(self.output_text)
    
    def _setup_signals(self):
        """设置信号连接"""
        self.output_signal.connect(self._append_output)
        
        # 连接进程列表选择变化信号
        self.process_list.currentItemChanged.connect(self._on_process_selection_changed)
    

    
    def _setup_refresh_timer(self):
        """移除自动刷新定时器 - 改为手动刷新"""
        # 自动刷新功能已移除，保留手动刷新按钮供用户控制
        pass
    
    def start_backend_service(self):
        """启动后端服务 - 使用统一进程启动函数"""
        if self.is_running:
            return
            
        self.is_running = True
        
        # 构建启动命令 - 统一使用列表形式，避免cmd.exe包装进程
        cmd = [sys.executable, "-m", "uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000", "--workers", "1"]
        
        # 使用统一进程启动函数启动后端服务
        success = self.start_external_process(
            cmd,
            process_name="后端服务",
            show_in_terminal=True
        )
        
        if success:
            # 从统一进程管理中获取后端进程引用
            backend_info = self.running_processes.get("后端服务")
            if backend_info:
                self.backend_process = backend_info['process']
            
            self._append_output("=== 🚀 后端服务启动中 ===\n", "info")
            self._append_output(f"工作目录: {os.getcwd()}\n", "info")
            self._append_output(f"启动命令: {cmd}\n", "info")
            
            # 立即刷新进程列表以显示后端服务
            QTimer.singleShot(1000, self._refresh_process_list)
        else:
            self._append_output("后端服务启动失败\n", "error")
            self.is_running = False
    
    def _is_port_in_use(self, port):
        """检查端口是否被占用"""
        import socket
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(1)
            result = sock.connect_ex(('localhost', port))
            sock.close()
            return result == 0
        except:
            return False
    
    def _find_existing_backend_process(self):
        """查找已存在的后端服务进程"""
        try:
            current_pid = os.getpid()
            for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
                try:
                    # 跳过当前进程
                    if proc.info['pid'] == current_pid:
                        continue
                    
                    cmdline = proc.info.get('cmdline', [])
                    if not cmdline:
                        continue
                    
                    cmdline_str = ' '.join(cmdline)
                    # 检查是否为我们的后端服务进程
                    if ('uvicorn' in cmdline_str.lower() and 
                        'app.main:app' in cmdline_str and 
                        '8000' in cmdline_str):
                        return proc.info['pid']
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
        except Exception as e:
            self._append_output(f"查找现有进程时出错: {e}\n", "error")
        return None
    
    def _create_pseudo_process(self, pid):
        """为现有进程创建伪进程对象"""
        class PseudoProcess:
            def __init__(self, pid):
                self.pid = pid
                
            def poll(self):
                try:
                    import psutil
                    proc = psutil.Process(self.pid)
                    return None if proc.is_running() else 0
                except:
                    return 0
                    
            def terminate(self):
                try:
                    import psutil
                    proc = psutil.Process(self.pid)
                    proc.terminate()
                except:
                    pass
                    
            def kill(self):
                try:
                    import psutil
                    proc = psutil.Process(self.pid)
                    proc.kill()
                except:
                    pass
                    
            def wait(self, timeout=None):
                import time
                start_time = time.time()
                while self.poll() is None:
                    if timeout and (time.time() - start_time) > timeout:
                        raise subprocess.TimeoutExpired(None, timeout)
                    time.sleep(0.1)
                return 0
        
        return PseudoProcess(pid)
    
    def stop_backend_service(self):
        """停止后端服务 - 使用统一进程管理"""
        # 检查是否在统一进程管理中
        if "后端服务" in self.running_processes:
            # 使用统一进程管理停止后端服务
            backend_info = self.running_processes["后端服务"]
            process = backend_info['process']
            
            self._append_output(f"正在停止 后端服务...\n", "info")
            
            try:
                # 获取进程PID
                original_pid = process.pid
                self._append_output(f"目标进程 PID: {original_pid}\n", "info")
                
                # 直接强制终止
                process.kill()
                return_code = process.wait(timeout=3)
                self._append_output(f"后端服务 已强制终止 (返回码: {return_code})\n", "warning")
                
                # 从统一进程管理中移除
                del self.running_processes["后端服务"]
                
                # 简化的清理记录
                self.is_running = False
                self.backend_process = None
                self._append_output(f"后端服务 资源清理完成\n", "info")
                    
                return True
                    
            except Exception as e:
                self._append_output(f"停止 后端服务 时出错: {str(e)}\n", "error")
                return False
        else:
            # 如果没有在统一进程管理中，使用原有逻辑
            if not self.is_running or not self.backend_process:
                return True
            process = self.backend_process
            
            self._append_output(f"正在停止 后端服务...\n", "info")
            
            try:
                # 获取进程PID
                original_pid = process.pid
                self._append_output(f"目标进程 PID: {original_pid}\n", "info")
                
                # 直接强制终止
                process.kill()
                return_code = process.wait(timeout=3)
                self._append_output(f"后端服务 已强制终止 (返回码: {return_code})\n", "warning")
                
                # 简化的清理记录
                self.is_running = False
                self.backend_process = None
                self._append_output(f"后端服务 资源清理完成\n", "info")
                    
                return True
                    
            except Exception as e:
                self._append_output(f"停止 后端服务 时出错: {str(e)}\n", "error")
                return False
    
    # 输出读取功能已由统一进程管理自动处理，不再需要单独的读取函数
    
    def _append_output(self, text, text_type="stdout"):
        """添加输出到文本框"""
        cursor = self.output_text.textCursor()
        cursor.movePosition(QTextCursor.End)
        
        # 设置文本格式
        format_obj = QTextCharFormat()
        if text_type == "info":
            format_obj.setForeground(QColor("#006600"))    # 深绿色
        elif text_type == "error":
            format_obj.setForeground(QColor("#cc0000"))    # 深红色
        elif text_type == "warning":
            format_obj.setForeground(QColor("#cc6600"))    # 橙色
        elif text_type == "stdout":
            format_obj.setForeground(QColor("#333333"))    # 深灰色
        elif text_type == "stderr":
            format_obj.setForeground(QColor("#cc0000"))    # 深红色
        else:
            format_obj.setForeground(QColor("#666666"))    # 中灰色
        
        cursor.setCharFormat(format_obj)
        cursor.insertText(text)
        self.output_text.setTextCursor(cursor)
        
        # 自动滚动到底部
        scrollbar = self.output_text.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())
    
    def clear_output(self):
        """清空输出"""
        self.output_text.clear()
    
    def _force_kill_process_tree(self, process):
        """强制终止进程树 - 跨平台实现"""
        if not process:
            return
            
        try:
            import psutil
            # 获取主进程
            parent = psutil.Process(process.pid)
            # 获取所有子进程
            children = parent.children(recursive=True)
            
            self._append_output(f"正在终止进程树，父进程 PID: {process.pid}\n", "info")
            self._append_output(f"发现 {len(children)} 个子进程\n", "info")
            
            # 第一阶段：优雅终止所有子进程
            terminated_children = []
            for child in children:
                try:
                    self._append_output(f"  优雅终止子进程: PID={child.pid}\n", "info")
                    child.terminate()
                    terminated_children.append(child)
                except psutil.NoSuchProcess:
                    pass
                except Exception as e:
                    self._append_output(f"  优雅终止子进程失败: PID={child.pid}, 错误: {e}\n", "error")
            
            # 等待子进程优雅终止
            if terminated_children:
                gone, alive = psutil.wait_procs(terminated_children, timeout=3)
                self._append_output(f"  优雅终止成功: {len(gone)}, 仍需强制: {len(alive)}\n", "info")
                
                # 第二阶段：强制杀死仍未终止的子进程
                for p in alive:
                    try:
                        self._append_output(f"  强制终止顽固子进程: PID={p.pid}\n", "warning")
                        p.kill()
                    except psutil.NoSuchProcess:
                        pass
                
                # 等待强制终止完成
                if alive:
                    psutil.wait_procs(alive, timeout=2)
            
            # 第三阶段：优雅终止父进程
            try:
                self._append_output(f"  优雅终止父进程: PID={process.pid}\n", "info")
                parent.terminate()
                parent.wait(timeout=3)
                self._append_output(f"  父进程已优雅终止\n", "info")
            except psutil.TimeoutExpired:
                # 第四阶段：强制终止父进程
                self._append_output(f"  父进程优雅终止超时，强制终止\n", "warning")
                try:
                    parent.kill()
                    parent.wait(timeout=2)
                    self._append_output(f"  父进程已强制终止\n", "warning")
                except psutil.TimeoutExpired:
                    self._append_output(f"  父进程强制终止也超时\n", "error")
                except psutil.NoSuchProcess:
                    self._append_output(f"  父进程已不存在\n", "info")
            except psutil.NoSuchProcess:
                self._append_output(f"  父进程已不存在\n", "info")
                
        except ImportError:
            # 如果没有psutil，使用基本的终止方法
            try:
                self._append_output("psutil不可用，使用基本终止方法\n", "warning")
                process.kill()
                process.wait(timeout=2)
            except Exception as e:
                self._append_output(f"基本终止方法失败: {e}\n", "error")
        except Exception as e:
            self._append_output(f"增强终止进程树时出错: {e}\n", "error")
    
    def _verify_process_termination(self, pid):
        """验证进程是否真正终止 - 防止假停止现象"""
        try:
            import psutil
            # 检查进程是否还存在
            try:
                proc = psutil.Process(pid)
                # 如果能获取到进程，说明还没终止
                self._append_output(f"  验证发现进程仍存在: PID={pid}, 状态={proc.status()}\n", "warning")
                return False
            except psutil.NoSuchProcess:
                # 进程不存在，说明已终止
                self._append_output(f"  验证确认进程已不存在: PID={pid}\n", "info")
                return True
        except ImportError:
            # 没有psutil时的基本验证
            try:
                os.kill(pid, 0)  # 检查进程是否存在
                self._append_output(f"  基本验证发现进程仍存在: PID={pid}\n", "warning")
                return False
            except OSError:
                self._append_output(f"  基本验证确认进程不存在: PID={pid}\n", "info")
                return True
        except Exception as e:
            self._append_output(f"  验证过程出错: {e}\n", "error")
            return False
    
    def _verify_backend_port_released(self):
        """验证后端服务端口是否真正释放"""
        try:
            import socket
            import time
            port = 8000  # 后端服务默认端口
            
            # 尝试连接端口来验证是否可用
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(1)
            try:
                result = sock.connect_ex(('localhost', port))
                if result == 0:
                    # 端口仍被占用，尝试查找占用进程
                    self._append_output(f"端口 {port} 仍被占用\n", "warning")
                    self._investigate_port_occupancy(port)
                    return False
                else:
                    # 端口可用
                    self._append_output(f"端口 {port} 已释放\n", "info")
                    return True
            finally:
                sock.close()
        except Exception as e:
            self._append_output(f"端口验证出错: {e}\n", "error")
            return False
    
    def _investigate_port_occupancy(self, port):
        """调查端口占用情况"""
        try:
            import psutil
            self._append_output(f"正在调查端口 {port} 的占用情况...\n", "info")
            
            # 查找占用指定端口的进程
            for proc in psutil.process_iter(['pid', 'name', 'connections']):
                try:
                    connections = proc.connections()
                    for conn in connections:
                        if conn.laddr.port == port:
                            self._append_output(f"  发现占用进程: PID={proc.pid}, 名称={proc.name()}\n", "warning")
                            # 尝试终止该进程
                            self._attempt_terminate_port_holder(proc.pid)
                except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                    continue
                except Exception:
                    continue
                    
        except ImportError:
            self._append_output("psutil不可用，无法调查端口占用\n", "warning")
        except Exception as e:
            self._append_output(f"调查端口占用出错: {e}\n", "error")
    
    def _perform_additional_port_cleanup(self):
        """执行额外的端口清理操作"""
        try:
            import psutil
            import subprocess
            port = 8000
            
            self._append_output(f"执行端口 {port} 的深度清理...\n", "info")
            
            # 方法1：使用netstat查找占用进程
            try:
                result = subprocess.run(
                    ['netstat', '-ano'], 
                    capture_output=True, 
                    text=True, 
                    timeout=5
                )
                if result.returncode == 0:
                    lines = result.stdout.split('\n')
                    for line in lines:
                        if f':{port}' in line and 'LISTENING' in line:
                            parts = line.split()
                            if len(parts) >= 5:
                                pid = parts[-1]
                                if pid.isdigit():
                                    self._append_output(f"  发现监听进程 PID={pid}\n", "info")
                                    self._attempt_terminate_port_holder(int(pid))
            except Exception as e:
                self._append_output(f"  netstat方法失败: {e}\n", "warning")
            
            # 方法2：查找相关进程
            related_processes = []
            for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
                try:
                    cmdline = proc.info.get('cmdline', [])
                    if not cmdline:
                        continue
                    
                    cmdline_str = ' '.join(cmdline)
                    if (('uvicorn' in cmdline_str.lower() or 
                         'fastapi' in cmdline_str.lower()) and 
                        '8000' in cmdline_str):
                        related_processes.append(proc)
                        self._append_output(f"  发现相关进程: PID={proc.pid}\n", "info")
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
                except Exception:
                    continue
            
            # 终止相关进程
            for proc in related_processes:
                try:
                    proc.terminate()
                    proc.wait(timeout=3)
                    self._append_output(f"  ✓ 已终止相关进程: PID={proc.pid}\n", "info")
                except psutil.TimeoutExpired:
                    try:
                        proc.kill()
                        proc.wait(timeout=2)
                        self._append_output(f"  ✓ 强制终止相关进程: PID={proc.pid}\n", "warning")
                    except Exception as e:
                        self._append_output(f"  ✗ 终止相关进程失败: PID={proc.pid}, {e}\n", "error")
                except Exception as e:
                    self._append_output(f"  ✗ 终止相关进程失败: PID={proc.pid}, {e}\n", "error")
                    
        except Exception as e:
            self._append_output(f"额外端口清理出错: {e}\n", "error")
    
    def _attempt_terminate_port_holder(self, pid):
        """尝试终止占用端口的进程"""
        try:
            import psutil
            proc = psutil.Process(pid)
            self._append_output(f"  尝试终止占用进程: PID={pid}\n", "info")
            
            # 优雅终止
            proc.terminate()
            try:
                proc.wait(timeout=3)
                self._append_output(f"  ✓ 成功终止进程 PID={pid}\n", "info")
            except psutil.TimeoutExpired:
                # 强制终止
                proc.kill()
                proc.wait(timeout=2)
                self._append_output(f"  ✓ 强制终止进程 PID={pid}\n", "warning")
                
        except Exception as e:
            self._append_output(f"  ✗ 终止进程失败 PID={pid}: {e}\n", "error")
    
    def _additional_cleanup_by_pid(self, pid):
        """根据PID进行额外清理 - 兜底措施"""
        try:
            import psutil
            self._append_output(f"执行额外清理 PID: {pid}\n", "info")
            
            # 查找所有可能相关的进程
            related_processes = []
            for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
                try:
                    if proc.info['pid'] == pid:
                        related_processes.append(proc)
                        continue
                    
                    cmdline = proc.info.get('cmdline', [])
                    if not cmdline:
                        continue
                    
                    cmdline_str = ' '.join(cmdline)
                    # 匹配相同端口或相似特征的进程
                    if ('uvicorn' in cmdline_str.lower() and 
                        ('8000' in cmdline_str or 'app.main:app' in cmdline_str)):
                        related_processes.append(proc)
                        self._append_output(f"  发现相关进程: PID={proc.info['pid']}\n", "info")
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
                except Exception:
                    continue
            
            # 强制终止所有相关进程
            killed_count = 0
            for proc in related_processes:
                try:
                    proc.kill()
                    proc.wait(timeout=2)
                    killed_count += 1
                    self._append_output(f"  ✓ 已终止相关进程: PID={proc.pid}\n", "info")
                except Exception as e:
                    self._append_output(f"  ✗ 终止相关进程失败: PID={proc.pid}, {e}\n", "error")
            
            self._append_output(f"额外清理完成，共终止 {killed_count} 个进程\n", "info")
            
        except ImportError:
            self._append_output("psutil不可用，跳过额外清理\n", "warning")
        except Exception as e:
            self._append_output(f"额外清理出错: {e}\n", "error")
    
    def start_external_process(self, cmd, process_name="External Process", show_in_terminal=True):
        """启动外部进程并捕获输出 - 增强版
        
        Args:
            cmd: 命令列表或字符串
            process_name: 进程名称，用于标识
            show_in_terminal: 是否在终端面板显示输出
            
        Returns:
            bool: 启动是否成功
        """
        # 检查是否已有同名进程在运行
        if process_name in self.running_processes:
            existing_process = self.running_processes[process_name]['process']
            if existing_process.poll() is None:  # 进程仍在运行
                if show_in_terminal:
                    self._append_output(f"进程 '{process_name}' 已在运行中\n", "warning")
                return False
            else:
                # 进程已结束，清理记录
                del self.running_processes[process_name]
            
        try:
            # 设置环境变量，确保编码一致性
            env = os.environ.copy()
            env['PYTHONIOENCODING'] = 'utf-8'
            env['PYTHONUTF8'] = '1'
            
            if isinstance(cmd, str):
                # Windows系统使用shell=True
                shell = True if platform.system() == "Windows" else False
                process = subprocess.Popen(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    stdin=subprocess.PIPE,
                    shell=shell,
                    bufsize=1,  # 行缓冲模式
                    universal_newlines=True,  # 使用文本模式
                    encoding='utf-8',
                    errors='replace',
                    env=env  # 传递环境变量
                )
            else:
                # 命令列表形式
                process = subprocess.Popen(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    stdin=subprocess.PIPE,
                    shell=False,
                    bufsize=1,  # 行缓冲模式
                    universal_newlines=True,  # 使用文本模式
                    encoding='utf-8',
                    errors='replace',
                    env=env  # 传递环境变量
                )
            
            # 检查进程是否成功启动
            if process.poll() is not None:
                # 进程立即退出，说明启动失败
                if show_in_terminal:
                    self._append_output(f"启动 {process_name} 失败: 进程立即退出\n", "error")
                return False
            
            # 启动输出读取线程
            stdout_thread = threading.Thread(
                target=self._read_process_output, 
                args=(process, process_name, "stdout"), 
                daemon=True
            )
            stderr_thread = threading.Thread(
                target=self._read_process_output, 
                args=(process, process_name, "stderr"), 
                daemon=True
            )
            
            stdout_thread.start()
            stderr_thread.start()
            
            if show_in_terminal:
                self._append_output(f"=== 🚀 启动 {process_name} ===\n", "info")
                self._append_output(f"命令: {' '.join(cmd) if isinstance(cmd, list) else cmd}\n", "info")
                self._append_output(f"进程PID: {process.pid}\n", "info")
            
            # 保存进程引用以便后续管理
            self.running_processes[process_name] = {
                'process': process,
                'threads': [stdout_thread, stderr_thread],
                'start_time': time.time(),
                'name': process_name
            }
            
            return True
            
        except Exception as e:
            if show_in_terminal:
                self._append_output(f"启动 {process_name} 失败: {str(e)}\n", "error")
            return False
    
    def _read_process_output(self, process, process_name, stream_type):
        """读取进程输出的通用方法 - 实时读取模式"""
        try:
            stream = process.stdout if stream_type == "stdout" else process.stderr
            while process.poll() is None:
                # 使用readline()实现实时输出
                line = stream.readline()
                if line:
                    # 处理编码问题：尝试多种编码方式
                    try:
                        # 首先尝试UTF-8
                        clean_line = filter_ansi_escape(line.rstrip())
                    except UnicodeDecodeError:
                        try:
                            # 如果UTF-8失败，尝试GBK（Windows默认编码）
                            clean_line = filter_ansi_escape(line.encode('latin1').decode('gbk', errors='replace').rstrip())
                        except:
                            # 如果都失败，使用错误替换
                            clean_line = filter_ansi_escape(line.encode('utf-8', errors='replace').decode('utf-8', errors='replace').rstrip())
                    
                    if clean_line.strip():
                        self.output_signal.emit(f"[{process_name}] {clean_line}\n", stream_type)
                else:
                    # 没有输出时短暂休眠，避免CPU占用过高
                    time.sleep(0.01)
        except Exception as e:
            self.output_signal.emit(f"[{process_name}] {stream_type}读取错误: {str(e)}\n", "error")
    
    def get_running_processes_by_name(self, process_name):
        """根据名称获取运行中的进程"""
        running_processes = []
        to_remove = []
        
        for name, proc_info in self.running_processes.items():
            if process_name in name:
                process = proc_info['process']
                if process.poll() is None:  # 进程仍在运行
                    running_processes.append(proc_info)
                else:
                    # 进程已结束，标记清理
                    to_remove.append(name)
        
        # 清理已结束的进程
        for name in to_remove:
            del self.running_processes[name]
            
        return running_processes
    
    def get_all_running_processes(self):
        """获取所有运行中的进程"""
        running = []
        to_remove = []
        
        for name, proc_info in self.running_processes.items():
            process = proc_info['process']
            if process.poll() is None:  # 进程仍在运行
                running.append(proc_info)
            else:
                # 进程已结束，标记清理
                to_remove.append(name)
        
        # 清理已结束的进程
        for name in to_remove:
            del self.running_processes[name]
            
        return running
    
    def stop_external_process(self, process_name):
        """停止通过统一进程启动函数启动的外部进程"""
        if process_name not in self.running_processes:
            self._append_output(f"进程 '{process_name}' 不在运行中\n", "warning")
            return False
            
        process_info = self.running_processes[process_name]
        process = process_info['process']
        
        self._append_output(f"正在停止 {process_name}...\n", "info")
        
        try:
            # 获取进程PID
            original_pid = process.pid
            self._append_output(f"目标进程 PID: {original_pid}\n", "info")
            
            # 直接强制终止
            process.kill()
            return_code = process.wait(timeout=3)
            self._append_output(f"{process_name} 已强制终止 (返回码: {return_code})\n", "warning")
            
            # 从统一进程管理中移除
            del self.running_processes[process_name]
            
            self._append_output(f"{process_name} 资源清理完成\n", "info")
            return True
                
        except Exception as e:
            self._append_output(f"停止 {process_name} 时出错: {str(e)}\n", "error")
            return False
    
    def get_python_process_info(self):
        """
        获取所有Python进程的详细信息（排除自身）- 返回缓存版本
        """
        # 返回缓存的进程列表
        self.scan_mutex.lock()
        cached_processes = self.python_processes_cache.copy()
        self.scan_mutex.unlock()
        return cached_processes
    
    def _scan_python_processes(self):
        """
        在后台线程中扫描Python进程
        """
        current_pid = os.getpid()  # 获取当前进程的PID
        python_processes = []

        # 获取Python关键字列表，用于快速匹配
        python_keywords = ['python', 'pythonw', 'python3']

        for proc in psutil.process_iter(['pid', 'name', 'cmdline', 'create_time',
                                         'cpu_percent', 'memory_info', 'status']):
            try:
                proc_info = proc.info
                pid = proc_info['pid']

                # 跳过自身进程
                if pid == current_pid:
                    continue

                proc_name = proc_info['name'].lower() if proc_info['name'] else ''

                # 检查是否为Python进程
                # 方法1：通过进程名（快速检查）
                is_python_by_name = any(keyword in proc_name for keyword in python_keywords)

                # 如果进程名没有匹配，再检查命令行（更慢的检查）
                if not is_python_by_name:
                    cmdline = proc_info.get('cmdline', [])
                    if not cmdline:
                        continue
                    is_python_by_name = any('python' in arg.lower() for arg in cmdline)

                if is_python_by_name:
                    # 为了性能考虑，我们只获取关键信息，延迟获取CPU和内存使用率
                    detailed_info = {
                        'pid': pid,
                        'name': proc_info['name'] or 'N/A',
                        'command_line': ' '.join(proc_info.get('cmdline', [])) if proc_info.get('cmdline') else 'N/A',
                        'create_time': datetime.fromtimestamp(proc_info['create_time']).strftime(
                            '%Y-%m-%d %H:%M:%S') if proc_info.get('create_time') else 'N/A',
                        'cpu_percent': proc.cpu_percent(interval=0.05) if proc.is_running() else 0,  # 使用较短的采样间隔
                        'memory_percent': round(proc.memory_percent(), 2) if proc.is_running() else 0,
                        'memory_rss': f"{proc_info['memory_info'].rss / 1024 / 1024:.2f} MB" if proc_info.get(
                            'memory_info') else 'N/A',
                        'status': proc_info.get('status', 'N/A'),
                        'username': proc.username() if hasattr(proc, 'username') else 'N/A',
                        'working_directory': proc.cwd() if hasattr(proc, 'cwd') else 'N/A'
                    }
                    python_processes.append(detailed_info)

            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue
            except Exception as e:
                continue

        # 发送信号更新UI
        self.python_processes_updated.emit(python_processes)
        return python_processes
    
    def _update_python_processes_cache(self, processes):
        """
        更新Python进程缓存
        """
        self.scan_mutex.lock()
        self.python_processes_cache = processes
        self.scan_mutex.unlock()
    
    def _on_python_processes_updated(self, processes):
        """
        处理Python进程更新信号
        """
        self._update_python_processes_cache(processes)
    
    # 自动进程扫描功能已移除，改用手动刷新
    

    
    # 停止所有进程功能已由进程列表中的统一停止方法替代
    
    def refresh_process_status(self):
        """刷新进程状态显示 - 手动触发后台扫描，带防抖机制"""
        # 防止重复点击导致多个扫描线程同时运行（内部状态管理，不改变按钮外观）
        if hasattr(self, 'is_scanning') and self.is_scanning:
            self._append_output("扫描已在进行中，请稍候...\n", "warning")
            return
        
        # 创建并启动后台扫描线程
        self.scan_thread = ProcessScanThread()
        # 连接处理完成信号
        self.scan_thread.result_ready.connect(self._on_process_scan_completed_and_reset_state)
        self.scan_thread.finished.connect(self._on_scan_thread_finished)  # 连接线程结束信号
        self.is_scanning = True  # 设置扫描状态
        self.scan_thread.start()
        
        # 显示扫描开始信息
        self._append_output("=== 开始扫描进程... ===\n", "info")
        # 不再禁用按钮，让用户可以随时点击，但内部仍防重复请求
    
    def _on_process_scan_completed_and_reset_state(self, python_processes):
        """处理进程扫描完成的回调并重置内部状态"""
        try:
            # 调用原来的处理函数
            self._on_process_scan_completed(python_processes)
        finally:
            # 重置扫描状态，允许下次点击
            self.is_scanning = False


    def _on_process_scan_completed(self, python_processes):
        """处理进程扫描完成的回调"""
        # 更新进程缓存
        self._update_python_processes_cache(python_processes)
        
        # 统一使用psutil扫描的结果
        python_count = len(python_processes)
        
        # 检查后端服务状态
        backend_running = self.backend_process and self.backend_process.poll() is None
        backend_status = "运行中" if backend_running else "已停止"
        
        # 计算总进程数（排除当前进程）
        all_pids = {proc['pid'] for proc in python_processes if proc['pid'] != os.getpid()}
        total_count = len(all_pids)
        
        # 刷新进程列表
        self._refresh_process_list()
        
        if total_count > 0:
            self._append_output(f"=== 当前运行中的进程 ({total_count} 个) ===\n", "info")
            
            # 显示所有Python进程（包括后端服务）
            for proc_info in python_processes:
                # 跳过当前进程
                if proc_info['pid'] == os.getpid():
                    continue
                # 检查是否是后端服务进程
                is_backend = backend_running and self.backend_process and proc_info['pid'] == self.backend_process.pid
                process_type = "后端服务" if is_backend else "Python进程"
                self._append_output(f"  • {proc_info['name']} (PID: {proc_info['pid']}) - {process_type}\n", "info")
        else:
            self._append_output("当前没有运行中的进程\n", "info")

    def _on_scan_thread_finished(self):
        """处理扫描线程结束事件"""
        # 重置扫描状态以允许下一次扫描
        self.is_scanning = False
    
    def _refresh_process_list(self):
        """刷新进程列表显示"""
        # 清空现有列表
        self.process_list.clear()
        
        # 获取所有Python进程信息（使用缓存，这已经包含了后端服务）
        python_processes = self.get_python_process_info()
        
        # 标记是否有后端服务进程
        backend_running = self.backend_process and self.backend_process.poll() is None
        backend_found_in_scan = False
        
        # 添加所有Python进程
        for proc_info in python_processes:
            # 排除当前进程
            if proc_info['pid'] == os.getpid():
                continue
            
            # 显示进程名和PID
            display_name = f"{proc_info['name']} (PID: {proc_info['pid']})"
            
            item = QListWidgetItem(display_name)
            item.setData(Qt.UserRole, {
                'type': 'python',
                'name': proc_info['name'],
                'pid': proc_info['pid'],
                'details': proc_info
            })
            # 添加详细信息作为工具提示
            tooltip_info = (
                f"进程名: {proc_info['name']}\n"
                f"PID: {proc_info['pid']}\n"
                f"命令行: {proc_info['command_line']}\n"
                f"CPU: {proc_info['cpu_percent']}%\n"
                f"内存: {proc_info['memory_rss']}\n"
                f"状态: {proc_info['status']}\n"
                f"启动时间: {proc_info['create_time']}"
            )
            item.setToolTip(tooltip_info)
            self.process_list.addItem(item)
        
        # 更新按钮状态
        has_processes = self.process_list.count() > 0
        self.stop_selected_btn.setEnabled(has_processes)
        self.stop_all_btn.setEnabled(has_processes)
        
        # 如果有进程，自动选择第一个
        if has_processes and self.process_list.currentRow() == -1:
            self.process_list.setCurrentRow(0)
    
    def _on_process_selection_changed(self, current_item, previous_item):
        """进程选择变化时的处理"""
        has_selection = current_item is not None
        self.stop_selected_btn.setEnabled(has_selection)
    
    def _on_process_double_clicked(self, item):
        """双击进程项时停止该进程"""
        self._stop_selected_process()
    

    
    def kill_python_process_by_pid(self, pid):
        """
        根据PID终止指定的Python进程 - 直接强制终止
        """
        current_pid = os.getpid()
        
        # 确认不是自身进程
        if pid == current_pid:
            self._append_output(f"无法终止自身进程 (PID: {pid})\n", "error")
            return False

        try:
            self._append_output(f"正在处理进程 PID: {pid}...\n", "info")

            # 获取进程对象
            proc = psutil.Process(pid)

            if not proc.is_running():
                self._append_output(f"进程 {pid} 已不存在，跳过\n", "warning")
                return True

            # 直接强制杀死
            proc.kill()
            proc.wait(timeout=2)
            self._append_output(f"⚠ 进程 {pid} 已强制终止\n", "warning")
            return True

        except psutil.NoSuchProcess:
            self._append_output(f"⚠ 进程 {pid} 已不存在\n", "warning")
            return True
        except psutil.AccessDenied:
            self._append_output(f"✗ 无权限操作进程 {pid}\n", "error")
            return False
        except Exception as e:
            self._append_output(f"✗ 处理进程 {pid} 时出错: {e}\n", "error")
            return False
    
    def stop_all_processes(self):
        """停止所有运行中的进程"""
        # 确认对话框
        from PySide6.QtWidgets import QMessageBox
        reply = QMessageBox.question(
            self,
            "确认停止全部",
            "确定要停止所有运行中的进程吗？",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            self._append_output("=== 停止所有进程 ===\n", "warning")
            
            # 停止所有统一管理的进程
            stopped_count = 0
            process_names = list(self.running_processes.keys())
            
            for process_name in process_names:
                if process_name in self.running_processes:
                    process_info = self.running_processes[process_name]
                    process = process_info['process']
                    
                    if process.poll() is None:  # 进程仍在运行
                        try:
                            # 获取进程PID
                            pid = process.pid
                            self._append_output(f"正在停止进程: {process_name} (PID: {pid})\n", "info")
                            
                            # 终止进程
                            process.kill()
                            process.wait(timeout=2)
                            
                            # 从进程管理中移除
                            del self.running_processes[process_name]
                            
                            self._append_output(f"✓ {process_name} 已停止\n", "info")
                            stopped_count += 1
                            
                        except Exception as e:
                            self._append_output(f"✗ 停止 {process_name} 时出错: {str(e)}\n", "error")
            
            # 停止所有Python进程
            python_processes = self.get_python_process_info()
            current_pid = os.getpid()
            
            for proc_info in python_processes:
                pid = proc_info['pid']
                if pid != current_pid:  # 不停止自己
                    process_name = proc_info['name']
                    
                    # 检查是否已经在统一管理中处理过
                    already_processed = False
                    for managed_name in process_names:
                        if managed_name in self.running_processes:
                            managed_pid = self.running_processes[managed_name]['process'].pid
                            if managed_pid == pid:
                                already_processed = True
                                break
                    
                    if not already_processed:
                        self._append_output(f"正在停止Python进程: {process_name} (PID: {pid})\n", "info")
                        success = self.kill_python_process_by_pid(pid)
                        if success:
                            stopped_count += 1
            
            self._append_output(f"=== 已停止 {stopped_count} 个进程 ===\n", "info")
            
            # 刷新进程列表状态
            self.refresh_process_status()

    def _stop_selected_process(self):
        """停止选中的进程"""
        current_item = self.process_list.currentItem()
        if not current_item:
            return
        
        process_data = current_item.data(Qt.UserRole)
        process_name = process_data['name']
        process_type = process_data['type']
        
        # 确认对话框
        from PySide6.QtWidgets import QMessageBox
        reply = QMessageBox.question(
            self,
            "确认停止",
            f"确定要停止进程 '{process_name}' 吗？",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            self._append_output(f"=== 停止进程: {process_name} ===\n", "warning")
            
            if process_type == 'backend':
                # 使用与普通Python进程相同的终止函数
                pid = process_data['pid']
                success = self.kill_python_process_by_pid(pid)
                if success:
                    self._append_output(f"✓ {process_name} (PID: {pid}) 已停止\n", "info")
                else:
                    self._append_output(f"✗ {process_name} (PID: {pid}) 停止失败\n", "error")
            elif process_type == 'python':
                # 使用psutil终止Python进程
                pid = process_data['pid']
                success = self.kill_python_process_by_pid(pid)
                if success:
                    self._append_output(f"✓ {process_name} (PID: {pid}) 已停止\n", "info")
                else:
                    self._append_output(f"✗ {process_name} (PID: {pid}) 停止失败\n", "error")
            else:
                # 停止外部进程
                success = self.stop_backend_service()
                if success:
                    self._append_output(f"✓ {process_name} 已停止\n", "info")
                else:
                    self._append_output(f"✗ {process_name} 停止失败\n", "error")
            
            # 刷新列表和状态
            self.refresh_process_status()
    
    def closeEvent(self, event):
        """窗口关闭事件 - 增强版进程终止"""
        # 自动进程扫描已移除，无需停止扫描线程
        
        # 统一获取所有Python进程
        python_processes = self.get_python_process_info()
        python_count = len(python_processes)
        
        if python_count > 0:
            # 停止所有Python进程
            for proc_info in python_processes:
                if proc_info['pid'] != os.getpid():  # 不停止自己
                    # 检查是否是后端服务进程
                    if (self.backend_process and 
                        self.backend_process.poll() is None and  # 进程仍在运行
                        proc_info['pid'] == self.backend_process.pid):
                        # 如果是后端服务进程，使用专门的方法停止
                        self.stop_backend_service()
                    else:
                        # 其他Python进程使用psutil方式终止
                        self.kill_python_process_by_pid(proc_info['pid'])
        
        # 确保主后端服务也被停止
        self.stop_backend_service()
    def get_recent_output(self, line_count=10):
        """获取最近的输出行"""
        try:
            # 获取输出文本框的内容
            text = self.output_text.toPlainText()
            if not text:
                return []
            
            # 按行分割并获取最后几行
            lines = text.split('\n')
            # 过滤空行并获取指定数量的行
            non_empty_lines = [line for line in lines if line.strip()]
            recent_lines = non_empty_lines[-line_count:] if len(non_empty_lines) > line_count else non_empty_lines
            
            return recent_lines
        except Exception as e:
            print(f"获取最近输出时出错: {e}")
            return []

        super().closeEvent(event)


if __name__ == "__main__":
    from PySide6.QtWidgets import QApplication, QMainWindow
    
    app = QApplication(sys.argv)
    
    # 创建主窗口
    window = QMainWindow()
    window.setWindowTitle("简化信息面板测试")
    window.setGeometry(100, 100, 800, 600)
    
    # 创建信息面板
    info_panel = SimpleInfoPanel()
    window.setCentralWidget(info_panel)
    
    window.show()
    sys.exit(app.exec())