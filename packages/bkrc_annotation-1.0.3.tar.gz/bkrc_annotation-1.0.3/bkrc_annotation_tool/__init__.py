"""图像标注工具包"""

__version__ = "1.0.0"
__author__ = "标注工具团队"

# 导入主要模块以方便使用
from .main import main
from .main_window import AnnotationTool

__all__ = ["main", "AnnotationTool"]