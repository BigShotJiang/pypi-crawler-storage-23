import os
import math


class AnnotationUtils:
    """标注工具通用工具类"""

    @staticmethod
    def get_annotation_file_paths(image_path):
        """获取图片对应的标注文件路径"""
        base_name = os.path.splitext(image_path)[0]
        return [base_name + '.json']

    @staticmethod
    def filter_files_by_extensions(folder_path, extensions=None):
        """根据后缀名筛选文件夹中的文件"""
        if extensions is None:
            extensions = ['.png', '.xpm', '.jpg', '.jpeg', '.bmp', '.tiff', '.gif']

        if not os.path.exists(folder_path):
            return []

        files = []
        for file in sorted(os.listdir(folder_path)):
            file_path = os.path.join(folder_path, file)
            if os.path.isfile(file_path):
                if os.path.splitext(file)[1].lower() in extensions:
                    files.append(file_path)
        return files

    @staticmethod
    def get_existing_labels(shapes):
        """提取形状列表中的唯一标签"""
        return sorted(list({shape.label.strip() for shape in shapes if shape.label.strip()}))

    @staticmethod
    def split_list_evenly(lst, n):
        """将列表均匀分成n份"""
        if n <= 0:
            return []

        avg = len(lst) // n
        remainder = len(lst) % n
        result = []
        start = 0

        for i in range(n):
            end = start + avg + (1 if i < remainder else 0)
            if start < len(lst):
                result.append(lst[start:end])
            else:
                result.append([])
            start = end
        return result

    @staticmethod
    def format_file_size(size_bytes):
        """格式化文件大小"""
        if size_bytes < 1024:
            return f"{size_bytes} B"
        elif size_bytes < 1024 * 1024:
            return f"{size_bytes / 1024:.1f} KB"
        elif size_bytes < 1024 * 1024 * 1024:
            return f"{size_bytes / (1024 * 1024):.1f} MB"
        else:
            return f"{size_bytes / (1024 * 1024 * 1024):.1f} GB"

    @staticmethod
    def normalize_path(path):
        """标准化文件路径"""
        return os.path.normpath(path)