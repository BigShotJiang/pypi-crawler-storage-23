
import os
import sys
import numpy as np
import cv2 as cv
from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *

# 延迟导入ONNX相关模块，避免DLL加载问题
def import_onnx_modules():
    """延迟导入ONNX相关模块"""
    try:
        from onnxruntime.quantization import (
            quantize_static,
            QuantType,
            QuantFormat,
            CalibrationDataReader
        )
        import onnx
        import onnxruntime as ort
        return quantize_static, QuantType, QuantFormat, CalibrationDataReader, onnx, ort
    except ImportError as e:
        raise ImportError(f"无法导入ONNX相关模块: {str(e)}\n请确保已安装: pip install onnx onnxruntime")


# --------------------------
# 校准数据读取器（支持中文路径）
# --------------------------
class CalibrationReader:
    def __init__(self, img_dir, max_samples=100):
        # 延迟导入ONNX模块
        _, _, _, CalibrationDataReader, _, _ = import_onnx_modules()
        # 继承CalibrationDataReader
        class _CalibrationReaderImpl(CalibrationDataReader):
            def __init__(self, img_dir, max_samples):
                super().__init__()
                all_img_paths = self._search_images(img_dir)
                self.img_paths = self._filter_valid_images(all_img_paths)[:max_samples]
                self.idx = 0
                self.input_name = "images"

                if not self.img_paths:
                    raise ValueError(f"校准目录 {img_dir} 中未找到可用图像！请检查路径或文件是否有效")
                print(f"已加载 {len(self.img_paths)} 张有效校准图像（支持中文路径）")

            def _search_images(self, root_dir):
                """递归搜索所有图像路径（支持中文）"""
                image_ext = (".jpg", ".jpeg", ".png", ".bmp", ".JPG", ".PNG")
                img_paths = []
                for dirpath, _, filenames in os.walk(root_dir):
                    for f in filenames:
                        if f.lower().endswith(image_ext):
                            img_path = os.path.join(dirpath, f)
                            img_paths.append(img_path)
                return img_paths

            def _read_image(self, img_path):
                """读取中文路径图像的核心方法"""
                try:
                    img_data = np.fromfile(img_path, dtype=np.uint8)
                    img = cv.imdecode(img_data, cv.IMREAD_COLOR)
                    return img
                except Exception as e:
                    print(f"读取图像 {img_path} 失败：{e}")
                    return None

            def _filter_valid_images(self, img_paths):
                """过滤有效图像（基于中文路径读取）"""
                valid_paths = []
                for path in img_paths:
                    img = self._read_image(path)
                    if img is not None:
                        valid_paths.append(path)
                    else:
                        print(f"警告：跳过无效图像：{path}")
                return valid_paths

            def preprocess(self, img_path):
                """预处理（使用支持中文路径的读取方法）"""
                img = self._read_image(img_path)
                img = cv.resize(img, (640, 640))
                img = img.astype(np.float32) / 255.0
                img = np.transpose(img, (2, 0, 1))  # HWC→CHW
                return np.expand_dims(img, axis=0)

            def get_next(self):
                """迭代返回校准数据"""
                while self.idx < len(self.img_paths):
                    current_path = self.img_paths[self.idx]
                    self.idx += 1
                    try:
                        data = {self.input_name: self.preprocess(current_path)}
                        return data
                    except Exception as e:
                        print(f"处理图像 {current_path} 时出错：{e}，已跳过")
                return None
        
        # 创建实际的读取器实例
        self._reader_impl = _CalibrationReaderImpl(img_dir, max_samples)
        
        # 将方法代理到实际实现
        self.get_next = self._reader_impl.get_next
        self.preprocess = self._reader_impl.preprocess
    def __init__(self, img_dir, max_samples=100):
        all_img_paths = self._search_images(img_dir)
        self.img_paths = self._filter_valid_images(all_img_paths)[:max_samples]
        self.idx = 0
        self.input_name = "images"

        if not self.img_paths:
            raise ValueError(f"校准目录 {img_dir} 中未找到可用图像！请检查路径或文件是否有效")
        print(f"已加载 {len(self.img_paths)} 张有效校准图像（支持中文路径）")

    def _search_images(self, root_dir):
        """递归搜索所有图像路径（支持中文）"""
        image_ext = (".jpg", ".jpeg", ".png", ".bmp", ".JPG", ".PNG")
        img_paths = []
        for dirpath, _, filenames in os.walk(root_dir):
            for f in filenames:
                if f.lower().endswith(image_ext):
                    img_path = os.path.join(dirpath, f)
                    img_paths.append(img_path)
        return img_paths

    def _read_image(self, img_path):
        """读取中文路径图像的核心方法"""
        try:
            img_data = np.fromfile(img_path, dtype=np.uint8)
            img = cv.imdecode(img_data, cv.IMREAD_COLOR)
            return img
        except Exception as e:
            print(f"读取图像 {img_path} 失败：{e}")
            return None

    def _filter_valid_images(self, img_paths):
        """过滤有效图像（基于中文路径读取）"""
        valid_paths = []
        for path in img_paths:
            img = self._read_image(path)
            if img is not None:
                valid_paths.append(path)
            else:
                print(f"警告：跳过无效图像：{path}")
        return valid_paths

    def preprocess(self, img_path):
        """预处理（使用支持中文路径的读取方法）"""
        img = self._read_image(img_path)
        img = cv.resize(img, (640, 640))
        img = img.astype(np.float32) / 255.0
        img = np.transpose(img, (2, 0, 1))  # HWC→CHW
        return np.expand_dims(img, axis=0)

    def get_next(self):
        """迭代返回校准数据"""
        while self.idx < len(self.img_paths):
            current_path = self.img_paths[self.idx]
            self.idx += 1
            try:
                data = {self.input_name: self.preprocess(current_path)}
                return data
            except Exception as e:
                print(f"处理图像 {current_path} 时出错：{e}，已跳过")
        return None


# --------------------------
# 量化工作线程
# --------------------------
class QuantizationThread(QThread):
    progress = Signal(str)
    finished = Signal(bool, str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.model_input = ""
        self.calibration_dir = ""
        self.model_output = ""
        self.excluded_nodes = []
        # 校准样本数参数，默认100
        self.max_calib_samples = 100

    def run(self):
        try:
            # 延迟导入ONNX模块
            quantize_static, QuantType, QuantFormat, _, _, ort = import_onnx_modules()
            
            self.progress.emit("开始量化过程...")

            # 1. 预处理ONNX模型
            self.progress.emit("预处理ONNX模型...")
            model_preprocessed = "./preprocessed_temp.onnx"
            import subprocess
            result = subprocess.run(
                [sys.executable, "-m", "onnxruntime.quantization.preprocess",
                 "--input", self.model_input,
                 "--output", model_preprocessed],
                capture_output=True,
                text=True
            )

            if result.returncode != 0:
                raise RuntimeError(f"预处理失败：{result.stderr}")

            if not os.path.exists(model_preprocessed):
                raise RuntimeError("预处理输出文件不存在")

            # 2. 初始化校准读取器，传入用户选择的样本数
            self.progress.emit(f"加载校准图像（共{self.max_calib_samples}张）...")
            calibration_reader = CalibrationReader(self.calibration_dir, self.max_calib_samples)

            # 3. 执行静态量化
            self.progress.emit("执行静态量化...")
            quantize_static(
                model_input=model_preprocessed,
                model_output=self.model_output,
                calibration_data_reader=calibration_reader,
                weight_type=QuantType.QInt8,
                activation_type=QuantType.QUInt8,
                quant_format=QuantFormat.QDQ,
                nodes_to_exclude=self.excluded_nodes,
                per_channel=False,
                reduce_range=True
            )

            # 4. 验证量化模型
            self.progress.emit("验证量化模型...")
            sess = ort.InferenceSession(self.model_output, providers=["CPUExecutionProvider"])
            input_name = sess.get_inputs()[0].name
            input_shape = sess.get_inputs()[0].shape
            test_input = np.random.rand(*input_shape).astype(np.float32)
            outputs = sess.run(None, {input_name: test_input})

            # 清理临时文件
            if os.path.exists(model_preprocessed):
                os.remove(model_preprocessed)

            self.progress.emit("量化完成！")
            self.finished.emit(True, f"量化成功！模型保存至：{self.model_output}")

        except ImportError as e:
            error_msg = f"依赖库缺失：{str(e)}"
            self.progress.emit(error_msg)
            self.finished.emit(False, error_msg)
        except Exception as e:
            error_msg = f"量化失败：{str(e)}"
            self.progress.emit(error_msg)
            self.finished.emit(False, error_msg)


# --------------------------
# 主界面
# --------------------------
class YOLOv8Quantizer(QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("YOLOv8 ONNX 量化工具")
        self.setGeometry(100, 100, 800, 600)

        # 创建中央部件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        # 主布局
        layout = QVBoxLayout(central_widget)

        # 模型路径选择
        model_group = QGroupBox("模型设置")
        model_layout = QVBoxLayout()

        # 输入模型
        input_layout = QHBoxLayout()
        input_layout.addWidget(QLabel("输入模型:"))
        self.input_model_edit = QLineEdit("best.onnx")
        input_layout.addWidget(self.input_model_edit)
        self.input_model_btn = QPushButton("浏览")
        self.input_model_btn.clicked.connect(self.browse_input_model)
        input_layout.addWidget(self.input_model_btn)
        model_layout.addLayout(input_layout)

        # 校准目录 + 校准样本数
        calib_layout = QHBoxLayout()
        calib_layout.addWidget(QLabel("校准数据目录:"))
        self.calib_dir_edit = QLineEdit(
            r"D:\迅雷下载\00-进迭时空模型量化案例\02-PyTorch\04-基于YOLOv8的水果分类\datasets\valid")
        calib_layout.addWidget(self.calib_dir_edit)
        self.calib_dir_btn = QPushButton("浏览")
        self.calib_dir_btn.clicked.connect(self.browse_calib_dir)
        calib_layout.addWidget(self.calib_dir_btn)
        # 校准样本数选择框
        calib_layout.addSpacing(20)
        calib_layout.addWidget(QLabel("校准样本数:"))
        self.max_calib_spin = QSpinBox()
        self.max_calib_spin.setRange(1, 2000)
        self.max_calib_spin.setValue(100)
        self.max_calib_spin.setFixedWidth(100)
        calib_layout.addWidget(self.max_calib_spin)
        model_layout.addLayout(calib_layout)

        # 输出模型
        output_layout = QHBoxLayout()
        output_layout.addWidget(QLabel("输出模型:"))
        self.output_model_edit = QLineEdit("yolov8n_quantized.onnx")
        output_layout.addWidget(self.output_model_edit)
        self.output_model_btn = QPushButton("浏览")
        self.output_model_btn.clicked.connect(self.browse_output_model)
        output_layout.addWidget(self.output_model_btn)
        model_layout.addLayout(output_layout)

        model_group.setLayout(model_layout)
        layout.addWidget(model_group)

        # 节点排除设置
        nodes_group = QGroupBox("节点排除设置")
        nodes_layout = QVBoxLayout()

        # 节点列表
        self.nodes_text = QTextEdit()
        self.nodes_text.setPlainText("""/model.22/Concat_3
/model.22/Split
/model.22/dfl/Reshape
/model.22/dfl/Transpose
/model.22/dfl/Softmax
/model.22/dfl/conv/Conv
/model.22/dfl/Reshape_1
/model.22/Slice
/model.22/Slice_1
/model.22/Sub
/model.22/Add_1
/model.22/Div_1
/model.22/Concat_4
/model.22/Mul_2
/model.22/Sigmoid
/model.22/Concat_5""")
        self.nodes_text.setMaximumHeight(150)
        nodes_layout.addWidget(QLabel("排除的节点列表（每行一个）:"))
        nodes_layout.addWidget(self.nodes_text)

        nodes_group.setLayout(nodes_layout)
        layout.addWidget(nodes_group)

        # 进度显示
        progress_group = QGroupBox("进度信息")
        progress_layout = QVBoxLayout()
        self.progress_text = QTextEdit()
        self.progress_text.setReadOnly(True)
        self.progress_text.setMaximumHeight(150)
        progress_layout.addWidget(self.progress_text)
        progress_group.setLayout(progress_layout)
        layout.addWidget(progress_group)

        # 开始按钮
        self.start_btn = QPushButton("开始量化")
        self.start_btn.clicked.connect(self.start_quantization)
        layout.addWidget(self.start_btn)

        # 量化线程
        self.quant_thread = QuantizationThread()
        self.quant_thread.progress.connect(self.update_progress)
        self.quant_thread.finished.connect(self.quantization_finished)

    def browse_input_model(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "选择输入模型", "", "ONNX Files (*.onnx)"
        )
        if file_path:
            self.input_model_edit.setText(file_path)

    def browse_calib_dir(self):
        dir_path = QFileDialog.getExistingDirectory(
            self, "选择校准数据目录"
        )
        if dir_path:
            self.calib_dir_edit.setText(dir_path)

    def browse_output_model(self):
        file_path, _ = QFileDialog.getSaveFileName(
            self, "保存输出模型", "", "ONNX Files (*.onnx)"
        )
        if file_path:
            self.output_model_edit.setText(file_path)

    def start_quantization(self):
        # 检查输入
        if not os.path.exists(self.input_model_edit.text()):
            QMessageBox.warning(self, "警告", "输入模型文件不存在！")
            return

        if not os.path.exists(self.calib_dir_edit.text()):
            QMessageBox.warning(self, "警告", "校准数据目录不存在！")
            return

        # 设置线程参数
        self.quant_thread.model_input = self.input_model_edit.text()
        self.quant_thread.calibration_dir = self.calib_dir_edit.text()
        self.quant_thread.model_output = self.output_model_edit.text()

        # 解析排除节点列表
        nodes_text = self.nodes_text.toPlainText()
        excluded_nodes = [line.strip() for line in nodes_text.split('\n') if line.strip()]
        self.quant_thread.excluded_nodes = excluded_nodes

        # 将界面选择的样本数传递给线程
        self.quant_thread.max_calib_samples = self.max_calib_spin.value()

        # 清空进度显示
        self.progress_text.clear()

        # 禁用开始按钮
        self.start_btn.setEnabled(False)
        self.start_btn.setText("量化中...")

        # 启动量化线程
        self.quant_thread.start()

    def update_progress(self, message):
        self.progress_text.append(message)
        # 滚动到底部
        scrollbar = self.progress_text.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())

    def quantization_finished(self, success, message):
        if success:
            QMessageBox.information(self, "成功", message)
        else:
            QMessageBox.critical(self, "错误", message)

        # 恢复开始按钮
        self.start_btn.setEnabled(True)
        self.start_btn.setText("开始量化")


# --------------------------
# 主函数
# --------------------------
def main():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")  # 使用Fusion样式，更简洁

    window = YOLOv8Quantizer()
    window.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()