import ipaddress  # 导入ipaddress模块
from datetime import datetime
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QGroupBox, QLabel,
    QLineEdit, QListWidget, QListWidgetItem, QPushButton,
    QProgressBar, QMessageBox, QApplication
)
from PySide6.QtCore import Qt

from .direct_detector import DirectDetector
from .network_utils import NetworkUtils


class DirectDetectionDialog(QDialog):
    """TCP程序IP探测对话框"""

    def __init__(self, detector, parent=None):
        super().__init__(parent)
        self.detector = detector
        self.parent_window = parent
        self.setWindowTitle("TCP程序IP探测工具")
        self.resize(500, 400)

        self.init_ui()

        # 连接信号
        self.detector.online_device.connect(self.add_online_device)
        self.detector.scan_progress.connect(self.update_progress)
        self.detector.scan_finished.connect(self.on_scan_finished)

    def init_ui(self):
        """初始化UI"""
        layout = QVBoxLayout(self)

        # 1. 探测配置区域
        scan_group = QGroupBox("探测配置")
        scan_layout = QVBoxLayout(scan_group)

        # 网络地址输入
        network_layout = QHBoxLayout()
        network_layout.addWidget(QLabel("探测网段:"))
        self.network_input = QLineEdit("192.168.224.0/24")
        self.network_input.setPlaceholderText("例如: 192.168.1.0/24 或 192.168.1.1-192.168.1.100")
        network_layout.addWidget(self.network_input)
        scan_layout.addLayout(network_layout)

        # 示例说明
        example_label = QLabel("示例: 192.168.1.0/24 (扫描1-254), 192.168.1.1-192.168.1.100 (扫描1-100)")
        example_label.setStyleSheet("color: gray; font-size: 10pt;")
        scan_layout.addWidget(example_label)

        layout.addWidget(scan_group)

        # 2. 进度显示
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setVisible(False)
        layout.addWidget(self.progress_bar)

        self.status_label = QLabel("准备就绪")
        layout.addWidget(self.status_label)

        # 3. 在线设备列表
        list_group = QGroupBox("已启动后端服务的IP列表")
        list_layout = QVBoxLayout(list_group)

        self.device_list = QListWidget()
        self.device_list.setSelectionMode(QListWidget.SelectionMode.MultiSelection)  # 修复：使用正确的枚举值
        list_layout.addWidget(self.device_list)

        # 列表操作按钮
        list_btn_layout = QHBoxLayout()
        self.select_all_btn = QPushButton("全选")
        self.select_all_btn.clicked.connect(self.select_all_devices)
        self.clear_selection_btn = QPushButton("清空选择")
        self.clear_selection_btn.clicked.connect(self.clear_selection)

        list_btn_layout.addWidget(self.select_all_btn)
        list_btn_layout.addWidget(self.clear_selection_btn)
        list_btn_layout.addStretch()
        list_layout.addLayout(list_btn_layout)

        layout.addWidget(list_group)

        # 4. 按钮区域
        button_layout = QHBoxLayout()

        self.scan_btn = QPushButton("开始探测")
        self.scan_btn.clicked.connect(self.start_scan)
        button_layout.addWidget(self.scan_btn)

        self.stop_btn = QPushButton("停止探测")
        self.stop_btn.clicked.connect(self.stop_scan)
        self.stop_btn.setEnabled(False)
        button_layout.addWidget(self.stop_btn)

        self.add_ips_btn = QPushButton("添加选中IP到列表")
        self.add_ips_btn.clicked.connect(self.add_selected_ips)
        self.add_ips_btn.setEnabled(False)
        button_layout.addWidget(self.add_ips_btn)

        close_btn = QPushButton("关闭")
        close_btn.clicked.connect(self.close)
        button_layout.addWidget(close_btn)

        layout.addLayout(button_layout)

    def start_scan(self):
        """开始探测"""
        network = self.network_input.text().strip()
        if not network:
            QMessageBox.warning(self, "警告", "请输入要探测的网段")
            return

        # 验证网络格式
        if not self.validate_network(network):
            QMessageBox.warning(self, "错误",
                                "网段格式不正确！\n\n正确格式：\n"
                                "1. CIDR格式: 192.168.1.0/24\n"
                                "2. 范围格式: 192.168.1.1-192.168.1.100\n"
                                "3. 单个IP: 192.168.1.100")
            return

        # 清空列表
        self.device_list.clear()
        self.add_ips_btn.setEnabled(False)

        # 显示进度条
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)

        # 更新按钮状态
        self.scan_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)

        self.status_label.setText(f"正在探测网络 {network}...")

        # 开始探测
        self.detector.scan_network(network)

    def stop_scan(self):
        """停止探测"""
        self.detector.stop_scan()
        self.status_label.setText("扫描已停止")

    def validate_network(self, network):
        """验证网络地址格式"""
        # CIDR格式
        if "/" in network:
            try:
                ipaddress.ip_network(network, strict=False)
                return True
            except:
                return False
        # 范围格式
        elif "-" in network:
            parts = network.split("-")
            if len(parts) != 2:
                return False
            try:
                ipaddress.ip_address(parts[0])
                ipaddress.ip_address(parts[1])
                return True
            except:
                return False
        # 单个IP
        else:
            try:
                ipaddress.ip_address(network)
                return True
            except:
                return False

    def add_online_device(self, ip):
        """添加探测到的IP到列表（去重）"""
        # 检查是否已经存在相同的IP
        existing_items = self.device_list.findItems(ip, Qt.MatchFlag.MatchExactly)
        if not existing_items:
            self.device_list.addItem(ip)

    def update_progress(self, completed, total):
        """更新进度"""
        if total > 0:
            progress = int((completed / total) * 100)
            self.progress_bar.setValue(progress)
            self.status_label.setText(f"扫描进度: {completed}/{total} ({progress}%)")

    def on_scan_finished(self):
        """扫描完成"""
        self.progress_bar.setValue(100)
        self.scan_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)

        device_count = self.device_list.count()
        if device_count > 0:
            self.add_ips_btn.setEnabled(True)
            self.status_label.setText(f"扫描完成！发现 {device_count} 个在线设备")
        else:
            self.status_label.setText("扫描完成！未发现在线设备")

    def select_all_devices(self):
        """全选设备"""
        self.device_list.selectAll()

    def clear_selection(self):
        """清空选择"""
        self.device_list.clearSelection()

    def add_selected_ips(self):
        """添加选中的IP到主窗口的IP列表"""
        selected_items = self.device_list.selectedItems()
        if not selected_items:
            QMessageBox.warning(self, "警告", "请至少选择一个IP")
            return

        added_count = 0
        for item in selected_items:
            ip = item.text()
            if self.parent_window and hasattr(self.parent_window, 'saved_ips'):
                if ip not in self.parent_window.saved_ips:
                    self.parent_window.saved_ips.append(ip)
                    added_count += 1

        QMessageBox.information(self, "成功",
                                f"已将 {added_count} 个IP添加到分发目标列表\n\n"
                                f"现在可以在分发文件时使用这些IP")

    def closeEvent(self, event):
        """关闭事件"""
        if self.detector.is_scanning:
            reply = QMessageBox.question(
                self,
                "确认关闭",
                "扫描正在进行中，确认要关闭吗？",
                QMessageBox.Yes | QMessageBox.No
            )
            if reply == QMessageBox.Yes:
                self.detector.stop_scan()
                event.accept()
            else:
                event.ignore()
        else:
            event.accept()