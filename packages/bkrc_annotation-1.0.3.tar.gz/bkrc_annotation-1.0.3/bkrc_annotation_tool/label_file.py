import json

from .shapes import Shape


class LabelFile:
    def __init__(self):
        self.shapes = []
        self.image_path = ""
        self.image_width = 0
        self.image_height = 0
        self.version = "4.5.6"
        self.flags = {}

    def load(self, filename):
        """加载标注文件"""
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                data = json.load(f)

            self.image_path = data.get("imagePath", "")
            self.image_width = data.get("imageWidth", 0)
            self.image_height = data.get("imageHeight", 0)
            self.version = data.get("version", "4.5.6")
            self.flags = data.get("flags", {})

            self.shapes = []
            for shape_data in data.get("shapes", []):
                try:
                    shape = Shape()
                    shape.load_from_dict(shape_data)
                    self.shapes.append(shape)
                except Exception as e:
                    print(f"警告: 跳过无法加载的形状: {str(e)}")
        except Exception as e:
            raise Exception(f"无法读取JSON文件: {str(e)}")

    def save(self, filename, shapes, image_path, image_height, image_width):
        """保存标注文件"""
        save_data = {
            "version": self.version,
            "flags": self.flags,
            "shapes": [shape.to_dict() for shape in shapes],
            "imagePath": image_path,
            "imageData": None,
            "imageHeight": image_height,
            "imageWidth": image_width
        }

        try:
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(save_data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            raise Exception(f"无法保存JSON文件: {str(e)}")