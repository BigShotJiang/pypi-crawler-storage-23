import os
import shutil
import random
from typing import List, Tuple, Dict, Optional, Callable
import yaml
from pathlib import Path


class DatasetSplitter:
    """
    数据集划分工具类，用于将数据集按比例划分为训练集、验证集和测试集
    """
    
    def __init__(self, source_dir: str):
        """
        初始化数据集划分器
        
        Args:
            source_dir: 源数据目录，应包含images和labels子目录
        """
        self.source_dir = Path(source_dir)
        self.images_dir = self.source_dir / "images"
        self.labels_dir = self.source_dir / "labels"
        
        if not self.images_dir.exists():
            raise ValueError(f"图像目录不存在: {self.images_dir}")
        
        if not self.labels_dir.exists():
            raise ValueError(f"标签目录不存在: {self.labels_dir}")
    
    def get_image_label_pairs(self) -> List[Tuple[Path, Path]]:
        """
        获取图像和标签的配对列表
        
        Returns:
            包含(图像路径, 标签路径)元组的列表
        """
        pairs = []
        
        # 支持常见的图像格式
        image_extensions = ['.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.webp']
        
        for img_file in self.images_dir.iterdir():
            if img_file.suffix.lower() in image_extensions:
                # 查找对应的标签文件（同名但扩展名为.txt）
                label_file = self.labels_dir / f"{img_file.stem}.txt"
                
                if label_file.exists():
                    pairs.append((img_file, label_file))
                else:
                    print(f"警告: 找不到 {img_file} 对应的标签文件")
        
        return pairs
    
    def split_dataset(
        self, 
        output_dir: str, 
        train_ratio: float = 0.7, 
        val_ratio: float = 0.2, 
        test_ratio: float = 0.1,
        seed: int = 42,
        progress_callback: Optional[Callable[[int, int], None]] = None
    ) -> Dict[str, int]:
        """
        划分数据集
        
        Args:
            output_dir: 输出目录
            train_ratio: 训练集比例
            val_ratio: 验证集比例
            test_ratio: 测试集比例
            seed: 随机种子
            progress_callback: 进度回调函数，接收当前进度和总进度作为参数
        
        Returns:
            各数据集的数量统计
        """
        # 验证比例总和
        total_ratio = train_ratio + val_ratio + test_ratio
        if abs(total_ratio - 1.0) > 1e-6:
            raise ValueError(f"比例之和必须等于1，当前为 {total_ratio}")
        
        # 设置随机种子
        random.seed(seed)
        
        # 获取图像-标签配对
        pairs = self.get_image_label_pairs()
        if not pairs:
            raise ValueError("没有找到任何图像-标签配对")
        
        print(f"总共找到 {len(pairs)} 个图像-标签配对")
        
        # 随机打乱数据
        random.shuffle(pairs)
        
        # 计算分割点
        total_count = len(pairs)
        train_end = int(total_count * train_ratio)
        val_end = train_end + int(total_count * val_ratio)
        
        # 分割数据集
        train_pairs = pairs[:train_end]
        val_pairs = pairs[train_end:val_end]
        test_pairs = pairs[val_end:]
        
        # 创建输出目录
        output_path = Path(output_dir)
        output_path.mkdir(exist_ok=True)
        
        # 创建子目录
        train_img_dir = output_path / "train" / "images"
        train_lbl_dir = output_path / "train" / "labels"
        val_img_dir = output_path / "val" / "images"
        val_lbl_dir = output_path / "val" / "labels"
        test_img_dir = output_path / "test" / "images"
        test_lbl_dir = output_path / "test" / "labels"
        
        # 创建所有需要的目录
        for dir_path in [train_img_dir, train_lbl_dir, val_img_dir, val_lbl_dir, test_img_dir, test_lbl_dir]:
            dir_path.mkdir(parents=True, exist_ok=True)
        
        # 合并所有数据集以便于进度跟踪
        all_pairs = []
        all_pairs.extend([(pair, 'train') for pair in train_pairs])
        all_pairs.extend([(pair, 'val') for pair in val_pairs])
        all_pairs.extend([(pair, 'test') for pair in test_pairs])
        
        # 复制所有文件并跟踪进度
        for i, ((img_path, lbl_path), dataset_type) in enumerate(all_pairs):
            # 根据数据集类型选择输出目录
            if dataset_type == 'train':
                img_output_dir = train_img_dir
                lbl_output_dir = train_lbl_dir
            elif dataset_type == 'val':
                img_output_dir = val_img_dir
                lbl_output_dir = val_lbl_dir
            else:  # test
                img_output_dir = test_img_dir
                lbl_output_dir = test_lbl_dir
            
            # 复制图像文件
            dest_img_path = img_output_dir / img_path.name
            shutil.copy2(img_path, dest_img_path)
            
            # 复制标签文件
            dest_lbl_path = lbl_output_dir / lbl_path.name
            shutil.copy2(lbl_path, dest_lbl_path)
            
            # 更新进度
            if progress_callback:
                progress_callback(i + 1, total_count)
        
        # 返回统计信息
        stats = {
            'train': len(train_pairs),
            'val': len(val_pairs),
            'test': len(test_pairs),
            'total': total_count
        }
        
        return stats
    
    def create_yaml_config(
        self, 
        output_path: str, 
        class_names: List[str], 
        train_path: str = "./train", 
        val_path: str = "./val", 
        test_path: str = "./test",
        use_absolute_path: bool = False
    ):
        """
        创建YOLO格式的data.yaml配置文件
        
        Args:
            output_path: 输出yaml文件路径
            class_names: 类别名称列表
            train_path: 训练集路径
            val_path: 验证集路径
            test_path: 测试集路径
            use_absolute_path: 是否使用绝对路径
        """
        # 如果使用绝对路径，则转换路径为绝对路径
        if use_absolute_path:
            output_dir = os.path.dirname(output_path)
            train_path = os.path.abspath(os.path.join(output_dir, train_path))
            val_path = os.path.abspath(os.path.join(output_dir, val_path))
            test_path = os.path.abspath(os.path.join(output_dir, test_path))
        
        data = {
            'train': train_path,
            'val': val_path,
            'test': test_path,
            'nc': len(class_names),  # 类别数量
            'names': class_names     # 类别名称列表
        }
        
        with open(output_path, 'w', encoding='utf-8') as f:
            yaml.dump(data, f, default_flow_style=False, allow_unicode=True)
        
        print(f"YAML配置文件已创建: {output_path}")


def split_dataset_from_folder(
    source_folder: str, 
    output_folder: str,
    train_ratio: float = 0.7,
    val_ratio: float = 0.2,
    test_ratio: float = 0.1,
    class_names: Optional[List[str]] = None,
    seed: int = 42,
    use_absolute_path: bool = False,
    progress_callback: Optional[Callable[[int, int], None]] = None
) -> Dict[str, int]:
    """
    从指定文件夹划分数据集的便捷函数
    
    Args:
        source_folder: 源文件夹路径，应包含images和labels子目录
        output_folder: 输出文件夹路径
        train_ratio: 训练集比例
        val_ratio: 验证集比例
        test_ratio: 测试集比例
        class_names: 类别名称列表（可选，如果提供则会生成data.yaml）
        seed: 随机种子
        use_absolute_path: 是否使用绝对路径
        progress_callback: 进度回调函数
    
    Returns:
        各数据集的数量统计
    """
    splitter = DatasetSplitter(source_folder)
    stats = splitter.split_dataset(
        output_dir=output_folder,
        train_ratio=train_ratio,
        val_ratio=val_ratio,
        test_ratio=test_ratio,
        seed=seed,
        progress_callback=progress_callback
    )
    
    # 如果提供了类别名称，则生成data.yaml
    if class_names:
        yaml_path = os.path.join(output_folder, "data.yaml")
        splitter.create_yaml_config(
            output_path=yaml_path,
            class_names=class_names,
            train_path="./train",
            val_path="./val",
            test_path="./test",
            use_absolute_path=use_absolute_path
        )
    
    return stats