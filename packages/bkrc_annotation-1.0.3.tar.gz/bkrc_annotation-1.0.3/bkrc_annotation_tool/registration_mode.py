import requests
import base64
from pathlib import Path
import cv2
import numpy as np
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


class XAnyLabelingClient:
    def __init__(self, base_url="http://127.0.0.1:8000", api_key=None):
        self.base_url = base_url
        self.headers = {"Content-Type": "application/json"}
        if api_key:
            self.headers["Token"] = api_key

        # 优化1：创建带连接池的Session，复用HTTP连接
        self.session = requests.Session()
        retry_strategy = Retry(
            total=3,  # 重试3次
            backoff_factor=0.3,  # 重试间隔递增：0.3s, 0.6s, 1.2s
            status_forcelist=[429, 500, 502, 503, 504],  # 需要重试的HTTP状态码
            allowed_methods=["POST", "GET"]
        )
        adapter = HTTPAdapter(
            max_retries=retry_strategy,
            pool_connections=10,  # 连接池大小
            pool_maxsize=10
        )
        self.session.mount("http://", adapter)
        self.session.headers.update(self.headers)

    def health(self):
        """检查服务器健康状态"""
        try:
            return self.session.get(f"{self.base_url}/health", timeout=2).json()
        except Exception as e:
            return {"status": "error", "message": f"无法连接到服务器: {str(e)}"}

    def list_models(self):
        """列出所有可用模型"""
        try:
            response = self.session.get(f"{self.base_url}/v1/models", timeout=2).json()
            if response.get("success") and "data" in response:
                # 只返回模型ID列表，类似于算法获取.py的方式
                data_content = response["data"]
                if isinstance(data_content, list):
                    # 如果data是列表，则从每个元素中提取id
                    model_ids = [model.get("id") for model in data_content if "id" in model]
                elif isinstance(data_content, dict):
                    # 如果data是字典，则返回其键
                    model_ids = list(data_content.keys())
                else:
                    model_ids = []
                return model_ids
            else:
                return []
        except Exception as e:
            return {"success": False, "message": f"连接服务器失败: {str(e)}"}

    def predict(self, inference_id, params=None):
        """
        运行推理（已删除image参数，使用NumPy生成假图片数据）
        :param inference_id: 模型ID
        :param params: 推理参数
        """
        # 优化2：降低JPG编码质量，减少数据量和编码耗时
        encode_params = [cv2.IMWRITE_JPEG_QUALITY, 80]  # 质量80（默认95）

        # --------------------------
        # 核心：NumPy生成模拟假图片数据（适配OpenCV格式）
        # 格式要求：uint8类型、BGR通道、形状为 (高度, 宽度, 3)，像素值0-255
        # 可自定义尺寸：建议和模型输入尺寸匹配（如YOLO常用640x640、640x480）
        # --------------------------
        img_height = 640  # 假图高度，可修改
        img_width = 640  # 假图宽度，可修改
        # 生成随机假图：np.random.randint生成0-255的整数，uint8是图像标准数据类型
        fake_img = np.random.randint(0, 256, (img_height, img_width, 3), dtype=np.uint8)

        # 将假图编码为JPG并转换为base64（和原真实图片处理逻辑一致）
        success, encoded_image = cv2.imencode('.jpg', fake_img, encode_params)
        if not success:
            return {"success": False, "message": "假图片编码失败"}
        img_base64 = base64.b64encode(encoded_image).decode()

        # 构建请求载荷 - 直接将参数合并到payload中
        payload = {
            "image": f"data:image/jpeg;base64,{img_base64}"
        }
        
        # 如果params存在，将其合并到payload中
        if params:
            payload.update(params)

        try:
            # 使用专用API端点，而非通用端点
            response = self.session.post(
                f"{self.base_url}/v1/predict/{inference_id}",
                json=payload,
                timeout=10.0  # 10秒超时（给模型加载和推理足够时间）
            )
            return response.json()
        except requests.exceptions.Timeout:
            return {"success": False, "message": "请求超时"}
        except Exception as e:
            return {"success": False, "message": f"请求失败: {str(e)}"}

    def close(self):
        """关闭Session，释放连接"""
        self.session.close()


# 使用示例（核心修改：让用户选择服务器返回的inference_id，增加输入异常处理）
if __name__ == "__main__":
    # 初始化客户端
    client = XAnyLabelingClient()

    # 检查服务健康状态
    health_status = client.health()
    print("=" * 50)
    print("服务健康状态:", health_status)
    print("=" * 50)

    if health_status.get("status") == "healthy":
        # 列出可用模型
        models = client.list_models()

        # 处理无可用模型的情况
        if not models:
            print("❌ 服务器未返回任何可用的inference_id，请检查服务端模型配置")
            client.close()
        else:
            # 打印带序号的可用模型列表（用户习惯从1开始计数）
            print("✅ 服务器返回可用inference_id列表：")
            for idx, model_id in enumerate(models, start=1):
                print(f"   [{idx}] {model_id}")
            print("-" * 50)

            # 循环让用户选择，直到输入合法
            while True:
                try:
                    # 获取用户输入的序号
                    select_num = int(input("请选择要使用的模型序号："))
                    # 检查序号是否在有效范围内
                    if 1 <= select_num <= len(models):
                        selected_model = models[select_num - 1]  # 转换为列表索引
                        break
                    else:
                        print(f"❌ 序号超出范围，请输入1-{len(models)}之间的数字！")
                except ValueError:
                    # 处理用户输入非数字的情况
                    print("❌ 输入无效，请输入纯数字序号！")

            # 打印用户选择的模型ID，确认选择
            print(f"✅ 你选择的模型ID：{selected_model}")
            print("-" * 50)

            # 执行模型推理（使用用户选择的inference_id，参数可自行修改）
            result = client.predict(
                inference_id=selected_model,  # 选择服务器支持的推理算法
                params={
                    "conf_threshold": 0.3,
                    "iou_threshold": 0.5,
                    "model_abs_path": r"C:\download\客户端_服务端\bkrc-Data-annotation-tool-Server-main20点05分\bkrc-Data-annotation-tool-Server-main2026年1月14日11点12分\bkrc-Data-annotation-tool-Server-main\app\server_model_file\model.onnx",#本地模型
                    "classes": ["1", "2", "3", "4", "5"],#类别
                    "instance_name": "my_custom_yolo_instance"#实例名称
                }
            )

            # 打印推理结果
            print("📊 模型推理结果：")
            print(result)
            print("=" * 50)
            print("推理已完成（使用NumPy模拟假图片）")
    else:
        print("❌ 无法连接到bkrc-Data-annotation-tool服务，请确保服务已启动")
        print("💡 启动命令参考: bkrc-Data-annotation-tool --host 0.0.0.0 --port 8000")

    # 最后关闭session，释放连接
    client.close()
