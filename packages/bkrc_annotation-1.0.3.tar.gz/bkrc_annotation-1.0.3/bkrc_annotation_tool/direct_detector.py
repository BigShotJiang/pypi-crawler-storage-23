import socket
import threading
import ipaddress
from concurrent.futures import ThreadPoolExecutor

from PySide6.QtCore import QObject, Signal


class DirectDetector(QObject):
    """TCP程序IP探测工具 - 用于探测运行后端服务的设备"""

    online_device = Signal(str)  # 发现在线设备信号
    scan_progress = Signal(int, int)  # 扫描进度信号
    scan_finished = Signal()  # 扫描完成信号

    def __init__(self, port=8888):
        super().__init__()
        self.port = port
        self.running = True
        self.is_scanning = False
        self.stop_flag = threading.Event()

    def scan_network(self, network):
        """异步多线程探测网段内启动了后端服务的IP"""
        if self.is_scanning:
            return

        self.is_scanning = True
        self.stop_flag.clear()

        threading.Thread(target=self._scan_thread, args=(network,), daemon=True).start()

    def _scan_thread(self, network):
        """扫描线程"""
        try:
            # 解析网段
            if "/" in network:
                prefix = network.split("/")[0].rsplit(".", 1)[0]
                ips = [f"{prefix}.{i}" for i in range(1, 255)]
            elif "-" in network:
                prefix = network.split("-")[0].rsplit(".", 1)[0]
                start, end = network.split("-")[0].rsplit(".", 1)[1], network.split("-")[1]
                ips = [f"{prefix}.{i}" for i in range(int(start), int(end) + 1)]
            else:
                ips = [network]

            # 获取本机IP（用于跳过）
            def get_local_ips():
                local_ips = []
                try:
                    hostname = socket.gethostname()
                    for ip in socket.gethostbyname_ex(hostname)[2]:
                        if not ip.startswith("127."):
                            local_ips.append(ip)
                except:
                    pass
                return local_ips

            local_ips = get_local_ips()

            # 单个IP探测逻辑（异步执行）
            def check_ip(ip):
                if self.stop_flag.is_set() or ip in local_ips:
                    return
                try:
                    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    sock.settimeout(1.5)  # 缩短超时，提升扫描速度
                    sock.connect((ip, self.port))
                    sock.sendall("TEST_PING".encode('utf-8'))
                    response = sock.recv(1024)
                    if response.decode('utf-8') == "TEST_PONG":
                        self.online_device.emit(ip)
                    sock.close()
                except:
                    pass

            total_ips = len(ips)
            completed = 0

            # 异步多线程探测（线程池优化，提升并发效率）
            with ThreadPoolExecutor(max_workers=100) as executor:
                for _ in executor.map(check_ip, ips):
                    completed += 1
                    if self.stop_flag.is_set():
                        break
                    progress = int((completed / total_ips) * 100)
                    self.scan_progress.emit(completed, total_ips)

        except Exception as e:
            print(f"扫描出错: {e}")
        finally:
            self.is_scanning = False
            self.scan_finished.emit()

    def stop_scan(self):
        """停止扫描"""
        if self.is_scanning:
            self.stop_flag.set()
            self.is_scanning = False