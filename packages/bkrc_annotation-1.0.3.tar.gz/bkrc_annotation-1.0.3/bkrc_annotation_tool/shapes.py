import math
from PySide6.QtCore import QPointF
from PySide6.QtGui import QColor, QPen, QPainterPath, QFont
from PySide6.QtCore import QRectF

from .color_utils import ColorUtils


class Shape:
    def __init__(self, label="", shape_type="rectangle"):
        self.label = label
        self.shape_type = shape_type
        self.points = []
        self.scale = 1.0
        self.selected = False
        self.flags = {}
        self.group_id = None
        self.other_data = {}
        self.closed = False
        
        # 旋转框参数
        self.direction = 0  # 旋转角度（弧度）
        self.center = None  # 中心点

        self.line_color = ColorUtils.get_color_for_label(label)
        self.fill_color = QColor(self.line_color.red(),
                                 self.line_color.green(),
                                 self.line_color.blue(),
                                 30)

    def add_point(self, point):
        # 为兼容AI检测结果，矩形不再限制只能两个点
        # AI检测返回的矩形可能已经转换为四个点的格式
        if self.shape_type == "rectangle":
            # 对于AI检测返回的矩形，可能已经是四个点的格式
            self.points.append(point)
        elif self.shape_type == "rotation":
            if len(self.points) < 2:
                self.points.append(point)
            elif len(self.points) == 2:  # 已有两个点，计算另外两个点形成旋转矩形
                # 计算矩形的宽度和高度
                width = abs(self.points[1].x() - self.points[0].x())
                height = abs(self.points[1].y() - self.points[0].y())
                
                # 根据前两个点的位置确定矩形的四个顶点
                x1, y1 = self.points[0].x(), self.points[0].y()
                x2, y2 = self.points[1].x(), self.points[1].y()
                
                # 确定其他两个点的位置
                p3 = QPointF(x2, y1)  # 第三个点
                p4 = QPointF(x1, y2)  # 第四个点
                
                # 将所有四个点加入列表
                self.points = [self.points[0], QPointF(x2, y1), self.points[1], QPointF(x1, y2)]
        else:
            self.points.append(point)

    def close(self):
        """关闭形状，对于多边形确保首尾点连接形成闭合环"""
        if self.shape_type == "polygon" and len(self.points) >= 3:
            # 对于多边形，检查首尾点是否已经连接
            first_point = self.points[0]
            last_point = self.points[-1]
            
            # 检查首尾点是否已经很接近
            distance = math.hypot(
                first_point.x() - last_point.x(),
                first_point.y() - last_point.y()
            )
            
            # 如果首尾点不重合，则在绘制时显式连接，但不添加新点到points列表
            # 这样可以与其他工具保持兼容
            pass
        elif self.shape_type == "rotation" and len(self.points) == 2:
            # 对于旋转框，如果有2个点，计算另外2个点形成完整的四边形
            x1, y1 = self.points[0].x(), self.points[0].y()
            x2, y2 = self.points[1].x(), self.points[1].y()
            
            # 确定其他两个点的位置以形成矩形
            # 根据两点确定的对角线，生成完整的矩形
            p3 = QPointF(x2, y1)  # 第三个点
            p4 = QPointF(x1, y2)  # 第四个点
            
            # 将所有四个点加入列表
            self.points = [self.points[0], QPointF(x2, y1), self.points[1], QPointF(x1, y2)]
            
            # 计算中心点
            cx = (x1 + x2) / 2
            cy = (y1 + y2) / 2
            self.center = QPointF(cx, cy)
        elif self.shape_type == "rotation" and len(self.points) == 4:
            # 如果已经有4个点，计算中心点
            cx = sum(p.x() for p in self.points) / 4
            cy = sum(p.y() for p in self.points) / 4
            self.center = QPointF(cx, cy)
            
        self.closed = True

    def contains_point(self, point, threshold=10):
        """判断点是否在形状内"""
        if not self.points:
            return False

        x_coords = [p.x() for p in self.points]
        y_coords = [p.y() for p in self.points]

        if self.shape_type == "rectangle":
            return (min(x_coords) - threshold <= point.x() <= max(x_coords) + threshold and
                    min(y_coords) - threshold <= point.y() <= max(y_coords) + threshold)
        elif self.shape_type == "rotation":
            # 对于旋转框，使用多边形的点在内部算法
            if len(self.points) >= 4:
                inside = False
                n = len(self.points)
                for i in range(n):
                    j = (i + 1) % n
                    xi, yi, xj, yj = x_coords[i], y_coords[i], x_coords[j], y_coords[j]
                    if ((yi > point.y()) != (yj > point.y())):
                        x_intersect = (point.y() - yi) * (xj - xi) / (yj - yi) + xi
                        if point.x() <= x_intersect:
                            inside = not inside
                return inside
            else:
                # 如果点数不足4个，使用最小边界框检测
                return (min(x_coords) - threshold <= point.x() <= max(x_coords) + threshold and
                        min(y_coords) - threshold <= point.y() <= max(y_coords) + threshold)
        elif self.shape_type == "circle" and len(self.points) >= 2:
            cx, cy = self.points[0].x(), self.points[0].y()
            radius = math.hypot(self.points[1].x() - cx, self.points[1].y() - cy)
            return math.hypot(point.x() - cx, point.y() - cy) <= radius + threshold
        elif self.shape_type == "line" and len(self.points) >= 2:
            x1, y1, x2, y2 = x_coords[0], y_coords[0], x_coords[1], y_coords[1]
            numerator = abs((y2 - y1) * point.x() - (x2 - x1) * point.y() + x2 * y1 - y2 * x1)
            denominator = math.hypot(y2 - y1, x2 - x1)
            return (numerator / denominator) <= threshold if denominator != 0 else False
        elif self.shape_type == "point":
            return math.hypot(point.x() - x_coords[0], point.y() - y_coords[0]) <= threshold
        elif self.shape_type == "polygon" and len(self.points) >= 3:
            inside = False
            n = len(self.points)
            for i in range(n):
                j = (i + 1) % n
                xi, yi, xj, yj = x_coords[i], y_coords[i], x_coords[j], y_coords[j]
                if ((yi > point.y()) != (yj > point.y())):
                    x_intersect = (point.y() - yi) * (xj - xi) / (yj - yi) + xi
                    if point.x() <= x_intersect:
                        inside = not inside
            return inside
        return False

    def paint(self, painter):
        """绘制形状"""
        if not self.points:
            return

        if self.selected:
            pen_color = ColorUtils.get_lighter_color(self.line_color)
            pen_width = 3.0 / self.scale if self.scale > 0 else 3.0
        else:
            pen_color = self.line_color
            pen_width = 2.0 / self.scale if self.scale > 0 else 2.0

        painter.setPen(QPen(pen_color, pen_width))

        if self.selected:
            fill_color = QColor(self.fill_color.red(),
                                self.fill_color.green(),
                                self.fill_color.blue(),
                                50)
        else:
            fill_color = self.fill_color

        painter.setBrush(fill_color)

        if self.shape_type == "rectangle" and len(self.points) >= 2:
            painter.drawRect(QRectF(min(self.points, key=lambda p: p.x()).x(),
                                    min(self.points, key=lambda p: p.y()).y(),
                                    max(self.points, key=lambda p: p.x()).x() - min(self.points,
                                                                                    key=lambda p: p.x()).x(),
                                    max(self.points, key=lambda p: p.y()).y() - min(self.points,
                                                                                    key=lambda p: p.y()).y()))
        elif self.shape_type == "rotation":
            # 绘制旋转框，这是一个四边形
            if len(self.points) >= 4:
                path = QPainterPath()
                path.moveTo(self.points[0])
                for p in self.points[1:]:
                    path.lineTo(p)
                path.lineTo(self.points[0])  # 闭合路径
                painter.drawPath(path)
                
                # 绘制旋转框的中心点，以便用户识别这是旋转框
                if len(self.points) == 4:
                    # 计算中心点
                    center_x = (self.points[0].x() + self.points[2].x()) / 2
                    center_y = (self.points[0].y() + self.points[2].y()) / 2
                    center_point = QPointF(center_x, center_y)
                    
                    # 绘制中心点（红色圆圈）
                    old_pen = painter.pen()
                    painter.setPen(QPen(QColor(255, 0, 0), max(2, int(3 / self.scale))))  # 红色圆圈
                    radius = max(3, int(5 / self.scale))  # 半径随缩放变化
                    painter.drawEllipse(center_point, radius, radius)
                    painter.setPen(old_pen)  # 恢复原来的画笔
            elif len(self.points) == 2:
                # 如果只有2个点，绘制一个临时矩形
                painter.drawRect(QRectF(min(self.points, key=lambda p: p.x()).x(),
                                        min(self.points, key=lambda p: p.y()).y(),
                                        max(self.points, key=lambda p: p.x()).x() - min(self.points,
                                                                                        key=lambda p: p.x()).x(),
                                        max(self.points, key=lambda p: p.y()).y() - min(self.points,
                                                                                        key=lambda p: p.y()).y()))
        elif self.shape_type == "circle" and len(self.points) >= 2:
            cx, cy = self.points[0].x(), self.points[0].y()
            radius = math.hypot(self.points[1].x() - cx, self.points[1].y() - cy)
            painter.drawEllipse(QPointF(cx, cy), radius, radius)
        elif self.shape_type == "line" and len(self.points) >= 2:
            painter.drawLine(self.points[0], self.points[1])
        elif self.shape_type == "point":
            painter.drawEllipse(self.points[0], 5, 5)
        elif self.shape_type == "polygon":
            path = QPainterPath()
            path.moveTo(self.points[0])
            for p in self.points[1:]:
                path.lineTo(p)
            if self.closed and len(self.points) >= 3:
                path.lineTo(self.points[0])  # 显式连接到最后一个点以确保闭合
            painter.drawPath(path)

        # 绘制标签
        if self.label:
            center_x = sum(p.x() for p in self.points) / len(self.points)
            center_y = sum(p.y() for p in self.points) / len(self.points)

            text_color = ColorUtils.get_contrast_color(self.line_color)
            painter.setPen(QPen(text_color, 1))
            painter.setFont(QFont("Arial", 12))
            painter.drawText(QPointF(center_x, center_y), self.label)

    def to_dict(self):
        """转换为字典"""
        if self.shape_type == "rectangle" and len(self.points) >= 2:
            min_x = min(p.x() for p in self.points)
            min_y = min(p.y() for p in self.points)
            max_x = max(p.x() for p in self.points)
            max_y = max(p.y() for p in self.points)
            points = [[min_x, min_y], [max_x, min_y], [max_x, max_y], [min_x, max_y]]
        elif self.shape_type == "rotation":
            # 对于旋转框，保存所有点的坐标
            points = [[p.x(), p.y()] for p in self.points]
        elif self.shape_type == "polygon" and self.closed and len(self.points) >= 3:
            # 对于闭合多边形，为了与其他工具兼容，可以添加第一个点作为最后一个点
            # 但这里我们保持简洁，只保存原始顶点
            points = [[p.x(), p.y()] for p in self.points]
        else:
            points = [[p.x(), p.y()] for p in self.points]

        result = {
            "label": self.label,
            "shape_type": self.shape_type,
            "flags": self.flags,
            "group_id": self.group_id,
            "points": points,
            "closed": self.closed,
            "line_color": self.line_color.name(),
            "fill_color": self.fill_color.name(),
            **self.other_data
        }
        
        # 如果是旋转框，添加方向信息
        if self.shape_type == "rotation":
            result["direction"] = self.direction
        
        return result

    def load_from_dict(self, data):
        """从字典加载"""
        self.label = data.get("label", "")
        self.shape_type = data.get("shape_type", "rectangle")
        self.flags = data.get("flags", {})
        self.group_id = data.get("group_id", None)
        
        # 重要修复：对于多边形，默认认为3个或更多点的多边形是闭合的
        # 这与bkrc-Data-annotation-tool等工具的行为保持一致
        if data.get("shape_type", "rectangle") == "polygon":
            points_data = data.get("points", [])
            self.closed = data.get("closed", len(points_data) >= 3)  # 如果没有明确指定closed，默认3点以上的多边形为闭合
        else:
            self.closed = data.get("closed", False)
        
        # 如果是旋转框，加载方向信息
        if self.shape_type == "rotation":
            self.direction = data.get("direction", 0)
        
        self.other_data = {k: v for k, v in data.items()
                           if k not in ["label", "shape_type", "flags", "group_id", "points",
                                        "line_color", "fill_color", "closed", "direction"]}

        line_color_str = data.get("line_color")
        if line_color_str:
            self.line_color = QColor(line_color_str)
        else:
            self.line_color = ColorUtils.get_color_for_label(self.label)

        fill_color_str = data.get("fill_color")
        if fill_color_str:
            self.fill_color = QColor(fill_color_str)
            if self.fill_color.alpha() == 255:
                self.fill_color.setAlpha(30)
        else:
            self.fill_color = QColor(self.line_color.red(),
                                     self.line_color.green(),
                                     self.line_color.blue(),
                                     30)

        points_data = data.get("points", [])
        self._original_points_data = points_data
        raw_points = [QPointF(float(p[0]), float(p[1])) for p in points_data]
        
        # 对于多边形，进行额外的点清理处理
        if self.shape_type == "polygon" and raw_points:
            cleaned_points = [raw_points[0]]  # 添加第一个点
            
            # 遍历剩余点，移除连续的重复点
            for i in range(1, len(raw_points)):
                prev_point = raw_points[i-1]
                curr_point = raw_points[i]
                
                # 检查当前点是否与前一点相同（使用小阈值判断）
                distance = math.hypot(
                    curr_point.x() - prev_point.x(),
                    curr_point.y() - prev_point.y()
                )
                
                if distance > 1e-5:  # 如果不是重复点，则添加
                    cleaned_points.append(curr_point)
            
            # 检查是否是闭合多边形，且首尾点重复
            if self.closed and len(cleaned_points) >= 3:
                first_point = cleaned_points[0]
                last_point = cleaned_points[-1]
                distance = math.hypot(
                    first_point.x() - last_point.x(),
                    first_point.y() - last_point.y()
                )
                # 如果首尾点几乎重合（距离小于阈值），则移除最后一个重复点
                if distance < 1e-5:
                    cleaned_points = cleaned_points[:-1]
            
            self.points = cleaned_points
        elif self.shape_type == "rotation":
            # 对于旋转框，直接使用原始点
            self.points = raw_points
        else:
            self.points = raw_points
        
        if self.shape_type == "rectangle" and len(self.points) >= 2:
            min_x = min(p.x() for p in self.points)
            min_y = min(p.y() for p in self.points)
            max_x = max(p.x() for p in self.points)
            max_y = max(p.y() for p in self.points)
            self.points = [QPointF(min_x, min_y), QPointF(max_x, max_y)]
        # 注意：对于polygon类型，我们保留原始的所有点，不做任何修改
        # 对于rotation类型，我们也保留原始的所有点