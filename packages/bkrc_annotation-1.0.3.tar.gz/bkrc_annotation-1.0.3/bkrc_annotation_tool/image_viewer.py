import math
import os
from PySide6.QtWidgets import (
    QLabel, QDialog, QVBoxLayout, QLineEdit, QListWidget,
    QDialogButtonBox, QListWidgetItem, QApplication
)
from PySide6.QtGui import (
    QPainter, QPen, QColor, QFont, QPainterPath, QPixmap,
    QCursor, QMouseEvent
)
from PySide6.QtCore import (
    Qt, QPointF, QRectF, QRect, QEvent, Signal
)

from .annotation_utils import AnnotationUtils
from .color_utils import ColorUtils
from .shapes import Shape


class ImageViewer(QLabel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAlignment(Qt.AlignCenter)
        self.setMinimumSize(400, 300)
        self.setFocusPolicy(Qt.StrongFocus)
        self.setMouseTracking(True)

        self.pixmap = None
        self.scale_factor = 1.0
        self.original_width = 0
        self.original_height = 0
        self.image_rect = QRectF()

        self.shapes = []
        self.current_shape = None
        self.drawing = False
        self.selected_shape = None
        self.hover_shape = None
        self.mode = "rectangle"
        self.start_point = None

        self.is_panning = False
        self.pan_start_pos = None
        self.pan_start_scroll = None
        
        # 添加拖动和调整大小的状态变量
        self.is_dragging = False
        self.is_resizing = False
        self.drag_start_pos = None
        self.resize_handle_index = -1
        self.resize_start_pos = None
        
        # 添加形状修改信号
        self.shapes_modified = None

    def map_to_image_coords(self, pos):
        """显示坐标转原始图像坐标"""
        if self.pixmap is None:
            return QPointF(pos)

        scaled_width = self.pixmap.width() * self.scale_factor
        scaled_height = self.pixmap.height() * self.scale_factor

        offset_x = max(0, (self.width() - scaled_width) / 2)
        offset_y = max(0, (self.height() - scaled_height) / 2)

        self.image_rect = QRectF(offset_x, offset_y, scaled_width, scaled_height)

        x = max(0, min((pos.x() - offset_x) / self.scale_factor, self.original_width - 1))
        y = max(0, min((pos.y() - offset_y) / self.scale_factor, self.original_height - 1))

        return QPointF(x, y)

    def map_from_image_coords(self, pos):
        """原始图像坐标转显示坐标"""
        if self.pixmap is None:
            return QPointF(pos)

        scaled_width = self.pixmap.width() * self.scale_factor
        scaled_height = self.pixmap.height() * self.scale_factor

        offset_x = max(0, (self.width() - scaled_width) / 2)
        offset_y = max(0, (self.height() - scaled_height) / 2)

        return QPointF(pos.x() * self.scale_factor + offset_x, pos.y() * self.scale_factor + offset_y)

    def load_image(self, image_path):
        """加载图像"""
        # 保存当前模式
        current_mode = self.mode
        
        try:
            self.pixmap = QPixmap(image_path) if os.path.exists(image_path) else None
            if self.pixmap and not self.pixmap.isNull():
                self.original_width = self.pixmap.width()
                self.original_height = self.pixmap.height()
            else:
                self.original_width = 0
                self.original_height = 0
                self.pixmap = None

            self.shapes = []
            self.scale_factor = 1.0
            self.selected_shape = None
            self.hover_shape = None
            self.current_shape = None
            self.drawing = False
            # 恢复之前保存的模式，而不是总是设为"rectangle"
            self.mode = current_mode
            self.start_point = None

            self.update_display()
            self.update()
        except Exception as e:
            print(f"加载图片失败: {e}")
            self.pixmap = None
            self.update_display()

    def update_display(self):
        """更新显示"""
        if self.pixmap and not self.pixmap.isNull():
            scaled_width = int(self.pixmap.width() * self.scale_factor)
            scaled_height = int(self.pixmap.height() * self.scale_factor)

            scaled_pixmap = self.pixmap.scaled(
                scaled_width,
                scaled_height,
                Qt.KeepAspectRatio,
                Qt.SmoothTransformation
            )
            self.setPixmap(scaled_pixmap)
            self.setMinimumSize(scaled_width, scaled_height)
        else:
            self.clear()
            self.setText("未加载图像")
            self.setMinimumSize(400, 300)

    def zoom_in(self):
        """放大"""
        self.scale_factor *= 1.2
        self.update_display()

    def zoom_out(self):
        """缩小"""
        self.scale_factor /= 1.2
        self.update_display()

    def reset_zoom(self):
        """重置缩放"""
        self.scale_factor = 1.0
        self.update_display()

    def wheelEvent(self, event):
        """滚轮事件"""
        if event.modifiers() & Qt.ControlModifier and self.pixmap:
            mouse_pos = event.position().toPoint()
            original_image_pos = self.map_to_image_coords(mouse_pos)

            scroll_area = self.parent().parent()
            h_bar = scroll_area.horizontalScrollBar()
            v_bar = scroll_area.verticalScrollBar()
            h_val, v_val = h_bar.value(), v_bar.value()

            if event.angleDelta().y() > 0:
                self.scale_factor *= 1.2
            else:
                self.scale_factor /= 1.2

            self.scale_factor = max(0.1, min(self.scale_factor, 10.0))
            self.update_display()

            new_widget_pos = self.map_from_image_coords(original_image_pos)
            h_bar.setValue(h_val + int(new_widget_pos.x() - mouse_pos.x()))
            v_bar.setValue(v_val + int(new_widget_pos.y() - mouse_pos.y()))

            event.accept()
        else:
            super().wheelEvent(event)

    def mousePressEvent(self, event):
        """鼠标按下事件"""
        if not self.pixmap:
            return

        pos = self.map_to_image_coords(event.pos())

        if event.button() == Qt.LeftButton:
            if event.modifiers() & Qt.ShiftModifier:
                self.is_panning = True
                self.pan_start_pos = event.pos()
                self.pan_start_scroll = self.get_scrollbar_values()
                self.setCursor(QCursor(Qt.ClosedHandCursor))
            else:
                # 检查是否点击在调整大小的控制点上（只使用悬停的形状）
                if self.hover_shape:
                    handle_index = self.get_handle_index_at(pos, self.hover_shape)
                    if handle_index != -1:
                        # 开始调整大小
                        self.is_resizing = True
                        self.resize_handle_index = handle_index
                        self.resize_start_pos = pos
                        self.drawing = False
                    else:
                        # 开始拖动
                        self.is_dragging = True
                        self.drag_start_pos = pos
                        self.drawing = False
                else:
                    self.drawing = True
                    self._start_drawing_shape(pos)
        elif event.button() == Qt.RightButton:
            self._handle_right_click()

        self.update()

    def mouseMoveEvent(self, event):
        """鼠标移动事件"""
        if not self.pixmap:
            return

        pos = self.map_to_image_coords(event.pos())

        if self.is_panning and self.pan_start_pos:
            delta = event.pos() - self.pan_start_pos
            scroll_area = self.parent().parent()
            h_bar = scroll_area.horizontalScrollBar()
            v_bar = scroll_area.verticalScrollBar()

            if self.pan_start_scroll:
                h_bar.setValue(self.pan_start_scroll[0] - delta.x())
                v_bar.setValue(self.pan_start_scroll[1] - delta.y())
        elif self.is_dragging and self.hover_shape and self.drag_start_pos:
            # 拖动形状
            delta_x = pos.x() - self.drag_start_pos.x()
            delta_y = pos.y() - self.drag_start_pos.y()

            # 移动所有点
            for i, point in enumerate(self.hover_shape.points):
                new_x = point.x() + delta_x
                new_y = point.y() + delta_y
                self.hover_shape.points[i] = QPointF(new_x, new_y)

            # 更新起始位置，以便继续拖动
            self.drag_start_pos = pos
        elif self.is_resizing and self.hover_shape and self.resize_start_pos:
            # 调整形状大小
            delta_x = pos.x() - self.resize_start_pos.x()
            delta_y = pos.y() - self.resize_start_pos.y()

            # 根据形状类型和控制点索引调整大小
            if self.hover_shape.shape_type == "rectangle" and len(self.hover_shape.points) >= 2:
                min_x = min(p.x() for p in self.hover_shape.points)
                min_y = min(p.y() for p in self.hover_shape.points)
                max_x = max(p.x() for p in self.hover_shape.points)
                max_y = max(p.y() for p in self.hover_shape.points)

                if self.resize_handle_index == 0:  # 左上角
                    min_x += delta_x
                    min_y += delta_y
                elif self.resize_handle_index == 1:  # 右上角
                    max_x += delta_x
                    min_y += delta_y
                elif self.resize_handle_index == 2:  # 右下角
                    max_x += delta_x
                    max_y += delta_y
                elif self.resize_handle_index == 3:  # 左下角
                    min_x += delta_x
                    max_y += delta_y

                # 更新矩形的点
                self.hover_shape.points = [QPointF(min_x, min_y), QPointF(max_x, max_y)]
            elif self.hover_shape.shape_type == "circle" and len(self.hover_shape.points) >= 2:
                # 对于圆形，只调整半径
                if self.resize_handle_index > 0:  # 不是圆心
                    center = self.hover_shape.points[0]
                    self.hover_shape.points[1] = QPointF(
                        center.x() + (pos.x() - center.x()),
                        center.y() + (pos.y() - center.y())
                    )
            elif self.hover_shape.shape_type == "polygon" and self.resize_handle_index >= 0:
                # 对于多边形，只调整选中的顶点
                if self.resize_handle_index < len(self.hover_shape.points):
                    self.hover_shape.points[self.resize_handle_index] = pos

            # 更新起始位置，以便继续调整大小
            self.resize_start_pos = pos
        else:
            # 如果已有选中的形状，保持其高亮状态；否则根据鼠标位置确定悬停形状
            hovered = next((s for s in reversed(self.shapes) if s.contains_point(pos)), None)
            if hovered:
                self.hover_shape = hovered
            elif not self.selected_shape:
                self.hover_shape = None

            if self.drawing and self.current_shape:
                if self.mode in ["rectangle", "rotation", "circle", "line"] and self.start_point:
                    self.current_shape.points[-1] = pos

            # 更新光标
            self.update_cursor(event.pos())

        self.update()
        
        # 触发形状修改事件（即时保存）
        if (self.is_dragging or self.is_resizing) and self.shapes_modified:
            self.shapes_modified()

    def mouseReleaseEvent(self, event):
        """鼠标释放事件"""
        if not self.pixmap or event.button() != Qt.LeftButton:
            return

        if self.is_panning:
            self.is_panning = False
            self.pan_start_pos = None
            self.pan_start_scroll = None
            self.setCursor(QCursor(Qt.ArrowCursor))
            return

        if self.is_dragging:
            self.is_dragging = False
            self.drag_start_pos = None
            # 触发形状修改事件（即时保存）
            if self.shapes_modified:
                self.shapes_modified()
            return

        if self.is_resizing:
            self.is_resizing = False
            self.resize_handle_index = -1
            self.resize_start_pos = None
            # 触发形状修改事件（即时保存）
            if self.shapes_modified:
                self.shapes_modified()
            return

        if not self.drawing:
            return

        pos = self.map_to_image_coords(event.pos())

        if self.mode == "rectangle" and self.start_point:
            min_size = 5
            if abs(pos.x() - self.start_point.x()) < min_size:
                pos.setX(
                    self.start_point.x() + min_size if pos.x() > self.start_point.x() else self.start_point.x() - min_size)
            if abs(pos.y() - self.start_point.y()) < min_size:
                pos.setY(
                    self.start_point.y() + min_size if pos.y() > self.start_point.y() else self.start_point.y() - min_size)

            self.current_shape.points[-1] = pos
            self.current_shape.close()
            if self.assign_label_to_shape(self.current_shape):
                self.shapes.append(self.current_shape)
                self.update_ui_lists()
            self.current_shape = None
            self.drawing = False
        elif self.mode == "rotation" and self.start_point:
            min_size = 5
            if abs(pos.x() - self.start_point.x()) < min_size:
                pos.setX(
                    self.start_point.x() + min_size if pos.x() > self.start_point.x() else self.start_point.x() - min_size)
            if abs(pos.y() - self.start_point.y()) < min_size:
                pos.setY(
                    self.start_point.y() + min_size if pos.y() > self.start_point.y() else self.start_point.y() - min_size)

            self.current_shape.points[-1] = pos
            self.current_shape.close()
            if self.assign_label_to_shape(self.current_shape):
                self.shapes.append(self.current_shape)
                self.update_ui_lists()
            self.current_shape = None
            self.drawing = False
        elif self.mode in ["circle", "line"]:
            self.current_shape.close()
            if self.assign_label_to_shape(self.current_shape):
                self.shapes.append(self.current_shape)
                self.update_ui_lists()
            self.current_shape = None
            self.drawing = False
        elif self.mode == "polygon":
            # 检查是否靠近起点以闭合多边形
            if len(self.current_shape.points) > 2:
                distance_to_first = math.hypot(pos.x() - self.current_shape.points[0].x(),
                                              pos.y() - self.current_shape.points[0].y())
                if distance_to_first < 10:  # 距离起点足够近则闭合
                    # 闭合多边形，但不添加重复的点
                    self.current_shape.close()
                    if self.assign_label_to_shape(self.current_shape):
                        self.shapes.append(self.current_shape)
                        self.update_ui_lists()
                    self.current_shape = None
                    self.drawing = False
                else:
                    # 否则添加新点
                    self.current_shape.add_point(pos)
            else:
                # 至少需要3个点才能考虑闭合
                self.current_shape.add_point(pos)

        self.update()
        
        # 触发形状修改事件（即时保存）
        if self.shapes_modified:
            self.shapes_modified()

    def get_scrollbar_values(self):
        """获取滚动条位置"""
        scroll_area = self.parent().parent()
        h_bar = scroll_area.horizontalScrollBar()
        v_bar = scroll_area.verticalScrollBar()
        return (h_bar.value(), v_bar.value())

    def get_resize_handles(self, shape):
        """获取形状的调整大小控制点"""
        if not shape or not shape.points:
            return []

        handles = []
        if shape.shape_type == "rectangle" and len(shape.points) >= 2:
            # 对于矩形，获取四个角点作为控制点
            min_x = min(p.x() for p in shape.points)
            min_y = min(p.y() for p in shape.points)
            max_x = max(p.x() for p in shape.points)
            max_y = max(p.y() for p in shape.points)
            handles = [
                QPointF(min_x, min_y),  # 左上角
                QPointF(max_x, min_y),  # 右上角
                QPointF(max_x, max_y),  # 右下角
                QPointF(min_x, max_y)   # 左下角
            ]
        elif shape.shape_type == "rotation" and len(shape.points) >= 4:
            # 对于旋转框，使用四个顶点作为控制点
            handles = shape.points[:4]
        elif shape.shape_type == "polygon" and len(shape.points) >= 3:
            # 对于多边形，使用所有顶点作为控制点
            handles = shape.points
        elif shape.shape_type == "circle" and len(shape.points) >= 2:
            # 对于圆形，使用圆心和边缘点作为控制点
            center = shape.points[0]
            radius = math.hypot(shape.points[1].x() - center.x(), shape.points[1].y() - center.y())
            handles = [
                center,  # 圆心
                QPointF(center.x() + radius, center.y()),  # 右侧边缘
                QPointF(center.x(), center.y() - radius),  # 顶部边缘
                QPointF(center.x() - radius, center.y()),  # 左侧边缘
                QPointF(center.x(), center.y() + radius)   # 底部边缘
            ]
        return handles

    def get_handle_index_at(self, pos, shape, threshold=8):
        """获取鼠标位置所在的控制点索引"""
        handles = self.get_resize_handles(shape)
        for i, handle in enumerate(handles):
            distance = math.hypot(pos.x() - handle.x(), pos.y() - handle.y())
            if distance <= threshold:
                return i
        return -1

    def update_cursor(self, pos):
        """根据鼠标位置更新光标"""
        if not self.pixmap:
            return

        image_pos = self.map_to_image_coords(pos)
        
        # 检查是否悬停在调整大小的控制点上（只使用悬停的形状）
        if self.hover_shape:
            handle_index = self.get_handle_index_at(image_pos, self.hover_shape)
            if handle_index != -1:
                # 根据控制点位置设置相应的光标
                if handle_index == 0:
                    self.setCursor(QCursor(Qt.SizeFDiagCursor))
                elif handle_index == 1:
                    self.setCursor(QCursor(Qt.SizeBDiagCursor))
                elif handle_index == 2:
                    self.setCursor(QCursor(Qt.SizeFDiagCursor))
                elif handle_index == 3:
                    self.setCursor(QCursor(Qt.SizeBDiagCursor))
                elif handle_index == 4:
                    self.setCursor(QCursor(Qt.SizeVerCursor))
                elif handle_index == 5:
                    self.setCursor(QCursor(Qt.SizeHorCursor))
                return

        # 检查是否悬停在形状上
        if self.hover_shape:
            self.setCursor(QCursor(Qt.PointingHandCursor))
        else:
            self.setCursor(QCursor(Qt.ArrowCursor))

    def _start_drawing_shape(self, pos):
        """开始绘制形状"""
        self.start_point = pos

        if self.mode == "rectangle":
            self.current_shape = Shape(shape_type="rectangle")
            self.current_shape.add_point(pos)
            self.current_shape.add_point(pos)
        elif self.mode == "rotation":
            self.current_shape = Shape(shape_type="rotation")
            self.current_shape.add_point(pos)
            self.current_shape.add_point(pos)
        elif self.mode == "polygon":
            if not self.current_shape:
                self.current_shape = Shape(shape_type="polygon")
            self.current_shape.add_point(pos)
        elif self.mode == "point":
            point_shape = Shape(shape_type="point")
            point_shape.add_point(pos)
            if self.assign_label_to_shape(point_shape):
                self.shapes.append(point_shape)
                self.update_ui_lists()
            self.current_shape = None
            self.drawing = False
        elif self.mode == "circle":
            self.current_shape = Shape(shape_type="circle")
            self.current_shape.add_point(pos)
            self.current_shape.add_point(pos)
        elif self.mode == "line":
            self.current_shape = Shape(shape_type="line")
            self.current_shape.add_point(pos)
            self.current_shape.add_point(pos)

    def _handle_right_click(self):
        """处理右键点击"""
        if self.current_shape and self.mode == "polygon":
            if len(self.current_shape.points) > 2:
                # 使用与鼠标点击相同的闭合逻辑
                self.current_shape.close()
                if self.assign_label_to_shape(self.current_shape):
                    self.shapes.append(self.current_shape)
                    self.update_ui_lists()
            self.current_shape = None
            self.drawing = False
        elif self.current_shape:
            self.current_shape = None
            self.drawing = False

    def keyPressEvent(self, event):
        """键盘事件"""
        if event.key() == Qt.Key_Escape:
            self.current_shape = None
            self.drawing = False
            self.selected_shape = None
            self.hover_shape = None
            self.is_panning = False
            self.setCursor(QCursor(Qt.ArrowCursor))
        elif event.key() == Qt.Key_Delete:
            if self.selected_shape:
                self.shapes.remove(self.selected_shape)
                self.selected_shape = None
            elif self.hover_shape:
                self.shapes.remove(self.hover_shape)
                self.hover_shape = None
            self.update_ui_lists()
            
            # 触发形状修改事件（即时保存）
            if self.shapes_modified:
                self.shapes_modified()
        elif event.key() == Qt.Key_Return and self.current_shape and self.mode == "polygon":
            if len(self.current_shape.points) > 2:
                # 使用与鼠标点击相同的闭合逻辑
                self.current_shape.close()
                if self.assign_label_to_shape(self.current_shape):
                    self.shapes.append(self.current_shape)
                    self.update_ui_lists()
                self.current_shape = None
                self.drawing = False
                
                # 触发形状修改事件（即时保存）
                if self.shapes_modified:
                    self.shapes_modified()
        else:
            super().keyPressEvent(event)

        self.update()

    def paintEvent(self, event):
        """绘制事件"""
        super().paintEvent(event)
        if not self.pixmap:
            return

        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        scaled_width = self.pixmap.width() * self.scale_factor
        scaled_height = self.pixmap.height() * self.scale_factor
        offset_x = max(0, (self.width() - scaled_width) / 2)
        offset_y = max(0, (self.height() - scaled_height) / 2)

        painter.translate(offset_x, offset_y)
        painter.scale(self.scale_factor, self.scale_factor)

        for shape in self.shapes:
            shape.scale = self.scale_factor
            shape.selected = (shape == self.hover_shape and not self.drawing)
            shape.paint(painter)

            # 只为悬停的形状绘制调整大小的控制点
            if shape == self.hover_shape and not self.drawing:
                handles = self.get_resize_handles(shape)
                handle_size = max(4, int(8 / self.scale_factor))
                painter.setPen(QPen(QColor(255, 255, 255), 2))
                painter.setBrush(QColor(0, 0, 255))
                for handle in handles:
                    painter.drawEllipse(handle, handle_size, handle_size)

        if self.current_shape:
            self.current_shape.selected = True
            self.current_shape.scale = self.scale_factor
            self.current_shape.paint(painter)

            # 总是获取鼠标位置用于绘制辅助线
            mouse_local_pos = self.mapFromGlobal(self.cursor().pos())
            mouse_image_pos = self.map_to_image_coords(mouse_local_pos)
            mouse_display_pos = self.map_from_image_coords(mouse_image_pos)

            if self.mode == "polygon" and len(self.current_shape.points) > 0:
                painter.resetTransform()
                last_point = self.current_shape.points[-1]
                last_display_point = self.map_from_image_coords(last_point)

                # 计算鼠标与起点的距离
                if len(self.current_shape.points) > 2:
                    first_point = self.current_shape.points[0]
                    first_display_point = self.map_from_image_coords(first_point)
                    distance_to_first = math.hypot(
                        mouse_display_pos.x() - first_display_point.x(),
                        mouse_display_pos.y() - first_display_point.y()
                    )
                    
                    if distance_to_first < 10:
                        # 当鼠标靠近起点时，显示闭合提示
                        painter.setPen(QPen(QColor(255, 0, 0), 3))  # 红色粗线条表示可以闭合
                        painter.drawLine(last_display_point, first_display_point)  # 直接连接到起点
                        painter.drawEllipse(first_display_point, 6, 6)  # 更大的圆圈提示
                    else:
                        # 正常情况下连接到鼠标位置
                        painter.setPen(QPen(QColor(0, 255, 0), 2))
                        painter.drawLine(last_display_point, mouse_display_pos)
                else:
                    # 不足3个点时正常绘制到鼠标位置
                    painter.setPen(QPen(QColor(0, 255, 0), 2))
                    painter.drawLine(last_display_point, mouse_display_pos)
            elif self.mode == "rotation" and len(self.current_shape.points) == 2:
                # 对于旋转框，绘制从起始点到当前位置的矩形
                painter.resetTransform()
                start_point = self.current_shape.points[0]
                start_display_point = self.map_from_image_coords(start_point)
                end_display_point = mouse_display_pos
                
                # 绘制临时矩形
                painter.setPen(QPen(QColor(0, 255, 0), 2))
                rect = QRectF(start_display_point, end_display_point).normalized()
                painter.drawRect(rect)

    def delete_selected(self):
        """删除选中形状"""
        if self.selected_shape and self.selected_shape in self.shapes:
            self.shapes.remove(self.selected_shape)
            self.selected_shape = None
        elif self.hover_shape and self.hover_shape in self.shapes:
            self.shapes.remove(self.hover_shape)
            self.hover_shape = None

        self.update()
        self.update_ui_lists()
        
        # 添加形状修改事件触发
        if self.shapes_modified:
            self.shapes_modified()

    def assign_label_to_shape(self, shape):
        """为形状分配标签"""
        parent = self.parent()
        while parent and not hasattr(parent, 'global_labels'):
            parent = parent.parent()

        dialog = QDialog(self)
        dialog.setWindowTitle("输入标签")
        dialog.resize(350, 300)

        layout = QVBoxLayout(dialog)

        label_input = QLineEdit(shape.label)
        layout.addWidget(QLabel("标签名称:"))
        layout.addWidget(label_input)

        layout.addWidget(QLabel("选择标签:"))
        all_labels_list = QListWidget()
        current_labels = AnnotationUtils.get_existing_labels(self.shapes)
        all_labels = set(current_labels)
        if parent and hasattr(parent, 'global_labels'):
            all_labels.update(parent.global_labels)

        for label in sorted(all_labels):
            all_labels_list.addItem(label)
        layout.addWidget(all_labels_list)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)

        all_labels_list.itemClicked.connect(lambda item: label_input.setText(item.text()))

        if dialog.exec_() == QDialog.Accepted:
            label = label_input.text().strip()
            if label:
                shape.label = label
                shape.line_color = ColorUtils.get_color_for_label(label)
                shape.fill_color = QColor(shape.line_color.red(),
                                          shape.line_color.green(),
                                          shape.line_color.blue(),
                                          30)

                if parent and hasattr(parent, 'global_labels'):
                    parent.global_labels.add(label)
                self.update_ui_lists()
                
                # 添加形状修改事件触发
                if self.shapes_modified:
                    self.shapes_modified()
                return True
        return False

    def update_ui_lists(self):
        """更新UI列表"""
        parent = self.parent()
        while parent:
            if hasattr(parent, 'update_shapes_list') and hasattr(parent, 'update_labels_list'):
                parent.update_shapes_list()
                parent.update_labels_list()
                break
            parent = parent.parent()
        
        # 通知主窗口画布已修改，立即触发保存
        main_parent = self.parent()
        while main_parent:
            if hasattr(main_parent, 'on_canvas_modified'):
                main_parent.on_canvas_modified()
                break
            main_parent = main_parent.parent()