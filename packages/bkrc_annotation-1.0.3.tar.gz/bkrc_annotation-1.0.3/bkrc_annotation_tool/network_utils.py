import socket
import ipaddress


class NetworkUtils:
    """网络工具类"""

    @staticmethod
    def get_local_ip():
        """获取本机局域网IP - 简化版本"""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(('8.8.8.8', 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except:
            return "127.0.0.1"

    @staticmethod
    def get_network_prefix():
        """获取网络前缀"""
        local_ip = NetworkUtils.get_local_ip()
        parts = local_ip.split('.')
        if len(parts) >= 3:
            return f"{parts[0]}.{parts[1]}.{parts[2]}"
        return "192.168.1"