from PySide6.QtGui import QColor


class ColorUtils:
    """颜色工具类 - 随机生成不同的颜色"""
    _color_cache = {}

    @staticmethod
    def get_color_for_label(label: str) -> QColor:
        """根据标签名获取颜色"""
        if not label:
            return QColor(255, 50, 50)

        if label in ColorUtils._color_cache:
            return ColorUtils._color_cache[label]

        hash_value = 0
        for char in label:
            hash_value = (hash_value * 31 + ord(char)) & 0xFFFFFFFF

        r = ((hash_value >> 16) & 0xFF) % 200 + 50
        g = ((hash_value >> 8) & 0xFF) % 200 + 50
        b = (hash_value & 0xFF) % 200 + 50

        if max(r, g, b) < 100:
            r = min(255, r + 100)
            g = min(255, g + 100)
            b = min(255, b + 100)
        elif min(r, g, b) > 200:
            r = max(50, r - 100)
            g = max(50, g - 100)
            b = max(50, b - 100)

        color = QColor(r, g, b)
        ColorUtils._color_cache[label] = color
        return color

    @staticmethod
    def get_contrast_color(color: QColor) -> QColor:
        """获取与给定颜色对比度高的颜色"""
        luminance = 0.299 * color.red() + 0.587 * color.green() + 0.114 * color.blue()
        return QColor(0, 0, 0) if luminance > 128 else QColor(255, 255, 255)

    @staticmethod
    def get_lighter_color(color: QColor, factor=1.5) -> QColor:
        """获取更亮的颜色"""
        return QColor(
            min(255, int(color.red() * factor)),
            min(255, int(color.green() * factor)),
            min(255, int(color.blue() * factor))
        )