import os
import shutil
import sys
import traceback
import glob
import json
import subprocess
import re
import threading
from queue import Queue
from pathlib import Path
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QScrollArea,
    QLabel, QPushButton, QListWidget, QListWidgetItem, QFileDialog,
    QMessageBox, QInputDialog, QGroupBox, QFrame, QStatusBar,
    QApplication, QGridLayout, QAbstractItemView, QDialog, QLineEdit, QSplitter, QTabWidget, QSizePolicy,
    QProgressBar, QComboBox, QStackedWidget, QFormLayout
)
from PySide6.QtCore import Qt, QTimer, Signal, QThread, Slot
from PySide6.QtGui import QColor

from .image_viewer import ImageViewer
from .network_utils import NetworkUtils
from .annotation_utils import AnnotationUtils
from .color_utils import ColorUtils
from .direct_detector import DirectDetector
from .detection_dialog import DirectDetectionDialog
from .http_client import LANFileClient
from .transfer_dialogs import OptimizedFileTransferDialog, TransferProgressDialog, DistributionWorker
from .label_file import LabelFile
from .label_converter import LabelConverter
from .dataset_splitter import DatasetSplitter, split_dataset_from_folder
from .browser_widgets import TensorBoardBrowser, NetronBrowser
# 导入统一的进程管理工具
# 进程管理功能已整合到信息面板，不再需要单独导入
# 导入增强版信息面板（包含进程列表功能）
from .simple_info_panel import SimpleInfoPanel
# 导入训练进程管理工具

import cv2
import tempfile
import time
from PySide6.QtWidgets import QProgressDialog, QSpinBox, QGridLayout


# 模型量化功能已移至单独的导入方式，删除了直接启动py文件的方式

# 导入ANSI颜色过滤器
from .simple_info_panel import filter_ansi_escape

# 编码检测和转换函数
def smart_decode(byte_data):
    """智能解码，尝试多种编码"""
    encodings = ['utf-8', 'gbk', 'gb2312', 'cp936']
    for encoding in encodings:
        try:
            return byte_data.decode(encoding)
        except UnicodeDecodeError:
            continue
    # 如果都失败，使用错误处理
    return byte_data.decode('utf-8', errors='replace')






# BrowserWidget类已移至browser_widgets.py，此处删除重复定义





class ModelExportThread(QThread):
    """模型导出线程"""
    export_started = Signal()
    export_finished = Signal(str)  # 输出路径
    export_error = Signal(str)  # 错误信息

    def __init__(self, model_path, export_format):
        super().__init__()
        self.model_path = model_path
        self.export_format = export_format

    def run(self):
        """使用subprocess执行模型导出"""
        try:
            self.export_started.emit()

            import subprocess
            import sys

            # 获取输出文件路径
            base_path = os.path.splitext(self.model_path)[0]
            output_path = f"{base_path}.{self.export_format.lower()}"

            # 准备Python脚本执行导出
            script_content = f'''import sys\nsys.path.append('.')\nfrom ultralytics import YOLO\n\n# 加载模型\nmodel = YOLO('{self.model_path.replace(chr(92), chr(92) + chr(92))}')\n\n# 导出模型\nmodel.export(format='{self.export_format.upper()}')\n\nprint(f"Model exported successfully to {{'{base_path}.{self.export_format.lower()}'+''}}")\n'''
            # 使用subprocess执行Python脚本，避免text=True以防止编码问题
            result = subprocess.run(
                [sys.executable, '-c', script_content],
                capture_output=True,
                timeout=3600  # 1小时超时
            )

            # 解码输出，处理可能的编码问题
            try:
                stdout = result.stdout.decode('utf-8', errors='replace') if isinstance(result.stdout,
                                                                                       bytes) else result.stdout
            except (UnicodeDecodeError, AttributeError):
                stdout = str(result.stdout)

            try:
                stderr = result.stderr.decode('utf-8', errors='replace') if isinstance(result.stderr,
                                                                                       bytes) else result.stderr
            except (UnicodeDecodeError, AttributeError):
                stderr = str(result.stderr)

            if result.returncode == 0:
                # 发射完成信号
                self.export_finished.emit(output_path)
            else:
                error_msg = stderr.strip() if stderr else "Unknown error occurred during export"
                self.export_error.emit(error_msg)

        except subprocess.TimeoutExpired:
            self.export_error.emit("模型导出超时，请检查模型大小和系统资源")
        except FileNotFoundError:
            self.export_error.emit("未找到Python解释器，请检查Python安装")
        except ImportError:
            self.export_error.emit("未安装ultralytics库，请先安装: pip install ultralytics")
        except UnicodeDecodeError as e:
            self.export_error.emit(f"输出编码错误: {str(e)}")
        except Exception as e:
            self.export_error.emit(str(e))


# 训练进程现在统一通过信息面板管理


class FrameExtractionDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("视频帧提取设置")
        self.setModal(True)

        layout = QVBoxLayout()

        # 创建输入控件
        form_layout = QFormLayout()

        self.interval_spin = QSpinBox()
        self.interval_spin.setRange(1, 1000)
        self.interval_spin.setValue(1)
        form_layout.addRow("帧间隔:", self.interval_spin)

        self.prefix_edit = QLineEdit()
        self.prefix_edit.setText("frame_")
        form_layout.addRow("文件名前缀:", self.prefix_edit)

        self.seq_spin = QSpinBox()
        self.seq_spin.setRange(3, 10)
        self.seq_spin.setValue(5)
        form_layout.addRow("序号长度:", self.seq_spin)

        layout.addLayout(form_layout)

        # 按钮
        button_layout = QHBoxLayout()
        ok_btn = QPushButton("确定")
        cancel_btn = QPushButton("取消")

        ok_btn.clicked.connect(self.accept)
        cancel_btn.clicked.connect(self.reject)

        button_layout.addWidget(ok_btn)
        button_layout.addWidget(cancel_btn)
        layout.addLayout(button_layout)

        self.setLayout(layout)

    def get_values(self):
        return self.interval_spin.value(), self.prefix_edit.text(), self.seq_spin.value()





class AnnotationTool(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("BKRC - 图像标注工具 - 客户端")
        self.setGeometry(100, 100, 1500, 1000)
        self.setFocusPolicy(Qt.StrongFocus)

        # 文件夹标注变量
        self.image_files = []
        self.current_image_index = -1
        self.current_folder = ""
        self.current_file_path = ""
        self.global_labels = set()

        # 网络相关
        self.server_ip = NetworkUtils.get_local_ip()
        self.server_port = 8000

        # TCP探测器
        self.direct_detector = DirectDetector(port=8888)

        # 分发相关
        self.transfer_worker = None
        self.transfer_progress_dialog = None
        self.saved_ips = []



        # 创建虚拟的image_viewer对象以保持向后兼容性
        self.image_viewer = self._create_dummy_image_viewer()

        # 保存当前视图状态
        self.current_view = 'canvas'

        # TensorBoard进程管理
        self.tensorboard_process = None
        self.current_tensorboard_port = None
        self.tensorboard_loaded = False
        self.last_training_logdir = None
        self.last_training_config = None
        
        # Netron进程管理
        self.netron_process = None
        self.current_netron_port = None
        self.netron_loaded = False

        # 数据集分割线程
        self.dataset_split_thread = None

        # 创建UI
        self._init_ui()

        # 默认模式
        self.current_mode = "rectangle"
        if self.current_view == 'canvas':
            self.image_viewer.mode = "rectangle"
        self.update_mode_buttons()

        # 状态栏
        self.status_label = QLabel("就绪")
        self.statusBar().addPermanentWidget(self.status_label)
        self.statusBar().showMessage("就绪")

        # 程序启动后自动连接服务器
        QTimer.singleShot(1000, self.auto_connect_to_server)

        # 连接图像查看器的修改信号
        if self.current_view == 'canvas':
            self.image_viewer.shapes_modified = self.on_canvas_modified











    def _create_dummy_image_viewer(self):
        """创建虚拟图像查看器对象"""

        class DummyImageViewer:
            def __init__(self):
                self.shapes = []
                self.original_width = 800
                self.original_height = 600
                self.scale_factor = 1.0
                self.mode = "rectangle"
                self.selected_shape = None
                self.hover_shape = None
                self.pixmap = None
                self.current_shape = None
                self.drawing = False
                self.shapes_modified = None

            def reset_zoom(self):
                pass

            def update(self):
                pass

            def update_display(self):
                pass

            def load_image(self, path):
                pass

            def delete_selected(self):
                pass

            def zoom_in(self):
                pass

            def zoom_out(self):
                pass

        return DummyImageViewer()

    def _init_ui(self):
        """初始化UI"""
        
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QVBoxLayout(main_widget)  # 改为垂直布局以容纳底部终端

        # 创建主要水平分割器（用于左右面板）
        main_splitter = QSplitter(Qt.Horizontal)

        # 左侧面板
        left_panel = self._create_left_panel()
        left_scroll = QScrollArea()
        left_scroll.setWidgetResizable(True)
        left_scroll.setWidget(left_panel)
        left_scroll.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)
        main_splitter.addWidget(left_scroll)

        # 中间区域 - 堆叠布局
        self.stacked_widget = QStackedWidget()

        # 图像查看器画布
        self.image_viewer = ImageViewer(self)
        self.canvas_scroll = QScrollArea()
        self.canvas_scroll.setWidget(self.image_viewer)
        self.canvas_scroll.setWidgetResizable(False)
        self.canvas_scroll.setAlignment(Qt.AlignCenter)
        self.canvas_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.canvas_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)

        # TensorBoard浏览器
        self.tensorboard_view = TensorBoardBrowser(port=6006, parent=self)
        self.tensorboard_scroll = QScrollArea()
        self.tensorboard_scroll.setWidget(self.tensorboard_view)
        self.tensorboard_scroll.setWidgetResizable(True)
        self.tensorboard_scroll.setAlignment(Qt.AlignCenter)
        self.tensorboard_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.tensorboard_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)

        # Netron浏览器
        self.netron_view = NetronBrowser(port=8080, parent=self)
        self.netron_scroll = QScrollArea()
        self.netron_scroll.setWidget(self.netron_view)
        self.netron_scroll.setWidgetResizable(True)
        self.netron_scroll.setAlignment(Qt.AlignCenter)
        self.netron_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.netron_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)

        # 添加到堆叠布局
        self.stacked_widget.addWidget(self.canvas_scroll)
        self.stacked_widget.addWidget(self.tensorboard_scroll)
        self.stacked_widget.addWidget(self.netron_scroll)

        # 根据当前视图状态显示相应组件
        if self.current_view == 'canvas':
            self.stacked_widget.setCurrentIndex(0)
        elif self.current_view == 'tensorboard':
            self.stacked_widget.setCurrentIndex(1)
        else:
            self.stacked_widget.setCurrentIndex(2)

        # 连接堆叠部件的当前索引更改信号
        self.stacked_widget.currentChanged.connect(self.on_view_changed)

        main_splitter.addWidget(self.stacked_widget)

        # 右侧面板
        right_panel = self._create_right_panel()
        right_scroll = QScrollArea()
        right_scroll.setWidgetResizable(True)
        right_scroll.setWidget(right_panel)
        # 设置右侧面板尺寸策略为可扩展
        right_scroll.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        right_scroll.setAlignment(Qt.AlignTop)
        right_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        right_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)

        main_splitter.addWidget(right_scroll)

        # 设置初始尺寸和拉伸因子
        main_splitter.setSizes([300, 800, 300])
        main_splitter.setStretchFactor(0, 0)  # 左侧面板不拉伸
        main_splitter.setStretchFactor(1, 1)  # 中间区域可拉伸
        main_splitter.setStretchFactor(2, 0)  # 右侧面板不拉伸，但允许用户手动调整

        # 创建垂直分割器来包含主内容和底部终端
        vertical_splitter = QSplitter(Qt.Vertical)
        vertical_splitter.addWidget(main_splitter)
        
        # 创建底部信息面板
        self._create_bottom_terminal_panel(vertical_splitter)
        
        # 设置垂直分割器的比例
        vertical_splitter.setSizes([700, 300])  # 主内容占70%，信息面板占30%
        vertical_splitter.setStretchFactor(0, 1)
        vertical_splitter.setStretchFactor(1, 0)
        
        main_layout.addWidget(vertical_splitter)

    def _create_bottom_terminal_panel(self, parent_splitter):
        """创建底部信息面板 - 与左右边栏统一风格"""
        # 创建一个滚动区域，与左右面板保持一致
        bottom_scroll = QScrollArea()
        bottom_scroll.setWidgetResizable(True)
        bottom_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        bottom_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        bottom_scroll.setAlignment(Qt.AlignTop)
        
        # 创建内容部件
        bottom_panel = QWidget()
        bottom_layout = QVBoxLayout(bottom_panel)
        bottom_layout.setSpacing(10)
        bottom_layout.setContentsMargins(5, 5, 5, 5)  # 与左右面板一致的边距
        
        # 直接使用简化信息面板，其中已包含进程列表和控制台输出两个功能组
        self.info_panel = SimpleInfoPanel(self)
        self.info_panel.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)
        bottom_layout.addWidget(self.info_panel)
        
        bottom_layout.addStretch()
        
        # 设置滚动区域的内容
        bottom_scroll.setWidget(bottom_panel)
        
        # 设置滚动区域的大小策略
        bottom_scroll.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)
        
        # 添加到分割器
        parent_splitter.addWidget(bottom_scroll)
        
        # 设置面板大小策略
        bottom_panel.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)
    
    
    def _create_left_panel(self):
        """创建左侧面板"""
        left_panel = QWidget()
        left_layout = QVBoxLayout(left_panel)
        left_layout.setSpacing(10)
        left_layout.setContentsMargins(5, 5, 5, 5)

        # === 网络功能区域 ===
        network_group = QGroupBox("局域网传输")
        network_layout = QVBoxLayout(network_group)

        server_status_layout = QHBoxLayout()
        server_status_layout.addWidget(QLabel("服务器状态:"))
        self.server_status_indicator = QLabel("●")
        self.server_status_indicator.setStyleSheet("color: red; font-weight: bold;")
        server_status_layout.addWidget(self.server_status_indicator)
        self.server_status_label = QLabel("未连接")
        server_status_layout.addWidget(self.server_status_label)
        server_status_layout.addStretch()
        network_layout.addLayout(server_status_layout)

        self.server_info_label = QLabel(f"服务器: {self.server_ip}:{self.server_port}")
        self.server_info_label.setStyleSheet("color: blue; font-weight: bold;")
        network_layout.addWidget(self.server_info_label)

        server_btn_layout = QHBoxLayout()
        self.connect_server_btn = QPushButton("连接服务器")
        self.connect_server_btn.clicked.connect(self.connect_to_server)
        server_btn_layout.addWidget(self.connect_server_btn)

        self.detect_btn = QPushButton("探测在线设备")
        self.detect_btn.clicked.connect(self.show_detection_dialog)
        self.detect_btn.setToolTip("探测运行后端服务的设备IP")
        server_btn_layout.addWidget(self.detect_btn)

        self.distribute_btn = QPushButton("分发文件...")
        self.distribute_btn.clicked.connect(lambda: self.configure_transfer("distribution"))
        self.distribute_btn.setEnabled(False)
        server_btn_layout.addWidget(self.distribute_btn)

        self.reverse_btn = QPushButton("回传文件...")
        self.reverse_btn.clicked.connect(lambda: self.configure_transfer("reverse"))
        self.reverse_btn.setEnabled(False)
        server_btn_layout.addWidget(self.reverse_btn)

        network_layout.addLayout(server_btn_layout)

        ip_info_layout = QHBoxLayout()
        ip_info_layout.addWidget(QLabel("已保存IP:"))
        self.saved_ips_label = QLabel("0个")
        self.saved_ips_label.setStyleSheet("color: blue; font-weight: bold;")
        ip_info_layout.addWidget(self.saved_ips_label)
        ip_info_layout.addStretch()
        network_layout.addLayout(ip_info_layout)

        left_layout.addWidget(network_group)

        # === 文件操作区域 ===
        file_group = QGroupBox("文件操作")
        file_layout = QVBoxLayout(file_group)

        # 第一行：打开文件和视频按钮
        single_btn_layout = QHBoxLayout()
        self.open_file_btn = QPushButton("打开文件")
        self.open_file_btn.clicked.connect(self.open_single_file)
        single_btn_layout.addWidget(self.open_file_btn)

        self.open_video_btn = QPushButton("打开视频")
        self.open_video_btn.clicked.connect(self.open_video_file)
        single_btn_layout.addWidget(self.open_video_btn)
        file_layout.addLayout(single_btn_layout)

        # 第二行：打开文件夹和刷新按钮
        folder_btn_layout = QHBoxLayout()
        self.load_folder_btn = QPushButton("打开文件夹")
        self.load_folder_btn.clicked.connect(self.load_folder)
        folder_btn_layout.addWidget(self.load_folder_btn)

        self.refresh_folder_btn = QPushButton("刷新文件夹")
        self.refresh_folder_btn.clicked.connect(self.load_folder_refresh)
        self.refresh_folder_btn.setEnabled(False)
        folder_btn_layout.addWidget(self.refresh_folder_btn)
        file_layout.addLayout(folder_btn_layout)

        # 第三行：导航按钮
        nav_layout = QHBoxLayout()
        self.prev_btn = QPushButton("上一张 (←)")
        self.prev_btn.clicked.connect(self.prev_image)
        self.prev_btn.setEnabled(False)
        nav_layout.addWidget(self.prev_btn)

        self.next_btn = QPushButton("下一张 (→)")
        self.next_btn.clicked.connect(self.next_image)
        self.next_btn.setEnabled(False)
        nav_layout.addWidget(self.next_btn)
        file_layout.addLayout(nav_layout)

        self.progress_label = QLabel("")
        file_layout.addWidget(self.progress_label)

        left_layout.addWidget(file_group)

        # === 标注工具区域 ===
        tool_group = QGroupBox("标注工具")
        tool_layout = QVBoxLayout(tool_group)

        shape_layout = QGridLayout()
        self.rect_btn = QPushButton("矩形")
        self.rect_btn.clicked.connect(lambda: self.set_mode("rectangle"))
        self.rect_btn.setStyleSheet("background-color: lightblue;")
        shape_layout.addWidget(self.rect_btn, 0, 0)

        self.rotation_btn = QPushButton("旋转框")
        self.rotation_btn.clicked.connect(lambda: self.set_mode("rotation"))
        shape_layout.addWidget(self.rotation_btn, 0, 1)

        self.polygon_btn = QPushButton("多边形")
        self.polygon_btn.clicked.connect(lambda: self.set_mode("polygon"))
        shape_layout.addWidget(self.polygon_btn, 1, 0)

        self.circle_btn = QPushButton("圆形")
        self.circle_btn.clicked.connect(lambda: self.set_mode("circle"))
        shape_layout.addWidget(self.circle_btn, 1, 1)

        self.line_btn = QPushButton("直线")
        self.line_btn.clicked.connect(lambda: self.set_mode("line"))
        shape_layout.addWidget(self.line_btn, 2, 0)

        self.point_btn = QPushButton("点")
        self.point_btn.clicked.connect(lambda: self.set_mode("point"))
        shape_layout.addWidget(self.point_btn, 2, 1)

        tool_layout.addLayout(shape_layout)

        op_layout = QHBoxLayout()
        self.reset_zoom_btn = QPushButton("重置缩放 (R)")
        self.reset_zoom_btn.clicked.connect(self.reset_zoom)
        op_layout.addWidget(self.reset_zoom_btn)

        self.delete_btn = QPushButton("删除选中")
        self.delete_btn.clicked.connect(self.delete_selected)
        op_layout.addWidget(self.delete_btn)
        tool_layout.addLayout(op_layout)

        left_layout.addWidget(tool_group)

        # === 标签列表 ===
        label_group = QGroupBox("标签列表")
        label_layout = QVBoxLayout(label_group)
        self.labels_list = QListWidget()
        self.labels_list.setMinimumHeight(120)
        self.labels_list.setMaximumHeight(200)
        self.labels_list.setSelectionMode(QAbstractItemView.SingleSelection)
        self.labels_list.itemDoubleClicked.connect(self.on_label_double_clicked)
        label_layout.addWidget(self.labels_list)
        left_layout.addWidget(label_group)

        # === 文件列表 ===
        filelist_group = QGroupBox("文件列表")
        filelist_layout = QVBoxLayout(filelist_group)
        self.files_list = QListWidget()
        self.files_list.setMinimumHeight(120)
        self.files_list.setMaximumHeight(200)
        self.files_list.setSelectionMode(QAbstractItemView.SingleSelection)
        self.files_list.itemClicked.connect(self.on_file_selected)
        filelist_layout.addWidget(self.files_list)
        left_layout.addWidget(filelist_group)

        # === 标注列表 ===
        shapelist_group = QGroupBox("标注列表")
        shapelist_layout = QVBoxLayout(shapelist_group)
        self.shapes_list = QListWidget()
        self.shapes_list.setMinimumHeight(120)
        self.shapes_list.setMaximumHeight(200)
        self.shapes_list.setSelectionMode(QAbstractItemView.SingleSelection)
        self.shapes_list.itemClicked.connect(self.on_shape_selected)
        shapelist_layout.addWidget(self.shapes_list)
        left_layout.addWidget(shapelist_group)

        left_layout.addStretch()

        return left_panel

    def _create_right_panel(self):
        """创建右侧面板"""
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        right_layout.setSpacing(10)
        right_layout.setContentsMargins(5, 5, 5, 5)

        # === AI检测服务配置区域 ===
        ai_detection_group = QGroupBox("AI检测服务配置")
        ai_detection_layout = QVBoxLayout(ai_detection_group)

        # 服务地址配置
        service_layout = QHBoxLayout()
        service_layout.addWidget(QLabel("服务地址:"))
        self.ai_service_url_combo = QComboBox()
        self.ai_service_url_combo.setEditable(True)  # 允许编辑，这样用户也可以输入自定义地址
        # 移除默认内容，只显示http://
        self.ai_service_url_combo.setPlaceholderText("http://")
        # 设置下拉菜单自适应大小
        self.ai_service_url_combo.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLengthWithIcon)
        self.ai_service_url_combo.setMinimumContentsLength(30)  # 设置最小内容长度
        # 设置下拉菜单尺寸策略为可扩展
        self.ai_service_url_combo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        service_layout.addWidget(self.ai_service_url_combo, 1)  # 设置拉伸因子为1
        
        self.refresh_endpoints_btn = QPushButton("刷新")
        self.refresh_endpoints_btn.clicked.connect(self.refresh_ai_endpoints)
        service_layout.addWidget(self.refresh_endpoints_btn)
        ai_detection_layout.addLayout(service_layout)

        # 置信度阈值配置
        conf_layout = QHBoxLayout()
        conf_layout.addWidget(QLabel("置信度阈值:"))
        self.conf_threshold_edit = QLineEdit()
        self.conf_threshold_edit.setText("0.3")
        self.conf_threshold_edit.setPlaceholderText("检测置信度阈值 (0.0-1.0)")
        conf_layout.addWidget(self.conf_threshold_edit)
        ai_detection_layout.addLayout(conf_layout)

        # NMS阈值配置
        nms_layout = QHBoxLayout()
        nms_layout.addWidget(QLabel("NMS阈值:"))
        self.nms_threshold_edit = QLineEdit()
        self.nms_threshold_edit.setText("0.5")
        self.nms_threshold_edit.setPlaceholderText("非极大值抑制阈值 (0.0-1.0)")
        nms_layout.addWidget(self.nms_threshold_edit)
        ai_detection_layout.addLayout(nms_layout)

        # 模型路径配置
        model_layout = QHBoxLayout()
        model_layout.addWidget(QLabel("模型路径:"))
        self.model_path_edit = QLineEdit()
        # 移除默认路径
        self.model_path_edit.setPlaceholderText("输入模型文件路径 (.onnx等)")
        model_layout.addWidget(self.model_path_edit)

        self.browse_model_path_btn = QPushButton("浏览")
        self.browse_model_path_btn.clicked.connect(self.browse_ai_model_path)
        model_layout.addWidget(self.browse_model_path_btn)
        ai_detection_layout.addLayout(model_layout)

        # 类别配置
        classes_layout = QHBoxLayout()
        classes_layout.addWidget(QLabel("类别:"))
        self.classes_edit = QLineEdit()
        self.classes_edit.setText("0,1,2,3,4,5")
        self.classes_edit.setPlaceholderText("类别索引，用逗号分隔")
        classes_layout.addWidget(self.classes_edit)
        ai_detection_layout.addLayout(classes_layout)

        # 实例名称配置
        instance_layout = QHBoxLayout()
        instance_layout.addWidget(QLabel("实例名称:"))
        self.instance_name_edit = QLineEdit()
        self.instance_name_edit.setText("my_custom_yolo_instance")
        self.instance_name_edit.setPlaceholderText("模型实例名称")
        instance_layout.addWidget(self.instance_name_edit)
        ai_detection_layout.addLayout(instance_layout)

        # 操作按钮
        ai_btn_layout = QHBoxLayout()

        self.start_detection_btn = QPushButton("开始检测")
        self.start_detection_btn.clicked.connect(self.start_ai_detection)
        ai_btn_layout.addWidget(self.start_detection_btn)

        self.batch_detection_btn = QPushButton("批量检测")
        self.batch_detection_btn.clicked.connect(self.start_batch_ai_detection)
        ai_btn_layout.addWidget(self.batch_detection_btn)

        ai_detection_layout.addLayout(ai_btn_layout)

        # 状态标签
        self.ai_status_label = QLabel("AI检测: 就绪")
        ai_detection_layout.addWidget(self.ai_status_label)

        right_layout.addWidget(ai_detection_group)

        # === 标签格式转换区域 ===
        conversion_group = QGroupBox("标签格式转换")
        conversion_layout = QVBoxLayout(conversion_group)

        conversion_btn_layout = QHBoxLayout()
        self.json_to_yolo_btn = QPushButton("JSON转YOLO(全部)")
        self.json_to_yolo_btn.clicked.connect(self.convert_all_json_to_yolo)
        conversion_btn_layout.addWidget(self.json_to_yolo_btn)

        self.yolo_to_json_btn = QPushButton("YOLO转JSON(全部)")
        self.yolo_to_json_btn.clicked.connect(self.convert_all_yolo_to_json)
        conversion_btn_layout.addWidget(self.yolo_to_json_btn)

        conversion_layout.addLayout(conversion_btn_layout)

        yolo_voc_btn_layout = QHBoxLayout()
        self.json_to_voc_btn = QPushButton("JSON转VOC(全部)")
        self.json_to_voc_btn.clicked.connect(self.convert_all_json_to_voc)
        yolo_voc_btn_layout.addWidget(self.json_to_voc_btn)

        self.voc_to_json_btn = QPushButton("VOC转JSON(全部)")
        self.voc_to_json_btn.clicked.connect(self.convert_all_voc_to_json)
        yolo_voc_btn_layout.addWidget(self.voc_to_json_btn)

        conversion_layout.addLayout(yolo_voc_btn_layout)

        coco_conversion_btn_layout = QHBoxLayout()
        self.json_to_coco_btn = QPushButton("JSON转COCO(全部)")
        self.json_to_coco_btn.clicked.connect(self.convert_all_json_to_coco)
        coco_conversion_btn_layout.addWidget(self.json_to_coco_btn)

        self.coco_to_json_btn = QPushButton("COCO转JSON(全部)")
        self.coco_to_json_btn.clicked.connect(self.convert_all_coco_to_json)
        coco_conversion_btn_layout.addWidget(self.coco_to_json_btn)

        conversion_layout.addLayout(coco_conversion_btn_layout)
        
        # 添加更多转换格式的按钮
        extended_conversion_btn_layout = QHBoxLayout()
        self.json_to_dota_btn = QPushButton("JSON转DOTA(全部)")
        self.json_to_dota_btn.clicked.connect(self.convert_all_json_to_dota)
        extended_conversion_btn_layout.addWidget(self.json_to_dota_btn)

        self.dota_to_json_btn = QPushButton("DOTA转JSON(全部)")
        self.dota_to_json_btn.clicked.connect(self.convert_all_dota_to_json)
        extended_conversion_btn_layout.addWidget(self.dota_to_json_btn)

        conversion_layout.addLayout(extended_conversion_btn_layout)
        
        ocr_tracking_conversion_btn_layout = QHBoxLayout()
        self.json_to_ppocr_btn = QPushButton("JSON转PP-OCR(全部)")
        self.json_to_ppocr_btn.clicked.connect(self.convert_all_json_to_ppocr)
        ocr_tracking_conversion_btn_layout.addWidget(self.json_to_ppocr_btn)

        self.ppocr_to_json_btn = QPushButton("PP-OCR转JSON(全部)")
        self.ppocr_to_json_btn.clicked.connect(self.convert_all_ppocr_to_json)
        ocr_tracking_conversion_btn_layout.addWidget(self.ppocr_to_json_btn)

        conversion_layout.addLayout(ocr_tracking_conversion_btn_layout)
        
        mask_mot_conversion_btn_layout = QHBoxLayout()
        self.json_to_mot_btn = QPushButton("JSON转MOT(全部)")
        self.json_to_mot_btn.clicked.connect(self.convert_all_json_to_mot)
        mask_mot_conversion_btn_layout.addWidget(self.json_to_mot_btn)

        self.mot_to_json_btn = QPushButton("MOT转JSON(全部)")
        self.mot_to_json_btn.clicked.connect(self.convert_all_mot_to_json)
        mask_mot_conversion_btn_layout.addWidget(self.mot_to_json_btn)

        conversion_layout.addLayout(mask_mot_conversion_btn_layout)
        
        mask_conversion_layout = QHBoxLayout()
        self.json_to_mask_btn = QPushButton("JSON转Mask(全部)")
        self.json_to_mask_btn.clicked.connect(self.convert_all_json_to_mask)
        mask_conversion_layout.addWidget(self.json_to_mask_btn)

        conversion_layout.addLayout(mask_conversion_layout)

        right_layout.addWidget(conversion_group)

        # === 数据集划分区域 ===
        dataset_split_group = QGroupBox("数据集划分")
        dataset_split_layout = QVBoxLayout(dataset_split_group)

        dataset_path_layout = QHBoxLayout()
        dataset_path_layout.addWidget(QLabel("数据集路径:"))
        self.dataset_input_path_edit = QLineEdit()
        self.dataset_input_path_edit.setPlaceholderText("选择数据集路径，留空则使用当前文件夹")
        dataset_path_layout.addWidget(self.dataset_input_path_edit)

        self.browse_dataset_input_btn = QPushButton("浏览")
        self.browse_dataset_input_btn.clicked.connect(self.browse_dataset_input_path)
        dataset_path_layout.addWidget(self.browse_dataset_input_btn)

        dataset_split_layout.addLayout(dataset_path_layout)

        output_path_layout = QHBoxLayout()
        output_path_layout.addWidget(QLabel("输出路径:"))
        self.dataset_output_path_edit = QLineEdit()
        self.dataset_output_path_edit.setPlaceholderText("选择数据集输出路径")
        output_path_layout.addWidget(self.dataset_output_path_edit)

        self.browse_dataset_output_btn = QPushButton("浏览")
        self.browse_dataset_output_btn.clicked.connect(self.browse_dataset_output_path)
        output_path_layout.addWidget(self.browse_dataset_output_btn)

        dataset_split_layout.addLayout(output_path_layout)

        ratio_layout = QGridLayout()

        ratio_layout.addWidget(QLabel("训练集比例:"), 0, 0)
        self.train_ratio_edit = QLineEdit()
        self.train_ratio_edit.setText("0.7")
        ratio_layout.addWidget(self.train_ratio_edit, 0, 1)

        ratio_layout.addWidget(QLabel("验证集比例:"), 1, 0)
        self.val_ratio_edit = QLineEdit()
        self.val_ratio_edit.setText("0.2")
        ratio_layout.addWidget(self.val_ratio_edit, 1, 1)

        ratio_layout.addWidget(QLabel("测试集比例:"), 2, 0)
        self.test_ratio_edit = QLineEdit()
        self.test_ratio_edit.setText("0.1")
        ratio_layout.addWidget(self.test_ratio_edit, 2, 1)

        dataset_split_layout.addLayout(ratio_layout)

        self.split_dataset_btn = QPushButton("开始划分")
        self.split_dataset_btn.clicked.connect(self.split_dataset)
        dataset_split_layout.addWidget(self.split_dataset_btn)

        self.dataset_split_progress = QProgressBar()
        self.dataset_split_progress.setVisible(False)
        dataset_split_layout.addWidget(self.dataset_split_progress)

        right_layout.addWidget(dataset_split_group)

        # === 模型训练区域 ===
        training_group = QGroupBox("模型训练")
        training_layout = QVBoxLayout(training_group)

        model_layout = QVBoxLayout()

        dataset_layout = QHBoxLayout()
        dataset_layout.addWidget(QLabel("数据集配置:"))
        self.dataset_path_edit = QLineEdit()
        self.dataset_path_edit.setPlaceholderText("选择data.yaml配置文件")
        dataset_layout.addWidget(self.dataset_path_edit)

        self.browse_dataset_btn = QPushButton("浏览")
        self.browse_dataset_btn.clicked.connect(self.browse_dataset_config)
        dataset_layout.addWidget(self.browse_dataset_btn)

        model_layout.addLayout(dataset_layout)

        # 预训练模型选择
        pretrained_layout = QHBoxLayout()
        pretrained_layout.addWidget(QLabel("预训练模型:"))
        self.pretrained_model_edit = QLineEdit()
        self.pretrained_model_edit.setPlaceholderText("选择预训练模型文件(.pt)")
        pretrained_layout.addWidget(self.pretrained_model_edit)

        self.browse_model_btn = QPushButton("浏览")
        self.browse_model_btn.clicked.connect(self.browse_pretrained_model)
        pretrained_layout.addWidget(self.browse_model_btn)

        model_layout.addLayout(pretrained_layout)

        # 检查点模型选择
        checkpoint_layout = QHBoxLayout()
        checkpoint_layout.addWidget(QLabel("检查点模型:"))
        self.checkpoint_model_edit = QLineEdit()
        self.checkpoint_model_edit.setPlaceholderText("选择检查点模型文件(.pt) - 继续训练")
        checkpoint_layout.addWidget(self.checkpoint_model_edit)

        self.browse_checkpoint_btn = QPushButton("浏览")
        self.browse_checkpoint_btn.clicked.connect(self.browse_checkpoint_model)
        checkpoint_layout.addWidget(self.browse_checkpoint_btn)

        model_layout.addLayout(checkpoint_layout)

        # 连接预训练模型和检查点模型的交互
        self.pretrained_model_edit.textChanged.connect(self.on_pretrained_model_changed)
        self.checkpoint_model_edit.textChanged.connect(self.on_checkpoint_model_changed)

        params_layout = QGridLayout()

        params_layout.addWidget(QLabel("图像尺寸:"), 0, 0)
        self.img_size_edit = QLineEdit()
        self.img_size_edit.setText("640,640")
        params_layout.addWidget(self.img_size_edit, 0, 1)

        params_layout.addWidget(QLabel("Batch Size:"), 1, 0)
        self.batch_size_edit = QLineEdit()
        self.batch_size_edit.setText("32")
        params_layout.addWidget(self.batch_size_edit, 1, 1)

        params_layout.addWidget(QLabel("Epochs:"), 2, 0)
        self.epochs_edit = QLineEdit()
        self.epochs_edit.setText("100")
        params_layout.addWidget(self.epochs_edit, 2, 1)

        params_layout.addWidget(QLabel("Workers:"), 3, 0)
        self.workers_edit = QLineEdit()
        self.workers_edit.setText("0")
        params_layout.addWidget(self.workers_edit, 3, 1)

        model_layout.addLayout(params_layout)

        # 创建训练按钮布局
        training_btn_layout = QHBoxLayout()

        self.start_training_btn = QPushButton("开始训练")
        self.start_training_btn.clicked.connect(self.start_model_training)
        training_btn_layout.addWidget(self.start_training_btn)

        # 停止训练功能已由进程列表中的统一停止方法替代
        # self.stop_training_btn = QPushButton("停止训练")
        # self.stop_training_btn.clicked.connect(self.stop_model_training)
        # self.stop_training_btn.setEnabled(False)  # 初始禁用
        # training_btn_layout.addWidget(self.stop_training_btn)

        model_layout.addLayout(training_btn_layout)

        self.training_progress = QProgressBar()
        self.training_progress.setVisible(False)
        model_layout.addWidget(self.training_progress)

        view_switch_layout = QHBoxLayout()
        self.view_switch_btn = QPushButton("切换到TensorBoard视图")
        self.view_switch_btn.clicked.connect(self.toggle_view)
        view_switch_layout.addWidget(self.view_switch_btn)

        # 添加训练图片查看按钮
        self.view_training_images_btn = QPushButton("查看训练图片")
        self.view_training_images_btn.clicked.connect(self.view_training_images)
        view_switch_layout.addWidget(self.view_training_images_btn)

        model_layout.addLayout(view_switch_layout)

        training_layout.addLayout(model_layout)

        right_layout.addWidget(training_group)

        # === 模型导出区域 ===
        export_group = QGroupBox("模型导出")
        export_layout = QVBoxLayout(export_group)

        # 模型路径选择
        model_export_layout = QHBoxLayout()
        model_export_layout.addWidget(QLabel("模型路径:"))
        self.model_export_path_edit = QLineEdit()
        self.model_export_path_edit.setPlaceholderText("选择要导出的模型文件(.pt)")
        model_export_layout.addWidget(self.model_export_path_edit)

        self.browse_export_model_btn = QPushButton("浏览")
        self.browse_export_model_btn.clicked.connect(self.browse_export_model)
        model_export_layout.addWidget(self.browse_export_model_btn)

        export_layout.addLayout(model_export_layout)

        # 导出格式输入
        format_layout = QHBoxLayout()
        format_layout.addWidget(QLabel("导出格式:"))
        self.export_format_edit = QLineEdit()
        self.export_format_edit.setPlaceholderText(
            "输入导出格式 (如: onnx, torchscript, pb, tflite, engine, coreml, paddle)")
        format_layout.addWidget(self.export_format_edit)

        export_layout.addLayout(format_layout)

        # 导出按钮
        self.export_model_btn = QPushButton("导出模型")
        self.export_model_btn.clicked.connect(self.export_model)
        export_layout.addWidget(self.export_model_btn)

        right_layout.addWidget(export_group)

        # === 模型量化和Netron视图区域 ===
        quantization_group = QGroupBox("模型量化")
        quantization_layout = QVBoxLayout(quantization_group)

        # 创建按钮布局将两个按钮放在同一行
        quantization_btn_layout = QHBoxLayout()

        # 量化按钮
        self.quantize_model_btn = QPushButton("启动模型量化工具")
        self.quantize_model_btn.clicked.connect(self.launch_quantization_tool)
        quantization_btn_layout.addWidget(self.quantize_model_btn)

        # Netron视图按钮
        self.netron_view_btn = QPushButton("切换到Netron视图")
        self.netron_view_btn.clicked.connect(self.toggle_netron_view)
        quantization_btn_layout.addWidget(self.netron_view_btn)

        quantization_layout.addLayout(quantization_btn_layout)

        right_layout.addWidget(quantization_group)

        right_layout.addStretch()

        return right_panel

    # ========== TCP探测功能 ==========
    def show_detection_dialog(self):
        """显示探测对话框"""
        dialog = DirectDetectionDialog(self.direct_detector, self)
        dialog.exec_()
        self.update_saved_ips_display()

    def update_saved_ips_display(self):
        """更新已保存IP的显示"""
        count = len(self.saved_ips) if hasattr(self, 'saved_ips') else 0
        self.saved_ips_label.setText(f"{count}个")
        if count > 0:
            ips_to_show = self.saved_ips[:10]
            self.saved_ips_label.setToolTip("\n".join(ips_to_show))

    # ========== 服务器连接功能 ==========

    
    def auto_connect_to_server(self):
        """程序启动后自动连接服务器"""
        try:
            self.statusBar().showMessage("正在自动连接服务器...")
            
            # 直接调用LANFileClient的静态方法检查服务器状态
            result = LANFileClient.get_server_status(self.server_ip, self.server_port)
            
            if result and result.get('status') == 'online':
                self.server_status_label.setText("已连接")
                self.server_status_indicator.setStyleSheet("color: green; font-weight: bold;")
                self.server_info_label.setText(f"服务器: {self.server_ip}:{self.server_port}")
                
                if self.current_folder and os.path.exists(self.current_folder):
                    self.sync_folder_to_server()

                self.distribute_btn.setEnabled(True)
                self.reverse_btn.setEnabled(True)

                self.statusBar().showMessage(f"自动连接服务器成功: {self.server_ip}:{self.server_port}", 3000)
            else:
                # 自动连接失败，但不显示错误消息，保持静默
                self.server_status_label.setText("未连接")
                self.server_status_indicator.setStyleSheet("color: orange; font-weight: bold;")
                self.server_info_label.setText(f"服务器: {self.server_ip}:{self.server_port} (自动连接失败)")
                
        except Exception as e:
            # 自动连接失败，但不显示错误消息，保持静默
            self.server_status_label.setText("未连接")
            self.server_status_indicator.setStyleSheet("color: orange; font-weight: bold;")
            self.server_info_label.setText(f"服务器: {self.server_ip}:{self.server_port} (自动连接失败)")

    def connect_to_server(self):
        """手动连接到后端服务器"""
        try:
            self.statusBar().showMessage(f"正在连接到服务器 {self.server_ip}:{self.server_port}...")
            
            # 直接调用LANFileClient的静态方法检查服务器状态
            result = LANFileClient.get_server_status(self.server_ip, self.server_port)
            
            if result and result.get('status') == 'online':
                self.server_status_label.setText("已连接")
                self.server_status_indicator.setStyleSheet("color: green; font-weight: bold;")
                self.server_info_label.setText(f"服务器: {self.server_ip}:{self.server_port}")
                
                if self.current_folder and os.path.exists(self.current_folder):
                    self.sync_folder_to_server()

                self.distribute_btn.setEnabled(True)
                self.reverse_btn.setEnabled(True)

                self.statusBar().showMessage(f"成功连接到服务器 {self.server_ip}:{self.server_port}", 3000)
            else:
                self.server_status_label.setText("连接失败")
                self.server_status_indicator.setStyleSheet("color: red; font-weight: bold;")
                self.server_info_label.setText(f"服务器: {self.server_ip}:{self.server_port} (连接失败)")
                
                error_msg = f"服务器返回: {result.get('status', '未知状态')}" if result else "无法连接到服务器，请确保后端服务已启动"
                self.statusBar().showMessage(f"无法连接到服务器: {error_msg}", 5000)
                
        except Exception as e:
            # 连接失败
            self.server_status_label.setText("连接失败")
            self.server_status_indicator.setStyleSheet("color: red; font-weight: bold;")
            self.server_info_label.setText(f"服务器: {self.server_ip}:{self.server_port} (连接失败)")
            self.statusBar().showMessage(f"连接服务器失败: {str(e)}", 5000)



    def sync_folder_to_server(self):
        """同步当前文件夹到服务器"""
        if not self.current_folder or not os.path.exists(self.current_folder):
            return

        try:
            result = LANFileClient.set_server_folder(self.server_ip, self.current_folder, self.server_port)
            if result and result.get('status') == 'success':
                print(f"已同步文件夹到服务器: {self.current_folder}")
        except Exception as e:
            print(f"同步文件夹出错: {e}")

    def start_tensorboard(self, logdir="runs/detect/train", port=6006):
        """
        通过信息面板启动TensorBoard
        :param logdir: 日志文件目录
        :param port: 端口号
        """
        if not os.path.exists(logdir):
            print(f"警告：日志目录 {logdir} 不存在，请检查路径！")
            QMessageBox.warning(self, "警告", f"日志目录 {logdir} 不存在，请检查路径！")
            return

        # 通过信息面板启动TensorBoard
        if hasattr(self, 'info_panel') and self.info_panel:
            # 首先检查是否已经有TensorBoard进程在运行
            tensorboard_processes = self.info_panel.get_running_processes_by_name(f"TensorBoard_{port}")
            if tensorboard_processes:
                # 如果已经有TensorBoard进程在运行，先停止它
                print(f"检测到TensorBoard_{port}进程已在运行，先停止现有进程")
                self.info_panel.stop_external_process(f"TensorBoard_{port}")
                # 使用QTimer非阻塞等待，避免界面冻结
                QTimer.singleShot(2000, lambda: self._delayed_start_tensorboard(logdir, port))
            else:
                # 没有运行中的进程，直接启动
                self._start_tensorboard_process(logdir, port)
        else:
            QMessageBox.critical(self, "错误", "信息面板未初始化，无法启动TensorBoard")

    def _delayed_start_tensorboard(self, logdir, port):
        """延迟启动TensorBoard"""
        # 再次检查是否还有进程在运行
        tensorboard_processes = self.info_panel.get_running_processes_by_name(f"TensorBoard_{port}")
        if not tensorboard_processes:
            # 进程已停止，启动新的TensorBoard
            self._start_tensorboard_process(logdir, port)
        else:
            # 进程仍在运行，强制停止并重试
            print(f"TensorBoard_{port}进程仍在运行，强制停止并重试")
            self.info_panel.stop_external_process(f"TensorBoard_{port}")
            QTimer.singleShot(1000, lambda: self._delayed_start_tensorboard(logdir, port))

    def _start_tensorboard_process(self, logdir, port):
        """启动TensorBoard进程"""
        # 构建TensorBoard启动命令 - 使用Python模块方式确保在Windows下也能找到
        cmd = [
            sys.executable,  # 使用当前Python解释器
            "-m", "tensorboard.main",
            "--logdir", logdir,
            "--port", str(port),
            "--host", "0.0.0.0",
            "--reload_multifile", "true",
            "--reload_interval", "30"
        ]
        
        # 通过信息面板启动进程（不进行严格的成功判断）
        self.info_panel.start_external_process(
            cmd, 
            f"TensorBoard_{port}", 
            show_in_terminal=True
        )
        
        # 直接认为启动成功，因为用户反馈实际是可以访问的
        print(f"TensorBoard启动命令已发送，端口：{port}，日志目录：{logdir}")
        # 记录日志目录用于后续检查
        self.last_training_logdir = logdir

    def get_latest_run_folder(self):
        """获取最新的训练运行文件夹，总是返回最新的训练路径"""
        detect_path = "runs/detect"
        if not os.path.exists(detect_path):
            return "runs/detect/train"

        folders = glob.glob(os.path.join(detect_path, "*"))
        folders = [f for f in folders if os.path.isdir(f)]
        if not folders:
            return "runs/detect/train"

        # 按修改时间排序，返回最新的文件夹
        latest_folder = max(folders, key=os.path.getmtime)
        return latest_folder




    # ========== 网络相关方法 ==========
    def configure_transfer(self, mode="distribution"):
        """配置传输（分发或回传）"""
        # 不再需要传统的服务器连接，因为传输功能将使用AI检测服务的地址
        # 但仍然检查是否为分发模式且没有打开文件夹
        if mode == "distribution" and not self.current_folder:
            QMessageBox.warning(self, "警告", "请先打开文件夹")
            return

        dialog = OptimizedFileTransferDialog(mode=mode, parent=self)

        if mode == "distribution":
            dialog.load_local_files_optimized()

        if dialog.exec_() == QDialog.Accepted:
            config = dialog.get_config()

            if mode == "distribution":
                if not config['target_ips']:
                    QMessageBox.warning(self, "警告", "请至少添加一个目标IP")
                    return

                if not config['selected_files']:
                    QMessageBox.warning(self, "警告", "请选择要分发的文件")
                    return

                total_files = len(config['selected_files'])
                ip_count = len(config['target_ips'])

                summary = f"分发配置摘要:\n\n目标IP数: {ip_count}\n文件总数: {total_files}\n"
                summary += f"分发模式: {'平均分发' if config['even_distribution'] else '全量分发'}\n"
                summary += f"覆盖已存在文件: {'是' if config['overwrite'] else '否'}\n"
                summary += f"并发传输: {'是' if config.get('concurrent', True) else '否'}\n"

                if config['even_distribution']:
                    summary += f"\n各IP分配文件数:\n"
                    for ip, files in config['file_groups'].items():
                        summary += f"  {ip}: {len(files)} 个文件\n"

                summary += f"\n确认开始分发？"

                reply = QMessageBox.question(
                    self, "确认分发", summary, QMessageBox.Yes | QMessageBox.No
                )

                if reply == QMessageBox.Yes:
                    self.start_transfer(config)

            elif mode == "reverse":
                if not config.get('target_ip'):
                    QMessageBox.warning(self, "警告", "请选择目标IP")
                    return

                if not config['selected_files']:
                    QMessageBox.warning(self, "警告", "请选择要回传的文件")
                    return

                summary = f"回传配置摘要:\n\n目标IP: {config['target_ip']}\n"
                summary += f"文件总数: {len(config['selected_files'])}\n"
                summary += f"覆盖已存在文件: {'是' if config['overwrite'] else '否'}\n确认开始回传？"

                reply = QMessageBox.question(
                    self, "确认回传", summary, QMessageBox.Yes | QMessageBox.No
                )

                if reply == QMessageBox.Yes:
                    self.start_transfer(config)

    def start_transfer(self, config):
        """开始传输"""
        self.transfer_worker = DistributionWorker(config, self)

        self.transfer_progress_dialog = TransferProgressDialog(self)
        self.transfer_progress_dialog.set_worker(self.transfer_worker)

        self.transfer_worker.distribution_complete.connect(
            lambda results: self.show_transfer_results(results, config)
        )

        self.transfer_progress_dialog.show()
        self.transfer_worker.start()

        mode = config.get('mode', 'distribution')
        self.statusBar().showMessage(f"开始{'分发' if mode == 'distribution' else '回传'}文件...")

    def show_transfer_results(self, results, config):
        """显示传输结果"""
        total_success = results.get('total_success', 0)
        total_fail = results.get('total_fail', 0)
        total = total_success + total_fail

        mode = config.get('mode', 'distribution')

        result_text = f"{'分发' if mode == 'distribution' else '回传'}完成！\n\n"
        result_text += f"总计: {total} 个文件\n成功: {total_success} 个\n失败: {total_fail} 个"

        if total_fail == 0:
            QMessageBox.information(self, f"{'分发' if mode == 'distribution' else '回传'}完成", result_text)
        else:
            QMessageBox.warning(self, f"{'分发' if mode == 'distribution' else '回传'}完成", result_text)

    # ========== 文件操作相关方法 ==========
    def load_folder(self):
        """加载文件夹"""
        folder_path = QFileDialog.getExistingDirectory(self, "选择图片文件夹")
        if not folder_path:
            return

        self.load_folder_with_path(folder_path)

    def load_folder_refresh(self):
        """刷新当前文件夹"""
        if self.current_folder:
            self.load_folder_with_path(self.current_folder, refresh=True)
        else:
            QMessageBox.warning(self, "提示", "请先打开一个文件夹")

    def open_single_file(self):
        """打开单个文件"""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "选择文件",
            "",
            "图像文件 (*.png *.jpg *.jpeg *.bmp *.tiff *.gif);;所有文件 (*)"
        )

        if not file_path:
            return

        # 清空当前图像列表并加载单个文件
        folder_path = os.path.dirname(file_path)
        self.current_folder = AnnotationUtils.normalize_path(folder_path)

        # 只加载选中的文件
        self.image_files = [file_path]
        self.current_image_index = 0
        self.load_image_from_list(self.current_image_index)

        self.update_nav_buttons()
        self.update_progress_label()
        self.update_files_list()



        self.refresh_folder_btn.setEnabled(True)

        if hasattr(self, 'dataset_input_path_edit') and not self.dataset_input_path_edit.text():
            self.dataset_input_path_edit.setText(self.current_folder)

        self.statusBar().showMessage(f"已打开文件: {file_path}", 3000)

    def open_video_file(self):
        """打开视频文件并将其拆分为图片"""
        video_path, _ = QFileDialog.getOpenFileName(
            self,
            "选择视频文件",
            "",
            "视频文件 (*.mp4 *.avi *.mov *.mkv *.wmv *.flv *.webm);;所有文件 (*)"
        )

        if not video_path:
            return

        # 使用Path处理中文路径
        video_path_obj = Path(video_path).resolve()
        video_path = str(video_path_obj)

        # 创建输出目录
        video_name = os.path.splitext(os.path.basename(video_path))[0]
        output_dir = str(Path(video_path).parent / video_name)

        # 检查输出目录是否已存在
        if os.path.exists(output_dir):
            reply = QMessageBox.question(
                self,
                "警告",
                f"目录 '{video_name}' 已存在。是否覆盖？",
                QMessageBox.Yes | QMessageBox.No
            )
            if reply == QMessageBox.No:
                return

            # 删除现有目录
            try:
                shutil.rmtree(output_dir)
            except OSError as e:
                QMessageBox.critical(self, "错误", f"删除现有目录失败: {str(e)}")
                return

        # 提取帧间隔设置对话框
        dialog = FrameExtractionDialog(self)
        if not dialog.exec_():
            return

        interval, prefix, seq_len = dialog.get_values()

        try:
            os.makedirs(output_dir, exist_ok=True)

            # 为了解决中文路径问题，创建临时文件进行处理
            _, ext = os.path.splitext(video_path)
            with tempfile.NamedTemporaryFile(suffix=ext, delete=False) as tmp_file:
                temp_video_path = tmp_file.name

            # 复制原视频到临时文件
            shutil.copy2(video_path, temp_video_path)

            try:
                # 使用临时文件路径进行处理
                cap = cv2.VideoCapture(temp_video_path)
                total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
                fps = int(cap.get(cv2.CAP_PROP_FPS))

                # 创建进度对话框
                progress = QProgressDialog("正在提取视频帧...", "取消", 0, total_frames, self)
                progress.setWindowTitle("提取进度")
                progress.setWindowModality(Qt.WindowModal)
                progress.show()

                frame_count = 0
                saved_count = 0
                while True:
                    if progress.wasCanceled():
                        break

                    ret, frame = cap.read()
                    if not ret:
                        break

                    # 按指定间隔保存帧
                    if frame_count % interval == 0:
                        filename = f"{prefix}{str(saved_count).zfill(seq_len)}.jpg"
                        filepath = os.path.join(output_dir, filename)
                        # 使用imencode解决中文路径问题
                        success, encoded_image = cv2.imencode('.jpg', frame)
                        if success:
                            with open(filepath, 'wb') as f:
                                f.write(encoded_image.tobytes())
                        saved_count += 1

                    frame_count += 1
                    progress.setValue(frame_count)
                    QApplication.processEvents()

                cap.release()

            finally:
                # 清理临时文件
                if os.path.exists(temp_video_path):
                    os.unlink(temp_video_path)

            progress.close()

            if saved_count > 0:
                # 加载提取的帧文件夹
                self.load_folder_with_path(output_dir)
                self.statusBar().showMessage(f"视频已成功提取为 {saved_count} 张图片: {output_dir}", 5000)
            else:
                QMessageBox.information(self, "提示", "没有提取到任何帧")

        except Exception as e:
            QMessageBox.critical(self, "错误", f"提取视频帧时发生错误: {str(e)}")

    def extract_frames_from_video(self, video_path, output_dir, interval=1, prefix="frame_", seq_len=5):
        """从视频中提取帧"""
        try:
            os.makedirs(output_dir, exist_ok=True)

            cap = cv2.VideoCapture(video_path)
            total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

            progress = QProgressDialog("正在提取视频帧...", "取消", 0, total_frames, self)
            progress.setWindowTitle("提取进度")
            progress.setWindowModality(Qt.WindowModal)
            progress.show()

            frame_count = 0
            saved_count = 0
            while True:
                if progress.wasCanceled():
                    break

                ret, frame = cap.read()
                if not ret:
                    break

                if frame_count % interval == 0:
                    filename = f"{prefix}{str(saved_count).zfill(seq_len)}.jpg"
                    filepath = os.path.join(output_dir, filename)
                    cv2.imwrite(filepath, frame)
                    saved_count += 1

                frame_count += 1
                progress.setValue(frame_count)
                QApplication.processEvents()

            cap.release()
            progress.close()

            return saved_count
        except Exception as e:
            print(f"提取视频帧时发生错误: {str(e)}")
            return 0

    def load_folder_with_path(self, folder_path, refresh=False):
        """使用指定路径加载文件夹"""
        self.current_folder = AnnotationUtils.normalize_path(folder_path)

        # 扫描图片文件
        self.image_files = AnnotationUtils.filter_files_by_extensions(
            folder_path, ['.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.gif']
        )

        # 更新UI
        if self.image_files:
            self.current_image_index = 0
            self.load_image_from_list(self.current_image_index)
        else:
            self.current_image_index = -1
            self.current_file_path = ""
            self.image_viewer.pixmap = None
            self.image_viewer.update_display()
            self.setWindowTitle(f"图像标注工具 - {os.path.basename(folder_path)}")

            self.image_viewer.shapes = []
            self.update_shapes_list()
            self.update_labels_list()

        self.update_nav_buttons()
        self.update_progress_label()
        self.update_files_list()



        self.refresh_folder_btn.setEnabled(True)

        if hasattr(self, 'dataset_input_path_edit') and not self.dataset_input_path_edit.text():
            self.dataset_input_path_edit.setText(self.current_folder)

        file_count = len(self.image_files)
        if not refresh:
            if file_count > 0:
                self.statusBar().showMessage(f"已打开文件夹: {folder_path} ({file_count} 个文件)", 3000)
            else:
                self.statusBar().showMessage(f"已打开空文件夹: {folder_path}", 3000)
        else:
            self.statusBar().showMessage(f"文件夹已刷新: {folder_path} ({file_count} 个文件)", 2000)

    def load_image_from_list(self, index):
        """从列表加载图片"""
        if 0 <= index < len(self.image_files):
            file_path = self.image_files[index]
            try:
                self.image_viewer.load_image(file_path)
                self.current_file_path = file_path
                self.setWindowTitle(f"图像标注工具 - {os.path.basename(file_path)}")

                # 自动加载标注
                for annotation_path in AnnotationUtils.get_annotation_file_paths(file_path):
                    if os.path.exists(annotation_path):
                        self.load_annotation(annotation_path)
                        break

                # 更新全局标签
                for label in AnnotationUtils.get_existing_labels(self.image_viewer.shapes):
                    self.global_labels.add(label)

                self.update_shapes_list()
                self.update_labels_list()

                self.center_image_in_scrollarea()

            except Exception as e:
                QMessageBox.critical(self, "错误", f"无法加载图片: {str(e)}")

    def update_files_list(self):
        """更新文件列表"""
        self.files_list.clear()
        for i, file_path in enumerate(self.image_files):
            item = QListWidgetItem(os.path.basename(file_path))
            item.setData(Qt.UserRole, i)
            if i == self.current_image_index:
                item.setSelected(True)
                item.setBackground(QColor(200, 230, 255))
            self.files_list.addItem(item)

    def prev_image(self):
        """上一张"""
        if not self.image_files:
            QMessageBox.warning(self, "提示", "未打开图片文件夹！")
            return

        if self.current_image_index <= 0:
            QMessageBox.information(self, "提示", "已经是第一张图片！")
            return

        self.current_image_index -= 1
        self.load_image_from_list(self.current_image_index)
        self.update_nav_buttons()
        self.update_progress_label()
        self.update_files_list()

    def next_image(self):
        """下一张"""
        if not self.image_files:
            QMessageBox.warning(self, "提示", "未打开图片文件夹！")
            return

        if self.current_image_index >= len(self.image_files) - 1:
            QMessageBox.information(self, "提示", "已经是最后一张图片！")
            return

        self.current_image_index += 1
        self.load_image_from_list(self.current_image_index)
        self.update_nav_buttons()
        self.update_progress_label()
        self.update_files_list()

    def update_nav_buttons(self):
        """更新导航按钮状态"""
        has_files = bool(self.image_files)
        self.prev_btn.setEnabled(has_files and self.current_image_index > 0)
        self.next_btn.setEnabled(has_files and self.current_image_index < len(self.image_files) - 1)

    def update_progress_label(self):
        """更新进度标签"""
        if self.image_files:
            self.progress_label.setText(f"进度: {self.current_image_index + 1}/{len(self.image_files)}")
        else:
            self.progress_label.setText("")

    def on_file_selected(self, item):
        """文件选择事件"""
        index = item.data(Qt.UserRole)
        if 0 <= index < len(self.image_files):
            self.current_image_index = index
            self.load_image_from_list(self.current_image_index)
            self.update_nav_buttons()
            self.update_progress_label()
            self.update_files_list()

    def load_annotation(self, annotation_path):
        """加载标注"""
        try:
            label_file = LabelFile()
            label_file.load(annotation_path)
            self.image_viewer.shapes = label_file.shapes

            # 更新形状的缩放和颜色
            for shape in self.image_viewer.shapes:
                shape.scale = self.image_viewer.scale_factor
                
                # 确保颜色正确设置（如果JSON中没有保存颜色信息）
                if not shape.line_color or shape.line_color == QColor("red"):
                    from .color_utils import ColorUtils
                    shape.line_color = ColorUtils.get_color_for_label(shape.label)
                    shape.fill_color = QColor(
                        shape.line_color.red(),
                        shape.line_color.green(),
                        shape.line_color.blue(),
                        30
                    )

            self.update_shapes_list()
            self.update_labels_list()
            self.image_viewer.update()
        except Exception as e:
            self.statusBar().showMessage(f"加载标注失败: {str(e)}", 3000)



    def save_annotation_silent(self):
        """静默保存标注（无提示）"""
        if not self.current_file_path or not os.path.exists(self.current_file_path):
            return

        for annotation_path in AnnotationUtils.get_annotation_file_paths(self.current_file_path):
            try:
                label_file = LabelFile()
                label_file.save(
                    filename=annotation_path,
                    shapes=self.image_viewer.shapes,
                    image_path=os.path.basename(self.current_file_path),
                    image_height=self.image_viewer.original_height,
                    image_width=self.image_viewer.original_width
                )
            except Exception as e:
                pass

    def check_save_before_switch(self):
        """切换图片前自动保存标注"""
        self.save_annotation_silent()
        return True

    def set_mode(self, mode):
        """设置标注模式"""
        self.current_mode = mode
        self.image_viewer.mode = mode
        self.update_mode_buttons()

    def update_mode_buttons(self):
        """更新模式按钮样式"""
        buttons = {
            "rectangle": self.rect_btn,
            "rotation": self.rotation_btn,
            "polygon": self.polygon_btn,
            "circle": self.circle_btn,
            "line": self.line_btn,
            "point": self.point_btn
        }
        for btn_mode, btn in buttons.items():
            if btn_mode == self.current_mode:
                btn.setStyleSheet("background-color: lightblue; font-weight: bold;")
            else:
                btn.setStyleSheet("")

    def reset_zoom(self):
        """重置缩放"""
        if hasattr(self, 'image_viewer') and self.image_viewer:
            try:
                self.image_viewer.reset_zoom()
                self.center_image_in_scrollarea()
            except:
                if hasattr(self, 'tensorboard_view'):
                    self.tensorboard_view.refresh_page()
        else:
            if hasattr(self, 'tensorboard_view'):
                self.tensorboard_view.refresh_page()

    def center_image_in_scrollarea(self):
        """将图片居中显示在滚动区域中"""
        if hasattr(self, 'image_viewer') and hasattr(self, 'canvas_scroll') and self.image_viewer:
            try:
                from PySide6.QtCore import QTimer
                timer = QTimer(self)
                timer.setSingleShot(True)
                timer.timeout.connect(self._perform_centering)
                timer.start(50)
            except:
                pass
        else:
            if hasattr(self, 'tensorboard_view'):
                self.tensorboard_view.refresh_page()

    def _perform_centering(self):
        """执行实际的居中操作"""
        if hasattr(self, 'image_viewer') and hasattr(self, 'canvas_scroll') and self.image_viewer:
            try:
                self.canvas_scroll.update()
                self.image_viewer.update()
                QApplication.processEvents()

                h_bar = self.canvas_scroll.horizontalScrollBar()
                v_bar = self.canvas_scroll.verticalScrollBar()

                h_min, h_max = h_bar.minimum(), h_bar.maximum()
                v_min, v_max = v_bar.minimum(), v_bar.maximum()

                h_center = h_min + (h_max - h_min) // 2
                v_center = v_min + (v_max - v_min) // 2

                h_bar.setValue(h_center)
                v_bar.setValue(v_center)
            except:
                pass

    def delete_selected(self):
        """删除选中形状"""
        if hasattr(self, 'image_viewer') and self.image_viewer:
            try:
                self.image_viewer.delete_selected()
            except:
                pass

    def update_labels_list(self):
        """更新标签列表"""
        self.labels_list.clear()
        current_labels = AnnotationUtils.get_existing_labels(self.image_viewer.shapes)
        all_labels = set(current_labels) | self.global_labels

        for label in sorted(all_labels):
            self.labels_list.addItem(label)

    def update_shapes_list(self):
        """更新形状列表"""
        self.shapes_list.clear()
        for i, shape in enumerate(self.image_viewer.shapes):
            shape_info = f"[{i + 1}] {shape.label.strip() or '未命名'}"
            if shape.shape_type != "rectangle":
                shape_info += f" ({shape.shape_type})"

            if shape.points:
                x_coords = [p.x() for p in shape.points]
                y_coords = [p.y() for p in shape.points]
                shape_info += f" [{int(min(x_coords))},{int(min(y_coords))}]→[{int(max(x_coords))},{int(max(y_coords))}]"

            item = QListWidgetItem(shape_info)
            item.setData(Qt.UserRole, i)
            item.setForeground(shape.line_color)
            self.shapes_list.addItem(item)

    def on_shape_selected(self, item):
        """形状选择事件"""
        index = item.data(Qt.UserRole)
        if 0 <= index < len(self.image_viewer.shapes):
            self.image_viewer.selected_shape = self.image_viewer.shapes[index]
            self.image_viewer.hover_shape = self.image_viewer.shapes[index]
            self.image_viewer.update()

    def on_label_double_clicked(self, item):
        """标签双击事件"""
        label_name = item.text().strip()
        if not label_name:
            return

        dialog = QDialog(self)
        dialog.setWindowTitle("编辑标签")
        dialog.resize(300, 250)

        layout = QVBoxLayout(dialog)
        layout.addWidget(QLabel(f"当前标签: {label_name}"))

        button_layout = QHBoxLayout()

        modify_btn = QPushButton("修改标签")
        modify_btn.clicked.connect(lambda: self._modify_label(label_name, dialog))

        color_btn = QPushButton("修改颜色")
        color_btn.clicked.connect(lambda: self._change_label_color(label_name, dialog))

        delete_btn = QPushButton("删除标签")
        delete_btn.clicked.connect(lambda: self._delete_label(label_name, dialog))

        button_layout.addWidget(modify_btn)
        button_layout.addWidget(color_btn)
        button_layout.addWidget(delete_btn)
        layout.addLayout(button_layout)

        cancel_btn = QPushButton("取消")
        cancel_btn.clicked.connect(dialog.reject)
        layout.addWidget(cancel_btn)

        dialog.exec_()

    def browse_dataset_input_path(self):
        """浏览数据集输入路径"""
        folder_path = QFileDialog.getExistingDirectory(self, "选择输入数据集路径")
        if folder_path:
            self.dataset_input_path_edit.setText(folder_path)













    def browse_dataset_output_path(self):
        """浏览数据集输出路径"""
        folder_path = QFileDialog.getExistingDirectory(self, "选择输出数据集路径")
        if folder_path:
            self.dataset_output_path_edit.setText(folder_path)

    def split_dataset(self):
        """执行数据集划分"""
        try:
            input_path = self.dataset_input_path_edit.text().strip()
            output_path = self.dataset_output_path_edit.text().strip()

            if not input_path:
                if self.current_folder and os.path.exists(self.current_folder):
                    input_path = self.current_folder
                else:
                    QMessageBox.warning(self, "警告", "请先打开一个图片文件夹作为数据源!")
                    return
            elif not os.path.exists(input_path):
                QMessageBox.warning(self, "警告", "请输入有效的输入数据集路径!")
                return

            if not output_path:
                QMessageBox.warning(self, "警告", "请选择输出数据集路径!")
                return

            try:
                train_ratio = float(self.train_ratio_edit.text().strip())
                val_ratio = float(self.val_ratio_edit.text().strip())
                test_ratio = float(self.test_ratio_edit.text().strip())
            except ValueError:
                QMessageBox.critical(self, "错误", "划分比例必须是数字!")
                return

            total_ratio = train_ratio + val_ratio + test_ratio
            if abs(total_ratio - 1.0) > 1e-6:
                QMessageBox.critical(self, "错误", f"划分比例之和必须等于1，当前为 {total_ratio}")
                return

            # 从数据集中自动提取类别名称
            classes_file = os.path.join(input_path, "label.txt")
            if os.path.exists(classes_file):
                with open(classes_file, 'r', encoding='utf-8') as f:
                    class_names = [line.strip() for line in f.readlines() if line.strip()]
            else:
                class_names = []
                labels_dir = os.path.join(input_path, "labels")
                if os.path.exists(labels_dir):
                    all_labels = set()
                    for txt_file in os.listdir(labels_dir):
                        if txt_file.endswith('.txt'):
                            txt_path = os.path.join(labels_dir, txt_file)
                            try:
                                with open(txt_path, 'r', encoding='utf-8') as f:
                                    for line in f:
                                        line = line.strip()
                                        if line:
                                            pass  # YOLO格式只有ID，无法获取原始类别名
                            except Exception:
                                continue
                if not class_names and os.path.exists(input_path):
                    json_files = [f for f in os.listdir(input_path) if
                                  f.endswith('.json')]
                    if json_files:
                        all_labels = set()
                        for json_file in json_files:
                            try:
                                with open(os.path.join(input_path, json_file), 'r', encoding='utf-8') as f:
                                    data = json.load(f)
                                    if 'shapes' in data:
                                        for shape in data['shapes']:
                                            if 'label' in shape and shape['label'].strip():
                                                all_labels.add(shape['label'].strip())
                            except Exception:
                                continue
                        if all_labels:
                            class_names = sorted(list(all_labels))
                    else:
                        if self.current_folder and os.path.exists(self.current_folder):
                            all_labels = set()
                            for file in os.listdir(self.current_folder):
                                if file.endswith('.json'):
                                    json_file_path = os.path.join(self.current_folder, file)
                                    try:
                                        with open(json_file_path, 'r', encoding='utf-8') as f:
                                            data = json.load(f)
                                            if 'shapes' in data:
                                                for shape in data['shapes']:
                                                    if 'label' in shape and shape['label'].strip():
                                                        all_labels.add(shape['label'].strip())
                                    except Exception:
                                        continue
                            if all_labels:
                                class_names = sorted(list(all_labels))

            # 检查输入路径是否已经是YOLO格式
            images_dir = os.path.join(input_path, "images")
            labels_dir = os.path.join(input_path, "labels")
            is_yolo_format = os.path.exists(images_dir) and os.path.exists(labels_dir)

            # 如果不是YOLO格式，需要先转换
            if not is_yolo_format:
                json_files = [f for f in os.listdir(input_path) if f.endswith('.json')]
                if json_files:
                    temp_yolo_path = os.path.join(input_path, "temp_yolo_dataset")
                    os.makedirs(temp_yolo_path, exist_ok=True)
                    temp_images_dir = os.path.join(temp_yolo_path, "images")
                    temp_labels_dir = os.path.join(temp_yolo_path, "labels")
                    os.makedirs(temp_images_dir, exist_ok=True)
                    os.makedirs(temp_labels_dir, exist_ok=True)

                    classes_file = os.path.join(input_path, "label.txt")
                    if not os.path.exists(classes_file):
                        all_labels = set()
                        for json_file in json_files:
                            try:
                                with open(os.path.join(input_path, json_file), 'r', encoding='utf-8') as f:
                                    data = json.load(f)
                                    if 'shapes' in data:
                                        for shape in data['shapes']:
                                            if 'label' in shape and shape['label'].strip():
                                                all_labels.add(shape['label'].strip())
                            except Exception:
                                continue

                        if all_labels:
                            with open(classes_file, 'w', encoding='utf-8') as f:
                                for label in sorted(all_labels):
                                    f.write(f"{label}\n")

                    converter = LabelConverter(classes_file=classes_file)

                    for json_file in json_files:
                        json_path = os.path.join(input_path, json_file)
                        base_name = os.path.splitext(json_file)[0]
                        image_found = False
                        for ext in ['.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.gif']:
                            img_path = os.path.join(input_path, base_name + ext)
                            if os.path.exists(img_path):
                                dest_img_path = os.path.join(temp_images_dir, os.path.basename(img_path))
                                shutil.copy2(img_path, dest_img_path)

                                yolo_txt_path = os.path.join(temp_labels_dir, base_name + ".txt")
                                try:
                                    converter.custom_to_yolo(
                                        input_file=json_path,
                                        output_file=yolo_txt_path,
                                        mode="hbb",
                                        skip_empty_files=False
                                    )
                                except Exception as e:
                                    print(f"转换文件 {json_file} 时出错: {e}")

                                image_found = True
                                break

                    input_path = temp_yolo_path
                else:
                    QMessageBox.warning(self, "警告", "输入路径不包含有效的YOLO格式数据或JSON标注文件!")
                    return

            # 计算总的文件数量用于进度显示
            splitter = DatasetSplitter(input_path)
            pairs = splitter.get_image_label_pairs()
            total_count = len(pairs)

            # 创建进度对话框
            from PySide6.QtWidgets import QProgressDialog
            from PySide6.QtCore import Qt
            progress = QProgressDialog("正在划分数据集...", "取消", 0, total_count, self)
            progress.setWindowTitle("数据集划分进度")
            progress.setWindowModality(Qt.WindowModal)
            progress.show()

            # 定义进度回调函数
            def progress_callback(current, total):
                progress.setValue(current)
                QApplication.processEvents()
                if progress.wasCanceled():
                    # 如果用户取消了操作，可以在这里处理中断逻辑
                    # 由于目前的实现是同步的，我们仅检查是否取消
                    pass

            # 在后台线程中执行划分任务
            class DatasetSplitThread(QThread):
                split_finished = Signal(dict)
                split_error = Signal(str)

                def __init__(self, input_path, output_path, train_ratio, val_ratio, test_ratio, class_names):
                    super().__init__()
                    self.input_path = input_path
                    self.output_path = output_path
                    self.train_ratio = train_ratio
                    self.val_ratio = val_ratio
                    self.test_ratio = test_ratio
                    self.class_names = class_names

                def run(self):
                    import shutil
                    try:
                        stats = split_dataset_from_folder(
                            source_folder=self.input_path,
                            output_folder=self.output_path,
                            train_ratio=self.train_ratio,
                            val_ratio=self.val_ratio,
                            test_ratio=self.test_ratio,
                            class_names=self.class_names if self.class_names else None,
                            use_absolute_path=True,
                            progress_callback=progress_callback
                        )

                        if "temp_yolo_dataset" in self.input_path:
                            try:
                                shutil.rmtree(self.input_path)
                            except Exception as e:
                                print(f"清理临时文件时出错: {e}")

                        self.split_finished.emit(stats)
                    except Exception as e:
                        if "temp_yolo_dataset" in self.input_path:
                            try:
                                shutil.rmtree(self.input_path)
                            except Exception as cleanup_e:
                                print(f"清理临时文件时出错: {cleanup_e}")
                        self.split_error.emit(str(e))

            self.dataset_split_thread = DatasetSplitThread(
                input_path, output_path, train_ratio, val_ratio, test_ratio, class_names
            )

            def on_split_finished(stats):
                progress.close()
                msg = f"数据集划分完成!\n\n统计信息:\n训练集: {stats['train']} 个\n验证集: {stats['val']} 个\n测试集: {stats['test']} 个\n总计: {stats['total']} 个"
                QMessageBox.information(self, "划分完成", msg)

            def on_split_error(error):
                progress.close()
                QMessageBox.critical(self, "划分错误", f"数据集划分过程中出现错误:\n{error}")

            self.dataset_split_thread.split_finished.connect(on_split_finished)
            self.dataset_split_thread.split_error.connect(on_split_error)

            self.dataset_split_thread.start()

        except Exception as e:
            QMessageBox.critical(self, "错误", f"启动数据集划分时出现错误:\n{str(e)}")

    def _modify_label(self, old_label, dialog):
        """修改标签"""
        new_label, ok = QInputDialog.getText(self, "修改标签", "新标签名称:", QLineEdit.Normal, old_label)
        if ok and new_label.strip():
            new_label = new_label.strip()
            for shape in self.image_viewer.shapes:
                if shape.label.strip() == old_label:
                    shape.label = new_label
                    shape.line_color = ColorUtils.get_color_for_label(new_label)
                    shape.fill_color = QColor(shape.line_color.red(),
                                              shape.line_color.green(),
                                              shape.line_color.blue(),
                                              30)

            self.global_labels.discard(old_label)
            self.global_labels.add(new_label)

            dialog.accept()
            self.update_labels_list()
            self.update_shapes_list()
            self.image_viewer.update()

    def _change_label_color(self, label_name, dialog):
        """修改标签颜色"""
        from PySide6.QtWidgets import QColorDialog

        current_color = None
        for shape in self.image_viewer.shapes:
            if shape.label.strip() == label_name:
                current_color = shape.line_color
                break

        if current_color is None:
            current_color = ColorUtils.get_color_for_label(label_name)

        color_dialog = QColorDialog(current_color, self)
        color_dialog.setWindowTitle(f"选择 '{label_name}' 的颜色")

        if color_dialog.exec_():
            selected_color = color_dialog.currentColor()

            for shape in self.image_viewer.shapes:
                if shape.label.strip() == label_name:
                    shape.line_color = selected_color
                    shape.fill_color = QColor(selected_color.red(),
                                              selected_color.green(),
                                              selected_color.blue(),
                                              30)

            dialog.accept()
            self.update_shapes_list()
            self.image_viewer.update()
            self.save_annotation_silent()

    def _delete_label(self, label_name, dialog):
        """删除标签"""
        shape_count = sum(1 for shape in self.image_viewer.shapes if shape.label.strip() == label_name)

        if shape_count == 0:
            QMessageBox.information(self, "提示", f"标签 '{label_name}' 没有对应的标注框！")
            dialog.accept()
            return

        reply = QMessageBox.question(
            self, "确认删除",
            f"确定要删除标签 '{label_name}' 吗？\n这将同时删除该标签对应的 {shape_count} 个标注框！",
            QMessageBox.Yes | QMessageBox.No
        )

        if reply == QMessageBox.Yes:
            self.image_viewer.shapes = [s for s in self.image_viewer.shapes if s.label.strip() != label_name]
            self.image_viewer.selected_shape = None
            self.image_viewer.hover_shape = None

            if not any(s.label.strip() == label_name for s in self.image_viewer.shapes):
                self.global_labels.discard(label_name)

            dialog.accept()
            self.update_labels_list()
            self.update_shapes_list()
            self.image_viewer.update()

    def keyPressEvent(self, event):
        """键盘事件"""
        if event.key() == Qt.Key_Escape:
            self.image_viewer.current_shape = None
            self.image_viewer.drawing = False
        elif event.key() == Qt.Key_Delete:
            self.delete_selected()
        elif event.key() == Qt.Key_R:
            self.reset_zoom()
        elif event.key() in [Qt.Key_Plus, Qt.Key_Equal]:
            self.image_viewer.zoom_in()
        elif event.key() == Qt.Key_Minus:
            self.image_viewer.zoom_out()
        elif event.key() == Qt.Key_A:
            self.prev_image()
        elif event.key() == Qt.Key_D:
            self.next_image()
        elif event.key() == Qt.Key_Left:
            self.prev_image()
        elif event.key() == Qt.Key_Right:
            self.next_image()
        elif event.key() == Qt.Key_S and event.modifiers() & Qt.ControlModifier:
            self.save_annotation_silent()
        else:
            super().keyPressEvent(event)

    def closeEvent(self, event):
        """关闭事件"""
        # 清理所有运行中的后端服务
        self.cleanup_backend_services()
        
        # 接受关闭事件
        event.accept()
    
    def cleanup_backend_services(self):
        """清理所有运行中的后端服务"""
        print("正在清理后端服务...")
        
        # 1. 清理TensorBoard进程
        if hasattr(self, 'tensorboard_process') and self.tensorboard_process:
            try:
                print("正在终止TensorBoard进程...")
                self.tensorboard_process.terminate()
                self.tensorboard_process.wait(timeout=5)  # 等待5秒
                print("TensorBoard进程已终止")
            except Exception as e:
                print(f"终止TensorBoard进程时出错: {e}")
                try:
                    self.tensorboard_process.kill()  # 强制终止
                    print("TensorBoard进程已被强制终止")
                except Exception as kill_e:
                    print(f"强制终止TensorBoard进程失败: {kill_e}")
        
        # 2. 清理Netron进程
        if hasattr(self, 'netron_process') and self.netron_process:
            try:
                print("正在终止Netron进程...")
                self.netron_process.terminate()
                self.netron_process.wait(timeout=5)  # 等待5秒
                print("Netron进程已终止")
            except Exception as e:
                print(f"终止Netron进程时出错: {e}")
                try:
                    self.netron_process.kill()  # 强制终止
                    print("Netron进程已被强制终止")
                except Exception as kill_e:
                    print(f"强制终止Netron进程失败: {kill_e}")
        
        # 3. 清理信息面板中的外部进程
        if hasattr(self, 'info_panel') and self.info_panel:
            try:
                print("正在清理信息面板中的进程...")
                # 获取所有运行中的进程并终止它们
                running_processes = self.info_panel.get_all_running_processes()
                for process_info in running_processes:
                    try:
                        process = process_info.get('process')
                        if process and process.poll() is None:  # 进程仍在运行
                            process_name = process_info.get('name', '未知进程')
                            print(f"正在终止进程: {process_name}")
                            process.terminate()
                            process.wait(timeout=3)
                            print(f"进程 {process_name} 已终止")
                    except Exception as proc_e:
                        print(f"终止进程 {process_info.get('name', '未知进程')} 时出错: {proc_e}")
                
                # 清理信息面板的进程列表（通过清空running_processes字典）
                if hasattr(self.info_panel, 'running_processes'):
                    self.info_panel.running_processes.clear()
                print("信息面板进程已清理")
            except Exception as e:
                print(f"清理信息面板进程时出错: {e}")
        
        # 4. 清理TensorBoard和Netron浏览器视图
        if hasattr(self, 'tensorboard_view') and self.tensorboard_view:
            try:
                self.tensorboard_view.cleanup()
                print("TensorBoard视图已清理")
            except Exception as e:
                print(f"清理TensorBoard视图时出错: {e}")
        
        if hasattr(self, 'netron_view') and self.netron_view:
            try:
                self.netron_view.cleanup()
                print("Netron视图已清理")
            except Exception as e:
                print(f"清理Netron视图时出错: {e}")
        
        print("后端服务清理完成")


    







    def convert_all_json_to_yolo(self):
        """将当前文件夹中所有JSON标注批量转换为YOLO格式"""
        if not self.current_folder or not os.path.exists(self.current_folder):
            QMessageBox.warning(self, "警告", "请先打开一个图片文件夹！")
            return

        output_dir = QFileDialog.getExistingDirectory(
            self,
            "选择YOLO文件输出目录",
            self.current_folder
        )

        if not output_dir:
            return

        json_files = []
        for file in os.listdir(self.current_folder):
            if file.lower().endswith('.json'):
                json_file_path = os.path.join(self.current_folder, file)
                json_files.append(json_file_path)

        if not json_files:
            QMessageBox.information(self, "提示", "当前文件夹中没有找到JSON标注文件！")
            return

        classes_file = os.path.join(self.current_folder, "label.txt")
        if not os.path.exists(classes_file):
            try:
                all_labels = set()
                for json_file in json_files:
                    try:
                        label_file = LabelFile()
                        label_file.load(json_file)
                        for shape in label_file.shapes:
                            if shape.label.strip():
                                all_labels.add(shape.label.strip())
                    except:
                        continue

                if all_labels:
                    with open(classes_file, 'w', encoding='utf-8') as f:
                        for label in sorted(all_labels):
                            f.write(f"{label}\n")
                    QMessageBox.information(self, "提示", f"已创建label.txt文件，包含 {len(all_labels)} 个类别。")
                else:
                    QMessageBox.warning(self, "警告", "当前JSON文件中没有标签，无法创建label.txt。")
                    return
            except Exception as e:
                QMessageBox.critical(self, "错误", f"创建label.txt失败: {str(e)}")
                return

        converter = LabelConverter(classes_file=classes_file)
        successful_conversions = 0
        failed_conversions = 0

        from PySide6.QtWidgets import QProgressDialog
        from PySide6.QtCore import Qt

        progress = QProgressDialog("正在转换JSON标注文件为YOLO格式...", "取消", 0, len(json_files), self)
        progress.setWindowTitle("转换进度")
        progress.setWindowModality(Qt.WindowModal)
        progress.show()

        for i, json_file in enumerate(json_files):
            if progress.wasCanceled():
                break

            try:
                file_name = os.path.splitext(os.path.basename(json_file))[0]
                yolo_txt_path = os.path.join(output_dir, f"{file_name}.txt")

                is_empty = converter.custom_to_yolo(
                    input_file=json_file,
                    output_file=yolo_txt_path,
                    mode="hbb",
                    skip_empty_files=False
                )

                successful_conversions += 1
            except Exception as e:
                failed_conversions += 1
                print(f"转换失败 {json_file}: {str(e)}")

            progress.setValue(i + 1)
            QApplication.processEvents()

        progress.close()

        result_msg = f"批量转换完成！\n成功: {successful_conversions} 个文件"
        if failed_conversions > 0:
            result_msg += f"\n失败: {failed_conversions} 个文件"
        QMessageBox.information(self, "转换完成", result_msg)

    def test_ai_service_connection(self):
        """测试AI服务连接"""
        import requests
        import json
        
        # 优先使用存储的数据，如果没有则使用当前文本
        service_url = self.ai_service_url_combo.currentData()
        if not service_url:
            service_url = self.ai_service_url_combo.currentText().strip()
        
        if not service_url:
            QMessageBox.warning(self, "警告", "请选择或输入AI检测服务地址！")
            return
            
        try:
            # 测试基本连接
            test_url = service_url.replace("/v1/predict/", "/health")
            response = requests.get(test_url, timeout=5)
            
            if response.status_code == 200:
                result = response.json()
                if result.get("status") == "healthy":
                    QMessageBox.information(self, "连接成功", f"AI服务连接正常！\n服务状态: {result}")
                    self.statusBar().showMessage("AI服务连接测试成功", 3000)
                else:
                    QMessageBox.warning(self, "服务状态异常", f"AI服务响应但状态异常: {result}")
                    self.statusBar().showMessage("AI服务状态异常", 3000)
            else:
                QMessageBox.critical(self, "连接失败", f"AI服务连接失败，状态码: {response.status_code}")
                self.statusBar().showMessage("AI服务连接失败", 3000)
                
        except requests.exceptions.ConnectionError:
            QMessageBox.critical(self, "连接错误", "无法连接到AI检测服务，请检查服务地址和网络连接！")
            self.statusBar().showMessage("AI服务连接错误", 3000)
        except requests.exceptions.Timeout:
            QMessageBox.critical(self, "连接超时", "连接AI检测服务超时，请检查服务是否正常运行！")
            self.statusBar().showMessage("AI服务连接超时", 3000)
        except Exception as e:
            QMessageBox.critical(self, "错误", f"测试AI服务连接时发生错误: {str(e)}")
            self.statusBar().showMessage(f"AI服务测试错误: {str(e)}", 3000)

    def start_ai_detection(self):
        """开始AI检测 - 在当前图片上运行检测"""
        if not hasattr(self, 'current_file_path') or not self.current_file_path:
            QMessageBox.warning(self, "警告", "请先打开一张图片！")
            return
            
        # 获取当前图片路径
        image_path = self.current_file_path
        if not os.path.exists(image_path):
            QMessageBox.critical(self, "错误", f"图片文件不存在: {image_path}")
            return
            
        # 获取配置参数
        # 优先使用存储的数据，如果没有则使用当前文本
        service_url = self.ai_service_url_combo.currentData()
        if not service_url:
            service_url = self.ai_service_url_combo.currentText().strip()
        conf_threshold = float(self.conf_threshold_edit.text().strip()) if self.conf_threshold_edit.text().strip() else 0.3
        nms_threshold = float(self.nms_threshold_edit.text().strip()) if self.nms_threshold_edit.text().strip() else 0.5
        model_path = self.model_path_edit.text().strip()
        classes_str = self.classes_edit.text().strip()
        instance_name = self.instance_name_edit.text().strip()
        
        # 解析类别列表
        classes = []
        if classes_str:
            try:
                classes = [int(x.strip()) for x in classes_str.split(',') if x.strip()]
            except ValueError:
                QMessageBox.warning(self, "警告", "检测类别格式错误，请输入数字，用逗号分隔！")
                return
        
        if not service_url:
            QMessageBox.warning(self, "警告", "请输入AI检测服务地址！")
            return
            
        try:
            # 准备请求参数
            params = {
                "conf_threshold": conf_threshold,
                "nms_threshold": nms_threshold,
                "model_abs_path": model_path,
                "classes": classes,
                "instance_name": instance_name
            }
            
            # 执行检测
            self.statusBar().showMessage("正在执行AI检测，请稍候...")
            
            # 导入必要的库
            import requests
            import base64
            import cv2
            import numpy as np
            from pathlib import Path
            
            # 读取图片并编码
            img_bytes = Path(image_path).read_bytes()
            img_base64 = base64.b64encode(img_bytes).decode()
            
            # 构建请求载荷
            payload = {
                "image": f"data:image/jpeg;base64,{img_base64}"
            }
            payload.update(params)
            
            # 发送请求
            response = requests.post(service_url, json=payload, timeout=30)
            result = response.json()
            
            if result.get("success"):
                # 成功检测，保存结果
                self.save_ai_detection_result(image_path, result)
                
                # 将AI检测结果直接显示在画布上（不生成新图片）
                if self.current_view == 'canvas' and hasattr(self, 'image_viewer'):
                    # 直接将AI检测结果添加到画布的标注列表中
                    self.add_ai_detection_to_canvas(result)
                    
                    # 更新状态栏
                    shape_count = len(result.get("data", {}).get("shapes", []))
                    self.statusBar().showMessage(f"AI检测完成，检测到 {shape_count} 个目标", 5000)
                else:
                    shape_count = len(result.get("data", {}).get("shapes", []))
                    self.statusBar().showMessage(f"AI检测完成，检测到 {shape_count} 个目标", 3000)
            else:
                error_msg = result.get("message", "未知错误")
                QMessageBox.critical(self, "检测失败", f"AI检测失败: {error_msg}")
                self.statusBar().showMessage(f"AI检测失败: {error_msg}", 3000)
                
        except Exception as e:
            QMessageBox.critical(self, "错误", f"执行AI检测时发生错误: {str(e)}")
            self.statusBar().showMessage(f"AI检测错误: {str(e)}", 3000)

    def save_ai_detection_result(self, image_path, result):
        """保存AI检测结果为JSON文件"""
        from pathlib import Path
        import json
        
        # 构建JSON文件名：例如 test.jpg -> test.json（与图片同名）
        img_path = Path(image_path)
        json_path = img_path.parent / f"{img_path.stem}.json"

        # 转换推理结果为Label Studio兼容格式
        converted_result = self.convert_to_label_studio_format_for_ai(result, image_path)

        # 保存JSON文件
        try:
            with open(json_path, "w", encoding="utf-8") as f:
                json.dump(converted_result, f, ensure_ascii=False, indent=4)
            print(f"✅ AI检测结果已保存: {json_path}")
            return True
        except Exception as e:
            print(f"❌ 保存AI检测结果JSON失败: {e}")
            return False

    def start_batch_ai_detection(self):
        """批量AI检测 - 在当前文件夹的所有图片上运行检测"""
        if not hasattr(self, 'image_files') or not self.image_files:
            QMessageBox.warning(self, "警告", "请先打开一个包含图片的文件夹！")
            return
            
        # 获取配置参数
        service_url = self.ai_service_url_combo.currentData()
        if not service_url:
            service_url = self.ai_service_url_combo.currentText().strip()
        conf_threshold = float(self.conf_threshold_edit.text().strip()) if self.conf_threshold_edit.text().strip() else 0.3
        nms_threshold = float(self.nms_threshold_edit.text().strip()) if self.nms_threshold_edit.text().strip() else 0.5
        model_path = self.model_path_edit.text().strip()
        classes_str = self.classes_edit.text().strip()
        instance_name = self.instance_name_edit.text().strip()
        
        # 验证参数
        if not service_url:
            QMessageBox.warning(self, "警告", "请先配置AI服务地址！")
            return
            
        # 转换类别字符串为列表
        try:
            classes = [int(c.strip()) for c in classes_str.split(',') if c.strip()] if classes_str else []
        except ValueError:
            QMessageBox.warning(self, "警告", "类别格式错误，请使用逗号分隔的数字！")
            return
            
        # 创建进度对话框
        from PySide6.QtWidgets import QProgressDialog
        from PySide6.QtCore import Qt
        progress_dialog = QProgressDialog("批量AI检测中...", "取消", 0, len(self.image_files), self)
        progress_dialog.setWindowTitle("批量AI检测")
        progress_dialog.setWindowModality(Qt.WindowModal)  # 窗口模态
        progress_dialog.show()
        
        # 批量检测
        success_count = 0
        total_count = len(self.image_files)
        
        for i, image_path in enumerate(self.image_files):
            # 检查用户是否取消了操作
            if progress_dialog.wasCanceled():
                break
                
            # 更新进度
            progress_dialog.setValue(i)
            progress_dialog.setLabelText(f"正在检测第 {i+1}/{total_count} 张图片: {os.path.basename(image_path)}")
            
            # 检测单张图片
            try:
                result = self._detect_single_image(image_path, service_url, conf_threshold, nms_threshold, model_path, classes, instance_name)
                if result and result.get("success"):
                    # 保存检测结果
                    if self.save_ai_detection_result(image_path, result):
                        success_count += 1
                        print(f"✅ 批量检测完成: {os.path.basename(image_path)}")
                    else:
                        print(f"❌ 批量检测保存失败: {os.path.basename(image_path)}")
                else:
                    print(f"❌ 批量检测失败: {os.path.basename(image_path)}")
                    
            except Exception as e:
                print(f"❌ 批量检测异常: {os.path.basename(image_path)} - {str(e)}")
            
            # 处理事件，确保UI响应
            from PySide6.QtCore import QCoreApplication
            QCoreApplication.processEvents()
        
        # 完成进度
        progress_dialog.setValue(total_count)
        progress_dialog.close()
        
        # 显示结果
        QMessageBox.information(self, "批量检测完成", 
                               f"批量AI检测完成！\n成功检测: {success_count}/{total_count} 张图片")
        self.statusBar().showMessage(f"批量检测完成: {success_count}/{total_count} 张图片", 5000)

    def _detect_single_image(self, image_path, service_url, conf_threshold, nms_threshold, model_path, classes, instance_name):
        """单张图片检测的通用函数"""
        import requests
        import base64
        
        # 读取图片并编码为base64
        try:
            with open(image_path, "rb") as image_file:
                image_data = base64.b64encode(image_file.read()).decode('utf-8')
        except Exception as e:
            print(f"❌ 读取图片失败: {image_path} - {str(e)}")
            return None
        
        # 构建请求数据
        request_data = {
            "image": image_data,
            "conf_threshold": conf_threshold,
            "nms_threshold": nms_threshold,
            "model_abs_path": model_path,
            "classes": classes,
            "instance_name": instance_name
        }
        
        # 发送检测请求
        try:
            response = requests.post(service_url, json=request_data, timeout=30)
            if response.status_code == 200:
                return response.json()
            else:
                print(f"❌ 检测请求失败: {response.status_code} - {response.text}")
                return None
        except Exception as e:
            print(f"❌ 检测请求异常: {str(e)}")
            return None

    def refresh_ai_endpoints(self):
        """刷新AI服务端点列表"""
        import requests
        import json
        
        # 获取基础URL（优先使用存储的数据，如果没有则使用当前文本）
        current_url = self.ai_service_url_combo.currentData()
        if not current_url:
            current_url = self.ai_service_url_combo.currentText().strip()
        
        if current_url:
            # 提取基础URL
            if '/v1/predict/' in current_url:
                base_url = current_url.split('/v1/predict/')[0]
            else:
                base_url = current_url
        else:
            base_url = "http://127.0.0.1:8000"
        
        try:
            self.statusBar().showMessage("正在获取AI服务端点列表...")
            
            # 1. 首先检查服务健康状态
            health_response = requests.get(f"{base_url}/health", timeout=5)
            if health_response.status_code != 200:
                print(f"服务不可用，状态码: {health_response.status_code}")
                QMessageBox.warning(self, "警告", f"服务不可用，状态码: {health_response.status_code}")
                self.statusBar().showMessage("获取AI服务端点失败", 3000)
                return
            
            health_data = health_response.json()
            if health_data.get("status") != "healthy":
                print(f"服务不健康: {health_data}")
                QMessageBox.warning(self, "警告", f"服务不健康: {health_data}")
                self.statusBar().showMessage("AI服务状态异常", 3000)
                return
            
            print("✅ 服务健康检查通过")
            
            # 2. 获取模型参数信息
            models_response = requests.get(f"{base_url}/v1/model-params-info", timeout=5)
            if models_response.status_code != 200:
                print(f"获取模型参数信息失败，状态码: {models_response.status_code}")
                QMessageBox.warning(self, "警告", f"获取模型参数信息失败，状态码: {models_response.status_code}")
                self.statusBar().showMessage("获取模型参数信息失败", 3000)
                return
            
            models_data = models_response.json()
            if not models_data.get("success"):
                print(f"获取模型参数信息失败: {models_data}")
                QMessageBox.warning(self, "警告", f"获取模型参数信息失败: {models_data}")
                self.statusBar().showMessage("获取模型参数信息失败", 3000)
                return
            
            models_params = models_data.get("data", {})
            print(f"✅ 获取到 {len(models_params)} 个模型的参数信息")
            
            # 3. 清空并重新填充下拉菜单
            self.ai_service_url_combo.clear()
            
            # 添加获取到的端点
            for inference_id, model_info in models_params.items():
                endpoint_url = f"{base_url}/v1/predict/{inference_id}"
                # 只显示URL部分，不显示模型名称和类型信息
                display_text = endpoint_url
                self.ai_service_url_combo.addItem(display_text, endpoint_url)
            
            # 如果没有找到任何端点，添加默认选项
            if self.ai_service_url_combo.count() == 0:
                self.ai_service_url_combo.addItem("http://127.0.0.1:8000/v1/predict/my_yolox", "http://127.0.0.1:8000/v1/predict/my_yolox")
            
            self.statusBar().showMessage(f"成功获取到 {len(models_params)} 个AI服务端点", 3000)
            
        except requests.exceptions.ConnectionError:
            error_msg = f"无法连接到服务器: {base_url}\n请确保X-AnyLabeling服务正在运行"
            print(f"❌ {error_msg}")
            QMessageBox.critical(self, "连接错误", error_msg)
            self.statusBar().showMessage("AI服务连接错误", 3000)
        except requests.exceptions.Timeout:
            error_msg = "请求超时，服务器响应过慢"
            print(f"❌ {error_msg}")
            QMessageBox.critical(self, "连接超时", error_msg)
            self.statusBar().showMessage("AI服务连接超时", 3000)
        except Exception as e:
            error_msg = f"获取API端点时出错: {str(e)}"
            print(f"❌ {error_msg}")
            QMessageBox.critical(self, "错误", error_msg)
            self.statusBar().showMessage(f"获取AI服务端点错误: {str(e)}", 3000)

    def add_ai_detection_to_canvas(self, result):
        """将AI检测结果添加到画布的标注列表中"""
        if not hasattr(self, 'image_viewer') or not self.image_viewer:
            return
            
        if not result.get("success") or "data" not in result:
            return
            
        shapes_data = result["data"].get("shapes", [])
        if not shapes_data:
            return
            
        # 清空现有的标注
        self.image_viewer.shapes = []
        
        # 添加AI检测结果到画布
        for shape_data in shapes_data:
            try:
                from .shapes import Shape
                from PySide6.QtCore import QPointF
                from PySide6.QtGui import QColor
                from .color_utils import ColorUtils
                
                new_shape = Shape()
                label = shape_data.get("label", "detected")
                new_shape.label = label

                points_data = shape_data.get("points", [])
                
                # 检查是否是两点矩形（AI检测返回的标准格式）
                if len(points_data) == 2 and shape_data.get("shape_type", "rectangle") == "rectangle":
                    # 将两点矩形转换为四点矩形格式，以确保正确绘制
                    x1, y1 = points_data[0]
                    x2, y2 = points_data[1]
                    # 创建矩形的四个顶点（顺时针方向）
                    rectangle_points = [[x1, y1], [x2, y1], [x2, y2], [x1, y2]]
                    
                    for point_data in rectangle_points:
                        if isinstance(point_data, list) and len(point_data) >= 2:
                            x, y = point_data[0], point_data[1]
                            new_shape.add_point(QPointF(x, y))
                elif len(points_data) == 4 and shape_data.get("shape_type", "rectangle") == "rectangle":
                    # 如果已经是四点矩形格式，直接使用
                    for point_data in points_data:
                        if isinstance(point_data, list) and len(point_data) >= 2:
                            x, y = point_data[0], point_data[1]
                            new_shape.add_point(QPointF(x, y))
                else:
                    # 处理其他类型的形状（多边形、旋转框等）
                    for point_data in points_data:
                        if isinstance(point_data, list) and len(point_data) >= 2:
                            x, y = point_data[0], point_data[1]
                            new_shape.add_point(QPointF(x, y))

                shape_type = shape_data.get("shape_type", "rectangle")
                new_shape.shape_type = shape_type

                new_shape.line_color = ColorUtils.get_color_for_label(new_shape.label)
                new_shape.fill_color = QColor(
                    new_shape.line_color.red(),
                    new_shape.line_color.green(),
                    new_shape.line_color.blue(),
                    30
                )

                # 标记为AI检测结果
                new_shape._is_ai_detected = True
                
                # 添加到画布形状列表
                self.image_viewer.shapes.append(new_shape)
                
            except Exception as e:
                print(f"创建形状对象时出错: {e}")
                continue
        
        # 更新形状的缩放
        for shape in self.image_viewer.shapes:
            shape.scale = self.image_viewer.scale_factor
        
        # 强制更新画布显示
        self.image_viewer.update_display()
        self.image_viewer.repaint()
        
        # 更新标注列表显示
        self.update_shapes_list()

    def convert_to_label_studio_format_for_ai(self, result, image_path):
        """将AI检测结果转换为Label Studio兼容的格式"""
        import cv2
        from pathlib import Path
        
        # 获取图片尺寸
        img = cv2.imread(image_path)
        height, width = img.shape[:2] if img is not None else (0, 0)

        # 提取图片文件名
        img_filename = Path(image_path).name

        # 初始化基础结构
        label_studio_data = {
            "version": "4.5.6",
            "flags": {},
            "shapes": [],
            "imagePath": img_filename,
            "imageData": None,
            "imageHeight": height,
            "imageWidth": width
        }

        # 如果推理成功且有数据，则转换形状数据
        if result.get("success") and "data" in result:
            shapes_data = result["data"].get("shapes", [])
            converted_shapes = []

            for shape in shapes_data:
                # 获取坐标点
                points = shape.get("points", [])

                # 确定shape类型（根据点的数量判断）
                if len(points) == 2:
                    # 边界框格式 [[x1, y1], [x2, y2]]
                    x1, y1 = points[0]
                    x2, y2 = points[1]
                    # 形成矩形的四个点
                    rectangle_points = [
                        [x1, y1],
                        [x2, y1],
                        [x2, y2],
                        [x1, y2]
                    ]
                    shape_type = "rectangle"
                    closed = True
                elif len(points) >= 3:
                    # 多边形格式
                    rectangle_points = points
                    shape_type = "polygon"
                    closed = True
                else:
                    # 默认处理方式
                    rectangle_points = points
                    shape_type = "rectangle"
                    closed = True

                # 构造新的shape对象
                converted_shape = {
                    "label": shape.get("label", ""),
                    "shape_type": shape_type,
                    "flags": {},
                    "group_id": None,
                    "points": rectangle_points,
                    "closed": closed,
                    "line_color": "#ff0000",  # 红色边框
                    "kie_linking": [],
                    "score": shape.get("score", None),
                    "description": "",
                    "difficult": False,
                    "attributes": {}
                }

                # 如果是旋转框，需要添加特殊字段
                if shape.get("shape_type", "") == "rotation":
                    converted_shape["shape_type"] = "rotation"
                    converted_shape["closed"] = False  # 旋转框通常是开放的
                    converted_shape["direction"] = shape.get("direction", 0)

                converted_shapes.append(converted_shape)

            label_studio_data["shapes"] = converted_shapes

        return label_studio_data

    def convert_all_json_to_voc(self):
        """将当前文件夹中所有JSON标注批量转换为VOC格式"""
        if not self.current_folder or not os.path.exists(self.current_folder):
            QMessageBox.warning(self, "警告", "请先打开一个图片文件夹！")
            return

        output_dir = QFileDialog.getExistingDirectory(
            self,
            "选择VOC文件输出目录",
            self.current_folder
        )

        if not output_dir:
            return

        json_files = []
        all_labels = set()
        for file in os.listdir(self.current_folder):
            if file.endswith('.json'):
                json_file_path = os.path.join(self.current_folder, file)
                base_name = os.path.splitext(file)[0]
                image_found = False
                for img_ext in ['.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.gif']:
                    img_file = os.path.join(self.current_folder, base_name + img_ext)
                    if os.path.exists(img_file):
                        json_files.append((json_file_path, img_file))
                        image_found = True
                        break
                if not image_found:
                    print(f"警告: 未找到 {base_name} 对应的图片文件")

        if not json_files:
            QMessageBox.information(self, "提示", "当前文件夹中没有找到有效的JSON标注文件及其对应的图片文件！")
            return

        classes_file = os.path.join(self.current_folder, "label.txt")
        if not os.path.exists(classes_file):
            try:
                all_labels = set()
                for json_file, _ in json_files:
                    try:
                        label_file = LabelFile()
                        label_file.load(json_file)
                        for shape in label_file.shapes:
                            if shape.label.strip():
                                all_labels.add(shape.label.strip())
                    except:
                        continue

                if all_labels:
                    with open(classes_file, 'w', encoding='utf-8') as f:
                        for label in sorted(all_labels):
                            f.write(f"{label}\n")
                    QMessageBox.information(self, "提示", f"已创建label.txt文件，包含 {len(all_labels)} 个类别。")
                else:
                    QMessageBox.warning(self, "警告", "当前JSON文件中没有标签，无法创建label.txt。")
                    return
            except Exception as e:
                QMessageBox.critical(self, "错误", f"创建label.txt失败: {str(e)}")
                return

        converter = LabelConverter(classes_file=classes_file)
        successful_conversions = 0
        failed_conversions = 0

        from PySide6.QtWidgets import QProgressDialog
        from PySide6.QtCore import Qt

        progress = QProgressDialog("正在转换JSON标注文件为VOC格式...", "取消", 0, len(json_files), self)
        progress.setWindowTitle("转换进度")
        progress.setWindowModality(Qt.WindowModal)
        progress.show()

        for i, (json_file, image_file) in enumerate(json_files):
            if progress.wasCanceled():
                break

            try:
                file_name = os.path.splitext(os.path.basename(json_file))[0]
                voc_xml_path = os.path.join(output_dir, f"{file_name}.xml")

                is_empty = converter.custom_to_voc(
                    image_file=image_file,
                    input_file=json_file,
                    output_dir=voc_xml_path,
                    mode="rectangle",
                    skip_empty_files=False
                )

                successful_conversions += 1
            except Exception as e:
                failed_conversions += 1
                print(f"转换失败 {json_file}: {str(e)}")

            progress.setValue(i + 1)
            QApplication.processEvents()

        progress.close()

        result_msg = f"批量转换完成！\n成功: {successful_conversions} 个文件"
        if failed_conversions > 0:
            result_msg += f"\n失败: {failed_conversions} 个文件"
        QMessageBox.information(self, "转换完成", result_msg)

    def convert_all_yolo_to_json(self):
        """将YOLO标注批量转换为JSON格式"""
        classes_file, _ = QFileDialog.getOpenFileName(
            self,
            "选择标签文件",
            self.current_folder if self.current_folder else "",
            "所有文件 (*);;标签文件 (label.txt);;文本文件 (*.txt)"
        )

        if not classes_file:
            return

        yolo_folder = QFileDialog.getExistingDirectory(
            self,
            "选择YOLO标签文件夹",
            self.current_folder if self.current_folder else ""
        )

        if not yolo_folder:
            return

        output_folder = self.current_folder
        if not output_folder or not os.path.exists(output_folder):
            QMessageBox.warning(self, "警告", "请先打开一个图片文件夹作为输出目录！")
            return

        yolo_files = []
        for file in os.listdir(yolo_folder):
            if file.lower().endswith('.txt'):
                yolo_file_path = os.path.join(yolo_folder, file)
                try:
                    with open(yolo_file_path, 'r', encoding="utf-8") as f:
                        content = f.read().strip()
                        if content:
                            lines = content.split('\n')
                            is_yolo = True
                            for line in lines:
                                line = line.strip()
                                if not line:
                                    continue
                                parts = line.split()
                                if len(parts) < 5:
                                    is_yolo = False
                                    break
                                try:
                                    float(parts[0])
                                    for coord in parts[1:]:
                                        float(coord)
                                except ValueError:
                                    is_yolo = False
                                    break
                            if is_yolo:
                                base_name = os.path.splitext(file)[0]
                                image_found = False
                                for img_ext in ['.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.gif']:
                                    img_file = os.path.join(output_folder, base_name + img_ext)
                                    if os.path.exists(img_file):
                                        yolo_files.append((yolo_file_path, img_file))
                                        image_found = True
                                        break
                                if not image_found:
                                    print(f"警告: 在当前文件夹中未找到 {base_name} 对应的图片文件")
                except Exception as e:
                    print(f"检查YOLO文件失败 {yolo_file_path}: {str(e)}")

        if not yolo_files:
            QMessageBox.information(self, "提示", "在指定的YOLO文件夹中没有找到有效的YOLO标注文件或对应的图片文件！")
            return

        from PySide6.QtWidgets import QProgressDialog
        from PySide6.QtCore import Qt

        progress = QProgressDialog("正在转换YOLO标注文件为JSON格式...", "取消", 0, len(yolo_files), self)
        progress.setWindowTitle("转换进度")
        progress.setWindowModality(Qt.WindowModal)
        progress.show()

        converter = LabelConverter(classes_file=classes_file)
        successful_conversions = 0
        failed_conversions = 0

        for i, (yolo_file, image_file) in enumerate(yolo_files):
            if progress.wasCanceled():
                break

            try:
                file_name = os.path.splitext(os.path.basename(yolo_file))[0]
                json_file_path = os.path.join(output_folder, f"{file_name}.json")

                try:
                    converter.yolo_to_custom(
                        input_file=yolo_file,
                        output_file=json_file_path,
                        image_file=image_file,
                        mode="hbb"
                    )
                except Exception as seg_error:
                    try:
                        converter.yolo_to_custom(
                            input_file=yolo_file,
                            output_file=json_file_path,
                            image_file=image_file,
                            mode="seg"
                        )
                    except Exception as final_error:
                        raise final_error

                successful_conversions += 1
            except Exception as e:
                failed_conversions += 1
                print(f"转换失败 {yolo_file}: {str(e)}")

            progress.setValue(i + 1)
            QApplication.processEvents()

        progress.close()

        result_msg = f"批量转换完成！\n成功: {successful_conversions} 个文件"
        if failed_conversions > 0:
            result_msg += f"\n失败: {failed_conversions} 个文件"
        QMessageBox.information(self, "转换完成", result_msg)

    def convert_all_voc_to_json(self):
        """将VOC标注批量转换为JSON格式"""
        voc_folder = QFileDialog.getExistingDirectory(
            self,
            "选择VOC标注文件夹",
            self.current_folder if self.current_folder else ""
        )

        if not voc_folder:
            return

        output_folder = self.current_folder
        if not output_folder or not os.path.exists(output_folder):
            QMessageBox.warning(self, "警告", "请先打开一个图片文件夹作为输出目录！")
            return

        voc_files = []
        for file in os.listdir(voc_folder):
            if file.lower().endswith('.xml'):
                voc_file_path = os.path.join(voc_folder, file)
                try:
                    import xml.etree.ElementTree as ET
                    tree = ET.parse(voc_file_path)
                    root = tree.getroot()
                    if root.find("object") is not None or root.find("size") is not None:
                        base_name = os.path.splitext(file)[0]
                        image_found = False
                        for img_ext in ['.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.gif']:
                            img_file = os.path.join(output_folder, base_name + img_ext)
                            if os.path.exists(img_file):
                                voc_files.append((voc_file_path, base_name + img_ext))
                                image_found = True
                                break
                        if not image_found:
                            print(f"警告: 在当前文件夹中未找到 {base_name} 对应的图片文件")
                except Exception as e:
                    print(f"检查VOC文件失败 {voc_file_path}: {str(e)}")

        if not voc_files:
            QMessageBox.information(self, "提示", "在指定的VOC文件夹中没有找到有效的VOC标注文件或对应的图片文件！")
            return

        from PySide6.QtWidgets import QProgressDialog
        from PySide6.QtCore import Qt

        progress = QProgressDialog("正在转换VOC标注文件为JSON格式...", "取消", 0, len(voc_files), self)
        progress.setWindowTitle("转换进度")
        progress.setWindowModality(Qt.WindowModal)
        progress.show()

        converter = LabelConverter()
        successful_conversions = 0
        failed_conversions = 0

        for i, (voc_file, image_filename) in enumerate(voc_files):
            if progress.wasCanceled():
                break

            try:
                file_name = os.path.splitext(os.path.basename(voc_file))[0]
                json_file_path = os.path.join(output_folder, f"{file_name}.json")

                converter.voc_to_custom(
                    input_file=voc_file,
                    output_file=json_file_path,
                    image_filename=image_filename,
                    mode="rectangle"
                )

                successful_conversions += 1
            except Exception as e:
                failed_conversions += 1
                print(f"转换失败 {voc_file}: {str(e)}")

            progress.setValue(i + 1)
            QApplication.processEvents()

        progress.close()

        result_msg = f"批量转换完成！\n成功: {successful_conversions} 个文件"
        if failed_conversions > 0:
            result_msg += f"\n失败: {failed_conversions} 个文件"
        QMessageBox.information(self, "转换完成", result_msg)

    def convert_all_json_to_coco(self):
        """将当前文件夹中所有JSON标注批量转换为COCO格式"""
        if not self.current_folder or not os.path.exists(self.current_folder):
            QMessageBox.warning(self, "警告", "请先打开一个图片文件夹！")
            return

        output_dir = QFileDialog.getExistingDirectory(
            self,
            "选择COCO文件输出目录",
            self.current_folder
        )

        if not output_dir:
            return

        json_files = []
        for file in os.listdir(self.current_folder):
            if file.endswith('.json'):
                json_file_path = os.path.join(self.current_folder, file)
                base_name = os.path.splitext(file)[0]
                image_found = False
                for img_ext in ['.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.gif']:
                    img_file = os.path.join(self.current_folder, base_name + img_ext)
                    if os.path.exists(img_file):
                        json_files.append(img_file)
                        image_found = True
                        break
                if not image_found:
                    print(f"警告: 未找到 {base_name} 对应的图片文件")

        if not json_files:
            QMessageBox.information(self, "提示", "当前文件夹中没有找到有效的JSON标注文件及其对应的图片文件！")
            return

        classes_file = os.path.join(self.current_folder, "label.txt")
        if not os.path.exists(classes_file):
            try:
                all_labels = set()
                for img_file in json_files:
                    base_name = os.path.splitext(os.path.basename(img_file))[0]
                    json_file = os.path.join(self.current_folder, base_name + ".json")
                    if os.path.exists(json_file):
                        try:
                            label_file = LabelFile()
                            label_file.load(json_file)
                            for shape in label_file.shapes:
                                if shape.label.strip():
                                    all_labels.add(shape.label.strip())
                        except:
                            continue

                if all_labels:
                    with open(classes_file, 'w', encoding='utf-8') as f:
                        for label in sorted(all_labels):
                            f.write(f"{label}\n")
                    QMessageBox.information(self, "提示", f"已创建label.txt文件，包含 {len(all_labels)} 个类别。")
                else:
                    QMessageBox.warning(self, "警告", "当前JSON文件中没有标签，无法创建label.txt。")
                    return
            except Exception as e:
                QMessageBox.critical(self, "错误", f"创建label.txt失败: {str(e)}")
                return

        converter = LabelConverter(classes_file=classes_file)
        successful_conversions = 0
        failed_conversions = 0

        from PySide6.QtWidgets import QProgressDialog
        from PySide6.QtCore import Qt

        progress = QProgressDialog("正在转换JSON标注文件为COCO格式...", "取消", 0, 1, self)
        progress.setWindowTitle("转换进度")
        progress.setWindowModality(Qt.WindowModal)
        progress.show()

        try:
            image_list = json_files
            output_coco_path = os.path.join(output_dir, "annotations.json")

            converter.custom_to_coco(
                image_list=image_list,
                input_path=self.current_folder,
                output_path=output_dir,
                mode="rectangle"
            )

            successful_conversions = len(image_list)
        except Exception as e:
            failed_conversions = len(image_list)
            print(f"转换失败: {str(e)}")
        finally:
            progress.close()

        result_msg = f"批量转换完成！\n成功: {successful_conversions} 个文件"
        if failed_conversions > 0:
            result_msg += f"\n失败: {failed_conversions} 个文件"
        QMessageBox.information(self, "转换完成", result_msg)

    def convert_all_coco_to_json(self):
        """将COCO标注批量转换为JSON格式"""
        coco_file, _ = QFileDialog.getOpenFileName(
            self,
            "选择COCO标注文件",
            self.current_folder if self.current_folder else "",
            "COCO文件 (*.json);;所有文件 (*)"
        )

        if not coco_file:
            return

        output_folder = self.current_folder
        if not output_folder or not os.path.exists(output_folder):
            QMessageBox.warning(self, "警告", "请先打开一个图片文件夹作为输出目录！")
            return

        from PySide6.QtWidgets import QProgressDialog
        from PySide6.QtCore import Qt

        progress = QProgressDialog("正在转换COCO标注文件为JSON格式...", "取消", 0, 1, self)
        progress.setWindowTitle("转换进度")
        progress.setWindowModality(Qt.WindowModal)
        progress.show()

        converter = LabelConverter()
        successful_conversions = 0
        failed_conversions = 0

        try:
            output_dir_path = output_folder

            converter.coco_to_custom(
                input_file=coco_file,
                output_dir_path=output_dir_path,
                mode="rectangle"
            )

            successful_conversions = 1
        except Exception as e:
            failed_conversions = 1
            print(f"转换失败 {coco_file}: {str(e)}")
        finally:
            progress.close()

        result_msg = f"批量转换完成！\n成功: {successful_conversions} 个文件"
        if failed_conversions > 0:
            result_msg += f"\n失败: {failed_conversions} 个文件"
        QMessageBox.information(self, "转换完成", result_msg)

    def on_canvas_modified(self):
        """处理画布修改事件，立即保存标注"""
        if self.current_file_path and os.path.exists(self.current_file_path):
            self.save_annotation_silent()

    def browse_dataset_config(self):
        """浏览数据集配置文件"""
        file_path, _ = QFileDialog.getOpenFileName(self, "选择数据集配置文件", "", "配置文件 (*.yaml *.yml)")
        if file_path:
            self.dataset_path_edit.setText(file_path)

    def browse_pretrained_model(self):
        """浏览预训练模型文件"""
        file_path, _ = QFileDialog.getOpenFileName(self, "选择预训练模型文件", "", "模型文件 (*.pt)")
        if file_path:
            self.pretrained_model_edit.setText(file_path)

    def browse_checkpoint_model(self):
        """浏览检查点模型文件"""
        file_path, _ = QFileDialog.getOpenFileName(self, "选择检查点模型文件", "", "模型文件 (*.pt)")
        if file_path:
            self.checkpoint_model_edit.setText(file_path)

    def on_pretrained_model_changed(self):
        """处理预训练模型选择变化"""
        has_pretrained = bool(self.pretrained_model_edit.text().strip())
        if has_pretrained:
            self.checkpoint_model_edit.setEnabled(False)
            self.browse_checkpoint_btn.setEnabled(False)
        else:
            self.checkpoint_model_edit.setEnabled(True)
            self.browse_checkpoint_btn.setEnabled(True)

    def on_checkpoint_model_changed(self):
        """处理检查点模型选择变化"""
        has_checkpoint = bool(self.checkpoint_model_edit.text().strip())
        if has_checkpoint:
            self.pretrained_model_edit.setEnabled(False)
            self.browse_model_btn.setEnabled(False)
        else:
            self.pretrained_model_edit.setEnabled(True)
            self.browse_model_btn.setEnabled(True)

    def toggle_view(self):
        """切换视图：在画布和TensorBoard浏览器之间"""
        if self.current_view == 'canvas':
            # 从画布切换到TensorBoard
            self.current_view = 'tensorboard'
            self.stacked_widget.setCurrentIndex(1)

            port = 6006  # 默认端口

            latest_logdir = self.get_latest_run_folder()
            # 确保启动TensorBoard时使用最新的日志目录
            self.start_tensorboard(logdir=latest_logdir, port=port)
            self.tensorboard_view.load_tensorboard(port=port)

            # 更新按钮文本为切换回画布
            if hasattr(self, 'view_switch_btn'):
                self.view_switch_btn.setText("切换到画布视图")
        else:
            # 从TensorBoard或其他视图切换回画布
            self.current_view = 'canvas'
            self.stacked_widget.setCurrentIndex(0)

            # 更新按钮文本为切换到TensorBoard
            if hasattr(self, 'view_switch_btn'):
                self.view_switch_btn.setText("切换到TensorBoard视图")

        # 显示当前视图状态
        if self.current_view == 'tensorboard':
            view_name = 'TensorBoard浏览器'
        else:
            view_name = '图像标注画布'

        self.statusBar().showMessage(f"当前视图: {view_name}")

    def view_training_images(self):
        """查看训练过程中产生的图片 - 直接打开训练目录"""
        try:
            # 获取最新的训练路径
            latest_logdir = self.get_latest_run_folder()
            
            # 检查路径是否存在
            if not os.path.exists(latest_logdir):
                QMessageBox.warning(self, "警告", f"训练目录不存在: {latest_logdir}")
                return
            
            # 直接打开训练目录
            if os.name == 'nt':  # Windows
                os.startfile(latest_logdir)
            elif os.name == 'posix':  # Linux, macOS
                subprocess.run(['xdg-open', latest_logdir])
            
            self.statusBar().showMessage(f"已打开训练目录: {latest_logdir}", 3000)
                
        except Exception as e:
            QMessageBox.critical(self, "错误", f"打开训练目录时出错: {str(e)}")

    def on_view_changed(self, index):
        """处理视图更改事件"""
        # 当切换到浏览器视图时(索引为1)，确保浏览器组件被激活
        if index == 1:  # TensorBoard视图
            port = 6006  # 默认端口

            latest_logdir = self.get_latest_run_folder()
            # 确保启动TensorBoard时使用最新的日志目录
            self.start_tensorboard(logdir=latest_logdir, port=port)
            self.tensorboard_view.load_tensorboard(port=port)
        elif index == 0:  # Canvas视图
            pass
        elif index == 2:  # Netron视图
            port = 8080  # 默认端口
            self.netron_view.load_netron(port=port)

    def toggle_netron_view(self):
        """切换到Netron视图或从Netron视图切换回画布"""
        if self.current_view == 'netron':
            # 如果当前在Netron视图，则切换回画布
            self.current_view = 'canvas'
            self.stacked_widget.setCurrentIndex(0)
            if hasattr(self, 'netron_view_btn'):
                self.netron_view_btn.setText("切换到Netron视图")
            self.statusBar().showMessage("当前视图: 图像标注画布")
        else:
            # 如果不在Netron视图，则切换到Netron视图
            # 首先通过信息面板启动netron服务
            if hasattr(self, 'info_panel') and self.info_panel:
                # 检查是否已经有Netron进程在运行
                netron_processes = self.info_panel.get_running_processes_by_name("Netron Server")
                if netron_processes:
                    # 如果已经有Netron进程在运行，直接使用现有的
                    print("Netron服务已在运行中，直接使用现有服务")
                else:
                    # 直接启动netron命令，避免通过脚本启动产生两个进程
                    netron_cmd = ["netron", "--port", "8080", "--host", "localhost"]
                    success = self.info_panel.start_external_process(
                        netron_cmd,
                        process_name="Netron Server",
                        show_in_terminal=True
                    )
                    if not success:
                        # 检查是否是因为netron未安装
                        try:
                            # 尝试直接运行netron命令检查是否安装
                            result = subprocess.run(["netron", "--help"], 
                                                  capture_output=True, 
                                                  text=True, 
                                                  timeout=5)
                            if result.returncode != 0:
                                QMessageBox.warning(self, "警告", "未安装netron，请运行 'pip install netron' 安装")
                                return
                        except FileNotFoundError:
                            QMessageBox.warning(self, "警告", "未安装netron，请运行 'pip install netron' 安装")
                            return

            self.current_view = 'netron'
            self.stacked_widget.setCurrentIndex(2)
            if hasattr(self, 'netron_view_btn'):
                self.netron_view_btn.setText("切换到画布视图")
            self.statusBar().showMessage("当前视图: Netron浏览器")

    def start_model_training(self):
        """开始模型训练"""
        try:
            dataset_path = self.dataset_path_edit.text().strip()
            pretrained_model = self.pretrained_model_edit.text().strip()
            checkpoint_model = self.checkpoint_model_edit.text().strip()

            if not dataset_path or not os.path.exists(dataset_path):
                QMessageBox.warning(self, "警告", f"数据集配置文件不存在: {dataset_path}")
                return

            # 检查模型选择，预训练模型和检查点模型不能同时为空，也不能同时选择
            if not pretrained_model and not checkpoint_model:
                QMessageBox.warning(self, "警告", "请选择预训练模型文件或检查点模型文件")
                return

            if pretrained_model and checkpoint_model:
                QMessageBox.warning(self, "警告", "预训练模型和检查点模型只能选择一个")
                return

            imgsz_str = self.img_size_edit.text().strip()
            try:
                imgsz = tuple(map(int, imgsz_str.split(',')))
                if len(imgsz) == 1:
                    imgsz = (imgsz[0], imgsz[0])
            except ValueError:
                QMessageBox.critical(self, "错误", "图像尺寸格式不正确，请使用逗号分隔的两个整数，如: 640,640")
                return

            try:
                batch_size = int(self.batch_size_edit.text().strip())
                epochs = int(self.epochs_edit.text().strip())
                workers = int(self.workers_edit.text().strip())
            except ValueError:
                QMessageBox.critical(self, "错误", "训练参数必须是整数")
                return

            self.training_progress.setVisible(True)
            self.training_progress.setRange(0, 0)
            self.statusBar().showMessage(f"正在开始模型训练...")
            self.start_training_btn.setEnabled(False)
            # 停止训练功能已由进程列表中的统一停止方法替代

            # 确定使用的模型，优先使用检查点模型（继续训练）
            model_to_use = checkpoint_model if checkpoint_model else pretrained_model
            is_resuming = bool(checkpoint_model)  # 是否为继续训练

            config = {
                'dataset_path': dataset_path,
                'pretrained_model': model_to_use,
                'img_size': imgsz,
                'batch_size': batch_size,
                'epochs': epochs,
                'workers': workers,
                'resume_from_checkpoint': is_resuming,  # 添加是否从检查点继续训练的标志
                'checkpoint_model': checkpoint_model if is_resuming else ''
            }

            # 记录本次训练的配置，用于后续定位训练日志
            self.last_training_config = config

            # 通过信息面板启动训练进程
            if hasattr(self, 'info_panel') and self.info_panel:
                # 构造训练命令 - 直接使用ultralytics CLI
                train_script = "from ultralytics import YOLO; "
                train_script += f"model = YOLO('{model_to_use}'); "
                train_script += f"train_args = {{'data': '{dataset_path}', 'imgsz': {imgsz[0] if isinstance(imgsz, (tuple, list)) else imgsz}, 'batch': {batch_size}, 'epochs': {epochs}, 'workers': {workers}, 'save_period': 10, 'verbose': True, 'amp': False}}; "
                
                if is_resuming and checkpoint_model:
                    train_script += f"train_args['resume'] = '{checkpoint_model}'; "
                
                train_script += "results = model.train(**train_args); "
                train_script += "print('训练完成!')"
                
                cmd_parts = [sys.executable, '-c', train_script]
                
                # 记录配置用于后续定位训练日志
                self.last_training_config = config
                
                # 通过信息面板启动训练
                success = self.info_panel.start_external_process(
                    cmd_parts, 
                    "模型训练", 
                    show_in_terminal=True
                )
                
                if success:
                    self.statusBar().showMessage("训练进程已启动，请在底部信息面板查看输出")
                    # 启动进度监控定时器
                    self.training_timer = QTimer(self)
                    self.training_timer.timeout.connect(self.check_training_progress)
                    self.training_timer.start(2000)  # 每2秒检查一次
                else:
                    self.statusBar().showMessage("训练进程启动失败")
                    self.train_btn.setEnabled(True)
            else:
                QMessageBox.critical(self, "错误", "信息面板未初始化，无法启动训练进程")

        except Exception as e:
            self.training_progress.setVisible(False)
            self.start_training_btn.setEnabled(True)
            # 停止训练功能已由进程列表中的统一停止方法替代
            # 重新启用模型选择控件
            if self.checkpoint_model_edit.text().strip():
                self.pretrained_model_edit.setEnabled(False)
                self.browse_model_btn.setEnabled(False)
            elif self.pretrained_model_edit.text().strip():
                self.checkpoint_model_edit.setEnabled(False)
                self.browse_checkpoint_btn.setEnabled(False)
            else:
                self.pretrained_model_edit.setEnabled(True)
                self.browse_model_btn.setEnabled(True)
                self.checkpoint_model_edit.setEnabled(True)
                self.browse_checkpoint_btn.setEnabled(True)
            self.statusBar().showMessage(f"启动训练失败: {str(e)}", 5000)
            QMessageBox.critical(self, "错误", f"启动模型训练时出现错误:\n{str(e)}")

    # 模型训练停止功能已由进程列表中的统一停止方法替代

    def check_training_progress(self):
        """检查训练进度（定时器回调） - 优化版本"""
        try:
            # 通过信息面板检查训练进程状态
            if hasattr(self, 'info_panel') and self.info_panel:
                # 检查是否有运行中的训练进程
                training_processes = self.info_panel.get_running_processes_by_name("模型训练")
                if not training_processes:
                    # 检查是否是正常完成还是被停止
                    if hasattr(self, '_training_manually_stopped') and self._training_manually_stopped:
                        # 用户手动停止的训练
                        self.on_training_finished(False, "训练已被用户停止", self.get_latest_run_folder())
                        delattr(self, '_training_manually_stopped')
                    else:
                        # 训练正常完成
                        self.on_training_finished(True, "训练已完成", self.get_latest_run_folder())
                    return
                
                # 从信息面板获取最新输出作为进度信息
                recent_output = self.info_panel.get_recent_output(10)  # 获取最近10行输出
                if recent_output:
                    last_line = recent_output[-1]
                    if "Epoch" in last_line or "训练" in last_line:
                        # 训练信息只在信息面板显示，不在状态栏重复显示
                        self.training_progress.setFormat(last_line.strip())
            else:
                # 信息面板不可用，停止监控
                if hasattr(self, 'training_timer'):
                    self.training_timer.stop()
                    del self.training_timer
        except Exception as e:
            print(f"检查训练进度时出错: {e}")

    def _on_training_stopped(self):
        """训练停止后的统一处理"""
        # 标记为手动停止
        self._training_manually_stopped = True
        
        # 停止监控定时器
        if hasattr(self, 'training_timer'):
            self.training_timer.stop()
            del self.training_timer
        
        # 重新启用训练按钮和控件
        self.start_training_btn.setEnabled(True)
        # 停止训练功能已由进程列表中的统一停止方法替代

        # 重新启用模型选择控件
        if self.checkpoint_model_edit.text().strip():
            self.pretrained_model_edit.setEnabled(False)
            self.browse_model_btn.setEnabled(False)
        elif self.pretrained_model_edit.text().strip():
            self.checkpoint_model_edit.setEnabled(False)
            self.browse_checkpoint_btn.setEnabled(False)
        else:
            self.pretrained_model_edit.setEnabled(True)
            self.browse_model_btn.setEnabled(True)
            self.checkpoint_model_edit.setEnabled(True)
            self.browse_checkpoint_btn.setEnabled(True)

        self.training_progress.setVisible(False)

    def on_training_finished(self, success, message, save_dir=None):
        """训练完成后的处理"""
        # 停止监控定时器
        if hasattr(self, 'training_timer'):
            self.training_timer.stop()
            del self.training_timer
        
        # 训练进程由信息面板统一管理，无需单独清理资源
        
        # 重新启用训练按钮和控件
        self.start_training_btn.setEnabled(True)
        # 停止训练功能已由进程列表中的统一停止方法替代

        # 重新启用模型选择控件
        if self.checkpoint_model_edit.text().strip():
            self.pretrained_model_edit.setEnabled(False)
            self.browse_model_btn.setEnabled(False)
        elif self.pretrained_model_edit.text().strip():
            self.checkpoint_model_edit.setEnabled(False)
            self.browse_checkpoint_btn.setEnabled(False)
        else:
            self.pretrained_model_edit.setEnabled(True)
            self.browse_model_btn.setEnabled(True)
            self.checkpoint_model_edit.setEnabled(True)
            self.browse_checkpoint_btn.setEnabled(True)

        self.training_progress.setVisible(False)

        if success:
            # 更新训练日志目录
            if save_dir and os.path.exists(save_dir):
                self.last_training_logdir = save_dir

                # 如果当前正在显示TensorBoard视图，自动重启TensorBoard
                if self.current_view == 'tensorboard':
                    self.start_tensorboard(logdir=save_dir, port=6006)
                    self.tensorboard_view.load_tensorboard(port=6006)

            self.statusBar().showMessage(message, 5000)
            QMessageBox.information(self, "训练完成", message)
        else:
            self.statusBar().showMessage(f"训练出错: {message}", 5000)
            QMessageBox.critical(self, "训练错误", f"训练过程中出现错误:\n{message}")

    # ... existing code ...

    def browse_export_model(self):
        """浏览导出模型文件"""
        file_path, _ = QFileDialog.getOpenFileName(self, "选择要导出的模型文件", "", "模型文件 (*.pt)")
        if file_path:
            self.model_export_path_edit.setText(file_path)

    def browse_ai_model_path(self):
        """浏览AI检测模型文件路径"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, 
            "选择AI检测模型文件", 
            "", 
            "模型文件 (*.onnx *.pt *.pth *.weights *.engine *.tflite *.pb)"
        )
        if file_path:
            self.model_path_edit.setText(file_path)

    def export_model(self):
        """导出模型 - 使用后台线程避免界面卡顿"""
        model_path = self.model_export_path_edit.text().strip()
        export_format = self.export_format_edit.text().strip()

        if not model_path:
            QMessageBox.warning(self, "警告", "请选择要导出的模型文件!")
            return

        if not export_format:
            QMessageBox.warning(self, "警告", "请输入导出格式!")
            return

        # 验证模型文件是否存在
        if not os.path.exists(model_path):
            QMessageBox.critical(self, "错误", f"模型文件不存在: {model_path}")
            return

        # 创建并启动导出线程
        self.export_thread = ModelExportThread(model_path, export_format)
        self.export_thread.export_started.connect(self.on_export_started)
        self.export_thread.export_finished.connect(self.on_export_finished)
        self.export_thread.export_error.connect(self.on_export_error)
        self.export_thread.start()

    def on_export_started(self):
        """导出开始时的处理"""
        self.export_model_btn.setEnabled(False)
        self.statusBar().showMessage("正在导出模型...")

    def on_export_finished(self, output_path):
        """导出完成时的处理"""
        self.export_model_btn.setEnabled(True)
        self.statusBar().showMessage(f"模型已成功导出到: {output_path}")
        QMessageBox.information(self, "导出完成", f"模型已成功导出到: {output_path}")

    def on_export_error(self, error_msg):
        """导出出错时的处理"""
        self.export_model_btn.setEnabled(True)
        self.statusBar().showMessage(f"模型导出失败: {error_msg}")
        QMessageBox.critical(self, "导出失败", f"模型导出失败: {error_msg}")

    def launch_quantization_tool(self):
        """启动模型量化工具（直接导入方式）"""
        try:
            # 直接导入量化模块
            from .quantization_process import YOLOv8Quantizer

            # 检查是否已有量化窗口打开
            if hasattr(self,
                       'quantization_window') and self.quantization_window and self.quantization_window.isVisible():
                # 如果窗口已存在且可见，将其前置显示
                self.quantization_window.raise_()
                self.quantization_window.activateWindow()
                self.statusBar().showMessage("模型量化工具已在前台显示", 3000)
                return

            # 创建新的量化工具窗口，设置父窗口为主窗口
            self.quantization_window = YOLOv8Quantizer(self)

            # 设置窗口属性
            self.quantization_window.setAttribute(Qt.WA_DeleteOnClose, True)

            # 连接窗口关闭信号
            self.quantization_window.destroyed.connect(self.on_quantization_window_closed)

            # 显示窗口
            self.quantization_window.show()

            self.statusBar().showMessage("模型量化工具已启动", 3000)

        except ImportError as e:
            QMessageBox.critical(self, "导入错误",
                                 f"无法导入量化模块: {str(e)}\n请确保 quantization_process.py 文件存在且可导入")
        except Exception as e:
            QMessageBox.critical(self, "错误", f"启动模型量化工具失败: {str(e)}")

    def on_quantization_window_closed(self):
        """量化窗口关闭后的清理工作"""
        if hasattr(self, 'quantization_window'):
            self.quantization_window = None
        self.statusBar().showMessage("模型量化工具已关闭", 3000)
    
    # 新增转换功能：JSON转DOTA格式
    def convert_all_json_to_dota(self):
        """将当前文件夹中所有JSON标注批量转换为DOTA格式"""
        if not self.current_folder or not os.path.exists(self.current_folder):
            QMessageBox.warning(self, "警告", "请先打开一个图片文件夹！")
            return

        output_dir = QFileDialog.getExistingDirectory(
            self,
            "选择DOTA文件输出目录",
            self.current_folder
        )

        if not output_dir:
            return

        json_files = []
        for file in os.listdir(self.current_folder):
            if file.lower().endswith('.json'):
                json_file_path = os.path.join(self.current_folder, file)
                json_files.append(json_file_path)

        if not json_files:
            QMessageBox.information(self, "提示", "当前文件夹中没有找到JSON标注文件！")
            return

        converter = LabelConverter()
        successful_conversions = 0
        failed_conversions = 0

        from PySide6.QtWidgets import QProgressDialog
        from PySide6.QtCore import Qt

        progress = QProgressDialog("正在转换JSON标注文件为DOTA格式...", "取消", 0, len(json_files), self)
        progress.setWindowTitle("转换进度")
        progress.setWindowModality(Qt.WindowModal)
        progress.show()

        for i, json_file in enumerate(json_files):
            if progress.wasCanceled():
                break

            try:
                file_name = os.path.splitext(os.path.basename(json_file))[0]
                dota_txt_path = os.path.join(output_dir, f"{file_name}.txt")

                converter.custom_to_dota(
                    input_file=json_file,
                    output_file=dota_txt_path
                )

                successful_conversions += 1
            except Exception as e:
                failed_conversions += 1
                print(f"转换失败 {json_file}: {str(e)}")

            progress.setValue(i + 1)
            QApplication.processEvents()

        progress.close()

        result_msg = f"批量转换完成！\n成功: {successful_conversions} 个文件"
        if failed_conversions > 0:
            result_msg += f"\n失败: {failed_conversions} 个文件"
        QMessageBox.information(self, "转换完成", result_msg)

    # 新增转换功能：DOTA转JSON格式
    def convert_all_dota_to_json(self):
        """将当前文件夹中所有DOTA标注批量转换为JSON格式"""
        if not self.current_folder or not os.path.exists(self.current_folder):
            QMessageBox.warning(self, "警告", "请先打开一个图片文件夹！")
            return

        dota_folder = QFileDialog.getExistingDirectory(
            self,
            "选择DOTA标注文件夹",
            self.current_folder
        )

        if not dota_folder:
            return

        output_folder = self.current_folder

        dota_files = []
        for file in os.listdir(dota_folder):
            if file.lower().endswith('.txt'):
                dota_file_path = os.path.join(dota_folder, file)
                base_name = os.path.splitext(file)[0]
                
                # 寻找对应的图片文件
                image_found = False
                for img_ext in ['.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.gif']:
                    img_file = os.path.join(self.current_folder, base_name + img_ext)
                    if os.path.exists(img_file):
                        dota_files.append((dota_file_path, img_file))
                        image_found = True
                        break
                
                if not image_found:
                    print(f"警告: 未找到 {base_name} 对应的图片文件")

        if not dota_files:
            QMessageBox.information(self, "提示", "在指定的DOTA文件夹中没有找到有效的DOTA标注文件或对应的图片文件！")
            return

        from PySide6.QtWidgets import QProgressDialog
        from PySide6.QtCore import Qt

        progress = QProgressDialog("正在转换DOTA标注文件为JSON格式...", "取消", 0, len(dota_files), self)
        progress.setWindowTitle("转换进度")
        progress.setWindowModality(Qt.WindowModal)
        progress.show()

        converter = LabelConverter()
        successful_conversions = 0
        failed_conversions = 0

        for i, (dota_file, image_file) in enumerate(dota_files):
            if progress.wasCanceled():
                break

            try:
                file_name = os.path.splitext(os.path.basename(dota_file))[0]
                json_file_path = os.path.join(output_folder, f"{file_name}.json")

                converter.dota_to_custom(
                    input_file=dota_file,
                    output_file=json_file_path,
                    image_file=image_file
                )

                successful_conversions += 1
            except Exception as e:
                failed_conversions += 1
                print(f"转换失败 {dota_file}: {str(e)}")

            progress.setValue(i + 1)
            QApplication.processEvents()

        progress.close()

        result_msg = f"批量转换完成！\n成功: {successful_conversions} 个文件"
        if failed_conversions > 0:
            result_msg += f"\n失败: {failed_conversions} 个文件"
        QMessageBox.information(self, "转换完成", result_msg)

    # 新增转换功能：JSON转MOT格式
    def convert_all_json_to_mot(self):
        """将当前文件夹中所有JSON标注批量转换为MOT格式"""
        if not self.current_folder or not os.path.exists(self.current_folder):
            QMessageBox.warning(self, "警告", "请先打开一个图片文件夹！")
            return

        output_dir = QFileDialog.getExistingDirectory(
            self,
            "选择MOT文件输出目录",
            self.current_folder
        )

        if not output_dir:
            return

        # 创建MOT格式所需的目录结构
        mot_seq_dir = os.path.join(output_dir, "seqmap")
        os.makedirs(mot_seq_dir, exist_ok=True)

        converter = LabelConverter()
        successful_conversions = 0
        failed_conversions = 0

        from PySide6.QtWidgets import QProgressDialog
        from PySide6.QtCore import Qt

        # 获取当前文件夹中的所有JSON文件
        json_files = []
        for file in os.listdir(self.current_folder):
            if file.lower().endswith('.json'):
                json_file_path = os.path.join(self.current_folder, file)
                json_files.append(json_file_path)

        if not json_files:
            QMessageBox.information(self, "提示", "当前文件夹中没有找到JSON标注文件！")
            return

        progress = QProgressDialog("正在转换JSON标注文件为MOT格式...", "取消", 0, len(json_files), self)
        progress.setWindowTitle("转换进度")
        progress.setWindowModality(Qt.WindowModal)
        progress.show()

        try:
            converter.custom_to_mot(
                input_path=self.current_folder,
                save_path=output_dir
            )
            successful_conversions = len(json_files)
        except Exception as e:
            failed_conversions = len(json_files)
            print(f"转换失败: {str(e)}")
        finally:
            progress.close()

        result_msg = f"批量转换完成！\n成功: {successful_conversions} 个文件"
        if failed_conversions > 0:
            result_msg += f"\n失败: {failed_conversions} 个文件"
        QMessageBox.information(self, "转换完成", result_msg)

    # 新增转换功能：MOT转JSON格式
    def convert_all_mot_to_json(self):
        """将当前文件夹中所有MOT标注批量转换为JSON格式"""
        mot_file, _ = QFileDialog.getOpenFileName(
            self,
            "选择MOT标注文件",
            self.current_folder if self.current_folder else "",
            "MOT文件 (*.txt);;所有文件 (*)"
        )

        if not mot_file:
            return

        image_folder = QFileDialog.getExistingDirectory(
            self,
            "选择对应图片文件夹",
            self.current_folder if self.current_folder else ""
        )

        if not image_folder:
            return

        output_folder = self.current_folder
        if not output_folder or not os.path.exists(output_folder):
            QMessageBox.warning(self, "警告", "请先打开一个图片文件夹作为输出目录！")
            return

        from PySide6.QtWidgets import QProgressDialog
        from PySide6.QtCore import Qt

        progress = QProgressDialog("正在转换MOT标注文件为JSON格式...", "取消", 0, 1, self)
        progress.setWindowTitle("转换进度")
        progress.setWindowModality(Qt.WindowModal)
        progress.show()

        converter = LabelConverter()
        successful_conversions = 0
        failed_conversions = 0

        try:
            converter.mot_to_custom(
                input_file=mot_file,
                output_path=output_folder,
                image_path=image_folder
            )
            successful_conversions = 1
        except Exception as e:
            failed_conversions = 1
            print(f"转换失败 {mot_file}: {str(e)}")
        finally:
            progress.close()

        result_msg = f"批量转换完成！\n成功: {successful_conversions} 个文件"
        if failed_conversions > 0:
            result_msg += f"\n失败: {failed_conversions} 个文件"
        QMessageBox.information(self, "转换完成", result_msg)

    # 新增转换功能：JSON转PP-OCR格式
    def convert_all_json_to_ppocr(self):
        """将当前文件夹中所有JSON标注批量转换为PP-OCR格式"""
        if not self.current_folder or not os.path.exists(self.current_folder):
            QMessageBox.warning(self, "警告", "请先打开一个图片文件夹！")
            return

        output_dir = QFileDialog.getExistingDirectory(
            self,
            "选择PP-OCR文件输出目录",
            self.current_folder
        )

        if not output_dir:
            return

        image_folder = self.current_folder
        label_file_path = os.path.join(output_dir, "train.txt")

        from PySide6.QtWidgets import QProgressDialog
        from PySide6.QtCore import Qt

        # 获取当前文件夹中的所有图片文件
        image_files = []
        for file in os.listdir(self.current_folder):
            if file.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.gif')):
                image_file_path = os.path.join(self.current_folder, file)
                json_file = os.path.join(self.current_folder, os.path.splitext(file)[0] + '.json')
                if os.path.exists(json_file):
                    image_files.append((image_file_path, json_file))

        if not image_files:
            QMessageBox.information(self, "提示", "当前文件夹中没有找到有效的图片文件及其对应的JSON标注！")
            return

        progress = QProgressDialog("正在转换JSON标注文件为PP-OCR格式...", "取消", 0, len(image_files), self)
        progress.setWindowTitle("转换进度")
        progress.setWindowModality(Qt.WindowModal)
        progress.show()

        converter = LabelConverter()
        successful_conversions = 0
        failed_conversions = 0

        try:
            for i, (image_file, label_file) in enumerate(image_files):
                if progress.wasCanceled():
                    break

                converter.custom_to_ppocr(
                    image_file=image_file,
                    label_file=label_file,
                    save_path=label_file_path,
                    mode="rectangle"
                )
                successful_conversions += 1
                progress.setValue(i + 1)
                QApplication.processEvents()
        except Exception as e:
            failed_conversions = len(image_files)
            print(f"转换失败: {str(e)}")
        finally:
            progress.close()

        result_msg = f"批量转换完成！\n成功: {successful_conversions} 个文件"
        if failed_conversions > 0:
            result_msg += f"\n失败: {failed_conversions} 个文件"
        QMessageBox.information(self, "转换完成", result_msg)

    # 新增转换功能：PP-OCR转JSON格式
    def convert_all_ppocr_to_json(self):
        """将PP-OCR标注批量转换为JSON格式"""
        ppocr_file, _ = QFileDialog.getOpenFileName(
            self,
            "选择PP-OCR标注文件",
            self.current_folder if self.current_folder else "",
            "PP-OCR文件 (*.txt);;所有文件 (*)"
        )

        if not ppocr_file:
            return

        image_folder = QFileDialog.getExistingDirectory(
            self,
            "选择对应图片文件夹",
            self.current_folder if self.current_folder else ""
        )

        if not image_folder:
            return

        output_folder = self.current_folder
        if not output_folder or not os.path.exists(output_folder):
            QMessageBox.warning(self, "警告", "请先打开一个图片文件夹作为输出目录！")
            return

        from PySide6.QtWidgets import QProgressDialog
        from PySide6.QtCore import Qt

        progress = QProgressDialog("正在转换PP-OCR标注文件为JSON格式...", "取消", 0, 1, self)
        progress.setWindowTitle("转换进度")
        progress.setWindowModality(Qt.WindowModal)
        progress.show()

        converter = LabelConverter()
        successful_conversions = 0
        failed_conversions = 0

        try:
            converter.ppocr_to_custom(
                input_file=ppocr_file,
                output_path=output_folder,
                image_path=image_folder,
                mode="rectangle"
            )
            successful_conversions = 1
        except Exception as e:
            failed_conversions = 1
            print(f"转换失败 {ppocr_file}: {str(e)}")
        finally:
            progress.close()

        result_msg = f"批量转换完成！\n成功: {successful_conversions} 个文件"
        if failed_conversions > 0:
            result_msg += f"\n失败: {failed_conversions} 个文件"
        QMessageBox.information(self, "转换完成", result_msg)

    # 新增转换功能：JSON转Mask格式
    def convert_all_json_to_mask(self):
        """将当前文件夹中所有JSON标注批量转换为Mask格式"""
        if not self.current_folder or not os.path.exists(self.current_folder):
            QMessageBox.warning(self, "警告", "请先打开一个图片文件夹！")
            return

        output_dir = QFileDialog.getExistingDirectory(
            self,
            "选择Mask文件输出目录",
            self.current_folder
        )

        if not output_dir:
            return

        # 询问用户选择输出格式
        format_options = ["grayscale", "rgb"]
        format_choice, ok = QInputDialog.getItem(self, "选择输出格式", "选择Mask输出格式:", format_options, 0, False)
        if not ok:
            return

        # 创建映射表
        mapping_table = {
            "type": format_choice,
            "colors": {}  # 这里需要根据实际类别填充颜色映射
        }

        converter = LabelConverter()
        successful_conversions = 0
        failed_conversions = 0

        from PySide6.QtWidgets import QProgressDialog
        from PySide6.QtCore import Qt

        # 获取当前文件夹中的所有JSON文件
        json_files = []
        for file in os.listdir(self.current_folder):
            if file.lower().endswith('.json'):
                json_file_path = os.path.join(self.current_folder, file)
                base_name = os.path.splitext(file)[0]
                
                # 寻找对应的图片文件
                for img_ext in ['.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.gif']:
                    img_file = os.path.join(self.current_folder, base_name + img_ext)
                    if os.path.exists(img_file):
                        json_files.append((json_file_path, img_file))
                        break

        if not json_files:
            QMessageBox.information(self, "提示", "当前文件夹中没有找到有效的JSON标注文件及对应图片！")
            return

        progress = QProgressDialog("正在转换JSON标注文件为Mask格式...", "取消", 0, len(json_files), self)
        progress.setWindowTitle("转换进度")
        progress.setWindowModality(Qt.WindowModal)
        progress.show()

        for i, (json_file, image_file) in enumerate(json_files):
            if progress.wasCanceled():
                break

            try:
                file_name = os.path.splitext(os.path.basename(json_file))[0]
                mask_file_path = os.path.join(output_dir, f"{file_name}_mask.png")

                converter.custom_to_mask(
                    input_file=json_file,
                    output_file=mask_file_path,
                    mapping_table=mapping_table
                )

                successful_conversions += 1
            except Exception as e:
                failed_conversions += 1
                print(f"转换失败 {json_file}: {str(e)}")

            progress.setValue(i + 1)
            QApplication.processEvents()

        progress.close()

        result_msg = f"批量转换完成！\n成功: {successful_conversions} 个文件"
        if failed_conversions > 0:
            result_msg += f"\n失败: {failed_conversions} 个文件"
        QMessageBox.information(self, "转换完成", result_msg)

