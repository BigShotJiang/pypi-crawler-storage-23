import sys
import traceback
import os
from pathlib import Path
from PySide6.QtWidgets import QApplication, QMessageBox
from PySide6.QtCore import QTimer, QFile, QTextStream

from .main_window import AnnotationTool


def load_stylesheet(app, stylesheet_path):
    """加载QSS样式表"""
    try:
        if os.path.exists(stylesheet_path):
            # 读取QSS文件
            with open(stylesheet_path, 'r', encoding='utf-8') as f:
                stylesheet = f.read()

            # 应用样式表
            app.setStyleSheet(stylesheet)
            print(f"已加载样式表: {stylesheet_path}")
            return True
        else:
            print(f"警告: 样式表文件不存在: {stylesheet_path}")

            # 创建默认样式表文件
            default_qss = """QWidget {
    font-family: "Microsoft YaHei", "Segoe UI", Arial, sans-serif;
    font-size: 10pt;
    background-color: #f0f0f0;
}
QPushButton {
    background-color: #4a90e2;
    color: white;
    border: none;
    border-radius: 4px;
    padding: 6px 12px;
    font-weight: bold;
}"""

            with open(stylesheet_path, 'w', encoding='utf-8') as f:
                f.write(default_qss)
            app.setStyleSheet(default_qss)
            print(f"已创建并加载默认样式表: {stylesheet_path}")
            return True

    except Exception as e:
        print(f"加载样式表时出错: {e}")
        return False


def main():
    app = QApplication(sys.argv)
    app.setStyle('Fusion')

    app.setApplicationName("图像标注工具客户端")
    app.setOrganizationName("标注工具团队")

    # 加载QSS样式表
    # 首先尝试当前目录下的style.qss
    stylesheet_path = "style.qss"

    # 如果当前目录没有，尝试查找相对路径
    if not os.path.exists(stylesheet_path):
        # 尝试其他可能的位置
        possible_paths = [
            "styles.qss",
        ]

        for path in possible_paths:
            if os.path.exists(path):
                stylesheet_path = path
                break

    load_stylesheet(app, stylesheet_path)

    def handle_exception(exc_type, exc_value, exc_traceback):
        error_msg = "".join(traceback.format_exception(exc_type, exc_value, exc_traceback))
        print(f"未捕获的异常:\n{error_msg}")

        def show_error():
            QMessageBox.critical(None, "程序错误",
                                 f"程序发生错误:\n{str(exc_value)}\n\n详细错误信息已打印到控制台。")

        QTimer.singleShot(0, show_error)

    sys.excepthook = handle_exception

    try:
        tool = AnnotationTool()
        tool.show()

        app.aboutToQuit.connect(tool.cleanup_resources)

        sys.exit(app.exec())
    except Exception as e:
        print(f"启动程序时出错: {e}")
        traceback.print_exc()


if __name__ == "__main__":
    main()