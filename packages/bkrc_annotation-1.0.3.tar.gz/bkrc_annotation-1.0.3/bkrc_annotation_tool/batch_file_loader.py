import os
import traceback
from PySide6.QtCore import QThread, Signal, QThread
from .annotation_utils import AnnotationUtils
from .http_client import LANFileClient


class BatchFileLoader(QThread):
    """批量文件加载器 - 使用线程分批加载文件，避免UI卡死"""

    batch_loaded = Signal(list, int, int)  # 文件列表, 起始索引, 结束索引
    load_complete = Signal(int)  # 总文件数
    load_progress = Signal(int, int)  # 已加载数, 总数
    load_error = Signal(str)

    def __init__(self, mode, folder_path=None, ip=None, port=8000, extensions=None):
        super().__init__()
        self.mode = mode  # "local" 或 "remote"
        self.folder_path = folder_path
        self.ip = ip
        self.port = port
        self.extensions = extensions or ['.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.gif', '.json']
        self.batch_size = 100  # 每批加载100个文件
        self.cancel_flag = False
        self.all_files = []
        self.remote_files_cache = {}

    def run(self):
        """运行加载线程"""
        try:
            if self.mode == "local":
                self._load_local_files()
            elif self.mode == "remote":
                self._load_remote_files()
        except Exception as e:
            self.load_error.emit(str(e))
            traceback.print_exc()

    def _load_local_files(self):
        """加载本地文件"""
        if not self.folder_path or not os.path.exists(self.folder_path):
            self.load_error.emit("文件夹不存在")
            return

        # 获取所有文件
        all_files = []
        for file in sorted(os.listdir(self.folder_path)):  # 修复：使用 self.folder_path
            if self.cancel_flag:
                return

            file_path = os.path.join(self.folder_path, file)  # 修复：使用 self.folder_path
            if os.path.isfile(file_path):
                ext = os.path.splitext(file)[1].lower()
                if ext in self.extensions:
                    all_files.append(file)
                    self.remote_files_cache[file] = {'path': file_path}

        self.all_files = all_files

        # 分批发送文件
        total_files = len(all_files)
        self.load_progress.emit(0, total_files)

        for i in range(0, total_files, self.batch_size):
            if self.cancel_flag:
                return

            batch = all_files[i:min(i + self.batch_size, total_files)]
            self.batch_loaded.emit(batch, i, min(i + self.batch_size, total_files))
            self.load_progress.emit(min(i + self.batch_size, total_files), total_files)

            # 让UI有机会处理事件
            QThread.msleep(10)

        self.load_complete.emit(total_files)

    def _load_remote_files(self):
        """加载远程文件"""
        if not self.ip:
            self.load_error.emit("未指定IP地址")
            return

        try:
            # 获取远程文件列表
            result = LANFileClient.list_files(self.ip, self.port)
            if not result:
                self.load_error.emit("无法获取文件列表")
                return

            files = result.get('files', [])
            if not files:
                self.load_complete.emit(0)
                return

            # 过滤文件
            filtered_files = []
            for file_info in files:
                if self.cancel_flag:
                    return

                filename = file_info.get('name', '')
                ext = os.path.splitext(filename)[1].lower()
                if ext in self.extensions:
                    filtered_files.append(filename)
                    self.remote_files_cache[filename] = {
                        'path': file_info.get('path', ''),
                        'size': file_info.get('size', 0),
                        'type': file_info.get('type', 'other')
                    }

            self.all_files = filtered_files

            # 分批发送文件
            total_files = len(filtered_files)
            self.load_progress.emit(0, total_files)

            for i in range(0, total_files, self.batch_size):
                if self.cancel_flag:
                    return

                batch = filtered_files[i:min(i + self.batch_size, total_files)]
                self.batch_loaded.emit(batch, i, min(i + self.batch_size, total_files))
                self.load_progress.emit(min(i + self.batch_size, total_files), total_files)

                # 让UI有机会处理事件
                QThread.msleep(10)

            self.load_complete.emit(total_files)

        except Exception as e:
            self.load_error.emit(f"加载远程文件失败: {str(e)}")

    def cancel(self):
        """取消加载"""
        self.cancel_flag = True