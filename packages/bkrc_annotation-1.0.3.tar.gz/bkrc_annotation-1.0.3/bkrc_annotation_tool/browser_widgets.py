"""
浏览器组件模块，提供通用的浏览器组件功能
"""
import sys
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, 
    QLineEdit, QStatusBar, QLabel, QSizePolicy
)
from PySide6.QtCore import Qt, QUrl
from PySide6.QtWebEngineWidgets import QWebEngineView


class BrowserWidget(QWidget):
    """通用浏览器组件，可嵌入到UI中"""

    def __init__(self, port=8080, placeholder_text=None, default_url=None, parent=None):
        super().__init__(parent)
        self.port = port

        # 创建主布局
        layout = QVBoxLayout(self)

        # ========== 控制栏 ==========
        control_layout = QHBoxLayout()

        # 后退按钮
        self.back_btn = QPushButton("← 后退")
        self.back_btn.clicked.connect(self.go_back)
        control_layout.addWidget(self.back_btn)

        # 前进按钮
        self.forward_btn = QPushButton("前进 →")
        self.forward_btn.clicked.connect(self.go_forward)
        control_layout.addWidget(self.forward_btn)

        # 刷新按钮
        self.refresh_btn = QPushButton("↻ 刷新")
        self.refresh_btn.clicked.connect(self.refresh_page)
        control_layout.addWidget(self.refresh_btn)

        # 地址栏
        self.url_bar = QLineEdit()
        if placeholder_text:
            self.url_bar.setPlaceholderText(placeholder_text)
        else:
            self.url_bar.setPlaceholderText(f"请输入网址（例如：http://localhost:{self.port}）")
        # 按回车键访问输入的网址
        self.url_bar.returnPressed.connect(self.navigate_to_url)
        control_layout.addWidget(self.url_bar, stretch=1)

        layout.addLayout(control_layout)

        # ========== 网页显示区域 ==========
        try:
            self.web_view = QWebEngineView()

            # 默认加载指定URL
            if default_url:
                self.web_view.setUrl(QUrl(default_url))
            else:
                default_url = f"http://localhost:{self.port}"
                self.web_view.setUrl(QUrl(default_url))
            # 监听网页加载状态，更新地址栏
            self.web_view.urlChanged.connect(self.update_url_bar)
            layout.addWidget(self.web_view)
        except Exception as e:
            # 如果WebEngine不可用，显示错误信息
            error_label = QLabel(f"Web浏览器组件初始化失败: {str(e)}\n请确保系统有正确的图形驱动。")
            error_label.setWordWrap(True)
            layout.addWidget(error_label)

        # ========== 状态栏 ==========
        self.status_bar = QStatusBar()
        # 监听加载进度，更新状态栏
        if hasattr(self, 'web_view'):
            self.web_view.loadProgress.connect(self.update_status_bar)

    def navigate_to_url(self):
        """访问地址栏输入的网址"""
        url_text = self.url_bar.text().strip()
        # 补全网址前缀
        if not url_text.startswith(("http://", "https://")):
            url_text = f"http://{url_text}"

        try:
            url = QUrl(url_text)
            if url.isValid() and hasattr(self, 'web_view'):
                self.web_view.setUrl(url)
            else:
                self.status_bar.showMessage("无效的网址！", 3000)
        except Exception as e:
            self.status_bar.showMessage(f"访问失败：{str(e)}", 3000)

    def update_url_bar(self, url):
        """网页地址变化时，更新地址栏显示"""
        self.url_bar.setText(url.toString())
        self.url_bar.setCursorPosition(0)

    def go_back(self):
        """后退到上一页"""
        if hasattr(self, 'web_view') and self.web_view.history().canGoBack():
            self.web_view.history().back()
        else:
            self.status_bar.showMessage("没有上一页", 2000)

    def go_forward(self):
        """前进到下一页"""
        if hasattr(self, 'web_view') and self.web_view.history().canGoForward():
            self.web_view.history().forward()
        else:
            self.status_bar.showMessage("没有下一页", 2000)

    def refresh_page(self):
        """刷新当前页面"""
        if hasattr(self, 'web_view'):
            self.web_view.reload()
            self.status_bar.showMessage("正在刷新...", 1000)
        else:
            self.status_bar.showMessage("浏览器组件不可用", 2000)

    def update_status_bar(self, progress):
        """更新状态栏的加载进度"""
        if progress == 100:
            self.status_bar.showMessage("页面加载完成", 2000)
        else:
            self.status_bar.showMessage(f"加载中：{progress}%", 0)

    def load_url(self, port):
        """加载指定端口的URL"""
        if hasattr(self, 'web_view'):
            url = QUrl(f"http://localhost:{port}")
            self.web_view.setUrl(url)

    def cleanup(self):
        """清理资源"""
        if hasattr(self, 'web_view'):
            self.web_view.page().profile().clearHttpCache()
            self.web_view.stop()
            self.web_view.close()


class NetronBrowser(BrowserWidget):
    """Netron浏览器组件，可嵌入到UI中"""

    def __init__(self, port=8080, parent=None):
        super().__init__(port=port, 
                         placeholder_text=f"请输入网址（例如：http://localhost:{port}）", 
                         default_url=f"http://localhost:{port}", 
                         parent=parent)

    def load_netron(self, port=8080):
        """加载指定端口的Netron"""
        self.load_url(port)


class TensorBoardBrowser(BrowserWidget):
    """TensorBoard浏览器组件，可嵌入到UI中"""

    def __init__(self, port=6006, parent=None):
        super().__init__(port=port, 
                         placeholder_text=f"请输入网址（例如：http://localhost:{port}）", 
                         default_url=f"http://localhost:{port}", 
                         parent=parent)

    def load_tensorboard(self, port=6006):
        """加载指定端口的TensorBoard"""
        self.load_url(port)