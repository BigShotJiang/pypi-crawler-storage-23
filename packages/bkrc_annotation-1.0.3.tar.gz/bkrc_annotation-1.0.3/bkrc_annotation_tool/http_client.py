import requests
import json
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import threading

from .network_utils import NetworkUtils


class OptimizedHTTPClient:
    """优化的HTTP客户端 - 支持连接复用和并发传输"""

    def __init__(self, max_workers=50, max_retries=3, timeout=30):
        self.max_workers = max_workers
        self.sessions = {}
        self.executor = ThreadPoolExecutor(max_workers=max_workers)
        self.max_retries = max_retries
        self.timeout = timeout
        self._session_lock = threading.Lock()

    def get_session(self, ip, port=8000):
        """获取或创建指定IP的Session - 线程安全"""
        key = f"{ip}:{port}"

        with self._session_lock:
            if key not in self.sessions:
                session = requests.Session()

                # 配置重试策略
                retry_strategy = Retry(
                    total=self.max_retries,
                    backoff_factor=0.5,
                    status_forcelist=[500, 502, 503, 504],
                    allowed_methods=["GET", "POST", "PUT", "DELETE"]
                )

                # 优化连接池配置
                adapter = HTTPAdapter(
                    pool_connections=50,  # 连接池大小
                    pool_maxsize=100,  # 最大连接数
                    max_retries=retry_strategy,
                    pool_block=False  # 不阻塞连接请求
                )
                session.mount('http://', adapter)
                session.mount('https://', adapter)

                # 设置默认超时
                session.timeout = self.timeout

                self.sessions[key] = session

                # 设置长连接
                session.keep_alive = True

            return self.sessions[key]

    def upload_file_batch(self, ip, file_paths, port=8000, client_name="标注工具客户端", overwrite=True):
        """批量上传文件到服务器 - 使用单个Session并发上传"""
        results = {}

        try:
            session = self.get_session(ip, port)
            client_ip = NetworkUtils.get_local_ip()

            def upload_single(file_path):
                try:
                    filename = os.path.basename(file_path)
                    url = f"http://{ip}:{port}/upload/{filename}"

                    with open(file_path, 'rb') as f:
                        files = {'file': (filename, f, 'application/octet-stream')}
                        data = {
                            'client_ip': client_ip,
                            'client_name': client_name,
                            'overwrite': 'true' if overwrite else 'false'
                        }

                        response = session.post(url, files=files, data=data, timeout=self.timeout)

                    if response.status_code == 200:
                        return file_path, response.json()
                    else:
                        return file_path, {"error": f"状态码: {response.status_code}", "status": "fail"}

                except Exception as e:
                    return file_path, {"error": str(e), "status": "fail"}

            # 并发上传所有文件
            with ThreadPoolExecutor(max_workers=min(len(file_paths), 20)) as executor:
                futures = {executor.submit(upload_single, fp): fp for fp in file_paths}

                for future in as_completed(futures):
                    file_path = futures[future]
                    try:
                        file_path, result = future.result()
                        results[file_path] = result
                    except Exception as e:
                        results[file_path] = {"error": str(e), "status": "fail"}

            return results

        except Exception as e:
            print(f"批量上传失败 {ip}:{port}: {e}")
            for fp in file_paths:
                results[fp] = {"error": str(e), "status": "fail"}
            return results

    def upload_file(self, ip, file_path, port=8000, client_name="标注工具客户端", overwrite=True):
        """上传单个文件到服务器"""
        try:
            filename = os.path.basename(file_path)
            url = f"http://{ip}:{port}/upload/{filename}"
            client_ip = NetworkUtils.get_local_ip()

            session = self.get_session(ip, port)

            with open(file_path, 'rb') as f:
                files = {'file': (filename, f, 'application/octet-stream')}
                data = {
                    'client_ip': client_ip,
                    'client_name': client_name,
                    'overwrite': 'true' if overwrite else 'false'
                }

                response = session.post(url, files=files, data=data, timeout=self.timeout)

            if response.status_code == 200:
                return response.json()
            else:
                print(f"上传失败: {response.status_code} - {response.text}")
                return {"error": f"状态码: {response.status_code}", "status": "fail"}
        except Exception as e:
            print(f"上传文件失败 {filename} to {ip}:{port}: {e}")
            return {"error": str(e), "status": "fail"}

    def send_request(self, method, ip, endpoint, port=8000, **kwargs):
        """发送HTTP请求的统一方法"""
        try:
            url = f"http://{ip}:{port}{endpoint}"
            session = self.get_session(ip, port)

            # 设置默认超时
            if 'timeout' not in kwargs:
                kwargs['timeout'] = self.timeout

            if method.lower() == 'get':
                response = session.get(url, **kwargs)
            elif method.lower() == 'post':
                response = session.post(url, **kwargs)
            else:
                raise ValueError(f"不支持的HTTP方法: {method}")

            if response.status_code == 200:
                try:
                    return response.json()
                except:
                    return response.text
            else:
                print(f"请求失败: {response.status_code} - {response.text}")
                return None
        except Exception as e:
            print(f"请求失败 {method} {url}: {e}")
            return None

    def close_all(self):
        """关闭所有连接"""
        for session in self.sessions.values():
            try:
                session.close()
            except:
                pass
        self.sessions.clear()
        self.executor.shutdown(wait=True)


class LANFileClient:
    """局域网文件客户端"""

    _http_client = OptimizedHTTPClient(max_workers=50, timeout=60)

    @staticmethod
    def get_server_status(ip, port=8000):
        """获取指定服务器状态"""
        try:
            result = LANFileClient._http_client.send_request('get', ip, '/status', port)
            if result is None:
                return {"status": "offline", "ip": ip}
            return result
        except:
            return {"status": "offline", "ip": ip}

    @staticmethod
    def list_files(ip, port=8000):
        """列出服务器的文件 - 移除限制"""
        return LANFileClient._http_client.send_request('get', ip, '/files', port)

    @staticmethod
    def upload_file(ip, file_path, port=8000, client_name="标注工具客户端", overwrite=True):
        """上传文件到服务器"""
        return LANFileClient._http_client.upload_file(ip, file_path, port, client_name, overwrite)

    @staticmethod
    def upload_files_batch(ip, file_paths, port=8000, client_name="标注工具客户端", overwrite=True):
        """批量上传文件到服务器 - 使用并发和连接复用"""
        return LANFileClient._http_client.upload_file_batch(ip, file_paths, port, client_name, overwrite)

    @staticmethod
    def send_reverse_transfer_request(ip, files, port=8000):
        """发送回传请求到服务器"""
        try:
            data = {'files': json.dumps(files)}
            return LANFileClient._http_client.send_request('post', ip, '/reverse_transfer', port, data=data)
        except Exception as e:
            print(f"发送回传请求失败: {e}")
            return None

    @staticmethod
    def download_file(ip, filename, save_path, port=8000):
        """从服务器下载文件"""
        try:
            url = f"http://{ip}:{port}/file/{filename}"
            session = LANFileClient._http_client.get_session(ip, port)

            # 使用流式下载
            with session.get(url, stream=True, timeout=60) as response:
                if response.status_code == 200:
                    total_size = int(response.headers.get('content-length', 0))
                    chunk_size = 8192

                    with open(save_path, 'wb') as f:
                        if total_size == 0:
                            for chunk in response.iter_content(chunk_size=chunk_size):
                                if chunk:
                                    f.write(chunk)
                        else:
                            downloaded = 0
                            for chunk in response.iter_content(chunk_size=chunk_size):
                                if chunk:
                                    f.write(chunk)
                                    downloaded += len(chunk)
                    return True
                else:
                    print(f"下载失败: {response.status_code}")
                    return False
        except Exception as e:
            print(f"下载文件失败 {filename} from {ip}:{port}: {e}")
            return False

    @staticmethod
    def set_server_folder(ip, folder_path, port=8000):
        """设置服务器文件夹"""
        try:
            # 使用表单数据格式，而不是JSON数据格式
            import requests
            url = f"http://{ip}:{port}/set_folder"
            session = LANFileClient._http_client.get_session(ip, port)
            
            # 使用表单数据而不是JSON数据
            # 注意：服务器可能在处理成功后返回500错误，但操作实际上已完成
            try:
                response = session.post(url, data={'folder_path': folder_path}, timeout=15)  # 缩短超时时间
                
                # 如果成功，直接返回
                if response.status_code == 200:
                    try:
                        return response.json()
                    except:
                        return response.text
                
            except requests.exceptions.RequestException as e:
                # 捕获连接错误、500错误等，但不打印错误信息以减少干扰
                pass  # 静默处理异常，因为操作可能仍然成功
                
            # 无论响应如何，都检查操作是否实际成功
            # 通过获取服务器状态来确认文件夹是否已更改
            try:
                import time
                time.sleep(0.3)  # 减少等待时间以提高响应速度
                status = LANFileClient.get_server_status(ip, port)
                if status and 'folder' in status:
                    # 标准化路径以进行比较
                    normalized_server_folder = status['folder'].replace('\\', '/').rstrip('/')
                    normalized_request_folder = folder_path.replace('\\', '/').rstrip('/')
                    
                    if normalized_server_folder == normalized_request_folder:
                        return {
                            "message": "文件夹设置成功", 
                            "folder": status['folder'], 
                            "status": "success"
                        }
                    
            except Exception:
                # 静默处理状态检查异常
                pass
                
            # 如果到这里说明操作失败
            return None
            
        except Exception:
            # 静默处理异常
            return None

    @staticmethod
    def get_network_info(ip, port=8000):
        """获取服务器网络信息"""
        try:
            return LANFileClient._http_client.send_request('get', ip, '/network_info', port)
        except Exception as e:
            print(f"获取网络信息失败: {e}")
            return None

    @staticmethod
    def detect_network(ip, network, port=8000):
        """请求服务器探测网络"""
        try:
            data = {'network': network}
            return LANFileClient._http_client.send_request('post', ip, '/detect_network', port, data=data)
        except Exception as e:
            print(f"请求网络探测失败: {e}")
            return None

    @staticmethod
    def download_files_batch(ip, file_info_list, local_folder, port=8000):
        """批量下载文件 - 使用并发和连接复用"""
        results = {}

        def download_single(filename):
            try:
                save_path = os.path.join(local_folder, filename)
                success = LANFileClient.download_file(ip, filename, save_path, port)
                return filename, success, None
            except Exception as e:
                return filename, False, str(e)

        # 并发下载所有文件
        with ThreadPoolExecutor(max_workers=min(len(file_info_list), 20)) as executor:
            futures = {executor.submit(download_single, filename): filename for filename in file_info_list}

            for future in as_completed(futures):
                filename = futures[future]
                try:
                    filename, success, error = future.result()
                    results[filename] = {"success": success, "error": error}
                except Exception as e:
                    results[filename] = {"success": False, "error": str(e)}

        return results

    @staticmethod
    def close_all_connections():
        """关闭所有连接"""
        LANFileClient._http_client.close_all()