from datetime import datetime
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QGridLayout, QGroupBox,
    QLabel, QPushButton, QHBoxLayout
)
from PySide6.QtCore import Qt


class SimpleServerDetailDialog(QDialog):
    """简化的服务器详情对话框 - 只显示设备基本信息"""

    def __init__(self, server_info, parent=None):
        super().__init__(parent)
        self.setWindowTitle("设备信息")
        self.resize(400, 300)

        self.server_info = server_info
        self.init_ui()

    def init_ui(self):
        """初始化UI"""
        layout = QVBoxLayout(self)

        # 设备基本信息
        info_group = QGroupBox("设备基本信息")
        info_layout = QGridLayout(info_group)

        info_layout.addWidget(QLabel("IP地址:"), 0, 0)
        ip_label = QLabel(self.server_info.get('ip', '未知'))
        ip_label.setStyleSheet("font-weight: bold; color: blue;")
        info_layout.addWidget(ip_label, 0, 1)

        info = self.server_info.get('info', {})

        info_layout.addWidget(QLabel("设备名称:"), 1, 0)
        info_layout.addWidget(QLabel(info.get('name', '未知')), 1, 1)

        info_layout.addWidget(QLabel("设备类型:"), 2, 0)
        device_type = info.get('type', 'unknown')
        type_text = "图像标注工具后端服务"
        type_label = QLabel(type_text)
        type_label.setStyleSheet("color: green; font-weight: bold;")
        info_layout.addWidget(type_label, 2, 1)

        info_layout.addWidget(QLabel("主机名:"), 3, 0)
        info_layout.addWidget(QLabel(info.get('hostname', '未知')), 3, 1)

        info_layout.addWidget(QLabel("端口:"), 4, 0)
        info_layout.addWidget(QLabel(str(info.get('port', 8000))), 4, 1)

        info_layout.addWidget(QLabel("发现时间:"), 5, 0)
        timestamp = info.get('timestamp', '')
        if timestamp:
            try:
                dt = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
                time_str = dt.strftime('%Y-%m-%d %H:%M:%S')
            except:
                time_str = timestamp
        else:
            time_str = '未知'
        info_layout.addWidget(QLabel(time_str), 5, 1)

        layout.addWidget(info_group)

        # 按钮
        button_layout = QHBoxLayout()
        close_btn = QPushButton("关闭")
        close_btn.clicked.connect(self.close)
        button_layout.addStretch()
        button_layout.addWidget(close_btn)
        layout.addLayout(button_layout)