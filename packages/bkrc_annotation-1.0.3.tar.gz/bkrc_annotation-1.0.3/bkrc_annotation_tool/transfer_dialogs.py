import os
from datetime import datetime
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QGroupBox, QLabel,
    QLineEdit, QListWidget, QListWidgetItem, QPushButton,
    QCheckBox, QSpinBox, QGridLayout, QScrollArea, QWidget,
    QTextEdit, QProgressBar, QDialogButtonBox, QMessageBox,
    QApplication, QAbstractItemView
)
from PySide6.QtCore import Qt, Signal, QThread, QTimer
from PySide6.QtCore import QObject, Signal
from PySide6.QtGui import QColor
import threading
import traceback

from .annotation_utils import AnnotationUtils
from .http_client import LANFileClient
from .batch_file_loader import BatchFileLoader


class OptimizedFileTransferDialog(QDialog):
    """优化的文件传输对话框 - 支持大量文件的分批加载"""

    def __init__(self, mode="distribution", parent=None):
        super().__init__(parent)
        self.mode = mode  # 修复：使用传入的mode参数
        self.setWindowTitle("分发配置" if mode == "distribution" else "回传配置")  # 根据模式设置标题
        self.resize(900, 700)

        # 从主窗口获取已保存的IP列表
        if parent and hasattr(parent, 'saved_ips'):
            self.target_ips = parent.saved_ips.copy()
        else:
            self.target_ips = []

        # 从主窗口获取AI检测服务配置的服务器地址
        self.server_address = "http://127.0.0.1:8000"  # 默认地址
        if parent and hasattr(parent, 'detection_widget'):
            self.server_address = parent.detection_widget.url_edit.text()
            # 监听AI检测服务地址变化
            parent.detection_widget.url_edit.textChanged.connect(self.on_server_address_changed)

        self.selected_files = []
        self.extensions = ['.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.gif', '.json']

        # 批量加载器
        self.file_loader = None
        self.all_files = []  # 所有文件列表
        self.displayed_files = set()  # 已显示的文件
        self.remote_files_cache = {}

        # 回传模式特定变量
        self.current_target_ip = None

        self.init_ui()

        # 自动初始化连接服务器
        self.auto_connect_to_server()

    def on_server_address_changed(self, text):
        """当AI检测服务地址改变时更新服务器地址"""
        self.server_address = text
        self.status_label.setText(f"服务器地址已更新: {text}")

    def auto_connect_to_server(self):
        """自动连接到服务器"""
        if hasattr(self, 'status_label'):
            self.status_label.setText("正在自动连接服务器...")
            
        # 提取服务器IP和端口
        try:
            from urllib.parse import urlparse
            parsed_url = urlparse(self.server_address)
            server_ip = parsed_url.hostname if parsed_url.hostname else '127.0.0.1'
            server_port = parsed_url.port if parsed_url.port else 8000
            
            # 尝试连接服务器 - 首先检查AI检测服务
            ai_connected = False
            ai_health_status = None
            
            try:
                from detection_widget import XAnyLabelingClient
                client = XAnyLabelingClient(base_url=self.server_address)
                ai_health_status = client.health()
                if ai_health_status and ai_health_status.get("status") == "healthy":
                    ai_connected = True
                    self.status_label.setText(f"✓ 已连接到AI检测服务: {self.server_address}")
                    client.close()
                    print(f"DEBUG: Successfully connected to AI detection service at {self.server_address}")
                else:
                    print(f"DEBUG: AI detection service not healthy: {ai_health_status}")
            except Exception as ai_error:
                print(f"DEBUG: Failed to connect to AI detection service: {str(ai_error)}")
                # AI检测服务不可用，尝试连接文件传输服务
                pass
            
            if ai_connected:
                # 如果是回传模式，自动加载远程文件
                if self.mode == "reverse":
                    self.current_target_ip = server_ip
                    # 自动添加服务器IP到列表（如果不存在）
                    if server_ip not in self.target_ips:
                        self.target_ips.append(server_ip)
                        if hasattr(self, 'ip_list_widget'):
                            self.ip_list_widget.addItem(server_ip)
                # 如果是分发模式，可以显示连接状态
                elif self.mode == "distribution":
                    self.status_label.setText(f"服务器连接成功: {self.server_address}")
            else:
                # 尝试连接文件传输服务
                try:
                    from http_client import LANFileClient
                    status = LANFileClient.get_server_status(server_ip, server_port)
                    if status and status.get('status') == 'running':
                        self.status_label.setText(f"已连接到文件传输服务: {self.server_address}")
                        # 如果是回传模式，自动加载远程文件
                        if self.mode == "reverse":
                            self.current_target_ip = server_ip
                            # 自动添加服务器IP到列表（如果不存在）
                            if server_ip not in self.target_ips:
                                self.target_ips.append(server_ip)
                                if hasattr(self, 'ip_list_widget'):
                                    self.ip_list_widget.addItem(server_ip)
                    else:
                        self.status_label.setText(f"服务器连接失败: {self.server_address}")
                except Exception as e:
                    self.status_label.setText(f"服务器连接错误: {str(e)}")
        except Exception as e:
            self.status_label.setText(f"服务器地址解析错误: {str(e)}")

    def init_ui(self):
        """初始化UI"""
        layout = QVBoxLayout(self)

        # 1. 目标IP配置
        ip_group = QGroupBox("目标IP配置")
        ip_layout = QVBoxLayout(ip_group)

        # IP输入和添加按钮
        ip_input_layout = QHBoxLayout()
        self.ip_input = QLineEdit()
        self.ip_input.setPlaceholderText("输入IP地址，如: 192.168.1.100")
        add_ip_btn = QPushButton("添加")
        add_ip_btn.clicked.connect(self.add_ip)
        ip_input_layout.addWidget(self.ip_input)
        ip_input_layout.addWidget(add_ip_btn)
        ip_layout.addLayout(ip_input_layout)

        # IP列表
        self.ip_list_widget = QListWidget()
        self.ip_list_widget.setMaximumHeight(150)
        self.ip_list_widget.setSelectionMode(QAbstractItemView.MultiSelection)
        self.ip_list_widget.itemSelectionChanged.connect(self.on_ip_selected)

        # 加载已保存的IP
        for ip in self.target_ips:
            self.ip_list_widget.addItem(ip)

        ip_layout.addWidget(self.ip_list_widget)

        # IP列表操作按钮
        ip_btn_layout = QHBoxLayout()

        # 根据模式决定是否显示加载远程文件按钮
        if self.mode == "reverse":
            load_files_btn = QPushButton("加载远程文件")
            load_files_btn.clicked.connect(self.load_remote_files_optimized)
            ip_btn_layout.addWidget(load_files_btn)

        remove_ip_btn = QPushButton("删除选中")
        remove_ip_btn.clicked.connect(self.remove_ip)
        clear_ips_btn = QPushButton("清空列表")
        clear_ips_btn.clicked.connect(self.clear_ips)

        ip_btn_layout.addWidget(remove_ip_btn)
        ip_btn_layout.addWidget(clear_ips_btn)
        ip_layout.addLayout(ip_btn_layout)

        layout.addWidget(ip_group)

        # 2. 文件类型筛选
        filter_group = QGroupBox("文件类型筛选")
        filter_layout = QVBoxLayout(filter_group)

        # 文件后缀输入框（不使用下拉菜单，只保留输入框）
        ext_layout = QHBoxLayout()
        ext_layout.addWidget(QLabel("文件后缀:"))
        self.ext_input = QLineEdit(".png,.jpg,.jpeg,.bmp,.tiff,.gif,.json")
        self.ext_input.setPlaceholderText("例如: .png,.jpg,.json")
        ext_layout.addWidget(self.ext_input)
        filter_layout.addLayout(ext_layout)

        # 筛选按钮
        filter_btn_layout = QHBoxLayout()
        apply_filter_btn = QPushButton("应用筛选")
        apply_filter_btn.clicked.connect(self.apply_filter)
        reset_filter_btn = QPushButton("重置筛选")
        reset_filter_btn.clicked.connect(self.reset_filter)
        filter_btn_layout.addWidget(apply_filter_btn)
        filter_btn_layout.addWidget(reset_filter_btn)
        filter_layout.addLayout(filter_btn_layout)

        layout.addWidget(filter_group)

        # 3. 文件选择区域
        file_group = QGroupBox("选择要传输的文件")
        file_layout = QVBoxLayout(file_group)

        # 文件列表和滚动区域
        self.file_list_container = QWidget()
        file_list_layout = QVBoxLayout(self.file_list_container)

        # 文件列表
        self.file_list_widget = QListWidget()
        self.file_list_widget.setSelectionMode(QAbstractItemView.MultiSelection)
        self.file_list_widget.setMaximumHeight(250)
        self.file_list_widget.itemSelectionChanged.connect(self.update_file_counts)
        file_list_layout.addWidget(self.file_list_widget)

        # 文件计数和加载进度
        file_info_layout = QHBoxLayout()
        self.file_count_label = QLabel("等待加载文件...")
        self.load_progress_label = QLabel("")
        file_info_layout.addWidget(self.file_count_label)
        file_info_layout.addWidget(self.load_progress_label)
        file_info_layout.addStretch()
        file_list_layout.addLayout(file_info_layout)

        # 文件列表容器放入滚动区域
        file_scroll = QScrollArea()
        file_scroll.setWidget(self.file_list_container)
        file_scroll.setWidgetResizable(True)
        file_layout.addWidget(file_scroll)

        # 文件操作按钮
        file_btn_layout = QHBoxLayout()

        if self.mode == "distribution":
            load_local_btn = QPushButton("加载本地文件")
            load_local_btn.clicked.connect(self.load_local_files_optimized)
            file_btn_layout.addWidget(load_local_btn)

        select_all_btn = QPushButton("全选")
        select_all_btn.clicked.connect(self.optimized_select_all_files)
        select_none_btn = QPushButton("全不选")
        select_none_btn.clicked.connect(self.select_none_files)

        file_btn_layout.addWidget(select_all_btn)
        file_btn_layout.addWidget(select_none_btn)
        file_layout.addLayout(file_btn_layout)

        layout.addWidget(file_group)

        # 4. 传输选项
        options_group = QGroupBox("传输选项")
        options_layout = QGridLayout(options_group)

        self.overwrite_check = QCheckBox("覆盖目标文件（如果存在）")
        self.overwrite_check.setChecked(True)
        options_layout.addWidget(self.overwrite_check, 0, 0)

        if self.mode == "distribution":
            self.even_distribution_check = QCheckBox("平均分发文件")
            self.even_distribution_check.setChecked(False)
            options_layout.addWidget(self.even_distribution_check, 0, 1)

            self.skip_sent_check = QCheckBox("不加载已分发文件")
            self.skip_sent_check.setChecked(True)
            options_layout.addWidget(self.skip_sent_check, 1, 0)

            # 并发传输选项
            self.concurrent_check = QCheckBox("并发传输（推荐）")
            self.concurrent_check.setChecked(True)
            options_layout.addWidget(self.concurrent_check, 2, 0)

            self.concurrent_threads = QSpinBox()
            self.concurrent_threads.setRange(1, 50)
            self.concurrent_threads.setValue(10)
            options_layout.addWidget(QLabel("并发线程数:"), 2, 1)
            options_layout.addWidget(self.concurrent_threads, 2, 2)
        else:
            # 回传模式特定选项
            self.delete_after_transfer = QCheckBox("传输后删除远程文件")
            self.delete_after_transfer.setChecked(False)
            options_layout.addWidget(self.delete_after_transfer, 0, 1)

        layout.addWidget(options_group)

        # 5. 状态显示
        status_group = QGroupBox("状态")
        status_layout = QVBoxLayout(status_group)
        self.status_label = QLabel("准备就绪")
        status_layout.addWidget(self.status_label)
        layout.addWidget(status_group)

        # 6. 按钮
        button_layout = QHBoxLayout()
        ok_btn = QPushButton("开始传输")
        ok_btn.clicked.connect(self.accept)
        cancel_btn = QPushButton("取消")
        cancel_btn.clicked.connect(self.reject)
        button_layout.addWidget(ok_btn)
        button_layout.addWidget(cancel_btn)
        layout.addLayout(button_layout)

    def load_local_files_optimized(self):
        """优化版加载本地文件 - 使用批量加载器"""
        if self.mode != "distribution":
            return

        if self.parent() and hasattr(self.parent(), 'current_folder'):
            folder_path = self.parent().current_folder
            if not folder_path or not os.path.exists(folder_path):
                QMessageBox.warning(self, "警告", "请先打开一个文件夹")
                return

            # 停止现有的加载器
            if self.file_loader and self.file_loader.isRunning():
                self.file_loader.cancel()
                self.file_loader.wait(1000)

            # 创建新的加载器
            # 使用临时禁用界面更新来提高性能
            self.file_list_widget.setUpdatesEnabled(False)
            self.file_list_widget.clear()
            self.all_files = []
            self.displayed_files.clear()
            self.remote_files_cache.clear()

            self.status_label.setText("正在扫描本地文件...")
            QApplication.processEvents()

            # 获取扩展名，使用输入框中的值
            ext_text = self.ext_input.text().strip()
            if ext_text:
                extensions = [ext.strip().lower() for ext in ext_text.split(',') if ext.strip()]
            else:
                extensions = ['.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.gif', '.json']

            self.file_loader = BatchFileLoader("local", folder_path, extensions=extensions)
            self.file_loader.batch_loaded.connect(self.add_files_batch)
            self.file_loader.load_complete.connect(self.on_files_load_complete)
            self.file_loader.load_progress.connect(self.on_load_progress)
            self.file_loader.load_error.connect(self.on_load_error)
            self.file_loader.start()

    def load_remote_files_optimized(self):
        """优化版加载远程文件 - 使用批量加载器"""
        if not self.current_target_ip:
            QMessageBox.warning(self, "警告", "请先选择一个目标IP")
            return

        self.status_label.setText(f"正在连接 {self.current_target_ip}...")
        QApplication.processEvents()

        # 停止现有的加载器
        if self.file_loader and self.file_loader.isRunning():
            self.file_loader.cancel()
            self.file_loader.wait(1000)

        # 创建新的加载器
        self.file_list_widget.setUpdatesEnabled(False)  # 临时禁用界面更新
        self.file_list_widget.clear()
        self.all_files = []
        self.displayed_files.clear()
        self.remote_files_cache.clear()

        # 获取扩展名，使用输入框中的值
        ext_text = self.ext_input.text().strip()
        if ext_text:
            extensions = [ext.strip().lower() for ext in ext_text.split(',') if ext.strip()]
        else:
            extensions = ['.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.gif', '.json']

        self.file_loader = BatchFileLoader("remote", ip=self.current_target_ip,
                                           port=8000, extensions=extensions)
        self.file_loader.batch_loaded.connect(self.add_files_batch)
        self.file_loader.load_complete.connect(self.on_files_load_complete)
        self.file_loader.load_progress.connect(self.on_load_progress)
        self.file_loader.load_error.connect(self.on_load_error)
        self.file_loader.start()

    def add_files_batch(self, file_batch, start_idx, end_idx):
        """批量添加文件到列表 - 修复版"""
        if not file_batch:
            return

        # 阻塞信号，避免每次添加都触发事件
        self.file_list_widget.blockSignals(True)

        try:
            for i, filename in enumerate(file_batch):
                # 检查是否已经显示过
                if filename in self.displayed_files:
                    continue

                # 添加到显示列表
                self.displayed_files.add(filename)

                # 创建列表项
                if self.mode == "distribution":
                    item_text = filename

                    # 确保缓存中有完整路径信息
                    if filename not in self.remote_files_cache:
                        # 尝试获取完整路径
                        if self.parent() and hasattr(self.parent(), 'current_folder'):
                            folder = self.parent().current_folder
                            file_path = os.path.join(folder, filename)
                            self.remote_files_cache[filename] = {'path': file_path}
                            print(f"添加文件到缓存: {filename} -> {file_path}")
                else:
                    # 远程文件显示大小信息
                    file_info = self.file_loader.remote_files_cache.get(filename, {})
                    size_str = AnnotationUtils.format_file_size(file_info.get('size', 0))
                    item_text = f"{filename} ({size_str})"

                item = QListWidgetItem(item_text)
                # 确保设置 UserRole 数据为文件名
                item.setData(Qt.UserRole, filename)

                # 添加图标表示文件类型
                if filename.lower().endswith('.json'):
                    item.setForeground(QColor(0, 128, 0))  # 绿色表示标注文件
                elif any(filename.lower().endswith(ext) for ext in ['.png', '.jpg', '.jpeg', '.bmp', '.gif']):
                    item.setForeground(QColor(0, 0, 255))  # 蓝色表示图像文件

                self.file_list_widget.addItem(item)

                # 每添加50个文件就更新UI
                if i % 50 == 0:
                    QApplication.processEvents()

        finally:
            self.file_list_widget.blockSignals(False)

        # 更新缓存
        if self.file_loader:
            self.remote_files_cache.update(self.file_loader.remote_files_cache)

        # 更新文件计数
        displayed_count = len(self.displayed_files)
        total_count = len(self.file_loader.all_files) if self.file_loader and self.file_loader.all_files else 0
        self.file_count_label.setText(f"已显示 {displayed_count}/{total_count} 个文件")
        QApplication.processEvents()

    def on_files_load_complete(self, total_files):
        """文件加载完成"""
        # 重新启用界面更新
        self.file_list_widget.setUpdatesEnabled(True)

        if total_files == 0:
            self.status_label.setText("未找到符合条件的文件")
            QMessageBox.information(self, "提示", "未找到符合条件的文件")
        else:
            self.status_label.setText(f"文件加载完成，共 {total_files} 个文件")

    def on_load_progress(self, loaded, total):
        """加载进度更新"""
        if total > 0:
            percent = int((loaded / total) * 100)
            self.load_progress_label.setText(f"加载进度: {percent}%")
            self.status_label.setText(f"正在加载文件... {loaded}/{total}")

    def on_load_error(self, error_msg):
        """加载错误"""
        # 重新启用界面更新
        self.file_list_widget.setUpdatesEnabled(True)
        QMessageBox.critical(self, "错误", f"加载文件失败: {error_msg}")
        self.status_label.setText(f"加载失败: {error_msg}")

    def optimized_select_all_files(self):
        """优化版全选文件 - 使用延迟选择"""
        if self.file_list_widget.count() == 0:
            return

        self.status_label.setText("正在全选文件...")
        QApplication.processEvents()

        # 临时禁用界面更新以提高性能
        self.file_list_widget.setUpdatesEnabled(False)

        # 对于大量文件，使用分批选择
        total_items = self.file_list_widget.count()
        batch_size = 100

        # 阻塞信号，避免每次选择都触发事件
        self.file_list_widget.blockSignals(True)

        try:
            for i in range(0, total_items, batch_size):
                end_idx = min(i + batch_size, total_items)

                for j in range(i, end_idx):
                    item = self.file_list_widget.item(j)
                    if not item.isHidden():
                        item.setSelected(True)

                # 每处理一批就更新UI
                if i % 500 == 0:
                    self.status_label.setText(f"全选进度: {end_idx}/{total_items}")
                    QApplication.processEvents()

        finally:
            self.file_list_widget.blockSignals(False)
            self.file_list_widget.setUpdatesEnabled(True)  # 重新启用界面更新
            self.file_list_widget.itemSelectionChanged.emit()

        self.status_label.setText(f"已全选 {total_items} 个文件")
        self.update_file_counts()

    def on_ip_selected(self):
        """IP选择事件"""
        selected_items = self.ip_list_widget.selectedItems()
        if selected_items:
            self.current_target_ip = selected_items[0].text()
        else:
            self.current_target_ip = None

    def add_ip(self):
        """添加IP到列表"""
        ip = self.ip_input.text().strip()
        if ip and self.validate_ip(ip):
            if ip not in self.target_ips:
                self.target_ips.append(ip)
                self.ip_list_widget.addItem(ip)
                self.ip_input.clear()
                self.status_label.setText(f"已添加IP: {ip}")
            else:
                QMessageBox.warning(self, "提示", "该IP已存在列表中")
        else:
            QMessageBox.warning(self, "错误", "请输入有效的IP地址")

    def remove_ip(self):
        """从列表删除选中的IP"""
        selected_items = self.ip_list_widget.selectedItems()
        if not selected_items:
            return

        for item in selected_items:
            ip = item.text()
            if ip in self.target_ips:
                self.target_ips.remove(ip)
            self.ip_list_widget.takeItem(self.ip_list_widget.row(item))
            self.status_label.setText(f"已删除IP: {ip}")

    def clear_ips(self):
        """清空IP列表"""
        self.target_ips.clear()
        self.ip_list_widget.clear()
        self.current_target_ip = None
        self.status_label.setText("已清空IP列表")

    def apply_filter(self):
        """应用文件后缀筛选"""
        ext_text = self.ext_input.text().strip()
        if not ext_text:
            return

        extensions = [ext.strip().lower() for ext in ext_text.split(',') if ext.strip()]
        self.extensions = extensions

        # 筛选文件
        self.file_list_widget.blockSignals(True)
        try:
            for i in range(self.file_list_widget.count()):
                item = self.file_list_widget.item(i)
                filename = item.data(Qt.UserRole) if item.data(Qt.UserRole) else item.text()

                if filename is None:
                    item.setHidden(True)
                    continue

                should_show = False
                for ext in self.extensions:
                    if filename.lower().endswith(ext.lower()):
                        should_show = True
                        break

                item.setHidden(not should_show)
        finally:
            self.file_list_widget.blockSignals(False)

        # 统计显示的文件数量
        visible_count = sum(
            1 for i in range(self.file_list_widget.count()) if not self.file_list_widget.item(i).isHidden())
        self.status_label.setText(f"显示 {visible_count} 个文件")
        self.update_file_counts()

    def reset_filter(self):
        """重置筛选"""
        self.ext_input.setText(".png,.jpg,.jpeg,.bmp,.tiff,.gif,.json")
        self.extensions = ['.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.gif', '.json']
        self.apply_filter()

    def select_none_files(self):
        """全不选文件"""
        self.file_list_widget.blockSignals(True)
        try:
            for i in range(self.file_list_widget.count()):
                self.file_list_widget.item(i).setSelected(False)
        finally:
            self.file_list_widget.blockSignals(False)
            self.file_list_widget.itemSelectionChanged.emit()

    def update_file_counts(self):
        """更新文件计数"""
        total_count = sum(
            1 for i in range(self.file_list_widget.count()) if not self.file_list_widget.item(i).isHidden())
        selected_count = len([item for item in self.file_list_widget.selectedItems() if not item.isHidden()])

        if self.mode == "distribution":
            self.file_count_label.setText(f"已显示 {total_count} 个文件，选中 {selected_count} 个")
        else:
            self.file_count_label.setText(f"已显示 {total_count} 个远程文件，选中 {selected_count} 个")

    def validate_ip(self, ip):
        """验证IP地址格式"""
        try:
            parts = ip.split('.')
            if len(parts) != 4:
                return False
            for part in parts:
                if not 0 <= int(part) <= 255:
                    return False
            return True
        except:
            return False

    def get_selected_ips(self):
        """获取选中的IP"""
        selected_ips = []
        for item in self.ip_list_widget.selectedItems():
            ip = item.text()
            if ip in self.target_ips:
                selected_ips.append(ip)
        return selected_ips

    def get_selected_files(self):
        """获取选中的文件 - 修复版"""
        selected_files = []

        for i in range(self.file_list_widget.count()):
            item = self.file_list_widget.item(i)
            if not item.isHidden() and item.isSelected():
                filename = item.data(Qt.UserRole) if item.data(Qt.UserRole) else item.text()
                # 清理可能的额外信息（如文件大小信息）
                if self.mode == "reverse" and " (" in filename:
                    filename = filename.split(" (")[0]
                selected_files.append(filename)

        print(f"get_selected_files 返回: {selected_files}")
        return selected_files

    def get_config(self):
        """获取传输配置"""
        if self.mode == "distribution":
            return self._get_distribution_config()
        else:
            return self._get_reverse_config()

    def _get_distribution_config(self):
        """获取分发配置 - 修复版"""
        selected_file_names = self.get_selected_files()
        selected_files = []

        # 调试信息：打印选中的文件名
        print(f"选中的文件名: {selected_file_names}")
        print(f"缓存中的文件: {list(self.remote_files_cache.keys())[:10] if self.remote_files_cache else '空'}")

        if self.parent() and hasattr(self.parent(), 'current_folder'):
            folder = self.parent().current_folder
            print(f"当前文件夹: {folder}")

            # 方法1：首先尝试从缓存中获取完整路径
            for filename in selected_file_names:
                if filename in self.remote_files_cache:
                    cache_entry = self.remote_files_cache.get(filename)
                    if cache_entry and 'path' in cache_entry:
                        file_path = cache_entry['path']
                        if os.path.exists(file_path):
                            selected_files.append(file_path)
                            print(f"从缓存获取路径: {file_path}")
                            continue

                # 方法2：如果缓存中没有，尝试使用当前文件夹构建路径
                file_path = os.path.join(folder, filename)
                if os.path.exists(file_path):
                    selected_files.append(file_path)
                    print(f"从文件夹构建路径: {file_path}")
                else:
                    # 方法3：尝试查找实际文件
                    # 如果文件名包含路径信息，直接使用
                    if os.path.sep in filename:
                        if os.path.exists(filename):
                            selected_files.append(filename)
                            print(f"直接使用完整路径: {filename}")

                    # 在文件夹中搜索匹配的文件
                    for root, dirs, files in os.walk(folder):
                        for file in files:
                            if file == filename:
                                found_path = os.path.join(root, file)
                                selected_files.append(found_path)
                                print(f"搜索到文件: {found_path}")
                                break
        else:
            print("警告: 没有获取到父窗口或当前文件夹")
            # 尝试直接使用选中的文件名作为路径
            for filename in selected_file_names:
                if os.path.exists(filename):
                    selected_files.append(filename)
                    print(f"直接使用文件路径: {filename}")

        # 调试信息：打印找到的文件路径
        print(f"最终选中的文件数: {len(selected_files)}")
        for i, file_path in enumerate(selected_files[:5]):  # 只打印前5个
            print(f"  {i + 1}. {file_path}")
        if len(selected_files) > 5:
            print(f"  ... 还有 {len(selected_files) - 5} 个文件")

        # 获取选中的IP而不是所有IP
        selected_ips = []
        for item in self.ip_list_widget.selectedItems():
            ip = item.text()
            if ip in self.target_ips:
                selected_ips.append(ip)

        # 如果没有选中任何IP，则使用所有IP
        if not selected_ips:
            selected_ips = self.target_ips.copy()

        # 计算分发方式
        file_groups = {}
        if self.even_distribution_check.isChecked() and selected_ips:
            file_lists = AnnotationUtils.split_list_evenly(selected_files, len(selected_ips))
            for i, ip in enumerate(selected_ips):
                if i < len(file_lists):
                    file_groups[ip] = file_lists[i]
                else:
                    file_groups[ip] = []
        else:
            for ip in selected_ips:
                file_groups[ip] = selected_files.copy()

        return {
            'mode': 'distribution',
            'target_ips': selected_ips,
            'selected_files': selected_files,
            'file_groups': file_groups,
            'overwrite': self.overwrite_check.isChecked(),
            'even_distribution': self.even_distribution_check.isChecked(),
            'skip_sent': self.skip_sent_check.isChecked(),
            'concurrent': self.concurrent_check.isChecked(),
            'concurrent_threads': self.concurrent_threads.value() if hasattr(self, 'concurrent_threads') else 10,
            'extensions': self.extensions
        }

    def _get_reverse_config(self):
        """获取回传配置"""
        selected_file_names = self.get_selected_files()

        # 获取远程文件信息
        selected_files_info = []
        for filename in selected_file_names:
            if filename in self.remote_files_cache:
                selected_files_info.append({
                    'name': filename,
                    'path': self.remote_files_cache[filename]['path'],
                    'size': self.remote_files_cache[filename]['size']
                })
        
        # 获取选中的IP，如果没有选中则使用第一个IP
        selected_ips = self.get_selected_ips()
        target_ip = selected_ips[0] if selected_ips else self.current_target_ip
        
        # 如果还是没有目标IP，尝试从IP列表中获取第一个
        if not target_ip and self.target_ips:
            target_ip = self.target_ips[0]

        return {
            'mode': 'reverse',
            'target_ip': target_ip,
            'selected_files': selected_file_names,
            'selected_files_info': selected_files_info,
            'remote_files_cache': self.remote_files_cache,
            'overwrite': self.overwrite_check.isChecked(),
            'delete_after_transfer': self.delete_after_transfer.isChecked() if hasattr(self,
                                                                                       'delete_after_transfer') else False
        }

    def accept(self):
        """对话框接受时保存IP列表到主窗口"""
        if self.mode == "reverse":
            # 获取选中的IP进行检查
            selected_ips = self.get_selected_ips()
            target_ip = selected_ips[0] if selected_ips else self.current_target_ip
            
            # 如果还是没有目标IP，尝试从IP列表中获取第一个
            if not target_ip and self.target_ips:
                target_ip = self.target_ips[0]
                
            if not target_ip:
                QMessageBox.warning(self, "警告", "请选择目标IP")
                return

        if self.mode == "reverse" and not self.get_selected_files():
            QMessageBox.warning(self, "警告", "请选择要回传的文件")
            return

        if self.mode == "distribution" and not self.target_ips:
            QMessageBox.warning(self, "警告", "请添加至少一个目标IP")
            return

        if self.mode == "distribution" and not self.get_selected_files():
            QMessageBox.warning(self, "警告", "请选择要分发的文件")
            return

        if self.parent() and hasattr(self.parent(), 'saved_ips'):
            # 合并IP列表，避免重复
            for ip in self.target_ips:
                if ip not in self.parent().saved_ips:
                    self.parent().saved_ips.append(ip)

        # 停止加载线程
        if self.file_loader and self.file_loader.isRunning():
            self.file_loader.cancel()
            self.file_loader.wait(500)

        super().accept()

    def closeEvent(self, event):
        """关闭事件 - 清理资源"""
        # 停止加载线程
        if self.file_loader and self.file_loader.isRunning():
            self.file_loader.cancel()
            self.file_loader.wait(1000)

        super().closeEvent(event)


class DistributionWorker(QThread):
    """分发工作线程 - 优化版：支持并发传输和连接复用"""

    progress_update = Signal(int, int, str)
    file_sent = Signal(str, str, bool, str)
    distribution_complete = Signal(dict)
    reverse_transfer_started = Signal(str, list)
    reverse_transfer_complete = Signal(str, dict)

    def __init__(self, config, parent=None):
        super().__init__(parent)
        self.config = config
        self.cancel_flag = False
        self._lock = threading.Lock()

    def run(self):
        """执行分发任务"""
        try:
            if self.config.get('mode') == 'distribution':
                self._run_distribution_optimized()
            elif self.config.get('mode') == 'reverse':
                self._run_reverse_transfer_optimized()
        except Exception as e:
            self.progress_update.emit(0, 0, f"传输出错: {str(e)}")
            traceback.print_exc()

    def _run_distribution_optimized(self):
        """执行分发 - 优化版本：并发传输"""
        target_ips = self.config.get('target_ips', [])
        file_groups = self.config.get('file_groups', {})
        total_tasks = sum(len(files) for files in file_groups.values())
        completed_tasks = 0
        overwrite = self.config.get('overwrite', True)
        concurrent = self.config.get('concurrent', True)
        concurrent_threads = self.config.get('concurrent_threads', 10)

        self.progress_update.emit(0, total_tasks, f"开始分发 {total_tasks} 个文件到 {len(target_ips)} 个目标...")

        results = {
            'total_success': 0,
            'total_fail': 0,
            'ip_results': {},
            'distributed_files': []
        }

        for ip_index, ip in enumerate(target_ips):
            if self.cancel_flag:
                break

            files_for_ip = file_groups.get(ip, [])
            if not files_for_ip:
                continue

            ip_success = 0
            ip_fail = 0

            self.progress_update.emit(
                completed_tasks,
                total_tasks,
                f"正在分发到 {ip} ({ip_index + 1}/{len(target_ips)})"
            )

            if concurrent and len(files_for_ip) > 1:
                # 并发批量上传
                upload_results = LANFileClient.upload_files_batch(
                    ip,
                    files_for_ip,
                    client_name=self.config.get('client_name', '标注工具客户端'),
                    overwrite=overwrite
                )

                for file_path, result in upload_results.items():
                    filename = os.path.basename(file_path)

                    if self.cancel_flag:
                        break

                    if result.get('status') == 'success':
                        ip_success += 1
                        info_msg = "（覆盖）" if result.get('overwritten', False) else ""
                        self.file_sent.emit(filename, ip, True, info_msg)
                        results['distributed_files'].append(filename)
                    else:
                        ip_fail += 1
                        error_msg = result.get('error', '未知错误')
                        info_msg = f"（失败: {error_msg}）"
                        self.file_sent.emit(filename, ip, False, info_msg)

                    completed_tasks += 1
                    self.progress_update.emit(
                        completed_tasks,
                        total_tasks,
                        f"{ip}: {filename}{info_msg} ({completed_tasks}/{total_tasks})"
                    )
            else:
                # 串行上传（兼容模式）
                for file_path in files_for_ip:
                    if self.cancel_flag:
                        break

                    filename = os.path.basename(file_path)
                    result = LANFileClient.upload_file(
                        ip,
                        file_path,
                        client_name=self.config.get('client_name', '标注工具客户端'),
                        overwrite=overwrite
                    )

                    info_msg = ""
                    if result:
                        if result.get('status') == 'success':
                            ip_success += 1
                            if result.get('overwritten', False):
                                info_msg = "（覆盖）"
                            self.file_sent.emit(filename, ip, True, info_msg)
                            results['distributed_files'].append(filename)
                        else:
                            ip_fail += 1
                            error_msg = result.get('error', '未知错误')
                            info_msg = f"（失败: {error_msg}）"
                            self.file_sent.emit(filename, ip, False, info_msg)
                    else:
                        ip_fail += 1
                        info_msg = "（失败: 无响应）"
                        self.file_sent.emit(filename, ip, False, info_msg)

                    completed_tasks += 1
                    self.progress_update.emit(
                        completed_tasks,
                        total_tasks,
                        f"{ip}: {filename}{info_msg} ({completed_tasks}/{total_tasks})"
                    )

            with self._lock:
                results['ip_results'][ip] = {
                    'success': ip_success,
                    'fail': ip_fail,
                    'total': len(files_for_ip)
                }
                results['total_success'] += ip_success
                results['total_fail'] += ip_fail

        if not self.cancel_flag:
            self.progress_update.emit(total_tasks, total_tasks, "分发完成！")
            self.distribution_complete.emit(results)
        else:
            self.progress_update.emit(completed_tasks, total_tasks, "分发已取消！")

    def _run_reverse_transfer_optimized(self):
        """执行回传 - 优化版本：批量并发下载"""
        target_ip = self.config.get('target_ip')
        selected_files = self.config.get('selected_files', [])
        selected_files_info = self.config.get('selected_files_info', [])
        overwrite = self.config.get('overwrite', True)

        if not target_ip:
            self.progress_update.emit(0, 0, "错误: 未指定目标IP")
            return

        total_files = len(selected_files)
        if total_files == 0:
            self.progress_update.emit(0, 0, "错误: 未选择文件")
            return

        self.progress_update.emit(0, total_files, f"开始从 {target_ip} 回传 {total_files} 个文件...")

        results = {
            'total_success': 0,
            'total_fail': 0,
            'files': []
        }

        # 获取当前打开的文件夹
        if self.parent() and hasattr(self.parent(), 'current_folder'):
            local_folder = self.parent().current_folder
        else:
            # 如果主窗口没有打开文件夹，使用当前工作目录
            local_folder = os.getcwd()

        if not local_folder or not os.path.exists(local_folder):
            os.makedirs(local_folder, exist_ok=True)

        # 批量并发下载
        download_results = LANFileClient.download_files_batch(target_ip, selected_files, local_folder)

        for i, filename in enumerate(selected_files):
            if self.cancel_flag:
                break

            result = download_results.get(filename, {})
            success = result.get('success', False)

            if success:
                with self._lock:
                    results['total_success'] += 1
                    results['files'].append({"filename": filename, "status": "success"})
                self.file_sent.emit(filename, target_ip, True, "（下载成功）")
            else:
                with self._lock:
                    results['total_fail'] += 1
                    results['files'].append({"filename": filename, "status": "fail", "error": result.get('error')})
                self.file_sent.emit(filename, target_ip, False, f"（下载失败: {result.get('error', '未知错误')}）")

            self.progress_update.emit(i + 1, total_files, f"回传进度: {i + 1}/{total_files}")

        if not self.cancel_flag:
            self.progress_update.emit(total_files, total_files,
                                      f"回传完成！成功: {results['total_success']}, 失败: {results['total_fail']}")
            self.distribution_complete.emit(results)
        else:
            self.progress_update.emit(results['total_success'] + results['total_fail'], total_files, "回传已取消")

    def cancel(self):
        """取消分发"""
        self.cancel_flag = True


class TransferProgressDialog(QDialog):
    """传输进度对话框 - 用于分发和回传"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("传输进度")
        self.resize(700, 600)

        self.worker = None
        self.init_ui()

    def init_ui(self):
        """初始化UI"""
        layout = QVBoxLayout(self)

        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        layout.addWidget(self.progress_bar)

        self.status_label = QLabel("准备开始传输...")
        layout.addWidget(self.status_label)

        self.details_text = QTextEdit()
        self.details_text.setReadOnly(True)
        self.details_text.setStyleSheet("font-family: 'Courier New'; font-size: 10pt;")
        layout.addWidget(self.details_text)

        button_layout = QHBoxLayout()
        self.cancel_btn = QPushButton("取消")
        self.cancel_btn.clicked.connect(self.cancel_transfer)
        self.close_btn = QPushButton("关闭")
        self.close_btn.clicked.connect(self.close)
        self.close_btn.setEnabled(False)

        button_layout.addWidget(self.cancel_btn)
        button_layout.addWidget(self.close_btn)
        layout.addLayout(button_layout)

    def set_worker(self, worker):
        """设置工作线程"""
        self.worker = worker

        worker.progress_update.connect(self.update_progress)
        worker.file_sent.connect(self.add_file_log)
        worker.distribution_complete.connect(self.transfer_complete)
        worker.finished.connect(self.worker_finished)

    def update_progress(self, current, total, message):
        """更新进度"""
        if total > 0:
            progress = int((current / total) * 100)
            self.progress_bar.setValue(progress)

        self.status_label.setText(message)
        self.details_text.append(f"[{datetime.now().strftime('%H:%M:%S')}] {message}")

        scrollbar = self.details_text.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())

    def add_file_log(self, filename, ip, success, info=""):
        """添加文件传输日志"""
        status = "✓ 成功" if success else "✗ 失败"
        color = "green" if success else "red"
        self.details_text.append(
            f'<font color="{color}">[{datetime.now().strftime("%H:%M:%S")}] {filename} -> {ip}: {status} {info}</font>')

        scrollbar = self.details_text.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())

    def transfer_complete(self, results):
        """传输完成"""
        total_success = results.get('total_success', 0)
        total_fail = results.get('total_fail', 0)
        total = total_success + total_fail

        self.details_text.append(f"\n{'=' * 50}")
        self.details_text.append("<b>=== 传输完成 ===</b>")
        self.details_text.append(f"总计文件数: {total}")
        self.details_text.append(f"<font color='green'>成功: {total_success}</font>")
        self.details_text.append(f"<font color='red'>失败: {total_fail}</font>")

        if 'ip_results' in results:
            self.details_text.append("\n<b>各IP传输结果:</b>")
            for ip, ip_result in results['ip_results'].items():
                success_rate = (ip_result['success'] / ip_result['total'] * 100) if ip_result['total'] > 0 else 0
                color = "green" if success_rate == 100 else "orange" if success_rate >= 50 else "red"
                self.details_text.append(
                    f'  <font color="{color}">{ip}: 成功 {ip_result["success"]}/{ip_result["total"]} ({success_rate:.1f}%)</font>')

        self.status_label.setText(f"传输完成！成功: {total_success}, 失败: {total_fail}")
        self.progress_bar.setValue(100)

        scrollbar = self.details_text.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())

    def worker_finished(self):
        """工作线程完成"""
        self.cancel_btn.setEnabled(False)
        self.close_btn.setEnabled(True)

    def cancel_transfer(self):
        """取消传输"""
        if self.worker:
            self.worker.cancel()
            self.details_text.append(
                f"<font color='orange'>[{datetime.now().strftime('%H:%M:%S')}] 用户取消传输</font>")
            self.status_label.setText("传输已取消")

    def closeEvent(self, event):
        """关闭事件"""
        if self.worker and self.worker.isRunning():
            reply = QMessageBox.question(
                self,
                "确认关闭",
                "传输正在进行中，确认要关闭吗？",
                QMessageBox.Yes | QMessageBox.No
            )

            if reply == QMessageBox.Yes:
                self.worker.cancel()
                event.accept()
            else:
                event.ignore()
        else:
            event.accept()