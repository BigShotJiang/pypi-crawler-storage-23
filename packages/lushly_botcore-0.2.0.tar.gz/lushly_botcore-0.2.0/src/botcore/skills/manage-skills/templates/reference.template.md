# {Reference Topic}

{Brief introduction explaining what this reference covers.}

## Overview

{High-level explanation of the topic.}

## Patterns

### Pattern 1: {Name}

{When to use this pattern.}

```{language}
// Example implementation
```

### Pattern 2: {Name}

{When to use this pattern.}

```{language}
// Example implementation
```

## Common Issues

| Issue | Cause | Fix |
|-------|-------|-----|
| {Problem} | {Why it happens} | {How to fix} |

## Best Practices

- {Practice 1}
- {Practice 2}
- {Practice 3}

## Related

- [{Related topic}]({path-to-related}.md)
