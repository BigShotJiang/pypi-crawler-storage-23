import asyncio
import os
import shutil
import re
from getpass import getpass

# --- LIBRARY UTAMA ---
import httpx
import img2pdf
from playwright.async_api import async_playwright

# --- IMPORT MODUL TETANGGA (SAFE IMPORT) ---
# Ini menjaga script tetap jalan meskipun dijalankan tanpa struktur folder src/utils yang lengkap
from utils.logger import Logger as log
from utils.helper import clear_screen, prepare_directories, collect_images_recursive, format_login_id
from utils.scraper import get_chapter_list

# --- IMPORT CORE ENGINE KITA ---
# Pastikan folder 'core' ada sejajar file ini
try:
    from core.auth import RBVAuth        # Engine Login SSO
    from core.network import RBVDownloader # Engine Download HTTPX
except ImportError:
    print("Error: Folder 'core/' not found!")
    exit()

class RBVEngine:
    def __init__(self):
        self.base_dir = ""
        self.temp_dir = ""
        self.cookies = None

    async def start(self, username="057136542", password="@SalutAR13022006", kode_mk="EKMA5101"):
        clear_screen()
        print("==========================================")
        print("   RBV DOWNLOADER CLI - PYTHON EDITION    ")
        print("==========================================")

        # 1. INPUT DATA
        if not username:
            username = input("NIM / Email UT : ")
            username = format_login_id(username)
        if not password:
            password = getpass("Password : ")
        if not kode_mk:
            kode_mk = input("Kode MK (e,g. : DAPU6209): : ").upper()
        
        # Siapkan folder output & temp
        self.base_dir, self.temp_dir = prepare_directories(kode_mk)

        # 2. LOGIN PHASE (Playwright)
        log.log("Initiating Secure Login sequence...", "info")
        auth = RBVAuth(username, password)
        # Override URL target biar setelah login langsung ke buku yang dituju
        auth.target_url = f"https://pustaka.ut.ac.id/reader/index.php?modul={kode_mk}"
        
        self.cookies = await auth.get_cookies()
        if not self.cookies:
            log.log("Login Failed! Aborting.", "error")
            return

        # 3. METADATA PHASE (Ambil Daftar Bab)
        chapters = []
        log.log("🔍 Fetching Module Metadata...", "info")
        
        async with async_playwright() as p:
            browser = await p.chromium.launch(
                headless=True,
                args=[
                    "--no-sandbox", 
                    "--disable-setuid-sandbox", 
                    "--disable-dev-shm-usage", 
                    "--disable-gpu"
                    ] 
                )
            context = await browser.new_context()

            # Inject cookie hasil login tadi
            await context.add_cookies([
                {'name': k, 'value': v, 'domain': 'pustaka.ut.ac.id', 'path': '/'} 
                for k, v in self.cookies.items()
            ])
            
            page = await context.new_page()
            try:
                await page.goto(f"https://pustaka.ut.ac.id/reader/index.php?modul={kode_mk}", timeout=60000)
                chapters = await get_chapter_list(page)
            except Exception as e:
                log.log(f"Error accessing page: {e}", "error")

            # Fallback kalau gagal scrape sidebar, kita tebak aja M1-M12
            if not chapters:
                log.log("Failed to read sidebar", "warn")
                await browser.close()
                return
            
            await browser.close()    

        log.log(f"Found {len(chapters)} Chapters. Switching to Turbo Engine.", "success")

        # 4. DOWNLOAD PHASE (HTTPX Turbo)
        downloader = RBVDownloader(self.cookies)
        downloader.resolution = "800" # Resolusi HD

        for idx, bab in enumerate(chapters):
            doc_id = bab['id'].replace('.pdf', '')
            log.log(f"\n⚡ Processing: {bab['label']} (ID: {doc_id})", "info")

            # Folder khusus per bab di dalam temp
            bab_dir = os.path.join(self.temp_dir, doc_id)
            if not os.path.exists(bab_dir):
                os.makedirs(bab_dir)

            # --- LOGIKA DOWNLOAD PARALEL PINTAR ---
            concurrency = 5 # Jangan rakus, 5 aja biar error nabraknya ga kebanyakan
            page_num = 1
            total_downloaded = 0
            end_of_module = False

            while not end_of_module:
                batch_indices = range(page_num, page_num + concurrency)
                # Tembak langsung tanpa function pembungkus closure yang ribet
                tasks = [downloader.download_page(doc_id, f"{kode_mk}/", p, bab_dir) for p in batch_indices]
                
                results = await asyncio.gather(*tasks)
                
                for r in results:
                    if r:
                        total_downloaded += 1
                    else:
                        # Ketemu False (halaman ga ada), langsung pasang rem blong!
                        end_of_module = True 
                
                page_num += concurrency
            
            log.log(f" -> Downloaded {total_downloaded} pages.", "success")

        # 5. PDF COMPILATION
        log.log("\n📦 Compiling Full PDF...", "info")
        
        # Kumpulkan semua gambar dari semua folder bab
        all_images = collect_images_recursive(self.temp_dir)

        if all_images:
            output_pdf = os.path.join(self.base_dir, f"{kode_mk}-FullBook-HD.pdf")
            try:
                with open(output_pdf, "wb") as f:
                    f.write(img2pdf.convert(all_images))
                log.log(f"SUCCESS! File saved to: {output_pdf}", "success")
                
                # Cleanup temp folder
                try:
                    shutil.rmtree(self.temp_dir)
                except:
                    pass
            except Exception as e:
                log.log(f"PDF Error: {e}", "error")
        else:
            log.log("Zonk. No images were downloaded successfully.", "error")

# --- MAIN RUNNER ---
def main_entry():
    try:
        engine = RBVEngine()
        asyncio.run(engine.start())
    except KeyboardInterrupt:
        print("\nBye.")
    except Exception as e:
        print(f"\nCritical Error: {e}")

if __name__ == "__main__":
    main_entry()
