from .rxml import *

__doc__ = rxml.__doc__
if hasattr(rxml, "__all__"):
    __all__ = rxml.__all__