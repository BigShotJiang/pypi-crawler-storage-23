"""AgentBaton — Task coordination for AI agents."""
__version__ = "0.0.1"
