"""Entry point for running as a module: python -m openrag_mcp"""

from openrag_mcp.server import main

if __name__ == "__main__":
    main()

