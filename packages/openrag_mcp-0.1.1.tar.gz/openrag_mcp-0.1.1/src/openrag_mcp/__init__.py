"""OpenRAG MCP Server - Expose OpenRAG capabilities via Model Context Protocol."""

from openrag_mcp.server import main

__version__ = "0.1.0"
__all__ = ["main"]

