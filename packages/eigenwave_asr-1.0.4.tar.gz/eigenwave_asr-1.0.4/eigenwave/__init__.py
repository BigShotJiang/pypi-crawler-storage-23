"""
EigenWave-ASR: High-Performance Speech Recognition
===================================================

A novel ASR model using Multi-Scale Robin Features with 
mathematical differential operators for speech recognition.

Usage:
    from eigenwave import EigenWaveASR
    
    model = EigenWaveASR.from_pretrained("sakibhasan/eigenwave-asr")
    text = model.transcribe("audio.wav")
    
    # Or batch transcription
    texts = model.transcribe(["audio1.wav", "audio2.wav"])
"""

__version__ = "1.0.4"
__author__ = "Sakib Hasan"

from .model import EigenWaveASR

__all__ = ["EigenWaveASR"]
