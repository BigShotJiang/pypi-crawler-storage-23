"""HeyDucky — your AI rubber duck that actually talks back."""

__version__ = "0.1.0"
