"""PySide6 GUI for the HeyDucky remote agent."""
