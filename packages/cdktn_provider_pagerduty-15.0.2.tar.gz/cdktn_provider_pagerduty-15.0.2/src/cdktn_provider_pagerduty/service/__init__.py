r'''
# `pagerduty_service`

Refer to the Terraform Registry for docs: [`pagerduty_service`](https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service).
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import cdktn as _cdktn_78ede62e
import constructs as _constructs_77d1e7e8


class Service(
    _cdktn_78ede62e.TerraformResource,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-pagerduty.service.Service",
):
    '''Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service pagerduty_service}.'''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id_: builtins.str,
        *,
        escalation_policy: builtins.str,
        name: builtins.str,
        acknowledgement_timeout: typing.Optional[builtins.str] = None,
        alert_creation: typing.Optional[builtins.str] = None,
        alert_grouping: typing.Optional[builtins.str] = None,
        alert_grouping_parameters: typing.Optional[typing.Union["ServiceAlertGroupingParameters", typing.Dict[builtins.str, typing.Any]]] = None,
        alert_grouping_timeout: typing.Optional[builtins.str] = None,
        auto_pause_notifications_parameters: typing.Optional[typing.Union["ServiceAutoPauseNotificationsParameters", typing.Dict[builtins.str, typing.Any]]] = None,
        auto_resolve_timeout: typing.Optional[builtins.str] = None,
        description: typing.Optional[builtins.str] = None,
        id: typing.Optional[builtins.str] = None,
        incident_urgency_rule: typing.Optional[typing.Union["ServiceIncidentUrgencyRule", typing.Dict[builtins.str, typing.Any]]] = None,
        response_play: typing.Optional[builtins.str] = None,
        scheduled_actions: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["ServiceScheduledActions", typing.Dict[builtins.str, typing.Any]]]]] = None,
        support_hours: typing.Optional[typing.Union["ServiceSupportHours", typing.Dict[builtins.str, typing.Any]]] = None,
        connection: typing.Optional[typing.Union[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.WinrmProvisionerConnection", typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]] = None,
        depends_on: typing.Optional[typing.Sequence["_cdktn_78ede62e.ITerraformDependable"]] = None,
        for_each: typing.Optional["_cdktn_78ede62e.ITerraformIterator"] = None,
        lifecycle: typing.Optional[typing.Union["_cdktn_78ede62e.TerraformResourceLifecycle", typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union["_cdktn_78ede62e.FileProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.LocalExecProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.RemoteExecProvisioner", typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service pagerduty_service} Resource.

        :param scope: The scope in which to define this construct.
        :param id_: The scoped construct ID. Must be unique amongst siblings in the same scope
        :param escalation_policy: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#escalation_policy Service#escalation_policy}.
        :param name: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#name Service#name}.
        :param acknowledgement_timeout: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#acknowledgement_timeout Service#acknowledgement_timeout}.
        :param alert_creation: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#alert_creation Service#alert_creation}.
        :param alert_grouping: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#alert_grouping Service#alert_grouping}.
        :param alert_grouping_parameters: alert_grouping_parameters block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#alert_grouping_parameters Service#alert_grouping_parameters}
        :param alert_grouping_timeout: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#alert_grouping_timeout Service#alert_grouping_timeout}.
        :param auto_pause_notifications_parameters: auto_pause_notifications_parameters block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#auto_pause_notifications_parameters Service#auto_pause_notifications_parameters}
        :param auto_resolve_timeout: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#auto_resolve_timeout Service#auto_resolve_timeout}.
        :param description: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#description Service#description}.
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#id Service#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param incident_urgency_rule: incident_urgency_rule block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#incident_urgency_rule Service#incident_urgency_rule}
        :param response_play: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#response_play Service#response_play}.
        :param scheduled_actions: scheduled_actions block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#scheduled_actions Service#scheduled_actions}
        :param support_hours: support_hours block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#support_hours Service#support_hours}
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cc4da8f47ccee2051f4ca2cb9f745f53712597cde58ee2b81c8e21963f48c79d)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id_", value=id_, expected_type=type_hints["id_"])
        config = ServiceConfig(
            escalation_policy=escalation_policy,
            name=name,
            acknowledgement_timeout=acknowledgement_timeout,
            alert_creation=alert_creation,
            alert_grouping=alert_grouping,
            alert_grouping_parameters=alert_grouping_parameters,
            alert_grouping_timeout=alert_grouping_timeout,
            auto_pause_notifications_parameters=auto_pause_notifications_parameters,
            auto_resolve_timeout=auto_resolve_timeout,
            description=description,
            id=id,
            incident_urgency_rule=incident_urgency_rule,
            response_play=response_play,
            scheduled_actions=scheduled_actions,
            support_hours=support_hours,
            connection=connection,
            count=count,
            depends_on=depends_on,
            for_each=for_each,
            lifecycle=lifecycle,
            provider=provider,
            provisioners=provisioners,
        )

        jsii.create(self.__class__, self, [scope, id_, config])

    @jsii.member(jsii_name="generateConfigForImport")
    @builtins.classmethod
    def generate_config_for_import(
        cls,
        scope: "_constructs_77d1e7e8.Construct",
        import_to_id: builtins.str,
        import_from_id: builtins.str,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
    ) -> "_cdktn_78ede62e.ImportableResource":
        '''Generates CDKTN code for importing a Service resource upon running "cdktn plan ".

        :param scope: The scope in which to define this construct.
        :param import_to_id: The construct id used in the generated config for the Service to import.
        :param import_from_id: The id of the existing Service that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#import import section} in the documentation of this resource for the id to use
        :param provider: ? Optional instance of the provider where the Service to import is found.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__865b6617bd4df9b5dcc7c7a4c3b4251917372e44c845d4811f98d975297ccf0c)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument import_to_id", value=import_to_id, expected_type=type_hints["import_to_id"])
            check_type(argname="argument import_from_id", value=import_from_id, expected_type=type_hints["import_from_id"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
        return typing.cast("_cdktn_78ede62e.ImportableResource", jsii.sinvoke(cls, "generateConfigForImport", [scope, import_to_id, import_from_id, provider]))

    @jsii.member(jsii_name="putAlertGroupingParameters")
    def put_alert_grouping_parameters(
        self,
        *,
        config: typing.Optional[typing.Union["ServiceAlertGroupingParametersConfig", typing.Dict[builtins.str, typing.Any]]] = None,
        type: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param config: config block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#config Service#config}
        :param type: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#type Service#type}.
        '''
        value = ServiceAlertGroupingParameters(config=config, type=type)

        return typing.cast(None, jsii.invoke(self, "putAlertGroupingParameters", [value]))

    @jsii.member(jsii_name="putAutoPauseNotificationsParameters")
    def put_auto_pause_notifications_parameters(
        self,
        *,
        enabled: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        timeout: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param enabled: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#enabled Service#enabled}.
        :param timeout: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#timeout Service#timeout}.
        '''
        value = ServiceAutoPauseNotificationsParameters(
            enabled=enabled, timeout=timeout
        )

        return typing.cast(None, jsii.invoke(self, "putAutoPauseNotificationsParameters", [value]))

    @jsii.member(jsii_name="putIncidentUrgencyRule")
    def put_incident_urgency_rule(
        self,
        *,
        type: builtins.str,
        during_support_hours: typing.Optional[typing.Union["ServiceIncidentUrgencyRuleDuringSupportHours", typing.Dict[builtins.str, typing.Any]]] = None,
        outside_support_hours: typing.Optional[typing.Union["ServiceIncidentUrgencyRuleOutsideSupportHours", typing.Dict[builtins.str, typing.Any]]] = None,
        urgency: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param type: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#type Service#type}.
        :param during_support_hours: during_support_hours block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#during_support_hours Service#during_support_hours}
        :param outside_support_hours: outside_support_hours block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#outside_support_hours Service#outside_support_hours}
        :param urgency: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#urgency Service#urgency}.
        '''
        value = ServiceIncidentUrgencyRule(
            type=type,
            during_support_hours=during_support_hours,
            outside_support_hours=outside_support_hours,
            urgency=urgency,
        )

        return typing.cast(None, jsii.invoke(self, "putIncidentUrgencyRule", [value]))

    @jsii.member(jsii_name="putScheduledActions")
    def put_scheduled_actions(
        self,
        value: typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["ServiceScheduledActions", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__def975d62bb68dc9212263b3eed0de82599979e8d371dc8559e6d966b77dbd9b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putScheduledActions", [value]))

    @jsii.member(jsii_name="putSupportHours")
    def put_support_hours(
        self,
        *,
        days_of_week: typing.Optional[typing.Sequence[jsii.Number]] = None,
        end_time: typing.Optional[builtins.str] = None,
        start_time: typing.Optional[builtins.str] = None,
        time_zone: typing.Optional[builtins.str] = None,
        type: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param days_of_week: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#days_of_week Service#days_of_week}.
        :param end_time: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#end_time Service#end_time}.
        :param start_time: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#start_time Service#start_time}.
        :param time_zone: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#time_zone Service#time_zone}.
        :param type: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#type Service#type}.
        '''
        value = ServiceSupportHours(
            days_of_week=days_of_week,
            end_time=end_time,
            start_time=start_time,
            time_zone=time_zone,
            type=type,
        )

        return typing.cast(None, jsii.invoke(self, "putSupportHours", [value]))

    @jsii.member(jsii_name="resetAcknowledgementTimeout")
    def reset_acknowledgement_timeout(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAcknowledgementTimeout", []))

    @jsii.member(jsii_name="resetAlertCreation")
    def reset_alert_creation(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAlertCreation", []))

    @jsii.member(jsii_name="resetAlertGrouping")
    def reset_alert_grouping(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAlertGrouping", []))

    @jsii.member(jsii_name="resetAlertGroupingParameters")
    def reset_alert_grouping_parameters(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAlertGroupingParameters", []))

    @jsii.member(jsii_name="resetAlertGroupingTimeout")
    def reset_alert_grouping_timeout(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAlertGroupingTimeout", []))

    @jsii.member(jsii_name="resetAutoPauseNotificationsParameters")
    def reset_auto_pause_notifications_parameters(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAutoPauseNotificationsParameters", []))

    @jsii.member(jsii_name="resetAutoResolveTimeout")
    def reset_auto_resolve_timeout(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAutoResolveTimeout", []))

    @jsii.member(jsii_name="resetDescription")
    def reset_description(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDescription", []))

    @jsii.member(jsii_name="resetId")
    def reset_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetId", []))

    @jsii.member(jsii_name="resetIncidentUrgencyRule")
    def reset_incident_urgency_rule(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetIncidentUrgencyRule", []))

    @jsii.member(jsii_name="resetResponsePlay")
    def reset_response_play(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResponsePlay", []))

    @jsii.member(jsii_name="resetScheduledActions")
    def reset_scheduled_actions(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetScheduledActions", []))

    @jsii.member(jsii_name="resetSupportHours")
    def reset_support_hours(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSupportHours", []))

    @jsii.member(jsii_name="synthesizeAttributes")
    def _synthesize_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeAttributes", []))

    @jsii.member(jsii_name="synthesizeHclAttributes")
    def _synthesize_hcl_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeHclAttributes", []))

    @jsii.python.classproperty
    @jsii.member(jsii_name="tfResourceType")
    def TF_RESOURCE_TYPE(cls) -> builtins.str:
        return typing.cast(builtins.str, jsii.sget(cls, "tfResourceType"))

    @builtins.property
    @jsii.member(jsii_name="alertGroupingParameters")
    def alert_grouping_parameters(
        self,
    ) -> "ServiceAlertGroupingParametersOutputReference":
        return typing.cast("ServiceAlertGroupingParametersOutputReference", jsii.get(self, "alertGroupingParameters"))

    @builtins.property
    @jsii.member(jsii_name="autoPauseNotificationsParameters")
    def auto_pause_notifications_parameters(
        self,
    ) -> "ServiceAutoPauseNotificationsParametersOutputReference":
        return typing.cast("ServiceAutoPauseNotificationsParametersOutputReference", jsii.get(self, "autoPauseNotificationsParameters"))

    @builtins.property
    @jsii.member(jsii_name="createdAt")
    def created_at(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "createdAt"))

    @builtins.property
    @jsii.member(jsii_name="htmlUrl")
    def html_url(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "htmlUrl"))

    @builtins.property
    @jsii.member(jsii_name="incidentUrgencyRule")
    def incident_urgency_rule(self) -> "ServiceIncidentUrgencyRuleOutputReference":
        return typing.cast("ServiceIncidentUrgencyRuleOutputReference", jsii.get(self, "incidentUrgencyRule"))

    @builtins.property
    @jsii.member(jsii_name="lastIncidentTimestamp")
    def last_incident_timestamp(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "lastIncidentTimestamp"))

    @builtins.property
    @jsii.member(jsii_name="scheduledActions")
    def scheduled_actions(self) -> "ServiceScheduledActionsList":
        return typing.cast("ServiceScheduledActionsList", jsii.get(self, "scheduledActions"))

    @builtins.property
    @jsii.member(jsii_name="status")
    def status(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "status"))

    @builtins.property
    @jsii.member(jsii_name="supportHours")
    def support_hours(self) -> "ServiceSupportHoursOutputReference":
        return typing.cast("ServiceSupportHoursOutputReference", jsii.get(self, "supportHours"))

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @builtins.property
    @jsii.member(jsii_name="acknowledgementTimeoutInput")
    def acknowledgement_timeout_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "acknowledgementTimeoutInput"))

    @builtins.property
    @jsii.member(jsii_name="alertCreationInput")
    def alert_creation_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "alertCreationInput"))

    @builtins.property
    @jsii.member(jsii_name="alertGroupingInput")
    def alert_grouping_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "alertGroupingInput"))

    @builtins.property
    @jsii.member(jsii_name="alertGroupingParametersInput")
    def alert_grouping_parameters_input(
        self,
    ) -> typing.Optional["ServiceAlertGroupingParameters"]:
        return typing.cast(typing.Optional["ServiceAlertGroupingParameters"], jsii.get(self, "alertGroupingParametersInput"))

    @builtins.property
    @jsii.member(jsii_name="alertGroupingTimeoutInput")
    def alert_grouping_timeout_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "alertGroupingTimeoutInput"))

    @builtins.property
    @jsii.member(jsii_name="autoPauseNotificationsParametersInput")
    def auto_pause_notifications_parameters_input(
        self,
    ) -> typing.Optional["ServiceAutoPauseNotificationsParameters"]:
        return typing.cast(typing.Optional["ServiceAutoPauseNotificationsParameters"], jsii.get(self, "autoPauseNotificationsParametersInput"))

    @builtins.property
    @jsii.member(jsii_name="autoResolveTimeoutInput")
    def auto_resolve_timeout_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "autoResolveTimeoutInput"))

    @builtins.property
    @jsii.member(jsii_name="descriptionInput")
    def description_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "descriptionInput"))

    @builtins.property
    @jsii.member(jsii_name="escalationPolicyInput")
    def escalation_policy_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "escalationPolicyInput"))

    @builtins.property
    @jsii.member(jsii_name="idInput")
    def id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "idInput"))

    @builtins.property
    @jsii.member(jsii_name="incidentUrgencyRuleInput")
    def incident_urgency_rule_input(
        self,
    ) -> typing.Optional["ServiceIncidentUrgencyRule"]:
        return typing.cast(typing.Optional["ServiceIncidentUrgencyRule"], jsii.get(self, "incidentUrgencyRuleInput"))

    @builtins.property
    @jsii.member(jsii_name="nameInput")
    def name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameInput"))

    @builtins.property
    @jsii.member(jsii_name="responsePlayInput")
    def response_play_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "responsePlayInput"))

    @builtins.property
    @jsii.member(jsii_name="scheduledActionsInput")
    def scheduled_actions_input(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceScheduledActions"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceScheduledActions"]]], jsii.get(self, "scheduledActionsInput"))

    @builtins.property
    @jsii.member(jsii_name="supportHoursInput")
    def support_hours_input(self) -> typing.Optional["ServiceSupportHours"]:
        return typing.cast(typing.Optional["ServiceSupportHours"], jsii.get(self, "supportHoursInput"))

    @builtins.property
    @jsii.member(jsii_name="acknowledgementTimeout")
    def acknowledgement_timeout(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "acknowledgementTimeout"))

    @acknowledgement_timeout.setter
    def acknowledgement_timeout(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1ecdcc058d653b6f7664244b407ed62b0244c5075aac96fdbcaa635a566bea46)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "acknowledgementTimeout", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="alertCreation")
    def alert_creation(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "alertCreation"))

    @alert_creation.setter
    def alert_creation(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5ff8b1f437fddf7f79f800add4828b6bda39015e0175045e37bc619aacb98aeb)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "alertCreation", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="alertGrouping")
    def alert_grouping(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "alertGrouping"))

    @alert_grouping.setter
    def alert_grouping(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1af5e88d68647b0167a6626cfcc4daf00867ae8314ebe0b7a85a58d6ed4618f9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "alertGrouping", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="alertGroupingTimeout")
    def alert_grouping_timeout(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "alertGroupingTimeout"))

    @alert_grouping_timeout.setter
    def alert_grouping_timeout(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b126b8714310ea1f23f19f18513854e5d4487b7eec64fd655088dcd690134cff)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "alertGroupingTimeout", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="autoResolveTimeout")
    def auto_resolve_timeout(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "autoResolveTimeout"))

    @auto_resolve_timeout.setter
    def auto_resolve_timeout(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e7a3cae79e7668b2f016b44a090811ec28ac30668e797364db8f999eb52f8898)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "autoResolveTimeout", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="description")
    def description(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "description"))

    @description.setter
    def description(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3b64bd45aa41ad060a6514b45abec4cbfc025b9aba44a4a2d6de40d543f546f9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "description", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="escalationPolicy")
    def escalation_policy(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "escalationPolicy"))

    @escalation_policy.setter
    def escalation_policy(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ca5390f0088233bb5aba52ed323f1e67d3f957cc23529799d1670cc39a71116a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "escalationPolicy", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @id.setter
    def id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8138471419a46d66bb57ac33ebf77a67dff0f685164881a631bea5eccabae1f9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "id", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @name.setter
    def name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__29e79b808ff555ccb2f33254eafee76e1660911422d5e76d6d1e4410dfdcbac0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "name", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="responsePlay")
    def response_play(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "responsePlay"))

    @response_play.setter
    def response_play(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__edeee92f577d7cff6b673cd34cc0d9a1580f762c457c26bf52c5313cbb5a2034)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "responsePlay", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-pagerduty.service.ServiceAlertGroupingParameters",
    jsii_struct_bases=[],
    name_mapping={"config": "config", "type": "type"},
)
class ServiceAlertGroupingParameters:
    def __init__(
        self,
        *,
        config: typing.Optional[typing.Union["ServiceAlertGroupingParametersConfig", typing.Dict[builtins.str, typing.Any]]] = None,
        type: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param config: config block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#config Service#config}
        :param type: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#type Service#type}.
        '''
        if isinstance(config, dict):
            config = ServiceAlertGroupingParametersConfig(**config)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4343d73a99b21e71d7111cb362ab5d6e7024e7e15bb4d9dcb4b002b92893870f)
            check_type(argname="argument config", value=config, expected_type=type_hints["config"])
            check_type(argname="argument type", value=type, expected_type=type_hints["type"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if config is not None:
            self._values["config"] = config
        if type is not None:
            self._values["type"] = type

    @builtins.property
    def config(self) -> typing.Optional["ServiceAlertGroupingParametersConfig"]:
        '''config block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#config Service#config}
        '''
        result = self._values.get("config")
        return typing.cast(typing.Optional["ServiceAlertGroupingParametersConfig"], result)

    @builtins.property
    def type(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#type Service#type}.'''
        result = self._values.get("type")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ServiceAlertGroupingParameters(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-pagerduty.service.ServiceAlertGroupingParametersConfig",
    jsii_struct_bases=[],
    name_mapping={
        "aggregate": "aggregate",
        "fields": "fields",
        "timeout": "timeout",
        "time_window": "timeWindow",
    },
)
class ServiceAlertGroupingParametersConfig:
    def __init__(
        self,
        *,
        aggregate: typing.Optional[builtins.str] = None,
        fields: typing.Optional[typing.Sequence[builtins.str]] = None,
        timeout: typing.Optional[jsii.Number] = None,
        time_window: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param aggregate: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#aggregate Service#aggregate}.
        :param fields: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#fields Service#fields}.
        :param timeout: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#timeout Service#timeout}.
        :param time_window: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#time_window Service#time_window}.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7de42bd72c5fca11be6dbc58727d8655e3de322844358cf6ef256f4174c41ceb)
            check_type(argname="argument aggregate", value=aggregate, expected_type=type_hints["aggregate"])
            check_type(argname="argument fields", value=fields, expected_type=type_hints["fields"])
            check_type(argname="argument timeout", value=timeout, expected_type=type_hints["timeout"])
            check_type(argname="argument time_window", value=time_window, expected_type=type_hints["time_window"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if aggregate is not None:
            self._values["aggregate"] = aggregate
        if fields is not None:
            self._values["fields"] = fields
        if timeout is not None:
            self._values["timeout"] = timeout
        if time_window is not None:
            self._values["time_window"] = time_window

    @builtins.property
    def aggregate(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#aggregate Service#aggregate}.'''
        result = self._values.get("aggregate")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def fields(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#fields Service#fields}.'''
        result = self._values.get("fields")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def timeout(self) -> typing.Optional[jsii.Number]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#timeout Service#timeout}.'''
        result = self._values.get("timeout")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def time_window(self) -> typing.Optional[jsii.Number]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#time_window Service#time_window}.'''
        result = self._values.get("time_window")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ServiceAlertGroupingParametersConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ServiceAlertGroupingParametersConfigOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-pagerduty.service.ServiceAlertGroupingParametersConfigOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6399dec3638443c41ef24293d66f3f1ccc73697935c703de964dcc3a6213bcba)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetAggregate")
    def reset_aggregate(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAggregate", []))

    @jsii.member(jsii_name="resetFields")
    def reset_fields(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFields", []))

    @jsii.member(jsii_name="resetTimeout")
    def reset_timeout(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTimeout", []))

    @jsii.member(jsii_name="resetTimeWindow")
    def reset_time_window(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTimeWindow", []))

    @builtins.property
    @jsii.member(jsii_name="aggregateInput")
    def aggregate_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "aggregateInput"))

    @builtins.property
    @jsii.member(jsii_name="fieldsInput")
    def fields_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "fieldsInput"))

    @builtins.property
    @jsii.member(jsii_name="timeoutInput")
    def timeout_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "timeoutInput"))

    @builtins.property
    @jsii.member(jsii_name="timeWindowInput")
    def time_window_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "timeWindowInput"))

    @builtins.property
    @jsii.member(jsii_name="aggregate")
    def aggregate(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "aggregate"))

    @aggregate.setter
    def aggregate(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__60bab9ab13ce1c3c75d0f5301c72f8d9bea51333319479b441da0987f1668cc7)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "aggregate", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="fields")
    def fields(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "fields"))

    @fields.setter
    def fields(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__acad7d45a0827fbe1bef6fb895adb8ef48ad7b809004afd496c295d622675ae2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "fields", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="timeout")
    def timeout(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "timeout"))

    @timeout.setter
    def timeout(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7ef7f0ae5b3c0f155cfc962fc7f2873d0b09bc5039bb272ef2fdbf18c509455a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "timeout", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="timeWindow")
    def time_window(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "timeWindow"))

    @time_window.setter
    def time_window(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3a805eaee0373e599f898feecf55849b3345110fbd6b7aadb145657e0b4384a4)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "timeWindow", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional["ServiceAlertGroupingParametersConfig"]:
        return typing.cast(typing.Optional["ServiceAlertGroupingParametersConfig"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["ServiceAlertGroupingParametersConfig"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__381e977d20a5f5aad7394cbb0201ee679f7756f581bcf3575af266cd2e2d8130)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class ServiceAlertGroupingParametersOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-pagerduty.service.ServiceAlertGroupingParametersOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d5391f22f511ab5e22fc4a9533f9b67502a759c44c210c5161ce8f313d3074ab)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putConfig")
    def put_config(
        self,
        *,
        aggregate: typing.Optional[builtins.str] = None,
        fields: typing.Optional[typing.Sequence[builtins.str]] = None,
        timeout: typing.Optional[jsii.Number] = None,
        time_window: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param aggregate: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#aggregate Service#aggregate}.
        :param fields: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#fields Service#fields}.
        :param timeout: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#timeout Service#timeout}.
        :param time_window: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#time_window Service#time_window}.
        '''
        value = ServiceAlertGroupingParametersConfig(
            aggregate=aggregate,
            fields=fields,
            timeout=timeout,
            time_window=time_window,
        )

        return typing.cast(None, jsii.invoke(self, "putConfig", [value]))

    @jsii.member(jsii_name="resetConfig")
    def reset_config(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetConfig", []))

    @jsii.member(jsii_name="resetType")
    def reset_type(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetType", []))

    @builtins.property
    @jsii.member(jsii_name="config")
    def config(self) -> "ServiceAlertGroupingParametersConfigOutputReference":
        return typing.cast("ServiceAlertGroupingParametersConfigOutputReference", jsii.get(self, "config"))

    @builtins.property
    @jsii.member(jsii_name="configInput")
    def config_input(self) -> typing.Optional["ServiceAlertGroupingParametersConfig"]:
        return typing.cast(typing.Optional["ServiceAlertGroupingParametersConfig"], jsii.get(self, "configInput"))

    @builtins.property
    @jsii.member(jsii_name="typeInput")
    def type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "typeInput"))

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @type.setter
    def type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d1d3e8ab14d18d1bfa51f4b5ddac9cd2e9e1be782e51fd211628bb97f2c5a8a4)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "type", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional["ServiceAlertGroupingParameters"]:
        return typing.cast(typing.Optional["ServiceAlertGroupingParameters"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["ServiceAlertGroupingParameters"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5b0f48f11071934e06721e7687622e80892efe687db6c8ba71ef98c3574fc737)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-pagerduty.service.ServiceAutoPauseNotificationsParameters",
    jsii_struct_bases=[],
    name_mapping={"enabled": "enabled", "timeout": "timeout"},
)
class ServiceAutoPauseNotificationsParameters:
    def __init__(
        self,
        *,
        enabled: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        timeout: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param enabled: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#enabled Service#enabled}.
        :param timeout: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#timeout Service#timeout}.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8a6a9298c5e313664254b3521fa787f4c5af90b5f80823b8d99aea67e0022e32)
            check_type(argname="argument enabled", value=enabled, expected_type=type_hints["enabled"])
            check_type(argname="argument timeout", value=timeout, expected_type=type_hints["timeout"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if enabled is not None:
            self._values["enabled"] = enabled
        if timeout is not None:
            self._values["timeout"] = timeout

    @builtins.property
    def enabled(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#enabled Service#enabled}.'''
        result = self._values.get("enabled")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def timeout(self) -> typing.Optional[jsii.Number]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#timeout Service#timeout}.'''
        result = self._values.get("timeout")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ServiceAutoPauseNotificationsParameters(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ServiceAutoPauseNotificationsParametersOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-pagerduty.service.ServiceAutoPauseNotificationsParametersOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5931370edc5e8f6e06fc3c8036a646f036fd2acc702ee3eac975cca5cc82e74a)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetEnabled")
    def reset_enabled(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEnabled", []))

    @jsii.member(jsii_name="resetTimeout")
    def reset_timeout(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTimeout", []))

    @builtins.property
    @jsii.member(jsii_name="enabledInput")
    def enabled_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "enabledInput"))

    @builtins.property
    @jsii.member(jsii_name="timeoutInput")
    def timeout_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "timeoutInput"))

    @builtins.property
    @jsii.member(jsii_name="enabled")
    def enabled(self) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "enabled"))

    @enabled.setter
    def enabled(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1875539dce587df67287a53c176c772ed0abfa67d22fb86c62bcc68b1bea77f8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "enabled", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="timeout")
    def timeout(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "timeout"))

    @timeout.setter
    def timeout(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__48f616b0b860b7af5ca43306c41991dd494930eca2bab9c9ad7c13bcf8a89d28)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "timeout", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["ServiceAutoPauseNotificationsParameters"]:
        return typing.cast(typing.Optional["ServiceAutoPauseNotificationsParameters"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["ServiceAutoPauseNotificationsParameters"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c5b660c4e95ee754745200a64c409408f0020347f1bdb4b6fb1c84f834c2edfc)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-pagerduty.service.ServiceConfig",
    jsii_struct_bases=[_cdktn_78ede62e.TerraformMetaArguments],
    name_mapping={
        "connection": "connection",
        "count": "count",
        "depends_on": "dependsOn",
        "for_each": "forEach",
        "lifecycle": "lifecycle",
        "provider": "provider",
        "provisioners": "provisioners",
        "escalation_policy": "escalationPolicy",
        "name": "name",
        "acknowledgement_timeout": "acknowledgementTimeout",
        "alert_creation": "alertCreation",
        "alert_grouping": "alertGrouping",
        "alert_grouping_parameters": "alertGroupingParameters",
        "alert_grouping_timeout": "alertGroupingTimeout",
        "auto_pause_notifications_parameters": "autoPauseNotificationsParameters",
        "auto_resolve_timeout": "autoResolveTimeout",
        "description": "description",
        "id": "id",
        "incident_urgency_rule": "incidentUrgencyRule",
        "response_play": "responsePlay",
        "scheduled_actions": "scheduledActions",
        "support_hours": "supportHours",
    },
)
class ServiceConfig(_cdktn_78ede62e.TerraformMetaArguments):
    def __init__(
        self,
        *,
        connection: typing.Optional[typing.Union[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.WinrmProvisionerConnection", typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]] = None,
        depends_on: typing.Optional[typing.Sequence["_cdktn_78ede62e.ITerraformDependable"]] = None,
        for_each: typing.Optional["_cdktn_78ede62e.ITerraformIterator"] = None,
        lifecycle: typing.Optional[typing.Union["_cdktn_78ede62e.TerraformResourceLifecycle", typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union["_cdktn_78ede62e.FileProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.LocalExecProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.RemoteExecProvisioner", typing.Dict[builtins.str, typing.Any]]]]] = None,
        escalation_policy: builtins.str,
        name: builtins.str,
        acknowledgement_timeout: typing.Optional[builtins.str] = None,
        alert_creation: typing.Optional[builtins.str] = None,
        alert_grouping: typing.Optional[builtins.str] = None,
        alert_grouping_parameters: typing.Optional[typing.Union["ServiceAlertGroupingParameters", typing.Dict[builtins.str, typing.Any]]] = None,
        alert_grouping_timeout: typing.Optional[builtins.str] = None,
        auto_pause_notifications_parameters: typing.Optional[typing.Union["ServiceAutoPauseNotificationsParameters", typing.Dict[builtins.str, typing.Any]]] = None,
        auto_resolve_timeout: typing.Optional[builtins.str] = None,
        description: typing.Optional[builtins.str] = None,
        id: typing.Optional[builtins.str] = None,
        incident_urgency_rule: typing.Optional[typing.Union["ServiceIncidentUrgencyRule", typing.Dict[builtins.str, typing.Any]]] = None,
        response_play: typing.Optional[builtins.str] = None,
        scheduled_actions: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["ServiceScheduledActions", typing.Dict[builtins.str, typing.Any]]]]] = None,
        support_hours: typing.Optional[typing.Union["ServiceSupportHours", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        :param escalation_policy: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#escalation_policy Service#escalation_policy}.
        :param name: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#name Service#name}.
        :param acknowledgement_timeout: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#acknowledgement_timeout Service#acknowledgement_timeout}.
        :param alert_creation: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#alert_creation Service#alert_creation}.
        :param alert_grouping: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#alert_grouping Service#alert_grouping}.
        :param alert_grouping_parameters: alert_grouping_parameters block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#alert_grouping_parameters Service#alert_grouping_parameters}
        :param alert_grouping_timeout: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#alert_grouping_timeout Service#alert_grouping_timeout}.
        :param auto_pause_notifications_parameters: auto_pause_notifications_parameters block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#auto_pause_notifications_parameters Service#auto_pause_notifications_parameters}
        :param auto_resolve_timeout: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#auto_resolve_timeout Service#auto_resolve_timeout}.
        :param description: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#description Service#description}.
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#id Service#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param incident_urgency_rule: incident_urgency_rule block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#incident_urgency_rule Service#incident_urgency_rule}
        :param response_play: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#response_play Service#response_play}.
        :param scheduled_actions: scheduled_actions block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#scheduled_actions Service#scheduled_actions}
        :param support_hours: support_hours block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#support_hours Service#support_hours}
        '''
        if isinstance(lifecycle, dict):
            lifecycle = _cdktn_78ede62e.TerraformResourceLifecycle(**lifecycle)
        if isinstance(alert_grouping_parameters, dict):
            alert_grouping_parameters = ServiceAlertGroupingParameters(**alert_grouping_parameters)
        if isinstance(auto_pause_notifications_parameters, dict):
            auto_pause_notifications_parameters = ServiceAutoPauseNotificationsParameters(**auto_pause_notifications_parameters)
        if isinstance(incident_urgency_rule, dict):
            incident_urgency_rule = ServiceIncidentUrgencyRule(**incident_urgency_rule)
        if isinstance(support_hours, dict):
            support_hours = ServiceSupportHours(**support_hours)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a9911ed4673665b9fcf867700a71e5f8d346f18e401f95fcc95ec4b71a76d3af)
            check_type(argname="argument connection", value=connection, expected_type=type_hints["connection"])
            check_type(argname="argument count", value=count, expected_type=type_hints["count"])
            check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
            check_type(argname="argument for_each", value=for_each, expected_type=type_hints["for_each"])
            check_type(argname="argument lifecycle", value=lifecycle, expected_type=type_hints["lifecycle"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
            check_type(argname="argument provisioners", value=provisioners, expected_type=type_hints["provisioners"])
            check_type(argname="argument escalation_policy", value=escalation_policy, expected_type=type_hints["escalation_policy"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument acknowledgement_timeout", value=acknowledgement_timeout, expected_type=type_hints["acknowledgement_timeout"])
            check_type(argname="argument alert_creation", value=alert_creation, expected_type=type_hints["alert_creation"])
            check_type(argname="argument alert_grouping", value=alert_grouping, expected_type=type_hints["alert_grouping"])
            check_type(argname="argument alert_grouping_parameters", value=alert_grouping_parameters, expected_type=type_hints["alert_grouping_parameters"])
            check_type(argname="argument alert_grouping_timeout", value=alert_grouping_timeout, expected_type=type_hints["alert_grouping_timeout"])
            check_type(argname="argument auto_pause_notifications_parameters", value=auto_pause_notifications_parameters, expected_type=type_hints["auto_pause_notifications_parameters"])
            check_type(argname="argument auto_resolve_timeout", value=auto_resolve_timeout, expected_type=type_hints["auto_resolve_timeout"])
            check_type(argname="argument description", value=description, expected_type=type_hints["description"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
            check_type(argname="argument incident_urgency_rule", value=incident_urgency_rule, expected_type=type_hints["incident_urgency_rule"])
            check_type(argname="argument response_play", value=response_play, expected_type=type_hints["response_play"])
            check_type(argname="argument scheduled_actions", value=scheduled_actions, expected_type=type_hints["scheduled_actions"])
            check_type(argname="argument support_hours", value=support_hours, expected_type=type_hints["support_hours"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "escalation_policy": escalation_policy,
            "name": name,
        }
        if connection is not None:
            self._values["connection"] = connection
        if count is not None:
            self._values["count"] = count
        if depends_on is not None:
            self._values["depends_on"] = depends_on
        if for_each is not None:
            self._values["for_each"] = for_each
        if lifecycle is not None:
            self._values["lifecycle"] = lifecycle
        if provider is not None:
            self._values["provider"] = provider
        if provisioners is not None:
            self._values["provisioners"] = provisioners
        if acknowledgement_timeout is not None:
            self._values["acknowledgement_timeout"] = acknowledgement_timeout
        if alert_creation is not None:
            self._values["alert_creation"] = alert_creation
        if alert_grouping is not None:
            self._values["alert_grouping"] = alert_grouping
        if alert_grouping_parameters is not None:
            self._values["alert_grouping_parameters"] = alert_grouping_parameters
        if alert_grouping_timeout is not None:
            self._values["alert_grouping_timeout"] = alert_grouping_timeout
        if auto_pause_notifications_parameters is not None:
            self._values["auto_pause_notifications_parameters"] = auto_pause_notifications_parameters
        if auto_resolve_timeout is not None:
            self._values["auto_resolve_timeout"] = auto_resolve_timeout
        if description is not None:
            self._values["description"] = description
        if id is not None:
            self._values["id"] = id
        if incident_urgency_rule is not None:
            self._values["incident_urgency_rule"] = incident_urgency_rule
        if response_play is not None:
            self._values["response_play"] = response_play
        if scheduled_actions is not None:
            self._values["scheduled_actions"] = scheduled_actions
        if support_hours is not None:
            self._values["support_hours"] = support_hours

    @builtins.property
    def connection(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", "_cdktn_78ede62e.WinrmProvisionerConnection"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("connection")
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", "_cdktn_78ede62e.WinrmProvisionerConnection"]], result)

    @builtins.property
    def count(
        self,
    ) -> typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("count")
        return typing.cast(typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]], result)

    @builtins.property
    def depends_on(
        self,
    ) -> typing.Optional[typing.List["_cdktn_78ede62e.ITerraformDependable"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("depends_on")
        return typing.cast(typing.Optional[typing.List["_cdktn_78ede62e.ITerraformDependable"]], result)

    @builtins.property
    def for_each(self) -> typing.Optional["_cdktn_78ede62e.ITerraformIterator"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("for_each")
        return typing.cast(typing.Optional["_cdktn_78ede62e.ITerraformIterator"], result)

    @builtins.property
    def lifecycle(
        self,
    ) -> typing.Optional["_cdktn_78ede62e.TerraformResourceLifecycle"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("lifecycle")
        return typing.cast(typing.Optional["_cdktn_78ede62e.TerraformResourceLifecycle"], result)

    @builtins.property
    def provider(self) -> typing.Optional["_cdktn_78ede62e.TerraformProvider"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provider")
        return typing.cast(typing.Optional["_cdktn_78ede62e.TerraformProvider"], result)

    @builtins.property
    def provisioners(
        self,
    ) -> typing.Optional[typing.List[typing.Union["_cdktn_78ede62e.FileProvisioner", "_cdktn_78ede62e.LocalExecProvisioner", "_cdktn_78ede62e.RemoteExecProvisioner"]]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provisioners")
        return typing.cast(typing.Optional[typing.List[typing.Union["_cdktn_78ede62e.FileProvisioner", "_cdktn_78ede62e.LocalExecProvisioner", "_cdktn_78ede62e.RemoteExecProvisioner"]]], result)

    @builtins.property
    def escalation_policy(self) -> builtins.str:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#escalation_policy Service#escalation_policy}.'''
        result = self._values.get("escalation_policy")
        assert result is not None, "Required property 'escalation_policy' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def name(self) -> builtins.str:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#name Service#name}.'''
        result = self._values.get("name")
        assert result is not None, "Required property 'name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def acknowledgement_timeout(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#acknowledgement_timeout Service#acknowledgement_timeout}.'''
        result = self._values.get("acknowledgement_timeout")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def alert_creation(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#alert_creation Service#alert_creation}.'''
        result = self._values.get("alert_creation")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def alert_grouping(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#alert_grouping Service#alert_grouping}.'''
        result = self._values.get("alert_grouping")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def alert_grouping_parameters(
        self,
    ) -> typing.Optional["ServiceAlertGroupingParameters"]:
        '''alert_grouping_parameters block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#alert_grouping_parameters Service#alert_grouping_parameters}
        '''
        result = self._values.get("alert_grouping_parameters")
        return typing.cast(typing.Optional["ServiceAlertGroupingParameters"], result)

    @builtins.property
    def alert_grouping_timeout(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#alert_grouping_timeout Service#alert_grouping_timeout}.'''
        result = self._values.get("alert_grouping_timeout")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def auto_pause_notifications_parameters(
        self,
    ) -> typing.Optional["ServiceAutoPauseNotificationsParameters"]:
        '''auto_pause_notifications_parameters block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#auto_pause_notifications_parameters Service#auto_pause_notifications_parameters}
        '''
        result = self._values.get("auto_pause_notifications_parameters")
        return typing.cast(typing.Optional["ServiceAutoPauseNotificationsParameters"], result)

    @builtins.property
    def auto_resolve_timeout(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#auto_resolve_timeout Service#auto_resolve_timeout}.'''
        result = self._values.get("auto_resolve_timeout")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def description(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#description Service#description}.'''
        result = self._values.get("description")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def id(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#id Service#id}.

        Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        '''
        result = self._values.get("id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def incident_urgency_rule(self) -> typing.Optional["ServiceIncidentUrgencyRule"]:
        '''incident_urgency_rule block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#incident_urgency_rule Service#incident_urgency_rule}
        '''
        result = self._values.get("incident_urgency_rule")
        return typing.cast(typing.Optional["ServiceIncidentUrgencyRule"], result)

    @builtins.property
    def response_play(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#response_play Service#response_play}.'''
        result = self._values.get("response_play")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def scheduled_actions(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceScheduledActions"]]]:
        '''scheduled_actions block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#scheduled_actions Service#scheduled_actions}
        '''
        result = self._values.get("scheduled_actions")
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceScheduledActions"]]], result)

    @builtins.property
    def support_hours(self) -> typing.Optional["ServiceSupportHours"]:
        '''support_hours block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#support_hours Service#support_hours}
        '''
        result = self._values.get("support_hours")
        return typing.cast(typing.Optional["ServiceSupportHours"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ServiceConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-pagerduty.service.ServiceIncidentUrgencyRule",
    jsii_struct_bases=[],
    name_mapping={
        "type": "type",
        "during_support_hours": "duringSupportHours",
        "outside_support_hours": "outsideSupportHours",
        "urgency": "urgency",
    },
)
class ServiceIncidentUrgencyRule:
    def __init__(
        self,
        *,
        type: builtins.str,
        during_support_hours: typing.Optional[typing.Union["ServiceIncidentUrgencyRuleDuringSupportHours", typing.Dict[builtins.str, typing.Any]]] = None,
        outside_support_hours: typing.Optional[typing.Union["ServiceIncidentUrgencyRuleOutsideSupportHours", typing.Dict[builtins.str, typing.Any]]] = None,
        urgency: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param type: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#type Service#type}.
        :param during_support_hours: during_support_hours block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#during_support_hours Service#during_support_hours}
        :param outside_support_hours: outside_support_hours block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#outside_support_hours Service#outside_support_hours}
        :param urgency: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#urgency Service#urgency}.
        '''
        if isinstance(during_support_hours, dict):
            during_support_hours = ServiceIncidentUrgencyRuleDuringSupportHours(**during_support_hours)
        if isinstance(outside_support_hours, dict):
            outside_support_hours = ServiceIncidentUrgencyRuleOutsideSupportHours(**outside_support_hours)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bcfc106730598272c6bce47d45191527c4dad4fce1821529f311a04e9a0cf6a0)
            check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            check_type(argname="argument during_support_hours", value=during_support_hours, expected_type=type_hints["during_support_hours"])
            check_type(argname="argument outside_support_hours", value=outside_support_hours, expected_type=type_hints["outside_support_hours"])
            check_type(argname="argument urgency", value=urgency, expected_type=type_hints["urgency"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "type": type,
        }
        if during_support_hours is not None:
            self._values["during_support_hours"] = during_support_hours
        if outside_support_hours is not None:
            self._values["outside_support_hours"] = outside_support_hours
        if urgency is not None:
            self._values["urgency"] = urgency

    @builtins.property
    def type(self) -> builtins.str:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#type Service#type}.'''
        result = self._values.get("type")
        assert result is not None, "Required property 'type' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def during_support_hours(
        self,
    ) -> typing.Optional["ServiceIncidentUrgencyRuleDuringSupportHours"]:
        '''during_support_hours block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#during_support_hours Service#during_support_hours}
        '''
        result = self._values.get("during_support_hours")
        return typing.cast(typing.Optional["ServiceIncidentUrgencyRuleDuringSupportHours"], result)

    @builtins.property
    def outside_support_hours(
        self,
    ) -> typing.Optional["ServiceIncidentUrgencyRuleOutsideSupportHours"]:
        '''outside_support_hours block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#outside_support_hours Service#outside_support_hours}
        '''
        result = self._values.get("outside_support_hours")
        return typing.cast(typing.Optional["ServiceIncidentUrgencyRuleOutsideSupportHours"], result)

    @builtins.property
    def urgency(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#urgency Service#urgency}.'''
        result = self._values.get("urgency")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ServiceIncidentUrgencyRule(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-pagerduty.service.ServiceIncidentUrgencyRuleDuringSupportHours",
    jsii_struct_bases=[],
    name_mapping={"type": "type", "urgency": "urgency"},
)
class ServiceIncidentUrgencyRuleDuringSupportHours:
    def __init__(
        self,
        *,
        type: typing.Optional[builtins.str] = None,
        urgency: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param type: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#type Service#type}.
        :param urgency: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#urgency Service#urgency}.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9b3b3d53be66ead079fe3bc9a3ca1738f762c786d8641f96c27d1e7ce68c2a55)
            check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            check_type(argname="argument urgency", value=urgency, expected_type=type_hints["urgency"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if type is not None:
            self._values["type"] = type
        if urgency is not None:
            self._values["urgency"] = urgency

    @builtins.property
    def type(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#type Service#type}.'''
        result = self._values.get("type")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def urgency(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#urgency Service#urgency}.'''
        result = self._values.get("urgency")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ServiceIncidentUrgencyRuleDuringSupportHours(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ServiceIncidentUrgencyRuleDuringSupportHoursOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-pagerduty.service.ServiceIncidentUrgencyRuleDuringSupportHoursOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f7fae8dbc0d660dda31293028e8ada713457e99c44f3bb037d01cdaccbc72841)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetType")
    def reset_type(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetType", []))

    @jsii.member(jsii_name="resetUrgency")
    def reset_urgency(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetUrgency", []))

    @builtins.property
    @jsii.member(jsii_name="typeInput")
    def type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "typeInput"))

    @builtins.property
    @jsii.member(jsii_name="urgencyInput")
    def urgency_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "urgencyInput"))

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @type.setter
    def type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bfb662633cf51479257899b4cb559e63717f190936de315d9629f7926b167065)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "type", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="urgency")
    def urgency(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "urgency"))

    @urgency.setter
    def urgency(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4ec6561140869e3c30a417ca8dac0efb081d09b79c9426a340a7747789de2e7e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "urgency", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["ServiceIncidentUrgencyRuleDuringSupportHours"]:
        return typing.cast(typing.Optional["ServiceIncidentUrgencyRuleDuringSupportHours"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["ServiceIncidentUrgencyRuleDuringSupportHours"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9f803fc72a39398acb44fe18ff120c4c5cd1b31e953c0209b135ebbb3dda208e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class ServiceIncidentUrgencyRuleOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-pagerduty.service.ServiceIncidentUrgencyRuleOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__527620f3e3a189ef35b23ee7ebe30fff3bb6da4643f36927e472349f3bbb0b71)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putDuringSupportHours")
    def put_during_support_hours(
        self,
        *,
        type: typing.Optional[builtins.str] = None,
        urgency: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param type: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#type Service#type}.
        :param urgency: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#urgency Service#urgency}.
        '''
        value = ServiceIncidentUrgencyRuleDuringSupportHours(
            type=type, urgency=urgency
        )

        return typing.cast(None, jsii.invoke(self, "putDuringSupportHours", [value]))

    @jsii.member(jsii_name="putOutsideSupportHours")
    def put_outside_support_hours(
        self,
        *,
        type: typing.Optional[builtins.str] = None,
        urgency: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param type: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#type Service#type}.
        :param urgency: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#urgency Service#urgency}.
        '''
        value = ServiceIncidentUrgencyRuleOutsideSupportHours(
            type=type, urgency=urgency
        )

        return typing.cast(None, jsii.invoke(self, "putOutsideSupportHours", [value]))

    @jsii.member(jsii_name="resetDuringSupportHours")
    def reset_during_support_hours(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDuringSupportHours", []))

    @jsii.member(jsii_name="resetOutsideSupportHours")
    def reset_outside_support_hours(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOutsideSupportHours", []))

    @jsii.member(jsii_name="resetUrgency")
    def reset_urgency(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetUrgency", []))

    @builtins.property
    @jsii.member(jsii_name="duringSupportHours")
    def during_support_hours(
        self,
    ) -> "ServiceIncidentUrgencyRuleDuringSupportHoursOutputReference":
        return typing.cast("ServiceIncidentUrgencyRuleDuringSupportHoursOutputReference", jsii.get(self, "duringSupportHours"))

    @builtins.property
    @jsii.member(jsii_name="outsideSupportHours")
    def outside_support_hours(
        self,
    ) -> "ServiceIncidentUrgencyRuleOutsideSupportHoursOutputReference":
        return typing.cast("ServiceIncidentUrgencyRuleOutsideSupportHoursOutputReference", jsii.get(self, "outsideSupportHours"))

    @builtins.property
    @jsii.member(jsii_name="duringSupportHoursInput")
    def during_support_hours_input(
        self,
    ) -> typing.Optional["ServiceIncidentUrgencyRuleDuringSupportHours"]:
        return typing.cast(typing.Optional["ServiceIncidentUrgencyRuleDuringSupportHours"], jsii.get(self, "duringSupportHoursInput"))

    @builtins.property
    @jsii.member(jsii_name="outsideSupportHoursInput")
    def outside_support_hours_input(
        self,
    ) -> typing.Optional["ServiceIncidentUrgencyRuleOutsideSupportHours"]:
        return typing.cast(typing.Optional["ServiceIncidentUrgencyRuleOutsideSupportHours"], jsii.get(self, "outsideSupportHoursInput"))

    @builtins.property
    @jsii.member(jsii_name="typeInput")
    def type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "typeInput"))

    @builtins.property
    @jsii.member(jsii_name="urgencyInput")
    def urgency_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "urgencyInput"))

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @type.setter
    def type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fc35cd8dbcaf4d1c0d4824b51e4451ca2047c3817f933136353ed8da625c758f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "type", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="urgency")
    def urgency(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "urgency"))

    @urgency.setter
    def urgency(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__82f67f5cf1cde329c8afb8f4bea16e56ffd1104e6eade73fa87cb10374a8f492)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "urgency", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional["ServiceIncidentUrgencyRule"]:
        return typing.cast(typing.Optional["ServiceIncidentUrgencyRule"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["ServiceIncidentUrgencyRule"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__892b9c6f2f15945f075809162e1b40b49142bd51ab02a14cb46c7b31cf353d5f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-pagerduty.service.ServiceIncidentUrgencyRuleOutsideSupportHours",
    jsii_struct_bases=[],
    name_mapping={"type": "type", "urgency": "urgency"},
)
class ServiceIncidentUrgencyRuleOutsideSupportHours:
    def __init__(
        self,
        *,
        type: typing.Optional[builtins.str] = None,
        urgency: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param type: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#type Service#type}.
        :param urgency: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#urgency Service#urgency}.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b69a4f1fbaa90e34d125c6eef51e47bd641506fc06c7ca002434ce06410f4652)
            check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            check_type(argname="argument urgency", value=urgency, expected_type=type_hints["urgency"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if type is not None:
            self._values["type"] = type
        if urgency is not None:
            self._values["urgency"] = urgency

    @builtins.property
    def type(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#type Service#type}.'''
        result = self._values.get("type")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def urgency(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#urgency Service#urgency}.'''
        result = self._values.get("urgency")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ServiceIncidentUrgencyRuleOutsideSupportHours(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ServiceIncidentUrgencyRuleOutsideSupportHoursOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-pagerduty.service.ServiceIncidentUrgencyRuleOutsideSupportHoursOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__088902813916c5c2d77478b526e43a95f4c13c0436febdfad4e72f4337b0ed2b)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetType")
    def reset_type(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetType", []))

    @jsii.member(jsii_name="resetUrgency")
    def reset_urgency(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetUrgency", []))

    @builtins.property
    @jsii.member(jsii_name="typeInput")
    def type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "typeInput"))

    @builtins.property
    @jsii.member(jsii_name="urgencyInput")
    def urgency_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "urgencyInput"))

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @type.setter
    def type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__10f792298a49b858b6996637edc1e2c97b927ca2f391d05853865e25444520bd)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "type", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="urgency")
    def urgency(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "urgency"))

    @urgency.setter
    def urgency(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4c4bef9a03a5f1f4ae5fca2bb17602e99c8d005f8f6862d2f4bb7522a836ef57)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "urgency", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["ServiceIncidentUrgencyRuleOutsideSupportHours"]:
        return typing.cast(typing.Optional["ServiceIncidentUrgencyRuleOutsideSupportHours"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["ServiceIncidentUrgencyRuleOutsideSupportHours"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__96ef6fcf6cd54410b9653449cb368df77f2add3b6143cea548549403571a2142)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-pagerduty.service.ServiceScheduledActions",
    jsii_struct_bases=[],
    name_mapping={"at": "at", "to_urgency": "toUrgency", "type": "type"},
)
class ServiceScheduledActions:
    def __init__(
        self,
        *,
        at: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["ServiceScheduledActionsAt", typing.Dict[builtins.str, typing.Any]]]]] = None,
        to_urgency: typing.Optional[builtins.str] = None,
        type: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param at: at block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#at Service#at}
        :param to_urgency: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#to_urgency Service#to_urgency}.
        :param type: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#type Service#type}.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3fa20cb8eaed03cd967418c46a908b9a5f9dca58779c82a3be68319ff1fd20ec)
            check_type(argname="argument at", value=at, expected_type=type_hints["at"])
            check_type(argname="argument to_urgency", value=to_urgency, expected_type=type_hints["to_urgency"])
            check_type(argname="argument type", value=type, expected_type=type_hints["type"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if at is not None:
            self._values["at"] = at
        if to_urgency is not None:
            self._values["to_urgency"] = to_urgency
        if type is not None:
            self._values["type"] = type

    @builtins.property
    def at(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceScheduledActionsAt"]]]:
        '''at block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#at Service#at}
        '''
        result = self._values.get("at")
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceScheduledActionsAt"]]], result)

    @builtins.property
    def to_urgency(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#to_urgency Service#to_urgency}.'''
        result = self._values.get("to_urgency")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def type(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#type Service#type}.'''
        result = self._values.get("type")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ServiceScheduledActions(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-pagerduty.service.ServiceScheduledActionsAt",
    jsii_struct_bases=[],
    name_mapping={"name": "name", "type": "type"},
)
class ServiceScheduledActionsAt:
    def __init__(
        self,
        *,
        name: typing.Optional[builtins.str] = None,
        type: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param name: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#name Service#name}.
        :param type: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#type Service#type}.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e6ea59d04612822bfa5e952f730438e8349c3c8472b98cfcd8efcb24576c1baa)
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument type", value=type, expected_type=type_hints["type"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if name is not None:
            self._values["name"] = name
        if type is not None:
            self._values["type"] = type

    @builtins.property
    def name(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#name Service#name}.'''
        result = self._values.get("name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def type(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#type Service#type}.'''
        result = self._values.get("type")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ServiceScheduledActionsAt(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ServiceScheduledActionsAtList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-pagerduty.service.ServiceScheduledActionsAtList",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__eb1f6992ed684f390bed7882516460f23a12b3fdfda9f730fe83521729adf8d7)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(self, index: jsii.Number) -> "ServiceScheduledActionsAtOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f6b655241d31713152e2204f78a5f391b564c034a67d353663c4a519fc260feb)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("ServiceScheduledActionsAtOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__08fad37676cbe6da7723b018c054136edcd445b26000c707bab4fc5b34a8f039)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> "_cdktn_78ede62e.IInterpolatingParent":
        '''The parent resource.'''
        return typing.cast("_cdktn_78ede62e.IInterpolatingParent", jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(
        self,
        value: "_cdktn_78ede62e.IInterpolatingParent",
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6108be9a52cd61ceafa1b84bab4b665af15cf34ea34b2b861910bf2290216116)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cbdc0d41c2f32d07ff6b5f3ac453f9c65882e3aa44aa702b05426fc42c8f351d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceScheduledActionsAt"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceScheduledActionsAt"]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceScheduledActionsAt"]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0c8b8e3b61e49835691fbbd9b5d53b934aa4f2042a1af67c8087e44fb1807436)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class ServiceScheduledActionsAtOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-pagerduty.service.ServiceScheduledActionsAtOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__108e277f94074b30fc0d9896002daeca106bb7b48ab6540ec2e008e7623e706c)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="resetName")
    def reset_name(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetName", []))

    @jsii.member(jsii_name="resetType")
    def reset_type(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetType", []))

    @builtins.property
    @jsii.member(jsii_name="nameInput")
    def name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameInput"))

    @builtins.property
    @jsii.member(jsii_name="typeInput")
    def type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "typeInput"))

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @name.setter
    def name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__abf068b5250979aad80a945f6adc8e80cff4e6666813c6f53659be615a03eb77)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "name", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @type.setter
    def type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e22bed9f5d6969d689b4c3913c8a1b5aea7cad7bc297c602fade6de1ea012998)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "type", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "ServiceScheduledActionsAt"]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "ServiceScheduledActionsAt"]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "ServiceScheduledActionsAt"]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3c358fac72402cef55bcd11909de9cecd8b1acc09149c7a6254d8b3cd46273de)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class ServiceScheduledActionsList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-pagerduty.service.ServiceScheduledActionsList",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__46f907682c0de85d098644cc9c373a59fa8736bd27a0c1887643067cfcc98980)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(self, index: jsii.Number) -> "ServiceScheduledActionsOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__44b95e65a2dc3d50d290baaf861eea32f263180694a398fe868d75ad421f4e0b)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("ServiceScheduledActionsOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5b6f26a0276243b2beba7cee39c2f0b4d73690e6f6d66587f0935184f1c73001)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> "_cdktn_78ede62e.IInterpolatingParent":
        '''The parent resource.'''
        return typing.cast("_cdktn_78ede62e.IInterpolatingParent", jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(
        self,
        value: "_cdktn_78ede62e.IInterpolatingParent",
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__faaa1de4df12ed25bca80dea8277624e8eadcf9395d1c6008cedb0e0dd4991b8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__60dfbdb6df91ce46da3c383c2cb6e9b26f00df3eadd34d328b0dbb169993990b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceScheduledActions"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceScheduledActions"]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceScheduledActions"]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1bd08576b48dfb4437de3fdeff1c97fcff56cb4fce42620088f970721fc1d42b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class ServiceScheduledActionsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-pagerduty.service.ServiceScheduledActionsOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2f1b52622cf1fa55731e2766a727a721b918b1e2acc411d55592ea50817efb9f)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="putAt")
    def put_at(
        self,
        value: typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["ServiceScheduledActionsAt", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4439d269884922e2dd99a092ab411a6427f032945e9ddbc3c64527904386665c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putAt", [value]))

    @jsii.member(jsii_name="resetAt")
    def reset_at(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAt", []))

    @jsii.member(jsii_name="resetToUrgency")
    def reset_to_urgency(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetToUrgency", []))

    @jsii.member(jsii_name="resetType")
    def reset_type(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetType", []))

    @builtins.property
    @jsii.member(jsii_name="at")
    def at(self) -> "ServiceScheduledActionsAtList":
        return typing.cast("ServiceScheduledActionsAtList", jsii.get(self, "at"))

    @builtins.property
    @jsii.member(jsii_name="atInput")
    def at_input(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceScheduledActionsAt"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceScheduledActionsAt"]]], jsii.get(self, "atInput"))

    @builtins.property
    @jsii.member(jsii_name="toUrgencyInput")
    def to_urgency_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "toUrgencyInput"))

    @builtins.property
    @jsii.member(jsii_name="typeInput")
    def type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "typeInput"))

    @builtins.property
    @jsii.member(jsii_name="toUrgency")
    def to_urgency(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "toUrgency"))

    @to_urgency.setter
    def to_urgency(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__eec8af5d3f8659d185dc982a82e4c256965367d7728b36ada88cd7a00ef86c8a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "toUrgency", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @type.setter
    def type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__97f7b0f29a711a585887d008793f41232107a262809f2c5a7cac4c6d8a4cf97b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "type", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "ServiceScheduledActions"]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "ServiceScheduledActions"]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "ServiceScheduledActions"]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__283312d2d2da71ea45c1e8bc02b264c80ed37b76f58706adde438b083bba08f3)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-pagerduty.service.ServiceSupportHours",
    jsii_struct_bases=[],
    name_mapping={
        "days_of_week": "daysOfWeek",
        "end_time": "endTime",
        "start_time": "startTime",
        "time_zone": "timeZone",
        "type": "type",
    },
)
class ServiceSupportHours:
    def __init__(
        self,
        *,
        days_of_week: typing.Optional[typing.Sequence[jsii.Number]] = None,
        end_time: typing.Optional[builtins.str] = None,
        start_time: typing.Optional[builtins.str] = None,
        time_zone: typing.Optional[builtins.str] = None,
        type: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param days_of_week: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#days_of_week Service#days_of_week}.
        :param end_time: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#end_time Service#end_time}.
        :param start_time: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#start_time Service#start_time}.
        :param time_zone: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#time_zone Service#time_zone}.
        :param type: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#type Service#type}.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__87a42cacf0de8ba35e7bac09c92b63f6ba66eaf91e1180c9ad7b06b762b19e1b)
            check_type(argname="argument days_of_week", value=days_of_week, expected_type=type_hints["days_of_week"])
            check_type(argname="argument end_time", value=end_time, expected_type=type_hints["end_time"])
            check_type(argname="argument start_time", value=start_time, expected_type=type_hints["start_time"])
            check_type(argname="argument time_zone", value=time_zone, expected_type=type_hints["time_zone"])
            check_type(argname="argument type", value=type, expected_type=type_hints["type"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if days_of_week is not None:
            self._values["days_of_week"] = days_of_week
        if end_time is not None:
            self._values["end_time"] = end_time
        if start_time is not None:
            self._values["start_time"] = start_time
        if time_zone is not None:
            self._values["time_zone"] = time_zone
        if type is not None:
            self._values["type"] = type

    @builtins.property
    def days_of_week(self) -> typing.Optional[typing.List[jsii.Number]]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#days_of_week Service#days_of_week}.'''
        result = self._values.get("days_of_week")
        return typing.cast(typing.Optional[typing.List[jsii.Number]], result)

    @builtins.property
    def end_time(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#end_time Service#end_time}.'''
        result = self._values.get("end_time")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def start_time(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#start_time Service#start_time}.'''
        result = self._values.get("start_time")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def time_zone(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#time_zone Service#time_zone}.'''
        result = self._values.get("time_zone")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def type(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service#type Service#type}.'''
        result = self._values.get("type")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ServiceSupportHours(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ServiceSupportHoursOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-pagerduty.service.ServiceSupportHoursOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4a4933d6a27ccda3ce8c33a4e6a59918bf26644c20823b4611035ae39f5c37a6)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetDaysOfWeek")
    def reset_days_of_week(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDaysOfWeek", []))

    @jsii.member(jsii_name="resetEndTime")
    def reset_end_time(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEndTime", []))

    @jsii.member(jsii_name="resetStartTime")
    def reset_start_time(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetStartTime", []))

    @jsii.member(jsii_name="resetTimeZone")
    def reset_time_zone(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTimeZone", []))

    @jsii.member(jsii_name="resetType")
    def reset_type(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetType", []))

    @builtins.property
    @jsii.member(jsii_name="daysOfWeekInput")
    def days_of_week_input(self) -> typing.Optional[typing.List[jsii.Number]]:
        return typing.cast(typing.Optional[typing.List[jsii.Number]], jsii.get(self, "daysOfWeekInput"))

    @builtins.property
    @jsii.member(jsii_name="endTimeInput")
    def end_time_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "endTimeInput"))

    @builtins.property
    @jsii.member(jsii_name="startTimeInput")
    def start_time_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "startTimeInput"))

    @builtins.property
    @jsii.member(jsii_name="timeZoneInput")
    def time_zone_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "timeZoneInput"))

    @builtins.property
    @jsii.member(jsii_name="typeInput")
    def type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "typeInput"))

    @builtins.property
    @jsii.member(jsii_name="daysOfWeek")
    def days_of_week(self) -> typing.List[jsii.Number]:
        return typing.cast(typing.List[jsii.Number], jsii.get(self, "daysOfWeek"))

    @days_of_week.setter
    def days_of_week(self, value: typing.List[jsii.Number]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e9362180fe61798e7a5a63fa6c6cbd02826b3bee1d854308ddf8f3c6a497570e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "daysOfWeek", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="endTime")
    def end_time(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "endTime"))

    @end_time.setter
    def end_time(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bcd6db1119266bb1c30d2b3510df1ec9e5f68d3e56970383a93ecf16164b5257)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "endTime", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="startTime")
    def start_time(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "startTime"))

    @start_time.setter
    def start_time(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__feab60df7b425722b4afda0867ecd1d459999466afc2bd5b42205f9b5d7bd07a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "startTime", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="timeZone")
    def time_zone(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "timeZone"))

    @time_zone.setter
    def time_zone(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__95298b01de79946b18ea42b98e1c7f74a5d60ecc9abc068bffe548e8c97e7ed9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "timeZone", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @type.setter
    def type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b15f1f43ff64292b38c0a0bb85fbd2dea5a48500c85616729a7d47084fc05bd5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "type", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional["ServiceSupportHours"]:
        return typing.cast(typing.Optional["ServiceSupportHours"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(self, value: typing.Optional["ServiceSupportHours"]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__019211f0b6fb521977a1d96db2d17908abbc80c8128779936cfcd107882f4800)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


__all__ = [
    "Service",
    "ServiceAlertGroupingParameters",
    "ServiceAlertGroupingParametersConfig",
    "ServiceAlertGroupingParametersConfigOutputReference",
    "ServiceAlertGroupingParametersOutputReference",
    "ServiceAutoPauseNotificationsParameters",
    "ServiceAutoPauseNotificationsParametersOutputReference",
    "ServiceConfig",
    "ServiceIncidentUrgencyRule",
    "ServiceIncidentUrgencyRuleDuringSupportHours",
    "ServiceIncidentUrgencyRuleDuringSupportHoursOutputReference",
    "ServiceIncidentUrgencyRuleOutputReference",
    "ServiceIncidentUrgencyRuleOutsideSupportHours",
    "ServiceIncidentUrgencyRuleOutsideSupportHoursOutputReference",
    "ServiceScheduledActions",
    "ServiceScheduledActionsAt",
    "ServiceScheduledActionsAtList",
    "ServiceScheduledActionsAtOutputReference",
    "ServiceScheduledActionsList",
    "ServiceScheduledActionsOutputReference",
    "ServiceSupportHours",
    "ServiceSupportHoursOutputReference",
]

publication.publish()

def _typecheckingstub__cc4da8f47ccee2051f4ca2cb9f745f53712597cde58ee2b81c8e21963f48c79d(
    scope: _constructs_77d1e7e8.Construct,
    id_: builtins.str,
    *,
    escalation_policy: builtins.str,
    name: builtins.str,
    acknowledgement_timeout: typing.Optional[builtins.str] = None,
    alert_creation: typing.Optional[builtins.str] = None,
    alert_grouping: typing.Optional[builtins.str] = None,
    alert_grouping_parameters: typing.Optional[typing.Union[ServiceAlertGroupingParameters, typing.Dict[builtins.str, typing.Any]]] = None,
    alert_grouping_timeout: typing.Optional[builtins.str] = None,
    auto_pause_notifications_parameters: typing.Optional[typing.Union[ServiceAutoPauseNotificationsParameters, typing.Dict[builtins.str, typing.Any]]] = None,
    auto_resolve_timeout: typing.Optional[builtins.str] = None,
    description: typing.Optional[builtins.str] = None,
    id: typing.Optional[builtins.str] = None,
    incident_urgency_rule: typing.Optional[typing.Union[ServiceIncidentUrgencyRule, typing.Dict[builtins.str, typing.Any]]] = None,
    response_play: typing.Optional[builtins.str] = None,
    scheduled_actions: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[ServiceScheduledActions, typing.Dict[builtins.str, typing.Any]]]]] = None,
    support_hours: typing.Optional[typing.Union[ServiceSupportHours, typing.Dict[builtins.str, typing.Any]]] = None,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__865b6617bd4df9b5dcc7c7a4c3b4251917372e44c845d4811f98d975297ccf0c(
    scope: _constructs_77d1e7e8.Construct,
    import_to_id: builtins.str,
    import_from_id: builtins.str,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__def975d62bb68dc9212263b3eed0de82599979e8d371dc8559e6d966b77dbd9b(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[ServiceScheduledActions, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1ecdcc058d653b6f7664244b407ed62b0244c5075aac96fdbcaa635a566bea46(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5ff8b1f437fddf7f79f800add4828b6bda39015e0175045e37bc619aacb98aeb(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1af5e88d68647b0167a6626cfcc4daf00867ae8314ebe0b7a85a58d6ed4618f9(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b126b8714310ea1f23f19f18513854e5d4487b7eec64fd655088dcd690134cff(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e7a3cae79e7668b2f016b44a090811ec28ac30668e797364db8f999eb52f8898(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3b64bd45aa41ad060a6514b45abec4cbfc025b9aba44a4a2d6de40d543f546f9(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ca5390f0088233bb5aba52ed323f1e67d3f957cc23529799d1670cc39a71116a(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8138471419a46d66bb57ac33ebf77a67dff0f685164881a631bea5eccabae1f9(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__29e79b808ff555ccb2f33254eafee76e1660911422d5e76d6d1e4410dfdcbac0(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__edeee92f577d7cff6b673cd34cc0d9a1580f762c457c26bf52c5313cbb5a2034(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4343d73a99b21e71d7111cb362ab5d6e7024e7e15bb4d9dcb4b002b92893870f(
    *,
    config: typing.Optional[typing.Union[ServiceAlertGroupingParametersConfig, typing.Dict[builtins.str, typing.Any]]] = None,
    type: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7de42bd72c5fca11be6dbc58727d8655e3de322844358cf6ef256f4174c41ceb(
    *,
    aggregate: typing.Optional[builtins.str] = None,
    fields: typing.Optional[typing.Sequence[builtins.str]] = None,
    timeout: typing.Optional[jsii.Number] = None,
    time_window: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6399dec3638443c41ef24293d66f3f1ccc73697935c703de964dcc3a6213bcba(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__60bab9ab13ce1c3c75d0f5301c72f8d9bea51333319479b441da0987f1668cc7(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__acad7d45a0827fbe1bef6fb895adb8ef48ad7b809004afd496c295d622675ae2(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7ef7f0ae5b3c0f155cfc962fc7f2873d0b09bc5039bb272ef2fdbf18c509455a(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3a805eaee0373e599f898feecf55849b3345110fbd6b7aadb145657e0b4384a4(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__381e977d20a5f5aad7394cbb0201ee679f7756f581bcf3575af266cd2e2d8130(
    value: typing.Optional[ServiceAlertGroupingParametersConfig],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d5391f22f511ab5e22fc4a9533f9b67502a759c44c210c5161ce8f313d3074ab(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d1d3e8ab14d18d1bfa51f4b5ddac9cd2e9e1be782e51fd211628bb97f2c5a8a4(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5b0f48f11071934e06721e7687622e80892efe687db6c8ba71ef98c3574fc737(
    value: typing.Optional[ServiceAlertGroupingParameters],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8a6a9298c5e313664254b3521fa787f4c5af90b5f80823b8d99aea67e0022e32(
    *,
    enabled: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    timeout: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5931370edc5e8f6e06fc3c8036a646f036fd2acc702ee3eac975cca5cc82e74a(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1875539dce587df67287a53c176c772ed0abfa67d22fb86c62bcc68b1bea77f8(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__48f616b0b860b7af5ca43306c41991dd494930eca2bab9c9ad7c13bcf8a89d28(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c5b660c4e95ee754745200a64c409408f0020347f1bdb4b6fb1c84f834c2edfc(
    value: typing.Optional[ServiceAutoPauseNotificationsParameters],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a9911ed4673665b9fcf867700a71e5f8d346f18e401f95fcc95ec4b71a76d3af(
    *,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    escalation_policy: builtins.str,
    name: builtins.str,
    acknowledgement_timeout: typing.Optional[builtins.str] = None,
    alert_creation: typing.Optional[builtins.str] = None,
    alert_grouping: typing.Optional[builtins.str] = None,
    alert_grouping_parameters: typing.Optional[typing.Union[ServiceAlertGroupingParameters, typing.Dict[builtins.str, typing.Any]]] = None,
    alert_grouping_timeout: typing.Optional[builtins.str] = None,
    auto_pause_notifications_parameters: typing.Optional[typing.Union[ServiceAutoPauseNotificationsParameters, typing.Dict[builtins.str, typing.Any]]] = None,
    auto_resolve_timeout: typing.Optional[builtins.str] = None,
    description: typing.Optional[builtins.str] = None,
    id: typing.Optional[builtins.str] = None,
    incident_urgency_rule: typing.Optional[typing.Union[ServiceIncidentUrgencyRule, typing.Dict[builtins.str, typing.Any]]] = None,
    response_play: typing.Optional[builtins.str] = None,
    scheduled_actions: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[ServiceScheduledActions, typing.Dict[builtins.str, typing.Any]]]]] = None,
    support_hours: typing.Optional[typing.Union[ServiceSupportHours, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bcfc106730598272c6bce47d45191527c4dad4fce1821529f311a04e9a0cf6a0(
    *,
    type: builtins.str,
    during_support_hours: typing.Optional[typing.Union[ServiceIncidentUrgencyRuleDuringSupportHours, typing.Dict[builtins.str, typing.Any]]] = None,
    outside_support_hours: typing.Optional[typing.Union[ServiceIncidentUrgencyRuleOutsideSupportHours, typing.Dict[builtins.str, typing.Any]]] = None,
    urgency: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9b3b3d53be66ead079fe3bc9a3ca1738f762c786d8641f96c27d1e7ce68c2a55(
    *,
    type: typing.Optional[builtins.str] = None,
    urgency: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f7fae8dbc0d660dda31293028e8ada713457e99c44f3bb037d01cdaccbc72841(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bfb662633cf51479257899b4cb559e63717f190936de315d9629f7926b167065(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4ec6561140869e3c30a417ca8dac0efb081d09b79c9426a340a7747789de2e7e(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9f803fc72a39398acb44fe18ff120c4c5cd1b31e953c0209b135ebbb3dda208e(
    value: typing.Optional[ServiceIncidentUrgencyRuleDuringSupportHours],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__527620f3e3a189ef35b23ee7ebe30fff3bb6da4643f36927e472349f3bbb0b71(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fc35cd8dbcaf4d1c0d4824b51e4451ca2047c3817f933136353ed8da625c758f(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__82f67f5cf1cde329c8afb8f4bea16e56ffd1104e6eade73fa87cb10374a8f492(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__892b9c6f2f15945f075809162e1b40b49142bd51ab02a14cb46c7b31cf353d5f(
    value: typing.Optional[ServiceIncidentUrgencyRule],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b69a4f1fbaa90e34d125c6eef51e47bd641506fc06c7ca002434ce06410f4652(
    *,
    type: typing.Optional[builtins.str] = None,
    urgency: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__088902813916c5c2d77478b526e43a95f4c13c0436febdfad4e72f4337b0ed2b(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__10f792298a49b858b6996637edc1e2c97b927ca2f391d05853865e25444520bd(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4c4bef9a03a5f1f4ae5fca2bb17602e99c8d005f8f6862d2f4bb7522a836ef57(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__96ef6fcf6cd54410b9653449cb368df77f2add3b6143cea548549403571a2142(
    value: typing.Optional[ServiceIncidentUrgencyRuleOutsideSupportHours],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3fa20cb8eaed03cd967418c46a908b9a5f9dca58779c82a3be68319ff1fd20ec(
    *,
    at: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[ServiceScheduledActionsAt, typing.Dict[builtins.str, typing.Any]]]]] = None,
    to_urgency: typing.Optional[builtins.str] = None,
    type: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e6ea59d04612822bfa5e952f730438e8349c3c8472b98cfcd8efcb24576c1baa(
    *,
    name: typing.Optional[builtins.str] = None,
    type: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__eb1f6992ed684f390bed7882516460f23a12b3fdfda9f730fe83521729adf8d7(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f6b655241d31713152e2204f78a5f391b564c034a67d353663c4a519fc260feb(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__08fad37676cbe6da7723b018c054136edcd445b26000c707bab4fc5b34a8f039(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6108be9a52cd61ceafa1b84bab4b665af15cf34ea34b2b861910bf2290216116(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cbdc0d41c2f32d07ff6b5f3ac453f9c65882e3aa44aa702b05426fc42c8f351d(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0c8b8e3b61e49835691fbbd9b5d53b934aa4f2042a1af67c8087e44fb1807436(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[ServiceScheduledActionsAt]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__108e277f94074b30fc0d9896002daeca106bb7b48ab6540ec2e008e7623e706c(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__abf068b5250979aad80a945f6adc8e80cff4e6666813c6f53659be615a03eb77(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e22bed9f5d6969d689b4c3913c8a1b5aea7cad7bc297c602fade6de1ea012998(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3c358fac72402cef55bcd11909de9cecd8b1acc09149c7a6254d8b3cd46273de(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, ServiceScheduledActionsAt]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__46f907682c0de85d098644cc9c373a59fa8736bd27a0c1887643067cfcc98980(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__44b95e65a2dc3d50d290baaf861eea32f263180694a398fe868d75ad421f4e0b(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5b6f26a0276243b2beba7cee39c2f0b4d73690e6f6d66587f0935184f1c73001(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__faaa1de4df12ed25bca80dea8277624e8eadcf9395d1c6008cedb0e0dd4991b8(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__60dfbdb6df91ce46da3c383c2cb6e9b26f00df3eadd34d328b0dbb169993990b(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1bd08576b48dfb4437de3fdeff1c97fcff56cb4fce42620088f970721fc1d42b(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[ServiceScheduledActions]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2f1b52622cf1fa55731e2766a727a721b918b1e2acc411d55592ea50817efb9f(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4439d269884922e2dd99a092ab411a6427f032945e9ddbc3c64527904386665c(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[ServiceScheduledActionsAt, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__eec8af5d3f8659d185dc982a82e4c256965367d7728b36ada88cd7a00ef86c8a(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__97f7b0f29a711a585887d008793f41232107a262809f2c5a7cac4c6d8a4cf97b(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__283312d2d2da71ea45c1e8bc02b264c80ed37b76f58706adde438b083bba08f3(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, ServiceScheduledActions]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__87a42cacf0de8ba35e7bac09c92b63f6ba66eaf91e1180c9ad7b06b762b19e1b(
    *,
    days_of_week: typing.Optional[typing.Sequence[jsii.Number]] = None,
    end_time: typing.Optional[builtins.str] = None,
    start_time: typing.Optional[builtins.str] = None,
    time_zone: typing.Optional[builtins.str] = None,
    type: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4a4933d6a27ccda3ce8c33a4e6a59918bf26644c20823b4611035ae39f5c37a6(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e9362180fe61798e7a5a63fa6c6cbd02826b3bee1d854308ddf8f3c6a497570e(
    value: typing.List[jsii.Number],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bcd6db1119266bb1c30d2b3510df1ec9e5f68d3e56970383a93ecf16164b5257(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__feab60df7b425722b4afda0867ecd1d459999466afc2bd5b42205f9b5d7bd07a(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__95298b01de79946b18ea42b98e1c7f74a5d60ecc9abc068bffe548e8c97e7ed9(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b15f1f43ff64292b38c0a0bb85fbd2dea5a48500c85616729a7d47084fc05bd5(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__019211f0b6fb521977a1d96db2d17908abbc80c8128779936cfcd107882f4800(
    value: typing.Optional[ServiceSupportHours],
) -> None:
    """Type checking stubs"""
    pass
