r'''
# `pagerduty_service_integration`

Refer to the Terraform Registry for docs: [`pagerduty_service_integration`](https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration).
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import cdktn as _cdktn_78ede62e
import constructs as _constructs_77d1e7e8


class ServiceIntegration(
    _cdktn_78ede62e.TerraformResource,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-pagerduty.serviceIntegration.ServiceIntegration",
):
    '''Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration pagerduty_service_integration}.'''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id_: builtins.str,
        *,
        service: builtins.str,
        email_filter: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["ServiceIntegrationEmailFilter", typing.Dict[builtins.str, typing.Any]]]]] = None,
        email_filter_mode: typing.Optional[builtins.str] = None,
        email_incident_creation: typing.Optional[builtins.str] = None,
        email_parser: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["ServiceIntegrationEmailParser", typing.Dict[builtins.str, typing.Any]]]]] = None,
        email_parsing_fallback: typing.Optional[builtins.str] = None,
        id: typing.Optional[builtins.str] = None,
        integration_email: typing.Optional[builtins.str] = None,
        integration_key: typing.Optional[builtins.str] = None,
        name: typing.Optional[builtins.str] = None,
        type: typing.Optional[builtins.str] = None,
        vendor: typing.Optional[builtins.str] = None,
        connection: typing.Optional[typing.Union[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.WinrmProvisionerConnection", typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]] = None,
        depends_on: typing.Optional[typing.Sequence["_cdktn_78ede62e.ITerraformDependable"]] = None,
        for_each: typing.Optional["_cdktn_78ede62e.ITerraformIterator"] = None,
        lifecycle: typing.Optional[typing.Union["_cdktn_78ede62e.TerraformResourceLifecycle", typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union["_cdktn_78ede62e.FileProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.LocalExecProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.RemoteExecProvisioner", typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration pagerduty_service_integration} Resource.

        :param scope: The scope in which to define this construct.
        :param id_: The scoped construct ID. Must be unique amongst siblings in the same scope
        :param service: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#service ServiceIntegration#service}.
        :param email_filter: email_filter block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#email_filter ServiceIntegration#email_filter}
        :param email_filter_mode: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#email_filter_mode ServiceIntegration#email_filter_mode}.
        :param email_incident_creation: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#email_incident_creation ServiceIntegration#email_incident_creation}.
        :param email_parser: email_parser block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#email_parser ServiceIntegration#email_parser}
        :param email_parsing_fallback: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#email_parsing_fallback ServiceIntegration#email_parsing_fallback}.
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#id ServiceIntegration#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param integration_email: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#integration_email ServiceIntegration#integration_email}.
        :param integration_key: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#integration_key ServiceIntegration#integration_key}.
        :param name: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#name ServiceIntegration#name}.
        :param type: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#type ServiceIntegration#type}.
        :param vendor: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#vendor ServiceIntegration#vendor}.
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__028267ba12aac17ac17a74f615c9d97cbf66ff01d3ce7809d6bc02bee4272f46)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id_", value=id_, expected_type=type_hints["id_"])
        config = ServiceIntegrationConfig(
            service=service,
            email_filter=email_filter,
            email_filter_mode=email_filter_mode,
            email_incident_creation=email_incident_creation,
            email_parser=email_parser,
            email_parsing_fallback=email_parsing_fallback,
            id=id,
            integration_email=integration_email,
            integration_key=integration_key,
            name=name,
            type=type,
            vendor=vendor,
            connection=connection,
            count=count,
            depends_on=depends_on,
            for_each=for_each,
            lifecycle=lifecycle,
            provider=provider,
            provisioners=provisioners,
        )

        jsii.create(self.__class__, self, [scope, id_, config])

    @jsii.member(jsii_name="generateConfigForImport")
    @builtins.classmethod
    def generate_config_for_import(
        cls,
        scope: "_constructs_77d1e7e8.Construct",
        import_to_id: builtins.str,
        import_from_id: builtins.str,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
    ) -> "_cdktn_78ede62e.ImportableResource":
        '''Generates CDKTN code for importing a ServiceIntegration resource upon running "cdktn plan ".

        :param scope: The scope in which to define this construct.
        :param import_to_id: The construct id used in the generated config for the ServiceIntegration to import.
        :param import_from_id: The id of the existing ServiceIntegration that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#import import section} in the documentation of this resource for the id to use
        :param provider: ? Optional instance of the provider where the ServiceIntegration to import is found.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b78538808a51de65580bd180b840788ef54c9e54f0d10593dd8a67873e2e64e5)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument import_to_id", value=import_to_id, expected_type=type_hints["import_to_id"])
            check_type(argname="argument import_from_id", value=import_from_id, expected_type=type_hints["import_from_id"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
        return typing.cast("_cdktn_78ede62e.ImportableResource", jsii.sinvoke(cls, "generateConfigForImport", [scope, import_to_id, import_from_id, provider]))

    @jsii.member(jsii_name="putEmailFilter")
    def put_email_filter(
        self,
        value: typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["ServiceIntegrationEmailFilter", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__807909b3a3ab66bbd7ea265019c2afa0cb95e036bbe225f60d0620e848b7fbcb)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putEmailFilter", [value]))

    @jsii.member(jsii_name="putEmailParser")
    def put_email_parser(
        self,
        value: typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["ServiceIntegrationEmailParser", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__38999d0826de30e32fcf0ba6467d8b99bac07aa1d280dd7cf0476da35f41c41b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putEmailParser", [value]))

    @jsii.member(jsii_name="resetEmailFilter")
    def reset_email_filter(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEmailFilter", []))

    @jsii.member(jsii_name="resetEmailFilterMode")
    def reset_email_filter_mode(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEmailFilterMode", []))

    @jsii.member(jsii_name="resetEmailIncidentCreation")
    def reset_email_incident_creation(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEmailIncidentCreation", []))

    @jsii.member(jsii_name="resetEmailParser")
    def reset_email_parser(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEmailParser", []))

    @jsii.member(jsii_name="resetEmailParsingFallback")
    def reset_email_parsing_fallback(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEmailParsingFallback", []))

    @jsii.member(jsii_name="resetId")
    def reset_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetId", []))

    @jsii.member(jsii_name="resetIntegrationEmail")
    def reset_integration_email(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetIntegrationEmail", []))

    @jsii.member(jsii_name="resetIntegrationKey")
    def reset_integration_key(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetIntegrationKey", []))

    @jsii.member(jsii_name="resetName")
    def reset_name(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetName", []))

    @jsii.member(jsii_name="resetType")
    def reset_type(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetType", []))

    @jsii.member(jsii_name="resetVendor")
    def reset_vendor(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetVendor", []))

    @jsii.member(jsii_name="synthesizeAttributes")
    def _synthesize_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeAttributes", []))

    @jsii.member(jsii_name="synthesizeHclAttributes")
    def _synthesize_hcl_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeHclAttributes", []))

    @jsii.python.classproperty
    @jsii.member(jsii_name="tfResourceType")
    def TF_RESOURCE_TYPE(cls) -> builtins.str:
        return typing.cast(builtins.str, jsii.sget(cls, "tfResourceType"))

    @builtins.property
    @jsii.member(jsii_name="emailFilter")
    def email_filter(self) -> "ServiceIntegrationEmailFilterList":
        return typing.cast("ServiceIntegrationEmailFilterList", jsii.get(self, "emailFilter"))

    @builtins.property
    @jsii.member(jsii_name="emailParser")
    def email_parser(self) -> "ServiceIntegrationEmailParserList":
        return typing.cast("ServiceIntegrationEmailParserList", jsii.get(self, "emailParser"))

    @builtins.property
    @jsii.member(jsii_name="htmlUrl")
    def html_url(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "htmlUrl"))

    @builtins.property
    @jsii.member(jsii_name="emailFilterInput")
    def email_filter_input(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceIntegrationEmailFilter"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceIntegrationEmailFilter"]]], jsii.get(self, "emailFilterInput"))

    @builtins.property
    @jsii.member(jsii_name="emailFilterModeInput")
    def email_filter_mode_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "emailFilterModeInput"))

    @builtins.property
    @jsii.member(jsii_name="emailIncidentCreationInput")
    def email_incident_creation_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "emailIncidentCreationInput"))

    @builtins.property
    @jsii.member(jsii_name="emailParserInput")
    def email_parser_input(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceIntegrationEmailParser"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceIntegrationEmailParser"]]], jsii.get(self, "emailParserInput"))

    @builtins.property
    @jsii.member(jsii_name="emailParsingFallbackInput")
    def email_parsing_fallback_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "emailParsingFallbackInput"))

    @builtins.property
    @jsii.member(jsii_name="idInput")
    def id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "idInput"))

    @builtins.property
    @jsii.member(jsii_name="integrationEmailInput")
    def integration_email_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "integrationEmailInput"))

    @builtins.property
    @jsii.member(jsii_name="integrationKeyInput")
    def integration_key_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "integrationKeyInput"))

    @builtins.property
    @jsii.member(jsii_name="nameInput")
    def name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameInput"))

    @builtins.property
    @jsii.member(jsii_name="serviceInput")
    def service_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "serviceInput"))

    @builtins.property
    @jsii.member(jsii_name="typeInput")
    def type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "typeInput"))

    @builtins.property
    @jsii.member(jsii_name="vendorInput")
    def vendor_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "vendorInput"))

    @builtins.property
    @jsii.member(jsii_name="emailFilterMode")
    def email_filter_mode(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "emailFilterMode"))

    @email_filter_mode.setter
    def email_filter_mode(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2d937e8aeecf4f75eb73834acac6cdcdb648b31ac3b71fae50e0058c88391f98)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "emailFilterMode", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="emailIncidentCreation")
    def email_incident_creation(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "emailIncidentCreation"))

    @email_incident_creation.setter
    def email_incident_creation(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__771dfb5c897cfb3baecdd9dedcd2113f6c402b56841dddfa42d0a3d5ad1e3d9a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "emailIncidentCreation", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="emailParsingFallback")
    def email_parsing_fallback(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "emailParsingFallback"))

    @email_parsing_fallback.setter
    def email_parsing_fallback(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__63609ddcb62478ae0be41aaa8383f1d67b4f1e552e9160638b4b2d6b82ba5672)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "emailParsingFallback", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @id.setter
    def id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0aaa70ff3277ca41ba76bd0f811732098362931a642b5652d7554e675a33cd5a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "id", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="integrationEmail")
    def integration_email(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "integrationEmail"))

    @integration_email.setter
    def integration_email(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5c9fedd8d89695bb9ac2f9cf9ef62937b503155c99f690ed9d38d5dd92c70440)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "integrationEmail", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="integrationKey")
    def integration_key(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "integrationKey"))

    @integration_key.setter
    def integration_key(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b57e5a2cec5d6933c415753ce47fe1798af8fb89a5bf5ac0e3991b2e53f03b23)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "integrationKey", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @name.setter
    def name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b780fb537b974a10065f0dae583f75b0844ec7fd129343dddece3a9f9d1e8b28)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "name", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="service")
    def service(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "service"))

    @service.setter
    def service(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ce1ff411c74fc04709f43da1fdc5e1348986efc301fefcb6b8caec63b641deee)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "service", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @type.setter
    def type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2ead76e48cb99434c92b8ab00f361a17ae854464a3b6a3a43f8ad5da9ca8e875)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "type", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="vendor")
    def vendor(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "vendor"))

    @vendor.setter
    def vendor(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4796ea2e652a7c52e3f36a731329e591cb182e4116d25f7bff8ea709a5b5da23)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "vendor", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-pagerduty.serviceIntegration.ServiceIntegrationConfig",
    jsii_struct_bases=[_cdktn_78ede62e.TerraformMetaArguments],
    name_mapping={
        "connection": "connection",
        "count": "count",
        "depends_on": "dependsOn",
        "for_each": "forEach",
        "lifecycle": "lifecycle",
        "provider": "provider",
        "provisioners": "provisioners",
        "service": "service",
        "email_filter": "emailFilter",
        "email_filter_mode": "emailFilterMode",
        "email_incident_creation": "emailIncidentCreation",
        "email_parser": "emailParser",
        "email_parsing_fallback": "emailParsingFallback",
        "id": "id",
        "integration_email": "integrationEmail",
        "integration_key": "integrationKey",
        "name": "name",
        "type": "type",
        "vendor": "vendor",
    },
)
class ServiceIntegrationConfig(_cdktn_78ede62e.TerraformMetaArguments):
    def __init__(
        self,
        *,
        connection: typing.Optional[typing.Union[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.WinrmProvisionerConnection", typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]] = None,
        depends_on: typing.Optional[typing.Sequence["_cdktn_78ede62e.ITerraformDependable"]] = None,
        for_each: typing.Optional["_cdktn_78ede62e.ITerraformIterator"] = None,
        lifecycle: typing.Optional[typing.Union["_cdktn_78ede62e.TerraformResourceLifecycle", typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union["_cdktn_78ede62e.FileProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.LocalExecProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.RemoteExecProvisioner", typing.Dict[builtins.str, typing.Any]]]]] = None,
        service: builtins.str,
        email_filter: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["ServiceIntegrationEmailFilter", typing.Dict[builtins.str, typing.Any]]]]] = None,
        email_filter_mode: typing.Optional[builtins.str] = None,
        email_incident_creation: typing.Optional[builtins.str] = None,
        email_parser: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["ServiceIntegrationEmailParser", typing.Dict[builtins.str, typing.Any]]]]] = None,
        email_parsing_fallback: typing.Optional[builtins.str] = None,
        id: typing.Optional[builtins.str] = None,
        integration_email: typing.Optional[builtins.str] = None,
        integration_key: typing.Optional[builtins.str] = None,
        name: typing.Optional[builtins.str] = None,
        type: typing.Optional[builtins.str] = None,
        vendor: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        :param service: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#service ServiceIntegration#service}.
        :param email_filter: email_filter block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#email_filter ServiceIntegration#email_filter}
        :param email_filter_mode: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#email_filter_mode ServiceIntegration#email_filter_mode}.
        :param email_incident_creation: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#email_incident_creation ServiceIntegration#email_incident_creation}.
        :param email_parser: email_parser block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#email_parser ServiceIntegration#email_parser}
        :param email_parsing_fallback: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#email_parsing_fallback ServiceIntegration#email_parsing_fallback}.
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#id ServiceIntegration#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param integration_email: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#integration_email ServiceIntegration#integration_email}.
        :param integration_key: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#integration_key ServiceIntegration#integration_key}.
        :param name: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#name ServiceIntegration#name}.
        :param type: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#type ServiceIntegration#type}.
        :param vendor: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#vendor ServiceIntegration#vendor}.
        '''
        if isinstance(lifecycle, dict):
            lifecycle = _cdktn_78ede62e.TerraformResourceLifecycle(**lifecycle)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6821679a7913c3c38c195d141cdaf8a3d0ea3166cb1f697e9ab11223f6bda66b)
            check_type(argname="argument connection", value=connection, expected_type=type_hints["connection"])
            check_type(argname="argument count", value=count, expected_type=type_hints["count"])
            check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
            check_type(argname="argument for_each", value=for_each, expected_type=type_hints["for_each"])
            check_type(argname="argument lifecycle", value=lifecycle, expected_type=type_hints["lifecycle"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
            check_type(argname="argument provisioners", value=provisioners, expected_type=type_hints["provisioners"])
            check_type(argname="argument service", value=service, expected_type=type_hints["service"])
            check_type(argname="argument email_filter", value=email_filter, expected_type=type_hints["email_filter"])
            check_type(argname="argument email_filter_mode", value=email_filter_mode, expected_type=type_hints["email_filter_mode"])
            check_type(argname="argument email_incident_creation", value=email_incident_creation, expected_type=type_hints["email_incident_creation"])
            check_type(argname="argument email_parser", value=email_parser, expected_type=type_hints["email_parser"])
            check_type(argname="argument email_parsing_fallback", value=email_parsing_fallback, expected_type=type_hints["email_parsing_fallback"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
            check_type(argname="argument integration_email", value=integration_email, expected_type=type_hints["integration_email"])
            check_type(argname="argument integration_key", value=integration_key, expected_type=type_hints["integration_key"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            check_type(argname="argument vendor", value=vendor, expected_type=type_hints["vendor"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "service": service,
        }
        if connection is not None:
            self._values["connection"] = connection
        if count is not None:
            self._values["count"] = count
        if depends_on is not None:
            self._values["depends_on"] = depends_on
        if for_each is not None:
            self._values["for_each"] = for_each
        if lifecycle is not None:
            self._values["lifecycle"] = lifecycle
        if provider is not None:
            self._values["provider"] = provider
        if provisioners is not None:
            self._values["provisioners"] = provisioners
        if email_filter is not None:
            self._values["email_filter"] = email_filter
        if email_filter_mode is not None:
            self._values["email_filter_mode"] = email_filter_mode
        if email_incident_creation is not None:
            self._values["email_incident_creation"] = email_incident_creation
        if email_parser is not None:
            self._values["email_parser"] = email_parser
        if email_parsing_fallback is not None:
            self._values["email_parsing_fallback"] = email_parsing_fallback
        if id is not None:
            self._values["id"] = id
        if integration_email is not None:
            self._values["integration_email"] = integration_email
        if integration_key is not None:
            self._values["integration_key"] = integration_key
        if name is not None:
            self._values["name"] = name
        if type is not None:
            self._values["type"] = type
        if vendor is not None:
            self._values["vendor"] = vendor

    @builtins.property
    def connection(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", "_cdktn_78ede62e.WinrmProvisionerConnection"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("connection")
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", "_cdktn_78ede62e.WinrmProvisionerConnection"]], result)

    @builtins.property
    def count(
        self,
    ) -> typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("count")
        return typing.cast(typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]], result)

    @builtins.property
    def depends_on(
        self,
    ) -> typing.Optional[typing.List["_cdktn_78ede62e.ITerraformDependable"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("depends_on")
        return typing.cast(typing.Optional[typing.List["_cdktn_78ede62e.ITerraformDependable"]], result)

    @builtins.property
    def for_each(self) -> typing.Optional["_cdktn_78ede62e.ITerraformIterator"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("for_each")
        return typing.cast(typing.Optional["_cdktn_78ede62e.ITerraformIterator"], result)

    @builtins.property
    def lifecycle(
        self,
    ) -> typing.Optional["_cdktn_78ede62e.TerraformResourceLifecycle"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("lifecycle")
        return typing.cast(typing.Optional["_cdktn_78ede62e.TerraformResourceLifecycle"], result)

    @builtins.property
    def provider(self) -> typing.Optional["_cdktn_78ede62e.TerraformProvider"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provider")
        return typing.cast(typing.Optional["_cdktn_78ede62e.TerraformProvider"], result)

    @builtins.property
    def provisioners(
        self,
    ) -> typing.Optional[typing.List[typing.Union["_cdktn_78ede62e.FileProvisioner", "_cdktn_78ede62e.LocalExecProvisioner", "_cdktn_78ede62e.RemoteExecProvisioner"]]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provisioners")
        return typing.cast(typing.Optional[typing.List[typing.Union["_cdktn_78ede62e.FileProvisioner", "_cdktn_78ede62e.LocalExecProvisioner", "_cdktn_78ede62e.RemoteExecProvisioner"]]], result)

    @builtins.property
    def service(self) -> builtins.str:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#service ServiceIntegration#service}.'''
        result = self._values.get("service")
        assert result is not None, "Required property 'service' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def email_filter(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceIntegrationEmailFilter"]]]:
        '''email_filter block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#email_filter ServiceIntegration#email_filter}
        '''
        result = self._values.get("email_filter")
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceIntegrationEmailFilter"]]], result)

    @builtins.property
    def email_filter_mode(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#email_filter_mode ServiceIntegration#email_filter_mode}.'''
        result = self._values.get("email_filter_mode")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def email_incident_creation(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#email_incident_creation ServiceIntegration#email_incident_creation}.'''
        result = self._values.get("email_incident_creation")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def email_parser(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceIntegrationEmailParser"]]]:
        '''email_parser block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#email_parser ServiceIntegration#email_parser}
        '''
        result = self._values.get("email_parser")
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceIntegrationEmailParser"]]], result)

    @builtins.property
    def email_parsing_fallback(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#email_parsing_fallback ServiceIntegration#email_parsing_fallback}.'''
        result = self._values.get("email_parsing_fallback")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def id(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#id ServiceIntegration#id}.

        Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        '''
        result = self._values.get("id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def integration_email(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#integration_email ServiceIntegration#integration_email}.'''
        result = self._values.get("integration_email")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def integration_key(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#integration_key ServiceIntegration#integration_key}.'''
        result = self._values.get("integration_key")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def name(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#name ServiceIntegration#name}.'''
        result = self._values.get("name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def type(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#type ServiceIntegration#type}.'''
        result = self._values.get("type")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def vendor(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#vendor ServiceIntegration#vendor}.'''
        result = self._values.get("vendor")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ServiceIntegrationConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-pagerduty.serviceIntegration.ServiceIntegrationEmailFilter",
    jsii_struct_bases=[],
    name_mapping={
        "body_mode": "bodyMode",
        "body_regex": "bodyRegex",
        "from_email_mode": "fromEmailMode",
        "from_email_regex": "fromEmailRegex",
        "subject_mode": "subjectMode",
        "subject_regex": "subjectRegex",
    },
)
class ServiceIntegrationEmailFilter:
    def __init__(
        self,
        *,
        body_mode: typing.Optional[builtins.str] = None,
        body_regex: typing.Optional[builtins.str] = None,
        from_email_mode: typing.Optional[builtins.str] = None,
        from_email_regex: typing.Optional[builtins.str] = None,
        subject_mode: typing.Optional[builtins.str] = None,
        subject_regex: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param body_mode: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#body_mode ServiceIntegration#body_mode}.
        :param body_regex: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#body_regex ServiceIntegration#body_regex}.
        :param from_email_mode: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#from_email_mode ServiceIntegration#from_email_mode}.
        :param from_email_regex: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#from_email_regex ServiceIntegration#from_email_regex}.
        :param subject_mode: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#subject_mode ServiceIntegration#subject_mode}.
        :param subject_regex: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#subject_regex ServiceIntegration#subject_regex}.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__81b44b0f9f75af6896aca2aa17e37941c72753a9ec69fe66a720f8adb351535e)
            check_type(argname="argument body_mode", value=body_mode, expected_type=type_hints["body_mode"])
            check_type(argname="argument body_regex", value=body_regex, expected_type=type_hints["body_regex"])
            check_type(argname="argument from_email_mode", value=from_email_mode, expected_type=type_hints["from_email_mode"])
            check_type(argname="argument from_email_regex", value=from_email_regex, expected_type=type_hints["from_email_regex"])
            check_type(argname="argument subject_mode", value=subject_mode, expected_type=type_hints["subject_mode"])
            check_type(argname="argument subject_regex", value=subject_regex, expected_type=type_hints["subject_regex"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if body_mode is not None:
            self._values["body_mode"] = body_mode
        if body_regex is not None:
            self._values["body_regex"] = body_regex
        if from_email_mode is not None:
            self._values["from_email_mode"] = from_email_mode
        if from_email_regex is not None:
            self._values["from_email_regex"] = from_email_regex
        if subject_mode is not None:
            self._values["subject_mode"] = subject_mode
        if subject_regex is not None:
            self._values["subject_regex"] = subject_regex

    @builtins.property
    def body_mode(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#body_mode ServiceIntegration#body_mode}.'''
        result = self._values.get("body_mode")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def body_regex(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#body_regex ServiceIntegration#body_regex}.'''
        result = self._values.get("body_regex")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def from_email_mode(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#from_email_mode ServiceIntegration#from_email_mode}.'''
        result = self._values.get("from_email_mode")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def from_email_regex(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#from_email_regex ServiceIntegration#from_email_regex}.'''
        result = self._values.get("from_email_regex")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def subject_mode(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#subject_mode ServiceIntegration#subject_mode}.'''
        result = self._values.get("subject_mode")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def subject_regex(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#subject_regex ServiceIntegration#subject_regex}.'''
        result = self._values.get("subject_regex")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ServiceIntegrationEmailFilter(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ServiceIntegrationEmailFilterList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-pagerduty.serviceIntegration.ServiceIntegrationEmailFilterList",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a8bf5c8e4912c5fd85fd773195679ff3bbb92d587bcd76a5b15bba04bf88e6ac)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(self, index: jsii.Number) -> "ServiceIntegrationEmailFilterOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__86f620008cb370877803a1dbace7073d993cd0b546b1b99fc6ea15b6ce62edb9)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("ServiceIntegrationEmailFilterOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0c0ce651d4ae91f18ad14aac802aaf0835fc3c933a42c92d24ed048d5eda3141)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> "_cdktn_78ede62e.IInterpolatingParent":
        '''The parent resource.'''
        return typing.cast("_cdktn_78ede62e.IInterpolatingParent", jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(
        self,
        value: "_cdktn_78ede62e.IInterpolatingParent",
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6bbe49a478354be66100175ec89bd7e1c02cab27f371a77b797a5f87e82c4218)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b5137d53db9ca2989afec9ef0555de2e78f3639847c72a34152597340adb0806)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceIntegrationEmailFilter"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceIntegrationEmailFilter"]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceIntegrationEmailFilter"]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b52455dc194a598cb8b0a66d52777ac9a9ea53b55ac4c1bed214bcd0c74deee0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class ServiceIntegrationEmailFilterOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-pagerduty.serviceIntegration.ServiceIntegrationEmailFilterOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__02e2b2d9ee93fb67148b46b1aa583ae1cee973f64fb3e9441b21464969b987b3)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="resetBodyMode")
    def reset_body_mode(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetBodyMode", []))

    @jsii.member(jsii_name="resetBodyRegex")
    def reset_body_regex(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetBodyRegex", []))

    @jsii.member(jsii_name="resetFromEmailMode")
    def reset_from_email_mode(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFromEmailMode", []))

    @jsii.member(jsii_name="resetFromEmailRegex")
    def reset_from_email_regex(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFromEmailRegex", []))

    @jsii.member(jsii_name="resetSubjectMode")
    def reset_subject_mode(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSubjectMode", []))

    @jsii.member(jsii_name="resetSubjectRegex")
    def reset_subject_regex(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSubjectRegex", []))

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @builtins.property
    @jsii.member(jsii_name="bodyModeInput")
    def body_mode_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "bodyModeInput"))

    @builtins.property
    @jsii.member(jsii_name="bodyRegexInput")
    def body_regex_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "bodyRegexInput"))

    @builtins.property
    @jsii.member(jsii_name="fromEmailModeInput")
    def from_email_mode_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "fromEmailModeInput"))

    @builtins.property
    @jsii.member(jsii_name="fromEmailRegexInput")
    def from_email_regex_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "fromEmailRegexInput"))

    @builtins.property
    @jsii.member(jsii_name="subjectModeInput")
    def subject_mode_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "subjectModeInput"))

    @builtins.property
    @jsii.member(jsii_name="subjectRegexInput")
    def subject_regex_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "subjectRegexInput"))

    @builtins.property
    @jsii.member(jsii_name="bodyMode")
    def body_mode(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "bodyMode"))

    @body_mode.setter
    def body_mode(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1519f58dba752c5cfe6714975d469caa99562974b0d6fe5245f8381776661c99)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "bodyMode", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="bodyRegex")
    def body_regex(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "bodyRegex"))

    @body_regex.setter
    def body_regex(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6472bc9f2ec596c438f77ad322c95e491e998c58b6736b7ce98d6c780585fbd2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "bodyRegex", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="fromEmailMode")
    def from_email_mode(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "fromEmailMode"))

    @from_email_mode.setter
    def from_email_mode(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f4d9521fdaec4ede1f92055bb1a77270321594462441aae668d4655b55f1b866)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "fromEmailMode", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="fromEmailRegex")
    def from_email_regex(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "fromEmailRegex"))

    @from_email_regex.setter
    def from_email_regex(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8cf2eec5fd8a155c9f95cea0db5326b7a8703b994a6968acc85fad43af1b4013)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "fromEmailRegex", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="subjectMode")
    def subject_mode(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "subjectMode"))

    @subject_mode.setter
    def subject_mode(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0a71ab2c9046118770c28990389ab7fdd821b335db24d369aea91dfd8c75a9b1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "subjectMode", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="subjectRegex")
    def subject_regex(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "subjectRegex"))

    @subject_regex.setter
    def subject_regex(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c90c0aaf669ba46413e829692a0e2a9a0aaa28d2057f278420daa538d9e0eacf)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "subjectRegex", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "ServiceIntegrationEmailFilter"]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "ServiceIntegrationEmailFilter"]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "ServiceIntegrationEmailFilter"]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8d70922ea7177015d8b6929c4bf5fb71281133bea869e55d7d6225b9a9ff02d0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-pagerduty.serviceIntegration.ServiceIntegrationEmailParser",
    jsii_struct_bases=[],
    name_mapping={
        "action": "action",
        "match_predicate": "matchPredicate",
        "value_extractor": "valueExtractor",
    },
)
class ServiceIntegrationEmailParser:
    def __init__(
        self,
        *,
        action: builtins.str,
        match_predicate: typing.Union["ServiceIntegrationEmailParserMatchPredicate", typing.Dict[builtins.str, typing.Any]],
        value_extractor: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["ServiceIntegrationEmailParserValueExtractor", typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''
        :param action: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#action ServiceIntegration#action}.
        :param match_predicate: match_predicate block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#match_predicate ServiceIntegration#match_predicate}
        :param value_extractor: value_extractor block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#value_extractor ServiceIntegration#value_extractor}
        '''
        if isinstance(match_predicate, dict):
            match_predicate = ServiceIntegrationEmailParserMatchPredicate(**match_predicate)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5511e9b09efe25dca1d82427fc5585f913f0f248b2105ffd0ee0f31f9f7b63a7)
            check_type(argname="argument action", value=action, expected_type=type_hints["action"])
            check_type(argname="argument match_predicate", value=match_predicate, expected_type=type_hints["match_predicate"])
            check_type(argname="argument value_extractor", value=value_extractor, expected_type=type_hints["value_extractor"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "action": action,
            "match_predicate": match_predicate,
        }
        if value_extractor is not None:
            self._values["value_extractor"] = value_extractor

    @builtins.property
    def action(self) -> builtins.str:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#action ServiceIntegration#action}.'''
        result = self._values.get("action")
        assert result is not None, "Required property 'action' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def match_predicate(self) -> "ServiceIntegrationEmailParserMatchPredicate":
        '''match_predicate block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#match_predicate ServiceIntegration#match_predicate}
        '''
        result = self._values.get("match_predicate")
        assert result is not None, "Required property 'match_predicate' is missing"
        return typing.cast("ServiceIntegrationEmailParserMatchPredicate", result)

    @builtins.property
    def value_extractor(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceIntegrationEmailParserValueExtractor"]]]:
        '''value_extractor block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#value_extractor ServiceIntegration#value_extractor}
        '''
        result = self._values.get("value_extractor")
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceIntegrationEmailParserValueExtractor"]]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ServiceIntegrationEmailParser(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ServiceIntegrationEmailParserList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-pagerduty.serviceIntegration.ServiceIntegrationEmailParserList",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7207ddb6cb9d28d21b5f69ec3584f7c49650bad9bc0542c7ff19d1fce89c84ca)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(self, index: jsii.Number) -> "ServiceIntegrationEmailParserOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1898e575c74837b27bccb0168018a7148f4313e6aaac03d443f1e140435a7edb)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("ServiceIntegrationEmailParserOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b25a918884480de09f9e56af280edc0f4890a0ab829a0f026c685cf6ed0e81c4)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> "_cdktn_78ede62e.IInterpolatingParent":
        '''The parent resource.'''
        return typing.cast("_cdktn_78ede62e.IInterpolatingParent", jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(
        self,
        value: "_cdktn_78ede62e.IInterpolatingParent",
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__24d1b8fbac7d874e0ecf149fe0c11c92ef13c899a2515807d457ebda7d45b29e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6138be4f285e9c6196713a874f1db007f20ecef1cc987da41743ce1c76d9b30d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceIntegrationEmailParser"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceIntegrationEmailParser"]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceIntegrationEmailParser"]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e8f555adb0cd55647a0fd940612c41fef6858c5400617795884797ba0f361a5f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-pagerduty.serviceIntegration.ServiceIntegrationEmailParserMatchPredicate",
    jsii_struct_bases=[],
    name_mapping={"type": "type", "predicate": "predicate"},
)
class ServiceIntegrationEmailParserMatchPredicate:
    def __init__(
        self,
        *,
        type: builtins.str,
        predicate: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["ServiceIntegrationEmailParserMatchPredicatePredicate", typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''
        :param type: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#type ServiceIntegration#type}.
        :param predicate: predicate block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#predicate ServiceIntegration#predicate}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__139a3add752de349613647a1f98ab8fbe843ef0a344538bb9317b51c2f1b87dd)
            check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            check_type(argname="argument predicate", value=predicate, expected_type=type_hints["predicate"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "type": type,
        }
        if predicate is not None:
            self._values["predicate"] = predicate

    @builtins.property
    def type(self) -> builtins.str:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#type ServiceIntegration#type}.'''
        result = self._values.get("type")
        assert result is not None, "Required property 'type' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def predicate(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceIntegrationEmailParserMatchPredicatePredicate"]]]:
        '''predicate block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#predicate ServiceIntegration#predicate}
        '''
        result = self._values.get("predicate")
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceIntegrationEmailParserMatchPredicatePredicate"]]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ServiceIntegrationEmailParserMatchPredicate(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ServiceIntegrationEmailParserMatchPredicateOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-pagerduty.serviceIntegration.ServiceIntegrationEmailParserMatchPredicateOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__718b490acdd5bbfa6c6f6e1d8b199afd9c3d4b2c07ab58db85576f8e8bd2f998)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putPredicate")
    def put_predicate(
        self,
        value: typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["ServiceIntegrationEmailParserMatchPredicatePredicate", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__28762d85d0045795cc1e4f1f08bfd2cee6371cedee1bf1c25ffa5ac19f03cac0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putPredicate", [value]))

    @jsii.member(jsii_name="resetPredicate")
    def reset_predicate(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPredicate", []))

    @builtins.property
    @jsii.member(jsii_name="predicate")
    def predicate(self) -> "ServiceIntegrationEmailParserMatchPredicatePredicateList":
        return typing.cast("ServiceIntegrationEmailParserMatchPredicatePredicateList", jsii.get(self, "predicate"))

    @builtins.property
    @jsii.member(jsii_name="predicateInput")
    def predicate_input(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceIntegrationEmailParserMatchPredicatePredicate"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceIntegrationEmailParserMatchPredicatePredicate"]]], jsii.get(self, "predicateInput"))

    @builtins.property
    @jsii.member(jsii_name="typeInput")
    def type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "typeInput"))

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @type.setter
    def type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__41639c5f867a9c45faddfe5da33edee34dc8f239aaa96d3fd38427d23ce10a72)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "type", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["ServiceIntegrationEmailParserMatchPredicate"]:
        return typing.cast(typing.Optional["ServiceIntegrationEmailParserMatchPredicate"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["ServiceIntegrationEmailParserMatchPredicate"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2ff49ea23db156f8b75ae86d4df1e8336a1559924b1b0269ff244d2f4afb9aed)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-pagerduty.serviceIntegration.ServiceIntegrationEmailParserMatchPredicatePredicate",
    jsii_struct_bases=[],
    name_mapping={
        "type": "type",
        "matcher": "matcher",
        "part": "part",
        "predicate": "predicate",
    },
)
class ServiceIntegrationEmailParserMatchPredicatePredicate:
    def __init__(
        self,
        *,
        type: builtins.str,
        matcher: typing.Optional[builtins.str] = None,
        part: typing.Optional[builtins.str] = None,
        predicate: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["ServiceIntegrationEmailParserMatchPredicatePredicatePredicate", typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''
        :param type: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#type ServiceIntegration#type}.
        :param matcher: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#matcher ServiceIntegration#matcher}.
        :param part: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#part ServiceIntegration#part}.
        :param predicate: predicate block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#predicate ServiceIntegration#predicate}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1bad21858fcb7fe0c6076ce4d8044ffff6033ba55ca223251c67979204789ff1)
            check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            check_type(argname="argument matcher", value=matcher, expected_type=type_hints["matcher"])
            check_type(argname="argument part", value=part, expected_type=type_hints["part"])
            check_type(argname="argument predicate", value=predicate, expected_type=type_hints["predicate"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "type": type,
        }
        if matcher is not None:
            self._values["matcher"] = matcher
        if part is not None:
            self._values["part"] = part
        if predicate is not None:
            self._values["predicate"] = predicate

    @builtins.property
    def type(self) -> builtins.str:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#type ServiceIntegration#type}.'''
        result = self._values.get("type")
        assert result is not None, "Required property 'type' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def matcher(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#matcher ServiceIntegration#matcher}.'''
        result = self._values.get("matcher")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def part(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#part ServiceIntegration#part}.'''
        result = self._values.get("part")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def predicate(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceIntegrationEmailParserMatchPredicatePredicatePredicate"]]]:
        '''predicate block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#predicate ServiceIntegration#predicate}
        '''
        result = self._values.get("predicate")
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceIntegrationEmailParserMatchPredicatePredicatePredicate"]]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ServiceIntegrationEmailParserMatchPredicatePredicate(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ServiceIntegrationEmailParserMatchPredicatePredicateList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-pagerduty.serviceIntegration.ServiceIntegrationEmailParserMatchPredicatePredicateList",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2834b0a88530dca5dabd5dd66d2ffb15842834d98db2dfcad462c4e6c71132e9)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "ServiceIntegrationEmailParserMatchPredicatePredicateOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__90a796d9e77944ccb1bf94641c08f6829d2193b9fad4672465be7c49ba0575e3)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("ServiceIntegrationEmailParserMatchPredicatePredicateOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bce6bea0ca8f001ce5ed6fa2f1049be7c06f89b3559dd52f3355b0544b8b32f1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> "_cdktn_78ede62e.IInterpolatingParent":
        '''The parent resource.'''
        return typing.cast("_cdktn_78ede62e.IInterpolatingParent", jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(
        self,
        value: "_cdktn_78ede62e.IInterpolatingParent",
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e9f8f7541ece298c7ad2c20e5dee22226ae09320e959b03ec3993efa18d0a414)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ec99847e50e12af559c29d87397b0445d55ce793b6d99700db62f0234b939109)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceIntegrationEmailParserMatchPredicatePredicate"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceIntegrationEmailParserMatchPredicatePredicate"]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceIntegrationEmailParserMatchPredicatePredicate"]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e967369fe874e67fa606acb51d4a494c022a35a8f91b011548aca0ae48e63b7f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class ServiceIntegrationEmailParserMatchPredicatePredicateOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-pagerduty.serviceIntegration.ServiceIntegrationEmailParserMatchPredicatePredicateOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bcfa025b2458969fd8e0dacdc3bc0225ec36bc418d5861e8996cf95da7d8a585)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="putPredicate")
    def put_predicate(
        self,
        value: typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["ServiceIntegrationEmailParserMatchPredicatePredicatePredicate", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__538737174e7d990f7a22d9510ac28fcd41d6a8eeb195df23756b4106f20c514c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putPredicate", [value]))

    @jsii.member(jsii_name="resetMatcher")
    def reset_matcher(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMatcher", []))

    @jsii.member(jsii_name="resetPart")
    def reset_part(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPart", []))

    @jsii.member(jsii_name="resetPredicate")
    def reset_predicate(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPredicate", []))

    @builtins.property
    @jsii.member(jsii_name="predicate")
    def predicate(
        self,
    ) -> "ServiceIntegrationEmailParserMatchPredicatePredicatePredicateList":
        return typing.cast("ServiceIntegrationEmailParserMatchPredicatePredicatePredicateList", jsii.get(self, "predicate"))

    @builtins.property
    @jsii.member(jsii_name="matcherInput")
    def matcher_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "matcherInput"))

    @builtins.property
    @jsii.member(jsii_name="partInput")
    def part_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "partInput"))

    @builtins.property
    @jsii.member(jsii_name="predicateInput")
    def predicate_input(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceIntegrationEmailParserMatchPredicatePredicatePredicate"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceIntegrationEmailParserMatchPredicatePredicatePredicate"]]], jsii.get(self, "predicateInput"))

    @builtins.property
    @jsii.member(jsii_name="typeInput")
    def type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "typeInput"))

    @builtins.property
    @jsii.member(jsii_name="matcher")
    def matcher(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "matcher"))

    @matcher.setter
    def matcher(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__95526bff02cf05f8adf06a039dcb22da51ac1ab0e41d70d06d20a43e7c67d39c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "matcher", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="part")
    def part(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "part"))

    @part.setter
    def part(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__73c10e7f8f1291ae6a64f7bc2cd69c7fb3cfe45a7ed793fb5cccc0a81d2884e5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "part", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @type.setter
    def type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__91315e0b572effe45e65e613e24c9cf903e191986132791e9ea58d67130d5053)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "type", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "ServiceIntegrationEmailParserMatchPredicatePredicate"]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "ServiceIntegrationEmailParserMatchPredicatePredicate"]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "ServiceIntegrationEmailParserMatchPredicatePredicate"]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4eabdeb07bb8159eef2c738fd6c7cb1a5a106ca1dd0a711e4177bd8e7f4e72bd)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-pagerduty.serviceIntegration.ServiceIntegrationEmailParserMatchPredicatePredicatePredicate",
    jsii_struct_bases=[],
    name_mapping={"matcher": "matcher", "part": "part", "type": "type"},
)
class ServiceIntegrationEmailParserMatchPredicatePredicatePredicate:
    def __init__(
        self,
        *,
        matcher: builtins.str,
        part: builtins.str,
        type: builtins.str,
    ) -> None:
        '''
        :param matcher: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#matcher ServiceIntegration#matcher}.
        :param part: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#part ServiceIntegration#part}.
        :param type: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#type ServiceIntegration#type}.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f402f39fae9a16c4db0fbcaed1bc27152f94ef6eef771f184283f074d4e4cf67)
            check_type(argname="argument matcher", value=matcher, expected_type=type_hints["matcher"])
            check_type(argname="argument part", value=part, expected_type=type_hints["part"])
            check_type(argname="argument type", value=type, expected_type=type_hints["type"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "matcher": matcher,
            "part": part,
            "type": type,
        }

    @builtins.property
    def matcher(self) -> builtins.str:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#matcher ServiceIntegration#matcher}.'''
        result = self._values.get("matcher")
        assert result is not None, "Required property 'matcher' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def part(self) -> builtins.str:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#part ServiceIntegration#part}.'''
        result = self._values.get("part")
        assert result is not None, "Required property 'part' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def type(self) -> builtins.str:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#type ServiceIntegration#type}.'''
        result = self._values.get("type")
        assert result is not None, "Required property 'type' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ServiceIntegrationEmailParserMatchPredicatePredicatePredicate(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ServiceIntegrationEmailParserMatchPredicatePredicatePredicateList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-pagerduty.serviceIntegration.ServiceIntegrationEmailParserMatchPredicatePredicatePredicateList",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ce70f3d8b8682760edee371077a99f2a6c7df6969981becc417ed9f2e5b89c41)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "ServiceIntegrationEmailParserMatchPredicatePredicatePredicateOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3ddcce6b82fe3d18a4007e22ab1ff7dd6a904e80b0da6e03f07b29fc946ea77e)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("ServiceIntegrationEmailParserMatchPredicatePredicatePredicateOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__709868c389903c37decbddedbbc3bf153fb7c575cee982fb533bcb418da74ce8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> "_cdktn_78ede62e.IInterpolatingParent":
        '''The parent resource.'''
        return typing.cast("_cdktn_78ede62e.IInterpolatingParent", jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(
        self,
        value: "_cdktn_78ede62e.IInterpolatingParent",
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e366f254709f9510bd7886df8ff643f940e0dc80356fbd933b2038e00407098d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0bd3076fd6122e8411828dfa228e129c5e0ae9b050782874f99b8a1365c94ebe)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceIntegrationEmailParserMatchPredicatePredicatePredicate"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceIntegrationEmailParserMatchPredicatePredicatePredicate"]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceIntegrationEmailParserMatchPredicatePredicatePredicate"]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__12b6e78149a3f6dbccd15e396dcca0766a2ba7c49b0d9bdf35ea4f7b6b8c704e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class ServiceIntegrationEmailParserMatchPredicatePredicatePredicateOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-pagerduty.serviceIntegration.ServiceIntegrationEmailParserMatchPredicatePredicatePredicateOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2950288f4cf3ca91740ce4e34f858a23d95977cc303dc149e5e48ce2d9223daa)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="matcherInput")
    def matcher_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "matcherInput"))

    @builtins.property
    @jsii.member(jsii_name="partInput")
    def part_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "partInput"))

    @builtins.property
    @jsii.member(jsii_name="typeInput")
    def type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "typeInput"))

    @builtins.property
    @jsii.member(jsii_name="matcher")
    def matcher(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "matcher"))

    @matcher.setter
    def matcher(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6c125cfe1ddb8a3b002fba6ffe94c71a5b8cb9ed36cabc5335fc14a7562e108a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "matcher", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="part")
    def part(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "part"))

    @part.setter
    def part(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bb47aeb0c58537361dc136a0a75d71e273947071fd5409c238ba7fb6d5cfd905)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "part", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @type.setter
    def type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8ddc2b4ac79650ff7d174345ec8052571cc8ad20f52fa03ef91c10a21ab9a97c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "type", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "ServiceIntegrationEmailParserMatchPredicatePredicatePredicate"]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "ServiceIntegrationEmailParserMatchPredicatePredicatePredicate"]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "ServiceIntegrationEmailParserMatchPredicatePredicatePredicate"]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3742d9524c0860cab7b4c7fd023422866fa23b4fb7b381b9440b240eb1d5eef1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class ServiceIntegrationEmailParserOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-pagerduty.serviceIntegration.ServiceIntegrationEmailParserOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e6d192c889117e92c0d6fefc1258a132989938feae5eeb78ec3d0ea0cee9b60d)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="putMatchPredicate")
    def put_match_predicate(
        self,
        *,
        type: builtins.str,
        predicate: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["ServiceIntegrationEmailParserMatchPredicatePredicate", typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''
        :param type: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#type ServiceIntegration#type}.
        :param predicate: predicate block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#predicate ServiceIntegration#predicate}
        '''
        value = ServiceIntegrationEmailParserMatchPredicate(
            type=type, predicate=predicate
        )

        return typing.cast(None, jsii.invoke(self, "putMatchPredicate", [value]))

    @jsii.member(jsii_name="putValueExtractor")
    def put_value_extractor(
        self,
        value: typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["ServiceIntegrationEmailParserValueExtractor", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e2a05fa137eb9e811ce0af16983c107b9cc6644a3b984835a57f5d02dbc808bf)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putValueExtractor", [value]))

    @jsii.member(jsii_name="resetValueExtractor")
    def reset_value_extractor(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetValueExtractor", []))

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "id"))

    @builtins.property
    @jsii.member(jsii_name="matchPredicate")
    def match_predicate(
        self,
    ) -> "ServiceIntegrationEmailParserMatchPredicateOutputReference":
        return typing.cast("ServiceIntegrationEmailParserMatchPredicateOutputReference", jsii.get(self, "matchPredicate"))

    @builtins.property
    @jsii.member(jsii_name="valueExtractor")
    def value_extractor(self) -> "ServiceIntegrationEmailParserValueExtractorList":
        return typing.cast("ServiceIntegrationEmailParserValueExtractorList", jsii.get(self, "valueExtractor"))

    @builtins.property
    @jsii.member(jsii_name="actionInput")
    def action_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "actionInput"))

    @builtins.property
    @jsii.member(jsii_name="matchPredicateInput")
    def match_predicate_input(
        self,
    ) -> typing.Optional["ServiceIntegrationEmailParserMatchPredicate"]:
        return typing.cast(typing.Optional["ServiceIntegrationEmailParserMatchPredicate"], jsii.get(self, "matchPredicateInput"))

    @builtins.property
    @jsii.member(jsii_name="valueExtractorInput")
    def value_extractor_input(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceIntegrationEmailParserValueExtractor"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceIntegrationEmailParserValueExtractor"]]], jsii.get(self, "valueExtractorInput"))

    @builtins.property
    @jsii.member(jsii_name="action")
    def action(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "action"))

    @action.setter
    def action(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__423ad11e713135e7f5dea2b5c272c30266e682715449feb01d322311f7c6d942)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "action", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "ServiceIntegrationEmailParser"]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "ServiceIntegrationEmailParser"]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "ServiceIntegrationEmailParser"]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c6ec7a83ce29b70b703fb217e5f03a7e9c78baf159d8077e74e9cd2b71f2df35)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-pagerduty.serviceIntegration.ServiceIntegrationEmailParserValueExtractor",
    jsii_struct_bases=[],
    name_mapping={
        "part": "part",
        "type": "type",
        "value_name": "valueName",
        "ends_before": "endsBefore",
        "regex": "regex",
        "starts_after": "startsAfter",
    },
)
class ServiceIntegrationEmailParserValueExtractor:
    def __init__(
        self,
        *,
        part: builtins.str,
        type: builtins.str,
        value_name: builtins.str,
        ends_before: typing.Optional[builtins.str] = None,
        regex: typing.Optional[builtins.str] = None,
        starts_after: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param part: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#part ServiceIntegration#part}.
        :param type: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#type ServiceIntegration#type}.
        :param value_name: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#value_name ServiceIntegration#value_name}.
        :param ends_before: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#ends_before ServiceIntegration#ends_before}.
        :param regex: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#regex ServiceIntegration#regex}.
        :param starts_after: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#starts_after ServiceIntegration#starts_after}.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4256dd671eca9a18d8163558ffec49d8eb20f4f767dd06fbcded908865bf7a11)
            check_type(argname="argument part", value=part, expected_type=type_hints["part"])
            check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            check_type(argname="argument value_name", value=value_name, expected_type=type_hints["value_name"])
            check_type(argname="argument ends_before", value=ends_before, expected_type=type_hints["ends_before"])
            check_type(argname="argument regex", value=regex, expected_type=type_hints["regex"])
            check_type(argname="argument starts_after", value=starts_after, expected_type=type_hints["starts_after"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "part": part,
            "type": type,
            "value_name": value_name,
        }
        if ends_before is not None:
            self._values["ends_before"] = ends_before
        if regex is not None:
            self._values["regex"] = regex
        if starts_after is not None:
            self._values["starts_after"] = starts_after

    @builtins.property
    def part(self) -> builtins.str:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#part ServiceIntegration#part}.'''
        result = self._values.get("part")
        assert result is not None, "Required property 'part' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def type(self) -> builtins.str:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#type ServiceIntegration#type}.'''
        result = self._values.get("type")
        assert result is not None, "Required property 'type' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def value_name(self) -> builtins.str:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#value_name ServiceIntegration#value_name}.'''
        result = self._values.get("value_name")
        assert result is not None, "Required property 'value_name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def ends_before(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#ends_before ServiceIntegration#ends_before}.'''
        result = self._values.get("ends_before")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def regex(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#regex ServiceIntegration#regex}.'''
        result = self._values.get("regex")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def starts_after(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.2/docs/resources/service_integration#starts_after ServiceIntegration#starts_after}.'''
        result = self._values.get("starts_after")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ServiceIntegrationEmailParserValueExtractor(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ServiceIntegrationEmailParserValueExtractorList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-pagerduty.serviceIntegration.ServiceIntegrationEmailParserValueExtractorList",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2b6d594c752d1f7c8893ce06eb4b84cb486a736977c38f95617888ec2d866e6e)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "ServiceIntegrationEmailParserValueExtractorOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5cf6586e8ae5f36f3d5353817050dcb7c3a4f7b5cf545b7649096262283f1efd)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("ServiceIntegrationEmailParserValueExtractorOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__75515b6bf15478fc475a230fdade6558ff44355d345a4f2bde55d3eb35efdea5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> "_cdktn_78ede62e.IInterpolatingParent":
        '''The parent resource.'''
        return typing.cast("_cdktn_78ede62e.IInterpolatingParent", jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(
        self,
        value: "_cdktn_78ede62e.IInterpolatingParent",
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ee5175a4a1a0158e308ba5f394b8366472f488e8e95350de912527e3a41285c5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__55176248ced78001f3ea4b71b3bf8f68f95401312104d4410ab35e195db0039b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceIntegrationEmailParserValueExtractor"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceIntegrationEmailParserValueExtractor"]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["ServiceIntegrationEmailParserValueExtractor"]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8793d6e2101447eff374628f57dd4a44f5c783185d024f8b9e7aa6c700db3704)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class ServiceIntegrationEmailParserValueExtractorOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-pagerduty.serviceIntegration.ServiceIntegrationEmailParserValueExtractorOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7bfcce1c80c9c56dceb40d2873be5191ed7ed6a6e1546eae2d799e2625206d5e)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="resetEndsBefore")
    def reset_ends_before(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEndsBefore", []))

    @jsii.member(jsii_name="resetRegex")
    def reset_regex(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRegex", []))

    @jsii.member(jsii_name="resetStartsAfter")
    def reset_starts_after(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetStartsAfter", []))

    @builtins.property
    @jsii.member(jsii_name="endsBeforeInput")
    def ends_before_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "endsBeforeInput"))

    @builtins.property
    @jsii.member(jsii_name="partInput")
    def part_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "partInput"))

    @builtins.property
    @jsii.member(jsii_name="regexInput")
    def regex_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "regexInput"))

    @builtins.property
    @jsii.member(jsii_name="startsAfterInput")
    def starts_after_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "startsAfterInput"))

    @builtins.property
    @jsii.member(jsii_name="typeInput")
    def type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "typeInput"))

    @builtins.property
    @jsii.member(jsii_name="valueNameInput")
    def value_name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "valueNameInput"))

    @builtins.property
    @jsii.member(jsii_name="endsBefore")
    def ends_before(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "endsBefore"))

    @ends_before.setter
    def ends_before(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0c64c773d089245414857875a92189f61b964e443debc0aec71ce8dde8a9c250)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "endsBefore", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="part")
    def part(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "part"))

    @part.setter
    def part(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__18aea6e04f7db679ecd7b1d29f679fafc16498a961d5516324c353d764930b36)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "part", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="regex")
    def regex(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "regex"))

    @regex.setter
    def regex(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4e1da29f03692839b095599d128f86866c909044f3646cc798073777a24802db)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "regex", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="startsAfter")
    def starts_after(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "startsAfter"))

    @starts_after.setter
    def starts_after(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c47da5df6e27fd6255ae449b451910019265fbd7d8fec7bdedeeb5e788d6fadc)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "startsAfter", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @type.setter
    def type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7d1d38aebbade6521474783904857e554e19006ec84753f27983ff8befbe9429)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "type", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="valueName")
    def value_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "valueName"))

    @value_name.setter
    def value_name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bd281661ea8b2b96a260cf951ee89e2d4f3417d8bce4ea12c8824f88f72885f2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "valueName", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "ServiceIntegrationEmailParserValueExtractor"]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "ServiceIntegrationEmailParserValueExtractor"]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "ServiceIntegrationEmailParserValueExtractor"]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ffdec95a59511fcc24f20c5a88be065e398dfa8f69dc9ea30f1e575eea1cf54e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


__all__ = [
    "ServiceIntegration",
    "ServiceIntegrationConfig",
    "ServiceIntegrationEmailFilter",
    "ServiceIntegrationEmailFilterList",
    "ServiceIntegrationEmailFilterOutputReference",
    "ServiceIntegrationEmailParser",
    "ServiceIntegrationEmailParserList",
    "ServiceIntegrationEmailParserMatchPredicate",
    "ServiceIntegrationEmailParserMatchPredicateOutputReference",
    "ServiceIntegrationEmailParserMatchPredicatePredicate",
    "ServiceIntegrationEmailParserMatchPredicatePredicateList",
    "ServiceIntegrationEmailParserMatchPredicatePredicateOutputReference",
    "ServiceIntegrationEmailParserMatchPredicatePredicatePredicate",
    "ServiceIntegrationEmailParserMatchPredicatePredicatePredicateList",
    "ServiceIntegrationEmailParserMatchPredicatePredicatePredicateOutputReference",
    "ServiceIntegrationEmailParserOutputReference",
    "ServiceIntegrationEmailParserValueExtractor",
    "ServiceIntegrationEmailParserValueExtractorList",
    "ServiceIntegrationEmailParserValueExtractorOutputReference",
]

publication.publish()

def _typecheckingstub__028267ba12aac17ac17a74f615c9d97cbf66ff01d3ce7809d6bc02bee4272f46(
    scope: _constructs_77d1e7e8.Construct,
    id_: builtins.str,
    *,
    service: builtins.str,
    email_filter: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[ServiceIntegrationEmailFilter, typing.Dict[builtins.str, typing.Any]]]]] = None,
    email_filter_mode: typing.Optional[builtins.str] = None,
    email_incident_creation: typing.Optional[builtins.str] = None,
    email_parser: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[ServiceIntegrationEmailParser, typing.Dict[builtins.str, typing.Any]]]]] = None,
    email_parsing_fallback: typing.Optional[builtins.str] = None,
    id: typing.Optional[builtins.str] = None,
    integration_email: typing.Optional[builtins.str] = None,
    integration_key: typing.Optional[builtins.str] = None,
    name: typing.Optional[builtins.str] = None,
    type: typing.Optional[builtins.str] = None,
    vendor: typing.Optional[builtins.str] = None,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b78538808a51de65580bd180b840788ef54c9e54f0d10593dd8a67873e2e64e5(
    scope: _constructs_77d1e7e8.Construct,
    import_to_id: builtins.str,
    import_from_id: builtins.str,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__807909b3a3ab66bbd7ea265019c2afa0cb95e036bbe225f60d0620e848b7fbcb(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[ServiceIntegrationEmailFilter, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__38999d0826de30e32fcf0ba6467d8b99bac07aa1d280dd7cf0476da35f41c41b(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[ServiceIntegrationEmailParser, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2d937e8aeecf4f75eb73834acac6cdcdb648b31ac3b71fae50e0058c88391f98(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__771dfb5c897cfb3baecdd9dedcd2113f6c402b56841dddfa42d0a3d5ad1e3d9a(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__63609ddcb62478ae0be41aaa8383f1d67b4f1e552e9160638b4b2d6b82ba5672(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0aaa70ff3277ca41ba76bd0f811732098362931a642b5652d7554e675a33cd5a(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5c9fedd8d89695bb9ac2f9cf9ef62937b503155c99f690ed9d38d5dd92c70440(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b57e5a2cec5d6933c415753ce47fe1798af8fb89a5bf5ac0e3991b2e53f03b23(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b780fb537b974a10065f0dae583f75b0844ec7fd129343dddece3a9f9d1e8b28(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ce1ff411c74fc04709f43da1fdc5e1348986efc301fefcb6b8caec63b641deee(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2ead76e48cb99434c92b8ab00f361a17ae854464a3b6a3a43f8ad5da9ca8e875(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4796ea2e652a7c52e3f36a731329e591cb182e4116d25f7bff8ea709a5b5da23(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6821679a7913c3c38c195d141cdaf8a3d0ea3166cb1f697e9ab11223f6bda66b(
    *,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    service: builtins.str,
    email_filter: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[ServiceIntegrationEmailFilter, typing.Dict[builtins.str, typing.Any]]]]] = None,
    email_filter_mode: typing.Optional[builtins.str] = None,
    email_incident_creation: typing.Optional[builtins.str] = None,
    email_parser: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[ServiceIntegrationEmailParser, typing.Dict[builtins.str, typing.Any]]]]] = None,
    email_parsing_fallback: typing.Optional[builtins.str] = None,
    id: typing.Optional[builtins.str] = None,
    integration_email: typing.Optional[builtins.str] = None,
    integration_key: typing.Optional[builtins.str] = None,
    name: typing.Optional[builtins.str] = None,
    type: typing.Optional[builtins.str] = None,
    vendor: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__81b44b0f9f75af6896aca2aa17e37941c72753a9ec69fe66a720f8adb351535e(
    *,
    body_mode: typing.Optional[builtins.str] = None,
    body_regex: typing.Optional[builtins.str] = None,
    from_email_mode: typing.Optional[builtins.str] = None,
    from_email_regex: typing.Optional[builtins.str] = None,
    subject_mode: typing.Optional[builtins.str] = None,
    subject_regex: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a8bf5c8e4912c5fd85fd773195679ff3bbb92d587bcd76a5b15bba04bf88e6ac(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__86f620008cb370877803a1dbace7073d993cd0b546b1b99fc6ea15b6ce62edb9(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0c0ce651d4ae91f18ad14aac802aaf0835fc3c933a42c92d24ed048d5eda3141(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6bbe49a478354be66100175ec89bd7e1c02cab27f371a77b797a5f87e82c4218(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b5137d53db9ca2989afec9ef0555de2e78f3639847c72a34152597340adb0806(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b52455dc194a598cb8b0a66d52777ac9a9ea53b55ac4c1bed214bcd0c74deee0(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[ServiceIntegrationEmailFilter]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__02e2b2d9ee93fb67148b46b1aa583ae1cee973f64fb3e9441b21464969b987b3(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1519f58dba752c5cfe6714975d469caa99562974b0d6fe5245f8381776661c99(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6472bc9f2ec596c438f77ad322c95e491e998c58b6736b7ce98d6c780585fbd2(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f4d9521fdaec4ede1f92055bb1a77270321594462441aae668d4655b55f1b866(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8cf2eec5fd8a155c9f95cea0db5326b7a8703b994a6968acc85fad43af1b4013(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0a71ab2c9046118770c28990389ab7fdd821b335db24d369aea91dfd8c75a9b1(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c90c0aaf669ba46413e829692a0e2a9a0aaa28d2057f278420daa538d9e0eacf(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8d70922ea7177015d8b6929c4bf5fb71281133bea869e55d7d6225b9a9ff02d0(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, ServiceIntegrationEmailFilter]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5511e9b09efe25dca1d82427fc5585f913f0f248b2105ffd0ee0f31f9f7b63a7(
    *,
    action: builtins.str,
    match_predicate: typing.Union[ServiceIntegrationEmailParserMatchPredicate, typing.Dict[builtins.str, typing.Any]],
    value_extractor: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[ServiceIntegrationEmailParserValueExtractor, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7207ddb6cb9d28d21b5f69ec3584f7c49650bad9bc0542c7ff19d1fce89c84ca(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1898e575c74837b27bccb0168018a7148f4313e6aaac03d443f1e140435a7edb(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b25a918884480de09f9e56af280edc0f4890a0ab829a0f026c685cf6ed0e81c4(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__24d1b8fbac7d874e0ecf149fe0c11c92ef13c899a2515807d457ebda7d45b29e(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6138be4f285e9c6196713a874f1db007f20ecef1cc987da41743ce1c76d9b30d(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e8f555adb0cd55647a0fd940612c41fef6858c5400617795884797ba0f361a5f(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[ServiceIntegrationEmailParser]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__139a3add752de349613647a1f98ab8fbe843ef0a344538bb9317b51c2f1b87dd(
    *,
    type: builtins.str,
    predicate: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[ServiceIntegrationEmailParserMatchPredicatePredicate, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__718b490acdd5bbfa6c6f6e1d8b199afd9c3d4b2c07ab58db85576f8e8bd2f998(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__28762d85d0045795cc1e4f1f08bfd2cee6371cedee1bf1c25ffa5ac19f03cac0(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[ServiceIntegrationEmailParserMatchPredicatePredicate, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__41639c5f867a9c45faddfe5da33edee34dc8f239aaa96d3fd38427d23ce10a72(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2ff49ea23db156f8b75ae86d4df1e8336a1559924b1b0269ff244d2f4afb9aed(
    value: typing.Optional[ServiceIntegrationEmailParserMatchPredicate],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1bad21858fcb7fe0c6076ce4d8044ffff6033ba55ca223251c67979204789ff1(
    *,
    type: builtins.str,
    matcher: typing.Optional[builtins.str] = None,
    part: typing.Optional[builtins.str] = None,
    predicate: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[ServiceIntegrationEmailParserMatchPredicatePredicatePredicate, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2834b0a88530dca5dabd5dd66d2ffb15842834d98db2dfcad462c4e6c71132e9(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__90a796d9e77944ccb1bf94641c08f6829d2193b9fad4672465be7c49ba0575e3(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bce6bea0ca8f001ce5ed6fa2f1049be7c06f89b3559dd52f3355b0544b8b32f1(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e9f8f7541ece298c7ad2c20e5dee22226ae09320e959b03ec3993efa18d0a414(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ec99847e50e12af559c29d87397b0445d55ce793b6d99700db62f0234b939109(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e967369fe874e67fa606acb51d4a494c022a35a8f91b011548aca0ae48e63b7f(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[ServiceIntegrationEmailParserMatchPredicatePredicate]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bcfa025b2458969fd8e0dacdc3bc0225ec36bc418d5861e8996cf95da7d8a585(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__538737174e7d990f7a22d9510ac28fcd41d6a8eeb195df23756b4106f20c514c(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[ServiceIntegrationEmailParserMatchPredicatePredicatePredicate, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__95526bff02cf05f8adf06a039dcb22da51ac1ab0e41d70d06d20a43e7c67d39c(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__73c10e7f8f1291ae6a64f7bc2cd69c7fb3cfe45a7ed793fb5cccc0a81d2884e5(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__91315e0b572effe45e65e613e24c9cf903e191986132791e9ea58d67130d5053(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4eabdeb07bb8159eef2c738fd6c7cb1a5a106ca1dd0a711e4177bd8e7f4e72bd(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, ServiceIntegrationEmailParserMatchPredicatePredicate]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f402f39fae9a16c4db0fbcaed1bc27152f94ef6eef771f184283f074d4e4cf67(
    *,
    matcher: builtins.str,
    part: builtins.str,
    type: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ce70f3d8b8682760edee371077a99f2a6c7df6969981becc417ed9f2e5b89c41(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3ddcce6b82fe3d18a4007e22ab1ff7dd6a904e80b0da6e03f07b29fc946ea77e(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__709868c389903c37decbddedbbc3bf153fb7c575cee982fb533bcb418da74ce8(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e366f254709f9510bd7886df8ff643f940e0dc80356fbd933b2038e00407098d(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0bd3076fd6122e8411828dfa228e129c5e0ae9b050782874f99b8a1365c94ebe(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__12b6e78149a3f6dbccd15e396dcca0766a2ba7c49b0d9bdf35ea4f7b6b8c704e(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[ServiceIntegrationEmailParserMatchPredicatePredicatePredicate]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2950288f4cf3ca91740ce4e34f858a23d95977cc303dc149e5e48ce2d9223daa(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6c125cfe1ddb8a3b002fba6ffe94c71a5b8cb9ed36cabc5335fc14a7562e108a(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bb47aeb0c58537361dc136a0a75d71e273947071fd5409c238ba7fb6d5cfd905(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8ddc2b4ac79650ff7d174345ec8052571cc8ad20f52fa03ef91c10a21ab9a97c(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3742d9524c0860cab7b4c7fd023422866fa23b4fb7b381b9440b240eb1d5eef1(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, ServiceIntegrationEmailParserMatchPredicatePredicatePredicate]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e6d192c889117e92c0d6fefc1258a132989938feae5eeb78ec3d0ea0cee9b60d(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e2a05fa137eb9e811ce0af16983c107b9cc6644a3b984835a57f5d02dbc808bf(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[ServiceIntegrationEmailParserValueExtractor, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__423ad11e713135e7f5dea2b5c272c30266e682715449feb01d322311f7c6d942(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c6ec7a83ce29b70b703fb217e5f03a7e9c78baf159d8077e74e9cd2b71f2df35(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, ServiceIntegrationEmailParser]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4256dd671eca9a18d8163558ffec49d8eb20f4f767dd06fbcded908865bf7a11(
    *,
    part: builtins.str,
    type: builtins.str,
    value_name: builtins.str,
    ends_before: typing.Optional[builtins.str] = None,
    regex: typing.Optional[builtins.str] = None,
    starts_after: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2b6d594c752d1f7c8893ce06eb4b84cb486a736977c38f95617888ec2d866e6e(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5cf6586e8ae5f36f3d5353817050dcb7c3a4f7b5cf545b7649096262283f1efd(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__75515b6bf15478fc475a230fdade6558ff44355d345a4f2bde55d3eb35efdea5(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ee5175a4a1a0158e308ba5f394b8366472f488e8e95350de912527e3a41285c5(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__55176248ced78001f3ea4b71b3bf8f68f95401312104d4410ab35e195db0039b(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8793d6e2101447eff374628f57dd4a44f5c783185d024f8b9e7aa6c700db3704(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[ServiceIntegrationEmailParserValueExtractor]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7bfcce1c80c9c56dceb40d2873be5191ed7ed6a6e1546eae2d799e2625206d5e(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0c64c773d089245414857875a92189f61b964e443debc0aec71ce8dde8a9c250(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__18aea6e04f7db679ecd7b1d29f679fafc16498a961d5516324c353d764930b36(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4e1da29f03692839b095599d128f86866c909044f3646cc798073777a24802db(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c47da5df6e27fd6255ae449b451910019265fbd7d8fec7bdedeeb5e788d6fadc(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7d1d38aebbade6521474783904857e554e19006ec84753f27983ff8befbe9429(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bd281661ea8b2b96a260cf951ee89e2d4f3417d8bce4ea12c8824f88f72885f2(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ffdec95a59511fcc24f20c5a88be065e398dfa8f69dc9ea30f1e575eea1cf54e(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, ServiceIntegrationEmailParserValueExtractor]],
) -> None:
    """Type checking stubs"""
    pass
