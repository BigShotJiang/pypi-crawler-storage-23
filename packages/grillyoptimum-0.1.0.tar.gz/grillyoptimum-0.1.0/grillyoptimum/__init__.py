"""GrillyOptimum — HuggingFace Optimum-compatible Vulkan backend.

Optional grilly extension providing:
- VulkanModelForCausalLM: HF-compatible model with from_pretrained + generate
- VulkanConfig: Backend configuration
- Pipeline integration for HF transformers pipelines

Usage:
    from grillyoptimum import VulkanModelForCausalLM
    model = VulkanModelForCausalLM.from_pretrained("meta-llama/Llama-3.2-3B-Instruct")
    output = model.generate(input_ids, max_new_tokens=100)
"""

from .modeling import VulkanModelForCausalLM
from .configuration import VulkanConfig

__version__ = "0.1.0"

__all__ = [
    "VulkanModelForCausalLM",
    "VulkanConfig",
]
