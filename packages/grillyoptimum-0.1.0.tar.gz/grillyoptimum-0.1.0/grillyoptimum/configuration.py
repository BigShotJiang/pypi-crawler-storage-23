"""Vulkan backend configuration for HF Optimum compatibility."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class VulkanConfig:
    """Configuration for the Vulkan inference backend.

    Args:
        dtype: Weight precision ("fp16" or "fp32").
        use_vulkan: Whether to use Vulkan GPU acceleration.
        page_size: KV-cache page size (default 256).
        raw_window: Raw KV window (default 2048).
        enable_h2o: Enable H2O eviction for extended context.
        h2o_lambda: H2O decay rate.
        enable_vsa: Enable VSA multi-scale summaries.
        enable_quantization: Enable SmoothQuant INT8.
        quantize_group_size: INT8 quantization group size.
    """

    dtype: str = "fp16"
    use_vulkan: bool = True
    page_size: int = 256
    raw_window: int = 2048
    enable_h2o: bool = False
    h2o_lambda: float = 0.0002
    enable_vsa: bool = False
    enable_quantization: bool = False
    quantize_group_size: int = 64
    max_batch_size: int = 1
    device: str = "vulkan"

    def to_dict(self) -> dict:
        from dataclasses import asdict
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> VulkanConfig:
        valid_fields = {f.name for f in cls.__dataclass_fields__.values()}
        return cls(**{k: v for k, v in d.items() if k in valid_fields})
