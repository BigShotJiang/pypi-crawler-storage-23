import sys
import pandas as pd
import numpy as np
import os

def check_inputs():
    # 1. Check number of parameters [cite: 10]
    if len(sys.argv) != 5:
        print("Error: Wrong number of parameters.")
        print("Usage: python <program.py> <InputDataFile> <Weights> <Impacts> <OutputResultFileName>")
        print('Example: python topsis.py data.csv "1,1,1,1" "+,+,-,+" result.csv')
        sys.exit(1)

    input_file = sys.argv[1]
    weights_str = sys.argv[2]
    impacts_str = sys.argv[3]
    output_file = sys.argv[4]

    # 2. Check if input file exists [cite: 12]
    if not os.path.isfile(input_file):
        print(f"Error: File '{input_file}' not found.")
        sys.exit(1)

    return input_file, weights_str, impacts_str, output_file

def main():
    input_file, weights_str, impacts_str, output_file = check_inputs()

    try:
        # Load data (Try reading as CSV first, can be adapted for Excel if needed)
        # Assignment implies CSV usage in examples [cite: 8]
        df = pd.read_csv(input_file)
        
        # 3. Validation: Input file must contain three or more columns [cite: 13]
        if df.shape[1] < 3:
            print("Error: Input file must contain three or more columns.")
            sys.exit(1)

        # Separate non-numeric first column (ID) and numeric criteria
        dataset = df.iloc[:, 1:].values
        
        # 4. Validation: From 2nd to last columns must contain numeric values only [cite: 14]
        if not np.issubdtype(dataset.dtype, np.number):
             print("Error: Columns from 2nd to last must contain numeric values only.")
             sys.exit(1)

        # Parse Weights and Impacts
        try:
            weights = [float(w) for w in weights_str.split(',')]
            impacts = impacts_str.split(',')
        except ValueError:
            print("Error: Weights must be numeric and separated by commas.")
            sys.exit(1)

        # 5. Validation: Count of weights, impacts, and columns must match [cite: 15]
        num_cols = dataset.shape[1]
        if len(weights) != num_cols or len(impacts) != num_cols:
            print(f"Error: Number of weights ({len(weights)}), impacts ({len(impacts)}), "
                  f"and columns ({num_cols}) must be the same.")
            sys.exit(1)

        # 6. Validation: Impacts must be either '+' or '-' [cite: 16]
        if not all(i in ['+', '-'] for i in impacts):
            print("Error: Impacts must be either '+' or '-'.")
            sys.exit(1)

        # --- TOPSIS ALGORITHM ---
        
        # Step 1: Vector Normalization
        # Divide each value by the square root of the sum of squares of that column
        rss = np.sqrt(np.sum(dataset**2, axis=0))
        normalized_data = dataset / rss

        # Step 2: Weighted Normalized Decision Matrix
        weighted_data = normalized_data * weights

        # Step 3: Ideal Best (V+) and Ideal Worst (V-) values
        ideal_best = []
        ideal_worst = []

        for i in range(num_cols):
            if impacts[i] == '+':
                ideal_best.append(np.max(weighted_data[:, i]))
                ideal_worst.append(np.min(weighted_data[:, i]))
            else: # Impact is '-'
                ideal_best.append(np.min(weighted_data[:, i]))
                ideal_worst.append(np.max(weighted_data[:, i]))

        # Step 4: Euclidean Distance Calculation
        S_plus = np.sqrt(np.sum((weighted_data - ideal_best)**2, axis=1))
        S_minus = np.sqrt(np.sum((weighted_data - ideal_worst)**2, axis=1))

        # Step 5: Calculate Performance Score
        # Score = S_minus / (S_plus + S_minus)
        performance_score = S_minus / (S_plus + S_minus)

        # Step 6: Assign Score and Rank to dataframe
        df['Topsis Score'] = performance_score
        
        # Rank: Higher score is better. 
        # rank(ascending=False) gives rank 1 to highest score
        df['Rank'] = df['Topsis Score'].rank(ascending=False).astype(int)

        # Save to output file
        df.to_csv(output_file, index=False)
        print(f"Success: Result saved to {output_file}")

    except Exception as e:
        print(f"An unexpected error occurred: {e}")

if __name__ == "__main__":
    main()