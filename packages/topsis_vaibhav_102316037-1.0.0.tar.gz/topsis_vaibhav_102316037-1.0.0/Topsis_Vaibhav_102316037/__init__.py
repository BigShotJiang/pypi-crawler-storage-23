from .topsis import main

# This allows users to run it via: from Topsis_Vaibhav_102316037 import main
__version__ = '1.0.0'
