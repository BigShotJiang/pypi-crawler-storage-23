# TOPSIS-Vaibhav-102316037

A Python package to implement the Technique for Order of Preference by Similarity to Ideal Solution (TOPSIS).

## Installation
```bash
pip install Topsis-Vaibhav-102316037

```bash
topsis <InputDataFile> <Weights> <Impacts> <OutputResultFileName>

```bash
topsis data.csv "1,1,1,1,1" "+,+,-,+,+" result.csv