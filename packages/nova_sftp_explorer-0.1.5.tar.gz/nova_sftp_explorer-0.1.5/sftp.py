from ui import NovaSFTPExplorer


def main():
    app = NovaSFTPExplorer()
    app.mainloop()


if __name__ == "__main__":
    main()
