"""Smoke test — 100k interactions, verify entropy decrease and ops increase."""

import numpy as np
from abiogenesis.experiment import Experiment
from abiogenesis.metrics import compression_ratio


def test_smoke_100k():
    """Run 100k interactions and check basic trends."""
    config = {
        "n_tapes": 1024,
        "tape_len": 64,
        "max_steps_per_interaction": 10_000,
        "snapshot_interval": 10_000,
        "checkpoint_interval": 50_000,
        "seed": 12345,
        "output_dir": "/tmp/bff_smoke_test/",
    }

    exp = Experiment(config)

    # Record initial state
    initial_cr = compression_ratio(exp.soup.get_state())

    exp.run(n_interactions=100_000)

    # Basic checks
    assert exp.interaction_count == 100_000

    # Ops log should have values
    ops = exp.ops_log[:100_000]
    assert ops.sum() > 0, "Some interactions should execute instructions"

    # Snapshots should have been recorded
    assert len(exp.snapshot_interactions) > 0
    assert len(exp.snapshot_compression) > 0

    # Print summary for manual inspection
    print(f"\nSmoke test results:")
    print(f"  Initial compression ratio: {initial_cr:.4f}")
    print(f"  Final compression ratio:   {exp.snapshot_compression[-1]:.4f}")
    print(f"  Mean ops/interaction:       {float(ops.mean()):.2f}")
    print(f"  Max ops in single run:      {int(ops.max())}")
    print(f"  Non-zero ops interactions:  {int((ops > 0).sum())} / 100000")

    # At 100k interactions the soup may not have fully transitioned,
    # but we should see SOME activity
    assert int((ops > 0).sum()) > 100, "Expected at least some active interactions"
