# Contributing to Abiogenesis

Thanks for your interest in contributing.

## Development Setup

```bash
git clone https://github.com/dopexthrone/abiogenesis.git
cd abiogenesis
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
pytest tests/
```

## Running Tests

```bash
pytest tests/ -v          # all 92 tests
pytest tests/ -x          # stop on first failure
pytest tests/test_soup.py # single module
```

## Code Style

- Python 3.10+ with type hints
- No external dependencies beyond numpy (matplotlib is optional for viz)
- All internal imports use relative syntax (`from .module import ...`)
- Tests go in `tests/test_<module>.py`

## Adding Features

1. Core simulation modules (`interpreter.py`, `soup.py`, `metrics.py`, `probe.py`, `swarm.py`) are validated against 10M-interaction experiments. Changes to these require test coverage and must not break existing behavior.
2. New metrics or probes should go in their respective modules.
3. New experiment runners should follow the pattern in `experiment.py` / `swarm_runner.py`.
4. Export new public API items from `__init__.py`.

## Reporting Issues

Open an issue with:
- What you expected
- What happened
- Minimal reproduction code
- Python version and OS
