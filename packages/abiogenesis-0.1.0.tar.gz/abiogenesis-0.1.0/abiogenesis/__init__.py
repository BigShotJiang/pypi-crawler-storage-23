"""Abiogenesis — artificial life through symbiogenesis.

A soup of random byte tapes running a minimal Turing-complete interpreter
spontaneously produces self-replicating programs through symbiogenesis.
"""

__version__ = "0.1.0"

# Core
from .interpreter import execute, execute_traced
from .soup import Soup, InteractionResult

# Metrics
from .metrics import (
    compression_ratio,
    shannon_entropy,
    population_histogram,
    top_sequences,
    find_replicators,
    find_repeated_subsequences,
    classify_replicator,
    ReplicatorType,
    Replicator,
    depth_histogram,
)

# Probe
from .probe import CrystallizationProbe, ProbeReading

# Swarm
from .swarm import Agent, KTermFusion, DiversityProbe, Provenance

# Runners
from .experiment import Experiment
from .swarm_runner import SwarmExperiment
