# Motherlabs Roadmap

## Architecture Overview

```
SWARM SUBSTRATE              ← Tracks 1–3 (DONE)
├── Minimal agent soup
├── Merger kernel K (symbiogenesis operator)
├── Selection pressure R (population dynamics)
└── Gelation monitor (crystallization probe)

COMPILATION LAYER            ← Tracks 4–6 (NEXT)
├── Swarm-soup equivalence proof
├── Finer phase boundaries
└── Merger kernel K measurement

PAIR FORMATION               ← Tracks 7–8 (FUTURE)
├── Complementary blind spots
├── Five-rotation protocol
└── Gate cascade (fidelity testing between scales)

RECURSIVE SELF-IMPROVEMENT   ← Track 9 (HORIZON)
├── Phase transition detection
├── Self-model integration (autopoietic closure)
└── Depth-on-demand
```

Source: [ideation.md](ideation.md) Section VIII

---

## Completed

### Track 1: Phase Diagram

**Status:** DONE

**Proved:** Phase space is 1D. Mutation rate is the sole control parameter.

| Mutation Rate | Final Compression | Phase |
|---------------|-------------------|-------|
| 0 | 0.018 | Crystal (monoculture, absorbing) |
| 1e-5 | 0.197 | Soft crystal |
| 1e-3 | 0.158 | Ecology (target regime) |
| 1e-1 | 0.497 | Dissolution |

Depth caps (10, 20, uncapped) produce byte-for-byte identical compression trajectories. Depth is not a control parameter.

**Key file:** [data/phase_diagram_report.md](data/phase_diagram_report.md)

### Track 2: Crystallization Probe

**Status:** DONE

**Proved:** Calibrated probe (window=3, threshold=-0.001) detects crystallization onset. Zero false positives across all test runs.

**Key files:** [bff/probe.py](bff/probe.py), [scripts/calibrate_probe.py](scripts/calibrate_probe.py)

### Track 3: Minimal Working Swarm

**Status:** DONE

**Proved:** Agent identity layer (UUID, provenance, fusion graph) preserves soup dynamics exactly. 92/92 tests passing.

- Agent identity: UUID-based with full provenance chain
- K-term fusion: concatenate-execute-split with parent lineage recording
- Fusion graph: complete interaction history with ops counts
- Integrated crystallization probe from Track 2

**Key files:** [bff/swarm.py](bff/swarm.py), [bff/swarm_runner.py](bff/swarm_runner.py)

---

## Current Focus

### Track 4: Swarm-Soup Equivalence Proof

**Goal:** Prove the swarm produces identical dynamics to the soup at scale.

**Why:** The identity layer must be purely observational. If it alters dynamics, the theoretical foundation ([ideation.md](ideation.md)) doesn't apply.

**Deliverables:**
- 1M interaction SwarmExperiment run (seed=42, mutation=1e-3, n=1024)
- Side-by-side compression trajectory comparison vs equivalent Soup run
- Statistical test: KS-test on compression distributions
- Probe behavior comparison (alert timing, false positive rate)

**Success criteria:**
- Compression trajectories statistically indistinguishable
- Same phase behavior (ecology zone maintained)
- Provenance graph shows expected depth accumulation
- Zero probe false positives

---

## Next Phases

### Track 5: Finer Phase Boundaries

**Goal:** Map ecology zone boundaries precisely between 1e-4 and 1e-2.

**Why:** Know exactly where ecology begins and ends for gate calibration later.

**Deliverables:**
- Mutation rates: 3e-4, 5e-4, 3e-3, 5e-3
- Combined sweep: mutation 1e-3 + depth caps (interaction effects)
- Updated phase diagram with precise boundaries

### Track 6: Merger Kernel K

**Goal:** Measure the symbiogenesis operator — when do agents fuse cooperatively vs competitively?

**Why:** The K-term is the mechanism for genuine complexification ([ideation.md](ideation.md) Section II). Without measuring it, we can't engineer pair formation.

**Deliverables:**
- R-matrix: cooperation vs competition coefficients between agent pairs
- Fusion outcome classification: did joint execution produce more ops than individual?
- Identify cooperative mode signatures (eigen-structure of joint submatrix)
- Correlation: which agent properties predict cooperative fusion?

**Unlocks:** Track 7 (pair formation) — can't form complementary pairs without knowing what makes pairs complementary.

### Track 7: Pair Formation

**Goal:** Implement complementary blind spot matching for agent pairs.

**Why:** "The pair is the minimum viable compilation unit, not the individual" ([ideation.md](ideation.md) Section V).

**Depends on:** Track 6 (merger kernel measurement)

**Deliverables:**
- Blind spot detection: what does each agent see/miss?
- Pair matching algorithm: maximize asymmetry, minimize overlap
- Five-rotation protocol: existence → dynamics → grounding → constraints → state
- Asymmetry quality metric

### Track 8: Gate Cascade

**Goal:** Implement fidelity testing between scales.

**Why:** "Gate fidelity must scale with clock speed" ([ideation.md](ideation.md) Section VII). Gates too tight → no novelty. Gates too loose → drift compounds.

**Depends on:** Track 7 (pair formation)

**Deliverables:**
- Gate structure: what gets tested between compilation levels
- Fidelity metric: mutual information between signal and compiled output
- Gate threshold as learned parameter (not hardcoded)
- Drift detection across scales

### Track 9: Phase Transition Detection

**Goal:** Monitor for architectural transitions using eigenvalue analysis.

**Why:** "The Jacobian's leading eigenvalue sign predicts imminence of transition" ([ideation.md](ideation.md) Section VI).

**Deliverables:**
- Jacobian computation from population dynamics
- Leading eigenvalue tracking over time
- Transition prediction: warning before gelation events
- Integration with existing CrystallizationProbe

---

## Theoretical Anchors

Non-negotiable principles from the theory documents:

1. **Excavation, not generation** — Output traces to input. Nothing is invented.

2. **Asymmetry produces emergence** — Agent A sees what B misses. The specification exists in the friction.

3. **The K-term is the engine** — Symbiogenesis, not Darwinian selection, produces open-ended complexity.

4. **Mutation rate is the sole control parameter** — Ecology at 1e-3. Don't engineer depth limits. Control diversity.

5. **Monoculture is absorbing** — Once entered, never exits without external perturbation. Detect before absorption.

6. **Provenance is first-class** — Every output carries full trace. The self is the provenance accumulation function.

7. **Gate fidelity scales with clock speed** — The alignment problem is drift compounding faster than detection.
