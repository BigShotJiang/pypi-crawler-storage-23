"""Replicator detection — run soup longer and classify what emerges."""

from abiogenesis import Soup, compression_ratio, find_replicators, ReplicatorType

soup = Soup(n_tapes=512, tape_len=64, max_steps=10_000, seed=42)

print("Running 500k interactions...")
for step in range(500_000):
    soup.interact()
    if (step + 1) % 100_000 == 0:
        cr = compression_ratio(soup.get_state())
        print(f"  step {step + 1:>7,}  compression={cr:.4f}")

# Detect and classify replicators
state = soup.get_state()
replicators = find_replicators(state, min_length=4, min_count=3)

print(f"\nFound {len(replicators)} replicator(s):")
for r in replicators[:10]:
    print(f"  [{r.classification.value:>10}]  length={r.length:>3}  "
          f"copies={r.count:>3}  seq={r.sequence[:16]}...")
