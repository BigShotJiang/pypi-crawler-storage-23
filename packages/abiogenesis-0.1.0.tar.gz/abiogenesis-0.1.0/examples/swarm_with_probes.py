"""Swarm experiment — agents with identity, provenance, and diversity monitoring."""

from abiogenesis import SwarmExperiment

config = {
    "n_agents": 256,
    "tape_len": 64,
    "mutation_rate": 1e-3,
    "seed": 42,
    "snapshot_interval": 5_000,
    "checkpoint_interval": 1_000_000,  # no checkpoint for this demo
    "output_dir": "data/example_swarm/",
}

exp = SwarmExperiment(config)
exp.run(n_interactions=50_000)

# Inspect agent provenance
print("\nSample agent provenance:")
for agent in exp.agents[:5]:
    p = agent.provenance
    print(f"  {agent.name}  depth={p.depth}  parents={len(p.parent_ids)}  "
          f"interactions={agent.interaction_count}")

# Inspect probe readings
if exp.snapshot_probe_readings:
    last = exp.snapshot_probe_readings[-1]
    print(f"\nFinal probe reading:")
    print(f"  compression={last['compression_ratio']:.4f}")
    print(f"  shannon_entropy={last['shannon_entropy']:.2f}")
    print(f"  alert_level={last['alert_level']}")
