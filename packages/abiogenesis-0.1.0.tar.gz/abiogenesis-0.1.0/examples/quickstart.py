"""Quickstart — run a primordial soup and watch structure emerge."""

from abiogenesis import Soup, compression_ratio

soup = Soup(n_tapes=512, tape_len=64, max_steps=10_000, seed=42)

for step in range(100_000):
    soup.interact()
    if (step + 1) % 25_000 == 0:
        cr = compression_ratio(soup.get_state())
        print(f"  step {step + 1:>7,}  compression={cr:.4f}")

print("\nDone. Lower compression = more structure emerging from randomness.")
