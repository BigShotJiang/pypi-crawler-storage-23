"""RL Bot — base agent template customized per task."""

import json
import os
from pathlib import Path
from typing import Any

from dotenv import load_dotenv
from openai import OpenAI

load_dotenv(Path(__file__).resolve().parents[2] / ".env")

from openartemis.config import resolve_artemis_model

RL_BOT_BASE = """You are a coding agent with tools: read_file, write_file, list_dir, run_terminal, take_screenshot.
The lead role plans step-by-step; the worker role executes one step at a time using the tools.
Customize the lead and worker system prompts for this specific task while keeping the same JSON plan format and tool usage."""

CUSTOMIZE_PROMPT = """Given this user request: {user_request}

Customize the base agent for this task. Return a JSON object with two keys:
- "lead": system prompt for the planning role (must still ask for JSON steps with id, action, file; max 50 steps; output ONLY valid JSON)
- "worker": system prompt for the execution role (must still describe tools: read_file, write_file, list_dir, run_terminal, take_screenshot)

Keep both prompts concise. Adapt tone and focus to the task (e.g. game, web app, script).
Output ONLY valid JSON, no markdown."""


def customize_for_task(
    user_request: str,
    model: str = "gpt-4o-mini",
) -> dict[str, str]:
    """
    Call the model to produce task-specific lead_system and worker_system.
    Returns {"lead": "...", "worker": "..."}. Falls back to defaults if customization fails.
    """
    from openartemis.agent.agent_orchestrator import LEAD_SYSTEM, WORKER_SYSTEM

    default = {"lead": LEAD_SYSTEM, "worker": WORKER_SYSTEM}
    client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
    if not client.api_key:
        return default
    model = resolve_artemis_model(model) if isinstance(model, str) and "artemis" in model.lower() else model
    try:
        resp = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": RL_BOT_BASE},
                {"role": "user", "content": CUSTOMIZE_PROMPT.format(user_request=user_request)},
            ],
        )
        content = (resp.choices[0].message.content or "").strip()
        if content.startswith("```"):
            lines = content.split("\n")
            if lines[0].startswith("```"):
                lines = lines[1:]
            if lines and lines[-1].strip() == "```":
                lines = lines[:-1]
            content = "\n".join(lines)
        data = json.loads(content)
        lead = (data.get("lead") or "").strip()
        worker = (data.get("worker") or "").strip()
        if lead and worker:
            return {"lead": lead, "worker": worker}
    except (json.JSONDecodeError, KeyError, Exception):
        pass
    return default
