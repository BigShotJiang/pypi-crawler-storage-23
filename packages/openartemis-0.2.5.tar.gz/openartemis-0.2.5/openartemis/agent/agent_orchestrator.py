"""Agent orchestrator — lead model plans, worker executes with workspace tools."""

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

from dotenv import load_dotenv
from openai import OpenAI

load_dotenv(Path(__file__).resolve().parents[2] / ".env")

from openartemis.agent.agent_tools import (
    AGENT_TOOLS,
    AGENT_WORKSPACE,
    read_file,
    write_file,
    list_dir,
    run_terminal,
    take_screenshot,
)
from openartemis.agent.rl_bot import customize_for_task
from openartemis.config import resolve_artemis_model

LEAD_SYSTEM = """You are a coding lead. Given a user request, create a step-by-step plan to build it.

Output a JSON object:
{"steps": [
  {"id": 1, "action": "description of what to do", "file": "optional filename"},
  ...
]}

Rules:
- Break into small, concrete steps
- Each step should be one file write or one command
- For web apps: create index.html, add JS, then run server
- Max 50 steps (complex projects may need many steps)
- Output ONLY valid JSON, no markdown."""

WORKER_SYSTEM = """You are a coding worker. You execute ONE step at a time using your tools.

Tools: read_file, write_file, list_dir, run_terminal, take_screenshot.

- read_file(path) — read file contents
- write_file(path, content) — write or overwrite file
- list_dir(path) — list directory (default ".")
- run_terminal(command) — run command in workspace (e.g. "python -m http.server 8000")
- take_screenshot(url_or_path) — capture URL or file, get vision feedback (e.g. http://localhost:8000 after starting server)

Execute the step. For web apps: write HTML, start server, then take_screenshot to verify. Be concise."""


def _execute_agent_tool(name: str, args: dict) -> str:
    """Execute agent workspace tool."""
    if name == "read_file":
        return read_file(args.get("path", ""))
    if name == "write_file":
        return write_file(args.get("path", ""), args.get("content", ""))
    if name == "list_dir":
        return list_dir(args.get("path", "."))
    if name == "run_terminal":
        return run_terminal(args.get("command", ""))
    if name == "take_screenshot":
        return take_screenshot(
            args.get("url_or_path", ""),
            args.get("prompt", "Describe what you see. Any issues or improvements?"),
        )
    return f"Unknown tool: {name}"


def run_agent_mode(
    user_request: str,
    lead_model: str = "gpt-4o",
    worker_model: str = "gpt-4o-mini",
    on_status: Callable[[str], None] | None = None,
    max_steps: int = 50,
    output_path: Path | None = None,
) -> str:
    """
    Run agent mode: lead plans, worker executes. Returns final report.
    """
    client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
    lead_model = resolve_artemis_model(lead_model) if isinstance(lead_model, str) and "artemis" in lead_model.lower() else lead_model
    worker_model = resolve_artemis_model(worker_model) if isinstance(worker_model, str) and "artemis" in worker_model.lower() else worker_model

    AGENT_WORKSPACE.mkdir(parents=True, exist_ok=True)
    status_path = (output_path.with_name(output_path.name + ".status") if output_path else None)

    def _status(s: str) -> None:
        if on_status:
            on_status(s)
        if status_path:
            try:
                status_path.parent.mkdir(parents=True, exist_ok=True)
                status_path.write_text(s, encoding="utf-8")
            except Exception:
                pass

    _status("Creating plan...")
    customized = customize_for_task(user_request, model=lead_model)
    lead_system = customized["lead"]
    worker_system = customized["worker"]
    resp = client.chat.completions.create(
        model=lead_model,
        messages=[
            {"role": "system", "content": lead_system},
            {"role": "user", "content": user_request},
        ],
    )
    content = (resp.choices[0].message.content or "").strip()
    if content.startswith("```"):
        lines = content.split("\n")
        if lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        content = "\n".join(lines)
    try:
        data = json.loads(content)
        steps = data.get("steps", [])[:max_steps]
    except json.JSONDecodeError:
        return "Could not create plan. Please try rephrasing."

    if not steps:
        return "No steps in plan."

    report_parts = []
    for step in steps:
        step_id = step.get("id", 0)
        action = step.get("action", "")
        _status(f"Step {step_id}: {action[:50]}...")
        messages = [
            {"role": "system", "content": worker_system},
            {"role": "user", "content": f"Step {step_id}: {action}"},
        ]
        for _ in range(8):
            resp = client.chat.completions.create(
                model=worker_model,
                messages=messages,
                tools=AGENT_TOOLS,
                tool_choice="auto",
            )
            msg = resp.choices[0].message
            msg_dict = {
                "role": msg.role,
                "content": msg.content or "",
                "tool_calls": [{"id": tc.id, "function": {"name": tc.function.name, "arguments": tc.function.arguments}} for tc in (msg.tool_calls or [])],
            }
            messages.append(msg_dict)

            if not msg.tool_calls:
                report_parts.append(f"Step {step_id}: {msg.content or '(no output)'}")
                break

            for tc in msg.tool_calls:
                name = tc.function.name
                try:
                    args = json.loads(tc.function.arguments)
                except json.JSONDecodeError:
                    args = {}
                result = _execute_agent_tool(name, args)
                if name == "write_file":
                    _status(f"Writing {args.get('path', '')}...")
                elif name == "run_terminal":
                    _status(f"Running: {args.get('command', '')[:40]}...")
                elif name == "take_screenshot":
                    _status("Taking screenshot and reviewing...")
                messages.append({"role": "tool", "tool_call_id": tc.id, "content": result})
        else:
            report_parts.append(f"Step {step_id}: (max turns)")

    report = "\n\n".join(report_parts)
    _status("Done")

    if output_path:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(
            f"# Agent Report — {user_request}\n\n{datetime.now().isoformat()}\n\n---\n\n{report}",
            encoding="utf-8",
        )

    return report
