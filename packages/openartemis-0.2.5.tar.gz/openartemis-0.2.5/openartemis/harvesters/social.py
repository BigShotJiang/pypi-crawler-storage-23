"""Social harvester: TikTok, Instagram, X via ddgs web search + yt-dlp + Whisper."""

import logging
import re
import tempfile
from pathlib import Path
from typing import Any, Iterator

from ddgs import DDGS

from openartemis.harvesters.base import Harvester
from openartemis.output import write_post
from openartemis.transcription import transcribe_audio

logger = logging.getLogger(__name__)

PLATFORM_CONFIG = {
    "tiktok": {
        "site": "site:tiktok.com",
        "url_pattern": re.compile(r"https?://(?:www\.)?tiktok\.com/[\w/?#=&\-]+", re.I),
    },
    "instagram": {
        "site": "site:instagram.com/reel",
        "url_pattern": re.compile(r"https?://(?:www\.)?instagram\.com/reel/[\w\-]+[/?#]?", re.I),
    },
    "x": {
        "site": "site:x.com/status",
        "url_pattern": re.compile(
            r"https?://(?:www\.)?(?:x\.com|twitter\.com)/\w+/status/\d+", re.I
        ),
    },
}


class SocialHarvester(Harvester):
    """Harvest TikTok, Instagram, X via web search + yt-dlp + Whisper."""

    def __init__(self, platform: str):
        if platform not in PLATFORM_CONFIG:
            raise ValueError(f"Unknown platform: {platform}. Use one of: {list(PLATFORM_CONFIG)}")
        self.platform = platform
        self.config = PLATFORM_CONFIG[platform]

    def harvest(
        self,
        query: str,
        max_results: int,
        out_dir: Path,
        whisper_model: str = "base",
    ) -> Iterator[dict[str, Any]]:
        search_query = f"{query} {self.config['site']}"
        pattern = self.config["url_pattern"]
        seen_urls: set[str] = set()

        try:
            results = DDGS().text(search_query, max_results=max_results * 2)
        except Exception as e:
            logger.error("Web search failed: %s", e)
            return

        for r in results:
            href = r.get("href") or r.get("url", "")
            if not href or href in seen_urls:
                continue
            match = pattern.search(href)
            if not match:
                continue
            url = match.group(0).rstrip("/?#")
            if "?" in url:
                url = url.split("?")[0]
            if url in seen_urls:
                continue
            seen_urls.add(url)

            if len(seen_urls) > max_results:
                break

            try:
                data = self._download_and_transcribe(url, whisper_model)
                if data:
                    post_id = self._extract_id(url)
                    write_post(out_dir, self.platform, post_id, data)
                    yield data
            except Exception as e:
                logger.warning("Skipping %s: %s", url, e)
                continue

    def _extract_id(self, url: str) -> str:
        """Extract a short ID from URL for filenames."""
        parts = url.rstrip("/").split("/")
        for p in reversed(parts):
            if p and p not in ("reel", "video", "status"):
                return p[:32]
        return url.replace("https://", "").replace("http://", "")[:32]

    def _download_and_transcribe(self, url: str, whisper_model: str) -> dict[str, Any] | None:
        import yt_dlp

        with tempfile.TemporaryDirectory() as tmpdir:
            out_tmpl = str(Path(tmpdir) / "audio.%(ext)s")
            ydl_opts = {
                "format": "bestaudio/best",
                "postprocessors": [{
                    "key": "FFmpegExtractAudio",
                    "preferredcodec": "wav",
                }],
                "outtmpl": out_tmpl,
                "quiet": True,
            }
            info_dict = {}
            try:
                with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                    info_dict = ydl.extract_info(url, download=True) or {}
            except Exception as e:
                logger.warning("yt-dlp failed for %s: %s", url, e)
                return None

            audio_path = Path(tmpdir) / "audio.wav"
            if not audio_path.exists():
                audios = list(Path(tmpdir).glob("audio.*"))
                if not audios:
                    return None
                audio_path = audios[0]

            result = transcribe_audio(str(audio_path), whisper_model)
            title = info_dict.get("title") or url

            return {
                "url": url,
                "platform": self.platform,
                "title": title,
                "published_at": info_dict.get("upload_date") or "",
                "source": "whisper",
                "segments": result["segments"],
                "full_text": result["text"],
            }
