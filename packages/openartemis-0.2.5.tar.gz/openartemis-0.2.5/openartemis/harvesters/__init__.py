"""Harvesters for different platforms."""

from openartemis.harvesters.base import Harvester
from openartemis.harvesters.youtube import YouTubeHarvester
from openartemis.harvesters.social import SocialHarvester

__all__ = ["Harvester", "YouTubeHarvester", "SocialHarvester"]
