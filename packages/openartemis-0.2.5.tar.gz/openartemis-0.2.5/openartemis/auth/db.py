"""SQLite database for OpenArtemis auth."""

import hashlib
import json
import secrets
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from openartemis.auth.passwords import hash_password

DATA_DIR = Path.home() / ".openartemis"
DB_PATH = DATA_DIR / "openartemis.db"
SESSION_FILE = DATA_DIR / "session.json"


def _get_conn() -> sqlite3.Connection:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    """Create tables if they don't exist."""
    conn = _get_conn()
    try:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT NOT NULL,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                role TEXT NOT NULL DEFAULT 'user',
                approved INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL DEFAULT (datetime('now'))
            );
            CREATE TABLE IF NOT EXISTS approval_requests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT NOT NULL,
                username TEXT NOT NULL,
                requested_at TEXT NOT NULL DEFAULT (datetime('now')),
                status TEXT NOT NULL DEFAULT 'pending',
                resolved_by INTEGER,
                resolved_at TEXT,
                FOREIGN KEY (resolved_by) REFERENCES users(id)
            );
            CREATE TABLE IF NOT EXISTS sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                token_hash TEXT NOT NULL,
                expires_at TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT (datetime('now')),
                FOREIGN KEY (user_id) REFERENCES users(id)
            );
            CREATE TABLE IF NOT EXISTS usage_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                credits_used INTEGER NOT NULL DEFAULT 0,
                action TEXT,
                created_at TEXT NOT NULL DEFAULT (datetime('now')),
                FOREIGN KEY (user_id) REFERENCES users(id)
            );
            CREATE INDEX IF NOT EXISTS idx_sessions_token ON sessions(token_hash);
            CREATE INDEX IF NOT EXISTS idx_sessions_expires ON sessions(expires_at);
            CREATE TABLE IF NOT EXISTS login_attempts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL,
                attempted_at TEXT NOT NULL DEFAULT (datetime('now'))
            );
            CREATE INDEX IF NOT EXISTS idx_login_attempts_username ON login_attempts(username);
            CREATE INDEX IF NOT EXISTS idx_login_attempts_at ON login_attempts(attempted_at);
            CREATE TABLE IF NOT EXISTS invite_codes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                code_hash TEXT NOT NULL UNIQUE,
                email TEXT,
                created_at TEXT NOT NULL DEFAULT (datetime('now')),
                expires_at TEXT NOT NULL,
                used_by_user_id INTEGER,
                used_at TEXT,
                FOREIGN KEY (used_by_user_id) REFERENCES users(id)
            );
            CREATE INDEX IF NOT EXISTS idx_invite_codes_hash ON invite_codes(code_hash);
            CREATE INDEX IF NOT EXISTS idx_invite_codes_expires ON invite_codes(expires_at);
            CREATE TABLE IF NOT EXISTS code_attempts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                attempted_at TEXT NOT NULL DEFAULT (datetime('now'))
            );
            CREATE INDEX IF NOT EXISTS idx_code_attempts_at ON code_attempts(attempted_at);
            CREATE TABLE IF NOT EXISTS chat_sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                title TEXT,
                created_at TEXT NOT NULL DEFAULT (datetime('now')),
                updated_at TEXT NOT NULL DEFAULT (datetime('now')),
                FOREIGN KEY (user_id) REFERENCES users(id)
            );
            CREATE TABLE IF NOT EXISTS chat_messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id INTEGER NOT NULL,
                role TEXT NOT NULL,
                content TEXT NOT NULL DEFAULT '',
                tool_calls TEXT,
                created_at TEXT NOT NULL DEFAULT (datetime('now')),
                FOREIGN KEY (session_id) REFERENCES chat_sessions(id)
            );
            CREATE INDEX IF NOT EXISTS idx_chat_sessions_user ON chat_sessions(user_id);
            CREATE INDEX IF NOT EXISTS idx_chat_messages_session ON chat_messages(session_id);
        """)
        conn.commit()
    finally:
        conn.close()


def get_user_count() -> int:
    """Return number of users."""
    conn = _get_conn()
    try:
        cur = conn.execute("SELECT COUNT(*) FROM users")
        return cur.fetchone()[0]
    finally:
        conn.close()


def create_admin(email: str, username: str, password: str) -> dict[str, Any]:
    """Create first admin user. Returns user dict."""
    if len(password) < 8:
        raise ValueError("Password must be at least 8 characters.")
    init_db()
    conn = _get_conn()
    try:
        conn.execute(
            "INSERT INTO users (email, username, password_hash, role, approved) VALUES (?, ?, ?, 'admin', 1)",
            (email, username, hash_password(password)),
        )
        conn.commit()
        cur = conn.execute("SELECT * FROM users WHERE username = ?", (username,))
        row = cur.fetchone()
        return dict(row) if row else {}
    finally:
        conn.close()


def reset_admin_password(username: str, new_password: str) -> tuple[bool, str]:
    """Reset password for an admin user. Returns (success, message)."""
    if len(new_password) < 8:
        return False, "Password must be at least 8 characters."
    conn = _get_conn()
    try:
        cur = conn.execute(
            "UPDATE users SET password_hash = ? WHERE username = ? AND role = 'admin'",
            (hash_password(new_password), username),
        )
        conn.commit()
        if cur.rowcount == 0:
            return False, f"No admin user named '{username}' found."
        return True, f"Password reset for {username}."
    finally:
        conn.close()


def get_user_by_username(username: str) -> dict[str, Any] | None:
    """Get user by username. Returns dict or None."""
    conn = _get_conn()
    try:
        cur = conn.execute("SELECT * FROM users WHERE username = ?", (username,))
        row = cur.fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def get_user_by_id(user_id: int) -> dict[str, Any] | None:
    """Get user by id."""
    conn = _get_conn()
    try:
        cur = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,))
        row = cur.fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def register_user(email: str, username: str, password: str) -> tuple[bool, str]:
    """Register user (pending approval). Returns (success, message)."""
    if len(password) < 8:
        return False, "Password must be at least 8 characters."
    init_db()
    conn = _get_conn()
    try:
        cur = conn.execute("SELECT id FROM users WHERE username = ?", (username,))
        if cur.fetchone():
            return False, "Username already taken."
        cur = conn.execute("SELECT id FROM users WHERE email = ?", (email,))
        if cur.fetchone():
            return False, "Email already registered."
        conn.execute(
            "INSERT INTO users (email, username, password_hash, role, approved) VALUES (?, ?, ?, 'user', 0)",
            (email, username, hash_password(password)),
        )
        conn.execute(
            "INSERT INTO approval_requests (email, username, status) VALUES (?, ?, 'pending')",
            (email, username),
        )
        conn.commit()
        return True, "Request sent. You'll get access once approved."
    finally:
        conn.close()


def get_pending_approvals() -> list[dict[str, Any]]:
    """Get all pending approval requests."""
    conn = _get_conn()
    try:
        cur = conn.execute(
            "SELECT * FROM approval_requests WHERE status = 'pending' ORDER BY requested_at DESC"
        )
        return [dict(row) for row in cur.fetchall()]
    finally:
        conn.close()


def approve_request(request_id: int, admin_id: int) -> bool:
    """Approve a request. Returns True on success."""
    conn = _get_conn()
    try:
        cur = conn.execute("SELECT email, username FROM approval_requests WHERE id = ? AND status = 'pending'", (request_id,))
        row = cur.fetchone()
        if not row:
            return False
        email, username = row["email"], row["username"]
        conn.execute(
            "UPDATE users SET approved = 1 WHERE username = ?",
            (username,),
        )
        conn.execute(
            "UPDATE approval_requests SET status = 'approved', resolved_by = ?, resolved_at = datetime('now') WHERE id = ?",
            (admin_id, request_id),
        )
        conn.commit()
        return True
    finally:
        conn.close()


def reject_request(request_id: int, admin_id: int) -> bool:
    """Reject a request."""
    conn = _get_conn()
    try:
        cur = conn.execute(
            "UPDATE approval_requests SET status = 'rejected', resolved_by = ?, resolved_at = datetime('now') WHERE id = ? AND status = 'pending'",
            (admin_id, request_id),
        )
        conn.commit()
        return cur.rowcount > 0
    finally:
        conn.close()


def list_users() -> list[dict[str, Any]]:
    """List all users."""
    conn = _get_conn()
    try:
        cur = conn.execute("SELECT id, email, username, role, approved, created_at FROM users ORDER BY created_at DESC")
        return [dict(row) for row in cur.fetchall()]
    finally:
        conn.close()


def revoke_user(user_id: int) -> bool:
    """Revoke user access (set approved=0)."""
    conn = _get_conn()
    try:
        cur = conn.execute("UPDATE users SET approved = 0 WHERE id = ? AND role != 'admin'", (user_id,))
        conn.commit()
        return cur.rowcount > 0
    finally:
        conn.close()


def create_user_direct(email: str, username: str, password: str, approved: bool = True) -> tuple[bool, str]:
    """Admin: create user directly (no approval needed)."""
    if len(password) < 8:
        return False, "Password must be at least 8 characters."
    conn = _get_conn()
    try:
        cur = conn.execute("SELECT id FROM users WHERE username = ?", (username,))
        if cur.fetchone():
            return False, "Username already taken."
        conn.execute(
            "INSERT INTO users (email, username, password_hash, role, approved) VALUES (?, ?, ?, 'user', ?)",
            (email, username, hash_password(password), 1 if approved else 0),
        )
        conn.commit()
        return True, "User created."
    finally:
        conn.close()


def log_usage(user_id: int, credits_used: int, action: str = "harvest") -> None:
    """Log API usage for a user."""
    conn = _get_conn()
    try:
        conn.execute(
            "INSERT INTO usage_log (user_id, credits_used, action) VALUES (?, ?, ?)",
            (user_id, credits_used, action),
        )
        conn.commit()
    finally:
        conn.close()


def record_failed_login(username: str) -> None:
    """Record a failed login attempt for rate limiting."""
    conn = _get_conn()
    try:
        conn.execute(
            "INSERT INTO login_attempts (username, attempted_at) VALUES (?, datetime('now'))",
            (username,),
        )
        conn.commit()
        # Prune attempts older than 15 minutes
        conn.execute(
            "DELETE FROM login_attempts WHERE attempted_at < datetime('now', '-15 minutes')"
        )
        conn.commit()
    finally:
        conn.close()


def get_failed_login_count(username: str) -> int:
    """Count failed logins for username in last 15 minutes."""
    conn = _get_conn()
    try:
        cur = conn.execute(
            """SELECT COUNT(*) FROM login_attempts
               WHERE username = ? AND attempted_at > datetime('now', '-15 minutes')""",
            (username,),
        )
        return cur.fetchone()[0]
    finally:
        conn.close()


def get_usage_by_user() -> list[dict[str, Any]]:
    """Get total credits used per user (for admin)."""
    conn = _get_conn()
    try:
        cur = conn.execute("""
            SELECT u.id, u.username, u.email, COALESCE(SUM(ul.credits_used), 0) as total_credits
            FROM users u
            LEFT JOIN usage_log ul ON u.id = ul.user_id
            GROUP BY u.id
            ORDER BY total_credits DESC
        """)
        return [dict(row) for row in cur.fetchall()]
    finally:
        conn.close()


def _hash_code(code: str) -> str:
    """Hash invite code for secure storage."""
    return hashlib.sha256(code.encode("utf-8")).hexdigest()


def create_invite_code(admin_id: int, email: str | None = None) -> tuple[str, datetime]:
    """Create a one-time invite code. Returns (plain_code, expires_at). Code expires in 7 days."""
    code = secrets.token_hex(5).upper()
    code_hash = _hash_code(code)
    expires = datetime.utcnow() + timedelta(days=7)
    conn = _get_conn()
    try:
        conn.execute(
            "INSERT INTO invite_codes (code_hash, email, expires_at) VALUES (?, ?, ?)",
            (code_hash, email or "", expires.isoformat()),
        )
        conn.commit()
        return code, expires
    finally:
        conn.close()


def redeem_invite_code(
    code: str, email: str, username: str, password: str
) -> tuple[dict[str, Any] | None, str]:
    """
    Redeem invite code and create user. Returns (user_dict, error_message).
    On success, error_message is empty.
    """
    if len(password) < 8:
        return None, "Password must be at least 8 characters."

    # Rate limit: 5 code attempts per 15 minutes
    conn = _get_conn()
    try:
        cur = conn.execute(
            "SELECT COUNT(*) FROM code_attempts WHERE attempted_at > datetime('now', '-15 minutes')"
        )
        if cur.fetchone()[0] >= 5:
            return None, "Too many attempts. Please wait 15 minutes."
    finally:
        conn.close()

    code_hash = _hash_code(code.strip().upper())
    init_db()
    conn = _get_conn()
    try:
        cur = conn.execute(
            """SELECT id, email, expires_at, used_by_user_id FROM invite_codes
               WHERE code_hash = ?""",
            (code_hash,),
        )
        row = cur.fetchone()
        if not row:
            conn.execute("INSERT INTO code_attempts (attempted_at) VALUES (datetime('now'))")
            conn.commit()
            return None, "Invalid or expired code."

        code_id, _code_email, expires_at, used_by = row["id"], row["email"], row["expires_at"], row["used_by_user_id"]
        if used_by is not None:
            conn.execute("INSERT INTO code_attempts (attempted_at) VALUES (datetime('now'))")
            conn.commit()
            return None, "Code already used."

        expires = datetime.fromisoformat(expires_at)
        if expires < datetime.utcnow():
            return None, "Code has expired."

        cur = conn.execute("SELECT id FROM users WHERE username = ?", (username,))
        if cur.fetchone():
            return None, "Username already taken."

        cur = conn.execute("SELECT id FROM users WHERE email = ?", (email,))
        if cur.fetchone():
            return None, "Email already registered."

        conn.execute(
            "INSERT INTO users (email, username, password_hash, role, approved) VALUES (?, ?, ?, 'user', 1)",
            (email, username, hash_password(password)),
        )
        cur = conn.execute("SELECT id FROM users WHERE username = ?", (username,))
        new_user_row = cur.fetchone()
        new_user_id = new_user_row["id"] if new_user_row else None
        conn.execute(
            "UPDATE invite_codes SET used_by_user_id = ?, used_at = datetime('now') WHERE id = ?",
            (new_user_id, code_id),
        )
        conn.commit()

        cur = conn.execute("SELECT * FROM users WHERE username = ?", (username,))
        user_row = cur.fetchone()
        return dict(user_row) if user_row else None, ""
    finally:
        conn.close()


def get_code_attempt_count() -> int:
    """Count code redemption attempts in last 15 minutes (for rate limiting)."""
    conn = _get_conn()
    try:
        cur = conn.execute(
            "SELECT COUNT(*) FROM code_attempts WHERE attempted_at > datetime('now', '-15 minutes')"
        )
        return cur.fetchone()[0]
    finally:
        conn.close()


def _prune_code_attempts() -> None:
    """Remove old code attempts."""
    conn = _get_conn()
    try:
        conn.execute("DELETE FROM code_attempts WHERE attempted_at < datetime('now', '-15 minutes')")
        conn.commit()
    finally:
        conn.close()


# --- Chat history ---

def create_chat_session(user_id: int, title: str = "") -> int:
    """Create a new chat session. Returns session id."""
    conn = _get_conn()
    try:
        cur = conn.execute(
            "INSERT INTO chat_sessions (user_id, title) VALUES (?, ?)",
            (user_id, title[:200] if title else ""),
        )
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def get_chat_sessions(user_id: int, limit: int = 20) -> list[dict[str, Any]]:
    """List recent chat sessions for user."""
    conn = _get_conn()
    try:
        cur = conn.execute(
            """SELECT id, title, created_at, updated_at FROM chat_sessions
               WHERE user_id = ? ORDER BY updated_at DESC LIMIT ?""",
            (user_id, limit),
        )
        return [dict(row) for row in cur.fetchall()]
    finally:
        conn.close()


def get_chat_messages(session_id: int) -> list[dict[str, Any]]:
    """Get all messages for a chat session (OpenAI format: role, content, tool_calls)."""
    conn = _get_conn()
    try:
        cur = conn.execute(
            "SELECT role, content, tool_calls FROM chat_messages WHERE session_id = ? ORDER BY id",
            (session_id,),
        )
        rows = []
        for row in cur.fetchall():
            d = {"role": row["role"], "content": row["content"] or ""}
            if row["tool_calls"]:
                try:
                    d["tool_calls"] = json.loads(row["tool_calls"])
                except json.JSONDecodeError:
                    pass
            rows.append(d)
        return rows
    finally:
        conn.close()


def append_chat_message(
    session_id: int, role: str, content: str, tool_calls: str | list | dict | None = None
) -> None:
    """Append a message to a chat session."""
    tc_str = json.dumps(tool_calls) if tool_calls is not None and tool_calls != [] else ""
    conn = _get_conn()
    try:
        conn.execute(
            """INSERT INTO chat_messages (session_id, role, content, tool_calls) VALUES (?, ?, ?, ?)""",
            (session_id, role, content, tc_str),
        )
        conn.execute(
            "UPDATE chat_sessions SET updated_at = datetime('now') WHERE id = ?",
            (session_id,),
        )
        if role == "user" and content:
            conn.execute(
                "UPDATE chat_sessions SET title = ? WHERE id = ? AND (title = '' OR title IS NULL)",
                (content[:200], session_id),
            )
        conn.commit()
    finally:
        conn.close()


def update_chat_session_title(session_id: int, title: str) -> None:
    """Update chat session title."""
    conn = _get_conn()
    try:
        conn.execute(
            "UPDATE chat_sessions SET title = ?, updated_at = datetime('now') WHERE id = ?",
            (title[:200] if title else "", session_id),
        )
        conn.commit()
    finally:
        conn.close()
