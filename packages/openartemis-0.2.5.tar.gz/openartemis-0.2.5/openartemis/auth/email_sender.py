"""Email sending for approval requests."""

import os
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

from dotenv import load_dotenv
from pathlib import Path

load_dotenv(Path(__file__).resolve().parents[2] / ".env")

ADMIN_EMAIL = os.environ.get("ADMIN_EMAIL", "gamtrain400@gmail.com")


def send_approval_request_email(username: str, email: str) -> bool:
    """Send approval request to admin. Returns True if sent."""
    smtp_host = os.environ.get("SMTP_HOST", "smtp.gmail.com")
    smtp_port = int(os.environ.get("SMTP_PORT", "587"))
    smtp_user = os.environ.get("SMTP_USER", ADMIN_EMAIL)
    smtp_password = os.environ.get("SMTP_PASSWORD")

    if not smtp_password:
        return False

    to_email = os.environ.get("ADMIN_EMAIL", "gamtrain400@gmail.com")
    subject = f"OpenArtemis: New access request from {username}"
    body = f"""{email} ({username}) requested access to OpenArtemis.

Run `openartemis admin` to approve or reject.
"""

    try:
        msg = MIMEMultipart()
        msg["From"] = smtp_user
        msg["To"] = to_email
        msg["Subject"] = subject
        msg.attach(MIMEText(body, "plain"))

        with smtplib.SMTP(smtp_host, smtp_port) as server:
            server.starttls()
            server.login(smtp_user, smtp_password)
            server.sendmail(smtp_user, to_email, msg.as_string())
        return True
    except Exception:
        return False
