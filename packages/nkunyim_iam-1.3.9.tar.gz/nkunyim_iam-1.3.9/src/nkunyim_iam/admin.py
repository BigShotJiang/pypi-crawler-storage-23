from django.contrib import admin

from nkunyim_iam.models import (
    User,
    Logging,
)
from nkunyim_iam.manager import (
    UserAdmin,
    LoggingAdmin,
)

admin.site.register(User, UserAdmin)
admin.site.register(Logging, LoggingAdmin)