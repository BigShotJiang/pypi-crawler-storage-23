from rest_framework import serializers

from nkunyim_iam.models import (
    Logging,
    User,
)



class UserSerializer(serializers.ModelSerializer):

    class Meta:
        model = User
        exclude = ['password',]
      
      
class LoggingSerializer(serializers.ModelSerializer):

    class Meta:
        model = Logging
        fields = '__all__'