from .dotenvage import *

__doc__ = dotenvage.__doc__
if hasattr(dotenvage, "__all__"):
    __all__ = dotenvage.__all__