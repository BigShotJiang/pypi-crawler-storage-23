"""Utility components for Yosoi."""

from yosoi.utils.files import init_yosoi

__all__ = [
    'init_yosoi',
]
