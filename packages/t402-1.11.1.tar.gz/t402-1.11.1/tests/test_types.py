from t402.types import (
    PaymentRequirements,
    t402PaymentRequiredResponse,
    ExactPaymentPayload,
    EIP3009Authorization,
    VerifyResponse,
    SettleResponse,
    PaymentPayloadV1,
    parse_payment_payload,
    T402Headers,
)


def test_payment_requirements_serde():
    original = PaymentRequirements(
        scheme="exact",
        network="base",
        max_amount_required="1000",
        resource="/api/v1/resource",
        description="Test resource",
        mime_type="application/json",
        output_schema=None,
        pay_to="0x123",
        max_timeout_seconds=60,
        asset="0x0000000000000000000000000000000000000000",
        extra=None,
    )
    expected = {
        "scheme": "exact",
        "network": "base",
        "maxAmountRequired": "1000",
        "resource": "/api/v1/resource",
        "description": "Test resource",
        "mimeType": "application/json",
        "outputSchema": None,
        "payTo": "0x123",
        "maxTimeoutSeconds": 60,
        "asset": "0x0000000000000000000000000000000000000000",
        "extra": None,
    }
    assert original.model_dump(by_alias=True) == expected
    assert PaymentRequirements(**expected) == original


def test_t402_payment_required_response_serde():
    payment_req = PaymentRequirements(
        scheme="exact",
        network="base",
        max_amount_required="1000",
        resource="/api/v1/resource",
        description="Test resource",
        mime_type="application/json",
        output_schema=None,
        pay_to="0x123",
        max_timeout_seconds=60,
        asset="0x0000000000000000000000000000000000000000",
        extra=None,
    )
    original = t402PaymentRequiredResponse(
        t402_version=1, accepts=[payment_req], error=""
    )
    expected = {
        "t402Version": 1,
        "accepts": [payment_req.model_dump(by_alias=True)],
        "error": "",
    }
    assert original.model_dump(by_alias=True) == expected
    assert t402PaymentRequiredResponse(**expected) == original


def test_eip3009_authorization_serde():
    original = EIP3009Authorization(
        from_="0x123",
        to="0x456",
        value="1000",
        valid_after="0",
        valid_before="1000",
        nonce="0x789",
    )
    expected = {
        "from": "0x123",
        "to": "0x456",
        "value": "1000",
        "validAfter": "0",
        "validBefore": "1000",
        "nonce": "0x789",
    }
    assert original.model_dump(by_alias=True) == expected
    assert EIP3009Authorization(**expected) == original


def test_exact_payment_payload_serde():
    auth = EIP3009Authorization(
        from_="0x123",
        to="0x456",
        value="1000",
        valid_after="0",
        valid_before="1000",
        nonce="0x789",
    )
    original = ExactPaymentPayload(signature="0x123", authorization=auth)
    expected = {"signature": "0x123", "authorization": auth.model_dump(by_alias=True)}
    assert original.model_dump(by_alias=True) == expected
    assert ExactPaymentPayload(**expected) == original


def test_verify_response_serde():
    original = VerifyResponse(is_valid=True, invalid_reason=None, payer="0x123")
    expected = {"isValid": True, "invalidReason": None, "payer": "0x123"}
    assert original.model_dump(by_alias=True) == expected
    assert VerifyResponse(**expected) == original


def test_settle_response_serde():
    original = SettleResponse(
        success=True,
        error_reason=None,
        transaction="0x123",
        network="base",
        payer="0x123",
    )
    expected = {
        "success": True,
        "errorReason": None,
        "transaction": "0x123",
        "network": "base",
        "payer": "0x123",
        "confirmations": None,
    }
    assert original.model_dump(by_alias=True) == expected
    assert SettleResponse(**expected) == original


def test_payment_payload_serde():
    auth = EIP3009Authorization(
        from_="0x123",
        to="0x456",
        value="1000",
        valid_after="0",
        valid_before="1000",
        nonce="0x789",
    )
    payload = ExactPaymentPayload(signature="0x123", authorization=auth)
    original = PaymentPayloadV1(
        t402_version=1,
        scheme="exact",
        network="base",
        payload=payload,
    )
    expected = {
        "t402Version": 1,
        "scheme": "exact",
        "network": "base",
        "payload": payload.model_dump(by_alias=True),
    }
    assert original.model_dump(by_alias=True) == expected
    assert PaymentPayloadV1(**expected) == original


def test_parse_payment_payload_v1():
    """Test that parse_payment_payload returns V1 for t402Version=1."""
    data = {
        "t402Version": 1,
        "scheme": "exact",
        "network": "eip155:8453",
        "payload": {"signature": "0x123", "authorization": {
            "from": "0x123", "to": "0x456", "value": "1000",
            "validAfter": "0", "validBefore": "1000", "nonce": "0x789",
        }},
    }
    result = parse_payment_payload(data)
    assert isinstance(result, PaymentPayloadV1)
    assert result.scheme == "exact"


def test_t402_headers_serde():
    original = T402Headers(x_payment="test-payment")
    expected = {"x_payment": "test-payment"}
    assert original.model_dump(by_alias=True) == expected
    assert T402Headers(**expected) == original
