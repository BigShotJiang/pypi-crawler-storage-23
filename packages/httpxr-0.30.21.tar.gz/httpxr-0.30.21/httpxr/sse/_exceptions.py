from __future__ import annotations

from httpxr import TransportError


class SSEError(TransportError):
    pass
