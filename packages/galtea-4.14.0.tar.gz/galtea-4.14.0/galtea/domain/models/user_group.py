from typing import List, Optional

from pydantic import Field

from galtea.utils.from_camel_case_base_model import FromCamelCaseBaseModel


class UserGroupBase(FromCamelCaseBaseModel):
    name: str
    type: str
    description: Optional[str] = None


class UserGroup(UserGroupBase):
    id: str
    organization_id: str
    user_ids: List[str] = Field(default_factory=list)
    metric_ids: List[str] = Field(default_factory=list)
    created_at: str
    deleted_at: Optional[str] = None
