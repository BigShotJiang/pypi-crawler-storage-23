"""
NeuralClaw — The Self-Evolving Cognitive Agent Framework.

This setup.py exists for backward compatibility with tools that don't
support PEP 517 / pyproject.toml. All configuration lives in pyproject.toml.
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
