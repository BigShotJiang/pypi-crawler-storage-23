"""Cortex — Cognitive processing modules."""
