"""
Skill Registry — Plugin discovery, loading, and registration.

Discovers skills from built-in and user directories, loads their manifests,
and registers their tools for the reasoning cortex.
"""

from __future__ import annotations

import importlib
import pkgutil
from pathlib import Path
from typing import Any

from neuralclaw.cortex.reasoning.deliberate import ToolDef
from neuralclaw.skills.manifest import SkillManifest


# ---------------------------------------------------------------------------
# Skill Registry
# ---------------------------------------------------------------------------

class SkillRegistry:
    """
    Central registry for all skills (built-in and user-installed).

    Handles:
    - Discovery of built-in skills
    - Dynamic loading of skill modules
    - Registration of tool definitions
    - Lookup by name
    """

    def __init__(self) -> None:
        self._skills: dict[str, SkillManifest] = {}
        self._tool_defs: list[ToolDef] = []

    def register(self, manifest: SkillManifest) -> None:
        """Register a skill from its manifest."""
        self._skills[manifest.name] = manifest

        # Convert to ToolDefs for the reasoning cortex
        for tool in manifest.tools:
            self._tool_defs.append(ToolDef(
                name=tool.name,
                description=tool.description,
                parameters=tool.to_json_schema(),
                handler=tool.handler,
            ))

    def load_builtins(self) -> None:
        """Discover and load all built-in skills."""
        import neuralclaw.skills.builtins as builtins_pkg

        for importer, modname, ispkg in pkgutil.iter_modules(builtins_pkg.__path__):
            try:
                module = importlib.import_module(f"neuralclaw.skills.builtins.{modname}")
                if hasattr(module, "get_manifest"):
                    manifest = module.get_manifest()
                    if isinstance(manifest, SkillManifest):
                        self.register(manifest)
            except Exception as e:
                # Log but don't crash on individual skill failures
                print(f"[SkillRegistry] Failed to load builtin skill '{modname}': {e}")

    def get_all_tools(self) -> list[ToolDef]:
        """Get all registered tool definitions."""
        return self._tool_defs.copy()

    def get_skill(self, name: str) -> SkillManifest | None:
        """Look up a skill by name."""
        return self._skills.get(name)

    def list_skills(self) -> list[SkillManifest]:
        """List all registered skills."""
        return list(self._skills.values())

    @property
    def count(self) -> int:
        return len(self._skills)

    @property
    def tool_count(self) -> int:
        return len(self._tool_defs)
