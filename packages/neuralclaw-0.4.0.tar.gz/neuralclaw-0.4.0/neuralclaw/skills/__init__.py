"""Skills — Plugin framework with capability-based permissions."""
