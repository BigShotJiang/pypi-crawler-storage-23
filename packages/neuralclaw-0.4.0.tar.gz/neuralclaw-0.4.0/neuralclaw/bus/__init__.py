"""Neural Bus — Inter-cortex event system and telemetry."""
