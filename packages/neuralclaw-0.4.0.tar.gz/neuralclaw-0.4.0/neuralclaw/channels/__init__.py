"""Channels — Multi-platform messaging adapters."""
