"""
NeuralClaw Configuration — TOML-based config with OS keychain secrets.

Loads from ~/.neuralclaw/config.toml. Secrets (API keys, tokens) are stored
in the OS keychain via the `keyring` library, never in plaintext on disk.
"""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import toml

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

APP_NAME = "neuralclaw"
CONFIG_DIR = Path.home() / f".{APP_NAME}"
CONFIG_FILE = CONFIG_DIR / "config.toml"
DATA_DIR = CONFIG_DIR / "data"
LOG_DIR = CONFIG_DIR / "logs"
MEMORY_DB = DATA_DIR / "memory.db"

DEFAULT_CONFIG: dict[str, Any] = {
    "general": {
        "name": "NeuralClaw",
        "persona": "You are NeuralClaw, a helpful and intelligent AI assistant.",
        "log_level": "INFO",
        "telemetry_stdout": True,
    },
    "providers": {
        "primary": "openai",
        "fallback": ["openrouter", "local"],
        "openai": {
            "model": "gpt-4o",
            "base_url": "https://api.openai.com/v1",
        },
        "anthropic": {
            "model": "claude-sonnet-4-20250514",
            "base_url": "https://api.anthropic.com",
        },
        "openrouter": {
            "model": "anthropic/claude-sonnet-4-20250514",
            "base_url": "https://openrouter.ai/api/v1",
        },
        "local": {
            "model": "llama3",
            "base_url": "http://localhost:11434/v1",
        },
    },
    "memory": {
        "db_path": str(MEMORY_DB),
        "max_episodic_results": 10,
        "max_semantic_results": 5,
        "importance_threshold": 0.3,
    },
    "security": {
        "threat_threshold": 0.7,
        "block_threshold": 0.9,
        "max_skill_timeout_seconds": 30,
        "allow_shell_execution": False,
    },
    "channels": {
        "telegram": {"enabled": False},
        "discord": {"enabled": False},
    },
}


# ---------------------------------------------------------------------------
# Keyring helpers
# ---------------------------------------------------------------------------

def _get_secret(key: str) -> str | None:
    """Retrieve a secret from OS keychain."""
    try:
        import keyring as kr
        return kr.get_password(APP_NAME, key)
    except Exception:
        return None


def _set_secret(key: str, value: str) -> None:
    """Store a secret in OS keychain."""
    try:
        import keyring as kr
        kr.set_password(APP_NAME, key, value)
    except Exception:
        pass  # Graceful fallback — user can set env vars instead


def get_api_key(provider: str) -> str | None:
    """Get API key for a provider. Checks env vars first, then keyring."""
    env_map = {
        "openai": "OPENAI_API_KEY",
        "anthropic": "ANTHROPIC_API_KEY",
        "openrouter": "OPENROUTER_API_KEY",
    }
    env_var = env_map.get(provider)
    if env_var:
        val = os.environ.get(env_var)
        if val:
            return val
    return _get_secret(f"{provider}_api_key")


def set_api_key(provider: str, key: str) -> None:
    """Store API key in OS keychain."""
    _set_secret(f"{provider}_api_key", key)


# ---------------------------------------------------------------------------
# Config dataclasses
# ---------------------------------------------------------------------------

@dataclass
class ProviderConfig:
    name: str
    model: str
    base_url: str
    api_key: str | None = None


@dataclass
class MemoryConfig:
    db_path: str = str(MEMORY_DB)
    max_episodic_results: int = 10
    max_semantic_results: int = 5
    importance_threshold: float = 0.3


@dataclass
class SecurityConfig:
    threat_threshold: float = 0.7
    block_threshold: float = 0.9
    max_skill_timeout_seconds: int = 30
    allow_shell_execution: bool = False


@dataclass
class ChannelConfig:
    name: str
    enabled: bool = False
    token: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass
class NeuralClawConfig:
    name: str = "NeuralClaw"
    persona: str = "You are NeuralClaw, a helpful and intelligent AI assistant."
    log_level: str = "INFO"
    telemetry_stdout: bool = True

    primary_provider: ProviderConfig | None = None
    fallback_providers: list[ProviderConfig] = field(default_factory=list)

    memory: MemoryConfig = field(default_factory=MemoryConfig)
    security: SecurityConfig = field(default_factory=SecurityConfig)
    channels: list[ChannelConfig] = field(default_factory=list)

    _raw: dict[str, Any] = field(default_factory=dict, repr=False)


# ---------------------------------------------------------------------------
# Config loading
# ---------------------------------------------------------------------------

def _build_provider(name: str, section: dict[str, Any]) -> ProviderConfig:
    return ProviderConfig(
        name=name,
        model=section.get("model", "gpt-4o"),
        base_url=section.get("base_url", ""),
        api_key=get_api_key(name),
    )


def load_config(path: Path | None = None) -> NeuralClawConfig:
    """Load configuration from TOML file, with defaults."""
    path = path or CONFIG_FILE
    raw: dict[str, Any] = {}

    if path.exists():
        with open(path, "r", encoding="utf-8") as f:
            raw = toml.load(f)

    # Merge with defaults
    merged = _deep_merge(DEFAULT_CONFIG, raw)

    general = merged.get("general", {})
    providers_section = merged.get("providers", {})
    mem_section = merged.get("memory", {})
    sec_section = merged.get("security", {})
    chan_section = merged.get("channels", {})

    # Build provider configs
    primary_name = providers_section.get("primary", "openai")
    primary = _build_provider(primary_name, providers_section.get(primary_name, {}))

    fallback_names = providers_section.get("fallback", [])
    fallbacks = [
        _build_provider(n, providers_section.get(n, {}))
        for n in fallback_names if n != primary_name
    ]

    # Build channel configs
    channels: list[ChannelConfig] = []
    for ch_name, ch_data in chan_section.items():
        if isinstance(ch_data, dict):
            # Check multiple key naming conventions + env vars
            token = (
                _get_secret(f"{ch_name}_api_key")
                or _get_secret(f"{ch_name}_token")
                or os.environ.get(f"NEURALCLAW_{ch_name.upper()}_TOKEN")
            )
            # Auto-enable any channel that has a token configured
            explicitly_enabled = ch_data.get("enabled", False)
            auto_enabled = bool(token)
            channels.append(ChannelConfig(
                name=ch_name,
                enabled=explicitly_enabled or auto_enabled,
                token=token,
                extra=ch_data,
            ))

    return NeuralClawConfig(
        name=general.get("name", "NeuralClaw"),
        persona=general.get("persona", DEFAULT_CONFIG["general"]["persona"]),
        log_level=general.get("log_level", "INFO"),
        telemetry_stdout=general.get("telemetry_stdout", True),
        primary_provider=primary,
        fallback_providers=fallbacks,
        memory=MemoryConfig(**{k: v for k, v in mem_section.items()}),
        security=SecurityConfig(**{k: v for k, v in sec_section.items()}),
        channels=channels,
        _raw=merged,
    )


def ensure_dirs() -> None:
    """Create config / data / log directories if needed."""
    for d in (CONFIG_DIR, DATA_DIR, LOG_DIR):
        d.mkdir(parents=True, exist_ok=True)


def save_default_config() -> Path:
    """Write default config.toml if it doesn't exist. Returns the path."""
    ensure_dirs()
    if not CONFIG_FILE.exists():
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            toml.dump(DEFAULT_CONFIG, f)
    return CONFIG_FILE


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _deep_merge(base: dict, override: dict) -> dict:
    """Recursively merge override into base."""
    result = base.copy()
    for k, v in override.items():
        if k in result and isinstance(result[k], dict) and isinstance(v, dict):
            result[k] = _deep_merge(result[k], v)
        else:
            result[k] = v
    return result
