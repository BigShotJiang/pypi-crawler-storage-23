"""
NeuralClaw Swarm — Multi-agent collaboration module.

Provides delegation chains, consensus protocols, and agent mesh
for inter-agent communication and task distribution.
"""

from neuralclaw.swarm.delegation import (
    DelegationChain,
    DelegationContext,
    DelegationResult,
    DelegationStatus,
    DelegationPolicy,
    DelegationRecord,
)
from neuralclaw.swarm.consensus import (
    ConsensusProtocol,
    ConsensusStrategy,
    ConsensusResult,
    ConsensusVote,
)
from neuralclaw.swarm.mesh import (
    AgentMesh,
    AgentCard,
    AgentStatus,
    MeshMessage,
)

__all__ = [
    "DelegationChain",
    "DelegationContext",
    "DelegationResult",
    "DelegationStatus",
    "DelegationPolicy",
    "DelegationRecord",
    "ConsensusProtocol",
    "ConsensusStrategy",
    "ConsensusResult",
    "ConsensusVote",
    "AgentMesh",
    "AgentCard",
    "AgentStatus",
    "MeshMessage",
]
