"""Synth AI CLI."""

from synth_ai.cli.main import cli

__all__ = ["cli"]
