"""Legacy GEPA alias under synth_ai.dspy.teleprompt."""

from __future__ import annotations

from synth_ai.dspy.gepa import GEPA

__all__ = ["GEPA"]
