"""Adapter namespace for GEPA compatibility."""
# See: specifications/tanha/master_specification.md
