"""Default adapter stubs for GEPA compatibility."""
# See: specifications/tanha/master_specification.md

from .default_adapter import DefaultAdapter

__all__ = ["DefaultAdapter"]
