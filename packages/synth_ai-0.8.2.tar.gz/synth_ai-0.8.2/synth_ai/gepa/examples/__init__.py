"""Example datasets for GEPA compatibility."""
# See: specifications/tanha/master_specification.md

from . import aime, banking77

__all__ = ["aime", "banking77"]
