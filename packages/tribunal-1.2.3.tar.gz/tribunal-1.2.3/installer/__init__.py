"""Tribunal Installer - Step-based installation pipeline."""

__version__ = "1.2.0"
__build__ = "dev"
