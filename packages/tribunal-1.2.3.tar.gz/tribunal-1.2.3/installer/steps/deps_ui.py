"""UI wrapper functions for dependency installation steps."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from installer.steps.deps_claude import install_claude_code
from installer.steps.deps_playwright import install_playwright_cli
from installer.steps.deps_vexor import install_vexor


def _install_with_spinner(ui: Any, name: str, install_fn: Any, *args: Any) -> bool:
    """Run an installation function with a spinner."""
    if ui:
        with ui.spinner(f"Installing {name}..."):
            result = install_fn(*args) if args else install_fn()
        if result:
            ui.success(f"{name} installed")
        else:
            ui.warning(f"Could not install {name} - please install manually")
        return result
    else:
        return install_fn(*args) if args else install_fn()


def _install_claude_code_with_ui(ui: Any, project_dir: Path) -> bool:
    """Install Claude Code with UI feedback."""
    if ui:
        ui.status("Installing Claude Code via npm...")
        success, version = install_claude_code(project_dir, ui)
        if success:
            if version != "latest":
                ui.success(f"Claude Code installed (pinned to v{version})")
                ui.info(f"Version {version} is the last stable release tested with Tribunal")
                ui.info("To change: edit FORCE_CLAUDE_VERSION in ~/.claude/settings.json")
            else:
                ui.success("Claude Code installed (latest)")
            ui.success("Claude Code config defaults applied")
        else:
            ui.warning("Could not install Claude Code - please install manually")
        return success
    else:
        success, _ = install_claude_code(project_dir)
        return success


def _install_playwright_cli_with_ui(ui: Any) -> bool:
    """Install playwright-cli with UI feedback."""
    if ui:
        ui.status("Installing playwright-cli...")
    if install_playwright_cli(ui):
        if ui:
            ui.success("playwright-cli installed")
        return True
    else:
        if ui:
            ui.warning("Could not install playwright-cli - please install manually")
        return False


def _install_vexor_with_ui(ui: Any) -> bool:
    """Install Vexor with local embeddings (GPU auto-detected)."""
    from installer.platform_utils import has_nvidia_gpu

    use_cuda = has_nvidia_gpu()
    mode_str = "CUDA" if use_cuda else "CPU"

    if ui:
        ui.status(f"Installing Vexor with local embeddings ({mode_str})...")

    if install_vexor(use_local=True, ui=ui):
        if ui:
            ui.success(f"Vexor installed with local embeddings ({mode_str})")
        return True
    else:
        if ui:
            ui.warning("Could not install Vexor - please install manually")
        return False
