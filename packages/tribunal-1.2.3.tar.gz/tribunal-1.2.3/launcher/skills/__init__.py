"""Tribunal skills management.

Provides the ``sfc skills`` subcommand for listing, creating, analysing,
and validating project skills.
"""

from __future__ import annotations

import argparse

__all__ = ["handle_skills_command"]


def handle_skills_command(args: argparse.Namespace) -> None:
    """Dispatch skills subcommands."""
    cmd: str | None = getattr(args, "skills_command", None)

    if cmd is None or cmd == "list":
        from launcher.skills.list_cmd import run_list

        run_list()

    elif cmd == "show":
        from launcher.skills.show_cmd import run_show

        run_show(args.name)

    elif cmd == "init":
        from launcher.skills.init_cmd import run_init

        run_init()

    elif cmd == "analyze":
        from launcher.skills.analyze_cmd import run_analyze

        run_analyze(dry_run=args.dry_run, model=args.model)

    elif cmd == "create":
        from launcher.skills.create_cmd import run_create

        run_create(args.name)

    elif cmd == "doctor":
        from launcher.skills.doctor_cmd import run_doctor

        run_doctor()

    else:
        print("Unknown skills command. Run 'sfc skills --help' for usage.")
