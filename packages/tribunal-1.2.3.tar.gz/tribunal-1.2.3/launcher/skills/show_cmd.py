"""``sfc skills show <name>`` — display a skill's content."""

from __future__ import annotations

import sys

from launcher.skills._scanner import _read_text_safe, find_skills_dir


def run_show(name: str) -> None:
    """Pretty-print a single skill's SKILL.md."""
    skills_dir = find_skills_dir()
    skill_file = skills_dir / name / "SKILL.md"

    if not skill_file.is_file():
        print(f"Skill '{name}' not found.", file=sys.stderr)
        print(f"Looked in: {skills_dir / name}", file=sys.stderr)
        print()
        # Suggest similar names
        if skills_dir.is_dir():
            available = [d.name for d in skills_dir.iterdir() if d.is_dir() and (d / "SKILL.md").is_file()]
            if available:
                print(f"Available skills: {', '.join(available)}")
        sys.exit(1)

    content = _read_text_safe(skill_file)
    if content is None:
        sys.exit(1)

    try:
        from rich.console import Console
        from rich.markdown import Markdown

        console = Console()
        console.print(Markdown(content))
    except ImportError:
        print(content)
