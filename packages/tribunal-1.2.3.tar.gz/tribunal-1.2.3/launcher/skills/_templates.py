"""Template strings for project.md and SKILL.md generation."""

from __future__ import annotations

# ---------------------------------------------------------------------------
# project.md template  (mirrors /sync Phase 5 format)
# ---------------------------------------------------------------------------

PROJECT_MD_TEMPLATE = """\
# Project: {name}

**Last Updated:** {date}

## Overview

{overview}

## Technology Stack

{tech_stack}

## Directory Structure

```
{directory_structure}
```

## Development Commands

{dev_commands}
"""


# ---------------------------------------------------------------------------
# SKILL.md template  (matches /learn Phase 0.4 format)
# ---------------------------------------------------------------------------

SKILL_MD_TEMPLATE = """\
---
name: {name}
description: |
  [CRITICAL: This determines when the skill triggers. Include:]
  - What the skill does
  - Specific trigger conditions (exact error messages, symptoms)
  - When to use it (contexts, scenarios)
author: Tribunal
version: 1.0.0
---

# {title}

## Problem

[Clear description of the problem this skill solves]

## Context / Trigger Conditions

[When to use - exact error messages, symptoms, scenarios]

## Solution

[Step-by-step solution]

## Verification

[How to verify it worked]

## Example

[Concrete example]

## References

[Links to documentation]
"""


def render_project_md(project: dict) -> str:
    """Render a project.md from a detect_project() result dict."""
    from datetime import date

    # Build tech stack section
    tech_lines: list[str] = []
    if project.get("languages"):
        tech_lines.append(f"- **Language:** {', '.join(project['languages'])}")
    if project.get("frameworks"):
        tech_lines.append(f"- **Framework:** {', '.join(project['frameworks'])}")
    if project.get("build_tools"):
        tech_lines.append(f"- **Build Tool:** {', '.join(project['build_tools'])}")
    if project.get("test_frameworks"):
        tech_lines.append(f"- **Testing:** {', '.join(project['test_frameworks'])}")
    if project.get("package_manager"):
        tech_lines.append(f"- **Package Manager:** {project['package_manager']}")

    tech_stack = "\n".join(tech_lines) if tech_lines else "- *Not detected*"

    # Build directory structure
    dirs = project.get("directory_structure", [])
    dir_lines = "\n".join(f"{d}/" for d in dirs) if dirs else "[run sfc skills analyze for full structure]"

    # Build dev commands section
    dev_cmds = project.get("dev_commands", {})
    if dev_cmds:
        pm = project.get("package_manager") or "npm"
        cmd_lines: list[str] = []
        for key, value in dev_cmds.items():
            cmd_lines.append(f"- **{key.capitalize()}:** `{pm} run {key}`")
        dev_commands = "\n".join(cmd_lines)
    else:
        dev_commands = "- *Not detected — run `sfc skills analyze` for AI-powered discovery*"

    return PROJECT_MD_TEMPLATE.format(
        name=project.get("name", "Unknown"),
        date=date.today().isoformat(),
        overview="[Run `sfc skills analyze` for AI-generated overview]",
        tech_stack=tech_stack,
        directory_structure=dir_lines,
        dev_commands=dev_commands,
    )


def render_skill_md(name: str) -> str:
    """Render a SKILL.md scaffold from a skill name."""
    title = name.replace("-", " ").title()
    return SKILL_MD_TEMPLATE.format(name=name, title=title)
