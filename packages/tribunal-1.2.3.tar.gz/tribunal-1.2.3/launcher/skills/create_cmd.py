"""``sfc skills create <name>`` — scaffold a new skill from template."""

from __future__ import annotations

import re
import sys

from launcher.skills._scanner import find_skills_dir
from launcher.skills._templates import render_skill_md


def run_create(name: str) -> None:
    """Validate *name*, create the skill directory, and write a SKILL.md template."""
    # Validate name is kebab-case
    if not re.match(r"^[a-z][a-z0-9]*(-[a-z0-9]+)*$", name):
        print(
            f"Invalid skill name '{name}'. Use kebab-case (e.g., 'deploy-workflow', 'api-client').",
            file=sys.stderr,
        )
        sys.exit(1)

    skills_dir = find_skills_dir()
    skill_dir = skills_dir / name

    if skill_dir.exists():
        print(f"Skill '{name}' already exists at {skill_dir}", file=sys.stderr)
        sys.exit(1)

    try:
        skill_dir.mkdir(parents=True, exist_ok=True)
        skill_file = skill_dir / "SKILL.md"
        skill_file.write_text(render_skill_md(name), encoding="utf-8")
    except OSError as exc:
        print(f"Error creating skill '{name}': {exc}", file=sys.stderr)
        sys.exit(1)

    print(f"Created skill: {skill_file}")
    print()
    print("Next steps:")
    print(f"  1. Edit {skill_file} to add your skill's content")
    print("  2. Fill in the description with specific trigger conditions")
    print("  3. Add the solution steps, verification, and examples")
