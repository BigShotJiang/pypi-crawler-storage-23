"""``sfc skills list`` — list all project skills."""

from __future__ import annotations

from launcher.skills._scanner import scan_skills


def run_list() -> None:
    """List skills in a formatted table."""
    skills = scan_skills()

    if not skills:
        print("No skills found in .claude/skills/")
        print()
        print("  sfc skills init      Bootstrap project configuration")
        print("  sfc skills analyze   AI-powered skill discovery")
        print("  sfc skills create    Create a skill from template")
        return

    try:
        from rich.console import Console
        from rich.table import Table

        console = Console()
        table = Table(title="Project Skills", show_lines=False)
        table.add_column("Name", style="cyan", no_wrap=True)
        table.add_column("Version", style="green", no_wrap=True)
        table.add_column("Description")

        for s in skills:
            desc = s["description"]
            # Collapse multi-line descriptions to first line
            first_line = desc.split("\n")[0] if desc else ""
            if len(first_line) > 80:
                first_line = first_line[:77] + "..."
            table.add_row(s["name"], s["version"], first_line)

        console.print(table)
    except ImportError:
        # Plain text fallback
        print("Project Skills:")
        print()
        for s in skills:
            desc = s["description"].split("\n")[0][:60] if s["description"] else ""
            version = f" (v{s['version']})" if s["version"] else ""
            print(f"  {s['name']}{version}: {desc}")

    print()
    print(f"{len(skills)} skill(s) found.  Use 'sfc skills show <name>' for details.")
