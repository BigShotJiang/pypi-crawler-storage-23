"""Tribunal statusline subpackage.

Provides :func:`render_statusline` for IDE integration.
"""

from __future__ import annotations

from launcher.statusline.formatter import render_statusline

__all__ = ["render_statusline"]
