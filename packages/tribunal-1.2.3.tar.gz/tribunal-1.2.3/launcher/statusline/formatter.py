"""Format the complete statusline string for IDE display.

Combines the output of all widgets into a single line.  The format is::

    [MODE] [ctx:N%] [mem:N]

Example::

    [QUICK] [ctx:47%] [mem:3]

Claude Code pipes JSON data to stdin on every statusline invocation.
This module reads that data, persists the context percentage for the
context_monitor hook, and renders the final statusline.
"""

from __future__ import annotations

from launcher.statusline.providers import (
    get_context_usage,
    get_memory_count,
    get_mode,
    parse_stdin_data,
    persist_context_pct,
)
from launcher.statusline.widgets import (
    context_widget,
    memory_widget,
    mode_widget,
)


def render_statusline() -> str:
    """Build and return the full statusline string.

    This is the main entry point used by the CLI and by
    ``python -m launcher.statusline``.

    Side-effects:
    - Reads JSON from stdin (piped by Claude Code).
    - Writes ``context-pct.json`` for the context_monitor hook.
    """
    stdin_data = parse_stdin_data()
    persist_context_pct(stdin_data)

    ctx_pct = get_context_usage(stdin_data)

    parts: list[str] = [
        mode_widget(get_mode()),
        context_widget(ctx_pct),
        memory_widget(get_memory_count()),
    ]
    return " ".join(p for p in parts if p)
