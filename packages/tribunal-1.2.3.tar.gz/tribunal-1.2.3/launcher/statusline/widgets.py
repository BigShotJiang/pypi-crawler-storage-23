"""Widget renderers for individual statusline components.

Each widget function returns a short string fragment suitable for inclusion
in a single-line statusline displayed in an IDE.
"""

from __future__ import annotations

from typing import Any


def mode_widget(mode: str) -> str:
    """Render the mode indicator.

    Parameters
    ----------
    mode:
        The current operating mode (e.g. ``'quick'`` or ``'spec'``).
    """
    label = mode.upper()
    return f"[{label}]"


def session_widget(session_info: dict[str, Any] | None) -> str:
    """Render the session indicator.

    Parameters
    ----------
    session_info:
        The active session dict, or ``None`` if no session is running.
    """
    if session_info is None:
        return "[no session]"

    session_id: str = session_info.get("id", "???")
    short_id = session_id[:8]
    return f"[session:{short_id}]"


def memory_widget(count: int) -> str:
    """Render the memory count indicator.

    Parameters
    ----------
    count:
        Number of memory files currently stored.
    """
    return f"[mem:{count}]"


def context_widget(pct: int | None) -> str:
    """Render the context usage indicator.

    Parameters
    ----------
    pct:
        Context window usage as a percentage (0-100), or ``None`` if
        not yet available (before the first API call in a session).
    """
    if pct is None:
        return ""
    if pct >= 90:
        return f"[ctx:{pct}% !!]"
    if pct >= 80:
        return f"[ctx:{pct}% !]"
    return f"[ctx:{pct}%]"
