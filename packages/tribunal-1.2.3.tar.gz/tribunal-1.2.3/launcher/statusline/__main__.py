"""Entry point for ``python -m launcher.statusline``."""

from __future__ import annotations

import sys

from launcher.statusline.formatter import render_statusline


def main() -> None:
    """Print the statusline to stdout."""
    output = render_statusline()
    sys.stdout.write(output + "\n")


main()
