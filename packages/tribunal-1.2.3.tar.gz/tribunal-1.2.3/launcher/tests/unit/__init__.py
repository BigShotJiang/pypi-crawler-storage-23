"""Launcher unit tests."""
