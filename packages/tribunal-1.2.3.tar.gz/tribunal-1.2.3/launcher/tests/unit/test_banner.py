"""Tests for launcher.banner module."""

from __future__ import annotations

import sys
from unittest.mock import patch


class TestPrintBanner:
    """Test banner output with Rich and plain text fallback."""

    def test_prints_with_rich(self, capsys):
        """Should print styled banner when Rich is available."""
        from launcher.banner import print_banner

        print_banner()

        # Rich writes to its own Console, so we just verify no exception

    def test_fallback_without_rich(self, capsys):
        """Should print plain text when Rich is not installed."""
        import builtins

        real_import = builtins.__import__

        def mock_import(name, *args, **kwargs):
            if name in ("rich.console",):
                raise ImportError("mocked")
            return real_import(name, *args, **kwargs)

        # Clear cached rich modules and the banner module to force re-import
        saved = {}
        for mod_name in list(sys.modules):
            if mod_name.startswith("rich") or mod_name == "launcher.banner":
                saved[mod_name] = sys.modules.pop(mod_name)

        try:
            with patch("builtins.__import__", side_effect=mock_import):
                from launcher.banner import print_banner

                print_banner()

            captured = capsys.readouterr()
            assert "Tribunal" in captured.out
        finally:
            # Restore cached modules
            sys.modules.update(saved)

    def test_output_contains_version(self, capsys):
        """Should include the version in output."""
        import builtins

        real_import = builtins.__import__

        def mock_import(name, *args, **kwargs):
            if name in ("rich.console",):
                raise ImportError("mocked")
            return real_import(name, *args, **kwargs)

        saved = {}
        for mod_name in list(sys.modules):
            if mod_name.startswith("rich") or mod_name == "launcher.banner":
                saved[mod_name] = sys.modules.pop(mod_name)

        try:
            with patch("builtins.__import__", side_effect=mock_import):
                from launcher.banner import print_banner

                print_banner()

            captured = capsys.readouterr()
            assert "v" in captured.out
        finally:
            sys.modules.update(saved)
