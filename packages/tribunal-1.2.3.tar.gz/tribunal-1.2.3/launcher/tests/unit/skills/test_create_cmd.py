"""Tests for launcher.skills.create_cmd module."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import pytest


class TestRunCreate:
    """Test skill creation from template."""

    def test_creates_skill_directory(self, tmp_path: Path):
        with patch("launcher.skills.create_cmd.find_skills_dir", return_value=tmp_path / ".claude" / "skills"):
            from launcher.skills.create_cmd import run_create

            run_create("my-workflow")

        skill_file = tmp_path / ".claude" / "skills" / "my-workflow" / "SKILL.md"
        assert skill_file.is_file()
        content = skill_file.read_text()
        assert "name: my-workflow" in content
        assert "My Workflow" in content  # title

    def test_rejects_invalid_name(self, capsys):
        with pytest.raises(SystemExit):
            from launcher.skills.create_cmd import run_create

            run_create("InvalidName")

    def test_rejects_uppercase(self, capsys):
        with pytest.raises(SystemExit):
            from launcher.skills.create_cmd import run_create

            run_create("My-Skill")

    def test_rejects_starting_with_number(self, capsys):
        with pytest.raises(SystemExit):
            from launcher.skills.create_cmd import run_create

            run_create("2fast")

    def test_accepts_valid_kebab_names(self, tmp_path: Path):
        with patch("launcher.skills.create_cmd.find_skills_dir", return_value=tmp_path / ".claude" / "skills"):
            from launcher.skills.create_cmd import run_create

            run_create("api-client")

        assert (tmp_path / ".claude" / "skills" / "api-client" / "SKILL.md").is_file()

    def test_rejects_duplicate_name(self, tmp_path: Path):
        skills_dir = tmp_path / ".claude" / "skills" / "existing"
        skills_dir.mkdir(parents=True)

        with patch("launcher.skills.create_cmd.find_skills_dir", return_value=tmp_path / ".claude" / "skills"):
            with pytest.raises(SystemExit):
                from launcher.skills.create_cmd import run_create

                run_create("existing")
