"""Tests for launcher.skills._scanner module."""

from __future__ import annotations

from pathlib import Path


class TestParseFrontmatter:
    """Test YAML frontmatter extraction."""

    def test_extracts_simple_fields(self):
        from launcher.skills._scanner import parse_frontmatter

        content = "---\nname: my-skill\ndescription: A test skill\nversion: 1.0.0\n---\n# Skill"
        result = parse_frontmatter(content)
        assert result["name"] == "my-skill"
        assert result["description"] == "A test skill"
        assert result["version"] == "1.0.0"

    def test_handles_no_frontmatter(self):
        from launcher.skills._scanner import parse_frontmatter

        result = parse_frontmatter("# Just a heading\n\nSome content.")
        assert result == {}

    def test_handles_empty_string(self):
        from launcher.skills._scanner import parse_frontmatter

        result = parse_frontmatter("")
        assert result == {}

    def test_handles_multiline_description(self):
        from launcher.skills._scanner import parse_frontmatter

        content = (
            "---\n"
            "name: my-skill\n"
            "description: |\n"
            "  First line of description.\n"
            "  Second line of description.\n"
            "version: 1.0.0\n"
            "---\n"
        )
        result = parse_frontmatter(content)
        assert result["name"] == "my-skill"
        assert "First line" in result["description"]
        assert "Second line" in result["description"]
        assert result["version"] == "1.0.0"

    def test_handles_values_with_colons(self):
        from launcher.skills._scanner import parse_frontmatter

        content = "---\nname: my-skill\ndescription: Use when: errors happen\n---\n"
        result = parse_frontmatter(content)
        assert result["description"] == "Use when: errors happen"


class TestScanSkills:
    """Test skill directory scanning."""

    def test_finds_skills(self, tmp_path: Path):
        from launcher.skills._scanner import scan_skills

        skill_dir = tmp_path / ".claude" / "skills" / "test-skill"
        skill_dir.mkdir(parents=True)
        (skill_dir / "SKILL.md").write_text("---\nname: test-skill\ndescription: A test\nversion: 1.0.0\n---\n# Test\n")

        results = scan_skills(tmp_path)
        assert len(results) == 1
        assert results[0]["name"] == "test-skill"
        assert results[0]["version"] == "1.0.0"

    def test_returns_empty_for_missing_dir(self, tmp_path: Path):
        from launcher.skills._scanner import scan_skills

        results = scan_skills(tmp_path)
        assert results == []

    def test_skips_dirs_without_skill_md(self, tmp_path: Path):
        from launcher.skills._scanner import scan_skills

        skill_dir = tmp_path / ".claude" / "skills" / "no-skill"
        skill_dir.mkdir(parents=True)
        # No SKILL.md created

        results = scan_skills(tmp_path)
        assert results == []

    def test_uses_dir_name_as_fallback(self, tmp_path: Path):
        from launcher.skills._scanner import scan_skills

        skill_dir = tmp_path / ".claude" / "skills" / "fallback-name"
        skill_dir.mkdir(parents=True)
        (skill_dir / "SKILL.md").write_text("---\ndescription: test\n---\n")

        results = scan_skills(tmp_path)
        assert len(results) == 1
        assert results[0]["name"] == "fallback-name"

    def test_multiple_skills_sorted(self, tmp_path: Path):
        from launcher.skills._scanner import scan_skills

        for name in ("zebra", "alpha", "middle"):
            d = tmp_path / ".claude" / "skills" / name
            d.mkdir(parents=True)
            (d / "SKILL.md").write_text(f"---\nname: {name}\nversion: 1.0.0\n---\n")

        results = scan_skills(tmp_path)
        assert [r["name"] for r in results] == ["alpha", "middle", "zebra"]


class TestFindDirs:
    """Test directory locators."""

    def test_find_skills_dir(self, tmp_path: Path):
        from launcher.skills._scanner import find_skills_dir

        result = find_skills_dir(tmp_path)
        assert result == tmp_path / ".claude" / "skills"
