"""Tests for skills CLI integration."""

from __future__ import annotations

from unittest.mock import patch


class TestSkillsParser:
    """Test that the skills subcommand is registered in argparse."""

    def test_has_skills_subcommand(self):
        from launcher.cli import _build_parser

        parser = _build_parser()
        args, _ = parser.parse_known_args(["skills"])
        assert args.command == "skills"

    def test_skills_default_is_list(self):
        from launcher.cli import _build_parser

        parser = _build_parser()
        args, _ = parser.parse_known_args(["skills"])
        assert args.skills_command is None  # defaults to list

    def test_skills_list_subcommand(self):
        from launcher.cli import _build_parser

        parser = _build_parser()
        args, _ = parser.parse_known_args(["skills", "list"])
        assert args.skills_command == "list"

    def test_skills_show_subcommand(self):
        from launcher.cli import _build_parser

        parser = _build_parser()
        args, _ = parser.parse_known_args(["skills", "show", "my-skill"])
        assert args.skills_command == "show"
        assert args.name == "my-skill"

    def test_skills_init_subcommand(self):
        from launcher.cli import _build_parser

        parser = _build_parser()
        args, _ = parser.parse_known_args(["skills", "init"])
        assert args.skills_command == "init"

    def test_skills_analyze_subcommand(self):
        from launcher.cli import _build_parser

        parser = _build_parser()
        args, _ = parser.parse_known_args(["skills", "analyze"])
        assert args.skills_command == "analyze"
        assert args.dry_run is False
        assert args.model == "sonnet"

    def test_skills_analyze_dry_run(self):
        from launcher.cli import _build_parser

        parser = _build_parser()
        args, _ = parser.parse_known_args(["skills", "analyze", "--dry-run"])
        assert args.dry_run is True

    def test_skills_analyze_model(self):
        from launcher.cli import _build_parser

        parser = _build_parser()
        args, _ = parser.parse_known_args(["skills", "analyze", "--model", "opus"])
        assert args.model == "opus"

    def test_skills_create_subcommand(self):
        from launcher.cli import _build_parser

        parser = _build_parser()
        args, _ = parser.parse_known_args(["skills", "create", "new-skill"])
        assert args.skills_command == "create"
        assert args.name == "new-skill"

    def test_skills_doctor_subcommand(self):
        from launcher.cli import _build_parser

        parser = _build_parser()
        args, _ = parser.parse_known_args(["skills", "doctor"])
        assert args.skills_command == "doctor"


class TestSkillsDispatch:
    """Test that main() dispatches to handle_skills_command."""

    def test_dispatches_to_skills_handler(self):
        with patch("launcher.skills.handle_skills_command") as mock_handler:
            import pytest

            from launcher.cli import main

            # skills with no subcommand exits 0 (prints usage to stdout)
            with pytest.raises(SystemExit) as exc_info:
                main(["skills"])
            assert exc_info.value.code == 0

        mock_handler.assert_called_once()
