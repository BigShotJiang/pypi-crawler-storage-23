"""Tests for launcher.skills.doctor_cmd module."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import pytest


class TestRunDoctor:
    """Test skill validation."""

    def test_reports_missing_skill_md(self, tmp_path: Path, capsys):
        skill_dir = tmp_path / ".claude" / "skills" / "broken-skill"
        skill_dir.mkdir(parents=True)
        # No SKILL.md

        with patch("launcher.skills.doctor_cmd.find_skills_dir", return_value=tmp_path / ".claude" / "skills"):
            from launcher.skills.doctor_cmd import run_doctor

            with pytest.raises(SystemExit):
                run_doctor()

        captured = capsys.readouterr()
        assert "Missing SKILL.md" in captured.out

    def test_reports_missing_name(self, tmp_path: Path, capsys):
        skill_dir = tmp_path / ".claude" / "skills" / "no-name"
        skill_dir.mkdir(parents=True)
        (skill_dir / "SKILL.md").write_text("---\ndescription: Some description here\nversion: 1.0.0\n---\n")

        with patch("launcher.skills.doctor_cmd.find_skills_dir", return_value=tmp_path / ".claude" / "skills"):
            from launcher.skills.doctor_cmd import run_doctor

            with pytest.raises(SystemExit):
                run_doctor()

        captured = capsys.readouterr()
        assert "Missing 'name'" in captured.out

    def test_reports_short_description(self, tmp_path: Path, capsys):
        skill_dir = tmp_path / ".claude" / "skills" / "short-desc"
        skill_dir.mkdir(parents=True)
        (skill_dir / "SKILL.md").write_text("---\nname: short-desc\ndescription: hi\nversion: 1.0.0\n---\n")

        with patch("launcher.skills.doctor_cmd.find_skills_dir", return_value=tmp_path / ".claude" / "skills"):
            from launcher.skills.doctor_cmd import run_doctor

            with pytest.raises(SystemExit):
                run_doctor()

        captured = capsys.readouterr()
        assert "too short" in captured.out

    def test_reports_missing_version(self, tmp_path: Path, capsys):
        skill_dir = tmp_path / ".claude" / "skills" / "no-version"
        skill_dir.mkdir(parents=True)
        (skill_dir / "SKILL.md").write_text(
            "---\nname: no-version\ndescription: A description with enough content\n---\n"
        )

        with patch("launcher.skills.doctor_cmd.find_skills_dir", return_value=tmp_path / ".claude" / "skills"):
            from launcher.skills.doctor_cmd import run_doctor

            with pytest.raises(SystemExit):
                run_doctor()

        captured = capsys.readouterr()
        assert "Missing 'version'" in captured.out

    def test_healthy_skill_passes(self, tmp_path: Path, capsys):
        skill_dir = tmp_path / ".claude" / "skills" / "good-skill"
        skill_dir.mkdir(parents=True)
        (skill_dir / "SKILL.md").write_text(
            "---\nname: good-skill\ndescription: A proper description with trigger conditions\nversion: 1.0.0\n---\n"
        )

        with patch("launcher.skills.doctor_cmd.find_skills_dir", return_value=tmp_path / ".claude" / "skills"):
            from launcher.skills.doctor_cmd import run_doctor

            run_doctor()  # Should NOT raise

        captured = capsys.readouterr()
        assert "healthy" in captured.out

    def test_no_skills_dir(self, tmp_path: Path, capsys):
        with patch("launcher.skills.doctor_cmd.find_skills_dir", return_value=tmp_path / ".claude" / "skills"):
            from launcher.skills.doctor_cmd import run_doctor

            run_doctor()  # Should NOT raise

        captured = capsys.readouterr()
        assert "No .claude/skills/ directory" in captured.out
