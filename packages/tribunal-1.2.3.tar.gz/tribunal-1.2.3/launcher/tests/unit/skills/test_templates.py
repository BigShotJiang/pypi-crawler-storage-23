"""Tests for launcher.skills._templates module."""

from __future__ import annotations


class TestRenderProjectMd:
    """Test project.md template rendering."""

    def test_includes_project_name(self):
        from launcher.skills._templates import render_project_md

        result = render_project_md({"name": "my-app"})
        assert "# Project: my-app" in result

    def test_includes_languages(self):
        from launcher.skills._templates import render_project_md

        result = render_project_md({"name": "app", "languages": ["Python", "Go"]})
        assert "Python, Go" in result

    def test_includes_frameworks(self):
        from launcher.skills._templates import render_project_md

        result = render_project_md({"name": "app", "frameworks": ["FastAPI"]})
        assert "FastAPI" in result

    def test_handles_none_package_manager(self):
        from launcher.skills._templates import render_project_md

        result = render_project_md(
            {
                "name": "app",
                "package_manager": None,
                "dev_commands": {"dev": "run-dev"},
            }
        )
        assert "None" not in result
        assert "npm run dev" in result

    def test_handles_missing_fields(self):
        from launcher.skills._templates import render_project_md

        # Should not raise even with empty dict
        result = render_project_md({})
        assert "# Project: Unknown" in result

    def test_includes_dev_commands(self):
        from launcher.skills._templates import render_project_md

        result = render_project_md(
            {
                "name": "app",
                "package_manager": "bun",
                "dev_commands": {"dev": "vite", "test": "vitest"},
            }
        )
        assert "bun run dev" in result
        assert "bun run test" in result


class TestRenderSkillMd:
    """Test SKILL.md template rendering."""

    def test_includes_name_in_frontmatter(self):
        from launcher.skills._templates import render_skill_md

        result = render_skill_md("my-workflow")
        assert "name: my-workflow" in result

    def test_generates_title(self):
        from launcher.skills._templates import render_skill_md

        result = render_skill_md("deploy-workflow")
        assert "# Deploy Workflow" in result

    def test_includes_version(self):
        from launcher.skills._templates import render_skill_md

        result = render_skill_md("test")
        assert "version: 1.0.0" in result
