"""Tests for launcher.skills package."""

from __future__ import annotations
