"""Pytest configuration for launcher tests."""

from __future__ import annotations
