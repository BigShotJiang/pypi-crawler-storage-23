"""Print the Tribunal startup banner.

Uses the Rich library for styled terminal output.  Falls back to plain text
if Rich is not installed.
"""

from __future__ import annotations

import shutil

from launcher import __version__

BANNER_TEXT = "Tribunal"
TAGLINE = "Claude Code is powerful. Tribunal makes it reliable."

# Requires ~70 columns to render without wrapping.
ASCII_ART = r"""
     _____ __   _ _________      __    __   ______          __
    / ___// /__(_) / / __(_)__  / /___/ /  / ____/___  ____/ /__
    \__ \/ //_/ / / / /_/ / _ \/ / __  /  / /   / __ \/ __  / _ \
   ___/ / ,< / / / / __/ /  __/ / /_/ /  / /___/ /_/ / /_/ /  __/
  /____/_/|_/_/_/_/_/ /_/\___/_/\__,_/   \____/\____/\__,_/\___/
"""

ASCII_ART_MIN_WIDTH = 70


def print_banner() -> None:
    """Print the Tribunal ASCII art banner to the terminal."""
    term_width = shutil.get_terminal_size((80, 24)).columns
    use_ascii_art = term_width >= ASCII_ART_MIN_WIDTH

    try:
        from rich.console import Console

        console = Console()

        if use_ascii_art:
            console.print(f"[bold cyan]{ASCII_ART}[/bold cyan]", highlight=False)
        else:
            console.print(f"\n  [bold cyan]{BANNER_TEXT}[/bold cyan]\n")
        console.print(f"  [dim]{TAGLINE}[/dim]")
        console.print(f"  [dim]v{__version__}[/dim]")
        console.print()

    except ImportError:
        # Fallback: plain text if Rich is not available.
        if use_ascii_art:
            print(ASCII_ART)
        else:
            print(f"\n  {BANNER_TEXT}\n")
        print(f"  {TAGLINE}")
        print(f"  v{__version__}")
        print()
