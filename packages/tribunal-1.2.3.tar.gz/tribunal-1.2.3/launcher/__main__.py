"""Entry point for python -m launcher."""

from launcher.cli import main

main()
