# Instructions

L'élève propose *la requête SQL* suivante :
```sql
{{requete}}
```

Indique de manière synthétique l'objectif fonctionnel de cette requête. 
