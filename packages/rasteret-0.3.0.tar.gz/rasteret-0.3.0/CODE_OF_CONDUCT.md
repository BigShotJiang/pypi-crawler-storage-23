# Contributor Covenant Code of Conduct

This project has adopted the
[Contributor Covenant Code of Conduct](https://www.contributor-covenant.org/version/2/1/code_of_conduct/).

All contributors, maintainers, and participants are expected to follow it
in all project spaces: issues, pull requests, discussions, and any other
communication channels.

## Enforcement

Instances of abusive, harassing, or otherwise unacceptable behavior may be
reported to the project maintainers at **sid@terrafloww.com** or
**aditya@terrafloww.com**.

All reports will be reviewed and investigated and will result in a response
appropriate to the circumstances.

## Resources

- [Contributor Covenant v2.1 (full text)](https://www.contributor-covenant.org/version/2/1/code_of_conduct/)
- [Contributor Covenant FAQ](https://www.contributor-covenant.org/faq/)
