# Security Policy

## Supported Versions

Security updates are provided for `main` and the most recent minor
release series.

| Version | Supported |
|---------|-----------|
| 0.3.x   | Yes       |
| < 0.3   | No        |

## Reporting a Vulnerability

**Please do not open a public issue for security vulnerabilities.**

Use GitHub's private reporting feature:

1. Go to [https://github.com/terrafloww/rasteret/security](https://github.com/terrafloww/rasteret/security).
2. Click **Report a vulnerability**.
3. Fill out the form and submit your draft security advisory.

See [GitHub's docs](https://docs.github.com/en/code-security/security-advisories/guidance-on-reporting-and-writing/privately-reporting-a-security-vulnerability) for details.
