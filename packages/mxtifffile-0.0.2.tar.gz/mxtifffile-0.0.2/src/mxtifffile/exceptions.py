class MxTiffFormatError(Exception):
    """Raised when MxTiffFile cannot detect or parse the format of a TIFF file."""
