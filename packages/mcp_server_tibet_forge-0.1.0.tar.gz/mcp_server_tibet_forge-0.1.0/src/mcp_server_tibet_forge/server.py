"""
MCP Server for tibet-forge - The Gordon Ramsay of code scanning.

Tools:
- forge_scan: Scan a project and get trust score + roasts
- forge_shame: Submit to Hall of Shame leaderboard
- forge_leaderboard: View the Hall of Shame
- forge_score: Quick score check
"""

import asyncio
import json
from pathlib import Path
from typing import Any

import httpx
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

# Hall of Shame API
SHAME_API = "https://brein.jaspervandemeent.nl/api/shame"

server = Server("tibet-forge")


def get_tools() -> list[Tool]:
    """Return available tools."""
    return [
        Tool(
            name="forge_scan",
            description="Scan a project directory for code quality issues. Returns trust score, grade, and Gordon Ramsay-style roasts.",
            inputSchema={
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Path to the project directory to scan"
                    },
                    "include_roasts": {
                        "type": "boolean",
                        "description": "Include code smell roasts (default: true)",
                        "default": True
                    }
                },
                "required": ["path"]
            }
        ),
        Tool(
            name="forge_score",
            description="Get just the trust score for a project (quick check).",
            inputSchema={
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Path to the project directory"
                    }
                },
                "required": ["path"]
            }
        ),
        Tool(
            name="forge_shame",
            description="Submit a scanned project to the public Hall of Shame leaderboard. Compete for Shitcoder of the Month!",
            inputSchema={
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Path to the project directory to shame"
                    },
                    "coder_name": {
                        "type": "string",
                        "description": "Your name for the leaderboard"
                    },
                    "repo_url": {
                        "type": "string",
                        "description": "Optional GitHub URL for the repo"
                    }
                },
                "required": ["path", "coder_name"]
            }
        ),
        Tool(
            name="forge_leaderboard",
            description="View the Hall of Shame leaderboard - who has the worst code?",
            inputSchema={
                "type": "object",
                "properties": {
                    "limit": {
                        "type": "integer",
                        "description": "Number of entries to show (default: 10)",
                        "default": 10
                    }
                }
            }
        ),
    ]


@server.list_tools()
async def list_tools() -> list[Tool]:
    """List available tools."""
    return get_tools()


@server.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    """Handle tool calls."""

    if name == "forge_scan":
        return await handle_scan(arguments)
    elif name == "forge_score":
        return await handle_score(arguments)
    elif name == "forge_shame":
        return await handle_shame(arguments)
    elif name == "forge_leaderboard":
        return await handle_leaderboard(arguments)
    else:
        return [TextContent(type="text", text=f"Unknown tool: {name}")]


async def handle_scan(args: dict[str, Any]) -> list[TextContent]:
    """Scan a project and return results."""
    path = Path(args["path"]).expanduser().resolve()
    include_roasts = args.get("include_roasts", True)

    if not path.exists():
        return [TextContent(type="text", text=f"Error: Path not found: {path}")]

    try:
        from tibet_forge.forge import Forge
        from tibet_forge.config import ForgeConfig

        config = ForgeConfig()
        forge = Forge(config)
        result = forge.scan(path)

        # Build response
        score = result.trust_score
        output = []
        output.append(f"# tibet-forge Scan Results")
        output.append(f"**Project:** {path.name}")
        output.append(f"**Trust Score:** {score.total}/100 ({score.grade})")
        output.append(f"\n{score.grade_message()}")
        output.append(f"\n## Score Breakdown")
        output.append(score.summary())

        # Bloat issues
        if result.bloat_report and result.bloat_report.issues:
            output.append(f"\n## Bloat Issues ({len(result.bloat_report.issues)})")
            for issue in result.bloat_report.issues[:5]:
                output.append(f"- {issue.description}")
                output.append(f"  > {issue.suggestion}")

        # Security issues
        if result.security_report and result.security_report.issues:
            output.append(f"\n## Security Issues ({len(result.security_report.issues)})")
            for issue in result.security_report.issues[:5]:
                output.append(f"- [{issue.severity.upper()}] {issue.description}")
                output.append(f"  > {issue.suggestion}")

        # Code smells with roasts
        if include_roasts and result.quality_report and result.quality_report.smells:
            output.append(f"\n## Code Smells - Gordon Ramsay Mode")
            for smell in result.quality_report.smells[:5]:
                output.append(f"- **{smell.file.split('/')[-1]}:{smell.line}**")
                output.append(f"  *\"{smell.roast}\"*")

        # Certification status
        if result.certified:
            output.append(f"\n## CERTIFIED")
            output.append(result.badge_markdown)
        else:
            output.append(f"\n## Not Certified")
            output.append(f"Score {score.total} < 70 required for certification")

        return [TextContent(type="text", text="\n".join(output))]

    except ImportError:
        return [TextContent(type="text", text="Error: tibet-forge not installed. Run: pip install tibet-forge")]
    except Exception as e:
        return [TextContent(type="text", text=f"Error scanning: {str(e)}")]


async def handle_score(args: dict[str, Any]) -> list[TextContent]:
    """Quick score check."""
    path = Path(args["path"]).expanduser().resolve()

    if not path.exists():
        return [TextContent(type="text", text=f"Error: Path not found: {path}")]

    try:
        from tibet_forge.forge import Forge

        forge = Forge()
        result = forge.scan(path)
        score = result.trust_score

        emoji = "" if score.total >= 70 else "" if score.total >= 50 else ""
        output = f"{emoji} **{path.name}**: {score.total}/100 ({score.grade})\n\n{score.grade_message()}"

        return [TextContent(type="text", text=output)]

    except Exception as e:
        return [TextContent(type="text", text=f"Error: {str(e)}")]


async def handle_shame(args: dict[str, Any]) -> list[TextContent]:
    """Submit to Hall of Shame."""
    path = Path(args["path"]).expanduser().resolve()
    coder_name = args["coder_name"]
    repo_url = args.get("repo_url", f"local://{path}")

    if not path.exists():
        return [TextContent(type="text", text=f"Error: Path not found: {path}")]

    try:
        from tibet_forge.forge import Forge
        from tibet_forge.shame import determine_shame_category, generate_custom_roast, generate_highlights

        forge = Forge()
        result = forge.scan(path)

        category = determine_shame_category(result)
        roast = generate_custom_roast(result, category)
        highlights = generate_highlights(result)

        # Submit to API
        async with httpx.AsyncClient() as client:
            resp = await client.post(f"{SHAME_API}/submit", json={
                "coder_name": coder_name,
                "repo_url": repo_url,
                "repo_name": path.name,
                "score": result.trust_score.total,
                "grade": result.trust_score.grade,
                "category": category,
                "roast": roast,
                "highlights": highlights[:5]
            }, timeout=10)

            if resp.status_code == 200:
                data = resp.json()
                output = [
                    f"# SHAME SUBMITTED!",
                    f"**{coder_name}** has entered the Hall of Shame!",
                    f"",
                    f"- Score: {result.trust_score.total}/100 ({result.trust_score.grade})",
                    f"- Points earned: {data['points_earned']}",
                    f"- Total points: {data['total_points']}",
                    f"- Current rank: #{data['current_rank']}",
                    f"",
                    f"*\"{roast}\"*",
                ]
                if data['current_rank'] == 1:
                    output.append(f"\n**YOU ARE #1 SHITCODER OF THE MONTH!**")
                return [TextContent(type="text", text="\n".join(output))]
            else:
                return [TextContent(type="text", text=f"Error submitting: {resp.text}")]

    except Exception as e:
        return [TextContent(type="text", text=f"Error: {str(e)}")]


async def handle_leaderboard(args: dict[str, Any]) -> list[TextContent]:
    """Get Hall of Shame leaderboard."""
    limit = args.get("limit", 10)

    try:
        async with httpx.AsyncClient() as client:
            resp = await client.get(f"{SHAME_API}/leaderboard", params={"limit": limit}, timeout=10)

            if resp.status_code == 200:
                data = resp.json()

                if not data["leaderboard"]:
                    return [TextContent(type="text", text="# Hall of Shame\n\nNo submissions yet! Be the first shitcoder to claim the throne!\n\nUse `forge_shame` to submit your worst code.")]

                output = ["# Hall of Shame Leaderboard", ""]

                for entry in data["leaderboard"]:
                    medal = entry.get("medal", "")
                    output.append(f"{medal} **#{entry['rank']} {entry['coder_name']}** - {entry['total_points']} pts")
                    output.append(f"   Worst score: {entry['worst_score']}/100 | Submissions: {entry['submissions']}")

                output.append(f"\n*Total submissions: {data['total_submissions']}*")
                return [TextContent(type="text", text="\n".join(output))]
            else:
                return [TextContent(type="text", text=f"Error fetching leaderboard: {resp.text}")]

    except Exception as e:
        return [TextContent(type="text", text=f"Error: {str(e)}")]


def main():
    """Run the MCP server."""
    asyncio.run(run_server())


async def run_server():
    """Run the server with stdio transport."""
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())


if __name__ == "__main__":
    main()
