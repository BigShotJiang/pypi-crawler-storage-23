"""MCP Server for tibet-forge - The Gordon Ramsay of code scanning."""
__version__ = "0.1.0"
