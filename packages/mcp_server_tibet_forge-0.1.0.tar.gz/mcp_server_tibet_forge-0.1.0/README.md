# mcp-server-tibet-forge

MCP Server for **tibet-forge** - The Gordon Ramsay of code scanning.

Scan code, get roasts, and compete in the Hall of Shame - all from your AI assistant!

## Installation

```bash
pip install mcp-server-tibet-forge
```

## Configuration

Add to your Claude Desktop config (`~/.config/claude/claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "tibet-forge": {
      "command": "mcp-server-tibet-forge"
    }
  }
}
```

Or with uvx:

```json
{
  "mcpServers": {
    "tibet-forge": {
      "command": "uvx",
      "args": ["mcp-server-tibet-forge"]
    }
  }
}
```

## Tools

### `forge_scan`
Scan a project directory for code quality issues. Returns trust score, grade, and Gordon Ramsay-style roasts.

```
"Scan my project at ~/code/myapp"
```

### `forge_score`
Quick trust score check for a project.

```
"What's the score for ~/code/myapp?"
```

### `forge_shame`
Submit a scanned project to the public Hall of Shame leaderboard. Compete for **Shitcoder of the Month**!

```
"Submit ~/code/myapp to the Hall of Shame as 'JohnDoe'"
```

### `forge_leaderboard`
View the Hall of Shame leaderboard - who has the worst code?

```
"Show me the Hall of Shame leaderboard"
```

## Example Usage

Ask Claude:

> "Scan my code at ~/projects/legacy-app and tell me how bad it is"

Claude will:
1. Run tibet-forge scan
2. Show you the trust score (0-100)
3. Roast your code Gordon Ramsay style
4. Offer to submit to the Hall of Shame

## The TIBET Grading Scale

| Grade | Score | Verdict |
|-------|-------|---------|
| A | 90-100 | FUCKING AWESOME! Push to production. |
| B | 70-89 | Solid. Add a @tibet_audit wrapper. |
| C | 50-69 | Dangerous. The CISO gets hives. |
| D | 25-49 | Over-engineered. Stop hallucinating. |
| F | 0-24 | SHIT. Delete the repo and start over. |

## Hall of Shame

The public leaderboard at [humotica.com](https://humotica.com) tracks:
- **Points**: Lower score = more shame points
- **Categories**: bloat_king, security_nightmare, spaghetti_master, llm_hallucinator
- **Monthly winners**: Compete for Shitcoder of the Month!

## Links

- [tibet-forge on PyPI](https://pypi.org/project/tibet-forge/)
- [Hall of Shame API](https://brein.jaspervandemeent.nl/api/shame/leaderboard)
- [Humotica](https://humotica.com)

## License

MIT
