# NanoClaw (qwibitai/nanoclaw) Research Report

> Last updated: 2026-02-27
> Repository: https://github.com/qwibitai/nanoclaw
> Stars: ~15,600 | License: MIT | Language: TypeScript
> Website: https://nanoclaw.dev

---

## 1. Project Overview

NanoClaw is a lightweight personal AI assistant that differentiates itself with **container-level OS isolation** (not just application-layer permission checks). The codebase is intentionally kept "small enough to fully understand" (~34.9k tokens, 19% of a context window).

- Created: 2026-01-31
- Latest version: v1.1.3 (2026-02-25)
- Primary contributor: gavrielc
- Design philosophy: "AI-native" — no config files, no install wizards, no dashboards; everything through Claude interaction

### Comparison with OpenClaw

| Dimension | OpenClaw | NanoClaw |
|-----------|---------|----------|
| Codebase | ~500K lines, 53 config files, 70+ deps | ~35k tokens |
| Security model | Application-layer (allowlists, pairing) | OS-level container isolation |
| Process model | Single Node.js process, shared memory | Independent Docker containers per group |

## 2. Technology Stack

| Layer | Technology |
|-------|-----------|
| Runtime | Node.js 22 (single process) |
| Language | TypeScript 5.7 |
| AI Agent SDK | `@anthropic-ai/claude-agent-sdk` ^0.2.34 |
| Primary channel | WhatsApp (via `@whiskeysockets/baileys` ^7.0) |
| Database | SQLite (`better-sqlite3` ^11.8) |
| Container runtime | Docker (default) / Apple Container (macOS native) |
| MCP | `@modelcontextprotocol/sdk` ^1.12 |
| Scheduling | `cron-parser` ^5.5 |
| Logging | Pino + pino-pretty |
| Config validation | Zod v4 |
| Testing | Vitest ^4.0 + @vitest/coverage-v8 |
| Code quality | Prettier + Husky (pre-commit hooks) |
| Build | tsc (production), tsx (dev hot-reload) |

## 3. Architecture

### Core Flow

```
WhatsApp (baileys) --> SQLite --> Polling Loop (2s) --> Docker Container (Claude Agent SDK) --> Response
```

### Process Model

1. **Message Receive**: WhatsApp channel via baileys connects to WhatsApp Web, stores messages in SQLite
2. **Message Polling**: Main loop polls database every 2 seconds for new messages in registered groups
3. **Trigger Word Filter**: Non-primary groups require trigger word (default `@Andy`); primary group (user's self-chat) processes directly
4. **Containerized Execution**: Creates independent Docker container per group; container runs Claude Agent SDK; only explicitly mounted directories are visible
5. **IPC Communication**: Host <-> container via filesystem IPC (JSON files) for message passing and task management
6. **Streaming Output**: Agent output parsed via marker pairs (`---NANOCLAW_OUTPUT_START---` / `---NANOCLAW_OUTPUT_END---`) from container stdout

### Key Source Files

| File | Responsibility |
|------|---------------|
| `src/index.ts` | Main orchestrator: state management, message loop, Agent invocation |
| `src/channels/whatsapp.ts` | WhatsApp connection, auth, send/receive |
| `src/container-runner.ts` | Container mount construction, Agent container launch |
| `src/container-runtime.ts` | Container runtime abstraction (Docker/Apple Container) |
| `src/group-queue.ts` | Per-group queue + global concurrency control (default max 5 containers) |
| `src/ipc.ts` | Filesystem IPC polling and task processing |
| `src/router.ts` | Message formatting and outbound routing |
| `src/task-scheduler.ts` | Cron-based task scheduling |
| `src/db.ts` | SQLite operations (messages, groups, sessions, state) |
| `src/mount-security.ts` | Mount security validation (allowlist, blocklist modes) |
| `src/config.ts` | Config constants (trigger words, paths, timeouts) |
| `container/Dockerfile` | Agent container image (node:22-slim + Chromium + Claude Code) |
| `container/agent-runner/src/index.ts` | In-container agent runner (calls Claude Agent SDK) |
| `skills-engine/` | Skills system engine (install, uninstall, upgrade, conflict detection) |

### Agent Container Internals

Container based on `node:22-slim`, pre-installed:
- Chromium (for browser automation)
- `agent-browser` (agent browser tool)
- `@anthropic-ai/claude-code` (Claude Code CLI)

The `agent-runner` receives JSON via stdin, uses Claude Agent SDK `query()` for the Agent loop, supports:
- **MessageStream**: Push-based async iterable, allows follow-up messages to flow into container via IPC files
- **Session Resume**: Continue previous conversation via sessionId
- **Hook Mechanism**: `PreToolUseHookInput`, `PreCompactHookInput` lifecycle hooks

## 4. Core Features

### 4.1 Container-Level Security Isolation (Key Differentiator)

- **Process isolation**: Each Agent runs in independent Docker container
- **Filesystem isolation**: Only explicitly mounted directories visible
- **Non-root execution**: Container runs as `node` user (uid 1000)
- **Ephemeral containers**: Destroyed after each invocation (`--rm`)
- **Mount security**:
  - Allowlist stored outside project root (`~/.config/nanoclaw/mount-allowlist.json`) — container cannot modify
  - Default blocks: `.ssh`, `.gnupg`, `.aws`, `.azure`, `.env`, `credentials`
  - Symlink resolution prevents traversal attacks
  - Non-primary group mounts default to read-only
  - Project root mounted read-only even for primary group

### 4.2 Group Isolation

- Each group has independent `CLAUDE.md` memory file
- Independent filesystem and container sandbox
- Independent Claude sessions (`data/sessions/{group}/.claude/`)
- Strict IPC authorization (non-primary groups cannot send messages to other groups or create tasks)

### 4.3 Agent Swarms

- First personal AI assistant to support Agent Swarms
- Launch multiple specialized Agents for team collaboration on complex tasks

### 4.4 Scheduled Tasks

- Cron expression-based scheduling
- Tasks run in containers, can reply to user
- Create, pause, resume, delete tasks
- Task run logs persisted

### 4.5 Skills System

Design philosophy: **"Don't add features, add Skills"**

Available Skills:
- `/setup` — First-time configuration
- `/add-discord` — Add Discord channel
- `/add-telegram` — Add Telegram channel
- `/add-slack` — Add Slack channel
- `/add-gmail` — Add Gmail integration
- `/add-voice-transcription` — Voice to text
- `/add-parallel` — Parallel processing
- `/add-telegram-swarm` — Telegram + Swarm integration
- `/convert-to-apple-container` — Switch to Apple Container runtime
- `/customize` — Guided customization
- `/debug` — Debug troubleshooting
- `/update` — Pull upstream updates
- `/qodo-pr-resolver` — Qodo PR Review fixes

Skills Engine (`skills-engine/`) provides full lifecycle management: install, uninstall, backup, restore, conflict detection, path remapping, git rebase integration, structured merging (npm deps, Docker Compose services, env vars).

### 4.6 Browser Automation

Container pre-installs Chromium + agent-browser; all Agents can use browser automation for web search and content fetching via Bash.

### 4.7 Multi-Channel Support

WhatsApp (native built-in), Telegram, Discord, Slack, Signal, headless mode.

### 4.8 AI-Native Design Philosophy

- No install wizard — Claude Code guides setup
- No monitoring dashboard — ask Claude what happened
- No debug tools — describe problem, let Claude fix
- No config files — modify code directly

## 5. Latest Release — v1.1.3

Recent commits (2026-02-25/26):
- Added husky and format:fix scripts (#535)
- Updated token count to 38.4k tokens (19% context window)
- CI optimizations, logging improvements, code formatting (#456)
- Multiple contributor documentation updates

Project activity: 204 open issues, extremely active for a project less than 1 month old (15,000+ stars).

## 6. Relevance to WorkPilot

### 6.1 Container Security Model (High Value)

NanoClaw's container isolation approach is highly relevant to WorkPilot. WorkPilot currently uses application-layer sandbox (command guards + path restriction). The two can be combined:

- WorkPilot can add container execution as an option on top of existing application-layer sandbox
- NanoClaw's mount security mechanism (allowlist/blocklist/symlink resolution) directly applicable
- Non-root container execution + ephemeral containers for defense in depth

### 6.2 Skills System (Medium-High Value)

NanoClaw's "don't add features, add skills" philosophy aligns with WorkPilot's SkillsEngine, but implementations differ:

- NanoClaw: Skills are Claude Code SKILL.md files, AI executes code transformations
- WorkPilot: Skills are declarative workflow definitions
- NanoClaw's skills-engine provides robust merge/conflict detection/rollback — useful for WorkPilot plugin lifecycle

### 6.3 Agent Swarms (High Value)

Multi-agent team collaboration is a cutting-edge feature. WorkPilot can consider adding multi-agent coordination layer on top of AgentLoop.

### 6.4 Filesystem IPC (Medium Value)

JSON file-based IPC between host and container. If WorkPilot adds container execution mode, this IPC pattern is worth referencing.

### 6.5 Claude Agent SDK Integration (Medium Value)

NanoClaw directly integrates Anthropic Claude Agent SDK (not just API calls), providing native Agent capabilities (Hooks, Session management, Compact, etc.). If WorkPilot deeply binds to Claude ecosystem, this path is worth considering.

### 6.6 MessageStream (Medium Value)

Push-based async iterable design that allows injecting user messages while Agent is running — useful for WorkPilot's AgentLoop real-time interaction capabilities.

### Architecture Comparison

| Dimension | NanoClaw | WorkPilot |
|-----------|----------|-----------|
| Complexity | Minimal (few source files) | Full enterprise (20+ modules) |
| Security model | Container isolation (OS-level) | Application-layer sandbox |
| LLM integration | Claude Agent SDK only | LiteLLM (100+ models) |
| Channels | WhatsApp primary | Teams/Outlook/GitHub/ADO |
| Configuration | No config, modify code | Pydantic v2 YAML config |
| Persistence | SQLite | JSONL |
| Gateway | None (single process) | FastAPI REST/SSE |
| Auth | WhatsApp QR code | Entra ID / MSAL |
| Extension | Skills (code transforms) | Plugins + declarative workflows |

### Key Takeaway

NanoClaw's "small enough to understand" design philosophy proves the value of keeping codebases within AI context window range. WorkPilot should consider maintaining similar comprehensibility targets for core modules.
