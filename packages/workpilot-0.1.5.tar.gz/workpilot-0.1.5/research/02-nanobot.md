# nanobot (HKUDS/nanobot) Research Report

> Last updated: 2026-02-27
> Repository: https://github.com/HKUDS/nanobot
> Stars: ~26,100 | License: MIT | Language: Python
> **WorkPilot's direct inspiration source**

---

## 1. Project Overview

HKUDS/nanobot is an **ultra-lightweight personal AI assistant framework** developed by the Hong Kong University Data Science Lab. It implements full Agent functionality in only **~4,000 lines of Python** (vs Claude Code's 430,000 lines — a 99% reduction).

- Created: 2026-02-01
- Latest version: v0.1.4.post2 (2026-02-24)
- PyPI package: `nanobot-ai`
- Runtime: Python >= 3.11

### Also Investigated: nanobot-ai/nanobot

A separate project — a Go + Svelte MCP Agent building platform (1,085 stars, Apache-2.0, v0.0.55). Not the primary inspiration for WorkPilot but its MCP hosting patterns are noted in Section 6.

## 2. Technology Stack

| Category | Technology |
|----------|-----------|
| Language | Python >= 3.11, strict typing |
| Config | Pydantic v2 + Pydantic Settings, JSON config, camelCase/snake_case compatible |
| LLM routing | LiteLLM (100+ models), 20+ providers |
| CLI | Typer |
| Logging | Loguru |
| HTTP | httpx |
| WebSocket | websockets + websocket-client |
| MCP | `mcp` library (>= 1.26.0) |
| Scheduling | croniter |
| Channel SDKs | python-telegram-bot, slack-sdk, lark-oapi, dingtalk-stream, qq-botpy, python-socketio, matrix-nio |
| Build | Hatchling |
| Lint | Ruff |
| Testing | pytest + pytest-asyncio |

## 3. Architecture

```
Channels (Telegram / Discord / WhatsApp / Slack / Feishu / DingTalk / QQ / Matrix / Email / CLI)
    |
    v
MessageBus (asyncio.Queue inbound/outbound)
    |
    v
AgentLoop (LLM <-> Tool execution loop, max 40 iterations)
    |
    +-- ToolRegistry (shell, filesystem, web, mcp, spawn, cron, message)
    +-- ContextBuilder (system prompt + workspace files)
    +-- MemoryStore (MEMORY.md long-term + HISTORY.md searchable log)
    +-- SessionManager (JSONL persistence)
    +-- Sandbox (command guards + path restriction)
    +-- Skills (github, weather, tmux, clawhub, etc.)
    +-- Cron / Heartbeat (scheduled tasks + proactive wake)
```

### Source Structure

```
nanobot/
  agent/
    loop.py          -- Agentic loop (LLM <-> tool execution)
    context.py       -- Prompt builder
    memory.py        -- Two-layer persistent memory
    skills.py        -- Skill loader
    subagent.py      -- Background sub-task execution
    tools/           -- Built-in tools (shell, filesystem, web, mcp, spawn, cron, message)
  bus/               -- Message bus (async inbound/outbound queues)
  channels/          -- Chat channel integrations (12 channels)
  providers/         -- LLM providers (registry pattern, 2-step to add new)
  session/           -- JSONL conversation persistence
  config/            -- Pydantic v2 config schema
  cron/              -- Scheduled tasks
  heartbeat/         -- Heartbeat / proactive wake mechanism
  skills/            -- Built-in skills (github, weather, tmux, clawhub, etc.)
  cli/               -- CLI entry point
```

### Key Architecture Patterns

1. **Message Bus Decoupling**: channels and agent fully decoupled via `asyncio.Queue`
2. **Agentic Loop**: LLM -> tool calls -> LLM -> ... -> final response, max 40 iterations
3. **Two-Layer Memory**: MEMORY.md (long-term facts) + HISTORY.md (grep-searchable log), LLM auto-consolidation
4. **Tool ABC**: All tools inherit `Tool` abstract base class with JSON Schema parameter validation
5. **Provider Registry**: Data-driven registry (`ProviderSpec` dataclass), 2 steps to add a new provider
6. **JSONL Sessions**: Append-only persistence, LLM cache-friendly

## 4. Core Features

### 4.1 Multi-Channel Support (12 platforms)

Telegram, Discord, WhatsApp, Slack, Feishu/Lark, DingTalk, QQ, Matrix (Element), Email (IMAP/SMTP), Mochat (Claw IM), CLI

### 4.2 Built-in Tools

- Shell execution (sandboxed, blocks dangerous commands like `rm -rf /`, fork bombs)
- File system operations (read/write/edit/list, path traversal protection)
- Web search (Brave Search API)
- Web fetch (URL content scraping)
- MCP tool integration (stdio + HTTP transport)
- Spawn (sub-agent generation)
- Cron (scheduled task management)
- Message (cross-channel messaging)

### 4.3 Security

- Dangerous command pattern detection (rm -rf, fork bomb, mkfs, etc.)
- Path traversal protection (`relative_to()` check)
- `restrictToWorkspace` sandbox mode
- `allowFrom` user allowlist
- Command execution timeout (60s)
- Output truncation (10KB)

### 4.4 LLM Providers

20+ providers: OpenRouter, Anthropic, OpenAI, DeepSeek, Groq, Gemini, MiniMax, SiliconFlow, VolcEngine, Dashscope (Qwen), Moonshot/Kimi, Zhipu GLM, vLLM, OpenAI Codex (OAuth), GitHub Copilot (OAuth), custom OpenAI-compatible endpoints.

### 4.5 Other Features

- MCP (Model Context Protocol) integration
- Cron tasks + heartbeat mechanism (HEARTBEAT.md)
- Prompt cache optimization
- Docker + Docker Compose deployment
- systemd user service deployment
- Agent social networking (Moltbook, ClawdChat)
- Voice transcription (Groq Whisper)

## 5. Latest Release — v0.1.4.post2

- 32 PRs merged, 14 new contributors
- Heartbeat system fully refactored (virtual tool call decision mechanism)
- Prompt cache optimization (dynamic context moved from system prompt to user messages)
- Agent reliability enhancements (behavior constraints, full tool history, error prompts)
- Slack thread isolation, Feishu rich text image extraction
- Path traversal security fix
- MCP configurable timeout
- Provider API key hot-reload

## 6. Relevance to WorkPilot

### Direct Lineage — What WorkPilot Borrowed

WorkPilot's architecture is directly modeled on HKUDS/nanobot:

| Feature | nanobot | WorkPilot |
|---------|---------|-----------|
| Message Bus | `asyncio.Queue` inbound/outbound | Same pattern |
| Agent Loop | `loop.py` LLM <-> tool loop | Same pattern |
| Two-Layer Memory | MEMORY.md + HISTORY.md | Same pattern |
| Tool ABC | `Tool` base class + JSON Schema | Same pattern |
| JSONL Sessions | Append-only persistence | Same pattern |
| Channel Decoupling | channels -> bus -> agent | Same pattern |
| Provider Routing | LiteLLM + registry | Same pattern |
| Pydantic v2 Config | camelCase/snake_case support | Enhanced with SecretStr |
| Security Sandbox | Command interception + path restriction | Enhanced (10 deny patterns) |
| CLI | Typer | Same |
| Logging | Loguru | Same |

### WorkPilot's Enterprise Enhancements Over nanobot

1. **Microsoft ecosystem integration**: Teams, Outlook, GitHub, ADO channels + Graph API (mail/calendar/directory)
2. **MSAL Entra ID authentication**: Enterprise identity (nanobot only has simple allowFrom)
3. **FastAPI Gateway**: HTTP gateway + REST + SSE + Webhook endpoints
4. **Security Profiles**: solo/team/strict graduated permission control
5. **SecretStr**: Pydantic SecretStr prevents credential leakage (nanobot uses plaintext config)
6. **Audit logging**: Structured audit + auto-redaction (JWT, AWS key, GitHub PAT, etc.)
7. **Prompt injection detection**: Pattern scanning
8. **Azure Key Vault**: Enterprise credential management
9. **Approval workflow**: Configurable human-in-the-loop
10. **DAG workflow engine**: Declarative multi-step workflows
11. **MCP Server mode**: Expose tools via MCP
12. **Browser automation**: Playwright integration
13. **APScheduler**: More mature than nanobot's croniter

### From nanobot-ai/nanobot (Go/Svelte project)

- MCP host concept: running as standalone MCP host
- Hooks system: TypeScript/JavaScript lifecycle hooks (more flexible)
- Docker sandbox: MCP server containerized isolation
- Directory-based config: `.md` files + YAML front-matter as Agent definitions
- MCP-UI support: Elicitation (user input prompts), progress notifications

### Tracking Recommendations

- **Follow nanobot's rapid updates**: Near-daily releases; provider compatibility, channel stability, and prompt cache optimizations worth tracking
- **Adopt security fixes**: Path traversal protection upgrade from `startswith` to `relative_to()` — directly applicable
- **Heartbeat improvements**: Virtual tool call mechanism for proactive agent wake
