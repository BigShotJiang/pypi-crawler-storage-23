# OpenClaw (openclaw/openclaw) Research Report

> Last updated: 2026-02-27
> Repository: https://github.com/openclaw/openclaw
> Stars: ~235,000 | License: MIT | Language: TypeScript

---

## 1. Project Overview

OpenClaw is the most popular open-source **personal AI assistant platform**, running locally on your own device. Core philosophy: **local-first, privacy-respecting, own-your-data**.

- Created: 2025-11-24
- Latest release: v2026.2.26 (daily CalVer releases)
- Primary contributor: steipete (10,709 commits)
- Origin: evolved from Warelay -> Clawdbot -> Moltbot -> OpenClaw

## 2. Technology Stack

| Layer | Technology |
|-------|-----------|
| Primary language | TypeScript (~86%, 27.8M lines) |
| Native apps | Swift (macOS/iOS) + Kotlin (Android) |
| Runtime | Node.js >= 22 (production), Bun (development) |
| Package manager | pnpm (monorepo workspace) |
| Build | tsdown (TS build), tsgo (type checking) |
| Linting | Oxlint + Oxfmt (Rust-based) |
| Testing | Vitest + V8 coverage (70% threshold) |
| Deployment | Docker / Docker Compose / Fly.io / Nix / Podman |
| Documentation | Mintlify (docs.openclaw.ai) |

**Key dependencies:**
- Channels: Baileys (WhatsApp), grammY (Telegram), discord.js (Discord), Bolt (Slack), signal-cli (Signal)
- Browser automation: Playwright / Chrome DevTools Protocol
- TTS: ElevenLabs, sherpa-onnx
- Models: 100+ models (Anthropic, OpenAI, Google Gemini, Azure OpenAI, etc.), recommended: Anthropic Opus 4.6
- MCP: via mcporter bridge

## 3. Architecture

```
Multi-Channel (WhatsApp / Telegram / Slack / Discord / Signal / iMessage / Teams / Matrix / ...)
               |
               v
       Gateway (WebSocket control plane, ws://127.0.0.1:18789)
               |
               +-- Pi Agent Runtime (RPC mode, tool streaming + block streaming)
               +-- CLI Surface (gateway, agent, send, wizard, doctor)
               +-- WebChat UI (built-in web chat interface)
               +-- macOS / iOS / Android native apps
               +-- Canvas Host (A2UI visual workspace)
               +-- Cron / Webhooks (scheduled tasks + event triggers)
               +-- Browser Control (dedicated Chrome instance)
               +-- Skills Platform (bundled/managed/workspace skills)
               +-- Plugin System (npm distribution + local extensions)
```

### Core Architecture Patterns

1. **Gateway Control Plane**: All channels connect via WebSocket to a single Gateway, unified management of sessions, channels, tools and events
2. **Agent Runtime (Pi)**: RPC-mode agent runtime with tool streaming and block streaming
3. **Multi-Channel Routing**: Inbound channel/account/peer can route to isolated Agents (workspace + independent sessions)
4. **Session Model**: `main` for direct chat, group isolation, activation mode, queue mode, reply passback
5. **Extension/Plugin Architecture**: Core stays lean, optional features via npm-distributed plugins
6. **Media Pipeline**: Image/audio/video transcription, size limits, temp file lifecycle management

### Key Source Directories

| Directory | Responsibility |
|-----------|---------------|
| `src/gateway/` | Gateway server (~150+ files) |
| `src/channels/` | Channel registration, routing, flow control |
| `src/telegram/`, `src/discord/`, `src/slack/` | Per-channel implementations |
| `src/memory/` | Vector memory (SQLite-vec, embeddings, hybrid search) |
| `src/security/` | Audit, DM policies, regex safety, temp path protection |
| `src/providers/` | LLM provider integrations |
| `src/browser/` | Browser automation |
| `src/canvas-host/` | A2UI visual workspace |
| `extensions/` | Channel extension plugins (40+) |
| `apps/` | Native apps (macOS/iOS/Android) |
| `skills/` | Skills system (60+ built-in) |

## 4. Core Features

### 4.1 Multi-Channel Messaging (15+ channels)

- **Built-in**: WhatsApp, Telegram, Slack, Discord, Google Chat, Signal, iMessage, WebChat
- **Extensions**: BlueBubbles, Microsoft Teams, Matrix, Zalo, LINE, Feishu, IRC, Nostr, Twitch, Mattermost, Nextcloud Talk, Synology Chat
- Per-channel DM policy (pairing/allowlist/open), group routing, command gateway

### 4.2 Native Cross-Platform Apps

- **macOS menu bar app**: control plane, Voice Wake/PTT, Talk Mode, WebChat, debug tools
- **iOS**: Canvas, Voice Wake, Talk Mode, camera, screen recording, Bonjour pairing
- **Android**: Canvas, Talk Mode, camera, screen recording, optional SMS, device state/info

### 4.3 Voice & Vision

- **Voice Wake**: always-listening on macOS/iOS/Android
- **Talk Mode**: ElevenLabs-based voice conversation overlay
- **Live Canvas (A2UI)**: agent-driven visual workspace (push/reset/evaluate/snapshot)

### 4.4 Tools & Automation

- **Browser Control**: dedicated Chrome/Chromium instance, snapshots, actions, uploads
- **Cron**: scheduled agent tasks
- **Webhooks**: inbound event triggers
- **Gmail Pub/Sub**: Gmail message push integration
- **Skills Platform**: 60+ built-in (GitHub, Slack, Discord, coding agent, Apple Notes, Obsidian, Notion, Weather, Spotify, etc.)

### 4.5 Security

- DM pairing mechanism (unknown senders verified via pairing code)
- Per-channel allowlists
- Audit logging (all tool calls, messages, security events)
- Sandbox path protection (workspace restriction + symlink escape prevention)
- SSRF protection (blocks localhost/private IP fetches by default)
- Node execution approval (structured commandArgv approval + versioned binding matching)
- Security profiles (graduated permission control)

### 4.6 Memory System

- Vector embedding memory: SQLite-vec + multiple embedding providers (OpenAI, Gemini, Voyage, Mistral)
- Hybrid search: vector + full-text + MMR dedup + time decay
- Batch operations: embedding batch processing + incremental sync
- QMD query parsing: structured memory query language

### 4.7 MCP Support

- Via **mcporter** bridge (keeps decoupled)
- Dynamic add/change MCP servers without Gateway restart

## 5. Latest Release — v2026.2.26

- **External secrets management**: `openclaw secrets` full workflow (audit, configure, apply, reload)
- **ACP/thread-bound agents**: ACP agents as first-class runtime for thread sessions
- **Agent routing CLI**: `openclaw agents bindings/bind/unbind`
- **Codex WebSocket transport**: `openai-codex` defaults to WebSocket (SSE fallback)
- **Android device capabilities**: device state/info + notification list node commands
- **Security fixes**: sandbox path alias protection, plugin channel HTTP auth hardening, Node execution approval strengthening, device pairing metadata lockdown

## 6. Relevance to WorkPilot

### Directly Applicable

| OpenClaw Feature | WorkPilot Mapping | Reference Value |
|-----------------|-------------------|-----------------|
| Gateway WS control plane | Gateway (FastAPI) | WS design better for real-time bidirectional communication |
| Multi-channel routing + account binding | Channels (Teams/Outlook/GitHub/ADO) | Mature channel abstraction and per-channel DM policies |
| DM pairing + Allowlist | Channel Allowlists | Pairing code more secure and user-friendly than static allowlist |
| Skills Platform (60+) | SkillsEngine | bundled/managed/workspace three-tier skill model + ClawHub distribution |
| Plugin/Extension system | Plugins | npm distribution + local extension loading + plugin sandbox |
| Vector memory (SQLite-vec) | MemoryStore (MEMORY.md + HISTORY.md) | Vector search + hybrid retrieval far more advanced |
| Sandbox + symlink escape detection | Sandbox | Symlink escape prevention, temp path protection |
| Node execution approval bindings | Approval Workflow | Structured argv approval + versioned bindings |

### Key Differences

| Dimension | OpenClaw | WorkPilot |
|-----------|---------|-----------|
| Language | TypeScript (Node.js) | Python |
| Target | Personal AI assistant | Enterprise AI coding+office assistant |
| Channel focus | Social/messaging (WhatsApp, Telegram...) | Enterprise (Teams, Outlook, GitHub, ADO) |
| LLM integration | Direct multi-provider + OAuth | LiteLLM unified routing |
| Auth | Pairing code + local allowlist | Entra ID (MSAL) |
| Deployment | Local device + optional remote | Enterprise server |
| Microsoft integration | Teams as one channel | Deep Graph API (Mail, Calendar, Directory) |

### Recommendations

1. **Channel abstraction**: Reference `channels/registry.ts` + `channels/session.ts` + `routing/` for channel lifecycle and routing decoupling
2. **Memory upgrade**: SQLite-vec vector storage + hybrid search + time decay as long-term replacement for file-based memory
3. **Security hardening**: Symlink escape detection, structured execution approval bindings, SSRF protection
4. **Skills distribution**: ClawHub marketplace model for extensibility
5. **Gateway real-time**: Consider adding WebSocket support alongside REST/SSE
