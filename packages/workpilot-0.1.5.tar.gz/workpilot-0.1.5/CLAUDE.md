# WorkPilot — Enterprise AI Assistant

## Overview

WorkPilot is an enterprise-grade AI coding and office assistant built with Python.
Inspired by [HKUDS/nanobot](https://github.com/HKUDS/nanobot) — ultra-lightweight,
safe by default, with Microsoft ecosystem integration (Teams, Web Chat)
and dual development + office productivity capabilities.

## Architecture

> Full spec: [design/core-infra.md](design/core-infra.md)

```
┌─────────────────────────────────────────────────────────────┐
│                    Transport Layer                            │
│                                                              │
│  Tier 1: CLI Channel          (always available)             │
│  Tier 2: Self-Hosted Gateway  (REST/SSE/WS, opt-in)         │
│  Tier 3: Cloud Gateway        (Teams, Web Chat via WSS)      │
│                                                              │
└──────────────────────────┬──────────────────────────────────┘
                           │
┌──────────────────────────▼──────────────────────────────────┐
│                    Message Bus                                │
│  Inbound Queue (100) + Outbound Queue (100) + Event Bus      │
│  Sequential processing lock · 15+ typed events               │
└──────────────────────────┬──────────────────────────────────┘
                           │
┌──────────────────────────▼──────────────────────────────────┐
│                    Processing Layer                           │
│                                                              │
│  Agent Loop (default agent — primary orchestrator)           │
│    Research → Context Assembly → LLM ↔ Tool Loop → Response  │
│    Spawns: explorer (fast/read-only) · user-defined agents   │
│                                                              │
│  ┌──────────────────────────┐  ┌────────────────────┐       │
│  │     Tool Registry        │  │   Skills (SKILL.md) │       │
│  │  14 protected + MCP      │  │   Prompt overlays   │       │
│  │  (browser/cron optional) │  │   Progressive        │       │
│  │                          │  │   disclosure         │       │
│  │  Hook pipeline (3-phase):│  │   (2% context budget)│       │
│  │  preflight (sequential)  │  │                      │       │
│  │  → execute (parallel)    │  │  Bundled: github,    │       │
│  │  → postflight (sequential│  │  review, office, ado │       │
│  │                          │  └────────────────────┘       │
│  │  Approval: never/auto/   │                                │
│  │  always · Security       │                                │
│  │  Classifier (fast LLM)   │                                │
│  └──────────────────────────┘                                │
└─────────────────────────────────────────────────────────────┘
                           │
┌──────────────────────────▼──────────────────────────────────┐
│                    Foundation Layer                           │
│                                                              │
│  Provider (LiteLLM + circuit breaker + cost tracking)        │
│  Memory (MEMORY.md facts + SQLite history)                   │
│  Session (JSONL append-only + fork for sub-agents)           │
│  Security (sandbox + audit + leak detect + E-stop +          │
│            Security Classifier + SSRF)                       │
│  Observer (Log / Prometheus / OTLP)                          │
│  Config (YAML + env + profiles: open/standard/controlled/    │
│          restricted)                                          │
│  Scheduler (cron + interval + event + heartbeat)             │
└─────────────────────────────────────────────────────────────┘
```

## Built-in Agents

> Full spec: [design/builtin-agents.md](design/builtin-agents.md)

3 built-in agents (defined in `workpilot/agents/builtin.py`) + 5 bundled templates:

| Agent | Type | Model | Description |
|-------|------|-------|-------------|
| `default` | built-in | auto | Primary orchestrator, user interaction, spawns sub-agents |
| `explorer` | built-in | fast | Fast codebase search — read-only tools, 10x cheaper |
| `security` | built-in | fast | Internal Security Classifier — evaluates tool calls (not user-facing) |
| `coder` | template | auto | Code implementation, testing |
| `reviewer` | template | auto | Code review |
| `tester` | template | auto | Test generation |
| `researcher` | template | auto | Web + file research |
| `communicator` | template | auto | Email/message drafting |

## Directory Structure

```
workpilot/
+-- runtime.py          # Main orchestrator — wires all subsystems
+-- agent/              # Agentic loop, context, memory, skills, compaction, loop detection
|   +-- tools/          # 14 protected tools: shell, filesystem, git, web, browser*, spawn,
|                       # message, cron*  (* = conditional on config)
+-- agents/             # Built-in agent configs + merge_agents()
+-- bus/                # Message queues (bounded 100) + typed event pub/sub
+-- channels/           # CLI · Web (Tier 2) · Cloud Gateway WSS (Tier 3)
+-- config/             # Pydantic v2 schema + YAML/env loader + profiles
+-- providers/          # LiteLLM + circuit breaker + model aliases
+-- session/            # JSONL append-only sessions + fork for sub-agents
+-- security/           # Sandbox · audit · RBAC · leak detection · E-stop ·
|                       # Security Classifier · SSRF
+-- hooks/              # 4 hook points, 8 built-in handlers
+-- mcp/                # MCP server (expose tools) + MCP client (consume tools)
+-- cron/               # Unified scheduler (cron/interval/event/heartbeat)
+-- gateway/            # FastAPI self-hosted server (Tier 2): REST/SSE/WS
+-- templates/          # Identity file templates (SOUL, USER, AGENTS, MEMORY, TOOLS)
+-- utils/helpers.py    # get_data_dir(), webchat_url_from_connect(), etc.
+-- plugins/            # Dynamic plugin discovery
+-- cli/commands.py     # All CLI commands (Typer)
tests/                  # pytest + pytest-asyncio
cloud_gateway/          # .NET 10 Cloud Gateway — separate service
    src/CloudGateway/
    +-- Endpoints/      # /, /chat, /auth/*, /webchat/status
    +-- Relay/          # /connect WSS (Python client) · /webchat WSS (browser)
    +-- Services/       # IClientRegistry, IMessageDelivery, OutboundRouter
    +-- Helpers/        # ClaimHelper: GetOid(), GetUpn()
    +-- Templates/      # chat.html, login.html, auth-msal.js (EmbeddedResource)
```

## Key Design Patterns

> Full specs: [design/core/](design/core/) (5 core specs) + [design/features/](design/features/) (14+ feature specs)

1. **Protocol-first** — every subsystem boundary is an abstract protocol (Tool, Channel, Provider, Memory, Session, Skill, Observer)
2. **Message Bus** — channels and agent decoupled via bounded async queues (100) + typed event pub/sub (15+ events)
3. **Agentic Loop** — research phase → context assembly → LLM ↔ tool loop → session persist (nanobot ancestor + ZeroClaw research + IronClaw compaction)
4. **Tool Hook Pipeline (3-phase)** — preflight hooks sequential (E-stop, RBAC, Security Classifier) → execute **parallel** (independent tools via asyncio.gather) → postflight hooks sequential (leak scan, redact, audit)
5. **Tool Approval** — each tool declares `approval: never | auto | always`; `auto` tools go through the Security Classifier (fast LLM, arg redaction, 5-min cache); `escalate` decisions are currently treated as reject (human-in-the-loop routing is planned for v0.2)
6. **Two-Layer Memory** — MEMORY.md (8KB facts, always in context) + SQLite History Store (FTS5, searchable archive, 90-day TTL)
7. **Skills as Prompts** — SKILL.md with YAML frontmatter; LLM reads and uses tools autonomously; progressive disclosure (2% context budget for summaries)
8. **Sub-Agent Delegation** — spawn tool creates scoped child loops (fresh context, restricted tools, permission intersection); parallel fan-out; depth-2 default; session forking tracks lineage
9. **3-Tier Channels** — CLI (local) → Self-Hosted Gateway (REST/SSE/WS) → Cloud Gateway (Teams, Web Chat via outbound WSS; stateless relay, data stays local)
10. **Security Profiles** — open (full autonomy) → standard (medium-risk approval) → controlled (Security Classifier reviews all) → restricted (human-only, sub-agents disabled)
11. **Graceful Iteration** — nudge at max-2, force-text at max-1, hard stop at max (IronClaw pattern)
12. **Loop Detection** — 3 detectors (repeat, poll, ping-pong); inject warning → terminate if persists
13. **Context Compaction** — 3-tier at 80/85/95%; MEMORY.md survives compaction (re-read from disk)
14. **Cloud Auto-Connect** — `runtime._start_cloud_if_enabled()` called on every startup; silent auth only in chat mode; full interactive login in gateway mode; MSAL token persisted to `~/.workpilot/token_cache_<client_id[:8]>.json`
15. **Scheduler** — unified cron/interval/event/heartbeat via APScheduler; jobs run via `AgentLoop.run_once()`; session modes: `isolated` (fresh context) or `persistent` (shared across runs)

## Enterprise Safety Features

- **Command sandbox**: deny patterns in `config/schema.py → ShellConfig.deny_patterns` (not sandbox.py)
- **Path sandbox**: workspace restriction, deny-listed sensitive paths, SSRF protection (`security/ssrf.py`)
- **Audit logging**: every tool call, message, and security event — append-only with auto redaction
- **Secret redaction**: JWT, AWS keys, GitHub PATs, OpenAI keys, Slack tokens, high-entropy strings
- **Leak detection**: credential pattern scan on all tool output + outbound messages
- **E-stop**: global halt — manual or automatic (on leak detection); all loops exit, gateway 503
- **Security Classifier** (`security/classifier.py`): fast LLM classifier; redacts sensitive arg keys before classification; 5-min result cache; `escalate` → reject (human routing planned v0.2)
- **Security profiles**: open / standard / controlled / restricted — graduated autonomy
- **Per-agent permissions**: `AgentPermissions` in `AgentConfig` overrides profile per agent
- **Entra ID auth**: MSAL-based token validation for Gateway and Cloud Gateway
- **MCP tool isolation**: untrusted by default; container isolation in restricted profile

## Running

```bash
pip install -e ".[dev]"        # Install with dev deps
pip install -e ".[all]"        # Install with all optional deps
workpilot onboard              # Interactive project setup (was: init)
workpilot agent                # Interactive agent REPL (was: chat)
workpilot run "Fix the bug"    # One-shot prompt
workpilot gateway              # Start self-hosted HTTP gateway server
workpilot cloud                # Connect to Cloud Gateway (Teams, Web Chat)
workpilot status               # Show config status
workpilot doctor               # Diagnose issues
workpilot logs                 # Show recent log output
workpilot version              # Print version string
pytest tests/ -v               # Run tests

# Sub-commands
workpilot agents list|add      # Agent management
workpilot graph login|status   # Microsoft Graph auth
workpilot tools list           # Tool discovery
workpilot mcp list|add|remove  # MCP server management
workpilot sessions list|show   # Session browser
workpilot security audit|credentials|roles
workpilot skills list
workpilot cron list|add
```

## Conventions

- Python >= 3.11, strict typing
- Pydantic v2 for config validation (SecretStr for secrets)
- LiteLLM for unified LLM routing (100+ models)
- FastAPI + Uvicorn for gateway / webhook server
- MSAL for Entra ID / Microsoft Graph authentication
- pytest + pytest-asyncio for testing
- Loguru for structured logging
- Ruff for linting + formatting (`python -m ruff check` / `python -m ruff format`)

## Cloud Gateway (.NET 10)

Separate service in `cloud_gateway/` — **not part of the Python package**.

```bash
cd cloud_gateway
dotnet build CloudGateway.slnx          # Build
dotnet test CloudGateway.slnx           # Test
# Deploy to Azure App Service:
dotnet publish src/CloudGateway/CloudGateway.csproj \
  --configuration Release --runtime win-x64 --self-contained false --output publish/
powershell -Command "Compress-Archive -Path publish\* -DestinationPath deploy.zip -Force"
az webapp deploy --resource-group future-test --name workpilot-gw-dev \
  --src-path deploy.zip --type zip
```

Key patterns:
- `ClaimHelper.GetOid()` / `GetUpn()` — always use these, never `FindFirstValue("oid")` directly (claim mapping differs across .NET versions)
- `RequireAssertion(ctx => HasOid(ctx.User))` — NOT `RequireClaim("oid")` (fails with Microsoft.Identity.Web in .NET 10)
- `ClientConnection.SendJsonAsync()` — all WebSocket sends must go through this (SemaphoreSlim serialises concurrent sends; returns `bool` — `false` = socket closed → buffer/unregister)
- HTML templates in `Templates/` as EmbeddedResource; `{{PLACEHOLDER}}` replaced at startup or per-request

## Design Docs

```
design/
+-- core-infra.md                  # Core architecture & protocols (root spec)
+-- builtin-features.md            # Built-in features overview
+-- builtin-agents.md              # Built-in agents (default, explorer, security) + templates
+-- cloud-gateway/
|   +-- server.md                  # Cloud Gateway server (.NET 10, Azure App Service)
|   +-- webchat-botframework.md    # Web Chat / DirectLine Bot Framework integration
|   +-- teams-bot.md               # Teams bot app design (manifest, OID routing, UAMI auth)
+-- core/
|   +-- agent.md                   # Agent loop: research, compaction, loop detection, streaming
|   +-- tool.md                    # Tool protocol, approval mechanism, registry, security boundary
|   +-- channel.md                 # 3-tier channel model, routing, auth, session mapping
|   +-- message-bus.md             # Queues, event bus, message types, injection
|   +-- skill.md                   # SKILL.md format, discovery, trust model, progressive disclosure
|   +-- scheduler.md               # Scheduler protocol (cron, interval, event, heartbeat)
+-- features/
    +-- agent-default.md           # Default agent: prompt assembly, delegation, memory, compaction
    +-- agent-explorer.md          # Explorer agent: fast model, read-only, cost savings
    +-- agent-security.md          # Security agent: approval classifier, input redaction, caching
    +-- cli.md                     # CLI commands, REPL, init wizard, management sub-commands
    +-- channel-cli.md             # CLI channel spec
    +-- channel-web.md             # Self-hosted gateway spec
    +-- channel-cloud.md           # Cloud Gateway client spec
    +-- tool-shell.md              # Shell tool: 3-layer security, background mode
    +-- tool-files.md              # File tools: read, write, edit, list, search
    +-- tool-git.md                # Git tool: read/write/push/dangerous classification
    +-- tool-http.md               # HTTP tools: request, web_search, web_fetch
    +-- tool-browser.md            # Browser tool: Playwright automation
    +-- tool-spawn.md              # Spawn tool: sub-agent delegation, depth, concurrency
    +-- tool-message.md            # Message tool: cross-channel publishing
    +-- tool-cron.md               # CronTool: agent self-scheduling
```

## Git Workflow

> **CRITICAL: NEVER push directly to `main`.** Always use a feature branch.

```bash
# Always create a branch first
git checkout -b feat/<name>    # new feature
git checkout -b fix/<name>     # bug fix
git checkout -b docs/<name>    # documentation

# Push branch and open PR
git push -u origin <branch>
gh pr create ...

# Only merge to main via PR — never git push origin main
```

- `main` is protected — all changes go through pull requests
- If you accidentally push to main, **do not push again to undo it**. Instead:
  ```bash
  git checkout -b revert/<name>
  git revert HEAD --no-edit
  git push -u origin revert/<name>
  gh pr create ...   # merge the revert via PR
  ```
