# Build the WorkPilot Teams app package (WorkPilot-teams-app.zip)
# Run from the teams/ directory:  .\build.ps1

$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ScriptDir

# Validate
if (-not (Test-Path "manifest.json")) { Write-Error "manifest.json not found"; exit 1 }
if (-not (Test-Path "color.png") -or -not (Test-Path "outline.png")) {
    Write-Error "color.png / outline.png not found"
    exit 1
}

# Package
$out = "WorkPilot-teams-app.zip"
if (Test-Path $out) { Remove-Item $out }
Compress-Archive -Path manifest.json, color.png, outline.png -DestinationPath $out
Write-Host "Created $out  ($((Get-Item $out).Length / 1KB) KB)"
Write-Host ""
Write-Host "Install in Teams:"
Write-Host "  Teams → Apps → Manage your apps → Upload a custom app → $out"
