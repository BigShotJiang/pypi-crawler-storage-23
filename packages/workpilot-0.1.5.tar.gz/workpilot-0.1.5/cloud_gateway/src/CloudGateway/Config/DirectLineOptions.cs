namespace CloudGateway.Config;

/// <summary>
/// Configuration for the Azure Bot Service DirectLine Web Chat integration.
/// Enables POST /webchat/directline/token and GET /webchat/ui endpoints.
/// </summary>
public sealed class DirectLineOptions
{
    public const string Section = "DirectLine";

    /// <summary>
    /// Enable the DirectLine token and Web Chat UI endpoints.
    /// Automatically set to true by Bicep when DirectLine__Secret is non-empty.
    /// </summary>
    public bool Enabled { get; set; } = false;

    /// <summary>
    /// Web Chat channel DirectLine secret from Azure Bot Service.
    /// Store in Azure Key Vault for production deployments.
    /// Never expose this value to browser clients — only the generated token is returned.
    /// </summary>
    public string Secret { get; set; } = string.Empty;

    /// <summary>
    /// Trusted origin injected into DirectLine tokens (e.g. "https://your-gateway.azurewebsites.net").
    /// Used in the trustedOrigins field of the token-generate request so DirectLine
    /// restricts which origins may use the token.
    /// Must be configured explicitly — do NOT derive from the incoming Host header,
    /// which is controlled by the caller and could be spoofed.
    /// If empty, no trustedOrigins restriction is sent to DirectLine.
    /// </summary>
    public string TrustedOrigin { get; set; } = string.Empty;
}
