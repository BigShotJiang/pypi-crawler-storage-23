using Microsoft.AspNetCore.Authentication;

namespace CloudGateway.Config;

/// <summary>
/// Configuration for the development-only bypass authentication mode.
/// MUST only be enabled in Development environment.
/// </summary>
public sealed class BypassAuthOptions : AuthenticationSchemeOptions
{
    public const string Scheme  = "DevBypass";
    public const string Section = "Auth:Bypass";

    /// <summary>Must be explicitly true to activate bypass. Never defaults to true.</summary>
    public bool Enabled { get; set; } = false;

    /// <summary>The Bearer token value that triggers bypass authentication.</summary>
    public string Token { get; set; } = "dev-bypass";

    /// <summary>Fake Entra OID injected into the synthetic ClaimsPrincipal.</summary>
    public string Oid { get; set; } = "00000000-0000-0000-0000-000000000001";

    /// <summary>Fake UPN injected into the synthetic ClaimsPrincipal.</summary>
    public string Upn { get; set; } = "dev@localhost";
}
