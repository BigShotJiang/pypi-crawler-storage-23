namespace CloudGateway.Config;

public sealed class TeamsOptions
{
    public const string Section = "Teams";

    /// <summary>Enable the Teams bot endpoint (POST /bot/teams).</summary>
    public bool Enabled { get; set; } = true;
}
