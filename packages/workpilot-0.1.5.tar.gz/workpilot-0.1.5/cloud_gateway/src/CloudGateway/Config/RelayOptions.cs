namespace CloudGateway.Config;

public sealed class RelayOptions
{
    public const string Section = "Relay";

    /// <summary>Interval at which the server sends ping frames to connected clients.</summary>
    public int HeartbeatIntervalSeconds { get; set; } = 30;

    /// <summary>Maximum time to wait for a pong reply before closing the connection.</summary>
    public int HeartbeatTimeoutSeconds { get; set; } = 10;

    /// <summary>How long buffered messages are held for offline clients.</summary>
    public int OfflineBufferTtlMinutes { get; set; } = 60;

    /// <summary>Maximum buffered messages per user (oldest dropped first when exceeded).</summary>
    public int OfflineBufferMaxMessages { get; set; } = 100;

    /// <summary>
    /// Active response timeout for Web Chat only.
    /// Teams has no active timeout — agent upstream timeout is the limit.
    /// </summary>
    public int ResponseTimeoutSeconds { get; set; } = 120;

    /// <summary>How long a ReplyContext entry is kept before passive TTL cleanup.</summary>
    public int ReplyContextTtlMinutes { get; set; } = 60;

    /// <summary>Background eviction scan interval for expired ReplyContext entries.</summary>
    public int ReplyContextEvictionIntervalMinutes { get; set; } = 5;

    /// <summary>Maximum accumulated chunk content per channel_id for Teams buffering (bytes).</summary>
    public int ChunkBufferMaxBytes { get; set; } = 102_400;

    /// <summary>
    /// Public URL of this gateway shown in offline notifications sent to Teams.
    /// Example: https://workpilot-gw-dev.azurewebsites.net
    /// Leave empty to omit the website link from the offline message.
    /// </summary>
    public string HomeUrl { get; set; } = "";

    public TimeSpan HeartbeatInterval => TimeSpan.FromSeconds(HeartbeatIntervalSeconds);
    public TimeSpan HeartbeatTimeout => TimeSpan.FromSeconds(HeartbeatTimeoutSeconds);
    public TimeSpan OfflineBufferTtl => TimeSpan.FromMinutes(OfflineBufferTtlMinutes);
    public TimeSpan ResponseTimeout => TimeSpan.FromSeconds(ResponseTimeoutSeconds);
    public TimeSpan ReplyContextTtl => TimeSpan.FromMinutes(ReplyContextTtlMinutes);
    public TimeSpan ReplyContextEvictionInterval => TimeSpan.FromMinutes(ReplyContextEvictionIntervalMinutes);
}
