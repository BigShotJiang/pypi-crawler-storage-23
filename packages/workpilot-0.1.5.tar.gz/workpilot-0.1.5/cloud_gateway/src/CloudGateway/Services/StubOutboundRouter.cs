using CloudGateway.Models;
using Microsoft.Extensions.Logging;

namespace CloudGateway.Services;

/// <summary>
/// Phase 6 stub — logs routed frames; replaced by real implementations in Phase 7/8.
/// </summary>
public sealed class StubOutboundRouter(ILogger<StubOutboundRouter> logger) : IOutboundRouter
{
    public Task RouteResponseAsync(
        ResponseFrame frame,
        ReplyContext context,
        CancellationToken cancellationToken = default)
    {
        logger.LogDebug(
            "[STUB] Route response channel_id={ChannelId} source={Source}",
            frame.ChannelId, context.Source);
        return Task.CompletedTask;
    }

    public Task RouteChunkAsync(
        ChunkFrame frame,
        ReplyContext context,
        CancellationToken cancellationToken = default)
    {
        logger.LogDebug(
            "[STUB] Route chunk channel_id={ChannelId} done={Done} source={Source}",
            frame.ChannelId, frame.Done, context.Source);
        return Task.CompletedTask;
    }
}
