using CloudGateway.Models;

namespace CloudGateway.Services;

/// <summary>
/// Holds MessageFrames for users who are currently offline.
/// Messages are delivered in FIFO order when the client reconnects.
/// </summary>
public interface IOfflineBuffer
{
    void Enqueue(string oid, MessageFrame message);

    /// <summary>
    /// Drain all non-expired buffered messages for the user (called on reconnect).
    /// Clears the buffer for that OID after draining.
    /// </summary>
    IReadOnlyList<MessageFrame> Drain(string oid);
}
