using CloudGateway.Models;

namespace CloudGateway.Services;

/// <summary>
/// Maps channel_id → ReplyContext.
/// Validates owner_oid on retrieval to prevent cross-user reply injection.
/// </summary>
public interface IReplyContextStore
{
    void Store(ReplyContext context);

    /// <summary>
    /// Returns the context if found and ownerOid matches.
    /// Returns null if not found, expired, or ownerOid mismatch (security boundary).
    /// Caller should log SECURITY WARNING on mismatch — this method does not.
    /// </summary>
    ReplyContext? Get(string channelId, string ownerOid);

    /// <summary>Returns the context without owner check (for internal cleanup only).</summary>
    ReplyContext? GetUnchecked(string channelId);

    void Delete(string channelId);
}
