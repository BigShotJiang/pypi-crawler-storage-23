using System.Net.WebSockets;

namespace CloudGateway.Services;

/// <summary>Active browser Web Chat WebSocket connection.</summary>
public sealed class WebChatConnection
{
    public required string ConnectionId { get; init; }   // opaque per-connection ID
    public required string Oid          { get; init; }
    public required string Upn          { get; init; }
    public required WebSocket Socket    { get; init; }
    public DateTimeOffset ConnectedAt   { get; init; } = DateTimeOffset.UtcNow;
}

/// <summary>
/// Tracks active browser Web Chat WebSocket connections.
/// Maps connection_id → WebChatConnection for outbound routing.
/// </summary>
public interface IWebChatRegistry
{
    void Register(WebChatConnection connection);
    void Unregister(string connectionId);
    WebChatConnection? Get(string connectionId);
    bool IsActive(string connectionId);

    /// <summary>Number of active connections for the given OID.</summary>
    int CountByOid(string oid);
}
