using System.Collections.Concurrent;

namespace CloudGateway.Services;

/// <summary>
/// In-memory client registry using ConcurrentDictionary.
/// Single App Service instance in v1 — no distributed state needed.
/// Future: replace with Azure SignalR Service backplane for multi-instance.
/// </summary>
public sealed class InMemoryClientRegistry : IClientRegistry
{
    private readonly ConcurrentDictionary<string, List<ClientConnection>> _store = new();
    private readonly object _lock = new();

    public void Register(ClientConnection connection)
    {
        _store.AddOrUpdate(
            connection.Oid,
            _ => [connection],
            (_, list) =>
            {
                lock (_lock) { list.Add(connection); }
                return list;
            });
    }

    public void Unregister(ClientConnection connection)
    {
        if (!_store.TryGetValue(connection.Oid, out var list)) return;

        lock (_lock)
        {
            list.Remove(connection);
        }

        if (list.Count == 0)
            _store.TryRemove(connection.Oid, out _);
    }

    public ClientConnection? GetActive(string oid)
    {
        if (!_store.TryGetValue(oid, out var list)) return null;

        lock (_lock)
        {
            return list
                .OrderByDescending(c => c.LastActivity)
                .FirstOrDefault();
        }
    }

    public IReadOnlyList<ClientConnection> GetAll(string oid)
    {
        if (!_store.TryGetValue(oid, out var list)) return [];

        lock (_lock) { return list.ToList(); }
    }

    public bool IsOnline(string oid) => GetActive(oid) is not null;
}
