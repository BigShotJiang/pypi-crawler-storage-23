using System.Collections.Concurrent;

namespace CloudGateway.Services;

public sealed class InMemoryWebChatRegistry : IWebChatRegistry
{
    private readonly ConcurrentDictionary<string, WebChatConnection> _store = new();

    public void Register(WebChatConnection connection) =>
        _store[connection.ConnectionId] = connection;

    public void Unregister(string connectionId) =>
        _store.TryRemove(connectionId, out _);

    public WebChatConnection? Get(string connectionId) =>
        _store.TryGetValue(connectionId, out var c) ? c : null;

    public bool IsActive(string connectionId) => _store.ContainsKey(connectionId);

    public int CountByOid(string oid) =>
        _store.Values.Count(c => c.Oid == oid);
}
