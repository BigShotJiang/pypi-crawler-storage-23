using System.Buffers;
using System.Collections.Concurrent;
using System.Text;
using CloudGateway.Config;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace CloudGateway.Services;

/// <summary>
/// Accumulates streaming chunk content per channel_id for Teams delivery.
/// Teams has no streaming API — chunks are buffered until done=true, then sent as one reply.
/// </summary>
public sealed class StreamingChunkBuffer
{
    private const string TruncationNote = "\n\n[Response truncated: exceeded maximum length]";

    /// <summary>
    /// Pairs a <see cref="StringBuilder"/> with its current UTF-8 byte count so
    /// <see cref="Append"/> stays O(added content) instead of O(total content).
    /// </summary>
    private sealed class Buffer
    {
        public readonly StringBuilder Content  = new();
        public          int           ByteCount = 0;
    }

    private readonly ConcurrentDictionary<string, Buffer> _buffers = new();
    private readonly int _maxBytes;
    private readonly ILogger<StreamingChunkBuffer> _logger;

    public StreamingChunkBuffer(
        IOptions<RelayOptions> options,
        ILogger<StreamingChunkBuffer> logger)
    {
        _maxBytes = options.Value.ChunkBufferMaxBytes;
        _logger   = logger;
    }

    /// <summary>Append a chunk for the given channel_id. Returns false if already truncated.</summary>
    public bool Append(string channelId, string content)
    {
        var buf = _buffers.GetOrAdd(channelId, _ => new Buffer());

        lock (buf)
        {
            if (buf.ByteCount >= _maxBytes)
                return false;   // already truncated

            var newBytes = Encoding.UTF8.GetByteCount(content);

            if (buf.ByteCount + newBytes <= _maxBytes)
            {
                buf.Content.Append(content);
                buf.ByteCount += newBytes;
                return true;
            }

            // Truncation needed. Reserve space for the note so the total stays within _maxBytes.
            var noteBytes = Encoding.UTF8.GetByteCount(TruncationNote);
            var available = _maxBytes - noteBytes - buf.ByteCount;

            if (available > 0)
            {
                // Find the largest slice of `content` that fits AND ends on a valid
                // UTF-8 scalar boundary using Rune.DecodeFromUtf8.
                var raw       = Encoding.UTF8.GetBytes(content);
                var span      = raw.AsSpan(0, Math.Min(available, raw.Length));
                int validBytes = 0;

                while (!span.IsEmpty)
                {
                    var status = Rune.DecodeFromUtf8(span, out _, out int consumed);
                    if (status != OperationStatus.Done) break; // incomplete / invalid — stop here
                    validBytes += consumed;
                    span        = span[consumed..];
                }

                if (validBytes > 0)
                {
                    buf.Content.Append(Encoding.UTF8.GetString(raw, 0, validBytes));
                    buf.ByteCount += validBytes;
                }
            }

            buf.Content.Append(TruncationNote);
            buf.ByteCount += noteBytes;
            _logger.LogWarning(
                "Chunk buffer truncated for channel_id={ChannelId} at {Bytes} bytes",
                channelId, buf.ByteCount);
            return false;
        }
    }

    /// <summary>
    /// Retrieve and remove the accumulated content for the given channel_id.
    /// Returns empty string if nothing was buffered.
    /// </summary>
    public string Flush(string channelId)
    {
        if (!_buffers.TryRemove(channelId, out var buf)) return string.Empty;

        lock (buf) { return buf.Content.ToString(); }
    }

    /// <summary>Discard the buffer without returning content (e.g. on timeout).</summary>
    public void Discard(string channelId) =>
        _buffers.TryRemove(channelId, out _);
}
