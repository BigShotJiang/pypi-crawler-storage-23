using CloudGateway.Models;

namespace CloudGateway.Services;

/// <summary>
/// Routes a client response or streaming chunk back to the originating source channel.
/// Phase 6 stub: logs only. Real delivery wired in Phase 7 (WebChat) and Phase 8 (Teams).
/// </summary>
public interface IOutboundRouter
{
    Task RouteResponseAsync(
        ResponseFrame frame,
        ReplyContext context,
        CancellationToken cancellationToken = default);

    Task RouteChunkAsync(
        ChunkFrame frame,
        ReplyContext context,
        CancellationToken cancellationToken = default);
}
