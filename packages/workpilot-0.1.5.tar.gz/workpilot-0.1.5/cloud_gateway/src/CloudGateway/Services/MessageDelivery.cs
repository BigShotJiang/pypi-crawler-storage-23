using System.Net.WebSockets;
using CloudGateway.Models;
using Microsoft.Extensions.Logging;

namespace CloudGateway.Services;

public sealed class MessageDelivery(
    IClientRegistry registry,
    IOfflineBuffer buffer,
    ILogger<MessageDelivery> logger) : IMessageDelivery
{
    public async Task DeliverAsync(string oid, MessageFrame frame, CancellationToken ct = default)
    {
        var client = registry.GetActive(oid);
        if (client is null)
        {
            buffer.Enqueue(oid, frame);
            logger.LogDebug("User {Oid} offline — message buffered", oid);
            return;
        }

        try
        {
            var sent = await client.SendJsonAsync(frame, ct);
            if (sent)
            {
                client.LastActivity = DateTimeOffset.UtcNow;
                logger.LogDebug("Message delivered live to {Oid}", oid);
            }
            else
            {
                // Socket not open — treat as offline and buffer.
                logger.LogWarning("Socket closed for {Oid} — unregistering and buffering", oid);
                registry.Unregister(client);
                buffer.Enqueue(oid, frame);
            }
        }
        catch (Exception ex) when (ex is WebSocketException or InvalidOperationException or OperationCanceledException)
        {
            logger.LogWarning(ex, "WebSocket send failed for {Oid} — buffering", oid);
            registry.Unregister(client);
            buffer.Enqueue(oid, frame);
        }
    }
}
