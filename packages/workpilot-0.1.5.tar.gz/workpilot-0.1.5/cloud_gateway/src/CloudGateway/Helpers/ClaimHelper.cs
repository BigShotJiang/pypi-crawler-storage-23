using System.Security.Claims;

namespace CloudGateway.Helpers;

/// <summary>
/// Claim-extraction helpers that work regardless of whether
/// JwtBearer has MapInboundClaims enabled or disabled.
/// </summary>
internal static class ClaimHelper
{
    /// <summary>
    /// WS-Federation URI used by older claim-type mapping stacks.
    /// Declared once so it never diverges across call sites.
    /// </summary>
    internal const string OidClaimUri =
        "http://schemas.microsoft.com/identity/claims/objectidentifier";

    /// <summary>Returns the Entra OID, trying the short name first.</summary>
    internal static string? GetOid(this ClaimsPrincipal user) =>
        user.FindFirstValue("oid") ?? user.FindFirstValue(OidClaimUri);

    /// <summary>Returns the best available display name / UPN.</summary>
    internal static string GetUpn(this ClaimsPrincipal user, string fallback = "User") =>
        user.FindFirstValue("preferred_username")
        ?? user.FindFirstValue("upn")
        ?? user.Identity?.Name
        ?? fallback;
}
