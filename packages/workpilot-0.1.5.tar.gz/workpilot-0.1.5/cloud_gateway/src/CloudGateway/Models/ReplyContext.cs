namespace CloudGateway.Models;

public enum ReplySource { Teams, WebChat }

/// <summary>
/// Ephemeral routing metadata stored per channel_id.
/// Allows the server to deliver a client response back to the originating source.
/// owner_oid is validated on every outbound response to prevent cross-user reply injection.
/// </summary>
public sealed class ReplyContext
{
    public required string ChannelId   { get; init; }

    /// <summary>
    /// Entra OID of the WorkPilot user whose client received this message.
    /// = from.aadObjectId (Teams) or browser user OID (Web Chat).
    /// Validated against the responding client's OID before delivery.
    /// </summary>
    public required string OwnerOid    { get; init; }

    public required ReplySource Source { get; init; }
    public required DateTimeOffset CreatedAt  { get; init; }
    public required DateTimeOffset ExpiresAt  { get; init; }

    // ── Teams-specific ───────────────────────────────────────────────────────
    public string? ServiceUrl      { get; init; }  // e.g. https://smba.trafficmanager.net/amer/
    public string? ConversationId  { get; init; }  // Bot Framework conversation ID
    public string? ActivityId      { get; init; }  // Original activity ID (replyToId)
    public string? FromId          { get; init; }  // Bot Framework user ID ("29:...")
    public string? TenantId        { get; init; }  // Entra tenant ID

    // ── Web Chat-specific ────────────────────────────────────────────────────
    public string? WebChatConnectionId { get; init; }  // browser WebSocket identifier

    // ── Teams streaming buffer ───────────────────────────────────────────────
    // Accumulated chunk content for Teams (no streaming API — sent as one reply on done).
    // Stored separately in StreamingChunkBuffer, not here.
}
