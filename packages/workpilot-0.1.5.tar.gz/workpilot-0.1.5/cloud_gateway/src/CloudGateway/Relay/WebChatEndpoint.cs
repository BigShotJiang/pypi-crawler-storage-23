using System.Buffers;
using System.Net.WebSockets;
using System.Security.Claims;
using System.Text.Json;
using CloudGateway.Config;
using CloudGateway.Helpers;
using CloudGateway.Models;
using CloudGateway.Services;
using Microsoft.Extensions.Options;

namespace CloudGateway.Relay;

public static class WebChatEndpoint
{
    public static IEndpointRouteBuilder MapWebChatEndpoint(this IEndpointRouteBuilder app)
    {
        // Authenticated via cookie (production OIDC) or bypass Bearer (development).
        // Uses "WebChatUser" policy which requires oid claim.
        app.MapGet("/webchat", HandleAsync)
           .RequireAuthorization("WebChatUser");

        // GET /webchat/status — returns whether the user's WorkPilot client is online.
        // Used by the SPA to show "agent online/offline" before opening WebSocket.
        app.MapGet("/webchat/status", (
            HttpContext ctx,
            IClientRegistry clientRegistry) =>
        {
            var oid = ctx.User.GetOid();
            if (string.IsNullOrEmpty(oid))
                return Results.Unauthorized();

            return Results.Ok(new
            {
                online = clientRegistry.IsOnline(oid),
                oid,
            });
        }).RequireAuthorization("WebChatUser");

        return app;
    }

    private static async Task HandleAsync(
        HttpContext ctx,
        IWebChatRegistry webChatRegistry,
        IClientRegistry clientRegistry,
        IReplyContextStore replyStore,
        IMessageDelivery delivery,
        IOptions<RelayOptions> relayOpts,
        IOptions<RateLimitOptions> rateLimitOpts,
        ILogger<Program> logger)
    {
        if (!ctx.WebSockets.IsWebSocketRequest)
        {
            ctx.Response.StatusCode = StatusCodes.Status400BadRequest;
            return;
        }

        var oid = ctx.User.GetOid()!;
        var upn = ctx.User.GetUpn(oid);

        // Enforce per-user WebSocket connection cap before accepting the upgrade.
        var maxConns = rateLimitOpts.Value.MaxWebSocketConnectionsPerUser;
        if (webChatRegistry.CountByOid(oid) >= maxConns)
        {
            ctx.Response.StatusCode = StatusCodes.Status429TooManyRequests;
            ctx.Response.Headers["Retry-After"] = "60";
            logger.LogWarning(
                "WebSocket cap ({Max}) reached for {Oid} — rejecting /webchat", maxConns, oid);
            return;
        }

        var opts         = relayOpts.Value;
        var connectionId = $"wc-conn-{Guid.NewGuid()}";
        var threadId     = WireFrames.WebChatThreadId(oid);   // "wc_{full-oid}"

        using var ws = await ctx.WebSockets.AcceptWebSocketAsync();

        var connection = new WebChatConnection
        {
            ConnectionId = connectionId,
            Oid          = oid,
            Upn          = upn,
            Socket       = ws,
        };
        webChatRegistry.Register(connection);
        logger.LogInformation("WebChat connected: {Upn} ({Oid})", upn, oid);

        try
        {
            // Send connected frame with deterministic thread_id
            await ConnectEndpoint.SendJsonAsync(ws,
                new ConnectedBrowserFrame { ThreadId = threadId, BufferedCount = 0 },
                ctx.RequestAborted);

            await ReceiveLoopAsync(
                ws, oid, upn, threadId, connectionId,
                replyStore, delivery, webChatRegistry, clientRegistry, opts,
                ctx.RequestAborted, logger);
        }
        finally
        {
            webChatRegistry.Unregister(connectionId);
            logger.LogInformation("WebChat disconnected: {Upn} ({Oid})", upn, oid);
        }
    }

    private static async Task ReceiveLoopAsync(
        WebSocket ws,
        string oid,
        string upn,
        string threadId,
        string connectionId,
        IReplyContextStore replyStore,
        IMessageDelivery delivery,
        IWebChatRegistry webChatRegistry,
        IClientRegistry clientRegistry,
        RelayOptions opts,
        CancellationToken requestAborted,
        ILogger logger)
    {
        var recvBuffer = ArrayPool<byte>.Shared.Rent(opts.ChunkBufferMaxBytes);
        try
        {
            while (ws.State == WebSocketState.Open && !requestAborted.IsCancellationRequested)
            {
                WebSocketReceiveResult result;
                using var ms = new MemoryStream();

                do
                {
                    try
                    {
                        result = await ws.ReceiveAsync(
                            new ArraySegment<byte>(recvBuffer), requestAborted);
                    }
                    catch (OperationCanceledException) { return; }
                    catch (WebSocketException)         { return; }

                    if (result.MessageType == WebSocketMessageType.Close)
                    {
                        await CloseGracefullyAsync(ws, logger);
                        return;
                    }
                    ms.Write(recvBuffer, 0, result.Count);
                }
                while (!result.EndOfMessage);

                await DispatchBrowserFrameAsync(
                    ms.ToArray(),
                    oid, upn, threadId, connectionId,
                    replyStore, delivery, webChatRegistry, clientRegistry,
                    opts, requestAborted, logger);
            }
        }
        finally
        {
            ArrayPool<byte>.Shared.Return(recvBuffer);
        }
    }

    private static async Task DispatchBrowserFrameAsync(
        byte[] bytes,
        string oid,
        string upn,
        string threadId,
        string connectionId,
        IReplyContextStore replyStore,
        IMessageDelivery delivery,
        IWebChatRegistry webChatRegistry,
        IClientRegistry clientRegistry,
        RelayOptions opts,
        CancellationToken ct,
        ILogger logger)
    {
        try
        {
            using var doc = JsonDocument.Parse(bytes);
            if (!doc.RootElement.TryGetProperty("type", out var typeProp)) return;
            if (typeProp.GetString() != FrameType.Message) return;

            var content = doc.RootElement.TryGetProperty("content", out var cp)
                ? cp.GetString() ?? string.Empty
                : string.Empty;

            // Assign opaque routing key for this request/response pair
            var channelId = WireFrames.NewChannelId();

            // Store reply context so the WorkPilot client's response is routed back here
            replyStore.Store(new ReplyContext
            {
                ChannelId           = channelId,
                OwnerOid            = oid,
                Source              = ReplySource.WebChat,
                CreatedAt           = DateTimeOffset.UtcNow,
                ExpiresAt           = DateTimeOffset.UtcNow + opts.ReplyContextTtl,
                WebChatConnectionId = connectionId,
            });

            // Build and deliver the message frame to the WorkPilot client
            var frame = new MessageFrame
            {
                ChannelId  = channelId,
                SenderId   = oid,
                SenderName = upn,
                Content    = content,
                ThreadId   = threadId,
                SessionKey = WireFrames.WebChatSessionKey(upn, oid),
                Timestamp  = DateTimeOffset.UtcNow.ToString("O"),
                Metadata   = new MessageMetadata { Source = "cloud_webchat" },
            };

            // If the WorkPilot client is offline, notify the browser immediately
            // and still buffer the message for delivery when the client reconnects.
            if (!clientRegistry.IsOnline(oid))
            {
                logger.LogDebug(
                    "WebChat user {Oid} offline — sending agent_offline, buffering message",
                    oid);
                var browserConn = webChatRegistry.Get(connectionId);
                if (browserConn is not null)
                {
                    await ConnectEndpoint.SendJsonAsync(
                        browserConn.Socket,
                        new ErrorFrame
                        {
                            Code    = ErrorCode.AgentOffline,
                            Message = "Your WorkPilot agent is offline. Start `workpilot cloud` on your machine to connect.",
                        },
                        ct);
                }
            }

            await delivery.DeliverAsync(oid, frame, ct);

            logger.LogDebug(
                "WebChat message delivered channel_id={ChannelId} oid={Oid}",
                channelId, oid);

            // Response timeout (Web Chat only — 120 s).
            // Notifies both the browser AND the WorkPilot client (design §10.2).
            // Pass ct so the delay is cancelled immediately when the browser disconnects,
            // preventing orphaned timer tasks accumulating under load.
            _ = Task.Run(async () =>
            {
                try { await Task.Delay(opts.ResponseTimeout, ct); }
                catch (OperationCanceledException) { return; } // browser disconnected

                if (replyStore.GetUnchecked(channelId) is null) return; // already answered

                replyStore.Delete(channelId);
                logger.LogWarning("WebChat response timeout channel_id={ChannelId}", channelId);

                var timeoutError = new ErrorFrame
                {
                    Code      = ErrorCode.ResponseTimeout,
                    ChannelId = channelId,
                    Message   = "Agent did not respond in time. Please try again.",
                };

                // 1. Notify browser
                try
                {
                    var browserConn = webChatRegistry.Get(connectionId);
                    if (browserConn is not null)
                        await ConnectEndpoint.SendJsonAsync(
                            browserConn.Socket, timeoutError, CancellationToken.None);
                }
                catch { /* browser may have disconnected */ }

                // 2. Notify WorkPilot client so it knows the reply was dropped (design §10.2)
                try
                {
                    var clientConn = clientRegistry.GetActive(oid);
                    if (clientConn is not null)
                        await clientConn.SendJsonAsync(timeoutError, CancellationToken.None);
                }
                catch { /* client may have disconnected */ }
            }, CancellationToken.None);
        }
        catch (JsonException ex)
        {
            logger.LogWarning(ex, "Malformed frame from WebChat browser — ignored");
        }
    }

    private static async Task CloseGracefullyAsync(WebSocket ws, ILogger logger)
    {
        try
        {
            if (ws.State == WebSocketState.Open)
                await ws.CloseAsync(WebSocketCloseStatus.NormalClosure,
                    "Closing", CancellationToken.None);
        }
        catch (Exception ex)
        {
            logger.LogDebug(ex, "Error during WebChat WebSocket close");
        }
    }
}
