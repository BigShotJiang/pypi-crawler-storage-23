using System.Security.Claims;
using System.Text.Encodings.Web;
using CloudGateway.Config;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Options;

namespace CloudGateway.Auth;

/// <summary>
/// Development-only authentication handler that accepts a configurable bypass token.
/// Produces a synthetic ClaimsPrincipal with fake OID and UPN for local e2e testing.
///
/// SAFETY GUARDS (both must pass):
///   1. ASP.NET Core environment must be "Development"
///   2. Auth:Bypass:Enabled must be explicitly true in config
///
/// If either guard fails the handler returns NoResult, allowing other schemes to run.
/// </summary>
public sealed class BypassAuthHandler(
    IOptionsMonitor<BypassAuthOptions> options,
    ILoggerFactory loggerFactory,
    UrlEncoder encoder,
    IWebHostEnvironment env)
    : AuthenticationHandler<BypassAuthOptions>(options, loggerFactory, encoder)
{
    private readonly ILogger<BypassAuthHandler> _log =
        loggerFactory.CreateLogger<BypassAuthHandler>();

    protected override Task<AuthenticateResult> HandleAuthenticateAsync()
    {
        // Guard 1: production hard-stop
        if (!env.IsDevelopment())
            return Task.FromResult(AuthenticateResult.NoResult());

        // Guard 2: explicit opt-in
        if (!Options.Enabled)
            return Task.FromResult(AuthenticateResult.NoResult());

        var authHeader = Request.Headers.Authorization.FirstOrDefault();
        if (authHeader is null || !authHeader.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
            return Task.FromResult(AuthenticateResult.NoResult());

        var token = authHeader["Bearer ".Length..].Trim();
        if (!string.Equals(token, Options.Token, StringComparison.Ordinal))
            return Task.FromResult(AuthenticateResult.NoResult());

        _log.LogWarning(
            "⚠ DEV BYPASS AUTH active — this must never appear in production logs. " +
            "oid={Oid} upn={Upn}",
            Options.Oid, Options.Upn);

        var claims = new[]
        {
            new Claim("oid",                  Options.Oid),
            new Claim("preferred_username",   Options.Upn),
            new Claim("upn",                  Options.Upn),
            new Claim(ClaimTypes.Name,        Options.Upn),
        };

        var identity  = new ClaimsIdentity(claims, BypassAuthOptions.Scheme);
        var principal = new ClaimsPrincipal(identity);
        var ticket    = new AuthenticationTicket(principal, BypassAuthOptions.Scheme);

        return Task.FromResult(AuthenticateResult.Success(ticket));
    }
}
