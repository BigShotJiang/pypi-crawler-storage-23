using CloudGateway.Models;
using CloudGateway.Services;

namespace CloudGateway.Endpoints;

/// <summary>
/// Development-only debug endpoints for e2e testing.
/// Only registered when ASPNETCORE_ENVIRONMENT=Development.
/// NEVER available in production.
/// </summary>
public static class DebugEndpoints
{
    public static IEndpointRouteBuilder MapDebugEndpoints(
        this IEndpointRouteBuilder app,
        IWebHostEnvironment env)
    {
        if (!env.IsDevelopment()) return app;

        // Inject a MessageFrame into the offline buffer for a given OID.
        // Used to test: offline buffer delivery, relay chain, buffered reconnect.
        app.MapPost("/debug/inject/{oid}", async (
            string oid,
            DebugInjectRequest req,
            IClientRegistry registry,
            IMessageDelivery delivery,
            ILogger<Program> logger,
            CancellationToken ct) =>
        {
            var frame = new MessageFrame
            {
                ChannelId  = WireFrames.NewChannelId(),
                SenderId   = req.SenderId   ?? "debug-sender-oid",
                SenderName = req.SenderName ?? "Debug User",
                Content    = req.Content    ?? "debug message",
                ThreadId   = req.ThreadId   ?? "debug-thread-1",
                SessionKey = WireFrames.TeamsSessionKey(
                    req.SenderId ?? "debug-sender-oid",
                    req.ThreadId ?? "debug-thread-1"),
                Timestamp  = DateTimeOffset.UtcNow.ToString("O"),
                Metadata   = new MessageMetadata
                {
                    Source   = "cloud_teams",
                    TenantId = "72f988bf-86f1-41af-91ab-2d7cd011db47",
                },
            };

            var isOnline = registry.IsOnline(oid);
            await delivery.DeliverAsync(oid, frame, ct);

            logger.LogInformation(
                "[DEBUG] Injected message for OID={Oid} online={Online} content={Content}",
                oid, isOnline, frame.Content);

            return Results.Ok(new
            {
                channel_id = frame.ChannelId,
                oid,
                online     = isOnline,
            });
        }).AllowAnonymous();

        // Return current registry state for debugging.
        app.MapGet("/debug/registry", (IClientRegistry registry) =>
        {
            // Can't enumerate OIDs from the interface; just confirm endpoint works.
            return Results.Ok(new { status = "ok", note = "registry is online" });
        }).AllowAnonymous();

        return app;
    }

    private sealed record DebugInjectRequest(
        string? Content,
        string? SenderId,
        string? SenderName,
        string? ThreadId);
}
