using System.Net.Http.Headers;
using System.Security.Claims;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using CloudGateway.Config;
using Microsoft.Extensions.Options;

namespace CloudGateway.Endpoints;

/// <summary>
/// Azure Bot Service DirectLine Web Chat integration using MSAL.js popup auth.
///
///   POST /webchat/directline/token  — validates the MSAL.js Bearer token (JwtBearer),
///                                     exchanges the DirectLine secret for a short-lived
///                                     user-bound token safe to send to the browser.
///   GET  /webchat/ui                — serves a static HTML page that uses MSAL.js popup
///                                     to authenticate the user client-side, then calls
///                                     the token endpoint with a Bearer token.
///
/// No server-side OIDC redirect or correlation cookies needed.
/// </summary>
public static class BotWebChatEndpoint
{
    private static readonly JsonSerializerOptions _json = new()
    {
        PropertyNamingPolicy   = JsonNamingPolicy.CamelCase,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
    };

    public static IEndpointRouteBuilder MapBotWebChatEndpoint(
        this IEndpointRouteBuilder app,
        bool enabled,
        string clientId,
        string tenantId)
    {
        // Return immediately when disabled — don't expose endpoints that only return 503.
        // Reduces attack surface and avoids leaking feature presence to unauthenticated callers.
        if (!enabled)
            return app;

        // Token endpoint: authenticated via MSAL.js id-token (MsalBrowser scheme).
        // id-tokens have aud = clientId GUID — separate from WorkPilotClient access tokens.
        app.MapPost("/webchat/directline/token", HandleTokenAsync)
           .RequireAuthorization("WebChatBrowserUser");

        // UI page: served anonymously; MSAL.js popup handles auth entirely client-side.
        app.MapGet("/webchat/ui",
            (HttpContext ctx, IOptions<DirectLineOptions> opts) =>
                HandleUiAsync(ctx, opts, clientId, tenantId))
           .AllowAnonymous();

        // Blank redirect page used as MSAL popup redirectUri.
        // Must be completely empty — no MSAL code — so the popup closes cleanly
        // after AAD redirects back here with the auth code.
        app.MapGet("/webchat/auth", () => Results.Content(
            "<!DOCTYPE html><html><head><title></title></head><body></body></html>",
            "text/html"))
           .AllowAnonymous();

        return app;
    }

    // ── Token endpoint ────────────────────────────────────────────────────────

    private static async Task HandleTokenAsync(
        HttpContext ctx,
        IOptions<DirectLineOptions> opts,
        IHttpClientFactory httpClientFactory,
        ILogger<Program> logger)
    {
        var options = opts.Value;

        // Token responses must never be cached — they contain bearer tokens.
        ctx.Response.Headers["Cache-Control"] = "no-store";
        ctx.Response.Headers["Pragma"]        = "no-cache";

        if (!options.Enabled || string.IsNullOrWhiteSpace(options.Secret))
        {
            ctx.Response.StatusCode  = StatusCodes.Status503ServiceUnavailable;
            ctx.Response.ContentType = "application/json";
            await ctx.Response.WriteAsync(JsonSerializer.Serialize(new
            {
                error   = "directline_unavailable",
                message = "Web Chat is not configured. Contact your administrator.",
            }));
            return;
        }

        var oid = ctx.User.FindFirstValue("oid")
               ?? ctx.User.FindFirstValue("http://schemas.microsoft.com/identity/claims/objectidentifier");
        var upn = ctx.User.FindFirstValue("preferred_username")
               ?? ctx.User.FindFirstValue("upn")
               ?? ctx.User.FindFirstValue("name")
               ?? oid;

        if (string.IsNullOrEmpty(oid))
        {
            ctx.Response.StatusCode = StatusCodes.Status401Unauthorized;
            return;
        }

        // Use the configured TrustedOrigin allowlist — never reflect the incoming
        // Host header, which an authenticated caller could spoof to obtain a token
        // trusted by an arbitrary origin.
        var tokenRequest = string.IsNullOrWhiteSpace(options.TrustedOrigin)
            ? (object)new { user = new { id = $"dl_{oid}", name = upn } }
            : (object)new { user = new { id = $"dl_{oid}", name = upn },
                            trustedOrigins = new[] { options.TrustedOrigin } };

        try
        {
            var http = httpClientFactory.CreateClient("DirectLine");
            using var req = new HttpRequestMessage(
                HttpMethod.Post,
                "v3/directline/tokens/generate");
            req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", options.Secret);
            req.Content = new StringContent(
                JsonSerializer.Serialize(tokenRequest, _json),
                Encoding.UTF8,
                "application/json");

            using var resp = await http.SendAsync(req, ctx.RequestAborted);

            if (!resp.IsSuccessStatusCode)
            {
                logger.LogWarning("DirectLine token generation failed: {StatusCode}", (int)resp.StatusCode);
                ctx.Response.StatusCode  = StatusCodes.Status503ServiceUnavailable;
                ctx.Response.ContentType = "application/json";
                await ctx.Response.WriteAsync(JsonSerializer.Serialize(new
                {
                    error   = "directline_unavailable",
                    message = "Could not obtain a DirectLine token. Please try again.",
                }));
                return;
            }

            var body = await resp.Content.ReadAsStringAsync(ctx.RequestAborted);
            using var doc = JsonDocument.Parse(body);

            var token          = doc.RootElement.GetProperty("token").GetString();
            var conversationId = doc.RootElement.GetProperty("conversationId").GetString();
            var expiresIn      = doc.RootElement.TryGetProperty("expires_in", out var exp)
                ? exp.GetInt32() : 1800;

            logger.LogDebug(
                "DirectLine token issued for oid={Oid} conversationId={ConversationId}",
                oid, conversationId);

            ctx.Response.ContentType = "application/json";
            await ctx.Response.WriteAsync(JsonSerializer.Serialize(new
            {
                token,
                conversationId,
                expiresIn,
            }));
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            logger.LogError(ex, "DirectLine token generation threw an unexpected exception");
            ctx.Response.StatusCode  = StatusCodes.Status503ServiceUnavailable;
            ctx.Response.ContentType = "application/json";
            await ctx.Response.WriteAsync(JsonSerializer.Serialize(new
            {
                error   = "directline_unavailable",
                message = "Could not obtain a DirectLine token. Please try again.",
            }));
        }
    }

    // ── UI endpoint ───────────────────────────────────────────────────────────

    private static async Task HandleUiAsync(
        HttpContext ctx,
        IOptions<DirectLineOptions> opts,
        string clientId,
        string tenantId)
    {
        // Always return HTML — the page loads regardless of Secret configuration.
        // If the token endpoint returns 503 (Secret missing), the in-page JS error
        // handler shows the message to the user. Returning JSON 503 here would break
        // the text/html contract and prevent the MSAL login UI from rendering at all.
        ctx.Response.ContentType = "text/html; charset=utf-8";
        await ctx.Response.WriteAsync(BuildUiHtml(clientId, tenantId));
    }

    private static string BuildUiHtml(string clientId, string tenantId)
    {
        // Safely encode config values as JSON strings before embedding in JS.
        // Prevents injection if values ever contain quotes, backslashes, or </script>.
        var safeClientId = JsonSerializer.Serialize(clientId);   // → "c5bdcb9d-..."
        var safeTenantId = JsonSerializer.Serialize(tenantId);
        return BuildUiHtmlCore(safeClientId, safeTenantId);
    }

    private static string BuildUiHtmlCore(string safeClientId, string safeTenantId) => $$"""
        <!DOCTYPE html>
        <html lang="en">
        <head>
          <meta charset="utf-8" />
          <meta name="viewport" content="width=device-width, initial-scale=1" />
          <title>WorkPilot Web Chat</title>
          <style>
            * { box-sizing: border-box; margin: 0; padding: 0; }
            body { display: flex; flex-direction: column; height: 100vh;
                   font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
                   background: #f3f2f1; }
            #header { padding: 12px 16px; background: #464775; color: white;
                      font-size: 16px; font-weight: 600; display: flex;
                      align-items: center; gap: 8px; }
            #webchat { flex: 1; overflow: hidden; }
            #status  { display: flex; align-items: center; justify-content: center;
                       height: 100%; color: #605e5c; font-size: 14px; gap: 8px; }
            .spinner { width: 20px; height: 20px; border: 2px solid #c8c6c4;
                       border-top-color: #464775; border-radius: 50%;
                       animation: spin 0.8s linear infinite; }
            @keyframes spin { to { transform: rotate(360deg); } }
            .error   { color: #a4262c; }
          </style>
        </head>
        <body>
          <div id="header">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
              <circle cx="10" cy="10" r="9" stroke="white" stroke-width="1.5"/>
              <path d="M6 10.5l2.5 2.5L14 7.5" stroke="white" stroke-width="1.5"
                    stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            WorkPilot
          </div>
          <div id="webchat">
            <div id="status">
              <div class="spinner" id="spinner"></div>
              <span id="status-text">Signing in…</span>
            </div>
          </div>

          <!-- MSAL.js v2.35.0 — Microsoft official CDN (UMD build) -->
          <script src="https://alcdn.msauth.net/browser/2.35.0/js/msal-browser.min.js"
                  crossorigin="anonymous"></script>
          <!-- botframework-webchat (pinned version + SRI for supply-chain safety) -->
          <script src="https://cdn.botframework.com/botframework-webchat/4.15.9/webchat.js"
                  integrity="sha384-kr+6QqBRD45fWiraMYzQdm0CpHzmKMtNk0gRLBVqa379eQdjCHNnm8jfmAhiOQnI"
                  crossorigin="anonymous"></script>

          <script>
            const CLIENT_ID      = {{safeClientId}};
            const TENANT_ID      = {{safeTenantId}};
            // Use openid + profile only — avoids the "app requesting token for itself"
            // (AADSTS90009) error that occurs when client_id == resource app_id.
            // loginPopup returns an idToken with aud=clientId that the server
            // validates via the MsalBrowser JwtBearer scheme.
            const LOGIN_SCOPES   = ['openid', 'profile'];
            // Dedicated blank page — no MSAL code — so the popup closes cleanly.
            const POPUP_REDIRECT = window.location.origin + '/webchat/auth';

            const msalConfig = {
              auth: {
                clientId:    CLIENT_ID,
                authority:   'https://login.microsoftonline.com/' + TENANT_ID,
                redirectUri: POPUP_REDIRECT,
              },
              cache: {
                cacheLocation:          'sessionStorage',
                storeAuthStateInCookie: false,
              },
            };

            (async function () {
              const statusEl  = document.getElementById('status');
              const statusTxt = document.getElementById('status-text');
              const spinner   = document.getElementById('spinner');

              try {
                const pca = new msal.PublicClientApplication(msalConfig);

                // Required in MSAL v2 on page load to process any redirect responses.
                await pca.handleRedirectPromise();

                // Try silent re-auth for returning users (uses cached session).
                let idToken;
                const accounts = pca.getAllAccounts();
                if (accounts.length > 0) {
                  try {
                    const r = await pca.acquireTokenSilent({
                      scopes:  LOGIN_SCOPES,
                      account: accounts[0],
                    });
                    idToken = r.idToken;
                  } catch (_) { /* fall through to interactive */ }
                }

                if (!idToken) {
                  // loginPopup redirects to the blank /webchat/auth page — no MSAL
                  // code there, so the popup closes cleanly without nested-popup errors.
                  statusTxt.textContent = 'Signing in…';
                  const r = await pca.loginPopup({
                    scopes:      LOGIN_SCOPES,
                    redirectUri: POPUP_REDIRECT,
                  });
                  idToken = r.idToken;  // id-token: aud=clientId, contains oid + name
                }

                // Exchange the AAD id-token for a DirectLine token.
                // Server validates id-token via the MsalBrowser JwtBearer scheme.
                statusTxt.textContent = 'Connecting…';
                const tokenRes = await fetch('/webchat/directline/token', {
                  method:  'POST',
                  headers: { 'Authorization': 'Bearer ' + idToken },
                });

                if (!tokenRes.ok) {
                  const body = await tokenRes.json().catch(() => ({}));
                  throw new Error(body.message || 'HTTP ' + tokenRes.status);
                }

                const { token } = await tokenRes.json();
                statusEl.style.display = 'none';

                window.WebChat.renderWebChat(
                  {
                    directLine: window.WebChat.createDirectLine({ token }),
                    styleOptions: {
                      botAvatarInitials:  'WP',
                      userAvatarInitials: 'Me',
                      accent:             '#464775',
                    },
                  },
                  document.getElementById('webchat'),
                );
              } catch (err) {
                spinner.style.display = 'none';
                statusTxt.textContent = err.message || 'Sign-in failed.';
                statusTxt.className   = 'error';
              }
            })();
          </script>
        </body>
        </html>
        """;
}
