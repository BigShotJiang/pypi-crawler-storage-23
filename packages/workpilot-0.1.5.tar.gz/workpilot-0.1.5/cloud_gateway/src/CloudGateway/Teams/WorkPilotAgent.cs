using System.Text.Json;
using CloudGateway.Config;
using CloudGateway.Models;
using CloudGateway.Services;
using Microsoft.Agents.Builder;
using Microsoft.Agents.Builder.App;
using Microsoft.Agents.Builder.State;
using Microsoft.Agents.Core.Models;
using Microsoft.Extensions.Options;

namespace CloudGateway.Teams;

/// <summary>
/// M365 Agents SDK agent that handles inbound Teams message activities.
/// Routes each message to the sender's connected WorkPilot client via IMessageDelivery.
/// Processing is fire-and-forget so the HTTP 202 response is returned immediately.
/// </summary>
public sealed class WorkPilotAgent : AgentApplication
{
    private readonly IMessageDelivery _delivery;
    private readonly IReplyContextStore _replyStore;
    private readonly IClientRegistry _registry;
    private readonly TeamsReplyService _teamsReply;
    private readonly RelayOptions _opts;
    private readonly ILogger<WorkPilotAgent> _logger;

    public WorkPilotAgent(
        AgentApplicationOptions options,
        IMessageDelivery delivery,
        IReplyContextStore replyStore,
        IClientRegistry registry,
        TeamsReplyService teamsReply,
        IOptions<RelayOptions> relayOpts,
        ILogger<WorkPilotAgent> logger)
        : base(options)
    {
        _delivery   = delivery;
        _replyStore = replyStore;
        _registry   = registry;
        _teamsReply = teamsReply;
        _opts       = relayOpts.Value;
        _logger     = logger;

        // Register handler for message activities only.
        OnActivity(ActivityTypes.Message, HandleMessageAsync);
    }

    private async Task HandleMessageAsync(
        ITurnContext ctx,
        ITurnState state,
        CancellationToken ct)
    {
        var activity = ctx.Activity;

        // Guard: routing requires Entra OID — guests/legacy accounts may not have it.
        var oid = activity.From?.AadObjectId;

        // DirectLine (Web Chat) activities set from.id = "dl_{oid}" but leave
        // aadObjectId null. Strip the "dl_" prefix to recover the Entra OID.
        // Validate with Guid.TryParse to reject malformed values (e.g. "dl_" alone).
        if (string.IsNullOrEmpty(oid) &&
            activity.From?.Id?.StartsWith("dl_", StringComparison.OrdinalIgnoreCase) == true)
        {
            var candidate = activity.From.Id[3..];
            if (Guid.TryParse(candidate, out _))
                oid = candidate;
        }

        if (string.IsNullOrEmpty(oid))
        {
            _logger.LogDebug(
                "Activity discarded: from.aadObjectId missing and from.id not in dl_{{oid}} format (from.id={FromId})",
                activity.From?.Id);
            return;
        }

        var channelId  = WireFrames.NewChannelId();
        var sessionKey = WireFrames.TeamsSessionKey(oid, activity.Conversation.Id);
        var tenantId   = ExtractTenantId(activity);

        // Store reply context so the client's outbound response can be routed back.
        _replyStore.Store(new ReplyContext
        {
            ChannelId      = channelId,
            OwnerOid       = oid,
            Source         = ReplySource.Teams,
            CreatedAt      = DateTimeOffset.UtcNow,
            ExpiresAt      = DateTimeOffset.UtcNow + _opts.ReplyContextTtl,
            ServiceUrl     = activity.ServiceUrl,
            ConversationId = activity.Conversation.Id,
            ActivityId     = activity.Id,
            FromId         = activity.From?.Id,
            TenantId       = tenantId,
        });

        var frame = new MessageFrame
        {
            ChannelId  = channelId,
            SenderId   = oid,
            SenderName = activity.From?.Name ?? oid,
            Content    = activity.Text ?? string.Empty,   // verbatim, includes <at> XML
            ThreadId   = activity.Conversation.Id,
            SessionKey = sessionKey,
            Timestamp  = DateTimeOffset.UtcNow.ToString("O"),
            Metadata   = new MessageMetadata
            {
                Source   = "cloud_teams",
                TenantId = tenantId,
            },
        };

        var online = _registry.IsOnline(oid);

        // If the user's WorkPilot client is not connected, send an immediate offline
        // notification so they know what to do — their message is still buffered.
        // Only for Teams activities: DirectLine/Web Chat handles offline via its own WebSocket error frame.
        if (!online)
        {
            var offlineCtx = _replyStore.GetUnchecked(channelId);
            if (offlineCtx?.Source == ReplySource.Teams)
            {
                var msg = BuildOfflineMessage(_opts.HomeUrl);
                _ = Task.Run(
                    async () =>
                    {
                        try
                        {
                            await _teamsReply.SendReplyAsync(msg, offlineCtx, CancellationToken.None);
                        }
                        catch (Exception ex)
                        {
                            _logger.LogError(
                                ex,
                                "Failed to send offline Teams notification channel_id={ChannelId} oid={Oid}",
                                channelId, oid);
                        }
                    },
                    CancellationToken.None);
            }
        }

        // Fire-and-forget: deliver to client without blocking the HTTP 202 response.
        _ = Task.Run(
            async () => await _delivery.DeliverAsync(oid, frame, CancellationToken.None),
            CancellationToken.None);

        _logger.LogInformation(
            "Teams activity queued channel_id={ChannelId} oid={Oid} online={Online}",
            channelId, oid, online);

        await Task.CompletedTask;
    }

    private static string BuildOfflineMessage(string homeUrl)
    {
        var links = "[GitHub](https://github.com/gim-home/WorkPilot)";
        if (!string.IsNullOrWhiteSpace(homeUrl))
            links = $"[Official Website]({homeUrl.TrimEnd('/')}) | " + links;

        return $"""
            ⚠️ **WorkPilot is not connected**

            Your local WorkPilot agent is currently offline. Install and run it to start chatting.

            **Quick start**

            ```
            git clone https://github.com/gim-home/WorkPilot.git
            cd WorkPilot
            pip install -e ".[all]"
            workpilot onboard
            workpilot cloud
            ```

            {links}

            *Your message has been queued and will be delivered once your agent comes online.*
            """;
    }

    private static string? ExtractTenantId(IActivity activity)
    {
        try
        {
            if (activity.ChannelData is JsonElement cd &&
                cd.TryGetProperty("tenant", out var tenant) &&
                tenant.TryGetProperty("id", out var tenantId))
                return tenantId.GetString();
        }
        catch { /* ignore */ }

        return null;
    }
}
