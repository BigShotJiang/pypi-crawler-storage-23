using System.Net.Http.Json;
using System.Text.Json.Serialization;
using Azure.Core;
using Azure.Identity;
using CloudGateway.Models;
using Microsoft.Extensions.Logging;

namespace CloudGateway.Teams;

/// <summary>
/// Sends replies to Teams conversations via the Bot Framework Connector REST API.
/// Authenticates using User-Assigned Managed Identity (no client secret).
///
/// In Development (IsDevelopment == true): skips the actual HTTP call and logs at DEBUG.
/// UAMI is only available on Azure App Service — not on a local developer machine.
/// </summary>
public sealed class TeamsReplyService
{
    private static readonly string[] _scopes = ["https://api.botframework.com/.default"];

    private readonly IHttpClientFactory _httpFactory;
    private readonly TokenCredential _credential;
    private readonly ILogger<TeamsReplyService> _logger;
    private readonly bool _devMode;

    public TeamsReplyService(
        IHttpClientFactory httpFactory,
        IConfiguration configuration,
        IWebHostEnvironment env,
        ILogger<TeamsReplyService> logger)
    {
        _httpFactory = httpFactory;
        _logger      = logger;
        _devMode     = env.IsDevelopment();

        // UAMI in production; DefaultAzureCredential falls back to developer credentials locally.
        var uamiClientId = configuration["MicrosoftAppId"];
        _credential = string.IsNullOrWhiteSpace(uamiClientId)
            ? new DefaultAzureCredential()
            : new ManagedIdentityCredential(
                ManagedIdentityId.FromUserAssignedClientId(uamiClientId));
    }

    /// <summary>
    /// Send a text reply to the originating Teams conversation.
    /// Called proactively — outside of an active ITurnContext.
    /// </summary>
    public async Task SendReplyAsync(
        string content,
        ReplyContext context,
        CancellationToken ct = default)
    {
        // In local development UAMI is unavailable (no Azure IMDS endpoint).
        // Skip the actual Bot Connector call to keep e2e tests clean.
        if (_devMode)
        {
            _logger.LogDebug(
                "[DEV] Teams reply skipped (UAMI unavailable locally) " +
                "channel_id={ChannelId} content_len={Len}",
                context.ChannelId, content.Length);
            return;
        }

        if (string.IsNullOrEmpty(context.ServiceUrl) ||
            string.IsNullOrEmpty(context.ConversationId))
        {
            _logger.LogWarning(
                "Teams reply skipped: missing ServiceUrl or ConversationId for channel_id={ChannelId}",
                context.ChannelId);
            return;
        }

        try
        {
            var tokenResult = await _credential.GetTokenAsync(
                new TokenRequestContext(_scopes), ct);

            var client = _httpFactory.CreateClient("BotConnector");
            client.DefaultRequestHeaders.Authorization =
                new System.Net.Http.Headers.AuthenticationHeaderValue(
                    "Bearer", tokenResult.Token);

            var serviceUrl = context.ServiceUrl.TrimEnd('/');
            var url        = $"{serviceUrl}/v3/conversations/{Uri.EscapeDataString(context.ConversationId)}/activities";

            if (!string.IsNullOrEmpty(context.ActivityId))
                url += $"/{Uri.EscapeDataString(context.ActivityId)}";

            var reply = new BotReplyActivity
            {
                Type      = "message",
                Text      = content,
                ReplyToId = context.ActivityId,
            };

            var response = await client.PostAsJsonAsync(url, reply, ct);

            if (!response.IsSuccessStatusCode)
            {
                var body = await response.Content.ReadAsStringAsync(ct);
                _logger.LogWarning(
                    "Teams reply failed: {Status} {Body} channel_id={ChannelId}",
                    response.StatusCode, body, context.ChannelId);
            }
            else
            {
                _logger.LogDebug(
                    "Teams reply sent channel_id={ChannelId}", context.ChannelId);
            }
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            _logger.LogError(ex,
                "Teams reply error channel_id={ChannelId}", context.ChannelId);
        }
    }

    // Minimal Bot Connector activity payload for replies
    private sealed record BotReplyActivity
    {
        [JsonPropertyName("type")]      public string Type      { get; init; } = "message";
        [JsonPropertyName("text")]      public string Text      { get; init; } = string.Empty;
        [JsonPropertyName("replyToId")] public string? ReplyToId { get; init; }
    }
}
