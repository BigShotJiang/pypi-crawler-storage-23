// Placeholders replaced at startup: {{CLIENT_ID_JSON}}, {{TENANT_ID_JSON}}
const CLIENT_ID    = {{CLIENT_ID_JSON}};
const TENANT_ID    = {{TENANT_ID_JSON}};
const REDIRECT_URI = window.location.origin + '/auth/redirect';

const pca = new msal.PublicClientApplication({
  auth:  { clientId: CLIENT_ID, authority: 'https://login.microsoftonline.com/' + TENANT_ID, redirectUri: REDIRECT_URI },
  cache: { cacheLocation: 'sessionStorage', storeAuthStateInCookie: false },
});

(async () => {
  await pca.handleRedirectPromise();

  // Silent re-auth for returning users
  let idToken;
  const accounts = pca.getAllAccounts();
  if (accounts.length > 0) {
    try {
      const r = await pca.acquireTokenSilent({ scopes: ['openid', 'profile'], account: accounts[0] });
      idToken = r.idToken;
    } catch (_) {}
  }

  if (idToken) { await exchange(idToken); return; }

  // No cached session — show the button
  document.getElementById('status').textContent = '';
  document.getElementById('btn').disabled = false;
  document.getElementById('btn').onclick = async () => {
    document.getElementById('btn').disabled = true;
    document.getElementById('status').textContent = 'Opening sign-in window...';
    try {
      const r = await pca.loginPopup({ scopes: ['openid', 'profile'], redirectUri: REDIRECT_URI });
      await exchange(r.idToken);
    } catch (e) {
      document.getElementById('status').textContent = e.message || 'Sign-in cancelled.';
      document.getElementById('btn').disabled = false;
    }
  };
})();

async function exchange(idToken) {
  document.getElementById('status').textContent = 'Completing sign-in...';
  const r = await fetch('/auth/token', { method: 'POST', headers: { 'Authorization': 'Bearer ' + idToken } });
  if (r.ok) { window.location.reload(); }
  else {
    document.getElementById('status').textContent = 'Sign-in failed (' + r.status + ').';
    document.getElementById('btn').disabled = false;
  }
}
