using System.Collections.Concurrent;
using System.Security.Claims;
using System.Text.Json;
using CloudGateway.Config;
using Microsoft.Extensions.Options;

namespace CloudGateway.Middleware;

/// <summary>
/// Per-user token-bucket rate limiter keyed on the authenticated Entra OID claim.
/// Unauthenticated requests pass through unchecked (auth middleware handles them).
/// /health and /health/ready are always bypassed.
/// </summary>
public sealed class RateLimitMiddleware
{
    private static readonly HashSet<string> _bypassPaths =
        new(StringComparer.OrdinalIgnoreCase) { "/health", "/health/ready" };

    private sealed class TokenBucket(double requestsPerMinute)
    {
        private readonly object _syncRoot      = new();
        private double _tokens                 = requestsPerMinute;
        private long   _lastRefillTicks        = Environment.TickCount64;
        private readonly double _maxTokens     = requestsPerMinute;
        private readonly double _refillPerMs   = requestsPerMinute / 60_000.0;

        public bool TryConsume()
        {
            lock (_syncRoot)
            {
                var now     = Environment.TickCount64;
                var elapsed = now - _lastRefillTicks;
                _lastRefillTicks = now;
                _tokens = Math.Min(_maxTokens, _tokens + elapsed * _refillPerMs);
                if (_tokens < 1.0) return false;
                _tokens -= 1.0;
                return true;
            }
        }
    }

    private readonly RequestDelegate _next;
    private readonly double _requestsPerMinute;
    private readonly ConcurrentDictionary<string, TokenBucket> _buckets = new();

    public RateLimitMiddleware(RequestDelegate next, IOptions<RateLimitOptions> options)
    {
        _next              = next;
        _requestsPerMinute = options.Value.HttpRequestsPerMinute;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        var path = context.Request.Path.Value ?? string.Empty;

        if (_bypassPaths.Contains(path))
        {
            await _next(context);
            return;
        }

        var oid = context.User.FindFirstValue("oid");
        if (oid is not null)
        {
            var bucket = _buckets.GetOrAdd(oid, _ => new TokenBucket(_requestsPerMinute));
            if (!bucket.TryConsume())
            {
                context.Response.StatusCode  = StatusCodes.Status429TooManyRequests;
                context.Response.Headers["Retry-After"] = "60";
                context.Response.ContentType = "application/json";
                await context.Response.WriteAsync(
                    JsonSerializer.Serialize(new { error = "Too Many Requests", retryAfterSeconds = 60 }));
                return;
            }
        }

        await _next(context);
    }

    /// <summary>Reset all buckets — intended for testing only.</summary>
    internal void ResetAll() => _buckets.Clear();
}
