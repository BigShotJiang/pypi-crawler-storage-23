// User-Assigned Managed Identity
// Used as the Bot Framework app identity (MicrosoftAppType: UserAssignedMSI).
// Assigned to the App Service so it can authenticate outbound Bot Connector calls
// without any client secret.

param name     string
param location string = resourceGroup().location
param tags     object = {}

resource uami 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' = {
  name:     name
  location: location
  tags:     tags
}

output clientId    string = uami.properties.clientId
output principalId string = uami.properties.principalId
output id          string = uami.id
output name        string = uami.name
