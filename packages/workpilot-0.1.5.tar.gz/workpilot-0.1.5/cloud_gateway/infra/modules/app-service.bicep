// App Service + App Service Plan (Windows runtime)
// Hosts the Cloud Gateway .NET 10 process on Windows.
// Windows runtime supports all SKUs including D1 (Shared).
// Uses a User-Assigned Managed Identity (UAMI) for Bot Framework authentication.
// DirectLine__Secret is the only secret — store in Key Vault and use a Key Vault reference
// for production: @Microsoft.KeyVault(VaultUri=...;SecretName=directline-secret)

@description('App Service name (must be globally unique)')
param appName string

@description('App Service Plan SKU')
@allowed(['D1', 'B1', 'B2', 'B3', 'P1v3', 'P2v3', 'P3v3'])
param sku string = 'B2'

param location    string = resourceGroup().location
param tags        object = {}

@description('Client ID of the User-Assigned Managed Identity')
param uamiClientId string

@description('Resource ID of the User-Assigned Managed Identity')
param uamiResourceId string

@description('Entra ID tenant ID (72f988bf-...)')
param tenantId string

@description('Entra App Registration client ID for JWT validation on /connect')
param entraClientId string

@description('Application Insights connection string (optional; empty = disabled)')
param appInsightsConnectionString string = ''

@description('DirectLine channel secret for /webchat/directline/token. Empty = feature disabled. Store in Key Vault for production.')
@secure()
param directLineSecret string = ''

@description('Trusted origin for DirectLine tokens (e.g. https://your-gateway.azurewebsites.net). Empty = no origin restriction.')
param directLineTrustedOrigin string = ''

var planName = '${appName}-plan'

resource appServicePlan 'Microsoft.Web/serverfarms@2023-01-01' = {
  name:     planName
  location: location
  tags:     tags
  sku:      { name: sku }
  kind:     'app'          // Windows
  properties: { reserved: false }
}

resource appService 'Microsoft.Web/sites@2023-01-01' = {
  name:     appName
  location: location
  tags:     tags
  identity: {
    type: 'SystemAssigned, UserAssigned'
    userAssignedIdentities: { '${uamiResourceId}': {} }
  }
  properties: {
    serverFarmId: appServicePlan.id
    httpsOnly:    true
    siteConfig: {
      // Windows .NET 10 runtime — no linuxFxVersion needed.
      // azd deploys via ZIP / run-from-package; the published binaries target Windows.
      netFrameworkVersion: 'v10.0'
      // alwaysOn requires Basic tier or above; D1 (Shared) does not support it.
      alwaysOn:          sku != 'D1' && sku != 'F1'
      minTlsVersion:     '1.2'
      webSocketsEnabled: true          // required for /connect and /webchat WSS relay
      healthCheckPath:   '/health/ready'
      ftpsState:         'Disabled'
      http20Enabled:     true

      appSettings: [
        { name: 'ASPNETCORE_ENVIRONMENT',         value: 'Production'         }
        { name: 'ASPNETCORE_URLS',                value: 'http://+:80'        }  // Windows default port
        // .NET 10 on Windows App Service: DOTNET_ROOT must be set so the ANCM
        // host locator finds the installed runtime (required for inprocess hosting).
        { name: 'DOTNET_ROOT',                    value: 'C:\\Program Files\\dotnet' }
        // Bot Framework UAMI authentication (no MicrosoftAppPassword)
        { name: 'MicrosoftAppType',               value: 'UserAssignedMSI'    }
        { name: 'MicrosoftAppId',                 value: uamiClientId         }
        { name: 'MicrosoftAppTenantId',           value: tenantId             }
        // Entra ID JWT validation for /connect (WorkPilot client)
        { name: 'AzureAd__Instance',              value: environment().authentication.loginEndpoint }
        { name: 'AzureAd__TenantId',              value: tenantId             }
        { name: 'AzureAd__ClientId',              value: entraClientId        }
        // Audience = GUID (no api:// prefix) — the Python CLI uses scope
        // '{clientId}/.default' which produces aud = clientId GUID. Using
        // api://{clientId} as audience would reject those tokens.
        { name: 'AzureAd__Audience',              value: entraClientId            }
        // M365 Agents SDK outbound auth via UAMI
        { name: 'Connections__ServiceConnection__Settings__AuthType',              value: 'ManagedIdentity'                        }
        { name: 'Connections__ServiceConnection__Settings__ManagedIdentityClientId', value: uamiClientId                          }
        { name: 'Connections__ServiceConnection__Settings__Scopes__0',            value: 'https://api.botframework.com/.default'  }
        { name: 'ConnectionsMap__0__ServiceUrl',  value: '*'                  }
        { name: 'ConnectionsMap__0__Connection',  value: 'ServiceConnection'  }
        // Application Insights — connection string passed from main.bicep.
        // The Serilog AI sink is conditional: if empty the sink is not added
        // (see Program.cs), so this is safe to set even if unused.
        { name: 'ApplicationInsights__ConnectionString', value: appInsightsConnectionString }
        // DirectLine Web Chat — auto-enabled when secret is non-empty.
        // For production use a Key Vault reference for DirectLine__Secret.
        { name: 'DirectLine__Enabled',        value: directLineSecret != '' ? 'true' : 'false' }
        { name: 'DirectLine__Secret',         value: directLineSecret }
        // TrustedOrigin restricts which browser origins may use generated tokens.
        // Set to the App Service hostname (e.g. https://<name>.azurewebsites.net).
        { name: 'DirectLine__TrustedOrigin',  value: directLineTrustedOrigin }
      ]
    }
  }
}

output principalId  string = appService.identity.principalId   // system-assigned MI
output defaultHostName string = appService.properties.defaultHostName
output id           string = appService.id
output name         string = appService.name
