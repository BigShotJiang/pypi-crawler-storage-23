// Azure Key Vault
// No secrets stored in v1 — all configuration values are non-secret identifiers.
// Retained as infrastructure pattern for future use.

param name              string
param location          string = resourceGroup().location
param tags              object = {}
param appServicePrincipalId string  // system-assigned MI of App Service (for future use)

var kvSecretsUserRoleId = '4633458b-17de-408a-b874-0445c86b69e6'

resource keyVault 'Microsoft.KeyVault/vaults@2023-07-01' = {
  name:     name
  location: location
  tags:     tags
  properties: {
    sku:                      { family: 'A', name: 'standard' }
    tenantId:                 subscription().tenantId
    enableRbacAuthorization:  true
    enableSoftDelete:         true
    softDeleteRetentionInDays: 7
    publicNetworkAccess:      'Enabled'
    networkAcls: {
      defaultAction: 'Allow'
      bypass:        'AzureServices'
    }
  }
}

// Grant App Service system-assigned MI read access (for future secrets)
resource roleAssignment 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name:  guid(keyVault.id, appServicePrincipalId, kvSecretsUserRoleId)
  scope: keyVault
  properties: {
    roleDefinitionId: subscriptionResourceId(
      'Microsoft.Authorization/roleDefinitions', kvSecretsUserRoleId)
    principalId:   appServicePrincipalId
    principalType: 'ServicePrincipal'
  }
}

output vaultUri string = keyVault.properties.vaultUri
output id       string = keyVault.id
output name     string = keyVault.name
