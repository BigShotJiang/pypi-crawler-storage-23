#!/usr/bin/env bash
# setup-entra.sh
# Pre-provision hook: creates a SINGLE Entra ID App Registration used by
# BOTH the Cloud Gateway server (JWT validation) and the WorkPilot CLI client
# (device code flow). This is the "combined client + resource" pattern.
#
# Single App Registration configured as:
#   - Resource: exposes API scope "connect"  (gateway server validates JWTs)
#   - Public client: redirect URI http://localhost (CLI device code flow)
#
# Microsoft corporate tenant note:
#   If the tenant requires ServiceManagementReference, set:
#     export SERVICE_MGMT_REF="<your-itsm-reference-or-team-alias>"
#   before running this script.
#
# Skip creation if app already exists:
#   export ENTRA_GATEWAY_CLIENT_ID=<id>
#   bash infra/scripts/setup-entra.sh --skip-create
#
# Exports to azd environment:
#   ENTRA_GATEWAY_CLIENT_ID  — used by Bicep as entraClientId (server JWT audience)
#   ENTRA_CLI_CLIENT_ID      — same value; WorkPilot CLI uses this for device code flow

set -euo pipefail

ENV="${AZURE_ENV_NAME:-dev}"
SKIP_CREATE="${1:-}"
SERVICE_MGMT_REF="${SERVICE_MGMT_REF:-}"

GATEWAY_APP_NAME="WorkPilot Cloud Gateway (${ENV})"
CLI_APP_NAME="WorkPilot CLI (${ENV})"
GATEWAY_API_URI="api://workpilot-gw-${ENV}"

log()  { echo "[setup-entra] $*"; }
warn() { echo "[setup-entra] WARNING: $*" >&2; }

# ── Skip-create mode: IDs already provided ───────────────────────────────────
if [[ "${SKIP_CREATE}" == "--skip-create" ]]; then
  if [[ -z "${ENTRA_GATEWAY_CLIENT_ID:-}" || -z "${ENTRA_CLI_CLIENT_ID:-}" ]]; then
    log "ERROR: --skip-create requires ENTRA_GATEWAY_CLIENT_ID and ENTRA_CLI_CLIENT_ID to be set."
    exit 1
  fi
  log "Skip-create mode: using provided IDs."
  GATEWAY_APP_ID="${ENTRA_GATEWAY_CLIENT_ID}"
  CLI_APP_ID="${ENTRA_CLI_CLIENT_ID}"
else

  # ── 1. Gateway Server App Registration ─────────────────────────────────────
  log "Checking Gateway App Registration: '${GATEWAY_APP_NAME}'"

  GATEWAY_APP_ID=$(az ad app list \
    --display-name "${GATEWAY_APP_NAME}" \
    --query "[0].appId" -o tsv 2>/dev/null || true)

  if [[ -z "${GATEWAY_APP_ID}" ]]; then
    log "Creating Gateway App Registration..."

    CREATE_ARGS=(
      --display-name "${GATEWAY_APP_NAME}"
      --sign-in-audience "AzureADMyOrg"
      --query appId -o tsv
    )
    [[ -n "${SERVICE_MGMT_REF}" ]] && CREATE_ARGS+=(--service-management-reference "${SERVICE_MGMT_REF}")

    GATEWAY_APP_ID=$(az ad app create "${CREATE_ARGS[@]}") || {
      warn "az ad app create failed."
      warn ""
      warn "If your tenant requires ServiceManagementReference, set:"
      warn "  export SERVICE_MGMT_REF='<your-itsm-ref-or-alias>'"
      warn "and re-run this script."
      warn ""
      warn "Alternatively, create the app manually in the Portal:"
      warn "  https://portal.azure.com/#view/Microsoft_AAD_RegisteredApps/CreateApplicationBlade"
      warn "  Display name: ${GATEWAY_APP_NAME}"
      warn "  Supported account types: This org only"
      warn "  Expose an API: identifier URI = ${GATEWAY_API_URI}"
      warn "  Authentication > Allow public client flows = Yes"
      warn "  Authentication > Platform: Mobile/desktop > Redirect URI: http://localhost"
      warn ""
      warn "Then run:"
      warn "  export ENTRA_GATEWAY_CLIENT_ID=<app-id>"
      warn "  bash infra/scripts/setup-entra.sh --skip-create"
      exit 1
    }
    log "Created: ${GATEWAY_APP_ID}"

    az ad app update --id "${GATEWAY_APP_ID}" \
      --identifier-uris "${GATEWAY_API_URI}" 2>/dev/null || true
  else
    log "Existing Gateway App: ${GATEWAY_APP_ID}"
  fi

  # ── Configure as combined client + resource ─────────────────────────────────
  # The same app is used for:
  #   - Server (JWT validation):  audience = api://{GATEWAY_APP_ID}
  #   - CLI client (device code): public client with http://localhost redirect
  #   - Web Chat OIDC:            web redirect URIs (set below or manually)
  GATEWAY_OBJ=$(az ad app show --id "${GATEWAY_APP_ID}" --query id -o tsv 2>/dev/null)
  if [[ -n "${GATEWAY_OBJ}" ]]; then
    log "Configuring as combined client + resource (public client)..."
    az rest --method PATCH \
      --uri "https://graph.microsoft.com/v1.0/applications/${GATEWAY_OBJ}" \
      --body '{"isFallbackPublicClient": true, "publicClient": {"redirectUris": ["http://localhost"]}}' \
      2>/dev/null || warn "Could not set publicClient config — do it manually in Portal"
    log "Public client configured: http://localhost redirect URI"

    # Web redirect URIs for OIDC server-side code flow (Web Chat browser auth).
    # Some tenants block PATCH on web.redirectUris via API — add manually if needed.
    GATEWAY_URL="${GATEWAY_URL:-https://workpilot-gw-${ENV}.azurewebsites.net}"
    az rest --method PATCH \
      --uri "https://graph.microsoft.com/v1.0/applications/${GATEWAY_OBJ}" \
      --body "{\"web\":{\"redirectUris\":[\"${GATEWAY_URL}/auth/callback\",\"http://localhost:5136/auth/callback\"]}}" \
      2>/dev/null && log "Web redirect URIs set: ${GATEWAY_URL}/auth/callback" || {
      warn "Could not set web redirect URIs via API."
      warn "Add manually in Azure Portal > App Registrations > ${GATEWAY_APP_NAME}:"
      warn "  Authentication > Web platform > Redirect URIs:"
      warn "    ${GATEWAY_URL}/auth/callback"
      warn "    http://localhost:5136/auth/callback"
    }
  fi

fi   # end skip-create block

# ── 3. Export to azd environment ──────────────────────────────────────────────
# Both GATEWAY and CLI use the same App ID (combined client + resource pattern)
log "Exporting to azd environment..."
azd env set ENTRA_GATEWAY_CLIENT_ID "${GATEWAY_APP_ID}"
azd env set ENTRA_CLI_CLIENT_ID      "${GATEWAY_APP_ID}"   # same app

log ""
log "Done. Single App Registration (combined client + resource):"
log "  App ID:                  ${GATEWAY_APP_ID}"
log "  ENTRA_GATEWAY_CLIENT_ID: ${GATEWAY_APP_ID}  (JWT validation on /connect)"
log "  ENTRA_CLI_CLIENT_ID:     ${GATEWAY_APP_ID}  (device code flow for WorkPilot CLI)"
log ""
log "Next: run 'azd provision' to deploy Azure resources."
