"""
Phase 8 e2e test: /bot/teams Teams activity -> /connect client -> Teams reply (stub).

Tests:
  1. POST /bot/teams without auth -> 401 (token validation disabled in dev)
  2. POST /bot/teams valid activity -> 202 Accepted
  3. Activity with missing aadObjectId -> 202 (discarded, no crash)
  4. Valid activity -> WorkPilot client receives message frame
  5. Client responds -> OutboundRouter logs Teams stub send

TokenValidation:Enabled=false in appsettings.Development.json
lets us POST without a real Bot Framework JWT.

Run: python tests/e2e_teams_test.py
"""
import asyncio, json, time
import httpx
import websockets

BASE       = "http://localhost:5136"
BASE_WS    = "ws://localhost:5136"
TOKEN      = "dev-bypass"
HEADERS_WS = {"Authorization": f"Bearer {TOKEN}"}
BYPASS_OID = "00000000-0000-0000-0000-000000000001"

passed = failed = 0

def ok(label):
    global passed; passed += 1
    print(f"  PASS  {label}")

def fail(label, reason=""):
    global failed; failed += 1
    print(f"  FAIL  {label}" + (f": {reason}" if reason else ""))

def make_activity(oid=BYPASS_OID, text="Hello WorkPilot", aad_object_id=True):
    activity = {
        "type": "message",
        "id":   f"act_{int(time.time())}",
        "text": text,
        "from": {
            "id":   f"29:{oid}",
            "name": "Test User",
        },
        "conversation": {
            "id":          f"19:test-conv-{int(time.time())}@thread.v2",
            "isGroup":     True,
            "conversationType": "channel",
        },
        "recipient": {
            "id":   "28:bot-id",
            "name": "WorkPilot",
        },
        "serviceUrl": "https://smba.trafficmanager.net/amer/",
        "channelId":  "msteams",
        "channelData": {
            "tenant": {"id": "72f988bf-86f1-41af-91ab-2d7cd011db47"}
        },
    }
    if aad_object_id:
        activity["from"]["aadObjectId"] = oid
    return activity


# ── 1. Auth ───────────────────────────────────────────────────────────────────

def test_teams_auth():
    print("\n[1] /bot/teams auth")

    # With TokenValidation:Enabled=false the adapter accepts unauthenticated requests.
    r = httpx.post(f"{BASE}/bot/teams",
                   json=make_activity(),
                   headers={"Content-Type": "application/json"})
    if r.status_code in (200, 202):
        ok(f"1a no-auth accepted (TokenValidation disabled in dev): {r.status_code}")
    else:
        fail("1a no-auth", f"status={r.status_code} body={r.text[:100]}")


# ── 2. Valid activity accepted ────────────────────────────────────────────────

def test_teams_accepted():
    print("\n[2] Valid activity -> 202")

    r = httpx.post(f"{BASE}/bot/teams",
                   json=make_activity(text="Fix the auth bug"),
                   headers={"Content-Type": "application/json"},
                   timeout=10)
    if r.status_code in (200, 202):
        ok(f"2a activity accepted: {r.status_code}")
    else:
        fail("2a activity accepted", f"status={r.status_code} body={r.text[:200]}")


# ── 3. Missing aadObjectId -> discarded ──────────────────────────────────────

def test_teams_missing_oid():
    print("\n[3] Missing aadObjectId -> discarded (not crashed)")

    r = httpx.post(f"{BASE}/bot/teams",
                   json=make_activity(aad_object_id=False),
                   headers={"Content-Type": "application/json"})
    if r.status_code in (200, 202):
        ok("3a missing aadObjectId accepted (discarded server-side)")
    else:
        fail("3a missing oid", f"status={r.status_code}")

    # Health still OK
    h = httpx.get(f"{BASE}/health")
    if h.status_code == 200:
        ok("3b server healthy after missing oid")
    else:
        fail("3b server health")


# ── 4. Activity delivered to connected client ─────────────────────────────────

async def test_teams_to_client():
    print("\n[4] Teams activity -> client receives message frame")

    await asyncio.sleep(0.3)  # let prior tests' buffered messages settle
    async with websockets.connect(
        f"{BASE_WS}/connect", additional_headers=HEADERS_WS
    ) as client:
        # 1. Drain connected frame
        connected = json.loads(await asyncio.wait_for(client.recv(), timeout=3))
        assert connected.get("type") == "connected", f"expected connected: {connected}"
        # 2. If there are buffered messages (from tests 1-3), drain them completely
        if connected.get("buffered_count", 0) > 0:
            while True:
                f = json.loads(await asyncio.wait_for(client.recv(), timeout=3))
                if f.get("type") == "buffered_end":
                    break

        # Post Teams activity (NOW the client queue is clean)
        r = httpx.post(f"{BASE}/bot/teams",
                       json=make_activity(text="Hello WorkPilot"),
                       headers={"Content-Type": "application/json"})
        if r.status_code not in (200, 202):
            fail("4a activity post", f"status={r.status_code}"); return
        ok(f"4a activity posted: {r.status_code}")

        # Client should receive the message
        try:
            async with asyncio.timeout(5):
                msg_raw = await client.recv()
            msg = json.loads(msg_raw)
        except asyncio.TimeoutError:
            fail("4b client recv timeout"); return

        if msg.get("type") == "message":
            ok("4b client received message frame")
            if msg.get("metadata", {}).get("source") == "cloud_teams":
                ok("4c source=cloud_teams")
            else:
                fail("4c source", str(msg.get("metadata")))
            if msg.get("content") == "Hello WorkPilot":
                ok("4d content verbatim (no mention stripping by server)")
            else:
                fail("4d content", msg.get("content"))
            if str(msg.get("session_key", "")).startswith("cloud_teams:"):
                ok(f"4e session_key={msg['session_key'][:40]}...")
            else:
                fail("4e session_key", msg.get("session_key"))
            if str(msg.get("channel_id", "")).startswith("cid_"):
                ok(f"4f channel_id format correct: {msg['channel_id'][:12]}...")
            else:
                fail("4f channel_id", msg.get("channel_id"))
        else:
            fail("4b wrong frame type", str(msg))
            return

        # 5. Client sends response -> OutboundRouter handles (Teams stub logs it)
        await client.send(json.dumps({
            "type":       "response",
            "channel_id": msg["channel_id"],
            "content":    "Bug is fixed!",
            "format":     "markdown",
        }))
        ok("5a client sent response with valid channel_id")

        # Health check to confirm no crash
        await asyncio.sleep(0.3)
        h = httpx.get(f"{BASE}/health")
        if h.status_code == 200:
            ok("5b server healthy after Teams reply routing")
        else:
            fail("5b server health")


# ── Main ──────────────────────────────────────────────────────────────────────

async def main():
    print("=" * 60)
    print("Cloud Gateway Phase 8 -- Teams Channel E2E")
    print("=" * 60)

    test_teams_auth()
    test_teams_accepted()
    test_teams_missing_oid()
    await test_teams_to_client()

    print("\n" + "=" * 60)
    print(f"Results: {passed} passed, {failed} failed")
    print("ALL TEAMS TESTS PASSED" if failed == 0 else "SOME TESTS FAILED")
    print("=" * 60)

asyncio.run(main())
