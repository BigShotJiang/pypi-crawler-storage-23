using System.Net;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc.Testing;

namespace CloudGateway.Integration;

// Sequential collection prevents Serilog global-state conflicts between test classes.
[Collection("Integration")]
public sealed class HealthEndpointTests(WebApplicationFactory<Program> factory)
    : IClassFixture<WebApplicationFactory<Program>>
{
    private readonly HttpClient _client = factory.CreateClient();

    [Fact]
    public async Task GetHealth_Returns200()
    {
        var response = await _client.GetAsync("/health");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
    }

    [Fact]
    public async Task GetHealth_ReturnsOkStatus()
    {
        var response = await _client.GetAsync("/health");
        var body     = await response.Content.ReadAsStringAsync();
        var doc      = JsonDocument.Parse(body);

        Assert.Equal("ok", doc.RootElement.GetProperty("status").GetString());
    }

    [Fact]
    public async Task GetHealthReady_Returns200()
    {
        var response = await _client.GetAsync("/health/ready");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
    }

    [Fact]
    public async Task GetHealthReady_ReturnsReadyStatus()
    {
        var response = await _client.GetAsync("/health/ready");
        var body     = await response.Content.ReadAsStringAsync();
        var doc      = JsonDocument.Parse(body);

        Assert.Equal("ready", doc.RootElement.GetProperty("status").GetString());
    }
}
