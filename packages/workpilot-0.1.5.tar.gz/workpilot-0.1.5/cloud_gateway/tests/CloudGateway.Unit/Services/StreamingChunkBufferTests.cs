using CloudGateway.Config;
using CloudGateway.Services;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;

namespace CloudGateway.Unit.Services;

public sealed class StreamingChunkBufferTests
{
    private static StreamingChunkBuffer MakeBuffer(int maxBytes = 1024)
    {
        var opts = Options.Create(new RelayOptions { ChunkBufferMaxBytes = maxBytes });
        return new StreamingChunkBuffer(opts, NullLogger<StreamingChunkBuffer>.Instance);
    }

    [Fact]
    public void Accumulate_ThenFlushOnDone_ReturnsCombinedContent()
    {
        var buffer = MakeBuffer();
        buffer.Append("cid_1", "Hello ");
        buffer.Append("cid_1", "world");
        buffer.Append("cid_1", "!");

        var result = buffer.Flush("cid_1");

        Assert.Equal("Hello world!", result);
    }

    [Fact]
    public void SizeLimitExceeded_ContentTruncated()
    {
        var buffer = MakeBuffer(maxBytes: 10);
        buffer.Append("cid_1", "12345");    // 5 bytes
        buffer.Append("cid_1", "67890XYZ"); // would exceed

        var result = buffer.Flush("cid_1");

        // Must be truncated and contain truncation note
        Assert.Contains("[Response truncated", result);
    }

    [Fact]
    public void SizeLimitExceeded_TotalBytesDoNotExceedMax()
    {
        // Verify the truncation note does NOT push the buffer over _maxBytes.
        // TruncationNote is ~47 bytes; use max=200 so note + existing content fit.
        const int max = 200;
        var buffer = MakeBuffer(maxBytes: max);
        buffer.Append("cid_1", new string('a', 100));  // 100 bytes — fits
        buffer.Append("cid_1", new string('b', 150));  // 100+150=250 — triggers truncation

        var result = buffer.Flush("cid_1");
        var resultBytes = System.Text.Encoding.UTF8.GetByteCount(result);

        Assert.Contains("[Response truncated", result);
        Assert.True(resultBytes <= max,
            $"Buffer exceeded max: {resultBytes} bytes > {max} max");
    }

    [Fact]
    public void SizeLimitExceeded_MultiByte_TruncatesOnRuneBoundary()
    {
        // "日" = 3 UTF-8 bytes; a limit that falls mid-rune must not produce garbage
        const int max = 50;
        var buffer = MakeBuffer(maxBytes: max);
        buffer.Append("cid_1", new string('日', 20)); // 60 bytes — exceeds limit

        var result = buffer.Flush("cid_1");

        // Result should be valid UTF-8 / valid string (no replacement chars)
        Assert.DoesNotContain("\uFFFD", result);
        Assert.Contains("[Response truncated", result);
    }

    [Fact]
    public void Flush_ClearsBuffer()
    {
        var buffer = MakeBuffer();
        buffer.Append("cid_1", "content");

        buffer.Flush("cid_1");

        Assert.Equal(string.Empty, buffer.Flush("cid_1"));
    }

    [Fact]
    public void MultipleChannelIds_Isolated()
    {
        var buffer = MakeBuffer();
        buffer.Append("cid_A", "from-A");
        buffer.Append("cid_B", "from-B");

        Assert.Equal("from-A", buffer.Flush("cid_A"));
        Assert.Equal("from-B", buffer.Flush("cid_B"));
    }

    [Fact]
    public void Discard_RemovesBuffer()
    {
        var buffer = MakeBuffer();
        buffer.Append("cid_1", "some data");

        buffer.Discard("cid_1");

        Assert.Equal(string.Empty, buffer.Flush("cid_1"));
    }
}
