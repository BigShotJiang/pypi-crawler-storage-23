using CloudGateway.Config;
using CloudGateway.Models;
using CloudGateway.Services;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;

namespace CloudGateway.Unit.Services;

public sealed class InMemoryReplyContextStoreTests
{
    private static InMemoryReplyContextStore MakeStore(int ttlMinutes = 60)
    {
        var opts = Options.Create(new RelayOptions { ReplyContextTtlMinutes = ttlMinutes });
        return new InMemoryReplyContextStore(opts, NullLogger<InMemoryReplyContextStore>.Instance);
    }

    private static ReplyContext TeamsCtx(string channelId, string ownerOid) => new()
    {
        ChannelId      = channelId,
        OwnerOid       = ownerOid,
        Source         = ReplySource.Teams,
        CreatedAt      = DateTimeOffset.UtcNow,
        ExpiresAt      = DateTimeOffset.UtcNow.AddHours(1),
        ServiceUrl     = "https://smba.trafficmanager.net/amer/",
        ConversationId = "19:abc@thread.v2",
        ActivityId     = "act-1",
        FromId         = "29:user-1",
        TenantId       = "72f988bf-86f1-41af-91ab-2d7cd011db47",
    };

    private static ReplyContext WebChatCtx(string channelId, string ownerOid) => new()
    {
        ChannelId            = channelId,
        OwnerOid             = ownerOid,
        Source               = ReplySource.WebChat,
        CreatedAt            = DateTimeOffset.UtcNow,
        ExpiresAt            = DateTimeOffset.UtcNow.AddHours(1),
        WebChatConnectionId  = "ws-conn-abc",
    };

    [Fact]
    public void Store_ThenGet_ReturnsContext()
    {
        var store = MakeStore();
        var ctx   = TeamsCtx("cid_test-1", "oid-1");
        store.Store(ctx);

        var result = store.Get("cid_test-1", "oid-1");

        Assert.NotNull(result);
        Assert.Equal("cid_test-1", result.ChannelId);
        Assert.Equal("oid-1",      result.OwnerOid);
    }

    [Fact]
    public void Get_UnknownChannelId_ReturnsNull()
    {
        var store = MakeStore();

        Assert.Null(store.Get("cid_nonexistent", "oid-1"));
    }

    [Fact]
    public void OwnerOidMismatch_ReturnsNull()
    {
        var store = MakeStore();
        store.Store(TeamsCtx("cid_secure", "oid-alice"));

        // oid-bob tries to retrieve oid-alice's context
        var result = store.Get("cid_secure", "oid-bob");

        Assert.Null(result);
        // Context must still exist (not deleted by mismatch)
        Assert.NotNull(store.GetUnchecked("cid_secure"));
    }

    [Fact]
    public void EvictExpired_RemovesEntries()
    {
        var opts = Options.Create(new RelayOptions
        {
            ReplyContextTtlMinutes          = 0,
            ReplyContextEvictionIntervalMinutes = 0,
        });
        var store = new InMemoryReplyContextStore(
            opts, NullLogger<InMemoryReplyContextStore>.Instance);

        var expired = new ReplyContext
        {
            ChannelId      = "cid_expired",
            OwnerOid       = "oid-1",
            Source         = ReplySource.Teams,
            CreatedAt      = DateTimeOffset.UtcNow.AddHours(-2),
            ExpiresAt      = DateTimeOffset.UtcNow.AddSeconds(-1),  // already expired
            ServiceUrl     = "https://smba.trafficmanager.net/amer/",
            ConversationId = "19:abc@thread.v2",
            ActivityId     = "act-1",
            FromId         = "29:user-1",
        };
        store.Store(expired);

        // Get should return null (expired)
        Assert.Null(store.Get("cid_expired", "oid-1"));
    }

    [Fact]
    public void Delete_AfterSend_ContextGone()
    {
        var store = MakeStore();
        store.Store(TeamsCtx("cid_del", "oid-1"));

        store.Delete("cid_del");

        Assert.Null(store.Get("cid_del", "oid-1"));
    }

    [Fact]
    public void WebChat_Context_HasConnectionId()
    {
        var store = MakeStore();
        store.Store(WebChatCtx("cid_wc", "oid-1"));

        var result = store.Get("cid_wc", "oid-1");

        Assert.NotNull(result);
        Assert.Equal(ReplySource.WebChat, result.Source);
        Assert.Equal("ws-conn-abc",       result.WebChatConnectionId);
    }

    [Fact]
    public void Teams_Context_HasServiceUrl()
    {
        var store = MakeStore();
        store.Store(TeamsCtx("cid_teams", "oid-1"));

        var result = store.Get("cid_teams", "oid-1");

        Assert.NotNull(result);
        Assert.Equal(ReplySource.Teams,                           result.Source);
        Assert.Equal("https://smba.trafficmanager.net/amer/",     result.ServiceUrl);
        Assert.Equal("19:abc@thread.v2",                          result.ConversationId);
    }
}
