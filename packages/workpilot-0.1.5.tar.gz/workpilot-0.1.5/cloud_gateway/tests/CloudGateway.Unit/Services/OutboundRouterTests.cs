using System.Net.WebSockets;
using System.Text;
using System.Text.Json;
using CloudGateway.Config;
using CloudGateway.Models;
using CloudGateway.Services;
using CloudGateway.Teams;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;

namespace CloudGateway.Unit.Services;

/// <summary>
/// Unit tests for OutboundRouter — Phase 9 relay routing.
/// </summary>
public sealed class OutboundRouterTests
{
    // ── WebSocket that captures sent bytes ────────────────────────────────────

    private sealed class CapturingSocket : WebSocket
    {
        private readonly MemoryStream _buf = new();
        public string LastJson => Encoding.UTF8.GetString(_buf.ToArray());
        public override WebSocketState State => WebSocketState.Open;
        public override Task SendAsync(ArraySegment<byte> buf, WebSocketMessageType _, bool __, CancellationToken ___) { _buf.Write(buf.Array!, buf.Offset, buf.Count); return Task.CompletedTask; }
        public override void Dispose() { }
        public override void Abort() { }
        public override WebSocketCloseStatus? CloseStatus => null;
        public override string? CloseStatusDescription => null;
        public override string? SubProtocol => null;
        public override Task CloseAsync(WebSocketCloseStatus _, string? __, CancellationToken ___) => Task.CompletedTask;
        public override Task CloseOutputAsync(WebSocketCloseStatus _, string? __, CancellationToken ___) => Task.CompletedTask;
        public override Task<WebSocketReceiveResult> ReceiveAsync(ArraySegment<byte> _, CancellationToken __) =>
            Task.FromResult(new WebSocketReceiveResult(0, WebSocketMessageType.Close, true));
    }

    // ── Fake registry ─────────────────────────────────────────────────────────

    private sealed class FakeRegistry : IWebChatRegistry
    {
        private readonly Dictionary<string, WebChatConnection> _store = new();
        public void Register(WebChatConnection c) => _store[c.ConnectionId] = c;
        public void Unregister(string id) => _store.Remove(id);
        public WebChatConnection? Get(string id) => _store.TryGetValue(id, out var c) ? c : null;
        public bool IsActive(string id) => _store.ContainsKey(id);
        public int CountByOid(string oid) => _store.Values.Count(c => c.Oid == oid);
    }

    // ── Factory helpers ────────────────────────────────────────────────────────

    private static (OutboundRouter router, StreamingChunkBuffer chunkBuffer) Make(
        FakeRegistry registry)
    {
        var opts = Options.Create(new RelayOptions { ChunkBufferMaxBytes = 102_400, ReplyContextTtlMinutes = 60 });
        var chunkBuffer = new StreamingChunkBuffer(opts, NullLogger<StreamingChunkBuffer>.Instance);

        // TeamsReplyService in Development mode skips actual HTTP calls (returns immediately).
        var env    = new FakeEnv("Development");
        var config = new ConfigurationBuilder().Build();
        var teamsReply = new TeamsReplyService(
            new FakeHttpClientFactory(),
            config,
            env,
            NullLogger<TeamsReplyService>.Instance);

        var router = new OutboundRouter(
            registry, chunkBuffer, teamsReply,
            NullLogger<OutboundRouter>.Instance);

        return (router, chunkBuffer);
    }

    private static ReplyContext WcCtx(string cid, string connId) => new()
    {
        ChannelId = cid, OwnerOid = "oid-1",
        Source = ReplySource.WebChat,
        CreatedAt = DateTimeOffset.UtcNow, ExpiresAt = DateTimeOffset.UtcNow.AddHours(1),
        WebChatConnectionId = connId,
    };

    private static ReplyContext TeamsCtx(string cid) => new()
    {
        ChannelId = cid, OwnerOid = "oid-1",
        Source = ReplySource.Teams,
        CreatedAt = DateTimeOffset.UtcNow, ExpiresAt = DateTimeOffset.UtcNow.AddHours(1),
        ServiceUrl = "https://smba.trafficmanager.net/amer/",
        ConversationId = "19:conv@thread.v2", ActivityId = "act-1", FromId = "29:u",
    };

    // ── WebChat: response routing ──────────────────────────────────────────────

    [Fact]
    public async Task RouteResponseAsync_WebChat_SendsFrameToSocket()
    {
        var ws  = new CapturingSocket();
        var reg = new FakeRegistry();
        reg.Register(new WebChatConnection { ConnectionId = "c1", Oid = "oid-1", Upn = "u@t", Socket = ws });
        var (router, _) = Make(reg);
        var cid = WireFrames.NewChannelId();
        var ctx = WcCtx(cid, "c1");

        await router.RouteResponseAsync(
            new ResponseFrame { ChannelId = cid, Content = "hello browser", Format = "markdown" },
            ctx);

        var sent = JsonDocument.Parse(ws.LastJson);
        Assert.Equal("response", sent.RootElement.GetProperty("type").GetString());
        Assert.Equal("hello browser", sent.RootElement.GetProperty("content").GetString());
    }

    [Fact]
    public async Task RouteChunkAsync_WebChat_ForwardsImmediately()
    {
        var ws  = new CapturingSocket();
        var reg = new FakeRegistry();
        reg.Register(new WebChatConnection { ConnectionId = "c2", Oid = "oid-1", Upn = "u@t", Socket = ws });
        var (router, _) = Make(reg);
        var cid = WireFrames.NewChannelId();
        var ctx = WcCtx(cid, "c2");

        await router.RouteChunkAsync(
            new ChunkFrame { ChannelId = cid, Content = "tok", ChunkTypeValue = "token", Done = false },
            ctx);

        var sent = JsonDocument.Parse(ws.LastJson);
        Assert.Equal("chunk", sent.RootElement.GetProperty("type").GetString());
        Assert.Equal("tok",   sent.RootElement.GetProperty("content").GetString());
        Assert.False(sent.RootElement.GetProperty("done").GetBoolean());
    }

    [Fact]
    public async Task RouteResponseAsync_WebChat_NoConnection_DoesNotThrow()
    {
        var (router, _) = Make(new FakeRegistry()); // no connection registered
        var ctx = WcCtx(WireFrames.NewChannelId(), "gone");
        await router.RouteResponseAsync(
            new ResponseFrame { ChannelId = ctx.ChannelId, Content = "x", Format = "markdown" },
            ctx);
        // Pass: no exception thrown
    }

    // ── Teams: chunk buffering ─────────────────────────────────────────────────

    [Fact]
    public async Task RouteChunkAsync_Teams_AccumulatesUntilDone()
    {
        var (router, buffer) = Make(new FakeRegistry());
        var cid = WireFrames.NewChannelId();
        var ctx = TeamsCtx(cid);

        await router.RouteChunkAsync(new ChunkFrame { ChannelId = cid, Content = "A", ChunkTypeValue = "token", Done = false }, ctx);
        await router.RouteChunkAsync(new ChunkFrame { ChannelId = cid, Content = "B", ChunkTypeValue = "token", Done = false }, ctx);

        // Not yet done — buffer should still have content
        // (We can't peek without flushing, but we can verify the router didn't crash)

        // done=true with empty content — TeamsReplyService runs (dev mode: skips HTTP call)
        await router.RouteChunkAsync(new ChunkFrame { ChannelId = cid, Content = "", ChunkTypeValue = "token", Done = true }, ctx);

        // Buffer flushed after send
        Assert.Equal(string.Empty, buffer.Flush(cid));
    }

    [Fact]
    public async Task RouteChunkAsync_Teams_DoneTrue_IncludesFinalFrameContent()
    {
        // Regression: the done=true frame's Content was previously discarded.
        var (router, buffer) = Make(new FakeRegistry());
        var cid = WireFrames.NewChannelId();
        var ctx = TeamsCtx(cid);

        await router.RouteChunkAsync(new ChunkFrame { ChannelId = cid, Content = "Hello ", ChunkTypeValue = "token", Done = false }, ctx);

        // done=true with non-empty content — the final frame's content must be included
        await router.RouteChunkAsync(new ChunkFrame { ChannelId = cid, Content = "world", ChunkTypeValue = "token", Done = true }, ctx);

        // Buffer should be empty (was flushed and sent as "Hello world")
        Assert.Equal(string.Empty, buffer.Flush(cid));
    }

    [Fact]
    public async Task RouteResponseAsync_Teams_FlushesBufferBeforeSend()
    {
        var (router, buffer) = Make(new FakeRegistry());
        var cid = WireFrames.NewChannelId();
        var ctx = TeamsCtx(cid);

        // Pre-load buffer with partial streaming chunks
        buffer.Append(cid, "Partial ");

        await router.RouteResponseAsync(
            new ResponseFrame { ChannelId = cid, Content = "end.", Format = "markdown" },
            ctx);

        // Buffer flushed after sending
        Assert.Equal(string.Empty, buffer.Flush(cid));
    }
}

// ── Minimal fakes (file-scoped — only visible in this file) ──────────────────

file sealed class FakeHttpClientFactory : System.Net.Http.IHttpClientFactory
{
    public System.Net.Http.HttpClient CreateClient(string _) => new();
}

file sealed class FakeEnv(string name) : IWebHostEnvironment
{
    public string EnvironmentName { get; set; } = name;
    public string ApplicationName { get; set; } = "Test";
    public string WebRootPath { get; set; } = "";
    public string ContentRootPath { get; set; } = "";
    public Microsoft.Extensions.FileProviders.IFileProvider WebRootFileProvider
    {
        get => new Microsoft.Extensions.FileProviders.PhysicalFileProvider(AppContext.BaseDirectory);
        set { }
    }
    public Microsoft.Extensions.FileProviders.IFileProvider ContentRootFileProvider
    {
        get => new Microsoft.Extensions.FileProviders.PhysicalFileProvider(AppContext.BaseDirectory);
        set { }
    }
}
