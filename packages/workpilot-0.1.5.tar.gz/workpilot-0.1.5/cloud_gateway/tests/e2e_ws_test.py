"""
Quick e2e WebSocket test for /connect with bypass token.
Usage: python tests/e2e_ws_test.py
"""
import asyncio, json, sys
import websockets

URL   = "ws://localhost:5136/connect"
TOKEN = "dev-bypass"

async def run():
    headers = {"Authorization": f"Bearer {TOKEN}"}
    print(f"Connecting to {URL} ...")

    async with websockets.connect(URL, additional_headers=headers) as ws:
        print("OK WebSocket connected")

        # 1. Should receive "connected" frame immediately
        raw = await asyncio.wait_for(ws.recv(), timeout=5)
        frame = json.loads(raw)
        print(f"OK Received: {frame}")
        assert frame["type"] == "connected", f"Expected connected, got {frame}"
        assert "buffered_count" in frame
        print(f"  buffered_count = {frame['buffered_count']}")

        # 2. Send a pong (server may or may not have sent ping yet; send unsolicited pong)
        await ws.send(json.dumps({"type": "pong"}))
        print("OK Sent: pong")

        # 3. Send a response frame with unknown channel_id (should be silently ignored)
        await ws.send(json.dumps({
            "type": "response",
            "channel_id": "cid_00000000-0000-0000-0000-000000000000",
            "content": "test response",
            "format": "markdown"
        }))
        print("OK Sent: response with unknown channel_id")

        # 4. Send a chunk frame
        await ws.send(json.dumps({
            "type": "chunk",
            "channel_id": "cid_00000000-0000-0000-0000-000000000000",
            "content": "hello",
            "chunk_type": "token",
            "done": False
        }))
        print("OK Sent: chunk frame")

        # 5. Wait briefly — if server sends ping, reply with pong
        # (Heartbeat interval is 30s, so no ping expected in 3s — this just confirms
        #  the connection stays open and the server does not unexpectedly close it.)
        try:
            ping_raw = await asyncio.wait_for(asyncio.shield(ws.recv()), timeout=3)
            ping = json.loads(ping_raw)
            if ping.get("type") == "ping":
                await ws.send(json.dumps({"type": "pong"}))
                print("OK Ping received, pong sent")
        except (asyncio.TimeoutError, Exception):
            print("  (No ping within 3s — expected, heartbeat interval is 30s)")

        print("\nALL E2E ASSERTIONS PASSED")

asyncio.run(run())
