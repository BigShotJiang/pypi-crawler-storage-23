# -*- coding: utf-8 -*-
"""
Full Protocol E2E Test Suite
Simulates real Bot Framework / WebSocket wire protocol.

Run: python tests/e2e_protocol_test.py
"""
import asyncio, json, re, time, uuid
import httpx
import websockets

BASE    = "http://localhost:5136"
BASE_WS = "ws://localhost:5136"
TOKEN   = "dev-bypass"
H_BYPASS = {"Authorization": f"Bearer {TOKEN}"}
OID      = "00000000-0000-0000-0000-000000000001"
UPN      = "dev@localhost"
TENANT   = "72f988bf-86f1-41af-91ab-2d7cd011db47"

passed = failed = 0

def ok(label):
    global passed; passed += 1
    print(f"  PASS  {label}")

def fail(label, reason=""):
    global failed; failed += 1
    print(f"  FAIL  {label}" + (f": {reason}" if reason else ""))

def ws_connect(path="/connect"):
    return websockets.connect(f"{BASE_WS}{path}", additional_headers=H_BYPASS)

async def recv(ws, timeout=4):
    async with asyncio.timeout(timeout):
        return json.loads(await ws.recv())

async def drain(ws):
    """Consume connected frame + optional buffered sequence. Return connected frame."""
    frame = await recv(ws)
    assert frame["type"] == "connected", f"expected connected, got {frame}"
    if frame.get("buffered_count", 0) > 0:
        while True:
            f = await recv(ws)
            if f["type"] == "buffered_end":
                break
    return frame

# ─────────────────────────────────────────────────────────────────────────────
# Real Bot Framework Activity builders
# ─────────────────────────────────────────────────────────────────────────────

def bf_activity(
    text="Hello WorkPilot",
    conv_type="channel",
    include_mention=True,
    oid=OID,
    conv_id=None,
    act_id=None,
):
    """Build a realistic Bot Framework Teams message activity."""
    conv_id  = conv_id  or f"19:{uuid.uuid4().hex[:8]}@thread.tacv2"
    act_id   = act_id   or f"1{int(time.time() * 1000)}"
    is_group = conv_type != "personal"

    # Teams @mention entity (verbatim XML in text, entity in entities array)
    mention_text = "<at>WorkPilot</at>"
    entities = []
    if include_mention:
        text = f"{mention_text} {text}"
        entities.append({
            "type": "mention",
            "mentioned": {"id": "28:bot-id", "name": "WorkPilot"},
            "text": mention_text,
        })

    return {
        "type": "message",
        "id":   act_id,
        "timestamp": "2026-03-02T08:00:00.000Z",
        "text": text,
        "from": {
            "id":          f"29:1{oid[:8]}",
            "name":        "Test User",
            "aadObjectId": oid,
        },
        "conversation": {
            "id":               conv_id,
            "isGroup":          is_group,
            "conversationType": conv_type,
            "tenantId":         TENANT,
        },
        "recipient": {"id": "28:bot-id", "name": "WorkPilot"},
        "entities":  entities,
        "serviceUrl": "https://smba.trafficmanager.net/amer/",
        "channelId":  "msteams",
        "channelData": {
            "tenant": {"id": TENANT},
            "channel": {"id": conv_id},
        },
    }


# ─────────────────────────────────────────────────────────────────────────────
# Field validators (spec-aligned)
# ─────────────────────────────────────────────────────────────────────────────

UUID_RE    = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")
CID_RE     = re.compile(r"^cid_[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")
ISO8601_RE = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}")

def validate_message_frame(frame, source, label_prefix=""):
    p = label_prefix
    if frame.get("type") != "message":
        fail(f"{p}type", f"expected 'message' got '{frame.get('type')}'"); return False
    ok(f"{p}type == 'message'")

    if frame.get("channel") != "cloud":
        fail(f"{p}channel", frame.get("channel"))
    else:
        ok(f"{p}channel == 'cloud'")

    cid = frame.get("channel_id", "")
    if CID_RE.match(cid):
        ok(f"{p}channel_id format: cid_{{uuid}}")
    else:
        fail(f"{p}channel_id format", cid)

    sk = frame.get("session_key", "")
    if sk.startswith(source + ":"):
        ok(f"{p}session_key prefix: {source}:")
    else:
        fail(f"{p}session_key prefix", sk)

    ts = frame.get("timestamp", "")
    if ISO8601_RE.match(ts):
        ok(f"{p}timestamp ISO 8601")
    else:
        fail(f"{p}timestamp", ts)

    src = frame.get("metadata", {}).get("source", "")
    if src == source:
        ok(f"{p}metadata.source == '{source}'")
    else:
        fail(f"{p}metadata.source", src)

    for field in ("sender_id", "sender_name", "content", "thread_id"):
        if frame.get(field) is not None:
            ok(f"{p}{field} present")
        else:
            fail(f"{p}{field} missing")
    return True


# ─────────────────────────────────────────────────────────────────────────────
# A. Teams Channel Tests
# ─────────────────────────────────────────────────────────────────────────────

async def test_teams_personal_chat():
    print("\n[A1] Teams personal chat message")
    async with ws_connect() as client:
        cf = await drain(client)

        act = bf_activity(
            text="Fix the login bug",
            conv_type="personal",
            include_mention=False,  # personal chat: no @mention needed
        )
        r = httpx.post(f"{BASE}/bot/teams", json=act, timeout=10)
        if r.status_code not in (200, 202):
            fail("A1 post", f"status={r.status_code}"); return

        frame = await recv(client, timeout=5)
        ok("A1 activity accepted and delivered to client")
        validate_message_frame(frame, "cloud_teams", "A1 ")

        # Content is verbatim (no mention to strip in personal chat)
        if frame.get("content") == "Fix the login bug":
            ok("A1 content verbatim")
        else:
            fail("A1 content", frame.get("content"))


async def test_teams_channel_with_mention():
    print("\n[A2] Teams channel message with @WorkPilot mention")
    async with ws_connect() as client:
        await drain(client)

        act = bf_activity(
            text="review PR #42",
            conv_type="channel",
            include_mention=True,
        )
        r = httpx.post(f"{BASE}/bot/teams", json=act, timeout=10)
        frame = await recv(client, timeout=5)
        validate_message_frame(frame, "cloud_teams", "A2 ")

        # @mention XML is passed verbatim — client (Python) strips it
        if "<at>WorkPilot</at>" in frame.get("content", ""):
            ok("A2 @mention XML present in content (not stripped by server)")
        else:
            fail("A2 mention not in content", frame.get("content", ""))

        if frame.get("metadata", {}).get("tenant_id") == TENANT:
            ok("A2 tenant_id in metadata")
        else:
            fail("A2 tenant_id", frame.get("metadata", {}).get("tenant_id"))


async def test_teams_full_roundtrip():
    print("\n[A3] Teams full round-trip: activity -> client -> response routing")
    async with ws_connect() as client:
        await drain(client)

        act = bf_activity(text="summarize the meeting notes")
        r   = httpx.post(f"{BASE}/bot/teams", json=act, timeout=10)
        msg = await recv(client, timeout=5)
        ok("A3 client received Teams message")

        cid = msg["channel_id"]

        # Non-streaming response
        await client.send(json.dumps({
            "type":       "response",
            "channel_id": cid,
            "content":    "Here is the summary...",
            "format":     "markdown",
        }))
        ok("A3 client sent response")

        # Streaming round-trip: 3 chunks then done
        act2 = bf_activity(text="list the action items")
        httpx.post(f"{BASE}/bot/teams", json=act2, timeout=10)
        msg2 = await recv(client, timeout=5)
        cid2 = msg2["channel_id"]

        for content, done in [("Action 1", False), ("Action 2", False), ("", True)]:
            await client.send(json.dumps({
                "type":       "chunk",
                "channel_id": cid2,
                "content":    content,
                "chunk_type": "token",
                "done":       done,
            }))
        ok("A3 streaming chunks sent (Teams: server buffers, sends on done=true)")

        await asyncio.sleep(0.3)
        h = httpx.get(f"{BASE}/health")
        ok(f"A3 server healthy: {h.status_code}")


async def test_teams_missing_aad_oid():
    print("\n[A4] Teams activity without aadObjectId -> discarded")
    act = bf_activity()
    del act["from"]["aadObjectId"]

    r = httpx.post(f"{BASE}/bot/teams", json=act, timeout=10)
    if r.status_code in (200, 202):
        ok("A4 activity accepted")
    else:
        fail("A4 post", str(r.status_code))

    # No delivery should occur (nothing to assert on, just confirm no crash)
    h = httpx.get(f"{BASE}/health")
    ok(f"A4 server healthy after discard: {h.status_code}")


# ─────────────────────────────────────────────────────────────────────────────
# B. Web Chat Channel Tests
# ─────────────────────────────────────────────────────────────────────────────

async def test_webchat_protocol_fields():
    print("\n[B1] WebChat wire frame field validation")
    async with ws_connect() as wc_client, ws_connect("/webchat") as browser:
        await drain(wc_client)
        browser_connected = await recv(browser)

        # Validate connected frame
        if browser_connected.get("type") == "connected":
            ok("B1 browser connected frame type")
        else:
            fail("B1 connected type", str(browser_connected)); return

        tid = browser_connected.get("thread_id", "")
        # thread_id must be wc_{full-uuid}  (wc_ + 36-char OID with dashes)
        if tid.startswith("wc_") and len(tid) == 39 and UUID_RE.match(tid[3:]):
            ok(f"B1 thread_id format wc_{{full-oid}}: {tid}")
        else:
            fail("B1 thread_id format", tid)

        # Browser sends message
        await browser.send(json.dumps({"type": "message", "content": "Hello agent"}))
        msg = await recv(wc_client, timeout=5)
        validate_message_frame(msg, "cloud_webchat", "B1 ")

        # session_key: cloud_webchat:{upn}:wc_{oid}
        sk = msg.get("session_key", "")
        if sk.startswith(f"cloud_webchat:{UPN}:wc_") and len(sk.split(":")[-1]) == 39:
            ok(f"B1 session_key: {sk[:50]}...")
        else:
            fail("B1 session_key", sk)

        # sender_id is OID (for WebChat)
        if msg.get("sender_id") == OID:
            ok("B1 sender_id == OID")
        else:
            fail("B1 sender_id", msg.get("sender_id"))


async def test_webchat_streaming_protocol():
    print("\n[B2] WebChat streaming chunk protocol")
    async with ws_connect() as wc_client, ws_connect("/webchat") as browser:
        await drain(wc_client)
        await recv(browser)  # connected

        await browser.send(json.dumps({"type": "message", "content": "stream test"}))
        msg = await recv(wc_client, timeout=5)
        cid = msg["channel_id"]

        # Send 3 chunks with correct protocol
        chunks_data = [
            ("The ", "token",        False),
            ("answer", "token",      False),
            ("",       "token",      True),
        ]
        for content, chunk_type, done in chunks_data:
            await wc_client.send(json.dumps({
                "type":       "chunk",
                "channel_id": cid,
                "content":    content,
                "chunk_type": chunk_type,
                "done":       done,
            }))

        # Browser receives all 3 chunks
        received = []
        for _ in range(3):
            received.append(await recv(browser, timeout=5))

        # Validate chunk frames
        types    = [c["type"]       for c in received]
        contents = [c["content"]    for c in received]
        dones    = [c["done"]       for c in received]
        ctypes   = [c["chunk_type"] for c in received]

        if all(t == "chunk" for t in types):
            ok("B2 all frames are chunk type")
        else:
            fail("B2 chunk types", str(types))

        if contents == ["The ", "answer", ""]:
            ok("B2 chunk content order preserved")
        else:
            fail("B2 content order", str(contents))

        if dones == [False, False, True]:
            ok("B2 done flags correct: [False, False, True]")
        else:
            fail("B2 done flags", str(dones))

        if all(ct == "token" for ct in ctypes):
            ok("B2 chunk_type == 'token' on all chunks")
        else:
            fail("B2 chunk_type", str(ctypes))


async def test_webchat_response_routing():
    print("\n[B3] WebChat response routing: client -> browser")
    async with ws_connect() as wc_client, ws_connect("/webchat") as browser:
        await drain(wc_client)
        await recv(browser)  # connected

        await browser.send(json.dumps({"type": "message", "content": "what time is it?"}))
        msg = await recv(wc_client, timeout=5)
        cid = msg["channel_id"]

        await wc_client.send(json.dumps({
            "type":       "response",
            "channel_id": cid,
            "content":    "It is 2026-03-02 16:00 UTC.",
            "format":     "markdown",
        }))

        resp = await recv(browser, timeout=5)
        if resp.get("type") == "response":
            ok("B3 browser received response frame")
        else:
            fail("B3 response type", str(resp)); return

        if resp.get("content") == "It is 2026-03-02 16:00 UTC.":
            ok("B3 response content correct")
        else:
            fail("B3 content", resp.get("content"))


async def test_webchat_same_session_two_tabs():
    print("\n[B4] WebChat two browser tabs -> same session")
    async with ws_connect("/webchat") as b1, ws_connect("/webchat") as b2:
        c1 = await recv(b1)
        c2 = await recv(b2)

        t1 = c1.get("thread_id", "")
        t2 = c2.get("thread_id", "")

        if t1 == t2 and t1.startswith("wc_"):
            ok(f"B4 both tabs share thread_id: {t1[:20]}...")
        else:
            fail("B4 thread_id match", f"{t1} vs {t2}")


# ─────────────────────────────────────────────────────────────────────────────
# C. Cross-channel isolation
# ─────────────────────────────────────────────────────────────────────────────

async def test_channel_id_ownership():
    print("\n[C1] channel_id ownership: wrong owner cannot use it")
    # Post a Teams activity to get a channel_id
    async with ws_connect() as victim_client:
        await drain(victim_client)

        act = bf_activity(text="secret task")
        httpx.post(f"{BASE}/bot/teams", json=act, timeout=10)
        msg = await recv(victim_client, timeout=5)
        stolen_cid = msg["channel_id"]
        ok(f"C1 victim received message, channel_id={stolen_cid[:12]}...")

    # victim_client is now disconnected
    # Connect a different client (same OID due to dev bypass — can't test cross-OID
    # without two different OIDs, but we verify that a closed client's response
    # with an expired context is handled gracefully)
    await asyncio.sleep(0.3)
    async with ws_connect() as attacker_client:
        await drain(attacker_client)

        # Try to send response with the stolen/expired channel_id
        await attacker_client.send(json.dumps({
            "type":       "response",
            "channel_id": stolen_cid,
            "content":    "injected reply",
            "format":     "markdown",
        }))
        ok("C1 sent response with stolen channel_id (no crash)")

        h = httpx.get(f"{BASE}/health")
        ok(f"C1 server healthy: {h.status_code}")


async def test_webchat_routing_isolation():
    print("\n[C2] WebChat routing: response goes to correct browser only")
    async with ws_connect() as wc_client, ws_connect("/webchat") as b1, ws_connect("/webchat") as b2:
        await drain(wc_client)
        await recv(b1)
        await recv(b2)

        # b1 sends a message
        await b1.send(json.dumps({"type": "message", "content": "from b1"}))
        msg = await recv(wc_client, timeout=5)
        cid = msg["channel_id"]

        # Client responds
        await wc_client.send(json.dumps({
            "type":       "response",
            "channel_id": cid,
            "content":    "reply to b1",
            "format":     "markdown",
        }))

        # Only b1 should receive the response
        resp = await recv(b1, timeout=5)
        if resp.get("content") == "reply to b1":
            ok("C2 b1 received its response")
        else:
            fail("C2 b1 response", str(resp))

        # b2 must NOT receive anything
        try:
            unexpected = await recv(b2, timeout=1)
            fail("C2 b2 received unexpected frame", str(unexpected))
        except asyncio.TimeoutError:
            ok("C2 b2 did not receive unrelated response")


# ─────────────────────────────────────────────────────────────────────────────
# D. Wire protocol edge cases
# ─────────────────────────────────────────────────────────────────────────────

async def test_tool_progress_chunks():
    print("\n[D1] tool_progress chunks relayed to browser")
    async with ws_connect() as wc_client, ws_connect("/webchat") as browser:
        await drain(wc_client)
        await recv(browser)

        await browser.send(json.dumps({"type": "message", "content": "run tests"}))
        msg = await recv(wc_client, timeout=5)
        cid = msg["channel_id"]

        for chunk_type in ("tool_progress", "status"):
            await wc_client.send(json.dumps({
                "type":       "chunk",
                "channel_id": cid,
                "content":    f"Running {chunk_type}...",
                "chunk_type": chunk_type,
                "done":       False,
            }))

        # Final done chunk
        await wc_client.send(json.dumps({
            "type":       "chunk",
            "channel_id": cid,
            "content":    "",
            "chunk_type": "token",
            "done":       True,
        }))

        frames = []
        for _ in range(3):
            frames.append(await recv(browser, timeout=5))

        actual_types = [f.get("chunk_type") for f in frames]
        if actual_types == ["tool_progress", "status", "token"]:
            ok("D1 tool_progress and status chunks relayed correctly")
        else:
            fail("D1 chunk_type sequence", str(actual_types))


async def test_malformed_frames_resilience():
    print("\n[D2] Malformed frames: server resilience")
    async with ws_connect() as client:
        await drain(client)

        # D2a. Binary data (not text)
        # (websockets library sends text by default, skip binary for now)

        # D2b. Empty string
        await client.send("")
        ok("D2a empty string sent")

        # D2c. Valid JSON but unknown type
        await client.send(json.dumps({"type": "unknown_frame_type_xyz", "data": 123}))
        ok("D2b unknown frame type sent")

        # D2c. Chunk with chunk_type missing
        await client.send(json.dumps({
            "type":       "chunk",
            "channel_id": f"cid_{uuid.uuid4()}",
            "content":    "test",
            "done":       False,
            # chunk_type intentionally missing -> should be caught
        }))
        ok("D2c chunk missing chunk_type sent")

        # Confirm server still alive
        await asyncio.sleep(0.2)
        r = httpx.get(f"{BASE}/health")
        if r.status_code == 200:
            ok("D2d server healthy after malformed frames")
        else:
            fail("D2d server health", str(r.status_code))


# ─────────────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────────────



# ─────────────────────────────────────────────────────────────────────────────
# E. Offline / error frame tests
# ─────────────────────────────────────────────────────────────────────────────

async def test_agent_offline_frame():
    print('[E1] WebChat agent_offline frame when client is disconnected')
    # Ensure no /connect client is running for this OID
    await asyncio.sleep(0.3)
    async with ws_connect('/webchat') as browser:
        await recv(browser)  # connected frame

        # Send a message with no client online
        await browser.send(json.dumps({'type': 'message', 'content': 'hello?'}))

        # Should receive agent_offline error immediately
        try:
            frame = await recv(browser, timeout=4)
            if frame.get('type') == 'error' and frame.get('code') == 'agent_offline':
                ok('E1a browser received agent_offline error frame immediately')
                ok(f'E1b error message: {frame.get("message", "")[:60]}...')
            else:
                fail('E1a expected agent_offline', str(frame))
        except asyncio.TimeoutError:
            fail('E1a no response within 4s')

        # Server must still be healthy
        r = httpx.get(f'{BASE}/health')
        if r.status_code == 200:
            ok('E1c server healthy after agent_offline')


async def test_heartbeat_pong():
    print('[E2] Heartbeat: server sends ping, client replies pong')
    # Heartbeat interval is 30s in normal config — test that pong is accepted
    async with ws_connect() as client:
        await drain(client)

        # Send an unsolicited pong — server should handle gracefully
        await client.send(json.dumps({'type': 'pong'}))
        ok('E2a unsolicited pong accepted (no crash)')

        # Send another message to confirm connection is still alive
        r = httpx.post(f'{BASE}/debug/inject/{OID}',
                        json={'content': 'after-pong-check'})
        frame = await recv(client, timeout=5)
        if frame.get('type') == 'message' and frame.get('content') == 'after-pong-check':
            ok('E2b connection alive after pong exchange')
        else:
            fail('E2b connection dead after pong', str(frame))


async def test_webchat_agent_offline_then_reconnect():
    print('[E3] WebChat offline buffer: browser sends while offline, client reconnects and receives')
    await asyncio.sleep(0.3)

    # 1. Browser sends while no client is connected
    async with ws_connect('/webchat') as browser:
        await recv(browser)  # connected

        await browser.send(json.dumps({'type': 'message', 'content': 'deferred-hello'}))
        # Should immediately receive agent_offline
        try:
            frame = await recv(browser, timeout=4)
            if frame.get('code') == 'agent_offline':
                ok('E3a agent_offline received while offline')
            else:
                fail('E3a expected agent_offline', str(frame))
        except asyncio.TimeoutError:
            fail('E3a no agent_offline within 4s')

    # 2. Client reconnects — should receive the buffered message
    await asyncio.sleep(0.3)
    async with ws_connect() as client:
        connected = await recv(client)
        if connected.get('buffered_count', 0) >= 1:
            ok(f'E3b client reconnected with buffered_count={connected["buffered_count"]}')
            start = await recv(client)
            if start.get('type') == 'buffered_start':
                ok('E3c buffered_start received')
            msg = await recv(client)
            if msg.get('content') == 'deferred-hello':
                ok('E3d buffered message content correct')
            else:
                fail('E3d buffered content', msg.get('content'))
            end = await recv(client)
            if end.get('type') == 'buffered_end':
                ok('E3e buffered_end received')
        else:
            fail('E3b no buffered messages on reconnect', str(connected))

async def main():
    print("=" * 65)
    print("Cloud Gateway -- Full Protocol E2E Test Suite")
    print("=" * 65)

    # A. Teams Channel
    await asyncio.sleep(0.3)  # fresh start
    await test_teams_personal_chat()
    await test_teams_channel_with_mention()
    await test_teams_full_roundtrip()
    await test_teams_missing_aad_oid()

    # B. WebChat Channel
    await asyncio.sleep(0.3)
    await test_webchat_protocol_fields()
    await test_webchat_streaming_protocol()
    await test_webchat_response_routing()
    await test_webchat_same_session_two_tabs()

    # C. Cross-channel isolation
    await asyncio.sleep(0.3)
    await test_channel_id_ownership()
    await test_webchat_routing_isolation()

    # D. Wire protocol edge cases
    await asyncio.sleep(0.3)
    await test_tool_progress_chunks()
    await test_malformed_frames_resilience()

    # E. Offline / error frame tests
    await asyncio.sleep(0.3)
    await test_agent_offline_frame()
    await test_heartbeat_pong()
    await test_webchat_agent_offline_then_reconnect()

    print("\n" + "=" * 65)
    print(f"Results: {passed} passed, {failed} failed")
    print("ALL PROTOCOL TESTS PASSED" if failed == 0 else "SOME TESTS FAILED")
    print("=" * 65)
    import sys; sys.exit(0 if failed == 0 else 1)

asyncio.run(main())
