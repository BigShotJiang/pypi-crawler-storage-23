"""
HTTP / web-search / web-fetch tools — API calls, search, and content extraction.
"""

from __future__ import annotations

import asyncio
import html as html_mod
import ipaddress
import json
import re
import socket
import time
from typing import Any
from urllib.parse import urljoin, urlparse

import httpx
from loguru import logger

from workpilot.agent.tools.base import Tool, ToolMetadata
from workpilot.security.leak import detect_credentials
from workpilot.security.sanitizer import Sanitizer
from workpilot.security.ssrf import check_url_safety

# ── SSRF protection (mirrors browser.py — kept separate to avoid import coupling) ──

_BLOCKED_NETWORKS = [
    ipaddress.ip_network("127.0.0.0/8"),
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("169.254.0.0/16"),  # link-local / cloud metadata
    ipaddress.ip_network("100.64.0.0/10"),  # carrier-grade NAT
    ipaddress.ip_network("0.0.0.0/8"),
    ipaddress.ip_network("::1/128"),
    ipaddress.ip_network("fc00::/7"),
    ipaddress.ip_network("fe80::/10"),
]

_BLOCKED_HOSTNAMES = {"localhost", "metadata.google.internal"}
_BLOCKED_HOSTNAME_SUFFIXES = (".localhost", ".local", ".internal")


async def _validate_url(url: str) -> None:
    """Validate URL against SSRF rules. Raises ValueError if blocked."""
    parsed = urlparse(url)

    if parsed.scheme not in ("http", "https"):
        raise ValueError(f"URL scheme '{parsed.scheme}' not allowed (http/https only)")

    if parsed.username or parsed.password:
        raise ValueError("URLs with user:password@ are not allowed")

    hostname = parsed.hostname
    if not hostname:
        raise ValueError("URL must include a hostname")
    hostname_lower = hostname.lower()

    # Blocked hostnames
    if hostname_lower in _BLOCKED_HOSTNAMES:
        raise ValueError(f"Access to '{hostname}' blocked (SSRF protection)")
    if any(hostname_lower.endswith(s) for s in _BLOCKED_HOSTNAME_SUFFIXES):
        raise ValueError(f"Access to '{hostname}' blocked (SSRF protection)")

    # Literal IP check
    try:
        addr = ipaddress.ip_address(hostname)
        for network in _BLOCKED_NETWORKS:
            if addr in network:
                raise ValueError(f"Access to private/reserved IP {addr} blocked (SSRF protection)")
        # IPv4-mapped IPv6 bypass protection (e.g. ::ffff:127.0.0.1)
        if hasattr(addr, "ipv4_mapped") and addr.ipv4_mapped:
            mapped = addr.ipv4_mapped
            for network in _BLOCKED_NETWORKS:
                if mapped in network:
                    raise ValueError(
                        f"Access to IPv4-mapped address {addr} ({mapped}) blocked (SSRF protection)"
                    )
    except ValueError as e:
        if "SSRF" in str(e):
            raise
        # Not a literal IP — hostname, which is fine

    # DNS rebinding check
    try:
        loop = asyncio.get_running_loop()
        results = await loop.getaddrinfo(hostname, None)
        for _family, _type, _proto, _canonname, sockaddr in results:
            ip_str = sockaddr[0]
            addr = ipaddress.ip_address(ip_str)
            for network in _BLOCKED_NETWORKS:
                if addr in network:
                    raise ValueError(
                        f"Hostname '{hostname}' resolves to private IP {addr} "
                        f"(SSRF — DNS rebinding blocked)"
                    )
    except socket.gaierror:
        pass  # DNS failure will be caught by httpx


# ── HttpRequestTool ──────────────────────────────────────────────────────────


class HttpRequestTool(Tool):
    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(risk_level="medium", approval="auto", timeout=60)

    @property
    def name(self) -> str:
        return "http_request"

    @property
    def description(self) -> str:
        return "Make an HTTP request. Supports GET, POST, PUT, PATCH, DELETE."

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "The URL"},
                "method": {
                    "type": "string",
                    "enum": ["GET", "POST", "PUT", "PATCH", "DELETE"],
                    "description": "HTTP method (default: GET)",
                },
                "headers": {
                    "type": "object",
                    "description": "Request headers",
                    "additionalProperties": {"type": "string"},
                },
                "body": {"type": "string", "description": "Request body (JSON)"},
            },
            "required": ["url"],
        }

    async def execute(self, **kwargs: Any) -> str:
        url: str = kwargs["url"]
        method: str = kwargs.get("method", "GET")
        headers: dict[str, str] = kwargs.get("headers", {})
        body: str | None = kwargs.get("body")

        # Basic URL validation
        if not url.startswith(("http://", "https://")):
            return "Error: URL must start with http:// or https://"

        # SSRF protection
        ssrf_error = await check_url_safety(url)
        if ssrf_error:
            return f"BLOCKED: {ssrf_error}"

        # Outbound leak detection — block requests containing credentials
        scan_text = f"{url} {str(headers)} {body or ''}"
        findings = detect_credentials(scan_text)
        if findings:
            # Security-first: block on any credential pattern. False positives are safer than exfiltration.
            types = ", ".join(sorted({t for t, _ in findings}))
            return (
                f"Blocked: request contains potential credentials ({types}). "
                "Remove sensitive data and retry."
            )

        try:
            async with httpx.AsyncClient(timeout=30.0, follow_redirects=False) as client:
                resp = await client.request(
                    method=method,
                    url=url,
                    headers=headers,
                    content=body,
                )

            content_type = resp.headers.get("content-type", "")
            if "json" in content_type:
                body_text = json.dumps(resp.json(), indent=2)
            else:
                body_text = resp.text

            body_text = Sanitizer.truncate(body_text, 50_000)
            return f"HTTP {resp.status_code}\n\n{body_text}"

        except httpx.TimeoutException:
            return "HTTP request timed out"
        except Exception as exc:
            return f"HTTP error: {exc}"


# ── WebSearchTool ────────────────────────────────────────────────────────────

# Regex patterns for DuckDuckGo HTML result parsing (fallback when bs4 unavailable)
_DDG_RESULT_LINK = re.compile(
    r'<a\s+[^>]*class="result__a"[^>]*href="([^"]*)"[^>]*>(.*?)</a>',
    re.DOTALL,
)
_DDG_RESULT_SNIPPET = re.compile(
    r'<a\s+[^>]*class="result__snippet"[^>]*>(.*?)</a>',
    re.DOTALL,
)
_HTML_TAG = re.compile(r"<[^>]+>")


def _strip_html(text: str) -> str:
    """Remove HTML tags and decode entities."""
    return html_mod.unescape(_HTML_TAG.sub("", text)).strip()


class WebSearchTool(Tool):
    """Search the web using DuckDuckGo HTML search (no API key required)."""

    _last_request_time: float = 0.0
    _rate_lock: asyncio.Lock = asyncio.Lock()

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(risk_level="medium", approval="auto", timeout=30)

    @property
    def name(self) -> str:
        return "web_search"

    @property
    def description(self) -> str:
        return (
            "Search the web for information. Returns titles, URLs, and snippets. "
            "Uses DuckDuckGo (no API key required)."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "The search query"},
                "count": {
                    "type": "integer",
                    "description": "Number of results to return (default 5, max 10)",
                },
            },
            "required": ["query"],
        }

    async def execute(self, **kwargs: Any) -> str:
        query: str = kwargs["query"]
        count: int = max(1, min(kwargs.get("count", 5), 10))

        if not query.strip():
            return "Error: search query must not be empty"

        # Rate limit: at most 1 request per second
        async with WebSearchTool._rate_lock:
            now = time.monotonic()
            elapsed = now - WebSearchTool._last_request_time
            if elapsed < 1.0:
                await asyncio.sleep(1.0 - elapsed)
            WebSearchTool._last_request_time = time.monotonic()

        try:
            async with httpx.AsyncClient(timeout=20.0, follow_redirects=True) as client:
                resp = await client.get(
                    "https://html.duckduckgo.com/html/",
                    params={"q": query},
                    headers={"User-Agent": "WorkPilot/0.1 (web_search tool)"},
                )
                resp.raise_for_status()

            results = self._parse_results(resp.text, count)

            if not results:
                return f'No results found for "{query}".'

            lines: list[str] = [f'Search results for "{query}":\n']
            for i, (title, url, snippet) in enumerate(results, 1):
                lines.append(f"[{i}] {title}")
                lines.append(f"    {url}")
                if snippet:
                    lines.append(f"    {snippet}")
                lines.append("")

            return "\n".join(lines).rstrip()

        except httpx.TimeoutException:
            return "Web search timed out"
        except Exception as exc:
            logger.warning(f"web_search failed: {exc}")
            return f"Web search error: {exc}"

    def _parse_results(self, html: str, count: int) -> list[tuple[str, str, str]]:
        """Parse DuckDuckGo HTML results. Prefers BeautifulSoup, falls back to regex."""
        try:
            import bs4  # noqa: F401

            return self._parse_with_bs4(html, count)
        except ImportError:
            return self._parse_with_regex(html, count)

    def _parse_with_bs4(self, html: str, count: int) -> list[tuple[str, str, str]]:
        """Parse results using BeautifulSoup."""
        from bs4 import BeautifulSoup

        soup = BeautifulSoup(html, "html.parser")
        results: list[tuple[str, str, str]] = []

        for result_div in soup.select(".result"):
            if len(results) >= count:
                break

            link_el = result_div.select_one("a.result__a")
            snippet_el = result_div.select_one("a.result__snippet")

            if not link_el:
                continue

            title = link_el.get_text(strip=True)
            url = link_el.get("href", "")
            snippet = snippet_el.get_text(strip=True) if snippet_el else ""

            if title and url:
                results.append((title, str(url), snippet))

        return results

    def _parse_with_regex(self, html: str, count: int) -> list[tuple[str, str, str]]:
        """Parse results using regex fallback."""
        links = _DDG_RESULT_LINK.findall(html)
        snippets = _DDG_RESULT_SNIPPET.findall(html)

        results: list[tuple[str, str, str]] = []
        for i, (url, raw_title) in enumerate(links):
            if len(results) >= count:
                break
            title = _strip_html(raw_title)
            snippet = _strip_html(snippets[i]) if i < len(snippets) else ""
            if title and url:
                results.append((title, url, snippet))

        return results


# ── WebFetchTool ─────────────────────────────────────────────────────────────

_UNTRUSTED_OPEN = "[UNTRUSTED_CONTENT]"
_UNTRUSTED_CLOSE = "[/UNTRUSTED_CONTENT]"


class _FetchCache:
    """Simple TTL cache for web_fetch results (15-min TTL, 100 entries max)."""

    def __init__(self, ttl: float = 900.0, max_entries: int = 100) -> None:
        self._ttl = ttl
        self._max_entries = max_entries
        self._cache: dict[str, tuple[float, str]] = {}
        self._lock = asyncio.Lock()

    async def get(self, key: str) -> str | None:
        async with self._lock:
            entry = self._cache.get(key)
            if entry is None:
                return None
            ts, value = entry
            if time.monotonic() - ts > self._ttl:
                del self._cache[key]
                return None
            return value

    async def put(self, key: str, value: str) -> None:
        async with self._lock:
            # Evict expired entries first
            now = time.monotonic()
            expired = [k for k, (ts, _) in self._cache.items() if now - ts > self._ttl]
            for k in expired:
                del self._cache[k]

            # Evict oldest if at capacity
            if len(self._cache) >= self._max_entries:
                oldest_key = min(self._cache, key=lambda k: self._cache[k][0])
                del self._cache[oldest_key]

            self._cache[key] = (now, value)

    async def clear(self) -> None:
        async with self._lock:
            self._cache.clear()


class WebFetchTool(Tool):
    """Fetch a URL and extract readable content (HTML -> markdown or plain text)."""

    def __init__(self) -> None:
        self._cache = _FetchCache()

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(risk_level="medium", approval="auto", timeout=60)

    @property
    def name(self) -> str:
        return "web_fetch"

    @property
    def description(self) -> str:
        return (
            "Fetch a web page and extract its content as readable text. "
            "Supports CSS selectors to extract specific sections. "
            "Returns content wrapped in [UNTRUSTED_CONTENT] markers."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "The URL to fetch"},
                "selector": {
                    "type": "string",
                    "description": "Optional CSS selector to extract specific content (requires beautifulsoup4)",
                },
                "max_chars": {
                    "type": "integer",
                    "description": "Maximum characters to return (default 20000)",
                },
            },
            "required": ["url"],
        }

    async def execute(self, **kwargs: Any) -> str:
        url: str = kwargs["url"]
        selector: str | None = kwargs.get("selector")
        max_chars: int = max(100, min(kwargs.get("max_chars", 20_000), 100_000))

        # Basic URL validation
        if not url.startswith(("http://", "https://")):
            return "Error: URL must start with http:// or https://"

        # SSRF protection
        try:
            await _validate_url(url)
        except ValueError as e:
            return f"Error: {e}"

        # Cache keys
        raw_cache_key = url + "::raw"
        extracted_cache_key = url

        # Try cache first
        cached_extracted = await self._cache.get(extracted_cache_key)
        cached_raw = await self._cache.get(raw_cache_key)

        if cached_extracted is not None:
            logger.debug(f"web_fetch cache hit: {url}")
            content = cached_extracted
            raw_html = cached_raw  # may be None for non-HTML
        else:
            try:
                _MAX_RESPONSE_BYTES = 10 * 1024 * 1024  # 10 MB
                _MAX_REDIRECTS = 5
                current_url = url

                async with httpx.AsyncClient(timeout=30.0, follow_redirects=False) as client:
                    for _redirect_i in range(_MAX_REDIRECTS + 1):
                        resp = await client.get(
                            current_url,
                            headers={"User-Agent": "WorkPilot/0.1 (web_fetch tool)"},
                        )
                        if resp.is_redirect:
                            location = resp.headers.get("location")
                            if not location:
                                break
                            # Resolve relative redirects
                            current_url = urljoin(current_url, location)
                            await _validate_url(current_url)
                            continue
                        break
                    else:
                        return "Error: too many redirects (max 5)"

                    resp.raise_for_status()

                # Enforce response size limit
                content_length = resp.headers.get("content-length")
                if content_length and int(content_length) > _MAX_RESPONSE_BYTES:
                    return (
                        f"Error: response too large ({int(content_length)} bytes, "
                        f"max {_MAX_RESPONSE_BYTES})"
                    )
                if len(resp.content) > _MAX_RESPONSE_BYTES:
                    return (
                        f"Error: response too large ({len(resp.content)} bytes, "
                        f"max {_MAX_RESPONSE_BYTES})"
                    )

                content_type = resp.headers.get("content-type", "")
                raw_text = resp.text
                raw_html = None

                if "json" in content_type:
                    import json

                    try:
                        content = json.dumps(resp.json(), indent=2)
                    except Exception:
                        content = raw_text
                elif "html" in content_type:
                    raw_html = raw_text
                    content = self._extract_html(raw_text)
                    await self._cache.put(raw_cache_key, raw_html)
                elif "markdown" in content_type:
                    content = raw_text
                else:
                    content = raw_text

                await self._cache.put(extracted_cache_key, content)

            except httpx.TimeoutException:
                return "Web fetch timed out"
            except Exception as exc:
                logger.warning(f"web_fetch failed: {exc}")
                return f"Web fetch error: {exc}"

        # Apply CSS selector on raw HTML if available
        if selector and raw_html is not None:
            try:
                selected = self._apply_selector(raw_html, selector)
                if selected is not None:
                    content = selected
            except Exception as exc:
                logger.warning(f"CSS selector failed: {exc}")

        content = Sanitizer.truncate(content, max_chars)
        return f"{_UNTRUSTED_OPEN}\n{content}\n{_UNTRUSTED_CLOSE}"

    def _extract_html(self, html: str) -> str:
        """Extract readable content from HTML. Prefers bs4+markdownify, falls back to regex."""
        try:
            from bs4 import BeautifulSoup

            soup = BeautifulSoup(html, "html.parser")

            # Remove script, style, nav, footer, header tags
            for tag in soup(["script", "style", "nav", "footer", "header", "aside"]):
                tag.decompose()

            try:
                import markdownify

                return markdownify.markdownify(
                    str(soup.body or soup),
                    heading_style="ATX",
                    strip=["img"],
                ).strip()
            except ImportError:
                return soup.get_text(separator="\n", strip=True)

        except ImportError:
            # Regex fallback: strip all HTML tags
            text = re.sub(r"<script[^>]*>.*?</script>", "", html, flags=re.DOTALL)
            text = re.sub(r"<style[^>]*>.*?</style>", "", text, flags=re.DOTALL)
            text = _HTML_TAG.sub("", text)
            text = html_mod.unescape(text)
            # Collapse whitespace
            text = re.sub(r"\n{3,}", "\n\n", text)
            text = re.sub(r"[ \t]+", " ", text)
            return text.strip()

    def _apply_selector(self, html: str, selector: str) -> str | None:
        """Apply CSS selector to HTML and return extracted text."""
        try:
            from bs4 import BeautifulSoup

            soup = BeautifulSoup(html, "html.parser")
            elements = soup.select(selector)
            if not elements:
                return None

            parts: list[str] = []
            for el in elements:
                try:
                    import markdownify

                    parts.append(
                        markdownify.markdownify(str(el), heading_style="ATX", strip=["img"]).strip()
                    )
                except ImportError:
                    parts.append(el.get_text(separator="\n", strip=True))
            return "\n\n".join(parts)
        except ImportError:
            logger.warning("CSS selector requires beautifulsoup4: pip install beautifulsoup4")
            return None
