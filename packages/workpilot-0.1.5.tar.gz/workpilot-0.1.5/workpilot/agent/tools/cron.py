"""
CronTool — lets the agent manage scheduled jobs at runtime.

The agent can list, add, remove, enable, and disable jobs.
Dynamic jobs persist to .workpilot/cron/jobs.json.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from workpilot.agent.tools.base import Tool, ToolMetadata

if TYPE_CHECKING:
    from workpilot.cron.service import SchedulerService


class CronTool(Tool):
    """Agent-facing tool for managing scheduled jobs (nanobot CronTool pattern)."""

    def __init__(self, scheduler: SchedulerService) -> None:
        self._scheduler = scheduler

    @property
    def name(self) -> str:
        return "cron"

    @property
    def description(self) -> str:
        return (
            "Manage scheduled jobs and reminders. "
            "Actions: list (show all jobs), add (create a job), "
            "remove (delete a job), enable (re-enable), disable (pause), "
            "describe (show job details). "
            "Schedule types: "
            "'at:+SECONDS' for a delayed one-shot (e.g. 'at:+60' = remind in 1 min, "
            "'at:+300' = remind in 5 min), "
            "'at:ISO_DATETIME' for a specific time (e.g. 'at:2026-03-04T15:00:00'), "
            "'at' for immediate one-shot, "
            "integer like 120 for repeat every 120 seconds, "
            "cron expression like '*/5 * * * *' for standard cron. "
            "ALWAYS use notify_channels=['*'] so the result is delivered as a message."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["list", "add", "remove", "enable", "disable", "describe"],
                    "description": "Action to perform",
                },
                "job_id": {
                    "type": "string",
                    "description": "Job ID (required for remove/enable/disable/describe)",
                },
                "schedule": {
                    "type": "string",
                    "description": (
                        "Schedule type. "
                        "For reminders/delays: use 'at:+SECONDS' (e.g. 'at:+60' for 1 min, "
                        "'at:+120' for 2 min, 'at:+300' for 5 min). "
                        "For a specific time: use 'at:ISO_DATETIME' "
                        "(e.g. 'at:2026-03-04T15:00:00' or 'at:2026-03-04T15:00:00+08:00'). "
                        "For immediate one-shot: use 'at'. "
                        "For repeating: use integer seconds like 3600. "
                        "For cron: use expression like '0 9 * * *'."
                    ),
                },
                "prompt": {
                    "type": "string",
                    "description": "Job prompt (required for add)",
                },
                "notify_channels": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": (
                        "Channels to send the job result to. "
                        "Use ['*'] to broadcast to ALL active channels. "
                        "Use specific names like ['cli'] or ['cli', 'teams'] for targeted delivery. "
                        "If omitted, result is only logged."
                    ),
                },
            },
            "required": ["action"],
        }

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(risk_level="low", approval="auto")

    async def execute(self, **kwargs: Any) -> str:
        action = kwargs.get("action", "")

        if action == "list":
            jobs = self._scheduler.list_jobs()
            if not jobs:
                return "No scheduled jobs."
            lines = ["Scheduled jobs:"]
            for j in jobs:
                status = "enabled" if j["enabled"] else "DISABLED"
                next_run = j.get("next_run") or "N/A"
                lines.append(
                    f"  {j['name']}: {j['trigger_type']} ({j['schedule']}) "
                    f"agent={j['agent']} [{status}] next={next_run}"
                )
            return "\n".join(lines)

        elif action == "add":
            schedule = kwargs.get("schedule")
            prompt = kwargs.get("prompt")
            if not schedule or not prompt:
                return "Error: 'schedule' and 'prompt' are required for add."
            import uuid as _uuid

            job_id = kwargs.get("job_id") or f"agent-{_uuid.uuid4().hex[:8]}"
            notify_channels = kwargs.get("notify_channels") or ["*"]
            try:
                self._scheduler.add_job(
                    name=job_id,
                    schedule=schedule,
                    prompt=prompt,
                    notify_channels=notify_channels,
                    dynamic=True,
                )
            except ValueError as exc:
                return f"Error: {exc}"
            return f"Job '{job_id}' added (schedule={schedule})."

        elif action == "remove":
            job_id = kwargs.get("job_id")
            if not job_id:
                return "Error: 'job_id' is required for remove."
            if job_id not in {j["name"] for j in self._scheduler.list_jobs()}:
                return f"Error: job '{job_id}' not found."
            self._scheduler.remove_job(job_id)
            return f"Job '{job_id}' removed."

        elif action == "enable":
            job_id = kwargs.get("job_id")
            if not job_id:
                return "Error: 'job_id' is required for enable."
            if job_id not in {j["name"] for j in self._scheduler.list_jobs()}:
                return f"Error: job '{job_id}' not found."
            self._scheduler.enable(job_id)
            return f"Job '{job_id}' enabled."

        elif action == "disable":
            job_id = kwargs.get("job_id")
            if not job_id:
                return "Error: 'job_id' is required for disable."
            if job_id not in {j["name"] for j in self._scheduler.list_jobs()}:
                return f"Error: job '{job_id}' not found."
            self._scheduler.disable(job_id)
            return f"Job '{job_id}' disabled."

        elif action == "describe":
            job_id = kwargs.get("job_id")
            if not job_id:
                return "Error: 'job_id' is required for describe."
            jobs = {j["name"]: j for j in self._scheduler.list_jobs()}
            job = jobs.get(job_id)
            if not job:
                return f"Error: job '{job_id}' not found."
            return (
                f"Job: {job['name']}\n"
                f"Schedule: {job['trigger_type']} ({job['schedule']})\n"
                f"Agent: {job['agent']}\n"
                f"Status: {'enabled' if job['enabled'] else 'DISABLED'}\n"
                f"Next run: {job.get('next_run') or 'N/A'}\n"
                f"Failures: {job['failure_count']}"
            )

        return f"Unknown action: {action}"
