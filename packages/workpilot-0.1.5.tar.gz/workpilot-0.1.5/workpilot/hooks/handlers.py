"""
Built-in hook handlers — the 8 safety handlers always registered.

on_message_received:
  - InjectionScanner (priority 10)

pre_tool_use:
  - EStopGate (priority 1)
  - PolicyGate (priority 10)

post_tool_use:
  - LeakScanner (priority 10)
  - Redactor (priority 20)
  - Auditor (priority 30)

on_message_sent:
  - OutboundLeakScanner (priority 10)
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from loguru import logger

from workpilot.hooks.manager import (
    HookResult,
    MessageHookContext,
    PostToolHookContext,
    PreToolHookContext,
)
from workpilot.security.leak import detect_credentials, redact_credentials
from workpilot.security.sanitizer import Sanitizer

if TYPE_CHECKING:
    from workpilot.security.audit import AuditLogger
    from workpilot.security.classifier import SecurityClassifier
    from workpilot.security.rbac import PolicyEngine


# ── on_message_received handlers ─────────────────────────────────────────────


class InjectionScanner:
    """Detect prompt injection patterns in inbound messages."""

    def __init__(self, *, block: bool = False) -> None:
        self._block = block

    async def __call__(self, ctx: MessageHookContext) -> HookResult:
        findings = Sanitizer.check_prompt_injection(ctx.content)
        if findings:
            logger.warning(
                "Injection patterns detected from {}: {}",
                ctx.sender_id or "unknown",
                findings,
            )
            if self._block:
                return HookResult.reject(f"Prompt injection detected: {findings[0]}")
        return HookResult.allow()


# ── pre_tool_use handlers ────────────────────────────────────────────────────


class EStopGate:
    """Reject all tool calls when E-stop is active."""

    def __init__(self, estop: object | None = None) -> None:
        self._estop = estop

    async def __call__(self, ctx: PreToolHookContext) -> HookResult:
        if self._estop is not None and getattr(self._estop, "is_halted", False):
            return HookResult.reject("E-stop is active — all tool execution halted")
        return HookResult.allow()


class PolicyGate:
    """Check RBAC permissions before tool execution."""

    def __init__(self, policy_engine: PolicyEngine | None = None) -> None:
        self._engine = policy_engine

    async def __call__(self, ctx: PreToolHookContext) -> HookResult:
        if self._engine is None:
            return HookResult.allow()
        # check_permission returns (allowed: bool, level: AutonomyLevel)
        # operation defaults to "write" for tools that modify state
        operation = (
            "read" if ctx.tool_name in ("read_file", "list_dir", "search_files") else "write"
        )
        allowed, _level = self._engine.check_permission(
            ctx.tool_name, operation, agent_name=ctx.agent_name
        )
        if not allowed:
            return HookResult.reject(
                f"Tool '{ctx.tool_name}' denied by policy for agent '{ctx.agent_name}'"
            )
        return HookResult.allow()


class ApprovalGate:
    """Security Agent approval gate for tool calls.

    Routes all tool calls through the SecurityClassifier, which handles
    profile-based shortcuts (open=allow, restricted=deny) and LLM-based
    risk assessment for standard/controlled profiles.

    Tool metadata (never/auto/always) is not checked here — the classifier
    handles risk assessment based on tool name, args, and security profile.
    In a future version, tool metadata will be used for pre-filtering.

    When no classifier is provided the gate allows all calls (backward
    compatible with the pre-v0.2 stub behaviour).
    """

    def __init__(self, classifier: SecurityClassifier | None = None) -> None:
        self._classifier = classifier

    async def __call__(self, ctx: PreToolHookContext) -> HookResult:
        # No classifier wired -> allow all (backward compat)
        if not self._classifier:
            return HookResult.allow()

        result = await self._classifier.classify(ctx.tool_name, ctx.args, tool_risk=ctx.tool_risk)
        if result.decision == "allow":
            return HookResult.allow()
        if result.decision == "escalate":
            # In v0.2, escalate will route to human approval UI.
            # For now, treated as reject for safety.
            return HookResult.reject(f"Escalated for review: {result.reason}")
        return HookResult.reject(f"[{result.risk}] {result.reason}")


# ── post_tool_use handlers ───────────────────────────────────────────────────


class LeakScanner:
    """Scan tool output for credential patterns and env-var values."""

    async def __call__(self, ctx: PostToolHookContext) -> HookResult:
        # Pattern-based detection (JWT, AWS, GitHub PAT, etc.)
        findings = detect_credentials(ctx.result)
        if findings:
            types = ", ".join(sorted({t for t, _ in findings}))
            logger.warning(
                "Credential patterns detected in '{}' output: {}",
                ctx.tool_name,
                types,
            )

        # Env-var value detection (existing)
        redacted = Sanitizer.redact_env_values(ctx.result)
        if redacted != ctx.result:
            logger.warning("Env var leak detected in '{}' output", ctx.tool_name)

        return HookResult.allow()


class Redactor:
    """Replace detected secrets in tool output.

    Env-var values are replaced with ``[REDACTED]``.
    Credential patterns are replaced with ``[REDACTED:{type}]``
    (e.g. ``[REDACTED:JWT]``, ``[REDACTED:AWS Access Key]``).
    """

    async def __call__(self, ctx: PostToolHookContext) -> HookResult:
        # Pattern-based redaction first, then env-var redaction
        cleaned = redact_credentials(ctx.result)
        cleaned = Sanitizer.redact_env_values(cleaned)
        if cleaned != ctx.result:
            ctx.result = cleaned
        return HookResult.allow(data=ctx)


class Auditor:
    """Log every tool call to the audit trail."""

    def __init__(self, audit_logger: AuditLogger | None = None) -> None:
        self._audit = audit_logger

    async def __call__(self, ctx: PostToolHookContext) -> HookResult:
        if self._audit is not None:
            self._audit.log_tool(
                tool=ctx.tool_name,
                actor=ctx.agent_name,
                args=ctx.args,
                result=ctx.result[:200] if ctx.result else "",
                is_error=not ctx.success,
                session_id=ctx.session_id,
                duration_ms=ctx.duration_ms,
            )
        return HookResult.allow()


# ── on_message_sent handlers ────────────────────────────────────────────────


class OutboundLeakScanner:
    """Scan outbound responses for credential leaks."""

    async def __call__(self, ctx: MessageHookContext) -> HookResult:
        cleaned = redact_credentials(ctx.content)
        cleaned = Sanitizer.redact_env_values(cleaned)
        if cleaned != ctx.content:
            logger.warning("Leak detected in outbound message to {}", ctx.channel)
            ctx.content = cleaned
        return HookResult.allow(data=ctx)


# ── Registration helper ──────────────────────────────────────────────────────


def register_builtin_handlers(
    hook_manager: object,
    *,
    estop: object | None = None,
    policy_engine: PolicyEngine | None = None,
    audit_logger: AuditLogger | None = None,
    classifier: SecurityClassifier | None = None,
    block_injections: bool = False,
) -> None:
    """Register all built-in handlers onto a HookManager.

    Args:
        hook_manager: HookManager instance.
        estop: EStop instance (optional).
        policy_engine: PolicyEngine instance (optional).
        audit_logger: AuditLogger instance (optional).
        classifier: SecurityClassifier for the ApprovalGate (optional).
        block_injections: If True, reject messages with injection patterns.
    """
    mgr = hook_manager  # type: ignore[assignment]

    # on_message_received
    mgr.register("on_message_received", InjectionScanner(block=block_injections), priority=10)

    # pre_tool_use
    mgr.register("pre_tool_use", EStopGate(estop), priority=1)
    mgr.register("pre_tool_use", PolicyGate(policy_engine), priority=10)
    mgr.register("pre_tool_use", ApprovalGate(classifier), priority=20)

    # post_tool_use
    mgr.register("post_tool_use", LeakScanner(), priority=10)
    mgr.register("post_tool_use", Redactor(), priority=20)
    mgr.register("post_tool_use", Auditor(audit_logger), priority=30)

    # on_message_sent
    mgr.register("on_message_sent", OutboundLeakScanner(), priority=10)
