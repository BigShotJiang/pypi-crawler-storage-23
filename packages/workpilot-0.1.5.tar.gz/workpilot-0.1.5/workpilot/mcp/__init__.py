"""
MCP (Model Context Protocol) integration for WorkPilot.

Provides client and server implementations for MCP, enabling WorkPilot to:
- **Client**: connect to external MCP servers and use their tools
- **Server**: expose WorkPilot tools to external MCP clients

Both transports (stdio subprocess and HTTP/SSE) are supported via
the pluggable transport layer in ``workpilot.mcp.transport``.
"""

from workpilot.mcp.client import MCPClient
from workpilot.mcp.server import MCPServer

__all__ = ["MCPClient", "MCPServer"]
