"""
MCP client — connects to external MCP servers to discover and invoke tools.

Supports both stdio (subprocess) and HTTP/SSE transports using JSON-RPC 2.0
protocol, following the Model Context Protocol specification.
"""

from __future__ import annotations

import asyncio
from typing import Any

from loguru import logger

from workpilot.mcp.transport import HttpTransport, MCPTransport, StdioTransport


class MCPClient:
    """
    Client that connects to an external MCP server.

    Supports two transport modes:
    - **stdio**: spawns a subprocess and communicates via stdin/stdout
    - **http**: connects to an HTTP/SSE endpoint

    Usage::

        client = MCPClient(command="npx", args=["-y", "@modelcontextprotocol/server-fs"])
        await client.connect()
        tools = await client.list_tools()
        result = await client.call_tool("read_file", {"path": "/tmp/example.txt"})
        await client.disconnect()
    """

    def __init__(
        self,
        *,
        command: str | None = None,
        args: list[str] | None = None,
        url: str | None = None,
        headers: dict[str, str] | None = None,
        name: str = "mcp-server",
    ) -> None:
        """
        Initialize the MCP client.

        Provide either command/args for stdio transport, or url for HTTP transport.

        Args:
            command: Executable to spawn for stdio transport.
            args: Arguments for the subprocess command.
            url: URL for HTTP/SSE transport.
            headers: Optional HTTP headers (for HTTP transport).
            name: Human-readable server name for logging.
        """
        if command is None and url is None:
            raise ValueError("MCPClient requires either 'command' (stdio) or 'url' (http)")

        self._name = name
        self._transport: MCPTransport | None = None
        self._request_id = 0
        self._pending: dict[int, asyncio.Future[dict[str, Any]]] = {}
        self._receive_task: asyncio.Task[None] | None = None

        if command is not None:
            self._transport_factory = lambda: StdioTransport(command, args)
        else:
            assert url is not None
            self._transport_factory = lambda: HttpTransport(url, headers=headers)

    @property
    def is_connected(self) -> bool:
        """Whether the client has an active transport connection."""
        return self._transport is not None

    @property
    def name(self) -> str:
        """Server name for logging and identification."""
        return self._name

    async def connect(self) -> None:
        """
        Establish connection to the MCP server.

        For stdio: spawns the subprocess.
        For HTTP: opens the HTTP client and SSE stream.
        """
        if self._transport is not None:
            logger.warning(f"MCPClient({self._name}): already connected")
            return

        transport = self._transport_factory()
        await transport.start()
        self._transport = transport
        self._receive_task = asyncio.create_task(self._receive_loop())

        # Send initialize handshake
        response = await self._send_request(
            "initialize",
            {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {
                    "name": "workpilot",
                    "version": "0.1.0",
                },
            },
        )
        logger.info(
            f"MCPClient({self._name}): connected, "
            f"server={response.get('result', {}).get('serverInfo', {})}"
        )

        # Send initialized notification (no response expected)
        await self._send_notification("notifications/initialized", {})

    async def list_tools(self) -> list[dict[str, Any]]:
        """
        Request the list of available tools from the MCP server.

        Returns:
            List of tool descriptors, each with 'name', 'description',
            and 'inputSchema' fields.
        """
        if self._transport is None:
            raise RuntimeError(f"MCPClient({self._name}): not connected")

        response = await self._send_request("tools/list", {})
        result = response.get("result", {})
        tools = result.get("tools", [])
        logger.debug(f"MCPClient({self._name}): discovered {len(tools)} tools")
        return tools

    async def call_tool(self, name: str, arguments: dict[str, Any] | None = None) -> str:
        """
        Invoke a tool on the MCP server.

        Args:
            name: Tool name as reported by list_tools().
            arguments: Tool input parameters.

        Returns:
            Tool execution result as a string.
        """
        if self._transport is None:
            raise RuntimeError(f"MCPClient({self._name}): not connected")

        response = await self._send_request(
            "tools/call",
            {
                "name": name,
                "arguments": arguments or {},
            },
        )

        # Check for JSON-RPC error
        if "error" in response:
            error = response["error"]
            code = error.get("code", -1)
            message = error.get("message", "Unknown error")
            logger.error(f"MCPClient({self._name}): tool error: [{code}] {message}")
            return f"MCP error [{code}]: {message}"

        # Extract result content
        result = response.get("result", {})
        content_parts = result.get("content", [])
        text_parts: list[str] = []
        for part in content_parts:
            if isinstance(part, dict) and part.get("type") == "text":
                text_parts.append(part.get("text", ""))
            elif isinstance(part, dict):
                text_parts.append(str(part))
            else:
                text_parts.append(str(part))

        return "\n".join(text_parts) if text_parts else str(result)

    async def disconnect(self) -> None:
        """Close the connection to the MCP server."""
        if self._receive_task is not None:
            self._receive_task.cancel()
            try:
                await self._receive_task
            except asyncio.CancelledError:
                pass
            self._receive_task = None

        if self._transport is not None:
            await self._transport.close()
            self._transport = None

        # Cancel any pending requests
        for future in self._pending.values():
            if not future.done():
                future.cancel()
        self._pending.clear()

        logger.info(f"MCPClient({self._name}): disconnected")

    # ------------------------------------------------------------------
    # Internal JSON-RPC helpers
    # ------------------------------------------------------------------

    def _next_id(self) -> int:
        """Generate monotonically increasing request IDs."""
        self._request_id += 1
        return self._request_id

    async def _send_request(
        self,
        method: str,
        params: dict[str, Any],
        *,
        timeout: float = 30.0,
    ) -> dict[str, Any]:
        """Send a JSON-RPC request and wait for the matching response."""
        if self._transport is None:
            raise RuntimeError(f"MCPClient({self._name}): transport not available")

        request_id = self._next_id()
        message: dict[str, Any] = {
            "jsonrpc": "2.0",
            "id": request_id,
            "method": method,
            "params": params,
        }

        future: asyncio.Future[dict[str, Any]] = asyncio.get_event_loop().create_future()
        self._pending[request_id] = future

        await self._transport.send(message)

        try:
            return await asyncio.wait_for(future, timeout=timeout)
        except TimeoutError:
            self._pending.pop(request_id, None)
            raise TimeoutError(
                f"MCPClient({self._name}): request '{method}' (id={request_id}) "
                f"timed out after {timeout}s"
            )

    async def _send_notification(self, method: str, params: dict[str, Any]) -> None:
        """Send a JSON-RPC notification (no response expected)."""
        if self._transport is None:
            raise RuntimeError(f"MCPClient({self._name}): transport not available")

        message: dict[str, Any] = {
            "jsonrpc": "2.0",
            "method": method,
            "params": params,
        }
        await self._transport.send(message)

    async def _receive_loop(self) -> None:
        """Background task that routes incoming JSON-RPC messages to pending futures."""
        assert self._transport is not None
        try:
            while True:
                message = await self._transport.receive()

                # Match responses to pending requests by id
                msg_id = message.get("id")
                if msg_id is not None and msg_id in self._pending:
                    future = self._pending.pop(msg_id)
                    if not future.done():
                        future.set_result(message)
                elif msg_id is not None:
                    logger.debug(
                        f"MCPClient({self._name}): received response for unknown id={msg_id}"
                    )
                else:
                    # Server-initiated notification — log it
                    method = message.get("method", "unknown")
                    logger.debug(f"MCPClient({self._name}): notification: {method}")
        except (ConnectionError, asyncio.CancelledError):
            pass
        except Exception as exc:
            logger.error(f"MCPClient({self._name}): receive loop error: {exc}")
