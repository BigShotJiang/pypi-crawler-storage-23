"""
Approval workflow — gates agent actions that require human confirmation.

When the PolicyEngine resolves an autonomy level of APPROVAL (level 1),
the agent creates an ApprovalRequest here.  The request stays pending
until a human resolves it (approve / deny) or the configured timeout
elapses.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import Any

from loguru import logger

from workpilot.config.schema import ApprovalConfig, AutonomyLevel

# ── Data model ──────────────────────────────────────────────────────────────


class ApprovalStatus(str, Enum):
    """Lifecycle states for an approval request."""

    PENDING = "pending"
    APPROVED = "approved"
    DENIED = "denied"
    TIMEOUT = "timeout"


@dataclass
class ApprovalRequest:
    """A single pending-approval record.

    Attributes
    ----------
    id:
        Unique request identifier (UUID4).
    tool_name:
        The tool that triggered the approval requirement.
    args:
        The arguments the tool would be called with.
    agent_name:
        The agent that requested the action.
    autonomy_level:
        The resolved autonomy level at creation time.
    channel:
        Channel through which the approval was requested.
    status:
        Current lifecycle state.
    created_at:
        UTC timestamp of request creation.
    resolved_at:
        UTC timestamp of resolution, or ``None`` if still pending.
    resolver:
        Identity of the human who resolved the request, or ``None``.
    """

    id: str = field(default_factory=lambda: uuid.uuid4().hex)
    tool_name: str = ""
    args: dict[str, Any] = field(default_factory=dict)
    agent_name: str = ""
    autonomy_level: AutonomyLevel = AutonomyLevel.APPROVAL
    channel: str = "cli"
    status: ApprovalStatus = ApprovalStatus.PENDING
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    resolved_at: datetime | None = None
    resolver: str | None = None


# ── Manager ─────────────────────────────────────────────────────────────────


class ApprovalManager:
    """Manages the lifecycle of approval requests.

    Parameters
    ----------
    config:
        Approval workflow settings (timeout, escalation channels, etc.).
    """

    def __init__(self, config: ApprovalConfig) -> None:
        self._config = config
        self._pending: dict[str, ApprovalRequest] = {}
        logger.debug(
            "ApprovalManager initialised — timeout={}s, escalation={}",
            config.timeout_seconds,
            config.escalation_channels,
        )

    # ── Create request ──────────────────────────────────────────────────

    async def request_approval(
        self,
        tool_name: str,
        args: dict[str, Any],
        agent_name: str,
        channel: str,
    ) -> ApprovalRequest:
        """Create an approval request and register it as pending.

        Parameters
        ----------
        tool_name:
            The tool requiring approval.
        args:
            Proposed tool call arguments.
        agent_name:
            Agent identity requesting the action.
        channel:
            Channel the approval prompt should be sent through.

        Returns
        -------
        ApprovalRequest
            The newly created (PENDING) request.
        """
        request = ApprovalRequest(
            tool_name=tool_name,
            args=args,
            agent_name=agent_name,
            autonomy_level=AutonomyLevel.APPROVAL,
            channel=channel or self._config.default_channel,
        )
        self._pending[request.id] = request
        logger.info(
            "Approval requested: id={} tool={} agent={} channel={}",
            request.id,
            tool_name,
            agent_name,
            channel,
        )
        return request

    # ── Resolve ─────────────────────────────────────────────────────────

    def resolve(self, request_id: str, approved: bool, resolver: str) -> None:
        """Resolve a pending request.

        Parameters
        ----------
        request_id:
            The UUID of the request to resolve.
        approved:
            ``True`` to approve, ``False`` to deny.
        resolver:
            Identity of the human resolving the request.

        Raises
        ------
        KeyError
            If ``request_id`` is not found among pending requests.
        ValueError
            If the request has already been resolved.
        """
        if request_id not in self._pending:
            raise KeyError(f"Approval request not found: {request_id}")

        request = self._pending[request_id]
        if request.status != ApprovalStatus.PENDING:
            raise ValueError(f"Request {request_id} already resolved as {request.status.value}")

        request.status = ApprovalStatus.APPROVED if approved else ApprovalStatus.DENIED
        request.resolved_at = datetime.now(UTC)
        request.resolver = resolver

        logger.info(
            "Approval resolved: id={} status={} resolver={}",
            request_id,
            request.status.value,
            resolver,
        )

        # Remove from pending map once resolved
        del self._pending[request_id]

    # ── Queries ─────────────────────────────────────────────────────────

    def get_pending(self) -> list[ApprovalRequest]:
        """Return all currently pending approval requests.

        Requests that have timed out are automatically marked before
        being filtered out.
        """
        # Sweep timeouts first
        for req_id in list(self._pending):
            self.check_timeout(req_id)

        return [req for req in self._pending.values() if req.status == ApprovalStatus.PENDING]

    def check_timeout(self, request_id: str) -> bool:
        """Check whether a pending request has exceeded its timeout.

        If timed out the request's status is updated to ``TIMEOUT`` and
        it is removed from the pending map.

        Parameters
        ----------
        request_id:
            The UUID of the request to check.

        Returns
        -------
        bool
            ``True`` if the request has timed out, ``False`` otherwise.
            Also returns ``False`` if the request is not found.
        """
        request = self._pending.get(request_id)
        if request is None:
            return False

        elapsed = (datetime.now(UTC) - request.created_at).total_seconds()
        if elapsed >= self._config.timeout_seconds:
            request.status = ApprovalStatus.TIMEOUT
            request.resolved_at = datetime.now(UTC)
            del self._pending[request_id]
            logger.warning(
                "Approval request timed out: id={} tool={} elapsed={:.0f}s",
                request_id,
                request.tool_name,
                elapsed,
            )
            return True

        return False
