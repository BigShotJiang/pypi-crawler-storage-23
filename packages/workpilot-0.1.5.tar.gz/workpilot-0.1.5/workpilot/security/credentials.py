"""
Credential manager — resolves secrets from environment variables, .env files,
or Azure Key Vault.  Never persists credentials to disk in plaintext.
"""

from __future__ import annotations

import os
from pathlib import Path

import httpx
from loguru import logger

from workpilot.config.schema import CredentialProvider


class CredentialManager:
    """
    Hierarchical credential resolution:
    1. In-memory cache (populated on first access)
    2. Environment variables
    3. .env file (if provider == dotenv)
    4. Azure Key Vault (if provider == azure-keyvault)
    """

    def __init__(
        self,
        provider: CredentialProvider = CredentialProvider.ENV,
        vault_url: str | None = None,
    ) -> None:
        self._provider = provider
        self._vault_url = vault_url
        self._cache: dict[str, str] = {}

    def get(self, name: str) -> str:
        """Get a credential or raise KeyError."""
        if name in self._cache:
            return self._cache[name]

        value: str | None = None
        if self._provider == CredentialProvider.ENV:
            value = os.environ.get(name)
        elif self._provider == CredentialProvider.DOTENV:
            value = os.environ.get(name) or self._from_dotenv(name)
        elif self._provider == CredentialProvider.AZURE_KEYVAULT:
            value = os.environ.get(name) or self._from_keyvault(name)

        if value is None:
            raise KeyError(f"Credential not found: {name}")

        self._cache[name] = value
        return value

    def get_optional(self, name: str) -> str | None:
        try:
            return self.get(name)
        except KeyError:
            return None

    def _from_dotenv(self, name: str) -> str | None:
        dotenv_path = Path.cwd() / ".env"
        if not dotenv_path.is_file():
            return None
        for line in dotenv_path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" not in line:
                continue
            key, _, val = line.partition("=")
            key = key.strip()
            val = val.strip().strip("'\"")
            if key == name:
                return val
        return None

    def _from_keyvault(self, name: str) -> str | None:
        if not self._vault_url:
            logger.warning("Key Vault URL not configured")
            return None
        try:
            # Use managed identity token
            token_resp = httpx.get(
                "http://169.254.169.254/metadata/identity/oauth2/token",
                params={"api-version": "2019-08-01", "resource": "https://vault.azure.net"},
                headers={"Metadata": "true"},
                timeout=5.0,
            )
            token_resp.raise_for_status()
            access_token = token_resp.json()["access_token"]

            secret_name = name.replace("_", "-").lower()
            secret_resp = httpx.get(
                f"{self._vault_url}/secrets/{secret_name}",
                params={"api-version": "7.4"},
                headers={"Authorization": f"Bearer {access_token}"},
                timeout=10.0,
            )
            if secret_resp.status_code == 200:
                return secret_resp.json()["value"]
            logger.warning(f"Key Vault secret {secret_name} not found: {secret_resp.status_code}")
        except Exception as exc:
            logger.error(f"Key Vault error: {exc}")
        return None

    def clear_cache(self) -> None:
        self._cache.clear()
