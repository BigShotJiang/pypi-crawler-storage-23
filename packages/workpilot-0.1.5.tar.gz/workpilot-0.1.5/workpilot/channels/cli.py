"""
CLI channel — interactive REPL for local terminal use.
"""

from __future__ import annotations

import asyncio
import sys
from typing import Any

from rich.console import Console

from workpilot.bus.events import OutboundMessage, StreamingChunk
from workpilot.bus.queue import MessageBus
from workpilot.channels.base import BaseChannel

console = Console()


class CLIChannel(BaseChannel):
    """Terminal-based interactive channel."""

    def __init__(self, bus: MessageBus, prompt: str = "you> ") -> None:
        super().__init__(bus)
        self._prompt = prompt
        self._running = False
        self._streaming = False

    @property
    def name(self) -> str:
        return "cli"

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def send(self, channel_id: str, content: str, **kwargs: Any) -> None:
        console.print()
        console.print(f"[bold green]assistant>[/bold green] {content}")
        console.print()

    async def _handle_outbound(self, msg: OutboundMessage | StreamingChunk) -> None:
        """Handle both full messages and streaming chunks from the bus."""
        if isinstance(msg, StreamingChunk) and msg.channel == self.name:
            if msg.done:
                if self._streaming:
                    sys.stdout.write("\n\n")
                    sys.stdout.flush()
                    self._streaming = False
            else:
                if not self._streaming:
                    sys.stdout.write("\nassistant> ")
                    self._streaming = True
                sys.stdout.write(msg.content)
                sys.stdout.flush()

    async def run_repl(self) -> None:
        """Run the interactive read-eval-print loop."""
        from prompt_toolkit import PromptSession
        from prompt_toolkit.patch_stdout import patch_stdout

        session: PromptSession[str] = PromptSession(self._prompt)
        self._running = True

        # Subscribe to streaming chunks from the bus
        self._bus.on_outbound(self._handle_outbound)

        console.print("[bold]WorkPilot Chat[/bold] — type /exit to quit, /new to reset\n")

        while self._running:
            try:
                with patch_stdout():
                    text = await asyncio.get_event_loop().run_in_executor(
                        None, lambda: session.prompt()
                    )
            except (EOFError, KeyboardInterrupt):
                break

            text = text.strip()
            if not text:
                continue
            if text in ("/exit", "/quit"):
                break

            await self._handle_message(
                channel_id="terminal",
                sender_id="user",
                sender_name="User",
                content=text,
            )

            # Wait for the response to be sent (give agent time)
            await asyncio.sleep(0.1)
