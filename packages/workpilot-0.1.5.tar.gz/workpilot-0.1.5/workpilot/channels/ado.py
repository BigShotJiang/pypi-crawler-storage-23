"""
Azure DevOps channel — work items, PR comments, pipeline triggers.
"""

from __future__ import annotations

import base64
from typing import Any

import httpx
from loguru import logger

from workpilot.bus.queue import MessageBus
from workpilot.channels.base import BaseChannel


class ADOChannel(BaseChannel):
    """Azure DevOps REST API channel."""

    def __init__(
        self,
        bus: MessageBus,
        *,
        organization: str,
        project: str,
        pat: str,
        allow_from: list[str] | None = None,
    ) -> None:
        super().__init__(bus, allow_from)
        self._org = organization
        self._project = project
        self._auth = base64.b64encode(f":{pat}".encode()).decode()
        self._base = f"https://dev.azure.com/{organization}"

    @property
    def name(self) -> str:
        return "ado"

    async def start(self) -> None:
        logger.info(f"ADO channel started (org={self._org}, project={self._project})")

    async def stop(self) -> None:
        pass

    def _headers(self, content_type: str = "application/json") -> dict[str, str]:
        return {
            "Authorization": f"Basic {self._auth}",
            "Content-Type": content_type,
        }

    async def send(self, channel_id: str, content: str, **kwargs: Any) -> None:
        action = kwargs.get("action", "comment-work-item")
        if action == "comment-work-item":
            await self._comment_work_item(int(kwargs["work_item_id"]), content)
        elif action == "comment-pr":
            await self._comment_pr(kwargs["repository_id"], int(kwargs["pr_id"]), content)

    async def _comment_work_item(self, work_item_id: int, comment: str) -> None:
        url = (
            f"{self._base}/{self._project}/_apis/wit/workitems/"
            f"{work_item_id}/comments?api-version=7.1-preview.4"
        )
        async with httpx.AsyncClient() as client:
            resp = await client.post(url, json={"text": comment}, headers=self._headers())
            if not resp.is_success:
                logger.error(f"ADO comment failed: {resp.status_code}")

    async def _comment_pr(self, repo_id: str, pr_id: int, comment: str) -> None:
        url = (
            f"{self._base}/{self._project}/_apis/git/repositories/{repo_id}/"
            f"pullRequests/{pr_id}/threads?api-version=7.1"
        )
        body = {
            "comments": [{"parentCommentId": 0, "content": comment, "commentType": 1}],
            "status": 1,
        }
        async with httpx.AsyncClient() as client:
            resp = await client.post(url, json=body, headers=self._headers())
            if not resp.is_success:
                logger.error(f"ADO PR comment failed: {resp.status_code}")

    async def create_work_item(
        self,
        wi_type: str,
        title: str,
        description: str = "",
        assigned_to: str = "",
    ) -> dict[str, Any]:
        url = f"{self._base}/{self._project}/_apis/wit/workitems/${wi_type}?api-version=7.1"
        patches = [{"op": "add", "path": "/fields/System.Title", "value": title}]
        if description:
            patches.append(
                {"op": "add", "path": "/fields/System.Description", "value": description}
            )
        if assigned_to:
            patches.append({"op": "add", "path": "/fields/System.AssignedTo", "value": assigned_to})

        async with httpx.AsyncClient() as client:
            resp = await client.post(
                url,
                json=patches,
                headers=self._headers("application/json-patch+json"),
            )
            resp.raise_for_status()
            return resp.json()

    async def trigger_pipeline(self, pipeline_id: int, branch: str | None = None) -> dict[str, Any]:
        url = f"{self._base}/{self._project}/_apis/pipelines/{pipeline_id}/runs?api-version=7.1"
        body: dict[str, Any] = {}
        if branch:
            body["resources"] = {"repositories": {"self": {"refName": f"refs/heads/{branch}"}}}

        async with httpx.AsyncClient() as client:
            resp = await client.post(url, json=body, headers=self._headers())
            resp.raise_for_status()
            return resp.json()

    async def process_webhook(self, payload: dict[str, Any]) -> None:
        """Process an ADO webhook event."""
        event_type = payload.get("eventType", "")
        resource = payload.get("resource", {})
        if not resource:
            return

        if event_type.startswith("workitem."):
            fields = resource.get("fields", {})
            await self._handle_message(
                channel_id=f"workitem/{resource.get('id', '')}",
                sender_id=resource.get("revisedBy", {}).get("uniqueName", "system"),
                sender_name=resource.get("revisedBy", {}).get("displayName", "system"),
                content=fields.get("System.Description", fields.get("System.Title", "")),
                metadata={"event_type": event_type, "work_item_id": resource.get("id")},
            )
