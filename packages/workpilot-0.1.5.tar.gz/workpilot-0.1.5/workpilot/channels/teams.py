"""
Microsoft Teams channel — Bot Framework REST API integration.
"""

from __future__ import annotations

from typing import Any

import httpx
from loguru import logger

from workpilot.bus.queue import MessageBus
from workpilot.channels.base import BaseChannel


class TeamsChannel(BaseChannel):
    """MS Teams via Bot Framework REST API."""

    def __init__(
        self,
        bus: MessageBus,
        *,
        app_id: str,
        app_password: str,
        tenant_id: str | None = None,
        allow_from: list[str] | None = None,
    ) -> None:
        super().__init__(bus, allow_from)
        self._app_id = app_id
        self._app_password = app_password
        self._tenant_id = tenant_id
        self._token: str = ""
        self._token_expires: float = 0

    @property
    def name(self) -> str:
        return "teams"

    async def start(self) -> None:
        logger.info("Teams channel started")

    async def stop(self) -> None:
        self._token = ""

    async def _get_token(self) -> str:
        import time

        if self._token and time.time() < self._token_expires - 60:
            return self._token

        url = (
            f"https://login.microsoftonline.com/{self._tenant_id}/oauth2/v2.0/token"
            if self._tenant_id
            else "https://login.microsoftonline.com/botframework.com/oauth2/v2.0/token"
        )
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                url,
                data={
                    "grant_type": "client_credentials",
                    "client_id": self._app_id,
                    "client_secret": self._app_password,
                    "scope": "https://api.botframework.com/.default",
                },
            )
            resp.raise_for_status()
            data = resp.json()
            self._token = data["access_token"]
            self._token_expires = time.time() + data["expires_in"]
            return self._token

    async def send(self, channel_id: str, content: str, **kwargs: Any) -> None:
        token = await self._get_token()
        service_url = kwargs.get("service_url", "https://smba.trafficmanager.net/teams/")
        activity = {"type": "message", "text": content}
        if kwargs.get("reply_to_id"):
            activity["replyToId"] = kwargs["reply_to_id"]

        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{service_url}v3/conversations/{channel_id}/activities",
                json=activity,
                headers={"Authorization": f"Bearer {token}"},
            )
            if not resp.is_success:
                logger.error(f"Teams send failed: {resp.status_code} {resp.text}")

    async def process_activity(self, activity: dict[str, Any]) -> None:
        """Process an incoming Bot Framework activity (call from webhook)."""
        if activity.get("type") != "message":
            return

        sender = activity.get("from", {})
        conversation = activity.get("conversation", {})

        await self._handle_message(
            channel_id=conversation.get("id", ""),
            sender_id=sender.get("aadObjectId", sender.get("id", "")),
            sender_name=sender.get("name", ""),
            content=activity.get("text", ""),
            thread_id=conversation.get("id"),
            metadata={
                "service_url": activity.get("serviceUrl"),
                "activity_id": activity.get("id"),
            },
        )
