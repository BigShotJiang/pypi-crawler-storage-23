---
name: ado
description: Azure DevOps work item and pipeline assistance
metadata:
  workpilot:
    activation:
      keywords: [ado, azure devops, work item, pipeline, boards]
    always: false
---
## Azure DevOps Workflow

When working with Azure DevOps:
1. Link work items to PRs and commits
2. Update work item state as work progresses
3. Use proper area paths and iteration paths
4. Monitor pipeline runs and fix failures
