"""
GatewayServer — FastAPI-based HTTP API gateway for WorkPilot.

Provides:
- / — status dashboard (auto-refresh every 5 s)
- /chat  /chat.html — chat UI (moved from /)
- /health — basic health check (backward compat)
- /v1/chat/completions — OpenAI-compatible chat completions (backward compat)
- /webhooks/{channel} — webhook receiver for GitHub/ADO/Teams/Outlook
- /api/chat — send prompt, receive response (via bus)
- /api/chat/stream — SSE streaming response
- /api/ws — WebSocket bidirectional chat
- /api/sessions — session management
- /api/tools — tool discovery
- /api/health — detailed health check
- /api/status — comprehensive runtime status (polled by dashboard)
- /api/estop — E-stop trigger
- /api/reset — E-stop reset

FastAPI and uvicorn are imported at use time so the rest of
WorkPilot can start without them installed.
"""

from __future__ import annotations

import asyncio
import json
import time
import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

from loguru import logger
from pydantic import BaseModel, Field

from workpilot import __version__
from workpilot.config.schema import GatewayConfig
from workpilot.gateway.auth import AuthMiddleware
from workpilot.gateway.estop_middleware import EStopMiddleware
from workpilot.gateway.middleware import RateLimiter, RequestLogger
from workpilot.utils.helpers import webchat_url_from_connect

if TYPE_CHECKING:
    from workpilot.channels.web import WebChannel
    from workpilot.runtime import Runtime

# FastAPI types needed at module level for annotation resolution
# (from __future__ import annotations defers evaluation, so get_type_hints()
# needs these in module globals).
try:
    from fastapi import Request, WebSocket
except ImportError:
    pass


# ── Request / Response schemas (backward-compat OpenAI format) ─────────────


class ChatMessage(BaseModel):
    """Single message in a chat completion request."""

    role: str
    content: str


class ChatCompletionRequest(BaseModel):
    """OpenAI-compatible chat completion request."""

    messages: list[ChatMessage]
    model: str | None = None
    stream: bool = False
    temperature: float | None = None
    max_tokens: int | None = None


class ChatChoiceMessage(BaseModel):
    """Message inside a chat completion choice."""

    role: str = "assistant"
    content: str


class ChatChoice(BaseModel):
    """Single choice in a chat completion response."""

    index: int = 0
    message: ChatChoiceMessage
    finish_reason: str = "stop"


class UsageInfo(BaseModel):
    """Token usage statistics."""

    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0


class ChatCompletionResponse(BaseModel):
    """OpenAI-compatible chat completion response."""

    id: str = Field(default_factory=lambda: f"chatcmpl-{uuid.uuid4().hex[:12]}")
    object: str = "chat.completion"
    created: int = Field(default_factory=lambda: int(time.time()))
    model: str = "workpilot"
    choices: list[ChatChoice]
    usage: UsageInfo = Field(default_factory=UsageInfo)


class WebhookPayload(BaseModel):
    """Generic webhook payload — channels parse specifics themselves."""

    event: str | None = None
    payload: dict[str, Any] = Field(default_factory=dict)


class HealthResponse(BaseModel):
    """Basic health check response."""

    status: str = "ok"
    version: str = __version__


class ErrorResponse(BaseModel):
    """Standard error response body."""

    error: str
    message: str = ""


# ── New /api/* schemas ─────────────────────────────────────────────────────


class ChatRequest(BaseModel):
    """Request for /api/chat and /api/chat/stream."""

    prompt: str
    session_id: str | None = None


class ChatResponse(BaseModel):
    """Response from /api/chat."""

    response: str
    session_id: str


class ToolInfo(BaseModel):
    """Tool metadata for /api/tools."""

    name: str
    description: str
    risk_level: str
    approval: str


class HealthDetailResponse(BaseModel):
    """Detailed health for /api/health."""

    status: str
    version: str = __version__
    estop: dict[str, Any] = Field(default_factory=dict)
    bus: dict[str, Any] = Field(default_factory=dict)


class EStopRequest(BaseModel):
    """Request for /api/estop."""

    reason: str


class EStopResetRequest(BaseModel):
    """Request for /api/reset."""

    actor: str = "api"


# ── Gateway Server ─────────────────────────────────────────────────────────


class GatewayServer:
    """
    FastAPI-based HTTP API gateway for WorkPilot.

    Wraps the Runtime to expose an HTTP API with:
    - Legacy endpoints: /health, /v1/chat/completions, /webhooks/*
    - New API endpoints: /api/chat, /api/chat/stream, /api/ws,
      /api/sessions, /api/tools, /api/health, /api/estop, /api/reset
    """

    def __init__(self, config: GatewayConfig, runtime: Runtime) -> None:
        self._config = config
        self._runtime = runtime
        self._rate_limiter = RateLimiter(config.rate_limit_per_minute)
        self._web_channel: WebChannel | None = None
        self._server: Any = None  # uvicorn.Server instance

        self._app = self._create_app()

    def set_web_channel(self, channel: WebChannel) -> None:
        """Inject the WebChannel after construction (called by Runtime)."""
        self._web_channel = channel

    # ── App factory ──────────────────────────────────────────────────────

    def _create_app(self) -> Any:  # noqa: C901
        """Build and return the FastAPI application."""
        try:
            from fastapi import FastAPI, WebSocketDisconnect
            from fastapi.middleware.cors import CORSMiddleware
            from fastapi.responses import HTMLResponse, JSONResponse, Response, StreamingResponse
        except ImportError as exc:
            raise ImportError(
                "FastAPI is required for the gateway server. "
                "Install it with: pip install fastapi uvicorn"
            ) from exc

        app = FastAPI(
            title="WorkPilot Gateway",
            version=__version__,
            docs_url="/docs",
            redoc_url=None,
        )

        # ── Middleware (outermost first) ─────────────────────────────────
        # FastAPI executes middleware in reverse add order:
        # Auth (innermost) → E-stop → RequestLogger → CORS (outermost)

        # CORS
        app.add_middleware(
            CORSMiddleware,
            allow_origins=self._config.cors_origins,
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

        # Request logging
        app.add_middleware(RequestLogger)

        # E-stop gate (returns 503 for /api/* when halted)
        app.add_middleware(EStopMiddleware, estop=self._runtime.estop)

        # Auth (skips /health and /api/health)
        app.add_middleware(AuthMiddleware, config=self._config)

        # ── Helper ───────────────────────────────────────────────────────

        def _get_client_ip(request: Request) -> str:
            return request.client.host if request.client else "unknown"

        def _check_rate_limit(request: Request) -> JSONResponse | None:
            """Return a 429 JSONResponse if rate-limited, else None."""
            if not self._rate_limiter.check(_get_client_ip(request)):
                return JSONResponse(
                    status_code=429,
                    content=ErrorResponse(
                        error="rate_limit_exceeded",
                        message="Too many requests. Please try again later.",
                    ).model_dump(),
                )
            return None

        def _require_web_channel() -> JSONResponse | None:
            """Return a 503 JSONResponse if WebChannel is not available."""
            if self._web_channel is None:
                return JSONResponse(
                    status_code=503,
                    content=ErrorResponse(
                        error="service_unavailable",
                        message="Web channel not initialized.",
                    ).model_dump(),
                )
            return None

        # ── Web UI ────────────────────────────────────────────────────────

        # Cache both pages at startup
        _static = Path(__file__).parent / "static"

        _status_html: str | None = None
        _status_path = _static / "status.html"
        if _status_path.exists():
            _status_html = _status_path.read_text(encoding="utf-8")

        _chat_html: str | None = None
        _chat_path = _static / "chat.html"
        if _chat_path.exists():
            _chat_html = _chat_path.read_text(encoding="utf-8")

        _favicon_svg: str | None = None
        _favicon_path = _static / "favicon.svg"
        if _favicon_path.exists():
            _favicon_svg = _favicon_path.read_text(encoding="utf-8")

        # Track server start time for uptime calculation
        _started_at: datetime = datetime.now(UTC)

        @app.get("/", response_class=HTMLResponse)
        async def ui_index() -> HTMLResponse:
            """Status dashboard — system overview at a glance."""
            if _status_html is None:
                return HTMLResponse(
                    "<h1>WorkPilot</h1><p>Status dashboard not found.</p>", status_code=404
                )
            return HTMLResponse(_status_html)

        @app.get("/chat", response_class=HTMLResponse)
        @app.get("/chat.html", response_class=HTMLResponse)
        async def ui_chat() -> HTMLResponse:
            """Chat UI — moved from / to /chat."""
            if _chat_html is None:
                return HTMLResponse(
                    "<h1>WorkPilot Chat</h1><p>Chat UI not found.</p>", status_code=404
                )
            return HTMLResponse(_chat_html)

        @app.get("/auth/spa-callback", response_class=HTMLResponse)
        async def spa_callback() -> HTMLResponse:
            """Blank page for MSAL.js popup/redirect callback."""
            return HTMLResponse(
                "<!DOCTYPE html><html><head><title>Auth</title></head><body></body></html>",
                headers={"Cache-Control": "no-store"},
            )

        @app.get("/favicon.svg")
        async def favicon() -> Response:
            """Serve the WorkPilot SVG favicon."""
            if _favicon_svg is None:
                return Response(status_code=404)
            return Response(
                content=_favicon_svg,
                media_type="image/svg+xml",
                headers={"Cache-Control": "public, max-age=86400"},
            )

        # ── Legacy routes (backward compat) ──────────────────────────────

        @app.get("/health", response_model=HealthResponse)
        async def health() -> HealthResponse:
            return HealthResponse()

        @app.post("/v1/chat/completions", response_model=ChatCompletionResponse)
        async def chat_completions(
            body: ChatCompletionRequest,
            request: Request,
        ) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp

            if body.stream:
                return JSONResponse(
                    status_code=400,
                    content=ErrorResponse(
                        error="unsupported",
                        message="Streaming is not yet supported on this endpoint. Use /api/chat/stream.",
                    ).model_dump(),
                )

            user_messages = [m for m in body.messages if m.role == "user"]
            if not user_messages:
                return JSONResponse(
                    status_code=400,
                    content=ErrorResponse(
                        error="bad_request",
                        message="At least one user message is required.",
                    ).model_dump(),
                )

            prompt = user_messages[-1].content

            try:
                response_text = await self._runtime.run_prompt(prompt)
            except Exception as exc:
                logger.error(f"Chat completion error: {exc}")
                return JSONResponse(
                    status_code=500,
                    content=ErrorResponse(
                        error="internal_error",
                        message="An internal error occurred while processing the request.",
                    ).model_dump(),
                )

            result = ChatCompletionResponse(
                model=body.model or "workpilot",
                choices=[
                    ChatChoice(
                        message=ChatChoiceMessage(content=response_text),
                    ),
                ],
            )
            return JSONResponse(status_code=200, content=result.model_dump())

        @app.post("/webhooks/{channel}")
        async def webhook_receiver(
            channel: str,
            body: WebhookPayload,
            request: Request,
        ) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp

            supported = {"github", "ado", "teams", "outlook"}
            if channel not in supported:
                return JSONResponse(
                    status_code=404,
                    content=ErrorResponse(
                        error="not_found",
                        message=f"Unknown channel: {channel}. Supported: {', '.join(sorted(supported))}",
                    ).model_dump(),
                )

            logger.info(f"Webhook received: channel={channel}, event={body.event}")

            try:
                from workpilot.bus.events import InboundMessage

                msg = InboundMessage(
                    channel=channel,
                    channel_id=f"webhook-{channel}",
                    sender_id="webhook",
                    sender_name="webhook",
                    content=f"[webhook:{channel}] event={body.event}",
                    metadata={"webhook_event": body.event or "", **body.payload},
                )
                await self._runtime.bus.publish_inbound(msg)
            except Exception as exc:
                logger.error(f"Webhook processing error ({channel}): {exc}")
                return JSONResponse(
                    status_code=500,
                    content=ErrorResponse(
                        error="internal_error",
                        message="Failed to process webhook.",
                    ).model_dump(),
                )

            return JSONResponse(
                status_code=200,
                content={"status": "accepted", "channel": channel},
            )

        # ── New /api/* routes ────────────────────────────────────────────

        @app.get("/api/auth/config")
        async def auth_config() -> JSONResponse:
            entra_tid = self._config.entra_tenant_id
            entra_cid = self._config.entra_client_id
            return JSONResponse(
                content={
                    "entra_enabled": bool(entra_tid and entra_cid),
                    "entra_tenant_id": entra_tid,
                    "entra_client_id": entra_cid,
                    "api_key_enabled": self._config.api_key is not None,
                }
            )

        # ── Device code flow (no redirect URI needed) ────────────────────
        # Stores pending device code flows keyed by user_code
        _device_flows: dict[str, Any] = {}
        _device_msal_apps: dict[str, Any] = {}

        @app.post("/api/auth/device-code")
        async def device_code_start() -> JSONResponse:
            entra_tid = self._config.entra_tenant_id
            entra_cid = self._config.entra_client_id
            if not entra_tid or not entra_cid:
                return JSONResponse(
                    status_code=400,
                    content={
                        "error": "entra_not_configured",
                        "message": "Entra ID is not configured on this gateway.",
                    },
                )

            try:
                import msal as _msal

                app = _msal.PublicClientApplication(
                    client_id=entra_cid,
                    authority=f"https://login.microsoftonline.com/{entra_tid}",
                )
                flow = app.initiate_device_flow(scopes=[f"{entra_cid}/.default"])
                if "user_code" not in flow:
                    return JSONResponse(
                        status_code=500,
                        content={
                            "error": "device_flow_failed",
                            "message": flow.get(
                                "error_description", "Failed to initiate device code flow"
                            ),
                        },
                    )

                user_code = flow["user_code"]
                _device_flows[user_code] = flow
                _device_msal_apps[user_code] = app

                return JSONResponse(
                    content={
                        "user_code": user_code,
                        "verification_uri": flow.get(
                            "verification_uri", "https://microsoft.com/devicelogin"
                        ),
                        "expires_in": flow.get("expires_in", 900),
                        "message": flow.get("message", ""),
                    }
                )
            except ImportError:
                return JSONResponse(
                    status_code=500,
                    content={
                        "error": "msal_not_installed",
                        "message": "MSAL library is not installed on the server.",
                    },
                )
            except Exception as exc:
                logger.error(f"Device code initiation error: {exc}")
                return JSONResponse(
                    status_code=500,
                    content={
                        "error": "internal_error",
                        "message": "Failed to start device code flow.",
                    },
                )

        @app.post("/api/auth/device-code/poll")
        async def device_code_poll(request: Request) -> JSONResponse:
            body = await request.json()
            user_code = body.get("user_code", "")

            flow = _device_flows.get(user_code)
            msal_app = _device_msal_apps.get(user_code)
            if not flow or not msal_app:
                return JSONResponse(
                    status_code=404,
                    content={
                        "error": "flow_not_found",
                        "message": "No pending device code flow for this code.",
                    },
                )

            try:
                result = await asyncio.to_thread(
                    msal_app.acquire_token_by_device_flow,
                    flow,
                    exit_condition=lambda flow: True,  # Return immediately after one poll
                )

                if "access_token" in result:
                    # Success — clean up
                    _device_flows.pop(user_code, None)
                    _device_msal_apps.pop(user_code, None)
                    return JSONResponse(
                        content={
                            "status": "complete",
                            "access_token": result["access_token"],
                            "account": {
                                "name": result.get("id_token_claims", {}).get("name", ""),
                                "username": result.get("id_token_claims", {}).get(
                                    "preferred_username", ""
                                ),
                            },
                        }
                    )
                elif result.get("error") == "authorization_pending":
                    return JSONResponse(content={"status": "pending"})
                else:
                    # Error — clean up
                    _device_flows.pop(user_code, None)
                    _device_msal_apps.pop(user_code, None)
                    return JSONResponse(
                        status_code=400,
                        content={
                            "status": "error",
                            "error": result.get("error", "unknown"),
                            "message": result.get("error_description", "Authentication failed."),
                        },
                    )
            except Exception as exc:
                logger.error(f"Device code poll error: {exc}")
                return JSONResponse(content={"status": "pending"})

        @app.get("/api/health", response_model=HealthDetailResponse)
        async def api_health() -> JSONResponse:
            estop_status = self._runtime.estop.status()
            bus = self._runtime.bus
            return JSONResponse(
                content=HealthDetailResponse(
                    status="halted" if self._runtime.estop.is_halted else "ok",
                    estop=estop_status,
                    bus={
                        "inbound_qsize": bus.inbound_qsize,
                        "outbound_qsize": bus.outbound_qsize,
                    },
                ).model_dump(),
            )

        @app.get("/api/status")
        async def api_status() -> JSONResponse:
            """Comprehensive runtime snapshot — polled by the status dashboard."""
            rt = self._runtime
            uptime = int((datetime.now(UTC) - _started_at).total_seconds())

            # Tools breakdown by risk level
            tools = rt.tool_registry.list_tools()
            by_risk: dict[str, int] = {"low": 0, "medium": 0, "high": 0, "critical": 0}
            for t in tools:
                risk = (
                    str(getattr(t.metadata, "risk_level", "low")).lower() if t.metadata else "low"
                )
                by_risk[risk] = by_risk.get(risk, 0) + 1

            # Session count (best-effort)
            try:
                session_count = len(rt.session_manager.list_sessions())
            except Exception:
                session_count = 0

            # Active channels with optional navigation URLs.
            # "cloud" expands into separate Web Chat and Teams entries.
            _cloud_chan = rt.channel_manager.get("cloud")
            cloud_connected = getattr(_cloud_chan, "is_connected", False)
            cloud_cfg = rt.config.channels.cloud

            def _channel_entries(name: str) -> list[dict]:
                if name == "cloud":
                    return []  # handled separately below
                if name in ("web", "gateway"):
                    return [{"name": name, "url": "/chat", "connected": True}]
                return [{"name": name, "url": None, "connected": True}]

            channels = [e for n in rt.channel_manager._channels for e in _channel_entries(n)]

            # Always append cloud chips when cloud is configured (url set),
            # showing as grayed-out when the WebSocket is not connected.
            if cloud_cfg.enabled and cloud_cfg.url:
                try:
                    webchat_url: str | None = webchat_url_from_connect(cloud_cfg.url)
                except ValueError:
                    webchat_url = None
                channels.append(
                    {
                        "name": "Web Chat (Cloud)",
                        "url": webchat_url,
                        "connected": cloud_connected,
                    }
                )
                teams_url = cloud_cfg.teams_app_url or None
                channels.append(
                    {
                        "name": "Teams (Cloud)",
                        "url": teams_url,
                        # Only "connected" (blue) when cloud WebSocket is up AND url is set
                        "connected": cloud_connected and bool(teams_url),
                    }
                )

            return JSONResponse(
                {
                    "version": rt.config.version,
                    "uptime_seconds": uptime,
                    "started_at": _started_at.isoformat(),
                    "status": "halted" if rt.estop.is_halted else "ok",
                    "estop": rt.estop.status(),
                    "bus": {
                        "inbound_qsize": rt.bus.inbound_qsize,
                        "outbound_qsize": rt.bus.outbound_qsize,
                    },
                    "provider": {"model": rt.config.agents.default.model},
                    "channels": channels,
                    "sessions": {"count": session_count},
                    "tools": {"count": len(tools), "by_risk": by_risk},
                    "scheduler": {"enabled": rt.scheduler is not None},
                    "workspace": str(rt.workspace),
                }
            )

        @app.post("/api/chat", response_model=ChatResponse)
        async def api_chat(body: ChatRequest, request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp

            channel_check = _require_web_channel()
            if channel_check:
                return channel_check

            assert self._web_channel is not None  # guarded above
            channel_id = self._web_channel.make_channel_id("web-req")
            sender_id = "api-user"
            timeout = self._config.request_timeout

            try:
                response_text = await self._web_channel.submit_and_wait(
                    channel_id=channel_id,
                    sender_id=sender_id,
                    content=body.prompt,
                    timeout=timeout,
                )
            except TimeoutError:
                return JSONResponse(
                    status_code=504,
                    content=ErrorResponse(
                        error="timeout",
                        message=f"Agent did not respond within {timeout} seconds.",
                    ).model_dump(),
                )
            except Exception as exc:
                logger.error(f"API chat error: {exc}")
                return JSONResponse(
                    status_code=500,
                    content=ErrorResponse(
                        error="internal_error",
                        message="An internal error occurred while processing the request.",
                    ).model_dump(),
                )

            session_id = body.session_id or self._runtime.session_manager.get_or_create_id(
                "web", sender_id
            )
            return JSONResponse(
                content=ChatResponse(
                    response=response_text,
                    session_id=session_id,
                ).model_dump(),
            )

        @app.post("/api/chat/stream")
        async def api_chat_stream(
            body: ChatRequest, request: Request
        ) -> StreamingResponse | JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp

            channel_check = _require_web_channel()
            if channel_check:
                return channel_check

            assert self._web_channel is not None
            channel_id = self._web_channel.make_channel_id("web-sse")
            sender_id = "api-user"
            timeout = self._config.request_timeout

            # Register response queue — SSE yields the final response as events
            response_queue = self._web_channel.register_request(channel_id)

            # Publish message through the bus
            await self._web_channel._handle_message(
                channel_id=channel_id,
                sender_id=sender_id,
                sender_name=sender_id,
                content=body.prompt,
            )

            async def event_generator():
                try:
                    result = await asyncio.wait_for(response_queue.get(), timeout=timeout)
                    if result is not None:
                        yield f"event: message\ndata: {json.dumps({'content': result, 'done': False})}\n\n"
                    yield f"event: done\ndata: {json.dumps({'done': True})}\n\n"
                except TimeoutError:
                    yield f"event: error\ndata: {json.dumps({'error': 'timeout'})}\n\n"
                except Exception as exc:
                    logger.error(f"SSE stream error: {exc}")
                    yield f"event: error\ndata: {json.dumps({'error': 'internal_error'})}\n\n"
                finally:
                    self._web_channel.unregister_request(channel_id)  # type: ignore[union-attr]

            return StreamingResponse(
                event_generator(),
                media_type="text/event-stream",
                headers={
                    "Cache-Control": "no-cache",
                    "Connection": "keep-alive",
                    "X-Accel-Buffering": "no",
                },
            )

        @app.websocket("/api/ws")
        async def websocket_endpoint(websocket: WebSocket) -> None:
            await websocket.accept()

            channel_check = _require_web_channel()
            if channel_check:
                await websocket.close(code=1011, reason="Web channel not initialized")
                return

            assert self._web_channel is not None
            channel_id = self._web_channel.make_channel_id("web-ws")
            response_queue = self._web_channel.register_request(channel_id)
            push_queue = self._web_channel.register_push(channel_id)
            timeout = self._config.request_timeout

            async def _push_loop() -> None:
                """Forward push notifications (scheduler/background) to WebSocket."""
                while True:
                    msg = await push_queue.get()
                    if msg is None:
                        break
                    try:
                        await websocket.send_json({"type": "push", "content": msg})
                    except Exception:
                        break

            push_task = asyncio.create_task(_push_loop())

            try:
                while True:
                    data = await websocket.receive_json()
                    prompt = data.get("prompt", "")
                    sender_id = data.get("sender_id", "ws-user")

                    if not prompt:
                        await websocket.send_json({"error": "prompt is required"})
                        continue

                    # Submit through the bus
                    await self._web_channel._handle_message(
                        channel_id=channel_id,
                        sender_id=sender_id,
                        sender_name=sender_id,
                        content=prompt,
                    )

                    # Wait for response
                    try:
                        response = await asyncio.wait_for(response_queue.get(), timeout=timeout)
                        await websocket.send_json({"response": response})
                    except TimeoutError:
                        await websocket.send_json({"error": "timeout"})
            except WebSocketDisconnect:
                logger.debug(f"WebSocket disconnected: {channel_id}")
            except Exception as exc:
                logger.error(f"WebSocket error: {exc}")
            finally:
                push_task.cancel()
                try:
                    await push_task
                except asyncio.CancelledError:
                    pass
                self._web_channel.unregister_push(channel_id)  # type: ignore[union-attr]
                self._web_channel.unregister_request(channel_id)  # type: ignore[union-attr]

        @app.get("/api/sessions")
        async def list_sessions(request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp

            sessions = self._runtime.session_manager.list_sessions()
            return JSONResponse(content=sessions)

        @app.get("/api/sessions/{session_id:path}")
        async def get_session(session_id: str, request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp

            messages = self._runtime.session_manager.get_messages(session_id)
            if not messages:
                return JSONResponse(
                    status_code=404,
                    content=ErrorResponse(
                        error="not_found",
                        message=f"Session not found: {session_id}",
                    ).model_dump(),
                )
            return JSONResponse(content={"session_id": session_id, "messages": messages})

        @app.delete("/api/sessions/{session_id:path}")
        async def delete_session(session_id: str, request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp

            self._runtime.session_manager.clear(session_id)
            return JSONResponse(content={"status": "deleted", "session_id": session_id})

        @app.get("/api/tools")
        async def list_tools(request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp

            tools = self._runtime.tool_registry.list_tools()
            tool_list = [
                ToolInfo(
                    name=t.name,
                    description=t.description,
                    risk_level=t.metadata.risk_level,
                    approval=t.metadata.approval,
                ).model_dump()
                for t in tools
            ]
            return JSONResponse(content=tool_list)

        @app.post("/api/estop")
        async def trigger_estop(body: EStopRequest, request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp

            self._runtime.estop.trigger(body.reason, actor="api")
            return JSONResponse(content=self._runtime.estop.status())

        @app.post("/api/reset")
        async def reset_estop(body: EStopResetRequest, request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp

            self._runtime.estop.reset(actor=body.actor)
            return JSONResponse(content=self._runtime.estop.status())

        return app

    # ── Lifecycle ────────────────────────────────────────────────────────

    async def start(self) -> None:
        """Start the gateway server using uvicorn."""
        try:
            import uvicorn
        except ImportError as exc:
            raise ImportError(
                "uvicorn is required for the gateway server. Install it with: pip install uvicorn"
            ) from exc

        config = uvicorn.Config(
            app=self._app,
            host=self._config.host,
            port=self._config.port,
            log_level="info",
        )
        self._server = uvicorn.Server(config)

        logger.info(f"Gateway server starting on http://{self._config.host}:{self._config.port}")
        await self._server.serve()

    async def stop(self) -> None:
        """Gracefully shut down the gateway server."""
        if self._server is not None:
            logger.info("Gateway server shutting down")
            self._server.should_exit = True
            self._server = None

    @property
    def app(self) -> Any:
        """Return the underlying FastAPI app (for testing or ASGI mounting)."""
        return self._app
