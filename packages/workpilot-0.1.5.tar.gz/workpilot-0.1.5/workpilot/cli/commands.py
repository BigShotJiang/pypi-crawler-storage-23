"""
CLI commands — Typer-based entry points for WorkPilot.

Top-level commands:
  workpilot agent                  — interactive agent REPL
  workpilot gateway                — start multi-channel gateway server
  workpilot run "<prompt>"         — one-shot agent execution
  workpilot onboard               — interactive project setup
  workpilot status                 — runtime status overview
  workpilot doctor                 — health diagnostics
  workpilot logs                   — show recent log output
  workpilot version                — print version string

Sub-apps (grouped):
  workpilot agents   list | add
  workpilot graph    login | status | test
  workpilot tools    list
  workpilot mcp      list | add | remove
  workpilot sessions list | show
  workpilot security audit | credentials | roles
  workpilot skills   list
  workpilot cron     list | add
"""

from __future__ import annotations

import asyncio
import os
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from workpilot import __version__
from workpilot.config.loader import load_config
from workpilot.config.schema import AppConfig
from workpilot.runtime import Runtime

# ── Console ─────────────────────────────────────────────────────────────────

console = Console()

# ── Helpers ─────────────────────────────────────────────────────────────────


def _get_runtime(
    config_path: str = ".",
    profile: str | None = None,
) -> Runtime:
    """Load config and construct a Runtime instance."""
    config = load_config(config_path, profile)
    return Runtime(config)


def _load_config_safe(
    config_path: str = ".",
    profile: str | None = None,
) -> AppConfig:
    """Load and validate configuration, exiting on failure."""
    try:
        return load_config(config_path, profile)
    except Exception as exc:
        console.print(f"[red]Config error:[/red] {exc}")
        raise typer.Exit(1)


# ── Sub-apps ────────────────────────────────────────────────────────────────

agents_app = typer.Typer(name="agents", help="Manage configured agents")
graph_app = typer.Typer(name="graph", help="Microsoft Graph authentication")
tools_app = typer.Typer(name="tools", help="Tool management")
mcp_app = typer.Typer(name="mcp", help="MCP server management")
sessions_app = typer.Typer(name="sessions", help="Session management")
security_app = typer.Typer(name="security", help="Security and compliance")
skills_app = typer.Typer(name="skills", help="Skill management")
cron_app = typer.Typer(name="cron", help="Cron job management")

# ── Main app ────────────────────────────────────────────────────────────────

app = typer.Typer(
    name="workpilot",
    help="WorkPilot — enterprise-grade AI coding assistant",
    add_completion=False,
    no_args_is_help=True,
)
app.add_typer(agents_app, name="agents")
app.add_typer(graph_app, name="graph")
app.add_typer(tools_app, name="tools")
app.add_typer(mcp_app, name="mcp")
app.add_typer(sessions_app, name="sessions")
app.add_typer(security_app, name="security")
app.add_typer(skills_app, name="skills")
app.add_typer(cron_app, name="cron")


# ═══════════════════════════════════════════════════════════════════════════
# Top-level commands
# ═══════════════════════════════════════════════════════════════════════════


@app.command()
def agent(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    profile: str | None = typer.Option(None, "--profile", "-p", help="Config profile"),
) -> None:
    """Start an interactive agent REPL session."""
    try:
        rt = _get_runtime(config, profile)
        asyncio.run(rt.run_chat())
    except KeyboardInterrupt:
        console.print("\nGoodbye!")
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(1)


@app.command()
def gateway(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    profile: str | None = typer.Option(None, "--profile", "-p", help="Config profile"),
    host: str | None = typer.Option(None, "--host", help="Override bind host"),
    port: int | None = typer.Option(None, "--port", help="Override bind port"),
) -> None:
    """Start the multi-channel gateway server (FastAPI + uvicorn)."""
    try:
        from workpilot.gateway.server import GatewayServer  # noqa: F401
    except ImportError:
        console.print(
            "[red]Error:[/red] FastAPI and uvicorn are required for the gateway.\n"
            "  Install with: [bold]pip install fastapi uvicorn[/bold]"
        )
        raise typer.Exit(1)

    cfg = _load_config_safe(config, profile)
    gateway_cfg = cfg.gateway

    # Allow CLI overrides for host / port
    if host is not None:
        gateway_cfg.host = host
    if port is not None:
        gateway_cfg.port = port

    rt = Runtime(cfg)

    console.print(
        Panel(
            f"[bold]WorkPilot Gateway[/bold]  v{__version__}\n"
            f"Listening on [cyan]http://{gateway_cfg.host}:{gateway_cfg.port}[/cyan]\n\n"
            f"  GET  /                     — web chat UI\n"
            f"  GET  /health               — health check\n"
            f"  GET  /docs                 — API docs (Swagger)\n"
            f"  POST /api/chat             — send prompt\n"
            f"  POST /api/chat/stream      — SSE streaming\n"
            f"  WS   /api/ws               — WebSocket chat\n"
            f"  GET  /api/sessions          — list sessions\n"
            f"  GET  /api/tools             — list tools\n"
            f"  GET  /api/health            — detailed health\n"
            f"  POST /api/estop             — emergency stop\n"
            f"  POST /api/reset             — reset E-stop\n"
            f"  POST /v1/chat/completions  — OpenAI-compatible\n"
            f"  POST /webhooks/:channel    — channel webhooks",
            title="Gateway",
            border_style="green",
        )
    )

    try:
        asyncio.run(rt.run_gateway())
    except KeyboardInterrupt:
        console.print("\nShutting down gateway...")


@app.command()
def cloud(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    profile: str | None = typer.Option(None, "--profile", "-p", help="Config profile"),
    url: str | None = typer.Option(None, "--url", help="Override Cloud Gateway WSS URL"),
    scope: str | None = typer.Option(None, "--scope", help="Override Entra ID scope"),
    login_method: str | None = typer.Option(
        None,
        "--login",
        help="Login method: auto (default), browser (PKCE popup), device (code at URL)",
    ),
) -> None:
    """Connect to WorkPilot Cloud Gateway (remote relay mode).

    Authenticates with Entra ID, then maintains a persistent WebSocket to
    the Cloud Gateway. Messages from Teams and Web Chat are relayed to the
    local agent; responses are sent back.

    Login methods:
      auto    — try browser popup, fall back to device code (default)
      browser — open browser for PKCE sign-in (http://localhost callback)
      device  — device code flow (URL + code; works without a browser)
    """
    cfg = _load_config_safe(config, profile)
    cloud_cfg = cfg.channels.cloud

    # Apply CLI overrides
    if url:
        cloud_cfg.url = url
    if scope:
        cloud_cfg.scope = scope
    if login_method:
        cloud_cfg.login_method = login_method  # type: ignore[assignment]

    method_label = {
        "auto": "browser -> device code fallback",
        "browser": "browser popup (PKCE)",
        "device": "device code (URL + code)",
    }.get(cloud_cfg.login_method, cloud_cfg.login_method)

    console.print(
        Panel(
            f"[bold]WorkPilot Cloud[/bold]  v{__version__}\n\n"
            f"Gateway : [cyan]{cloud_cfg.url}[/cyan]\n"
            f"Tenant  : [dim]{cloud_cfg.tenant_id}[/dim]\n"
            f"Client  : [dim]{cloud_cfg.client_id}[/dim]\n"
            f"Login   : [yellow]{method_label}[/yellow]\n\n"
            f"Sign in with your Entra ID account to continue.\n"
            f"Press [bold]Ctrl+C[/bold] to disconnect.",
            title="Cloud Gateway",
            border_style="blue",
        )
    )

    try:
        asyncio.run(_run_cloud(cfg, cloud_cfg))
    except KeyboardInterrupt:
        console.print("\n[yellow]Disconnected from Cloud Gateway.[/yellow]")
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(1)


async def _run_cloud(cfg: AppConfig, cloud_cfg: Any) -> None:
    """Async entry point: wire up the cloud channel and run the agent loop."""
    from workpilot.channels.cloud import CloudChannel

    rt = Runtime(cfg)
    ch = CloudChannel(
        rt.bus,
        url=cloud_cfg.url,
        tenant_id=cloud_cfg.tenant_id,
        client_id=cloud_cfg.client_id,
        scope=cloud_cfg.scope,
        login_method=cloud_cfg.login_method,
        login_port=cloud_cfg.login_port or cfg.gateway.port,
        allow_from=cloud_cfg.allow_from or None,
        auto_reconnect=cloud_cfg.auto_reconnect,
        reconnect_max=cloud_cfg.reconnect_max,
        bypass_token=cloud_cfg.bypass_token,
        open_browser_on_connect=True,
    )
    rt.channel_manager.add(ch)
    await ch.start()
    # Keep the agent loop running — messages arrive via the cloud channel
    await rt.run_cloud()


@app.command()
def run(
    prompt: str = typer.Argument(..., help="The prompt to send to the agent"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    profile: str | None = typer.Option(None, "--profile", "-p", help="Config profile"),
    session_id: str | None = typer.Option(None, "--session", "-s", help="Resume a session"),
) -> None:
    """Run an agent with a one-shot prompt."""
    try:
        rt = _get_runtime(config, profile)
        response = asyncio.run(rt.run_prompt(prompt, session_id))
        console.print(response)
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(1)


@app.command()
def onboard(
    directory: str = typer.Option(".", "--dir", "-d", help="Target directory"),
    name: str = typer.Option("my-workpilot-project", "--name", help="Project name"),
) -> None:
    """Interactively create a local config override (workpilot.local.yaml)."""
    import yaml

    dir_path = Path(directory).resolve()
    dir_path.mkdir(parents=True, exist_ok=True)

    local_path = dir_path / "workpilot.local.yaml"
    if local_path.exists():
        console.print(f"[red]Local config already exists:[/red] {local_path}")
        raise typer.Exit(1)

    # Warn if no base config
    base_path = dir_path / "workpilot.yaml"
    if not base_path.exists():
        console.print(
            "[yellow]Warning:[/yellow] No workpilot.yaml found in this directory.\n"
            "  The base config (workpilot.yaml) should be committed with your project.\n"
            "  The local override will still be created.\n"
        )

    console.print(
        Panel(
            "[bold]Welcome to WorkPilot![/bold]\n\n"
            "This wizard creates your local config override (workpilot.local.yaml).\n"
            "Use it to set API keys, model preferences, and local settings.\n"
            "This file is gitignored and never committed.",
            title="Onboard",
            border_style="blue",
        )
    )

    # GitHub sign-in (auto-configures Copilot)
    github_token: str | None = None
    sign_in_github: bool = typer.confirm(
        "Sign in with GitHub? (auto-configures Copilot)",
        default=True,
    )
    if sign_in_github:
        from workpilot.security.github_auth import GitHubAuthError, github_device_login

        try:
            github_token = github_device_login(console=console)
        except (GitHubAuthError, Exception) as exc:
            console.print(f"[yellow]GitHub sign-in failed:[/yellow] {exc}")
            console.print("  You can set the token in workpilot.local.yaml later.\n")

    # Interactive prompts
    model: str = typer.prompt(
        "Default model (auto = pick best available)",
        default="auto",
    )
    security_profile: str = typer.prompt(
        "Security profile (open/standard/controlled/restricted)",
        default="standard",
    )
    enable_gateway: bool = typer.confirm("Enable HTTP gateway?", default=False)

    local_config: dict = {
        "providers": {
            "github_copilot": {"token": github_token or "${GITHUB_TOKEN}"},
        },
        "agents": {
            "default": {
                "model": model,
            },
        },
        "security": {
            "profile": security_profile,
        },
        "logging": {"level": "DEBUG", "format": "pretty"},
    }

    if enable_gateway:
        import secrets

        api_key = f"wp-{secrets.token_urlsafe(32)}"
        local_config["gateway"] = {
            "enabled": True,
            "host": "localhost",
            "port": 3003,
            "api_key": api_key,
        }

    header = (
        "# WorkPilot local config override\n"
        "# This file is gitignored — use it for API keys, model preferences,\n"
        "# and local settings that should not be committed.\n"
        "# Values here are deep-merged on top of workpilot.yaml.\n"
        "\n"
    )
    local_path.write_text(
        header + yaml.dump(local_config, default_flow_style=False, sort_keys=False),
        encoding="utf-8",
    )
    console.print(f"[green]Created:[/green] {local_path}")

    if github_token:
        console.print("[green]GitHub token saved to workpilot.local.yaml[/green]")

    next_steps = (
        "[bold]Next steps:[/bold]\n"
        "  1. Edit workpilot.local.yaml for local preferences\n"
        "  2. Run: [cyan]workpilot agent[/cyan]  (interactive REPL)\n"
        "  3. Run: [cyan]workpilot doctor[/cyan] (verify setup)"
    )
    if not github_token:
        next_steps = (
            "[bold]Next steps:[/bold]\n"
            "  1. Copy .env.example to .env and add your API keys\n"
            "  2. Edit workpilot.local.yaml for local preferences\n"
            "  3. Run: [cyan]workpilot agent[/cyan]  (interactive REPL)\n"
            "  4. Run: [cyan]workpilot doctor[/cyan] (verify setup)"
        )
    console.print(Panel(next_steps, border_style="green"))


@app.command()
def status(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    profile: str | None = typer.Option(None, "--profile", "-p", help="Config profile"),
) -> None:
    """Show runtime configuration status."""
    cfg = _load_config_safe(config, profile)

    console.print(
        Panel(
            f"[bold]{cfg.name}[/bold]  v{cfg.version}\n"
            f"Security profile: [cyan]{cfg.security.profile.value}[/cyan]  |  "
            f"Entrypoint: [cyan]{cfg.entrypoint}[/cyan]",
            title="WorkPilot Status",
            border_style="blue",
        )
    )

    # Agents table
    agents_table = Table(title="Agents")
    agents_table.add_column("Name", style="bold")
    agents_table.add_column("Model")
    agents_table.add_column("Temp")
    agents_table.add_column("Max Iter")
    agents_table.add_column("Tools")

    entry = cfg.entrypoint
    agents_table.add_row(
        "default" + (" *" if entry == "default" else ""),
        cfg.agents.default.model,
        str(cfg.agents.default.temperature),
        str(cfg.agents.default.max_iterations),
        str(len(cfg.agents.default.tools)),
    )
    for name, ag in cfg.agents.agents.items():
        agents_table.add_row(
            name + (" *" if entry == name else ""),
            ag.model,
            str(ag.temperature),
            str(ag.max_iterations),
            str(len(ag.tools)),
        )
    console.print(agents_table)

    # Channels
    channels_table = Table(title="Channels")
    channels_table.add_column("Channel", style="bold")
    channels_table.add_column("Enabled")
    channels_table.add_row("CLI", "[green]yes[/green]" if cfg.channels.cli.enabled else "no")
    channels_table.add_row("Teams", "[green]yes[/green]" if cfg.channels.teams.enabled else "no")
    channels_table.add_row(
        "Outlook", "[green]yes[/green]" if cfg.channels.outlook.enabled else "no"
    )
    channels_table.add_row("GitHub", "[green]yes[/green]" if cfg.channels.github.enabled else "no")
    channels_table.add_row("ADO", "[green]yes[/green]" if cfg.channels.ado.enabled else "no")
    cloud_cfg = cfg.channels.cloud
    if not cloud_cfg.enabled:
        cloud_status = "no"
    elif not cloud_cfg.url:
        cloud_status = "[yellow]url not set[/yellow]"
    else:
        cloud_status = f"[green]yes[/green]  [dim]{cloud_cfg.url}[/dim]"
    channels_table.add_row("Web Chat (Cloud)", cloud_status)
    if cloud_cfg.enabled and cloud_cfg.teams_app_url:
        channels_table.add_row(
            "Teams (Cloud)", f"[green]yes[/green]  [dim]{cloud_cfg.teams_app_url}[/dim]"
        )
    elif cloud_cfg.enabled:
        channels_table.add_row("Teams (Cloud)", "[yellow]teams_app_url not set[/yellow]")
    console.print(channels_table)

    # Security
    console.print("\n[bold]Security[/bold]")
    console.print(f"  Profile:              {cfg.security.profile.value}")
    console.print(f"  Credentials:          {cfg.security.credential_provider.value}")
    console.print(
        f"  Audit:                {'enabled' if cfg.security.audit.enabled else 'disabled'}"
    )
    console.print(f"  RBAC roles:           {len(cfg.security.roles)}")
    console.print(f"  Workspace restrict:   {cfg.tools.filesystem.restrict_to_workspace}")
    console.print(f"  Shell deny patterns:  {len(cfg.tools.shell.deny_patterns)}")

    # Features
    console.print("\n[bold]Features[/bold]")
    console.print(f"  Graph:    {'[green]enabled[/green]' if cfg.graph.enabled else 'disabled'}")
    console.print(f"  Gateway:  {'[green]enabled[/green]' if cfg.gateway.enabled else 'disabled'}")
    console.print(f"  Cron:     {'[green]enabled[/green]' if cfg.cron.enabled else 'disabled'}")
    console.print(
        f"  Browser:  {'[green]enabled[/green]' if cfg.tools.browser.enabled else 'disabled'}"
    )

    # MCP servers
    mcp_count = len(cfg.tools.mcp_servers)
    console.print(f"  MCP servers: {mcp_count}")
    if mcp_count > 0:
        for name, srv in cfg.tools.mcp_servers.items():
            transport = "stdio" if srv.command else "http"
            console.print(f"    - {name} ({transport})")

    console.print()


@app.command()
def doctor(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    profile: str | None = typer.Option(None, "--profile", "-p", help="Config profile"),
) -> None:
    """Run health diagnostics and report issues."""
    console.print(Panel("[bold]WorkPilot Doctor[/bold]", title="Diagnostics", border_style="blue"))
    issues: list[str] = []
    warnings: list[str] = []

    # 1. Python version
    py_version = sys.version_info
    if py_version >= (3, 11):
        console.print(
            f"  [green]PASS[/green]  Python {py_version.major}.{py_version.minor}.{py_version.micro}"
        )
    else:
        msg = f"Python >= 3.11 required, found {py_version.major}.{py_version.minor}"
        console.print(f"  [red]FAIL[/red]  {msg}")
        issues.append(msg)

    # 2. Config validity
    try:
        cfg = load_config(config, profile)
        console.print("  [green]PASS[/green]  Configuration valid")
    except Exception as exc:
        msg = f"Config error: {exc}"
        console.print(f"  [red]FAIL[/red]  {msg}")
        issues.append(msg)
        # Cannot continue most checks without config
        _doctor_summary(issues, warnings)
        return

    # 3. LLM provider connectivity
    _doctor_check_provider(cfg, issues, warnings)

    # 4. Graph auth
    _doctor_check_graph(cfg, issues, warnings)

    # 5. Required packages
    _doctor_check_packages(cfg, issues, warnings)

    # 6. Tool availability
    _doctor_check_tools(cfg, issues, warnings)

    # 7. Credentials
    _doctor_check_credentials(cfg, issues, warnings)

    _doctor_summary(issues, warnings)


def _doctor_check_provider(cfg: AppConfig, issues: list[str], warnings: list[str]) -> None:
    """Check whether the LLM provider keys are set."""
    anthropic_key = os.environ.get("ANTHROPIC_API_KEY", "")
    openai_key = os.environ.get("OPENAI_API_KEY", "")
    azure_key = os.environ.get("AZURE_OPENAI_API_KEY", "")

    has_key = bool(anthropic_key or openai_key or azure_key)

    # Also check if the config has a non-empty key (after env substitution)
    if cfg.providers.anthropic.api_key:
        val = cfg.providers.anthropic.api_key.get_secret_value()
        if val and val != "your-key-here" and not val.startswith("${"):
            has_key = True

    if has_key:
        console.print("  [green]PASS[/green]  LLM provider API key found")
    else:
        msg = (
            "No LLM API key found (set ANTHROPIC_API_KEY, OPENAI_API_KEY, or AZURE_OPENAI_API_KEY)"
        )
        console.print(f"  [yellow]WARN[/yellow]  {msg}")
        warnings.append(msg)


def _doctor_check_graph(cfg: AppConfig, issues: list[str], warnings: list[str]) -> None:
    """Check Graph configuration if enabled."""
    if not cfg.graph.enabled:
        console.print("  [dim]SKIP[/dim]  Microsoft Graph (disabled)")
        return

    has_client_id = bool(
        cfg.graph.auth.client_id
        and cfg.graph.auth.client_id.get_secret_value()
        and not cfg.graph.auth.client_id.get_secret_value().startswith("${")
    )
    has_tenant = bool(cfg.graph.auth.tenant_id)

    if has_client_id and has_tenant:
        console.print("  [green]PASS[/green]  Microsoft Graph credentials configured")
    else:
        msg = "Graph enabled but client_id or tenant_id missing"
        console.print(f"  [yellow]WARN[/yellow]  {msg}")
        warnings.append(msg)

    try:
        import msal  # noqa: F401

        console.print("  [green]PASS[/green]  msal package installed")
    except ImportError:
        msg = "msal not installed (required for Graph): pip install msal"
        console.print(f"  [yellow]WARN[/yellow]  {msg}")
        warnings.append(msg)


def _doctor_check_packages(cfg: AppConfig, issues: list[str], warnings: list[str]) -> None:
    """Check optional dependency packages."""
    optional_deps: list[tuple[str, str, bool]] = [
        ("fastapi", "gateway server", cfg.gateway.enabled),
        ("uvicorn", "gateway server", cfg.gateway.enabled),
        ("apscheduler", "cron service", cfg.cron.enabled),
        ("playwright", "browser tool", cfg.tools.browser.enabled),
    ]
    for pkg, purpose, needed in optional_deps:
        try:
            __import__(pkg)
            console.print(f"  [green]PASS[/green]  {pkg} installed")
        except ImportError:
            if needed:
                msg = f"{pkg} not installed (required for {purpose}): pip install {pkg}"
                console.print(f"  [red]FAIL[/red]  {msg}")
                issues.append(msg)
            else:
                console.print(f"  [dim]SKIP[/dim]  {pkg} (not needed — {purpose} disabled)")


def _doctor_check_tools(cfg: AppConfig, issues: list[str], warnings: list[str]) -> None:
    """Check that configured tools are known."""
    known_tools = {
        "shell",
        "read_file",
        "write_file",
        "edit_file",
        "list_dir",
        "git",
        "http_request",
        "browser",
        "send_message",
        "spawn_agent",
    }
    agent_tools = set(cfg.agents.default.tools)
    for _name, ag in cfg.agents.agents.items():
        agent_tools.update(ag.tools)

    unknown = agent_tools - known_tools
    if unknown:
        msg = f"Unknown tools referenced in agent config: {', '.join(sorted(unknown))}"
        console.print(f"  [yellow]WARN[/yellow]  {msg}")
        warnings.append(msg)
    else:
        console.print(
            f"  [green]PASS[/green]  All configured tools are valid ({len(agent_tools)} tools)"
        )


def _doctor_check_credentials(cfg: AppConfig, issues: list[str], warnings: list[str]) -> None:
    """Check credential provider setup."""
    provider = cfg.security.credential_provider.value
    console.print(f"  [green]PASS[/green]  Credential provider: {provider}")

    if provider == "azure-keyvault":
        if not cfg.security.azure_keyvault_url:
            msg = "Azure Key Vault URL not configured"
            console.print(f"  [yellow]WARN[/yellow]  {msg}")
            warnings.append(msg)
        else:
            console.print(
                f"  [green]PASS[/green]  Key Vault URL: {cfg.security.azure_keyvault_url}"
            )


def _doctor_summary(issues: list[str], warnings: list[str]) -> None:
    """Print the doctor summary."""
    console.print()
    if not issues and not warnings:
        console.print(Panel("[green]All checks passed![/green]", border_style="green"))
    elif not issues:
        console.print(
            Panel(
                f"[yellow]{len(warnings)} warning(s)[/yellow], 0 errors",
                border_style="yellow",
            )
        )
    else:
        console.print(
            Panel(
                f"[red]{len(issues)} error(s)[/red], [yellow]{len(warnings)} warning(s)[/yellow]",
                border_style="red",
            )
        )


@app.command()
def logs(
    lines: int = typer.Option(50, "--lines", "-n", help="Number of lines to show"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Show recent log output."""
    cfg = _load_config_safe(config)

    log_file = cfg.logging.file
    if not log_file:
        console.print("[yellow]No log file configured.[/yellow]  Logs go to stderr by default.")
        console.print("  Set [bold]logging.file[/bold] in workpilot.yaml to enable file logging.")
        return

    log_path = Path(log_file)
    if not log_path.exists():
        console.print(f"[yellow]Log file not found:[/yellow] {log_path}")
        return

    try:
        all_lines = log_path.read_text(encoding="utf-8").splitlines()
        tail = all_lines[-lines:] if len(all_lines) > lines else all_lines
        for line in tail:
            console.print(line)
    except Exception as exc:
        console.print(f"[red]Error reading log file:[/red] {exc}")
        raise typer.Exit(1)


@app.command()
def version() -> None:
    """Show WorkPilot version."""
    console.print(f"WorkPilot v{__version__}")


# ═══════════════════════════════════════════════════════════════════════════
# agents sub-commands
# ═══════════════════════════════════════════════════════════════════════════


@agents_app.command("list")
def agents_list(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    profile: str | None = typer.Option(None, "--profile", "-p", help="Config profile"),
) -> None:
    """List all configured agents."""
    cfg = _load_config_safe(config, profile)

    table = Table(title="Configured Agents")
    table.add_column("Name", style="bold")
    table.add_column("Model")
    table.add_column("Temp")
    table.add_column("Max Iter")
    table.add_column("Tools")
    table.add_column("Entrypoint")

    entry = cfg.entrypoint
    table.add_row(
        "default",
        cfg.agents.default.model,
        str(cfg.agents.default.temperature),
        str(cfg.agents.default.max_iterations),
        ", ".join(cfg.agents.default.tools),
        "[green]yes[/green]" if entry == "default" else "",
    )
    for name, ag in cfg.agents.agents.items():
        table.add_row(
            name,
            ag.model,
            str(ag.temperature),
            str(ag.max_iterations),
            ", ".join(ag.tools),
            "[green]yes[/green]" if entry == name else "",
        )
    console.print(table)


@agents_app.command("add")
def agents_add(
    name: str = typer.Argument(..., help="Agent name"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Add a new agent interactively (appends to workpilot.yaml)."""
    import yaml

    config_path = Path(config)
    if config_path.is_dir():
        for candidate in ("workpilot.yaml", "workpilot.yml"):
            p = config_path / candidate
            if p.exists():
                config_path = p
                break
        else:
            console.print("[red]No workpilot.yaml found in directory.[/red]")
            raise typer.Exit(1)

    if not config_path.is_file():
        console.print(f"[red]Config file not found:[/red] {config_path}")
        raise typer.Exit(1)

    # Interactive prompts for agent settings
    model: str = typer.prompt("Model", default="auto")
    instructions: str = typer.prompt("Instructions", default="You are a helpful assistant.")
    temperature: float = float(typer.prompt("Temperature", default="0.3"))
    max_iterations: int = int(typer.prompt("Max iterations", default="25"))

    # Load existing YAML, inject the agent, write back
    raw = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    agents_section = raw.setdefault("agents", {})
    agents_section[name] = {
        "model": model,
        "instructions": instructions,
        "temperature": temperature,
        "max_iterations": max_iterations,
        "tools": [
            "shell",
            "read_file",
            "write_file",
            "edit_file",
            "list_dir",
            "git",
            "http_request",
        ],
    }
    config_path.write_text(
        yaml.dump(raw, default_flow_style=False, sort_keys=False),
        encoding="utf-8",
    )
    console.print(f"[green]Agent '{name}' added to {config_path}[/green]")


# ═══════════════════════════════════════════════════════════════════════════
# graph sub-commands
# ═══════════════════════════════════════════════════════════════════════════


@graph_app.command("login")
def graph_login(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    profile: str | None = typer.Option(None, "--profile", "-p", help="Config profile"),
) -> None:
    """Authenticate with Microsoft Graph using device code flow."""
    try:
        from workpilot.graph.auth import GraphAuth
    except ImportError:
        console.print(
            "[red]Error:[/red] Graph auth requires the 'msal' package.\n"
            "  Install with: [bold]pip install msal[/bold]"
        )
        raise typer.Exit(1)

    cfg = _load_config_safe(config, profile)

    if not cfg.graph.enabled:
        console.print("[yellow]Graph integration is disabled in config.[/yellow]")
        console.print("  Set [bold]graph.enabled: true[/bold] in workpilot.yaml")
        raise typer.Exit(1)

    auth = GraphAuth(cfg.graph.auth)

    console.print("[bold]Starting Microsoft Graph device code flow...[/bold]\n")
    console.print("Follow the instructions below to authenticate.\n")

    try:
        token = asyncio.run(auth.get_token())
        console.print("\n[green]Authenticated successfully![/green]")
        console.print(f"  Token preview: {token[:20]}...")
    except Exception as exc:
        console.print(f"\n[red]Authentication failed:[/red] {exc}")
        raise typer.Exit(1)


@graph_app.command("status")
def graph_status(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    profile: str | None = typer.Option(None, "--profile", "-p", help="Config profile"),
) -> None:
    """Show Microsoft Graph authentication status."""
    cfg = _load_config_safe(config, profile)

    table = Table(title="Microsoft Graph Status")
    table.add_column("Setting", style="bold")
    table.add_column("Value")

    table.add_row("Enabled", "[green]yes[/green]" if cfg.graph.enabled else "[red]no[/red]")
    table.add_row("Tenant ID", cfg.graph.auth.tenant_id or "[dim]not set[/dim]")

    client_id = cfg.graph.auth.client_id
    if client_id:
        val = client_id.get_secret_value()
        table.add_row(
            "Client ID",
            f"{val[:8]}..." if val and not val.startswith("${") else "[dim]not set[/dim]",
        )
    else:
        table.add_row("Client ID", "[dim]not set[/dim]")

    table.add_row("Device Code", "[green]yes[/green]" if cfg.graph.auth.use_device_code else "no")
    table.add_row(
        "Managed Identity", "[green]yes[/green]" if cfg.graph.auth.use_managed_identity else "no"
    )
    table.add_row("Scopes", ", ".join(cfg.graph.auth.scopes))

    console.print(table)


@graph_app.command("test")
def graph_test(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    profile: str | None = typer.Option(None, "--profile", "-p", help="Config profile"),
) -> None:
    """Test Microsoft Graph API connection by fetching /me."""
    try:
        from workpilot.graph.auth import GraphAuth
        from workpilot.graph.client import GraphClient
    except ImportError:
        console.print("[red]Error:[/red] msal or httpx not installed.")
        raise typer.Exit(1)

    cfg = _load_config_safe(config, profile)

    if not cfg.graph.enabled:
        console.print("[yellow]Graph integration is disabled.[/yellow]")
        raise typer.Exit(1)

    auth = GraphAuth(cfg.graph.auth)
    client = GraphClient(auth)

    console.print("[bold]Testing Graph API connection...[/bold]")

    try:
        result = asyncio.run(client.get("/me"))
        display_name = result.get("displayName", "unknown")
        email = result.get("mail", result.get("userPrincipalName", "unknown"))
        console.print("\n[green]Connection successful![/green]")
        console.print(f"  Display name: {display_name}")
        console.print(f"  Email:        {email}")
    except Exception as exc:
        console.print(f"\n[red]Connection failed:[/red] {exc}")
        raise typer.Exit(1)


# ═══════════════════════════════════════════════════════════════════════════
# tools sub-commands
# ═══════════════════════════════════════════════════════════════════════════


@tools_app.command("list")
def tools_list(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    profile: str | None = typer.Option(None, "--profile", "-p", help="Config profile"),
) -> None:
    """List all available tools (built-in + MCP)."""
    cfg = _load_config_safe(config, profile)

    table = Table(title="Built-in Tools")
    table.add_column("Tool", style="bold")
    table.add_column("Description")
    table.add_column("Risk")

    # Load risk levels from RBAC module
    try:
        from workpilot.security.rbac import TOOL_CATEGORIES
    except ImportError:
        TOOL_CATEGORIES = {}

    builtin_tools = [
        ("shell", "Execute shell commands"),
        ("read_file", "Read file contents"),
        ("write_file", "Write or create files"),
        ("edit_file", "Edit files with search/replace"),
        ("list_dir", "List directory contents"),
        ("git", "Git operations"),
        ("http_request", "Make HTTP requests"),
        ("browser", "Browser automation (Playwright)"),
        ("send_message", "Send messages via channels"),
        ("spawn_agent", "Spawn sub-agent"),
    ]

    for tool_name, description in builtin_tools:
        risk = TOOL_CATEGORIES.get(tool_name, "medium")
        risk_str = str(risk.value) if hasattr(risk, "value") else str(risk)
        risk_display = {
            "low": "[green]low[/green]",
            "medium": "[yellow]medium[/yellow]",
            "high": "[red]high[/red]",
            "critical": "[bold red]critical[/bold red]",
        }.get(risk_str, risk_str)
        table.add_row(tool_name, description, risk_display)

    console.print(table)

    # MCP tools
    mcp_servers = cfg.tools.mcp_servers
    if mcp_servers:
        mcp_table = Table(title="MCP Servers")
        mcp_table.add_column("Name", style="bold")
        mcp_table.add_column("Transport")
        mcp_table.add_column("Command / URL")

        for name, srv in mcp_servers.items():
            if srv.command:
                cmd_display = f"{srv.command} {' '.join(srv.args)}"
                mcp_table.add_row(name, "stdio", cmd_display)
            elif srv.url:
                mcp_table.add_row(name, "http", srv.url)
            else:
                mcp_table.add_row(name, "[dim]unknown[/dim]", "")

        console.print(mcp_table)
    else:
        console.print("\n[dim]No MCP servers configured.[/dim]")


# ═══════════════════════════════════════════════════════════════════════════
# mcp sub-commands
# ═══════════════════════════════════════════════════════════════════════════


@mcp_app.command("list")
def mcp_list(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """List configured MCP servers."""
    cfg = _load_config_safe(config)

    servers = cfg.tools.mcp_servers
    if not servers:
        console.print("[dim]No MCP servers configured.[/dim]")
        return

    table = Table(title="MCP Servers")
    table.add_column("Name", style="bold")
    table.add_column("Transport")
    table.add_column("Command / URL")
    table.add_column("Env")

    for name, srv in servers.items():
        if srv.command:
            cmd = f"{srv.command} {' '.join(srv.args)}"
            transport = "stdio"
        elif srv.url:
            cmd = srv.url
            transport = "http"
        else:
            cmd = ""
            transport = "[dim]unknown[/dim]"

        env_str = ", ".join(f"{k}=..." for k in srv.env) if srv.env else ""
        table.add_row(name, transport, cmd, env_str)

    console.print(table)


@mcp_app.command("add")
def mcp_add(
    name: str = typer.Argument(..., help="MCP server name"),
    command: str = typer.Argument(..., help="Command to run (stdio transport)"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Add an MCP server to the configuration."""
    import shlex

    import yaml

    config_path = Path(config)
    if config_path.is_dir():
        for candidate in ("workpilot.yaml", "workpilot.yml"):
            p = config_path / candidate
            if p.exists():
                config_path = p
                break
        else:
            console.print("[red]No workpilot.yaml found.[/red]")
            raise typer.Exit(1)

    if not config_path.is_file():
        console.print(f"[red]Config file not found:[/red] {config_path}")
        raise typer.Exit(1)

    raw = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    tools_section = raw.setdefault("tools", {})
    mcp_section = tools_section.setdefault("mcp_servers", {})

    # Parse command into executable + args
    parts = shlex.split(command)
    mcp_section[name] = {
        "command": parts[0],
        "args": parts[1:] if len(parts) > 1 else [],
    }

    config_path.write_text(
        yaml.dump(raw, default_flow_style=False, sort_keys=False),
        encoding="utf-8",
    )
    console.print(f"[green]MCP server '{name}' added to {config_path}[/green]")


@mcp_app.command("remove")
def mcp_remove(
    name: str = typer.Argument(..., help="MCP server name to remove"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Remove an MCP server from the configuration."""
    import yaml

    config_path = Path(config)
    if config_path.is_dir():
        for candidate in ("workpilot.yaml", "workpilot.yml"):
            p = config_path / candidate
            if p.exists():
                config_path = p
                break
        else:
            console.print("[red]No workpilot.yaml found.[/red]")
            raise typer.Exit(1)

    if not config_path.is_file():
        console.print(f"[red]Config file not found:[/red] {config_path}")
        raise typer.Exit(1)

    raw = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    mcp_servers = raw.get("tools", {}).get("mcp_servers", {})

    if name not in mcp_servers:
        console.print(f"[yellow]MCP server '{name}' not found in config.[/yellow]")
        raise typer.Exit(1)

    del mcp_servers[name]
    config_path.write_text(
        yaml.dump(raw, default_flow_style=False, sort_keys=False),
        encoding="utf-8",
    )
    console.print(f"[green]MCP server '{name}' removed from {config_path}[/green]")


# ═══════════════════════════════════════════════════════════════════════════
# sessions sub-commands
# ═══════════════════════════════════════════════════════════════════════════


@sessions_app.command("list")
def sessions_list() -> None:
    """List all saved sessions."""
    from workpilot.utils.helpers import get_sessions_dir

    sessions_dir = get_sessions_dir()
    session_files = sorted(sessions_dir.glob("*.jsonl"))

    if not session_files:
        console.print("[dim]No sessions found.[/dim]")
        return

    table = Table(title="Sessions")
    table.add_column("Session ID", style="bold")
    table.add_column("Size")
    table.add_column("Messages")
    table.add_column("Modified")

    for path in session_files:
        session_id = path.stem
        size_bytes = path.stat().st_size
        mod_time = datetime.fromtimestamp(path.stat().st_mtime, tz=UTC)
        mod_str = mod_time.strftime("%Y-%m-%d %H:%M:%S UTC")

        # Count lines (each line = one message)
        try:
            line_count = sum(
                1 for line in path.read_text(encoding="utf-8").splitlines() if line.strip()
            )
        except Exception:
            line_count = 0

        if size_bytes < 1024:
            size_str = f"{size_bytes} B"
        elif size_bytes < 1024 * 1024:
            size_str = f"{size_bytes / 1024:.1f} KB"
        else:
            size_str = f"{size_bytes / (1024 * 1024):.1f} MB"

        table.add_row(session_id, size_str, str(line_count), mod_str)

    console.print(table)


@sessions_app.command("show")
def sessions_show(
    session_id: str = typer.Argument(..., help="Session ID to show"),
    lines: int = typer.Option(20, "--lines", "-n", help="Number of recent messages to show"),
) -> None:
    """Show details for a specific session."""
    import json

    from workpilot.utils.helpers import get_sessions_dir

    sessions_dir = get_sessions_dir()

    # Try direct match and sanitized match
    safe_id = session_id.replace(":", "_").replace("/", "_")
    candidates = [
        sessions_dir / f"{session_id}.jsonl",
        sessions_dir / f"{safe_id}.jsonl",
    ]

    session_path = None
    for c in candidates:
        if c.exists():
            session_path = c
            break

    if session_path is None:
        console.print(f"[red]Session not found:[/red] {session_id}")
        raise typer.Exit(1)

    messages: list[dict] = []
    for line in session_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line:
            try:
                messages.append(json.loads(line))
            except json.JSONDecodeError:
                continue

    console.print(f"\n[bold]Session:[/bold] {session_path.stem}")
    console.print(f"[bold]Messages:[/bold] {len(messages)}\n")

    # Show last N messages
    tail = messages[-lines:] if len(messages) > lines else messages
    for msg in tail:
        role = msg.get("role", "unknown")
        content = msg.get("content", "")
        ts = msg.get("timestamp", "")

        if role == "user":
            console.print(f"  [cyan]{role}[/cyan] ({ts}): {content[:200]}")
        elif role == "assistant":
            console.print(f"  [green]{role}[/green] ({ts}): {content[:200]}")
        else:
            console.print(f"  [dim]{role}[/dim] ({ts}): {content[:200]}")


# ═══════════════════════════════════════════════════════════════════════════
# security sub-commands
# ═══════════════════════════════════════════════════════════════════════════


@security_app.command("audit")
def security_audit(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Show security audit configuration and recent events."""
    cfg = _load_config_safe(config)

    console.print(Panel("[bold]Security Audit[/bold]", title="Audit", border_style="blue"))

    table = Table(title="Audit Configuration")
    table.add_column("Setting", style="bold")
    table.add_column("Value")

    table.add_row(
        "Enabled", "[green]yes[/green]" if cfg.security.audit.enabled else "[red]no[/red]"
    )
    table.add_row(
        "Redact secrets",
        "[green]yes[/green]" if cfg.security.audit.redact_secrets else "[red]no[/red]",
    )
    table.add_row("Log file", cfg.security.audit.log_file or "[dim]stderr (default)[/dim]")

    console.print(table)

    # Show recent audit entries if a log file is configured
    audit_file = cfg.security.audit.log_file
    if audit_file:
        audit_path = Path(audit_file)
        if audit_path.exists():
            import json

            all_lines = audit_path.read_text(encoding="utf-8").splitlines()
            recent = all_lines[-10:]
            console.print(f"\n[bold]Recent audit events[/bold] (last {len(recent)}):")
            for line in recent:
                try:
                    entry = json.loads(line)
                    event = entry.get("event", "unknown")
                    ts = entry.get("ts", "")
                    console.print(f"  [{ts}] {event}")
                except json.JSONDecodeError:
                    continue
        else:
            console.print(f"\n[dim]Audit log file does not exist yet: {audit_path}[/dim]")

    # Sandbox summary
    console.print("\n[bold]Sandbox[/bold]")
    console.print(f"  Shell deny patterns:    {len(cfg.tools.shell.deny_patterns)}")
    console.print(f"  Shell timeout:          {cfg.tools.shell.timeout}s")
    console.print(f"  File size limit:        {cfg.tools.filesystem.max_file_size_bytes:,} bytes")
    console.print(f"  Workspace restriction:  {cfg.tools.filesystem.restrict_to_workspace}")
    console.print(f"  Denied paths:           {len(cfg.tools.filesystem.deny_paths)}")


@security_app.command("credentials")
def security_credentials(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Show credential provider status (never shows actual values)."""
    cfg = _load_config_safe(config)

    console.print(Panel("[bold]Credential Status[/bold]", border_style="blue"))

    table = Table(title="Credentials")
    table.add_column("Credential", style="bold")
    table.add_column("Source")
    table.add_column("Status")

    creds_to_check = [
        ("ANTHROPIC_API_KEY", "LLM Provider"),
        ("OPENAI_API_KEY", "LLM Provider"),
        ("AZURE_OPENAI_API_KEY", "LLM Provider"),
        ("GITHUB_TOKEN", "GitHub Channel"),
        ("ADO_PAT", "Azure DevOps"),
    ]

    for env_var, purpose in creds_to_check:
        val = os.environ.get(env_var, "")
        if val:
            table.add_row(env_var, purpose, "[green]set[/green]")
        else:
            table.add_row(env_var, purpose, "[dim]not set[/dim]")

    console.print(table)

    console.print(f"\n  Provider: [bold]{cfg.security.credential_provider.value}[/bold]")
    if cfg.security.azure_keyvault_url:
        console.print(f"  Key Vault URL: {cfg.security.azure_keyvault_url}")


@security_app.command("roles")
def security_roles(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Show configured RBAC roles."""
    cfg = _load_config_safe(config)

    console.print(Panel("[bold]RBAC Roles[/bold]", border_style="blue"))

    if not cfg.security.roles:
        console.print("[dim]No custom RBAC roles defined.[/dim]")
        console.print(f"  Default role: [bold]{cfg.security.default_role}[/bold]")
        console.print(f"  Require auth: {cfg.security.require_auth}")
        return

    table = Table(title="Roles")
    table.add_column("Role", style="bold")
    table.add_column("Allowed Tools")
    table.add_column("Denied Tools")
    table.add_column("Channels")
    table.add_column("Max Iter")

    for role_name, role in cfg.security.roles.items():
        is_default = " *" if role_name == cfg.security.default_role else ""
        table.add_row(
            role_name + is_default,
            ", ".join(role.allowed_tools),
            ", ".join(role.denied_tools) or "[dim]none[/dim]",
            ", ".join(role.allowed_channels),
            str(role.max_iterations),
        )

    console.print(table)
    console.print(f"\n  Default role: [bold]{cfg.security.default_role}[/bold]")
    console.print(f"  Require auth: {cfg.security.require_auth}")

    # Show security profile autonomy defaults
    try:
        from workpilot.security.rbac import PolicyEngine

        engine = PolicyEngine(cfg.security)
        profile_defaults = engine.PROFILE_DEFAULTS.get(cfg.security.profile, {})
        if profile_defaults:
            console.print(
                f"\n[bold]Profile '{cfg.security.profile.value}' autonomy defaults:[/bold]"
            )
            for category, level in profile_defaults.items():
                level_str = {0: "forbidden", 1: "approval", 2: "notify", 3: "autonomous"}.get(
                    level.value, str(level.value)
                )
                console.print(f"  {category:12s} -> {level_str}")
    except Exception:
        pass


# ═══════════════════════════════════════════════════════════════════════════
# skills sub-commands
# ═══════════════════════════════════════════════════════════════════════════


@skills_app.command("list")
def skills_list(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """List all loaded skills (bundled + workspace)."""
    try:
        from workpilot.skills.loader import SkillLoader
    except ImportError:
        console.print("[red]Skills module not available.[/red]")
        raise typer.Exit(1)

    cfg = _load_config_safe(config)
    workspace = Path(cfg.agents.default.workspace).resolve()
    loader = SkillLoader(workspace)
    skills = loader.load_all()

    if not skills:
        console.print("[dim]No skills loaded.[/dim]")
        return

    table = Table(title="Skills")
    table.add_column("Name", style="bold")
    table.add_column("Mode")
    table.add_column("Triggers")
    table.add_column("Description")

    for skill in skills:
        mode_display = (
            "[green]always[/green]" if skill.mode == "always" else "[cyan]available[/cyan]"
        )
        triggers_str = ", ".join(skill.triggers) if skill.triggers else "[dim]none[/dim]"
        desc = skill.description[:60] + "..." if len(skill.description) > 60 else skill.description
        table.add_row(skill.name, mode_display, triggers_str, desc)

    console.print(table)


# ═══════════════════════════════════════════════════════════════════════════
# cron sub-commands
# ═══════════════════════════════════════════════════════════════════════════


@cron_app.command("list")
def cron_list(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """List configured cron jobs."""
    cfg = _load_config_safe(config)

    if not cfg.cron.enabled:
        console.print("[dim]Cron service is disabled.[/dim]")
        console.print("  Set [bold]cron.enabled: true[/bold] in workpilot.yaml")
        return

    jobs = cfg.cron.jobs
    if not jobs:
        console.print("[dim]No cron jobs configured.[/dim]")
        return

    table = Table(title="Cron Jobs")
    table.add_column("Name", style="bold")
    table.add_column("Schedule")
    table.add_column("Agent")
    table.add_column("Prompt")
    table.add_column("Enabled")

    for name, job in jobs.items():
        prompt_preview = job.prompt[:50] + "..." if len(job.prompt) > 50 else job.prompt
        table.add_row(
            name,
            job.schedule,
            job.agent,
            prompt_preview,
            "[green]yes[/green]" if job.enabled else "[red]no[/red]",
        )

    console.print(table)


@cron_app.command("add")
def cron_add(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Add a cron job interactively."""
    import yaml

    config_path = Path(config)
    if config_path.is_dir():
        for candidate in ("workpilot.yaml", "workpilot.yml"):
            p = config_path / candidate
            if p.exists():
                config_path = p
                break
        else:
            console.print("[red]No workpilot.yaml found.[/red]")
            raise typer.Exit(1)

    if not config_path.is_file():
        console.print(f"[red]Config file not found:[/red] {config_path}")
        raise typer.Exit(1)

    name: str = typer.prompt("Job name")
    schedule: str = typer.prompt("Cron schedule (e.g. '0 9 * * 1-5' for weekdays at 9am)")
    agent_name: str = typer.prompt("Agent name", default="default")
    prompt: str = typer.prompt("Prompt")

    raw = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    cron_section = raw.setdefault("cron", {})
    cron_section["enabled"] = True
    jobs_section = cron_section.setdefault("jobs", {})
    jobs_section[name] = {
        "schedule": schedule,
        "agent": agent_name,
        "prompt": prompt,
        "enabled": True,
    }

    config_path.write_text(
        yaml.dump(raw, default_flow_style=False, sort_keys=False),
        encoding="utf-8",
    )
    console.print(f"[green]Cron job '{name}' added to {config_path}[/green]")
