"""WorkPilot — Enterprise AI assistant with Microsoft ecosystem integration."""

__version__ = "0.1.5"
