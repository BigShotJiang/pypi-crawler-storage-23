"""
Office workflow orchestrator — automates office productivity tasks.

Provides email management, report generation, professional communication
drafting, and meeting-notes parsing via Graph API and LLM interactions.
"""

from __future__ import annotations

import textwrap
from datetime import UTC, datetime
from typing import Any

from loguru import logger

from workpilot.agent.tools.registry import ToolRegistry
from workpilot.providers.base import LLMProvider


class OfficeWorkflow:
    """
    Office workflow orchestrator.

    Provides high-level async methods for email triage, report compilation,
    professional communication drafting, and meeting-notes extraction.
    """

    def __init__(
        self,
        *,
        tool_registry: ToolRegistry,
        graph_client: Any | None = None,
    ) -> None:
        """
        Initialize the office workflow.

        Args:
            tool_registry: The central tool registry for executing tools.
            graph_client: An optional Microsoft Graph API client instance.
                When ``None``, Graph-dependent features will degrade gracefully.
        """
        self._tools = tool_registry
        self._graph = graph_client

    # ------------------------------------------------------------------
    # Email assistant
    # ------------------------------------------------------------------

    async def email_assistant(self, action: str, **kwargs: Any) -> dict[str, Any]:
        """
        Perform email-related actions via the Graph API or LLM.

        Args:
            action: One of ``"summarize_unread"``, ``"draft_reply"``, or
                ``"send"``.
            **kwargs: Action-specific keyword arguments:

                - **summarize_unread**: ``folder`` (str, default ``"inbox"``),
                  ``limit`` (int, default 10).
                - **draft_reply**: ``message_id`` (str), ``tone`` (str,
                  default ``"professional"``), ``language`` (str,
                  default ``"en"``).
                - **send**: ``to`` (list[str]), ``subject`` (str),
                  ``body`` (str), ``confirm`` (bool, default True).

        Returns:
            A dict with ``action``, ``status``, and action-specific data
            (e.g., ``summaries``, ``draft``, ``message_id``).
        """
        logger.info("Email assistant action: {}", action)

        handlers: dict[str, Any] = {
            "summarize_unread": self._summarize_unread,
            "draft_reply": self._draft_reply,
            "send": self._send_email,
        }

        handler = handlers.get(action)
        if handler is None:
            logger.warning("Unknown email action: {}", action)
            return {
                "action": action,
                "status": "error",
                "error": f"Unknown action: {action}",
            }

        try:
            result = await handler(**kwargs)
            return {"action": action, "status": "ok", **result}
        except Exception as exc:
            logger.error("Email assistant ({}) failed: {}", action, exc)
            return {"action": action, "status": "error", "error": str(exc)}

    # ------------------------------------------------------------------
    # Report generation
    # ------------------------------------------------------------------

    async def generate_report(self, report_type: str, data: dict[str, Any]) -> str:
        """
        Compile a structured report from multiple data sources.

        Args:
            report_type: One of ``"weekly"``, ``"daily"``, or ``"status"``.
            data: Input data dict. Expected keys vary by type but may include:

                - ``git_summary`` — dict with ``commits``, ``prs_merged``, etc.
                - ``ado_items`` — list of work-item dicts
                - ``calendar_events`` — list of calendar event dicts
                - ``notes`` — free-text notes to include
                - ``team`` — team name (for headers)

        Returns:
            A formatted Markdown report string.
        """
        logger.info("Generating {} report", report_type)

        generators: dict[str, Any] = {
            "weekly": self._generate_weekly_report,
            "daily": self._generate_daily_report,
            "status": self._generate_status_report,
        }

        generator = generators.get(report_type)
        if generator is None:
            logger.warning("Unknown report type: {}", report_type)
            return f"Error: unknown report type '{report_type}'"

        try:
            return await generator(data)
        except Exception as exc:
            logger.error("Report generation ({}) failed: {}", report_type, exc)
            return f"Error generating {report_type} report: {exc}"

    # ------------------------------------------------------------------
    # Communication drafting
    # ------------------------------------------------------------------

    async def draft_communication(
        self,
        topic: str,
        recipients: list[str],
        language: str = "en",
        bilingual: bool = False,
    ) -> str:
        """
        Draft a professional communication (email / announcement).

        Args:
            topic: The subject or topic to communicate about.
            recipients: List of recipient names or addresses (used for
                tone and salutation).
            language: Primary language code (``"en"`` or ``"cn"``).
            bilingual: If True, produce both Chinese and English versions.

        Returns:
            The drafted communication as a string.
        """
        logger.info(
            "Drafting communication — topic={}, bilingual={}",
            topic,
            bilingual,
        )

        recipient_list = ", ".join(recipients) if recipients else "team"

        if bilingual:
            prompt = textwrap.dedent(f"""\
                Draft a professional communication about the following topic.
                Provide TWO versions: first in Chinese (中文), then in English.
                Separate them with "---".

                Topic: {topic}
                Recipients: {recipient_list}

                The tone should be professional and clear.
                Include a greeting and sign-off for each version.
            """)
        else:
            lang_name = "Chinese" if language == "cn" else "English"
            prompt = textwrap.dedent(f"""\
                Draft a professional communication in {lang_name} about the
                following topic.

                Topic: {topic}
                Recipients: {recipient_list}

                The tone should be professional and clear.
                Include a greeting and sign-off.
            """)

        # Use the LLM via the tool registry's shell or directly if a
        # provider reference is available on the graph client.
        provider = self._get_provider()
        if provider is None:
            logger.warning("No LLM provider available for drafting")
            return f"[Draft placeholder] Topic: {topic}"

        response = await provider.complete(
            model="anthropic/claude-sonnet-4-20250514",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.4,
            max_tokens=4096,
        )
        return response.content

    # ------------------------------------------------------------------
    # Meeting notes
    # ------------------------------------------------------------------

    async def meeting_notes(self, transcript: str) -> dict[str, Any]:
        """
        Parse a meeting transcript into structured notes.

        Args:
            transcript: Raw meeting transcript text.

        Returns:
            A dict with keys:

            - ``summary`` — concise meeting summary (2-3 sentences)
            - ``decisions`` — list of decisions made
            - ``action_items`` — list of dicts with ``assignee``, ``task``,
              and ``due_date`` (if mentioned)
            - ``attendees`` — list of attendee names extracted from the
              transcript
        """
        logger.info("Parsing meeting notes ({} chars)", len(transcript))

        prompt = textwrap.dedent(f"""\
            Parse the following meeting transcript and extract structured notes.

            Respond with JSON:
            {{
                "summary": "2-3 sentence summary",
                "decisions": ["decision 1", "decision 2", ...],
                "action_items": [
                    {{"assignee": "Name", "task": "description", "due_date": "date or null"}},
                    ...
                ],
                "attendees": ["Name1", "Name2", ...]
            }}

            Transcript:
            {transcript}
        """)

        provider = self._get_provider()
        if provider is None:
            logger.warning("No LLM provider available for meeting notes")
            return {
                "summary": "Provider unavailable — could not parse transcript.",
                "decisions": [],
                "action_items": [],
                "attendees": [],
            }

        response = await provider.complete(
            model="anthropic/claude-sonnet-4-20250514",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.2,
            max_tokens=4096,
        )
        return self._parse_meeting_response(response.content)

    # ------------------------------------------------------------------
    # Private helpers — email
    # ------------------------------------------------------------------

    async def _summarize_unread(
        self,
        folder: str = "inbox",
        limit: int = 10,
    ) -> dict[str, Any]:
        """Fetch and summarize unread emails."""
        if self._graph is None:
            return {"summaries": [], "note": "Graph client not configured"}

        try:
            messages = await self._graph.get_unread_messages(
                folder=folder,
                limit=limit,
            )
        except Exception as exc:
            logger.error("Failed to fetch unread messages: {}", exc)
            return {"summaries": [], "error": str(exc)}

        summaries: list[dict[str, str]] = []
        for msg in messages:
            summaries.append(
                {
                    "id": msg.get("id", ""),
                    "from": msg.get("from", {}).get("emailAddress", {}).get("address", "unknown"),
                    "subject": msg.get("subject", "(no subject)"),
                    "preview": msg.get("bodyPreview", "")[:200],
                    "received": msg.get("receivedDateTime", ""),
                }
            )
        return {"summaries": summaries}

    async def _draft_reply(
        self,
        message_id: str = "",
        tone: str = "professional",
        language: str = "en",
    ) -> dict[str, Any]:
        """Draft a reply to a specific email."""
        if not message_id:
            return {"draft": "", "error": "message_id is required"}

        original_body = ""
        if self._graph is not None:
            try:
                msg = await self._graph.get_message(message_id)
                original_body = msg.get("body", {}).get("content", "")
            except Exception as exc:
                logger.warning("Could not fetch original message: {}", exc)

        lang_name = "Chinese" if language == "cn" else "English"
        prompt = textwrap.dedent(f"""\
            Draft a {tone} reply in {lang_name} to the following email.
            Keep it concise and actionable.

            Original email:
            {original_body or "(original not available)"}
        """)

        provider = self._get_provider()
        if provider is None:
            return {"draft": f"[Placeholder reply to {message_id}]"}

        response = await provider.complete(
            model="anthropic/claude-sonnet-4-20250514",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.4,
            max_tokens=2048,
        )
        return {"draft": response.content, "message_id": message_id}

    async def _send_email(
        self,
        to: list[str] | None = None,
        subject: str = "",
        body: str = "",
        confirm: bool = True,
    ) -> dict[str, Any]:
        """Send an email, optionally requiring confirmation."""
        if not to:
            return {"sent": False, "error": "No recipients specified"}

        if confirm:
            return {
                "sent": False,
                "pending_confirmation": True,
                "to": to,
                "subject": subject,
                "body_preview": body[:200],
                "note": "Confirmation required before sending.",
            }

        if self._graph is None:
            return {"sent": False, "error": "Graph client not configured"}

        try:
            await self._graph.send_message(
                to_addresses=to,
                subject=subject,
                body=body,
            )
            return {"sent": True, "to": to, "subject": subject}
        except Exception as exc:
            logger.error("Failed to send email: {}", exc)
            return {"sent": False, "error": str(exc)}

    # ------------------------------------------------------------------
    # Private helpers — reports
    # ------------------------------------------------------------------

    async def _generate_weekly_report(self, data: dict[str, Any]) -> str:
        """Generate a weekly summary report."""
        now = datetime.now(UTC).strftime("%Y-%m-%d")
        team = data.get("team", "Engineering")
        git = data.get("git_summary", {})
        ado = data.get("ado_items", [])
        calendar = data.get("calendar_events", [])
        notes = data.get("notes", "")

        sections: list[str] = [
            f"# Weekly Report — {team}",
            f"**Week ending:** {now}\n",
        ]

        # Git summary
        if git:
            sections.append("## Code Activity")
            sections.append(f"- **Commits:** {git.get('commits', 0)}")
            sections.append(f"- **PRs merged:** {git.get('prs_merged', 0)}")
            sections.append(f"- **PRs open:** {git.get('prs_open', 0)}")
            if git.get("highlights"):
                sections.append("### Highlights")
                for h in git["highlights"]:
                    sections.append(f"- {h}")

        # Work items
        if ado:
            sections.append("## Work Items")
            completed = [i for i in ado if i.get("state") == "Done"]
            in_progress = [i for i in ado if i.get("state") == "Active"]
            sections.append(f"- **Completed:** {len(completed)}")
            sections.append(f"- **In progress:** {len(in_progress)}")
            for item in completed[:5]:
                sections.append(f"  - {item.get('title', 'Untitled')}")

        # Calendar
        if calendar:
            sections.append("## Key Meetings")
            for evt in calendar[:5]:
                sections.append(f"- **{evt.get('subject', 'Meeting')}** — {evt.get('date', 'TBD')}")

        # Notes
        if notes:
            sections.append(f"## Notes\n{notes}")

        return "\n".join(sections)

    async def _generate_daily_report(self, data: dict[str, Any]) -> str:
        """Generate a daily standup-style report."""
        now = datetime.now(UTC).strftime("%Y-%m-%d")
        sections: list[str] = [
            f"# Daily Report — {now}\n",
        ]

        yesterday = data.get("yesterday", [])
        today = data.get("today", [])
        blockers = data.get("blockers", [])

        sections.append("## Yesterday")
        if yesterday:
            for item in yesterday:
                sections.append(f"- {item}")
        else:
            sections.append("- (nothing logged)")

        sections.append("## Today")
        if today:
            for item in today:
                sections.append(f"- {item}")
        else:
            sections.append("- (nothing planned)")

        sections.append("## Blockers")
        if blockers:
            for b in blockers:
                sections.append(f"- {b}")
        else:
            sections.append("- None")

        return "\n".join(sections)

    async def _generate_status_report(self, data: dict[str, Any]) -> str:
        """Generate a project status report."""
        now = datetime.now(UTC).strftime("%Y-%m-%d")
        project = data.get("project", "Project")
        status = data.get("status", "on_track")  # on_track / at_risk / blocked
        sections: list[str] = [
            f"# Status Report — {project}",
            f"**Date:** {now}",
            f"**Status:** {status.replace('_', ' ').title()}\n",
        ]

        milestones = data.get("milestones", [])
        if milestones:
            sections.append("## Milestones")
            for m in milestones:
                emoji_map = {"done": "[x]", "in_progress": "[-]", "pending": "[ ]"}
                marker = emoji_map.get(m.get("state", "pending"), "[ ]")
                sections.append(f"- {marker} {m.get('name', 'Unnamed')}")

        risks = data.get("risks", [])
        if risks:
            sections.append("## Risks")
            for r in risks:
                sections.append(f"- {r}")

        next_steps = data.get("next_steps", [])
        if next_steps:
            sections.append("## Next Steps")
            for s in next_steps:
                sections.append(f"- {s}")

        return "\n".join(sections)

    # ------------------------------------------------------------------
    # Private helpers — meeting notes
    # ------------------------------------------------------------------

    @staticmethod
    def _parse_meeting_response(content: str) -> dict[str, Any]:
        """Parse the LLM meeting-notes response into a structured dict."""
        import json

        cleaned = content.strip()
        if cleaned.startswith("```"):
            lines = cleaned.split("\n")
            if lines[0].startswith("```"):
                lines = lines[1:]
            if lines and lines[-1].strip() == "```":
                lines = lines[:-1]
            cleaned = "\n".join(lines).strip()

        try:
            parsed = json.loads(cleaned)
            if isinstance(parsed, dict):
                return {
                    "summary": parsed.get("summary", ""),
                    "decisions": parsed.get("decisions", []),
                    "action_items": parsed.get("action_items", []),
                    "attendees": parsed.get("attendees", []),
                }
        except (json.JSONDecodeError, TypeError):
            pass

        return {
            "summary": content,
            "decisions": [],
            "action_items": [],
            "attendees": [],
        }

    # ------------------------------------------------------------------
    # Utility
    # ------------------------------------------------------------------

    def _get_provider(self) -> LLMProvider | None:
        """
        Resolve an LLM provider from available sources.

        Checks the graph client first (it may carry a provider reference),
        then falls back to None.
        """
        if self._graph is not None and hasattr(self._graph, "provider"):
            return self._graph.provider  # type: ignore[attr-defined]
        return None
