"""Tests for audit logger."""

import json
from pathlib import Path

from workpilot.config.schema import AuditConfig
from workpilot.security.audit import AuditLogger, _redact_dict, _redact_string


class TestRedaction:
    def test_redact_sensitive_keys(self):
        data = {"url": "https://api.example.com", "token": "secret123", "name": "test"}
        result = _redact_dict(data)
        assert result["url"] == "https://api.example.com"
        assert result["token"] == "[REDACTED]"
        assert result["name"] == "test"

    def test_redact_nested(self):
        data = {"config": {"api_key": "sk-1234", "model": "gpt-4"}}
        result = _redact_dict(data)
        assert result["config"]["api_key"] == "[REDACTED]"
        assert result["config"]["model"] == "gpt-4"

    def test_redact_jwt(self):
        jwt = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.abc123def456"
        assert "[REDACTED]" in _redact_string(jwt)

    def test_redact_github_pat(self):
        assert "[REDACTED]" in _redact_string("ghp_abc123def456ghi789jkl012mno345pqr678")

    def test_redact_openai_key(self):
        assert "[REDACTED]" in _redact_string("sk-abc123def456ghi789jkl0abcde")


class TestAuditLogger:
    def test_disabled_logger(self):
        logger = AuditLogger(AuditConfig(enabled=False))
        # Should not raise
        logger.log_tool(tool="shell", actor="agent", args={"cmd": "ls"}, result="ok")

    def test_file_logging(self, tmp_path: Path):
        log_file = tmp_path / "audit.jsonl"
        logger = AuditLogger(
            AuditConfig(
                enabled=True,
                log_file=str(log_file),
                redact_secrets=True,
            )
        )

        logger.log_tool(
            tool="shell",
            actor="agent",
            args={"command": "ls", "token": "secret"},
            result="file1\nfile2",
        )

        lines = log_file.read_text().strip().split("\n")
        assert len(lines) == 1
        entry = json.loads(lines[0])
        assert entry["event"] == "tool:execute"
        assert entry["tool"] == "shell"
        assert entry["args"]["token"] == "[REDACTED]"

    def test_security_event(self, tmp_path: Path):
        log_file = tmp_path / "audit.jsonl"
        logger = AuditLogger(AuditConfig(enabled=True, log_file=str(log_file)))

        logger.log_security(
            event="prompt_injection_detected",
            details={"sender": "user1", "pattern": "ignore instructions"},
            severity="warning",
        )

        entry = json.loads(log_file.read_text().strip())
        assert entry["event"] == "security:prompt_injection_detected"
        assert entry["severity"] == "warning"
