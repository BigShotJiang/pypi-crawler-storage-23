"""Tests for tool registry and built-in tools."""

from pathlib import Path
from typing import Any

import pytest

from workpilot.agent.tools.base import Tool
from workpilot.agent.tools.filesystem import EditFileTool, ListDirTool, ReadFileTool, WriteFileTool
from workpilot.agent.tools.git import GitTool
from workpilot.agent.tools.registry import ToolRegistry
from workpilot.agent.tools.shell import ShellTool
from workpilot.config.schema import FileSystemConfig, ShellConfig
from workpilot.security.sandbox import Sandbox


class MockTool(Tool):
    @property
    def name(self) -> str:
        return "mock"

    @property
    def description(self) -> str:
        return "A mock tool"

    @property
    def parameters(self) -> dict[str, Any]:
        return {"type": "object", "properties": {"input": {"type": "string"}}}

    async def execute(self, **kwargs: Any) -> str:
        return f"mock result: {kwargs.get('input', '')}"


class TestToolRegistry:
    def test_register_and_get(self):
        registry = ToolRegistry()
        tool = MockTool()
        registry.register(tool)
        assert registry.get("mock") is tool

    def test_list_tools(self):
        registry = ToolRegistry()
        registry.register(MockTool())
        tools = registry.list_tools()
        assert len(tools) == 1
        assert tools[0].name == "mock"

    def test_get_schemas(self):
        registry = ToolRegistry()
        registry.register(MockTool())
        schemas = registry.get_schemas()
        assert len(schemas) == 1
        assert schemas[0]["type"] == "function"
        assert schemas[0]["function"]["name"] == "mock"

    @pytest.mark.asyncio
    async def test_execute(self):
        registry = ToolRegistry()
        registry.register(MockTool())
        result = await registry.execute("mock", {"input": "hello"})
        assert result == "mock result: hello"

    @pytest.mark.asyncio
    async def test_execute_unknown_tool(self):
        registry = ToolRegistry()
        result = await registry.execute("nonexistent", {})
        assert "unknown tool" in result

    def test_unregister(self):
        registry = ToolRegistry()
        registry.register(MockTool())
        registry.unregister("mock")
        assert registry.get("mock") is None


@pytest.fixture
def sandbox(tmp_path: Path) -> Sandbox:
    return Sandbox(
        tmp_path,
        shell_config=ShellConfig(timeout=5),
        fs_config=FileSystemConfig(restrict_to_workspace=True),
    )


class TestFileTools:
    @pytest.mark.asyncio
    async def test_write_and_read(self, sandbox: Sandbox, tmp_path: Path):
        write_tool = WriteFileTool(sandbox)
        read_tool = ReadFileTool(sandbox)

        result = await write_tool.execute(path="test.txt", content="Hello World")
        assert "Written" in result

        content = await read_tool.execute(path="test.txt")
        assert content == "Hello World"

    @pytest.mark.asyncio
    async def test_edit_file(self, sandbox: Sandbox, tmp_path: Path):
        (tmp_path / "edit.txt").write_text("foo bar baz")
        edit_tool = EditFileTool(sandbox)

        result = await edit_tool.execute(path="edit.txt", old_string="bar", new_string="qux")
        assert "edit.txt" in result

        content = (tmp_path / "edit.txt").read_text()
        assert content == "foo qux baz"

    @pytest.mark.asyncio
    async def test_list_dir(self, sandbox: Sandbox, tmp_path: Path):
        (tmp_path / "a.txt").write_text("a")
        (tmp_path / "b.txt").write_text("b")
        (tmp_path / "subdir").mkdir()

        tool = ListDirTool(sandbox)
        result = await tool.execute(path=".")
        assert "a.txt" in result
        assert "b.txt" in result
        assert "subdir/" in result

    @pytest.mark.asyncio
    async def test_read_blocked_path(self, sandbox: Sandbox):
        tool = ReadFileTool(sandbox)
        result = await tool.execute(path="../../etc/passwd")
        assert "BLOCKED" in result


class TestShellTool:
    @pytest.mark.asyncio
    async def test_runs_command(self, sandbox: Sandbox):
        tool = ShellTool(sandbox)
        result = await tool.execute(command="echo hello")
        assert "hello" in result

    @pytest.mark.asyncio
    async def test_blocks_dangerous_command(self, sandbox: Sandbox):
        tool = ShellTool(sandbox)
        result = await tool.execute(command="rm -rf /")
        assert "BLOCKED" in result


class TestGitTool:
    @pytest.mark.asyncio
    async def test_blocks_force_push(self, sandbox: Sandbox):
        tool = GitTool(sandbox)
        result = await tool.execute(args="push --force origin main")
        assert "BLOCKED" in result

    @pytest.mark.asyncio
    async def test_blocks_reset_hard(self, sandbox: Sandbox):
        tool = GitTool(sandbox)
        result = await tool.execute(args="reset --hard HEAD~5")
        assert "BLOCKED" in result
