"""Tests for the DevWorkflow and OfficeWorkflow modules."""

from unittest.mock import MagicMock

import pytest

from workpilot.agent.tools.registry import ToolRegistry
from workpilot.providers.base import LLMProvider
from workpilot.workflows.dev import DevWorkflow
from workpilot.workflows.office import OfficeWorkflow

# ── Helpers ──────────────────────────────────────────────────────────────────


def _make_dev_workflow() -> DevWorkflow:
    """Create a DevWorkflow with mock dependencies.

    Note: audit is a plain MagicMock (no spec) because DevWorkflow calls
    ``self._audit.log(...)`` which is not defined on AuditLogger.
    """
    registry = MagicMock(spec=ToolRegistry)
    provider = MagicMock(spec=LLMProvider)
    audit = MagicMock()  # no spec — DevWorkflow uses audit.log() generically
    return DevWorkflow(tool_registry=registry, provider=provider, audit=audit)


def _make_office_workflow(
    graph_client: object | None = None,
) -> OfficeWorkflow:
    """Create an OfficeWorkflow with mock dependencies."""
    registry = MagicMock(spec=ToolRegistry)
    return OfficeWorkflow(tool_registry=registry, graph_client=graph_client)


# ── DevWorkflow ──────────────────────────────────────────────────────────────


class TestDevWorkflow:
    def test_initialization(self):
        wf = _make_dev_workflow()
        assert wf._tools is not None
        assert wf._provider is not None
        assert wf._audit is not None

    def test_generate_change_report_bilingual(self):
        wf = _make_dev_workflow()
        changes = {
            "summary": "Refactored the auth module for better clarity.",
            "commits": [
                {"sha": "abc12345", "message": "Refactor auth"},
                {"sha": "def67890", "message": "Add tests"},
            ],
            "files_changed": ["auth.py", "test_auth.py"],
            "pr_url": "https://github.com/org/repo/pull/42",
            "author": "Alice",
        }

        report = wf.generate_change_report(changes, bilingual=True)

        # Chinese section
        assert "变更报告" in report
        assert "作者" in report
        assert "提交记录" in report
        assert "变更文件" in report
        # English section
        assert "Change Report" in report
        assert "Author" in report
        assert "Alice" in report
        assert "Commits" in report
        assert "Files Changed" in report
        assert "abc12345" in report
        assert "auth.py" in report
        assert "https://github.com/org/repo/pull/42" in report

    def test_generate_change_report_english_only(self):
        wf = _make_dev_workflow()
        changes = {
            "summary": "Fixed a bug.",
            "commits": [{"sha": "aaa11111", "message": "Fix bug"}],
            "files_changed": ["main.py"],
            "pr_url": "N/A",
            "author": "Bob",
        }

        report = wf.generate_change_report(changes, bilingual=False)

        # Should NOT have Chinese
        assert "变更报告" not in report
        # Should have English
        assert "Change Report" in report
        assert "Bob" in report
        assert "Fix bug" in report

    def test_generate_change_report_no_commits(self):
        wf = _make_dev_workflow()
        changes = {
            "summary": "Minor change.",
            "files_changed": ["readme.md"],
        }

        report = wf.generate_change_report(changes, bilingual=False)

        assert "Change Report" in report
        assert "Minor change." in report
        assert "Commits" not in report  # No commits section

    def test_generate_change_report_no_files(self):
        wf = _make_dev_workflow()
        changes = {
            "summary": "Config update.",
            "commits": [{"sha": "bbb22222", "message": "Update config"}],
        }

        report = wf.generate_change_report(changes, bilingual=False)

        assert "Files Changed" not in report

    def test_generate_change_report_defaults(self):
        wf = _make_dev_workflow()
        changes = {}  # All defaults

        report = wf.generate_change_report(changes, bilingual=False)

        assert "Change Report" in report
        assert "No summary provided." in report
        assert "Unknown" in report  # default author

    def test_audit_logged_on_change_report(self):
        wf = _make_dev_workflow()
        changes = {"summary": "test", "commits": []}
        wf.generate_change_report(changes, bilingual=False)
        wf._audit.log.assert_called_once()

    def test_parse_review_response_valid_json(self):
        json_str = '{"summary": "Looks good", "issues": [], "approval": "approve"}'
        result = DevWorkflow._parse_review_response(json_str)
        assert result["summary"] == "Looks good"
        assert result["issues"] == []
        assert result["approval"] == "approve"

    def test_parse_review_response_invalid_json(self):
        result = DevWorkflow._parse_review_response("This is just text.")
        assert result["summary"] == "This is just text."
        assert result["issues"] == []
        assert result["approval"] == "comment"

    def test_try_parse_json_fenced(self):
        text = '```json\n{"key": "value"}\n```'
        result = DevWorkflow._try_parse_json(text)
        assert result["key"] == "value"

    def test_try_parse_json_bare(self):
        text = '{"key": "value"}'
        result = DevWorkflow._try_parse_json(text)
        assert result["key"] == "value"

    def test_try_parse_json_fallback(self):
        result = DevWorkflow._try_parse_json("not json", fallback={"default": True})
        assert result == {"default": True}


# ── OfficeWorkflow ───────────────────────────────────────────────────────────


class TestOfficeWorkflow:
    def test_initialization_no_graph(self):
        wf = _make_office_workflow(graph_client=None)
        assert wf._tools is not None
        assert wf._graph is None

    def test_initialization_with_graph(self):
        mock_graph = MagicMock()
        wf = _make_office_workflow(graph_client=mock_graph)
        assert wf._graph is mock_graph

    @pytest.mark.asyncio
    async def test_email_assistant_unknown_action(self):
        wf = _make_office_workflow()
        result = await wf.email_assistant("nonexistent_action")
        assert result["status"] == "error"
        assert "Unknown action" in result["error"]

    @pytest.mark.asyncio
    async def test_generate_report_unknown_type(self):
        wf = _make_office_workflow()
        result = await wf.generate_report("unknown_type", {})
        assert "unknown report type" in result.lower()

    @pytest.mark.asyncio
    async def test_generate_daily_report(self):
        wf = _make_office_workflow()
        data = {
            "yesterday": ["Fixed auth bug", "Reviewed PRs"],
            "today": ["Deploy release"],
            "blockers": ["Waiting on API key"],
        }
        result = await wf.generate_report("daily", data)
        assert "Daily Report" in result
        assert "Fixed auth bug" in result
        assert "Deploy release" in result
        assert "Waiting on API key" in result

    @pytest.mark.asyncio
    async def test_generate_weekly_report(self):
        wf = _make_office_workflow()
        data = {
            "team": "Platform",
            "git_summary": {"commits": 42, "prs_merged": 5, "prs_open": 2},
            "notes": "Good progress this week.",
        }
        result = await wf.generate_report("weekly", data)
        assert "Weekly Report" in result
        assert "Platform" in result
        assert "42" in result
        assert "Good progress" in result

    @pytest.mark.asyncio
    async def test_generate_status_report(self):
        wf = _make_office_workflow()
        data = {
            "project": "WorkPilot",
            "status": "on_track",
            "milestones": [
                {"name": "MVP", "state": "done"},
                {"name": "Beta", "state": "in_progress"},
            ],
            "risks": ["API rate limits"],
            "next_steps": ["Deploy to staging"],
        }
        result = await wf.generate_report("status", data)
        assert "Status Report" in result
        assert "WorkPilot" in result
        assert "On Track" in result
        assert "MVP" in result
        assert "API rate limits" in result
        assert "Deploy to staging" in result

    def test_parse_meeting_response_valid(self):
        json_str = (
            '{"summary": "Discussed roadmap", "decisions": ["Use Python"], '
            '"action_items": [{"assignee": "Alice", "task": "Setup CI", "due_date": null}], '
            '"attendees": ["Alice", "Bob"]}'
        )
        result = OfficeWorkflow._parse_meeting_response(json_str)
        assert result["summary"] == "Discussed roadmap"
        assert "Use Python" in result["decisions"]
        assert len(result["action_items"]) == 1
        assert "Alice" in result["attendees"]

    def test_parse_meeting_response_fenced_json(self):
        text = '```json\n{"summary": "Meeting notes", "decisions": [], "action_items": [], "attendees": ["Bob"]}\n```'
        result = OfficeWorkflow._parse_meeting_response(text)
        assert result["summary"] == "Meeting notes"

    def test_parse_meeting_response_invalid_json(self):
        result = OfficeWorkflow._parse_meeting_response("Not JSON at all.")
        assert result["summary"] == "Not JSON at all."
        assert result["decisions"] == []
        assert result["action_items"] == []

    def test_get_provider_none_when_no_graph(self):
        wf = _make_office_workflow(graph_client=None)
        assert wf._get_provider() is None

    def test_get_provider_from_graph(self):
        mock_graph = MagicMock()
        mock_provider = MagicMock(spec=LLMProvider)
        mock_graph.provider = mock_provider
        wf = _make_office_workflow(graph_client=mock_graph)
        assert wf._get_provider() is mock_provider

    @pytest.mark.asyncio
    async def test_draft_communication_no_provider(self):
        wf = _make_office_workflow(graph_client=None)
        result = await wf.draft_communication(
            topic="Architecture review",
            recipients=["team@example.com"],
        )
        assert "placeholder" in result.lower()
