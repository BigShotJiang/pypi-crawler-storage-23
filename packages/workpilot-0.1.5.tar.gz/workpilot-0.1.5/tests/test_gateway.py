"""Tests for the Gateway module (auth, middleware, server schemas)."""

from unittest.mock import MagicMock

import pytest
from pydantic import SecretStr

from workpilot.config.schema import GatewayConfig
from workpilot.gateway.auth import verify_api_key
from workpilot.gateway.middleware import RateLimiter

# ── verify_api_key ───────────────────────────────────────────────────────────


class TestVerifyApiKey:
    def test_no_key_configured_allows_anything(self):
        config = GatewayConfig(api_key=None)
        assert verify_api_key(None, config) is True
        assert verify_api_key("any-key", config) is True

    def test_matching_key_returns_true(self):
        config = GatewayConfig(api_key=SecretStr("my-secret-key"))
        assert verify_api_key("my-secret-key", config) is True

    def test_wrong_key_returns_false(self):
        config = GatewayConfig(api_key=SecretStr("my-secret-key"))
        assert verify_api_key("wrong-key", config) is False

    def test_none_key_when_configured_returns_false(self):
        config = GatewayConfig(api_key=SecretStr("my-secret-key"))
        assert verify_api_key(None, config) is False

    def test_empty_key_returns_false(self):
        config = GatewayConfig(api_key=SecretStr("my-secret-key"))
        assert verify_api_key("", config) is False

    def test_constant_time_comparison(self):
        """Verify that hmac.compare_digest is used (functional check)."""
        config = GatewayConfig(api_key=SecretStr("secret"))
        # If the comparison is correct, nearly-matching keys should fail
        assert verify_api_key("secre", config) is False
        assert verify_api_key("secret!", config) is False
        assert verify_api_key("secret", config) is True


# ── RateLimiter ──────────────────────────────────────────────────────────────


class TestRateLimiter:
    def test_first_request_allowed(self):
        limiter = RateLimiter(rate_per_minute=60)
        assert limiter.check("10.0.0.1") is True

    def test_requests_within_limit_allowed(self):
        limiter = RateLimiter(rate_per_minute=10)
        # First 10 requests should all be allowed (bucket starts full)
        for _ in range(10):
            assert limiter.check("10.0.0.1") is True

    def test_requests_over_limit_denied(self):
        limiter = RateLimiter(rate_per_minute=5)
        # Exhaust the bucket
        for _ in range(5):
            limiter.check("10.0.0.1")
        # Next request should be denied
        assert limiter.check("10.0.0.1") is False

    def test_different_clients_independent(self):
        limiter = RateLimiter(rate_per_minute=2)
        # Exhaust client A
        limiter.check("10.0.0.1")
        limiter.check("10.0.0.1")
        assert limiter.check("10.0.0.1") is False
        # Client B should still have tokens
        assert limiter.check("10.0.0.2") is True

    def test_reset_single_client(self):
        limiter = RateLimiter(rate_per_minute=2)
        # Exhaust client A
        limiter.check("10.0.0.1")
        limiter.check("10.0.0.1")
        assert limiter.check("10.0.0.1") is False
        # Reset client A
        limiter.reset("10.0.0.1")
        # Client A should now be allowed again
        assert limiter.check("10.0.0.1") is True

    def test_reset_all_clients(self):
        limiter = RateLimiter(rate_per_minute=2)
        limiter.check("10.0.0.1")
        limiter.check("10.0.0.1")
        limiter.check("10.0.0.2")
        limiter.check("10.0.0.2")
        # Reset all
        limiter.reset()
        assert limiter.check("10.0.0.1") is True
        assert limiter.check("10.0.0.2") is True

    def test_tokens_refill_over_time(self):
        # Use a small bucket so exhaustion is instant (no time for refill)
        limiter = RateLimiter(rate_per_minute=10)
        # Exhaust all tokens
        for _ in range(10):
            limiter.check("10.0.0.1")
        # Right after exhaustion, should be denied (no time for refill)
        assert limiter.check("10.0.0.1") is False


# ── GatewayServer schemas (import validation) ───────────────────────────────


class TestGatewaySchemas:
    def test_health_response_schema(self):
        from workpilot.gateway.server import HealthResponse

        health = HealthResponse()
        assert health.status == "ok"
        assert health.version is not None

    def test_chat_completion_request_schema(self):
        from workpilot.gateway.server import ChatCompletionRequest, ChatMessage

        req = ChatCompletionRequest(
            messages=[ChatMessage(role="user", content="Hello")],
        )
        assert len(req.messages) == 1
        assert req.stream is False

    def test_chat_completion_response_schema(self):
        from workpilot.gateway.server import (
            ChatChoice,
            ChatChoiceMessage,
            ChatCompletionResponse,
        )

        resp = ChatCompletionResponse(
            choices=[ChatChoice(message=ChatChoiceMessage(content="Hi there"))],
        )
        assert resp.object == "chat.completion"
        assert resp.choices[0].message.content == "Hi there"
        assert resp.choices[0].finish_reason == "stop"

    def test_error_response_schema(self):
        from workpilot.gateway.server import ErrorResponse

        err = ErrorResponse(error="bad_request", message="Something went wrong")
        assert err.error == "bad_request"

    def test_webhook_payload_schema(self):
        from workpilot.gateway.server import WebhookPayload

        wh = WebhookPayload(event="push", payload={"ref": "refs/heads/main"})
        assert wh.event == "push"
        assert "ref" in wh.payload


# ── Optional: FastAPI endpoint test (skip if FastAPI not installed) ───────────


class TestGatewayEndpoints:
    @pytest.fixture
    def _skip_if_no_fastapi(self):
        try:
            import fastapi  # noqa: F401
            import httpx  # noqa: F401
        except ImportError:
            pytest.skip("FastAPI or httpx not installed")

    @pytest.mark.usefixtures("_skip_if_no_fastapi")
    @pytest.mark.asyncio
    async def test_health_endpoint(self):
        from httpx import ASGITransport, AsyncClient

        from workpilot.config.schema import GatewayConfig
        from workpilot.gateway.server import GatewayServer

        config = GatewayConfig(enabled=True, api_key=None)
        runtime_mock = MagicMock()
        server = GatewayServer(config, runtime_mock)

        async with AsyncClient(
            transport=ASGITransport(app=server.app), base_url="http://test"
        ) as client:
            resp = await client.get("/health")
            assert resp.status_code == 200
            data = resp.json()
            assert data["status"] == "ok"


# ── /api/status cloud channel payload ────────────────────────────────────────


def _make_runtime(*, cloud_url: str = "", teams_app_url: str = "", cloud_connected: bool = False):
    """Build a minimal runtime mock for /api/status tests."""
    from workpilot.config.schema import AppConfig

    cfg = AppConfig()
    cfg.channels.cloud.url = cloud_url
    cfg.channels.cloud.teams_app_url = teams_app_url

    cloud_chan_mock = MagicMock()
    cloud_chan_mock.is_connected = cloud_connected

    rt = MagicMock()
    rt.config = cfg
    rt.estop.is_halted = False
    rt.estop.status.return_value = {"halted": False, "reason": None}
    rt.tool_registry.list_tools.return_value = []
    rt.session_manager.list_sessions.return_value = []
    rt.scheduler = None
    rt.bus.inbound_qsize = 0
    rt.bus.outbound_qsize = 0
    rt.channel_manager._channels = {}
    rt.channel_manager.get.return_value = cloud_chan_mock if cloud_url else None
    return rt


class TestStatusChannelPayload:
    @pytest.fixture
    def _skip_if_no_fastapi(self):
        try:
            import fastapi  # noqa: F401
            import httpx  # noqa: F401
        except ImportError:
            pytest.skip("FastAPI or httpx not installed")

    async def _get_channels(self, runtime) -> list:
        from httpx import ASGITransport, AsyncClient

        from workpilot.gateway.server import GatewayServer

        config = GatewayConfig(enabled=True, api_key=None)
        server = GatewayServer(config, runtime)
        async with AsyncClient(
            transport=ASGITransport(app=server.app), base_url="http://test"
        ) as client:
            resp = await client.get("/api/status")
            assert resp.status_code == 200
            return resp.json()["channels"]

    @pytest.mark.usefixtures("_skip_if_no_fastapi")
    @pytest.mark.asyncio
    async def test_no_cloud_url_no_chips(self):
        """Cloud chips are hidden when cloud.url is not configured."""
        channels = await self._get_channels(_make_runtime(cloud_url=""))
        names = [c["name"] for c in channels]
        assert "Web Chat (Cloud)" not in names
        assert "Teams (Cloud)" not in names

    @pytest.mark.usefixtures("_skip_if_no_fastapi")
    @pytest.mark.asyncio
    async def test_cloud_configured_but_disconnected(self):
        """Both chips present and connected=False when cloud is configured but offline."""
        channels = await self._get_channels(
            _make_runtime(
                cloud_url="wss://example.com/connect",
                teams_app_url="https://teams.example.com/app",
                cloud_connected=False,
            )
        )
        by_name = {c["name"]: c for c in channels}
        assert "Web Chat (Cloud)" in by_name
        assert "Teams (Cloud)" in by_name
        assert by_name["Web Chat (Cloud)"]["connected"] is False
        assert by_name["Teams (Cloud)"]["connected"] is False

    @pytest.mark.usefixtures("_skip_if_no_fastapi")
    @pytest.mark.asyncio
    async def test_cloud_connected_with_teams_url(self):
        """Both chips connected=True when WebSocket is live and teams_app_url is set."""
        channels = await self._get_channels(
            _make_runtime(
                cloud_url="wss://example.com/connect",
                teams_app_url="https://teams.example.com/app",
                cloud_connected=True,
            )
        )
        by_name = {c["name"]: c for c in channels}
        assert by_name["Web Chat (Cloud)"]["connected"] is True
        assert by_name["Teams (Cloud)"]["connected"] is True

    @pytest.mark.usefixtures("_skip_if_no_fastapi")
    @pytest.mark.asyncio
    async def test_teams_chip_disconnected_without_teams_url(self):
        """Teams chip connected=False when teams_app_url is not set, even if cloud is live."""
        channels = await self._get_channels(
            _make_runtime(
                cloud_url="wss://example.com/connect",
                teams_app_url="",
                cloud_connected=True,
            )
        )
        by_name = {c["name"]: c for c in channels}
        assert by_name["Web Chat (Cloud)"]["connected"] is True
        assert by_name["Teams (Cloud)"]["connected"] is False

    @pytest.mark.usefixtures("_skip_if_no_fastapi")
    @pytest.mark.asyncio
    async def test_webchat_url_derived_from_connect_url(self):
        """Web Chat (Cloud) url is derived from wss:// → https:// connect URL."""
        channels = await self._get_channels(
            _make_runtime(cloud_url="wss://example.com/connect", cloud_connected=True)
        )
        by_name = {c["name"]: c for c in channels}
        assert by_name["Web Chat (Cloud)"]["url"] == "https://example.com/chat"
