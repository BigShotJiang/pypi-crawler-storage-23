"""Tests for LLM response streaming through the agent loop.

Covers:
- LLMChunk dataclass
- LLMProvider.stream() default fallback
- LiteLLMProvider.stream() delegation
- AgentLoop streaming for text-only responses
- AgentLoop non-streaming when tools are present
- StreamingChunk publication to the bus
- CLIChannel streaming chunk handling
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

from workpilot.agent.loop import AgentLoop
from workpilot.agent.tools.base import Tool, ToolMetadata
from workpilot.agent.tools.registry import ToolRegistry
from workpilot.bus.events import OutboundMessage, StreamingChunk
from workpilot.bus.queue import MessageBus
from workpilot.channels.cli import CLIChannel
from workpilot.config.schema import AgentConfig, AuditConfig
from workpilot.providers.base import LLMChunk, LLMProvider, LLMResponse, ToolCallRequest
from workpilot.security.audit import AuditLogger
from workpilot.session.manager import SessionManager

# ── Helpers ──────────────────────────────────────────────────────────────────


class EchoTool(Tool):
    @property
    def name(self) -> str:
        return "echo"

    @property
    def description(self) -> str:
        return "Echo the input"

    @property
    def parameters(self) -> dict:
        return {"type": "object", "properties": {"text": {"type": "string"}}, "required": ["text"]}

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(risk_level="low", approval="never")

    async def execute(self, **kwargs) -> str:
        return f"echo: {kwargs['text']}"


def _make_registry(*tools: Tool) -> ToolRegistry:
    reg = ToolRegistry(AuditLogger(AuditConfig(enabled=False)))
    for t in tools:
        reg.register(t)
    return reg


def _make_loop(
    provider: AsyncMock,
    tmp_path: Path,
    *,
    tools: list[Tool] | None = None,
    config: AgentConfig | None = None,
) -> AgentLoop:
    registry = _make_registry(*(tools or [EchoTool()]))
    return AgentLoop(
        config=config or AgentConfig(max_iterations=40),
        provider=provider,
        tool_registry=registry,
        bus=MessageBus(),
        session_manager=SessionManager(tmp_path),
        audit=AuditLogger(AuditConfig(enabled=False)),
        workspace=tmp_path,
    )


def _tc(name: str, args: dict, tc_id: str = "tc1") -> ToolCallRequest:
    return ToolCallRequest(id=tc_id, name=name, arguments=args)


# ── LLMChunk dataclass ──────────────────────────────────────────────────────


class TestLLMChunk:
    def test_defaults(self):
        chunk = LLMChunk()
        assert chunk.content == ""
        assert chunk.tool_calls == []
        assert chunk.finish_reason is None
        assert chunk.model == ""

    def test_with_content(self):
        chunk = LLMChunk(content="Hello", finish_reason="stop", model="gpt-4o")
        assert chunk.content == "Hello"
        assert chunk.finish_reason == "stop"
        assert chunk.model == "gpt-4o"


# ── LLMProvider.stream() default fallback ────────────────────────────────────


class TestLLMProviderStreamFallback:
    @pytest.mark.asyncio
    async def test_default_stream_falls_back_to_complete(self):
        """Base LLMProvider.stream() yields a single chunk from complete()."""
        provider = LLMProvider()
        provider.complete = AsyncMock(
            return_value=LLMResponse(
                content="hello world",
                finish_reason="stop",
                model="test-model",
            )
        )

        chunks = []
        async for chunk in provider.stream(
            model="test-model",
            messages=[{"role": "user", "content": "hi"}],
        ):
            chunks.append(chunk)

        assert len(chunks) == 1
        assert chunks[0].content == "hello world"
        assert chunks[0].finish_reason == "stop"
        assert chunks[0].model == "test-model"


# ── Agent loop streaming ────────────────────────────────────────────────────


class TestAgentLoopStreaming:
    @pytest.mark.asyncio
    async def test_stream_used_for_text_only_response_with_channel(self, tmp_path):
        """When channel info is provided and no tools needed, stream() is used."""

        async def mock_stream(**kwargs):
            yield LLMChunk(content="Hello ", model="test")
            yield LLMChunk(content="world!", finish_reason="stop", model="test")

        provider = AsyncMock()
        provider.stream = mock_stream
        # complete should not be called for text-only with channel info
        provider.complete = AsyncMock()

        loop = _make_loop(provider, tmp_path)

        # Collect streaming chunks dispatched to handlers (dispatch_outbound)
        chunks: list[StreamingChunk] = []

        async def capture(msg):
            if isinstance(msg, StreamingChunk):
                chunks.append(msg)

        loop._bus.on_outbound(capture)

        result = await loop.run_once("hi", channel="cli", channel_id="terminal")

        assert result == "Hello world!"
        # Should have 3 chunks: "Hello ", "world!", and done marker
        assert len(chunks) == 3
        assert chunks[0].content == "Hello "
        assert chunks[0].done is False
        assert chunks[1].content == "world!"
        assert chunks[1].done is False
        assert chunks[2].content == ""
        assert chunks[2].done is True
        # complete() should NOT have been called
        provider.complete.assert_not_called()

    @pytest.mark.asyncio
    async def test_complete_used_without_channel_info(self, tmp_path):
        """Without channel info, falls back to complete() (no streaming)."""
        provider = AsyncMock()
        provider.complete = AsyncMock(return_value=LLMResponse(content="Just text", tool_calls=[]))

        loop = _make_loop(provider, tmp_path)
        result = await loop.run_once("hi")

        assert result == "Just text"
        provider.complete.assert_called_once()

    @pytest.mark.asyncio
    async def test_complete_used_when_tools_available(self, tmp_path):
        """When tools are available (first iteration), complete() is used even with channel."""
        provider = AsyncMock()
        provider.complete = AsyncMock(
            return_value=LLMResponse(content="Used tools path", tool_calls=[])
        )

        # Config must include "echo" in tools list so tool_schemas is non-empty
        loop = _make_loop(provider, tmp_path, config=AgentConfig(max_iterations=40, tools=["echo"]))
        result = await loop.run_once("hi", channel="cli", channel_id="terminal")

        # On first iteration, tools_for_call is not None (tools are registered),
        # so complete() is used, not stream()
        assert result == "Used tools path"
        provider.complete.assert_called_once()

    @pytest.mark.asyncio
    async def test_stream_chunks_carry_channel_info(self, tmp_path):
        """StreamingChunks published to bus carry correct channel/channel_id."""

        async def mock_stream(**kwargs):
            yield LLMChunk(content="data", finish_reason="stop", model="test")

        provider = AsyncMock()
        provider.stream = mock_stream
        provider.complete = AsyncMock()

        # Use no tools so forced text path is taken even on iteration 1
        loop = _make_loop(provider, tmp_path, tools=[])

        chunks: list[StreamingChunk] = []

        async def capture(msg):
            if isinstance(msg, StreamingChunk):
                chunks.append(msg)

        loop._bus.on_outbound(capture)

        await loop.run_once("hi", channel="web", channel_id="ws-123")

        assert all(c.channel == "web" for c in chunks)
        assert all(c.channel_id == "ws-123" for c in chunks)

    @pytest.mark.asyncio
    async def test_tool_call_then_stream_final(self, tmp_path):
        """Tool call iteration uses complete(), final text iteration uses stream()."""

        async def mock_stream(**kwargs):
            yield LLMChunk(content="Done!", finish_reason="stop", model="test")

        provider = AsyncMock()
        provider.complete = AsyncMock(
            return_value=LLMResponse(
                content="",
                tool_calls=[_tc("echo", {"text": "ping"})],
            )
        )
        provider.stream = mock_stream

        loop = _make_loop(provider, tmp_path, config=AgentConfig(max_iterations=40, tools=["echo"]))

        # After the first complete() returns tool calls, the second iteration
        # will also use complete() because tools are still available.
        # We need to make complete() return text on the second call.
        provider.complete = AsyncMock(
            side_effect=[
                LLMResponse(content="", tool_calls=[_tc("echo", {"text": "ping"})]),
                LLMResponse(content="Final answer", tool_calls=[]),
            ]
        )

        result = await loop.run_once("do it", channel="cli", channel_id="t")

        # The second call still has tools available (iteration < max-1),
        # so complete() is used for both. Stream is only used when tools=None.
        assert result == "Final answer"
        assert provider.complete.call_count == 2


# ── CLI channel streaming ────────────────────────────────────────────────────


class TestCLIChannelStreaming:
    @pytest.mark.asyncio
    async def test_handle_outbound_streaming_chunk(self, monkeypatch):
        """CLIChannel writes streaming tokens to stdout."""
        written: list[str] = []
        flushed = [0]

        mock_stdout = MagicMock()
        mock_stdout.write = lambda s: written.append(s)
        mock_stdout.flush = lambda: flushed.__setitem__(0, flushed[0] + 1)
        monkeypatch.setattr("workpilot.channels.cli.sys.stdout", mock_stdout)

        bus = MessageBus()
        channel = CLIChannel(bus)

        # First chunk: starts streaming
        await channel._handle_outbound(
            StreamingChunk(channel="cli", channel_id="t", content="Hello ")
        )
        assert "\nassistant> " in written
        assert "Hello " in written

        # Second chunk
        await channel._handle_outbound(
            StreamingChunk(channel="cli", channel_id="t", content="world!")
        )
        assert "world!" in written

        # Done marker: ends streaming
        await channel._handle_outbound(
            StreamingChunk(channel="cli", channel_id="t", content="", done=True)
        )
        assert "\n\n" in written
        assert channel._streaming is False

    @pytest.mark.asyncio
    async def test_handle_outbound_ignores_other_channels(self, monkeypatch):
        """CLIChannel ignores StreamingChunks for other channels."""
        written: list[str] = []
        mock_stdout = MagicMock()
        mock_stdout.write = lambda s: written.append(s)
        mock_stdout.flush = lambda: None
        monkeypatch.setattr("workpilot.channels.cli.sys.stdout", mock_stdout)

        bus = MessageBus()
        channel = CLIChannel(bus)

        await channel._handle_outbound(
            StreamingChunk(channel="web", channel_id="ws-1", content="ignored")
        )
        assert len(written) == 0

    @pytest.mark.asyncio
    async def test_handle_outbound_full_message_no_crash(self):
        """CLIChannel._handle_outbound handles OutboundMessage without crash."""
        bus = MessageBus()
        channel = CLIChannel(bus)

        # Should not raise for OutboundMessage (not a StreamingChunk)
        await channel._handle_outbound(
            OutboundMessage(channel="cli", channel_id="t", content="full message")
        )


# ── Channel manager streaming dispatch ───────────────────────────────────────


class TestChannelManagerStreaming:
    @pytest.mark.asyncio
    async def test_streaming_chunks_not_dispatched_as_send(self):
        """ChannelManager skips StreamingChunks (channels handle them directly)."""
        from workpilot.channels.manager import ChannelManager

        bus = MessageBus()
        manager = ChannelManager(bus)

        mock_channel = AsyncMock()
        mock_channel.name = "cli"
        manager._channels["cli"] = mock_channel

        # Publish a StreamingChunk — send() should NOT be called
        await manager._dispatch_outbound(
            StreamingChunk(channel="cli", channel_id="t", content="chunk")
        )
        mock_channel.send.assert_not_called()

        # Publish OutboundMessage — send() SHOULD be called
        await manager._dispatch_outbound(
            OutboundMessage(channel="cli", channel_id="t", content="full")
        )
        mock_channel.send.assert_called_once()
