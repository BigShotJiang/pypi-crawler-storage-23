"""Tests for the MCP (Model Context Protocol) client, server, and transport modules."""

import pytest

from workpilot.agent.tools.base import Tool
from workpilot.agent.tools.registry import ToolRegistry
from workpilot.mcp.server import MCPServer
from workpilot.mcp.transport import HttpTransport, StdioTransport

# ── Test helpers: mock tools ─────────────────────────────────────────────────


class MockTool(Tool):
    """A simple mock tool for testing the MCP server."""

    def __init__(self, name: str = "mock_tool", description: str = "A mock tool"):
        self._name = name
        self._description = description

    @property
    def name(self) -> str:
        return self._name

    @property
    def description(self) -> str:
        return self._description

    @property
    def parameters(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "input": {"type": "string", "description": "Input text"},
            },
            "required": ["input"],
        }

    async def execute(self, **kwargs) -> str:
        return f"Result: {kwargs.get('input', 'none')}"


def _make_server_with_tools() -> MCPServer:
    """Create an MCPServer with a mock tool registry."""
    registry = ToolRegistry()
    registry.register(MockTool("read_file", "Read a file"))
    registry.register(MockTool("write_file", "Write a file"))
    return MCPServer(registry)


# ── MCPServer handle_request ─────────────────────────────────────────────────


class TestMCPServer:
    @pytest.mark.asyncio
    async def test_initialize_handshake(self):
        server = _make_server_with_tools()
        response = await server.handle_request(
            {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "initialize",
                "params": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {},
                    "clientInfo": {"name": "test-client", "version": "1.0"},
                },
            }
        )

        assert response["jsonrpc"] == "2.0"
        assert response["id"] == 1
        assert "result" in response
        result = response["result"]
        assert result["protocolVersion"] == "2024-11-05"
        assert "serverInfo" in result
        assert result["serverInfo"]["name"] == "workpilot"

    @pytest.mark.asyncio
    async def test_tools_list(self):
        server = _make_server_with_tools()
        response = await server.handle_request(
            {
                "jsonrpc": "2.0",
                "id": 2,
                "method": "tools/list",
                "params": {},
            }
        )

        assert response["id"] == 2
        result = response["result"]
        tools = result["tools"]
        assert len(tools) == 2
        names = {t["name"] for t in tools}
        assert "read_file" in names
        assert "write_file" in names
        # Each tool should have inputSchema
        for tool in tools:
            assert "inputSchema" in tool
            assert "description" in tool

    @pytest.mark.asyncio
    async def test_tools_call_success(self):
        server = _make_server_with_tools()
        response = await server.handle_request(
            {
                "jsonrpc": "2.0",
                "id": 3,
                "method": "tools/call",
                "params": {
                    "name": "read_file",
                    "arguments": {"input": "hello world"},
                },
            }
        )

        assert response["id"] == 3
        result = response["result"]
        assert "content" in result
        assert len(result["content"]) == 1
        assert result["content"][0]["type"] == "text"
        assert "Result: hello world" in result["content"][0]["text"]

    @pytest.mark.asyncio
    async def test_tools_call_unknown_tool(self):
        server = _make_server_with_tools()
        response = await server.handle_request(
            {
                "jsonrpc": "2.0",
                "id": 4,
                "method": "tools/call",
                "params": {
                    "name": "nonexistent_tool",
                    "arguments": {},
                },
            }
        )

        assert response["id"] == 4
        assert "error" in response
        assert response["error"]["code"] == -32603

    @pytest.mark.asyncio
    async def test_tools_call_missing_name(self):
        server = _make_server_with_tools()
        response = await server.handle_request(
            {
                "jsonrpc": "2.0",
                "id": 5,
                "method": "tools/call",
                "params": {"arguments": {}},
            }
        )

        assert "error" in response

    @pytest.mark.asyncio
    async def test_unknown_method(self):
        server = _make_server_with_tools()
        response = await server.handle_request(
            {
                "jsonrpc": "2.0",
                "id": 6,
                "method": "some/unknown/method",
                "params": {},
            }
        )

        assert response["id"] == 6
        assert "error" in response
        assert response["error"]["code"] == -32601
        assert "not found" in response["error"]["message"].lower()

    @pytest.mark.asyncio
    async def test_notification_no_id_returns_empty(self):
        server = _make_server_with_tools()
        response = await server.handle_request(
            {
                "jsonrpc": "2.0",
                "method": "notifications/initialized",
                "params": {},
            }
        )
        assert response == {}

    @pytest.mark.asyncio
    async def test_custom_server_name(self):
        registry = ToolRegistry()
        server = MCPServer(registry, server_name="my-agent", server_version="2.0.0")
        response = await server.handle_request(
            {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "initialize",
                "params": {},
            }
        )
        info = response["result"]["serverInfo"]
        assert info["name"] == "my-agent"
        assert info["version"] == "2.0.0"


# ── MCPServer response helpers ───────────────────────────────────────────────


class TestMCPServerResponses:
    def test_success_response_format(self):
        resp = MCPServer._success_response(42, {"key": "value"})
        assert resp["jsonrpc"] == "2.0"
        assert resp["id"] == 42
        assert resp["result"]["key"] == "value"

    def test_error_response_format(self):
        resp = MCPServer._error_response(42, -32600, "Invalid Request")
        assert resp["jsonrpc"] == "2.0"
        assert resp["id"] == 42
        assert resp["error"]["code"] == -32600
        assert resp["error"]["message"] == "Invalid Request"

    def test_error_response_with_none_id(self):
        resp = MCPServer._error_response(None, -32700, "Parse error")
        assert resp["id"] is None


# ── Transport abstractions ───────────────────────────────────────────────────


class TestStdioTransport:
    def test_initialization(self):
        transport = StdioTransport("node", args=["server.js"])
        assert transport._command == "node"
        assert transport._args == ["server.js"]

    def test_default_args(self):
        transport = StdioTransport("python")
        assert transport._args == []

    def test_is_running_false_initially(self):
        transport = StdioTransport("echo")
        assert transport.is_running is False


class TestHttpTransport:
    def test_initialization(self):
        transport = HttpTransport("https://mcp.example.com/api")
        assert transport._url == "https://mcp.example.com/api"

    def test_url_trailing_slash_stripped(self):
        transport = HttpTransport("https://mcp.example.com/api/")
        assert transport._url == "https://mcp.example.com/api"

    def test_headers_stored(self):
        transport = HttpTransport(
            "https://mcp.example.com/api",
            headers={"Authorization": "Bearer token123"},
        )
        assert transport._headers["Authorization"] == "Bearer token123"

    def test_default_headers_empty(self):
        transport = HttpTransport("https://mcp.example.com/api")
        assert transport._headers == {}

    def test_parse_sse_event_valid(self):
        block = 'data: {"jsonrpc": "2.0", "id": 1, "result": {}}'
        result = HttpTransport._parse_sse_event(block)
        assert result is not None
        assert result["jsonrpc"] == "2.0"

    def test_parse_sse_event_multiline(self):
        block = 'data: {"jsonrpc": "2.0",\ndata:  "id": 1,\ndata:  "result": {}}'
        # Multi-line data merging: lines are joined
        result = HttpTransport._parse_sse_event(block)
        assert result is not None

    def test_parse_sse_event_no_data(self):
        block = "event: ping"
        result = HttpTransport._parse_sse_event(block)
        assert result is None

    def test_parse_sse_event_invalid_json(self):
        block = "data: not-valid-json"
        result = HttpTransport._parse_sse_event(block)
        assert result is None
