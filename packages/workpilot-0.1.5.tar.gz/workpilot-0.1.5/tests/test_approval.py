"""Tests for the ApprovalManager and approval workflow module."""

from datetime import UTC, datetime, timedelta

import pytest

from workpilot.config.schema import ApprovalConfig, AutonomyLevel
from workpilot.security.approval import ApprovalManager, ApprovalRequest, ApprovalStatus

# ── Helpers ──────────────────────────────────────────────────────────────────


def _make_manager(timeout_seconds: int = 900) -> ApprovalManager:
    """Create an ApprovalManager with a given timeout."""
    config = ApprovalConfig(timeout_seconds=timeout_seconds)
    return ApprovalManager(config)


# ── ApprovalRequest dataclass ────────────────────────────────────────────────


class TestApprovalRequest:
    def test_default_status_is_pending(self):
        req = ApprovalRequest()
        assert req.status == ApprovalStatus.PENDING

    def test_default_has_uuid(self):
        req = ApprovalRequest()
        assert isinstance(req.id, str)
        assert len(req.id) == 32  # uuid4().hex length

    def test_default_autonomy_level_is_approval(self):
        req = ApprovalRequest()
        assert req.autonomy_level == AutonomyLevel.APPROVAL

    def test_created_at_is_set(self):
        req = ApprovalRequest()
        assert isinstance(req.created_at, datetime)

    def test_resolved_at_is_none_initially(self):
        req = ApprovalRequest()
        assert req.resolved_at is None


# ── Creating approval requests ───────────────────────────────────────────────


class TestRequestApproval:
    @pytest.mark.asyncio
    async def test_request_returns_pending_request(self):
        mgr = _make_manager()
        req = await mgr.request_approval(
            tool_name="shell",
            args={"command": "rm -rf /tmp/test"},
            agent_name="code-bot",
            channel="teams",
        )
        assert req.status == ApprovalStatus.PENDING
        assert req.tool_name == "shell"
        assert req.agent_name == "code-bot"
        assert req.channel == "teams"

    @pytest.mark.asyncio
    async def test_request_is_tracked_in_pending(self):
        mgr = _make_manager()
        req = await mgr.request_approval(
            tool_name="git",
            args={},
            agent_name="bot",
            channel="cli",
        )
        pending = mgr.get_pending()
        assert len(pending) == 1
        assert pending[0].id == req.id

    @pytest.mark.asyncio
    async def test_multiple_requests_tracked(self):
        mgr = _make_manager()
        await mgr.request_approval("shell", {}, "bot", "cli")
        await mgr.request_approval("git", {}, "bot", "cli")
        pending = mgr.get_pending()
        assert len(pending) == 2


# ── Resolving requests ───────────────────────────────────────────────────────


class TestResolve:
    @pytest.mark.asyncio
    async def test_approve_changes_status(self):
        mgr = _make_manager()
        req = await mgr.request_approval("shell", {}, "bot", "cli")
        mgr.resolve(req.id, approved=True, resolver="admin@example.com")
        assert req.status == ApprovalStatus.APPROVED
        assert req.resolver == "admin@example.com"
        assert req.resolved_at is not None

    @pytest.mark.asyncio
    async def test_deny_changes_status(self):
        mgr = _make_manager()
        req = await mgr.request_approval("shell", {}, "bot", "cli")
        mgr.resolve(req.id, approved=False, resolver="admin@example.com")
        assert req.status == ApprovalStatus.DENIED

    @pytest.mark.asyncio
    async def test_resolved_request_removed_from_pending(self):
        mgr = _make_manager()
        req = await mgr.request_approval("shell", {}, "bot", "cli")
        mgr.resolve(req.id, approved=True, resolver="admin")
        assert len(mgr.get_pending()) == 0

    @pytest.mark.asyncio
    async def test_resolve_unknown_id_raises_key_error(self):
        mgr = _make_manager()
        with pytest.raises(KeyError, match="Approval request not found"):
            mgr.resolve("nonexistent-id", approved=True, resolver="admin")

    @pytest.mark.asyncio
    async def test_resolve_already_resolved_raises_value_error(self):
        mgr = _make_manager()
        req = await mgr.request_approval("shell", {}, "bot", "cli")
        # Keep a reference before it's removed from pending
        req_id = req.id
        mgr.resolve(req_id, approved=True, resolver="admin")
        # Now the request is removed from pending dict entirely
        # So resolving again should raise KeyError (not found)
        with pytest.raises(KeyError):
            mgr.resolve(req_id, approved=False, resolver="admin2")


# ── Timeout checking ─────────────────────────────────────────────────────────


class TestTimeout:
    @pytest.mark.asyncio
    async def test_not_timed_out_returns_false(self):
        mgr = _make_manager(timeout_seconds=900)
        req = await mgr.request_approval("shell", {}, "bot", "cli")
        assert mgr.check_timeout(req.id) is False

    @pytest.mark.asyncio
    async def test_timed_out_returns_true_and_marks_status(self):
        mgr = _make_manager(timeout_seconds=1)  # 1 second timeout
        req = await mgr.request_approval("shell", {}, "bot", "cli")
        # Manually set created_at to the past to simulate timeout
        req.created_at = datetime.now(UTC) - timedelta(seconds=10)
        assert mgr.check_timeout(req.id) is True
        assert req.status == ApprovalStatus.TIMEOUT
        assert req.resolved_at is not None

    @pytest.mark.asyncio
    async def test_timed_out_removed_from_pending(self):
        mgr = _make_manager(timeout_seconds=1)
        req = await mgr.request_approval("shell", {}, "bot", "cli")
        req.created_at = datetime.now(UTC) - timedelta(seconds=10)
        mgr.check_timeout(req.id)
        assert len(mgr.get_pending()) == 0

    def test_check_timeout_unknown_id_returns_false(self):
        mgr = _make_manager()
        assert mgr.check_timeout("nonexistent-id") is False


# ── get_pending sweeps timeouts ──────────────────────────────────────────────


class TestGetPending:
    @pytest.mark.asyncio
    async def test_get_pending_sweeps_expired(self):
        mgr = _make_manager(timeout_seconds=1)
        req1 = await mgr.request_approval("shell", {}, "bot", "cli")
        req2 = await mgr.request_approval("git", {}, "bot", "cli")

        # Expire req1 only
        req1.created_at = datetime.now(UTC) - timedelta(seconds=10)

        pending = mgr.get_pending()
        assert len(pending) == 1
        assert pending[0].id == req2.id
