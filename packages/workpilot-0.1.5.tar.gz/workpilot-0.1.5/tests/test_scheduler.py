"""Tests for SchedulerService — cron, interval, event triggers + heartbeat."""

from __future__ import annotations

import asyncio
import json
from unittest.mock import AsyncMock, MagicMock

import pytest

from workpilot.agent.tools.cron import CronTool
from workpilot.bus.queue import MessageBus
from workpilot.config.schema import CronConfig, CronJobConfig, HeartbeatConfig
from workpilot.cron.service import SchedulerService, _detect_trigger_type, _Job, _parse_at_schedule

# ── Trigger detection ────────────────────────────────────────────────────────


class TestTriggerDetection:
    def test_cron_expression(self):
        assert _detect_trigger_type("0 9 * * 1-5") == "cron"

    def test_interval_int(self):
        assert _detect_trigger_type(3600) == "interval"

    def test_event_with_dot(self):
        assert _detect_trigger_type("tool.failed") == "event"
        assert _detect_trigger_type("security.leak") == "event"

    def test_cron_not_confused_with_event(self):
        # Cron expression has spaces and numbers
        assert _detect_trigger_type("*/5 * * * *") == "cron"


# ── SchedulerService lifecycle ───────────────────────────────────────────────


class TestSchedulerLifecycle:
    def test_init_loads_config_jobs(self, tmp_path):
        config = CronConfig(
            enabled=True,
            jobs={
                "daily": CronJobConfig(schedule="0 9 * * *", prompt="report"),
            },
        )
        svc = SchedulerService(config, tmp_path)
        assert "daily" in svc._jobs
        assert svc._jobs["daily"].prompt == "report"

    def test_init_disabled_is_noop(self, tmp_path):
        config = CronConfig(enabled=False)
        svc = SchedulerService(config, tmp_path)
        assert not svc._running

    def test_health_before_start(self, tmp_path):
        config = CronConfig(
            enabled=True, jobs={"j1": CronJobConfig(schedule="0 * * * *", prompt="x")}
        )
        svc = SchedulerService(config, tmp_path)
        h = svc.health()
        assert h["running"] is False
        assert h["total_jobs"] == 1
        assert h["active_jobs"] == 1


# ── Job CRUD ─────────────────────────────────────────────────────────────────


class TestJobCRUD:
    def test_add_job(self, tmp_path):
        config = CronConfig(enabled=True)
        svc = SchedulerService(config, tmp_path)
        svc.add_job("test", 3600, "do stuff", dynamic=True)
        assert "test" in svc._jobs
        assert svc._jobs["test"].dynamic is True

    def test_remove_job(self, tmp_path):
        config = CronConfig(enabled=True, jobs={"j1": CronJobConfig(schedule=60, prompt="x")})
        svc = SchedulerService(config, tmp_path)
        svc.remove_job("j1")
        assert "j1" not in svc._jobs

    def test_enable_disable(self, tmp_path):
        config = CronConfig(enabled=True, jobs={"j1": CronJobConfig(schedule=60, prompt="x")})
        svc = SchedulerService(config, tmp_path)
        svc.disable("j1")
        assert svc._jobs["j1"].enabled is False
        svc.enable("j1")
        assert svc._jobs["j1"].enabled is True
        assert svc._jobs["j1"].failure_count == 0  # reset on enable

    def test_list_jobs(self, tmp_path):
        config = CronConfig(
            enabled=True,
            jobs={
                "cron_job": CronJobConfig(schedule="0 9 * * *", prompt="report"),
                "interval_job": CronJobConfig(schedule=3600, prompt="check"),
            },
        )
        svc = SchedulerService(config, tmp_path)
        jobs = svc.list_jobs()
        assert len(jobs) == 2
        names = {j["name"] for j in jobs}
        assert names == {"cron_job", "interval_job"}
        types = {j["trigger_type"] for j in jobs}
        assert "cron" in types
        assert "interval" in types


# ── Job execution ────────────────────────────────────────────────────────────


class TestJobExecution:
    @pytest.mark.asyncio
    async def test_execute_job_calls_run_once(self, tmp_path):
        config = CronConfig(enabled=True)
        svc = SchedulerService(config, tmp_path)

        mock_agent = AsyncMock()
        mock_agent.run_once = AsyncMock(return_value="done")
        svc.set_agent_loop(mock_agent)

        job = _Job(name="test", schedule=60, agent="default", prompt="do it")
        result = await svc._execute_job(job)

        assert result == "done"
        mock_agent.run_once.assert_called_once()
        call_args = mock_agent.run_once.call_args
        assert call_args[0][0] == "do it"
        assert call_args[1]["session_id"].startswith("scheduler:test:")

    @pytest.mark.asyncio
    async def test_persistent_session_mode(self, tmp_path):
        config = CronConfig(enabled=True)
        svc = SchedulerService(config, tmp_path)

        mock_agent = AsyncMock()
        mock_agent.run_once = AsyncMock(return_value="ok")
        svc.set_agent_loop(mock_agent)

        job = _Job(
            name="monitor", schedule=60, agent="default", prompt="check", session_mode="persistent"
        )
        await svc._execute_job(job)

        session_id = mock_agent.run_once.call_args[1]["session_id"]
        assert session_id == "scheduler:monitor"  # no run_id suffix

    @pytest.mark.asyncio
    async def test_execute_without_agent_loop(self, tmp_path):
        config = CronConfig(enabled=True)
        svc = SchedulerService(config, tmp_path)
        # No agent loop set
        job = _Job(name="test", schedule=60, agent="default", prompt="x")
        result = await svc._execute_job(job)
        assert result is None

    @pytest.mark.asyncio
    async def test_failure_increments_counter(self, tmp_path):
        config = CronConfig(enabled=True)
        svc = SchedulerService(config, tmp_path)

        mock_agent = AsyncMock()
        mock_agent.run_once = AsyncMock(side_effect=RuntimeError("boom"))
        svc.set_agent_loop(mock_agent)

        job = _Job(name="fail", schedule=60, agent="default", prompt="x")
        svc._jobs["fail"] = job

        await svc._execute_job(job)
        assert job.failure_count == 1

    @pytest.mark.asyncio
    async def test_auto_disable_after_max_failures(self, tmp_path):
        config = CronConfig(enabled=True)
        svc = SchedulerService(config, tmp_path)

        mock_agent = AsyncMock()
        mock_agent.run_once = AsyncMock(side_effect=RuntimeError("boom"))
        svc.set_agent_loop(mock_agent)

        job = _Job(name="unstable", schedule=60, agent="default", prompt="x")
        job.failure_count = 4  # one more will hit MAX_CONSECUTIVE_FAILURES=5
        svc._jobs["unstable"] = job

        await svc._execute_job(job)
        assert job.enabled is False  # auto-disabled


# ── Run history ──────────────────────────────────────────────────────────────


class TestRunHistory:
    @pytest.mark.asyncio
    async def test_run_recorded(self, tmp_path):
        config = CronConfig(enabled=True)
        svc = SchedulerService(config, tmp_path)

        mock_agent = AsyncMock()
        mock_agent.run_once = AsyncMock(return_value="result text")
        svc.set_agent_loop(mock_agent)

        job = _Job(name="hist", schedule=60, agent="default", prompt="x")
        await svc._execute_job(job)

        history = svc.get_history("hist")
        assert len(history) == 1
        assert history[0]["status"] == "success"
        assert "result text" in history[0]["result_preview"]

    @pytest.mark.asyncio
    async def test_failure_recorded(self, tmp_path):
        config = CronConfig(enabled=True)
        svc = SchedulerService(config, tmp_path)

        mock_agent = AsyncMock()
        mock_agent.run_once = AsyncMock(side_effect=RuntimeError("fail"))
        svc.set_agent_loop(mock_agent)

        job = _Job(name="fhist", schedule=60, agent="default", prompt="x")
        svc._jobs["fhist"] = job
        await svc._execute_job(job)

        history = svc.get_history("fhist")
        assert len(history) == 1
        assert history[0]["status"] == "failed"

    def test_empty_history(self, tmp_path):
        config = CronConfig(enabled=True)
        svc = SchedulerService(config, tmp_path)
        assert svc.get_history("nonexistent") == []


# ── Heartbeat ────────────────────────────────────────────────────────────────


class TestHeartbeat:
    def test_heartbeat_config_defaults(self):
        hb = HeartbeatConfig()
        assert hb.enabled is True
        assert hb.interval == 1800

    def test_heartbeat_md_read(self, tmp_path):
        (tmp_path / "HEARTBEAT.md").write_text("- Check CI\n- Check PRs", encoding="utf-8")
        config = CronConfig(enabled=True, heartbeat=HeartbeatConfig(enabled=True, interval=60))
        SchedulerService(config, tmp_path)  # loads config, verifies no crash
        heartbeat_md = tmp_path / "HEARTBEAT.md"
        assert heartbeat_md.read_text(encoding="utf-8") == "- Check CI\n- Check PRs"

    @pytest.mark.asyncio
    async def test_heartbeat_execution(self, tmp_path):
        (tmp_path / "HEARTBEAT.md").write_text("- Monitor CI pipeline", encoding="utf-8")
        config = CronConfig(enabled=True, heartbeat=HeartbeatConfig(enabled=True, interval=60))
        svc = SchedulerService(config, tmp_path)

        mock_agent = AsyncMock()
        mock_agent.run_once = AsyncMock(return_value="CI is green")
        svc.set_agent_loop(mock_agent)

        # Manually register heartbeat (normally done in start())
        svc._register_heartbeat()
        await svc._execute_heartbeat()

        mock_agent.run_once.assert_called_once()
        prompt = mock_agent.run_once.call_args[0][0]
        assert "Monitor CI pipeline" in prompt

    @pytest.mark.asyncio
    async def test_heartbeat_skips_if_no_file(self, tmp_path):
        config = CronConfig(enabled=True, heartbeat=HeartbeatConfig(enabled=True))
        svc = SchedulerService(config, tmp_path)

        mock_agent = AsyncMock()
        svc.set_agent_loop(mock_agent)

        await svc._execute_heartbeat()
        mock_agent.run_once.assert_not_called()


# ── Dynamic job persistence ──────────────────────────────────────────────────


class TestDynamicPersistence:
    def test_persist_and_reload(self, tmp_path):
        config = CronConfig(enabled=True)
        svc = SchedulerService(config, tmp_path)
        svc.add_job("dyn1", 3600, "task 1", dynamic=True)
        svc.add_job("dyn2", "0 9 * * *", "task 2", dynamic=True)

        # Verify file written
        jobs_file = tmp_path / ".workpilot" / "cron" / "jobs.json"
        assert jobs_file.is_file()
        data = json.loads(jobs_file.read_text(encoding="utf-8"))
        assert len(data) == 2

        # Reload in new service instance
        svc2 = SchedulerService(config, tmp_path)
        assert "dyn1" in svc2._jobs
        assert "dyn2" in svc2._jobs
        assert svc2._jobs["dyn1"].dynamic is True

    def test_config_jobs_take_precedence(self, tmp_path):
        # Write a dynamic job with same name as config job
        cron_dir = tmp_path / ".workpilot" / "cron"
        cron_dir.mkdir(parents=True)
        (cron_dir / "jobs.json").write_text(
            json.dumps([{"name": "overlap", "schedule": 999, "prompt": "dynamic"}]),
            encoding="utf-8",
        )

        config = CronConfig(
            enabled=True,
            jobs={"overlap": CronJobConfig(schedule=60, prompt="config wins")},
        )
        svc = SchedulerService(config, tmp_path)
        assert svc._jobs["overlap"].prompt == "config wins"


# ── CronTool ─────────────────────────────────────────────────────────────────


class TestCronTool:
    def _make_tool(self, tmp_path) -> CronTool:
        config = CronConfig(enabled=True, jobs={"j1": CronJobConfig(schedule=60, prompt="x")})
        svc = SchedulerService(config, tmp_path)
        return CronTool(svc)

    @pytest.mark.asyncio
    async def test_list(self, tmp_path):
        tool = self._make_tool(tmp_path)
        result = await tool.execute(action="list")
        assert "j1" in result
        assert "interval" in result

    @pytest.mark.asyncio
    async def test_add(self, tmp_path):
        tool = self._make_tool(tmp_path)
        result = await tool.execute(action="add", schedule="0 9 * * *", prompt="daily report")
        assert "added" in result.lower()

    @pytest.mark.asyncio
    async def test_remove(self, tmp_path):
        tool = self._make_tool(tmp_path)
        result = await tool.execute(action="remove", job_id="j1")
        assert "removed" in result.lower()

    @pytest.mark.asyncio
    async def test_enable_disable(self, tmp_path):
        tool = self._make_tool(tmp_path)
        result = await tool.execute(action="disable", job_id="j1")
        assert "disabled" in result.lower()
        result = await tool.execute(action="enable", job_id="j1")
        assert "enabled" in result.lower()

    @pytest.mark.asyncio
    async def test_add_missing_params(self, tmp_path):
        tool = self._make_tool(tmp_path)
        result = await tool.execute(action="add")
        assert "error" in result.lower()

    @pytest.mark.asyncio
    async def test_metadata(self, tmp_path):
        tool = self._make_tool(tmp_path)
        assert tool.name == "cron"
        assert tool.metadata.approval == "auto"


# ── Session modes ────────────────────────────────────────────────────────────


class TestSessionModes:
    def test_config_session_mode(self, tmp_path):
        config = CronConfig(
            enabled=True,
            jobs={"j1": CronJobConfig(schedule=60, prompt="x", session_mode="persistent")},
        )
        svc = SchedulerService(config, tmp_path)
        assert svc._jobs["j1"].session_mode == "persistent"

    def test_default_session_mode_is_isolated(self, tmp_path):
        config = CronConfig(enabled=True, jobs={"j1": CronJobConfig(schedule=60, prompt="x")})
        svc = SchedulerService(config, tmp_path)
        assert svc._jobs["j1"].session_mode == "isolated"


# ── Notify channels ──────────────────────────────────────────────────────────


class TestNotifyChannels:
    @pytest.mark.asyncio
    async def test_result_delivered_to_channel(self, tmp_path):
        bus = MessageBus()
        outbound = []

        async def capture(msg):
            outbound.append(msg)

        bus.on_outbound(capture)

        config = CronConfig(enabled=True)
        svc = SchedulerService(config, tmp_path, bus=bus)

        mock_agent = AsyncMock()
        mock_agent.run_once = AsyncMock(return_value="CI is green")
        svc.set_agent_loop(mock_agent)

        job = _Job(
            name="notify_test",
            schedule=60,
            agent="default",
            prompt="check",
            notify_channels=["cli"],
        )
        await svc._execute_job(job)

        assert len(outbound) >= 1
        assert "CI is green" in outbound[0].content

    @pytest.mark.asyncio
    async def test_channel_id_uses_scheduler_prefix(self, tmp_path):
        """Bug #2: channel_id should be 'scheduler:<job_name>', not the channel name."""
        bus = MessageBus()
        outbound = []

        async def capture(msg):
            outbound.append(msg)

        bus.on_outbound(capture)

        config = CronConfig(enabled=True)
        svc = SchedulerService(config, tmp_path, bus=bus)

        mock_agent = AsyncMock()
        mock_agent.run_once = AsyncMock(return_value="done")
        svc.set_agent_loop(mock_agent)

        job = _Job(
            name="ch_test",
            schedule=60,
            agent="default",
            prompt="check",
            notify_channels=["cli"],
        )
        await svc._execute_job(job)

        assert len(outbound) == 1
        assert outbound[0].channel_id == "scheduler:ch_test"
        assert outbound[0].channel == "cli"

    @pytest.mark.asyncio
    async def test_outbound_metadata_has_session_info(self, tmp_path):
        """Bug #5: OutboundMessage metadata should include source, job_name, session_id."""
        bus = MessageBus()
        outbound = []

        async def capture(msg):
            outbound.append(msg)

        bus.on_outbound(capture)

        config = CronConfig(enabled=True)
        svc = SchedulerService(config, tmp_path, bus=bus)

        mock_agent = AsyncMock()
        mock_agent.run_once = AsyncMock(return_value="result")
        svc.set_agent_loop(mock_agent)

        job = _Job(
            name="meta_test",
            schedule=60,
            agent="default",
            prompt="check",
            notify_channels=["cli"],
        )
        await svc._execute_job(job)

        assert len(outbound) == 1
        meta = outbound[0].metadata
        assert meta["source"] == "scheduler"
        assert meta["job_name"] == "meta_test"
        assert "session_id" in meta

    @pytest.mark.asyncio
    async def test_wildcard_resolves_to_active_channels(self, tmp_path):
        """Bug #3: '*' should resolve to active channels at notification time."""
        bus = MessageBus()
        outbound = []

        async def capture(msg):
            outbound.append(msg)

        bus.on_outbound(capture)

        config = CronConfig(enabled=True)
        svc = SchedulerService(
            config,
            tmp_path,
            bus=bus,
            active_channels_fn=lambda: ["cli", "teams"],
        )

        mock_agent = AsyncMock()
        mock_agent.run_once = AsyncMock(return_value="broadcast")
        svc.set_agent_loop(mock_agent)

        job = _Job(
            name="wildcard_test",
            schedule=60,
            agent="default",
            prompt="check",
            notify_channels=["*"],
        )
        await svc._execute_job(job)

        assert len(outbound) == 2
        channels = {m.channel for m in outbound}
        assert channels == {"cli", "teams"}

    @pytest.mark.asyncio
    async def test_wildcard_error_isolation(self, tmp_path):
        """Bug #3: One channel failure shouldn't block delivery to others."""
        bus = MessageBus()
        call_count = 0

        async def flaky_publish(msg):
            nonlocal call_count
            call_count += 1
            if msg.channel == "bad":
                raise RuntimeError("channel down")

        bus.publish_outbound = flaky_publish  # type: ignore[assignment]

        config = CronConfig(enabled=True)
        svc = SchedulerService(
            config,
            tmp_path,
            bus=bus,
            active_channels_fn=lambda: ["bad", "good"],
        )

        mock_agent = AsyncMock()
        mock_agent.run_once = AsyncMock(return_value="data")
        svc.set_agent_loop(mock_agent)

        job = _Job(
            name="iso_test",
            schedule=60,
            agent="default",
            prompt="check",
            notify_channels=["*"],
        )
        # Should not raise despite "bad" channel failing
        result = await svc._execute_job(job)
        assert result == "data"
        assert call_count == 2  # both channels attempted


# ── Bug #1: next_run_time in list_jobs ────────────────────────────────────────


class TestListJobsNextRun:
    def test_list_jobs_has_next_run_field(self, tmp_path):
        """Bug #1: list_jobs() must include 'next_run' in each entry."""
        config = CronConfig(enabled=True, jobs={"j1": CronJobConfig(schedule=60, prompt="x")})
        svc = SchedulerService(config, tmp_path)
        jobs = svc.list_jobs()
        assert len(jobs) == 1
        assert "next_run" in jobs[0]
        # No scheduler running → next_run is None
        assert jobs[0]["next_run"] is None

    def test_list_jobs_next_run_from_apscheduler(self, tmp_path):
        """Bug #1: next_run should come from APScheduler when available."""
        config = CronConfig(enabled=True, jobs={"j1": CronJobConfig(schedule=60, prompt="x")})
        svc = SchedulerService(config, tmp_path)

        # Mock the scheduler's get_job
        mock_ap_job = MagicMock()
        mock_ap_job.next_run_time = MagicMock()
        mock_ap_job.next_run_time.isoformat.return_value = "2026-01-01T12:00:00+00:00"
        mock_scheduler = MagicMock()
        mock_scheduler.get_job.return_value = mock_ap_job
        svc._scheduler = mock_scheduler

        jobs = svc.list_jobs()
        assert jobs[0]["next_run"] == "2026-01-01T12:00:00+00:00"


# ── Bug #6: error_type in run history ─────────────────────────────────────────


class TestErrorTypeInHistory:
    @pytest.mark.asyncio
    async def test_error_type_recorded_on_failure(self, tmp_path):
        """Bug #6: Failed runs should record the exception type."""
        config = CronConfig(enabled=True)
        svc = SchedulerService(config, tmp_path)

        mock_agent = AsyncMock()
        mock_agent.run_once = AsyncMock(side_effect=RuntimeError("boom"))
        svc.set_agent_loop(mock_agent)

        job = _Job(name="err_type", schedule=60, agent="default", prompt="x")
        svc._jobs["err_type"] = job
        await svc._execute_job(job)

        history = svc.get_history("err_type")
        assert len(history) == 1
        assert history[0]["error_type"] == "RuntimeError"

    @pytest.mark.asyncio
    async def test_no_error_type_on_success(self, tmp_path):
        """Bug #6: Successful runs should not have error_type."""
        config = CronConfig(enabled=True)
        svc = SchedulerService(config, tmp_path)

        mock_agent = AsyncMock()
        mock_agent.run_once = AsyncMock(return_value="ok")
        svc.set_agent_loop(mock_agent)

        job = _Job(name="no_err", schedule=60, agent="default", prompt="x")
        await svc._execute_job(job)

        history = svc.get_history("no_err")
        assert len(history) == 1
        assert "error_type" not in history[0]

    @pytest.mark.asyncio
    async def test_result_preview_increased_to_500(self, tmp_path):
        """Bug #6: result_preview should be up to 500 chars (was 200)."""
        config = CronConfig(enabled=True)
        svc = SchedulerService(config, tmp_path)

        long_result = "x" * 600
        mock_agent = AsyncMock()
        mock_agent.run_once = AsyncMock(return_value=long_result)
        svc.set_agent_loop(mock_agent)

        job = _Job(name="long_prev", schedule=60, agent="default", prompt="x")
        await svc._execute_job(job)

        history = svc.get_history("long_prev")
        assert len(history[0]["result_preview"]) == 500


# ── Bug #7: concurrent job limit ─────────────────────────────────────────────


class TestConcurrentJobLimit:
    def test_semaphore_created_from_config(self, tmp_path):
        """Bug #7: Semaphore should use max_concurrent_jobs from config."""
        config = CronConfig(enabled=True, max_concurrent_jobs=3)
        svc = SchedulerService(config, tmp_path)
        assert svc._job_semaphore._value == 3

    def test_default_semaphore_is_5(self, tmp_path):
        config = CronConfig(enabled=True)
        svc = SchedulerService(config, tmp_path)
        assert svc._job_semaphore._value == 5

    @pytest.mark.asyncio
    async def test_semaphore_limits_concurrency(self, tmp_path):
        """Bug #7: Jobs should be limited by the semaphore."""
        config = CronConfig(enabled=True, max_concurrent_jobs=1)
        svc = SchedulerService(config, tmp_path)

        concurrency = []
        max_concurrent = 0

        async def slow_run(prompt, session_id=None):
            nonlocal max_concurrent
            concurrency.append(1)
            current = len(concurrency)
            if current > max_concurrent:
                max_concurrent = current
            await asyncio.sleep(0.05)
            concurrency.pop()
            return "done"

        mock_agent = AsyncMock()
        mock_agent.run_once = slow_run
        svc.set_agent_loop(mock_agent)

        job1 = _Job(name="c1", schedule=60, agent="default", prompt="x")
        job2 = _Job(name="c2", schedule=60, agent="default", prompt="y")

        await asyncio.gather(svc._execute_job(job1), svc._execute_job(job2))
        assert max_concurrent <= 1


# ── Bug #8: default notify_channels in CronTool ──────────────────────────────


class TestDefaultNotifyChannels:
    @pytest.mark.asyncio
    async def test_add_defaults_to_broadcast(self, tmp_path):
        """Bug #8: CronTool add should default notify_channels to ['*']."""
        config = CronConfig(enabled=True)
        svc = SchedulerService(config, tmp_path)
        tool = CronTool(svc)

        await tool.execute(action="add", schedule="at:+60", prompt="remind me")

        # Find the job that was added
        jobs = svc.list_jobs()
        agent_jobs = [j for j in jobs if j["name"].startswith("agent-")]
        assert len(agent_jobs) == 1
        # Check that the internal _Job has notify_channels=["*"]
        job = svc._jobs[agent_jobs[0]["name"]]
        assert job.notify_channels == ["*"]

    @pytest.mark.asyncio
    async def test_add_explicit_channels_respected(self, tmp_path):
        """Bug #8: Explicit notify_channels should override the default."""
        config = CronConfig(enabled=True)
        svc = SchedulerService(config, tmp_path)
        tool = CronTool(svc)

        await tool.execute(
            action="add", schedule="at:+60", prompt="remind", notify_channels=["cli"]
        )

        jobs = svc.list_jobs()
        agent_jobs = [j for j in jobs if j["name"].startswith("agent-")]
        job = svc._jobs[agent_jobs[0]["name"]]
        assert job.notify_channels == ["cli"]


# ── Bug #9: failed one-shot retention ─────────────────────────────────────────


class TestFailedOneShotRetention:
    @pytest.mark.asyncio
    async def test_failed_oneshot_disabled_not_removed(self, tmp_path):
        """Bug #9: Failed one-shot jobs should be disabled, not removed."""
        config = CronConfig(enabled=True)
        svc = SchedulerService(config, tmp_path)

        mock_agent = AsyncMock()
        mock_agent.run_once = AsyncMock(side_effect=RuntimeError("fail"))
        svc.set_agent_loop(mock_agent)

        job = _Job(name="oneshot_fail", schedule="at", agent="default", prompt="x", dynamic=True)
        svc._jobs["oneshot_fail"] = job

        # Simulate what _run_and_remove does
        result = await svc._execute_job(job)
        if result is not None:
            svc.remove_job(job.name)
        else:
            svc.disable(job.name)

        # Job should still exist but be disabled
        assert "oneshot_fail" in svc._jobs
        assert svc._jobs["oneshot_fail"].enabled is False


# ── Describe action ──────────────────────────────────────────────────────────


class TestDescribeAction:
    @pytest.mark.asyncio
    async def test_describe_returns_job_info(self, tmp_path):
        config = CronConfig(enabled=True, jobs={"j1": CronJobConfig(schedule=60, prompt="x")})
        svc = SchedulerService(config, tmp_path)
        tool = CronTool(svc)

        result = await tool.execute(action="describe", job_id="j1")
        assert "Job: j1" in result
        assert "Schedule: interval (60)" in result
        assert "Status: enabled" in result
        assert "Failures: 0" in result

    @pytest.mark.asyncio
    async def test_describe_missing_job(self, tmp_path):
        config = CronConfig(enabled=True)
        svc = SchedulerService(config, tmp_path)
        tool = CronTool(svc)

        result = await tool.execute(action="describe", job_id="nope")
        assert "not found" in result.lower()

    @pytest.mark.asyncio
    async def test_describe_missing_job_id(self, tmp_path):
        config = CronConfig(enabled=True)
        svc = SchedulerService(config, tmp_path)
        tool = CronTool(svc)

        result = await tool.execute(action="describe")
        assert "error" in result.lower()


# ── CronTool list shows next_run ──────────────────────────────────────────────


class TestCronToolListNextRun:
    @pytest.mark.asyncio
    async def test_list_output_includes_next_run(self, tmp_path):
        config = CronConfig(enabled=True, jobs={"j1": CronJobConfig(schedule=60, prompt="x")})
        svc = SchedulerService(config, tmp_path)
        tool = CronTool(svc)

        result = await tool.execute(action="list")
        assert "next=" in result


# ── Schema additions ──────────────────────────────────────────────────────────


class TestSchemaAdditions:
    def test_max_concurrent_jobs_default(self):
        config = CronConfig(enabled=True)
        assert config.max_concurrent_jobs == 5

    def test_max_concurrent_jobs_custom(self):
        config = CronConfig(enabled=True, max_concurrent_jobs=10)
        assert config.max_concurrent_jobs == 10

    def test_job_timeout_default_none(self):
        job = CronJobConfig(schedule=60)
        assert job.timeout is None

    def test_job_timeout_custom(self):
        job = CronJobConfig(schedule=60, timeout=300)
        assert job.timeout == 300


# ── At trigger (nanobot at_iso pattern) ───────────────────────────────────────


class TestAtTrigger:
    def test_detect_at_relative(self):
        assert _detect_trigger_type("at:+60") == "at"

    def test_detect_at_immediate(self):
        assert _detect_trigger_type("at") == "at"

    def test_detect_at_absolute_iso(self):
        assert _detect_trigger_type("at:2026-12-25T09:00:00") == "at"

    def test_parse_at_immediate(self):
        assert _parse_at_schedule("at") is None

    def test_parse_at_relative(self):
        from datetime import UTC, datetime

        result = _parse_at_schedule("at:+60")
        assert result is not None
        # Should be approximately 60 seconds from now
        delta = (result - datetime.now(UTC)).total_seconds()
        assert 55 < delta < 65

    def test_parse_at_absolute_iso(self):
        result = _parse_at_schedule("at:2026-12-25T09:00:00")
        assert result is not None
        assert result.year == 2026
        assert result.month == 12
        assert result.day == 25
        assert result.hour == 9
        assert result.tzinfo is not None  # UTC assumed when no tz given

    def test_parse_at_with_timezone(self):
        from datetime import timedelta

        result = _parse_at_schedule("at:2026-03-04T15:00:00+08:00")
        assert result is not None
        assert result.utcoffset() == timedelta(hours=8)

    def test_add_at_relative_job(self, tmp_path):
        config = CronConfig(enabled=True)
        svc = SchedulerService(config, tmp_path)
        svc.add_job("reminder", "at:+300", "remind me", dynamic=True)
        assert "reminder" in svc._jobs
        assert svc._jobs["reminder"].schedule == "at:+300"

    def test_add_at_absolute_job(self, tmp_path):
        config = CronConfig(enabled=True)
        svc = SchedulerService(config, tmp_path)
        svc.add_job("meeting", "at:2026-12-25T09:00:00", "join standup", dynamic=True)
        assert "meeting" in svc._jobs

    def test_add_at_past_rejected(self, tmp_path):
        config = CronConfig(enabled=True)
        svc = SchedulerService(config, tmp_path)
        with pytest.raises(ValueError, match="past"):
            svc.add_job("old", "at:2020-01-01T00:00:00", "too late", dynamic=True)

    def test_add_at_negative_delay_rejected(self, tmp_path):
        config = CronConfig(enabled=True)
        svc = SchedulerService(config, tmp_path)
        with pytest.raises(ValueError, match="positive"):
            svc.add_job("neg", "at:+-5", "bad", dynamic=True)

    def test_list_jobs_shows_at_trigger_type(self, tmp_path):
        config = CronConfig(enabled=True)
        svc = SchedulerService(config, tmp_path)
        svc.add_job("at_job", "at:+120", "test", dynamic=True)
        jobs = svc.list_jobs()
        at_jobs = [j for j in jobs if j["name"] == "at_job"]
        assert at_jobs[0]["trigger_type"] == "at"

    @pytest.mark.asyncio
    async def test_crontool_add_with_at(self, tmp_path):
        config = CronConfig(enabled=True)
        svc = SchedulerService(config, tmp_path)
        tool = CronTool(svc)

        result = await tool.execute(action="add", schedule="at:+60", prompt="remind me")
        assert "added" in result.lower()
