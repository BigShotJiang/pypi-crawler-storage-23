"""Tests for SecurityClassifier -- the fast LLM classifier for tool approval."""

from __future__ import annotations

import asyncio
import json
from typing import Any
from unittest.mock import AsyncMock

import pytest

from workpilot.hooks.handlers import ApprovalGate
from workpilot.hooks.manager import HookVerdict, PreToolHookContext
from workpilot.providers.base import LLMProvider, LLMResponse
from workpilot.security.classifier import ClassifyResult, SecurityClassifier

# ── Helpers ──────────────────────────────────────────────────────────────────


def _mock_provider(content: str = "") -> LLMProvider:
    """Return an LLMProvider whose ``complete`` returns *content*."""
    provider = LLMProvider()
    provider.complete = AsyncMock(return_value=LLMResponse(content=content))
    return provider


def _allow_response() -> str:
    return json.dumps({"decision": "allow", "risk": "low", "reason": "safe read operation"})


def _deny_response() -> str:
    return json.dumps({"decision": "deny", "risk": "high", "reason": "dangerous command"})


def _escalate_response() -> str:
    return json.dumps({"decision": "escalate", "risk": "medium", "reason": "uncertain"})


# ── Profile-based bypass ────────────────────────────────────────────────────


class TestProfileBypass:
    @pytest.mark.asyncio
    async def test_open_profile_allows_without_llm_call(self):
        provider = _mock_provider()
        clf = SecurityClassifier(provider, profile="open")

        result = await clf.classify("shell", {"command": "rm -rf /"})

        assert result.decision == "allow"
        assert result.risk == "low"
        assert "open profile" in result.reason
        provider.complete.assert_not_called()

    @pytest.mark.asyncio
    async def test_restricted_profile_escalates_without_llm_call(self):
        provider = _mock_provider()
        clf = SecurityClassifier(provider, profile="restricted")

        result = await clf.classify("read_file", {"path": "/etc/hosts"})

        assert result.decision == "escalate"
        assert result.risk == "high"
        assert "restricted" in result.reason
        provider.complete.assert_not_called()


# ── LLM classification decisions ─────────────────────────────────────────────


class TestClassifyDecisions:
    @pytest.mark.asyncio
    async def test_allow_decision(self):
        provider = _mock_provider(_allow_response())
        clf = SecurityClassifier(provider, profile="standard")

        result = await clf.classify("read_file", {"path": "README.md"})

        assert result.decision == "allow"
        assert result.risk == "low"
        provider.complete.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_deny_decision(self):
        provider = _mock_provider(_deny_response())
        clf = SecurityClassifier(provider, profile="standard")

        result = await clf.classify("shell", {"command": "rm -rf /"})

        assert result.decision == "deny"
        assert result.risk == "high"

    @pytest.mark.asyncio
    async def test_escalate_decision(self):
        provider = _mock_provider(_escalate_response())
        clf = SecurityClassifier(provider, profile="standard")

        result = await clf.classify("shell", {"command": "curl example.com"})

        assert result.decision == "escalate"
        assert result.risk == "medium"

    @pytest.mark.asyncio
    async def test_controlled_profile_calls_classifier(self):
        provider = _mock_provider(_allow_response())
        clf = SecurityClassifier(provider, profile="controlled")

        result = await clf.classify("read_file", {"path": "test.txt"})

        assert result.decision == "allow"
        provider.complete.assert_awaited_once()


# ── Cache behaviour ──────────────────────────────────────────────────────────


class TestCache:
    @pytest.mark.asyncio
    async def test_cache_hit_avoids_second_llm_call(self):
        provider = _mock_provider(_allow_response())
        clf = SecurityClassifier(provider, profile="standard")

        # First call populates cache
        r1 = await clf.classify("read_file", {"path": "a.txt"})
        # Second identical call should use cache
        r2 = await clf.classify("read_file", {"path": "a.txt"})

        assert r1.decision == r2.decision
        assert provider.complete.await_count == 1

    @pytest.mark.asyncio
    async def test_different_args_are_not_cached(self):
        provider = _mock_provider(_allow_response())
        clf = SecurityClassifier(provider, profile="standard")

        await clf.classify("read_file", {"path": "a.txt"})
        await clf.classify("read_file", {"path": "b.txt"})

        assert provider.complete.await_count == 2

    @pytest.mark.asyncio
    async def test_cache_expires_after_ttl(self):
        provider = _mock_provider(_allow_response())
        clf = SecurityClassifier(provider, profile="standard")
        clf.CACHE_TTL = 0  # expire immediately

        await clf.classify("read_file", {"path": "a.txt"})
        await clf.classify("read_file", {"path": "a.txt"})

        assert provider.complete.await_count == 2


# ── Timeout handling ─────────────────────────────────────────────────────────


class TestTimeout:
    @pytest.mark.asyncio
    async def test_timeout_returns_escalate(self):
        provider = LLMProvider()

        async def slow_complete(**kwargs: Any) -> LLMResponse:
            await asyncio.sleep(10)
            return LLMResponse(content=_allow_response())

        provider.complete = slow_complete  # type: ignore[assignment]

        clf = SecurityClassifier(provider, profile="standard")
        clf.TIMEOUT = 0.05  # 50ms timeout

        result = await clf.classify("shell", {"command": "echo hello"})

        assert result.decision == "escalate"
        assert result.risk == "medium"
        assert "unavailable" in result.reason.lower() or "Classifier" in result.reason

    @pytest.mark.asyncio
    async def test_provider_error_returns_escalate(self):
        provider = LLMProvider()
        provider.complete = AsyncMock(side_effect=RuntimeError("connection reset"))

        clf = SecurityClassifier(provider, profile="standard")

        result = await clf.classify("shell", {"command": "ls"})

        assert result.decision == "escalate"
        assert result.risk == "medium"


# ── Argument redaction ───────────────────────────────────────────────────────


class TestRedaction:
    def test_sensitive_key_is_redacted(self):
        clf = SecurityClassifier(_mock_provider(), profile="standard")
        redacted = clf._redact_args({"password": "s3cret", "path": "/tmp"})
        assert redacted["password"] == "[REDACTED]"
        assert redacted["path"] == "/tmp"

    def test_jwt_value_is_redacted(self):
        clf = SecurityClassifier(_mock_provider(), profile="standard")
        redacted = clf._redact_args({"header": "eyJhbGciOiJIUzI1NiJ9.payload.sig"})
        assert redacted["header"] == "[REDACTED]"

    def test_github_pat_is_redacted(self):
        clf = SecurityClassifier(_mock_provider(), profile="standard")
        redacted = clf._redact_args({"token_val": "ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdef1234"})
        assert redacted["token_val"] == "[REDACTED]"

    def test_openai_key_is_redacted(self):
        clf = SecurityClassifier(_mock_provider(), profile="standard")
        redacted = clf._redact_args({"key": "sk-abc123def456ghi789jkl012mno"})
        assert redacted["key"] == "[REDACTED]"

    def test_non_secret_value_preserved(self):
        clf = SecurityClassifier(_mock_provider(), profile="standard")
        redacted = clf._redact_args({"command": "echo hello", "path": "/tmp"})
        assert redacted["command"] == "echo hello"
        assert redacted["path"] == "/tmp"

    def test_sensitive_keys_by_name(self):
        clf = SecurityClassifier(_mock_provider(), profile="standard")
        for key_name in ("api_key", "secret", "token", "authorization", "credentials"):
            redacted = clf._redact_args({key_name: "some_value"})
            assert redacted[key_name] == "[REDACTED]", f"{key_name} was not redacted"


# ── Response parsing ─────────────────────────────────────────────────────────


class TestParsing:
    def test_valid_json_parsed(self):
        clf = SecurityClassifier(_mock_provider(), profile="standard")
        result = clf._parse_response('{"decision": "allow", "risk": "low", "reason": "safe"}')
        assert result.decision == "allow"
        assert result.risk == "low"
        assert result.reason == "safe"

    def test_invalid_json_returns_escalate(self):
        clf = SecurityClassifier(_mock_provider(), profile="standard")
        result = clf._parse_response("not json at all")
        assert result.decision == "escalate"
        assert result.risk == "medium"

    def test_unknown_decision_defaults_to_escalate(self):
        clf = SecurityClassifier(_mock_provider(), profile="standard")
        result = clf._parse_response('{"decision": "maybe", "risk": "low", "reason": "hmm"}')
        assert result.decision == "escalate"

    def test_unknown_risk_defaults_to_high(self):
        clf = SecurityClassifier(_mock_provider(), profile="standard")
        result = clf._parse_response('{"decision": "allow", "risk": "extreme", "reason": "ok"}')
        assert result.risk == "high"

    def test_missing_fields_use_defaults(self):
        clf = SecurityClassifier(_mock_provider(), profile="standard")
        result = clf._parse_response("{}")
        assert result.decision == "escalate"
        assert result.risk == "medium"
        assert result.reason == ""


# ── LLM call parameters ─────────────────────────────────────────────────────


class TestLLMCallParams:
    @pytest.mark.asyncio
    async def test_calls_fast_model_with_correct_params(self):
        provider = _mock_provider(_allow_response())
        clf = SecurityClassifier(provider, profile="standard")

        await clf.classify("read_file", {"path": "test.txt"})

        call_kwargs = provider.complete.call_args.kwargs
        assert call_kwargs["model"] == "fast"
        assert call_kwargs["max_tokens"] == 200
        assert "temperature" not in call_kwargs
        assert len(call_kwargs["messages"]) == 2
        assert call_kwargs["messages"][0]["role"] == "system"
        assert call_kwargs["messages"][1]["role"] == "user"

    @pytest.mark.asyncio
    async def test_prompt_includes_tool_name_and_args(self):
        provider = _mock_provider(_allow_response())
        clf = SecurityClassifier(provider, profile="standard")

        await clf.classify("shell", {"command": "echo hi"})

        user_msg = provider.complete.call_args.kwargs["messages"][1]["content"]
        assert "shell" in user_msg
        assert "echo hi" in user_msg


# ── ApprovalGate integration ────────────────────────────────────────────────


class TestApprovalGateIntegration:
    @pytest.mark.asyncio
    async def test_no_classifier_allows_all(self):
        gate = ApprovalGate(classifier=None)
        ctx = PreToolHookContext(tool_name="shell", args={"command": "rm -rf /"})
        result = await gate(ctx)
        assert result.verdict == HookVerdict.ALLOW

    @pytest.mark.asyncio
    async def test_classifier_allow_passes_through(self):
        provider = _mock_provider(_allow_response())
        clf = SecurityClassifier(provider, profile="standard")
        gate = ApprovalGate(classifier=clf)

        ctx = PreToolHookContext(tool_name="read_file", args={"path": "test.txt"})
        result = await gate(ctx)

        assert result.verdict == HookVerdict.ALLOW

    @pytest.mark.asyncio
    async def test_classifier_deny_rejects(self):
        provider = _mock_provider(_deny_response())
        clf = SecurityClassifier(provider, profile="standard")
        gate = ApprovalGate(classifier=clf)

        ctx = PreToolHookContext(tool_name="shell", args={"command": "rm -rf /"})
        result = await gate(ctx)

        assert result.verdict == HookVerdict.REJECT
        assert "high" in result.reason
        assert "dangerous" in result.reason.lower()

    @pytest.mark.asyncio
    async def test_classifier_escalate_rejects_with_escalation_message(self):
        provider = _mock_provider(_escalate_response())
        clf = SecurityClassifier(provider, profile="standard")
        gate = ApprovalGate(classifier=clf)

        ctx = PreToolHookContext(tool_name="shell", args={"command": "curl example.com"})
        result = await gate(ctx)

        assert result.verdict == HookVerdict.REJECT
        assert "Escalated for review" in result.reason
        assert "uncertain" in result.reason


# ── ClassifyResult dataclass ─────────────────────────────────────────────────


class TestClassifyResult:
    def test_fields(self):
        r = ClassifyResult(decision="allow", risk="low", reason="test")
        assert r.decision == "allow"
        assert r.risk == "low"
        assert r.reason == "test"


# ── Cache key determinism ───────────────────────────────────────────────────


class TestCacheKey:
    def test_same_args_same_key(self):
        clf = SecurityClassifier(_mock_provider(), profile="standard")
        k1 = clf._cache_key("shell", {"a": "1", "b": "2"})
        k2 = clf._cache_key("shell", {"b": "2", "a": "1"})
        assert k1 == k2

    def test_different_tool_different_key(self):
        clf = SecurityClassifier(_mock_provider(), profile="standard")
        k1 = clf._cache_key("shell", {"command": "ls"})
        k2 = clf._cache_key("read_file", {"command": "ls"})
        assert k1 != k2

    def test_different_tool_risk_different_key(self):
        clf = SecurityClassifier(_mock_provider(), profile="standard")
        k1 = clf._cache_key("shell", {"command": "ls"}, tool_risk="low")
        k2 = clf._cache_key("shell", {"command": "ls"}, tool_risk="high")
        assert k1 != k2

    def test_none_tool_risk_different_from_low(self):
        clf = SecurityClassifier(_mock_provider(), profile="standard")
        k1 = clf._cache_key("shell", {"command": "ls"}, tool_risk=None)
        k2 = clf._cache_key("shell", {"command": "ls"}, tool_risk="low")
        assert k1 != k2


# ── Nested redaction (Fix #3) ────────────────────────────────────────────────


class TestNestedRedaction:
    def test_nested_dict_secret_is_redacted(self):
        clf = SecurityClassifier(_mock_provider(), profile="standard")
        redacted = clf._redact_args({"config": {"password": "s3cret", "host": "localhost"}})
        assert redacted["config"]["password"] == "[REDACTED]"
        assert redacted["config"]["host"] == "localhost"

    def test_nested_list_secret_is_redacted(self):
        clf = SecurityClassifier(_mock_provider(), profile="standard")
        redacted = clf._redact_args(
            {"headers": ["Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.payload.sig", "Accept: */*"]}
        )
        assert redacted["headers"][0] == "[REDACTED]"
        assert redacted["headers"][1] == "Accept: */*"

    def test_deeply_nested_secret_is_redacted(self):
        clf = SecurityClassifier(_mock_provider(), profile="standard")
        redacted = clf._redact_args({"outer": {"inner": {"api_key": "my-secret-key"}}})
        assert redacted["outer"]["inner"]["api_key"] == "[REDACTED]"

    def test_list_of_dicts_with_secrets(self):
        clf = SecurityClassifier(_mock_provider(), profile="standard")
        redacted = clf._redact_args({"items": [{"token": "abc123"}, {"name": "safe"}]})
        assert redacted["items"][0]["token"] == "[REDACTED]"
        assert redacted["items"][1]["name"] == "safe"

    def test_nested_list_in_list(self):
        clf = SecurityClassifier(_mock_provider(), profile="standard")
        redacted = clf._redact_args({"data": [["sk-abc123def456ghi789jkl012mno", "safe"]]})
        assert redacted["data"][0][0] == "[REDACTED]"
        assert redacted["data"][0][1] == "safe"


# ── Critical risk value (Fix #2) ─────────────────────────────────────────────


class TestCriticalRisk:
    def test_critical_risk_is_accepted(self):
        clf = SecurityClassifier(_mock_provider(), profile="standard")
        result = clf._parse_response(
            '{"decision": "deny", "risk": "critical", "reason": "extremely dangerous"}'
        )
        assert result.risk == "critical"
        assert result.decision == "deny"


# ── Standard profile low-risk bypass (Fix #4) ────────────────────────────────


class TestStandardLowRiskBypass:
    @pytest.mark.asyncio
    async def test_standard_low_risk_skips_llm(self):
        provider = _mock_provider()
        clf = SecurityClassifier(provider, profile="standard")

        result = await clf.classify("read_file", {"path": "a.txt"}, tool_risk="low")

        assert result.decision == "allow"
        assert result.risk == "low"
        assert "low-risk tool" in result.reason
        provider.complete.assert_not_called()

    @pytest.mark.asyncio
    async def test_standard_medium_risk_calls_llm(self):
        provider = _mock_provider(_allow_response())
        clf = SecurityClassifier(provider, profile="standard")

        result = await clf.classify("shell", {"command": "ls"}, tool_risk="medium")

        assert result.decision == "allow"
        provider.complete.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_controlled_low_risk_still_calls_llm(self):
        provider = _mock_provider(_allow_response())
        clf = SecurityClassifier(provider, profile="controlled")

        result = await clf.classify("read_file", {"path": "a.txt"}, tool_risk="low")

        assert result.decision == "allow"
        provider.complete.assert_awaited_once()


# ── Cache eviction enforces max size (Fix #8) ────────────────────────────────


class TestCacheEvictionMaxSize:
    @pytest.mark.asyncio
    async def test_eviction_removes_oldest_when_over_max(self):
        provider = _mock_provider(_allow_response())
        clf = SecurityClassifier(provider, profile="standard")
        clf.CACHE_MAX_SIZE = 2
        clf.CACHE_TTL = 3600  # long TTL so nothing expires

        await clf.classify("tool_a", {"x": "1"})
        await clf.classify("tool_b", {"x": "2"})
        await clf.classify("tool_c", {"x": "3"})

        # After 3 entries with max=2, eviction should trim to 2
        assert len(clf._cache) <= 2


# ── Context redaction in prompt (Fix #1) ──────────────────────────────────────


class TestContextRedaction:
    @pytest.mark.asyncio
    async def test_context_secrets_are_redacted_in_prompt(self):
        provider = _mock_provider(_allow_response())
        clf = SecurityClassifier(provider, profile="standard")

        await clf.classify(
            "shell",
            {"command": "echo hi"},
            context={"api_key": "super-secret", "workspace": "/home/user"},
        )

        user_msg = provider.complete.call_args.kwargs["messages"][1]["content"]
        assert "super-secret" not in user_msg
        assert "[REDACTED]" in user_msg
        assert "/home/user" in user_msg


# ── Exception sanitization (PR #30 round-2 fix) ─────────────────────────────


class TestExceptionSanitization:
    @pytest.mark.asyncio
    async def test_provider_error_reason_contains_only_type_name(self):
        """Exception reason must not leak sensitive details like API keys in URLs."""
        provider = LLMProvider()
        provider.complete = AsyncMock(
            side_effect=RuntimeError("https://api.openai.com/v1?key=sk-secret123")
        )
        clf = SecurityClassifier(provider, profile="standard")

        result = await clf.classify("shell", {"command": "ls"})

        assert result.decision == "escalate"
        assert "RuntimeError" in result.reason
        assert "sk-secret123" not in result.reason
        assert "openai" not in result.reason

    @pytest.mark.asyncio
    async def test_timeout_reason_contains_only_type_name(self):
        """Timeout reason must only include the exception type."""
        provider = LLMProvider()

        async def slow_complete(**kwargs: Any) -> LLMResponse:
            await asyncio.sleep(10)
            return LLMResponse(content=_allow_response())

        provider.complete = slow_complete  # type: ignore[assignment]

        clf = SecurityClassifier(provider, profile="standard")
        clf.TIMEOUT = 0.05

        result = await clf.classify("shell", {"command": "echo hello"})

        assert result.decision == "escalate"
        assert "Classifier unavailable:" in result.reason
        # Should NOT include the full exception message
        assert "10" not in result.reason or "TimeoutError" in result.reason


# ── ApprovalGate tool_risk passthrough (PR #30 round-2 fix) ─────────────────


class TestApprovalGateToolRisk:
    @pytest.mark.asyncio
    async def test_gate_passes_tool_risk_to_classifier(self):
        """ApprovalGate must pass tool_risk from context to classifier."""
        provider = _mock_provider(_allow_response())
        clf = SecurityClassifier(provider, profile="standard")
        gate = ApprovalGate(classifier=clf)

        ctx = PreToolHookContext(tool_name="read_file", args={"path": "test.txt"}, tool_risk="low")
        result = await gate(ctx)

        # low-risk tool in standard profile -> allow without LLM call
        assert result.verdict == HookVerdict.ALLOW
        provider.complete.assert_not_called()

    @pytest.mark.asyncio
    async def test_gate_medium_risk_calls_classifier(self):
        """ApprovalGate must pass medium risk, triggering LLM call."""
        provider = _mock_provider(_allow_response())
        clf = SecurityClassifier(provider, profile="standard")
        gate = ApprovalGate(classifier=clf)

        ctx = PreToolHookContext(tool_name="shell", args={"command": "ls"}, tool_risk="medium")
        result = await gate(ctx)

        assert result.verdict == HookVerdict.ALLOW
        provider.complete.assert_awaited_once()


# ── Classifier prompt mentions critical risk (PR #30 round-2 fix) ───────────


class TestClassifierPromptCritical:
    @pytest.mark.asyncio
    async def test_system_prompt_includes_critical(self):
        """The classifier system prompt must mention 'critical' as a risk level."""
        provider = _mock_provider(_allow_response())
        clf = SecurityClassifier(provider, profile="standard")

        await clf.classify("shell", {"command": "ls"})

        system_msg = provider.complete.call_args.kwargs["messages"][0]["content"]
        assert "critical" in system_msg
