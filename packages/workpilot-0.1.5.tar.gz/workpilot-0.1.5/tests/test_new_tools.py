"""Tests for the new tools: MessageTool, SpawnTool, BrowserTool."""

import asyncio
import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from workpilot.agent.tools.browser import BrowserTool
from workpilot.agent.tools.message import MessageTool
from workpilot.agent.tools.spawn import SpawnTool
from workpilot.bus.events import OutboundMessage
from workpilot.bus.queue import MessageBus
from workpilot.config.schema import BrowserConfig

# ── MessageTool ──────────────────────────────────────────────────────────────


class TestMessageTool:
    def test_name_and_description(self):
        bus = MagicMock(spec=MessageBus)
        tool = MessageTool(bus)
        assert tool.name == "message"
        assert "channel" in tool.description.lower()

    def test_parameters_schema(self):
        bus = MagicMock(spec=MessageBus)
        tool = MessageTool(bus)
        params = tool.parameters
        assert params["type"] == "object"
        assert "channel" in params["properties"]
        assert "content" in params["properties"]
        assert "channel" in params["required"]
        assert "content" in params["required"]

    @pytest.mark.asyncio
    async def test_send_message_publishes_outbound(self):
        bus = AsyncMock(spec=MessageBus)
        tool = MessageTool(bus)

        result = await tool.execute(channel="teams", content="Hello team!")

        bus.publish_outbound.assert_called_once()
        msg = bus.publish_outbound.call_args[0][0]
        assert isinstance(msg, OutboundMessage)
        assert msg.channel == "teams"
        assert msg.content == "Hello team!"
        assert "Message sent to teams" in result

    @pytest.mark.asyncio
    async def test_send_with_recipient(self):
        bus = AsyncMock(spec=MessageBus)
        tool = MessageTool(bus)

        result = await tool.execute(channel="outlook", content="Hi!", recipient="alice@example.com")

        msg = bus.publish_outbound.call_args[0][0]
        assert msg.channel_id == "alice@example.com"
        assert "recipient: alice@example.com" in result

    @pytest.mark.asyncio
    async def test_send_with_thread_id(self):
        bus = AsyncMock(spec=MessageBus)
        tool = MessageTool(bus)

        result = await tool.execute(channel="cli", content="Reply", thread_id="thread-123")

        msg = bus.publish_outbound.call_args[0][0]
        assert msg.thread_id == "thread-123"
        assert "thread: thread-123" in result

    @pytest.mark.asyncio
    async def test_empty_content_rejected(self):
        bus = AsyncMock(spec=MessageBus)
        tool = MessageTool(bus)

        result = await tool.execute(channel="cli", content="   ")

        assert "empty" in result.lower()
        bus.publish_outbound.assert_not_called()

    @pytest.mark.asyncio
    async def test_publish_error_handled(self):
        bus = AsyncMock(spec=MessageBus)
        bus.publish_outbound.side_effect = RuntimeError("bus down")
        tool = MessageTool(bus)

        result = await tool.execute(channel="cli", content="Hello")

        assert "Error" in result


# ── SpawnTool ────────────────────────────────────────────────────────────────


class TestSpawnTool:
    @pytest.fixture
    def spawn_fn(self):
        """A mock spawn function that returns a success message."""

        async def _fn(agent_name: str, prompt: str) -> str:
            return f"[{agent_name}] completed: {prompt}"

        return _fn

    def test_name_and_description(self, spawn_fn):
        tool = SpawnTool(spawn_fn)
        assert tool.name == "spawn"
        assert "sub-agent" in tool.description.lower()

    def test_parameters_schema(self, spawn_fn):
        tool = SpawnTool(spawn_fn)
        params = tool.parameters
        assert "agent" in params["properties"]
        assert "prompt" in params["properties"]
        assert "mode" in params["properties"]

    @pytest.mark.asyncio
    async def test_serial_mode(self, spawn_fn):
        tool = SpawnTool(spawn_fn)
        result = await tool.execute(agent="coder", prompt="Fix the bug")
        assert "[coder] completed: Fix the bug" in result

    @pytest.mark.asyncio
    async def test_serial_mode_default(self, spawn_fn):
        tool = SpawnTool(spawn_fn)
        # mode defaults to "serial"
        result = await tool.execute(agent="coder", prompt="hello")
        assert "completed" in result

    @pytest.mark.asyncio
    async def test_serial_mode_error_handling(self):
        async def _fail(agent_name: str, prompt: str) -> str:
            raise RuntimeError("agent crashed")

        tool = SpawnTool(_fail)
        result = await tool.execute(agent="coder", prompt="task", mode="serial")
        assert "Error" in result
        assert "failed" in result

    @pytest.mark.asyncio
    async def test_parallel_mode(self, spawn_fn):
        tool = SpawnTool(spawn_fn)
        items = json.dumps(
            [
                {"agent": "reviewer", "prompt": "Review code"},
                {"agent": "tester", "prompt": "Run tests"},
            ]
        )
        result = await tool.execute(agent="ignored", prompt=items, mode="parallel")

        assert "[reviewer]" in result
        assert "[tester]" in result
        assert "Review code" in result
        assert "Run tests" in result

    @pytest.mark.asyncio
    async def test_parallel_mode_invalid_json(self, spawn_fn):
        tool = SpawnTool(spawn_fn)
        result = await tool.execute(agent="ignored", prompt="not json", mode="parallel")
        assert "Error" in result
        assert "JSON" in result

    @pytest.mark.asyncio
    async def test_parallel_mode_empty_array(self, spawn_fn):
        tool = SpawnTool(spawn_fn)
        result = await tool.execute(agent="ignored", prompt="[]", mode="parallel")
        assert "Error" in result

    @pytest.mark.asyncio
    async def test_background_mode_returns_task_id(self, spawn_fn):
        tool = SpawnTool(spawn_fn)
        result = await tool.execute(agent="coder", prompt="background task", mode="background")
        assert "Background task started" in result
        # Should have a task ID in the output
        assert (
            "task ID" in result.lower()
            or "task_id" in result.lower()
            or len(tool._background_tasks) == 1
        )

    @pytest.mark.asyncio
    async def test_background_task_result_retrieval(self, spawn_fn):
        tool = SpawnTool(spawn_fn)
        await tool.execute(agent="coder", prompt="bg task", mode="background")
        # Wait for the background task to complete
        await asyncio.sleep(0.1)
        # Get the task ID from the background tasks
        task_ids = list(tool._background_tasks.keys())
        assert len(task_ids) == 1
        bg_result = tool.get_background_result(task_ids[0])
        assert bg_result is not None
        assert "completed" in bg_result

    def test_get_background_result_unknown_id(self, spawn_fn):
        tool = SpawnTool(spawn_fn)
        assert tool.get_background_result("nonexistent") is None

    @pytest.mark.asyncio
    async def test_unknown_mode(self, spawn_fn):
        tool = SpawnTool(spawn_fn)
        result = await tool.execute(agent="coder", prompt="task", mode="invalid")
        assert "Error" in result
        assert "unknown" in result.lower()


# ── BrowserTool ──────────────────────────────────────────────────────────────


class TestBrowserTool:
    def test_name_and_description(self):
        config = BrowserConfig()
        tool = BrowserTool(config)
        assert tool.name == "browser"
        assert "browser" in tool.description.lower()

    def test_parameters_schema(self):
        config = BrowserConfig()
        tool = BrowserTool(config)
        params = tool.parameters
        assert params["type"] == "object"
        assert "action" in params["properties"]
        actions = params["properties"]["action"]["enum"]
        assert "navigate" in actions
        assert "click" in actions
        assert "screenshot" in actions

    def test_openai_schema(self):
        config = BrowserConfig()
        tool = BrowserTool(config)
        schema = tool.to_openai_schema()
        assert schema["type"] == "function"
        assert schema["function"]["name"] == "browser"

    @pytest.mark.asyncio
    async def test_missing_playwright_raises_runtime_error(self):
        config = BrowserConfig()
        tool = BrowserTool(config)

        # Ensure playwright is not available by patching the import
        with patch.dict("sys.modules", {"playwright": None, "playwright.async_api": None}):
            result = await tool.execute(action="navigate", url="https://example.com")
            # Should return an error message about playwright not being installed
            assert "error" in result.lower() or "playwright" in result.lower()

    @pytest.mark.asyncio
    async def test_unknown_action(self):
        config = BrowserConfig()
        tool = BrowserTool(config)
        # Mock the _ensure_page to avoid needing playwright
        mock_page = AsyncMock()
        tool._page = mock_page

        result = await tool.execute(action="unknown_action")
        assert "unknown" in result.lower()
