"""Tests for Microsoft Graph integration (auth, client, mail, teams, tools)."""

from unittest.mock import AsyncMock

import pytest

from workpilot.config.schema import GraphAuthConfig
from workpilot.graph.auth import GraphAuth
from workpilot.graph.client import GRAPH_BASE_URL, GraphClient
from workpilot.graph.mail import MailClient
from workpilot.graph.teams import TeamsGraphClient
from workpilot.graph.tools import (
    create_graph_tools,
)

# ── GraphAuth ────────────────────────────────────────────────────────────────


class TestGraphAuth:
    def test_init_stores_config(self):
        config = GraphAuthConfig()
        auth = GraphAuth(config)
        assert auth._config is config

    def test_not_authenticated_initially(self):
        auth = GraphAuth(GraphAuthConfig())
        assert auth.is_authenticated is False

    def test_is_authenticated_with_valid_token(self):
        import time

        auth = GraphAuth(GraphAuthConfig())
        auth._token = "some-token"
        auth._token_expires = time.time() + 3600
        assert auth.is_authenticated is True

    def test_is_authenticated_expired_token(self):
        import time

        auth = GraphAuth(GraphAuthConfig())
        auth._token = "some-token"
        auth._token_expires = time.time() - 100  # expired
        assert auth.is_authenticated is False


# ── GraphClient ──────────────────────────────────────────────────────────────


class TestGraphClient:
    def test_url_construction_default(self):
        auth = AsyncMock()
        client = GraphClient(auth)
        assert client._base_url == GRAPH_BASE_URL

    def test_url_construction_custom(self):
        auth = AsyncMock()
        client = GraphClient(auth, base_url="https://custom.example.com/api/")
        assert client._base_url == "https://custom.example.com/api"

    def test_timeout_default(self):
        auth = AsyncMock()
        client = GraphClient(auth)
        assert client._timeout == 30.0

    def test_timeout_custom(self):
        auth = AsyncMock()
        client = GraphClient(auth, timeout=60.0)
        assert client._timeout == 60.0


# ── MailClient ───────────────────────────────────────────────────────────────


class TestMailClient:
    @pytest.mark.asyncio
    async def test_list_messages_calls_graph_get(self):
        mock_graph = AsyncMock(spec=GraphClient)
        mock_graph.get.return_value = {"value": [{"id": "1", "subject": "Hello"}]}
        mail = MailClient(mock_graph)

        result = await mail.list_messages(folder="inbox", top=5)

        mock_graph.get.assert_called_once()
        call_args = mock_graph.get.call_args
        assert "/mailFolders/inbox/messages" in call_args[0][0]
        assert len(result) == 1
        assert result[0]["subject"] == "Hello"

    @pytest.mark.asyncio
    async def test_list_messages_with_filter(self):
        mock_graph = AsyncMock(spec=GraphClient)
        mock_graph.get.return_value = {"value": []}
        mail = MailClient(mock_graph)

        await mail.list_messages(filter_str="isRead eq false")

        call_args = mock_graph.get.call_args
        params = call_args[1].get("params") or call_args[0][1]
        assert "$filter" in params

    @pytest.mark.asyncio
    async def test_get_message(self):
        mock_graph = AsyncMock(spec=GraphClient)
        mock_graph.get.return_value = {"id": "msg123", "body": {"content": "text"}}
        mail = MailClient(mock_graph)

        result = await mail.get_message("msg123")

        assert result["id"] == "msg123"
        mock_graph.get.assert_called_once()

    @pytest.mark.asyncio
    async def test_send_mail(self):
        mock_graph = AsyncMock(spec=GraphClient)
        mock_graph.post.return_value = {}
        mail = MailClient(mock_graph)

        await mail.send_mail(to=["alice@example.com"], subject="Hi", body="Hello")

        mock_graph.post.assert_called_once()
        call_args = mock_graph.post.call_args
        assert "/sendMail" in call_args[0][0]
        payload = call_args[0][1]
        assert payload["message"]["subject"] == "Hi"

    @pytest.mark.asyncio
    async def test_reply_to(self):
        mock_graph = AsyncMock(spec=GraphClient)
        mock_graph.post.return_value = {}
        mail = MailClient(mock_graph)

        await mail.reply_to("msg123", body="Thanks!")

        call_args = mock_graph.post.call_args
        assert "/reply" in call_args[0][0]

    @pytest.mark.asyncio
    async def test_search_messages(self):
        mock_graph = AsyncMock(spec=GraphClient)
        mock_graph.get.return_value = {"value": [{"id": "1"}, {"id": "2"}]}
        mail = MailClient(mock_graph)

        results = await mail.search_messages("subject:invoice", top=5)

        assert len(results) == 2

    @pytest.mark.asyncio
    async def test_user_id_in_endpoint(self):
        mock_graph = AsyncMock(spec=GraphClient)
        mock_graph.get.return_value = {"value": []}
        mail = MailClient(mock_graph, user_id="user@example.com")

        await mail.list_messages()

        call_args = mock_graph.get.call_args
        endpoint = call_args[0][0]
        assert "user@example.com" in endpoint


# ── TeamsGraphClient ─────────────────────────────────────────────────────────


class TestTeamsGraphClient:
    @pytest.mark.asyncio
    async def test_send_channel_message(self):
        mock_graph = AsyncMock(spec=GraphClient)
        mock_graph.post.return_value = {"id": "msg1"}
        teams = TeamsGraphClient(mock_graph)

        result = await teams.send_channel_message("team1", "chan1", "Hello team!")

        assert result["id"] == "msg1"
        call_args = mock_graph.post.call_args
        assert "/teams/team1/channels/chan1/messages" in call_args[0][0]

    @pytest.mark.asyncio
    async def test_send_chat_message(self):
        mock_graph = AsyncMock(spec=GraphClient)
        mock_graph.post.return_value = {"id": "msg2"}
        teams = TeamsGraphClient(mock_graph)

        result = await teams.send_chat_message("chat123", "Hi there!")

        assert result["id"] == "msg2"
        call_args = mock_graph.post.call_args
        assert "/chats/chat123/messages" in call_args[0][0]

    @pytest.mark.asyncio
    async def test_list_channels(self):
        mock_graph = AsyncMock(spec=GraphClient)
        mock_graph.get.return_value = {"value": [{"id": "c1"}, {"id": "c2"}]}
        teams = TeamsGraphClient(mock_graph)

        channels = await teams.list_channels("team1")

        assert len(channels) == 2

    @pytest.mark.asyncio
    async def test_list_teams(self):
        mock_graph = AsyncMock(spec=GraphClient)
        mock_graph.get.return_value = {"value": [{"id": "t1"}]}
        teams = TeamsGraphClient(mock_graph)

        result = await teams.list_teams()

        assert len(result) == 1
        mock_graph.get.assert_called_once_with("/me/joinedTeams")


# ── Graph Tools ──────────────────────────────────────────────────────────────


class TestGraphTools:
    def test_create_graph_tools_returns_five_tools(self):
        mock_graph = AsyncMock(spec=GraphClient)
        tools = create_graph_tools(mock_graph)
        assert len(tools) == 5

    def test_tool_names(self):
        mock_graph = AsyncMock(spec=GraphClient)
        tools = create_graph_tools(mock_graph)
        names = {t.name for t in tools}
        assert names == {
            "graph_mail_list",
            "graph_mail_send",
            "graph_mail_reply",
            "graph_mail_search",
            "graph_teams_send",
        }

    def test_tool_schemas_have_required_fields(self):
        mock_graph = AsyncMock(spec=GraphClient)
        tools = create_graph_tools(mock_graph)
        for tool in tools:
            schema = tool.to_openai_schema()
            assert "type" in schema
            assert schema["type"] == "function"
            assert "function" in schema
            func = schema["function"]
            assert "name" in func
            assert "description" in func
            assert "parameters" in func

    @pytest.mark.asyncio
    async def test_mail_list_tool_execute(self):
        mock_graph = AsyncMock(spec=GraphClient)
        mock_graph.get.return_value = {"value": [{"id": "m1", "subject": "Test"}]}

        tools = create_graph_tools(mock_graph)
        mail_list_tool = next(t for t in tools if t.name == "graph_mail_list")
        result = await mail_list_tool.execute(folder="inbox", top=5)

        assert "m1" in result
        assert "Test" in result

    @pytest.mark.asyncio
    async def test_teams_send_tool_missing_target(self):
        mock_graph = AsyncMock(spec=GraphClient)
        tools = create_graph_tools(mock_graph)
        teams_tool = next(t for t in tools if t.name == "graph_teams_send")

        result = await teams_tool.execute(content="Hello")
        assert "Error" in result
