"""Tests for model alias resolution in provider router."""

import os
from unittest.mock import patch

from pydantic import SecretStr

from workpilot.config.schema import (
    GitHubCopilotConfig,
    ModelAlias,
    ProviderConfig,
    ProvidersConfig,
)
from workpilot.providers.router import resolve_model


def _providers(**kwargs) -> ProvidersConfig:
    """Create a ProvidersConfig with specified keys set."""
    p = ProvidersConfig()
    if "anthropic" in kwargs:
        p.anthropic = ProviderConfig(api_key=SecretStr(kwargs["anthropic"]))
    if "openai" in kwargs:
        p.openai = ProviderConfig(api_key=SecretStr(kwargs["openai"]))
    if "github" in kwargs:
        p.github_copilot = GitHubCopilotConfig(token=SecretStr(kwargs["github"]))
    if "aliases" in kwargs:
        p.aliases = kwargs["aliases"]
    return p


class TestResolveModelConcreteIds:
    def test_concrete_model_returned_as_is(self):
        assert (
            resolve_model("anthropic/claude-sonnet-4-5-20250929")
            == "anthropic/claude-sonnet-4-5-20250929"
        )

    def test_concrete_model_ignores_providers(self):
        p = _providers(anthropic="key")
        assert resolve_model("openai/gpt-4o", p) == "openai/gpt-4o"


class TestAutoAlias:
    @patch.dict(os.environ, {}, clear=True)
    def test_auto_resolves_to_first_available(self):
        p = _providers(anthropic="sk-test")
        result = resolve_model("auto", p)
        assert result.startswith("anthropic/")

    @patch.dict(os.environ, {}, clear=True)
    def test_auto_prefers_github_over_anthropic(self):
        p = _providers(github="ghp_test", anthropic="sk-test")
        result = resolve_model("auto", p)
        assert result.startswith("github/")

    @patch.dict(os.environ, {}, clear=True)
    def test_auto_fallback_when_no_credentials(self):
        p = ProvidersConfig()
        result = resolve_model("auto", p)
        assert result == "openai/gpt-4o"  # fallback

    @patch.dict(os.environ, {}, clear=True)
    def test_auto_no_providers_arg(self):
        result = resolve_model("auto", None)
        assert result == "openai/gpt-4o"  # fallback


class TestFastAlias:
    @patch.dict(os.environ, {}, clear=True)
    def test_fast_prefers_cheap_models(self):
        p = _providers(anthropic="sk-test")
        result = resolve_model("fast", p)
        assert "haiku" in result.lower() or "mini" in result.lower()

    @patch.dict(os.environ, {}, clear=True)
    def test_fast_github_prefers_mini(self):
        p = _providers(github="ghp_test")
        result = resolve_model("fast", p)
        assert "mini" in result

    @patch.dict(os.environ, {}, clear=True)
    def test_fast_falls_back_to_default(self):
        p = ProvidersConfig()
        result = resolve_model("fast", p)
        assert result == "openai/gpt-4o"  # ultimate fallback


class TestReasoningAlias:
    @patch.dict(os.environ, {}, clear=True)
    def test_reasoning_prefers_strong_models(self):
        p = _providers(anthropic="sk-test")
        result = resolve_model("reasoning", p)
        assert "sonnet" in result.lower() or "opus" in result.lower()

    @patch.dict(os.environ, {}, clear=True)
    def test_reasoning_openai_prefers_o1(self):
        p = _providers(openai="sk-test")
        result = resolve_model("reasoning", p)
        assert "o1" in result


class TestCodingAlias:
    @patch.dict(os.environ, {}, clear=True)
    def test_coding_uses_auto_candidates(self):
        p = _providers(anthropic="sk-test")
        result = resolve_model("coding", p)
        # coding uses same candidates as auto
        assert result.startswith("anthropic/")


class TestUserConfiguredAliases:
    @patch.dict(os.environ, {}, clear=True)
    def test_alias_override_in_config(self):
        aliases = ModelAlias(fast="anthropic/claude-haiku-4-5-20251001")
        p = _providers(anthropic="sk-test", aliases=aliases)
        result = resolve_model("fast", p)
        assert result == "anthropic/claude-haiku-4-5-20251001"

    @patch.dict(os.environ, {}, clear=True)
    def test_alias_auto_falls_through(self):
        aliases = ModelAlias(fast="auto")  # default
        p = _providers(anthropic="sk-test", aliases=aliases)
        result = resolve_model("fast", p)
        # "auto" in alias → falls through to fast-specific auto-resolution
        assert "haiku" in result.lower() or "mini" in result.lower()

    @patch.dict(os.environ, {}, clear=True)
    def test_all_aliases_configurable(self):
        aliases = ModelAlias(
            default="openai/gpt-4o",
            fast="openai/gpt-4o-mini",
            reasoning="anthropic/claude-opus-4-5-20250929",
            coding="anthropic/claude-sonnet-4-5-20250929",
        )
        p = _providers(aliases=aliases)
        assert resolve_model("auto", p) == "openai/gpt-4o"
        assert resolve_model("fast", p) == "openai/gpt-4o-mini"
        assert resolve_model("reasoning", p) == "anthropic/claude-opus-4-5-20250929"
        assert resolve_model("coding", p) == "anthropic/claude-sonnet-4-5-20250929"
