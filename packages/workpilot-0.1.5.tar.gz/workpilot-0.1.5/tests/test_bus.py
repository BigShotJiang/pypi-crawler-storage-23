"""Tests for message bus and event bus."""

import asyncio

import pytest

from workpilot.bus.events import EventType, InboundMessage, OutboundMessage, StreamingChunk
from workpilot.bus.queue import EventBus, MessageBus


class TestMessageBus:
    @pytest.mark.asyncio
    async def test_inbound_publish_and_get(self):
        bus = MessageBus()
        msg = InboundMessage(
            channel="cli",
            channel_id="terminal",
            sender_id="user",
            sender_name="User",
            content="hello",
        )
        await bus.publish_inbound(msg)
        received = await bus.get_inbound()
        assert received.content == "hello"
        assert received.channel == "cli"

    @pytest.mark.asyncio
    async def test_outbound_handler(self):
        bus = MessageBus()
        received: list[OutboundMessage] = []

        async def handler(msg: OutboundMessage) -> None:
            received.append(msg)

        bus.on_outbound(handler)

        msg = OutboundMessage(channel="cli", channel_id="terminal", content="response")
        await bus.publish_outbound(msg)

        assert len(received) == 1
        assert received[0].content == "response"

    @pytest.mark.asyncio
    async def test_multiple_outbound_handlers(self):
        bus = MessageBus()
        count = [0]

        async def h1(msg: OutboundMessage) -> None:
            count[0] += 1

        async def h2(msg: OutboundMessage) -> None:
            count[0] += 10

        bus.on_outbound(h1)
        bus.on_outbound(h2)

        await bus.publish_outbound(OutboundMessage(channel="cli", channel_id="t", content="x"))
        assert count[0] == 11

    @pytest.mark.asyncio
    async def test_qsize(self):
        bus = MessageBus()
        assert bus.inbound_qsize == 0
        await bus.publish_inbound(
            InboundMessage(channel="c", channel_id="c", sender_id="u", sender_name="U", content="m")
        )
        assert bus.inbound_qsize == 1

    def test_message_bus_has_event_bus(self):
        bus = MessageBus()
        assert isinstance(bus.events, EventBus)


class TestStreamingChunk:
    def test_defaults(self):
        chunk = StreamingChunk(channel="cli", channel_id="t", content="hello")
        assert chunk.chunk_type == "token"
        assert chunk.done is False

    def test_tool_progress(self):
        chunk = StreamingChunk(
            channel="cli",
            channel_id="t",
            content="Running npm test...",
            chunk_type="tool_progress",
            done=False,
        )
        assert chunk.chunk_type == "tool_progress"


class TestEventType:
    def test_all_event_types_are_strings(self):
        for et in EventType:
            assert isinstance(et.value, str)
            assert "." in et.value

    def test_key_events_exist(self):
        assert EventType.TOOL_EXECUTED == "tool.executed"
        assert EventType.SECURITY_ESTOP == "security.estop"
        assert EventType.AGENT_ITERATION == "agent.iteration"


class TestEventBus:
    @pytest.mark.asyncio
    async def test_emit_and_subscribe(self):
        bus = EventBus()
        received = []

        async def handler(event_type, payload):
            received.append((event_type, payload))

        bus.on(EventType.TOOL_EXECUTED, handler)
        bus.emit(EventType.TOOL_EXECUTED, {"tool": "shell", "duration_ms": 100})

        await asyncio.sleep(0.05)  # let fire-and-forget task run
        assert len(received) == 1
        assert received[0][0] == EventType.TOOL_EXECUTED
        assert received[0][1]["tool"] == "shell"

    @pytest.mark.asyncio
    async def test_unsubscribe(self):
        bus = EventBus()
        received = []

        async def handler(event_type, payload):
            received.append(payload)

        bus.on(EventType.SECURITY_ALERT, handler)
        bus.off(EventType.SECURITY_ALERT, handler)
        bus.emit(EventType.SECURITY_ALERT, {"type": "leak"})

        await asyncio.sleep(0.05)
        assert len(received) == 0

    @pytest.mark.asyncio
    async def test_handler_error_isolation(self):
        bus = EventBus()
        received = []

        async def bad_handler(event_type, payload):
            raise RuntimeError("boom")

        async def good_handler(event_type, payload):
            received.append(payload)

        bus.on(EventType.TOOL_EXECUTED, bad_handler)
        bus.on(EventType.TOOL_EXECUTED, good_handler)
        bus.emit(EventType.TOOL_EXECUTED, {"tool": "git"})

        await asyncio.sleep(0.05)
        # good_handler should still receive the event despite bad_handler crashing
        assert len(received) == 1
        assert received[0]["tool"] == "git"

    @pytest.mark.asyncio
    async def test_no_subscribers_is_noop(self):
        bus = EventBus()
        bus.emit(EventType.COST_WARNING, {"cost": 5.0})  # should not raise

    @pytest.mark.asyncio
    async def test_multiple_event_types(self):
        bus = EventBus()
        tool_events = []
        security_events = []

        async def tool_handler(et, p):
            tool_events.append(p)

        async def security_handler(et, p):
            security_events.append(p)

        bus.on(EventType.TOOL_EXECUTED, tool_handler)
        bus.on(EventType.SECURITY_ALERT, security_handler)

        bus.emit(EventType.TOOL_EXECUTED, {"tool": "shell"})
        bus.emit(EventType.SECURITY_ALERT, {"type": "injection"})

        await asyncio.sleep(0.05)
        assert len(tool_events) == 1
        assert len(security_events) == 1
