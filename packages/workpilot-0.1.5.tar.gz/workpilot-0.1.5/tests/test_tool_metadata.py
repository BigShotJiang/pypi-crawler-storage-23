"""Tests for ToolMetadata, approval declarations, and anti-shadowing."""

import pytest

from workpilot.agent.tools.base import Tool, ToolMetadata
from workpilot.agent.tools.filesystem import (
    EditFileTool,
    ListDirTool,
    ReadFileTool,
    WriteFileTool,
)
from workpilot.agent.tools.git import GitTool
from workpilot.agent.tools.message import MessageTool
from workpilot.agent.tools.registry import PROTECTED_TOOLS, ToolRegistry
from workpilot.agent.tools.shell import ShellTool
from workpilot.agent.tools.spawn import SpawnTool
from workpilot.agent.tools.web import HttpRequestTool
from workpilot.security.sandbox import Sandbox

# ── Fixtures ─────────────────────────────────────────────────────────────────


@pytest.fixture
def sandbox(tmp_path):
    return Sandbox(workspace=tmp_path)


# ── ToolMetadata defaults ────────────────────────────────────────────────────


class TestToolMetadataDefaults:
    def test_default_values(self):
        m = ToolMetadata()
        assert m.risk_level == "low"
        assert m.isolation == "process"
        assert m.category == "builtin"
        assert m.approval == "auto"
        assert m.timeout == 600
        assert m.streaming is False

    def test_custom_values(self):
        m = ToolMetadata(risk_level="high", approval="always", timeout=30)
        assert m.risk_level == "high"
        assert m.approval == "always"
        assert m.timeout == 30


class TestBaseToolMetadata:
    def test_base_tool_has_default_metadata(self):
        class MinimalTool(Tool):
            @property
            def name(self):
                return "test"

            @property
            def description(self):
                return "test"

            @property
            def parameters(self):
                return {"type": "object", "properties": {}}

            async def execute(self, **kwargs):
                return "ok"

        t = MinimalTool()
        assert isinstance(t.metadata, ToolMetadata)
        assert t.metadata.approval == "auto"

    def test_base_tool_validate_returns_empty(self):
        class MinimalTool(Tool):
            @property
            def name(self):
                return "test"

            @property
            def description(self):
                return "test"

            @property
            def parameters(self):
                return {"type": "object", "properties": {}}

            async def execute(self, **kwargs):
                return "ok"

        t = MinimalTool()
        assert t.validate({}) == []


# ── Per-tool approval declarations ───────────────────────────────────────────


class TestShellMetadata:
    def test_approval_auto(self, sandbox):
        t = ShellTool(sandbox)
        assert t.metadata.approval == "auto"
        assert t.metadata.risk_level == "medium"


class TestFilesystemMetadata:
    def test_read_file_never(self, sandbox):
        t = ReadFileTool(sandbox)
        assert t.metadata.approval == "never"
        assert t.metadata.risk_level == "low"

    def test_write_file_never(self, sandbox):
        t = WriteFileTool(sandbox)
        assert t.metadata.approval == "never"
        assert t.metadata.risk_level == "medium"

    def test_edit_file_never(self, sandbox):
        t = EditFileTool(sandbox)
        assert t.metadata.approval == "never"
        assert t.metadata.risk_level == "medium"

    def test_list_dir_never(self, sandbox):
        t = ListDirTool(sandbox)
        assert t.metadata.approval == "never"
        assert t.metadata.risk_level == "low"


class TestGitMetadata:
    def test_approval_auto(self, sandbox):
        t = GitTool(sandbox)
        assert t.metadata.approval == "auto"
        assert t.metadata.risk_level == "medium"


class TestHttpMetadata:
    def test_approval_auto(self):
        t = HttpRequestTool()
        assert t.metadata.approval == "auto"
        assert t.metadata.risk_level == "medium"
        assert t.metadata.timeout == 60


class TestBrowserMetadata:
    def test_approval_always(self):
        from workpilot.agent.tools.browser import BrowserTool
        from workpilot.config.schema import BrowserConfig

        t = BrowserTool(BrowserConfig())
        assert t.metadata.approval == "always"
        assert t.metadata.risk_level == "high"


class TestMessageMetadata:
    def test_approval_never(self):
        from workpilot.bus.queue import MessageBus

        t = MessageTool(MessageBus())
        assert t.metadata.approval == "never"
        assert t.metadata.risk_level == "low"
        assert t.metadata.timeout == 30


class TestSpawnMetadata:
    def test_approval_auto(self):
        async def noop(a, p):
            return "ok"

        t = SpawnTool(noop)
        assert t.metadata.approval == "auto"
        assert t.metadata.risk_level == "medium"


# ── Anti-shadowing ───────────────────────────────────────────────────────────


class _DummyTool(Tool):
    def __init__(self, tool_name: str):
        self._name = tool_name

    @property
    def name(self):
        return self._name

    @property
    def description(self):
        return "dummy"

    @property
    def parameters(self):
        return {"type": "object", "properties": {}}

    async def execute(self, **kwargs):
        return "ok"


class TestProtectedTools:
    def test_protected_set_has_14_tools(self):
        assert len(PROTECTED_TOOLS) == 14

    def test_key_tools_are_protected(self):
        assert "shell" in PROTECTED_TOOLS
        assert "read_file" in PROTECTED_TOOLS
        assert "spawn" in PROTECTED_TOOLS
        assert "message" in PROTECTED_TOOLS
        assert "git" in PROTECTED_TOOLS


class TestAntiShadowing:
    def test_first_registration_succeeds(self):
        reg = ToolRegistry()
        reg.register(_DummyTool("shell"))
        assert reg.get("shell") is not None

    def test_second_registration_of_protected_raises(self):
        reg = ToolRegistry()
        reg.register(_DummyTool("shell"))
        with pytest.raises(ValueError, match="Cannot override protected"):
            reg.register(_DummyTool("shell"))

    def test_custom_tool_can_be_re_registered(self):
        reg = ToolRegistry()
        reg.register(_DummyTool("my_custom_tool"))
        reg.register(_DummyTool("my_custom_tool"))  # should not raise

    def test_unregister_then_register_protected_succeeds(self):
        reg = ToolRegistry()
        reg.register(_DummyTool("shell"))
        reg.unregister("shell")
        reg.register(_DummyTool("shell"))  # should succeed after unregister
