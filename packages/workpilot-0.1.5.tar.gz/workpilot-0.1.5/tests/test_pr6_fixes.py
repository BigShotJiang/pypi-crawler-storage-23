"""Tests for PR #6 Copilot review fixes (#6-#11)."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from workpilot.agent.loop import AgentLoop
from workpilot.agent.tools.base import Tool, ToolMetadata
from workpilot.agent.tools.registry import ToolRegistry
from workpilot.agents.builtin import get_builtin_agents, merge_agents
from workpilot.bus.events import EventType, InboundMessage, StreamingChunk
from workpilot.bus.queue import EventBus, MessageBus
from workpilot.config.schema import AgentConfig, AuditConfig
from workpilot.hooks.manager import (
    HookManager,
    HookResult,
)
from workpilot.providers.base import LLMChunk, LLMResponse, ToolCallRequest
from workpilot.security.audit import AuditLogger
from workpilot.session.manager import SessionManager

# ── Helpers ──────────────────────────────────────────────────────────────────


class _EchoTool(Tool):
    @property
    def name(self) -> str:
        return "echo"

    @property
    def description(self) -> str:
        return "Echo"

    @property
    def parameters(self) -> dict:
        return {"type": "object", "properties": {"text": {"type": "string"}}}

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(approval="never")

    async def execute(self, **kwargs) -> str:
        return f"echo: {kwargs.get('text', '')}"


def _make_loop(provider, tmp_path, *, hooks=None, config=None):
    reg = ToolRegistry(AuditLogger(AuditConfig(enabled=False)))
    reg.register(_EchoTool())
    return AgentLoop(
        config=config or AgentConfig(max_iterations=5, name="TestAgent"),
        provider=provider,
        tool_registry=reg,
        bus=MessageBus(),
        session_manager=SessionManager(tmp_path),
        audit=AuditLogger(AuditConfig(enabled=False)),
        workspace=tmp_path,
        hooks=hooks,
    )


def _provider(*responses):
    p = AsyncMock()
    resp_list = list(responses)
    stream_iter = iter(resp_list)
    p.complete = AsyncMock(side_effect=resp_list)

    # Provide a working stream() async generator for streaming path compatibility.
    # Each call to stream() yields a single chunk from the next response.
    async def _stream(**kwargs):
        r = next(stream_iter)
        yield LLMChunk(content=r.content, finish_reason=r.finish_reason, model=r.model)

    p.stream = _stream
    return p


# ── #6: merge_agents default_factory fields ──────────────────────────────────


class TestMergeAgentsDefaultFactory:
    """Fix #6: merge_agents() must work with default_factory fields (tools, metadata)."""

    def test_user_override_tools_applied(self):
        builtin = get_builtin_agents()
        user = {"explorer": AgentConfig(tools=["read_file", "shell"])}
        merged = merge_agents(builtin, user)
        assert "shell" in merged["explorer"].tools

    def test_user_override_metadata_applied(self):
        builtin = get_builtin_agents()
        user = {"explorer": AgentConfig(metadata={"custom": True})}
        merged = merge_agents(builtin, user)
        assert merged["explorer"].metadata.get("custom") is True

    def test_builtin_tools_preserved_when_user_has_defaults(self):
        """User config with default tools should NOT override builtin's specific tools."""
        builtin = get_builtin_agents()
        # User config with default max_iterations (same as AgentConfig default = 40)
        user = {"explorer": AgentConfig(timeout=60)}
        merged = merge_agents(builtin, user)
        # Explorer should keep its 15 iterations (not get overridden to 40)
        assert merged["explorer"].timeout == 60
        assert set(merged["explorer"].tools) == {"read_file", "list_dir", "search_files"}


# ── #7: OutboundHandler accepts StreamingChunk ───────────────────────────────


class TestOutboundStreamingChunk:
    """Fix #7: publish_outbound() should work with StreamingChunk."""

    @pytest.mark.asyncio
    async def test_streaming_chunk_dispatched_to_handler(self):
        bus = MessageBus()
        received = []

        async def handler(msg):
            received.append(msg)

        bus.on_outbound(handler)
        chunk = StreamingChunk(channel="cli", channel_id="t", content="partial")
        await bus.publish_outbound(chunk)
        assert len(received) == 1
        assert isinstance(received[0], StreamingChunk)
        assert received[0].content == "partial"


# ── #8: EventBus.emit() safe without event loop ─────────────────────────────


class TestEventBusSyncSafe:
    """Fix #8: emit() should not crash when no event loop is running."""

    def test_emit_without_event_loop_no_crash(self):
        bus = EventBus()
        received = []

        async def handler(et, p):
            received.append(p)

        bus.on(EventType.SECURITY_ALERT, handler)
        # This runs in a sync context — no event loop
        bus.emit(EventType.SECURITY_ALERT, {"type": "test"})
        # Should not raise; handler is skipped silently
        assert received == []


# ── #9: session_key used for routing ─────────────────────────────────────────


class TestSessionKeyRouting:
    """Fix #9: _process_message uses session_key when available."""

    @pytest.mark.asyncio
    async def test_session_key_takes_priority(self, tmp_path):
        provider = _provider(LLMResponse(content="ok", tool_calls=[]))
        loop = _make_loop(provider, tmp_path)

        msg = InboundMessage(
            channel="cloud",
            channel_id="cid",
            sender_id="user1",
            content="hello",
            session_key="cloud_teams:user1:thread42",
        )
        outbound = []
        loop._bus.on_outbound(AsyncMock(side_effect=lambda m: outbound.append(m)))
        await loop._process_message(msg)

        # Session should be stored under session_key, not channel:sender_id
        messages = loop._sessions.get_messages("cloud_teams:user1:thread42")
        assert len(messages) >= 2  # user + assistant

    @pytest.mark.asyncio
    async def test_fallback_to_session_id(self, tmp_path):
        provider = _provider(LLMResponse(content="ok", tool_calls=[]))
        loop = _make_loop(provider, tmp_path)

        msg = InboundMessage(
            channel="cli",
            channel_id="t",
            sender_id="user1",
            content="hello",
            session_id="explicit-sid",
        )
        outbound = []
        loop._bus.on_outbound(AsyncMock(side_effect=lambda m: outbound.append(m)))
        await loop._process_message(msg)

        messages = loop._sessions.get_messages("explicit-sid")
        assert len(messages) >= 2


# ── #10: agent_name in PreToolHookContext ────────────────────────────────────


class TestAgentNameInHookContext:
    """Fix #10: PreToolHookContext carries actual agent name, not 'default'."""

    @pytest.mark.asyncio
    async def test_pre_tool_hook_receives_agent_name(self, tmp_path):
        hooks = HookManager()
        captured_names = []

        async def capture(ctx):
            captured_names.append(ctx.agent_name)
            return HookResult.allow()

        hooks.register("pre_tool_use", capture)

        tc = ToolCallRequest(id="tc1", name="echo", arguments={"text": "hi"})
        provider = _provider(
            LLMResponse(content=None, tool_calls=[tc]),
            LLMResponse(content="done", tool_calls=[]),
        )
        loop = _make_loop(
            provider,
            tmp_path,
            hooks=hooks,
            config=AgentConfig(name="Explorer", max_iterations=5),
        )
        await loop.run_once("test")
        assert "Explorer" in captured_names


# ── #11: post_tool_use hook result applied ───────────────────────────────────


class TestPostToolHookResultApplied:
    """Fix #11: post_tool_use hook modifications propagate to tool result."""

    @pytest.mark.asyncio
    async def test_hook_can_modify_tool_output(self, tmp_path):
        hooks = HookManager()

        async def redact_hook(ctx):
            ctx.result = ctx.result.replace("secret123", "[REDACTED]")
            return HookResult.allow(data=ctx)

        hooks.register("post_tool_use", redact_hook)

        tc = ToolCallRequest(id="tc1", name="echo", arguments={"text": "secret123"})
        provider = _provider(
            LLMResponse(content=None, tool_calls=[tc]),
            LLMResponse(content="done", tool_calls=[]),
        )
        loop = _make_loop(provider, tmp_path, hooks=hooks)
        await loop.run_once("reveal secret")

        # Check that the second LLM call received the redacted tool result
        second_call = provider.complete.call_args_list[1]
        messages = second_call.kwargs.get("messages", [])
        tool_results = [m for m in messages if m.get("role") == "tool"]
        assert len(tool_results) == 1
        assert "secret123" not in tool_results[0]["content"]
        assert "[REDACTED]" in tool_results[0]["content"]
