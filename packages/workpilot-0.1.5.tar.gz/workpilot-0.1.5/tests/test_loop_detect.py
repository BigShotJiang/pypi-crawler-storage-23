"""Tests for loop detection — repeat, poll, ping-pong detectors."""

from workpilot.agent.loop_detect import (
    LoopDetector,
    PingPongDetector,
    PollDetector,
    RepeatDetector,
    _hash_args,
)


class TestHashArgs:
    def test_same_args_same_hash(self):
        assert _hash_args({"a": 1}) == _hash_args({"a": 1})

    def test_different_args_different_hash(self):
        assert _hash_args({"a": 1}) != _hash_args({"a": 2})

    def test_key_order_irrelevant(self):
        assert _hash_args({"a": 1, "b": 2}) == _hash_args({"b": 2, "a": 1})


class TestRepeatDetector:
    def test_no_repeat_under_threshold(self):
        d = RepeatDetector(threshold=3)
        h = _hash_args({"cmd": "ls"})
        assert d.check("shell", h) is None
        assert d.check("shell", h) is None  # only 2

    def test_repeat_at_threshold(self):
        d = RepeatDetector(threshold=3)
        h = _hash_args({"cmd": "ls"})
        d.check("shell", h)
        d.check("shell", h)
        msg = d.check("shell", h)
        assert msg is not None
        assert "repeating" in msg.lower()

    def test_different_tool_resets(self):
        d = RepeatDetector(threshold=3)
        h = _hash_args({"cmd": "ls"})
        d.check("shell", h)
        d.check("shell", h)
        d.check("read_file", _hash_args({"path": "x"}))  # break
        assert d.check("shell", h) is None  # reset, only 1

    def test_different_args_not_repeat(self):
        d = RepeatDetector(threshold=3)
        d.check("shell", _hash_args({"cmd": "ls"}))
        d.check("shell", _hash_args({"cmd": "pwd"}))
        d.check("shell", _hash_args({"cmd": "date"}))
        # All shell but different args — no repeat


class TestPollDetector:
    def test_no_poll_with_different_tools(self):
        d = PollDetector()
        d.check("shell", _hash_args({"cmd": "ls"}))
        d.check("read_file", _hash_args({"path": "x"}))
        assert d.check("git", _hash_args({"op": "status"})) is None

    def test_poll_detected(self):
        d = PollDetector()
        h = _hash_args({"url": "http://api/status"})
        d.check("http_request", h)
        d.check("read_file", _hash_args({"path": "log.txt"}))  # check result
        msg = d.check("http_request", h)  # same tool+args again
        assert msg is not None
        assert "polling" in msg.lower()

    def test_same_tool_different_args_no_poll(self):
        d = PollDetector()
        d.check("shell", _hash_args({"cmd": "ls"}))
        d.check("read_file", _hash_args({"path": "x"}))
        assert d.check("shell", _hash_args({"cmd": "pwd"})) is None


class TestPingPongDetector:
    def test_no_pingpong_under_threshold(self):
        d = PingPongDetector(threshold=4)
        d.check("shell", _hash_args({}))
        d.check("read_file", _hash_args({}))
        d.check("shell", _hash_args({}))
        assert d.check("read_file", _hash_args({})) is None  # only 4, need 8

    def test_pingpong_at_threshold(self):
        d = PingPongDetector(threshold=4)
        for _ in range(3):
            d.check("shell", _hash_args({}))
            d.check("read_file", _hash_args({}))
        d.check("shell", _hash_args({}))
        msg = d.check("read_file", _hash_args({}))  # 4th pair
        assert msg is not None
        assert "alternating" in msg.lower()

    def test_three_tools_no_pingpong(self):
        d = PingPongDetector(threshold=4)
        for _ in range(5):
            d.check("shell", _hash_args({}))
            d.check("read_file", _hash_args({}))
            d.check("git", _hash_args({}))
        # A-B-C pattern, not A-B-A-B


class TestLoopDetector:
    def test_no_loop_returns_none(self):
        d = LoopDetector()
        msg, terminate = d.check("shell", {"cmd": "ls"})
        assert msg is None
        assert terminate is False

    def test_first_detection_warns(self):
        d = LoopDetector(repeat_threshold=3)
        args = {"cmd": "ls"}
        d.check("shell", args)
        d.check("shell", args)
        msg, terminate = d.check("shell", args)
        assert msg is not None
        assert terminate is False  # first warning, not termination

    def test_persistent_loop_terminates(self):
        d = LoopDetector(repeat_threshold=2)
        args = {"cmd": "ls"}
        d.check("shell", args)
        msg1, term1 = d.check("shell", args)  # first detection
        assert msg1 is not None
        assert term1 is False

        # Continue the same pattern
        d.check("shell", args)
        msg2, term2 = d.check("shell", args)  # second detection
        assert msg2 is not None
        assert term2 is True  # should terminate

    def test_different_action_resets_warn(self):
        d = LoopDetector(repeat_threshold=2)
        args = {"cmd": "ls"}
        d.check("shell", args)
        d.check("shell", args)  # first detection, warned

        # Different tool — resets warned state
        d.check("read_file", {"path": "x"})
        msg, terminate = d.check("read_file", {"path": "x"})
        # New repeat detected, but warned was reset → warn, not terminate
        assert msg is not None
        assert terminate is False
