"""Tests for the Web Channel, E-stop middleware, auth updates, and new /api/* endpoints."""

from __future__ import annotations

import asyncio
import json
from unittest.mock import AsyncMock, MagicMock

import pytest
from pydantic import SecretStr

from workpilot.bus.events import StreamingChunk
from workpilot.bus.queue import MessageBus
from workpilot.channels.web import WebChannel
from workpilot.config.schema import GatewayConfig
from workpilot.gateway.auth import AuthMiddleware
from workpilot.gateway.estop_middleware import EStopMiddleware
from workpilot.security.estop import EStop

# ── WebChannel unit tests ──────────────────────────────────────────────────


class TestWebChannel:
    def test_name_is_web(self):
        bus = MessageBus()
        channel = WebChannel(bus)
        assert channel.name == "web"

    @pytest.mark.asyncio
    async def test_start_stop(self):
        bus = MessageBus()
        channel = WebChannel(bus)
        await channel.start()
        assert channel._running is True
        await channel.stop()
        assert channel._running is False

    @pytest.mark.asyncio
    async def test_register_and_send(self):
        bus = MessageBus()
        channel = WebChannel(bus)
        await channel.start()

        q = channel.register_request("test-id-1")
        await channel.send("test-id-1", "Hello response")
        result = await asyncio.wait_for(q.get(), timeout=1.0)
        assert result == "Hello response"

    @pytest.mark.asyncio
    async def test_send_ignores_unknown_channel_id(self):
        bus = MessageBus()
        channel = WebChannel(bus)
        await channel.start()
        # Should not raise
        await channel.send("nonexistent-id", "Hello")

    @pytest.mark.asyncio
    async def test_unregister_cleans_up(self):
        bus = MessageBus()
        channel = WebChannel(bus)
        await channel.start()

        channel.register_request("test-id-2")
        channel.register_stream("test-id-2")
        assert "test-id-2" in channel._response_queues
        assert "test-id-2" in channel._stream_queues

        channel.unregister_request("test-id-2")
        assert "test-id-2" not in channel._response_queues
        assert "test-id-2" not in channel._stream_queues

    @pytest.mark.asyncio
    async def test_stop_signals_queues(self):
        bus = MessageBus()
        channel = WebChannel(bus)
        await channel.start()

        q = channel.register_request("test-id-3")
        await channel.stop()
        # Queue should have None sentinel
        result = await asyncio.wait_for(q.get(), timeout=1.0)
        assert result is None

    def test_make_channel_id(self):
        cid = WebChannel.make_channel_id("web-req")
        assert cid.startswith("web-req-")
        assert len(cid) == len("web-req-") + 12


class TestWebChannelStreaming:
    @pytest.mark.asyncio
    async def test_register_stream_returns_queue(self):
        bus = MessageBus()
        channel = WebChannel(bus)
        q = channel.register_stream("sse-1")
        assert q is not None
        assert "sse-1" in channel._stream_queues

    @pytest.mark.asyncio
    async def test_send_streaming_routes_chunk(self):
        bus = MessageBus()
        channel = WebChannel(bus)
        q = channel.register_stream("sse-2")

        chunk = StreamingChunk(channel="web", channel_id="sse-2", content="Hello")
        await channel.send_streaming("sse-2", chunk)

        result = await asyncio.wait_for(q.get(), timeout=1.0)
        assert result.content == "Hello"

    @pytest.mark.asyncio
    async def test_send_streaming_ignores_unknown(self):
        bus = MessageBus()
        channel = WebChannel(bus)
        chunk = StreamingChunk(channel="web", channel_id="unknown", content="test")
        # Should not raise
        await channel.send_streaming("unknown", chunk)


class TestWebChannelSubmitAndWait:
    @pytest.mark.asyncio
    async def test_submit_and_wait_returns_response(self):
        bus = MessageBus()
        channel = WebChannel(bus)
        await channel.start()

        async def fake_agent():
            """Simulate agent consuming from bus and responding."""
            msg = await bus.get_inbound()
            await channel.send(msg.channel_id, "Agent response")

        agent_task = asyncio.create_task(fake_agent())

        result = await channel.submit_and_wait(
            channel_id="req-1",
            sender_id="test-user",
            content="Hello agent",
            timeout=5.0,
        )
        assert result == "Agent response"
        await agent_task

    @pytest.mark.asyncio
    async def test_submit_and_wait_timeout(self):
        bus = MessageBus()
        channel = WebChannel(bus)
        await channel.start()

        with pytest.raises(TimeoutError):
            await channel.submit_and_wait(
                channel_id="req-timeout",
                sender_id="test-user",
                content="Hello",
                timeout=0.1,
            )

    @pytest.mark.asyncio
    async def test_submit_and_wait_cleans_up_on_timeout(self):
        bus = MessageBus()
        channel = WebChannel(bus)
        await channel.start()

        with pytest.raises(TimeoutError):
            await channel.submit_and_wait(
                channel_id="req-cleanup",
                sender_id="test-user",
                content="Hello",
                timeout=0.1,
            )
        # Queue should be cleaned up
        assert "req-cleanup" not in channel._response_queues


# ── E-stop middleware tests ────────────────────────────────────────────────


class TestEStopMiddleware:
    @pytest.mark.asyncio
    async def test_passes_through_when_not_halted(self):
        estop = EStop()
        app_mock = AsyncMock()
        mw = EStopMiddleware(app_mock, estop)

        scope = {"type": "http", "path": "/api/chat"}
        await mw(scope, None, None)
        app_mock.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_returns_503_when_halted(self):
        estop = EStop()
        estop.trigger("test halt", actor="test")
        app_mock = AsyncMock()
        mw = EStopMiddleware(app_mock, estop)

        sent_messages = []

        async def mock_send(msg):
            sent_messages.append(msg)

        scope = {"type": "http", "path": "/api/chat"}
        await mw(scope, None, mock_send)

        # App should NOT be called
        app_mock.assert_not_awaited()
        # Should have sent 503
        assert sent_messages[0]["status"] == 503
        body = json.loads(sent_messages[1]["body"])
        assert body["error"] == "service_unavailable"
        assert "test halt" in body["message"]

    @pytest.mark.asyncio
    async def test_health_exempt_from_estop(self):
        estop = EStop()
        estop.trigger("halted", actor="test")
        app_mock = AsyncMock()
        mw = EStopMiddleware(app_mock, estop)

        scope = {"type": "http", "path": "/api/health"}
        await mw(scope, None, None)
        app_mock.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_estop_endpoint_exempt(self):
        estop = EStop()
        estop.trigger("halted", actor="test")
        app_mock = AsyncMock()
        mw = EStopMiddleware(app_mock, estop)

        scope = {"type": "http", "path": "/api/estop"}
        await mw(scope, None, None)
        app_mock.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_reset_endpoint_exempt(self):
        estop = EStop()
        estop.trigger("halted", actor="test")
        app_mock = AsyncMock()
        mw = EStopMiddleware(app_mock, estop)

        scope = {"type": "http", "path": "/api/reset"}
        await mw(scope, None, None)
        app_mock.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_non_api_paths_pass_through_when_halted(self):
        estop = EStop()
        estop.trigger("halted", actor="test")
        app_mock = AsyncMock()
        mw = EStopMiddleware(app_mock, estop)

        # Legacy /health and /v1/* should not be gated
        for path in ["/health", "/v1/chat/completions", "/webhooks/github"]:
            app_mock.reset_mock()
            scope = {"type": "http", "path": path}
            await mw(scope, None, None)
            app_mock.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_websocket_also_gated(self):
        estop = EStop()
        estop.trigger("halted", actor="test")
        app_mock = AsyncMock()
        mw = EStopMiddleware(app_mock, estop)

        sent_messages = []

        async def mock_receive():
            return {"type": "websocket.connect"}

        async def mock_send(msg):
            sent_messages.append(msg)

        scope = {"type": "websocket", "path": "/api/ws"}
        await mw(scope, mock_receive, mock_send)
        app_mock.assert_not_awaited()
        assert sent_messages[0]["type"] == "websocket.close"
        assert sent_messages[0]["code"] == 1013


# ── Auth middleware updates tests ──────────────────────────────────────────


class TestAuthXApiKey:
    def test_x_api_key_extracted(self):
        scope = {
            "headers": [
                (b"x-api-key", b"my-secret-key"),
            ],
        }
        result = AuthMiddleware._extract_x_api_key(scope)
        assert result == "my-secret-key"

    def test_x_api_key_case_insensitive(self):
        scope = {
            "headers": [
                (b"X-API-Key", b"my-secret-key"),
            ],
        }
        result = AuthMiddleware._extract_x_api_key(scope)
        assert result == "my-secret-key"

    def test_x_api_key_missing(self):
        scope = {"headers": []}
        result = AuthMiddleware._extract_x_api_key(scope)
        assert result is None

    def test_api_health_is_public(self):
        assert "/api/health" in AuthMiddleware._PUBLIC_PATHS

    def test_health_still_public(self):
        assert "/health" in AuthMiddleware._PUBLIC_PATHS


# ── GatewayConfig update ──────────────────────────────────────────────────


class TestGatewayConfigUpdate:
    def test_request_timeout_default(self):
        config = GatewayConfig()
        assert config.request_timeout == 300

    def test_request_timeout_custom(self):
        config = GatewayConfig(request_timeout=60)
        assert config.request_timeout == 60


# ── New /api/* schemas ─────────────────────────────────────────────────────


class TestNewSchemas:
    def test_chat_request(self):
        from workpilot.gateway.server import ChatRequest

        req = ChatRequest(prompt="Hello")
        assert req.prompt == "Hello"
        assert req.session_id is None

    def test_chat_response(self):
        from workpilot.gateway.server import ChatResponse

        resp = ChatResponse(response="Hi", session_id="web:user")
        assert resp.response == "Hi"

    def test_tool_info(self):
        from workpilot.gateway.server import ToolInfo

        ti = ToolInfo(
            name="shell", description="Run shell commands", risk_level="high", approval="always"
        )
        assert ti.name == "shell"
        assert ti.risk_level == "high"

    def test_health_detail_response(self):
        from workpilot.gateway.server import HealthDetailResponse

        h = HealthDetailResponse(status="ok")
        assert h.version is not None
        assert h.estop == {}
        assert h.bus == {}

    def test_estop_request(self):
        from workpilot.gateway.server import EStopRequest

        req = EStopRequest(reason="security breach")
        assert req.reason == "security breach"

    def test_estop_reset_request_default_actor(self):
        from workpilot.gateway.server import EStopResetRequest

        req = EStopResetRequest()
        assert req.actor == "api"


# ── Integration tests (FastAPI + httpx) ────────────────────────────────────


def _skip_if_no_fastapi():
    try:
        import fastapi  # noqa: F401
        import httpx  # noqa: F401
    except ImportError:
        pytest.skip("FastAPI or httpx not installed")


def _make_runtime_mock():
    """Create a mock Runtime with real bus, estop, and session manager."""
    from workpilot.session.manager import SessionManager

    runtime = MagicMock()
    runtime.bus = MessageBus()
    runtime.estop = EStop(events=runtime.bus.events)
    runtime.session_manager = SessionManager()

    # Mock tool registry
    mock_tool = MagicMock()
    mock_tool.name = "shell"
    mock_tool.description = "Run shell commands"
    mock_tool.metadata.risk_level = "high"
    mock_tool.metadata.approval = "always"
    runtime.tool_registry.list_tools.return_value = [mock_tool]

    return runtime


def _make_gateway_with_channel(runtime=None):
    """Create a GatewayServer with WebChannel wired up."""
    from workpilot.channels.web import WebChannel
    from workpilot.gateway.server import GatewayServer

    if runtime is None:
        runtime = _make_runtime_mock()

    config = GatewayConfig(enabled=True, api_key=None, entra_tenant_id="", entra_client_id="")
    server = GatewayServer(config, runtime)

    channel = WebChannel(runtime.bus)
    server.set_web_channel(channel)

    return server, channel, runtime


class TestApiEndpoints:
    @pytest.fixture(autouse=True)
    def _skip(self):
        _skip_if_no_fastapi()

    @pytest.mark.asyncio
    async def test_api_health(self):
        from httpx import ASGITransport, AsyncClient

        server, channel, runtime = _make_gateway_with_channel()
        async with AsyncClient(
            transport=ASGITransport(app=server.app), base_url="http://test"
        ) as client:
            resp = await client.get("/api/health")
            assert resp.status_code == 200
            data = resp.json()
            assert data["status"] == "ok"
            assert "estop" in data
            assert "bus" in data

    @pytest.mark.asyncio
    async def test_api_health_when_halted(self):
        from httpx import ASGITransport, AsyncClient

        server, channel, runtime = _make_gateway_with_channel()
        runtime.estop.trigger("test", actor="test")
        async with AsyncClient(
            transport=ASGITransport(app=server.app), base_url="http://test"
        ) as client:
            resp = await client.get("/api/health")
            assert resp.status_code == 200  # /api/health is exempt
            data = resp.json()
            assert data["status"] == "halted"

    @pytest.mark.asyncio
    async def test_api_chat(self):
        from httpx import ASGITransport, AsyncClient

        server, channel, runtime = _make_gateway_with_channel()
        await channel.start()

        async def fake_agent():
            msg = await runtime.bus.get_inbound()
            await channel.send(msg.channel_id, "Agent says hello")

        agent_task = asyncio.create_task(fake_agent())

        async with AsyncClient(
            transport=ASGITransport(app=server.app), base_url="http://test"
        ) as client:
            resp = await client.post("/api/chat", json={"prompt": "Hello"})
            assert resp.status_code == 200
            data = resp.json()
            assert data["response"] == "Agent says hello"
            assert "session_id" in data

        await agent_task

    @pytest.mark.asyncio
    async def test_api_chat_503_when_no_channel(self):
        from httpx import ASGITransport, AsyncClient

        from workpilot.gateway.server import GatewayServer

        runtime = _make_runtime_mock()
        config = GatewayConfig(enabled=True, api_key=None, entra_tenant_id="", entra_client_id="")
        server = GatewayServer(config, runtime)
        # Don't set web channel

        async with AsyncClient(
            transport=ASGITransport(app=server.app), base_url="http://test"
        ) as client:
            resp = await client.post("/api/chat", json={"prompt": "Hello"})
            assert resp.status_code == 503

    @pytest.mark.asyncio
    async def test_api_chat_estop_blocks(self):
        from httpx import ASGITransport, AsyncClient

        server, channel, runtime = _make_gateway_with_channel()
        runtime.estop.trigger("security breach", actor="test")

        async with AsyncClient(
            transport=ASGITransport(app=server.app), base_url="http://test"
        ) as client:
            resp = await client.post("/api/chat", json={"prompt": "Hello"})
            assert resp.status_code == 503
            data = resp.json()
            assert data["error"] == "service_unavailable"

    @pytest.mark.asyncio
    async def test_api_tools(self):
        from httpx import ASGITransport, AsyncClient

        server, channel, runtime = _make_gateway_with_channel()

        async with AsyncClient(
            transport=ASGITransport(app=server.app), base_url="http://test"
        ) as client:
            resp = await client.get("/api/tools")
            assert resp.status_code == 200
            data = resp.json()
            assert len(data) == 1
            assert data[0]["name"] == "shell"
            assert data[0]["risk_level"] == "high"

    @pytest.mark.asyncio
    async def test_api_sessions_empty(self):
        from httpx import ASGITransport, AsyncClient

        server, channel, runtime = _make_gateway_with_channel()

        async with AsyncClient(
            transport=ASGITransport(app=server.app), base_url="http://test"
        ) as client:
            resp = await client.get("/api/sessions")
            assert resp.status_code == 200
            assert resp.json() == []

    @pytest.mark.asyncio
    async def test_api_session_not_found(self):
        from httpx import ASGITransport, AsyncClient

        server, channel, runtime = _make_gateway_with_channel()

        async with AsyncClient(
            transport=ASGITransport(app=server.app), base_url="http://test"
        ) as client:
            resp = await client.get("/api/sessions/nonexistent")
            assert resp.status_code == 404

    @pytest.mark.asyncio
    async def test_api_session_crud(self):
        from httpx import ASGITransport, AsyncClient

        server, channel, runtime = _make_gateway_with_channel()
        sm = runtime.session_manager
        sm.add_message("web:user1", {"role": "user", "content": "Hello"})
        sm.add_message("web:user1", {"role": "assistant", "content": "Hi"})

        async with AsyncClient(
            transport=ASGITransport(app=server.app), base_url="http://test"
        ) as client:
            # Get session
            resp = await client.get("/api/sessions/web:user1")
            assert resp.status_code == 200
            data = resp.json()
            assert len(data["messages"]) == 2

            # Delete session
            resp = await client.delete("/api/sessions/web:user1")
            assert resp.status_code == 200
            assert resp.json()["status"] == "deleted"

    @pytest.mark.asyncio
    async def test_api_estop_trigger_and_reset(self):
        from httpx import ASGITransport, AsyncClient

        server, channel, runtime = _make_gateway_with_channel()

        async with AsyncClient(
            transport=ASGITransport(app=server.app), base_url="http://test"
        ) as client:
            # Trigger
            resp = await client.post("/api/estop", json={"reason": "test halt"})
            assert resp.status_code == 200
            data = resp.json()
            assert data["halted"] is True
            assert data["reason"] == "test halt"

            # Reset
            resp = await client.post("/api/reset", json={"actor": "admin"})
            assert resp.status_code == 200
            data = resp.json()
            assert data["halted"] is False

    @pytest.mark.asyncio
    async def test_api_estop_accessible_when_halted(self):
        """E-stop and reset endpoints are exempt from E-stop middleware."""
        from httpx import ASGITransport, AsyncClient

        server, channel, runtime = _make_gateway_with_channel()
        runtime.estop.trigger("halted", actor="test")

        async with AsyncClient(
            transport=ASGITransport(app=server.app), base_url="http://test"
        ) as client:
            # /api/estop should be accessible even when halted
            resp = await client.post("/api/estop", json={"reason": "double halt"})
            assert resp.status_code == 200

            # /api/reset should be accessible to clear the halt
            resp = await client.post("/api/reset", json={"actor": "admin"})
            assert resp.status_code == 200
            assert resp.json()["halted"] is False


class TestApiChatStream:
    @pytest.fixture(autouse=True)
    def _skip(self):
        _skip_if_no_fastapi()

    @pytest.mark.asyncio
    async def test_sse_returns_event_stream(self):
        from httpx import ASGITransport, AsyncClient

        server, channel, runtime = _make_gateway_with_channel()
        await channel.start()

        async def fake_agent():
            msg = await runtime.bus.get_inbound()
            await channel.send(msg.channel_id, "SSE response")

        agent_task = asyncio.create_task(fake_agent())

        async with AsyncClient(
            transport=ASGITransport(app=server.app), base_url="http://test"
        ) as client:
            resp = await client.post("/api/chat/stream", json={"prompt": "Hello"})
            assert resp.status_code == 200
            assert "text/event-stream" in resp.headers["content-type"]

            # Parse SSE events
            lines = resp.text.strip().split("\n\n")
            assert len(lines) >= 2

            # First event: message
            assert "event: message" in lines[0]
            data_line = [ln for ln in lines[0].split("\n") if ln.startswith("data:")][0]
            data = json.loads(data_line[5:].strip())
            assert data["content"] == "SSE response"

            # Last event: done
            assert "event: done" in lines[-1]

        await agent_task


class TestBackwardCompatibility:
    """Ensure existing endpoints still work after adding new /api/* routes."""

    @pytest.fixture(autouse=True)
    def _skip(self):
        _skip_if_no_fastapi()

    @pytest.mark.asyncio
    async def test_legacy_health(self):
        from httpx import ASGITransport, AsyncClient

        server, channel, runtime = _make_gateway_with_channel()

        async with AsyncClient(
            transport=ASGITransport(app=server.app), base_url="http://test"
        ) as client:
            resp = await client.get("/health")
            assert resp.status_code == 200
            assert resp.json()["status"] == "ok"

    @pytest.mark.asyncio
    async def test_legacy_health_not_blocked_by_estop(self):
        from httpx import ASGITransport, AsyncClient

        server, channel, runtime = _make_gateway_with_channel()
        runtime.estop.trigger("halted", actor="test")

        async with AsyncClient(
            transport=ASGITransport(app=server.app), base_url="http://test"
        ) as client:
            resp = await client.get("/health")
            assert resp.status_code == 200

    @pytest.mark.asyncio
    async def test_legacy_webhook(self):
        from httpx import ASGITransport, AsyncClient

        server, channel, runtime = _make_gateway_with_channel()

        async with AsyncClient(
            transport=ASGITransport(app=server.app), base_url="http://test"
        ) as client:
            resp = await client.post(
                "/webhooks/github",
                json={"event": "push", "payload": {"ref": "refs/heads/main"}},
            )
            assert resp.status_code == 200
            assert resp.json()["status"] == "accepted"


class TestRateLimiting:
    @pytest.fixture(autouse=True)
    def _skip(self):
        _skip_if_no_fastapi()

    @pytest.mark.asyncio
    async def test_api_chat_rate_limited(self):
        from httpx import ASGITransport, AsyncClient

        runtime = _make_runtime_mock()
        config = GatewayConfig(
            enabled=True,
            api_key=None,
            entra_tenant_id="",
            entra_client_id="",
            rate_limit_per_minute=2,
        )
        from workpilot.channels.web import WebChannel
        from workpilot.gateway.server import GatewayServer

        server = GatewayServer(config, runtime)
        channel = WebChannel(runtime.bus)
        server.set_web_channel(channel)
        await channel.start()

        async def fake_agent():
            while True:
                try:
                    msg = await asyncio.wait_for(runtime.bus.get_inbound(), timeout=1.0)
                    await channel.send(msg.channel_id, "response")
                except TimeoutError:
                    break

        agent_task = asyncio.create_task(fake_agent())

        async with AsyncClient(
            transport=ASGITransport(app=server.app), base_url="http://test"
        ) as client:
            # First 2 requests should succeed
            resp1 = await client.post("/api/chat", json={"prompt": "Hello"})
            assert resp1.status_code == 200
            resp2 = await client.post("/api/chat", json={"prompt": "Hello"})
            assert resp2.status_code == 200
            # Third should be rate limited
            resp3 = await client.post("/api/chat", json={"prompt": "Hello"})
            assert resp3.status_code == 429

        agent_task.cancel()
        try:
            await agent_task
        except asyncio.CancelledError:
            pass


class TestAuthWithApiKey:
    @pytest.fixture(autouse=True)
    def _skip(self):
        _skip_if_no_fastapi()

    @pytest.mark.asyncio
    async def test_x_api_key_accepted(self):
        from httpx import ASGITransport, AsyncClient

        runtime = _make_runtime_mock()
        config = GatewayConfig(enabled=True, api_key=SecretStr("test-key"))
        from workpilot.gateway.server import GatewayServer

        server = GatewayServer(config, runtime)

        async with AsyncClient(
            transport=ASGITransport(app=server.app), base_url="http://test"
        ) as client:
            resp = await client.get("/api/tools", headers={"X-API-Key": "test-key"})
            assert resp.status_code == 200

    @pytest.mark.asyncio
    async def test_x_api_key_rejected(self):
        from httpx import ASGITransport, AsyncClient

        runtime = _make_runtime_mock()
        config = GatewayConfig(enabled=True, api_key=SecretStr("test-key"))
        from workpilot.gateway.server import GatewayServer

        server = GatewayServer(config, runtime)

        async with AsyncClient(
            transport=ASGITransport(app=server.app), base_url="http://test"
        ) as client:
            resp = await client.get("/api/tools", headers={"X-API-Key": "wrong-key"})
            assert resp.status_code == 401

    @pytest.mark.asyncio
    async def test_bearer_still_works(self):
        from httpx import ASGITransport, AsyncClient

        runtime = _make_runtime_mock()
        config = GatewayConfig(enabled=True, api_key=SecretStr("test-key"))
        from workpilot.gateway.server import GatewayServer

        server = GatewayServer(config, runtime)

        async with AsyncClient(
            transport=ASGITransport(app=server.app), base_url="http://test"
        ) as client:
            resp = await client.get(
                "/api/tools",
                headers={"Authorization": "Bearer test-key"},
            )
            assert resp.status_code == 200

    @pytest.mark.asyncio
    async def test_no_auth_returns_401(self):
        from httpx import ASGITransport, AsyncClient

        runtime = _make_runtime_mock()
        config = GatewayConfig(enabled=True, api_key=SecretStr("test-key"))
        from workpilot.gateway.server import GatewayServer

        server = GatewayServer(config, runtime)

        async with AsyncClient(
            transport=ASGITransport(app=server.app), base_url="http://test"
        ) as client:
            resp = await client.get("/api/tools")
            assert resp.status_code == 401


# ── Web Chat UI tests ─────────────────────────────────────────────────────


class TestWebChatUI:
    @pytest.fixture(autouse=True)
    def _skip(self):
        _skip_if_no_fastapi()

    @pytest.mark.asyncio
    async def test_ui_served_at_root(self):
        from httpx import ASGITransport, AsyncClient

        server, channel, runtime = _make_gateway_with_channel()

        async with AsyncClient(
            transport=ASGITransport(app=server.app), base_url="http://test"
        ) as client:
            resp = await client.get("/")
            assert resp.status_code == 200
            assert "text/html" in resp.headers["content-type"]

    @pytest.mark.asyncio
    async def test_ui_contains_workpilot_branding(self):
        from httpx import ASGITransport, AsyncClient

        server, channel, runtime = _make_gateway_with_channel()

        async with AsyncClient(
            transport=ASGITransport(app=server.app), base_url="http://test"
        ) as client:
            resp = await client.get("/")
            assert resp.status_code == 200
            assert "WorkPilot" in resp.text

    @pytest.mark.asyncio
    async def test_ui_is_public_with_api_key(self):
        """UI page should be accessible even when API key auth is required."""
        from httpx import ASGITransport, AsyncClient

        runtime = _make_runtime_mock()
        config = GatewayConfig(enabled=True, api_key=SecretStr("test-key"))
        from workpilot.gateway.server import GatewayServer

        server = GatewayServer(config, runtime)

        async with AsyncClient(
            transport=ASGITransport(app=server.app), base_url="http://test"
        ) as client:
            resp = await client.get("/")
            assert resp.status_code == 200
            assert "WorkPilot" in resp.text

    def test_root_in_public_paths(self):
        assert "/" in AuthMiddleware._PUBLIC_PATHS

    def test_auth_config_in_public_paths(self):
        assert "/api/auth/config" in AuthMiddleware._PUBLIC_PATHS

    @pytest.mark.asyncio
    async def test_api_auth_config_endpoint(self):
        from httpx import ASGITransport, AsyncClient

        server, channel, runtime = _make_gateway_with_channel()

        async with AsyncClient(
            transport=ASGITransport(app=server.app), base_url="http://test"
        ) as client:
            resp = await client.get("/api/auth/config")
            assert resp.status_code == 200
            data = resp.json()
            assert "entra_enabled" in data
            assert "api_key_enabled" in data

    @pytest.mark.asyncio
    async def test_api_auth_config_public_with_key(self):
        """Auth config endpoint is public even when API key auth is enabled."""
        from httpx import ASGITransport, AsyncClient

        runtime = _make_runtime_mock()
        config = GatewayConfig(enabled=True, api_key=SecretStr("test-key"))
        from workpilot.gateway.server import GatewayServer

        server = GatewayServer(config, runtime)

        async with AsyncClient(
            transport=ASGITransport(app=server.app), base_url="http://test"
        ) as client:
            resp = await client.get("/api/auth/config")
            assert resp.status_code == 200
