"""Tests for the enhanced memory system: KnowledgeStore, MemoryStore, VectorIndex, HybridMemory."""

from pathlib import Path

import pytest

from workpilot.agent.memory import (
    HybridMemory,
    KnowledgeStore,
    MemoryStore,
    VectorIndex,
)

# ── KnowledgeStore (SQLite FTS5) ─────────────────────────────────────────────


class TestKnowledgeStore:
    @pytest.fixture
    def store(self, tmp_path: Path) -> KnowledgeStore:
        return KnowledgeStore(tmp_path)

    def test_add_returns_id(self, store: KnowledgeStore):
        row_id = store.add("Python is a programming language")
        assert isinstance(row_id, int)
        assert row_id > 0

    def test_count_after_add(self, store: KnowledgeStore):
        assert store.count() == 0
        store.add("fact one")
        store.add("fact two")
        assert store.count() == 2

    def test_get_by_id(self, store: KnowledgeStore):
        row_id = store.add("User prefers dark mode", category="preference")
        entry = store.get(row_id)
        assert entry is not None
        assert entry["content"] == "User prefers dark mode"
        assert entry["category"] == "preference"

    def test_get_nonexistent_returns_none(self, store: KnowledgeStore):
        assert store.get(9999) is None

    def test_search_fts5(self, store: KnowledgeStore):
        store.add("Python 3.11 is required for this project")
        store.add("TypeScript was used previously")
        store.add("The Python runtime handles orchestration")

        results = store.search("Python")
        assert len(results) >= 2
        # All results should contain "Python" in the content
        for r in results:
            assert "python" in r["content"].lower()

    def test_search_empty_query_returns_empty(self, store: KnowledgeStore):
        store.add("some fact")
        results = store.search("")
        assert results == []

    def test_search_no_matches(self, store: KnowledgeStore):
        store.add("Python is great")
        results = store.search("Rust")
        assert results == []

    def test_update_entry(self, store: KnowledgeStore):
        row_id = store.add("old content")
        store.update(row_id, "new content")
        entry = store.get(row_id)
        assert entry is not None
        assert entry["content"] == "new content"

    def test_update_fts_index_synced(self, store: KnowledgeStore):
        row_id = store.add("Python language")
        store.update(row_id, "Rust language")

        # Old content should not be found
        old_results = store.search("Python")
        old_ids = {r["id"] for r in old_results}
        assert row_id not in old_ids

        # New content should be found
        new_results = store.search("Rust")
        new_ids = {r["id"] for r in new_results}
        assert row_id in new_ids

    def test_delete_entry(self, store: KnowledgeStore):
        row_id = store.add("to be deleted")
        assert store.count() == 1
        store.delete(row_id)
        assert store.count() == 0
        assert store.get(row_id) is None

    def test_delete_removes_from_fts(self, store: KnowledgeStore):
        row_id = store.add("deletable fact")
        store.delete(row_id)
        results = store.search("deletable")
        assert len(results) == 0

    def test_add_with_source(self, store: KnowledgeStore):
        row_id = store.add("Fact from user", source="user")
        entry = store.get(row_id)
        assert entry["source"] == "user"

    def test_close(self, store: KnowledgeStore):
        store.add("fact")
        store.close()
        # After close, operations should raise an error
        with pytest.raises((RuntimeError, Exception)):
            store.add("another fact")


# ── MemoryStore (file-based) ─────────────────────────────────────────────────


class TestMemoryStore:
    def test_read_empty_memory(self, tmp_path: Path):
        store = MemoryStore(tmp_path)
        assert store.read_memory() == ""

    def test_write_and_read_memory(self, tmp_path: Path):
        store = MemoryStore(tmp_path)
        store.write_memory("User prefers Python 3.11")
        assert store.read_memory() == "User prefers Python 3.11"

    def test_append_and_read_history(self, tmp_path: Path):
        store = MemoryStore(tmp_path)
        store.append_history("Created a new PR")
        history = store.read_history()
        assert "Created a new PR" in history

    def test_empty_history(self, tmp_path: Path):
        store = MemoryStore(tmp_path)
        assert store.read_history() == ""

    def test_agent_name_scoping(self, tmp_path: Path):
        store = MemoryStore(tmp_path, agent_name="code-bot")
        store.write_memory("code-bot specific memory")

        expected_dir = tmp_path / "memory" / "agents" / "code-bot"
        assert expected_dir.is_dir()
        assert (expected_dir / "MEMORY.md").is_file()

    def test_agent_scoping_isolation(self, tmp_path: Path):
        store_a = MemoryStore(tmp_path, agent_name="bot-a")
        store_b = MemoryStore(tmp_path, agent_name="bot-b")

        store_a.write_memory("memory for A")
        store_b.write_memory("memory for B")

        assert store_a.read_memory() == "memory for A"
        assert store_b.read_memory() == "memory for B"

    def test_shared_memory_rw(self, tmp_path: Path):
        store = MemoryStore(tmp_path, agent_name="agent1")
        store.write_shared("shared knowledge")
        assert store.read_shared() == "shared knowledge"

    def test_shared_memory_accessible_across_agents(self, tmp_path: Path):
        store_a = MemoryStore(tmp_path, agent_name="agent-a")
        store_b = MemoryStore(tmp_path, agent_name="agent-b")

        store_a.write_shared("cross-agent knowledge")
        assert store_b.read_shared() == "cross-agent knowledge"

    def test_consolidation_prompt_structure(self, tmp_path: Path):
        store = MemoryStore(tmp_path)
        store.write_memory("existing fact")
        messages = [
            {"role": "user", "content": "How do I deploy?"},
            {"role": "assistant", "content": "Use the deploy command."},
        ]
        prompt = store.build_consolidation_prompt(messages)
        assert "existing fact" in prompt
        assert "deploy" in prompt

    def test_apply_consolidation(self, tmp_path: Path):
        store = MemoryStore(tmp_path)
        llm_response = (
            "Here is the consolidation:\n\n"
            "```memory\nUser knows Python. User prefers dark mode.\n```\n\n"
            "```history\nDiscussed deployment procedure.\n```"
        )
        store.apply_consolidation(llm_response)
        assert "Python" in store.read_memory()
        assert "deployment" in store.read_history()


# ── VectorIndex (numpy-based) ────────────────────────────────────────────────


class TestVectorIndex:
    @pytest.fixture
    def _check_numpy(self):
        try:
            import numpy  # noqa: F401
        except ImportError:
            pytest.skip("numpy not installed")

    @pytest.mark.usefixtures("_check_numpy")
    def test_available(self, tmp_path: Path):
        vi = VectorIndex(tmp_path, dimension=4)
        assert vi.available is True

    @pytest.mark.usefixtures("_check_numpy")
    def test_add_and_size(self, tmp_path: Path):
        vi = VectorIndex(tmp_path, dimension=4)
        vi.add(1, [1.0, 0.0, 0.0, 0.0])
        vi.add(2, [0.0, 1.0, 0.0, 0.0])
        assert vi.size == 2

    @pytest.mark.usefixtures("_check_numpy")
    def test_search_returns_most_similar(self, tmp_path: Path):
        vi = VectorIndex(tmp_path, dimension=4)
        vi.add(1, [1.0, 0.0, 0.0, 0.0])
        vi.add(2, [0.0, 1.0, 0.0, 0.0])
        vi.add(3, [0.9, 0.1, 0.0, 0.0])

        results = vi.search([1.0, 0.0, 0.0, 0.0], top_k=2)
        # ID 1 should be the most similar
        assert results[0][0] == 1
        # Second result should be ID 3 (near the query)
        assert results[1][0] == 3

    @pytest.mark.usefixtures("_check_numpy")
    def test_search_empty_index(self, tmp_path: Path):
        vi = VectorIndex(tmp_path, dimension=4)
        results = vi.search([1.0, 0.0, 0.0, 0.0])
        assert results == []

    @pytest.mark.usefixtures("_check_numpy")
    def test_remove(self, tmp_path: Path):
        vi = VectorIndex(tmp_path, dimension=4)
        vi.add(1, [1.0, 0.0, 0.0, 0.0])
        vi.add(2, [0.0, 1.0, 0.0, 0.0])
        vi.remove(1)
        assert vi.size == 1

    @pytest.mark.usefixtures("_check_numpy")
    def test_wrong_dimension_raises(self, tmp_path: Path):
        vi = VectorIndex(tmp_path, dimension=4)
        with pytest.raises(ValueError, match="dimension"):
            vi.add(1, [1.0, 0.0])  # wrong dimension

    @pytest.mark.usefixtures("_check_numpy")
    def test_persistence(self, tmp_path: Path):
        vi1 = VectorIndex(tmp_path, dimension=4)
        vi1.add(1, [1.0, 0.0, 0.0, 0.0])
        vi1.add(2, [0.0, 1.0, 0.0, 0.0])

        # Create a new VectorIndex pointing to the same path
        vi2 = VectorIndex(tmp_path, dimension=4)
        assert vi2.size == 2


# ── HybridMemory ─────────────────────────────────────────────────────────────


class TestHybridMemory:
    def test_initialization(self, tmp_path: Path):
        hm = HybridMemory(tmp_path)
        assert hm.memory_store is not None
        assert hm.knowledge is not None
        assert hm.vectors is not None

    def test_memory_proxy_methods(self, tmp_path: Path):
        hm = HybridMemory(tmp_path)
        hm.write_memory("Hybrid memory fact")
        assert hm.read_memory() == "Hybrid memory fact"

    def test_history_proxy(self, tmp_path: Path):
        hm = HybridMemory(tmp_path)
        hm.append_history("Discussed architecture")
        history = hm.read_history()
        assert "Discussed architecture" in history

    def test_add_knowledge(self, tmp_path: Path):
        hm = HybridMemory(tmp_path)
        entry_id = hm.add_knowledge("Python 3.11 required", category="fact")
        assert isinstance(entry_id, int)
        assert hm.knowledge.count() == 1

    def test_remove_knowledge(self, tmp_path: Path):
        hm = HybridMemory(tmp_path)
        entry_id = hm.add_knowledge("temporary fact")
        hm.remove_knowledge(entry_id)
        assert hm.knowledge.count() == 0

    def test_search_fts_only(self, tmp_path: Path):
        hm = HybridMemory(tmp_path)
        hm.add_knowledge("Python is the runtime language", category="fact")
        hm.add_knowledge("TypeScript was replaced", category="fact")

        results = hm.search("Python")
        assert len(results) >= 1
        assert any("Python" in r["content"] for r in results)
        # Each result should have a 'score' key
        for r in results:
            assert "score" in r

    def test_search_no_results(self, tmp_path: Path):
        hm = HybridMemory(tmp_path)
        hm.add_knowledge("Python fact")
        results = hm.search("Rust")
        assert results == []

    def test_agent_scoped_hybrid_memory(self, tmp_path: Path):
        hm = HybridMemory(tmp_path, agent_name="code-bot")
        hm.write_memory("code-bot memory")
        assert "code-bot memory" in hm.read_memory()

    def test_close(self, tmp_path: Path):
        hm = HybridMemory(tmp_path)
        hm.add_knowledge("fact")
        hm.close()
        # After close, the knowledge store should error
        with pytest.raises((RuntimeError, Exception)):
            hm.knowledge.add("new fact")

    def test_consolidation_proxy(self, tmp_path: Path):
        hm = HybridMemory(tmp_path)
        prompt = hm.build_consolidation_prompt(
            [
                {"role": "user", "content": "Tell me about Python"},
            ]
        )
        assert "Python" in prompt

    def test_apply_consolidation_proxy(self, tmp_path: Path):
        hm = HybridMemory(tmp_path)
        response = (
            "```memory\nPython 3.11 is required.\n```\n\n```history\nDiscussed Python version.\n```"
        )
        hm.apply_consolidation(response)
        assert "Python" in hm.read_memory()
        assert "version" in hm.read_history()
