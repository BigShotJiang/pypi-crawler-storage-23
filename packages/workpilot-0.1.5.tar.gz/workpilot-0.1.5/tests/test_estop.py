"""Tests for E-stop mechanism."""

import asyncio

import pytest

from workpilot.bus.events import EventType
from workpilot.bus.queue import EventBus
from workpilot.security.estop import EStop, EStopError


class TestEStop:
    def test_initially_not_halted(self):
        estop = EStop()
        assert not estop.is_halted
        assert estop.reason == ""

    def test_trigger_sets_halted(self):
        estop = EStop()
        estop.trigger("leak detected", actor="leak_detector")
        assert estop.is_halted
        assert estop.reason == "leak detected"

    def test_trigger_idempotent(self):
        estop = EStop()
        estop.trigger("first", actor="a")
        estop.trigger("second", actor="b")  # ignored
        assert estop.reason == "first"

    def test_reset_clears_halted(self):
        estop = EStop()
        estop.trigger("test", actor="admin")
        estop.reset(actor="admin")
        assert not estop.is_halted
        assert estop.reason == ""

    def test_reset_when_not_halted_is_noop(self):
        estop = EStop()
        estop.reset(actor="admin")  # should not raise
        assert not estop.is_halted

    def test_check_raises_when_halted(self):
        estop = EStop()
        estop.trigger("emergency", actor="system")
        with pytest.raises(EStopError, match="E-stop active"):
            estop.check()

    def test_check_passes_when_not_halted(self):
        estop = EStop()
        estop.check()  # should not raise

    def test_status_when_halted(self):
        estop = EStop()
        estop.trigger("leak", actor="detector")
        status = estop.status()
        assert status["halted"] is True
        assert status["reason"] == "leak"
        assert status["actor"] == "detector"
        assert status["triggered_at"] is not None

    def test_status_when_not_halted(self):
        estop = EStop()
        status = estop.status()
        assert status["halted"] is False
        assert status["triggered_at"] is None


class TestEStopWithEventBus:
    @pytest.mark.asyncio
    async def test_trigger_emits_event(self):
        events = EventBus()
        estop = EStop(events=events)
        received = []

        async def handler(et, payload):
            received.append(payload)

        events.on(EventType.SECURITY_ESTOP, handler)
        estop.trigger("test", actor="admin")

        await asyncio.sleep(0.05)
        assert len(received) == 1
        assert received[0]["action"] == "trigger"
        assert received[0]["reason"] == "test"

    @pytest.mark.asyncio
    async def test_reset_emits_event(self):
        events = EventBus()
        estop = EStop(events=events)
        received = []

        async def handler(et, payload):
            received.append(payload)

        events.on(EventType.SECURITY_ESTOP, handler)
        estop.trigger("test", actor="admin")
        estop.reset(actor="admin")

        await asyncio.sleep(0.05)
        assert len(received) == 2
        assert received[1]["action"] == "reset"


class TestEStopWithAudit:
    def test_trigger_logs_to_audit(self):
        logged = []

        class MockAudit:
            def log_security(self, **kwargs):
                logged.append(kwargs)

        estop = EStop(audit=MockAudit())
        estop.trigger("leak", actor="detector")
        assert len(logged) == 1
        assert logged[0]["event"] == "estop_triggered"
        assert logged[0]["severity"] == "critical"

    def test_reset_logs_to_audit(self):
        logged = []

        class MockAudit:
            def log_security(self, **kwargs):
                logged.append(kwargs)

        estop = EStop(audit=MockAudit())
        estop.trigger("leak", actor="detector")
        estop.reset(actor="admin")
        assert len(logged) == 2
        assert logged[1]["event"] == "estop_reset"
