# Cloud Gateway Server

> **Date**: 2026-03-02
> **Status**: Draft v2
> **Layer**: Cloud Gateway (standalone service — separate deployment from WorkPilot client)
> **Depends on**: [channel-cloud.md](../features/channel-cloud.md), [core/channel.md](../core/channel.md), [core/message-bus.md](../core/message-bus.md)
> **Related**: [channel-web.md](../features/channel-web.md) (Tier 2 self-hosted gateway, separate service)

---

## 0. Relationship to Other Specs

This document specifies the **server side** of the Cloud Gateway — the public SaaS service that WorkPilot clients connect to.

[channel-cloud.md](../features/channel-cloud.md) specifies the **client side** — the Python `CloudChannel` implementation inside the WorkPilot client codebase.

```
[channel-cloud.md]              [this document]
WorkPilot client (Python)  ←→  Cloud Gateway server (.NET 8 / C#)
  CloudChannel                   Azure App Service
  outbound WSS                   public HTTPS / WSS
```

---

## 1. Purpose

WorkPilot users run their agent on a local machine with no public IP. External platforms (Teams, browser Web Chat) need to reach it. The Cloud Gateway server is the public endpoint that makes this possible without the user setting up any infrastructure.

It is a **stateless relay** — it never executes agent logic, reads message content for processing, or stores user data. It only:

1. Authenticates incoming connections (Entra ID for clients and browsers; Bot Framework JWT for Teams)
2. Maintains an ephemeral registry of connected WorkPilot clients (`OID → WebSocket`)
3. Routes messages from external sources to the right user's client
4. Relays responses and streaming chunks back to the originating source
5. Buffers messages for offline clients (up to 1 hour, in-memory only)

---

## 2. Design Principles

### Stateless by design

All state held by the server is **ephemeral and in-memory** — no database, no file writes, no persistent storage of any kind. If the server restarts, all connections drop and clients reconnect automatically (exponential backoff per [channel-cloud.md §6](../features/channel-cloud.md)).

In-memory state (client connections, offline buffer, reply contexts) is a runtime concern, not a data concern. It is rebuilt naturally as clients reconnect.

**Implication for scale-out**: v1 runs as a single App Service instance. Multiple instances would require cross-instance WebSocket routing (e.g., via Azure SignalR Service), which is a larger architectural change deferred to a future version. ARR Affinity is not used; it is unreliable through reverse proxies.

### Content opacity

The server treats `content` fields as opaque byte sequences. It routes without reading, never stores, and never logs message text.

### @mention pass-through

The server forwards Teams message text verbatim, including `@WorkPilot` mention XML (`<at>WorkPilot</at>`). The Python client is responsible for stripping mentions before passing content to the Agent Loop.

### No secrets — Managed Identity everywhere

The server never holds API keys or client secrets for service-to-service authentication. All outbound auth uses the **User-Assigned Managed Identity (UAMI)**:

| Dependency | Auth method |
|-----------|------------|
| Bot Framework Connector (send Teams replies) | UAMI (`MicrosoftAppType: UserAssignedMSI`) |
| Application Insights telemetry ingestion | Connection string — **exception, see below** |
| Entra ID JWT validation (inbound) | Public JWKS endpoint — no credential needed |
| Bot Framework JWT validation (inbound) | Public JWKS endpoint — no credential needed |

`TenantId`, `ClientId`, and UAMI `ClientId` are public identifiers set directly in App Service Application Settings.

**Observability — standard logging interface**: All server code logs through `ILogger<T>` (ASP.NET Core standard interface). The backing sink is pluggable:

| Configuration | Sink |
|--------------|------|
| `ApplicationInsights:ConnectionString` set | Logs forwarded to Application Insights via SDK |
| `ApplicationInsights:ConnectionString` absent or empty | Logs written to stdout (Serilog console sink) |

This means Application Insights is entirely optional and can be wired in or removed without changing application code. The connection string is set directly in App Service Application Settings — it is not stored in Key Vault.

### Single-tenant (v1)

The Entra App Registration and Azure Bot Service registration are single-tenant. This is also required by Microsoft's deprecation of new multi-tenant bot registrations after July 31, 2025. See §6.4 for the future multi-tenant path.

---

## 3. Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│  External Sources                                                     │
│                                                                       │
│  ┌─────────────────────┐      ┌─────────────────────┐               │
│  │  Teams               │      │  Browser (Web Chat)  │               │
│  │  (Bot Framework)     │      │  (Entra ID OIDC)     │               │
│  └──────────┬──────────┘      └──────────┬──────────┘               │
│             │ POST /bot/teams             │ WSS /webchat              │
└─────────────┼─────────────────────────────┼─────────────────────────┘
              │                             │
┌─────────────▼─────────────────────────────▼─────────────────────────┐
│  Cloud Gateway Server (Azure App Service, .NET 8 / ASP.NET Core)     │
│                                                                       │
│  Auth                                                                 │
│  ├─ /connect   → JwtBearer (Authorization: Bearer header)            │
│  ├─ /webchat   → Cookie (HttpOnly JWT, set by /auth/callback)         │
│  └─ /bot/teams → CloudAdapter (Bot Framework JWT)                    │
│                                                                       │
│  Ephemeral In-Memory State                                            │
│  ├─ ClientRegistry    OID → List<ClientConnection>                   │
│  ├─ OfflineBuffer     OID → Queue<MessageFrame>  (1h TTL)            │
│  └─ ReplyContextStore channel_id → ReplyContext  (1h TTL)            │
│                                                                       │
│  Router                                                               │
│  ├─ Teams activity → OID → forward to client WSS                     │
│  ├─ Browser message → OID → forward to client WSS                    │
│  ├─ Client response → channel_id → reply via Bot Connector           │
│  └─ Client response → channel_id → forward to browser WSS           │
│                                                                       │
│  Health                                                               │
│  ├─ GET /health        (liveness — always public)                    │
│  └─ GET /health/ready  (readiness — always public)                   │
└──────────────────────────────────┬──────────────────────────────────┘
                                   │ WSS /connect
┌──────────────────────────────────▼──────────────────────────────────┐
│  WorkPilot Client (user's local machine)                              │
│  Python CloudChannel — all agent processing local                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 4. Endpoints

| Endpoint | Transport | Auth | Description |
|----------|-----------|------|-------------|
| `GET /connect` | WebSocket | Entra ID Bearer (Authorization header) | WorkPilot Python client connection — client config: `wss://<host>/connect` |
| `GET /` | HTTPS | None (redirect) | Web Chat SPA entry point — initiates Entra ID OIDC auth code flow |
| `GET /auth/callback` | HTTPS | None (OIDC code) | Entra ID auth callback — validates code, sets session cookie |
| `GET /webchat` | WebSocket | Session cookie (`Cookie` header) | Browser web chat connection — cookie sent automatically by browser |
| `POST /bot/teams` | HTTPS | Bot Framework JWT (CloudAdapter) | Inbound Teams activity |
| `GET /health` | HTTPS | None | Liveness probe — always 200 while process is alive |
| `GET /health/ready` | HTTPS | None | Readiness probe — 200 once server is fully initialised |

**`/health` response body:**
```json
{ "status": "ok", "version": "1.0.0" }
```

**`/health/ready` response body (200):**
```json
{ "status": "ready", "version": "1.0.0", "timestamp": "2026-03-02T12:00:00Z" }
```

`/health/ready` returns 503 only during startup before `CloudAdapter` and `IClientRegistry` are initialised. Once the server is running it always returns 200 — the relay is stateless and has no downstream dependencies to check.

### Not in scope (v1)

| Endpoint | Reason deferred |
|----------|----------------|
| `POST /bot/outlook` | Requires separate Azure Bot registration; different activity schema |
| `POST /webhooks/github` | Requires GitHub App registration; sender → user routing needs separate design |
| `POST /webhooks/ado` | Same as GitHub |
| Cloud Portal (`/portal/*`) | Phase 14 per [builtin-features.md §8](../builtin-features.md) |

---

## 5. Wire Protocol

All WebSocket messages are **JSON text frames** with a mandatory `type` field. The protocol is identical on both `/connect` and `/webchat` endpoints, with direction differences noted.

### 5.1 Server → Client (`/connect`)

#### `connected` — registration acknowledged

Sent immediately after the WebSocket upgrade is accepted. Signals how many buffered messages will follow.

```json
{
  "type": "connected",
  "buffered_count": 3
}
```

#### `message` — relay an inbound message to the Agent Loop

Field names match Python `InboundMessage` in [message-bus.md §5](../core/message-bus.md). The client constructs an `InboundMessage` from this frame and publishes it to its local Message Bus.

```json
{
  "type": "message",
  "channel": "cloud",
  "sender_id": "a7f3d9b2-4c1d-8f7a-b2e4-c1d8f7ab2e4c",
  "sender_name": "John Smith",
  "content": "Hello <at>WorkPilot</at> fix the auth bug in PR #42",
  "thread_id": "19:abc123@thread.v2",
  "channel_id": "cid_f47ac10b-58cc-4372-a567-0e02b2c3d479",
  "session_key": "cloud_teams:a7f3d9b2-4c1d-8f7a-b2e4-c1d8f7ab2e4c:19:abc123@thread.v2",
  "timestamp": "2026-03-02T12:00:00Z",
  "metadata": {
    "source": "cloud_teams",
    "tenant_id": "72f988bf-86f1-41af-91ab-2d7cd011db47"
  }
}
```

Field notes:

| Field | Notes |
|-------|-------|
| `content` | Verbatim from source — includes `<at>WorkPilot</at>` for Teams mentions. Client strips the mention. |
| `channel_id` | Opaque routing key generated by the server (`cid_{uuid}`). Must be echoed back in `response`/`chunk`. |
| `session_key` | Computed as `"{source}:{sender_id}:{thread_id}"`. Used by the Python `SessionManager`. |
| `thread_id` | Source-platform conversation ID. No prefix — the source is in `metadata.source`. |
| `metadata.source` | `"cloud_teams"` or `"cloud_webchat"`. Indicates the source channel and is used as the `{source}` prefix in `session_key`. |

#### `buffered_start` / `buffered_end` — offline buffer delivery

Wraps buffered messages so the client can handle them as a group.

```json
{ "type": "buffered_start", "count": 3 }
```
*(N × `message` frames)*
```json
{ "type": "buffered_end" }
```

#### `ping` — heartbeat from server

```json
{ "type": "ping" }
```

The client must reply with `pong` within 10 seconds or the connection is closed.

#### `error` — server notification

```json
{
  "type": "error",
  "code": "reply_context_expired",
  "channel_id": "cid_f47ac10b-58cc-4372-a567-0e02b2c3d479",
  "message": "The reply window for this message has expired. The response was not delivered."
}
```

Error codes (server → WorkPilot client, via `/connect`):

| Code | Trigger | `channel_id` present |
|------|---------|----------------------|
| `reply_context_expired` | Client sent `response`/`chunk` for an expired or unknown `channel_id` | Yes |
| `response_timeout` | Web Chat only — client did not respond within `ResponseTimeoutSeconds` (120 s); browser has been notified | Yes |
| `rate_limited` | Connection rate limit exceeded | No |
| `auth_expired` | Bearer token has expired (server closes connection after this) | No |
| `server_error` | Unexpected internal error | No |

Error codes (server → browser, via `/webchat`):

| Code | Trigger |
|------|---------|
| `agent_offline` | Browser sent a message but no WorkPilot client is connected for this user |
| `response_timeout` | Client did not respond within 120 s (Web Chat only) |
| `server_error` | Unexpected internal error |

---

### 5.2 Client → Server (`/connect`)

#### `response` — relay an outbound message back to the source

```json
{
  "type": "response",
  "channel_id": "cid_f47ac10b-58cc-4372-a567-0e02b2c3d479",
  "content": "Fixed the auth bug. PR #42 updated.",
  "thread_id": "19:abc123@thread.v2",
  "format": "markdown"
}
```

The server looks up `channel_id` in the Reply Context Store:
- Found, source = `teams` → send via Bot Connector
- Found, source = `webchat` → forward to browser WebSocket
- Not found (expired or unknown) → send `error(reply_context_expired)` to client

#### `chunk` — relay a streaming chunk back to the source

```json
{
  "type": "chunk",
  "channel_id": "cid_f47ac10b-58cc-4372-a567-0e02b2c3d479",
  "content": "Fixed the auth bug.",
  "chunk_type": "token",
  "done": false
}
```

Final chunk signals completion:

```json
{
  "type": "chunk",
  "channel_id": "cid_f47ac10b-58cc-4372-a567-0e02b2c3d479",
  "content": "",
  "chunk_type": "token",
  "done": true
}
```

`chunk_type` values mirror `StreamingChunk` from [message-bus.md §5](../core/message-bus.md):

| Value | Meaning | Forwarded to Teams | Forwarded to Web Chat |
|-------|---------|--------------------|-----------------------|
| `token` | LLM output token | Buffered until `done: true` | Real-time |
| `tool_progress` | Tool execution status | Buffered | Real-time |
| `status` | Agent lifecycle | Buffered | Real-time |

Teams has no streaming API. The server accumulates all chunks for a `channel_id` and sends one final message when `done: true` arrives. Optionally, a typing indicator activity is sent while buffering.

#### `pong` — heartbeat reply

```json
{ "type": "pong" }
```

---

### 5.3 Server ↔ Browser (`/webchat`)

#### Browser → Server

```json
{
  "type": "message",
  "content": "Fix the auth bug"
}
```

The browser does not send `thread_id` — it is assigned by the server and returned in the `connected` frame.

#### Server → Browser: `connected`

```json
{
  "type": "connected",
  "thread_id": "wc_a7f3d9b2-4c1d-8f7a-b2e4-c1d8f7ab2e4c",
  "buffered_count": 0
}
```

`thread_id` is deterministic: `wc_{full_oid}` (the user's full Entra Object ID with dashes, prefixed with `wc_`). This ensures all browser tabs for the same user share the same session (see §7).

#### Server → Browser: forwarded response/chunk

The server forwards `response` and `chunk` frames from the WorkPilot client to the browser, replacing `channel_id` with the browser's WebSocket identifier (opaque to the browser — it is not echoed back).

#### Server → Browser: agent offline

```json
{
  "type": "error",
  "code": "agent_offline",
  "message": "Your WorkPilot agent is offline. Start `workpilot cloud` on your machine to connect."
}
```

Sent when the browser sends a message but no client is connected for this user. The message is also added to the Offline Buffer.

---

## 6. Authentication

### 6.1 WorkPilot Python Client — `/connect`

The Python client sends the Entra ID access token in the standard HTTP `Authorization` header during the WebSocket upgrade. This is possible because Python's `websockets` library supports custom headers on the upgrade request.

```
GET /connect HTTP/1.1
Host: gateway.workpilot.example.com
Authorization: Bearer {entra-access-token}
Upgrade: websocket
Connection: Upgrade
```

ASP.NET Core JwtBearer middleware validates the token before the WebSocket upgrade is accepted. If validation fails, the server returns `401 Unauthorized` and the upgrade is rejected.

On success, extracts from token claims:

| Claim | Used for |
|-------|---------|
| `oid` | Immutable user Object ID → Client Registry key |
| `preferred_username` or `upn` | User Principal Name → display, session key `sender_id` |
| `tid` | Tenant ID → logged for future multi-tenant support |

### 6.2 Browser — `/webchat`

Browsers cannot set the `Authorization` header on a `WebSocket` upgrade request using the native browser API. The correct browser-native solution is a **server-set HttpOnly cookie**: the browser sends it automatically in the `Cookie` header on every request, including WebSocket upgrades — no query string, no client-side token handling.

#### Auth flow

```
1. Browser visits https://<gateway-host>/
   ↓
2. Server redirects to Entra ID OIDC auth endpoint (auth code flow)
   ↓
3. User authenticates in browser → Entra ID redirects to GET /auth/callback?code=...
   ↓
4. Server validates auth code with Entra ID, receives JWT
   ↓
5. Server sets cookie:
     Set-Cookie: session={signed-jwt}; HttpOnly; Secure; SameSite=Strict; Path=/
   ↓
6. Browser redirected to web chat SPA (https://<gateway-host>/)
   ↓
7. SPA opens WebSocket:
     GET /webchat HTTP/1.1
     Cookie: session={signed-jwt}          ← browser sends automatically
     Upgrade: websocket
   ↓
8. Server validates cookie, extracts OID + UPN, accepts WebSocket upgrade
```

#### Cookie properties

| Property | Value | Reason |
|----------|-------|--------|
| `HttpOnly` | Yes | JavaScript cannot read it — XSS protection |
| `Secure` | Yes | HTTPS only — enforced by App Service |
| `SameSite` | `Strict` | CSRF protection |
| `Path` | `/` | Sent on all paths including `/webchat` |
| Content | Signed JWT (from Entra ID) | Server validates signature on each request |

The cookie contains the Entra ID JWT directly. The server validates it with the same JwtBearer pipeline used for `/connect`. No separate session store is required.

### 6.3 Teams Bot — `/bot/teams`

Teams sends an HTTP POST with a Bot Framework JWT in the `Authorization` header. The server uses `CloudAdapter` from `Microsoft.Bot.Builder.Integration.AspNet.Core` to validate the request.

`CloudAdapter` validates:
1. JWT signature against Bot Framework JWKS (`https://login.botframework.com/v1/.well-known/keys`)
2. Audience = Bot App ID (the UAMI client ID)
3. Token not expired

This validates **who sent the request** (Bot Framework / Azure Bot Service), not the end user. The end user identity is inside the `Activity` payload: `activity.from.aadObjectId` = the user's Entra Object ID.

**Bot Framework authenticates via User-Assigned Managed Identity (UAMI) — no client secret.**

`CloudAdapter` is configured with `MicrosoftAppType: "UserAssignedMSI"`. The `ConfigurationServiceClientCredentialFactory` detects this type and uses `ManagedIdentityCredential` (from `Azure.Identity`) to authenticate outbound Bot Connector calls, with no password or secret of any kind.

```
appsettings:
  MicrosoftAppType:     "UserAssignedMSI"
  MicrosoftAppId:       {uami-client-id}      # UAMI client ID — not a secret
  MicrosoftAppTenantId: 72f988bf-86f1-41af-91ab-2d7cd011db47            # not a secret
```

The Azure Bot Service registration must also be configured with App type = **User-assigned managed identity** and App ID = the UAMI client ID.

### 6.4 Single-Tenant Registration & Future Path

**v1: Single-tenant**

The Azure Bot registration is `SingleTenant`. Only users in the configured Entra tenant can interact with the bot. This is the correct approach given Microsoft's deprecation of new multi-tenant bot registrations (effective July 31, 2025).

**Future: Multi-tenant**

Supporting multiple enterprise tenants requires a different architecture, since creating new multi-tenant bot registrations is no longer possible. Two options to evaluate at that time:

| Option | Description |
|--------|-------------|
| **Per-tenant bot registrations** | Each enterprise tenant registers their own Azure Bot pointing to the Cloud Gateway. Gateway validates `MicrosoftAppId` against a configured list. |
| **Tenant-specific deployments** | Each tenant gets a dedicated Cloud Gateway instance with its own single-tenant registration. Simpler auth, higher operational cost. |

The v1 codebase should make the tenant ID configurable (not hardcoded) to ease this future transition.

---

## 7. Session Key Derivation

Per [channel.md §4](../core/channel.md), the session key for Cloud channel messages follows a three-part format. The exact middle component differs by channel:

| Source | Format | Middle component |
|--------|--------|-----------------|
| `cloud_teams` | `cloud_teams:{oid}:{conversation_id}` | Entra OID |
| `cloud_webchat` | `cloud_webchat:{upn}:wc_{oid}` | UPN (for human readability in logs) |

The server computes and embeds `session_key` in every `message` frame. The Python client passes it to its `SessionManager` to load the correct conversation history.

| Source | `sender_id` (routing key) | `thread_id` | Example `session_key` |
|--------|--------------------------|-------------|----------------------|
| `cloud_teams` | `activity.from.aadObjectId` (Entra OID) | `activity.conversation.id` | `cloud_teams:a7f3d9b2-4c1d-8f7a-b2e4-c1d8f7ab2e4c:19:abc123@thread.v2` |
| `cloud_webchat` | Entra OID (`oid` claim) | `wc_{oid}` (full Entra OID with dashes) | `cloud_webchat:john@contoso.com:wc_a7f3d9b2-4c1d-8f7a-b2e4-c1d8f7ab2e4c` |

**Both Teams and Web Chat `sender_id` use the Entra OID** — immutable, unique, consistent across both channels. Using OID for both makes session keys stable regardless of UPN or display name changes. `sender_name` carries the human-readable display value (UPN or `from.name`) for presentation purposes only.

Note that the Web Chat `session_key` middle component (`cloud_webchat:{upn}:wc_{oid}`) embeds the UPN for human readability in session logs. This UPN is sourced directly from the OIDC `preferred_username`/`upn` auth claim (not from `sender_name`). The `sender_name` field in the wire frame is for display only and is not used as a routing or session-lookup key.

**Web Chat `thread_id` design**: `wc_{oid}` where `oid` is the **full Entra OID GUID with dashes preserved**. Example: OID `a7f3d9b2-4c1d-8f7a-b2e4-c1d8f7ab2e4c` → `thread_id = "wc_a7f3d9b2-4c1d-8f7a-b2e4-c1d8f7ab2e4c"`.

This is deterministic (same user always gets same `thread_id`), globally unique, and requires no truncation or collision reasoning. The server always returns this same `thread_id` in the `connected` frame regardless of how many browser tabs the user has open — ensuring all tabs share one conversation session.

---

## 8. Multi-User Routing

### 8.1 Routing Principle: Sender Identity, Not Addressee

All users install the **same shared** `@WorkPilot` bot. The `@WorkPilot` mention in a Teams message is only how the user invokes the bot — it carries no routing information for the server.

Routing is based entirely on **who sent the message**: `activity.from.aadObjectId` (the sender's Entra OID). The server uses this to find the sender's own WorkPilot client and forward the message to it.

```
User A types "@WorkPilot fix my bug"
  → Teams POSTs activity(from.aadObjectId = A_oid) to /bot/teams
  → server extracts A_oid → looks up A_oid in ClientRegistry → forwards to A's client
  → A's local agent processes, responds back through A's WebSocket

User B types "@WorkPilot help me"  (same bot, different user)
  → Teams POSTs activity(from.aadObjectId = B_oid) to /bot/teams
  → server extracts B_oid → looks up B_oid in ClientRegistry → forwards to B's client
  → B's local agent processes independently
```

Each user gets their **own agent** running on their own machine. The shared bot registration is purely an infrastructure convenience — it eliminates the need for every user to register their own bot and AAD app.

### 8.2 Client Registry

An in-memory mapping from Entra OID to all active WebSocket connections for that user:

```
ClientRegistry: OID → List<ClientConnection>

ClientConnection:
  oid: string
  upn: string
  socket: WebSocket
  connected_at: DateTimeOffset
  last_activity: DateTimeOffset    # updated on every frame received
```

Multiple connections per OID are allowed (user running `workpilot cloud` on home + work machine). When routing inbound messages, the server sends to the **most recently active** connection (highest `last_activity`).

### 8.3 Routing Inbound (External → Client)

```
Teams activity received (POST /bot/teams)
  │
  ├─ CloudAdapter validates Bot Framework JWT
  ├─ Extract activity.from.aadObjectId  (= Entra OID, routing key + sender_id)
  ├─ Extract activity.from.name         (= display name, for sender_name only)
  ├─ Extract activity.conversation.id   (= thread_id)
  ├─ Generate channel_id = "cid_{uuid}"
  ├─ Store ReplyContext(channel_id, owner_oid=from.aadObjectId, TTL=1h)
  ├─ Build "message" frame with session_key
  ├─ Look up OID in ClientRegistry
  │   ├─ Connected: send frame via WebSocket
  │   │             (no active timeout — wait for upstream agent to respond)
  │   └─ Offline:  enqueue in OfflineBuffer(OID, frame, TTL=1h)
  └─ Return HTTP 202 Accepted to Bot Framework immediately
     (async — do not await client response)
```

Teams (`cloud_teams`) uses a fire-and-forget model: the server returns 202 immediately and sends the reply via Bot Connector whenever the agent responds (within the 1-hour TTL). No server-side active timeout is applied — the agent's own timeout is the upstream limit.

Web Chat (`cloud_webchat`) messages use an active 120-second timeout because the browser is waiting on an open WebSocket and needs a feedback signal:

```
Browser sends "message" frame (/webchat WebSocket)
  │
  ├─ Authenticated OID already known (from /webchat upgrade)
  ├─ Generate channel_id = "cid_{uuid}"
  ├─ Store ReplyContext(channel_id, owner_oid=authenticated_oid, TTL=1h)
  ├─ Build "message" frame with session_key
  ├─ Look up OID in ClientRegistry
  │   ├─ Connected: send frame via WorkPilot client WebSocket
  │   │             start ResponseTimeout timer (120 s) for channel_id
  │   └─ Offline:  send "error(agent_offline)" to browser
  │                + enqueue in OfflineBuffer(OID, frame, TTL=1h)
  └─ (no HTTP response — this is a WebSocket frame)
```

### 8.4 Routing Outbound (Client → Source)

```
Client sends "response" or "chunk" frame (/connect WebSocket)
  │
  ├─ Extract channel_id from frame
  ├─ Extract sender_oid from the client's authenticated WebSocket connection
  ├─ Look up channel_id in ReplyContextStore
  │
  ├─ Not found (expired or unknown):
  │   └─ Send "error(reply_context_expired)" to client
  │
  ├─ Found, but context.owner_oid ≠ sender_oid:   ← ownership check
  │   ├─ Log SECURITY WARNING: "OID mismatch on channel_id — possible cross-user reply attempt"
  │   │   (log: sender_oid, context.owner_oid, channel_id — no content logged)
  │   └─ Send "error(reply_context_expired)" to client  (treat as not found; don't reveal owner)
  │
  ├─ Found, owner_oid matches, source = "teams":
  │   ├─ If "chunk" + done=false: buffer by channel_id
  │   ├─ If "response" OR "chunk" + done=true:
  │   │   ├─ Assemble full content from buffer + final frame
  │   │   ├─ Send reply via Bot Framework Connector
  │   │   │   POST {service_url}/v3/conversations/{conversation_id}/activities
  │   │   └─ Delete ReplyContext entry
  │
  └─ Found, owner_oid matches, source = "webchat":
      ├─ If "chunk": forward to browser WebSocket immediately
      └─ If "response": forward to browser WebSocket, delete ReplyContext entry
```

---

## 9. Teams Integration (Bot Framework)

### 9.1 Adapter Pattern

The server uses `CloudAdapter` from `Microsoft.Bot.Builder.Integration.AspNet.Core`. `CloudAdapter` is the modern replacement for `BotFrameworkHttpAdapter` and supports both public Azure and sovereign cloud deployments.

```
POST /bot/teams
  │
  └─ CloudAdapter.ProcessAsync(request, response, bot)
       │
       ├─ Validates Bot Framework JWT automatically
       ├─ Deserializes Activity from request body
       ├─ Calls IBot.OnTurnAsync(ITurnContext, cancellationToken)
       └─ Handles reply via ConnectorClient created from activity.ServiceUrl
```

The `IBot` implementation receives a validated `ITurnContext` containing the deserialized `Activity`.

### 9.2 Activity Fields Used

Teams `message` activities provide these routing-relevant fields:

| Field | Value | Used for |
|-------|-------|---------|
| `activity.from.aadObjectId` | User's Entra OID (GUID) | ClientRegistry lookup key AND `sender_id` in session_key |
| `activity.from.name` | User's display name (e.g., "John Smith") | `sender_name` in `message` frame (display only, not used for routing or session keys) |
| `activity.text` | Message content including `<at>` XML | `content` (verbatim) |
| `activity.conversation.id` | Teams conversation/channel ID | `thread_id`, part of `session_key` |
| `activity.serviceUrl` | Bot Framework reply endpoint | Stored in ReplyContext |
| `activity.channelData.tenant.id` | Entra tenant ID | `metadata.tenant_id` |

The server only processes `activity.type == "message"`. All other activity types (typing indicators, reactions, member added/removed, etc.) are acknowledged with HTTP 200 and discarded.

**Missing `aadObjectId`**: External guest accounts and some legacy accounts may not include `from.aadObjectId`. When this field is absent or empty, the server cannot match the sender to a WorkPilot client (routing requires Entra OID). The activity is acknowledged with HTTP 200 and silently discarded. A DEBUG log entry is written: `"Teams activity discarded: from.aadObjectId missing (from.id={id})"`. No error is returned to Teams.

### 9.3 @mention Pass-through

Teams message text contains mention markup:

```json
{
  "text": "Hello <at>WorkPilot</at> fix the auth bug",
  "entities": [
    {
      "type": "mention",
      "mentioned": { "id": "28:bot-app-id", "name": "WorkPilot" },
      "text": "<at>WorkPilot</at>"
    }
  ]
}
```

The server forwards `activity.text` **verbatim** as the `content` field — including the `<at>WorkPilot</at>` XML. The Python `CloudChannel` client is responsible for stripping the mention before constructing the `InboundMessage` for the Agent Loop.

### 9.4 Sending Replies via Bot Connector

When a `response` frame arrives with `source = "teams"`, the server sends the reply via the Bot Framework Connector:

1. Create `ConnectorClient` using `activity.serviceUrl` from the ReplyContext
2. Authenticate using Bot App credentials (client credentials grant via `ConfigurationServiceClientCredentialFactory`)
3. Build reply `Activity`:
   - `type: "message"`
   - `text: response.content`
   - `conversation: { id: conversation_id }`
   - `replyToId: original_activity_id` (for proper threading)
4. `POST {service_url}/v3/conversations/{conversation_id}/activities/{replyToId}`
5. On success: delete ReplyContext entry
6. On failure (e.g., Teams-side error): log error, send `server_error` to client

### 9.5 Streaming and Teams

Teams has no streaming API. The server buffers all `chunk` frames for a `channel_id` in memory (keyed by `channel_id`). When `done: true` arrives (or a `response` frame), the accumulated content is sent as a single reply.

Optionally, while buffering, the server sends a typing indicator activity to Teams (`activity.type = "typing"`). This provides feedback that the bot is "thinking."

Chunk buffer is bounded: max 100KB per `channel_id`. If exceeded, the response is truncated and a note is appended.

---

## 10. Reply Context Store

### 10.1 Structure

An in-memory map from `channel_id` to `ReplyContext`:

```
ReplyContext:
  channel_id: string            # "cid_{uuid}" — the key
  owner_oid: string             # Entra OID of the WorkPilot user whose client received this message
                                # = from.aadObjectId (Teams) or browser user OID (Web Chat)
                                # Used to validate that only the correct client can respond
  source: "cloud_teams" | "cloud_webchat"
  created_at: DateTimeOffset
  expires_at: DateTimeOffset    # created_at + 1 hour

  // Teams-specific fields:
  service_url: string           # e.g., "https://smba.trafficmanager.net/amer/"
  conversation_id: string       # Bot Framework conversation ID
  activity_id: string           # Original activity ID (for replyToId)
  from_id: string               # Bot Framework user ID ("29:...")
  tenant_id: string             # Entra tenant ID

  // Web Chat-specific fields:
  webchat_connection_id: string # Identifier of the browser WebSocket

  // For Teams streaming buffer:
  chunk_buffer: List<string>    # Accumulated chunk content (cleared after send)
```

This is ephemeral routing metadata only. No message content is stored beyond the chunk buffer needed for Teams reply assembly.

`owner_oid` is set when the ReplyContext is created (from the Teams activity's `from.aadObjectId` or the browser's authenticated OID). It is the security boundary for multi-user isolation — see §8.4.

**Stale `webchat_connection_id`**: A Web Chat browser WebSocket may close while its message is being processed by the client's agent. When the client sends a `response` and the server looks up the `webchat_connection_id`, if that WebSocket is no longer open, the server drops the response silently and logs at DEBUG: `"webchat_connection_id {id} no longer active — response dropped"`. The browser will not receive this particular response. The user can reload the web chat and send again.

### 10.2 Response Timeout (Web Chat only — 120 s)

The active response timeout **only applies to Web Chat** (`source = "webchat"`). A browser holds an open WebSocket waiting for a reply; it needs a feedback signal if the agent is slow.

When the server forwards a `message` frame to the WorkPilot client for a Web Chat request, a **120-second timer** starts for that `channel_id`. If no `response` and no `chunk (done: true)` arrives before the timer fires:

1. Send `error(response_timeout, channel_id=...)` to the **browser** WebSocket
2. Send `error(response_timeout, channel_id=...)` to the **client** WebSocket so it knows the reply was not delivered
3. Delete the ReplyContext entry and discard any buffered chunks for that `channel_id`

The timer is cancelled immediately when a valid `response` or `chunk (done=true)` is received.

**Teams (Bot Framework) has no active timeout.** The server returns HTTP 202 immediately and waits for the agent to respond within the TTL window. The upstream agent's own execution timeout is the effective limit. If the agent never responds, the TTL cleanup (§10.3) eventually evicts the entry. Teams simply shows the message as unanswered — no server-generated error reply is sent.

### 10.3 TTL Expiry

The TTL (1 hour) is the **passive cleanup mechanism** for both Teams and Web Chat contexts. When the TTL expires, the entry is silently evicted with no action taken toward the source channel.

If the client sends a `response` or `chunk` for a `channel_id` whose TTL has already expired:

1. Looks up `channel_id` — not found
2. Sends `error(reply_context_expired, channel_id=...)` to the client

TTL eviction runs as a background timer (scan every 5 minutes, evict all entries where `expires_at < now`).

---

## 11. Offline Buffer

When a client is offline (no entry in ClientRegistry for that OID), inbound messages are held temporarily:

```
OfflineBuffer: OID → Queue<MessageFrame>

Per-message TTL: 1 hour (configurable, matches ReplyContext TTL)
Max messages per OID: 100 (oldest dropped first when at capacity)
```

On client reconnect:
1. Server sends `connected` with `buffered_count`
2. Server sends `buffered_start` with count
3. Server delivers each non-expired message frame in FIFO order
4. Server sends `buffered_end`
5. Buffer for that OID is cleared

The Offline Buffer is in-memory only. Messages are lost if the server restarts. This is acceptable given the stateless design principle — the user will simply need to re-send via the source channel.

---

## 12. Connection Management

### 12.1 Heartbeat

Every 30 seconds (configurable), the server sends a `ping` frame to each connected WorkPilot client. If no `pong` is received within 10 seconds, the connection is marked stale and closed. The client is removed from the ClientRegistry. The Python client's auto-reconnect (exponential backoff) handles reconnection.

The heartbeat also serves as a proxy-keepalive, preventing Azure App Service idle-connection timeouts (default: 240 seconds).

### 12.2 Reconnect (Client Responsibility)

The Python `CloudChannel` handles reconnect automatically. Per [channel-cloud.md §6](../features/channel-cloud.md):
- Initial retry delay: 1 second
- Backoff: exponential (×2 each attempt)
- Max retry delay: 60 seconds
- Attempts: unlimited until explicitly stopped

The server has no reconnect logic — it accepts new WebSocket connections and re-registers them.

### 12.3 Multiple Clients

A user running `workpilot cloud` on multiple machines has multiple entries in ClientRegistry. All are valid simultaneously. Inbound messages are routed to the most recently active connection. All connections receive offline buffer delivery on reconnect (but only the first to reconnect will receive the buffered messages — subsequent reconnects find an empty buffer).

### 12.4 Single Instance (v1)

v1 deploys as a single App Service instance. No scale-out is supported because WebSocket connections are pinned to the process that accepted them, and the in-memory ClientRegistry is process-local.

ARR Affinity (Azure's sticky session cookie) is **not** relied upon — it is unreliable through reverse proxies. Instead, scale-out is deferred to a future version that would use Azure SignalR Service as the WebSocket backplane, replacing the in-process ClientRegistry.

The App Service Plan SKU should be sized for the expected concurrent WebSocket connections (each is ~4KB memory; a P2v3 can handle ~50,000 idle WebSocket connections).

---

## 13. Security

| Concern | How |
|---------|-----|
| **Client auth** | Entra ID Bearer JWT via `Microsoft.Identity.Web` JwtBearer middleware |
| **Browser auth** | Entra ID OIDC auth code flow → server sets HttpOnly Secure SameSite=Strict cookie → browser sends `Cookie` header automatically on WebSocket upgrade → server validates JWT from cookie |
| **Teams auth** | Bot Framework JWT validated by `CloudAdapter` before `IBot.OnTurnAsync` is called |
| **Content opacity** | `content` field is forwarded without reading, inspection, or logging |
| **No message storage** | Offline Buffer stores `message` frames (JSON), not parsed content. ReplyContext stores routing metadata only. |
| **Audit log** | Logs: endpoint, user OID (not UPN), HTTP status, duration. Message content is never logged. |
| **No auth secrets** | All service-to-service auth uses Managed Identity — no API keys, no client secrets. Exception: Application Insights connection string may optionally be stored in Key Vault (it is not an auth credential but controls a billable resource). |
| **Transport** | HTTPS/WSS enforced at App Service level (HTTPS-only setting). TLS 1.2 minimum. |
| **Rate limiting** | Per-user OID: max 5 concurrent WebSocket connections, max 60 HTTP requests/minute |
| **Session cookie** | HttpOnly, Secure, SameSite=Strict — JWT never appears in URLs, logs, or JavaScript. |
| **Cross-user reply isolation** | `ReplyContext.owner_oid` validated against the responding client's OID before delivering any response. Mismatch → logged as SECURITY WARNING, treated as `reply_context_expired`. Prevents a user from sending a response into another user's conversation. |
| **Injection** | Not a server concern — content passes through opaquely. Python client handles prompt injection detection. |

---

## 14. Azure Deployment

### 14.1 Azure Resources

| Resource | SKU / Tier | Purpose |
|----------|-----------|---------|
| App Service Plan | P2v3 (prod) / B2 (dev) | Linux, .NET 8 |
| App Service | Linux, .NET 8 runtime | Cloud Gateway process |
| User-Assigned Managed Identity (UAMI) | — | Bot Framework app identity; assigned to App Service; used for Bot Connector auth |
| Application Insights | Workspace-based | Logs, metrics, traces (content-free); configured via connection string; **optional** |
| Log Analytics Workspace | PerGB2018 | Application Insights backend; only needed if Application Insights is enabled |
| Azure Bot Service | F0 (dev) / S1 (prod) | Teams channel registration; app type = User-assigned managed identity |
| Azure Key Vault | Standard | Optional — no items stored in v1; retained as pattern for future use |

### 14.2 Entra App Registrations

**Server registration** (`WorkPilot Cloud Gateway`):

| Setting | Value |
|---------|-------|
| Supported account types | Single tenant |
| Expose an API | App ID URI: `api://{client-id}` |
| Scope | `connect` (used by Python client to request access) |
| App roles | `Gateway.User` |
| Redirect URIs | None (API only — no browser login to this registration) |

**Client registration** (`WorkPilot CLI`):

| Setting | Value |
|---------|-------|
| Supported account types | Single tenant |
| Redirect URI | `http://localhost` (for device code flow callback) |
| API permission | Delegated `api://{server-client-id}/connect` |

**Web Chat browser login** uses the **Client registration** with an additional redirect URI for the Cloud Gateway web chat URL (`https://{gateway-host}/auth/callback`). The browser authenticates via OIDC auth code flow; the server sets a session cookie on completion.

### 14.3 App Service Configuration

Most settings are non-secret identifiers set directly in App Settings. The Application Insights connection string is the single exception — it may optionally be stored in Key Vault.

```
ASPNETCORE_ENVIRONMENT                        = Production
MicrosoftAppType                              = UserAssignedMSI
MicrosoftAppId                                = {uami-client-id}
MicrosoftAppTenantId                          = 72f988bf-86f1-41af-91ab-2d7cd011db47
AzureAd__Instance                             = https://login.microsoftonline.com/
AzureAd__TenantId                             = 72f988bf-86f1-41af-91ab-2d7cd011db47
AzureAd__ClientId                             = {gateway-entra-app-client-id}
AzureAd__Audience                             = api://{gateway-entra-app-client-id}

# Application Insights — optional, three ways to configure:
#   a) Set directly (connection string is not an auth credential):
ApplicationInsights__ConnectionString         = {ai-connection-string}
#   b) Protect in Key Vault and reference here:
ApplicationInsights__ConnectionString         = @Microsoft.KeyVault(SecretUri=https://{vault}.vault.azure.net/secrets/AppInsightsConnectionString/)
#   c) Omit entirely to disable Application Insights.
```

Application Insights is **optional**. If `ApplicationInsights__ConnectionString` is absent or empty, the SDK is not initialised and no telemetry is sent.

The App Service must have the UAMI **assigned as a user-assigned identity** in addition to the system-assigned identity.

App Service settings:
- User-assigned identity: the UAMI resource
- WebSockets: **Enabled** (required for WSS relay)
- Always On: Enabled
- HTTPS Only: Enforced
- Minimum TLS: 1.2
- Health check path: `/health/ready`
- ARR Affinity: **Disabled** (single instance; no sticky sessions needed)

### 14.4 Azure Bot Service

The Azure Bot Service registration links Teams to the Cloud Gateway:
- Messaging endpoint: `https://{app-service-hostname}/bot/teams`
- **App type: User-assigned managed identity**
- **App ID: UAMI client ID** (not an Entra app registration client ID)
- Teams channel: enabled

Using UAMI as the bot identity means no client secret is ever created or stored. The Azure Bot Service validates the bot's identity via the managed identity token chain.

Users install the bot into their Teams via admin consent or self-install from the Teams App Catalog. Once installed, any message to `@WorkPilot` in Teams triggers a POST to `/bot/teams`.

---

## 15. Configuration

Full `appsettings.json` schema:

```json
{
  "AzureAd": {
    "Instance": "https://login.microsoftonline.com/",
    "TenantId": "72f988bf-86f1-41af-91ab-2d7cd011db47",
    "ClientId": "__set_in_app_settings__",
    "Audience": "api://__ClientId__"
  },
  "MicrosoftAppType": "UserAssignedMSI",
  "MicrosoftAppId": "__set_in_app_settings__",       // UAMI client ID — not a secret
  "MicrosoftAppTenantId": "72f988bf-86f1-41af-91ab-2d7cd011db47",
  "Teams": {
    "Enabled": true
  },
  "Relay": {
    "HeartbeatIntervalSeconds": 30,
    "HeartbeatTimeoutSeconds": 10,
    "OfflineBufferTtlMinutes": 60,
    "OfflineBufferMaxMessages": 100,
    "ResponseTimeoutSeconds": 120,           // Web Chat only; Teams has no active timeout
    "ReplyContextTtlMinutes": 60,
    "ReplyContextEvictionIntervalMinutes": 5,
    "ChunkBufferMaxBytes": 102400
  },
  "RateLimit": {
    "HttpRequestsPerMinute": 60,
    "MaxWebSocketConnectionsPerUser": 5
  },
  "ApplicationInsights": {
    "ConnectionString": ""    // optional — leave empty or omit to disable Application Insights
  }
}
```

No `MicrosoftAppPassword` field. No Key Vault references. All values are non-secret identifiers set directly in App Service Application Settings via Bicep. Application Insights is optional — omit `ConnectionString` to disable it and log to stdout only.
```

---

## 16. Implementation Notes

### 16.1 Tech Stack & Key NuGet Packages

| Package | Version | Purpose |
|---------|---------|---------|
| `Microsoft.Identity.Web` | 3.8.2+ | Entra ID JWT validation for `/connect` and `/webchat/token` |
| `Microsoft.Bot.Builder.Integration.AspNet.Core` | 4.23.0+ | `CloudAdapter` with `UserAssignedMSI` support |
| `Azure.Identity` | 1.13.0+ | `ManagedIdentityCredential` / `DefaultAzureCredential` for all outbound Azure calls |
| `Serilog.AspNetCore` | 9.0+ | Structured logging |
| `Serilog.Sinks.ApplicationInsights` | 4.0+ | Application Insights log sink — only registered if `ApplicationInsights:ConnectionString` is set |
| `Serilog.Sinks.Console` | 6.0+ | Stdout log sink — always registered; sole sink when App Insights is not configured |
| `Microsoft.ApplicationInsights.AspNetCore` | 2.23.0+ | Application Insights SDK — optional; not initialised if connection string is absent |

ASP.NET Core built-in WebSocket support (`app.UseWebSockets()`) is used — no SignalR dependency.

### 16.2 Key Interfaces

```
IClientRegistry      — OID → List<ClientConnection>    (in-memory, ConcurrentDictionary)
IOfflineBuffer       — OID → Queue<MessageFrame>        (in-memory, bounded)
IReplyContextStore   — channel_id → ReplyContext        (in-memory, TTL-evicted)
ITeamsAdapter        — validate activity, send reply    (CloudAdapter wrapper)
```

All four are registered as singletons. In-memory implementations for v1. Future multi-instance: `IClientRegistry` and `IOfflineBuffer` would be backed by Azure SignalR Service (not Redis — SignalR Service handles WebSocket affinity natively, Redis does not).

### 16.3 `POST /bot/teams` Concurrency Pattern

The Bot Framework endpoint must return HTTP 200 quickly (within 5 seconds) or Teams retries. The handler must:
1. Validate the activity synchronously (via `CloudAdapter`)
2. Dispatch to the WorkPilot client asynchronously (fire-and-forget)
3. Return 202 Accepted immediately

The reply to Teams is sent later when the client sends back a `response` frame (no active server-side timeout for Teams — the agent's own execution timeout is the upstream limit). If the client never responds, the TTL cleanup evicts the ReplyContext after 1 hour.

### 16.4 Out of Scope for v1

| Feature | Notes |
|---------|-------|
| Outlook Bot | Separate Bot registration; different activity schema |
| GitHub App webhooks | GitHub App registration; sender-to-user routing needs separate design |
| ADO webhooks | Same as GitHub |
| Cloud Portal | Phase 14 per [builtin-features.md §8](../builtin-features.md) |
| Multi-instance scale-out | Requires Azure SignalR Service as backplane |
| Web Chat file upload | Future; requires multipart frame handling and workspace transfer protocol |
