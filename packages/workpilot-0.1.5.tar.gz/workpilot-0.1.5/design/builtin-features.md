# WorkPilot — Built-in Features Specification

> **Layer**: 2 of 3 (Core & Infrastructure → **Built-in Features** → Extended Abilities)
> **Status**: Draft v2
> **Date**: 2026-02-28
> **Depends on**: [core-infra.md](core-infra.md), [core/channel.md](core/channel.md)

Concrete features that ship with WorkPilot. Everything here builds on the protocols defined in core-infra. Each feature has a detailed spec in `features/`.

---

## 1. Deployment Modes

| Mode | Command | Network | Channels Available |
|------|---------|---------|-------------------|
| **Local** (default) | `workpilot chat` / `workpilot run` | None | CLI |
| **Self-Hosted Gateway** | `workpilot serve` | Requires reachable IP | CLI + REST/SSE/WS |
| **Cloud Gateway** | `workpilot cloud` | Outbound WSS only | CLI + Teams + Web Chat |

All computation and data stay on the client. Cloud Gateway is a stateless relay.

---

## 2. CLI

Spec: [features/cli.md](features/cli.md)

| Command | Description |
|---------|-------------|
| `workpilot chat` | Interactive REPL |
| `workpilot run "prompt"` | One-shot execution |
| `workpilot serve` | Start HTTP gateway |
| `workpilot cloud` | Login (Entra ID) + connect to Cloud Gateway |
| `workpilot init` | Guided config creation |
| `workpilot status` | Show config, health, connected services |
| `workpilot doctor` | Diagnose issues |
| `workpilot secrets audit/set/test` | Credential management |
| `workpilot sessions/memory/tools/mcp/skills/cron/cost` | Management sub-commands |
| `workpilot security estop/reset/audit` | Security management |

---

## 3. Built-in Tools

Tool protocol defined in [core/tool.md](core/tool.md). Each tool below implements that protocol.

### Defaults

All tools support `timeout` as a protocol-level call parameter (see [core/tool.md](core/tool.md) Section 2). LLM can pass shorter timeout per call; cannot exceed config default.

| Tool | Spec | approval | risk | config timeout |
|------|------|----------|------|---------------|
| `shell` | [tool-shell.md](features/tool-shell.md) | auto | medium | 600s |
| `read_file` | [tool-files.md](features/tool-files.md) | never | low | 600s |
| `write_file` | [tool-files.md](features/tool-files.md) | never | medium | 600s |
| `edit_file` | [tool-files.md](features/tool-files.md) | never | medium | 600s |
| `list_dir` | [tool-files.md](features/tool-files.md) | never | low | 600s |
| `search_files` | [tool-files.md](features/tool-files.md) | never | low | 600s |
| `git` (read) | [tool-git.md](features/tool-git.md) | never | low | 600s |
| `git` (write) | [tool-git.md](features/tool-git.md) | auto | medium | 600s |
| `git push` | [tool-git.md](features/tool-git.md) | always | high | 600s |
| `git` (dangerous) | [tool-git.md](features/tool-git.md) | always | critical | 600s |
| `http_request` | [tool-http.md](features/tool-http.md) | auto | medium | 60s |
| `web_search` | [tool-http.md](features/tool-http.md) | never | low | 60s |
| `web_fetch` | [tool-http.md](features/tool-http.md) | auto | medium | 60s |
| `browser` | [tool-browser.md](features/tool-browser.md) | always (first) / auto | high | 60s |
| `spawn` | [tool-spawn.md](features/tool-spawn.md) | auto | medium | 600s |
| `message` | [tool-message.md](features/tool-message.md) | never | low | 30s |
| `cron` | [tool-cron.md](features/tool-cron.md) | auto | low | 600s |

---

## 4. Channels

Architecture: [core/channel.md](core/channel.md)

### 4.1 CLI Channel

Spec: [features/channel-cli.md](features/channel-cli.md)

- Always enabled, local user trusted
- Rich formatting, streaming output, slash commands
- prompt-toolkit for input (history, multi-line, tab completion)

### 4.2 Self-Hosted Gateway

Spec: [features/channel-web.md](features/channel-web.md)

- FastAPI REST/SSE/WebSocket
- Binds to `127.0.0.1` by default
- Auth: API key or Entra ID
- Webhook ingestion endpoint

### 4.3 Cloud Gateway

Spec: [features/channel-cloud.md](features/channel-cloud.md)

- Outbound WSS to Cloud Gateway service (no public IP needed)
- Entra ID login (mandatory)
- Stateless relay — data never leaves client

### 4.4 Teams (via Cloud Gateway)

- Shared Bot Framework bot — no user bot registration
- Receive messages from Teams chats/channels
- Reply in-thread, support `@WorkPilot` mentions

### 4.5 Web Chat (via Cloud Gateway)

- Browser-based chat at `<cloud-gateway-host>`
- Entra ID login
- Streaming responses via WebSocket
- Works on any device with a browser

### 4.6 Future: Cloud Portal

- Management dashboard served by Cloud Gateway
- Sessions, status, cost, memory, tools browsing — all queried from local client via WSS
- Data stays local (portal is a remote window into local agent)

---

## 5. Microsoft Graph Integration

**Status: TODO** — deferred to later design phase.

Microsoft Graph (mail, calendar, directory, Teams messaging) is a key differentiator for WorkPilot. Implementation approach TBD — options include: single `graph` tool with operation param, MCP server, or http_request + Skill pattern.

---

## 6. Built-in Agents

Spec: [builtin-agents.md](builtin-agents.md)

3 built-in agents + 5 bundled templates:

| Agent | Type | Model | Tools | Budget | Description |
|-------|------|-------|-------|--------|-------------|
| `default` | **built-in** | auto | 13 (14 with cron) | 40 iter | Primary orchestrator, user interaction |
| `explorer` | **built-in** | fast | 3 (read-only) | 15 iter | Fast codebase search (Claude Code Explore pattern) |
| `security` | **built-in** | fast | 0 (none) | 1 iter | Internal tool approval assessment |
| `coder` | template | auto | 7 (dev) | 25 iter | Code implementation, testing |
| `reviewer` | template | auto | 4 (read-only) | 15 iter | Code review |
| `tester` | template | auto | 7 (dev) | 25 iter | Test generation |
| `researcher` | template | auto | 6 (read+web) | 20 iter | Web + file research |
| `communicator` | template | auto | 2 (read-only) | 10 iter | Email/message drafting |

---

## 7. Built-in Skills

SKILL.md files bundled with WorkPilot. Read-only (copy to workspace to customize).

| Skill | Trigger | Steps |
|-------|---------|-------|
| **GitHub PR** | "create a PR", "fix bug with PR" | Branch → code changes → test → generate PR description → create PR |
| **Code Review** | "review this code", "review PR #42" | Read diff → analyze (bugs, security, style) → structured comments |
| **Office Comms** | "send email", "schedule meeting" | Determine type → draft (bilingual) → user approval → send via Graph |

---

## 8. Scheduler + Heartbeat

Spec: [core/scheduler.md](core/scheduler.md)

Jobs executed via `AgentLoop.run_once()` — tool hooks and security apply. Results delivered to notify_channels.

| Feature | Description |
|---------|-------------|
| **Triggers** | cron expression, interval (seconds), event (Bus EventType match) |
| **Session modes** | `isolated` (fresh per run) / `persistent` (context across runs) |
| **HEARTBEAT.md** | Natural-language proactive tasks — agent reads and decides whether to act (nanobot pattern) |
| **CronTool** | Built-in tool for agent self-scheduling (list, add, remove, enable, disable) |
| **Run history** | Per-job JSONL (auto-pruned, last 100 entries) |
| **Delivery** | Results to `notify_channels` or log only; empty results suppressed |

---

## 9. DAG Workflow Engine

Deterministic, pre-defined execution DAGs — complementary to Skills (LLM-driven).

```yaml
# Example: deploy workflow
name: deploy
trigger:
  commands: ["/deploy"]
steps:
  build:
    tool: shell
    args: { command: "npm run build" }
  test:
    tool: shell
    args: { command: "npm test" }
    depends_on: [build]
  deploy:
    tool: shell
    args: { command: "deploy.sh {{inputs.environment}}" }
    depends_on: [test]
```

- Steps in topological order, parallel when no dependencies
- Each step goes through full hook pipeline
- Triggers: command, cron, Bus event, LLM decision, API call
- E-stop cancels all running steps

---

## 10. Implementation Priority

| Phase | Feature | Depends on |
|-------|---------|------------|
| **1** | CLI commands (core) | Core: config |
| **2** | Built-in tools (shell, files, git, http) | Core: tool registry |
| **3** | CLI channel + REPL | Core: agent loop |
| **4** | `workpilot init` wizard | Phase 1-3 |
| **5** | Secrets management | Core: credential store |
| **6** | Self-hosted Gateway | Core: gateway |
| **7** | Graph API tools | Core: tool registry |
| **8** | Browser tool | Core: tool registry |
| **9** | Spawn tool + sub-agents | Core: agent loop |
| **10** | Built-in skills (SKILL.md) | Core: skill loader |
| **11** | Scheduler + heartbeat + CronTool | Core: scheduler + agent loop |
| **12** | DAG workflow engine | Core: tools + bus |
| **13** | Cloud Gateway client | Core: channels |
| **14** | Teams (via Cloud) + Web Chat | Cloud Gateway service |
| **15** | Portal / Dashboard | Gateway + Cloud |
| **16** | Management CLI (sessions, memory, mcp, cron, cost) | Various |
