# Shell Tool

> **Date**: 2026-02-28
> **Tool name**: `shell`
> **Risk level**: medium
> **Isolation**: process

---

## Reference

| | OpenClaw | nanobot | NanoClaw | IronClaw | ZeroClaw |
|---|---|---|---|---|---|
| Method | Node exec + argv approval | Python subprocess | Claude SDK in Docker | WASM + Docker | Native + kernel sandbox |
| Deny patterns | Structured argv binding | 5+ patterns | N/A (container) | Capability-based | Deny-pattern guards |
| Timeout | — | **60s** | — | — | — |
| Output limit | — | **10KB** | Marker-based | — | — |
| Streaming | Block streaming | Batch | Marker stdout | — | WebSocket |
| Approval | Versioned bindings | No | No | Human-in-loop | E-stop |

**WorkPilot goes beyond all 5 projects** with a three-layer classification cascade for command safety.

---

## 1. Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `command` | string | yes | — | Shell command to execute |
| `working_dir` | string | no | workspace root | Working directory |
| `timeout` | int | no | 600 | Timeout in seconds. LLM can pass a shorter value per call. (0 = background mode) |
| `background` | bool | no | false | Run in background (no timeout, for long-running processes like servers) |

---

## 2. Three-Layer Security Model

Deny patterns alone are unreliable (easily bypassed). WorkPilot uses a **classification cascade**:

```
Command received
  ↓
Layer 1: Rule Engine (regex patterns, <1ms)
  ├─ DENY  → blocked immediately, audit logged
  ├─ ALLOW → execute, audit logged
  └─ UNCERTAIN → pass to Layer 2
  ↓
Layer 2: Security Agent (LLM classifier, ~1-2s)
  ├─ DENY  → blocked, audit logged
  ├─ ALLOW → execute, audit logged
  └─ UNCERTAIN → pass to Layer 3
  ↓
Layer 3: Approval Gate (human review)
  ├─ SUSPICIOUS → must approve (wait indefinitely)
  └─ LOW-RISK UNCERTAIN → auto-approve after timeout (default 3 min)
  ↓
All outcomes audit logged (command, classification result, layer that decided, actor)
```

### Layer 1: Rule Engine

Fast regex matching. No LLM call. Results in DENY / ALLOW / UNCERTAIN.

**Deny patterns** (commands that are always blocked):

```
rm\s+-rf\s+/                      # recursive delete root
:\(\)\s*\{\s*:\|:&\s*\}           # fork bomb
\bformat\b.*[A-Z]:               # format drive (Windows)
\bshutdown\b                      # shutdown system
\breboot\b                        # reboot system
\bmkfs\b                          # make filesystem
\bdd\b\s+if=.*/dev/              # dd from device
\bchown\b\s+-R\s+root            # chown to root
```

**High-risk patterns** (not denied, but always routed to Layer 3 approval — skip Layer 2 Security Agent):

```
\b(curl|wget)\b                   # network download — may exfiltrate or fetch malicious content
\bchmod\b                          # permission change — may open security holes
\b(curl|wget)\b.*\|\s*(ba)?sh    # pipe to shell — especially dangerous variant
```

These commands are legitimate dev tools but carry inherent risk. Users can approve them, and "Always allow this pattern" saves the decision for future use.

**Allow patterns** (commands that are always safe):

```
\b(ls|dir|pwd|echo|cat|head|tail|wc|sort|grep|find|which|whoami|date|uname)\b
\b(git\s+(status|diff|log|show|branch|remote))\b
\b(python|node|npm|pip|dotnet|cargo)\s+(--version|-V|--help)\b
```

**Everything else** → UNCERTAIN (passed to Layer 2).

### Layer 2: Security Agent

A lightweight LLM call (fast model) that classifies the command's intent and risk:

**Input to Security Agent:**
- The command string
- The working directory
- The current security profile (open/standard/controlled/restricted)

**Security Agent prompt** (simplified):
```
Classify this shell command's risk level:
Command: {command}
Working dir: {working_dir}
Profile: {profile}

Respond with one of:
- ALLOW: command is safe (read-only, standard dev tooling, build commands)
- DENY: command is destructive (deletes data, modifies system, exfiltrates secrets)
- SUSPICIOUS: command could be dangerous, needs human review
- LOW_RISK: command is unusual but probably safe, auto-approve is OK
```

**Security Agent rules:**
- Uses a fast/cheap model (not the main agent's model)
- Timeout: 3 seconds — if no response, treat as SUSPICIOUS
- The Security Agent is **conservative** — when in doubt, classify as SUSPICIOUS
- The Security Agent sees the raw command, not the agent's explanation of why it wants to run it

### Layer 3: Approval Gate

Human-in-the-loop for commands that couldn't be classified automatically.

| Classification | Behavior |
|---------------|----------|
| **SUSPICIOUS** | Present to user. Wait for explicit approve/deny. No auto-approve. |
| **LOW_RISK** | Present to user. Auto-approve after 3 minutes if no response. |

**Presentation to user:**

```
⚠ Shell command needs approval:
  Command: docker run --rm -v /:/host alpine cat /host/etc/shadow
  Risk: SUSPICIOUS (Security Agent: possible data exfiltration)

  [Approve] [Deny] [Always allow this pattern]
```

"Always allow this pattern" adds the command pattern to the user's allow list (stored in config).

### Layer Bypass by Profile

| Profile | Layer 1 | Layer 2 | Layer 3 |
|---------|---------|---------|---------|
| `open` | Deny patterns active | Skip (auto-ALLOW uncertain) | Skip |
| `standard` | Deny patterns active | Security Agent (medium+ risk only) | Auto-approve LOW_RISK (3 min) |
| `controlled` | Deny patterns active | Security Agent active (all) | Auto-approve LOW_RISK (3 min) |
| `restricted` | Deny patterns active | Security Agent active (all) | All uncertain must be manually approved |

---

## 3. Timeout & Background Mode

### Standard Mode (default)

| Setting | Default | Range | Description |
|---------|---------|-------|-------------|
| `timeout` | 600s | 1-3600s | Max execution time. Config default is long; LLM passes shorter value per call when appropriate. |

On timeout: kill process, return partial output + `Command timed out after {N}s`.

### Background Mode

For long-running processes that shouldn't be killed (dev servers, watchers, etc.):

```
shell(command="npm run dev", background=true)
```

| Behavior | Description |
|----------|-------------|
| No timeout | Process runs until explicitly stopped |
| Output streaming | stdout/stderr forwarded as StreamingChunk events |
| Process tracking | Background PID tracked by shell tool |
| Stop mechanism | Agent calls `shell(command="kill {pid}")` or `/stop` slash command |
| Max background processes | Configurable (default: 3) |
| Session cleanup | All background processes killed on session end or E-stop |

**Background result:**
```
Started background process: PID 12345
Command: npm run dev
Use shell("kill 12345") to stop.
```

---

## 4. Output

### Standard Output

```
Exit code: 0
stdout: [output or LLM-extracted summary]
stderr: [error output]
Duration: 2.3s
```

### Output Size Management

Output size is **dynamically adjusted** based on two factors:

1. **Config limit** — `max_output_bytes` (default 64KB)
2. **Remaining context tokens** — estimated tokens left in the current LLM context window

The effective limit is the **minimum** of the two:

```
effective_limit = min(config.max_output_bytes, estimated_remaining_tokens * 4)
```

This prevents a single tool output from blowing up the context window, even if the config allows large output.

### Output Processing Pipeline

```
Raw command output (stdout + stderr)
  ↓
Size check:
  ├─ Within effective_limit → use as-is
  └─ Exceeds effective_limit → LLM extraction (see below)
  ↓
Leak scan (post_tool_use hook) → redact secrets
  ↓
Audit log (command, exit code, duration — raw output NOT logged)
  ↓
Return to agent loop
```

### LLM-Based Output Extraction

When raw output exceeds `effective_limit`, instead of simple truncation, use a **fast LLM call** to extract the useful information:

```
Raw output (e.g., 500KB of test results)
  ↓
Check: fits in LLM context window?
  ├─ YES → send full output to fast LLM with extraction prompt:
  │         "Extract the key information from this command output.
  │          Focus on: errors, warnings, test results, status, actionable items.
  │          Be concise. Keep exact error messages and stack traces."
  │         → return extracted summary
  │
  └─ NO  → hard truncate first (head 4KB + tail 60KB), then send to fast LLM
           → return extracted summary
```

**LLM extraction benefits:**
- Preserves semantic meaning (truncation loses context, extraction doesn't)
- Keeps exact error messages and stack traces (the most useful parts)
- Filters out noise (progress bars, verbose logging, repeated lines)
- Fits the result within the remaining context budget

**Fallback:** If LLM extraction fails (timeout, error), fall back to hard truncation (head 4KB + tail 60KB).

**Cost control:** Extraction uses the fast/cheap model (same as Security Agent), not the main agent model. Extraction is skipped if raw output already fits within `effective_limit`.

### Post-Output Processing

All output (raw or extracted) passes through the hook pipeline:
1. **Leak scan** (post_tool_use) — detect credentials in output
2. **Redaction** — replace detected secrets with `[REDACTED]`
3. **Audit** — log command, exit code, duration (raw output NOT logged for privacy)

---

## 5. Streaming

When channel supports streaming:

| Mode | Behavior |
|------|----------|
| Standard | stdout forwarded line-by-line as `StreamingChunk` events. User sees real-time output. Final result is complete captured output. |
| Background | stdout/stderr continuously streamed until process exits or is killed. |

Tool progress indicator during execution:
```
⠋ Running shell: npm test... (12s)
```

---

## 6. Platform Handling

| Platform | Detection order | Notes |
|----------|----------------|-------|
| Linux/macOS | `$SHELL` → `bash` | Standard POSIX |
| Windows | `bash` → `powershell` → `cmd` | Prefer bash (Git Bash / WSL), fallback to PowerShell, last resort cmd |

**Auto-detection**: Try `bash` first (Git Bash or WSL) → then `powershell` → then `cmd.exe`. Configurable override in config.

**Deny patterns are platform-aware**: Windows-specific patterns (`format C:`, `Remove-Item -Recurse -Force`, `del /s /q`) active only on Windows. Unix patterns (`rm -rf /`, `mkfs`) active only on Unix.

---

## 7. Config

```yaml
tools:
  shell:
    timeout: 600                    # seconds (config default, LLM can pass shorter per call)
    max_output_bytes: 65536         # 64KB (default), also bounded by remaining context tokens
    output_extraction:
      enabled: true                 # use LLM to extract useful info when output exceeds limit
      model: auto                   # fast model for extraction
    max_background: 3               # max concurrent background processes
    deny_patterns:                  # extend default deny list
      - 'custom_dangerous_pattern'
    allow_patterns:                 # always-allow patterns
      - 'my_safe_script\.sh'
    security_agent:
      enabled: true                 # enable Layer 2 classification
      model: auto                   # fast model for classification
      timeout: 3                    # seconds for classification call
    approval:
      auto_approve_timeout: 180     # seconds for LOW_RISK auto-approve (3 min)
```
