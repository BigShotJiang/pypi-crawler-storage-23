# CLI Channel

> **Date**: 2026-02-28
> **Channel name**: `cli`
> **Always enabled**: yes

---

## Reference

| | OpenClaw | nanobot | NanoClaw | IronClaw | ZeroClaw |
|---|---|---|---|---|---|
| CLI type | Gateway WS client | **Standard channel on Bus** | Headless mode | Ratatui TUI | Channel trait impl |
| Framework | Node.js | **Typer + prompt-toolkit** | None | Ratatui + Clap | Clap |
| Rendering | Client-dependent | Loguru | N/A | Rich TUI panels | tracing |
| Streaming | Block streaming via WS | Batch | N/A | TUI refresh | WebSocket |

**nanobot pattern**: CLI is just another channel on the MessageBus, not a special path.

---

## Spec

The CLI channel is defined in [cli.md](cli.md). This document specifies only the **channel protocol implementation**, not the CLI commands (which are in cli.md).

### Channel Properties

| Property | Value |
|----------|-------|
| Name | `cli` |
| Always enabled | Yes (cannot disable) |
| Auth | None (local user is trusted) |
| `supports_streaming` | `true` |
| Multi-session | One session at a time (REPL is single-user) |

### InboundMessage

```
channel: "cli"
sender_id: "local"
content: user input text
thread_id: null (single thread)
```

### OutboundMessage Rendering

- Markdown rendered via `rich`
- Code blocks syntax-highlighted
- Streaming: tokens printed character-by-character
- Tool activity: spinner + name
- Errors: red panel

### Slash Command Handling

Slash commands (`/new`, `/stop`, `/status`, etc.) are handled **locally** by the CLI channel before publishing to the Bus. They do NOT go through the Agent Loop.

### Lifecycle

- `start()`: initialize prompt-toolkit REPL, display welcome message
- `stop()`: close REPL, print goodbye
- `health()`: always healthy (local process)
