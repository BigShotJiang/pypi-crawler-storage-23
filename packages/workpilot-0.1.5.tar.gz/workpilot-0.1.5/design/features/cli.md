# CLI

> **Status**: Draft v1
> **Date**: 2026-02-28
> **Framework**: Typer (nanobot convention)
> **Architecture**: CLI-as-Channel (nanobot, ZeroClaw pattern)

---

## Reference Comparison

| | OpenClaw | nanobot | NanoClaw | IronClaw | ZeroClaw |
|---|---|---|---|---|---|
| Framework | Node.js (unspecified) | **Typer** | None (AI-native) | Clap | Clap 4.5 |
| Architecture | Thin WS client to Gateway | **CLI as channel on Bus** | No CLI | Ratatui TUI | CLI as channel trait |
| Setup wizard | `wizard` | — | `/setup` via chat | Settings wizard | — |
| Health check | `doctor` | Heartbeat | `/debug` via chat | Heartbeat | Heartbeat |
| Secrets mgmt | `secrets audit/configure/apply/reload` | — | — | Encrypted keychain | ChaCha20 storage |
| Skill scaffold | — | — | Skills via chat | — | `skill new <name>` |
| REPL streaming | Block streaming via WS | — | Marker-pair stdout | Ratatui TUI | SSE/WS |
| Output format | Client-dependent | Loguru | WhatsApp messages | Ratatui panels | tracing + web UI |

**Key decisions:**
- **Typer** — Python ecosystem standard, nanobot convention
- **CLI-as-Channel** — CLI is just another channel on the MessageBus, not a special path
- **Rich** for terminal formatting (tables, panels, Markdown rendering, streaming)
- **No TUI** — Ratatui is Rust-specific; a full TUI adds complexity without clear benefit for a Python agent
- **Streaming by default** — token-by-token output in REPL, not wait-for-completion

---

## 1. Entry Points

```
workpilot chat                    # Interactive REPL (Local Mode)
workpilot run "fix the bug"      # One-shot prompt
workpilot serve                   # Start HTTP gateway (Gateway Mode)
workpilot cloud                   # Login (Entra ID) + connect to Cloud Gateway
workpilot init                    # Create workpilot.yaml (guided wizard)
workpilot status                  # Show config, health, mode, connected services
workpilot doctor                  # Diagnose issues (OpenClaw pattern)
workpilot version                 # Show version info
```

**Global options** (apply to all commands):

| Flag | Description |
|------|-------------|
| `--workspace PATH` | Override workspace directory (default: current dir) |
| `--config PATH` | Override config file path (default: `workpilot.yaml`) |
| `--verbose` / `-v` | Increase log verbosity (repeat for more: `-vv`, `-vvv`) |
| `--quiet` / `-q` | Suppress all non-essential output |

---

## 2. Command Reference

### 2.1 Core Commands

| Command | Options | Description |
|---------|---------|-------------|
| `chat` | `--session ID`, `--agent NAME`, `--model MODEL` | Interactive REPL |
| `run` | `"prompt"`, `--session ID`, `--agent NAME`, `--model MODEL`, `--output FORMAT` | One-shot execution |
| `serve` | `--host`, `--port`, `--workers` | Start HTTP gateway |
| `cloud` | `--url URL`, `--chat` | Login (Entra ID) + connect to Cloud Gateway |
| `cloud login` | — | Login only (cache Entra ID token) |
| `cloud logout` | — | Clear cached token + disconnect |
| `cloud status` | — | Show login state, connection, linked channels |
| `init` | `--profile open\|standard\|controlled\|restricted` | Guided config creation |
| `status` | — | Show running state |
| `doctor` | — | Diagnose config, credentials, connectivity |
| `version` | — | Version info |

### 2.2 Management Sub-Commands

```
workpilot sessions                # Session management
  list                            # List sessions (recent first)
  show <id>                       # View session messages
  delete <id>                     # Delete session
  export <id> [--format json|md]  # Export session

workpilot memory                  # Memory management
  show                            # Print MEMORY.md content
  search <query>                  # Search history store
  clear                           # Clear facts (with confirmation)
  stats                           # Show memory stats (fact count, history size, DB size)

workpilot tools                   # Tool management
  list                            # List registered tools with metadata
  info <name>                     # Show tool details (schema, risk, isolation)

workpilot mcp                     # MCP server management
  list                            # List connected MCP servers + tool counts
  connect <name>                  # Connect to MCP server from config
  disconnect <name>               # Disconnect MCP server
  tools <server>                  # List tools from specific MCP server

workpilot skills                  # Skill management
  list                            # List available skills (bundled + workspace)
  show <name>                     # Show skill definition
  new <name>                      # Scaffold new workspace skill (ZeroClaw pattern)
  run <name> [--input KEY=VAL]    # Start a chat session with the skill pre-loaded in context

workpilot cron                    # Scheduler management
  list                            # List all jobs with status and next run
  add <schedule> <prompt>         # Add cron job
  remove <id>                     # Remove job
  enable <id>                     # Enable a disabled job
  disable <id>                    # Disable a job
  run <id>                        # Force immediate execution
  history [<id>]                  # Show job execution history
  status                          # Scheduler health (running, job counts)

workpilot security                # Security management
  status                          # Show security profile, E-stop state
  estop                           # Trigger emergency stop
  reset                           # Reset E-stop (with confirmation)
  audit [--tail N]                # Show recent audit log entries

workpilot secrets                 # Secrets management (OpenClaw pattern)
  audit                           # List all secrets, show source + status (set/missing/expired)
  set <name>                      # Set a secret (interactive prompt, never as CLI arg)
  set <name> --from-env VAR       # Copy a secret from an environment variable
  remove <name>                   # Remove a secret from credential store
  rotate <name>                   # Prompt for new value, replace old, test
  test                            # Test all configured secrets (verify provider keys, Graph creds, etc.)

workpilot cost                    # Cost tracking
  summary                         # Show total token usage + estimated cost
  session <id>                    # Show cost for specific session
  providers                       # Show per-provider cost breakdown
```

---

## 3. Interactive REPL (`workpilot chat`)

### 3.1 Behavior

```
$ workpilot chat
WorkPilot v0.2 (model: auto, profile: standard)
Type /help for commands. Ctrl+C to exit.

you> fix the typo in README.md
[streaming tokens appear here as they arrive...]
Done. Changed line 42: "teh" → "the"

you> /status
Agent: default | Model: gpt-4o | Session: abc123 | Iterations: 3/40

you> /exit
```

### 3.2 REPL Slash Commands

| Command | Description |
|---------|-------------|
| `/help` | Show available commands |
| `/new` | Clear session, start fresh |
| `/stop` | Cancel current agent operation |
| `/status` | Show agent status (model, session, iteration count, cost) |
| `/memory` | Show MEMORY.md content |
| `/tools` | List available tools |
| `/skills` | List available skills |
| `/model <name>` | Switch model mid-session |
| `/cost` | Show session token usage + cost |
| `/history` | Show recent session messages |
| `/export [file]` | Export current session |
| `/exit` | Quit (also Ctrl+C, Ctrl+D) |

### 3.3 Streaming Output

- LLM response tokens are printed character-by-character as they arrive (via `Provider.stream()`)
- Tool calls shown with a spinner: `⠋ Running shell: npm test...`
- Tool results shown in a dimmed/indented block
- Final response in normal style
- Errors in red
- Controlled by `channel.supports_streaming = True` on CLIChannel

### 3.4 Rich Formatting

Using the `rich` library:

| Element | Rendering |
|---------|-----------|
| Markdown | Rendered with syntax highlighting |
| Code blocks | Syntax-highlighted by language |
| Tables | Rich table formatting |
| Diffs | Highlighted additions (green) / deletions (red) |
| Errors | Red panel with error details |
| Tool activity | Spinner + tool name + args summary |
| Cost | Right-aligned in status bar |

### 3.5 Input Handling

- `prompt-toolkit` for input (line editing, history, multi-line)
- Up/Down arrows for history recall
- Multi-line input: paste or use `"""` delimiters
- Tab completion for slash commands
- Ctrl+C during agent execution → interrupt (equivalent to `/stop`)
- Ctrl+C at prompt → exit
- Ctrl+D → exit

---

## 4. One-Shot Mode (`workpilot run`)

```
$ workpilot run "what files are in src/"
src/
  main.py
  utils.py
  config.py

$ workpilot run "fix the bug in main.py" --quiet
Done. Changed line 42: "teh" → "the"

$ echo "explain this error" | workpilot run -
# Reads from stdin (pipe support)
```

- Runs a single prompt through the agent loop
- Prints response to stdout (streaming by default)
- `--quiet` suppresses progress/status, prints response text only
- Exit code: 0 on success, 1 on error, 2 on E-stop
- Supports stdin via `-` argument (for piping)
- `--session ID` to continue a previous session

---

## 5. Setup Wizard (`workpilot init`)

Guided interactive setup (OpenClaw `wizard` pattern):

```
$ workpilot init
Welcome to WorkPilot setup!

[1/6] LLM Provider
  Detected: ANTHROPIC_API_KEY ✓, OPENAI_API_KEY ✓
  Default model: auto (will select best available)

[2/6] Security Profile
  > open         — full autonomy, no approval gates
    standard     — medium-risk ops need approval
    controlled   — all auto tools reviewed by Security Agent
    restricted   — human approval required, sub-agents disabled

[3/6] Secrets
  Detected: ANTHROPIC_API_KEY ✓, OPENAI_API_KEY ✓
  Store to local credential store for persistence? (y/n)

[4/6] Channels
  ✓ CLI (always enabled)
    Self-hosted Gateway (run local HTTP server)

[5/6] Microsoft Graph
    Enable mail/calendar/directory? (requires Entra ID login)

[6/6] MCP Servers
    Add MCP server connections? (none configured)

Written: workpilot.yaml
Run `workpilot chat` to start.
```

- Detects available API keys from environment
- Prompts only for missing essentials
- Writes `workpilot.yaml` with selected options
- Non-interactive mode: `workpilot init --profile open --no-prompt`

---

## 6. Health Check (`workpilot doctor`)

Diagnoses common issues (OpenClaw `doctor` pattern):

```
$ workpilot doctor
WorkPilot Doctor

Config:
  ✓ workpilot.yaml found and valid
  ✓ Security profile: standard

Providers:
  ✓ anthropic: API key set, reachable
  ✓ openai: API key set, reachable
  ✗ azure_openai: not configured

Memory:
  ✓ MEMORY.md: 2.1KB (26% of 8KB cap)
  ✓ History DB: 847 entries, 4.2MB

MCP Servers:
  ✓ filesystem: connected, 5 tools
  ✗ github: connection refused

Security:
  ✓ E-stop: not triggered
  ✓ Leak detector: active
  ✓ Audit log: writable

Channels:
  ✓ CLI: ready

Secrets:
  ✓ ANTHROPIC_API_KEY: set (env)
  ✓ OPENAI_API_KEY: set (env)
  ✗ GRAPH_CLIENT_SECRET: missing

1 warning, 2 items not configured. Run `workpilot init` to configure.
```

- Checks config validity
- Tests provider connectivity (ping with minimal token request)
- Verifies memory store health
- Tests MCP server connections
- Reports security state
- Suggests fixes for issues found

---

## 7. Secrets Management (`workpilot secrets`)

Inspired by OpenClaw's `openclaw secrets audit/configure/apply/reload` workflow. Provides a dedicated interface for credential lifecycle management.

### 7.1 Design

Secrets in WorkPilot come from multiple sources (in priority order):

| Source | Description | Persistence |
|--------|-------------|-------------|
| Environment variable | `ANTHROPIC_API_KEY`, etc. | Session only (or shell profile) |
| `.env` file | `workpilot.local.yaml` or `.env` in workspace | File-based, gitignored |
| Local credential store | OS keychain (Windows Credential Manager / macOS Keychain / Linux keyring) | Persistent, encrypted |
| Azure Key Vault | Enterprise vault (via Managed Identity or client credentials) | Remote, centralized |

`workpilot secrets` manages the **local credential store** and provides visibility across all sources.

### 7.2 Commands

```
$ workpilot secrets audit
WorkPilot Secrets Audit

  Name                    Source          Status
  ANTHROPIC_API_KEY       env             ✓ set
  OPENAI_API_KEY          env             ✓ set
  GITHUB_TOKEN            credential store ✓ set
  GRAPH_CLIENT_ID         workpilot.yaml   ✓ set
  GRAPH_CLIENT_SECRET     —               ✗ missing
  AZURE_OPENAI_KEY        —               ✗ missing

4 set, 2 missing. Run `workpilot secrets set <name>` to configure.
```

```
$ workpilot secrets set GRAPH_CLIENT_SECRET
Enter value for GRAPH_CLIENT_SECRET: ****
Stored in local credential store (Windows Credential Manager).

$ workpilot secrets set GITHUB_TOKEN --from-env GITHUB_TOKEN
Copied GITHUB_TOKEN from environment to local credential store.

$ workpilot secrets remove AZURE_OPENAI_KEY
Removed AZURE_OPENAI_KEY from credential store.

$ workpilot secrets test
Testing configured secrets...
  ✓ ANTHROPIC_API_KEY: valid (claude-sonnet-4-5-20250929 responded)
  ✓ OPENAI_API_KEY: valid (gpt-4o responded)
  ✓ GITHUB_TOKEN: valid (authenticated as @username)
  ✓ GRAPH_CLIENT_SECRET: valid (Graph API token acquired)
  — AZURE_OPENAI_KEY: not configured (skipped)

$ workpilot secrets rotate GITHUB_TOKEN
Current value: ghp_****...****3xYz
Enter new value: ****
Updated GITHUB_TOKEN in credential store.
Testing... ✓ valid (authenticated as @username)
```

### 7.3 Security

- Secrets are **never printed in full** — always masked (`****...****` showing only last 4 chars)
- `secrets set` prompts for value interactively (not passed as command argument, to avoid shell history exposure)
- `--from-env` copies from an env var (useful for CI/CD migration to credential store)
- Credential store uses OS-native encryption (via `keyring` Python library)
- `secrets test` makes minimal API calls to verify (1 token completion for LLM keys, auth check for tokens)
- Audit logger records all secrets operations (set/remove/rotate/test) without logging the secret values

---

## 8. Cloud Gateway (`workpilot cloud`)

Login to Microsoft account (Entra ID), then connect to Cloud Gateway. The Cloud Gateway cannot be used without user login — authentication is mandatory.

### 8.1 Commands

```
workpilot cloud                   # Login (if needed) + connect + start agent loop
workpilot cloud login             # Login only (Entra ID device code flow)
workpilot cloud logout            # Clear cached token + disconnect
workpilot cloud status            # Show login state, connection status, linked channels
```

### 8.2 Login Flow

```
$ workpilot cloud
No cached token found. Starting login...

To sign in, use a web browser to open https://microsoft.com/devicelogin
and enter the code: ABCD-EFGH

Waiting for authentication... ✓ Logged in as wei@contoso.com

Connecting to Cloud Gateway (wss://<cloud-gateway-host>)... ✓ Connected
Channels available via Cloud Gateway:
  ✓ Teams (@WorkPilot bot in 3 chats)
  ✓ Web Chat (https://<cloud-gateway-host>)

Agent loop started. Listening for messages...
Press Ctrl+C to disconnect.
```

### 8.3 Token Caching

- Entra ID tokens cached locally (MSAL token cache, encrypted)
- Subsequent `workpilot cloud` reuses cached token — no re-login needed until token expires
- `workpilot cloud logout` clears the cached token
- Token refresh handled automatically by MSAL

### 8.4 What Happens on `workpilot cloud`

```
1. Check for cached Entra ID token
   ├─ Found + valid → use it
   ├─ Found + expired → refresh via MSAL
   └─ Not found → device code login flow
2. Establish WSS connection to Cloud Gateway
3. Cloud Gateway validates token, registers this client for the user
4. Start Agent Loop locally (same as `workpilot chat` but with Cloud Gateway as channel)
5. Receive messages from Cloud Gateway (Teams/Outlook/GitHub/webhooks)
6. Process locally → send response back through WSS
7. On Ctrl+C: graceful disconnect, agent loop stops, WSS closes
```

### 8.5 Combined with Local REPL

`workpilot cloud` can optionally enable CLI REPL alongside the Cloud Gateway channel:

```
$ workpilot cloud --chat
Logged in as wei@contoso.com. Connected to Cloud Gateway.
CLI REPL also enabled — you can type here too.

you> fix the bug in main.py
[agent processes locally, responds in CLI]

[Teams] @john: @WorkPilot review my PR #42
[agent processes locally, responds via Cloud Gateway → Teams]
```

Without `--chat`, the agent runs headless — only responding to messages from Cloud Gateway channels.

---

## 9. CLI Architecture

```
workpilot CLI (Typer)
  ↓
CLIChannel (implements Channel protocol)
  ↓
Message Bus (InboundMessage / OutboundMessage)
  ↓
Agent Loop (same as any other channel)
```

The CLI is **not** a privileged entry point. It is a Channel implementation that:
- Reads user input via `prompt-toolkit`
- Publishes `InboundMessage` to the Bus
- Subscribes to `OutboundMessage` + `StreamingChunk` events
- Renders output via `rich`
- Handles slash commands locally (before publishing to Bus)
- Reports `supports_streaming = True`

Management commands (`sessions`, `memory`, `tools`, etc.) bypass the Agent Loop — they interact directly with the subsystem APIs. They don't go through the Bus.

---

## 10. Exit Codes

| Code | Meaning |
|------|---------|
| 0 | Success |
| 1 | Error (tool failure, config error, etc.) |
| 2 | E-stop triggered |
| 130 | Interrupted (Ctrl+C) |

---

## 11. Environment Variables

Standard overrides (no `workpilot.yaml` needed for quick use):

| Variable | Description |
|----------|-------------|
| `WORKPILOT_MODEL` | Override default model |
| `WORKPILOT_PROFILE` | Override security profile |
| `WORKPILOT_LOG_LEVEL` | Override log level |
| `ANTHROPIC_API_KEY` | Anthropic provider key |
| `OPENAI_API_KEY` | OpenAI provider key |
| `GITHUB_TOKEN` | GitHub provider / channel key |
| `AZURE_OPENAI_*` | Azure OpenAI config |

Config resolution: defaults → `workpilot.yaml` → `workpilot.local.yaml` → `WORKPILOT_*` env vars.
