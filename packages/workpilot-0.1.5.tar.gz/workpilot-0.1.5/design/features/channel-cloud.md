# Cloud Gateway Channel

> **Date**: 2026-02-28
> **Channel name**: `cloud`
> **Default**: disabled (opt-in via `workpilot cloud`)

---

## Reference

No reference project implements a **centralized cloud relay** service. The closest approaches:

| Project | Remote Access Model |
|---------|-------------------|
| **OpenClaw** | Local-first + Fly.io deploy — no relay |
| **nanobot** | Local only — no remote |
| **NanoClaw** | WhatsApp servers act as implicit relay (outbound connection) |
| **IronClaw** | Local Web Gateway — no relay |
| **ZeroClaw** | **Tunnel trait** (Cloudflare / Tailscale / ngrok) — closest pattern |

**WorkPilot's Cloud Gateway is unique.** It combines:
- ZeroClaw's "outbound-only, no public IP" pattern
- NanoClaw's "messaging platform as relay" insight
- Enterprise Entra ID authentication
- Centralized Bot Framework / webhook handling — **users don't register their own bots or AAD apps**

---

## 1. Architecture

```
┌──────────────────────────────────────────────────────────────────┐
│  User's Machine (no public IP needed)                             │
│                                                                   │
│  ┌─────────────┐                                                 │
│  │  WorkPilot   │ ── outbound WSS ──→ Cloud Gateway              │
│  │  (client)    │ ←── messages ──────                             │
│  │              │                                                 │
│  │  Agent Loop  │  ← all processing happens locally              │
│  │  Tools       │  ← user's API keys stay local                  │
│  │  Memory      │  ← user's data never leaves machine            │
│  └─────────────┘                                                 │
└──────────────────────────────────────────────────────────────────┘
        │ outbound WSS only
        ▼
┌──────────────────────────────────────────────────────────────────┐
│  Cloud Gateway (public SaaS service)                              │
│                                                                   │
│  ┌─────────────────────────────────────────────┐                 │
│  │  Stateless Relay                             │                 │
│  │  - Entra ID auth (validates user tokens)     │                 │
│  │  - Routes messages between clients & sources │                 │
│  │  - Never reads, stores, or processes data    │                 │
│  └─────────────────────────────────────────────┘                 │
│                                                                   │
│  ┌────────────────────────────────────────────┐                  │
│  │  Shared Infrastructure (managed by service) │                  │
│  │                                             │                  │
│  │  Teams Bot ←── Bot Framework ──→ Microsoft  │                  │
│  │  Web Chat (browser UI)                       │                  │
│  └────────────────────────────────────────────┘                  │
└──────────────────────────────────────────────────────────────────┘
```

### Key Principle: Stateless Relay

The Cloud Gateway is a **message router, not a processor**. It:

| Does | Does NOT |
|------|----------|
| Validate Entra ID tokens | Store user data |
| Route messages between client and sources | Read message content |
| Manage shared bot registrations | Execute agent logic |
| Handle webhook callbacks | Hold API keys |
| Maintain WebSocket connections | Process tools |
| Provide connection presence info | Access user's filesystem |

---

## 2. Why Cloud Gateway

### Problem: External Integration Requires Public Endpoints

| Integration | Requires | Without Cloud Gateway |
|-------------|---------|----------------------|
| Teams bot | Bot Framework endpoint (public HTTPS) | User registers own bot + AAD app |
| Outlook bot | Bot Framework endpoint (public HTTPS) | User registers own bot + AAD app |
| GitHub webhooks | Public webhook URL | User configures reverse proxy / ngrok |
| ADO webhooks | Public webhook URL | User configures reverse proxy / ngrok |

### Solution: Shared Infrastructure

The Cloud Gateway provides **one shared bot registration and webhook endpoint** for all users:

| Source | v1 scope | Notes |
|--------|---------|-------|
| **Teams bot** | ✅ v1 | Shared Bot Framework registration, single-tenant |
| **Web Chat** | ✅ v1 | Browser SPA served by Cloud Gateway |
| **Outlook bot** | 🔜 Future | Separate Bot registration required |
| **GitHub App** | 🔜 Future | Sender → user routing design pending |
| **ADO webhook** | 🔜 Future | Same as GitHub |

Users just run `workpilot cloud` → login with Entra ID → done. No bot registration, no AAD app creation, no public IP.

---

## 3. Client-Side Flow

```
$ workpilot cloud

1. Entra ID login (device code flow → browser)
   ↓
2. Establish WSS to wss://<cloud-gateway-host>/connect
   ↓
3. Cloud Gateway validates token, registers client for this user
   ↓
4. Start Agent Loop locally (same as `workpilot chat`)
   ↓
5. Messages arrive from Cloud Gateway:
   ├─ Teams: "@WorkPilot fix the bug" → InboundMessage(channel="cloud", metadata.source="teams", ...)
   └─ Web Chat: browser message → InboundMessage(channel="cloud", metadata.source="webchat", ...)
   ↓
6. Agent Loop processes locally
   ↓
7. OutboundMessage sent back through WSS → Cloud Gateway → source channel
   ├─ Teams reply
   └─ Web Chat response
```

### What Runs Where

| Component | Client (local) | Cloud Gateway |
|-----------|----------------|---------------|
| Agent Loop | **Yes** | No |
| Tool execution | **Yes** | No |
| Memory / Session | **Yes** | No |
| LLM API calls | **Yes** (user's keys) | No |
| Teams Bot (Bot Framework) | No | **Yes** (shared) |
| Web Chat UI | No | **Yes** (served as SPA) |
| Entra ID validation | Device code flow | **Token validation** |
| User data | **Stays local** | **Never stored** |

---

## 4. Channel Protocol Implementation

The Cloud Gateway client is a Channel implementation:

| Property | Value |
|----------|-------|
| Name | `cloud` |
| Default | Disabled |
| `supports_streaming` | `true` (streaming chunks forwarded through WSS) |
| Auth | Entra ID (mandatory) |
| Connection | Outbound WSS (client initiates) |
| Reconnect | Automatic with exponential backoff |

### Wire Protocol

All frames sent over WSS are JSON text with a mandatory `type` field. The full wire protocol is defined in [cloud-gateway/server.md §5](../cloud-gateway/server.md). The key frames for the CloudChannel implementation are:

#### Receiving: `message` frame (Server → Client)

```json
{
  "type": "message",
  "channel": "cloud",
  "sender_id": "a7f3d9b2-4c1d-8f7a-b2e4-c1d8f7ab2e4c",
  "sender_name": "John Smith",
  "content": "Hello <at>WorkPilot</at> fix the auth bug in PR #42",
  "thread_id": "19:abc123@thread.v2",
  "channel_id": "cid_f47ac10b-58cc-4372-a567-0e02b2c3d479",
  "session_key": "cloud_teams:a7f3d9b2-4c1d-8f7a-b2e4-c1d8f7ab2e4c:19:abc123@thread.v2",
  "timestamp": "2026-03-02T12:00:00Z",
  "metadata": {
    "source": "cloud_teams",
    "tenant_id": "72f988bf-86f1-41af-91ab-2d7cd011db47"
  }
}
```

CloudChannel reads `channel_id` from the wire `message` frame and sets it directly on `InboundMessage.channel_id` (a first-class field, not metadata). The Agent Loop echoes `inbound.channel_id` into `OutboundMessage.channel_id`. CloudChannel.send() writes it as the `channel_id` field of the wire `response`/`chunk` frame.

```
wire message frame
  channel_id = "cid_f47ac10b-58cc-4372-a567-0e02b2c3d479"
        ↓ CloudChannel
InboundMessage.channel_id = "cid_f47ac10b-58cc-4372-a567-0e02b2c3d479"
        ↓ Agent Loop (echoes inbound.channel_id → outbound.channel_id)
OutboundMessage.channel_id = "cid_f47ac10b-58cc-4372-a567-0e02b2c3d479"
        ↓ CloudChannel.send()
wire response frame
  channel_id = "cid_f47ac10b-58cc-4372-a567-0e02b2c3d479"   ← echoed back to server
```

`content` is verbatim from the source. For Teams messages it may include mention XML: `<at>WorkPilot</at>`. CloudChannel strips all `<at>…</at>` occurrences (regex: `<at>[^<]*</at>`) and trims surrounding whitespace before publishing to the Agent Loop.

`session_key` uses `{source}` from `metadata.source` (`"cloud_teams"` or `"cloud_webchat"`) as the prefix — not the channel name `"cloud"`. The `cloud_` prefix distinguishes Cloud Gateway sessions from any future direct-channel sessions. Format: `"{source}:{sender_id}:{thread_id}"`. Pass directly to `SessionManager` without modification.

| Source | `metadata.source` | `sender_id` | `thread_id` | Example `session_key` |
|--------|-------------|-------------|-------------|----------------------|
| Teams | `cloud_teams` | `from.aadObjectId` (Entra OID) | `activity.conversation.id` | `cloud_teams:a7f3d9b2-...:19:abc123@thread.v2` |
| Web Chat | `cloud_webchat` | UPN from Entra token | `wc_{full-oid}` | `cloud_webchat:john@contoso.com:wc_a7f3d9b2-4c1d-8f7a-b2e4-c1d8f7ab2e4c` |

For Teams messages, `sender_id` is `from.aadObjectId` (the Entra OID), not the display name. The display name is mutable and non-unique.

#### Sending: `response` frame (Client → Server)

```json
{
  "type": "response",
  "channel_id": "cid_f47ac10b-58cc-4372-a567-0e02b2c3d479",
  "content": "Fixed the auth bug. PR #42 updated.",
  "thread_id": "19:abc123@thread.v2",
  "format": "markdown"
}
```

`channel_id` **must echo** the value received in the originating `message` frame. The server uses it to look up how to deliver the response (Teams Bot Connector, browser WebSocket, etc.). It is NOT the thread ID.

#### Sending: `chunk` frame (Client → Server, streaming)

```json
{
  "type": "chunk",
  "channel_id": "cid_f47ac10b-58cc-4372-a567-0e02b2c3d479",
  "content": "Fixed",
  "chunk_type": "token",
  "done": false
}
```

Final chunk: `"done": true`, `"content": ""`. `chunk_type` values: `"token"`, `"tool_progress"`, `"status"`.

#### Receiving: `error` frame (Server → Client)

```json
{
  "type": "error",
  "code": "reply_context_expired",
  "channel_id": "cid_f47ac10b-58cc-4372-a567-0e02b2c3d479",
  "message": "The reply window for this message has expired."
}
```

CloudChannel error handling:

| Code | Client action |
|------|--------------|
| `reply_context_expired` | Log WARNING — response was not delivered; user may need to retry |
| `response_timeout` | Log WARNING — Web Chat only; response was not delivered in 120 s |
| `auth_expired` | Re-authenticate via device code flow and reconnect |
| `rate_limited` | Back off and retry connection |
| `server_error` | Log ERROR; reconnect with exponential backoff |

#### Receiving: `ping` frame (Server → Client)

```json
{ "type": "ping" }
```

The client **must** respond with `pong` within 10 seconds or the server closes the connection.

#### Sending: `pong` frame (Client → Server)

```json
{ "type": "pong" }
```

#### Receiving: `connected` frame (Server → Client)

Sent immediately after the WebSocket upgrade is accepted:

```json
{
  "type": "connected",
  "buffered_count": 3
}
```

If `buffered_count > 0`, the following sequence follows immediately:

```json
{ "type": "buffered_start", "count": 3 }
```
*(N × `message` frames — identical format to the `message` frame above)*
```json
{ "type": "buffered_end" }
```

CloudChannel should process buffered messages in order after receiving `buffered_end`, before entering normal receive mode.

Cloud Gateway routes responses back to the originating source channel (Teams, Web Chat) using the `channel_id` routing key.

---

## 5. Supported Source Channels (via Cloud Gateway)

| Source | How Cloud Gateway Connects | User Setup |
|--------|---------------------------|------------|
| **Teams** | Shared Bot Framework bot — installed to user's Teams via admin consent or self-install | User adds the WorkPilot bot to their Teams |
| **Web Chat** | Cloud Gateway serves web SPA at `<cloud-gateway-host>` | User opens browser, logs in with Entra ID |

Both source channels share the same Cloud Gateway infrastructure. **Users never register their own bots or AAD apps.**

---

## 6. Connection Management

### Reconnect

| Setting | Default |
|---------|---------|
| Auto-reconnect | Yes |
| Initial retry delay | 1 second |
| Max retry delay | 60 seconds (exponential backoff) |
| Heartbeat | Server sends `ping` every 30 s; client must reply `pong` within 10 s |

### Multiple Clients

One user can have multiple clients connected simultaneously (home, work, laptop). Cloud Gateway tracks all connected clients for a user and routes messages to the **most recently active** client.

### Offline

When no client is connected, Cloud Gateway holds messages in a short-term buffer (configurable TTL, default 1 hour). When the client reconnects, buffered messages are delivered.

---

## 7. Security

| Concern | How |
|---------|-----|
| **Authentication** | Entra ID — every WSS connection must present a valid MSAL token |
| **Data privacy** | Cloud Gateway is stateless relay — never reads, stores, or processes message content |
| **Transport** | WSS (TLS encrypted) |
| **Message routing** | User identity from Entra ID token → route to correct client |
| **Audit** | Client-side audit logging captures all messages (Cloud Gateway does not log content) |
| **E-stop** | Client-side E-stop disconnects from Cloud Gateway |

---

## 8. Config

```yaml
channels:
  cloud:
    enabled: false
    url: "wss://<cloud-gateway-host>/connect"   # WorkPilot client relay endpoint
    auto_reconnect: true
    reconnect_interval: 1                        # seconds (initial, with backoff)
    heartbeat_interval: 30                       # seconds (server sends ping; client replies pong)
```

Activated via `workpilot cloud` (which handles Entra ID login + connection).

---

## 9. Cloud Web Chat

The Cloud Gateway also serves a **web chat UI** — users can chat with their agent directly from a browser, without installing the WorkPilot CLI.

### How It Works

```
Browser (any device)
  ↓
https://<cloud-gateway-host> → Entra ID OIDC auth code flow
  ↓
Server validates code, sets HttpOnly Secure SameSite=Strict cookie (JWT)
  ↓
Cloud Gateway serves web chat SPA
  ↓
WebSocket to /webchat — browser sends Cookie header automatically
  ↓
Cloud Gateway validates cookie, forwards messages to user's WorkPilot client
  ↓
Client processes locally → response flows back → Cloud Gateway → browser
```

### Requirements

- User must have a **WorkPilot client running** and connected to Cloud Gateway (`workpilot cloud`)
- The browser connects to the Cloud Gateway, NOT directly to the user's machine
- All processing still happens on the user's machine — the web chat is just another message source

### If No Client Connected

Two things happen simultaneously:
1. Browser immediately receives `error(agent_offline)` frame — the web chat displays: "Your WorkPilot agent is offline. Start `workpilot cloud` on your machine to connect."
2. The message is added to the Cloud Gateway offline buffer (TTL 1 hour). When the user's WorkPilot client reconnects, buffered messages are delivered automatically.

### Features

| Feature | Detail | v1 scope |
|---------|--------|---------|
| **Streaming** | Token-by-token via WebSocket (Cloud Gateway relays chunks) | ✅ v1 |
| **Session history** | Stored on user's local machine; web chat shows current session only | ✅ v1 |
| **Code blocks** | Syntax-highlighted rendering | ✅ v1 |
| **Tool activity** | Show tool name + progress while agent is executing | ✅ v1 |
| **Mobile responsive** | Works on phone/tablet browsers | ✅ v1 |
| **Auth** | Entra ID OIDC — server-set HttpOnly cookie; same identity as desktop | ✅ v1 |
| **File sharing** | Upload files via web chat → forwarded to agent workspace | 🔜 Future |

### What the Web Chat is NOT

- NOT a hosted agent — the agent always runs locally on the user's machine
- NOT a data store — conversation history lives on the user's machine
- NOT a replacement for CLI — it's a remote access convenience

---

## 10. Future: Cloud Portal

A management dashboard served by the Cloud Gateway. **Not in initial release** — planned for future.

### Planned Features

| Page | Description | Data Source |
|------|-------------|------------|
| `/chat` | Web chat interface (Section 9) | Real-time via WSS relay |
| `/sessions` | Browse past sessions | Queried from user's client via WSS |
| `/status` | Agent health, connected channels, E-stop state | Real-time from client |
| `/cost` | Token usage, cost breakdown by provider/session | Queried from client |
| `/memory` | Browse MEMORY.md, search history | Queried from client |
| `/tools` | List registered tools, MCP servers | Queried from client |
| `/settings` | View config (secrets redacted) | Queried from client |

### Architecture Principle

The Cloud Portal is a **thin UI layer** that queries the user's connected client for all data. The Cloud Gateway does not store any of this data — it relays queries and responses over WSS.

```
Browser → Cloud Portal UI → Cloud Gateway → WSS → User's Client → local data
                                                   ↓
                                              Client responds
                                                   ↓
Browser ← Cloud Portal UI ← Cloud Gateway ← WSS ← response
```

This preserves the privacy model: all data stays on the user's machine. The portal is a remote window into the local agent.

### Tech Stack (planned)

- Frontend: lightweight SPA (served by Cloud Gateway as static assets)
- Real-time: WebSocket (same connection as web chat)
- Auth: Entra ID (mandatory)

---

## 11. Cloud Gateway Server

The Cloud Gateway server is a **separate service** — not part of the WorkPilot client codebase. This spec only defines the **client-side channel protocol** and the user-facing capabilities (web chat, portal).

Server specification: [cloud-gateway/server.md](../cloud-gateway/server.md)
