# Web Channel (Self-Hosted)

> **Date**: 2026-02-28
> **Channel name**: `web`
> **Default**: disabled (opt-in via `workpilot serve`)

---

## Reference

| | OpenClaw | nanobot | NanoClaw | IronClaw | ZeroClaw |
|---|---|---|---|---|---|
| Has gateway | **YES** (WS control plane, 150+ files) | NO | NO | **YES** (Axum Web + SSE/WS) | **YES** (Axum REST/WS) |
| Protocol | **WebSocket** (primary) | — | — | SSE + WebSocket | REST + WebSocket |
| Auth | Gateway token | — | — | Not detailed | OTP + pairing |
| Binds to | 127.0.0.1 | — | — | Not specified | **127.0.0.1 only** |
| Dashboard | WebChat UI | — | — | Chat/memory/tasks/logs pages | Embedded Vite/TS frontend |

---

## Spec

The Gateway is a self-hosted HTTP server for API access, webhook ingestion, and web dashboard. It requires the user's machine to be reachable (public IP, reverse proxy, or VPN).

### Endpoints

| Endpoint | Method | Auth | Description |
|----------|--------|------|-------------|
| `/api/chat` | POST | API key / Entra ID | Send prompt, receive response |
| `/api/chat/stream` | POST | API key / Entra ID | Send prompt, SSE streaming response |
| `/api/ws` | WebSocket | API key / Entra ID | Bidirectional chat |
| `/api/sessions` | GET | API key / Entra ID | List sessions |
| `/api/sessions/{id}` | GET/DELETE | API key / Entra ID | Get or delete session |
| `/api/tools` | GET | API key / Entra ID | List available tools |
| `/api/health` | GET | None | Health check (all subsystems) |
| `/api/estop` | POST | API key / Entra ID | Trigger E-stop |
| `/api/reset` | POST | API key / Entra ID | Reset E-stop |
| `/webhooks/{name}` | POST | Webhook secret | Webhook ingestion (generic) |

### Auth

Two methods:

| Method | How | Use case |
|--------|-----|----------|
| **API key** | `X-API-Key` header | Simple, for scripts and tools |
| **Entra ID** | Bearer token (MSAL validation) | Enterprise SSO |

### Channel Properties

| Property | Value |
|----------|-------|
| Name | `web` |
| Default | Disabled |
| `supports_streaming` | `true` (SSE + WebSocket) |
| Bind address | `127.0.0.1` by default (ZeroClaw pattern — refuse public exposure) |
| Port | 3000 (configurable) |
| E-stop | Returns 503 for all `/api/*` when halted |

### Config

```yaml
gateway:
  enabled: false
  host: "127.0.0.1"
  port: 3000
  api_key: ${WORKPILOT_API_KEY}     # or null for Entra ID only
  cors_origins: ["*"]
```

### When to Use

- Internal network access (behind VPN/firewall)
- CI/CD integration (scripts call `/api/chat`)
- Web dashboard
- Custom frontend applications

For **external access without public IP**, use Cloud Gateway instead (channel-cloud.md).
