# Scheduler Protocol

> **Type**: Core Infrastructure
> **Date**: 2026-03-04
> **Parent**: [core-infra.md](../core-infra.md) Section 4.10

---

## Reference (from actual source code)

| Dimension | nanobot | OpenClaw |
|-----------|---------|---------|
| **Library** | croniter | croner |
| **Triggers** | cron, interval, at | cron, interval, at |
| **Execution** | InboundMessage → Bus | System event → session |
| **Session** | Shared (main) | Main or Isolated |
| **Delivery** | Channel | Announce / Webhook / None |
| **Persistence** | `jobs.json` | `jobs.json` + `runs/*.jsonl` |
| **Heartbeat** | HEARTBEAT.md (LLM decides) | Heartbeat prompt |
| **Self-scheduling** | CronTool | CLI/API |
| **Error handling** | Log + continue | Backoff + auto-disable |

**What WorkPilot adopts:**
- nanobot's **agent pipeline** — jobs go through `run_once()` with tool hooks, security, audit
- nanobot's **HEARTBEAT.md** — natural-language proactive tasks, LLM decides whether to act
- nanobot's **CronTool** — agent can schedule its own future work
- OpenClaw's **session modes** — isolated (fresh) vs persistent (context across runs)
- OpenClaw's **run history** — JSONL per job for audit

**What WorkPilot drops (for simplicity):**
- OpenClaw's webhook delivery (v2+)
- OpenClaw's stagger window (single-user, not needed)
- OpenClaw's model override per job (v2+)
- Complex retry/backoff (v1: log + continue, disable after N failures)

---

## 1. Design

Jobs execute via `AgentLoop.run_once()`. The agent processes them through the standard tool pipeline. No special code path.

```
Trigger fires (cron / interval / event)
  ↓
SchedulerService calls AgentLoop.run_once(prompt, session_id):
  session_id = "scheduler:{job_id}" or "scheduler:{job_id}:{run_id}"
  ↓
AgentLoop processes (hooks → LLM ↔ tools → response string)
  ↓
SchedulerService receives result directly (run_once returns string):
  - Record in run history
  - If notify_channels: publish OutboundMessage to each channel via Bus
```

**Why `run_once()` instead of `InboundMessage`**: `run_once()` runs the agent loop (LLM ↔ tools with `pre_tool_use`/`post_tool_use` hooks, security, compaction, loop detection) and returns the response directly. This avoids the routing problem of OutboundMessage with no registered "scheduler" channel.

**Hook coverage**: `run_once()` applies `pre_tool_use` and `post_tool_use` hooks (E-stop, policy, leak scan, audit). It intentionally skips `on_message_received` (no external input to scan for injection) and `on_message_sent` (delivery handled by SchedulerService).

---

## 2. Protocol

| Method | Description |
|--------|-------------|
| `start()` | Load jobs, register heartbeat, start APScheduler |
| `stop()` | Graceful shutdown, wait for running jobs |
| `add_job(job)` | Register a job (config or dynamic) |
| `remove_job(job_id)` | Remove a job |
| `enable(job_id)` | Enable a disabled job |
| `disable(job_id)` | Disable without removing |
| `list_jobs()` | All jobs with next_run time and status |
| `run_now(job_id)` | Force immediate execution |
| `health()` | Running state, active jobs, failure counts |

APScheduler handles scheduling, coalescing, and missed-fire logic.

---

## 3. Triggers

| Trigger | Format | Example |
|---------|--------|---------|
| **cron** | 5-field expression | `"0 9 * * 1-5"` (weekdays 9am) |
| **interval** | Seconds | `3600` (every hour) |
| **at** | `"at"`, `"at:+SECONDS"`, or `"at:ISO_DATETIME"` | `"at:+60"` (60s delay), `"at:2026-03-04T15:00:00"` (absolute) |
| **event** | EventType name | `"tool.failed"` (react to Bus event) |

Cron and interval use APScheduler's `CronTrigger.from_crontab()` and `IntervalTrigger(seconds=N)`. The `at` trigger (nanobot `at_iso` pattern) supports three formats: `"at"` (immediate), `"at:+60"` (relative delay), and `"at:2026-03-04T15:00:00"` (absolute ISO datetime with optional timezone). Delayed/absolute `at` uses `DateTrigger`; immediate uses `asyncio.create_task`. Event triggers subscribe to the EventBus — when a matching event fires, the job executes.

If previous run is still active when next trigger fires, the trigger is skipped (APScheduler `max_instances=1`). Global concurrency is limited by `max_concurrent_jobs` (default 5) via `asyncio.Semaphore`.

---

## 4. Job Definition

```yaml
cron:
  enabled: true
  jobs:
    daily-report:
      schedule: "0 9 * * 1-5"      # cron expression (or integer for interval seconds)
      agent: default
      prompt: "Generate a daily status report. Check CI, open PRs, and pending issues."
      session_mode: isolated         # isolated | persistent
      notify_channels: [cli]         # where to deliver results (empty = log only)
      enabled: true

    monitor-ci:
      schedule: 3600                 # interval: every hour
      agent: explorer                # cheap fast model
      prompt: "Check if CI pipeline is green. Only report if something is wrong."
      session_mode: persistent       # same session across runs
      enabled: true

    on-leak-cleanup:
      schedule: "security.leak"     # event trigger: fires when leak detected
      agent: default
      prompt: "A credential leak was detected. Review the audit log and suggest remediation."
      enabled: true
```

### Fields

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `schedule` | string or int | required | Cron expression, interval seconds, `"at"` / `"at:+SECONDS"` / `"at:ISO_DATETIME"`, or EventType name |
| `agent` | string | `"default"` | Which agent processes the job |
| `prompt` | string | required | The message sent to the agent |
| `session_mode` | string | `"isolated"` | `isolated` or `persistent` |
| `notify_channels` | list | `[]` | Channels for result delivery; `["*"]` = all active channels |
| `enabled` | bool | true | Whether job is active |
| `timeout` | int or null | null | Per-job timeout override in seconds (null = use global default) |

**Trigger auto-detection**: `"at"` / `"at:+N"` / `"at:ISO"` → one-shot, integer → interval, string with `.` matching an EventType → event trigger, other string → cron expression. No explicit `trigger` field needed.

---

## 5. Session Modes

| Mode | Session Key | Behavior | Use Case |
|------|-----------|----------|----------|
| **isolated** | `scheduler:{job_id}:{run_id}` | Fresh each run | Reports, cleanup |
| **persistent** | `scheduler:{job_id}` | Reused across runs | Monitoring (agent remembers previous checks) |

Isolated is the default — safe, no state leakage. Persistent is opted in when context matters.

---

## 6. Heartbeat + HEARTBEAT.md

The heartbeat is a **built-in interval job** (default: every 30 minutes).

### What it does

1. Read `{workspace}/HEARTBEAT.md` (if exists)
2. Pass content to the agent as the job prompt
3. Agent **decides** whether to take action (nanobot virtual-tool-call pattern)
4. If no action needed, returns silently (no noise)

### HEARTBEAT.md

Users write natural-language tasks. The agent and users both can edit this file.

```markdown
# Heartbeat Tasks

- Check if any PR review requests are pending
- Monitor CI pipeline for failures on main branch
```

### Config

```yaml
cron:
  heartbeat:
    enabled: true
    interval: 1800       # 30 minutes (seconds)
```

When `heartbeat.enabled` is true, the scheduler auto-registers a built-in interval job named `__heartbeat__`.

---

## 7. CronTool (Agent Self-Scheduling)

Built-in tool (nanobot pattern) — the agent can manage its own jobs.

```
name: cron
parameters:
  action: "list" | "add" | "remove" | "enable" | "disable" | "describe"
  job_id: string           (for remove/enable/disable/describe)
  schedule: string | int   (for add: "at:+SECONDS", "at:ISO_DATETIME", cron expr, interval, event type)
  prompt: string           (for add)
  notify_channels: list    (for add: default ["*"] to broadcast to all active channels)
```

Examples:
- "Remind me in 5 minutes" → `cron(action="add", schedule="at:+300", prompt="...", notify_channels=["*"])`
- "Remind me at 3pm" → `cron(action="add", schedule="at:2026-03-04T15:00:00", prompt="...")`
- "Schedule a daily standup summary" → `cron(action="add", schedule="0 9 * * 1-5", prompt="...")`
- "Cancel the CI check" → `cron(action="remove", job_id="monitor-ci")`
- "What does that job do?" → `cron(action="describe", job_id="monitor-ci")`
- "Pause the monitor job" → `cron(action="disable", job_id="monitor-ci")`
- "Resume the monitor job" → `cron(action="enable", job_id="monitor-ci")`

Dynamic jobs persist to `{workspace}/.workpilot/cron/jobs.json`. When `notify_channels` is omitted in `add`, it defaults to `["*"]` to ensure results reach the user.

---

## 8. Persistence

| What | Where | Format |
|------|-------|--------|
| **Static jobs** | `workpilot.yaml` → `cron.jobs` | YAML (in config) |
| **Dynamic jobs** | `.workpilot/cron/jobs.json` | JSON array |
| **Run history** | `.workpilot/cron/runs/{job_id}.jsonl` | JSONL (auto-pruned, last 100) |

Config jobs take precedence over dynamic jobs with the same ID.

---

## 9. Error Handling

| Scenario | Behavior |
|----------|----------|
| Job exception | Catch, log, record in history with `error_type`, continue to next run |
| Job timeout (v2: per-job override via `timeout` field) | Cancel task, mark as failed |
| N consecutive failures (5 default) | Auto-disable job via `disable()`, log warning |
| Failed `at` (one-shot) job | Disabled (not removed) — kept for inspection via `list` |
| E-stop active | All jobs suspended |
| Disabled job | Skipped by scheduler, re-enable via `enable()` or CLI |
| Concurrent job limit exceeded | Job waits for semaphore (up to `max_concurrent_jobs`, default 5) |

Run history records include `error_type` (e.g. `"RuntimeError"`, `"TimeoutError"`) on failure for diagnostics. Result previews are stored up to 500 characters.

No complex retry/backoff in v1. If the agent fails, it will try again at the next scheduled time. Auto-disabled jobs can be re-enabled via `enable(job_id)` or `workpilot cron enable <id>`.

---

## 10. Result Delivery

When a cron job produces a response:

1. **Always**: record in run history (JSONL)
2. **If `notify_channels` specified**: publish `OutboundMessage` to each channel
3. **Empty suppression**: if the agent returns nothing actionable, skip notification (heartbeat pattern)

### OutboundMessage fields

| Field | Value | Purpose |
|-------|-------|---------|
| `channel` | target channel name (e.g. `"cli"`) | Routing |
| `channel_id` | `"scheduler:<job_name>"` | Identifies scheduler as sender (not a user conversation) |
| `content` | `"[Cron: <job_name>]\n<result>"` | Prefixed for traceability |
| `metadata.source` | `"scheduler"` | Audit trail |
| `metadata.job_name` | job name | Links notification to job |
| `metadata.session_id` | session ID used for execution | Links notification to run session |

### Wildcard resolution

`notify_channels: ["*"]` resolves to all active channels at notification time via `active_channels_fn()`. Each channel delivery is wrapped in `try/except` — one channel failure does not block others.

---

## 11. Runtime Wiring

Note: the current codebase has `CronService` in `workpilot/cron/service.py`. This will be renamed to `SchedulerService` during implementation to reflect the broader scope (cron + interval + event + heartbeat).

```
Runtime.__init__():
  if config.cron.enabled:
    self.scheduler = SchedulerService(config.cron, bus, workspace)
    self.tool_registry.register(CronTool(self.scheduler))

Runtime.run_chat() / run_gateway():
  if self.scheduler:
    await self.scheduler.start()
  ...
  if self.scheduler:
    await self.scheduler.stop()
```

---

## 12. Config

```yaml
cron:
  enabled: false                    # disabled by default
  max_concurrent_jobs: 5            # global concurrency limit (asyncio.Semaphore)
  heartbeat:
    enabled: true
    interval: 1800                  # 30 minutes
  jobs:
    # ... user-defined jobs (see Section 4)
```

---

## 13. CLI Commands

| Command | Description |
|---------|-------------|
| `workpilot cron list` | List all jobs with status, next run time |
| `workpilot cron add` | Add a dynamic job (interactive) |
| `workpilot cron remove <id>` | Remove a dynamic job |
| `workpilot cron enable <id>` | Enable a disabled job |
| `workpilot cron disable <id>` | Disable a job |
| `workpilot cron run <id>` | Force immediate execution |
| `workpilot cron history [<id>]` | Show run history |
| `workpilot cron status` | Scheduler health (running, active/disabled counts) |

---

## 14. Implementation Priority

| Phase | What | Depends On |
|-------|------|-----------|
| **1** | SchedulerService (start/stop, APScheduler, job CRUD) | Config |
| **2** | Job execution via AgentLoop.run_once() | Agent Loop |
| **3** | Heartbeat + HEARTBEAT.md | Phase 2 |
| **4** | CronTool (agent self-scheduling) | Phase 1, Tool Registry |
| **5** | Run history (JSONL) + dynamic job persistence | Phase 2 |
| **6** | CLI commands (remove, run, history) | Phase 1, 5 |
