# Channel Architecture

> **Type**: Core Infrastructure
> **Date**: 2026-02-28
> **Parent**: [core-infra.md](../core-infra.md) Section 4.2

---

## Reference

| Dimension | OpenClaw | nanobot | NanoClaw | IronClaw | ZeroClaw |
|-----------|---------|---------|----------|----------|----------|
| **Abstraction** | Gateway WS hub | **MessageBus queue** | WhatsApp-first | WASM channels | **Channel trait** |
| **Channel count** | 15+ | 12 | WhatsApp + skills | 7+ (WASM) | 20+ |
| **Multi-channel** | Yes (all via Gateway) | Yes (all via Bus) | Limited | Yes (hot-load) | Yes (trait-driven) |
| **Isolation** | Per-channel independent | Per-channel independent | **Per-group container** | Per-channel independent | Per-channel independent |
| **Routing** | **Agent binding** (channel→agent) | Single agent queue | **Per-group** (channel→container) | Intent router | Multi-agent IPC |
| **Session mapping** | Channel+account+peer → session | Channel+sender → session | Group → session | Session per channel | Session per channel |
| **Auth model** | **Pairing + allowlist + DM policy** | allowFrom list | WhatsApp QR | **Pairing + allowlist** | **OTP + allowlist** |
| **Remote access** | Fly.io deploy | None | WhatsApp as relay | Local | **Tunnel trait** (CF/TS/ngrok) |
| **Hot-add** | Via extensions | No | Via Skills (code mod) | **WASM hot-load** | Config-driven |
| **Attachments** | Media pipeline (image/audio/video) | Not detailed | Via container | Not detailed | Not detailed |

---

## 1. Three-Tier Channel Model

```
┌─────────────────────────────────────────────────────────────┐
│  Tier 1: Local (always available)                            │
│  ┌────────────────┐                                         │
│  │  CLI Channel    │ ← workpilot chat / run                 │
│  └────────────────┘                                         │
├─────────────────────────────────────────────────────────────┤
│  Tier 2: Self-Hosted Gateway (opt-in)                        │
│  ┌────────────────┐                                         │
│  │  Gateway        │ ← workpilot serve                      │
│  │  REST/SSE/WS   │ ← requires reachable IP                │
│  └────────────────┘                                         │
├─────────────────────────────────────────────────────────────┤
│  Tier 3: Cloud Gateway (opt-in)                              │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  Cloud Channel (outbound WSS → Cloud Gateway)        │    │
│  │                                                      │    │
│  │  Source channels via Cloud Gateway:                   │    │
│  │    Teams │ Web Chat                                   │    │
│  │    (shared infrastructure, no user bot/app setup)     │    │
│  └─────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
```

| Tier | Channel | Need | User action | Data location |
|------|---------|------|-------------|---------------|
| 1 | CLI | Nothing | `workpilot chat` | Local |
| 2 | Gateway | Reachable IP/port | `workpilot serve` | Local |
| 3 | Cloud | Entra ID login | `workpilot cloud` | Local (Cloud Gateway is stateless relay) |

---

## 2. Channel Protocol

All channels implement:

| Method | Description |
|--------|-------------|
| `start()` | Begin listening for external input |
| `stop()` | Stop listening, drain in-flight messages |
| `send(OutboundMessage)` | Deliver response to external surface |
| `supports_streaming → bool` | Whether channel can deliver token-by-token |
| `health() → HealthStatus` | Connection/readiness status |

### Channel Properties

| Property | Type | Description |
|----------|------|-------------|
| `name` | string | Unique identifier (e.g., "cli", "web", "cloud") |
| `supports_streaming` | bool | Token streaming capability |
| `supports_attachments` | bool | Can send/receive files, images |
| `supports_threading` | bool | Threaded conversations (reply in thread) |
| `auth_required` | bool | Whether inbound messages must be authenticated |

---

## 3. Message Types

> Canonical definitions in [message-bus.md](message-bus.md). Summary here.

### InboundMessage

```
InboundMessage:
  channel: str              # "cli", "web", "cloud"
  channel_id: str           # routing identifier (for Cloud: cid_* from Cloud Gateway)
  sender_id: str            # user identifier
  content: str              # message text
  thread_id: str | None     # for threaded conversations
  session_key: str           # computed: "{channel}:{sender_id}:{thread_id}"
  attachments: list | None  # files, images
  timestamp: datetime
  metadata: dict
    source: str | None      # original source for Cloud ("cloud_teams", "cloud_webchat")
    tenant_id: str | None   # Entra ID tenant (for Cloud)
    injection: bool          # true if injected during active processing
    interrupt: bool          # true if /stop or /cancel
```

### OutboundMessage

```
OutboundMessage:
  channel: str              # target channel
  channel_id: str           # routing identifier
  content: str              # response text
  thread_id: str | None     # reply in thread
  attachments: list | None  # files to attach
```

### StreamingChunk

```
StreamingChunk:
  channel: str              # target channel
  channel_id: str           # routing identifier
  content: str              # text fragment
  chunk_type: str           # "token" | "tool_progress" | "status"
  done: bool                # true on final chunk
```

---

## 4. Routing

### Message Flow

```
External input
  ↓
Channel normalizes → InboundMessage
  ↓
Published to Message Bus
  ↓
Agent Loop consumes from Bus (FIFO)
  ↓
Agent processes → OutboundMessage / StreamingChunk
  ↓
Published to Bus
  ↓
Channel subscribes to messages matching its name → delivers to external surface
```

### Session Mapping

Each inbound message maps to a session:

| Channel | Session key | Pattern |
|---------|-------------|---------|
| CLI | Fixed ("cli:local") | Single session per REPL |
| Gateway | Request-provided or auto-generated | Per-API-caller |
| Cloud | `{source}:{sender_id}:{thread_id}` | Per-conversation-thread |

`{source}` is `"cloud_teams"` or `"cloud_webchat"` — the `cloud_` prefix distinguishes Cloud Gateway sessions from any future direct channel implementations.

Example: A Teams message from user with OID `a7f3d9b2...` in conversation `19:abc123@thread.v2` maps to session `cloud_teams:a7f3d9b2-...:19:abc123@thread.v2`. (Teams `sender_id` uses `from.aadObjectId`, not display name, because display names are mutable and non-unique.)

**CloudChannel session key handling**: The Cloud Gateway server pre-computes `session_key` and sends it in the wire `message` frame. The Python `CloudChannel` sets `InboundMessage.session_key` directly from this value — it does **not** call `SessionManager.get_or_create_id()`. That method is designed for channels where the session key is derived locally (`{channel}:{sender_id}`) and does not incorporate `thread_id`. Cloud channel bypasses it to preserve the full `{source}:{sender_id}:{thread_id}` identity.

The Agent Loop uses the session key to load/store conversation history. Different threads = different sessions = independent context.

### Multi-Channel Concurrency

Multiple channels can be active simultaneously. Each channel operates independently:
- One channel's failure doesn't affect others (Bus decouples)
- Messages from different channels are processed sequentially by the Agent Loop (single queue)
- Messages within the same session share conversation context
- Messages from different sessions are independent

---

## 5. Channel Isolation

Each channel is an independent subsystem:

| Aspect | Behavior |
|--------|----------|
| **Failure isolation** | One channel crash doesn't affect others |
| **Auth isolation** | Each channel has its own auth mechanism |
| **Session isolation** | Different channels can map to different or same sessions |
| **Lifecycle isolation** | Channels start/stop independently |
| **Resource isolation** | Each channel manages its own connections/sockets |

---

## 6. Channel Auth

| Channel | Auth | Who validates |
|---------|------|--------------|
| CLI | None (local user trusted) | N/A |
| Gateway | API key (`X-API-Key`) or Entra ID Bearer token | Gateway middleware |
| Cloud | Entra ID (device code login → MSAL token) | Cloud Gateway service |
| Teams (via Cloud) | Entra ID (Bot Framework user identity) | Cloud Gateway |
| Web Chat (via Cloud) | Entra ID (browser login) | Cloud Gateway |

All auth decisions happen **before** the message reaches the Agent Loop. The Agent Loop trusts that the channel has already authenticated the sender.

---

## 7. Source Channels via Cloud Gateway

The Cloud Gateway is a **single WorkPilot channel** (`cloud`) that multiplexes multiple external source channels. The WorkPilot client doesn't need separate implementations for Teams, Outlook, GitHub, etc. — the Cloud Gateway normalizes everything into `InboundMessage`.

```
Cloud Gateway (public service)
  ├─ Teams bot (Bot Framework)     → InboundMessage(channel="cloud", metadata.source="cloud_teams")
  ├─ Web Chat (browser)            → InboundMessage(channel="cloud", metadata.source="cloud_webchat")
  └─ (future: more source channels can be added to Cloud Gateway)
  ↓
All forwarded to user's client via WSS
  ↓
WorkPilot client receives as InboundMessage on the "cloud" channel
```

**Users never register their own bots or AAD apps.** The Cloud Gateway provides shared infrastructure for all users.

---

## 8. Channel Lifecycle

| Phase | Behavior |
|-------|----------|
| **Registration** | Channel registered with Runtime at startup (from config) |
| **Start** | Channel starts listening (open connections, bind ports) |
| **Running** | Receives/sends messages via Bus |
| **Health check** | Heartbeat monitors channel health |
| **Reconnect** | On connection loss: auto-reconnect with exponential backoff (Cloud channel) |
| **Stop** | Graceful shutdown: drain in-flight messages, close connections |
| **E-stop** | All channels continue running but stop processing new messages (Agent Loop halted, not channels) |

### Hot-Reload

Tool Registry supports hot-reload (register/unregister at runtime). Channels do NOT support hot-add/remove at runtime in v1 — channel configuration requires restart. This is simpler and matches nanobot's approach. (IronClaw has WASM hot-load but that's Rust-specific complexity.)

---

## 9. Comparison: WorkPilot vs Reference Projects

| Aspect | OpenClaw | nanobot | WorkPilot |
|--------|---------|---------|-----------|
| **CLI** | Gateway WS client | Channel on Bus | Channel on Bus (nanobot pattern) |
| **HTTP Gateway** | WS control plane (150+ files) | None | FastAPI REST/SSE/WS (simpler) |
| **Remote access** | Fly.io / native apps | None | **Cloud Gateway** (unique: stateless relay + shared bots) |
| **External channels** | 15+ built-in | 12 built-in | **Via Cloud Gateway** (no client-side channel code) |
| **Auth** | Pairing + allowlist | allowFrom | **Entra ID** (enterprise SSO) |
| **Data location** | Local | Local | **Always local** (Cloud Gateway never stores data) |
| **Web chat** | Built-in WebChat UI | None | **Via Cloud Gateway** (browser → Cloud → client) |
| **Bot registration** | Per-user setup | Per-user setup | **Shared** (Cloud Gateway manages) |

WorkPilot's unique contribution: **three tiers with zero-config escalation** (CLI → Gateway → Cloud), where the Cloud tier provides enterprise channel access (Teams, Outlook, GitHub, ADO, web chat) without requiring users to manage bots, apps, or public endpoints.

---

## Feature Specs

| Channel | Spec location |
|---------|---------------|
| CLI | [features/channel-cli.md](../features/channel-cli.md) |
| Gateway | [features/channel-web.md](../features/channel-web.md) |
| Cloud | [features/channel-cloud.md](../features/channel-cloud.md) |
