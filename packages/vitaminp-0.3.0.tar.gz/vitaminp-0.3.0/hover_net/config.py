# Cell 1: Patch config.py values at runtime (no need to edit the file)
import importlib
import random
import cv2
import numpy as np
from dataset import get_dataset

class Config(object):
    def __init__(self):
        self.seed        = 10
        self.logging     = True
        self.debug       = False

        model_name  = "hovernet"
        model_mode  = "fast"   # PanNuke is 256x256 → fast mode
        nr_type     = 6        # 5 cell types + background

        self.type_classification = True

        act_shape = [256, 256]
        out_shape = [164, 164]

        self.dataset_name = "pannuke"
        self.log_dir      = "/rsrch9/home/plm/idso_fa1_pathology/TIER2/yasin-vitaminp/pannuke/hovernet_logs"

        self.train_dir_list = [
            "/rsrch9/home/plm/idso_fa1_pathology/TIER2/yasin-vitaminp/pannuke/hovernet_format/train"
        ]
        self.valid_dir_list = [
            "/rsrch9/home/plm/idso_fa1_pathology/TIER2/yasin-vitaminp/pannuke/hovernet_format/valid"
        ]

        self.shape_info = {
            "train": {"input_shape": act_shape, "mask_shape": out_shape},
            "valid": {"input_shape": act_shape, "mask_shape": out_shape},
        }

        self.dataset     = get_dataset("consep")  # consep works fine as base dataset type
        module           = importlib.import_module("models.%s.opt" % model_name)
        self.model_config = module.get_config(nr_type, model_mode)