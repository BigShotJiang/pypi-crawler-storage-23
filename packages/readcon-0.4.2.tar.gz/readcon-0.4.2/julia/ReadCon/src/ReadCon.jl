module ReadCon

include("types.jl")
include("wrapper.jl")

export Atom, ConFrame, read_con, write_con

end # module
