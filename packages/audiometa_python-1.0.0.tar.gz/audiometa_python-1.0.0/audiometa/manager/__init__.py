"""Metadata manager classes for different audio formats."""
