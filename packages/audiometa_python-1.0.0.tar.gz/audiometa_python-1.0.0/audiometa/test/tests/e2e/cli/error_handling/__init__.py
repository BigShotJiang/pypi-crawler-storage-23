# Error handling tests for CLI
