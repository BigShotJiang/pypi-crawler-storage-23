"""Integration tests for reading metadata."""
