"""Tests for multiple entries for the same tag."""
