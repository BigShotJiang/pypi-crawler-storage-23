"""Tests for reading multiple entries for the same tag."""
