# GitLab

Детальний гайд для інтеграції з GitLab CI.

---

## Токени {#tokens}

### CI_JOB_TOKEN (автоматичний)

В GitLab CI автоматично доступний `CI_JOB_TOKEN`:

```yaml
variables:
  AI_REVIEWER_GITLAB_TOKEN: $CI_JOB_TOKEN
```

**Обмеження `CI_JOB_TOKEN`:**

| Функція | Статус |
|---------|--------|
| Читати MR | :white_check_mark: |
| Читати diff | :white_check_mark: |
| Постити notes | :white_check_mark: |
| Створювати discussions | :x: |

!!! warning "Обмежені права"
    `CI_JOB_TOKEN` не може створювати inline discussions.

    Для повної функціональності використовуйте Personal Access Token.

### Personal Access Token (PAT) {#get-token}

Для **всіх планів GitLab** (включаючи Free). Рекомендовано для локального запуску або повної функціональності в CI.

**Як створити:**

1. Перейдіть до **User Settings → Access Tokens → Add new token**
    - URL: `https://gitlab.com/-/user_settings/personal_access_tokens`
2. Заповніть поля:
    - **Token name:** `ai-code-reviewer`
    - **Expiration date:** встановіть за потреби (наприклад, 1 рік)
    - **Scopes:** оберіть **`api`**
3. Натисніть **Create personal access token**
4. **Скопіюйте токен одразу** — GitLab показує його лише один раз!

**Як використовувати в CI:**

1. Перейдіть до **Settings → CI/CD → Variables → Add variable**
2. Додайте змінну:
    - **Key:** `AI_REVIEWER_GITLAB_TOKEN` (або `GITLAB_TOKEN`)
    - **Value:** вставте ваш токен
    - **Flags:** увімкніть **Masked** та **Protected**
3. Використовуйте в `.gitlab-ci.yml`:

```yaml
variables:
  AI_REVIEWER_GITLAB_TOKEN: $GITLAB_TOKEN  # Personal Access Token з CI/CD Variables
```

!!! warning "Збережіть токен"
    GitLab показує токен **лише один раз**. Збережіть його в безпечному місці одразу.

### Project Access Token (:material-crown: Premium/Ultimate) {#project-token}

Доступний лише на планах **GitLab Premium** та **Ultimate**. Гарний вибір, якщо ви хочете токен, прив'язаний до проєкту, а не до особистого акаунту.

**Переваги над PAT:**

- Обмежений одним проєктом (немає доступу до інших проєктів)
- Може бути відкликаний мейнтейнерами проєкту (немає залежності від конкретного користувача)
- Краще для команд — не прив'язаний до персонального акаунту

**Як створити:**

1. Перейдіть до **Project → Settings → Access Tokens**
    - URL: `https://gitlab.com/<owner>/<repo>/-/settings/access_tokens`
2. Заповніть поля:
    - **Token name:** `ai-code-reviewer`
    - **Role:** `Developer` (мінімально необхідна роль)
    - **Scopes:** оберіть **`api`**
3. Натисніть **Create project access token**
4. **Скопіюйте токен одразу**

**Як використовувати в CI:**

Так само як PAT — додайте як `AI_REVIEWER_GITLAB_TOKEN` в CI/CD Variables:

```yaml
variables:
  AI_REVIEWER_GITLAB_TOKEN: $GITLAB_PROJECT_TOKEN  # Project Access Token з CI/CD Variables
```

!!! info "Який токен обрати?"
    | | CI_JOB_TOKEN | Personal Access Token | Project Access Token |
    |---|---|---|---|
    | **План** | Всі | Всі (включаючи Free) | Лише Premium/Ultimate |
    | **Налаштування** | Автоматичне | Ручне | Ручне |
    | **Область дії** | Лише поточний job | Всі проєкти користувача | Один проєкт |
    | **Inline коментарі** | :x: | :white_check_mark: | :white_check_mark: |
    | **Найкраще для** | Швидкий старт | Free план + повні можливості | Команди на Premium/Ultimate |

---

## CI/CD Variables

### Додавання змінних

`Settings → CI/CD → Variables → Add variable`

| Змінна | Значення | Опції |
|--------|----------|-------|
| `AI_REVIEWER_GOOGLE_API_KEY` | Gemini API ключ | Masked |
| `AI_REVIEWER_GITLAB_TOKEN` | PAT (якщо потрібен) | Masked |

!!! tip "Masked"
    Завжди вмикайте **Masked** для секретів — вони не будуть показані в логах.

---

## Triggers

### Рекомендований trigger

```yaml
rules:
  - if: $CI_PIPELINE_SOURCE == "merge_request_event"
```

Це запускає job тільки для Merge Request pipelines.

### Альтернативний trigger (only/except)

```yaml
only:
  - merge_requests
```

!!! note "rules vs only"
    `rules` — новіший синтаксис, рекомендований GitLab.

---

## Job приклади

### Мінімальний

```yaml
ai-review:
  image: ghcr.io/konstziv/ai-code-reviewer:1
  script:
    - ai-review
  rules:
    - if: $CI_PIPELINE_SOURCE == "merge_request_event"
  variables:
    AI_REVIEWER_GOOGLE_API_KEY: $GOOGLE_API_KEY
    AI_REVIEWER_GITLAB_TOKEN: $CI_JOB_TOKEN  # Автоматичний, не потребує налаштування
```

### Повний (рекомендовано)

```yaml
ai-review:
  image: ghcr.io/konstziv/ai-code-reviewer:1
  stage: test
  script:
    - ai-review
  rules:
    - if: $CI_PIPELINE_SOURCE == "merge_request_event"
  allow_failure: true
  timeout: 10m
  variables:
    AI_REVIEWER_GOOGLE_API_KEY: $GOOGLE_API_KEY
    # CI_JOB_TOKEN (автоматичний) або Personal Access Token для повних прав:
    AI_REVIEWER_GITLAB_TOKEN: $CI_JOB_TOKEN    # або: $GITLAB_PAT (див. "Отримання токена")
    AI_REVIEWER_LANGUAGE: uk
    AI_REVIEWER_LANGUAGE_MODE: adaptive
  interruptible: true
```

**Що робить:**

- `allow_failure: true` — MR не блокується якщо review failed
- `timeout: 10m` — максимум 10 хвилин
- `interruptible: true` — можна скасувати при новому коміті

### З кастомним stage

```yaml
stages:
  - test
  - review
  - deploy

ai-review:
  stage: review
  image: ghcr.io/konstziv/ai-code-reviewer:1
  script:
    - ai-review
  rules:
    - if: $CI_PIPELINE_SOURCE == "merge_request_event"
  needs: []  # Не чекати на попередні stages
```

---

## Self-hosted GitLab

### Конфігурація

```yaml
variables:
  AI_REVIEWER_GITLAB_URL: https://gitlab.mycompany.com
  AI_REVIEWER_GOOGLE_API_KEY: $GOOGLE_API_KEY
  AI_REVIEWER_GITLAB_TOKEN: $GITLAB_TOKEN
```

### Docker registry

Якщо ваш GitLab не має доступу до `ghcr.io`, створіть mirror:

```bash
# На машині з доступом
docker pull ghcr.io/konstziv/ai-code-reviewer:1
docker tag ghcr.io/konstziv/ai-code-reviewer:1 \
    gitlab.mycompany.com:5050/devops/ai-code-reviewer:latest
docker push gitlab.mycompany.com:5050/devops/ai-code-reviewer:latest
```

```yaml
ai-review:
  image: gitlab.mycompany.com:5050/devops/ai-code-reviewer:latest
```

---

## GitLab CI змінні

AI Code Reviewer автоматично використовує:

| Змінна | Опис |
|--------|------|
| `CI_PROJECT_PATH` | `owner/repo` |
| `CI_MERGE_REQUEST_IID` | Номер MR |
| `CI_SERVER_URL` | URL GitLab |
| `CI_JOB_TOKEN` | Автоматичний токен |

Вам не потрібно передавати `--repo` та `--pr` — вони беруться з CI автоматично.

---

## Результат review

### Notes (коментарі)

AI Review публікує коментарі до MR як notes.

### Discussions (inline)

Для inline коментарів потрібен повний PAT токен (не `CI_JOB_TOKEN`).

Inline коментарі з'являються безпосередньо біля рядків коду в diff view.

### Summary

В кінці review публікується Summary note з:

- Загальною статистикою
- Метриками
- Good practices

---

## Troubleshooting

### Review не постить коментарі

**Перевірте:**

1. `AI_REVIEWER_GOOGLE_API_KEY` (або `GOOGLE_API_KEY`) змінна встановлена
2. `AI_REVIEWER_GITLAB_TOKEN` (або `GITLAB_TOKEN`) має достатньо прав (scope: `api`)
3. Pipeline запущено для MR (не для гілки)

### "401 Unauthorized"

**Причина:** Невалідний токен.

**Рішення:**

- Перевірте що токен не expired
- Перевірте scope (потрібен `api`)

### "403 Forbidden"

**Причина:** Недостатньо прав.

**Рішення:**

- Використовуйте PAT замість `CI_JOB_TOKEN`
- Перевірте що токен має доступ до проєкту

### "404 Not Found"

**Причина:** MR не знайдено.

**Рішення:**

- Перевірте що pipeline запущено для MR
- Перевірте `CI_MERGE_REQUEST_IID`

### Rate limit (429)

**Причина:** Перевищено ліміт API.

**Рішення:**

- AI Code Reviewer автоматично retry з backoff
- Якщо постійно — зачекайте або збільште ліміти

---

## Best practices

### 1. Використовуйте PAT для повної функціональності

```yaml
variables:
  AI_REVIEWER_GITLAB_TOKEN: $GITLAB_TOKEN  # PAT, не CI_JOB_TOKEN
```

### 2. Додайте allow_failure

```yaml
allow_failure: true
```

MR не буде заблоковано якщо review failed.

### 3. Встановіть timeout

```yaml
timeout: 10m
```

### 4. Зробіть job interruptible

```yaml
interruptible: true
```

При новому коміті старий review буде скасовано.

### 5. Не чекайте на інші stages

```yaml
needs: []
```

Review запуститься одразу, не чекаючи на build/test.

---

## Наступний крок

- [GitHub інтеграція →](github.md)
- [CLI Reference →](api.md)
