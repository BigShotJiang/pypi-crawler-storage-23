#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
群接龙开放平台API客户端模块

该模块提供了与群接龙开放平台API交互的功能，包括：
- 认证token管理
- 订单查询
- 商品查询
- 同步和异步操作
- 缓存管理

参考文档: 群接龙开放平台API文档
"""
from typing import Optional, Union, Any, Dict

import diskcache
import httpx
import redis
from py_easy_httpx.request import AsyncHttpxRequest

from py_easy_httpx.response import json_paser, async_json_paser


class Open(AsyncHttpxRequest):
    """
    群接龙开放平台API客户端类

    用于与群接龙开放平台API交互，支持认证、订单查询、商品查询等操作
    """

    def __init__(
            self,
            base_url: Optional[str] = "https://openapi.qunjielong.com",
            secret: Optional[str] = None,
            cache_config: Optional[dict] = None,
            client_kwargs: Optional[dict] = None
    ):
        """
        初始化Open实例

        Args:
            base_url: API基础URL，默认为"https://openapi.qunjielong.com"
            secret: 群接龙开放平台密钥
            cache_config: 缓存配置
            client_kwargs: 传递给httpx.Client的额外参数
        """
        # 处理基础URL，确保格式正确
        self.base_url = base_url or "https://openapi.qunjielong.com"
        self.base_url = self.base_url[:-1] if self.base_url.endswith("/") else self.base_url
        
        # 初始化参数
        self.secret = secret or ""
        
        # 初始化缓存配置
        self.cache_config = cache_config or {}
        self.cache_config.setdefault("key", f"py_easy_qunjielong_open_{self.secret}")
        self.cache_config.setdefault("expire", 7100)  # 缓存过期时间，默认7100秒
        
        # 初始化客户端参数
        self.client_kwargs = client_kwargs or {}
        self.client_kwargs.setdefault("base_url", self.base_url)
        self.client_kwargs.setdefault("timeout", 60)  # 设置60秒超时
        
        # 初始化access_token
        self.access_token = ""

    @json_paser(
        validator={
            "type": "object",
            "properties": {
                "code": {
                    "oneOf": [
                        {"type": "integer", "const": 200},
                        {"type": "string", "const": "200"},
                    ],
                },
            },
            "required": ["code"],
        },
        path_expr="$.data"
    )
    def request(self, client: Optional[httpx.Client] = None, **kwargs) -> httpx.Response:
        """
        同步请求方法

        Args:
            client: 可选的同步客户端实例
            **kwargs: 传递给client.request的额外参数

        Returns:
            httpx.Response - HTTP响应对象
        """
        # 确保请求参数中包含accessToken
        params = kwargs.setdefault("params", {})
        params.setdefault("accessToken", self.access_token)
        kwargs["params"] = params
        
        # 发送请求
        if not isinstance(client, httpx.Client):
            with self.client() as client:
                return client.request(**kwargs)
        return client.request(**kwargs)

    @async_json_paser(
        validator={
            "type": "object",
            "properties": {
                "code": {
                    "oneOf": [
                        {"type": "integer", "const": 200},
                        {"type": "string", "const": "200"},
                    ],
                },
            },
            "required": ["code"],
        },
        path_expr="$.data"
    )
    async def async_request(self, client: Optional[httpx.AsyncClient] = None, **kwargs) -> httpx.Response:
        """
        异步请求方法

        Args:
            client: 可选的异步客户端实例
            **kwargs: 传递给client.request的额外参数

        Returns:
            httpx.Response - HTTP响应对象
        """
        # 确保请求参数中包含accessToken
        params = kwargs.setdefault("params", {})
        params.setdefault("accessToken", self.access_token)
        kwargs["params"] = params
        
        # 发送异步请求
        if not isinstance(client, httpx.AsyncClient):
            async with self.async_client() as client:
                return await client.request(**kwargs)
        return await client.request(**kwargs)

    @json_paser(
        validator={
            "type": "object",
            "properties": {
                "code": {
                    "oneOf": [
                        {"type": "integer", "const": 200},
                        {"type": "string", "const": "200"},
                    ],
                },
            },
            "required": ["code"],
        },
        path_expr="$.data"
    )
    def get_access_token(self, client: Optional[httpx.Client] = None, **kwargs) -> Any:
        """
        获取认证token

        Args:
            client: 可选的同步客户端实例
            **kwargs: 传递给request的额外参数

        Returns:
            RequestResponse - 响应结果对象，包含access_token
        """
        # 设置默认请求方法和URL
        kwargs.setdefault("method", "GET")
        kwargs.setdefault("url", "/open/auth/token")
        
        # 确保参数中包含secret
        params = kwargs.get("params", {})
        params.setdefault("secret", self.secret)
        kwargs["params"] = params
        
        # 发送请求
        return self.request(client=client, **kwargs)

    @json_paser(
        validator={
            "type": "object",
            "properties": {
                "code": {
                    "oneOf": [
                        {"type": "integer", "const": 200},
                        {"type": "string", "const": "200"},
                    ],
                },
            },
            "required": ["code"],
        },
        path_expr="$.data"
    )
    def get_home_info(self, client: Optional[httpx.Client] = None, **kwargs) -> Any:
        """
        获取群接龙信息

        Args:
            client: 可选的同步客户端实例
            **kwargs: 传递给request的额外参数

        Returns:
            RequestResponse - 响应结果对象
        """
        # 设置默认请求方法和URL
        kwargs.setdefault("method", "GET")
        kwargs.setdefault("url", "/open/api/ghome/getGhomeInfo")
        
        # 确保参数中包含accessToken
        params = kwargs.get("params", {})
        params.setdefault("accessToken", self.access_token)
        kwargs["params"] = params
        
        # 发送请求
        return self.request(client=client, **kwargs)

    def refresh_access_token(
            self,
            client: Optional[httpx.Client] = None,
            get_access_token_kwargs: Optional[dict] = None,
            get_home_info_kwargs: Optional[dict] = None
    ) -> 'Open':
        """
        刷新access_token

        Args:
            client: 可选的同步客户端实例
            get_access_token_kwargs: 传递给get_access_token的额外参数
            get_home_info_kwargs: 传递给get_home_info的额外参数

        Returns:
            Open - 自身实例，支持链式调用
        """
        # 初始化参数
        get_access_token_kwargs = get_access_token_kwargs or {}
        get_home_info_kwargs = get_home_info_kwargs or {}
        
        # 获取缓存配置
        cache_key = self.cache_config.get("key", f"py_easy_qunjielong_open_{self.secret}")
        cache_expire = self.cache_config.get("expire", 7100)  # 默认缓存7100秒
        cache_instance = self.cache_config.get("instance", None)
        
        # 无缓存实例时，直接获取新的access_token
        if not isinstance(cache_instance, Union[diskcache.Cache, redis.Redis]):
            access_token: str = self.get_access_token(client=client, **get_access_token_kwargs)
            if isinstance(access_token, str) and len(access_token) > 0:
                self.access_token = access_token
        else:
            # 有缓存实例时，先尝试从缓存获取
            self.access_token = cache_instance.get(cache_key, None)
            
            # 验证access_token是否有效（通过调用get_home_info接口）
            home_info: dict = self.get_home_info(client=client,
                                                 **get_home_info_kwargs)
            
            if not home_info:
                # access_token无效，重新获取
                access_token: str = self.get_access_token(client=client, **get_access_token_kwargs)
                if isinstance(access_token, str) and len(access_token) > 0:
                    self.access_token = access_token
                    # 缓存新的access_token
                    if isinstance(cache_instance, diskcache.Cache):
                        cache_instance.set(cache_key, self.access_token, expire=cache_expire)
                    elif isinstance(cache_instance, redis.Redis):
                        cache_instance.set(cache_key, self.access_token, ex=cache_expire)
        
        return self