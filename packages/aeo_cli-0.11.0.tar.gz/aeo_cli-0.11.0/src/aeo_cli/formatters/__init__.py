"""Output formatters for AEO audit reports."""
