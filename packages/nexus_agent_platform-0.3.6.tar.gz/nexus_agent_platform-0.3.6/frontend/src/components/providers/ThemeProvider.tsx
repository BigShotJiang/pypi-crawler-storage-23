"use client";

import { useEffect } from "react";
import { loadTheme, applyTheme } from "@/lib/stores/theme";

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  useEffect(() => {
    const theme = loadTheme();
    applyTheme(theme);

    // localStorage 변경 감지 (다른 탭에서 변경 시)
    const handler = (e: StorageEvent) => {
      if (e.key === "nexus-theme") {
        const updated = loadTheme();
        applyTheme(updated);
      }
    };
    window.addEventListener("storage", handler);
    return () => window.removeEventListener("storage", handler);
  }, []);

  return <>{children}</>;
}
