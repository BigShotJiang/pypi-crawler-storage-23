import os
import asyncio
from litellm import acompletion
from dotenv import load_dotenv
import json

load_dotenv()

async def test_llm():
    api_key = os.getenv("GOOGLE_API_KEY")
    model = os.getenv("LITELLM_MODEL", "gemini/gemini-2.0-flash")
    
    print(f"Testing model: {model}")
    print(f"API Key exists: {bool(api_key)}")
    
    messages = [{"role": "user", "content": "hello"}]
    
    try:
        response = await acompletion(
            model=model,
            messages=messages,
            api_key=api_key
        )
        print("Response received successfully")
        dump = response.model_dump()
        print(json.dumps(dump, indent=2))
        
        message = dump["choices"][0]["message"]
        print(f"Message keys: {message.keys()}")
        print(f"tool_calls value: {message.get('tool_calls')}")
        
        if "tool_calls" in message:
            print("tool_calls key is in message")
            if message["tool_calls"] is None:
                print("tool_calls is None")
            else:
                print(f"tool_calls is: {type(message['tool_calls'])}")
                
    except Exception as e:
        print(f"Error: {str(e)}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(test_llm())
