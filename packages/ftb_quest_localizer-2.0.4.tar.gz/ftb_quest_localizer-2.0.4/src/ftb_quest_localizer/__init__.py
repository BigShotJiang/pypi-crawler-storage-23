"""FTB Quest Localizer - Extract and manage quest strings for easy localization."""

__version__ = "2.0.0"
