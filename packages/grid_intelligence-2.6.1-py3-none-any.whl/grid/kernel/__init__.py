"""Kernel-level primitives: routing, message bus, and scheduling."""
