"""Essence package: foundational state representations for GRID."""

from .core_state import EssentialState

__all__ = ["EssentialState"]
