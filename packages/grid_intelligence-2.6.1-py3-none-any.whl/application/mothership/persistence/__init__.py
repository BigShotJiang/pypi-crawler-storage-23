"""
Persistence module for DRT data.
"""
