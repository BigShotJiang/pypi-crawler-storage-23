"""Light of the seven cognitive module."""
