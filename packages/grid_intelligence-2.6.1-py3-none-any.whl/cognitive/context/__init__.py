"""Cognitive context module for activity domain and context management."""

from .DEFINITION import ActivityDomain

__all__ = ["ActivityDomain"]
