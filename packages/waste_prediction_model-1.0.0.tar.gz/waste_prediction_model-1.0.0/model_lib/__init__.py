"""
model_lib — portable, self-contained waste prediction + FL adapter.

Public API
----------
    from model_lib import WastePredictor, predict_waste
    from model_lib import PredictionInput, PredictionResult
    from model_lib.fl_adapter import (
        FederatedModelAdapter,
        WastePredictorFLAdapter,
        FLMessage,
        FLEventType,
        MODEL_REGISTRY,
        get_adapter,
    )

Quick start
-----------
    predictor = WastePredictor()          # loads model lazily on first predict
    result = predictor.predict(
        production_volume=50_000,
        rain_sum=200,
        temperature_mean=28,
        humidity_mean=85,
        wind_speed_mean=15,
        month=6,
    )
    print(result.total_waste_kg)

Model file location
-------------------
Set the ``WASTE_PREDICTOR_MODEL_PATH`` environment variable, or drop the .pkl
file at  ``~/.model_lib/waste_predictor_v4.pkl``.
"""
from importlib.metadata import PackageNotFoundError, version

from model_lib.predictor import WastePredictor, predict_waste
from model_lib.types import (
    OUTPUT_COLUMNS,
    INPUT_COLUMNS,
    PredictionInput,
    PredictionResult,
)

try:
    __version__: str = version("model-lib")
except PackageNotFoundError:   # editable / source install
    __version__ = "0.0.0.dev"

__all__ = [
    # Core prediction
    "WastePredictor",
    "predict_waste",
    # Typed contracts
    "PredictionInput",
    "PredictionResult",
    "OUTPUT_COLUMNS",
    "INPUT_COLUMNS",
    # Metadata
    "__version__",
]
