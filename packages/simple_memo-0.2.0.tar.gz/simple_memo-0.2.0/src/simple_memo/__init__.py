"""simple-memo — A simple CLI for Apple Notes & Reminders on macOS."""

__version__ = "0.2.0"
