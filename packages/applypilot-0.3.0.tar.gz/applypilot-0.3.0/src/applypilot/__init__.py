"""ApplyPilot — AI-powered end-to-end job application pipeline."""

__version__ = "0.3.0"
