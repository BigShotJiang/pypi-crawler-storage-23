"""Scoring pipeline: job scoring, resume tailoring, cover letters, PDF export."""
