"""
PandaDock: GPU-accelerated molecular docking software with SE(3)-equivariant GNN scoring
"""

__version__ = "4.0.1"
__author__ = "Pritam Kumar Panda @Stanford University"