from django.apps import AppConfig


class ThelabInstrumentationConfig(AppConfig):
    name = "thelabinstrumentation"
    label = "thelabinstrumentation"
