"""Tests for the thelabinstrumentation package."""
