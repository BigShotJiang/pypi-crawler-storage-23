"""Framework interceptors for OpenAI, Anthropic, LangChain, and more."""
