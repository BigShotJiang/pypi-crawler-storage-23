"""Audit logging and event bus for AvaKill."""
