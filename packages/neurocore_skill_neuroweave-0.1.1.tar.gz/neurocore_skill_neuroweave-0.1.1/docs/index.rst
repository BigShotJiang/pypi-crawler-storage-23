neurocore-skill-neuroweave
==========================

NeuroWeave knowledge graph memory skill for NeuroCore.

Bridges NeuroWeave's async knowledge graph API into NeuroCore's synchronous
FlowEngine skill system. Registers automatically via the ``neurocore.skills``
entry point.

.. toctree::
   :maxdepth: 2
   :caption: Contents

   autoapi/index
