from cli.drp import main

main()
