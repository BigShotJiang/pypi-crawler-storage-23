---
description: This skill should be used when the user runs "/gsd-lean:plan" or asks to "create a plan", "decompose requirements into tasks", or "generate PLAN.md". Also used from the execute phase to update an existing plan with new information or encountered issues. Decomposes requirements into structured tasks, writes cycle/PLAN.md, and verifies it passes review.
argument-hint: [additional planning context or update details]
allowed-tools: Read, Write, Edit, Glob, Grep, Bash(uvx gsd-lean:*), Bash(git:*), Task, LSP, EnterPlanMode, ExitPlanMode
---

## Current State

**Phase:** !`uvx gsd-lean status --path . 2>/dev/null | grep -A1 "Current Phase" | tail -1 | tr -d '\140'`

## Instructions

Run the **plan phase** of GSD-Lean's development workflow.

### Step 1: Transition Phase

Run:
```
uvx gsd-lean transition plan --path .
```

If this fails with a precondition error, direct the user to run `/gsd-lean:discuss` first.

### Step 1.5: Detect Mode

Check if `.planning/cycle/PLAN.md` exists and its Status header is `in-progress`. If both are true, this is an **update** (returning from execute to revise the plan). Follow **[Update Mode](#update-mode)** below.

Otherwise, this is a fresh plan. Continue with Step 2 (normal mode).

---

## Update Mode

Use this mode when returning from the execute phase to revise an existing PLAN.md. The user must provide `$ARGUMENTS` describing what changed — either new information that affects tasks, or encountered issues to document.

If `$ARGUMENTS` is empty, ask the user what needs updating before proceeding.

### U-1: Read Existing Plan

Call `EnterPlanMode`. Read `.planning/cycle/PLAN.md`, `.planning/cycle/DECISIONS.md`, and `.planning/cycle/REQUIREMENTS.md`.

### U-2: Apply Updates

Based on `$ARGUMENTS`, determine the update type and apply changes:

**New information** — When the user describes new insights, changed requirements, or missing details that affect task definitions:
- Modify the relevant task(s) in both the summary table and Task Details sections
- Update Description, Files, and/or Verification fields as needed
- Add new tasks if the new information requires additional work (use next available T-NNN ID)
- Preserve all existing task statuses (`done`, `in-progress`, etc.) — only modify content, not progress

**Encountered issues** — When the user describes problems encountered during execution and how they were resolved:
- Append an `## Encountered Issues` section at the bottom of PLAN.md (or add to it if one already exists)
- Each issue gets a subsection with **Problem** and **Fix** descriptions
- This documents the issue for subsequent tasks to avoid repeating the same mistake

### U-3: Set Status to Draft

Call `ExitPlanMode` to leave plan mode. Update the PLAN.md Status header from `in-progress` to `draft`. This forces re-verification.

### U-4: Continue to Verification

Skip to [Step 6.5: Read Subagent Config](#step-65-read-subagent-config) to re-verify the updated plan.

---

## Normal Mode

Goal: decompose requirements into structured tasks, write cycle/PLAN.md, and verify it passes review.

### Step 2: Enter Plan Mode

Call `EnterPlanMode`. Task decomposition and design happens in plan mode (read-only). You will exit plan mode before writing PLAN.md.

### Step 3: Read Inputs

Read these files:
- `.planning/cycle/REQUIREMENTS.md` — what to build (User Intent, Motivation, Goals, Non-Goals, Functional Requirements, Affected Files, Key Interfaces, Edge Cases, Testing Strategy, Non-Functional Requirements)
- `.planning/cycle/DECISIONS.md` — how to build it (Style & Preferences, Constraints, Dependencies)
- `.planning/PROJECT.md` — stack, constraints
- `.planning/CONTEXT.md` — static architecture, tooling, skills context

> **Note:** Architecture, Tooling, and Skills context lives in `.planning/CONTEXT.md` (static, persists across cycles). Cycle docs (cycle/REQUIREMENTS.md, cycle/DECISIONS.md) contain per-cycle content only.

### Step 4: Decompose Into Tasks

If the user provided additional arguments (`$ARGUMENTS`), treat them as extra planning context — e.g., scope constraints, priority hints, or focus areas. Factor them into task decomposition alongside the input files.

Break requirements into discrete, committable tasks. For each task:
- **ID:** `T-NNN` format (zero-padded 3 digits, e.g. T-001, T-002)
- **Wave:** integer for execution ordering (wave 1 before wave 2, etc.)
- **Title:** short imperative description
- **Files:** which files are created/modified
- **Verification:** specific, runnable criteria (test commands, lint checks, manual checks)
- **Dependencies:** which other T-NNN tasks must complete first (or "none")

Guidelines:
- Each task touches at most ~5 files (split larger tasks)
- Wave 1 = foundational work (modules, types, core logic)
- Wave 2 = features built on wave 1 (CLI commands, integrations)
- Wave 3 = skills, docs, polish
- **Tracer bullet:** Before full decomposition, identify the thinnest end-to-end slice through all system layers. This is production code (not a prototype) — a minimal but complete path from input to output that validates the architecture. Create 1–3 tasks for this slice, prefix titles with `[tracer]`, assign wave 1, and give them the lowest T-NNN IDs. Remaining tasks expand from this foundation.
  - If the feature is single-layered or too small for a meaningful end-to-end slice, skip the tracer and note why in PLAN.md.
- Every requirement must map to at least one task
- Every decision must be respected in task design
- Every goal in Goals must map to at least one task
- Non-Goals must not appear as tasks
- Affected Files should inform the Files column of each task
- Testing Strategy should inform verification criteria
- Edge Cases should be covered by tasks or verification criteria

### Step 5: Exit Plan Mode

Call `ExitPlanMode` to leave plan mode. The following steps will write PLAN.md and run verification.

### Step 6: Write PLAN.md

Write `.planning/cycle/PLAN.md` using this exact format:

````markdown
# Plan

> **Status:** draft
> **Created:** <ISO 8601 UTC timestamp>
> **Waves:** <total wave count>
> **Source:** cycle/REQUIREMENTS.md

## Tasks

| ID | Wave | Status | Title | Files | Verification |
|----|------|--------|-------|-------|-------------|
| T-001 | 1 | pending | [tracer] <minimal end-to-end title> | `<file1>`, `<file2>` | <brief verification> |
| T-002 | 1 | pending | <title> | `<file>` | <brief verification> |
| T-003 | 2 | pending | <title> | `<file>` | <brief verification> |

## Task Details

### T-001: [tracer] <minimal end-to-end title>

**Description:** <1-3 sentences. Must explain which layers this tracer cuts through and why this is the thinnest valid slice.>

**Files:**
- `path/to/file.py` (create | modify)

**Verification:**
- [ ] <specific check, e.g. "unit tests in tests/test_foo.py pass">
- [ ] <specific check, e.g. "mypy src/module/ clean">

**Dependencies:** none

---

### T-002: <title>

**Description:** ...

**Files:**
- `path/to/file.py` (modify)

**Verification:**
- [ ] ...

**Dependencies:** T-001

---
````

Important:
- Status header MUST be `draft` initially
- Every task in the summary table MUST have a corresponding Task Details section
- Task IDs must be sequential and zero-padded to 3 digits
- Status values: `pending`, `in-progress`, `done`, `blocked`
- Files column uses backtick-wrapped paths, comma-separated

### Step 6.5: Read Subagent Config

Read `.planning/config.yaml` if it exists. For each subagent spawned below, resolve `model` and `max_turns`:

| Subagent | Config key |
|----------|------------|
| plan-review | `skills.plan.subagents.plan-review` |

Fallback to `defaults` section, then omit parameters (inherit from session).

### Step 7: Verify Plan

Use the Task tool to spawn a plan-review subagent with `subagent_type=general-purpose`. If config was loaded, also pass `model` and `max_turns` from the resolved config for `skills.plan.subagents.plan-review`. Omit any parameter that is null/unset.

Read and use the prompt [from references/verify-plan-subagent-prompt.md](references/verify-plan-subagent-prompt.md) as the subagent prompt.

### Step 8: Handle Review Result

**If PASS:**
- Update cycle/PLAN.md Status header from `draft` to `verified`
- Print: "Plan verified. {N} tasks across {W} waves. Run `/gsd-lean:execute` when ready."

**If FAIL:**
- Print the issues found
- Revise cycle/PLAN.md to address each issue
- Re-run the verification subagent (same prompt as Step 7)
- If second review also fails: print issues and ask user to resolve manually
- If second review passes: update Status to `verified`

Maximum 1 revision loop (2 total verification attempts).

### Step 9: Update State

The phase transition in Step 1 already updated STATE.md. No further state updates needed unless you need to note blockers.
