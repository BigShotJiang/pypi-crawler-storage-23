---
description: This skill should be used when the user asks to "discuss a feature", "research requirements", "probe preferences", or runs /gsd-lean:discuss. Runs enriched discuss phase — research, probe preferences, populate requirements and decisions.
argument-hint: [feature or change description]
allowed-tools: Read, Write, Edit, Glob, Grep, Bash(uvx gsd-lean:*), Bash(git:*), Task, WebSearch, WebFetch, LSP, EnterPlanMode, ExitPlanMode, mcp__context7__resolve-library-id, mcp__context7__query-docs
---

## Current State

**Phase:** !`uvx gsd-lean status --path . 2>/dev/null | grep -A1 "Current Phase" | tail -1 | tr -d '\140'`
**Project:** !`head -1 .planning/PROJECT.md 2>/dev/null || echo "Not initialized"`

## Instructions

This is the **discuss phase** of GSD-Lean's development workflow. Goal: deeply understand what the user wants to build, explore the codebase, research external resources, probe user preferences, and capture everything in cycle/REQUIREMENTS.md and cycle/DECISIONS.md. These documents must be **entirely self-contained** — a fresh `/plan` session reads only these + PROJECT.md + CONTEXT.md.

### Step 1: Verify Phase

Read `.planning/STATE.md`. If not in `discuss` phase, run:
```
uvx gsd-lean transition discuss --path . --force
```

### Step 2: Enter Plan Mode

Call `EnterPlanMode`. All exploration, research, and user probing happens in plan mode (read-only).

### Step 3: Read Existing State + Project Context

Read these files to understand current context:
- `.planning/PROJECT.md` — static project overview
- `.planning/CONTEXT.md` — static architecture, tooling, skills context
- `.planning/cycle/REQUIREMENTS.md` — cycle-specific requirements template
- `.planning/cycle/DECISIONS.md` — cycle-specific decisions template
- `CLAUDE.md` at repo root — extract dev commands, code style, conventions, tooling
- `PROJECT_KNOWLEDGE.md` if it exists — architecture, data flow, patterns
- `README.md` if it exists — project overview

Static docs (PROJECT.md, CONTEXT.md) persist across cycles — reference rather than duplicate their content. Cycle docs (cycle/REQUIREMENTS.md, cycle/DECISIONS.md) are fresh templates to populate.

### Step 4: Explore Codebase

**Explore code relevant to the feature before writing anything — this is mandatory.**

1. Use LSP tools (`documentSymbol`, `workspaceSymbol`, `goToDefinition`, `findReferences`) to understand code relevant to the feature
2. Explore source directories that will be affected
3. Identify existing patterns, utilities, modules to reuse or extend
4. Identify exact files that will need to change (for Affected Files section)
5. Read test files to understand testing patterns and conventions

**Prefer LSP over Grep** for code navigation. Use LSP operations to trace code paths, find symbol usages, and understand interfaces. Fall back to Grep only for text patterns that aren't symbols (e.g. string literals, comments, config keys).

### Step 5: Read Subagent Config

Read `.planning/config.yaml` if it exists. For each subagent spawned below, resolve `model` and `max_turns`:

| Subagent | Config key |
|----------|------------|
| explore | `skills.discuss.subagents.explore` |
| verify | `skills.discuss.subagents.verify` |

Fallback to `defaults` section, then omit parameters (inherit from session).

### Step 6: Spawn Research Subagent

Use the Task tool to spawn a research subagent with `subagent_type=Explore`. If config was loaded, also pass `model` and `max_turns` from the resolved config for `skills.discuss.subagents.explore`. Omit any parameter that is null/unset.

Read the prompt template from `references/research-subagent-prompt.md`. Fill in `{feature_description}` from $ARGUMENTS and `{codebase_findings}` from Step 4, then pass the filled prompt to the subagent.

### Step 7: Probe User Preferences

While research runs (or after), actively ask the user about:
- **Architecture:** preferred patterns, module structure, dependency approach
- **Error handling:** style (exceptions vs result types), granularity, user-facing messages
- **Testing:** coverage expectations, test patterns, integration test needs
- **Naming:** conventions for functions, files, classes
- **Constraints:** performance, backwards compatibility, API surface
- **Scope:** what's explicitly in/out

Use `AskUserQuestion` with specific options, not open-ended questions. Ask 2-4 questions max per round.

### Step 8: Exit Plan Mode

Call `ExitPlanMode` to leave plan mode. The following steps will write to `.planning/` files.

### Step 9: Update State Files

Merge research findings + user answers into the following sections. Replace template placeholders with real content. If a section cannot be fully populated during discuss, use `(to be determined during /plan)` as acceptable placeholder for Affected Files — but all other sections must have substantive content.

**`.planning/cycle/REQUIREMENTS.md`** — update these 10 sections:

1. **User Intent** — 1-2 paragraph summary of what + why
2. **Motivation** — why this change is needed, link to issues/PRDs if relevant
3. **Goals** — bulleted list of what this aims to achieve
4. **Non-Goals** — explicit out-of-scope items (prevents scope creep in /plan)
5. **Functional Requirements** — detailed feature requirements
6. **Affected Files** — table of files to create/modify with descriptions
7. **Key Interfaces** — proposed function signatures, class definitions, API contracts
8. **Edge Cases & Error Handling** — numbered list of edge cases + handling
9. **Testing Strategy** — test files, test cases, coverage notes
10. **Non-Functional Requirements** — performance, security, backwards compatibility

**`.planning/cycle/DECISIONS.md`** — update these 3 sections:

1. **Style & Preferences** — code style, naming, pattern preferences
2. **Constraints** — limits, backwards compatibility, API surface
3. **Dependencies** — new packages/tools needed; if none, state "None"

Each decision should have a one-line rationale.

> **Note:** Architecture, Tooling, and Skills context lives in `.planning/CONTEXT.md` (static, persists across cycles). Do NOT duplicate that content in cycle/DECISIONS.md.

### Step 10: Verify Documents

Use the Task tool to spawn a verification subagent with `subagent_type=general-purpose`. If config was loaded, also pass `model` and `max_turns` from the resolved config for `skills.discuss.subagents.verify`. Omit any parameter that is null/unset.

Read the prompt template from `references/verify-subagent-prompt.md` and pass it to the subagent.

**If PASS:** proceed to Step 11.

**If FAIL:** fix the issues and re-verify (max 1 retry). If second attempt also fails, print the issues and ask the user to resolve manually.

### Step 11: Summary

Print a summary of what was captured:
- Key requirements (bulleted)
- Key decisions (bulleted)
- Any gaps or open questions

Then suggest: "Requirements and decisions captured. Run `/gsd-lean:plan` when ready to generate a plan."

## Additional Resources

### Reference Files

Subagent prompt templates (read and fill placeholders before passing to Task tool):
- **`references/research-subagent-prompt.md`** — Research subagent prompt; fill `{feature_description}` and `{codebase_findings}`
- **`references/verify-subagent-prompt.md`** — Verification subagent prompt; use as-is
