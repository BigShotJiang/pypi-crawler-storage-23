# CONTEXT.md Seeding Guidelines

> Adapted from the internal `/claude-md-improver` update guidelines. Guides what to seed into `.planning/CONTEXT.md` during `/init`.

## Core Principle

Only seed information that will genuinely help future agent sessions. Every line must earn its place — the context window is precious.

## What TO Seed

### 1. Commands Discovered

Format: backtick-wrapped command + dash + brief purpose.

```markdown
- `make test` — run pytest suite
- `npm run dev` — start dev server on port 3000
- `cargo build --release` — optimized production build
```

Why: Saves future sessions from rediscovering dev commands.

### 2. Non-Obvious Patterns / Gotchas

```markdown
- Tests must run sequentially due to shared DB state
- `yarn.lock` authoritative; delete `node_modules` if deps mismatch
- `NEXT_PUBLIC_*` vars must be set at build time, not runtime
```

Why: Prevents repeating debugging sessions.

### 3. Architecture Entry Points and Data Flow

```markdown
- Entry: `src/main.py` → CLI dispatcher → command handlers
- Data: request → middleware chain → handler → repository → DB
- Plugin system: extensions loaded from `plugins/` via registry in `src/registry.py`
```

Why: Architecture knowledge not obvious from directory names alone.

### 4. Config Quirks

```markdown
- Redis connection requires `?family=0` suffix for IPv6
- Auth module depends on `crypto` being initialized first
```

Why: Environment-specific knowledge that trips up fresh sessions.

## What NOT to Seed

### 1. Obvious Code Info

Bad: "The `UserService` class handles user operations."
The class name already tells us this.

### 2. Generic Best Practices

Bad: "Always write tests for new features." / "Use meaningful variable names."
Universal advice, not project-specific.

### 3. Info Already in CLAUDE.md

Bad: Duplicating commands or architecture from the project's CLAUDE.md.
Good: "See CLAUDE.md for full command reference" — reference it, don't copy.

### 4. Verbose Explanations

Bad: Multi-sentence explanations of standard technologies.
Good: One-liner per concept. "Auth: JWT with HS256, tokens in Bearer header."

### 5. One-Off Info

Bad: "Fixed a bug in commit abc123 where login didn't work."
Won't recur; clutters the file.

## Validation Checklist

Before finalizing seeded content, verify:

- [ ] Each entry is project-specific
- [ ] No generic advice or obvious info
- [ ] Commands reference real scripts/targets
- [ ] No duplication of CLAUDE.md content
- [ ] Would a fresh agent session find this helpful?
- [ ] Is this the most concise way to express it?
