---
description: This skill should be used when the user asks to "execute a task", "run the next task", "implement the plan", or runs /gsd-lean:execute. Spawns executor subagent, verifies, auto-debugs on failure, and commits.
argument-hint: ["task ID(s) to execute, e.g. 'T-003' or 'T-001 T-003'"]
allowed-tools: Read, Write, Edit, Glob, Grep, Bash, Task, LSP
---

## Current State

**Phase:** !`uvx gsd-lean status --path . 2>/dev/null | grep -A1 "Current Phase" | tail -1 | tr -d '\140'`
**Plan:** !`uvx gsd-lean plan-status --path . 2>/dev/null || echo "No plan"`

## Instructions

Run the **execute phase** of GSD-Lean's development workflow. Goal: pick the next task from PLAN.md, implement it via a subagent, verify it, auto-debug if needed, and commit.

### Step 1: Ensure Execute Phase

**Branch guard:** Run `git rev-parse --abbrev-ref HEAD`. If the current branch equals the repo's default branch (e.g. `main`), **stop immediately** and tell the user:
> You are on the default branch. Create a feature branch before running /gsd-lean:execute.

Do **not** create the branch yourself — let the user decide the branch name.

Read `.planning/STATE.md`. If not in `execute` phase, run:
```
uvx gsd-lean transition execute --path .
```
If this fails (plan not verified), tell the user to run `/gsd-lean:plan` first.

### Step 2: Identify Target Task

**Build target set from arguments:**
1. Extract all task IDs matching `T-\d{3}` from $ARGUMENTS
2. If IDs found → build **target set**:
   - Read Task Details for each task in target set
   - Check **Dependencies:** field; add any dep task IDs whose status is not `done`
   - Repeat expansion transitively until no new tasks added
   - Print which tasks are in target set (including auto-added deps)
3. If no IDs in $ARGUMENTS → no target set (execute all pending tasks as before)

**Select next task:**
- If target set exists:
  1. Check for `in-progress` task within target set
  2. Else find first `pending` task in target set (wave order, then ID order)
- If no target set:
  1. Check for `in-progress` task in cycle/PLAN.md
  2. Else find first `pending` task in wave order

If no task available:
- Target set → "All specified tasks complete: {IDs}." Stop.
- No target set → "All tasks complete. Run `/gsd-lean:complete`." Stop.

### Step 3: Update Task Status

If the task is `pending`, update its status to `in-progress` in the cycle/PLAN.md summary table.
If this is the first task being executed (plan status is `verified`), update the plan Status header to `in-progress`.

### Step 4: Read Task Details

Read the Task Details section for the target task in `.planning/cycle/PLAN.md`. Extract:
- **Description** — what to implement
- **Files** — files to create/modify (with actions)
- **Verification** — checklist items
- **Dependencies** — prerequisite tasks (should already be `done`)

Also read:
- `CLAUDE.md` — project commands, code style, conventions
- `.planning/PROJECT.md` — stack, constraints
- `.planning/CONTEXT.md` — static architecture, tooling, skills context

### Step 5: Read Subagent Config

Read `.planning/config.yaml` if it exists. For each subagent spawned below, resolve `model` and `max_turns`:

| Subagent | Config key |
|----------|------------|
| executor | `skills.execute.subagents.executor` |
| auto-debug | `skills.execute.subagents.auto-debug` |
| verify | `skills.execute.subagents.verify` |

Fallback to `defaults` section, then omit parameters (inherit from session).

### Step 6: Spawn Executor Subagent

Use the Task tool to spawn an executor subagent with `subagent_type=general-purpose`. If config was loaded, also pass `model` and `max_turns` from the resolved config for `skills.execute.subagents.executor`. Omit any parameter that is null/unset.

Read the prompt template from `references/executor-subagent-prompt.md`. Fill in placeholders (`{task_id}`, `{task_title}`, `{task_description}`, `{files_list}`, `{verification_checklist}`) from task details, then pass the filled prompt to the subagent.

### Step 7: Collect Changed Files

Parse the executor subagent output for the list of files it changed. Store this as `{changed_files}` — it will be passed to the verify subagent so it stages only these files (not unrelated user changes).

### Step 8: Verify

After the executor subagent completes, spawn a **verify subagent** using the Task tool with `subagent_type=general-purpose`. If config was loaded, also pass `model` and `max_turns` from the resolved config for `skills.execute.subagents.verify`. Omit any parameter that is null/unset.

Read the prompt template from `references/verify-subagent-prompt.md`. Fill in placeholders (`{task_id}`, `{task_title}`, `{changed_files}`, `{verification_checklist}`) from task details and Step 7 output, then pass the filled prompt to the subagent.

Parse the verification result for PASS/FAIL.

### Step 9: Handle Verification Result

**If PASS:**
1. Parse the verify subagent output. Confirm it includes "Plan Updated" and a commit hash (or "nothing to commit").
2. If the subagent failed to update PLAN.md or commit, fall back:
   - Update task status to `done` in `cycle/PLAN.md` summary table
   - Tick all `- [ ]` to `- [x]` in the Task Details section for this task
   - Stage only files changed by executor/auto-debug subagents, then commit with conventional message and footer (do **NOT** use `git add -A`)
3. Go to Step 11

**If FAIL:**
1. Capture the error output from the verify subagent
2. Identify which files were touched by the executor subagent
3. Go to Step 10

### Step 10: Auto-Debug

Spawn an auto-debug subagent with `subagent_type=general-purpose`. If config was loaded, also pass `model` and `max_turns` from the resolved config for `skills.execute.subagents.auto-debug`. Omit any parameter that is null/unset.

Read the prompt template from `references/auto-debug-subagent-prompt.md`. Fill in placeholders (`{task_id}`, `{task_title}`, `{task_description}`, `{error_output}`, `{touched_files}`) from task details and verification output, then pass the filled prompt to the subagent.

After the auto-debug subagent completes, merge its modified files into `{changed_files}`, then re-run Step 8 (spawn verify subagent again with the updated file list).

**If PASS:** Go to Step 9 (PASS path).

**If still FAIL:**
1. Report the diagnosis: root cause + what was tried + remaining errors
2. Task stays `in-progress`
3. Ask user: "Auto-debug failed. Would you like to fix manually, skip this task, or retry?"
4. Stop the loop — do not proceed to the next task

### Step 11: Check for More Tasks

**If target set was defined:**
1. Check if any tasks in target set still `pending` or `in-progress`
2. If yes → print "Task {task_id} complete. {remaining} target tasks remaining. Continuing..." → loop to Step 2
3. If no → print "All specified tasks complete: {IDs}." Stop. Do NOT update Status header.

**If no target set:**
1. Check for more `pending` tasks in cycle/PLAN.md
2. If yes → print "Task {task_id} complete. {remaining} tasks remaining. Continuing..." → loop to Step 2
3. If no → update Status header to `complete`. Print "All tasks complete. Run `/gsd-lean:complete` to finish the workflow."

## Additional Resources

### Reference Files

Subagent prompt templates (read and fill placeholders before passing to Task tool):
- **`references/executor-subagent-prompt.md`** — Executor subagent prompt; fill `{task_id}`, `{task_title}`, `{task_description}`, `{files_list}`, `{verification_checklist}`
- **`references/verify-subagent-prompt.md`** — Verify subagent prompt; fill `{task_id}`, `{task_title}`, `{changed_files}`, `{verification_checklist}`
- **`references/auto-debug-subagent-prompt.md`** — Auto-debug subagent prompt; fill `{task_id}`, `{task_title}`, `{task_description}`, `{error_output}`, `{touched_files}`
