from gsd_lean.cli.app import main

__all__ = ['main']
