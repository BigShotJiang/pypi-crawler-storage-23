"""Installer utilities for deploying GSD-Lean hooks into consumer projects."""

import importlib.resources
import json
import stat
from pathlib import Path
from typing import Any

SETTINGS_REL = Path('.claude', 'settings.json')
HOOK_REL = Path('.claude', 'hooks', 'gsd-lean-statusline.sh')
BUNDLED_SCRIPT = 'data/gsd-lean-statusline.sh'


def install_statusline(root: Path, *, force: bool = False) -> list[str]:
    """Install the GSD-Lean statusline hook into a project.

    Copies the bundled statusline script to ``.claude/hooks/`` and configures
    ``statusLine`` in ``.claude/settings.json``.

    Args:
        root: Project root directory.
        force: Overwrite existing statusline configuration.

    Returns:
        List of human-readable action descriptions.
    """
    actions: list[str] = []

    settings_path = root / SETTINGS_REL
    settings: dict[str, Any] = {}

    if settings_path.exists():
        settings = json.loads(settings_path.read_text())

    # Always copy bundled script
    hook_path = root / HOOK_REL
    hook_path.parent.mkdir(parents=True, exist_ok=True)

    script_content = importlib.resources.files('gsd_lean').joinpath(BUNDLED_SCRIPT).read_text()
    hook_path.write_text(script_content)
    hook_path.chmod(hook_path.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    actions.append(f'copied {HOOK_REL}')

    # Configure settings.json only if no existing statusline (or force)
    if 'statusLine' in settings and not force:
        actions.append(f"statusline already configured — {HOOK_REL} available if you'd like to switch")
        return actions

    settings_path.parent.mkdir(parents=True, exist_ok=True)
    settings['statusLine'] = {
        'type': 'command',
        'command': str(HOOK_REL),
    }
    settings_path.write_text(json.dumps(settings, indent=2) + '\n')
    actions.append(f'configured statusLine in {SETTINGS_REL}')

    return actions
