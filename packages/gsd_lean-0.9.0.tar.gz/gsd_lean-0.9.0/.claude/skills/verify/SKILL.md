---
description: Verify recent work (lint + format + typecheck + tests)
allowed-tools: Bash(make ruff), Bash(make pyright), Bash(make run-tests), Bash(make run-tests-cov), Bash(git diff:*)
---

## Changes to Verify

**Changed files (uncommitted):**
```
!`git diff --name-only HEAD 2>/dev/null || echo "No changes"`
```

**Changed files (last commit):**
```
!`git diff --name-only HEAD~1 2>/dev/null || echo "No previous commit"`
```

## Verification Steps

Run each verification step and report results:

1. **Ruff linter + formatter**: `make ruff`
2. **Pyright typechecker**: `make pyright`
3. **Tests + coverage**: `make run-tests-cov`

## Instructions

1. Run each command above sequentially
2. For each step, report:
   - PASS if no errors
   - FAIL with file paths and error messages if errors found
3. Summarize: "X/3 checks passed" at the end
4. If all pass, say "Ready to commit"
5. If any fail, list specific files and errors to fix

## Troubleshooting

1. Docker sandbox runs might encounter I/O error when running `make run-tests-cov` due to a flaky sandbox filestystem issue. To resolve, run tests without parallel workers: `uv run pytest --cov=src tests`
