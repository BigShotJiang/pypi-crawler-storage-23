---
description: Create a git commit with pre-computed context
argument-hint: [additional context]
allowed-tools: Bash(git status:*), Bash(git diff:*), Bash(git log:*), Bash(git add:*), Bash(git commit:*), Bash(git branch:*)
---

## Current Context

**Branch:** !`git branch --show-current`

**Status:**
```
!`git status --porcelain`
```

**Staged changes:**
```
!`git diff --cached --stat`
```

**Unstaged changes:**
```
!`git diff --stat`
```

**Recent commits (for style reference):**
```
!`git log --oneline -5`
```

## Instructions

Based on the context above:

1. Check branch: If on `main`, warn user and ask to create feature branch first
2. If there are unstaged changes that should be committed, stage them with `git add`
3. Create a commit following conventional commit style. If provided, take the additional context from user into account. Provided context: "$ARGUMENTS"
4. Use the recent commits as style reference
5. Keep the message concise (1-2 sentences max)
6. End the commit message with:

```
[Generated with Claude Code](https://claude.com/claude-code)

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>
```

If there are no changes to commit, inform the user.
