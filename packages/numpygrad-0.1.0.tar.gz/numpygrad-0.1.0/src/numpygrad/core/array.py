from typing import Any

import numpy as np

from numpygrad.core.device import DeviceId
from numpygrad.core.dispatch import dispatch
from numpygrad.core.opid import OperatorId
from numpygrad.core.version import VersionCounter

type ArrayCoercible = "np.ndarray | int | float | \
list[int | float] | tuple[int | float] | Array | tuple[int, ...] | \
list[list[int | float]] | list[tuple[int | float]]"


class Array:
    def __init__(
        self,
        data: ArrayCoercible,
        *,
        device: DeviceId | str = "cpu_np",
        requires_grad: bool = False,
        label: str = "",
        dtype: np.dtype | None = None,
        version_counter: VersionCounter | None = None,
    ):
        if isinstance(data, (int, float)):
            data = np.array(data)
        elif isinstance(data, (list, tuple)):
            data = np.array(data)
        elif isinstance(data, np.ndarray):
            pass
        elif isinstance(data, Array):
            # Unwrap so self.data is always ndarray and zeros_like(grad) gets
            # correct shape
            data = data.data

        self.data: np.ndarray = data  # type: ignore
        if dtype is not None:
            self.data = self.data.astype(dtype)

        self._version_counter: VersionCounter = (
            version_counter if version_counter is not None else VersionCounter()
        )
        self.device: DeviceId = DeviceId(device)

        if self.dtype != np.float32 and self.dtype != np.float64 and requires_grad:
            raise ValueError("Only arrays of floating point dtype can require gradients")
        self.requires_grad = requires_grad
        self.grad = np.zeros_like(self.data) if requires_grad else None

        self.grad_fn = None
        self.ctx = None
        self.parents = ()
        self.label = label

    @property
    def _version(self) -> int:
        return self._version_counter.version

    def numpy(self) -> np.ndarray:
        return self.data

    @property
    def shape(self) -> tuple[int, ...]:
        return self.data.shape

    @property
    def ndim(self) -> int:
        return self.data.ndim

    @property
    def dtype(self) -> np.dtype:
        return self.data.dtype

    @property
    def nbytes(self) -> int:
        return self.data.nbytes

    @property
    def size(self) -> int:
        return self.data.size

    @property
    def itemsize(self) -> int:
        return self.data.itemsize

    @property
    def strides(self) -> tuple[int, ...]:
        return self.data.strides

    def item(self) -> float:
        return self.data.item()

    def __repr__(self) -> str:
        out = f"Array(data={self.data}"
        if self.requires_grad:
            out += ", requires_grad=True"
            if self.grad_fn is not None:
                out += f", grad_fn={self.grad_fn.__name__}"
        if self.label != "":
            out += f", label={self.label}"
        out += ")"
        return out

    def __getitem__(self, key) -> "Array":
        return dispatch(OperatorId.SLICE, self, key=key)

    def __setitem__(
        self, key: "ArrayCoercible | slice | tuple[slice, ...]", value: ArrayCoercible
    ) -> None:
        from numpygrad.ops.core import ensure_array  # local import to avoid circular dependency
        from numpygrad.ops.transforms import normalize_key

        self.data[normalize_key(key)] = ensure_array(value).data
        self._version_counter.increment()

    def setitem(self, key: "ArrayCoercible | slice | tuple[slice, ...]", value: ArrayCoercible):
        return dispatch(OperatorId.SETITEM, self, key, value)

    def masked_fill(self, mask: "Array", value: float | int) -> "Array":
        return dispatch(OperatorId.MASKED_FILL, self, mask, value)

    def __gt__(self, other: ArrayCoercible) -> "Array":
        return dispatch(OperatorId.GT, self, other)

    def __lt__(self, other: ArrayCoercible) -> "Array":
        return dispatch(OperatorId.LT, self, other)

    def __ge__(self, other: ArrayCoercible) -> "Array":
        return dispatch(OperatorId.GE, self, other)

    def __le__(self, other: ArrayCoercible) -> "Array":
        return dispatch(OperatorId.LE, self, other)

    def __eq__(self, other: ArrayCoercible) -> "Array":  # type: ignore
        return dispatch(OperatorId.EQ, self, other)

    def __ne__(self, other: ArrayCoercible) -> "Array":  # type: ignore
        return dispatch(OperatorId.NE, self, other)

    def __mul__(self, other: ArrayCoercible) -> "Array":
        return dispatch(OperatorId.MUL, self, other)

    def __add__(self, other: ArrayCoercible) -> "Array":
        return dispatch(OperatorId.ADD, self, other)

    def __rmul__(self, other: ArrayCoercible) -> "Array":
        return dispatch(OperatorId.MUL, self, other)

    def __neg__(self) -> "Array":
        return self * -1.0

    def __sub__(self, other):
        return self + (-other)

    def __pow__(self, other: ArrayCoercible) -> "Array":
        return dispatch(OperatorId.POW, self, other)

    def __truediv__(self, other: "int | float | Array | np.ndarray") -> "Array":
        return self * other**-1

    def __matmul__(self, other: ArrayCoercible) -> "Array":
        return dispatch(OperatorId.MATMUL, self, other)

    def sum(self, axis=None, keepdims=False) -> "Array":
        return dispatch(OperatorId.SUM, self, axis=axis, keepdims=keepdims)

    def exp(self) -> "Array":
        return dispatch(OperatorId.EXP, self)

    def log(self) -> "Array":
        return dispatch(OperatorId.LOG, self)

    def abs(self) -> "Array":
        return dispatch(OperatorId.ABS, self)

    def transpose(self, *axes) -> "Array":
        if len(axes) == 2 and all(isinstance(a, int) for a in axes):
            # PyTorch-style: swap two dims, generate the full permutation
            ndim = self.ndim
            perm = list(range(ndim))
            d0, d1 = axes[0] % ndim, axes[1] % ndim
            perm[d0], perm[d1] = perm[d1], perm[d0]
            axes_ = tuple(perm)
        elif len(axes) == 1 and isinstance(axes[0], (tuple, list)):
            axes_ = tuple(axes[0])
        else:
            axes_ = axes
        return dispatch(OperatorId.TRANSPOSE, self, axes=axes_)

    def permute(self, *dims) -> "Array":
        return self.transpose(*dims)

    def reshape(self, *new_shape) -> "Array":
        shape = (
            new_shape[0]
            if len(new_shape) == 1 and isinstance(new_shape[0], (tuple, list))
            else new_shape
        )
        return dispatch(OperatorId.RESHAPE, self, new_shape=shape)

    def view(self, *shape) -> "Array":
        new_shape = shape[0] if len(shape) == 1 and isinstance(shape[0], (tuple, list)) else shape
        return self.reshape(new_shape)

    def mean(self, axis: tuple[int, ...] | int | None = None, keepdims: bool = False) -> "Array":
        return dispatch(OperatorId.MEAN, self, axis=axis, keepdims=keepdims)

    def max(self, axis: int | None = None, keepdims: bool = False) -> "Array":
        return dispatch(OperatorId.MAX, self, axis=axis, keepdims=keepdims)

    def min(self, axis: int | None = None, keepdims: bool = False) -> "Array":
        return dispatch(OperatorId.MIN, self, axis=axis, keepdims=keepdims)

    def prod(self, axis: int | None = None, keepdims: bool = False) -> "Array":
        return dispatch(OperatorId.PRODUCT, self, axis=axis, keepdims=keepdims)

    def argmax(self, axis: int | None = None, keepdims: bool = False) -> "Array":
        return dispatch(OperatorId.ARGMAX, self, axis=axis, keepdims=keepdims)

    # --- simple wrappers (no autograd) ---

    def tolist(self) -> list:
        return self.data.tolist()

    def nonzero(self) -> tuple["Array", ...]:
        return tuple(Array(idx) for idx in np.nonzero(self.data))

    def astype(self, dtype) -> "Array":
        new_data = self.data.astype(dtype)
        is_float = np.issubdtype(new_data.dtype, np.floating)
        return Array(new_data, device=self.device, requires_grad=self.requires_grad and is_float)

    def all(self, axis=None, keepdims: bool = False) -> "Array":
        return Array(np.all(self.data, axis=axis, keepdims=keepdims))

    def any(self, axis=None, keepdims: bool = False) -> "Array":
        return Array(np.any(self.data, axis=axis, keepdims=keepdims))

    def fill(self, value) -> None:
        self.data.fill(value)
        self._version_counter.increment()

    def sort(self, axis: int = -1) -> None:
        self.data.sort(axis=axis)
        self._version_counter.increment()

    def round(self, decimals: int = 0) -> "Array":
        return Array(np.round(self.data, decimals=decimals), device=self.device)

    def triu(self, x: ArrayCoercible, k: int = 0) -> "Array":
        return dispatch(OperatorId.TRIU, self, x, k=k)

    # --- compositions of existing differentiable ops ---

    def std(self, axis=None, ddof: int = 0, keepdims: bool = False) -> "Array":
        return self.var(axis=axis, ddof=ddof, keepdims=keepdims) ** 0.5

    def trace(self, offset: int = 0) -> "Array":
        return self.diagonal(offset=offset).sum()

    # --- new differentiable ops ---

    def squeeze(self, axis=None) -> "Array":
        return dispatch(OperatorId.SQUEEZE, self, axis=axis)

    def repeat(self, repeats: int, axis=None) -> "Array":
        return dispatch(OperatorId.REPEAT, self, repeats=repeats, axis=axis)

    def diagonal(self, offset: int = 0, axis1: int = 0, axis2: int = 1) -> "Array":
        return dispatch(OperatorId.DIAGONAL, self, offset=offset, axis1=axis1, axis2=axis2)

    def cumsum(self, axis=None) -> "Array":
        return dispatch(OperatorId.CUMSUM, self, axis=axis)

    def cumprod(self, axis=None) -> "Array":
        return dispatch(OperatorId.CUMPROD, self, axis=axis)

    def var(self, axis=None, ddof: int = 0, keepdims: bool = False) -> "Array":
        return dispatch(OperatorId.VAR, self, axis=axis, ddof=ddof, keepdims=keepdims)

    def sqrt(self) -> "Array":
        return self**0.5

    def split(self, split_size_or_sections: "int | list[int]", dim: int = 0) -> "tuple[Array, ...]":
        from numpygrad.ops.transforms import split as _split

        return _split(self, split_size_or_sections, dim=dim)

    @property
    def T(self) -> "Array":
        return self.transpose(tuple(reversed(range(self.ndim))))

    def backward(self, grad: np.ndarray | None = None) -> None:
        if grad is None:
            grad = np.ones_like(self.data)

        # build topo order (iterative post-order DFS — avoids recursive closure cycles)
        topo = []
        visited: set[int] = set()
        stack: list[tuple[Any, bool]] = [(self, False)]
        while stack:
            node, processed = stack.pop()
            if processed:
                topo.append(node)
            elif id(node) not in visited:
                visited.add(id(node))
                stack.append((node, True))
                for parent in getattr(node, "parents", ()):
                    if id(parent) not in visited:
                        stack.append((parent, False))

        # seed gradient
        self.grad = grad

        # backward pass
        for node in reversed(topo):
            if getattr(node, "grad_fn", None) is None:
                continue

            grads = node.grad_fn.backward(node.ctx, node.grad)

            for parent, parent_grad in zip(node.parents, grads, strict=False):
                if getattr(parent, "requires_grad", False):
                    parent.grad += parent_grad
