from yta_constants.enum import YTAEnum as Enum


class TransitionMode(Enum):
    """
    The modes the TransitionTrackItem accept as mode to
    implement it, that is the way you handle the frames
    of the previous and the next clip.
    """

    TRIM = 'trim'
    """
    The transition will use the real frames of both the
    previous and the next clip, which will make both 
    clips last less time.

    It means that from:
    - `[ClipA] [Gap] [ClipB]`
    We will move to:
    - `[ClipA_trimmed] [Transition] [ClipB_trimmed]`
    """
    FREEZE_TAIL = 'freeze_tail'
    """
    The transition will use the last frame of the 
    previous clip but frozen, which means that it will
    be used for the whole transition duration. The next
    clip 'start' time moment will be increased because
    the previous clip is not trimmed and the transition
    will last an additional amount of time.

    It means that from:
    - `[ClipA] [Gap] [ClipB]`
    We will move to:
    - `[ClipA] [Transition] [ClipB_delayed]`
    """
    FREEZE_HEAD = 'freeze_head'
    """
    The transition will use the first frame of the next
    clip but frozen, which means that it will be used
    for the whole transition duration. The next clip
    'start' time moment will be increased because the
    previous clip is not trimmed and the transition will
    last an additional amount of time.

    It means that from:
    - `[ClipA] [Gap] [ClipB]`
    We will move to:
    - `[ClipA] [Transition] [ClipB_delayed]`
    """
    FREEZE_BOTH = 'freeze_both'
    """
    The transition will use the last frame of the
    previous clip and the first frame of the next one,
    but frozen, which means that they will be used for
    the whole transition duration. The next clip 'start'
    time moment will be increased because the previous
    clip is not trimmed and the transition will last an
    additional amount of time.

    It means that from:
    - `[ClipA] [Gap] [ClipB]`
    We will move to:
    - `[ClipA] [Transition] [ClipB_delayed]`
    """