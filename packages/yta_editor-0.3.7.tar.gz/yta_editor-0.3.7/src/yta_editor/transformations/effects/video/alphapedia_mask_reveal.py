from yta_editor.media.video import VideoFileMedia
from yta_editor.transformations.effects.abstract import EffectParameters
from yta_editor.transformations.effects.video import VideoEffect
from yta_editor_nodes.processor.video.alphapedia_mask_reveal import AlphaPediaMaskRevealVideoNodeProcessor
from yta_editor_time.evaluation_context import EvaluationContext
from yta_editor_parameters.abstract import VideoEditorParameter
from yta_editor_parameters import ConstantVideoEditorParameter
from yta_validation.parameter import ParameterValidator
from yta_validation import PythonValidator
from typing import Union
from dataclasses import dataclass


# TODO: We need to define all the specific effect
# params to be able to build them properly missing
# no fields
@dataclass
class AlphaPediaMaskRevealVideoEffectParameters(EffectParameters):
    """
    The parameters to use when applying this effect
    that reveals a video with an alpha pedia mask for
    a specific `evaluation_context`.

    This will be returned by the effect when
    calculated, for a specific `evaluation_context`.
    """

    def __init__(
        self,
        mask_frame: Union['np.ndarray', 'moderngl.Texture']
    ):
        # TODO: Add doc
        self.mask_frame: Union['np.ndarray', 'moderngl.Texture'] = mask_frame
        """
        The frame that must be used to be applied as
        the mask frame.
        """
        

class AlphaPediaMaskRevealVideoEffect(VideoEffect):
    """
    The effect that will modify the video by
    revealing it with an alpha video mask according
    to the provided conditions.
    """

    def __init__(
        self,
        mask_input_filename: str,
        do_use_gpu: bool = True
    ):
        self.do_use_gpu: bool = do_use_gpu
        """
        Flag to indicate if using GPU or not.
        """
        # TODO: This is a bit stupid, storing it like this
        self.mask_input_filename: VideoEditorParameter = ConstantVideoEditorParameter(mask_input_filename)
        """
        The `VideoEditorParameter` that defines the value that
        should be applied as the mask video filename to extract
        the frame to be applied for the specific
        `evaluation_context`.
        """

    def _get_params_at(
        self,
        evaluation_context: EvaluationContext
    ) -> AlphaPediaMaskRevealVideoEffectParameters:
        """
        *For internal use only*

        Get the parameters that must be applied at the given
        `evaluation_context`.
        """
        ParameterValidator.validate_mandatory_instance_of('evaluation_context', evaluation_context, EvaluationContext)

        # TODO: This is repeated in the 'transition_calculator.py'
        mask_video = VideoFileMedia(
            filename = self.mask_input_filename.evaluate(evaluation_context)
        )

        """
        TODO: Important failure here below:
        This media doesn't have the '.number_of_frames', which
        is read from the source. I created the following Notion
        task to review it, but by now we are calculating it:
        - https://www.notion.so/Source-sin-number_of_frames-318f5a32d46280279b0ce05afe909a68?v=2caf5a32d46281c5b6fd000c350fcc72&source=copy_link
        """
        mask_video_number_of_frames = int(mask_video.duration * mask_video.fps)
        t_transition_media = evaluation_context.progress.value * (mask_video_number_of_frames - 1) / mask_video.fps

        video_frame = mask_video.get_video_frame_at(
            t_media = t_transition_media
        ).to_ndarray(format = 'rgba')
        
        video_frame = (
            video_frame.frame
            if PythonValidator.is_instance_of(video_frame, 'VideoFrame') else
            video_frame
        )

        return AlphaPediaMaskRevealVideoEffectParameters(
            mask_frame = video_frame
        )
    
    def _apply(
        self,
        # TODO: Set the type
        frame: any,
        output_size: Union[tuple[int, int], None],
        evaluation_context: EvaluationContext
    # TODO: Set the type
    ) -> any:
        parameters = self._get_params_at(
            evaluation_context = evaluation_context
        )

        return AlphaPediaMaskRevealVideoNodeProcessor(
            # TODO: What do I do with the 'opengl_context' (?)
            opengl_context = None
        ).process(
            inputs = {
                'base_input': frame,
                'mask_input': parameters.mask_frame
            },
            evaluation_context = evaluation_context,
            do_use_gpu = self.do_use_gpu,
            output_size = output_size,
        )