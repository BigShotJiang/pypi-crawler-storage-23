#!/usr/bin/env python3

from datetime import datetime
from pathlib import Path
import typer
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from aiohttp import ClientResponse
from nssurge_api.api import SurgeAPIClient
from nssurge_api.types import (
    Capability,
)


def strtobool(val: str) -> bool:
    """Convert a string representation of truth to True or False.

    True values are 'y', 'yes', 't', 'true', 'on', and '1';
    False values are 'n', 'no', 'f', 'false', 'off', and '0'.
    Raises ValueError if 'val' is anything else.
    """
    val_lower = val.lower()
    if val_lower in ("y", "yes", "t", "true", "on", "1"):
        return True
    elif val_lower in ("n", "no", "f", "false", "off", "0"):
        return False
    else:
        raise ValueError(f"Invalid truth value: {val!r}")


def s2b(s: str) -> bool:
    return bool(strtobool(s))


async def parse_cap_get(resp: "ClientResponse") -> bool:
    if not resp.status == 200:
        raise ValueError(f"Unexpected status code: {resp.status}")
    return (await resp.json())["enabled"]


async def get_cap_state(client: SurgeAPIClient, capability: Capability) -> bool:
    get_resp = await client.get_cap(capability)
    orig_state = await parse_cap_get(get_resp)
    return orig_state


def bool2color(state: bool) -> str:
    if state:
        color = typer.colors.GREEN
    else:
        color = typer.colors.RED
    return color


def use_local_nssurge_api_module():
    import sys

    sys.path.insert(0, str(Path.home() / "testdir" / "nssurge-api"))
    print(sys.path)


def _truncate(value: Any, max_len: int = 96) -> str:
    text = str(value)
    if len(text) <= max_len:
        return text
    return text[: max_len - 1] + "…"


def _human_bytes(value: Any) -> str:
    if not isinstance(value, (int, float)):
        return _truncate(value)
    units = ["B", "KB", "MB", "GB", "TB"]
    size = float(value)
    unit_idx = 0
    while size >= 1024 and unit_idx < len(units) - 1:
        size /= 1024
        unit_idx += 1
    if unit_idx == 0:
        return f"{int(size)} {units[unit_idx]}"
    return f"{size:.2f} {units[unit_idx]}"


def _format_epoch(value: Any) -> str:
    if not isinstance(value, (int, float)) or value <= 0:
        return "-"
    return datetime.fromtimestamp(value).strftime("%Y-%m-%d %H:%M:%S")


def _print_table(title: str, columns: list[str], rows: list[list[Any]]) -> None:
    from rich.console import Console
    from rich.table import Table

    console = Console()
    table = Table(title=title)
    for column in columns:
        table.add_column(column)
    for row in rows:
        table.add_row(*[str(item) for item in row])
    if not rows:
        table.add_row(*(["-"] * len(columns)))
    console.print(table)


def _render_events_table(data: dict[str, Any]) -> None:
    events = data.get("events", [])
    rows: list[list[Any]] = []
    for event in events[:200]:
        rows.append(
            [
                event.get("date", "-"),
                event.get("type", "-"),
                _truncate(event.get("identifier", "-"), 40),
                _truncate(event.get("content", "-"), 96),
            ]
        )
    _print_table("Events", ["Date", "Type", "Identifier", "Content"], rows)


def _render_rules_table(data: dict[str, Any]) -> None:
    policies = data.get("available-policies", [])
    policy_rows = [[idx + 1, policy] for idx, policy in enumerate(policies)]
    _print_table("Available Policies", ["#", "Policy"], policy_rows)

    rules = data.get("rules", [])
    max_rows = 200
    rule_rows = [
        [idx + 1, _truncate(rule, 140)] for idx, rule in enumerate(rules[:max_rows])
    ]
    _print_table(
        f"Rules (showing {min(len(rules), max_rows)} / {len(rules)})",
        ["#", "Rule"],
        rule_rows,
    )


def _render_traffic_tables(data: dict[str, Any]) -> None:
    interfaces: dict[str, Any] = data.get("interface", {})
    interface_rows: list[list[Any]] = []
    for name, stats in interfaces.items():
        interface_rows.append(
            [
                name,
                _human_bytes(stats.get("inCurrentSpeed", 0)) + "/s",
                _human_bytes(stats.get("outCurrentSpeed", 0)) + "/s",
                _human_bytes(stats.get("in", 0)),
                _human_bytes(stats.get("out", 0)),
            ]
        )
    _print_table(
        "Traffic by Interface",
        ["Interface", "In Speed", "Out Speed", "In Total", "Out Total"],
        interface_rows,
    )

    connectors: dict[str, Any] = data.get("connector", {})
    connector_rows: list[list[Any]] = []
    for name, stats in list(connectors.items())[:200]:
        connector_rows.append(
            [
                _truncate(name, 36),
                _human_bytes(stats.get("inCurrentSpeed", 0)) + "/s",
                _human_bytes(stats.get("outCurrentSpeed", 0)) + "/s",
                _human_bytes(stats.get("in", 0)),
                _human_bytes(stats.get("out", 0)),
            ]
        )
    _print_table(
        f"Traffic by Connector (showing {min(len(connectors), 200)} / {len(connectors)})",
        ["Connector", "In Speed", "Out Speed", "In Total", "Out Total"],
        connector_rows,
    )


def _render_policy_table(data: dict[str, Any]) -> None:
    rows: list[list[Any]] = []
    for proxy in data.get("proxies", []):
        rows.append(["Proxy", proxy])
    for group in data.get("policy-groups", []):
        rows.append(["Policy Group", group])
    _print_table("Policies", ["Type", "Name"], rows)


def _render_requests_table(data: dict[str, Any]) -> None:
    requests = data.get("requests", [])
    rows: list[list[Any]] = []
    for request in requests[:200]:
        process_name = Path(request.get("processPath", "")).name
        rows.append(
            [
                request.get("id", "-"),
                request.get("status", "-"),
                request.get("method", "-"),
                _truncate(request.get("policyName", "-"), 24),
                _truncate(request.get("rule", "-"), 28),
                _human_bytes(request.get("inBytes", 0)),
                _human_bytes(request.get("outBytes", 0)),
                _truncate(process_name, 28),
                _truncate(request.get("URL", "-"), 50),
            ]
        )
    _print_table(
        f"Requests (showing {min(len(requests), 200)} / {len(requests)})",
        [
            "ID",
            "Status",
            "Method",
            "Policy",
            "Rule",
            "In",
            "Out",
            "Process",
            "URL",
        ],
        rows,
    )


def _render_dns_table(data: dict[str, Any]) -> None:
    local = data.get("local", [])
    local_rows: list[list[Any]] = []
    for record in local[:200]:
        local_rows.append(
            [
                record.get("domain", "-"),
                record.get("data", "-"),
                record.get("source", "-"),
                _truncate(record.get("comment", "-"), 32),
            ]
        )
    _print_table(
        f"DNS Local Records (showing {min(len(local), 200)} / {len(local)})",
        ["Domain", "Data", "Source", "Comment"],
        local_rows,
    )

    cache = data.get("dnsCache", [])
    cache_rows: list[list[Any]] = []
    for record in cache[:200]:
        resolved_data = record.get("data", "-")
        if isinstance(resolved_data, list):
            resolved_data = ", ".join(resolved_data)
        cache_rows.append(
            [
                _truncate(record.get("domain", "-"), 48),
                _truncate(resolved_data, 48),
                record.get("server", "-"),
                f"{float(record.get('timeCost', 0)) * 1000:.1f} ms",
                _format_epoch(record.get("expiresTime", 0)),
            ]
        )
    _print_table(
        f"DNS Cache (showing {min(len(cache), 200)} / {len(cache)})",
        ["Domain", "Data", "Server", "Time Cost", "Expires"],
        cache_rows,
    )


def _render_modules_table(data: dict[str, Any]) -> None:
    enabled_set = set(data.get("enabled", []))
    rows = []
    for module in data.get("available", []):
        rows.append([module, "Yes" if module in enabled_set else "No"])
    _print_table("Modules", ["Module", "Enabled"], rows)


def _render_scripts_table(data: dict[str, Any]) -> None:
    scripts = data.get("scripts", [])
    if not scripts:
        _print_table("Scripts", ["Info"], [["No scripts"]])
        return

    first = scripts[0]
    if isinstance(first, dict):
        preferred_keys = ["name", "type", "event", "enabled", "result"]
        keys = [key for key in preferred_keys if key in first]
        for key in first:
            if key not in keys:
                keys.append(key)
            if len(keys) >= 8:
                break
        rows = [
            [_truncate(script.get(key, "-"), 48) for key in keys]
            for script in scripts[:200]
        ]
        _print_table(
            f"Scripts (showing {min(len(scripts), 200)} / {len(scripts)})",
            keys,
            rows,
        )
        return

    rows = [[_truncate(script, 120)] for script in scripts[:200]]
    _print_table(
        f"Scripts (showing {min(len(scripts), 200)} / {len(scripts)})",
        ["Script"],
        rows,
    )


def _render_devices_table(data: dict[str, Any]) -> None:
    devices = data.get("devices", [])
    rows: list[list[Any]] = []
    for device in devices[:200]:
        rows.append(
            [
                _truncate(device.get("name", "-"), 24),
                _truncate(device.get("identifier", "-"), 22),
                device.get("displayIPAddress", "-"),
                _human_bytes(device.get("currentSpeed", 0)) + "/s",
                _human_bytes(device.get("totalBytes", 0)),
                device.get("activeConnections", 0),
                _truncate(device.get("vendor", "-"), 22),
            ]
        )
    _print_table(
        f"Devices (showing {min(len(devices), 200)} / {len(devices)})",
        [
            "Name",
            "Identifier",
            "IP",
            "Speed",
            "Total",
            "Active",
            "Vendor",
        ],
        rows,
    )


def _render_profiles_table(data: dict[str, Any]) -> None:
    if "profiles" in data and isinstance(data["profiles"], list):
        rows = [[idx + 1, profile] for idx, profile in enumerate(data["profiles"])]
        _print_table("Profiles", ["#", "Profile"], rows)
        return

    rows = [
        ["name", data.get("name", "-")],
        ["originalProfile bytes", len(str(data.get("originalProfile", "")))],
        ["profile bytes", len(str(data.get("profile", "")))],
    ]
    _print_table("Active Profile", ["Field", "Value"], rows)


def _render_generic_table(data: dict[str, Any]) -> None:
    rows = [[str(key), _truncate(value, 140)] for key, value in data.items()]
    _print_table("Result", ["Key", "Value"], rows)


def _render_as_rich_table(data: Any) -> None:
    if not isinstance(data, dict):
        from rich.console import Console

        Console().print(data)
        return

    keys = set(data.keys())
    if keys == {"events"}:
        _render_events_table(data)
    elif keys == {"available-policies", "rules"}:
        _render_rules_table(data)
    elif keys == {"connector", "interface", "startTime"}:
        _render_traffic_tables(data)
    elif keys == {"proxies", "policy-groups"}:
        _render_policy_table(data)
    elif keys == {"requests"}:
        _render_requests_table(data)
    elif keys == {"dnsCache", "local"}:
        _render_dns_table(data)
    elif keys == {"available", "enabled"}:
        _render_modules_table(data)
    elif keys == {"scripts"}:
        _render_scripts_table(data)
    elif keys == {"devices"}:
        _render_devices_table(data)
    elif keys == {"profiles"} or keys == {"name", "originalProfile", "profile"}:
        _render_profiles_table(data)
    else:
        _render_generic_table(data)


def typer_output_dict(
    d: dict,
    output_json: bool = False,
    pretty_print: bool = False,
    rich_print: bool = False,
    plain_python_object: bool = False,
) -> None:
    if output_json:
        import json

        typer.secho(json.dumps(d, indent=2, ensure_ascii=False))
    elif pretty_print:
        from pprint import PrettyPrinter

        pp = PrettyPrinter(indent=2)
        typer.secho(pp.pformat(d))
    elif plain_python_object:
        typer.secho(d)
    else:
        _ = rich_print
        _render_as_rich_table(d)


# typer_output_dict_typer_options = (    output_json: bool = typer.Option(False, "--json", "-j"),
#     pretty_print: bool = typer.Option(False, "--pretty", "-p"),)
rich_print: bool = (typer.Option(False, "--rich", "-r"),)  # type: ignore
