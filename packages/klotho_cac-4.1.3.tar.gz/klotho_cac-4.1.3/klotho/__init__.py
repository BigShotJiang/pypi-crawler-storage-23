"""
Klotho: A comprehensive toolkit for computational music.

From the Greek "Κλωθώ" (Klotho), one of the three Fates who spins the thread of life.
This library weaves together various aspects of musical computation.

Submodules:
- topos:   Abstract mathematical and structural foundations
- chronos: Temporal and rhythm structures
- tonos:   Tonal systems, pitches, scales, and harmony
- dynatos: Expression, dynamics, and envelopes
- thetos:  Compositional parameters and instrumentation
- semeios: Visualization, notation, and representation
- utils:   General utilities and helper functions
"""
from . import topos
from . import chronos
from . import tonos
from . import dynatos
from . import thetos
from . import semeios
from . import utils

from .topos.graphs import Graph, Tree, Lattice, Group
from .topos.collections import Pattern, CombinationSet, PartitionSet

from .chronos import RhythmPair, RhythmTree, TemporalUnit, TemporalUnitSequence, TemporalBlock

from .tonos import Pitch, Scale, Chord, Voicing, Sonority, ChordSequence, Contour

from .dynatos import Envelope, DynamicRange

from .thetos import ParameterTree, ParameterField, Instrument, SynthDefInstrument, MidiInstrument, JsInstrument, CompositionalUnit, types
from .thetos.types import frequency, cent, midicent, midi, amplitude, decibel, real_onset, real_duration, metric_onset, metric_duration

from .semeios.visualization.plots import plot
from .semeios.visualization.klotho_plot import KlothoPlot
from .semeios.notelists.supercollider import Scheduler

from .utils.playback.player import play
from .utils.playback.midi_player import play_midi, create_midi
from .utils.playback._config import set_audio_engine, get_audio_engine

__all__ = [
    'topos', 'chronos', 'tonos', 'dynatos', 'thetos', 'semeios', 'utils',
]

__version__ = '4.1.3'