# logmera

Self-hosted AI observability backend with FastAPI + PostgreSQL, plus a lightweight Python SDK logger.

## Features

- Async FastAPI backend
- PostgreSQL storage via SQLAlchemy ORM
- Auto table creation for `logs` on startup
- Typer CLI with interactive DB URL setup
- Python SDK function: `logmera.log(...)`

## Install

```bash
pip install logmera
```

## Start Server

Use a browser-safe port like `8000` (avoid `6000` in browser).

```bash
logmera --host 127.0.0.1 --port 8000
```

Notes:
- The CLI is currently single-command mode, so use `logmera --port 8000` (not `logmera start ...`).
- On first run, if DB is not configured, it prompts for `DATABASE_URL`.
- Entered DB URL is saved at `~/.logmera/config.env`.

## Database Configuration

Resolution order for DB URL:
1. `--db-url`
2. `DATABASE_URL` env var
3. `~/.logmera/config.env`
4. Interactive prompt

Examples:

```bash
logmera --db-url "postgresql://postgres:postgres@localhost:5432/logmera"
```

```bash
logmera --no-prompt --db-url "postgresql://postgres:postgres@localhost:5432/logmera"
```

Optional DB pool env vars:

```bash
DB_POOL_SIZE=10
DB_MAX_OVERFLOW=20
DB_POOL_TIMEOUT=30
```

## API Endpoints

- `GET /` -> welcome message
- `GET /health` -> `{"status":"ok"}`
- `POST /logs` -> create log
- `GET /logs` -> list logs ordered by `created_at DESC`

### Example: Health

```bash
curl http://127.0.0.1:8000/health
```

### Example: Create Log

```bash
curl -X POST http://127.0.0.1:8000/logs \
  -H "Content-Type: application/json" \
  -d '{
    "project_id":"demo",
    "prompt":"Hello",
    "response":"Hi there",
    "model":"gemini-2.5-flash",
    "latency_ms":123,
    "status":"success"
  }'
```

### Example: List Logs

```bash
curl http://127.0.0.1:8000/logs
```

## SDK Usage

`logmera/sdk.py` exposes `logmera.log(...)`.

```python
import logmera

ok = logmera.log(
    project_id="demo-chat",
    prompt="Hello",
    response="Hi",
    model="gemini-2.5-flash",
    latency_ms=95,
    status="success",
)
```

SDK env vars:
- `LOGMERA_URL` (default: `http://127.0.0.1:8000`)
- `LOGMERA_TIMEOUT_SECONDS` (default: `10`)
- `LOGMERA_RETRIES` (default: `2`)

## Local PostgreSQL Quick Start (Docker)

```bash
docker run --name logmera-postgres \
  -e POSTGRES_USER=postgres \
  -e POSTGRES_PASSWORD=postgres \
  -e POSTGRES_DB=logmera \
  -p 5432:5432 -d postgres:16
```

Then start:

```bash
logmera --db-url "postgresql://postgres:postgres@localhost:5432/logmera"
```
