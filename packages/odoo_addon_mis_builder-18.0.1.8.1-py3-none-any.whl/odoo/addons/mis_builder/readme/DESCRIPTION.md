This module allows you to build Management Information Systems
dashboards. Such style of reports presents KPI in rows and time periods
in columns. Reports mainly fetch data from account moves, but can also
combine data coming from arbitrary Odoo models. Reports can be exported
to PDF, Excel and they can be added to Odoo dashboards.
