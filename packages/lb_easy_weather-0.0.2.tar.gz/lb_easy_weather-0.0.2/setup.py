from setuptools import setup

setup(
	name='lb-easy-weather',
	version='0.0.2',
	py_modules=['lb_easy_weather'],
	description='Simple weather library for lazy developers',
	long_description=open('README.md', encoding='utf-8').read(),
	long_description_content_type='text/markdown',
	author='logic-break',
	author_email='abibasqabiba@gmail.com',
	url='https://github.com/logic-break/logic-break/tree/main/libraries/lb_easy_weather',
	license='Non-Commercial', 
	classifiers=[
		'Programming Language :: Python :: 3',
		'Operating System :: OS Independent',
		'Topic :: Software Development :: Libraries :: Python Modules',
	],
	python_requires='>=3.6',
)