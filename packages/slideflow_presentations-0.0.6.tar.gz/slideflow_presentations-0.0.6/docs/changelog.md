# Changelog

The canonical project changelog is maintained at repository root:

- [CHANGELOG.md](https://github.com/joe-broadhead/slideflow/blob/master/CHANGELOG.md)

Use it for release notes, migration notes, and known-issues tracking across versions.
