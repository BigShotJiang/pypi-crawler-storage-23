__version__ = "75.20260302"
GIT_REF = "a44ae07"
URL = "https://github.com/micro-manager/mmCoreAndDevices/tree/a44ae07"