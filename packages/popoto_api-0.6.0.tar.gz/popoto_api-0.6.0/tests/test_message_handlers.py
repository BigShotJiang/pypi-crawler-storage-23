import logging
import queue
import sys
from importlib import import_module
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

popoto_module = import_module("popoto_api.popoto")


class _FakeSocket:
    def __init__(self, client, payload):
        self._client = client
        self._bytes = [bytes([byte]) for byte in payload.encode("utf-8")]

    def settimeout(self, timeout):
        self.timeout = timeout

    def recv(self, _size):
        if self._bytes:
            return self._bytes.pop(0)
        self._client.is_running = False
        raise OSError("stop")


def _make_client(payload):
    client = popoto_module.popoto.__new__(popoto_module.popoto)
    logger = logging.getLogger(f"test-message-handler-{id(client)}")
    logger.handlers = [logging.NullHandler()]
    logger.propagate = False

    client.logger = logger
    client.ip = "127.0.0.1"
    client.cmdport = 17000
    client.verbose = 2
    client.is_running = True
    client.rawTerminal = False
    client.replyQ = queue.Queue()
    client._intercept_handlers = {}
    client._reconnect_callbacks = []
    client.remoteCommandHandler = None
    client.remotePshellEnabled = False
    client.remotePshellCommandQueue = queue.Queue()
    client.cmdsocket = _FakeSocket(client, payload)

    return client


def test_message_handler_positive():
    client = _make_client('{"Alert":"TxComplete"}\r')
    calls = []

    def handler(reply, user_args):
        calls.append((reply, user_args))

    client.register_message_handler('{"Alert": "TxComplete"}', handler)
    client.RxCmdLoop()

    reply = client.replyQ.get_nowait()
    assert reply == {"Alert": "TxComplete"}
    assert calls == [({"Alert": "TxComplete"}, ())]


def test_message_handler_negative():
    client = _make_client('{"Alert":"TxComplete"}\r')
    calls = []

    def handler(reply, user_args):
        calls.append((reply, user_args))

    client.register_message_handler('{"Alert": TxComplete"}', handler)
    client.RxCmdLoop()

    reply = client.replyQ.get_nowait()
    assert reply == {"Alert": "TxComplete"}
    assert calls == []
