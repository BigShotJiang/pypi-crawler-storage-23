import io
import logging
import socket
import subprocess
import sys
from logging import StreamHandler
from pathlib import Path
import time

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from popoto_api import popoto

TIMEOUT = 30

logging.disable(logging.NOTSET)


def _wait_for_port(host, port):
    deadline = time.time() + TIMEOUT
    while time.time() < deadline:
        try:
            with socket.create_connection((host, port), timeout=0.2):
                return True
        except OSError:
            time.sleep(0.5)
    return False


def _read_startup_output(proc):
    if proc.stdout is None:
        return ""

    output = []
    while True:
        try:
            chunk = proc.stdout.read1(4096)
        except OSError:
            break
        if not chunk:
            break
        output.append(chunk.decode("utf-8", errors="replace"))
        if len(chunk) < 4096:
            break
    return "".join(output)


def main():
    print("starting popoto_app")
    popoto_app_proc = subprocess.Popen(
        ["/app/src/pvo/bin/x86/Linux/popoto_app"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )

    try:
        if not _wait_for_port("127.0.0.1", 17000):
            print("popoto_app did not open port 17000")
            startup_output = _read_startup_output(popoto_app_proc)
            if startup_output:
                print(f"startup output: {startup_output!r}")
            return 3
        print("popoto_app ready")

        p = popoto("localhost", 17000, "test-stdout")
        p.verbose = 2
        print(f"client initialized at verbose={p.verbose}")
        api_stdout = io.StringIO()
        capture_output = StreamHandler(api_stdout)
        p.logger.propagate = False
        p.logger.addHandler(capture_output)
        print(
            "logger state:",
            p.logger.level,
            p.logger.getEffectiveLevel(),
            p.logger.disabled,
            p.logger.manager.disable,
            len(p.logger.handlers),
        )
        capture_output.emit(
            logging.makeLogRecord(
                {"msg": "manual-probe", "levelno": logging.WARNING, "levelname": "WARNING"}
            )
        )
        print(f"manual handler output: {api_stdout.getvalue()!r}")
        p.logger.log(logging.WARNING, "probe")
        print(f"probe logger output: {api_stdout.getvalue()!r}")
        p.drainReplyQquiet()
        print("drained reply queue")
        p.get("Carrier")
        print("requested Carrier")

        if p.waitForSpecificReply("Carrier") == {"Timeout": 0}:
            print("timed out waiting for Carrier reply")
            return 1

        captured = api_stdout.getvalue()
        print(f"captured logger output: {captured!r}")
        if '"Carrier":' not in captured:
            print("Carrier reply not found in logger output")
            return 2

        return 0
    finally:
        print("stopping popoto_app")
        popoto_app_proc.terminate()
        popoto_app_proc.wait(timeout=10)


if __name__ == "__main__":
    raise SystemExit(main())
