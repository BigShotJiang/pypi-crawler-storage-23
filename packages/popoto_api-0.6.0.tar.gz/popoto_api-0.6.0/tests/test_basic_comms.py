import sys
import multiprocessing
from pathlib import Path
from time import sleep

from pvo import main as pvo_main

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from popoto_api import popoto


def main():
    pvoproc = multiprocessing.Process(target=pvo_main)
    pvoproc.start()

    try:
        sleep(40)

        p = popoto('localhost', 17000)
        p2 = popoto('localhost', 18000)

        p.transmitJSON({"Payload": {"Data": [1, 2, 3, 4, 5]}})
        if p2.waitForSpecificReply("Data", [1, 2, 3, 4, 5]) == {"Timeout": 0}:
            return 1
        return 0
    finally:
        if pvoproc.is_alive():
            pvoproc.terminate()
            pvoproc.join(timeout=10)


if __name__ == "__main__":
    multiprocessing.freeze_support()
    raise SystemExit(main())
