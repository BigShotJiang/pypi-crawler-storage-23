========================================
Popoto Modem Python API Reference Manual
========================================

Welcome to the Popoto Modem Python API Reference Manual. This documentation is generated
from the package's docstrings and provides both narrative guides and API
reference material.



.. toctree::
   :maxdepth: 2
   :caption: Contents

   intro
   api
