"""Sphinx configuration for the Popoto Modem API documentation."""

from __future__ import annotations

import os
import sys
from datetime import datetime

# Add the project's source directory to sys.path so autodoc can find the package.
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, PROJECT_ROOT)
sys.path.insert(0, os.path.join(PROJECT_ROOT, "src"))

project = "Popoto Python API Reference"
author = "Popoto Modem Team"
copyright = f"2019-{datetime.now():%Y}, {author}"
language = "en"

# Read the dynamically maintained version if available.
try:
    from pipeline.version import __version__ as release  # type: ignore
except Exception:  # pragma: no cover - fall back if pipeline isn't importable.
    release = "0.0.0"

extensions = [
    "sphinx.ext.autodoc",
    "sphinx.ext.napoleon",
    "sphinx.ext.viewcode",
]

templates_path = ["_templates"]
exclude_patterns: list[str] = []

html_theme = "alabaster"
html_static_path = ["_static"]

latex_elements = {
    "papersize": "letterpaper",
    "pointsize": "10pt",
    "extraclassoptions": "openany,oneside",
    "fontpkg": r"""
\usepackage{mathptmx}
\usepackage[scaled=.90]{helvet}
\usepackage{courier}
\usepackage{montserrat}
""",
    "fncychap": "",
    "tocdepth": r"\setcounter{tocdepth}{3}",
    "secnumdepth": r"\setcounter{secnumdepth}{4}",
    "atendofbody": r"""
\appendix
\clearpage
\input{PopotoModulation.tex}
""",
}

latex_docclass = {"manual": "book"}

latex_logo = os.path.join("_static", "latex", "popoto-logo-blue-with-text.png")

latex_additional_files = [
    os.path.join("_static", "latex", "popoto-docstyle.sty"),
    os.path.join("_static", "latex", "PopotoModulation.tex"),
    os.path.join("_static", "latex", "popoto-logo-horizontal-blue.png"),
    os.path.join("_static", "latex", "popoto-logo-blue-with-text.png"),
]

# Autodoc / Napoleon configuration tweaks.
autodoc_typehints = "description"
napoleon_google_docstring = True
napoleon_numpy_docstring = False
napoleon_include_private_with_doc = False
