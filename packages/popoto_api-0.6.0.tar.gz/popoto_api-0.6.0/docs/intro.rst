************
Overview
************

============
Introduction
============

At a low level, the Popoto Modem is controlled by JSON API messages sent over a
TCP socket. These API messages provide a human readable format which may be used
to design custom control software for the Popoto Modem. The Python API provides
an abstraction of these control messages, and can be used for easy integration
with custom Python scripts and programs.

========================================
High-level Description of the Popoto API
========================================

-------
Sockets
-------

The socket-based I/O structure of the Popoto software provides a flexible
framework for interface, test, and portability. With a small amount of additional
code, these sockets can be used to control the modem over standard interfaces
such as RS-422, RS-232, and Ethernet. By default, the TCP Sockets on the
modem use the following ports to communicate with the API:

+-------+---------------+---------------------+
| Port  |     Role      |        Notes        |
+=======+===============+=====================+
| 17000 | Commands      |                     |
+-------+---------------+---------------------+
| 17001 | Data          |                     |
+-------+---------------+---------------------+
| 17002 | PCM Logging   | Not For Typical Use |
+-------+---------------+---------------------+
| 17003 | PCM Streaming | Not For Typical Use |
+-------+---------------+---------------------+
| 17004 | PCM Playback  | Not For Typical Use |
+-------+---------------+---------------------+

The Python API primarily uses its connection to the Command Port (17000) to
control the modem. It connects to the modem's IP address and the appropriate
port using Python's `socket`_ module.

---------------------
JSON Command Messages
---------------------

As stated above, the messages used to directly control the Popoto Modem are in a
`JSON`_ format. This has two main advantages:

1. The messages are human-readable, and thus easy to understand at a glance.
2. Libraries for parsing JSON are available in most major programming
   languages, allowing for integration with a large variety of applications.


--------
Commands
--------
Commands sent to the Popoto Modem are represented as specially-formatted JSON
objects. These consist of two parts, the Command keyword, which represents
the action to be performed, and the Argument keyword, which represents the
parameters with which to perform the action.
The basic structure of a Popoto JSON command is as follows:

``{"Command": "<command>", "Arguments": "<argument>"}``

..  NOTE::
    *Getting the software version*

    A simple example of a JSON command is the command to check the software
    version. This command is issued as follows:

    ``{"Command": "GetVersion", "Arguments": "Unused Arguments"}``

    The modem responds with its version number in the following format:

    ``{"Info":"Popoto Modem Version 4.7.0-beta+950.f8fbd.a5f0345c2"}``

----------------------
System-Level Variables
----------------------
The Popoto Modem contains various variables/parameters which can be used to
adjust the modem's setup or provide the user with information regarding the
state of the modem.

.. NOTE::
    *Setting the Carrier Frequency*

    One simple variable which can be used to demonstrate variable get/set
    capabilities is the Carrier variable, which dictates the modem's carrier
    frequency. In this example, the carrier is set to 25 kHz.

    ``{ "Command": "SetValue", "Arguments": "Carrier int 25000 0"}``

    This would result in the modem responding as follows:

    ``{"Info":"Value Set Carrier=25000"}``

================
The Python Layer
================
In addition to direct use of the JSON API, the modem can be controlled using its
Python API. This is installable via pip from the Popoto Modem repository on
PyPi (``pip install popoto-api``), or directly using the popoto.py file, which
is available on `GitLab`_.

The Python API command reference can be found in a subsequent section of this
document.

-------------
Example Usage
-------------

The example below configures two modems, sends a short JSON payload from the
transmitter, and waits for the receiver to return the decoded data.

.. code-block:: python

   #!/usr/bin/env python3
   from popoto import popoto

   TX_IP, RX_IP = "10.0.0.121", "10.0.0.122"
   MSG = "Hello World"

   rx = popoto(RX_IP)
   tx = popoto(TX_IP)

   tx.set("TxPowerWatts", 1)
   tx.set("Carrier", 30000)
   rx.set("Carrier", 30000)
   tx.transmitJSON('{"Payload":{"Data":"' + MSG + '"} }')

   print(
       rx.waitForSpecificReply("Data", list(bytes(MSG, "ASCII")))
   )

   tx.tearDownPopoto()
   rx.tearDownPopoto()

==============
Pshell
==============
For direct, user-level access, the pshell can be used, which provides a helpful
CLI for controlling the modem. The pshell is implemented in both 
`python`_ (default) and rust (available on request).

It is useful to note that default_shell.py is filled with examples of
interfacing to the Python Popoto API. The user is encouraged to add new, custom
commands to pshell.py to simplify and automate their particular use case.


.. |socket_diagram| image:: _static/images/socket_diagram.jpg

.. _socket: https://docs.python.org/3/library/socket.html

.. _JSON: https://www.json.org/json-en.html

.. _GitLab: https://gitlab.popotomodem.com/delresearch/api/pythonpopotoapi

.. _python: https://gitlab.popotomodem.com/delresearch/pshell
