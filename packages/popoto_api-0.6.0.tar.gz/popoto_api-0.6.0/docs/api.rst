API Reference
=============

Popoto Client
-------------

.. autoclass:: popoto_api.popoto.popoto
   :members:
   :undoc-members:
   :show-inheritance:
