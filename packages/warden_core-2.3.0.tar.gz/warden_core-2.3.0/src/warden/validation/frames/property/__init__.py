"""Property testing validation frame."""

from warden.validation.frames.property.property_frame import PropertyFrame

__all__ = ["PropertyFrame"]
