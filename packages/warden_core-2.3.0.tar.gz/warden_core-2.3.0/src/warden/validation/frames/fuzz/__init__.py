"""Fuzz testing validation frame."""

from warden.validation.frames.fuzz.fuzz_frame import FuzzFrame

__all__ = ["FuzzFrame"]
