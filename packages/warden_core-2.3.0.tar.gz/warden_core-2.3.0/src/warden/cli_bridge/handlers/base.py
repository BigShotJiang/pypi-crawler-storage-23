"""
Base Handler for Warden Bridge.
"""


class BaseHandler:
    """Base class for all bridge handlers."""

    pass
