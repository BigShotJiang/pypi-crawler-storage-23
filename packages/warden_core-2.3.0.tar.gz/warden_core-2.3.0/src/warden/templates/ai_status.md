# Warden Security Status
Updated: {timestamp}

**Status**: {status}
**Score**: {score}/10

{status_details}

> [!NOTE]
> Run `warden scan` to update this status.
> If status is FAIL, check `.warden/reports/` for details.
