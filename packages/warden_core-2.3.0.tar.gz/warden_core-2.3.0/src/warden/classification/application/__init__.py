"""Classification application module."""
