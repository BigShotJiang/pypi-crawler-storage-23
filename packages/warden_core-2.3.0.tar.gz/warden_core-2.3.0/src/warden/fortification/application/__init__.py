"""Fortification application module."""
