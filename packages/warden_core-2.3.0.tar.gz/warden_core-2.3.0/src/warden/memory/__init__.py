"""Memory module."""
