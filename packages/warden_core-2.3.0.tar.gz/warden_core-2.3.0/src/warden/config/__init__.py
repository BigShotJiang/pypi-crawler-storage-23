"""
Pipeline configuration management.

YAML parser, exporter, validator for pipeline configurations.
"""
