"""Shared taint analysis service — usable by any validation frame."""

from __future__ import annotations

from warden.analysis.taint.service import TaintAnalysisService

__all__ = ["TaintAnalysisService"]
