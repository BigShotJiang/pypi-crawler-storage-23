<p>
  <picture>
    <!-- light mode logo -->
    <source media='(prefers-color-scheme: light)' srcset='https://raw.githubusercontent.com/easyscience/assets-branding/refs/heads/master/easyutilities/logos/light.svg'>
    <!-- dark mode logo -->
    <source media='(prefers-color-scheme: dark)' srcset='https://raw.githubusercontent.com/easyscience/assets-branding/refs/heads/master/easyutilities/logos/dark.svg'>
    <!-- default logo == light mode logo -->
    <img src='https://raw.githubusercontent.com/easyscience/assets-branding/refs/heads/master/easyutilities/logos/light.svg' alt='EasyUtilities'>
  </picture>
</p>

**EasyUtilities** is a shared library of utility classes and helper
functions used across the EasyScience framework.

<!-- HOME REPOSITORY SECTION -->

**EasyUtilities** is developed as a Python library.

## Useful Links

### 📚 For Users

- 📖 [Documentation](https://easyscience.github.io/utils/latest)
- 🚀
  [Getting Started](https://easyscience.github.io/utils/latest/introduction)
- 🧪 [Tutorials](https://easyscience.github.io/utils/latest/tutorials)
- 💬
  [Get in Touch](https://easyscience.github.io/utils/latest/introduction/#get-in-touch)
- 🧾
  [Citation](https://easyscience.github.io/utils/latest/introduction/#citation)

### 🤝 For Contributors

- 🤝
  [Contributing Guide](https://github.com/easyscience/utils/blob/master/CONTRIBUTING.md)
- 🛡
  [Code of Conduct](https://github.com/easyscience/.github/blob/master/CODE_OF_CONDUCT.md)
- 🐞 [Issue Tracker](https://github.com/easyscience/utils/issues)
- 💡 [Discussions](https://github.com/easyscience/utils/discussions)
- 🧑‍💻 [Source Code](https://github.com/easyscience/utils)

### ⚖️ Project Information

- ⚖️
  [License](https://raw.githubusercontent.com/easyscience/utils/refs/heads/master/LICENSE)
