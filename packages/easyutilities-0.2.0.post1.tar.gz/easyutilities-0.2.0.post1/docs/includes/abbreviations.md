<!-- prettier-ignore-start -->

*[CIF]: Crystallographic Information File.
*[curl]: Command-line tool for transferring data with URLs.
*[GitHub]: A web-based platform for version control and collaboration.
*[Google Colab]: Cloud service that allows you to run Jupyter Notebooks in the cloud.
*[IUCr]: International Union of Crystallography.
*[Jupyter Notebook]: An open-source web application that allows you to create and share documents that contain live code, equations, visualizations, and narrative text.
*[JupyterLab]: Web-based interactive development environment for notebooks, code, and data.
*[pip]: Package installer for Python.
*[PyPI]: The Python Package Index is a repository of software for the Python programming language.
*[Conda]: Conda is a cross-platform, language-agnostic binary package manager.
*[Pixi]: A modern package manager for Windows, macOS, and Linux.

<!-- prettier-ignore-end -->
