# %% [markdown]
# # Dummy Tutorial
#
# This is a dummy tutorial file to ensure that the tutorials section is
# not empty. You can replace this file with actual tutorial content as
# needed.

# %% [markdown]
# ## Import Library

# %%
import easyutilities

# %% [markdown]
# ## Step 1: Blah Blah Blah

# %%
# This is a placeholder for tutorial content.
print('This is a dummy tutorial.')
print('Imported library:', easyutilities)
