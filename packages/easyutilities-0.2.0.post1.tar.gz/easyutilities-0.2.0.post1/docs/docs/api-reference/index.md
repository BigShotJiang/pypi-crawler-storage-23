---
icon: material/code-braces-box
---

# :material-code-braces-box: API Reference

This section contains the reference detailing the functions and modules
available in EasyUtilities.

- [environment](environment.md) – Runtime environment detection
  utilities.
