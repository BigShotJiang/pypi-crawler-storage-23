# Changelog

All notable changes to this project will be documented in this file.

## Unreleased

No tracked entries yet.

## 0.1.2 - 2026-02-21

Patch release adding typing metadata for downstream type checkers.

- Added `py.typed` marker to declare inline typing support in `winregkit` (PEP 561).

## 0.1.1 - 2026-02-21

Patch release to validate automated GitHub Release notes.

- Publish workflow now uses GitHub-generated release notes for tag releases.

## 0.1.0 - 2026-02-21

First stable 0.1 release.

- Finalizes the 0.1 API surface for key traversal, typed value operations, and path-based key construction.
- Strengthens test coverage across fake and real backends, with backend-selective test flags for CI and local runs.
- Enforces formatting checks in CI alongside linting, tests, and Windows mypy checks.

## 0.1.0rc2 - 2026-02-21

Second release candidate for the 0.1 line.

- Publish workflow now creates a basic GitHub Release alongside PyPI publication.
- Release automation now avoids duplicate publish attempts from branch-triggered CI runs.

## 0.1.0rc1 - 2026-02-21

Initial release candidate for the 0.1 line.

- API surface refined for clearer typed value access and iteration naming.
- Cross-platform test strategy stabilized for real Windows `winreg` and fake backend coverage.
- CI and publish workflows aligned around `uv` tooling with release-tag-driven publishing.
- Project release/version workflow standardized on `uv version`.
