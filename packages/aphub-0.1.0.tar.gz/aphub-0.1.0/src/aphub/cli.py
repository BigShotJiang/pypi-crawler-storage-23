"""
Main CLI entry point for aphub command.
"""

import typer
import yaml
from typing import Optional, Callable
from pathlib import Path
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

from aphub_sdk import HubClient, HubClientError
from aphub.config import get_config
from aphub.progress import create_progress_bar

app = typer.Typer(
    name="aphub",
    help="AI Agent Hub CLI - The Docker Hub for AI Agents",
    no_args_is_help=True,
)
console = Console()

# Configuration
DEFAULT_HUB_URL = "https://hub.aipartnerup.com"


def get_client(hub_url: Optional[str] = None, progress_callback: Optional[Callable] = None) -> HubClient:
    """Get configured HubClient instance."""
    config = get_config()
    
    url = hub_url or config.hub_url
    # Use access_token if available, otherwise use api_key
    api_key = config.access_token or config.api_key
    access_token = config.access_token
    refresh_token = config.refresh_token
    
    return HubClient(
        base_url=url,
        api_key=api_key if not access_token else None,
        access_token=access_token,
        refresh_token=refresh_token,
        progress_callback=progress_callback,
    )


@app.command()
def login(
    username: Optional[str] = typer.Option(None, "--username", "-u", help="Username"),
    password: Optional[str] = typer.Option(
        None, "--password", "-p", help="Password", hide_input=True
    ),
    hub_url: Optional[str] = typer.Option(None, "--hub-url", help="Hub URL"),
):
    """Login to AI Agent Hub."""
    config = get_config()
    
    # Get hub URL
    url = hub_url or config.hub_url
    if hub_url:
        config.hub_url = hub_url
    
    # Get credentials
    if not username:
        username = typer.prompt("Username")
    if not password:
        password = typer.prompt("Password", hide_input=True)
    
    try:
        # Login using SDK
        client = HubClient(base_url=url)
        auth_response = client.login(username, password)
        
        # Save tokens to config
        config.access_token = auth_response.access_token
        config.refresh_token = auth_response.refresh_token
        
        console.print(f"[green]✓ Successfully logged in as {username}[/green]")
        console.print(f"[dim]Hub URL: {url}[/dim]")
        client.close()
                
    except HubClientError as e:
        console.print(f"[red]✗ {e}[/red]")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"[red]✗ Error: {e}[/red]")
        raise typer.Exit(1)


@app.command()
def logout():
    """Logout and clear saved credentials."""
    config = get_config()
    config.clear_auth()
    console.print("[green]✓ Logged out successfully[/green]")


@app.command()
def push(
    manifest_path: Path = typer.Argument(
        ...,
        help="Path to agent.yaml manifest file",
        exists=True,
    ),
    tag: str = typer.Option("latest", "--tag", "-t", help="Version tag"),
    files_path: Optional[Path] = typer.Option(None, "--files", "-f", help="Path to agent files directory"),
    hub_url: Optional[str] = typer.Option(None, "--hub-url", help="Hub URL"),
    no_progress: bool = typer.Option(False, "--no-progress", help="Disable progress bar"),
):
    """Push an Agent to the registry."""
    try:
        # Load manifest
        with open(manifest_path, "r") as f:
            manifest_data = yaml.safe_load(f)
        
        # Extract agent name from manifest
        if "metadata" in manifest_data and "name" in manifest_data["metadata"]:
            agent_name = manifest_data["metadata"]["name"]
        elif "name" in manifest_data:
            agent_name = manifest_data["name"]
        else:
            console.print("[red]✗ Manifest must contain 'name' or 'metadata.name'[/red]")
            raise typer.Exit(1)
        
        # Determine files path (default to manifest directory)
        if not files_path:
            files_path = manifest_path.parent
        
        # Create progress bar
        progress_callback = None
        if not no_progress:
            progress, progress_callback = create_progress_bar(f"Uploading {agent_name}:{tag}")
        else:
            progress = None
        
        console.print(f"[blue]Pushing agent '{agent_name}' (tag: {tag})...[/blue]")
        
        with get_client(hub_url, progress_callback=progress_callback) as client:
            if progress:
                with progress:
                    # Push manifest and files
                    result = client.push(
                        manifest=manifest_path,
                        tag=tag,
                        files_path=files_path if files_path and files_path.exists() else None
                    )
                    
                    if result.success:
                        console.print(f"[green]✓ Successfully pushed {agent_name}:{tag}[/green]")
                        if hasattr(result, 'version') and result.version:
                            console.print(f"  Version: {result.version}")
                    else:
                        error_msg = getattr(result, 'message', 'Push failed')
                        console.print(f"[red]✗ Push failed: {error_msg}[/red]")
                        raise typer.Exit(1)
            else:
                # No progress bar
                result = client.push(
                    manifest=manifest_path,
                    tag=tag,
                    files_path=files_path if files_path and files_path.exists() else None
                )
                
                if result.success:
                    console.print(f"[green]✓ Successfully pushed {agent_name}:{tag}[/green]")
                    if hasattr(result, 'version') and result.version:
                        console.print(f"  Version: {result.version}")
                else:
                    error_msg = getattr(result, 'message', 'Push failed')
                    console.print(f"[red]✗ Push failed: {error_msg}[/red]")
                    raise typer.Exit(1)
                
    except FileNotFoundError:
        console.print(f"[red]✗ File not found: {manifest_path}[/red]")
        raise typer.Exit(1)
    except yaml.YAMLError as e:
        console.print(f"[red]✗ Invalid YAML: {e}[/red]")
        raise typer.Exit(1)
    except HubClientError as e:
        console.print(f"[red]✗ Error: {e}[/red]")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"[red]✗ Unexpected error: {e}[/red]")
        raise typer.Exit(1)


@app.command()
def pull(
    name: str = typer.Argument(..., help="Agent name (e.g., 'my-agent' or 'user/my-agent')"),
    tag: str = typer.Option("latest", "--tag", "-t", help="Version tag"),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Output directory"),
    hub_url: Optional[str] = typer.Option(None, "--hub-url", help="Hub URL"),
    no_progress: bool = typer.Option(False, "--no-progress", help="Disable progress bar"),
):
    """Pull an Agent from the registry."""
    try:
        # Default output to current directory with agent name
        if not output:
            output = Path(".") / name.split("/")[-1]
        
        # Create progress bar
        progress_callback = None
        if not no_progress:
            progress, progress_callback = create_progress_bar(f"Downloading {name}:{tag}")
        else:
            progress = None
        
        with get_client(hub_url, progress_callback=progress_callback) as client:
            if progress:
                with progress:
                    if not no_progress:
                        console.print(f"[blue]Pulling {name}:{tag}...[/blue]")
                    
                    result = client.pull(name=name, tag=tag, output_path=output)
                    
                    if result.success:
                        console.print(f"[green]✓ Successfully pulled {name}:{tag}[/green]")
                        console.print(f"  Output: {output}")
                        if hasattr(result, 'manifest') and result.manifest:
                            manifest = result.manifest
                            if hasattr(manifest, 'spec') and hasattr(manifest.spec, 'framework'):
                                console.print(f"  Framework: {manifest.spec.framework}")
                            elif hasattr(manifest, 'framework'):
                                console.print(f"  Framework: {manifest.framework}")
                    else:
                        error_msg = getattr(result, 'message', 'Pull failed')
                        console.print(f"[red]✗ Pull failed: {error_msg}[/red]")
                        raise typer.Exit(1)
            else:
                # No progress bar
                console.print(f"[blue]Pulling {name}:{tag}...[/blue]")
                
                result = client.pull(name=name, tag=tag, output_path=output)
                
                if result.success:
                    console.print(f"[green]✓ Successfully pulled {name}:{tag}[/green]")
                    console.print(f"  Output: {output}")
                else:
                    error_msg = getattr(result, 'message', 'Pull failed')
                    console.print(f"[red]✗ Pull failed: {error_msg}[/red]")
                    raise typer.Exit(1)
                
    except HubClientError as e:
        console.print(f"[red]✗ Error: {e}[/red]")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"[red]✗ Unexpected error: {e}[/red]")
        raise typer.Exit(1)


@app.command()
def search(
    query: str = typer.Argument(..., help="Search query"),
    framework: Optional[str] = typer.Option(None, "--framework", "-f", help="Filter by framework"),
    limit: int = typer.Option(20, "--limit", "-l", help="Number of results"),
    hub_url: Optional[str] = typer.Option(None, "--hub-url", help="Hub URL"),
):
    """Search for Agents."""
    try:
        with get_client(hub_url) as client:
            result = client.search(query=query, framework=framework, page_size=limit)
            
            if not result.results:
                console.print(f"[yellow]No agents found for '{query}'[/yellow]")
                return
            
            # Display results in a table
            table = Table(title=f"Search Results for '{query}'")
            table.add_column("Name", style="cyan")
            table.add_column("Description")
            table.add_column("Framework", style="green")
            table.add_column("Version")
            table.add_column("Downloads", justify="right")
            table.add_column("Stars", justify="right")
            
            for item in result.results:
                agent = item.agent if hasattr(item, 'agent') else item
                name = getattr(agent, 'full_name', None) or getattr(agent, 'name', 'N/A')
                desc = getattr(agent, 'description', '') or ''
                desc_short = (desc[:50] + "...") if len(desc) > 50 else desc
                framework_name = getattr(agent, 'framework', 'N/A')
                version = getattr(agent, 'latest_version', None) or "-"
                downloads = getattr(agent, 'downloads', 0) or getattr(agent, 'downloads_count', 0)
                stars = getattr(agent, 'stars', 0) or getattr(agent, 'stars_count', 0)
                
                table.add_row(
                    name,
                    desc_short,
                    framework_name,
                    version,
                    str(downloads),
                    str(stars),
                )
            
            console.print(table)
            total = getattr(result, 'total', len(result.results))
            console.print(f"\nFound {total} agents (showing {len(result.results)})")
            
    except HubClientError as e:
        console.print(f"[red]✗ Error: {e}[/red]")
        raise typer.Exit(1)


@app.command()
def info(
    name: str = typer.Argument(..., help="Agent name"),
    hub_url: Optional[str] = typer.Option(None, "--hub-url", help="Hub URL"),
):
    """Get detailed information about an Agent."""
    try:
        with get_client(hub_url) as client:
            agent = client.get_agent(name)
            
            # Build info panel
            info_lines = []
            info_lines.append(f"[bold cyan]{name}[/bold cyan]")
            if hasattr(agent, 'description') and agent.description:
                info_lines.append(f"[dim]{agent.description}[/dim]")
            info_lines.append("")
            
            if hasattr(agent, 'framework'):
                info_lines.append(f"Framework: [green]{agent.framework}[/green]")
            if hasattr(agent, 'latest_version'):
                info_lines.append(f"Latest Version: {agent.latest_version or 'N/A'}")
            if hasattr(agent, 'metadata'):
                metadata = agent.metadata
                if hasattr(metadata, 'downloads'):
                    info_lines.append(f"Downloads: {metadata.downloads}")
                if hasattr(metadata, 'stars'):
                    info_lines.append(f"Stars: {metadata.stars}")
                if hasattr(metadata, 'verified') and metadata.verified:
                    info_lines.append("[blue]✓ Verified[/blue]")
            
            console.print(Panel("\n".join(info_lines), title="Agent Information"))
            
            # List tags
            tags = client.list_tags(name)
            if tags:
                console.print(f"\n[bold]Tags:[/bold] {', '.join(tags)}")
                
    except HubClientError as e:
        console.print(f"[red]✗ Error: {e}[/red]")
        raise typer.Exit(1)


@app.command()
def tags(
    name: str = typer.Argument(..., help="Agent name"),
    hub_url: Optional[str] = typer.Option(None, "--hub-url", help="Hub URL"),
):
    """List all tags for an Agent."""
    try:
        with get_client(hub_url) as client:
            tags_list = client.list_tags(name)
            
            if not tags_list:
                console.print(f"[yellow]No tags found for {name}[/yellow]")
                return
            
            table = Table(title=f"Tags for {name}")
            table.add_column("Tag", style="cyan")
            
            for tag in tags_list:
                table.add_row(tag)
            
            console.print(table)
                
    except HubClientError as e:
        console.print(f"[red]✗ Error: {e}[/red]")
        raise typer.Exit(1)


@app.command()
def manifest(
    name: str = typer.Argument(..., help="Agent name"),
    tag: str = typer.Option("latest", "--tag", "-t", help="Version tag"),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Output file (default: stdout)"),
    hub_url: Optional[str] = typer.Option(None, "--hub-url", help="Hub URL"),
):
    """Get Agent manifest."""
    try:
        with get_client(hub_url) as client:
            # Use SDK method to get manifest
            manifest_obj = client.get_manifest(name, tag)
            
            # Convert to dict for YAML output
            manifest_data = manifest_obj.model_dump(by_alias=True, exclude_none=True)
            
            # Output manifest
            if output:
                with open(output, "w") as f:
                    yaml.dump(manifest_data, f, default_flow_style=False, sort_keys=False)
                console.print(f"[green]✓ Manifest saved to {output}[/green]")
            else:
                console.print(yaml.dump(manifest_data, default_flow_style=False, sort_keys=False))
                
    except HubClientError as e:
        console.print(f"[red]✗ Error: {e}[/red]")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"[red]✗ Error: {e}[/red]")
        raise typer.Exit(1)


@app.command()
def rate(
    name: str = typer.Argument(..., help="Agent name"),
    rating: int = typer.Option(..., "--rating", "-r", help="Rating (1-5)"),
    comment: Optional[str] = typer.Option(None, "--comment", "-c", help="Optional comment"),
    hub_url: Optional[str] = typer.Option(None, "--hub-url", help="Hub URL"),
):
    """Rate an Agent."""
    # Validate rating range
    if rating < 1 or rating > 5:
        console.print("[red]✗ Rating must be between 1 and 5[/red]")
        raise typer.Exit(1)
    
    try:
        with get_client(hub_url) as client:
            result = client.rate_agent(name, rating, comment)
            
            if result.success:
                console.print(f"[green]✓ {result.message}[/green]")
            else:
                console.print(f"[red]✗ {result.message}[/red]")
                raise typer.Exit(1)
                
    except HubClientError as e:
        console.print(f"[red]✗ Error: {e}[/red]")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"[red]✗ Unexpected error: {e}[/red]")
        raise typer.Exit(1)


# =============================================================================
# Skill subcommand group
# =============================================================================

skill_app = typer.Typer(name="skill", help="Manage AI coding skills")
app.add_typer(skill_app)


@skill_app.command("push")
def skill_push(
    manifest_path: Path = typer.Argument(
        ...,
        help="Path to skill.yaml manifest file",
        exists=True,
    ),
    tag: str = typer.Option("latest", "--tag", "-t", help="Version tag"),
    files_path: Optional[Path] = typer.Option(None, "--files", "-f", help="Path to skill files directory"),
    hub_url: Optional[str] = typer.Option(None, "--hub-url", help="Hub URL"),
    no_progress: bool = typer.Option(False, "--no-progress", help="Disable progress bar"),
):
    """Push a Skill to the registry."""
    try:
        with open(manifest_path, "r") as f:
            manifest_data = yaml.safe_load(f)

        if "metadata" in manifest_data and "name" in manifest_data["metadata"]:
            skill_name = manifest_data["metadata"]["name"]
        elif "name" in manifest_data:
            skill_name = manifest_data["name"]
        else:
            console.print("[red]Manifest must contain 'name' or 'metadata.name'[/red]")
            raise typer.Exit(1)

        if not files_path:
            files_path = manifest_path.parent

        progress_callback = None
        if not no_progress:
            progress, progress_callback = create_progress_bar(f"Uploading {skill_name}:{tag}")
        else:
            progress = None

        console.print(f"[blue]Pushing skill '{skill_name}' (tag: {tag})...[/blue]")

        with get_client(hub_url, progress_callback=progress_callback) as client:
            if progress:
                with progress:
                    result = client.push_skill(
                        manifest=manifest_path,
                        tag=tag,
                        files_path=files_path if files_path and files_path.exists() else None,
                    )
            else:
                result = client.push_skill(
                    manifest=manifest_path,
                    tag=tag,
                    files_path=files_path if files_path and files_path.exists() else None,
                )

            if result.success:
                console.print(f"[green]Successfully pushed {skill_name}:{tag}[/green]")
                if result.version:
                    console.print(f"  Version: {result.version}")
            else:
                console.print(f"[red]Push failed: {result.message or 'Unknown error'}[/red]")
                raise typer.Exit(1)

    except FileNotFoundError:
        console.print(f"[red]File not found: {manifest_path}[/red]")
        raise typer.Exit(1)
    except yaml.YAMLError as e:
        console.print(f"[red]Invalid YAML: {e}[/red]")
        raise typer.Exit(1)
    except HubClientError as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)
    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Unexpected error: {e}[/red]")
        raise typer.Exit(1)


@skill_app.command("pull")
def skill_pull(
    name: str = typer.Argument(..., help="Skill name (e.g., 'code-forge' or 'user/code-forge')"),
    tag: str = typer.Option("latest", "--tag", "-t", help="Version tag"),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Output directory"),
    hub_url: Optional[str] = typer.Option(None, "--hub-url", help="Hub URL"),
    no_progress: bool = typer.Option(False, "--no-progress", help="Disable progress bar"),
):
    """Pull a Skill from the registry."""
    try:
        if not output:
            output = Path(".") / name.split("/")[-1]

        progress_callback = None
        if not no_progress:
            progress, progress_callback = create_progress_bar(f"Downloading {name}:{tag}")
        else:
            progress = None

        console.print(f"[blue]Pulling skill {name}:{tag}...[/blue]")

        with get_client(hub_url, progress_callback=progress_callback) as client:
            if progress:
                with progress:
                    result = client.pull_skill(name=name, tag=tag, output_path=output)
            else:
                result = client.pull_skill(name=name, tag=tag, output_path=output)

            if result.success:
                console.print(f"[green]Successfully pulled {name}:{tag}[/green]")
                console.print(f"  Output: {output}")
            else:
                console.print(f"[red]Pull failed: {result.message or 'Unknown error'}[/red]")
                raise typer.Exit(1)

    except HubClientError as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)
    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Unexpected error: {e}[/red]")
        raise typer.Exit(1)


@skill_app.command("search")
def skill_search(
    query: str = typer.Argument(..., help="Search query"),
    platform: Optional[str] = typer.Option(None, "--platform", "-p", help="Filter by platform"),
    limit: int = typer.Option(20, "--limit", "-l", help="Number of results"),
    hub_url: Optional[str] = typer.Option(None, "--hub-url", help="Hub URL"),
):
    """Search for Skills."""
    try:
        platforms = [platform] if platform else None

        with get_client(hub_url) as client:
            result = client.search_skills(query=query, platforms=platforms, page_size=limit)

            if not result.results:
                console.print(f"[yellow]No skills found for '{query}'[/yellow]")
                return

            table = Table(title=f"Skill Search Results for '{query}'")
            table.add_column("Name", style="cyan")
            table.add_column("Description")
            table.add_column("Version")
            table.add_column("Skills", justify="right")
            table.add_column("Platforms", style="green")
            table.add_column("Downloads", justify="right")

            for item in result.results:
                skill = item.skill if hasattr(item, 'skill') else item
                s_name = getattr(skill, 'full_name', None) or getattr(skill, 'name', 'N/A')
                desc = getattr(skill, 'description', '') or ''
                desc_short = (desc[:50] + "...") if len(desc) > 50 else desc
                ver = getattr(skill, 'latest_version', None) or "-"
                skill_count = str(getattr(skill, 'skill_count', 0))
                plats = ", ".join(getattr(skill, 'platforms', []))
                downloads = str(getattr(skill, 'downloads', 0))

                table.add_row(s_name, desc_short, ver, skill_count, plats, downloads)

            console.print(table)
            total = getattr(result, 'total', len(result.results))
            console.print(f"\nFound {total} skills (showing {len(result.results)})")

    except HubClientError as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)


@skill_app.command("info")
def skill_info(
    name: str = typer.Argument(..., help="Skill name"),
    hub_url: Optional[str] = typer.Option(None, "--hub-url", help="Hub URL"),
):
    """Get detailed information about a Skill."""
    try:
        with get_client(hub_url) as client:
            skill = client.get_skill(name)

            info_lines = []
            info_lines.append(f"[bold cyan]{name}[/bold cyan]")
            if skill.description:
                info_lines.append(f"[dim]{skill.description}[/dim]")
            info_lines.append("")

            info_lines.append(f"Latest Version: {skill.latest_version or 'N/A'}")
            info_lines.append(f"Skills in pack: {skill.skill_count}")
            if skill.platforms:
                info_lines.append(f"Platforms: {', '.join(skill.platforms)}")
            if skill.metadata:
                info_lines.append(f"Downloads: {skill.metadata.downloads}")
                info_lines.append(f"Stars: {skill.metadata.stars}")
                if skill.metadata.verified:
                    info_lines.append("[blue]Verified[/blue]")

            console.print(Panel("\n".join(info_lines), title="Skill Information"))

            skill_tags = client.list_skill_tags(name)
            if skill_tags:
                console.print(f"\n[bold]Tags:[/bold] {', '.join(skill_tags)}")

    except HubClientError as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)


@skill_app.command("tags")
def skill_tags(
    name: str = typer.Argument(..., help="Skill name"),
    hub_url: Optional[str] = typer.Option(None, "--hub-url", help="Hub URL"),
):
    """List all tags for a Skill."""
    try:
        with get_client(hub_url) as client:
            tags_list = client.list_skill_tags(name)

            if not tags_list:
                console.print(f"[yellow]No tags found for {name}[/yellow]")
                return

            table = Table(title=f"Tags for {name}")
            table.add_column("Tag", style="cyan")

            for tag in tags_list:
                table.add_row(tag)

            console.print(table)

    except HubClientError as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)


@app.command()
def version():
    """Show version information."""
    from aphub import __version__ as cli_version
    from aphub_sdk import __version__ as sdk_version

    console.print(f"aphub CLI version: [cyan]{cli_version}[/cyan]")
    console.print(f"SDK version: [cyan]{sdk_version}[/cyan]")


if __name__ == "__main__":
    app()
