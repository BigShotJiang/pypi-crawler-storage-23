"""
aphub CLI - Command-line tool for AI Agent Hub

Usage:
    aphub login
    aphub push <name>
    aphub pull <name>
    aphub search <query>
"""

__version__ = "0.1.0"
