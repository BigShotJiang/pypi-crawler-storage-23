"""
Configuration management for aphub
"""

import json
import os
from pathlib import Path
from typing import Optional
from appdirs import user_config_dir


class Config:
    """CLI configuration manager"""
    
    def __init__(self):
        self.config_dir = Path(user_config_dir("aphub", "aipartnerup"))
        self.config_file = self.config_dir / "config.json"
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self._config: dict = {}
        self._load()
    
    def _load(self):
        """Load configuration from file"""
        if self.config_file.exists():
            try:
                with open(self.config_file, "r") as f:
                    self._config = json.load(f)
            except (json.JSONDecodeError, IOError):
                self._config = {}
        else:
            self._config = {}
    
    def _save(self):
        """Save configuration to file"""
        try:
            with open(self.config_file, "w") as f:
                json.dump(self._config, f, indent=2)
        except IOError:
            pass
    
    def get(self, key: str, default: Optional[str] = None) -> Optional[str]:
        """Get configuration value"""
        return self._config.get(key, default)
    
    def set(self, key: str, value: str):
        """Set configuration value"""
        self._config[key] = value
        self._save()
    
    def unset(self, key: str):
        """Remove configuration value"""
        if key in self._config:
            del self._config[key]
            self._save()
    
    @property
    def hub_url(self) -> str:
        """Get hub URL"""
        return self.get("hub_url") or os.environ.get("APHUB_URL", "https://hub.aipartnerup.com")
    
    @hub_url.setter
    def hub_url(self, value: str):
        """Set hub URL"""
        self.set("hub_url", value)
    
    @property
    def api_key(self) -> Optional[str]:
        """Get API key (from config or environment)"""
        return self.get("api_key") or os.environ.get("APHUB_API_KEY")
    
    @api_key.setter
    def api_key(self, value: str):
        """Set API key"""
        self.set("api_key", value)
    
    @property
    def access_token(self) -> Optional[str]:
        """Get access token"""
        return self.get("access_token")
    
    @access_token.setter
    def access_token(self, value: str):
        """Set access token"""
        self.set("access_token", value)
    
    @property
    def refresh_token(self) -> Optional[str]:
        """Get refresh token"""
        return self.get("refresh_token")
    
    @refresh_token.setter
    def refresh_token(self, value: str):
        """Set refresh token"""
        self.set("refresh_token", value)
    
    def clear_auth(self):
        """Clear authentication tokens"""
        self.unset("access_token")
        self.unset("refresh_token")
        self.unset("api_key")


# Global config instance
_config_instance: Optional[Config] = None


def get_config() -> Config:
    """Get global config instance"""
    global _config_instance
    if _config_instance is None:
        _config_instance = Config()
    return _config_instance

