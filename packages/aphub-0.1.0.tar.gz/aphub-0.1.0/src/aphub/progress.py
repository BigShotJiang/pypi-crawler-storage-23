"""
Progress bar utilities for CLI
"""

from rich.progress import Progress, BarColumn, TextColumn, DownloadColumn, TransferSpeedColumn
from typing import Callable


def create_progress_callback(progress: Progress, task_id) -> Callable[[int, int], None]:
    """Create a progress callback function for uploads/downloads"""
    def callback(bytes_sent: int, total_bytes: int):
        progress.update(task_id, completed=bytes_sent, total=total_bytes)
    return callback


def create_progress_bar(description: str = "Processing") -> tuple[Progress, Callable[[int, int], None]]:
    """Create a progress bar and callback"""
    progress = Progress(
        TextColumn("[bold blue]{task.description}"),
        BarColumn(),
        DownloadColumn(),
        TransferSpeedColumn(),
        TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
    )
    
    task_id = progress.add_task(description, total=100)
    
    def callback(bytes_sent: int, total_bytes: int):
        if total_bytes > 0:
            progress.update(task_id, completed=bytes_sent, total=total_bytes)
    
    return progress, callback

