# aphub

Command-line tool for aphub - The Docker Hub for AI Agents

## Installation

```bash
pip install aphub
```

## Quick Start

### Login

```bash
aphub login
# or
aphub login --username myuser --password mypass
```

### Push Agent

```bash
aphub push ./agent.yaml --tag latest --files ./agent-files/
```

### Pull Agent

```bash
aphub pull customer-service-agent
aphub pull customer-service-agent --tag 1.0.0 --output ./agents/
```

### Search Agents

```bash
aphub search "customer service"
aphub search chatbot --framework aipartnerupflow --limit 50
```

### Get Agent Info

```bash
aphub info customer-service-agent
aphub info myorg/my-agent
```

### List Tags

```bash
aphub tags customer-service-agent
```

### Get Manifest

```bash
aphub manifest customer-service-agent --tag 1.0.0
aphub manifest customer-service-agent --tag 1.0.0 --output manifest.yaml
```

## Commands

| Command | Description |
|---------|-------------|
| `aphub login` | Login to hub.aipartnerup.com |
| `aphub logout` | Logout and clear saved credentials |
| `aphub push <manifest>` | Push an Agent to the registry |
| `aphub pull <name>` | Pull an Agent from the registry |
| `aphub search <query>` | Search for Agents |
| `aphub info <name>` | Get detailed agent information |
| `aphub tags <name>` | List all tags for an agent |
| `aphub manifest <name>` | Get agent manifest |
| `aphub version` | Show version information |

## Features

### Progress Bars
Upload and download progress is automatically displayed for large files:

```bash
aphub pull my-agent  # Shows progress bar
aphub pull my-agent --no-progress  # Disable progress bar
```

### Token Auto-Refresh
Tokens are automatically refreshed when expired. No manual intervention needed!

### Configuration

#### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `APHUB_URL` | Hub API URL | `https://hub.aipartnerup.com` |
| `APHUB_API_KEY` | API key for authentication | - |

#### Config File
Configuration is stored in:
- macOS/Linux: `~/.config/aphub/config.json`
- Windows: `%APPDATA%/aphub/config.json`

## Examples

### Complete Workflow

```bash
# 1. Login
aphub login

# 2. Push your agent
aphub push ./my-agent/agent.yaml --tag 1.0.0 --files ./my-agent/

# 3. Search for agents
aphub search "customer service" --framework aipartnerupflow

# 4. Pull an agent
aphub pull customer-service-agent --tag latest --output ./agents/

# 5. Get agent details
aphub info customer-service-agent

# 6. List all versions
aphub tags customer-service-agent
```

## License

Apache-2.0
