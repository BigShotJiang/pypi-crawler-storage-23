"""
Unit tests for CLI commands
"""

import pytest
from unittest.mock import Mock, patch

from aphub.config import Config
from aphub.cli import get_client


@pytest.fixture
def temp_config_dir(tmp_path):
    """Create a temporary config directory"""
    config_dir = tmp_path / "config"
    config_dir.mkdir()
    return config_dir


def test_config_get_set(temp_config_dir):
    """Test config get/set operations"""
    config = Config()
    config.config_dir = temp_config_dir
    config.config_file = temp_config_dir / "config.json"
    
    config.set("test_key", "test_value")
    assert config.get("test_key") == "test_value"
    
    config.unset("test_key")
    assert config.get("test_key") is None


def test_config_hub_url(temp_config_dir):
    """Test hub URL configuration"""
    config = Config()
    config.config_dir = temp_config_dir
    config.config_file = temp_config_dir / "config.json"
    
    config.hub_url = "http://custom-hub.com"
    assert config.hub_url == "http://custom-hub.com"


def test_config_tokens(temp_config_dir):
    """Test token configuration"""
    config = Config()
    config.config_dir = temp_config_dir
    config.config_file = temp_config_dir / "config.json"
    
    config.access_token = "test-access-token"
    config.refresh_token = "test-refresh-token"
    
    assert config.access_token == "test-access-token"
    assert config.refresh_token == "test-refresh-token"
    
    config.clear_auth()
    assert config.access_token is None
    assert config.refresh_token is None


def test_get_client():
    """Test get_client function"""
    with patch('aphub.cli.get_config') as mock_get_config:
        mock_config = Mock()
        mock_config.hub_url = "http://test.com"
        mock_config.access_token = "test-token"
        mock_config.api_key = None
        mock_config.refresh_token = None
        mock_get_config.return_value = mock_config
        
        client = get_client()
        assert client.base_url == "http://test.com"


def test_progress_bar():
    """Test progress bar creation"""
    from aphub.progress import create_progress_bar
    
    progress, callback = create_progress_bar("Test")
    assert progress is not None
    assert callback is not None
    
    # Test callback
    callback(50, 100)
    # Should not raise


@pytest.mark.skip(reason="Requires actual API or mock server")
def test_login_command():
    """Test login command"""
    # This would require mocking httpx or using a test server
    pass


@pytest.mark.skip(reason="Requires actual API or mock server")
def test_push_command():
    """Test push command"""
    # This would require mocking httpx or using a test server
    pass

