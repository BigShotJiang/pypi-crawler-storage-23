Single-shot API
===============

Single-shot seal/open and export APIs (RFC 9180 §6).

.. automodule:: rfc9180.single_shot
   :members:
   :undoc-members:
   :show-inheritance:
