Context
=======

HPKE encryption contexts (RFC 9180 §5.2). Sender and recipient contexts for seal/open and export.

.. automodule:: rfc9180.context
   :members:
   :undoc-members:
   :show-inheritance:
