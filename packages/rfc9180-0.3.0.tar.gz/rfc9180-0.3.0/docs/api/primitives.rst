Primitives
==========

KEM, KDF, and AEAD primitives used by HPKE.

KEM (Key Encapsulation Mechanism)
---------------------------------

.. automodule:: rfc9180.primitives.kem
   :members:
   :undoc-members:
   :show-inheritance:

KDF (Key Derivation Function)
-----------------------------

.. automodule:: rfc9180.primitives.kdf
   :members:
   :undoc-members:
   :show-inheritance:

AEAD
----

.. automodule:: rfc9180.primitives.aead
   :members:
   :undoc-members:
   :show-inheritance:
