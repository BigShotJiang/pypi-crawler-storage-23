Setup
=====

HPKE setup functions (RFC 9180 §5.1). Creates encryption contexts for each mode.

.. automodule:: rfc9180.setup
   :members:
   :undoc-members:
   :show-inheritance:
