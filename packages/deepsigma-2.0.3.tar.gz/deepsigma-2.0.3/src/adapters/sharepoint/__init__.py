"""SharePoint connector for DeepSigma canonical record ingestion."""
from adapters.sharepoint.connector import SharePointConnector

__all__ = ["SharePointConnector"]
