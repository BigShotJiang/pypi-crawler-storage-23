"""OpenTelemetry adapter for Σ OVERWATCH."""
