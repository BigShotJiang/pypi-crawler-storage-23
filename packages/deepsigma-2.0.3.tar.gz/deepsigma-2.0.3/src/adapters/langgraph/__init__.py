# adapters/langgraph — LangGraph trace connector for Coherence Ops evidence.
