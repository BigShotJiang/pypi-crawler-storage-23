"""Power Platform / Dataverse connector for DeepSigma canonical record ingestion."""
from adapters.powerplatform.connector import DataverseConnector

__all__ = ["DataverseConnector"]
