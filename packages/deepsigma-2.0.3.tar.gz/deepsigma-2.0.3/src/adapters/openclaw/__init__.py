"""OpenClaw adapter for Σ OVERWATCH."""
