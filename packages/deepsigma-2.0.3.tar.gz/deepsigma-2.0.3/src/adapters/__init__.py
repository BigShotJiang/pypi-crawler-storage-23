"""Σ OVERWATCH adapters — integration bridges for external platforms."""
