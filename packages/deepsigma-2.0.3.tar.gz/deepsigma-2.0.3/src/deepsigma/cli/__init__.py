"""DeepSigma unified CLI."""
