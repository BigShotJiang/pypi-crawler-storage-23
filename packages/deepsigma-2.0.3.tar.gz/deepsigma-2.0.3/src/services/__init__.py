"""DeepSigma services — SPARQL, RDF, and semantic query layer."""
