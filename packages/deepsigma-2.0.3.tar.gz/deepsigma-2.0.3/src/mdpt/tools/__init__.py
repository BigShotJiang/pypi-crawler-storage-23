"""MDPT tools — generators and validators."""
