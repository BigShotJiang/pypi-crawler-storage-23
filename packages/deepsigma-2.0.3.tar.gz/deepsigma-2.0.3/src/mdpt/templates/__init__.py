"""MDPT templates — JSON schemas and starter templates."""
