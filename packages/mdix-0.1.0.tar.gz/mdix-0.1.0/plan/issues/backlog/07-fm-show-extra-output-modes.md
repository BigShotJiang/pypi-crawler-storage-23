---
id: mdix-07
title: "Defer: add mdix fm show --raw/--normalized output modes"
type: task
status: open
priority: P3
parent: null
depends_on: []
labels:
  - backlog
  - frontmatter
---

## Goal
Add additional `mdix fm show` output formats beyond the Sprint 1 minimal slice.

## Deferred scope
- `--raw`: output the original YAML frontmatter block as-is
- `--normalized`: pretty-print and sort frontmatter YAML in a canonical form

## Notes
This is explicitly deferred from Sprint 1 to keep the initial "self-hosted issue management" slice small.

