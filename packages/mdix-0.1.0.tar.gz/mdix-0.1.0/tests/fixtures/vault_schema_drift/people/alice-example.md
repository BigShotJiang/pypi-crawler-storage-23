---
title: "Alice Example"
type: person
rolle: "Research Lead"
kontakt_email: "alice@example.com"
status: zu_kontaktieren
---

Alice is an example person note with legacy keys.
