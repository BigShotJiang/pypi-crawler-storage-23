---
title: "Missing Type"
position: "Analyst"
status: lead
---

This note intentionally omits a required type field.
