---
title: "Bob Example"
type: person
position: "Operator"
kontakt:
  email: "bob@example.com"
status: identified
---

Bob already uses canonical fields.
