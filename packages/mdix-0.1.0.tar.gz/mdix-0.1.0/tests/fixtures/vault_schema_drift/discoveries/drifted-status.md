---
title: "Drifted Status"
type: discovery
status: active
legacy_note: null
---

This note intentionally uses a non-canonical status value.
