---
title: "Marie Curie"
type: person
tags:
  - physics
  - chemistry
status: active
---

Marie Curie pioneered research on radioactivity.
