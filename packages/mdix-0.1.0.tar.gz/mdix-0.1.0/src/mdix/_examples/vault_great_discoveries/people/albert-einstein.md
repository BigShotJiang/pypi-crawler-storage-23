---
title: "Albert Einstein"
type: person
tags:
  - physics
  - relativity
status: active
---

Albert Einstein developed the theory of general relativity.
