---
title: "Einstein 1915 Paper"
type: media
tags:
  - paper
  - relativity
---

The 1915 paper presents the field equations of general relativity.
