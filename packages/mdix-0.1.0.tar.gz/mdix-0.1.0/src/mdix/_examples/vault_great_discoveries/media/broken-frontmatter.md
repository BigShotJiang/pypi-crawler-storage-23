---
title: "Broken Frontmatter Example"
type: media
tags: [paper
---

This note intentionally contains malformed YAML frontmatter.
