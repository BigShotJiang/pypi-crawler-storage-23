Chemistry studies the composition and behavior of substances.
