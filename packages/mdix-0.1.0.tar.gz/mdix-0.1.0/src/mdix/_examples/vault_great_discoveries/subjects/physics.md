---
title: "Physics"
type: subject
tags:
  - science
---

Physics studies matter, energy, and the laws of nature.
