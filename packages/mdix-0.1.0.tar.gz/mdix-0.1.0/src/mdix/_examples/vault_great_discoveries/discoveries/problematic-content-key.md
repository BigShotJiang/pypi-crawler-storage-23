---
title: "Problematic Metadata Example"
type: discovery
content: this key triggers a parser edge case in python-frontmatter
---

This note intentionally contains a frontmatter key that conflicts with parser internals.
