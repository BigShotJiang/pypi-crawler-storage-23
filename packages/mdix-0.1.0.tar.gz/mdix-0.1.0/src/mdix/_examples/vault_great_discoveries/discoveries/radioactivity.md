---
title: "Radioactivity"
type: discovery
tags:
  - physics
  - chemistry
status: active
---

Radioactivity describes spontaneous nuclear decay.
