---
title: "General Relativity"
type: discovery
tags:
  - physics
status: active
---

General relativity explains gravitation as the geometry of spacetime.
