---
title: "Form Energy"
type: company
status: active
tags: ["manufacturer", "long-duration", "iron-air", "usa"]
hq: "Berkeley, California, USA"
focus: ["iron-air batteries", "multi-day energy storage", "manufacturing"]
---

# Form Energy

An American energy storage company developing [[iron-air-battery]] technology for multi-day grid storage. Founded in 2017. Backed by investors including Breakthrough Energy Ventures, ArcelorMittal, and Prelude Ventures.
([Form Energy website](https://formenergy.com))

## Technology

Form Energy's iron-air battery targets 100+ hours of discharge duration at approximately [$250/kWh installed cost](https://formenergy.com/technology/), using iron, water, and air as primary materials. This positions it for use cases where lithium-ion is uneconomic: replacing fossil peakers that run for multi-day stretches during renewable droughts.

## Manufacturing

[Form Factory 1](https://formenergy.com/updates/) opened in Weirton, West Virginia, on a [converted 55-acre former Weirton Steel site](https://formenergy.com/updates/). It began production in mid-to-late 2024 and initially employs ~300 people across ~550,000 sq ft. An expansion announced in October 2024 will add nearly 300,000 sq ft, targeting 750+ employees and at least 500 MW of annual production capacity by end of 2025.

In September 2024, the company received a [$150 million grant from the US Department of Energy](https://www.energy.gov/lpo/form-energy) to fund a new manufacturing line with capacity up to 20 GWh by 2027. Approximately [80% of all components are sourced domestically](https://formenergy.com/updates/).

## Deployments

Form Energy has announced projects in Minnesota, Colorado, California, New York, Georgia, and Virginia, expected to become operational in 2025 and 2026. As of early 2025, no projects have publicly reported full commissioning at commercial scale.

## Safety

The iron-air battery technology [passed UL9540A safety testing](https://formenergy.com/updates/) with no thermal runaway, uncontrolled heating, or fire, even under extreme fault conditions such as continuous overcharging for seven days. The water-based electrolyte is non-flammable.

## Sources

- [Form Energy: Technology](https://formenergy.com/technology/)
- [Form Energy: Updates](https://formenergy.com/updates/)
- [DOE Loan Programs Office: Form Energy](https://www.energy.gov/lpo/form-energy)

## Related

[[iron-air-battery]], [[round-trip-efficiency]]
