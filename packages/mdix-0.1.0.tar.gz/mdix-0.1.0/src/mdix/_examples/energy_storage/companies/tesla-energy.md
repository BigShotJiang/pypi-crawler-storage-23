---
title: "Tesla Energy"
type: company
status: active
tags: ["manufacturer", "bess", "inverter", "usa"]
hq: "Austin, Texas, USA"
focus: ["utility-scale BESS", "residential storage", "solar"]
---

# Tesla Energy

The energy storage and generation division of Tesla, Inc. Produces Powerwall (residential), Powerpack (commercial), and Megapack (utility-scale) battery systems, alongside Solar Roof and solar panel products.

## Key products

**Megapack** is the primary utility-scale product:
- Single unit: ~3.9 MWh energy, ~1.9 MW power
- LFP chemistry (transitioned from NCA as of 2021-2022)
- Integrated Autobidder software for automated market participation

**Powerwall 3** (~13.5 kWh, residential) and **Powerpack** (smaller commercial).

## Manufacturing

The [Megafactory in Lathrop, California](https://en.wikipedia.org/wiki/Tesla_Megapack) is dedicated to Megapack production. Tesla reached an [annualized production rate of 40 GWh/year (~10,000 Megapacks/year) by end of 2024](https://www.utilitydive.com/news/tesla-energy-deploys-company-record-94-gwh-of-storage-in-q2-2024/720823/) after adding a second assembly line. A second Megafactory in Shanghai was announced with a similar 40 GWh/year target starting Q1 2025.

In Q2 2024, Tesla Energy [deployed a company-record 9.4 GWh of storage in a single quarter](https://www.utilitydive.com/news/tesla-energy-deploys-company-record-94-gwh-of-storage-in-q2-2024/720823/).

## Notable deployments

- [[hornsdale-power-reserve]] (150 MW / 193.5 MWh) - landmark early project
- Elkhorn Battery, Pacific Gas & Electric, CA (182.5 MW / 730 MWh)

## Market position

Tesla Energy is one of the top three BESS suppliers globally by GWh shipped. Competitors at utility scale include [[fluence]], BYD, CATL-backed projects, and Sungrow.

## Sources

- [Wikipedia: Tesla Megapack](https://en.wikipedia.org/wiki/Tesla_Megapack)
- [Utility Dive: Tesla Energy deploys company-record 9.4 GWh in Q2 2024](https://www.utilitydive.com/news/tesla-energy-deploys-company-record-94-gwh-of-storage-in-q2-2024/720823/)
- [ESS News: Tesla smashes records with big increase in energy storage deployments in 2024](https://www.ess-news.com/2025/01/03/tesla-smashes-its-own-records-with-big-increase-in-energy-storage-deployments-in-2024/)

## Related

[[lithium-ion-battery]], [[fluence]], [[catl]]
