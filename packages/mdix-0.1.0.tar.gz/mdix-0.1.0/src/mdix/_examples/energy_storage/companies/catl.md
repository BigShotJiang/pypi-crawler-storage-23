---
title: "CATL (Contemporary Amperex Technology)"
type: company
status: active
tags: ["manufacturer", "cells", "china", "ev", "grid-scale"]
hq: "Ningde, Fujian, China"
focus: ["EV batteries", "energy storage systems", "cell manufacturing"]
---

# CATL (Contemporary Amperex Technology Co. Limited)

The world's largest manufacturer of lithium-ion battery cells by volume, serving both EV and stationary energy storage markets. Founded in 2011 by Robin Zeng, originally spun off from ATL (Amperex Technology Limited).

## Scale (2024)

- **Revenue**: ~362 billion RMB (~$50B USD), down ~10% YoY due to price competition
- **Net profit**: ~50.7 billion RMB (+15% YoY)
- **EV battery global market share**: [~37.9%](https://en.wikipedia.org/wiki/CATL), China share ~46%
- **Energy storage battery global shipment share**: [~36.5%](https://en.wikipedia.org/wiki/CATL), applied in over 1,700 projects
- **LFP global market share**: [~37% in 2024-2025](https://www.grandviewresearch.com/industry-analysis/lithium-iron-phosphate-battery-market)
- **Cumulative EV installations**: >17 million units
- **R&D spend**: 18.6 billion RMB; 43,000+ patents

## Products for stationary storage

- **EnerOne / EnerC**: containerized utility-scale BESS using LFP cells
- **TENER** (announced 2024): 5 MWh container, targets zero-capacity-degradation guarantee over 5 years

Cell-level prices from CATL reached approximately [$50-60/kWh at the cell level in 2024](https://www.energy-storage.news/catl-tener-battery-energy-storage-system-launch/), driving aggressive global pricing pressure.

## Technology

CATL's cell-to-pack (CTP) technology reduces the number of components between cell and pack, improving volumetric energy density by 15-20% and reducing cost. CTP has become an industry benchmark.

Sodium-ion cells are in early commercial production at CATL but not yet at scale for stationary storage.

## Geopolitical context

US tariffs and export controls on Chinese battery technology limit CATL's direct presence in North American utility projects, though some CATL cells reach the US through third-party integrators. CATL announced a technology licensing arrangement with Ford's BlueOval battery subsidiary to build a factory in Marshall, Michigan.

## Sources

- [Wikipedia: CATL](https://en.wikipedia.org/wiki/CATL)
- [Energy-Storage.news: CATL TENER system launch](https://www.energy-storage.news/catl-tener-battery-energy-storage-system-launch/)

## Related

[[lithium-ion-battery]], [[tesla-energy]], [[fluence]]
