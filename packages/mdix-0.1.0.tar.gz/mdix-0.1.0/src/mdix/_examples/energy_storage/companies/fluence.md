---
title: "Fluence Energy"
type: company
status: active
tags: ["integrator", "bess", "software", "usa"]
hq: "Arlington, Virginia, USA"
focus: ["utility-scale BESS integration", "storage software", "AI bidding"]
---

# Fluence Energy

A global energy storage technology and services company (NASDAQ: FLNC) formed as a joint venture between AES Corporation and Siemens in January 2018. Went public in November 2021. ([Wikipedia](https://en.wikipedia.org/wiki/Fluence_Energy))

Fluence is a system integrator and software provider rather than a cell manufacturer. It sources cells from multiple suppliers and delivers the full stack from hardware to bidding software.

## Ownership

[AES Grid Stability holds 28.5% of economic interest with 66.6% voting power; Siemens holds 28.5% economic interest with 13.3% voting power](https://fluenceenergy.com/investor-relations/).

## Products

**Gridstack** - modular utility-scale BESS:
- Cells sourced from multiple manufacturers (historically Samsung SDI, LG Energy Solution, others)
- DC-coupled and AC-coupled configurations

**Fluence IQ (Mosaic)** - AI-powered bidding and optimization software:
- Autonomous multi-market participation (energy, ancillary services, capacity)
- Available as a managed service on third-party assets, not just Fluence hardware

## Market position and deployments

As of September 30, 2024, Fluence [operates in 50 markets worldwide with 5.0 GW of energy storage assets deployed](https://fluenceenergy.com/investor-relations/). Prior to the JV's formation, AES and Siemens had deployed 48 projects totaling 463 MW across 13 countries.

Fluence was the integrator for the [[moss-landing-energy-storage]] facility (LG Energy Solution cells), which experienced a significant fire in January 2025 that is under investigation.

## Revenue model

Revenue from hardware sales, long-term service agreements (LTSA), and Fluence IQ software subscriptions. The software business provides some recurring revenue independent of hardware deployment.

## Sources

- [Wikipedia: Fluence Energy](https://en.wikipedia.org/wiki/Fluence_Energy)
- [Fluence investor relations](https://fluenceenergy.com/investor-relations/)

## Related

[[tesla-energy]], [[catl]], [[lithium-ion-battery]], [[moss-landing-energy-storage]]
