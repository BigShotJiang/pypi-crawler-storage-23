---
title: "Bath County Pumped Storage Station"
type: project
status: active
tags: ["pumped-hydro", "grid-scale", "usa", "long-duration"]
location: "Bath County, Virginia, USA"
capacity_mwh: 24000
power_mw: 3003
technology: "[[pumped-hydro-storage]]"
year_commissioned: 1985
---

# Bath County Pumped Storage Station

The largest pumped hydro facility in North America and formerly the world's largest (surpassed by Fengning, China in 2021). Owned 60% by Dominion Energy and 40% by FirstEnergy, and operated by Dominion. Located in the Allegheny Mountains of western Virginia.
([Wikipedia](https://en.wikipedia.org/wiki/Bath_County_Pumped_Storage_Station))

## Specifications

- **Power**: [3,003 MW](https://en.wikipedia.org/wiki/Bath_County_Pumped_Storage_Station) from 6 reversible pump-turbine units, each 500-505 MW
- **Energy**: ~24,000 MWh (upper reservoir full to empty, roughly 3 hours at full power)
- **Round-trip efficiency**: ~80% (consumes 5 kW to generate 4 kW)
- **Elevation difference**: >1,100 feet between upper and lower reservoirs
- **Upper reservoir**: 278 surface acres, 105-foot operating range
- **Generating flow**: up to 13.5 million gallons per minute
- **Pumping flow**: up to 12.7 million gallons per minute

([Wikipedia](https://en.wikipedia.org/wiki/Bath_County_Pumped_Storage_Station))

## Construction and cost

Construction began March 1977 and was completed December 1985 at a cost of [$1.6 billion](https://en.wikipedia.org/wiki/Bath_County_Pumped_Storage_Station). Between 2004 and 2009, Voith-Siemens upgraded the turbines to increase capacity to 3,003 MW. The plant can have one unit online in 6 minutes and all six units operating within 15 minutes.

## Operations

The plant stores energy for PJM Interconnection, the regional transmission organization serving 13 states and DC. Historically charged overnight off baseload coal and nuclear; increasingly charges during solar midday periods as the grid decarbonizes. The upper reservoir empties in roughly 3 hours at full generation. The plant performs more than 4,000 generator starts annually.

## FERC relicensing

The plant's FERC operating license expires December 27, 2026, triggering a relicensing process with updated environmental review requirements.

## Sources

- [Wikipedia: Bath County Pumped Storage Station](https://en.wikipedia.org/wiki/Bath_County_Pumped_Storage_Station)

## Related

[[pumped-hydro-storage]], [[round-trip-efficiency]]
