---
title: "Moss Landing Energy Storage Facility"
type: project
status: active
tags: ["bess", "grid-scale", "california", "lithium-ion"]
location: "Moss Landing, California, USA"
capacity_mwh: 3000
power_mw: 750
technology: "[[lithium-ion-battery]]"
year_commissioned: 2021
---

# Moss Landing Energy Storage Facility

The world's largest battery energy storage facility by power and energy capacity, owned and operated by [Vistra Corp](https://www.vistracorp.com) on the site of a decommissioned gas plant in Monterey County, California. Uses LG Energy Solution cells integrated by [[fluence]].

## Capacity and phases

The facility was built in three phases:

- **Phase 1** (August 2021): 182.5 MW / 730 MWh
- **Phase 2** (2022): +182.5 MW / +730 MWh
- **Phase 3** (June 2023): +350 MW / +1,400 MWh - total **750 MW / 3,000 MWh**

([Utility Dive](https://www.utilitydive.com/news/moss-landing-battery-fire-vistra/737837/))

The site reuses infrastructure from the Moss Landing Power Plant, which has operated since 1950, including existing grid interconnection in a corridor between San Francisco and Los Angeles.

## Role in California's grid

California's grid operator (CAISO) increasingly relies on storage to manage the "duck curve" - the steep ramp in demand as solar generation falls in the late afternoon. The Moss Landing facility is large enough to materially shift this ramp. Revenue streams include CAISO ancillary services, energy arbitrage, and resource adequacy contracts.

By September 2024, [California had 13,391 MW of cumulative battery storage capacity](https://www.utilitydive.com/news/moss-landing-battery-fire-vistra/737837/), adding 7,000+ MW in 2024 alone.

## Fire incident (January 2025)

On January 16, 2025, a major fire broke out in the Phase 1 battery array, with [flames reaching up to 100 feet high](https://www.utilitydive.com/news/moss-landing-battery-fire-vistra/737837/). The fire destroyed approximately 75-100% of the 300 MW indoor array and prompted evacuation of roughly 1,200 nearby residents. Highway 1 was closed; no injuries were reported.

The incident was [the fourth fire-related event at the site since 2020](https://www.canarymedia.com/articles/energy-storage/moss-landing-fire-reveals-flaws-in-the-battery-industrys-early-designs) and prompted scrutiny of lithium-ion BESS fire suppression design, particularly for indoor installations. The EPA oversaw battery removal and cleanup, with de-energization complete by March 2025.
([EPA response page](https://www.epa.gov/ca/moss-landing-vistra-battery-fire))

## Sources

- [Utility Dive: Moss Landing battery fire sparks calls to improve safety](https://www.utilitydive.com/news/moss-landing-battery-fire-vistra/737837/)
- [Canary Media: Moss Landing fire reveals flaws in the battery industry's early designs](https://www.canarymedia.com/articles/energy-storage/moss-landing-fire-reveals-flaws-in-the-battery-industrys-early-designs)
- [EPA: Moss Landing Vistra Battery Fire Response](https://www.epa.gov/ca/moss-landing-vistra-battery-fire)

## Related

[[lithium-ion-battery]], [[fluence]]
