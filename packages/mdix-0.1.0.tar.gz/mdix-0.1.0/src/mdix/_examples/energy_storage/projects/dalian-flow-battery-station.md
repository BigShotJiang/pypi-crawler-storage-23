---
title: "Dalian Flow Battery Energy Storage Station"
type: project
status: active
tags: ["vanadium-flow", "grid-scale", "china", "long-duration"]
location: "Shahekou District, Dalian, Liaoning Province, China"
capacity_mwh: 400
power_mw: 100
technology: "[[vanadium-flow-battery]]"
year_commissioned: 2022
---

# Dalian Flow Battery Energy Storage Station

The world's largest vanadium redox flow battery (VRFB) installation at the time of commissioning, built by [Dalian Rongke Energy Storage Technology Development Co., Ltd.](https://rkpstorage.com/projects/) A national demonstration project approved by China's National Energy Administration (NEA).

([CNESA](http://en.cnesa.org/new-blog/2022/7/19/after-6-years-the-100mw400mwh-redox-flow-battery-storage-project-in-dalian-is-connected-to-the-grid), [PV Magazine](https://www.pv-magazine.com/2022/09/29/china-connects-worlds-largest-redox-flow-battery-system-to-grid/))

## Specifications (Phase 1)

- **Power**: 100 MW
- **Energy**: 400 MWh (4-hour duration)
- **Chemistry**: All-vanadium redox flow
- **Grid connection**: [May 24, 2022; commercial operations from October 2022](http://en.cnesa.org/new-blog/2022/7/19/after-6-years-the-100mw400mwh-redox-flow-battery-storage-project-in-dalian-is-connected-to-the-grid)
- **Cost**: approximately [CNY 1.9 billion (~$266 million) for Phase 1](http://en.cnesa.org/new-blog/2022/7/19/after-6-years-the-100mw400mwh-redox-flow-battery-storage-project-in-dalian-is-connected-to-the-grid)
- **Full project plan**: 200 MW / 800 MWh

## Technology background

The project originated from research at the [Dalian Institute of Chemical Physics, Chinese Academy of Sciences](https://english.cas.cn/Special_Reports/rd/2022/202410/t20241031_693355.shtml), which has worked on vanadium flow technology since the 1990s. Rongke Power was spun out from that research base.

## Purpose and grid services

The station supports grid peak-shaving, stores renewable energy as chemical energy in vanadium electrolytes, and provides frequency regulation. [400 MWh can supply approximately 200,000 residents for one day](https://www.pv-magazine.com/2022/09/29/china-connects-worlds-largest-redox-flow-battery-system-to-grid/). The project has also [demonstrated black-start capability for thermal generation units](http://en.cnesa.org/new-blog/2022/7/19/after-6-years-the-100mw400mwh-redox-flow-battery-storage-project-in-dalian-is-connected-to-the-grid) after grid failure.

## Context: subsequent projects

Larger VRFB projects have since been announced and commissioned in China. A [175 MW / 700 MWh project came online in 2024, and a 200 MW / 1,000 MWh project in 2025](https://www.ess-news.com/2026/01/07/china-connects-worlds-largest-vanadium-flow-battery-project/), reflecting continued scale-up of the technology by Chinese developers.

## Sources

- [CNESA: 100MW/400MWh Redox Flow Battery Project Connected to the Grid](http://en.cnesa.org/new-blog/2022/7/19/after-6-years-the-100mw400mwh-redox-flow-battery-storage-project-in-dalian-is-connected-to-the-grid)
- [PV Magazine: China connects world's largest redox flow battery system to grid](https://www.pv-magazine.com/2022/09/29/china-connects-worlds-largest-redox-flow-battery-system-to-grid/)
- [Chinese Academy of Sciences: World's Largest Flow Battery Energy Storage Station](https://english.cas.cn/Special_Reports/rd/2022/202410/t20241031_693355.shtml)
- [Rongke Power: Milestone Projects](https://rkpstorage.com/projects/)
- [ESS News: China connects world's largest vanadium flow battery project (2026)](https://www.ess-news.com/2026/01/07/china-connects-worlds-largest-vanadium-flow-battery-project/)

## Related

[[vanadium-flow-battery]], [[round-trip-efficiency]]
