---
title: "Hornsdale Power Reserve"
type: project
status: active
tags: ["bess", "grid-services", "australia", "lithium-ion"]
location: "South Australia, Australia"
capacity_mwh: 193.5
power_mw: 150
technology: "[[lithium-ion-battery]]"
year_commissioned: 2017
---

# Hornsdale Power Reserve

A grid-scale battery energy storage system (BESS) in South Australia, roughly 16 km north of Jamestown. Built by Neoen using Tesla Megapack hardware, it was the world's largest utility-scale battery when commissioned in November 2017.
([Wikipedia](https://en.wikipedia.org/wiki/Hornsdale_Power_Reserve), [official site](https://hornsdalepowerreserve.com.au))

## Capacity

- **Phase 1** (December 2017): 100 MW / 129 MWh
- **Phase 2** (September 2020): +50 MW / +64.5 MWh
- **Total**: 150 MW / 193.5 MWh

([ARENA project summary](https://arena.gov.au/knowledge-bank/neoen-hornsdale-power-reserve-upgrade-project-summary-report/))

## Grid services provided

The HPR provides multiple stacked revenue streams:

- **Frequency Control Ancillary Services (FCAS)**: In its first six months, it was responsible for [55% of frequency control and ancillary services in South Australia](https://hornsdalepowerreserve.com.au).
- **Synthetic inertia (Virtual Machine Mode)**: Upgraded in July 2022 to provide approximately [2,000 MWs of grid inertia](https://arena.gov.au/knowledge-bank/neoen-hornsdale-power-reserve-upgrade-project-summary-report/), roughly 15% of South Australia's total grid requirement.
- **Energy arbitrage**: Charges from co-located Hornsdale Wind Farm, discharges at peak prices.
- **Emergency backstop**: Contracted under the SA Government's Grid Scale Storage agreement.

## Economic and policy significance

The HPR was partly catalyzed by a public bet: Elon Musk promised to deliver the 100 MW system in 100 days or it would be free. It was commissioned on time.

In its first two years of operation, the HPR [saved South Australian consumers over AUD 150 million](https://www.cefc.com.au/case-studies/sa-big-battery-a-pioneering-grid-game-changer/) in FCAS costs. The expansion received AUD 15 million from the SA Government's Grid Scale Storage Fund and AUD 8 million in ARENA grant funding.

## Sources

- [Hornsdale Power Reserve official site](https://hornsdalepowerreserve.com.au)
- [Wikipedia: Hornsdale Power Reserve](https://en.wikipedia.org/wiki/Hornsdale_Power_Reserve)
- [ARENA project summary report](https://arena.gov.au/knowledge-bank/neoen-hornsdale-power-reserve-upgrade-project-summary-report/)
- [CEFC case study](https://www.cefc.com.au/case-studies/sa-big-battery-a-pioneering-grid-game-changer/)

## Related

[[tesla-energy]], [[lithium-ion-battery]]
