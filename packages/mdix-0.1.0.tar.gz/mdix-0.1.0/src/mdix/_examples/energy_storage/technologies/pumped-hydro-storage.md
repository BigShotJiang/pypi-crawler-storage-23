---
title: "Pumped Hydro Storage"
type: technology
status: active
tags: ["mechanical", "mature", "grid-scale", "long-duration"]
round_trip_efficiency_pct: "70-85"
typical_duration_hours: "6-20"
maturity: mature
---

# Pumped Hydro Storage

The largest installed form of grid energy storage globally, [accounting for roughly 90% of worldwide storage capacity by energy](https://www.iea.org/reports/hydropower-special-market-report) (IEA). Water is pumped from a lower reservoir to an upper reservoir during off-peak periods and released through turbines to generate electricity on demand.
([Wikipedia](https://en.wikipedia.org/wiki/Pumped-storage_hydroelectricity))

## Scale and footprint

Individual plants range from tens of MW to several GW. [[bath-county-pumped-storage]] at 3,003 MW is [the largest in North America](https://en.wikipedia.org/wiki/Bath_County_Pumped_Storage_Station). The [Fengning Pumped Storage Power Station in China (3,600 MW)](https://en.wikipedia.org/wiki/Fengning_Pumped_Storage_Power_Station) surpassed it in 2021 as the world's largest.

Reservoirs can store many hours to days of energy, making pumped hydro the natural benchmark for long-duration storage economics.

## Economics

Very site-constrained. New greenfield projects require suitable topography (elevation difference), water rights, and regulatory approval - permitting typically takes 10-15 years in the US and EU. Once built, plants have very long operational lives (50-100 years) and low operating costs.

[Capital costs range from $500-4,500/kWh depending on site](https://www.iea.org/reports/hydropower-special-market-report), with most recent projects at $1,000-2,000/kWh. The long life and low operating cost can make levelized cost of storage competitive with alternatives despite the high upfront cost.

## Variants

- **Closed-loop (off-river)**: No connection to a natural river; lower environmental impact, often faster permitting
- **Open-loop**: Connected to a natural watercourse; more hydrological constraints and environmental review
- **Underground**: Lower reservoir underground (mine or purpose-built cavern); relaxes geographic constraints, still rare

## Limitations

- Site-limited: not deployable everywhere
- Long development timelines (10-15 years for permitting in the US/EU)
- Ecosystem and water rights permitting
- Low energy density means large land footprint

## Sources

- [Wikipedia: Pumped-storage hydroelectricity](https://en.wikipedia.org/wiki/Pumped-storage_hydroelectricity)
- [IEA: Hydropower Special Market Report](https://www.iea.org/reports/hydropower-special-market-report)

## Related

[[bath-county-pumped-storage]], [[round-trip-efficiency]]
