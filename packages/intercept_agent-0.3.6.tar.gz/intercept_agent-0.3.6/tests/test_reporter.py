"""Tests for the reporter HTTP client."""

import asyncio
import logging
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from posture_agent.core.config import APIConfig, Settings
from posture_agent.models.report import PostureReportPayload
from posture_agent.services.reporter import send_report


def _make_payload() -> PostureReportPayload:
    """Create a minimal posture report payload for testing."""
    return PostureReportPayload(
        fingerprint="a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4",
        agent_version="0.3.6",
    )


def _make_settings(api_key: str = "", tenant_id: str = "") -> Settings:
    """Create a Settings object with a specific api_key for testing."""
    settings = MagicMock(spec=Settings)
    settings.api = APIConfig(
        url="http://localhost:8000",
        timeout=5,
        retries=1,
        api_key=api_key,
        tenant_id=tenant_id,
    )
    return settings


class TestReporterHeaderSelection:
    """Verify that the reporter sends the correct auth header based on key prefix."""

    def test_hsk_key_sends_x_api_key_header(self):
        """An hsk_ prefixed key should be sent as X-API-Key."""
        payload = _make_payload()
        settings = _make_settings(api_key="hsk_testkey00000000")

        captured_request = {}

        async def _mock_post(url, json=None, headers=None):
            captured_request["url"] = url
            captured_request["headers"] = dict(headers) if headers else {}
            captured_request["json"] = json
            response = MagicMock()
            response.raise_for_status = MagicMock()
            response.json.return_value = {"id": "report-1"}
            return response

        mock_client = AsyncMock()
        mock_client.post = _mock_post
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("posture_agent.services.reporter.httpx.AsyncClient", return_value=mock_client):
            result = asyncio.run(send_report(payload, settings))

        assert "X-API-Key" in captured_request["headers"]
        assert captured_request["headers"]["X-API-Key"] == "hsk_testkey00000000"
        assert "X-Service-Token" not in captured_request["headers"]
        assert result == {"id": "report-1"}

    def test_non_hsk_key_warns_and_sends_no_auth(self, caplog):
        """A key without the hsk_ prefix should log a warning and send no auth header."""
        payload = _make_payload()
        settings = _make_settings(api_key="my-invalid-key-value")

        captured_request = {}

        async def _mock_post(url, json=None, headers=None):
            captured_request["url"] = url
            captured_request["headers"] = dict(headers) if headers else {}
            response = MagicMock()
            response.raise_for_status = MagicMock()
            response.json.return_value = {"id": "report-2"}
            return response

        mock_client = AsyncMock()
        mock_client.post = _mock_post
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with caplog.at_level(logging.WARNING, logger="posture_agent.services.reporter"):
            with patch("posture_agent.services.reporter.httpx.AsyncClient", return_value=mock_client):
                asyncio.run(send_report(payload, settings))

        assert "X-API-Key" not in captured_request["headers"]
        assert "X-Service-Token" not in captured_request["headers"]
        assert any("does not start with 'hsk_'" in msg for msg in caplog.messages)

    def test_no_key_sends_no_auth_header(self):
        """When api_key is empty, no auth header should be sent."""
        payload = _make_payload()
        settings = _make_settings(api_key="")

        captured_request = {}

        async def _mock_post(url, json=None, headers=None):
            captured_request["headers"] = dict(headers) if headers else {}
            response = MagicMock()
            response.raise_for_status = MagicMock()
            response.json.return_value = {"id": "report-3"}
            return response

        mock_client = AsyncMock()
        mock_client.post = _mock_post
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("posture_agent.services.reporter.httpx.AsyncClient", return_value=mock_client):
            asyncio.run(send_report(payload, settings))

        assert "X-API-Key" not in captured_request["headers"]
        assert "X-Service-Token" not in captured_request["headers"]

    def test_hsk_key_omits_tenant_id_from_body(self):
        """When using hsk_ API key, tenant_id should NOT be in the body (API resolves it from the key)."""
        payload = _make_payload()
        settings = _make_settings(api_key="hsk_abc123", tenant_id="tenant-uuid-here")

        captured_request = {}

        async def _mock_post(url, json=None, headers=None):
            captured_request["json"] = json
            captured_request["headers"] = dict(headers) if headers else {}
            response = MagicMock()
            response.raise_for_status = MagicMock()
            response.json.return_value = {"id": "report-4"}
            return response

        mock_client = AsyncMock()
        mock_client.post = _mock_post
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("posture_agent.services.reporter.httpx.AsyncClient", return_value=mock_client):
            asyncio.run(send_report(payload, settings))

        assert "tenant_id" not in captured_request["json"]
        assert captured_request["headers"]["X-API-Key"] == "hsk_abc123"

    def test_tenant_id_included_when_no_api_key(self):
        """When no API key is set but tenant_id is configured, include it in the body (dev-local compat)."""
        payload = _make_payload()
        settings = _make_settings(api_key="", tenant_id="tenant-uuid-here")

        captured_request = {}

        async def _mock_post(url, json=None, headers=None):
            captured_request["json"] = json
            response = MagicMock()
            response.raise_for_status = MagicMock()
            response.json.return_value = {"id": "report-5"}
            return response

        mock_client = AsyncMock()
        mock_client.post = _mock_post
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("posture_agent.services.reporter.httpx.AsyncClient", return_value=mock_client):
            asyncio.run(send_report(payload, settings))

        assert captured_request["json"]["tenant_id"] == "tenant-uuid-here"

    def test_correct_url_constructed(self):
        """The reporter should POST to the correct posture reports endpoint."""
        payload = _make_payload()
        settings = _make_settings(api_key="hsk_url_test")

        captured_request = {}

        async def _mock_post(url, json=None, headers=None):
            captured_request["url"] = url
            response = MagicMock()
            response.raise_for_status = MagicMock()
            response.json.return_value = {"id": "ok"}
            return response

        mock_client = AsyncMock()
        mock_client.post = _mock_post
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("posture_agent.services.reporter.httpx.AsyncClient", return_value=mock_client):
            asyncio.run(send_report(payload, settings))

        assert captured_request["url"] == "http://localhost:8000/api/v1/core/posture/reports"
