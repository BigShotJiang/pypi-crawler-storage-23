"""Logging setup for the Posture Agent.

Uses stdlib logging (not loguru) to avoid adding dependencies to the
PyPI package. Matches the Intercept platform log format for consistency.
"""

import logging
import sys


def setup_agent_logging(logging_config: dict | None = None) -> None:
    """Configure logging for the posture agent.

    Args:
        logging_config: Dict from YAML "logging" section.
    """
    config = logging_config or {}
    level_str = config.get("level", "INFO").upper()
    level = getattr(logging, level_str, logging.INFO)

    console_config = config.get("console", {})
    console_format = console_config.get("format", "text")

    if console_format == "json":
        fmt = '{"timestamp":"%(asctime)s","level":"%(levelname)s","module":"%(name)s","function":"%(funcName)s","line":%(lineno)d,"message":"%(message)s"}'
    else:
        fmt = "%(asctime)s | %(levelname)-8s | %(name)s:%(funcName)s:%(lineno)d - %(message)s"

    logging.basicConfig(
        level=level,
        format=fmt,
        datefmt="%Y-%m-%d %H:%M:%S",
        stream=sys.stderr,
        force=True,
    )
