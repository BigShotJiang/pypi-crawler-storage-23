"""前端托管服务（与 npm FrontHostService 对齐，servicePath: gateway-h5）。"""
from typing import Any, Optional

from .base_client import BaseClient
from .types import ClientConfig, RequestOptions, TokenStorage


class FrontHostService(BaseClient):
    service_path = "gateway-h5"

    def __init__(
        self,
        config: ClientConfig,
        token_storage: Optional[TokenStorage] = None,
    ) -> None:
        super().__init__(config, token_storage=token_storage)

    @property
    def service_name(self) -> str:
        return "fronthost"

    def list_projects(
        self,
        params: Optional[dict] = None,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request("/projects", RequestOptions(
            method="GET",
            params=params or {},
        ))

    def create_project(
        self,
        request: dict,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request("/projects", RequestOptions(method="POST", body=request))

    def deploy(
        self,
        project_id: str,
        request: dict,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request(f"/projects/{project_id}/deploy", RequestOptions(
            method="POST",
            body=request,
        ))
