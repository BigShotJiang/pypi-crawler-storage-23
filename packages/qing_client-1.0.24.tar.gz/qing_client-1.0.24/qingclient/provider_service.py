"""Provider 服务（与 npm ProviderService 对齐）。"""
from typing import Any, Optional

from .base_client import BaseClient
from .types import ClientConfig, RequestOptions, TokenStorage


class ProviderService(BaseClient):
    service_path = "providers"

    def __init__(
        self,
        config: ClientConfig,
        token_storage: Optional[TokenStorage] = None,
    ) -> None:
        super().__init__(config, token_storage=token_storage)

    @property
    def service_name(self) -> str:
        return "provider"

    def list_providers(
        self,
        params: Optional[dict] = None,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request("", RequestOptions(
            method="GET",
            params=params or {},
        ))

    def get_provider(
        self,
        provider_id: str,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request(f"/{provider_id}", RequestOptions(method="GET"))

    def chat_completions(
        self,
        provider_id: str,
        request: dict,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request(f"/{provider_id}/chat/completions", RequestOptions(
            method="POST",
            body=request,
        ))
