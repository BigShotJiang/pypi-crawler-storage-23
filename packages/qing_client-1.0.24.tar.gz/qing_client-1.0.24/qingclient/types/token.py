"""Token 服务类型（与 npm token types 对齐）。"""
from dataclasses import dataclass
from typing import Optional


@dataclass
class WxOfficialAccountTokenResponse:
    access_token: str


@dataclass
class WxJsapiTicketResponse:
    jsapi_ticket: str


@dataclass
class WxSignatureRequest:
    appid: str
    url: str
    imgUrl: Optional[str] = None


@dataclass
class WxSignatureResponse:
    appId: str
    timestamp: int
    nonceStr: str
    signature: str
    url: str
    imgUrl: Optional[str] = None


@dataclass
class WxMiniProgramTokenResponse:
    access_token: str


@dataclass
class WxMiniProgramLoginResponse:
    openid: str
    session_key: str
    unionid: Optional[str] = None


@dataclass
class WxPhoneInfo:
    """微信小程序 getuserphonenumber 返回的 phone_info（字段与接口一致 camelCase）."""
    phoneNumber: Optional[str] = None
    purePhoneNumber: Optional[str] = None
    countryCode: Optional[str] = None


@dataclass
class WxMiniProgramPhoneResponse:
    """微信小程序获取手机号响应（与 token-service POST /wxmp/phone 对齐）."""
    phone_info: WxPhoneInfo
