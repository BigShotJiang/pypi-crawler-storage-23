"""Msg 服务类型（与 npm msg types 对齐）。"""
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class Message:
    id: Optional[str] = None
    _id: Optional[str] = None
    pid: Optional[str] = None
    aid: Optional[str] = None
    userId: Optional[str] = None
    title: str = ""
    content: str = ""
    type: str = "system"
    category: str = ""
    isRead: bool = False
    createdAt: Optional[str] = None
    updatedAt: Optional[str] = None
    readAt: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class MessageQueryParams:
    type: Optional[str] = None
    category: Optional[str] = None
    isRead: Optional[bool] = None
    page: Optional[int] = None
    limit: Optional[int] = None
    userId: Optional[str] = None
    pid: Optional[str] = None
    aid: Optional[str] = None


@dataclass
class MessageTypeItem:
    type: str
    label: Optional[str] = None


@dataclass
class CategoryInfo:
    category: str
    unreadCount: int
    latestMessage: Optional[Dict[str, Any]] = None


@dataclass
class MessageStats:
    total: int
    byCategory: Optional[Dict[str, int]] = None


@dataclass
class BatchMarkAsReadRequest:
    messageIds: List[str]
    userId: Optional[str] = None


@dataclass
class CreateMessageRequest:
    title: str
    content: str
    type: str
    category: str
    userId: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


@dataclass
class BatchCreateMessageRequest:
    messages: List[Dict[str, Any]]


@dataclass
class SendFeishuRequest:
    url: str
    elements: List[Dict[str, Any]]
    title: Optional[str] = None
    bgColor: Optional[str] = None
    noticeUser: Optional[List[Dict[str, Any]]] = None
    actions: Optional[List[Dict[str, Any]]] = None


@dataclass
class SendSmsCodeRequest:
    phone: str
    scene: Optional[str] = None


@dataclass
class VerifySmsCodeRequest:
    phone: str
    code: str
    scene: Optional[str] = None
