"""Auth 服务类型（与 npm auth types 对齐）。"""
from dataclasses import dataclass
from typing import Optional


@dataclass
class LoginResponse:
    access_token: str
    token_type: str
    expires_at: str
    project_id: int
    org_id: Optional[str] = None
    app_id: Optional[str] = None


@dataclass
class LoginCredentials:
    username: str
    password: str
    org_id: Optional[str] = None
    app_id: Optional[str] = None


@dataclass
class WechatLoginCredentials:
    code: str
    phone_code: Optional[str] = None
    org_id: Optional[str] = None
    app_id: Optional[str] = None


@dataclass
class RegisterRequest:
    username: str
    email: str
    password: str
    name: Optional[str] = None
    phone: Optional[str] = None
    org_id: Optional[str] = None
    app_id: Optional[str] = None


@dataclass
class TemporaryTokenRequest:
    expires_in: Optional[int] = None  # 60-3600 秒


@dataclass
class TemporaryTokenResponse:
    temporary_token: str
    expires_at: str
    expires_in: int


@dataclass
class VerifyTemporaryTokenRequest:
    temporary_token: str


@dataclass
class VerifyTemporaryTokenResponse:
    valid: bool
    user_id: Optional[str] = None
    expires_at: Optional[str] = None


@dataclass
class TokenInfoResponse:
    sub: str
    exp: int
    expires_at: str
    project_id: int
    role: str
    token_type: str
    org_id: Optional[str] = None
    app_id: Optional[str] = None


@dataclass
class RevokeTokenResponse:
    revoked: bool
    message: Optional[str] = None
