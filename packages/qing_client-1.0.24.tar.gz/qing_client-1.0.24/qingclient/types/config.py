"""客户端配置：网关/后端模式、各服务地址。"""
from dataclasses import dataclass
from typing import Optional

from .base import UserContext, TokenStorage


@dataclass
class ClientConfig:
    """与 npm ClientConfig 对齐。"""

    # ========== 前端/网关模式 ==========
    gateway_url: Optional[str] = None
    project_id: Optional[str] = None
    org_id: Optional[str] = None
    app_id: Optional[str] = None

    # ========== 后端模式 - 各服务地址 ==========
    auth_service_url: Optional[str] = None
    msg_service_url: Optional[str] = None
    user_service_url: Optional[str] = None
    file_service_url: Optional[str] = None
    token_service_url: Optional[str] = None
    aigc_service_url: Optional[str] = None
    ai_service_url: Optional[str] = None
    audit_log_service_url: Optional[str] = None
    provider_service_url: Optional[str] = None
    usage_service_url: Optional[str] = None
    org_service_url: Optional[str] = None
    gateway_h5_service_url: Optional[str] = None
    delivery_stream_service_url: Optional[str] = None
    ez_ability_service_url: Optional[str] = None
    im_service_url: Optional[str] = None
    hub_service_url: Optional[str] = None
    task_service_url: Optional[str] = None
    notes_service_url: Optional[str] = None
    memory_service_url: Optional[str] = None

    # ========== 通用 ==========
    user_context: Optional[UserContext] = None
    token_storage: Optional[TokenStorage] = None
    timeout: Optional[int] = None  # 毫秒

    @property
    def is_gateway_mode(self) -> bool:
        return bool(self.gateway_url)
