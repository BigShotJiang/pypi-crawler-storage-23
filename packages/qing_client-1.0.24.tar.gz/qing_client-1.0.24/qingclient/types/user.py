"""User 服务类型（与 npm user types 对齐）。"""
from dataclasses import dataclass
from typing import Optional


@dataclass
class User:
    id: int
    username: str
    email: str
    name: Optional[str] = None
    avatar: Optional[str] = None
    role: Optional[str] = None
    phone: Optional[str] = None
    last_login_ip: Optional[str] = None
    last_login: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    is_active: bool = True
    project_id: Optional[int] = None


@dataclass
class UserCreateRequest:
    username: str
    email: str
    password: str
    name: Optional[str] = None
    role: Optional[str] = None
    phone: Optional[str] = None
    project_id: Optional[int] = None


@dataclass
class UserUpdateRequest:
    name: Optional[str] = None
    avatar: Optional[str] = None
    phone: Optional[str] = None
    role: Optional[str] = None
    project_id: Optional[int] = None


@dataclass
class SelfPasswordChangeRequest:
    old_password: str
    new_password: str


@dataclass
class SelfUserUpdateRequest:
    name: Optional[str] = None
    avatar: Optional[str] = None
    phone: Optional[str] = None


@dataclass
class UserOperationResponse:
    id: Optional[int] = None


@dataclass
class PasswordResetRequest:
    new_password: str
