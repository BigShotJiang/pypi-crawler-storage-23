"""任务服务（与 npm TaskService 对齐）。"""
from typing import Any, Optional

from .base_client import BaseClient
from .types import ClientConfig, RequestOptions, TokenStorage, PaginatedResponse


class TaskService(BaseClient):
    service_path = "task"

    def __init__(
        self,
        config: ClientConfig,
        token_storage: Optional[TokenStorage] = None,
    ) -> None:
        super().__init__(config, token_storage=token_storage)

    @property
    def service_name(self) -> str:
        return "task"

    def list_tasks(
        self,
        params: Optional[dict] = None,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        """列表查询。params 可含 view(mine/public/all)、status、page、per_page 等。"""
        return self.request("", RequestOptions(
            method="GET",
            params=params or {},
        ))

    def list_my_tasks(
        self,
        params: Optional[dict] = None,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        """我的任务，等价于 list_tasks({**params, "view": "mine"})。"""
        p = dict(params or {})
        p["view"] = "mine"
        return self.list_tasks(p, options)

    def list_public_tasks(
        self,
        params: Optional[dict] = None,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        """可接公开任务，等价于 list_tasks({**params, "view": "public"})。"""
        p = dict(params or {})
        p["view"] = "public"
        return self.list_tasks(p, options)

    def list_all_tasks(
        self,
        params: Optional[dict] = None,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        """全部任务（仅 SUPER_ADMIN/ADMIN 可调用），等价于 list_tasks({**params, "view": "all"})。"""
        p = dict(params or {})
        p["view"] = "all"
        return self.list_tasks(p, options)

    def get_task(
        self,
        task_id: str,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request(f"/{task_id}", RequestOptions(method="GET"))

    def create_task(
        self,
        request: dict,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request("", RequestOptions(method="POST", body=request))

    def update_task(
        self,
        task_id: str,
        update_data: dict,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request(f"/{task_id}", RequestOptions(
            method="PUT",
            body=update_data,
        ))

    def delete_task(
        self,
        task_id: str,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request(f"/{task_id}", RequestOptions(method="DELETE"))
