"""文件服务（与 npm FileService 对齐）。"""
from typing import Any, Optional

from .base_client import BaseClient
from .types import ClientConfig, RequestOptions, TokenStorage, PaginatedResponse


class FileService(BaseClient):
    """服务路径: files（V2）/ file（V1 兼容）。"""

    def __init__(
        self,
        config: ClientConfig,
        token_storage: Optional[TokenStorage] = None,
        service_name: str = "files",
    ) -> None:
        super().__init__(config, service_path=service_name, token_storage=token_storage)

    @property
    def service_name(self) -> str:
        return "file"

    def create_file(
        self,
        file_data: dict,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request("", RequestOptions(method="POST", body=file_data))

    def get_file_by_id(
        self,
        file_id: str,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request(f"/{file_id}", RequestOptions(method="GET"))

    def update_file(
        self,
        file_id: str,
        update_data: dict,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request(f"/{file_id}", RequestOptions(method="PUT", body=update_data))

    def delete_file(
        self,
        file_id: str,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request(f"/{file_id}", RequestOptions(method="DELETE"))

    def get_storage_stats(
        self,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request("/storage-stats", RequestOptions(method="GET"))

    def list_files(
        self,
        query: Optional[dict] = None,
        options: Optional[RequestOptions] = None,
    ) -> PaginatedResponse:
        return self.paginated_request("", RequestOptions(
            method="GET",
            params=query or {},
        ))

    def generate_oss_upload_sign(
        self,
        request: dict,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request("/oss/generate-sign", RequestOptions(
            method="POST",
            body=request,
        ))

    def get_oss_config(
        self,
        project_id: str,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request(f"/oss/config/{project_id}", RequestOptions(method="GET"))

    def create_folder(
        self,
        request: dict,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request("/folders", RequestOptions(method="POST", body=request))

    def get_folder_by_id(
        self,
        folder_id: str,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request(f"/folders/{folder_id}", RequestOptions(method="GET"))

    def update_folder(
        self,
        folder_id: str,
        update_data: dict,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request(f"/folders/{folder_id}", RequestOptions(
            method="PUT",
            body=update_data,
        ))
