"""能力枢纽服务（与 npm HubService 对齐）。"""
from typing import Any, Optional

from .base_client import BaseClient
from .types import ClientConfig, RequestOptions, TokenStorage


class HubService(BaseClient):
    service_path = "hub"

    def __init__(
        self,
        config: ClientConfig,
        token_storage: Optional[TokenStorage] = None,
    ) -> None:
        super().__init__(config, token_storage=token_storage)

    @property
    def service_name(self) -> str:
        return "hub"

    def get_stats(
        self,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request("/stats", RequestOptions(method="GET"))

    def list_workers(
        self,
        params: Optional[dict] = None,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request("/workers", RequestOptions(
            method="GET",
            params=params or {},
        ))

    def list_tasks(
        self,
        params: Optional[dict] = None,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request("/tasks", RequestOptions(
            method="GET",
            params=params or {},
        ))
