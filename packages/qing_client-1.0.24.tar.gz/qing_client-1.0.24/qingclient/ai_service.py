"""AI 服务（与 npm AiService 对齐）。"""
from typing import Any, Optional

from .base_client import BaseClient
from .types import ClientConfig, RequestOptions, TokenStorage


class AiService(BaseClient):
    service_path = "ai"

    def __init__(
        self,
        config: ClientConfig,
        token_storage: Optional[TokenStorage] = None,
    ) -> None:
        super().__init__(config, token_storage=token_storage)

    @property
    def service_name(self) -> str:
        return "ai"

    def chat_completion(
        self,
        request: dict,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request("/chat", RequestOptions(method="POST", body=request))

    def chat_completion_stream(
        self,
        request: dict,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request("/chat/stream", RequestOptions(method="POST", body=request))

    def create_session(
        self,
        request: dict,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request("/session", RequestOptions(method="POST", body=request))

    def get_sessions(
        self,
        params: Optional[dict] = None,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request("/session", RequestOptions(
            method="GET",
            params=params or {},
        ))

    def get_session(
        self,
        session_id: str,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request(f"/session/{session_id}", RequestOptions(method="GET"))

    def update_session(
        self,
        session_id: str,
        update_data: dict,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request(f"/session/{session_id}", RequestOptions(
            method="PUT",
            body=update_data,
        ))

    def add_message(
        self,
        session_id: str,
        request: dict,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request(f"/session/{session_id}/messages", RequestOptions(
            method="POST",
            body=request,
        ))

    def switch_model(
        self,
        session_id: str,
        request: dict,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        return self.request(f"/session/{session_id}/switch-model", RequestOptions(
            method="POST",
            body=request,
        ))
