# The PostgreSQL role for masked reads.
from __future__ import annotations

MASKED_READER_ROLE = "dsl_masked_reader"
