"""Event and browser type definitions."""

from typing import Literal

BrowserType = Literal["chrome", "chrome-new", "chrome-h", "firefox", "servo", "lightpanda", "auto"]
