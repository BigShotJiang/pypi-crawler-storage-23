"""Synix core — shared models, config, logging, errors."""
