"""Backward compatibility shim — moved to synix.build.projections."""

from synix.build.projections import BaseProjection  # noqa: F401
