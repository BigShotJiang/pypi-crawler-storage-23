Alice Chen is a backend engineer from Portland who specializes in distributed systems.
She has been programming for 12 years and speaks three languages.
On weekends she enjoys hiking in the Columbia River Gorge.
