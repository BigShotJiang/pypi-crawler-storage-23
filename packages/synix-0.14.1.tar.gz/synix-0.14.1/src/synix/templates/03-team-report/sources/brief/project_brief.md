Build an accessible dashboard that visualizes real-time climate sensor data.
The system needs a scalable backend to ingest sensor streams, a data pipeline
to clean and aggregate readings, and an intuitive UI that meets WCAG 2.1 AA
standards. The team has 8 weeks.
