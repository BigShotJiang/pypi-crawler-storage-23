"""Synix adapters — source format parsers (ChatGPT, Claude, Claude Code, text/markdown)."""
