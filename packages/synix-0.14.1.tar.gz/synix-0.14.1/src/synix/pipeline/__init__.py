"""Backward compatibility — use synix.build.pipeline and synix.build.dag."""
