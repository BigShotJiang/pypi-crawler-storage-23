"""Backward compatibility shim — moved to synix.build.runner."""

from synix.build.runner import LayerStats, RunResult, run  # noqa: F401
