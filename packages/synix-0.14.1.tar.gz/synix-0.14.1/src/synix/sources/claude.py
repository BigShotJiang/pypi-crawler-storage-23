"""Backward compatibility shim — moved to synix.adapters.claude."""

from synix.adapters.claude import parse_claude  # noqa: F401
