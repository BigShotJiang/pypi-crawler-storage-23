"""Backward compatibility shim — moved to synix.adapters.chatgpt."""

from synix.adapters.chatgpt import parse_chatgpt  # noqa: F401
