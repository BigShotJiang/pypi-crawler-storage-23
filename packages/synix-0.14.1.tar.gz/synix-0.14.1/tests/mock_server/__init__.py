"""OpenAI-compatible mock LLM server for testing."""
