.. _unstallation:

Uninstallation
==============

To uninstall, use ``pip uninstall ironic-ui`` from with-in the horizon
virtual environment. You will also need to remove the
``openstack_dashboard/enabled/_2200_ironic.py`` file from the horizon
installation.
