"""TeXFlow MCP tool definitions."""
