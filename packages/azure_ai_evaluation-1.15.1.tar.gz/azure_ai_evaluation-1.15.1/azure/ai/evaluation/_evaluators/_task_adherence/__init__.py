# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from ._task_adherence import TaskAdherenceEvaluator

__all__ = ["TaskAdherenceEvaluator"]
