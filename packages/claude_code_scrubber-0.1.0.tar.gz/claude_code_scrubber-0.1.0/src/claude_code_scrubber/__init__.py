"""Claude Code Scrubber - Scrub personal info, secrets, and API keys from Claude Code transcripts."""

__version__ = "0.1.0"
