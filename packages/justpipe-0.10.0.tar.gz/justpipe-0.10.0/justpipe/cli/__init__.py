"""Command-line interface for justpipe observability."""

__all__ = []
