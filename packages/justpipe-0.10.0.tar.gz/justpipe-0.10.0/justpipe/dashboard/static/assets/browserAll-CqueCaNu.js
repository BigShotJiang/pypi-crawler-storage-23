import{e as i,A as e,C as a,a as s,E as t,F as n}from"./pixijs-Cln1qcTV.js";import"./webworkerAll-C73Bk7uS.js";i.add(e);i.mixin(a,s);i.add(t);i.mixin(a,n);
