import{e,f as s,h as a}from"./pixijs-Cln1qcTV.js";e.add(s);e.add(a);
