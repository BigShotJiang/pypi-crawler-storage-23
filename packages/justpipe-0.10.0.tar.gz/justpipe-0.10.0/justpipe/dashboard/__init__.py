"""Web dashboard for justpipe pipeline observability."""
