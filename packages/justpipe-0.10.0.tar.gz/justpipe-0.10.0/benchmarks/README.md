# Benchmarks

Performance checks live here and are intentionally separate from correctness
tests.

- Run with: `uv run pytest benchmarks/ -q`
- Not executed by default because pytest `testpaths` targets `tests/` only.
