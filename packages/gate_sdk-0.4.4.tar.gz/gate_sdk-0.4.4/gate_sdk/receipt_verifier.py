"""
Gate Receipt Verifier (standalone).

Verifies HMAC-SHA256 signature over the 6-field signed payload per receipt-spec.
Uses constant-time comparison. No AWS or backend dependencies.
"""

import hmac
import hashlib
import base64
import json
from typing import Any, Dict, Optional, Tuple

RECEIPT_SIGNATURE_PREFIX = "HS256:"


def _signed_payload_from_full_receipt(full: Dict[str, Any]) -> Dict[str, str]:
    """Build the 6-field signed payload from a full receipt (API response shape)."""
    if "evaluated_at_ms" in full and full["evaluated_at_ms"] is not None:
        from datetime import datetime
        ts_ms = full["evaluated_at_ms"]
        timestamp = datetime.utcfromtimestamp(ts_ms / 1000.0).strftime("%Y-%m-%dT%H:%M:%S.000Z")
    elif full.get("timestamp"):
        timestamp = str(full["timestamp"])
    else:
        timestamp = "1970-01-01T00:00:00.000Z"
    return {
        "requestId": str(full.get("request_id") or full.get("requestId") or ""),
        "decision": str(full.get("decision") or ""),
        "txDigest": str(full.get("txDigest") or ""),
        "policyHash": str(full.get("policy_snapshot_id") or full.get("policyHash") or ""),
        "timestamp": timestamp,
        "tenantId": str(full.get("tenant_id") or full.get("tenantId") or ""),
    }


def _canonical_signed_payload(payload: Dict[str, str]) -> str:
    """Canonical JSON for the signed payload (sorted keys). Must match hot path and TS verifier."""
    keys = ["decision", "policyHash", "requestId", "tenantId", "timestamp", "txDigest"]
    ordered = {k: (payload.get(k) if payload.get(k) is not None else "") for k in keys}
    return json.dumps(ordered, separators=(",", ":"), sort_keys=True)


def verify_receipt_signature(
    payload: Dict[str, str],
    signature: str,
    hmac_secret: str,
) -> bool:
    """Verify signature over the signed payload using constant-time compare. Returns True if valid."""
    canonical = _canonical_signed_payload(payload)
    expected_hmac = hmac.new(
        hmac_secret.encode("utf-8"),
        canonical.encode("utf-8"),
        hashlib.sha256,
    ).digest()
    expected = RECEIPT_SIGNATURE_PREFIX + base64.b64encode(expected_hmac).decode("ascii")

    if not signature.startswith(RECEIPT_SIGNATURE_PREFIX) or not expected.startswith(RECEIPT_SIGNATURE_PREFIX):
        return False
    sig_b64 = signature[len(RECEIPT_SIGNATURE_PREFIX) :]
    exp_b64 = expected[len(RECEIPT_SIGNATURE_PREFIX) :]
    try:
        sig_buf = base64.b64decode(sig_b64)
        exp_buf = base64.b64decode(exp_b64)
        if len(sig_buf) != len(exp_buf):
            return False
        return hmac.compare_digest(sig_buf, exp_buf)
    except Exception:
        return False


def verify_receipt(
    receipt: Dict[str, Any],
    signature: str,
    hmac_secret: str,
) -> Tuple[bool, Optional[Dict[str, str]]]:
    """
    One-shot: from full receipt + signature + secret, verify.
    Returns (valid, payload). Use when you have the Hot Path response (receipt + receiptSignature).
    """
    if "requestId" in receipt and isinstance(receipt.get("requestId"), str):
        payload = {k: str(receipt[k]) for k in ("requestId", "decision", "txDigest", "policyHash", "timestamp", "tenantId") if receipt.get(k) is not None}
        payload.setdefault("requestId", "")
        payload.setdefault("decision", "")
        payload.setdefault("txDigest", "")
        payload.setdefault("policyHash", "")
        payload.setdefault("timestamp", "")
        payload.setdefault("tenantId", "")
    else:
        payload = _signed_payload_from_full_receipt(receipt)
    valid = verify_receipt_signature(payload, signature, hmac_secret)
    return (valid, payload if valid else None)
