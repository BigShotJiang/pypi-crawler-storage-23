"""
Canonical transaction digest for decision-token binding.
MUST match gate-hotpath and TypeScript SDK for verification.
"""

import hashlib
import json
from typing import Any, Dict, Optional


def _canonical_json_binding(obj: Any) -> str:
    """Canonical JSON for binding object only - must match hot path / TS output."""
    if obj is None:
        return "null"
    if isinstance(obj, str):
        return json.dumps(obj, separators=(",", ":"))
    if isinstance(obj, (int, float)):
        return str(int(obj)) if isinstance(obj, float) and obj == int(obj) else str(obj)
    if isinstance(obj, bool):
        return "true" if obj else "false"
    if isinstance(obj, list):
        return "[" + ",".join(_canonical_json_binding(i) for i in obj) + "]"
    if isinstance(obj, dict):
        parts = []
        for k in sorted(obj.keys()):
            v = obj[k]
            parts.append(json.dumps(k, separators=(",", ":")) + ":" + _canonical_json_binding(v))
        return "{" + ",".join(parts) + "}"
    return json.dumps(obj, separators=(",", ":"))


def _normalize_address(addr: Optional[str]) -> str:
    if addr is None or addr == "":
        return ""
    s = str(addr).strip()
    if s.startswith("0x"):
        return s.lower()
    return "0x" + s.lower()


def _normalize_data(data: Optional[str]) -> str:
    if data is None or data == "":
        return ""
    s = str(data).strip().lower()
    return s if s.startswith("0x") else "0x" + s


def build_tx_binding_object(
    tx_intent: Dict[str, Any],
    signer_id: Optional[str] = None,
    decoded_recipient: Optional[str] = None,
    decoded_fields: Optional[Dict[str, Any]] = None,
    from_address: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Build canonical tx binding from intent (same as hot path / TS SDK).
    tx_intent may use 'to' or 'toAddress', 'value' or 'valueAtomic'/'valueDecimal'.
    """
    to_addr = tx_intent.get("toAddress") or tx_intent.get("to") or ""
    value = str(
        tx_intent.get("valueAtomic")
        or tx_intent.get("valueDecimal")
        or tx_intent.get("value")
        or "0"
    )
    data = _normalize_data(
        tx_intent.get("data") or tx_intent.get("payloadHash") or tx_intent.get("dataHash") or ""
    )
    chain_id = str(tx_intent.get("chainId") or tx_intent.get("chain") or "")
    to_address = _normalize_address(to_addr)
    nonce = str(tx_intent["nonce"]) if tx_intent.get("nonce") is not None else ""

    out: Dict[str, Any] = {
        "chainId": chain_id,
        "toAddress": to_address,
        "value": value,
        "data": data,
        "nonce": nonce,
    }
    if from_address:
        out["fromAddress"] = _normalize_address(from_address)
    if decoded_recipient is not None:
        out["decodedRecipient"] = _normalize_address(decoded_recipient) if decoded_recipient else None
    if decoded_fields and isinstance(decoded_fields, dict):
        decoded = {k: v for k, v in decoded_fields.items() if v is not None}
        if decoded:
            out["decoded"] = decoded
    if signer_id:
        out["signerId"] = signer_id
    if tx_intent.get("networkFamily"):
        out["networkFamily"] = tx_intent["networkFamily"]
    return out


def compute_tx_digest(binding: Dict[str, Any]) -> str:
    """Compute SHA256(canonical_json(binding)). Must match hot path digest."""
    canonical = _canonical_json_binding(binding)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()
