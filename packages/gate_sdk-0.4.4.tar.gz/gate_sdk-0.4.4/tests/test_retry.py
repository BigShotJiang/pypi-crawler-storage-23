"""
Unit tests for gate_sdk.retry (is_retryable_status, is_retryable_error, calculate_backoff_delay, retry_with_backoff).
"""

import pytest
from unittest.mock import patch

from gate_sdk.retry import (
    is_retryable_status,
    is_retryable_error,
    calculate_backoff_delay,
    retry_with_backoff,
)
from gate_sdk.errors import GateError, GateRateLimitError, GateServerError, GateAuthError


class TestIsRetryableStatus:
    def test_429_is_retryable(self):
        assert is_retryable_status(429) is True

    def test_500_is_retryable(self):
        assert is_retryable_status(500) is True
        assert is_retryable_status(502) is True
        assert is_retryable_status(503) is True
        assert is_retryable_status(599) is True

    def test_4xx_except_429_not_retryable(self):
        assert is_retryable_status(400) is False
        assert is_retryable_status(401) is False
        assert is_retryable_status(403) is False
        assert is_retryable_status(404) is False

    def test_2xx_not_retryable(self):
        assert is_retryable_status(200) is False


class TestIsRetryableError:
    def test_rate_limit_is_retryable(self):
        assert is_retryable_error(GateRateLimitError("x")) is True

    def test_server_error_is_retryable(self):
        assert is_retryable_error(GateServerError("x")) is True

    def test_auth_error_not_retryable(self):
        assert is_retryable_error(GateAuthError("x")) is False

    def test_generic_gate_error_not_retryable(self):
        assert is_retryable_error(GateError("x")) is False

    def test_non_gate_error_not_retryable(self):
        assert is_retryable_error(ValueError("x")) is False


class TestCalculateBackoffDelay:
    def test_first_attempt_delay_in_range(self):
        d = calculate_backoff_delay(1, base_delay_ms=100, max_delay_ms=800, factor=2.0)
        assert 0.1 <= d <= 0.2  # 100ms + jitter

    def test_delay_capped_by_max(self):
        d = calculate_backoff_delay(10, base_delay_ms=100, max_delay_ms=100)
        assert d <= 0.2  # max 100ms + jitter, in seconds

    def test_delay_increases_with_attempt(self):
        d1 = calculate_backoff_delay(1, base_delay_ms=100, max_delay_ms=5000)
        d2 = calculate_backoff_delay(2, base_delay_ms=100, max_delay_ms=5000)
        d3 = calculate_backoff_delay(3, base_delay_ms=100, max_delay_ms=5000)
        assert d1 < d2 < d3


class TestRetryWithBackoff:
    def test_returns_result_on_success(self):
        result = retry_with_backoff(lambda: 42, max_attempts=3)
        assert result == 42

    def test_retries_on_retryable_error_then_succeeds(self):
        calls = []

        def flaky():
            calls.append(1)
            if len(calls) < 2:
                raise GateServerError("temp")
            return "ok"

        result = retry_with_backoff(flaky, max_attempts=3, base_delay_ms=1, max_delay_ms=10)
        assert result == "ok"
        assert len(calls) == 2

    def test_raises_after_max_attempts(self):
        def always_fail():
            raise GateServerError("nope")

        with pytest.raises(GateServerError):
            retry_with_backoff(always_fail, max_attempts=2, base_delay_ms=1, max_delay_ms=5)

    def test_does_not_retry_on_non_retryable_gate_error(self):
        calls = []

        def auth_fail():
            calls.append(1)
            raise GateAuthError("forbidden")

        with pytest.raises(GateAuthError):
            retry_with_backoff(auth_fail, max_attempts=3)
        assert len(calls) == 1

    def test_does_not_retry_on_generic_exception(self):
        calls = []

        def value_error():
            calls.append(1)
            raise ValueError("bad")

        with pytest.raises(ValueError):
            retry_with_backoff(value_error, max_attempts=3)
        assert len(calls) == 1
