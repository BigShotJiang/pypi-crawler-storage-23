class NEMOCEConfig:
    plugin_id = 1000
