# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, Union, Optional

from .._models import BaseModel

__all__ = ["WorkflowItem"]


class WorkflowItem(BaseModel):
    """
    Representation of an instance of an abstract Workflow
    Attributes:
        workflow_name: Key in the map of workflows defined at the top of a plan config
        workflow_alias: Alias of the abstract workflow in the graph. If None, defaults to workflow_name.
                        Use in order to re-use the same abstract workflow in multiple portions of the graph.
        workflow_inputs: Inputs to the workflow can be:
                          1) empty if this workflow does not receive input from another workflow,
                          2) a dictionary mapping another workflow's outputs or a branch's merged outputs to this workflows input keys
                          For case 2, inputs can be a mapping from:
                          a) str to str
                          b) str to dict(str, str)
                          c) str to dict(str, dict(str, str))
    """

    workflow_name: str
    """The name of the abstract workflow"""

    workflow_alias: Optional[str] = None
    """The alias of the abstract workflow in the graph"""

    workflow_inputs: Optional[Dict[str, Union[str, Dict[str, Union[str, object]]]]] = None
    """The inputs to the workflow"""
