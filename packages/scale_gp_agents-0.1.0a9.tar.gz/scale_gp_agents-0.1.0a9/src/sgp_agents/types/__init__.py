# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from . import (
    node_item_output,
    plan_config_output,
    config_create_response,
    workflow_config_output,
    config_retrieve_response,
    compound_condition_output,
)
from .. import _compat
from .workflow_item import WorkflowItem as WorkflowItem
from .unary_condition import UnaryCondition as UnaryCondition
from .node_item_output import NodeItemOutput as NodeItemOutput
from .config_list_params import ConfigListParams as ConfigListParams
from .plan_config_output import PlanConfigOutput as PlanConfigOutput
from .jinja_node_template import JinjaNodeTemplate as JinjaNodeTemplate
from .workflow_item_param import WorkflowItemParam as WorkflowItemParam
from .config_create_params import ConfigCreateParams as ConfigCreateParams
from .config_list_response import ConfigListResponse as ConfigListResponse
from .config_execute_params import ConfigExecuteParams as ConfigExecuteParams
from .node_item_input_param import NodeItemInputParam as NodeItemInputParam
from .unary_condition_param import UnaryConditionParam as UnaryConditionParam
from .config_create_response import ConfigCreateResponse as ConfigCreateResponse
from .config_delete_response import ConfigDeleteResponse as ConfigDeleteResponse
from .workflow_config_output import WorkflowConfigOutput as WorkflowConfigOutput
from .plan_config_input_param import PlanConfigInputParam as PlanConfigInputParam
from .config_retrieve_response import ConfigRetrieveResponse as ConfigRetrieveResponse
from .compound_condition_output import CompoundConditionOutput as CompoundConditionOutput
from .jinja_node_template_param import JinjaNodeTemplateParam as JinjaNodeTemplateParam
from .workflow_config_input_param import WorkflowConfigInputParam as WorkflowConfigInputParam
from .compound_condition_input_param import CompoundConditionInputParam as CompoundConditionInputParam

# Rebuild cyclical models only after all modules are imported.
# This ensures that, when building the deferred (due to cyclical references) model schema,
# Pydantic can resolve the necessary references.
# See: https://github.com/pydantic/pydantic/issues/11250 for more context.
if _compat.PYDANTIC_V1:
    compound_condition_output.CompoundConditionOutput.update_forward_refs()  # type: ignore
    node_item_output.NodeItemOutput.update_forward_refs()  # type: ignore
    plan_config_output.PlanConfigOutput.update_forward_refs()  # type: ignore
    workflow_config_output.WorkflowConfigOutput.update_forward_refs()  # type: ignore
    config_create_response.ConfigCreateResponse.update_forward_refs()  # type: ignore
    config_retrieve_response.ConfigRetrieveResponse.update_forward_refs()  # type: ignore
else:
    compound_condition_output.CompoundConditionOutput.model_rebuild(_parent_namespace_depth=0)
    node_item_output.NodeItemOutput.model_rebuild(_parent_namespace_depth=0)
    plan_config_output.PlanConfigOutput.model_rebuild(_parent_namespace_depth=0)
    workflow_config_output.WorkflowConfigOutput.model_rebuild(_parent_namespace_depth=0)
    config_create_response.ConfigCreateResponse.model_rebuild(_parent_namespace_depth=0)
    config_retrieve_response.ConfigRetrieveResponse.model_rebuild(_parent_namespace_depth=0)
