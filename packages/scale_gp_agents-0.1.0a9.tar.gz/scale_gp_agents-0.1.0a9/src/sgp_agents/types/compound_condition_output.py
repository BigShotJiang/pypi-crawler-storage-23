# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import TYPE_CHECKING, List, Union, Optional
from typing_extensions import Literal, TypeAlias, TypeAliasType

from .._compat import PYDANTIC_V1
from .._models import BaseModel
from .unary_condition import UnaryCondition

__all__ = ["CompoundConditionOutput", "Condition"]

if TYPE_CHECKING or not PYDANTIC_V1:
    Condition = TypeAliasType("Condition", Union[UnaryCondition, "CompoundConditionOutput"])
else:
    Condition: TypeAlias = Union[UnaryCondition, "CompoundConditionOutput"]


class CompoundConditionOutput(BaseModel):
    """Representation of a compound boolean statement, i.e.

    a
    negation, conjunction, or disjunction of UnaryConditions
    """

    conditions: Optional[List[Condition]] = None
    """The list of conditions to apply the logical operator to"""

    input_names: Optional[List[str]] = None
    """The list of input names used in the conditions, populated by model validator"""

    logical_operator: Optional[Literal["ALL", "ANY", "NOT"]] = None
    """The logical operator to apply to the conditions"""
