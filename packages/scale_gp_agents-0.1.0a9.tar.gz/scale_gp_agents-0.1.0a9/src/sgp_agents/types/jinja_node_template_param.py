# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Optional
from typing_extensions import TypedDict

from .._types import SequenceNotStr

__all__ = ["JinjaNodeTemplateParam"]


class JinjaNodeTemplateParam(TypedDict, total=False):
    """
    Base model for a Jinja template.
    Guaranteed to store a string that can be read in to Template().
    """

    jinja_helper_functions: Optional[SequenceNotStr[Union[str, object]]]
    """Potential helper functions to use in jinja, please refer to egp_services.enums"""

    jinja_template_path: Optional[str]
    """Path to a Jinja2 template file. Default None."""

    jinja_template_str: Optional[str]
    """Raw template to apply to the data.

    This should be a Jinja2 template string. Please note, the data will be mapped as
    'value' in the template. Default None corresponds to {{value}}. Should access
    property `jinja_template_str` or field `jinja_template_str_loaded` for the
    loaded template data
    """

    jinja_template_str_loaded: Optional[str]
    """
    The original jinja_template_str field from the config might not contain the
    needed template, and we may need to load S3 data specified with
    `jinja_template_path`. This field caches the loaded template content, it is also
    accessed through property `jinja_template_str`.
    """
