# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import TYPE_CHECKING, Union, Iterable, Optional
from typing_extensions import Literal, TypeAlias, TypedDict, TypeAliasType

from .._types import SequenceNotStr
from .._compat import PYDANTIC_V1
from .unary_condition_param import UnaryConditionParam

__all__ = ["CompoundConditionInputParam", "Condition"]

if TYPE_CHECKING or not PYDANTIC_V1:
    Condition = TypeAliasType("Condition", Union[UnaryConditionParam, "CompoundConditionInputParam"])
else:
    Condition: TypeAlias = Union[UnaryConditionParam, "CompoundConditionInputParam"]


class CompoundConditionInputParam(TypedDict, total=False):
    """Representation of a compound boolean statement, i.e.

    a
    negation, conjunction, or disjunction of UnaryConditions
    """

    conditions: Optional[Iterable[Condition]]
    """The list of conditions to apply the logical operator to"""

    input_names: SequenceNotStr[str]
    """The list of input names used in the conditions, populated by model validator"""

    logical_operator: Literal["ALL", "ANY", "NOT"]
    """The logical operator to apply to the conditions"""
