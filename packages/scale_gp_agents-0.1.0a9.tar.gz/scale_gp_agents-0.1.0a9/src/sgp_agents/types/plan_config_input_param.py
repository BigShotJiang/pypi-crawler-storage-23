# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union, Iterable, Optional
from typing_extensions import Literal, Required, TypeAlias, TypedDict

from .._types import SequenceNotStr
from .workflow_item_param import WorkflowItemParam

__all__ = [
    "PlanConfigInputParam",
    "Plan",
    "PlanBranchConfigInput",
    "PlanBranchConfigInputConditionalWorkflow",
    "PlanLoopConfigInput",
    "PlanLoopConfigInputLoopInputs",
    "PlanLoopConfigInputLoopInputsSelfEdge",
    "Workflows",
    "WorkflowsWorkflowInput",
]


class PlanBranchConfigInputConditionalWorkflow(TypedDict, total=False):
    """
    Representation of a workflow that is part of a branch complex
    Attributes:
        condition: Either if, elif, or else
        condition_input_var: the variable that is inputted into the unary condition
        operator: the unary condition operator
        reference_var: the unary condition reference variable that is used to build a predicate function with the operator
        condition_tree: a compound logical expression expressed as a tree (see CompoundCondition), optional if the above condition vars are set
        workflow_nodes: to be set to a list of all nodes in the workflow at runtime, so they can
                        be easily ignored if this branch is not selected to run
    """

    condition: Required[Literal["if", "elif", "else"]]
    """The condition type"""

    workflow_name: Required[str]
    """The name of the abstract workflow"""

    condition_input_var: Optional[str]
    """The input variable to the unary condition"""

    condition_tree: Optional["CompoundConditionInputParam"]
    """Representation of a compound boolean statement, i.e.

    a negation, conjunction, or disjunction of UnaryConditions
    """

    operator: Optional[str]
    """The operator to use in the unary condition"""

    reference_var: Optional[str]
    """The reference variable to use in the unary condition"""

    workflow_alias: Optional[str]
    """The alias of the abstract workflow in the graph"""

    workflow_inputs: Optional[Dict[str, Union[str, Dict[str, Union[str, object]]]]]
    """The inputs to the workflow"""

    workflow_nodes: SequenceNotStr[str]
    """The nodes that make up the workflow"""


class PlanBranchConfigInput(TypedDict, total=False):
    """
    A representation of a branch complex.
    Branches can have multiple conditional workflows, each with a condition and a workflow.
    They need not end with an else branch, but if they don't then the user must provide a
    default source to pass through the merge node from outside the branch.
    Attributes:
        branch: name of the branch
        conditional_workflows: conditional workflows associated with the branch
        merge_outputs: Map where each key is an alias mapping to a list of node outputs the conditional workflows.
                       For example, the config:
                           - branch: do_A_or_B
                             ...
                             merge_outputs:
                                 response_A_or_B:
                                 - "workflow_A.response_node.output"
                                 - "workflow_B.response_node.output"
                                 chunks_A_or_B:
                                 - "workflow_A.chunks_node.output"
                                 - "workflow_B.chunks_node.output"
                        allows the user to reference the response/chunks outputs of either branch via the aliases
                        "do_A_or_B.response_A_or_B.output" and "do_A_or_B.chunks_A_or_B.output" in downstream steps of a plan
    """

    branch: Required[str]

    conditional_workflows: Required[Iterable[PlanBranchConfigInputConditionalWorkflow]]

    merge_outputs: Dict[str, SequenceNotStr[str]]

    save_merge_to_memory: Dict[str, str]


class PlanLoopConfigInputLoopInputsSelfEdge(TypedDict, total=False):
    """
    A self edge in a loop complex is configured with 2 attributes:
        (a) node_name: the name of a node within the loop whose output will be passed to the next iteration,
        (b) a default value or source to use when the loop is at its first iteration
    """

    node_name: Required[str]

    default_source: Optional[str]

    default_value: object


PlanLoopConfigInputLoopInputs: TypeAlias = Union[str, PlanLoopConfigInputLoopInputsSelfEdge]


class PlanLoopConfigInput(TypedDict, total=False):
    """
    A representation of a loop complex
    Currently, loops are implemented as a series of BranchConfigs.

    Attributes:
        name: name of the loop
        workflow: the workflow to be repeated in the loop
        condition: the condition that yields True if the loop is to be continued
        max_iter: the maximum number of iterations the loop will run. required for now.
        loop_inputs: a mapping of inputs to the looped workflow to either a string or SelfEdge.
                     If a string, the key is assumed to map to a raw input to the plan or another
                     container's (branch/workflow) node's output.
                     If a SelfEdge, the key is assumed to map to a node within the loop whose output
                     will be passed to the next iteration.
        merge_outputs: a map to define the final outputs of the loop.
                       The key is an alias that maps to a node within the workflow.
    """

    condition: Required["CompoundConditionInputParam"]
    """Representation of a compound boolean statement, i.e.

    a negation, conjunction, or disjunction of UnaryConditions
    """

    max_iter: Required[int]

    name: Required[str]

    workflow: Required[WorkflowItemParam]
    """
    Representation of an instance of an abstract Workflow Attributes: workflow_name:
    Key in the map of workflows defined at the top of a plan config workflow_alias:
    Alias of the abstract workflow in the graph. If None, defaults to workflow_name.
    Use in order to re-use the same abstract workflow in multiple portions of the
    graph. workflow_inputs: Inputs to the workflow can be: 1) empty if this workflow
    does not receive input from another workflow, 2) a dictionary mapping another
    workflow's outputs or a branch's merged outputs to this workflows input keys For
    case 2, inputs can be a mapping from: a) str to str b) str to dict(str, str) c)
    str to dict(str, dict(str, str))
    """

    loop_inputs: Dict[str, PlanLoopConfigInputLoopInputs]

    merge_outputs: Dict[str, str]


Plan: TypeAlias = Union[WorkflowItemParam, PlanBranchConfigInput, PlanLoopConfigInput]


class WorkflowsWorkflowInput(TypedDict, total=False):
    """
    A representation of a DAG of functions
    Attributes:
        name: name of the workflow
        nodes: a list of node items that make up the workflow
    """

    name: Required[str]

    nodes: Required[Iterable["NodeItemInputParam"]]


Workflows: TypeAlias = Union[WorkflowsWorkflowInput, str, Iterable["NodeItemInputParam"]]


class PlanConfigInputParam(TypedDict, total=False):
    """Representation of a plan, i.e. a composition of workflows and branch complexes

    Public attributes:
        workflows: maps a workflow "name" to either a workflow yaml file or an inline workflow definition
        plan: representation of the graph connecting workflows / branch complexes

    Private attributes:
        helper_workflows: a list of workflows created by default, in order to
                          support loops and other control flow features
    """

    plan: Required[Iterable[Plan]]

    id: Optional[str]

    account_id: Optional[str]

    application_variant_id: Optional[str]

    base_url: Optional[str]

    concurrency_default: bool

    datasets: Optional[Iterable[object]]

    egp_api_key_override: Optional[str]

    egp_ui_evaluation: Optional[object]

    evaluations: Optional[Iterable["NodeItemInputParam"]]

    final_output_nodes: Optional[SequenceNotStr[str]]

    nodes_to_log: Union[str, SequenceNotStr[str], None]

    num_workers: Optional[int]

    streaming_nodes: Optional[SequenceNotStr[str]]

    subtype: Optional[Literal["chat", "report"]]

    type: Optional[Literal["workflow", "plan", "state_machine"]]

    user_input: object

    workflows: Dict[str, Workflows]


from .node_item_input_param import NodeItemInputParam
from .compound_condition_input_param import CompoundConditionInputParam
