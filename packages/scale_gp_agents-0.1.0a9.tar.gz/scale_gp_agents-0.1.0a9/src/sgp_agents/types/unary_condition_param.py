# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

__all__ = ["UnaryConditionParam"]


class UnaryConditionParam(TypedDict, total=False):
    """Representation of a boolean function with a single input
    e.g.

    the condition specified by
        input_name: x
        operator: 'contains'
        ref_value: 'c'
    would evaluate to True if x == 'cat'
    Operators are defined in the constant function store CONDITIONAL_ACTION_MAP
    """

    condition_input_var: Required[str]
    """The name of the variable to evaluate the condition on"""

    operator: Required[str]
    """The operator to apply to the input variable"""

    reference_var: object
    """The reference value to compare the input variable to."""
