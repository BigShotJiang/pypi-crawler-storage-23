# Changelog

## 0.1.0-alpha.9 (2026-03-05)

Full Changelog: [v0.1.0-alpha.8...v0.1.0-alpha.9](https://github.com/scaleapi/agents-python/compare/v0.1.0-alpha.8...v0.1.0-alpha.9)

### Features

* **api:** manual updates ([7c2b71f](https://github.com/scaleapi/agents-python/commit/7c2b71f8e27755e23b53c857526a345b16fdf6ad))
* **client:** add custom JSON encoder for extended type support ([3444886](https://github.com/scaleapi/agents-python/commit/34448863426a38e42b6aae5b10d17e2efda91cd7))


### Bug Fixes

* use _async_transform_recursive instead of _transform_recursive ([459146b](https://github.com/scaleapi/agents-python/commit/459146beca0f0c6116d6260ffa48008e407aad7d))


### Chores

* add missing isclass check ([#48](https://github.com/scaleapi/agents-python/issues/48)) ([414b31f](https://github.com/scaleapi/agents-python/commit/414b31f89ac943b1f808eecf23a5cc0015b97b3c))
* **ci:** upgrade `actions/github-script` ([ed240b5](https://github.com/scaleapi/agents-python/commit/ed240b5155fa161a076adfcdfff7a4bccab6fd21))
* **client:** simplify `Optional[object]` to just `object` ([#47](https://github.com/scaleapi/agents-python/issues/47)) ([d97a17a](https://github.com/scaleapi/agents-python/commit/d97a17aa8b8d790b854039e6dd3686c38c82ecce))
* format all `api.md` files ([9500232](https://github.com/scaleapi/agents-python/commit/9500232fc4f2434da9d4147180ab5365deb29982))
* **internal:** add request options to SSE classes ([4519594](https://github.com/scaleapi/agents-python/commit/4519594fd2f5e23b66f6bc6b3716bcbd27fcf4bf))
* **internal:** bump dependencies ([7db5953](https://github.com/scaleapi/agents-python/commit/7db5953739f67c8ddfe896a943c8f40b07e1b020))
* **internal:** bump httpx dependency ([#49](https://github.com/scaleapi/agents-python/issues/49)) ([c3c89f1](https://github.com/scaleapi/agents-python/commit/c3c89f12864345b46ec4e95489f03b672887ee29))
* **internal:** codegen related update ([#39](https://github.com/scaleapi/agents-python/issues/39)) ([9dd5f2d](https://github.com/scaleapi/agents-python/commit/9dd5f2db62e5d3727b864d68539278a16780824c))
* **internal:** codegen related update ([#41](https://github.com/scaleapi/agents-python/issues/41)) ([53bfc93](https://github.com/scaleapi/agents-python/commit/53bfc93d8dbf66f919e50aad990fbf854ab6fab9))
* **internal:** codegen related update ([#45](https://github.com/scaleapi/agents-python/issues/45)) ([4afd56d](https://github.com/scaleapi/agents-python/commit/4afd56dcac2a4fca1703bec0938f517c2d1ef528))
* **internal:** fix lint error on Python 3.14 ([9cc8760](https://github.com/scaleapi/agents-python/commit/9cc876002cd09784e6490ff65a4f7fd59ebf4c99))
* **internal:** fix some typos ([#44](https://github.com/scaleapi/agents-python/issues/44)) ([1a1fa6d](https://github.com/scaleapi/agents-python/commit/1a1fa6de9a7a8f047b0ccd9a262838c49303712a))
* **internal:** make `test_proxy_environment_variables` more resilient ([f81aebb](https://github.com/scaleapi/agents-python/commit/f81aebb54fc59647db7a88f54b465d8bf9ca4005))
* **internal:** make `test_proxy_environment_variables` more resilient to env ([a1d6c53](https://github.com/scaleapi/agents-python/commit/a1d6c53d27b31ecb5cabf46cc5fc187c250fcd3a))
* **internal:** update `actions/checkout` version ([e981f83](https://github.com/scaleapi/agents-python/commit/e981f83e34a04cc785a21cfd7910ad2b1460f44d))
* **internal:** updated imports ([#42](https://github.com/scaleapi/agents-python/issues/42)) ([847c4a4](https://github.com/scaleapi/agents-python/commit/847c4a45333d7305a2153cca4094b885af6db54f))
* remove custom code ([95fed29](https://github.com/scaleapi/agents-python/commit/95fed29cc436c5a6a29790fadc4a478eee8b29e0))
* small refactors ([#46](https://github.com/scaleapi/agents-python/issues/46)) ([0a83e80](https://github.com/scaleapi/agents-python/commit/0a83e80b3b629ab178389f4dc477c9313e2c1ede))
* **test:** do not count install time for mock server timeout ([18cf2fe](https://github.com/scaleapi/agents-python/commit/18cf2fe199881b5c46e48b089a07cb78795d4c1d))
* update mock server docs ([35686a6](https://github.com/scaleapi/agents-python/commit/35686a639f80827f95e861597862bfbca171eedf))
* update SDK settings ([39aa2b2](https://github.com/scaleapi/agents-python/commit/39aa2b2cf6d6eef3f3c04c63a8bd76eb2291c849))


### Documentation

* **readme:** example snippet for client context manager ([#43](https://github.com/scaleapi/agents-python/issues/43)) ([4a225f5](https://github.com/scaleapi/agents-python/commit/4a225f5561f7525285f6d07c147fea4c32d01abb))

## 0.1.0-alpha.5 (2024-11-29)

Full Changelog: [v0.1.0-alpha.4...v0.1.0-alpha.5](https://github.com/scaleapi/agents-python/compare/v0.1.0-alpha.4...v0.1.0-alpha.5)

### Features

* **api:** api update ([#32](https://github.com/scaleapi/agents-python/issues/32)) ([d33f139](https://github.com/scaleapi/agents-python/commit/d33f139d862d334cac7a82098f55195de3649fa6))


### Chores

* **internal:** codegen related update ([#34](https://github.com/scaleapi/agents-python/issues/34)) ([9be0bf6](https://github.com/scaleapi/agents-python/commit/9be0bf64b0c90c2f18619a796295da49478666e8))
* **internal:** codegen related update ([#36](https://github.com/scaleapi/agents-python/issues/36)) ([6e58ba3](https://github.com/scaleapi/agents-python/commit/6e58ba3a2caa53ebb07c9cc6705d932aaef05e70))
* **internal:** fix compat model_dump method when warnings are passed ([#35](https://github.com/scaleapi/agents-python/issues/35)) ([f46ce06](https://github.com/scaleapi/agents-python/commit/f46ce063c9c23988b777cf01d11c50c1a36cb025))
* rebuild project due to codegen change ([#27](https://github.com/scaleapi/agents-python/issues/27)) ([b55b5e3](https://github.com/scaleapi/agents-python/commit/b55b5e3a3c1678adcbbc0c6cc268e54687a63be1))
* rebuild project due to codegen change ([#29](https://github.com/scaleapi/agents-python/issues/29)) ([a4a2617](https://github.com/scaleapi/agents-python/commit/a4a26178279e291120870693edc8a1ca3136ac8c))
* rebuild project due to codegen change ([#30](https://github.com/scaleapi/agents-python/issues/30)) ([843fa63](https://github.com/scaleapi/agents-python/commit/843fa63bbb410d61405d45f8781b14775ef2ecbf))
* rebuild project due to codegen change ([#31](https://github.com/scaleapi/agents-python/issues/31)) ([e50646f](https://github.com/scaleapi/agents-python/commit/e50646f111c9439070c557ee410905c4755a8fbc))

## 0.1.0-alpha.4 (2024-10-22)

Full Changelog: [v0.1.0-alpha.3...v0.1.0-alpha.4](https://github.com/scaleapi/agents-python/compare/v0.1.0-alpha.3...v0.1.0-alpha.4)

### Features

* **api:** api update ([#23](https://github.com/scaleapi/agents-python/issues/23)) ([26b600c](https://github.com/scaleapi/agents-python/commit/26b600c8ad74cdc44bac80b28788fea0cfcde1d6))

## 0.1.0-alpha.3 (2024-10-14)

Full Changelog: [v0.1.0-alpha.2...v0.1.0-alpha.3](https://github.com/scaleapi/agents-python/compare/v0.1.0-alpha.2...v0.1.0-alpha.3)

### Features

* **api:** api update ([#15](https://github.com/scaleapi/agents-python/issues/15)) ([391e8ed](https://github.com/scaleapi/agents-python/commit/391e8ed1a2775a2751f09b2880b8aef345943231))
* **api:** api update ([#17](https://github.com/scaleapi/agents-python/issues/17)) ([0dbd546](https://github.com/scaleapi/agents-python/commit/0dbd54672a4c3e1602f81c62f0218b521ce7a97e))
* **api:** api update ([#18](https://github.com/scaleapi/agents-python/issues/18)) ([903c321](https://github.com/scaleapi/agents-python/commit/903c321f4802082abe02146317fcfb1889b6a25d))
* **api:** api update ([#19](https://github.com/scaleapi/agents-python/issues/19)) ([5e54a2a](https://github.com/scaleapi/agents-python/commit/5e54a2a77f61fae9b94f7c515b9e18e7ce62d804))
* **api:** api update ([#20](https://github.com/scaleapi/agents-python/issues/20)) ([1bc9466](https://github.com/scaleapi/agents-python/commit/1bc94666d1e20ee7b9791de52eda04d042a80d6e))
* **api:** api update ([#21](https://github.com/scaleapi/agents-python/issues/21)) ([617dfd5](https://github.com/scaleapi/agents-python/commit/617dfd5455f0b438f285d11cd07dfbf331939ba2))


### Bug Fixes

* **internal:** handle recursive imports ([9ce182d](https://github.com/scaleapi/agents-python/commit/9ce182dce282232c8030b29c04df0d580627dbfc))

## 0.1.0-alpha.2 (2024-10-04)

Full Changelog: [v0.0.1-alpha.1...v0.1.0-alpha.2](https://github.com/scaleapi/agents-python/compare/v0.0.1-alpha.1...v0.1.0-alpha.2)

### Features

* **api:** OpenAPI spec update via Stainless API ([#12](https://github.com/scaleapi/agents-python/issues/12)) ([d2e8255](https://github.com/scaleapi/agents-python/commit/d2e825504368f072deb458f2ba4e43fa90d09437))
* **api:** OpenAPI spec update via Stainless API ([#7](https://github.com/scaleapi/agents-python/issues/7)) ([8062fc7](https://github.com/scaleapi/agents-python/commit/8062fc7d4b5b17ad87ac7616501aa40b57489fad))


### Bug Fixes

* **types:** deduplicate node item ([#11](https://github.com/scaleapi/agents-python/issues/11)) ([20b087c](https://github.com/scaleapi/agents-python/commit/20b087cfb9d2b5441dd20d06b32b8508bc6b0a98))


### Chores

* **internal:** add support for parsing bool response content ([#13](https://github.com/scaleapi/agents-python/issues/13)) ([3926753](https://github.com/scaleapi/agents-python/commit/39267530e828faaf20f9243c14fdbe56d080be42))
* **internal:** codegen related update ([#10](https://github.com/scaleapi/agents-python/issues/10)) ([551ba45](https://github.com/scaleapi/agents-python/commit/551ba45eff20663ea38219848f6b9ee6c8a66f1b))
* **internal:** codegen related update ([#8](https://github.com/scaleapi/agents-python/issues/8)) ([dd91cac](https://github.com/scaleapi/agents-python/commit/dd91cac1d451c2ae3e93d10de5d077704e25fa42))
* **internal:** codegen related update ([#9](https://github.com/scaleapi/agents-python/issues/9)) ([813e413](https://github.com/scaleapi/agents-python/commit/813e4135ffd411983bcfdd3c153539b165e6383d))
* update SDK settings ([#5](https://github.com/scaleapi/agents-python/issues/5)) ([2535b0c](https://github.com/scaleapi/agents-python/commit/2535b0cf1de9ee6c1681de30d7d812fee4fd4abd))

## 0.0.1-alpha.1 (2024-08-28)

Full Changelog: [v0.0.1-alpha.0...v0.0.1-alpha.1](https://github.com/scaleapi/agents-python/compare/v0.0.1-alpha.0...v0.0.1-alpha.1)

### Chores

* go live ([#1](https://github.com/scaleapi/agents-python/issues/1)) ([b1c9aa6](https://github.com/scaleapi/agents-python/commit/b1c9aa6639e9e1105b4f336cb7c9ff450dc5a9b4))
* update SDK settings ([#3](https://github.com/scaleapi/agents-python/issues/3)) ([139dd33](https://github.com/scaleapi/agents-python/commit/139dd33d0d444f47ce2b597491892cd9d9efd3c8))
