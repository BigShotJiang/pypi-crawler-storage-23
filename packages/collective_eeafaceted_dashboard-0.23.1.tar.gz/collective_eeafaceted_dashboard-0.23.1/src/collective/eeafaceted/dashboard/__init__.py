# -*- coding: utf-8 -*-
"""Init and utils."""

from zope.i18nmessageid import MessageFactory


FacetedDashboardMessageFactory = MessageFactory('collective.eeafaceted.dashboard')
