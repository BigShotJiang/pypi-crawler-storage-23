PROJECTNAME = 'collective.eeafaceted.dashboard'

DEFAULT_PORTLET_TITLE = u'Collections'

CURRENT_CRITERION = 'querynextprev.current_criterion'
