"""Scoring internals."""
