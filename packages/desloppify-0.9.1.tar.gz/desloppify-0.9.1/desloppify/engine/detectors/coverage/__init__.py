"""Coverage detector helpers."""

