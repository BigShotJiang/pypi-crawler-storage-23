"""Detector pattern libraries."""

