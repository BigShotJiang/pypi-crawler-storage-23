"""Work queue internals."""
