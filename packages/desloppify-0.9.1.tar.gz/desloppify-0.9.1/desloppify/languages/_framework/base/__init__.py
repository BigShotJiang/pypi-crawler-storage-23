"""Shared framework base package."""
