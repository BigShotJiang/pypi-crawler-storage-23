"""Review context internals."""
