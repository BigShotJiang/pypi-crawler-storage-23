"""Search-oriented core utilities."""

