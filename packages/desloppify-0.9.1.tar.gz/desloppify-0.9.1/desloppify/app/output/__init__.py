"""Output generation package."""
