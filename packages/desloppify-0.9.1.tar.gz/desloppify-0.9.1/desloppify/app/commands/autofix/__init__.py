"""Autofix command package."""
