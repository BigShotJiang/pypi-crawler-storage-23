"""Domain models used across the ncheck application."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


def _strip_none(raw_data: dict[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in raw_data.items() if value is not None}


@dataclass(slots=True)
class PingResult:
    """Represents the normalized result of a ping execution."""

    host: str
    status: str
    avg_latency_ms: float | None = None
    min_latency_ms: float | None = None
    max_latency_ms: float | None = None
    packet_loss_percent: float | None = None
    error_message: str | None = None

    @property
    def ok(self) -> bool:
        return self.status == "success"

    def to_dict(self) -> dict[str, Any]:
        return _strip_none(
            {
                "host": self.host,
                "status": self.status,
                "avg_latency_ms": self.avg_latency_ms,
                "min_latency_ms": self.min_latency_ms,
                "max_latency_ms": self.max_latency_ms,
                "packet_loss_percent": self.packet_loss_percent,
                "error_message": self.error_message,
            }
        )


@dataclass(slots=True)
class DnsResult:
    """Represents the normalized result of a DNS lookup."""

    host: str
    status: str
    query_type: str
    addresses: list[str] | None = None
    error_message: str | None = None

    @property
    def ok(self) -> bool:
        return self.status == "success"

    def to_dict(self) -> dict[str, Any]:
        return _strip_none(
            {
                "host": self.host,
                "status": self.status,
                "query_type": self.query_type,
                "addresses": self.addresses,
                "error_message": self.error_message,
            }
        )


@dataclass(slots=True)
class HttpResult:
    """Represents the normalized result of an HTTP check."""

    url: str
    status: str
    method: str
    http_status_code: int | None = None
    reason: str | None = None
    response_time_ms: float | None = None
    final_url: str | None = None
    error_message: str | None = None

    @property
    def ok(self) -> bool:
        return self.status == "success"

    def to_dict(self) -> dict[str, Any]:
        return _strip_none(
            {
                "url": self.url,
                "status": self.status,
                "method": self.method,
                "http_status_code": self.http_status_code,
                "reason": self.reason,
                "response_time_ms": self.response_time_ms,
                "final_url": self.final_url,
                "error_message": self.error_message,
            }
        )


@dataclass(slots=True)
class PortScanResult:
    """Represents the normalized result of a TCP port scan."""

    host: str
    status: str
    tested_ports: list[int] | None = None
    open_ports: list[int] | None = None
    closed_ports: list[int] | None = None
    timeout_seconds: float | None = None
    error_message: str | None = None

    @property
    def ok(self) -> bool:
        return self.status == "success"

    def to_dict(self) -> dict[str, Any]:
        return _strip_none(
            {
                "host": self.host,
                "status": self.status,
                "tested_ports": self.tested_ports,
                "open_ports": self.open_ports,
                "closed_ports": self.closed_ports,
                "timeout_seconds": self.timeout_seconds,
                "error_message": self.error_message,
            }
        )


@dataclass(slots=True)
class TracerouteResult:
    """Represents a traceroute execution result."""

    host: str
    status: str
    max_hops: int
    timeout_seconds: float
    hop_count: int | None = None
    hops: list[str] | None = None
    error_message: str | None = None

    @property
    def ok(self) -> bool:
        return self.status == "success"

    def to_dict(self) -> dict[str, Any]:
        return _strip_none(
            {
                "host": self.host,
                "status": self.status,
                "max_hops": self.max_hops,
                "timeout_seconds": self.timeout_seconds,
                "hop_count": self.hop_count,
                "hops": self.hops,
                "error_message": self.error_message,
            }
        )


@dataclass(slots=True)
class TlsResult:
    """Represents a TLS inspection result."""

    host: str
    status: str
    port: int
    protocol: str | None = None
    cipher: str | None = None
    subject: str | None = None
    issuer: str | None = None
    not_before: str | None = None
    not_after: str | None = None
    days_remaining: int | None = None
    warnings: list[str] | None = None
    error_message: str | None = None

    @property
    def ok(self) -> bool:
        return self.status == "success" and not self.warnings

    def to_dict(self) -> dict[str, Any]:
        return _strip_none(
            {
                "host": self.host,
                "status": self.status,
                "port": self.port,
                "protocol": self.protocol,
                "cipher": self.cipher,
                "subject": self.subject,
                "issuer": self.issuer,
                "not_before": self.not_before,
                "not_after": self.not_after,
                "days_remaining": self.days_remaining,
                "warnings": self.warnings,
                "error_message": self.error_message,
            }
        )


@dataclass(slots=True)
class SecurityAuditResult:
    """Represents a lightweight security posture audit."""

    host: str
    status: str
    scan_ports: list[int]
    open_ports: list[int] | None = None
    risky_open_ports: list[int] | None = None
    missing_security_headers: list[str] | None = None
    findings: list[str] | None = None
    recommendations: list[str] | None = None
    risk_level: str | None = None
    risk_score: int | None = None
    audited_url: str | None = None
    error_message: str | None = None

    @property
    def ok(self) -> bool:
        return self.status == "success" and (self.risk_score or 0) == 0

    def to_dict(self) -> dict[str, Any]:
        return _strip_none(
            {
                "host": self.host,
                "status": self.status,
                "scan_ports": self.scan_ports,
                "open_ports": self.open_ports,
                "risky_open_ports": self.risky_open_ports,
                "missing_security_headers": self.missing_security_headers,
                "findings": self.findings,
                "recommendations": self.recommendations,
                "risk_level": self.risk_level,
                "risk_score": self.risk_score,
                "audited_url": self.audited_url,
                "error_message": self.error_message,
            }
        )


@dataclass(slots=True)
class SystemUsageResult:
    """Represents local system resource diagnostics."""

    status: str
    cpu_percent: float | None = None
    cpu_count_logical: int | None = None
    cpu_count_physical: int | None = None
    memory_total_mb: float | None = None
    memory_used_mb: float | None = None
    memory_percent: float | None = None
    swap_percent: float | None = None
    top_processes: list[dict[str, Any]] | None = None
    error_message: str | None = None

    @property
    def ok(self) -> bool:
        return self.status == "success"

    def to_dict(self) -> dict[str, Any]:
        return _strip_none(
            {
                "status": self.status,
                "cpu_percent": self.cpu_percent,
                "cpu_count_logical": self.cpu_count_logical,
                "cpu_count_physical": self.cpu_count_physical,
                "memory_total_mb": self.memory_total_mb,
                "memory_used_mb": self.memory_used_mb,
                "memory_percent": self.memory_percent,
                "swap_percent": self.swap_percent,
                "top_processes": self.top_processes,
                "error_message": self.error_message,
            }
        )


@dataclass(slots=True)
class AttackSurfaceResult:
    """Represents a composed external attack-surface assessment."""

    host: str
    status: str
    scan_ports: list[int]
    resolved_addresses: list[str] | None = None
    open_ports: list[int] | None = None
    tls_summary: dict[str, Any] | None = None
    http_summary: dict[str, Any] | None = None
    findings: list[str] | None = None
    recommendations: list[str] | None = None
    risk_level: str | None = None
    risk_score: int | None = None
    error_message: str | None = None

    @property
    def ok(self) -> bool:
        return self.status == "success" and (self.risk_score or 0) == 0

    def to_dict(self) -> dict[str, Any]:
        return _strip_none(
            {
                "host": self.host,
                "status": self.status,
                "scan_ports": self.scan_ports,
                "resolved_addresses": self.resolved_addresses,
                "open_ports": self.open_ports,
                "tls_summary": self.tls_summary,
                "http_summary": self.http_summary,
                "findings": self.findings,
                "recommendations": self.recommendations,
                "risk_level": self.risk_level,
                "risk_score": self.risk_score,
                "error_message": self.error_message,
            }
        )


@dataclass(slots=True)
class OsintDomainResult:
    """Represents passive OSINT findings for a domain/host."""

    target: str
    status: str
    whois_server: str | None = None
    registrar: str | None = None
    creation_date: str | None = None
    expiry_date: str | None = None
    name_servers: list[str] | None = None
    dns_records: dict[str, list[str]] | None = None
    subdomains: list[str] | None = None
    total_subdomains: int | None = None
    security_txt_url: str | None = None
    security_txt_present: bool | None = None
    robots_txt_present: bool | None = None
    sitemap_xml_present: bool | None = None
    findings: list[str] | None = None
    recommendations: list[str] | None = None
    risk_level: str | None = None
    risk_score: int | None = None
    error_message: str | None = None

    @property
    def ok(self) -> bool:
        return self.status == "success"

    def to_dict(self) -> dict[str, Any]:
        return _strip_none(
            {
                "target": self.target,
                "status": self.status,
                "whois_server": self.whois_server,
                "registrar": self.registrar,
                "creation_date": self.creation_date,
                "expiry_date": self.expiry_date,
                "name_servers": self.name_servers,
                "dns_records": self.dns_records,
                "subdomains": self.subdomains,
                "total_subdomains": self.total_subdomains,
                "security_txt_url": self.security_txt_url,
                "security_txt_present": self.security_txt_present,
                "robots_txt_present": self.robots_txt_present,
                "sitemap_xml_present": self.sitemap_xml_present,
                "findings": self.findings,
                "recommendations": self.recommendations,
                "risk_level": self.risk_level,
                "risk_score": self.risk_score,
                "error_message": self.error_message,
            }
        )


@dataclass(slots=True)
class OsintEmailResult:
    """Represents passive OSINT findings for an email identity."""

    email: str
    status: str
    domain: str
    mx_records: list[str] | None = None
    gravatar_url: str | None = None
    breaches: list[dict[str, Any]] | None = None
    breach_count: int | None = None
    findings: list[str] | None = None
    recommendations: list[str] | None = None
    risk_level: str | None = None
    risk_score: int | None = None
    error_message: str | None = None

    @property
    def ok(self) -> bool:
        return self.status == "success"

    def to_dict(self) -> dict[str, Any]:
        return _strip_none(
            {
                "email": self.email,
                "status": self.status,
                "domain": self.domain,
                "mx_records": self.mx_records,
                "gravatar_url": self.gravatar_url,
                "breaches": self.breaches,
                "breach_count": self.breach_count,
                "findings": self.findings,
                "recommendations": self.recommendations,
                "risk_level": self.risk_level,
                "risk_score": self.risk_score,
                "error_message": self.error_message,
            }
        )


@dataclass(slots=True)
class PersonalSecurityResult:
    """Represents local personal-security hygiene checks."""

    status: str
    platform: str
    hostname: str
    firewall_status: str | None = None
    listening_ports: list[dict[str, Any]] | None = None
    risky_listening_ports: list[dict[str, Any]] | None = None
    findings: list[str] | None = None
    recommendations: list[str] | None = None
    risk_level: str | None = None
    risk_score: int | None = None
    error_message: str | None = None

    @property
    def ok(self) -> bool:
        return self.status == "success"

    def to_dict(self) -> dict[str, Any]:
        return _strip_none(
            {
                "status": self.status,
                "platform": self.platform,
                "hostname": self.hostname,
                "firewall_status": self.firewall_status,
                "listening_ports": self.listening_ports,
                "risky_listening_ports": self.risky_listening_ports,
                "findings": self.findings,
                "recommendations": self.recommendations,
                "risk_level": self.risk_level,
                "risk_score": self.risk_score,
                "error_message": self.error_message,
            }
        )
