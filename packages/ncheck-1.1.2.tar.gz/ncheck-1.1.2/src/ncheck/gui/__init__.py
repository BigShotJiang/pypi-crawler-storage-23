"""GUI entry points and helpers for ncheck."""

from ncheck.gui.launcher import launch_streamlit_dashboard

__all__ = ["launch_streamlit_dashboard"]
