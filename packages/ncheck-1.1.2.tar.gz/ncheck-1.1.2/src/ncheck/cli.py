from __future__ import annotations

import json
from pathlib import Path
from typing import Literal

import typer
from rich.console import Console
from rich.panel import Panel

from ncheck import __version__
from ncheck.gui.launcher import launch_streamlit_dashboard
from ncheck.helpers import dict_to_table
from ncheck.logic import (available_checks, build_batch_report,
                          execute_check_safe, load_batch_plan, normalize_host,
                          parse_ports_spec)
from ncheck.services import (run_attack_surface_assessment, run_dns_lookup,
                             run_http_check, run_osint_domain, run_osint_email,
                             run_personal_security_check, run_ping,
                             run_port_scan, run_security_audit,
                             run_system_usage, run_tls_inspection,
                             run_traceroute)

app = typer.Typer(
    add_completion=True,
    no_args_is_help=True,
    rich_markup_mode="rich",
    help="Network diagnostics CLI with professional terminal output.",
)
console = Console()


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(f"ncheck {__version__}")
        raise typer.Exit()


def _render_output(
    payload: dict[str, object],
    title: str,
    ok: bool,
    json_output: bool,
) -> None:
    if json_output:
        typer.echo(json.dumps(payload, indent=2, sort_keys=True))
        return

    border_style = "green" if ok else "red"
    table = dict_to_table(payload, title=title)
    console.print(Panel(table, border_style=border_style))


def _resolve_host(raw_host: str | None, *, prompt_label: str) -> str:
    host = raw_host if raw_host is not None else typer.prompt(prompt_label)
    try:
        return normalize_host(host)
    except ValueError as exc:
        raise typer.BadParameter(str(exc)) from exc


def _resolve_ports(raw_ports: str) -> list[int]:
    try:
        return parse_ports_spec(raw_ports)
    except ValueError as exc:
        raise typer.BadParameter(str(exc)) from exc


@app.callback()
def main(
    version: bool | None = typer.Option(
        None,
        "--version",
        callback=_version_callback,
        is_eager=True,
        help="Show installed ncheck version and exit.",
    ),
) -> None:
    """Professional network diagnostics in your terminal."""


@app.command()
def ping(
    host: str | None = typer.Argument(
        None,
        help="Host or IP address to ping.",
    ),
    count: int = typer.Option(
        4,
        "--count",
        "-c",
        min=1,
        max=20,
        help="Number of ICMP requests to send.",
    ),
    timeout: float = typer.Option(
        2.0,
        "--timeout",
        "-t",
        min=0.1,
        max=30.0,
        help="Timeout in seconds per request.",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Print output as JSON for automation.",
    ),
) -> None:
    """Run ping diagnostics against a host."""

    normalized_host = _resolve_host(host, prompt_label="Host to ping")

    result = run_ping(normalized_host, count=count, timeout=timeout)
    _render_output(
        payload=result.to_dict(),
        title="Ping Report",
        ok=result.ok,
        json_output=json_output,
    )

    if not result.ok:
        raise typer.Exit(code=1)


@app.command("traceroute")
def traceroute_command(
    host: str | None = typer.Argument(
        None,
        help="Host or IP for route tracing.",
    ),
    max_hops: int = typer.Option(
        20,
        "--max-hops",
        "-m",
        min=1,
        max=64,
        help="Maximum hops before traceroute stops.",
    ),
    timeout: float = typer.Option(
        1.5,
        "--timeout",
        "-t",
        min=0.1,
        max=10.0,
        help="Timeout in seconds per hop probe.",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Print output as JSON for automation.",
    ),
) -> None:
    """Trace network path to a host."""

    normalized_host = _resolve_host(host, prompt_label="Host to trace")

    result = run_traceroute(normalized_host, max_hops=max_hops, timeout_seconds=timeout)
    _render_output(
        payload=result.to_dict(),
        title="Traceroute Report",
        ok=result.ok,
        json_output=json_output,
    )

    if not result.ok:
        raise typer.Exit(code=1)


@app.command("tls")
def tls_inspect(
    host: str | None = typer.Argument(
        None,
        help="Host with TLS endpoint.",
    ),
    port: int = typer.Option(
        443,
        "--port",
        "-p",
        min=1,
        max=65535,
        help="TLS service port.",
    ),
    timeout: float = typer.Option(
        5.0,
        "--timeout",
        "-t",
        min=0.2,
        max=30.0,
        help="Socket timeout in seconds.",
    ),
    fail_on_warnings: bool = typer.Option(
        False,
        "--fail-on-warnings/--no-fail-on-warnings",
        help="Return exit code 1 when certificate warnings are present.",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Print output as JSON for automation.",
    ),
) -> None:
    """Inspect TLS certificate and negotiated protocol."""

    normalized_host = _resolve_host(host, prompt_label="Host to inspect")

    result = run_tls_inspection(normalized_host, port=port, timeout_seconds=timeout)
    _render_output(
        payload=result.to_dict(),
        title="TLS Report",
        ok=result.status == "success",
        json_output=json_output,
    )

    if result.status != "success":
        raise typer.Exit(code=1)
    if fail_on_warnings and result.warnings:
        raise typer.Exit(code=1)


@app.command("dns")
def dns_lookup(
    host: str | None = typer.Argument(
        None,
        help="Host to resolve through DNS.",
    ),
    family: Literal["any", "ipv4", "ipv6"] = typer.Option(
        "any",
        "--family",
        "-f",
        help="Address family to query.",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Print output as JSON for automation.",
    ),
) -> None:
    """Resolve hostnames to IP addresses."""

    normalized_host = _resolve_host(host, prompt_label="Host to resolve")

    result = run_dns_lookup(normalized_host, family=family)
    _render_output(
        payload=result.to_dict(),
        title="DNS Report",
        ok=result.ok,
        json_output=json_output,
    )

    if not result.ok:
        raise typer.Exit(code=1)


@app.command("http")
def http_check(
    url: str | None = typer.Argument(
        None,
        help="Target URL (scheme optional, defaults to https).",
    ),
    method: Literal["GET", "HEAD"] = typer.Option(
        "GET",
        "--method",
        "-m",
        help="HTTP method used for the check.",
    ),
    timeout: float = typer.Option(
        5.0,
        "--timeout",
        "-t",
        min=0.1,
        max=60.0,
        help="Request timeout in seconds.",
    ),
    follow_redirects: bool = typer.Option(
        True,
        "--follow-redirects/--no-follow-redirects",
        help="Follow HTTP redirects.",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Print output as JSON for automation.",
    ),
) -> None:
    """Validate HTTP reachability and response behavior."""

    if url is None:
        url = typer.prompt("URL to check")

    try:
        result = run_http_check(
            url=url,
            method=method,
            timeout=timeout,
            follow_redirects=follow_redirects,
        )
    except ValueError as exc:
        raise typer.BadParameter(str(exc)) from exc
    _render_output(
        payload=result.to_dict(),
        title="HTTP Report",
        ok=result.ok,
        json_output=json_output,
    )

    if not result.ok:
        raise typer.Exit(code=1)


@app.command("system")
def system_usage(
    interval: float = typer.Option(
        0.2,
        "--interval",
        "-i",
        min=0.1,
        max=5.0,
        help="Sampling interval in seconds for CPU percent.",
    ),
    top: int = typer.Option(
        8,
        "--top",
        min=1,
        max=30,
        help="Number of top processes by CPU/memory to include.",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Print output as JSON for automation.",
    ),
) -> None:
    """Show local CPU, memory and top process usage."""

    result = run_system_usage(interval_seconds=interval, top=top)
    _render_output(
        payload=result.to_dict(),
        title="System Resource Report",
        ok=result.ok,
        json_output=json_output,
    )

    if not result.ok:
        raise typer.Exit(code=1)


@app.command("audit")
def security_audit(
    host: str | None = typer.Argument(
        None,
        help="Target host for defensive security posture audit.",
    ),
    ports: str = typer.Option(
        "21,22,23,80,443,445,3389",
        "--ports",
        "-p",
        help="Port scope for exposure checks.",
    ),
    timeout: float = typer.Option(
        1.0,
        "--timeout",
        "-t",
        min=0.1,
        max=10.0,
        help="Timeout in seconds per connection test.",
    ),
    workers: int = typer.Option(
        120,
        "--workers",
        "-w",
        min=1,
        max=512,
        help="Number of concurrent workers for scanning.",
    ),
    url: str | None = typer.Option(
        None,
        "--url",
        help="Optional URL for HTTP security header checks.",
    ),
    authorized: bool = typer.Option(
        False,
        "--authorized",
        help="Confirms you are authorized to assess this target.",
    ),
    fail_on_findings: bool = typer.Option(
        True,
        "--fail-on-findings/--no-fail-on-findings",
        help="Return exit code 1 when medium/high risk findings are present.",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Print output as JSON for automation.",
    ),
) -> None:
    """Run a defensive pentest-style exposure audit (authorized targets only)."""

    if not authorized:
        raise typer.BadParameter(
            "For legal and ethical use, pass --authorized to confirm target authorization."
        )

    normalized_host = _resolve_host(host, prompt_label="Host to audit")
    parsed_ports = _resolve_ports(ports)

    result = run_security_audit(
        host=normalized_host,
        ports=parsed_ports,
        timeout_seconds=timeout,
        workers=workers,
        url=url,
    )
    _render_output(
        payload=result.to_dict(),
        title="Security Audit Report",
        ok=result.status == "success" and ((result.risk_score or 0) == 0),
        json_output=json_output,
    )

    if result.status != "success":
        raise typer.Exit(code=1)
    if fail_on_findings and not result.ok:
        raise typer.Exit(code=1)


@app.command("ports")
def port_scan(
    host: str | None = typer.Argument(
        None,
        help="Host to scan for open TCP ports.",
    ),
    ports: str = typer.Option(
        "22,80,443",
        "--ports",
        "-p",
        help="Port list (e.g. 22,80,443 or 1-1024).",
    ),
    timeout: float = typer.Option(
        0.6,
        "--timeout",
        "-t",
        min=0.05,
        max=10.0,
        help="Connection timeout per port in seconds.",
    ),
    workers: int = typer.Option(
        100,
        "--workers",
        "-w",
        min=1,
        max=512,
        help="Number of concurrent scan workers.",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Print output as JSON for automation.",
    ),
) -> None:
    """Scan target host for open TCP ports."""

    normalized_host = _resolve_host(host, prompt_label="Host to scan")
    parsed_ports = _resolve_ports(ports)

    result = run_port_scan(
        host=normalized_host,
        ports=parsed_ports,
        timeout=timeout,
        workers=workers,
    )
    _render_output(
        payload=result.to_dict(),
        title="Port Scan Report",
        ok=result.ok,
        json_output=json_output,
    )

    if not result.ok:
        raise typer.Exit(code=1)


@app.command("surface")
def attack_surface(
    host: str | None = typer.Argument(
        None,
        help="Target host for authorized attack-surface assessment.",
    ),
    ports: str = typer.Option(
        "21,22,23,80,443,445,3389",
        "--ports",
        "-p",
        help="Port scope for surface mapping.",
    ),
    timeout: float = typer.Option(
        1.0,
        "--timeout",
        "-t",
        min=0.1,
        max=10.0,
        help="Timeout in seconds per network operation.",
    ),
    workers: int = typer.Option(
        120,
        "--workers",
        "-w",
        min=1,
        max=512,
        help="Number of concurrent workers for scan phases.",
    ),
    tls_port: int = typer.Option(
        443,
        "--tls-port",
        min=1,
        max=65535,
        help="TLS endpoint port used in certificate assessment.",
    ),
    http_method: Literal["GET", "HEAD"] = typer.Option(
        "HEAD",
        "--http-method",
        help="HTTP method for endpoint validation in surface report.",
    ),
    url: str | None = typer.Option(
        None,
        "--url",
        help="Optional URL to include in HTTP surface checks.",
    ),
    authorized: bool = typer.Option(
        False,
        "--authorized",
        help="Confirms you are authorized to assess this target.",
    ),
    fail_on_findings: bool = typer.Option(
        True,
        "--fail-on-findings/--no-fail-on-findings",
        help="Return exit code 1 when medium/high risk findings are present.",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Print output as JSON for automation.",
    ),
) -> None:
    """Run a composed attack-surface assessment (authorized targets only)."""

    if not authorized:
        raise typer.BadParameter(
            "For legal and ethical use, pass --authorized to confirm target authorization."
        )

    normalized_host = _resolve_host(host, prompt_label="Host to assess")
    parsed_ports = _resolve_ports(ports)

    result = run_attack_surface_assessment(
        host=normalized_host,
        ports=parsed_ports,
        authorized=True,
        timeout_seconds=timeout,
        workers=workers,
        url=url,
        tls_port=tls_port,
        http_method=http_method,
    )
    _render_output(
        payload=result.to_dict(),
        title="Attack Surface Report",
        ok=result.status == "success" and ((result.risk_score or 0) == 0),
        json_output=json_output,
    )

    if result.status != "success":
        raise typer.Exit(code=1)
    if fail_on_findings and not result.ok:
        raise typer.Exit(code=1)


@app.command("osint-domain")
def osint_domain(
    target: str | None = typer.Argument(
        None,
        help="Domain/host to collect passive OSINT intelligence.",
    ),
    timeout: float = typer.Option(
        5.0,
        "--timeout",
        "-t",
        min=0.2,
        max=30.0,
        help="Timeout in seconds per remote request.",
    ),
    include_subdomains: bool = typer.Option(
        True,
        "--include-subdomains/--no-include-subdomains",
        help="Query Certificate Transparency logs for discovered subdomains.",
    ),
    max_subdomains: int = typer.Option(
        250,
        "--max-subdomains",
        min=1,
        max=2000,
        help="Maximum number of subdomains to keep in output.",
    ),
    fail_on_findings: bool = typer.Option(
        False,
        "--fail-on-findings/--no-fail-on-findings",
        help="Return exit code 1 when risk findings are present.",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Print output as JSON for automation.",
    ),
) -> None:
    """Run passive OSINT on domain metadata and public exposure signals."""

    normalized_target = _resolve_host(target, prompt_label="Domain/host for OSINT")
    result = run_osint_domain(
        target=normalized_target,
        timeout_seconds=timeout,
        include_subdomains=include_subdomains,
        max_subdomains=max_subdomains,
    )
    _render_output(
        payload=result.to_dict(),
        title="OSINT Domain Report",
        ok=result.status == "success" and ((result.risk_score or 0) == 0),
        json_output=json_output,
    )

    if result.status != "success":
        raise typer.Exit(code=1)
    if fail_on_findings and (result.risk_score or 0) > 0:
        raise typer.Exit(code=1)


@app.command("osint-email")
def osint_email(
    email: str | None = typer.Argument(
        None,
        help="Email identity to inspect using passive OSINT sources.",
    ),
    timeout: float = typer.Option(
        5.0,
        "--timeout",
        "-t",
        min=0.2,
        max=30.0,
        help="Timeout in seconds per remote request.",
    ),
    hibp_api_key: str | None = typer.Option(
        None,
        "--hibp-api-key",
        envvar="HIBP_API_KEY",
        help="Optional HaveIBeenPwned API key for breach intelligence.",
    ),
    fail_on_findings: bool = typer.Option(
        False,
        "--fail-on-findings/--no-fail-on-findings",
        help="Return exit code 1 when risk findings are present.",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Print output as JSON for automation.",
    ),
) -> None:
    """Run passive OSINT on an email identity (defensive profile)."""

    if email is None:
        email = typer.prompt("Email for OSINT")

    result = run_osint_email(
        email=email,
        timeout_seconds=timeout,
        hibp_api_key=hibp_api_key,
    )
    _render_output(
        payload=result.to_dict(),
        title="OSINT Email Report",
        ok=result.status == "success" and ((result.risk_score or 0) == 0),
        json_output=json_output,
    )

    if result.status != "success":
        raise typer.Exit(code=1)
    if fail_on_findings and (result.risk_score or 0) > 0:
        raise typer.Exit(code=1)


@app.command("personal-security")
def personal_security(
    top_ports: int = typer.Option(
        30,
        "--top-ports",
        min=1,
        max=200,
        help="Maximum number of listening ports to include in output.",
    ),
    risky_ports: str = typer.Option(
        "21,23,445,3389,5900,6379,27017",
        "--risky-ports",
        help="Custom risky ports used for local hygiene classification.",
    ),
    fail_on_findings: bool = typer.Option(
        False,
        "--fail-on-findings/--no-fail-on-findings",
        help="Return exit code 1 when risk findings are present.",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Print output as JSON for automation.",
    ),
) -> None:
    """Run local personal-security posture checks (firewall + exposed services)."""

    parsed_risky_ports = _resolve_ports(risky_ports)
    result = run_personal_security_check(
        top_ports=top_ports,
        risky_ports=parsed_risky_ports,
    )
    _render_output(
        payload=result.to_dict(),
        title="Personal Security Report",
        ok=result.status == "success" and ((result.risk_score or 0) == 0),
        json_output=json_output,
    )

    if result.status != "success":
        raise typer.Exit(code=1)
    if fail_on_findings and (result.risk_score or 0) > 0:
        raise typer.Exit(code=1)


@app.command("batch")
def batch_run(
    plan_file: Path = typer.Argument(
        ...,
        exists=True,
        dir_okay=False,
        readable=True,
        resolve_path=True,
        help="Path to a JSON/YAML batch plan file.",
    ),
    stop_on_error: bool = typer.Option(
        False,
        "--stop-on-error",
        help="Stop execution immediately after the first failed check.",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Print output as JSON for automation.",
    ),
) -> None:
    """Run multiple diagnostics from a declarative JSON/YAML plan."""

    try:
        checks_plan = load_batch_plan(plan_file)
    except ValueError as exc:
        raise typer.BadParameter(str(exc)) from exc

    executions = []
    for check_entry in checks_plan:
        execution = execute_check_safe(
            check=str(check_entry["check"]),
            options=check_entry.get("options", {}),
        )
        executions.append(execution)

        if stop_on_error and not execution.ok:
            break

    report = build_batch_report(executions)
    _render_output(
        payload=report,
        title="Batch Diagnostics Report",
        ok=report["status"] == "success",
        json_output=json_output,
    )

    if report["status"] != "success":
        raise typer.Exit(code=1)


@app.command("gui")
def launch_gui(
    host: str = typer.Option(
        "127.0.0.1",
        "--host",
        help="Address used by the GUI web server.",
    ),
    port: int = typer.Option(
        8501,
        "--port",
        min=1,
        max=65535,
        help="Port used by the GUI web server.",
    ),
    headless: bool = typer.Option(
        False,
        "--headless",
        help="Start GUI server without opening browser automatically.",
    ),
) -> None:
    """Start the enterprise web dashboard for interactive diagnostics."""

    try:
        exit_code = launch_streamlit_dashboard(
            host=host,
            port=port,
            headless=headless,
        )
    except RuntimeError as exc:
        raise typer.BadParameter(
            f"{exc} Available checks: {', '.join(available_checks())}."
        ) from exc

    if exit_code != 0:
        raise typer.Exit(code=exit_code)


if __name__ == "__main__":
    app()
