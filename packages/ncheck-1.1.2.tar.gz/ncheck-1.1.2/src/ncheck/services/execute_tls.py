"""Service layer for TLS certificate and protocol inspection."""

from __future__ import annotations

import socket
import ssl
from datetime import UTC, datetime

from ncheck.logic import normalize_host
from ncheck.models import TlsResult

_CERT_DATE_FORMAT = "%b %d %H:%M:%S %Y %Z"


def _flatten_name(name_parts: tuple[tuple[tuple[str, str], ...], ...]) -> str:
    for part in name_parts:
        for key, value in part:
            if key == "commonName":
                return value
    return "unknown"


def _parse_certificate_date(raw_value: str | None) -> datetime | None:
    if not raw_value:
        return None
    try:
        parsed = datetime.strptime(raw_value, _CERT_DATE_FORMAT)
    except ValueError:
        return None
    return parsed.replace(tzinfo=UTC)


def run_tls_inspection(
    host: str, port: int = 443, timeout_seconds: float = 5.0
) -> TlsResult:
    normalized_host = normalize_host(host)
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE

    try:
        with socket.create_connection(
            (normalized_host, port),
            timeout=timeout_seconds,
        ) as raw_socket:
            with context.wrap_socket(
                raw_socket, server_hostname=normalized_host
            ) as tls_socket:
                cert = tls_socket.getpeercert()
                protocol = tls_socket.version()
                cipher = tls_socket.cipher()[0] if tls_socket.cipher() else None
    except Exception as exc:
        return TlsResult(
            host=normalized_host,
            status="error",
            port=port,
            error_message=str(exc),
        )

    subject = _flatten_name(cert.get("subject", ()))
    issuer = _flatten_name(cert.get("issuer", ()))
    not_before_raw = cert.get("notBefore")
    not_after_raw = cert.get("notAfter")
    not_after_date = _parse_certificate_date(not_after_raw)

    days_remaining: int | None = None
    warnings: list[str] = []
    now = datetime.now(tz=UTC)
    if not_after_date:
        days_remaining = (not_after_date - now).days
        if days_remaining < 0:
            warnings.append("Certificate is expired.")
        elif days_remaining < 30:
            warnings.append("Certificate will expire in less than 30 days.")

    if protocol in {"TLSv1", "TLSv1.1"}:
        warnings.append(f"Weak TLS protocol negotiated: {protocol}.")

    return TlsResult(
        host=normalized_host,
        status="success",
        port=port,
        protocol=protocol,
        cipher=cipher,
        subject=subject,
        issuer=issuer,
        not_before=not_before_raw,
        not_after=not_after_raw,
        days_remaining=days_remaining,
        warnings=warnings or None,
    )
