"""Service layer for local personal-security posture checks."""

from __future__ import annotations

import importlib
import platform
import socket
import subprocess
from typing import Any

from ncheck.models import PersonalSecurityResult

_DEFAULT_RISKY_PORTS = {
    21: "FTP",
    23: "Telnet",
    445: "SMB",
    3389: "RDP",
    5900: "VNC",
    6379: "Redis",
    27017: "MongoDB",
}


def _risk_level(score: int) -> str:
    if score == 0:
        return "low"
    if score <= 3:
        return "medium"
    return "high"


def _detect_firewall_status(system_name: str) -> str:
    if system_name.startswith("win"):
        try:
            result = subprocess.run(
                ["netsh", "advfirewall", "show", "allprofiles", "state"],
                capture_output=True,
                text=True,
                check=False,
            )
        except FileNotFoundError:
            return "unknown"

        output = f"{result.stdout}\n{result.stderr}".upper()
        if "OFF" in output:
            return "off"
        if "ON" in output:
            return "on"
        return "unknown"

    if system_name == "linux":
        for command in (
            ["ufw", "status"],
            ["firewall-cmd", "--state"],
        ):
            try:
                result = subprocess.run(
                    command,
                    capture_output=True,
                    text=True,
                    check=False,
                )
            except FileNotFoundError:
                continue

            output = f"{result.stdout}\n{result.stderr}".lower()
            if "active" in output or "running" in output:
                return "on"
            if "inactive" in output or "not running" in output:
                return "off"

        return "unknown"

    if system_name == "darwin":
        try:
            result = subprocess.run(
                ["/usr/libexec/ApplicationFirewall/socketfilterfw", "--getglobalstate"],
                capture_output=True,
                text=True,
                check=False,
            )
        except FileNotFoundError:
            return "unknown"

        output = f"{result.stdout}\n{result.stderr}".lower()
        if "enabled" in output:
            return "on"
        if "disabled" in output:
            return "off"

    return "unknown"


def _collect_listening_ports(
    psutil: Any,
    *,
    top_ports: int,
    risky_ports: dict[int, str],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    records: dict[tuple[int, str, int], dict[str, Any]] = {}
    for connection in psutil.net_connections(kind="inet"):
        status = str(getattr(connection, "status", "")).upper()
        if status != "LISTEN":
            continue

        local_address = getattr(connection, "laddr", None)
        if not local_address:
            continue

        ip = str(getattr(local_address, "ip", "") or "")
        port = int(getattr(local_address, "port", 0) or 0)
        pid = int(getattr(connection, "pid", 0) or 0)
        if port <= 0:
            continue

        process_name = "unknown"
        if pid > 0:
            try:
                process_name = str(psutil.Process(pid).name() or "unknown")
            except Exception:
                process_name = "unknown"

        key = (port, ip, pid)
        records[key] = {
            "port": port,
            "address": ip,
            "pid": pid,
            "process": process_name,
            "service_risk_hint": risky_ports.get(port),
        }

    listening_ports = sorted(
        records.values(), key=lambda item: (item["port"], item["address"])
    )
    limited_ports = listening_ports[: max(1, top_ports)]
    risky_listening_ports = [
        item for item in limited_ports if int(item.get("port", 0)) in risky_ports
    ]
    return limited_ports, risky_listening_ports


def run_personal_security_check(
    top_ports: int = 30,
    risky_ports: list[int] | None = None,
) -> PersonalSecurityResult:
    try:
        psutil = importlib.import_module("psutil")
    except ModuleNotFoundError:
        return PersonalSecurityResult(
            status="error",
            platform=platform.system().lower(),
            hostname=socket.gethostname(),
            error_message="Dependency 'psutil' is missing. Install with: pip install -e .",
        )

    system_name = platform.system().lower()
    hostname = socket.gethostname()
    selected_risky_ports: dict[int, str]
    if risky_ports:
        selected_risky_ports = {
            int(port): _DEFAULT_RISKY_PORTS.get(int(port), "Custom risky port")
            for port in risky_ports
            if 1 <= int(port) <= 65535
        }
    else:
        selected_risky_ports = dict(_DEFAULT_RISKY_PORTS)

    try:
        firewall_status = _detect_firewall_status(system_name)
        listening_ports, risky_listening_ports = _collect_listening_ports(
            psutil,
            top_ports=max(1, top_ports),
            risky_ports=selected_risky_ports,
        )
    except Exception as exc:
        return PersonalSecurityResult(
            status="error",
            platform=system_name,
            hostname=hostname,
            error_message=str(exc),
        )

    findings: list[str] = []
    recommendations: list[str] = []
    risk_score = 0

    if firewall_status == "off":
        findings.append("Host firewall appears to be disabled.")
        recommendations.append("Enable host firewall profiles for all network zones.")
        risk_score += 3
    elif firewall_status == "unknown":
        findings.append("Firewall status could not be verified automatically.")
        recommendations.append("Validate firewall state manually on this host.")
        risk_score += 1

    if risky_listening_ports:
        unique_risky_ports = sorted(
            {int(entry["port"]) for entry in risky_listening_ports}
        )
        exposed_ports = ", ".join(str(port) for port in unique_risky_ports)
        findings.append(
            f"Potentially risky services are listening locally: {exposed_ports}."
        )
        recommendations.append(
            "Restrict listening interfaces and require VPN/jump-host access."
        )
        risk_score += min(10, len(risky_listening_ports) * 2)

    if not listening_ports:
        recommendations.append("No listening TCP/UDP services found in sampled output.")

    return PersonalSecurityResult(
        status="success",
        platform=system_name,
        hostname=hostname,
        firewall_status=firewall_status,
        listening_ports=listening_ports,
        risky_listening_ports=risky_listening_ports or None,
        findings=findings or None,
        recommendations=recommendations or None,
        risk_level=_risk_level(risk_score),
        risk_score=risk_score,
    )
