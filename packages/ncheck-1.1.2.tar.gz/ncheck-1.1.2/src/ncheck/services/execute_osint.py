"""Service layer for passive OSINT workflows."""

from __future__ import annotations

import hashlib
import json
import re
import socket
import urllib.error
import urllib.parse
import urllib.request
from typing import Any

from ncheck.logic import normalize_host
from ncheck.models import OsintDomainResult, OsintEmailResult

_WHOIS_SERVERS = {
    "com": "whois.verisign-grs.com",
    "net": "whois.verisign-grs.com",
    "org": "whois.pir.org",
    "io": "whois.nic.io",
    "dev": "whois.nic.google",
    "app": "whois.nic.google",
    "br": "whois.registro.br",
}

_EMAIL_PATTERN = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def _risk_level(score: int) -> str:
    if score == 0:
        return "low"
    if score <= 3:
        return "medium"
    return "high"


def _extract_whois_value(raw_text: str, keys: tuple[str, ...]) -> str | None:
    pattern = re.compile(
        rf"^(?:{'|'.join(re.escape(key) for key in keys)}):\s*(.+)$",
        flags=re.IGNORECASE | re.MULTILINE,
    )
    match = pattern.search(raw_text)
    if not match:
        return None
    return match.group(1).strip() or None


def _extract_name_servers(raw_text: str) -> list[str]:
    values: set[str] = set()
    for line in raw_text.splitlines():
        stripped = line.strip()
        lowered = stripped.lower()
        if lowered.startswith("name server:"):
            values.add(stripped.split(":", maxsplit=1)[1].strip().lower().rstrip("."))
        elif lowered.startswith("nserver:"):
            values.add(
                stripped.split(":", maxsplit=1)[1]
                .strip()
                .lower()
                .split()[0]
                .rstrip(".")
            )
    return sorted(value for value in values if value)


def _query_whois(server: str, query: str, timeout_seconds: float) -> str:
    with socket.create_connection((server, 43), timeout=timeout_seconds) as conn:
        conn.sendall(f"{query}\r\n".encode())
        chunks: list[bytes] = []
        while True:
            data = conn.recv(4096)
            if not data:
                break
            chunks.append(data)
    return b"".join(chunks).decode("utf-8", errors="replace")


def _resolve_whois_server(target: str, timeout_seconds: float) -> str:
    tld = (
        target.rsplit(".", maxsplit=1)[-1].lower() if "." in target else target.lower()
    )
    if tld in _WHOIS_SERVERS:
        return _WHOIS_SERVERS[tld]

    root_response = _query_whois(
        "whois.iana.org", target, timeout_seconds=timeout_seconds
    )
    for line in root_response.splitlines():
        stripped = line.strip()
        if stripped.lower().startswith("refer:"):
            return stripped.split(":", maxsplit=1)[1].strip()

    return "whois.iana.org"


def _doh_query(name: str, record_type: str, timeout_seconds: float) -> list[str]:
    params = urllib.parse.urlencode({"name": name, "type": record_type})
    url = f"https://cloudflare-dns.com/dns-query?{params}"
    request = urllib.request.Request(
        url=url,
        headers={"accept": "application/dns-json", "user-agent": "ncheck-osint"},
    )

    with urllib.request.urlopen(request, timeout=timeout_seconds) as response:
        payload = json.loads(response.read().decode("utf-8"))
    answers = payload.get("Answer") or []
    results = [str(answer.get("data", "")).strip() for answer in answers]
    return sorted({item for item in results if item})


def _url_exists(url: str, timeout_seconds: float) -> bool:
    request = urllib.request.Request(url=url, method="GET")
    try:
        with urllib.request.urlopen(request, timeout=timeout_seconds) as response:
            return int(response.status) < 500
    except urllib.error.HTTPError as exc:
        return int(exc.code) < 500
    except Exception:
        return False


def _discover_subdomains(
    target: str, timeout_seconds: float, max_subdomains: int
) -> list[str]:
    query = urllib.parse.quote(f"%.{target}")
    url = f"https://crt.sh/?q={query}&output=json"
    request = urllib.request.Request(url=url, headers={"user-agent": "ncheck-osint"})

    with urllib.request.urlopen(request, timeout=timeout_seconds) as response:
        payload = json.loads(response.read().decode("utf-8"))

    subdomains: set[str] = set()
    if not isinstance(payload, list):
        return []

    for entry in payload:
        if not isinstance(entry, dict):
            continue
        names = str(entry.get("name_value", "")).splitlines()
        for name in names:
            normalized = name.strip().lower()
            if not normalized:
                continue
            if normalized.startswith("*."):
                normalized = normalized[2:]
            if normalized.endswith(target) and normalized != target:
                subdomains.add(normalized)

    return sorted(subdomains)[: max(1, max_subdomains)]


def run_osint_domain(
    target: str,
    timeout_seconds: float = 5.0,
    include_subdomains: bool = True,
    max_subdomains: int = 250,
) -> OsintDomainResult:
    normalized_target = normalize_host(target)
    findings: list[str] = []
    recommendations: list[str] = []
    risk_score = 0

    registrar: str | None = None
    creation_date: str | None = None
    expiry_date: str | None = None
    name_servers: list[str] | None = None
    whois_server: str | None = None

    try:
        whois_server = _resolve_whois_server(
            normalized_target, timeout_seconds=timeout_seconds
        )
        whois_text = _query_whois(
            whois_server,
            normalized_target,
            timeout_seconds=timeout_seconds,
        )
        registrar = _extract_whois_value(whois_text, ("Registrar", "registrar"))
        creation_date = _extract_whois_value(
            whois_text,
            ("Creation Date", "Created On", "created"),
        )
        expiry_date = _extract_whois_value(
            whois_text,
            ("Registry Expiry Date", "Expiry Date", "Expires On", "expires"),
        )
        name_servers = _extract_name_servers(whois_text) or None
    except Exception as exc:
        findings.append(f"WHOIS lookup failed: {exc}")
        recommendations.append(
            "Validate registrar and lifecycle data directly in your registrar portal."
        )
        risk_score += 1

    dns_records: dict[str, list[str]] = {}
    for record_type in ["A", "AAAA", "MX", "NS", "TXT"]:
        try:
            dns_records[record_type] = _doh_query(
                normalized_target,
                record_type,
                timeout_seconds=timeout_seconds,
            )
        except Exception:
            dns_records[record_type] = []

    try:
        dns_records["DMARC"] = _doh_query(
            f"_dmarc.{normalized_target}",
            "TXT",
            timeout_seconds=timeout_seconds,
        )
    except Exception:
        dns_records["DMARC"] = []

    txt_records = " ".join(dns_records.get("TXT", [])).lower()
    if "v=spf1" not in txt_records:
        findings.append("No SPF policy detected in TXT records.")
        recommendations.append(
            "Publish an SPF record to restrict spoofed sender infrastructure."
        )
        risk_score += 1
    if not dns_records.get("DMARC"):
        findings.append("No DMARC policy detected.")
        recommendations.append(
            "Publish a DMARC record and move to `p=quarantine/reject` over time."
        )
        risk_score += 1

    security_txt_url = f"https://{normalized_target}/.well-known/security.txt"
    security_txt_present = _url_exists(
        security_txt_url, timeout_seconds=timeout_seconds
    )
    if not security_txt_present:
        http_security_txt_url = f"http://{normalized_target}/.well-known/security.txt"
        if _url_exists(http_security_txt_url, timeout_seconds=timeout_seconds):
            security_txt_present = True
            security_txt_url = http_security_txt_url
    if not security_txt_present:
        findings.append("No security.txt disclosure policy was found.")
        recommendations.append(
            "Publish `.well-known/security.txt` with security contact and disclosure policy."
        )
        risk_score += 1

    robots_txt_present = _url_exists(
        f"https://{normalized_target}/robots.txt",
        timeout_seconds=timeout_seconds,
    )
    sitemap_xml_present = _url_exists(
        f"https://{normalized_target}/sitemap.xml",
        timeout_seconds=timeout_seconds,
    )

    subdomains: list[str] | None = None
    if include_subdomains:
        try:
            subdomains = _discover_subdomains(
                normalized_target,
                timeout_seconds=timeout_seconds,
                max_subdomains=max_subdomains,
            )
            if len(subdomains) > 80:
                findings.append(
                    "Large externally discoverable subdomain footprint "
                    f"({len(subdomains)} entries)."
                )
                recommendations.append(
                    "Apply regular subdomain lifecycle cleanup and takeover monitoring."
                )
                risk_score += 1
        except Exception as exc:
            findings.append(f"Certificate Transparency lookup failed: {exc}")
            recommendations.append(
                "Cross-check subdomain inventory with your DNS/IaC source of truth."
            )

    return OsintDomainResult(
        target=normalized_target,
        status="success",
        whois_server=whois_server,
        registrar=registrar,
        creation_date=creation_date,
        expiry_date=expiry_date,
        name_servers=name_servers,
        dns_records=dns_records,
        subdomains=subdomains,
        total_subdomains=len(subdomains or []),
        security_txt_url=security_txt_url if security_txt_present else None,
        security_txt_present=security_txt_present,
        robots_txt_present=robots_txt_present,
        sitemap_xml_present=sitemap_xml_present,
        findings=findings or None,
        recommendations=recommendations or None,
        risk_level=_risk_level(risk_score),
        risk_score=risk_score,
    )


def _query_hibp(
    email: str, api_key: str, timeout_seconds: float
) -> list[dict[str, Any]]:
    encoded_email = urllib.parse.quote(email)
    url = f"https://haveibeenpwned.com/api/v3/breachedaccount/{encoded_email}"
    request = urllib.request.Request(
        url=url,
        headers={
            "hibp-api-key": api_key,
            "user-agent": "ncheck-osint",
            "accept": "application/json",
        },
    )

    try:
        with urllib.request.urlopen(request, timeout=timeout_seconds) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            return []
        raise ValueError(f"HIBP query failed with status {exc.code}.") from exc
    except Exception as exc:
        raise ValueError(f"HIBP query failed: {exc}") from exc

    if not isinstance(payload, list):
        return []

    breaches: list[dict[str, Any]] = []
    for item in payload:
        if not isinstance(item, dict):
            continue
        breaches.append(
            {
                "name": item.get("Name"),
                "title": item.get("Title"),
                "domain": item.get("Domain"),
                "breach_date": item.get("BreachDate"),
                "pwn_count": item.get("PwnCount"),
            }
        )
    return breaches


def run_osint_email(
    email: str,
    timeout_seconds: float = 5.0,
    hibp_api_key: str | None = None,
) -> OsintEmailResult:
    normalized_email = email.strip().lower()
    if not _EMAIL_PATTERN.match(normalized_email):
        return OsintEmailResult(
            email=normalized_email,
            status="error",
            domain="",
            error_message="Invalid email format.",
        )

    domain = normalized_email.rsplit("@", maxsplit=1)[1]
    findings: list[str] = []
    recommendations: list[str] = []
    risk_score = 0

    try:
        mx_records = _doh_query(domain, "MX", timeout_seconds=timeout_seconds)
    except Exception:
        mx_records = []

    if not mx_records:
        findings.append("No MX records were discovered for the email domain.")
        recommendations.append("Validate email routing posture and domain health.")
        risk_score += 1

    gravatar_hash = hashlib.md5(
        normalized_email.encode("utf-8")
    ).hexdigest()  # noqa: S324
    gravatar_url = f"https://www.gravatar.com/avatar/{gravatar_hash}?d=404"

    breaches: list[dict[str, Any]] | None = None
    if hibp_api_key and hibp_api_key.strip():
        try:
            breaches = _query_hibp(
                normalized_email,
                api_key=hibp_api_key.strip(),
                timeout_seconds=timeout_seconds,
            )
        except ValueError as exc:
            findings.append(str(exc))
            recommendations.append("Validate HIBP API key and rate limits.")
    else:
        findings.append("HIBP API key not provided; breach lookup was skipped.")
        recommendations.append(
            "Provide `--hibp-api-key` for high-confidence breach intelligence."
        )

    breach_count = len(breaches or [])
    if breach_count > 0:
        findings.append(f"Email appears in {breach_count} breach dataset(s).")
        recommendations.append(
            "Rotate passwords, enable MFA and monitor account recovery channels."
        )
        risk_score += min(10, breach_count * 2)

    return OsintEmailResult(
        email=normalized_email,
        status="success",
        domain=domain,
        mx_records=mx_records or None,
        gravatar_url=gravatar_url,
        breaches=breaches,
        breach_count=breach_count,
        findings=findings or None,
        recommendations=recommendations or None,
        risk_level=_risk_level(risk_score),
        risk_score=risk_score,
    )
