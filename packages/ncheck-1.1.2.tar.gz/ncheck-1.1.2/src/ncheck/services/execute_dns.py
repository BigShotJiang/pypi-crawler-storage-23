"""Service layer for DNS lookups."""

from __future__ import annotations

import socket

from ncheck.logic import normalize_host
from ncheck.models import DnsResult

_FAMILY_BY_NAME = {
    "any": socket.AF_UNSPEC,
    "ipv4": socket.AF_INET,
    "ipv6": socket.AF_INET6,
}


def run_dns_lookup(host: str, family: str = "any") -> DnsResult:
    normalized_host = normalize_host(host)
    normalized_family = family.lower()

    if normalized_family not in _FAMILY_BY_NAME:
        return DnsResult(
            host=normalized_host,
            status="error",
            query_type=normalized_family,
            error_message="Invalid family. Use one of: any, ipv4, ipv6.",
        )

    try:
        entries = socket.getaddrinfo(
            normalized_host,
            None,
            _FAMILY_BY_NAME[normalized_family],
            socket.SOCK_STREAM,
        )
    except socket.gaierror as exc:
        return DnsResult(
            host=normalized_host,
            status="error",
            query_type=normalized_family,
            error_message=str(exc),
        )
    except Exception as exc:
        return DnsResult(
            host=normalized_host,
            status="error",
            query_type=normalized_family,
            error_message=str(exc),
        )

    addresses = sorted({entry[4][0] for entry in entries if entry[4]})
    if not addresses:
        return DnsResult(
            host=normalized_host,
            status="error",
            query_type=normalized_family,
            error_message="No addresses found.",
        )

    return DnsResult(
        host=normalized_host,
        status="success",
        query_type=normalized_family,
        addresses=addresses,
    )
