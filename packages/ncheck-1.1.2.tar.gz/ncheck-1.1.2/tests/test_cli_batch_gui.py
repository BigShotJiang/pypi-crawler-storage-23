from typer.testing import CliRunner

import ncheck.cli as cli_module
from ncheck.logic.executor import CheckExecution

runner = CliRunner()


def _build_execution(check: str, ok: bool) -> CheckExecution:
    status = "success" if ok else "error"
    return CheckExecution(
        check=check,
        ok=ok,
        payload={"status": status},
        started_at="2026-02-28T10:00:00Z",
        finished_at="2026-02-28T10:00:01Z",
        duration_ms=1000.0,
        input={},
    )


def test_batch_command_success(monkeypatch, tmp_path) -> None:
    plan_file = tmp_path / "plan.json"
    plan_file.write_text("{}", encoding="utf-8")

    monkeypatch.setattr(
        cli_module,
        "load_batch_plan",
        lambda path: [
            {"check": "ping", "options": {"host": "example.com"}},
            {"check": "dns", "options": {"host": "example.com"}},
        ],
    )
    monkeypatch.setattr(
        cli_module,
        "execute_check_safe",
        lambda check, options: _build_execution(check=check, ok=True),
    )

    result = runner.invoke(cli_module.app, ["batch", str(plan_file), "--json"])

    assert result.exit_code == 0
    assert '"total_checks": 2' in result.stdout
    assert '"status": "success"' in result.stdout


def test_batch_command_stop_on_error(monkeypatch, tmp_path) -> None:
    plan_file = tmp_path / "plan.json"
    plan_file.write_text("{}", encoding="utf-8")

    monkeypatch.setattr(
        cli_module,
        "load_batch_plan",
        lambda path: [
            {"check": "ping", "options": {"host": "example.com"}},
            {"check": "dns", "options": {"host": "example.com"}},
        ],
    )

    called_checks: list[str] = []

    def _fake_execute(check: str, options):  # noqa: ANN001
        called_checks.append(check)
        return _build_execution(check=check, ok=False)

    monkeypatch.setattr(cli_module, "execute_check_safe", _fake_execute)

    result = runner.invoke(
        cli_module.app,
        ["batch", str(plan_file), "--stop-on-error", "--json"],
    )

    assert result.exit_code == 1
    assert called_checks == ["ping"]
    assert '"failed_checks": 1' in result.stdout


def test_gui_command_success(monkeypatch) -> None:
    captured: dict[str, object] = {}

    def _fake_launch(host: str, port: int, headless: bool) -> int:
        captured["host"] = host
        captured["port"] = port
        captured["headless"] = headless
        return 0

    monkeypatch.setattr(cli_module, "launch_streamlit_dashboard", _fake_launch)

    result = runner.invoke(
        cli_module.app,
        ["gui", "--host", "0.0.0.0", "--port", "9010", "--headless"],
    )

    assert result.exit_code == 0
    assert captured == {"host": "0.0.0.0", "port": 9010, "headless": True}


def test_gui_command_missing_dependency(monkeypatch) -> None:
    def _raise_runtime_error(host: str, port: int, headless: bool) -> int:
        raise RuntimeError("Dependency 'streamlit' is missing.")

    monkeypatch.setattr(cli_module, "launch_streamlit_dashboard", _raise_runtime_error)

    result = runner.invoke(cli_module.app, ["gui"])

    assert result.exit_code == 2
    assert "streamlit" in result.output
