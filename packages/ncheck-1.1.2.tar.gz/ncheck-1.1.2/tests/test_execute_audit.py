import ncheck.services.execute_audit as audit_service
from ncheck.models import PortScanResult


def test_run_security_audit_success_with_findings(monkeypatch) -> None:
    def _fake_run_port_scan(
        host: str,
        ports: list[int],
        timeout: float,
        workers: int,
    ) -> PortScanResult:
        return PortScanResult(
            host=host,
            status="success",
            tested_ports=ports,
            open_ports=[21, 443],
            closed_ports=[22],
            timeout_seconds=timeout,
        )

    monkeypatch.setattr(audit_service, "run_port_scan", _fake_run_port_scan)
    monkeypatch.setattr(
        audit_service,
        "_check_missing_headers",
        lambda url, timeout_seconds: (["content-security-policy"], None),
    )

    result = audit_service.run_security_audit(
        host="example.com",
        ports=[21, 22, 443],
        timeout_seconds=1.0,
        workers=50,
    )

    assert result.status == "success"
    assert result.risk_score == 3
    assert result.risk_level == "medium"
    assert result.risky_open_ports == [21]
    assert result.missing_security_headers == ["content-security-policy"]


def test_run_security_audit_port_scan_error(monkeypatch) -> None:
    def _fake_run_port_scan(
        host: str,
        ports: list[int],
        timeout: float,
        workers: int,
    ) -> PortScanResult:
        return PortScanResult(
            host=host,
            status="error",
            tested_ports=ports,
            error_message="dns failure",
        )

    monkeypatch.setattr(audit_service, "run_port_scan", _fake_run_port_scan)

    result = audit_service.run_security_audit("example.com", ports=[80, 443])

    assert result.status == "error"
    assert result.error_message == "dns failure"
