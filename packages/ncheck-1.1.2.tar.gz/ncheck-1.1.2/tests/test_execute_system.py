import ncheck.services.execute_system as system_service


class _FakeProcess:
    def __init__(self, pid: int, name: str, cpu: float, memory: float) -> None:
        self.info = {
            "pid": pid,
            "name": name,
            "cpu_percent": cpu,
            "memory_percent": memory,
        }


class _FakeMemory:
    total = 8 * 1024 * 1024 * 1024
    used = 4 * 1024 * 1024 * 1024
    percent = 50.0


class _FakeSwap:
    percent = 12.5


class _FakePsutil:
    @staticmethod
    def cpu_percent(interval: float) -> float:
        assert interval == 0.2
        return 34.6

    @staticmethod
    def cpu_count(logical: bool):
        return 8 if logical else 4

    @staticmethod
    def virtual_memory() -> _FakeMemory:
        return _FakeMemory()

    @staticmethod
    def swap_memory() -> _FakeSwap:
        return _FakeSwap()

    @staticmethod
    def process_iter(attrs):
        return [
            _FakeProcess(100, "python", 20.0, 2.5),
            _FakeProcess(200, "browser", 30.0, 8.0),
        ]


def test_run_system_usage_success(monkeypatch) -> None:
    monkeypatch.setattr(
        system_service.importlib,
        "import_module",
        lambda name: _FakePsutil,
    )

    result = system_service.run_system_usage(interval_seconds=0.2, top=2)

    assert result.ok is True
    assert result.cpu_percent == 34.6
    assert result.cpu_count_logical == 8
    assert result.memory_percent == 50.0
    assert result.top_processes
    assert result.top_processes[0]["name"] == "browser"


def test_run_system_usage_missing_dependency(monkeypatch) -> None:
    def _raise_module_not_found(name: str):
        raise ModuleNotFoundError("No module named 'psutil'")

    monkeypatch.setattr(
        system_service.importlib, "import_module", _raise_module_not_found
    )

    result = system_service.run_system_usage()

    assert result.ok is False
    assert "psutil" in (result.error_message or "")
