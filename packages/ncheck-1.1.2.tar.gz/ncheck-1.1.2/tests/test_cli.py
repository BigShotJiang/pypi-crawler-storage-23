from typer.testing import CliRunner

import ncheck.cli as cli_module
from ncheck.models import (DnsResult, HttpResult, PingResult, PortScanResult,
                           SecurityAuditResult, SystemUsageResult, TlsResult,
                           TracerouteResult)

runner = CliRunner()


def test_ping_json_output_success(monkeypatch) -> None:
    def _fake_run_ping(host: str, count: int, timeout: float) -> PingResult:
        assert host == "example.com"
        assert count == 4
        assert timeout == 2.0
        return PingResult(
            host=host,
            status="success",
            avg_latency_ms=10.0,
            min_latency_ms=8.5,
            max_latency_ms=12.1,
            packet_loss_percent=0.0,
        )

    monkeypatch.setattr(cli_module, "run_ping", _fake_run_ping)

    result = runner.invoke(cli_module.app, ["ping", "example.com", "--json"])

    assert result.exit_code == 0
    assert '"status": "success"' in result.stdout
    assert '"host": "example.com"' in result.stdout


def test_ping_returns_exit_code_1_on_failure(monkeypatch) -> None:
    def _fake_run_ping(host: str, count: int, timeout: float) -> PingResult:
        return PingResult(
            host=host,
            status="error",
            error_message="timeout reached",
        )

    monkeypatch.setattr(cli_module, "run_ping", _fake_run_ping)

    result = runner.invoke(cli_module.app, ["ping", "example.com"])

    assert result.exit_code == 1
    assert "timeout reached" in result.stdout


def test_ping_prompts_for_host_when_missing(monkeypatch) -> None:
    called: dict[str, str] = {}

    def _fake_run_ping(host: str, count: int, timeout: float) -> PingResult:
        called["host"] = host
        return PingResult(host=host, status="success")

    monkeypatch.setattr(cli_module, "run_ping", _fake_run_ping)

    result = runner.invoke(cli_module.app, ["ping", "--json"], input="localhost\n")

    assert result.exit_code == 0
    assert called["host"] == "localhost"


def test_version_flag() -> None:
    result = runner.invoke(cli_module.app, ["--version"])
    assert result.exit_code == 0
    assert "ncheck " in result.stdout


def test_dns_json_output_success(monkeypatch) -> None:
    def _fake_run_dns_lookup(host: str, family: str) -> DnsResult:
        assert host == "example.com"
        assert family == "ipv4"
        return DnsResult(
            host=host,
            status="success",
            query_type=family,
            addresses=["93.184.216.34"],
        )

    monkeypatch.setattr(cli_module, "run_dns_lookup", _fake_run_dns_lookup)

    result = runner.invoke(
        cli_module.app, ["dns", "example.com", "--family", "ipv4", "--json"]
    )

    assert result.exit_code == 0
    assert '"query_type": "ipv4"' in result.stdout


def test_http_command_returns_exit_code_1_on_error(monkeypatch) -> None:
    def _fake_run_http_check(
        url: str,
        method: str,
        timeout: float,
        follow_redirects: bool,
    ) -> HttpResult:
        assert url == "https://example.com"
        assert method == "GET"
        assert timeout == 5.0
        assert follow_redirects is True
        return HttpResult(
            url=url,
            status="error",
            method=method,
            error_message="request timeout",
        )

    monkeypatch.setattr(cli_module, "run_http_check", _fake_run_http_check)

    result = runner.invoke(cli_module.app, ["http", "https://example.com"])

    assert result.exit_code == 1
    assert "request timeout" in result.stdout


def test_ports_json_output_success(monkeypatch) -> None:
    def _fake_run_port_scan(
        host: str,
        ports: list[int],
        timeout: float,
        workers: int,
    ) -> PortScanResult:
        assert host == "localhost"
        assert ports == [22, 80, 443]
        assert timeout == 0.6
        assert workers == 100
        return PortScanResult(
            host=host,
            status="success",
            tested_ports=ports,
            open_ports=[22],
            closed_ports=[80, 443],
            timeout_seconds=timeout,
        )

    monkeypatch.setattr(cli_module, "run_port_scan", _fake_run_port_scan)

    result = runner.invoke(
        cli_module.app,
        ["ports", "localhost", "--ports", "22,80,443", "--json"],
    )

    assert result.exit_code == 0
    assert '"open_ports": [' in result.stdout


def test_ports_command_rejects_invalid_ports_spec() -> None:
    result = runner.invoke(cli_module.app, ["ports", "localhost", "--ports", "abc"])
    assert result.exit_code == 2


def test_traceroute_json_output_success(monkeypatch) -> None:
    def _fake_run_traceroute(
        host: str, max_hops: int, timeout_seconds: float
    ) -> TracerouteResult:
        assert host == "example.com"
        assert max_hops == 10
        assert timeout_seconds == 1.0
        return TracerouteResult(
            host=host,
            status="success",
            max_hops=max_hops,
            timeout_seconds=timeout_seconds,
            hop_count=2,
            hops=["192.168.1.1", "93.184.216.34"],
        )

    monkeypatch.setattr(cli_module, "run_traceroute", _fake_run_traceroute)

    result = runner.invoke(
        cli_module.app,
        ["traceroute", "example.com", "--max-hops", "10", "--timeout", "1", "--json"],
    )

    assert result.exit_code == 0
    assert '"hop_count": 2' in result.stdout


def test_tls_fail_on_warnings(monkeypatch) -> None:
    def _fake_run_tls_inspection(
        host: str, port: int, timeout_seconds: float
    ) -> TlsResult:
        return TlsResult(
            host=host,
            status="success",
            port=port,
            protocol="TLSv1.2",
            warnings=["Certificate will expire in less than 30 days."],
        )

    monkeypatch.setattr(cli_module, "run_tls_inspection", _fake_run_tls_inspection)

    result = runner.invoke(
        cli_module.app,
        ["tls", "example.com", "--fail-on-warnings", "--json"],
    )
    assert result.exit_code == 1


def test_system_json_output_success(monkeypatch) -> None:
    def _fake_run_system_usage(interval_seconds: float, top: int) -> SystemUsageResult:
        assert interval_seconds == 0.2
        assert top == 8
        return SystemUsageResult(
            status="success",
            cpu_percent=30.5,
            cpu_count_logical=8,
            memory_percent=40.2,
            top_processes=[
                {
                    "pid": 1,
                    "name": "python",
                    "cpu_percent": 10.0,
                    "memory_percent": 2.0,
                }
            ],
        )

    monkeypatch.setattr(cli_module, "run_system_usage", _fake_run_system_usage)

    result = runner.invoke(cli_module.app, ["system", "--json"])
    assert result.exit_code == 0
    assert '"cpu_percent": 30.5' in result.stdout


def test_audit_requires_authorization_flag() -> None:
    result = runner.invoke(cli_module.app, ["audit", "example.com", "--json"])
    assert result.exit_code == 2


def test_audit_json_output_success(monkeypatch) -> None:
    def _fake_run_security_audit(
        host: str,
        ports: list[int],
        timeout_seconds: float,
        workers: int,
        url: str | None,
    ) -> SecurityAuditResult:
        assert host == "example.com"
        assert ports == [80, 443]
        assert timeout_seconds == 1.0
        assert workers == 120
        assert url is None
        return SecurityAuditResult(
            host=host,
            status="success",
            scan_ports=ports,
            open_ports=[443],
            risk_level="low",
            risk_score=0,
        )

    monkeypatch.setattr(cli_module, "run_security_audit", _fake_run_security_audit)

    result = runner.invoke(
        cli_module.app,
        ["audit", "example.com", "--ports", "80,443", "--authorized", "--json"],
    )
    assert result.exit_code == 0
    assert '"risk_level": "low"' in result.stdout
