import ncheck.services.execute_tls as tls_service


class _FakeTlsSocket:
    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        return None

    def getpeercert(self):
        return {
            "subject": ((("commonName", "example.com"),),),
            "issuer": ((("commonName", "Example CA"),),),
            "notBefore": "Jan 01 00:00:00 2025 GMT",
            "notAfter": "Jan 01 00:00:00 2030 GMT",
        }

    def version(self) -> str:
        return "TLSv1.3"

    def cipher(self):
        return ("TLS_AES_256_GCM_SHA384", "TLSv1.3", 256)


class _FakeRawSocket:
    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        return None


class _FakeSslContext:
    check_hostname = False
    verify_mode = 0

    def wrap_socket(self, raw_socket, server_hostname: str):
        assert server_hostname == "example.com"
        return _FakeTlsSocket()


def test_run_tls_inspection_success(monkeypatch) -> None:
    monkeypatch.setattr(
        tls_service.socket,
        "create_connection",
        lambda address, timeout: _FakeRawSocket(),
    )
    monkeypatch.setattr(
        tls_service.ssl, "SSLContext", lambda protocol: _FakeSslContext()
    )

    result = tls_service.run_tls_inspection(
        "example.com", port=443, timeout_seconds=1.0
    )

    assert result.status == "success"
    assert result.protocol == "TLSv1.3"
    assert result.subject == "example.com"
    assert result.issuer == "Example CA"


def test_run_tls_inspection_error(monkeypatch) -> None:
    def _raise_connection_error(address, timeout):
        raise OSError("connection refused")

    monkeypatch.setattr(
        tls_service.socket,
        "create_connection",
        _raise_connection_error,
    )

    result = tls_service.run_tls_inspection("example.com")

    assert result.status == "error"
    assert "connection refused" in (result.error_message or "")
