from ncheck.logic import (humanize_key, normalize_host, normalize_url,
                          parse_ports_spec)


def test_normalize_host_trims_input() -> None:
    assert normalize_host("  example.com  ") == "example.com"


def test_normalize_host_rejects_empty_values() -> None:
    try:
        normalize_host("   ")
    except ValueError as exc:
        assert str(exc) == "Host cannot be empty."
    else:
        raise AssertionError("Expected ValueError for empty host input.")


def test_humanize_key_converts_snake_case() -> None:
    assert humanize_key("packet_loss_percent") == "Packet Loss Percent"


def test_normalize_url_adds_https_scheme() -> None:
    assert normalize_url("example.com") == "https://example.com"


def test_normalize_url_rejects_invalid_scheme() -> None:
    try:
        normalize_url("ftp://example.com")
    except ValueError as exc:
        assert "http or https" in str(exc)
    else:
        raise AssertionError("Expected ValueError for unsupported scheme.")


def test_parse_ports_spec_supports_ranges_and_single_values() -> None:
    assert parse_ports_spec("80, 443, 1000-1002") == [80, 443, 1000, 1001, 1002]


def test_parse_ports_spec_rejects_invalid_ports() -> None:
    try:
        parse_ports_spec("70000")
    except ValueError as exc:
        assert "between 1 and 65535" in str(exc)
    else:
        raise AssertionError("Expected ValueError for invalid port.")
