import pytest

from ncheck.logic import load_batch_plan


def test_load_batch_plan_accepts_json_list(tmp_path) -> None:
    plan_file = tmp_path / "plan.json"
    plan_file.write_text(
        '[{"check": "ping", "host": "example.com", "count": 3}]',
        encoding="utf-8",
    )

    plan = load_batch_plan(plan_file)

    assert plan == [
        {
            "check": "ping",
            "options": {
                "host": "example.com",
                "count": 3,
            },
        }
    ]


def test_load_batch_plan_merges_options_from_entry_and_options_field(tmp_path) -> None:
    plan_file = tmp_path / "plan.json"
    plan_file.write_text(
        (
            '{"checks": [{"check": "dns", "family": "ipv4", "options": '
            '{"host": "example.com"}}]}'
        ),
        encoding="utf-8",
    )

    plan = load_batch_plan(plan_file)

    assert plan == [
        {
            "check": "dns",
            "options": {
                "host": "example.com",
                "family": "ipv4",
            },
        }
    ]


def test_load_batch_plan_rejects_empty_plan(tmp_path) -> None:
    plan_file = tmp_path / "plan.json"
    plan_file.write_text('{"checks": []}', encoding="utf-8")

    with pytest.raises(ValueError) as excinfo:
        load_batch_plan(plan_file)

    assert "at least one check entry" in str(excinfo.value)
