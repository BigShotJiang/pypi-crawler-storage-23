class FIELD():

    """Docstring for FIELD. """

    def __init__(self):
        """TODO: to be defined. """
        pass

    def get_fy4b_agri_data(self, chn, res='4km'):
        pass

        
