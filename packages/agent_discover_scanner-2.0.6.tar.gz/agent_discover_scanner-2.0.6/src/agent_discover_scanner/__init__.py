"""AgentDiscover Scanner - Detect AI Agents and Shadow AI across 4 layers."""

__version__ = "2.0.2"

__all__ = ["__version__"]
