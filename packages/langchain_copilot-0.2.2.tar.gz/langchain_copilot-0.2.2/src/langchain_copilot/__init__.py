"""LangChain integration for GitHub Copilot SDK."""

from langchain_copilot.chat_models import CopilotChatModel

__version__ = "0.2.0"
__all__ = ["CopilotChatModel"]
