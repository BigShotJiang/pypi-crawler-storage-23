# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.2.2] - 2026-02-26
### Added
- Memory example demonstrating conversation history with `RunnableWithMessageHistory` (example 09)

### Fixed
- Fixed `cli_url` TypeError by passing options as dictionary to `CopilotClient`
- Fixed indefinite hang when only system messages are provided
- Improved message validation to raise clear errors for empty prompts

### Changed
- Refactored message handling and prompt construction logic
- Improved error messages for invalid message configurations
- Enhanced test coverage for edge cases

### Removed
- Removed temperature example (06_temperature.py) as it was redundant

## [0.2.1] - 2026-01-29

### Added
- GitHub Actions workflow for automated PyPI releases
- TestPyPI manual publishing workflow for pre-release testing
- Comprehensive release documentation (RELEASE.md)

### Fixed
- Fixed author name in pyproject.toml metadata
- Fixed project URLs configuration
- Fixed dependency declarations in pyproject.toml

## [0.2.0] - 2026-01-28

### Added
- LangChain standard interface compliance via `langchain-tests`
- Comprehensive test suite with unit and integration tests
- Support for tool binding and function calling
- Additional examples showcasing temperature control, async operations, and tool usage
- CI/CD automation with GitHub Actions for testing and publishing
- Automated PyPI publishing via GitHub Releases with Trusted Publishing
- TestPyPI manual publishing workflow for pre-release testing

### Changed
- Improved error handling and SDK event suppression
- Enhanced documentation with QUICKSTART.md, TESTING.md, and RELEASE.md
- Synchronized versioning between pyproject.toml and __init__.py

### Fixed
- AsyncIO event loop handling in synchronous contexts
- Version mismatch between package metadata and source code

## [0.1.0] - 2026-01-15

### Added
- Initial release of langchain-copilot
- CopilotChatModel implementing LangChain BaseChatModel interface
- Shared client pattern with lazy initialization
- Full async/sync support for generate and stream operations
- Event-based SDK integration with GitHub Copilot CLI
- Support for system, human, and AI messages
- Basic examples demonstrating invoke, streaming, and async operations
- Development tooling: pytest, black, ruff, uv integration
- MIT License

[unreleased]: https://github.com/derf974/copilot-langchain/compare/v0.2.1...HEAD
[0.2.1]: https://github.com/derf974/copilot-langchain/compare/v0.2.0...v0.2.1
[0.2.0]: https://github.com/derf974/copilot-langchain/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/derf974/copilot-langchain/releases/tag/v0.1.0
