from __future__ import annotations

import os
import tomllib
import urllib.request
from pathlib import Path

from pydantic import ValidationError

from vet.cli.config.cli_config_schema import CliConfigPreset
from vet.cli.config.cli_config_schema import merge_presets
from vet.cli.config.cli_config_schema import parse_cli_config_from_dict
from vet.cli.config.schema import ModelsConfig
from vet.cli.config.schema import ProviderConfig
from vet.imbue_core.data_types import CustomGuideConfig
from vet.imbue_core.data_types import CustomGuidesConfig
from vet.imbue_core.data_types import get_valid_issue_code_values


class ConfigLoadError(Exception):
    pass


_DEFAULT_REGISTRY_URL = "https://raw.githubusercontent.com/imbue-ai/vet/main/registry/models.json"
_REGISTRY_FETCH_TIMEOUT_SECONDS = 5


def get_xdg_config_home() -> Path:
    xdg_config = os.environ.get("XDG_CONFIG_HOME")
    if xdg_config:
        return Path(xdg_config)
    return Path.home() / ".config"


def _get_xdg_cache_home() -> Path:
    xdg_cache = os.environ.get("XDG_CACHE_HOME")
    if xdg_cache:
        return Path(xdg_cache)
    return Path.home() / ".cache"


def _get_registry_cache_path() -> Path:
    return _get_xdg_cache_home() / "vet" / "remote_models.json"


def update_remote_registry_cache() -> tuple[Path, ModelsConfig]:
    url = os.environ.get("VET_REGISTRY_URL", _DEFAULT_REGISTRY_URL)
    req = urllib.request.Request(url, headers={"User-Agent": "vet"})
    with urllib.request.urlopen(req, timeout=_REGISTRY_FETCH_TIMEOUT_SECONDS) as resp:
        data = resp.read()
    try:
        config = ModelsConfig.model_validate_json(data)
    except ValidationError as e:
        raise ConfigLoadError(f"Remote registry at {url} returned invalid data: {e}") from e
    cache_path = _get_registry_cache_path()
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    cache_path.write_bytes(data)
    return cache_path, config


def find_git_repo_root(start_path: Path) -> Path | None:
    current = start_path.resolve()
    while current != current.parent:
        if (current / ".git").exists():
            return current
        current = current.parent
    if (current / ".git").exists():
        return current
    return None


def _get_config_file_paths(
    global_subpath: str,
    global_filename: str,
    project_filename: str,
    repo_path: Path | None = None,
) -> list[Path]:
    paths = [get_xdg_config_home() / global_subpath / global_filename]

    if repo_path:
        git_root = find_git_repo_root(repo_path)
        root = git_root if git_root else repo_path
        paths.append(root / ".vet" / project_filename)

    return paths


def get_config_file_paths(repo_path: Path | None = None) -> list[Path]:
    return _get_config_file_paths("vet", "models.json", "models.json", repo_path)


def _load_single_config_file(config_path: Path) -> ModelsConfig:
    try:
        with open(config_path) as f:
            return ModelsConfig.model_validate_json(f.read())
    except ValidationError as e:
        raise ConfigLoadError(f"Invalid configuration in {config_path}: {e}") from e
    except OSError as e:
        raise ConfigLoadError(f"Cannot read {config_path}: {e}") from e


def load_models_config(repo_path: Path | None = None) -> ModelsConfig:
    merged_providers: dict[str, ProviderConfig] = {}

    for config_path in get_config_file_paths(repo_path):
        if config_path.exists():
            config = _load_single_config_file(config_path)
            merged_providers.update(config.providers)

    return ModelsConfig(providers=merged_providers)


def load_registry_config() -> ModelsConfig:
    cache_path = _get_registry_cache_path()
    if cache_path.exists():
        return _load_single_config_file(cache_path)
    return ModelsConfig(providers={})


def get_model_ids_from_config(config: ModelsConfig) -> set[str]:
    return {mid for provider in config.providers.values() for mid in provider.models}


def get_provider_for_model(model_id: str, config: ModelsConfig) -> ProviderConfig | None:
    for provider in config.providers.values():
        if model_id in provider.models:
            return provider
    return None


def get_models_by_provider_from_config(config: ModelsConfig) -> dict[str, list[str]]:
    result: dict[str, list[str]] = {}
    for provider_id, provider in config.providers.items():
        display_name = provider.name or provider_id
        result[display_name] = list(provider.models.keys())
    return result


def get_cli_config_file_paths(repo_path: Path | None = None) -> list[Path]:
    return _get_config_file_paths("vet", "configs.toml", "configs.toml", repo_path)


def _load_cli_config_file(config_path: Path) -> dict[str, CliConfigPreset]:
    try:
        with open(config_path, "rb") as f:
            data = tomllib.load(f)
        return parse_cli_config_from_dict(data)
    except tomllib.TOMLDecodeError as e:
        raise ConfigLoadError(f"Invalid TOML in {config_path}: {e}") from e
    except ValidationError as e:
        raise ConfigLoadError(f"Invalid configuration in {config_path}: {e}") from e
    except OSError as e:
        raise ConfigLoadError(f"Cannot read {config_path}: {e}") from e


def load_cli_config(repo_path: Path | None = None) -> dict[str, CliConfigPreset]:
    merged_configs: dict[str, CliConfigPreset] = {}

    for config_path in get_cli_config_file_paths(repo_path):
        if config_path.exists():
            file_configs = _load_cli_config_file(config_path)
            for name, preset in file_configs.items():
                if name in merged_configs:
                    merged_configs[name] = merge_presets(merged_configs[name], preset)
                else:
                    merged_configs[name] = preset

    return merged_configs


def get_config_preset(
    config_name: str,
    cli_configs: dict[str, CliConfigPreset],
    repo_path: Path | None = None,
) -> CliConfigPreset:
    if config_name not in cli_configs:
        available = sorted(cli_configs.keys())
        if available:
            raise ConfigLoadError(f"Configuration '{config_name}' not found. Available configs: {', '.join(available)}")
        else:
            paths = get_cli_config_file_paths(repo_path)
            paths_list = "\n".join(f"  - {p} ({'global' if i == 0 else 'project'})" for i, p in enumerate(paths))
            raise ConfigLoadError(
                f"Configuration '{config_name}' not found.\n\n"
                f"No configuration files found. Create a config at one of these locations:\n{paths_list}"
            )
    return cli_configs[config_name]


def get_guides_config_file_paths(repo_path: Path | None = None) -> list[Path]:
    return _get_config_file_paths("vet", "guides.toml", "guides.toml", repo_path)


def _load_single_guides_file(config_path: Path) -> CustomGuidesConfig:
    try:
        with open(config_path, "rb") as f:
            data = tomllib.load(f)
    except tomllib.TOMLDecodeError as e:
        raise ConfigLoadError(f"Invalid TOML in {config_path}: {e}") from e
    except OSError as e:
        raise ConfigLoadError(f"Cannot read {config_path}: {e}") from e

    all_issue_code_values = get_valid_issue_code_values()
    guides: dict[str, CustomGuideConfig] = {}
    for key, value in data.items():
        if key not in all_issue_code_values:
            raise ConfigLoadError(
                f"Unknown issue code '{key}' in {config_path}. " f"Use --list-issue-codes to see valid codes."
            )
        if not isinstance(value, dict):
            raise ConfigLoadError(f"Expected a table for '{key}' in {config_path}, got {type(value).__name__}")
        try:
            guides[key] = CustomGuideConfig.model_validate(value)
        except ValidationError as e:
            raise ConfigLoadError(f"Invalid guide configuration for '{key}' in {config_path}: {e}") from e

    return CustomGuidesConfig(guides=guides)


def load_custom_guides_config(repo_path: Path | None = None) -> CustomGuidesConfig:
    merged_guides: dict[str, CustomGuideConfig] = {}

    for config_path in get_guides_config_file_paths(repo_path):
        if config_path.exists():
            config = _load_single_guides_file(config_path)
            merged_guides.update(config.guides)

    return CustomGuidesConfig(guides=merged_guides)
