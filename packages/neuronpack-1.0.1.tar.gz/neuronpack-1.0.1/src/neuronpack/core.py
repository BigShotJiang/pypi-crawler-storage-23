import json
import os
import time
import logging
from pathlib import Path
from typing import Dict, Any, Optional, List
import torch
import safetensors.torch
import orjson
import numpy as np

from .router import Router

log = logging.getLogger("neuronpack")

class NeuronPack:
    """
    NeuronPack: A universal, hardware-compiled, composable model container format.
    """
    
    def __init__(self, path: str):
        self.path = Path(path)
        self.pieces_dir = self.path / "pieces"
        self.manifest_path = self.path / "manifest.json"
        
        # Router
        self.router_dir = self.path / "router"
        self.router = Router(self.router_dir)
        
        # RSI Callbacks
        self._on_piece_loaded_cbs = []
        self._on_manifest_changed_cbs = []
        self._metric_thresholds = []
        
        # In-memory representations
        self.manifest: Dict[str, Any] = {}
        
        self._initialize_structure()

    # --- RSI Event Hooks ---
    
    def on_piece_loaded(self, callback):
        """Register a callback that fires when a piece is retrieved or loaded."""
        self._on_piece_loaded_cbs.append(callback)
        
    def on_manifest_changed(self, callback):
        """Register a callback that fires when the manifest is updated on disk."""
        self._on_manifest_changed_cbs.append(callback)
        
    def on_metric_threshold(self, metric: str, threshold: float, direction: str, callback):
        """
        Register a callback that fires when a reported metric crosses the threshold.
        direction: 'above' or 'below'
        """
        if direction not in ["above", "below"]:
            raise ValueError("Direction must be 'above' or 'below'")
        self._metric_thresholds.append({
            "metric": metric,
            "threshold": threshold,
            "direction": direction,
            "callback": callback
        })
        
    def report_metric(self, metric: str, value: float):
        """Intake evaluation metrics to trigger potential RSI hooks."""
        for th in self._metric_thresholds:
            if th["metric"] == metric:
                if (th["direction"] == "above" and value > th["threshold"]) or \
                   (th["direction"] == "below" and value < th["threshold"]):
                    th["callback"]()
                    
    def check_idle_pieces(self, min_load_count: int) -> List[str]:
        """
        Calculates pieces that might be 'idle' or dead based on load_count.
        Can be used manually by RSI to decide when to call prune().
        """
        idle_ids = []
        for file in self.pieces_dir.glob("*.meta"):
            with open(file, "rb") as f:
                meta = orjson.loads(f.read())
            if meta.get("load_count", 0) < min_load_count:
                idle_ids.append(meta["id"])
        return idle_ids

    # --- Core Mechanics ---

    def _initialize_structure(self):
        """Creates the necessary folder structure if it doesn't exist."""
        self.path.mkdir(parents=True, exist_ok=True)
        self.pieces_dir.mkdir(parents=True, exist_ok=True)
        self.router_dir.mkdir(parents=True, exist_ok=True)
        
        if self.manifest_path.exists():
            with open(self.manifest_path, "r") as f:
                self.manifest = json.load(f)
        else:
            self.manifest = {
                "model_name": self.path.stem,
                "architecture_type": "unknown",
                "graph": []
            }

    @classmethod
    def load(cls, path: str) -> "NeuronPack":
        """Loads an existing NeuronPack from the given path."""
        p = Path(path)
        if not p.exists():
            raise FileNotFoundError(f"NeuronPack not found at {path}")
        return cls(str(path))

    def save(self):
        """Saves the current state of the manifest to disk."""
        with open(self.manifest_path, "wb") as f:
             f.write(orjson.dumps(self.manifest, option=orjson.OPT_INDENT_2))
             
        for cb in self._on_manifest_changed_cbs:
            cb(self.manifest)

    def _validate_meta(self, meta: Dict[str, Any]):
        """Validates the metadata dictionary against the strict spec."""
        required_keys = {
            "id": str,
            "role": str,
            "architecture": str,
            "input_shape": list,
            "output_shape": list,
            "dtype": str,
            "params": int,
            "embedding": (list, type(None)),
            "tags": list,
            "load_count": int,
            "version": str,
            "trainable": bool,
            "dependencies": list,
            "target_hardware": (str, type(None)),
            "compiled": bool,
            "compatibility_group": str,
            "integrity_hash": str
        }
        
        missing_keys = [k for k in required_keys if k not in meta]
        if missing_keys:
            log.error(f"Metadata validation failed. Missing keys: {missing_keys}")
            raise ValueError(f"Missing required metadata keys: {missing_keys}")
            
        type_failures = []
        for k, expected_type in required_keys.items():
            if not isinstance(meta[k], expected_type):
                type_failures.append(f"'{k}' expected {expected_type}, got {type(meta[k]).__name__}")
                
        if type_failures:
            log.error(f"Metadata type validation failed: {type_failures}")
            raise TypeError(f"Metadata strict type signature mismatch: {type_failures}")
            
    def add_piece(self, piece_id: str, weights: Dict[str, torch.Tensor], meta: Dict[str, Any]):
        """
        Adds a new piece to the NeuronPack.
        
        Args:
            piece_id: Unique identifier for the piece.
            weights: State dict of PyTorch tensors.
            meta: Metadata dictionary describing the piece contract.
        """
        # Ensure 'id' in meta matches piece_id
        if "id" not in meta:
            meta["id"] = piece_id
        elif meta["id"] != piece_id:
             raise ValueError(f"piece_id '{piece_id}' does not match meta id '{meta['id']}'")
             
        # Generate Structural Integrity Hash automatically
        import hashlib
        h = hashlib.sha256()
        for k in sorted(weights.keys()):
            h.update(k.encode("utf-8"))
            h.update(str(list(weights[k].shape)).encode("utf-8"))
        meta["integrity_hash"] = h.hexdigest()
             
        self._validate_meta(meta)
        
        # Save Metadata (Atomic Write Approach for Concurrency)
        meta_path = self.pieces_dir / f"{piece_id}.meta"
        tmp_meta_path = meta_path.with_suffix(".meta.tmp")
        with open(tmp_meta_path, "wb") as f:
            f.write(orjson.dumps(meta, option=orjson.OPT_INDENT_2))
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_meta_path, meta_path)
            
        # Save Weights (Retry Loop for OS File-Locks)
        weight_path = self.pieces_dir / f"{piece_id}.weights"
        
        retries = 3
        for attempt in range(retries):
            try:
                safetensors.torch.save_file(weights, weight_path)
                break
            except PermissionError as e:
                log.warning(f"[I/O Locked] Retrying weight save for {piece_id} (Attempt {attempt+1}/{retries})")
                if attempt == retries - 1:
                    raise e
                time.sleep(0.01)
        
    def swap_piece(self, piece_id: str, new_weights: Dict[str, torch.Tensor], new_meta: Optional[Dict] = None):
        """
        Live-swaps an existing piece with new weights and optionally updated metadata.
        Used heavily in RSI for mutation or replacement without container recreation.
        """
        if new_meta is None:
            new_meta = self.get_piece_meta(piece_id)
            # Auto-bump version string simply formatted
            ver = new_meta.get("version", "1.0.0")
            parts = ver.split(".")
            if len(parts) >= 3 and parts[-1].isdigit():
                parts[-1] = str(int(parts[-1]) + 1)
                new_meta["version"] = ".".join(parts)
                
        # Overwrite on disk (add_piece automatically handles saving `.meta` and `.weights`)
        log.debug(f"Swapping piece {piece_id} to execution payload...")
        self.add_piece(piece_id, new_weights, new_meta)
        
        # If it was an expert with an embedding, the router matrix is now stale.
        # Fire a quick update for consistency
        if new_meta.get("embedding") is not None:
             self.update_registry()
             
    def prune(self, role: str, min_load_count: int) -> int:
        """
        Removes pieces matching `role` that have fewer loads than `min_load_count`.
        Returns the number of pieces deleted.
        """
        removed = 0
        for file in self.pieces_dir.glob("*.meta"):
            with open(file, "rb") as f:
                meta = orjson.loads(f.read())
                
            if meta.get("role") == role and meta.get("load_count", 0) < min_load_count:
                piece_id = meta["id"]
                # Delete files safely in order: kernel, weights, then meta
                kernel_path = self.pieces_dir / f"{piece_id}.kernel.pt2"
                weights_path = self.pieces_dir / f"{piece_id}.weights"
                
                success = True
                failed_files = []
                
                for p in [kernel_path, weights_path, file]:
                    try:
                        p.unlink(missing_ok=True)
                    except PermissionError:
                        success = False
                        failed_files.append(p.name)
                
                if success:
                    removed += 1
                    log.info(f"Pruned dead architectural branch: {piece_id}")
                else:
                    log.warning(f"Could not fully prune locked execution piece {piece_id}. Failed files: {failed_files}")
                
        if removed > 0:
            self.update_registry()
            
        return removed
            
    def _increment_load_count(self, piece_id: str):
        """Internal helper to track usage telemetry for pieces."""
        meta_path = self.pieces_dir / f"{piece_id}.meta"
        try:
            with open(meta_path, "rb") as f:
                meta = orjson.loads(f.read())
            meta["load_count"] = meta.get("load_count", 0) + 1
            with open(meta_path, "wb") as f:
                f.write(orjson.dumps(meta, option=orjson.OPT_INDENT_2))
        except Exception:
            pass # Failsafe telemetry
            
    def get_piece_meta(self, piece_id: str) -> Dict[str, Any]:
        """Retrieves the metadata for a given piece."""
        meta_path = self.pieces_dir / f"{piece_id}.meta"
        if not meta_path.exists():
            log.error(f"Metadata piece '{piece_id}' not found.")
            raise FileNotFoundError(f"Metadata for piece '{piece_id}' not found.")
            
        with open(meta_path, "rb") as f:
            return orjson.loads(f.read())
            
    def get_piece_weights(self, piece_id: str) -> Dict[str, torch.Tensor]:
         """Retrieves the weights for a given piece using a concurrency safe retry loop."""
         weight_path = self.pieces_dir / f"{piece_id}.weights"
         if not weight_path.exists():
              log.error(f"Weights for '{piece_id}' not found.")
              raise FileNotFoundError(f"Weights for piece '{piece_id}' not found.")
              
         self._increment_load_count(piece_id)
         for cb in self._on_piece_loaded_cbs:
             cb(piece_id)
              
         # OS File Lock Retry mechanism for extreme concurrency bounds
         retries = 3
         for attempt in range(retries):
             try:
                 with safetensors.safe_open(weight_path, framework="pt", device="cpu") as f:
                     # Force clone to sever the memory-map OS file handle, allowing immediate prune/deletion
                     return {k: f.get_tensor(k).clone() for k in f.keys()}
             except PermissionError as e:
                 if attempt == retries - 1:
                     log.error(f"Concurrency lock failure unresolvable on: {piece_id}")
                     raise e
                 log.warning(f"OS Lock on {piece_id} spotted, executing load retry {attempt+1}")
                 time.sleep(0.01)
         
    def get_piece(self, piece_id: str) -> Dict[str, Any]:
        """Convenience method to retrieve both meta and weights."""
        return {
            "meta": self.get_piece_meta(piece_id),
            "weights": self.get_piece_weights(piece_id)
        }

    def update_registry(self):
        """
        Scans all pieces and compiles an embedded knowledge base for routing.
        Extracts `embedding` from metadata to create index arrays.
        """
        embeddings_list = []
        registry_map = {}
        idx = 0
        
        for file in self.pieces_dir.glob("*.meta"):
            try:
                with open(file, "rb") as f:
                    meta = orjson.loads(f.read())
                    
                emb = meta.get("embedding")
                if emb is not None:
                    embeddings_list.append(emb)
                    registry_map[str(idx)] = meta["id"]
                    idx += 1
            except Exception as e:
                print(f"Warning: Failed to parse metadata for {file}: {e}")
                
        if embeddings_list:
            emb_array = np.array(embeddings_list, dtype=np.float32)
            self.router.save(emb_array, registry_map)
        else:
            print("Notice: No valid embeddings found in any .meta files. Registry not updated.")

    def merge_experts(self, expert_ids: List[str], routing_scores: List[float]) -> Dict[str, torch.Tensor]:
        """
        Loads and eagerly merges the weights of multiple experts using a weighted sum.
        Assumes all experts share the exact same parameter structure.
        """
        if len(expert_ids) != len(routing_scores):
            raise ValueError("expert_ids and routing_scores must have the same length.")
            
        if not expert_ids:
            return {}
            
        merged_weights: Dict[str, torch.Tensor] | None = None
        seen_keys = set()
        
        for piece_id, score in zip(expert_ids, routing_scores):
            weights = self.get_piece_weights(piece_id)
            
            # Initial validation and setup
            if merged_weights is None:
                merged_weights = {k: torch.zeros_like(v) for k, v in weights.items()}
                seen_keys = set(weights.keys())
                
            # Structural validation
            current_keys = set(weights.keys())
            if current_keys != seen_keys:
                raise ValueError(f"Expert {piece_id} parameter keys {current_keys} do not match archetype keys {seen_keys}")
                
            # Weighted merge operation
            for k in seen_keys:
                # Multiply block without modifying original weights instance reference natively loaded
                merged_weights[k].add_(weights[k] * score)
                
        return merged_weights

    def compile_piece(self, piece_id: str, module: torch.nn.Module, example_inputs: tuple):
        """
        Ahead-Of-Time (AOT) compiles a given piece using PyTorch AOTInductor.
        Saves a highly optimized binary to `.kernel` and updates metadata.
        
        Args:
            piece_id: The ID of the generic piece to compile.
            module: The instantiated nn.Module structured for this piece.
            example_inputs: A tuple of dummy tensors (matching input shapes) to trace the graph.
        """
        # Ensure we have the latest state dict
        weights = self.get_piece_weights(piece_id)
        module.load_state_dict(weights)
        module.eval()
        
        # 1. Export the graph
        exported_program = torch.export.export(module, args=example_inputs)
        
        # 2. Compile and package
        kernel_path = self.pieces_dir / f"{piece_id}.kernel.pt2"
        torch._inductor.aoti_compile_and_package(
            exported_program,
            package_path=str(kernel_path)
        )
        
        # 3. Update metadata to reflect compilation status
        meta_path = self.pieces_dir / f"{piece_id}.meta"
        with open(meta_path, "rb") as f:
            meta = orjson.loads(f.read())
            
        meta["compiled"] = True
        
        with open(meta_path, "wb") as f:
            f.write(orjson.dumps(meta, option=orjson.OPT_INDENT_2))
            
    def load_piece_kernel(self, piece_id: str):
        """
        Attempts to load the AOT-compiled `.kernel.pt2` payload.
        
        Returns:
            The callable compiled artifact.
            
        Raises:
            FileNotFoundError if the kernel doesn't exist.
            RuntimeError if the kernel fails to load (e.g., hardware mismatch),
                         prompting fallback to standard weights.
        """
        kernel_path = self.pieces_dir / f"{piece_id}.kernel.pt2"
        if not kernel_path.exists():
            raise FileNotFoundError(f"No AOT compiled kernel exists for {piece_id}. Path: {kernel_path}")
            
        self._increment_load_count(piece_id)
        for cb in self._on_piece_loaded_cbs:
             cb(piece_id)
             
        try:
            # Load the compiled package artifact
            compiled_runner = torch._inductor.aoti_load_package(str(kernel_path))
            return compiled_runner
        except Exception as e:
            raise RuntimeError(
                f"Failed to load AOT kernel for {piece_id}. "
                f"This may be due to hardware or CUDA version mismatch. "
                f"Fallback to `.weights` is required. Internal error: {e}"
            )

