import json
import logging
from pathlib import Path
from typing import List, Dict, Any, Tuple
import numpy as np
from numba import njit

log = logging.getLogger("neuronpack")

@njit(fastmath=True, cache=True)
def _numba_cosine_search(query: np.ndarray, embeddings: np.ndarray, top_k: int):
    """
    Highly optimized JIT-compiled math backend for exact cosine similarity.
    query: (1, D), embeddings: (N, D)
    """
    q_norm = np.linalg.norm(query[0])
    q_norm = q_norm if q_norm != 0 else 1.0
    
    N = embeddings.shape[0]
    similarities = np.empty(N, dtype=np.float32)
    
    for i in range(N):
        e_norm = np.linalg.norm(embeddings[i])
        e_norm = e_norm if e_norm != 0 else 1.0
        dot_product = np.dot(query[0], embeddings[i])
        similarities[i] = dot_product / (q_norm * e_norm)
        
    k = min(top_k, N)
    if k == 0:
        return np.empty(0, dtype=np.int64), np.empty(0, dtype=np.float32)
        
    top_indices = np.argsort(-similarities)[:k]
    # Numba argsort returns a copy, so pulling from similarities array works smoothly
    top_scores = np.empty(k, dtype=np.float32)
    for idx_idx, orig_idx in enumerate(top_indices):
        top_scores[idx_idx] = similarities[orig_idx]
        
    return top_indices, top_scores


class Router:
    """
    Handles fast similarity search over expert embeddings.
    """
    def __init__(self, router_dir: Path):
        self.router_dir = Path(router_dir)
        self.registry_path = self.router_dir / "registry.json"
        self.embeddings_path = self.router_dir / "embeddings.npy"
        
        # In-memory indices
        self.embeddings: np.ndarray | None = None
        self.registry: Dict[str, str] = {} # maps index (str) to piece_id
        
        self.load()
        
    def load(self):
        """Loads embeddings and registry if they exist."""
        if self.embeddings_path.exists() and self.registry_path.exists():
            self.embeddings = np.load(self.embeddings_path)
            with open(self.registry_path, "r") as f:
                self.registry = json.load(f)
        else:
            self.embeddings = None
            self.registry = {}
            
    def save(self, embeddings: np.ndarray, registry: Dict[str, str]):
        """Saves embeddings and registry to disk."""
        self.router_dir.mkdir(parents=True, exist_ok=True)
        
        # Save embeddings
        np.save(self.embeddings_path, embeddings)
        self.embeddings = embeddings
        
        # Save registry
        with open(self.registry_path, "w") as f:
            json.dump(registry, f, indent=2)
        self.registry = registry

    def search(self, query_embedding: np.ndarray | list, top_k: int = 2) -> Tuple[List[str], List[float]]:
        """
        Finds the top_k matching experts for the given query using exact cosine similarity.
        
        Args:
            query_embedding: 1D vector representing the query semantics.
            top_k: Number of experts to return.
            
        Returns:
            Tuple of (list of piece_ids, list of scores)
        """
        if self.embeddings is None or not self.registry:
            log.error("Router search failed. No experts loaded in registry.")
            raise ValueError("Router has no loaded experts. Call update_registry() on the pack first.")
            
        query = np.array(query_embedding, dtype=np.float32)
        if query.ndim != 1:
            log.error(f"Router query dimension mismatch: expected 1D, got {query.shape}")
            raise ValueError(f"query_embedding must be a 1D vector, got shape {query.shape}")
            
        # Ensure correct shape for broadcasting into Numba API
        query = query.reshape(1, -1)
        
        # Numba math computation (Near C-speed without Python overhead)
        top_indices, top_scores = _numba_cosine_search(query, self.embeddings, top_k)
        
        # Mapping numerical indices back to piece_ids using the registry.json map
        expert_ids = [self.registry[str(idx)] for idx in top_indices]
        
        return expert_ids, top_scores.tolist()
