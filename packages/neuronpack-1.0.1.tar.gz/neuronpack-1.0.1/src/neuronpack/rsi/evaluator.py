import time
import math
import torch
import torch.nn as nn
from typing import Callable, Any
from neuronpack import NeuronPack

class Evaluator:
    """
    Computes the Meta-Objective Function: J(A) = P^alpha * R^(-beta) * exp(-gamma * C(A))
    
    This fitness scalar balances pure analytical performance (P) against 
    hardware latency (R) and architectural bloat (C(A)).
    """
    def __init__(self, 
                 performance_fn: Callable[[nn.Module], float],
                 alpha: float = 1.0, 
                 beta: float = 0.1, 
                 gamma: float = 0.01):
        """
        Args:
            performance_fn: A function that takes the current assembled model and 
                            returns a performance scalar P (higher is better, e.g. -loss or accuracy).
            alpha: Weight of pure performance.
            beta: Weight of latency penalization.
            gamma: Weight of complexity/parameter-count penalization.
        """
        self.performance_fn = performance_fn
        self.alpha = alpha
        self.beta = beta
        self.gamma = gamma
        
    def _compute_complexity(self, pack: NeuronPack) -> int:
        """
        Calculates C(A) = Total parameter count across the registry.
        """
        total_params = 0
        for piece_id in pack.router.registry.values():
            meta = pack.get_piece_meta(piece_id)
            total_params += meta.get("params", 0)
        return total_params
        
    def _measure_latency(self, model: nn.Module) -> float:
        """
        Measures R (latency in milliseconds).
        In a real scenario, this involves a dummy forward pass or leveraging reported metrics.
        We'll use a mocked timing envelope here assuming the user's `performance_fn` 
        handles the actual forward passes.
        """
        # For this RSI envelope, we assume R is proportional to the parameter count
        # or we rely on the user to record it. Here we simulate a baseline hardware cost.
        params = sum(p.numel() for p in model.parameters())
        # Simulate ~1ms per million parameters
        return max(1.0, params / 1e6)
        
    def evaluate(self, model: nn.Module, pack: NeuronPack) -> float:
        """
        Computes the final J(A) fitness score for the architecture.
        """
        # 1. Base Performance (P)
        p_score = self.performance_fn(model)
        
        # 2. Resource Efficiency (R)
        r_score = self._measure_latency(model)
        
        # 3. Complexity (C(A)) 
        # Convert absolute param count to "Millions of Params" for numerical stability in the exponent
        c_score = self._compute_complexity(pack) / 1e6
        
        # Meta-Objective: J(A) = P^alpha * R^(-beta) * e^(-gamma * C(A))
        # Ensure P is tightly bounded positive for the exponent.
        p_safe = max(1e-5, p_score)
        
        j_a = (math.pow(p_safe, self.alpha) * 
               math.pow(r_score, -self.beta) * 
               math.exp(-self.gamma * c_score))
               
        return j_a
