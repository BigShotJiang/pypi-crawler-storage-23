import copy
import logging
import torch
import torch.nn as nn
from typing import List, Callable, Dict, Any, Tuple
from neuronpack import NeuronPack

from .evaluator import Evaluator
from .search import Mutator

log = logging.getLogger("neuronpack")

class RSIController:
    """
    NEURON-RSI Execution Loop.
    Orchestrates the meta-learning cycle: proposing architectures, evaluating J(A),
    and executing Safe Replacement.
    """
    def __init__(self, 
                 primary_pack: NeuronPack, 
                 base_model: nn.Module,
                 evaluator: Evaluator,
                 mutator: Mutator,
                 significance_threshold: float = 0.01):
        """
        Args:
            primary_pack: The active functioning NeuronPack payload.
            base_model: The static Torch framework querying the Router.
            evaluator: The Meta-Objective instance calculating J(A).
            mutator: The ASE executing dynamic structure mutations.
            significance_threshold: Floating point multiplier representing the strict 
                                    growth percentage required to accept a structural mutation (e.g. 0.01 = 1%).
        """
        self.pack = primary_pack
        self.base_model = base_model
        self.evaluator = evaluator
        self.mutator = mutator
        self.significance_threshold = significance_threshold
        
        # Keep track of best achieved meta-objective score
        self.best_j_a = float('-inf')
        
    def _evaluate_state(self) -> float:
        """
        Calculates J(A) for the current active container state.
        Assumes `self.base_model` is structurally linked to `self.pack.router`.
        """
        # Ensure we have a baseline score
        return self.evaluator.evaluate(self.base_model, self.pack)

    def run_generation(self) -> Dict[str, Any]:
        """
        Executes one full cycle of True RSI.
        
        1. Evaluates Current State (J(A))
        2. Proposes Modifications (ASE)
        3. Evaluates Candidates (J(A'))
        4. Statistically Significant Selection
        5. Safe Replacement Execution
        
        Returns an operations report dict.
        """
        report = {"generation": len(self.pack.router.registry), "mutations_attempted": 0, "accepted": False}
        
        # Phase 1: Status Quo
        current_j_a = self._evaluate_state()
        if self.best_j_a == float('-inf'):
            self.best_j_a = current_j_a
            
        report["current_j_a"] = current_j_a
        log.debug(f"[RSI Phase 1] Status Quo J(A) = {current_j_a:.6f}")
            
        # Phase 2: Propose (Sandbox Expansion)
        candidate_ids = []
        loaded_experts = []
        for pid in self.pack.router.registry.values():
            meta = self.pack.get_piece_meta(pid)
            loaded_experts.append((meta.get("load_count", 0), pid))
            
        if loaded_experts:
            loaded_experts.sort(reverse=True)
            top_expert_id = loaded_experts[0][1]
            
            # Spawn mutants utilizing configured defaults
            mutant_id_1 = self.mutator.mutate_embedding(top_expert_id, self.pack)
            mutant_id_2 = self.mutator.spawn_clone_with_weight_noise(top_expert_id, self.pack)
            
            candidate_ids.extend([mutant_id_1, mutant_id_2])
            report["mutations_attempted"] = 2
            
            # Commit the sandbox layout so the Router engine can see them
            self.pack.update_registry()
            log.info(f"[RSI Phase 2] Proposed 2 architecture mutants sourced from {top_expert_id}")
        
        if not candidate_ids:
             # Seed generation if empty
             seed_id = self.mutator.spawn_random_expert(self.pack)
             self.pack.update_registry()
             report["accepted"] = True
             report["reason"] = "seeded_initial_expert"
             log.info("[RSI Phase 2] Blank architecture. Speculatively seeded random expert.")
             return report

        # Phase 3 & 4: Simulate and Evaluate
        candidate_j_a = self._evaluate_state()
        report["candidate_j_a"] = candidate_j_a
        log.debug(f"[RSI Phase 4] Candidate Sandbox J(A') = {candidate_j_a:.6f}")
        
        # Phase 5: Safe Replacement (Statistical Significance Check)
        improvement_margin = candidate_j_a - current_j_a
        is_significant = improvement_margin > (abs(current_j_a) * self.significance_threshold)
        
        if is_significant:
            # Commit structural changes
            self.best_j_a = candidate_j_a
            report["accepted"] = True
            report["reason"] = "significant_improvement"
            log.info(f"[RSI Phase 5] ACCEPTED mutated architecture. J(A') > J(A).")
            
            # Skip pruning here to allow the external loop to control layout
            report["pruned_weak_experts"] = 0
            
        else:
            # Rollback Sandbox
            failed_rollback_ids = []
            for cid in candidate_ids:
                weight_path = self.pack.pieces_dir / f"{cid}.weights"
                meta_path = self.pack.pieces_dir / f"{cid}.meta"
                try:
                    weight_path.unlink(missing_ok=True)
                    meta_path.unlink(missing_ok=True)
                except PermissionError:
                    failed_rollback_ids.append(cid)
                    log.error(f"[RSI Fatal OS] Files for {cid} locked during rollback!")
                    
            if failed_rollback_ids:
                report["rollback_partial"] = True
                report["failed_rollback_ids"] = failed_rollback_ids
                
            self.pack.update_registry() # Erase candidates from routing table
            report["accepted"] = False
            report["reason"] = "failed_to_beat_status_quo"
            log.info(f"[RSI Phase 5] REJECTED architecture. Rolling back Sandbox to Baseline J(A).")
            
        return report
