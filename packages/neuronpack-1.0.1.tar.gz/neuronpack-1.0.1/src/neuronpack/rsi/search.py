import numpy as np
import copy
from typing import Dict, Any, Type, List, Union, Optional
import torch
import torch.nn as nn
import logging
from neuronpack import NeuronPack

log = logging.getLogger("neuronpack")

class Mutator:
    """
    Architecture Search Engine (ASE).
    Handles constrained mutation operations over the NeuronPack search space.
    """
    def __init__(self, 
                 piece_archetypes: Union[List[Type[nn.Module]], Type[nn.Module]],
                 embedded_dim: int = 8,
                 default_noise_scale: float = 0.1,
                 default_noise_std: float = 0.01):
        """
        Args:
            piece_archetypes: A list of supported nn.Module classes to sample from during spawning,
                              enabling heterogeneous architecture search.
            embedded_dim: Dimensionality of the semantic routing embedding dynamically created.
            default_noise_scale: Radius for spherical embedding mutations.
            default_noise_std: Standard deviation for structural weight gaussian mutations.
        """
        if not isinstance(piece_archetypes, list):
            self.archetypes = [piece_archetypes]
        else:
            self.archetypes = piece_archetypes
            
        self.embedded_dim = embedded_dim
        self.default_noise_scale = default_noise_scale
        self.default_noise_std = default_noise_std
        
    def _generate_new_id(self, base_id: str, generation: int) -> str:
        return f"{base_id}_mut_g{generation}_{np.random.randint(1000, 9999)}"
        
    def mutate_embedding(self, piece_id: str, pack: NeuronPack, noise_scale: Optional[float] = None) -> str:
        """
        Nudges the semantic routing embedding of a piece to explore new feature spaces.
        Returns the ID of the new mutated piece.
        """
        scale = noise_scale if noise_scale is not None else self.default_noise_scale
        meta = pack.get_piece_meta(piece_id)
        weights = pack.get_piece_weights(piece_id)
        
        emb = np.array(meta.get("embedding", []))
        if emb.size == 0:
            log.error(f"Cannot mutate embedding for {piece_id}: No embedding found.")
            raise ValueError(f"Cannot mutate embedding for {piece_id}: No embedding found.")
            
        # Add spherical noise and re-normalize
        noise = np.random.normal(0, scale, size=emb.shape).astype(np.float32)
        new_emb = emb + noise
        norm = np.linalg.norm(new_emb)
        norm = max(norm, 1e-8)
        new_emb = new_emb / norm
        
        new_id = self._generate_new_id(piece_id, meta.get("load_count", 0))
        
        new_meta = copy.deepcopy(meta)
        new_meta["id"] = new_id
        new_meta["embedding"] = new_emb.tolist()
        new_meta["load_count"] = 0 # Reset telemetry for the mutant
        
        pack.add_piece(new_id, weights, new_meta)
        log.info(f"Mutated embedding for {piece_id} -> {new_id} [scale={scale}]")
        return new_id
        
    def spawn_clone_with_weight_noise(self, piece_id: str, pack: NeuronPack, noise_std: Optional[float] = None) -> str:
        """
        Clones an expert, injects Gaussian noise into its weights to promote 
        evolutionary divergence, and inserts it into the Pack.
        """
        std = noise_std if noise_std is not None else self.default_noise_std
        meta = pack.get_piece_meta(piece_id)
        weights = pack.get_piece_weights(piece_id)
        
        new_weights = {}
        for k, v in weights.items():
            # Apply additive noise to floating point parameters
            if v.is_floating_point():
                noise = torch.randn_like(v) * std
                new_weights[k] = v + noise
            else:
                new_weights[k] = v.clone()
                
        new_id = self._generate_new_id(piece_id, meta.get("load_count", 0))
        
        new_meta = copy.deepcopy(meta)
        new_meta["id"] = new_id
        new_meta["load_count"] = 0
        
        pack.add_piece(new_id, new_weights, new_meta)
        log.info(f"Spawned noisy weight clone for {piece_id} -> {new_id} [std={std}]")
        return new_id
        
    def spawn_random_expert(self, pack: NeuronPack) -> str:
        """
        Instantiates a completely fresh expert by sampling from the allowed archetypes
        with new random weights and a random semantic embedding.
        """
        selected_archetype = np.random.choice(self.archetypes)
        module = selected_archetype()
        weights = module.state_dict()
        
        emb = np.random.randn(self.embedded_dim).astype(np.float32)
        emb = emb / np.linalg.norm(emb)
        
        new_id = f"expert_rnd_g0_{np.random.randint(1000, 9999)}"
        
        meta = {
            "id": new_id,
            "role": "mlp_expert",
            "architecture": selected_archetype.__name__,
            "input_shape": [None], # Abstracted for ASE
            "output_shape": [None],
            "dtype": "float32",
            "params": sum(p.numel() for p in module.parameters()),
            "embedding": emb.tolist(),
            "tags": ["ase_spawn"],
            "load_count": 0,
            "version": "1.0.0",
            "trainable": True,
            "dependencies": [],
            "target_hardware": "cpu",
            "compiled": False,
            "compatibility_group": "rsi_dynamic"
        }
        
        pack.add_piece(new_id, weights, meta)
        log.info(f"Spawned totally random generic expert: {new_id} [{selected_archetype.__name__}]")
        return new_id
