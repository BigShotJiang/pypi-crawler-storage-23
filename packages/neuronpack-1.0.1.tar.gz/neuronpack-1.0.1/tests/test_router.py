import os
import tempfile
import pytest
import numpy as np
import torch
from neuronpack.core import NeuronPack
from neuronpack.router import Router

@pytest.fixture
def temp_pack_dir():
    with tempfile.TemporaryDirectory() as td:
        yield td

@pytest.fixture
def base_meta():
    return {
        "role": "mlp_expert",
        "architecture": "feed_forward",
        "input_shape": [None, 10],
        "output_shape": [None, 10],
        "dtype": "float32",
        "params": 100,
        "tags": ["moe"],
        "load_count": 0,
        "version": "1.0.0",
        "trainable": True,
        "dependencies": [],
        "target_hardware": None,
        "compiled": False,
        "compatibility_group": "default_transformers"
    }

def test_router_similarity():
    with tempfile.TemporaryDirectory() as td:
        router = Router(td)
        
        # 3 experts
        # E1 is close to [1, 0]
        # E2 is close to [0, 1]
        # E3 is close to [-1, 0]
        embeddings = np.array([
            [1.0, 0.1],
            [0.1, 1.0],
            [-1.0, 0.1]
        ], dtype=np.float32)
        
        registry = {"0": "exp_1", "1": "exp_2", "2": "exp_3"}
        
        router.save(embeddings, registry)
        
        # Test Query 1: should match exp_1
        query = np.array([1.0, 0.0])
        ids, scores = router.search(query, top_k=2)
        assert ids[0] == "exp_1"
        assert ids[1] == "exp_2" # because exp_3 is negative cosine
        assert len(ids) == 2
        
        # Test Query 2: should match exp_3
        query2 = np.array([-1.0, 0.0])
        ids2, scores2 = router.search(query2, top_k=1)
        assert ids2[0] == "exp_3"

def test_pack_update_registry(temp_pack_dir, base_meta):
    pack = NeuronPack(temp_pack_dir)
    
    # Add two experts with opposite embeddings
    w1 = {"w": torch.ones(10, 10)}
    m1 = base_meta.copy()
    m1["embedding"] = [1.0, 0.0]
    pack.add_piece("exp_A", w1, m1)
    
    w2 = {"w": torch.zeros(10, 10)}
    m2 = base_meta.copy()
    m2["embedding"] = [-1.0, 0.0]
    pack.add_piece("exp_B", w2, m2)
    
    pack.update_registry()
    
    # Reload pack and test router
    loaded = NeuronPack.load(temp_pack_dir)
    assert loaded.router.embeddings is not None
    assert len(loaded.router.registry) == 2
    
    res_ids, _ = loaded.router.search([1.0, 0.0], top_k=1)
    assert res_ids[0] == "exp_A"

def test_merge_experts(temp_pack_dir, base_meta):
    pack = NeuronPack(temp_pack_dir)
    
    # wA = 10.0
    # wB = 2.0
    pack.add_piece("exp_1", {"weight": torch.ones(2, 2) * 10.0}, base_meta | {"id": "exp_1", "embedding": [1.0]})
    pack.add_piece("exp_2", {"weight": torch.ones(2, 2) * 2.0}, base_meta | {"id": "exp_2", "embedding": [2.0]})
    
    # Blend: 80% exp_1 + 20% exp_2
    # Expected: (10 * 0.8) + (2 * 0.2) = 8 + 0.4 = 8.4
    merged = pack.merge_experts(["exp_1", "exp_2"], [0.8, 0.2])
    
    assert "weight" in merged
    assert torch.allclose(merged["weight"], torch.ones(2, 2) * 8.4)

def test_merge_experts_shape_mismatch(temp_pack_dir, base_meta):
    pack = NeuronPack(temp_pack_dir)
    pack.add_piece("exp_1", {"weight": torch.ones(2, 2)}, base_meta | {"id": "exp_1", "embedding": [1.0]})
    pack.add_piece("exp_2", {"weight": torch.ones(3, 3)}, base_meta | {"id": "exp_2", "embedding": [2.0]})
    
    with pytest.raises(RuntimeError): # PyTorch tensor size mismatch during internal add_
        pack.merge_experts(["exp_1", "exp_2"], [0.5, 0.5])
