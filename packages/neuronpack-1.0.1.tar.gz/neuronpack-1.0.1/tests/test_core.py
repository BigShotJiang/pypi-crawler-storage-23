import os
import tempfile
import pytest
import torch
import safetensors.torch
from neuronpack.core import NeuronPack

@pytest.fixture
def temp_pack_dir():
    with tempfile.TemporaryDirectory() as td:
        yield td

@pytest.fixture
def dummy_weights():
    return {
        "weight": torch.randn(10, 10),
        "bias": torch.randn(10)
    }

@pytest.fixture
def valid_meta():
    return {
        "id": "test_layer_01",
        "role": "attention",
        "architecture": "multi_head_attention",
        "input_shape": [None, 10],
        "output_shape": [None, 10],
        "dtype": "float32",
        "params": 110,
        "embedding": [0.1, 0.2, 0.3],
        "tags": ["test"],
        "load_count": 0,
        "version": "1.0.0",
        "trainable": True,
        "dependencies": [],
        "target_hardware": None,
        "compiled": False,
        "compatibility_group": "default_transformers"
    }

def test_initialization(temp_pack_dir):
    pack = NeuronPack(temp_pack_dir)
    assert os.path.exists(pack.path)
    assert os.path.exists(pack.pieces_dir)
    assert pack.manifest["model_name"] == os.path.basename(temp_pack_dir)

def test_add_piece_valid(temp_pack_dir, dummy_weights, valid_meta):
    pack = NeuronPack(temp_pack_dir)
    pack.add_piece("test_layer_01", dummy_weights, valid_meta)
    
    assert os.path.exists(os.path.join(pack.pieces_dir, "test_layer_01.meta"))
    assert os.path.exists(os.path.join(pack.pieces_dir, "test_layer_01.weights"))

def test_add_piece_invalid_meta(temp_pack_dir, dummy_weights, valid_meta):
    pack = NeuronPack(temp_pack_dir)
    invalid_meta = valid_meta.copy()
    del invalid_meta["role"] # Remove a required field
    
    with pytest.raises(ValueError, match="Missing required metadata keys"):
        pack.add_piece("test_layer_01", dummy_weights, invalid_meta)

def test_id_mismatch(temp_pack_dir, dummy_weights, valid_meta):
    pack = NeuronPack(temp_pack_dir)
    with pytest.raises(ValueError, match="does not match meta id"):
        pack.add_piece("wrong_id", dummy_weights, valid_meta)

def test_save_and_load_manifest(temp_pack_dir):
    pack = NeuronPack(temp_pack_dir)
    pack.manifest["architecture_type"] = "transformer"
    pack.save()
    
    loaded_pack = NeuronPack.load(temp_pack_dir)
    assert loaded_pack.manifest["architecture_type"] == "transformer"

def test_get_piece(temp_pack_dir, dummy_weights, valid_meta):
    pack = NeuronPack(temp_pack_dir)
    pack.add_piece("test_layer_01", dummy_weights, valid_meta)
    
    piece = pack.get_piece("test_layer_01")
    
    # Check meta
    assert piece["meta"]["id"] == "test_layer_01"
    assert piece["meta"]["role"] == "attention"
    
    # Check weights
    assert "weight" in piece["weights"]
    assert "bias" in piece["weights"]
    assert torch.equal(piece["weights"]["weight"], dummy_weights["weight"])
    assert torch.equal(piece["weights"]["bias"], dummy_weights["bias"])
