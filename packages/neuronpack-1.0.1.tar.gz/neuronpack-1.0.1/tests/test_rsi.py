import os
import tempfile
import pytest
import torch
from neuronpack.core import NeuronPack

@pytest.fixture
def temp_pack_dir():
    with tempfile.TemporaryDirectory() as td:
        yield td

@pytest.fixture
def base_meta():
    return {
        "role": "mlp_expert",
        "architecture": "feed_forward",
        "input_shape": [None, 4],
        "output_shape": [None, 8],
        "dtype": "float32",
        "params": 40,
        "embedding": None,
        "tags": ["rsi_test"],
        "load_count": 0,
        "version": "1.0.0",
        "trainable": False,
        "dependencies": [],
        "target_hardware": None,
        "compiled": False,
        "compatibility_group": "default_transformers"
    }

def test_on_piece_loaded_telemetry(temp_pack_dir, base_meta):
    pack = NeuronPack(temp_pack_dir)
    pack.add_piece("expert_1", {"w": torch.ones(2, 2)}, base_meta | {"id": "expert_1"})
    
    loaded_pieces = []
    pack.on_piece_loaded(lambda pid: loaded_pieces.append(pid))
    
    # Trigger load
    pack.get_piece_weights("expert_1")
    
    assert "expert_1" in loaded_pieces
    
    # Telemetry check disk state
    meta = pack.get_piece_meta("expert_1")
    assert meta["load_count"] == 1

def test_metric_thresholds(temp_pack_dir):
    pack = NeuronPack(temp_pack_dir)
    
    events_triggered = []
    
    pack.on_metric_threshold(
        metric="loss", 
        threshold=0.5, 
        direction="below", 
        callback=lambda: events_triggered.append("loss_below_0.5")
    )
    
    # Should not trigger
    pack.report_metric("loss", 0.6)
    assert len(events_triggered) == 0
    
    # Should trigger
    pack.report_metric("loss", 0.4)
    assert "loss_below_0.5" in events_triggered

def test_swap_piece(temp_pack_dir, base_meta):
    pack = NeuronPack(temp_pack_dir)
    pack.add_piece("expert_1", {"w": torch.ones(2, 2)}, base_meta | {"id": "expert_1"})
    
    new_weights = {"w": torch.zeros(2, 2)}
    pack.swap_piece("expert_1", new_weights)
    
    # Read back and verify change and automatic version increment
    swapped_weights = pack.get_piece_weights("expert_1")
    assert torch.equal(swapped_weights["w"], torch.zeros(2, 2))
    
    swapped_meta = pack.get_piece_meta("expert_1")
    assert swapped_meta["version"] == "1.0.1"

def test_prune_idle_pieces(temp_pack_dir, base_meta):
    pack = NeuronPack(temp_pack_dir)
    # Piece A starts with 0
    pack.add_piece("A", {"w": torch.ones(1)}, base_meta | {"id": "A"})
    # Piece B starts with 50 loads
    pack.add_piece("B", {"w": torch.ones(1)}, base_meta | {"id": "B", "load_count": 50})
    
    # Check idle threshold logic
    idle = pack.check_idle_pieces(min_load_count=10)
    assert "A" in idle
    assert "B" not in idle
    
    # Prune drops A but keeps B
    removed = pack.prune(role="mlp_expert", min_load_count=10)
    assert removed == 1
    
    # Validate disk state
    with pytest.raises(FileNotFoundError):
        pack.get_piece_meta("A")
        
    assert pack.get_piece_meta("B")["load_count"] == 50
