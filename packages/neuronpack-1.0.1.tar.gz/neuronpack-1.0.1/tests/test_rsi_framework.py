import os
import tempfile
import pytest
import numpy as np
import torch
import torch.nn as nn
from neuronpack import NeuronPack
from neuronpack.rsi import Evaluator, Mutator, RSIController

class DummyExpert(nn.Module):
    def __init__(self):
        super().__init__()
        self.w = nn.Parameter(torch.ones(2, 2))
        
    def forward(self, x):
        return x @ self.w

@pytest.fixture
def temp_pack():
    with tempfile.TemporaryDirectory() as td:
        pack = NeuronPack(td)
        yield pack

def dummy_performance_score(model: nn.Module) -> float:
    """
    Deterministic mock: The model performance is proportional to the 
    number of parameters (bigger = better performance, but more bloat).
    """
    return float(sum(p.numel() for p in model.parameters())) * 10.0

def test_evaluator_math():
    evaluator = Evaluator(
        performance_fn=dummy_performance_score,
        alpha=1.0,  # Linear reward
        beta=0.0,   # Ignore latency
        gamma=100.0 # Extreme penalty for parameters
    )
    
    # Simulate a Pack with 200 params total
    class MockPack:
        class MockRouter:
            registry = {"0": "piece_1", "1": "piece_2"}
        router = MockRouter()
        def get_piece_meta(self, pid):
            return {"params": 100}
            
    mock_pack = MockPack()
    model = DummyExpert() # 4 params in base model
    
    # Calculate J(A)
    # P = 4 * 10 = 40.0
    # C(A) = 200 / 1e6 = 0.0002
    # R = 4 / 1e6 = 0.000004 (but we set beta=0 so it's 1.0)
    # J(A) = 40.0 * 1.0 * e^(-100 * 0.0002) = 40.0 * e^(-0.02) = ~39.2
    
    score = evaluator.evaluate(model, mock_pack)
    assert 39.0 < score < 39.5

def test_mutator_search_engine(temp_pack):
    mutator = Mutator(DummyExpert, embedded_dim=4)
    
    # 1. Spawn Initial
    id_seed = mutator.spawn_random_expert(temp_pack)
    assert temp_pack.get_piece_meta(id_seed)["architecture"] == "DummyExpert"
    
    # 2. Clone with weight noise
    id_clone = mutator.spawn_clone_with_weight_noise(id_seed, temp_pack, noise_std=0.5)
    
    # Assert structural fork
    orig_w = temp_pack.get_piece_weights(id_seed)["w"]
    mut_w = temp_pack.get_piece_weights(id_clone)["w"]
    assert not torch.equal(orig_w, mut_w) # Noise applied
    
    # Assert semantic mapping preserved
    assert temp_pack.get_piece_meta(id_seed)["embedding"] == temp_pack.get_piece_meta(id_clone)["embedding"]
    
    # 3. Mutate Semantic Embedding Space
    id_embed = mutator.mutate_embedding(id_seed, temp_pack, noise_scale=1.0)
    assert temp_pack.get_piece_meta(id_seed)["embedding"] != temp_pack.get_piece_meta(id_embed)["embedding"]

def test_controller_execution_loop(temp_pack):
    model = DummyExpert()
    
    # We want to encourage growth. 
    # Alpha = 1.0 (Reward extra performance). 
    # Gamma = 0.01 (Low penalty for params)
    evaluator = Evaluator(dummy_performance_score, alpha=1.0, beta=0.0, gamma=0.01)
    mutator = Mutator(DummyExpert)
    
    controller = RSIController(temp_pack, model, evaluator, mutator)
    
    # Generation 1: Empty pack, should seed an expert
    report_1 = controller.run_generation()
    assert report_1["accepted"] == True
    assert report_1["reason"] == "seeded_initial_expert"
    assert len(temp_pack.router.registry) == 1
    
    # Generation 2: Will spawn 2 mutants. 
    # Because `dummy_performance_score` just looks at `model` (which is static `DummyExpert` 4 params),
    # P(A) is constant. However, adding mutants increases C(A) (Pack params).
    # Therefore J(A') < J(A). The controller should reject the mutation and rollback.
    report_2 = controller.run_generation()
    assert report_2["accepted"] == False
    assert report_2["reason"] == "failed_to_beat_status_quo"
    assert len(temp_pack.router.registry) == 1 # Sandbox erased
    
    # Let's forcefully change the model to simulate the Router mapping to a bigger aggregated network structure
    # This simulates a "successful mutation" where the new experts provide higher performance.
    mock_scores = [100.0, 999999.0]
    def mock_evaluate_state():
        return mock_scores.pop(0)
        
    controller._evaluate_state = mock_evaluate_state
    
    report_3 = controller.run_generation()
    assert report_3["accepted"] == True
    assert report_3["reason"] == "significant_improvement"
    assert len(temp_pack.router.registry) > 1 # Mutants kept alive
