import os
import shutil
import torch
import torch.nn as nn
from neuronpack.core import NeuronPack

class SimpleExpert(nn.Module):
    def __init__(self, in_dim, out_dim):
        super().__init__()
        self.linear = nn.Linear(in_dim, out_dim)
        self.gelu = nn.GELU()
        
    def forward(self, x):
        return self.gelu(self.linear(x))

def run_standalone_test():
    test_dir = "aot_test_container.neuron"
    if os.path.exists(test_dir):
        shutil.rmtree(test_dir, ignore_errors=True)
        
    pack = NeuronPack(test_dir)
    
    module = SimpleExpert(4, 8)
    state_dict = module.state_dict()
    
    meta = {
        "id": "standalone_expert",
        "role": "mlp_expert",
        "architecture": "feed_forward",
        "input_shape": [None, 4],
        "output_shape": [None, 8],
        "dtype": "float32",
        "params": 40,
        "embedding": None,
        "tags": ["aot"],
        "load_count": 0,
        "version": "1.0.0",
        "trainable": False,
        "dependencies": [],
        "target_hardware": None,
        "compiled": False
    }
    
    pack.add_piece("standalone_expert", state_dict, meta)
    
    example_x = torch.randn(2, 4)
    expected_out = module(example_x)
    
    print("Compiling piece...")
    try:
        pack.compile_piece("standalone_expert", module, (example_x,))
    except Exception as e:
        print(f"Compilation skipped/failed due to environment: {e}")
        return
        
    print("Compilation successful. Loading kernel...")
    try:
        runner = pack.load_piece_kernel("standalone_expert")
        out = runner(example_x)
        if isinstance(out, (list, tuple)):
            out = out[0]
            
        diff = torch.max(torch.abs(out - expected_out)).item()
        print(f"Max difference between original and compiled: {diff}")
        if diff < 1e-4:
            print("SUCCESS: AOT Kernel matches PyTorch eager execution perfectly.")
    except Exception as e:
        print(f"Failed to load/run compiled kernel: {e}")

if __name__ == "__main__":
    run_standalone_test()
