import os
import tempfile
import pytest
import torch
import torch.nn as nn
from neuronpack.core import NeuronPack

# Dummy PyTorch module
class SimpleExpert(nn.Module):
    def __init__(self, in_dim, out_dim):
        super().__init__()
        self.linear = nn.Linear(in_dim, out_dim)
        self.gelu = nn.GELU()
        
    def forward(self, x):
        return self.gelu(self.linear(x))

@pytest.fixture
def temp_pack_dir():
    with tempfile.TemporaryDirectory() as td:
        yield td

@pytest.fixture
def expert_meta():
    return {
        "role": "mlp_expert",
        "architecture": "feed_forward",
        "input_shape": [None, 4],
        "output_shape": [None, 8],
        "dtype": "float32",
        "params": 40,
        "embedding": None,
        "tags": ["aot-test"],
        "load_count": 0,
        "version": "1.0.0",
        "trainable": False,
        "dependencies": [],
        "target_hardware": None,
        "compiled": False,
        "compatibility_group": "default_transformers"
    }

def test_aot_compile_and_load(temp_pack_dir, expert_meta):
    pack = NeuronPack(temp_pack_dir)
    
    # Initialize a module and its state
    module = SimpleExpert(4, 8)
    state_dict = module.state_dict()
    
    # 1. Add typical piece
    pack.add_piece("test_expert", state_dict, expert_meta | {"id": "test_expert"})
    
    # Ensure it's not compiled yet
    assert not pack.get_piece_meta("test_expert")["compiled"]
    
    # Define an example input
    example_x = torch.randn(2, 4)
    expected_out = module(example_x)
    
    try:
        # 2. Compile
        pack.compile_piece("test_expert", module, (example_x,))
    except Exception as e:
        pytest.skip(f"AOT compilation failed, possibly due to missing C++ toolchain locally: {e}")
        return
        
    # Validation: Meta updated
    assert pack.get_piece_meta("test_expert")["compiled"]
    
    # Validation: Kernel exists
    kernel_path = pack.pieces_dir / "test_expert.kernel.pt2"
    assert kernel_path.exists()
    
    # 3. Load Kernel
    compiled_runner = pack.load_piece_kernel("test_expert")
    
    # 4. Infer via Kernel
    # AOT kernels return a list or tuple of outputs
    kernel_out = compiled_runner(example_x)
    
    if isinstance(kernel_out, (list, tuple)):
        kernel_out = kernel_out[0]
        
    # Check numerical equivalence
    assert torch.allclose(expected_out, kernel_out, atol=1e-5)

def test_load_nonexistent_kernel(temp_pack_dir, expert_meta):
    pack = NeuronPack(temp_pack_dir)
    pack.add_piece("missing_kernel", {"w": torch.ones(1)}, expert_meta | {"id": "missing_kernel"})
    
    with pytest.raises(FileNotFoundError):
        pack.load_piece_kernel("missing_kernel")
