import os
import time
import tempfile
import torch
import torch.nn as nn
from neuronpack import NeuronPack
import numpy as np

temp_dir = tempfile.mkdtemp()
pack = NeuronPack(temp_dir)

NUM_EXPERTS = 100
EXPERT_PARAMS = 100_000 # 100k parameters per expert
TOTAL_PARAMS = NUM_EXPERTS * EXPERT_PARAMS # 10M parameters total

class DummyExpert(nn.Module):
    def __init__(self, params=EXPERT_PARAMS):
        super().__init__()
        # Flattened representation for simplicity.
        self.w = nn.Parameter(torch.randn(params))
        
    def forward(self, x):
        return x * self.w.sum()

class MonolithicModel(nn.Module):
    def __init__(self, num_experts=NUM_EXPERTS, expert_params=EXPERT_PARAMS):
        super().__init__()
        # Traditional MoE keeps all experts in a giant list inside a single object
        self.experts = nn.ModuleList([DummyExpert(expert_params) for _ in range(num_experts)])
        self.routing = nn.Linear(8, num_experts) # Traditional routing layer
        
    def forward(self, x_emb, x_data):
        # x_emb: (batch, 8) routing signature
        gating = torch.softmax(self.routing(x_emb), dim=-1) # (batch, num_experts)
        best_expert_idx = torch.argmax(gating, dim=-1)
        
        # In a standard run we'd route it. But the point is the whole model lives in memory.
        expert = self.experts[best_expert_idx[0]] 
        return expert(x_data)

def run_benchmarks():
    print("==================================================")
    print(" NEURONPACK VS TRADITIONAL MONOLITHIC BENCHMARKS ")
    print(f" Simulating {NUM_EXPERTS} Experts ({TOTAL_PARAMS / 1e6:.1f}M Params Total)")
    print("==================================================\n")
    
    # --- Setup ---
    print("Setting up models...")
    monolithic_model = MonolithicModel()
    
    # Setup NeuronPack
    for i in range(NUM_EXPERTS):
        expert = DummyExpert()
        emb = np.random.randn(8).astype(np.float32)
        emb /= np.linalg.norm(emb)
        meta = {
            "id": f"expert_{i}",
            "embedding": emb.tolist(),
            "params": EXPERT_PARAMS,
            "role": "mlp_expert",
            "architecture": "DummyExpert",
            "input_shape": [None],
            "output_shape": [None],
            "dtype": "float32",
            "tags": ["benchmark"],
            "load_count": 0,
            "version": "1.0.0",
            "trainable": True,
            "dependencies": [],
            "target_hardware": "cpu",
            "compiled": False
        }
        pack.add_piece(f"expert_{i}", expert.state_dict(), meta)
        
    pack.update_registry()
    print("Setup complete.\n")

    # ==========================================
    # 1. Disk I/O: Updating a Single Expert
    # ==========================================
    print("--- 1. Disk I/O: Updating a Single Expert ---")
    
    # Traditional: Must resave the entire 10M param state_dict because we tweaked 1 expert
    new_expert = DummyExpert()
    monolithic_model.experts[50] = new_expert
    
    start = time.perf_counter()
    torch.save(monolithic_model.state_dict(), "traditional_model.pt")
    trad_save_time = time.perf_counter() - start
    
    # NeuronPack: Swap ONLY the 100k param piece on disk
    start = time.perf_counter()
    new_meta = pack.get_piece_meta("expert_50").copy()
    pack.add_piece("expert_50", new_expert.state_dict(), new_meta)
    np_save_time = time.perf_counter() - start
    
    print(f"Traditional Save Time (10M params): {trad_save_time*1000:.2f} ms")
    print(f"NeuronPack Save Time (100k params): {np_save_time*1000:.2f} ms")
    print(f"-> NeuronPack is {trad_save_time / max(1e-6, np_save_time):.1f}x Faster\n")

    # ==========================================
    # 2. Disk I/O: Loading a Single Expert
    # ==========================================
    print("--- 2. Disk I/O: Loading a Single Expert ---")
    
    # Traditional: Must load the giant checkpoint file, then extract sub-dictionary
    start = time.perf_counter()
    giant_state_dict = torch.load("traditional_model.pt", weights_only=True)
    loaded_expert_w = {k: v for k, v in giant_state_dict.items() if "experts.50" in k}
    trad_load_time = time.perf_counter() - start
    
    # NeuronPack: Safetensors zero-copy load of just that piece
    start = time.perf_counter()
    np_expert_w = pack.get_piece_weights("expert_50")
    np_load_time = time.perf_counter() - start
    
    print(f"Traditional Load Time (Whole Model + Parse): {trad_load_time*1000:.2f} ms")
    print(f"NeuronPack Load Time  (Zero-Copy Target):    {np_load_time*1000:.2f} ms")
    print(f"-> NeuronPack is {trad_load_time / max(1e-6, np_load_time):.1f}x Faster\n")

    # ==========================================
    # 3. Routing Engine vs PyTorch Linear
    # ==========================================
    print("--- 3. Routing: Finding Top-1 Expert (1,000 queries) ---")
    
    # Let's upscale the routing registry to 10,000 for routing stress test
    print("Scaling router registry temporarily to 10,000 experts for routing test...")
    large_registry = {}
    large_embs = np.random.randn(10000, 8).astype(np.float32)
    for i in range(10000):
        large_embs[i] /= np.linalg.norm(large_embs[i])
        large_registry[str(i)] = f"exp_{i}"
        
    pack.router.registry = large_registry
    pack.router.embeddings = large_embs
    
    routing_signatures = np.random.randn(1000, 8).astype(np.float32)
    routing_signatures_pt = torch.tensor(routing_signatures)
    
    giant_routing_layer = nn.Linear(8, 10000)
    
    # Traditional PyTorch Forward Route
    start = time.perf_counter()
    with torch.no_grad():
        for i in range(1000):
             logits = giant_routing_layer(routing_signatures_pt[i])
             top_1 = torch.argmax(logits)
    trad_route_time = time.perf_counter() - start
    
    # NeuronPack Numba Cosine Router
    # (Do one cold start to compile numba)
    _ = pack.router.search(routing_signatures[0], top_k=1)
    
    start = time.perf_counter()
    for i in range(1000):
        _ = pack.router.search(routing_signatures[i], top_k=1)
    np_route_time = time.perf_counter() - start
    
    print(f"Traditional (PyTorch nn.Linear Forward): {trad_route_time*1000:.2f} ms")
    print(f"NeuronPack (Numba @njit Exact Cosine):   {np_route_time*1000:.2f} ms")
    
    speedup = trad_route_time / np_route_time if np_route_time > 0 else float('inf')
    if speedup > 1:
        print(f"-> NeuronPack is {speedup:.1f}x Faster\n")
    else:
        print(f"-> NeuronPack holds parity with specialized Tensor operations ({speedup:.2f}x)\n")

    # ==========================================
    # 4. Memory Footprint (Conceptual)
    # ==========================================
    print("--- 4. VRAM / RAM Memory Footprint ---")
    
    trad_mem = sum(p.numel() * p.element_size() for p in monolithic_model.parameters()) / (1024**2)
    np_mem = EXPERT_PARAMS * 4 / (1024**2) # Size of just 1 expert loaded dynamically
    
    print(f"Traditional (10M active): ~{trad_mem:.2f} MB baseline locked in RAM")
    print(f"NeuronPack (On-Disk):     ~{np_mem:.2f} MB active RAM (Swaps dynamically)")
    print(f"-> NeuronPack achieves {trad_mem / max(1e-6, np_mem):.1f}x reduction in idle footprint constraints.")

    # Cleanup
    if os.path.exists("traditional_model.pt"):
        os.remove("traditional_model.pt")

if __name__ == "__main__":
    run_benchmarks()
