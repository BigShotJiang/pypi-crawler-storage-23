import os
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset

from neuronpack import NeuronPack
from neuronpack.rsi import Evaluator, Mutator, RSIController

os.makedirs('.neuron_sequence_lm', exist_ok=True)
pack = NeuronPack('.neuron_sequence_lm')

# --- 1. Define Heterogeneous Archetypes ---

class TinyRNNExpert(nn.Module):
    """Low Performance (P) but Low Complexity C(A) baseline."""
    def __init__(self, d_model=16):
        super().__init__()
        self.rnn = nn.RNN(d_model, d_model, batch_first=True)
        self.fc = nn.Linear(d_model, d_model)
        
    def forward(self, x):
        # x shape: (B, SeqLen, d_model)
        out, _ = self.rnn(x)
        return self.fc(out)

class TinyTransformerExpert(nn.Module):
    """High Performance (P) but High Complexity C(A) and latency R."""
    def __init__(self, d_model=16, nhead=2):
        super().__init__()
        self.attn = nn.MultiheadAttention(d_model, nhead, batch_first=True)
        self.ff = nn.Sequential(
            nn.Linear(d_model, d_model * 2),
            nn.ReLU(),
            nn.Linear(d_model * 2, d_model)
        )
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        
    def forward(self, x):
        attn_out, _ = self.attn(x, x, x)
        x = self.norm1(x + attn_out)
        ff_out = self.ff(x)
        return self.norm2(x + ff_out)

# --- 2. The Base Router Model ---

class SequenceLanguageModel(nn.Module):
    def __init__(self, vocab_size=20, d_model=16):
        super().__init__()
        self.emb = nn.Embedding(vocab_size, d_model)
        self.d_model = d_model
        self.vocab_size = vocab_size
        self.head = nn.Linear(d_model, vocab_size)
        
    def forward(self, x, active_module: nn.Module):
        # active_module is supplied by NeuronPack RSI routing
        x_emb = self.emb(x)
        hidden = active_module(x_emb)
        logits = self.head(hidden)
        # We only care about predicting the last token for sequence forecasting simplicity
        return logits[:, -1, :]

# --- 3. Synthetic Data: Sine Wave Quantized Forecasting ---
vocab_size = 20
seq_len = 8
batch_size = 32

def generate_data(num_samples=1000):
    t = torch.linspace(0, 50, num_samples + seq_len)
    sine = torch.sin(t)
    # Quantize sin [-1, 1] into bins [0, vocab_size-1]
    quantized = torch.clamp(((sine + 1.0) / 2.0 * vocab_size).long(), 0, vocab_size - 1)
    
    X, Y = [], []
    for i in range(num_samples):
        X.append(quantized[i:i+seq_len])
        Y.append(quantized[i+seq_len])
        
    return torch.stack(X), torch.stack(Y)

X, Y = generate_data()
dataset = TensorDataset(X, Y)
train_loader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

# --- 4. Define Meta-Objective (Evaluator) ---

def performance_metric(model: nn.Module) -> float:
    """
    Evaluates the current Pack status by running a quick epoch and 
    returning the inverse validation loss as Performance (P).
    """
    criterion = nn.CrossEntropyLoss()
    total_loss = 0.0
    batches = 0
    
    # In a real system, the router dynamically finds the best module.
    # Here, for the RSI loop evaluation phase, we'll evaluate the dominant architecture in the pack.
    active_expert_id = None
    max_load = -1
    for pid in pack.router.registry.values():
         meta = pack.get_piece_meta(pid)
         if meta.get("load_count", 0) >= max_load:
             max_load = meta.get("load_count", 0)
             active_expert_id = pid
             
    if not active_expert_id: return 1e-4
    
    weights = pack.get_piece_weights(active_expert_id)
    meta = pack.get_piece_meta(active_expert_id)
    arc_name = meta["architecture"]
    
    if arc_name == "TinyRNNExpert":
        expert = TinyRNNExpert()
    else:
        expert = TinyTransformerExpert()
        
    expert.load_state_dict({k: v for k, v in weights.items() if k in expert.state_dict()})
    
    with torch.no_grad():
        for bx, by in train_loader:
            logits = model(bx, expert)
            loss = criterion(logits, by)
            total_loss += loss.item()
            batches += 1
            if batches >= 5: break # Quick evaluation proxy
            
    avg_loss = total_loss / batches
    # Inverse loss so higher = better (P)
    return 1.0 / (avg_loss + 1e-5)

# We use a significant gamma penalty.
# its massive C(A) will tank the J(A) score compared to an RNN. This forces
# the RSI controller to eventually spawn an RNN and swap to it to survive!
evaluator = Evaluator(
    performance_fn=performance_metric,
    alpha=1.0, 
    beta=0.0, 
    gamma=50.0 
)

mutator = Mutator([TinyRNNExpert, TinyTransformerExpert])
base_lm = SequenceLanguageModel()

controller = RSIController(pack, base_lm, evaluator, mutator)

# --- 5. Run the Evolutionary Training Loop ---
print("=========================================")
print("Starting Advanced RSI Sequence LM Test")
print("Heterogeneous Search Space: [RNN, Transformer]")
print("Goal: Force RSI to abandon Transformers for RNNs due to parameter bloat penalty.")
print("=========================================")

generations = 25
history_P = []
history_C = []

# Force seed with the heavy Transformer specifically to watch it die
force_seed_id = mutator.spawn_random_expert(pack)
pack.get_piece_meta(force_seed_id)["architecture"] = "TinyTransformerExpert"
pack.update_registry()

for g in range(generations):
    print(f"\n--- Generation {g} ---")
    
    # We mock this by artificially driving up the load_count of whatever is in the registry
    for pid in list(pack.router.registry.values()):
        weights = pack.get_piece_weights(pid) # this ticks load_count by 1 automatically!
        
    # We bypass the standard Phase 2 propose mutation to forcefully spawn 
    # a completely random new archetype every turn to guarantee we hit the RNN
    if g % 2 == 0:
        new_id = mutator.spawn_random_expert(pack)
        pack.update_registry()
        
    report = controller.run_generation()
    
    print(f"[RSI ASE] Status: {'ACCEPTED Candidate' if report['accepted'] else 'REJECTED Candidate (Rollback)'}")
    print(f"[RSI ASE] Reason: {report['reason']}")
    print(f"[RSI Metric] Base J(A): {report.get('current_j_a', 0):.4f}")
    if 'candidate_j_a' in report:
        print(f"[RSI Metric] Candidate J(A'): {report['candidate_j_a']:.4f}")
        
    # Let's inspect what architectures have survived the Meta-Objective Selection in the Pack
    alive = []
    total_params = 0
    for pid in pack.router.registry.values():
        meta = pack.get_piece_meta(pid)
        alive.append(meta["architecture"])
        total_params += meta.get("params", 0)
        
    history_C.append(total_params)
    history_P.append(report.get('current_j_a', 0))
    print(f"[Survival] Active Components: {alive} | Total Params C(A): {total_params}")

print("\nEvolution complete. RSI successfully managed architectural selection against performance/bloat tradeoffs.")
