import os
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset

from neuronpack import NeuronPack
from neuronpack.rsi import Evaluator, Mutator, RSIController

os.makedirs('.neuron_diffusion_lm', exist_ok=True)
pack = NeuronPack('.neuron_diffusion_lm')

# --- 1. Define Diffusion Archetypes ---
# We will evolve the backbone of a tiny diffusion process

class TinyMLPUnet(nn.Module):
    """A minimal Multi-Layer Perceptron acting as a denoising backbone (Low C(A))."""
    def __init__(self, data_dim=8, hidden_dim=32):
        super().__init__()
        # Input: corrupted x (data_dim) + time embedding (1) -> output noise prediction (data_dim)
        self.net = nn.Sequential(
            nn.Linear(data_dim + 1, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, data_dim)
        )
        
    def forward(self, x, t):
        # x: (B, data_dim), t: (B, 1)
        return self.net(torch.cat([x, t], dim=-1))

class TinyAttentionUnet(nn.Module):
    """A more complex backbone using Self-Attention to model dependencies (High C(A), High P)."""
    def __init__(self, data_dim=8, hidden_dim=32):
        super().__init__()
        self.proj_in = nn.Linear(data_dim + 1, hidden_dim)
        self.attn = nn.MultiheadAttention(hidden_dim, 2, batch_first=True)
        self.proj_out = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, data_dim)
        )
        
    def forward(self, x, t):
        # x: (B, data_dim), t: (B, 1)
        h = self.proj_in(torch.cat([x, t], dim=-1)).unsqueeze(1) # (B, 1, hidden_dim)
        attn_out, _ = self.attn(h, h, h)
        return self.proj_out(attn_out.squeeze(1))

# --- 2. The Base Diffusion Model ---

class TinyDiffusionModel(nn.Module):
    def __init__(self, timesteps=10):
        super().__init__()
        self.timesteps = timesteps
        
    def forward(self, x_0, t, noise, active_backbone: nn.Module):
        """
        Simulates the forward noising process and returns the backbone's noise prediction.
        """
        # Very simplified standard linear noise schedule
        alpha = 1.0 - (t / self.timesteps) * 0.99
        x_t = torch.sqrt(alpha) * x_0 + torch.sqrt(1 - alpha) * noise
        
        predicted_noise = active_backbone(x_t, t)
        return predicted_noise

# --- 3. Synthetic Data: Clustering ---
data_dim = 8
batch_size = 32

def generate_data(num_samples=1000):
    # Generates data clustered around two Gaussian modes
    mode1 = torch.randn(num_samples // 2, data_dim) * 0.5 - 2.0
    mode2 = torch.randn(num_samples // 2, data_dim) * 0.5 + 2.0
    X = torch.cat([mode1, mode2], dim=0)
    return X[torch.randperm(num_samples)] # Shuffle

X = generate_data()
dataset = TensorDataset(X)
train_loader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

# --- 4. Define Meta-Objective (Evaluator) ---

def performance_metric(model: nn.Module) -> float:
    """
    Evaluates the current Pack status by running a quick epoch 
    and returning the inverse MSE loss as Performance (P).
    """
    criterion = nn.MSELoss()
    total_loss = 0.0
    batches = 0
    
    active_expert_id = None
    max_load = -1
    for pid in pack.router.registry.values():
         meta = pack.get_piece_meta(pid)
         if meta.get("load_count", 0) >= max_load:
             max_load = meta.get("load_count", 0)
             active_expert_id = pid
             
    if not active_expert_id: return 1e-4
    
    weights = pack.get_piece_weights(active_expert_id)
    meta = pack.get_piece_meta(active_expert_id)
    arc_name = meta["architecture"]
    
    if arc_name == "TinyMLPUnet":
        expert = TinyMLPUnet()
    else:
        expert = TinyAttentionUnet()
        
    expert.load_state_dict({k: v for k, v in weights.items() if k in expert.state_dict()})
    
    with torch.no_grad():
        for (bx,) in train_loader:
            # Sample random timesteps
            t = torch.randint(1, model.timesteps + 1, (bx.size(0), 1), dtype=torch.float32)
            noise = torch.randn_like(bx)
            
            pred_noise = model(bx, t, noise, expert)
            loss = criterion(pred_noise, noise)
            
            total_loss += loss.item()
            batches += 1
            if batches >= 5: break
            
    avg_loss = total_loss / batches
    return 1.0 / (avg_loss + 1e-5)

# Standard evaluation curve
evaluator = Evaluator(
    performance_fn=performance_metric,
    alpha=1.0, 
    beta=0.0, 
    gamma=10.0 # Standard parameter cost
)

mutator = Mutator([TinyMLPUnet, TinyAttentionUnet])
base_diff = TinyDiffusionModel()

controller = RSIController(pack, base_diff, evaluator, mutator)

# --- 5. Run Evolutionary Training ---
print("=========================================")
print("Starting Advanced RSI Tiny Diffusion Test")
print("Heterogeneous Search Space: [MLP Denoising Backbone, Attention Denoising Backbone]")
print("=========================================")

generations = 10

# Force seed to see what survives
force_seed_id = mutator.spawn_random_expert(pack)
pack.update_registry()

for g in range(generations):
    print(f"\n--- Generation {g} ---")
    
    for pid in list(pack.router.registry.values()):
        weights = pack.get_piece_weights(pid) # Bump load counts
        
    report = controller.run_generation()
    
    print(f"[RSI ASE] Status: {'ACCEPTED Candidate' if report['accepted'] else 'REJECTED Candidate (Rollback)'}")
    print(f"[RSI ASE] Reason: {report['reason']}")
    print(f"[RSI Metric] Base J(A): {report.get('current_j_a', 0):.4f}")
    if 'candidate_j_a' in report:
        print(f"[RSI Metric] Candidate J(A'): {report['candidate_j_a']:.4f}")
        
    alive = []
    total_params = 0
    for pid in pack.router.registry.values():
        meta = pack.get_piece_meta(pid)
        alive.append(meta["architecture"])
        total_params += meta.get("params", 0)
        
    print(f"[Survival] Active Components: {alive} | Total Params C(A): {total_params}")

print("\nEvolution complete for Tiny Diffusion backbone.")
