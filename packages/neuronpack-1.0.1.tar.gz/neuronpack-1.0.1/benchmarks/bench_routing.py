import time
import shutil
import tempfile
from pathlib import Path
import torch
import numpy as np
from neuronpack import NeuronPack

def create_mock_pack(path: str, n_experts: int, dim: int = 128, param_size: int = 4096):
    """Generates a dummy NeuronPack with N experts."""
    pack = NeuronPack(path)
    
    # Generate random embeddings for all experts
    np.random.seed(42)
    embeddings = np.random.randn(n_experts, dim).astype(np.float32)
    
    # Normalize embeddings
    embeddings /= np.linalg.norm(embeddings, axis=1, keepdims=True)
    
    print(f"Generating {n_experts} experts...")
    start_t = time.perf_counter()
    
    dummy_weight = {"weight": torch.randn(param_size, param_size)}
    
    for i in range(n_experts):
        meta = {
            "id": f"expert_{i}",
            "role": "mlp_expert",
            "architecture": "feed_forward",
            "input_shape": [None, param_size],
            "output_shape": [None, param_size],
            "dtype": "float32",
            "params": param_size * param_size,
            "embedding": embeddings[i].tolist(),
            "tags": ["benchmark"],
            "load_count": 0,
            "version": "1.0.0",
            "trainable": False,
            "dependencies": [],
            "target_hardware": None,
            "compiled": False
        }
        pack.add_piece(f"expert_{i}", dummy_weight, meta)
        
    print(f"Generated {n_experts} experts in {time.perf_counter() - start_t:.2f}s")
    
    start_t = time.perf_counter()
    pack.update_registry()
    print(f"Updated registry in {time.perf_counter() - start_t:.2f}s")
    
    return pack

def run_benchmarks():
    print("=== NeuronPack v0.2 Benchmarks ===")
    
    n_experts = 10_000
    top_k = 4
    dim = 128
    param_size = 1024 # 1024x1024 tensor = ~4MB per expert
    
    with tempfile.TemporaryDirectory() as td:
        pack_path = Path(td) / "bench_model.neuron"
        pack = create_mock_pack(str(pack_path), n_experts, dim=dim, param_size=param_size)
        
        # 1. Routing Benchmark
        print("\n--- Benchmarking Router Search ---")
        query_embedding = np.random.randn(dim).astype(np.float32)
        
        # Warmup
        pack.router.search(query_embedding, top_k=top_k)
        
        iters = 1000
        start_t = time.perf_counter()
        for _ in range(iters):
            pack.router.search(query_embedding, top_k=top_k)
        total_time = time.perf_counter() - start_t
        print(f"Searched top-{top_k} among {n_experts} experts: {total_time/iters * 1000:.3f} ms / query")
        
        # 2. Merging Benchmark
        print("\n--- Benchmarking Expert Merging ---")
        ids, scores = pack.router.search(query_embedding, top_k=top_k)
        
        # Warmup
        pack.merge_experts(ids, scores)
        
        merge_iters = 50
        start_t = time.perf_counter()
        for _ in range(merge_iters):
             pack.merge_experts(ids, scores)
        
        merge_time = time.perf_counter() - start_t
        print(f"Merged {top_k} experts ({param_size}x{param_size} params each): {merge_time/merge_iters * 1000:.3f} ms / merge")

if __name__ == "__main__":
    run_benchmarks()
