"""keephive: a knowledge sidecar for Claude Code."""

__version__ = "0.23.1"
