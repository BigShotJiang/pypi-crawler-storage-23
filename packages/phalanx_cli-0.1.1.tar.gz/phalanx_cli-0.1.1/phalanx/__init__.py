"""Phalanx — open-source, vendor-agnostic multi-agent orchestration CLI."""

__version__ = "0.1.1"
