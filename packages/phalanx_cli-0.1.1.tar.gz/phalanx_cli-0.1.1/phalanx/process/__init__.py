"""Process management: tmux sessions, worktrees, process pools."""
