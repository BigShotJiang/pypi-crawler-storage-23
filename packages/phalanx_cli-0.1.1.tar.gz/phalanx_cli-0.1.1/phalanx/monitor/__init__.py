"""Monitor: heartbeat, stall detection, lifecycle, GC."""
