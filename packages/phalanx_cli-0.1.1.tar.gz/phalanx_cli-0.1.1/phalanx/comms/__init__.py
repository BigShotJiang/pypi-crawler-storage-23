"""Communication: messaging and file locking."""
