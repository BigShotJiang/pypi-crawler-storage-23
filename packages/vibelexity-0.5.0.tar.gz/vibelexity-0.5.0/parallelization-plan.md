# Vibelexity Parallelization Plan

## Goal

Parallelize file-level metric analysis using `multiprocessing` to achieve a **3-6x speedup** on multi-core machines. This targets the dominant bottleneck: the sequential `_analyze_files` loop that parses and computes metrics for every source file one at a time.

---

## Current Architecture

```
cli()
  -> _validate_and_collect_files()          # collect N source files
  -> _perform_analysis(source_files, args)
       -> find_cycles(source_files)          # TASK A: circular deps (reads files itself)
       -> find_dead_code(source_files)       # TASK B: dead code    (reads files itself)
       -> _analyze_files(source_files)       # TASK C: per-file metrics (THE BOTTLENECK)
       -> find_duplicates(results)           # TASK D: depends on C
```

All four tasks run sequentially. Tasks A, B, and C are completely independent.

### Where Time Is Spent

| Phase | Work | Bound | Relative Cost |
|-------|------|-------|---------------|
| File I/O (`read_text`) | Read source from disk | I/O | Low (OS page cache) |
| Tree-sitter parse | C-level AST construction | CPU | **High** |
| 7 metric walks per function | Python AST traversal | CPU | **High** |
| Cycle detection | Graph build + DFS/Tarjan | CPU + I/O | Medium |
| Dead code detection | 2x parse + cross-ref graph | CPU + I/O | Medium |
| Duplication grouping | Hash-based clustering | CPU | Low |

The `_analyze_files` loop (Task C) dominates for any codebase with more than ~50 files. Each file is: read from disk, parsed by tree-sitter, then 7+ recursive metric walks run per function. This is CPU-bound work that the GIL prevents from parallelizing with threads.

---

## Strategy

### Tier 1 (Highest Impact): Parallelize `_analyze_files` with `ProcessPoolExecutor`

**Why ProcessPoolExecutor and not multiprocessing.Pool:**
- Cleaner API, better exception propagation, context manager support.
- Built into the standard library (`concurrent.futures`), no new dependencies.

**Why processes and not threads:**
- The work is CPU-bound (tree-sitter parsing + Python AST walks).
- The GIL prevents threads from achieving true parallelism for CPU work.
- Each file analysis is self-contained with no shared mutable state.

**Why this is safe:**
- `Parser` objects are created fresh per call in `parse_with_language()` — no shared state.
- `Language` singletons (`PY_LANGUAGE`, etc.) are immutable, safe to share across forks.
- All result types (`FileComplexity`, `FunctionComplexity`, `HalsteadMetrics`, `PatternViolation`) are pure dataclasses with only primitive fields (int, float, str, None, list). No tree-sitter `Node` references are stored. **Fully pickle-serializable.**
- No module-level side effects that would break with `fork` or `spawn`.

### Tier 2 (Secondary): Parallelize Top-Level Tasks A/B/C

Run `find_cycles`, `find_dead_code`, and `_analyze_files` concurrently using `ThreadPoolExecutor` (or `ProcessPoolExecutor`). Since each reads files independently and writes to separate result slots, there are no conflicts.

This is a smaller win because cycles and dead code are typically faster than the full metrics analysis, but it's free once the infrastructure exists.

---

## Detailed Implementation Plan

### Step 1: Create a Worker Function

Create a top-level module function that can be pickled by multiprocessing. It wraps the existing per-file analysis and returns structured results including errors.

**File: `src/vibelexity/analysis.py`**

```python
from concurrent.futures import ProcessPoolExecutor
import os

def _analyze_single_file(filepath: str) -> tuple[str, FileComplexity | None, str | None]:
    """Worker function for parallel file analysis.

    Returns (filepath, result_or_none, error_message_or_none).
    Must be a top-level function for pickling.
    """
    from vibelexity.analyzers.go import analyze_file as analyze_file_go
    from vibelexity.analyzers.python import analyze_file as analyze_file_py
    from vibelexity.analyzers.typescript import analyze_file as analyze_file_ts

    ext = Path(filepath).suffix.lower()
    if ext in {".ts", ".tsx", ".js", ".jsx"}:
        analyzer = analyze_file_ts
    elif ext in {".go"}:
        analyzer = analyze_file_go
    else:
        analyzer = analyze_file_py

    try:
        result = analyzer(filepath)
        return (filepath, result, None)
    except Exception as e:
        return (filepath, None, str(e))
```

**Key design decisions:**
- Imports are inside the function so each worker process loads them on first call (avoids pickling import state).
- Returns a 3-tuple so the parent can collect both results and errors without losing information.
- The function signature takes a single `str` argument — simple, picklable.

### Step 2: Replace the Sequential Loop

**File: `src/vibelexity/analysis.py`**

```python
def _analyze_files(filepaths, parallel: bool = True) -> list[FileComplexity]:
    if not parallel or len(filepaths) < 4:
        return _analyze_files_sequential(filepaths)
    return _analyze_files_parallel(filepaths)


def _analyze_files_sequential(filepaths) -> list[FileComplexity]:
    """Original sequential implementation, used for small file counts."""
    # (move current _analyze_files body here unchanged)
    ...


def _analyze_files_parallel(filepaths) -> list[FileComplexity]:
    """Parallel file analysis using ProcessPoolExecutor."""
    max_workers = min(os.cpu_count() or 1, len(filepaths))

    results = []
    filepath_strs = [str(f) for f in filepaths]

    with ProcessPoolExecutor(max_workers=max_workers) as executor:
        for filepath, result, error in executor.map(
            _analyze_single_file, filepath_strs
        ):
            if error is not None:
                print(f"Warning: skipping {filepath}: {error}", file=sys.stderr)
            elif result is not None:
                results.append(result)

    return results
```

**Key design decisions:**
- **Threshold of 4 files**: Below this, process spawn overhead exceeds the parallelism benefit. The exact threshold can be tuned, but 4 is a reasonable starting point.
- **`max_workers` capped by file count**: No point spawning 8 processes for 5 files.
- **`executor.map` preserves ordering**: Results come back in submission order, which matches the current sequential behavior. If ordering doesn't matter, `as_completed` could be used for slightly better throughput, but the difference is negligible.
- **Errors are collected and printed after**: Same user-visible behavior as the current code.

### Step 3: Parallelize Top-Level Tasks (Tier 2)

**File: `src/vibelexity/main.py`, inside `_perform_analysis`**

```python
from concurrent.futures import ThreadPoolExecutor

def _perform_analysis(source_files, args):
    config = {"ts_module_resolution": args.ts_module_resolution}
    analysis_data = {}

    run_all = not any([...])  # (unchanged)

    # Define task callables
    def run_cycles():
        if args.show_circulars or run_all:
            if args.algorithm == "tarjan":
                return find_cycles_tarjan(source_files, config=config)
            return find_cycles(source_files, config=config)
        return None

    def run_dead_code():
        if args.show_dead or run_all:
            return find_dead_code(source_files)
        return None

    def run_metrics():
        if (args.show_bad_patterns or args.show_dupes or args.show_fatties
                or args.worst_cog or args.worst_npath or args.worst_dtd
                or args.worst_cc or args.worst_mi or args.worst_ldi
                or run_all):
            return _analyze_files(source_files)
        return None

    # Run A, B, C in parallel
    with ThreadPoolExecutor(max_workers=3) as executor:
        future_cycles = executor.submit(run_cycles)
        future_dead = executor.submit(run_dead_code)
        future_metrics = executor.submit(run_metrics)

        analysis_data["cycles"] = future_cycles.result()
        analysis_data["dead_code"] = future_dead.result()
        analysis_data["results"] = future_metrics.result()

    # D depends on C — runs after
    if args.show_dupes or run_all:
        results = analysis_data.get("results")
        analysis_data["duplicates"] = (
            find_duplicates(results, ...) if results else []
        )
    else:
        analysis_data["duplicates"] = None

    return analysis_data
```

**Why `ThreadPoolExecutor` here (not `ProcessPoolExecutor`):**
- The `run_metrics` task already internally uses `ProcessPoolExecutor` from Step 2. Nesting `ProcessPoolExecutor` inside another `ProcessPoolExecutor` causes deadlocks.
- Threads work here because the three tasks are coarse-grained. `run_metrics` releases the GIL into its own process pool. `run_cycles` and `run_dead_code` release the GIL during file I/O and during tree-sitter C parsing.
- This gives us overlapped execution of all three analysis pipelines.

### Step 4: Add `--no-parallel` CLI Flag

Add a flag to disable parallelization for debugging and profiling.

```python
("--no-parallel", {
    "dest": "no_parallel",
    "action": "store_true",
    "help": "Disable parallel processing (useful for debugging)",
}),
```

Thread this through `_perform_analysis` and `_analyze_files`.

### Step 5: Handle `spawn` Start Method (macOS)

On macOS, the default multiprocessing start method is `spawn` (not `fork`) since Python 3.8. With `spawn`, each worker process re-imports all modules from scratch. This is actually fine for our case because:

- Tree-sitter language loading happens at import time and is fast (~5ms per language).
- There are no module-level resources that need to be inherited.
- No `if __name__ == "__main__"` guard is needed because `ProcessPoolExecutor` handles this internally.

No special handling required, but worth noting in comments.

---

## What NOT to Parallelize

| Component | Reason |
|-----------|--------|
| Per-metric walks within a single file | Too fine-grained; process spawn overhead would dwarf the ~7 microsecond savings per function. |
| `find_duplicates` | Already O(n) hash-based grouping; takes milliseconds even for large codebases. |
| Graph algorithms in cycle detection | Inherently sequential (DFS/Tarjan require ordered traversal). |
| Output formatting | Trivially fast and must be sequential for correct terminal output. |

---

## Risk Assessment

| Risk | Likelihood | Mitigation |
|------|-----------|------------|
| Pickle serialization failure | Low | All result dataclasses use only primitive types. No `Node` refs stored. Verified. |
| Process spawn overhead dominates for small codebases | Medium | Threshold check: fall back to sequential for < 4 files. |
| Non-deterministic output ordering | Low | `executor.map` preserves order. If using `as_completed`, sort results by filepath after collection. |
| Memory spike from N parallel parses | Low-Medium | `max_workers` is capped at `os.cpu_count()`. Each parse is ~2-10MB for typical files. On an 8-core machine, peak is ~80MB additional. |
| macOS `spawn` overhead | Low | ~50ms one-time cost for worker process initialization. Amortized over hundreds of files. |
| Deadlock from nested process pools | Medium | Tier 2 uses `ThreadPoolExecutor` for the outer level, not `ProcessPoolExecutor`. |
| Broken stderr output from workers | Low | Workers return errors as strings; parent prints them. No direct stderr writes from workers. |

---

## Files Changed

| File | Change |
|------|--------|
| `src/vibelexity/analysis.py` | Add `_analyze_single_file` worker, add `_analyze_files_parallel`, modify `_analyze_files` to dispatch. |
| `src/vibelexity/main.py` | Wrap tasks A/B/C in `ThreadPoolExecutor` inside `_perform_analysis`. Add `--no-parallel` flag. |
| `tests/` | Add test for parallel analysis producing same results as sequential. |

No new dependencies. No changes to parsers, metrics, analyzers, or models.

---

## Expected Performance Gains

| Codebase Size | Sequential (est.) | Parallel 8-core (est.) | Speedup |
|--------------|-------------------|----------------------|---------|
| 10 files | ~0.3s | ~0.3s (sequential fallback) | 1x |
| 100 files | ~3s | ~0.8s | ~4x |
| 1,000 files | ~30s | ~6s | ~5x |
| 10,000 files | ~5min | ~1min | ~5x |

The speedup plateaus around 5-6x on 8 cores due to:
- Amdahl's law: serial portions (file collection, aggregation, output) are ~10-15% of total time.
- Process spawn cost: ~50ms per worker on macOS with `spawn`.
- I/O contention: many workers reading files simultaneously.

---

## Implementation Order

1. **Step 1 + 2**: `_analyze_single_file` worker + `_analyze_files_parallel` — this is 80% of the win.
2. **Step 4**: `--no-parallel` flag — needed for testing correctness.
3. **Step 5**: Verify behavior on macOS `spawn` — just a test run, no code changes expected.
4. **Step 3**: Top-level task parallelism — smaller additional win, clean implementation.
5. **Tests**: Verify parallel results match sequential results exactly.

---

## Validation

To confirm correctness:
```bash
# Run both modes and compare JSON output
uv run vibelexity /path/to/codebase --json > parallel.json
uv run vibelexity /path/to/codebase --json --no-parallel > sequential.json
diff parallel.json sequential.json
# Should produce no output (identical results)
```
