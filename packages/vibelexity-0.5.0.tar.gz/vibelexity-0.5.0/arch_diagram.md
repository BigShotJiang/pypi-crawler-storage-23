# Vibelexity Architecture Diagram

```mermaid
graph TB
    subgraph CLI["CLI & Orchestration"]
        main["main.py<br/><i>cli(), argparse</i>"]
        analysis["analysis.py<br/><i>_analyze_files(), candidates</i>"]
        file_utils["file_utils.py<br/><i>_collect_source_files()</i>"]
        cache["cache.py<br/><i>load/save cached, worktrees</i>"]
    end

    subgraph Core["Core / Shared"]
        models["models.py<br/><i>FunctionComplexity, FileComplexity,<br/>HalsteadMetrics, CallGraph, etc.</i>"]
        common["common.py<br/><i>compute_halstead(), MI, LDI,<br/>LOC/SLOC, boolean chains</i>"]
        stats["stats.py<br/><i>percentile, aggregate_*</i>"]
        thresholds["thresholds.py<br/><i>COGNITIVE=15, NPATH=200, etc.</i>"]
    end

    subgraph Parsers["Parsers (tree-sitter)"]
        p_shared["parsers/shared.py"]
        p_py["parsers/python.py"]
        p_ts["parsers/typescript.py"]
        p_go["parsers/go.py"]
    end

    subgraph Analyzers["Analyzers"]
        a_common["analyzers/common.py<br/><i>AnalyzerConfig,<br/>analyze_source_generic()</i>"]
        a_shared["analyzers/shared.py<br/><i>create_analyze_file()</i>"]
        a_py["analyzers/python.py"]
        a_ts["analyzers/typescript.py"]
        a_go["analyzers/go.py"]
    end

    subgraph Metrics["Metrics"]
        m_cognitive["metrics/cognitive/<br/><i>common, python, ts, go</i>"]
        m_halstead["metrics/halstead/<br/><i>common, python, ts, go</i>"]
        m_cyclomatic["metrics/cyclomatic/<br/><i>shared, python, ts, go</i>"]
        m_npath["metrics/npath/<br/><i>python, ts, go</i>"]
        m_dtd["metrics/dtd/<br/><i>python, ts, go</i>"]
        m_lloc["metrics/lloc/<br/><i>python, ts, go</i>"]
        m_fatness["metrics/fatness/<br/><i>compute_fatness(),<br/>python, ts, go</i>"]
        m_duplication["metrics/duplication/<br/><i>core, config</i>"]
        m_indirection["metrics/indirection/<br/><i>python</i>"]
    end

    subgraph CircDeps["Circular Dependencies"]
        cd_core["circular_deps/core.py<br/><i>build_dependency_graph(),<br/>find_cycles()</i>"]
        cd_models["circular_deps/models.py<br/><i>ImportInfo, Cycle,<br/>DependencyGraph</i>"]
        cd_fmt["circular_deps/formatter.py"]
        cd_parsers["circular_deps/parsers/<br/><i>base, python, ts, go</i>"]
        cd_resolvers["circular_deps/resolvers/<br/><i>base, shared, python,<br/>ts, tsconfig, go</i>"]
    end

    subgraph DeadCode["Dead Code Detection"]
        dc_core["dead_code/core.py<br/><i>find_dead_code()</i>"]
        dc_fmt["dead_code/formatters.py"]
        dc_parsers["dead_code/parsers/<br/><i>base, python, ts, go</i>"]
    end

    subgraph CallGraph["Call Graph"]
        cg_core["call_graph/core.py<br/><i>build_call_graph(),<br/>find_call_cycles()</i>"]
        cg_fmt["call_graph/formatters.py<br/><i>format_dot()</i>"]
        cg_parsers["call_graph/parsers/<br/><i>base, python</i>"]
    end

    subgraph Patterns["Pattern Detection"]
        pat_shared["patterns/shared.py<br/><i>check_patterns()</i>"]
        pat_common["patterns/common.py<br/><i>create_query(), run_captures()</i>"]
        pat_py["patterns/python.py"]
        pat_ts["patterns/typescript.py"]
        pat_loops["patterns/loops.py"]
    end

    subgraph Output["Output"]
        out_rich["output/rich_output.py<br/><i>print_*_table()</i>"]
        out_json["output/json.py<br/><i>_print_json()</i>"]
        out_cmp["output/comparison.py<br/><i>delta_text()</i>"]
    end

    %% CLI orchestration
    main --> analysis
    main --> file_utils
    main --> cache
    main --> out_rich
    main --> out_json
    main --> cd_core
    main --> dc_core
    main --> cg_core
    main --> m_duplication
    main --> m_fatness

    %% Analysis layer
    analysis --> a_py
    analysis --> a_ts
    analysis --> a_go
    analysis --> stats
    analysis --> thresholds

    %% Analyzers → Parsers
    a_py --> p_py
    a_ts --> p_ts
    a_go --> p_go
    a_py --> a_common
    a_ts --> a_common
    a_go --> a_common
    a_common --> a_shared
    a_common --> models
    a_common --> common

    %% Parsers shared
    p_py --> p_shared
    p_ts --> p_shared
    p_go --> p_shared

    %% Analyzers → Metrics
    a_py --> m_cognitive
    a_py --> m_halstead
    a_py --> m_cyclomatic
    a_py --> m_npath
    a_py --> m_dtd
    a_py --> m_lloc
    a_py --> pat_shared

    a_ts --> m_cognitive
    a_ts --> m_halstead
    a_ts --> m_cyclomatic
    a_ts --> m_npath
    a_ts --> m_dtd
    a_ts --> m_lloc
    a_ts --> pat_shared

    a_go --> m_cognitive
    a_go --> m_halstead
    a_go --> m_cyclomatic
    a_go --> m_npath
    a_go --> m_dtd
    a_go --> m_lloc

    %% Metrics → Core
    m_cognitive --> common
    m_halstead --> common
    m_fatness --> models
    m_duplication --> models

    %% Circular deps internals
    cd_core --> cd_models
    cd_core --> cd_parsers
    cd_core --> cd_resolvers
    cd_core --> p_shared
    cd_fmt --> cd_models

    %% Dead code internals
    dc_core --> dc_parsers
    dc_core --> models
    dc_fmt --> models

    %% Call graph internals
    cg_core --> cg_parsers
    cg_core --> models

    %% Pattern internals
    pat_shared --> pat_common
    pat_shared --> pat_py
    pat_shared --> pat_ts
    pat_shared --> pat_loops

    %% Output dependencies
    out_rich --> stats
    out_rich --> out_cmp
    out_rich --> analysis
    out_json --> stats
    out_json --> models
    out_json --> analysis

    %% Stats → Core
    stats -.-> models

    %% Parsers → fatness param count
    p_py --> m_fatness
    p_ts --> m_fatness
    p_go --> m_fatness

    %% Styling
    classDef cliStyle fill:#4A90D9,stroke:#2C5F8A,color:#fff
    classDef coreStyle fill:#E8A838,stroke:#B07D2B,color:#fff
    classDef parserStyle fill:#7BC67E,stroke:#4A8B4D,color:#fff
    classDef analyzerStyle fill:#C084C0,stroke:#8B5E8B,color:#fff
    classDef metricStyle fill:#E06666,stroke:#A34545,color:#fff
    classDef depStyle fill:#6DB3F2,stroke:#4A8BC0,color:#fff
    classDef deadStyle fill:#93C47D,stroke:#6B8F5A,color:#fff
    classDef cgStyle fill:#F6B26B,stroke:#C08040,color:#fff
    classDef patStyle fill:#A4C2F4,stroke:#7590B8,color:#fff
    classDef outStyle fill:#FFD966,stroke:#C0A44D,color:#333

    class main,analysis,file_utils,cache cliStyle
    class models,common,stats,thresholds coreStyle
    class p_shared,p_py,p_ts,p_go parserStyle
    class a_common,a_shared,a_py,a_ts,a_go analyzerStyle
    class m_cognitive,m_halstead,m_cyclomatic,m_npath,m_dtd,m_lloc,m_fatness,m_duplication,m_indirection metricStyle
    class cd_core,cd_models,cd_fmt,cd_parsers,cd_resolvers depStyle
    class dc_core,dc_fmt,dc_parsers deadStyle
    class cg_core,cg_fmt,cg_parsers cgStyle
    class pat_shared,pat_common,pat_py,pat_ts,pat_loops patStyle
    class out_rich,out_json,out_cmp outStyle
```

## Legend

| Color | Subsystem | Description |
|-------|-----------|-------------|
| Blue | CLI & Orchestration | `main.py`, `analysis.py`, `file_utils.py`, `cache.py` |
| Orange | Core / Shared | `models.py`, `common.py`, `stats.py`, `thresholds.py` |
| Green | Parsers | Tree-sitter AST parsing per language |
| Purple | Analyzers | Orchestrate metric computation per language |
| Red | Metrics | 9 metric families with per-language implementations |
| Light Blue | Circular Dependencies | Import parsers, path resolvers, cycle detection |
| Light Green | Dead Code | Symbol definition/reference tracking, unused code |
| Peach | Call Graph | Function call graph construction (Python-only) |
| Periwinkle | Pattern Detection | Anti-pattern and loop detection |
| Yellow | Output | Rich terminal tables, JSON, comparison deltas |

## Data Flow

`main.py` orchestrates everything &rarr; `analysis.py` dispatches to language-specific analyzers &rarr; analyzers call parsers for AST + metrics for computation &rarr; results aggregate via `stats.py` &rarr; output renders via `rich_output.py` or `json.py`. The circular deps, dead code, call graph, and duplication subsystems run as independent analysis passes invoked directly from `main.py`.
