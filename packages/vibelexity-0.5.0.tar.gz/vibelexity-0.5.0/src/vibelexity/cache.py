"""Git state detection and cache I/O for vibelexity."""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
import uuid
from dataclasses import dataclass
from pathlib import Path


@dataclass
class GitState:
    is_git_repo: bool
    commit_hash: str
    is_dirty: bool
    repo_root: str


@dataclass
class CacheResult:
    hit: bool
    data: dict | None


@dataclass
class WorktreeInfo:
    path: str
    branch_name: str


def get_git_state(target_dir: str | Path) -> GitState:
    """Detect git repository state for the given directory."""
    target_dir = str(target_dir)

    try:
        result = subprocess.run(
            ["git", "rev-parse", "--is-inside-work-tree"],
            capture_output=True, text=True, cwd=target_dir,
        )
        is_git = result.returncode == 0 and result.stdout.strip() == "true"
    except FileNotFoundError:
        is_git = False

    if not is_git:
        return GitState(is_git_repo=False, commit_hash="", is_dirty=False, repo_root="")

    commit_hash = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        capture_output=True, text=True, cwd=target_dir,
    ).stdout.strip()

    porcelain = subprocess.run(
        ["git", "status", "--porcelain"],
        capture_output=True, text=True, cwd=target_dir,
    ).stdout.strip()
    is_dirty = len(porcelain) > 0

    repo_root = subprocess.run(
        ["git", "rev-parse", "--show-toplevel"],
        capture_output=True, text=True, cwd=target_dir,
    ).stdout.strip()

    return GitState(
        is_git_repo=True,
        commit_hash=commit_hash,
        is_dirty=is_dirty,
        repo_root=repo_root,
    )


def get_cache_key(git_state: GitState) -> str:
    """Return cache key: commit hash for git repos, 'nogit' otherwise."""
    if git_state.is_git_repo:
        return git_state.commit_hash
    return "nogit"


def _cache_dir(target_dir: str | Path) -> Path:
    """Return the .vibelexity cache directory for the given target."""
    return Path(target_dir).resolve() / ".vibelexity"


def load_cached(target_dir: str | Path, key: str) -> CacheResult:
    """Load cached analysis results from .vibelexity/<key>.json."""
    cache_file = _cache_dir(target_dir) / f"{key}.json"
    if not cache_file.exists():
        return CacheResult(hit=False, data=None)

    try:
        data = json.loads(cache_file.read_text(encoding="utf-8"))
        return CacheResult(hit=True, data=data)
    except (json.JSONDecodeError, OSError) as e:
        print(f"Warning: corrupt cache file {cache_file}, treating as miss: {e}", file=sys.stderr)
        return CacheResult(hit=False, data=None)


def save_cached(target_dir: str | Path, key: str, data: dict) -> Path:
    """Write analysis results to .vibelexity/<key>.json."""
    cache = _cache_dir(target_dir)
    cache.mkdir(parents=True, exist_ok=True)
    cache_file = cache / f"{key}.json"
    cache_file.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return cache_file


def create_temp_worktree(repo_root: str | Path) -> WorktreeInfo:
    """Create a temporary git worktree for clean-state analysis."""
    hex_id = uuid.uuid4().hex[:8]
    branch_name = f"_vibelexity_tmp_{hex_id}"
    worktree_path = Path(repo_root) / f".{hex_id}"

    subprocess.run(
        ["git", "worktree", "add", "-b", branch_name, str(worktree_path), "HEAD"],
        capture_output=True, text=True, cwd=str(repo_root),
        check=True,
    )

    return WorktreeInfo(path=str(worktree_path), branch_name=branch_name)


def cleanup_temp_worktree(repo_root: str | Path, info: WorktreeInfo) -> None:
    """Remove temporary worktree and its branch."""
    repo_root = str(repo_root)

    subprocess.run(
        ["git", "worktree", "remove", info.path, "--force"],
        capture_output=True, text=True, cwd=repo_root,
    )

    subprocess.run(
        ["git", "branch", "-D", info.branch_name],
        capture_output=True, text=True, cwd=repo_root,
    )

    # Fallback: remove directory if it still exists
    worktree_dir = Path(info.path)
    if worktree_dir.exists():
        shutil.rmtree(worktree_dir, ignore_errors=True)
