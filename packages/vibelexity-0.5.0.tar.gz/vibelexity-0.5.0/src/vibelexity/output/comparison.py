"""Delta formatting utilities for vibelexity baseline comparison."""

from __future__ import annotations

from rich.text import Text


def _safe_get(d: dict, *keys, default=0):
    """Safely traverse nested dict keys."""
    val = d
    for k in keys:
        if isinstance(val, dict):
            val = val.get(k, default)
        else:
            return default
    return val if val is not None else default


def delta_text(baseline_val, current_val, higher_is_worse: bool) -> Text:
    """Create a styled delta text with arrow for inline display.

    higher_is_worse=True:  increase is bad (red ↑), decrease is good (green ↓)
    higher_is_worse=False: decrease is bad (red ↓), increase is good (green ↑)

    Returns styled Text. Never returns empty — shows ±0 when unchanged.
    """
    delta = current_val - baseline_val
    if abs(delta) < 0.005:
        return Text(" ±0", style="dim")

    if isinstance(delta, float):
        delta_str = f"{delta:+,.2f}"
    else:
        delta_str = f"{delta:+,}"

    if higher_is_worse:
        style = "bold red" if delta > 0 else "bold green"
        arrow = "↑" if delta > 0 else "↓"
    else:
        style = "bold red" if delta < 0 else "bold green"
        arrow = "↓" if delta < 0 else "↑"

    return Text(f" {arrow}{delta_str}", style=style)
