"""Rich table output formatting for vibelexity."""

from __future__ import annotations

import os
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.table import Column, Table
from rich.text import Text

from vibelexity import thresholds
from vibelexity.analysis import (
    _aggregate_cognitive,
    _aggregate_cyclomatic,
    _aggregate_dtd,
    _aggregate_ldi,
    _aggregate_mi,
    _aggregate_npath,
    _build_candidate_lists,
    _compute_stats,
    _find_refactor_candidates,
    _get_metric_val,
)
from vibelexity.output.comparison import _safe_get, delta_text

console = Console(soft_wrap=True, width=120)


def _osc8_link(path: str, line: int | None = None) -> str:
    """Return visible text formatted as an OSC 8 terminal hyperlink.

    The link target is a ``file://`` URL pointing to the absolute path.
    When *line* is given the visible label is ``path:line`` and the URL
    carries a ``#line=<n>`` fragment so supporting editors (e.g. VS Code,
    JetBrains) jump directly to that line.
    """
    abs_path = os.path.abspath(path)
    label = f"{path}:{line}" if line is not None else path
    fragment = f"#line={line}" if line is not None else ""
    url = f"file://{abs_path}{fragment}"
    ESC = "\x1b"
    ST = "\x1b\\"
    return f"{ESC}]8;;{url}{ST}{label}{ESC}]8;;{ST}"


def _osc8_link_text(path: str, line: int | None = None, style: str = "dim") -> Text:
    """Return a Rich Text object with an OSC 8 file:// hyperlink.

    Suitable for use inside Rich tables and panels where raw ANSI escapes
    cannot be embedded directly.
    """
    abs_path = os.path.abspath(path)
    label = f"{path}:{line}" if line is not None else path
    fragment = f"#line={line}" if line is not None else ""
    url = f"file://{abs_path}{fragment}"
    return Text.from_markup(f"[{style}][link={url}]{label}[/link][/{style}]")


_PADDING_STATISTICS = (0, 4, 0, 4)  # top, right, bottom, left
_PADDING = (0, 1, 0, 1)  # top, right, bottom, left


_METRIC_SECTIONS = [
    (
        "Cognitive complexity",
        "Cognitive",
        _aggregate_cognitive,
        "complexity",
        thresholds.COGNITIVE_COMPLEXITY_THRESHOLD,
        "higher",
    ),
    (
        "NPath complexity",
        "NPath",
        _aggregate_npath,
        "npath",
        thresholds.NPATH_THRESHOLD,
        "higher",
    ),
    (
        "Data Transformation Density (DTD)",
        "DTD",
        _aggregate_dtd,
        "dtd",
        thresholds.DTD_THRESHOLD,
        "higher",
    ),
    (
        "Cyclomatic complexity",
        "Cyclomatic",
        _aggregate_cyclomatic,
        "cyclomatic",
        thresholds.CYCLOMATIC_THRESHOLD,
        "higher",
    ),
    (
        "Maintainability Index (MI)",
        "MI",
        _aggregate_mi,
        "mi",
        thresholds.MI_RED_THRESHOLD,
        "lower",
    ),
    (
        "Logic Density Index (LDI)",
        "LDI",
        _aggregate_ldi,
        "ldi",
        thresholds.LDI_THRESHOLD,
        "higher",
    ),
]


def _format_number(value: int | float, compact: bool = False) -> str:
    """Format a number with compact or standard format."""
    if compact and value >= 100_000 and value < 1_000_000:
        scaled = value / 1_000
        return f"{scaled:.1f} × 10³"
    if compact and value >= 1_000_000:
        return "∞"
    return f"{value:,.2f}" if isinstance(value, float) else f"{value:,}"


def _get_cell_style(value, threshold, mode="higher") -> str:
    """Get appropriate style for a cell based on threshold."""
    if threshold == 0:
        return "green"
    if mode == "higher":
        return "bold red" if value > threshold else "green"
    else:
        return "bold red" if value < threshold else "green"


def _format_value_with_threshold(
    value: int | float, threshold: int | float, mode: str, compact: bool = False
) -> Text:
    """Format a metric value with colour based on threshold."""
    style = _get_cell_style(value, threshold, mode)
    return Text(_format_number(value, compact), style=style)


def _append_delta(
    cell: Text,
    current_val,
    baseline_key_path: tuple,
    baseline: dict | None,
    higher_is_worse: bool,
) -> Text:
    """Append an inline delta annotation to an existing cell if baseline is present."""
    if baseline is None:
        return cell
    baseline_val = _safe_get(baseline, *baseline_key_path)
    dt = delta_text(baseline_val, current_val, higher_is_worse)
    return Text.assemble(cell, dt)


def print_summary_table(results, all_funcs, total_loc, baseline=None):
    """Print module/function count and line-metric summary."""
    table = Table.grid(padding=(0, 2), expand=True)
    table.add_column(justify="right", style="bold cyan")
    table.add_column()

    analyzed_text = Text(
        f"{len(results)} modules, {len(all_funcs)} functions", style="bold"
    )
    loc_text = Text(f"{total_loc:,}", style="bold green")
    funcs_text = Text(f"{len(all_funcs)}", style="bold green")

    if baseline:
        analyzed_text.append(
            delta_text(
                _safe_get(baseline, "modules_analyzed"),
                len(results),
                higher_is_worse=True,
            )
        )
        loc_text.append(
            delta_text(
                _safe_get(baseline, "total_loc"), total_loc, higher_is_worse=True
            )
        )
        funcs_text.append(
            delta_text(
                _safe_get(baseline, "total_functions"),
                len(all_funcs),
                higher_is_worse=True,
            )
        )

    table.add_row("Analyzed", analyzed_text)
    table.add_row("Total lines:", loc_text)
    table.add_row("Total functions:", funcs_text)

    console.print()
    console.print(table)

    if baseline:
        short_hash = baseline.get("commit_hash", "")[:7]
        if short_hash:
            console.print(
                Text(
                    f"  Comparing against baseline: commit {short_hash}",
                    style="dim cyan",
                )
            )


def print_statistics_table(results, all_funcs, baseline=None):
    """Print complexity, NPath, DTD, cyclomatic, MI, and LDI distributions."""
    console.print()

    has_delta = baseline is not None
    title_suffix = " (Δ vs baseline)" if has_delta else ""

    table = Table(
        title=Text(f"Statistics{title_suffix}", style="bold cyan"),
        box=None,
        show_header=True,
        show_edge=False,
        show_lines=True,
        header_style="bold yellow",
        pad_edge=True,
        padding=_PADDING_STATISTICS,
    )

    table.add_column("Metric")
    table.add_column("Average", justify="right")
    table.add_column("Median", justify="right")
    table.add_column("P95", justify="right")
    table.add_column("P99", justify="right")

    # Map from agg_fn to cache dict key for baseline lookups
    _AGG_TO_CACHE_KEY = {
        _aggregate_cognitive: "cognitive",
        _aggregate_npath: "npath",
        _aggregate_dtd: "dtd",
        _aggregate_cyclomatic: "cyclomatic",
        _aggregate_mi: "mi",
        _aggregate_ldi: "ldi",
    }

    for title, _, agg_fn, metric_name, threshold, threshold_mode in _METRIC_SECTIONS:
        agg = agg_fn(results)
        use_compact = agg_fn == _aggregate_npath
        higher_is_worse = threshold_mode == "higher"
        cache_key = _AGG_TO_CACHE_KEY.get(agg_fn, metric_name)

        avg_cell = _format_value_with_threshold(
            agg["stats"]["average"], threshold, threshold_mode, use_compact
        )
        avg_cell = _append_delta(
            avg_cell,
            agg["stats"]["average"],
            (cache_key, "stats", "average"),
            baseline,
            higher_is_worse,
        )

        median_cell = _format_value_with_threshold(
            agg["stats"]["median"], threshold, threshold_mode, use_compact
        )
        median_cell = _append_delta(
            median_cell,
            agg["stats"]["median"],
            (cache_key, "stats", "median"),
            baseline,
            higher_is_worse,
        )

        p95_cell = _format_value_with_threshold(
            agg["stats"]["p95"], threshold, threshold_mode, use_compact
        )
        p95_cell = _append_delta(
            p95_cell,
            agg["stats"]["p95"],
            (cache_key, "stats", "p95"),
            baseline,
            higher_is_worse,
        )

        p99_cell = _format_value_with_threshold(
            agg["stats"]["p99"], threshold, threshold_mode, use_compact
        )
        p99_cell = _append_delta(
            p99_cell,
            agg["stats"]["p99"],
            (cache_key, "stats", "p99"),
            baseline,
            higher_is_worse,
        )

        table.add_row(Text(title), avg_cell, median_cell, p95_cell, p99_cell)

    table.add_section()
    table.add_row(Text(""), Text(""), Text(""), Text(""), Text(""))
    table.add_section()

    loc_stats = _compute_stats([r.loc for r in results])
    lloc_stats = _compute_stats([r.lloc for r in results])
    sloc_stats = _compute_stats([r.sloc for r in results])

    for name, stats, cache_key in [
        ("Lines per module → LOC", loc_stats, "loc_stats"),
        ("Lines per module → LLOC", lloc_stats, "lloc_stats"),
        ("Lines per module → SLOC", sloc_stats, "sloc_stats"),
    ]:
        avg_cell = Text(f"{stats['average']:.2f}", style="green")
        avg_cell = _append_delta(
            avg_cell,
            stats["average"],
            (cache_key, "average"),
            baseline,
            higher_is_worse=True,
        )
        median_cell = Text(f"{stats['median']:.2f}", style="green")
        median_cell = _append_delta(
            median_cell,
            stats["median"],
            (cache_key, "median"),
            baseline,
            higher_is_worse=True,
        )
        p95_cell = Text(f"{stats['p95']:.2f}", style="green")
        p95_cell = _append_delta(
            p95_cell, stats["p95"], (cache_key, "p95"), baseline, higher_is_worse=True
        )
        p99_cell = Text(f"{stats['p99']:.2f}", style="green")
        p99_cell = _append_delta(
            p99_cell, stats["p99"], (cache_key, "p99"), baseline, higher_is_worse=True
        )
        table.add_row(
            Text(name, style="dim cyan"), avg_cell, median_cell, p95_cell, p99_cell
        )

    console.print(table)
    console.print()


def _count_with_delta(
    label: str,
    current_val: int,
    baseline_key: str | tuple,
    baseline: dict | None,
    higher_is_worse: bool = True,
) -> Text:
    """Create a 'Label: value Δ' text for count-style rows."""
    parts = [
        Text(f"{label}: ", style="yellow"),
        Text(f"{current_val}", style="green"),
    ]
    if baseline is not None:
        key_path = baseline_key if isinstance(baseline_key, tuple) else (baseline_key,)
        baseline_val = _safe_get(baseline, *key_path)
        parts.append(delta_text(baseline_val, current_val, higher_is_worse))
    return Text.assemble(*parts)


def print_pattern_violations_table(results, show_bad_patterns=False, baseline=None):
    """Print pattern violations."""
    all_violations = []
    for result in results:
        for violation in result.pattern_violations:
            all_violations.append(
                (result.path, violation.line, violation.type, violation.description)
            )

    if not all_violations:
        console.print(Text("Pattern violations: None", style="bold cyan"))
        return

    violations_by_type = defaultdict(list)
    for path, line, v_type, description in all_violations:
        violations_by_type[v_type].append((path, line, description))

    type_counts = {
        v_type: len(violations) for v_type, violations in violations_by_type.items()
    }

    console.print()

    if show_bad_patterns:
        for v_type in sorted(type_counts.keys()):
            label = v_type.replace("_", " ").title()
            table = Table(
                box=None,
                show_header=False,
                show_edge=False,
                pad_edge=True,
                padding=_PADDING,
            )
            table.add_column()
            table.add_row(Text(f"{label}: {type_counts[v_type]}", style="bold yellow"))
            console.print(table)

            for path, line, description in violations_by_type[v_type]:
                loc_link = _osc8_link(path, line)
                print(f"  {loc_link:<70} {description}")
    else:
        table = Table(
            title=Text("Pattern violations", style="bold cyan"),
            box=None,
            show_header=True,
            show_edge=False,
            header_style="bold yellow",
            padding=_PADDING,
        )
        table.add_column("Type")
        table.add_column("Count", justify="right")

        total_text = Text.assemble(Text(f"{len(all_violations)}", style="green"))
        if baseline is not None:
            baseline_val = _safe_get(baseline, "pattern_violations_count")
            total_text.append(
                delta_text(baseline_val, len(all_violations), higher_is_worse=True)
            )

        table.add_row(
            Text("Total violations", style="yellow"),
            total_text,
        )

        bl_by_type = (
            _safe_get(baseline, "pattern_violations_by_type")
            if baseline is not None
            else None
        )

        for v_type in sorted(type_counts.keys()):
            label = v_type.replace("_", " ").title()
            count_text = Text(str(type_counts[v_type]), style="green")
            if bl_by_type is not None and isinstance(bl_by_type, dict):
                bl_count = bl_by_type.get(v_type, 0)
                count_text.append(
                    delta_text(bl_count, type_counts[v_type], higher_is_worse=True)
                )
            table.add_row(Text(label), count_text)

        console.print(table)
        console.print(Text("Use --show-bad-patterns to see the full list", style="dim"))


def print_duplication_table(
    duplicates,
    show_dupes=False,
    dup_stats=None,
    all_funcs=None,
    total_loc=None,
    baseline=None,
):
    """Print duplication clusters."""
    type1 = sorted(
        [c for c in duplicates if c.dup_type == 1],
        key=lambda c: len(c.members),
        reverse=True,
    )
    type2 = sorted(
        [c for c in duplicates if c.dup_type == 2],
        key=lambda c: len(c.members),
        reverse=True,
    )

    console.print()

    table = Table(
        title=Text("Code duplication", style="bold cyan"),
        box=None,
        show_header=False,
        show_edge=False,
        pad_edge=True,
        padding=_PADDING,
    )
    table.add_column()

    t1_text = Text(f"Type 1 (exact clones): {len(type1)} cluster(s)", style="yellow")
    if baseline is not None:
        t1_text.append(
            delta_text(
                _safe_get(baseline, "type1_clusters"), len(type1), higher_is_worse=True
            )
        )
    table.add_row(t1_text)

    t2_text = Text(
        f"Type 2 (parametric clones): {len(type2)} cluster(s)", style="yellow"
    )
    if baseline is not None:
        t2_text.append(
            delta_text(
                _safe_get(baseline, "type2_clusters"), len(type2), higher_is_worse=True
            )
        )
    table.add_row(t2_text)

    if dup_stats and all_funcs and total_loc is not None:
        table.add_row(Text())

        t1_lines_text = Text(
            f"  Type 1 lines: {dup_stats['type1_duplicate_lines']}/{total_loc} ({dup_stats['type1_duplicate_lines_pct']:.1f}%)",
            style="yellow",
        )
        if baseline is not None:
            bl_pct = _safe_get(baseline, "duplication", "type1_duplicate_lines_pct")
            t1_lines_text.append(
                delta_text(
                    bl_pct, dup_stats["type1_duplicate_lines_pct"], higher_is_worse=True
                )
            )
        table.add_row(t1_lines_text)

        t1_funcs_text = Text(
            f"  Type 1 functions: {dup_stats['type1_duplicate_functions']}/{len(all_funcs)} ({dup_stats['type1_duplicate_functions_pct']:.1f}%)",
            style="yellow",
        )
        if baseline is not None:
            bl_pct = _safe_get(baseline, "duplication", "type1_duplicate_functions_pct")
            t1_funcs_text.append(
                delta_text(
                    bl_pct,
                    dup_stats["type1_duplicate_functions_pct"],
                    higher_is_worse=True,
                )
            )
        table.add_row(t1_funcs_text)

        table.add_row(Text())

        t2_lines_text = Text(
            f"  Type 2 lines: {dup_stats['type2_duplicate_lines']}/{total_loc} ({dup_stats['type2_duplicate_lines_pct']:.1f}%)",
            style="yellow",
        )
        if baseline is not None:
            bl_pct = _safe_get(baseline, "duplication", "type2_duplicate_lines_pct")
            t2_lines_text.append(
                delta_text(
                    bl_pct, dup_stats["type2_duplicate_lines_pct"], higher_is_worse=True
                )
            )
        table.add_row(t2_lines_text)

        t2_funcs_text = Text(
            f"  Type 2 functions: {dup_stats['type2_duplicate_functions']}/{len(all_funcs)} ({dup_stats['type2_duplicate_functions_pct']:.1f}%)",
            style="yellow",
        )
        if baseline is not None:
            bl_pct = _safe_get(baseline, "duplication", "type2_duplicate_functions_pct")
            t2_funcs_text.append(
                delta_text(
                    bl_pct,
                    dup_stats["type2_duplicate_functions_pct"],
                    higher_is_worse=True,
                )
            )
        table.add_row(t2_funcs_text)

    console.print(table)

    if show_dupes and duplicates:
        for cluster in type1 + type2:
            kind = "Type 1 (exact)" if cluster.dup_type == 1 else "Type 2 (parametric)"
            console.print()
            console.print(
                Text(f"  {kind} - {len(cluster.members)} functions:", style="yellow")
            )
            for fpath, func in cluster.members:
                print(f"    {_osc8_link(fpath, func.line)} {func.name}")
    elif not show_dupes:
        console.print(Text("Use --show-dupes to see the full list", style="dim"))


def print_dead_code_table(dead_code_violations, show_dead=False, baseline=None):
    """Print dead code violations summary by type."""
    type_counts = defaultdict(int)
    for v in dead_code_violations:
        type_counts[v.type] += 1

    labels = {
        "unused_import": "Unused imports",
        "dead_function": "Dead functions",
        "dead_class": "Dead classes",
        "unused_local_var": "Unused local variables",
    }

    total = len(dead_code_violations)

    console.print()

    table = Table(
        title=Text("Dead code violations", style="bold cyan"),
        box=None,
        show_header=False,
        show_edge=False,
        pad_edge=True,
        padding=_PADDING,
    )
    table.add_column()

    table.add_row(
        _count_with_delta(
            "Total violations", total, "dead_code_violations_count", baseline
        )
    )

    bl_dc_by_type = (
        _safe_get(baseline, "dead_code_by_type") if baseline is not None else None
    )

    for v_type in sorted(type_counts.keys()):
        label = labels.get(v_type, v_type.replace("_", " ").title())
        count_text = Text.assemble(
            Text(f"{label}: ", style="yellow"),
            Text(f"{type_counts[v_type]}", style="green"),
        )
        if bl_dc_by_type is not None and isinstance(bl_dc_by_type, dict):
            bl_count = bl_dc_by_type.get(v_type, 0)
            count_text.append(
                delta_text(bl_count, type_counts[v_type], higher_is_worse=True)
            )
        table.add_row(count_text)

    console.print(table)

    if show_dead:
        for v in dead_code_violations:
            loc_path = getattr(v, "path", None) or getattr(v, "location", "")
            loc_line = getattr(v, "line", None)
            loc = (
                _osc8_link(loc_path, loc_line)
                if loc_line is not None
                else _osc8_link(loc_path)
            )
            print(f"  {loc} - {v.type}")
    if not show_dead:
        console.print(Text("Use --show-dead to see the full list", style="dim"))


def print_fatness_table(fatness_report, show_fatties=False, baseline=None):
    """Print fatness metrics - files/functions that exceed size thresholds."""
    wide_functions = [f for f in fatness_report.fat_functions if f["param_count"] > 5]
    save_world_functions = [
        f for f in fatness_report.fat_functions if f["call_count"] > 7
    ]

    console.print()

    table = Table(
        title=Text("Fatness metrics", style="bold cyan"),
        box=None,
        show_header=False,
        show_edge=False,
        pad_edge=True,
        padding=_PADDING,
    )
    table.add_column()

    table.add_row(
        _count_with_delta(
            "Fat files", len(fatness_report.fat_files), "fat_files_count", baseline
        )
    )
    table.add_row(
        _count_with_delta(
            "Fat functions",
            len(fatness_report.fat_functions),
            "fat_functions_count",
            baseline,
        )
    )
    table.add_row(
        _count_with_delta(
            "Wide functions (>5 params)",
            len(wide_functions),
            "wide_functions_count",
            baseline,
        )
    )
    table.add_row(
        _count_with_delta(
            "Save the world functions (>7 calls)",
            len(save_world_functions),
            "save_the_world_count",
            baseline,
        )
    )

    console.print(table)

    if show_fatties:
        if fatness_report.fat_files:
            console.print()
            console.print(
                Text("Fat files (>500 LOC or >20 functions):", style="yellow")
            )
            for file_info in fatness_report.fat_files:
                print(f"    {_osc8_link(file_info['path'])} - {file_info['reason']}")

        if fatness_report.fat_functions:
            console.print()
            console.print(
                Text("Fat functions (>50 LOC, >5 params, or >7 calls):", style="yellow")
            )
            for func_info in fatness_report.fat_functions:
                print(
                    f"    {_osc8_link(func_info['path'], func_info['line'])} {func_info['name']} - {func_info['reason']}"
                )

    if not show_fatties:
        console.print(Text("Use --show-fatties to see the full list", style="dim"))


def print_refactor_candidates_table(candidate_lists):
    """Print top 10 refactor candidates."""
    candidates, func_lookup, thresholds_map = _find_refactor_candidates(candidate_lists)

    if not candidates:
        console.print(Text("Top 10 Refactor Candidates:", style="bold cyan"))
        console.print(Text("No refactor candidates found", style="dim"))
        return

    console.print(Text("Top 10 Refactor Candidates:", style="bold cyan"))

    table = Table(
        box=None,
        show_header=True,
        show_edge=False,
        show_lines=True,
        header_style="bold yellow",
        padding=_PADDING,
        expand=False,
    )
    table.add_column("Violation", width=50, overflow="fold")
    table.add_column("Location - Function Name", overflow="fold")

    for key, names in candidates[:10]:
        fpath, func = func_lookup[key]
        violation_parts = []
        for n in names:
            val = _get_metric_val(func, n)
            thresh = thresholds_map.get(n, 0)
            op = "<" if n == "mi" else ">"
            val_fmt = _format_number(val, n == "npath")
            thresh_fmt = _format_number(thresh, n == "npath")

            if n == "mi":
                violates = val < thresh
                val_style = "bold red" if violates else "green"
            else:
                violates = val > thresh
                val_style = "bold red" if violates else "green"

            violation_parts.append(
                Text.assemble(
                    Text(f"{n}: ", style="dim"),
                    Text(val_fmt, style=val_style),
                    Text(f" ({op} ", style="dim"),
                    Text(thresh_fmt, style="dim"),
                    Text(")", style="dim"),
                )
            )

        if violation_parts:
            violations_text = Text()
            for i, part in enumerate(violation_parts):
                if i > 0:
                    violations_text.append(", ")
                violations_text.append(part)
        else:
            violations_text = Text("")

        loc_text = _osc8_link_text(fpath, func.line)
        loc_text.append(f" - {func.name}", style="dim")
        table.add_row(violations_text, loc_text)

    console.print(table)


def print_worst_metrics_table(metric_name, all_funcs, limit=10):
    """Print worst N metric scores for a specific metric."""
    reverse = metric_name != "mi"

    metric_labels = {
        "complexity": "Cognitive Complexity",
        "npath": "NPath Complexity",
        "dtd": "Data Transformation Density",
        "cyclomatic": "Cyclomatic Complexity",
        "mi": "Maintainability Index",
        "ldi": "Logic Density Index",
    }

    title = f"Worst {limit} {metric_labels.get(metric_name, metric_name)}"

    console.print()

    sorted_funcs = sorted(
        all_funcs, key=lambda x: _get_metric_val(x[1], metric_name), reverse=reverse
    )[:limit]

    max_loc_len = (
        max(len(f"{fpath}:{func.line}") for fpath, func in sorted_funcs)
        if sorted_funcs
        else 0
    )

    table = Table(
        title=Text(title, style="bold cyan"),
        box=None,
        show_header=True,
        show_edge=False,
        show_lines=True,
        header_style="bold yellow",
        padding=_PADDING,
        expand=True,
    )
    table.add_column("Value", width=6, overflow="fold")
    table.add_column("Location - Function Name", overflow="fold")

    for fpath, func in sorted_funcs:
        val = _get_metric_val(func, metric_name)
        val_str = _format_number(val, metric_name == "npath")
        style = (
            "bold red"
            if (
                (metric_name != "mi" and val > thresholds.NPATH_THRESHOLD)
                or (metric_name == "mi" and val < thresholds.MI_RED_THRESHOLD)
            )
            else "green"
        )

        loc_text = _osc8_link_text(fpath, func.line)
        loc_text.append(f" - {func.name}", style="dim")
        table.add_row(Text(val_str, style=style), loc_text)

    console.print(table)


def print_cycle_stats_table(cycle_stats, show_circulars=False, baseline=None):
    """Print circular import cycle statistics."""
    num_runtime = cycle_stats.get("num_runtime_cycles", 0)
    num_type = cycle_stats.get("num_type_cycles", 0)
    runtime_stats = cycle_stats.get("runtime_cycle_length_stats", _compute_stats([]))
    type_stats = cycle_stats.get("type_cycle_length_stats", _compute_stats([]))

    console.print()
    console.print(Text("Circular import cycles:", style="bold cyan"))

    table = Table(
        box=None,
        show_header=False,
        show_edge=False,
        pad_edge=True,
        padding=_PADDING,
    )
    table.add_column()

    table.add_row(
        _count_with_delta("Runtime cycles", num_runtime, "num_runtime_cycles", baseline)
    )

    if num_runtime > 0:
        stats_str = (
            f"Avg: {runtime_stats['average']:.2f}, Median: {runtime_stats['median']:.2f}, "
            f"P95: {runtime_stats['p95']:.2f}, P99: {runtime_stats['p99']:.2f}"
        )
        table.add_row(Text(f"  {stats_str}", style="green"))

    table.add_row(
        _count_with_delta(
            "Cycles with type imports", num_type, "num_type_cycles", baseline
        )
    )

    if num_type > 0:
        stats_str = (
            f"Avg: {type_stats['average']:.2f}, Median: {type_stats['median']:.2f}, "
            f"P95: {type_stats['p95']:.2f}, P99: {type_stats['p99']:.2f}"
        )
        table.add_row(Text(f"  {stats_str}", style="green"))

    console.print(table)

    if show_circulars and (num_runtime > 0 or num_type > 0):
        runtime_cycles = cycle_stats.get("runtime_cycles", [])
        type_cycles = cycle_stats.get("type_cycles", [])

        if runtime_cycles:
            console.print()
            console.print(Text("Runtime cycles:", style="yellow"))
            for cycle in runtime_cycles:
                rel_paths = _make_relative_paths(cycle.files)
                cycle_str = _format_cycle(rel_paths, cycle.depth)
                console.print(f"  {cycle_str} (length: {cycle.depth})")

        if type_cycles:
            console.print()
            console.print(Text("Cycles with type imports:", style="yellow"))
            for cycle in type_cycles:
                rel_paths = _make_relative_paths(cycle.files)
                cycle_str = _format_cycle(rel_paths, cycle.depth)
                console.print(f"  {cycle_str} (length: {cycle.depth})")
    elif not show_circulars:
        console.print(Text("Use --show-circulars to see cycle details", style="dim"))


def _make_relative_paths(paths: list[str]) -> list[str]:
    """Convert absolute paths to relative paths from current working directory."""
    result = []
    for p in paths:
        try:
            rel = os.path.relpath(p)
            result.append(rel)
        except ValueError:
            result.append(p)
    return result


def _format_cycle(paths: list[str], depth: int) -> str:
    """Format a cycle for display.

    - If < 5 modules: show A -> B -> C
    - If >= 5 modules: show A -> ... -> C
    """
    if depth < 5:
        return " -> ".join(paths)
    else:
        return f"{paths[0]} -> ... -> {paths[-1]}"


# Mapping from cached dict metric keys to display config
# (title, dict_key, threshold, threshold_mode, use_compact)
_CACHED_METRIC_SECTIONS = [
    (
        "Cognitive complexity",
        "cognitive",
        thresholds.COGNITIVE_COMPLEXITY_THRESHOLD,
        "higher",
        False,
    ),
    ("NPath complexity", "npath", thresholds.NPATH_THRESHOLD, "higher", True),
    (
        "Data Transformation Density (DTD)",
        "dtd",
        thresholds.DTD_THRESHOLD,
        "higher",
        False,
    ),
    (
        "Cyclomatic complexity",
        "cyclomatic",
        thresholds.CYCLOMATIC_THRESHOLD,
        "higher",
        False,
    ),
    ("Maintainability Index (MI)", "mi", thresholds.MI_RED_THRESHOLD, "lower", False),
    ("Logic Density Index (LDI)", "ldi", thresholds.LDI_THRESHOLD, "higher", False),
]


def print_cached_summary_table(aggregate: dict, commit_hash: str = "") -> None:
    """Render cached aggregate dict as summary + statistics tables."""
    short_hash = commit_hash[:7] if commit_hash else "unknown"
    console.print()
    console.print(Text(f"Cached results for commit {short_hash}", style="bold cyan"))

    # Summary grid
    table = Table.grid(padding=(0, 2), expand=True)
    table.add_column(justify="right", style="bold cyan")
    table.add_column()

    modules = aggregate.get("modules_analyzed", 0)
    total_funcs = aggregate.get("total_functions", 0)
    total_loc = aggregate.get("total_loc", 0)

    table.add_row(
        "Analyzed",
        Text(f"{modules} modules, {total_funcs} functions", style="bold"),
    )
    table.add_row("Total lines:", Text(f"{total_loc:,}", style="bold green"))
    table.add_row("Total functions:", Text(f"{total_funcs}", style="bold green"))

    console.print()
    console.print(table)

    # Statistics table
    console.print()

    stats_table = Table(
        title=Text("Statistics", style="bold cyan"),
        box=None,
        show_header=True,
        show_edge=False,
        show_lines=True,
        header_style="bold yellow",
        pad_edge=True,
        padding=_PADDING_STATISTICS,
    )

    stats_table.add_column("Metric")
    stats_table.add_column("Average", justify="right")
    stats_table.add_column("Median", justify="right")
    stats_table.add_column("P95", justify="right")
    stats_table.add_column("P99", justify="right")

    for title, key, threshold, mode, use_compact in _CACHED_METRIC_SECTIONS:
        metric_data = aggregate.get(key, {})
        stats = metric_data.get(
            "stats", {"average": 0, "median": 0, "p95": 0, "p99": 0}
        )

        avg_cell = _format_value_with_threshold(
            stats["average"], threshold, mode, use_compact
        )
        median_cell = _format_value_with_threshold(
            stats["median"], threshold, mode, use_compact
        )
        p95_cell = _format_value_with_threshold(
            stats["p95"], threshold, mode, use_compact
        )
        p99_cell = _format_value_with_threshold(
            stats["p99"], threshold, mode, use_compact
        )

        stats_table.add_row(Text(title), avg_cell, median_cell, p95_cell, p99_cell)

    stats_table.add_section()
    stats_table.add_row(Text(""), Text(""), Text(""), Text(""), Text(""))
    stats_table.add_section()

    for name, stats_key in [
        ("Lines per module → LOC", "loc_stats"),
        ("Lines per module → LLOC", "lloc_stats"),
        ("Lines per module → SLOC", "sloc_stats"),
    ]:
        stats = aggregate.get(
            stats_key, {"average": 0, "median": 0, "p95": 0, "p99": 0}
        )
        stats_table.add_row(
            Text(name, style="dim cyan"),
            Text(f"{stats['average']:.2f}", style="green"),
            Text(f"{stats['median']:.2f}", style="green"),
            Text(f"{stats['p95']:.2f}", style="green"),
            Text(f"{stats['p99']:.2f}", style="green"),
        )

    console.print(stats_table)
    console.print()

    # Cycle stats
    num_cycles = aggregate.get("num_cycles", 0)
    cycle_stats = aggregate.get(
        "cycle_length_stats", {"average": 0, "median": 0, "p95": 0, "p99": 0}
    )

    console.print(Text("Circular import cycles:", style="bold cyan"))

    cycle_table = Table(
        box=None,
        show_header=False,
        show_edge=False,
        pad_edge=True,
        padding=_PADDING,
    )
    cycle_table.add_column()
    cycle_table.add_row(
        Text(f"Number of cycles detected: {num_cycles}", style="yellow")
    )

    if num_cycles > 0:
        stats_str = (
            f"Avg: {cycle_stats['average']:.2f}, Median: {cycle_stats['median']:.2f}, "
            f"P95: {cycle_stats['p95']:.2f}, P99: {cycle_stats['p99']:.2f}"
        )
        cycle_table.add_row(
            Text("Cycle length statistics (nodes per cycle):", style="yellow")
        )
        cycle_table.add_row(Text(f"  {stats_str}", style="green"))

    console.print(cycle_table)

    # Count summaries
    console.print()

    counts_table = Table(
        title=Text("Counts (from cache)", style="bold cyan"),
        box=None,
        show_header=False,
        show_edge=False,
        pad_edge=True,
        padding=_PADDING,
    )
    counts_table.add_column()

    pv = aggregate.get("pattern_violations_count", 0)
    dc = aggregate.get("dead_code_violations_count", 0)
    ff = aggregate.get("fat_files_count", 0)
    ffn = aggregate.get("fat_functions_count", 0)

    counts_table.add_row(
        Text.assemble(
            Text("Pattern violations: ", style="yellow"), Text(f"{pv}", style="green")
        )
    )
    counts_table.add_row(
        Text.assemble(
            Text("Dead code violations: ", style="yellow"), Text(f"{dc}", style="green")
        )
    )
    counts_table.add_row(
        Text.assemble(Text("Fat files: ", style="yellow"), Text(f"{ff}", style="green"))
    )
    counts_table.add_row(
        Text.assemble(
            Text("Fat functions: ", style="yellow"), Text(f"{ffn}", style="green")
        )
    )

    dup = aggregate.get("duplication", {})
    dup_funcs_pct = dup.get("duplicate_functions_pct", 0.0)
    dup_lines_pct = dup.get("duplicate_lines_pct", 0.0)
    counts_table.add_row(
        Text.assemble(
            Text("Duplicate functions: ", style="yellow"),
            Text(f"{dup_funcs_pct:.1f}%", style="green"),
        )
    )
    counts_table.add_row(
        Text.assemble(
            Text("Duplicate lines: ", style="yellow"),
            Text(f"{dup_lines_pct:.1f}%", style="green"),
        )
    )

    console.print(counts_table)
