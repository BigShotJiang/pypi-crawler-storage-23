"""Shared parsed-file context for multi-analysis runs."""

from __future__ import annotations

from pathlib import Path

from vibelexity.models import ParsedFile
from vibelexity.parsers.go import parse as parse_go
from vibelexity.parsers.python import parse as parse_python
from vibelexity.parsers.typescript import parse as parse_typescript

_PY_EXTENSIONS = {".py"}
_TS_EXTENSIONS = {".ts", ".tsx", ".js", ".jsx"}
_GO_EXTENSIONS = {".go"}


def _detect_language(filepath: str | Path) -> str | None:
    ext = Path(filepath).suffix.lower()
    if ext in _PY_EXTENSIONS:
        return "python"
    if ext in _TS_EXTENSIONS:
        return "typescript"
    if ext in _GO_EXTENSIONS:
        return "go"
    return None


def _is_tsx(filepath: str | Path) -> bool:
    return Path(filepath).suffix.lower() in {".tsx", ".jsx"}


def build_parsed_files(filepaths: list[Path] | list[str]) -> dict[str, ParsedFile]:
    """Build a shared parse context keyed by absolute file path."""
    parsed: dict[str, ParsedFile] = {}

    for filepath in filepaths:
        path = Path(filepath)
        abs_path = str(path.resolve())
        lang = _detect_language(path)
        if lang is None:
            continue

        source = path.read_text()

        try:
            if lang == "python":
                root = parse_python(source)
                tsx = False
            elif lang == "typescript":
                tsx = _is_tsx(path)
                root = parse_typescript(source, tsx=tsx)
            else:
                root = parse_go(source)
                tsx = False
        except Exception:
            continue

        parsed[abs_path] = ParsedFile(
            path=str(path),
            abs_path=abs_path,
            lang=lang,
            source=source,
            root=root,
            tsx=tsx,
        )

    return parsed
