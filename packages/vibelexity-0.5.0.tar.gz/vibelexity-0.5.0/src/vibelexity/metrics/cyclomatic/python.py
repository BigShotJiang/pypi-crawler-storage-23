"""McCabe cyclomatic complexity for Python."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from tree_sitter import Node

import vibelexity.metrics.cyclomatic.shared as shared

_PY_DECISION_TYPES = {
    "if_statement",
    "elif_clause",
    "for_statement",
    "while_statement",
    "except_clause",
    "conditional_expression",
    "case_clause",
    "boolean_operator",
}


def _py_skip_check(child: Node, top_func: Node) -> bool:
    """Skip nested function/class definitions."""
    if child.type == "function_definition" and child is not top_func:
        return True
    if child.type == "class_definition":
        return True
    if child.type == "decorated_definition":
        return True
    return False


def _count_decisions(node: Node, top_func: Node) -> int:
    return shared.count_decisions_generic(
        node, top_func, _py_skip_check, _PY_DECISION_TYPES, None
    )


compute_cyclomatic_py = shared.compute_cyclomatic_generic(_count_decisions)
