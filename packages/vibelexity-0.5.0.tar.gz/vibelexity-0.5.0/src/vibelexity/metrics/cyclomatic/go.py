"""McCabe cyclomatic complexity for Go."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from tree_sitter import Node

from vibelexity.parsers.go import is_named_func_literal
import vibelexity.metrics.cyclomatic.shared as shared

_GO_DECISION_TYPES = {
    "if_statement",
    "for_statement",
    "expression_case",
    "type_case",
    "communication_case",
}

_GO_LOGICAL_OPS = {"&&", "||"}


def _go_skip_check(child: Node, top_func: Node) -> bool:
    """Skip nested function/method declarations."""
    if (
        child.type in ("function_declaration", "method_declaration")
        and child is not top_func
    ):
        return True
    if child.type == "func_literal" and child is not top_func:
        return is_named_func_literal(child)
    return False


def _count_decisions(node: Node, top_func: Node) -> int:
    return shared.count_decisions_generic(
        node, top_func, _go_skip_check, _GO_DECISION_TYPES, _GO_LOGICAL_OPS
    )


compute_cyclomatic_go = shared.compute_cyclomatic_generic(_count_decisions)
