"""TypeScript parameter counter for fatness metrics."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from tree_sitter import Node


def param_count(func_node: Node) -> int:
    """Count parameters in a TypeScript function node."""
    for child in func_node.children:
        if child.type == "formal_parameters":
            count = 0
            if (
                len(child.children) >= 2
                and child.children[0].type == "("
                and child.children[-1].type == ")"
            ):
                middle_children = child.children[1:-1]
            else:
                middle_children = child.children
            for param_child in middle_children:
                if param_child.type in (
                    "identifier",
                    "required_parameter",
                    "optional_parameter",
                    "rest_parameter",
                ):
                    count += 1
            return count
    return 0
