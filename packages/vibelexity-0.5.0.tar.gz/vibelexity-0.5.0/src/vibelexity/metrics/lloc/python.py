"""LLOC (Logical Lines of Code) for Python."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from tree_sitter import Node

_PY_LLOC_TYPES = {
    # Simple statements
    "expression_statement",
    "return_statement",
    "pass_statement",
    "break_statement",
    "continue_statement",
    "raise_statement",
    "assert_statement",
    "delete_statement",
    "global_statement",
    "nonlocal_statement",
    "import_statement",
    "import_from_statement",
    "future_import_statement",
    "type_alias_statement",
    # Compound statement headers
    "if_statement",
    "elif_clause",
    "else_clause",
    "for_statement",
    "while_statement",
    "try_statement",
    "except_clause",
    "finally_clause",
    "with_statement",
    "function_definition",
    "class_definition",
    "match_statement",
    "case_clause",
    # Decorators
    "decorator",
}


def count_lloc(root: Node) -> int:
    """Count logical lines of code in a Python AST."""
    count = 0
    if root.type in _PY_LLOC_TYPES:
        count += 1
    for child in root.children:
        count += count_lloc(child)
    return count
