"""LLOC (Logical Lines of Code) for Go."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from tree_sitter import Node

_GO_LLOC_TYPES = {
    # Simple statements
    "expression_statement",
    "send_statement",
    "inc_statement",
    "dec_statement",
    "assignment_statement",
    "short_var_declaration",
    "return_statement",
    "go_statement",
    "defer_statement",
    "break_statement",
    "continue_statement",
    "goto_statement",
    "fallthrough_statement",
    "labeled_statement",
    "empty_statement",
    # Declarations
    "function_declaration",
    "method_declaration",
    "var_declaration",
    "const_declaration",
    "type_declaration",
    "import_declaration",
    # Compound statement headers
    "if_statement",
    "for_statement",
    "expression_switch_statement",
    "type_switch_statement",
    "select_statement",
    # Case clauses
    "expression_case",
    "type_case",
    "default_case",
    "communication_case",
}


def count_lloc(root: Node) -> int:
    """Count logical lines of code in a Go AST."""
    count = 0
    if root.type in _GO_LLOC_TYPES:
        count += 1
    if root.type == "if_statement":
        alt = root.child_by_field_name("alternative")
        if alt is not None and alt.type == "block":
            count += 1  # terminal else
    for child in root.children:
        count += count_lloc(child)
    return count
