"""LLOC (Logical Lines of Code) for TypeScript."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from tree_sitter import Node

_TS_LLOC_TYPES = {
    # Simple statements
    "expression_statement",
    "return_statement",
    "break_statement",
    "continue_statement",
    "throw_statement",
    "debugger_statement",
    "empty_statement",
    # Declarations
    "variable_declaration",
    "lexical_declaration",
    "function_declaration",
    "generator_function_declaration",
    "class_declaration",
    "abstract_class_declaration",
    "type_alias_declaration",
    "interface_declaration",
    "enum_declaration",
    # Import / export
    "import_statement",
    "export_statement",
    # Compound statement headers
    "if_statement",
    "for_statement",
    "for_in_statement",
    "while_statement",
    "do_statement",
    "switch_statement",
    "switch_case",
    "switch_default",
    "try_statement",
    "catch_clause",
    "finally_clause",
    "with_statement",
    "labeled_statement",
}


def count_lloc(root: Node) -> int:
    """Count logical lines of code in a TypeScript AST."""
    count = 0
    if root.type in _TS_LLOC_TYPES:
        count += 1
    elif root.type == "else_clause":
        if not any(c.type == "if_statement" for c in root.children):
            count += 1
    for child in root.children:
        count += count_lloc(child)
    return count
