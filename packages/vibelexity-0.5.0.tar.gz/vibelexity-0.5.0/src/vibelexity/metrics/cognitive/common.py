"""Common cognitive complexity utilities."""

from __future__ import annotations
from functools import partial


def compute_cognitive(func_node, func_name: str, walk_fn) -> int:
    return walk_fn(func_node, nesting=0, func_name=func_name, top_func=func_node)


def make_compute_cognitive(walk_fn):
    return partial(compute_cognitive, walk_fn=walk_fn)
