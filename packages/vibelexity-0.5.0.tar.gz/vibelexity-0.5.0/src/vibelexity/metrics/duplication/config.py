"""Per-language configuration for AST-based duplication detection."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class LanguageConfig:
    comment_types: frozenset[str]
    identifier_types: frozenset[str]
    literal_types: frozenset[str]


PYTHON_CONFIG = LanguageConfig(
    comment_types=frozenset({"comment"}),
    identifier_types=frozenset({"identifier"}),
    literal_types=frozenset({
        "integer", "float", "string", "concatenated_string",
        "true", "false", "none",
    }),
)

TYPESCRIPT_CONFIG = LanguageConfig(
    comment_types=frozenset({"comment"}),
    identifier_types=frozenset({
        "identifier", "property_identifier", "shorthand_property_identifier",
        "type_identifier",
    }),
    literal_types=frozenset({
        "number", "string", "template_string", "regex",
        "true", "false", "null", "undefined",
    }),
)

GO_CONFIG = LanguageConfig(
    comment_types=frozenset({"comment"}),
    identifier_types=frozenset({
        "identifier", "type_identifier", "field_identifier", "package_identifier",
    }),
    literal_types=frozenset({
        "int_literal", "float_literal", "imaginary_literal",
        "rune_literal", "raw_string_literal", "interpreted_string_literal",
        "true", "false", "nil", "iota",
    }),
)
