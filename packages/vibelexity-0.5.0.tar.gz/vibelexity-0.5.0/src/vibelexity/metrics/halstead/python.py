"""Halstead complexity measures for Python."""

from __future__ import annotations

from vibelexity.metrics.halstead.common import HalsteadConfig, make_compute_halstead

_PY_OPERATOR_TOKENS = {
    # Arithmetic
    "+",
    "-",
    "*",
    "/",
    "//",
    "%",
    "**",
    # Comparison
    "==",
    "!=",
    "<",
    ">",
    "<=",
    ">=",
    # Bitwise
    "&",
    "|",
    "^",
    "~",
    "<<",
    ">>",
    # Assignment
    "=",
    "+=",
    "-=",
    "*=",
    "/=",
    "//=",
    "%=",
    "**=",
    "&=",
    "|=",
    "^=",
    "<<=",
    ">>=",
    # Other symbols
    ".",
    ",",
    ":",
    ";",
    "(",
    ")",
    "[",
    "]",
    "{",
    "}",
    "->",
}

_PY_KEYWORD_OPERATORS = {
    "if_statement",
    "elif_clause",
    "else_clause",
    "for_statement",
    "while_statement",
    "return_statement",
    "yield",
    "function_definition",
    "class_definition",
    "import_statement",
    "import_from_statement",
    "try_statement",
    "except_clause",
    "finally_clause",
    "with_statement",
    "raise_statement",
    "assert_statement",
    "pass_statement",
    "break_statement",
    "continue_statement",
    "delete_statement",
    "global_statement",
    "nonlocal_statement",
    "match_statement",
    "case_clause",
    "lambda",
}

_PY_OPERAND_TYPES = {
    "identifier",
    "integer",
    "float",
    "string",
    "concatenated_string",
    "true",
    "false",
    "none",
}

_PY_COMMENT_TYPES = {"comment"}


compute_halstead_py = make_compute_halstead(
    HalsteadConfig(
        comment_types=_PY_COMMENT_TYPES,
        keyword_operators=_PY_KEYWORD_OPERATORS,
        operand_types=_PY_OPERAND_TYPES,
        operator_tokens=_PY_OPERATOR_TOKENS,
    )
)
