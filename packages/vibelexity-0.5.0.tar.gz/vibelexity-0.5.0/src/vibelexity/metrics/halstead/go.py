"""Halstead complexity measures for Go."""

from __future__ import annotations

from vibelexity.metrics.halstead.common import HalsteadConfig, make_compute_halstead

_GO_OPERATOR_TOKENS = {
    # Arithmetic
    "+",
    "-",
    "*",
    "/",
    "%",
    # Comparison
    "==",
    "!=",
    "<",
    ">",
    "<=",
    ">=",
    # Bitwise
    "&",
    "|",
    "^",
    "<<",
    ">>",
    "&^",
    # Logical (leaf tokens)
    "&&",
    "||",
    "!",
    # Assignment
    "=",
    ":=",
    "+=",
    "-=",
    "*=",
    "/=",
    "%=",
    "&=",
    "|=",
    "^=",
    "<<=",
    ">>=",
    "&^=",
    # Channel
    "<-",
    # Other symbols
    ".",
    ",",
    ":",
    ";",
    "(",
    ")",
    "[",
    "]",
    "{",
    "}",
    "...",
}

_GO_KEYWORD_OPERATORS = {
    "if_statement",
    "for_statement",
    "expression_switch_statement",
    "type_switch_statement",
    "select_statement",
    "return_statement",
    "go_statement",
    "defer_statement",
    "function_declaration",
    "method_declaration",
    "var_declaration",
    "const_declaration",
    "type_declaration",
    "import_declaration",
    "short_var_declaration",
    "assignment_statement",
    "break_statement",
    "continue_statement",
    "goto_statement",
    "fallthrough_statement",
    "expression_case",
    "type_case",
    "default_case",
    "communication_case",
    "send_statement",
    "inc_statement",
    "dec_statement",
    "labeled_statement",
}

_GO_OPERAND_TYPES = {
    "identifier",
    "type_identifier",
    "field_identifier",
    "package_identifier",
    "int_literal",
    "float_literal",
    "imaginary_literal",
    "rune_literal",
    "raw_string_literal",
    "interpreted_string_literal",
    "true",
    "false",
    "nil",
    "iota",
}

_GO_COMMENT_TYPES = {"comment"}


compute_halstead_go = make_compute_halstead(
    HalsteadConfig(
        comment_types=_GO_COMMENT_TYPES,
        keyword_operators=_GO_KEYWORD_OPERATORS,
        operand_types=_GO_OPERAND_TYPES,
        operator_tokens=_GO_OPERATOR_TOKENS,
    )
)
