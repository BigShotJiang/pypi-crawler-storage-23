"""Halstead complexity measures for TypeScript."""

from __future__ import annotations

from vibelexity.metrics.halstead.common import HalsteadConfig, make_compute_halstead

_TS_OPERATOR_TOKENS = {
    # Arithmetic
    "+",
    "-",
    "*",
    "/",
    "%",
    "**",
    # Comparison / equality
    "==",
    "!=",
    "===",
    "!==",
    "<",
    ">",
    "<=",
    ">=",
    # Bitwise
    "&",
    "|",
    "^",
    "~",
    "<<",
    ">>",
    ">>>",
    # Logical (leaf tokens)
    "&&",
    "||",
    "!",
    # Assignment
    "=",
    "+=",
    "-=",
    "*=",
    "/=",
    "%=",
    "**=",
    "&=",
    "|=",
    "^=",
    "<<=",
    ">>=",
    ">>>=",
    "&&=",
    "||=",
    "??=",
    # Other symbols
    ".",
    ",",
    ":",
    ";",
    "(",
    ")",
    "[",
    "]",
    "{",
    "}",
    "=>",
    "?.",
    "??",
    # Unary / misc
    "++",
    "--",
    "typeof",
    "instanceof",
    "in",
    "void",
    "delete",
    "...",
}

_TS_KEYWORD_OPERATORS = {
    "if_statement",
    "else_clause",
    "for_statement",
    "for_in_statement",
    "while_statement",
    "do_statement",
    "return_statement",
    "throw_statement",
    "function_declaration",
    "generator_function_declaration",
    "class_declaration",
    "abstract_class_declaration",
    "method_definition",
    "arrow_function",
    "import_statement",
    "export_statement",
    "try_statement",
    "catch_clause",
    "finally_clause",
    "switch_statement",
    "switch_case",
    "switch_default",
    "variable_declaration",
    "lexical_declaration",
    "type_alias_declaration",
    "interface_declaration",
    "enum_declaration",
    "break_statement",
    "continue_statement",
    "labeled_statement",
    "with_statement",
    "debugger_statement",
    "new_expression",
}

_TS_OPERAND_TYPES = {
    "identifier",
    "property_identifier",
    "shorthand_property_identifier",
    "number",
    "string",
    "template_string",
    "template_substitution",
    "regex",
    "true",
    "false",
    "null",
    "undefined",
    "this",
    "super",
    "type_identifier",
}

_TS_COMMENT_TYPES = {"comment"}


compute_halstead_ts = make_compute_halstead(
    HalsteadConfig(
        comment_types=_TS_COMMENT_TYPES,
        keyword_operators=_TS_KEYWORD_OPERATORS,
        operand_types=_TS_OPERAND_TYPES,
        operator_tokens=_TS_OPERATOR_TOKENS,
    )
)
