"""Python source file analyzer -- assembles all metrics."""

from __future__ import annotations

from vibelexity.analyzers.common import (
    AnalyzerConfig,
    analyze_parsed_generic,
    analyze_source_generic,
)
from vibelexity.analyzers.shared import create_analyze_file
from vibelexity.models import FileComplexity
from vibelexity.parsers.python import (
    parse,
    collect_functions,
    func_name,
    func_param_count,
)
from vibelexity.patterns.shared import check_patterns as check_patterns_all
from vibelexity.metrics.lloc.python import count_lloc
from vibelexity.metrics.halstead.python import compute_halstead_py
from vibelexity.metrics.npath.python import compute_npath_py
from vibelexity.metrics.dtd.python import compute_dtd_py
from vibelexity.metrics.cognitive.python import compute_cognitive_py
from vibelexity.metrics.cyclomatic.python import compute_cyclomatic_py
from vibelexity.metrics.duplication.config import PYTHON_CONFIG

Node = object


def check_patterns(
    root: Node, patterns: list[str] | None = None, source: str | None = None
) -> list:
    """Wrapper for check_patterns that matches the expected signature."""
    return check_patterns_all("python", root, patterns, source)


def analyze_source(code: str) -> FileComplexity:
    config = AnalyzerConfig(
        parse_fn=parse,
        collect_functions_fn=collect_functions,
        func_name_fn=func_name,
        func_param_count_fn=func_param_count,
        compute_cognitive_fn=compute_cognitive_py,
        compute_halstead_fn=compute_halstead_py,
        compute_npath_fn=compute_npath_py,
        compute_dtd_fn=compute_dtd_py,
        compute_cyclomatic_fn=compute_cyclomatic_py,
        count_lloc_fn=count_lloc,
        dup_config=PYTHON_CONFIG,
        check_patterns_fn=check_patterns,
    )
    return analyze_source_generic(code, config)


def analyze_parsed(code: str, root: Node) -> FileComplexity:
    """Analyze source using a pre-parsed Python AST root."""
    config = AnalyzerConfig(
        parse_fn=parse,
        collect_functions_fn=collect_functions,
        func_name_fn=func_name,
        func_param_count_fn=func_param_count,
        compute_cognitive_fn=compute_cognitive_py,
        compute_halstead_fn=compute_halstead_py,
        compute_npath_fn=compute_npath_py,
        compute_dtd_fn=compute_dtd_py,
        compute_cyclomatic_fn=compute_cyclomatic_py,
        count_lloc_fn=count_lloc,
        dup_config=PYTHON_CONFIG,
        check_patterns_fn=check_patterns,
    )
    return analyze_parsed_generic(code, root, config)


analyze_file = create_analyze_file(analyze_source)
