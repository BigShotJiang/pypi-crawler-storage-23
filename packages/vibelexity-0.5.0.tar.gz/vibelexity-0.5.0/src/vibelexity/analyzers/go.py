"""Go source file analyzer -- assembles all metrics."""

from __future__ import annotations

from pathlib import Path

from vibelexity.analyzers.common import (
    AnalyzerConfig,
    analyze_parsed_generic,
    analyze_source_generic,
)
from vibelexity.analyzers.shared import create_analyze_file
from vibelexity.models import FileComplexity
from vibelexity.parsers.go import parse, collect_functions, func_name, func_param_count
from vibelexity.metrics.lloc.go import count_lloc
from vibelexity.metrics.halstead.go import compute_halstead_go
from vibelexity.metrics.npath.go import compute_npath_go
from vibelexity.metrics.dtd.go import compute_dtd_go
from vibelexity.metrics.cognitive.go import compute_cognitive_go
from vibelexity.metrics.cyclomatic.go import compute_cyclomatic_go
from vibelexity.metrics.duplication.config import GO_CONFIG


def analyze_source(code: str) -> FileComplexity:
    config = AnalyzerConfig(
        parse_fn=parse,
        collect_functions_fn=collect_functions,
        func_name_fn=func_name,
        func_param_count_fn=func_param_count,
        compute_cognitive_fn=compute_cognitive_go,
        compute_halstead_fn=compute_halstead_go,
        compute_npath_fn=compute_npath_go,
        compute_dtd_fn=compute_dtd_go,
        compute_cyclomatic_fn=compute_cyclomatic_go,
        count_lloc_fn=count_lloc,
        dup_config=GO_CONFIG,
    )
    return analyze_source_generic(code, config)


def analyze_parsed(code: str, root: object) -> FileComplexity:
    """Analyze source using a pre-parsed Go AST root."""
    config = AnalyzerConfig(
        parse_fn=parse,
        collect_functions_fn=collect_functions,
        func_name_fn=func_name,
        func_param_count_fn=func_param_count,
        compute_cognitive_fn=compute_cognitive_go,
        compute_halstead_fn=compute_halstead_go,
        compute_npath_fn=compute_npath_go,
        compute_dtd_fn=compute_dtd_go,
        compute_cyclomatic_fn=compute_cyclomatic_go,
        count_lloc_fn=count_lloc,
        dup_config=GO_CONFIG,
    )
    return analyze_parsed_generic(code, root, config)


analyze_file = create_analyze_file(analyze_source)
