"""Shared helpers for code analyzers."""

from __future__ import annotations

from pathlib import Path

from vibelexity.models import FileComplexity


def analyze_file_generic(
    filepath: str,
    analyze_source_fn,
    **kwargs,
) -> FileComplexity:
    """Generic file analysis function used by all language analyzers."""
    path = Path(filepath)
    source = path.read_text()
    result = analyze_source_fn(source, **kwargs)
    result.path = str(path)
    return result


def create_analyze_file(analyze_source_fn):
    """Create an analyze_file function with the given analyze_source function."""

    def analyze_file(filepath: str, **kwargs) -> FileComplexity:
        """Analyze a file and return cognitive complexity scores."""
        return analyze_file_generic(filepath, analyze_source_fn, **kwargs)

    return analyze_file
