from __future__ import annotations

import json

from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from vibelexity.circular_deps.models import Cycle


def format_text(cycles: list[Cycle]) -> str:
    output = []
    output.append("\nCircular Dependencies")
    output.append("─────────────────────")

    if cycles:
        for i, cycle in enumerate(cycles, 1):
            output.append(
                f"\033[33m⚠ Warning: cycle detected ({cycle.depth} files)\033[0m"
            )
            for from_file, to_file, line in cycle.edges:
                from_name = Path(from_file).name
                to_name = Path(to_file).name
                output.append(f"  {from_name}:{line} → {to_name}")
            output.append("")
        output.append(f"{len(cycles)} cycle(s) found")
    else:
        output.append("\033[32m✓ No circular dependencies found\033[0m")

    return "\n".join(output)


def format_json(cycles: list[Cycle]) -> str:
    cycle_list = []
    for cycle in cycles:
        cycle_list.append(
            {
                "severity": "warning",
                "depth": cycle.depth,
                "files": cycle.files,
                "edges": [
                    {"from": f, "to": t, "line": line} for f, t, line in cycle.edges
                ],
            }
        )

    return json.dumps({"cycles": cycle_list, "total_cycles": len(cycles)}, indent=2)
