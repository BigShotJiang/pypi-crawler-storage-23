from __future__ import annotations

from dataclasses import dataclass


@dataclass
class ImportInfo:
    """Single import extracted from a source file."""

    raw_module: str
    resolved_path: str | None
    import_type: str
    line: int
    is_dynamic: bool
    node_type: str
    is_type_import: bool = False


@dataclass
class Cycle:
    """Detected circular dependency."""

    files: list[str]
    edges: list[tuple[str, str, int]]
    depth: int
    severity: str = "warning"
    is_type_cycle: bool = False


@dataclass
class DependencyGraph:
    edges: dict[str, list[ImportInfo]]
    local_files: set[str]
    root_dir: str
