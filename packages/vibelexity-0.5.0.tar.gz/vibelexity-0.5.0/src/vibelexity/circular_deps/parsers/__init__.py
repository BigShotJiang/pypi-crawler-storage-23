from __future__ import annotations

from vibelexity.circular_deps.parsers.base import ImportParser
from vibelexity.circular_deps.parsers.python import PythonImportParser
from vibelexity.circular_deps.parsers.typescript import TypeScriptImportParser
from vibelexity.circular_deps.parsers.go import GoImportParser
