from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from vibelexity.circular_deps.models import ImportInfo


class ImportParser(ABC):
    @abstractmethod
    def extract_imports(self, source: str, filepath: str, **kwargs) -> list[ImportInfo]:
        """Parse source and return ImportInfo list."""
        pass
