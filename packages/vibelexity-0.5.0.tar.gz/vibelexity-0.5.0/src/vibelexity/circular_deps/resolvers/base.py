from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    pass


class PathResolver(ABC):
    @abstractmethod
    def resolve(self, module: str, current_file: str, root_dir: str) -> str | None:
        """Return resolved absolute path or None if external."""
        pass
