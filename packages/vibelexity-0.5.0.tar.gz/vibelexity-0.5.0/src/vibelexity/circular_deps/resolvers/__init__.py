from __future__ import annotations

from vibelexity.circular_deps.resolvers.base import PathResolver
from vibelexity.circular_deps.resolvers.python import PythonPathResolver
from vibelexity.circular_deps.resolvers.typescript import TypeScriptPathResolver
from vibelexity.circular_deps.resolvers.go import GoPathResolver
