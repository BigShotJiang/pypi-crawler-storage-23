"""Shared helpers for path resolvers."""

from __future__ import annotations

import os


def check_under_root(path: str, root_dir: str) -> str | None:
    """Check if a path is under the root directory.

    Returns absolute path if under root, None otherwise.
    """
    abs_path = os.path.abspath(path)
    abs_root = os.path.abspath(root_dir)
    if abs_path.startswith(abs_root):
        return abs_path
    return None
