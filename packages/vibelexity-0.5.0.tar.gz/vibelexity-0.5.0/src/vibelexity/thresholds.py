"""Thresholds for code quality metrics.

All thresholds are for the "common candidates" detection - functions
appearing in multiple refactor candidate lists.
"""

# Cognitive Complexity (SonarSource/SonarQube standard)
COGNITIVE_COMPLEXITY_THRESHOLD = 15

# NPath Complexity (OCLint and industry standard)
NPATH_THRESHOLD = 200

# Data Transformation Density (custom metric)
DTD_THRESHOLD = 15

# Cyclomatic Complexity (McCabe standard)
CYCLOMATIC_THRESHOLD = 20

# Maintainability Index (VSCode/industry: >=60 moderate, <60 difficult)
# Note: MI uses a dynamic threshold based on the top-10 baseline
MI_RED_THRESHOLD = 10

# Logic Density Index (custom metric)
LDI_THRESHOLD = 30
