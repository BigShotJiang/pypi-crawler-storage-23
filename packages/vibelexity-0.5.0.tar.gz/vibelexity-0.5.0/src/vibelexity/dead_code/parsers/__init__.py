from __future__ import annotations

from vibelexity.dead_code.parsers.base import (
    DeadCodeParser,
    ImportedSymbol,
    VariableDefinition,
    SymbolDefinition,
    SymbolReference,
)
from vibelexity.dead_code.parsers.python import PythonDeadCodeParser
from vibelexity.dead_code.parsers.typescript import TypeScriptDeadCodeParser
from vibelexity.dead_code.parsers.go import GoDeadCodeParser
