"""Base parser interface for dead code detection."""

from __future__ import annotations

from dataclasses import dataclass
from abc import ABC, abstractmethod
from typing import Callable

Node = object
Query = object


@dataclass
class SymbolDefinition:
    name: str
    line: int
    definition_type: str
    exported: bool = False


@dataclass
class ImportedSymbol:
    name: str
    line: int
    imported_from: str | None = None
    alias: str | None = None


@dataclass
class VariableDefinition:
    name: str
    line: int
    scope_type: str
    definition_type: str


@dataclass
class SymbolReference:
    name: str
    line: int


class DeadCodeParser(ABC):
    def __init__(self) -> None:
        self._reference_extractor: (
            Callable[[Node, str], list[SymbolReference]] | None
        ) = None
        self._query_cache: dict[tuple[str, object], Query] = {}

    def _query(self, query_str: str):
        from vibelexity.patterns.common import create_query

        lang = self._get_language()
        cache_key = (query_str, lang)
        query = self._query_cache.get(cache_key)
        if query is None:
            query = create_query(lang, query_str)
            self._query_cache[cache_key] = query
        return query

    @abstractmethod
    def extract_imports(self, root: Node, source: str) -> list[ImportedSymbol]:
        pass

    @abstractmethod
    def extract_definitions(self, root: Node, source: str) -> list[SymbolDefinition]:
        pass

    def extract_references(self, root: Node, source: str) -> list[SymbolReference]:
        if self._reference_extractor is None:
            self._reference_extractor = self._create_reference_extractor()
        return self._reference_extractor(root, source)

    def _get_reference_query_str(self) -> str:
        return "(identifier) @usage_ref"

    def _create_reference_extractor(
        self,
    ) -> Callable[[Node, str], list[SymbolReference]]:
        from vibelexity.patterns.common import run_captures

        query_str = self._get_reference_query_str()
        query = self._query(query_str)

        def extractor(root: Node, source: str) -> list[SymbolReference]:
            captures = run_captures(query, root)
            refs = []
            for node, capture_name in captures:
                if capture_name == "usage_ref" and node.text:
                    refs.append(
                        SymbolReference(node.text.decode(), node.start_point[0] + 1)
                    )
            return refs

        return extractor

    def _get_language(self):
        raise NotImplementedError("Subclasses must implement _get_language()")
