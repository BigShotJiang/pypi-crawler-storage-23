"""Pattern detection for all languages."""

from __future__ import annotations

from vibelexity.patterns.shared import check_patterns as check_patterns_all


def check_patterns(language: str, root, patterns: list[str] | None = None):
    """Run pattern checks for a language.

    Args:
        language: Language name ("python", "typescript", "go")
        root: AST root node
        patterns: List of specific pattern functions to run, or None for all

    Returns:
        List of PatternViolation objects
    """
    return check_patterns_all(language, root, patterns)
