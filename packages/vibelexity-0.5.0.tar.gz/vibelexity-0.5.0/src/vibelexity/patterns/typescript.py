"""Pattern detection for TypeScript source files."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from tree_sitter import Node

from vibelexity.models import PatternViolation
from vibelexity.parsers.typescript import TS_LANGUAGE
from vibelexity.patterns.common import create_query, run_captures


_TS_ANY_TYPE_QUERY = "(predefined_type) @any_type"

_TS_NON_NULL_QUERY = "(non_null_expression) @nonnull"

_TS_AS_EXPRESSION_QUERY = "(as_expression) @as_expr"

_TS_TYPE_ASSERTION_QUERY = "(type_assertion) @angle_assertion"

_TS_ENUM_QUERY = "(enum_declaration) @enum_decl"

_TS_TYPE_IDENTIFIER_QUERY = "(type_identifier) @type_id"

_TS_ARRAY_TYPE_QUERY = "(array_type) @array_type"

_TS_PRIVATE_FIELD_QUERY = """
(public_field_definition
  (accessibility_modifier) @modifier
) @field
"""

_TS_PRIVATE_METHOD_QUERY = """
(method_definition
  (accessibility_modifier) @modifier
) @method
"""

_TS_CLASS_METHOD_QUERY = """
(class_body
  (method_definition) @method
)
"""

_TS_EMPTY_INTERFACE_QUERY = """
(interface_declaration
  (interface_body) @body) @interface
"""

_TS_WRAPPER_TYPE_QUERY = "(type_identifier) @type_id"

_TS_DOUBLE_CAST_QUERY = "(as_expression) @as_expr"

_TS_ANY_GENERIC_QUERY = """
(type_parameter
  (constraint
    (predefined_type) @any_type
  )
) @type_param
"""

_TS_INTERFACE_QUERY = """
(interface_declaration
  (interface_body) @body
) @interface
"""


def check_double_casting(root: Node) -> list[PatternViolation]:
    """Detect double casting pattern: (x as unknown) as T."""
    violations = []
    seen: set[int] = set()

    def _has_nested_as_expression(node: Node) -> bool:
        """Check if node contains a nested as_expression."""
        for child in node.children:
            if child.type == "as_expression":
                return True
            if _has_nested_as_expression(child):
                return True
        return False

    def _has_parent_as_expression(node: Node) -> bool:
        """Check if node has a parent that is an as_expression."""
        parent = node.parent
        while parent:
            if parent.type == "as_expression":
                return True
            parent = parent.parent
        return False

    query = create_query(TS_LANGUAGE, _TS_DOUBLE_CAST_QUERY)
    for node, capture_name in run_captures(query, root):
        if capture_name == "as_expr":
            if id(node) in seen:
                continue

            if _has_nested_as_expression(node) and not _has_parent_as_expression(node):
                seen.add(id(node))
                line = node.start_point[0] + 1
                violations.append(
                    PatternViolation(
                        type="double_casting",
                        line=line,
                        description="Double casting (x as unknown) as T - typically indicates a logic error; use proper validation",
                        severity="warning",
                    )
                )

    return violations


def check_any_generic_constraint(root: Node) -> list[PatternViolation]:
    """Detect <T extends any> generic constraints (redundant)."""
    violations = []
    type_params: dict[int, Node] = {}

    for node in root.children:
        _collect_type_param_nodes(node, type_params)

    query = create_query(TS_LANGUAGE, _TS_ANY_GENERIC_QUERY)
    for node, capture_name in run_captures(query, root):
        if capture_name == "any_type":
            text = node.text.decode() if node.text else ""
            if text == "any":
                type_param = node
                while type_param and type_param.type != "type_parameter":
                    type_param = type_param.parent

                if type_param:
                    line = type_param.start_point[0] + 1
                    violations.append(
                        PatternViolation(
                            type="any_generic_constraint",
                            line=line,
                            description="Generic constraint 'extends any' is redundant - use <T> or <T extends object>",
                            severity="info",
                        )
                    )

    return violations


def _collect_type_param_nodes(node: Node, acc: dict[int, Node]) -> None:
    """Collect all type_parameter nodes."""
    if node.type == "type_parameter":
        acc[id(node)] = node
    for child in node.children:
        _collect_type_param_nodes(child, acc)


def check_over_optional_interface(root: Node) -> list[PatternViolation]:
    """Detect interfaces where 100% of properties are optional."""
    violations = []

    query = create_query(TS_LANGUAGE, _TS_INTERFACE_QUERY)
    for node, capture_name in run_captures(query, root):
        if capture_name == "body":
            parent = node.parent
            if not parent:
                continue

            property_signatures = [
                child for child in node.children if child.type == "property_signature"
            ]

            property_count = len(property_signatures)
            if property_count < 2:
                continue

            optional_count = 0
            for sig in property_signatures:
                for child in sig.children:
                    if child.type == "?":
                        optional_count += 1
                        break

            if optional_count == property_count:
                line = parent.start_point[0] + 1
                violations.append(
                    PatternViolation(
                        type="over_optional_interface",
                        line=line,
                        description="All interface properties are optional - use required base properties and Partial<T> only when needed",
                        severity="info",
                    )
                )

    return violations


def check_any_type(root: Node) -> list[PatternViolation]:
    """Detect explicit 'any' type annotations."""
    query = create_query(TS_LANGUAGE, _TS_ANY_TYPE_QUERY)
    captures = run_captures(query, root)

    violations = []
    for node, capture_name in captures:
        if capture_name == "any_type":
            text = node.text.decode() if node.text else ""
            if text == "any":
                line = node.start_point[0] + 1
                violations.append(
                    PatternViolation(
                        type="any_type",
                        line=line,
                        description="Explicit 'any' type bypasses type safety - consider a more specific type",
                        severity="warning",
                    )
                )

    return violations


def check_non_null_assertion(root: Node) -> list[PatternViolation]:
    """Detect non-null assertion operator (!)."""
    query = create_query(TS_LANGUAGE, _TS_NON_NULL_QUERY)
    captures = run_captures(query, root)

    violations = []
    for node, capture_name in captures:
        if capture_name == "nonnull":
            line = node.start_point[0] + 1
            violations.append(
                PatternViolation(
                    type="non_null_assertion",
                    line=line,
                    description="Non-null assertion (!) assumes value is non-null - consider proper null checking",
                    severity="warning",
                )
            )

    return violations


def check_as_assertion(root: Node) -> list[PatternViolation]:
    """Detect 'as' type assertions."""
    query = create_query(TS_LANGUAGE, _TS_AS_EXPRESSION_QUERY)
    captures = run_captures(query, root)

    violations = []
    for node, capture_name in captures:
        if capture_name == "as_expr":
            line = node.start_point[0] + 1
            violations.append(
                PatternViolation(
                    type="as_assertion",
                    line=line,
                    description="'as' type assertion overrides type system - ensure this is necessary",
                    severity="info",
                )
            )

    return violations


def check_angle_assertion(root: Node, tsx: bool = False) -> list[PatternViolation]:
    """Detect angle-bracket type assertions (<T>x).

    Args:
        root: AST root node
        tsx: If True, skip detection (ambiguous with JSX syntax)

    Returns:
        List of PatternViolation objects
    """
    if tsx:
        return []

    query = create_query(TS_LANGUAGE, _TS_TYPE_ASSERTION_QUERY)
    captures = run_captures(query, root)

    violations = []
    for node, capture_name in captures:
        if capture_name == "angle_assertion":
            line = node.start_point[0] + 1
            violations.append(
                PatternViolation(
                    type="angle_assertion",
                    line=line,
                    description="Angle-bracket type assertion (<T>x) - consider using 'as' syntax or verify necessity",
                    severity="info",
                )
            )

    return violations


def check_enum_declaration(root: Node) -> list[PatternViolation]:
    """Detect enum declarations (suggest union types as alternative)."""
    query = create_query(TS_LANGUAGE, _TS_ENUM_QUERY)
    captures = run_captures(query, root)

    violations = []
    for node, capture_name in captures:
        if capture_name == "enum_decl":
            line = node.start_point[0] + 1
            violations.append(
                PatternViolation(
                    type="enum_declaration",
                    line=line,
                    description="Enum declaration - consider using union types for better type inference",
                    severity="info",
                )
            )

    return violations


def check_function_type(root: Node) -> list[PatternViolation]:
    """Detect use of 'Function' as a type annotation (too permissive)."""
    query = create_query(TS_LANGUAGE, _TS_TYPE_IDENTIFIER_QUERY)
    captures = run_captures(query, root)

    violations = []
    for node, capture_name in captures:
        if capture_name == "type_id":
            text = node.text.decode() if node.text else ""
            if text == "Function":
                line = node.start_point[0] + 1
                violations.append(
                    PatternViolation(
                        type="function_type",
                        line=line,
                        description="'Function' type is too permissive - use explicit function signature (...args) => ReturnType",
                        severity="warning",
                    )
                )

    return violations


def _is_function_parameter(node: Node) -> bool:
    """Check if array_type is inside a function parameter context."""
    parent = node.parent
    while parent:
        if parent.type == "required_parameter" or parent.type == "rest_parameter":
            grandparent = parent.parent
            if grandparent and grandparent.type == "formal_parameters":
                return True
            return True
        if parent.type in (
            "function_declaration",
            "function_expression",
            "arrow_function",
            "method_definition",
        ):
            return False
        parent = parent.parent
    return False


def _is_readonly_array(array_node: Node) -> bool:
    """Check if array_type is wrapped in a readonly_type."""
    parent = array_node.parent
    return parent is not None and parent.type == "readonly_type"


def check_missing_readonly(root: Node) -> list[PatternViolation]:
    """Detect arrays in function parameters that lack readonly modifier."""
    query = create_query(TS_LANGUAGE, _TS_ARRAY_TYPE_QUERY)
    captures = run_captures(query, root)

    violations = []

    for node, capture_name in captures:
        if capture_name == "array_type":
            if _is_readonly_array(node):
                continue

            if not _is_function_parameter(node):
                continue

            line = node.start_point[0] + 1
            violations.append(
                PatternViolation(
                    type="missing_readonly",
                    line=line,
                    description="Array parameter without 'readonly' - consider 'readonly T[]' to prevent mutation",
                    severity="info",
                )
            )

    return violations


def check_private_keyword(root: Node) -> list[PatternViolation]:
    """Detect 'private' keyword usage (soft privacy) vs # prefix (hard privacy)."""
    violations = []

    field_query = create_query(TS_LANGUAGE, _TS_PRIVATE_FIELD_QUERY)
    for node, capture_name in run_captures(field_query, root):
        if capture_name == "modifier":
            text = node.text.decode() if node.text else ""
            if text == "private":
                field_node = node.parent
                line = (
                    field_node.start_point[0] + 1
                    if field_node
                    else node.start_point[0] + 1
                )
                violations.append(
                    PatternViolation(
                        type="private_keyword",
                        line=line,
                        description="'private' keyword is soft-privacy (accessible at runtime) - consider # prefix for true privacy",
                        severity="info",
                    )
                )

    method_query = create_query(TS_LANGUAGE, _TS_PRIVATE_METHOD_QUERY)
    for node, capture_name in run_captures(method_query, root):
        if capture_name == "modifier":
            text = node.text.decode() if node.text else ""
            if text == "private":
                method_node = node.parent
                line = (
                    method_node.start_point[0] + 1
                    if method_node
                    else node.start_point[0] + 1
                )
                violations.append(
                    PatternViolation(
                        type="private_keyword",
                        line=line,
                        description="'private' keyword is soft-privacy (accessible at runtime) - consider # prefix for true privacy",
                        severity="info",
                    )
                )

    return violations


def _is_getter_or_setter(node: Node) -> bool:
    """Check if method_definition is a getter or setter."""
    for child in node.children:
        if child.type in ("get", "set"):
            return True
    return False


def check_non_arrow_method(root: Node) -> list[PatternViolation]:
    """Detect class methods that could lose 'this' context when passed as callbacks."""
    query = create_query(TS_LANGUAGE, _TS_CLASS_METHOD_QUERY)
    captures = run_captures(query, root)

    violations = []
    seen_methods: set[int] = set()

    for node, capture_name in captures:
        if capture_name == "method":
            if id(node) in seen_methods:
                continue
            seen_methods.add(id(node))

            if _is_getter_or_setter(node):
                continue

            has_modifier = False
            for child in node.children:
                if child.type == "accessibility_modifier":
                    has_modifier = True
                    break

            if has_modifier:
                continue

            line = node.start_point[0] + 1
            violations.append(
                PatternViolation(
                    type="non_arrow_method",
                    line=line,
                    description="Method may lose 'this' context when passed as callback - consider arrow function property: handleClick = () => {}",
                    severity="warning",
                )
            )

    return violations


def check_empty_interface(root: Node) -> list[PatternViolation]:
    """Detect empty interface declarations."""
    query = create_query(TS_LANGUAGE, _TS_EMPTY_INTERFACE_QUERY)
    captures = run_captures(query, root)

    violations = []
    seen: set[int] = set()

    for node, capture_name in captures:
        if capture_name == "body":
            interface_node = node.parent
            if interface_node and id(interface_node) not in seen:
                if node.child_count == 2:
                    seen.add(id(interface_node))
                    line = interface_node.start_point[0] + 1
                    violations.append(
                        PatternViolation(
                            type="empty_interface",
                            line=line,
                            description="Empty interface acts like 'any' - use a proper type or Record<string, unknown>",
                            severity="warning",
                        )
                    )

    return violations


_WRAPPER_TYPES = {"Number", "String", "Boolean"}


def check_wrapper_type(root: Node) -> list[PatternViolation]:
    """Detect use of Number, String, Boolean wrapper objects instead of primitives."""
    query = create_query(TS_LANGUAGE, _TS_WRAPPER_TYPE_QUERY)
    captures = run_captures(query, root)

    violations = []
    for node, capture_name in captures:
        if capture_name == "type_id":
            parent = node.parent
            if parent and parent.type == "type_annotation":
                text = node.text.decode() if node.text else ""
                if text in _WRAPPER_TYPES:
                    line = node.start_point[0] + 1
                    violations.append(
                        PatternViolation(
                            type="wrapper_type",
                            line=line,
                            description=f"'{text}' is a wrapper object - use lowercase primitive '{text.lower()}'",
                            severity="warning",
                        )
                    )

    return violations


def check_all_patterns(root: Node, tsx: bool = False) -> list[PatternViolation]:
    """Run all TypeScript pattern checks.

    Args:
        root: AST root node
        tsx: If True, skip angle-bracket assertions (ambiguous with JSX)

    Returns:
        List of all PatternViolation objects
    """
    violations = []
    violations.extend(check_any_type(root))
    violations.extend(check_non_null_assertion(root))
    violations.extend(check_as_assertion(root))
    violations.extend(check_angle_assertion(root, tsx=tsx))
    violations.extend(check_enum_declaration(root))
    violations.extend(check_function_type(root))
    violations.extend(check_missing_readonly(root))
    violations.extend(check_private_keyword(root))
    violations.extend(check_non_arrow_method(root))
    violations.extend(check_empty_interface(root))
    violations.extend(check_wrapper_type(root))
    violations.extend(check_double_casting(root))
    violations.extend(check_any_generic_constraint(root))
    violations.extend(check_over_optional_interface(root))
    return violations
