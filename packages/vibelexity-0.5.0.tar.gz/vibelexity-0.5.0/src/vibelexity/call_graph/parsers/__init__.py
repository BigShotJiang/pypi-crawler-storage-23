"""Call graph parsers."""

from __future__ import annotations

from vibelexity.call_graph.parsers.base import CallGraphParser
from vibelexity.call_graph.parsers.python import PythonCallParser

__all__ = ["CallGraphParser", "PythonCallParser"]
