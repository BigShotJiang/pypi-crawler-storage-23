"""Base class for call graph parsers."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from tree_sitter import Node

from vibelexity.models import FunctionDefinition, CallEdge


class CallGraphParser(ABC):
    @abstractmethod
    def extract_function_definitions(
        self, root: Node, source: str, filepath: str
    ) -> list[FunctionDefinition]:
        pass

    @abstractmethod
    def extract_calls(
        self,
        root: Node,
        source: str,
        filepath: str,
        all_functions: list[FunctionDefinition],
    ) -> list[CallEdge]:
        pass
