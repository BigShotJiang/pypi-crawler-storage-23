def aa(b,c):
	return a(1,1,2, "dada", r == u, r > j, [c.type == "template_substitution" for c in node.children])

class a:
	pass

#def bar2(x):
#    return qq(r == u)()
def bar2(x):
    return qq()
def bar1(x):
    return qq("aa")
def bar(x):
    return qq(2,2,3, "aa", [c for c in k])
def foo(x):
    return bar(x + 1)
def foo(x):
    e = 3
    return bar(x + 1)

def _is_template_container(node):
    """fsfsfsdfsd"""
    #fsdfsfsd
	return e()
def aa(b,c):
	return any(c for c in k, e)
@property
def total(self) -> int:
    return sum([1,2])
#@property
#def total(self) -> int:
#    return sum(ia)

