"""Pyparse: A tree-sitter based parser for querying Python programs."""

from __future__ import annotations

from pyparse.cli import cli, parse_file, QueryResult

__all__ = ["cli", "parse_file", "QueryResult"]
