from __future__ import annotations


def func3_1():
    print("func3_1")


def func3_2():
    print("func3_2")


def func3_3():
    print("func3_3")


def func3_4():
    print("func3_4")


def func3_5():
    print("func3_5")
