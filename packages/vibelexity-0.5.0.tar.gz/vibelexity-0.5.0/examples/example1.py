from __future__ import annotations

from example2 import func2_1, func2_2, func2_3, func2_4, func2_5
from example3 import func3_1, func3_2, func3_3, func3_4, func3_5


def func1():
    print("func1")
    func2_1()
    func2_2()
    func2_3()
    func2_4()
    func2_5()


def func2():
    print("func2")
    func2_1()
    func2_2()
    func2_3()
    func2_4()
    func2_5()


def func3():
    print("func3")
    func3_1()
    func3_2()
    func3_3()
    func3_4()
    func3_5()


def func4():
    print("func4")
    func3_1()
    func3_2()
    func3_3()
    func3_4()
    func3_5()


def func5():
    print("func5")


def main():
    print("main")
    func1()
    func2()
    func3()
    func4()
    func5()


if __name__ == "__main__":
    main()
