from __future__ import annotations


def func2_1():
    print("func2_1")


def func2_2():
    print("func2_2")


def func2_3():
    print("func2_3")


def func2_4():
    print("func2_4")


def func2_5():
    print("func2_5")
