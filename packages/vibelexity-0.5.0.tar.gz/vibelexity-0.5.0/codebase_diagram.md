# Vibelexity Codebase Architecture

```mermaid
graph TB
    subgraph "Core Models"
        models[models.py<br/>FileComplexity<br/>FunctionComplexity<br/>HalsteadMetrics<br/>PatternViolation<br/>DeadCodeViolation]
    end

    subgraph "Entry Points"
        main[main.py<br/>CLI Entry Point]
        analysis[analysis.py<br/>Analysis Functions]
    end

    subgraph "Three-Layer Architecture"
        direction TB
        
        subgraph "Parsers Layer"
            parsers_shared[parsers/shared.py<br/>Common Parser Utilities]
            parsers_python[parsers/python.py<br/>Python AST Parser]
            parsers_go[parsers/go.py<br/>Go AST Parser]
            parsers_ts[parsers/typescript.py<br/>TypeScript AST Parser]
        end
        
        subgraph "Metrics Layer"
            metrics_cognitive[metrics/cognitive/<br/>Cognitive Complexity]
            metrics_halstead[metrics/halstead/<br/>Halstead Metrics]
            metrics_cyclomatic[metrics/cyclomatic/<br/>Cyclomatic Complexity]
            metrics_npath[metrics/npath/<br/>NPath Complexity]
            metrics_dtd[metrics/dtd/<br/>Data Transformation Density]
            metrics_lloc[metrics/lloc/<br/>Logical Lines of Code]
            metrics_duplication[metrics/duplication/<br/>Code Duplication]
            metrics_fatness[metrics/fatness/<br/>Function Fatness]
            metrics_common[metrics/cognitive/common.py<br/>Shared Metric Utilities]
        end
        
        subgraph "Analyzers Layer"
            analyzers_common[analyzers/common.py<br/>analyze_source_generic]
            analyzers_shared[analyzers/shared.py<br/>Shared Analyzer Utilities]
            analyzers_python[analyzers/python.py<br/>Python Analyzer]
            analyzers_go[analyzers/go.py<br/>Go Analyzer]
            analyzers_ts[analyzers/typescript.py<br/>TypeScript Analyzer]
        end
    end

    subgraph "Additional Analysis"
        circular[circular_deps/<br/>Circular Dependency Detection]
        dead_code[dead_code/<br/>Dead Code Detection]
        call_graph[call_graph/<br/>Call Graph Analysis]
        patterns[patterns/<br/>Pattern Detection]
    end

    %% Entry flow
    main --> analysis
    analysis --> parsers_python
    analysis --> parsers_go
    analysis --> parsers_ts
    
    %% Parser to metrics flow
    parsers_python --> metrics_cognitive
    parsers_python --> metrics_halstead
    parsers_python --> metrics_cyclomatic
    parsers_go --> metrics_cognitive
    parsers_go --> metrics_halstead
    parsers_go --> metrics_cyclomatic
    parsers_ts --> metrics_cognitive
    parsers_ts --> metrics_halstead
    parsers_ts --> metrics_cyclomatic
    
    %% Metrics to analyzers flow
    metrics_cognitive --> analyzers_common
    metrics_halstead --> analyzers_common
    metrics_cyclomatic --> analyzers_common
    metrics_npath --> analyzers_common
    metrics_dtd --> analyzers_common
    metrics_lloc --> analyzers_common
    metrics_duplication --> analyzers_common
    metrics_fatness --> analyzers_common
    
    %% Analyzers to models
    analyzers_common --> models
    analyzers_python --> models
    analyzers_go --> models
    analyzers_ts --> models
    
    %% Shared utilities
    parsers_shared -.-> parsers_python
    parsers_shared -.-> parsers_go
    parsers_shared -.-> parsers_ts
    
    metrics_common -.-> metrics_cognitive
    metrics_common -.-> metrics_halstead
    
    analyzers_shared -.-> analyzers_python
    analyzers_shared -.-> analyzers_go
    analyzers_shared -.-> analyzers_ts
    
    %% Additional analysis connections
    models -.-> circular
    models -.-> dead_code
    models -.-> call_graph
    models -.-> patterns
    
    style models fill:#f9f,stroke:#333,stroke-width:4px
    style main fill:#bbf,stroke:#333,stroke-width:2px
    style analyzers_common fill:#bfb,stroke:#333,stroke-width:2px
```

## Key Relationships Explained

### Data Flow Pattern
1. **Entry** → `main.py` or `analysis.py` functions
2. **Parse** → Language-specific parsers extract AST nodes
3. **Compute** → Metrics layer calculates complexity values
4. **Assemble** → Analyzers combine metrics into `FileComplexity`
5. **Report** → Results aggregated for output

### Three-Layer Architecture
- **Parsers** (`parsers/`): Language-specific AST parsing
- **Metrics** (`metrics/`): Individual complexity calculations  
- **Analyzers** (`analyzers/`): Orchestration and result assembly

### Shared Components
- `models.py`: Core data structures
- `common.py`: Shared metric utilities (Halstead, boolean scoring)
- `analyzers/shared.py`: Generic analysis wrapper
- `parsers/shared.py`: Parser utilities

### Language Support
Each supported language (Python, Go, TypeScript) has implementations across all three layers, enabling consistent analysis regardless of source language.