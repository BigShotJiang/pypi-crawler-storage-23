"""Tests for pattern checking dispatch."""

from vibelexity.parsers.python import parse as parse_py
from vibelexity.parsers.typescript import parse as parse_ts
from vibelexity.parsers.go import parse as parse_go
from vibelexity.patterns import check_patterns


def test_python_patterns_dispatch():
    """Python patterns are dispatched to Python checker."""
    code = """
# Module-level execution
foo = 42
"""
    root = parse_py(code)
    violations = check_patterns("python", root)
    assert isinstance(violations, list)


def test_python_patterns_with_filter():
    """Specific pattern can be filtered."""
    code = """
# No patterns
def foo():
    pass
"""
    root = parse_py(code)
    violations = check_patterns("python", root, patterns=["check_wildcard_imports"])
    assert isinstance(violations, list)


def test_typescript_patterns_dispatch():
    """TypeScript returns empty list (not implemented)."""
    code = """
const foo = 42;
"""
    root = parse_ts(code)
    violations = check_patterns("typescript", root)
    assert violations == []


def test_go_patterns_dispatch():
    """Go returns empty list (not implemented)."""
    code = """
func foo() {
    fmt.Println("hello")
}
"""
    root = parse_go(code)
    violations = check_patterns("go", root)
    assert violations == []


def test_invalid_language_dispatch():
    """Invalid language returns empty list."""
    code = "foo"
    violations = check_patterns("invalid", None)
    assert violations == []
