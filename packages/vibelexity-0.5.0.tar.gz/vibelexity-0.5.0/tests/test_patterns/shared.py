"""Tests for shared pattern detection utilities."""

from vibelexity.parsers.python import parse

from vibelexity.patterns.shared import check_patterns


def test_check_patterns_python_empty_filters():
    """Python with empty patterns list returns no violations."""
    code = """
import os

def foo():
    pass
"""
    root = parse(code)
    violations = check_patterns("python", root, patterns=[])
    assert violations == []


def test_check_patterns_python_specific_pattern():
    """Can run specific pattern checks."""
    code = """
import os

def foo():
    import sys
"""
    root = parse(code)
    violations = check_patterns("python", root, patterns=["check_nested_imports"])
    assert len(violations) == 1
    assert violations[0].type == "nested_import"


def test_check_patterns_python_all_patterns():
    """Can run all pattern checks for Python."""
    code = """
import os
from foo import *

def foo():
    import sys
    return x
"""
    root = parse(code)
    violations = check_patterns("python", root, patterns=None)
    assert len(violations) >= 2


def test_check_patterns_typescript_empty():
    """TypeScript patterns return empty list."""
    code = "function foo() {}"
    root = parse(code)
    violations = check_patterns("typescript", root)
    assert violations == []


def test_check_patterns_go_empty():
    """Go patterns return empty list."""
    code = "package main; func foo() {}"
    root = parse(code)
    violations = check_patterns("go", root)
    assert violations == []


def test_check_patterns_unknown_language():
    """Unknown language returns empty list."""
    code = "foo"
    root = parse(code)
    violations = check_patterns("unknown", root)
    assert violations == []


def test_check_patterns_invalid_pattern_name():
    """Invalid pattern names are ignored."""
    code = """
import os

def foo():
    pass
"""
    root = parse(code)
    violations = check_patterns("python", root, patterns=["invalid_pattern"])
    assert violations == []


def test_check_patterns_typescript_with_filter():
    """TypeScript patterns with filter still return empty."""
    code = "function foo() {}"
    root = parse(code)
    violations = check_patterns("typescript", root, patterns=["any_pattern"])
    assert violations == []


def test_check_patterns_go_with_filter():
    """Go patterns with filter still return empty."""
    code = "func foo() {}"
    root = parse(code)
    violations = check_patterns("go", root, patterns=["any_pattern"])
    assert violations == []


def test_check_patterns_mixed_valid_invalid():
    """Some valid, some invalid patterns are processed correctly."""
    code = """
import os

def foo():
    pass

def bar():
    pass
"""
    root = parse(code)
    violations = check_patterns(
        "python", root, patterns=["invalid_pattern", "check_nested_imports"]
    )
    assert violations == []
