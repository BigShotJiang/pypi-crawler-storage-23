"""Tests for TypeScript pattern detection."""

from vibelexity.patterns.typescript import (
    check_all_patterns,
    check_angle_assertion,
    check_any_generic_constraint,
    check_any_type,
    check_as_assertion,
    check_double_casting,
    check_empty_interface,
    check_enum_declaration,
    check_function_type,
    check_missing_readonly,
    check_non_arrow_method,
    check_non_null_assertion,
    check_over_optional_interface,
    check_private_keyword,
    check_wrapper_type,
)
from vibelexity.patterns.shared import check_patterns
from vibelexity.parsers.typescript import parse


def test_any_type_basic():
    """Detect explicit any type annotations."""
    code = """
function foo(x: any): any {
    const y: any = x;
    return y;
}
"""
    root = parse(code)
    violations = check_any_type(root)

    assert len(violations) == 3
    assert all(v.type == "any_type" for v in violations)
    assert violations[0].line == 2


def test_any_type_not_flagged():
    """Other types should not be flagged."""
    code = """
function foo(x: string): number {
    const y: boolean = true;
    return 1;
}
"""
    root = parse(code)
    violations = check_any_type(root)

    assert len(violations) == 0


def test_non_null_assertion_basic():
    """Detect non-null assertion operator."""
    code = """
const a = obj!.prop;
const b = getValue()!;
"""
    root = parse(code)
    violations = check_non_null_assertion(root)

    assert len(violations) == 2
    assert all(v.type == "non_null_assertion" for v in violations)


def test_non_null_not_flagged():
    """Regular property access should not be flagged."""
    code = """
const a = obj.prop;
const b = getValue();
"""
    root = parse(code)
    violations = check_non_null_assertion(root)

    assert len(violations) == 0


def test_as_assertion_basic():
    """Detect 'as' type assertions."""
    code = """
const c = x as string;
const d = y as unknown as MyType;
"""
    root = parse(code)
    violations = check_as_assertion(root)

    assert len(violations) == 3
    assert all(v.type == "as_assertion" for v in violations)


def test_as_assertion_not_flagged():
    """Regular declarations should not be flagged."""
    code = """
const c = x;
const d: string = y;
"""
    root = parse(code)
    violations = check_as_assertion(root)

    assert len(violations) == 0


def test_angle_assertion_basic():
    """Detect angle-bracket type assertions."""
    code = """
const d = <string>x;
const e = <MyType>getValue();
"""
    root = parse(code)
    violations = check_angle_assertion(root, tsx=False)

    assert len(violations) == 2
    assert all(v.type == "angle_assertion" for v in violations)


def test_angle_assertion_tsx_skip():
    """Angle-bracket assertions should be skipped in TSX."""
    code = """
const d = <string>x;
"""
    root = parse(code)
    violations = check_angle_assertion(root, tsx=True)

    assert len(violations) == 0


def test_enum_declaration_basic():
    """Detect enum declarations."""
    code = """
enum Color { Red, Green, Blue }

enum Status {
  Active = "active",
  Inactive = "inactive"
}
"""
    root = parse(code)
    violations = check_enum_declaration(root)

    assert len(violations) == 2
    assert all(v.type == "enum_declaration" for v in violations)


def test_enum_not_flagged():
    """Union types should not be flagged."""
    code = """
type Color = "red" | "green" | "blue";
type Status = "active" | "inactive";
"""
    root = parse(code)
    violations = check_enum_declaration(root)

    assert len(violations) == 0


def test_function_type_basic():
    """Detect 'Function' type annotation."""
    code = """
const fn: Function = () => {};
function acceptFn(cb: Function): void {}
"""
    root = parse(code)
    violations = check_function_type(root)

    assert len(violations) == 2
    assert all(v.type == "function_type" for v in violations)


def test_function_type_not_flagged():
    """Explicit function signatures should not be flagged."""
    code = """
const fn: () => void = () => {};
function acceptFn(cb: (x: number) => string): void {}
"""
    root = parse(code)
    violations = check_function_type(root)

    assert len(violations) == 0


def test_missing_readonly_basic():
    """Detect arrays without readonly in function parameters."""
    code = """
function process(items: string[]): void {}
function transform(data: number[], opts: boolean[]): number[] {}
"""
    root = parse(code)
    violations = check_missing_readonly(root)

    assert len(violations) == 3
    assert all(v.type == "missing_readonly" for v in violations)


def test_missing_readonly_with_readonly():
    """Arrays with readonly should not be flagged."""
    code = """
function process(items: readonly string[]): void {}
function transform(data: readonly number[]): number[] {}
"""
    root = parse(code)
    violations = check_missing_readonly(root)

    assert len(violations) == 0


def test_missing_readonly_not_in_param():
    """Arrays not in function parameters should not be flagged."""
    code = """
const items: string[] = [];
function process(): string[] {
    return [];
}
"""
    root = parse(code)
    violations = check_missing_readonly(root)

    assert len(violations) == 0


def test_all_patterns():
    """Test check_all_patterns runs all checkers."""
    code = """
function foo(x: any): any {
    const a = obj!.prop;
    const b = x as string;
    const c = <number>x;
    return y;
}

enum Color { Red }

const fn: Function = () => {};

function process(items: string[]): void {}
"""
    root = parse(code)
    violations = check_all_patterns(root, tsx=False)

    types = {v.type for v in violations}
    assert "any_type" in types
    assert "non_null_assertion" in types
    assert "as_assertion" in types
    assert "angle_assertion" in types
    assert "enum_declaration" in types
    assert "function_type" in types
    assert "missing_readonly" in types


def test_all_patterns_tsx():
    """Test check_all_patterns skips angle assertions in TSX."""
    code = """
const c = <number>x;
"""
    root = parse(code)
    violations = check_all_patterns(root, tsx=True)

    types = {v.type for v in violations}
    assert "angle_assertion" not in types


def test_check_patterns_integration():
    """Test check_patterns dispatch for TypeScript."""
    code = """
function foo(x: any): any {
    const a = obj!.prop;
    return a;
}
"""
    root = parse(code)
    violations = check_patterns("typescript", root)

    assert len(violations) >= 2
    types = {v.type for v in violations}
    assert "any_type" in types
    assert "non_null_assertion" in types


def test_ignore_comment_any_type():
    """Ignore comment should suppress any_type."""
    code = """// vibelexity-ignore:any-type
function foo(x: any): any {
    return x;
}
"""
    root = parse(code)
    violations = check_patterns("typescript", root, source=code)

    assert not any(v.type == "any_type" for v in violations)


def test_ignore_comment_non_null():
    """Ignore comment should suppress non_null_assertion."""
    code = """// vibelexity-ignore:non-null
const a = obj!.prop;
"""
    root = parse(code)
    violations = check_patterns("typescript", root, source=code)

    assert not any(v.type == "non_null_assertion" for v in violations)


def test_ignore_comment_multiple():
    """Ignore comment with multiple patterns."""
    code = """// vibelexity-ignore:any-type, non-null
function foo(x: any): any {
    const a = obj!.prop;
    return a;
}
"""
    root = parse(code)
    violations = check_patterns("typescript", root, source=code)

    assert not any(v.type == "any_type" for v in violations)
    assert not any(v.type == "non_null_assertion" for v in violations)


def test_ignore_comment_as_assertion():
    """Ignore comment should suppress as_assertion."""
    code = """// vibelexity-ignore:as-assertion
const a = x as string;
"""
    root = parse(code)
    violations = check_patterns("typescript", root, source=code)

    assert not any(v.type == "as_assertion" for v in violations)


def test_ignore_comment_enum():
    """Ignore comment should suppress enum_declaration."""
    code = """// vibelexity-ignore:enum
enum Color { Red, Green, Blue }
"""
    root = parse(code)
    violations = check_patterns("typescript", root, source=code)

    assert not any(v.type == "enum_declaration" for v in violations)


def test_analyzer_integration():
    """Test that analyze_source includes pattern violations."""
    from vibelexity.analyzers.typescript import analyze_source

    code = """
function foo(x: any): any {
    const a = obj!.prop;
    return a;
}
"""
    result = analyze_source(code, tsx=False)

    assert len(result.pattern_violations) >= 2
    types = {v.type for v in result.pattern_violations}
    assert "any_type" in types
    assert "non_null_assertion" in types


def test_analyzer_tsx_skips_angle():
    """Test that analyze_source with tsx=True skips angle assertions."""
    from vibelexity.analyzers.typescript import analyze_source

    code = """
const c = <number>x;
"""
    result = analyze_source(code, tsx=True)

    assert not any(v.type == "angle_assertion" for v in result.pattern_violations)


def test_private_keyword_field():
    """Detect 'private' keyword on class fields."""
    code = """
class User {
    private id: string;
    private secretValue: number;
    public name: string;
}
"""
    root = parse(code)
    violations = check_private_keyword(root)

    assert len(violations) == 2
    assert all(v.type == "private_keyword" for v in violations)
    assert violations[0].line == 3


def test_private_keyword_method():
    """Detect 'private' keyword on class methods."""
    code = """
class User {
    private getSecret() {
        return this.secret;
    }
    public publicMethod() {}
}
"""
    root = parse(code)
    violations = check_private_keyword(root)

    assert len(violations) == 1
    assert violations[0].type == "private_keyword"
    assert violations[0].line == 3


def test_private_keyword_not_flagged():
    """Hard-private # fields and other modifiers should not be flagged."""
    code = """
class User {
    #trulyPrivate: string;
    public name: string;
    protected value: number;
}
"""
    root = parse(code)
    violations = check_private_keyword(root)

    assert len(violations) == 0


def test_non_arrow_method_basic():
    """Detect regular class methods that could lose context."""
    code = """
class Component {
    handleClick() {
        console.log('clicked');
    }
    process() {
        return 1;
    }
}
"""
    root = parse(code)
    violations = check_non_arrow_method(root)

    assert len(violations) == 2
    assert all(v.type == "non_arrow_method" for v in violations)


def test_non_arrow_method_arrow_not_flagged():
    """Arrow function properties should not be flagged."""
    code = """
class Component {
    handleClick = () => {
        console.log('clicked');
    };
}
"""
    root = parse(code)
    violations = check_non_arrow_method(root)

    assert len(violations) == 0


def test_non_arrow_method_getter_setter_not_flagged():
    """Getters and setters should not be flagged."""
    code = """
class User {
    private _name: string;

    get name(): string {
        return this._name;
    }

    set name(value: string) {
        this._name = value;
    }
}
"""
    root = parse(code)
    violations = check_non_arrow_method(root)

    assert len(violations) == 0


def test_non_arrow_method_private_not_flagged():
    """Methods with explicit modifier (private/public/protected) should not be flagged."""
    code = """
class Component {
    private handleClick() {
        console.log('clicked');
    }
    public process() {
        return 1;
    }
}
"""
    root = parse(code)
    violations = check_non_arrow_method(root)

    assert len(violations) == 0


def test_all_patterns_includes_new():
    """Test check_all_patterns includes private_keyword and non_arrow_method."""
    code = """
class User {
    private id: string;
    handleClick() {
        console.log('click');
    }
}
"""
    root = parse(code)
    violations = check_all_patterns(root)

    types = {v.type for v in violations}
    assert "private_keyword" in types
    assert "non_arrow_method" in types


def test_ignore_comment_private_keyword():
    """Ignore comment should suppress private_keyword."""
    code = """// vibelexity-ignore:private-keyword
class User {
    private id: string;
}
"""
    root = parse(code)
    violations = check_patterns("typescript", root, source=code)

    assert not any(v.type == "private_keyword" for v in violations)


def test_ignore_comment_non_arrow_method():
    """Ignore comment should suppress non_arrow_method."""
    code = """// vibelexity-ignore:non-arrow-method
class Component {
    handleClick() {
        console.log('click');
    }
}
"""
    root = parse(code)
    violations = check_patterns("typescript", root, source=code)

    assert not any(v.type == "non_arrow_method" for v in violations)


def test_empty_interface_basic():
    """Detect empty interface declarations."""
    code = """
interface User {}

interface Config {}
"""
    root = parse(code)
    violations = check_empty_interface(root)

    assert len(violations) == 2
    assert all(v.type == "empty_interface" for v in violations)


def test_empty_interface_with_members_not_flagged():
    """Interfaces with members should not be flagged."""
    code = """
interface User {
    name: string;
    id: number;
}

interface Config {
    debug: boolean;
}
"""
    root = parse(code)
    violations = check_empty_interface(root)

    assert len(violations) == 0


def test_empty_interface_extends():
    """Empty interfaces extending others should still be flagged."""
    code = """
interface User extends Base {}

interface Config extends Record<string, unknown> {}
"""
    root = parse(code)
    violations = check_empty_interface(root)

    assert len(violations) == 2
    assert all(v.type == "empty_interface" for v in violations)


def test_wrapper_type_basic():
    """Detect Number, String, Boolean wrapper types."""
    code = """
const count: Number = 5;
const name: String = "test";
const flag: Boolean = true;
"""
    root = parse(code)
    violations = check_wrapper_type(root)

    assert len(violations) == 3
    types = {v.type for v in violations}
    assert types == {"wrapper_type"}


def test_wrapper_type_primitives_not_flagged():
    """Primitive types should not be flagged."""
    code = """
const count: number = 5;
const name: string = "test";
const flag: boolean = true;
"""
    root = parse(code)
    violations = check_wrapper_type(root)

    assert len(violations) == 0


def test_wrapper_type_function_params():
    """Wrapper types in function parameters should be detected."""
    code = """
function process(n: Number, s: String): Boolean {
    return true;
}
"""
    root = parse(code)
    violations = check_wrapper_type(root)

    assert len(violations) == 3


def test_wrapper_type_generic_not_flagged():
    """Generic type parameters should not be flagged."""
    code = """
function wrap<T>(value: T): T {
    return value;
}
const x: MyNumber = 5;
"""
    root = parse(code)
    violations = check_wrapper_type(root)

    assert len(violations) == 0


def test_all_patterns_includes_empty_interface():
    """Test check_all_patterns includes empty_interface."""
    code = """
interface User {}
"""
    root = parse(code)
    violations = check_all_patterns(root)

    types = {v.type for v in violations}
    assert "empty_interface" in types


def test_all_patterns_includes_wrapper_type():
    """Test check_all_patterns includes wrapper_type."""
    code = """
const x: Number = 5;
"""
    root = parse(code)
    violations = check_all_patterns(root)

    types = {v.type for v in violations}
    assert "wrapper_type" in types


def test_ignore_comment_empty_interface():
    """Ignore comment should suppress empty_interface."""
    code = """// vibelexity-ignore:empty-interface
interface User {}
"""
    root = parse(code)
    violations = check_patterns("typescript", root, source=code)

    assert not any(v.type == "empty_interface" for v in violations)


def test_ignore_comment_wrapper_type():
    """Ignore comment should suppress wrapper_type."""
    code = """// vibelexity-ignore:wrapper-type
const x: Number = 5;
"""
    root = parse(code)
    violations = check_patterns("typescript", root, source=code)

    assert not any(v.type == "wrapper_type" for v in violations)


def test_double_casting_basic():
    """Detect double casting pattern (x as unknown) as T."""
    code = """
const user = (data as unknown) as User;
const config = (result as any) as Config;
"""
    root = parse(code)
    violations = check_double_casting(root)

    assert len(violations) == 2
    assert all(v.type == "double_casting" for v in violations)
    assert violations[0].line == 2


def test_double_casting_chained():
    """Detect double casting without parentheses."""
    code = """
const x = data as unknown as MyType;
"""
    root = parse(code)
    violations = check_double_casting(root)

    assert len(violations) == 1
    assert violations[0].type == "double_casting"
    assert violations[0].line == 2


def test_double_casting_single_not_flagged():
    """Single type assertion should not be flagged."""
    code = """
const x = data as string;
const y = value as unknown;
const z = result as User;
"""
    root = parse(code)
    violations = check_double_casting(root)

    assert len(violations) == 0


def test_double_casting_triple():
    """Triple casting should only flag once."""
    code = """
const x = ((data as unknown) as any) as MyType;
"""
    root = parse(code)
    violations = check_double_casting(root)

    assert len(violations) == 1
    assert violations[0].type == "double_casting"


def test_any_generic_constraint_basic():
    """Detect <T extends any> generic constraints."""
    code = """
function handle<T extends any>(input: T) {}
class Container<T extends any> {}
interface Factory<T extends any> {}
"""
    root = parse(code)
    violations = check_any_generic_constraint(root)

    assert len(violations) == 3
    assert all(v.type == "any_generic_constraint" for v in violations)


def test_any_generic_constraint_complex():
    """Detect extends any with multiple type parameters."""
    code = """
function transform<T extends any, U>(x: T, y: U) {}
"""
    root = parse(code)
    violations = check_any_generic_constraint(root)

    assert len(violations) == 1
    assert violations[0].line == 2


def test_any_generic_constraint_object_not_flagged():
    """Extends object should not be flagged."""
    code = """
function handle<T extends object>(input: T) {}
"""
    root = parse(code)
    violations = check_any_generic_constraint(root)

    assert len(violations) == 0


def test_any_generic_constraint_no_constraint_not_flagged():
    """Type parameter without constraint should not be flagged."""
    code = """
function handle<T>(input: T) {}
"""
    root = parse(code)
    violations = check_any_generic_constraint(root)

    assert len(violations) == 0


def test_any_generic_constraint_other_types_not_flagged():
    """Other constraint types should not be flagged."""
    code = """
function handle<T extends string>(input: T) {}
function process<T extends SomeType>(input: T) {}
"""
    root = parse(code)
    violations = check_any_generic_constraint(root)

    assert len(violations) == 0


def test_over_optional_interface_basic():
    """Detect interfaces where all properties are optional (≥2 properties)."""
    code = """
interface Settings {
    theme?: string;
    fontSize?: number;
}
"""
    root = parse(code)
    violations = check_over_optional_interface(root)

    assert len(violations) == 1
    assert violations[0].type == "over_optional_interface"
    assert violations[0].line == 2


def test_over_optional_interface_many_properties():
    """Detect interface with 5+ all-optional properties."""
    code = """
interface Config {
    a?: string;
    b?: number;
    c?: boolean;
    d?: object;
    e?: symbol;
}
"""
    root = parse(code)
    violations = check_over_optional_interface(root)

    assert len(violations) == 1
    assert violations[0].type == "over_optional_interface"


def test_over_optional_interface_mixed_not_flagged():
    """Mixed optional/required should not be flagged."""
    code = """
interface User {
    id: number;
    name?: string;
    email?: string;
}
"""
    root = parse(code)
    violations = check_over_optional_interface(root)

    assert len(violations) == 0


def test_over_optional_interface_single_optional_not_flagged():
    """Single optional property interface should not be flagged."""
    code = """
interface Single {
    name?: string;
}
"""
    root = parse(code)
    violations = check_over_optional_interface(root)

    assert len(violations) == 0


def test_over_optional_interface_all_required_not_flagged():
    """All required properties should not be flagged."""
    code = """
interface Required {
    id: number;
    name: string;
}
"""
    root = parse(code)
    violations = check_over_optional_interface(root)

    assert len(violations) == 0


def test_over_optional_interface_with_methods():
    """Interface with methods should still check property signatures only."""
    code = """
interface Handler {
    data?: string;
    process?(): void;
}
"""
    root = parse(code)
    violations = check_over_optional_interface(root)

    assert len(violations) == 0


def test_all_patterns_includes_double_casting():
    """Test check_all_patterns includes double_casting."""
    code = """
const x = (data as unknown) as User;
"""
    root = parse(code)
    violations = check_all_patterns(root)

    types = {v.type for v in violations}
    assert "double_casting" in types


def test_all_patterns_includes_any_generic_constraint():
    """Test check_all_patterns includes any_generic_constraint."""
    code = """
function handle<T extends any>(x: T) {}
"""
    root = parse(code)
    violations = check_all_patterns(root)

    types = {v.type for v in violations}
    assert "any_generic_constraint" in types


def test_all_patterns_includes_over_optional_interface():
    """Test check_all_patterns includes over_optional_interface."""
    code = """
interface X {
    a?: string;
    b?: number;
}
"""
    root = parse(code)
    violations = check_all_patterns(root)

    types = {v.type for v in violations}
    assert "over_optional_interface" in types


def test_ignore_comment_double_casting():
    """Ignore comment should suppress double_casting."""
    code = """// vibelexity-ignore:double-casting
const x = (data as unknown) as User;
"""
    root = parse(code)
    violations = check_patterns("typescript", root, source=code)

    assert not any(v.type == "double_casting" for v in violations)


def test_ignore_comment_any_generic_constraint():
    """Ignore comment should suppress any_generic_constraint."""
    code = """// vibelexity-ignore:any-generic
function handle<T extends any>(x: T) {}
"""
    root = parse(code)
    violations = check_patterns("typescript", root, source=code)

    assert not any(v.type == "any_generic_constraint" for v in violations)


def test_ignore_comment_over_optional_interface():
    """Ignore comment should suppress over_optional_interface."""
    code = """// vibelexity-ignore:over-optional
interface X {
    a?: string;
    b?: number;
}
"""
    root = parse(code)
    violations = check_patterns("typescript", root, source=code)

    assert not any(v.type == "over_optional_interface" for v in violations)
