from __future__ import annotations

import os
import shutil
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from vibelexity.circular_deps import find_cycles
from vibelexity.circular_deps.parsers.python import PythonImportParser
from vibelexity.circular_deps.parsers.typescript import TypeScriptImportParser
from vibelexity.analysis import _compute_cycle_stats


def test_python_type_checking_import_detection():
    parser = PythonImportParser()
    source = """
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from mymodule import MyType
    from .localmod import LocalType

from regular import RegularClass
import os
"""
    imports = parser.extract_imports(source, "test.py")
    assert len(imports) == 5

    type_imports = [imp for imp in imports if imp.is_type_import]
    runtime_imports = [imp for imp in imports if not imp.is_type_import]

    assert len(type_imports) == 2
    assert len(runtime_imports) == 3

    assert type_imports[0].raw_module == "mymodule"
    assert type_imports[1].raw_module == ".localmod"

    runtime_modules = {imp.raw_module for imp in runtime_imports}
    assert "regular" in runtime_modules
    assert "os" in runtime_modules
    assert "typing" in runtime_modules


def test_typescript_import_type_detection():
    parser = TypeScriptImportParser()
    source = """
import type { Foo } from "./bar";
import { type Bar } from "./baz";
import { normal } from "./qux";
import { type Mixed, runtime } from "./mixed";
"""
    imports = parser.extract_imports(source, "test.ts")
    assert len(imports) == 5

    type_imports = [imp for imp in imports if imp.is_type_import]
    runtime_imports = [imp for imp in imports if not imp.is_type_import]

    assert len(type_imports) == 3
    assert len(runtime_imports) == 2

    type_modules = {imp.raw_module for imp in type_imports}
    runtime_modules = {imp.raw_module for imp in runtime_imports}

    assert "./bar" in type_modules
    assert "./baz" in type_modules
    assert "./mixed" in type_modules
    assert "./qux" in runtime_modules
    assert "./mixed" in runtime_modules


def test_python_type_only_cycle_detection():
    tmpdir = Path(tempfile.mkdtemp())
    try:
        a_py = tmpdir / "a.py"
        b_py = tmpdir / "b.py"

        a_py.write_text(
            """
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from b import MyType

def func_a():
    pass
"""
        )
        b_py.write_text(
            """
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from a import func_a

class MyType:
    pass
"""
        )

        cycles = find_cycles([a_py, b_py])

        assert len(cycles) == 1
        assert cycles[0].is_type_cycle is True
        assert cycles[0].depth == 2
    finally:
        shutil.rmtree(tmpdir)


def test_python_runtime_cycle_detection():
    tmpdir = Path(tempfile.mkdtemp())
    try:
        a_py = tmpdir / "a.py"
        b_py = tmpdir / "b.py"

        a_py.write_text("from b import func_b\ndef func_a(): pass")
        b_py.write_text("from a import func_a\ndef func_b(): pass")

        cycles = find_cycles([a_py, b_py])

        assert len(cycles) == 1
        assert cycles[0].is_type_cycle is False
        assert cycles[0].depth == 2
    finally:
        shutil.rmtree(tmpdir)


def test_python_mixed_runtime_and_type_cycles():
    tmpdir = Path(tempfile.mkdtemp())
    try:
        a_py = tmpdir / "a.py"
        b_py = tmpdir / "b.py"
        c_py = tmpdir / "c.py"

        a_py.write_text("from b import func_b\ndef func_a(): pass")
        b_py.write_text(
            """
from a import func_a
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from c import TypeC

def func_b():
    pass
"""
        )
        c_py.write_text(
            """
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from b import TypeB

class TypeC:
    pass
"""
        )

        cycles = find_cycles([a_py, b_py, c_py])

        assert len(cycles) == 2

        runtime_cycles = [c for c in cycles if not c.is_type_cycle]
        type_cycles = [c for c in cycles if c.is_type_cycle]

        assert len(runtime_cycles) == 1
        assert len(type_cycles) == 1

        stats = _compute_cycle_stats(cycles)
        assert stats["num_runtime_cycles"] == 1
        assert stats["num_type_cycles"] == 1
    finally:
        shutil.rmtree(tmpdir)


def test_cycle_stats_separate_counts():
    tmpdir = Path(tempfile.mkdtemp())
    try:
        a_py = tmpdir / "a.py"
        b_py = tmpdir / "b.py"
        c_py = tmpdir / "c.py"

        a_py.write_text("from b import x\ndef a(): pass")
        b_py.write_text("from a import a\ndef x(): pass")
        c_py.write_text(
            """
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from a import a
class C: pass
"""
        )
        a_py.write_text(
            """
from b import x
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from c import C
def a(): pass
"""
        )

        cycles = find_cycles([a_py, b_py, c_py])
        stats = _compute_cycle_stats(cycles)

        assert stats["num_cycles"] >= 1
        assert "num_runtime_cycles" in stats
        assert "num_type_cycles" in stats
        assert "runtime_cycle_length_stats" in stats
        assert "type_cycle_length_stats" in stats
        assert "runtime_cycles" in stats
        assert "type_cycles" in stats
    finally:
        shutil.rmtree(tmpdir)
