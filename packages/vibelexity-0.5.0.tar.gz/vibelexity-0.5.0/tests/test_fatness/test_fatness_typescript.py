"""Tests for TypeScript parameter counting in fatness metrics."""

from vibelexity.metrics.fatness.typescript import param_count
from vibelexity.parsers.typescript import TS_LANGUAGE, parse as parse_ts


def test_zero_params():
    """Function with no parameters."""
    code = """
function foo(): number {
    return 42;
}
"""
    root = parse_ts(code)
    func = list(root.children)[0]
    assert param_count(func) == 0


def test_single_param():
    """Function with single parameter."""
    code = """
function foo(x: number): number {
    return x;
}
"""
    root = parse_ts(code)
    func = list(root.children)[0]
    assert param_count(func) == 1


def test_multiple_params():
    """Function with multiple parameters."""
    code = """
function foo(x: number, y: string, z: boolean): number {
    return 42;
}
"""
    root = parse_ts(code)
    func = list(root.children)[0]
    assert param_count(func) == 3


def test_with_default_params():
    """Function with default parameters."""
    code = """
function foo(x: number, y: number = 10): number {
    return x + y;
}
"""
    root = parse_ts(code)
    func = list(root.children)[0]
    assert param_count(func) == 2


def test_with_rest_param():
    """Function with rest parameter."""
    code = """
function foo(x: number, ...y: number[]): number {
    return x;
}
"""
    root = parse_ts(code)
    func = list(root.children)[0]
    assert param_count(func) == 2


def test_long_parameter_list():
    """Function with many parameters."""
    code = """
function foo(a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number): number {
    return 42;
}
"""
    root = parse_ts(code)
    func = list(root.children)[0]
    assert param_count(func) == 10


def test_arrow_function_with_params():
    """Arrow function with parameters."""
    code = """
const foo = (x: number, y: string): number => {
    return 42;
};
"""
    root = parse_ts(code)
    func = list(root.children)[0].children[1].children[2]
    assert param_count(func) == 2


def test_arrow_function_no_params():
    """Arrow function with no parameters."""
    code = """
const foo = (): number => {
    return 42;
};
"""
    root = parse_ts(code)
    func = list(root.children)[0].children[1].children[0]
    assert param_count(func) == 0
