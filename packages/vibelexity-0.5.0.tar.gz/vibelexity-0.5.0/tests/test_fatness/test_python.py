"""Tests for Python parameter counting in fatness metrics."""

from vibelexity.metrics.fatness.python import param_count
from vibelexity.parsers.python import parse as parse_py


def test_zero_params():
    """Function with no parameters."""
    code = """
def foo():
    return 42
"""
    func = list(parse_py(code).children)[0]
    assert param_count(func) == 0


def test_single_param():
    """Function with single parameter."""
    code = """
def foo(x):
    return x
"""
    func = list(parse_py(code).children)[0]
    assert param_count(func) == 1


def test_multiple_params():
    """Function with multiple parameters."""
    code = """
def foo(x, y, z):
    return x + y + z
"""
    func = list(parse_py(code).children)[0]
    assert param_count(func) == 3


def test_with_default_params():
    """Function with default parameters."""
    code = """
def foo(x, y=10, z=20):
    return x + y + z
"""
    func = list(parse_py(code).children)[0]
    assert param_count(func) == 3


def test_with_keyword_only_params():
    """Function with keyword-only parameters."""
    code = """
def foo(x, *, y, z):
    return x + y + z
"""
    func = list(parse_py(code).children)[0]
    assert param_count(func) == 3


def test_with_args_kw_args():
    """Function with *args and **kwargs."""
    code = """
def foo(x, *args, **kwargs):
    return x
"""
    func = list(parse_py(code).children)[0]
    assert param_count(func) == 1


def test_long_parameter_list():
    """Function with many parameters."""
    code = """
def foo(a, b, c, d, e, f, g, h, i, j):
    return 42
"""
    func = list(parse_py(code).children)[0]
    assert param_count(func) == 10
