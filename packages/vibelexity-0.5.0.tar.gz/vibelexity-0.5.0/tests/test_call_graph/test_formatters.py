"""Tests for DOT format and external call filtering."""

from __future__ import annotations

from pathlib import Path
import tempfile

from vibelexity.call_graph import build_call_graph
from vibelexity.call_graph.formatters import format_dot


def test_format_dot():
    code = """
    def foo():
        bar()
    
    def bar():
        baz()
    
    def baz():
        pass
    """
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
        f.write(code)
        f.flush()

        graph = build_call_graph([Path(f.name)])
        dot_output = format_dot(graph)

        assert "digraph call_graph" in dot_output
        # Node IDs now use filepath:function_name format
        filepath = f.name
        assert f'"{filepath}:foo" -> "{filepath}:bar"' in dot_output
        assert f'"{filepath}:bar" -> "{filepath}:baz"' in dot_output

        Path(f.name).unlink()


def test_format_dot_filters_external():
    code = """
    def foo():
        print("hello")
        bar()
    
    def bar():
        pass
    """
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
        f.write(code)
        f.flush()

        graph = build_call_graph([Path(f.name)])
        dot_output = format_dot(graph)

        # External calls should be filtered out
        assert "print" not in dot_output
        # Only internal calls should appear
        filepath = f.name
        assert f'"{filepath}:foo" -> "{filepath}:bar"' in dot_output

        Path(f.name).unlink()
