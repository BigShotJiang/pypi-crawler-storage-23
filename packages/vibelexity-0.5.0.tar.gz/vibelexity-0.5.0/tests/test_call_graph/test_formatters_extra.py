"""Additional tests for call_graph/formatters."""

from pathlib import Path

from vibelexity.call_graph.formatters import format_dot
from vibelexity.models import CallGraph, CallEdge, FunctionDefinition


def test_format_dot_value_error_on_relative_path():
    """Test ValueError when computing relative path (paths don't share common prefix)."""
    graph = CallGraph(
        functions={
            ("foo", "/some/absolute/path/file.py"): FunctionDefinition(
                name="foo",
                filepath="/some/absolute/path/file.py",
                line=1,
                def_type="function",
            )
        },
        calls=[
            CallEdge(
                caller_file="/some/absolute/path/file.py",
                caller_function="foo",
                caller_line=5,
                callee_file="/some/absolute/path/file.py",
                callee_function="foo",
                callee_line=1,
                call_site_line=5,
                call_type="local",
            )
        ],
    )

    # base_path that doesn't share directory with absolute paths
    base_path = "/completely/different/path"

    result = format_dot(graph, base_path=base_path)

    # Should handle ValueError gracefully and use absolute path
    assert result is not None
    assert "digraph call_graph" in result
    # Should contain the filepath since it couldn't be made relative
    assert "/some/absolute/path/file.py" in result


def test_format_dot_relative_path_with_quotes():
    """Test proper escaping of quotes in file paths."""
    graph = CallGraph(
        functions={
            ("foo", "/path/to/quoted/file.py"): FunctionDefinition(
                name="foo",
                filepath="/path/to/quoted/file.py",
                line=1,
                def_type="function",
            )
        },
        calls=[
            CallEdge(
                caller_file="/path/to/quoted/file.py",
                caller_function="foo",
                caller_line=5,
                callee_file="/path/to/quoted/file.py",
                callee_function="foo",
                callee_line=1,
                call_site_line=5,
                call_type="local",
            )
        ],
    )

    base_path = "/path"
    result = format_dot(graph, base_path=base_path)

    # Should handle quotes in paths
    assert result is not None


def test_filter_internal_calls():
    """Test that external calls are filtered out."""
    from vibelexity.call_graph.formatters import _filter_internal_calls

    graph = CallGraph(
        functions={},
        calls=[
            CallEdge(
                caller_file="/a.py",
                caller_function="foo",
                caller_line=1,
                callee_file=None,
                callee_function="print",
                callee_line=None,
                call_site_line=1,
                call_type="external",
            ),
            CallEdge(
                caller_file="/a.py",
                caller_function="bar",
                caller_line=2,
                callee_file="/b.py",
                callee_function="baz",
                callee_line=1,
                call_site_line=2,
                call_type="local",
            ),
        ],
    )

    internal = _filter_internal_calls(graph)

    # Should only return internal calls
    assert len(internal) == 1
    assert internal[0].caller_function == "bar"
    assert internal[0].callee_function == "baz"
