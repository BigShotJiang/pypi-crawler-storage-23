"""Init file for test_call_graph tests."""
