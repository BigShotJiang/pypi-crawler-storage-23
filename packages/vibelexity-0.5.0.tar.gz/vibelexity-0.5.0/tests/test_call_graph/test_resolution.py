"""Tests for callee resolution."""

from __future__ import annotations

from pathlib import Path
import tempfile

from vibelexity.call_graph import build_call_graph
from vibelexity.models import CallGraph


def test_local_call_resolution():
    code = """
def foo():
    return bar()
    
def bar():
    return 42
"""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
        f.write(code)
        f.flush()

        graph = build_call_graph([Path(f.name)])

        foo_calls = [c for c in graph.calls if c.caller_function == "foo"]
        assert len(foo_calls) == 1
        assert foo_calls[0].callee_function == "bar"
        assert foo_calls[0].call_type == "local"
        assert foo_calls[0].callee_file is not None

        Path(f.name).unlink()


def test_external_call_resolution():
    code = """
def foo():
    return print("hello")
"""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
        f.write(code)
        f.flush()

        graph = build_call_graph([Path(f.name)])

        foo_calls = [c for c in graph.calls if c.caller_function == "foo"]
        assert len(foo_calls) == 1
        assert foo_calls[0].callee_function == "print"
        assert foo_calls[0].call_type == "external"
        assert foo_calls[0].callee_file is None

        Path(f.name).unlink()


def test_method_call_resolution():
    code = """
class MyClass:
    def foo(self):
        self.bar()
        
    def bar(self):
        return 42
"""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
        f.write(code)
        f.flush()

        graph = build_call_graph([Path(f.name)])

        foo_calls = [c for c in graph.calls if c.caller_function == "foo"]
        assert len(foo_calls) == 1
        assert foo_calls[0].callee_function == "bar"
        assert foo_calls[0].call_type == "method"

        Path(f.name).unlink()
