"""Tests for dead code text/json formatters."""

from __future__ import annotations

from rich.console import Console

from vibelexity.dead_code.formatters import format_text
from vibelexity.models import DeadCodeViolation


def test_format_text_handles_brackets_in_paths_and_symbols() -> None:
    """Rich markup should not break when data contains bracket characters."""
    violations = [
        DeadCodeViolation(
            type="dead_function",
            symbol="bad[/link]symbol",
            location="example-codebased/opencode/src/routes/[id]/file.ts",
            line=12,
            confidence="high",
        )
    ]

    output = format_text(violations)

    console = Console(record=True)
    console.print(output)
    rendered = console.export_text()
    assert "dead_function" in rendered
