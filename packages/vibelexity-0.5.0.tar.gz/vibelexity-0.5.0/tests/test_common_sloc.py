"""Additional common.py tests for edge cases."""

from vibelexity.parsers.python import parse
from vibelexity.common import _compute_sloc, _unwrap_parens


def test_compute_sloc_multiline_comment_with_code():
    """Multi-line comment with code on boundary lines."""
    code = """def foo():
    # comment with code
    x = 1  # inline
    # comment spanning
    # multiple lines
    y = 2
"""
    root = parse(code)
    sloc = _compute_sloc(code, root)
    # Should count lines with actual code
    assert sloc > 0
    assert sloc <= 6  # Max 6 non-comment lines


def test_compute_sloc_multiline_comment_mixed():
    """Multi-line comment with mixed code/boundary."""
    code = """# Comment with code
x = 1
# More comment
"""
    root = parse(code)
    sloc = _compute_sloc(code, root)
    assert sloc == 1


def test_compute_sloc_comment_at_line_boundary():
    """Comment spanning exact line boundaries."""
    code = """x = 1
# Single line comment
y = 2
"""
    root = parse(code)
    sloc = _compute_sloc(code, root)
    assert sloc == 2


def test_compute_sloc_unwrap_parens_deep():
    """Unwrap deeply nested parentheses."""
    code = "x = (((y)))"
    root = parse(code)
    # Find parenthesized expression
    found = None

    def find_paren(node):
        nonlocal found
        if node.type == "parenthesized_expression":
            unwrapped = _unwrap_parens(node)
            # Each unwrap should peel one layer
            assert (
                unwrapped.type != "parenthesized_expression"
                or node.type == "parenthesized_expression"
            )
            found = True
        for child in node.children:
            find_paren(child)

    find_paren(root)


def test_compute_sloc_no_comments():
    """SLOC with no comments just counts non-blank lines."""
    code = """def foo():
    x = 1
    y = 2
"""
    root = parse(code)
    sloc = _compute_sloc(code, root)
    assert sloc == 3
