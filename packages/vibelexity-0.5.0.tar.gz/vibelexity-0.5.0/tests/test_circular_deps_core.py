"""Tests for circular dependencies core logic covering edge cases."""

from pathlib import Path
import tempfile
import shutil

from vibelexity.circular_deps.core import (
    _detect_language,
    _get_parser,
    _get_resolver,
    _find_common_root,
)
from vibelexity.parsers.context import build_parsed_files


def test_detect_language_python():
    """Detect Python files."""
    assert _detect_language("test.py") == "python"
    assert _detect_language("subdir/test.py") == "python"


def test_detect_language_typescript():
    """Detect TypeScript files."""
    assert _detect_language("test.ts") == "typescript"
    assert _detect_language("test.tsx") == "typescript"
    assert _detect_language("test.js") == "typescript"
    assert _detect_language("test.jsx") == "typescript"


def test_detect_language_go():
    """Detect Go files."""
    assert _detect_language("test.go") == "go"


def test_detect_language_unsupported():
    """Return None for unsupported files."""
    assert _detect_language("test.json") is None
    assert _detect_language("test.md") is None
    assert _detect_language("test.txt") is None
    assert _detect_language("test.rst") is None


def test_get_parser_python():
    """Get Python parser."""
    parser = _get_parser("python")
    assert parser is not None
    assert parser.__class__.__name__ == "PythonImportParser"


def test_get_parser_typescript():
    """Get TypeScript parser."""
    parser = _get_parser("typescript")
    assert parser is not None
    assert parser.__class__.__name__ == "TypeScriptImportParser"


def test_get_parser_go():
    """Get Go parser."""
    parser = _get_parser("go")
    assert parser is not None
    assert parser.__class__.__name__ == "GoImportParser"


def test_get_parser_unknown():
    """Return None for unknown languages."""
    assert _get_parser("unknown") is None
    assert _get_parser("") is None
    assert _get_parser(None) is None


def test_get_resolver_python():
    """Get Python path resolver."""
    resolver = _get_resolver("python")
    assert resolver is not None
    assert resolver.__class__.__name__ == "PythonPathResolver"


def test_get_resolver_typescript():
    """Get TypeScript path resolver."""
    resolver = _get_resolver("typescript")
    assert resolver is not None
    assert resolver.__class__.__name__ == "TypeScriptPathResolver"


def test_get_resolver_go():
    """Get Go path resolver."""
    resolver = _get_resolver("go")
    assert resolver is not None
    assert resolver.__class__.__name__ == "GoPathResolver"


def test_get_resolver_unknown():
    """Return None for unknown languages."""
    assert _get_resolver("unknown") is None
    assert _get_resolver("") is None
    assert _get_resolver(None) is None


def test_get_resolver_typescript_with_config():
    """TypeScript resolver respects module_resolution config."""
    config = {"ts_module_resolution": "node"}
    resolver = _get_resolver("typescript", config=config)
    assert resolver is not None


def test_find_common_root_empty():
    """Empty files list returns empty string."""
    root = _find_common_root([])
    assert root == ""


def test_find_common_root_single_file():
    """Single file returns its directory."""
    root = _find_common_root(["/path/to/file.py"])
    assert root == "/path/to"


def test_find_common_root_same_directory():
    """Same directory returns that directory."""
    root = _find_common_root(["/path/to/a.py", "/path/to/b.py"])
    assert root == "/path/to"


def test_find_common_root_different_directories():
    """Different directories find common prefix."""
    root = _find_common_root(["/path/to/a.py", "/path/other/b.py"])
    assert root == "/path"


def test_find_common_root_no_common_root():
    """Paths on different drives or no common root."""
    import os

    paths = [
        "/path/to/a.py",
        "/different/path/b.py",
    ]
    root = _find_common_root(paths)
    assert root in ("/", "")


def test_build_dependency_graph_empty_files():
    """Empty file list returns empty graph."""
    from vibelexity.circular_deps.core import build_dependency_graph

    graph = build_dependency_graph([])
    assert len(graph.edges) == 0


def test_build_dependency_graph_unsupported_extension():
    """Unsupported file extensions are skipped."""
    from vibelexity.circular_deps.core import build_dependency_graph

    tmpdir = Path(tempfile.mkdtemp())
    try:
        json_file = tmpdir / "test.json"
        json_file.write_text("{}")

        graph = build_dependency_graph([json_file])
        assert len(graph.edges) >= 0  # May have entries for skipped files
    finally:
        shutil.rmtree(tmpdir)


def test_build_dependency_graph_mixed_languages():
    """Mixed language files are processed correctly."""
    from vibelexity.circular_deps.core import build_dependency_graph

    tmpdir = Path(tempfile.mkdtemp())
    try:
        py_file = tmpdir / "test.py"
        py_file.write_text("import os")

        go_file = tmpdir / "test.go"
        go_file.write_text('package main\nimport "os"')

        graph = build_dependency_graph([py_file, go_file])
        assert len(graph.edges) >= 2
    finally:
        shutil.rmtree(tmpdir)


def test_find_cycles_empty_files():
    """Empty file list has no cycles."""
    from vibelexity.circular_deps.core import find_cycles

    cycles = find_cycles([])
    assert len(cycles) == 0


def test_find_cycles_single_file():
    """Single file with no imports has no cycles."""
    from vibelexity.circular_deps.core import find_cycles

    tmpdir = Path(tempfile.mkdtemp())
    try:
        py_file = tmpdir / "test.py"
        py_file.write_text("def foo(): pass")

        cycles = find_cycles([py_file])
        assert len(cycles) == 0
    finally:
        shutil.rmtree(tmpdir)


def test_build_dependency_graph_reuses_parsed_context(monkeypatch):
    """Dependency graph should reuse provided parsed roots."""
    from vibelexity.circular_deps.core import build_dependency_graph
    import vibelexity.circular_deps.parsers.python as py_parser

    tmpdir = Path(tempfile.mkdtemp())
    try:
        py_file = tmpdir / "test.py"
        py_file.write_text("import os\n")
        parsed = build_parsed_files([py_file])

        def _fail_parse(_source: str):
            raise RuntimeError("parse should not be called")

        monkeypatch.setattr(py_parser, "parse", _fail_parse)
        graph = build_dependency_graph([py_file], parsed_files=parsed)
        assert str(py_file.resolve()) in graph.edges
    finally:
        shutil.rmtree(tmpdir)
