"""Halstead integration tests for Python."""

from vibelexity.analyzers.python import analyze_source


def test_halstead_simple_function():
    """Simple function produces non-zero Halstead metrics."""
    code = """
def add(a, b):
    return a + b
"""
    result = analyze_source(code)
    h = result.functions[0].halstead
    assert h is not None
    assert h.N1 > 0
    assert h.N2 > 0
    assert h.vocabulary > 0
    assert h.volume > 0


def test_halstead_empty_source():
    """Empty source has no functions."""
    result = analyze_source("")
    assert len(result.functions) == 0


def test_halstead_operators_counted():
    """Operators like +, -, = are counted."""
    code = """
def f():
    x = 1 + 2
    y = x - 3
"""
    result = analyze_source(code)
    h = result.functions[0].halstead
    assert h.n1 >= 2   # at least = and +, -
    assert h.N1 >= 4   # at least two = and one + and one -


def test_halstead_volume_scales_with_code():
    """More code should produce higher volume."""
    small = "def f():\n    x = 1\n"
    big = "def g():\n    x = 1\n    y = 2\n    z = x + y\n    w = z * x\n"
    h_small = analyze_source(small).functions[0].halstead
    h_big = analyze_source(big).functions[0].halstead
    assert h_big.volume > h_small.volume
