"""Halstead integration tests for Go."""

from vibelexity.analyzers.go import analyze_source


def test_halstead_basic():
    """Basic Go function produces Halstead metrics."""
    code = """
package main

func add(a, b int) int {
    return a + b
}
"""
    result = analyze_source(code)
    h = result.functions[0].halstead
    assert h is not None
    assert h.N1 > 0
    assert h.N2 > 0
    assert h.volume > 0


def test_halstead_short_var_declaration():
    """:= is counted as an operator."""
    code = """
package main

func f() {
    x := 1
    y := x + 2
}
"""
    result = analyze_source(code)
    h = result.functions[0].halstead
    assert h.N1 > 0
    assert h.volume > 0


def test_halstead_channel_operator():
    """<- is counted as an operator."""
    code = """
package main

func f(ch chan int) {
    ch <- 42
    x := <-ch
}
"""
    result = analyze_source(code)
    h = result.functions[0].halstead
    assert h.N1 > 0
    assert h.volume > 0


def test_halstead_empty_source():
    """Empty Go source has no functions."""
    result = analyze_source("")
    assert len(result.functions) == 0
