"""Halstead integration tests for TypeScript."""

from vibelexity.analyzers.typescript import analyze_source


def test_halstead_basic():
    """Basic TypeScript function produces Halstead metrics."""
    code = """
function add(a, b) {
    return a + b;
}
"""
    result = analyze_source(code)
    h = result.functions[0].halstead
    assert h is not None
    assert h.N1 > 0
    assert h.N2 > 0
    assert h.volume > 0


def test_halstead_strict_equality():
    """=== and !== are counted as operators."""
    code = """
function f() {
    const x = a === b;
    const y = c !== d;
}
"""
    result = analyze_source(code)
    h = result.functions[0].halstead
    assert h.n1 >= 2  # at least === and !==


def test_halstead_optional_chaining_and_nullish():
    """?. and ?? are counted as operators."""
    code = """
function f() {
    const x = a?.b ?? c;
}
"""
    result = analyze_source(code)
    h = result.functions[0].halstead
    assert h.N1 > 0
    assert h.volume > 0


def test_halstead_empty_source():
    """Empty TypeScript source has no functions."""
    result = analyze_source("")
    assert len(result.functions) == 0
