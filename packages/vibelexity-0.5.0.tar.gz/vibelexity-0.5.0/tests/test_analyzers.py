"""Tests for analyzer modules."""

from pathlib import Path
from tempfile import NamedTemporaryFile

from vibelexity.analyzers.python import analyze_file as analyze_py_file
from vibelexity.analyzers.typescript import analyze_file as analyze_ts_file
from vibelexity.analyzers.go import analyze_file as analyze_go_file
from vibelexity.analysis import _analyze_files
from vibelexity.parsers.context import build_parsed_files


def test_analyze_file_py():
    code = """
def foo(x):
    return x + 1
"""
    with NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
        f.write(code)
        filepath = f.name

    try:
        result = analyze_py_file(filepath)
        assert result.path == filepath
        assert len(result.functions) == 1
    finally:
        Path(filepath).unlink()


def test_analyze_file_ts_normal_extension():
    """TypeScript analyzer detects .ts extension."""
    code = "function foo(x: number) { return x + 1; }"
    with NamedTemporaryFile(mode="w", suffix=".ts", delete=False) as f:
        f.write(code)
        filepath = f.name

    try:
        result = analyze_ts_file(filepath)
        assert result.path == filepath
        assert len(result.functions) == 1
    finally:
        Path(filepath).unlink()


def test_analyze_file_ts_tsx_extension():
    """TypeScript analyzer detects .tsx extension."""
    code = "function foo(x: number) { return x + 1; }"
    with NamedTemporaryFile(mode="w", suffix=".tsx", delete=False) as f:
        f.write(code)
        filepath = f.name

    try:
        result = analyze_ts_file(filepath)
        assert result.path == filepath
        assert len(result.functions) == 1
    finally:
        Path(filepath).unlink()

    code = """
package main

func foo(x int) int {
    return x + 1
}
"""
    with NamedTemporaryFile(mode="w", suffix=".go", delete=False) as f:
        f.write(code)
        filepath = f.name

    try:
        result = analyze_go_file(filepath)
        assert result.path == filepath
        assert len(result.functions) == 1
    finally:
        Path(filepath).unlink()


def test_analyze_py_empty_file():
    """Python analyzer handles empty files."""
    with NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
        f.write("")
        filepath = f.name

    try:
        result = analyze_py_file(filepath)
        assert result.path == filepath
        assert len(result.functions) == 0
    finally:
        Path(filepath).unlink()


def test_analyze_ts_empty_file():
    """TypeScript analyzer handles empty files."""
    with NamedTemporaryFile(mode="w", suffix=".ts", delete=False) as f:
        f.write("")
        filepath = f.name

    try:
        result = analyze_ts_file(filepath)
        assert result.path == filepath
        assert len(result.functions) == 0
    finally:
        Path(filepath).unlink()


def test_analyze_go_empty_file():
    """Go analyzer handles empty files."""
    with NamedTemporaryFile(mode="w", suffix=".go", delete=False) as f:
        f.write("")
        filepath = f.name

    try:
        result = analyze_go_file(filepath)
        assert result.path == filepath
        assert len(result.functions) == 0
    finally:
        Path(filepath).unlink()


def test_analyze_files_reuses_parsed_context(monkeypatch):
    """Shared parse context bypasses reparsing in serial mode."""
    import vibelexity.analyzers.python as py_analyzer

    code = """
def foo(x):
    return x + 1
"""
    with NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
        f.write(code)
        filepath = f.name

    parsed = build_parsed_files([Path(filepath)])

    def _fail_parse(_source: str):
        raise RuntimeError("parse should not be called")

    monkeypatch.setattr(py_analyzer, "parse", _fail_parse)

    try:
        results = _analyze_files([Path(filepath)], jobs=1, parsed_files=parsed)
        assert len(results) == 1
        assert len(results[0].functions) == 1
    finally:
        Path(filepath).unlink()
