from boto3.s3.transfer import TransferConfig as BotoTransferConfig

from vcm_file_uploader._types import TransferConfig
from vcm_file_uploader.transfer import create_transfer_config


class TestCreateTransferConfig:
    def test_defaults(self):
        cfg = create_transfer_config()
        assert isinstance(cfg, BotoTransferConfig)
        assert cfg.multipart_threshold == 128 * 1024 * 1024
        assert cfg.multipart_chunksize == 128 * 1024 * 1024
        assert cfg.max_concurrency == 8

    def test_custom_values(self):
        custom = TransferConfig(
            multipart_threshold=64 * 1024 * 1024,
            multipart_chunksize=32 * 1024 * 1024,
            max_concurrency=4,
        )
        cfg = create_transfer_config(custom)
        assert cfg.multipart_threshold == 64 * 1024 * 1024
        assert cfg.multipart_chunksize == 32 * 1024 * 1024
        assert cfg.max_concurrency == 4

    def test_none_uses_defaults(self):
        cfg = create_transfer_config(None)
        assert cfg.multipart_threshold == 128 * 1024 * 1024

    def test_returns_boto_type(self):
        cfg = create_transfer_config()
        assert type(cfg).__name__ == "TransferConfig"
        assert hasattr(cfg, "multipart_threshold")
        assert hasattr(cfg, "max_concurrency")
