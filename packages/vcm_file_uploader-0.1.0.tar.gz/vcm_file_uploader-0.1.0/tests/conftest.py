import boto3
import pytest
from moto import mock_aws

BUCKET_NAME = "test-bucket"
REGION = "us-east-1"
PREFIX = "jobs/test-job/attempt-001/"

# Dummy STS credentials for moto
STS_CREDS = {
    "aws_access_key_id": "testing",
    "aws_secret_access_key": "testing",
    "aws_session_token": "testing",
    "region": REGION,
}


@pytest.fixture
def aws_credentials(monkeypatch):
    """Set dummy AWS credentials for moto."""
    monkeypatch.setenv("AWS_ACCESS_KEY_ID", "testing")
    monkeypatch.setenv("AWS_SECRET_ACCESS_KEY", "testing")
    monkeypatch.setenv("AWS_SECURITY_TOKEN", "testing")
    monkeypatch.setenv("AWS_SESSION_TOKEN", "testing")
    monkeypatch.setenv("AWS_DEFAULT_REGION", REGION)


@pytest.fixture
def mock_s3(aws_credentials):
    """Start moto mock and create test bucket. Yields (bucket_name, s3_client)."""
    with mock_aws():
        client = boto3.client("s3", region_name=REGION)
        client.create_bucket(Bucket=BUCKET_NAME)
        yield BUCKET_NAME, client


@pytest.fixture
def s3_bucket(aws_credentials):
    """Create a mocked S3 bucket and return (bucket_name, s3_client)."""
    with mock_aws():
        client = boto3.client("s3", region_name=REGION)
        client.create_bucket(Bucket=BUCKET_NAME)
        yield BUCKET_NAME, client
