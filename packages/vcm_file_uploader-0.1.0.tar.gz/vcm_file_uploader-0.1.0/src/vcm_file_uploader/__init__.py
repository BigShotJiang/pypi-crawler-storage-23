"""vcm-file-uploader: Upload workflow artifacts to S3 using STS credentials."""

__version__ = "0.1.0"

from vcm_file_uploader._types import (
    CompressionInfo,
    TransferConfig,
    UploadFileEntry,
    UploadResult,
    UploadSummary,
)
from vcm_file_uploader.compress import compress_file, maybe_compress
from vcm_file_uploader.manifest import ManifestWriter
from vcm_file_uploader.plan import UploadPlan
from vcm_file_uploader.segmenter import LogSegmenter
from vcm_file_uploader.session import STSUploadSession
from vcm_file_uploader.state import JsonlStore, StateManager
from vcm_file_uploader.watchman import BackupWatchman

__all__ = [
    "BackupWatchman",
    "CompressionInfo",
    "JsonlStore",
    "LogSegmenter",
    "ManifestWriter",
    "StateManager",
    "STSUploadSession",
    "TransferConfig",
    "UploadFileEntry",
    "UploadPlan",
    "UploadResult",
    "UploadSummary",
    "compress_file",
    "maybe_compress",
]
