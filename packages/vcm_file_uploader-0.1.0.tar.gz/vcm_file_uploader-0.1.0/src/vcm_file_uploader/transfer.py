"""TransferManager configuration helpers."""

from __future__ import annotations

from boto3.s3.transfer import TransferConfig as BotoTransferConfig

from vcm_file_uploader._types import TransferConfig


def create_transfer_config(config: TransferConfig | None = None) -> BotoTransferConfig:
    """Create a boto3 TransferConfig from a vcm TransferConfig.

    If no config is provided, uses defaults (128 MiB threshold/chunksize, 8 concurrency).
    """
    if config is None:
        config = TransferConfig()
    return BotoTransferConfig(
        multipart_threshold=config.multipart_threshold,
        multipart_chunksize=config.multipart_chunksize,
        max_concurrency=config.max_concurrency,
    )
