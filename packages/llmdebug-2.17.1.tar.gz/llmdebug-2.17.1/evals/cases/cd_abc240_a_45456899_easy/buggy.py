A, B = map(int, input().split())

if B - A == 1 or A - B == 9:
    print("Yes")
else:
    print("No")
