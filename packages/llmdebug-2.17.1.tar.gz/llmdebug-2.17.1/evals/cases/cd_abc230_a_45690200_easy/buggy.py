n = int(input())
x = n
if n >= 42:
    x += 1
print(f"AGC0{x}")
