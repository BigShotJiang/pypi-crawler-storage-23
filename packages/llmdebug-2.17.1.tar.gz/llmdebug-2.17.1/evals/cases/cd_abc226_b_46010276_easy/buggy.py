n = int(input())
l = set()
for i in range(n):
    l.add(input().replace(" ", ""))
print(len(l))
