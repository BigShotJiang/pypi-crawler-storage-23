abc = "abcdefghijklnmopqrstuvwxyz"
print(abc[int(input()) - 97])
