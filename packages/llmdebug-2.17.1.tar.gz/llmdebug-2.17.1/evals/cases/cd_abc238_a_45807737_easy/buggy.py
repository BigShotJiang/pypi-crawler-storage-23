N = int(input())
if N > 4:
    print("Yes")
else:
    print("No")
