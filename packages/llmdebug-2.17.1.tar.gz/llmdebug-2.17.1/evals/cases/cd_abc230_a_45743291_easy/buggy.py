N = int(input())

if N >= 43:
    print(f"AGC{N + 1:03}")
else:
    print(f"AGC{N:03}")
