import subprocess
import sys


def test_condefects_0():
    proc = subprocess.run(
        [sys.executable, "buggy.py"],
        input='4 3 1\n1 2 3 1\n',
        capture_output=True,
        text=True,
        timeout=10,
    )
    expected = '4\n'
    actual = proc.stdout.strip()
    assert actual == expected.strip(), (
        f"Expected {expected.strip()!r}, got {actual!r}"
    )


def test_condefects_1():
    proc = subprocess.run(
        [sys.executable, "buggy.py"],
        input='5 2 1\n1 3 2 4 1\n',
        capture_output=True,
        text=True,
        timeout=10,
    )
    expected = '0\n'
    actual = proc.stdout.strip()
    assert actual == expected.strip(), (
        f"Expected {expected.strip()!r}, got {actual!r}"
    )


def test_condefects_2():
    proc = subprocess.run(
        [sys.executable, "buggy.py"],
        input='5 1 1\n1 1 1 1 1\n',
        capture_output=True,
        text=True,
        timeout=10,
    )
    expected = '15\n'
    actual = proc.stdout.strip()
    assert actual == expected.strip(), (
        f"Expected {expected.strip()!r}, got {actual!r}"
    )


def test_condefects_3():
    proc = subprocess.run(
        [sys.executable, "buggy.py"],
        input='10 8 1\n2 7 1 8 2 8 1 8 2 8\n',
        capture_output=True,
        text=True,
        timeout=10,
    )
    expected = '36\n'
    actual = proc.stdout.strip()
    assert actual == expected.strip(), (
        f"Expected {expected.strip()!r}, got {actual!r}"
    )


def test_condefects_4():
    proc = subprocess.run(
        [sys.executable, "buggy.py"],
        input='614 12 12\n5 9 8 6 5 11 1 7 9 4 6 4 12 8 2 5 6 5 12 8 12 2 6 7 3 1 3 5 7 5 7 5 12 7 4 3 11 8 10 1 2 6 6 8 8 9 5 8 6 11 5 12 1 9 6 7 4 7 12 2 10 1 12 9 4 5 6 1 9 1 1 3 7 6 11 5 6 6 6 6 11 10 8 12 1 4 4 7 12 6 1 1 1 3 8 3 9 1 6 10 5 12 9 3 6 9 3 5 11 10 3 1 11 12 9 8 4 12 3 12 9 5 12 11 12 8 10 9 5 5 2 1 5 10 4 8 6 9 8 2 7 3 7 6 4 11 6 5 8 10 8 12 4 8 11 7 12 11 4 12 10 11 4 3 3 6 9 10 11 4 11 11 12 7 4 1 9 7 5 1 1 1 10 8 7 3 2 11 10 8 11 7 5 6 3 7 10 9 2 12 5 12 4 10 5 9 10 6 4 8 2 12 8 7 12 1 12 3 7 10 9 2 4 12 8 2 6 2 1 10 8 8 5 2 12 6 7 4 7 8 4 6 10 3 7 7 9 5 9 2 1 5 9 1 8 5 6 4 12 1 2 2 1 7 11 2 8 10 5 1 7 3 11 1 10 6 2 9 4 7 10 5 10 1 7 1 7 12 6 4 11 10 11 11 7 3 7 12 4 2 9 7 7 12 3 3 12 12 11 4 1 5 5 5 3 7 10 7 2 9 4 3 12 9 4 7 6 5 10 6 1 9 2 6 7 7 2 2 1 10 10 2 9 9 3 6 11 10 7 8 8 9 3 12 4 12 12 3 5 7 11 3 9 10 3 12 11 4 7 3 6 12 5 2 9 5 8 5 3 12 5 6 4 12 3 3 10 11 3 1 4 11 6 4 3 10 10 9 1 5 1 4 11 10 5 8 8 4 7 9 12 11 12 5 10 7 10 4 7 2 3 5 9 9 6 8 5 11 10 5 4 3 3 12 7 3 3 8 12 2 9 9 2 4 8 9 10 2 3 7 10 11 8 11 11 3 7 7 2 2 1 4 5 3 7 9 8 12 8 2 10 7 8 4 1 9 5 10 6 5 8 12 11 3 5 6 11 7 11 3 11 7 1 7 5 5 1 3 8 6 7 4 11 4 9 4 1 6 4 12 3 8 8 5 2 6 9 8 4 12 1 1 4 6 6 12 3 10 2 6 6 10 10 8 7 9 7 3 9 12 11 12 3 11 8 8 11 6 4 3 2 4 6 4 6 2 2 4 5 5 1 11 1 4 8 7 6 8 1 2 12 4 8 8 11 8 3 5 1 7 4 6 11 7 1 9 11 10 8 2 3 3 12 12 2 1 2 2 4 1 1 10 7 2 10 3 6 12 11 1 9 7 9 1\n',
        capture_output=True,
        text=True,
        timeout=10,
    )
    expected = '58\n'
    actual = proc.stdout.strip()
    assert actual == expected.strip(), (
        f"Expected {expected.strip()!r}, got {actual!r}"
    )
