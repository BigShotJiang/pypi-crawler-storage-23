- Savoir-faire Linux
- Simone Orsi \<<simone.orsi@camptocamp.com>\>
- [Tecnativa](https://www.tecnativa.com):
  - Ernesto Tejeda

Trobz

- Dung Tran \<<dungtd@trobz.com>\>
- Yvan Dotet \<<yvan.dotet@logicasoft.eu>\>

TODO: many contribs to retrieve from history, we can open other PRs to
update this list.
