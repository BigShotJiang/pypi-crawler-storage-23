This module was written to manage Actions of your management system.
