# /// script
# requires-python = ">=3.11"
# dependencies = [
#     "click>=8.3.1",
# ]
# ///


import pathlib
import tomllib
import subprocess
import click


DEFAULT_BRANCH = "main"
PROJECT_FILE = "pyproject.toml"
INDENT = " " * 4
BAR = "=" * 80


def get_project_file(cwd='.'):
    directory = pathlib.Path(cwd).resolve()
    if not directory.exists():
        return None
    child = None
    while directory != child:
        file = directory / PROJECT_FILE
        if file.exists():
            return file
        child, directory = directory, directory.parent
    return None


def shell(args, **kwds):
    out = subprocess.run(args, encoding="utf8", capture_output=True, **kwds)
    out.stdout = out.stdout.strip()
    out.stderr = out.stderr.strip()
    return out


@click.command(context_settings={"help_option_names": ['-h', '--help']})
def main() -> None:
    """ Add and push git tag for project release.

    It will look for project version, check repo sanity, create tag and push it.

    \b
    Project version is found in the 'project.version' entry of pyproject.toml.
    A good way to handle that is with `uv version` command:
      Start branch with:
        uv version --bump dev --bump patch
      Close branch with:
        uv version --bump stable
    """

    # get project file
    project_file = get_project_file()
    if project_file is None:
        click.echo(f"error: unable to find project file ({PROJECT_FILE})", err=True)
        exit(1)
    click.echo(f"Found project file: {project_file}")

    # get version from project file
    config = tomllib.load(project_file.open("rb"))
    version = config.get("project", {}).get("version", None)
    if version is None:
        click.echo("error: unable to find '[project.version]' key in project file.", err=True)
        exit(1)
    version = version.strip()
    version_tag = f"v{version}"
    click.echo(f"Found version: {version}")

    # TODO  check that all workspace members have the same version

    # get active branch
    branch = shell(["git", "branch", "--show-current"]).stdout
    if branch != DEFAULT_BRANCH:
        click.echo(f"warning: current branch is '{branch}', should be '{DEFAULT_BRANCH}'")
        if not click.confirm(f"Do you want to release from '{branch}' instead ?"):
            exit(1)

    # check if repo is clean
    repo_not_clean = shell(["git", "diff-index", "--quiet", "HEAD"]).returncode
    if repo_not_clean:
        click.echo("warning: git repo is not clean, current changes won't be released", err=True)
        if not click.confirm(f"Continue with not clean repo ?"):
            exit(1)

    # check if new tag already exists
    tags = shell(["git", "tag", "--list"]).stdout.splitlines()
    if version_tag in tags:
        click.echo("error: git tag already exists [{version_tag}]", err=True)
        exit(1)

    # show commit to be released
    click.echo("Commit to be released:")
    click.echo(BAR)
    subprocess.run(["git", "log", "HEAD^..HEAD"])
    click.echo(BAR)

    # prepare commands modifying repo
    cmd_git = [
        ["git", "tag", "-a", version_tag, "-m", f"\"release of {version_tag}\""],
        ["git", "push", "origin", branch],
        ["git", "push", "origin", version_tag],
    ]

    # ask confirmation for commands
    click.echo("The following commands will be executed:")
    click.echo("\n".join(INDENT + " ".join(cmd) for cmd in cmd_git))
    if not click.confirm("Confirm execution ?"):
        exit(1)

    # run commands
    for cmd in cmd_git:
        click.echo(f"running: {' '.join(cmd)}")
        subprocess.run(cmd)


if __name__ == "__main__":
    main()
