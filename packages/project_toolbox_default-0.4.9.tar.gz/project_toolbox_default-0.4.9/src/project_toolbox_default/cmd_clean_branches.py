# /// script
# requires-python = ">=3.11"
# dependencies = [
#     "click>=8.3.1",
# ]
# ///


"""
git branch -d $(git branch --merged=master | grep -v master)
git fetch --prune

"""


import subprocess
import click


DEFAULT_BRANCH = "main"


def run(cmd):
    click.echo(f"$ {' '.join(cmd)}")
    return subprocess.run(cmd)


@click.command(context_settings={"help_option_names": ['-h', '--help']})
@click.argument("ref_branch", default=DEFAULT_BRANCH)
def main(ref_branch):
    """ Clean unused branches.
    """
    cmd = ["git", "branch", "--merged", ref_branch]
    result = run(cmd)
    if result.returncode:
        exit(result.returncode)

    branches = subprocess.run(
        [*cmd, "--format='%(refname:short)'"],
        capture_output=True,
        text=True
    ).stdout.split()
    branches = [n.replace("'", "") for n in branches]
    if DEFAULT_BRANCH in branches:
        branches.remove(DEFAULT_BRANCH)

    if branches:
        run(["git", "branch", "-d", *branches])

    run(["git", "fetch", "--prune"])
    run(["git", "branch", "--all"])


if __name__ == "__main__":
    main()
