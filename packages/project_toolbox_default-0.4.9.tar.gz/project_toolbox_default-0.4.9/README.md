# project-toolbox-default

A [project-toolbox](https://pypi.org/project/project-toolbox/) plugin for my default development workflow.

## Getting started

If not done yet, [install uv](https://docs.astral.sh/uv/getting-started/installation/) and [project-toolbox](https://pypi.org/project/project-toolbox/).

Add the toolbox to the project:
```shell
cd path/to/project
t self install default
```
This will edit the 'pyproject.toml' file of the project.

Now you can use the toolbox:
```shell
# show all commands
t
# use a command
t <command> <arg1> <arg2> ...
```

## Philosophy

I want a toolbox to support my Python development workflow.
This toolbox does not cover all workflows.

For now, I'm working with git and uv.

Some general principles:
  - tools should make each step of the workflow simple and easy
  - tools should make the workflow easy to follow and remember
  - tools should automate repetitive tasks
  - tools should reduce the number of command to remember
  - tools should avoid mistakes by checking project sanity
  - tools should tell what they are doing
