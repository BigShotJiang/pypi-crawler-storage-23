"""
MCP (Model Context Protocol) server endpoint for StateZero.

**Proof of concept / admin-only.**  This endpoint is intended for trusted
admin users (internal ops chat, developer tooling, etc.).  The code
execution sandbox uses restricted builtins but runs in-process — it is
NOT suitable for untrusted input.  Restrict access to staff/superusers
and protect the endpoint behind your network boundary.

Exposes two tools over JSON-RPC 2.0 / HTTP POST:
  - statezero_introspect: returns registered model & action schemas
  - statezero_execute: runs Python code in a restricted sandbox with the
    StateZero client pre-configured for the authenticated user

Wire up via mcp_urls.py (opt-in):
    path("mcp/", include("statezero.adaptors.django.mcp_urls"))

Authentication:
  By default, only ``SessionAuthentication`` is enabled (suitable for
  local development).  For production use with MCP clients like Claude
  Desktop, you must configure an OAuth 2.1 provider (e.g.
  ``django-oauth-toolkit``) and point ``STATEZERO_MCP_AUTHENTICATION_CLASSES``
  at its DRF authentication backend.  See the README for a full guide.
"""

import io
import signal
import sys
import traceback

from django.conf import settings
from django.utils.module_loading import import_string
from rest_framework.response import Response
from rest_framework.views import APIView

from statezero.adaptors.django.actions import DjangoActionSchemaGenerator
from statezero.adaptors.django.config import config, registry
from statezero.core.actions import action_registry

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_SERVER_NAME = "statezero"
_SERVER_VERSION = "0.1.0"
_PROTOCOL_VERSION = "2025-03-26"
_EXECUTE_TIMEOUT_SECONDS = 10

_SAFE_BUILTINS = {
    "print": print,
    "len": len,
    "range": range,
    "enumerate": enumerate,
    "zip": zip,
    "sorted": sorted,
    "reversed": reversed,
    "list": list,
    "dict": dict,
    "set": set,
    "tuple": tuple,
    "str": str,
    "int": int,
    "float": float,
    "bool": bool,
    "None": None,
    "True": True,
    "False": False,
    "isinstance": isinstance,
    "type": type,
    "max": max,
    "min": min,
    "sum": sum,
    "abs": abs,
    "round": round,
    "map": map,
    "filter": filter,
    "any": any,
    "all": all,
    "hasattr": hasattr,
    "getattr": getattr,
    "repr": repr,
    "format": format,
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_mcp_permission_class = import_string(
    getattr(settings, "STATEZERO_MCP_PERMISSION_CLASS", "rest_framework.permissions.IsAdminUser")
)

_mcp_authentication_classes = [
    import_string(cls) for cls in getattr(
        settings,
        "STATEZERO_MCP_AUTHENTICATION_CLASSES",
        [
            "rest_framework.authentication.SessionAuthentication",
        ],
    )
]


def _jsonrpc_ok(id, result):
    return Response({"jsonrpc": "2.0", "id": id, "result": result})


def _jsonrpc_error(id, code, message, data=None):
    err = {"code": code, "message": message}
    if data is not None:
        err["data"] = data
    return Response({"jsonrpc": "2.0", "id": id, "error": err})


# ---------------------------------------------------------------------------
# Tool: statezero_introspect
# ---------------------------------------------------------------------------

def _introspect():
    """Return model schemas and action schemas for all registered models/actions."""
    if not hasattr(config, "schema_generator") or config.schema_generator is None:
        config.initialize()

    # Model schemas
    models_out = {}
    for model_class, model_config in registry._models_config.items():
        schema = config.schema_generator.generate_schema(
            model_class,
            global_schema_overrides=config.schema_overrides,
            additional_fields=model_config.additional_fields or [],
        )
        models_out[schema.model_name] = schema.model_dump(mode="json")

    # Action schemas
    actions_response = DjangoActionSchemaGenerator.generate_actions_schema()
    actions_data = actions_response.data if hasattr(actions_response, "data") else actions_response

    return {
        "models": models_out,
        "actions": actions_data.get("actions", {}),
    }


# ---------------------------------------------------------------------------
# Tool: statezero_execute (sandbox)
# ---------------------------------------------------------------------------

def _build_sandbox_namespace(user):
    """Build a restricted namespace with the StateZero client configured for *user*."""
    from statezero.client.runtime_template import (
        Model, Manager, QuerySet, Q, F, _model_registry,
        configure, StateZeroError, ValidationError, NotFound,
        PermissionDenied, MultipleObjectsReturned, _resolve_value,
        _transport,
    )
    from statezero.client.testing import DjangoTransport

    # Fresh transport for this user
    transport = DjangoTransport(user=user)

    # We need to configure the runtime globally so the sandbox code uses it.
    # Save and restore after execution.
    configure(transport=transport)

    ns = {}

    # Build Model subclasses dynamically for every registered model
    if not hasattr(config, "schema_generator") or config.schema_generator is None:
        config.initialize()

    for model_class, model_config in registry._models_config.items():
        schema = config.schema_generator.generate_schema(
            model_class,
            global_schema_overrides=config.schema_overrides,
            additional_fields=model_config.additional_fields or [],
        )
        class_name = schema.class_name
        model_name = schema.model_name
        pk_field = schema.primary_key_field

        relations = {}
        for field_name, rel_info in schema.relationships.items():
            rel_type = rel_info.get("type", "")
            if rel_type in ("foreign-key", "one-to-one"):
                relations[field_name] = rel_info["model"]

        # Create model class dynamically
        model_cls = type(class_name, (Model,), {
            "_model_name": model_name,
            "_pk_field": pk_field,
            "_relations": relations,
        })
        ns[class_name] = model_cls

    # Build action wrapper functions
    for action_name, action_def in action_registry.get_actions().items():
        # Capture action_name in closure
        def _make_action_fn(name):
            def action_fn(**kwargs):
                resolved = {k: _resolve_value(v) for k, v in kwargs.items()}
                return transport.post_action(name, resolved)
            action_fn.__name__ = name
            action_fn.__qualname__ = name
            return action_fn

        ns[action_name] = _make_action_fn(action_name)

    # Add helpers
    ns["Q"] = Q
    ns["F"] = F
    ns["configure"] = configure
    ns["StateZeroError"] = StateZeroError
    ns["ValidationError"] = ValidationError
    ns["NotFound"] = NotFound
    ns["PermissionDenied"] = PermissionDenied
    ns["MultipleObjectsReturned"] = MultipleObjectsReturned

    # Restricted builtins
    ns["__builtins__"] = dict(_SAFE_BUILTINS)

    return ns


class _Timeout:
    """Context manager that raises TimeoutError after *seconds* (Unix only, no-op on Windows)."""

    def __init__(self, seconds):
        self.seconds = seconds
        self._supported = hasattr(signal, "SIGALRM")

    def _handler(self, signum, frame):
        raise TimeoutError(f"Execution timed out after {self.seconds}s")

    def __enter__(self):
        if self._supported:
            self._old = signal.signal(signal.SIGALRM, self._handler)
            signal.alarm(self.seconds)
        return self

    def __exit__(self, *exc):
        if self._supported:
            signal.alarm(0)
            signal.signal(signal.SIGALRM, self._old)
        return False


def _execute_code(code, user):
    """Execute *code* in the sandbox, returning (result, stdout, stderr, error)."""
    import ast as _ast

    ns = _build_sandbox_namespace(user)

    stdout_capture = io.StringIO()
    stderr_capture = io.StringIO()

    result = None
    error = None

    # Attempt to capture the last expression's value
    try:
        tree = _ast.parse(code, mode="exec")
    except SyntaxError as exc:
        return None, "", "", f"SyntaxError: {exc}"

    # If the last statement is an expression, capture its value
    last_expr = None
    if tree.body and isinstance(tree.body[-1], _ast.Expr):
        last_expr = _ast.Expression(body=tree.body.pop().value)
        _ast.fix_missing_locations(last_expr)

    exec_code = compile(tree, "<mcp>", "exec")
    eval_code = compile(last_expr, "<mcp>", "eval") if last_expr else None

    old_stdout, old_stderr = sys.stdout, sys.stderr
    try:
        sys.stdout = stdout_capture
        sys.stderr = stderr_capture
        with _Timeout(_EXECUTE_TIMEOUT_SECONDS):
            exec(exec_code, ns)
            if eval_code is not None:
                result = eval(eval_code, ns)
    except TimeoutError as exc:
        error = str(exc)
    except Exception:
        error = traceback.format_exc()
    finally:
        sys.stdout = old_stdout
        sys.stderr = old_stderr

    # Stringify result for JSON serialisation
    if result is not None:
        try:
            # Try to make it JSON-friendly
            import json
            json.dumps(result)  # test serialisability
        except (TypeError, ValueError):
            result = repr(result)

    return result, stdout_capture.getvalue(), stderr_capture.getvalue(), error


# ---------------------------------------------------------------------------
# MCP View  (JSON-RPC 2.0 / HTTP POST)
# ---------------------------------------------------------------------------

class MCPView(APIView):
    """
    Single DRF view handling the MCP JSON-RPC 2.0 protocol surface
    needed for tool-based interactions:

        initialize      → server capabilities + info
        tools/list      → tool definitions
        tools/call      → dispatch to introspect / execute

    Auth defaults to session auth for local development.  Configure
    ``STATEZERO_MCP_AUTHENTICATION_CLASSES`` for production (e.g. OAuth 2.1
    via ``django-oauth-toolkit``).
    """

    authentication_classes = _mcp_authentication_classes
    permission_classes = [_mcp_permission_class]

    # -- tool metadata -------------------------------------------------------

    TOOLS = [
        {
            "name": "statezero_introspect",
            "description": (
                "Return the schemas of all registered models and actions. "
                "Use this first to discover available models, their fields, "
                "relationships, and available actions before writing queries."
            ),
            "inputSchema": {
                "type": "object",
                "properties": {},
                "required": [],
            },
        },
        {
            "name": "statezero_execute",
            "description": (
                "Execute Python code using the StateZero client library. "
                "The sandbox provides generated Model classes (with .objects manager), "
                "action functions, Q/F helpers, and error classes. "
                "Write standard Django-ORM-style queries, e.g.:\n\n"
                "  users = User.objects.filter(active=True).fetch(limit=5)\n"
                "  result = [{\"name\": u.name} for u in users]\n\n"
                "The value of the last expression is returned as the result."
            ),
            "inputSchema": {
                "type": "object",
                "properties": {
                    "code": {
                        "type": "string",
                        "description": "Python code to execute in the StateZero sandbox.",
                    },
                },
                "required": ["code"],
            },
        },
    ]

    # -- dispatch ------------------------------------------------------------

    def post(self, request, *args, **kwargs):
        body = request.data

        method = body.get("method")
        req_id = body.get("id")
        params = body.get("params", {})

        if method == "initialize":
            return self._handle_initialize(req_id)
        elif method == "tools/list":
            return self._handle_tools_list(req_id)
        elif method == "tools/call":
            return self._handle_tools_call(req_id, params, request)
        else:
            return _jsonrpc_error(req_id, -32601, f"Method not found: {method}")

    # -- handlers ------------------------------------------------------------

    def _handle_initialize(self, req_id):
        return _jsonrpc_ok(req_id, {
            "protocolVersion": _PROTOCOL_VERSION,
            "capabilities": {"tools": {}},
            "serverInfo": {
                "name": _SERVER_NAME,
                "version": _SERVER_VERSION,
            },
        })

    def _handle_tools_list(self, req_id):
        return _jsonrpc_ok(req_id, {"tools": self.TOOLS})

    def _handle_tools_call(self, req_id, params, request):
        tool_name = params.get("name")
        tool_args = params.get("arguments", {})

        if tool_name == "statezero_introspect":
            return self._call_introspect(req_id)
        elif tool_name == "statezero_execute":
            return self._call_execute(req_id, tool_args, request)
        else:
            return _jsonrpc_error(req_id, -32602, f"Unknown tool: {tool_name}")

    def _call_introspect(self, req_id):
        try:
            data = _introspect()
        except Exception:
            return _jsonrpc_error(req_id, -32000, "Introspection failed", traceback.format_exc())
        return _jsonrpc_ok(req_id, {
            "content": [{"type": "text", "text": _json_dumps(data)}],
        })

    def _call_execute(self, req_id, tool_args, request):
        code = tool_args.get("code")
        if not code:
            return _jsonrpc_error(req_id, -32602, "Missing required argument: code")

        user = request.user
        if not user or not user.is_authenticated:
            return _jsonrpc_error(req_id, -32000, "Authentication required")

        result, stdout, stderr, error = _execute_code(code, user)

        parts = []
        if error:
            parts.append(f"Error:\n{error}")
        if stdout:
            parts.append(f"stdout:\n{stdout}")
        if stderr:
            parts.append(f"stderr:\n{stderr}")
        if result is not None:
            parts.append(f"Result:\n{_json_dumps(result)}")
        if not parts:
            parts.append("(no output)")

        text = "\n\n".join(parts)
        is_error = error is not None

        return _jsonrpc_ok(req_id, {
            "content": [{"type": "text", "text": text}],
            "isError": is_error,
        })


def _json_dumps(obj):
    """JSON-serialise with compact formatting."""
    import json
    return json.dumps(obj, default=str, separators=(",", ":"), ensure_ascii=False)
