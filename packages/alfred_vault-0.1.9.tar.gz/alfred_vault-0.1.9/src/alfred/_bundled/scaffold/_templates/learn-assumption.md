---
type: assumption
status: active # active | challenged | invalidated | confirmed
confidence: medium # low | medium | high
source: "" # where this came from (person, document, meeting)
source_date:
project: [] # [[project links]]
based_on: [] # [[evidence it rests on]]
confirmed_by: [] # [[evidence that strengthened it]]
challenged_by: [] # [[evidence that weakened it]]
invalidated_by: [] # [[evidence that killed it]]
related: []
created: "{{date}}"
tags: []
---

# {{title}}

## Claim

<!-- What exactly is being assumed — state it precisely -->

## Basis

<!-- Why do we believe this? What evidence or experience supports it? -->

## Evidence Trail

<!-- As confirming or challenging evidence arrives, log it here with dates -->

## Impact

<!-- What decisions or plans depend on this assumption? -->

![[learn-assumption.base#Depends On This]]
![[learn-assumption.base#Related]]
