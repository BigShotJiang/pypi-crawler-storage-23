"""
Supreme 2 MAX — MCP Tools

All ``@mcp.tool()`` decorated functions are registered here.

Tools
~~~~~
* ``analyze_project``      — analyse project structure, languages, frameworks.
* ``run_security_scan``    — run full / incremental / quick security scan.
* ``get_scan_results``     — retrieve & filter issues from a stored scan.
* ``generate_report``      — build an aggregated JSON + HTML report and persist it.
* ``analyze_findings``     — false-positive analysis and issue prioritisation.
"""

from __future__ import annotations

import asyncio
import copy
import io
import json
import os
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from supreme_max.mcp_server._server import mcp
from supreme_max.mcp_server.state import ScanStateManager
from supreme_max.mcp_server.security import (
    SecurityError,
    safe_validate_project_path,
    sanitize_analyzed_issues,
    sanitize_scan_results,
)
from supreme_max.core.pattern_analyzer import CodePatternAnalyzer


# ---------------------------------------------------------------------------
# Singleton state manager — created lazily so unit tests can monkey-patch.
# ---------------------------------------------------------------------------

_state_manager: Optional[ScanStateManager] = None


def _get_state_manager() -> ScanStateManager:
    global _state_manager
    if _state_manager is None:
        _state_manager = ScanStateManager()
    return _state_manager


# ---------------------------------------------------------------------------
# Scanner class name -> user-friendly tool/scanner identifier
# ---------------------------------------------------------------------------

_SCANNER_DISPLAY_NAMES: Dict[str, str] = {
    "PythonScanner": "bandit",
    "JavaScriptScanner": "eslint",
    "TypeScriptScanner": "typescript_scanner",
    "GoScanner": "golangci_lint",
    "RustScanner": "cargo_audit",
    "RubyScanner": "rubocop",
    "PHPScanner": "phpstan",
    "JavaScanner": "spotbugs",
    "KotlinScanner": "detekt",
    "ScalaScanner": "scalastyle",
    "CSharpScanner": "csharp_scanner",
    "CppScanner": "cppcheck",
    "SwiftScanner": "swiftlint",
    "PerlScanner": "perlcritic",
    "BashScanner": "shellcheck",
    "PowerShellScanner": "psscriptanalyzer",
    "BatScanner": "bat_scanner",
    "LuaScanner": "luacheck",
    "RScanner": "r_scanner",
    "ElixirScanner": "elixir_scanner",
    "HaskellScanner": "hlint",
    "ClojureScanner": "clj_kondo",
    "DartScanner": "dart_scanner",
    "GroovyScanner": "groovy_scanner",
    "SolidityScanner": "slither",
    "ZigScanner": "zig_scanner",
    "YAMLScanner": "yaml_scanner",
    "JSONScanner": "json_scanner",
    "TOMLScanner": "toml_scanner",
    "XMLScanner": "xml_scanner",
    "EnvScanner": "env_scanner",
    "TerraformScanner": "tflint",
    "DockerScanner": "hadolint",
    "HTMLScanner": "htmlhint",
    "CSSScanner": "stylelint",
    "SQLScanner": "sqlfluff",
    "GraphQLScanner": "graphql_scanner",
    "ProtobufScanner": "protobuf_scanner",
    "MarkdownScanner": "markdownlint",
    # AI / built-in scanners
    "MCPConfigScanner": "mcp_config_scanner",
    "MCPServerScanner": "mcp_server_scanner",
    "AIContextScanner": "ai_context_scanner",
    "AgentMemoryScanner": "agent_memory_scanner",
    "RAGSecurityScanner": "rag_security_scanner",
    "A2AScanner": "a2a_scanner",
    "PromptLeakageScanner": "prompt_leakage_scanner",
    "ToolCallbackScanner": "tool_callback_scanner",
    "OWASPLLMScanner": "owasp_llm_scanner",
    "ModelAttackScanner": "model_attack_scanner",
    "MultiAgentScanner": "multi_agent_scanner",
    "LLMOpsScanner": "llmops_scanner",
    # External integrations
    "GitLeaksScanner": "gitleaks",
    "TrivyScanner": "trivy",
    "SemgrepScanner": "semgrep",
}

# Reverse map: user-friendly name -> internal scanner class name
_DISPLAY_TO_CLASS: Dict[str, str] = {
    v: k for k, v in _SCANNER_DISPLAY_NAMES.items()
}


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _estimate_scan_time(total_files: int, num_scanners: int) -> str:
    """Return a human-readable scan time estimate string."""
    base_seconds = total_files * num_scanners * 0.05
    if base_seconds < 10:
        return "5-15 seconds"
    if base_seconds < 30:
        return "15-30 seconds"
    if base_seconds < 60:
        return "30-45 seconds"
    if base_seconds < 120:
        return "1-2 minutes"
    if base_seconds < 300:
        return "2-5 minutes"
    return "5+ minutes"


def _scanner_names(class_names: set) -> list:
    """Convert internal scanner class names to user-friendly identifiers."""
    return sorted(
        _SCANNER_DISPLAY_NAMES.get(name, name) for name in class_names
    )


def _capitalize_language(lang: str) -> str:
    """Capitalise language names to match the expected output style."""
    special = {
        "python": "Python",
        "javascript": "JavaScript",
        "typescript": "TypeScript",
        "csharp": "C#",
        "cpp": "C++",
        "c": "C",
        "objectivec": "Objective-C",
        "bash": "Bash",
        "powershell": "PowerShell",
        "graphql": "GraphQL",
        "protobuf": "Protobuf",
        "yaml": "YAML",
        "json": "JSON",
        "toml": "TOML",
        "xml": "XML",
        "html": "HTML",
        "css": "CSS",
        "sql": "SQL",
        "php": "PHP",
        "ini": "INI",
        "env": "ENV",
        "markdown": "Markdown",
        "config": "Config",
        "properties": "Properties",
    }
    return special.get(lang, lang.capitalize())


# ===================================================================
# Tool 1 — analyze_project
# ===================================================================

@mcp.tool()
async def analyze_project(
    project_path: str,
    include_dependencies: bool = False,
) -> Dict[str, Any]:
    """Analyze a project's structure, languages, frameworks, and security patterns.

    Scans the project directory using CodePatternAnalyzer to detect programming
    languages, frameworks, security patterns, and AI/LLM usage.  Returns a
    structured summary with recommended scanners so that only the relevant
    subset of the 74 available scanners is executed.

    Args:
        project_path: Absolute or relative path to the project root directory.
        include_dependencies: When True, include dependency directories
            (node_modules, venv, etc.) in the analysis.  Default is False.

    Returns:
        A dictionary with project_summary, recommended_scanners,
        security_context, and scan_time_estimate.
    """
    # Validate input (security: path traversal & sandbox check)
    try:
        resolved = safe_validate_project_path(project_path)
    except SecurityError as exc:
        return {"error": str(exc)}
    if not resolved.exists():
        return {"error": f"Path not found: {project_path}"}
    if not resolved.is_dir():
        return {"error": f"Path is not a directory: {project_path}"}

    # Run CodePatternAnalyzer
    analyzer = CodePatternAnalyzer()

    if include_dependencies:
        original_skip = CodePatternAnalyzer.SKIP_DIRECTORIES
        CodePatternAnalyzer.SKIP_DIRECTORIES = set()
        try:
            analysis = analyzer.analyze_repo(resolved)
        finally:
            CodePatternAnalyzer.SKIP_DIRECTORIES = original_skip
    else:
        analysis = analyzer.analyze_repo(resolved)

    # Build response
    languages_map: Dict[str, int] = {
        _capitalize_language(lang): count
        for lang, count in analysis.languages.items()
    }

    recommended = _scanner_names(analysis.recommended_scanners)
    file_extensions: Dict[str, int] = dict(analysis.file_extensions)
    sc = analysis.security_context

    return {
        "project_summary": {
            "total_files": analysis.total_files,
            "languages": languages_map,
            "frameworks": sorted(analysis.frameworks),
            "file_extensions": file_extensions,
        },
        "recommended_scanners": recommended,
        "security_context": {
            "uses_orm": sc.uses_orm,
            "has_input_validation": sc.has_input_validation,
            "has_ci_config": sc.has_ci_config,
            "has_ai_patterns": sc.has_ai_patterns,
            "has_mcp_config": sc.has_mcp_config,
        },
        "scan_time_estimate": _estimate_scan_time(
            analysis.total_files, len(recommended),
        ),
    }


# ===================================================================
# Tool 2 — run_security_scan
# ===================================================================

_VALID_MODES = {"full", "incremental", "quick"}
_VALID_SEVERITIES = {"all", "critical", "high", "medium", "low"}


def _filter_issues_by_severity(
    issues: List[Dict[str, Any]], severity_filter: str
) -> List[Dict[str, Any]]:
    """Keep only issues at or above *severity_filter*."""
    if severity_filter == "all":
        return issues

    ranking = {"critical": 4, "high": 3, "medium": 2, "low": 1, "info": 0}
    threshold = ranking.get(severity_filter, 0)

    return [
        issue
        for issue in issues
        if ranking.get(issue.get("severity", "").lower(), 0) >= threshold
    ]


def _build_issue_entry(
    issue: Dict[str, Any],
    file_path: str,
    scanner_name: str,
    issue_index: int,
) -> Dict[str, Any]:
    """Normalise a raw issue dict into the output schema shape."""
    return {
        "id": f"{scanner_name}-{issue_index}",
        "severity": issue.get("severity", "MEDIUM"),
        "scanner": scanner_name,
        "rule_id": issue.get("rule_id") or issue.get("code") or "",
        "file": file_path,
        "line": issue.get("line") or issue.get("line_number") or 0,
        "message": (
            issue.get("message")
            or issue.get("issue_text")
            or issue.get("issue")
            or str(issue)
        ),
        "code_snippet": issue.get("code") or "",
        "remediation": issue.get("remediation", ""),
    }


@mcp.tool()
async def run_security_scan(
    project_path: str,
    scanners: Optional[List[str]] = None,
    mode: str = "full",
    severity_filter: str = "all",
    exclude_paths: Optional[List[str]] = None,
    parallel_workers: Optional[int] = None,
) -> Dict[str, Any]:
    """Run a security scan on a project and return structured results.

    Executes the SupremeMaxParallelScanner autonomously, discovers files,
    runs all (or selected) scanners in parallel across multiple CPU cores,
    de-duplicates findings and persists the results via ScanStateManager.

    Args:
        project_path: Absolute or relative path to the project root.
        scanners: Optional list of scanner names to run (e.g. ["bandit",
            "eslint"]).  When omitted every applicable scanner is used.
        mode: Scan mode — "full" (all files), "incremental" (only changed
            files via cache) or "quick" (changed files only, no cache write).
        severity_filter: Minimum severity to include in results — "all",
            "critical", "high", "medium" or "low".
        exclude_paths: Additional directory/file patterns to skip.
        parallel_workers: Number of worker processes.  ``None`` = auto-detect
            CPU cores.

    Returns:
        A dictionary with scan_id, summary, issues, and report_path.
    """
    # ------------------------------------------------------------------
    # 1. Validate inputs (security: path traversal & sandbox check)
    # ------------------------------------------------------------------
    try:
        resolved = safe_validate_project_path(project_path)
    except SecurityError as exc:
        return {"error": str(exc)}
    if not resolved.exists():
        return {"error": f"Path not found: {project_path}"}
    if not resolved.is_dir():
        return {"error": f"Path is not a directory: {project_path}"}

    mode = mode.lower()
    if mode not in _VALID_MODES:
        return {"error": f"Invalid mode '{mode}'. Must be one of: {', '.join(sorted(_VALID_MODES))}"}

    severity_filter = severity_filter.lower()
    if severity_filter not in _VALID_SEVERITIES:
        return {"error": f"Invalid severity_filter '{severity_filter}'. Must be one of: {', '.join(sorted(_VALID_SEVERITIES))}"}

    # ------------------------------------------------------------------
    # 2. Initialise the parallel scanner
    # ------------------------------------------------------------------
    from supreme_max.core.parallel import SupremeMaxParallelScanner

    # Signal subprocess context — forces sequential scanning to avoid
    # multiprocessing issues on Windows
    os.environ['SUPREME2L_SUBPROCESS'] = '1'

    quick_mode = mode in ("quick", "incremental")
    use_cache = mode != "full"

    scanner = SupremeMaxParallelScanner(
        project_root=resolved,
        workers=parallel_workers,
        use_cache=use_cache,
        quick_mode=quick_mode,
    )

    # Honour extra exclude_paths from the caller
    if exclude_paths:
        for ep in exclude_paths:
            if ep not in scanner.config.exclude_paths:
                scanner.config.exclude_paths.append(ep)

    # ------------------------------------------------------------------
    # 3. Discover files & run scan in a thread (CPU-bound)
    #    Redirect stdout to avoid corrupting the JSON-RPC channel
    # ------------------------------------------------------------------
    wall_start = time.monotonic()

    def _do_scan():
        _saved_stdout = sys.stdout
        sys.stdout = io.StringIO()  # swallow all output silently
        try:
            files = scanner.find_scannable_files()
            if not files:
                return [], files
            results = scanner.scan_parallel(files)
            if scanner.cache:
                scanner.cache.save()
            return results, files
        finally:
            sys.stdout = _saved_stdout

    try:
        results, files = await asyncio.wait_for(
            asyncio.to_thread(_do_scan),
            timeout=300.0,  # 5-minute hard ceiling
        )
    except asyncio.TimeoutError:
        wall_seconds = time.monotonic() - wall_start
        return {
            "error": (
                f"Scan timed out after {wall_seconds:.0f}s. "
                "Try a smaller directory, use mode='quick', or add "
                "slow paths to exclude_paths."
            ),
        }

    wall_seconds = time.monotonic() - wall_start

    if not files:
        return {
            "scan_id": None,
            "summary": {
                "files_scanned": 0,
                "issues_found": 0,
                "scan_time": "0.00s",
                "scanners_used": [],
            },
            "issues": [],
            "report_path": None,
            "message": "No scannable files found.",
        }

    # ------------------------------------------------------------------
    # 4. Collect & normalise findings
    # ------------------------------------------------------------------
    all_issues: List[Dict[str, Any]] = []
    scanners_used: set[str] = set()
    files_cached = 0
    issue_counter = 0

    for res in results:
        if res.cached:
            files_cached += 1
            continue

        scanner_label = res.scanner or "unknown"
        if scanner_label != "cached":
            scanners_used.add(scanner_label)

        for raw_issue in res.issues:
            issue_counter += 1
            entry = _build_issue_entry(
                raw_issue if isinstance(raw_issue, dict) else raw_issue.to_dict(),
                res.file,
                scanner_label,
                issue_counter,
            )
            all_issues.append(entry)

    # Apply severity filter
    filtered_issues = _filter_issues_by_severity(all_issues, severity_filter)

    # ------------------------------------------------------------------
    # 5. Generate JSON report
    # ------------------------------------------------------------------
    from supreme_max.core.reporter import SupremeMaxReportGenerator

    report_dir = resolved / ".supreme2l" / "reports"
    report_dir.mkdir(parents=True, exist_ok=True)

    reporter_findings = []
    for issue in all_issues:  # use unfiltered for persistent report
        reporter_findings.append({
            "scanner": issue["scanner"],
            "file": issue["file"],
            "line": issue["line"],
            "severity": issue["severity"],
            "confidence": "HIGH",
            "issue": issue["message"],
            "cwe": issue.get("rule_id", ""),
            "code": issue.get("code_snippet", ""),
        })

    scan_results_for_reporter = {
        "findings": reporter_findings,
        "files_scanned": len(results) - files_cached,
        "total_lines_scanned": 0,
    }

    generator = SupremeMaxReportGenerator(report_dir)
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    json_report_path = generator.generate_json_report(
        scan_results_for_reporter,
        report_dir / f"supreme2l-scan-{timestamp}.json",
    )

    # ------------------------------------------------------------------
    # 6. Persist via ScanStateManager
    # ------------------------------------------------------------------
    state = _get_state_manager()

    files_scanned_count = len(results) - files_cached
    sorted_scanners = sorted(scanners_used)

    scan_data: Dict[str, Any] = {
        "project_path": str(resolved),
        "mode": mode,
        # Top-level fields for ScanStateManager compatibility
        "scanners_used": sorted_scanners,
        "files_scanned": files_scanned_count,
        "issues_found": len(filtered_issues),
        "scan_time": round(wall_seconds, 2),
        # Summary dict for richer consumers
        "summary": {
            "files_scanned": files_scanned_count,
            "files_cached": files_cached,
            "issues_found": len(filtered_issues),
            "scan_time": f"{wall_seconds:.2f}s",
            "scanners_used": sorted_scanners,
        },
        "issues": filtered_issues,
        "report_path": str(json_report_path),
    }

    scan_id = state.store_scan(scan_data)

    # ------------------------------------------------------------------
    # 6b. Generate HTML report + save both to project root
    # ------------------------------------------------------------------
    security_score = _compute_security_score(all_issues)
    risk = _risk_level(security_score)

    html_report_data: Dict[str, Any] = {
        "metadata": {
            "scan_id": scan_id,
            "project_path": str(resolved),
            "generated_at": datetime.now(timezone.utc).isoformat(),
        },
        "summary": {
            "files_scanned": files_scanned_count,
            "issues_found": len(filtered_issues),
            "scan_time": f"{wall_seconds:.2f}s",
            "scanners_used": sorted_scanners,
        },
        "aggregations": _aggregate_issues(filtered_issues),
        "security_score": security_score,
        "risk_level": risk,
        "issues": filtered_issues,
    }

    html_content = _build_html_report(html_report_data)

    # Save HTML alongside JSON in .supreme2l/reports/
    html_report_in_dir = report_dir / f"supreme2l-scan-{timestamp}.html"
    html_report_in_dir.write_text(html_content, encoding="utf-8")

    # Copy JSON + HTML to the project root directory
    proj_json_path = resolved / f"supreme2l-scan-{timestamp}.json"
    proj_html_path = resolved / f"supreme2l-scan-{timestamp}.html"
    proj_json_path.write_text(
        json.dumps(html_report_data, indent=2, default=str), encoding="utf-8"
    )
    proj_html_path.write_text(html_content, encoding="utf-8")

    # ------------------------------------------------------------------
    # 7. Sanitize secrets & return response
    # ------------------------------------------------------------------
    sanitize_scan_results(filtered_issues)

    return {
        "scan_id": scan_id,
        "summary": scan_data["summary"],
        "issues": filtered_issues,
        "report_path": str(json_report_path),
        "html_report_path": str(html_report_in_dir),
        "project_report_path": str(proj_json_path),
        "project_html_report_path": str(proj_html_path),
    }


# ===================================================================
# Tool 3 — get_scan_results
# ===================================================================

@mcp.tool()
async def get_scan_results(
    scan_id: str = "latest",
    filters: Optional[Dict[str, Any]] = None,
    severity: Optional[str] = None,
    file_pattern: Optional[str] = None,
    scanner: Optional[str] = None,
    limit: int = 100,
) -> Dict[str, Any]:
    """Return filtered issues from a previously stored scan.

    Parameters
    ----------
    scan_id:
        UUID of the scan **or** the literal ``"latest"``.
    filters:
        Optional dict with any combination of:

        * ``severity``     — list of severity strings (case-insensitive).
        * ``file_pattern`` — regex applied to ``issue["file"]``.
        * ``scanner``      — exact scanner name.
        * ``rule_id``      — exact rule id.
    severity:
        Comma-separated severity levels (e.g. "critical,high").
        Shortcut alternative to ``filters.severity``.
    file_pattern:
        Regex pattern to filter by file path.
        Shortcut alternative to ``filters.file_pattern``.
    scanner:
        Exact scanner name to filter by.
        Shortcut alternative to ``filters.scanner``.
    limit:
        Max issues returned (applied *after* filtering).  Default 100.

    Returns
    -------
    dict
        ``{"scan_id": "…", "issues": […]}`` on success,
        ``{"error": "…"}`` when the scan is not found.
    """
    state = _get_state_manager()
    scan_result = state.get_scan(scan_id)

    if scan_result is None:
        return {"error": f"Scan '{scan_id}' not found"}

    # Work on a *shallow copy* of the issues list — never mutate the original.
    issues: List[Dict[str, Any]] = copy.deepcopy(
        scan_result.get("issues", [])
    )

    # Resolve the real scan_id when "latest" was requested.
    resolved_id = scan_id
    if scan_id == "latest":
        meta = state.get_scan_metadata("latest")
        if meta:
            resolved_id = meta["scan_id"]

    # ── Build effective filters from both `filters` dict and shortcut params ──
    effective_filters: Dict[str, Any] = dict(filters) if filters else {}
    if severity and "severity" not in effective_filters:
        effective_filters["severity"] = [s.strip() for s in severity.split(",")]
    if file_pattern and "file_pattern" not in effective_filters:
        effective_filters["file_pattern"] = file_pattern
    if scanner and "scanner" not in effective_filters:
        effective_filters["scanner"] = scanner

    # ── Apply filters ─────────────────────────────────────────────
    if effective_filters:
        # severity — list of allowed levels, compared upper-cased.
        severity_filter: Optional[List[str]] = effective_filters.get("severity")
        if severity_filter:
            allowed = {s.upper() for s in severity_filter}
            issues = [
                i for i in issues
                if str(i.get("severity", "")).upper() in allowed
            ]

        # file_pattern — regex matched against issue["file"].
        fp: Optional[str] = effective_filters.get("file_pattern")
        if fp:
            try:
                compiled = re.compile(fp)
                issues = [
                    i for i in issues
                    if compiled.search(str(i.get("file", "")))
                ]
            except re.error:
                pass  # Silently ignore invalid regex.

        # scanner — exact match.
        scanner_filter: Optional[str] = effective_filters.get("scanner")
        if scanner_filter:
            issues = [
                i for i in issues
                if i.get("scanner") == scanner_filter
            ]

        # rule_id — exact match.
        rule_id_filter: Optional[str] = effective_filters.get("rule_id")
        if rule_id_filter:
            issues = [
                i for i in issues
                if i.get("rule_id") == rule_id_filter
            ]

    # ── Limit ─────────────────────────────────────────────────────
    issues = issues[:limit]

    return {
        "scan_id": resolved_id,
        "issues": issues,
    }


# ===================================================================
# Tool 4 — generate_report
# ===================================================================

_REPORTS_DIR = Path.home() / ".supreme2l" / "reports"

# Severity penalty weights for the security score.
_SEVERITY_PENALTIES: Dict[str, int] = {
    "CRITICAL": -30,
    "HIGH":     -15,
    "MEDIUM":    -5,
    "LOW":       -1,
}


def _build_html_report(report: Dict[str, Any]) -> str:
    """Build a professional HTML security report from MCP report data.

    Produces the same visual style as the Supreme 2 Light VS Code extension
    reports (dark theme, score circle, severity cards, findings list).
    """
    import html as html_lib
    try:
        from supreme_max import __version__
    except Exception:
        __version__ = "1.0.0"

    # --- Extract fields from the MCP report structure ---------------------
    metadata = report.get("metadata", {})
    summary = report.get("summary", {})
    issues = report.get("issues", [])
    security_score = report.get("security_score", 100)
    risk_level = report.get("risk_level", "EXCELLENT")
    generated_at = metadata.get("generated_at", datetime.now(timezone.utc).isoformat())
    project_path = metadata.get("project_path", "")

    files_scanned = summary.get("files_scanned", 0)
    issues_found = summary.get("issues_found", len(issues))
    scan_time = summary.get("scan_time", 0.0)
    scanners_used = summary.get("scanners_used", [])

    # --- Severity counts --------------------------------------------------
    actual_counts: Dict[str, int] = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0}
    for issue in issues:
        sev = str(issue.get("severity", "LOW")).upper()
        if sev in actual_counts:
            actual_counts[sev] += 1

    # --- Score colour -----------------------------------------------------
    score = security_score
    if score >= 90:
        score_color = "#22c55e"
    elif score >= 70:
        score_color = "#eab308"
    elif score >= 50:
        score_color = "#f97316"
    else:
        score_color = "#ef4444"

    # --- Format timestamp -------------------------------------------------
    try:
        ts_display = datetime.fromisoformat(generated_at).strftime("%B %d, %Y at %H:%M")
    except Exception:
        ts_display = generated_at

    # --- Build findings HTML ----------------------------------------------
    findings_html = _build_findings_html(issues)

    # --- Assemble full HTML -----------------------------------------------
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supreme 2 MAX Security Report</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}

        :root {{
            --bg: #0d1117;
            --bg-card: #161b22;
            --bg-card-hover: #21262d;
            --border: #30363d;
            --text: #e6edf3;
            --text-muted: #8b949e;
            --primary: #00CED1;
            --primary-dark: #123B70;
            --accent: #98FB92;
            --critical: #f85149;
            --high: #db6d28;
            --medium: #d29922;
            --low: #00CED1;
            --success: #98FB92;
        }}

        body {{
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--bg);
            color: var(--text);
            line-height: 1.6;
            min-height: 100vh;
        }}

        .container {{
            max-width: 1200px;
            margin: 0 auto;
            padding: 40px 24px;
        }}

        .header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 48px;
            padding-bottom: 24px;
            border-bottom: 1px solid var(--border);
        }}

        .logo {{
            display: flex;
            align-items: center;
            gap: 12px;
        }}

        .logo-icon {{
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }}

        .logo-text {{
            font-size: 28px;
            font-weight: 700;
            letter-spacing: -0.5px;
        }}

        .logo-version {{
            font-size: 14px;
            color: var(--text-muted);
            font-weight: 400;
        }}

        .report-meta {{
            text-align: right;
            color: var(--text-muted);
            font-size: 14px;
        }}

        .summary-grid {{
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 40px;
        }}

        .summary-card {{
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 24px;
        }}

        .summary-card.score {{
            grid-column: span 2;
            display: flex;
            align-items: center;
            gap: 24px;
        }}

        .score-circle {{
            position: relative;
            width: 100px;
            height: 100px;
            flex-shrink: 0;
        }}

        .score-circle svg {{
            transform: rotate(-90deg);
            width: 100%;
            height: 100%;
        }}

        .score-bg {{
            fill: none;
            stroke: var(--border);
            stroke-width: 8;
        }}

        .score-progress {{
            fill: none;
            stroke: {score_color};
            stroke-width: 8;
            stroke-linecap: round;
            stroke-dasharray: 251;
            stroke-dashoffset: {251 - (251 * score / 100)};
        }}

        .score-value {{
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: 28px;
            font-weight: 700;
            color: {score_color};
        }}

        .score-info h3 {{
            font-size: 14px;
            color: var(--text-muted);
            font-weight: 500;
            margin-bottom: 4px;
        }}

        .score-info .risk {{
            font-size: 24px;
            font-weight: 600;
        }}

        .summary-label {{
            font-size: 13px;
            color: var(--text-muted);
            margin-bottom: 8px;
            font-weight: 500;
        }}

        .summary-value {{
            font-size: 32px;
            font-weight: 700;
        }}

        .severity-section {{
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 24px;
            margin-bottom: 40px;
        }}

        .section-title {{
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 8px;
        }}

        .severity-grid {{
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 16px;
        }}

        .severity-item {{
            background: var(--bg);
            border-radius: 8px;
            padding: 16px;
            text-align: center;
        }}

        .severity-count {{
            font-size: 36px;
            font-weight: 700;
            margin-bottom: 4px;
        }}

        .severity-count.critical {{ color: var(--critical); }}
        .severity-count.high {{ color: var(--high); }}
        .severity-count.medium {{ color: var(--medium); }}
        .severity-count.low {{ color: var(--low); }}

        .severity-label {{
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }}

        .severity-label.critical {{ color: var(--critical); }}
        .severity-label.high {{ color: var(--high); }}
        .severity-label.medium {{ color: var(--medium); }}
        .severity-label.low {{ color: var(--low); }}

        .findings-section {{
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 24px;
        }}

        .finding {{
            background: var(--bg);
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 16px;
            border-left: 4px solid var(--border);
        }}

        .finding:last-child {{
            margin-bottom: 0;
        }}

        .finding.critical {{ border-left-color: var(--critical); }}
        .finding.high {{ border-left-color: var(--high); }}
        .finding.medium {{ border-left-color: var(--medium); }}
        .finding.low {{ border-left-color: var(--low); }}

        .finding-header {{
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 12px;
            gap: 16px;
        }}

        .finding-location {{
            font-family: 'SF Mono', Monaco, monospace;
            font-size: 13px;
            color: var(--text-muted);
            background: var(--bg-card);
            padding: 4px 10px;
            border-radius: 4px;
        }}

        .finding-badge {{
            font-size: 11px;
            font-weight: 600;
            padding: 4px 10px;
            border-radius: 4px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            flex-shrink: 0;
        }}

        .finding-badge.critical {{ background: var(--critical); color: white; }}
        .finding-badge.high {{ background: var(--high); color: white; }}
        .finding-badge.medium {{ background: var(--medium); color: #1e293b; }}
        .finding-badge.low {{ background: var(--low); color: white; }}

        .finding-message {{
            font-size: 15px;
            color: var(--text);
            margin-bottom: 12px;
            line-height: 1.5;
        }}

        .finding-code {{
            background: #0d1117;
            border: 1px solid var(--border);
            border-radius: 6px;
            padding: 14px;
            font-family: 'SF Mono', Monaco, monospace;
            font-size: 13px;
            color: #e6edf3;
            overflow-x: auto;
            margin-bottom: 12px;
        }}

        .finding-meta {{
            display: flex;
            gap: 20px;
            font-size: 13px;
            color: var(--text-muted);
        }}

        .finding-meta a {{
            color: var(--primary);
            text-decoration: none;
        }}

        .finding-meta a:hover {{
            text-decoration: underline;
        }}

        .no-findings {{
            text-align: center;
            padding: 60px 20px;
            color: var(--success);
        }}

        .no-findings-icon {{
            font-size: 48px;
            margin-bottom: 16px;
        }}

        .no-findings-text {{
            font-size: 18px;
            font-weight: 500;
        }}

        .footer {{
            text-align: center;
            margin-top: 40px;
            padding-top: 24px;
            border-top: 1px solid var(--border);
            color: var(--text-muted);
            font-size: 14px;
        }}

        .footer a {{
            color: var(--primary);
            text-decoration: none;
        }}

        @media (max-width: 768px) {{
            .summary-grid {{
                grid-template-columns: 1fr;
            }}
            .summary-card.score {{
                grid-column: span 1;
            }}
            .severity-grid {{
                grid-template-columns: repeat(2, 1fr);
            }}
            .header {{
                flex-direction: column;
                gap: 16px;
                text-align: center;
            }}
            .report-meta {{
                text-align: center;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <header class="header">
            <div class="logo">
                <div class="logo-icon">🛡️</div>
                <div>
                    <div class="logo-text">Supreme 2 MAX</div>
                    <div class="logo-version">v{__version__}</div>
                </div>
            </div>
            <div class="report-meta">
                <div>Security Scan Report</div>
                <div>{ts_display}</div>
                <div style="margin-top: 4px; font-size: 12px;">{html_lib.escape(project_path)}</div>
            </div>
        </header>

        <div class="summary-grid">
            <div class="summary-card score">
                <div class="score-circle">
                    <svg viewBox="0 0 100 100">
                        <circle cx="50" cy="50" r="40" class="score-bg"/>
                        <circle cx="50" cy="50" r="40" class="score-progress"/>
                    </svg>
                    <div class="score-value">{int(score)}</div>
                </div>
                <div class="score-info">
                    <h3>Security Score</h3>
                    <div class="risk" style="color: {score_color}">{risk_level}</div>
                </div>
            </div>
            <div class="summary-card">
                <div class="summary-label">Total Issues</div>
                <div class="summary-value">{issues_found}</div>
            </div>
            <div class="summary-card">
                <div class="summary-label">Files Scanned</div>
                <div class="summary-value">{files_scanned}</div>
            </div>
        </div>

        <div class="severity-section">
            <h2 class="section-title">Issue Breakdown</h2>
            <div class="severity-grid">
                <div class="severity-item">
                    <div class="severity-count critical">{actual_counts['CRITICAL']}</div>
                    <div class="severity-label critical">Critical</div>
                </div>
                <div class="severity-item">
                    <div class="severity-count high">{actual_counts['HIGH']}</div>
                    <div class="severity-label high">High</div>
                </div>
                <div class="severity-item">
                    <div class="severity-count medium">{actual_counts['MEDIUM']}</div>
                    <div class="severity-label medium">Medium</div>
                </div>
                <div class="severity-item">
                    <div class="severity-count low">{actual_counts['LOW']}</div>
                    <div class="severity-label low">Low</div>
                </div>
            </div>
        </div>

        <div class="findings-section">
            <h2 class="section-title">Findings ({issues_found})</h2>
            {findings_html}
        </div>

        <footer class="footer">
            <p>Generated by <strong>Supreme 2 MAX</strong> v{__version__} &bull; 74+ Security Analyzers</p>
            <p><a href="https://silenceai.net">Silence AI</a></p>
        </footer>
    </div>
</body>
</html>"""

    return html


def _build_findings_html(issues: List[Dict[str, Any]]) -> str:
    """Build the HTML findings cards matching the VS Code extension style."""
    import html as html_lib

    if not issues:
        return """
        <div class="no-findings">
            <h2>All systems operational</h2>
            <p>No vulnerabilities found.</p>
        </div>
        """

    severity_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "UNDEFINED": 4}
    sorted_issues = sorted(
        issues,
        key=lambda i: severity_order.get(str(i.get("severity", "LOW")).upper(), 99),
    )

    parts: List[str] = []
    for issue in sorted_issues:
        severity = str(issue.get("severity", "LOW")).upper()

        # Fields may come from different scan formats — try both key names
        issue_text = html_lib.escape(str(issue.get("issue") or issue.get("message", "Unknown issue")))
        file_path = html_lib.escape(str(issue.get("file", "Unknown")))
        line = issue.get("line", "?")
        code_raw = issue.get("code") or issue.get("code_snippet", "")
        code = html_lib.escape(str(code_raw)) if code_raw else ""
        scanner = html_lib.escape(str(issue.get("scanner", "unknown")))
        confidence = html_lib.escape(str(issue.get("confidence", "N/A")))
        cwe = issue.get("cwe") or issue.get("rule_id", "")
        remediation = html_lib.escape(str(issue.get("remediation", ""))) if issue.get("remediation") else ""

        code_block = f'<div class="code-block">{code}</div>' if code else ""
        cwe_html = (
            f'<div class="meta-item"><span class="meta-label">CWE</span>'
            f'<a href="https://cwe.mitre.org/data/definitions/{html_lib.escape(str(cwe))}.html" '
            f'target="_blank" class="meta-value">{html_lib.escape(str(cwe))}</a></div>'
            if cwe else ""
        )
        remediation_html = (
            f'<div style="margin-top:10px; padding:10px; background:rgba(46,204,113,0.06); '
            f'border-radius:6px; border-left:3px solid #2ecc71; font-size:0.9rem; color:#a0d8b0;">'
            f'<strong style="color:#2ecc71;">Fix:</strong> {remediation}</div>'
            if remediation else ""
        )

        parts.append(f"""
            <div class="card severity-{severity}">
                <div class="card-header">
                    <div class="issue-main">
                        <div class="badges">
                            <span class="badge badge-type">{scanner}</span>
                            <span class="badge severity-badge {severity}">{severity}</span>
                        </div>
                        <div class="issue-title">{issue_text}</div>
                    </div>
                </div>
                <div class="description">{issue_text}</div>
                {code_block}
                {remediation_html}
                <div class="meta-grid">
                    <div class="meta-item">
                        <span class="meta-label">Location</span>
                        <span class="meta-value">{file_path}:{line}</span>
                    </div>
                    <div class="meta-item">
                        <span class="meta-label">Scanner</span>
                        <span class="meta-value">{scanner}</span>
                    </div>
                    <div class="meta-item">
                        <span class="meta-label">Confidence</span>
                        <span class="meta-value">{confidence}</span>
                    </div>
                    {cwe_html}
                </div>
            </div>
        """)

    return "".join(parts)


def _build_remediation_table(issues: List[Dict[str, Any]]) -> str:
    """Build an HTML summary table of findings with severity, file, and remediation."""
    import html as html_lib

    if not issues:
        return ""

    severity_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "UNDEFINED": 4}
    sorted_issues = sorted(
        issues,
        key=lambda i: severity_order.get(str(i.get("severity", "LOW")).upper(), 99),
    )

    rows: List[str] = []
    for idx, issue in enumerate(sorted_issues, 1):
        severity = str(issue.get("severity", "LOW")).upper()
        sev_class = severity.lower()
        issue_text = html_lib.escape(str(issue.get("issue") or issue.get("message", "Unknown")))
        file_path = html_lib.escape(str(issue.get("file", "Unknown")))
        line = issue.get("line", "?")
        scanner = html_lib.escape(str(issue.get("scanner", "unknown")))
        remediation = html_lib.escape(str(issue.get("remediation", "Review and fix manually"))) if issue.get("remediation") else "Review and fix manually"

        rows.append(
            f'<tr>'
            f'<td style="text-align:center;">{idx}</td>'
            f'<td><span class="sev-dot {sev_class}"></span>{severity}</td>'
            f'<td style="max-width:280px;">{issue_text}</td>'
            f'<td><code style="font-size:0.8rem;color:#a29bfe;">{file_path}:{line}</code></td>'
            f'<td>{scanner}</td>'
            f'<td style="max-width:260px;">{remediation}</td>'
            f'</tr>'
        )

    return f"""
    <div class="remediation-section">
        <h2>Vulnerability Summary &amp; Remediation</h2>
        <table class="remediation-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Severity</th>
                    <th>Issue</th>
                    <th>File</th>
                    <th>Scanner</th>
                    <th>Remediation</th>
                </tr>
            </thead>
            <tbody>
                {''.join(rows)}
            </tbody>
        </table>
    </div>
    """


def _compute_security_score(issues: List[Dict[str, Any]]) -> int:
    """Compute a 0-100 security score from a list of issues."""
    penalty = sum(
        _SEVERITY_PENALTIES.get(str(i.get("severity", "")).upper(), 0)
        for i in issues
    )
    return max(0, 100 + penalty)


def _risk_level(score: int) -> str:
    """Map a security score to a human-readable risk level."""
    if score >= 90:
        return "EXCELLENT"
    if score >= 75:
        return "GOOD"
    if score >= 50:
        return "MODERATE"
    if score >= 25:
        return "CONCERNING"
    return "CRITICAL"


def _aggregate_issues(issues: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Build ``by_severity``, ``by_file``, and ``by_scanner`` aggregations."""
    by_severity: Dict[str, int] = {}
    by_file: Dict[str, int] = {}
    by_scanner: Dict[str, int] = {}

    for issue in issues:
        sev = str(issue.get("severity", "UNKNOWN")).upper()
        by_severity[sev] = by_severity.get(sev, 0) + 1

        fpath = str(issue.get("file", "unknown"))
        by_file[fpath] = by_file.get(fpath, 0) + 1

        scanner_name = str(issue.get("scanner", "unknown"))
        by_scanner[scanner_name] = by_scanner.get(scanner_name, 0) + 1

    return {
        "by_severity": by_severity,
        "by_file": by_file,
        "by_scanner": by_scanner,
    }


@mcp.tool()
async def generate_report(scan_id: str = "latest") -> Dict[str, Any]:
    """Generate a full JSON + HTML report for a stored scan.

    The report is saved to ``~/.supreme2l/reports/`` with a timestamped
    filename **and** an HTML version is generated alongside it.  Both
    files are also copied into the scanned project's root directory.

    The HTML report uses the same professional dark-theme design as the
    Supreme 2 Light VS Code extension reports.

    Parameters
    ----------
    scan_id:
        UUID of the scan **or** ``"latest"``.

    Returns
    -------
    dict
        ``{"report_path": "…", "html_report_path": "…", "format": "json+html",
        "message": "…"}`` on success, ``{"error": "…"}`` on failure.
    """
    state = _get_state_manager()
    scan_result = state.get_scan(scan_id)

    if scan_result is None:
        return {"error": f"Scan '{scan_id}' not found"}

    # Resolve the real scan_id.
    resolved_id = scan_id
    if scan_id == "latest":
        meta = state.get_scan_metadata("latest")
        if meta:
            resolved_id = meta["scan_id"]

    issues: List[Dict[str, Any]] = scan_result.get("issues", [])

    security_score = _compute_security_score(issues)
    risk = _risk_level(security_score)
    aggregations = _aggregate_issues(issues)

    now = datetime.now(timezone.utc)

    report: Dict[str, Any] = {
        "metadata": {
            "scan_id": resolved_id,
            "project_path": scan_result.get("project_path", ""),
            "generated_at": now.isoformat(),
            "scanner_version": scan_result.get("scanner_version", "1.0.0"),
        },
        "summary": {
            "files_scanned": scan_result.get("files_scanned", 0),
            "issues_found": len(issues),
            "scan_time": scan_result.get("scan_time", 0.0),
            "scanners_used": scan_result.get("scanners_used", []),
        },
        "aggregations": aggregations,
        "security_score": security_score,
        "risk_level": risk,
        "issues": issues,
    }

    # Persist report -----------------------------------------------------------
    _REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    ts_str = now.strftime('%Y%m%d-%H%M%S')
    filename = f"supreme2l-scan-{ts_str}.json"
    report_path = _REPORTS_DIR / filename
    report_path.write_text(json.dumps(report, indent=2, default=str), encoding="utf-8")

    # Generate HTML report (same style as Supreme 2 Light VS Code extension) ---
    html_content = _build_html_report(report)
    html_filename = f"supreme2l-scan-{ts_str}.html"
    html_report_path = _REPORTS_DIR / html_filename
    html_report_path.write_text(html_content, encoding="utf-8")

    # Also save JSON + HTML in the project root directory ----------------------
    project_path = scan_result.get("project_path", "")
    project_root_json = ""
    project_root_html = ""
    if project_path:
        project_dir = Path(project_path)
        if project_dir.is_dir():
            proj_json = project_dir / f"supreme2l-scan-{ts_str}.json"
            proj_html = project_dir / f"supreme2l-scan-{ts_str}.html"
            proj_json.write_text(
                json.dumps(report, indent=2, default=str), encoding="utf-8"
            )
            proj_html.write_text(html_content, encoding="utf-8")
            project_root_json = str(proj_json)
            project_root_html = str(proj_html)

    # Update metadata in SQLite ------------------------------------------------
    state.update_scan_report_path(resolved_id, str(report_path))

    result: Dict[str, Any] = {
        "report_path": str(report_path),
        "html_report_path": str(html_report_path),
        "format": "json+html",
        "message": "Report generated successfully (JSON + HTML)",
    }
    if project_root_json:
        result["project_report_path"] = project_root_json
        result["project_html_report_path"] = project_root_html

    return result


# ===================================================================
# Tool 5 — analyze_findings
# ===================================================================

_VALID_FP_LEVELS = {"aggressive", "moderate", "conservative"}
_VALID_PRIORITIZE = {"severity", "scanner", "file"}

# Confidence thresholds per fp_filter_level.
_FP_CONFIDENCE_THRESHOLDS: Dict[str, float] = {
    "aggressive": 0.50,
    "moderate": 0.70,
    "conservative": 0.90,
}

_SEVERITY_RANK: Dict[str, int] = {
    "CRITICAL": 5,
    "HIGH": 4,
    "MEDIUM": 3,
    "LOW": 2,
    "INFO": 1,
}


def _priority_score(issue: Dict[str, Any]) -> float:
    """Higher = more urgent.  Combines severity + FP confidence inverse."""
    sev = _SEVERITY_RANK.get(issue.get("severity", "MEDIUM").upper(), 3)
    fp_conf = issue.get("fp_analysis", {}).get("confidence", 0.0)
    return sev * 10 + (1 - fp_conf) * 5


def _issue_context_flags(
    issue: Dict[str, Any],
    test_dirs: set,
    has_validation: bool,
    security_patterns: set,
) -> Dict[str, bool]:
    """Derive contextual boolean flags for a single issue."""
    file_path = issue.get("file", "").lower()

    in_test = any(td.lower() in file_path for td in test_dirs) or any(
        marker in file_path
        for marker in ("test_", "/tests/", "/test/", "__tests__", "/spec/")
    )

    uses_safe = any(
        pat in file_path for pat in ("secure", "crypto", "auth")
    ) or any(
        sp.lower() in file_path for sp in security_patterns
    )

    return {
        "in_test_file": in_test,
        "has_validation": has_validation,
        "uses_safe_api": uses_safe,
    }


def _normalise_finding_for_fp_filter(issue: Dict[str, Any]) -> Dict[str, Any]:
    """Convert the MCP issue schema into the dict shape FalsePositiveFilter
    expects (keys: file, line, scanner, severity, issue, code)."""
    return {
        "file": issue.get("file", ""),
        "line": issue.get("line", 0),
        "scanner": issue.get("scanner", ""),
        "severity": issue.get("severity", "MEDIUM"),
        "issue": issue.get("message", ""),
        "code": issue.get("code_snippet", ""),
        "rule_id": issue.get("rule_id", ""),
    }


@mcp.tool()
async def analyze_findings(
    scan_id: str,
    fp_filter_level: str = "moderate",
    prioritize_by: str = "severity",
) -> Dict[str, Any]:
    """Analyze scan findings to detect false positives and prioritize issues.

    Applies the FalsePositiveFilter with a security-context-aware pipeline
    (1000+ FP patterns, security wrapper detection, docstring exclusion,
    test file detection, language-specific rules) and enriches each issue
    with FP likelihood, confidence score, and contextual flags.

    Args:
        scan_id: The UUID returned by a previous ``run_security_scan`` call.
        fp_filter_level: Filtering aggressiveness — "aggressive" (maximum
            noise reduction, may hide real issues), "moderate" (balanced,
            default), or "conservative" (minimal filtering, more noise).
        prioritize_by: Sort key for returned issues — "severity" (default),
            "scanner", or "file".

    Returns:
        A dictionary with analyzed_issues, summary, and critical_issues.
    """
    # ------------------------------------------------------------------
    # 1. Validate inputs
    # ------------------------------------------------------------------
    fp_filter_level = fp_filter_level.lower()
    if fp_filter_level not in _VALID_FP_LEVELS:
        return {
            "error": f"Invalid fp_filter_level '{fp_filter_level}'. "
                     f"Must be one of: {', '.join(sorted(_VALID_FP_LEVELS))}",
        }

    prioritize_by = prioritize_by.lower()
    if prioritize_by not in _VALID_PRIORITIZE:
        return {
            "error": f"Invalid prioritize_by '{prioritize_by}'. "
                     f"Must be one of: {', '.join(sorted(_VALID_PRIORITIZE))}",
        }

    # ------------------------------------------------------------------
    # 2. Load persisted scan
    # ------------------------------------------------------------------
    state = _get_state_manager()
    scan_result = state.get_scan(scan_id)
    if not scan_result:
        return {"error": f"Scan not found: {scan_id}"}

    raw_issues: List[Dict[str, Any]] = scan_result.get("issues", [])
    if not raw_issues:
        return {
            "analyzed_issues": [],
            "summary": {
                "total_issues": 0,
                "likely_false_positives": 0,
                "high_priority_issues": 0,
                "fp_reduction_rate": "0%",
            },
            "critical_issues": [],
        }

    project_path = scan_result.get("project_path", "")
    resolved_root = Path(project_path) if project_path else Path.cwd()

    # ------------------------------------------------------------------
    # 3. Gather security context via CodePatternAnalyzer (read-only)
    # ------------------------------------------------------------------
    analyzer = CodePatternAnalyzer()

    async def _analyze_repo():
        return await asyncio.to_thread(analyzer.analyze_repo, resolved_root)

    analysis = await _analyze_repo()

    test_dirs: set = analysis.security_context.test_directories
    has_validation: bool = analysis.security_context.has_input_validation
    security_patterns: set = analysis.security_context.security_patterns

    # ------------------------------------------------------------------
    # 4. Run FalsePositiveFilter
    # ------------------------------------------------------------------
    from supreme_max.core.fp_filter import FalsePositiveFilter

    fp_filter = FalsePositiveFilter(source_root=resolved_root)
    confidence_threshold = _FP_CONFIDENCE_THRESHOLDS[fp_filter_level]

    # Convert MCP issues → format expected by FP filter
    compat_findings = [_normalise_finding_for_fp_filter(i) for i in raw_issues]

    def _run_fp():
        return fp_filter.filter_findings(compat_findings)

    retained, likely_fps = await asyncio.to_thread(_run_fp)

    # Use CodePatternAnalyzer's security-context FP check for extra context
    def _run_ctx():
        ctx_map = {}
        for f in compat_findings:
            ctx = analyzer.get_fp_context(analysis, {
                "rule_id": f.get("rule_id", ""),
                "message": f.get("issue", ""),
                "file": f.get("file", ""),
            })
            ctx_map[id(f)] = ctx
        return ctx_map

    ctx_results = await asyncio.to_thread(_run_ctx)

    # ------------------------------------------------------------------
    # 5. Re-classify using the chosen confidence threshold
    # ------------------------------------------------------------------
    final_retained: List[Dict[str, Any]] = []
    final_fps: List[Dict[str, Any]] = []

    for compat, original in zip(compat_findings, raw_issues):
        fp_info = compat.get("fp_analysis", {})
        confidence = fp_info.get("confidence", 0.0)
        is_fp = fp_info.get("is_likely_fp", False)

        classified_as_fp = is_fp and confidence >= confidence_threshold

        # Also incorporate CodePatternAnalyzer context
        ctx = ctx_results.get(id(compat), {})
        ctx_reduction = ctx.get("confidence_reduction", 0)
        if ctx_reduction >= 50 and not classified_as_fp:
            if confidence_threshold <= 0.70:  # aggressive or moderate
                classified_as_fp = True
                fp_info["reason"] = fp_info.get("reason") or "security_context"
                fp_info["explanation"] = (
                    fp_info.get("explanation", "")
                    + "; " + "; ".join(ctx.get("reasons", []))
                ).strip("; ")
                fp_info["confidence"] = max(confidence, ctx_reduction / 100)

        # Build enriched issue entry
        context_flags = _issue_context_flags(
            original, test_dirs, has_validation, security_patterns,
        )

        enriched: Dict[str, Any] = {
            "issue": original,
            "likely_false_positive": classified_as_fp,
            "fp_reason": fp_info.get("reason", ""),
            "confidence": round(fp_info.get("confidence", 0.0), 2),
            "priority_score": round(_priority_score({
                **original,
                "fp_analysis": fp_info,
            }), 2),
            "context": context_flags,
        }

        if classified_as_fp:
            final_fps.append(enriched)
        else:
            final_retained.append(enriched)

    # ------------------------------------------------------------------
    # 6. Sort / prioritize
    # ------------------------------------------------------------------
    def _sort_key(entry: Dict[str, Any]):
        if prioritize_by == "severity":
            return -entry["priority_score"]
        elif prioritize_by == "scanner":
            return (entry["issue"].get("scanner", ""), -entry["priority_score"])
        else:  # file
            return (entry["issue"].get("file", ""), -entry["priority_score"])

    final_retained.sort(key=_sort_key)
    final_fps.sort(key=_sort_key)

    all_analyzed = final_retained + final_fps

    # ------------------------------------------------------------------
    # 7. Pick top-10 critical issues (highest priority, NOT false positives)
    # ------------------------------------------------------------------
    critical_issues = [
        entry for entry in final_retained
        if entry["issue"].get("severity", "").upper() in ("CRITICAL", "HIGH")
    ][:10]

    # ------------------------------------------------------------------
    # 8. Build summary
    # ------------------------------------------------------------------
    total = len(raw_issues)
    fp_count = len(final_fps)
    high_priority = len([
        e for e in final_retained
        if _SEVERITY_RANK.get(e["issue"].get("severity", "").upper(), 0) >= 4
    ])
    fp_rate = f"{fp_count / total * 100:.0f}%" if total else "0%"

    # Sanitize secrets before returning to LLM context
    sanitize_analyzed_issues(all_analyzed)
    sanitize_analyzed_issues(critical_issues)

    return {
        "analyzed_issues": all_analyzed,
        "summary": {
            "total_issues": total,
            "likely_false_positives": fp_count,
            "high_priority_issues": high_priority,
            "fp_reduction_rate": fp_rate,
        },
        "critical_issues": critical_issues,
    }
