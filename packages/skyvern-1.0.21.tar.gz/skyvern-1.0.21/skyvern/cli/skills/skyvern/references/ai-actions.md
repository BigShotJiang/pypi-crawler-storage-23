# AI Actions

## `skyvern_act`

Use for chained interactions on the current page.

Example intent:
"Close the cookie banner, open Filters, choose Remote, then apply."

## `skyvern_extract`

Use for structured output, optionally schema-constrained.

## `skyvern_validate`

Use for binary confirmation of state.

Example:
"The cart total is visible and greater than zero."
