# CLI and MCP Parity Summary

Common mappings:

- `skyvern browser navigate` -> `skyvern_navigate`
- `skyvern browser act` -> `skyvern_act`
- `skyvern browser extract` -> `skyvern_extract`
- `skyvern workflow run` -> `skyvern_workflow_run`
- `skyvern credential list` -> `skyvern_credential_list`

Use CLI for local operator workflows and MCP tools for agent-driven integrations.
