# Changelog

## [0.1.5] - 2026-02-19

### Fixed
- **Linting**: Fixed various lint errors (bare exceptions, line lengths) identified by `ruff`.

## [0.1.4] - 2026-02-19

### Fixed
- **Documentation**: Removed incorrect references to "Typer CLI" and `[cli]` extra in `README.md`.
- **Tests**: Fixed `test_resolve.py` mocking to correctly handle internal `yfinance` attributes.
- **Dependencies**: Clarified that `argparse` is used for the CLI, requiring no extra dependencies.

