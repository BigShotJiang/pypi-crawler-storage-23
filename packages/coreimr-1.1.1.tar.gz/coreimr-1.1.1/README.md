# CoreImR

Advanced, Zero-dependency HTML to Image & PDF converter for Python.

It seamlessly opens a temporary HTML file natively using the headless browser engine (Chromium or Edge) already installed on your machine and takes a screenshot or prints a PDF. **100% zero-dependency**, lightweight, lightning-fast, and feature-rich!

## Full Stack Support
CoreImR natively utilizes the Chromium engine, meaning it fully supports all modern web technologies, development servers, and frameworks:
- **HTML5 & CSS3** (Canvas, SVG, Animations, Flexbox, Grid, Gradient, WebGL)
- **Frameworks & JSX** (React, Next.js, Vue, Svelte) – Works perfectly with code built via `npm` or `npx` (just point CoreImR to your compiled HTML or local dev server!)
- **JavaScript & APIs** (Fetch, WebSockets, dynamic DOM manipulation)
- **Backend Integration** (PHP, Node.js, Python, Rust) – Generate dynamic templates on your backend and pass the output string directly to CoreImR to render receipts, invoices, or dynamic user cards!

## Features (v1.1.1)
- **Zero Dependencies** (only uses the Python standard library `subprocess` and OS built-in browsers)
- **Multi-Format Export** (`output_format='jpeg' | 'png' | 'bmp' | 'pdf'`) - natively generates PNGs and vector PDFs. Other formats convert seamlessly (install `Pillow` optionally for ultra-fast image conversions)
- Configurable **Dimensions** (`width`, `height`)
- Support for **Transparent Backgrounds** (`transparent=True` - perfectly cuts the background out!)
- **Delay / Virtual Time Budget** (`delay`) - wait for animations/JS to load before capture
- **High DPI / Retina support** (`device_scale_factor`) - scale up resolution cleanly for super-crisp text
- **Timeouts** (`timeout`) - Safety mechanism to kill hung browser processes

## Installation

```bash
pip install coreimr
```

## Usage

### Simple Example

```python
from coreimr import render

render('<h1>Hello World!</h1>', 'output.png')
```

### Advanced Example

```python
from coreimr import CoreImR

html = """
<!DOCTYPE html>
<html>
<body style="background: transparent; margin: 0; width: 100vw; height: 100vh; display: flex; align-items: center; justify-content: center;">
    <h1 style="color: black; font-family: sans-serif;">Stable CoreImR with Transparent Background!</h1>
</body>
</html>
"""

# High DPI scaling, perfectly working transparency, and process safety timeouts!
imr = CoreImR(
    width=1920, 
    height=1080, 
    transparent=True, 
    delay=500,
    device_scale_factor=2, # Renders at 2x resolution (3840x2160) for crisp text
    output_format='png',   # You can also use 'pdf', 'jpeg', or 'bmp'!
    timeout=15             # Kills the process if rendering takes longer than 15s
)

imr.render(html, 'output_advanced_v1.1.1.png')
```

## Publishing & Contributing
If you're developing locally:
1. Build local wheels: `python setup.py sdist bdist_wheel`
2. Publish to PyPI: `twine upload dist/*`

Enjoy building completely independent systems!