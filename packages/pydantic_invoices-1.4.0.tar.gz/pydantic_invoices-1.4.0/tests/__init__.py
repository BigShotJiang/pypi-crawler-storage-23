"""Tests for pydantic_invoices package."""
