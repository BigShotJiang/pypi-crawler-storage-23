from redis import Redis

redis_client = Redis()
