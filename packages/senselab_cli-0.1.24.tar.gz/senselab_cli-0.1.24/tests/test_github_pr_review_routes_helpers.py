import unittest
from flask import Flask
from types import SimpleNamespace

from api.routes.github import (
    _get_metrics_window,
    _build_mode_workflow_map_for_specialist,
    _refresh_binding_mode_map,
    _infer_review_mode_from_workflow_name,
    _is_internal_worker_call,
    _is_pr_paused,
    _resolve_review_modes_for_event,
    _upsert_pr_pause_state,
    _workflow_ids_for_mode,
)
from unittest.mock import MagicMock, patch


class GitHubPRReviewRouteHelpersTest(unittest.TestCase):
    def setUp(self):
        self.app = Flask(__name__)
        self.app.config["APP_SECRET_KEY"] = "test-secret"

    def test_internal_worker_call_authorized(self):
        with self.app.test_request_context(
            "/api/github/project/pr-reviews/process/worker",
            method="POST",
            headers={"X-Internal-Worker-Key": "test-secret"},
        ):
            self.assertTrue(_is_internal_worker_call(self._request_proxy()))

    def test_internal_worker_call_unauthorized(self):
        with self.app.test_request_context(
            "/api/github/project/pr-reviews/process/worker",
            method="POST",
            headers={"X-Internal-Worker-Key": "wrong"},
        ):
            self.assertFalse(_is_internal_worker_call(self._request_proxy()))

    def test_metrics_window_defaults(self):
        with self.app.test_request_context("/metrics"):
            bucket, since = _get_metrics_window()
            self.assertEqual(bucket, "day")
            self.assertIsNotNone(since)

    def test_metrics_window_respects_bounds(self):
        with self.app.test_request_context("/metrics?bucket=hour&lookback_days=9999"):
            bucket, since = _get_metrics_window()
            self.assertEqual(bucket, "hour")
            self.assertIsNotNone(since)

    def test_review_mode_inference_for_swe_workflows(self):
        self.assertEqual(
            _infer_review_mode_from_workflow_name("Open PR review"),
            "OPEN_PR_REVIEW",
        )
        self.assertEqual(
            _infer_review_mode_from_workflow_name("Maintainability and Design"),
            "MAINTAINABILITY_AND_DESIGN",
        )
        self.assertEqual(
            _infer_review_mode_from_workflow_name("Test and quality analysis"),
            "TEST_AND_QUALITY_ANALYSIS",
        )
        self.assertEqual(
            _infer_review_mode_from_workflow_name("PR Tests & Quality Gates Review Function"),
            "TEST_AND_QUALITY_ANALYSIS",
        )
        self.assertEqual(
            _infer_review_mode_from_workflow_name("PR Test & Quality Gates Review Function"),
            "TEST_AND_QUALITY_ANALYSIS",
        )
        self.assertEqual(
            _infer_review_mode_from_workflow_name("PR Maintainability & Design Review Function"),
            "MAINTAINABILITY_AND_DESIGN",
        )
        self.assertEqual(
            _infer_review_mode_from_workflow_name("PR Maintainability Design Review Function"),
            "MAINTAINABILITY_AND_DESIGN",
        )
        self.assertEqual(
            _infer_review_mode_from_workflow_name("PR Maintainability Review Function"),
            "MAINTAINABILITY_AND_DESIGN",
        )
        self.assertEqual(
            _infer_review_mode_from_workflow_name("PR Perf & Cost Review Function"),
            "PERFORMANCE_AND_COST",
        )
        self.assertEqual(
            _infer_review_mode_from_workflow_name("PR Perf Cost Review Function"),
            "PERFORMANCE_AND_COST",
        )
        self.assertEqual(
            _infer_review_mode_from_workflow_name("PR Test & Quality Gates Review Function"),
            "TEST_AND_QUALITY_ANALYSIS",
        )
        self.assertEqual(
            _infer_review_mode_from_workflow_name("PR Security Review Deep Dive Function"),
            "SECURITY_DEEP_DIVE",
        )
        self.assertEqual(
            _infer_review_mode_from_workflow_name("PR Security Deep Dive Function"),
            "SECURITY_DEEP_DIVE",
        )

    def test_review_mode_inference_for_sre_workflow(self):
        self.assertEqual(
            _infer_review_mode_from_workflow_name("Master PR Review"),
            "PR_REVIEW",
        )
        self.assertEqual(
            _infer_review_mode_from_workflow_name("Master PR Review Function"),
            "PR_REVIEW",
        )
        self.assertEqual(
            _infer_review_mode_from_workflow_name("PR Master Review Function"),
            "PR_REVIEW",
        )

    def test_review_mode_inference_unknown(self):
        self.assertIsNone(_infer_review_mode_from_workflow_name("Daily Infra Summary"))

    def test_workflow_ids_for_mode_supports_string_and_list(self):
        class _Binding:
            mode_workflow_map = {
                "PR_REVIEW": "wf-1",
                "OPEN_PR_REVIEW": ["wf-a", "wf-b"],
            }

        self.assertEqual(_workflow_ids_for_mode(_Binding(), "PR_REVIEW"), ["wf-1"])
        self.assertEqual(_workflow_ids_for_mode(_Binding(), "OPEN_PR_REVIEW"), ["wf-a", "wf-b"])
        self.assertEqual(_workflow_ids_for_mode(_Binding(), "UNKNOWN"), [])

    def test_resolve_review_modes_for_event_full_review_includes_mode_map(self):
        class _Binding:
            enabled_review_modes = ["PR_REVIEW"]
            mode_workflow_map = {
                "PR_REVIEW": "wf-master",
                "SECURITY_DEEP_DIVE": "wf-security",
                "__workflow_allowlist__": ["wf-master", "wf-security"],
            }

        self.assertEqual(
            _resolve_review_modes_for_event(_Binding(), "full_review"),
            ["PR_REVIEW", "SECURITY_DEEP_DIVE"],
        )
        self.assertEqual(
            _resolve_review_modes_for_event(_Binding(), "review"),
            ["PR_REVIEW"],
        )

    def test_is_pr_paused_returns_true_when_state_exists(self):
        paused_state = SimpleNamespace(is_paused=True)
        mocked_query = MagicMock()
        mocked_query.filter_by.return_value.first.return_value = paused_state

        with patch("api.routes.github.PRReviewPauseState.query", mocked_query):
            self.assertTrue(
                _is_pr_paused(
                    project_guid="proj",
                    repository_full_name="org/repo",
                    pull_request_number=123,
                    assistant_guid="assistant",
                    review_mode="PR_REVIEW",
                )
            )

    def test_upsert_pr_pause_state_updates_existing_row(self):
        existing = SimpleNamespace(
            is_paused=False,
            source_command="pause",
            updated_by="old",
        )
        mocked_query = MagicMock()
        mocked_query.filter_by.return_value.first.return_value = existing

        with patch("api.routes.github.PRReviewPauseState.query", mocked_query):
            with patch("api.routes.github.db.session.add") as mocked_add:
                state = _upsert_pr_pause_state(
                    project_guid="proj",
                    repository_full_name="org/repo",
                    pull_request_number=123,
                    assistant_guid="assistant",
                    review_mode="PR_REVIEW",
                    is_paused=True,
                    source_command="resume",
                    updated_by="tester",
                )

        self.assertIs(state, existing)
        self.assertTrue(existing.is_paused)
        self.assertEqual(existing.source_command, "resume")
        self.assertEqual(existing.updated_by, "tester")
        mocked_add.assert_not_called()

    def test_upsert_pr_pause_state_creates_new_row_when_missing(self):
        mocked_query = MagicMock()
        mocked_query.filter_by.return_value.first.return_value = None

        created_rows = []

        def _capture_new_row(row):
            created_rows.append(row)

        with patch("api.routes.github.PRReviewPauseState.query", mocked_query):
            with patch("api.routes.github.db.session.add", side_effect=_capture_new_row):
                state = _upsert_pr_pause_state(
                    project_guid="proj",
                    repository_full_name="org/repo",
                    pull_request_number=99,
                    assistant_guid="assistant",
                    review_mode="SECURITY_DEEP_DIVE",
                    is_paused=True,
                    source_command="pause",
                    updated_by="tester",
                )

        self.assertEqual(len(created_rows), 1)
        self.assertIs(state, created_rows[0])
        self.assertTrue(state.is_paused)
        self.assertEqual(state.source_command, "pause")
        self.assertEqual(state.updated_by, "tester")

    def test_build_mode_workflow_map_for_specialist_honors_allowed_workflow_ids(self):
        wf_master = MagicMock(id="wf-master", workflow_name="Master PR Review Function")
        wf_security = MagicMock(id="wf-security", workflow_name="PR Security Deep Dive Function")
        mocked_query = MagicMock()
        mocked_query.filter_by.return_value.all.return_value = [wf_master, wf_security]

        with patch("api.routes.github.SpecialistWorkflows.query", mocked_query):
            mode_map = _build_mode_workflow_map_for_specialist(
                specialist_guid="specialist-1",
                allowed_workflow_ids={"wf-security"},
            )

        self.assertEqual(mode_map, {"SECURITY_DEEP_DIVE": "wf-security"})

    def test_build_mode_workflow_map_for_specialist_returns_empty_when_allowlist_has_no_matches(self):
        wf_master = MagicMock(id="wf-master", workflow_name="Master PR Review Function")
        mocked_query = MagicMock()
        mocked_query.filter_by.return_value.all.return_value = [wf_master]

        with patch("api.routes.github.SpecialistWorkflows.query", mocked_query):
            mode_map = _build_mode_workflow_map_for_specialist(
                specialist_guid="specialist-1",
                allowed_workflow_ids={"wf-other"},
            )

        self.assertEqual(mode_map, {})

    def test_refresh_binding_mode_map_preserves_existing_workflow_allowlist(self):
        wf_master = MagicMock(id="wf-master", workflow_name="Master PR Review Function")
        wf_security = MagicMock(id="wf-security", workflow_name="PR Security Deep Dive Function")
        mocked_query = MagicMock()
        mocked_query.filter_by.return_value.all.return_value = [wf_master, wf_security]

        class _Binding:
            assistant_guid = "specialist-1"
            enabled_review_modes = ["PR_REVIEW"]
            mode_workflow_map = {"PR_REVIEW": "wf-master"}

        binding = _Binding()
        with patch("api.routes.github.SpecialistWorkflows.query", mocked_query):
            changed = _refresh_binding_mode_map(binding)

        self.assertFalse(changed)
        self.assertEqual(binding.mode_workflow_map, {"PR_REVIEW": "wf-master"})
        self.assertEqual(binding.enabled_review_modes, ["PR_REVIEW"])

    def test_refresh_binding_mode_map_ignores_legacy_mapping_subset_without_allowlist(self):
        wf_master = MagicMock(id="wf-master", workflow_name="Master PR Review Function")
        wf_security = MagicMock(id="wf-security", workflow_name="PR Security Deep Dive Function")
        mocked_query = MagicMock()
        mocked_query.filter_by.return_value.all.return_value = [wf_master, wf_security]

        class _Binding:
            assistant_guid = "specialist-1"
            enabled_review_modes = ["PR_REVIEW"]
            mode_workflow_map = {"PR_REVIEW": "wf-master"}

        binding = _Binding()
        with patch("api.routes.github.SpecialistWorkflows.query", mocked_query):
            changed = _refresh_binding_mode_map(binding)

        self.assertTrue(changed)
        self.assertEqual(
            binding.mode_workflow_map,
            {"PR_REVIEW": "wf-master", "SECURITY_DEEP_DIVE": "wf-security"},
        )

    @staticmethod
    def _request_proxy():
        from flask import request

        return request


if __name__ == "__main__":
    unittest.main()
