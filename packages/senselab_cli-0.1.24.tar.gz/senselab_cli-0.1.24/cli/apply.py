from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable
from uuid import UUID

import yaml

from cli.api import APIClient, APIError


@dataclass
class ApplyAgentResult:
    agent_name: str
    specialist_guid: str
    connectors_attached: int
    functions_created: int
    config_applied: bool


@dataclass
class ApplyResult:
    agents: list[ApplyAgentResult]
    agents_created: int
    connectors_attached_total: int
    functions_created_total: int


def _is_uuid(value: str) -> bool:
    try:
        UUID(value)
        return True
    except Exception:
        return False


def _extract_credential_guid(item: dict[str, Any]) -> str | None:
    for key in ("tool_cred_guid", "cred_guid", "db_secret", "guid", "id"):
        value = item.get(key)
        if value:
            return str(value)
    return None


def _extract_credential_name(item: dict[str, Any]) -> str | None:
    for key in ("tool_cred_name", "cred_name", "connection_name", "name"):
        value = item.get(key)
        if value:
            return str(value)
    return None


def _resolve_connector_reference(
    connector_ref: str, connector_instances: list[dict[str, Any]]
) -> str:
    if _is_uuid(connector_ref):
        return connector_ref

    for item in connector_instances:
        if _extract_credential_name(item) == connector_ref:
            cred_guid = _extract_credential_guid(item)
            if cred_guid:
                return cred_guid

    raise APIError(
        f"Connector reference '{connector_ref}' not found in project connector instances."
    )


def _build_specialist_payload(spec: dict[str, Any]) -> dict[str, Any]:
    required = ("name", "system_prompt", "prompt_template", "role_guid", "llm_guid")
    missing = [field for field in required if not spec.get(field)]
    if missing:
        raise APIError(f"assistant is missing required fields: {', '.join(missing)}")

    payload: dict[str, Any] = {
        "name": spec["name"],
        "system_prompt": spec["system_prompt"],
        "prompt_template": spec["prompt_template"],
        "role_guid": spec["role_guid"],
        "llm_guid": spec["llm_guid"],
    }
    if spec.get("description"):
        payload["description"] = spec["description"]
    payload["is_default"] = False
    return payload


def _build_config_payload(connectors: list[dict[str, Any]]) -> dict[str, Any]:
    config_payload: dict[str, Any] = {}
    generic_items: list[dict[str, Any]] = []
    for item in connectors:
        connector_type = str(item.get("type") or "").strip().lower()
        connector_aliases = {
            "aws": "aws_services",
            "gcp": "gcp_services",
            "github": "github_repos",
            "gitlab": "gitlab_repos",
        }
        connector_type = connector_aliases.get(connector_type, connector_type)
        cred_guid = item["resolved_cred_guid"]
        config = item.get("config", {})

        if connector_type == "github_repos":
            config_payload["github_repos"] = {
                "tool_cred_guid": cred_guid,
                "repos": config.get("repos", []),
            }
        elif connector_type == "gitlab_repos":
            config_payload["gitlab_repos"] = {
                "tool_cred_guid": cred_guid,
                "repos": config.get("repos", []),
            }
        elif connector_type == "aws_services":
            config_payload["aws_services"] = {
                "tool_cred_guid": cred_guid,
                "region": config.get("region", ""),
                "services": config.get("services", []),
                "context": config.get("context", ""),
            }
        elif connector_type == "gcp_services":
            config_payload["gcp_services"] = {
                "tool_cred_guid": cred_guid,
                "region": config.get("region", ""),
                "services": config.get("services", []),
                "context": config.get("context", ""),
            }
        elif connector_type == "generic":
            generic_items.append(
                {
                    "tool_cred_guid": cred_guid,
                    "plugin": config.get("plugin", ""),
                    "context": config.get("context", ""),
                }
            )
    if generic_items:
        config_payload["generic"] = generic_items
    return config_payload


def _build_workflows_payload(functions: list[dict[str, Any]]) -> list[dict[str, Any]]:
    workflows: list[dict[str, Any]] = []
    for function in functions:
        if not isinstance(function, dict):
            raise APIError("functions entries must be objects.")
        function_name = function.get("function_name") or function.get("workflow_name")
        if not function_name or not function.get("definition"):
            raise APIError(
                "Each custom function must include function_name and definition fields."
            )
        workflows.append(
            {
                "workflow_name": function_name,
                "definition": function["definition"],
                "variables": function.get("variables"),
                "schema_version": function.get("schema_version", "1.0.0"),
            }
        )
    return workflows


def load_apply_file(path: str) -> dict[str, Any]:
    apply_path = Path(path).expanduser()
    if not apply_path.exists():
        raise APIError(f"YAML file not found: {apply_path}")

    with apply_path.open("r", encoding="utf-8") as f:
        parsed = yaml.safe_load(f)
    if not isinstance(parsed, dict):
        raise APIError("YAML root must be an object.")
    return parsed


def _extract_agent_specs(payload: dict[str, Any]) -> list[dict[str, Any]]:
    if "agent" in payload:
        agent_spec = payload.get("agent")
        if isinstance(agent_spec, dict):
            return [agent_spec]
        if isinstance(agent_spec, list):
            specs = [item for item in agent_spec if isinstance(item, dict)]
            if len(specs) != len(agent_spec):
                raise APIError("When using 'agent' as a list, all entries must be objects.")
            return specs
        raise APIError("'agent' must be an object or a list of objects.")

    # Backward compatibility with previous key.
    if "assistant" in payload:
        assistant_spec = payload.get("assistant")
        if isinstance(assistant_spec, dict):
            return [assistant_spec]
        raise APIError("'assistant' must be an object.")

    raise APIError("Missing required 'agent' section in YAML.")


def _resolve_role_prompt_reference(
    role_details: dict[str, Any],
    function_ref: str,
) -> dict[str, Any]:
    ref = function_ref.strip()
    if not ref:
        raise APIError("Function reference cannot be empty.")

    prompts = role_details.get("workflow_prompts") or []
    by_id: list[dict[str, Any]] = []
    by_name: list[dict[str, Any]] = []
    for item in prompts:
        if not isinstance(item, dict):
            continue
        prompt_id = str(item.get("id") or "").strip()
        prompt_name = str(item.get("name") or "").strip()
        if prompt_id and prompt_id == ref:
            by_id.append(item)
        if prompt_name and prompt_name.casefold() == ref.casefold():
            by_name.append(item)

    if by_id:
        return by_id[0]
    if len(by_name) == 1:
        return by_name[0]
    if len(by_name) > 1:
        options = ", ".join([f"{x.get('name')} ({x.get('id')})" for x in by_name[:5]])
        raise APIError(
            f"More than one role function matches '{ref}'.",
            suggestion=f"Use function ID instead. Matches: {options}",
        )

    raise APIError(
        f"Role function '{ref}' was not found in the selected role.",
        suggestion="Run `sense-cli agent roles --list` and `sense-cli agent function --list` to find valid names.",
    )


def _resolve_functions_payload(
    functions: list[Any],
    role_details: dict[str, Any],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    generated_prompts: list[dict[str, Any]] = []
    custom_workflows_input: list[dict[str, Any]] = []

    for entry in functions:
        if isinstance(entry, str):
            generated_prompts.append(_resolve_role_prompt_reference(role_details, entry))
            continue
        if not isinstance(entry, dict):
            raise APIError("functions entries must be strings or objects.")

        # Backward-compatible custom workflow creation path.
        if entry.get("definition"):
            custom_workflows_input.append(entry)
            continue

        function_ref = entry.get("function_name") or entry.get("workflow_name") or entry.get("id")
        if not function_ref:
            raise APIError(
                "Each function entry must include function_name (or id)."
            )
        generated_prompts.append(_resolve_role_prompt_reference(role_details, str(function_ref)))

    deduped_generated: list[dict[str, Any]] = []
    seen_prompt_ids: set[str] = set()
    for item in generated_prompts:
        prompt_id = str(item.get("id") or "").strip()
        if not prompt_id or prompt_id in seen_prompt_ids:
            continue
        seen_prompt_ids.add(prompt_id)
        deduped_generated.append(item)
    return deduped_generated, _build_workflows_payload(custom_workflows_input)


def apply_assistant_config(
    api: APIClient,
    project_guid: str,
    payload: dict[str, Any],
    dry_run: bool = False,
    progress: Callable[[str, str], None] | None = None,
) -> ApplyResult:
    agents = _extract_agent_specs(payload)
    root_connectors = payload.get("connectors", [])
    root_functions = payload.get("functions", [])
    if root_connectors is None:
        root_connectors = []
    if root_functions is None:
        root_functions = []
    if not isinstance(root_connectors, list):
        raise APIError("'connectors' must be a list.")
    if not isinstance(root_functions, list):
        raise APIError("'functions' must be a list.")

    roles = api.get_specialist_roles(project_guid, is_active=None)
    connector_instances = api.list_connector_instances(project_guid)

    llm_connections = []
    for conn in connector_instances:
        if not isinstance(conn, dict):
            continue
        plugin = str(conn.get("plugin", "")).strip()
        if plugin.casefold() == "raia llm".casefold():
            llm_connections.append(conn)

    results: list[ApplyAgentResult] = []
    for index, agent in enumerate(agents, start=1):
        agent_name = str(agent.get("name") or "").strip() or f"agent-{index}"
        connectors = agent.get("connectors", root_connectors)
        functions = agent.get("functions", root_functions)
        if connectors is None:
            connectors = []
        if functions is None:
            functions = []
        if not isinstance(connectors, list):
            raise APIError(f"agent '{agent_name}' has invalid connectors. Expected a list.")
        if not isinstance(functions, list):
            raise APIError(f"agent '{agent_name}' has invalid functions. Expected a list.")

        if progress:
            progress("resolve_role", f"Resolving defaults for agent '{agent_name}'...")
        role_guid = str(agent.get("role_guid", "")).strip()
        if not role_guid:
            raise APIError(f"agent '{agent_name}' is missing required field: role_guid")

        role_details: dict[str, Any] | None = None
        for item in roles:
            if not isinstance(item, dict):
                continue
            if str(item.get("role_guid", "")).strip() == role_guid:
                role_details = item
                break
        if role_details is None:
            raise APIError(
                f"Role '{role_guid}' was not found for this project.",
                suggestion="Run `sense-cli agent roles --list` to list valid role GUIDs.",
            )

        resolved_llm_guid = str(agent.get("llm_guid") or "").strip()
        if not resolved_llm_guid:
            if progress:
                progress("resolve_llm", f"Resolving default Raia LLM for '{agent_name}'...")
            if not llm_connections:
                raise APIError(
                    "Could not find a default 'Raia LLM' connection for this project.",
                    suggestion=(
                        "Configure the Raia LLM connection first, or provide agent.llm_guid "
                        "explicitly in your YAML."
                    ),
                )
            default_llm = next((item for item in llm_connections if item.get("default")), llm_connections[0])
            llm_guid = _extract_credential_guid(default_llm)
            if not llm_guid:
                raise APIError("Could not resolve a valid llm_guid from the default Raia LLM connection.")
            resolved_llm_guid = llm_guid

        resolved_system_prompt = str(
            agent.get("system_prompt") or role_details.get("system_prompt") or ""
        ).strip()
        if not resolved_system_prompt:
            raise APIError(
                f"agent '{agent_name}' is missing system_prompt and role has no default.",
                suggestion=(
                    "Add `system_prompt` to YAML, or choose a role that has a default system prompt."
                ),
            )

        resolved_prompt_template = str(
            agent.get("prompt_template") or role_details.get("prompt_template") or ""
        ).strip()
        if not resolved_prompt_template:
            raise APIError(
                f"agent '{agent_name}' is missing prompt_template and role has no default.",
                suggestion=(
                    "Add `prompt_template` to YAML, or choose a role that has a default prompt template."
                ),
            )

        resolved_agent = dict(agent)
        resolved_agent["llm_guid"] = resolved_llm_guid
        resolved_agent["system_prompt"] = resolved_system_prompt
        resolved_agent["prompt_template"] = resolved_prompt_template
        resolved_agent["is_default"] = False
        specialist_payload = _build_specialist_payload(resolved_agent)

        resolved_connectors: list[dict[str, Any]] = []
        for connector in connectors:
            if not isinstance(connector, dict):
                raise APIError("Each connector entry must be an object.")
            connector_ref = connector.get("connector")
            if not connector_ref:
                raise APIError("Each connector entry must include 'connector'.")
            resolved_guid = _resolve_connector_reference(str(connector_ref), connector_instances)
            resolved_connectors.append({**connector, "resolved_cred_guid": resolved_guid})

        generated_prompts, custom_workflows_payload = _resolve_functions_payload(functions, role_details)
        config_payload = _build_config_payload(resolved_connectors)
        tool_cred_guids = [item["resolved_cred_guid"] for item in resolved_connectors]

        specialist_guid = "dry-run"
        if not dry_run:
            if progress:
                progress("create_agent", f"Creating agent '{agent_name}'...")
            create_payload = {**specialist_payload}
            if tool_cred_guids:
                create_payload["tool_cred_guids"] = tool_cred_guids
            specialist_result = api.create_specialist(project_guid, create_payload)
            specialist_guid = str(specialist_result.get("specialist_guid") or "")
            if not specialist_guid:
                raise APIError("Failed to create specialist: missing specialist_guid in response.")

            if config_payload:
                if progress:
                    progress("attach_connectors", f"Applying connector context for '{agent_name}'...")
                api.configure_specialist(project_guid, specialist_guid, config_payload)

            if generated_prompts:
                if progress:
                    progress("enable_functions", f"Generating role functions for '{agent_name}'...")
                api.generate_functions_for_specialist(
                    project_guid,
                    specialist_guid,
                    generated_prompts,
                )

            if custom_workflows_payload:
                if progress:
                    progress("create_custom_functions", f"Creating custom functions for '{agent_name}'...")
                api.create_specialist_workflows(project_guid, specialist_guid, custom_workflows_payload)

        results.append(
            ApplyAgentResult(
                agent_name=agent_name,
                specialist_guid=specialist_guid,
                connectors_attached=len(tool_cred_guids),
                functions_created=len(generated_prompts) + len(custom_workflows_payload),
                config_applied=bool(config_payload),
            )
        )

    if progress:
        progress("done", "Done.")
    return ApplyResult(
        agents=results,
        agents_created=len(results),
        connectors_attached_total=sum(item.connectors_attached for item in results),
        functions_created_total=sum(item.functions_created for item in results),
    )

