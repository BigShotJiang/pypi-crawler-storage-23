from __future__ import annotations

import json
import os
import re
import stat
import subprocess
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from cli.api import APIClient
from cli.config import CLIConfig

LINEAGE_MARKER_START = "# >>> sense-cli lineage >>>"
LINEAGE_MARKER_END = "# <<< sense-cli lineage <<<"
LINEAGE_HOOK = "pre-push"
LINEAGE_HOOKS = ("pre-commit", "commit-msg", LINEAGE_HOOK)
LINEAGE_DIR = ".sense-cli/lineage"
LINEAGE_EVENTS_FILE = "events.jsonl"
LINEAGE_SESSION_HINTS_FILE = "session_hints.json"
LINEAGE_SESSIONS_DIR = ".sense-cli/sessions"
LINEAGE_CHECKPOINTS_DIR = ".sense-cli/checkpoints"
LINEAGE_CURRENT_SESSION_FILE = "current.json"


def resolve_repo_root(repo: str | None = None) -> Path:
    if repo:
        root = Path(repo).expanduser().resolve()
        if not (root / ".git").exists():
            raise ValueError(f"Not a git repository: {root}")
        return root

    result = _run_git(["git", "rev-parse", "--show-toplevel"])
    if result is None:
        raise ValueError("No git repository found. Run inside a repo or pass --repo.")
    return Path(result).resolve()


def lineage_dir(repo_root: Path) -> Path:
    return repo_root / LINEAGE_DIR


def lineage_events_path(repo_root: Path) -> Path:
    return lineage_dir(repo_root) / LINEAGE_EVENTS_FILE


def lineage_session_hints_path(repo_root: Path) -> Path:
    return lineage_dir(repo_root) / LINEAGE_SESSION_HINTS_FILE


def lineage_current_session_path(repo_root: Path) -> Path:
    return repo_root / LINEAGE_SESSIONS_DIR / LINEAGE_CURRENT_SESSION_FILE


def lineage_session_file_path(repo_root: Path, session_id: str) -> Path:
    safe = _safe_identifier(session_id)
    return repo_root / LINEAGE_SESSIONS_DIR / f"{safe}.json"


def lineage_checkpoint_file_path(repo_root: Path, checkpoint_id: str) -> Path:
    safe = _safe_identifier(checkpoint_id)
    return repo_root / LINEAGE_CHECKPOINTS_DIR / f"{safe}.json"


def hook_file_path(repo_root: Path, hook_name: str = LINEAGE_HOOK) -> Path:
    return repo_root / ".git" / "hooks" / hook_name


def build_hook_block(repo_root: Path, hook_name: str = LINEAGE_HOOK) -> str:
    quoted_repo = _shell_quote(str(repo_root))
    capture_cmd = f"sense-cli --quiet lineage capture --hook {hook_name} --repo {quoted_repo}"
    if hook_name == "commit-msg":
        capture_cmd += ' --commit-msg-file "$1"'
    lines = [
        LINEAGE_MARKER_START,
        'if command -v sense-cli >/dev/null 2>&1; then',
        f"  {capture_cmd} >/dev/null 2>&1 || true",
    ]
    if hook_name == LINEAGE_HOOK:
        lines.append(f"  sense-cli --quiet lineage sync --repo {quoted_repo} >/dev/null 2>&1 || true")
    lines.extend(
        [
        "fi",
        LINEAGE_MARKER_END,
        ]
    )
    return "\n".join(lines) + "\n"


def is_lineage_enabled(repo_root: Path) -> bool:
    return bool(installed_lineage_hooks(repo_root))


def installed_lineage_hooks(repo_root: Path) -> list[str]:
    installed: list[str] = []
    for hook_name in LINEAGE_HOOKS:
        hook_path = hook_file_path(repo_root, hook_name=hook_name)
        if not hook_path.exists():
            continue
        content = hook_path.read_text(encoding="utf-8", errors="ignore")
        if LINEAGE_MARKER_START in content and LINEAGE_MARKER_END in content:
            installed.append(hook_name)
    return installed


def install_lineage_hook(repo_root: Path) -> None:
    for hook_name in LINEAGE_HOOKS:
        hook_path = hook_file_path(repo_root, hook_name=hook_name)
        hook_path.parent.mkdir(parents=True, exist_ok=True)
        existing = hook_path.read_text(encoding="utf-8", errors="ignore") if hook_path.exists() else ""
        block = build_hook_block(repo_root, hook_name=hook_name)
        updated = _replace_marker_block(existing, block)

        if not updated.startswith("#!"):
            updated = "#!/usr/bin/env sh\nset -e\n\n" + updated

        hook_path.write_text(updated, encoding="utf-8")
        _ensure_executable(hook_path)

    lineage_dir(repo_root).mkdir(parents=True, exist_ok=True)
    events_path = lineage_events_path(repo_root)
    if not events_path.exists():
        events_path.write_text("", encoding="utf-8")
    (repo_root / LINEAGE_SESSIONS_DIR).mkdir(parents=True, exist_ok=True)
    (repo_root / LINEAGE_CHECKPOINTS_DIR).mkdir(parents=True, exist_ok=True)


def remove_lineage_hook(repo_root: Path) -> bool:
    removed_any = False
    for hook_name in LINEAGE_HOOKS:
        hook_path = hook_file_path(repo_root, hook_name=hook_name)
        if not hook_path.exists():
            continue
        content = hook_path.read_text(encoding="utf-8", errors="ignore")
        updated, changed = _remove_marker_block(content)
        if not changed:
            continue
        # Keep custom hooks untouched; if empty shell remains, leave it valid.
        if not updated.strip():
            updated = "#!/usr/bin/env sh\nset -e\n"
        hook_path.write_text(updated, encoding="utf-8")
        _ensure_executable(hook_path)
        removed_any = True
    return removed_any


def capture_event(
    repo_root: Path,
    hook_name: str = LINEAGE_HOOK,
    commit_msg_file: str | None = None,
) -> dict[str, Any]:
    repo_full_name = _infer_repo_full_name(repo_root)
    branch = _run_git(["git", "rev-parse", "--abbrev-ref", "HEAD"], cwd=repo_root) or "unknown"
    head_sha = _run_git(["git", "rev-parse", "HEAD"], cwd=repo_root)
    file_paths = _infer_changed_files(repo_root)
    commit_lineage = _infer_lineage_from_commit_metadata(
        repo_root=repo_root,
        head_sha=head_sha,
        commit_msg_file=commit_msg_file,
    )
    persisted_hints = _read_session_hints(repo_root)
    cursor_hints = _read_cursor_context_hints(repo_root)

    tool = _first_env(["SENSE_CLI_LINEAGE_TOOL", "CURSOR_AGENT", "CLAUDE_CODE", "GEMINI_CLI"]) or "unknown"
    provider = _first_env(
        [
            "SENSE_CLI_LINEAGE_PROVIDER",
            "SENSELAB_LLM_PROVIDER",
            "CURSOR_MODEL_PROVIDER",
            "CLAUDE_PROVIDER",
            "GEMINI_PROVIDER",
        ]
    )
    model = _first_env(
        [
            "SENSE_CLI_LINEAGE_MODEL",
            "SENSELAB_LLM_MODEL",
            "CURSOR_MODEL",
            "CURSOR_MODEL_NAME",
            "CLAUDE_MODEL",
            "GEMINI_MODEL",
            "OPENAI_MODEL",
        ]
    )
    session_id = _first_env(
        [
            "SENSE_CLI_LINEAGE_SESSION_ID",
            "CURSOR_SESSION_ID",
            "CLAUDE_SESSION_ID",
            "GEMINI_SESSION_ID",
        ]
    )
    if (tool == "unknown" or not tool) and cursor_hints.get("tool"):
        tool = str(cursor_hints.get("tool"))
    if not provider and cursor_hints.get("provider"):
        provider = str(cursor_hints.get("provider"))
    if not model and cursor_hints.get("model"):
        model = str(cursor_hints.get("model"))
    if not session_id and cursor_hints.get("session_id"):
        session_id = str(cursor_hints.get("session_id"))

    if (tool == "unknown" or not tool) and commit_lineage.get("tool"):
        tool = str(commit_lineage.get("tool"))
    if not provider and commit_lineage.get("provider"):
        provider = str(commit_lineage.get("provider"))
    if not model and commit_lineage.get("model"):
        model = str(commit_lineage.get("model"))
    if not session_id and commit_lineage.get("session_id"):
        session_id = str(commit_lineage.get("session_id"))
    if (tool == "unknown" or not tool) and persisted_hints.get("tool"):
        tool = str(persisted_hints.get("tool"))
    if not provider and persisted_hints.get("provider"):
        provider = str(persisted_hints.get("provider"))
    if not model and persisted_hints.get("model"):
        model = str(persisted_hints.get("model"))
    if not session_id and persisted_hints.get("session_id"):
        session_id = str(persisted_hints.get("session_id"))
    if (tool == "unknown" or not tool) and (repo_root / ".cursor").exists():
        tool = "cursor"

    if not session_id:
        session_id = _stable_session_id(repo_full_name=repo_full_name, branch=branch)

    event = {
        "event_at": datetime.now(UTC).isoformat(),
        "hook": hook_name,
        "repository_full_name": repo_full_name,
        "branch": branch,
        "head_sha": head_sha,
        "tool": tool,
        "provider": provider,
        "model": model,
        "session_id": session_id,
        "file_paths": file_paths,
        "metadata": {
            "captured_by": hook_name,
            "commit_trailers": commit_lineage.get("trailers") or {},
            "hint_sources": {
                "cursor_context": bool(cursor_hints),
                "commit_trailers": bool(commit_lineage),
                "persisted_hints": bool(persisted_hints),
            },
        },
    }
    _append_local_event(repo_root, event)
    _write_session_hints(
        repo_root,
        {
            "tool": tool,
            "provider": provider,
            "model": model,
            "session_id": session_id,
            "updated_at": datetime.now(UTC).isoformat(),
            "source_hook": hook_name,
        },
    )
    _update_local_session_ledger(repo_root=repo_root, event=event)
    _write_local_checkpoint(repo_root=repo_root, event=event)
    return event


def pending_events_count(repo_root: Path) -> int:
    return len(_read_events(repo_root))


def sync_events(
    *,
    config: CLIConfig,
    api: APIClient,
    repo_root: Path,
    project_guid: str | None,
    batch_size: int = 100,
) -> tuple[int, int]:
    events = _read_events(repo_root)
    sessions = _read_local_sessions(repo_root)
    checkpoints = _read_local_checkpoints(repo_root)
    if not events:
        if sessions:
            api.ingest_cli_lineage_sessions(sessions=sessions, project_guid=project_guid)
        if checkpoints:
            api.ingest_cli_lineage_checkpoints(checkpoints=checkpoints, project_guid=project_guid)
        return 0, 0

    sent = 0
    remaining = list(events)
    while remaining:
        batch = remaining[:batch_size]
        api.ingest_cli_lineage_events(events=batch, project_guid=project_guid)
        sent += len(batch)
        remaining = remaining[batch_size:]

    if sessions:
        api.ingest_cli_lineage_sessions(sessions=sessions, project_guid=project_guid)
    if checkpoints:
        api.ingest_cli_lineage_checkpoints(checkpoints=checkpoints, project_guid=project_guid)

    _write_events(repo_root, [])
    return sent, len(remaining)


def _append_local_event(repo_root: Path, event: dict[str, Any]) -> None:
    target = lineage_events_path(repo_root)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(event, ensure_ascii=True))
        handle.write("\n")


def _read_events(repo_root: Path) -> list[dict[str, Any]]:
    path = lineage_events_path(repo_root)
    if not path.exists():
        return []
    events: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        raw = line.strip()
        if not raw:
            continue
        try:
            parsed = json.loads(raw)
            if isinstance(parsed, dict):
                events.append(parsed)
        except json.JSONDecodeError:
            continue
    return events


def _write_events(repo_root: Path, events: list[dict[str, Any]]) -> None:
    path = lineage_events_path(repo_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = "\n".join(json.dumps(item, ensure_ascii=True) for item in events)
    if payload:
        payload += "\n"
    path.write_text(payload, encoding="utf-8")


def _read_session_hints(repo_root: Path) -> dict[str, Any]:
    path = lineage_session_hints_path(repo_root)
    if not path.exists():
        return {}
    try:
        parsed = json.loads(path.read_text(encoding="utf-8", errors="ignore") or "{}")
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _write_session_hints(repo_root: Path, hints: dict[str, Any]) -> None:
    path = lineage_session_hints_path(repo_root)
    existing = _read_session_hints(repo_root)
    merged = {
        **existing,
        **{key: value for key, value in hints.items() if value not in (None, "", "unknown")},
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(merged, ensure_ascii=True, sort_keys=True), encoding="utf-8")


def _update_local_session_ledger(*, repo_root: Path, event: dict[str, Any]) -> None:
    session_id = str(event.get("session_id") or "").strip()
    repository_full_name = str(event.get("repository_full_name") or "").strip()
    if not session_id or not repository_full_name:
        return
    current_path = lineage_current_session_path(repo_root)
    session_path = lineage_session_file_path(repo_root, session_id)
    current = _read_json_file(current_path)
    now_iso = datetime.now(UTC).isoformat()
    payload = {
        "session_id": session_id,
        "repository_full_name": repository_full_name,
        "branch": event.get("branch"),
        "base_sha": current.get("base_sha"),
        "head_sha": event.get("head_sha"),
        "tool": event.get("tool"),
        "provider": event.get("provider"),
        "model": event.get("model"),
        "started_at": current.get("started_at") or now_iso,
        "ended_at": now_iso,
        "event_at": event.get("event_at"),
        "metadata": {
            "latest_hook": event.get("hook"),
            "changed_files_count": len(event.get("file_paths") or []),
        },
    }
    _write_json_file(current_path, payload)
    _write_json_file(session_path, payload)


def _write_local_checkpoint(*, repo_root: Path, event: dict[str, Any]) -> None:
    commit_sha = str(event.get("head_sha") or "").strip()
    if not commit_sha:
        return
    checkpoint_payload = {
        "event_at": event.get("event_at"),
        "repository_full_name": event.get("repository_full_name"),
        "branch": event.get("branch"),
        "session_id": event.get("session_id"),
        "commit_sha": commit_sha,
        "tool": event.get("tool"),
        "provider": event.get("provider"),
        "model": event.get("model"),
        "file_paths": event.get("file_paths") or [],
        "metadata": event.get("metadata") if isinstance(event.get("metadata"), dict) else {},
    }
    _write_json_file(
        lineage_checkpoint_file_path(repo_root, checkpoint_id=commit_sha),
        checkpoint_payload,
    )


def _read_local_sessions(repo_root: Path) -> list[dict[str, Any]]:
    root = repo_root / LINEAGE_SESSIONS_DIR
    if not root.exists():
        return []
    rows: list[dict[str, Any]] = []
    for path in root.glob("*.json"):
        if path.name == LINEAGE_CURRENT_SESSION_FILE:
            continue
        parsed = _read_json_file(path)
        if isinstance(parsed, dict) and parsed.get("repository_full_name") and parsed.get("session_id"):
            rows.append(parsed)
    return rows[:200]


def _read_local_checkpoints(repo_root: Path) -> list[dict[str, Any]]:
    root = repo_root / LINEAGE_CHECKPOINTS_DIR
    if not root.exists():
        return []
    rows: list[dict[str, Any]] = []
    for path in root.glob("*.json"):
        parsed = _read_json_file(path)
        if isinstance(parsed, dict) and parsed.get("repository_full_name") and parsed.get("commit_sha"):
            rows.append(parsed)
    return rows[:500]


def _read_json_file(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    try:
        parsed = json.loads(path.read_text(encoding="utf-8", errors="ignore") or "{}")
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _write_json_file(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=True, sort_keys=True), encoding="utf-8")


def _safe_identifier(value: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "_", str(value or "").strip())
    return cleaned[:128] or "unknown"


def _stable_session_id(*, repo_full_name: str | None, branch: str | None) -> str:
    seed = f"{repo_full_name or 'repo'}:{branch or 'branch'}"
    return _safe_identifier(seed)


def _replace_marker_block(content: str, block: str) -> str:
    pattern = re.compile(
        rf"{re.escape(LINEAGE_MARKER_START)}.*?{re.escape(LINEAGE_MARKER_END)}\n?",
        flags=re.DOTALL,
    )
    if pattern.search(content):
        return pattern.sub(block, content)

    updated = content
    if updated and not updated.endswith("\n"):
        updated += "\n"
    if updated and not updated.endswith("\n\n"):
        updated += "\n"
    return updated + block


def _remove_marker_block(content: str) -> tuple[str, bool]:
    pattern = re.compile(
        rf"\n?{re.escape(LINEAGE_MARKER_START)}.*?{re.escape(LINEAGE_MARKER_END)}\n?",
        flags=re.DOTALL,
    )
    updated, count = pattern.subn("\n", content)
    updated = re.sub(r"\n{3,}", "\n\n", updated)
    return updated, count > 0


def _ensure_executable(path: Path) -> None:
    current = path.stat().st_mode
    path.chmod(current | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)


def _run_git(command: list[str], cwd: Path | None = None) -> str | None:
    try:
        result = subprocess.run(
            command,
            cwd=str(cwd) if cwd else None,
            check=False,
            capture_output=True,
            text=True,
        )
    except Exception:
        return None
    if result.returncode != 0:
        return None
    return result.stdout.strip() or None


def _first_env(names: list[str]) -> str | None:
    for name in names:
        value = os.getenv(name)
        if value and value.strip():
            return value.strip()
    return None


def _infer_changed_files(repo_root: Path) -> list[str]:
    # Pre-push can include both staged and committed deltas; keep this lightweight.
    staged = _run_git(["git", "diff", "--name-only", "--cached"], cwd=repo_root) or ""
    unstaged = _run_git(["git", "diff", "--name-only"], cwd=repo_root) or ""
    names = set()
    for blob in (staged, unstaged):
        for line in blob.splitlines():
            candidate = line.strip()
            if candidate:
                names.add(candidate)
    return sorted(names)[:500]


def _infer_repo_full_name(repo_root: Path) -> str | None:
    remote = _run_git(["git", "config", "--get", "remote.origin.url"], cwd=repo_root)
    if not remote:
        return None
    remote = remote.strip()

    ssh_match = re.search(r"[:/]([^/:\s]+)/([^/\s]+?)(?:\.git)?$", remote)
    if ssh_match:
        return f"{ssh_match.group(1)}/{ssh_match.group(2)}"
    return None


def _read_cursor_context_hints(repo_root: Path) -> dict[str, Any]:
    cursor_dir = repo_root / ".cursor"
    if not cursor_dir.exists():
        return {}
    candidates = (
        cursor_dir / "session.json",
        cursor_dir / "agent-session.json",
        cursor_dir / "agent-state.json",
        cursor_dir / "metadata.json",
    )
    merged: dict[str, Any] = {}
    for candidate in candidates:
        if not candidate.exists() or not candidate.is_file():
            continue
        try:
            parsed = json.loads(candidate.read_text(encoding="utf-8", errors="ignore") or "{}")
        except json.JSONDecodeError:
            continue
        hints = _extract_lineage_hints_from_payload(parsed)
        for key in ("tool", "provider", "model", "session_id"):
            if not merged.get(key) and hints.get(key):
                merged[key] = hints[key]
    return merged


def _extract_lineage_hints_from_payload(payload: Any) -> dict[str, str]:
    hints: dict[str, str] = {}

    def _walk(value: Any, key_path: str = "") -> None:
        if isinstance(value, dict):
            for raw_key, raw_val in value.items():
                key = str(raw_key).strip()
                lowered = key.lower()
                path = f"{key_path}.{lowered}" if key_path else lowered
                if isinstance(raw_val, str) and raw_val.strip():
                    val = raw_val.strip()
                    if lowered in {"tool", "agent", "client"} and not hints.get("tool"):
                        hints["tool"] = val
                    elif lowered in {"provider", "model_provider", "modelprovider"} and not hints.get("provider"):
                        hints["provider"] = val
                    elif lowered in {"model", "model_name", "modelname", "activemodel", "currentmodel"} and not hints.get("model"):
                        hints["model"] = val
                    elif (
                        lowered in {"session_id", "sessionid", "conversation_id", "conversationid", "checkpoint_id"}
                        or "session" in path
                    ) and not hints.get("session_id"):
                        hints["session_id"] = val
                if isinstance(raw_val, (dict, list)):
                    _walk(raw_val, path)
        elif isinstance(value, list):
            for item in value:
                if isinstance(item, (dict, list)):
                    _walk(item, key_path)

    _walk(payload)
    if not hints.get("tool"):
        hints["tool"] = "cursor"
    return hints


def _infer_lineage_from_commit_metadata(
    *,
    repo_root: Path,
    head_sha: str | None,
    commit_msg_file: str | None,
) -> dict[str, Any]:
    message = _read_commit_message(
        repo_root=repo_root,
        head_sha=head_sha,
        commit_msg_file=commit_msg_file,
    )
    if not message:
        return {}
    trailers = _extract_commit_trailers(message)
    if not trailers:
        return {}
    return {
        "tool": trailers.get("ai_tool"),
        "provider": trailers.get("ai_provider"),
        "model": trailers.get("ai_model"),
        "session_id": trailers.get("ai_session_id"),
        "trailers": trailers,
    }


def _read_commit_message(
    *,
    repo_root: Path,
    head_sha: str | None,
    commit_msg_file: str | None,
) -> str | None:
    if commit_msg_file:
        candidate = Path(commit_msg_file)
        if not candidate.is_absolute():
            candidate = repo_root / candidate
        try:
            if candidate.exists():
                return candidate.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            return None
    commit_ref = head_sha or "HEAD"
    return _run_git(["git", "log", "-1", "--format=%B", commit_ref], cwd=repo_root)


def _extract_commit_trailers(message: str) -> dict[str, str]:
    if not message:
        return {}
    trailers: dict[str, str] = {}
    for raw_line in message.splitlines():
        line = raw_line.strip()
        if not line or ":" not in line:
            continue
        match = re.match(r"^([A-Za-z0-9][A-Za-z0-9 _-]{0,80}):\s*(.+)$", line)
        if not match:
            continue
        key = match.group(1).strip().lower().replace("_", "-").replace(" ", "-")
        value = match.group(2).strip()
        if not value:
            continue
        if key in {"ai-model", "x-ai-model", "llm-model", "model"}:
            trailers["ai_model"] = value
        elif key in {"ai-provider", "x-ai-provider", "llm-provider", "provider"}:
            trailers["ai_provider"] = value
        elif key in {"ai-tool", "x-ai-tool", "tool", "generated-by"}:
            trailers["ai_tool"] = value
        elif key in {"ai-session-id", "x-ai-session-id", "session-id", "ai-session"}:
            trailers["ai_session_id"] = value
    return trailers


def _shell_quote(value: str) -> str:
    return "'" + value.replace("'", "'\"'\"'") + "'"
