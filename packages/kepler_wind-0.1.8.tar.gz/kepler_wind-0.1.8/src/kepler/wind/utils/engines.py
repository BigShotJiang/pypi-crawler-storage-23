"""
数据引擎

此模块已重构以使用新的配置管理系统，同时保持向后兼容性。
建议新代码直接从 kepler.wind.utils.config_manager 导入所需的组件。
"""

import os

from kepler.wind.utils.config_manager import (
    BUNDLE_DIR,
    ENGINE,
    WIND_DB,
    ConfigManager,
    DatabaseManager,
    BundleManager,
)

# 保持向后兼容性的重新导出
__all__ = ['WIND_DB', 'ENGINE', 'BUNDLE_DIR', 'ConfigManager', 'DatabaseManager', 'BundleManager']

# 为了向后兼容，保留对旧版配置系统的支持
try:
    import yaml
    from kepler.atlas import DataBase
    from sqlalchemy import create_engine

    # 旧的配置系统逻辑（仅用于向后兼容）
    CONFIG_FILE_NAME = "wind.yaml"
    HOME_PATH = os.path.expanduser(f"~{os.sep}.sangreal{os.sep}wind")
    if not os.path.exists(HOME_PATH):
        os.makedirs(HOME_PATH)
    CONFIG_FILE = os.path.join(HOME_PATH, CONFIG_FILE_NAME)

    YAML_TYPE = f"""
    wind.config:
        engine: engine url
        schema: blank or other

    bundle.config:
        dir: blank or other
    """

    def get_db(config, k):
        """向后兼容的数据库连接函数"""
        if config is not None:
            db_config = config.get(k, None)
            if db_config is None:
                raise ValueError(
                    f"Please check the {CONFIG_FILE} and add {k}!\
        The yaml' type is like {YAML_TYPE}"
                )
            engine = create_engine(db_config["engine"])
            schema = db_config["schema"]
            return DataBase(engine, schema), engine
        else:
            return DataBase(None), None

    def get_bundle(config, k):
        """向后兼容的bundle目录获取函数"""
        if config is not None:
            bundle_config = config.get(k, None)
            if bundle_config is not None:
                bundle_dir = bundle_config["dir"]
                if bundle_dir is None:
                    bundle_dir = f"{os.path.expanduser(f'~{os.sep}.sangreal{os.sep}backtest{os.sep}bundle{os.sep}')}"
                return bundle_dir
            else:
                bundle_dir = f"{os.path.expanduser(f'~{os.sep}.sangreal{os.sep}backtest{os.sep}bundle{os.sep}')}"
                return bundle_dir
        else:
            return

    # 保持旧的配置加载逻辑，但实际使用新的配置管理器
    if not os.path.isfile(CONFIG_FILE):
        config = None
    else:
        with open(CONFIG_FILE, "r") as f:
            config = yaml.load(f, Loader=yaml.FullLoader)

    # 如果新配置管理器可用且配置了数据库，使用新系统
    if ENGINE is not None:
        # 使用新的配置管理系统
        pass
    else:
        # 回退到旧系统（保持向后兼容性）
        if config is not None:
            _WIND_DB, _ENGINE = get_db(config, "wind.config")
            _BUNDLE_DIR = get_bundle(config, "bundle.config")

            if _ENGINE is not None:
                # 替换为旧系统的配置
                WIND_DB = _WIND_DB
                ENGINE = _ENGINE
                BUNDLE_DIR = _BUNDLE_DIR

    if BUNDLE_DIR is not None:
        if not BUNDLE_DIR.endswith(os.sep):
            raise ValueError(f"bundle_dir的路径必须以{os.sep}结尾")
        if not os.path.exists(BUNDLE_DIR):
            os.makedirs(BUNDLE_DIR)

except ImportError:
    # 如果依赖库不可用，使用新系统
    pass
