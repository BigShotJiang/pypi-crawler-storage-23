from collections.abc import Iterable

from kepler.wind.utils.fund_base import _fund_nav_api


def get_fund_nav(fund_list=None, begin_dt="20010101", end_dt="20990101"):
    """[获取基金净值]

    Keyword Arguments:
        fund_list {[str or iterable or None]} -- [list of funds or fund] (default: {None})
        begin_dt {str} -- [description] (default: {'20010101'})
        end_dt {str} -- [description] (default: {'20990101'})

    Returns:
        [pd.DataFrame] -- [f_sid|trade_dt|s_close]
    """
    # 🎯 使用统一的API实例，消除try/except重复模式
    return _fund_nav_api.get_fund_data(fund_list, begin_dt, end_dt)


if __name__ == "__main__":
    print(get_fund_nav("163407.OF"))
    # print(get_fund_nav(['000001.OF', '000002.OF']))
    # print(get_fund_nav(begin_dt='20190114'))
