# Changelog

## 0.1.0 (2026-02-28)


### Features

* PhenoRadar baseline ([0081f23](https://github.com/mkrg01/phenoradar/commit/0081f2384339810ec449288c5532dad5ad104338))


### Documentation

* update Python badge for supported versions ([c9f9417](https://github.com/mkrg01/phenoradar/commit/c9f9417516f4b840d029460828f000ea6977ccf8))
