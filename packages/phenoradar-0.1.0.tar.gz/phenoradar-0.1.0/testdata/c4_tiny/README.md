# c4_tiny

Compact test dataset for PhenoRadar.

## Files

- `species_metadata.tsv`: 20 species rows (train/validation, external_test, discovery_inference)
- `tpm.tsv`: 1,515 long-format expression rows

## Origin

This dataset is a compact subset derived from `c4_dataset/` for smoke testing and documentation examples.

## SHA-256

- `species_metadata.tsv`: `c0c4732607da374e70f7ec8c7906aceb902c90aff3111fd03559852df1ab9327`
- `tpm.tsv`: `ff782ac12288e5f7240c7d4ccf3a029ca6d867c8cd1ec9d0d1429d25bb110602`
