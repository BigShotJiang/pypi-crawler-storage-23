import os
import shutil

from django.conf import settings
from django.contrib.auth.models import User
from django.core.files.base import ContentFile
from django.test import Client, TestCase
from django.utils.translation import deactivate_all
from PIL import Image

from testapp.models import HTML, Article, Download


def zero_management_form_data(prefix):
    return {
        f"{prefix}-TOTAL_FORMS": 0,
        f"{prefix}-INITIAL_FORMS": 0,
        f"{prefix}-MIN_NUM_FORMS": 0,
        f"{prefix}-MAX_NUM_FORMS": 1000,
    }


def merge_dicts(*dicts):
    res = {}
    for d in dicts:
        res.update(d)
    return res


def openimage(path):
    return open(os.path.join(settings.MEDIA_ROOT, path), "rb")


class Test(TestCase):
    def setUp(self):
        self.user = User.objects.create_superuser("admin", "admin@test.ch", "blabla")
        deactivate_all()
        path = os.path.join(settings.MEDIA_ROOT, "download")
        if os.path.exists(path):
            shutil.rmtree(path)

    def login(self):
        client = Client()
        client.force_login(self.user)
        return client

    def test_modules(self):
        """Admin modules are present, necessary JS too"""

        client = self.login()

        response = client.get("/admin/")
        self.assertContains(
            response, '<a href="/admin/testapp/article/">Articles</a>', 1
        )

    def test_simple(self):
        article = Article.objects.create()
        HTML.objects.create(
            parent=article, ordering=1, region="main", html="<b>Hello</b>"
        )
        download = Download(parent=article, ordering=2, region="main")
        download.file.save("world.txt", ContentFile("World"))

        response = self.client.get(f"/{article.pk}/")
        self.assertContains(response, "<b>Hello</b>")
        self.assertContains(response, 'class="download button"')

        self.assertEqual(download.file_size, 5)
        self.assertTrue(download.show_preview)
        self.assertFalse(download.preview)

        self.assertEqual(download.basename, "world.txt")
        self.assertEqual(download.caption_or_basename, "world.txt")

        download.caption = "Hello World"
        self.assertEqual(download.basename, "world.txt")
        self.assertEqual(download.caption_or_basename, "Hello World")

    def test_preview(self):
        client = self.login()
        with openimage("smallliz.tif") as f:
            response = client.post(
                "/admin/testapp/article/add/",
                merge_dicts(
                    zero_management_form_data("testapp_html_set"),
                    zero_management_form_data("testapp_download_set"),
                    {
                        "testapp_download_set-TOTAL_FORMS": 1,
                        "testapp_download_set-0-file": f,
                        "testapp_download_set-0-region": "main",
                        "testapp_download_set-0-ordering": "10",
                        "testapp_download_set-0-show_preview": "1",
                    },
                ),
            )

        self.assertRedirects(response, "/admin/testapp/article/")

        download = Download.objects.get()
        self.assertEqual(download.file_size, 5052)
        self.assertTrue(download.preview.name.endswith(".jpg"))

        image = Image.open(download.preview)
        self.assertEqual(image.size, (160, 160))

    def test_large_image(self):
        client = self.login()
        with openimage("yes.pdf") as f:
            response = client.post(
                "/admin/testapp/article/add/",
                merge_dicts(
                    zero_management_form_data("testapp_html_set"),
                    zero_management_form_data("testapp_download_set"),
                    {
                        "testapp_download_set-TOTAL_FORMS": 1,
                        "testapp_download_set-0-file": f,
                        "testapp_download_set-0-region": "main",
                        "testapp_download_set-0-ordering": "10",
                        "testapp_download_set-0-show_preview": "1",
                    },
                ),
            )

        self.assertRedirects(response, "/admin/testapp/article/")

        download = Download.objects.get()
        self.assertEqual(download.file_size, 15325)
        self.assertTrue(download.preview.name.endswith(".jpg"))

        image = Image.open(download.preview)
        self.assertTrue(image.size[0] <= 310)
