==================
feincms3-downloads
==================

.. image:: https://github.com/matthiask/feincms3-downloads/actions/workflows/tests.yml/badge.svg
    :target: https://github.com/matthiask/feincms3-downloads/
    :alt: CI Status

Requires local imagemagick and poppler-utils installations.
