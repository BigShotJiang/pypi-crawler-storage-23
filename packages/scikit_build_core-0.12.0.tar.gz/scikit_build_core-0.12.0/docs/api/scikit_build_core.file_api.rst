scikit\_build\_core.file\_api package
=====================================

.. automodule:: scikit_build_core.file_api
   :members:
   :show-inheritance:
   :undoc-members:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   scikit_build_core.file_api.model

Submodules
----------

scikit\_build\_core.file\_api.query module
------------------------------------------

.. automodule:: scikit_build_core.file_api.query
   :members:
   :show-inheritance:
   :undoc-members:

scikit\_build\_core.file\_api.reply module
------------------------------------------

.. automodule:: scikit_build_core.file_api.reply
   :members:
   :show-inheritance:
   :undoc-members:
