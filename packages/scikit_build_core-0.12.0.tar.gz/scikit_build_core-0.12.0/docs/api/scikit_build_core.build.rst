scikit\_build\_core.build package
=================================

.. automodule:: scikit_build_core.build
   :members:
   :show-inheritance:
   :undoc-members:

Submodules
----------

scikit\_build\_core.build.generate module
-----------------------------------------

.. automodule:: scikit_build_core.build.generate
   :members:
   :show-inheritance:
   :undoc-members:

scikit\_build\_core.build.metadata module
-----------------------------------------

.. automodule:: scikit_build_core.build.metadata
   :members:
   :show-inheritance:
   :undoc-members:

scikit\_build\_core.build.sdist module
--------------------------------------

.. automodule:: scikit_build_core.build.sdist
   :members:
   :show-inheritance:
   :undoc-members:

scikit\_build\_core.build.wheel module
--------------------------------------

.. automodule:: scikit_build_core.build.wheel
   :members:
   :show-inheritance:
   :undoc-members:
