scikit\_build\_core.builder package
===================================

.. automodule:: scikit_build_core.builder
   :members:
   :show-inheritance:
   :undoc-members:

Submodules
----------

scikit\_build\_core.builder.builder module
------------------------------------------

.. automodule:: scikit_build_core.builder.builder
   :members:
   :show-inheritance:
   :undoc-members:

scikit\_build\_core.builder.generator module
--------------------------------------------

.. automodule:: scikit_build_core.builder.generator
   :members:
   :show-inheritance:
   :undoc-members:

scikit\_build\_core.builder.get\_requires module
------------------------------------------------

.. automodule:: scikit_build_core.builder.get_requires
   :members:
   :show-inheritance:
   :undoc-members:

scikit\_build\_core.builder.macos module
----------------------------------------

.. automodule:: scikit_build_core.builder.macos
   :members:
   :show-inheritance:
   :undoc-members:

scikit\_build\_core.builder.sysconfig module
--------------------------------------------

.. automodule:: scikit_build_core.builder.sysconfig
   :members:
   :show-inheritance:
   :undoc-members:

scikit\_build\_core.builder.wheel\_tag module
---------------------------------------------

.. automodule:: scikit_build_core.builder.wheel_tag
   :members:
   :show-inheritance:
   :undoc-members:
