scikit\_build\_core.resources package
=====================================

.. automodule:: scikit_build_core.resources
   :members:
   :show-inheritance:
   :undoc-members:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   scikit_build_core.resources.find_python
