def nested1_generated_check():
    # noinspection PyUnresolvedReferences
    from ..nested1.generated import nested_data  # type: ignore[import-not-found]

    return nested_data
