#include "pkg_export.h"

extern "C" PKG_EXPORT int func() {return 42;}
