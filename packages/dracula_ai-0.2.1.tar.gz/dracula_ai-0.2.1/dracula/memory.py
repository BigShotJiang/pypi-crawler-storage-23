import json
import os
from .exceptions import ChatException


class Memory:
    def __init__(self, max_messages: int = 10):
        self.history = []
        self.max_messages = max_messages

    def add_message(self, role: str, content: str):
        self.history.append({"role": role, "content": content})

        if len(self.history) > self.max_messages:
            self.history.pop(0)

    def get_history(self):
        return self.history

    def clear(self):
        self.history = []

    def save(self, filepath: str):
        try:
            with open(filepath, "w", encoding="utf-8") as f:
                json.dump(self.history, f, indent=4, ensure_ascii=False)

        except Exception as e:
            raise ChatException(f"Failed to save conversation: {str(e)}")

    def load(self, filepath: str):
        try:
            if not os.path.exists(filepath):
                raise ChatException(f"File not found: {filepath}")

            with open(filepath, "r", encoding="utf-8") as f:
                self.history = json.load(f)

        except ChatException:
            raise
        except Exception as e:
            raise ChatException(f"Failed to load conversation: {str(e)}")
