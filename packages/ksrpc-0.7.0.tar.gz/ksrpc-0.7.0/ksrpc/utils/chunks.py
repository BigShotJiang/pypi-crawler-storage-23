# 发送端分块
import sys
import zlib
from datetime import datetime
from io import BytesIO

from ksrpc.utils.misc import format_number
from ksrpc.utils.tqdm import update_progress

# TODO 需要防止zlib压缩后数据出现与边界同样字符串，如果修改，客服端和服务端需要保持一致
CHUNK_BORDER: str = "\r\r\r ChUnKeD \n\n\n"
CHUNK_BORDER_BYTES = CHUNK_BORDER.encode("utf-8")
CHUNK_SIZE: int = 1024 * 128  # 128KB

ZLIB_COMPRESS_LEVEL: int = 6


async def data_sender(data, print, chunk_size=CHUNK_SIZE):
    file = sys.stderr
    print(f'{datetime.now()} 加载数据: ({format_number(len(data))}B) [', end='', file=file)
    data = BytesIO(data)
    chunk = data.read(chunk_size)
    i = -1
    size = 0
    while chunk:
        buf = zlib.compress(chunk, ZLIB_COMPRESS_LEVEL) + CHUNK_BORDER_BYTES
        size += len(buf)
        yield buf
        i += 1
        update_progress(i, print, file=file)
        chunk = data.read(chunk_size)
    # 会快速的显示到此处，但实际数据还在发送中，建议与客户端接收进度一起看
    print(f'] 压缩完成 ({format_number(size)}B) | 底层异步发送中，请勿立即退出！', file=file)


async def send_in_chunks(ws, data, print, chunk_size=CHUNK_SIZE):
    # 64KB时，某宽发出的大数据无法zlib解压，所以改成了32KB
    # 将数据分块发送
    file = sys.stderr
    print(f'{datetime.now()} 发送数据: ({format_number(len(data))}B) [', end='', file=file)

    j = -1
    size = 0
    for i in range(0, len(data), chunk_size):
        chunk = data[i:i + chunk_size]
        buf = zlib.compress(chunk, ZLIB_COMPRESS_LEVEL)
        size += len(buf)
        await ws.send_bytes(buf)
        await ws.send_str(CHUNK_BORDER)
        j += 1
        update_progress(j, print, file=file)
    # 会快速的显示到此处，但实际数据还在发送中，建议与客户端接收进度一起看
    print(f'] 压缩完成 ({format_number(size)}B) | 底层异步发送中，请勿立即退出！', file=file)

    # 发送结束标志
    await ws.send_str("EOF")
