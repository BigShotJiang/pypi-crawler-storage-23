from uuid import UUID

from sqlalchemy import BigInteger, ForeignKey, Identity, Text
from sqlalchemy.dialects.postgresql import BYTEA
from sqlalchemy.orm import Mapped, mapped_column
from xplan_tools.model.orm import Base, Feature


class Document(Base):
    __tablename__ = "docs"
    __table_args__ = {"schema": Feature.__table_args__.get("schema")}
    pk: Mapped[int] = mapped_column(
        BigInteger,
        Identity(always=True),
        primary_key=True,
    )
    id: Mapped[UUID] = mapped_column(
        ForeignKey(
            Feature.id, ondelete="CASCADE", deferrable=True, initially="DEFERRED"
        ),
        index=True,
    )
    filename: Mapped[str] = mapped_column(Text, index=True, unique=True)
    filetype: Mapped[str] = mapped_column(Text)
    filedata: Mapped[bytes] = mapped_column(BYTEA)
