"""
Copyright 2025 Google LLC

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

     https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

import datetime
import os
import random
import string
import tarfile

from docker.utils import build
from .system_characteristics import DockerPlatform
from ..utils.console import xpk_exit, xpk_print
from ..utils.feature_flags import FeatureFlags
from ..utils.file import write_tmp_file
from ..utils.execution_context import is_dry_run
from .commands import run_command_with_updates

DEFAULT_DOCKER_IMAGE = 'python:3.10'
DEFAULT_SCRIPT_DIR = os.getcwd()


def validate_docker_image(docker_image, args) -> int:
  """Validates that the user provided docker image exists in your project.

  Args:
    docker_image: The docker image to verify.
    args: user provided arguments for running the command.

  Returns:
    0 if successful and 1 otherwise.
  """

  project = args.project

  if not any(repo in docker_image for repo in ['gcr.io', 'docker.pkg.dev']):
    return 0

  command = (
      f'gcloud container images describe {docker_image} --project {project}'
  )
  return_code = run_command_with_updates(
      command, 'Validate Docker Image', verbose=False
  )
  if return_code != 0:
    xpk_print(
        'Failed to validate your docker image, check that the docker image'
        f' exists. You may be able to find the {docker_image} in {project}.'
        ' If the docker image exists, the service account of this'
        ' project maybe be missing the permissions to access the docker image.'
    )
    return return_code
  else:
    return 0


def build_docker_image_from_base_image(
    args, docker_platform: DockerPlatform, verbose=True
) -> tuple[int, str]:
  """Adds script dir to the base docker image and uploads the image.

  Args:
    args: user provided arguments for running the command.

  Returns:
    Tuple of:
      0 if successful and 1 otherwise.
      Name of the Docker image created.
  """

  # Pick a name for the docker image.
  docker_image_prefix = (
      'dry-run' if is_dry_run() else os.getenv('USER', 'unknown')
  )
  docker_name = f'{docker_image_prefix}-runner'

  # Pick a randomly generated `tag_length` character docker tag.
  tag_length = 4
  tag_random_prefix = (
      'prefix'
      if is_dry_run()
      else ''.join(random.choices(string.ascii_lowercase, k=tag_length))
  )
  tag_datetime = (
      'current'
      if is_dry_run()
      else datetime.datetime.now().strftime('%Y-%m-%d-%H-%M-%S')
  )
  tag_name = f'{tag_random_prefix}-{tag_datetime}'
  cloud_docker_image = f'gcr.io/{args.project}/{docker_name}:{tag_name}'
  return (
      _build_image_with_crane(
          args,
          docker_platform,
          cloud_docker_image,
          verbose=verbose,
      )
      if FeatureFlags.CRANE_WORKLOADS_ENABLED
      else _build_image_with_docker(
          args,
          docker_platform,
          docker_name,
          cloud_docker_image,
          verbose=verbose,
      )
  )


def _build_image_archive(script_dir: str) -> str:
  image_archive_path = write_tmp_file(payload='')
  xpk_print(
      f'Adding {script_dir} to container image archive {image_archive_path}'
  )
  if is_dry_run():
    return image_archive_path

  ignore_patterns = []
  ignore_path = os.path.join(script_dir, '.dockerignore')
  if os.path.exists(ignore_path):
    with open(ignore_path, 'r', encoding='utf=8') as ignore_file:
      ignore_patterns = [
          line.strip()
          for line in ignore_file
          if not line.isspace() and not line.startswith('#')
      ]

  paths_to_add = build.exclude_paths(script_dir, ignore_patterns)

  with tarfile.open(image_archive_path, 'w') as tar:
    for path in sorted(paths_to_add):
      full_path = os.path.join(script_dir, path)
      archive_name = os.path.join('app', path)
      info = tar.gettarinfo(full_path, arcname=archive_name)
      info.uid = info.gid = 0
      info.uname = info.gname = 'root'

      if os.path.isfile(full_path):
        with open(full_path, 'rb') as f:
          tar.addfile(info, f)
      else:
        # Directories and special files (symlinks, etc.)
        tar.addfile(info, None)
    return image_archive_path


def _build_image_with_crane(
    args,
    platform: DockerPlatform,
    container_image: str,
    verbose=True,
) -> tuple[int, str]:

  image_archive_path = _build_image_archive(args.script_dir)

  crane_command = (
      f'crane mutate {args.base_docker_image} --append {image_archive_path}'
      f' --platform {platform.value} --tag {container_image}'
      ' --workdir /app'
  )

  return_code = run_command_with_updates(
      crane_command, 'Upload Container Image', verbose=verbose
  )

  xpk_print(f'Deleting container image archive {image_archive_path}')
  if not is_dry_run():
    os.remove(image_archive_path)

  if return_code != 0:
    xpk_print('Failed to upload container image.')
    xpk_exit(1)
  return return_code, container_image


def _build_image_with_docker(
    args,
    docker_platform: DockerPlatform,
    docker_name: str,
    cloud_docker_image: str,
    verbose=True,
) -> tuple[int, str]:
  script_dir_dockerfile = """FROM {base_docker_image}

  # Set the working directory in the container
  WORKDIR /app

  # Copy all files from local workspace into docker container
  COPY . .

  WORKDIR /app
  """

  docker_file = script_dir_dockerfile.format(
      base_docker_image=args.base_docker_image,
  )
  tmp = write_tmp_file(docker_file)
  docker_build_command = (
      f'docker buildx build --platform={docker_platform.value} -f'
      f' {str(tmp)} -t {docker_name} {args.script_dir}'
  )
  xpk_print(f'Building {args.script_dir} into docker image.')
  return_code = run_command_with_updates(
      docker_build_command,
      'Building script_dir into docker image',
      verbose=verbose,
  )
  if return_code != 0:
    xpk_print(
        'Failed to add script_dir to docker image, check the base docker image.'
        f' You should be able to navigate to the URL {args.base_docker_image}'
        f' in {args.project}.'
    )
    xpk_exit(1)

  xpk_print(f'Adding Docker Image: {cloud_docker_image} to {args.project}')

  # Tag the docker image.
  tag_docker_image_command = f'docker tag {docker_name} {cloud_docker_image}'
  return_code = run_command_with_updates(
      tag_docker_image_command, 'Tag Docker Image', verbose=verbose
  )
  if return_code != 0:
    xpk_print(
        f'Failed to tag docker image with: {cloud_docker_image}.'
        f' You should be able to navigate to the URL {cloud_docker_image} in'
        f' {args.project}.'
    )
    xpk_exit(1)

  # Upload image to Artifact Registry.
  upload_docker_image_command = f'docker push {cloud_docker_image}'
  return_code = run_command_with_updates(
      upload_docker_image_command, 'Upload Docker Image', verbose=verbose
  )
  if return_code != 0:
    xpk_print(
        'Failed to upload docker image.'
        f' You should be able to navigate to the URL {cloud_docker_image} in'
        f' {args.project}.'
    )
    xpk_exit(1)
  return return_code, cloud_docker_image


def setup_docker_image(
    args, docker_platform: DockerPlatform
) -> tuple[int, str]:
  """Does steps to verify docker args, check image, and build image (if asked).

  Args:
    args: user provided arguments for running the command.

  Returns:
    tuple:
      0 if successful and 1 otherwise.
      Name of the docker image to use.
  """
  use_base_docker_image = use_base_docker_image_or_docker_image(args)

  docker_image = args.base_docker_image
  if use_base_docker_image:
    validate_docker_image_code = validate_docker_image(docker_image, args)
    if validate_docker_image_code != 0:
      xpk_exit(validate_docker_image_code)
    build_docker_image_code, docker_image = build_docker_image_from_base_image(
        args, docker_platform
    )
    if build_docker_image_code != 0:
      xpk_exit(build_docker_image_code)
  else:
    docker_image = args.docker_image
    validate_docker_image_code = validate_docker_image(args.docker_image, args)
    if validate_docker_image_code != 0:
      xpk_exit(validate_docker_image_code)

  return 0, docker_image


def use_base_docker_image_or_docker_image(args) -> bool:
  """Checks for correct docker image arguments.

  Args:
    args: user provided arguments for running the command.

  Returns:
    True if intended to use base docker image, False to use docker image.
  """
  use_base_docker_image = True
  # Check if (base_docker_image and script_dir) or (docker_image) is set.
  if args.docker_image is not None:
    if args.script_dir is not DEFAULT_SCRIPT_DIR:
      xpk_print(
          '`--script-dir` and --docker-image can not be used together. Please'
          ' see `--help` command for more details.'
      )
      xpk_exit(1)
    if args.base_docker_image is not DEFAULT_DOCKER_IMAGE:
      xpk_print(
          '`--base-docker-image` and --docker-image can not be used together.'
          ' Please see `--help` command for more details.'
      )
      xpk_exit(1)
    use_base_docker_image = False
  return use_base_docker_image
