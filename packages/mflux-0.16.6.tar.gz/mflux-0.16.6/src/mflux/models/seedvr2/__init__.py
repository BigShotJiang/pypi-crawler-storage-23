# SeedVR2 Image Upscaler
# Diffusion-based single-image super-resolution using NaDiT transformer

from mflux.models.seedvr2.variants.upscale.seedvr2 import SeedVR2

__all__ = ["SeedVR2"]
