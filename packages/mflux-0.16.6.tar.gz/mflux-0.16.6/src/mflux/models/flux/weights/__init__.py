from mflux.models.flux.weights.flux_weight_definition import FluxWeightDefinition
from mflux.models.flux.weights.flux_weight_mapping import FluxWeightMapping

__all__ = ["FluxWeightDefinition", "FluxWeightMapping"]
