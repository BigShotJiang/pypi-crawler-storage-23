from mflux.models.z_image.variants.z_image import ZImage

ZImageTurbo = ZImage

__all__ = ["ZImage", "ZImageTurbo"]
