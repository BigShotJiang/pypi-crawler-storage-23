# Z-Image Text Encoder (Qwen3)

