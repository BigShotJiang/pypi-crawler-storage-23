# =============================================================
# MEGA BENCHMARK PULL LIST
# =============================================================

# === FLAGSHIPS (the big boys) ===
ollama pull deepseek-r1:671b
ollama pull llama3.1:405b
ollama pull deepseek-coder-v2:236b
ollama pull qwen3:235b-a22b
ollama pull command-r-plus:104b
ollama pull qwen2.5:72b
ollama pull llama3.3:70b
ollama pull llama3.1:70b
ollama pull deepseek-r1:70b
ollama pull qwen3:72b

# === MID-TIER (32B-class) ===
ollama pull qwen3:32b
ollama pull qwen2.5-coder:32b
ollama pull command-r:35b
ollama pull gemma3:27b
ollama pull devstral:24b

# === EFFICIENT (8-14B) ===
ollama pull qwen3:14b
ollama pull phi4:14b
ollama pull gemma3:12b
ollama pull qwen3:8b
ollama pull llama3.1:8b
ollama pull gemma3:4b

# === REASONING SPECIALISTS ===
ollama pull deepseek-r1:32b
ollama pull deepseek-r1:14b
ollama pull deepseek-r1:8b
ollama pull deepseek-r1:1.5b

# === CODING SPECIALISTS ===
ollama pull qwen2.5-coder:14b
ollama pull qwen2.5-coder:7b
ollama pull qwen2.5-coder:1.5b
ollama pull codellama:70b
ollama pull codellama:34b
ollama pull starcoder2:15b
ollama pull starcoder2:7b
ollama pull starcoder2:3b

# === MULTIMODAL / VISION ===
ollama pull llava-llama3
ollama pull llava:34b
ollama pull llava:13b
ollama pull llava:7b

# === SMOL / EDGE / SCALING LAW STUDY ===
ollama pull qwen3:4b
ollama pull qwen3:1.7b
ollama pull qwen3:0.6b
ollama pull phi4-mini:3.8b
ollama pull gemma3:1b
ollama pull smollm2:1.7b
ollama pull smollm2:360m
ollama pull smollm2:135m

# === MISC / INTERESTING ===
ollama pull mixtral:8x22b
ollama pull mixtral:8x7b
ollama pull mistral:7b
ollama pull mistral-large:123b
ollama pull falcon3:10b
ollama pull yi:34b
