import reflex as rx

__all__ = ["lucide"]

lucide = rx.icon
