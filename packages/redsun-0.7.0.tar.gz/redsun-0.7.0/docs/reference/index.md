# Reference

- **[API reference](api.md)** - Public API
- **[Changelog](changelog.md)** - Version history and release notes
