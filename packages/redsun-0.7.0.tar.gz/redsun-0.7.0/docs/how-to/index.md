# How-to guides

## Getting started
- **[Installation](installation.md)**
- **[Build documentation](build-docs.md)**
- **[Run tests](run-tests.md)**
