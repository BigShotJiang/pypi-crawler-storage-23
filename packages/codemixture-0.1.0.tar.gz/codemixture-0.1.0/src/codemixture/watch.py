"""Codemixture file watcher — re-tangles on changes."""

from __future__ import annotations

import sys
import time
from pathlib import Path

from codemixture.tangle import CodemixtureError, tangle_project


def _try_tangle(paths: list[Path], output_dir: Path | None) -> None:
    """Attempt to tangle files, printing errors without crashing."""
    try:
        tangle_project(paths, output_dir=output_dir, verbose=True)
    except CodemixtureError as e:
        print(f"  error: {e}", file=sys.stderr)
    except Exception as e:
        print(f"  unexpected error: {e}", file=sys.stderr)


def watch_files(
    paths: list[Path],
    output_dir: Path | None = None,
    debounce_ms: int = 500,
) -> int:
    """Watch codemixture files and re-tangle on changes.

    Requires the watchdog package. Returns exit code.
    """
    try:
        from watchdog.events import FileSystemEventHandler
        from watchdog.observers import Observer
    except ImportError:
        print(
            "cm: watch requires the 'watchdog' package.\n"
            "Install it with: pip install codemixture[watch]",
            file=sys.stderr,
        )
        return 1

    # Resolve all paths and collect directories to watch
    resolved = [p.resolve() for p in paths if p.exists()]
    if not resolved:
        print("cm: no files to watch", file=sys.stderr)
        return 1

    watch_set = {str(p) for p in resolved}
    watch_dirs = {str(p.parent) for p in resolved}

    class TangleHandler(FileSystemEventHandler):
        def __init__(self):
            self._last_event = 0.0
            self._debounce_sec = debounce_ms / 1000.0

        def on_modified(self, event):
            if event.is_directory:
                return
            if event.src_path not in watch_set:
                return
            now = time.time()
            if now - self._last_event < self._debounce_sec:
                return
            self._last_event = now
            print(f"\n  Changed: {event.src_path}")
            _try_tangle(resolved, output_dir)

    # Initial tangle
    print("Tangling all files...")
    _try_tangle(resolved, output_dir)

    # Start watching
    observer = Observer()
    handler = TangleHandler()
    for d in watch_dirs:
        observer.schedule(handler, d, recursive=False)

    observer.start()
    print(f"Watching {len(resolved)} file(s) for changes. Press Ctrl+C to stop.")

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nStopping watcher.")
        observer.stop()

    observer.join()
    return 0
