"""Allow running codemixture as a module: python -m codemixture."""

from codemixture.cli import main

raise SystemExit(main())
