"""Codemixture tangler — extracts executable code from codemixture documents."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


class CodemixtureError(Exception):
    """Base error for all codemixture operations."""

    def __init__(self, message: str, file: str | None = None, line: int | None = None):
        self.file = file
        self.line = line
        prefix = ""
        if file:
            prefix = f"{file}:"
            if line is not None:
                prefix = f"{file}:{line}: "
        super().__init__(f"{prefix}{message}")


class ParseError(CodemixtureError):
    """Error parsing a codemixture document."""


class UnresolvedIncludeError(CodemixtureError):
    """An @include references a section that does not exist."""


class CircularIncludeError(CodemixtureError):
    """Circular @include dependency detected."""


class UnbalancedSectionError(CodemixtureError):
    """A @begin has no matching @end, or vice versa."""


class DuplicateSectionError(CodemixtureError):
    """A named section is defined more than once (use @append to extend)."""


@dataclass
class CodeBlock:
    """A fenced code block extracted from a markdown document."""

    language: str
    lines: list[str]
    start_line: int
    end_line: int
    output_file: str | None = None


@dataclass
class NamedSection:
    """A named section defined by @begin/@end directives."""

    name: str
    lines: list[str]
    source_file: str | None = None
    start_line: int = 0


@dataclass
class DocumentMetadata:
    """Metadata extracted from codemixture HTML comments."""

    type: str | None = None
    file: str | None = None
    depends: list[str] = field(default_factory=list)
    version: str | None = None
    language: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass
class Document:
    """A parsed codemixture document."""

    path: Path
    metadata: DocumentMetadata
    code_blocks: list[CodeBlock]
    named_sections: dict[str, NamedSection] = field(default_factory=dict)
    source_text: str = ""

# Language to comment prefix mapping
COMMENT_PREFIXES: dict[str, str] = {
    "python": "#",
    "py": "#",
    "shell": "#",
    "sh": "#",
    "bash": "#",
    "zsh": "#",
    "ruby": "#",
    "rb": "#",
    "perl": "#",
    "r": "#",
    "makefile": "#",
    "make": "#",
    "yaml": "#",
    "yml": "#",
    "toml": "#",
    "dockerfile": "#",
    "javascript": "//",
    "js": "//",
    "typescript": "//",
    "ts": "//",
    "rust": "//",
    "rs": "//",
    "go": "//",
    "c": "//",
    "cpp": "//",
    "java": "//",
    "kotlin": "//",
    "swift": "//",
    "scala": "//",
    "dart": "//",
    "zig": "//",
    "sql": "--",
    "lua": "--",
    "haskell": "--",
    "hs": "--",
    "elm": "--",
    "css": "/*",
    "html": "<!--",
    "xml": "<!--",
    "svg": "<!--",
}

# Fence detection
FENCE_OPEN_RE = re.compile(r"^(`{3,}|~{3,})\s*(\w+)?\s*$")

# Metadata blocks: <!-- codemixture\n...\n-->
METADATA_BLOCK_RE = re.compile(r"<!--\s*codemixture\s*\n(.*?)-->", re.DOTALL)

# Inline metadata: <!-- cm:keyword value -->
INLINE_META_RE = re.compile(r"<!--\s*cm:(\w+)\s+(.*?)\s*-->")

# Directive pattern (built dynamically per language)
def _directive_re(prefix: str) -> re.Pattern:
    """Build a regex matching @directive(name) for a given comment prefix."""
    esc = re.escape(prefix)
    if prefix == "/*":
        return re.compile(
            r"^(\s*)/\*\s*@(begin|end|include|append)\(([^)]+)\)\s*\*/\s*$"
        )
    if prefix == "<!--":
        return re.compile(
            r"^(\s*)<!--\s*@(begin|end|include|append)\(([^)]+)\)\s*-->\s*$"
        )
    return re.compile(
        rf"^(\s*){esc}\s*@(begin|end|include|append)\(([^)]+)\)\s*$"
    )


def parse_metadata_yaml(text: str) -> dict[str, Any]:
    """Parse a minimal YAML subset: flat key-value pairs and simple lists.

    Handles:
        key: value
        key: "quoted value"
        key: [item1, item2]
    """
    result: dict[str, Any] = {}
    for line in text.strip().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if ":" not in line:
            continue
        key, _, value = line.partition(":")
        key = key.strip()
        value = value.strip()
        # Strip quotes
        if (value.startswith('"') and value.endswith('"')) or (
            value.startswith("'") and value.endswith("'")
        ):
            value = value[1:-1]
        # Parse inline list
        if value.startswith("[") and value.endswith("]"):
            items = value[1:-1].split(",")
            value = [item.strip().strip('"').strip("'") for item in items if item.strip()]
        result[key] = value
    return result


def extract_metadata(source: str) -> DocumentMetadata:
    """Extract document-level metadata from codemixture HTML comments."""
    meta = DocumentMetadata()
    match = METADATA_BLOCK_RE.search(source)
    if not match:
        return meta
    raw = parse_metadata_yaml(match.group(1))
    meta.type = raw.get("type")
    meta.file = raw.get("file")
    meta.version = raw.get("version")
    meta.language = raw.get("language")
    depends = raw.get("depends", [])
    if isinstance(depends, str):
        meta.depends = [depends]
    else:
        meta.depends = depends
    # Store everything else in extra
    known = {"type", "file", "depends", "version", "language"}
    meta.extra = {k: v for k, v in raw.items() if k not in known}
    return meta


def extract_code_blocks(source: str, source_file: str | None = None) -> list[CodeBlock]:
    """Extract all fenced code blocks from a codemixture document.

    Returns code blocks in document order with their language, line numbers,
    and target output file.
    """
    meta = extract_metadata(source)
    current_file = meta.file
    blocks: list[CodeBlock] = []
    lines = source.splitlines()
    i = 0

    while i < len(lines):
        # Check for inline cm:file directive
        inline_match = INLINE_META_RE.match(lines[i])
        if inline_match and inline_match.group(1) == "file":
            current_file = inline_match.group(2)
            i += 1
            continue

        # Check for fence opening
        fence_match = FENCE_OPEN_RE.match(lines[i])
        if fence_match:
            fence_char = fence_match.group(1)[0]
            fence_len = len(fence_match.group(1))
            language = fence_match.group(2) or meta.language or ""
            start_line = i + 1  # 1-indexed
            i += 1
            block_lines: list[str] = []
            while i < len(lines):
                # Check for matching close fence
                close_re = re.compile(
                    rf"^{re.escape(fence_char)}{{{fence_len},}}\s*$"
                )
                if close_re.match(lines[i]):
                    break
                block_lines.append(lines[i])
                i += 1
            end_line = i + 1
            blocks.append(CodeBlock(
                language=language,
                lines=block_lines,
                start_line=start_line,
                end_line=end_line,
                output_file=current_file,
            ))
        i += 1

    return blocks


def collect_sections(
    code_blocks: list[CodeBlock],
    source_file: str | None = None,
) -> dict[str, NamedSection]:
    """Collect named sections from code blocks.

    Scans for @begin(name)/@end(name) directive pairs and @append(name)
    directives. Returns a dict mapping section names to their contents.
    """
    sections: dict[str, NamedSection] = {}

    for block in code_blocks:
        prefix = COMMENT_PREFIXES.get(block.language.lower(), "#")
        directive_re = _directive_re(prefix)
        current_section: str | None = None
        current_is_append: bool = False
        current_lines: list[str] = []
        current_start: int = block.start_line

        for offset, line in enumerate(block.lines):
            line_num = block.start_line + offset
            m = directive_re.match(line)
            if not m:
                if current_section is not None:
                    current_lines.append(line)
                continue

            _indent, directive, name = m.group(1), m.group(2), m.group(3)

            if directive == "begin":
                if current_section is not None:
                    raise UnbalancedSectionError(
                        f"nested @begin({name}) inside @begin({current_section})",
                        file=source_file,
                        line=line_num,
                    )
                if name in sections:
                    raise DuplicateSectionError(
                        f"section '{name}' already defined (use @append to extend)",
                        file=source_file,
                        line=line_num,
                    )
                current_section = name
                current_is_append = False
                current_lines = []
                current_start = line_num

            elif directive == "end":
                if current_section is None:
                    raise UnbalancedSectionError(
                        f"@end({name}) without matching @begin",
                        file=source_file,
                        line=line_num,
                    )
                if name != current_section:
                    raise UnbalancedSectionError(
                        f"@end({name}) does not match @begin({current_section})",
                        file=source_file,
                        line=line_num,
                    )
                if current_is_append and name in sections:
                    sections[name].lines.extend(current_lines)
                else:
                    sections[name] = NamedSection(
                        name=name,
                        lines=current_lines,
                        source_file=source_file,
                        start_line=current_start,
                    )
                current_section = None
                current_is_append = False
                current_lines = []

            elif directive == "append":
                if current_section is not None:
                    raise UnbalancedSectionError(
                        f"@append({name}) inside @begin({current_section})",
                        file=source_file,
                        line=line_num,
                    )
                current_section = name
                current_is_append = True
                current_lines = []
                current_start = line_num

        if current_section is not None:
            # sections close at end of code block
            if current_section in sections:
                sections[current_section].lines.extend(current_lines)
            else:
                sections[current_section] = NamedSection(
                    name=current_section,
                    lines=current_lines,
                    source_file=source_file,
                    start_line=current_start,
                )

    return sections


def resolve_includes(
    lines: list[str],
    sections: dict[str, NamedSection],
    language: str,
    source_file: str | None = None,
    resolution_stack: list[str] | None = None,
    project_sections: dict[str, NamedSection] | None = None,
) -> list[str]:
    """Resolve @include directives in a list of code lines.

    Recursively substitutes @include(name) with the named section's contents.
    The @include line's leading whitespace is prepended to each included line.
    """
    if resolution_stack is None:
        resolution_stack = []

    prefix = COMMENT_PREFIXES.get(language.lower(), "#")
    directive_re = _directive_re(prefix)
    result: list[str] = []

    for line in lines:
        m = directive_re.match(line)
        if not m or m.group(2) != "include":
            result.append(line)
            continue

        indent = m.group(1)
        ref = m.group(3)

        # Parse cross-document reference: doc:section
        if ":" in ref:
            doc_name, section_name = ref.split(":", 1)
            # Look up in project_sections
            qualified = f"{doc_name}:{section_name}"
            if project_sections and qualified in project_sections:
                section = project_sections[qualified]
            elif project_sections and section_name in project_sections:
                section = project_sections[section_name]
            else:
                raise UnresolvedIncludeError(
                    f"unresolved @include({ref})",
                    file=source_file,
                )
        else:
            section_name = ref
            if section_name not in sections:
                # Try project-wide
                if project_sections and section_name in project_sections:
                    section = project_sections[section_name]
                else:
                    raise UnresolvedIncludeError(
                        f"unresolved @include({section_name})",
                        file=source_file,
                    )
            else:
                section = sections[section_name]

        # Cycle detection
        if section_name in resolution_stack:
            cycle = " -> ".join(resolution_stack + [section_name])
            raise CircularIncludeError(
                f"circular include: {cycle}",
                file=source_file,
            )

        # Recursively resolve the section's own includes
        resolved = resolve_includes(
            section.lines,
            sections,
            language,
            source_file,
            resolution_stack + [section_name],
            project_sections,
        )

        # Apply indentation
        for sec_line in resolved:
            if sec_line.strip():
                result.append(indent + sec_line)
            else:
                result.append(sec_line)

    return result


def _has_directives(code_blocks: list[CodeBlock]) -> bool:
    """Check if any code block contains @begin, @end, @include, or @append."""
    for block in code_blocks:
        prefix = COMMENT_PREFIXES.get(block.language.lower(), "#")
        directive_re = _directive_re(prefix)
        for line in block.lines:
            if directive_re.match(line):
                return True
    return False


def parse_document(path: Path) -> Document:
    """Parse a codemixture document from a file path."""
    source = path.read_text(encoding="utf-8")
    metadata = extract_metadata(source)
    code_blocks = extract_code_blocks(source, source_file=str(path))
    named_sections = collect_sections(code_blocks, source_file=str(path))
    return Document(
        path=path,
        metadata=metadata,
        code_blocks=code_blocks,
        named_sections=named_sections,
        source_text=source,
    )


def tangle_document(
    doc: Document,
    project_sections: dict[str, NamedSection] | None = None,
) -> dict[str, str]:
    """Tangle a parsed document into output files.

    Returns a dict mapping output file paths to their contents.
    """
    # Group code blocks by output file
    file_blocks: dict[str, list[CodeBlock]] = {}
    for block in doc.code_blocks:
        target = block.output_file
        if target is None:
            continue
        if target not in file_blocks:
            file_blocks[target] = []
        file_blocks[target].append(block)

    results: dict[str, str] = {}

    for filepath, blocks in file_blocks.items():
        # Determine primary language from blocks
        language = ""
        for b in blocks:
            if b.language:
                language = b.language
                break

        # Concatenate all lines from blocks for this file
        all_lines: list[str] = []
        for b in blocks:
            all_lines.extend(b.lines)

        # If directives are present, resolve them
        if _has_directives(blocks):
            all_lines = resolve_includes(
                all_lines,
                doc.named_sections,
                language,
                source_file=str(doc.path),
                project_sections=project_sections,
            )

        # Strip section definitions (@begin..@end, @append..@end) from output.
        # Section body lines are captured in named sections and included via
        # @include — emitting them literally would duplicate them.
        prefix = COMMENT_PREFIXES.get(language.lower(), "#")
        directive_re = _directive_re(prefix)
        output_lines: list[str] = []
        in_section = False
        for line in all_lines:
            m = directive_re.match(line)
            if m:
                d = m.group(2)
                if d in ("begin", "append"):
                    in_section = True
                    continue
                if d == "end":
                    in_section = False
                    continue
            if in_section:
                continue
            output_lines.append(line)

        results[filepath] = "\n".join(output_lines) + "\n"

    return results


def tangle_file(
    path: Path,
    output_dir: Path | None = None,
    dry_run: bool = False,
    verbose: bool = False,
) -> dict[str, str]:
    """Tangle a single codemixture file. Convenience wrapper.

    Returns dict of output filepath -> contents.
    """
    doc = parse_document(path)
    results = tangle_document(doc)

    if not dry_run:
        for filepath, content in results.items():
            if output_dir:
                out = output_dir / filepath
            else:
                out = path.parent / filepath
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_text(content, encoding="utf-8")
            if verbose:
                print(f"  {out}")

    return results


def tangle_project(
    paths: list[Path],
    output_dir: Path | None = None,
    dry_run: bool = False,
    verbose: bool = False,
) -> dict[str, str]:
    """Tangle multiple codemixture files as a project.

    Handles cross-document references by building a project-wide section map.
    """
    # First pass: parse all documents and build project-wide section map
    documents: list[Document] = []
    project_sections: dict[str, NamedSection] = {}

    for path in paths:
        doc = parse_document(path)
        documents.append(doc)
        doc_stem = path.stem
        for name, section in doc.named_sections.items():
            # Store as both unqualified and qualified name
            qualified = f"{doc_stem}:{name}"
            project_sections[qualified] = section
            if name not in project_sections:
                project_sections[name] = section

    # Second pass: tangle each document with project-wide sections available
    all_results: dict[str, str] = {}
    for doc in documents:
        results = tangle_document(doc, project_sections=project_sections)
        if not dry_run:
            for filepath, content in results.items():
                if output_dir:
                    out = output_dir / filepath
                else:
                    out = doc.path.parent / filepath
                out.parent.mkdir(parents=True, exist_ok=True)
                out.write_text(content, encoding="utf-8")
                if verbose:
                    print(f"  {out}")
        all_results.update(results)

    return all_results
