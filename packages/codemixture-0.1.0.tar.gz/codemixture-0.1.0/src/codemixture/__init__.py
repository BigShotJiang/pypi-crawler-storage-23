"""Codemixture — a literate programming system for the AI coding era."""

from codemixture.tangle import (
    CodeBlock,
    CodemixtureError,
    CircularIncludeError,
    Document,
    DocumentMetadata,
    DuplicateSectionError,
    NamedSection,
    ParseError,
    UnbalancedSectionError,
    UnresolvedIncludeError,
    extract_code_blocks,
    extract_metadata,
    parse_document,
    tangle_document,
    tangle_file,
    tangle_project,
)

__version__ = "0.1.0"

__all__ = [
    "CodeBlock",
    "CodemixtureError",
    "CircularIncludeError",
    "Document",
    "DocumentMetadata",
    "DuplicateSectionError",
    "NamedSection",
    "ParseError",
    "UnbalancedSectionError",
    "UnresolvedIncludeError",
    "extract_code_blocks",
    "extract_metadata",
    "parse_document",
    "tangle_document",
    "tangle_file",
    "tangle_project",
]
