"""Codemixture CLI — the `cm` command."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path


def main(argv: list[str] | None = None) -> int:
    """Main entry point for the cm CLI."""
    parser = argparse.ArgumentParser(
        prog="cm",
        description="Codemixture — literate programming for the AI coding era",
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # cm tangle
    tangle_parser = subparsers.add_parser(
        "tangle", help="Extract code from codemixture documents"
    )
    tangle_parser.add_argument(
        "files", nargs="+", type=Path, help="Codemixture .md files to tangle"
    )
    tangle_parser.add_argument(
        "--output-dir", "-o", type=Path, default=None,
        help="Output directory (default: relative to each source file)",
    )
    tangle_parser.add_argument(
        "--dry-run", "-n", action="store_true",
        help="Show what would be generated without writing files",
    )
    tangle_parser.add_argument(
        "--verbose", "-v", action="store_true",
        help="Print each generated file path",
    )

    # cm check
    check_parser = subparsers.add_parser(
        "check", help="Validate codemixture documents"
    )
    check_parser.add_argument(
        "files", nargs="+", type=Path, help="Codemixture .md files to check"
    )
    check_parser.add_argument(
        "--strict", action="store_true",
        help="Treat warnings as errors",
    )

    # cm watch
    watch_parser = subparsers.add_parser(
        "watch", help="Watch files and re-tangle on changes"
    )
    watch_parser.add_argument(
        "files", nargs="*", type=Path,
        help="Codemixture .md files to watch (default: all .md in current dir)",
    )
    watch_parser.add_argument(
        "--output-dir", "-o", type=Path, default=None,
        help="Output directory",
    )
    watch_parser.add_argument(
        "--debounce", type=int, default=500,
        help="Debounce interval in milliseconds (default: 500)",
    )

    # cm init
    init_parser = subparsers.add_parser(
        "init", help="Initialize a new codemixture project"
    )
    init_parser.add_argument(
        "dir", nargs="?", type=Path, default=Path("."),
        help="Directory for the new project (default: current directory)",
    )
    init_parser.add_argument(
        "--name", type=str, default=None,
        help="Project name (default: directory name)",
    )
    init_parser.add_argument(
        "--language", type=str, default="python",
        help="Default language (default: python)",
    )

    args = parser.parse_args(argv)

    if args.command is None:
        parser.print_help()
        return 0

    if args.command == "tangle":
        return cmd_tangle(args)
    elif args.command == "check":
        return cmd_check(args)
    elif args.command == "watch":
        return cmd_watch(args)
    elif args.command == "init":
        return cmd_init(args)

    return 0


def cmd_tangle(args: argparse.Namespace) -> int:
    """Execute the tangle command."""
    from codemixture.tangle import (
        CodemixtureError,
        tangle_file,
        tangle_project,
    )

    try:
        files = [Path(f) for f in args.files]
        for f in files:
            if not f.exists():
                print(f"cm: error: {f} not found", file=sys.stderr)
                return 1

        if len(files) == 1:
            results = tangle_file(
                files[0],
                output_dir=args.output_dir,
                dry_run=args.dry_run,
                verbose=args.verbose,
            )
        else:
            results = tangle_project(
                files,
                output_dir=args.output_dir,
                dry_run=args.dry_run,
                verbose=args.verbose,
            )

        if args.dry_run:
            for filepath in sorted(results):
                print(f"  would write: {filepath}")
        elif args.verbose:
            print(f"Tangled {len(results)} file(s)")

        return 0

    except CodemixtureError as e:
        print(f"cm: {e}", file=sys.stderr)
        return 1


def cmd_check(args: argparse.Namespace) -> int:
    """Execute the check command."""
    try:
        from codemixture.check import check_files
    except ImportError:
        # Fallback: minimal check without the full checker module
        from codemixture.tangle import CodemixtureError, parse_document

        errors = 0
        for f in args.files:
            if not f.exists():
                print(f"cm: error: {f} not found", file=sys.stderr)
                errors += 1
                continue
            try:
                parse_document(f)
                print(f"  {f}: ok")
            except CodemixtureError as e:
                print(f"  {f}: {e}", file=sys.stderr)
                errors += 1
        return 1 if errors else 0

    return check_files([Path(f) for f in args.files], strict=args.strict)


def cmd_watch(args: argparse.Namespace) -> int:
    """Execute the watch command."""
    try:
        from codemixture.watch import watch_files
    except ImportError:
        print(
            "cm: watch requires the 'watchdog' package.\n"
            "Install it with: pip install codemixture[watch]",
            file=sys.stderr,
        )
        return 1

    files = [Path(f) for f in args.files] if args.files else list(Path(".").glob("*.md"))
    return watch_files(files, output_dir=args.output_dir, debounce_ms=args.debounce)


def cmd_init(args: argparse.Namespace) -> int:
    """Execute the init command."""
    project_dir = Path(args.dir)
    project_dir.mkdir(parents=True, exist_ok=True)

    name = args.name or project_dir.resolve().name
    language = args.language

    project_file = project_dir / f"{name}.md"
    if project_file.exists():
        print(f"cm: {project_file} already exists", file=sys.stderr)
        return 1

    comment = LANG_COMMENT.get(language, "#")
    fence = "`" * 3
    ext = _lang_extension(language)

    lines = [
        f"# {name}",
        "",
        "<!-- codemixture",
        "type: project",
        f"name: {name}",
        "version: 0.1.0",
        f"language: {language}",
        f"file: src/{name}/main.{ext}",
        "-->",
        "",
        "## Overview",
        "",
        "Describe your project here.",
        "",
        "## Main",
        "",
        f"{fence}{language}",
        f"{comment} Your code here",
        fence,
        "",
    ]
    content = "\n".join(lines)
    project_file.write_text(content, encoding="utf-8")
    print(f"  Created {project_file}")
    return 0


LANG_COMMENT: dict[str, str] = {
    "python": "#",
    "javascript": "//",
    "typescript": "//",
    "rust": "//",
    "go": "//",
    "c": "//",
    "cpp": "//",
    "java": "//",
    "ruby": "#",
    "shell": "#",
    "bash": "#",
}


def _lang_extension(language: str) -> str:
    """Map language name to file extension."""
    extensions: dict[str, str] = {
        "python": "py",
        "javascript": "js",
        "typescript": "ts",
        "rust": "rs",
        "go": "go",
        "c": "c",
        "cpp": "cpp",
        "java": "java",
        "ruby": "rb",
        "shell": "sh",
        "bash": "sh",
    }
    return extensions.get(language, language)


if __name__ == "__main__":
    sys.exit(main())
