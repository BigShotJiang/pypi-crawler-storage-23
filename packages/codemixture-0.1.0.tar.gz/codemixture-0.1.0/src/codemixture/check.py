"""Codemixture document checker — validates without tangling."""

from __future__ import annotations

import sys
from pathlib import Path

from codemixture.tangle import (
    COMMENT_PREFIXES,
    CodemixtureError,
    CircularIncludeError,
    DuplicateSectionError,
    UnbalancedSectionError,
    UnresolvedIncludeError,
    _directive_re,
    _has_directives,
    collect_sections,
    extract_code_blocks,
    extract_metadata,
    resolve_includes,
)


class Diagnostic:
    """A single validation diagnostic."""

    def __init__(
        self,
        severity: str,
        message: str,
        file: str | None = None,
        line: int | None = None,
    ):
        self.severity = severity
        self.message = message
        self.file = file
        self.line = line

    def __str__(self) -> str:
        prefix = ""
        if self.file:
            prefix = f"{self.file}:"
            if self.line is not None:
                prefix = f"{self.file}:{self.line}: "
        return f"{prefix}{self.severity}: {self.message}"


def check_metadata(path: Path) -> list[Diagnostic]:
    """Check that required metadata fields are present."""
    diagnostics: list[Diagnostic] = []
    source = path.read_text(encoding="utf-8")
    meta = extract_metadata(source)

    if meta.file is None and meta.type not in ("specification", "project"):
        diagnostics.append(Diagnostic(
            "warning",
            "no 'file' metadata — document won't produce output when tangled",
            file=str(path),
        ))

    return diagnostics


def check_sections(path: Path) -> list[Diagnostic]:
    """Check for unbalanced @begin/@end and duplicate sections."""
    diagnostics: list[Diagnostic] = []
    source = path.read_text(encoding="utf-8")
    code_blocks = extract_code_blocks(source, source_file=str(path))

    try:
        collect_sections(code_blocks, source_file=str(path))
    except UnbalancedSectionError as e:
        diagnostics.append(Diagnostic("error", str(e), file=str(path)))
    except DuplicateSectionError as e:
        diagnostics.append(Diagnostic("error", str(e), file=str(path)))

    return diagnostics


def check_includes(
    path: Path,
    project_sections: dict | None = None,
) -> list[Diagnostic]:
    """Check that all @include references can be resolved."""
    diagnostics: list[Diagnostic] = []
    source = path.read_text(encoding="utf-8")
    code_blocks = extract_code_blocks(source, source_file=str(path))

    if not _has_directives(code_blocks):
        return diagnostics

    try:
        sections = collect_sections(code_blocks, source_file=str(path))
    except CodemixtureError:
        return diagnostics  # Already reported by check_sections

    # Try resolving includes for each code block's lines
    for block in code_blocks:
        language = block.language or "python"
        try:
            all_lines: list[str] = []
            for b in code_blocks:
                all_lines.extend(b.lines)
            resolve_includes(
                all_lines,
                sections,
                language,
                source_file=str(path),
                project_sections=project_sections,
            )
            break  # Only need to resolve once
        except UnresolvedIncludeError as e:
            diagnostics.append(Diagnostic("error", str(e), file=str(path)))
            break
        except CircularIncludeError as e:
            diagnostics.append(Diagnostic("error", str(e), file=str(path)))
            break

    return diagnostics


def check_unused(path: Path) -> list[Diagnostic]:
    """Warn about named sections that are never @included."""
    diagnostics: list[Diagnostic] = []
    source = path.read_text(encoding="utf-8")
    code_blocks = extract_code_blocks(source, source_file=str(path))

    if not _has_directives(code_blocks):
        return diagnostics

    try:
        sections = collect_sections(code_blocks, source_file=str(path))
    except CodemixtureError:
        return diagnostics

    # Find all @include references
    included_names: set[str] = set()
    for block in code_blocks:
        prefix = COMMENT_PREFIXES.get(block.language.lower(), "#")
        directive_re = _directive_re(prefix)
        for line in block.lines:
            m = directive_re.match(line)
            if m and m.group(2) == "include":
                ref = m.group(3)
                if ":" in ref:
                    _, name = ref.split(":", 1)
                    included_names.add(name)
                else:
                    included_names.add(ref)

    for name in sections:
        if name not in included_names:
            diagnostics.append(Diagnostic(
                "warning",
                f"section '{name}' is defined but never included",
                file=str(path),
                line=sections[name].start_line,
            ))

    return diagnostics


def check_file(path: Path, strict: bool = False) -> list[Diagnostic]:
    """Run all checks on a single file."""
    diagnostics: list[Diagnostic] = []
    diagnostics.extend(check_metadata(path))
    diagnostics.extend(check_sections(path))
    diagnostics.extend(check_includes(path))
    diagnostics.extend(check_unused(path))
    return diagnostics


def check_files(paths: list[Path], strict: bool = False) -> int:
    """Check multiple files. Returns exit code (0 = ok, 1 = errors found)."""
    has_errors = False

    for path in paths:
        if not path.exists():
            print(f"cm: error: {path} not found", file=sys.stderr)
            has_errors = True
            continue

        diagnostics = check_file(path, strict=strict)

        if not diagnostics:
            print(f"  {path}: ok")
            continue

        for d in diagnostics:
            if d.severity == "error":
                has_errors = True
            elif strict and d.severity == "warning":
                has_errors = True
            print(f"  {d}")

    return 1 if has_errors else 0
