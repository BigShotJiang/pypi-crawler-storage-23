---
tags:
  category: system
  context: tag-value
---
# status: `blocked`

Cannot proceed until something else is resolved. A sub-state of open — the commitment still exists but progress is gated on an external dependency.
