---
tags:
  category: system
  context: meta
---
# .meta/album — Same Album

Items tagged with the same album. Groups tracks from
the same release together.

album=*
album=
