Create session description for automated future selection.

Max {max_sentences} sentences. Include: main goals, actions performed, current focus/pending.
Include tool/workflow signals if relevant (coding, data extraction, web research, scripting, file ops).
Factual, specific, no fluff.

Session: {session_name}

Conversation:
{conversation_excerpt}