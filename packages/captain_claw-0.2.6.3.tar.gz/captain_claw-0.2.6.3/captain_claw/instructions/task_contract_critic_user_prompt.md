Evaluate the candidate response against the requirements.

Original user request:
{user_input}

Requirements JSON:
{requirements_json}

Candidate response:
{candidate_response}

Return JSON only.
