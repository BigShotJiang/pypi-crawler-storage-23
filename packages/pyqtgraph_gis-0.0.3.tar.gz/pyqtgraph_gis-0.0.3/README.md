# PyQtGraph GIS Widget

[![pyqtgraph](https://img.shields.io/badge/github-pyqtgraph-blue?logo=github)](https://github.com/pyqtgraph/pyqtgraph)

Tile-base GIS widget for PyQt6 applications extending on the [PyQtGraph](https://github.com/pyqtgraph/pyqtgraph/)
library.

The widget allows you to display any geodata in a PyQt6 application with the ease of use of PyQtGraph.
This includes support for displaying geodata in the form of points, lines, polygons and raster data.
The library could be used to display:

- Vehicle positions or paths in a fleet management or log-analysis application
- Geospatial data in a scientific or GIS application, like weather data, population density, or land use
- Any other geospatial data that can be represented as points, lines, polygons or raster data

You can find code examples in the [Documentation](https://github.com/olemeif/pyqtgraph-gis/wiki).

## Requirements

- [Python](https://www.python.org/) 3.13 or higher (earlier versions may work but are not tested)
- [PyQt6](https://www.riverbankcomputing.com/software/pyqt/)
- [PyQtGraph](https://www.pyqtgraph.org/)
- [Requests](https://requests.readthedocs.io/en/latest/)

## Installation

You can install the library using pip:

```bash
pip install pyqtgraph-gis
```

## Documentation

You can find the documentation with a quickstart guide, API reference, code examples and more in
the [Wiki](https://github.com/olemeif/pyqtgraph-gis/wiki).
