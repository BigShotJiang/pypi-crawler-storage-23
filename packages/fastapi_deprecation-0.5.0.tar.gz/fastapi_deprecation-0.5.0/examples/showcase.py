from datetime import datetime, timedelta, timezone
import logging

import asyncio
from typing import AsyncGenerator
from starlette.responses import StreamingResponse

from fastapi import FastAPI, APIRouter, Depends, Query, WebSocket, Request, Response
from fastapi.responses import JSONResponse
from fastapi_deprecation import (
    deprecated,
    DeprecationDependency,
    DeprecationMiddleware,
    DeprecationConfig,
    auto_deprecate_openapi,
    set_deprecation_callback,
)
from fastapi_deprecation.metrics import DeprecationTracker, InMemoryMetricsStore

# ---------------------------------------------------------
# Setup: Telemetry Logging
# ---------------------------------------------------------
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("api.telemetry")


# Simple logging callback
def log_deprecation_usage(
    request: Request, response: Response, dep: DeprecationDependency | DeprecationConfig
):
    """Log when a client accesses a deprecated endpoint."""
    logger.warning(
        f"DEPRECATED USAGE: ⚠ Client accessed {request.url.path} "
        f"{f'(Sunset: {dep.sunset_date})' if dep.sunset_date else ''}"
    )


set_deprecation_callback(log_deprecation_usage)


# Initialize the universal metrics tracker
tracker = DeprecationTracker(store=InMemoryMetricsStore())
set_deprecation_callback(tracker.record_usage)


# Calculate some dynamic dates for the example so it always runs
now = datetime.now(timezone.utc)
sunset_past = now - timedelta(days=30)
sunset_future = now + timedelta(days=60)
deprecation_future = now + timedelta(days=10)


# =========================================================
# Scenario 1: Mounted Sub-Application (v1 API)
# Uses Global Middleware to sunset entire prefix
# =========================================================
v1_app = FastAPI(title="Showcase API v1", description="Legacy API (Sunset)")


@v1_app.get("/users")
async def get_users_v1():
    # Because of middleware, you won't actually be able to hit this if sunset_date has passed
    return [{"id": 1, "name": "Alice", "v": 1}, {"id": 2, "name": "Bob", "v": 1}]


@v1_app.get("/products")
async def get_products_v1():
    return [{"id": 101, "name": "Widget", "v": 1}]


# =========================================================
# Scenario 2: Router Dependency (v2 API)
# Deprecates all endpoints within a router
# =========================================================
v2_router = APIRouter(
    prefix="/v2",
    tags=["v2 - Deprecated Layer"],
    dependencies=[
        Depends(
            DeprecationDependency(
                deprecation_date="2024-01-01",
                sunset_date=sunset_future.isoformat(),
                alternative="/v3",
                links={"successor-version": "/docs#/v3"},
            )
        )
    ],
)


# Entire router deprecated with dependency. Still active, but warns
@v2_router.get("/users")
async def get_users_v2(active_only: bool = True):
    """Entire router deprecated with dependency. Still active, but emits warnings headers."""
    return [
        {"id": 1, "name": "Alice", "schema": "v2"},
        {"id": 2, "name": "Bob", "schema": "v2"},
    ]


# Entire router deprecated with dependency. Still active, but warns
@v2_router.get("/products")
async def get_products_v2():
    """Entire router deprecated with dependency. Still active, but emits warnings headers."""
    return [{"id": 101, "name": "Super Widget", "schema": "v2"}]


# =========================================================
# Scenario 3: Decorator (v3 API)
# Granular endpoint deprecations and the active modern API
# =========================================================
v3_router = APIRouter(prefix="/v3", tags=["v3 - Current API"])


# A fully active, modern endpoint
@v3_router.get("/users")
async def get_users_v3(status: str = Query("active", description="Filter by status")):
    """A fully active, modern endpoint"""
    return {
        "data": [
            {"id": 1, "name": "Alice", "status": "active", "schema": "v3"},
            {"id": 2, "name": "Bob", "status": "active", "schema": "v3"},
        ],
        "meta": {"version": 3, "total": 2},
    }


# An endpoint undergoing a scheduled brownout (with alternative)
@v3_router.get("/reports/legacy")
@deprecated(
    sunset_date=sunset_future.isoformat(),
    alternative="/v3/reports/modern",
    brownouts=[
        (now - timedelta(hours=1), now + timedelta(hours=2))  # Currently offline!
    ],
    detail="Legacy reports are undergoing scheduled maintenance (brownout) to simulate final shutdown.",
)
async def legacy_reports():
    """Endpoint with alternative and undergoing scheduled maintenance (brownout) to simulate final shutdown."""
    return {"report_data": "Lots of unstructured data in a bad format"}


# The modern, active reports endpoint that legacy redirects to.
@v3_router.get("/reports/modern")
async def modern_reports():
    """The modern, active reports endpoint that legacy redirects to."""
    return {"report_data": {"structured": True, "format": "JSON"}}


# An endpoint using a Custom Response Model
custom_sunset_response = JSONResponse(
    status_code=410,
    content={
        "error": "gone",
        "description": "The XML export feature has been permanently removed.",
        "migration_guide": "https://example.com/migrate-from-xml",
    },
)


# Endpoint using a Custom Response Model
@v3_router.get("/export/xml")
@deprecated(
    sunset_date=sunset_past.isoformat(),  # Sunset has already passed!
    response=custom_sunset_response,
)
async def export_xml():
    """Endpoint using a Custom Response Model, sunset has already passed"""
    return "<data><item>You should not see this</item></data>"


# An endpoint announcing an Upcoming Deprecation
@v3_router.get("/legacy-auth")
@deprecated(
    deprecation_date=deprecation_future.isoformat(),  # Not deprecated yet, but will be!
    sunset_date=(now + timedelta(days=365)).isoformat(),
    detail="Switch to OAuth2 soon.",
)
async def legacy_auth():
    """Endpoint announcing an Upcoming Deprecation"""
    return {"token": "insecure-legacy-token"}


# An endpoint demonstrating Progressive Chaos Engineering and Edge Caching
@v3_router.get("/flaky-data")
@deprecated(
    deprecation_date=(
        now - timedelta(days=15)
    ).isoformat(),  # Deprecation started 15 days ago
    sunset_date=(now + timedelta(days=15)).isoformat(),  # Sunset is 15 days from now
    progressive_brownout=True,  # 50% failure rate right now!
    cache_tag="api-v3-flaky",  # Edge caching tag for instant CDN purging
    detail="This endpoint is progressively degrading. Expect probabilistic 410 Gone responses.",
)
async def flaky_data():
    """Endpoint demonstrating Progressive Chaos Engineering and Edge Caching"""
    return {"message": "You got lucky! The request succeeded."}


# An endpoint demonstrating Static Chaos Engineering
@v3_router.get("/static-flaky-data")
@deprecated(
    sunset_date=(now + timedelta(days=15)).isoformat(),  # Sunset is 15 days from now
    brownout_probability=0.1,  # Static 10% failure rate
    detail="This endpoint has a static 10% chance to fail.",
)
async def static_flaky_data():
    """Endpoint demonstrating Static Chaos Engineering"""
    return {"message": "You survived the 10% static brownout!"}


# =========================================================
# Scenario 4: Real-Time Stream Deprecation (WebSockets & SSE)
# =========================================================


# Demonstrating generic WebSocket deprecation injection
@v3_router.websocket("/ws")
@deprecated(
    sunset_date=sunset_future.isoformat(),
    alternative="/v4/ws",
    detail="Use the new v4 WebSocket stream for better performance.",
)
async def deprecated_websocket(websocket: WebSocket):
    await websocket.accept()
    await websocket.send_text(
        "Hello from the deprecated WebSocket! Deprecation headers were sent during HTTP Upgrade."
    )
    await websocket.close()


# =========================================================
# Scenario 5: Real-Time Stream Deprecation (SSE)
# =========================================================


# Demonstrating Server-Sent Events (SSE) graceful decay wrapper


async def fake_sse_stream() -> AsyncGenerator[str, None]:
    for i in range(5):
        yield f'event: update\ndata: {{"tick": {i}}}\n\n'
        await asyncio.sleep(1)


@v3_router.get("/stream")
@deprecated(
    sunset_date=sunset_past.isoformat(),
    link="https://example.com/migrate/v3/stream",
)  # Sunset has already passed!
async def streaming_endpoint():
    """Endpoint demonstrating graceful SSE deprecation termination."""
    # The @deprecated decorator now automatically wraps and detects StreamingResponses
    # that produce event-stream outputs!
    return StreamingResponse(fake_sse_stream(), media_type="text/event-stream")


# =========================================================
# Main Application Assembly
# =========================================================
app = FastAPI(
    title="Deprecation Showcase API",
    description="Demonstrates global middleware, router dependencies, and granular `@deprecated` decorators.",
)

# =========================================================
# Metrics Dashboard
# =========================================================


@app.get(
    "/admin/metrics",
    tags=["Metrics"],
    summary="View Deprecation Analytics",
    description="Export the aggregated usage metrics of all deprecated endpoints from the DeprecationTracker.",
)
async def get_metrics():
    return await tracker.export_json()


# 1. Apply Middleware (applies to the mounted v1 app and unroutable 404s)
app.add_middleware(
    DeprecationMiddleware,
    deprecations={
        "/v1": DeprecationConfig(
            sunset_date=sunset_past,  # v1 is globally killed by middleware
            detail="The v1 API is sunset globally via ASGI middleware.",
        )
    },
)

# 2. Mount Sub-App
app.mount("/v1", v1_app)

# 3. Include Routers
app.include_router(v2_router)
app.include_router(v3_router)

# 4. Generate OpenAPI schemas for all endpoints (including mounts!)
auto_deprecate_openapi(app)

if __name__ == "__main__":
    import uvicorn

    print("\n--- Starting FastAPI Deprecation Showcase ---")
    print("API documentation serving at: http://127.0.0.1:8000/docs")
    print("Check out the /v1, /v2, and /v3 endpoints in the Swagger interface.\n")
    uvicorn.run(app, host="127.0.0.1", port=8000)
