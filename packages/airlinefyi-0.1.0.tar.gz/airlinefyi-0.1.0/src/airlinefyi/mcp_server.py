"""MCP server for airlinefyi."""

from __future__ import annotations

from typing import Any

from mcp.server.fastmcp import FastMCP

from airlinefyi.api import AirlineFYI

mcp = FastMCP("airlinefyi")


@mcp.tool()
def search_airlinefyi(query: str) -> dict[str, Any]:
    """Search airlinefyi.com for content matching the query."""
    with AirlineFYI() as api:
        return api.search(query)
