# airlinefyi

Airlines, fleets and route data API client — [airlinefyi.com](https://airlinefyi.com)

## Install

```bash
pip install airlinefyi
```

## Quick Start

```python
from airlinefyi.api import AirlineFYI

with AirlineFYI() as api:
    results = api.search("delta")
    print(results)
```

## License

MIT
