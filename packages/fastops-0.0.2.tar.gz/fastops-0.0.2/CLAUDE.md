# fastops — Development Guide

## Project Overview
Python library for generating Dockerfiles and Docker Compose configs. Source of truth is always the notebooks (`nbs/`); Python modules are generated via nbdev export.

## Workflow
- **Edit**: only edit notebooks in `nbs/`, never edit `fastops/*.py` directly
- **Export**: `uv run python -c "import nbdev; nbdev.nbdev_export()"`
- **Dependencies**: `uv add <pkg>` (never pip install)
- **Always plan before coding** — show plan and get approval before implementing

## Notebook → Module Map
| Notebook | Module | Contents |
|---|---|---|
| `nbs/00_core.ipynb` | `fastops/core.py` | `Dockerfile` builder, `Docker` class, `calldocker()`, build/run/test helpers |
| `nbs/01_compose.ipynb` | `fastops/compose.py` | `Compose` builder, `service()`, `swag()`, `appfile()` |
| `nbs/02_caddy.ipynb` | `fastops/caddy.py` | `caddyfile()`, `caddy()`, `cloudflared_svc()`, `crowdsec()` |
| `nbs/03_multipass.ipynb` | `fastops/multipass.py` | `Multipass` class, `cloud_init_yaml()`, `launch()`, `launch_docker_vm()`, VM helpers |
| `nbs/04_cloudflare.ipynb` | `fastops/cloudflare.py` | `CF` class (Cloudflare SDK wrapper), `dns_record()` |
| `nbs/05_apps.ipynb` | `fastops/apps.py` | `python_app()`, `fasthtml_app()`, `fastapi_react()`, `go_app()`, `rust_app()` |
| `nbs/06_vps.ipynb` | `fastops/vps.py` | `vps_init()`, `create()`, `servers()`, `server_ip()`, `delete()`, `run_ssh()`, `sync()`, `deploy()` |

## Key APIs

### Dockerfile builder (`core.py`)
```python
df = (Dockerfile()
    .from_('python', '3.12-slim')
    .run('pip install flask')
    .copy('.', '/app')
    .expose(8080)
    .cmd(['python', 'app.py']))
df.save('Dockerfile')
df.build(tag='myapp:latest')  # patched method
```

### Compose builder (`compose.py`)
```python
dc = (Compose()
    .svc('app', build='.', networks=['web'])
    .svc('swag', **swag('myapp.example.com', port=5001))
    .network('web').volume('swag_config'))
dc.save('docker-compose.yml')
```

### Caddy module (`caddy.py`)
```python
from fastops.caddy import caddyfile, caddy, cloudflared_svc, crowdsec

# Minimal: Caddy auto-TLS, ports 80+443 open
dc = (Compose()
    .svc('app', build='.', networks=['web'])
    .svc('caddy', **caddy('myapp.example.com', port=5001))
    .network('web').volume('caddy_data').volume('caddy_config'))

# With cloudflared (zero open ports)
dc = (Compose()
    .svc('app', build='.', networks=['web'])
    .svc('caddy', **caddy('myapp.example.com', port=5001, cloudflared=True))
    .svc('cloudflared', **cloudflared_svc(), networks=['web'])
    .network('web').volume('caddy_data').volume('caddy_config'))

# With CrowdSec + cloudflared (full security)
dc = (Compose()
    .svc('app', build='.', networks=['web'])
    .svc('caddy', **caddy('myapp.example.com', port=5001, crowdsec=True, cloudflared=True))
    .svc('crowdsec', **crowdsec())
    .svc('cloudflared', **cloudflared_svc(), networks=['web'])
    .network('web')
    .volume('caddy_data').volume('caddy_config')
    .volume('crowdsec-db').volume('crowdsec-config'))
```

### `caddy()` image selection
| `crowdsec` | `dns` | Image |
|---|---|---|
| False | None | `caddy:2` |
| True | None | `serfriz/caddy-crowdsec:latest` |
| False | `'cloudflare'` | `serfriz/caddy-cloudflare:latest` |
| True | `'cloudflare'` | `ghcr.io/buildplan/csdp-caddy:latest` |
| False | `'duckdns'` | `serfriz/caddy-duckdns:latest` |

### Apps module (`apps.py`)
```python
from fastops.apps import python_app, fasthtml_app, fastapi_react, go_app, rust_app

# FastHTML app with uv, extra apt packages, persistent volumes
df = fasthtml_app(port=5001, pkgs=['rclone', 'ca-certificates'], volumes=['/app/data'])

# FastAPI + React two-stage build
df = fastapi_react(port=8000, frontend_dir='frontend')

# Go two-stage build → distroless
df = go_app(port=8080, go_version='1.22')

# Rust two-stage build → distroless
df = rust_app(port=8080, binary='myapp')
```

### `run_mount()` on Dockerfile
```python
# Cache mounts for faster rebuilds
df = (Dockerfile().from_('python:3.12-slim')
    .run_mount('uv sync --frozen --no-dev', target='/root/.cache/uv')
    .run_mount('go mod download', target='/go/pkg/mod'))
```

### CLI wrapper (`core.py`)
```python
# Docker CLI (subprocess-based, no docker-py dependency)
calldocker('build', '-t', 'myapp', '.')  # direct
dk.build('.', t='myapp', rm=True)         # via Docker class
dk.ps(format='{{.Names}}', a=True)        # → docker ps --format={{.Names}} -a

# Podman support: set DOCKR_RUNTIME=podman
```

### VPS module (`vps.py`)
```python
from fastops.vps import vps_init, create, servers, run_ssh, deploy

# Generate cloud-init YAML for a fresh VPS
yaml = vps_init('myserver', pub_keys='ssh-rsa AAAA...',
                docker=True, cf_token='<tunnel-token>',
                packages=['git'])

# Provision a Hetzner server
ip = create('prod', image='ubuntu-24.04', server_type='cx22',
            location='nbg1', cloud_init=yaml, ssh_keys=['mykey'])

# SSH commands
run_ssh(ip, 'docker ps', user='deploy', key='~/.ssh/id_ed25519')

# Deploy a Compose stack
deploy(compose_obj, ip, user='deploy', key='~/.ssh/id_ed25519', path='/srv/app')
```

### Flag-building convention (`Docker.__call__`, `DockerCompose.__call__`)
- `k=v` (single char, non-bool) → `-k v`
- `k=True` (single char) → `-k`
- `key=v` (multi char, non-bool) → `--key=v`
- `key=True` (multi char) → `--key`
- `from_='builder'` → `--from=builder` (trailing `_` stripped)

## Key Patterns

### Notebook JSON
- Never hand-write notebook JSON — use `nbformat` Python library
- `nbformat` escapes `!` as `\!` — for cells with `!=`, use `json.load/dump` directly

### `fastcore.basics`
- `store_attr()` does NOT save `**kwargs` — use `store_attr(but='kwargs')` + `self.extra = kwargs`
- `concat` from `fastcore.all` for flattening lists of lists

### Docker on macOS (Colima / Podman Machine)
- Colima: only mounts `~/` into VM — bind mounts from `/tmp` or `/var/folders` silently fail
- Podman Machine: only mounts `$HOME` — same restriction
- Always use paths under `~/` for Docker bind mounts in tests

### SWAG patterns
- Use `proxy.conf` not `default.conf` (SWAG creates `default.conf` as directory)
- DuckDNS: use `subdomains=''` (wildcard doesn't cover bare domain in SWAG)

### Caddyfile env var syntax
- Caddy: `{$VAR_NAME}` (e.g., `acme_dns cloudflare {$CLOUDFLARE_API_TOKEN}`)
- Docker Compose env substitution: `${VAR_NAME}` (different!)

## Runtime Support
- Default: `docker` CLI via subprocess
- Podman: set `DOCKR_RUNTIME=podman` — all CLI calls use podman transparently
- `_clean_cfg()` (credential stripping) only runs for Docker, skipped for other runtimes
- Dockerfile/Compose YAML are already runtime-agnostic

## Dependencies
- Runtime: `fastcore>=1.12.14`, `pyyaml>=6.0`
- Dev: `nbdev>=2.3.0`, `pytest>=8.0.0`
- No docker-py or podman-py — subprocess only
