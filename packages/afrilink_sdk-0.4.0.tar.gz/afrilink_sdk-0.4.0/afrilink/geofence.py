"""
AfriLink Geofence Module

Restricts SDK usage to users physically located in Africa.
Uses IP-based geolocation via free public APIs to determine
the user's continent. The check runs at authentication time
and blocks non-African traffic even if DataSpires credentials
are valid.

No external dependencies required — uses stdlib urllib.
"""

import os
import json
from typing import Tuple, Optional

try:
    import requests as _requests
except ImportError:
    _requests = None
    import urllib.request
    import urllib.error


# ISO 3166-1 alpha-2 codes for African countries
AFRICAN_COUNTRY_CODES = {
    "DZ", "AO", "BJ", "BW", "BF", "BI", "CV", "CM", "CF", "TD",
    "KM", "CG", "CD", "CI", "DJ", "EG", "GQ", "ER", "SZ", "ET",
    "GA", "GM", "GH", "GN", "GW", "KE", "LS", "LR", "LY", "MG",
    "MW", "ML", "MR", "MU", "YT", "MA", "MZ", "NA", "NE", "NG",
    "RE", "RW", "ST", "SN", "SC", "SL", "SO", "ZA", "SS", "SD",
    "TZ", "TG", "TN", "UG", "EH", "ZM", "ZW",
}


def _fetch_json(url: str, timeout: int = 10) -> Optional[dict]:
    """Fetch JSON from a URL using requests or urllib."""
    try:
        if _requests:
            resp = _requests.get(url, timeout=timeout)
            if resp.status_code == 200:
                return resp.json()
            return None
        else:
            req = urllib.request.Request(url)
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.loads(resp.read().decode("utf-8"))
    except Exception:
        return None


def check_geofence() -> Tuple[bool, str, Optional[str]]:
    """
    Check whether the current user is located in Africa.

    Tries multiple free geolocation APIs in order. Each returns the
    user's country code; we check it against AFRICAN_COUNTRY_CODES.

    Returns:
        Tuple of (is_allowed, country_code_or_error, continent)
            - is_allowed: True if the user is in Africa
            - country_code_or_error: 2-letter country code, or error message
            - continent: continent name if available, else None
    """
    # Allow override for testing / development
    if os.environ.get("AFRILINK_SKIP_GEOFENCE", "").lower() in ("1", "true", "yes"):
        return True, "SKIP", "override"

    # ── Strategy 1: ip-api.com (no key needed, 45 req/min) ──
    data = _fetch_json("http://ip-api.com/json/?fields=status,countryCode,continent")
    if data and data.get("status") == "success":
        cc = data.get("countryCode", "")
        continent = data.get("continent", "")
        return cc in AFRICAN_COUNTRY_CODES, cc, continent

    # ── Strategy 2: ipapi.co (no key needed, 1000/day) ──
    data = _fetch_json("https://ipapi.co/json/")
    if data and "country_code" in data:
        cc = data["country_code"]
        continent = data.get("continent_code", "")
        return cc in AFRICAN_COUNTRY_CODES, cc, continent

    # ── Strategy 3: ipinfo.io (no key needed, 50k/month) ──
    data = _fetch_json("https://ipinfo.io/json")
    if data and "country" in data:
        cc = data["country"]
        # ipinfo doesn't return continent, infer from country code
        return cc in AFRICAN_COUNTRY_CODES, cc, None

    # All APIs failed — fail open with a warning rather than blocking
    # This prevents legitimate African users from being locked out
    # due to transient network issues with geolocation services
    return True, "UNKNOWN", None


class GeofenceError(Exception):
    """Raised when SDK usage is attempted outside of Africa."""

    def __init__(self, country_code: str, continent: Optional[str] = None):
        self.country_code = country_code
        self.continent = continent
        location = f"{country_code}"
        if continent:
            location += f" ({continent})"
        super().__init__(
            f"\n{'='*60}\n"
            f"  AfriLink SDK — Access Restricted\n"
            f"{'='*60}\n\n"
            f"  Your current location ({location}) is outside Africa.\n\n"
            f"  The AfriLink SDK is exclusively available to users\n"
            f"  accessing it from the African continent.\n\n"
            f"  If you believe this is an error, please contact\n"
            f"  support@dataspires.com\n"
            f"{'='*60}"
        )


def enforce_geofence():
    """
    Enforce the Africa geofence. Raises GeofenceError if the user
    is not located in Africa.

    Called during client.authenticate() before any credentials are
    processed.
    """
    allowed, cc, continent = check_geofence()
    if not allowed:
        raise GeofenceError(cc, continent)
    return cc, continent
