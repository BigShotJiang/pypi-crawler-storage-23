from setuptools import setup, find_packages

setup(
    name="orze",
    version="1.10.2",
    packages=find_packages(),
    install_requires=[
        "torch",
        "torchvision",
        "pyyaml",
        "requests",
        "tqdm",
    ],
    author="orze contributors",
    description="GPU experiment orchestrator using filesystem coordination",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    license="Apache-2.0",
    python_requires=">=3.8",
)
