"""Prompts module for Ultimate Gemini MCP."""

from .image_prompts import register_image_prompts

__all__ = ["register_image_prompts"]
