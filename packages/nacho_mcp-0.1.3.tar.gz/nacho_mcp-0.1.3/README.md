# nacho-mcp

MCP server for [Nacho](https://nacho.bot) — search, pull, and install context files in your AI assistant.

## Usage

This server is installed automatically when you run `nacho init`. To add it manually:

```bash
nacho init
```

## Links

- [nacho.bot](https://nacho.bot)
- [Documentation](https://nacho.bot/docs)
- [Repository](https://github.com/DevJoy-Studio-LLC/nacho)
