from mcp.server.fastmcp import FastMCP

from nacho_mcp.tools import info, init, install, pull, search

mcp = FastMCP("nacho")


@mcp.tool()
def nacho_search(query: str = "", tags: str = "", sort: str = "relevance", page: int = 1) -> str:
    """Search for contexts on Nacho by keyword or tags.

    Args:
        query: Search keywords (e.g. "fastapi react", "golang cli")
        tags: Comma-separated tag filter (e.g. "python,react")
        sort: Sort order — relevance, newest, downloads, upvotes, or updated
        page: Page number for pagination
    """
    return search(query=query, tags=tags, sort=sort, page=page)


@mcp.tool()
def nacho_info(ref: str) -> str:
    """Get detailed info about a Nacho context including description, tags, versions, and stats.

    Args:
        ref: Context reference in username/context-name format (e.g. "nacho/fastapi-react")
    """
    return info(ref=ref)


@mcp.tool()
def nacho_pull(ref: str, version: int | None = None) -> str:
    """Download the raw markdown content of a Nacho context.

    Args:
        ref: Context reference in username/context-name format
        version: Specific version number to download (latest if omitted)
    """
    return pull(ref=ref, version=version)


@mcp.tool()
def nacho_install(ref: str, version: int | None = None) -> str:
    """Install a Nacho context as project instructions. Downloads the context and writes it to AGENTS.md (the universal agent instructions file). If your provider is set to "claude" (via `nacho config set provider claude`), also creates a CLAUDE.md stub that imports AGENTS.md so Claude Code picks it up automatically.

    Args:
        ref: Context reference in username/context-name format
        version: Specific version number to install (latest if omitted)
    """
    return install(ref=ref, version=version)


@mcp.tool()
def nacho_init(project_description: str, tags: str = "") -> str:
    """Find Nacho contexts matching a project description. Returns the top matches for the user to choose from, then they can install with nacho_install.

    Args:
        project_description: Description of the project to build (e.g. "Python FastAPI backend with auth and Postgres")
        tags: Optional comma-separated tags to narrow results (e.g. "python,fastapi")
    """
    return init(project_description=project_description, tags=tags)


def main():
    mcp.run(transport="stdio")
