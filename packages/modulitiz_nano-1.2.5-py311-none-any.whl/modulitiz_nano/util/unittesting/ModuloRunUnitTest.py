import os
import pkgutil
import shutil
import unittest

import coverage

from modulitiz_nano.ModuloColorText import ModuloColorText
from modulitiz_nano.files.ModuloFiles import ModuloFiles


class ModuloRunUnitTest(object):
	PATTERN_TO_PRINT="""{}
	==================================================
			{}
	==================================================
	"""+ModuloColorText.DEFAULT
	
	@classmethod
	def startTests(cls,currentFilePath:str,collectCoverage:bool)->bool:
		currentPath=os.path.dirname(currentFilePath)
		suite=cls.__createTestSuite(currentPath)
		print("Starting tests...")
		runner=unittest.TextTestRunner(verbosity=2)
		if collectCoverage:
			modulePath=ModuloFiles.normalizzaSlashPath(ModuloFiles.pathJoin(currentPath,"../../"))
			coverageDbPath=ModuloFiles.pathJoin(modulePath,".coverageDb")
			rootPath=ModuloFiles.normalizzaSlashPath(ModuloFiles.pathJoin(modulePath,"../"))
			cov=coverage.Coverage(data_file=coverageDbPath,source=[rootPath])
			cov.start()
			result=runner.run(suite)
			cov.stop()
			cov.save()
			coverageOutDir=ModuloFiles.pathJoin(modulePath,".coverage")
			if os.path.exists(coverageOutDir):
				shutil.rmtree(coverageOutDir)
			coveragePerc=cov.html_report(directory=coverageOutDir)
			if ModuloFiles.getFileSize(coverageDbPath)>=0:
				os.remove(coverageDbPath)
			coveragePerc=int(coveragePerc)
			msgCoverage=f" with coverage at {coveragePerc}%"
		else:
			result=runner.run(suite)
			msgCoverage=""
		isSuccess=result.wasSuccessful()
		if isSuccess:
			print(cls.PATTERN_TO_PRINT.format(ModuloColorText.VERDE,"Tests completed successfully"+msgCoverage))
		else:
			print(cls.PATTERN_TO_PRINT.format(ModuloColorText.ROSSO,"Errors during tests execution"))
		return isSuccess
	
	@staticmethod
	def __createTestSuite(currentPath:str)->unittest.TestSuite:
		paths = [x[0] for x in os.walk(currentPath)]
		paths=[x for x in paths if not os.path.basename(x).startswith("__")]
		testLoader=unittest.TestLoader()
		suite=unittest.TestSuite()
		for modInfo in pkgutil.walk_packages(paths):
			modFinder=modInfo.module_finder
			modName=modInfo.name
			spec=modFinder.find_spec(modName)
			loader=spec.loader
			module=loader.load_module(modName)
			# carico ogni test presente in un modulo
			for tests in testLoader.loadTestsFromModule(module):
				if tests.countTestCases()!=0:
					suite.addTests(tests)
		return suite
