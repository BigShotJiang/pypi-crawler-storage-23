import traceback

from modulitiz_nano.ModuloListe import ModuloListe


class ExceptionUtil(object):
	
	@staticmethod
	def toString(exception)->str:
		try:
			rows=traceback.format_exception(exception)
			rows=ModuloListe.eliminaElementiVuoti(rows)
			return "".join(rows)
		except Exception as e2:
			return "Parsing %s causes %s"%(exception,e2)
