class CacheBean(object):
	def __init__(self,valore,dataLastUpdate):
		self.valore=valore
		self.dataLastUpdate=dataLastUpdate
	
