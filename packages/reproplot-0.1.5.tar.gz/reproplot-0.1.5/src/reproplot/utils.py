"""
utilitary functions
"""
import os
import copy
import json
import pickle
from itertools import product
import subprocess
import __main__
from types import FunctionType
from typing import Callable


def dump_json(py_object, path, indent=0):
    """ save object in json file
    Args:
        - py_object : python object to save
        - path (str) : path where to save the object
        - indent (int) : indent level to use (for readability)
    """
    with open(path, "w") as outfile:
        json.dump(py_object, outfile, indent=indent)


def load_json(path):
    """ load object from json file
    Args:
        - path (str) : path where to save the object
    """
    with open(path, 'r') as openfile:
        return json.load(openfile)


def dump_pickle(py_object, path):
    """ save object in pickle file
    Args:
        - py_object : python object to save
        - path (str) : path where to save the object
    """
    with open(path, "wb") as outfile:
        pickle.dump(py_object, outfile)


def load_pickle(path):
    """ load object from pickle file
    Args:
        - path (str) : path where to save the object
    """
    with open(path, 'rb') as openfile:
        return pickle.load(openfile)


def make_grid(block: dict[str, list]):
    """ build iterator over different combination of params (gridsearch)
    Args:
        block: block of parameters (dictionnary of {"param_name": list of values})

    Yields:
        dictionnary of {"param_name": value (or [value])}
    """
    for params in product(*block.values()):
        yield {key: param for key, param in zip(block.keys(), params)}


def make_meta_grid(config_blocks: dict[str, dict[str, list]]):
    """ build iterator on all configs from config dict

    config_blocks: all configuration
    {"_default_params": {"par1": [3]}, "diff_lines_params": {"par2": [2,3]}}

    Yields:
        All experiment configurations (dicts)
    """
    config_blocks = copy.copy(config_blocks)
    flattened = {key: val for block_name, block in config_blocks.items()
                 for key, val in block.items()}
    for params in make_grid(flattened):
        yield params


def count_combinations(list_dic):
    """ count number of parameter combinations

    Args:
        - list_dic : dictionnary of {"par1": list of values}

    Returns:
        - (int) number of possible parameter combinations
    """
    nb = 1
    for _, params in list_dic.items():
        nb *= len(params)
    return nb


def update_params(params: dict, *updates) -> dict:
    """ add new parameters or replace existing ones
    Args:
        - params   : dictionnary of parameters
        - *updates : dictionnaries of additionnal parameters
    Return:
         - (dict) updated dictionnary of parameters
    """
    paramsall = params.copy()
    for new_params in updates:
        paramsall.update(new_params)
    return paramsall


def make_exp_name(params, nametag, tags_list):
    """ create experiment name
    Args:
        - params : dictionnary of {"par1": value}
        - nametag (str) : prefix to identify experiment series
        - tag_list (str list) : list of params to put in experiment name

    Returns:
        - (str) experiment name
    """
    exp_name = nametag
    for name in tags_list:
        if name[0] != "_":
            exp_name += f"-{name}_{params[name]}"
    return exp_name


def make_plot_name(params, nametag, metric, tags_list):
    """" result should depend on diff_plot
    Args:
        - params : dictionnary of {"par1": value}
        - nametag (str) : prefix to identify experiment series
        - metric (str) : metric plotted
        - tag_list (str list) : list of param names to put in experiment name

    Returns:
        - (str) plot name
    """
    plot_name = f"{nametag}-{metric}"
    for name in tags_list:
        plot_name += f"-{name}_{params[name]}"
    return plot_name


def map_display_names(param_names: list[str], displayed_names: Callable[[str], str] | dict[str, str] | None = None) -> dict[str, str]:
    """ map param names to their display names """
    if displayed_names is None:
        display = {name: name for name in param_names}
    elif isinstance(displayed_names, dict):
        display = {name: displayed_names.get(
            name, name) for name in param_names}
    else:  # if displayed_names is a function
        display = {name: displayed_names(name) for name in param_names}
    return display


def make_title(params: dict, tags_list: list, seeds: list, displayed_names) -> str:
    """
    Args:
        - params : dictionnary of {"par1": value}
        - tags_list (str list) : list of param names to put in experiment name
        - seeds: list of seeds used in the experiment

    Returns:
        - (str) plot title
    """
    param_names = list(params)
    display = map_display_names(param_names, displayed_names)
    if len(tags_list) == 0:
        return "X"
    title = ""
    for name in tags_list:
        if len(title):
            title += ", "
        title += f"{display[name]}={params[name]}"
    title += f"       ({str(len(seeds))} seeds)"
    return title


def make_legend(params: dict, displayed_names: Callable[[str], str] | dict[str, str] | None = None) -> str:
    """ Create a legend from parameters

    Args:
        params: dictionnary of {"parameter_name": value}
        displayed_names: function or dict returning the displayed string from the param name

    Returns:
        legend
    """
    param_names = list(params)
    display = map_display_names(param_names, displayed_names)
    legend = f"{display[param_names[0]]}={params[param_names[0]]}"
    for name in param_names[1:]:
        legend += f", {display[name]}={params[name]}"
    return legend


def check_compatibility(params_config: dict, exp_tags: list[str]) -> None:
    """ check if the same name is generated twice
    Args:
        params_config: all experiment parameters
        exp_tags : list of parameters to put in experiment names
    """
    for block_name, block in params_config.items():
        if block_name[0] != "_":
            for param in block.keys():
                if param not in exp_tags:
                    print(
                        f"WARNING : Experiment names should depend on -{param} to avoid having the same name")


def scan_runs(
        res_dir: str, dir_path: str,
        nametag: str = "",
        config_grid: dict = {},
        exp_tags=None, set_depending_params=lambda x: None
) -> tuple[int, int, list[str]]:
    """ finds existing and missing runs
    res_dir: name of the directory where to store results as json
    dir_path: path to directory containing -res_dir
    nametag: prefix that identifies the series of experiments
    config_grid: all parameters of the experiment
    exp_tags: list of parameters to put in experiment names
    set_depending_params: function editing in-place a dictionnary of parameters

    Return:
        count_done: number of runs already ran
        count_total: number of total runs required
        confs_paths: paths of runs to be run
    """
    confs_paths = []
    count_done, count_total = 0, 0
    for params in make_grid(clean_config(config_grid)):
        set_depending_params(params)
        exp_name = make_exp_name(params, nametag, exp_tags)
        exp_dir = f"{dir_path}/{res_dir}/{exp_name}/"
        for seed in config_grid["_seed"]:
            path = exp_dir + f"seed_{seed}/"
            if os.path.isdir(path):
                count_done += 1
            else:
                confs_paths.append((params.copy(), path))
            count_total += 1
    return count_done, count_total, confs_paths


def get_git_hash() -> str:
    """ return current git hash (empty string if no git repo)"""
    command = "git rev-parse HEAD"
    try:
        git_hash = subprocess.check_output(command, shell=True, text=True)
    except subprocess.CalledProcessError:
        print("Could not access git commit, putting empty hash")
        git_hash = ""
    return git_hash


def flatten_list(matrix: list[list]) -> list:
    """ flatten a list of lists """
    flat_list = []
    for row in matrix:
        flat_list.extend(row)
    return flat_list


def flatten_dict(dic: dict[str, dict]) -> dict:
    """ flatten a dictionnary of dictionnaries """
    return {key: value for dic1 in dic.values() for key, value in dic1.items()}


def clean_config(config: dict) -> dict:
    """ 'clean' the config by removing parameters with leading _ """
    return {key: val for key, val in config.items() if key[0] != "_"}


def put_in_list(params: dict):
    """ put parameters in singletons lists """
    return {key: [value] for key, value in params.items()}


def get_main_dir() -> str:
    """ return path of directory containing main file """
    return str(os.path.dirname(os.path.realpath(__main__.__file__)))
