"""
Functions to handle the experiments pipeline
"""

import os
import random
from tqdm import tqdm
from types import FunctionType
from collections.abc import Iterable, Sequence

from .utils import load_json, make_exp_name, check_compatibility, flatten_dict
from .reprod_exps import run_experiments
from .reprod_plots import plot_experiments


def rename_exps(directory: str, new_tag: str, new_exp_tags: list[str], old_tag: str | None = None) -> None:
    """rename experiment names using parameters saved
    Args:
        directory: directory of experiments
        new_tag: new prefix for experiment names
        new_exp_tags: new names of metrics to put in experiment names
        old_tag: specify to rename only experiments with that tag
    """
    print("Renaming experiments of directory :", directory)
    exp_names_paths = [(f.name, f.path)
                       for f in os.scandir(directory) if f.is_dir()]
    counter = 0
    for exp_name, exp_path in exp_names_paths:
        prefix_cond = True
        if old_tag is not None:
            prefix = exp_name.split("-")[0]
            prefix_cond = prefix == old_tag
        if prefix_cond:
            params = load_json(exp_path + "/params.json")
            exp_name_new = make_exp_name(
                params, new_tag, tags_list=new_exp_tags)
            os.rename(exp_path, directory + "/" + exp_name_new)
            counter += 1
            print("renaming:", exp_name, "\n into: ", exp_name_new)
    print(f"Renamed {counter} experiments")


def index_exps(directory: str, nametag: str | None = None, param_requirements: FunctionType | None = None) -> None:
    """gives a summary of available experiments
    Args:
        directory: directory of experiments
        nametag: specify to see only experiments with that tag
        param_requirements: function taking params as input
                    and outputing True if this experiment should be included
    """
    exp_names_paths = [(f.name, f.path)
                       for f in os.scandir(directory) if f.is_dir()]
    all_params = {}
    seeds = set()
    nb_runs, nb_exps = 0, 0
    for exp_name, exp_path in tqdm(exp_names_paths):
        loaded_params = load_json(exp_path + "/params.json")
        select = True
        if param_requirements is not None:
            select = param_requirements(loaded_params)
        if nametag is not None:
            prefix = exp_name.split("-")[0]
            select = select and (prefix == nametag)
        if select:
            nb_exps += 1
            for name, value in loaded_params.items():
                if type(value) is list:
                    value = tuple(value)
                if name in all_params:
                    all_params[name].add(value)
                else:
                    all_params[name] = {value}
            for seed_name in [f.name for f in os.scandir(exp_path) if f.is_dir()]:
                if "failed" not in seed_name:
                    seed = int(seed_name[5:])
                    seeds.add(seed)
                    nb_runs += 1
    print(
        f"found {nb_runs} runs grouped in {nb_exps}/{len(exp_names_paths)} experiments with parameters :"
    )

    def _custom_key(obj):
        if obj is None:
            return 0
        elif type(obj) is int or float:
            return obj
        else:
            return len(obj)

    for name, values in all_params.items():
        print(name, sorted(values, key=_custom_key))
    print("seeds", sorted(seeds))


def run_and_plot(
    experiment_func: FunctionType,
    x_axis_params: dict,
    diff_lines_params: dict = {},
    diff_rows_params: dict = {},
    diff_cols_params: dict = {},
    diff_plots_params: dict = {},
    default_params: dict = {},
    seeds: Iterable[int] = [],
    # --- paths --
    res_dir: str = "results_RPP",
    plot_dir: str = "plots_RPP",
    nametag: str = "",
    exp_tags: list = [],
    # ---- data manipulation --
    set_depending_params: FunctionType = lambda x: None,
    # --- plotting params ----
    plot_type="lines",
    custom_names: dict = {},
    plt_hook: FunctionType = lambda: None,
    # -- misc
    verb: Sequence[str] = ["pbar"],
    no_run: bool = False,
    no_plot: bool = False,
    ignore_missing: bool = False,
    config_watermark: dict = {},
    **plot_kwargs
) -> None:
    """run and plot experiments by using all hyperparameters in a grid-search fashion
    Args:
        experiment_func: function to call for each run
        x_axis_params: dict,
        diff_lines_params: one parameter value per line
        diff_rows_params: one parameter value per row
        diff_cols_params: one parameter value per column
        diff_plots_params: one parameter value per plot
        default_params: default parameters
        seeds: seeds of runs to plot
        res_dir: directory containing the data to plot
        plot_dir: directory where to save the plot
        nametag: prefix identifying the series of experiments
        exp_tags: list of parameters used in experiment names
        set_depending_params: function editing in-place a dictionnary of parameters
        plot_type: name of type of plot to use
        custom_names: dictionnary of labels or functions to apply to labels
        plt_hook: function to apply just before saving the plot
        verb: string codes to indicate verbose
        no_run: True to disable running new experiments
        no_plot: True to disable plotting
        ignore_missing: True to plot despite missing data
        config_watermark: dictionnary of all parameters passed as input used for watermarking (optional)
        **plot_kwargs: keyword arguments for specific plot types
    """
    if seeds == []:
        seeds = [random.randint(1, 99999)]
        print(f"No seeds specified, using random seed {seeds[0]}")

    # the  order of the dict entries matters
    config_blocks = {
        "_default_params": {key: [val] for key, val in default_params.items()},
        "diff_plots_params": diff_plots_params,
        "diff_rows_params": diff_rows_params,
        "diff_cols_params": diff_cols_params,
        "diff_lines_params": diff_lines_params,
        "x_axis_params": x_axis_params,
        "_seeds_block": {"_seed": seeds},
    }

    if exp_tags == []:
        for block_name, block in config_blocks.items():
            if block_name[0] != "_":
                exp_tags += list(block.keys())
        exp_tags = sorted(exp_tags)

    check_compatibility(config_blocks, exp_tags)

    config_grid = flatten_dict(config_blocks)
    if not no_run:
        run_experiments(
            experiment_func=experiment_func,
            res_dir=res_dir,
            # seeds=seeds,
            nametag=nametag,
            config_grid=config_grid,
            exp_tags=exp_tags,
            set_depending_params=set_depending_params,
            verb=verb,
        )

    plot_path_config = {"res_dir": res_dir, "plot_dir": plot_dir,
                        "nametag": nametag, "exp_tags": exp_tags}

    if not no_plot:
        plot_experiments(
            path_config=plot_path_config,
            config_blocks=config_blocks,
            set_depending_params=set_depending_params,
            ignore_missing=ignore_missing,
            plot_type=plot_type,
            custom_names=custom_names,
            plt_hook=plt_hook,
            config_watermark=config_watermark,
            **plot_kwargs,
        )


def run_and_plot_wrap(**config_watermark):
    run_and_plot(**config_watermark, config_watermark=config_watermark)
