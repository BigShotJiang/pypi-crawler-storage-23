import os
import copy
from types import FunctionType

import numpy as np

from .utils import (
    get_git_hash,
    get_main_dir,
    load_json,
    make_exp_name,
    make_grid,
    make_legend,
    make_plot_name,
    make_title,
    flatten_list,
    flatten_dict,
    put_in_list
)


from .plotting import ExpPlot


def _load_one_point(params: dict, res_dir: str, nametag: str, exp_tags: list[str], ignore_missing: bool) -> float | int:
    """ load values of the metrics for all seeds for one parameter combination

    params: all parameters including _metric, and _seed e.g. {'_metric': 'error', '_seed': 3,  'noise': 0.1}
    res_dir: directory containing the data to plot
    metrics: the list of metrics

    Return
        value or  np.nan
    """
    def _handle_missing(ignore_missing, path):
        if ignore_missing:
            print(f"{path} not found, plotting without it.")
        else:
            raise Exception(
                "{} not found, use ignore_missing=True to plot anyway".format(
                    path)
            )
    metric = params["_metric"]
    seed = params["_seed"]
    exp_name = make_exp_name(params, nametag, exp_tags)
    exp_dir = f"{get_main_dir()}/{res_dir}/{exp_name}/"
    path = exp_dir + f"seed_{seed}/"
    try:
        value = load_json(path + "metrics.json")[metric]
        # implicitely taking value at end of training
        if type(value) is list:
            value = value[-1]
    except OSError:
        _handle_missing(ignore_missing, path)
        value = np.nan
    return value


class DataGrid():
    """ a tensor containing metrics for all parameter combinations and seeds, plus information on the parameters (default parameters are handled separately)


    self.tensor[i][j][k] is the value for parameters param_names
    """

    def __init__(self, config_grid: dict[str, list]):
        """
        config_grid: {"<param_name>": [value1, value2], ..}
        """
        shape = [len(param_list) for param_list in config_grid.values()]
        self.tensor = np.zeros(shape)
        self.config_grid = config_grid

    def __str__(self):
        infos = f"config_grid: {self.config_grid}"
        infos += f"\ntensor: {self.tensor}"
        infos += f"\ntensor shape: {self.tensor.shape}"
        infos += f"\ncorresponding parameters: {list(self.config_grid)}"
        return infos

    def load_grid_(self, res_dir: str, nametag: str, exp_tags: list[str], ignore_missing: bool = False):
        """ load the data from the path into self.tensor """
        config_clean = self.config_grid
        index_grid = {param_name: list(range(len(param_list)))
                      for param_name, param_list in config_clean.items()}
        for indexes_dic, config in zip(make_grid(index_grid), make_grid(config_clean)):
            value = _load_one_point(
                config, res_dir, nametag, exp_tags, ignore_missing)
            indexes = list(indexes_dic.values())
            self.tensor[*indexes] = value

    def format_data(self, block_struct: dict[str, list[str]]) -> np.ndarray:
        """ return the tensor formatted for plotting

        structure: {
        # "diff_lines": ["<param_name>",...],
        "diff_rows": ["<param_name>"],
        # "_seeds_block: {["_seed"]},
            }

        Returns:
            tensor of values of the metric, ndim of 6:
            (n_rows, n_cols, n_lines, n_xvals, n_seeds)
        """
        # finding sizes of blocks and target indexes
        reorder_indexes = []
        final_block_sizes = []
        for blockname, param_names in block_struct.items():
            block_indexes = []
            block_size = 1
            for param_name in param_names:
                param_index = list(self.config_grid).index(param_name)
                block_indexes.append(param_index)
                block_size *= len(self.config_grid[param_name])
            reorder_indexes.append(block_indexes)
            if blockname not in ["_default_params", "_this_plot_params"]:
                final_block_sizes.append(block_size)
        # formatting
        tensor = self.tensor
        tensor = np.moveaxis(tensor, flatten_list(
            reorder_indexes), range(len(self.config_grid)))
        tensor = tensor.reshape(final_block_sizes)
        return tensor

    # def save(self, path: str):
    #     """ save the DataGrid as a json? csv? pickle?? """
    #     pass
    #
    # def load(self, path: str):
    #     """ load the DataGrid  """
    #     pass


class PlotConf():
    """ configuration for a plot containing the data and information to plot the data"""

    def __init__(self,
                 params_config: dict,
                 set_depending_params: FunctionType,
                 plot_type: str,
                 title: str,
                 savepath: str,
                 ):
        self.set_depending_params = set_depending_params
        self.title = title
        self.savepath = savepath
        self.plot_type = plot_type

        self.params_config = params_config
        self.datagrid = DataGrid(flatten_dict(params_config))

    def __str__(self):
        infos = f"title: {self.title}"
        infos += f"\nsavepath: {self.savepath}"
        infos += f"\nplot_type: {self.plot_type}"
        infos += f"\nparams_config: {self.params_config}"
        infos += f"\ndatagrid shape: {self.datagrid.tensor.shape}"
        return infos

    # def load_data(
    #         self, res_dir: str, metrics: list[str], nametag: str, exp_tags: list[str],
    #         ignore_missing: bool = False):
    #     """ load the data in the DataGrid self.tensor"""
    #     self.datagrid.load_grid_(res_dir, nametag, exp_tags,
    #                              metrics, ignore_missing)

    def plot(self, custom_names, plt_hook: FunctionType,
             config_watermark: dict = {}, **plot_kwargs
             ):
        """ plot the data in the DataGrid according to the instructions """
        displayed_names = plot_kwargs.get("displayed_names", None)
        params_config = self.params_config
        structure = {block_name: list(block_params) for block_name,
                     block_params in params_config.items()
                     if block_name != "diff_plots_params"}
        plot_array = self.datagrid.format_data(
            structure)
        if "_metric" in params_config["_this_plot_params"]:
            ylab = params_config["_this_plot_params"]["_metric"][0]
        else:
            ylab = ""
        xlab, _ = list(params_config["x_axis_params"].items())[0]
        linelabs, rowlabs, collabs = [], [], []
        for params in make_grid(params_config["diff_lines_params"]):
            linelabs.append(make_legend(params, displayed_names))
        for params in make_grid(params_config["diff_rows_params"]):
            rowlabs.append(make_legend(params, displayed_names))
        for params in make_grid(params_config["diff_cols_params"]):
            collabs.append(make_legend(params, displayed_names))

        labels = {"title": self.title,
                  "ylab": ylab, "xlab": xlab,
                  "rows": rowlabs, "cols": collabs,
                  "x_vals": list(params_config["x_axis_params"].values())[0],
                  }
        if self.plot_type == "lines":
            labels["lines"] = linelabs
        elif self.plot_type == "heatmap":
            labels["y_vals"] = list(
                params_config["diff_lines_params"].values())[0]
        # apply custom labels
        for key, val in custom_names.items():
            if type(val) is type(labels[key]):
                labels[key] = val
            elif type(val) is FunctionType:
                labels[key] = val(labels[key])
            else:
                print(f"WARNING: Type error for custom name {key}")
        if config_watermark != {}:
            watermarks = ["config:" + str(config_watermark),
                          "git commit:" + get_git_hash()]
        else:
            watermarks = []
        exp_plot = ExpPlot(plot_type=self.plot_type)
        exp_plot.plot(array=plot_array, savepath=self.savepath,
                      labels=labels, plt_hook=plt_hook, watermarks=watermarks, **plot_kwargs)


def plot_experiments(
    path_config: dict,
    config_blocks: dict[str, dict[str, list]],
    set_depending_params: FunctionType,
    ignore_missing: bool,
    plot_type: str,
    custom_names: dict[str, FunctionType],
    config_watermark: dict = {},
    plt_hook: FunctionType = lambda: None,
    **plot_kwargs
):
    """ plot the experiments """
    plot_dir_path = get_main_dir() + "/" + path_config["plot_dir"]
    os.makedirs(plot_dir_path, exist_ok=True)
    for thisplot_params in make_grid(config_blocks["diff_plots_params"]):
        params_config_thisplot = copy.deepcopy(config_blocks)
        # params of this plot are not a block anymore
        del params_config_thisplot["diff_plots_params"]
        params_config_thisplot["_this_plot_params"] = put_in_list(
            thisplot_params)
        plot_tags = list(params_config_thisplot["_this_plot_params"].keys())
        title = make_title(thisplot_params, plot_tags, params_config_thisplot["_seeds_block"]["_seed"],
                           plot_kwargs.get("displayed_names", None))
        filename = make_plot_name(
            thisplot_params, path_config["nametag"], "temp_metric_name", plot_tags)
        savepath = f"{plot_dir_path}/{filename}"
        plot_conf = PlotConf(
            params_config_thisplot,
            set_depending_params,
            plot_type,
            title,
            savepath,
        )
        plot_conf.datagrid.load_grid_(
            path_config["res_dir"], path_config["nametag"], path_config["exp_tags"], ignore_missing)
        plot_conf.plot(
            custom_names=custom_names,
            config_watermark=config_watermark, plt_hook=plt_hook, **plot_kwargs)
