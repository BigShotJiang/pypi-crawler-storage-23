from types import FunctionType
from collections.abc import Iterable

import numpy as np
from matplotlib import pyplot as plt

from .utils import get_git_hash


def _finalize_plot(fig, axs, title, xlab, ylab, savepath, extension="pdf", fontsize="11", show=False, watermarks: list = [], plt_hook=lambda x, y: None, **kwargs):
    fig.suptitle(title, wrap=True)
    fig.supxlabel(xlab, size=fontsize)
    fig.supylabel(ylab, size=fontsize)
    # for ax in axs[-1, :]:
    #     ax.set_xlabel(xlab, size=fontsize)
    # for ax in axs[:, 0]:
    #     ax.set_ylabel(ylab, size=fontsize)
    # plt.xlabel(xlab, size=fontsize)
    # plt.ylabel(ylab, size=fontsize)
    # plt.tick_params(axis='both', which='both', labelsize=fontsize)
    # plt.gca().xaxis.offsetText.set_fontsize(fontsize)
    # plt.gca().yaxis.offsetText.set_fontsize(fontsize)
    for i, text in enumerate(watermarks):
        plt.text(0, 0.01 * i, text, fontsize=1, alpha=0,
                 transform=plt.gcf().transFigure,
                 ha='left', va='bottom')
    fig.tight_layout()
    plt_hook(fig, axs)
    if savepath is not None:
        fig.savefig(f"{savepath}.{extension}")
    if show:
        plt.show()
    plt.close()


colors = ["blue", "red", "green", "orange"] * 1000
linestyles = ["-", "--", ":", "-."] * 1000


class ExpPlot():
    """ contains information and methods specific to a plot type """

    def __init__(self, plot_type: str):
        self.plot_type = plot_type
        self.registered_types = {
            "lines": self._plot_lines,
            "heatmap": self._plot_heatmap,
            "custom_subplot": self._plot_custom_subplot,
        }

    def plot(self, **kwargs):
        self.registered_types[self.plot_type](**kwargs)

    def _plot_lines(self, array: np.ndarray,
                    labels: dict,
                    savepath: str | None = None,
                    plt_hook=lambda x, y: None,
                    std=False, confidence=True,
                    **kwargs,
                    ):
        """ plots a line plot """
        n_rows, n_cols, n_lines, n_x_values, n_seeds = array.shape
        fig, axs = plt.subplots(
            int(n_rows), n_cols, sharey=True, sharex=True, squeeze=False)
        arr_mean = np.nanmean(array, axis=-1)  # average on seeds
        arr_std = np.nanstd(array, axis=-1)  # std on seeds

        for row, row_axes in enumerate(axs):
            for col, ax in enumerate(row_axes):
                if row == n_rows - 1:
                    ax.set_xlabel(labels["cols"][col])
                if col == 0:
                    ax.set_ylabel(labels["rows"][row])
                style_iter = zip(colors, linestyles)
                for line_idx, (line_mean, line_lab) in enumerate(zip(arr_mean[row][col], labels["lines"])):
                    color, linestyle = next(style_iter)
                    if line_lab[0] == "_":
                        line_lab = line_lab[1:]
                    axs[row, col].plot(
                        # 1 metric
                        labels["x_vals"], line_mean, label=line_lab, color=color, linestyle=linestyle)
                    if std:
                        line_stds = arr_std[row][col][line_idx]
                        ax.fill_between(
                            labels["x_vals"], line_mean - line_stds, line_mean + line_stds, alpha=0.1, color=color)
                    if confidence:
                        line_conf = 1.96 * \
                            arr_std[row][col][line_idx] / n_seeds**0.5
                        ax.fill_between(
                            labels["x_vals"], line_mean - line_conf, line_mean + line_conf, alpha=0.1, color=color)

                if row == col == 0:
                    ax.legend()
        _finalize_plot(fig, axs, title=labels["title"], xlab=labels["xlab"],
                       ylab=labels["ylab"], savepath=savepath, plt_hook=plt_hook, **kwargs)

    def _plot_heatmap(self, array: np.ndarray,
                      labels: dict,
                      savepath: str | None = None,
                      plt_hook=lambda x, y: None,
                      std=False, confidence=True,
                      **kwargs,
                      ):
        """ plots a heatmap plot """
        n_rows, n_cols, n_y_values, n_x_values, n_seeds = array.shape
        fig, axs = plt.subplots(
            int(n_rows), n_cols, sharey=True, sharex=True, squeeze=False)
        arr_mean = np.nanmean(array, axis=-1)  # average on seeds
        # arr_std = np.nanstd(array, axis=-1)  # std on seeds
        for row, row_axes in enumerate(axs):
            for col, ax in enumerate(row_axes):
                if row == n_rows - 1:
                    ax.set_xlabel(labels["cols"][col])
                if col == 0:
                    ax.set_ylabel(labels["rows"][row])
                # for line_idx, (line_mean, line_lab) in enumerate(zip(arr_mean[0][row][col], labels["lines"])):
                ax.pcolor(labels["x_vals"], labels["y_vals"],
                          arr_mean[row][col])
                if row == col == 0:
                    ax.legend()

        _finalize_plot(fig, axs, title=labels["title"], xlab=labels["xlab"], ylab=labels["ylab"],
                       savepath=savepath, plt_hook=plt_hook)

    def _plot_custom_subplot(self, array: np.ndarray,
                             labels: dict,
                             plot_func: FunctionType,
                             savepath: str | None = None,
                             plt_hook=lambda x, y: None,
                             **kwargs,
                             ):
        """ 
        runs plot_func() custom function for each subplot 
        """
        n_rows, n_cols, n_lines, n_x_values, n_seeds = array.shape
        fig, axs = plt.subplots(
            int(n_rows), n_cols, sharey=True, sharex=True, squeeze=False)

        for row, row_axes in enumerate(axs):
            for col, ax in enumerate(row_axes):
                if row == n_rows - 1:
                    ax.set_xlabel(labels["cols"][col])
                if col == 0:
                    ax.set_ylabel(labels["rows"][row])
                plot_func(ax, array[row][col], labels)

                if row == col == 0:
                    ax.legend()
        _finalize_plot(fig, axs, title=labels["title"], xlab=labels["xlab"], ylab=labels["ylab"],
                       savepath=savepath, plt_hook=plt_hook)
