"""结果收集器: json、html、allure、custom"""
