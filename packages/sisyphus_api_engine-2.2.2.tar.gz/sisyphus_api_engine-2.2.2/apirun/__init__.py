"""sisyphus-api-engine: YAML 驱动的接口自动化测试引擎"""

__version__ = "2.2.2"

from apirun.keyword import Keyword

__all__ = ["__version__", "Keyword"]
