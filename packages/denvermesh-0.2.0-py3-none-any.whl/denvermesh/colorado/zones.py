import enum


class Zones(enum.Enum):
    URBAN = 0
    SUBURBAN = 1
    RURAL = 2
    FRONTIER = 3
