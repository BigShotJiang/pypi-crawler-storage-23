"""Eval and provider configuration models."""

from __future__ import annotations

import os
import re
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Any, Literal, overload

if TYPE_CHECKING:
    from collections.abc import Sequence
    from pathlib import Path

    from pytest_skill_engineering.core.skill import Skill

#: Supported MCP transport types.
Transport = Literal["stdio", "sse", "streamable-http"]


class ClarificationLevel(Enum):
    """Severity level when clarification is detected."""

    INFO = "info"  # Log only, don't affect test outcome
    WARNING = "warning"  # Log and record as warning
    ERROR = "error"  # Treat as test error


@dataclass(slots=True, frozen=True)
class ClarificationDetection:
    """Configuration for detecting when an agent asks for clarification.

    When enabled, uses a judge LLM to detect if the agent is asking the user
    for clarification (e.g., \"Would you like me to...?\") instead of executing
    the requested task. This is important because agents being tested should
    act autonomously, not ask questions.

    The judge model can be the same as the agent's model (default) or a
    separate, cheaper model.

    Example:
        # Use agent's own model as judge
        Eval(
            provider=Provider(model="azure/gpt-5-mini"),
            clarification_detection=ClarificationDetection(enabled=True),
        )

        # Use a separate cheaper model as judge
        Eval(
            provider=Provider(model="azure/gpt-4.1"),
            clarification_detection=ClarificationDetection(
                enabled=True,
                level=ClarificationLevel.ERROR,
                judge_model="azure/gpt-5-mini",
            ),
        )
    """

    enabled: bool = False
    level: ClarificationLevel = ClarificationLevel.WARNING
    judge_model: str | None = None  # None = use agent's own model


class WaitStrategy(Enum):
    """Wait strategy for server startup."""

    READY = "ready"
    LOG = "log"
    TOOLS = "tools"


@dataclass(slots=True, frozen=True)
class Wait:
    """Wait configuration for server startup.

    Example:
        Wait.for_log("Server started")
        Wait.for_tools(["read_file", "write_file"])
        Wait.ready()
    """

    strategy: WaitStrategy
    pattern: str | None = None
    tools: tuple[str, ...] | None = None
    timeout_ms: int = 30000

    @classmethod
    def ready(cls, timeout_ms: int = 30000) -> Wait:
        """Wait for server to signal ready (default)."""
        return cls(strategy=WaitStrategy.READY, timeout_ms=timeout_ms)

    @classmethod
    def for_log(cls, pattern: str, timeout_ms: int = 30000) -> Wait:
        """Wait for specific log pattern in stderr."""
        return cls(strategy=WaitStrategy.LOG, pattern=pattern, timeout_ms=timeout_ms)

    @classmethod
    def for_tools(cls, tools: Sequence[str], timeout_ms: int = 30000) -> Wait:
        """Wait until specific tools are available."""
        return cls(strategy=WaitStrategy.TOOLS, tools=tuple(tools), timeout_ms=timeout_ms)


@overload
def _expand_env(value: str) -> str: ...


@overload
def _expand_env(value: None) -> None: ...


def _expand_env(value: str | None) -> str | None:
    """Expand ${VAR} patterns in string for server environment variables."""
    if value is None:
        return None
    pattern = r"\$\{([^}]+)\}"
    return re.sub(pattern, lambda m: os.environ.get(m.group(1), m.group(0)), value)


@dataclass(slots=True)
class Provider:
    """LLM provider configuration.

    Authentication is handled via standard environment variables:
    - Azure: AZURE_API_BASE + `az login` (Entra ID)
    - OpenAI: OPENAI_API_KEY
    - Anthropic: ANTHROPIC_API_KEY

    See https://ai.pydantic.dev/models/ for supported providers.

    Example:
        Provider(model="openai/gpt-4o-mini")
        Provider(model="azure/gpt-5-mini", temperature=0.7)
        Provider(model="azure/gpt-5-mini", rpm=10, tpm=10000)
    """

    model: str
    temperature: float | None = None
    max_tokens: int | None = None
    rpm: int | None = None  # Requests per minute
    tpm: int | None = None  # Tokens per minute


@dataclass(slots=True)
class MCPServer:
    """MCP server configuration.

    Supports three transports:

    **stdio** (default) — Launches a local subprocess and communicates via
    stdin/stdout. Requires ``command``.

    **sse** — Connects to a remote server using Server-Sent Events.
    Requires ``url``.

    **streamable-http** — Connects to a remote server using the
    Streamable HTTP transport (recommended for production).
    Requires ``url``.

    Example:
        # stdio (default)
        MCPServer(
            command=["npx", "-y", "@modelcontextprotocol/server-filesystem"],
            args=["--directory", "/workspace"],
        )

        # SSE remote server
        MCPServer(
            transport="sse",
            url="http://localhost:8000/sse",
        )

        # Streamable HTTP remote server
        MCPServer(
            transport="streamable-http",
            url="http://localhost:8000/mcp",
        )

        # With custom headers (e.g. auth)
        MCPServer(
            transport="streamable-http",
            url="https://mcp.example.com/mcp",
            headers={"Authorization": "Bearer ${MCP_TOKEN}"},
        )
    """

    command: list[str] = field(default_factory=list)
    args: list[str] = field(default_factory=list)
    env: dict[str, str] = field(default_factory=dict)
    wait: Wait = field(default_factory=Wait.ready)
    cwd: str | None = None
    transport: Transport = "stdio"
    url: str | None = None
    headers: dict[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        # Expand env vars in environment (process env is stable at fixture construction time)
        self.env = {k: _expand_env(v) for k, v in self.env.items()}
        # NOTE: headers are NOT expanded here — they are expanded lazily at connection time
        # in MCPServerProcess._open_transport() so that env vars set by autouse fixtures
        # (e.g. access tokens) are resolved at the moment the server actually connects.
        # Validate transport/field combinations
        if self.transport == "stdio":
            if not self.command:
                msg = "MCPServer with transport='stdio' requires 'command'"
                raise ValueError(msg)
            if self.url:
                msg = "MCPServer with transport='stdio' does not use 'url'"
                raise ValueError(msg)
        elif self.transport in ("sse", "streamable-http"):
            if not self.url:
                msg = f"MCPServer with transport='{self.transport}' requires 'url'"
                raise ValueError(msg)
            if self.command:
                msg = f"MCPServer with transport='{self.transport}' does not use 'command'"
                raise ValueError(msg)


@dataclass(slots=True)
class CLIServer:
    """CLI server that wraps a command-line tool as an MCP-like tool.

    Wraps a single CLI command (like `git`, `docker`, `echo`) and exposes it
    as a tool the LLM can call with arbitrary arguments.

    By default, help discovery is DISABLED. The LLM must run `command --help`
    itself to discover available subcommands. This tests that your skill/prompt
    properly instructs the LLM to discover CLI capabilities.

    Example:
        CLIServer(
            name="git-cli",
            command="git",
            tool_prefix="git",      # Creates "git_execute" tool
            shell="bash",           # Shell to use (default: auto-detect)
        )

        # Enable auto-discovery (pre-populates tool description with help output)
        CLIServer(
            name="my-cli",
            command="my-tool",
            discover_help=True,     # Runs --help and includes in tool description
        )

        # Custom description instead of discovery
        CLIServer(
            name="legacy-cli",
            command="old-tool",
            description="Manages legacy data. Use: list, get <id>, delete <id>",
        )

    The generated tool accepts an `args` parameter:
        git_execute(args="status --porcelain")
        git_execute(args="log -n 5 --oneline")
    """

    name: str
    command: str
    tool_prefix: str | None = None
    shell: str | None = None  # auto-detect: bash on Unix, powershell on Windows
    cwd: str | None = None
    env: dict[str, str] = field(default_factory=dict)
    discover_help: bool = False  # LLM must discover help itself (tests skill instructions)
    help_flag: str = "--help"  # Flag to get help text (when discover_help=True)
    description: str | None = None  # Custom description (overrides help discovery)
    timeout: float = 30.0  # Timeout in seconds for each CLI command execution

    def __post_init__(self) -> None:
        self.env = {k: _expand_env(v) for k, v in self.env.items()}
        if self.tool_prefix is None:
            # Use command name as prefix (e.g., "git" -> "git_execute")
            self.tool_prefix = self.command.split()[0].split("/")[-1]


@dataclass(slots=True)
class CLIExecution:
    """Result of a CLI command execution.

    Captures exit code, stdout, stderr for assertions.
    """

    command: str
    args: str
    exit_code: int
    stdout: str
    stderr: str
    duration_ms: int


@dataclass(slots=True)
class Eval:
    """AI agent configuration combining provider and servers.

    The Eval is the unit of comparison in pytest-skill-engineering. Each agent has
    a unique ``id`` (auto-generated UUID) that flows through the entire
    pipeline — from test execution to report rendering.

    Define agents at module level and parametrize tests with them so the
    same Eval object (same UUID) is reused across tests:

    Example:
        Eval(
            name="banking-fast",
            provider=Provider(model="azure/gpt-5-mini"),
            mcp_servers=[banking_server],
            system_prompt="Be concise.",
        )

    Comparing agents:
        agents = [agent_fast, agent_smart, agent_expert]

        @pytest.mark.parametrize("agent", agents, ids=lambda a: a.name)
        async def test_query(eval_run, agent):
            result = await eval_run(agent, "What's my balance?")

    Filtering tools:
        Eval(
            provider=Provider(model="azure/gpt-5-mini"),
            mcp_servers=[excel_server],
            allowed_tools=["read_cell", "write_cell"],  # Only expose these tools
        )
    """

    provider: Provider
    name: str = ""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    mcp_servers: list[MCPServer] = field(default_factory=list)
    cli_servers: list[CLIServer] = field(default_factory=list)
    system_prompt: str | None = None
    max_turns: int = 10
    skill: Skill | None = None
    allowed_tools: list[str] | None = None  # Filter to specific tools (None = all)
    system_prompt_name: str | None = None  # Label for system prompt (for report grouping)
    retries: int = 1  # Max tool error retries (Pydantic AI default)
    clarification_detection: ClarificationDetection = field(default_factory=ClarificationDetection)
    custom_agent_name: str | None = None  # Name from .agent.md file
    custom_agent_description: str | None = None  # Description from .agent.md file
    instruction_files: list[dict[str, Any]] = field(default_factory=list)

    def __post_init__(self) -> None:
        """Auto-construct name from dimensions if not explicitly set."""
        if not self.name:
            model = self.provider.model
            display_model = model.split("/")[-1] if "/" in model else model
            parts = [display_model]
            if self.system_prompt_name:
                parts.append(self.system_prompt_name)
            if self.skill:
                parts.append(self.skill.name)
            self.name = " + ".join(parts)

    @classmethod
    def from_agent_file(
        cls,
        path: "str | Path",
        provider: "Provider",
        *,
        mcp_servers: "list[MCPServer] | None" = None,
        cli_servers: "list[CLIServer] | None" = None,
        skill: "Skill | None" = None,
        **overrides: "Any",
    ) -> "Eval":
        """Load agent configuration from a ``.agent.md`` or ``.md`` file.

        Uses the agent's prompt body as ``system_prompt`` and maps the
        ``tools`` frontmatter field to ``allowed_tools`` (unless overridden).

        Args:
            path: Path to the ``.agent.md`` (VS Code format) or ``.md``
                (Claude Code format) agent file.
            provider: LLM provider configuration.
            mcp_servers: MCP servers to attach to the agent.
            cli_servers: CLI servers to attach to the agent.
            skill: Eval skill to load.
            **overrides: Additional keyword arguments forwarded to
                :class:`Eval` (e.g. ``name``, ``max_turns``,
                ``allowed_tools``).

        Returns:
            A fully configured :class:`Eval` instance.

        Example::

            agent = Eval.from_agent_file(
                ".github/agents/reviewer.agent.md",
                provider=Provider(model="azure/gpt-5-mini"),
                mcp_servers=[my_server],
            )
        """
        from pytest_skill_engineering.core.evals import load_custom_agent  # noqa: PLC0415

        parsed = load_custom_agent(path)

        name: str = overrides.pop("name", parsed["name"])  # type: ignore[assignment]
        system_prompt: str = overrides.pop("system_prompt", parsed["prompt"])  # type: ignore[assignment]
        description: str = parsed.get("description", "")

        # Map frontmatter 'tools' → allowed_tools (unless caller overrides it)
        tools_from_file: list[str] | None = parsed["metadata"].get("tools")
        allowed_tools: list[str] | None = overrides.pop("allowed_tools", tools_from_file)  # type: ignore[assignment]

        return cls(
            name=name,
            provider=provider,
            mcp_servers=mcp_servers or [],
            cli_servers=cli_servers or [],
            skill=skill,
            system_prompt=system_prompt,
            allowed_tools=allowed_tools,
            custom_agent_name=name,
            custom_agent_description=description,
            **overrides,
        )

    @classmethod
    def from_instructions(
        cls,
        name: str,
        instructions: str,
        description: str = "",
        *,
        provider: "Provider",
        **kwargs: "Any",
    ) -> "Eval":
        """Create an eval with named instructions.

        Replaces the raw ``system_prompt=`` pattern with a named, documented
        agent. Useful when you have instructions that aren't loaded from a
        file but still want agent identity in reports.

        Args:
            name: Human-readable agent name shown in reports.
            instructions: System prompt / instructions for the agent.
            description: Optional description of what the agent does.
            provider: LLM provider configuration.
            **kwargs: Additional keyword arguments forwarded to :class:`Eval`.

        Returns:
            A fully configured :class:`Eval` instance.

        Example::

            agent = Eval.from_instructions(
                "financial-advisor",
                "You are a financial advisor. Answer questions about accounts.",
                description="Handles account balance queries",
                provider=Provider(model="azure/gpt-5-mini"),
            )
        """
        return cls(
            name=name,
            provider=provider,
            system_prompt=instructions,
            custom_agent_name=name,
            custom_agent_description=description,
            **kwargs,
        )

    @classmethod
    def from_instruction_files(
        cls,
        paths: "list[str | Path]",
        provider: "Provider",
        *,
        name: str = "",
        mcp_servers: "list[MCPServer] | None" = None,
        cli_servers: "list[CLIServer] | None" = None,
        skill: "Skill | None" = None,
        **kwargs: "Any",
    ) -> "Eval":
        """Create an eval with custom instruction files.

        Loads instruction files and concatenates them as system prompt.
        Each file contributes its content to the combined instructions.

        Args:
            paths: List of paths to instruction files.
            provider: LLM provider configuration.
            name: Optional name (defaults to instruction file names joined by " + ").
            mcp_servers: MCP servers to attach.
            cli_servers: CLI servers to attach.
            skill: Eval skill to load.
            **kwargs: Additional keyword arguments forwarded to Eval.

        Returns:
            A fully configured :class:`Eval` instance.

        Example::

            agent = Eval.from_instruction_files(
                [".github/copilot-instructions.md", "coding-standards.instructions.md"],
                provider=Provider(model="azure/gpt-5-mini"),
            )
        """
        from pytest_skill_engineering.core.evals import load_instruction_file  # noqa: PLC0415

        loaded = [load_instruction_file(p) for p in paths]
        combined_instructions = "\n\n".join(f["content"] for f in loaded)
        auto_name = name or " + ".join(f["name"] for f in loaded)

        return cls(
            name=auto_name,
            provider=provider,
            mcp_servers=mcp_servers or [],
            cli_servers=cli_servers or [],
            skill=skill,
            system_prompt=combined_instructions,
            instruction_files=loaded,
            **kwargs,
        )
