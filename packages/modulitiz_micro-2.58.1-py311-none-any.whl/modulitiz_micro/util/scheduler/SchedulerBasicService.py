from datetime import time as dt_time
from typing import Callable

from apscheduler import events
from apscheduler.events import JobExecutionEvent
from apscheduler.executors.pool import ThreadPoolExecutor
from apscheduler.job import Job
from apscheduler.jobstores.memory import MemoryJobStore
from apscheduler.schedulers.background import BackgroundScheduler

from modulitiz_micro.util.scheduler.AbstractSchedulerBasicService import AbstractSchedulerBasicService
from modulitiz_micro.util.scheduler.enums.ExecutorEnum import ExecutorEnum
from modulitiz_micro.util.scheduler.enums.TriggerEnum import TriggerEnum
from modulitiz_nano.ModuloDate import ModuloDate


class SchedulerBasicService(AbstractSchedulerBasicService):
	def __init__(self,*args):
		super().__init__(*args)
		self._addLoggerInternalToMainLogger()
		self.scheduler:BackgroundScheduler|None=None
	
	def create(self,onExceptionCallback:Callable[[JobExecutionEvent,],None]|None):
		jobStores={
			'default':MemoryJobStore()
		}
		executors={
			ExecutorEnum.DEFAULT:ThreadPoolExecutor(50)
		}
		jobDefaults={
			# https://apscheduler.readthedocs.io/en/3.x/userguide.html#missed-job-executions-and-coalescing
			'coalesce':True,
			'max_instances':1
		}
		self.scheduler=BackgroundScheduler(jobstores=jobStores,executors=executors,job_defaults=jobDefaults)
		_onExceptionCallback=None
		if onExceptionCallback is None:
			if self._logger is not None:
				_onExceptionCallback=self._standardOnException
		else:
			_onExceptionCallback=onExceptionCallback
		if _onExceptionCallback is not None:
			self.scheduler.add_listener(onExceptionCallback,events.EVENT_JOB_ERROR|events.EVENT_JOB_MISSED)
	
	def cancelJobByTag(self,tag:str):
		job=self.scheduler.get_job(tag)
		if job is None:
			return
		job.remove()
	
	def addJobCron(self,function: Callable,functionParams: list|tuple,**kwargs) -> Job:
		return self.scheduler.add_job(function,TriggerEnum.CRON,functionParams,**kwargs)
	
	def addJobAtTime(self,function:Callable,functionParams:list|tuple,time:str|dt_time,tag:str|None,**kwargs)->Job:
		if isinstance(time,str):
			time=ModuloDate.stringToTime(time)
		return self.scheduler.add_job(function,TriggerEnum.CRON,functionParams,hour=time.hour,minute=time.minute,second=time.second,id=tag,**kwargs)
	
	def rescheduleJobAtTime(self,tag:str,time:dt_time,**kwargs)->Job|None:
		job=self.scheduler.get_job(tag)
		if job is None:
			return None
		self.scheduler.reschedule_job(tag,trigger=TriggerEnum.CRON,hour=time.hour,minute=time.minute,second=time.second,**kwargs)
		return job
