from enum import StrEnum
from enum import unique


@unique
class ExecutorEnum(StrEnum):
	DEFAULT="default"
