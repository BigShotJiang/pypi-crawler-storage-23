from bs4 import BeautifulSoup
from bs4 import ResultSet
from bs4 import Tag

from modulitiz_nano.ModuloStringhe import ModuloStringhe
from modulitiz_nano.files.ModuloFiles import ModuloFiles


class DomModule(object):
	def __init__(self, filePath: str|None, htmlString: str|None):
		if filePath is not None:
			self.filePath=filePath
			htmlString=ModuloFiles.readFileText(filePath, True)
		self.htmlString=htmlString
		self.dom=self.__createObj()
	
	@staticmethod
	def innerHTML(tag:Tag)->str:
		"""
		dato in input un tag html della classe BeautifulSoup, restituisce il codice html all'interno di questo tag
		"""
		return "".join([str(x) for x in tag.contents])
	
	def selector(self,cssSelector:str)->ResultSet[Tag]:
		"""
		estrae tutti gli elementi che corrispondono al css selector
		"""
		return self.dom.select(cssSelector)
	
	@staticmethod
	def getAttributeValue(tag:Tag, nomeAttr:str):
		return tag.attrs[nomeAttr]
	
	@staticmethod
	def setAttributeValue(tag:Tag, nomeAttr:str, value):
		tag.attrs[nomeAttr]=value
		return tag
	
	@staticmethod
	def setInnerHtml(tag:Tag, value):
		tag.string=value
	
	def save(self):
		htmlOut=str(self.dom).encode(ModuloStringhe.CODIFICA_UTF8)
		with open(self.filePath, "wb") as file:
			file.write(htmlOut)
	
	def __createObj(self)->BeautifulSoup:
		return BeautifulSoup(self.htmlString, features="xml")
