from datetime import datetime

from suntime import Sun

from modulitiz_nano.ModuloDate import ModuloDate


class SunUtil(object):
	@staticmethod
	def getLocalSunrise(lat: float,long: float,dateTime: datetime|None = None) -> datetime:
		if dateTime is None:
			dateTime=ModuloDate.now()
		sun=Sun(lat,long)
		return sun.get_sunrise_time(dateTime,ModuloDate.getTimezoneLocal(dateTime))
	
	@staticmethod
	def getLocalSunset(lat: float,long: float,dateTime: datetime|None = None) -> datetime:
		if dateTime is None:
			dateTime=ModuloDate.now()
		sun=Sun(lat,long)
		return sun.get_sunset_time(dateTime,ModuloDate.getTimezoneLocal(dateTime))
