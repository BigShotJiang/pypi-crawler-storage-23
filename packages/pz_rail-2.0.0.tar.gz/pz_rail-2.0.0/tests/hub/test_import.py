import rail.stages


def test_import():
    rail.stages.import_and_attach_all()
