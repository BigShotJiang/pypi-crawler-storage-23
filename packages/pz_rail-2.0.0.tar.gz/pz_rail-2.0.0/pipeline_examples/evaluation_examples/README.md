This directory contains example notebooks explaining how to use the RAIL Evaluation Module.

- [demo.ipynb](https://htmlpreview.github.io/?https://github.com/LSSTDESC/RAIL/blob/master/examples/evaluation/demo.html) explains how to construct a basic `Evaluator`, and use it to compute evaluation metrics given an ensemble of p(z) estimates.
