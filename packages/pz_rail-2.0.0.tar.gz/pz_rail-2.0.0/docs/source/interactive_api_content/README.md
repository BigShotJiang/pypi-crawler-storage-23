# rail/docs/source/interactive_api_content

The `rst` files in this directory are prepended to the API documentation of the modules
with the same names.

Files should have exactly the same name as the generated `rst` file in `docs/api`, which
is how discovery is done.
