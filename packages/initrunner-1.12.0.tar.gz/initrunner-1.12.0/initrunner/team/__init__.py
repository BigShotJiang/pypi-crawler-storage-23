"""Multi-agent team mode — single-file, one-shot sequential collaboration."""
