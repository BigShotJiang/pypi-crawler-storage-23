This module supplies a new screen enabling you to manage your work
encoding (timesheet) by period. Timesheet entries are made by employees
each day. At the end of the defined period, employees submit their
validated sheet and the reviewer must then approve submitted entries.
Periods are defined in the company forms and you can set them to run
monthly, weekly or daily. By default, policy is configured to have HR
Officers as reviewers.
