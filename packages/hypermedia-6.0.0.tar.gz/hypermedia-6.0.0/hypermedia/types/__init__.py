"""Most of the typing used in hypermedia is taken from Ludic.

https://github.com/getludic/ludic
"""
