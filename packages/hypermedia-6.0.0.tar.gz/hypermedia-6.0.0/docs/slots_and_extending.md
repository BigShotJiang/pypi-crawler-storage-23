# Slots and Extenting

Hypermedia comes lets you define slots where you want to be able to add, extend, later.


# Slot

You can add a slot to any hypermedia `Element` you want
