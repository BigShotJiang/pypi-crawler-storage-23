# -*- coding: utf-8 -*-
# Python

"""Copyright (c) Alexander Fedotov.
This source code is licensed under the license found in the
LICENSE file in the root directory of this source tree.
"""
import sys
from .main import machine
from .config import settings
import click
import fileinput


@click.command()
# @click.option('--api-key', 'api_key', envvar='API_KEY',
#               default='no_key', help='Language Model API provider key.')
def run():  # api_key):
    # print(f'received {api_key}')
    """
        $ messages | ./run.py               # Accepts messages list from the pipe
        $ ./run.py /home/user/file.txt      # Reads file.
        $ ./run.py < /home/user/file.txt    # Reads file.
    """
    with fileinput.input() as f_input:
        for line in f_input:
            print(f"Received: {line}", end='')

