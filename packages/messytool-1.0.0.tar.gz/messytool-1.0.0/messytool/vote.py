from tkinter import *
root=Tk()
y=StringVar()
n=StringVar()
t=StringVar()
y.set(0)
n.set(0)
t.set(0)
def yes():
    y.set(int(y.get())+1)
    t.set(int(t.get())+1)
def no():
    n.set(int(n.get())+1)
    t.set(int(t.get())+1)
b1=Button(root,text='Yes',command=yes,width=20,bg='green').grid(row=0,column=0)
b2=Button(root,text='No',command=no,width=20,bg='red').grid(row=0,column=1)
l1=Label(root,textvariable=y).grid(row=1,column=0)
l2=Label(root,textvariable=n).grid(row=1,column=1)
l3=Label(root,text='Total:').grid(row=2,column=0)
l4=Label(root,textvariable=t).grid(row=2,column=1)

