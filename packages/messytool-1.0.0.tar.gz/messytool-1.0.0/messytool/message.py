from win10toast import ToastNotifier
def send(title,msg):
    toaster=ToastNotifier()
    toaster.showToast(title,msg)
def send_warning(msg):
    toaster=ToastNotifier()
    toaster.showToast('Warning',msg)
def send_error(msg):
    toaster=ToastNotifier()
    toaster.showToast('Error',msg)
