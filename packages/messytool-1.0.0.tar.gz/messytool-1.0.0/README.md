message.py:A package sending message.
It only works on Windows.Dont't use macOS or
Lunix system except ERRORS.
vote.py:To vote,only need to import it.
vote.py:To calc,only need to import it too.