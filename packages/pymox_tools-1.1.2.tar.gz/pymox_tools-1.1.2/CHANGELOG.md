# CHANGELOG

<!-- version list -->

## v1.1.2 (2026-02-22)

### Bug Fixes

- Nett
  ([`c60008d`](https://github.com/PyMoX-fr/GC7/commit/c60008dabc4f5a9f51d706580e85a0b8dcc2fe02))


## v1.1.1 (2026-02-22)

### Bug Fixes

- Up doc
  ([`ae02335`](https://github.com/PyMoX-fr/GC7/commit/ae0233522a176f7c8f2e30748248819332f4cd00))


## v1.1.0 (2026-02-21)

### Features

- Rappel semantic prefix
  ([`fa16eed`](https://github.com/PyMoX-fr/GC7/commit/fa16eed6f5825244b002125e39940c28692f7cb8))


## v1.0.6 (2025-08-04)

### Bug Fixes

- Try 1.0.6
  ([`2738278`](https://github.com/PyMoX-fr/GC7/commit/2738278da8c7c33dac1ada54b33dafb04ca4a859))


## v1.0.5 (2025-08-03)

### Bug Fixes

- Try v5
  ([`a3054f8`](https://github.com/PyMoX-fr/GC7/commit/a3054f8608157acf7cfb1c98af8b68bf646c44a8))


## v1.0.4 (2025-08-03)

### Bug Fixes

- Set local dev for tokens()
  ([`3183e15`](https://github.com/PyMoX-fr/GC7/commit/3183e15b25687c51da31870827091a5e81f756ff))


## v1.0.3 (2025-08-03)


## v1.0.2 (2025-08-03)


## v1.0.1 (2025-08-03)

### Bug Fixes

- Set hello()
  ([`03efc80`](https://github.com/PyMoX-fr/GC7/commit/03efc8032804e20feadba5fd246e07c1bc133b4b))


## v1.0.0 (2025-08-03)

- Initial Release
