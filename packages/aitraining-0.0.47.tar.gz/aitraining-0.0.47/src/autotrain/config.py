import os


HF_API = os.getenv("HF_API", "https://huggingface.co")
