"""MCP tool registrations for Frida operations."""
