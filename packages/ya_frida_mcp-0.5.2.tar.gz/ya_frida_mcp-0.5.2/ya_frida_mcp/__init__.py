"""Ya-Frida-MCP: Full-featured MCP server for Frida dynamic instrumentation."""

__version__ = "0.1.0"
