"""Middleware components for code-index MCP server."""

from .project_context_middleware import ProjectContextMiddleware

__all__ = ["ProjectContextMiddleware"]
