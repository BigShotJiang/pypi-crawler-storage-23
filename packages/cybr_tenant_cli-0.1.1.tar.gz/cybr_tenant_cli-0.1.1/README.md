# Account Manager

A CLI tool to manage accounts and launch them in incognito mode with passwords automatically copied to clipboard.

## Installation

```bash
pip install -e .
```

## Usage

```bash
# Add a new account
account-manager add

# List all accounts
account-manager list

# Open an account in incognito mode
account-manager open

# Delete an account
account-manager delete
```

## Features

- Store multiple account credentials securely
- Launch URLs in incognito mode
- Auto-copy passwords to clipboard
- Interactive account selection
