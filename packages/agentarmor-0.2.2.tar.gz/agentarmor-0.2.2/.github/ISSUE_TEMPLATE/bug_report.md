---
name: Bug report
about: Create a report to help us improve
title: "[BUG] "
labels: bug
assignees: ''
---

**Describe the bug**
A clear and concise description of what the bug is.

**To Reproduce**
Steps to reproduce the behavior:
1. Initialize AgentArmor with '...'
2. Send request to '...'
3. See error

**Expected behavior**
A clear and concise description of what you expected to happen.

**Environment Information (please complete the following information):**
 - OS: [e.g. macOS, Ubuntu Linux, Windows]
 - Python Version: [e.g. 3.10.2]
 - AgentArmor Version: [e.g. 0.1.0]
 - Target SDK: [e.g. openai==1.14.0, anthropic==0.23.0]

**Additional context**
Add any other context about the problem here (e.g., traceback logs).
