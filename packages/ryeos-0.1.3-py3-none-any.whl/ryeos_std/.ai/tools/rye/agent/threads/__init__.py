# rye:signed:2026-02-26T05:02:40Z:b55d5c8d563369effee41e171ab40e64a34a85b4b5ece5689bb8380992c447fe:rPDMKfRnS5AL6vVwPy0K2GvB5TsqGpLwjU5l7zxA0wZYXzjoRxRIgnG3Vmh6cWVNgfKrKkBFvAPMyh1mmlYoDg==:4b987fd4e40303ac
"""Thread system package."""

__version__ = "1.0.0"
__tool_type__ = "python"
__category__ = "rye/agent/threads"
__tool_description__ = "Thread system package init"
