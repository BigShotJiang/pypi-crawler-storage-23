# rye:signed:2026-02-26T05:02:40Z:8bac16b17b74c93fc82839b6bdd9c986fdf5389113e4a1b9e8facf8e1d0b17f5:Fjcgz0Ok3Vn0LQy0EVe44f9euLJTvI8ZoLJKacCyHLsR59an06B8k2Ex7SchhZKkdLA0imw7hUZnb2fcIXWLCg==:4b987fd4e40303ac
"""Primary tools package — rye_execute, rye_sign, rye_search, rye_load."""

__version__ = "1.0.0"
__tool_type__ = "python"
__category__ = "rye/primary"
__tool_description__ = "Primary tools package init"
