<!-- rye:signed:2026-02-26T05:02:40Z:97f592b911ae423728a4cb91bb1a93d5ae513951dfa1e0474e16bb0aca063851:yKb4IHovELqgtEaylIqEums0WLm2m8zAokp770yNhOWUSjm66h1dk31H8J7gIqc0PJlgihvYCxdcOvkzqKd3Bw==:4b987fd4e40303ac -->
# Read

Read file contents with optional offset and line limit.

```xml
<directive name="read" version="1.0.0">
  <metadata>
    <description>Read file contents from disk with optional offset and line limit for large files.</description>
    <category>rye/file-system</category>
    <author>rye-os</author>
    <model tier="fast" />
    <limits turns="3" tokens="2048" />
    <permissions>
      <execute>
        <tool>rye.file-system.read</tool>
      </execute>
    </permissions>
  </metadata>

  <inputs>
    <input name="file_path" type="string" required="true">
      Path to the file to read (absolute or relative to project root)
    </input>
    <input name="offset" type="integer" required="false">
      Starting line number, 1-indexed (default: 1)
    </input>
    <input name="limit" type="integer" required="false">
      Maximum number of lines to return (default: 2000)
    </input>
  </inputs>

  <outputs>
    <output name="content">File contents with line numbers</output>
  </outputs>
</directive>
```

<process>
  <step name="validate_inputs">
    Validate that {input:file_path} is non-empty.
    Default {input:offset} to 1 and {input:limit} to 2000 if not provided.
  </step>

  <step name="call_read">
    Read the file:
    `rye_execute(item_type="tool", item_id="rye/file-system/read", parameters={"path": "{input:file_path}", "offset": {input:offset}, "limit": {input:limit}})`
  </step>

  <step name="return_result">
    Return the file contents with line numbers.
  </step>
</process>
