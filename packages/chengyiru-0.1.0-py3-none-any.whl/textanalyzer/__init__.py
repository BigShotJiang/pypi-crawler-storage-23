# 从当前目录的sentiment_analyzer.py导入函数（点.不能丢！）
from .sentiment_analyzer import analyze_sentiment

# 声明对外暴露的函数（新手可忽略，但是加上更规范）
__all__ = ["analyze_sentiment"]