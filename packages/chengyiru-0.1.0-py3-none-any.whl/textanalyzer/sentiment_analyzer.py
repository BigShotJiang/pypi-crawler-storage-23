# 导入情感分析的核心库
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

# 定义情感分析函数（名字绝对不能错）
def analyze_sentiment(text: str) -> dict:
    """
    分析文本情感，返回负面/中性/正面/综合分数
    """
    # 创建分析器对象
    analyzer = SentimentIntensityAnalyzer()
    # 计算情感分数
    sentiment_result = analyzer.polarity_scores(text)
    # 返回结果
    return sentiment_result