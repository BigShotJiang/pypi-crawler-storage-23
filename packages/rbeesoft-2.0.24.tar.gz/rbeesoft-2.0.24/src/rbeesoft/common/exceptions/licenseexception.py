class LicenseException(Exception):
    pass