from rbeesoft.app.ui.widgets.centraldockwidget import CentralDockWidget
from rbeesoft.app.ui.widgets.logdockwidget import LogDockWidget