from rbeesoft.app.ui.widgets.pages.page import Page
from rbeesoft.app.ui.widgets.pages.pagerouter import PageRouter