# Kalshi API

- **Base URL:** `https://api.elections.kalshi.com/trade-api/v2`
- All endpoints are public, read-only. No authentication required.
