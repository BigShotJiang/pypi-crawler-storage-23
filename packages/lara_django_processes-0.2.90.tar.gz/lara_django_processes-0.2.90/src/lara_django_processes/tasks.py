"""
_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_processes celery tasks*

:details: lara_django_processes celery tasks.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

# from config import celery_app

# @celery_app.task()

from celery import shared_task
from celery.utils.log import get_task_logger
from prefect import flow
from prefect_aws.s3 import S3Bucket

logger = get_task_logger(__name__)


@shared_task
def deploy_process(instance_name, instance_id):
    """Deploy prefect process."""
    print(f"******* - --- loading bucket block {instance_name}")

    # get DEFAULT_PREFCT_WORKPOOL from settings

    prefect_workpool = "local-process-worker-1"  # settings.DEFAULT_PREFCT_WORKPOOL

    # if instance has a workpool set as parameters, use it !

    s3_bucket_block = S3Bucket.load("minio-prefect-flows-lara")

    print(f"******* - --- deploying prefect process {instance_name} - {prefect_workpool} ")

    flow.from_source(source=s3_bucket_block, entrypoint="robot_workflow_sila.py:science_robotic_process").deploy(
        name=f"minio-s3-deployment-lara-{instance_name}-{instance_id}",
        work_pool_name="local-process-worker-1",  # prefect_workpool,
        job_variables={"env": {"EXTRA_PIP_PACKAGES": "prefect-aws"}},
        tags=["lara", "sila"],
        description="Deployment of a SiLA workflow.",
        version="v0.0.1",
    )
