"""
_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_processes models *

:details: lara_django_processes database models.

:authors: - mark doerr <mark.doerr@uni-greifswald.de>
          - marco di sarno <disarno@k3b.de>

.. note:: -
.. todo:: - remove unwanted models/fields
________________________________________________________________________
"""

from django.conf import settings

settings.FIXTURES += []

from .abstracts import ExtraData, ProcessAbstr, ProcessInstanceAbstr, ProcMethodClass
from .method import (
    Method,
    MethodInstance,
    MethodInstancesSubset,
    MethodsSubset,
    OrderedMethodInstancesSubset,
    OrderedMethodsSubset,
)
from .procedure import (
    OrderedProcedureInstancesSubset,
    OrderedProceduresSubset,
    Procedure,
    ProcedureInstance,
    ProcedureInstancesSubset,
    ProceduresSubset,
)
from .process import OrderedProcessesSubset, Process, ProcessesSubset, ProcessStep, ProcessStepClass
from .process_instance import (
    OrderedProcessInstancesSubset,
    ProcessInstance,
    ProcessInstancesSubset,
    ProcessInstanceStep,
)
