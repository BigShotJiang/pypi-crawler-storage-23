"""
_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_processes app *

:details: lara_django_processes app configuration.
         This provides a generic django app configuration mechanism.
         For more details see:
         https://docs.djangoproject.com/en/4.0/ref/applications/
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

from django.apps import AppConfig
from django.db.models.signals import post_save


class LaraDjangoProcessesConfig(AppConfig):
    name = "lara_django_processes"
    url_path = "processes/"
    # enter a verbose name for your app: lara_django_processes here - this will be used in the admin interface
    verbose_name = "LARA-django Processes"
    lara_app_icon = "lara_processes_icon.svg"  # this will be used to display an icon, e.g. in the main LARA menu.
    lara_app_color = "orange"  # this will be used to highlight the app in the main LARA sidebar and app page
    lara_app_stor_color = "yellow"  # this will be used to highlight the app in the main LARA sidebar and app page
    lara_app_icon = "lara_material_icon.svg"
    verbose_name_short = "Processes"
    lara_app_description = "Processes, Procedures and Methods"
    lara_class_apps = [
        {
            "name": "Processes",
            "path": "lara_django_processes:process-list",  # "/projects/project/list",
            "icon": lara_app_icon,
            "color": lara_app_color,
        },
        {
            "name": "Procedures",
            "path": "lara_django_processes:procedure-list",
            "icon": lara_app_icon,
            "color": lara_app_color,
        },
        {
            "name": "Methods",
            "path": "lara_django_processes:method-list",
            "icon": lara_app_icon,
            "color": lara_app_color,
        },
    ]
    lara_instance_apps = [
        {
            "name": "Process Instances",
            "path": "lara_django_processes:process-instance-list",  # "/projects/project/list",
            "icon": lara_app_icon,
            "color": lara_app_stor_color,
        },
        {
            "name": "Procedure Instances",
            "path": "lara_django_processes:procedure-instance-list",
            "icon": lara_app_icon,
            "color": lara_app_stor_color,
        },
        {
            "name": "Method Instances",
            "path": "lara_django_processes:method-instance-list",
            "icon": lara_app_icon,
            "color": lara_app_stor_color,
        },
    ]

    # def ready(self):
    #     from django.urls import path, include
    #     from lara_django_base.urls import urlpatterns

    #     urlpatterns.append(
    #         path('processes/', include('lara_django_processes.urls')))

    def ready(self):
        from . import signals

        post_save.connect(signals.post_save_handler, dispatch_uid="lara_django_processes.post_save")

        # add urlpatterns
        from django.urls import include, path
        from lara_django.urls import urlpatterns

        urlpatterns += [
            path(self.url_path, include("lara_django_processes.urls", namespace="lara_django_processes")),
        ]
