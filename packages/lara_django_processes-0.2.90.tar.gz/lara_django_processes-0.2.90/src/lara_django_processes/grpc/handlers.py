"""
_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_processes gRPC handlers*

:details: lara_django_processes gRPC handlers.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

# generated with django-socio-grpc generateprpcinterface lara_django_processes  (LARA-version)

# import logging
from lara_django_processes.grpc.services import (
    ExtraDataService,
    MethodClassService,
    MethodInstanceService,
    MethodService,
    ProcedureInstanceService,
    ProcedureService,
    ProcessInstanceService,
    ProcessService,
)

from .subscriptions import AppHandlerRegistryWithModelSignalDispatchers


def grpc_handlers(server):
    app_registry = AppHandlerRegistryWithModelSignalDispatchers("lara_django_processes", server)

    app_registry.get_grpc_module = lambda: "lara_django_processes_grpc.v1"

    app_registry.register(ExtraDataService)

    app_registry.register(MethodClassService)

    app_registry.register(MethodService)

    app_registry.register(ProcedureService)

    app_registry.register(ProcessService)

    app_registry.register(MethodInstanceService)

    app_registry.register(ProcedureInstanceService)

    app_registry.register(ProcessInstanceService)
