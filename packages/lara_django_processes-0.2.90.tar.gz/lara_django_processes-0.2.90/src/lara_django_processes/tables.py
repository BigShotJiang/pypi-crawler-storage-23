"""
_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_processes admin *

:details: lara_django_processes admin module admin backend configuration.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - run "lara-django-dev tables_generator lara_django_processes >> tables.py" to update this file
________________________________________________________________________
"""

# django Tests s. https://docs.djangoproject.com/en/4.1/topics/testing/overview/ for lara_django_processes
# generated with django-extensions tests_generator  lara_django_processes > tests.py (LARA-version)

import django_tables2 as tables
from django.utils.html import format_html

from .models import (
    ExtraData,
    Method,
    MethodInstance,
    Procedure,
    ProcedureInstance,
    Process,
    ProcessInstance,
    ProcMethodClass,
)


class ExtraDataTable(tables.Table):
    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_processes:extradata-detail', [tables.A('pk')]))

    class Meta:
        model = ExtraData

        fields = (
            "data_type",
            "namespace",
            "media_type",
            "iri",
            "url",
            "description",
            "image",
            "file",
        )


class MethodClassTable(tables.Table):
    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_processes:methodclass-detail', [tables.A('pk')]))

    class Meta:
        model = ProcMethodClass

        fields = ("method_class", "description")


class MethodTable(tables.Table):
    # adding link to column <column-to-be-linked>
    name = tables.Column(linkify=("lara_django_processes:method-detail", [tables.A("pk")]))
    edit = tables.Column(
        empty_values=(),
        verbose_name="Edit",
        default="Edit",
        linkify={
            "viewname": "lara_django_processes:method-update",
            "args": [(tables.A("pk"))],
        },
        attrs={"a": {"class": "btn btn-warning btn-sm"}},
    )

    delete = tables.Column(
        empty_values=(),
        verbose_name="Delete",
        default="Delete",
        linkify={
            "viewname": "lara_django_processes:method-delete",
            "args": [(tables.A("pk"))],
        },
        attrs={"a": {"class": "btn btn-danger btn-sm"}},
    )

    def render_edit(self):
        return format_html('<i class="bi bi-pencil-square"></i>')

    def render_delete(self):
        return format_html('<i class="bi bi-trash"></i>')

    class Meta:
        model = Method

        fields = (
            "name",
            "namespace",
            "method",
            "method_class",
            "version",
            "description",
            "remarks",
            "media_type",
            "method_file",
        )


class ProcedureTable(tables.Table):
    # adding link to column <column-to-be-linked>
    name = tables.Column(linkify=("lara_django_processes:procedure-detail", [tables.A("pk")]))
    edit = tables.Column(
        empty_values=(),
        verbose_name="Edit",
        default="Edit",
        linkify={
            "viewname": "lara_django_processes:procedure-update",
            "args": [(tables.A("pk"))],
        },
        attrs={"a": {"class": "btn btn-warning btn-sm"}},
    )

    delete = tables.Column(
        empty_values=(),
        verbose_name="Delete",
        default="Delete",
        linkify={
            "viewname": "lara_django_processes:procedure-delete",
            "args": [(tables.A("pk"))],
        },
        attrs={"a": {"class": "btn btn-danger btn-sm"}},
    )

    def render_edit(self):
        return format_html('<i class="bi bi-pencil-square"></i>')

    def render_delete(self):
        return format_html('<i class="bi bi-trash"></i>')

    class Meta:
        model = Procedure

        fields = (
            "name",
            "namespace",
            "version",
            "icon",
            "description",
            "remarks",
            "iri",
            "procedure",
            "procedure_class",
            "media_type",
            "procedure_file",
        )


class ProcessTable(tables.Table):
    # adding link to column <column-to-be-linked>
    name = tables.Column(linkify=("lara_django_processes:process-detail", [tables.A("pk")]))

    edit = tables.Column(
        empty_values=(),
        verbose_name="Edit",
        default="Edit",
        linkify={
            "viewname": "lara_django_processes:process-update",
            "args": [(tables.A("pk"))],
        },
        attrs={"a": {"class": "btn btn-warning btn-sm"}},
    )

    delete = tables.Column(
        empty_values=(),
        verbose_name="Delete",
        default="Delete",
        linkify={
            "viewname": "lara_django_processes:process-delete",
            "args": [(tables.A("pk"))],
        },
        attrs={"a": {"class": "btn btn-danger btn-sm"}},
    )

    def render_edit(self):
        return format_html('<i class="bi bi-pencil-square"></i>')

    def render_delete(self):
        return format_html('<i class="bi bi-trash"></i>')

    class Meta:
        model = Process

        fields = (
            "name",
            "namespace",
            "version",
            "icon",
            "description",
            "remarks",
            "iri",
            "process_class",
        )


class MethodInstanceTable(tables.Table):
    # adding link to column <column-to-be-linked>
    name = tables.Column(linkify=("lara_django_processes:method-instance-detail", [tables.A("pk")]))
    edit = tables.Column(
        empty_values=(),
        verbose_name="Edit",
        default="Edit",
        linkify={
            "viewname": "lara_django_processes:method-instance-update",
            "args": [(tables.A("pk"))],
        },
        attrs={"a": {"class": "btn btn-warning btn-sm"}},
    )

    delete = tables.Column(
        empty_values=(),
        verbose_name="Delete",
        default="Delete",
        linkify={
            "viewname": "lara_django_processes:method-instance-delete",
            "args": [(tables.A("pk"))],
        },
        attrs={"a": {"class": "btn btn-danger btn-sm"}},
    )

    def render_edit(self):
        return format_html('<i class="bi bi-pencil-square"></i>')

    def render_delete(self):
        return format_html('<i class="bi bi-trash"></i>')

    class Meta:
        model = MethodInstance

        fields = (
            "name",
            "namespace",
            "version",
            "status",
            "icon",
            "description",
            "remarks",
            "method_base",
            "media_type",
            "method_file",
        )


class ProcedureInstanceTable(tables.Table):
    # adding link to column <column-to-be-linked>
    name = tables.Column(linkify=("lara_django_processes:procedure-instance-detail", [tables.A("pk")]))
    edit = tables.Column(
        empty_values=(),
        verbose_name="Edit",
        default="Edit",
        linkify={
            "viewname": "lara_django_processes:procedure-instance-update",
            "args": [(tables.A("pk"))],
        },
        attrs={"a": {"class": "btn btn-warning btn-sm"}},
    )

    delete = tables.Column(
        empty_values=(),
        verbose_name="Delete",
        default="Delete",
        linkify={
            "viewname": "lara_django_processes:procedure-instance-delete",
            "args": [(tables.A("pk"))],
        },
        attrs={"a": {"class": "btn btn-danger btn-sm"}},
    )

    def render_edit(self):
        return format_html('<i class="bi bi-pencil-square"></i>')

    def render_delete(self):
        return format_html('<i class="bi bi-trash"></i>')

    class Meta:
        model = ProcedureInstance

        fields = (
            "name",
            "namespace",
            "version",
            "status",
            "icon",
            "description",
            "remarks",
            "iri",
            "procedure_base",
            "procedure",
            "media_type",
            "procedure_file",
        )


class ProcessInstanceTable(tables.Table):
    # adding link to column <column-to-be-linked>
    name = tables.Column(linkify=("lara_django_processes:process-instance-detail", [tables.A("pk")]))
    edit = tables.Column(
        empty_values=(),
        verbose_name="Edit",
        default="Edit",
        linkify={
            "viewname": "lara_django_processes:process-instance-update",
            "args": [(tables.A("pk"))],
        },
        attrs={"a": {"class": "btn btn-warning btn-sm"}},
    )

    delete = tables.Column(
        empty_values=(),
        verbose_name="Delete",
        default="Delete",
        linkify={
            "viewname": "lara_django_processes:process-instance-delete",
            "args": [(tables.A("pk"))],
        },
        attrs={"a": {"class": "btn btn-danger btn-sm"}},
    )

    def render_edit(self):
        return format_html('<i class="bi bi-pencil-square"></i>')

    def render_delete(self):
        return format_html('<i class="bi bi-trash"></i>')

    class Meta:
        model = ProcessInstance

        fields = (
            "name",
            "namespace",
            "version",
            "status",
            "icon",
            "description",
            "remarks",
            "iri",
            "process_base",
        )
