"""
_____________________________________________________________________.

:PROJECT: LARAsuite

*lara_django_processes Model Context Protocol (MCP) handler *

:details: lara_django_processes Model Context Protocol (MCP) handler.

:authors: mark doerr <mark.doerr@uni-greifswald.de>

________________________________________________________________________
"""

from mcp_server import ModelQueryToolset

from .models import (
    ExtraData,
    Method,
    MethodInstance,
    MethodInstancesSubset,
    MethodsSubset,
    OrderedMethodInstancesSubset,
    OrderedMethodsSubset,
    OrderedProcedureInstancesSubset,
    OrderedProceduresSubset,
    OrderedProcessesSubset,
    OrderedProcessInstancesSubset,
    Procedure,
    ProcedureInstance,
    ProcedureInstancesSubset,
    ProceduresSubset,
    Process,
    ProcessesSubset,
    ProcessInstance,
    ProcessInstancesSubset,
    ProcessInstanceStep,
    ProcessStep,
    ProcessStepClass,
    ProcMethodClass,
)


class ProcMethodClassQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `ProcMethodClass`."""

    model = ProcMethodClass


class ExtraDataQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `ExtraData`."""

    model = ExtraData


class MethodQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `Method`."""

    model = Method


class MethodsSubsetQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `MethodsSubset`."""

    model = MethodsSubset


class OrderedMethodsSubsetQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `OrderedMethodsSubset`."""

    model = OrderedMethodsSubset


class MethodInstanceQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `MethodInstance`."""

    model = MethodInstance


class MethodInstancesSubsetQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `MethodInstancesSubset`."""

    model = MethodInstancesSubset


class OrderedMethodInstancesSubsetQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `OrderedMethodInstancesSubset`."""

    model = OrderedMethodInstancesSubset


class ProcedureQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `Procedure`."""

    model = Procedure


class ProceduresSubsetQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `ProceduresSubset`."""

    model = ProceduresSubset


class OrderedProceduresSubsetQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `OrderedProceduresSubset`."""

    model = OrderedProceduresSubset


class ProcedureInstanceQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `ProcedureInstance`."""

    model = ProcedureInstance


class ProcedureInstancesSubsetQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `ProcedureInstancesSubset`."""

    model = ProcedureInstancesSubset


class OrderedProcedureInstancesSubsetQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `OrderedProcedureInstancesSubset`."""

    model = OrderedProcedureInstancesSubset


class ProcessStepClassQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `ProcessStepClass`."""

    model = ProcessStepClass


class ProcessQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `Process`."""

    model = Process


class ProcessStepQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `ProcessStep`."""

    model = ProcessStep


class ProcessesSubsetQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `ProcessesSubset`."""

    model = ProcessesSubset


class OrderedProcessesSubsetQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `OrderedProcessesSubset`."""

    model = OrderedProcessesSubset


class ProcessInstanceQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `ProcessInstance`."""

    model = ProcessInstance


class ProcessInstanceStepQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `ProcessInstanceStep`."""

    model = ProcessInstanceStep


class ProcessInstancesSubsetQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `ProcessInstancesSubset`."""

    model = ProcessInstancesSubset


class OrderedProcessInstancesSubsetQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `OrderedProcessInstancesSubset`."""

    model = OrderedProcessInstancesSubset
