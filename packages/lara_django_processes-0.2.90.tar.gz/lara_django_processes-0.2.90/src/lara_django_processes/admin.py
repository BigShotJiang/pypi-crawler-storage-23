"""
_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_processes admin *

:details: lara_django_processes admin module admin backend configuration.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - run "lara-django-dev admin_generator lara_django_processes >> admin.py" to update this file
________________________________________________________________________
"""

# -*- coding: utf-8 -*-
from django.contrib import admin

from .models import (
    ExtraData,
    Method,
    MethodInstance,
    Procedure,
    ProcedureInstance,
    Process,
    # ProcedureInstanceMoveStep,
    ProcessInstance,
    ProcessStepClass,
    ProcMethodClass,
)


@admin.register(ExtraData)
class ExtraDataAdmin(admin.ModelAdmin):
    list_display = (
        "name_full",
        "data_type",
        "namespace",
        "media_type",
        "url",
        "description",
        "extradata_id",
        "image",
        "file",
    )
    list_filter = ("data_type", "namespace", "media_type")


@admin.register(ProcMethodClass)
class MethodClassAdmin(admin.ModelAdmin):
    list_display = ("procmethodclass_id", "name", "description")


@admin.register(Method)
class MethodAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "namespace",
        "version",
        "parameters",
        "icon",
        "description",
        "remarks",
        "method_id",
        "method_json",
        "method_class",
        "media_type",
    )
    list_filter = ("namespace", "method_class", "media_type")
    raw_id_fields = (
        "substances",
        "polymers",
        "mixtures",
        "parts",
        "labware",
        "devices",
        "organisms",
        "creators",
        "tags",
        "data_extra",
    )
    search_fields = ("name",)


@admin.register(Procedure)
class ProcedureAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "namespace",
        "version",
        "parameters",
        "icon",
        "description",
        "remarks",
        "procedure_id",
        "procedure_json",
        "procedure_class",
        "media_type",
        "procedure_file",
    )
    list_filter = ("namespace", "procedure_class", "media_type")
    raw_id_fields = (
        "substances",
        "polymers",
        "mixtures",
        "parts",
        "labware",
        "devices",
        "organisms",
        "creators",
        "tags",
        "data_extra",
    )
    search_fields = ("name",)


@admin.register(Process)
class ProcessAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "namespace",
        "version",
        "parameters",
        "icon",
        "description",
        "remarks",
        "process_id",
        "process_class",
    )
    list_filter = ("namespace", "process_class")
    raw_id_fields = (
        "substances",
        "polymers",
        "mixtures",
        "parts",
        "labware",
        "devices",
        "creators",
        "tags",
        "data_extra",
        "procedures",
    )
    search_fields = ("name",)


@admin.register(MethodInstance)
class MethodInstanceAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "namespace",
        "version",
        "parameters",
        "status",
        "icon",
        "description",
        "remarks",
        "methodinstance_id",
        "method_base",
        "media_type",
    )
    list_filter = (
        "namespace",
        "status",
        "method_base",
        "media_type",
    )
    raw_id_fields = (
        "substance_instances",
        "polymer_instances",
        "mixture_instances",
        "part_instances",
        "labware_instances",
        "device_instances",
        "creators",
        "tags",
        "data_extra",
    )
    search_fields = ("name",)


@admin.register(ProcedureInstance)
class ProcedureInstanceAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "namespace",
        "version",
        "parameters",
        "status",
        "icon",
        "description",
        "remarks",
        "procedureinstance_id",
        "procedure_base",
        "procedure_json",
        "media_type",
        "procedure_file",
    )
    list_filter = (
        "namespace",
        "status",
        "procedure_base",
        "media_type",
    )
    raw_id_fields = (
        "substance_instances",
        "polymer_instances",
        "mixture_instances",
        "part_instances",
        "labware_instances",
        "device_instances",
        "organism_instances",
        "creators",
        "tags",
        "data_extra",
    )
    search_fields = ("name",)


@admin.register(ProcessStepClass)
class ProcedureInstanceStepClassAdmin(admin.ModelAdmin):
    list_display = ("description",)


# @admin.register(ProcessInstanceStep)
# class ProcedureInstanceStepAdmin(admin.ModelAdmin):
#     list_display = ("name",)
#     list_filter = ()
#     search_fields = ("name",)


# @admin.register(ProcedureInstanceMoveStep)
# class ProcedureInstanceMoveStepAdmin(admin.ModelAdmin):
#     list_display = ("name",)
#     list_filter = ()
#     raw_id_fields = ()
#     search_fields = ("name",)


@admin.register(ProcessInstance)
class ProcessInstanceAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "namespace",
        "version",
        "parameters",
        "status",
        "icon",
        "description",
        "remarks",
        "processinstance_id",
        "process_base",
    )
    list_filter = ("namespace", "status", "process_base")
    raw_id_fields = (
        "substance_instances",
        "polymer_instances",
        "mixture_instances",
        "part_instances",
        # "labware_instances",
        # "device_instances",
        # "organism_instances",
        "creators",
        "tags",
        "data_extra",
        # "procedure_instances",
    )
    search_fields = ("name",)
