"""
_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_data filter app *

:details: lara_django_data filter app.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

from django_filters import FilterSet

from .models import (
    ExtraData,
    Method,
    MethodInstance,
    Procedure,
    ProcedureInstance,
    Process,
    ProcessInstance,
    ProcMethodClass,
)


class ExtraDataFilterSet(FilterSet):
    class Meta:
        model = ExtraData
        fields = {
            "namespace__uri": ["exact", "contains"],
            "name_display": ["exact", "contains"],
            "name": ["exact", "contains"],
            "name_full": ["exact", "contains"],
            "iri": ["exact", "contains"],
            "url": ["exact", "contains"],
            "datetime_created": ["lt", "gt", "exact", "range"],
            "datetime_last_modified": ["lt", "gt", "exact", "range"],
            "description": ["exact", "contains"],
        }


class MethodClassFilterSet(FilterSet):
    class Meta:
        model = ProcMethodClass
        fields = {
            "name": ["exact", "contains"],
            "iri": ["exact", "contains"],
            "description": ["exact", "contains"],
        }


class MethodFilterSet(FilterSet):
    class Meta:
        model = Method
        fields = {
            "namespace__uri": ["exact", "contains"],
            "name": ["exact", "contains"],
            "name_display": ["exact", "contains"],
            "uri": ["exact", "contains"],
            "iri": ["exact", "contains"],
            "pid": ["exact", "contains"],
            "version": ["exact", "contains"],
            "description": ["exact", "contains"],
            "remarks": ["exact", "contains"],
            "datetime_last_modified": ["lt", "gt", "exact", "range"],
        }


class ProcedureFilterSet(FilterSet):
    class Meta:
        model = Procedure
        fields = {
            "namespace__uri": ["exact", "contains"],
            "name": ["exact", "contains"],
            "name_display": ["exact", "contains"],
            "procedure_txt": ["exact", "contains"],
            "uri": ["exact", "contains"],
            "iri": ["exact", "contains"],
            "pid": ["exact", "contains"],
            "version": ["exact", "contains"],
            "description": ["exact", "contains"],
            "remarks": ["exact", "contains"],
            "datetime_last_modified": ["lt", "gt", "exact", "range"],
        }


class ProcessFilterSet(FilterSet):
    class Meta:
        model = Process
        fields = {
            "namespace__uri": ["exact", "contains"],
            "name": ["exact", "contains"],
            "name_display": ["exact", "contains"],
            "uri": ["exact", "contains"],
            "iri": ["exact", "contains"],
            "pid": ["exact", "contains"],
            "version": ["exact", "contains"],
            "description": ["exact", "contains"],
            "remarks": ["exact", "contains"],
            "datetime_last_modified": ["lt", "gt", "exact", "range"],
        }


class MethodInstanceFilterSet(FilterSet):
    class Meta:
        model = MethodInstance
        fields = {
            "namespace__uri": ["exact", "contains"],
            "name": ["exact", "contains"],
            "name_display": ["exact", "contains"],
            "uri": ["exact", "contains"],
            "iri": ["exact", "contains"],
            "pid": ["exact", "contains"],
            "version": ["exact", "contains"],
            "description": ["exact", "contains"],
            "remarks": ["exact", "contains"],
            "datetime_last_modified": ["lt", "gt", "exact", "range"],
        }


class ProcedureInstanceFilterSet(FilterSet):
    class Meta:
        model = ProcedureInstance
        fields = {
            "namespace__uri": ["exact", "contains"],
            "name": ["exact", "contains"],
            "name_display": ["exact", "contains"],
            "uri": ["exact", "contains"],
            "iri": ["exact", "contains"],
            "pid": ["exact", "contains"],
            "version": ["exact", "contains"],
            "description": ["exact", "contains"],
            "remarks": ["exact", "contains"],
            "datetime_last_modified": ["lt", "gt", "exact", "range"],
        }


class ProcessInstanceFilterSet(FilterSet):
    class Meta:
        model = ProcessInstance
        fields = {
            "namespace__uri": ["exact", "contains"],
            "name": ["exact", "contains"],
            "name_display": ["exact", "contains"],
            "uri": ["exact", "contains"],
            "iri": ["exact", "contains"],
            "pid": ["exact", "contains"],
            "version": ["exact", "contains"],
            "description": ["exact", "contains"],
            "remarks": ["exact", "contains"],
            "datetime_last_modified": ["lt", "gt", "exact", "range"],
        }
