//! # Lib
//!
//! $$
//! V_0 = \mathbb{E}^{\mathbb{Q}}\!\left[e^{-\int_0^T r_t\,dt}\,\Pi(X_T)\right]
//! $$
//!
#![doc = include_str!("../README.md")]
#![allow(non_snake_case)]
#![allow(clippy::type_complexity)]
#![allow(clippy::too_many_arguments)]
//#![warn(missing_docs)]
// TODO: this is just temporary
#![allow(dead_code)]

#[cfg(feature = "mimalloc")]
#[global_allocator]
static GLOBAL: mimalloc::MiMalloc = mimalloc::MiMalloc;

#[cfg(feature = "jemalloc")]
#[global_allocator]
static GLOBAL: tikv_jemallocator::Jemalloc = tikv_jemallocator::Jemalloc;

#[macro_use]
mod macros;

#[cfg(feature = "ai")]
pub mod ai;
pub mod copulas;
pub mod distributions;
pub mod quant;
pub mod simd_rng;
pub mod stats;
pub mod stochastic;
pub mod traits;
mod visualization;

#[cfg(feature = "python")]
mod python;
