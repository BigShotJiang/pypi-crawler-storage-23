//! # CIR
//!
//! $$
//! dX_t=\kappa(\theta-X_t)\,dt+\sigma\sqrt{X_t}\,dW_t
//! $$
//!
pub use crate::stochastic::diffusion::cir::CIR;
