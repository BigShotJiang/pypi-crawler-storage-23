//! # Malliavin
//!
//! $$
//! D_r\!\left(\int_0^T u_t\,dW_t\right)=u_r\,\mathbf 1_{\{r\le T\}}
//! $$
//!
