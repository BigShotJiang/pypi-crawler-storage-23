"""Account exchange method types."""
from dataclasses import dataclass
from typing import Optional

from hotstuff.utils.address import validate_ethereum_address


# Add Agent Method
@dataclass
class AddAgentParams:
    """Parameters for adding an agent."""
    agentName: str
    agent: str
    forAccount: str
    validUntil: int
    signature: Optional[str] = None
    nonce: Optional[int] = None
    agentPrivateKey: Optional[str] = None
    signer: Optional[str] = None
    
    def __post_init__(self):
        """Validate and checksum Ethereum addresses."""
        if self.agent:
            self.agent = validate_ethereum_address(self.agent)
        if self.signer:
            self.signer = validate_ethereum_address(self.signer)


# Revoke Agent Method
@dataclass
class RevokeAgentParams:
    """Parameters for revoking an agent."""
    agent: str
    forAccount: str
    nonce: Optional[int] = None
    
    def __post_init__(self):
        """Validate and checksum the agent address."""
        self.agent = validate_ethereum_address(self.agent)


# Update Perp Instrument Leverage Method
@dataclass
class UpdatePerpInstrumentLeverageParams:
    """Parameters for updating perp instrument leverage."""
    instrumentId: int
    leverage: str
    nonce: Optional[int] = None


# Approve Broker Fee Method
@dataclass
class ApproveBrokerFeeParams:
    """Parameters for approving broker fee."""
    broker: str
    maxFeeRate: str
    nonce: Optional[int] = None
    
    def __post_init__(self):
        """Validate and checksum the broker address."""
        self.broker = validate_ethereum_address(self.broker)


# Create Referral Code Method
@dataclass
class CreateReferralCodeParams:
    """Parameters for creating a referral code."""
    code: str
    nonce: Optional[int] = None


# Set Referrer Method
@dataclass
class SetReferrerParams:
    """Parameters for setting a referrer."""
    code: str
    nonce: Optional[int] = None


# Claim Referral Rewards Method
@dataclass
class ClaimReferralRewardsParams:
    """Parameters for claiming referral rewards."""
    collateralId: int
    spot: bool
    nonce: Optional[int] = None
