"""
SQLite database for model-radar.

Stores model definitions synced from hardcoded providers, ping results,
and cache metadata. Database path: ~/.model-radar/models.db
"""

from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .config import CONFIG_DIR
from .providers import PROVIDERS, Model

DB_PATH = CONFIG_DIR / "models.db"


@contextmanager
def get_connection(db_path: Path | None = None):
    """Get a database connection context manager."""
    path = db_path or DB_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path))
    conn.row_factory = sqlite3.Row
    try:
        yield conn
    finally:
        conn.close()


def init_schema(db_path: Path | None = None) -> None:
    """Initialize database schema if tables don't exist."""
    with get_connection(db_path) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS models (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                provider_key TEXT NOT NULL,
                model_id TEXT NOT NULL,
                label TEXT NOT NULL,
                tier TEXT NOT NULL,
                swe_score TEXT,
                context_window TEXT,
                last_pinged_at TIMESTAMP,
                is_active BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(provider_key, model_id)
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS ping_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                model_id TEXT NOT NULL,
                provider_key TEXT NOT NULL,
                status TEXT NOT NULL,
                latency_ms REAL,
                error_detail TEXT,
                recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS cache_meta (
                key TEXT PRIMARY KEY,
                value TEXT,
                expires_at TIMESTAMP
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_models_provider ON models(provider_key)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_models_active ON models(is_active)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_ping_results_model ON ping_results(model_id, provider_key)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_ping_results_time ON ping_results(recorded_at DESC)")
        # Migration: add is_free if missing (1=free, 0=paid, NULL=unknown)
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(models)")
        columns = [row[1] for row in cursor.fetchall()]
        if "is_free" not in columns:
            conn.execute("ALTER TABLE models ADD COLUMN is_free INTEGER")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_models_is_free ON models(is_free)")
        conn.commit()


def _is_free_from_model_id(model_id: str) -> int | None:
    """Return 1 if model_id suggests free, 0 if we assume paid, None if unknown. For DB storage."""
    from .providers import _model_id_suggests_free
    v = _model_id_suggests_free(model_id)
    if v is True:
        return 1
    if v is False:
        return 0
    return None


def sync_models(db_path: Path | None = None) -> dict[str, int]:
    """
    Sync hardcoded provider models to database.
    
    Returns dict with counts per provider.
    """
    init_schema(db_path)
    
    with get_connection(db_path) as conn:
        cursor = conn.cursor()
        stats = {}
        
        for provider_key, provider in PROVIDERS.items():
            count = 0
            for model_tuple in provider.models:
                model_id, label, tier, swe_score, context = model_tuple
                is_free = _is_free_from_model_id(model_id)
                cursor.execute("""
                    INSERT INTO models (provider_key, model_id, label, tier, swe_score, context_window, is_free, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                    ON CONFLICT(provider_key, model_id) DO UPDATE SET
                        label = excluded.label,
                        tier = excluded.tier,
                        swe_score = excluded.swe_score,
                        context_window = excluded.context_window,
                        is_free = excluded.is_free,
                        updated_at = CURRENT_TIMESTAMP
                """, (provider_key, model_id, label, tier, swe_score, context, is_free))
                count += 1
            
            stats[provider_key] = count
        
        conn.commit()
        return stats


def get_all_models(db_path: Path | None = None, active_only: bool = True) -> list[Model]:
    """Get all models from database."""
    init_schema(db_path)
    
    with get_connection(db_path) as conn:
        cursor = conn.cursor()
        if active_only:
            cursor.execute("""
                SELECT provider_key, model_id, label, tier, swe_score, context_window, is_free
                FROM models WHERE is_active = 1
            """)
        else:
            cursor.execute("""
                SELECT provider_key, model_id, label, tier, swe_score, context_window, is_free
                FROM models
            """)
        rows = cursor.fetchall()
    
    return [
        Model(
            provider=row[0],
            model_id=row[1],
            label=row[2],
            tier=row[3],
            swe_score=row[4],
            context=row[5],
            is_free=bool(row[6]) if row[6] is not None else None,
        )
        for row in rows
    ]


def filter_models(
    db_path: Path | None = None,
    tier: str | None = None,
    provider: str | None = None,
    min_tier: str | None = None,
    active_only: bool = True,
    free_only: bool = False,
) -> list[Model]:
    """Filter models by tier, provider, min_tier, and optionally free_only."""
    from .providers import TIER_ORDER
    
    init_schema(db_path)
    
    with get_connection(db_path) as conn:
        cursor = conn.cursor()
        
        query = "SELECT provider_key, model_id, label, tier, swe_score, context_window, is_free FROM models WHERE 1=1"
        params = []
        
        if active_only:
            query += " AND is_active = 1"
        
        if free_only:
            query += " AND is_free = 1"
        
        if provider:
            query += " AND provider_key = ?"
            params.append(provider)
        
        if tier:
            query += " AND tier = ?"
            params.append(tier)
        elif min_tier and min_tier in TIER_ORDER:
            min_ord = TIER_ORDER[min_tier]
            placeholders = ",".join("?" for t in TIER_ORDER if TIER_ORDER[t] <= min_ord)
            query += f" AND tier IN ({placeholders})"
            params.extend([t for t in TIER_ORDER if TIER_ORDER[t] <= min_ord])
        
        cursor.execute(query, params)
        rows = cursor.fetchall()
    
    return [
        Model(
            provider=row[0],
            model_id=row[1],
            label=row[2],
            tier=row[3],
            swe_score=row[4],
            context=row[5],
            is_free=bool(row[6]) if row[6] is not None else None,
        )
        for row in rows
    ]


def record_ping(
    model_id: str,
    provider_key: str,
    status: str,
    latency_ms: float | None = None,
    error_detail: str | None = None,
    db_path: Path | None = None,
) -> None:
    """Record a ping result to the database."""
    init_schema(db_path)
    
    with get_connection(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO ping_results (model_id, provider_key, status, latency_ms, error_detail)
            VALUES (?, ?, ?, ?, ?)
        """, (model_id, provider_key, status, latency_ms, error_detail))
        
        # Update last_pinged_at on models table
        cursor.execute("""
            UPDATE models SET last_pinged_at = CURRENT_TIMESTAMP
            WHERE provider_key = ? AND model_id = ?
        """, (provider_key, model_id))
        
        conn.commit()


def get_recent_ping(
    model_id: str,
    provider_key: str,
    ttl_seconds: int = 300,
    db_path: Path | None = None,
) -> dict | None:
    """
    Get most recent ping result if not expired.
    
    Returns None if no result or result is older than TTL.
    """
    init_schema(db_path)
    
    with get_connection(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT id, model_id, provider_key, status, latency_ms, error_detail, recorded_at
            FROM ping_results
            WHERE model_id = ? AND provider_key = ?
            ORDER BY recorded_at DESC
            LIMIT 1
        """, (model_id, provider_key))
        
        row = cursor.fetchone()
        if not row:
            return None
        
        # Check TTL
        recorded_at_str = row[6]
        if recorded_at_str:
            # Handle both naive and aware datetimes
            recorded_at_str = recorded_at_str.replace("Z", "+00:00")
            if "+" not in recorded_at_str and "-" not in recorded_at_str[-6:]:
                # Naive datetime, assume UTC
                recorded_at = datetime.fromisoformat(recorded_at_str).replace(tzinfo=timezone.utc)
            else:
                recorded_at = datetime.fromisoformat(recorded_at_str)
            
            age = datetime.now(timezone.utc) - recorded_at
            if age.total_seconds() > ttl_seconds:
                return None
        
        return {
            "id": row[0],
            "model_id": row[1],
            "provider_key": row[2],
            "status": row[3],
            "latency_ms": row[4],
            "error_detail": row[5],
            "recorded_at": row[6],
        }


def get_stats(db_path: Path | None = None) -> dict[str, Any]:
    """Get database statistics."""
    init_schema(db_path)
    
    with get_connection(db_path) as conn:
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM models WHERE is_active = 1")
        active_models = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM models WHERE is_active = 0")
        inactive_models = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(DISTINCT provider_key) FROM models WHERE is_active = 1")
        providers = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM ping_results")
        ping_results = cursor.fetchone()[0]
        
        cursor.execute("SELECT MAX(recorded_at) FROM ping_results")
        last_ping = cursor.fetchone()[0]
        
        return {
            "active_models": active_models,
            "inactive_models": inactive_models,
            "providers": providers,
            "ping_results": ping_results,
            "last_ping": last_ping,
        }


def get_provider_stats(db_path: Path | None = None) -> dict[str, dict]:
    """Get per-provider statistics."""
    init_schema(db_path)
    
    with get_connection(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT provider_key, COUNT(*) as model_count,
                   SUM(CASE WHEN is_active = 1 THEN 1 ELSE 0 END) as active_count
            FROM models
            GROUP BY provider_key
        """)
        
        return {
            row[0]: {
                "total_models": row[1],
                "active_models": row[2],
            }
            for row in cursor.fetchall()
        }


def replace_provider_models(
    provider_key: str,
    models: list[tuple[str, str, str, str, str, bool | None]],
    db_path: Path | None = None,
) -> int:
    """
    Replace all models for a provider with the given list.
    Each tuple: (model_id, label, tier, swe_score, context_window, is_free).

    Returns the number of models inserted.
    """
    init_schema(db_path)

    with get_connection(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM models WHERE provider_key = ?", (provider_key,))
        count = 0
        for model_id, label, tier, swe_score, context, is_free in models:
            is_free_int = 1 if is_free is True else (0 if is_free is False else None)
            cursor.execute("""
                INSERT INTO models (provider_key, model_id, label, tier, swe_score, context_window, is_free)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (provider_key, model_id, label, tier, swe_score, context, is_free_int))
            count += 1
        conn.commit()
        return count


def ensure_db_populated(db_path: Path | None = None) -> bool:
    """
    Ensure the database has a model list. If it has zero active models,
    sync from hardcoded providers. Call this before using DB as source for discovery.

    Returns True if DB now has models (was already populated or just synced).
    """
    init_schema(db_path)
    stats = get_stats(db_path)
    if stats["active_models"] > 0:
        return True
    sync_models(db_path)
    return True


def get_models_for_discovery(
    db_path: Path | None = None,
    tier: str | None = None,
    provider: str | None = None,
    min_tier: str | None = None,
    active_only: bool = True,
    free_only: bool = False,
) -> list[Model]:
    """
    Get model list for discovery/scan. Uses the database when populated
    (ensures DB is populated from hardcoded sync if empty). Use this
    instead of providers.filter_models for scan, list_models, get_fastest.
    """
    ensure_db_populated(db_path)
    return filter_models(
        db_path=db_path,
        tier=tier,
        provider=provider,
        min_tier=min_tier,
        active_only=active_only,
        free_only=free_only,
    )
