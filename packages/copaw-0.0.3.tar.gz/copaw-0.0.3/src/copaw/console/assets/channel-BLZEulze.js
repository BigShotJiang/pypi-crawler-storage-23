import{ar as o,as as s}from"./index-keQp0sCw.js";const t=(r,a)=>o.lang.round(s.parse(r)[a]);export{t as c};
