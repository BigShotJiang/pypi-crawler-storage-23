# -*- coding: utf-8 -*-
from .base import BaseJobRepository
from .json_repo import JsonJobRepository

__all__ = ["BaseJobRepository", "JsonJobRepository"]
