# -*- coding: utf-8 -*-
"""DingTalk channel package."""
from .channel import DingTalkChannel

__all__ = ["DingTalkChannel"]
