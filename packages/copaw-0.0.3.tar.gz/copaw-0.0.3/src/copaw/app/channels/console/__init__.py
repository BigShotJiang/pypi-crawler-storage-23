# -*- coding: utf-8 -*-
"""Console channel package."""
from .channel import ConsoleChannel

__all__ = ["ConsoleChannel"]
