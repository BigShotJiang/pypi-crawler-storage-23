# -*- coding: utf-8 -*-
"""QQ channel package."""
from .channel import QQChannel

__all__ = ["QQChannel"]
