# -*- coding: utf-8 -*-
"""Discord channel package."""
from .channel import DiscordChannel

__all__ = ["DiscordChannel"]
