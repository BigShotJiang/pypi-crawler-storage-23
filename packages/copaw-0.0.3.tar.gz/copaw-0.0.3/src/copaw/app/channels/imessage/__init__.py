# -*- coding: utf-8 -*-
"""iMessage channel package."""
from .channel import IMessageChannel

__all__ = ["IMessageChannel"]
