# -*- coding: utf-8 -*-
"""Feishu channel package."""
from .channel import FeishuChannel

__all__ = ["FeishuChannel"]
