# -*- coding: utf-8 -*-
"""Local model inference backends."""

from .base import LocalBackend

__all__ = ["LocalBackend"]
