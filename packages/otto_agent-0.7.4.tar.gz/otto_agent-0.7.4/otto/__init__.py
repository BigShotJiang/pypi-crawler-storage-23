"""Otto — AI agent platform."""

__version__ = "0.7.2"
