---
name: orchestration
description: Delegation and sub-agent orchestration patterns for async jobs, fan-out, fan-in, retries, and redirects.
---

# Orchestration Skill

Use this skill when deciding whether to delegate, how to split work, and how to manage delegated jobs.

## When to delegate vs do it directly

Delegate when the task is likely to take many tool rounds, needs deep analysis, or benefits from running in parallel.

Delegate when work includes:
- Multi-file investigation with synthesis
- Long-running file/code changes
- Independent subproblems that can run in parallel
- Validation-heavy work with retries

Do it directly when work is quick:
- Single short answer from current context
- One or two simple tool calls
- Tiny edits with immediate response

## Core orchestration tools

- `delegate_task`: Start async delegated work
- `list_jobs`: Check delegated job status
- `cancel_job`: Stop running delegated work
- `retry_job`: Re-run failed delegated work
- `redirect_job`: Course-correct running/failed delegated work with new instructions

## Patterns

### 1) Single delegated task

Use when there is one clear unit of work.

Include:
- `task` with concrete outcome
- `deliverables` with explicit outputs
- `constraints` for guardrails
- `validation_cmds` when correctness is testable

### 2) Sequential chain (`depends_on`)

Use for ordered steps where step B must wait for step A.

- Create A
- Create B with `depends_on: [A]`
- Add more steps similarly

### 3) Parallel fan-out + fan-in synthesis (`children`)

Use when sub-tasks can run independently but user should receive one combined result.

- Pass `children=[{task: ...}, ...]` to `delegate_task`
- The parent `task` becomes the synthesis step
- Parent runs only after children complete
- User receives one consolidated completion notification

Use this for:
- Multi-file audits with one final summary
- Parallel research/comparison tasks
- Independent analysis that needs a merged recommendation

## Retry and redirect

- Use `retry_job` when a job failed and should be re-run with optional new feedback.
- Use `redirect_job` when a running job is off-track or a failed job needs a different approach.

Provide specific correction feedback (what to do differently), not generic “try again”.

## Contract quality checklist

Before delegating, make sure contracts are concrete:
- Task states the desired end state clearly
- Deliverables name exact files/artifacts when possible
- Constraints capture must-follow limits
- Validation commands are meaningful and fast

## Anti-patterns

Avoid:
- Delegating trivial questions
- Creating unnecessary chains when one task is enough
- Delegating with vague tasks and no deliverables
- Overusing fan-in for simple sequential work

Keep orchestration simple and outcome-focused.