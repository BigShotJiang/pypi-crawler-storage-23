from __future__ import annotations

import asyncio
import queue as _queue
import readline
import sys
import threading as _threading

import clypi
import mistune

from otto.chat import COMMANDS, Chat, build_setup_completion_message
from otto.config import OTTO_HOME, BotConfig, ChannelConfig
from otto.log import get_logger

# Layout
_INDENT = "  "  # 2 spaces — aligns response with input text after bar

# Reusable styles
_dim = clypi.Styler(dim=True)
_bold = clypi.Styler(bold=True)
_italic = clypi.Styler(italic=True)
_code_style = clypi.Styler(fg="cyan")
_error_style = clypi.Styler(fg="red", bold=True)
_bar_str = clypi.style("┃", fg="cyan")
# Readline needs ANSI escapes wrapped in \x01..\x02 to correctly calculate
# visible prompt width.  Without these markers input() shows raw codes.
_bar_prompt = "\x01\033[36m\x02┃\x01\033[39m\x02"
_GENERIC_USER_ERROR = "There was an error with this request. Check otto logs for more information."

log = get_logger("otto.cli_chat")


def _get_username() -> str:
    import getpass

    try:
        return getpass.getuser()
    except Exception:
        return "default"


def _is_tty() -> bool:
    try:
        return sys.stdout.isatty()
    except Exception:
        return False


# -- Markdown rendering (mistune) ----------------------------------------------


class _AnsiRenderer(mistune.HTMLRenderer):
    """Render markdown to ANSI escape sequences for terminal display."""

    def text(self, text):
        return text

    def paragraph(self, text):
        return text + "\n"

    def heading(self, text, level, **attrs):
        return _bold(text) + "\n"

    def strong(self, text):
        return _bold(text)

    def emphasis(self, text):
        return _italic(text)

    def codespan(self, text):
        return _code_style(text)

    def block_code(self, code, info=None):
        return _dim(code.rstrip()) + "\n"

    def link(self, text, url, title=None):
        if text == url:
            return _code_style(url)
        return f"{text} {_dim('(' + url + ')')}"

    def image(self, text, url, title=None):
        return _dim(f"[image: {text or url}]")

    def block_quote(self, text):
        lines = text.rstrip("\n").split("\n")
        bar = _dim("│ ")
        return "\n".join(bar + ln for ln in lines) + "\n"

    def list(self, text, ordered, **attrs):
        return text + "\n"

    def list_item(self, text, **attrs):
        return f"  • {text.strip()}\n"

    def thematic_break(self):
        return _dim("─" * 40) + "\n"

    def linebreak(self):
        return "\n"

    def softbreak(self):
        return "\n"

    def strikethrough(self, text):
        return _dim(text)

    def table_cell(self, text, align=None, head=False):
        content = text.strip()
        if head:
            content = _bold(content)
        return content + "\t"

    def table_row(self, text):
        cells = [c for c in text.split("\t") if c]
        return "│ " + " │ ".join(cells) + " │\n"

    def table_head(self, text):
        return text + _dim("─" * 40) + "\n"

    def table_body(self, text):
        return text

    def table(self, text):
        return text + "\n"

    def inline_html(self, html):
        return html

    def block_html(self, html):
        return html


_md_parser = mistune.create_markdown(
    renderer=_AnsiRenderer(escape=False),
    plugins=["strikethrough", "table"],
)


def _render_md(text: str) -> str:
    """Render markdown to ANSI using mistune."""
    result = _md_parser(text)
    # Strip trailing newlines (caller handles spacing)
    return result.rstrip("\n")


class _MarkdownStream:
    """Stateful streaming markdown-to-ANSI converter."""

    def __init__(self) -> None:
        self._in_bold = False
        self._in_italic = False
        self._in_code = False
        self._in_code_block = False
        self._in_heading = False
        self._at_line_start = True
        self._hash_count = 0
        self._pending = ""

    def _flush_buf(self, buf: list[str], parts: list[str]) -> None:
        if buf:
            parts.append(self._styled("".join(buf)))
            buf.clear()

    def feed(self, chunk: str) -> str:
        text = self._pending + chunk
        self._pending = ""
        parts: list[str] = []
        buf: list[str] = []
        i = 0
        n = len(text)

        while i < n:
            remaining = n - i

            # --- inside code block: only look for closing ``` ---
            if self._in_code_block:
                if text[i : i + 3] == "```":
                    self._flush_buf(buf, parts)
                    self._in_code_block = False
                    i += 3
                    continue
                if remaining < 3 and all(c == "`" for c in text[i:]):
                    self._flush_buf(buf, parts)
                    self._pending = text[i:]
                    return "".join(parts)
                buf.append(text[i])
                i += 1
                continue

            # --- newline: end heading if active, reset line-start ---
            if text[i] == "\n":
                self._flush_buf(buf, parts)
                if self._in_heading:
                    self._in_heading = False
                parts.append("\n")
                self._at_line_start = True
                self._hash_count = 0
                i += 1
                continue

            # --- heading detection at line start ---
            if self._at_line_start and not self._in_code:
                if text[i] == "#":
                    self._hash_count += 1
                    i += 1
                    if i >= n:
                        self._pending = "#" * self._hash_count
                        self._hash_count = 0
                        return "".join(parts)
                    continue
                if self._hash_count > 0 and text[i] == " ":
                    self._in_heading = True
                    self._at_line_start = False
                    self._hash_count = 0
                    i += 1
                    continue
                if self._hash_count > 0:
                    buf.extend(["#"] * self._hash_count)
                    self._hash_count = 0
                self._at_line_start = False

            # --- opening code block: ``` ---
            if text[i : i + 3] == "```":
                self._flush_buf(buf, parts)
                self._in_code_block = True
                i += 3
                while i < n and text[i] != "\n":
                    i += 1
                if i < n:
                    i += 1
                continue

            # Possible partial ``` at end of chunk
            if remaining < 3 and not self._in_code:
                tail = text[i:]
                if all(c == "`" for c in tail):
                    self._flush_buf(buf, parts)
                    self._pending = tail
                    return "".join(parts)

            # Inline code toggle: `
            if text[i] == "`":
                self._flush_buf(buf, parts)
                self._in_code = not self._in_code
                i += 1
                continue

            # Bold toggle: **  (not inside code)
            if text[i : i + 2] == "**" and not self._in_code:
                self._flush_buf(buf, parts)
                self._in_bold = not self._in_bold
                i += 2
                continue

            # Italic toggle: single * (not inside code, not **)
            if (
                text[i] == "*"
                and not self._in_code
                and (i + 1 >= n or text[i + 1] != "*")
                and (i == 0 or text[i - 1] != "*")
            ):
                # Could be start of ** if at end of chunk
                if remaining == 1:
                    self._flush_buf(buf, parts)
                    self._pending = "*"
                    return "".join(parts)
                self._flush_buf(buf, parts)
                self._in_italic = not self._in_italic
                i += 1
                continue

            # Link: [text](url) — render as "text (url)" with dim url
            if text[i] == "[" and not self._in_code:
                # Try to find complete [text](url) pattern
                close_bracket = text.find("]", i + 1)
                if close_bracket != -1 and close_bracket + 1 < n and text[close_bracket + 1] == "(":
                    close_paren = text.find(")", close_bracket + 2)
                    if close_paren != -1:
                        self._flush_buf(buf, parts)
                        link_text = text[i + 1 : close_bracket]
                        url = text[close_bracket + 2 : close_paren]
                        if link_text == url:
                            parts.append(_code_style(url))
                        else:
                            parts.append(f"{link_text} {_dim('(' + url + ')')}")
                        i = close_paren + 1
                        continue
                # Incomplete link — buffer for next chunk if near end
                if close_bracket == -1 and remaining < 80:
                    self._flush_buf(buf, parts)
                    self._pending = text[i:]
                    return "".join(parts)

            buf.append(text[i])
            i += 1

        if buf:
            parts.append(self._styled("".join(buf)))
        return "".join(parts)

    def _styled(self, text: str) -> str:
        if not text:
            return ""
        if self._in_code_block:
            return _dim(text)
        if self._in_code:
            return _code_style(text)
        if self._in_bold or self._in_heading:
            return _bold(text)
        if self._in_italic:
            return _italic(text)
        return text


# -- Renderer ------------------------------------------------------------------


def _format_tool_args(name: str, args: dict) -> str:
    for key in ("query", "q", "pattern", "url", "path", "command", "text"):
        if key in args and isinstance(args[key], str):
            val = args[key]
            if len(val) > 40:
                val = val[:37] + "..."
            return f'"{val}"'
    return ""


class CLIRenderer:
    output_format = "markdown"

    def __init__(self, model_label: str = "") -> None:
        self._has_content = False
        self._current_tool: str | None = None
        self._current_tool_args: dict = {}
        self._in_tool_box = False
        self._tool_box_has_footer = False
        self._spinner_visible = False
        self._model_label = model_label
        self._md = _MarkdownStream()

    def on_model_change(self, model: str) -> None:
        self._model_label = model.rsplit("/", 1)[-1] if "/" in model else model

    def show_spinner(self) -> None:
        if _is_tty() and self._model_label:
            sys.stdout.write(f"{_INDENT}{_dim(self._model_label + ' ···')}\n")
            sys.stdout.flush()
            self._spinner_visible = True

    def _clear_spinner(self) -> None:
        if self._spinner_visible and _is_tty():
            sys.stdout.write("\033[A\r\033[K")
            sys.stdout.flush()
        self._spinner_visible = False

    def on_text(self, chunk: str) -> None:
        self._clear_spinner()
        self._close_tool_box()
        styled = self._md.feed(chunk)
        if not self._has_content:
            styled = _INDENT + styled
        # Indent any mid-chunk newlines
        styled = styled.replace("\n", "\n" + _INDENT)
        sys.stdout.write(styled)
        sys.stdout.flush()
        self._has_content = True

    def on_tool_start(self, name: str, args: dict) -> None:
        self._clear_spinner()
        if self._has_content:
            sys.stdout.write("\n")
            self._has_content = False
        if self._tool_box_has_footer and _is_tty():
            sys.stdout.write("\033[A\r\033[K")
        if not self._in_tool_box:
            sys.stdout.write(f"{_INDENT}{_dim('┌─ tools ' + '─' * 35)}\n")
            self._in_tool_box = True
        args_str = _format_tool_args(name, args)
        suffix = f" {args_str}" if args_str else ""
        sys.stdout.write(f"{_INDENT}{_dim('│')} ◌ {name}{suffix}\n")
        sys.stdout.flush()
        self._current_tool = name
        self._current_tool_args = args
        self._tool_box_has_footer = False

    def on_tool_end(self, name: str, result: str) -> None:
        is_error = isinstance(result, str) and (
            result.startswith("Error") or result.startswith("error")
        )
        marker = "✗" if is_error else "✓"
        if self._in_tool_box:
            args_str = _format_tool_args(name, self._current_tool_args)
            suffix = f" {args_str}" if args_str else ""
            line = f"{_INDENT}{_dim('│')} {marker} {name}{suffix}\n"
            if _is_tty():
                sys.stdout.write(f"\033[A\r\033[K{line}")
            else:
                sys.stdout.write(line)
            sys.stdout.write(f"{_INDENT}{_dim('└' + '─' * 43)}\n")
            self._tool_box_has_footer = True
        else:
            line = _dim(f"◌ {name} {marker}")
            if _is_tty():
                sys.stdout.write(f"\033[A\r\033[K{_INDENT}{line}\n")
            else:
                sys.stdout.write(f"{_INDENT}{line}\n")
            self._tool_box_has_footer = False
        sys.stdout.flush()
        self._current_tool = None
        self._current_tool_args = {}

    def _close_tool_box(self) -> None:
        if self._in_tool_box and not self._tool_box_has_footer:
            sys.stdout.write(f"{_INDENT}{_dim('└' + '─' * 43)}\n")
        self._in_tool_box = False
        self._tool_box_has_footer = False

    async def send_text(self, text: str) -> None:
        self._close_tool_box()
        if self._has_content:
            sys.stdout.write("\n")
            self._has_content = False
        rendered = _render_md(text)
        for line in rendered.split("\n"):
            sys.stdout.write(f"{_INDENT}{line}\n")
        sys.stdout.write("\n")
        sys.stdout.flush()
        self._md = _MarkdownStream()

    async def send_with_buttons(self, text: str, buttons: list[list[tuple[str, str]]]) -> None:
        self._close_tool_box()
        if self._has_content:
            sys.stdout.write("\n")
            self._has_content = False
        rendered = _render_md(text)
        for line in rendered.split("\n"):
            sys.stdout.write(f"{_INDENT}{line}\n")
        idx = 1
        parts = []
        for row in buttons:
            for label, _data in row:
                parts.append(f"{idx}. {label}")
                idx += 1
        sys.stdout.write(f"{_INDENT}{_dim('  '.join(parts))}\n")
        sys.stdout.write("\n")
        sys.stdout.flush()
        self._md = _MarkdownStream()

    async def show_error(self, error: str) -> None:
        sys.stderr.write(f"{_INDENT}{_error_style('Error: ' + error)}\n")
        sys.stderr.flush()

    async def send_file(self, path: str, caption: str | None = None) -> None:
        self._close_tool_box()
        if self._has_content:
            sys.stdout.write("\n")
            self._has_content = False
        sys.stdout.write(f"{_INDENT}\U0001f4ce {path}\n")
        if caption:
            sys.stdout.write(f"{_INDENT}{caption}\n")
        sys.stdout.write("\n")
        sys.stdout.flush()

    async def flush(self) -> None:
        self._close_tool_box()
        if self._has_content:
            self._has_content = False
        sys.stdout.write("\n")
        sys.stdout.write(f"{_INDENT}{_dim('─ ' * 20)}\n")
        sys.stdout.write("\n")
        sys.stdout.flush()
        self._md = _MarkdownStream()

    def on_session_restored(self, chat_id: str, session_store) -> None:
        if not _is_tty():
            return
        sys.stdout.write("\033[2J\033[3J\033[H")
        session = session_store.load(chat_id)
        for message in session.messages:
            role = message.get("role")
            content = message.get("content")
            if not isinstance(content, str) or not content:
                continue
            if role == "user":
                for line in content.split("\n"):
                    sys.stdout.write(f"{_bar_str} {line}\n")
                sys.stdout.write("\n")
            elif role == "assistant":
                rendered = _render_md(content)
                for line in rendered.split("\n"):
                    sys.stdout.write(f"{_INDENT}{line}\n")
                sys.stdout.write("\n")
                sys.stdout.write(f"{_INDENT}{_dim('─ ' * 20)}\n")
                sys.stdout.write("\n")
        sys.stdout.flush()


# -- Channel -------------------------------------------------------------------


_SLASH_COMMANDS = sorted(f"/{cmd}" for cmd in COMMANDS)
_SLASH_COMMANDS.extend(["/exit", "/quit", "/q"])

_HISTORY_FILE = OTTO_HOME / "cli_history"


def _slash_completer(text: str, state: int) -> str | None:
    if text.startswith("/"):
        matches = [cmd for cmd in _SLASH_COMMANDS if cmd.startswith(text)]
    else:
        return None
    if state < len(matches):
        return matches[state]
    return None


def _setup_readline() -> None:
    readline.set_completer(_slash_completer)
    readline.set_completer_delims(" ")
    # libedit (macOS/some Linux) uses different bind syntax than GNU readline.
    if "libedit" in (readline.__doc__ or ""):
        readline.parse_and_bind("bind ^I rl_complete")
    else:
        readline.parse_and_bind("tab: complete")
    readline.set_history_length(500)
    try:
        if _HISTORY_FILE.exists():
            readline.read_history_file(str(_HISTORY_FILE))
    except OSError:
        pass


def _save_readline_history() -> None:
    try:
        _HISTORY_FILE.parent.mkdir(parents=True, exist_ok=True)
        readline.write_history_file(str(_HISTORY_FILE))
    except OSError:
        pass


class CLIChatChannel:
    def __init__(
        self,
        chat: Chat,
        bot_config: BotConfig,
        channel_config: ChannelConfig,
        resume_id: str | None = None,
    ):
        self._chat = chat
        self._bot_config = bot_config
        self._channel_config = channel_config
        self._resume_id = resume_id
        self._running = False
        model = bot_config.model or "default"
        short_model = model.rsplit("/", 1)[-1] if "/" in model else model
        self._renderer = CLIRenderer(model_label=short_model)

    @staticmethod
    def _friendly_error_message(exc: BaseException) -> str:
        lower = str(exc).lower()
        if "github_copilot" in lower or "copilot" in lower:
            if "editor-version" in lower or "ide auth" in lower:
                return "Copilot auth is incomplete. Run `otto auth login copilot` and retry."
            if "connection error" in lower:
                return "Could not reach GitHub Copilot. Check network/VPN and retry."
        return _GENERIC_USER_ERROR

    @property
    def alias(self) -> str:
        return self._bot_config.name

    async def _await_input(self) -> str | None:
        """Read a single input line without pre-printing the next prompt."""

        result_queue: _queue.SimpleQueue[str | None] = _queue.SimpleQueue()

        def _reader_once() -> None:
            try:
                result_queue.put(input(f"{_bar_prompt} "))
            except EOFError:
                result_queue.put(None)
            except Exception:
                result_queue.put(None)

        _threading.Thread(target=_reader_once, daemon=True, name="cli-input-once").start()

        while True:
            try:
                return result_queue.get_nowait()
            except _queue.Empty:
                await asyncio.sleep(0.05)

    async def start(self) -> None:
        """Run the interactive input loop."""
        self._running = True
        chat_id = _get_username()

        if _is_tty():
            _setup_readline()

        self._print_startup_header()
        if self._resume_id:
            self._chat._session_store.restore(chat_id, self._resume_id)
            self.replay_history(chat_id)
        else:
            # Fresh session — archive any existing one
            self._chat._session_store.rotate(chat_id)
            self._print_setup_completion_message()

        while self._running:
            try:
                line = await self._await_input()
                if line is None:  # EOF (Ctrl+D)
                    sys.stdout.write(_dim("exit") + "\n")
                    break
                line = line.strip()
                if not line:
                    continue
                # Handle multiline: if line is '"""', read until next '"""'
                if line == '"""':
                    line = await self._read_multiline()

                # CLI-local commands
                if line.lower() in ("/exit", "/quit", "/q"):
                    sys.stdout.write(_dim("bye!") + "\n")
                    break

                # Echo user input + show spinner
                self._echo_input(line)
                self._renderer.show_spinner()

                await self._chat.handle_message(
                    chat_id=chat_id,
                    text=line,
                    renderer=self._renderer,
                )
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                log.exception("cli chat request failed", error=str(exc), bot=self.alias)
                await self._renderer.show_error(self._friendly_error_message(exc))
            except KeyboardInterrupt:
                # Ctrl+C — exit gracefully.  The input thread is a daemon so
                # asyncio cleanup won't hang waiting for it.
                sys.stdout.write("\n" + _dim("ctrl+c — exiting") + "\n")
                break

        self._running = False
        if _is_tty():
            _save_readline_history()
        print()

    async def stop(self) -> None:
        self._running = False

    def _echo_input(self, text: str) -> None:
        """Echo user input as a highlighted block with the cyan bar."""
        # Move up over the prompt line and rewrite.
        if _is_tty():
            sys.stdout.write("\033[A\r\033[K")
        self._print_user_block(text)
        sys.stdout.flush()

    async def _read_multiline(self) -> str:
        lines: list[str] = []
        loop = asyncio.get_event_loop()
        while True:
            line = await loop.run_in_executor(None, lambda: input("... "))
            if line.strip() == '"""':
                break
            lines.append(line)
        return "\n".join(lines)

    def replay_history(self, chat_id: str) -> None:
        sys.stdout.write("\033[2J\033[3J\033[H")
        self._print_startup_header()

        session = self._chat._session_store.load(chat_id)
        for message in session.messages:
            role = message.get("role")
            content = message.get("content")
            if not isinstance(content, str) or not content:
                continue

            if role == "user":
                self._print_user_block(content)
                continue
            if role != "assistant":
                continue

            rendered = _render_md(content)
            for line in rendered.split("\n"):
                sys.stdout.write(f"{_INDENT}{line}\n")
            sys.stdout.write("\n")
            sys.stdout.write(f"{_INDENT}{_dim('─ ' * 20)}\n")
            sys.stdout.write("\n")
        sys.stdout.flush()

    def _print_startup_header(self) -> None:
        name = self._bot_config.name
        model = self._bot_config.model or "default"
        short_model = model.rsplit("/", 1)[-1] if "/" in model else model
        sys.stdout.write(f"\n\U0001f9a6 {_bold(name)} {_dim('\u00b7 ' + short_model)}\n\n")
        sys.stdout.flush()

    def _onboarding_message(self) -> str:
        return build_setup_completion_message(
            self._bot_config.channels,
            bot_name=self._bot_config.name,
            telegram_handle=None,
            output_format="markdown",
        )

    def _print_setup_completion_message(self) -> None:
        message = self._onboarding_message()
        if not message:
            return
        for line in _render_md(message).split("\n"):
            sys.stdout.write(f"{_INDENT}{line}\n")
        sys.stdout.write("\n")

    def _print_user_block(self, text: str) -> None:
        for line in text.split("\n"):
            sys.stdout.write(f"{_bar_str} {line}\n")
        sys.stdout.write("\n")
