"""Setup Core V2 — pure business-logic engine for Otto setup."""

from otto.setup_core.engine import build_plan, evaluate_requirements
from otto.setup_core.models import (
    OAUTH_CAPABLE_PROVIDERS,
    OAUTH_MODEL_PREFIXES,
    PROVIDER_ENV_VARS,
    CredentialGap,
    SetupChoice,
    SetupPlan,
    SetupRequirements,
    SetupValidationError,
)

__all__ = [
    "OAUTH_CAPABLE_PROVIDERS",
    "OAUTH_MODEL_PREFIXES",
    "PROVIDER_ENV_VARS",
    "SetupChoice",
    "SetupRequirements",
    "CredentialGap",
    "SetupPlan",
    "SetupValidationError",
    "evaluate_requirements",
    "build_plan",
]
