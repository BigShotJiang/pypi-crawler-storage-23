"""GitHub Copilot OAuth flow (RFC 8628 device code)."""

from __future__ import annotations

import asyncio
import base64
import inspect
import json
import os
import re
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import aiohttp

from otto.log import get_logger

log = get_logger(__name__)

_CLIENT_ID = base64.b64decode("SXYxLmI1MDdhMDhjODdlY2ZlOTg=").decode("ascii")
_DEFAULT_DOMAIN = "github.com"
_DEFAULT_POLL_INTERVAL_SECONDS = 5.0
_POLL_TIMEOUT_SECONDS = 900
_EXPIRY_BUFFER_SECONDS = 300

_COPILOT_HEADERS = {
    "User-Agent": "GitHubCopilotChat/0.35.0",
    "Editor-Version": "vscode/1.107.0",
    "Editor-Plugin-Version": "copilot-chat/0.35.0",
    "Copilot-Integration-Id": "vscode-chat",
}


async def _maybe_await(value: Any) -> Any:
    if inspect.isawaitable(value):
        return await value
    return value


def normalize_domain(raw: str) -> str | None:
    """Normalize domain/URL input into a hostname."""
    trimmed = str(raw or "").strip()
    if not trimmed:
        return None

    try:
        candidate = trimmed if "://" in trimmed else f"https://{trimmed}"
        parsed = urlparse(candidate)
    except Exception:
        return None

    host = (parsed.hostname or "").strip().lower()
    return host or None


def _urls(domain: str) -> dict[str, str]:
    return {
        "device_code": f"https://{domain}/login/device/code",
        "access_token": f"https://{domain}/login/oauth/access_token",
        "copilot_token": f"https://api.{domain}/copilot_internal/v2/token",
    }


def _base_url_from_token(token: str, enterprise: str | None = None) -> str:
    match = re.search(r"proxy-ep=([^;]+)", token)
    if match:
        endpoint = match.group(1).replace("proxy.", "api.", 1)
        return f"https://{endpoint}"
    if enterprise:
        return f"https://copilot-api.{enterprise}"
    return "https://api.individual.githubcopilot.com"


def get_api_base(credentials: dict[str, Any]) -> str:
    access = str(credentials.get("access", "")).strip()
    enterprise_raw = credentials.get("enterpriseUrl")
    enterprise = (
        normalize_domain(str(enterprise_raw))
        if isinstance(enterprise_raw, str) and enterprise_raw.strip()
        else None
    )
    return _base_url_from_token(access, enterprise)


async def _exchange_copilot_token(
    github_token: str,
    enterprise: str | None,
    urls: dict[str, str],
) -> dict[str, Any]:
    async with aiohttp.ClientSession() as session:
        async with session.get(
            urls["copilot_token"],
            headers={
                "Accept": "application/json",
                "Authorization": f"Bearer {github_token}",
                **_COPILOT_HEADERS,
            },
        ) as response:
            if response.status != 200:
                body = await response.text()
                raise RuntimeError(f"Copilot token exchange failed ({response.status}): {body}")
            payload = await response.json()

    token = str(payload.get("token", "")).strip()
    expires_at_raw = payload.get("expires_at")
    try:
        expires_at = float(expires_at_raw)
    except (TypeError, ValueError) as exc:
        raise RuntimeError("Copilot token response missing valid expires_at.") from exc

    if not token:
        raise RuntimeError("Copilot token response missing token.")

    return {
        "provider": "copilot",
        "type": "oauth",
        "refresh": github_token,
        "access": token,
        "expires": expires_at - _EXPIRY_BUFFER_SECONDS,
        "enterpriseUrl": enterprise,
    }


async def login(
    on_auth_url: Callable[[str, str], Any],
    on_prompt: Callable[[dict[str, Any]], Any],
    on_progress: Callable[[str], Any] | None = None,
    signal_cancelled: Callable[[], bool] | None = None,
) -> dict[str, Any]:
    """Run GitHub Copilot OAuth device-code flow and token exchange."""
    if not callable(on_prompt):
        raise RuntimeError("Copilot login requires an on_prompt callback.")

    raw_enterprise = await _maybe_await(
        on_prompt(
            {
                "message": "GitHub Enterprise URL/domain (blank for github.com)",
                "allowEmpty": True,
            }
        )
    )
    trimmed_enterprise = str(raw_enterprise or "").strip()
    enterprise = normalize_domain(trimmed_enterprise) if trimmed_enterprise else None
    if trimmed_enterprise and not enterprise:
        raise RuntimeError("Invalid GitHub Enterprise URL/domain")

    domain = enterprise or _DEFAULT_DOMAIN
    urls = _urls(domain)

    async with aiohttp.ClientSession() as session:
        async with session.post(
            urls["device_code"],
            json={"client_id": _CLIENT_ID, "scope": "read:user"},
            headers={"Accept": "application/json", "User-Agent": _COPILOT_HEADERS["User-Agent"]},
        ) as response:
            if response.status != 200:
                body = await response.text()
                raise RuntimeError(f"Device code request failed ({response.status}): {body}")
            device_payload = await response.json()

    device_code = str(device_payload.get("device_code", "")).strip()
    user_code = str(device_payload.get("user_code", "")).strip()
    verification_uri = str(device_payload.get("verification_uri", "")).strip()

    if not device_code or not user_code or not verification_uri:
        raise RuntimeError("Device code response missing required fields.")

    if callable(on_auth_url):
        try:
            result = on_auth_url(verification_uri, f"Enter code: {user_code}")
        except TypeError:
            result = on_auth_url(verification_uri, "")
        await _maybe_await(result)

    if callable(on_progress):
        await _maybe_await(on_progress("Waiting for device authorization..."))

    github_token: str | None = None
    deadline = time.time() + _POLL_TIMEOUT_SECONDS
    interval_seconds = _DEFAULT_POLL_INTERVAL_SECONDS

    async with aiohttp.ClientSession() as session:
        while time.time() < deadline:
            if signal_cancelled and signal_cancelled():
                raise RuntimeError("Login cancelled")

            async with session.post(
                urls["access_token"],
                json={
                    "client_id": _CLIENT_ID,
                    "device_code": device_code,
                    "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                },
                headers={
                    "Accept": "application/json",
                    "User-Agent": _COPILOT_HEADERS["User-Agent"],
                },
            ) as response:
                try:
                    payload = await response.json()
                except Exception:
                    payload = {}

            access_token = payload.get("access_token")
            if isinstance(access_token, str) and access_token:
                github_token = access_token
                break

            error = str(payload.get("error", "")).strip()
            if error == "authorization_pending":
                await asyncio.sleep(interval_seconds)
                continue
            if error == "slow_down":
                interval_seconds += 5.0
                await asyncio.sleep(interval_seconds)
                continue
            if error == "expired_token":
                raise RuntimeError("Device authorization expired. Start login again.")

            raise RuntimeError(f"Device flow failed: {error or 'unknown_error'}")
        else:
            raise RuntimeError("Device flow timed out after 900 seconds.")

    if github_token is None:
        raise RuntimeError("Device flow did not return an access token.")

    credentials = await _exchange_copilot_token(github_token, enterprise, urls)
    log.debug("Copilot OAuth login succeeded", enterprise=enterprise or _DEFAULT_DOMAIN)
    return credentials


async def refresh_token(
    refresh: str,
    enterprise_url: str | None = None,
    **kwargs: Any,
) -> dict[str, Any]:
    """Refresh Copilot access token using a GitHub OAuth token."""
    enterprise_alias = kwargs.get("enterpriseUrl")
    if isinstance(enterprise_alias, str) and enterprise_alias.strip():
        enterprise_url = enterprise_alias

    enterprise = normalize_domain(enterprise_url) if enterprise_url else None
    domain = enterprise or _DEFAULT_DOMAIN
    urls = _urls(domain)
    return await _exchange_copilot_token(refresh, enterprise, urls)


def get_api_key(credentials: dict[str, Any]) -> str:
    """Extract a usable API key from Copilot credentials."""
    return str(credentials["access"])


def sync_litellm_token_cache(credentials: dict[str, Any]) -> None:
    """Write Copilot credentials to LiteLLM's github_copilot token cache.

    LiteLLM's native github_copilot adapter reads tokens from files, not from
    request kwargs. We keep Otto's auth flow but sync into the expected cache.
    """
    refresh = str(credentials.get("refresh", "")).strip()
    access = str(credentials.get("access", "")).strip()
    if not refresh or not access:
        raise RuntimeError("Copilot credentials missing refresh/access tokens.")

    raw_expires = credentials.get("expires")
    try:
        expires_at = float(raw_expires)
    except (TypeError, ValueError) as exc:
        raise RuntimeError("Copilot credentials missing valid expires timestamp.") from exc

    token_dir_raw = os.environ.get("GITHUB_COPILOT_TOKEN_DIR")
    token_dir = (
        Path(token_dir_raw).expanduser()
        if token_dir_raw
        else Path("~/.config/litellm/github_copilot").expanduser()
    )
    token_dir.mkdir(parents=True, exist_ok=True)

    access_file = token_dir / os.environ.get("GITHUB_COPILOT_ACCESS_TOKEN_FILE", "access-token")
    api_key_file = token_dir / os.environ.get("GITHUB_COPILOT_API_KEY_FILE", "api-key.json")

    access_file.write_text(refresh, encoding="utf-8")
    os.chmod(access_file, 0o600)

    payload = {
        "token": access,
        "expires_at": expires_at,
        "endpoints": {
            "api": get_api_base(credentials),
        },
    }
    api_key_file.write_text(json.dumps(payload), encoding="utf-8")
    os.chmod(api_key_file, 0o600)
