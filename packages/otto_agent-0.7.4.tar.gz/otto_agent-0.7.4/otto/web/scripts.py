"""JavaScript for dashboard and setup wizard."""

from __future__ import annotations

DASHBOARD_JS = """
<script>
(function () {
    var panels  = document.querySelectorAll('.panel');
    var navBtns = document.querySelectorAll('.sb-item[data-panel]');
    var topTitle = document.getElementById('topbar-title');

    function activate(id) {
        var found = false;
        panels.forEach(function (p) {
            var on = p.id === 'panel-' + id;
            p.classList.toggle('active', on);
            if (on) found = true;
        });
        navBtns.forEach(function (b) {
            var on = b.dataset.panel === id;
            b.classList.toggle('active', on);
            if (on && topTitle) topTitle.textContent = b.textContent.trim();
        });
        if (found) history.replaceState(null, '', '#' + id);
    }

    navBtns.forEach(function (b) {
        b.addEventListener('click', function () { activate(b.dataset.panel); });
    });

    var hash = location.hash.replace('#', '');
    if (hash) activate(hash);
    else { var f = navBtns[0]; if (f) activate(f.dataset.panel); }

    window.toggleToken = function () {
        var f = document.getElementById('telegram_token');
        if (f) f.type = f.type === 'password' ? 'text' : 'password';
    };
    window.doAction = function (endpoint) {
        fetch(endpoint, { method: 'POST' }).then(function () {
            window.location.reload();
        });
    };
})();
</script>
"""

WIZARD_JS = """
<script>
(function () {
    var step = 1, total = 4;
    var oauthState = window.ottoWizardOAuthState || {};

    var oauthProviders = [
        { key: 'anthropic', display: 'Anthropic', prefixes: ['anthropic/', 'claude-code/'] },
        { key: 'openai', display: 'OpenAI', prefixes: ['openai/', 'codex/'] },
        { key: 'google', display: 'Google', prefixes: ['google/', 'gemini-cli/', 'vertex_ai/'] },
        { key: 'copilot', display: 'GitHub Copilot', prefixes: ['copilot/', 'github_copilot/'] }
    ];

    function detectOAuthProvider(model) {
        var normalized = (model || '').trim().toLowerCase();
        if (!normalized) return null;
        for (var i = 0; i < oauthProviders.length; i++) {
            var provider = oauthProviders[i];
            for (var j = 0; j < provider.prefixes.length; j++) {
                if (normalized.indexOf(provider.prefixes[j]) === 0) return provider;
            }
        }
        return null;
    }

    function updateAuthField() {
        var modelInput = document.getElementById('setup_model');
        var apiInput = document.getElementById('setup_api_key');
        var authMode = document.getElementById('setup_auth_mode');
        var label = document.getElementById('setup_api_key_label');
        var hint = document.getElementById('setup_api_key_hint');
        if (!modelInput || !apiInput || !authMode || !label || !hint) return;

        var provider = detectOAuthProvider(modelInput.value);
        if (!provider) {
            authMode.value = 'api_key';
            label.innerHTML = 'API key <span class="hint" style="display:inline; text-transform: none; font-weight: normal;">(optional)</span>';
            apiInput.placeholder = 'sk-... or leave blank to use env var';
            apiInput.disabled = false;
            hint.textContent = 'Used for API-key providers.';
            return;
        }

        authMode.value = 'oauth';
        apiInput.value = '';
        apiInput.disabled = true;

        if (oauthState[provider.key]) {
            label.textContent = provider.display + ' OAuth';
            apiInput.placeholder = 'Using saved OAuth credentials';
            hint.textContent = 'Stored OAuth credentials detected. Continue to use them.';
            return;
        }

        label.textContent = 'Authenticate with ' + provider.display;
        apiInput.placeholder = 'Run: otto auth login ' + provider.key;
        hint.textContent = 'OAuth credentials are required. Run: otto auth login ' + provider.key;
    }

    function show(n) {
        for (var i = 1; i <= total; i++) {
            var el = document.getElementById('sw-step-' + i);
            if (el) el.classList.toggle('active', i === n);
            var dot = document.getElementById('sw-fill-' + i);
            if (dot) dot.classList.toggle('active', i <= n);
        }
        document.getElementById('sw-back').hidden   = (n === 1);
        document.getElementById('sw-next').hidden   = (n === total);
        document.getElementById('sw-submit').hidden = (n !== total);
        if (n === total) buildReview();
    }

    function buildReview() {
        var model = (document.getElementById('setup_model') || {}).value || '\\u2014';
        var tgSel = document.querySelector('input[name="_add_telegram"]:checked');
        var tg    = tgSel && tgSel.value === 'yes' ? 'Yes' : 'No';
        var name  = (document.getElementById('setup_owner_name') || {}).value || 'owner';
        var rows  = [['Model', model], ['Telegram', tg], ['Owner', name]];
        document.getElementById('sw-review').innerHTML = rows.map(function (r) {
            return '<div class="sw-review-row"><span class="sw-review-key">' + r[0] +
                   '</span><span class="sw-review-val">' + r[1] + '</span></div>';
        }).join('');
    }

    window.swNext = function () { if (step < total) { step++; show(step); } };
    window.swBack = function () { if (step > 1)     { step--; show(step); } };

    var modelInput = document.getElementById('setup_model');
    if (modelInput) {
        modelInput.addEventListener('input', updateAuthField);
        modelInput.addEventListener('change', updateAuthField);
    }
    updateAuthField();

    document.querySelectorAll('input[name="_add_telegram"]').forEach(function (r) {
        r.addEventListener('change', function () {
            var add = r.value === 'yes' && r.checked;
            var tgf = document.getElementById('sw-tg-fields');
            if (tgf) tgf.hidden = !add;
            var tw = document.getElementById('sw-tid-wrap');
            if (tw) tw.hidden = !add;
        });
    });
})();
</script>
"""
