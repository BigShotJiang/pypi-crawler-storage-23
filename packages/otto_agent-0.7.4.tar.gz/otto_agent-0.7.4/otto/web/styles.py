"""CSS design tokens and stylesheet — dark-only, ported from beautiful-html-report."""

from __future__ import annotations

FONT_LINK = (
    '<link rel="preconnect" href="https://fonts.googleapis.com">'
    '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>'
    '<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600'
    '&display=swap" rel="stylesheet">'
)

# ---------------------------------------------------------------------------
# Single CSS constant — beautiful-html-report dark palette + gold accent
# ---------------------------------------------------------------------------

CSS = """
:root {
    --bg-page: #111110;
    --bg-surface: #1A1A18;
    --bg-sidebar: #0D0D0C;
    --border: #2A2A28;
    --text-primary: #F0EEE8;
    --text-muted: #8A8880;
    --accent: #B8974E;
    --status-running: #4ade80;
    --font-main: 'Inter', sans-serif;
}

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {
    font-family: var(--font-main);
    background-color: var(--bg-page);
    color: var(--text-primary);
    line-height: 1.5;
    font-size: 14px;
    display: flex;
    height: 100vh;
    overflow: hidden;
}

/* Typography */
h1, h2, h3, h4 {
    font-weight: 500;
    color: var(--text-primary);
}

.small-caps {
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    font-weight: 600;
    color: var(--text-muted);
}

/* Layout */
.sidebar {
    width: 280px;
    background-color: var(--bg-sidebar);
    border-right: 1px solid var(--border);
    display: flex;
    flex-direction: column;
    padding: 24px 0;
}

.main-content {
    flex: 1;
    overflow-y: auto;
    padding: 48px;
    display: flex;
    flex-direction: column;
    gap: 48px;
}

/* Sidebar / HUD */
.brand {
    padding: 0 24px;
    margin-bottom: 32px;
    display: flex;
    align-items: center;
    gap: 12px;
}

.brand-name {
    font-size: 14px;
    letter-spacing: 0.1em;
    color: var(--text-primary);
}

.status-dot {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background-color: var(--status-running);
    box-shadow: 0 0 8px var(--status-running);
}

.global-hud {
    padding: 0 24px;
    margin-bottom: 48px;
    display: flex;
    flex-direction: column;
    gap: 16px;
}

.hud-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 12px;
}

.hud-label {
    color: var(--text-muted);
}

.hud-value {
    color: var(--text-primary);
    font-family: monospace;
}

.nav-menu {
    list-style: none;
    display: flex;
    flex-direction: column;
    margin-bottom: auto;
}

.nav-item {
    padding: 8px 24px;
    color: var(--text-muted);
    text-decoration: none;
    display: block;
    border-left: 2px solid transparent;
    transition: all 0.2s ease;
    cursor: pointer;
}

.nav-item:hover {
    color: var(--text-primary);
}

.nav-item.active {
    color: var(--text-primary);
    border-left-color: var(--accent);
}

/* Panels */
.panel {
    display: none;
    animation: fadeIn 0.3s ease;
}

.panel.active {
    display: block;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(4px); }
    to { opacity: 1; transform: translateY(0); }
}

.panel-header {
    margin-bottom: 32px;
    display: flex;
    justify-content: space-between;
    align-items: flex-end;
}

.panel-title {
    font-size: 20px;
    margin-bottom: 8px;
}

.panel-desc {
    color: var(--text-muted);
}

/* Live Surface (Overview) */
.live-feed {
    display: flex;
    flex-direction: column;
    gap: 16px;
}

.feed-item {
    background-color: var(--bg-surface);
    border: 1px solid var(--border);
    padding: 24px;
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.feed-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.feed-type {
    display: flex;
    align-items: center;
    gap: 8px;
}

.feed-type-indicator {
    width: 4px;
    height: 4px;
    border-radius: 50%;
    background-color: var(--accent);
}

.feed-time {
    font-family: monospace;
    font-size: 12px;
    color: var(--text-muted);
}

.feed-content {
    color: var(--text-primary);
    line-height: 1.6;
}

.feed-meta {
    display: flex;
    gap: 16px;
    font-size: 12px;
    color: var(--text-muted);
    margin-top: 8px;
}

/* Matrix Bots Control */
.bot-matrix {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 24px;
}

.bot-card {
    background-color: var(--bg-surface);
    border: 1px solid var(--border);
    padding: 24px;
    display: flex;
    flex-direction: column;
    gap: 16px;
}

.bot-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid var(--border);
    padding-bottom: 16px;
}

.bot-name {
    font-size: 16px;
    font-weight: 500;
}

.bot-status {
    font-size: 12px;
    color: var(--status-running);
    display: flex;
    align-items: center;
    gap: 6px;
}

.bot-details {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.bot-detail-row {
    display: flex;
    justify-content: space-between;
    font-size: 13px;
}

.bot-detail-label {
    color: var(--text-muted);
}

.bot-detail-value {
    color: var(--text-primary);
    font-family: monospace;
}

/* Configuration Panel */
.config-card {
    background-color: var(--bg-surface);
    border: 1px solid var(--border);
    padding: 32px;
    margin-bottom: 24px;
}

.config-section-label {
    margin-bottom: 24px;
}

.form-group {
    margin-bottom: 24px;
}

.form-group:last-child {
    margin-bottom: 0;
}

.form-label {
    display: block;
    margin-bottom: 8px;
    color: var(--text-muted);
}

.form-input {
    width: 100%;
    max-width: 400px;
    background-color: var(--bg-page);
    border: 1px solid var(--border);
    color: var(--text-primary);
    padding: 10px 12px;
    font-family: var(--font-main);
    font-size: 14px;
    outline: none;
    transition: border-color 0.2s;
}

.form-input:focus {
    border-color: var(--accent);
}

/* Flash Messages */
.flash-message {
    padding: 16px;
    border-left: 2px solid var(--accent);
    color: var(--text-primary);
    margin-bottom: 24px;
    font-size: 13px;
}

/* Setup Wizard */
.wizard-container {
    display: none;
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    background-color: var(--bg-page);
    z-index: 100;
    align-items: center;
    justify-content: center;
}

.wizard-container.active {
    display: flex;
}

.wizard-content {
    width: 100%;
    max-width: 480px;
}

.wizard-progress {
    display: flex;
    gap: 8px;
    margin-bottom: 48px;
}

.progress-step {
    flex: 1;
    height: 2px;
    background-color: var(--border);
}

.progress-step.active {
    background-color: var(--accent);
}

.wizard-step {
    display: none;
}

.wizard-step.active {
    display: block;
    animation: fadeIn 0.4s ease;
}

.wizard-title {
    font-size: 24px;
    margin-bottom: 16px;
}

.wizard-desc {
    color: var(--text-muted);
    margin-bottom: 32px;
    line-height: 1.6;
}

.btn {
    background: transparent;
    border: 1px solid var(--border);
    color: var(--text-primary);
    padding: 10px 24px;
    font-family: var(--font-main);
    font-size: 14px;
    cursor: pointer;
    transition: all 0.2s;
}

.btn:hover {
    border-color: var(--text-muted);
}

.btn-primary {
    border-color: var(--accent);
    color: var(--accent);
}

.btn-primary:hover {
    background-color: var(--accent);
    color: var(--bg-page);
}

.wizard-actions {
    margin-top: 48px;
    display: flex;
    justify-content: flex-end;
    gap: 16px;
}

/* Utility */
.flex-between {
    display: flex;
    justify-content: space-between;
    align-items: center;
}
"""
