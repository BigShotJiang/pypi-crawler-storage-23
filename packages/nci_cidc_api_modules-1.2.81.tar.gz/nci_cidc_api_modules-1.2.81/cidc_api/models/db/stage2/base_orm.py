from sqlalchemy_mixins import SerializeMixin, ReprMixin
from cidc_api.config.db import Stage2BaseModel, ModelMixin
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy.types import JSON


class BaseORM(Stage2BaseModel, ModelMixin, ReprMixin, SerializeMixin):
    __abstract__ = True
    __repr__ = ReprMixin.__repr__

    trial_id: Mapped[str]
    version: Mapped[str]
    custom_row_data: Mapped[dict | None] = mapped_column(JSON)
