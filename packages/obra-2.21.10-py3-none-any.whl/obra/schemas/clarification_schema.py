"""Pydantic schemas for clarification loop feedback.

This module provides schemas for the clarification loop that iteratively
improves UserPlan quality through structured feedback. The loop identifies
specific field deficiencies and suggests improvements.

Architecture:
    - FieldFeedback: Feedback for a specific field in a UserPlan step
    - ClarificationFeedback: Result of one clarification iteration
    - ClarificationResult: Complete result of the clarification loop

Related:
    - docs/design/prds/USERPLAN_DOBRA_ENHANCEMENTS_PRD.md (FR-10 through FR-13c)
    - obra/hybrid/quality/clarification.py (uses these schemas)
    - config/default_config.yaml (clarification.max_iterations, quality_delta_threshold)
"""

from enum import Enum

from pydantic import BaseModel, ConfigDict, Field, field_validator


class IssueType(str, Enum):
    """Classification of field issues.

    Attributes:
        MISSING: Field is empty or not provided
        VAGUE: Field content is too vague or unspecific
        INCONSISTENT: Field conflicts with other fields
        INCOMPLETE: Field is partially filled but missing key information
        AMBIGUOUS: Field has multiple possible interpretations
    """

    MISSING = "missing"
    VAGUE = "vague"
    INCONSISTENT = "inconsistent"
    INCOMPLETE = "incomplete"
    AMBIGUOUS = "ambiguous"


class TerminalReason(str, Enum):
    """Reason why the clarification loop should terminate.

    Attributes:
        THRESHOLD_REACHED: Quality score meets or exceeds threshold
        MAX_ITERATIONS: Maximum iteration count reached
        DIMINISHING_RETURNS: Quality delta below threshold (< 0.05)
        NO_IMPROVEMENTS: No actionable improvements identified
    """

    THRESHOLD_REACHED = "threshold_reached"
    MAX_ITERATIONS = "max_iterations"
    DIMINISHING_RETURNS = "diminishing_returns"
    NO_IMPROVEMENTS = "no_improvements"


class FieldFeedback(BaseModel):
    """Feedback for a specific field in a UserPlan or step.

    Represents a single issue identified during quality assessment,
    with an actionable suggestion for improvement.

    Attributes:
        field: Name of the field with the issue (e.g., "deliverables", "success_criteria")
        issue: Classification of the issue type
        description: Human-readable description of the issue
        suggestion: Actionable improvement suggestion
        resolved: True if the field was auto-filled or improved during this iteration
        step_id: Optional step ID if this feedback is for a specific step (None for plan-level)

    Example:
        >>> feedback = FieldFeedback(
        ...     field="deliverables",
        ...     issue=IssueType.MISSING,
        ...     description="No deliverables specified for this step",
        ...     suggestion="Add specific deliverables such as 'User model class' or 'Migration file'",
        ...     resolved=False,
        ...     step_id="UP-20260115-auth:S1"
        ... )
    """

    field: str = Field(
        ...,
        min_length=1,
        description="Name of the field with the issue",
    )
    issue: IssueType = Field(
        ...,
        description="Classification of the issue type",
    )
    description: str = Field(
        ...,
        min_length=1,
        description="Human-readable description of the issue",
    )
    suggestion: str = Field(
        ...,
        min_length=1,
        description="Actionable improvement suggestion",
    )
    resolved: bool = Field(
        default=False,
        description="True if field was auto-filled or improved during this iteration",
    )
    step_id: str | None = Field(
        default=None,
        description="Step ID if feedback is for a specific step (None for plan-level)",
    )

    model_config = ConfigDict(extra="forbid")


class ClarificationFeedback(BaseModel):
    """Result of one clarification iteration.

    Tracks quality before and after refinement, along with the specific
    fields that were identified for improvement.

    Attributes:
        iteration: 1-based iteration number
        quality_before: Quality score at start of iteration (0.0-1.0)
        quality_after: Quality score at end of iteration (0.0-1.0)
        quality_delta: Change in quality score (quality_after - quality_before)
        fields_improved: List of field-level feedback items
        terminal: True if the loop should stop after this iteration
        terminal_reason: Reason for termination (if terminal=True)
        auto_filled_fields: Fields that were automatically populated

    Example:
        >>> feedback = ClarificationFeedback(
        ...     iteration=1,
        ...     quality_before=0.55,
        ...     quality_after=0.72,
        ...     quality_delta=0.17,
        ...     fields_improved=[field_feedback1, field_feedback2],
        ...     terminal=False,
        ...     terminal_reason=None
        ... )
    """

    iteration: int = Field(
        ...,
        ge=1,
        description="1-based iteration number",
    )
    quality_before: float = Field(
        ...,
        ge=0.0,
        le=1.0,
        description="Quality score at start of iteration (0.0-1.0)",
    )
    quality_after: float = Field(
        ...,
        ge=0.0,
        le=1.0,
        description="Quality score at end of iteration (0.0-1.0)",
    )
    quality_delta: float = Field(
        ...,
        description="Change in quality score (quality_after - quality_before)",
    )
    fields_improved: list[FieldFeedback] = Field(
        default_factory=list,
        description="List of field-level feedback items",
    )
    terminal: bool = Field(
        default=False,
        description="True if the loop should stop after this iteration",
    )
    terminal_reason: TerminalReason | None = Field(
        default=None,
        description="Reason for termination (if terminal=True)",
    )
    auto_filled_fields: list[str] = Field(
        default_factory=list,
        description="Field names that were automatically populated",
    )

    model_config = ConfigDict(extra="forbid")

    @field_validator("quality_before", "quality_after")
    @classmethod
    def validate_quality_score(cls, v: float) -> float:
        """Round quality scores to 2 decimal places."""
        return round(v, 2)

    @field_validator("quality_delta")
    @classmethod
    def validate_quality_delta(cls, v: float) -> float:
        """Round quality delta to 3 decimal places."""
        return round(v, 3)


class ClarificationResult(BaseModel):
    """Complete result of the clarification loop.

    Aggregates all iterations and provides final quality metrics.
    Used for reporting and audit purposes.

    Attributes:
        userplan_id: ID of the UserPlan that was refined
        initial_quality: Quality score before any clarification
        final_quality: Quality score after all iterations
        total_improvement: Total quality improvement (final - initial)
        iterations_run: Number of iterations executed
        iterations: List of feedback from each iteration
        final_terminal_reason: Reason the loop terminated
        fields_auto_filled: Total count of fields auto-filled across all iterations
        fields_improved_count: Total count of fields with feedback generated

    Example:
        >>> result = ClarificationResult(
        ...     userplan_id="UP-20260115-auth",
        ...     initial_quality=0.55,
        ...     final_quality=0.85,
        ...     total_improvement=0.30,
        ...     iterations_run=3,
        ...     iterations=[iter1, iter2, iter3],
        ...     final_terminal_reason=TerminalReason.THRESHOLD_REACHED
        ... )
    """

    userplan_id: str = Field(
        ...,
        description="ID of the UserPlan that was refined",
    )
    initial_quality: float = Field(
        ...,
        ge=0.0,
        le=1.0,
        description="Quality score before any clarification",
    )
    final_quality: float = Field(
        ...,
        ge=0.0,
        le=1.0,
        description="Quality score after all iterations",
    )
    total_improvement: float = Field(
        ...,
        description="Total quality improvement (final - initial)",
    )
    iterations_run: int = Field(
        ...,
        ge=0,
        description="Number of iterations executed",
    )
    iterations: list[ClarificationFeedback] = Field(
        default_factory=list,
        description="List of feedback from each iteration",
    )
    final_terminal_reason: TerminalReason = Field(
        ...,
        description="Reason the loop terminated",
    )
    fields_auto_filled: int = Field(
        default=0,
        ge=0,
        description="Total count of fields auto-filled across all iterations",
    )
    fields_improved_count: int = Field(
        default=0,
        ge=0,
        description="Total count of fields with feedback generated",
    )

    model_config = ConfigDict(extra="forbid")

    @field_validator("initial_quality", "final_quality")
    @classmethod
    def validate_quality_score(cls, v: float) -> float:
        """Round quality scores to 2 decimal places."""
        return round(v, 2)

    @field_validator("total_improvement")
    @classmethod
    def validate_improvement(cls, v: float) -> float:
        """Round improvement to 3 decimal places."""
        return round(v, 3)


# Convenience exports
__all__ = [
    "ClarificationFeedback",
    "ClarificationResult",
    "FieldFeedback",
    "IssueType",
    "TerminalReason",
]
