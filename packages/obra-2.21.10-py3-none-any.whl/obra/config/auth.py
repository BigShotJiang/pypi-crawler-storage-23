"""Firebase authentication state management for Obra.

Handles reading and writing Firebase auth credentials from
~/.obra/auth.yaml (separate from application config).

Example:
    from obra.config.auth import is_authenticated, get_auth_token

    if is_authenticated():
        token = get_auth_token()
"""

from datetime import UTC, datetime, timedelta

from .loaders import load_auth_state, save_auth_state


def get_firebase_uid() -> str | None:
    """Get stored Firebase UID.

    Returns:
        Firebase UID string or None if not authenticated
    """
    state = load_auth_state()
    return state.get("firebase_uid")


def get_user_email() -> str | None:
    """Get stored user email.

    Returns:
        User email string or None if not authenticated
    """
    state = load_auth_state()
    return state.get("user_email")


def get_auth_token() -> str | None:
    """Get stored Firebase ID token.

    Returns:
        Firebase ID token or None if not authenticated
    """
    state = load_auth_state()
    return state.get("auth_token")


def get_refresh_token() -> str | None:
    """Get stored Firebase refresh token.

    Returns:
        Firebase refresh token or None if not authenticated
    """
    state = load_auth_state()
    return state.get("refresh_token")


def get_auth_provider() -> str | None:
    """Get stored auth provider.

    Returns:
        Auth provider (e.g., "google.com", "github.com") or None
    """
    state = load_auth_state()
    return state.get("auth_provider")


def is_authenticated() -> bool:
    """Check if user is authenticated with Firebase Auth.

    Returns:
        True if Firebase UID and auth token are present
    """
    state = load_auth_state()
    return bool(state.get("firebase_uid") and state.get("auth_token"))


def save_firebase_auth(
    firebase_uid: str,
    email: str,
    auth_token: str,
    refresh_token: str,
    auth_provider: str,
    display_name: str | None = None,
    token_expires_at: datetime | None = None,
) -> None:
    """Save Firebase authentication to auth state file.

    Args:
        firebase_uid: Firebase user ID
        email: User's email address
        auth_token: Firebase ID token
        refresh_token: Firebase refresh token
        auth_provider: Auth provider (e.g., "google.com")
        display_name: Optional user display name
        token_expires_at: Optional token expiration time. If not provided,
            defaults to 1 hour from now (Firebase ID token lifetime).
    """
    state = load_auth_state()

    state["firebase_uid"] = firebase_uid
    state["user_email"] = email
    state["auth_token"] = auth_token
    state["refresh_token"] = refresh_token
    state["auth_provider"] = auth_provider
    state["auth_timestamp"] = datetime.now(UTC).isoformat()

    # Firebase ID tokens expire in 1 hour - save expiration for auto-refresh
    if token_expires_at is None:
        token_expires_at = datetime.now(UTC) + timedelta(hours=1)
    state["token_expires_at"] = token_expires_at.isoformat()

    if display_name:
        state["display_name"] = display_name

    # Also set user_id to email for compatibility with existing code
    state["user_id"] = email

    save_auth_state(state)


def clear_firebase_auth() -> None:
    """Clear stored Firebase authentication from auth state file."""
    state = load_auth_state()

    # Remove Firebase auth fields
    for key in [
        "firebase_uid",
        "user_email",
        "auth_token",
        "refresh_token",
        "auth_provider",
        "auth_timestamp",
        "display_name",
    ]:
        state.pop(key, None)

    save_auth_state(state)


# Public exports
__all__ = [
    "clear_firebase_auth",
    "get_auth_provider",
    "get_auth_token",
    "get_firebase_uid",
    "get_refresh_token",
    "get_user_email",
    "is_authenticated",
    "save_firebase_auth",
]
