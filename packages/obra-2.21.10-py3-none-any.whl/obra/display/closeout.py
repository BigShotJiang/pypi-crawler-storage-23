"""Session closeout message builder.

This module provides state-aware closeout messages for session termination,
including celebration banners for full mission completion and ASCII fallback
for Windows CMD/older PowerShell compatibility.

Usage:
    from obra.display.closeout import build_closeout_message, CloseoutContext, TerminationState

    ctx = CloseoutContext(
        state=TerminationState.COMPLETED,
        session_id="abc123",
        objective="Add feature X",
        ...
    )
    build_closeout_message(ctx, console, verbosity=1)
"""

from dataclasses import dataclass
from enum import Enum

from rich.console import Console

from obra.display.charset import get_unicode_support, glyphs
from obra.messages.registry import get_message


class TerminationState(str, Enum):
    """Session termination states for closeout messaging."""

    COMPLETED = "completed"
    ESCALATED = "escalated"
    INTERRUPTED = "interrupted"
    FAILED = "failed"
    EXPIRED = "expired"
    ABANDONED = "abandoned"


@dataclass
class CloseoutContext:
    """Data for building closeout message."""

    state: TerminationState
    session_id: str
    objective: str = ""
    work_summary: list[str] | None = None
    items_completed: int = 0
    items_total: int = 0
    quality_score: float = 0.0
    duration_seconds: float = 0.0  # This invocation
    total_duration_seconds: float = 0.0  # Cumulative across all invocations
    invocation_count: int = 1  # Number of run/resume calls
    files_created: list[str] | None = None
    files_modified: list[str] | None = None
    git_branch: str = ""
    git_commit_hash: str = ""
    termination_reason: str = ""
    warnings: list[str] | None = None
    terminal_phase: str = ""
    suppress_interrupt_hint: bool = False
    # Epic completion tracking (for celebration)
    epics_completed: int = 0
    epics_total: int = 0
    stories_completed: int = 0
    stories_total: int = 0
    tasks_completed: int = 0
    tasks_total: int = 0
    # FEAT-CLOSEOUT-SKIP-SUMMARY: Pending skip records for display
    pending_skips: list[dict[str, str]] | None = None


# State-specific configuration
# Banner text is generated dynamically via get_message('status.session.*')
STATE_CONFIG = {
    TerminationState.COMPLETED: {
        "banner_key": "status.session.complete",
        "glyph": "success",
        "style": "bold green",
    },
    TerminationState.ESCALATED: {
        "banner_key": "status.session.escalated",
        "glyph": "warning",
        "style": "bold yellow",
    },
    TerminationState.INTERRUPTED: {
        "banner_key": "status.session.paused",
        "glyph": "paused",
        "style": "bold cyan",
    },
    TerminationState.FAILED: {
        "banner_key": "status.session.failed",
        "glyph": "failure",
        "style": "bold red",
    },
    TerminationState.EXPIRED: {
        "banner_key": "status.session.expired",
        "glyph": "timeout",
        "style": "dim",
    },
    TerminationState.ABANDONED: {
        "banner_key": "status.session.abandoned",
        "glyph": "failure",
        "style": "dim",
    },
}


# Recovery message key mappings for next steps commands
# Maps logical action to message key (without 'recovery.' prefix)
_RECOVERY_KEYS = {
    "session.show": "recovery.session.show",
    "session.resume": "recovery.session.resume",
    "session.continue": "recovery.session.continue",
    "session.repair": "recovery.session.repair",
    "session.reset_review": "recovery.session.reset_review",
}


def _build_next_step(key_or_template: str, short_id: str, objective: str = "") -> str:
    """Build a next step command from a key or template.

    Args:
        key_or_template: Either a recovery message key (e.g., 'session.show')
                         or a raw template string
        short_id: Session short ID for placeholder substitution
        objective: Objective text for placeholder substitution

    Returns:
        Formatted command string
    """
    if key_or_template in _RECOVERY_KEYS:
        return get_message(_RECOVERY_KEYS[key_or_template], short_id=short_id)
    # For non-recovery commands, format as template
    return key_or_template.format(sid=short_id, objective=objective[:30] if objective else "...")


# State-specific next steps
# Each entry is (label, key_or_template) where key_or_template is either:
# - A recovery key like 'session.show' (looked up via get_message)
# - A raw command template like 'git diff HEAD~1'
NEXT_STEPS: dict[TerminationState, list[tuple[str, str]]] = {
    TerminationState.COMPLETED: [
        ("Review changes", "git diff HEAD~1"),
        ("View session", "session.show"),
        ("Continue", 'obra run --continue-from {sid} "Next task..."'),
    ],
    TerminationState.ESCALATED: [
        ("View breakpoint", "session.show"),
        ("Resume session", "session.resume"),
        ("Reset review", "session.reset_review"),
    ],
    TerminationState.INTERRUPTED: [
        ("Resume session", "session.resume"),
        ("View progress", "session.show"),
    ],
    TerminationState.FAILED: [
        ("View error", "session.show"),
        ("Repair session", "session.repair"),
        ("Retry", "session.resume"),
    ],
    TerminationState.EXPIRED: [
        ("View session", "session.show"),
        ("Start fresh", 'obra run "{objective}"'),
    ],
    TerminationState.ABANDONED: [
        ("View session", "session.show"),
        ("Start fresh", 'obra run "{objective}"'),
    ],
}


def _format_duration(seconds: float) -> str:
    """Format duration as human-readable string.

    Args:
        seconds: Duration in seconds.

    Returns:
        Formatted string like "45s", "1m 30s", or "2h 15m".
    """
    if seconds < 60:
        return f"{seconds:.0f}s"
    minutes = int(seconds // 60)
    secs = int(seconds % 60)
    if minutes < 60:
        return f"{minutes}m {secs}s"
    hours = minutes // 60
    mins = minutes % 60
    return f"{hours}h {mins}m"


def _format_duration_with_invocations(
    total_seconds: float,
    invocation_count: int,
) -> str:
    """Format duration with invocation count if multiple sessions.

    Args:
        total_seconds: Total duration in seconds.
        invocation_count: Number of invocations (run + resumes).

    Returns:
        Duration string, with "(across N sessions)" suffix if count > 1.
    """
    duration_str = _format_duration(total_seconds)
    if invocation_count > 1:
        return f"{duration_str} (across {invocation_count} sessions)"
    return duration_str


def _should_celebrate(ctx: CloseoutContext) -> bool:
    """Determine if this completion deserves full celebration banner.

    Triggers celebration when:
    - Session completed successfully
    - All epics are completed (epics_completed == epics_total)
    - At least one epic exists
    - Quality score meets threshold (>= 70)
    - Celebration mode is not disabled in config

    Args:
        ctx: Closeout context with session data.

    Returns:
        True if celebration banner should be shown.
    """
    # Check config for celebration_mode
    try:
        from obra.config import load_config

        config = load_config()
        if not config.get("display", {}).get("celebration_mode", True):
            return False
    except Exception:
        pass  # Default to allowing celebration if config unavailable

    if ctx.state != TerminationState.COMPLETED or ctx.quality_score < 70:
        return False
    if ctx.epics_total > 0:
        return ctx.epics_completed == ctx.epics_total
    if ctx.stories_total > 0:
        return ctx.stories_completed == ctx.stories_total
    return False


def _build_celebration_banner(
    ctx: CloseoutContext,
    console: Console,
    verbosity: int = 1,
) -> None:
    """Build celebration banner for full mission completion.

    Called when all epics completed successfully. Uses double-line borders
    to visually distinguish from partial session completion.

    Args:
        ctx: Closeout context with session data.
        console: Rich console for output.
        verbosity: Output detail level (0=quiet, 1=progress, 2=detail).
    """
    short_id = ctx.session_id.split("-")[0] if "-" in ctx.session_id else ctx.session_id

    # Double-line banner (=) vs single-line (-) signals full mission
    if get_unicode_support():
        border = "\u2550" * 60  # ═
        success_icon = "\u2713"  # ✓
        tl, tr, bl, br = "\u250c", "\u2510", "\u2514", "\u2518"  # ┌┐└┘
        h, v = "\u2500", "\u2502"  # ─│
    else:
        border = "=" * 60
        success_icon = "[ok]"
        tl, tr, bl, br = "+", "+", "+", "+"
        h, v = "-", "|"

    # Celebration header
    mission_text = get_message("status.celebration.mission_complete")
    console.print()
    console.print(f"[bold green]{border}[/bold green]")
    console.print()
    console.print(
        f"[bold green]                  {success_icon}  {mission_text}  {success_icon}[/bold green]",
        justify="center",
    )
    console.print()
    epic_word = "epic" if ctx.epics_total == 1 else "epics"
    console.print(
        f"[green]            All {ctx.epics_total} {epic_word} finished successfully[/green]",
        justify="center",
    )
    console.print()
    console.print(f"[bold green]{border}[/bold green]")

    if verbosity == 0:  # QUIET
        console.print(f"\n[dim]Session: {short_id}[/dim]")
        return

    # Objective
    console.print()
    if ctx.objective:
        obj_display = ctx.objective[:60] + "..." if len(ctx.objective) > 60 else ctx.objective
        console.print(f"  [bold]Objective:[/bold] {obj_display}")

    # Stats table
    console.print()
    epic_str = f"{ctx.epics_completed} Epic{'s' if ctx.epics_completed != 1 else ''}"
    story_str = f"{ctx.stories_completed} Stor{'ies' if ctx.stories_completed != 1 else 'y'}"
    task_str = f"{ctx.tasks_completed} Task{'s' if ctx.tasks_completed != 1 else ''}"
    quality_str = f"{ctx.quality_score:.0f}/100"

    # Table with box drawing
    col_w = 12
    table_content = f" {epic_str:^{col_w}} {v} {story_str:^{col_w}} {v} {task_str:^{col_w}} {v} {quality_str:^{col_w}} "
    table_width = len(table_content)
    table_border = h * table_width

    console.print(f"  {tl}{table_border}{tr}")
    console.print(f"  {v}{table_content}{v}")
    console.print(f"  {bl}{table_border}{br}")

    # Duration and files
    console.print()
    if ctx.total_duration_seconds > 0:
        duration_display = _format_duration_with_invocations(
            ctx.total_duration_seconds, ctx.invocation_count
        )
        console.print(f"  Duration: {duration_display}")
    elif ctx.duration_seconds > 0:
        console.print(f"  Duration: {_format_duration(ctx.duration_seconds)}")

    files_created = ctx.files_created or []
    files_modified = ctx.files_modified or []
    total_files = len(files_created) + len(files_modified)
    if total_files > 0:
        console.print(
            f"  Files: [green]+{len(files_created)} created[/green], [yellow]~{len(files_modified)} modified[/yellow]"
        )

    # Git info
    if ctx.git_branch or ctx.git_commit_hash:
        git_parts = []
        if ctx.git_branch:
            git_parts.append(f"Branch: {ctx.git_branch}")
        if ctx.git_commit_hash:
            git_parts.append(f"Commit: {ctx.git_commit_hash[:7]}")
        console.print(f"  Git: {', '.join(git_parts)}")

    # Next steps
    console.print()
    console.print("  [bold]Next steps:[/bold]")
    console.print("    [dim]git diff HEAD~1[/dim]                    [dim]# Review changes[/dim]")
    session_show_cmd = get_message("recovery.session.show", short_id=short_id)
    console.print(f"    [dim]{session_show_cmd}[/dim]        [dim]# View details[/dim]")

    # Footer
    console.print()
    console.print(f"[dim]{'-' * 60}[/dim]")
    console.print(f"[dim]Session: {short_id}[/dim]")


def build_closeout_message(
    ctx: CloseoutContext,
    console: Console,
    verbosity: int = 1,
) -> None:
    """Build and print closeout message based on termination state.

    Args:
        ctx: Closeout context with session data.
        console: Rich console for output.
        verbosity: Output detail level (0=quiet, 1=progress, 2=detail).
    """
    # Check for full mission completion - use celebration banner
    if _should_celebrate(ctx):
        _build_celebration_banner(ctx, console, verbosity)
        return

    # Standard closeout for partial completion or non-success states
    config = STATE_CONFIG[ctx.state]
    glyph = getattr(glyphs, config["glyph"])
    short_id = ctx.session_id.split("-")[0] if "-" in ctx.session_id else ctx.session_id

    # Banner
    console.print()
    banner_text = get_message(config["banner_key"])
    console.print(f"{glyph} {banner_text}", style=config["style"])

    if verbosity == 0:  # QUIET
        if ctx.state == TerminationState.INTERRUPTED and not ctx.suppress_interrupt_hint:
            from obra.display.recovery_hints import build_interrupt_recovery_hints

            console.print()
            console.print(glyphs.divider)
            for line in build_interrupt_recovery_hints(ctx.session_id or "").splitlines():
                if line:
                    console.print(f"[dim]{line}[/dim]")
                else:
                    console.print()
            return
        console.print(f"[dim]Session: {short_id}[/dim]")
        return

    # PROGRESS level and above
    console.print()

    # Objective echo
    if ctx.objective:
        obj_display = ctx.objective[:70] + "..." if len(ctx.objective) > 70 else ctx.objective
        console.print(f"  [bold]Objective:[/bold] {obj_display}")

    # Work summary (DETAIL only)
    if verbosity >= 2 and ctx.work_summary:
        console.print()
        console.print("  [bold]Summary:[/bold]")
        for item in ctx.work_summary[:3]:
            console.print(f"    {glyphs.tree_mid} {item}")

    # Files changed
    files_created = ctx.files_created or []
    files_modified = ctx.files_modified or []
    total_files = len(files_created) + len(files_modified)

    if total_files > 0:
        console.print()
        console.print(f"  [bold]Files ({total_files}):[/bold]")
        if verbosity >= 2:
            # Show file list at DETAIL
            for f in files_created[:5]:
                console.print(f"    [green]+ {f}[/green]")
            for f in files_modified[:5]:
                console.print(f"    [yellow]~ {f}[/yellow]")
            remaining = total_files - min(5, len(files_created)) - min(5, len(files_modified))
            if remaining > 0:
                console.print(f"    [dim]... and {remaining} more[/dim]")
        else:
            # Summary at PROGRESS
            console.print(
                f"    [green]+{len(files_created)} created[/green], [yellow]~{len(files_modified)} modified[/yellow]"
            )

    # Metrics line
    console.print()
    metrics_parts = []
    if ctx.quality_score > 0:
        metrics_parts.append(f"Quality: {ctx.quality_score:.0f}/100")
    if ctx.total_duration_seconds > 0:
        duration_display = _format_duration_with_invocations(
            ctx.total_duration_seconds, ctx.invocation_count
        )
        metrics_parts.append(f"Duration: {duration_display}")
    elif ctx.duration_seconds > 0:
        metrics_parts.append(f"Duration: {_format_duration(ctx.duration_seconds)}")
    if ctx.items_completed > 0:
        if ctx.items_total > 0:
            metrics_parts.append(f"Items: {ctx.items_completed}/{ctx.items_total}")
        else:
            metrics_parts.append(f"Items: {ctx.items_completed}")

    if metrics_parts:
        console.print(f"  {' | '.join(metrics_parts)}")

    # Git status
    if ctx.git_branch or ctx.git_commit_hash:
        git_info = []
        if ctx.git_branch:
            git_info.append(f"Branch: {ctx.git_branch}")
        if ctx.git_commit_hash:
            git_info.append(f"Commit: {ctx.git_commit_hash[:7]}")
        console.print(f"  [dim]Git: {', '.join(git_info)}[/dim]")
    elif ctx.state == TerminationState.ESCALATED:
        console.print(f"  [yellow]{glyphs.warning} Changes NOT committed (escalated)[/yellow]")

    # Warnings
    if ctx.warnings:
        console.print()
        for warning in ctx.warnings[:3]:
            console.print(f"  [yellow]{glyphs.warning} {warning}[/yellow]")

    # FEAT-CLOSEOUT-SKIP-SUMMARY: Show pending skips
    if ctx.pending_skips:
        console.print()
        count = len(ctx.pending_skips)
        console.print(f"  [bold yellow]Skipped ({count} pending):[/bold yellow]")
        for skip in ctx.pending_skips[:5]:
            reason = skip.get("reason", "unknown")
            desc = skip.get("description", "")
            console.print(f"    {glyphs.warning} {desc} [dim]({reason})[/dim]")
        if count > 5:
            console.print(f"    [dim]... and {count - 5} more[/dim]")
        console.print("    [dim]Run: obra cleanup --interactive[/dim]")

    # Termination reason for non-success
    if ctx.termination_reason and ctx.state != TerminationState.COMPLETED:
        console.print()
        console.print(f"  [dim]Reason: {ctx.termination_reason}[/dim]")

    if ctx.state == TerminationState.INTERRUPTED:
        if not ctx.suppress_interrupt_hint:
            from obra.display.recovery_hints import build_interrupt_recovery_hints

            console.print()
            console.print(glyphs.divider)
            for line in build_interrupt_recovery_hints(ctx.session_id or "").splitlines():
                if line:
                    console.print(f"[dim]{line}[/dim]")
                else:
                    console.print()
        return

    # Next steps
    steps = NEXT_STEPS.get(ctx.state, [])
    if steps:
        console.print()
        console.print("  [bold]Next steps:[/bold]")
        for label, key_or_template in steps[:3]:
            cmd_formatted = _build_next_step(key_or_template, short_id, ctx.objective or "")
            console.print(f"    [dim]{cmd_formatted}[/dim]  [dim]# {label}[/dim]")

    # Footer
    console.print()
    console.print(glyphs.divider)
    console.print(f"[dim]Session: {short_id}[/dim]")
