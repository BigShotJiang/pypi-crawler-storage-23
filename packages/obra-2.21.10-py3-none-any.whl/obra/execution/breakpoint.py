"""Breakpoint data model and persistence for capturing unrecoverable execution states.

This module provides the Breakpoint model for tracking execution states that
require human intervention or cannot be automatically recovered. Breakpoints
are created when the orchestrator encounters situations that cannot be resolved
through retry logic or automatic decomposition.

Usage:
    from obra.execution.breakpoint import Breakpoint, BreakpointReason, create_breakpoint

    # Create a breakpoint for an unrecoverable error
    breakpoint = Breakpoint(
        task_id="S1.T1",
        reason=BreakpointReason.UNRECOVERABLE_ERROR,
        error_type="ValidationError",
        error_message="Schema validation failed: missing required field 'work_id'",
        stack_trace="...",
        task_state={"status": "blocked", "attempts": 3},
    )

    # Serialize to JSON for persistence
    json_data = breakpoint.to_json()

    # Deserialize from JSON
    restored = Breakpoint.from_json(json_data)

    # Create and persist a breakpoint (returns TaskOutcome.BLOCKED)
    from obra.execution.breakpoint import create_breakpoint
    outcome, bp = create_breakpoint(
        task_id="S1.T1",
        error=some_exception,
        context={"operation": "derive", "attempt": 3},
    )

Related:
    - obra/execution/errors.py (error classification)
    - docs/design/briefs/S9-BREAKPOINT-ESCALATION-BRIEF.md (design doc)
"""

from __future__ import annotations

import json
import logging
import traceback
import uuid
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from obra.execution.errors import TaskOutcome

logger = logging.getLogger(__name__)

# Metric name for breakpoint tracking
METRIC_BREAKPOINTS_TOTAL = "obra_breakpoints_total"

# Global metrics storage for breakpoint counts
_breakpoint_metrics: list[dict[str, Any]] = []


def emit_breakpoint_metric(
    reason: str,
    task_id: str,
    log_event: Any | None = None,
    trace_id: str | None = None,
) -> dict[str, Any]:
    """Emit a breakpoint counter metric.

    Args:
        reason: Breakpoint reason (e.g., "unrecoverable_error")
        task_id: Task that triggered the breakpoint
        log_event: Optional event logger callback
        trace_id: Optional trace ID for correlation

    Returns:
        The emitted metric dict
    """
    metric = {
        "metric_name": METRIC_BREAKPOINTS_TOTAL,
        "value": 1,
        "labels": {
            "reason": reason,
        },
        "timestamp": datetime.now(UTC).isoformat(),
        "metadata": {
            "task_id": task_id,
        },
    }

    _breakpoint_metrics.append(metric)

    if log_event:
        try:
            log_event(
                "breakpoint_metric",
                session_id=None,
                trace_id=trace_id,
                **metric,
            )
        except Exception as e:
            logger.debug("Failed to log breakpoint metric: %s", e)

    logger.debug(
        "Emitted breakpoint metric: reason=%s, task_id=%s",
        reason,
        task_id,
    )

    return metric


def get_breakpoint_metrics_summary() -> dict[str, Any]:
    """Get summary of breakpoint metrics.

    Returns:
        Summary dict with total count and counts by reason.
    """
    if not _breakpoint_metrics:
        return {"total": 0, "by_reason": {}}

    by_reason: dict[str, int] = {}
    for m in _breakpoint_metrics:
        reason = m.get("labels", {}).get("reason", "unknown")
        by_reason[reason] = by_reason.get(reason, 0) + 1

    return {
        "total": len(_breakpoint_metrics),
        "by_reason": by_reason,
    }


class BreakpointReason(str, Enum):
    """Enum for classifying why a breakpoint was created.

    Breakpoints are escalation points where automatic execution cannot continue.
    Each reason indicates a different type of intervention required.

    Attributes:
        UNRECOVERABLE_ERROR: A permanent error that cannot be resolved by retry
            or decomposition. Examples: invalid credentials, corrupted state,
            irrecoverable data loss.
        HUMAN_INPUT_REQUIRED: The task requires information or decisions that
            only a human can provide. Examples: approval for destructive
            operations, clarification on ambiguous requirements.
        AMBIGUOUS_REQUIREMENT: The task requirements are unclear or contradictory,
            making it impossible to determine the correct action. Requires
            human clarification before proceeding.
        EXTERNAL_DEPENDENCY_FAILED: A required external service, resource, or
            dependency is unavailable and cannot be substituted. Examples:
            third-party API permanently down, required file/resource deleted.
    """

    UNRECOVERABLE_ERROR = "unrecoverable_error"
    HUMAN_INPUT_REQUIRED = "human_input_required"
    AMBIGUOUS_REQUIREMENT = "ambiguous_requirement"
    EXTERNAL_DEPENDENCY_FAILED = "external_dependency_failed"


@dataclass
class Breakpoint:
    """Model for capturing unrecoverable execution states.

    A Breakpoint represents a point where automatic execution has stopped and
    human intervention is required. It captures all relevant context needed to
    understand the issue and resume execution after resolution.

    Attributes:
        task_id: The task identifier that triggered the breakpoint (e.g., "S1.T1")
        reason: Classification of why the breakpoint was created
        error_type: The type/class name of the error that caused the breakpoint
        error_message: Human-readable description of the error
        id: Unique identifier for this breakpoint (auto-generated UUID)
        created_at: ISO-8601 timestamp when the breakpoint was created
        stack_trace: Full stack trace if available (for debugging)
        task_state: Snapshot of task state at breakpoint time (for resumption)
        context: Additional context data relevant to the breakpoint
        resolution_notes: Notes added after resolution (for audit trail)
        resume_context: Information needed to resume execution after resolution

    Example:
        >>> breakpoint = Breakpoint(
        ...     task_id="S1.T1",
        ...     reason=BreakpointReason.HUMAN_INPUT_REQUIRED,
        ...     error_type="ApprovalRequired",
        ...     error_message="Destructive operation requires human approval",
        ...     task_state={"operation": "delete_all", "target": "user_data"},
        ...     resume_context={"approved": False, "pending_action": "delete_all"},
        ... )
    """

    task_id: str
    reason: BreakpointReason
    error_type: str
    error_message: str
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    created_at: str = field(default_factory=lambda: datetime.now(UTC).isoformat())
    stack_trace: str = ""
    task_state: dict[str, Any] = field(default_factory=dict)
    context: dict[str, Any] = field(default_factory=dict)
    resolution_notes: str = ""
    resume_context: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert the breakpoint to a dictionary.

        Handles enum serialization by converting BreakpointReason to its value.

        Returns:
            Dictionary representation suitable for JSON serialization
        """
        data = asdict(self)
        # Convert enum to string value for serialization
        data["reason"] = self.reason.value
        return data

    def to_json(self, indent: int | None = 2) -> str:
        """Serialize the breakpoint to a JSON string.

        Args:
            indent: Number of spaces for indentation (None for compact)

        Returns:
            JSON string representation of the breakpoint
        """
        return json.dumps(self.to_dict(), indent=indent)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Breakpoint:
        """Create a Breakpoint from a dictionary.

        Handles enum deserialization by converting string values back to
        BreakpointReason enum.

        Args:
            data: Dictionary with breakpoint data

        Returns:
            Breakpoint instance

        Raises:
            ValueError: If reason is not a valid BreakpointReason value
            KeyError: If required fields are missing
        """
        # Make a copy to avoid mutating the input
        data = dict(data)

        # Convert reason string to enum
        reason_value = data.get("reason")
        if isinstance(reason_value, str):
            data["reason"] = BreakpointReason(reason_value)
        elif isinstance(reason_value, BreakpointReason):
            pass  # Already an enum
        else:
            msg = f"Invalid reason type: {type(reason_value)}"
            raise ValueError(msg)

        return cls(**data)

    @classmethod
    def from_json(cls, json_str: str) -> Breakpoint:
        """Deserialize a Breakpoint from a JSON string.

        Args:
            json_str: JSON string representation of a breakpoint

        Returns:
            Breakpoint instance

        Raises:
            json.JSONDecodeError: If JSON is invalid
            ValueError: If data is invalid for Breakpoint
            KeyError: If required fields are missing
        """
        data = json.loads(json_str)
        return cls.from_dict(data)

    def is_resolved(self) -> bool:
        """Check if this breakpoint has resolution notes.

        A breakpoint is considered resolved if resolution_notes is non-empty.
        This is a simple heuristic; actual resolution status may be tracked
        externally.

        Returns:
            True if resolution_notes is not empty
        """
        return bool(self.resolution_notes)

    def add_resolution_notes(self, notes: str) -> None:
        """Add resolution notes to this breakpoint.

        Args:
            notes: Human-readable notes about how the breakpoint was resolved
        """
        self.resolution_notes = notes


# Default breakpoint storage directory (relative to project root)
DEFAULT_BREAKPOINT_DIR = ".obra/breakpoints"


def get_breakpoint_dir(base_dir: str | Path | None = None) -> Path:
    """Get the breakpoint storage directory.

    Args:
        base_dir: Optional base directory for the project. If None, uses
            current working directory.

    Returns:
        Path to the breakpoint storage directory (.obra/breakpoints/)
    """
    if base_dir is None:
        base_dir = Path.cwd()
    elif isinstance(base_dir, str):
        base_dir = Path(base_dir)

    return base_dir / DEFAULT_BREAKPOINT_DIR


def _generate_breakpoint_filename(task_id: str, timestamp: str) -> str:
    """Generate a filename for a breakpoint file.

    Format: YYYYMMDD_HHMMSS_<task_id>_<uuid>.json
    Example: 20240115_103000_S1_T1_a3f2b1c8.json

    Args:
        task_id: The task identifier (e.g., "S1.T1")
        timestamp: ISO-8601 timestamp string

    Returns:
        Filename string for the breakpoint file
    """
    # Parse ISO timestamp and format for filename
    # Handle both formats: "2024-01-15T10:30:00+00:00" and "2024-01-15T10:30:00.123456+00:00"
    try:
        dt = datetime.fromisoformat(timestamp)
    except ValueError:
        # Fallback to current time if parsing fails
        dt = datetime.now(UTC)

    time_part = dt.strftime("%Y%m%d_%H%M%S")

    # Sanitize task_id for filename (replace dots with underscores for safety)
    safe_task_id = task_id.replace(".", "_")

    # UUID suffix prevents collisions when concurrent tasks create
    # breakpoints within the same second
    unique_suffix = uuid.uuid4().hex[:8]

    return f"{time_part}_{safe_task_id}_{unique_suffix}.json"


def _classify_error_to_reason(error: BaseException) -> BreakpointReason:
    """Classify an error to determine the appropriate breakpoint reason.

    Uses error type and message heuristics to determine the most appropriate
    BreakpointReason for a given exception.

    Args:
        error: The exception to classify

    Returns:
        BreakpointReason enum value
    """
    error_message = str(error).lower()

    # Check for external dependency failures
    external_patterns = [
        "service unavailable",
        "connection refused",
        "external service",
        "api unavailable",
        "dependency failed",
        "upstream error",
    ]
    if any(pattern in error_message for pattern in external_patterns):
        return BreakpointReason.EXTERNAL_DEPENDENCY_FAILED

    # Check for ambiguous requirements
    ambiguity_patterns = [
        "ambiguous",
        "unclear",
        "conflicting",
        "contradictory",
        "cannot determine",
        "multiple interpretations",
    ]
    if any(pattern in error_message for pattern in ambiguity_patterns):
        return BreakpointReason.AMBIGUOUS_REQUIREMENT

    # Check for human input required
    human_input_patterns = [
        "approval required",
        "human input",
        "manual intervention",
        "user decision",
        "requires confirmation",
        "permission required",
    ]
    if any(pattern in error_message for pattern in human_input_patterns):
        return BreakpointReason.HUMAN_INPUT_REQUIRED

    # Default to unrecoverable error for most cases
    return BreakpointReason.UNRECOVERABLE_ERROR


def persist_breakpoint(
    breakpoint_obj: Breakpoint,
    base_dir: str | Path | None = None,
) -> Path:
    """Persist a breakpoint to the filesystem.

    Writes the breakpoint to .obra/breakpoints/ as a JSON file with a
    timestamp-based filename for easy identification.

    Args:
        breakpoint_obj: The Breakpoint object to persist
        base_dir: Optional base directory for the project. If None, uses
            current working directory.

    Returns:
        Path to the created breakpoint file

    Raises:
        OSError: If the directory cannot be created or file cannot be written
    """
    bp_dir = get_breakpoint_dir(base_dir)

    # Create directory if it doesn't exist
    bp_dir.mkdir(parents=True, exist_ok=True)

    # Generate filename
    filename = _generate_breakpoint_filename(breakpoint_obj.task_id, breakpoint_obj.created_at)
    file_path = bp_dir / filename

    # Write JSON with pretty formatting for human readability
    file_path.write_text(breakpoint_obj.to_json(indent=2))

    logger.info(
        "Breakpoint created for task %s: %s (reason: %s)",
        breakpoint_obj.task_id,
        file_path,
        breakpoint_obj.reason.value,
    )

    return file_path


def load_breakpoint(file_path: str | Path) -> Breakpoint:
    """Load a breakpoint from a JSON file.

    Args:
        file_path: Path to the breakpoint JSON file

    Returns:
        Breakpoint object deserialized from the file

    Raises:
        FileNotFoundError: If the file does not exist
        json.JSONDecodeError: If the file contains invalid JSON
        ValueError: If the data is not a valid Breakpoint
    """
    if isinstance(file_path, str):
        file_path = Path(file_path)

    json_str = file_path.read_text()
    return Breakpoint.from_json(json_str)


def list_breakpoints(
    base_dir: str | Path | None = None,
    task_id: str | None = None,
) -> list[Path]:
    """List all breakpoint files in the storage directory.

    Args:
        base_dir: Optional base directory for the project. If None, uses
            current working directory.
        task_id: Optional task ID to filter by. If provided, only returns
            breakpoints for that specific task.

    Returns:
        List of paths to breakpoint files, sorted by creation time (newest first)
    """
    bp_dir = get_breakpoint_dir(base_dir)

    if not bp_dir.exists():
        return []

    # Find all JSON files
    breakpoint_files = list(bp_dir.glob("*.json"))

    # Filter by task ID if specified
    if task_id is not None:
        safe_task_id = task_id.replace(".", "_")
        breakpoint_files = [f for f in breakpoint_files if safe_task_id in f.stem]

    # Sort by filename (which starts with timestamp) in descending order
    breakpoint_files.sort(reverse=True)

    return breakpoint_files


def create_breakpoint(
    task_id: str,
    error: BaseException,
    context: dict[str, Any] | None = None,
    *,
    task_state: dict[str, Any] | None = None,
    reason: BreakpointReason | None = None,
    base_dir: str | Path | None = None,
    resume_context: dict[str, Any] | None = None,
) -> tuple[TaskOutcome, Breakpoint]:
    """Create and persist a breakpoint for an unrecoverable error.

    This is the primary entry point for creating breakpoints when the
    orchestrator encounters an error that cannot be recovered through
    retry logic or automatic decomposition.

    The function:
    1. Creates a Breakpoint object with full error context
    2. Persists it to .obra/breakpoints/ as a JSON file
    3. Logs the breakpoint creation with file path
    4. Returns TaskOutcome.BLOCKED to signal execution should stop

    Args:
        task_id: The task identifier (e.g., "S1.T1") that triggered the breakpoint
        error: The exception that caused the unrecoverable state
        context: Optional additional context about the error (operation, attempt count, etc.)
        task_state: Optional snapshot of task state at breakpoint time
        reason: Optional explicit BreakpointReason. If not provided, the reason
            will be automatically classified based on the error.
        base_dir: Optional base directory for the project. If None, uses
            current working directory.
        resume_context: Optional information needed to resume execution after resolution

    Returns:
        Tuple of (TaskOutcome.BLOCKED, Breakpoint) where the Breakpoint contains
        all the captured context for human review.

    Example:
        >>> try:
        ...     # Some operation that fails unrecoverably
        ...     raise ValueError("Invalid schema: missing work_id")
        ... except ValueError as e:
        ...     outcome, bp = create_breakpoint(
        ...         task_id="S1.T1",
        ...         error=e,
        ...         context={"operation": "derive", "attempt": 3},
        ...         task_state={"status": "blocked"},
        ...     )
        ...     # outcome is TaskOutcome.BLOCKED
        ...     # bp contains the full breakpoint data

    Note:
        The breakpoint file will be named with a timestamp and task ID for
        easy identification: YYYYMMDD_HHMMSS_S1_T1.json
    """
    # Import TaskOutcome here to avoid circular import
    from obra.execution.errors import TaskOutcome

    # Determine reason from error if not explicitly provided
    if reason is None:
        reason = _classify_error_to_reason(error)

    # Extract error details
    error_type = type(error).__name__
    error_message = str(error)

    # Get full stack trace
    stack_trace = "".join(traceback.format_exception(type(error), error, error.__traceback__))

    # Build context dict
    full_context = context.copy() if context else {}

    # Add error classification metadata
    full_context.setdefault("error_classified_as", reason.value)

    # Create the breakpoint
    bp = Breakpoint(
        task_id=task_id,
        reason=reason,
        error_type=error_type,
        error_message=error_message,
        stack_trace=stack_trace,
        task_state=task_state or {},
        context=full_context,
        resume_context=resume_context or {},
    )

    # Persist to filesystem
    file_path = persist_breakpoint(bp, base_dir=base_dir)

    # Log with full details for debugging
    logger.warning(
        "Breakpoint created - Task: %s, Reason: %s, Error: %s, File: %s",
        task_id,
        reason.value,
        error_message[:100] + "..." if len(error_message) > 100 else error_message,
        file_path,
    )

    # Emit breakpoint metric (P1 observability)
    emit_breakpoint_metric(
        reason=reason.value,
        task_id=task_id,
    )

    return TaskOutcome.BLOCKED, bp


__all__ = [
    "DEFAULT_BREAKPOINT_DIR",
    "METRIC_BREAKPOINTS_TOTAL",
    "Breakpoint",
    "BreakpointReason",
    "create_breakpoint",
    "emit_breakpoint_metric",
    "get_breakpoint_dir",
    "get_breakpoint_metrics_summary",
    "list_breakpoints",
    "load_breakpoint",
    "persist_breakpoint",
]
