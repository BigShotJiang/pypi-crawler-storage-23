"""
Message registry with domain-organized templates and thread-safe lazy loading.

This module provides the core infrastructure for user-facing messages:
- MessageDomain and category enums for type-safe domain organization
- MessageTemplate dataclass for template storage with format variants
- Thread-safe lazy loading via double-checked locking
- Placeholder validation against canonical set
- Formatting primitives for consistent output
"""

from __future__ import annotations

import os
import re
import threading
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    pass


# =============================================================================
# Domain and Category Enums
# =============================================================================


class MessageDomain(Enum):
    """Top-level domains for user-facing messages."""

    RECOVERY = "recovery"
    STATUS = "status"
    PROGRESS = "progress"
    ERROR = "error"
    WARNING = "warning"
    GUIDANCE = "guidance"
    PROMPT = "prompt"
    VALIDATOR = "validator"


class RecoveryCategory(Enum):
    """Categories for recovery domain messages."""

    AUTH = "auth"
    SESSION = "session"
    CONFIG = "config"
    NETWORK = "network"
    EXECUTION = "execution"


class StatusCategory(Enum):
    """Categories for status domain messages."""

    SESSION = "session"
    PHASE = "phase"
    CELEBRATION = "celebration"


class ProgressCategory(Enum):
    """Categories for progress domain messages."""

    ITEM = "item"
    STORY = "story"
    EPIC = "epic"
    FIX = "fix"
    FILES = "files"


class ErrorCategory(Enum):
    """Categories for error domain messages."""

    SESSION = "session"
    AUTH = "auth"
    NETWORK = "network"
    CONFIG = "config"
    EXECUTION = "execution"


class WarningCategory(Enum):
    """Categories for warning domain messages."""

    DEPRECATION = "deprecation"
    QUALITY = "quality"
    CACHE = "cache"
    VERSION = "version"
    RUNTIME = "runtime"


class GuidanceCategory(Enum):
    """Categories for guidance domain messages."""

    REQUIREMENT = "requirement"
    OPTIONS = "options"
    HINT = "hint"
    VALIDATION = "validation"
    INPUT = "input"


class PromptCategory(Enum):
    """Categories for prompt domain messages."""

    CONFIRM = "confirm"
    CHOICE = "choice"


class ValidatorCategory(Enum):
    """Categories for validator domain messages (SenseCheck pipeline)."""

    INTENT = "intent"
    PLAN = "plan"
    REVIEW_FILTER = "review_filter"
    CODE_VERIFY = "code_verify"


# Type alias for any category enum
type MessageCategory = (
    RecoveryCategory
    | StatusCategory
    | ProgressCategory
    | ErrorCategory
    | WarningCategory
    | GuidanceCategory
    | PromptCategory
    | ValidatorCategory
)


# =============================================================================
# Placeholder Validation
# =============================================================================

# Canonical placeholder set (FR-2 base set plus error/status extensions)
VALID_PLACEHOLDERS: frozenset[str] = frozenset(
    {
        "session_id",
        "short_id",
        "command",
        "item_id",
        "task_id",
        "story_id",
        "epic_id",
        "phase",
        "duration",
        "count",
        "created",
        "modified",
        "fixed",
        "failed",
        "skipped",
        "details",
        "title",
        "old",
        "new",
        "threshold",
        "version",
        "message",
        "action",
        "min",
        "max",
        "description",
        "state",
        "retry_after",
        "size",
        "path",
        "stage",
        "issue_id",
        "value",
        "check_count",
        "file_count",
        "files_read",
        "callers_checked",
        "blocking",
        "v0",
        "v1",
        "v2",
        "reason",
        "severity",
        "task_count",
        "changes",
        "pass_num",
        "passes",
        "adjustments",
        "blockers",
    }
)

# Regex pattern to extract placeholders from templates
_PLACEHOLDER_PATTERN = re.compile(r"\{(\w+)\}")


def _extract_placeholders(template: str) -> set[str]:
    """Extract placeholder names from a template string."""
    return set(_PLACEHOLDER_PATTERN.findall(template))


def _validate_template(key: str, template: MessageTemplate) -> None:
    """
    Validate that a template only uses canonical placeholders.

    Args:
        key: Template key for error messages
        template: MessageTemplate to validate

    Raises:
        ValueError: If template contains non-canonical placeholders
    """
    all_placeholders: set[str] = set()

    # Check main template
    all_placeholders.update(_extract_placeholders(template.template))

    # Check verbose template if present
    if template.verbose_template:
        all_placeholders.update(_extract_placeholders(template.verbose_template))

    # Check ASCII template if present
    if template.ascii_template:
        all_placeholders.update(_extract_placeholders(template.ascii_template))

    # Find any invalid placeholders
    invalid = all_placeholders - VALID_PLACEHOLDERS
    if invalid:
        msg = (
            f"Template '{key}' has invalid placeholders: {sorted(invalid)}. "
            f"Valid placeholders are: {sorted(VALID_PLACEHOLDERS)}"
        )
        raise ValueError(msg)


# =============================================================================
# Formatting Primitives (FR-9)
# =============================================================================

FORMATTING_PRIMITIVES: dict[str, str | int] = {
    "numbered_list_format": "{}. ",
    "bullet_format": "\u2022 ",  # bullet character
    "bullet_format_ascii": "- ",
    "indent_spaces": 2,
    "command_quote": "'",
    "max_line_width": 80,
}


# =============================================================================
# MessageTemplate Dataclass
# =============================================================================


@dataclass(frozen=True)
class MessageTemplate:
    """
    A user-facing message template with optional verbose and ASCII variants.

    Attributes:
        domain: The message domain (RECOVERY, STATUS, etc.)
        category: The category within the domain
        template: The base template string with placeholders
        verbose_template: Extended template for verbose mode (optional)
        ascii_template: ASCII-safe template without emoji (optional)
        placeholders: Tuple of required placeholder names
    """

    domain: MessageDomain
    category: MessageCategory
    template: str
    verbose_template: str | None = None
    ascii_template: str | None = None
    placeholders: tuple[str, ...] = ()

    def format(self, *, verbose: bool = False, ascii_mode: bool = False, **kwargs: object) -> str:
        """
        Format the template with the given values.

        Args:
            verbose: Use verbose_template if available
            ascii_mode: Use ascii_template if available
            **kwargs: Placeholder values

        Returns:
            Formatted message string
        """
        # Select appropriate template variant
        if verbose and self.verbose_template:
            tpl = self.verbose_template
        elif ascii_mode and self.ascii_template:
            tpl = self.ascii_template
        else:
            tpl = self.template

        # Format with provided values
        return tpl.format(**kwargs)


# =============================================================================
# Thread-Safe Lazy Loading (OR-6)
# =============================================================================

_lock = threading.Lock()
_templates: dict[str, MessageTemplate] | None = None


def _load_all_templates() -> dict[str, MessageTemplate]:
    """
    Load and validate all message templates from domain modules.

    Returns:
        Dictionary mapping template keys to MessageTemplate instances
    """
    templates: dict[str, MessageTemplate] = {}

    # Import domain modules and merge their templates
    # Each domain module exports a TEMPLATES dict
    try:
        from obra.messages.recovery import TEMPLATES as recovery_templates

        templates.update(recovery_templates)
    except ImportError:
        pass  # Domain not yet implemented

    try:
        from obra.messages.status import TEMPLATES as status_templates

        templates.update(status_templates)
    except ImportError:
        pass

    try:
        from obra.messages.progress import TEMPLATES as progress_templates

        templates.update(progress_templates)
    except ImportError:
        pass

    try:
        from obra.messages.errors import TEMPLATES as error_templates

        templates.update(error_templates)
    except ImportError:
        pass

    try:
        from obra.messages.warnings import TEMPLATES as warning_templates

        templates.update(warning_templates)
    except ImportError:
        pass

    try:
        from obra.messages.guidance import TEMPLATES as guidance_templates

        templates.update(guidance_templates)
    except ImportError:
        pass

    try:
        from obra.messages.prompts import TEMPLATES as prompt_templates

        templates.update(prompt_templates)
    except ImportError:
        pass

    try:
        from obra.messages.validator import TEMPLATES as validator_templates

        templates.update(validator_templates)
    except ImportError:
        pass

    # Validate all loaded templates
    for key, tpl in templates.items():
        _validate_template(key, tpl)

    return templates


def _get_templates() -> dict[str, MessageTemplate]:
    """
    Get the template dictionary with thread-safe lazy initialization.

    Uses double-checked locking pattern to prevent race conditions
    during CLI startup with multiple threads.

    Returns:
        Dictionary mapping template keys to MessageTemplate instances
    """
    global _templates

    # Fast path: already initialized
    if _templates is not None:
        return _templates

    # Slow path: acquire lock and check again
    with _lock:
        if _templates is None:
            _templates = _load_all_templates()
        return _templates


def _get_ascii_mode() -> bool:
    """
    Check if ASCII mode is enabled via environment or config.

    Returns:
        True if ASCII mode should be used
    """
    # Check environment variable first
    env_value = os.environ.get("OBRA_ASCII_MODE", "").lower()
    if env_value in ("1", "true", "yes"):
        return True

    # Try to check config (deferred import to avoid cycles)
    try:
        from obra.config.loaders import load_layered_config

        config, _, _ = load_layered_config()
        return not config.get("display", {}).get("emoji_enabled", True)
    except (ImportError, KeyError):
        pass

    return False


def _find_similar_keys(key: str, templates: dict[str, MessageTemplate]) -> list[str]:
    """
    Find keys similar to the given key, preferring same domain.

    Args:
        key: The key that wasn't found
        templates: Available templates

    Returns:
        List of up to 5 similar keys
    """
    # Extract domain from key if possible
    parts = key.split(".")
    domain_prefix = parts[0] if parts else ""

    # Collect candidates with same domain prefix first
    same_domain = [k for k in templates if k.startswith(domain_prefix + ".")]
    other_keys = [k for k in templates if not k.startswith(domain_prefix + ".")]

    # Simple similarity: keys that share prefix characters
    def prefix_match_len(k: str) -> int:
        for i, (a, b) in enumerate(zip(key, k, strict=False)):
            if a != b:
                return i
        return min(len(key), len(k))

    same_domain.sort(key=prefix_match_len, reverse=True)
    other_keys.sort(key=prefix_match_len, reverse=True)

    return (same_domain + other_keys)[:5]


# =============================================================================
# Public API (delegated from __init__.py)
# =============================================================================


def get_message(
    key: str,
    *,
    verbose: bool = False,
    ascii_mode: bool | None = None,
    **kwargs: object,
) -> str:
    """
    Get a formatted message by key.

    Args:
        key: Template key (e.g., 'recovery.auth.login')
        verbose: Use verbose variant if available
        ascii_mode: Use ASCII variant if available (auto-detect if None)
        **kwargs: Placeholder values

    Returns:
        Formatted message string

    Raises:
        KeyError: If key is not found (includes suggestions)
        ValueError: If required placeholders are missing
    """
    import logging

    logger = logging.getLogger(__name__)

    templates = _get_templates()

    if key not in templates:
        similar = _find_similar_keys(key, templates)
        similar_str = ", ".join(similar) if similar else "none"
        logger.debug("Message key not found: %s, using fallback", key)
        msg = f"Message key not found: '{key}'. Similar keys: {similar_str}"
        raise KeyError(msg)

    template = templates[key]

    # Check for missing required placeholders
    provided = set(kwargs.keys())
    required = set(template.placeholders)
    missing = required - provided
    if missing:
        msg = f"Missing required placeholders for '{key}': {sorted(missing)}"
        raise ValueError(msg)

    # Determine ASCII mode
    use_ascii = ascii_mode if ascii_mode is not None else _get_ascii_mode()

    return template.format(verbose=verbose, ascii_mode=use_ascii, **kwargs)


def list_messages(domain: MessageDomain | None = None) -> list[str]:
    """
    List all available message keys, optionally filtered by domain.

    Args:
        domain: Filter to only this domain (optional)

    Returns:
        Sorted list of message keys
    """
    templates = _get_templates()

    if domain is None:
        return sorted(templates.keys())

    return sorted(key for key, tpl in templates.items() if tpl.domain == domain)


def export_message_index() -> dict[str, dict[str, object]]:
    """
    Export all templates with metadata for auditing.

    Returns:
        Dictionary mapping keys to metadata dicts with fields:
        - domain: Domain name
        - category: Category name
        - placeholders: List of placeholder names
        - has_verbose: Whether verbose variant exists
        - has_ascii: Whether ASCII variant exists
    """
    templates = _get_templates()

    return {
        key: {
            "domain": tpl.domain.value,
            "category": tpl.category.value,
            "placeholders": list(tpl.placeholders),
            "has_verbose": tpl.verbose_template is not None,
            "has_ascii": tpl.ascii_template is not None,
        }
        for key, tpl in templates.items()
    }


# For testing: reset templates to force reload
def _reset_templates() -> None:
    """Reset templates for testing purposes."""
    global _templates
    with _lock:
        _templates = None
