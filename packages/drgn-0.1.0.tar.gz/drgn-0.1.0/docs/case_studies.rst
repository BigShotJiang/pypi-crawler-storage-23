Case Studies
============

These are writeups of real-world problems solved with drgn.

.. toctree::
   :maxdepth: 1

   case_studies/dm_crypt_key.rst
   case_studies/kyber_stack_trace.rst
