# Copyright (c) Meta Platforms, Inc. and affiliates.
# SPDX-License-Identifier: LGPL-2.1-or-later

"""
drgn internals

This package contains modules internal to drgn. You should not use them.
"""
