# Veez

**Veez** — Makes feel Python fly.

A collection of handy Python utilities for day-today or advance usages.

## Features

- Generate Fibbonacci(s)
- Checks Number Types
- Various List Utilities
- Simple Low Level Operations

## Installation

```bash
pip install veez
```
**OR**

```bash
pip3 install veez
```