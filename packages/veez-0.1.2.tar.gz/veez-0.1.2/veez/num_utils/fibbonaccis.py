class Fibbonaccis:
    @staticmethod

    def lim_fibbos(start1: int, start2: int, limit: int):
        sequence = [start1, start2]
    
        while len(sequence) < limit:
            next_val = sequence[-1] + sequence[-2]
            sequence.append(next_val)
        
        return sequence
    def inf_fibbos(start1: int, start2: int, ignore_warning: bool = False):
        import math

        if ignore_warning == False:
            print("Warning, the following program may crash your device..")
        else:
            pass

        limit = math.inf
        sequence = [start1, start2]
    
        while len(sequence) < limit:
            next_val = sequence[-1] + sequence[-2]
            sequence.append(next_val)
        
        return sequence