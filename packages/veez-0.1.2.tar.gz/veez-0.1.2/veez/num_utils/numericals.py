from typing import Union, List, Tuple
import sympy

class Numericals:
    @staticmethod

    def are_odd_or_even(collections_to_check: Union[List, Tuple], figure_out: str, return_how: str):
        ls = []

        if figure_out.lower() not in ["even", "odd"]:
            raise ValueError("figure_out parameter must be 'even' or 'odd'.")

        for nums in collections_to_check:
            if not isinstance(nums, int):
                raise TypeError("Items in the given list/tuple must all be integers in the collections_to_check parameter.")
            else:
                if nums % 2 == 0:
                    if figure_out.lower() == "even":
                        ls.append("True")
                    else:
                        ls.append("False")
                else:
                    if figure_out.lower() == "even":
                        ls.append("False")
                    else:
                        ls.append("True")
        
        if return_how.lower() == "list":
            return list(ls)
        elif return_how.lower() == "tuple":
            return tuple(ls)
        elif return_how.lower() == "set":
            raise ValueError("Cannot return set due to possible duplicate result conflicts in return_how parameter.")
        else:
            raise ValueError("Cannot accept anything except list/tuple in return_how parameter.")
    def is_odd_or_even(num: int, figure_out: str):
        if figure_out.lower() not in ["even", "odd"]:
            raise TypeError("figure_out parameter must be 'even' or 'odd'.")
        else:
            if num % 2 == 0:
                if figure_out.lower() == "even":
                    return True
                else:
                    return False
            else:
                if figure_out.lower() == "even":
                    return False
                else:
                    return True
    def is_prime_or_composite(num: int, figure_out: str):
        if figure_out.lower() not in ["prime", "composite"]:
            raise TypeError("figure_out parameter must be 'prime' or 'composite'.")
        
        return sympy.isprime(num)
    def are_prime_or_composite(collections_to_check: Union[List, Tuple], figure_out: str, return_how: str):
        if figure_out.lower() not in ["prime", "composite"]:
            raise TypeError("figure_out parameter must be 'prime' or 'composite'.")
        
        for nums in collections_to_check:
            if not isinstance(nums, int):
                raise TypeError("Items in the given list/tuple must all be integers in the collections_to_check parameter.")
          
            ls = []
            var = sympy.isprime(nums)

            if var == True:
                if figure_out == "prime":
                    ls.append("True")
                else:
                    ls.append("False")
            else:
                if figure_out == "prime":
                    ls.append("False")
                else:
                    ls.append("True")
        
        return ls