class ListOperations:
    @staticmethod

    def all_caps(list_to: list[str]) -> list[str]:
        ls = []
        
        for items in list_to:
            ls.append(items.capitalize())
        
        return ls
    def all_uppers(list_to: list[str]) -> list[str]:
        ls = []
        
        for items in list_to:
            ls.append(items.upper())
        
        return ls
    def all_lowers(list_to: list[str]) -> list[str]:
        ls = []
        
        for items in list_to:
            ls.append(items.lower())
        
        return ls
    def all_rands(list_to: list[str], length: int = None) -> list[str]:
        import random
        import string

        ls = []

        if length == None:
            for items in list_to:
                char_rule = string.ascii_letters + string.digits + string.punctuation

                item = ''.join(random.choices(char_rule))
                ls.append(item)
        else:
            for items in list_to:
                char_rule = string.ascii_letters + string.digits + string.punctuation

                item = ''.join(random.choices(char_rule, k=length))
                ls.append(item)

        return ls