import os

class DeleteVarsFiles:  
    def delete(file: str):
        os.remove(file)
    def deleteS(files: list[str] | tuple[str] | set[str]):
        for file in files:
            os.rename(file)