import os

class RenameVarsFiles:
    def rename(file: str, name: str):
        os.rename(file, name)
    def renameS(files: list[str] | tuple[str] | set[str], names: list[str] | tuple[str] | set[str]):
        if len(files) != len(names):
            raise IndexError("The amount of files to be renamed does not match the amout of names requested")
        
        for file, name in zip(files, names):
            os.rename(file, name)