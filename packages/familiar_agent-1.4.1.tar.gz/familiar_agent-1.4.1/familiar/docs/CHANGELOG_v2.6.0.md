# Familiar v2.6.0 — Release Notes

**Date:** 2026-02-06

## What Changed

### Launch Experience Overhaul
- **`run.sh` is now the universal entry point** — auto-detects Anthropic, OpenAI, or Ollama based on environment variables. No more guessing which script to run.
- **Root directory cleaned up** — from 37 items to 21. Install scripts, dev tools, and detailed docs moved to `scripts/` and `docs/`. Users see: README, run.sh, run.bat, config sample, and package directories.
- **`FamiliarLauncher.py` reduced from 327 to 39 lines** — now a thin wrapper that delegates to the `launcher/` package. One GUI implementation to maintain instead of two.
- **`run.bat` updated** — same provider auto-detection as run.sh for Windows.

### Pi Installer Consolidation
- **`install-nonprofit-pi.sh` merged into `install-pi.sh --nonprofit`** — adds nonprofit skills preset (email, calendar, tasks, nonprofit, knowledge, proactive), enables Telegram, prints cost estimate. One script instead of two.

### README Rewrite
- Opens with `cd familiar && ./run.sh` — three lines to running.
- No more `FAMILIAR_ZIP=` references.
- Advanced install paths clearly separated under "Advanced Installation."

### Cleanup (from prior session, included in this release)
- All 46 `[LAST NAME]` redactions fixed
- All license headers unified to MIT (zero BSL references)
- Version unified across all packages
- 49 test files and 16 dev doc artifacts stripped
- `requirements.txt` split: core (7 packages) vs `requirements-full.txt`
- `install.sh` auto-detects its own directory

## Upgrade

Replace your existing Familiar directory with the contents of this zip.
No config migration needed — `config.sample.yaml` is unchanged.
