# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Licensed under the MIT License

"""
Mesh Network Package v2.7.3

Complete peer-to-peer agent networking:
  Phase 1 (v2.7.0): mDNS Discovery + Peer Gateway Mode
  Phase 2 (v2.7.1): Signal Protocol Trust + PermissionMatrix
  Phase 3 (v2.7.2): Shared Memory Bridge via SkillBus
  Phase 4 (v2.7.3): Orchestrated Delegation via RemoteAgent
"""

# Original mesh module (was core/mesh.py, now core/mesh/gateway.py)
# Phase 1: Discovery (v2.7.0)
from .discovery import DiscoveredPeer, MeshDiscovery, PeerStore
from .gateway import (
    MeshConfig,
    MeshGateway,
    MeshNode,
    Message,
    MsgType,
    NodeInfo,
    generate_connection_string,
    get_mesh_config,
    run_gateway,
    run_node,
)

# Phase 3: Shared Memory (v2.7.2)
from .memory_bridge import (
    MemoryBridge,
    MeshMemoryResult,
    SharedMemoryMeta,
    SharedMemoryStore,
)
from .mesh_skill_endpoint import (
    MeshSkillEndpoint,
    register_remote_skills,
    unregister_remote_skills,
)

# Phase 4: Orchestrated Delegation (v2.7.3)
from .remote_agent import RemoteAgent

# Phase 2: Trust (v2.7.1)
from .trust import (
    MeshTrustManager,
    PermissionMatrix,
    TrustRecord,
    TrustStore,
    compute_fingerprint,
    compute_verification_code,
)

__all__ = [
    # Gateway
    "MeshGateway",
    "MeshNode",
    "MeshConfig",
    "Message",
    "MsgType",
    "NodeInfo",
    "get_mesh_config",
    "generate_connection_string",
    "run_gateway",
    "run_node",
    # Discovery (v2.7.0)
    "MeshDiscovery",
    "DiscoveredPeer",
    "PeerStore",
    # Trust (v2.7.1)
    "MeshTrustManager",
    "TrustRecord",
    "TrustStore",
    "PermissionMatrix",
    "compute_verification_code",
    "compute_fingerprint",
    # Shared Memory (v2.7.2)
    "MemoryBridge",
    "SharedMemoryStore",
    "SharedMemoryMeta",
    "MeshMemoryResult",
    # Delegation (v2.7.3)
    "RemoteAgent",
    "MeshSkillEndpoint",
    "register_remote_skills",
    "unregister_remote_skills",
]
