"""Operations sub-package – raster and vector implementations."""
