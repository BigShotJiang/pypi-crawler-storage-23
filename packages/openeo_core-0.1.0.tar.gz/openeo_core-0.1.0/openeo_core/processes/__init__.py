"""Processes sub-package – JSON spec registry."""

from openeo_core.processes.registry import ProcessRegistry

__all__ = ["ProcessRegistry"]
