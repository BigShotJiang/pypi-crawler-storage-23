"""Route subpackage for aweb FastAPI endpoints."""
