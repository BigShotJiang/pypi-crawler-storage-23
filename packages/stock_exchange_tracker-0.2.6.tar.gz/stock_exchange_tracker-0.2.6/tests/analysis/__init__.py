"""Tests for src.analysis modules."""
