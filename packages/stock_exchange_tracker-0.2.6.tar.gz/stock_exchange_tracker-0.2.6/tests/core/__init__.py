"""Tests for src.core modules."""
