"""Tests for Stock Exchange Tracker."""

