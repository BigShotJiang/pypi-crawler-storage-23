"""Data storage and persistence."""

from .data_storage import DataStorage

__all__ = ["DataStorage"]

