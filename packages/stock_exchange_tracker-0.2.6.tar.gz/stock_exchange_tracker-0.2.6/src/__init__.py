"""Stock Exchange Tracker - A professional stock market tracking tool."""

__version__ = "1.0.0"

