# froscord/voice/state.py

# vc_id -> {"owner": user_id, "message": message_id}
TEMP_VC: dict[int, dict] = {}

# vc_id -> set(user_ids muted inside this VC)
TEMP_MUTED: dict[int, set[int]] = {}