"""Allow running as: python -m metaflow_mcp_server"""

from metaflow_mcp_server.server import main

main()
