"""
SnapTrade Mapping Utilities
============================
Maps SnapTrade types and values to CPZ SDK models.
"""

from __future__ import annotations

from ..enums import OrderSide, OrderType, TimeInForce


def map_order_status(status: str) -> str:
    status_lower = status.lower().replace(" ", "_")
    status_map = {
        "filled": "filled",
        "executed": "filled",
        "canceled": "canceled",
        "cancelled": "canceled",
        "pending": "pending",
        "new": "pending",
        "open": "pending",
        "accepted": "accepted",
        "partially_filled": "partially_filled",
        "partial": "partially_filled",
        "rejected": "rejected",
        "expired": "expired",
    }
    return status_map.get(status_lower, "pending")


def map_order_side(side: str) -> OrderSide:
    if side.upper() in ("BUY", "B"):
        return OrderSide.BUY
    return OrderSide.SELL


def map_order_type(order_type: str) -> OrderType:
    if order_type.upper() in ("MKT", "MARKET"):
        return OrderType.MARKET
    if order_type.upper() in ("LMT", "LIMIT"):
        return OrderType.LIMIT
    return OrderType.MARKET


def map_time_in_force(tif: str) -> TimeInForce:
    tif_upper = tif.upper()
    if tif_upper == "GTC":
        return TimeInForce.GTC
    if tif_upper == "IOC":
        return TimeInForce.IOC
    if tif_upper == "FOK":
        return TimeInForce.FOK
    return TimeInForce.DAY
