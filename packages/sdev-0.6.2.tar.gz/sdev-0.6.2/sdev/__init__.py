"""
SDEV - 串口开发板控制器

- Demoboard：统一封装本地与远程串口交互；
- any_device(device_name)：按 DEVICE 模糊匹配并从 list 缓存取板，供脚本使用。
"""

from __future__ import annotations

from .models import Demoboard
from .remote import any_device

__version__ = "0.6.2"
__author__ = "klrc"
__email__ = "1440698245@qq.com"

__all__ = ["Demoboard", "any_device"]
