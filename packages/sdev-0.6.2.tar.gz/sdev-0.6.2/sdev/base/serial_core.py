from __future__ import annotations

"""
SerialCore：本地串口收发核心（纯 IO 层）

- 串口锁：避免多进程同时占用同一串口；
- connect / disconnect：管理串口与后台读线程生命周期；
- send / scan / clear：最基础的串口读写能力；
- scan_serial_ports：扫描本机可用串口列表；
- 不负责任何日志输出和显示，由上层 Demoboard / CLI 决定。
"""

import os
import queue
import re
import sys
import threading
import time
from typing import Generator, Iterable, Optional

import serial

if sys.platform == "win32":
    import msvcrt
else:  # Unix
    import fcntl

CTRL_C = "\x03"


def _port_lock_path(port: str) -> str:
    """锁文件路径：XDG_RUNTIME_DIR/sdev 或 ~/.cache/sdev，避免 /tmp。Windows 同用用户目录。"""
    base = os.environ.get("XDG_RUNTIME_DIR") or os.path.join(os.path.expanduser("~"), ".cache")
    lock_dir = os.path.join(base, "sdev")
    os.makedirs(lock_dir, mode=0o700, exist_ok=True)
    safe = re.sub(r"[^a-zA-Z0-9_.-]", "_", os.path.basename(port))
    return os.path.join(lock_dir, f"port_{safe}.lock")


def _acquire_port_lock(port: str):
    """
    对 port 持有跨进程排他锁（阻塞直到拿到），返回打开的 fd，调用方负责 close。
    Unix: fcntl.flock；Windows: msvcrt.locking。
    """
    path = _port_lock_path(port)
    fd = os.open(path, os.O_RDWR | os.O_CREAT, 0o600)
    if sys.platform == "win32":
        while True:
            try:
                msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
                break
            except OSError:
                time.sleep(0.1)
        return fd
    # Unix
    while True:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            break
        except BlockingIOError:
            time.sleep(0.1)
    return fd


def _release_port_lock(fd: Optional[int]) -> None:
    if fd is None:
        return
    try:
        if sys.platform == "win32":
            msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)
        else:
            fcntl.flock(fd, fcntl.LOCK_UN)
    finally:
        try:
            os.close(fd)
        except OSError:
            pass


def _try_acquire_port_lock(port: str) -> Optional[int]:
    """
    非阻塞尝试获取 port 的跨进程锁。成功返回 fd（调用方负责 _release_port_lock），失败返回 None（如已被占用）。
    """
    path = _port_lock_path(port)
    try:
        fd = os.open(path, os.O_RDWR | os.O_CREAT, 0o600)
    except OSError:
        return None
    try:
        if sys.platform == "win32":
            msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
        else:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except (OSError, BlockingIOError):
        try:
            os.close(fd)
        except OSError:
            pass
        return None
    return fd


def scan_serial_ports() -> list[str]:
    """扫描本机串口设备名（仅包含 ttyUSB）。无 pyserial 或无可匹配端口时返回 []。"""
    try:
        import serial.tools.list_ports
    except ImportError:
        return []
    out = []
    for p in serial.tools.list_ports.comports():
        if "ttyUSB" in (p.device or ""):
            out.append(p.device)
    return sorted(out)


def check_port_alive_nonblock(
    port: str,
    baudrate: int = 115200,
    timeout: float = 1.5,
    prompt_flag: str = " #",
) -> dict[str, object]:
    """
    非阻塞检查单个串口是否可用：
    - 先尝试拿跨进程锁，避免与其他进程冲突；
    - 成功后短暂打开串口，发送换行并等待包含 prompt_flag 的输出；
    - 超时/异常时返回 available=False，并附带 reason。

    返回结构：
    {"port": str, "baudrate": int, "available": bool, "reason": str}
    """
    fd = _try_acquire_port_lock(port)
    if fd is None:
        return {"port": port, "baudrate": baudrate, "available": False, "reason": "locked"}
    try:
        ser = serial.Serial(port, baudrate, timeout=min(0.2, timeout))
        if not ser.is_open:
            return {"port": port, "baudrate": baudrate, "available": False, "reason": "open_failed"}
        try:
            ser.reset_input_buffer()
            ser.write(b"\n")
            deadline = time.monotonic() + timeout
            acc: list[str] = []
            while time.monotonic() < deadline:
                line = ser.readline()
                if line:
                    try:
                        acc.append(line.decode("utf-8", errors="replace"))
                    except Exception:
                        pass
                    if prompt_flag in "".join(acc):
                        return {"port": port, "baudrate": baudrate, "available": True, "reason": "ok"}
                time.sleep(0.05)
            return {"port": port, "baudrate": baudrate, "available": False, "reason": "timeout"}
        finally:
            ser.close()
    except Exception as e:
        return {"port": port, "baudrate": baudrate, "available": False, "reason": str(e)}
    finally:
        _release_port_lock(fd)


def _content_contains_ctrl_c(text: str) -> bool:
    """是否包含设备回显的 Ctrl+C。"""
    n = text.replace("\x00", "")
    return CTRL_C in n or "^C" in n


class SerialCore:
    """
    本地串口核心：
    - 负责串口连接、后台读线程、send/scan/clear；
    - 持有跨进程文件锁，保证同一时刻只有一个进程占用同一串口。
    """

    def __init__(self, port: str, baudrate: int = 115200):
        self.port = port
        self.baudrate = baudrate
        self._serial: Optional[serial.Serial] = None
        self._buffer: queue.Queue = queue.Queue()
        self._reader_thread: Optional[threading.Thread] = None
        self._is_connected = False
        self._stop_reading = False
        self._lock_fd: Optional[int] = None

        # 扫描相关通用参数
        self._scan_timeout = 0.1
        self._max_lines_per_prompt = 4
        # 仅串口与缓冲区逻辑，不包含任何日志/显示状态

    # --- 轻量级日志接口：供上层 Demoboard.check_alive 使用，默认静默 ---

    def _log(self, level: str, message: str) -> None:
        """
        占位日志接口：目前串口核心层不做实际日志记录，仅为上层提供统一调用点。
        """
        return

    def error(self, message: str) -> None:
        self._log("error", message)

    def warning(self, message: str) -> None:
        self._log("warning", message)

    def success(self, message: str) -> None:
        self._log("success", message)

    # --- 连接与资源管理 ---

    def _serial_reader(self) -> None:
        while not self._stop_reading and self._serial is not None and self._serial.is_open:
            raw = self._serial.readline()
            if raw:
                try:
                    line = raw.decode("utf-8")
                    if line:
                        self._buffer.put(line)
                except UnicodeDecodeError:
                    continue

    def connect(self) -> None:
        if self._is_connected:
            return
        self._lock_fd = _acquire_port_lock(self.port)
        try:
            self._serial = serial.Serial(self.port, self.baudrate, timeout=self._scan_timeout)
            if not self._serial.is_open:
                raise RuntimeError(f"无法打开串口 {self.port}")
            self._stop_reading = False
            self._reader_thread = threading.Thread(target=self._serial_reader, daemon=True)
            self._reader_thread.start()
            self._is_connected = True
        except Exception:
            _release_port_lock(self._lock_fd)
            self._lock_fd = None
            raise

    def disconnect(self) -> None:
        if not self._is_connected:
            return
        self._stop_reading = True
        self._buffer.put(None)
        if self._reader_thread is not None and self._reader_thread.is_alive():
            self._reader_thread.join()
        self._reader_thread = None
        if self._serial is not None and self._serial.is_open:
            self._serial.close()
            self._serial = None
        _release_port_lock(self._lock_fd)
        self._lock_fd = None
        self._is_connected = False

    def __enter__(self) -> "SerialCore":
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.disconnect()

    # --- 基础收发 ---

    def send(self, prompt: str) -> None:
        if not self._is_connected or self._serial is None:
            raise RuntimeError("not connected")
        assert prompt is not None
        self._serial.write((prompt + "\n").encode("utf-8"))
        self._serial.flush()

    def _scan_raw(self, timeout: Optional[float] = None) -> Generator[str, None, None]:
        if not self._is_connected:
            raise RuntimeError("not connected")
        last_activity = time.monotonic()
        scan_timeout = self._scan_timeout if timeout is not None else None

        while True:
            try:
                line = self._buffer.get(timeout=scan_timeout) if scan_timeout else self._buffer.get()
            except queue.Empty:
                if timeout is not None and time.monotonic() - last_activity > timeout:
                    raise TimeoutError("scan deadline exceeded (no response)")
                continue
            if line is None:
                return
            last_activity = time.monotonic()
            yield line

    def scan(
        self,
        end_flag: Optional[str],
        timeout: Optional[float] = None,
        replace_with_acc: bool = False,
    ) -> Generator[str, None, None]:
        if end_flag is None:
            # 简单模式：仅根据超时结束扫描，逐行返回。
            try:
                for line in self._scan_raw(timeout):
                    yield line
            except TimeoutError:
                return

        # 有 end_flag 时，根据 replace_with_acc 走两套策略：
        # - replace_with_acc=True：保留原有「多行聚合」语义，适合命令回显等场景；
        # - replace_with_acc=False：流式逐行返回，end_flag 只作「停止条件」，不做多行聚合。
        if replace_with_acc:
            acc_cache = []
            try:
                for line in self._scan_raw(timeout):
                    acc_cache.append(line)
                    if len(acc_cache) > self._max_lines_per_prompt:
                        yield acc_cache.pop(0)

                    acc_line = "".join([x.rstrip("\r\n") for x in acc_cache])
                    found = end_flag in acc_line or (end_flag == CTRL_C and _content_contains_ctrl_c(acc_line))
                    if found:
                        yield acc_line + "\n"
                        break
            except TimeoutError:
                # 超时时先把已缓存的内容输出，再把异常抛给上层做决策。
                for x in acc_cache:
                    yield x
                raise
        else:
            # 流式模式：每读到一行就立刻返回，end_flag 仅用于决定何时停止。
            for line in self._scan_raw(timeout):
                yield line
                line_clean = line.rstrip("\r\n")
                found = end_flag in line_clean or (end_flag == CTRL_C and _content_contains_ctrl_c(line_clean))
                if found:
                    break

    def clear(self) -> None:
        while True:
            try:
                item = self._buffer.get_nowait()
                if item is None:
                    self._buffer.put(None)
                    return
            except queue.Empty:
                return

__all__ = [
    "CTRL_C",
    "SerialCore",
    "scan_serial_ports",
    "_try_acquire_port_lock",
    "_release_port_lock",
    "check_port_alive_nonblock",
]

