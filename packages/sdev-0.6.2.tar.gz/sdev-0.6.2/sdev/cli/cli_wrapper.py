"""
命令行入口（新布局）：

- sdev 'cmd'：在当前激活的 demoboard（本地或远程）上执行命令并回显输出；
- sdev HASH 'cmd'：按 HASH 激活对应 remote，再在其上执行命令；
- sdev list [type=demoboard]：列出 demoboard 状态（默认包含本地+remote，--local 仅本地）；
- sdev activate HASH：按 HASH 激活某个 demoboard；
- sdev deactivate：清空当前激活状态（本地 + remote）；
- sdev server start/stop/restart/status：启动/停止/重启/查看 demoboard server（TCP + UDP discovery）。
"""

from __future__ import annotations

import argparse
import itertools
import json
import os
import shutil
import signal
import socket
import subprocess
import sys
import threading
import time
from types import SimpleNamespace
from typing import Any, Optional, Tuple

from ..models import Demoboard
from ..base.serial_core import check_port_alive_nonblock
from ..remote import discovery

# 终端颜色
_GREEN = "\033[32m"
_RED = "\033[31m"
_YELLOW = "\033[33m"
_CYAN = "\033[36m"
_GREY = "\033[90m"
_RESET = "\033[0m"

# server 日志文件大小上限（字节），超过则简单轮转到 *.1
_SERVER_LOG_MAX_BYTES = 1 * 1024 * 1024  # 1 MiB


def _get_server_pid_path() -> str:
    """
    sdev server 的 pid 文件路径：默认 ~/.cache/sdev/server.pid 或 XDG_RUNTIME_DIR/sdev/server.pid。
    """
    base = os.environ.get("XDG_RUNTIME_DIR") or os.path.join(os.path.expanduser("~"), ".cache")
    pid_dir = os.path.join(base, "sdev")
    os.makedirs(pid_dir, mode=0o700, exist_ok=True)
    return os.path.join(pid_dir, "server.pid")


def _read_server_pid() -> Optional[int]:
    path = _get_server_pid_path()
    if not os.path.isfile(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            raw = f.read().strip()
        return int(raw) if raw else None
    except (OSError, ValueError):
        return None


def _get_server_log_path() -> str:
    """
    sdev server 的日志文件路径：默认 ~/.cache/sdev/server.log 或 XDG_RUNTIME_DIR/sdev/server.log。
    """
    base = os.environ.get("XDG_RUNTIME_DIR") or os.path.join(os.path.expanduser("~"), ".cache")
    log_dir = os.path.join(base, "sdev")
    os.makedirs(log_dir, mode=0o700, exist_ok=True)
    log_path = os.path.join(log_dir, "server.log")

    # 简单轮转：超过阈值时将当前日志重命名为 server.log.1（覆盖），新日志从空文件开始。
    try:
        if os.path.exists(log_path) and os.path.getsize(log_path) > _SERVER_LOG_MAX_BYTES:
            backup_path = log_path + ".1"
            try:
                os.replace(log_path, backup_path)
            except OSError:
                # 回退策略：无法重命名则直接删除旧日志，避免无限增长
                try:
                    os.remove(log_path)
                except OSError:
                    pass
    except OSError:
        # 获取大小/轮转失败时静默忽略，继续使用原路径
        pass

    return log_path


def _get_local_activation_path() -> str:
    """本地串口激活记录文件路径，与 get_sdev_config_dir 一致。"""
    return os.path.join(discovery.get_sdev_config_dir(), "local_activation.json")


def _get_sdev_cache_dir() -> str:
    """sdev 运行时目录（server pid、日志、端口锁）。reset 时整目录删除可避免漏清。"""
    return os.path.dirname(_get_server_pid_path())


def _load_local_activation() -> Optional[dict[str, Any]]:
    path = _get_local_activation_path()
    if not os.path.isfile(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError):
        return None
    return data if isinstance(data, dict) else None


def _save_local_activation(record: dict[str, Any]) -> None:
    path = _get_local_activation_path()
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(record, f, ensure_ascii=False, indent=2)


def _is_process_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    return True


def _get_default_port() -> str:
    act = _load_local_activation()
    if act and act.get("active") and act.get("port"):
        return str(act.get("port"))
    return os.environ.get("SDEV_PORT", "/dev/ttyUSB0")


def _get_default_baudrate() -> int:
    act = _load_local_activation()
    if act and act.get("active") and act.get("baudrate"):
        try:
            return int(act.get("baudrate"))
        except (TypeError, ValueError):
            pass
    try:
        return int(os.environ.get("SDEV_BAUDRATE", "115200"))
    except ValueError:
        return 115200


def _run_with_spinner(label: str, fn, *args, **kwargs):
    """
    单行：label + 行末旋转动画，完成后改为 label + ✔。
    """
    done = False
    frames = itertools.cycle("|/-\\")

    def spinner_worker() -> None:
        while not done:
            frame = next(frames)
            sys.stdout.write(f"\r{label} {frame}")
            sys.stdout.flush()
            time.sleep(0.1)

    t = threading.Thread(target=spinner_worker, daemon=True)
    t.start()
    try:
        result = fn(*args, **kwargs)
    finally:
        done = True  # type: ignore[assignment]
        t.join()
        sys.stdout.write(f"\r{label} {_GREEN}✔{_RESET}\n")
        sys.stdout.flush()
    return result


def _run_parallel_with_spinners(
    specs: list[tuple[str, Any]],
) -> list[Any]:
    """
    多行并行：每行 label + 行末旋转动画，该行任务完成后该行改为 label + ✔。
    specs: [(label, callable)], 每个 callable() 在子线程执行，返回结果收集为 list。
    """
    n = len(specs)
    if n == 0:
        return []
    results: list[Any] = [None] * n
    done_flags: list[bool] = [False] * n
    frame_iters = [itertools.cycle("|/-\\") for _ in range(n)]

    def run_i(i: int) -> None:
        try:
            results[i] = specs[i][1]()
        finally:
            done_flags[i] = True

    threads = [threading.Thread(target=run_i, args=(i,), daemon=True) for i in range(n)]
    for t in threads:
        t.start()

    def display_worker() -> None:
        while not all(done_flags):
            for i in range(n):
                label = specs[i][0]
                if done_flags[i]:
                    line = f"{label} {_GREEN}✔{_RESET}"
                else:
                    line = f"{label} {next(frame_iters[i])}"
                sys.stdout.write(line + "\n")
            sys.stdout.flush()
            if not all(done_flags):
                sys.stdout.write(f"\033[{n}A")
            time.sleep(0.1)

    display_thread = threading.Thread(target=display_worker, daemon=True)
    display_thread.start()
    for t in threads:
        t.join()
    time.sleep(0.15)
    for i in range(n):
        sys.stdout.write(f"{specs[i][0]} {_GREEN}✔{_RESET}\n")
    sys.stdout.flush()
    return results


def _scan_targets(targets: list[dict[str, Any]], timeout: float) -> list[dict[str, Any]]:
    """复用 board_list 的并行探测，不做终端输出。"""
    from ..remote.board_list import _scan_targets as _do_scan
    return _do_scan(targets, timeout)


def _scan_targets_with_spinner(targets: list[dict[str, Any]], timeout: float) -> list[dict[str, Any]]:
    """
    并行探测一组 target（本地 + 远程），在控制台用**单行**旋转动画展示进度。
    """
    if not targets:
        return []

    kinds = {t.get("kind") for t in targets}
    n = len(targets)
    if kinds == {"local"}:
        label = f"{_CYAN}[LOCAL]{_RESET} scanning {n} port(s)"
    elif kinds == {"remote"}:
        label = f"{_CYAN}[REMOTE]{_RESET} checking {n} board(s)"
    else:
        label = f"{_CYAN}[SCAN]{_RESET} checking {n} target(s)"

    return _run_with_spinner(label, _scan_targets, targets, timeout)


def _compute_host_hash(host: str, service_port: int, port: str) -> str:
    """
    根据 host + service_port + 串口号 生成短 hash，用于在 CLI 中标识单块开发板。
    - 使用 sha1 截断为 6 位 hex，足够短且在当前规模下碰撞概率可忽略。
    """
    import hashlib

    key = f"{host}:{service_port}:{port}".encode("utf-8", errors="ignore")
    return hashlib.sha1(key).hexdigest()[:6]


def _looks_like_hash(token: str) -> bool:
    """
    简单判断一个 token 是否形如我们生成的 HASH（8 位十六进制）。
    用于区分 `sdev HASH 'cmd'` 与普通 `sdev 'cmd'`。
    """
    # 目前使用 6 位 hex 作为 HASH 长度，这里接受 6 或 8 位，兼容未来可能的调整。
    if len(token) not in (6, 8):
        return False
    import string

    hexdigits = set(string.hexdigits)
    return all(c in hexdigits for c in token)


def _get_combined_demoboard_list_silent(
    timeout: float = 2.0,
    service_port: int = 7000,
    baudrate: Optional[int] = None,
    remote_hosts_override: Optional[list] = None,
) -> list[dict[str, Any]]:
    """
    静默获取「本地 + 远程」combined 列表并填充 device（保持原始大小写），不输出任何日志。
    供 activate 按 device 模糊匹配时使用。实现复用 sdev.remote.board_list。
    """
    from ..remote.board_list import get_combined_demoboard_list_silent as _get_combined

    effective_baud = baudrate or _get_default_baudrate()
    return _get_combined(
        timeout=timeout,
        service_port=service_port,
        baudrate=effective_baud,
        remote_hosts_override=remote_hosts_override,
    )


def _format_shell_prefix(host: Optional[str], port: str, baudrate: int) -> str:
    from ..util import format_shell_prefix as _fmt
    return _fmt(host, port, baudrate)


def cmd_server_status(args: argparse.Namespace) -> int:
    """
    打印本机 sdev server 状态与最近日志。
    """
    pid = _read_server_pid()
    running = pid is not None and _is_process_alive(pid)
    log_path = _get_server_log_path()

    if running:
        print(f"{_GREEN}[server] status: RUNNING{_RESET} (pid={pid})")
    else:
        print(f"{_RED}[server] status: NOT RUNNING{_RESET}")

    print(f"[server] log file: {log_path}")

    try:
        with open(log_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
    except OSError:
        print("[server] 日志文件不存在。")
        return 0

    n = max(1, int(getattr(args, "lines", 10) or 10))
    tail = lines[-n:]
    print(f"[server] 最近 {len(tail)} 行日志：")
    for line in tail:
        # 原样输出，保持 loguru 格式
        print(line.rstrip("\n"))
    return 0


def _resolve_demoboard_target_for_shell() -> Tuple[Optional[str], str, int]:
    """
    解析 shell 使用的 demoboard。任意时刻仅有一个目标被激活（activate 本地会清空远程，反之亦然）。
    - 优先使用「远程激活」记录（host:/dev/ttyUSBx）；
    - 其次使用「本地激活」记录（/dev/ttyUSBx）；
    - 否则回退到默认本地端口 + 波特率。
    返回 (host, port, baudrate)，其中 host 为 None 表示本地。
    """
    # 1. 远程激活优先：从 discovery 的 activation 记录中选择 active 的一条。
    try:
        remote_records = discovery.load_activations()
    except Exception:
        remote_records = []
    for r in remote_records:
        if not isinstance(r, dict):
            continue
        if not r.get("active"):
            continue
        host = (r.get("host") or "").strip()
        port = (r.get("port") or "").strip()
        if not host or not port:
            continue
        try:
            baud = int(r.get("baudrate") or _get_default_baudrate())
        except (TypeError, ValueError):
            baud = _get_default_baudrate()
        return host, port, baud

    # 2. 本地激活
    act = _load_local_activation()
    if act and act.get("active") and act.get("port"):
        port = str(act.get("port"))
        try:
            baud = int(act.get("baudrate") or _get_default_baudrate())
        except (TypeError, ValueError):
            baud = _get_default_baudrate()
        return None, port, baud

    # 3. 默认本地
    return None, _get_default_port(), _get_default_baudrate()


def cmd_shell(args: argparse.Namespace) -> int:
    """
    在当前激活的 demoboard（本地或远程）上执行单条命令并回显输出。
    """
    host, port, baudrate = _resolve_demoboard_target_for_shell()
    prefix = _format_shell_prefix(host, port, baudrate)
    print(f"{_CYAN}{prefix}{_RESET}")

    # 若未显式指定 --timeout，则默认等待 60 秒，避免长命令过早被认为超时。
    effective_timeout: Optional[float] = args.timeout if args.timeout is not None else 60.0

    with Demoboard(port, baudrate, host=host) as board:
        try:
            _ = board.execute_command(args.command, flag=args.flag, timeout=effective_timeout)
        except KeyboardInterrupt:
            # 将本地 Ctrl-C 映射为对板子的真实 Ctrl-C 中断，
            # 然后通过 execute_command(None, ...) 等待提示符，尽量让远端命令完整收尾。
            try:
                board.send_interrupt()
                # 不再发送新命令，仅等待当前提示符出现作为“收尾”信号。
                _ = board.execute_command(None, flag=args.flag, timeout=effective_timeout)
            except Exception:
                pass
            print()  # 保证光标回到新行
            return 130  # 约定：被 Ctrl-C 中断
        except TimeoutError as e:
            print(e, file=sys.stderr)
            return 1
        print()
        # sys.stdout.flush()
    return 0


def cmd_remote_list(args: argparse.Namespace) -> int:
    service_port = getattr(args, "service_port", 7000)
    hosts = discovery.get_remote_hosts(service_port=service_port, override=getattr(args, "remote_hosts", None))
    if not hosts:
        print(
            f"{_RED}[remote ERROR]{_RESET} 未发现任何在线 host（请确认各机已执行 'sdev server start' 且在同一局域网）",
            file=sys.stderr,
        )
        return 1
    print(f"{_CYAN}[remote INFO]{_RESET} 即将扫描 {len(hosts)} 台 remote host")

    all_boards = []
    for host, port in hosts:
        label = f"[remote] probing {host}:{port}"
        boards = _run_with_spinner(
            label,
            discovery.fetch_boards_from_host,
            host,
            port,
            timeout=args.timeout,
        )
        # 针对单个 host 打印阶段性结果
        up_count = sum(1 for b in boards if b.get("available"))
        total = len(boards)
        if total == 0:
            color = _YELLOW
            state = "EMPTY"
            extra = "no boards reported"
        elif up_count > 0:
            color = _GREEN
            state = "UP"
            extra = f"{up_count}/{total} up"
        else:
            color = _RED
            state = "DOWN"
            extra = f"0/{total} up"
        print(f"{color}[remote {state}]{_RESET} {host}:{port} - {extra}")

        all_boards.append(boards)
    merged = discovery.merge_and_dedupe(all_boards)
    print(f"{_CYAN}[remote INFO]{_RESET} 共发现 {len(merged)} 个 demoboard")
    if not merged:
        return 0

    # 读取本地 activation 记录，标记哪些 target 已被激活
    activations = {(r.get("host"), r.get("port")): r for r in discovery.load_activations() if r.get("active")}

    header = f"{'HOST':<18} {'PORT':<18} {'BAUD':<7} {'UP':<4} {'ACTIVE':<7} {'REASON'}"
    print(header)
    print("-" * len(header))
    for b in merged:
        host = (b.get("host") or "")[:16]
        port = (b.get("port") or "")[:16]
        baud = str(b.get("baudrate") or 115200)
        up = "yes" if b.get("available") else "no"
        active = "yes" if (b.get("host"), b.get("port")) in activations else "no"
        reason = b.get("reason") or ""
        print(f"{host:<18} {port:<18} {baud:<7} {up:<4} {active:<7} {reason}")
    return 0


def _list_local_boards(baudrate: Optional[int], timeout: float) -> list[dict[str, Any]]:
    """
    探测本机串口 demoboard 状态，返回列表而不打印：
    每项结构：{"host": "", "port": str, "baudrate": int, "available": bool, "reason": str, "source": "local"}。
    """
    from ..base.serial_core import scan_serial_ports

    ports = scan_serial_ports()
    if not ports:
        return []

    effective_baud = baudrate or _get_default_baudrate()
    targets: list[dict[str, Any]] = []
    for p in ports:
        targets.append(
            {
                "kind": "local",
                "host": "",
                "port": p,
                "baudrate": effective_baud,
                "service_port": None,
                "result": None,
                "done": False,
            }
        )

    return _scan_targets_with_spinner(targets, timeout)


def cmd_list_local(args: argparse.Namespace) -> int:
    """
    列出本机串口 demoboard 状态，仅检查本地串口。
    """
    results = _list_local_boards(args.baudrate, args.timeout)
    if not results:
        print(f"{_YELLOW}[local INFO]{_RESET} 未发现任何本机串口（ttyUSB*）。")
        return 0

    act = _load_local_activation()
    act_port = act.get("port") if act and act.get("active") else None

    header = f"{'PORT':<18} {'BAUD':<7} {'UP':<4} {'ACTIVE':<7} {'REASON'}"
    print(header)
    print("-" * len(header))
    for r in results:
        port = (r.get("port") or "")[:16]
        baud = str(r.get("baudrate") or args.baudrate or _get_default_baudrate())
        up = bool(r.get("available"))
        up_str = "yes" if up else "no"
        active = "yes" if act_port and act_port == r.get("port") else "no"
        reason = r.get("reason") or ""
        # 有效使用绿色，无效使用灰色即可，无需红色。
        color = _GREEN if up else _GREY
        print(f"{color}{port:<18} {baud:<7} {up_str:<4} {active:<7} {reason}{_RESET}")
    return 0


def cmd_demoboard_list(args: argparse.Namespace) -> int:
    """
    sdev demoboard list：
    - 默认包含本地 + remote，并统一在一张表内展示；
    - --local 时仅查询本地。
    """
    # 解析 type 过滤器：目前仅支持 type=demoboard，未指定时默认为 demoboard。
    type_value = "demoboard"
    filters = getattr(args, "filters", None)
    if filters:
        for token in filters:
            if "=" not in token:
                continue
            key, value = token.split("=", 1)
            key = key.strip().lower()
            value = value.strip().lower()
            if key == "type":
                type_value = value or "demoboard"
    if type_value not in ("demoboard", ""):
        print(
            f"{_RED}[ERROR]{_RESET} 当前仅支持 type=demoboard（收到: type={type_value!r}）。",
            file=sys.stderr,
        )
        return 1

    if args.local:
        return cmd_list_local(args)

    # 延迟导入以避免无关子命令时的额外依赖开销。
    from ..base.serial_core import scan_serial_ports

    # 本地与远程发现并行，每阶段一行：行末 spinner，完成后改为 ✔
    local_targets: list[dict[str, Any]] = []
    ports = scan_serial_ports()
    effective_baud = args.baudrate or _get_default_baudrate()
    service_port = getattr(args, "service_port", 7000)
    for p in ports:
        local_targets.append(
            {
                "kind": "local",
                "host": "",
                "port": p,
                "baudrate": effective_baud,
                "service_port": None,
                "result": None,
                "done": False,
            }
        )

    def _local_task() -> list[dict[str, Any]]:
        return _scan_targets(local_targets, args.timeout) if local_targets else []

    def _remote_discovery_task() -> list[dict[str, Any]]:
        hosts = discovery.get_remote_hosts(
            service_port=service_port,
            override=getattr(args, "remote_hosts", None),
        )
        all_boards = []
        for host, port in hosts:
            boards = discovery.fetch_boards_from_host(host, port, timeout=args.timeout)
            all_boards.append(boards)
        merged = discovery.merge_and_dedupe(all_boards)
        return merged

    label_local = f"{_CYAN}[LOCAL]{_RESET} scanning {len(local_targets)} local port(s)..."
    label_remote = f"{_CYAN}[REMOTE]{_RESET} discovering remote hosts..."
    local_results, merged = _run_parallel_with_spinners([
        (label_local, _local_task),
        (label_remote, _remote_discovery_task),
    ])

    # 远程 per-item 检查：在本地检查和远程 discovery 完成之后再进行。
    remote_targets: list[dict[str, Any]] = []
    for b in merged:
        if not isinstance(b, dict):
            continue
        remote_targets.append(
            {
                "kind": "remote",
                "host": b.get("host") or "",
                "port": b.get("port") or "",
                "baudrate": int(b.get("baudrate") or effective_baud),
                "service_port": service_port,
                "result": None,
                "done": False,
            }
        )

    remote_results = _scan_targets_with_spinner(remote_targets, args.timeout)

    # 统一结果（本地 + 远程）
    combined = local_results + remote_results

    # 统一表格输出
    act_local = _load_local_activation()
    act_local_port = act_local.get("port") if act_local and act_local.get("active") else None
    remote_activations = {
        (r.get("host"), r.get("port"))
        for r in discovery.load_activations()
        if isinstance(r, dict) and r.get("active")
    }

    if not combined:
        discovery.save_list_cache([])
        print(f"{_YELLOW}[INFO]{_RESET} 未发现任何 demoboard。")
        return 0

    # 对可用板子逐个获取 device（串行，避免持锁冲突），保留原始大小写
    device_timeout = getattr(args, "timeout", 2.0)
    for r in combined:
        if not r.get("available"):
            r["device"] = ""
            continue
        host_raw = (r.get("host") or "").strip()
        port_raw = (r.get("port") or "").strip()
        baud = int(r.get("baudrate") or 115200)
        use_remote = bool(host_raw and host_raw.lower() not in ("", "localhost"))
        try:
            if use_remote:
                board = Demoboard(port_raw, baud, host=host_raw, service_port=service_port)
            else:
                board = Demoboard(port_raw, baud)
            board.connect()
            try:
                r["device"] = board.check_model_type(timeout=device_timeout) or ""
            finally:
                board.disconnect()
        except Exception:
            r["device"] = ""

    discovery.save_list_cache(combined)

    # 表格前后各空一行，弱隔离上方 spinner 和下方 shell 提示符
    print()

    header = f"{'HASH':<8} {'HOST':<18} {'PORT':<18} {'BAUD':<7} {'UP':<4} {'*':<2} {'DEVICE':<12} {'REASON'}"
    print(header)
    print("-" * len(header))
    for r in combined:
        host_raw = r.get("host") or ""
        host = host_raw[:16]
        port_raw = r.get("port") or ""
        port = port_raw[:16]
        baud = str(r.get("baudrate") or 115200)
        up = bool(r.get("available"))
        up_str = "yes" if up else "no"
        reason = r.get("reason") or ""
        device = (r.get("device") or "")[:12]
        if r.get("source") == "local":
            is_active = act_local_port and act_local_port == r.get("port")
        else:
            key = (r.get("host"), r.get("port"))
            is_active = key in remote_activations
        active_str = "*" if is_active else ""
        # UP=yes 用绿色，UP=no 改为灰色显示即可。
        color = _GREEN if up else _GREY
        host_display = host or "(local)"
        ident_host = host_raw or "(local)"
        ident_port_num = service_port if r.get("source") == "remote" else 0
        host_hash = _compute_host_hash(ident_host, ident_port_num, port_raw or "")
        print(
            f"{color}{host_hash:<8} {host_display:<18} {port:<18} {baud:<7} "
            f"{up_str:<4} {active_str:<2} {device:<12} {reason}{_RESET}"
        )

    # 表格结束后空一行，视觉上与后续命令输出隔离
    print()

    return 0


def cmd_remote_reset(args: argparse.Namespace) -> int:
    discovery.save_list_cache([])
    print(f"已清空缓存: {discovery.get_list_cache_path()}")
    return 0


def _parse_remote_target(target: str) -> Tuple[str, str]:
    """
    将类似 192.168.1.200:/dev/ttyUSB0 的 target 分解为 (host, serial_port)。
    """
    if ":" not in target:
        raise ValueError(f"无效 target（期望 host:port 串口形式）: {target!r}")
    host, port = target.split(":", 1)
    host = host.strip()
    port = port.strip()
    if not host or not port:
        raise ValueError(f"无效 target（host 或串口为空）: {target!r}")
    return host, port


def cmd_remote_activate(args: argparse.Namespace) -> int:
    """
    激活一个 remote demoboard：本地记录 host+串口，并通过远端非阻塞 probe 做一次检查。
    """
    try:
        host, serial_port = _parse_remote_target(args.target)
    except ValueError as e:
        print(f"{_RED}[remote ERROR]{_RESET} {e}", file=sys.stderr)
        return 1

    service_port = args.service_port or 7000
    baudrate = args.baudrate or _get_default_baudrate()
    result = discovery.probe_remote_port(
        host,
        service_port=service_port,
        serial_port=serial_port,
        baudrate=baudrate,
        timeout=args.timeout,
    )
    ok = bool(result.get("available"))
    reason = result.get("reason", "")
    status = "OK" if ok else "FAILED"
    color = _GREEN if ok else _RED
    msg = f"probe {host}:{serial_port} baud={baudrate} -> {status}"
    if reason and not ok:
        msg += f" ({reason})"
    print(f"{color}[remote {status}]{_RESET} {msg}")

    # 当前只允许同时激活一个 remote 开发板：先将其它记录标记为 inactive。
    records = discovery.load_activations()
    for r in records:
        r["active"] = False
    key = (host, serial_port)
    updated = False
    for r in records:
        if (r.get("host"), r.get("port")) == key:
            r.update(
                {
                    "host": host,
                    "port": serial_port,
                    "baudrate": baudrate,
                    "active": ok,
                    "last_check": result.get("updated"),
                    "last_reason": reason,
                }
            )
            updated = True
            break
    if not updated:
        records.append(
            {
                "host": host,
                "port": serial_port,
                "baudrate": baudrate,
                "active": ok,
                "last_check": result.get("updated"),
                "last_reason": reason,
            }
        )
    discovery.save_activations(records)
    # 互斥：激活远程则清空本地激活，保证 sdev 'cmd' 只用当前目标
    if ok:
        _save_local_activation({"active": False})
    return 0 if ok else 1


def cmd_activate_local(args: argparse.Namespace) -> int:
    """
    激活本机默认串口：执行一次非阻塞检查并写入本地 config，供 sdev shell 使用。
    """
    port = (args.port or "").strip()
    if not port:
        print(f"{_RED}[local ERROR]{_RESET} 请指定要激活的串口路径，如 /dev/ttyUSB0。", file=sys.stderr)
        return 1

    baudrate = args.baudrate or _get_default_baudrate()
    timeout = args.timeout or 1.5
    result = check_port_alive_nonblock(port, baudrate=baudrate, timeout=timeout)
    ok = bool(result.get("available"))
    reason = result.get("reason", "")
    status = "OK" if ok else "FAILED"
    color = _GREEN if ok else _RED
    msg = f"probe local {port} baud={baudrate} -> {status}"
    if reason and not ok:
        msg += f" ({reason})"
    print(f"{color}[local {status}]{_RESET} {msg}")

    record: dict[str, Any] = {
        "port": port,
        "baudrate": baudrate,
        "active": ok,
        "last_reason": reason,
    }
    _save_local_activation(record)
    # 互斥：激活本地则清空远程激活，保证 sdev 'cmd' 只用当前目标
    records = discovery.load_activations()
    for r in records:
        r["active"] = False
    discovery.save_activations(records)
    return 0 if ok else 1


def cmd_demoboard_activate(args: argparse.Namespace) -> int:
    """
    sdev demoboard activate TARGET：
    - TARGET 为 /dev/ttyUSBx 时激活本地；
    - TARGET 为 host:/dev/ttyUSBx 时激活远程。
    """
    target = args.target.strip()
    if ":" in target:
        # 远程激活
        r_args = SimpleNamespace(
            target=target,
            service_port=args.service_port,
            baudrate=args.baudrate,
            timeout=args.timeout,
        )
        return cmd_remote_activate(r_args)

    # 本地激活
    l_args = SimpleNamespace(
        port=target,
        baudrate=args.baudrate,
        timeout=args.timeout,
    )
    return cmd_activate_local(l_args)


def cmd_demoboard_deactivate(args: argparse.Namespace) -> int:
    """
    sdev demoboard deactivate：
    - 清空当前激活状态（本地 + remote），不需要指定 target；
    - 仅通过本地记录文件控制，方便 shell 不带 host/device 参数直接使用。
    """
    # 本地激活：写回 active=False
    act = _load_local_activation()
    if act and act.get("active"):
        act["active"] = False
        _save_local_activation(act)
        port = act.get("port") or ""
        baud = act.get("baudrate") or ""
        print(f"{_CYAN}[local INFO]{_RESET} 已取消本地激活: port={port!r}, baudrate={baud}")
    else:
        print(f"{_CYAN}[local INFO]{_RESET} 当前无本地激活记录。")

    # 远程激活：将所有记录的 active 字段清零
    records = discovery.load_activations()
    any_active = False
    for r in records:
        if r.get("active"):
            any_active = True
        r["active"] = False
    if any_active:
        discovery.save_activations(records)
        print(f"{_CYAN}[remote INFO]{_RESET} 已取消所有 remote 激活记录。")
    else:
        print(f"{_CYAN}[remote INFO]{_RESET} 当前无 remote 激活记录。")

    return 0


def cmd_reset(args: argparse.Namespace) -> int:
    """
    sdev reset：
    - 停止本机 sdev server；
    - 删除整个 sdev 配置目录与缓存目录（避免漏清新增的 cache 文件）。
    """
    print(
        f"{_YELLOW}[WARN]{_RESET} 即将执行 sdev reset：停止本机 sdev server，并删除整个 sdev 配置/缓存目录。"
    )
    print(
        f"{_YELLOW}[WARN]{_RESET} 如果当前有其他终端或用户正在使用本机的开发板，可能会受到影响。"
    )

    # 1. 尝试停止 server（忽略未运行的情况）
    try:
        cmd_server_stop(args)
    except Exception as e:
        print(f"{_YELLOW}[WARN]{_RESET} 停止 sdev server 时遇到异常：{e}", file=sys.stderr)

    # 2. 删除整个 sdev 配置目录（list 缓存、本地/远程激活记录等）与缓存目录（pid、日志、端口锁）
    for dir_label, dir_path in [
        ("config", discovery.get_sdev_config_dir()),
        ("cache", _get_sdev_cache_dir()),
    ]:
        try:
            if os.path.isdir(dir_path):
                shutil.rmtree(dir_path)
                print(f"{_GREEN}[reset]{_RESET} 已删除 {dir_label} 目录: {dir_path}")
        except OSError as e:
            print(f"{_YELLOW}[WARN]{_RESET} 删除 {dir_path} 失败: {e}", file=sys.stderr)

    print(f"{_GREEN}[reset DONE]{_RESET} 本机 sdev server 已停止，sdev 配置与缓存目录已清理。")
    return 0


def cmd_activate_hash(args: argparse.Namespace) -> int:
    """
    按 HASH 激活 demoboard（本地或远程）：
    - 先在本机串口列表中按 HASH 匹配（(local)+0+port）；
    - 若无匹配再在远程 host 的 boards 列表中匹配并激活远程。
    """
    from types import SimpleNamespace

    from ..base.serial_core import scan_serial_ports

    target = (getattr(args, "target", "") or "").strip()
    if not target:
        print(f"{_RED}[ERROR]{_RESET} 请提供要激活的 HASH 或 DEVICE 名称。", file=sys.stderr)
        return 1

    service_port = getattr(args, "service_port", 7000) or 7000
    timeout = getattr(args, "timeout", 5.0) or 5.0
    override = getattr(args, "remote_hosts", None)
    baudrate = getattr(args, "baudrate", None) or _get_default_baudrate()

    # 若非 HASH，则按 DEVICE 从 list 缓存模糊匹配（不扫盘，无缓存或未命中时提示先 list）
    if not _looks_like_hash(target):
        from ..remote.board_list import resolve_first_device_match

        result = resolve_first_device_match(
            target,
            service_port=service_port,
            baudrate=baudrate,
        )
        if not result:
            print(
                f"{_RED}[ERROR]{_RESET} 未找到 DEVICE 包含 {target!r} 且状态正常的 demoboard。"
                " 请先执行 'sdev list type=demoboard' 或刷新 list 后重试。",
                file=sys.stderr,
            )
            return 1
        r, board = result
        board.disconnect()
        if r.get("source") == "local":
            l_args = SimpleNamespace(
                port=r.get("port"),
                baudrate=baudrate,
                timeout=timeout,
            )
            return cmd_activate_local(l_args)
        host = (r.get("host") or "").strip()
        serial_port = (r.get("port") or "").strip()
        r_args = SimpleNamespace(
            target=f"{host}:{serial_port}",
            service_port=service_port,
            baudrate=baudrate,
            timeout=timeout,
        )
        return cmd_remote_activate(r_args)

    # 先匹配本地：与 list 一致，(local) + service_port=0 + port
    for port in scan_serial_ports():
        h = _compute_host_hash("(local)", 0, port)
        if h == target:
            l_args = SimpleNamespace(port=port, baudrate=baudrate, timeout=timeout)
            return cmd_activate_local(l_args)

    hosts = discovery.get_remote_hosts(service_port=service_port, override=override)
    if not hosts:
        print(
            f"{_RED}[ERROR]{_RESET} 未找到匹配 HASH={target!r} 的 demoboard。"
            " 请先执行 'sdev list type=demoboard' 查看可用 HASH。",
            file=sys.stderr,
        )
        return 1

    # 根据 HASH 在所有 host 的 boards 列表中查找匹配的「单块板」。
    chosen_host: Optional[str] = None
    chosen_port: Optional[str] = None

    for host, port in hosts:
        boards = discovery.fetch_boards_from_host(host, service_port, timeout=timeout)
        for b in boards:
            if not isinstance(b, dict):
                continue
            serial_port = (b.get("port") or "").strip()
            if not serial_port:
                continue
            h = _compute_host_hash(host, service_port, serial_port)
            if h == target:
                chosen_host = host
                chosen_port = serial_port
                break
        if chosen_host is not None:
            break

    if not chosen_host or not chosen_port:
        print(
            f"{_RED}[ERROR]{_RESET} 未找到匹配 HASH={target!r} 的 demoboard。"
            " 请先执行 'sdev list type=demoboard' 查看可用 HASH。",
            file=sys.stderr,
        )
        return 1

    # 复用现有的 remote 激活逻辑。
    r_args = SimpleNamespace(
        target=f"{chosen_host}:{chosen_port}",
        service_port=service_port,
        baudrate=baudrate,
        timeout=timeout,
    )
    return cmd_remote_activate(r_args)


def cmd_server_start(args: argparse.Namespace) -> int:
    """
    启动本机 sdev server：在后台运行 sdev.remote.server，记录 pid 到缓存目录。
    """
    pid = _read_server_pid()
    if pid is not None and _is_process_alive(pid):
        print(f"sdev server 已在运行中（pid={pid}），请先执行 'sdev server stop'。", file=sys.stderr)
        return 1

    port = getattr(args, "port", 7000)
    python = sys.executable or "python3"
    cmd = [python, "-m", "sdev.remote.server", str(port)]

    # cwd 设为项目根目录（包含顶层 sdev 包），以确保使用当前源码而不是已安装旧版本。
    # server 进程内部会自行将日志写入 server.log（带大小限制），
    # 这里无需再重定向 stdout/stderr 到日志文件。
    project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    proc = subprocess.Popen(
        cmd,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        cwd=project_root,
    )
    with open(_get_server_pid_path(), "w", encoding="utf-8") as f:
        f.write(str(proc.pid))
    print(f"sdev server 已启动：port={port}, pid={proc.pid}")
    return 0


def cmd_server_stop(args: argparse.Namespace) -> int:
    """
    停止本机 sdev server：读取 pid 文件并发送 SIGTERM。
    """
    pid = _read_server_pid()
    if pid is None or not _is_process_alive(pid):
        print("未检测到正在运行的 sdev server。")
        # 清理残留 pid 文件
        try:
            os.remove(_get_server_pid_path())
        except OSError:
            pass
        return 0

    try:
        os.kill(pid, signal.SIGTERM)
    except OSError as e:
        print(f"停止 sdev server 失败：{e}", file=sys.stderr)
        return 1

    try:
        os.remove(_get_server_pid_path())
    except OSError:
        pass
    print(f"sdev server 已停止（pid={pid}）。")
    return 0


def cmd_server_restart(args: argparse.Namespace) -> int:
    """
    重启本机 sdev server：先 stop 再 start。若原本未启动，则等效于 start。
    """
    # 忽略 stop 的返回码，只要 start 成功即可
    cmd_server_stop(args)
    return cmd_server_start(args)


def main() -> int:
    parser = argparse.ArgumentParser(
        prog="sdev",
        description="串口开发板控制器：在 demoboard 上执行命令。",
    )
    subparsers = parser.add_subparsers(dest="subcommand")

    # list：当前支持 model=demoboard
    list_parser = subparsers.add_parser(
        "list",
        help="列出目标列表（当前仅支持 model=demoboard）",
    )
    list_parser.add_argument(
        "filters",
        nargs="*",
        help="过滤器，如 model=demoboard",
    )
    list_parser.add_argument(
        "--baudrate",
        type=int,
        default=None,
        help="本地串口波特率（默认 SDEV_BAUDRATE 或 115200）",
    )
    list_parser.add_argument(
        "--timeout",
        type=float,
        default=2.0,
        help="本地/远程每个 target 检查超时秒数（默认 2.0）",
    )
    list_parser.add_argument(
        "--service-port",
        type=int,
        default=7000,
        help="remote TCP 服务端口（默认 7000）",
    )
    list_parser.add_argument(
        "--remote-hosts",
        type=str,
        default=None,
        help="手动指定 remote host 列表，格式 host[:port][,host2[:port2]...]；跳过 UDP 广播发现",
    )
    list_parser.add_argument(
        "--local",
        action="store_true",
        help="仅查询本地 demoboard，不进行 remote 扫描",
    )
    # 目前仅支持 model=demoboard，因此直接复用 cmd_demoboard_list 实现。
    list_parser.set_defaults(func=cmd_demoboard_list)

    # activate：按 HASH 激活 remote demoboard
    activate_parser = subparsers.add_parser(
        "activate",
        help="按 HASH 激活 demoboard（HASH 由 list 命令输出）",
    )
    activate_parser.add_argument(
        "target",
        help="list 命令中显示的 HASH",
    )
    activate_parser.add_argument(
        "--baudrate",
        type=int,
        default=None,
        help="串口波特率（默认 SDEV_BAUDRATE 或 115200）",
    )
    activate_parser.add_argument(
        "--timeout",
        type=float,
        default=5.0,
        help="远端 probe 的超时秒数（默认 5.0）",
    )
    activate_parser.add_argument(
        "--service-port",
        type=int,
        default=7000,
        help="remote TCP 服务端口（默认 7000）",
    )
    activate_parser.add_argument(
        "--remote-hosts",
        type=str,
        default=None,
        help="手动指定 remote host 列表，格式 host[:port][,host2[:port2]...]；跳过 UDP 广播发现",
    )
    activate_parser.set_defaults(func=cmd_activate_hash)

    # deactivate：清空本地 + remote 激活记录
    deactivate_parser = subparsers.add_parser(
        "deactivate",
        help="取消当前所有激活记录（本地 + remote），无需指定 target",
    )
    deactivate_parser.set_defaults(func=cmd_demoboard_deactivate)

    # server 子命令组
    server_parser = subparsers.add_parser(
        "server",
        help="管理本机 demoboard server（start/stop/restart/status）",
    )
    server_sub = server_parser.add_subparsers(dest="server_command", required=True)

    server_start = server_sub.add_parser("start", help="启动本机 demoboard server（TCP + UDP discovery）")
    server_start.add_argument("--port", type=int, default=7000, help="TCP 监听端口（默认 7000）")
    server_start.set_defaults(func=cmd_server_start)

    server_stop = server_sub.add_parser("stop", help="停止本机 demoboard server")
    server_stop.set_defaults(func=cmd_server_stop)

    server_restart = server_sub.add_parser("restart", help="重启本机 demoboard server")
    server_restart.add_argument("--port", type=int, default=7000, help="TCP 监听端口（默认 7000）")
    server_restart.set_defaults(func=cmd_server_restart)

    server_status = server_sub.add_parser("status", help="查看本机 demoboard server 状态和最近日志")
    server_status.add_argument(
        "--lines",
        type=int,
        default=10,
        help="打印最近的日志行数（默认 10）",
    )
    server_status.set_defaults(func=cmd_server_status)

    # reset：停止 server 并清理本地缓存
    reset_parser = subparsers.add_parser(
        "reset",
        help="停止本机 sdev server 并清空本地缓存（激活记录、发现缓存、日志、端口锁等）",
    )
    reset_parser.set_defaults(func=cmd_reset)

    argv = sys.argv[1:]
    if not argv:
        parser.print_help()
        return 0

    # 若第一个参数是已知子命令，则正常走 argparse 分发。
    if argv[0] in {"list", "activate", "deactivate", "server", "reset"}:
        parsed = parser.parse_args(argv)
        return parsed.func(parsed)

    # 否则进入“简化 shell 模式”：
    # - sdev 'cmd'           -> 在当前激活的 demoboard 上执行 cmd
    # - sdev HASH 'cmd'      -> 先按 HASH 激活，再执行 cmd
    from types import SimpleNamespace

    # HASH + 命令
    if argv and _looks_like_hash(argv[0]):
        if len(argv) < 2:
            print(
                f"{_RED}[ERROR]{_RESET} 用法: sdev HASH 'command'，例如: sdev 1a2b3c4d 'cat /proc/meminfo'",
                file=sys.stderr,
            )
            return 1
        target_hash = argv[0]
        command = " ".join(argv[1:])
        act_args = SimpleNamespace(
            target=target_hash,
            baudrate=None,
            timeout=5.0,
            service_port=7000,
            remote_hosts=None,
        )
        rc = cmd_activate_hash(act_args)
        if rc != 0:
            return rc
    else:
        # 仅有命令：直接在当前激活的 demoboard 上执行。
        command = " ".join(argv)

    shell_args = SimpleNamespace(command=command, flag=" #", timeout=None)
    return cmd_shell(shell_args)


if __name__ == "__main__":
    sys.exit(main())

