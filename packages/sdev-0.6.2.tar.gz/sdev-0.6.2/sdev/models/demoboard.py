from __future__ import annotations

from typing import List, Optional, Iterable, Generator, Union

from ..base.serial_core import CTRL_C, SerialCore
from ..remote.client import RemoteSerialCore


class Demoboard:
    """
    Demoboard 设备：
    - init 时根据 host 是否为空选择 SerialCore 或 RemoteSerialCore；
    - 支持 with 语法自动 connect / disconnect；
    - 提供 execute_command() / check_alive() 高层接口，其余方法均视为内部实现细节。
    """

    def __init__(
        self,
        port: str,
        baudrate: int = 115200,
        *,
        host: Optional[str] = None,
        service_port: int = 7000,
    ):
        use_remote = bool(host and host.strip().lower() not in ("", "localhost"))
        if use_remote:
            core = RemoteSerialCore(host.strip(), port, baudrate, service_port=service_port)
        else:
            core = SerialCore(port, baudrate)
        self._core = core

    # --- 上下文管理：自动 connect / disconnect ---

    def connect(self) -> None:
        self._core.connect()

    def disconnect(self) -> None:
        self._core.disconnect()

    def __enter__(self) -> "Demoboard":
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.disconnect()

    # --- 基础显示接口：供上层选择性使用（默认不影响 CLI 行为） ---

    def _write_raw(self, text: str) -> None:
        """
        向宿主终端输出原始文本。
        默认实现直接写到 stdout；如需重定向，可在上层封装。
        """
        import sys

        sys.stdout.write(text)
        sys.stdout.flush()

    def _ensure_newline(self) -> None:
        """
        确保光标在新的一行开头。
        参考旧实现：具体换行由调用方控制，这里保持占位。
        """
        # 在当前简单实现中不主动输出内容，由上层决定何时写入换行。
        return

    def _display(
        self,
        lines: Iterable[str],
        *,
        flag: Optional[str] = None,
        flag_type: Optional[str] = None,
    ) -> Generator[str, None, None]:
        """
        参考旧版 SerialDevice.display 语义：
        - 逐行回显设备输出到宿主终端；
        - 可选对 flag 进行简单高亮（prompt / end_flag）。

        返回值仍然是原始行（generator），便于上层继续处理。
        """
        # 颜色方案：
        # - 普通输出：整体使用灰色；
        # - 命令回显（flag_type == "prompt"）：匹配片段用黄色；
        # - 结束 flag（flag_type == "end_flag"）：匹配片段用绿色。
        GREY = "\033[90m"
        YELLOW = "\033[33m"
        GREEN = "\033[32m"
        RESET = "\033[0m"

        for raw in lines:
            base = raw.rstrip("\n")
            nl = "\n" if raw.endswith("\n") else ""

            text = base
            if flag and flag in base:
                if flag_type == "prompt":
                    color = YELLOW
                elif flag_type == "end_flag":
                    color = GREEN
                else:
                    color = GREEN
                text = base.replace(flag, f"{color}{flag}{RESET}{GREY}")

            colored = f"{GREY}{text}{RESET}{nl}"
            self._write_raw(colored)
            yield raw

    # --- 对外 API ---

    def send_interrupt(self) -> None:
        """
        将一次「中断」请求转换为对板子的 Ctrl-C（^C）发送。
        供 CLI 在捕获本地 KeyboardInterrupt 时调用，尽量让远端 shell 也一起中断当前前台命令。
        """
        try:
            self._core.send(CTRL_C)
        except Exception:
            # 中断本身是“尽力而为”，失败时不再向外抛异常，避免干扰宿主进程退出路径。
            return

    def execute_command(
        self,
        cmd: Optional[str],
        *,
        flag: str = " #",
        timeout: Optional[float] = None,
        display: bool = True,
        stream: bool = False,
    ) -> Union[List[str], Generator[str, None, None]]:
        """
        在板子上执行一条命令并等待提示符出现：
        - cmd 为非 None 时：发送该命令并等待其回显 + 提示符；
        - cmd 为 None 时：不发送新命令，仅等待当前提示符（适合 Ctrl-C 之后“收尾”等待）。
        - 默认开启 display：边收数据边在宿主终端高亮回显（语义参考旧版 shell）；
        - stream=False：收集所有行并返回 list；
        - stream=True：返回一个逐行生成原始输出的 generator。
        """
        # 先清理残留输出，避免前一次命令的尾巴影响本次结果。
        self._core.clear()

        def _iter() -> Generator[str, None, None]:
            # 第一段：命令回显（使用 end_flag=cmd + replace_with_acc=True）
            if cmd is not None:
                if display:
                    # 模拟旧版 shell 的交互式提示：换行 + 黄色 >
                    self._ensure_newline()
                    self._write_raw("\n\033[33m>\033[0m ")
                self._core.send(cmd)
                part1 = self._core.scan(end_flag=cmd, timeout=timeout, replace_with_acc=True)
                if display:
                    part1 = self._display(part1, flag=cmd, flag_type="prompt")
                for line in part1:
                    yield line

            # 第二段：直到提示符（可选）
            if flag is not None:
                part2 = self._core.scan(end_flag=flag, timeout=timeout, replace_with_acc=False)
                if display:
                    part2 = self._display(part2, flag=flag, flag_type="end_flag")
                for line in part2:
                    yield line

            # 整条命令（两段扫描）结束后，如启用 display，则额外空一行，便于与后续命令视觉隔离。
            if display:
                self._write_raw("\n")

        gen = _iter()
        if stream:
            return gen
        return list(gen)

    def _scan_until_silent(self, timeout: float) -> List[str]:
        """
        内部工具：等待串口在给定时间窗口内“安静下来”。
        """
        lines: List[str] = []
        try:
            for line in self._core.scan(end_flag=None, timeout=timeout, replace_with_acc=False):
                lines.append(line)
        except TimeoutError:
            # 视为串口在给定窗口内没有更多输出
            pass
        return lines

    def check_alive(
        self,
        *,
        uboot_flag: str = "uboot#",
        prompt_flag: str = " #",
        timeout: float = 2.0,
    ) -> Optional[bool]:
        """
        简化版存活性检查：
        1. 先清理当前输出，直到短暂静默；
        2. 发送 Ctrl-C；
        3. 再读取一段时间输出，检查是否出现 prompt_flag / uboot_flag。
        """
        # 1. 等待当前输出安静
        self._scan_until_silent(timeout=timeout)

        # 2. 发送 Ctrl-C
        self._core.send(CTRL_C)

        # 3. 采样输出
        try:
            lines: List[str] = []
            for line in self._core.scan(end_flag=None, timeout=timeout, replace_with_acc=False):
                lines.append(line)
        except TimeoutError:
            self._core.error("check_alive: timeout while waiting for response after CTRL-C")
            return False

        output = "".join(lines)
        if uboot_flag in output:
            # 发现 uboot 提示符，认为当前不在正常 Linux shell 中
            self._core.warning(f"Found uboot flag '{uboot_flag}' during check_alive.")
            return False

        if prompt_flag not in output:
            self._core.error(
                f"Prompt flag '{prompt_flag}' not found in output. "
                "Serial port might not be connected or device is unresponsive."
            )
            return False

        self._core.success("check_alive passed.")
        return True

    def check_model_type(self, timeout: Optional[float] = 2.0) -> str:
        """
        在已连接的板子上读取设备树型号，只返回「前缀」用于列表展示。
        
        获取原理：
        - 板子跑的是 Linux 时，内核会把设备树里的 "model" 属性导出到
          /proc/device-tree/model（只读、可能带尾随 \\0）。
        - 设备树 model 常见格式为 "Vendor,Model" 或带路径的 "Model/..."，
          这里只取第一段作为前缀：若含 '/' 则取斜杠前，否则取整行（去 null、strip）。
        - 通过串口在板子上执行：cat ... ; echo（用 echo 补换行，避免无尾换行时与提示符连成一行），
          解析首行有效内容得到前缀，最多 16 字符。
        """
        cmd = "cat /proc/device-tree/model 2>/dev/null; echo"
        try:
            lines = self.execute_command(cmd, display=False, timeout=timeout)
        except Exception:
            return ""
        if not lines:
            return ""
        for line in lines:
            s = (line or "").replace("\x00", "").strip()
            if not s:
                continue
            if s == cmd:
                continue
            prefix = s.split("/")[0].strip()
            return prefix[:16].lower()
        return ""


__all__ = ["Demoboard"]

