from __future__ import annotations

"""
remote 侧客户端工具：

- host 发现：UDP 广播找到在线的 sdev server；
- demoboard 列表缓存：本地保存各 host 返回的 boards 列表；
- remote 激活记录：本地记录当前激活的远程开发板；
- probe_remote_port：通过 TCP 请求远端 server 对串口做一次非阻塞探测。
"""

import json
import os
import sys
import time
from datetime import datetime, timezone
from typing import Any

DISCOVERY_PORT = 7001


def _debug(msg: str) -> None:
    """
    轻量级调试输出：
    - 仅在环境变量 SDEV_REMOTE_DEBUG 为非空时生效；
    - 直接写入 stderr，避免额外依赖。
    """
    if not os.environ.get("SDEV_REMOTE_DEBUG"):
        return
    try:
        sys.stderr.write(f"[sdev-remote-debug] {msg}\n")
        sys.stderr.flush()
    except OSError:
        # 调试输出失败时静默忽略，避免影响正常流程
        pass


def _discover_hosts_via_zeroconf(timeout: float = 0.8) -> list[tuple[str, int]]:
    """
    通过 zeroconf(mDNS) 发现在线 host：
    - server 侧会发布 `_sdev._tcp.local.` 服务；
    - 这里简单浏览该服务若干秒，收集所有实例的 IP + 端口。
    """
    # 允许通过环境变量彻底关闭 zeroconf，便于在特殊网络或调试时缩短等待。
    if os.environ.get("SDEV_DISABLE_ZEROCONF"):
        _debug("zeroconf discovery disabled by SDEV_DISABLE_ZEROCONF")
        return []

    try:
        from zeroconf import ServiceBrowser, ServiceStateChange, Zeroconf
    except Exception as e:  # pragma: no cover - 依赖缺失时直接跳过
        _debug(f"zeroconf unavailable, skip mDNS discovery: {e}")
        return []

    found: dict[tuple[str, int], None] = {}

    def _on_service_state(zeroconf, service_type, name, state_change) -> None:
        if state_change is not ServiceStateChange.Added:
            return
        try:
            info = zeroconf.get_service_info(service_type, name, timeout=1000)
        except Exception:
            return
        if not info:
            return
        addrs = getattr(info, "parsed_addresses", lambda: [])()
        if not addrs:
            return
        host = (addrs[0] or "").strip()
        port = int(getattr(info, "port", 0) or 0)
        if host and port:
            found[(host, port)] = None

    zc = Zeroconf()
    try:
        ServiceBrowser(zc, "_sdev._tcp.local.", handlers=[_on_service_state])
        time.sleep(max(0.1, timeout))
    finally:
        try:
            zc.close()
        except Exception:
            pass

    hosts = [(h, p) for (h, p) in found.keys()]
    _debug(f"zeroconf discovery hosts={hosts}")
    return hosts


def get_sdev_config_dir() -> str:
    """sdev 配置/缓存目录（list 缓存、本地与远程激活记录等）。reset 时整目录删除可避免漏清。"""
    if sys.platform == "win32":
        base = os.environ.get("APPDATA") or os.path.join(os.path.expanduser("~"), "AppData", "Roaming")
    else:
        base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(os.path.expanduser("~"), ".config")
    return os.path.join(base, "sdev")


def get_list_cache_path() -> str:
    """统一缓存路径：本地+远程 combined（含 device），供 list/any_device/activate 使用。"""
    return os.path.join(get_sdev_config_dir(), "demoboard_list_cache.json")


def load_list_cache() -> list[dict[str, Any]]:
    """读取 list 缓存；无文件或解析失败返回 []。"""
    path = get_list_cache_path()
    if not os.path.isfile(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (json.JSONDecodeError, OSError):
        return []
    return data if isinstance(data, list) else []


def save_list_cache(entries: list[dict[str, Any]]) -> None:
    """写入 list 缓存（combined 结果，含 host/port/source/available/device）。"""
    path = get_list_cache_path()
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(entries, f, ensure_ascii=False, indent=2)


def _discover_hosts_via_udp(timeout: float = 1.5) -> list[tuple[str, int]]:
    """
    通过 UDP 广播主动发现在线 host：
    - 向 255.255.255.255:DISCOVERY_PORT 发送固定探测报文；
    - 在 timeout 内收集各 host 的 JSON 响应（{"host": ip, "port": tcp_port}）。
    """
    import socket

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock.settimeout(timeout)
        sock.bind(("", 0))

        # 1) 解析可选环境变量 SDEV_DISCOVERY_TARGETS：
        #    允许用户显式配置需要扫描的网关/广播地址，格式：
        #    "192.168.1.1,192.168.1.255:7001,10.0.0.1"
        raw_targets = os.environ.get("SDEV_DISCOVERY_TARGETS", "").strip()
        targets: set[tuple[str, int]] = set()
        if raw_targets:
            for item in raw_targets.split(","):
                item = item.strip()
                if not item:
                    continue
                if ":" in item:
                    host, port_s = item.rsplit(":", 1)
                    try:
                        port = int(port_s)
                    except ValueError:
                        port = DISCOVERY_PORT
                else:
                    host, port = item, DISCOVERY_PORT
                host = host.strip()
                if host:
                    targets.add((host, port))

        # 2) 若未显式配置，则采用保守默认：仅向 255.255.255.255 发送一份广播，
        #    避免对网络环境做过多假设。
        if not targets:
            targets.add(("255.255.255.255", DISCOVERY_PORT))

        # 发送探测报文到所有候选地址（通常只有 1~数个，很轻量）
        _debug(f"UDP discovery targets={list(targets)}, timeout={timeout}")
        for host, port in targets:
            try:
                sock.sendto(b"SDEV_DISCOVERY", (host, port))
            except OSError:
                continue

        hosts: set[tuple[str, int]] = set()
        start = time.monotonic()
        while True:
            remaining = timeout - (time.monotonic() - start)
            if remaining <= 0:
                break
            try:
                sock.settimeout(remaining)
                data, addr = sock.recvfrom(4096)
            except socket.timeout:
                break
            except OSError:
                break
            if not data:
                continue
            try:
                obj = json.loads(data.decode("utf-8"))
            except (json.JSONDecodeError, UnicodeDecodeError):
                continue

            # 仅接受带有正确 magic 的 sdev 响应，避免误把其他服务当成 sdev server。
            magic = (obj.get("magic") or "").strip()
            if magic != "sdev-remote-v1":
                _debug(f"UDP discovery ignore packet from {addr}: magic={magic!r}")
                continue

            host = (obj.get("host") or addr[0]).strip()
            try:
                port = int(obj.get("port") or 7000)
            except (TypeError, ValueError):
                port = 7000
            if host:
                hosts.add((host, port))
        out = list(hosts)
        _debug(f"UDP discovery got hosts={out}")
        return out
    finally:
        try:
            sock.close()
        except OSError:
            pass


def get_remote_hosts(service_port: int = 7000, override: str | None = None) -> list[tuple[str, int]]:
    """
    获取 remote host 列表：
    1. 若设置了 SDEV_REMOTE_HOSTS，则优先解析该环境变量（host[:port] 列表）；
    2. 否则，通过 UDP 广播主动发现当前局域网内正在执行 sdev server 的主机。
    """
    raw = override if override is not None else os.environ.get("SDEV_REMOTE_HOSTS", "")
    if raw.strip():
        out: list[tuple[str, int]] = []
        for s in raw.split(","):
            s = s.strip()
            if not s:
                continue
            if ":" in s:
                host, port_s = s.rsplit(":", 1)
                try:
                    out.append((host.strip(), int(port_s)))
                except ValueError:
                    out.append((s, service_port))
            else:
                out.append((s, service_port))
        _debug(f"get_remote_hosts from override/raw='{raw}' -> {out}")
        return out

    # 组合 UDP + zeroconf 两种发现方式，去重后返回：
    # - UDP：对简单局域网兼容性最好；
    # - zeroconf：对 Mac 等环境在多播受限时更友好。
    udp_hosts = _discover_hosts_via_udp()
    zc_hosts = _discover_hosts_via_zeroconf()
    merged: dict[tuple[str, int], None] = {}
    for h, p in udp_hosts + zc_hosts:
        # service_port 仅在 host 省略端口时起作用，这里已是 (host, port) 形式，直接使用。
        merged[(h, int(p or service_port))] = None

    # 过滤掉本机 IP（包括 127.0.0.1），避免把自己当作 remote host。
    import socket

    local_ips: set[str] = {"127.0.0.1"}
    try:
        hostname = socket.gethostname()
        for info in socket.getaddrinfo(hostname, None, family=socket.AF_INET):
            ip = info[4][0]
            if ip:
                local_ips.add(ip)
    except OSError:
        pass

    hosts = [(h, p) for (h, p) in merged.keys() if h not in local_ips]
    _debug(f"get_remote_hosts via UDP+zeroconf -> {hosts} (local_ips={list(local_ips)})")
    return hosts


def fetch_boards_from_host(host: str, port: int, timeout: float = 10.0) -> list[dict[str, Any]]:
    """向 host:port 发送 list 请求，返回带 host 字段的 boards 列表。"""
    import socket

    _debug(f"fetch_boards_from_host: connect to {host}:{port}, timeout={timeout}")

    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        sock.connect((host, port))
        sock.sendall(b'{"cmd":"list"}\n')
        buf = b""
        while b"\n" not in buf:
            chunk = sock.recv(4096)
            if not chunk:
                break
            buf += chunk
        sock.close()
    except Exception as e:
        _debug(f"fetch_boards_from_host: network error host={host} port={port} err={e!r}")
        return []
    try:
        line = buf.split(b"\n", 1)[0].decode("utf-8")
        obj = json.loads(line)
    except (json.JSONDecodeError, UnicodeDecodeError):
        _debug(f"fetch_boards_from_host: invalid response host={host} port={port} raw={buf!r}")
        return []
    boards = obj.get("boards") if isinstance(obj, dict) else []
    if not isinstance(boards, list):
        return []
    for b in boards:
        if isinstance(b, dict):
            b["host"] = host
    _debug(
        f"fetch_boards_from_host: parsed boards from {host}:{port} -> "
        f"{[{'port': b.get('port'), 'baudrate': b.get('baudrate'), 'available': b.get('available')} for b in boards]}"
    )
    return [b for b in boards if isinstance(b, dict)]


def merge_and_dedupe(host_boards: list[list[dict[str, Any]]]) -> list[dict[str, Any]]:
    """按 (host, port) 去重，保留最后一个，并写入 updated 时间戳。"""
    seen: dict[tuple[str, str], dict[str, Any]] = {}
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    for lst in host_boards:
        for b in lst:
            key = (b.get("host", ""), b.get("port", ""))
            if key[1]:
                b = dict(b)
                b["updated"] = now
                seen[key] = b
    return list(seen.values())


def get_activation_path() -> str:
    """本地激活 remote 记录文件路径。"""
    return os.path.join(get_sdev_config_dir(), "remote_activations.json")


def load_activations() -> list[dict[str, Any]]:
    path = get_activation_path()
    if not os.path.isfile(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (json.JSONDecodeError, OSError):
        return []
    return data if isinstance(data, list) else []


def save_activations(records: list[dict[str, Any]]) -> None:
    path = get_activation_path()
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(records, f, ensure_ascii=False, indent=2)


def probe_remote_port(
    host: str,
    service_port: int,
    serial_port: str,
    baudrate: int = 115200,
    timeout: float = 5.0,
) -> dict[str, Any]:
    """
    通过 TCP 调用远端 host 上的 sdev server，对指定串口执行非阻塞 check。
    返回 {port, baudrate, available, reason}。
    """
    import socket

    req = {
        "cmd": "probe",
        "port": serial_port,
        "baudrate": baudrate,
    }
    _debug(
        f"probe_remote_port: connect to {host}:{service_port}, "
        f"serial_port={serial_port}, baudrate={baudrate}, timeout={timeout}"
    )
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        sock.connect((host, service_port))
        payload = json.dumps(req, ensure_ascii=False).encode("utf-8") + b"\n"
        sock.sendall(payload)
        buf = b""
        while b"\n" not in buf:
            chunk = sock.recv(4096)
            if not chunk:
                break
            buf += chunk
        sock.close()
    except Exception as e:
        _debug(
            f"probe_remote_port: network error host={host} service_port={service_port} "
            f"serial_port={serial_port} err={e!r}"
        )
        return {
            "port": serial_port,
            "baudrate": baudrate,
            "available": False,
            "reason": f"network error: {e}",
        }

    try:
        line = buf.split(b"\n", 1)[0].decode("utf-8")
        obj = json.loads(line)
    except (json.JSONDecodeError, UnicodeDecodeError):
        _debug(
            f"probe_remote_port: invalid response host={host} service_port={service_port} "
            f"serial_port={serial_port} raw={buf!r}"
        )
        return {
            "port": serial_port,
            "baudrate": baudrate,
            "available": False,
            "reason": "invalid response",
        }

    if not isinstance(obj, dict):
        _debug(
            f"probe_remote_port: response is not dict host={host} service_port={service_port} "
            f"serial_port={serial_port} obj_type={type(obj)}"
        )
        return {
            "port": serial_port,
            "baudrate": baudrate,
            "available": False,
            "reason": "invalid response",
        }
    # 远端直接返回 result 字典
    result = obj.get("result") if "result" in obj else obj
    if not isinstance(result, dict):
        _debug(
            f"probe_remote_port: result is not dict host={host} service_port={service_port} "
            f"serial_port={serial_port} result_type={type(result)}"
        )
        return {
            "port": serial_port,
            "baudrate": baudrate,
            "available": False,
            "reason": "invalid result",
        }
    # 填补必备字段
    result.setdefault("port", serial_port)
    result.setdefault("baudrate", baudrate)
    result.setdefault("available", False)
    result.setdefault("reason", "")
    _debug(
        f"probe_remote_port: ok host={host} service_port={service_port} serial_port={serial_port} "
        f"available={result.get('available')} reason={result.get('reason')!r}"
    )
    return result


__all__ = [
    "DISCOVERY_PORT",
    "get_sdev_config_dir",
    "get_list_cache_path",
    "load_list_cache",
    "save_list_cache",
    "get_remote_hosts",
    "fetch_boards_from_host",
    "merge_and_dedupe",
    "get_activation_path",
    "load_activations",
    "save_activations",
    "probe_remote_port",
]

