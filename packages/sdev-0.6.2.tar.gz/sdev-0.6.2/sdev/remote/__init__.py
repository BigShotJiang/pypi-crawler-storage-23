from __future__ import annotations

"""
远程串口子包：

- client.RemoteSerialCore：远程串口核心客户端；
- server.RemoteServer：远程串口服务端；
- discovery：远程 host 发现与 demoboard 列表/激活记录管理；
- any_device(device_name)：按 DEVICE 模糊查询并返回 Demoboard 上下文，供脚本使用。
"""

from .client import RemoteSerialCore
from .server import RemoteServer
from . import discovery
from .board_list import any_device

__all__ = ["RemoteSerialCore", "RemoteServer", "discovery", "any_device"]

