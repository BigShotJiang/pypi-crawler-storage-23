"""
静默获取「本地 + 远程」demoboard 列表（供 list 命令）；any_device / resolve_first_device_match
仅从 list 缓存解析，不重复扫描。
"""
from __future__ import annotations

import threading
from contextlib import contextmanager
from typing import TYPE_CHECKING, Any, Generator, Optional, Tuple

if TYPE_CHECKING:
    from ..models import Demoboard

from ..base.serial_core import check_port_alive_nonblock, scan_serial_ports

from . import discovery


def _scan_targets(targets: list[dict[str, Any]], timeout: float) -> list[dict[str, Any]]:
    """并行探测一组 target（本地/远程），返回统一结构列表。供 list 命令用。"""
    def _worker(t: dict[str, Any]) -> None:
        if t["kind"] == "local":
            r = check_port_alive_nonblock(
                t["port"], baudrate=t["baudrate"], timeout=timeout
            )
        else:
            r = discovery.probe_remote_port(
                t["host"],
                service_port=t["service_port"],
                serial_port=t["port"],
                baudrate=t["baudrate"],
                timeout=timeout,
            )
        t["result"] = r
        t["done"] = True

    if not targets:
        return []
    threads = []
    for t in targets:
        th = threading.Thread(target=_worker, args=(t,), daemon=True)
        th.start()
        threads.append(th)
    for th in threads:
        th.join()
    results = []
    for t in targets:
        r = t.get("result") or {}
        kind = t["kind"]
        results.append({
            "host": "" if kind == "local" else t["host"],
            "port": r.get("port") or t["port"],
            "baudrate": int(r.get("baudrate") or t["baudrate"]),
            "available": bool(r.get("available")),
            "reason": r.get("reason") or "",
            "source": kind,
        })
    return results


def resolve_first_device_match(
    device_name: str,
    *,
    service_port: int = 7000,
    baudrate: int = 115200,
) -> Optional[Tuple[dict[str, Any], "Demoboard"]]:
    """
    从 list 缓存中按 DEVICE 模糊匹配第一个可用板子并连接，不发起扫描。
    无缓存或未命中时返回 None，调用方应提示「请先执行 sdev list 或刷新 list 后重试」。
    返回 (r, board) 或 None。board 已 connect，调用方负责 disconnect。
    """
    from ..models import Demoboard

    key = (device_name or "").strip().lower()
    combined = discovery.load_list_cache()
    if not combined:
        return None
    for r in combined:
        if not r.get("available"):
            continue
        dev = (r.get("device") or "").lower()
        if key not in dev:
            continue
        host_raw = (r.get("host") or "").strip()
        port_raw = (r.get("port") or "").strip()
        baud = int(r.get("baudrate") or baudrate)
        use_remote = bool(host_raw and host_raw.lower() not in ("", "localhost"))
        try:
            if use_remote:
                board = Demoboard(
                    port_raw, baud, host=host_raw, service_port=service_port
                )
            else:
                board = Demoboard(port_raw, baud)
            board.connect()
            return (r, board)
        except Exception:
            continue
    return None


def get_combined_demoboard_list_silent(
    timeout: float = 2.0,
    service_port: int = 7000,
    baudrate: int = 115200,
    remote_hosts_override: Optional[list] = None,
    fill_device: bool = True,
) -> list[dict[str, Any]]:
    """
    静默获取「本地 + 远程」combined 列表。fill_device=True 时逐板拉取 device（慢）；
    fill_device=False 时只做存活探测，不拉 device，供 any_device 按需查 device 用。
    """
    local_targets = []
    for p in scan_serial_ports():
        local_targets.append({
            "kind": "local",
            "host": "",
            "port": p,
            "baudrate": baudrate,
            "service_port": None,
            "result": None,
            "done": False,
        })
    local_results = _scan_targets(local_targets, timeout)

    hosts = discovery.get_remote_hosts(
        service_port=service_port, override=remote_hosts_override
    )
    all_boards = []
    for host, port in hosts:
        boards = discovery.fetch_boards_from_host(host, port, timeout=timeout)
        all_boards.append(boards)
    merged = discovery.merge_and_dedupe(all_boards)

    remote_targets = []
    for b in merged:
        if not isinstance(b, dict):
            continue
        remote_targets.append({
            "kind": "remote",
            "host": b.get("host") or "",
            "port": b.get("port") or "",
            "baudrate": int(b.get("baudrate") or baudrate),
            "service_port": service_port,
            "result": None,
            "done": False,
        })
    remote_results = _scan_targets(remote_targets, timeout)
    combined = local_results + remote_results

    if not fill_device:
        for r in combined:
            r["device"] = ""
        discovery.save_list_cache(combined)
        return combined

    from ..models import Demoboard

    device_timeout = min(timeout, 2.0)
    for r in combined:
        if not r.get("available"):
            r["device"] = ""
            continue
        port_raw = (r.get("port") or "").strip()
        host_raw = (r.get("host") or "").strip()
        baud = int(r.get("baudrate") or baudrate)
        use_remote = bool(host_raw and host_raw.lower() not in ("", "localhost"))
        try:
            if use_remote:
                board = Demoboard(
                    port_raw, baud, host=host_raw, service_port=service_port
                )
            else:
                board = Demoboard(port_raw, baud)
            board.connect()
            try:
                r["device"] = board.check_model_type(timeout=device_timeout) or ""
            finally:
                board.disconnect()
        except Exception:
            r["device"] = ""
    discovery.save_list_cache(combined)
    return combined


@contextmanager
def any_device(
    device_name: str,
    *,
    service_port: int = 7000,
    baudrate: int = 115200,
) -> Generator["Demoboard", None, None]:
    """
    从 list 缓存中按 DEVICE 模糊匹配第一个可用板子并返回其 Demoboard 上下文，不发起扫描。
    用法::
        from sdev.remote import any_device
        with any_device("xc01") as board:
            board.execute_command("ls")
    无缓存或未命中时请先执行 sdev list 或刷新 list 后重试。
    """
    result = resolve_first_device_match(
        device_name,
        service_port=service_port,
        baudrate=baudrate,
    )
    if not result:
        raise RuntimeError(
            f"未找到 DEVICE 包含 {device_name!r} 且状态正常的 demoboard。"
            " 请先执行 sdev list 或刷新 list 后重试。"
        )
    _r, board = result
    # 与 CLI shell 统一：首行打印激活目标前缀（蓝色）
    import sys
    from ..util import format_shell_prefix
    host_raw = (_r.get("host") or "").strip()
    port_raw = (_r.get("port") or "").strip()
    baud = int(_r.get("baudrate") or baudrate)
    host = host_raw if (host_raw and host_raw.lower() not in ("", "localhost")) else None
    prefix = format_shell_prefix(host, port_raw, baud)
    sys.stdout.write(f"\033[36m{prefix}\033[0m\n")
    sys.stdout.flush()
    try:
        yield board
    finally:
        board.disconnect()


__all__ = [
    "get_combined_demoboard_list_silent",
    "resolve_first_device_match",
    "any_device",
]
