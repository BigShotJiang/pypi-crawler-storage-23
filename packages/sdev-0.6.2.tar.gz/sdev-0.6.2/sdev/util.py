"""
共享工具：与 CLI/脚本展示相关的纯函数，供 cli_wrapper 与 board_list 等复用。
"""
from __future__ import annotations

from typing import Optional


def format_shell_prefix(host: Optional[str], port: str, baudrate: int) -> str:
    """
    构造激活目标前缀，与 conda 环境前缀风格一致：
    - 本地： (sdev local:/dev/ttyUSB0 baud=115200)
    - 远程： (sdev remote:192.168.1.101:/dev/ttyUSB0 baud=115200)
    """
    if host and str(host).strip():
        scope = "remote"
        target = f"{host}:{port}"
    else:
        scope = "local"
        target = port
    return f"(sdev {scope}:{target} baud={baudrate})"
