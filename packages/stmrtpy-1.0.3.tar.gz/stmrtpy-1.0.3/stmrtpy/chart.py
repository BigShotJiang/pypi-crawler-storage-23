import matplotlib.pyplot as plt
import matplotlib.animation as animation
from .utils import validate_dataframe
from .indicators import moving_average, rsi


# =============================
# INTERNAL THEME HANDLER
# =============================

def _apply_theme(theme):
    if theme == "dark":
        plt.style.use("dark_background")
    elif theme == "light":
        plt.style.use("default")
    elif theme == "seaborn":
        plt.style.use("seaborn-v0_8")
    else:
        plt.style.use("default")


# =============================
# Candlestick Chart
# =============================

def plot_candlestick(
    df,
    ma_windows=None,
    show_rsi=False,
    theme="light",
    interactive=False,
    save_path=None
):
    df = validate_dataframe(df)

    _apply_theme(theme)

    if interactive:
        plt.ion()

    if show_rsi:
        fig, (ax, ax_rsi) = plt.subplots(
            2, 1,
            figsize=(12, 8),
            gridspec_kw={'height_ratios': [3, 1]}
        )
    else:
        fig, ax = plt.subplots(figsize=(12, 6))

    # Candles
    for i in range(len(df)):
        color = "green" if df["Close"].iloc[i] >= df["Open"].iloc[i] else "red"

        ax.plot([i, i],
                [df["Low"].iloc[i], df["High"].iloc[i]],
                color=color)

        ax.plot([i, i],
                [df["Open"].iloc[i], df["Close"].iloc[i]],
                linewidth=5,
                color=color)

    # Moving Averages
    if ma_windows:
        for window in ma_windows:
            ma = moving_average(df, window)
            ax.plot(ma, label=f"MA {window}")

    ax.set_title("Candlestick Chart")
    ax.legend()

    # RSI Subplot
    if show_rsi:
        rsi_values = rsi(df)
        ax_rsi.plot(rsi_values)
        ax_rsi.set_title("RSI")

    plt.tight_layout()

    if save_path:
        plt.savefig(save_path)
    else:
        plt.show()

    plt.close()


# =============================
# Line Chart
# =============================

def plot_line(
    df,
    x,
    y,
    title=None,
    theme="light",
    interactive=False,
    save_path=None
):
    _apply_theme(theme)

    if interactive:
        plt.ion()

    fig, ax = plt.subplots(figsize=(10, 5))
    ax.plot(df[x], df[y])

    ax.set_title(title if title else f"{y} Line Chart")
    ax.set_xlabel(x)
    ax.set_ylabel(y)

    plt.tight_layout()

    if save_path:
        plt.savefig(save_path)
    else:
        plt.show()

    plt.close()


# =============================
# Bar Chart
# =============================

def plot_bar(
    df,
    x,
    y,
    title=None,
    theme="light",
    interactive=False,
    save_path=None
):
    _apply_theme(theme)

    if interactive:
        plt.ion()

    fig, ax = plt.subplots(figsize=(10, 5))
    ax.bar(df[x], df[y])

    ax.set_title(title if title else f"{y} Bar Chart")
    ax.set_xlabel(x)
    ax.set_ylabel(y)

    plt.tight_layout()

    if save_path:
        plt.savefig(save_path)
    else:
        plt.show()

    plt.close()


# =============================
# Live Chart Support
# =============================

def live_plot(update_func, interval=1000, theme="light"):
    _apply_theme(theme)

    fig, ax = plt.subplots()

    def wrapper(frame):
        ax.clear()
        update_func(ax)

    animation.FuncAnimation(fig, wrapper, interval=interval)
    plt.show()