import pandas as pd

def validate_dataframe(df):
    required_columns = ["Open", "High", "Low", "Close", "Volume"]

    for col in required_columns:
        if col not in df.columns:
            raise ValueError(f"Missing required column: {col}")

    return df