# stmrtpy

Professional stock market plotting library.

## Features

- Candlestick chart
- Volume subplot
- Moving averages
- RSI
- Dark mode

## Install

pip install stmrtpy

## Example

```python
import pandas as pd
from stmrtpy import plot_chart

df = pd.read_csv("data.csv")

plot_chart(
    df,
    ma_windows=(20, 50),
    show_rsi=True,
    dark=True,
    save_path="chart.png"
)