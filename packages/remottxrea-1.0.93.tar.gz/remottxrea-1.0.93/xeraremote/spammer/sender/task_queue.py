# queue/task_queue.py

from dataclasses import dataclass
from typing import List

from sender.message_sender import MessageSender


@dataclass
class SendTask:
    session: str
    target: str
    text: str


class TaskQueue:

    def __init__(self):
        self.tasks: List[SendTask] = []
        self.sender = MessageSender()

    def add(self, task: SendTask):
        self.tasks.append(task)

    def add_raw(self, session, target, text):
        self.tasks.append(
            SendTask(session, target, text)
        )

    async def run(self):

        while self.tasks:

            task = self.tasks.pop(0)

            try:
                await self.sender.send(
                    task.session,
                    task.target,
                    task.text
                )

            except Exception as e:
                print("Task failed:", e)
