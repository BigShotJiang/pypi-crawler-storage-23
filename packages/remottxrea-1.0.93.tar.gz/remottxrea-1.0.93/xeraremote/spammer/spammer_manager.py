# spammer_manager.py

import asyncio
from dataclasses import dataclass
from typing import List

from sender.message_sender import MessageSender
from queue.task_queue import TaskQueue


@dataclass
class SpamTask:
    session: str
    targets: List[str]
    text: str


class SpammerManager:

    def __init__(self):
        self.queue = TaskQueue()
        self.sender = MessageSender()

    def add_task(self, task: SpamTask):

        for target in task.targets:
            self.queue.add_raw(
                session=task.session,
                target=target,
                text=task.text
            )

    async def run(self):
        await self.queue.run()
