# remottxrea/circadian/weekly_rotator.py

import datetime


class WeeklyRotator:

    def __init__(self, shifts):
        self.shifts = shifts

    # ---------- GET WEEK INDEX ----------
    def get_week_index(self):

        now = datetime.datetime.utcnow()

        return now.isocalendar()[1]

    # ---------- ROTATE ----------
    def rotate(self):

        week = self.get_week_index()

        rotation = week % len(self.shifts)

        return (
            self.shifts[rotation:] +
            self.shifts[:rotation]
        )
