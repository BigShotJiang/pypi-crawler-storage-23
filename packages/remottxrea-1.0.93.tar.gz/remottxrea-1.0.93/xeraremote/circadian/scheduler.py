# remottxrea/circadian/scheduler.py

import asyncio

from ..circadian.shift_allocator import (
    ShiftAllocator
)
from ..circadian.weekly_rotator import (
    WeeklyRotator
)
from ..circadian.activity_controller import (
    ActivityController
)


class CircadianScheduler:

    def __init__(
        self,
        clients,
        duration_hours=12
    ):

        self.clients = clients
        self.duration = duration_hours

        if 24 % duration_hours != 0:
            raise ValueError(
                "Invalid duration."
            )

    # ---------- BUILD SHIFTS ----------
    def build_shifts(self):

        allocator = ShiftAllocator(
            self.clients,
            self.duration
        )

        shifts = allocator.allocate()

        rotator = WeeklyRotator(shifts)

        return rotator.rotate()

    # ---------- RUN ----------
    async def run(self):

        shifts = self.build_shifts()

        controller = ActivityController(
            self.duration
        )

        while True:

            for shift in shifts:

                await controller.run_shift(
                    shift
                )
