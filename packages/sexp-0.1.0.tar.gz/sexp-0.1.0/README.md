# sexp

A minimal-allocation S-expression library for Python, backed by a C extension.

**Work in progress.** Core design and implementation underway.