// This file is intentionally left empty.
// Catch2 with Catch2::Catch2WithMain provides its own main().
