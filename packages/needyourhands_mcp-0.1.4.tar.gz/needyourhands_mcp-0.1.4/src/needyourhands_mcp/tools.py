"""
Pydantic models for MCP tool inputs and outputs.

Every tool exposed by the NeedYourHands MCP server has a strongly-typed
input model and a corresponding output model defined here.
"""

from __future__ import annotations

from typing import Any, Optional

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Shared / reusable
# ---------------------------------------------------------------------------


class WorkerSummary(BaseModel):
    """Compact representation of a worker returned in search results."""

    id: str
    name: str
    rating: float = Field(ge=0.0, le=5.0)
    skills: list[str] = Field(default_factory=list)
    city: str = ""
    hourly_rate_min: Optional[float] = None
    distance_km: Optional[float] = None
    availability: str = "unknown"


class TimelineEvent(BaseModel):
    """A single event in a mission timeline."""

    timestamp: str
    event: str
    details: str = ""


class ProofItem(BaseModel):
    """Proof submitted by a worker."""

    type: str
    url: str
    timestamp: str
    verified: bool = False


class AvailabilitySlot(BaseModel):
    """A single availability slot."""

    start: str
    end: str
    available: bool = True


# ---------------------------------------------------------------------------
# search_humans
# ---------------------------------------------------------------------------


class SearchHumansInput(BaseModel):
    """Input for the search_humans tool."""

    skills: list[str] = Field(..., min_length=1, description="Required skills to search for.")
    location: str = Field(..., min_length=1, description="City or address to search around.")
    radius_km: int = Field(default=25, ge=1, le=500, description="Search radius in kilometres.")
    budget_max_eur: float = Field(
        default=100.0, gt=0, description="Maximum budget in EUR to filter by hourly rate."
    )
    urgency: str = Field(
        default="normal",
        pattern=r"^(normal|urgent)$",
        description="Urgency level: normal or urgent.",
    )


class SearchHumansOutput(BaseModel):
    """Output from the search_humans tool."""

    workers: list[WorkerSummary] = Field(default_factory=list)
    total: int = 0


# ---------------------------------------------------------------------------
# book_human
# ---------------------------------------------------------------------------


class BookHumanInput(BaseModel):
    """Input for the book_human tool."""

    human_id: str = Field(..., min_length=1, description="ID of the worker to book.")
    title: str = Field(..., min_length=1, max_length=256, description="Title of the task.")
    description: str = Field(
        ..., min_length=1, max_length=5000, description="Detailed description of the task."
    )
    location: dict[str, Any] = Field(
        ..., description="Location object: {address: str, city: str, latitude?: float, longitude?: float}"
    )
    deadline: str = Field(..., description="ISO 8601 deadline for the task.")
    budget_eur: float = Field(..., gt=0, description="Budget in EUR for the task.")


class BookHumanOutput(BaseModel):
    """Output from the book_human tool."""

    mission_id: str
    status: str
    worker_id: Optional[str] = None
    worker_name: Optional[str] = None
    budget_eur: Optional[float] = None
    platform_fee_eur: Optional[float] = None
    worker_payout_eur: Optional[float] = None
    deadline: Optional[str] = None
    created_at: Optional[str] = None


# ---------------------------------------------------------------------------
# get_availability
# ---------------------------------------------------------------------------


class GetAvailabilityInput(BaseModel):
    """Input for the get_availability tool."""

    human_id: str = Field(..., min_length=1, description="ID of the worker.")
    date: str = Field(..., description="ISO date (YYYY-MM-DD) to check availability for.")
    time_range: Optional[str] = Field(
        default=None,
        description="Optional time range like '09:00-18:00' to narrow the query.",
    )


class GetAvailabilityOutput(BaseModel):
    """Output from the get_availability tool."""

    available: bool = False
    slots: list[AvailabilitySlot] = Field(default_factory=list)
    next_available: Optional[str] = None


# ---------------------------------------------------------------------------
# submit_task
# ---------------------------------------------------------------------------


class SubmitTaskInput(BaseModel):
    """Input for the submit_task tool."""

    title: str = Field(..., min_length=1, max_length=256, description="Title of the task.")
    description: str = Field(
        ..., min_length=1, max_length=5000, description="Detailed description."
    )
    required_skills: list[str] = Field(
        ..., min_length=1, description="Skills required to perform the task."
    )
    location: dict[str, Any] = Field(
        ..., description="Location object: {address: str, city: str, latitude?: float, longitude?: float}"
    )
    budget_eur: float = Field(..., gt=0, description="Budget in EUR.")
    deadline: str = Field(..., description="ISO 8601 deadline for the task.")


class SubmitTaskOutput(BaseModel):
    """Output from the submit_task tool."""

    mission_id: str
    status: str = "open"
    matching_candidates: int = 0
    top_candidates: list[dict[str, Any]] = Field(default_factory=list)
    budget_eur: Optional[float] = None
    platform_fee_eur: Optional[float] = None
    worker_payout_eur: Optional[float] = None
    deadline: Optional[str] = None
    created_at: Optional[str] = None


# ---------------------------------------------------------------------------
# get_task_status
# ---------------------------------------------------------------------------


class GetTaskStatusInput(BaseModel):
    """Input for the get_task_status tool."""

    mission_id: str = Field(..., min_length=1, description="ID of the mission to check.")


class GetTaskStatusOutput(BaseModel):
    """Output from the get_task_status tool."""

    status: str
    proofs: list[ProofItem] = Field(default_factory=list)
    worker_id: Optional[str] = None
    worker_name: Optional[str] = None
    eta: Optional[str] = None
    timeline: list[TimelineEvent] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# rate_human
# ---------------------------------------------------------------------------


class RateHumanInput(BaseModel):
    """Input for the rate_human tool."""

    mission_id: str = Field(..., min_length=1, description="ID of the completed mission.")
    rating: int = Field(..., ge=1, le=5, description="Rating from 1 (poor) to 5 (excellent).")
    comment: str = Field(
        default="", max_length=2000, description="Optional feedback comment."
    )


class RateHumanOutput(BaseModel):
    """Output from the rate_human tool."""

    success: bool = False
    new_average_rating: Optional[float] = None


# ---------------------------------------------------------------------------
# verify_proof
# ---------------------------------------------------------------------------


class CancelMissionInput(BaseModel):
    """Input for the cancel_mission tool."""

    mission_id: str = Field(..., min_length=1, description="ID of the mission to cancel.")
    reason: str = Field(..., min_length=1, max_length=2000, description="Cancellation reason.")


class CancelMissionOutput(BaseModel):
    """Output from the cancel_mission tool."""

    mission_id: str
    new_status: str = "cancelled"
    reason: str = ""
    payment_action: str = "none"
    payment_status: str = ""
    cancelled_at: str = ""


# ---------------------------------------------------------------------------
# verify_proof
# ---------------------------------------------------------------------------


class VerifyProofInput(BaseModel):
    """Input for the verify_proof tool."""

    mission_id: str = Field(..., min_length=1, description="ID of the mission.")
    proof_index: int = Field(..., ge=0, description="Zero-based index of the proof to verify.")
    approved: bool = Field(..., description="True to approve, False to reject.")
    rejection_reason: str = Field(
        default="", max_length=2000, description="Required when rejecting a proof."
    )


class VerifyProofOutput(BaseModel):
    """Output from the verify_proof tool."""

    mission_id: str
    proof_index: int
    approved: bool
    new_mission_status: str = ""
    payment_captured: bool = False
    all_proofs_verified: bool = False
    total_proofs: int = 0
    verified_count: int = 0
