# Convexity CLI

Command-line interface for the Convexity platform.

## Installation

```bash
pip install convexity-cli
```

## Usage

```bash
convexity-cli --help
```
