"""CLI-specific exceptions for Convexity.

These exceptions are raised by the CLI client and commands
to provide user-friendly error messages.
"""

from typing import Any


class CLIError(Exception):
    """Base exception for CLI errors."""

    exit_code: int = 1

    def __init__(self, message: str, **kwargs: Any):
        super().__init__(message)
        self.message = message
        self.details = kwargs


class ConfigurationError(CLIError):
    """Configuration-related errors."""

    exit_code = 2


class AuthenticationError(CLIError):
    """Authentication failed - invalid or expired API key."""

    exit_code = 3

    def __init__(self, message: str = "Invalid or expired API key", **kwargs: Any):
        super().__init__(message, **kwargs)


class PermissionError(CLIError):
    """Permission denied - insufficient permissions for the operation."""

    exit_code = 4

    def __init__(self, message: str = "Insufficient permissions", **kwargs: Any):
        super().__init__(message, **kwargs)


class NotFoundError(CLIError):
    """Resource not found."""

    exit_code = 5

    def __init__(
        self,
        resource_type: str = "Resource",
        resource_id: str | None = None,
        **kwargs: Any,
    ):
        if resource_id:
            message = f"{resource_type} not found: {resource_id}"
        else:
            message = f"{resource_type} not found"
        super().__init__(message, **kwargs)
        self.resource_type = resource_type
        self.resource_id = resource_id


class ValidationError(CLIError):
    """Invalid request parameters."""

    exit_code = 6

    def __init__(
        self,
        message: str = "Invalid request parameters",
        errors: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ):
        super().__init__(message, **kwargs)
        self.errors = errors or []


class RateLimitError(CLIError):
    """Rate limit exceeded."""

    exit_code = 7

    def __init__(
        self,
        message: str = "Rate limit exceeded. Please try again later.",
        retry_after: int | None = None,
        **kwargs: Any,
    ):
        super().__init__(message, **kwargs)
        self.retry_after = retry_after


class ServerError(CLIError):
    """Server-side error."""

    exit_code = 8

    def __init__(
        self,
        message: str = "Server error. Please try again later.",
        status_code: int | None = None,
        **kwargs: Any,
    ):
        super().__init__(message, **kwargs)
        self.status_code = status_code


class NetworkError(CLIError):
    """Network connectivity error."""

    exit_code = 9

    def __init__(
        self,
        message: str = "Network error. Please check your connection.",
        **kwargs: Any,
    ):
        super().__init__(message, **kwargs)


class ConflictError(CLIError):
    """Resource conflict (e.g., already exists)."""

    exit_code = 10

    def __init__(
        self,
        message: str = "Resource conflict",
        **kwargs: Any,
    ):
        super().__init__(message, **kwargs)


class ProjectError(CLIError):
    """Project-related errors (pull/push)."""

    exit_code = 11


class APIError(CLIError):
    """Generic API error."""

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        response_body: Any | None = None,
        **kwargs: Any,
    ):
        super().__init__(message, **kwargs)
        self.status_code = status_code
        self.response_body = response_body
