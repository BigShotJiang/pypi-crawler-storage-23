"""Convexity CLI - Main entry point.

This module provides the main Typer application for the Convexity CLI,
including global options and command registration.
"""

import os
import sys
from typing import Annotated

# Check for --plain flag early before Typer/Rich is imported
# This ensures Rich is configured correctly at import time
if "--plain" in sys.argv or os.environ.get("NO_COLOR"):
    os.environ["NO_COLOR"] = "1"

import typer

from convexity_cli import __version__
from convexity_cli.commands import org, project
from convexity_cli.commands.utils import set_global_overrides
from convexity_cli.config import get_config_manager
from convexity_cli.exceptions import CLIError
from convexity_cli.output import output_error, output_json, output_success

# Create the main Typer application
app = typer.Typer(
    name="convexity",
    help="Convexity CLI - Manage your Convexity projects from the command line.",
    no_args_is_help=True,
    pretty_exceptions_enable=False,  # We handle exceptions ourselves
    rich_markup_mode=None,  # Disabled for Windows terminal compatibility
)

# Register command groups
app.add_typer(org.app, name="org")
app.add_typer(project.app, name="project")


@app.callback()
def global_options(
    api_key: Annotated[
        str | None,
        typer.Option("--api-key", envvar="CONVEXITY_API_KEY", help="API key for authentication"),
    ] = None,
    base_url: Annotated[
        str | None,
        typer.Option("--base-url", envvar="CONVEXITY_BASE_URL", help="Base URL for API"),
    ] = None,
    plain: Annotated[
        bool,
        typer.Option("--plain", envvar="NO_COLOR", help="Disable rich formatting"),
    ] = True,
) -> None:
    """Global options applied to all commands."""
    set_global_overrides(api_key=api_key, base_url=base_url)
    if plain:
        os.environ["NO_COLOR"] = "1"


# =============================================================================
# Global Commands
# =============================================================================


@app.command("version")
def version() -> None:
    """Show the CLI version."""
    output_json({"version": __version__})


@app.command("auth")
def auth(
    api_key: Annotated[
        str | None,
        typer.Option("--key", "-k", help="API key to save"),
    ] = None,
    clear: Annotated[
        bool,
        typer.Option("--clear", "-c", help="Clear saved API key"),
    ] = False,
    show: Annotated[
        bool,
        typer.Option("--show", "-s", help="Show current API key status"),
    ] = False,
) -> None:
    """Manage API key authentication.

    Examples:
        convexity auth --key cvx_xxx_yyy    # Save API key
        convexity auth --show               # Show current status
        convexity auth --clear              # Clear saved key
    """
    config_manager = get_config_manager()

    if clear:
        config_manager.clear_api_key()
        output_success("API key cleared")
        return

    if api_key:
        config_manager.set_api_key(api_key)
        # Mask the key for display
        masked = f"{api_key[:7]}...{api_key[-4:]}" if len(api_key) > 11 else "***"
        output_success(f"API key saved: {masked}")
        return

    if show:
        config = config_manager.load()
        current_key = config.get_api_key()
        if current_key:
            masked = f"{current_key[:7]}...{current_key[-4:]}" if len(current_key) > 11 else "***"
            output_json(
                {
                    "authenticated": True,
                    "api_key": masked,
                    "profile": config.active_profile,
                    "base_url": config.get_base_url(),
                }
            )
        else:
            output_json(
                {
                    "authenticated": False,
                    "profile": config.active_profile,
                    "base_url": config.get_base_url(),
                }
            )
        return

    # No options - show help
    typer.echo("Use --key to set API key, --show to check status, or --clear to remove")
    raise typer.Exit(0)


@app.command("config")
def config_cmd(
    key: Annotated[
        str | None,
        typer.Argument(help="Configuration key to get/set (e.g., 'server.base_url')"),
    ] = None,
    value: Annotated[
        str | None,
        typer.Option("--set", "-s", help="Value to set"),
    ] = None,
) -> None:
    """View or modify CLI configuration.

    Examples:
        convexity config                     # Show all config
        convexity config server.base_url     # Get specific value
        convexity config server.base_url --set https://api.example.com
    """
    config_manager = get_config_manager()
    config = config_manager.load()

    if key is None:
        # Show all config
        output_json(
            {
                "active_profile": config.active_profile,
                "profile": config.current_profile.model_dump(exclude_none=True),
            }
        )
        return

    if value is not None:
        # Set a value
        # For now, only support a few common settings
        if key == "server.base_url":
            config.current_profile.server.base_url = value
            config_manager.save(config)
            output_success(f"Set {key} = {value}")
        elif key == "server.timeout":
            config.current_profile.server.timeout = float(value)
            config_manager.save(config)
            output_success(f"Set {key} = {value}")
        elif key == "default_org":
            config_manager.set_default_org(value)
            output_success(f"Set default organization = {value}")
        elif key == "default_project":
            config_manager.set_default_project(value)
            output_success(f"Set default project = {value}")
        else:
            output_error(f"Unknown configuration key: {key}")
            raise typer.Exit(1)
        return

    # Get a specific value
    result = config_manager.get_value(key)
    if result is not None:
        output_json({key: result})
    else:
        output_error(f"Configuration key not found: {key}")
        raise typer.Exit(1)


# =============================================================================
# Error Handling
# =============================================================================


def main() -> None:
    """Main entry point with error handling."""
    try:
        app()
    except CLIError as e:
        output_error({"message": e.message, **e.details}, exit_code=e.exit_code)
        sys.exit(e.exit_code)
    except KeyboardInterrupt:
        output_error("Operation cancelled", exit_code=130)
        sys.exit(130)
    except Exception as e:
        output_error({"message": str(e), "type": type(e).__name__}, exit_code=1)
        sys.exit(1)


if __name__ == "__main__":
    main()
