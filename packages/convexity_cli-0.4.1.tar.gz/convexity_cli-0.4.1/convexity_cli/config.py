"""Configuration management for Convexity CLI.

Handles loading and saving CLI configuration including API keys
and server settings. Configuration is stored in ~/.convexity/config.yaml
"""

import os
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings, SettingsConfigDict
import yaml


class ServerConfig(BaseModel):
    """Server connection configuration."""

    base_url: str = "https://api.convexity.io"
    timeout: float = 30.0


class ProfileConfig(BaseModel):
    """A named configuration profile."""

    name: str
    api_key: str | None = None
    server: ServerConfig = Field(default_factory=ServerConfig)
    default_org: str | None = None
    default_project: str | None = None


class CLIConfig(BaseSettings):
    """Main CLI configuration."""

    model_config = SettingsConfigDict(
        env_prefix="CONVEXITY_",
        env_file=".env",
        extra="ignore",
    )

    # Active profile name
    active_profile: str = "default"

    # Profiles dictionary
    profiles: dict[str, ProfileConfig] = Field(default_factory=dict)

    # Override via environment variable
    api_key: str | None = Field(default=None, alias="CONVEXITY_API_KEY")
    base_url: str | None = Field(default=None, alias="CONVEXITY_BASE_URL")

    @property
    def current_profile(self) -> ProfileConfig:
        """Get the currently active profile."""
        if self.active_profile not in self.profiles:
            # Create default profile if it doesn't exist
            self.profiles[self.active_profile] = ProfileConfig(name=self.active_profile)
        return self.profiles[self.active_profile]

    def get_api_key(self) -> str | None:
        """Get API key with environment override."""
        return self.api_key or self.current_profile.api_key

    def get_base_url(self) -> str:
        """Get base URL with environment override."""
        return self.base_url or self.current_profile.server.base_url

    def get_timeout(self) -> float:
        """Get request timeout."""
        return self.current_profile.server.timeout


class ConfigManager:
    """Manages CLI configuration file operations."""

    DEFAULT_CONFIG_DIR = Path.home() / ".convexity"
    CONFIG_FILE = "config.yaml"

    def __init__(self, config_dir: Path | None = None):
        self.config_dir = config_dir or self.DEFAULT_CONFIG_DIR
        self.config_path = self.config_dir / self.CONFIG_FILE
        self._config: CLIConfig | None = None

    def ensure_config_dir(self) -> None:
        """Create config directory if it doesn't exist."""
        self.config_dir.mkdir(parents=True, exist_ok=True)
        # Set restrictive permissions on Unix-like systems
        if os.name != "nt":
            self.config_dir.chmod(0o700)

    def load(self) -> CLIConfig:
        """Load configuration from file."""
        if self._config is not None:
            return self._config

        if self.config_path.exists():
            with open(self.config_path) as f:
                data = yaml.safe_load(f) or {}
            self._config = CLIConfig(**data)
        else:
            self._config = CLIConfig()

        return self._config

    def save(self, config: CLIConfig | None = None) -> None:
        """Save configuration to file."""
        if config is not None:
            self._config = config

        if self._config is None:
            return

        self.ensure_config_dir()

        # Convert to dict, excluding None values and env overrides
        data = {
            "active_profile": self._config.active_profile,
            "profiles": {name: profile.model_dump(exclude_none=True) for name, profile in self._config.profiles.items()},
        }

        with open(self.config_path, "w") as f:
            yaml.dump(data, f, default_flow_style=False, sort_keys=False)

        # Set restrictive permissions on Unix-like systems
        if os.name != "nt":
            self.config_path.chmod(0o600)

    def set_api_key(self, api_key: str, profile: str | None = None) -> None:
        """Set API key for a profile."""
        config = self.load()
        profile_name = profile or config.active_profile

        if profile_name not in config.profiles:
            config.profiles[profile_name] = ProfileConfig(name=profile_name)

        config.profiles[profile_name].api_key = api_key
        self.save(config)

    def set_default_org(self, org_id: str, profile: str | None = None) -> None:
        """Set default organization for a profile."""
        config = self.load()
        profile_name = profile or config.active_profile

        if profile_name not in config.profiles:
            config.profiles[profile_name] = ProfileConfig(name=profile_name)

        config.profiles[profile_name].default_org = org_id
        self.save(config)

    def set_default_project(self, project_id: str, profile: str | None = None) -> None:
        """Set default project for a profile."""
        config = self.load()
        profile_name = profile or config.active_profile

        if profile_name not in config.profiles:
            config.profiles[profile_name] = ProfileConfig(name=profile_name)

        config.profiles[profile_name].default_project = project_id
        self.save(config)

    def get_value(self, key: str) -> Any:
        """Get a configuration value by key path (e.g., 'server.base_url')."""
        config = self.load()
        profile = config.current_profile

        parts = key.split(".")
        obj: Any = profile

        for part in parts:
            if hasattr(obj, part):
                obj = getattr(obj, part)
            elif isinstance(obj, dict) and part in obj:
                obj = obj[part]
            else:
                return None

        return obj

    def clear_api_key(self, profile: str | None = None) -> None:
        """Clear API key for a profile."""
        config = self.load()
        profile_name = profile or config.active_profile

        if profile_name in config.profiles:
            config.profiles[profile_name].api_key = None
            self.save(config)


# Global config manager instance
_config_manager: ConfigManager | None = None


def get_config_manager() -> ConfigManager:
    """Get the global config manager instance."""
    global _config_manager
    if _config_manager is None:
        _config_manager = ConfigManager()
    return _config_manager


def get_config() -> CLIConfig:
    """Get the current CLI configuration."""
    return get_config_manager().load()
