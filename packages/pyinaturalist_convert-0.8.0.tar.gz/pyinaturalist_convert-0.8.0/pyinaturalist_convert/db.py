"""Data models and utilities for storing observations and related data in a relational database,
including SQLite, PostgreSQL, and
`any other database supported by SQLAlchemy <https://docs.sqlalchemy.org/en/14/dialects/>`_.

These models contain a relevant subset of columns common to most iNat data sources,
suitable for combining data from API results, CSV export, DwC-A, and/or inaturalist-open-data.

Some helper functions are included for the most common cases of saving and loading taxon and
observation data. Requirements for a relational database are highly variable, so this won't suit all
use cases, but at least provides a starting point.

**Extra dependencies**: ``sqlalchemy``

**Example**::

    >>> from pyinaturalist import iNatClient
    >>> from pyinaturalist_convert import create_tables, read_observations, save_observations

    >>> # Fetch all of your own observations
    >>> client = iNatClient()
    >>> observations = client.observations.search(user_id='my_username').all()

    >>> # Save to a SQLite database
    >>> create_tables('observations.db')
    >>> save_observations(observations, 'observations.db')

    >>> # Read them back from the database
    >>> for observation in get_db_observations('observations.db'):
    ...    print(observation)

**Main functions:**

.. autosummary::
    :nosignatures:

    create_tables
    migrate
    get_db_observations
    get_db_taxa
    save_observations
    save_taxa

**Models:**

.. currentmodule:: pyinaturalist_convert._models

.. autosummary::
    :nosignatures:

    DbObservation
    DbPhoto
    DbTaxon
    DbUser
"""

# ruff: noqa: F401
import sqlite3
from collections.abc import Iterable, Iterator
from importlib.resources import files
from itertools import chain
from logging import getLogger
from pathlib import Path
from typing import TYPE_CHECKING, Optional

from pyinaturalist import Observation, Taxon

from .constants import DB_PATH, PathOrStr

# If SQLAlchemy isn't installed, don't raise ImportErrors at import time.
# DB Model classes require SA imports in module scope, so they're wrapped here.
try:
    from ._models import Base, DbObservation, DbPhoto, DbTaxon, DbUser
except ImportError:
    pass

if TYPE_CHECKING:
    from sqlalchemy.orm import Session


INITIAL_REVISION = '1085cbe39943'

logger = getLogger(__name__)


def create_tables(db_path: PathOrStr = DB_PATH, indexes: bool = True):
    """Create all tables defined in the registry in a SQLite database, if they don't already exist;
    and optionally create secondary indexes, if they don't already exist.

    Also adds the current alembic head revision, so future migrations can be applied.

    Args:
        db_path: Path to SQLite database file
        indexes: Whether to create secondary indexes (in addition to the primary key index)
    """
    from alembic import command

    for mapper in Base.mappers:
        create_table(mapper.class_, db_path, indexes=indexes)

    alembic_cfg = get_alembic_config(db_path)
    command.stamp(alembic_cfg, 'head')


def create_table(model, db_path: PathOrStr = DB_PATH, indexes: bool = True):
    """Create a single table for the specified model, if it doesn't already exist;
    and optionally create secondary indexes, if they don't already exist.

    Args:
        model: SQLAlchemy model class
        db_path: Path to SQLite database file
        indexes: Whether to create secondary indexes (in addition to the primary key index)
    """
    from sqlalchemy.schema import CreateIndex, CreateTable

    engine = _get_engine(db_path)
    table_name = model.__tablename__

    with engine.connect() as conn:
        logger.debug(f'Creating table {table_name}')
        conn.execute(CreateTable(model.__table__, if_not_exists=True))

        if indexes:
            logger.debug(f'Creating indexes for table {table_name}')
            for index in model.__table__.indexes:
                conn.execute(CreateIndex(index, if_not_exists=True))
        conn.commit()


def migrate(db_path: PathOrStr = DB_PATH):
    """Apply all pending database migrations to upgrade the schema to the latest version.

    This is an alternative to :py :func:`create_tables` that handles incremental schema changes.
    It also handles previously created tables with no alembic revision state.
    """
    from alembic import command

    alembic_cfg = get_alembic_config(db_path)

    with sqlite3.connect(db_path) as conn:
        tables = {
            row[0]
            for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
        }

    # If tables exist but no alembic version, stamp as initial revision before upgrading
    if tables.issuperset({'observation', 'taxon', 'photo'}) and 'alembic_version' not in tables:
        command.stamp(alembic_cfg, INITIAL_REVISION)

    command.upgrade(alembic_cfg, 'head')


def get_alembic_config(db_path: PathOrStr):
    """Get alembic config for the specified SQLite database"""
    from alembic.config import Config

    # Use alembic dir from either package (under src dir) or repo (under root)
    repo_alembic_dir = Path(__file__).parent.parent / 'alembic'
    if repo_alembic_dir.is_dir():
        script_location = str(repo_alembic_dir)
    else:
        script_location = str(files('pyinaturalist_convert') / 'alembic')

    alembic_cfg = Config()
    alembic_cfg.set_main_option('script_location', script_location)
    alembic_cfg.set_main_option('sqlalchemy.url', f'sqlite:///{db_path}')
    return alembic_cfg


def get_session(db_path: PathOrStr = DB_PATH) -> 'Session':
    """Get a SQLAlchemy session for a SQLite database"""
    from sqlalchemy.orm import Session

    return Session(_get_engine(db_path), future=True)


def _get_engine(db_path):
    from sqlalchemy import create_engine

    return create_engine(f'sqlite:///{db_path}')


def get_db_observations(
    db_path: PathOrStr = DB_PATH,
    ids: Optional[Iterable[int]] = None,
    username: Optional[str] = None,
    limit: Optional[int] = None,
    page: Optional[int] = None,
    order_by_created: bool = False,
    order_by_observed: bool = False,
) -> Iterator[Observation]:
    """Load observation records and associated taxa from SQLite"""
    from sqlalchemy import desc, select

    stmt = (
        select(DbObservation)
        .join(DbObservation.taxon, isouter=True)
        .join(DbObservation.user, isouter=True)
    )
    if ids:
        stmt = stmt.where(DbObservation.id.in_(list(ids)))  # type: ignore
    if username:
        stmt = stmt.where(DbUser.login == username)
    if limit:
        stmt = stmt.limit(limit)
    if limit and page and page > 1:
        stmt = stmt.offset((page - 1) * limit)
    if order_by_created:
        stmt = stmt.order_by(desc(DbObservation.created_at))
    elif order_by_observed:
        stmt = stmt.order_by(desc(DbObservation.observed_on))

    with get_session(db_path) as session:
        for obs in session.execute(stmt):
            yield obs[0].to_model()


def get_db_taxa(
    db_path: PathOrStr = DB_PATH,
    ids: Optional[list[int]] = None,
    accept_partial: bool = True,
    limit: int = 200,
) -> Iterator[Taxon]:
    """Load taxon records from SQLite"""
    from sqlalchemy import select

    stmt = select(DbTaxon)
    if ids:
        stmt = stmt.where(DbTaxon.id.in_(ids))  # type: ignore
    if not accept_partial:
        stmt = stmt.where(DbTaxon.partial == False)  # noqa: E712
    if limit:
        stmt = stmt.limit(limit)

    with get_session(db_path) as session:
        for taxon in session.execute(stmt):
            yield taxon[0].to_model()


def save_observations(observations: Iterable[Observation], db_path: PathOrStr = DB_PATH):
    """Save Observation objects (and associated taxa and photos) to SQLite"""
    with get_session(db_path) as session:
        for observation in observations:
            session.merge(DbObservation.from_model(observation, skip_taxon=True))
        session.commit()

    save_taxa([obs.taxon for obs in observations if obs.taxon], db_path)


def save_taxa(taxa: Iterable[Taxon], db_path: PathOrStr = DB_PATH):
    """Save Taxon objects (plus ancestors and children, if available) to SQLite"""
    from sqlalchemy import select

    # Combined list of taxa plus all their unique ancestors + children
    taxa_by_id = {t.id: t for t in chain.from_iterable([t.ancestors + t.children for t in taxa])}
    taxa_by_id.update({t.id: t for t in taxa})
    unique_taxon_ids = list(taxa_by_id.keys())

    with get_session(db_path) as session:
        stmt = select(DbTaxon).where(DbTaxon.id.in_(unique_taxon_ids))  # type: ignore
        existing_taxa = {t[0].id: t[0] for t in session.execute(stmt)}

        # Merge (instead of overwriting) any existing taxa with new data
        for taxon in taxa_by_id.values():
            if db_taxon := existing_taxa.get(taxon.id):
                db_taxon.update(taxon)
            else:
                session.add(DbTaxon.from_model(taxon))

        session.commit()
