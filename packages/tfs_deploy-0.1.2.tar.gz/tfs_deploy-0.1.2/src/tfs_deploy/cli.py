"""CLI for tfs-deploy."""

import json
import os
import subprocess
import sys
from pathlib import Path

import click
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

console = Console()

# Temporary merged environment file passed to s deploy
DEPLOY_ENV_FILE = ".env.deploy"


def run_command_simple(cmd: list[str], cwd: Path | None = None, env: dict | None = None) -> tuple[int, str, str]:
    """Run a command and print output directly without Rich formatting."""
    merged_env = {**os.environ, **(env or {})}

    console.print(f"[dim]$ {' '.join(cmd)}[/dim]")

    process = subprocess.Popen(
        cmd,
        cwd=cwd,
        env=merged_env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
        universal_newlines=True
    )

    stdout_lines = []
    if process.stdout:
        for line in process.stdout:
            print(line, end='')
            stdout_lines.append(line)

    process.wait()
    stdout = "".join(stdout_lines)

    return process.returncode, stdout, ""


def load_env_file(env_file: Path) -> dict:
    """Load environment variables from a file."""
    env = {}
    if env_file.exists():
        with open(env_file) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, value = line.split("=", 1)
                    env[key] = value
    return env


def write_env_file(env_file: Path, env: dict) -> None:
    """Write environment variables to a file with proper quoting."""
    with open(env_file, "w") as f:
        for key, value in sorted(env.items()):
            # Quote values that contain spaces, special chars, or start with special chars
            if not value:
                f.write(f"{key}=''\n")
            elif any(c in value for c in ' \t\n\r"\'\\$`!#&|;<>') or value.startswith(('-', '[', '{')):
                # Escape single quotes and wrap in single quotes
                escaped = value.replace("'", "'\"'\"'")
                f.write(f"{key}='{escaped}'\n")
            else:
                f.write(f"{key}={value}\n")


def print_header(title: str) -> None:
    """Print a section header."""
    console.print()
    console.print(Panel(Text(title, style="bold blue"), border_style="blue"))


def print_success(message: str) -> None:
    """Print a success message."""
    console.print(f"[green]✓[/green] {message}")


def print_error(message: str) -> None:
    """Print an error message."""
    console.print(f"[red]✗[/red] {message}")


def print_warning(message: str) -> None:
    """Print a warning message."""
    console.print(f"[yellow]⚠[/yellow] {message}")


@click.group()
@click.version_option(version=__import__("tfs_deploy").__version__, prog_name="tfs")
def cli():
    """TFS Deploy - Terraform + Serverless Devs deployment orchestrator."""
    pass


@cli.command()
@click.option("--stage", "-s", default=None, help="Deployment stage (dev, beta, prod)")
@click.option("--region", "-r", default=None, help="Alibaba Cloud region")
@click.option("--profile", "-p", default=None, help="Alibaba Cloud CLI profile")
@click.option("--skip-terraform", is_flag=True, help="Skip Terraform apply")
@click.option("--skip-deploy", is_flag=True, help="Skip s deploy")
@click.option("--skip-tests", is_flag=True, help="Skip integration tests")
@click.option("--auto-approve", "-y", is_flag=True, help="Auto approve Terraform changes")
@click.option("--terraform-dir", default=".", help="Directory containing Terraform files")
@click.option("--test-path", default="tests/integration", help="Path to integration tests")
@click.pass_context
def deploy(
    ctx,
    stage: str,
    region: str,
    profile: str,
    skip_terraform: bool,
    skip_deploy: bool,
    skip_tests: bool,
    auto_approve: bool,
    terraform_dir: str,
    test_path: str,
):
    """Deploy infrastructure and functions."""
    cwd = Path.cwd()

    # Load base .env file
    base_env = load_env_file(cwd / ".env")
    
    # Apply CLI overrides
    if stage:
        base_env["STAGE"] = stage
    if region:
        base_env["REGION"] = region
    if profile:
        base_env["PROFILE"] = profile

    # Use env values as defaults if CLI args not provided
    stage = base_env.get("STAGE", "dev")
    region = base_env.get("REGION", "us-west-1")
    profile = base_env.get("PROFILE", "default")

    # Build deployment environment (merged env passed to all commands)
    deploy_env = {**os.environ, **base_env}

    # Auto-pass all env vars as TF_VAR_* (lowercase) to Terraform
    for key, value in list(deploy_env.items()):
        if not key.startswith("TF_VAR_"):
            tf_key = f"TF_VAR_{key.lower()}"
            if tf_key not in deploy_env:
                deploy_env[tf_key] = value

    console.print(Panel.fit(
        f"[bold]TFS Deploy[/bold]\n"
        f"Stage: [cyan]{stage}[/cyan] | "
        f"Region: [cyan]{region}[/cyan] | "
        f"Profile: [cyan]{profile}[/cyan]"
    ))

    # Step 1: Terraform
    if not skip_terraform:
        print_header("Step 1: Terraform Infrastructure")

        tf_dir = cwd / terraform_dir
        if not (tf_dir / "main.tf").exists():
            print_warning(f"No main.tf found in {tf_dir}, skipping Terraform")
        else:
            try:
                console.print("[dim]Initializing Terraform...[/dim]")
                returncode, _, _ = run_command_simple(
                    ["terraform", "init",
                     "-backend-config", f"profile={profile}",
                     "-backend-config", f"region={region}",
                     "-backend-config", f"key={stage}/terraform.tfstate"],
                    cwd=tf_dir,
                    env=deploy_env
                )
                if returncode != 0:
                    raise click.ClickException("Terraform init failed")

                apply_cmd = ["terraform", "apply"]
                if auto_approve:
                    apply_cmd.append("-auto-approve")

                console.print("[dim]Applying Terraform changes...[/dim]")
                returncode, _, _ = run_command_simple(apply_cmd, cwd=tf_dir, env=deploy_env)
                if returncode != 0:
                    raise click.ClickException("Terraform apply failed")

                console.print("[dim]Exporting Terraform outputs...[/dim]")
                result = subprocess.run(
                    ["terraform", "output", "-json"],
                    cwd=tf_dir,
                    capture_output=True,
                    text=True
                )

                if result.returncode == 0:
                    outputs = json.loads(result.stdout)
                    # Add Terraform outputs to deploy_env (uppercase keys)
                    for key, value in outputs.items():
                        if isinstance(value, dict) and "value" in value:
                            env_key = key.upper()
                            deploy_env[env_key] = str(value["value"])

                print_success("Terraform infrastructure ready")

            except click.ClickException:
                raise
            except Exception as e:
                print_error(f"Terraform failed: {e}")
                raise
    else:
        print_warning("Skipping Terraform (as requested)")
        # Load existing .env.deploy if skipping terraform (preserves previous outputs)
        existing_deploy_env = load_env_file(cwd / DEPLOY_ENV_FILE)
        deploy_env.update(existing_deploy_env)

    # Write merged deploy_env to .env.deploy for s deploy
    deploy_env_file = cwd / DEPLOY_ENV_FILE
    write_env_file(deploy_env_file, {k: v for k, v in deploy_env.items() if not k.startswith("TF_VAR_")})
    print_success(f"Deployment environment written to {deploy_env_file}")

    # Step 2: Serverless Devs Deploy
    if not skip_deploy:
        print_header("Step 2: Serverless Devs Deploy")

        if not (cwd / "s.yaml").exists():
            print_error("No s.yaml found in current directory")
            raise click.ClickException("s.yaml is required for deployment")

        try:
            # Pass deploy_env to s deploy so it can read environment variables
            returncode, _, _ = run_command_simple(["s", "deploy", "-y"], cwd=cwd, env=deploy_env)
            if returncode != 0:
                print_warning("s deploy returned non-zero exit code, but continuing...")
            print_success("Function deployment completed")
        except Exception as e:
            print_error(f"s deploy failed: {e}")
            raise
    else:
        print_warning("Skipping s deploy (as requested)")

    # Step 3: Integration Tests
    if not skip_tests:
        print_header("Step 3: Integration Tests")

        test_dir = cwd / test_path
        if not test_dir.exists():
            print_warning(f"Test directory not found: {test_path}")
        else:
            try:
                venv_python = cwd / ".venv" / "bin" / "python"
                if not venv_python.exists():
                    venv_python = cwd / ".venv" / "Scripts" / "python.exe"

                if venv_python.exists():
                    pytest_cmd = [str(venv_python), "-m", "pytest", str(test_path), "-v"]
                else:
                    pytest_cmd = ["pytest", str(test_path), "-v"]

                returncode, _, _ = run_command_simple(pytest_cmd, cwd=cwd, env=deploy_env)

                if returncode == 0:
                    print_success("All integration tests passed")
                else:
                    print_error("Some integration tests failed")

            except Exception as e:
                print_warning(f"Integration tests failed: {e}")
    else:
        print_warning("Skipping integration tests (as requested)")

    # Clean up .env.deploy after successful deployment (optional)
    # deploy_env_file.unlink(missing_ok=True)

    console.print()
    console.print(Panel.fit(
        f"[bold green]Deployment Complete![/bold green]\n"
        f"Stage: [cyan]{stage}[/cyan] | Region: [cyan]{region}[/cyan]"
    ))


@cli.command()
@click.option("--stage", "-s", default=None, help="Deployment stage")
@click.option("--region", "-r", default=None, help="Alibaba Cloud region")
@click.option("--profile", "-p", default=None, help="Alibaba Cloud CLI profile")
@click.option("--terraform-dir", default=".", help="Directory containing Terraform files")
def destroy(
    stage: str,
    region: str,
    profile: str,
    terraform_dir: str,
):
    """Destroy Terraform infrastructure."""
    cwd = Path.cwd()
    tf_dir = cwd / terraform_dir

    # Load base .env file
    base_env = load_env_file(cwd / ".env")
    
    # Apply CLI overrides
    if stage:
        base_env["STAGE"] = stage
    if region:
        base_env["REGION"] = region
    if profile:
        base_env["PROFILE"] = profile

    # Use env values as defaults if CLI args not provided
    stage = base_env.get("STAGE", "dev")
    region = base_env.get("REGION", "us-west-1")
    profile = base_env.get("PROFILE", "default")

    # Build deployment environment
    deploy_env = {**os.environ, **base_env}

    # Auto-pass all env vars as TF_VAR_* (lowercase) to Terraform
    for key, value in list(deploy_env.items()):
        if not key.startswith("TF_VAR_"):
            tf_key = f"TF_VAR_{key.lower()}"
            if tf_key not in deploy_env:
                deploy_env[tf_key] = value

    print_header("Destroying Terraform Infrastructure")

    if not (tf_dir / "main.tf").exists():
        print_error(f"No Terraform files found in {tf_dir}")
        return

    try:
        returncode, _, _ = run_command_simple(
            ["terraform", "destroy", "-auto-approve"],
            cwd=tf_dir,
            env=deploy_env
        )
        if returncode != 0:
            raise click.ClickException("Terraform destroy failed")
        print_success("Infrastructure destroyed")
    except click.ClickException:
        raise
    except Exception as e:
        print_error(f"Terraform destroy failed: {e}")
        raise


@cli.command()
def init():
    """Initialize a new service with Terraform + s.yaml structure."""
    cwd = Path.cwd()

    print_header("Initializing TFS Project Structure")

    dirs = ["scripts", "src", "tests/unit", "tests/integration"]
    for d in dirs:
        (cwd / d).mkdir(parents=True, exist_ok=True)

    files = {
        ".env": "STAGE=dev\nREGION=us-west-1\nPROFILE=default\n",
        ".gitignore": ".env.terraform\n.terraform/\n*.tfstate\n*.tfstate.backup\n.venv/\n__pycache__/\n",
    }

    for filename, content in files.items():
        filepath = cwd / filename
        if not filepath.exists():
            filepath.write_text(content)
            print_success(f"Created {filename}")
        else:
            print_warning(f"{filename} already exists, skipping")

    console.print()
    console.print("[bold]Next steps:[/bold]")
    console.print("1. Create your main.tf for infrastructure")
    console.print("2. Create your s.yaml for function deployment")
    console.print("3. Run [cyan]tfs deploy[/cyan] to deploy")


def main():
    """Entry point for the CLI."""
    cli()


if __name__ == "__main__":
    main()
