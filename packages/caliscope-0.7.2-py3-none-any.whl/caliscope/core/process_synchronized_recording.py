"""Batch processing of synchronized multi-camera video.

Pure function that extracts 2D landmarks from synchronized video streams.
Uses batch synchronization from timestamps.csv — no real-time streaming.
"""

import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

import numpy as np
import pandas as pd
from numpy.typing import NDArray

from caliscope.cameras.camera_array import CameraData
from caliscope.core.point_data import ImagePoints
from caliscope.packets import PointPacket
from caliscope.recording.frame_source import FrameSource
from caliscope.recording.frame_sync import compute_sync_indices
from caliscope.task_manager.cancellation import CancellationToken
from caliscope.tracker import Tracker

logger = logging.getLogger(__name__)


@dataclass
class FrameData:
    """Frame data for a single camera at a sync index."""

    frame: NDArray[np.uint8]
    points: PointPacket | None
    frame_index: int


def process_synchronized_recording(
    recording_dir: Path,
    cameras: dict[int, CameraData],
    tracker: Tracker,
    *,
    subsample: int = 1,
    on_progress: Callable[[int, int], None] | None = None,
    on_frame_data: Callable[[int, dict[int, FrameData]], None] | None = None,
    token: CancellationToken | None = None,
) -> ImagePoints:
    """Process synchronized video recordings to extract 2D landmarks.

    Reads timestamps.csv to determine frame alignment, then processes
    each sync index by seeking directly to aligned frames.

    Args:
        recording_dir: Directory containing cam_N.mp4 and timestamps.csv
        cameras: Camera data by cam_id (provides rotation_count for frame orientation)
        tracker: Tracker for 2D point extraction (handles per-cam_id state internally)
        subsample: Process every Nth sync index (1 = all, 10 = every 10th)
        on_progress: Called with (current, total) during processing
        on_frame_data: Called with (sync_index, {cam_id: FrameData}) for live display
        token: Cancellation token for graceful shutdown

    Returns:
        ImagePoints containing all tracked 2D observations
    """
    # Load frame timestamps and compute sync assignments
    timestamps_csv = recording_dir / "timestamps.csv"
    sync_map = compute_sync_indices(timestamps_csv)

    # Load frame_time data for enriching output
    timestamps_df = pd.read_csv(timestamps_csv)
    frame_times = _build_frame_time_lookup(timestamps_df)

    # Get sync indices to process (with subsampling)
    all_sync_indices = sorted(sync_map.keys())
    sync_indices_to_process = all_sync_indices[::subsample]
    total = len(sync_indices_to_process)

    logger.info(f"Processing {total} sync indices (subsample={subsample}, total available={len(all_sync_indices)})")

    # Create frame sources (one per camera, for seeking)
    frame_sources = _create_frame_sources(recording_dir, cameras)

    # Point accumulation
    point_rows: list[dict] = []

    try:
        for i, sync_index in enumerate(sync_indices_to_process):
            # Check cancellation
            if token is not None and token.is_cancelled:
                logger.info("Processing cancelled")
                break

            # Read and track frames for this sync index
            frame_data: dict[int, FrameData] = {}
            cam_id_assignments = sync_map[sync_index]

            for cam_id, frame_index in cam_id_assignments.items():
                if frame_index is None:
                    logger.debug(f"Dropped frame: sync={sync_index}, cam_id={cam_id}")
                    continue

                if cam_id not in frame_sources:
                    # Camera in sync_map but not in cameras dict (shouldn't happen)
                    logger.warning(f"cam_id {cam_id} not in cameras dict, skipping")
                    continue

                camera = cameras[cam_id]
                frame = frame_sources[cam_id].get_frame(frame_index)

                if frame is None:
                    logger.warning(
                        f"Failed to read frame: sync={sync_index}, cam_id={cam_id}, frame_index={frame_index}"
                    )
                    continue

                # Tracker handles per-cam_id state internally via cam_id parameter
                points = tracker.get_points(frame, cam_id, camera.rotation_count)
                frame_data[cam_id] = FrameData(frame, points, frame_index)

                # Accumulate points
                frame_time = frame_times.get((cam_id, frame_index), 0.0)
                _accumulate_points(point_rows, sync_index, cam_id, frame_index, frame_time, points)

            # Invoke callbacks
            if on_frame_data is not None:
                on_frame_data(sync_index, frame_data)
            if on_progress is not None:
                on_progress(i + 1, total)

    finally:
        for source in frame_sources.values():
            source.close()

    return _build_image_points(point_rows)


def get_initial_thumbnails(
    recording_dir: Path,
    cameras: dict[int, CameraData],
) -> dict[int, NDArray[np.uint8]]:
    """Extract first frame from each camera for thumbnail display.

    Uses same FrameSource mechanism as processing, just reads frame 0.

    Args:
        recording_dir: Directory containing cam_N.mp4 files
        cameras: Camera data by cam_id

    Returns:
        Mapping of cam_id -> first frame (BGR image)
    """
    thumbnails: dict[int, NDArray[np.uint8]] = {}

    for cam_id in cameras:
        try:
            source = FrameSource(recording_dir, cam_id)
            frame = source.get_frame(0)
            source.close()

            if frame is not None:
                thumbnails[cam_id] = frame
            else:
                logger.warning(f"Could not read first frame for cam_id {cam_id}")
        except FileNotFoundError:
            logger.warning(f"Video file not found for cam_id {cam_id}")
        except ValueError as e:
            logger.warning(f"Error opening video for cam_id {cam_id}: {e}")

    return thumbnails


def _create_frame_sources(recording_dir: Path, cameras: dict[int, CameraData]) -> dict[int, FrameSource]:
    """Create FrameSource for each camera cam_id."""
    sources: dict[int, FrameSource] = {}

    for cam_id in cameras:
        try:
            sources[cam_id] = FrameSource(recording_dir, cam_id)
        except FileNotFoundError:
            logger.warning(f"Video file not found for cam_id {cam_id}, skipping")
        except ValueError as e:
            logger.warning(f"Error opening video for cam_id {cam_id}: {e}")

    return sources


def _build_frame_time_lookup(timestamps_df: pd.DataFrame) -> dict[tuple[int, int], float]:
    """Build lookup table: (cam_id, frame_index) -> frame_time.

    Frame index is the row number within each cam_id's sequence.
    """
    lookup: dict[tuple[int, int], float] = {}

    for cam_id, group in timestamps_df.groupby("cam_id"):
        sorted_group = group.sort_values("frame_time").reset_index(drop=True)
        for frame_index, row in sorted_group.iterrows():
            # frame_index here is actually the integer index from iterrows
            lookup[(int(cam_id), int(frame_index))] = float(row["frame_time"])  # type: ignore[arg-type]

    return lookup


def _accumulate_points(
    point_rows: list[dict],
    sync_index: int,
    cam_id: int,
    frame_index: int,
    frame_time: float,
    points: PointPacket | None,
) -> None:
    """Append point data to accumulator list."""
    if points is None:
        return

    point_count = len(points.point_id)
    if point_count == 0:
        return

    # Get obj_loc columns (may be None)
    obj_loc_x, obj_loc_y, obj_loc_z = points.obj_loc_list

    for i in range(point_count):
        point_rows.append(
            {
                "sync_index": sync_index,
                "cam_id": cam_id,
                "frame_index": frame_index,
                "frame_time": frame_time,
                "point_id": int(points.point_id[i]),
                "img_loc_x": float(points.img_loc[i, 0]),
                "img_loc_y": float(points.img_loc[i, 1]),
                "obj_loc_x": obj_loc_x[i],
                "obj_loc_y": obj_loc_y[i],
                "obj_loc_z": obj_loc_z[i],
            }
        )


def _build_image_points(point_rows: list[dict]) -> ImagePoints:
    """Construct ImagePoints from accumulated point data."""
    if not point_rows:
        # Return empty ImagePoints with correct schema
        df = pd.DataFrame(
            columns=[
                "sync_index",
                "cam_id",
                "frame_index",
                "frame_time",
                "point_id",
                "img_loc_x",
                "img_loc_y",
                "obj_loc_x",
                "obj_loc_y",
                "obj_loc_z",
            ]
        )
        return ImagePoints(df)

    df = pd.DataFrame(point_rows)
    return ImagePoints(df)
