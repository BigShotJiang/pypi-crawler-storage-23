from __future__ import annotations


class ProphetError(Exception):
    pass

