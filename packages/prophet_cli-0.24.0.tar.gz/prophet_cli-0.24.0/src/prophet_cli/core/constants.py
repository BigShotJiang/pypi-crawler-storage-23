from __future__ import annotations


BASE_TYPES = {
    "string",
    "int",
    "long",
    "short",
    "byte",
    "double",
    "float",
    "decimal",
    "boolean",
    "datetime",
    "date",
    "duration",
}

