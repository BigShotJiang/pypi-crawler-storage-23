from __future__ import annotations

from .generator import JavaSpringJpaDeps
from .generator import generate_outputs

__all__ = [
    "JavaSpringJpaDeps",
    "generate_outputs",
]

