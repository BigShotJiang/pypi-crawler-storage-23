# src/geobpe/cli.py

from __future__ import annotations

import argparse
from typing import Sequence

from geobpe.commands.encode import add_parser as add_encode_parser
from geobpe.commands.encode import run as run_encode
from geobpe.commands.induce import add_parser as add_induce_parser
from geobpe.commands.induce import run as run_induce


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="geobpe",
        description="GeoBPE command-line interface",
    )
    subparsers = parser.add_subparsers(
        dest="command",
        required=True,
        title="subcommands",
        metavar="{encode,induce}",
        help="Available GeoBPE subcommands",
    )
    # geobpe encode ...
    encode_parser = subparsers.add_parser(
        "encode",
        help="Train GeoBPE tokenizer and encode protein structures",
    )
    add_encode_parser(encode_parser)
    encode_parser.set_defaults(func=run_encode)

    # geobpe induce ...
    induce_parser = subparsers.add_parser(
        "induce",
        help="Tokenize new structures and induce token hierarchy",
    )
    add_induce_parser(induce_parser)
    induce_parser.set_defaults(func=run_induce)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if not hasattr(args, "func"):
        parser.print_help()
        return 1
    result = args.func(args)
    return int(result) if isinstance(result, int) else 0


if __name__ == "__main__":
    raise SystemExit(main())
