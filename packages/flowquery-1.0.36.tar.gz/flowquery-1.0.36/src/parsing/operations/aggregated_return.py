from typing import Any, Dict, List

from ..ast_node import ASTNode
from .group_by import GroupBy
from .return_op import Return


class AggregatedReturn(Return):
    """Represents an aggregated RETURN operation that groups and reduces values."""

    def __init__(self, expressions: List[ASTNode]) -> None:
        super().__init__(expressions)
        self._group_by = GroupBy(self.children)

    async def run(self) -> None:
        await self._group_by.run()

    @property
    def results(self) -> List[Dict[str, Any]]:
        if self._where is not None:
            self._group_by.where = self._where
        results = list(self._group_by.generate_results())
        if self._order_by is not None:
            results = self._order_by.sort(results)
        return results
